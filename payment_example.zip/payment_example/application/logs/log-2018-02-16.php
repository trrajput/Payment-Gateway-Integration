<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2018-02-16 10:02:15 --> Config Class Initialized
INFO - 2018-02-16 10:02:15 --> Hooks Class Initialized
DEBUG - 2018-02-16 10:02:15 --> UTF-8 Support Enabled
INFO - 2018-02-16 10:02:15 --> Utf8 Class Initialized
INFO - 2018-02-16 10:02:15 --> URI Class Initialized
INFO - 2018-02-16 10:02:15 --> Router Class Initialized
INFO - 2018-02-16 10:02:16 --> Output Class Initialized
INFO - 2018-02-16 10:02:16 --> Security Class Initialized
DEBUG - 2018-02-16 10:02:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-16 10:02:16 --> Input Class Initialized
INFO - 2018-02-16 10:02:16 --> Language Class Initialized
INFO - 2018-02-16 10:02:16 --> Loader Class Initialized
INFO - 2018-02-16 10:02:16 --> Helper loaded: url_helper
INFO - 2018-02-16 10:02:16 --> Helper loaded: file_helper
INFO - 2018-02-16 10:02:16 --> Helper loaded: email_helper
INFO - 2018-02-16 10:02:16 --> Helper loaded: common_helper
INFO - 2018-02-16 10:02:16 --> Database Driver Class Initialized
DEBUG - 2018-02-16 10:02:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-16 10:02:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-16 10:02:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-16 10:02:16 --> Pagination Class Initialized
INFO - 2018-02-16 10:02:16 --> Helper loaded: form_helper
INFO - 2018-02-16 10:02:16 --> Form Validation Class Initialized
INFO - 2018-02-16 10:02:16 --> Model Class Initialized
INFO - 2018-02-16 10:02:16 --> Controller Class Initialized
INFO - 2018-02-16 10:02:16 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-16 10:02:16 --> Config Class Initialized
INFO - 2018-02-16 10:02:16 --> Hooks Class Initialized
DEBUG - 2018-02-16 10:02:16 --> UTF-8 Support Enabled
INFO - 2018-02-16 10:02:16 --> Utf8 Class Initialized
INFO - 2018-02-16 10:02:16 --> URI Class Initialized
DEBUG - 2018-02-16 10:02:16 --> No URI present. Default controller set.
INFO - 2018-02-16 10:02:16 --> Router Class Initialized
INFO - 2018-02-16 10:02:16 --> Output Class Initialized
INFO - 2018-02-16 10:02:16 --> Security Class Initialized
DEBUG - 2018-02-16 10:02:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-16 10:02:16 --> Input Class Initialized
INFO - 2018-02-16 10:02:16 --> Language Class Initialized
INFO - 2018-02-16 10:02:16 --> Loader Class Initialized
INFO - 2018-02-16 10:02:16 --> Helper loaded: url_helper
INFO - 2018-02-16 10:02:16 --> Helper loaded: file_helper
INFO - 2018-02-16 10:02:16 --> Helper loaded: email_helper
INFO - 2018-02-16 10:02:16 --> Helper loaded: common_helper
INFO - 2018-02-16 10:02:16 --> Database Driver Class Initialized
DEBUG - 2018-02-16 10:02:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-16 10:02:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-16 10:02:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-16 10:02:16 --> Pagination Class Initialized
INFO - 2018-02-16 10:02:16 --> Helper loaded: form_helper
INFO - 2018-02-16 10:02:16 --> Form Validation Class Initialized
INFO - 2018-02-16 10:02:16 --> Model Class Initialized
INFO - 2018-02-16 10:02:16 --> Controller Class Initialized
INFO - 2018-02-16 10:02:16 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-16 10:02:16 --> Model Class Initialized
INFO - 2018-02-16 10:02:16 --> File loaded: /var/www/html/project/radio/application/views/index/index.php
INFO - 2018-02-16 10:02:16 --> Final output sent to browser
DEBUG - 2018-02-16 10:02:16 --> Total execution time: 0.0304
INFO - 2018-02-16 10:02:18 --> Config Class Initialized
INFO - 2018-02-16 10:02:18 --> Hooks Class Initialized
DEBUG - 2018-02-16 10:02:18 --> UTF-8 Support Enabled
INFO - 2018-02-16 10:02:18 --> Utf8 Class Initialized
INFO - 2018-02-16 10:02:18 --> URI Class Initialized
INFO - 2018-02-16 10:02:18 --> Router Class Initialized
INFO - 2018-02-16 10:02:18 --> Output Class Initialized
INFO - 2018-02-16 10:02:18 --> Security Class Initialized
DEBUG - 2018-02-16 10:02:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-16 10:02:18 --> Input Class Initialized
INFO - 2018-02-16 10:02:18 --> Language Class Initialized
INFO - 2018-02-16 10:02:18 --> Loader Class Initialized
INFO - 2018-02-16 10:02:18 --> Helper loaded: url_helper
INFO - 2018-02-16 10:02:18 --> Helper loaded: file_helper
INFO - 2018-02-16 10:02:18 --> Helper loaded: email_helper
INFO - 2018-02-16 10:02:18 --> Helper loaded: common_helper
INFO - 2018-02-16 10:02:18 --> Database Driver Class Initialized
DEBUG - 2018-02-16 10:02:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-16 10:02:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-16 10:02:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-16 10:02:18 --> Pagination Class Initialized
INFO - 2018-02-16 10:02:18 --> Helper loaded: form_helper
INFO - 2018-02-16 10:02:18 --> Form Validation Class Initialized
INFO - 2018-02-16 10:02:18 --> Model Class Initialized
INFO - 2018-02-16 10:02:18 --> Controller Class Initialized
INFO - 2018-02-16 10:02:18 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-16 10:02:18 --> Model Class Initialized
ERROR - 2018-02-16 10:02:18 --> Severity: Notice --> Undefined index: remember_me /var/www/html/project/radio/application/controllers/Index.php 73
INFO - 2018-02-16 10:02:18 --> Config Class Initialized
INFO - 2018-02-16 10:02:18 --> Hooks Class Initialized
DEBUG - 2018-02-16 10:02:18 --> UTF-8 Support Enabled
INFO - 2018-02-16 10:02:18 --> Utf8 Class Initialized
INFO - 2018-02-16 10:02:18 --> URI Class Initialized
INFO - 2018-02-16 10:02:18 --> Router Class Initialized
INFO - 2018-02-16 10:02:18 --> Output Class Initialized
INFO - 2018-02-16 10:02:18 --> Security Class Initialized
DEBUG - 2018-02-16 10:02:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-16 10:02:18 --> Input Class Initialized
INFO - 2018-02-16 10:02:18 --> Language Class Initialized
INFO - 2018-02-16 10:02:18 --> Loader Class Initialized
INFO - 2018-02-16 10:02:18 --> Helper loaded: url_helper
INFO - 2018-02-16 10:02:18 --> Helper loaded: file_helper
INFO - 2018-02-16 10:02:18 --> Helper loaded: email_helper
INFO - 2018-02-16 10:02:18 --> Helper loaded: common_helper
INFO - 2018-02-16 10:02:18 --> Database Driver Class Initialized
DEBUG - 2018-02-16 10:02:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-16 10:02:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-16 10:02:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-16 10:02:18 --> Pagination Class Initialized
INFO - 2018-02-16 10:02:18 --> Helper loaded: form_helper
INFO - 2018-02-16 10:02:18 --> Form Validation Class Initialized
INFO - 2018-02-16 10:02:18 --> Model Class Initialized
INFO - 2018-02-16 10:02:18 --> Controller Class Initialized
INFO - 2018-02-16 10:02:18 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-16 10:02:18 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-16 10:02:18 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-16 10:02:18 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-16 10:02:18 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-16 10:02:18 --> File loaded: /var/www/html/project/radio/application/views/dashboard/index.php
INFO - 2018-02-16 10:02:18 --> Final output sent to browser
DEBUG - 2018-02-16 10:02:18 --> Total execution time: 0.0565
INFO - 2018-02-16 10:02:29 --> Config Class Initialized
INFO - 2018-02-16 10:02:29 --> Hooks Class Initialized
DEBUG - 2018-02-16 10:02:29 --> UTF-8 Support Enabled
INFO - 2018-02-16 10:02:29 --> Utf8 Class Initialized
INFO - 2018-02-16 10:02:29 --> URI Class Initialized
INFO - 2018-02-16 10:02:29 --> Router Class Initialized
INFO - 2018-02-16 10:02:29 --> Output Class Initialized
INFO - 2018-02-16 10:02:29 --> Security Class Initialized
DEBUG - 2018-02-16 10:02:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-16 10:02:29 --> Input Class Initialized
INFO - 2018-02-16 10:02:29 --> Language Class Initialized
INFO - 2018-02-16 10:02:29 --> Loader Class Initialized
INFO - 2018-02-16 10:02:29 --> Helper loaded: url_helper
INFO - 2018-02-16 10:02:29 --> Helper loaded: file_helper
INFO - 2018-02-16 10:02:29 --> Helper loaded: email_helper
INFO - 2018-02-16 10:02:29 --> Helper loaded: common_helper
INFO - 2018-02-16 10:02:29 --> Database Driver Class Initialized
DEBUG - 2018-02-16 10:02:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-16 10:02:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-16 10:02:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-16 10:02:29 --> Pagination Class Initialized
INFO - 2018-02-16 10:02:29 --> Helper loaded: form_helper
INFO - 2018-02-16 10:02:29 --> Form Validation Class Initialized
INFO - 2018-02-16 10:02:29 --> Model Class Initialized
INFO - 2018-02-16 10:02:29 --> Controller Class Initialized
INFO - 2018-02-16 10:02:29 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-16 10:02:29 --> Model Class Initialized
INFO - 2018-02-16 10:02:29 --> Model Class Initialized
INFO - 2018-02-16 10:02:29 --> Model Class Initialized
INFO - 2018-02-16 10:02:29 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-16 10:02:29 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-16 10:02:29 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-16 10:02:29 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-16 10:02:29 --> File loaded: /var/www/html/project/radio/application/views/tracks/index.php
INFO - 2018-02-16 10:02:29 --> Final output sent to browser
DEBUG - 2018-02-16 10:02:29 --> Total execution time: 0.0085
INFO - 2018-02-16 10:02:30 --> Config Class Initialized
INFO - 2018-02-16 10:02:30 --> Hooks Class Initialized
DEBUG - 2018-02-16 10:02:30 --> UTF-8 Support Enabled
INFO - 2018-02-16 10:02:30 --> Utf8 Class Initialized
INFO - 2018-02-16 10:02:30 --> URI Class Initialized
INFO - 2018-02-16 10:02:30 --> Router Class Initialized
INFO - 2018-02-16 10:02:30 --> Output Class Initialized
INFO - 2018-02-16 10:02:30 --> Security Class Initialized
DEBUG - 2018-02-16 10:02:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-16 10:02:30 --> Input Class Initialized
INFO - 2018-02-16 10:02:30 --> Language Class Initialized
INFO - 2018-02-16 10:02:30 --> Loader Class Initialized
INFO - 2018-02-16 10:02:30 --> Helper loaded: url_helper
INFO - 2018-02-16 10:02:30 --> Helper loaded: file_helper
INFO - 2018-02-16 10:02:30 --> Helper loaded: email_helper
INFO - 2018-02-16 10:02:30 --> Helper loaded: common_helper
INFO - 2018-02-16 10:02:30 --> Database Driver Class Initialized
DEBUG - 2018-02-16 10:02:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-16 10:02:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-16 10:02:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-16 10:02:30 --> Pagination Class Initialized
INFO - 2018-02-16 10:02:30 --> Helper loaded: form_helper
INFO - 2018-02-16 10:02:30 --> Form Validation Class Initialized
INFO - 2018-02-16 10:02:30 --> Model Class Initialized
INFO - 2018-02-16 10:02:30 --> Controller Class Initialized
INFO - 2018-02-16 10:02:30 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-16 10:02:30 --> Model Class Initialized
INFO - 2018-02-16 10:02:30 --> Model Class Initialized
INFO - 2018-02-16 10:02:30 --> Model Class Initialized
INFO - 2018-02-16 10:19:03 --> Config Class Initialized
INFO - 2018-02-16 10:19:03 --> Hooks Class Initialized
DEBUG - 2018-02-16 10:19:03 --> UTF-8 Support Enabled
INFO - 2018-02-16 10:19:03 --> Utf8 Class Initialized
INFO - 2018-02-16 10:19:03 --> URI Class Initialized
INFO - 2018-02-16 10:19:03 --> Router Class Initialized
INFO - 2018-02-16 10:19:03 --> Output Class Initialized
INFO - 2018-02-16 10:19:03 --> Security Class Initialized
DEBUG - 2018-02-16 10:19:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-16 10:19:03 --> Input Class Initialized
INFO - 2018-02-16 10:19:03 --> Language Class Initialized
INFO - 2018-02-16 10:19:03 --> Loader Class Initialized
INFO - 2018-02-16 10:19:03 --> Helper loaded: url_helper
INFO - 2018-02-16 10:19:03 --> Helper loaded: file_helper
INFO - 2018-02-16 10:19:03 --> Helper loaded: email_helper
INFO - 2018-02-16 10:19:03 --> Helper loaded: common_helper
INFO - 2018-02-16 10:19:03 --> Database Driver Class Initialized
DEBUG - 2018-02-16 10:19:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-16 10:19:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-16 10:19:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-16 10:19:03 --> Pagination Class Initialized
INFO - 2018-02-16 10:19:03 --> Helper loaded: form_helper
INFO - 2018-02-16 10:19:03 --> Form Validation Class Initialized
INFO - 2018-02-16 10:19:03 --> Model Class Initialized
INFO - 2018-02-16 10:19:03 --> Controller Class Initialized
INFO - 2018-02-16 10:19:03 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-16 10:19:03 --> Model Class Initialized
INFO - 2018-02-16 10:19:03 --> Model Class Initialized
INFO - 2018-02-16 10:19:03 --> Model Class Initialized
INFO - 2018-02-16 10:19:03 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-16 10:19:03 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-16 10:19:03 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-16 10:19:03 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-16 10:19:03 --> File loaded: /var/www/html/project/radio/application/views/tracks/index.php
INFO - 2018-02-16 10:19:03 --> Final output sent to browser
DEBUG - 2018-02-16 10:19:03 --> Total execution time: 0.0382
INFO - 2018-02-16 10:19:04 --> Config Class Initialized
INFO - 2018-02-16 10:19:04 --> Hooks Class Initialized
DEBUG - 2018-02-16 10:19:04 --> UTF-8 Support Enabled
INFO - 2018-02-16 10:19:04 --> Utf8 Class Initialized
INFO - 2018-02-16 10:19:04 --> URI Class Initialized
INFO - 2018-02-16 10:19:04 --> Router Class Initialized
INFO - 2018-02-16 10:19:04 --> Output Class Initialized
INFO - 2018-02-16 10:19:04 --> Security Class Initialized
DEBUG - 2018-02-16 10:19:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-16 10:19:04 --> Input Class Initialized
INFO - 2018-02-16 10:19:04 --> Language Class Initialized
INFO - 2018-02-16 10:19:04 --> Loader Class Initialized
INFO - 2018-02-16 10:19:04 --> Helper loaded: url_helper
INFO - 2018-02-16 10:19:04 --> Helper loaded: file_helper
INFO - 2018-02-16 10:19:04 --> Helper loaded: email_helper
INFO - 2018-02-16 10:19:04 --> Helper loaded: common_helper
INFO - 2018-02-16 10:19:04 --> Database Driver Class Initialized
DEBUG - 2018-02-16 10:19:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-16 10:19:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-16 10:19:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-16 10:19:04 --> Pagination Class Initialized
INFO - 2018-02-16 10:19:04 --> Helper loaded: form_helper
INFO - 2018-02-16 10:19:04 --> Form Validation Class Initialized
INFO - 2018-02-16 10:19:04 --> Model Class Initialized
INFO - 2018-02-16 10:19:04 --> Controller Class Initialized
INFO - 2018-02-16 10:19:04 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-16 10:19:04 --> Model Class Initialized
INFO - 2018-02-16 10:19:04 --> Model Class Initialized
INFO - 2018-02-16 10:19:04 --> Model Class Initialized
INFO - 2018-02-16 10:19:41 --> Config Class Initialized
INFO - 2018-02-16 10:19:41 --> Hooks Class Initialized
DEBUG - 2018-02-16 10:19:41 --> UTF-8 Support Enabled
INFO - 2018-02-16 10:19:41 --> Utf8 Class Initialized
INFO - 2018-02-16 10:19:41 --> URI Class Initialized
INFO - 2018-02-16 10:19:41 --> Router Class Initialized
INFO - 2018-02-16 10:19:41 --> Output Class Initialized
INFO - 2018-02-16 10:19:41 --> Security Class Initialized
DEBUG - 2018-02-16 10:19:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-16 10:19:41 --> Input Class Initialized
INFO - 2018-02-16 10:19:41 --> Language Class Initialized
INFO - 2018-02-16 10:19:41 --> Loader Class Initialized
INFO - 2018-02-16 10:19:41 --> Helper loaded: url_helper
INFO - 2018-02-16 10:19:41 --> Helper loaded: file_helper
INFO - 2018-02-16 10:19:41 --> Helper loaded: email_helper
INFO - 2018-02-16 10:19:41 --> Helper loaded: common_helper
INFO - 2018-02-16 10:19:41 --> Database Driver Class Initialized
DEBUG - 2018-02-16 10:19:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-16 10:19:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-16 10:19:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-16 10:19:41 --> Pagination Class Initialized
INFO - 2018-02-16 10:19:41 --> Helper loaded: form_helper
INFO - 2018-02-16 10:19:41 --> Form Validation Class Initialized
INFO - 2018-02-16 10:19:41 --> Model Class Initialized
INFO - 2018-02-16 10:19:41 --> Controller Class Initialized
INFO - 2018-02-16 10:19:41 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-16 10:19:41 --> Model Class Initialized
INFO - 2018-02-16 10:19:41 --> Model Class Initialized
INFO - 2018-02-16 10:19:41 --> Model Class Initialized
INFO - 2018-02-16 10:19:41 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-16 10:19:41 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-16 10:19:41 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-16 10:19:41 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-16 10:19:41 --> File loaded: /var/www/html/project/radio/application/views/tracks/index.php
INFO - 2018-02-16 10:19:41 --> Final output sent to browser
DEBUG - 2018-02-16 10:19:41 --> Total execution time: 0.0057
INFO - 2018-02-16 10:19:42 --> Config Class Initialized
INFO - 2018-02-16 10:19:42 --> Hooks Class Initialized
DEBUG - 2018-02-16 10:19:42 --> UTF-8 Support Enabled
INFO - 2018-02-16 10:19:42 --> Utf8 Class Initialized
INFO - 2018-02-16 10:19:42 --> URI Class Initialized
INFO - 2018-02-16 10:19:42 --> Router Class Initialized
INFO - 2018-02-16 10:19:42 --> Output Class Initialized
INFO - 2018-02-16 10:19:42 --> Security Class Initialized
DEBUG - 2018-02-16 10:19:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-16 10:19:42 --> Input Class Initialized
INFO - 2018-02-16 10:19:42 --> Language Class Initialized
INFO - 2018-02-16 10:19:42 --> Loader Class Initialized
INFO - 2018-02-16 10:19:42 --> Helper loaded: url_helper
INFO - 2018-02-16 10:19:42 --> Helper loaded: file_helper
INFO - 2018-02-16 10:19:42 --> Helper loaded: email_helper
INFO - 2018-02-16 10:19:42 --> Helper loaded: common_helper
INFO - 2018-02-16 10:19:42 --> Database Driver Class Initialized
DEBUG - 2018-02-16 10:19:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-16 10:19:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-16 10:19:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-16 10:19:42 --> Pagination Class Initialized
INFO - 2018-02-16 10:19:42 --> Helper loaded: form_helper
INFO - 2018-02-16 10:19:42 --> Form Validation Class Initialized
INFO - 2018-02-16 10:19:42 --> Model Class Initialized
INFO - 2018-02-16 10:19:42 --> Controller Class Initialized
INFO - 2018-02-16 10:19:42 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-16 10:19:42 --> Model Class Initialized
INFO - 2018-02-16 10:19:42 --> Model Class Initialized
INFO - 2018-02-16 10:19:42 --> Model Class Initialized
INFO - 2018-02-16 10:19:44 --> Config Class Initialized
INFO - 2018-02-16 10:19:44 --> Hooks Class Initialized
DEBUG - 2018-02-16 10:19:44 --> UTF-8 Support Enabled
INFO - 2018-02-16 10:19:44 --> Utf8 Class Initialized
INFO - 2018-02-16 10:19:44 --> URI Class Initialized
INFO - 2018-02-16 10:19:44 --> Router Class Initialized
INFO - 2018-02-16 10:19:44 --> Output Class Initialized
INFO - 2018-02-16 10:19:44 --> Security Class Initialized
DEBUG - 2018-02-16 10:19:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-16 10:19:44 --> Input Class Initialized
INFO - 2018-02-16 10:19:44 --> Language Class Initialized
INFO - 2018-02-16 10:19:44 --> Loader Class Initialized
INFO - 2018-02-16 10:19:44 --> Helper loaded: url_helper
INFO - 2018-02-16 10:19:44 --> Helper loaded: file_helper
INFO - 2018-02-16 10:19:44 --> Helper loaded: email_helper
INFO - 2018-02-16 10:19:44 --> Helper loaded: common_helper
INFO - 2018-02-16 10:19:44 --> Database Driver Class Initialized
DEBUG - 2018-02-16 10:19:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-16 10:19:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-16 10:19:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-16 10:19:44 --> Pagination Class Initialized
INFO - 2018-02-16 10:19:44 --> Helper loaded: form_helper
INFO - 2018-02-16 10:19:44 --> Form Validation Class Initialized
INFO - 2018-02-16 10:19:44 --> Model Class Initialized
INFO - 2018-02-16 10:19:44 --> Controller Class Initialized
INFO - 2018-02-16 10:19:44 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-16 10:19:44 --> Model Class Initialized
INFO - 2018-02-16 10:19:44 --> Model Class Initialized
INFO - 2018-02-16 10:19:44 --> Model Class Initialized
INFO - 2018-02-16 10:19:44 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-16 10:19:44 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-16 10:19:44 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-16 10:19:44 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-16 10:19:44 --> File loaded: /var/www/html/project/radio/application/views/tracks/index.php
INFO - 2018-02-16 10:19:44 --> Final output sent to browser
DEBUG - 2018-02-16 10:19:44 --> Total execution time: 0.0047
INFO - 2018-02-16 10:19:55 --> Config Class Initialized
INFO - 2018-02-16 10:19:55 --> Hooks Class Initialized
DEBUG - 2018-02-16 10:19:55 --> UTF-8 Support Enabled
INFO - 2018-02-16 10:19:55 --> Utf8 Class Initialized
INFO - 2018-02-16 10:19:55 --> URI Class Initialized
INFO - 2018-02-16 10:19:55 --> Router Class Initialized
INFO - 2018-02-16 10:19:55 --> Output Class Initialized
INFO - 2018-02-16 10:19:55 --> Security Class Initialized
DEBUG - 2018-02-16 10:19:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-16 10:19:55 --> Input Class Initialized
INFO - 2018-02-16 10:19:55 --> Language Class Initialized
INFO - 2018-02-16 10:19:55 --> Loader Class Initialized
INFO - 2018-02-16 10:19:55 --> Helper loaded: url_helper
INFO - 2018-02-16 10:19:55 --> Helper loaded: file_helper
INFO - 2018-02-16 10:19:55 --> Helper loaded: email_helper
INFO - 2018-02-16 10:19:55 --> Helper loaded: common_helper
INFO - 2018-02-16 10:19:55 --> Database Driver Class Initialized
DEBUG - 2018-02-16 10:19:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-16 10:19:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-16 10:19:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-16 10:19:55 --> Pagination Class Initialized
INFO - 2018-02-16 10:19:55 --> Helper loaded: form_helper
INFO - 2018-02-16 10:19:55 --> Form Validation Class Initialized
INFO - 2018-02-16 10:19:55 --> Model Class Initialized
INFO - 2018-02-16 10:19:55 --> Controller Class Initialized
INFO - 2018-02-16 10:19:55 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-16 10:19:55 --> Model Class Initialized
INFO - 2018-02-16 10:19:55 --> Model Class Initialized
INFO - 2018-02-16 10:19:55 --> Model Class Initialized
INFO - 2018-02-16 10:20:27 --> Config Class Initialized
INFO - 2018-02-16 10:20:27 --> Hooks Class Initialized
DEBUG - 2018-02-16 10:20:27 --> UTF-8 Support Enabled
INFO - 2018-02-16 10:20:27 --> Utf8 Class Initialized
INFO - 2018-02-16 10:20:27 --> URI Class Initialized
INFO - 2018-02-16 10:20:27 --> Router Class Initialized
INFO - 2018-02-16 10:20:27 --> Output Class Initialized
INFO - 2018-02-16 10:20:27 --> Security Class Initialized
DEBUG - 2018-02-16 10:20:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-16 10:20:27 --> Input Class Initialized
INFO - 2018-02-16 10:20:27 --> Language Class Initialized
INFO - 2018-02-16 10:20:27 --> Loader Class Initialized
INFO - 2018-02-16 10:20:27 --> Helper loaded: url_helper
INFO - 2018-02-16 10:20:27 --> Helper loaded: file_helper
INFO - 2018-02-16 10:20:27 --> Helper loaded: email_helper
INFO - 2018-02-16 10:20:27 --> Helper loaded: common_helper
INFO - 2018-02-16 10:20:27 --> Database Driver Class Initialized
DEBUG - 2018-02-16 10:20:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-16 10:20:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-16 10:20:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-16 10:20:27 --> Pagination Class Initialized
INFO - 2018-02-16 10:20:27 --> Helper loaded: form_helper
INFO - 2018-02-16 10:20:27 --> Form Validation Class Initialized
INFO - 2018-02-16 10:20:27 --> Model Class Initialized
INFO - 2018-02-16 10:20:27 --> Controller Class Initialized
INFO - 2018-02-16 10:20:27 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-16 10:20:27 --> Model Class Initialized
INFO - 2018-02-16 10:20:27 --> Model Class Initialized
INFO - 2018-02-16 10:20:27 --> Model Class Initialized
INFO - 2018-02-16 10:20:47 --> Config Class Initialized
INFO - 2018-02-16 10:20:47 --> Hooks Class Initialized
DEBUG - 2018-02-16 10:20:47 --> UTF-8 Support Enabled
INFO - 2018-02-16 10:20:47 --> Utf8 Class Initialized
INFO - 2018-02-16 10:20:47 --> URI Class Initialized
INFO - 2018-02-16 10:20:47 --> Router Class Initialized
INFO - 2018-02-16 10:20:47 --> Output Class Initialized
INFO - 2018-02-16 10:20:47 --> Security Class Initialized
DEBUG - 2018-02-16 10:20:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-16 10:20:47 --> Input Class Initialized
INFO - 2018-02-16 10:20:47 --> Language Class Initialized
INFO - 2018-02-16 10:20:47 --> Loader Class Initialized
INFO - 2018-02-16 10:20:47 --> Helper loaded: url_helper
INFO - 2018-02-16 10:20:47 --> Helper loaded: file_helper
INFO - 2018-02-16 10:20:47 --> Helper loaded: email_helper
INFO - 2018-02-16 10:20:47 --> Helper loaded: common_helper
INFO - 2018-02-16 10:20:47 --> Database Driver Class Initialized
DEBUG - 2018-02-16 10:20:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-16 10:20:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-16 10:20:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-16 10:20:47 --> Pagination Class Initialized
INFO - 2018-02-16 10:20:47 --> Helper loaded: form_helper
INFO - 2018-02-16 10:20:47 --> Form Validation Class Initialized
INFO - 2018-02-16 10:20:47 --> Model Class Initialized
INFO - 2018-02-16 10:20:47 --> Controller Class Initialized
INFO - 2018-02-16 10:20:47 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-16 10:20:47 --> Model Class Initialized
INFO - 2018-02-16 10:20:47 --> Model Class Initialized
INFO - 2018-02-16 10:20:47 --> Model Class Initialized
INFO - 2018-02-16 10:20:47 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-16 10:20:47 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-16 10:20:47 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-16 10:20:47 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-16 10:20:47 --> File loaded: /var/www/html/project/radio/application/views/tracks/index.php
INFO - 2018-02-16 10:20:47 --> Final output sent to browser
DEBUG - 2018-02-16 10:20:47 --> Total execution time: 0.0090
INFO - 2018-02-16 10:20:48 --> Config Class Initialized
INFO - 2018-02-16 10:20:48 --> Hooks Class Initialized
DEBUG - 2018-02-16 10:20:48 --> UTF-8 Support Enabled
INFO - 2018-02-16 10:20:48 --> Utf8 Class Initialized
INFO - 2018-02-16 10:20:48 --> URI Class Initialized
INFO - 2018-02-16 10:20:48 --> Router Class Initialized
INFO - 2018-02-16 10:20:48 --> Output Class Initialized
INFO - 2018-02-16 10:20:48 --> Security Class Initialized
DEBUG - 2018-02-16 10:20:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-16 10:20:48 --> Input Class Initialized
INFO - 2018-02-16 10:20:48 --> Language Class Initialized
INFO - 2018-02-16 10:20:48 --> Loader Class Initialized
INFO - 2018-02-16 10:20:48 --> Helper loaded: url_helper
INFO - 2018-02-16 10:20:48 --> Helper loaded: file_helper
INFO - 2018-02-16 10:20:48 --> Helper loaded: email_helper
INFO - 2018-02-16 10:20:48 --> Helper loaded: common_helper
INFO - 2018-02-16 10:20:48 --> Database Driver Class Initialized
DEBUG - 2018-02-16 10:20:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-16 10:20:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-16 10:20:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-16 10:20:48 --> Pagination Class Initialized
INFO - 2018-02-16 10:20:48 --> Helper loaded: form_helper
INFO - 2018-02-16 10:20:48 --> Form Validation Class Initialized
INFO - 2018-02-16 10:20:48 --> Model Class Initialized
INFO - 2018-02-16 10:20:48 --> Controller Class Initialized
INFO - 2018-02-16 10:20:48 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-16 10:20:48 --> Model Class Initialized
INFO - 2018-02-16 10:20:48 --> Model Class Initialized
INFO - 2018-02-16 10:20:48 --> Model Class Initialized
INFO - 2018-02-16 10:20:51 --> Config Class Initialized
INFO - 2018-02-16 10:20:51 --> Hooks Class Initialized
DEBUG - 2018-02-16 10:20:51 --> UTF-8 Support Enabled
INFO - 2018-02-16 10:20:51 --> Utf8 Class Initialized
INFO - 2018-02-16 10:20:51 --> URI Class Initialized
INFO - 2018-02-16 10:20:51 --> Router Class Initialized
INFO - 2018-02-16 10:20:51 --> Output Class Initialized
INFO - 2018-02-16 10:20:51 --> Security Class Initialized
DEBUG - 2018-02-16 10:20:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-16 10:20:51 --> Input Class Initialized
INFO - 2018-02-16 10:20:51 --> Language Class Initialized
INFO - 2018-02-16 10:20:51 --> Loader Class Initialized
INFO - 2018-02-16 10:20:51 --> Helper loaded: url_helper
INFO - 2018-02-16 10:20:51 --> Helper loaded: file_helper
INFO - 2018-02-16 10:20:51 --> Helper loaded: email_helper
INFO - 2018-02-16 10:20:51 --> Helper loaded: common_helper
INFO - 2018-02-16 10:20:51 --> Database Driver Class Initialized
DEBUG - 2018-02-16 10:20:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-16 10:20:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-16 10:20:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-16 10:20:51 --> Pagination Class Initialized
INFO - 2018-02-16 10:20:51 --> Helper loaded: form_helper
INFO - 2018-02-16 10:20:51 --> Form Validation Class Initialized
INFO - 2018-02-16 10:20:51 --> Model Class Initialized
INFO - 2018-02-16 10:20:51 --> Controller Class Initialized
INFO - 2018-02-16 10:20:51 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-16 10:20:51 --> Model Class Initialized
INFO - 2018-02-16 10:20:51 --> Model Class Initialized
INFO - 2018-02-16 10:20:51 --> Model Class Initialized
INFO - 2018-02-16 10:20:51 --> Config Class Initialized
INFO - 2018-02-16 10:20:51 --> Hooks Class Initialized
DEBUG - 2018-02-16 10:20:51 --> UTF-8 Support Enabled
INFO - 2018-02-16 10:20:51 --> Utf8 Class Initialized
INFO - 2018-02-16 10:20:51 --> URI Class Initialized
INFO - 2018-02-16 10:20:51 --> Router Class Initialized
INFO - 2018-02-16 10:20:51 --> Output Class Initialized
INFO - 2018-02-16 10:20:51 --> Security Class Initialized
DEBUG - 2018-02-16 10:20:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-16 10:20:51 --> Input Class Initialized
INFO - 2018-02-16 10:20:51 --> Language Class Initialized
INFO - 2018-02-16 10:20:51 --> Loader Class Initialized
INFO - 2018-02-16 10:20:51 --> Helper loaded: url_helper
INFO - 2018-02-16 10:20:51 --> Helper loaded: file_helper
INFO - 2018-02-16 10:20:51 --> Helper loaded: email_helper
INFO - 2018-02-16 10:20:51 --> Helper loaded: common_helper
INFO - 2018-02-16 10:20:51 --> Database Driver Class Initialized
DEBUG - 2018-02-16 10:20:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-16 10:20:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-16 10:20:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-16 10:20:51 --> Pagination Class Initialized
INFO - 2018-02-16 10:20:51 --> Helper loaded: form_helper
INFO - 2018-02-16 10:20:51 --> Form Validation Class Initialized
INFO - 2018-02-16 10:20:51 --> Model Class Initialized
INFO - 2018-02-16 10:20:51 --> Controller Class Initialized
INFO - 2018-02-16 10:20:51 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-16 10:20:51 --> Model Class Initialized
INFO - 2018-02-16 10:20:51 --> Model Class Initialized
INFO - 2018-02-16 10:20:51 --> Model Class Initialized
INFO - 2018-02-16 10:20:52 --> Config Class Initialized
INFO - 2018-02-16 10:20:52 --> Hooks Class Initialized
DEBUG - 2018-02-16 10:20:52 --> UTF-8 Support Enabled
INFO - 2018-02-16 10:20:52 --> Utf8 Class Initialized
INFO - 2018-02-16 10:20:52 --> URI Class Initialized
INFO - 2018-02-16 10:20:52 --> Router Class Initialized
INFO - 2018-02-16 10:20:52 --> Output Class Initialized
INFO - 2018-02-16 10:20:52 --> Security Class Initialized
DEBUG - 2018-02-16 10:20:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-16 10:20:52 --> Input Class Initialized
INFO - 2018-02-16 10:20:52 --> Language Class Initialized
INFO - 2018-02-16 10:20:52 --> Loader Class Initialized
INFO - 2018-02-16 10:20:52 --> Helper loaded: url_helper
INFO - 2018-02-16 10:20:52 --> Helper loaded: file_helper
INFO - 2018-02-16 10:20:52 --> Helper loaded: email_helper
INFO - 2018-02-16 10:20:52 --> Helper loaded: common_helper
INFO - 2018-02-16 10:20:52 --> Database Driver Class Initialized
DEBUG - 2018-02-16 10:20:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-16 10:20:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-16 10:20:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-16 10:20:52 --> Pagination Class Initialized
INFO - 2018-02-16 10:20:52 --> Helper loaded: form_helper
INFO - 2018-02-16 10:20:52 --> Form Validation Class Initialized
INFO - 2018-02-16 10:20:52 --> Model Class Initialized
INFO - 2018-02-16 10:20:52 --> Controller Class Initialized
INFO - 2018-02-16 10:20:52 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-16 10:20:52 --> Model Class Initialized
INFO - 2018-02-16 10:20:52 --> Model Class Initialized
INFO - 2018-02-16 10:20:52 --> Model Class Initialized
INFO - 2018-02-16 10:20:52 --> Config Class Initialized
INFO - 2018-02-16 10:20:52 --> Hooks Class Initialized
DEBUG - 2018-02-16 10:20:52 --> UTF-8 Support Enabled
INFO - 2018-02-16 10:20:52 --> Utf8 Class Initialized
INFO - 2018-02-16 10:20:52 --> URI Class Initialized
INFO - 2018-02-16 10:20:52 --> Router Class Initialized
INFO - 2018-02-16 10:20:52 --> Output Class Initialized
INFO - 2018-02-16 10:20:52 --> Security Class Initialized
DEBUG - 2018-02-16 10:20:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-16 10:20:52 --> Input Class Initialized
INFO - 2018-02-16 10:20:52 --> Language Class Initialized
INFO - 2018-02-16 10:20:52 --> Loader Class Initialized
INFO - 2018-02-16 10:20:52 --> Helper loaded: url_helper
INFO - 2018-02-16 10:20:52 --> Helper loaded: file_helper
INFO - 2018-02-16 10:20:52 --> Helper loaded: email_helper
INFO - 2018-02-16 10:20:52 --> Helper loaded: common_helper
INFO - 2018-02-16 10:20:52 --> Database Driver Class Initialized
DEBUG - 2018-02-16 10:20:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-16 10:20:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-16 10:20:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-16 10:20:52 --> Pagination Class Initialized
INFO - 2018-02-16 10:20:52 --> Helper loaded: form_helper
INFO - 2018-02-16 10:20:52 --> Form Validation Class Initialized
INFO - 2018-02-16 10:20:52 --> Model Class Initialized
INFO - 2018-02-16 10:20:52 --> Controller Class Initialized
INFO - 2018-02-16 10:20:52 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-16 10:20:52 --> Model Class Initialized
INFO - 2018-02-16 10:20:52 --> Model Class Initialized
INFO - 2018-02-16 10:20:52 --> Model Class Initialized
INFO - 2018-02-16 10:20:54 --> Config Class Initialized
INFO - 2018-02-16 10:20:54 --> Hooks Class Initialized
DEBUG - 2018-02-16 10:20:54 --> UTF-8 Support Enabled
INFO - 2018-02-16 10:20:54 --> Utf8 Class Initialized
INFO - 2018-02-16 10:20:54 --> URI Class Initialized
INFO - 2018-02-16 10:20:54 --> Router Class Initialized
INFO - 2018-02-16 10:20:54 --> Output Class Initialized
INFO - 2018-02-16 10:20:54 --> Security Class Initialized
DEBUG - 2018-02-16 10:20:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-16 10:20:54 --> Input Class Initialized
INFO - 2018-02-16 10:20:54 --> Language Class Initialized
INFO - 2018-02-16 10:20:54 --> Loader Class Initialized
INFO - 2018-02-16 10:20:54 --> Helper loaded: url_helper
INFO - 2018-02-16 10:20:54 --> Helper loaded: file_helper
INFO - 2018-02-16 10:20:54 --> Helper loaded: email_helper
INFO - 2018-02-16 10:20:54 --> Helper loaded: common_helper
INFO - 2018-02-16 10:20:54 --> Database Driver Class Initialized
DEBUG - 2018-02-16 10:20:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-16 10:20:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-16 10:20:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-16 10:20:54 --> Pagination Class Initialized
INFO - 2018-02-16 10:20:54 --> Helper loaded: form_helper
INFO - 2018-02-16 10:20:54 --> Form Validation Class Initialized
INFO - 2018-02-16 10:20:54 --> Model Class Initialized
INFO - 2018-02-16 10:20:54 --> Controller Class Initialized
INFO - 2018-02-16 10:20:54 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-16 10:20:54 --> Model Class Initialized
INFO - 2018-02-16 10:20:54 --> Model Class Initialized
INFO - 2018-02-16 10:20:54 --> Model Class Initialized
INFO - 2018-02-16 10:20:54 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-16 10:20:54 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-16 10:20:54 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-16 10:20:54 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-16 10:20:54 --> File loaded: /var/www/html/project/radio/application/views/tracks/index.php
INFO - 2018-02-16 10:20:54 --> Final output sent to browser
DEBUG - 2018-02-16 10:20:54 --> Total execution time: 0.0047
INFO - 2018-02-16 10:20:54 --> Config Class Initialized
INFO - 2018-02-16 10:20:54 --> Hooks Class Initialized
DEBUG - 2018-02-16 10:20:54 --> UTF-8 Support Enabled
INFO - 2018-02-16 10:20:54 --> Utf8 Class Initialized
INFO - 2018-02-16 10:20:54 --> URI Class Initialized
INFO - 2018-02-16 10:20:54 --> Router Class Initialized
INFO - 2018-02-16 10:20:54 --> Output Class Initialized
INFO - 2018-02-16 10:20:54 --> Security Class Initialized
DEBUG - 2018-02-16 10:20:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-16 10:20:54 --> Input Class Initialized
INFO - 2018-02-16 10:20:54 --> Language Class Initialized
INFO - 2018-02-16 10:20:54 --> Loader Class Initialized
INFO - 2018-02-16 10:20:54 --> Helper loaded: url_helper
INFO - 2018-02-16 10:20:54 --> Helper loaded: file_helper
INFO - 2018-02-16 10:20:54 --> Helper loaded: email_helper
INFO - 2018-02-16 10:20:54 --> Helper loaded: common_helper
INFO - 2018-02-16 10:20:54 --> Database Driver Class Initialized
DEBUG - 2018-02-16 10:20:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-16 10:20:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-16 10:20:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-16 10:20:54 --> Pagination Class Initialized
INFO - 2018-02-16 10:20:54 --> Helper loaded: form_helper
INFO - 2018-02-16 10:20:54 --> Form Validation Class Initialized
INFO - 2018-02-16 10:20:54 --> Model Class Initialized
INFO - 2018-02-16 10:20:54 --> Controller Class Initialized
INFO - 2018-02-16 10:20:54 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-16 10:20:54 --> Model Class Initialized
INFO - 2018-02-16 10:20:54 --> Model Class Initialized
INFO - 2018-02-16 10:20:54 --> Model Class Initialized
INFO - 2018-02-16 10:20:57 --> Config Class Initialized
INFO - 2018-02-16 10:20:57 --> Hooks Class Initialized
DEBUG - 2018-02-16 10:20:57 --> UTF-8 Support Enabled
INFO - 2018-02-16 10:20:57 --> Utf8 Class Initialized
INFO - 2018-02-16 10:20:57 --> URI Class Initialized
INFO - 2018-02-16 10:20:57 --> Router Class Initialized
INFO - 2018-02-16 10:20:57 --> Output Class Initialized
INFO - 2018-02-16 10:20:57 --> Security Class Initialized
DEBUG - 2018-02-16 10:20:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-16 10:20:57 --> Input Class Initialized
INFO - 2018-02-16 10:20:57 --> Language Class Initialized
INFO - 2018-02-16 10:20:57 --> Loader Class Initialized
INFO - 2018-02-16 10:20:57 --> Helper loaded: url_helper
INFO - 2018-02-16 10:20:57 --> Helper loaded: file_helper
INFO - 2018-02-16 10:20:57 --> Helper loaded: email_helper
INFO - 2018-02-16 10:20:57 --> Helper loaded: common_helper
INFO - 2018-02-16 10:20:57 --> Database Driver Class Initialized
DEBUG - 2018-02-16 10:20:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-16 10:20:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-16 10:20:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-16 10:20:57 --> Pagination Class Initialized
INFO - 2018-02-16 10:20:57 --> Helper loaded: form_helper
INFO - 2018-02-16 10:20:57 --> Form Validation Class Initialized
INFO - 2018-02-16 10:20:57 --> Model Class Initialized
INFO - 2018-02-16 10:20:57 --> Controller Class Initialized
INFO - 2018-02-16 10:20:57 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-16 10:20:57 --> Model Class Initialized
INFO - 2018-02-16 10:20:57 --> Model Class Initialized
INFO - 2018-02-16 10:20:57 --> Model Class Initialized
INFO - 2018-02-16 10:20:57 --> Config Class Initialized
INFO - 2018-02-16 10:20:57 --> Hooks Class Initialized
DEBUG - 2018-02-16 10:20:57 --> UTF-8 Support Enabled
INFO - 2018-02-16 10:20:57 --> Utf8 Class Initialized
INFO - 2018-02-16 10:20:57 --> URI Class Initialized
INFO - 2018-02-16 10:20:57 --> Router Class Initialized
INFO - 2018-02-16 10:20:57 --> Output Class Initialized
INFO - 2018-02-16 10:20:57 --> Security Class Initialized
DEBUG - 2018-02-16 10:20:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-16 10:20:57 --> Input Class Initialized
INFO - 2018-02-16 10:20:57 --> Language Class Initialized
INFO - 2018-02-16 10:20:57 --> Loader Class Initialized
INFO - 2018-02-16 10:20:57 --> Helper loaded: url_helper
INFO - 2018-02-16 10:20:57 --> Helper loaded: file_helper
INFO - 2018-02-16 10:20:57 --> Helper loaded: email_helper
INFO - 2018-02-16 10:20:57 --> Helper loaded: common_helper
INFO - 2018-02-16 10:20:57 --> Database Driver Class Initialized
DEBUG - 2018-02-16 10:20:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-16 10:20:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-16 10:20:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-16 10:20:57 --> Pagination Class Initialized
INFO - 2018-02-16 10:20:57 --> Helper loaded: form_helper
INFO - 2018-02-16 10:20:57 --> Form Validation Class Initialized
INFO - 2018-02-16 10:20:57 --> Model Class Initialized
INFO - 2018-02-16 10:20:57 --> Controller Class Initialized
INFO - 2018-02-16 10:20:57 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-16 10:20:57 --> Model Class Initialized
INFO - 2018-02-16 10:20:57 --> Model Class Initialized
INFO - 2018-02-16 10:20:57 --> Model Class Initialized
INFO - 2018-02-16 10:20:59 --> Config Class Initialized
INFO - 2018-02-16 10:20:59 --> Hooks Class Initialized
DEBUG - 2018-02-16 10:20:59 --> UTF-8 Support Enabled
INFO - 2018-02-16 10:20:59 --> Utf8 Class Initialized
INFO - 2018-02-16 10:20:59 --> URI Class Initialized
INFO - 2018-02-16 10:20:59 --> Router Class Initialized
INFO - 2018-02-16 10:20:59 --> Output Class Initialized
INFO - 2018-02-16 10:20:59 --> Security Class Initialized
DEBUG - 2018-02-16 10:20:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-16 10:20:59 --> Input Class Initialized
INFO - 2018-02-16 10:20:59 --> Language Class Initialized
INFO - 2018-02-16 10:20:59 --> Loader Class Initialized
INFO - 2018-02-16 10:20:59 --> Helper loaded: url_helper
INFO - 2018-02-16 10:20:59 --> Helper loaded: file_helper
INFO - 2018-02-16 10:20:59 --> Helper loaded: email_helper
INFO - 2018-02-16 10:20:59 --> Helper loaded: common_helper
INFO - 2018-02-16 10:20:59 --> Database Driver Class Initialized
DEBUG - 2018-02-16 10:20:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-16 10:20:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-16 10:20:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-16 10:20:59 --> Pagination Class Initialized
INFO - 2018-02-16 10:20:59 --> Helper loaded: form_helper
INFO - 2018-02-16 10:20:59 --> Form Validation Class Initialized
INFO - 2018-02-16 10:20:59 --> Model Class Initialized
INFO - 2018-02-16 10:20:59 --> Controller Class Initialized
INFO - 2018-02-16 10:20:59 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-16 10:20:59 --> Model Class Initialized
INFO - 2018-02-16 10:20:59 --> Model Class Initialized
INFO - 2018-02-16 10:20:59 --> Model Class Initialized
INFO - 2018-02-16 10:20:59 --> Config Class Initialized
INFO - 2018-02-16 10:20:59 --> Hooks Class Initialized
DEBUG - 2018-02-16 10:20:59 --> UTF-8 Support Enabled
INFO - 2018-02-16 10:20:59 --> Utf8 Class Initialized
INFO - 2018-02-16 10:20:59 --> URI Class Initialized
INFO - 2018-02-16 10:20:59 --> Router Class Initialized
INFO - 2018-02-16 10:20:59 --> Output Class Initialized
INFO - 2018-02-16 10:20:59 --> Security Class Initialized
DEBUG - 2018-02-16 10:20:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-16 10:20:59 --> Input Class Initialized
INFO - 2018-02-16 10:20:59 --> Language Class Initialized
INFO - 2018-02-16 10:20:59 --> Loader Class Initialized
INFO - 2018-02-16 10:20:59 --> Helper loaded: url_helper
INFO - 2018-02-16 10:20:59 --> Helper loaded: file_helper
INFO - 2018-02-16 10:20:59 --> Helper loaded: email_helper
INFO - 2018-02-16 10:20:59 --> Helper loaded: common_helper
INFO - 2018-02-16 10:20:59 --> Database Driver Class Initialized
DEBUG - 2018-02-16 10:20:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-16 10:20:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-16 10:20:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-16 10:20:59 --> Pagination Class Initialized
INFO - 2018-02-16 10:20:59 --> Helper loaded: form_helper
INFO - 2018-02-16 10:20:59 --> Form Validation Class Initialized
INFO - 2018-02-16 10:20:59 --> Model Class Initialized
INFO - 2018-02-16 10:20:59 --> Controller Class Initialized
INFO - 2018-02-16 10:20:59 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-16 10:20:59 --> Model Class Initialized
INFO - 2018-02-16 10:20:59 --> Model Class Initialized
INFO - 2018-02-16 10:20:59 --> Model Class Initialized
INFO - 2018-02-16 10:31:11 --> Config Class Initialized
INFO - 2018-02-16 10:31:11 --> Hooks Class Initialized
DEBUG - 2018-02-16 10:31:11 --> UTF-8 Support Enabled
INFO - 2018-02-16 10:31:11 --> Utf8 Class Initialized
INFO - 2018-02-16 10:31:11 --> URI Class Initialized
INFO - 2018-02-16 10:31:11 --> Router Class Initialized
INFO - 2018-02-16 10:31:11 --> Output Class Initialized
INFO - 2018-02-16 10:31:11 --> Security Class Initialized
DEBUG - 2018-02-16 10:31:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-16 10:31:11 --> Input Class Initialized
INFO - 2018-02-16 10:31:11 --> Language Class Initialized
INFO - 2018-02-16 10:31:11 --> Loader Class Initialized
INFO - 2018-02-16 10:31:11 --> Helper loaded: url_helper
INFO - 2018-02-16 10:31:11 --> Helper loaded: file_helper
INFO - 2018-02-16 10:31:11 --> Helper loaded: email_helper
INFO - 2018-02-16 10:31:11 --> Helper loaded: common_helper
INFO - 2018-02-16 10:31:11 --> Database Driver Class Initialized
DEBUG - 2018-02-16 10:31:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-16 10:31:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-16 10:31:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-16 10:31:11 --> Pagination Class Initialized
INFO - 2018-02-16 10:31:11 --> Helper loaded: form_helper
INFO - 2018-02-16 10:31:11 --> Form Validation Class Initialized
INFO - 2018-02-16 10:31:11 --> Model Class Initialized
INFO - 2018-02-16 10:31:11 --> Controller Class Initialized
INFO - 2018-02-16 10:31:11 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-16 10:31:11 --> Model Class Initialized
INFO - 2018-02-16 10:31:11 --> Model Class Initialized
INFO - 2018-02-16 10:31:11 --> Model Class Initialized
INFO - 2018-02-16 10:31:11 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-16 10:31:11 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-16 10:31:11 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-16 10:31:11 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-16 10:31:11 --> File loaded: /var/www/html/project/radio/application/views/tracks/index.php
INFO - 2018-02-16 10:31:11 --> Final output sent to browser
DEBUG - 2018-02-16 10:31:11 --> Total execution time: 0.0115
INFO - 2018-02-16 10:31:11 --> Config Class Initialized
INFO - 2018-02-16 10:31:11 --> Hooks Class Initialized
DEBUG - 2018-02-16 10:31:11 --> UTF-8 Support Enabled
INFO - 2018-02-16 10:31:11 --> Utf8 Class Initialized
INFO - 2018-02-16 10:31:11 --> URI Class Initialized
INFO - 2018-02-16 10:31:11 --> Router Class Initialized
INFO - 2018-02-16 10:31:11 --> Output Class Initialized
INFO - 2018-02-16 10:31:11 --> Security Class Initialized
DEBUG - 2018-02-16 10:31:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-16 10:31:11 --> Input Class Initialized
INFO - 2018-02-16 10:31:11 --> Language Class Initialized
INFO - 2018-02-16 10:31:11 --> Loader Class Initialized
INFO - 2018-02-16 10:31:11 --> Helper loaded: url_helper
INFO - 2018-02-16 10:31:11 --> Helper loaded: file_helper
INFO - 2018-02-16 10:31:11 --> Helper loaded: email_helper
INFO - 2018-02-16 10:31:11 --> Helper loaded: common_helper
INFO - 2018-02-16 10:31:11 --> Database Driver Class Initialized
DEBUG - 2018-02-16 10:31:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-16 10:31:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-16 10:31:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-16 10:31:11 --> Pagination Class Initialized
INFO - 2018-02-16 10:31:11 --> Helper loaded: form_helper
INFO - 2018-02-16 10:31:11 --> Form Validation Class Initialized
INFO - 2018-02-16 10:31:11 --> Model Class Initialized
INFO - 2018-02-16 10:31:11 --> Controller Class Initialized
INFO - 2018-02-16 10:31:11 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-16 10:31:11 --> Model Class Initialized
INFO - 2018-02-16 10:31:11 --> Model Class Initialized
INFO - 2018-02-16 10:31:11 --> Model Class Initialized
ERROR - 2018-02-16 10:31:11 --> Query error: In aggregated query without GROUP BY, expression #1 of SELECT list contains nonaggregated column 'radio.t.iTracksId'; this is incompatible with sql_mode=only_full_group_by - Invalid query: SELECT `t`.*, `c`.`vTitle` as `category`, `sc`.`vTitle` as `subcategory`, COUNT(uf.iUserFavoritesId) as totalFavorites
FROM `Tracks` as `t`
JOIN `SubCategory` as `sc` ON `sc`.`iSubCategoryId` = `t`.`iSubCategoryId`
JOIN `Category` as `c` ON `c`.`iCategoryId` = `t`.`iCategoryId`
LEFT JOIN `UserFavorites` as `uf` ON `t`.`iTracksId` = `uf`.`iTracksId`
WHERE `t`.`is_deleted` =0
AND `c`.`is_deleted` =0
AND `sc`.`is_deleted` =0
ORDER BY `vTrackImage` ASC
INFO - 2018-02-16 10:31:11 --> Language file loaded: language/english/db_lang.php
INFO - 2018-02-16 10:31:16 --> Config Class Initialized
INFO - 2018-02-16 10:31:16 --> Hooks Class Initialized
DEBUG - 2018-02-16 10:31:16 --> UTF-8 Support Enabled
INFO - 2018-02-16 10:31:16 --> Utf8 Class Initialized
INFO - 2018-02-16 10:31:16 --> URI Class Initialized
INFO - 2018-02-16 10:31:16 --> Router Class Initialized
INFO - 2018-02-16 10:31:16 --> Output Class Initialized
INFO - 2018-02-16 10:31:16 --> Security Class Initialized
DEBUG - 2018-02-16 10:31:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-16 10:31:16 --> Input Class Initialized
INFO - 2018-02-16 10:31:16 --> Language Class Initialized
INFO - 2018-02-16 10:31:16 --> Loader Class Initialized
INFO - 2018-02-16 10:31:16 --> Helper loaded: url_helper
INFO - 2018-02-16 10:31:16 --> Helper loaded: file_helper
INFO - 2018-02-16 10:31:16 --> Helper loaded: email_helper
INFO - 2018-02-16 10:31:16 --> Helper loaded: common_helper
INFO - 2018-02-16 10:31:16 --> Database Driver Class Initialized
DEBUG - 2018-02-16 10:31:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-16 10:31:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-16 10:31:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-16 10:31:16 --> Pagination Class Initialized
INFO - 2018-02-16 10:31:16 --> Helper loaded: form_helper
INFO - 2018-02-16 10:31:16 --> Form Validation Class Initialized
INFO - 2018-02-16 10:31:16 --> Model Class Initialized
INFO - 2018-02-16 10:31:16 --> Controller Class Initialized
INFO - 2018-02-16 10:31:16 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-16 10:31:16 --> Model Class Initialized
INFO - 2018-02-16 10:31:16 --> Model Class Initialized
INFO - 2018-02-16 10:31:16 --> Model Class Initialized
INFO - 2018-02-16 10:31:16 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-16 10:31:16 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-16 10:31:16 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-16 10:31:16 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-16 10:31:16 --> File loaded: /var/www/html/project/radio/application/views/tracks/index.php
INFO - 2018-02-16 10:31:16 --> Final output sent to browser
DEBUG - 2018-02-16 10:31:16 --> Total execution time: 0.0048
INFO - 2018-02-16 10:31:17 --> Config Class Initialized
INFO - 2018-02-16 10:31:17 --> Hooks Class Initialized
DEBUG - 2018-02-16 10:31:17 --> UTF-8 Support Enabled
INFO - 2018-02-16 10:31:17 --> Utf8 Class Initialized
INFO - 2018-02-16 10:31:17 --> URI Class Initialized
INFO - 2018-02-16 10:31:17 --> Router Class Initialized
INFO - 2018-02-16 10:31:17 --> Output Class Initialized
INFO - 2018-02-16 10:31:17 --> Security Class Initialized
DEBUG - 2018-02-16 10:31:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-16 10:31:17 --> Input Class Initialized
INFO - 2018-02-16 10:31:17 --> Language Class Initialized
INFO - 2018-02-16 10:31:17 --> Loader Class Initialized
INFO - 2018-02-16 10:31:17 --> Helper loaded: url_helper
INFO - 2018-02-16 10:31:17 --> Helper loaded: file_helper
INFO - 2018-02-16 10:31:17 --> Helper loaded: email_helper
INFO - 2018-02-16 10:31:17 --> Helper loaded: common_helper
INFO - 2018-02-16 10:31:17 --> Database Driver Class Initialized
DEBUG - 2018-02-16 10:31:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-16 10:31:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-16 10:31:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-16 10:31:17 --> Pagination Class Initialized
INFO - 2018-02-16 10:31:17 --> Helper loaded: form_helper
INFO - 2018-02-16 10:31:17 --> Form Validation Class Initialized
INFO - 2018-02-16 10:31:17 --> Model Class Initialized
INFO - 2018-02-16 10:31:17 --> Controller Class Initialized
INFO - 2018-02-16 10:31:17 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-16 10:31:17 --> Model Class Initialized
INFO - 2018-02-16 10:31:17 --> Model Class Initialized
INFO - 2018-02-16 10:31:17 --> Model Class Initialized
ERROR - 2018-02-16 10:31:17 --> Query error: In aggregated query without GROUP BY, expression #1 of SELECT list contains nonaggregated column 'radio.t.iTracksId'; this is incompatible with sql_mode=only_full_group_by - Invalid query: SELECT `t`.*, `c`.`vTitle` as `category`, `sc`.`vTitle` as `subcategory`, COUNT(uf.iUserFavoritesId) as totalFavorites
FROM `Tracks` as `t`
JOIN `SubCategory` as `sc` ON `sc`.`iSubCategoryId` = `t`.`iSubCategoryId`
JOIN `Category` as `c` ON `c`.`iCategoryId` = `t`.`iCategoryId`
LEFT JOIN `UserFavorites` as `uf` ON `t`.`iTracksId` = `uf`.`iTracksId`
WHERE `t`.`is_deleted` =0
AND `c`.`is_deleted` =0
AND `sc`.`is_deleted` =0
ORDER BY `vTrackImage` ASC
INFO - 2018-02-16 10:31:17 --> Language file loaded: language/english/db_lang.php
INFO - 2018-02-16 10:32:48 --> Config Class Initialized
INFO - 2018-02-16 10:32:48 --> Hooks Class Initialized
DEBUG - 2018-02-16 10:32:48 --> UTF-8 Support Enabled
INFO - 2018-02-16 10:32:48 --> Utf8 Class Initialized
INFO - 2018-02-16 10:32:48 --> URI Class Initialized
INFO - 2018-02-16 10:32:48 --> Router Class Initialized
INFO - 2018-02-16 10:32:48 --> Output Class Initialized
INFO - 2018-02-16 10:32:48 --> Security Class Initialized
DEBUG - 2018-02-16 10:32:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-16 10:32:48 --> Input Class Initialized
INFO - 2018-02-16 10:32:48 --> Language Class Initialized
INFO - 2018-02-16 10:32:48 --> Loader Class Initialized
INFO - 2018-02-16 10:32:48 --> Helper loaded: url_helper
INFO - 2018-02-16 10:32:48 --> Helper loaded: file_helper
INFO - 2018-02-16 10:32:48 --> Helper loaded: email_helper
INFO - 2018-02-16 10:32:48 --> Helper loaded: common_helper
INFO - 2018-02-16 10:32:48 --> Database Driver Class Initialized
DEBUG - 2018-02-16 10:32:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-16 10:32:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-16 10:32:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-16 10:32:48 --> Pagination Class Initialized
INFO - 2018-02-16 10:32:48 --> Helper loaded: form_helper
INFO - 2018-02-16 10:32:48 --> Form Validation Class Initialized
INFO - 2018-02-16 10:32:48 --> Model Class Initialized
INFO - 2018-02-16 10:32:48 --> Controller Class Initialized
INFO - 2018-02-16 10:32:48 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-16 10:32:48 --> Model Class Initialized
INFO - 2018-02-16 10:32:48 --> Model Class Initialized
INFO - 2018-02-16 10:32:48 --> Model Class Initialized
INFO - 2018-02-16 10:32:48 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-16 10:32:48 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-16 10:32:48 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-16 10:32:48 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-16 10:32:48 --> File loaded: /var/www/html/project/radio/application/views/tracks/index.php
INFO - 2018-02-16 10:32:48 --> Final output sent to browser
DEBUG - 2018-02-16 10:32:48 --> Total execution time: 0.0138
INFO - 2018-02-16 10:32:49 --> Config Class Initialized
INFO - 2018-02-16 10:32:49 --> Hooks Class Initialized
DEBUG - 2018-02-16 10:32:49 --> UTF-8 Support Enabled
INFO - 2018-02-16 10:32:49 --> Utf8 Class Initialized
INFO - 2018-02-16 10:32:49 --> URI Class Initialized
INFO - 2018-02-16 10:32:49 --> Router Class Initialized
INFO - 2018-02-16 10:32:49 --> Output Class Initialized
INFO - 2018-02-16 10:32:49 --> Security Class Initialized
DEBUG - 2018-02-16 10:32:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-16 10:32:49 --> Input Class Initialized
INFO - 2018-02-16 10:32:49 --> Language Class Initialized
INFO - 2018-02-16 10:32:49 --> Loader Class Initialized
INFO - 2018-02-16 10:32:49 --> Helper loaded: url_helper
INFO - 2018-02-16 10:32:49 --> Helper loaded: file_helper
INFO - 2018-02-16 10:32:49 --> Helper loaded: email_helper
INFO - 2018-02-16 10:32:49 --> Helper loaded: common_helper
INFO - 2018-02-16 10:32:49 --> Database Driver Class Initialized
DEBUG - 2018-02-16 10:32:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-16 10:32:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-16 10:32:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-16 10:32:49 --> Pagination Class Initialized
INFO - 2018-02-16 10:32:49 --> Helper loaded: form_helper
INFO - 2018-02-16 10:32:49 --> Form Validation Class Initialized
INFO - 2018-02-16 10:32:49 --> Model Class Initialized
INFO - 2018-02-16 10:32:49 --> Controller Class Initialized
INFO - 2018-02-16 10:32:49 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-16 10:32:49 --> Model Class Initialized
INFO - 2018-02-16 10:32:49 --> Model Class Initialized
INFO - 2018-02-16 10:32:49 --> Model Class Initialized
INFO - 2018-02-16 10:33:41 --> Config Class Initialized
INFO - 2018-02-16 10:33:41 --> Hooks Class Initialized
DEBUG - 2018-02-16 10:33:41 --> UTF-8 Support Enabled
INFO - 2018-02-16 10:33:41 --> Utf8 Class Initialized
INFO - 2018-02-16 10:33:41 --> URI Class Initialized
INFO - 2018-02-16 10:33:41 --> Router Class Initialized
INFO - 2018-02-16 10:33:41 --> Output Class Initialized
INFO - 2018-02-16 10:33:41 --> Security Class Initialized
DEBUG - 2018-02-16 10:33:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-16 10:33:41 --> Input Class Initialized
INFO - 2018-02-16 10:33:41 --> Language Class Initialized
INFO - 2018-02-16 10:33:41 --> Loader Class Initialized
INFO - 2018-02-16 10:33:41 --> Helper loaded: url_helper
INFO - 2018-02-16 10:33:41 --> Helper loaded: file_helper
INFO - 2018-02-16 10:33:41 --> Helper loaded: email_helper
INFO - 2018-02-16 10:33:41 --> Helper loaded: common_helper
INFO - 2018-02-16 10:33:41 --> Database Driver Class Initialized
DEBUG - 2018-02-16 10:33:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-16 10:33:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-16 10:33:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-16 10:33:41 --> Pagination Class Initialized
INFO - 2018-02-16 10:33:41 --> Helper loaded: form_helper
INFO - 2018-02-16 10:33:41 --> Form Validation Class Initialized
INFO - 2018-02-16 10:33:41 --> Model Class Initialized
INFO - 2018-02-16 10:33:41 --> Controller Class Initialized
INFO - 2018-02-16 10:33:41 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-16 10:33:41 --> Model Class Initialized
INFO - 2018-02-16 10:33:41 --> Model Class Initialized
INFO - 2018-02-16 10:33:41 --> Model Class Initialized
INFO - 2018-02-16 10:33:41 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-16 10:33:41 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-16 10:33:41 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-16 10:33:41 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-16 10:33:41 --> File loaded: /var/www/html/project/radio/application/views/tracks/index.php
INFO - 2018-02-16 10:33:41 --> Final output sent to browser
DEBUG - 2018-02-16 10:33:41 --> Total execution time: 0.0052
INFO - 2018-02-16 10:33:41 --> Config Class Initialized
INFO - 2018-02-16 10:33:41 --> Hooks Class Initialized
DEBUG - 2018-02-16 10:33:41 --> UTF-8 Support Enabled
INFO - 2018-02-16 10:33:41 --> Utf8 Class Initialized
INFO - 2018-02-16 10:33:41 --> URI Class Initialized
INFO - 2018-02-16 10:33:41 --> Router Class Initialized
INFO - 2018-02-16 10:33:41 --> Output Class Initialized
INFO - 2018-02-16 10:33:41 --> Security Class Initialized
DEBUG - 2018-02-16 10:33:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-16 10:33:41 --> Input Class Initialized
INFO - 2018-02-16 10:33:41 --> Language Class Initialized
INFO - 2018-02-16 10:33:41 --> Loader Class Initialized
INFO - 2018-02-16 10:33:41 --> Helper loaded: url_helper
INFO - 2018-02-16 10:33:41 --> Helper loaded: file_helper
INFO - 2018-02-16 10:33:41 --> Helper loaded: email_helper
INFO - 2018-02-16 10:33:41 --> Helper loaded: common_helper
INFO - 2018-02-16 10:33:41 --> Database Driver Class Initialized
DEBUG - 2018-02-16 10:33:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-16 10:33:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-16 10:33:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-16 10:33:41 --> Pagination Class Initialized
INFO - 2018-02-16 10:33:41 --> Helper loaded: form_helper
INFO - 2018-02-16 10:33:41 --> Form Validation Class Initialized
INFO - 2018-02-16 10:33:41 --> Model Class Initialized
INFO - 2018-02-16 10:33:41 --> Controller Class Initialized
INFO - 2018-02-16 10:33:41 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-16 10:33:41 --> Model Class Initialized
INFO - 2018-02-16 10:33:41 --> Model Class Initialized
INFO - 2018-02-16 10:33:41 --> Model Class Initialized
INFO - 2018-02-16 10:34:04 --> Config Class Initialized
INFO - 2018-02-16 10:34:04 --> Hooks Class Initialized
DEBUG - 2018-02-16 10:34:04 --> UTF-8 Support Enabled
INFO - 2018-02-16 10:34:04 --> Utf8 Class Initialized
INFO - 2018-02-16 10:34:04 --> URI Class Initialized
INFO - 2018-02-16 10:34:04 --> Router Class Initialized
INFO - 2018-02-16 10:34:04 --> Output Class Initialized
INFO - 2018-02-16 10:34:04 --> Security Class Initialized
DEBUG - 2018-02-16 10:34:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-16 10:34:04 --> Input Class Initialized
INFO - 2018-02-16 10:34:04 --> Language Class Initialized
INFO - 2018-02-16 10:34:04 --> Loader Class Initialized
INFO - 2018-02-16 10:34:04 --> Helper loaded: url_helper
INFO - 2018-02-16 10:34:04 --> Helper loaded: file_helper
INFO - 2018-02-16 10:34:04 --> Helper loaded: email_helper
INFO - 2018-02-16 10:34:04 --> Helper loaded: common_helper
INFO - 2018-02-16 10:34:04 --> Database Driver Class Initialized
DEBUG - 2018-02-16 10:34:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-16 10:34:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-16 10:34:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-16 10:34:04 --> Pagination Class Initialized
INFO - 2018-02-16 10:34:04 --> Helper loaded: form_helper
INFO - 2018-02-16 10:34:04 --> Form Validation Class Initialized
INFO - 2018-02-16 10:34:04 --> Model Class Initialized
INFO - 2018-02-16 10:34:04 --> Controller Class Initialized
INFO - 2018-02-16 10:34:04 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-16 10:34:04 --> Model Class Initialized
INFO - 2018-02-16 10:34:04 --> Model Class Initialized
INFO - 2018-02-16 10:34:04 --> Model Class Initialized
INFO - 2018-02-16 10:34:05 --> Config Class Initialized
INFO - 2018-02-16 10:34:05 --> Hooks Class Initialized
DEBUG - 2018-02-16 10:34:05 --> UTF-8 Support Enabled
INFO - 2018-02-16 10:34:05 --> Utf8 Class Initialized
INFO - 2018-02-16 10:34:05 --> URI Class Initialized
INFO - 2018-02-16 10:34:05 --> Router Class Initialized
INFO - 2018-02-16 10:34:05 --> Output Class Initialized
INFO - 2018-02-16 10:34:05 --> Security Class Initialized
DEBUG - 2018-02-16 10:34:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-16 10:34:05 --> Input Class Initialized
INFO - 2018-02-16 10:34:05 --> Language Class Initialized
INFO - 2018-02-16 10:34:05 --> Loader Class Initialized
INFO - 2018-02-16 10:34:05 --> Helper loaded: url_helper
INFO - 2018-02-16 10:34:05 --> Helper loaded: file_helper
INFO - 2018-02-16 10:34:05 --> Helper loaded: email_helper
INFO - 2018-02-16 10:34:05 --> Helper loaded: common_helper
INFO - 2018-02-16 10:34:05 --> Database Driver Class Initialized
DEBUG - 2018-02-16 10:34:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-16 10:34:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-16 10:34:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-16 10:34:05 --> Pagination Class Initialized
INFO - 2018-02-16 10:34:05 --> Helper loaded: form_helper
INFO - 2018-02-16 10:34:05 --> Form Validation Class Initialized
INFO - 2018-02-16 10:34:05 --> Model Class Initialized
INFO - 2018-02-16 10:34:05 --> Controller Class Initialized
INFO - 2018-02-16 10:34:05 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-16 10:34:05 --> Model Class Initialized
INFO - 2018-02-16 10:34:05 --> Model Class Initialized
INFO - 2018-02-16 10:34:05 --> Model Class Initialized
INFO - 2018-02-16 10:34:07 --> Config Class Initialized
INFO - 2018-02-16 10:34:07 --> Hooks Class Initialized
DEBUG - 2018-02-16 10:34:07 --> UTF-8 Support Enabled
INFO - 2018-02-16 10:34:07 --> Utf8 Class Initialized
INFO - 2018-02-16 10:34:07 --> URI Class Initialized
INFO - 2018-02-16 10:34:07 --> Router Class Initialized
INFO - 2018-02-16 10:34:07 --> Output Class Initialized
INFO - 2018-02-16 10:34:07 --> Security Class Initialized
DEBUG - 2018-02-16 10:34:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-16 10:34:07 --> Input Class Initialized
INFO - 2018-02-16 10:34:07 --> Language Class Initialized
INFO - 2018-02-16 10:34:07 --> Loader Class Initialized
INFO - 2018-02-16 10:34:07 --> Helper loaded: url_helper
INFO - 2018-02-16 10:34:07 --> Helper loaded: file_helper
INFO - 2018-02-16 10:34:07 --> Helper loaded: email_helper
INFO - 2018-02-16 10:34:07 --> Helper loaded: common_helper
INFO - 2018-02-16 10:34:07 --> Database Driver Class Initialized
DEBUG - 2018-02-16 10:34:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-16 10:34:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-16 10:34:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-16 10:34:07 --> Pagination Class Initialized
INFO - 2018-02-16 10:34:07 --> Helper loaded: form_helper
INFO - 2018-02-16 10:34:07 --> Form Validation Class Initialized
INFO - 2018-02-16 10:34:07 --> Model Class Initialized
INFO - 2018-02-16 10:34:07 --> Controller Class Initialized
INFO - 2018-02-16 10:34:07 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-16 10:34:07 --> Model Class Initialized
INFO - 2018-02-16 10:34:07 --> Model Class Initialized
INFO - 2018-02-16 10:34:07 --> Model Class Initialized
INFO - 2018-02-16 10:34:08 --> Config Class Initialized
INFO - 2018-02-16 10:34:08 --> Hooks Class Initialized
DEBUG - 2018-02-16 10:34:08 --> UTF-8 Support Enabled
INFO - 2018-02-16 10:34:08 --> Utf8 Class Initialized
INFO - 2018-02-16 10:34:08 --> URI Class Initialized
INFO - 2018-02-16 10:34:08 --> Router Class Initialized
INFO - 2018-02-16 10:34:08 --> Output Class Initialized
INFO - 2018-02-16 10:34:08 --> Security Class Initialized
DEBUG - 2018-02-16 10:34:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-16 10:34:08 --> Input Class Initialized
INFO - 2018-02-16 10:34:08 --> Language Class Initialized
INFO - 2018-02-16 10:34:08 --> Loader Class Initialized
INFO - 2018-02-16 10:34:08 --> Helper loaded: url_helper
INFO - 2018-02-16 10:34:08 --> Helper loaded: file_helper
INFO - 2018-02-16 10:34:08 --> Helper loaded: email_helper
INFO - 2018-02-16 10:34:08 --> Helper loaded: common_helper
INFO - 2018-02-16 10:34:08 --> Database Driver Class Initialized
DEBUG - 2018-02-16 10:34:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-16 10:34:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-16 10:34:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-16 10:34:08 --> Pagination Class Initialized
INFO - 2018-02-16 10:34:08 --> Helper loaded: form_helper
INFO - 2018-02-16 10:34:08 --> Form Validation Class Initialized
INFO - 2018-02-16 10:34:08 --> Model Class Initialized
INFO - 2018-02-16 10:34:08 --> Controller Class Initialized
INFO - 2018-02-16 10:34:08 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-16 10:34:08 --> Model Class Initialized
INFO - 2018-02-16 10:34:08 --> Model Class Initialized
INFO - 2018-02-16 10:34:08 --> Model Class Initialized
INFO - 2018-02-16 10:34:10 --> Config Class Initialized
INFO - 2018-02-16 10:34:10 --> Hooks Class Initialized
DEBUG - 2018-02-16 10:34:10 --> UTF-8 Support Enabled
INFO - 2018-02-16 10:34:10 --> Utf8 Class Initialized
INFO - 2018-02-16 10:34:10 --> URI Class Initialized
INFO - 2018-02-16 10:34:10 --> Router Class Initialized
INFO - 2018-02-16 10:34:10 --> Output Class Initialized
INFO - 2018-02-16 10:34:10 --> Security Class Initialized
DEBUG - 2018-02-16 10:34:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-16 10:34:10 --> Input Class Initialized
INFO - 2018-02-16 10:34:10 --> Language Class Initialized
INFO - 2018-02-16 10:34:10 --> Loader Class Initialized
INFO - 2018-02-16 10:34:10 --> Helper loaded: url_helper
INFO - 2018-02-16 10:34:10 --> Helper loaded: file_helper
INFO - 2018-02-16 10:34:10 --> Helper loaded: email_helper
INFO - 2018-02-16 10:34:10 --> Helper loaded: common_helper
INFO - 2018-02-16 10:34:10 --> Database Driver Class Initialized
DEBUG - 2018-02-16 10:34:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-16 10:34:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-16 10:34:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-16 10:34:10 --> Pagination Class Initialized
INFO - 2018-02-16 10:34:10 --> Helper loaded: form_helper
INFO - 2018-02-16 10:34:10 --> Form Validation Class Initialized
INFO - 2018-02-16 10:34:10 --> Model Class Initialized
INFO - 2018-02-16 10:34:10 --> Controller Class Initialized
INFO - 2018-02-16 10:34:10 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-16 10:34:10 --> Model Class Initialized
INFO - 2018-02-16 10:34:10 --> Model Class Initialized
INFO - 2018-02-16 10:34:10 --> Model Class Initialized
INFO - 2018-02-16 10:34:12 --> Config Class Initialized
INFO - 2018-02-16 10:34:12 --> Hooks Class Initialized
DEBUG - 2018-02-16 10:34:12 --> UTF-8 Support Enabled
INFO - 2018-02-16 10:34:12 --> Utf8 Class Initialized
INFO - 2018-02-16 10:34:12 --> URI Class Initialized
INFO - 2018-02-16 10:34:12 --> Router Class Initialized
INFO - 2018-02-16 10:34:12 --> Output Class Initialized
INFO - 2018-02-16 10:34:12 --> Security Class Initialized
DEBUG - 2018-02-16 10:34:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-16 10:34:12 --> Input Class Initialized
INFO - 2018-02-16 10:34:12 --> Language Class Initialized
INFO - 2018-02-16 10:34:12 --> Loader Class Initialized
INFO - 2018-02-16 10:34:12 --> Helper loaded: url_helper
INFO - 2018-02-16 10:34:12 --> Helper loaded: file_helper
INFO - 2018-02-16 10:34:12 --> Helper loaded: email_helper
INFO - 2018-02-16 10:34:12 --> Helper loaded: common_helper
INFO - 2018-02-16 10:34:12 --> Database Driver Class Initialized
DEBUG - 2018-02-16 10:34:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-16 10:34:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-16 10:34:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-16 10:34:12 --> Pagination Class Initialized
INFO - 2018-02-16 10:34:12 --> Helper loaded: form_helper
INFO - 2018-02-16 10:34:12 --> Form Validation Class Initialized
INFO - 2018-02-16 10:34:12 --> Model Class Initialized
INFO - 2018-02-16 10:34:12 --> Controller Class Initialized
INFO - 2018-02-16 10:34:12 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-16 10:34:12 --> Model Class Initialized
INFO - 2018-02-16 10:34:12 --> Model Class Initialized
INFO - 2018-02-16 10:34:12 --> Model Class Initialized
INFO - 2018-02-16 10:34:14 --> Config Class Initialized
INFO - 2018-02-16 10:34:14 --> Hooks Class Initialized
DEBUG - 2018-02-16 10:34:14 --> UTF-8 Support Enabled
INFO - 2018-02-16 10:34:14 --> Utf8 Class Initialized
INFO - 2018-02-16 10:34:14 --> URI Class Initialized
INFO - 2018-02-16 10:34:14 --> Router Class Initialized
INFO - 2018-02-16 10:34:14 --> Output Class Initialized
INFO - 2018-02-16 10:34:14 --> Security Class Initialized
DEBUG - 2018-02-16 10:34:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-16 10:34:14 --> Input Class Initialized
INFO - 2018-02-16 10:34:14 --> Language Class Initialized
INFO - 2018-02-16 10:34:14 --> Loader Class Initialized
INFO - 2018-02-16 10:34:14 --> Helper loaded: url_helper
INFO - 2018-02-16 10:34:14 --> Helper loaded: file_helper
INFO - 2018-02-16 10:34:14 --> Helper loaded: email_helper
INFO - 2018-02-16 10:34:14 --> Helper loaded: common_helper
INFO - 2018-02-16 10:34:14 --> Database Driver Class Initialized
DEBUG - 2018-02-16 10:34:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-16 10:34:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-16 10:34:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-16 10:34:14 --> Pagination Class Initialized
INFO - 2018-02-16 10:34:14 --> Helper loaded: form_helper
INFO - 2018-02-16 10:34:14 --> Form Validation Class Initialized
INFO - 2018-02-16 10:34:14 --> Model Class Initialized
INFO - 2018-02-16 10:34:14 --> Controller Class Initialized
INFO - 2018-02-16 10:34:14 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-16 10:34:14 --> Model Class Initialized
INFO - 2018-02-16 10:34:14 --> Model Class Initialized
INFO - 2018-02-16 10:34:14 --> Model Class Initialized
INFO - 2018-02-16 10:34:14 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-16 10:34:14 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-16 10:34:14 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-16 10:34:14 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-16 10:34:14 --> File loaded: /var/www/html/project/radio/application/views/tracks/index.php
INFO - 2018-02-16 10:34:14 --> Final output sent to browser
DEBUG - 2018-02-16 10:34:14 --> Total execution time: 0.0050
INFO - 2018-02-16 10:34:15 --> Config Class Initialized
INFO - 2018-02-16 10:34:15 --> Hooks Class Initialized
DEBUG - 2018-02-16 10:34:15 --> UTF-8 Support Enabled
INFO - 2018-02-16 10:34:15 --> Utf8 Class Initialized
INFO - 2018-02-16 10:34:15 --> URI Class Initialized
INFO - 2018-02-16 10:34:15 --> Router Class Initialized
INFO - 2018-02-16 10:34:15 --> Output Class Initialized
INFO - 2018-02-16 10:34:15 --> Security Class Initialized
DEBUG - 2018-02-16 10:34:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-16 10:34:15 --> Input Class Initialized
INFO - 2018-02-16 10:34:15 --> Language Class Initialized
INFO - 2018-02-16 10:34:15 --> Loader Class Initialized
INFO - 2018-02-16 10:34:15 --> Helper loaded: url_helper
INFO - 2018-02-16 10:34:15 --> Helper loaded: file_helper
INFO - 2018-02-16 10:34:15 --> Helper loaded: email_helper
INFO - 2018-02-16 10:34:15 --> Helper loaded: common_helper
INFO - 2018-02-16 10:34:15 --> Database Driver Class Initialized
DEBUG - 2018-02-16 10:34:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-16 10:34:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-16 10:34:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-16 10:34:15 --> Pagination Class Initialized
INFO - 2018-02-16 10:34:15 --> Helper loaded: form_helper
INFO - 2018-02-16 10:34:15 --> Form Validation Class Initialized
INFO - 2018-02-16 10:34:15 --> Model Class Initialized
INFO - 2018-02-16 10:34:15 --> Controller Class Initialized
INFO - 2018-02-16 10:34:15 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-16 10:34:15 --> Model Class Initialized
INFO - 2018-02-16 10:34:15 --> Model Class Initialized
INFO - 2018-02-16 10:34:15 --> Model Class Initialized
INFO - 2018-02-16 10:34:40 --> Config Class Initialized
INFO - 2018-02-16 10:34:40 --> Hooks Class Initialized
DEBUG - 2018-02-16 10:34:40 --> UTF-8 Support Enabled
INFO - 2018-02-16 10:34:40 --> Utf8 Class Initialized
INFO - 2018-02-16 10:34:40 --> URI Class Initialized
INFO - 2018-02-16 10:34:40 --> Router Class Initialized
INFO - 2018-02-16 10:34:40 --> Output Class Initialized
INFO - 2018-02-16 10:34:40 --> Security Class Initialized
DEBUG - 2018-02-16 10:34:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-16 10:34:40 --> Input Class Initialized
INFO - 2018-02-16 10:34:40 --> Language Class Initialized
INFO - 2018-02-16 10:34:40 --> Loader Class Initialized
INFO - 2018-02-16 10:34:40 --> Helper loaded: url_helper
INFO - 2018-02-16 10:34:40 --> Helper loaded: file_helper
INFO - 2018-02-16 10:34:40 --> Helper loaded: email_helper
INFO - 2018-02-16 10:34:40 --> Helper loaded: common_helper
INFO - 2018-02-16 10:34:40 --> Database Driver Class Initialized
DEBUG - 2018-02-16 10:34:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-16 10:34:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-16 10:34:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-16 10:34:40 --> Pagination Class Initialized
INFO - 2018-02-16 10:34:40 --> Helper loaded: form_helper
INFO - 2018-02-16 10:34:40 --> Form Validation Class Initialized
INFO - 2018-02-16 10:34:40 --> Model Class Initialized
INFO - 2018-02-16 10:34:40 --> Controller Class Initialized
INFO - 2018-02-16 10:34:40 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-16 10:34:40 --> Model Class Initialized
INFO - 2018-02-16 10:34:40 --> Model Class Initialized
INFO - 2018-02-16 10:34:40 --> Model Class Initialized
INFO - 2018-02-16 10:34:40 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-16 10:34:40 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-16 10:34:40 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-16 10:34:40 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-16 10:34:40 --> File loaded: /var/www/html/project/radio/application/views/tracks/index.php
INFO - 2018-02-16 10:34:40 --> Final output sent to browser
DEBUG - 2018-02-16 10:34:40 --> Total execution time: 0.0059
INFO - 2018-02-16 10:34:40 --> Config Class Initialized
INFO - 2018-02-16 10:34:40 --> Hooks Class Initialized
DEBUG - 2018-02-16 10:34:40 --> UTF-8 Support Enabled
INFO - 2018-02-16 10:34:40 --> Utf8 Class Initialized
INFO - 2018-02-16 10:34:40 --> URI Class Initialized
INFO - 2018-02-16 10:34:40 --> Router Class Initialized
INFO - 2018-02-16 10:34:40 --> Output Class Initialized
INFO - 2018-02-16 10:34:40 --> Security Class Initialized
DEBUG - 2018-02-16 10:34:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-16 10:34:40 --> Input Class Initialized
INFO - 2018-02-16 10:34:40 --> Language Class Initialized
INFO - 2018-02-16 10:34:40 --> Loader Class Initialized
INFO - 2018-02-16 10:34:40 --> Helper loaded: url_helper
INFO - 2018-02-16 10:34:40 --> Helper loaded: file_helper
INFO - 2018-02-16 10:34:40 --> Helper loaded: email_helper
INFO - 2018-02-16 10:34:40 --> Helper loaded: common_helper
INFO - 2018-02-16 10:34:40 --> Database Driver Class Initialized
DEBUG - 2018-02-16 10:34:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-16 10:34:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-16 10:34:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-16 10:34:40 --> Pagination Class Initialized
INFO - 2018-02-16 10:34:40 --> Helper loaded: form_helper
INFO - 2018-02-16 10:34:40 --> Form Validation Class Initialized
INFO - 2018-02-16 10:34:40 --> Model Class Initialized
INFO - 2018-02-16 10:34:40 --> Controller Class Initialized
INFO - 2018-02-16 10:34:40 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-16 10:34:40 --> Model Class Initialized
INFO - 2018-02-16 10:34:40 --> Model Class Initialized
INFO - 2018-02-16 10:34:40 --> Model Class Initialized
INFO - 2018-02-16 10:34:42 --> Config Class Initialized
INFO - 2018-02-16 10:34:42 --> Hooks Class Initialized
DEBUG - 2018-02-16 10:34:42 --> UTF-8 Support Enabled
INFO - 2018-02-16 10:34:42 --> Utf8 Class Initialized
INFO - 2018-02-16 10:34:42 --> URI Class Initialized
INFO - 2018-02-16 10:34:42 --> Router Class Initialized
INFO - 2018-02-16 10:34:42 --> Output Class Initialized
INFO - 2018-02-16 10:34:42 --> Security Class Initialized
DEBUG - 2018-02-16 10:34:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-16 10:34:42 --> Input Class Initialized
INFO - 2018-02-16 10:34:42 --> Language Class Initialized
INFO - 2018-02-16 10:34:42 --> Loader Class Initialized
INFO - 2018-02-16 10:34:42 --> Helper loaded: url_helper
INFO - 2018-02-16 10:34:42 --> Helper loaded: file_helper
INFO - 2018-02-16 10:34:42 --> Helper loaded: email_helper
INFO - 2018-02-16 10:34:42 --> Helper loaded: common_helper
INFO - 2018-02-16 10:34:42 --> Database Driver Class Initialized
DEBUG - 2018-02-16 10:34:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-16 10:34:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-16 10:34:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-16 10:34:42 --> Pagination Class Initialized
INFO - 2018-02-16 10:34:42 --> Helper loaded: form_helper
INFO - 2018-02-16 10:34:42 --> Form Validation Class Initialized
INFO - 2018-02-16 10:34:42 --> Model Class Initialized
INFO - 2018-02-16 10:34:42 --> Controller Class Initialized
INFO - 2018-02-16 10:34:42 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-16 10:34:42 --> Model Class Initialized
INFO - 2018-02-16 10:34:42 --> Model Class Initialized
INFO - 2018-02-16 10:34:42 --> Model Class Initialized
INFO - 2018-02-16 10:34:42 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-16 10:34:42 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-16 10:34:42 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-16 10:34:42 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-16 10:34:42 --> File loaded: /var/www/html/project/radio/application/views/tracks/index.php
INFO - 2018-02-16 10:34:42 --> Final output sent to browser
DEBUG - 2018-02-16 10:34:42 --> Total execution time: 0.0040
INFO - 2018-02-16 10:34:43 --> Config Class Initialized
INFO - 2018-02-16 10:34:43 --> Hooks Class Initialized
DEBUG - 2018-02-16 10:34:43 --> UTF-8 Support Enabled
INFO - 2018-02-16 10:34:43 --> Utf8 Class Initialized
INFO - 2018-02-16 10:34:43 --> URI Class Initialized
INFO - 2018-02-16 10:34:43 --> Router Class Initialized
INFO - 2018-02-16 10:34:43 --> Output Class Initialized
INFO - 2018-02-16 10:34:43 --> Security Class Initialized
DEBUG - 2018-02-16 10:34:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-16 10:34:43 --> Input Class Initialized
INFO - 2018-02-16 10:34:43 --> Language Class Initialized
INFO - 2018-02-16 10:34:43 --> Loader Class Initialized
INFO - 2018-02-16 10:34:43 --> Helper loaded: url_helper
INFO - 2018-02-16 10:34:43 --> Helper loaded: file_helper
INFO - 2018-02-16 10:34:43 --> Helper loaded: email_helper
INFO - 2018-02-16 10:34:43 --> Helper loaded: common_helper
INFO - 2018-02-16 10:34:43 --> Database Driver Class Initialized
DEBUG - 2018-02-16 10:34:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-16 10:34:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-16 10:34:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-16 10:34:43 --> Pagination Class Initialized
INFO - 2018-02-16 10:34:43 --> Helper loaded: form_helper
INFO - 2018-02-16 10:34:43 --> Form Validation Class Initialized
INFO - 2018-02-16 10:34:43 --> Model Class Initialized
INFO - 2018-02-16 10:34:43 --> Controller Class Initialized
INFO - 2018-02-16 10:34:43 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-16 10:34:43 --> Model Class Initialized
INFO - 2018-02-16 10:34:43 --> Model Class Initialized
INFO - 2018-02-16 10:34:43 --> Model Class Initialized
INFO - 2018-02-16 10:48:01 --> Config Class Initialized
INFO - 2018-02-16 10:48:01 --> Hooks Class Initialized
DEBUG - 2018-02-16 10:48:01 --> UTF-8 Support Enabled
INFO - 2018-02-16 10:48:01 --> Utf8 Class Initialized
INFO - 2018-02-16 10:48:01 --> URI Class Initialized
INFO - 2018-02-16 10:48:01 --> Router Class Initialized
INFO - 2018-02-16 10:48:01 --> Output Class Initialized
INFO - 2018-02-16 10:48:01 --> Security Class Initialized
DEBUG - 2018-02-16 10:48:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-16 10:48:01 --> Input Class Initialized
INFO - 2018-02-16 10:48:01 --> Language Class Initialized
INFO - 2018-02-16 10:48:01 --> Loader Class Initialized
INFO - 2018-02-16 10:48:01 --> Helper loaded: url_helper
INFO - 2018-02-16 10:48:01 --> Helper loaded: file_helper
INFO - 2018-02-16 10:48:01 --> Helper loaded: email_helper
INFO - 2018-02-16 10:48:01 --> Helper loaded: common_helper
INFO - 2018-02-16 10:48:01 --> Database Driver Class Initialized
DEBUG - 2018-02-16 10:48:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-16 10:48:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-16 10:48:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-16 10:48:01 --> Pagination Class Initialized
INFO - 2018-02-16 10:48:01 --> Helper loaded: form_helper
INFO - 2018-02-16 10:48:01 --> Form Validation Class Initialized
INFO - 2018-02-16 10:48:01 --> Model Class Initialized
INFO - 2018-02-16 10:48:01 --> Controller Class Initialized
INFO - 2018-02-16 10:48:01 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-16 10:48:01 --> Model Class Initialized
INFO - 2018-02-16 10:48:01 --> Model Class Initialized
INFO - 2018-02-16 10:48:01 --> Model Class Initialized
INFO - 2018-02-16 10:48:03 --> Config Class Initialized
INFO - 2018-02-16 10:48:03 --> Hooks Class Initialized
DEBUG - 2018-02-16 10:48:03 --> UTF-8 Support Enabled
INFO - 2018-02-16 10:48:03 --> Utf8 Class Initialized
INFO - 2018-02-16 10:48:03 --> URI Class Initialized
INFO - 2018-02-16 10:48:03 --> Router Class Initialized
INFO - 2018-02-16 10:48:03 --> Output Class Initialized
INFO - 2018-02-16 10:48:03 --> Security Class Initialized
DEBUG - 2018-02-16 10:48:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-16 10:48:03 --> Input Class Initialized
INFO - 2018-02-16 10:48:03 --> Language Class Initialized
INFO - 2018-02-16 10:48:03 --> Loader Class Initialized
INFO - 2018-02-16 10:48:03 --> Helper loaded: url_helper
INFO - 2018-02-16 10:48:03 --> Helper loaded: file_helper
INFO - 2018-02-16 10:48:03 --> Helper loaded: email_helper
INFO - 2018-02-16 10:48:03 --> Helper loaded: common_helper
INFO - 2018-02-16 10:48:03 --> Database Driver Class Initialized
DEBUG - 2018-02-16 10:48:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-16 10:48:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-16 10:48:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-16 10:48:03 --> Pagination Class Initialized
INFO - 2018-02-16 10:48:03 --> Helper loaded: form_helper
INFO - 2018-02-16 10:48:03 --> Form Validation Class Initialized
INFO - 2018-02-16 10:48:03 --> Model Class Initialized
INFO - 2018-02-16 10:48:03 --> Controller Class Initialized
INFO - 2018-02-16 10:48:03 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-16 10:48:03 --> Model Class Initialized
INFO - 2018-02-16 10:48:03 --> Model Class Initialized
INFO - 2018-02-16 10:48:03 --> Model Class Initialized
INFO - 2018-02-16 10:50:41 --> Config Class Initialized
INFO - 2018-02-16 10:50:41 --> Hooks Class Initialized
DEBUG - 2018-02-16 10:50:41 --> UTF-8 Support Enabled
INFO - 2018-02-16 10:50:41 --> Utf8 Class Initialized
INFO - 2018-02-16 10:50:41 --> URI Class Initialized
INFO - 2018-02-16 10:50:41 --> Router Class Initialized
INFO - 2018-02-16 10:50:41 --> Output Class Initialized
INFO - 2018-02-16 10:50:41 --> Security Class Initialized
DEBUG - 2018-02-16 10:50:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-16 10:50:41 --> Input Class Initialized
INFO - 2018-02-16 10:50:41 --> Language Class Initialized
INFO - 2018-02-16 10:50:41 --> Loader Class Initialized
INFO - 2018-02-16 10:50:41 --> Helper loaded: url_helper
INFO - 2018-02-16 10:50:41 --> Helper loaded: file_helper
INFO - 2018-02-16 10:50:41 --> Helper loaded: email_helper
INFO - 2018-02-16 10:50:41 --> Helper loaded: common_helper
INFO - 2018-02-16 10:50:41 --> Database Driver Class Initialized
DEBUG - 2018-02-16 10:50:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-16 10:50:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-16 10:50:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-16 10:50:41 --> Pagination Class Initialized
INFO - 2018-02-16 10:50:41 --> Helper loaded: form_helper
INFO - 2018-02-16 10:50:41 --> Form Validation Class Initialized
INFO - 2018-02-16 10:50:41 --> Model Class Initialized
INFO - 2018-02-16 10:50:41 --> Controller Class Initialized
INFO - 2018-02-16 10:50:41 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-16 10:50:41 --> Model Class Initialized
INFO - 2018-02-16 10:50:41 --> Model Class Initialized
INFO - 2018-02-16 10:50:41 --> Model Class Initialized
INFO - 2018-02-16 10:50:42 --> Config Class Initialized
INFO - 2018-02-16 10:50:42 --> Hooks Class Initialized
DEBUG - 2018-02-16 10:50:42 --> UTF-8 Support Enabled
INFO - 2018-02-16 10:50:42 --> Utf8 Class Initialized
INFO - 2018-02-16 10:50:42 --> URI Class Initialized
INFO - 2018-02-16 10:50:42 --> Router Class Initialized
INFO - 2018-02-16 10:50:42 --> Output Class Initialized
INFO - 2018-02-16 10:50:42 --> Security Class Initialized
DEBUG - 2018-02-16 10:50:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-16 10:50:42 --> Input Class Initialized
INFO - 2018-02-16 10:50:42 --> Language Class Initialized
INFO - 2018-02-16 10:50:42 --> Loader Class Initialized
INFO - 2018-02-16 10:50:42 --> Helper loaded: url_helper
INFO - 2018-02-16 10:50:42 --> Helper loaded: file_helper
INFO - 2018-02-16 10:50:42 --> Helper loaded: email_helper
INFO - 2018-02-16 10:50:42 --> Helper loaded: common_helper
INFO - 2018-02-16 10:50:42 --> Database Driver Class Initialized
DEBUG - 2018-02-16 10:50:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-16 10:50:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-16 10:50:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-16 10:50:42 --> Pagination Class Initialized
INFO - 2018-02-16 10:50:42 --> Helper loaded: form_helper
INFO - 2018-02-16 10:50:42 --> Form Validation Class Initialized
INFO - 2018-02-16 10:50:42 --> Model Class Initialized
INFO - 2018-02-16 10:50:42 --> Controller Class Initialized
INFO - 2018-02-16 10:50:42 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-16 10:50:42 --> Model Class Initialized
INFO - 2018-02-16 10:50:42 --> Model Class Initialized
INFO - 2018-02-16 10:50:42 --> Model Class Initialized
INFO - 2018-02-16 10:50:43 --> Config Class Initialized
INFO - 2018-02-16 10:50:43 --> Hooks Class Initialized
DEBUG - 2018-02-16 10:50:43 --> UTF-8 Support Enabled
INFO - 2018-02-16 10:50:43 --> Utf8 Class Initialized
INFO - 2018-02-16 10:50:43 --> URI Class Initialized
INFO - 2018-02-16 10:50:43 --> Router Class Initialized
INFO - 2018-02-16 10:50:43 --> Output Class Initialized
INFO - 2018-02-16 10:50:43 --> Security Class Initialized
DEBUG - 2018-02-16 10:50:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-16 10:50:43 --> Input Class Initialized
INFO - 2018-02-16 10:50:43 --> Language Class Initialized
INFO - 2018-02-16 10:50:43 --> Loader Class Initialized
INFO - 2018-02-16 10:50:43 --> Helper loaded: url_helper
INFO - 2018-02-16 10:50:43 --> Helper loaded: file_helper
INFO - 2018-02-16 10:50:43 --> Helper loaded: email_helper
INFO - 2018-02-16 10:50:43 --> Helper loaded: common_helper
INFO - 2018-02-16 10:50:43 --> Database Driver Class Initialized
DEBUG - 2018-02-16 10:50:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-16 10:50:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-16 10:50:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-16 10:50:43 --> Pagination Class Initialized
INFO - 2018-02-16 10:50:43 --> Helper loaded: form_helper
INFO - 2018-02-16 10:50:43 --> Form Validation Class Initialized
INFO - 2018-02-16 10:50:43 --> Model Class Initialized
INFO - 2018-02-16 10:50:43 --> Controller Class Initialized
INFO - 2018-02-16 10:50:43 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-16 10:50:43 --> Model Class Initialized
INFO - 2018-02-16 10:50:43 --> Model Class Initialized
INFO - 2018-02-16 10:50:43 --> Model Class Initialized
INFO - 2018-02-16 10:50:46 --> Config Class Initialized
INFO - 2018-02-16 10:50:46 --> Hooks Class Initialized
DEBUG - 2018-02-16 10:50:46 --> UTF-8 Support Enabled
INFO - 2018-02-16 10:50:46 --> Utf8 Class Initialized
INFO - 2018-02-16 10:50:46 --> URI Class Initialized
INFO - 2018-02-16 10:50:46 --> Router Class Initialized
INFO - 2018-02-16 10:50:46 --> Output Class Initialized
INFO - 2018-02-16 10:50:46 --> Security Class Initialized
DEBUG - 2018-02-16 10:50:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-16 10:50:46 --> Input Class Initialized
INFO - 2018-02-16 10:50:46 --> Language Class Initialized
INFO - 2018-02-16 10:50:46 --> Loader Class Initialized
INFO - 2018-02-16 10:50:46 --> Helper loaded: url_helper
INFO - 2018-02-16 10:50:46 --> Helper loaded: file_helper
INFO - 2018-02-16 10:50:46 --> Helper loaded: email_helper
INFO - 2018-02-16 10:50:46 --> Helper loaded: common_helper
INFO - 2018-02-16 10:50:46 --> Database Driver Class Initialized
DEBUG - 2018-02-16 10:50:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-16 10:50:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-16 10:50:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-16 10:50:46 --> Pagination Class Initialized
INFO - 2018-02-16 10:50:46 --> Helper loaded: form_helper
INFO - 2018-02-16 10:50:46 --> Form Validation Class Initialized
INFO - 2018-02-16 10:50:46 --> Model Class Initialized
INFO - 2018-02-16 10:50:46 --> Controller Class Initialized
INFO - 2018-02-16 10:50:46 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-16 10:50:46 --> Model Class Initialized
INFO - 2018-02-16 10:50:46 --> Model Class Initialized
INFO - 2018-02-16 10:50:46 --> Model Class Initialized
INFO - 2018-02-16 10:50:47 --> Config Class Initialized
INFO - 2018-02-16 10:50:47 --> Hooks Class Initialized
DEBUG - 2018-02-16 10:50:47 --> UTF-8 Support Enabled
INFO - 2018-02-16 10:50:47 --> Utf8 Class Initialized
INFO - 2018-02-16 10:50:47 --> URI Class Initialized
INFO - 2018-02-16 10:50:47 --> Router Class Initialized
INFO - 2018-02-16 10:50:47 --> Output Class Initialized
INFO - 2018-02-16 10:50:47 --> Security Class Initialized
DEBUG - 2018-02-16 10:50:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-16 10:50:47 --> Input Class Initialized
INFO - 2018-02-16 10:50:47 --> Language Class Initialized
INFO - 2018-02-16 10:50:47 --> Loader Class Initialized
INFO - 2018-02-16 10:50:47 --> Helper loaded: url_helper
INFO - 2018-02-16 10:50:47 --> Helper loaded: file_helper
INFO - 2018-02-16 10:50:47 --> Helper loaded: email_helper
INFO - 2018-02-16 10:50:47 --> Helper loaded: common_helper
INFO - 2018-02-16 10:50:47 --> Database Driver Class Initialized
DEBUG - 2018-02-16 10:50:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-16 10:50:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-16 10:50:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-16 10:50:47 --> Pagination Class Initialized
INFO - 2018-02-16 10:50:47 --> Helper loaded: form_helper
INFO - 2018-02-16 10:50:47 --> Form Validation Class Initialized
INFO - 2018-02-16 10:50:47 --> Model Class Initialized
INFO - 2018-02-16 10:50:47 --> Controller Class Initialized
INFO - 2018-02-16 10:50:47 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-16 10:50:47 --> Model Class Initialized
INFO - 2018-02-16 10:50:47 --> Model Class Initialized
INFO - 2018-02-16 10:50:47 --> Model Class Initialized
INFO - 2018-02-16 10:50:47 --> Config Class Initialized
INFO - 2018-02-16 10:50:47 --> Hooks Class Initialized
DEBUG - 2018-02-16 10:50:47 --> UTF-8 Support Enabled
INFO - 2018-02-16 10:50:47 --> Utf8 Class Initialized
INFO - 2018-02-16 10:50:47 --> URI Class Initialized
INFO - 2018-02-16 10:50:47 --> Router Class Initialized
INFO - 2018-02-16 10:50:47 --> Output Class Initialized
INFO - 2018-02-16 10:50:47 --> Security Class Initialized
DEBUG - 2018-02-16 10:50:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-16 10:50:47 --> Input Class Initialized
INFO - 2018-02-16 10:50:47 --> Language Class Initialized
INFO - 2018-02-16 10:50:47 --> Loader Class Initialized
INFO - 2018-02-16 10:50:47 --> Helper loaded: url_helper
INFO - 2018-02-16 10:50:47 --> Helper loaded: file_helper
INFO - 2018-02-16 10:50:47 --> Helper loaded: email_helper
INFO - 2018-02-16 10:50:47 --> Helper loaded: common_helper
INFO - 2018-02-16 10:50:47 --> Database Driver Class Initialized
DEBUG - 2018-02-16 10:50:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-16 10:50:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-16 10:50:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-16 10:50:47 --> Pagination Class Initialized
INFO - 2018-02-16 10:50:47 --> Helper loaded: form_helper
INFO - 2018-02-16 10:50:47 --> Form Validation Class Initialized
INFO - 2018-02-16 10:50:47 --> Model Class Initialized
INFO - 2018-02-16 10:50:47 --> Controller Class Initialized
INFO - 2018-02-16 10:50:47 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-16 10:50:47 --> Model Class Initialized
INFO - 2018-02-16 10:50:47 --> Model Class Initialized
INFO - 2018-02-16 10:50:47 --> Model Class Initialized
INFO - 2018-02-16 10:50:50 --> Config Class Initialized
INFO - 2018-02-16 10:50:50 --> Hooks Class Initialized
DEBUG - 2018-02-16 10:50:50 --> UTF-8 Support Enabled
INFO - 2018-02-16 10:50:50 --> Utf8 Class Initialized
INFO - 2018-02-16 10:50:50 --> URI Class Initialized
INFO - 2018-02-16 10:50:50 --> Router Class Initialized
INFO - 2018-02-16 10:50:50 --> Output Class Initialized
INFO - 2018-02-16 10:50:50 --> Security Class Initialized
DEBUG - 2018-02-16 10:50:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-16 10:50:50 --> Input Class Initialized
INFO - 2018-02-16 10:50:50 --> Language Class Initialized
INFO - 2018-02-16 10:50:50 --> Loader Class Initialized
INFO - 2018-02-16 10:50:50 --> Helper loaded: url_helper
INFO - 2018-02-16 10:50:50 --> Helper loaded: file_helper
INFO - 2018-02-16 10:50:50 --> Helper loaded: email_helper
INFO - 2018-02-16 10:50:50 --> Helper loaded: common_helper
INFO - 2018-02-16 10:50:50 --> Database Driver Class Initialized
DEBUG - 2018-02-16 10:50:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-16 10:50:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-16 10:50:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-16 10:50:50 --> Pagination Class Initialized
INFO - 2018-02-16 10:50:50 --> Helper loaded: form_helper
INFO - 2018-02-16 10:50:50 --> Form Validation Class Initialized
INFO - 2018-02-16 10:50:50 --> Model Class Initialized
INFO - 2018-02-16 10:50:50 --> Controller Class Initialized
INFO - 2018-02-16 10:50:50 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-16 10:50:50 --> Model Class Initialized
INFO - 2018-02-16 10:50:50 --> Model Class Initialized
INFO - 2018-02-16 10:50:50 --> Model Class Initialized
INFO - 2018-02-16 10:50:51 --> Config Class Initialized
INFO - 2018-02-16 10:50:51 --> Hooks Class Initialized
DEBUG - 2018-02-16 10:50:51 --> UTF-8 Support Enabled
INFO - 2018-02-16 10:50:51 --> Utf8 Class Initialized
INFO - 2018-02-16 10:50:51 --> URI Class Initialized
INFO - 2018-02-16 10:50:51 --> Router Class Initialized
INFO - 2018-02-16 10:50:51 --> Output Class Initialized
INFO - 2018-02-16 10:50:51 --> Security Class Initialized
DEBUG - 2018-02-16 10:50:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-16 10:50:51 --> Input Class Initialized
INFO - 2018-02-16 10:50:51 --> Language Class Initialized
INFO - 2018-02-16 10:50:51 --> Loader Class Initialized
INFO - 2018-02-16 10:50:51 --> Helper loaded: url_helper
INFO - 2018-02-16 10:50:51 --> Helper loaded: file_helper
INFO - 2018-02-16 10:50:51 --> Helper loaded: email_helper
INFO - 2018-02-16 10:50:51 --> Helper loaded: common_helper
INFO - 2018-02-16 10:50:51 --> Database Driver Class Initialized
DEBUG - 2018-02-16 10:50:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-16 10:50:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-16 10:50:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-16 10:50:51 --> Pagination Class Initialized
INFO - 2018-02-16 10:50:51 --> Helper loaded: form_helper
INFO - 2018-02-16 10:50:51 --> Form Validation Class Initialized
INFO - 2018-02-16 10:50:51 --> Model Class Initialized
INFO - 2018-02-16 10:50:51 --> Controller Class Initialized
INFO - 2018-02-16 10:50:51 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-16 10:50:51 --> Model Class Initialized
INFO - 2018-02-16 10:50:51 --> Model Class Initialized
INFO - 2018-02-16 10:50:51 --> Model Class Initialized
INFO - 2018-02-16 10:50:51 --> Config Class Initialized
INFO - 2018-02-16 10:50:51 --> Hooks Class Initialized
DEBUG - 2018-02-16 10:50:51 --> UTF-8 Support Enabled
INFO - 2018-02-16 10:50:51 --> Utf8 Class Initialized
INFO - 2018-02-16 10:50:51 --> URI Class Initialized
INFO - 2018-02-16 10:50:51 --> Router Class Initialized
INFO - 2018-02-16 10:50:51 --> Output Class Initialized
INFO - 2018-02-16 10:50:51 --> Security Class Initialized
DEBUG - 2018-02-16 10:50:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-16 10:50:51 --> Input Class Initialized
INFO - 2018-02-16 10:50:51 --> Language Class Initialized
INFO - 2018-02-16 10:50:51 --> Loader Class Initialized
INFO - 2018-02-16 10:50:51 --> Helper loaded: url_helper
INFO - 2018-02-16 10:50:51 --> Helper loaded: file_helper
INFO - 2018-02-16 10:50:51 --> Helper loaded: email_helper
INFO - 2018-02-16 10:50:51 --> Helper loaded: common_helper
INFO - 2018-02-16 10:50:51 --> Database Driver Class Initialized
DEBUG - 2018-02-16 10:50:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-16 10:50:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-16 10:50:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-16 10:50:51 --> Pagination Class Initialized
INFO - 2018-02-16 10:50:51 --> Helper loaded: form_helper
INFO - 2018-02-16 10:50:51 --> Form Validation Class Initialized
INFO - 2018-02-16 10:50:51 --> Model Class Initialized
INFO - 2018-02-16 10:50:51 --> Controller Class Initialized
INFO - 2018-02-16 10:50:51 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-16 10:50:51 --> Model Class Initialized
INFO - 2018-02-16 10:50:51 --> Model Class Initialized
INFO - 2018-02-16 10:50:51 --> Model Class Initialized
INFO - 2018-02-16 11:00:30 --> Config Class Initialized
INFO - 2018-02-16 11:00:30 --> Hooks Class Initialized
DEBUG - 2018-02-16 11:00:30 --> UTF-8 Support Enabled
INFO - 2018-02-16 11:00:30 --> Utf8 Class Initialized
INFO - 2018-02-16 11:00:30 --> URI Class Initialized
INFO - 2018-02-16 11:00:30 --> Router Class Initialized
INFO - 2018-02-16 11:00:30 --> Output Class Initialized
INFO - 2018-02-16 11:00:30 --> Security Class Initialized
DEBUG - 2018-02-16 11:00:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-16 11:00:30 --> Input Class Initialized
INFO - 2018-02-16 11:00:30 --> Language Class Initialized
INFO - 2018-02-16 11:00:30 --> Loader Class Initialized
INFO - 2018-02-16 11:00:30 --> Helper loaded: url_helper
INFO - 2018-02-16 11:00:30 --> Helper loaded: file_helper
INFO - 2018-02-16 11:00:30 --> Helper loaded: email_helper
INFO - 2018-02-16 11:00:30 --> Helper loaded: common_helper
INFO - 2018-02-16 11:00:30 --> Database Driver Class Initialized
DEBUG - 2018-02-16 11:00:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-16 11:00:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-16 11:00:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-16 11:00:30 --> Pagination Class Initialized
INFO - 2018-02-16 11:00:30 --> Helper loaded: form_helper
INFO - 2018-02-16 11:00:30 --> Form Validation Class Initialized
INFO - 2018-02-16 11:00:30 --> Model Class Initialized
INFO - 2018-02-16 11:00:30 --> Controller Class Initialized
INFO - 2018-02-16 11:00:30 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-16 11:00:30 --> Model Class Initialized
INFO - 2018-02-16 11:00:30 --> Model Class Initialized
INFO - 2018-02-16 11:00:30 --> Model Class Initialized
INFO - 2018-02-16 11:00:30 --> Config Class Initialized
INFO - 2018-02-16 11:00:30 --> Hooks Class Initialized
DEBUG - 2018-02-16 11:00:30 --> UTF-8 Support Enabled
INFO - 2018-02-16 11:00:30 --> Utf8 Class Initialized
INFO - 2018-02-16 11:00:30 --> URI Class Initialized
INFO - 2018-02-16 11:00:30 --> Router Class Initialized
INFO - 2018-02-16 11:00:30 --> Output Class Initialized
INFO - 2018-02-16 11:00:30 --> Security Class Initialized
DEBUG - 2018-02-16 11:00:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-16 11:00:30 --> Input Class Initialized
INFO - 2018-02-16 11:00:30 --> Language Class Initialized
INFO - 2018-02-16 11:00:30 --> Loader Class Initialized
INFO - 2018-02-16 11:00:30 --> Helper loaded: url_helper
INFO - 2018-02-16 11:00:30 --> Helper loaded: file_helper
INFO - 2018-02-16 11:00:30 --> Helper loaded: email_helper
INFO - 2018-02-16 11:00:30 --> Helper loaded: common_helper
INFO - 2018-02-16 11:00:30 --> Database Driver Class Initialized
DEBUG - 2018-02-16 11:00:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-16 11:00:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-16 11:00:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-16 11:00:30 --> Pagination Class Initialized
INFO - 2018-02-16 11:00:30 --> Helper loaded: form_helper
INFO - 2018-02-16 11:00:30 --> Form Validation Class Initialized
INFO - 2018-02-16 11:00:30 --> Model Class Initialized
INFO - 2018-02-16 11:00:30 --> Controller Class Initialized
INFO - 2018-02-16 11:00:30 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-16 11:00:30 --> Model Class Initialized
INFO - 2018-02-16 11:00:30 --> Model Class Initialized
INFO - 2018-02-16 11:00:30 --> Model Class Initialized
INFO - 2018-02-16 11:00:31 --> Config Class Initialized
INFO - 2018-02-16 11:00:31 --> Hooks Class Initialized
DEBUG - 2018-02-16 11:00:31 --> UTF-8 Support Enabled
INFO - 2018-02-16 11:00:31 --> Utf8 Class Initialized
INFO - 2018-02-16 11:00:31 --> URI Class Initialized
INFO - 2018-02-16 11:00:31 --> Router Class Initialized
INFO - 2018-02-16 11:00:31 --> Output Class Initialized
INFO - 2018-02-16 11:00:31 --> Security Class Initialized
DEBUG - 2018-02-16 11:00:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-16 11:00:31 --> Input Class Initialized
INFO - 2018-02-16 11:00:31 --> Language Class Initialized
INFO - 2018-02-16 11:00:31 --> Loader Class Initialized
INFO - 2018-02-16 11:00:31 --> Helper loaded: url_helper
INFO - 2018-02-16 11:00:31 --> Helper loaded: file_helper
INFO - 2018-02-16 11:00:31 --> Helper loaded: email_helper
INFO - 2018-02-16 11:00:31 --> Helper loaded: common_helper
INFO - 2018-02-16 11:00:31 --> Database Driver Class Initialized
DEBUG - 2018-02-16 11:00:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-16 11:00:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-16 11:00:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-16 11:00:31 --> Pagination Class Initialized
INFO - 2018-02-16 11:00:31 --> Helper loaded: form_helper
INFO - 2018-02-16 11:00:31 --> Form Validation Class Initialized
INFO - 2018-02-16 11:00:31 --> Model Class Initialized
INFO - 2018-02-16 11:00:31 --> Controller Class Initialized
INFO - 2018-02-16 11:00:31 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-16 11:00:31 --> Model Class Initialized
INFO - 2018-02-16 11:00:31 --> Model Class Initialized
INFO - 2018-02-16 11:00:31 --> Model Class Initialized
INFO - 2018-02-16 11:00:32 --> Config Class Initialized
INFO - 2018-02-16 11:00:32 --> Hooks Class Initialized
DEBUG - 2018-02-16 11:00:32 --> UTF-8 Support Enabled
INFO - 2018-02-16 11:00:32 --> Utf8 Class Initialized
INFO - 2018-02-16 11:00:32 --> URI Class Initialized
INFO - 2018-02-16 11:00:32 --> Router Class Initialized
INFO - 2018-02-16 11:00:32 --> Output Class Initialized
INFO - 2018-02-16 11:00:32 --> Security Class Initialized
DEBUG - 2018-02-16 11:00:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-16 11:00:32 --> Input Class Initialized
INFO - 2018-02-16 11:00:32 --> Language Class Initialized
INFO - 2018-02-16 11:00:32 --> Loader Class Initialized
INFO - 2018-02-16 11:00:32 --> Helper loaded: url_helper
INFO - 2018-02-16 11:00:32 --> Helper loaded: file_helper
INFO - 2018-02-16 11:00:32 --> Helper loaded: email_helper
INFO - 2018-02-16 11:00:32 --> Helper loaded: common_helper
INFO - 2018-02-16 11:00:32 --> Database Driver Class Initialized
DEBUG - 2018-02-16 11:00:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-16 11:00:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-16 11:00:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-16 11:00:32 --> Pagination Class Initialized
INFO - 2018-02-16 11:00:32 --> Helper loaded: form_helper
INFO - 2018-02-16 11:00:32 --> Form Validation Class Initialized
INFO - 2018-02-16 11:00:32 --> Model Class Initialized
INFO - 2018-02-16 11:00:32 --> Controller Class Initialized
INFO - 2018-02-16 11:00:32 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-16 11:00:32 --> Model Class Initialized
INFO - 2018-02-16 11:00:32 --> Model Class Initialized
INFO - 2018-02-16 11:00:32 --> Model Class Initialized
INFO - 2018-02-16 11:00:34 --> Config Class Initialized
INFO - 2018-02-16 11:00:34 --> Hooks Class Initialized
DEBUG - 2018-02-16 11:00:34 --> UTF-8 Support Enabled
INFO - 2018-02-16 11:00:34 --> Utf8 Class Initialized
INFO - 2018-02-16 11:00:34 --> URI Class Initialized
INFO - 2018-02-16 11:00:34 --> Router Class Initialized
INFO - 2018-02-16 11:00:34 --> Output Class Initialized
INFO - 2018-02-16 11:00:34 --> Security Class Initialized
DEBUG - 2018-02-16 11:00:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-16 11:00:34 --> Input Class Initialized
INFO - 2018-02-16 11:00:34 --> Language Class Initialized
INFO - 2018-02-16 11:00:34 --> Loader Class Initialized
INFO - 2018-02-16 11:00:34 --> Helper loaded: url_helper
INFO - 2018-02-16 11:00:34 --> Helper loaded: file_helper
INFO - 2018-02-16 11:00:34 --> Helper loaded: email_helper
INFO - 2018-02-16 11:00:34 --> Helper loaded: common_helper
INFO - 2018-02-16 11:00:34 --> Database Driver Class Initialized
DEBUG - 2018-02-16 11:00:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-16 11:00:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-16 11:00:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-16 11:00:34 --> Pagination Class Initialized
INFO - 2018-02-16 11:00:34 --> Helper loaded: form_helper
INFO - 2018-02-16 11:00:34 --> Form Validation Class Initialized
INFO - 2018-02-16 11:00:34 --> Model Class Initialized
INFO - 2018-02-16 11:00:34 --> Controller Class Initialized
INFO - 2018-02-16 11:00:34 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-16 11:00:34 --> Model Class Initialized
INFO - 2018-02-16 11:00:34 --> Model Class Initialized
INFO - 2018-02-16 11:00:34 --> Model Class Initialized
INFO - 2018-02-16 11:00:35 --> Config Class Initialized
INFO - 2018-02-16 11:00:35 --> Hooks Class Initialized
DEBUG - 2018-02-16 11:00:35 --> UTF-8 Support Enabled
INFO - 2018-02-16 11:00:35 --> Utf8 Class Initialized
INFO - 2018-02-16 11:00:35 --> URI Class Initialized
INFO - 2018-02-16 11:00:35 --> Router Class Initialized
INFO - 2018-02-16 11:00:35 --> Output Class Initialized
INFO - 2018-02-16 11:00:35 --> Security Class Initialized
DEBUG - 2018-02-16 11:00:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-16 11:00:35 --> Input Class Initialized
INFO - 2018-02-16 11:00:35 --> Language Class Initialized
INFO - 2018-02-16 11:00:35 --> Loader Class Initialized
INFO - 2018-02-16 11:00:35 --> Helper loaded: url_helper
INFO - 2018-02-16 11:00:35 --> Helper loaded: file_helper
INFO - 2018-02-16 11:00:35 --> Helper loaded: email_helper
INFO - 2018-02-16 11:00:35 --> Helper loaded: common_helper
INFO - 2018-02-16 11:00:35 --> Database Driver Class Initialized
DEBUG - 2018-02-16 11:00:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-16 11:00:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-16 11:00:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-16 11:00:35 --> Pagination Class Initialized
INFO - 2018-02-16 11:00:35 --> Helper loaded: form_helper
INFO - 2018-02-16 11:00:35 --> Form Validation Class Initialized
INFO - 2018-02-16 11:00:35 --> Model Class Initialized
INFO - 2018-02-16 11:00:35 --> Controller Class Initialized
INFO - 2018-02-16 11:00:35 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-16 11:00:35 --> Model Class Initialized
INFO - 2018-02-16 11:00:35 --> Model Class Initialized
INFO - 2018-02-16 11:00:35 --> Model Class Initialized
INFO - 2018-02-16 11:00:37 --> Config Class Initialized
INFO - 2018-02-16 11:00:37 --> Hooks Class Initialized
DEBUG - 2018-02-16 11:00:37 --> UTF-8 Support Enabled
INFO - 2018-02-16 11:00:37 --> Utf8 Class Initialized
INFO - 2018-02-16 11:00:37 --> URI Class Initialized
INFO - 2018-02-16 11:00:37 --> Router Class Initialized
INFO - 2018-02-16 11:00:37 --> Output Class Initialized
INFO - 2018-02-16 11:00:37 --> Security Class Initialized
DEBUG - 2018-02-16 11:00:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-16 11:00:37 --> Input Class Initialized
INFO - 2018-02-16 11:00:37 --> Language Class Initialized
INFO - 2018-02-16 11:00:37 --> Loader Class Initialized
INFO - 2018-02-16 11:00:37 --> Helper loaded: url_helper
INFO - 2018-02-16 11:00:37 --> Helper loaded: file_helper
INFO - 2018-02-16 11:00:37 --> Helper loaded: email_helper
INFO - 2018-02-16 11:00:37 --> Helper loaded: common_helper
INFO - 2018-02-16 11:00:37 --> Database Driver Class Initialized
DEBUG - 2018-02-16 11:00:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-16 11:00:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-16 11:00:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-16 11:00:37 --> Pagination Class Initialized
INFO - 2018-02-16 11:00:37 --> Helper loaded: form_helper
INFO - 2018-02-16 11:00:37 --> Form Validation Class Initialized
INFO - 2018-02-16 11:00:37 --> Model Class Initialized
INFO - 2018-02-16 11:00:37 --> Controller Class Initialized
INFO - 2018-02-16 11:00:37 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-16 11:00:37 --> Model Class Initialized
INFO - 2018-02-16 11:00:37 --> Model Class Initialized
INFO - 2018-02-16 11:00:37 --> Model Class Initialized
INFO - 2018-02-16 11:00:38 --> Config Class Initialized
INFO - 2018-02-16 11:00:38 --> Hooks Class Initialized
DEBUG - 2018-02-16 11:00:38 --> UTF-8 Support Enabled
INFO - 2018-02-16 11:00:38 --> Utf8 Class Initialized
INFO - 2018-02-16 11:00:38 --> URI Class Initialized
INFO - 2018-02-16 11:00:38 --> Router Class Initialized
INFO - 2018-02-16 11:00:38 --> Output Class Initialized
INFO - 2018-02-16 11:00:38 --> Security Class Initialized
DEBUG - 2018-02-16 11:00:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-16 11:00:38 --> Input Class Initialized
INFO - 2018-02-16 11:00:38 --> Language Class Initialized
INFO - 2018-02-16 11:00:38 --> Loader Class Initialized
INFO - 2018-02-16 11:00:38 --> Helper loaded: url_helper
INFO - 2018-02-16 11:00:38 --> Helper loaded: file_helper
INFO - 2018-02-16 11:00:38 --> Helper loaded: email_helper
INFO - 2018-02-16 11:00:38 --> Helper loaded: common_helper
INFO - 2018-02-16 11:00:38 --> Database Driver Class Initialized
DEBUG - 2018-02-16 11:00:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-16 11:00:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-16 11:00:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-16 11:00:38 --> Pagination Class Initialized
INFO - 2018-02-16 11:00:38 --> Helper loaded: form_helper
INFO - 2018-02-16 11:00:38 --> Form Validation Class Initialized
INFO - 2018-02-16 11:00:38 --> Model Class Initialized
INFO - 2018-02-16 11:00:38 --> Controller Class Initialized
INFO - 2018-02-16 11:00:38 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-16 11:00:38 --> Model Class Initialized
INFO - 2018-02-16 11:00:38 --> Model Class Initialized
INFO - 2018-02-16 11:00:38 --> Model Class Initialized
INFO - 2018-02-16 11:00:39 --> Config Class Initialized
INFO - 2018-02-16 11:00:39 --> Hooks Class Initialized
DEBUG - 2018-02-16 11:00:39 --> UTF-8 Support Enabled
INFO - 2018-02-16 11:00:39 --> Utf8 Class Initialized
INFO - 2018-02-16 11:00:39 --> URI Class Initialized
INFO - 2018-02-16 11:00:39 --> Router Class Initialized
INFO - 2018-02-16 11:00:39 --> Output Class Initialized
INFO - 2018-02-16 11:00:39 --> Security Class Initialized
DEBUG - 2018-02-16 11:00:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-16 11:00:39 --> Input Class Initialized
INFO - 2018-02-16 11:00:39 --> Language Class Initialized
INFO - 2018-02-16 11:00:39 --> Loader Class Initialized
INFO - 2018-02-16 11:00:39 --> Helper loaded: url_helper
INFO - 2018-02-16 11:00:39 --> Helper loaded: file_helper
INFO - 2018-02-16 11:00:39 --> Helper loaded: email_helper
INFO - 2018-02-16 11:00:39 --> Helper loaded: common_helper
INFO - 2018-02-16 11:00:39 --> Database Driver Class Initialized
DEBUG - 2018-02-16 11:00:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-16 11:00:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-16 11:00:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-16 11:00:39 --> Pagination Class Initialized
INFO - 2018-02-16 11:00:39 --> Helper loaded: form_helper
INFO - 2018-02-16 11:00:39 --> Form Validation Class Initialized
INFO - 2018-02-16 11:00:39 --> Model Class Initialized
INFO - 2018-02-16 11:00:39 --> Controller Class Initialized
INFO - 2018-02-16 11:00:39 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-16 11:00:39 --> Model Class Initialized
INFO - 2018-02-16 11:00:39 --> Model Class Initialized
INFO - 2018-02-16 11:00:39 --> Model Class Initialized
INFO - 2018-02-16 11:00:40 --> Config Class Initialized
INFO - 2018-02-16 11:00:40 --> Hooks Class Initialized
DEBUG - 2018-02-16 11:00:40 --> UTF-8 Support Enabled
INFO - 2018-02-16 11:00:40 --> Utf8 Class Initialized
INFO - 2018-02-16 11:00:40 --> URI Class Initialized
INFO - 2018-02-16 11:00:40 --> Router Class Initialized
INFO - 2018-02-16 11:00:40 --> Output Class Initialized
INFO - 2018-02-16 11:00:40 --> Security Class Initialized
DEBUG - 2018-02-16 11:00:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-16 11:00:40 --> Input Class Initialized
INFO - 2018-02-16 11:00:40 --> Language Class Initialized
INFO - 2018-02-16 11:00:40 --> Loader Class Initialized
INFO - 2018-02-16 11:00:40 --> Helper loaded: url_helper
INFO - 2018-02-16 11:00:40 --> Helper loaded: file_helper
INFO - 2018-02-16 11:00:40 --> Helper loaded: email_helper
INFO - 2018-02-16 11:00:40 --> Helper loaded: common_helper
INFO - 2018-02-16 11:00:40 --> Database Driver Class Initialized
DEBUG - 2018-02-16 11:00:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-16 11:00:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-16 11:00:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-16 11:00:40 --> Pagination Class Initialized
INFO - 2018-02-16 11:00:40 --> Helper loaded: form_helper
INFO - 2018-02-16 11:00:40 --> Form Validation Class Initialized
INFO - 2018-02-16 11:00:40 --> Model Class Initialized
INFO - 2018-02-16 11:00:40 --> Controller Class Initialized
INFO - 2018-02-16 11:00:40 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-16 11:00:40 --> Model Class Initialized
INFO - 2018-02-16 11:00:40 --> Model Class Initialized
INFO - 2018-02-16 11:00:40 --> Model Class Initialized
INFO - 2018-02-16 11:00:41 --> Config Class Initialized
INFO - 2018-02-16 11:00:41 --> Hooks Class Initialized
DEBUG - 2018-02-16 11:00:41 --> UTF-8 Support Enabled
INFO - 2018-02-16 11:00:41 --> Utf8 Class Initialized
INFO - 2018-02-16 11:00:41 --> URI Class Initialized
INFO - 2018-02-16 11:00:41 --> Router Class Initialized
INFO - 2018-02-16 11:00:41 --> Output Class Initialized
INFO - 2018-02-16 11:00:41 --> Security Class Initialized
DEBUG - 2018-02-16 11:00:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-16 11:00:41 --> Input Class Initialized
INFO - 2018-02-16 11:00:41 --> Language Class Initialized
INFO - 2018-02-16 11:00:41 --> Loader Class Initialized
INFO - 2018-02-16 11:00:41 --> Helper loaded: url_helper
INFO - 2018-02-16 11:00:41 --> Helper loaded: file_helper
INFO - 2018-02-16 11:00:41 --> Helper loaded: email_helper
INFO - 2018-02-16 11:00:41 --> Helper loaded: common_helper
INFO - 2018-02-16 11:00:41 --> Database Driver Class Initialized
DEBUG - 2018-02-16 11:00:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-16 11:00:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-16 11:00:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-16 11:00:41 --> Pagination Class Initialized
INFO - 2018-02-16 11:00:41 --> Helper loaded: form_helper
INFO - 2018-02-16 11:00:41 --> Form Validation Class Initialized
INFO - 2018-02-16 11:00:41 --> Model Class Initialized
INFO - 2018-02-16 11:00:41 --> Controller Class Initialized
INFO - 2018-02-16 11:00:41 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-16 11:00:41 --> Model Class Initialized
INFO - 2018-02-16 11:00:41 --> Model Class Initialized
INFO - 2018-02-16 11:00:41 --> Model Class Initialized
INFO - 2018-02-16 11:00:42 --> Config Class Initialized
INFO - 2018-02-16 11:00:42 --> Hooks Class Initialized
DEBUG - 2018-02-16 11:00:42 --> UTF-8 Support Enabled
INFO - 2018-02-16 11:00:42 --> Utf8 Class Initialized
INFO - 2018-02-16 11:00:42 --> URI Class Initialized
INFO - 2018-02-16 11:00:42 --> Router Class Initialized
INFO - 2018-02-16 11:00:42 --> Output Class Initialized
INFO - 2018-02-16 11:00:42 --> Security Class Initialized
DEBUG - 2018-02-16 11:00:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-16 11:00:42 --> Input Class Initialized
INFO - 2018-02-16 11:00:42 --> Language Class Initialized
INFO - 2018-02-16 11:00:42 --> Loader Class Initialized
INFO - 2018-02-16 11:00:42 --> Helper loaded: url_helper
INFO - 2018-02-16 11:00:42 --> Helper loaded: file_helper
INFO - 2018-02-16 11:00:42 --> Helper loaded: email_helper
INFO - 2018-02-16 11:00:42 --> Helper loaded: common_helper
INFO - 2018-02-16 11:00:42 --> Database Driver Class Initialized
DEBUG - 2018-02-16 11:00:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-16 11:00:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-16 11:00:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-16 11:00:42 --> Pagination Class Initialized
INFO - 2018-02-16 11:00:42 --> Helper loaded: form_helper
INFO - 2018-02-16 11:00:42 --> Form Validation Class Initialized
INFO - 2018-02-16 11:00:42 --> Model Class Initialized
INFO - 2018-02-16 11:00:42 --> Controller Class Initialized
INFO - 2018-02-16 11:00:42 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-16 11:00:42 --> Model Class Initialized
INFO - 2018-02-16 11:00:42 --> Model Class Initialized
INFO - 2018-02-16 11:00:42 --> Model Class Initialized
INFO - 2018-02-16 11:00:46 --> Config Class Initialized
INFO - 2018-02-16 11:00:46 --> Hooks Class Initialized
DEBUG - 2018-02-16 11:00:46 --> UTF-8 Support Enabled
INFO - 2018-02-16 11:00:46 --> Utf8 Class Initialized
INFO - 2018-02-16 11:00:46 --> URI Class Initialized
INFO - 2018-02-16 11:00:46 --> Router Class Initialized
INFO - 2018-02-16 11:00:46 --> Output Class Initialized
INFO - 2018-02-16 11:00:46 --> Security Class Initialized
DEBUG - 2018-02-16 11:00:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-16 11:00:46 --> Input Class Initialized
INFO - 2018-02-16 11:00:46 --> Language Class Initialized
INFO - 2018-02-16 11:00:46 --> Loader Class Initialized
INFO - 2018-02-16 11:00:46 --> Helper loaded: url_helper
INFO - 2018-02-16 11:00:46 --> Helper loaded: file_helper
INFO - 2018-02-16 11:00:46 --> Helper loaded: email_helper
INFO - 2018-02-16 11:00:46 --> Helper loaded: common_helper
INFO - 2018-02-16 11:00:46 --> Database Driver Class Initialized
DEBUG - 2018-02-16 11:00:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-16 11:00:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-16 11:00:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-16 11:00:46 --> Pagination Class Initialized
INFO - 2018-02-16 11:00:46 --> Helper loaded: form_helper
INFO - 2018-02-16 11:00:46 --> Form Validation Class Initialized
INFO - 2018-02-16 11:00:46 --> Model Class Initialized
INFO - 2018-02-16 11:00:46 --> Controller Class Initialized
INFO - 2018-02-16 11:00:46 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-16 11:00:46 --> Model Class Initialized
INFO - 2018-02-16 11:00:46 --> Model Class Initialized
INFO - 2018-02-16 11:00:46 --> Model Class Initialized
INFO - 2018-02-16 11:00:47 --> Config Class Initialized
INFO - 2018-02-16 11:00:47 --> Hooks Class Initialized
DEBUG - 2018-02-16 11:00:47 --> UTF-8 Support Enabled
INFO - 2018-02-16 11:00:47 --> Utf8 Class Initialized
INFO - 2018-02-16 11:00:47 --> URI Class Initialized
INFO - 2018-02-16 11:00:47 --> Router Class Initialized
INFO - 2018-02-16 11:00:47 --> Output Class Initialized
INFO - 2018-02-16 11:00:47 --> Security Class Initialized
DEBUG - 2018-02-16 11:00:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-16 11:00:47 --> Input Class Initialized
INFO - 2018-02-16 11:00:47 --> Language Class Initialized
INFO - 2018-02-16 11:00:47 --> Loader Class Initialized
INFO - 2018-02-16 11:00:47 --> Helper loaded: url_helper
INFO - 2018-02-16 11:00:47 --> Helper loaded: file_helper
INFO - 2018-02-16 11:00:47 --> Helper loaded: email_helper
INFO - 2018-02-16 11:00:47 --> Helper loaded: common_helper
INFO - 2018-02-16 11:00:47 --> Database Driver Class Initialized
DEBUG - 2018-02-16 11:00:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-16 11:00:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-16 11:00:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-16 11:00:47 --> Pagination Class Initialized
INFO - 2018-02-16 11:00:47 --> Helper loaded: form_helper
INFO - 2018-02-16 11:00:47 --> Form Validation Class Initialized
INFO - 2018-02-16 11:00:47 --> Model Class Initialized
INFO - 2018-02-16 11:00:47 --> Controller Class Initialized
INFO - 2018-02-16 11:00:47 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-16 11:00:47 --> Model Class Initialized
INFO - 2018-02-16 11:00:47 --> Model Class Initialized
INFO - 2018-02-16 11:00:47 --> Model Class Initialized
INFO - 2018-02-16 11:00:48 --> Config Class Initialized
INFO - 2018-02-16 11:00:48 --> Hooks Class Initialized
DEBUG - 2018-02-16 11:00:48 --> UTF-8 Support Enabled
INFO - 2018-02-16 11:00:48 --> Utf8 Class Initialized
INFO - 2018-02-16 11:00:48 --> URI Class Initialized
INFO - 2018-02-16 11:00:48 --> Router Class Initialized
INFO - 2018-02-16 11:00:48 --> Output Class Initialized
INFO - 2018-02-16 11:00:48 --> Security Class Initialized
DEBUG - 2018-02-16 11:00:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-16 11:00:48 --> Input Class Initialized
INFO - 2018-02-16 11:00:48 --> Language Class Initialized
INFO - 2018-02-16 11:00:48 --> Loader Class Initialized
INFO - 2018-02-16 11:00:48 --> Helper loaded: url_helper
INFO - 2018-02-16 11:00:48 --> Helper loaded: file_helper
INFO - 2018-02-16 11:00:48 --> Helper loaded: email_helper
INFO - 2018-02-16 11:00:48 --> Helper loaded: common_helper
INFO - 2018-02-16 11:00:48 --> Database Driver Class Initialized
DEBUG - 2018-02-16 11:00:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-16 11:00:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-16 11:00:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-16 11:00:48 --> Pagination Class Initialized
INFO - 2018-02-16 11:00:48 --> Helper loaded: form_helper
INFO - 2018-02-16 11:00:48 --> Form Validation Class Initialized
INFO - 2018-02-16 11:00:48 --> Model Class Initialized
INFO - 2018-02-16 11:00:48 --> Controller Class Initialized
INFO - 2018-02-16 11:00:48 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-16 11:00:48 --> Model Class Initialized
INFO - 2018-02-16 11:00:48 --> Model Class Initialized
INFO - 2018-02-16 11:00:48 --> Model Class Initialized
INFO - 2018-02-16 11:00:49 --> Config Class Initialized
INFO - 2018-02-16 11:00:49 --> Hooks Class Initialized
DEBUG - 2018-02-16 11:00:49 --> UTF-8 Support Enabled
INFO - 2018-02-16 11:00:49 --> Utf8 Class Initialized
INFO - 2018-02-16 11:00:49 --> URI Class Initialized
INFO - 2018-02-16 11:00:49 --> Router Class Initialized
INFO - 2018-02-16 11:00:49 --> Output Class Initialized
INFO - 2018-02-16 11:00:49 --> Security Class Initialized
DEBUG - 2018-02-16 11:00:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-16 11:00:49 --> Input Class Initialized
INFO - 2018-02-16 11:00:49 --> Language Class Initialized
INFO - 2018-02-16 11:00:49 --> Loader Class Initialized
INFO - 2018-02-16 11:00:49 --> Helper loaded: url_helper
INFO - 2018-02-16 11:00:49 --> Helper loaded: file_helper
INFO - 2018-02-16 11:00:49 --> Helper loaded: email_helper
INFO - 2018-02-16 11:00:49 --> Helper loaded: common_helper
INFO - 2018-02-16 11:00:49 --> Database Driver Class Initialized
DEBUG - 2018-02-16 11:00:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-16 11:00:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-16 11:00:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-16 11:00:49 --> Pagination Class Initialized
INFO - 2018-02-16 11:00:49 --> Helper loaded: form_helper
INFO - 2018-02-16 11:00:49 --> Form Validation Class Initialized
INFO - 2018-02-16 11:00:49 --> Model Class Initialized
INFO - 2018-02-16 11:00:49 --> Controller Class Initialized
INFO - 2018-02-16 11:00:49 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-16 11:00:49 --> Model Class Initialized
INFO - 2018-02-16 11:00:49 --> Model Class Initialized
INFO - 2018-02-16 11:00:49 --> Model Class Initialized
INFO - 2018-02-16 11:00:50 --> Config Class Initialized
INFO - 2018-02-16 11:00:50 --> Hooks Class Initialized
DEBUG - 2018-02-16 11:00:50 --> UTF-8 Support Enabled
INFO - 2018-02-16 11:00:50 --> Utf8 Class Initialized
INFO - 2018-02-16 11:00:50 --> URI Class Initialized
INFO - 2018-02-16 11:00:50 --> Router Class Initialized
INFO - 2018-02-16 11:00:50 --> Output Class Initialized
INFO - 2018-02-16 11:00:50 --> Security Class Initialized
DEBUG - 2018-02-16 11:00:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-16 11:00:50 --> Input Class Initialized
INFO - 2018-02-16 11:00:50 --> Language Class Initialized
INFO - 2018-02-16 11:00:50 --> Loader Class Initialized
INFO - 2018-02-16 11:00:50 --> Helper loaded: url_helper
INFO - 2018-02-16 11:00:50 --> Helper loaded: file_helper
INFO - 2018-02-16 11:00:50 --> Helper loaded: email_helper
INFO - 2018-02-16 11:00:50 --> Helper loaded: common_helper
INFO - 2018-02-16 11:00:50 --> Database Driver Class Initialized
DEBUG - 2018-02-16 11:00:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-16 11:00:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-16 11:00:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-16 11:00:50 --> Pagination Class Initialized
INFO - 2018-02-16 11:00:50 --> Helper loaded: form_helper
INFO - 2018-02-16 11:00:50 --> Form Validation Class Initialized
INFO - 2018-02-16 11:00:50 --> Model Class Initialized
INFO - 2018-02-16 11:00:50 --> Controller Class Initialized
INFO - 2018-02-16 11:00:50 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-16 11:00:50 --> Model Class Initialized
INFO - 2018-02-16 11:00:50 --> Model Class Initialized
INFO - 2018-02-16 11:00:50 --> Model Class Initialized
INFO - 2018-02-16 11:00:50 --> Config Class Initialized
INFO - 2018-02-16 11:00:50 --> Hooks Class Initialized
DEBUG - 2018-02-16 11:00:50 --> UTF-8 Support Enabled
INFO - 2018-02-16 11:00:50 --> Utf8 Class Initialized
INFO - 2018-02-16 11:00:50 --> URI Class Initialized
INFO - 2018-02-16 11:00:50 --> Router Class Initialized
INFO - 2018-02-16 11:00:50 --> Output Class Initialized
INFO - 2018-02-16 11:00:50 --> Security Class Initialized
DEBUG - 2018-02-16 11:00:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-16 11:00:50 --> Input Class Initialized
INFO - 2018-02-16 11:00:50 --> Language Class Initialized
INFO - 2018-02-16 11:00:50 --> Loader Class Initialized
INFO - 2018-02-16 11:00:50 --> Helper loaded: url_helper
INFO - 2018-02-16 11:00:50 --> Helper loaded: file_helper
INFO - 2018-02-16 11:00:50 --> Helper loaded: email_helper
INFO - 2018-02-16 11:00:50 --> Helper loaded: common_helper
INFO - 2018-02-16 11:00:50 --> Database Driver Class Initialized
DEBUG - 2018-02-16 11:00:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-16 11:00:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-16 11:00:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-16 11:00:50 --> Pagination Class Initialized
INFO - 2018-02-16 11:00:50 --> Helper loaded: form_helper
INFO - 2018-02-16 11:00:50 --> Form Validation Class Initialized
INFO - 2018-02-16 11:00:50 --> Model Class Initialized
INFO - 2018-02-16 11:00:50 --> Controller Class Initialized
INFO - 2018-02-16 11:00:50 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-16 11:00:50 --> Model Class Initialized
INFO - 2018-02-16 11:00:50 --> Model Class Initialized
INFO - 2018-02-16 11:00:50 --> Model Class Initialized
INFO - 2018-02-16 11:00:51 --> Config Class Initialized
INFO - 2018-02-16 11:00:51 --> Hooks Class Initialized
DEBUG - 2018-02-16 11:00:51 --> UTF-8 Support Enabled
INFO - 2018-02-16 11:00:51 --> Utf8 Class Initialized
INFO - 2018-02-16 11:00:51 --> URI Class Initialized
INFO - 2018-02-16 11:00:51 --> Router Class Initialized
INFO - 2018-02-16 11:00:51 --> Output Class Initialized
INFO - 2018-02-16 11:00:51 --> Security Class Initialized
DEBUG - 2018-02-16 11:00:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-16 11:00:51 --> Input Class Initialized
INFO - 2018-02-16 11:00:51 --> Language Class Initialized
INFO - 2018-02-16 11:00:51 --> Loader Class Initialized
INFO - 2018-02-16 11:00:51 --> Helper loaded: url_helper
INFO - 2018-02-16 11:00:51 --> Helper loaded: file_helper
INFO - 2018-02-16 11:00:51 --> Helper loaded: email_helper
INFO - 2018-02-16 11:00:51 --> Helper loaded: common_helper
INFO - 2018-02-16 11:00:51 --> Database Driver Class Initialized
DEBUG - 2018-02-16 11:00:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-16 11:00:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-16 11:00:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-16 11:00:51 --> Pagination Class Initialized
INFO - 2018-02-16 11:00:51 --> Helper loaded: form_helper
INFO - 2018-02-16 11:00:51 --> Form Validation Class Initialized
INFO - 2018-02-16 11:00:51 --> Model Class Initialized
INFO - 2018-02-16 11:00:51 --> Controller Class Initialized
INFO - 2018-02-16 11:00:51 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-16 11:00:51 --> Model Class Initialized
INFO - 2018-02-16 11:00:51 --> Model Class Initialized
INFO - 2018-02-16 11:00:51 --> Model Class Initialized
INFO - 2018-02-16 11:00:51 --> Config Class Initialized
INFO - 2018-02-16 11:00:51 --> Hooks Class Initialized
DEBUG - 2018-02-16 11:00:51 --> UTF-8 Support Enabled
INFO - 2018-02-16 11:00:51 --> Utf8 Class Initialized
INFO - 2018-02-16 11:00:51 --> URI Class Initialized
INFO - 2018-02-16 11:00:51 --> Router Class Initialized
INFO - 2018-02-16 11:00:51 --> Output Class Initialized
INFO - 2018-02-16 11:00:51 --> Security Class Initialized
DEBUG - 2018-02-16 11:00:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-16 11:00:51 --> Input Class Initialized
INFO - 2018-02-16 11:00:51 --> Language Class Initialized
INFO - 2018-02-16 11:00:51 --> Loader Class Initialized
INFO - 2018-02-16 11:00:51 --> Helper loaded: url_helper
INFO - 2018-02-16 11:00:51 --> Helper loaded: file_helper
INFO - 2018-02-16 11:00:51 --> Helper loaded: email_helper
INFO - 2018-02-16 11:00:51 --> Helper loaded: common_helper
INFO - 2018-02-16 11:00:51 --> Database Driver Class Initialized
DEBUG - 2018-02-16 11:00:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-16 11:00:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-16 11:00:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-16 11:00:51 --> Pagination Class Initialized
INFO - 2018-02-16 11:00:51 --> Helper loaded: form_helper
INFO - 2018-02-16 11:00:51 --> Form Validation Class Initialized
INFO - 2018-02-16 11:00:51 --> Model Class Initialized
INFO - 2018-02-16 11:00:51 --> Controller Class Initialized
INFO - 2018-02-16 11:00:51 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-16 11:00:51 --> Model Class Initialized
INFO - 2018-02-16 11:00:51 --> Model Class Initialized
INFO - 2018-02-16 11:00:51 --> Model Class Initialized
INFO - 2018-02-16 11:00:55 --> Config Class Initialized
INFO - 2018-02-16 11:00:55 --> Hooks Class Initialized
DEBUG - 2018-02-16 11:00:55 --> UTF-8 Support Enabled
INFO - 2018-02-16 11:00:55 --> Utf8 Class Initialized
INFO - 2018-02-16 11:00:55 --> URI Class Initialized
INFO - 2018-02-16 11:00:55 --> Router Class Initialized
INFO - 2018-02-16 11:00:55 --> Output Class Initialized
INFO - 2018-02-16 11:00:55 --> Security Class Initialized
DEBUG - 2018-02-16 11:00:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-16 11:00:55 --> Input Class Initialized
INFO - 2018-02-16 11:00:55 --> Language Class Initialized
INFO - 2018-02-16 11:00:55 --> Loader Class Initialized
INFO - 2018-02-16 11:00:55 --> Helper loaded: url_helper
INFO - 2018-02-16 11:00:55 --> Helper loaded: file_helper
INFO - 2018-02-16 11:00:55 --> Helper loaded: email_helper
INFO - 2018-02-16 11:00:55 --> Helper loaded: common_helper
INFO - 2018-02-16 11:00:55 --> Database Driver Class Initialized
DEBUG - 2018-02-16 11:00:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-16 11:00:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-16 11:00:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-16 11:00:55 --> Pagination Class Initialized
INFO - 2018-02-16 11:00:55 --> Helper loaded: form_helper
INFO - 2018-02-16 11:00:55 --> Form Validation Class Initialized
INFO - 2018-02-16 11:00:55 --> Model Class Initialized
INFO - 2018-02-16 11:00:55 --> Controller Class Initialized
INFO - 2018-02-16 11:00:55 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-16 11:00:55 --> Model Class Initialized
INFO - 2018-02-16 11:00:55 --> Model Class Initialized
INFO - 2018-02-16 11:00:55 --> Model Class Initialized
INFO - 2018-02-16 11:00:55 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-16 11:00:55 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-16 11:00:55 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-16 11:00:55 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-16 11:00:55 --> File loaded: /var/www/html/project/radio/application/views/tracks/index.php
INFO - 2018-02-16 11:00:55 --> Final output sent to browser
DEBUG - 2018-02-16 11:00:55 --> Total execution time: 0.0052
INFO - 2018-02-16 11:00:55 --> Config Class Initialized
INFO - 2018-02-16 11:00:55 --> Hooks Class Initialized
DEBUG - 2018-02-16 11:00:55 --> UTF-8 Support Enabled
INFO - 2018-02-16 11:00:55 --> Utf8 Class Initialized
INFO - 2018-02-16 11:00:55 --> URI Class Initialized
INFO - 2018-02-16 11:00:55 --> Router Class Initialized
INFO - 2018-02-16 11:00:55 --> Output Class Initialized
INFO - 2018-02-16 11:00:55 --> Security Class Initialized
DEBUG - 2018-02-16 11:00:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-16 11:00:55 --> Input Class Initialized
INFO - 2018-02-16 11:00:55 --> Language Class Initialized
INFO - 2018-02-16 11:00:55 --> Loader Class Initialized
INFO - 2018-02-16 11:00:55 --> Helper loaded: url_helper
INFO - 2018-02-16 11:00:55 --> Helper loaded: file_helper
INFO - 2018-02-16 11:00:55 --> Helper loaded: email_helper
INFO - 2018-02-16 11:00:55 --> Helper loaded: common_helper
INFO - 2018-02-16 11:00:55 --> Database Driver Class Initialized
DEBUG - 2018-02-16 11:00:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-16 11:00:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-16 11:00:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-16 11:00:55 --> Pagination Class Initialized
INFO - 2018-02-16 11:00:55 --> Helper loaded: form_helper
INFO - 2018-02-16 11:00:55 --> Form Validation Class Initialized
INFO - 2018-02-16 11:00:55 --> Model Class Initialized
INFO - 2018-02-16 11:00:55 --> Controller Class Initialized
INFO - 2018-02-16 11:00:55 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-16 11:00:55 --> Model Class Initialized
INFO - 2018-02-16 11:00:55 --> Model Class Initialized
INFO - 2018-02-16 11:00:55 --> Model Class Initialized
INFO - 2018-02-16 11:01:20 --> Config Class Initialized
INFO - 2018-02-16 11:01:20 --> Hooks Class Initialized
DEBUG - 2018-02-16 11:01:20 --> UTF-8 Support Enabled
INFO - 2018-02-16 11:01:20 --> Utf8 Class Initialized
INFO - 2018-02-16 11:01:20 --> URI Class Initialized
INFO - 2018-02-16 11:01:20 --> Router Class Initialized
INFO - 2018-02-16 11:01:20 --> Output Class Initialized
INFO - 2018-02-16 11:01:20 --> Security Class Initialized
DEBUG - 2018-02-16 11:01:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-16 11:01:20 --> Input Class Initialized
INFO - 2018-02-16 11:01:20 --> Language Class Initialized
INFO - 2018-02-16 11:01:20 --> Loader Class Initialized
INFO - 2018-02-16 11:01:20 --> Helper loaded: url_helper
INFO - 2018-02-16 11:01:20 --> Helper loaded: file_helper
INFO - 2018-02-16 11:01:20 --> Helper loaded: email_helper
INFO - 2018-02-16 11:01:20 --> Helper loaded: common_helper
INFO - 2018-02-16 11:01:20 --> Database Driver Class Initialized
DEBUG - 2018-02-16 11:01:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-16 11:01:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-16 11:01:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-16 11:01:20 --> Pagination Class Initialized
INFO - 2018-02-16 11:01:20 --> Helper loaded: form_helper
INFO - 2018-02-16 11:01:20 --> Form Validation Class Initialized
INFO - 2018-02-16 11:01:20 --> Model Class Initialized
INFO - 2018-02-16 11:01:20 --> Controller Class Initialized
INFO - 2018-02-16 11:01:20 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-16 11:01:20 --> Model Class Initialized
INFO - 2018-02-16 11:01:20 --> Model Class Initialized
INFO - 2018-02-16 11:01:20 --> Model Class Initialized
INFO - 2018-02-16 11:01:20 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-16 11:01:20 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-16 11:01:20 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-16 11:01:20 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-16 11:01:20 --> File loaded: /var/www/html/project/radio/application/views/tracks/add_edit.php
INFO - 2018-02-16 11:01:20 --> Final output sent to browser
DEBUG - 2018-02-16 11:01:20 --> Total execution time: 0.0059
INFO - 2018-02-16 11:01:23 --> Config Class Initialized
INFO - 2018-02-16 11:01:23 --> Hooks Class Initialized
DEBUG - 2018-02-16 11:01:23 --> UTF-8 Support Enabled
INFO - 2018-02-16 11:01:23 --> Utf8 Class Initialized
INFO - 2018-02-16 11:01:23 --> URI Class Initialized
INFO - 2018-02-16 11:01:23 --> Router Class Initialized
INFO - 2018-02-16 11:01:23 --> Output Class Initialized
INFO - 2018-02-16 11:01:23 --> Security Class Initialized
DEBUG - 2018-02-16 11:01:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-16 11:01:23 --> Input Class Initialized
INFO - 2018-02-16 11:01:23 --> Language Class Initialized
INFO - 2018-02-16 11:01:23 --> Loader Class Initialized
INFO - 2018-02-16 11:01:23 --> Helper loaded: url_helper
INFO - 2018-02-16 11:01:23 --> Helper loaded: file_helper
INFO - 2018-02-16 11:01:23 --> Helper loaded: email_helper
INFO - 2018-02-16 11:01:23 --> Helper loaded: common_helper
INFO - 2018-02-16 11:01:23 --> Database Driver Class Initialized
DEBUG - 2018-02-16 11:01:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-16 11:01:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-16 11:01:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-16 11:01:23 --> Pagination Class Initialized
INFO - 2018-02-16 11:01:23 --> Helper loaded: form_helper
INFO - 2018-02-16 11:01:23 --> Form Validation Class Initialized
INFO - 2018-02-16 11:01:23 --> Model Class Initialized
INFO - 2018-02-16 11:01:23 --> Controller Class Initialized
INFO - 2018-02-16 11:01:23 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-16 11:01:23 --> Model Class Initialized
INFO - 2018-02-16 11:01:23 --> Model Class Initialized
INFO - 2018-02-16 11:01:23 --> Model Class Initialized
INFO - 2018-02-16 11:01:25 --> Config Class Initialized
INFO - 2018-02-16 11:01:25 --> Hooks Class Initialized
DEBUG - 2018-02-16 11:01:25 --> UTF-8 Support Enabled
INFO - 2018-02-16 11:01:25 --> Utf8 Class Initialized
INFO - 2018-02-16 11:01:25 --> URI Class Initialized
INFO - 2018-02-16 11:01:25 --> Router Class Initialized
INFO - 2018-02-16 11:01:25 --> Output Class Initialized
INFO - 2018-02-16 11:01:25 --> Security Class Initialized
DEBUG - 2018-02-16 11:01:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-16 11:01:25 --> Input Class Initialized
INFO - 2018-02-16 11:01:25 --> Language Class Initialized
INFO - 2018-02-16 11:01:25 --> Loader Class Initialized
INFO - 2018-02-16 11:01:25 --> Helper loaded: url_helper
INFO - 2018-02-16 11:01:25 --> Helper loaded: file_helper
INFO - 2018-02-16 11:01:25 --> Helper loaded: email_helper
INFO - 2018-02-16 11:01:25 --> Helper loaded: common_helper
INFO - 2018-02-16 11:01:25 --> Database Driver Class Initialized
DEBUG - 2018-02-16 11:01:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-16 11:01:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-16 11:01:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-16 11:01:25 --> Pagination Class Initialized
INFO - 2018-02-16 11:01:25 --> Helper loaded: form_helper
INFO - 2018-02-16 11:01:25 --> Form Validation Class Initialized
INFO - 2018-02-16 11:01:25 --> Model Class Initialized
INFO - 2018-02-16 11:01:25 --> Controller Class Initialized
INFO - 2018-02-16 11:01:25 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-16 11:01:25 --> Model Class Initialized
INFO - 2018-02-16 11:01:25 --> Model Class Initialized
INFO - 2018-02-16 11:01:25 --> Model Class Initialized
INFO - 2018-02-16 11:04:47 --> Config Class Initialized
INFO - 2018-02-16 11:04:47 --> Hooks Class Initialized
DEBUG - 2018-02-16 11:04:47 --> UTF-8 Support Enabled
INFO - 2018-02-16 11:04:47 --> Utf8 Class Initialized
INFO - 2018-02-16 11:04:47 --> URI Class Initialized
INFO - 2018-02-16 11:04:47 --> Router Class Initialized
INFO - 2018-02-16 11:04:47 --> Output Class Initialized
INFO - 2018-02-16 11:04:47 --> Security Class Initialized
DEBUG - 2018-02-16 11:04:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-16 11:04:47 --> Input Class Initialized
INFO - 2018-02-16 11:04:47 --> Language Class Initialized
INFO - 2018-02-16 11:04:47 --> Loader Class Initialized
INFO - 2018-02-16 11:04:47 --> Helper loaded: url_helper
INFO - 2018-02-16 11:04:47 --> Helper loaded: file_helper
INFO - 2018-02-16 11:04:47 --> Helper loaded: email_helper
INFO - 2018-02-16 11:04:47 --> Helper loaded: common_helper
INFO - 2018-02-16 11:04:47 --> Database Driver Class Initialized
DEBUG - 2018-02-16 11:04:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-16 11:04:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-16 11:04:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-16 11:04:47 --> Pagination Class Initialized
INFO - 2018-02-16 11:04:47 --> Helper loaded: form_helper
INFO - 2018-02-16 11:04:47 --> Form Validation Class Initialized
INFO - 2018-02-16 11:04:47 --> Model Class Initialized
INFO - 2018-02-16 11:04:47 --> Controller Class Initialized
INFO - 2018-02-16 11:04:47 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-16 11:04:47 --> Model Class Initialized
INFO - 2018-02-16 11:04:47 --> Model Class Initialized
INFO - 2018-02-16 11:04:47 --> Model Class Initialized
INFO - 2018-02-16 11:04:49 --> Config Class Initialized
INFO - 2018-02-16 11:04:49 --> Hooks Class Initialized
DEBUG - 2018-02-16 11:04:49 --> UTF-8 Support Enabled
INFO - 2018-02-16 11:04:49 --> Utf8 Class Initialized
INFO - 2018-02-16 11:04:49 --> URI Class Initialized
INFO - 2018-02-16 11:04:49 --> Router Class Initialized
INFO - 2018-02-16 11:04:49 --> Output Class Initialized
INFO - 2018-02-16 11:04:49 --> Security Class Initialized
DEBUG - 2018-02-16 11:04:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-16 11:04:49 --> Input Class Initialized
INFO - 2018-02-16 11:04:49 --> Language Class Initialized
INFO - 2018-02-16 11:04:49 --> Loader Class Initialized
INFO - 2018-02-16 11:04:49 --> Helper loaded: url_helper
INFO - 2018-02-16 11:04:49 --> Helper loaded: file_helper
INFO - 2018-02-16 11:04:49 --> Helper loaded: email_helper
INFO - 2018-02-16 11:04:49 --> Helper loaded: common_helper
INFO - 2018-02-16 11:04:49 --> Database Driver Class Initialized
DEBUG - 2018-02-16 11:04:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-16 11:04:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-16 11:04:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-16 11:04:49 --> Pagination Class Initialized
INFO - 2018-02-16 11:04:49 --> Helper loaded: form_helper
INFO - 2018-02-16 11:04:49 --> Form Validation Class Initialized
INFO - 2018-02-16 11:04:49 --> Model Class Initialized
INFO - 2018-02-16 11:04:49 --> Controller Class Initialized
INFO - 2018-02-16 11:04:49 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-16 11:04:49 --> Model Class Initialized
INFO - 2018-02-16 11:04:49 --> Model Class Initialized
INFO - 2018-02-16 11:04:49 --> Model Class Initialized
INFO - 2018-02-16 11:04:51 --> Config Class Initialized
INFO - 2018-02-16 11:04:51 --> Hooks Class Initialized
DEBUG - 2018-02-16 11:04:51 --> UTF-8 Support Enabled
INFO - 2018-02-16 11:04:51 --> Utf8 Class Initialized
INFO - 2018-02-16 11:04:51 --> URI Class Initialized
INFO - 2018-02-16 11:04:51 --> Router Class Initialized
INFO - 2018-02-16 11:04:51 --> Output Class Initialized
INFO - 2018-02-16 11:04:51 --> Security Class Initialized
DEBUG - 2018-02-16 11:04:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-16 11:04:51 --> Input Class Initialized
INFO - 2018-02-16 11:04:51 --> Language Class Initialized
INFO - 2018-02-16 11:04:51 --> Loader Class Initialized
INFO - 2018-02-16 11:04:51 --> Helper loaded: url_helper
INFO - 2018-02-16 11:04:51 --> Helper loaded: file_helper
INFO - 2018-02-16 11:04:51 --> Helper loaded: email_helper
INFO - 2018-02-16 11:04:51 --> Helper loaded: common_helper
INFO - 2018-02-16 11:04:51 --> Database Driver Class Initialized
DEBUG - 2018-02-16 11:04:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-16 11:04:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-16 11:04:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-16 11:04:51 --> Pagination Class Initialized
INFO - 2018-02-16 11:04:51 --> Helper loaded: form_helper
INFO - 2018-02-16 11:04:51 --> Form Validation Class Initialized
INFO - 2018-02-16 11:04:51 --> Model Class Initialized
INFO - 2018-02-16 11:04:51 --> Controller Class Initialized
INFO - 2018-02-16 11:04:51 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-16 11:04:51 --> Model Class Initialized
INFO - 2018-02-16 11:04:51 --> Model Class Initialized
INFO - 2018-02-16 11:04:51 --> Model Class Initialized
INFO - 2018-02-16 11:04:53 --> Config Class Initialized
INFO - 2018-02-16 11:04:53 --> Hooks Class Initialized
DEBUG - 2018-02-16 11:04:53 --> UTF-8 Support Enabled
INFO - 2018-02-16 11:04:53 --> Utf8 Class Initialized
INFO - 2018-02-16 11:04:53 --> URI Class Initialized
INFO - 2018-02-16 11:04:53 --> Router Class Initialized
INFO - 2018-02-16 11:04:53 --> Output Class Initialized
INFO - 2018-02-16 11:04:53 --> Security Class Initialized
DEBUG - 2018-02-16 11:04:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-16 11:04:53 --> Input Class Initialized
INFO - 2018-02-16 11:04:53 --> Language Class Initialized
INFO - 2018-02-16 11:04:53 --> Loader Class Initialized
INFO - 2018-02-16 11:04:53 --> Helper loaded: url_helper
INFO - 2018-02-16 11:04:53 --> Helper loaded: file_helper
INFO - 2018-02-16 11:04:53 --> Helper loaded: email_helper
INFO - 2018-02-16 11:04:53 --> Helper loaded: common_helper
INFO - 2018-02-16 11:04:53 --> Database Driver Class Initialized
DEBUG - 2018-02-16 11:04:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-16 11:04:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-16 11:04:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-16 11:04:53 --> Pagination Class Initialized
INFO - 2018-02-16 11:04:53 --> Helper loaded: form_helper
INFO - 2018-02-16 11:04:53 --> Form Validation Class Initialized
INFO - 2018-02-16 11:04:53 --> Model Class Initialized
INFO - 2018-02-16 11:04:53 --> Controller Class Initialized
INFO - 2018-02-16 11:04:53 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-16 11:04:53 --> Model Class Initialized
INFO - 2018-02-16 11:04:53 --> Model Class Initialized
INFO - 2018-02-16 11:04:53 --> Model Class Initialized
INFO - 2018-02-16 11:04:56 --> Config Class Initialized
INFO - 2018-02-16 11:04:56 --> Hooks Class Initialized
DEBUG - 2018-02-16 11:04:56 --> UTF-8 Support Enabled
INFO - 2018-02-16 11:04:56 --> Utf8 Class Initialized
INFO - 2018-02-16 11:04:56 --> URI Class Initialized
INFO - 2018-02-16 11:04:56 --> Router Class Initialized
INFO - 2018-02-16 11:04:56 --> Output Class Initialized
INFO - 2018-02-16 11:04:56 --> Security Class Initialized
DEBUG - 2018-02-16 11:04:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-16 11:04:56 --> Input Class Initialized
INFO - 2018-02-16 11:04:56 --> Language Class Initialized
INFO - 2018-02-16 11:04:56 --> Loader Class Initialized
INFO - 2018-02-16 11:04:56 --> Helper loaded: url_helper
INFO - 2018-02-16 11:04:56 --> Helper loaded: file_helper
INFO - 2018-02-16 11:04:56 --> Helper loaded: email_helper
INFO - 2018-02-16 11:04:56 --> Helper loaded: common_helper
INFO - 2018-02-16 11:04:56 --> Database Driver Class Initialized
DEBUG - 2018-02-16 11:04:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-16 11:04:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-16 11:04:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-16 11:04:56 --> Pagination Class Initialized
INFO - 2018-02-16 11:04:56 --> Helper loaded: form_helper
INFO - 2018-02-16 11:04:56 --> Form Validation Class Initialized
INFO - 2018-02-16 11:04:56 --> Model Class Initialized
INFO - 2018-02-16 11:04:56 --> Controller Class Initialized
INFO - 2018-02-16 11:04:56 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-16 11:04:56 --> Model Class Initialized
INFO - 2018-02-16 11:04:56 --> Model Class Initialized
INFO - 2018-02-16 11:04:56 --> Model Class Initialized
INFO - 2018-02-16 11:04:58 --> Config Class Initialized
INFO - 2018-02-16 11:04:58 --> Hooks Class Initialized
DEBUG - 2018-02-16 11:04:58 --> UTF-8 Support Enabled
INFO - 2018-02-16 11:04:58 --> Utf8 Class Initialized
INFO - 2018-02-16 11:04:58 --> URI Class Initialized
INFO - 2018-02-16 11:04:58 --> Router Class Initialized
INFO - 2018-02-16 11:04:58 --> Output Class Initialized
INFO - 2018-02-16 11:04:58 --> Security Class Initialized
DEBUG - 2018-02-16 11:04:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-16 11:04:58 --> Input Class Initialized
INFO - 2018-02-16 11:04:58 --> Language Class Initialized
INFO - 2018-02-16 11:04:58 --> Loader Class Initialized
INFO - 2018-02-16 11:04:58 --> Helper loaded: url_helper
INFO - 2018-02-16 11:04:58 --> Helper loaded: file_helper
INFO - 2018-02-16 11:04:58 --> Helper loaded: email_helper
INFO - 2018-02-16 11:04:58 --> Helper loaded: common_helper
INFO - 2018-02-16 11:04:58 --> Database Driver Class Initialized
DEBUG - 2018-02-16 11:04:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-16 11:04:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-16 11:04:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-16 11:04:58 --> Pagination Class Initialized
INFO - 2018-02-16 11:04:58 --> Helper loaded: form_helper
INFO - 2018-02-16 11:04:58 --> Form Validation Class Initialized
INFO - 2018-02-16 11:04:58 --> Model Class Initialized
INFO - 2018-02-16 11:04:58 --> Controller Class Initialized
INFO - 2018-02-16 11:04:58 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-16 11:04:58 --> Model Class Initialized
INFO - 2018-02-16 11:04:58 --> Model Class Initialized
INFO - 2018-02-16 11:04:58 --> Model Class Initialized
INFO - 2018-02-16 11:09:17 --> Config Class Initialized
INFO - 2018-02-16 11:09:17 --> Hooks Class Initialized
DEBUG - 2018-02-16 11:09:17 --> UTF-8 Support Enabled
INFO - 2018-02-16 11:09:17 --> Utf8 Class Initialized
INFO - 2018-02-16 11:09:17 --> URI Class Initialized
INFO - 2018-02-16 11:09:17 --> Router Class Initialized
INFO - 2018-02-16 11:09:17 --> Output Class Initialized
INFO - 2018-02-16 11:09:17 --> Security Class Initialized
DEBUG - 2018-02-16 11:09:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-16 11:09:17 --> Input Class Initialized
INFO - 2018-02-16 11:09:17 --> Language Class Initialized
INFO - 2018-02-16 11:09:17 --> Loader Class Initialized
INFO - 2018-02-16 11:09:17 --> Helper loaded: url_helper
INFO - 2018-02-16 11:09:17 --> Helper loaded: file_helper
INFO - 2018-02-16 11:09:17 --> Helper loaded: email_helper
INFO - 2018-02-16 11:09:17 --> Helper loaded: common_helper
INFO - 2018-02-16 11:09:17 --> Database Driver Class Initialized
DEBUG - 2018-02-16 11:09:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-16 11:09:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-16 11:09:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-16 11:09:17 --> Pagination Class Initialized
INFO - 2018-02-16 11:09:17 --> Helper loaded: form_helper
INFO - 2018-02-16 11:09:17 --> Form Validation Class Initialized
INFO - 2018-02-16 11:09:17 --> Model Class Initialized
INFO - 2018-02-16 11:09:17 --> Controller Class Initialized
INFO - 2018-02-16 11:09:17 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-16 11:09:17 --> Model Class Initialized
INFO - 2018-02-16 11:09:17 --> Model Class Initialized
INFO - 2018-02-16 11:09:17 --> Model Class Initialized
INFO - 2018-02-16 11:09:17 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-16 11:09:17 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-16 11:09:17 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-16 11:09:17 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-16 11:09:17 --> File loaded: /var/www/html/project/radio/application/views/tracks/index.php
INFO - 2018-02-16 11:09:17 --> Final output sent to browser
DEBUG - 2018-02-16 11:09:17 --> Total execution time: 0.0086
INFO - 2018-02-16 11:09:17 --> Config Class Initialized
INFO - 2018-02-16 11:09:17 --> Hooks Class Initialized
DEBUG - 2018-02-16 11:09:17 --> UTF-8 Support Enabled
INFO - 2018-02-16 11:09:17 --> Utf8 Class Initialized
INFO - 2018-02-16 11:09:17 --> URI Class Initialized
INFO - 2018-02-16 11:09:17 --> Router Class Initialized
INFO - 2018-02-16 11:09:17 --> Output Class Initialized
INFO - 2018-02-16 11:09:17 --> Security Class Initialized
DEBUG - 2018-02-16 11:09:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-16 11:09:17 --> Input Class Initialized
INFO - 2018-02-16 11:09:17 --> Language Class Initialized
INFO - 2018-02-16 11:09:17 --> Loader Class Initialized
INFO - 2018-02-16 11:09:17 --> Helper loaded: url_helper
INFO - 2018-02-16 11:09:17 --> Helper loaded: file_helper
INFO - 2018-02-16 11:09:17 --> Helper loaded: email_helper
INFO - 2018-02-16 11:09:17 --> Helper loaded: common_helper
INFO - 2018-02-16 11:09:17 --> Database Driver Class Initialized
DEBUG - 2018-02-16 11:09:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-16 11:09:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-16 11:09:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-16 11:09:17 --> Pagination Class Initialized
INFO - 2018-02-16 11:09:17 --> Helper loaded: form_helper
INFO - 2018-02-16 11:09:17 --> Form Validation Class Initialized
INFO - 2018-02-16 11:09:17 --> Model Class Initialized
INFO - 2018-02-16 11:09:17 --> Controller Class Initialized
INFO - 2018-02-16 11:09:17 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-16 11:09:17 --> Model Class Initialized
INFO - 2018-02-16 11:09:17 --> Model Class Initialized
INFO - 2018-02-16 11:09:17 --> Model Class Initialized
INFO - 2018-02-16 11:09:19 --> Config Class Initialized
INFO - 2018-02-16 11:09:19 --> Hooks Class Initialized
DEBUG - 2018-02-16 11:09:19 --> UTF-8 Support Enabled
INFO - 2018-02-16 11:09:19 --> Utf8 Class Initialized
INFO - 2018-02-16 11:09:19 --> URI Class Initialized
INFO - 2018-02-16 11:09:19 --> Router Class Initialized
INFO - 2018-02-16 11:09:19 --> Output Class Initialized
INFO - 2018-02-16 11:09:19 --> Security Class Initialized
DEBUG - 2018-02-16 11:09:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-16 11:09:19 --> Input Class Initialized
INFO - 2018-02-16 11:09:19 --> Language Class Initialized
INFO - 2018-02-16 11:09:19 --> Loader Class Initialized
INFO - 2018-02-16 11:09:19 --> Helper loaded: url_helper
INFO - 2018-02-16 11:09:19 --> Helper loaded: file_helper
INFO - 2018-02-16 11:09:19 --> Helper loaded: email_helper
INFO - 2018-02-16 11:09:19 --> Helper loaded: common_helper
INFO - 2018-02-16 11:09:19 --> Database Driver Class Initialized
DEBUG - 2018-02-16 11:09:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-16 11:09:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-16 11:09:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-16 11:09:19 --> Pagination Class Initialized
INFO - 2018-02-16 11:09:19 --> Helper loaded: form_helper
INFO - 2018-02-16 11:09:19 --> Form Validation Class Initialized
INFO - 2018-02-16 11:09:19 --> Model Class Initialized
INFO - 2018-02-16 11:09:19 --> Controller Class Initialized
INFO - 2018-02-16 11:09:19 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-16 11:09:19 --> Model Class Initialized
INFO - 2018-02-16 11:09:19 --> Model Class Initialized
INFO - 2018-02-16 11:09:19 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-16 11:09:19 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-16 11:09:19 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-16 11:09:19 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-16 11:09:19 --> File loaded: /var/www/html/project/radio/application/views/subcategory/index.php
INFO - 2018-02-16 11:09:19 --> Final output sent to browser
DEBUG - 2018-02-16 11:09:19 --> Total execution time: 0.0081
INFO - 2018-02-16 11:09:22 --> Config Class Initialized
INFO - 2018-02-16 11:09:22 --> Hooks Class Initialized
DEBUG - 2018-02-16 11:09:22 --> UTF-8 Support Enabled
INFO - 2018-02-16 11:09:22 --> Utf8 Class Initialized
INFO - 2018-02-16 11:09:22 --> URI Class Initialized
INFO - 2018-02-16 11:09:22 --> Router Class Initialized
INFO - 2018-02-16 11:09:22 --> Output Class Initialized
INFO - 2018-02-16 11:09:22 --> Security Class Initialized
DEBUG - 2018-02-16 11:09:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-16 11:09:22 --> Input Class Initialized
INFO - 2018-02-16 11:09:22 --> Language Class Initialized
INFO - 2018-02-16 11:09:22 --> Loader Class Initialized
INFO - 2018-02-16 11:09:22 --> Helper loaded: url_helper
INFO - 2018-02-16 11:09:22 --> Helper loaded: file_helper
INFO - 2018-02-16 11:09:22 --> Helper loaded: email_helper
INFO - 2018-02-16 11:09:22 --> Helper loaded: common_helper
INFO - 2018-02-16 11:09:22 --> Database Driver Class Initialized
DEBUG - 2018-02-16 11:09:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-16 11:09:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-16 11:09:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-16 11:09:22 --> Pagination Class Initialized
INFO - 2018-02-16 11:09:22 --> Helper loaded: form_helper
INFO - 2018-02-16 11:09:22 --> Form Validation Class Initialized
INFO - 2018-02-16 11:09:22 --> Model Class Initialized
INFO - 2018-02-16 11:09:22 --> Controller Class Initialized
INFO - 2018-02-16 11:09:22 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-16 11:09:22 --> Model Class Initialized
INFO - 2018-02-16 11:09:22 --> Model Class Initialized
INFO - 2018-02-16 11:09:22 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-16 11:09:22 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-16 11:09:22 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-16 11:09:22 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-16 11:09:22 --> File loaded: /var/www/html/project/radio/application/views/subcategory/add_edit.php
INFO - 2018-02-16 11:09:22 --> Final output sent to browser
DEBUG - 2018-02-16 11:09:22 --> Total execution time: 0.0057
INFO - 2018-02-16 11:09:25 --> Config Class Initialized
INFO - 2018-02-16 11:09:25 --> Hooks Class Initialized
DEBUG - 2018-02-16 11:09:25 --> UTF-8 Support Enabled
INFO - 2018-02-16 11:09:25 --> Utf8 Class Initialized
INFO - 2018-02-16 11:09:25 --> URI Class Initialized
INFO - 2018-02-16 11:09:25 --> Router Class Initialized
INFO - 2018-02-16 11:09:25 --> Output Class Initialized
INFO - 2018-02-16 11:09:25 --> Security Class Initialized
DEBUG - 2018-02-16 11:09:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-16 11:09:25 --> Input Class Initialized
INFO - 2018-02-16 11:09:25 --> Language Class Initialized
INFO - 2018-02-16 11:09:25 --> Loader Class Initialized
INFO - 2018-02-16 11:09:25 --> Helper loaded: url_helper
INFO - 2018-02-16 11:09:25 --> Helper loaded: file_helper
INFO - 2018-02-16 11:09:25 --> Helper loaded: email_helper
INFO - 2018-02-16 11:09:25 --> Helper loaded: common_helper
INFO - 2018-02-16 11:09:25 --> Database Driver Class Initialized
DEBUG - 2018-02-16 11:09:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-16 11:09:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-16 11:09:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-16 11:09:25 --> Pagination Class Initialized
INFO - 2018-02-16 11:09:25 --> Helper loaded: form_helper
INFO - 2018-02-16 11:09:25 --> Form Validation Class Initialized
INFO - 2018-02-16 11:09:25 --> Model Class Initialized
INFO - 2018-02-16 11:09:25 --> Controller Class Initialized
INFO - 2018-02-16 11:09:25 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-16 11:09:25 --> Model Class Initialized
INFO - 2018-02-16 11:09:25 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-16 11:09:25 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-16 11:09:25 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-16 11:09:25 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-16 11:09:25 --> File loaded: /var/www/html/project/radio/application/views/category/index.php
INFO - 2018-02-16 11:09:25 --> Final output sent to browser
DEBUG - 2018-02-16 11:09:25 --> Total execution time: 0.0228
INFO - 2018-02-16 11:09:27 --> Config Class Initialized
INFO - 2018-02-16 11:09:27 --> Hooks Class Initialized
DEBUG - 2018-02-16 11:09:27 --> UTF-8 Support Enabled
INFO - 2018-02-16 11:09:27 --> Utf8 Class Initialized
INFO - 2018-02-16 11:09:27 --> URI Class Initialized
INFO - 2018-02-16 11:09:27 --> Router Class Initialized
INFO - 2018-02-16 11:09:27 --> Output Class Initialized
INFO - 2018-02-16 11:09:27 --> Security Class Initialized
DEBUG - 2018-02-16 11:09:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-16 11:09:27 --> Input Class Initialized
INFO - 2018-02-16 11:09:27 --> Language Class Initialized
INFO - 2018-02-16 11:09:27 --> Loader Class Initialized
INFO - 2018-02-16 11:09:27 --> Helper loaded: url_helper
INFO - 2018-02-16 11:09:27 --> Helper loaded: file_helper
INFO - 2018-02-16 11:09:27 --> Helper loaded: email_helper
INFO - 2018-02-16 11:09:27 --> Helper loaded: common_helper
INFO - 2018-02-16 11:09:27 --> Database Driver Class Initialized
DEBUG - 2018-02-16 11:09:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-16 11:09:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-16 11:09:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-16 11:09:27 --> Pagination Class Initialized
INFO - 2018-02-16 11:09:27 --> Helper loaded: form_helper
INFO - 2018-02-16 11:09:27 --> Form Validation Class Initialized
INFO - 2018-02-16 11:09:27 --> Model Class Initialized
INFO - 2018-02-16 11:09:27 --> Controller Class Initialized
INFO - 2018-02-16 11:09:27 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-16 11:09:27 --> Model Class Initialized
INFO - 2018-02-16 11:09:27 --> Model Class Initialized
INFO - 2018-02-16 11:09:27 --> Model Class Initialized
INFO - 2018-02-16 11:09:27 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-16 11:09:27 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-16 11:09:27 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-16 11:09:27 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-16 11:09:27 --> File loaded: /var/www/html/project/radio/application/views/tracks/index.php
INFO - 2018-02-16 11:09:27 --> Final output sent to browser
DEBUG - 2018-02-16 11:09:27 --> Total execution time: 0.0045
INFO - 2018-02-16 11:09:27 --> Config Class Initialized
INFO - 2018-02-16 11:09:27 --> Hooks Class Initialized
DEBUG - 2018-02-16 11:09:27 --> UTF-8 Support Enabled
INFO - 2018-02-16 11:09:27 --> Utf8 Class Initialized
INFO - 2018-02-16 11:09:27 --> URI Class Initialized
INFO - 2018-02-16 11:09:27 --> Router Class Initialized
INFO - 2018-02-16 11:09:27 --> Output Class Initialized
INFO - 2018-02-16 11:09:27 --> Security Class Initialized
DEBUG - 2018-02-16 11:09:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-16 11:09:27 --> Input Class Initialized
INFO - 2018-02-16 11:09:27 --> Language Class Initialized
INFO - 2018-02-16 11:09:27 --> Loader Class Initialized
INFO - 2018-02-16 11:09:27 --> Helper loaded: url_helper
INFO - 2018-02-16 11:09:27 --> Helper loaded: file_helper
INFO - 2018-02-16 11:09:27 --> Helper loaded: email_helper
INFO - 2018-02-16 11:09:27 --> Helper loaded: common_helper
INFO - 2018-02-16 11:09:27 --> Database Driver Class Initialized
DEBUG - 2018-02-16 11:09:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-16 11:09:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-16 11:09:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-16 11:09:27 --> Pagination Class Initialized
INFO - 2018-02-16 11:09:27 --> Helper loaded: form_helper
INFO - 2018-02-16 11:09:27 --> Form Validation Class Initialized
INFO - 2018-02-16 11:09:27 --> Model Class Initialized
INFO - 2018-02-16 11:09:27 --> Controller Class Initialized
INFO - 2018-02-16 11:09:27 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-16 11:09:27 --> Model Class Initialized
INFO - 2018-02-16 11:09:27 --> Model Class Initialized
INFO - 2018-02-16 11:09:27 --> Model Class Initialized
INFO - 2018-02-16 11:13:43 --> Config Class Initialized
INFO - 2018-02-16 11:13:43 --> Hooks Class Initialized
DEBUG - 2018-02-16 11:13:43 --> UTF-8 Support Enabled
INFO - 2018-02-16 11:13:43 --> Utf8 Class Initialized
INFO - 2018-02-16 11:13:43 --> URI Class Initialized
INFO - 2018-02-16 11:13:43 --> Router Class Initialized
INFO - 2018-02-16 11:13:43 --> Output Class Initialized
INFO - 2018-02-16 11:13:43 --> Security Class Initialized
DEBUG - 2018-02-16 11:13:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-16 11:13:43 --> Input Class Initialized
INFO - 2018-02-16 11:13:43 --> Language Class Initialized
INFO - 2018-02-16 11:13:43 --> Loader Class Initialized
INFO - 2018-02-16 11:13:43 --> Helper loaded: url_helper
INFO - 2018-02-16 11:13:43 --> Helper loaded: file_helper
INFO - 2018-02-16 11:13:43 --> Helper loaded: email_helper
INFO - 2018-02-16 11:13:43 --> Helper loaded: common_helper
INFO - 2018-02-16 11:13:43 --> Database Driver Class Initialized
DEBUG - 2018-02-16 11:13:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-16 11:13:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-16 11:13:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-16 11:13:43 --> Pagination Class Initialized
INFO - 2018-02-16 11:13:43 --> Helper loaded: form_helper
INFO - 2018-02-16 11:13:43 --> Form Validation Class Initialized
INFO - 2018-02-16 11:13:43 --> Model Class Initialized
INFO - 2018-02-16 11:13:43 --> Controller Class Initialized
INFO - 2018-02-16 11:13:43 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-16 11:13:43 --> Model Class Initialized
INFO - 2018-02-16 11:13:43 --> Model Class Initialized
INFO - 2018-02-16 11:13:43 --> Model Class Initialized
INFO - 2018-02-16 11:13:43 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-16 11:13:43 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-16 11:13:43 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-16 11:13:43 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-16 11:13:43 --> File loaded: /var/www/html/project/radio/application/views/tracks/index.php
INFO - 2018-02-16 11:13:43 --> Final output sent to browser
DEBUG - 2018-02-16 11:13:43 --> Total execution time: 0.0088
INFO - 2018-02-16 11:13:43 --> Config Class Initialized
INFO - 2018-02-16 11:13:43 --> Hooks Class Initialized
DEBUG - 2018-02-16 11:13:43 --> UTF-8 Support Enabled
INFO - 2018-02-16 11:13:43 --> Utf8 Class Initialized
INFO - 2018-02-16 11:13:43 --> URI Class Initialized
INFO - 2018-02-16 11:13:43 --> Router Class Initialized
INFO - 2018-02-16 11:13:43 --> Output Class Initialized
INFO - 2018-02-16 11:13:43 --> Security Class Initialized
DEBUG - 2018-02-16 11:13:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-16 11:13:43 --> Input Class Initialized
INFO - 2018-02-16 11:13:43 --> Language Class Initialized
INFO - 2018-02-16 11:13:43 --> Loader Class Initialized
INFO - 2018-02-16 11:13:43 --> Helper loaded: url_helper
INFO - 2018-02-16 11:13:43 --> Helper loaded: file_helper
INFO - 2018-02-16 11:13:43 --> Helper loaded: email_helper
INFO - 2018-02-16 11:13:43 --> Helper loaded: common_helper
INFO - 2018-02-16 11:13:43 --> Database Driver Class Initialized
DEBUG - 2018-02-16 11:13:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-16 11:13:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-16 11:13:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-16 11:13:43 --> Pagination Class Initialized
INFO - 2018-02-16 11:13:43 --> Helper loaded: form_helper
INFO - 2018-02-16 11:13:43 --> Form Validation Class Initialized
INFO - 2018-02-16 11:13:43 --> Model Class Initialized
INFO - 2018-02-16 11:13:43 --> Controller Class Initialized
INFO - 2018-02-16 11:13:43 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-16 11:13:43 --> Model Class Initialized
INFO - 2018-02-16 11:13:43 --> Model Class Initialized
INFO - 2018-02-16 11:13:43 --> Model Class Initialized
ERROR - 2018-02-16 11:13:43 --> Query error: Table 'radio.SubCategory' doesn't exist - Invalid query: SELECT `t`.*, `c`.`vTitle` as `category`, `sc`.`vTitle` as `subcategory`, COUNT(uf.iUserFavoritesId) as totalFavorites
FROM `Tracks` as `t`
JOIN `SubCategory` as `sc` ON `sc`.`iSubCategoryId` = `t`.`iSubCategoryId`
JOIN `category` as `c` ON `c`.`iCategoryId` = `t`.`iCategoryId`
LEFT JOIN `UserFavorites` as `uf` ON `t`.`iTracksId` = `uf`.`iTracksId`
WHERE `t`.`is_deleted` =0
AND `c`.`is_deleted` =0
AND `sc`.`is_deleted` =0
GROUP BY `t`.`iTracksId`
ORDER BY `vTrackImage` ASC
INFO - 2018-02-16 11:13:43 --> Language file loaded: language/english/db_lang.php
INFO - 2018-02-16 11:13:48 --> Config Class Initialized
INFO - 2018-02-16 11:13:48 --> Hooks Class Initialized
DEBUG - 2018-02-16 11:13:48 --> UTF-8 Support Enabled
INFO - 2018-02-16 11:13:48 --> Utf8 Class Initialized
INFO - 2018-02-16 11:13:48 --> URI Class Initialized
INFO - 2018-02-16 11:13:48 --> Router Class Initialized
INFO - 2018-02-16 11:13:48 --> Output Class Initialized
INFO - 2018-02-16 11:13:48 --> Security Class Initialized
DEBUG - 2018-02-16 11:13:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-16 11:13:48 --> Input Class Initialized
INFO - 2018-02-16 11:13:48 --> Language Class Initialized
INFO - 2018-02-16 11:13:48 --> Loader Class Initialized
INFO - 2018-02-16 11:13:48 --> Helper loaded: url_helper
INFO - 2018-02-16 11:13:48 --> Helper loaded: file_helper
INFO - 2018-02-16 11:13:48 --> Helper loaded: email_helper
INFO - 2018-02-16 11:13:48 --> Helper loaded: common_helper
INFO - 2018-02-16 11:13:48 --> Database Driver Class Initialized
DEBUG - 2018-02-16 11:13:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-16 11:13:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-16 11:13:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-16 11:13:48 --> Pagination Class Initialized
INFO - 2018-02-16 11:13:48 --> Helper loaded: form_helper
INFO - 2018-02-16 11:13:48 --> Form Validation Class Initialized
INFO - 2018-02-16 11:13:48 --> Model Class Initialized
INFO - 2018-02-16 11:13:48 --> Controller Class Initialized
INFO - 2018-02-16 11:13:48 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-16 11:13:48 --> Model Class Initialized
INFO - 2018-02-16 11:13:48 --> Model Class Initialized
INFO - 2018-02-16 11:13:48 --> Model Class Initialized
INFO - 2018-02-16 11:13:48 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-16 11:13:48 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-16 11:13:48 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-16 11:13:48 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-16 11:13:48 --> File loaded: /var/www/html/project/radio/application/views/tracks/index.php
INFO - 2018-02-16 11:13:48 --> Final output sent to browser
DEBUG - 2018-02-16 11:13:48 --> Total execution time: 0.0066
INFO - 2018-02-16 11:13:49 --> Config Class Initialized
INFO - 2018-02-16 11:13:49 --> Hooks Class Initialized
DEBUG - 2018-02-16 11:13:49 --> UTF-8 Support Enabled
INFO - 2018-02-16 11:13:49 --> Utf8 Class Initialized
INFO - 2018-02-16 11:13:49 --> URI Class Initialized
INFO - 2018-02-16 11:13:49 --> Router Class Initialized
INFO - 2018-02-16 11:13:49 --> Output Class Initialized
INFO - 2018-02-16 11:13:49 --> Security Class Initialized
DEBUG - 2018-02-16 11:13:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-16 11:13:49 --> Input Class Initialized
INFO - 2018-02-16 11:13:49 --> Language Class Initialized
INFO - 2018-02-16 11:13:49 --> Loader Class Initialized
INFO - 2018-02-16 11:13:49 --> Helper loaded: url_helper
INFO - 2018-02-16 11:13:49 --> Helper loaded: file_helper
INFO - 2018-02-16 11:13:49 --> Helper loaded: email_helper
INFO - 2018-02-16 11:13:49 --> Helper loaded: common_helper
INFO - 2018-02-16 11:13:49 --> Database Driver Class Initialized
DEBUG - 2018-02-16 11:13:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-16 11:13:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-16 11:13:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-16 11:13:49 --> Pagination Class Initialized
INFO - 2018-02-16 11:13:49 --> Helper loaded: form_helper
INFO - 2018-02-16 11:13:49 --> Form Validation Class Initialized
INFO - 2018-02-16 11:13:49 --> Model Class Initialized
INFO - 2018-02-16 11:13:49 --> Controller Class Initialized
INFO - 2018-02-16 11:13:49 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-16 11:13:49 --> Model Class Initialized
INFO - 2018-02-16 11:13:49 --> Model Class Initialized
INFO - 2018-02-16 11:13:49 --> Model Class Initialized
INFO - 2018-02-16 11:13:50 --> Config Class Initialized
INFO - 2018-02-16 11:13:50 --> Hooks Class Initialized
DEBUG - 2018-02-16 11:13:50 --> UTF-8 Support Enabled
INFO - 2018-02-16 11:13:50 --> Utf8 Class Initialized
INFO - 2018-02-16 11:13:50 --> URI Class Initialized
INFO - 2018-02-16 11:13:50 --> Router Class Initialized
INFO - 2018-02-16 11:13:50 --> Output Class Initialized
INFO - 2018-02-16 11:13:50 --> Security Class Initialized
DEBUG - 2018-02-16 11:13:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-16 11:13:50 --> Input Class Initialized
INFO - 2018-02-16 11:13:50 --> Language Class Initialized
INFO - 2018-02-16 11:13:50 --> Loader Class Initialized
INFO - 2018-02-16 11:13:50 --> Helper loaded: url_helper
INFO - 2018-02-16 11:13:50 --> Helper loaded: file_helper
INFO - 2018-02-16 11:13:50 --> Helper loaded: email_helper
INFO - 2018-02-16 11:13:50 --> Helper loaded: common_helper
INFO - 2018-02-16 11:13:50 --> Database Driver Class Initialized
DEBUG - 2018-02-16 11:13:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-16 11:13:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-16 11:13:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-16 11:13:50 --> Pagination Class Initialized
INFO - 2018-02-16 11:13:50 --> Helper loaded: form_helper
INFO - 2018-02-16 11:13:50 --> Form Validation Class Initialized
INFO - 2018-02-16 11:13:50 --> Model Class Initialized
INFO - 2018-02-16 11:13:50 --> Controller Class Initialized
INFO - 2018-02-16 11:13:50 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-16 11:13:50 --> Model Class Initialized
INFO - 2018-02-16 11:13:50 --> Model Class Initialized
INFO - 2018-02-16 11:13:50 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-16 11:13:50 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-16 11:13:50 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-16 11:13:50 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-16 11:13:50 --> File loaded: /var/www/html/project/radio/application/views/subcategory/index.php
INFO - 2018-02-16 11:13:50 --> Final output sent to browser
DEBUG - 2018-02-16 11:13:50 --> Total execution time: 0.0055
INFO - 2018-02-16 11:13:53 --> Config Class Initialized
INFO - 2018-02-16 11:13:53 --> Hooks Class Initialized
DEBUG - 2018-02-16 11:13:53 --> UTF-8 Support Enabled
INFO - 2018-02-16 11:13:53 --> Utf8 Class Initialized
INFO - 2018-02-16 11:13:53 --> URI Class Initialized
INFO - 2018-02-16 11:13:53 --> Router Class Initialized
INFO - 2018-02-16 11:13:53 --> Output Class Initialized
INFO - 2018-02-16 11:13:53 --> Security Class Initialized
DEBUG - 2018-02-16 11:13:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-16 11:13:53 --> Input Class Initialized
INFO - 2018-02-16 11:13:53 --> Language Class Initialized
INFO - 2018-02-16 11:13:53 --> Loader Class Initialized
INFO - 2018-02-16 11:13:53 --> Helper loaded: url_helper
INFO - 2018-02-16 11:13:53 --> Helper loaded: file_helper
INFO - 2018-02-16 11:13:53 --> Helper loaded: email_helper
INFO - 2018-02-16 11:13:53 --> Helper loaded: common_helper
INFO - 2018-02-16 11:13:53 --> Database Driver Class Initialized
DEBUG - 2018-02-16 11:13:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-16 11:13:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-16 11:13:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-16 11:13:53 --> Pagination Class Initialized
INFO - 2018-02-16 11:13:53 --> Helper loaded: form_helper
INFO - 2018-02-16 11:13:53 --> Form Validation Class Initialized
INFO - 2018-02-16 11:13:53 --> Model Class Initialized
INFO - 2018-02-16 11:13:53 --> Controller Class Initialized
INFO - 2018-02-16 11:13:53 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-16 11:13:53 --> Model Class Initialized
INFO - 2018-02-16 11:13:53 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-16 11:13:53 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-16 11:13:53 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-16 11:13:53 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-16 11:13:53 --> File loaded: /var/www/html/project/radio/application/views/category/index.php
INFO - 2018-02-16 11:13:53 --> Final output sent to browser
DEBUG - 2018-02-16 11:13:53 --> Total execution time: 0.0056
INFO - 2018-02-16 11:13:54 --> Config Class Initialized
INFO - 2018-02-16 11:13:54 --> Hooks Class Initialized
DEBUG - 2018-02-16 11:13:54 --> UTF-8 Support Enabled
INFO - 2018-02-16 11:13:54 --> Utf8 Class Initialized
INFO - 2018-02-16 11:13:54 --> URI Class Initialized
INFO - 2018-02-16 11:13:54 --> Router Class Initialized
INFO - 2018-02-16 11:13:54 --> Output Class Initialized
INFO - 2018-02-16 11:13:54 --> Security Class Initialized
DEBUG - 2018-02-16 11:13:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-16 11:13:54 --> Input Class Initialized
INFO - 2018-02-16 11:13:54 --> Language Class Initialized
INFO - 2018-02-16 11:13:54 --> Loader Class Initialized
INFO - 2018-02-16 11:13:54 --> Helper loaded: url_helper
INFO - 2018-02-16 11:13:54 --> Helper loaded: file_helper
INFO - 2018-02-16 11:13:54 --> Helper loaded: email_helper
INFO - 2018-02-16 11:13:54 --> Helper loaded: common_helper
INFO - 2018-02-16 11:13:54 --> Database Driver Class Initialized
DEBUG - 2018-02-16 11:13:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-16 11:13:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-16 11:13:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-16 11:13:54 --> Pagination Class Initialized
INFO - 2018-02-16 11:13:54 --> Helper loaded: form_helper
INFO - 2018-02-16 11:13:54 --> Form Validation Class Initialized
INFO - 2018-02-16 11:13:54 --> Model Class Initialized
INFO - 2018-02-16 11:13:54 --> Controller Class Initialized
INFO - 2018-02-16 11:13:54 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-16 11:13:54 --> Model Class Initialized
INFO - 2018-02-16 11:13:54 --> Model Class Initialized
INFO - 2018-02-16 11:13:54 --> Model Class Initialized
INFO - 2018-02-16 11:13:54 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-16 11:13:54 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-16 11:13:54 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-16 11:13:54 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-16 11:13:54 --> File loaded: /var/www/html/project/radio/application/views/tracks/index.php
INFO - 2018-02-16 11:13:54 --> Final output sent to browser
DEBUG - 2018-02-16 11:13:54 --> Total execution time: 0.0055
INFO - 2018-02-16 11:13:54 --> Config Class Initialized
INFO - 2018-02-16 11:13:54 --> Hooks Class Initialized
DEBUG - 2018-02-16 11:13:54 --> UTF-8 Support Enabled
INFO - 2018-02-16 11:13:54 --> Utf8 Class Initialized
INFO - 2018-02-16 11:13:54 --> URI Class Initialized
INFO - 2018-02-16 11:13:54 --> Router Class Initialized
INFO - 2018-02-16 11:13:54 --> Output Class Initialized
INFO - 2018-02-16 11:13:54 --> Security Class Initialized
DEBUG - 2018-02-16 11:13:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-16 11:13:54 --> Input Class Initialized
INFO - 2018-02-16 11:13:54 --> Language Class Initialized
INFO - 2018-02-16 11:13:54 --> Loader Class Initialized
INFO - 2018-02-16 11:13:54 --> Helper loaded: url_helper
INFO - 2018-02-16 11:13:54 --> Helper loaded: file_helper
INFO - 2018-02-16 11:13:54 --> Helper loaded: email_helper
INFO - 2018-02-16 11:13:54 --> Helper loaded: common_helper
INFO - 2018-02-16 11:13:54 --> Database Driver Class Initialized
DEBUG - 2018-02-16 11:13:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-16 11:13:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-16 11:13:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-16 11:13:54 --> Pagination Class Initialized
INFO - 2018-02-16 11:13:54 --> Helper loaded: form_helper
INFO - 2018-02-16 11:13:54 --> Form Validation Class Initialized
INFO - 2018-02-16 11:13:54 --> Model Class Initialized
INFO - 2018-02-16 11:13:54 --> Controller Class Initialized
INFO - 2018-02-16 11:13:54 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-16 11:13:54 --> Model Class Initialized
INFO - 2018-02-16 11:13:54 --> Model Class Initialized
INFO - 2018-02-16 11:13:54 --> Model Class Initialized
INFO - 2018-02-16 11:13:55 --> Config Class Initialized
INFO - 2018-02-16 11:13:55 --> Hooks Class Initialized
DEBUG - 2018-02-16 11:13:55 --> UTF-8 Support Enabled
INFO - 2018-02-16 11:13:55 --> Utf8 Class Initialized
INFO - 2018-02-16 11:13:55 --> URI Class Initialized
INFO - 2018-02-16 11:13:55 --> Router Class Initialized
INFO - 2018-02-16 11:13:55 --> Output Class Initialized
INFO - 2018-02-16 11:13:55 --> Security Class Initialized
DEBUG - 2018-02-16 11:13:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-16 11:13:55 --> Input Class Initialized
INFO - 2018-02-16 11:13:55 --> Language Class Initialized
INFO - 2018-02-16 11:13:55 --> Loader Class Initialized
INFO - 2018-02-16 11:13:55 --> Helper loaded: url_helper
INFO - 2018-02-16 11:13:55 --> Helper loaded: file_helper
INFO - 2018-02-16 11:13:55 --> Helper loaded: email_helper
INFO - 2018-02-16 11:13:55 --> Helper loaded: common_helper
INFO - 2018-02-16 11:13:55 --> Database Driver Class Initialized
DEBUG - 2018-02-16 11:13:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-16 11:13:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-16 11:13:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-16 11:13:55 --> Pagination Class Initialized
INFO - 2018-02-16 11:13:55 --> Helper loaded: form_helper
INFO - 2018-02-16 11:13:55 --> Form Validation Class Initialized
INFO - 2018-02-16 11:13:55 --> Model Class Initialized
INFO - 2018-02-16 11:13:55 --> Controller Class Initialized
INFO - 2018-02-16 11:13:55 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-16 11:13:55 --> Model Class Initialized
INFO - 2018-02-16 11:13:55 --> Model Class Initialized
INFO - 2018-02-16 11:13:55 --> Model Class Initialized
INFO - 2018-02-16 11:13:55 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-16 11:13:55 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-16 11:13:55 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-16 11:13:55 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-16 11:13:55 --> File loaded: /var/www/html/project/radio/application/views/tracks/add_edit.php
INFO - 2018-02-16 11:13:55 --> Final output sent to browser
DEBUG - 2018-02-16 11:13:55 --> Total execution time: 0.0046
INFO - 2018-02-16 11:13:57 --> Config Class Initialized
INFO - 2018-02-16 11:13:57 --> Hooks Class Initialized
DEBUG - 2018-02-16 11:13:57 --> UTF-8 Support Enabled
INFO - 2018-02-16 11:13:57 --> Utf8 Class Initialized
INFO - 2018-02-16 11:13:57 --> URI Class Initialized
INFO - 2018-02-16 11:13:57 --> Router Class Initialized
INFO - 2018-02-16 11:13:57 --> Output Class Initialized
INFO - 2018-02-16 11:13:57 --> Security Class Initialized
DEBUG - 2018-02-16 11:13:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-16 11:13:57 --> Input Class Initialized
INFO - 2018-02-16 11:13:57 --> Language Class Initialized
INFO - 2018-02-16 11:13:57 --> Loader Class Initialized
INFO - 2018-02-16 11:13:57 --> Helper loaded: url_helper
INFO - 2018-02-16 11:13:57 --> Helper loaded: file_helper
INFO - 2018-02-16 11:13:57 --> Helper loaded: email_helper
INFO - 2018-02-16 11:13:57 --> Helper loaded: common_helper
INFO - 2018-02-16 11:13:57 --> Database Driver Class Initialized
DEBUG - 2018-02-16 11:13:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-16 11:13:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-16 11:13:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-16 11:13:57 --> Pagination Class Initialized
INFO - 2018-02-16 11:13:57 --> Helper loaded: form_helper
INFO - 2018-02-16 11:13:57 --> Form Validation Class Initialized
INFO - 2018-02-16 11:13:57 --> Model Class Initialized
INFO - 2018-02-16 11:13:57 --> Controller Class Initialized
INFO - 2018-02-16 11:13:57 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-16 11:13:57 --> Model Class Initialized
INFO - 2018-02-16 11:13:57 --> Model Class Initialized
INFO - 2018-02-16 11:13:57 --> Model Class Initialized
INFO - 2018-02-16 11:18:19 --> Config Class Initialized
INFO - 2018-02-16 11:18:19 --> Hooks Class Initialized
DEBUG - 2018-02-16 11:18:19 --> UTF-8 Support Enabled
INFO - 2018-02-16 11:18:19 --> Utf8 Class Initialized
INFO - 2018-02-16 11:18:19 --> URI Class Initialized
INFO - 2018-02-16 11:18:19 --> Router Class Initialized
INFO - 2018-02-16 11:18:19 --> Output Class Initialized
INFO - 2018-02-16 11:18:19 --> Security Class Initialized
DEBUG - 2018-02-16 11:18:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-16 11:18:19 --> Input Class Initialized
INFO - 2018-02-16 11:18:19 --> Language Class Initialized
INFO - 2018-02-16 11:18:19 --> Loader Class Initialized
INFO - 2018-02-16 11:18:19 --> Helper loaded: url_helper
INFO - 2018-02-16 11:18:19 --> Helper loaded: file_helper
INFO - 2018-02-16 11:18:19 --> Helper loaded: email_helper
INFO - 2018-02-16 11:18:19 --> Helper loaded: common_helper
INFO - 2018-02-16 11:18:19 --> Database Driver Class Initialized
DEBUG - 2018-02-16 11:18:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-16 11:18:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-16 11:18:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-16 11:18:19 --> Pagination Class Initialized
INFO - 2018-02-16 11:18:19 --> Helper loaded: form_helper
INFO - 2018-02-16 11:18:19 --> Form Validation Class Initialized
INFO - 2018-02-16 11:18:19 --> Model Class Initialized
INFO - 2018-02-16 11:18:19 --> Controller Class Initialized
INFO - 2018-02-16 11:18:19 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-16 11:18:19 --> Model Class Initialized
INFO - 2018-02-16 11:18:19 --> Model Class Initialized
INFO - 2018-02-16 11:18:19 --> Model Class Initialized
INFO - 2018-02-16 11:18:19 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-16 11:18:19 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-16 11:18:19 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-16 11:18:19 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-16 11:18:19 --> File loaded: /var/www/html/project/radio/application/views/tracks/add_edit.php
INFO - 2018-02-16 11:18:19 --> Final output sent to browser
DEBUG - 2018-02-16 11:18:19 --> Total execution time: 0.0080
INFO - 2018-02-16 11:18:24 --> Config Class Initialized
INFO - 2018-02-16 11:18:24 --> Hooks Class Initialized
DEBUG - 2018-02-16 11:18:24 --> UTF-8 Support Enabled
INFO - 2018-02-16 11:18:24 --> Utf8 Class Initialized
INFO - 2018-02-16 11:18:24 --> URI Class Initialized
INFO - 2018-02-16 11:18:24 --> Router Class Initialized
INFO - 2018-02-16 11:18:24 --> Output Class Initialized
INFO - 2018-02-16 11:18:24 --> Security Class Initialized
DEBUG - 2018-02-16 11:18:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-16 11:18:24 --> Input Class Initialized
INFO - 2018-02-16 11:18:24 --> Language Class Initialized
INFO - 2018-02-16 11:18:24 --> Loader Class Initialized
INFO - 2018-02-16 11:18:24 --> Helper loaded: url_helper
INFO - 2018-02-16 11:18:24 --> Helper loaded: file_helper
INFO - 2018-02-16 11:18:24 --> Helper loaded: email_helper
INFO - 2018-02-16 11:18:24 --> Helper loaded: common_helper
INFO - 2018-02-16 11:18:24 --> Database Driver Class Initialized
DEBUG - 2018-02-16 11:18:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-16 11:18:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-16 11:18:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-16 11:18:24 --> Pagination Class Initialized
INFO - 2018-02-16 11:18:24 --> Helper loaded: form_helper
INFO - 2018-02-16 11:18:24 --> Form Validation Class Initialized
INFO - 2018-02-16 11:18:24 --> Model Class Initialized
INFO - 2018-02-16 11:18:24 --> Controller Class Initialized
INFO - 2018-02-16 11:18:24 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-16 11:18:24 --> Model Class Initialized
INFO - 2018-02-16 11:18:24 --> Model Class Initialized
INFO - 2018-02-16 11:18:24 --> Model Class Initialized
INFO - 2018-02-16 11:18:26 --> Config Class Initialized
INFO - 2018-02-16 11:18:26 --> Hooks Class Initialized
DEBUG - 2018-02-16 11:18:26 --> UTF-8 Support Enabled
INFO - 2018-02-16 11:18:26 --> Utf8 Class Initialized
INFO - 2018-02-16 11:18:26 --> URI Class Initialized
INFO - 2018-02-16 11:18:26 --> Router Class Initialized
INFO - 2018-02-16 11:18:26 --> Output Class Initialized
INFO - 2018-02-16 11:18:26 --> Security Class Initialized
DEBUG - 2018-02-16 11:18:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-16 11:18:26 --> Input Class Initialized
INFO - 2018-02-16 11:18:26 --> Language Class Initialized
INFO - 2018-02-16 11:18:26 --> Loader Class Initialized
INFO - 2018-02-16 11:18:26 --> Helper loaded: url_helper
INFO - 2018-02-16 11:18:26 --> Helper loaded: file_helper
INFO - 2018-02-16 11:18:26 --> Helper loaded: email_helper
INFO - 2018-02-16 11:18:26 --> Helper loaded: common_helper
INFO - 2018-02-16 11:18:26 --> Database Driver Class Initialized
DEBUG - 2018-02-16 11:18:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-16 11:18:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-16 11:18:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-16 11:18:26 --> Pagination Class Initialized
INFO - 2018-02-16 11:18:26 --> Helper loaded: form_helper
INFO - 2018-02-16 11:18:26 --> Form Validation Class Initialized
INFO - 2018-02-16 11:18:26 --> Model Class Initialized
INFO - 2018-02-16 11:18:26 --> Controller Class Initialized
INFO - 2018-02-16 11:18:26 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-16 11:18:26 --> Model Class Initialized
INFO - 2018-02-16 11:18:26 --> Model Class Initialized
INFO - 2018-02-16 11:18:26 --> Model Class Initialized
INFO - 2018-02-16 11:18:26 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-16 11:18:26 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-16 11:18:26 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-16 11:18:26 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-16 11:18:26 --> File loaded: /var/www/html/project/radio/application/views/tracks/index.php
INFO - 2018-02-16 11:18:26 --> Final output sent to browser
DEBUG - 2018-02-16 11:18:26 --> Total execution time: 0.0060
INFO - 2018-02-16 11:18:26 --> Config Class Initialized
INFO - 2018-02-16 11:18:26 --> Hooks Class Initialized
DEBUG - 2018-02-16 11:18:26 --> UTF-8 Support Enabled
INFO - 2018-02-16 11:18:26 --> Utf8 Class Initialized
INFO - 2018-02-16 11:18:26 --> URI Class Initialized
INFO - 2018-02-16 11:18:26 --> Router Class Initialized
INFO - 2018-02-16 11:18:26 --> Output Class Initialized
INFO - 2018-02-16 11:18:26 --> Security Class Initialized
DEBUG - 2018-02-16 11:18:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-16 11:18:26 --> Input Class Initialized
INFO - 2018-02-16 11:18:26 --> Language Class Initialized
INFO - 2018-02-16 11:18:26 --> Loader Class Initialized
INFO - 2018-02-16 11:18:26 --> Helper loaded: url_helper
INFO - 2018-02-16 11:18:26 --> Helper loaded: file_helper
INFO - 2018-02-16 11:18:26 --> Helper loaded: email_helper
INFO - 2018-02-16 11:18:26 --> Helper loaded: common_helper
INFO - 2018-02-16 11:18:26 --> Database Driver Class Initialized
DEBUG - 2018-02-16 11:18:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-16 11:18:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-16 11:18:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-16 11:18:26 --> Pagination Class Initialized
INFO - 2018-02-16 11:18:26 --> Helper loaded: form_helper
INFO - 2018-02-16 11:18:26 --> Form Validation Class Initialized
INFO - 2018-02-16 11:18:26 --> Model Class Initialized
INFO - 2018-02-16 11:18:26 --> Controller Class Initialized
INFO - 2018-02-16 11:18:26 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-16 11:18:26 --> Model Class Initialized
INFO - 2018-02-16 11:18:26 --> Model Class Initialized
INFO - 2018-02-16 11:18:26 --> Model Class Initialized
INFO - 2018-02-16 12:15:04 --> Config Class Initialized
INFO - 2018-02-16 12:15:04 --> Hooks Class Initialized
DEBUG - 2018-02-16 12:15:04 --> UTF-8 Support Enabled
INFO - 2018-02-16 12:15:04 --> Utf8 Class Initialized
INFO - 2018-02-16 12:15:04 --> URI Class Initialized
INFO - 2018-02-16 12:15:04 --> Router Class Initialized
INFO - 2018-02-16 12:15:04 --> Output Class Initialized
INFO - 2018-02-16 12:15:04 --> Security Class Initialized
DEBUG - 2018-02-16 12:15:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-16 12:15:04 --> Input Class Initialized
INFO - 2018-02-16 12:15:04 --> Language Class Initialized
INFO - 2018-02-16 12:15:04 --> Loader Class Initialized
INFO - 2018-02-16 12:15:04 --> Helper loaded: url_helper
INFO - 2018-02-16 12:15:04 --> Helper loaded: file_helper
INFO - 2018-02-16 12:15:04 --> Helper loaded: email_helper
INFO - 2018-02-16 12:15:04 --> Helper loaded: common_helper
INFO - 2018-02-16 12:15:04 --> Database Driver Class Initialized
DEBUG - 2018-02-16 12:15:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-16 12:15:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-16 12:15:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-16 12:15:04 --> Pagination Class Initialized
INFO - 2018-02-16 12:15:04 --> Helper loaded: form_helper
INFO - 2018-02-16 12:15:04 --> Form Validation Class Initialized
INFO - 2018-02-16 12:15:04 --> Model Class Initialized
INFO - 2018-02-16 12:15:04 --> Controller Class Initialized
INFO - 2018-02-16 12:15:04 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-16 12:15:04 --> Model Class Initialized
INFO - 2018-02-16 12:15:04 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-16 12:15:04 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-16 12:15:04 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-16 12:15:04 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-16 12:15:04 --> File loaded: /var/www/html/project/radio/application/views/user/index.php
INFO - 2018-02-16 12:15:04 --> Final output sent to browser
DEBUG - 2018-02-16 12:15:04 --> Total execution time: 0.0253
INFO - 2018-02-16 12:15:04 --> Config Class Initialized
INFO - 2018-02-16 12:15:04 --> Hooks Class Initialized
DEBUG - 2018-02-16 12:15:04 --> UTF-8 Support Enabled
INFO - 2018-02-16 12:15:04 --> Utf8 Class Initialized
INFO - 2018-02-16 12:15:04 --> URI Class Initialized
INFO - 2018-02-16 12:15:04 --> Router Class Initialized
INFO - 2018-02-16 12:15:04 --> Output Class Initialized
INFO - 2018-02-16 12:15:04 --> Security Class Initialized
DEBUG - 2018-02-16 12:15:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-16 12:15:04 --> Input Class Initialized
INFO - 2018-02-16 12:15:04 --> Language Class Initialized
INFO - 2018-02-16 12:15:04 --> Loader Class Initialized
INFO - 2018-02-16 12:15:04 --> Helper loaded: url_helper
INFO - 2018-02-16 12:15:04 --> Helper loaded: file_helper
INFO - 2018-02-16 12:15:04 --> Helper loaded: email_helper
INFO - 2018-02-16 12:15:04 --> Helper loaded: common_helper
INFO - 2018-02-16 12:15:04 --> Database Driver Class Initialized
DEBUG - 2018-02-16 12:15:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-16 12:15:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-16 12:15:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-16 12:15:04 --> Pagination Class Initialized
INFO - 2018-02-16 12:15:04 --> Helper loaded: form_helper
INFO - 2018-02-16 12:15:04 --> Form Validation Class Initialized
INFO - 2018-02-16 12:15:04 --> Model Class Initialized
INFO - 2018-02-16 12:15:04 --> Controller Class Initialized
INFO - 2018-02-16 12:15:04 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-16 12:15:04 --> Model Class Initialized
ERROR - 2018-02-16 12:15:04 --> Query error: Unknown column 'us.is_delete' in 'where clause' - Invalid query: SELECT `us`.*
FROM `user_master` as `us`
WHERE `us`.`is_delete` =0
ORDER BY `vName` ASC
INFO - 2018-02-16 12:15:04 --> Language file loaded: language/english/db_lang.php
INFO - 2018-02-16 12:15:15 --> Config Class Initialized
INFO - 2018-02-16 12:15:15 --> Hooks Class Initialized
DEBUG - 2018-02-16 12:15:15 --> UTF-8 Support Enabled
INFO - 2018-02-16 12:15:15 --> Utf8 Class Initialized
INFO - 2018-02-16 12:15:15 --> URI Class Initialized
INFO - 2018-02-16 12:15:15 --> Router Class Initialized
INFO - 2018-02-16 12:15:15 --> Output Class Initialized
INFO - 2018-02-16 12:15:15 --> Security Class Initialized
DEBUG - 2018-02-16 12:15:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-16 12:15:15 --> Input Class Initialized
INFO - 2018-02-16 12:15:15 --> Language Class Initialized
INFO - 2018-02-16 12:15:15 --> Loader Class Initialized
INFO - 2018-02-16 12:15:15 --> Helper loaded: url_helper
INFO - 2018-02-16 12:15:15 --> Helper loaded: file_helper
INFO - 2018-02-16 12:15:15 --> Helper loaded: email_helper
INFO - 2018-02-16 12:15:15 --> Helper loaded: common_helper
INFO - 2018-02-16 12:15:15 --> Database Driver Class Initialized
DEBUG - 2018-02-16 12:15:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-16 12:15:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-16 12:15:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-16 12:15:15 --> Pagination Class Initialized
INFO - 2018-02-16 12:15:15 --> Helper loaded: form_helper
INFO - 2018-02-16 12:15:15 --> Form Validation Class Initialized
INFO - 2018-02-16 12:15:15 --> Model Class Initialized
INFO - 2018-02-16 12:15:15 --> Controller Class Initialized
INFO - 2018-02-16 12:15:15 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-16 12:15:15 --> Model Class Initialized
INFO - 2018-02-16 12:15:15 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-16 12:15:15 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-16 12:15:15 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-16 12:15:15 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-16 12:15:15 --> File loaded: /var/www/html/project/radio/application/views/user/index.php
INFO - 2018-02-16 12:15:15 --> Final output sent to browser
DEBUG - 2018-02-16 12:15:15 --> Total execution time: 0.0068
INFO - 2018-02-16 12:15:15 --> Config Class Initialized
INFO - 2018-02-16 12:15:15 --> Hooks Class Initialized
DEBUG - 2018-02-16 12:15:15 --> UTF-8 Support Enabled
INFO - 2018-02-16 12:15:15 --> Utf8 Class Initialized
INFO - 2018-02-16 12:15:15 --> URI Class Initialized
INFO - 2018-02-16 12:15:15 --> Router Class Initialized
INFO - 2018-02-16 12:15:15 --> Output Class Initialized
INFO - 2018-02-16 12:15:15 --> Security Class Initialized
DEBUG - 2018-02-16 12:15:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-16 12:15:15 --> Input Class Initialized
INFO - 2018-02-16 12:15:15 --> Language Class Initialized
INFO - 2018-02-16 12:15:15 --> Loader Class Initialized
INFO - 2018-02-16 12:15:15 --> Helper loaded: url_helper
INFO - 2018-02-16 12:15:15 --> Helper loaded: file_helper
INFO - 2018-02-16 12:15:15 --> Helper loaded: email_helper
INFO - 2018-02-16 12:15:15 --> Helper loaded: common_helper
INFO - 2018-02-16 12:15:15 --> Database Driver Class Initialized
DEBUG - 2018-02-16 12:15:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-16 12:15:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-16 12:15:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-16 12:15:15 --> Pagination Class Initialized
INFO - 2018-02-16 12:15:15 --> Helper loaded: form_helper
INFO - 2018-02-16 12:15:15 --> Form Validation Class Initialized
INFO - 2018-02-16 12:15:15 --> Model Class Initialized
INFO - 2018-02-16 12:15:15 --> Controller Class Initialized
INFO - 2018-02-16 12:15:15 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-16 12:15:15 --> Model Class Initialized
ERROR - 2018-02-16 12:15:15 --> Query error: Unknown column 'us.is_delete' in 'where clause' - Invalid query: SELECT `us`.*
FROM `user_master` as `us`
WHERE `us`.`is_delete` =0
ORDER BY `vName` ASC
INFO - 2018-02-16 12:15:15 --> Language file loaded: language/english/db_lang.php
INFO - 2018-02-16 12:17:08 --> Config Class Initialized
INFO - 2018-02-16 12:17:08 --> Hooks Class Initialized
DEBUG - 2018-02-16 12:17:08 --> UTF-8 Support Enabled
INFO - 2018-02-16 12:17:08 --> Utf8 Class Initialized
INFO - 2018-02-16 12:17:08 --> URI Class Initialized
INFO - 2018-02-16 12:17:08 --> Router Class Initialized
INFO - 2018-02-16 12:17:08 --> Output Class Initialized
INFO - 2018-02-16 12:17:08 --> Security Class Initialized
DEBUG - 2018-02-16 12:17:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-16 12:17:08 --> Input Class Initialized
INFO - 2018-02-16 12:17:08 --> Language Class Initialized
INFO - 2018-02-16 12:17:08 --> Loader Class Initialized
INFO - 2018-02-16 12:17:08 --> Helper loaded: url_helper
INFO - 2018-02-16 12:17:08 --> Helper loaded: file_helper
INFO - 2018-02-16 12:17:08 --> Helper loaded: email_helper
INFO - 2018-02-16 12:17:08 --> Helper loaded: common_helper
INFO - 2018-02-16 12:17:08 --> Database Driver Class Initialized
DEBUG - 2018-02-16 12:17:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-16 12:17:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-16 12:17:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-16 12:17:08 --> Pagination Class Initialized
INFO - 2018-02-16 12:17:08 --> Helper loaded: form_helper
INFO - 2018-02-16 12:17:08 --> Form Validation Class Initialized
INFO - 2018-02-16 12:17:08 --> Model Class Initialized
INFO - 2018-02-16 12:17:08 --> Controller Class Initialized
INFO - 2018-02-16 12:17:08 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-16 12:17:08 --> Model Class Initialized
INFO - 2018-02-16 12:17:08 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-16 12:17:08 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-16 12:17:08 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-16 12:17:08 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-16 12:17:08 --> File loaded: /var/www/html/project/radio/application/views/user/index.php
INFO - 2018-02-16 12:17:08 --> Final output sent to browser
DEBUG - 2018-02-16 12:17:08 --> Total execution time: 0.0074
INFO - 2018-02-16 12:17:08 --> Config Class Initialized
INFO - 2018-02-16 12:17:08 --> Hooks Class Initialized
DEBUG - 2018-02-16 12:17:08 --> UTF-8 Support Enabled
INFO - 2018-02-16 12:17:08 --> Utf8 Class Initialized
INFO - 2018-02-16 12:17:08 --> URI Class Initialized
INFO - 2018-02-16 12:17:08 --> Router Class Initialized
INFO - 2018-02-16 12:17:08 --> Output Class Initialized
INFO - 2018-02-16 12:17:08 --> Security Class Initialized
DEBUG - 2018-02-16 12:17:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-16 12:17:08 --> Input Class Initialized
INFO - 2018-02-16 12:17:08 --> Language Class Initialized
INFO - 2018-02-16 12:17:08 --> Loader Class Initialized
INFO - 2018-02-16 12:17:08 --> Helper loaded: url_helper
INFO - 2018-02-16 12:17:08 --> Helper loaded: file_helper
INFO - 2018-02-16 12:17:08 --> Helper loaded: email_helper
INFO - 2018-02-16 12:17:08 --> Helper loaded: common_helper
INFO - 2018-02-16 12:17:08 --> Database Driver Class Initialized
DEBUG - 2018-02-16 12:17:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-16 12:17:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-16 12:17:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-16 12:17:08 --> Pagination Class Initialized
INFO - 2018-02-16 12:17:08 --> Helper loaded: form_helper
INFO - 2018-02-16 12:17:08 --> Form Validation Class Initialized
INFO - 2018-02-16 12:17:08 --> Model Class Initialized
INFO - 2018-02-16 12:17:08 --> Controller Class Initialized
INFO - 2018-02-16 12:17:08 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-16 12:17:08 --> Model Class Initialized
INFO - 2018-02-16 12:20:13 --> Config Class Initialized
INFO - 2018-02-16 12:20:13 --> Hooks Class Initialized
DEBUG - 2018-02-16 12:20:13 --> UTF-8 Support Enabled
INFO - 2018-02-16 12:20:13 --> Utf8 Class Initialized
INFO - 2018-02-16 12:20:13 --> URI Class Initialized
INFO - 2018-02-16 12:20:13 --> Router Class Initialized
INFO - 2018-02-16 12:20:13 --> Output Class Initialized
INFO - 2018-02-16 12:20:13 --> Security Class Initialized
DEBUG - 2018-02-16 12:20:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-16 12:20:13 --> Input Class Initialized
INFO - 2018-02-16 12:20:13 --> Language Class Initialized
INFO - 2018-02-16 12:20:13 --> Loader Class Initialized
INFO - 2018-02-16 12:20:13 --> Helper loaded: url_helper
INFO - 2018-02-16 12:20:13 --> Helper loaded: file_helper
INFO - 2018-02-16 12:20:13 --> Helper loaded: email_helper
INFO - 2018-02-16 12:20:13 --> Helper loaded: common_helper
INFO - 2018-02-16 12:20:13 --> Database Driver Class Initialized
DEBUG - 2018-02-16 12:20:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-16 12:20:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-16 12:20:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-16 12:20:13 --> Pagination Class Initialized
INFO - 2018-02-16 12:20:13 --> Helper loaded: form_helper
INFO - 2018-02-16 12:20:13 --> Form Validation Class Initialized
INFO - 2018-02-16 12:20:13 --> Model Class Initialized
INFO - 2018-02-16 12:20:13 --> Controller Class Initialized
INFO - 2018-02-16 12:20:13 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-16 12:20:13 --> Model Class Initialized
INFO - 2018-02-16 12:20:13 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-16 12:20:13 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-16 12:20:13 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-16 12:20:13 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-16 12:20:13 --> File loaded: /var/www/html/project/radio/application/views/category/index.php
INFO - 2018-02-16 12:20:13 --> Final output sent to browser
DEBUG - 2018-02-16 12:20:13 --> Total execution time: 0.0062
INFO - 2018-02-16 12:21:09 --> Config Class Initialized
INFO - 2018-02-16 12:21:09 --> Hooks Class Initialized
DEBUG - 2018-02-16 12:21:09 --> UTF-8 Support Enabled
INFO - 2018-02-16 12:21:09 --> Utf8 Class Initialized
INFO - 2018-02-16 12:21:09 --> URI Class Initialized
INFO - 2018-02-16 12:21:09 --> Router Class Initialized
INFO - 2018-02-16 12:21:09 --> Output Class Initialized
INFO - 2018-02-16 12:21:09 --> Security Class Initialized
DEBUG - 2018-02-16 12:21:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-16 12:21:09 --> Input Class Initialized
INFO - 2018-02-16 12:21:09 --> Language Class Initialized
INFO - 2018-02-16 12:21:09 --> Loader Class Initialized
INFO - 2018-02-16 12:21:09 --> Helper loaded: url_helper
INFO - 2018-02-16 12:21:09 --> Helper loaded: file_helper
INFO - 2018-02-16 12:21:09 --> Helper loaded: email_helper
INFO - 2018-02-16 12:21:09 --> Helper loaded: common_helper
INFO - 2018-02-16 12:21:09 --> Database Driver Class Initialized
DEBUG - 2018-02-16 12:21:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-16 12:21:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-16 12:21:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-16 12:21:09 --> Pagination Class Initialized
INFO - 2018-02-16 12:21:09 --> Helper loaded: form_helper
INFO - 2018-02-16 12:21:09 --> Form Validation Class Initialized
INFO - 2018-02-16 12:21:09 --> Model Class Initialized
INFO - 2018-02-16 12:21:09 --> Controller Class Initialized
INFO - 2018-02-16 12:21:09 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-16 12:21:09 --> Model Class Initialized
INFO - 2018-02-16 12:21:09 --> Model Class Initialized
INFO - 2018-02-16 12:21:09 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-16 12:21:09 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-16 12:21:09 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-16 12:21:09 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-16 12:21:09 --> File loaded: /var/www/html/project/radio/application/views/subcategory/index.php
INFO - 2018-02-16 12:21:09 --> Final output sent to browser
DEBUG - 2018-02-16 12:21:09 --> Total execution time: 0.0074
INFO - 2018-02-16 12:25:02 --> Config Class Initialized
INFO - 2018-02-16 12:25:02 --> Hooks Class Initialized
DEBUG - 2018-02-16 12:25:02 --> UTF-8 Support Enabled
INFO - 2018-02-16 12:25:02 --> Utf8 Class Initialized
INFO - 2018-02-16 12:25:02 --> URI Class Initialized
INFO - 2018-02-16 12:25:02 --> Router Class Initialized
INFO - 2018-02-16 12:25:02 --> Output Class Initialized
INFO - 2018-02-16 12:25:02 --> Security Class Initialized
DEBUG - 2018-02-16 12:25:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-16 12:25:02 --> Input Class Initialized
INFO - 2018-02-16 12:25:02 --> Language Class Initialized
INFO - 2018-02-16 12:25:02 --> Loader Class Initialized
INFO - 2018-02-16 12:25:02 --> Helper loaded: url_helper
INFO - 2018-02-16 12:25:02 --> Helper loaded: file_helper
INFO - 2018-02-16 12:25:02 --> Helper loaded: email_helper
INFO - 2018-02-16 12:25:02 --> Helper loaded: common_helper
INFO - 2018-02-16 12:25:02 --> Database Driver Class Initialized
DEBUG - 2018-02-16 12:25:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-16 12:25:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-16 12:25:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-16 12:25:02 --> Pagination Class Initialized
INFO - 2018-02-16 12:25:02 --> Helper loaded: form_helper
INFO - 2018-02-16 12:25:02 --> Form Validation Class Initialized
INFO - 2018-02-16 12:25:02 --> Model Class Initialized
INFO - 2018-02-16 12:25:02 --> Controller Class Initialized
INFO - 2018-02-16 12:25:02 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-16 12:25:02 --> Model Class Initialized
INFO - 2018-02-16 12:25:02 --> Model Class Initialized
INFO - 2018-02-16 12:25:02 --> Model Class Initialized
INFO - 2018-02-16 12:25:02 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-16 12:25:02 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-16 12:25:02 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-16 12:25:02 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-16 12:25:02 --> File loaded: /var/www/html/project/radio/application/views/tracks/index.php
INFO - 2018-02-16 12:25:02 --> Final output sent to browser
DEBUG - 2018-02-16 12:25:02 --> Total execution time: 0.0061
INFO - 2018-02-16 12:25:02 --> Config Class Initialized
INFO - 2018-02-16 12:25:02 --> Hooks Class Initialized
DEBUG - 2018-02-16 12:25:02 --> UTF-8 Support Enabled
INFO - 2018-02-16 12:25:02 --> Utf8 Class Initialized
INFO - 2018-02-16 12:25:02 --> URI Class Initialized
INFO - 2018-02-16 12:25:02 --> Router Class Initialized
INFO - 2018-02-16 12:25:02 --> Output Class Initialized
INFO - 2018-02-16 12:25:02 --> Security Class Initialized
DEBUG - 2018-02-16 12:25:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-16 12:25:02 --> Input Class Initialized
INFO - 2018-02-16 12:25:02 --> Language Class Initialized
INFO - 2018-02-16 12:25:02 --> Loader Class Initialized
INFO - 2018-02-16 12:25:02 --> Helper loaded: url_helper
INFO - 2018-02-16 12:25:02 --> Helper loaded: file_helper
INFO - 2018-02-16 12:25:02 --> Helper loaded: email_helper
INFO - 2018-02-16 12:25:02 --> Helper loaded: common_helper
INFO - 2018-02-16 12:25:02 --> Database Driver Class Initialized
DEBUG - 2018-02-16 12:25:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-16 12:25:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-16 12:25:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-16 12:25:02 --> Pagination Class Initialized
INFO - 2018-02-16 12:25:02 --> Helper loaded: form_helper
INFO - 2018-02-16 12:25:02 --> Form Validation Class Initialized
INFO - 2018-02-16 12:25:02 --> Model Class Initialized
INFO - 2018-02-16 12:25:02 --> Controller Class Initialized
INFO - 2018-02-16 12:25:02 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-16 12:25:02 --> Model Class Initialized
INFO - 2018-02-16 12:25:02 --> Model Class Initialized
INFO - 2018-02-16 12:25:02 --> Model Class Initialized
INFO - 2018-02-16 12:25:32 --> Config Class Initialized
INFO - 2018-02-16 12:25:32 --> Hooks Class Initialized
DEBUG - 2018-02-16 12:25:32 --> UTF-8 Support Enabled
INFO - 2018-02-16 12:25:32 --> Utf8 Class Initialized
INFO - 2018-02-16 12:25:32 --> URI Class Initialized
INFO - 2018-02-16 12:25:32 --> Router Class Initialized
INFO - 2018-02-16 12:25:32 --> Output Class Initialized
INFO - 2018-02-16 12:25:32 --> Security Class Initialized
DEBUG - 2018-02-16 12:25:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-16 12:25:32 --> Input Class Initialized
INFO - 2018-02-16 12:25:32 --> Language Class Initialized
INFO - 2018-02-16 12:25:32 --> Loader Class Initialized
INFO - 2018-02-16 12:25:32 --> Helper loaded: url_helper
INFO - 2018-02-16 12:25:32 --> Helper loaded: file_helper
INFO - 2018-02-16 12:25:32 --> Helper loaded: email_helper
INFO - 2018-02-16 12:25:32 --> Helper loaded: common_helper
INFO - 2018-02-16 12:25:32 --> Database Driver Class Initialized
DEBUG - 2018-02-16 12:25:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-16 12:25:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-16 12:25:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-16 12:25:32 --> Pagination Class Initialized
INFO - 2018-02-16 12:25:32 --> Helper loaded: form_helper
INFO - 2018-02-16 12:25:32 --> Form Validation Class Initialized
INFO - 2018-02-16 12:25:32 --> Model Class Initialized
INFO - 2018-02-16 12:25:32 --> Controller Class Initialized
INFO - 2018-02-16 12:25:32 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-16 12:25:32 --> Model Class Initialized
INFO - 2018-02-16 12:25:32 --> Model Class Initialized
INFO - 2018-02-16 12:25:32 --> Model Class Initialized
INFO - 2018-02-16 12:25:32 --> Model Class Initialized
INFO - 2018-02-16 12:25:32 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-16 12:25:32 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-16 12:25:32 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-16 12:25:32 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-16 12:25:32 --> File loaded: /var/www/html/project/radio/application/views/dashboard/index.php
INFO - 2018-02-16 12:25:32 --> Final output sent to browser
DEBUG - 2018-02-16 12:25:32 --> Total execution time: 0.0103
INFO - 2018-02-16 12:25:38 --> Config Class Initialized
INFO - 2018-02-16 12:25:38 --> Hooks Class Initialized
DEBUG - 2018-02-16 12:25:38 --> UTF-8 Support Enabled
INFO - 2018-02-16 12:25:38 --> Utf8 Class Initialized
INFO - 2018-02-16 12:25:38 --> URI Class Initialized
INFO - 2018-02-16 12:25:38 --> Router Class Initialized
INFO - 2018-02-16 12:25:38 --> Output Class Initialized
INFO - 2018-02-16 12:25:38 --> Security Class Initialized
DEBUG - 2018-02-16 12:25:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-16 12:25:38 --> Input Class Initialized
INFO - 2018-02-16 12:25:38 --> Language Class Initialized
INFO - 2018-02-16 12:25:38 --> Loader Class Initialized
INFO - 2018-02-16 12:25:38 --> Helper loaded: url_helper
INFO - 2018-02-16 12:25:38 --> Helper loaded: file_helper
INFO - 2018-02-16 12:25:38 --> Helper loaded: email_helper
INFO - 2018-02-16 12:25:38 --> Helper loaded: common_helper
INFO - 2018-02-16 12:25:38 --> Database Driver Class Initialized
DEBUG - 2018-02-16 12:25:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-16 12:25:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-16 12:25:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-16 12:25:38 --> Pagination Class Initialized
INFO - 2018-02-16 12:25:38 --> Helper loaded: form_helper
INFO - 2018-02-16 12:25:38 --> Form Validation Class Initialized
INFO - 2018-02-16 12:25:38 --> Model Class Initialized
INFO - 2018-02-16 12:25:38 --> Controller Class Initialized
INFO - 2018-02-16 12:25:38 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-16 12:25:38 --> Model Class Initialized
INFO - 2018-02-16 12:25:38 --> Model Class Initialized
INFO - 2018-02-16 12:25:38 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-16 12:25:38 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-16 12:25:38 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-16 12:25:38 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-16 12:25:38 --> File loaded: /var/www/html/project/radio/application/views/subcategory/index.php
INFO - 2018-02-16 12:25:38 --> Final output sent to browser
DEBUG - 2018-02-16 12:25:38 --> Total execution time: 0.0056
INFO - 2018-02-16 12:25:40 --> Config Class Initialized
INFO - 2018-02-16 12:25:40 --> Hooks Class Initialized
DEBUG - 2018-02-16 12:25:40 --> UTF-8 Support Enabled
INFO - 2018-02-16 12:25:40 --> Utf8 Class Initialized
INFO - 2018-02-16 12:25:40 --> URI Class Initialized
INFO - 2018-02-16 12:25:40 --> Router Class Initialized
INFO - 2018-02-16 12:25:40 --> Output Class Initialized
INFO - 2018-02-16 12:25:40 --> Security Class Initialized
DEBUG - 2018-02-16 12:25:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-16 12:25:40 --> Input Class Initialized
INFO - 2018-02-16 12:25:40 --> Language Class Initialized
INFO - 2018-02-16 12:25:40 --> Loader Class Initialized
INFO - 2018-02-16 12:25:40 --> Helper loaded: url_helper
INFO - 2018-02-16 12:25:40 --> Helper loaded: file_helper
INFO - 2018-02-16 12:25:40 --> Helper loaded: email_helper
INFO - 2018-02-16 12:25:40 --> Helper loaded: common_helper
INFO - 2018-02-16 12:25:40 --> Database Driver Class Initialized
DEBUG - 2018-02-16 12:25:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-16 12:25:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-16 12:25:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-16 12:25:40 --> Pagination Class Initialized
INFO - 2018-02-16 12:25:40 --> Helper loaded: form_helper
INFO - 2018-02-16 12:25:40 --> Form Validation Class Initialized
INFO - 2018-02-16 12:25:40 --> Model Class Initialized
INFO - 2018-02-16 12:25:40 --> Controller Class Initialized
INFO - 2018-02-16 12:25:40 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-16 12:25:40 --> Model Class Initialized
INFO - 2018-02-16 12:25:40 --> Model Class Initialized
INFO - 2018-02-16 12:25:40 --> Model Class Initialized
INFO - 2018-02-16 12:25:40 --> Model Class Initialized
INFO - 2018-02-16 12:25:40 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-16 12:25:40 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-16 12:25:40 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-16 12:25:40 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-16 12:25:40 --> File loaded: /var/www/html/project/radio/application/views/dashboard/index.php
INFO - 2018-02-16 12:25:40 --> Final output sent to browser
DEBUG - 2018-02-16 12:25:40 --> Total execution time: 0.0072
INFO - 2018-02-16 12:25:41 --> Config Class Initialized
INFO - 2018-02-16 12:25:41 --> Hooks Class Initialized
DEBUG - 2018-02-16 12:25:41 --> UTF-8 Support Enabled
INFO - 2018-02-16 12:25:41 --> Utf8 Class Initialized
INFO - 2018-02-16 12:25:41 --> URI Class Initialized
INFO - 2018-02-16 12:25:41 --> Router Class Initialized
INFO - 2018-02-16 12:25:41 --> Output Class Initialized
INFO - 2018-02-16 12:25:41 --> Security Class Initialized
DEBUG - 2018-02-16 12:25:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-16 12:25:41 --> Input Class Initialized
INFO - 2018-02-16 12:25:41 --> Language Class Initialized
INFO - 2018-02-16 12:25:41 --> Loader Class Initialized
INFO - 2018-02-16 12:25:41 --> Helper loaded: url_helper
INFO - 2018-02-16 12:25:41 --> Helper loaded: file_helper
INFO - 2018-02-16 12:25:41 --> Helper loaded: email_helper
INFO - 2018-02-16 12:25:41 --> Helper loaded: common_helper
INFO - 2018-02-16 12:25:41 --> Database Driver Class Initialized
DEBUG - 2018-02-16 12:25:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-16 12:25:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-16 12:25:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-16 12:25:41 --> Pagination Class Initialized
INFO - 2018-02-16 12:25:41 --> Helper loaded: form_helper
INFO - 2018-02-16 12:25:41 --> Form Validation Class Initialized
INFO - 2018-02-16 12:25:41 --> Model Class Initialized
INFO - 2018-02-16 12:25:41 --> Controller Class Initialized
INFO - 2018-02-16 12:25:41 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-16 12:25:41 --> Model Class Initialized
INFO - 2018-02-16 12:25:41 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-16 12:25:41 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-16 12:25:41 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-16 12:25:41 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-16 12:25:41 --> File loaded: /var/www/html/project/radio/application/views/category/index.php
INFO - 2018-02-16 12:25:41 --> Final output sent to browser
DEBUG - 2018-02-16 12:25:41 --> Total execution time: 0.0051
INFO - 2018-02-16 12:25:42 --> Config Class Initialized
INFO - 2018-02-16 12:25:42 --> Hooks Class Initialized
DEBUG - 2018-02-16 12:25:42 --> UTF-8 Support Enabled
INFO - 2018-02-16 12:25:42 --> Utf8 Class Initialized
INFO - 2018-02-16 12:25:42 --> URI Class Initialized
INFO - 2018-02-16 12:25:42 --> Router Class Initialized
INFO - 2018-02-16 12:25:42 --> Output Class Initialized
INFO - 2018-02-16 12:25:42 --> Security Class Initialized
DEBUG - 2018-02-16 12:25:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-16 12:25:42 --> Input Class Initialized
INFO - 2018-02-16 12:25:42 --> Language Class Initialized
INFO - 2018-02-16 12:25:42 --> Loader Class Initialized
INFO - 2018-02-16 12:25:42 --> Helper loaded: url_helper
INFO - 2018-02-16 12:25:42 --> Helper loaded: file_helper
INFO - 2018-02-16 12:25:42 --> Helper loaded: email_helper
INFO - 2018-02-16 12:25:42 --> Helper loaded: common_helper
INFO - 2018-02-16 12:25:42 --> Database Driver Class Initialized
DEBUG - 2018-02-16 12:25:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-16 12:25:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-16 12:25:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-16 12:25:42 --> Pagination Class Initialized
INFO - 2018-02-16 12:25:42 --> Helper loaded: form_helper
INFO - 2018-02-16 12:25:42 --> Form Validation Class Initialized
INFO - 2018-02-16 12:25:42 --> Model Class Initialized
INFO - 2018-02-16 12:25:42 --> Controller Class Initialized
INFO - 2018-02-16 12:25:42 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-16 12:25:42 --> Model Class Initialized
INFO - 2018-02-16 12:25:42 --> Model Class Initialized
INFO - 2018-02-16 12:25:42 --> Model Class Initialized
INFO - 2018-02-16 12:25:42 --> Model Class Initialized
INFO - 2018-02-16 12:25:42 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-16 12:25:42 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-16 12:25:42 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-16 12:25:42 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-16 12:25:42 --> File loaded: /var/www/html/project/radio/application/views/dashboard/index.php
INFO - 2018-02-16 12:25:42 --> Final output sent to browser
DEBUG - 2018-02-16 12:25:42 --> Total execution time: 0.0055
INFO - 2018-02-16 12:25:43 --> Config Class Initialized
INFO - 2018-02-16 12:25:43 --> Hooks Class Initialized
DEBUG - 2018-02-16 12:25:43 --> UTF-8 Support Enabled
INFO - 2018-02-16 12:25:43 --> Utf8 Class Initialized
INFO - 2018-02-16 12:25:43 --> URI Class Initialized
INFO - 2018-02-16 12:25:43 --> Router Class Initialized
INFO - 2018-02-16 12:25:43 --> Output Class Initialized
INFO - 2018-02-16 12:25:43 --> Security Class Initialized
DEBUG - 2018-02-16 12:25:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-16 12:25:43 --> Input Class Initialized
INFO - 2018-02-16 12:25:43 --> Language Class Initialized
INFO - 2018-02-16 12:25:43 --> Loader Class Initialized
INFO - 2018-02-16 12:25:43 --> Helper loaded: url_helper
INFO - 2018-02-16 12:25:43 --> Helper loaded: file_helper
INFO - 2018-02-16 12:25:43 --> Helper loaded: email_helper
INFO - 2018-02-16 12:25:43 --> Helper loaded: common_helper
INFO - 2018-02-16 12:25:43 --> Database Driver Class Initialized
DEBUG - 2018-02-16 12:25:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-16 12:25:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-16 12:25:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-16 12:25:43 --> Pagination Class Initialized
INFO - 2018-02-16 12:25:43 --> Helper loaded: form_helper
INFO - 2018-02-16 12:25:43 --> Form Validation Class Initialized
INFO - 2018-02-16 12:25:43 --> Model Class Initialized
INFO - 2018-02-16 12:25:43 --> Controller Class Initialized
INFO - 2018-02-16 12:25:43 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-16 12:25:43 --> Model Class Initialized
INFO - 2018-02-16 12:25:43 --> Model Class Initialized
INFO - 2018-02-16 12:25:43 --> Model Class Initialized
INFO - 2018-02-16 12:25:43 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-16 12:25:43 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-16 12:25:43 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-16 12:25:43 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-16 12:25:43 --> File loaded: /var/www/html/project/radio/application/views/tracks/index.php
INFO - 2018-02-16 12:25:43 --> Final output sent to browser
DEBUG - 2018-02-16 12:25:43 --> Total execution time: 0.0050
INFO - 2018-02-16 12:25:44 --> Config Class Initialized
INFO - 2018-02-16 12:25:44 --> Hooks Class Initialized
DEBUG - 2018-02-16 12:25:44 --> UTF-8 Support Enabled
INFO - 2018-02-16 12:25:44 --> Utf8 Class Initialized
INFO - 2018-02-16 12:25:44 --> URI Class Initialized
INFO - 2018-02-16 12:25:44 --> Router Class Initialized
INFO - 2018-02-16 12:25:44 --> Output Class Initialized
INFO - 2018-02-16 12:25:44 --> Security Class Initialized
DEBUG - 2018-02-16 12:25:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-16 12:25:44 --> Input Class Initialized
INFO - 2018-02-16 12:25:44 --> Language Class Initialized
INFO - 2018-02-16 12:25:44 --> Loader Class Initialized
INFO - 2018-02-16 12:25:44 --> Helper loaded: url_helper
INFO - 2018-02-16 12:25:44 --> Helper loaded: file_helper
INFO - 2018-02-16 12:25:44 --> Helper loaded: email_helper
INFO - 2018-02-16 12:25:44 --> Helper loaded: common_helper
INFO - 2018-02-16 12:25:44 --> Database Driver Class Initialized
DEBUG - 2018-02-16 12:25:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-16 12:25:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-16 12:25:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-16 12:25:44 --> Pagination Class Initialized
INFO - 2018-02-16 12:25:44 --> Helper loaded: form_helper
INFO - 2018-02-16 12:25:44 --> Form Validation Class Initialized
INFO - 2018-02-16 12:25:44 --> Model Class Initialized
INFO - 2018-02-16 12:25:44 --> Controller Class Initialized
INFO - 2018-02-16 12:25:44 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-16 12:25:44 --> Model Class Initialized
INFO - 2018-02-16 12:25:44 --> Model Class Initialized
INFO - 2018-02-16 12:25:44 --> Model Class Initialized
INFO - 2018-02-16 12:25:46 --> Config Class Initialized
INFO - 2018-02-16 12:25:46 --> Hooks Class Initialized
DEBUG - 2018-02-16 12:25:46 --> UTF-8 Support Enabled
INFO - 2018-02-16 12:25:46 --> Utf8 Class Initialized
INFO - 2018-02-16 12:25:46 --> URI Class Initialized
INFO - 2018-02-16 12:25:46 --> Router Class Initialized
INFO - 2018-02-16 12:25:46 --> Output Class Initialized
INFO - 2018-02-16 12:25:46 --> Security Class Initialized
DEBUG - 2018-02-16 12:25:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-16 12:25:46 --> Input Class Initialized
INFO - 2018-02-16 12:25:46 --> Language Class Initialized
INFO - 2018-02-16 12:25:46 --> Loader Class Initialized
INFO - 2018-02-16 12:25:46 --> Helper loaded: url_helper
INFO - 2018-02-16 12:25:46 --> Helper loaded: file_helper
INFO - 2018-02-16 12:25:46 --> Helper loaded: email_helper
INFO - 2018-02-16 12:25:46 --> Helper loaded: common_helper
INFO - 2018-02-16 12:25:46 --> Database Driver Class Initialized
DEBUG - 2018-02-16 12:25:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-16 12:25:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-16 12:25:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-16 12:25:46 --> Pagination Class Initialized
INFO - 2018-02-16 12:25:46 --> Helper loaded: form_helper
INFO - 2018-02-16 12:25:46 --> Form Validation Class Initialized
INFO - 2018-02-16 12:25:46 --> Model Class Initialized
INFO - 2018-02-16 12:25:46 --> Controller Class Initialized
INFO - 2018-02-16 12:25:46 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-16 12:25:46 --> Model Class Initialized
INFO - 2018-02-16 12:25:46 --> Model Class Initialized
INFO - 2018-02-16 12:25:46 --> Model Class Initialized
INFO - 2018-02-16 12:25:46 --> Model Class Initialized
INFO - 2018-02-16 12:25:46 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-16 12:25:46 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-16 12:25:46 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-16 12:25:46 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-16 12:25:46 --> File loaded: /var/www/html/project/radio/application/views/dashboard/index.php
INFO - 2018-02-16 12:25:46 --> Final output sent to browser
DEBUG - 2018-02-16 12:25:46 --> Total execution time: 0.0081
INFO - 2018-02-16 12:26:34 --> Config Class Initialized
INFO - 2018-02-16 12:26:34 --> Hooks Class Initialized
DEBUG - 2018-02-16 12:26:34 --> UTF-8 Support Enabled
INFO - 2018-02-16 12:26:34 --> Utf8 Class Initialized
INFO - 2018-02-16 12:26:34 --> URI Class Initialized
INFO - 2018-02-16 12:26:34 --> Router Class Initialized
INFO - 2018-02-16 12:26:34 --> Output Class Initialized
INFO - 2018-02-16 12:26:34 --> Security Class Initialized
DEBUG - 2018-02-16 12:26:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-16 12:26:34 --> Input Class Initialized
INFO - 2018-02-16 12:26:34 --> Language Class Initialized
INFO - 2018-02-16 12:26:34 --> Loader Class Initialized
INFO - 2018-02-16 12:26:34 --> Helper loaded: url_helper
INFO - 2018-02-16 12:26:34 --> Helper loaded: file_helper
INFO - 2018-02-16 12:26:34 --> Helper loaded: email_helper
INFO - 2018-02-16 12:26:34 --> Helper loaded: common_helper
INFO - 2018-02-16 12:26:34 --> Database Driver Class Initialized
DEBUG - 2018-02-16 12:26:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-16 12:26:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-16 12:26:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-16 12:26:34 --> Pagination Class Initialized
INFO - 2018-02-16 12:26:34 --> Helper loaded: form_helper
INFO - 2018-02-16 12:26:34 --> Form Validation Class Initialized
INFO - 2018-02-16 12:26:34 --> Model Class Initialized
INFO - 2018-02-16 12:26:34 --> Controller Class Initialized
INFO - 2018-02-16 12:26:34 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-16 12:26:34 --> Model Class Initialized
INFO - 2018-02-16 12:26:34 --> Model Class Initialized
INFO - 2018-02-16 12:26:34 --> Model Class Initialized
INFO - 2018-02-16 12:26:34 --> Model Class Initialized
INFO - 2018-02-16 12:26:34 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-16 12:26:34 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-16 12:26:34 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-16 12:26:34 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-16 12:26:34 --> File loaded: /var/www/html/project/radio/application/views/dashboard/index.php
INFO - 2018-02-16 12:26:34 --> Final output sent to browser
DEBUG - 2018-02-16 12:26:34 --> Total execution time: 0.0075
INFO - 2018-02-16 12:26:41 --> Config Class Initialized
INFO - 2018-02-16 12:26:41 --> Hooks Class Initialized
DEBUG - 2018-02-16 12:26:41 --> UTF-8 Support Enabled
INFO - 2018-02-16 12:26:41 --> Utf8 Class Initialized
INFO - 2018-02-16 12:26:41 --> URI Class Initialized
INFO - 2018-02-16 12:26:41 --> Router Class Initialized
INFO - 2018-02-16 12:26:41 --> Output Class Initialized
INFO - 2018-02-16 12:26:41 --> Security Class Initialized
DEBUG - 2018-02-16 12:26:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-16 12:26:41 --> Input Class Initialized
INFO - 2018-02-16 12:26:41 --> Language Class Initialized
INFO - 2018-02-16 12:26:41 --> Loader Class Initialized
INFO - 2018-02-16 12:26:41 --> Helper loaded: url_helper
INFO - 2018-02-16 12:26:41 --> Helper loaded: file_helper
INFO - 2018-02-16 12:26:41 --> Helper loaded: email_helper
INFO - 2018-02-16 12:26:41 --> Helper loaded: common_helper
INFO - 2018-02-16 12:26:41 --> Database Driver Class Initialized
DEBUG - 2018-02-16 12:26:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-16 12:26:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-16 12:26:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-16 12:26:41 --> Pagination Class Initialized
INFO - 2018-02-16 12:26:41 --> Helper loaded: form_helper
INFO - 2018-02-16 12:26:41 --> Form Validation Class Initialized
INFO - 2018-02-16 12:26:41 --> Model Class Initialized
INFO - 2018-02-16 12:26:41 --> Controller Class Initialized
INFO - 2018-02-16 12:26:41 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-16 12:26:41 --> Model Class Initialized
INFO - 2018-02-16 12:26:41 --> Model Class Initialized
INFO - 2018-02-16 12:26:41 --> Model Class Initialized
INFO - 2018-02-16 12:26:41 --> Model Class Initialized
INFO - 2018-02-16 12:26:41 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-16 12:26:41 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-16 12:26:41 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-16 12:26:41 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-16 12:26:41 --> File loaded: /var/www/html/project/radio/application/views/dashboard/index.php
INFO - 2018-02-16 12:26:41 --> Final output sent to browser
DEBUG - 2018-02-16 12:26:41 --> Total execution time: 0.0078
INFO - 2018-02-16 12:30:14 --> Config Class Initialized
INFO - 2018-02-16 12:30:14 --> Hooks Class Initialized
DEBUG - 2018-02-16 12:30:14 --> UTF-8 Support Enabled
INFO - 2018-02-16 12:30:14 --> Utf8 Class Initialized
INFO - 2018-02-16 12:30:14 --> URI Class Initialized
INFO - 2018-02-16 12:30:14 --> Router Class Initialized
INFO - 2018-02-16 12:30:14 --> Output Class Initialized
INFO - 2018-02-16 12:30:14 --> Security Class Initialized
DEBUG - 2018-02-16 12:30:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-16 12:30:14 --> Input Class Initialized
INFO - 2018-02-16 12:30:14 --> Language Class Initialized
INFO - 2018-02-16 12:30:14 --> Loader Class Initialized
INFO - 2018-02-16 12:30:14 --> Helper loaded: url_helper
INFO - 2018-02-16 12:30:14 --> Helper loaded: file_helper
INFO - 2018-02-16 12:30:14 --> Helper loaded: email_helper
INFO - 2018-02-16 12:30:14 --> Helper loaded: common_helper
INFO - 2018-02-16 12:30:14 --> Database Driver Class Initialized
DEBUG - 2018-02-16 12:30:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-16 12:30:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-16 12:30:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-16 12:30:14 --> Pagination Class Initialized
INFO - 2018-02-16 12:30:14 --> Helper loaded: form_helper
INFO - 2018-02-16 12:30:14 --> Form Validation Class Initialized
INFO - 2018-02-16 12:30:14 --> Model Class Initialized
INFO - 2018-02-16 12:30:14 --> Controller Class Initialized
INFO - 2018-02-16 12:30:14 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-16 12:30:14 --> Model Class Initialized
INFO - 2018-02-16 12:30:14 --> Model Class Initialized
INFO - 2018-02-16 12:30:14 --> Model Class Initialized
INFO - 2018-02-16 12:30:14 --> Model Class Initialized
INFO - 2018-02-16 12:30:14 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-16 12:30:14 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-16 12:30:14 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-16 12:30:14 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-16 12:30:14 --> File loaded: /var/www/html/project/radio/application/views/dashboard/index.php
INFO - 2018-02-16 12:30:14 --> Final output sent to browser
DEBUG - 2018-02-16 12:30:14 --> Total execution time: 0.0114
INFO - 2018-02-16 12:37:57 --> Config Class Initialized
INFO - 2018-02-16 12:37:57 --> Hooks Class Initialized
DEBUG - 2018-02-16 12:37:57 --> UTF-8 Support Enabled
INFO - 2018-02-16 12:37:57 --> Utf8 Class Initialized
INFO - 2018-02-16 12:37:57 --> URI Class Initialized
INFO - 2018-02-16 12:37:57 --> Router Class Initialized
INFO - 2018-02-16 12:37:57 --> Output Class Initialized
INFO - 2018-02-16 12:37:57 --> Security Class Initialized
DEBUG - 2018-02-16 12:37:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-16 12:37:57 --> Input Class Initialized
INFO - 2018-02-16 12:37:57 --> Language Class Initialized
INFO - 2018-02-16 12:37:57 --> Loader Class Initialized
INFO - 2018-02-16 12:37:57 --> Helper loaded: url_helper
INFO - 2018-02-16 12:37:57 --> Helper loaded: file_helper
INFO - 2018-02-16 12:37:57 --> Helper loaded: email_helper
INFO - 2018-02-16 12:37:57 --> Helper loaded: common_helper
INFO - 2018-02-16 12:37:57 --> Database Driver Class Initialized
DEBUG - 2018-02-16 12:37:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-16 12:37:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-16 12:37:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-16 12:37:57 --> Pagination Class Initialized
INFO - 2018-02-16 12:37:57 --> Helper loaded: form_helper
INFO - 2018-02-16 12:37:57 --> Form Validation Class Initialized
INFO - 2018-02-16 12:37:57 --> Model Class Initialized
INFO - 2018-02-16 12:37:57 --> Controller Class Initialized
INFO - 2018-02-16 12:37:57 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-16 12:37:57 --> Model Class Initialized
INFO - 2018-02-16 12:37:57 --> Model Class Initialized
INFO - 2018-02-16 12:37:57 --> Model Class Initialized
INFO - 2018-02-16 12:37:57 --> Model Class Initialized
INFO - 2018-02-16 12:37:57 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-16 12:37:57 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-16 12:37:57 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-16 12:37:57 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-16 12:37:57 --> File loaded: /var/www/html/project/radio/application/views/dashboard/index.php
INFO - 2018-02-16 12:37:57 --> Final output sent to browser
DEBUG - 2018-02-16 12:37:57 --> Total execution time: 0.0071
INFO - 2018-02-16 12:38:01 --> Config Class Initialized
INFO - 2018-02-16 12:38:01 --> Hooks Class Initialized
DEBUG - 2018-02-16 12:38:01 --> UTF-8 Support Enabled
INFO - 2018-02-16 12:38:01 --> Utf8 Class Initialized
INFO - 2018-02-16 12:38:01 --> URI Class Initialized
INFO - 2018-02-16 12:38:01 --> Router Class Initialized
INFO - 2018-02-16 12:38:01 --> Output Class Initialized
INFO - 2018-02-16 12:38:01 --> Security Class Initialized
DEBUG - 2018-02-16 12:38:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-16 12:38:01 --> Input Class Initialized
INFO - 2018-02-16 12:38:01 --> Language Class Initialized
INFO - 2018-02-16 12:38:01 --> Loader Class Initialized
INFO - 2018-02-16 12:38:01 --> Helper loaded: url_helper
INFO - 2018-02-16 12:38:01 --> Helper loaded: file_helper
INFO - 2018-02-16 12:38:01 --> Helper loaded: email_helper
INFO - 2018-02-16 12:38:01 --> Helper loaded: common_helper
INFO - 2018-02-16 12:38:01 --> Database Driver Class Initialized
DEBUG - 2018-02-16 12:38:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-16 12:38:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-16 12:38:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-16 12:38:01 --> Pagination Class Initialized
INFO - 2018-02-16 12:38:01 --> Helper loaded: form_helper
INFO - 2018-02-16 12:38:01 --> Form Validation Class Initialized
INFO - 2018-02-16 12:38:01 --> Model Class Initialized
INFO - 2018-02-16 12:38:01 --> Controller Class Initialized
INFO - 2018-02-16 12:38:01 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-16 12:38:01 --> Model Class Initialized
INFO - 2018-02-16 12:38:01 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-16 12:38:01 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-16 12:38:01 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-16 12:38:01 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-16 12:38:01 --> File loaded: /var/www/html/project/radio/application/views/user/index.php
INFO - 2018-02-16 12:38:01 --> Final output sent to browser
DEBUG - 2018-02-16 12:38:01 --> Total execution time: 0.0064
INFO - 2018-02-16 12:38:01 --> Config Class Initialized
INFO - 2018-02-16 12:38:01 --> Hooks Class Initialized
DEBUG - 2018-02-16 12:38:01 --> UTF-8 Support Enabled
INFO - 2018-02-16 12:38:01 --> Utf8 Class Initialized
INFO - 2018-02-16 12:38:01 --> URI Class Initialized
INFO - 2018-02-16 12:38:01 --> Router Class Initialized
INFO - 2018-02-16 12:38:01 --> Output Class Initialized
INFO - 2018-02-16 12:38:01 --> Security Class Initialized
DEBUG - 2018-02-16 12:38:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-16 12:38:01 --> Input Class Initialized
INFO - 2018-02-16 12:38:01 --> Language Class Initialized
INFO - 2018-02-16 12:38:01 --> Loader Class Initialized
INFO - 2018-02-16 12:38:01 --> Helper loaded: url_helper
INFO - 2018-02-16 12:38:01 --> Helper loaded: file_helper
INFO - 2018-02-16 12:38:01 --> Helper loaded: email_helper
INFO - 2018-02-16 12:38:01 --> Helper loaded: common_helper
INFO - 2018-02-16 12:38:01 --> Database Driver Class Initialized
DEBUG - 2018-02-16 12:38:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-16 12:38:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-16 12:38:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-16 12:38:01 --> Pagination Class Initialized
INFO - 2018-02-16 12:38:01 --> Helper loaded: form_helper
INFO - 2018-02-16 12:38:01 --> Form Validation Class Initialized
INFO - 2018-02-16 12:38:01 --> Model Class Initialized
INFO - 2018-02-16 12:38:01 --> Controller Class Initialized
INFO - 2018-02-16 12:38:01 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-16 12:38:01 --> Model Class Initialized
INFO - 2018-02-16 12:43:17 --> Config Class Initialized
INFO - 2018-02-16 12:43:17 --> Hooks Class Initialized
DEBUG - 2018-02-16 12:43:17 --> UTF-8 Support Enabled
INFO - 2018-02-16 12:43:17 --> Utf8 Class Initialized
INFO - 2018-02-16 12:43:17 --> URI Class Initialized
INFO - 2018-02-16 12:43:17 --> Router Class Initialized
INFO - 2018-02-16 12:43:17 --> Output Class Initialized
INFO - 2018-02-16 12:43:17 --> Security Class Initialized
DEBUG - 2018-02-16 12:43:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-16 12:43:17 --> Input Class Initialized
INFO - 2018-02-16 12:43:17 --> Language Class Initialized
INFO - 2018-02-16 12:43:17 --> Loader Class Initialized
INFO - 2018-02-16 12:43:17 --> Helper loaded: url_helper
INFO - 2018-02-16 12:43:17 --> Helper loaded: file_helper
INFO - 2018-02-16 12:43:17 --> Helper loaded: email_helper
INFO - 2018-02-16 12:43:17 --> Helper loaded: common_helper
INFO - 2018-02-16 12:43:17 --> Database Driver Class Initialized
DEBUG - 2018-02-16 12:43:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-16 12:43:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-16 12:43:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-16 12:43:17 --> Pagination Class Initialized
INFO - 2018-02-16 12:43:17 --> Helper loaded: form_helper
INFO - 2018-02-16 12:43:17 --> Form Validation Class Initialized
INFO - 2018-02-16 12:43:17 --> Model Class Initialized
INFO - 2018-02-16 12:43:17 --> Controller Class Initialized
INFO - 2018-02-16 12:43:17 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-16 12:43:17 --> Model Class Initialized
INFO - 2018-02-16 12:43:17 --> Model Class Initialized
INFO - 2018-02-16 12:43:17 --> Model Class Initialized
INFO - 2018-02-16 12:43:17 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-16 12:43:17 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-16 12:43:17 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-16 12:43:17 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-16 12:43:17 --> File loaded: /var/www/html/project/radio/application/views/tracks/index.php
INFO - 2018-02-16 12:43:17 --> Final output sent to browser
DEBUG - 2018-02-16 12:43:17 --> Total execution time: 0.0111
INFO - 2018-02-16 12:43:17 --> Config Class Initialized
INFO - 2018-02-16 12:43:17 --> Hooks Class Initialized
DEBUG - 2018-02-16 12:43:17 --> UTF-8 Support Enabled
INFO - 2018-02-16 12:43:17 --> Utf8 Class Initialized
INFO - 2018-02-16 12:43:17 --> URI Class Initialized
INFO - 2018-02-16 12:43:17 --> Router Class Initialized
INFO - 2018-02-16 12:43:17 --> Output Class Initialized
INFO - 2018-02-16 12:43:17 --> Security Class Initialized
DEBUG - 2018-02-16 12:43:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-16 12:43:17 --> Input Class Initialized
INFO - 2018-02-16 12:43:17 --> Language Class Initialized
INFO - 2018-02-16 12:43:17 --> Loader Class Initialized
INFO - 2018-02-16 12:43:17 --> Helper loaded: url_helper
INFO - 2018-02-16 12:43:17 --> Helper loaded: file_helper
INFO - 2018-02-16 12:43:17 --> Helper loaded: email_helper
INFO - 2018-02-16 12:43:17 --> Helper loaded: common_helper
INFO - 2018-02-16 12:43:17 --> Database Driver Class Initialized
DEBUG - 2018-02-16 12:43:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-16 12:43:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-16 12:43:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-16 12:43:17 --> Pagination Class Initialized
INFO - 2018-02-16 12:43:17 --> Helper loaded: form_helper
INFO - 2018-02-16 12:43:17 --> Form Validation Class Initialized
INFO - 2018-02-16 12:43:17 --> Model Class Initialized
INFO - 2018-02-16 12:43:17 --> Controller Class Initialized
INFO - 2018-02-16 12:43:17 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-16 12:43:17 --> Model Class Initialized
INFO - 2018-02-16 12:43:17 --> Model Class Initialized
INFO - 2018-02-16 12:43:17 --> Model Class Initialized
INFO - 2018-02-16 12:44:08 --> Config Class Initialized
INFO - 2018-02-16 12:44:08 --> Hooks Class Initialized
DEBUG - 2018-02-16 12:44:08 --> UTF-8 Support Enabled
INFO - 2018-02-16 12:44:08 --> Utf8 Class Initialized
INFO - 2018-02-16 12:44:08 --> URI Class Initialized
INFO - 2018-02-16 12:44:08 --> Router Class Initialized
INFO - 2018-02-16 12:44:08 --> Output Class Initialized
INFO - 2018-02-16 12:44:08 --> Security Class Initialized
DEBUG - 2018-02-16 12:44:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-16 12:44:08 --> Input Class Initialized
INFO - 2018-02-16 12:44:08 --> Language Class Initialized
INFO - 2018-02-16 12:44:08 --> Loader Class Initialized
INFO - 2018-02-16 12:44:08 --> Helper loaded: url_helper
INFO - 2018-02-16 12:44:08 --> Helper loaded: file_helper
INFO - 2018-02-16 12:44:08 --> Helper loaded: email_helper
INFO - 2018-02-16 12:44:08 --> Helper loaded: common_helper
INFO - 2018-02-16 12:44:08 --> Database Driver Class Initialized
DEBUG - 2018-02-16 12:44:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-16 12:44:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-16 12:44:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-16 12:44:08 --> Pagination Class Initialized
INFO - 2018-02-16 12:44:08 --> Helper loaded: form_helper
INFO - 2018-02-16 12:44:08 --> Form Validation Class Initialized
INFO - 2018-02-16 12:44:08 --> Model Class Initialized
INFO - 2018-02-16 12:44:08 --> Controller Class Initialized
INFO - 2018-02-16 12:44:08 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-16 12:44:08 --> Model Class Initialized
INFO - 2018-02-16 12:44:08 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-16 12:44:08 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-16 12:44:08 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-16 12:44:08 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-16 12:44:08 --> File loaded: /var/www/html/project/radio/application/views/user/index.php
INFO - 2018-02-16 12:44:08 --> Final output sent to browser
DEBUG - 2018-02-16 12:44:08 --> Total execution time: 0.0048
INFO - 2018-02-16 12:44:09 --> Config Class Initialized
INFO - 2018-02-16 12:44:09 --> Hooks Class Initialized
DEBUG - 2018-02-16 12:44:09 --> UTF-8 Support Enabled
INFO - 2018-02-16 12:44:09 --> Utf8 Class Initialized
INFO - 2018-02-16 12:44:09 --> URI Class Initialized
INFO - 2018-02-16 12:44:09 --> Router Class Initialized
INFO - 2018-02-16 12:44:09 --> Output Class Initialized
INFO - 2018-02-16 12:44:09 --> Security Class Initialized
DEBUG - 2018-02-16 12:44:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-16 12:44:09 --> Input Class Initialized
INFO - 2018-02-16 12:44:09 --> Language Class Initialized
INFO - 2018-02-16 12:44:09 --> Loader Class Initialized
INFO - 2018-02-16 12:44:09 --> Helper loaded: url_helper
INFO - 2018-02-16 12:44:09 --> Helper loaded: file_helper
INFO - 2018-02-16 12:44:09 --> Helper loaded: email_helper
INFO - 2018-02-16 12:44:09 --> Helper loaded: common_helper
INFO - 2018-02-16 12:44:09 --> Database Driver Class Initialized
DEBUG - 2018-02-16 12:44:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-16 12:44:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-16 12:44:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-16 12:44:09 --> Pagination Class Initialized
INFO - 2018-02-16 12:44:09 --> Helper loaded: form_helper
INFO - 2018-02-16 12:44:09 --> Form Validation Class Initialized
INFO - 2018-02-16 12:44:09 --> Model Class Initialized
INFO - 2018-02-16 12:44:09 --> Controller Class Initialized
INFO - 2018-02-16 12:44:09 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-16 12:44:09 --> Model Class Initialized
INFO - 2018-02-16 12:44:09 --> Config Class Initialized
INFO - 2018-02-16 12:44:09 --> Hooks Class Initialized
DEBUG - 2018-02-16 12:44:09 --> UTF-8 Support Enabled
INFO - 2018-02-16 12:44:09 --> Utf8 Class Initialized
INFO - 2018-02-16 12:44:09 --> URI Class Initialized
INFO - 2018-02-16 12:44:09 --> Router Class Initialized
INFO - 2018-02-16 12:44:09 --> Output Class Initialized
INFO - 2018-02-16 12:44:09 --> Security Class Initialized
DEBUG - 2018-02-16 12:44:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-16 12:44:09 --> Input Class Initialized
INFO - 2018-02-16 12:44:09 --> Language Class Initialized
INFO - 2018-02-16 12:44:09 --> Loader Class Initialized
INFO - 2018-02-16 12:44:09 --> Helper loaded: url_helper
INFO - 2018-02-16 12:44:09 --> Helper loaded: file_helper
INFO - 2018-02-16 12:44:09 --> Helper loaded: email_helper
INFO - 2018-02-16 12:44:09 --> Helper loaded: common_helper
INFO - 2018-02-16 12:44:09 --> Database Driver Class Initialized
DEBUG - 2018-02-16 12:44:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-16 12:44:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-16 12:44:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-16 12:44:09 --> Pagination Class Initialized
INFO - 2018-02-16 12:44:09 --> Helper loaded: form_helper
INFO - 2018-02-16 12:44:09 --> Form Validation Class Initialized
INFO - 2018-02-16 12:44:09 --> Model Class Initialized
INFO - 2018-02-16 12:44:09 --> Controller Class Initialized
INFO - 2018-02-16 12:44:09 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-16 12:44:09 --> Model Class Initialized
INFO - 2018-02-16 12:44:09 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-16 12:44:09 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-16 12:44:09 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-16 12:44:09 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-16 12:44:09 --> File loaded: /var/www/html/project/radio/application/views/user/index.php
INFO - 2018-02-16 12:44:09 --> Final output sent to browser
DEBUG - 2018-02-16 12:44:09 --> Total execution time: 0.0052
INFO - 2018-02-16 12:44:11 --> Config Class Initialized
INFO - 2018-02-16 12:44:11 --> Hooks Class Initialized
DEBUG - 2018-02-16 12:44:11 --> UTF-8 Support Enabled
INFO - 2018-02-16 12:44:11 --> Utf8 Class Initialized
INFO - 2018-02-16 12:44:11 --> URI Class Initialized
INFO - 2018-02-16 12:44:11 --> Router Class Initialized
INFO - 2018-02-16 12:44:11 --> Output Class Initialized
INFO - 2018-02-16 12:44:11 --> Security Class Initialized
DEBUG - 2018-02-16 12:44:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-16 12:44:11 --> Input Class Initialized
INFO - 2018-02-16 12:44:11 --> Language Class Initialized
INFO - 2018-02-16 12:44:11 --> Loader Class Initialized
INFO - 2018-02-16 12:44:11 --> Helper loaded: url_helper
INFO - 2018-02-16 12:44:11 --> Helper loaded: file_helper
INFO - 2018-02-16 12:44:11 --> Helper loaded: email_helper
INFO - 2018-02-16 12:44:11 --> Helper loaded: common_helper
INFO - 2018-02-16 12:44:11 --> Database Driver Class Initialized
DEBUG - 2018-02-16 12:44:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-16 12:44:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-16 12:44:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-16 12:44:11 --> Pagination Class Initialized
INFO - 2018-02-16 12:44:11 --> Helper loaded: form_helper
INFO - 2018-02-16 12:44:11 --> Form Validation Class Initialized
INFO - 2018-02-16 12:44:11 --> Model Class Initialized
INFO - 2018-02-16 12:44:11 --> Controller Class Initialized
INFO - 2018-02-16 12:44:11 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-16 12:44:11 --> Model Class Initialized
INFO - 2018-02-16 12:44:12 --> Config Class Initialized
INFO - 2018-02-16 12:44:12 --> Hooks Class Initialized
DEBUG - 2018-02-16 12:44:12 --> UTF-8 Support Enabled
INFO - 2018-02-16 12:44:12 --> Utf8 Class Initialized
INFO - 2018-02-16 12:44:12 --> URI Class Initialized
INFO - 2018-02-16 12:44:12 --> Router Class Initialized
INFO - 2018-02-16 12:44:12 --> Output Class Initialized
INFO - 2018-02-16 12:44:12 --> Security Class Initialized
DEBUG - 2018-02-16 12:44:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-16 12:44:12 --> Input Class Initialized
INFO - 2018-02-16 12:44:12 --> Language Class Initialized
INFO - 2018-02-16 12:44:12 --> Loader Class Initialized
INFO - 2018-02-16 12:44:12 --> Helper loaded: url_helper
INFO - 2018-02-16 12:44:12 --> Helper loaded: file_helper
INFO - 2018-02-16 12:44:12 --> Helper loaded: email_helper
INFO - 2018-02-16 12:44:12 --> Helper loaded: common_helper
INFO - 2018-02-16 12:44:12 --> Database Driver Class Initialized
DEBUG - 2018-02-16 12:44:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-16 12:44:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-16 12:44:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-16 12:44:12 --> Pagination Class Initialized
INFO - 2018-02-16 12:44:12 --> Helper loaded: form_helper
INFO - 2018-02-16 12:44:12 --> Form Validation Class Initialized
INFO - 2018-02-16 12:44:12 --> Model Class Initialized
INFO - 2018-02-16 12:44:12 --> Controller Class Initialized
INFO - 2018-02-16 12:44:12 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-16 12:44:12 --> Model Class Initialized
INFO - 2018-02-16 12:44:12 --> Model Class Initialized
INFO - 2018-02-16 12:44:12 --> Model Class Initialized
INFO - 2018-02-16 12:44:12 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-16 12:44:12 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-16 12:44:12 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-16 12:44:12 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-16 12:44:12 --> File loaded: /var/www/html/project/radio/application/views/tracks/index.php
INFO - 2018-02-16 12:44:12 --> Final output sent to browser
DEBUG - 2018-02-16 12:44:12 --> Total execution time: 0.0053
INFO - 2018-02-16 12:44:12 --> Config Class Initialized
INFO - 2018-02-16 12:44:12 --> Hooks Class Initialized
DEBUG - 2018-02-16 12:44:12 --> UTF-8 Support Enabled
INFO - 2018-02-16 12:44:12 --> Utf8 Class Initialized
INFO - 2018-02-16 12:44:12 --> URI Class Initialized
INFO - 2018-02-16 12:44:12 --> Router Class Initialized
INFO - 2018-02-16 12:44:12 --> Output Class Initialized
INFO - 2018-02-16 12:44:12 --> Security Class Initialized
DEBUG - 2018-02-16 12:44:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-16 12:44:12 --> Input Class Initialized
INFO - 2018-02-16 12:44:12 --> Language Class Initialized
INFO - 2018-02-16 12:44:12 --> Loader Class Initialized
INFO - 2018-02-16 12:44:12 --> Helper loaded: url_helper
INFO - 2018-02-16 12:44:12 --> Helper loaded: file_helper
INFO - 2018-02-16 12:44:12 --> Helper loaded: email_helper
INFO - 2018-02-16 12:44:12 --> Helper loaded: common_helper
INFO - 2018-02-16 12:44:12 --> Database Driver Class Initialized
DEBUG - 2018-02-16 12:44:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-16 12:44:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-16 12:44:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-16 12:44:12 --> Pagination Class Initialized
INFO - 2018-02-16 12:44:12 --> Helper loaded: form_helper
INFO - 2018-02-16 12:44:12 --> Form Validation Class Initialized
INFO - 2018-02-16 12:44:12 --> Model Class Initialized
INFO - 2018-02-16 12:44:12 --> Controller Class Initialized
INFO - 2018-02-16 12:44:12 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-16 12:44:12 --> Model Class Initialized
INFO - 2018-02-16 12:44:12 --> Model Class Initialized
INFO - 2018-02-16 12:44:12 --> Model Class Initialized
INFO - 2018-02-16 12:44:16 --> Config Class Initialized
INFO - 2018-02-16 12:44:16 --> Hooks Class Initialized
DEBUG - 2018-02-16 12:44:16 --> UTF-8 Support Enabled
INFO - 2018-02-16 12:44:16 --> Utf8 Class Initialized
INFO - 2018-02-16 12:44:16 --> URI Class Initialized
INFO - 2018-02-16 12:44:16 --> Router Class Initialized
INFO - 2018-02-16 12:44:16 --> Output Class Initialized
INFO - 2018-02-16 12:44:16 --> Security Class Initialized
DEBUG - 2018-02-16 12:44:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-16 12:44:16 --> Input Class Initialized
INFO - 2018-02-16 12:44:16 --> Language Class Initialized
INFO - 2018-02-16 12:44:16 --> Loader Class Initialized
INFO - 2018-02-16 12:44:16 --> Helper loaded: url_helper
INFO - 2018-02-16 12:44:16 --> Helper loaded: file_helper
INFO - 2018-02-16 12:44:16 --> Helper loaded: email_helper
INFO - 2018-02-16 12:44:16 --> Helper loaded: common_helper
INFO - 2018-02-16 12:44:16 --> Database Driver Class Initialized
DEBUG - 2018-02-16 12:44:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-16 12:44:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-16 12:44:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-16 12:44:16 --> Pagination Class Initialized
INFO - 2018-02-16 12:44:16 --> Helper loaded: form_helper
INFO - 2018-02-16 12:44:16 --> Form Validation Class Initialized
INFO - 2018-02-16 12:44:16 --> Model Class Initialized
INFO - 2018-02-16 12:44:16 --> Controller Class Initialized
INFO - 2018-02-16 12:44:16 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-16 12:44:16 --> Model Class Initialized
INFO - 2018-02-16 12:44:16 --> Model Class Initialized
INFO - 2018-02-16 12:44:16 --> Model Class Initialized
INFO - 2018-02-16 12:44:16 --> Model Class Initialized
INFO - 2018-02-16 12:44:16 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-16 12:44:16 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-16 12:44:16 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-16 12:44:16 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-16 12:44:16 --> File loaded: /var/www/html/project/radio/application/views/dashboard/index.php
INFO - 2018-02-16 12:44:16 --> Final output sent to browser
DEBUG - 2018-02-16 12:44:16 --> Total execution time: 0.0074
INFO - 2018-02-16 12:44:17 --> Config Class Initialized
INFO - 2018-02-16 12:44:17 --> Hooks Class Initialized
DEBUG - 2018-02-16 12:44:17 --> UTF-8 Support Enabled
INFO - 2018-02-16 12:44:17 --> Utf8 Class Initialized
INFO - 2018-02-16 12:44:17 --> URI Class Initialized
INFO - 2018-02-16 12:44:17 --> Router Class Initialized
INFO - 2018-02-16 12:44:17 --> Output Class Initialized
INFO - 2018-02-16 12:44:17 --> Security Class Initialized
DEBUG - 2018-02-16 12:44:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-16 12:44:17 --> Input Class Initialized
INFO - 2018-02-16 12:44:17 --> Language Class Initialized
INFO - 2018-02-16 12:44:17 --> Loader Class Initialized
INFO - 2018-02-16 12:44:17 --> Helper loaded: url_helper
INFO - 2018-02-16 12:44:17 --> Helper loaded: file_helper
INFO - 2018-02-16 12:44:17 --> Helper loaded: email_helper
INFO - 2018-02-16 12:44:17 --> Helper loaded: common_helper
INFO - 2018-02-16 12:44:17 --> Database Driver Class Initialized
DEBUG - 2018-02-16 12:44:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-16 12:44:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-16 12:44:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-16 12:44:17 --> Pagination Class Initialized
INFO - 2018-02-16 12:44:17 --> Helper loaded: form_helper
INFO - 2018-02-16 12:44:17 --> Form Validation Class Initialized
INFO - 2018-02-16 12:44:17 --> Model Class Initialized
INFO - 2018-02-16 12:44:17 --> Controller Class Initialized
INFO - 2018-02-16 12:44:17 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-16 12:44:17 --> Model Class Initialized
INFO - 2018-02-16 12:44:17 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-16 12:44:17 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-16 12:44:17 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-16 12:44:17 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-16 12:44:17 --> File loaded: /var/www/html/project/radio/application/views/user/index.php
INFO - 2018-02-16 12:44:17 --> Final output sent to browser
DEBUG - 2018-02-16 12:44:17 --> Total execution time: 0.0043
INFO - 2018-02-16 12:44:17 --> Config Class Initialized
INFO - 2018-02-16 12:44:17 --> Hooks Class Initialized
DEBUG - 2018-02-16 12:44:17 --> UTF-8 Support Enabled
INFO - 2018-02-16 12:44:17 --> Utf8 Class Initialized
INFO - 2018-02-16 12:44:17 --> URI Class Initialized
INFO - 2018-02-16 12:44:17 --> Router Class Initialized
INFO - 2018-02-16 12:44:17 --> Output Class Initialized
INFO - 2018-02-16 12:44:17 --> Security Class Initialized
DEBUG - 2018-02-16 12:44:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-16 12:44:17 --> Input Class Initialized
INFO - 2018-02-16 12:44:17 --> Language Class Initialized
INFO - 2018-02-16 12:44:17 --> Loader Class Initialized
INFO - 2018-02-16 12:44:17 --> Helper loaded: url_helper
INFO - 2018-02-16 12:44:17 --> Helper loaded: file_helper
INFO - 2018-02-16 12:44:17 --> Helper loaded: email_helper
INFO - 2018-02-16 12:44:17 --> Helper loaded: common_helper
INFO - 2018-02-16 12:44:17 --> Database Driver Class Initialized
DEBUG - 2018-02-16 12:44:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-16 12:44:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-16 12:44:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-16 12:44:17 --> Pagination Class Initialized
INFO - 2018-02-16 12:44:17 --> Helper loaded: form_helper
INFO - 2018-02-16 12:44:17 --> Form Validation Class Initialized
INFO - 2018-02-16 12:44:17 --> Model Class Initialized
INFO - 2018-02-16 12:44:17 --> Controller Class Initialized
INFO - 2018-02-16 12:44:17 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-16 12:44:17 --> Model Class Initialized
INFO - 2018-02-16 12:44:18 --> Config Class Initialized
INFO - 2018-02-16 12:44:18 --> Hooks Class Initialized
DEBUG - 2018-02-16 12:44:18 --> UTF-8 Support Enabled
INFO - 2018-02-16 12:44:18 --> Utf8 Class Initialized
INFO - 2018-02-16 12:44:18 --> URI Class Initialized
INFO - 2018-02-16 12:44:18 --> Router Class Initialized
INFO - 2018-02-16 12:44:18 --> Output Class Initialized
INFO - 2018-02-16 12:44:18 --> Security Class Initialized
DEBUG - 2018-02-16 12:44:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-16 12:44:18 --> Input Class Initialized
INFO - 2018-02-16 12:44:18 --> Language Class Initialized
INFO - 2018-02-16 12:44:18 --> Loader Class Initialized
INFO - 2018-02-16 12:44:18 --> Helper loaded: url_helper
INFO - 2018-02-16 12:44:18 --> Helper loaded: file_helper
INFO - 2018-02-16 12:44:18 --> Helper loaded: email_helper
INFO - 2018-02-16 12:44:18 --> Helper loaded: common_helper
INFO - 2018-02-16 12:44:18 --> Database Driver Class Initialized
DEBUG - 2018-02-16 12:44:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-16 12:44:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-16 12:44:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-16 12:44:18 --> Pagination Class Initialized
INFO - 2018-02-16 12:44:18 --> Helper loaded: form_helper
INFO - 2018-02-16 12:44:18 --> Form Validation Class Initialized
INFO - 2018-02-16 12:44:18 --> Model Class Initialized
INFO - 2018-02-16 12:44:18 --> Controller Class Initialized
INFO - 2018-02-16 12:44:18 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-16 12:44:18 --> Model Class Initialized
INFO - 2018-02-16 12:44:18 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-16 12:44:18 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-16 12:44:18 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-16 12:44:18 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-16 12:44:18 --> File loaded: /var/www/html/project/radio/application/views/category/index.php
INFO - 2018-02-16 12:44:18 --> Final output sent to browser
DEBUG - 2018-02-16 12:44:18 --> Total execution time: 0.0059
INFO - 2018-02-16 12:44:19 --> Config Class Initialized
INFO - 2018-02-16 12:44:19 --> Hooks Class Initialized
DEBUG - 2018-02-16 12:44:19 --> UTF-8 Support Enabled
INFO - 2018-02-16 12:44:19 --> Utf8 Class Initialized
INFO - 2018-02-16 12:44:19 --> URI Class Initialized
INFO - 2018-02-16 12:44:19 --> Router Class Initialized
INFO - 2018-02-16 12:44:19 --> Output Class Initialized
INFO - 2018-02-16 12:44:19 --> Security Class Initialized
DEBUG - 2018-02-16 12:44:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-16 12:44:19 --> Input Class Initialized
INFO - 2018-02-16 12:44:19 --> Language Class Initialized
INFO - 2018-02-16 12:44:19 --> Loader Class Initialized
INFO - 2018-02-16 12:44:19 --> Helper loaded: url_helper
INFO - 2018-02-16 12:44:19 --> Helper loaded: file_helper
INFO - 2018-02-16 12:44:19 --> Helper loaded: email_helper
INFO - 2018-02-16 12:44:19 --> Helper loaded: common_helper
INFO - 2018-02-16 12:44:19 --> Database Driver Class Initialized
DEBUG - 2018-02-16 12:44:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-16 12:44:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-16 12:44:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-16 12:44:19 --> Pagination Class Initialized
INFO - 2018-02-16 12:44:19 --> Helper loaded: form_helper
INFO - 2018-02-16 12:44:19 --> Form Validation Class Initialized
INFO - 2018-02-16 12:44:19 --> Model Class Initialized
INFO - 2018-02-16 12:44:19 --> Controller Class Initialized
INFO - 2018-02-16 12:44:19 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-16 12:44:19 --> Model Class Initialized
INFO - 2018-02-16 12:44:19 --> Model Class Initialized
INFO - 2018-02-16 12:44:19 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-16 12:44:19 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-16 12:44:19 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-16 12:44:19 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-16 12:44:19 --> File loaded: /var/www/html/project/radio/application/views/subcategory/index.php
INFO - 2018-02-16 12:44:19 --> Final output sent to browser
DEBUG - 2018-02-16 12:44:19 --> Total execution time: 0.0068
INFO - 2018-02-16 12:44:20 --> Config Class Initialized
INFO - 2018-02-16 12:44:20 --> Hooks Class Initialized
DEBUG - 2018-02-16 12:44:20 --> UTF-8 Support Enabled
INFO - 2018-02-16 12:44:20 --> Utf8 Class Initialized
INFO - 2018-02-16 12:44:20 --> URI Class Initialized
INFO - 2018-02-16 12:44:20 --> Router Class Initialized
INFO - 2018-02-16 12:44:20 --> Output Class Initialized
INFO - 2018-02-16 12:44:20 --> Security Class Initialized
DEBUG - 2018-02-16 12:44:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-16 12:44:20 --> Input Class Initialized
INFO - 2018-02-16 12:44:20 --> Language Class Initialized
INFO - 2018-02-16 12:44:20 --> Loader Class Initialized
INFO - 2018-02-16 12:44:20 --> Helper loaded: url_helper
INFO - 2018-02-16 12:44:20 --> Helper loaded: file_helper
INFO - 2018-02-16 12:44:20 --> Helper loaded: email_helper
INFO - 2018-02-16 12:44:20 --> Helper loaded: common_helper
INFO - 2018-02-16 12:44:20 --> Database Driver Class Initialized
DEBUG - 2018-02-16 12:44:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-16 12:44:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-16 12:44:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-16 12:44:20 --> Pagination Class Initialized
INFO - 2018-02-16 12:44:20 --> Helper loaded: form_helper
INFO - 2018-02-16 12:44:20 --> Form Validation Class Initialized
INFO - 2018-02-16 12:44:20 --> Model Class Initialized
INFO - 2018-02-16 12:44:20 --> Controller Class Initialized
INFO - 2018-02-16 12:44:20 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-16 12:44:20 --> Model Class Initialized
INFO - 2018-02-16 12:44:20 --> Model Class Initialized
INFO - 2018-02-16 12:44:20 --> Model Class Initialized
INFO - 2018-02-16 12:44:20 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-16 12:44:20 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-16 12:44:20 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-16 12:44:20 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-16 12:44:20 --> File loaded: /var/www/html/project/radio/application/views/tracks/index.php
INFO - 2018-02-16 12:44:20 --> Final output sent to browser
DEBUG - 2018-02-16 12:44:20 --> Total execution time: 0.0051
INFO - 2018-02-16 12:44:21 --> Config Class Initialized
INFO - 2018-02-16 12:44:21 --> Hooks Class Initialized
DEBUG - 2018-02-16 12:44:21 --> UTF-8 Support Enabled
INFO - 2018-02-16 12:44:21 --> Utf8 Class Initialized
INFO - 2018-02-16 12:44:21 --> URI Class Initialized
INFO - 2018-02-16 12:44:21 --> Router Class Initialized
INFO - 2018-02-16 12:44:21 --> Output Class Initialized
INFO - 2018-02-16 12:44:21 --> Security Class Initialized
DEBUG - 2018-02-16 12:44:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-16 12:44:21 --> Input Class Initialized
INFO - 2018-02-16 12:44:21 --> Language Class Initialized
INFO - 2018-02-16 12:44:21 --> Loader Class Initialized
INFO - 2018-02-16 12:44:21 --> Helper loaded: url_helper
INFO - 2018-02-16 12:44:21 --> Helper loaded: file_helper
INFO - 2018-02-16 12:44:21 --> Helper loaded: email_helper
INFO - 2018-02-16 12:44:21 --> Helper loaded: common_helper
INFO - 2018-02-16 12:44:21 --> Database Driver Class Initialized
DEBUG - 2018-02-16 12:44:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-16 12:44:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-16 12:44:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-16 12:44:21 --> Pagination Class Initialized
INFO - 2018-02-16 12:44:21 --> Helper loaded: form_helper
INFO - 2018-02-16 12:44:21 --> Form Validation Class Initialized
INFO - 2018-02-16 12:44:21 --> Model Class Initialized
INFO - 2018-02-16 12:44:21 --> Controller Class Initialized
INFO - 2018-02-16 12:44:21 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-16 12:44:21 --> Model Class Initialized
INFO - 2018-02-16 12:44:21 --> Model Class Initialized
INFO - 2018-02-16 12:44:21 --> Model Class Initialized
INFO - 2018-02-16 12:44:22 --> Config Class Initialized
INFO - 2018-02-16 12:44:22 --> Hooks Class Initialized
DEBUG - 2018-02-16 12:44:22 --> UTF-8 Support Enabled
INFO - 2018-02-16 12:44:22 --> Utf8 Class Initialized
INFO - 2018-02-16 12:44:22 --> URI Class Initialized
INFO - 2018-02-16 12:44:22 --> Router Class Initialized
INFO - 2018-02-16 12:44:22 --> Output Class Initialized
INFO - 2018-02-16 12:44:22 --> Security Class Initialized
DEBUG - 2018-02-16 12:44:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-16 12:44:22 --> Input Class Initialized
INFO - 2018-02-16 12:44:22 --> Language Class Initialized
INFO - 2018-02-16 12:44:22 --> Loader Class Initialized
INFO - 2018-02-16 12:44:22 --> Helper loaded: url_helper
INFO - 2018-02-16 12:44:22 --> Helper loaded: file_helper
INFO - 2018-02-16 12:44:22 --> Helper loaded: email_helper
INFO - 2018-02-16 12:44:22 --> Helper loaded: common_helper
INFO - 2018-02-16 12:44:22 --> Database Driver Class Initialized
DEBUG - 2018-02-16 12:44:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-16 12:44:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-16 12:44:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-16 12:44:22 --> Pagination Class Initialized
INFO - 2018-02-16 12:44:22 --> Helper loaded: form_helper
INFO - 2018-02-16 12:44:22 --> Form Validation Class Initialized
INFO - 2018-02-16 12:44:22 --> Model Class Initialized
INFO - 2018-02-16 12:44:22 --> Controller Class Initialized
INFO - 2018-02-16 12:44:22 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-16 12:44:22 --> Model Class Initialized
INFO - 2018-02-16 12:44:22 --> Model Class Initialized
INFO - 2018-02-16 12:44:22 --> Model Class Initialized
INFO - 2018-02-16 12:44:22 --> Model Class Initialized
INFO - 2018-02-16 12:44:22 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-16 12:44:22 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-16 12:44:22 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-16 12:44:22 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-16 12:44:22 --> File loaded: /var/www/html/project/radio/application/views/dashboard/index.php
INFO - 2018-02-16 12:44:22 --> Final output sent to browser
DEBUG - 2018-02-16 12:44:22 --> Total execution time: 0.0075
INFO - 2018-02-16 12:44:23 --> Config Class Initialized
INFO - 2018-02-16 12:44:23 --> Hooks Class Initialized
DEBUG - 2018-02-16 12:44:23 --> UTF-8 Support Enabled
INFO - 2018-02-16 12:44:23 --> Utf8 Class Initialized
INFO - 2018-02-16 12:44:23 --> URI Class Initialized
INFO - 2018-02-16 12:44:23 --> Router Class Initialized
INFO - 2018-02-16 12:44:23 --> Output Class Initialized
INFO - 2018-02-16 12:44:23 --> Security Class Initialized
DEBUG - 2018-02-16 12:44:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-16 12:44:23 --> Input Class Initialized
INFO - 2018-02-16 12:44:23 --> Language Class Initialized
INFO - 2018-02-16 12:44:23 --> Loader Class Initialized
INFO - 2018-02-16 12:44:23 --> Helper loaded: url_helper
INFO - 2018-02-16 12:44:23 --> Helper loaded: file_helper
INFO - 2018-02-16 12:44:23 --> Helper loaded: email_helper
INFO - 2018-02-16 12:44:23 --> Helper loaded: common_helper
INFO - 2018-02-16 12:44:23 --> Database Driver Class Initialized
DEBUG - 2018-02-16 12:44:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-16 12:44:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-16 12:44:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-16 12:44:23 --> Pagination Class Initialized
INFO - 2018-02-16 12:44:23 --> Helper loaded: form_helper
INFO - 2018-02-16 12:44:23 --> Form Validation Class Initialized
INFO - 2018-02-16 12:44:23 --> Model Class Initialized
INFO - 2018-02-16 12:44:23 --> Controller Class Initialized
INFO - 2018-02-16 12:44:23 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-16 12:44:23 --> Model Class Initialized
INFO - 2018-02-16 12:44:23 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-16 12:44:23 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-16 12:44:23 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-16 12:44:23 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-16 12:44:23 --> File loaded: /var/www/html/project/radio/application/views/user/index.php
INFO - 2018-02-16 12:44:23 --> Final output sent to browser
DEBUG - 2018-02-16 12:44:23 --> Total execution time: 0.0045
INFO - 2018-02-16 12:44:23 --> Config Class Initialized
INFO - 2018-02-16 12:44:23 --> Hooks Class Initialized
DEBUG - 2018-02-16 12:44:23 --> UTF-8 Support Enabled
INFO - 2018-02-16 12:44:23 --> Utf8 Class Initialized
INFO - 2018-02-16 12:44:23 --> URI Class Initialized
INFO - 2018-02-16 12:44:23 --> Router Class Initialized
INFO - 2018-02-16 12:44:23 --> Output Class Initialized
INFO - 2018-02-16 12:44:23 --> Security Class Initialized
DEBUG - 2018-02-16 12:44:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-16 12:44:23 --> Input Class Initialized
INFO - 2018-02-16 12:44:23 --> Language Class Initialized
INFO - 2018-02-16 12:44:23 --> Loader Class Initialized
INFO - 2018-02-16 12:44:23 --> Helper loaded: url_helper
INFO - 2018-02-16 12:44:23 --> Helper loaded: file_helper
INFO - 2018-02-16 12:44:23 --> Helper loaded: email_helper
INFO - 2018-02-16 12:44:23 --> Helper loaded: common_helper
INFO - 2018-02-16 12:44:23 --> Database Driver Class Initialized
DEBUG - 2018-02-16 12:44:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-16 12:44:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-16 12:44:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-16 12:44:23 --> Pagination Class Initialized
INFO - 2018-02-16 12:44:23 --> Helper loaded: form_helper
INFO - 2018-02-16 12:44:23 --> Form Validation Class Initialized
INFO - 2018-02-16 12:44:23 --> Model Class Initialized
INFO - 2018-02-16 12:44:23 --> Controller Class Initialized
INFO - 2018-02-16 12:44:23 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-16 12:44:23 --> Model Class Initialized
INFO - 2018-02-16 12:44:31 --> Config Class Initialized
INFO - 2018-02-16 12:44:31 --> Hooks Class Initialized
DEBUG - 2018-02-16 12:44:31 --> UTF-8 Support Enabled
INFO - 2018-02-16 12:44:31 --> Utf8 Class Initialized
INFO - 2018-02-16 12:44:31 --> URI Class Initialized
INFO - 2018-02-16 12:44:31 --> Router Class Initialized
INFO - 2018-02-16 12:44:31 --> Output Class Initialized
INFO - 2018-02-16 12:44:31 --> Security Class Initialized
DEBUG - 2018-02-16 12:44:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-16 12:44:31 --> Input Class Initialized
INFO - 2018-02-16 12:44:31 --> Language Class Initialized
INFO - 2018-02-16 12:44:31 --> Loader Class Initialized
INFO - 2018-02-16 12:44:31 --> Helper loaded: url_helper
INFO - 2018-02-16 12:44:31 --> Helper loaded: file_helper
INFO - 2018-02-16 12:44:31 --> Helper loaded: email_helper
INFO - 2018-02-16 12:44:31 --> Helper loaded: common_helper
INFO - 2018-02-16 12:44:31 --> Database Driver Class Initialized
DEBUG - 2018-02-16 12:44:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-16 12:44:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-16 12:44:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-16 12:44:31 --> Pagination Class Initialized
INFO - 2018-02-16 12:44:31 --> Helper loaded: form_helper
INFO - 2018-02-16 12:44:31 --> Form Validation Class Initialized
INFO - 2018-02-16 12:44:31 --> Model Class Initialized
INFO - 2018-02-16 12:44:31 --> Controller Class Initialized
INFO - 2018-02-16 12:44:31 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-16 12:44:31 --> Model Class Initialized
INFO - 2018-02-16 12:44:31 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-16 12:44:31 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-16 12:44:31 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-16 12:44:31 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-16 12:44:31 --> File loaded: /var/www/html/project/radio/application/views/category/index.php
INFO - 2018-02-16 12:44:31 --> Final output sent to browser
DEBUG - 2018-02-16 12:44:31 --> Total execution time: 0.0085
INFO - 2018-02-16 12:44:33 --> Config Class Initialized
INFO - 2018-02-16 12:44:33 --> Hooks Class Initialized
DEBUG - 2018-02-16 12:44:33 --> UTF-8 Support Enabled
INFO - 2018-02-16 12:44:33 --> Utf8 Class Initialized
INFO - 2018-02-16 12:44:33 --> URI Class Initialized
INFO - 2018-02-16 12:44:33 --> Router Class Initialized
INFO - 2018-02-16 12:44:33 --> Output Class Initialized
INFO - 2018-02-16 12:44:33 --> Security Class Initialized
DEBUG - 2018-02-16 12:44:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-16 12:44:33 --> Input Class Initialized
INFO - 2018-02-16 12:44:33 --> Language Class Initialized
INFO - 2018-02-16 12:44:33 --> Loader Class Initialized
INFO - 2018-02-16 12:44:33 --> Helper loaded: url_helper
INFO - 2018-02-16 12:44:33 --> Helper loaded: file_helper
INFO - 2018-02-16 12:44:33 --> Helper loaded: email_helper
INFO - 2018-02-16 12:44:33 --> Helper loaded: common_helper
INFO - 2018-02-16 12:44:33 --> Database Driver Class Initialized
DEBUG - 2018-02-16 12:44:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-16 12:44:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-16 12:44:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-16 12:44:33 --> Pagination Class Initialized
INFO - 2018-02-16 12:44:33 --> Helper loaded: form_helper
INFO - 2018-02-16 12:44:33 --> Form Validation Class Initialized
INFO - 2018-02-16 12:44:33 --> Model Class Initialized
INFO - 2018-02-16 12:44:33 --> Controller Class Initialized
INFO - 2018-02-16 12:44:33 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-16 12:44:33 --> Model Class Initialized
INFO - 2018-02-16 12:44:33 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-16 12:44:33 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-16 12:44:33 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-16 12:44:33 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-16 12:44:33 --> File loaded: /var/www/html/project/radio/application/views/category/add_edit.php
INFO - 2018-02-16 12:44:33 --> Final output sent to browser
DEBUG - 2018-02-16 12:44:33 --> Total execution time: 0.0209
INFO - 2018-02-16 12:44:34 --> Config Class Initialized
INFO - 2018-02-16 12:44:34 --> Hooks Class Initialized
DEBUG - 2018-02-16 12:44:34 --> UTF-8 Support Enabled
INFO - 2018-02-16 12:44:34 --> Utf8 Class Initialized
INFO - 2018-02-16 12:44:34 --> URI Class Initialized
INFO - 2018-02-16 12:44:34 --> Router Class Initialized
INFO - 2018-02-16 12:44:34 --> Output Class Initialized
INFO - 2018-02-16 12:44:34 --> Security Class Initialized
DEBUG - 2018-02-16 12:44:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-16 12:44:34 --> Input Class Initialized
INFO - 2018-02-16 12:44:34 --> Language Class Initialized
INFO - 2018-02-16 12:44:34 --> Loader Class Initialized
INFO - 2018-02-16 12:44:34 --> Helper loaded: url_helper
INFO - 2018-02-16 12:44:34 --> Helper loaded: file_helper
INFO - 2018-02-16 12:44:34 --> Helper loaded: email_helper
INFO - 2018-02-16 12:44:34 --> Helper loaded: common_helper
INFO - 2018-02-16 12:44:34 --> Database Driver Class Initialized
DEBUG - 2018-02-16 12:44:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-16 12:44:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-16 12:44:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-16 12:44:34 --> Pagination Class Initialized
INFO - 2018-02-16 12:44:34 --> Helper loaded: form_helper
INFO - 2018-02-16 12:44:34 --> Form Validation Class Initialized
INFO - 2018-02-16 12:44:34 --> Model Class Initialized
INFO - 2018-02-16 12:44:34 --> Controller Class Initialized
INFO - 2018-02-16 12:44:34 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-16 12:44:34 --> Model Class Initialized
INFO - 2018-02-16 12:44:34 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-16 12:44:34 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-16 12:44:34 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-16 12:44:34 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-16 12:44:34 --> File loaded: /var/www/html/project/radio/application/views/category/index.php
INFO - 2018-02-16 12:44:34 --> Final output sent to browser
DEBUG - 2018-02-16 12:44:34 --> Total execution time: 0.0048
INFO - 2018-02-16 12:45:34 --> Config Class Initialized
INFO - 2018-02-16 12:45:34 --> Hooks Class Initialized
DEBUG - 2018-02-16 12:45:34 --> UTF-8 Support Enabled
INFO - 2018-02-16 12:45:34 --> Utf8 Class Initialized
INFO - 2018-02-16 12:45:34 --> URI Class Initialized
INFO - 2018-02-16 12:45:34 --> Router Class Initialized
INFO - 2018-02-16 12:45:34 --> Output Class Initialized
INFO - 2018-02-16 12:45:34 --> Security Class Initialized
DEBUG - 2018-02-16 12:45:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-16 12:45:34 --> Input Class Initialized
INFO - 2018-02-16 12:45:34 --> Language Class Initialized
INFO - 2018-02-16 12:45:34 --> Loader Class Initialized
INFO - 2018-02-16 12:45:34 --> Helper loaded: url_helper
INFO - 2018-02-16 12:45:34 --> Helper loaded: file_helper
INFO - 2018-02-16 12:45:34 --> Helper loaded: email_helper
INFO - 2018-02-16 12:45:34 --> Helper loaded: common_helper
INFO - 2018-02-16 12:45:34 --> Database Driver Class Initialized
DEBUG - 2018-02-16 12:45:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-16 12:45:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-16 12:45:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-16 12:45:34 --> Pagination Class Initialized
INFO - 2018-02-16 12:45:34 --> Helper loaded: form_helper
INFO - 2018-02-16 12:45:34 --> Form Validation Class Initialized
INFO - 2018-02-16 12:45:34 --> Model Class Initialized
INFO - 2018-02-16 12:45:34 --> Controller Class Initialized
INFO - 2018-02-16 12:45:34 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-16 12:45:34 --> Model Class Initialized
INFO - 2018-02-16 12:45:34 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-16 12:45:34 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-16 12:45:34 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-16 12:45:34 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-16 12:45:34 --> File loaded: /var/www/html/project/radio/application/views/category/add_edit.php
INFO - 2018-02-16 12:45:34 --> Final output sent to browser
DEBUG - 2018-02-16 12:45:34 --> Total execution time: 0.0079
INFO - 2018-02-16 12:45:36 --> Config Class Initialized
INFO - 2018-02-16 12:45:36 --> Hooks Class Initialized
DEBUG - 2018-02-16 12:45:36 --> UTF-8 Support Enabled
INFO - 2018-02-16 12:45:36 --> Utf8 Class Initialized
INFO - 2018-02-16 12:45:36 --> URI Class Initialized
INFO - 2018-02-16 12:45:36 --> Router Class Initialized
INFO - 2018-02-16 12:45:36 --> Output Class Initialized
INFO - 2018-02-16 12:45:36 --> Security Class Initialized
DEBUG - 2018-02-16 12:45:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-16 12:45:36 --> Input Class Initialized
INFO - 2018-02-16 12:45:36 --> Language Class Initialized
INFO - 2018-02-16 12:45:36 --> Loader Class Initialized
INFO - 2018-02-16 12:45:36 --> Helper loaded: url_helper
INFO - 2018-02-16 12:45:36 --> Helper loaded: file_helper
INFO - 2018-02-16 12:45:36 --> Helper loaded: email_helper
INFO - 2018-02-16 12:45:36 --> Helper loaded: common_helper
INFO - 2018-02-16 12:45:36 --> Database Driver Class Initialized
DEBUG - 2018-02-16 12:45:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-16 12:45:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-16 12:45:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-16 12:45:36 --> Pagination Class Initialized
INFO - 2018-02-16 12:45:36 --> Helper loaded: form_helper
INFO - 2018-02-16 12:45:36 --> Form Validation Class Initialized
INFO - 2018-02-16 12:45:36 --> Model Class Initialized
INFO - 2018-02-16 12:45:36 --> Controller Class Initialized
INFO - 2018-02-16 12:45:36 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-16 12:45:36 --> Model Class Initialized
INFO - 2018-02-16 12:45:36 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-16 12:45:36 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-16 12:45:36 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-16 12:45:36 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-16 12:45:36 --> File loaded: /var/www/html/project/radio/application/views/category/index.php
INFO - 2018-02-16 12:45:36 --> Final output sent to browser
DEBUG - 2018-02-16 12:45:36 --> Total execution time: 0.0050
INFO - 2018-02-16 12:45:37 --> Config Class Initialized
INFO - 2018-02-16 12:45:37 --> Hooks Class Initialized
DEBUG - 2018-02-16 12:45:37 --> UTF-8 Support Enabled
INFO - 2018-02-16 12:45:37 --> Utf8 Class Initialized
INFO - 2018-02-16 12:45:37 --> URI Class Initialized
INFO - 2018-02-16 12:45:37 --> Router Class Initialized
INFO - 2018-02-16 12:45:37 --> Output Class Initialized
INFO - 2018-02-16 12:45:37 --> Security Class Initialized
DEBUG - 2018-02-16 12:45:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-16 12:45:37 --> Input Class Initialized
INFO - 2018-02-16 12:45:37 --> Language Class Initialized
INFO - 2018-02-16 12:45:37 --> Loader Class Initialized
INFO - 2018-02-16 12:45:37 --> Helper loaded: url_helper
INFO - 2018-02-16 12:45:37 --> Helper loaded: file_helper
INFO - 2018-02-16 12:45:37 --> Helper loaded: email_helper
INFO - 2018-02-16 12:45:37 --> Helper loaded: common_helper
INFO - 2018-02-16 12:45:37 --> Database Driver Class Initialized
DEBUG - 2018-02-16 12:45:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-16 12:45:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-16 12:45:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-16 12:45:37 --> Pagination Class Initialized
INFO - 2018-02-16 12:45:37 --> Helper loaded: form_helper
INFO - 2018-02-16 12:45:37 --> Form Validation Class Initialized
INFO - 2018-02-16 12:45:37 --> Model Class Initialized
INFO - 2018-02-16 12:45:37 --> Controller Class Initialized
INFO - 2018-02-16 12:45:37 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-16 12:45:37 --> Model Class Initialized
INFO - 2018-02-16 12:45:37 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-16 12:45:37 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-16 12:45:37 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-16 12:45:37 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-16 12:45:37 --> File loaded: /var/www/html/project/radio/application/views/category/add_edit.php
INFO - 2018-02-16 12:45:37 --> Final output sent to browser
DEBUG - 2018-02-16 12:45:37 --> Total execution time: 0.0046
INFO - 2018-02-16 12:45:43 --> Config Class Initialized
INFO - 2018-02-16 12:45:43 --> Hooks Class Initialized
DEBUG - 2018-02-16 12:45:43 --> UTF-8 Support Enabled
INFO - 2018-02-16 12:45:43 --> Utf8 Class Initialized
INFO - 2018-02-16 12:45:43 --> URI Class Initialized
INFO - 2018-02-16 12:45:43 --> Router Class Initialized
INFO - 2018-02-16 12:45:43 --> Output Class Initialized
INFO - 2018-02-16 12:45:43 --> Security Class Initialized
DEBUG - 2018-02-16 12:45:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-16 12:45:43 --> Input Class Initialized
INFO - 2018-02-16 12:45:43 --> Language Class Initialized
INFO - 2018-02-16 12:45:43 --> Loader Class Initialized
INFO - 2018-02-16 12:45:43 --> Helper loaded: url_helper
INFO - 2018-02-16 12:45:43 --> Helper loaded: file_helper
INFO - 2018-02-16 12:45:43 --> Helper loaded: email_helper
INFO - 2018-02-16 12:45:43 --> Helper loaded: common_helper
INFO - 2018-02-16 12:45:43 --> Database Driver Class Initialized
DEBUG - 2018-02-16 12:45:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-16 12:45:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-16 12:45:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-16 12:45:43 --> Pagination Class Initialized
INFO - 2018-02-16 12:45:43 --> Helper loaded: form_helper
INFO - 2018-02-16 12:45:43 --> Form Validation Class Initialized
INFO - 2018-02-16 12:45:43 --> Model Class Initialized
INFO - 2018-02-16 12:45:43 --> Controller Class Initialized
INFO - 2018-02-16 12:45:43 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-16 12:45:43 --> Model Class Initialized
INFO - 2018-02-16 12:45:43 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-16 12:45:43 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-16 12:45:43 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-16 12:45:43 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-16 12:45:43 --> File loaded: /var/www/html/project/radio/application/views/category/add_edit.php
INFO - 2018-02-16 12:45:43 --> Final output sent to browser
DEBUG - 2018-02-16 12:45:43 --> Total execution time: 0.0086
INFO - 2018-02-16 12:46:50 --> Config Class Initialized
INFO - 2018-02-16 12:46:50 --> Hooks Class Initialized
DEBUG - 2018-02-16 12:46:50 --> UTF-8 Support Enabled
INFO - 2018-02-16 12:46:50 --> Utf8 Class Initialized
INFO - 2018-02-16 12:46:50 --> URI Class Initialized
INFO - 2018-02-16 12:46:50 --> Router Class Initialized
INFO - 2018-02-16 12:46:50 --> Output Class Initialized
INFO - 2018-02-16 12:46:50 --> Security Class Initialized
DEBUG - 2018-02-16 12:46:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-16 12:46:50 --> Input Class Initialized
INFO - 2018-02-16 12:46:50 --> Language Class Initialized
INFO - 2018-02-16 12:46:50 --> Loader Class Initialized
INFO - 2018-02-16 12:46:50 --> Helper loaded: url_helper
INFO - 2018-02-16 12:46:50 --> Helper loaded: file_helper
INFO - 2018-02-16 12:46:50 --> Helper loaded: email_helper
INFO - 2018-02-16 12:46:50 --> Helper loaded: common_helper
INFO - 2018-02-16 12:46:50 --> Database Driver Class Initialized
DEBUG - 2018-02-16 12:46:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-16 12:46:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-16 12:46:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-16 12:46:50 --> Pagination Class Initialized
INFO - 2018-02-16 12:46:50 --> Helper loaded: form_helper
INFO - 2018-02-16 12:46:50 --> Form Validation Class Initialized
INFO - 2018-02-16 12:46:50 --> Model Class Initialized
INFO - 2018-02-16 12:46:50 --> Controller Class Initialized
INFO - 2018-02-16 12:46:50 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-16 12:46:50 --> Model Class Initialized
INFO - 2018-02-16 12:46:50 --> Model Class Initialized
INFO - 2018-02-16 12:46:50 --> Model Class Initialized
INFO - 2018-02-16 12:46:50 --> Model Class Initialized
INFO - 2018-02-16 12:46:50 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-16 12:46:50 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-16 12:46:50 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-16 12:46:50 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-16 12:46:50 --> File loaded: /var/www/html/project/radio/application/views/dashboard/index.php
INFO - 2018-02-16 12:46:50 --> Final output sent to browser
DEBUG - 2018-02-16 12:46:50 --> Total execution time: 0.0084
INFO - 2018-02-16 12:46:50 --> Config Class Initialized
INFO - 2018-02-16 12:46:50 --> Hooks Class Initialized
DEBUG - 2018-02-16 12:46:50 --> UTF-8 Support Enabled
INFO - 2018-02-16 12:46:50 --> Utf8 Class Initialized
INFO - 2018-02-16 12:46:50 --> URI Class Initialized
INFO - 2018-02-16 12:46:50 --> Router Class Initialized
INFO - 2018-02-16 12:46:50 --> Output Class Initialized
INFO - 2018-02-16 12:46:50 --> Security Class Initialized
DEBUG - 2018-02-16 12:46:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-16 12:46:50 --> Input Class Initialized
INFO - 2018-02-16 12:46:50 --> Language Class Initialized
INFO - 2018-02-16 12:46:50 --> Loader Class Initialized
INFO - 2018-02-16 12:46:50 --> Helper loaded: url_helper
INFO - 2018-02-16 12:46:50 --> Helper loaded: file_helper
INFO - 2018-02-16 12:46:50 --> Helper loaded: email_helper
INFO - 2018-02-16 12:46:50 --> Helper loaded: common_helper
INFO - 2018-02-16 12:46:50 --> Database Driver Class Initialized
DEBUG - 2018-02-16 12:46:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-16 12:46:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-16 12:46:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-16 12:46:50 --> Pagination Class Initialized
INFO - 2018-02-16 12:46:50 --> Helper loaded: form_helper
INFO - 2018-02-16 12:46:50 --> Form Validation Class Initialized
INFO - 2018-02-16 12:46:50 --> Model Class Initialized
INFO - 2018-02-16 12:46:50 --> Controller Class Initialized
INFO - 2018-02-16 12:46:50 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-16 12:46:50 --> Model Class Initialized
INFO - 2018-02-16 12:46:50 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-16 12:46:50 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-16 12:46:50 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-16 12:46:50 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-16 12:46:50 --> File loaded: /var/www/html/project/radio/application/views/user/index.php
INFO - 2018-02-16 12:46:50 --> Final output sent to browser
DEBUG - 2018-02-16 12:46:50 --> Total execution time: 0.0052
INFO - 2018-02-16 12:46:51 --> Config Class Initialized
INFO - 2018-02-16 12:46:51 --> Hooks Class Initialized
DEBUG - 2018-02-16 12:46:51 --> UTF-8 Support Enabled
INFO - 2018-02-16 12:46:51 --> Utf8 Class Initialized
INFO - 2018-02-16 12:46:51 --> URI Class Initialized
INFO - 2018-02-16 12:46:51 --> Router Class Initialized
INFO - 2018-02-16 12:46:51 --> Output Class Initialized
INFO - 2018-02-16 12:46:51 --> Security Class Initialized
DEBUG - 2018-02-16 12:46:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-16 12:46:51 --> Input Class Initialized
INFO - 2018-02-16 12:46:51 --> Language Class Initialized
INFO - 2018-02-16 12:46:51 --> Loader Class Initialized
INFO - 2018-02-16 12:46:51 --> Helper loaded: url_helper
INFO - 2018-02-16 12:46:51 --> Helper loaded: file_helper
INFO - 2018-02-16 12:46:51 --> Helper loaded: email_helper
INFO - 2018-02-16 12:46:51 --> Helper loaded: common_helper
INFO - 2018-02-16 12:46:51 --> Database Driver Class Initialized
DEBUG - 2018-02-16 12:46:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-16 12:46:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-16 12:46:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-16 12:46:51 --> Pagination Class Initialized
INFO - 2018-02-16 12:46:51 --> Helper loaded: form_helper
INFO - 2018-02-16 12:46:51 --> Form Validation Class Initialized
INFO - 2018-02-16 12:46:51 --> Model Class Initialized
INFO - 2018-02-16 12:46:51 --> Controller Class Initialized
INFO - 2018-02-16 12:46:51 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-16 12:46:51 --> Model Class Initialized
INFO - 2018-02-16 12:46:53 --> Config Class Initialized
INFO - 2018-02-16 12:46:53 --> Hooks Class Initialized
DEBUG - 2018-02-16 12:46:53 --> UTF-8 Support Enabled
INFO - 2018-02-16 12:46:53 --> Utf8 Class Initialized
INFO - 2018-02-16 12:46:53 --> URI Class Initialized
INFO - 2018-02-16 12:46:53 --> Router Class Initialized
INFO - 2018-02-16 12:46:53 --> Output Class Initialized
INFO - 2018-02-16 12:46:53 --> Security Class Initialized
DEBUG - 2018-02-16 12:46:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-16 12:46:53 --> Input Class Initialized
INFO - 2018-02-16 12:46:53 --> Language Class Initialized
INFO - 2018-02-16 12:46:53 --> Loader Class Initialized
INFO - 2018-02-16 12:46:53 --> Helper loaded: url_helper
INFO - 2018-02-16 12:46:53 --> Helper loaded: file_helper
INFO - 2018-02-16 12:46:53 --> Helper loaded: email_helper
INFO - 2018-02-16 12:46:53 --> Helper loaded: common_helper
INFO - 2018-02-16 12:46:53 --> Database Driver Class Initialized
DEBUG - 2018-02-16 12:46:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-16 12:46:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-16 12:46:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-16 12:46:53 --> Pagination Class Initialized
INFO - 2018-02-16 12:46:53 --> Helper loaded: form_helper
INFO - 2018-02-16 12:46:53 --> Form Validation Class Initialized
INFO - 2018-02-16 12:46:53 --> Model Class Initialized
INFO - 2018-02-16 12:46:53 --> Controller Class Initialized
INFO - 2018-02-16 12:46:53 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-16 12:46:53 --> Model Class Initialized
INFO - 2018-02-16 12:46:53 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-16 12:46:53 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-16 12:46:53 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-16 12:46:53 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-16 12:46:53 --> File loaded: /var/www/html/project/radio/application/views/category/index.php
INFO - 2018-02-16 12:46:53 --> Final output sent to browser
DEBUG - 2018-02-16 12:46:53 --> Total execution time: 0.0057
INFO - 2018-02-16 12:46:54 --> Config Class Initialized
INFO - 2018-02-16 12:46:54 --> Hooks Class Initialized
DEBUG - 2018-02-16 12:46:54 --> UTF-8 Support Enabled
INFO - 2018-02-16 12:46:54 --> Utf8 Class Initialized
INFO - 2018-02-16 12:46:54 --> URI Class Initialized
INFO - 2018-02-16 12:46:54 --> Router Class Initialized
INFO - 2018-02-16 12:46:54 --> Output Class Initialized
INFO - 2018-02-16 12:46:54 --> Security Class Initialized
DEBUG - 2018-02-16 12:46:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-16 12:46:54 --> Input Class Initialized
INFO - 2018-02-16 12:46:54 --> Language Class Initialized
INFO - 2018-02-16 12:46:54 --> Loader Class Initialized
INFO - 2018-02-16 12:46:54 --> Helper loaded: url_helper
INFO - 2018-02-16 12:46:54 --> Helper loaded: file_helper
INFO - 2018-02-16 12:46:54 --> Helper loaded: email_helper
INFO - 2018-02-16 12:46:54 --> Helper loaded: common_helper
INFO - 2018-02-16 12:46:54 --> Database Driver Class Initialized
DEBUG - 2018-02-16 12:46:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-16 12:46:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-16 12:46:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-16 12:46:54 --> Pagination Class Initialized
INFO - 2018-02-16 12:46:54 --> Helper loaded: form_helper
INFO - 2018-02-16 12:46:54 --> Form Validation Class Initialized
INFO - 2018-02-16 12:46:54 --> Model Class Initialized
INFO - 2018-02-16 12:46:54 --> Controller Class Initialized
INFO - 2018-02-16 12:46:54 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-16 12:46:54 --> Model Class Initialized
INFO - 2018-02-16 12:46:54 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-16 12:46:54 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-16 12:46:54 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-16 12:46:54 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-16 12:46:54 --> File loaded: /var/www/html/project/radio/application/views/category/add_edit.php
INFO - 2018-02-16 12:46:54 --> Final output sent to browser
DEBUG - 2018-02-16 12:46:54 --> Total execution time: 0.0048
INFO - 2018-02-16 12:46:56 --> Config Class Initialized
INFO - 2018-02-16 12:46:56 --> Hooks Class Initialized
DEBUG - 2018-02-16 12:46:56 --> UTF-8 Support Enabled
INFO - 2018-02-16 12:46:56 --> Utf8 Class Initialized
INFO - 2018-02-16 12:46:56 --> URI Class Initialized
INFO - 2018-02-16 12:46:56 --> Router Class Initialized
INFO - 2018-02-16 12:46:56 --> Output Class Initialized
INFO - 2018-02-16 12:46:56 --> Security Class Initialized
DEBUG - 2018-02-16 12:46:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-16 12:46:56 --> Input Class Initialized
INFO - 2018-02-16 12:46:56 --> Language Class Initialized
INFO - 2018-02-16 12:46:56 --> Loader Class Initialized
INFO - 2018-02-16 12:46:56 --> Helper loaded: url_helper
INFO - 2018-02-16 12:46:56 --> Helper loaded: file_helper
INFO - 2018-02-16 12:46:56 --> Helper loaded: email_helper
INFO - 2018-02-16 12:46:56 --> Helper loaded: common_helper
INFO - 2018-02-16 12:46:56 --> Database Driver Class Initialized
DEBUG - 2018-02-16 12:46:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-16 12:46:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-16 12:46:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-16 12:46:56 --> Pagination Class Initialized
INFO - 2018-02-16 12:46:56 --> Helper loaded: form_helper
INFO - 2018-02-16 12:46:56 --> Form Validation Class Initialized
INFO - 2018-02-16 12:46:56 --> Model Class Initialized
INFO - 2018-02-16 12:46:56 --> Controller Class Initialized
INFO - 2018-02-16 12:46:56 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-16 12:46:56 --> Model Class Initialized
INFO - 2018-02-16 12:46:56 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-16 12:46:56 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-16 12:46:56 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-16 12:46:56 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-16 12:46:56 --> File loaded: /var/www/html/project/radio/application/views/category/index.php
INFO - 2018-02-16 12:46:56 --> Final output sent to browser
DEBUG - 2018-02-16 12:46:56 --> Total execution time: 0.0065
INFO - 2018-02-16 12:46:58 --> Config Class Initialized
INFO - 2018-02-16 12:46:58 --> Hooks Class Initialized
DEBUG - 2018-02-16 12:46:58 --> UTF-8 Support Enabled
INFO - 2018-02-16 12:46:58 --> Utf8 Class Initialized
INFO - 2018-02-16 12:46:58 --> URI Class Initialized
INFO - 2018-02-16 12:46:58 --> Router Class Initialized
INFO - 2018-02-16 12:46:58 --> Output Class Initialized
INFO - 2018-02-16 12:46:58 --> Security Class Initialized
DEBUG - 2018-02-16 12:46:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-16 12:46:58 --> Input Class Initialized
INFO - 2018-02-16 12:46:58 --> Language Class Initialized
INFO - 2018-02-16 12:46:58 --> Loader Class Initialized
INFO - 2018-02-16 12:46:58 --> Helper loaded: url_helper
INFO - 2018-02-16 12:46:58 --> Helper loaded: file_helper
INFO - 2018-02-16 12:46:58 --> Helper loaded: email_helper
INFO - 2018-02-16 12:46:58 --> Helper loaded: common_helper
INFO - 2018-02-16 12:46:58 --> Database Driver Class Initialized
DEBUG - 2018-02-16 12:46:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-16 12:46:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-16 12:46:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-16 12:46:58 --> Pagination Class Initialized
INFO - 2018-02-16 12:46:58 --> Helper loaded: form_helper
INFO - 2018-02-16 12:46:58 --> Form Validation Class Initialized
INFO - 2018-02-16 12:46:58 --> Model Class Initialized
INFO - 2018-02-16 12:46:58 --> Controller Class Initialized
INFO - 2018-02-16 12:46:58 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-16 12:46:58 --> Model Class Initialized
INFO - 2018-02-16 12:46:58 --> Model Class Initialized
INFO - 2018-02-16 12:46:58 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-16 12:46:58 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-16 12:46:58 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-16 12:46:58 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-16 12:46:58 --> File loaded: /var/www/html/project/radio/application/views/subcategory/index.php
INFO - 2018-02-16 12:46:58 --> Final output sent to browser
DEBUG - 2018-02-16 12:46:58 --> Total execution time: 0.0064
INFO - 2018-02-16 12:47:06 --> Config Class Initialized
INFO - 2018-02-16 12:47:06 --> Hooks Class Initialized
DEBUG - 2018-02-16 12:47:06 --> UTF-8 Support Enabled
INFO - 2018-02-16 12:47:06 --> Utf8 Class Initialized
INFO - 2018-02-16 12:47:06 --> URI Class Initialized
INFO - 2018-02-16 12:47:06 --> Router Class Initialized
INFO - 2018-02-16 12:47:06 --> Output Class Initialized
INFO - 2018-02-16 12:47:06 --> Security Class Initialized
DEBUG - 2018-02-16 12:47:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-16 12:47:06 --> Input Class Initialized
INFO - 2018-02-16 12:47:06 --> Language Class Initialized
INFO - 2018-02-16 12:47:06 --> Loader Class Initialized
INFO - 2018-02-16 12:47:06 --> Helper loaded: url_helper
INFO - 2018-02-16 12:47:06 --> Helper loaded: file_helper
INFO - 2018-02-16 12:47:06 --> Helper loaded: email_helper
INFO - 2018-02-16 12:47:06 --> Helper loaded: common_helper
INFO - 2018-02-16 12:47:06 --> Database Driver Class Initialized
DEBUG - 2018-02-16 12:47:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-16 12:47:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-16 12:47:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-16 12:47:06 --> Pagination Class Initialized
INFO - 2018-02-16 12:47:06 --> Helper loaded: form_helper
INFO - 2018-02-16 12:47:06 --> Form Validation Class Initialized
INFO - 2018-02-16 12:47:06 --> Model Class Initialized
INFO - 2018-02-16 12:47:06 --> Controller Class Initialized
INFO - 2018-02-16 12:47:06 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-16 12:47:06 --> Model Class Initialized
INFO - 2018-02-16 12:47:06 --> Model Class Initialized
INFO - 2018-02-16 12:47:06 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-16 12:47:06 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-16 12:47:06 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-16 12:47:06 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-16 12:47:06 --> File loaded: /var/www/html/project/radio/application/views/subcategory/add_edit.php
INFO - 2018-02-16 12:47:06 --> Final output sent to browser
DEBUG - 2018-02-16 12:47:06 --> Total execution time: 0.0066
INFO - 2018-02-16 12:47:07 --> Config Class Initialized
INFO - 2018-02-16 12:47:07 --> Hooks Class Initialized
DEBUG - 2018-02-16 12:47:07 --> UTF-8 Support Enabled
INFO - 2018-02-16 12:47:07 --> Utf8 Class Initialized
INFO - 2018-02-16 12:47:07 --> URI Class Initialized
INFO - 2018-02-16 12:47:07 --> Router Class Initialized
INFO - 2018-02-16 12:47:07 --> Output Class Initialized
INFO - 2018-02-16 12:47:07 --> Security Class Initialized
DEBUG - 2018-02-16 12:47:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-16 12:47:07 --> Input Class Initialized
INFO - 2018-02-16 12:47:07 --> Language Class Initialized
INFO - 2018-02-16 12:47:07 --> Loader Class Initialized
INFO - 2018-02-16 12:47:07 --> Helper loaded: url_helper
INFO - 2018-02-16 12:47:07 --> Helper loaded: file_helper
INFO - 2018-02-16 12:47:07 --> Helper loaded: email_helper
INFO - 2018-02-16 12:47:07 --> Helper loaded: common_helper
INFO - 2018-02-16 12:47:07 --> Database Driver Class Initialized
DEBUG - 2018-02-16 12:47:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-16 12:47:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-16 12:47:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-16 12:47:07 --> Pagination Class Initialized
INFO - 2018-02-16 12:47:07 --> Helper loaded: form_helper
INFO - 2018-02-16 12:47:07 --> Form Validation Class Initialized
INFO - 2018-02-16 12:47:07 --> Model Class Initialized
INFO - 2018-02-16 12:47:07 --> Controller Class Initialized
INFO - 2018-02-16 12:47:07 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-16 12:47:07 --> Model Class Initialized
INFO - 2018-02-16 12:47:07 --> Model Class Initialized
INFO - 2018-02-16 12:47:07 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-16 12:47:07 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-16 12:47:07 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-16 12:47:07 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-16 12:47:07 --> File loaded: /var/www/html/project/radio/application/views/subcategory/index.php
INFO - 2018-02-16 12:47:07 --> Final output sent to browser
DEBUG - 2018-02-16 12:47:07 --> Total execution time: 0.0055
INFO - 2018-02-16 12:47:09 --> Config Class Initialized
INFO - 2018-02-16 12:47:09 --> Hooks Class Initialized
DEBUG - 2018-02-16 12:47:09 --> UTF-8 Support Enabled
INFO - 2018-02-16 12:47:09 --> Utf8 Class Initialized
INFO - 2018-02-16 12:47:09 --> URI Class Initialized
INFO - 2018-02-16 12:47:09 --> Router Class Initialized
INFO - 2018-02-16 12:47:09 --> Output Class Initialized
INFO - 2018-02-16 12:47:09 --> Security Class Initialized
DEBUG - 2018-02-16 12:47:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-16 12:47:09 --> Input Class Initialized
INFO - 2018-02-16 12:47:09 --> Language Class Initialized
INFO - 2018-02-16 12:47:09 --> Loader Class Initialized
INFO - 2018-02-16 12:47:09 --> Helper loaded: url_helper
INFO - 2018-02-16 12:47:09 --> Helper loaded: file_helper
INFO - 2018-02-16 12:47:09 --> Helper loaded: email_helper
INFO - 2018-02-16 12:47:09 --> Helper loaded: common_helper
INFO - 2018-02-16 12:47:09 --> Database Driver Class Initialized
DEBUG - 2018-02-16 12:47:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-16 12:47:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-16 12:47:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-16 12:47:09 --> Pagination Class Initialized
INFO - 2018-02-16 12:47:09 --> Helper loaded: form_helper
INFO - 2018-02-16 12:47:09 --> Form Validation Class Initialized
INFO - 2018-02-16 12:47:09 --> Model Class Initialized
INFO - 2018-02-16 12:47:09 --> Controller Class Initialized
INFO - 2018-02-16 12:47:09 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-16 12:47:09 --> Model Class Initialized
INFO - 2018-02-16 12:47:09 --> Model Class Initialized
INFO - 2018-02-16 12:47:09 --> Model Class Initialized
INFO - 2018-02-16 12:47:09 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-16 12:47:09 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-16 12:47:09 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-16 12:47:09 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-16 12:47:09 --> File loaded: /var/www/html/project/radio/application/views/tracks/index.php
INFO - 2018-02-16 12:47:09 --> Final output sent to browser
DEBUG - 2018-02-16 12:47:09 --> Total execution time: 0.0051
INFO - 2018-02-16 12:47:09 --> Config Class Initialized
INFO - 2018-02-16 12:47:09 --> Hooks Class Initialized
DEBUG - 2018-02-16 12:47:09 --> UTF-8 Support Enabled
INFO - 2018-02-16 12:47:09 --> Utf8 Class Initialized
INFO - 2018-02-16 12:47:09 --> URI Class Initialized
INFO - 2018-02-16 12:47:09 --> Router Class Initialized
INFO - 2018-02-16 12:47:09 --> Output Class Initialized
INFO - 2018-02-16 12:47:09 --> Security Class Initialized
DEBUG - 2018-02-16 12:47:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-16 12:47:09 --> Input Class Initialized
INFO - 2018-02-16 12:47:09 --> Language Class Initialized
INFO - 2018-02-16 12:47:09 --> Loader Class Initialized
INFO - 2018-02-16 12:47:09 --> Helper loaded: url_helper
INFO - 2018-02-16 12:47:09 --> Helper loaded: file_helper
INFO - 2018-02-16 12:47:09 --> Helper loaded: email_helper
INFO - 2018-02-16 12:47:09 --> Helper loaded: common_helper
INFO - 2018-02-16 12:47:09 --> Database Driver Class Initialized
DEBUG - 2018-02-16 12:47:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-16 12:47:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-16 12:47:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-16 12:47:09 --> Pagination Class Initialized
INFO - 2018-02-16 12:47:09 --> Helper loaded: form_helper
INFO - 2018-02-16 12:47:09 --> Form Validation Class Initialized
INFO - 2018-02-16 12:47:09 --> Model Class Initialized
INFO - 2018-02-16 12:47:09 --> Controller Class Initialized
INFO - 2018-02-16 12:47:09 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-16 12:47:09 --> Model Class Initialized
INFO - 2018-02-16 12:47:09 --> Model Class Initialized
INFO - 2018-02-16 12:47:09 --> Model Class Initialized
INFO - 2018-02-16 12:47:12 --> Config Class Initialized
INFO - 2018-02-16 12:47:12 --> Hooks Class Initialized
DEBUG - 2018-02-16 12:47:12 --> UTF-8 Support Enabled
INFO - 2018-02-16 12:47:12 --> Utf8 Class Initialized
INFO - 2018-02-16 12:47:12 --> URI Class Initialized
INFO - 2018-02-16 12:47:12 --> Router Class Initialized
INFO - 2018-02-16 12:47:12 --> Output Class Initialized
INFO - 2018-02-16 12:47:12 --> Security Class Initialized
DEBUG - 2018-02-16 12:47:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-16 12:47:12 --> Input Class Initialized
INFO - 2018-02-16 12:47:12 --> Language Class Initialized
INFO - 2018-02-16 12:47:12 --> Loader Class Initialized
INFO - 2018-02-16 12:47:12 --> Helper loaded: url_helper
INFO - 2018-02-16 12:47:12 --> Helper loaded: file_helper
INFO - 2018-02-16 12:47:12 --> Helper loaded: email_helper
INFO - 2018-02-16 12:47:12 --> Helper loaded: common_helper
INFO - 2018-02-16 12:47:12 --> Database Driver Class Initialized
DEBUG - 2018-02-16 12:47:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-16 12:47:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-16 12:47:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-16 12:47:12 --> Pagination Class Initialized
INFO - 2018-02-16 12:47:12 --> Helper loaded: form_helper
INFO - 2018-02-16 12:47:12 --> Form Validation Class Initialized
INFO - 2018-02-16 12:47:12 --> Model Class Initialized
INFO - 2018-02-16 12:47:12 --> Controller Class Initialized
INFO - 2018-02-16 12:47:12 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-16 12:47:12 --> Model Class Initialized
INFO - 2018-02-16 12:47:12 --> Model Class Initialized
INFO - 2018-02-16 12:47:12 --> Model Class Initialized
INFO - 2018-02-16 12:47:12 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-16 12:47:12 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-16 12:47:12 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-16 12:47:12 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-16 12:47:12 --> File loaded: /var/www/html/project/radio/application/views/tracks/add_edit.php
INFO - 2018-02-16 12:47:12 --> Final output sent to browser
DEBUG - 2018-02-16 12:47:12 --> Total execution time: 0.0065
INFO - 2018-02-16 12:47:16 --> Config Class Initialized
INFO - 2018-02-16 12:47:16 --> Hooks Class Initialized
DEBUG - 2018-02-16 12:47:16 --> UTF-8 Support Enabled
INFO - 2018-02-16 12:47:16 --> Utf8 Class Initialized
INFO - 2018-02-16 12:47:16 --> URI Class Initialized
INFO - 2018-02-16 12:47:16 --> Router Class Initialized
INFO - 2018-02-16 12:47:16 --> Output Class Initialized
INFO - 2018-02-16 12:47:16 --> Security Class Initialized
DEBUG - 2018-02-16 12:47:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-16 12:47:16 --> Input Class Initialized
INFO - 2018-02-16 12:47:16 --> Language Class Initialized
INFO - 2018-02-16 12:47:16 --> Loader Class Initialized
INFO - 2018-02-16 12:47:16 --> Helper loaded: url_helper
INFO - 2018-02-16 12:47:16 --> Helper loaded: file_helper
INFO - 2018-02-16 12:47:16 --> Helper loaded: email_helper
INFO - 2018-02-16 12:47:16 --> Helper loaded: common_helper
INFO - 2018-02-16 12:47:16 --> Database Driver Class Initialized
DEBUG - 2018-02-16 12:47:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-16 12:47:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-16 12:47:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-16 12:47:16 --> Pagination Class Initialized
INFO - 2018-02-16 12:47:16 --> Helper loaded: form_helper
INFO - 2018-02-16 12:47:16 --> Form Validation Class Initialized
INFO - 2018-02-16 12:47:16 --> Model Class Initialized
INFO - 2018-02-16 12:47:16 --> Controller Class Initialized
INFO - 2018-02-16 12:47:16 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-16 12:47:16 --> Model Class Initialized
INFO - 2018-02-16 12:47:16 --> Model Class Initialized
INFO - 2018-02-16 12:47:16 --> Model Class Initialized
INFO - 2018-02-16 12:47:16 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-16 12:47:16 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-16 12:47:16 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-16 12:47:16 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-16 12:47:16 --> File loaded: /var/www/html/project/radio/application/views/tracks/index.php
INFO - 2018-02-16 12:47:16 --> Final output sent to browser
DEBUG - 2018-02-16 12:47:16 --> Total execution time: 0.0041
INFO - 2018-02-16 12:47:17 --> Config Class Initialized
INFO - 2018-02-16 12:47:17 --> Hooks Class Initialized
DEBUG - 2018-02-16 12:47:17 --> UTF-8 Support Enabled
INFO - 2018-02-16 12:47:17 --> Utf8 Class Initialized
INFO - 2018-02-16 12:47:17 --> URI Class Initialized
INFO - 2018-02-16 12:47:17 --> Router Class Initialized
INFO - 2018-02-16 12:47:17 --> Output Class Initialized
INFO - 2018-02-16 12:47:17 --> Security Class Initialized
DEBUG - 2018-02-16 12:47:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-16 12:47:17 --> Input Class Initialized
INFO - 2018-02-16 12:47:17 --> Language Class Initialized
INFO - 2018-02-16 12:47:17 --> Loader Class Initialized
INFO - 2018-02-16 12:47:17 --> Helper loaded: url_helper
INFO - 2018-02-16 12:47:17 --> Helper loaded: file_helper
INFO - 2018-02-16 12:47:17 --> Helper loaded: email_helper
INFO - 2018-02-16 12:47:17 --> Helper loaded: common_helper
INFO - 2018-02-16 12:47:17 --> Database Driver Class Initialized
DEBUG - 2018-02-16 12:47:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-16 12:47:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-16 12:47:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-16 12:47:17 --> Pagination Class Initialized
INFO - 2018-02-16 12:47:17 --> Helper loaded: form_helper
INFO - 2018-02-16 12:47:17 --> Form Validation Class Initialized
INFO - 2018-02-16 12:47:17 --> Model Class Initialized
INFO - 2018-02-16 12:47:17 --> Controller Class Initialized
INFO - 2018-02-16 12:47:17 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-16 12:47:17 --> Model Class Initialized
INFO - 2018-02-16 12:47:17 --> Model Class Initialized
INFO - 2018-02-16 12:47:17 --> Model Class Initialized
INFO - 2018-02-16 12:47:28 --> Config Class Initialized
INFO - 2018-02-16 12:47:28 --> Hooks Class Initialized
DEBUG - 2018-02-16 12:47:28 --> UTF-8 Support Enabled
INFO - 2018-02-16 12:47:28 --> Utf8 Class Initialized
INFO - 2018-02-16 12:47:28 --> URI Class Initialized
INFO - 2018-02-16 12:47:28 --> Router Class Initialized
INFO - 2018-02-16 12:47:28 --> Output Class Initialized
INFO - 2018-02-16 12:47:28 --> Security Class Initialized
DEBUG - 2018-02-16 12:47:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-16 12:47:28 --> Input Class Initialized
INFO - 2018-02-16 12:47:28 --> Language Class Initialized
INFO - 2018-02-16 12:47:28 --> Loader Class Initialized
INFO - 2018-02-16 12:47:28 --> Helper loaded: url_helper
INFO - 2018-02-16 12:47:28 --> Helper loaded: file_helper
INFO - 2018-02-16 12:47:28 --> Helper loaded: email_helper
INFO - 2018-02-16 12:47:28 --> Helper loaded: common_helper
INFO - 2018-02-16 12:47:28 --> Database Driver Class Initialized
DEBUG - 2018-02-16 12:47:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-16 12:47:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-16 12:47:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-16 12:47:28 --> Pagination Class Initialized
INFO - 2018-02-16 12:47:28 --> Helper loaded: form_helper
INFO - 2018-02-16 12:47:28 --> Form Validation Class Initialized
INFO - 2018-02-16 12:47:28 --> Model Class Initialized
INFO - 2018-02-16 12:47:28 --> Controller Class Initialized
INFO - 2018-02-16 12:47:28 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-16 12:47:28 --> Model Class Initialized
INFO - 2018-02-16 12:47:28 --> Config Class Initialized
INFO - 2018-02-16 12:47:28 --> Hooks Class Initialized
DEBUG - 2018-02-16 12:47:28 --> UTF-8 Support Enabled
INFO - 2018-02-16 12:47:28 --> Utf8 Class Initialized
INFO - 2018-02-16 12:47:28 --> URI Class Initialized
INFO - 2018-02-16 12:47:28 --> Router Class Initialized
INFO - 2018-02-16 12:47:28 --> Output Class Initialized
INFO - 2018-02-16 12:47:28 --> Security Class Initialized
DEBUG - 2018-02-16 12:47:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-16 12:47:28 --> Input Class Initialized
INFO - 2018-02-16 12:47:28 --> Language Class Initialized
INFO - 2018-02-16 12:47:28 --> Loader Class Initialized
INFO - 2018-02-16 12:47:28 --> Helper loaded: url_helper
INFO - 2018-02-16 12:47:28 --> Helper loaded: file_helper
INFO - 2018-02-16 12:47:28 --> Helper loaded: email_helper
INFO - 2018-02-16 12:47:28 --> Helper loaded: common_helper
INFO - 2018-02-16 12:47:28 --> Database Driver Class Initialized
DEBUG - 2018-02-16 12:47:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-16 12:47:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-16 12:47:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-16 12:47:28 --> Pagination Class Initialized
INFO - 2018-02-16 12:47:28 --> Helper loaded: form_helper
INFO - 2018-02-16 12:47:28 --> Form Validation Class Initialized
INFO - 2018-02-16 12:47:28 --> Model Class Initialized
INFO - 2018-02-16 12:47:28 --> Controller Class Initialized
INFO - 2018-02-16 12:47:28 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-16 12:47:28 --> Model Class Initialized
INFO - 2018-02-16 12:47:28 --> File loaded: /var/www/html/project/radio/application/views/index/index.php
INFO - 2018-02-16 12:47:28 --> Final output sent to browser
DEBUG - 2018-02-16 12:47:28 --> Total execution time: 0.0038
INFO - 2018-02-16 12:48:07 --> Config Class Initialized
INFO - 2018-02-16 12:48:07 --> Hooks Class Initialized
DEBUG - 2018-02-16 12:48:07 --> UTF-8 Support Enabled
INFO - 2018-02-16 12:48:07 --> Utf8 Class Initialized
INFO - 2018-02-16 12:48:07 --> URI Class Initialized
INFO - 2018-02-16 12:48:07 --> Router Class Initialized
INFO - 2018-02-16 12:48:07 --> Output Class Initialized
INFO - 2018-02-16 12:48:07 --> Security Class Initialized
DEBUG - 2018-02-16 12:48:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-16 12:48:07 --> Input Class Initialized
INFO - 2018-02-16 12:48:07 --> Language Class Initialized
INFO - 2018-02-16 12:48:07 --> Loader Class Initialized
INFO - 2018-02-16 12:48:07 --> Helper loaded: url_helper
INFO - 2018-02-16 12:48:07 --> Helper loaded: file_helper
INFO - 2018-02-16 12:48:07 --> Helper loaded: email_helper
INFO - 2018-02-16 12:48:07 --> Helper loaded: common_helper
INFO - 2018-02-16 12:48:07 --> Database Driver Class Initialized
DEBUG - 2018-02-16 12:48:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-16 12:48:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-16 12:48:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-16 12:48:07 --> Pagination Class Initialized
INFO - 2018-02-16 12:48:07 --> Helper loaded: form_helper
INFO - 2018-02-16 12:48:07 --> Form Validation Class Initialized
INFO - 2018-02-16 12:48:07 --> Model Class Initialized
INFO - 2018-02-16 12:48:07 --> Controller Class Initialized
INFO - 2018-02-16 12:48:07 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-16 12:48:07 --> Model Class Initialized
INFO - 2018-02-16 12:48:07 --> File loaded: /var/www/html/project/radio/application/views/index/index.php
INFO - 2018-02-16 12:48:07 --> Final output sent to browser
DEBUG - 2018-02-16 12:48:07 --> Total execution time: 0.0069
INFO - 2018-02-16 12:48:14 --> Config Class Initialized
INFO - 2018-02-16 12:48:14 --> Hooks Class Initialized
DEBUG - 2018-02-16 12:48:14 --> UTF-8 Support Enabled
INFO - 2018-02-16 12:48:14 --> Utf8 Class Initialized
INFO - 2018-02-16 12:48:14 --> URI Class Initialized
INFO - 2018-02-16 12:48:14 --> Router Class Initialized
INFO - 2018-02-16 12:48:14 --> Output Class Initialized
INFO - 2018-02-16 12:48:14 --> Security Class Initialized
DEBUG - 2018-02-16 12:48:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-16 12:48:14 --> Input Class Initialized
INFO - 2018-02-16 12:48:14 --> Language Class Initialized
INFO - 2018-02-16 12:48:14 --> Loader Class Initialized
INFO - 2018-02-16 12:48:14 --> Helper loaded: url_helper
INFO - 2018-02-16 12:48:14 --> Helper loaded: file_helper
INFO - 2018-02-16 12:48:14 --> Helper loaded: email_helper
INFO - 2018-02-16 12:48:14 --> Helper loaded: common_helper
INFO - 2018-02-16 12:48:14 --> Database Driver Class Initialized
DEBUG - 2018-02-16 12:48:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-16 12:48:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-16 12:48:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-16 12:48:14 --> Pagination Class Initialized
INFO - 2018-02-16 12:48:14 --> Helper loaded: form_helper
INFO - 2018-02-16 12:48:14 --> Form Validation Class Initialized
INFO - 2018-02-16 12:48:14 --> Model Class Initialized
INFO - 2018-02-16 12:48:14 --> Controller Class Initialized
INFO - 2018-02-16 12:48:14 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-16 12:48:14 --> Model Class Initialized
INFO - 2018-02-16 12:48:14 --> File loaded: /var/www/html/project/radio/application/views/index/index.php
INFO - 2018-02-16 12:48:14 --> Final output sent to browser
DEBUG - 2018-02-16 12:48:14 --> Total execution time: 0.0062
INFO - 2018-02-16 12:49:00 --> Config Class Initialized
INFO - 2018-02-16 12:49:00 --> Hooks Class Initialized
DEBUG - 2018-02-16 12:49:00 --> UTF-8 Support Enabled
INFO - 2018-02-16 12:49:00 --> Utf8 Class Initialized
INFO - 2018-02-16 12:49:00 --> URI Class Initialized
INFO - 2018-02-16 12:49:00 --> Router Class Initialized
INFO - 2018-02-16 12:49:00 --> Output Class Initialized
INFO - 2018-02-16 12:49:00 --> Security Class Initialized
DEBUG - 2018-02-16 12:49:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-16 12:49:00 --> Input Class Initialized
INFO - 2018-02-16 12:49:00 --> Language Class Initialized
ERROR - 2018-02-16 12:49:00 --> 404 Page Not Found: Index/forgotpassword
INFO - 2018-02-16 12:49:01 --> Config Class Initialized
INFO - 2018-02-16 12:49:01 --> Hooks Class Initialized
DEBUG - 2018-02-16 12:49:01 --> UTF-8 Support Enabled
INFO - 2018-02-16 12:49:01 --> Utf8 Class Initialized
INFO - 2018-02-16 12:49:01 --> URI Class Initialized
INFO - 2018-02-16 12:49:01 --> Router Class Initialized
INFO - 2018-02-16 12:49:01 --> Output Class Initialized
INFO - 2018-02-16 12:49:01 --> Security Class Initialized
DEBUG - 2018-02-16 12:49:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-16 12:49:01 --> Input Class Initialized
INFO - 2018-02-16 12:49:01 --> Language Class Initialized
INFO - 2018-02-16 12:49:01 --> Loader Class Initialized
INFO - 2018-02-16 12:49:01 --> Helper loaded: url_helper
INFO - 2018-02-16 12:49:01 --> Helper loaded: file_helper
INFO - 2018-02-16 12:49:01 --> Helper loaded: email_helper
INFO - 2018-02-16 12:49:01 --> Helper loaded: common_helper
INFO - 2018-02-16 12:49:01 --> Database Driver Class Initialized
DEBUG - 2018-02-16 12:49:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-16 12:49:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-16 12:49:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-16 12:49:01 --> Pagination Class Initialized
INFO - 2018-02-16 12:49:01 --> Helper loaded: form_helper
INFO - 2018-02-16 12:49:01 --> Form Validation Class Initialized
INFO - 2018-02-16 12:49:01 --> Model Class Initialized
INFO - 2018-02-16 12:49:01 --> Controller Class Initialized
INFO - 2018-02-16 12:49:01 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-16 12:49:01 --> Model Class Initialized
INFO - 2018-02-16 12:49:01 --> File loaded: /var/www/html/project/radio/application/views/index/index.php
INFO - 2018-02-16 12:49:01 --> Final output sent to browser
DEBUG - 2018-02-16 12:49:01 --> Total execution time: 0.0039
INFO - 2018-02-16 12:50:42 --> Config Class Initialized
INFO - 2018-02-16 12:50:42 --> Hooks Class Initialized
DEBUG - 2018-02-16 12:50:42 --> UTF-8 Support Enabled
INFO - 2018-02-16 12:50:42 --> Utf8 Class Initialized
INFO - 2018-02-16 12:50:42 --> URI Class Initialized
INFO - 2018-02-16 12:50:42 --> Router Class Initialized
INFO - 2018-02-16 12:50:42 --> Output Class Initialized
INFO - 2018-02-16 12:50:42 --> Security Class Initialized
DEBUG - 2018-02-16 12:50:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-16 12:50:42 --> Input Class Initialized
INFO - 2018-02-16 12:50:42 --> Language Class Initialized
INFO - 2018-02-16 12:50:42 --> Loader Class Initialized
INFO - 2018-02-16 12:50:42 --> Helper loaded: url_helper
INFO - 2018-02-16 12:50:42 --> Helper loaded: file_helper
INFO - 2018-02-16 12:50:42 --> Helper loaded: email_helper
INFO - 2018-02-16 12:50:42 --> Helper loaded: common_helper
INFO - 2018-02-16 12:50:42 --> Database Driver Class Initialized
DEBUG - 2018-02-16 12:50:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-16 12:50:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-16 12:50:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-16 12:50:42 --> Pagination Class Initialized
INFO - 2018-02-16 12:50:42 --> Helper loaded: form_helper
INFO - 2018-02-16 12:50:42 --> Form Validation Class Initialized
INFO - 2018-02-16 12:50:42 --> Model Class Initialized
INFO - 2018-02-16 12:50:42 --> Controller Class Initialized
INFO - 2018-02-16 12:50:42 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-16 12:50:42 --> Model Class Initialized
INFO - 2018-02-16 12:50:42 --> File loaded: /var/www/html/project/radio/application/views/index/index.php
INFO - 2018-02-16 12:50:42 --> Final output sent to browser
DEBUG - 2018-02-16 12:50:42 --> Total execution time: 0.0061
INFO - 2018-02-16 12:50:51 --> Config Class Initialized
INFO - 2018-02-16 12:50:51 --> Hooks Class Initialized
DEBUG - 2018-02-16 12:50:51 --> UTF-8 Support Enabled
INFO - 2018-02-16 12:50:51 --> Utf8 Class Initialized
INFO - 2018-02-16 12:50:51 --> URI Class Initialized
INFO - 2018-02-16 12:50:51 --> Router Class Initialized
INFO - 2018-02-16 12:50:51 --> Output Class Initialized
INFO - 2018-02-16 12:50:51 --> Security Class Initialized
DEBUG - 2018-02-16 12:50:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-16 12:50:51 --> Input Class Initialized
INFO - 2018-02-16 12:50:51 --> Language Class Initialized
INFO - 2018-02-16 12:50:51 --> Loader Class Initialized
INFO - 2018-02-16 12:50:51 --> Helper loaded: url_helper
INFO - 2018-02-16 12:50:51 --> Helper loaded: file_helper
INFO - 2018-02-16 12:50:51 --> Helper loaded: email_helper
INFO - 2018-02-16 12:50:51 --> Helper loaded: common_helper
INFO - 2018-02-16 12:50:51 --> Database Driver Class Initialized
DEBUG - 2018-02-16 12:50:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-16 12:50:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-16 12:50:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-16 12:50:51 --> Pagination Class Initialized
INFO - 2018-02-16 12:50:51 --> Helper loaded: form_helper
INFO - 2018-02-16 12:50:51 --> Form Validation Class Initialized
INFO - 2018-02-16 12:50:51 --> Model Class Initialized
INFO - 2018-02-16 12:50:51 --> Controller Class Initialized
INFO - 2018-02-16 12:50:51 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-16 12:50:51 --> Model Class Initialized
INFO - 2018-02-16 12:50:51 --> File loaded: /var/www/html/project/radio/application/views/index/index.php
INFO - 2018-02-16 12:50:51 --> Final output sent to browser
DEBUG - 2018-02-16 12:50:51 --> Total execution time: 0.0055
INFO - 2018-02-16 12:51:03 --> Config Class Initialized
INFO - 2018-02-16 12:51:03 --> Hooks Class Initialized
DEBUG - 2018-02-16 12:51:03 --> UTF-8 Support Enabled
INFO - 2018-02-16 12:51:03 --> Utf8 Class Initialized
INFO - 2018-02-16 12:51:03 --> URI Class Initialized
INFO - 2018-02-16 12:51:03 --> Router Class Initialized
INFO - 2018-02-16 12:51:03 --> Output Class Initialized
INFO - 2018-02-16 12:51:03 --> Security Class Initialized
DEBUG - 2018-02-16 12:51:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-16 12:51:03 --> Input Class Initialized
INFO - 2018-02-16 12:51:03 --> Language Class Initialized
INFO - 2018-02-16 12:51:03 --> Loader Class Initialized
INFO - 2018-02-16 12:51:03 --> Helper loaded: url_helper
INFO - 2018-02-16 12:51:03 --> Helper loaded: file_helper
INFO - 2018-02-16 12:51:03 --> Helper loaded: email_helper
INFO - 2018-02-16 12:51:03 --> Helper loaded: common_helper
INFO - 2018-02-16 12:51:03 --> Database Driver Class Initialized
DEBUG - 2018-02-16 12:51:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-16 12:51:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-16 12:51:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-16 12:51:03 --> Pagination Class Initialized
INFO - 2018-02-16 12:51:03 --> Helper loaded: form_helper
INFO - 2018-02-16 12:51:03 --> Form Validation Class Initialized
INFO - 2018-02-16 12:51:03 --> Model Class Initialized
INFO - 2018-02-16 12:51:03 --> Controller Class Initialized
INFO - 2018-02-16 12:51:03 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-16 12:51:03 --> Model Class Initialized
ERROR - 2018-02-16 12:51:03 --> Severity: Notice --> Undefined index: remember_me /var/www/html/project/radio/application/controllers/Index.php 73
INFO - 2018-02-16 12:51:03 --> Config Class Initialized
INFO - 2018-02-16 12:51:03 --> Hooks Class Initialized
DEBUG - 2018-02-16 12:51:03 --> UTF-8 Support Enabled
INFO - 2018-02-16 12:51:03 --> Utf8 Class Initialized
INFO - 2018-02-16 12:51:03 --> URI Class Initialized
INFO - 2018-02-16 12:51:03 --> Router Class Initialized
INFO - 2018-02-16 12:51:03 --> Output Class Initialized
INFO - 2018-02-16 12:51:03 --> Security Class Initialized
DEBUG - 2018-02-16 12:51:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-16 12:51:03 --> Input Class Initialized
INFO - 2018-02-16 12:51:03 --> Language Class Initialized
INFO - 2018-02-16 12:51:03 --> Loader Class Initialized
INFO - 2018-02-16 12:51:03 --> Helper loaded: url_helper
INFO - 2018-02-16 12:51:03 --> Helper loaded: file_helper
INFO - 2018-02-16 12:51:03 --> Helper loaded: email_helper
INFO - 2018-02-16 12:51:03 --> Helper loaded: common_helper
INFO - 2018-02-16 12:51:03 --> Database Driver Class Initialized
DEBUG - 2018-02-16 12:51:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-16 12:51:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-16 12:51:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-16 12:51:03 --> Pagination Class Initialized
INFO - 2018-02-16 12:51:03 --> Helper loaded: form_helper
INFO - 2018-02-16 12:51:03 --> Form Validation Class Initialized
INFO - 2018-02-16 12:51:03 --> Model Class Initialized
INFO - 2018-02-16 12:51:03 --> Controller Class Initialized
INFO - 2018-02-16 12:51:03 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-16 12:51:03 --> Model Class Initialized
INFO - 2018-02-16 12:51:03 --> Model Class Initialized
INFO - 2018-02-16 12:51:03 --> Model Class Initialized
INFO - 2018-02-16 12:51:03 --> Model Class Initialized
INFO - 2018-02-16 12:51:03 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-16 12:51:03 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-16 12:51:03 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-16 12:51:03 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-16 12:51:03 --> File loaded: /var/www/html/project/radio/application/views/dashboard/index.php
INFO - 2018-02-16 12:51:03 --> Final output sent to browser
DEBUG - 2018-02-16 12:51:03 --> Total execution time: 0.0047
INFO - 2018-02-16 12:51:06 --> Config Class Initialized
INFO - 2018-02-16 12:51:06 --> Hooks Class Initialized
DEBUG - 2018-02-16 12:51:06 --> UTF-8 Support Enabled
INFO - 2018-02-16 12:51:06 --> Utf8 Class Initialized
INFO - 2018-02-16 12:51:06 --> URI Class Initialized
INFO - 2018-02-16 12:51:06 --> Router Class Initialized
INFO - 2018-02-16 12:51:06 --> Output Class Initialized
INFO - 2018-02-16 12:51:06 --> Security Class Initialized
DEBUG - 2018-02-16 12:51:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-16 12:51:06 --> Input Class Initialized
INFO - 2018-02-16 12:51:06 --> Language Class Initialized
INFO - 2018-02-16 12:51:06 --> Loader Class Initialized
INFO - 2018-02-16 12:51:06 --> Helper loaded: url_helper
INFO - 2018-02-16 12:51:06 --> Helper loaded: file_helper
INFO - 2018-02-16 12:51:06 --> Helper loaded: email_helper
INFO - 2018-02-16 12:51:06 --> Helper loaded: common_helper
INFO - 2018-02-16 12:51:06 --> Database Driver Class Initialized
DEBUG - 2018-02-16 12:51:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-16 12:51:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-16 12:51:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-16 12:51:06 --> Pagination Class Initialized
INFO - 2018-02-16 12:51:06 --> Helper loaded: form_helper
INFO - 2018-02-16 12:51:06 --> Form Validation Class Initialized
INFO - 2018-02-16 12:51:06 --> Model Class Initialized
INFO - 2018-02-16 12:51:06 --> Controller Class Initialized
INFO - 2018-02-16 12:51:06 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-16 12:51:06 --> Model Class Initialized
INFO - 2018-02-16 12:51:06 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-16 12:51:06 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-16 12:51:06 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-16 12:51:06 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-16 12:51:06 --> File loaded: /var/www/html/project/radio/application/views/user/index.php
INFO - 2018-02-16 12:51:06 --> Final output sent to browser
DEBUG - 2018-02-16 12:51:06 --> Total execution time: 0.0043
INFO - 2018-02-16 12:51:06 --> Config Class Initialized
INFO - 2018-02-16 12:51:06 --> Hooks Class Initialized
DEBUG - 2018-02-16 12:51:06 --> UTF-8 Support Enabled
INFO - 2018-02-16 12:51:06 --> Utf8 Class Initialized
INFO - 2018-02-16 12:51:06 --> URI Class Initialized
INFO - 2018-02-16 12:51:06 --> Router Class Initialized
INFO - 2018-02-16 12:51:06 --> Output Class Initialized
INFO - 2018-02-16 12:51:06 --> Security Class Initialized
DEBUG - 2018-02-16 12:51:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-16 12:51:06 --> Input Class Initialized
INFO - 2018-02-16 12:51:06 --> Language Class Initialized
INFO - 2018-02-16 12:51:06 --> Loader Class Initialized
INFO - 2018-02-16 12:51:06 --> Helper loaded: url_helper
INFO - 2018-02-16 12:51:06 --> Helper loaded: file_helper
INFO - 2018-02-16 12:51:06 --> Helper loaded: email_helper
INFO - 2018-02-16 12:51:06 --> Helper loaded: common_helper
INFO - 2018-02-16 12:51:06 --> Database Driver Class Initialized
DEBUG - 2018-02-16 12:51:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-16 12:51:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-16 12:51:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-16 12:51:06 --> Pagination Class Initialized
INFO - 2018-02-16 12:51:06 --> Helper loaded: form_helper
INFO - 2018-02-16 12:51:06 --> Form Validation Class Initialized
INFO - 2018-02-16 12:51:06 --> Model Class Initialized
INFO - 2018-02-16 12:51:06 --> Controller Class Initialized
INFO - 2018-02-16 12:51:06 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-16 12:51:06 --> Model Class Initialized
INFO - 2018-02-16 12:51:09 --> Config Class Initialized
INFO - 2018-02-16 12:51:09 --> Hooks Class Initialized
DEBUG - 2018-02-16 12:51:09 --> UTF-8 Support Enabled
INFO - 2018-02-16 12:51:09 --> Utf8 Class Initialized
INFO - 2018-02-16 12:51:09 --> URI Class Initialized
INFO - 2018-02-16 12:51:09 --> Router Class Initialized
INFO - 2018-02-16 12:51:09 --> Output Class Initialized
INFO - 2018-02-16 12:51:09 --> Security Class Initialized
DEBUG - 2018-02-16 12:51:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-16 12:51:09 --> Input Class Initialized
INFO - 2018-02-16 12:51:09 --> Language Class Initialized
INFO - 2018-02-16 12:51:09 --> Loader Class Initialized
INFO - 2018-02-16 12:51:09 --> Helper loaded: url_helper
INFO - 2018-02-16 12:51:09 --> Helper loaded: file_helper
INFO - 2018-02-16 12:51:09 --> Helper loaded: email_helper
INFO - 2018-02-16 12:51:09 --> Helper loaded: common_helper
INFO - 2018-02-16 12:51:09 --> Database Driver Class Initialized
DEBUG - 2018-02-16 12:51:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-16 12:51:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-16 12:51:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-16 12:51:09 --> Pagination Class Initialized
INFO - 2018-02-16 12:51:09 --> Helper loaded: form_helper
INFO - 2018-02-16 12:51:09 --> Form Validation Class Initialized
INFO - 2018-02-16 12:51:09 --> Model Class Initialized
INFO - 2018-02-16 12:51:09 --> Controller Class Initialized
INFO - 2018-02-16 12:51:09 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-16 12:51:09 --> Model Class Initialized
INFO - 2018-02-16 12:51:09 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-16 12:51:09 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-16 12:51:09 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-16 12:51:09 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-16 12:51:09 --> File loaded: /var/www/html/project/radio/application/views/category/index.php
INFO - 2018-02-16 12:51:09 --> Final output sent to browser
DEBUG - 2018-02-16 12:51:09 --> Total execution time: 0.0068
INFO - 2018-02-16 12:51:13 --> Config Class Initialized
INFO - 2018-02-16 12:51:13 --> Hooks Class Initialized
DEBUG - 2018-02-16 12:51:13 --> UTF-8 Support Enabled
INFO - 2018-02-16 12:51:13 --> Utf8 Class Initialized
INFO - 2018-02-16 12:51:13 --> URI Class Initialized
INFO - 2018-02-16 12:51:13 --> Router Class Initialized
INFO - 2018-02-16 12:51:13 --> Output Class Initialized
INFO - 2018-02-16 12:51:13 --> Security Class Initialized
DEBUG - 2018-02-16 12:51:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-16 12:51:13 --> Input Class Initialized
INFO - 2018-02-16 12:51:13 --> Language Class Initialized
INFO - 2018-02-16 12:51:13 --> Loader Class Initialized
INFO - 2018-02-16 12:51:13 --> Helper loaded: url_helper
INFO - 2018-02-16 12:51:13 --> Helper loaded: file_helper
INFO - 2018-02-16 12:51:13 --> Helper loaded: email_helper
INFO - 2018-02-16 12:51:13 --> Helper loaded: common_helper
INFO - 2018-02-16 12:51:13 --> Database Driver Class Initialized
DEBUG - 2018-02-16 12:51:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-16 12:51:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-16 12:51:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-16 12:51:13 --> Pagination Class Initialized
INFO - 2018-02-16 12:51:13 --> Helper loaded: form_helper
INFO - 2018-02-16 12:51:13 --> Form Validation Class Initialized
INFO - 2018-02-16 12:51:13 --> Model Class Initialized
INFO - 2018-02-16 12:51:13 --> Controller Class Initialized
INFO - 2018-02-16 12:51:13 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-16 12:51:13 --> Model Class Initialized
INFO - 2018-02-16 12:51:13 --> Model Class Initialized
INFO - 2018-02-16 12:51:13 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-16 12:51:13 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-16 12:51:13 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-16 12:51:13 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-16 12:51:13 --> File loaded: /var/www/html/project/radio/application/views/subcategory/index.php
INFO - 2018-02-16 12:51:13 --> Final output sent to browser
DEBUG - 2018-02-16 12:51:13 --> Total execution time: 0.0072
INFO - 2018-02-16 12:51:14 --> Config Class Initialized
INFO - 2018-02-16 12:51:14 --> Hooks Class Initialized
DEBUG - 2018-02-16 12:51:14 --> UTF-8 Support Enabled
INFO - 2018-02-16 12:51:14 --> Utf8 Class Initialized
INFO - 2018-02-16 12:51:14 --> URI Class Initialized
INFO - 2018-02-16 12:51:14 --> Router Class Initialized
INFO - 2018-02-16 12:51:14 --> Output Class Initialized
INFO - 2018-02-16 12:51:14 --> Security Class Initialized
DEBUG - 2018-02-16 12:51:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-16 12:51:14 --> Input Class Initialized
INFO - 2018-02-16 12:51:14 --> Language Class Initialized
INFO - 2018-02-16 12:51:14 --> Loader Class Initialized
INFO - 2018-02-16 12:51:14 --> Helper loaded: url_helper
INFO - 2018-02-16 12:51:14 --> Helper loaded: file_helper
INFO - 2018-02-16 12:51:14 --> Helper loaded: email_helper
INFO - 2018-02-16 12:51:14 --> Helper loaded: common_helper
INFO - 2018-02-16 12:51:14 --> Database Driver Class Initialized
DEBUG - 2018-02-16 12:51:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-16 12:51:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-16 12:51:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-16 12:51:14 --> Pagination Class Initialized
INFO - 2018-02-16 12:51:14 --> Helper loaded: form_helper
INFO - 2018-02-16 12:51:14 --> Form Validation Class Initialized
INFO - 2018-02-16 12:51:14 --> Model Class Initialized
INFO - 2018-02-16 12:51:14 --> Controller Class Initialized
INFO - 2018-02-16 12:51:14 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-16 12:51:14 --> Model Class Initialized
INFO - 2018-02-16 12:51:14 --> Model Class Initialized
INFO - 2018-02-16 12:51:14 --> Model Class Initialized
INFO - 2018-02-16 12:51:14 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-16 12:51:14 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-16 12:51:14 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-16 12:51:14 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-16 12:51:14 --> File loaded: /var/www/html/project/radio/application/views/tracks/index.php
INFO - 2018-02-16 12:51:14 --> Final output sent to browser
DEBUG - 2018-02-16 12:51:14 --> Total execution time: 0.0046
INFO - 2018-02-16 12:51:14 --> Config Class Initialized
INFO - 2018-02-16 12:51:14 --> Hooks Class Initialized
DEBUG - 2018-02-16 12:51:14 --> UTF-8 Support Enabled
INFO - 2018-02-16 12:51:14 --> Utf8 Class Initialized
INFO - 2018-02-16 12:51:14 --> URI Class Initialized
INFO - 2018-02-16 12:51:14 --> Router Class Initialized
INFO - 2018-02-16 12:51:14 --> Output Class Initialized
INFO - 2018-02-16 12:51:14 --> Security Class Initialized
DEBUG - 2018-02-16 12:51:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-16 12:51:14 --> Input Class Initialized
INFO - 2018-02-16 12:51:14 --> Language Class Initialized
INFO - 2018-02-16 12:51:14 --> Loader Class Initialized
INFO - 2018-02-16 12:51:14 --> Helper loaded: url_helper
INFO - 2018-02-16 12:51:14 --> Helper loaded: file_helper
INFO - 2018-02-16 12:51:14 --> Helper loaded: email_helper
INFO - 2018-02-16 12:51:14 --> Helper loaded: common_helper
INFO - 2018-02-16 12:51:14 --> Database Driver Class Initialized
DEBUG - 2018-02-16 12:51:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-16 12:51:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-16 12:51:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-16 12:51:14 --> Pagination Class Initialized
INFO - 2018-02-16 12:51:14 --> Helper loaded: form_helper
INFO - 2018-02-16 12:51:14 --> Form Validation Class Initialized
INFO - 2018-02-16 12:51:14 --> Model Class Initialized
INFO - 2018-02-16 12:51:14 --> Controller Class Initialized
INFO - 2018-02-16 12:51:14 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-16 12:51:14 --> Model Class Initialized
INFO - 2018-02-16 12:51:14 --> Model Class Initialized
INFO - 2018-02-16 12:51:14 --> Model Class Initialized
INFO - 2018-02-16 12:51:16 --> Config Class Initialized
INFO - 2018-02-16 12:51:16 --> Hooks Class Initialized
DEBUG - 2018-02-16 12:51:16 --> UTF-8 Support Enabled
INFO - 2018-02-16 12:51:16 --> Utf8 Class Initialized
INFO - 2018-02-16 12:51:16 --> URI Class Initialized
INFO - 2018-02-16 12:51:16 --> Router Class Initialized
INFO - 2018-02-16 12:51:16 --> Output Class Initialized
INFO - 2018-02-16 12:51:16 --> Security Class Initialized
DEBUG - 2018-02-16 12:51:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-16 12:51:16 --> Input Class Initialized
INFO - 2018-02-16 12:51:16 --> Language Class Initialized
INFO - 2018-02-16 12:51:16 --> Loader Class Initialized
INFO - 2018-02-16 12:51:16 --> Helper loaded: url_helper
INFO - 2018-02-16 12:51:16 --> Helper loaded: file_helper
INFO - 2018-02-16 12:51:16 --> Helper loaded: email_helper
INFO - 2018-02-16 12:51:16 --> Helper loaded: common_helper
INFO - 2018-02-16 12:51:16 --> Database Driver Class Initialized
DEBUG - 2018-02-16 12:51:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-16 12:51:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-16 12:51:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-16 12:51:16 --> Pagination Class Initialized
INFO - 2018-02-16 12:51:16 --> Helper loaded: form_helper
INFO - 2018-02-16 12:51:16 --> Form Validation Class Initialized
INFO - 2018-02-16 12:51:16 --> Model Class Initialized
INFO - 2018-02-16 12:51:16 --> Controller Class Initialized
INFO - 2018-02-16 12:51:16 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-16 12:51:16 --> Model Class Initialized
INFO - 2018-02-16 12:51:16 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-16 12:51:16 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-16 12:51:16 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-16 12:51:16 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-16 12:51:16 --> File loaded: /var/www/html/project/radio/application/views/user/index.php
INFO - 2018-02-16 12:51:16 --> Final output sent to browser
DEBUG - 2018-02-16 12:51:16 --> Total execution time: 0.0035
INFO - 2018-02-16 12:51:16 --> Config Class Initialized
INFO - 2018-02-16 12:51:16 --> Hooks Class Initialized
DEBUG - 2018-02-16 12:51:16 --> UTF-8 Support Enabled
INFO - 2018-02-16 12:51:16 --> Utf8 Class Initialized
INFO - 2018-02-16 12:51:16 --> URI Class Initialized
INFO - 2018-02-16 12:51:16 --> Router Class Initialized
INFO - 2018-02-16 12:51:16 --> Output Class Initialized
INFO - 2018-02-16 12:51:16 --> Security Class Initialized
DEBUG - 2018-02-16 12:51:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-16 12:51:16 --> Input Class Initialized
INFO - 2018-02-16 12:51:16 --> Language Class Initialized
INFO - 2018-02-16 12:51:16 --> Loader Class Initialized
INFO - 2018-02-16 12:51:16 --> Helper loaded: url_helper
INFO - 2018-02-16 12:51:16 --> Helper loaded: file_helper
INFO - 2018-02-16 12:51:16 --> Helper loaded: email_helper
INFO - 2018-02-16 12:51:16 --> Helper loaded: common_helper
INFO - 2018-02-16 12:51:16 --> Database Driver Class Initialized
DEBUG - 2018-02-16 12:51:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-16 12:51:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-16 12:51:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-16 12:51:16 --> Pagination Class Initialized
INFO - 2018-02-16 12:51:16 --> Helper loaded: form_helper
INFO - 2018-02-16 12:51:16 --> Form Validation Class Initialized
INFO - 2018-02-16 12:51:16 --> Model Class Initialized
INFO - 2018-02-16 12:51:16 --> Controller Class Initialized
INFO - 2018-02-16 12:51:16 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-16 12:51:16 --> Model Class Initialized
INFO - 2018-02-16 12:52:49 --> Config Class Initialized
INFO - 2018-02-16 12:52:49 --> Hooks Class Initialized
DEBUG - 2018-02-16 12:52:49 --> UTF-8 Support Enabled
INFO - 2018-02-16 12:52:49 --> Utf8 Class Initialized
INFO - 2018-02-16 12:52:49 --> URI Class Initialized
INFO - 2018-02-16 12:52:49 --> Router Class Initialized
INFO - 2018-02-16 12:52:49 --> Output Class Initialized
INFO - 2018-02-16 12:52:49 --> Security Class Initialized
DEBUG - 2018-02-16 12:52:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-16 12:52:49 --> Input Class Initialized
INFO - 2018-02-16 12:52:49 --> Language Class Initialized
INFO - 2018-02-16 12:52:49 --> Loader Class Initialized
INFO - 2018-02-16 12:52:49 --> Helper loaded: url_helper
INFO - 2018-02-16 12:52:49 --> Helper loaded: file_helper
INFO - 2018-02-16 12:52:49 --> Helper loaded: email_helper
INFO - 2018-02-16 12:52:49 --> Helper loaded: common_helper
INFO - 2018-02-16 12:52:49 --> Database Driver Class Initialized
DEBUG - 2018-02-16 12:52:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-16 12:52:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-16 12:52:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-16 12:52:49 --> Pagination Class Initialized
INFO - 2018-02-16 12:52:49 --> Helper loaded: form_helper
INFO - 2018-02-16 12:52:49 --> Form Validation Class Initialized
INFO - 2018-02-16 12:52:49 --> Model Class Initialized
INFO - 2018-02-16 12:52:49 --> Controller Class Initialized
INFO - 2018-02-16 12:52:49 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-16 12:52:49 --> Model Class Initialized
INFO - 2018-02-16 12:52:49 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-16 12:52:49 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-16 12:52:49 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-16 12:52:49 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-16 12:52:49 --> File loaded: /var/www/html/project/radio/application/views/category/index.php
INFO - 2018-02-16 12:52:49 --> Final output sent to browser
DEBUG - 2018-02-16 12:52:49 --> Total execution time: 0.0070
INFO - 2018-02-16 12:52:53 --> Config Class Initialized
INFO - 2018-02-16 12:52:53 --> Hooks Class Initialized
DEBUG - 2018-02-16 12:52:53 --> UTF-8 Support Enabled
INFO - 2018-02-16 12:52:53 --> Utf8 Class Initialized
INFO - 2018-02-16 12:52:53 --> URI Class Initialized
INFO - 2018-02-16 12:52:53 --> Router Class Initialized
INFO - 2018-02-16 12:52:53 --> Output Class Initialized
INFO - 2018-02-16 12:52:53 --> Security Class Initialized
DEBUG - 2018-02-16 12:52:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-16 12:52:53 --> Input Class Initialized
INFO - 2018-02-16 12:52:53 --> Language Class Initialized
INFO - 2018-02-16 12:52:53 --> Loader Class Initialized
INFO - 2018-02-16 12:52:53 --> Helper loaded: url_helper
INFO - 2018-02-16 12:52:53 --> Helper loaded: file_helper
INFO - 2018-02-16 12:52:53 --> Helper loaded: email_helper
INFO - 2018-02-16 12:52:53 --> Helper loaded: common_helper
INFO - 2018-02-16 12:52:53 --> Database Driver Class Initialized
DEBUG - 2018-02-16 12:52:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-16 12:52:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-16 12:52:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-16 12:52:53 --> Pagination Class Initialized
INFO - 2018-02-16 12:52:53 --> Helper loaded: form_helper
INFO - 2018-02-16 12:52:53 --> Form Validation Class Initialized
INFO - 2018-02-16 12:52:53 --> Model Class Initialized
INFO - 2018-02-16 12:52:53 --> Controller Class Initialized
INFO - 2018-02-16 12:52:53 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-16 12:52:53 --> Model Class Initialized
INFO - 2018-02-16 12:52:53 --> Model Class Initialized
INFO - 2018-02-16 12:52:53 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-16 12:52:53 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-16 12:52:53 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-16 12:52:53 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-16 12:52:53 --> File loaded: /var/www/html/project/radio/application/views/subcategory/index.php
INFO - 2018-02-16 12:52:53 --> Final output sent to browser
DEBUG - 2018-02-16 12:52:53 --> Total execution time: 0.0052
INFO - 2018-02-16 13:00:05 --> Config Class Initialized
INFO - 2018-02-16 13:00:05 --> Hooks Class Initialized
DEBUG - 2018-02-16 13:00:05 --> UTF-8 Support Enabled
INFO - 2018-02-16 13:00:05 --> Utf8 Class Initialized
INFO - 2018-02-16 13:00:05 --> URI Class Initialized
INFO - 2018-02-16 13:00:05 --> Router Class Initialized
INFO - 2018-02-16 13:00:05 --> Output Class Initialized
INFO - 2018-02-16 13:00:05 --> Security Class Initialized
DEBUG - 2018-02-16 13:00:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-16 13:00:05 --> Input Class Initialized
INFO - 2018-02-16 13:00:05 --> Language Class Initialized
INFO - 2018-02-16 13:00:05 --> Loader Class Initialized
INFO - 2018-02-16 13:00:05 --> Helper loaded: url_helper
INFO - 2018-02-16 13:00:05 --> Helper loaded: file_helper
INFO - 2018-02-16 13:00:05 --> Helper loaded: email_helper
INFO - 2018-02-16 13:00:05 --> Helper loaded: common_helper
INFO - 2018-02-16 13:00:05 --> Database Driver Class Initialized
DEBUG - 2018-02-16 13:00:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-16 13:00:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-16 13:00:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-16 13:00:05 --> Pagination Class Initialized
INFO - 2018-02-16 13:00:05 --> Helper loaded: form_helper
INFO - 2018-02-16 13:00:05 --> Form Validation Class Initialized
INFO - 2018-02-16 13:00:05 --> Model Class Initialized
INFO - 2018-02-16 13:00:05 --> Controller Class Initialized
INFO - 2018-02-16 13:00:05 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-16 13:00:05 --> Model Class Initialized
INFO - 2018-02-16 13:00:05 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-16 13:00:05 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-16 13:00:05 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-16 13:00:05 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-16 13:00:05 --> File loaded: /var/www/html/project/radio/application/views/user/index.php
INFO - 2018-02-16 13:00:05 --> Final output sent to browser
DEBUG - 2018-02-16 13:00:05 --> Total execution time: 0.0059
INFO - 2018-02-16 13:00:05 --> Config Class Initialized
INFO - 2018-02-16 13:00:05 --> Hooks Class Initialized
DEBUG - 2018-02-16 13:00:05 --> UTF-8 Support Enabled
INFO - 2018-02-16 13:00:05 --> Utf8 Class Initialized
INFO - 2018-02-16 13:00:05 --> URI Class Initialized
INFO - 2018-02-16 13:00:05 --> Router Class Initialized
INFO - 2018-02-16 13:00:05 --> Output Class Initialized
INFO - 2018-02-16 13:00:05 --> Security Class Initialized
DEBUG - 2018-02-16 13:00:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-16 13:00:05 --> Input Class Initialized
INFO - 2018-02-16 13:00:05 --> Language Class Initialized
INFO - 2018-02-16 13:00:05 --> Loader Class Initialized
INFO - 2018-02-16 13:00:05 --> Helper loaded: url_helper
INFO - 2018-02-16 13:00:05 --> Helper loaded: file_helper
INFO - 2018-02-16 13:00:05 --> Helper loaded: email_helper
INFO - 2018-02-16 13:00:05 --> Helper loaded: common_helper
INFO - 2018-02-16 13:00:05 --> Database Driver Class Initialized
DEBUG - 2018-02-16 13:00:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-16 13:00:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-16 13:00:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-16 13:00:05 --> Pagination Class Initialized
INFO - 2018-02-16 13:00:05 --> Helper loaded: form_helper
INFO - 2018-02-16 13:00:05 --> Form Validation Class Initialized
INFO - 2018-02-16 13:00:05 --> Model Class Initialized
INFO - 2018-02-16 13:00:05 --> Controller Class Initialized
INFO - 2018-02-16 13:00:05 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-16 13:00:05 --> Model Class Initialized
INFO - 2018-02-16 13:26:14 --> Config Class Initialized
INFO - 2018-02-16 13:26:14 --> Hooks Class Initialized
DEBUG - 2018-02-16 13:26:14 --> UTF-8 Support Enabled
INFO - 2018-02-16 13:26:14 --> Utf8 Class Initialized
INFO - 2018-02-16 13:26:14 --> URI Class Initialized
INFO - 2018-02-16 13:26:14 --> Router Class Initialized
INFO - 2018-02-16 13:26:14 --> Output Class Initialized
INFO - 2018-02-16 13:26:14 --> Security Class Initialized
DEBUG - 2018-02-16 13:26:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-16 13:26:14 --> Input Class Initialized
INFO - 2018-02-16 13:26:14 --> Language Class Initialized
INFO - 2018-02-16 13:26:14 --> Loader Class Initialized
INFO - 2018-02-16 13:26:14 --> Helper loaded: url_helper
INFO - 2018-02-16 13:26:14 --> Helper loaded: file_helper
INFO - 2018-02-16 13:26:14 --> Helper loaded: email_helper
INFO - 2018-02-16 13:26:14 --> Helper loaded: common_helper
INFO - 2018-02-16 13:26:14 --> Database Driver Class Initialized
DEBUG - 2018-02-16 13:26:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-16 13:26:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-16 13:26:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-16 13:26:14 --> Pagination Class Initialized
INFO - 2018-02-16 13:26:14 --> Helper loaded: form_helper
INFO - 2018-02-16 13:26:14 --> Form Validation Class Initialized
INFO - 2018-02-16 13:26:14 --> Model Class Initialized
INFO - 2018-02-16 13:26:14 --> Controller Class Initialized
INFO - 2018-02-16 13:26:14 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-16 13:26:14 --> Model Class Initialized
INFO - 2018-02-16 13:26:14 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-16 13:26:14 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-16 13:26:14 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-16 13:26:14 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-16 13:26:14 --> File loaded: /var/www/html/project/radio/application/views/user/index.php
INFO - 2018-02-16 13:26:14 --> Final output sent to browser
DEBUG - 2018-02-16 13:26:14 --> Total execution time: 0.0053
INFO - 2018-02-16 13:26:15 --> Config Class Initialized
INFO - 2018-02-16 13:26:15 --> Hooks Class Initialized
DEBUG - 2018-02-16 13:26:15 --> UTF-8 Support Enabled
INFO - 2018-02-16 13:26:15 --> Utf8 Class Initialized
INFO - 2018-02-16 13:26:15 --> URI Class Initialized
INFO - 2018-02-16 13:26:15 --> Router Class Initialized
INFO - 2018-02-16 13:26:15 --> Output Class Initialized
INFO - 2018-02-16 13:26:15 --> Security Class Initialized
DEBUG - 2018-02-16 13:26:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-16 13:26:15 --> Input Class Initialized
INFO - 2018-02-16 13:26:15 --> Language Class Initialized
INFO - 2018-02-16 13:26:15 --> Loader Class Initialized
INFO - 2018-02-16 13:26:15 --> Helper loaded: url_helper
INFO - 2018-02-16 13:26:15 --> Helper loaded: file_helper
INFO - 2018-02-16 13:26:15 --> Helper loaded: email_helper
INFO - 2018-02-16 13:26:15 --> Helper loaded: common_helper
INFO - 2018-02-16 13:26:15 --> Database Driver Class Initialized
DEBUG - 2018-02-16 13:26:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-16 13:26:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-16 13:26:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-16 13:26:15 --> Pagination Class Initialized
INFO - 2018-02-16 13:26:15 --> Helper loaded: form_helper
INFO - 2018-02-16 13:26:15 --> Form Validation Class Initialized
INFO - 2018-02-16 13:26:15 --> Model Class Initialized
INFO - 2018-02-16 13:26:15 --> Controller Class Initialized
INFO - 2018-02-16 13:26:15 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-16 13:26:15 --> Model Class Initialized
INFO - 2018-02-16 13:27:06 --> Config Class Initialized
INFO - 2018-02-16 13:27:06 --> Hooks Class Initialized
DEBUG - 2018-02-16 13:27:06 --> UTF-8 Support Enabled
INFO - 2018-02-16 13:27:06 --> Utf8 Class Initialized
INFO - 2018-02-16 13:27:06 --> URI Class Initialized
INFO - 2018-02-16 13:27:06 --> Router Class Initialized
INFO - 2018-02-16 13:27:06 --> Output Class Initialized
INFO - 2018-02-16 13:27:06 --> Security Class Initialized
DEBUG - 2018-02-16 13:27:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-16 13:27:06 --> Input Class Initialized
INFO - 2018-02-16 13:27:06 --> Language Class Initialized
INFO - 2018-02-16 13:27:06 --> Loader Class Initialized
INFO - 2018-02-16 13:27:06 --> Helper loaded: url_helper
INFO - 2018-02-16 13:27:06 --> Helper loaded: file_helper
INFO - 2018-02-16 13:27:06 --> Helper loaded: email_helper
INFO - 2018-02-16 13:27:06 --> Helper loaded: common_helper
INFO - 2018-02-16 13:27:06 --> Database Driver Class Initialized
DEBUG - 2018-02-16 13:27:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-16 13:27:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-16 13:27:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-16 13:27:06 --> Pagination Class Initialized
INFO - 2018-02-16 13:27:06 --> Helper loaded: form_helper
INFO - 2018-02-16 13:27:06 --> Form Validation Class Initialized
INFO - 2018-02-16 13:27:06 --> Model Class Initialized
INFO - 2018-02-16 13:27:06 --> Controller Class Initialized
INFO - 2018-02-16 13:27:06 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-16 13:27:06 --> Model Class Initialized
INFO - 2018-02-16 13:27:06 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-16 13:27:06 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-16 13:27:06 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-16 13:27:06 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-16 13:27:06 --> File loaded: /var/www/html/project/radio/application/views/user/index.php
INFO - 2018-02-16 13:27:06 --> Final output sent to browser
DEBUG - 2018-02-16 13:27:06 --> Total execution time: 0.0057
INFO - 2018-02-16 13:27:07 --> Config Class Initialized
INFO - 2018-02-16 13:27:07 --> Hooks Class Initialized
DEBUG - 2018-02-16 13:27:07 --> UTF-8 Support Enabled
INFO - 2018-02-16 13:27:07 --> Utf8 Class Initialized
INFO - 2018-02-16 13:27:07 --> URI Class Initialized
INFO - 2018-02-16 13:27:07 --> Router Class Initialized
INFO - 2018-02-16 13:27:07 --> Output Class Initialized
INFO - 2018-02-16 13:27:07 --> Security Class Initialized
DEBUG - 2018-02-16 13:27:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-16 13:27:07 --> Input Class Initialized
INFO - 2018-02-16 13:27:07 --> Language Class Initialized
INFO - 2018-02-16 13:27:07 --> Loader Class Initialized
INFO - 2018-02-16 13:27:07 --> Helper loaded: url_helper
INFO - 2018-02-16 13:27:07 --> Helper loaded: file_helper
INFO - 2018-02-16 13:27:07 --> Helper loaded: email_helper
INFO - 2018-02-16 13:27:07 --> Helper loaded: common_helper
INFO - 2018-02-16 13:27:07 --> Database Driver Class Initialized
DEBUG - 2018-02-16 13:27:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-16 13:27:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-16 13:27:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-16 13:27:07 --> Pagination Class Initialized
INFO - 2018-02-16 13:27:07 --> Helper loaded: form_helper
INFO - 2018-02-16 13:27:07 --> Form Validation Class Initialized
INFO - 2018-02-16 13:27:07 --> Model Class Initialized
INFO - 2018-02-16 13:27:07 --> Controller Class Initialized
INFO - 2018-02-16 13:27:07 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-16 13:27:07 --> Model Class Initialized
INFO - 2018-02-16 13:27:10 --> Config Class Initialized
INFO - 2018-02-16 13:27:10 --> Hooks Class Initialized
DEBUG - 2018-02-16 13:27:10 --> UTF-8 Support Enabled
INFO - 2018-02-16 13:27:10 --> Utf8 Class Initialized
INFO - 2018-02-16 13:27:10 --> URI Class Initialized
INFO - 2018-02-16 13:27:10 --> Router Class Initialized
INFO - 2018-02-16 13:27:10 --> Output Class Initialized
INFO - 2018-02-16 13:27:10 --> Security Class Initialized
DEBUG - 2018-02-16 13:27:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-16 13:27:10 --> Input Class Initialized
INFO - 2018-02-16 13:27:10 --> Language Class Initialized
INFO - 2018-02-16 13:27:10 --> Loader Class Initialized
INFO - 2018-02-16 13:27:10 --> Helper loaded: url_helper
INFO - 2018-02-16 13:27:10 --> Helper loaded: file_helper
INFO - 2018-02-16 13:27:10 --> Helper loaded: email_helper
INFO - 2018-02-16 13:27:10 --> Helper loaded: common_helper
INFO - 2018-02-16 13:27:10 --> Database Driver Class Initialized
DEBUG - 2018-02-16 13:27:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-16 13:27:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-16 13:27:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-16 13:27:10 --> Pagination Class Initialized
INFO - 2018-02-16 13:27:10 --> Helper loaded: form_helper
INFO - 2018-02-16 13:27:10 --> Form Validation Class Initialized
INFO - 2018-02-16 13:27:10 --> Model Class Initialized
INFO - 2018-02-16 13:27:10 --> Controller Class Initialized
INFO - 2018-02-16 13:27:10 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-16 13:27:10 --> Model Class Initialized
INFO - 2018-02-16 13:27:10 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-16 13:27:10 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-16 13:27:10 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-16 13:27:10 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-16 13:27:10 --> File loaded: /var/www/html/project/radio/application/views/staticpages/index.php
INFO - 2018-02-16 13:27:10 --> Final output sent to browser
DEBUG - 2018-02-16 13:27:10 --> Total execution time: 0.0079
INFO - 2018-02-16 14:29:17 --> Config Class Initialized
INFO - 2018-02-16 14:29:17 --> Hooks Class Initialized
DEBUG - 2018-02-16 14:29:17 --> UTF-8 Support Enabled
INFO - 2018-02-16 14:29:17 --> Utf8 Class Initialized
INFO - 2018-02-16 14:29:17 --> URI Class Initialized
INFO - 2018-02-16 14:29:17 --> Router Class Initialized
INFO - 2018-02-16 14:29:17 --> Output Class Initialized
INFO - 2018-02-16 14:29:17 --> Security Class Initialized
DEBUG - 2018-02-16 14:29:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-16 14:29:17 --> Input Class Initialized
INFO - 2018-02-16 14:29:17 --> Language Class Initialized
INFO - 2018-02-16 14:29:17 --> Loader Class Initialized
INFO - 2018-02-16 14:29:17 --> Helper loaded: url_helper
INFO - 2018-02-16 14:29:17 --> Helper loaded: file_helper
INFO - 2018-02-16 14:29:17 --> Helper loaded: email_helper
INFO - 2018-02-16 14:29:17 --> Helper loaded: common_helper
INFO - 2018-02-16 14:29:17 --> Database Driver Class Initialized
DEBUG - 2018-02-16 14:29:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-16 14:29:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-16 14:29:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-16 14:29:17 --> Pagination Class Initialized
INFO - 2018-02-16 14:29:17 --> Helper loaded: form_helper
INFO - 2018-02-16 14:29:17 --> Form Validation Class Initialized
INFO - 2018-02-16 14:29:17 --> Model Class Initialized
INFO - 2018-02-16 14:29:17 --> Controller Class Initialized
INFO - 2018-02-16 14:29:17 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-16 14:29:17 --> Model Class Initialized
INFO - 2018-02-16 14:29:17 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-16 14:29:17 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-16 14:29:17 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-16 14:29:17 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-16 14:29:17 --> File loaded: /var/www/html/project/radio/application/views/staticpages/add_edit.php
INFO - 2018-02-16 14:29:17 --> Final output sent to browser
DEBUG - 2018-02-16 14:29:17 --> Total execution time: 0.0059
INFO - 2018-02-16 14:30:09 --> Config Class Initialized
INFO - 2018-02-16 14:30:09 --> Hooks Class Initialized
DEBUG - 2018-02-16 14:30:09 --> UTF-8 Support Enabled
INFO - 2018-02-16 14:30:09 --> Utf8 Class Initialized
INFO - 2018-02-16 14:30:09 --> URI Class Initialized
INFO - 2018-02-16 14:30:09 --> Router Class Initialized
INFO - 2018-02-16 14:30:09 --> Output Class Initialized
INFO - 2018-02-16 14:30:09 --> Security Class Initialized
DEBUG - 2018-02-16 14:30:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-16 14:30:09 --> Input Class Initialized
INFO - 2018-02-16 14:30:09 --> Language Class Initialized
INFO - 2018-02-16 14:30:09 --> Loader Class Initialized
INFO - 2018-02-16 14:30:09 --> Helper loaded: url_helper
INFO - 2018-02-16 14:30:09 --> Helper loaded: file_helper
INFO - 2018-02-16 14:30:09 --> Helper loaded: email_helper
INFO - 2018-02-16 14:30:09 --> Helper loaded: common_helper
INFO - 2018-02-16 14:30:09 --> Database Driver Class Initialized
DEBUG - 2018-02-16 14:30:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-16 14:30:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-16 14:30:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-16 14:30:09 --> Pagination Class Initialized
INFO - 2018-02-16 14:30:09 --> Helper loaded: form_helper
INFO - 2018-02-16 14:30:09 --> Form Validation Class Initialized
INFO - 2018-02-16 14:30:09 --> Model Class Initialized
INFO - 2018-02-16 14:30:09 --> Controller Class Initialized
INFO - 2018-02-16 14:30:09 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-16 14:30:09 --> Model Class Initialized
INFO - 2018-02-16 14:30:09 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-16 14:30:09 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-16 14:30:09 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-16 14:30:09 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-16 14:30:09 --> File loaded: /var/www/html/project/radio/application/views/staticpages/add_edit.php
INFO - 2018-02-16 14:30:09 --> Final output sent to browser
DEBUG - 2018-02-16 14:30:09 --> Total execution time: 0.0065
INFO - 2018-02-16 14:44:46 --> Config Class Initialized
INFO - 2018-02-16 14:44:46 --> Hooks Class Initialized
DEBUG - 2018-02-16 14:44:46 --> UTF-8 Support Enabled
INFO - 2018-02-16 14:44:46 --> Utf8 Class Initialized
INFO - 2018-02-16 14:44:46 --> URI Class Initialized
INFO - 2018-02-16 14:44:46 --> Router Class Initialized
INFO - 2018-02-16 14:44:46 --> Output Class Initialized
INFO - 2018-02-16 14:44:46 --> Security Class Initialized
DEBUG - 2018-02-16 14:44:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-16 14:44:46 --> Input Class Initialized
INFO - 2018-02-16 14:44:46 --> Language Class Initialized
INFO - 2018-02-16 14:44:46 --> Loader Class Initialized
INFO - 2018-02-16 14:44:46 --> Helper loaded: url_helper
INFO - 2018-02-16 14:44:46 --> Helper loaded: file_helper
INFO - 2018-02-16 14:44:46 --> Helper loaded: email_helper
INFO - 2018-02-16 14:44:46 --> Helper loaded: common_helper
INFO - 2018-02-16 14:44:46 --> Database Driver Class Initialized
DEBUG - 2018-02-16 14:44:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-16 14:44:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-16 14:44:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-16 14:44:46 --> Pagination Class Initialized
INFO - 2018-02-16 14:44:46 --> Helper loaded: form_helper
INFO - 2018-02-16 14:44:46 --> Form Validation Class Initialized
INFO - 2018-02-16 14:44:46 --> Model Class Initialized
INFO - 2018-02-16 14:44:46 --> Controller Class Initialized
INFO - 2018-02-16 14:44:46 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-16 14:44:46 --> Model Class Initialized
INFO - 2018-02-16 14:44:46 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-16 14:44:46 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-16 14:44:46 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-16 14:44:46 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-16 14:44:46 --> File loaded: /var/www/html/project/radio/application/views/staticpages/add_edit.php
INFO - 2018-02-16 14:44:46 --> Final output sent to browser
DEBUG - 2018-02-16 14:44:46 --> Total execution time: 0.0096
INFO - 2018-02-16 14:44:54 --> Config Class Initialized
INFO - 2018-02-16 14:44:54 --> Hooks Class Initialized
DEBUG - 2018-02-16 14:44:54 --> UTF-8 Support Enabled
INFO - 2018-02-16 14:44:54 --> Utf8 Class Initialized
INFO - 2018-02-16 14:44:54 --> URI Class Initialized
INFO - 2018-02-16 14:44:54 --> Router Class Initialized
INFO - 2018-02-16 14:44:54 --> Output Class Initialized
INFO - 2018-02-16 14:44:54 --> Security Class Initialized
DEBUG - 2018-02-16 14:44:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-16 14:44:54 --> Input Class Initialized
INFO - 2018-02-16 14:44:54 --> Language Class Initialized
INFO - 2018-02-16 14:44:54 --> Loader Class Initialized
INFO - 2018-02-16 14:44:54 --> Helper loaded: url_helper
INFO - 2018-02-16 14:44:54 --> Helper loaded: file_helper
INFO - 2018-02-16 14:44:54 --> Helper loaded: email_helper
INFO - 2018-02-16 14:44:54 --> Helper loaded: common_helper
INFO - 2018-02-16 14:44:54 --> Database Driver Class Initialized
DEBUG - 2018-02-16 14:44:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-16 14:44:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-16 14:44:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-16 14:44:54 --> Pagination Class Initialized
INFO - 2018-02-16 14:44:54 --> Helper loaded: form_helper
INFO - 2018-02-16 14:44:54 --> Form Validation Class Initialized
INFO - 2018-02-16 14:44:54 --> Model Class Initialized
INFO - 2018-02-16 14:44:54 --> Controller Class Initialized
INFO - 2018-02-16 14:44:54 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-16 14:44:54 --> Model Class Initialized
INFO - 2018-02-16 14:44:54 --> Config Class Initialized
INFO - 2018-02-16 14:44:54 --> Hooks Class Initialized
DEBUG - 2018-02-16 14:44:54 --> UTF-8 Support Enabled
INFO - 2018-02-16 14:44:54 --> Utf8 Class Initialized
INFO - 2018-02-16 14:44:54 --> URI Class Initialized
INFO - 2018-02-16 14:44:54 --> Router Class Initialized
INFO - 2018-02-16 14:44:54 --> Output Class Initialized
INFO - 2018-02-16 14:44:54 --> Security Class Initialized
DEBUG - 2018-02-16 14:44:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-16 14:44:54 --> Input Class Initialized
INFO - 2018-02-16 14:44:54 --> Language Class Initialized
INFO - 2018-02-16 14:44:54 --> Loader Class Initialized
INFO - 2018-02-16 14:44:54 --> Helper loaded: url_helper
INFO - 2018-02-16 14:44:54 --> Helper loaded: file_helper
INFO - 2018-02-16 14:44:54 --> Helper loaded: email_helper
INFO - 2018-02-16 14:44:54 --> Helper loaded: common_helper
INFO - 2018-02-16 14:44:54 --> Database Driver Class Initialized
DEBUG - 2018-02-16 14:44:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-16 14:44:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-16 14:44:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-16 14:44:54 --> Pagination Class Initialized
INFO - 2018-02-16 14:44:54 --> Helper loaded: form_helper
INFO - 2018-02-16 14:44:54 --> Form Validation Class Initialized
INFO - 2018-02-16 14:44:54 --> Model Class Initialized
INFO - 2018-02-16 14:44:54 --> Controller Class Initialized
INFO - 2018-02-16 14:44:54 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-16 14:44:54 --> Model Class Initialized
INFO - 2018-02-16 15:04:07 --> Config Class Initialized
INFO - 2018-02-16 15:04:07 --> Hooks Class Initialized
DEBUG - 2018-02-16 15:04:07 --> UTF-8 Support Enabled
INFO - 2018-02-16 15:04:07 --> Utf8 Class Initialized
INFO - 2018-02-16 15:04:07 --> URI Class Initialized
INFO - 2018-02-16 15:04:07 --> Router Class Initialized
INFO - 2018-02-16 15:04:07 --> Output Class Initialized
INFO - 2018-02-16 15:04:07 --> Security Class Initialized
DEBUG - 2018-02-16 15:04:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-16 15:04:07 --> Input Class Initialized
INFO - 2018-02-16 15:04:07 --> Language Class Initialized
INFO - 2018-02-16 15:04:07 --> Loader Class Initialized
INFO - 2018-02-16 15:04:07 --> Helper loaded: url_helper
INFO - 2018-02-16 15:04:07 --> Helper loaded: file_helper
INFO - 2018-02-16 15:04:07 --> Helper loaded: email_helper
INFO - 2018-02-16 15:04:07 --> Helper loaded: common_helper
INFO - 2018-02-16 15:04:07 --> Database Driver Class Initialized
DEBUG - 2018-02-16 15:04:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-16 15:04:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-16 15:04:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-16 15:04:07 --> Pagination Class Initialized
INFO - 2018-02-16 15:04:07 --> Helper loaded: form_helper
INFO - 2018-02-16 15:04:07 --> Form Validation Class Initialized
INFO - 2018-02-16 15:04:07 --> Model Class Initialized
INFO - 2018-02-16 15:04:07 --> Controller Class Initialized
INFO - 2018-02-16 15:04:07 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-16 15:04:07 --> Model Class Initialized
INFO - 2018-02-16 15:04:07 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-16 15:04:07 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-16 15:04:07 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-16 15:04:07 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-16 15:04:07 --> File loaded: /var/www/html/project/radio/application/views/staticpages/add_edit.php
INFO - 2018-02-16 15:04:07 --> Final output sent to browser
DEBUG - 2018-02-16 15:04:07 --> Total execution time: 0.0052
INFO - 2018-02-16 15:04:27 --> Config Class Initialized
INFO - 2018-02-16 15:04:27 --> Hooks Class Initialized
DEBUG - 2018-02-16 15:04:27 --> UTF-8 Support Enabled
INFO - 2018-02-16 15:04:27 --> Utf8 Class Initialized
INFO - 2018-02-16 15:04:27 --> URI Class Initialized
INFO - 2018-02-16 15:04:27 --> Router Class Initialized
INFO - 2018-02-16 15:04:27 --> Output Class Initialized
INFO - 2018-02-16 15:04:27 --> Security Class Initialized
DEBUG - 2018-02-16 15:04:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-16 15:04:27 --> Input Class Initialized
INFO - 2018-02-16 15:04:27 --> Language Class Initialized
INFO - 2018-02-16 15:04:27 --> Loader Class Initialized
INFO - 2018-02-16 15:04:27 --> Helper loaded: url_helper
INFO - 2018-02-16 15:04:27 --> Helper loaded: file_helper
INFO - 2018-02-16 15:04:27 --> Helper loaded: email_helper
INFO - 2018-02-16 15:04:27 --> Helper loaded: common_helper
INFO - 2018-02-16 15:04:27 --> Database Driver Class Initialized
DEBUG - 2018-02-16 15:04:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-16 15:04:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-16 15:04:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-16 15:04:27 --> Pagination Class Initialized
INFO - 2018-02-16 15:04:27 --> Helper loaded: form_helper
INFO - 2018-02-16 15:04:27 --> Form Validation Class Initialized
INFO - 2018-02-16 15:04:27 --> Model Class Initialized
INFO - 2018-02-16 15:04:27 --> Controller Class Initialized
INFO - 2018-02-16 15:04:27 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-16 15:04:27 --> Model Class Initialized
INFO - 2018-02-16 15:04:27 --> Config Class Initialized
INFO - 2018-02-16 15:04:27 --> Hooks Class Initialized
DEBUG - 2018-02-16 15:04:27 --> UTF-8 Support Enabled
INFO - 2018-02-16 15:04:27 --> Utf8 Class Initialized
INFO - 2018-02-16 15:04:27 --> URI Class Initialized
INFO - 2018-02-16 15:04:27 --> Router Class Initialized
INFO - 2018-02-16 15:04:27 --> Output Class Initialized
INFO - 2018-02-16 15:04:27 --> Security Class Initialized
DEBUG - 2018-02-16 15:04:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-16 15:04:27 --> Input Class Initialized
INFO - 2018-02-16 15:04:27 --> Language Class Initialized
INFO - 2018-02-16 15:04:27 --> Loader Class Initialized
INFO - 2018-02-16 15:04:27 --> Helper loaded: url_helper
INFO - 2018-02-16 15:04:27 --> Helper loaded: file_helper
INFO - 2018-02-16 15:04:27 --> Helper loaded: email_helper
INFO - 2018-02-16 15:04:27 --> Helper loaded: common_helper
INFO - 2018-02-16 15:04:27 --> Database Driver Class Initialized
DEBUG - 2018-02-16 15:04:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-16 15:04:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-16 15:04:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-16 15:04:27 --> Pagination Class Initialized
INFO - 2018-02-16 15:04:27 --> Helper loaded: form_helper
INFO - 2018-02-16 15:04:27 --> Form Validation Class Initialized
INFO - 2018-02-16 15:04:27 --> Model Class Initialized
INFO - 2018-02-16 15:04:27 --> Controller Class Initialized
INFO - 2018-02-16 15:04:27 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-16 15:04:27 --> Model Class Initialized
DEBUG - 2018-02-16 15:04:27 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-16 15:04:27 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-02-16 15:04:27 --> Config Class Initialized
INFO - 2018-02-16 15:04:27 --> Hooks Class Initialized
DEBUG - 2018-02-16 15:04:27 --> UTF-8 Support Enabled
INFO - 2018-02-16 15:04:27 --> Utf8 Class Initialized
INFO - 2018-02-16 15:04:27 --> URI Class Initialized
INFO - 2018-02-16 15:04:27 --> Router Class Initialized
INFO - 2018-02-16 15:04:27 --> Output Class Initialized
INFO - 2018-02-16 15:04:27 --> Security Class Initialized
DEBUG - 2018-02-16 15:04:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-16 15:04:27 --> Input Class Initialized
INFO - 2018-02-16 15:04:27 --> Language Class Initialized
INFO - 2018-02-16 15:04:27 --> Loader Class Initialized
INFO - 2018-02-16 15:04:27 --> Helper loaded: url_helper
INFO - 2018-02-16 15:04:27 --> Helper loaded: file_helper
INFO - 2018-02-16 15:04:27 --> Helper loaded: email_helper
INFO - 2018-02-16 15:04:27 --> Helper loaded: common_helper
INFO - 2018-02-16 15:04:27 --> Database Driver Class Initialized
DEBUG - 2018-02-16 15:04:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-16 15:04:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-16 15:04:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-16 15:04:27 --> Pagination Class Initialized
INFO - 2018-02-16 15:04:27 --> Helper loaded: form_helper
INFO - 2018-02-16 15:04:27 --> Form Validation Class Initialized
INFO - 2018-02-16 15:04:27 --> Model Class Initialized
INFO - 2018-02-16 15:04:27 --> Controller Class Initialized
INFO - 2018-02-16 15:04:27 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-16 15:04:27 --> Model Class Initialized
INFO - 2018-02-16 15:04:27 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-16 15:04:27 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-16 15:04:27 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-16 15:04:27 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-16 15:04:27 --> File loaded: /var/www/html/project/radio/application/views/staticpages/index.php
INFO - 2018-02-16 15:04:27 --> Final output sent to browser
DEBUG - 2018-02-16 15:04:27 --> Total execution time: 0.0059
INFO - 2018-02-16 15:04:30 --> Config Class Initialized
INFO - 2018-02-16 15:04:30 --> Hooks Class Initialized
DEBUG - 2018-02-16 15:04:30 --> UTF-8 Support Enabled
INFO - 2018-02-16 15:04:30 --> Utf8 Class Initialized
INFO - 2018-02-16 15:04:30 --> URI Class Initialized
INFO - 2018-02-16 15:04:30 --> Router Class Initialized
INFO - 2018-02-16 15:04:30 --> Output Class Initialized
INFO - 2018-02-16 15:04:30 --> Security Class Initialized
DEBUG - 2018-02-16 15:04:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-16 15:04:30 --> Input Class Initialized
INFO - 2018-02-16 15:04:30 --> Language Class Initialized
INFO - 2018-02-16 15:04:30 --> Loader Class Initialized
INFO - 2018-02-16 15:04:30 --> Helper loaded: url_helper
INFO - 2018-02-16 15:04:30 --> Helper loaded: file_helper
INFO - 2018-02-16 15:04:30 --> Helper loaded: email_helper
INFO - 2018-02-16 15:04:30 --> Helper loaded: common_helper
INFO - 2018-02-16 15:04:30 --> Database Driver Class Initialized
DEBUG - 2018-02-16 15:04:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-16 15:04:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-16 15:04:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-16 15:04:30 --> Pagination Class Initialized
INFO - 2018-02-16 15:04:30 --> Helper loaded: form_helper
INFO - 2018-02-16 15:04:30 --> Form Validation Class Initialized
INFO - 2018-02-16 15:04:30 --> Model Class Initialized
INFO - 2018-02-16 15:04:30 --> Controller Class Initialized
INFO - 2018-02-16 15:04:30 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-16 15:04:30 --> Model Class Initialized
INFO - 2018-02-16 15:04:30 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-16 15:04:30 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-16 15:04:30 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-16 15:04:30 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-16 15:04:30 --> File loaded: /var/www/html/project/radio/application/views/staticpages/add_edit.php
INFO - 2018-02-16 15:04:30 --> Final output sent to browser
DEBUG - 2018-02-16 15:04:30 --> Total execution time: 0.0055
INFO - 2018-02-16 15:05:07 --> Config Class Initialized
INFO - 2018-02-16 15:05:07 --> Hooks Class Initialized
DEBUG - 2018-02-16 15:05:07 --> UTF-8 Support Enabled
INFO - 2018-02-16 15:05:07 --> Utf8 Class Initialized
INFO - 2018-02-16 15:05:07 --> URI Class Initialized
INFO - 2018-02-16 15:05:07 --> Router Class Initialized
INFO - 2018-02-16 15:05:07 --> Output Class Initialized
INFO - 2018-02-16 15:05:07 --> Security Class Initialized
DEBUG - 2018-02-16 15:05:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-16 15:05:07 --> Input Class Initialized
INFO - 2018-02-16 15:05:07 --> Language Class Initialized
INFO - 2018-02-16 15:05:07 --> Loader Class Initialized
INFO - 2018-02-16 15:05:07 --> Helper loaded: url_helper
INFO - 2018-02-16 15:05:07 --> Helper loaded: file_helper
INFO - 2018-02-16 15:05:07 --> Helper loaded: email_helper
INFO - 2018-02-16 15:05:07 --> Helper loaded: common_helper
INFO - 2018-02-16 15:05:07 --> Database Driver Class Initialized
DEBUG - 2018-02-16 15:05:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-16 15:05:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-16 15:05:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-16 15:05:07 --> Pagination Class Initialized
INFO - 2018-02-16 15:05:07 --> Helper loaded: form_helper
INFO - 2018-02-16 15:05:07 --> Form Validation Class Initialized
INFO - 2018-02-16 15:05:07 --> Model Class Initialized
INFO - 2018-02-16 15:05:07 --> Controller Class Initialized
INFO - 2018-02-16 15:05:07 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-16 15:05:07 --> Model Class Initialized
INFO - 2018-02-16 15:05:10 --> Config Class Initialized
INFO - 2018-02-16 15:05:10 --> Hooks Class Initialized
DEBUG - 2018-02-16 15:05:10 --> UTF-8 Support Enabled
INFO - 2018-02-16 15:05:10 --> Utf8 Class Initialized
INFO - 2018-02-16 15:05:10 --> URI Class Initialized
INFO - 2018-02-16 15:05:10 --> Router Class Initialized
INFO - 2018-02-16 15:05:10 --> Output Class Initialized
INFO - 2018-02-16 15:05:10 --> Security Class Initialized
DEBUG - 2018-02-16 15:05:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-16 15:05:10 --> Input Class Initialized
INFO - 2018-02-16 15:05:10 --> Language Class Initialized
INFO - 2018-02-16 15:05:10 --> Loader Class Initialized
INFO - 2018-02-16 15:05:10 --> Helper loaded: url_helper
INFO - 2018-02-16 15:05:10 --> Helper loaded: file_helper
INFO - 2018-02-16 15:05:10 --> Helper loaded: email_helper
INFO - 2018-02-16 15:05:10 --> Helper loaded: common_helper
INFO - 2018-02-16 15:05:10 --> Database Driver Class Initialized
DEBUG - 2018-02-16 15:05:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-16 15:05:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-16 15:05:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-16 15:05:10 --> Pagination Class Initialized
INFO - 2018-02-16 15:05:10 --> Helper loaded: form_helper
INFO - 2018-02-16 15:05:10 --> Form Validation Class Initialized
INFO - 2018-02-16 15:05:10 --> Model Class Initialized
INFO - 2018-02-16 15:05:10 --> Controller Class Initialized
INFO - 2018-02-16 15:05:10 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-16 15:05:10 --> Model Class Initialized
INFO - 2018-02-16 15:05:10 --> Config Class Initialized
INFO - 2018-02-16 15:05:10 --> Hooks Class Initialized
DEBUG - 2018-02-16 15:05:10 --> UTF-8 Support Enabled
INFO - 2018-02-16 15:05:10 --> Utf8 Class Initialized
INFO - 2018-02-16 15:05:10 --> URI Class Initialized
INFO - 2018-02-16 15:05:10 --> Router Class Initialized
INFO - 2018-02-16 15:05:10 --> Output Class Initialized
INFO - 2018-02-16 15:05:10 --> Security Class Initialized
DEBUG - 2018-02-16 15:05:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-16 15:05:10 --> Input Class Initialized
INFO - 2018-02-16 15:05:10 --> Language Class Initialized
INFO - 2018-02-16 15:05:10 --> Loader Class Initialized
INFO - 2018-02-16 15:05:10 --> Helper loaded: url_helper
INFO - 2018-02-16 15:05:10 --> Helper loaded: file_helper
INFO - 2018-02-16 15:05:10 --> Helper loaded: email_helper
INFO - 2018-02-16 15:05:10 --> Helper loaded: common_helper
INFO - 2018-02-16 15:05:10 --> Database Driver Class Initialized
DEBUG - 2018-02-16 15:05:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-16 15:05:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-16 15:05:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-16 15:05:10 --> Pagination Class Initialized
INFO - 2018-02-16 15:05:10 --> Helper loaded: form_helper
INFO - 2018-02-16 15:05:10 --> Form Validation Class Initialized
INFO - 2018-02-16 15:05:10 --> Model Class Initialized
INFO - 2018-02-16 15:05:10 --> Controller Class Initialized
INFO - 2018-02-16 15:05:10 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-16 15:05:10 --> Model Class Initialized
DEBUG - 2018-02-16 15:05:10 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-16 15:05:10 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-02-16 15:05:10 --> Config Class Initialized
INFO - 2018-02-16 15:05:10 --> Hooks Class Initialized
DEBUG - 2018-02-16 15:05:10 --> UTF-8 Support Enabled
INFO - 2018-02-16 15:05:10 --> Utf8 Class Initialized
INFO - 2018-02-16 15:05:10 --> URI Class Initialized
INFO - 2018-02-16 15:05:10 --> Router Class Initialized
INFO - 2018-02-16 15:05:10 --> Output Class Initialized
INFO - 2018-02-16 15:05:10 --> Security Class Initialized
DEBUG - 2018-02-16 15:05:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-16 15:05:10 --> Input Class Initialized
INFO - 2018-02-16 15:05:10 --> Language Class Initialized
INFO - 2018-02-16 15:05:10 --> Loader Class Initialized
INFO - 2018-02-16 15:05:10 --> Helper loaded: url_helper
INFO - 2018-02-16 15:05:10 --> Helper loaded: file_helper
INFO - 2018-02-16 15:05:10 --> Helper loaded: email_helper
INFO - 2018-02-16 15:05:10 --> Helper loaded: common_helper
INFO - 2018-02-16 15:05:10 --> Database Driver Class Initialized
DEBUG - 2018-02-16 15:05:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-16 15:05:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-16 15:05:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-16 15:05:10 --> Pagination Class Initialized
INFO - 2018-02-16 15:05:10 --> Helper loaded: form_helper
INFO - 2018-02-16 15:05:10 --> Form Validation Class Initialized
INFO - 2018-02-16 15:05:10 --> Model Class Initialized
INFO - 2018-02-16 15:05:10 --> Controller Class Initialized
INFO - 2018-02-16 15:05:10 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-16 15:05:10 --> Model Class Initialized
INFO - 2018-02-16 15:05:10 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-16 15:05:10 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-16 15:05:10 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-16 15:05:10 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-16 15:05:10 --> File loaded: /var/www/html/project/radio/application/views/staticpages/index.php
INFO - 2018-02-16 15:05:10 --> Final output sent to browser
DEBUG - 2018-02-16 15:05:10 --> Total execution time: 0.0045
INFO - 2018-02-16 15:05:19 --> Config Class Initialized
INFO - 2018-02-16 15:05:19 --> Hooks Class Initialized
DEBUG - 2018-02-16 15:05:19 --> UTF-8 Support Enabled
INFO - 2018-02-16 15:05:19 --> Utf8 Class Initialized
INFO - 2018-02-16 15:05:19 --> URI Class Initialized
INFO - 2018-02-16 15:05:19 --> Router Class Initialized
INFO - 2018-02-16 15:05:19 --> Output Class Initialized
INFO - 2018-02-16 15:05:19 --> Security Class Initialized
DEBUG - 2018-02-16 15:05:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-16 15:05:19 --> Input Class Initialized
INFO - 2018-02-16 15:05:19 --> Language Class Initialized
INFO - 2018-02-16 15:05:19 --> Loader Class Initialized
INFO - 2018-02-16 15:05:19 --> Helper loaded: url_helper
INFO - 2018-02-16 15:05:19 --> Helper loaded: file_helper
INFO - 2018-02-16 15:05:19 --> Helper loaded: email_helper
INFO - 2018-02-16 15:05:19 --> Helper loaded: common_helper
INFO - 2018-02-16 15:05:19 --> Database Driver Class Initialized
DEBUG - 2018-02-16 15:05:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-16 15:05:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-16 15:05:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-16 15:05:19 --> Pagination Class Initialized
INFO - 2018-02-16 15:05:19 --> Helper loaded: form_helper
INFO - 2018-02-16 15:05:19 --> Form Validation Class Initialized
INFO - 2018-02-16 15:05:19 --> Model Class Initialized
INFO - 2018-02-16 15:05:19 --> Controller Class Initialized
INFO - 2018-02-16 15:05:19 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-16 15:05:19 --> Model Class Initialized
INFO - 2018-02-16 15:05:19 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-16 15:05:19 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-16 15:05:19 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-16 15:05:19 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-16 15:05:19 --> File loaded: /var/www/html/project/radio/application/views/staticpages/add_edit.php
INFO - 2018-02-16 15:05:19 --> Final output sent to browser
DEBUG - 2018-02-16 15:05:19 --> Total execution time: 0.0058
INFO - 2018-02-16 15:05:33 --> Config Class Initialized
INFO - 2018-02-16 15:05:33 --> Hooks Class Initialized
DEBUG - 2018-02-16 15:05:33 --> UTF-8 Support Enabled
INFO - 2018-02-16 15:05:33 --> Utf8 Class Initialized
INFO - 2018-02-16 15:05:33 --> URI Class Initialized
INFO - 2018-02-16 15:05:33 --> Router Class Initialized
INFO - 2018-02-16 15:05:33 --> Output Class Initialized
INFO - 2018-02-16 15:05:33 --> Security Class Initialized
DEBUG - 2018-02-16 15:05:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-16 15:05:33 --> Input Class Initialized
INFO - 2018-02-16 15:05:33 --> Language Class Initialized
INFO - 2018-02-16 15:05:33 --> Loader Class Initialized
INFO - 2018-02-16 15:05:33 --> Helper loaded: url_helper
INFO - 2018-02-16 15:05:33 --> Helper loaded: file_helper
INFO - 2018-02-16 15:05:33 --> Helper loaded: email_helper
INFO - 2018-02-16 15:05:33 --> Helper loaded: common_helper
INFO - 2018-02-16 15:05:33 --> Database Driver Class Initialized
DEBUG - 2018-02-16 15:05:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-16 15:05:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-16 15:05:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-16 15:05:33 --> Pagination Class Initialized
INFO - 2018-02-16 15:05:33 --> Helper loaded: form_helper
INFO - 2018-02-16 15:05:33 --> Form Validation Class Initialized
INFO - 2018-02-16 15:05:33 --> Model Class Initialized
INFO - 2018-02-16 15:05:33 --> Controller Class Initialized
INFO - 2018-02-16 15:05:33 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-16 15:05:33 --> Model Class Initialized
INFO - 2018-02-16 15:05:33 --> Config Class Initialized
INFO - 2018-02-16 15:05:33 --> Hooks Class Initialized
DEBUG - 2018-02-16 15:05:33 --> UTF-8 Support Enabled
INFO - 2018-02-16 15:05:33 --> Utf8 Class Initialized
INFO - 2018-02-16 15:05:33 --> URI Class Initialized
INFO - 2018-02-16 15:05:33 --> Router Class Initialized
INFO - 2018-02-16 15:05:33 --> Output Class Initialized
INFO - 2018-02-16 15:05:33 --> Security Class Initialized
DEBUG - 2018-02-16 15:05:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-16 15:05:33 --> Input Class Initialized
INFO - 2018-02-16 15:05:33 --> Language Class Initialized
INFO - 2018-02-16 15:05:33 --> Loader Class Initialized
INFO - 2018-02-16 15:05:33 --> Helper loaded: url_helper
INFO - 2018-02-16 15:05:33 --> Helper loaded: file_helper
INFO - 2018-02-16 15:05:33 --> Helper loaded: email_helper
INFO - 2018-02-16 15:05:33 --> Helper loaded: common_helper
INFO - 2018-02-16 15:05:33 --> Database Driver Class Initialized
DEBUG - 2018-02-16 15:05:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-16 15:05:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-16 15:05:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-16 15:05:33 --> Pagination Class Initialized
INFO - 2018-02-16 15:05:33 --> Helper loaded: form_helper
INFO - 2018-02-16 15:05:33 --> Form Validation Class Initialized
INFO - 2018-02-16 15:05:33 --> Model Class Initialized
INFO - 2018-02-16 15:05:33 --> Controller Class Initialized
INFO - 2018-02-16 15:05:33 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-16 15:05:33 --> Model Class Initialized
DEBUG - 2018-02-16 15:05:33 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-16 15:05:33 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-02-16 15:05:33 --> Config Class Initialized
INFO - 2018-02-16 15:05:33 --> Hooks Class Initialized
DEBUG - 2018-02-16 15:05:33 --> UTF-8 Support Enabled
INFO - 2018-02-16 15:05:33 --> Utf8 Class Initialized
INFO - 2018-02-16 15:05:33 --> URI Class Initialized
INFO - 2018-02-16 15:05:33 --> Router Class Initialized
INFO - 2018-02-16 15:05:33 --> Output Class Initialized
INFO - 2018-02-16 15:05:33 --> Security Class Initialized
DEBUG - 2018-02-16 15:05:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-16 15:05:33 --> Input Class Initialized
INFO - 2018-02-16 15:05:33 --> Language Class Initialized
INFO - 2018-02-16 15:05:33 --> Loader Class Initialized
INFO - 2018-02-16 15:05:33 --> Helper loaded: url_helper
INFO - 2018-02-16 15:05:33 --> Helper loaded: file_helper
INFO - 2018-02-16 15:05:33 --> Helper loaded: email_helper
INFO - 2018-02-16 15:05:33 --> Helper loaded: common_helper
INFO - 2018-02-16 15:05:33 --> Database Driver Class Initialized
DEBUG - 2018-02-16 15:05:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-16 15:05:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-16 15:05:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-16 15:05:33 --> Pagination Class Initialized
INFO - 2018-02-16 15:05:33 --> Helper loaded: form_helper
INFO - 2018-02-16 15:05:33 --> Form Validation Class Initialized
INFO - 2018-02-16 15:05:33 --> Model Class Initialized
INFO - 2018-02-16 15:05:33 --> Controller Class Initialized
INFO - 2018-02-16 15:05:33 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-16 15:05:33 --> Model Class Initialized
INFO - 2018-02-16 15:05:33 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-16 15:05:33 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-16 15:05:33 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-16 15:05:33 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-16 15:05:33 --> File loaded: /var/www/html/project/radio/application/views/staticpages/index.php
INFO - 2018-02-16 15:05:33 --> Final output sent to browser
DEBUG - 2018-02-16 15:05:33 --> Total execution time: 0.0065
INFO - 2018-02-16 15:05:44 --> Config Class Initialized
INFO - 2018-02-16 15:05:44 --> Hooks Class Initialized
DEBUG - 2018-02-16 15:05:44 --> UTF-8 Support Enabled
INFO - 2018-02-16 15:05:44 --> Utf8 Class Initialized
INFO - 2018-02-16 15:05:44 --> URI Class Initialized
INFO - 2018-02-16 15:05:44 --> Router Class Initialized
INFO - 2018-02-16 15:05:44 --> Output Class Initialized
INFO - 2018-02-16 15:05:44 --> Security Class Initialized
DEBUG - 2018-02-16 15:05:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-16 15:05:44 --> Input Class Initialized
INFO - 2018-02-16 15:05:44 --> Language Class Initialized
INFO - 2018-02-16 15:05:44 --> Loader Class Initialized
INFO - 2018-02-16 15:05:44 --> Helper loaded: url_helper
INFO - 2018-02-16 15:05:44 --> Helper loaded: file_helper
INFO - 2018-02-16 15:05:44 --> Helper loaded: email_helper
INFO - 2018-02-16 15:05:44 --> Helper loaded: common_helper
INFO - 2018-02-16 15:05:44 --> Database Driver Class Initialized
DEBUG - 2018-02-16 15:05:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-16 15:05:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-16 15:05:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-16 15:05:44 --> Pagination Class Initialized
INFO - 2018-02-16 15:05:44 --> Helper loaded: form_helper
INFO - 2018-02-16 15:05:44 --> Form Validation Class Initialized
INFO - 2018-02-16 15:05:44 --> Model Class Initialized
INFO - 2018-02-16 15:05:44 --> Controller Class Initialized
INFO - 2018-02-16 15:05:44 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-16 15:05:44 --> Model Class Initialized
ERROR - 2018-02-16 15:05:44 --> Severity: Notice --> Undefined property: Staticpages::$Category_model /var/www/html/project/radio/application/controllers/Staticpages.php 86
ERROR - 2018-02-16 15:05:44 --> Severity: error --> Exception: Call to a member function fetchData() on null /var/www/html/project/radio/application/controllers/Staticpages.php 86
INFO - 2018-02-16 15:05:45 --> Config Class Initialized
INFO - 2018-02-16 15:05:45 --> Hooks Class Initialized
DEBUG - 2018-02-16 15:05:45 --> UTF-8 Support Enabled
INFO - 2018-02-16 15:05:45 --> Utf8 Class Initialized
INFO - 2018-02-16 15:05:45 --> URI Class Initialized
INFO - 2018-02-16 15:05:45 --> Router Class Initialized
INFO - 2018-02-16 15:05:45 --> Output Class Initialized
INFO - 2018-02-16 15:05:45 --> Security Class Initialized
DEBUG - 2018-02-16 15:05:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-16 15:05:45 --> Input Class Initialized
INFO - 2018-02-16 15:05:45 --> Language Class Initialized
INFO - 2018-02-16 15:05:45 --> Loader Class Initialized
INFO - 2018-02-16 15:05:45 --> Helper loaded: url_helper
INFO - 2018-02-16 15:05:45 --> Helper loaded: file_helper
INFO - 2018-02-16 15:05:45 --> Helper loaded: email_helper
INFO - 2018-02-16 15:05:45 --> Helper loaded: common_helper
INFO - 2018-02-16 15:05:45 --> Database Driver Class Initialized
DEBUG - 2018-02-16 15:05:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-16 15:05:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-16 15:05:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-16 15:05:45 --> Pagination Class Initialized
INFO - 2018-02-16 15:05:45 --> Helper loaded: form_helper
INFO - 2018-02-16 15:05:45 --> Form Validation Class Initialized
INFO - 2018-02-16 15:05:45 --> Model Class Initialized
INFO - 2018-02-16 15:05:45 --> Controller Class Initialized
INFO - 2018-02-16 15:05:45 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-16 15:05:45 --> Model Class Initialized
INFO - 2018-02-16 15:05:45 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-16 15:05:45 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-16 15:05:45 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-16 15:05:45 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-16 15:05:45 --> File loaded: /var/www/html/project/radio/application/views/staticpages/index.php
INFO - 2018-02-16 15:05:45 --> Final output sent to browser
DEBUG - 2018-02-16 15:05:45 --> Total execution time: 0.0045
INFO - 2018-02-16 15:17:36 --> Config Class Initialized
INFO - 2018-02-16 15:17:36 --> Hooks Class Initialized
DEBUG - 2018-02-16 15:17:36 --> UTF-8 Support Enabled
INFO - 2018-02-16 15:17:36 --> Utf8 Class Initialized
INFO - 2018-02-16 15:17:36 --> URI Class Initialized
INFO - 2018-02-16 15:17:36 --> Router Class Initialized
INFO - 2018-02-16 15:17:36 --> Output Class Initialized
INFO - 2018-02-16 15:17:36 --> Security Class Initialized
DEBUG - 2018-02-16 15:17:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-16 15:17:36 --> Input Class Initialized
INFO - 2018-02-16 15:17:36 --> Language Class Initialized
INFO - 2018-02-16 15:17:36 --> Loader Class Initialized
INFO - 2018-02-16 15:17:36 --> Helper loaded: url_helper
INFO - 2018-02-16 15:17:36 --> Helper loaded: file_helper
INFO - 2018-02-16 15:17:36 --> Helper loaded: email_helper
INFO - 2018-02-16 15:17:36 --> Helper loaded: common_helper
INFO - 2018-02-16 15:17:36 --> Database Driver Class Initialized
DEBUG - 2018-02-16 15:17:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-16 15:17:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-16 15:17:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-16 15:17:36 --> Pagination Class Initialized
INFO - 2018-02-16 15:17:36 --> Helper loaded: form_helper
INFO - 2018-02-16 15:17:36 --> Form Validation Class Initialized
INFO - 2018-02-16 15:17:36 --> Model Class Initialized
INFO - 2018-02-16 15:17:36 --> Controller Class Initialized
INFO - 2018-02-16 15:17:36 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-16 15:17:36 --> Model Class Initialized
INFO - 2018-02-16 15:17:36 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-16 15:17:36 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-16 15:17:36 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-16 15:17:36 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-16 15:17:36 --> File loaded: /var/www/html/project/radio/application/views/staticpages/add_edit.php
INFO - 2018-02-16 15:17:36 --> Final output sent to browser
DEBUG - 2018-02-16 15:17:36 --> Total execution time: 0.0067
INFO - 2018-02-16 15:17:40 --> Config Class Initialized
INFO - 2018-02-16 15:17:40 --> Hooks Class Initialized
DEBUG - 2018-02-16 15:17:40 --> UTF-8 Support Enabled
INFO - 2018-02-16 15:17:40 --> Utf8 Class Initialized
INFO - 2018-02-16 15:17:40 --> URI Class Initialized
INFO - 2018-02-16 15:17:40 --> Router Class Initialized
INFO - 2018-02-16 15:17:40 --> Output Class Initialized
INFO - 2018-02-16 15:17:40 --> Security Class Initialized
DEBUG - 2018-02-16 15:17:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-16 15:17:40 --> Input Class Initialized
INFO - 2018-02-16 15:17:40 --> Language Class Initialized
INFO - 2018-02-16 15:17:40 --> Loader Class Initialized
INFO - 2018-02-16 15:17:40 --> Helper loaded: url_helper
INFO - 2018-02-16 15:17:40 --> Helper loaded: file_helper
INFO - 2018-02-16 15:17:40 --> Helper loaded: email_helper
INFO - 2018-02-16 15:17:40 --> Helper loaded: common_helper
INFO - 2018-02-16 15:17:40 --> Database Driver Class Initialized
DEBUG - 2018-02-16 15:17:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-16 15:17:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-16 15:17:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-16 15:17:40 --> Pagination Class Initialized
INFO - 2018-02-16 15:17:40 --> Helper loaded: form_helper
INFO - 2018-02-16 15:17:40 --> Form Validation Class Initialized
INFO - 2018-02-16 15:17:40 --> Model Class Initialized
INFO - 2018-02-16 15:17:40 --> Controller Class Initialized
INFO - 2018-02-16 15:17:40 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-16 15:17:40 --> Model Class Initialized
INFO - 2018-02-16 15:17:40 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-16 15:17:40 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-16 15:17:40 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-16 15:17:40 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-16 15:17:40 --> File loaded: /var/www/html/project/radio/application/views/staticpages/index.php
INFO - 2018-02-16 15:17:40 --> Final output sent to browser
DEBUG - 2018-02-16 15:17:40 --> Total execution time: 0.0068
INFO - 2018-02-16 15:17:42 --> Config Class Initialized
INFO - 2018-02-16 15:17:42 --> Hooks Class Initialized
DEBUG - 2018-02-16 15:17:42 --> UTF-8 Support Enabled
INFO - 2018-02-16 15:17:42 --> Utf8 Class Initialized
INFO - 2018-02-16 15:17:42 --> URI Class Initialized
INFO - 2018-02-16 15:17:42 --> Router Class Initialized
INFO - 2018-02-16 15:17:42 --> Output Class Initialized
INFO - 2018-02-16 15:17:42 --> Security Class Initialized
DEBUG - 2018-02-16 15:17:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-16 15:17:42 --> Input Class Initialized
INFO - 2018-02-16 15:17:42 --> Language Class Initialized
INFO - 2018-02-16 15:17:42 --> Loader Class Initialized
INFO - 2018-02-16 15:17:42 --> Helper loaded: url_helper
INFO - 2018-02-16 15:17:42 --> Helper loaded: file_helper
INFO - 2018-02-16 15:17:42 --> Helper loaded: email_helper
INFO - 2018-02-16 15:17:42 --> Helper loaded: common_helper
INFO - 2018-02-16 15:17:42 --> Database Driver Class Initialized
DEBUG - 2018-02-16 15:17:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-16 15:17:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-16 15:17:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-16 15:17:42 --> Pagination Class Initialized
INFO - 2018-02-16 15:17:42 --> Helper loaded: form_helper
INFO - 2018-02-16 15:17:42 --> Form Validation Class Initialized
INFO - 2018-02-16 15:17:42 --> Model Class Initialized
INFO - 2018-02-16 15:17:42 --> Controller Class Initialized
INFO - 2018-02-16 15:17:42 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-16 15:17:42 --> Model Class Initialized
INFO - 2018-02-16 15:17:42 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-16 15:17:42 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-16 15:17:42 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-16 15:17:42 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-16 15:17:42 --> File loaded: /var/www/html/project/radio/application/views/staticpages/add_edit.php
INFO - 2018-02-16 15:17:42 --> Final output sent to browser
DEBUG - 2018-02-16 15:17:42 --> Total execution time: 0.0064
INFO - 2018-02-16 15:17:44 --> Config Class Initialized
INFO - 2018-02-16 15:17:44 --> Hooks Class Initialized
DEBUG - 2018-02-16 15:17:44 --> UTF-8 Support Enabled
INFO - 2018-02-16 15:17:44 --> Utf8 Class Initialized
INFO - 2018-02-16 15:17:44 --> URI Class Initialized
INFO - 2018-02-16 15:17:44 --> Router Class Initialized
INFO - 2018-02-16 15:17:44 --> Output Class Initialized
INFO - 2018-02-16 15:17:44 --> Security Class Initialized
DEBUG - 2018-02-16 15:17:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-16 15:17:44 --> Input Class Initialized
INFO - 2018-02-16 15:17:44 --> Language Class Initialized
INFO - 2018-02-16 15:17:44 --> Loader Class Initialized
INFO - 2018-02-16 15:17:44 --> Helper loaded: url_helper
INFO - 2018-02-16 15:17:44 --> Helper loaded: file_helper
INFO - 2018-02-16 15:17:44 --> Helper loaded: email_helper
INFO - 2018-02-16 15:17:44 --> Helper loaded: common_helper
INFO - 2018-02-16 15:17:44 --> Database Driver Class Initialized
DEBUG - 2018-02-16 15:17:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-16 15:17:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-16 15:17:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-16 15:17:44 --> Pagination Class Initialized
INFO - 2018-02-16 15:17:44 --> Helper loaded: form_helper
INFO - 2018-02-16 15:17:44 --> Form Validation Class Initialized
INFO - 2018-02-16 15:17:44 --> Model Class Initialized
INFO - 2018-02-16 15:17:44 --> Controller Class Initialized
INFO - 2018-02-16 15:17:44 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-16 15:17:44 --> Model Class Initialized
INFO - 2018-02-16 15:17:44 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-16 15:17:44 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-16 15:17:44 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-16 15:17:44 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-16 15:17:44 --> File loaded: /var/www/html/project/radio/application/views/staticpages/index.php
INFO - 2018-02-16 15:17:44 --> Final output sent to browser
DEBUG - 2018-02-16 15:17:44 --> Total execution time: 0.0058
INFO - 2018-02-16 15:17:45 --> Config Class Initialized
INFO - 2018-02-16 15:17:45 --> Hooks Class Initialized
DEBUG - 2018-02-16 15:17:45 --> UTF-8 Support Enabled
INFO - 2018-02-16 15:17:45 --> Utf8 Class Initialized
INFO - 2018-02-16 15:17:45 --> URI Class Initialized
INFO - 2018-02-16 15:17:45 --> Router Class Initialized
INFO - 2018-02-16 15:17:45 --> Output Class Initialized
INFO - 2018-02-16 15:17:45 --> Security Class Initialized
DEBUG - 2018-02-16 15:17:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-16 15:17:45 --> Input Class Initialized
INFO - 2018-02-16 15:17:45 --> Language Class Initialized
INFO - 2018-02-16 15:17:45 --> Loader Class Initialized
INFO - 2018-02-16 15:17:45 --> Helper loaded: url_helper
INFO - 2018-02-16 15:17:45 --> Helper loaded: file_helper
INFO - 2018-02-16 15:17:45 --> Helper loaded: email_helper
INFO - 2018-02-16 15:17:45 --> Helper loaded: common_helper
INFO - 2018-02-16 15:17:45 --> Database Driver Class Initialized
DEBUG - 2018-02-16 15:17:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-16 15:17:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-16 15:17:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-16 15:17:45 --> Pagination Class Initialized
INFO - 2018-02-16 15:17:45 --> Helper loaded: form_helper
INFO - 2018-02-16 15:17:45 --> Form Validation Class Initialized
INFO - 2018-02-16 15:17:45 --> Model Class Initialized
INFO - 2018-02-16 15:17:45 --> Controller Class Initialized
INFO - 2018-02-16 15:17:45 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-16 15:17:45 --> Model Class Initialized
INFO - 2018-02-16 15:17:45 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-16 15:17:45 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-16 15:17:45 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-16 15:17:45 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-16 15:17:45 --> File loaded: /var/www/html/project/radio/application/views/staticpages/add_edit.php
INFO - 2018-02-16 15:17:45 --> Final output sent to browser
DEBUG - 2018-02-16 15:17:45 --> Total execution time: 0.0045
INFO - 2018-02-16 15:18:16 --> Config Class Initialized
INFO - 2018-02-16 15:18:16 --> Hooks Class Initialized
DEBUG - 2018-02-16 15:18:16 --> UTF-8 Support Enabled
INFO - 2018-02-16 15:18:16 --> Utf8 Class Initialized
INFO - 2018-02-16 15:18:16 --> URI Class Initialized
INFO - 2018-02-16 15:18:16 --> Router Class Initialized
INFO - 2018-02-16 15:18:16 --> Output Class Initialized
INFO - 2018-02-16 15:18:16 --> Security Class Initialized
DEBUG - 2018-02-16 15:18:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-16 15:18:16 --> Input Class Initialized
INFO - 2018-02-16 15:18:16 --> Language Class Initialized
INFO - 2018-02-16 15:18:16 --> Loader Class Initialized
INFO - 2018-02-16 15:18:16 --> Helper loaded: url_helper
INFO - 2018-02-16 15:18:16 --> Helper loaded: file_helper
INFO - 2018-02-16 15:18:16 --> Helper loaded: email_helper
INFO - 2018-02-16 15:18:16 --> Helper loaded: common_helper
INFO - 2018-02-16 15:18:16 --> Database Driver Class Initialized
DEBUG - 2018-02-16 15:18:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-16 15:18:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-16 15:18:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-16 15:18:16 --> Pagination Class Initialized
INFO - 2018-02-16 15:18:16 --> Helper loaded: form_helper
INFO - 2018-02-16 15:18:16 --> Form Validation Class Initialized
INFO - 2018-02-16 15:18:16 --> Model Class Initialized
INFO - 2018-02-16 15:18:16 --> Controller Class Initialized
INFO - 2018-02-16 15:18:16 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-16 15:18:16 --> Model Class Initialized
INFO - 2018-02-16 15:18:16 --> Config Class Initialized
INFO - 2018-02-16 15:18:16 --> Hooks Class Initialized
DEBUG - 2018-02-16 15:18:16 --> UTF-8 Support Enabled
INFO - 2018-02-16 15:18:16 --> Utf8 Class Initialized
INFO - 2018-02-16 15:18:16 --> URI Class Initialized
INFO - 2018-02-16 15:18:16 --> Router Class Initialized
INFO - 2018-02-16 15:18:16 --> Output Class Initialized
INFO - 2018-02-16 15:18:16 --> Security Class Initialized
DEBUG - 2018-02-16 15:18:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-16 15:18:16 --> Input Class Initialized
INFO - 2018-02-16 15:18:16 --> Language Class Initialized
INFO - 2018-02-16 15:18:16 --> Loader Class Initialized
INFO - 2018-02-16 15:18:16 --> Helper loaded: url_helper
INFO - 2018-02-16 15:18:16 --> Helper loaded: file_helper
INFO - 2018-02-16 15:18:16 --> Helper loaded: email_helper
INFO - 2018-02-16 15:18:16 --> Helper loaded: common_helper
INFO - 2018-02-16 15:18:16 --> Database Driver Class Initialized
DEBUG - 2018-02-16 15:18:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-16 15:18:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-16 15:18:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-16 15:18:16 --> Pagination Class Initialized
INFO - 2018-02-16 15:18:16 --> Helper loaded: form_helper
INFO - 2018-02-16 15:18:16 --> Form Validation Class Initialized
INFO - 2018-02-16 15:18:16 --> Model Class Initialized
INFO - 2018-02-16 15:18:16 --> Controller Class Initialized
INFO - 2018-02-16 15:18:16 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-16 15:18:16 --> Model Class Initialized
DEBUG - 2018-02-16 15:18:16 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-16 15:18:16 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-02-16 15:18:16 --> Config Class Initialized
INFO - 2018-02-16 15:18:16 --> Hooks Class Initialized
DEBUG - 2018-02-16 15:18:16 --> UTF-8 Support Enabled
INFO - 2018-02-16 15:18:16 --> Utf8 Class Initialized
INFO - 2018-02-16 15:18:16 --> URI Class Initialized
INFO - 2018-02-16 15:18:16 --> Router Class Initialized
INFO - 2018-02-16 15:18:16 --> Output Class Initialized
INFO - 2018-02-16 15:18:16 --> Security Class Initialized
DEBUG - 2018-02-16 15:18:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-16 15:18:16 --> Input Class Initialized
INFO - 2018-02-16 15:18:16 --> Language Class Initialized
INFO - 2018-02-16 15:18:16 --> Loader Class Initialized
INFO - 2018-02-16 15:18:16 --> Helper loaded: url_helper
INFO - 2018-02-16 15:18:16 --> Helper loaded: file_helper
INFO - 2018-02-16 15:18:16 --> Helper loaded: email_helper
INFO - 2018-02-16 15:18:16 --> Helper loaded: common_helper
INFO - 2018-02-16 15:18:16 --> Database Driver Class Initialized
DEBUG - 2018-02-16 15:18:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-16 15:18:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-16 15:18:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-16 15:18:16 --> Pagination Class Initialized
INFO - 2018-02-16 15:18:16 --> Helper loaded: form_helper
INFO - 2018-02-16 15:18:16 --> Form Validation Class Initialized
INFO - 2018-02-16 15:18:16 --> Model Class Initialized
INFO - 2018-02-16 15:18:16 --> Controller Class Initialized
INFO - 2018-02-16 15:18:16 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-16 15:18:16 --> Model Class Initialized
INFO - 2018-02-16 15:18:16 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-16 15:18:16 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-16 15:18:16 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-16 15:18:16 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-16 15:18:16 --> File loaded: /var/www/html/project/radio/application/views/staticpages/index.php
INFO - 2018-02-16 15:18:16 --> Final output sent to browser
DEBUG - 2018-02-16 15:18:16 --> Total execution time: 0.0058
INFO - 2018-02-16 15:18:22 --> Config Class Initialized
INFO - 2018-02-16 15:18:22 --> Hooks Class Initialized
DEBUG - 2018-02-16 15:18:22 --> UTF-8 Support Enabled
INFO - 2018-02-16 15:18:22 --> Utf8 Class Initialized
INFO - 2018-02-16 15:18:22 --> URI Class Initialized
INFO - 2018-02-16 15:18:22 --> Router Class Initialized
INFO - 2018-02-16 15:18:22 --> Output Class Initialized
INFO - 2018-02-16 15:18:22 --> Security Class Initialized
DEBUG - 2018-02-16 15:18:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-16 15:18:22 --> Input Class Initialized
INFO - 2018-02-16 15:18:22 --> Language Class Initialized
INFO - 2018-02-16 15:18:22 --> Loader Class Initialized
INFO - 2018-02-16 15:18:22 --> Helper loaded: url_helper
INFO - 2018-02-16 15:18:22 --> Helper loaded: file_helper
INFO - 2018-02-16 15:18:22 --> Helper loaded: email_helper
INFO - 2018-02-16 15:18:22 --> Helper loaded: common_helper
INFO - 2018-02-16 15:18:22 --> Database Driver Class Initialized
DEBUG - 2018-02-16 15:18:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-16 15:18:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-16 15:18:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-16 15:18:22 --> Pagination Class Initialized
INFO - 2018-02-16 15:18:22 --> Helper loaded: form_helper
INFO - 2018-02-16 15:18:22 --> Form Validation Class Initialized
INFO - 2018-02-16 15:18:22 --> Model Class Initialized
INFO - 2018-02-16 15:18:22 --> Controller Class Initialized
INFO - 2018-02-16 15:18:22 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-16 15:18:22 --> Model Class Initialized
INFO - 2018-02-16 15:18:22 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-16 15:18:22 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-16 15:18:22 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-16 15:18:22 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-16 15:18:22 --> File loaded: /var/www/html/project/radio/application/views/staticpages/add_edit.php
INFO - 2018-02-16 15:18:22 --> Final output sent to browser
DEBUG - 2018-02-16 15:18:22 --> Total execution time: 0.0063
INFO - 2018-02-16 15:18:25 --> Config Class Initialized
INFO - 2018-02-16 15:18:25 --> Hooks Class Initialized
DEBUG - 2018-02-16 15:18:25 --> UTF-8 Support Enabled
INFO - 2018-02-16 15:18:25 --> Utf8 Class Initialized
INFO - 2018-02-16 15:18:25 --> URI Class Initialized
INFO - 2018-02-16 15:18:25 --> Router Class Initialized
INFO - 2018-02-16 15:18:25 --> Output Class Initialized
INFO - 2018-02-16 15:18:25 --> Security Class Initialized
DEBUG - 2018-02-16 15:18:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-16 15:18:25 --> Input Class Initialized
INFO - 2018-02-16 15:18:25 --> Language Class Initialized
INFO - 2018-02-16 15:18:25 --> Loader Class Initialized
INFO - 2018-02-16 15:18:25 --> Helper loaded: url_helper
INFO - 2018-02-16 15:18:25 --> Helper loaded: file_helper
INFO - 2018-02-16 15:18:25 --> Helper loaded: email_helper
INFO - 2018-02-16 15:18:25 --> Helper loaded: common_helper
INFO - 2018-02-16 15:18:25 --> Database Driver Class Initialized
DEBUG - 2018-02-16 15:18:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-16 15:18:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-16 15:18:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-16 15:18:25 --> Pagination Class Initialized
INFO - 2018-02-16 15:18:25 --> Helper loaded: form_helper
INFO - 2018-02-16 15:18:25 --> Form Validation Class Initialized
INFO - 2018-02-16 15:18:25 --> Model Class Initialized
INFO - 2018-02-16 15:18:25 --> Controller Class Initialized
INFO - 2018-02-16 15:18:25 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-16 15:18:25 --> Model Class Initialized
INFO - 2018-02-16 15:18:30 --> Config Class Initialized
INFO - 2018-02-16 15:18:30 --> Hooks Class Initialized
DEBUG - 2018-02-16 15:18:30 --> UTF-8 Support Enabled
INFO - 2018-02-16 15:18:30 --> Utf8 Class Initialized
INFO - 2018-02-16 15:18:30 --> URI Class Initialized
INFO - 2018-02-16 15:18:30 --> Router Class Initialized
INFO - 2018-02-16 15:18:30 --> Output Class Initialized
INFO - 2018-02-16 15:18:30 --> Security Class Initialized
DEBUG - 2018-02-16 15:18:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-16 15:18:30 --> Input Class Initialized
INFO - 2018-02-16 15:18:30 --> Language Class Initialized
INFO - 2018-02-16 15:18:30 --> Loader Class Initialized
INFO - 2018-02-16 15:18:30 --> Helper loaded: url_helper
INFO - 2018-02-16 15:18:30 --> Helper loaded: file_helper
INFO - 2018-02-16 15:18:30 --> Helper loaded: email_helper
INFO - 2018-02-16 15:18:30 --> Helper loaded: common_helper
INFO - 2018-02-16 15:18:30 --> Database Driver Class Initialized
DEBUG - 2018-02-16 15:18:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-16 15:18:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-16 15:18:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-16 15:18:30 --> Pagination Class Initialized
INFO - 2018-02-16 15:18:30 --> Helper loaded: form_helper
INFO - 2018-02-16 15:18:30 --> Form Validation Class Initialized
INFO - 2018-02-16 15:18:30 --> Model Class Initialized
INFO - 2018-02-16 15:18:30 --> Controller Class Initialized
INFO - 2018-02-16 15:18:30 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-16 15:18:30 --> Model Class Initialized
INFO - 2018-02-16 15:18:30 --> Config Class Initialized
INFO - 2018-02-16 15:18:30 --> Hooks Class Initialized
DEBUG - 2018-02-16 15:18:30 --> UTF-8 Support Enabled
INFO - 2018-02-16 15:18:30 --> Utf8 Class Initialized
INFO - 2018-02-16 15:18:30 --> URI Class Initialized
INFO - 2018-02-16 15:18:30 --> Router Class Initialized
INFO - 2018-02-16 15:18:30 --> Output Class Initialized
INFO - 2018-02-16 15:18:30 --> Security Class Initialized
DEBUG - 2018-02-16 15:18:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-16 15:18:30 --> Input Class Initialized
INFO - 2018-02-16 15:18:30 --> Language Class Initialized
INFO - 2018-02-16 15:18:30 --> Loader Class Initialized
INFO - 2018-02-16 15:18:30 --> Helper loaded: url_helper
INFO - 2018-02-16 15:18:30 --> Helper loaded: file_helper
INFO - 2018-02-16 15:18:30 --> Helper loaded: email_helper
INFO - 2018-02-16 15:18:30 --> Helper loaded: common_helper
INFO - 2018-02-16 15:18:30 --> Database Driver Class Initialized
DEBUG - 2018-02-16 15:18:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-16 15:18:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-16 15:18:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-16 15:18:30 --> Pagination Class Initialized
INFO - 2018-02-16 15:18:30 --> Helper loaded: form_helper
INFO - 2018-02-16 15:18:30 --> Form Validation Class Initialized
INFO - 2018-02-16 15:18:30 --> Model Class Initialized
INFO - 2018-02-16 15:18:30 --> Controller Class Initialized
INFO - 2018-02-16 15:18:30 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-16 15:18:30 --> Model Class Initialized
DEBUG - 2018-02-16 15:18:30 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-16 15:18:30 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-02-16 15:18:30 --> Config Class Initialized
INFO - 2018-02-16 15:18:30 --> Hooks Class Initialized
DEBUG - 2018-02-16 15:18:30 --> UTF-8 Support Enabled
INFO - 2018-02-16 15:18:30 --> Utf8 Class Initialized
INFO - 2018-02-16 15:18:30 --> URI Class Initialized
INFO - 2018-02-16 15:18:30 --> Router Class Initialized
INFO - 2018-02-16 15:18:30 --> Output Class Initialized
INFO - 2018-02-16 15:18:30 --> Security Class Initialized
DEBUG - 2018-02-16 15:18:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-16 15:18:30 --> Input Class Initialized
INFO - 2018-02-16 15:18:30 --> Language Class Initialized
INFO - 2018-02-16 15:18:30 --> Loader Class Initialized
INFO - 2018-02-16 15:18:30 --> Helper loaded: url_helper
INFO - 2018-02-16 15:18:30 --> Helper loaded: file_helper
INFO - 2018-02-16 15:18:30 --> Helper loaded: email_helper
INFO - 2018-02-16 15:18:30 --> Helper loaded: common_helper
INFO - 2018-02-16 15:18:30 --> Database Driver Class Initialized
DEBUG - 2018-02-16 15:18:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-16 15:18:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-16 15:18:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-16 15:18:30 --> Pagination Class Initialized
INFO - 2018-02-16 15:18:30 --> Helper loaded: form_helper
INFO - 2018-02-16 15:18:30 --> Form Validation Class Initialized
INFO - 2018-02-16 15:18:30 --> Model Class Initialized
INFO - 2018-02-16 15:18:30 --> Controller Class Initialized
INFO - 2018-02-16 15:18:30 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-16 15:18:30 --> Model Class Initialized
INFO - 2018-02-16 15:18:30 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-16 15:18:30 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-16 15:18:30 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-16 15:18:30 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-16 15:18:30 --> File loaded: /var/www/html/project/radio/application/views/staticpages/index.php
INFO - 2018-02-16 15:18:30 --> Final output sent to browser
DEBUG - 2018-02-16 15:18:30 --> Total execution time: 0.0063
INFO - 2018-02-16 15:22:23 --> Config Class Initialized
INFO - 2018-02-16 15:22:23 --> Hooks Class Initialized
DEBUG - 2018-02-16 15:22:23 --> UTF-8 Support Enabled
INFO - 2018-02-16 15:22:23 --> Utf8 Class Initialized
INFO - 2018-02-16 15:22:23 --> URI Class Initialized
INFO - 2018-02-16 15:22:23 --> Router Class Initialized
INFO - 2018-02-16 15:22:23 --> Output Class Initialized
INFO - 2018-02-16 15:22:23 --> Security Class Initialized
DEBUG - 2018-02-16 15:22:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-16 15:22:23 --> Input Class Initialized
INFO - 2018-02-16 15:22:23 --> Language Class Initialized
INFO - 2018-02-16 15:22:23 --> Loader Class Initialized
INFO - 2018-02-16 15:22:23 --> Helper loaded: url_helper
INFO - 2018-02-16 15:22:23 --> Helper loaded: file_helper
INFO - 2018-02-16 15:22:23 --> Helper loaded: email_helper
INFO - 2018-02-16 15:22:23 --> Helper loaded: common_helper
INFO - 2018-02-16 15:22:23 --> Database Driver Class Initialized
DEBUG - 2018-02-16 15:22:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-16 15:22:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-16 15:22:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-16 15:22:23 --> Pagination Class Initialized
INFO - 2018-02-16 15:22:23 --> Helper loaded: form_helper
INFO - 2018-02-16 15:22:23 --> Form Validation Class Initialized
INFO - 2018-02-16 15:22:23 --> Model Class Initialized
INFO - 2018-02-16 15:22:23 --> Controller Class Initialized
INFO - 2018-02-16 15:22:23 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-16 15:22:23 --> Model Class Initialized
INFO - 2018-02-16 15:22:23 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-16 15:22:23 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-16 15:22:23 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-16 15:22:23 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-16 15:22:23 --> File loaded: /var/www/html/project/radio/application/views/staticpages/index.php
INFO - 2018-02-16 15:22:23 --> Final output sent to browser
DEBUG - 2018-02-16 15:22:23 --> Total execution time: 0.0077
INFO - 2018-02-16 15:22:28 --> Config Class Initialized
INFO - 2018-02-16 15:22:28 --> Hooks Class Initialized
DEBUG - 2018-02-16 15:22:28 --> UTF-8 Support Enabled
INFO - 2018-02-16 15:22:28 --> Utf8 Class Initialized
INFO - 2018-02-16 15:22:28 --> URI Class Initialized
INFO - 2018-02-16 15:22:28 --> Router Class Initialized
INFO - 2018-02-16 15:22:28 --> Output Class Initialized
INFO - 2018-02-16 15:22:28 --> Security Class Initialized
DEBUG - 2018-02-16 15:22:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-16 15:22:28 --> Input Class Initialized
INFO - 2018-02-16 15:22:28 --> Language Class Initialized
INFO - 2018-02-16 15:22:28 --> Loader Class Initialized
INFO - 2018-02-16 15:22:28 --> Helper loaded: url_helper
INFO - 2018-02-16 15:22:28 --> Helper loaded: file_helper
INFO - 2018-02-16 15:22:28 --> Helper loaded: email_helper
INFO - 2018-02-16 15:22:28 --> Helper loaded: common_helper
INFO - 2018-02-16 15:22:28 --> Database Driver Class Initialized
DEBUG - 2018-02-16 15:22:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-16 15:22:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-16 15:22:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-16 15:22:28 --> Pagination Class Initialized
INFO - 2018-02-16 15:22:28 --> Helper loaded: form_helper
INFO - 2018-02-16 15:22:28 --> Form Validation Class Initialized
INFO - 2018-02-16 15:22:28 --> Model Class Initialized
INFO - 2018-02-16 15:22:28 --> Controller Class Initialized
INFO - 2018-02-16 15:22:28 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-16 15:22:28 --> Model Class Initialized
INFO - 2018-02-16 15:22:28 --> Config Class Initialized
INFO - 2018-02-16 15:22:28 --> Hooks Class Initialized
DEBUG - 2018-02-16 15:22:28 --> UTF-8 Support Enabled
INFO - 2018-02-16 15:22:28 --> Utf8 Class Initialized
INFO - 2018-02-16 15:22:28 --> URI Class Initialized
INFO - 2018-02-16 15:22:28 --> Router Class Initialized
INFO - 2018-02-16 15:22:28 --> Output Class Initialized
INFO - 2018-02-16 15:22:28 --> Security Class Initialized
DEBUG - 2018-02-16 15:22:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-16 15:22:28 --> Input Class Initialized
INFO - 2018-02-16 15:22:28 --> Language Class Initialized
INFO - 2018-02-16 15:22:28 --> Loader Class Initialized
INFO - 2018-02-16 15:22:28 --> Helper loaded: url_helper
INFO - 2018-02-16 15:22:28 --> Helper loaded: file_helper
INFO - 2018-02-16 15:22:28 --> Helper loaded: email_helper
INFO - 2018-02-16 15:22:28 --> Helper loaded: common_helper
INFO - 2018-02-16 15:22:28 --> Database Driver Class Initialized
DEBUG - 2018-02-16 15:22:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-16 15:22:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-16 15:22:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-16 15:22:28 --> Pagination Class Initialized
INFO - 2018-02-16 15:22:28 --> Helper loaded: form_helper
INFO - 2018-02-16 15:22:28 --> Form Validation Class Initialized
INFO - 2018-02-16 15:22:28 --> Model Class Initialized
INFO - 2018-02-16 15:22:28 --> Controller Class Initialized
INFO - 2018-02-16 15:22:28 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-16 15:22:28 --> Model Class Initialized
INFO - 2018-02-16 15:22:28 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-16 15:22:28 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-16 15:22:28 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-16 15:22:28 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-16 15:22:28 --> File loaded: /var/www/html/project/radio/application/views/staticpages/index.php
INFO - 2018-02-16 15:22:28 --> Final output sent to browser
DEBUG - 2018-02-16 15:22:28 --> Total execution time: 0.0044
INFO - 2018-02-16 15:22:32 --> Config Class Initialized
INFO - 2018-02-16 15:22:32 --> Hooks Class Initialized
DEBUG - 2018-02-16 15:22:32 --> UTF-8 Support Enabled
INFO - 2018-02-16 15:22:32 --> Utf8 Class Initialized
INFO - 2018-02-16 15:22:32 --> URI Class Initialized
INFO - 2018-02-16 15:22:32 --> Router Class Initialized
INFO - 2018-02-16 15:22:32 --> Output Class Initialized
INFO - 2018-02-16 15:22:32 --> Security Class Initialized
DEBUG - 2018-02-16 15:22:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-16 15:22:32 --> Input Class Initialized
INFO - 2018-02-16 15:22:32 --> Language Class Initialized
INFO - 2018-02-16 15:22:32 --> Loader Class Initialized
INFO - 2018-02-16 15:22:32 --> Helper loaded: url_helper
INFO - 2018-02-16 15:22:32 --> Helper loaded: file_helper
INFO - 2018-02-16 15:22:32 --> Helper loaded: email_helper
INFO - 2018-02-16 15:22:32 --> Helper loaded: common_helper
INFO - 2018-02-16 15:22:32 --> Database Driver Class Initialized
DEBUG - 2018-02-16 15:22:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-16 15:22:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-16 15:22:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-16 15:22:32 --> Pagination Class Initialized
INFO - 2018-02-16 15:22:32 --> Helper loaded: form_helper
INFO - 2018-02-16 15:22:32 --> Form Validation Class Initialized
INFO - 2018-02-16 15:22:32 --> Model Class Initialized
INFO - 2018-02-16 15:22:32 --> Controller Class Initialized
INFO - 2018-02-16 15:22:32 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-16 15:22:32 --> Model Class Initialized
INFO - 2018-02-16 15:22:32 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-16 15:22:32 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-16 15:22:32 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-16 15:22:32 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-16 15:22:32 --> File loaded: /var/www/html/project/radio/application/views/staticpages/index.php
INFO - 2018-02-16 15:22:32 --> Final output sent to browser
DEBUG - 2018-02-16 15:22:32 --> Total execution time: 0.0054
INFO - 2018-02-16 15:22:34 --> Config Class Initialized
INFO - 2018-02-16 15:22:34 --> Hooks Class Initialized
DEBUG - 2018-02-16 15:22:34 --> UTF-8 Support Enabled
INFO - 2018-02-16 15:22:34 --> Utf8 Class Initialized
INFO - 2018-02-16 15:22:34 --> URI Class Initialized
INFO - 2018-02-16 15:22:34 --> Router Class Initialized
INFO - 2018-02-16 15:22:34 --> Output Class Initialized
INFO - 2018-02-16 15:22:34 --> Security Class Initialized
DEBUG - 2018-02-16 15:22:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-16 15:22:34 --> Input Class Initialized
INFO - 2018-02-16 15:22:34 --> Language Class Initialized
INFO - 2018-02-16 15:22:34 --> Loader Class Initialized
INFO - 2018-02-16 15:22:34 --> Helper loaded: url_helper
INFO - 2018-02-16 15:22:34 --> Helper loaded: file_helper
INFO - 2018-02-16 15:22:34 --> Helper loaded: email_helper
INFO - 2018-02-16 15:22:34 --> Helper loaded: common_helper
INFO - 2018-02-16 15:22:34 --> Database Driver Class Initialized
DEBUG - 2018-02-16 15:22:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-16 15:22:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-16 15:22:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-16 15:22:34 --> Pagination Class Initialized
INFO - 2018-02-16 15:22:34 --> Helper loaded: form_helper
INFO - 2018-02-16 15:22:34 --> Form Validation Class Initialized
INFO - 2018-02-16 15:22:34 --> Model Class Initialized
INFO - 2018-02-16 15:22:34 --> Controller Class Initialized
INFO - 2018-02-16 15:22:34 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-16 15:22:34 --> Model Class Initialized
INFO - 2018-02-16 15:22:34 --> Config Class Initialized
INFO - 2018-02-16 15:22:34 --> Hooks Class Initialized
DEBUG - 2018-02-16 15:22:34 --> UTF-8 Support Enabled
INFO - 2018-02-16 15:22:34 --> Utf8 Class Initialized
INFO - 2018-02-16 15:22:34 --> URI Class Initialized
INFO - 2018-02-16 15:22:34 --> Router Class Initialized
INFO - 2018-02-16 15:22:34 --> Output Class Initialized
INFO - 2018-02-16 15:22:34 --> Security Class Initialized
DEBUG - 2018-02-16 15:22:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-16 15:22:34 --> Input Class Initialized
INFO - 2018-02-16 15:22:34 --> Language Class Initialized
INFO - 2018-02-16 15:22:34 --> Loader Class Initialized
INFO - 2018-02-16 15:22:34 --> Helper loaded: url_helper
INFO - 2018-02-16 15:22:34 --> Helper loaded: file_helper
INFO - 2018-02-16 15:22:34 --> Helper loaded: email_helper
INFO - 2018-02-16 15:22:34 --> Helper loaded: common_helper
INFO - 2018-02-16 15:22:34 --> Database Driver Class Initialized
DEBUG - 2018-02-16 15:22:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-16 15:22:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-16 15:22:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-16 15:22:34 --> Pagination Class Initialized
INFO - 2018-02-16 15:22:34 --> Helper loaded: form_helper
INFO - 2018-02-16 15:22:34 --> Form Validation Class Initialized
INFO - 2018-02-16 15:22:34 --> Model Class Initialized
INFO - 2018-02-16 15:22:34 --> Controller Class Initialized
INFO - 2018-02-16 15:22:34 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-16 15:22:34 --> Model Class Initialized
INFO - 2018-02-16 15:22:34 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-16 15:22:34 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-16 15:22:34 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-16 15:22:34 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-16 15:22:34 --> File loaded: /var/www/html/project/radio/application/views/staticpages/index.php
INFO - 2018-02-16 15:22:34 --> Final output sent to browser
DEBUG - 2018-02-16 15:22:34 --> Total execution time: 0.0049
INFO - 2018-02-16 15:27:13 --> Config Class Initialized
INFO - 2018-02-16 15:27:13 --> Hooks Class Initialized
DEBUG - 2018-02-16 15:27:13 --> UTF-8 Support Enabled
INFO - 2018-02-16 15:27:13 --> Utf8 Class Initialized
INFO - 2018-02-16 15:27:13 --> URI Class Initialized
INFO - 2018-02-16 15:27:13 --> Router Class Initialized
INFO - 2018-02-16 15:27:13 --> Output Class Initialized
INFO - 2018-02-16 15:27:13 --> Security Class Initialized
DEBUG - 2018-02-16 15:27:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-16 15:27:13 --> Input Class Initialized
INFO - 2018-02-16 15:27:13 --> Language Class Initialized
INFO - 2018-02-16 15:27:13 --> Loader Class Initialized
INFO - 2018-02-16 15:27:13 --> Helper loaded: url_helper
INFO - 2018-02-16 15:27:13 --> Helper loaded: file_helper
INFO - 2018-02-16 15:27:13 --> Helper loaded: email_helper
INFO - 2018-02-16 15:27:13 --> Helper loaded: common_helper
INFO - 2018-02-16 15:27:13 --> Database Driver Class Initialized
DEBUG - 2018-02-16 15:27:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-16 15:27:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-16 15:27:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-16 15:27:13 --> Pagination Class Initialized
INFO - 2018-02-16 15:27:13 --> Helper loaded: form_helper
INFO - 2018-02-16 15:27:13 --> Form Validation Class Initialized
INFO - 2018-02-16 15:27:13 --> Model Class Initialized
INFO - 2018-02-16 15:27:13 --> Controller Class Initialized
INFO - 2018-02-16 15:27:13 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-16 15:27:13 --> Model Class Initialized
INFO - 2018-02-16 15:27:13 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-16 15:27:13 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-16 15:27:13 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-16 15:27:13 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-16 15:27:13 --> File loaded: /var/www/html/project/radio/application/views/staticpages/index.php
INFO - 2018-02-16 15:27:13 --> Final output sent to browser
DEBUG - 2018-02-16 15:27:13 --> Total execution time: 0.0088
INFO - 2018-02-16 15:27:17 --> Config Class Initialized
INFO - 2018-02-16 15:27:17 --> Hooks Class Initialized
DEBUG - 2018-02-16 15:27:17 --> UTF-8 Support Enabled
INFO - 2018-02-16 15:27:17 --> Utf8 Class Initialized
INFO - 2018-02-16 15:27:17 --> URI Class Initialized
INFO - 2018-02-16 15:27:17 --> Router Class Initialized
INFO - 2018-02-16 15:27:17 --> Output Class Initialized
INFO - 2018-02-16 15:27:17 --> Security Class Initialized
DEBUG - 2018-02-16 15:27:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-16 15:27:17 --> Input Class Initialized
INFO - 2018-02-16 15:27:17 --> Language Class Initialized
INFO - 2018-02-16 15:27:17 --> Loader Class Initialized
INFO - 2018-02-16 15:27:17 --> Helper loaded: url_helper
INFO - 2018-02-16 15:27:17 --> Helper loaded: file_helper
INFO - 2018-02-16 15:27:17 --> Helper loaded: email_helper
INFO - 2018-02-16 15:27:17 --> Helper loaded: common_helper
INFO - 2018-02-16 15:27:17 --> Database Driver Class Initialized
DEBUG - 2018-02-16 15:27:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-16 15:27:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-16 15:27:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-16 15:27:17 --> Pagination Class Initialized
INFO - 2018-02-16 15:27:17 --> Helper loaded: form_helper
INFO - 2018-02-16 15:27:17 --> Form Validation Class Initialized
INFO - 2018-02-16 15:27:17 --> Model Class Initialized
INFO - 2018-02-16 15:27:17 --> Controller Class Initialized
INFO - 2018-02-16 15:27:17 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-16 15:27:17 --> Model Class Initialized
INFO - 2018-02-16 15:27:17 --> Config Class Initialized
INFO - 2018-02-16 15:27:17 --> Hooks Class Initialized
DEBUG - 2018-02-16 15:27:17 --> UTF-8 Support Enabled
INFO - 2018-02-16 15:27:17 --> Utf8 Class Initialized
INFO - 2018-02-16 15:27:17 --> URI Class Initialized
INFO - 2018-02-16 15:27:17 --> Router Class Initialized
INFO - 2018-02-16 15:27:17 --> Output Class Initialized
INFO - 2018-02-16 15:27:17 --> Security Class Initialized
DEBUG - 2018-02-16 15:27:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-16 15:27:17 --> Input Class Initialized
INFO - 2018-02-16 15:27:17 --> Language Class Initialized
INFO - 2018-02-16 15:27:17 --> Loader Class Initialized
INFO - 2018-02-16 15:27:17 --> Helper loaded: url_helper
INFO - 2018-02-16 15:27:17 --> Helper loaded: file_helper
INFO - 2018-02-16 15:27:17 --> Helper loaded: email_helper
INFO - 2018-02-16 15:27:17 --> Helper loaded: common_helper
INFO - 2018-02-16 15:27:17 --> Database Driver Class Initialized
DEBUG - 2018-02-16 15:27:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-16 15:27:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-16 15:27:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-16 15:27:17 --> Pagination Class Initialized
INFO - 2018-02-16 15:27:17 --> Helper loaded: form_helper
INFO - 2018-02-16 15:27:17 --> Form Validation Class Initialized
INFO - 2018-02-16 15:27:17 --> Model Class Initialized
INFO - 2018-02-16 15:27:17 --> Controller Class Initialized
INFO - 2018-02-16 15:27:17 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-16 15:27:17 --> Model Class Initialized
INFO - 2018-02-16 15:27:17 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-16 15:27:17 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-16 15:27:17 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-16 15:27:17 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-16 15:27:17 --> File loaded: /var/www/html/project/radio/application/views/staticpages/index.php
INFO - 2018-02-16 15:27:17 --> Final output sent to browser
DEBUG - 2018-02-16 15:27:17 --> Total execution time: 0.0045
INFO - 2018-02-16 15:27:27 --> Config Class Initialized
INFO - 2018-02-16 15:27:27 --> Hooks Class Initialized
DEBUG - 2018-02-16 15:27:27 --> UTF-8 Support Enabled
INFO - 2018-02-16 15:27:27 --> Utf8 Class Initialized
INFO - 2018-02-16 15:27:27 --> URI Class Initialized
INFO - 2018-02-16 15:27:27 --> Router Class Initialized
INFO - 2018-02-16 15:27:27 --> Output Class Initialized
INFO - 2018-02-16 15:27:27 --> Security Class Initialized
DEBUG - 2018-02-16 15:27:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-16 15:27:27 --> Input Class Initialized
INFO - 2018-02-16 15:27:27 --> Language Class Initialized
INFO - 2018-02-16 15:27:27 --> Loader Class Initialized
INFO - 2018-02-16 15:27:27 --> Helper loaded: url_helper
INFO - 2018-02-16 15:27:27 --> Helper loaded: file_helper
INFO - 2018-02-16 15:27:27 --> Helper loaded: email_helper
INFO - 2018-02-16 15:27:27 --> Helper loaded: common_helper
INFO - 2018-02-16 15:27:27 --> Database Driver Class Initialized
DEBUG - 2018-02-16 15:27:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-16 15:27:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-16 15:27:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-16 15:27:27 --> Pagination Class Initialized
INFO - 2018-02-16 15:27:27 --> Helper loaded: form_helper
INFO - 2018-02-16 15:27:27 --> Form Validation Class Initialized
INFO - 2018-02-16 15:27:27 --> Model Class Initialized
INFO - 2018-02-16 15:27:27 --> Controller Class Initialized
INFO - 2018-02-16 15:27:27 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-16 15:27:27 --> Model Class Initialized
INFO - 2018-02-16 15:27:27 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-16 15:27:27 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-16 15:27:27 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-16 15:27:27 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-16 15:27:27 --> File loaded: /var/www/html/project/radio/application/views/staticpages/index.php
INFO - 2018-02-16 15:27:27 --> Final output sent to browser
DEBUG - 2018-02-16 15:27:27 --> Total execution time: 0.0071
INFO - 2018-02-16 15:48:54 --> Config Class Initialized
INFO - 2018-02-16 15:48:54 --> Hooks Class Initialized
DEBUG - 2018-02-16 15:48:54 --> UTF-8 Support Enabled
INFO - 2018-02-16 15:48:54 --> Utf8 Class Initialized
INFO - 2018-02-16 15:48:54 --> URI Class Initialized
INFO - 2018-02-16 15:48:54 --> Router Class Initialized
INFO - 2018-02-16 15:48:54 --> Output Class Initialized
INFO - 2018-02-16 15:48:54 --> Security Class Initialized
DEBUG - 2018-02-16 15:48:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-16 15:48:54 --> Input Class Initialized
INFO - 2018-02-16 15:48:54 --> Language Class Initialized
INFO - 2018-02-16 15:48:54 --> Loader Class Initialized
INFO - 2018-02-16 15:48:54 --> Helper loaded: url_helper
INFO - 2018-02-16 15:48:54 --> Helper loaded: file_helper
INFO - 2018-02-16 15:48:54 --> Helper loaded: email_helper
INFO - 2018-02-16 15:48:54 --> Helper loaded: common_helper
INFO - 2018-02-16 15:48:54 --> Database Driver Class Initialized
DEBUG - 2018-02-16 15:48:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-16 15:48:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-16 15:48:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-16 15:48:54 --> Pagination Class Initialized
INFO - 2018-02-16 15:48:54 --> Helper loaded: form_helper
INFO - 2018-02-16 15:48:54 --> Form Validation Class Initialized
INFO - 2018-02-16 15:48:54 --> Model Class Initialized
INFO - 2018-02-16 15:48:54 --> Controller Class Initialized
INFO - 2018-02-16 15:48:54 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-16 15:48:54 --> Model Class Initialized
INFO - 2018-02-16 15:48:54 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-16 15:48:54 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-16 15:48:54 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-16 15:48:54 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-16 15:48:54 --> File loaded: /var/www/html/project/radio/application/views/category/index.php
INFO - 2018-02-16 15:48:54 --> Final output sent to browser
DEBUG - 2018-02-16 15:48:54 --> Total execution time: 0.0067
INFO - 2018-02-16 15:48:56 --> Config Class Initialized
INFO - 2018-02-16 15:48:56 --> Hooks Class Initialized
DEBUG - 2018-02-16 15:48:56 --> UTF-8 Support Enabled
INFO - 2018-02-16 15:48:56 --> Utf8 Class Initialized
INFO - 2018-02-16 15:48:56 --> URI Class Initialized
INFO - 2018-02-16 15:48:56 --> Router Class Initialized
INFO - 2018-02-16 15:48:56 --> Output Class Initialized
INFO - 2018-02-16 15:48:56 --> Security Class Initialized
DEBUG - 2018-02-16 15:48:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-16 15:48:56 --> Input Class Initialized
INFO - 2018-02-16 15:48:56 --> Language Class Initialized
INFO - 2018-02-16 15:48:56 --> Loader Class Initialized
INFO - 2018-02-16 15:48:56 --> Helper loaded: url_helper
INFO - 2018-02-16 15:48:56 --> Helper loaded: file_helper
INFO - 2018-02-16 15:48:56 --> Helper loaded: email_helper
INFO - 2018-02-16 15:48:56 --> Helper loaded: common_helper
INFO - 2018-02-16 15:48:56 --> Database Driver Class Initialized
DEBUG - 2018-02-16 15:48:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-16 15:48:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-16 15:48:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-16 15:48:56 --> Pagination Class Initialized
INFO - 2018-02-16 15:48:56 --> Helper loaded: form_helper
INFO - 2018-02-16 15:48:56 --> Form Validation Class Initialized
INFO - 2018-02-16 15:48:56 --> Model Class Initialized
INFO - 2018-02-16 15:48:56 --> Controller Class Initialized
INFO - 2018-02-16 15:48:56 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-16 15:48:56 --> Model Class Initialized
INFO - 2018-02-16 15:48:56 --> Config Class Initialized
INFO - 2018-02-16 15:48:56 --> Hooks Class Initialized
DEBUG - 2018-02-16 15:48:56 --> UTF-8 Support Enabled
INFO - 2018-02-16 15:48:56 --> Utf8 Class Initialized
INFO - 2018-02-16 15:48:56 --> URI Class Initialized
INFO - 2018-02-16 15:48:56 --> Router Class Initialized
INFO - 2018-02-16 15:48:56 --> Output Class Initialized
INFO - 2018-02-16 15:48:56 --> Security Class Initialized
DEBUG - 2018-02-16 15:48:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-16 15:48:56 --> Input Class Initialized
INFO - 2018-02-16 15:48:56 --> Language Class Initialized
INFO - 2018-02-16 15:48:56 --> Loader Class Initialized
INFO - 2018-02-16 15:48:56 --> Helper loaded: url_helper
INFO - 2018-02-16 15:48:56 --> Helper loaded: file_helper
INFO - 2018-02-16 15:48:56 --> Helper loaded: email_helper
INFO - 2018-02-16 15:48:56 --> Helper loaded: common_helper
INFO - 2018-02-16 15:48:56 --> Database Driver Class Initialized
DEBUG - 2018-02-16 15:48:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-16 15:48:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-16 15:48:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-16 15:48:56 --> Pagination Class Initialized
INFO - 2018-02-16 15:48:56 --> Helper loaded: form_helper
INFO - 2018-02-16 15:48:56 --> Form Validation Class Initialized
INFO - 2018-02-16 15:48:56 --> Model Class Initialized
INFO - 2018-02-16 15:48:56 --> Controller Class Initialized
INFO - 2018-02-16 15:48:56 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-16 15:48:56 --> Model Class Initialized
INFO - 2018-02-16 15:48:56 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-16 15:48:56 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-16 15:48:56 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-16 15:48:56 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-16 15:48:56 --> File loaded: /var/www/html/project/radio/application/views/category/index.php
INFO - 2018-02-16 15:48:56 --> Final output sent to browser
DEBUG - 2018-02-16 15:48:56 --> Total execution time: 0.0043
INFO - 2018-02-16 15:48:58 --> Config Class Initialized
INFO - 2018-02-16 15:48:58 --> Hooks Class Initialized
DEBUG - 2018-02-16 15:48:58 --> UTF-8 Support Enabled
INFO - 2018-02-16 15:48:58 --> Utf8 Class Initialized
INFO - 2018-02-16 15:48:58 --> URI Class Initialized
INFO - 2018-02-16 15:48:58 --> Router Class Initialized
INFO - 2018-02-16 15:48:58 --> Output Class Initialized
INFO - 2018-02-16 15:48:58 --> Security Class Initialized
DEBUG - 2018-02-16 15:48:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-16 15:48:58 --> Input Class Initialized
INFO - 2018-02-16 15:48:58 --> Language Class Initialized
INFO - 2018-02-16 15:48:58 --> Loader Class Initialized
INFO - 2018-02-16 15:48:58 --> Helper loaded: url_helper
INFO - 2018-02-16 15:48:58 --> Helper loaded: file_helper
INFO - 2018-02-16 15:48:58 --> Helper loaded: email_helper
INFO - 2018-02-16 15:48:58 --> Helper loaded: common_helper
INFO - 2018-02-16 15:48:58 --> Database Driver Class Initialized
DEBUG - 2018-02-16 15:48:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-16 15:48:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-16 15:48:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-16 15:48:58 --> Pagination Class Initialized
INFO - 2018-02-16 15:48:58 --> Helper loaded: form_helper
INFO - 2018-02-16 15:48:58 --> Form Validation Class Initialized
INFO - 2018-02-16 15:48:58 --> Model Class Initialized
INFO - 2018-02-16 15:48:58 --> Controller Class Initialized
INFO - 2018-02-16 15:48:58 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-16 15:48:58 --> Model Class Initialized
INFO - 2018-02-16 15:48:58 --> Config Class Initialized
INFO - 2018-02-16 15:48:58 --> Hooks Class Initialized
DEBUG - 2018-02-16 15:48:58 --> UTF-8 Support Enabled
INFO - 2018-02-16 15:48:58 --> Utf8 Class Initialized
INFO - 2018-02-16 15:48:58 --> URI Class Initialized
INFO - 2018-02-16 15:48:58 --> Router Class Initialized
INFO - 2018-02-16 15:48:58 --> Output Class Initialized
INFO - 2018-02-16 15:48:58 --> Security Class Initialized
DEBUG - 2018-02-16 15:48:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-16 15:48:58 --> Input Class Initialized
INFO - 2018-02-16 15:48:58 --> Language Class Initialized
INFO - 2018-02-16 15:48:58 --> Loader Class Initialized
INFO - 2018-02-16 15:48:58 --> Helper loaded: url_helper
INFO - 2018-02-16 15:48:58 --> Helper loaded: file_helper
INFO - 2018-02-16 15:48:58 --> Helper loaded: email_helper
INFO - 2018-02-16 15:48:58 --> Helper loaded: common_helper
INFO - 2018-02-16 15:48:58 --> Database Driver Class Initialized
DEBUG - 2018-02-16 15:48:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-16 15:48:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-16 15:48:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-16 15:48:58 --> Pagination Class Initialized
INFO - 2018-02-16 15:48:58 --> Helper loaded: form_helper
INFO - 2018-02-16 15:48:58 --> Form Validation Class Initialized
INFO - 2018-02-16 15:48:58 --> Model Class Initialized
INFO - 2018-02-16 15:48:58 --> Controller Class Initialized
INFO - 2018-02-16 15:48:58 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-16 15:48:58 --> Model Class Initialized
INFO - 2018-02-16 15:48:58 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-16 15:48:58 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-16 15:48:58 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-16 15:48:58 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-16 15:48:58 --> File loaded: /var/www/html/project/radio/application/views/category/index.php
INFO - 2018-02-16 15:48:58 --> Final output sent to browser
DEBUG - 2018-02-16 15:48:58 --> Total execution time: 0.0043
INFO - 2018-02-16 15:49:00 --> Config Class Initialized
INFO - 2018-02-16 15:49:00 --> Hooks Class Initialized
DEBUG - 2018-02-16 15:49:00 --> UTF-8 Support Enabled
INFO - 2018-02-16 15:49:00 --> Utf8 Class Initialized
INFO - 2018-02-16 15:49:00 --> URI Class Initialized
INFO - 2018-02-16 15:49:00 --> Router Class Initialized
INFO - 2018-02-16 15:49:00 --> Output Class Initialized
INFO - 2018-02-16 15:49:00 --> Security Class Initialized
DEBUG - 2018-02-16 15:49:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-16 15:49:00 --> Input Class Initialized
INFO - 2018-02-16 15:49:00 --> Language Class Initialized
INFO - 2018-02-16 15:49:00 --> Loader Class Initialized
INFO - 2018-02-16 15:49:00 --> Helper loaded: url_helper
INFO - 2018-02-16 15:49:00 --> Helper loaded: file_helper
INFO - 2018-02-16 15:49:00 --> Helper loaded: email_helper
INFO - 2018-02-16 15:49:00 --> Helper loaded: common_helper
INFO - 2018-02-16 15:49:00 --> Database Driver Class Initialized
DEBUG - 2018-02-16 15:49:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-16 15:49:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-16 15:49:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-16 15:49:00 --> Pagination Class Initialized
INFO - 2018-02-16 15:49:00 --> Helper loaded: form_helper
INFO - 2018-02-16 15:49:00 --> Form Validation Class Initialized
INFO - 2018-02-16 15:49:00 --> Model Class Initialized
INFO - 2018-02-16 15:49:00 --> Controller Class Initialized
INFO - 2018-02-16 15:49:00 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-16 15:49:00 --> Model Class Initialized
INFO - 2018-02-16 15:49:00 --> Config Class Initialized
INFO - 2018-02-16 15:49:00 --> Hooks Class Initialized
DEBUG - 2018-02-16 15:49:00 --> UTF-8 Support Enabled
INFO - 2018-02-16 15:49:00 --> Utf8 Class Initialized
INFO - 2018-02-16 15:49:00 --> URI Class Initialized
INFO - 2018-02-16 15:49:00 --> Router Class Initialized
INFO - 2018-02-16 15:49:00 --> Output Class Initialized
INFO - 2018-02-16 15:49:00 --> Security Class Initialized
DEBUG - 2018-02-16 15:49:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-16 15:49:00 --> Input Class Initialized
INFO - 2018-02-16 15:49:00 --> Language Class Initialized
INFO - 2018-02-16 15:49:00 --> Loader Class Initialized
INFO - 2018-02-16 15:49:00 --> Helper loaded: url_helper
INFO - 2018-02-16 15:49:00 --> Helper loaded: file_helper
INFO - 2018-02-16 15:49:00 --> Helper loaded: email_helper
INFO - 2018-02-16 15:49:00 --> Helper loaded: common_helper
INFO - 2018-02-16 15:49:00 --> Database Driver Class Initialized
DEBUG - 2018-02-16 15:49:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-16 15:49:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-16 15:49:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-16 15:49:00 --> Pagination Class Initialized
INFO - 2018-02-16 15:49:00 --> Helper loaded: form_helper
INFO - 2018-02-16 15:49:00 --> Form Validation Class Initialized
INFO - 2018-02-16 15:49:00 --> Model Class Initialized
INFO - 2018-02-16 15:49:00 --> Controller Class Initialized
INFO - 2018-02-16 15:49:00 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-16 15:49:00 --> Model Class Initialized
INFO - 2018-02-16 15:49:00 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-16 15:49:00 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-16 15:49:00 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-16 15:49:00 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-16 15:49:00 --> File loaded: /var/www/html/project/radio/application/views/category/index.php
INFO - 2018-02-16 15:49:00 --> Final output sent to browser
DEBUG - 2018-02-16 15:49:00 --> Total execution time: 0.0046
INFO - 2018-02-16 15:49:01 --> Config Class Initialized
INFO - 2018-02-16 15:49:01 --> Hooks Class Initialized
DEBUG - 2018-02-16 15:49:01 --> UTF-8 Support Enabled
INFO - 2018-02-16 15:49:01 --> Utf8 Class Initialized
INFO - 2018-02-16 15:49:01 --> URI Class Initialized
INFO - 2018-02-16 15:49:01 --> Router Class Initialized
INFO - 2018-02-16 15:49:01 --> Output Class Initialized
INFO - 2018-02-16 15:49:01 --> Security Class Initialized
DEBUG - 2018-02-16 15:49:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-16 15:49:01 --> Input Class Initialized
INFO - 2018-02-16 15:49:01 --> Language Class Initialized
INFO - 2018-02-16 15:49:01 --> Loader Class Initialized
INFO - 2018-02-16 15:49:01 --> Helper loaded: url_helper
INFO - 2018-02-16 15:49:01 --> Helper loaded: file_helper
INFO - 2018-02-16 15:49:01 --> Helper loaded: email_helper
INFO - 2018-02-16 15:49:01 --> Helper loaded: common_helper
INFO - 2018-02-16 15:49:01 --> Database Driver Class Initialized
DEBUG - 2018-02-16 15:49:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-16 15:49:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-16 15:49:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-16 15:49:01 --> Pagination Class Initialized
INFO - 2018-02-16 15:49:01 --> Helper loaded: form_helper
INFO - 2018-02-16 15:49:01 --> Form Validation Class Initialized
INFO - 2018-02-16 15:49:01 --> Model Class Initialized
INFO - 2018-02-16 15:49:01 --> Controller Class Initialized
INFO - 2018-02-16 15:49:01 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-16 15:49:01 --> Model Class Initialized
INFO - 2018-02-16 15:49:01 --> Config Class Initialized
INFO - 2018-02-16 15:49:01 --> Hooks Class Initialized
DEBUG - 2018-02-16 15:49:01 --> UTF-8 Support Enabled
INFO - 2018-02-16 15:49:01 --> Utf8 Class Initialized
INFO - 2018-02-16 15:49:01 --> URI Class Initialized
INFO - 2018-02-16 15:49:01 --> Router Class Initialized
INFO - 2018-02-16 15:49:01 --> Output Class Initialized
INFO - 2018-02-16 15:49:01 --> Security Class Initialized
DEBUG - 2018-02-16 15:49:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-16 15:49:01 --> Input Class Initialized
INFO - 2018-02-16 15:49:01 --> Language Class Initialized
INFO - 2018-02-16 15:49:01 --> Loader Class Initialized
INFO - 2018-02-16 15:49:01 --> Helper loaded: url_helper
INFO - 2018-02-16 15:49:01 --> Helper loaded: file_helper
INFO - 2018-02-16 15:49:01 --> Helper loaded: email_helper
INFO - 2018-02-16 15:49:01 --> Helper loaded: common_helper
INFO - 2018-02-16 15:49:01 --> Database Driver Class Initialized
DEBUG - 2018-02-16 15:49:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-16 15:49:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-16 15:49:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-16 15:49:01 --> Pagination Class Initialized
INFO - 2018-02-16 15:49:01 --> Helper loaded: form_helper
INFO - 2018-02-16 15:49:01 --> Form Validation Class Initialized
INFO - 2018-02-16 15:49:01 --> Model Class Initialized
INFO - 2018-02-16 15:49:01 --> Controller Class Initialized
INFO - 2018-02-16 15:49:01 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-16 15:49:01 --> Model Class Initialized
INFO - 2018-02-16 15:49:01 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-16 15:49:01 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-16 15:49:01 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-16 15:49:01 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-16 15:49:01 --> File loaded: /var/www/html/project/radio/application/views/category/index.php
INFO - 2018-02-16 15:49:01 --> Final output sent to browser
DEBUG - 2018-02-16 15:49:01 --> Total execution time: 0.0059
INFO - 2018-02-16 15:49:02 --> Config Class Initialized
INFO - 2018-02-16 15:49:02 --> Hooks Class Initialized
DEBUG - 2018-02-16 15:49:02 --> UTF-8 Support Enabled
INFO - 2018-02-16 15:49:02 --> Utf8 Class Initialized
INFO - 2018-02-16 15:49:02 --> URI Class Initialized
INFO - 2018-02-16 15:49:02 --> Router Class Initialized
INFO - 2018-02-16 15:49:02 --> Output Class Initialized
INFO - 2018-02-16 15:49:02 --> Security Class Initialized
DEBUG - 2018-02-16 15:49:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-16 15:49:02 --> Input Class Initialized
INFO - 2018-02-16 15:49:02 --> Language Class Initialized
INFO - 2018-02-16 15:49:02 --> Loader Class Initialized
INFO - 2018-02-16 15:49:02 --> Helper loaded: url_helper
INFO - 2018-02-16 15:49:02 --> Helper loaded: file_helper
INFO - 2018-02-16 15:49:02 --> Helper loaded: email_helper
INFO - 2018-02-16 15:49:02 --> Helper loaded: common_helper
INFO - 2018-02-16 15:49:02 --> Database Driver Class Initialized
DEBUG - 2018-02-16 15:49:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-16 15:49:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-16 15:49:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-16 15:49:02 --> Pagination Class Initialized
INFO - 2018-02-16 15:49:02 --> Helper loaded: form_helper
INFO - 2018-02-16 15:49:02 --> Form Validation Class Initialized
INFO - 2018-02-16 15:49:02 --> Model Class Initialized
INFO - 2018-02-16 15:49:02 --> Controller Class Initialized
INFO - 2018-02-16 15:49:02 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-16 15:49:02 --> Model Class Initialized
INFO - 2018-02-16 15:49:02 --> Model Class Initialized
INFO - 2018-02-16 15:49:02 --> Model Class Initialized
INFO - 2018-02-16 15:49:02 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-16 15:49:02 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-16 15:49:02 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-16 15:49:02 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-16 15:49:02 --> File loaded: /var/www/html/project/radio/application/views/tracks/index.php
INFO - 2018-02-16 15:49:02 --> Final output sent to browser
DEBUG - 2018-02-16 15:49:02 --> Total execution time: 0.0084
INFO - 2018-02-16 15:49:03 --> Config Class Initialized
INFO - 2018-02-16 15:49:03 --> Hooks Class Initialized
DEBUG - 2018-02-16 15:49:03 --> UTF-8 Support Enabled
INFO - 2018-02-16 15:49:03 --> Utf8 Class Initialized
INFO - 2018-02-16 15:49:03 --> URI Class Initialized
INFO - 2018-02-16 15:49:03 --> Router Class Initialized
INFO - 2018-02-16 15:49:03 --> Output Class Initialized
INFO - 2018-02-16 15:49:03 --> Security Class Initialized
DEBUG - 2018-02-16 15:49:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-16 15:49:03 --> Input Class Initialized
INFO - 2018-02-16 15:49:03 --> Language Class Initialized
INFO - 2018-02-16 15:49:03 --> Loader Class Initialized
INFO - 2018-02-16 15:49:03 --> Helper loaded: url_helper
INFO - 2018-02-16 15:49:03 --> Helper loaded: file_helper
INFO - 2018-02-16 15:49:03 --> Helper loaded: email_helper
INFO - 2018-02-16 15:49:03 --> Helper loaded: common_helper
INFO - 2018-02-16 15:49:03 --> Database Driver Class Initialized
DEBUG - 2018-02-16 15:49:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-16 15:49:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-16 15:49:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-16 15:49:03 --> Pagination Class Initialized
INFO - 2018-02-16 15:49:03 --> Helper loaded: form_helper
INFO - 2018-02-16 15:49:03 --> Form Validation Class Initialized
INFO - 2018-02-16 15:49:03 --> Model Class Initialized
INFO - 2018-02-16 15:49:03 --> Controller Class Initialized
INFO - 2018-02-16 15:49:03 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-16 15:49:03 --> Model Class Initialized
INFO - 2018-02-16 15:49:03 --> Model Class Initialized
INFO - 2018-02-16 15:49:03 --> Model Class Initialized
INFO - 2018-02-16 15:49:04 --> Config Class Initialized
INFO - 2018-02-16 15:49:04 --> Hooks Class Initialized
DEBUG - 2018-02-16 15:49:04 --> UTF-8 Support Enabled
INFO - 2018-02-16 15:49:04 --> Utf8 Class Initialized
INFO - 2018-02-16 15:49:04 --> URI Class Initialized
INFO - 2018-02-16 15:49:04 --> Router Class Initialized
INFO - 2018-02-16 15:49:04 --> Output Class Initialized
INFO - 2018-02-16 15:49:04 --> Security Class Initialized
DEBUG - 2018-02-16 15:49:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-16 15:49:04 --> Input Class Initialized
INFO - 2018-02-16 15:49:04 --> Language Class Initialized
INFO - 2018-02-16 15:49:04 --> Loader Class Initialized
INFO - 2018-02-16 15:49:04 --> Helper loaded: url_helper
INFO - 2018-02-16 15:49:04 --> Helper loaded: file_helper
INFO - 2018-02-16 15:49:04 --> Helper loaded: email_helper
INFO - 2018-02-16 15:49:04 --> Helper loaded: common_helper
INFO - 2018-02-16 15:49:04 --> Database Driver Class Initialized
DEBUG - 2018-02-16 15:49:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-16 15:49:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-16 15:49:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-16 15:49:04 --> Pagination Class Initialized
INFO - 2018-02-16 15:49:04 --> Helper loaded: form_helper
INFO - 2018-02-16 15:49:04 --> Form Validation Class Initialized
INFO - 2018-02-16 15:49:04 --> Model Class Initialized
INFO - 2018-02-16 15:49:04 --> Controller Class Initialized
INFO - 2018-02-16 15:49:04 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-16 15:49:04 --> Model Class Initialized
INFO - 2018-02-16 15:49:04 --> Model Class Initialized
INFO - 2018-02-16 15:49:04 --> Model Class Initialized
INFO - 2018-02-16 15:49:04 --> Config Class Initialized
INFO - 2018-02-16 15:49:04 --> Hooks Class Initialized
DEBUG - 2018-02-16 15:49:04 --> UTF-8 Support Enabled
INFO - 2018-02-16 15:49:04 --> Utf8 Class Initialized
INFO - 2018-02-16 15:49:04 --> URI Class Initialized
INFO - 2018-02-16 15:49:04 --> Router Class Initialized
INFO - 2018-02-16 15:49:04 --> Output Class Initialized
INFO - 2018-02-16 15:49:04 --> Security Class Initialized
DEBUG - 2018-02-16 15:49:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-16 15:49:04 --> Input Class Initialized
INFO - 2018-02-16 15:49:04 --> Language Class Initialized
INFO - 2018-02-16 15:49:04 --> Loader Class Initialized
INFO - 2018-02-16 15:49:04 --> Helper loaded: url_helper
INFO - 2018-02-16 15:49:04 --> Helper loaded: file_helper
INFO - 2018-02-16 15:49:04 --> Helper loaded: email_helper
INFO - 2018-02-16 15:49:04 --> Helper loaded: common_helper
INFO - 2018-02-16 15:49:04 --> Database Driver Class Initialized
DEBUG - 2018-02-16 15:49:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-16 15:49:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-16 15:49:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-16 15:49:04 --> Pagination Class Initialized
INFO - 2018-02-16 15:49:04 --> Helper loaded: form_helper
INFO - 2018-02-16 15:49:04 --> Form Validation Class Initialized
INFO - 2018-02-16 15:49:04 --> Model Class Initialized
INFO - 2018-02-16 15:49:04 --> Controller Class Initialized
INFO - 2018-02-16 15:49:04 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-16 15:49:04 --> Model Class Initialized
INFO - 2018-02-16 15:49:04 --> Model Class Initialized
INFO - 2018-02-16 15:49:04 --> Model Class Initialized
INFO - 2018-02-16 15:49:05 --> Config Class Initialized
INFO - 2018-02-16 15:49:05 --> Hooks Class Initialized
DEBUG - 2018-02-16 15:49:05 --> UTF-8 Support Enabled
INFO - 2018-02-16 15:49:05 --> Utf8 Class Initialized
INFO - 2018-02-16 15:49:05 --> URI Class Initialized
INFO - 2018-02-16 15:49:05 --> Router Class Initialized
INFO - 2018-02-16 15:49:05 --> Output Class Initialized
INFO - 2018-02-16 15:49:05 --> Security Class Initialized
DEBUG - 2018-02-16 15:49:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-16 15:49:05 --> Input Class Initialized
INFO - 2018-02-16 15:49:05 --> Language Class Initialized
INFO - 2018-02-16 15:49:05 --> Loader Class Initialized
INFO - 2018-02-16 15:49:05 --> Helper loaded: url_helper
INFO - 2018-02-16 15:49:05 --> Helper loaded: file_helper
INFO - 2018-02-16 15:49:05 --> Helper loaded: email_helper
INFO - 2018-02-16 15:49:05 --> Helper loaded: common_helper
INFO - 2018-02-16 15:49:05 --> Database Driver Class Initialized
DEBUG - 2018-02-16 15:49:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-16 15:49:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-16 15:49:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-16 15:49:05 --> Pagination Class Initialized
INFO - 2018-02-16 15:49:05 --> Helper loaded: form_helper
INFO - 2018-02-16 15:49:05 --> Form Validation Class Initialized
INFO - 2018-02-16 15:49:05 --> Model Class Initialized
INFO - 2018-02-16 15:49:05 --> Controller Class Initialized
INFO - 2018-02-16 15:49:05 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-16 15:49:05 --> Model Class Initialized
INFO - 2018-02-16 15:49:05 --> Model Class Initialized
INFO - 2018-02-16 15:49:05 --> Model Class Initialized
INFO - 2018-02-16 15:49:05 --> Config Class Initialized
INFO - 2018-02-16 15:49:05 --> Hooks Class Initialized
DEBUG - 2018-02-16 15:49:05 --> UTF-8 Support Enabled
INFO - 2018-02-16 15:49:05 --> Utf8 Class Initialized
INFO - 2018-02-16 15:49:05 --> URI Class Initialized
INFO - 2018-02-16 15:49:05 --> Router Class Initialized
INFO - 2018-02-16 15:49:05 --> Output Class Initialized
INFO - 2018-02-16 15:49:05 --> Security Class Initialized
DEBUG - 2018-02-16 15:49:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-16 15:49:05 --> Input Class Initialized
INFO - 2018-02-16 15:49:05 --> Language Class Initialized
INFO - 2018-02-16 15:49:05 --> Loader Class Initialized
INFO - 2018-02-16 15:49:05 --> Helper loaded: url_helper
INFO - 2018-02-16 15:49:05 --> Helper loaded: file_helper
INFO - 2018-02-16 15:49:05 --> Helper loaded: email_helper
INFO - 2018-02-16 15:49:05 --> Helper loaded: common_helper
INFO - 2018-02-16 15:49:05 --> Database Driver Class Initialized
DEBUG - 2018-02-16 15:49:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-16 15:49:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-16 15:49:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-16 15:49:05 --> Pagination Class Initialized
INFO - 2018-02-16 15:49:05 --> Helper loaded: form_helper
INFO - 2018-02-16 15:49:05 --> Form Validation Class Initialized
INFO - 2018-02-16 15:49:05 --> Model Class Initialized
INFO - 2018-02-16 15:49:05 --> Controller Class Initialized
INFO - 2018-02-16 15:49:05 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-16 15:49:05 --> Model Class Initialized
INFO - 2018-02-16 15:49:05 --> Model Class Initialized
INFO - 2018-02-16 15:49:05 --> Model Class Initialized
INFO - 2018-02-16 15:49:12 --> Config Class Initialized
INFO - 2018-02-16 15:49:12 --> Hooks Class Initialized
DEBUG - 2018-02-16 15:49:12 --> UTF-8 Support Enabled
INFO - 2018-02-16 15:49:12 --> Utf8 Class Initialized
INFO - 2018-02-16 15:49:12 --> URI Class Initialized
INFO - 2018-02-16 15:49:12 --> Router Class Initialized
INFO - 2018-02-16 15:49:12 --> Output Class Initialized
INFO - 2018-02-16 15:49:12 --> Security Class Initialized
DEBUG - 2018-02-16 15:49:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-16 15:49:12 --> Input Class Initialized
INFO - 2018-02-16 15:49:12 --> Language Class Initialized
INFO - 2018-02-16 15:49:12 --> Loader Class Initialized
INFO - 2018-02-16 15:49:12 --> Helper loaded: url_helper
INFO - 2018-02-16 15:49:12 --> Helper loaded: file_helper
INFO - 2018-02-16 15:49:12 --> Helper loaded: email_helper
INFO - 2018-02-16 15:49:12 --> Helper loaded: common_helper
INFO - 2018-02-16 15:49:12 --> Database Driver Class Initialized
DEBUG - 2018-02-16 15:49:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-16 15:49:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-16 15:49:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-16 15:49:12 --> Pagination Class Initialized
INFO - 2018-02-16 15:49:12 --> Helper loaded: form_helper
INFO - 2018-02-16 15:49:12 --> Form Validation Class Initialized
INFO - 2018-02-16 15:49:12 --> Model Class Initialized
INFO - 2018-02-16 15:49:12 --> Controller Class Initialized
INFO - 2018-02-16 15:49:12 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-16 15:49:12 --> Model Class Initialized
INFO - 2018-02-16 15:49:12 --> Model Class Initialized
INFO - 2018-02-16 15:49:12 --> Model Class Initialized
INFO - 2018-02-16 15:49:12 --> Config Class Initialized
INFO - 2018-02-16 15:49:12 --> Hooks Class Initialized
DEBUG - 2018-02-16 15:49:12 --> UTF-8 Support Enabled
INFO - 2018-02-16 15:49:12 --> Utf8 Class Initialized
INFO - 2018-02-16 15:49:12 --> URI Class Initialized
INFO - 2018-02-16 15:49:12 --> Router Class Initialized
INFO - 2018-02-16 15:49:12 --> Output Class Initialized
INFO - 2018-02-16 15:49:12 --> Security Class Initialized
DEBUG - 2018-02-16 15:49:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-16 15:49:12 --> Input Class Initialized
INFO - 2018-02-16 15:49:12 --> Language Class Initialized
INFO - 2018-02-16 15:49:12 --> Loader Class Initialized
INFO - 2018-02-16 15:49:12 --> Helper loaded: url_helper
INFO - 2018-02-16 15:49:12 --> Helper loaded: file_helper
INFO - 2018-02-16 15:49:12 --> Helper loaded: email_helper
INFO - 2018-02-16 15:49:12 --> Helper loaded: common_helper
INFO - 2018-02-16 15:49:12 --> Database Driver Class Initialized
DEBUG - 2018-02-16 15:49:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-16 15:49:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-16 15:49:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-16 15:49:12 --> Pagination Class Initialized
INFO - 2018-02-16 15:49:12 --> Helper loaded: form_helper
INFO - 2018-02-16 15:49:12 --> Form Validation Class Initialized
INFO - 2018-02-16 15:49:12 --> Model Class Initialized
INFO - 2018-02-16 15:49:12 --> Controller Class Initialized
INFO - 2018-02-16 15:49:12 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-16 15:49:12 --> Model Class Initialized
INFO - 2018-02-16 15:49:12 --> Model Class Initialized
INFO - 2018-02-16 15:49:12 --> Model Class Initialized
INFO - 2018-02-16 15:49:13 --> Config Class Initialized
INFO - 2018-02-16 15:49:13 --> Hooks Class Initialized
DEBUG - 2018-02-16 15:49:13 --> UTF-8 Support Enabled
INFO - 2018-02-16 15:49:13 --> Utf8 Class Initialized
INFO - 2018-02-16 15:49:13 --> URI Class Initialized
INFO - 2018-02-16 15:49:13 --> Router Class Initialized
INFO - 2018-02-16 15:49:13 --> Output Class Initialized
INFO - 2018-02-16 15:49:13 --> Security Class Initialized
DEBUG - 2018-02-16 15:49:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-16 15:49:13 --> Input Class Initialized
INFO - 2018-02-16 15:49:13 --> Language Class Initialized
INFO - 2018-02-16 15:49:13 --> Loader Class Initialized
INFO - 2018-02-16 15:49:13 --> Helper loaded: url_helper
INFO - 2018-02-16 15:49:13 --> Helper loaded: file_helper
INFO - 2018-02-16 15:49:13 --> Helper loaded: email_helper
INFO - 2018-02-16 15:49:13 --> Helper loaded: common_helper
INFO - 2018-02-16 15:49:13 --> Database Driver Class Initialized
DEBUG - 2018-02-16 15:49:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-16 15:49:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-16 15:49:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-16 15:49:13 --> Pagination Class Initialized
INFO - 2018-02-16 15:49:13 --> Helper loaded: form_helper
INFO - 2018-02-16 15:49:13 --> Form Validation Class Initialized
INFO - 2018-02-16 15:49:13 --> Model Class Initialized
INFO - 2018-02-16 15:49:13 --> Controller Class Initialized
INFO - 2018-02-16 15:49:13 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-16 15:49:13 --> Model Class Initialized
INFO - 2018-02-16 15:49:13 --> Model Class Initialized
INFO - 2018-02-16 15:49:13 --> Model Class Initialized
INFO - 2018-02-16 15:49:13 --> Config Class Initialized
INFO - 2018-02-16 15:49:13 --> Hooks Class Initialized
DEBUG - 2018-02-16 15:49:13 --> UTF-8 Support Enabled
INFO - 2018-02-16 15:49:13 --> Utf8 Class Initialized
INFO - 2018-02-16 15:49:13 --> URI Class Initialized
INFO - 2018-02-16 15:49:13 --> Router Class Initialized
INFO - 2018-02-16 15:49:13 --> Output Class Initialized
INFO - 2018-02-16 15:49:13 --> Security Class Initialized
DEBUG - 2018-02-16 15:49:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-16 15:49:13 --> Input Class Initialized
INFO - 2018-02-16 15:49:13 --> Language Class Initialized
INFO - 2018-02-16 15:49:13 --> Loader Class Initialized
INFO - 2018-02-16 15:49:13 --> Helper loaded: url_helper
INFO - 2018-02-16 15:49:13 --> Helper loaded: file_helper
INFO - 2018-02-16 15:49:13 --> Helper loaded: email_helper
INFO - 2018-02-16 15:49:13 --> Helper loaded: common_helper
INFO - 2018-02-16 15:49:13 --> Database Driver Class Initialized
DEBUG - 2018-02-16 15:49:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-16 15:49:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-16 15:49:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-16 15:49:13 --> Pagination Class Initialized
INFO - 2018-02-16 15:49:13 --> Helper loaded: form_helper
INFO - 2018-02-16 15:49:13 --> Form Validation Class Initialized
INFO - 2018-02-16 15:49:13 --> Model Class Initialized
INFO - 2018-02-16 15:49:13 --> Controller Class Initialized
INFO - 2018-02-16 15:49:13 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-16 15:49:13 --> Model Class Initialized
INFO - 2018-02-16 15:49:13 --> Model Class Initialized
INFO - 2018-02-16 15:49:13 --> Model Class Initialized
INFO - 2018-02-16 15:49:14 --> Config Class Initialized
INFO - 2018-02-16 15:49:14 --> Hooks Class Initialized
DEBUG - 2018-02-16 15:49:14 --> UTF-8 Support Enabled
INFO - 2018-02-16 15:49:14 --> Utf8 Class Initialized
INFO - 2018-02-16 15:49:14 --> URI Class Initialized
INFO - 2018-02-16 15:49:14 --> Router Class Initialized
INFO - 2018-02-16 15:49:14 --> Output Class Initialized
INFO - 2018-02-16 15:49:14 --> Security Class Initialized
DEBUG - 2018-02-16 15:49:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-16 15:49:14 --> Input Class Initialized
INFO - 2018-02-16 15:49:14 --> Language Class Initialized
INFO - 2018-02-16 15:49:14 --> Loader Class Initialized
INFO - 2018-02-16 15:49:14 --> Helper loaded: url_helper
INFO - 2018-02-16 15:49:14 --> Helper loaded: file_helper
INFO - 2018-02-16 15:49:14 --> Helper loaded: email_helper
INFO - 2018-02-16 15:49:14 --> Helper loaded: common_helper
INFO - 2018-02-16 15:49:14 --> Database Driver Class Initialized
DEBUG - 2018-02-16 15:49:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-16 15:49:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-16 15:49:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-16 15:49:14 --> Pagination Class Initialized
INFO - 2018-02-16 15:49:14 --> Helper loaded: form_helper
INFO - 2018-02-16 15:49:14 --> Form Validation Class Initialized
INFO - 2018-02-16 15:49:14 --> Model Class Initialized
INFO - 2018-02-16 15:49:14 --> Controller Class Initialized
INFO - 2018-02-16 15:49:14 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-16 15:49:14 --> Model Class Initialized
INFO - 2018-02-16 15:49:14 --> Model Class Initialized
INFO - 2018-02-16 15:49:14 --> Model Class Initialized
INFO - 2018-02-16 15:49:14 --> Config Class Initialized
INFO - 2018-02-16 15:49:14 --> Hooks Class Initialized
DEBUG - 2018-02-16 15:49:14 --> UTF-8 Support Enabled
INFO - 2018-02-16 15:49:14 --> Utf8 Class Initialized
INFO - 2018-02-16 15:49:14 --> URI Class Initialized
INFO - 2018-02-16 15:49:14 --> Router Class Initialized
INFO - 2018-02-16 15:49:14 --> Output Class Initialized
INFO - 2018-02-16 15:49:14 --> Security Class Initialized
DEBUG - 2018-02-16 15:49:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-16 15:49:14 --> Input Class Initialized
INFO - 2018-02-16 15:49:14 --> Language Class Initialized
INFO - 2018-02-16 15:49:14 --> Loader Class Initialized
INFO - 2018-02-16 15:49:14 --> Helper loaded: url_helper
INFO - 2018-02-16 15:49:14 --> Helper loaded: file_helper
INFO - 2018-02-16 15:49:14 --> Helper loaded: email_helper
INFO - 2018-02-16 15:49:14 --> Helper loaded: common_helper
INFO - 2018-02-16 15:49:14 --> Database Driver Class Initialized
DEBUG - 2018-02-16 15:49:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-16 15:49:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-16 15:49:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-16 15:49:14 --> Pagination Class Initialized
INFO - 2018-02-16 15:49:14 --> Helper loaded: form_helper
INFO - 2018-02-16 15:49:14 --> Form Validation Class Initialized
INFO - 2018-02-16 15:49:14 --> Model Class Initialized
INFO - 2018-02-16 15:49:14 --> Controller Class Initialized
INFO - 2018-02-16 15:49:14 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-16 15:49:14 --> Model Class Initialized
INFO - 2018-02-16 15:49:14 --> Model Class Initialized
INFO - 2018-02-16 15:49:14 --> Model Class Initialized
INFO - 2018-02-16 15:49:15 --> Config Class Initialized
INFO - 2018-02-16 15:49:15 --> Hooks Class Initialized
DEBUG - 2018-02-16 15:49:15 --> UTF-8 Support Enabled
INFO - 2018-02-16 15:49:15 --> Utf8 Class Initialized
INFO - 2018-02-16 15:49:15 --> URI Class Initialized
INFO - 2018-02-16 15:49:15 --> Router Class Initialized
INFO - 2018-02-16 15:49:15 --> Output Class Initialized
INFO - 2018-02-16 15:49:15 --> Security Class Initialized
DEBUG - 2018-02-16 15:49:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-16 15:49:15 --> Input Class Initialized
INFO - 2018-02-16 15:49:15 --> Language Class Initialized
INFO - 2018-02-16 15:49:15 --> Loader Class Initialized
INFO - 2018-02-16 15:49:15 --> Helper loaded: url_helper
INFO - 2018-02-16 15:49:15 --> Helper loaded: file_helper
INFO - 2018-02-16 15:49:15 --> Helper loaded: email_helper
INFO - 2018-02-16 15:49:15 --> Helper loaded: common_helper
INFO - 2018-02-16 15:49:15 --> Database Driver Class Initialized
DEBUG - 2018-02-16 15:49:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-16 15:49:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-16 15:49:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-16 15:49:15 --> Pagination Class Initialized
INFO - 2018-02-16 15:49:15 --> Helper loaded: form_helper
INFO - 2018-02-16 15:49:15 --> Form Validation Class Initialized
INFO - 2018-02-16 15:49:15 --> Model Class Initialized
INFO - 2018-02-16 15:49:15 --> Controller Class Initialized
INFO - 2018-02-16 15:49:15 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-16 15:49:15 --> Model Class Initialized
INFO - 2018-02-16 15:49:15 --> Model Class Initialized
INFO - 2018-02-16 15:49:15 --> Model Class Initialized
INFO - 2018-02-16 15:49:15 --> Config Class Initialized
INFO - 2018-02-16 15:49:15 --> Hooks Class Initialized
DEBUG - 2018-02-16 15:49:15 --> UTF-8 Support Enabled
INFO - 2018-02-16 15:49:15 --> Utf8 Class Initialized
INFO - 2018-02-16 15:49:15 --> URI Class Initialized
INFO - 2018-02-16 15:49:15 --> Router Class Initialized
INFO - 2018-02-16 15:49:15 --> Output Class Initialized
INFO - 2018-02-16 15:49:15 --> Security Class Initialized
DEBUG - 2018-02-16 15:49:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-16 15:49:15 --> Input Class Initialized
INFO - 2018-02-16 15:49:15 --> Language Class Initialized
INFO - 2018-02-16 15:49:15 --> Loader Class Initialized
INFO - 2018-02-16 15:49:15 --> Helper loaded: url_helper
INFO - 2018-02-16 15:49:15 --> Helper loaded: file_helper
INFO - 2018-02-16 15:49:15 --> Helper loaded: email_helper
INFO - 2018-02-16 15:49:15 --> Helper loaded: common_helper
INFO - 2018-02-16 15:49:15 --> Database Driver Class Initialized
DEBUG - 2018-02-16 15:49:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-16 15:49:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-16 15:49:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-16 15:49:15 --> Pagination Class Initialized
INFO - 2018-02-16 15:49:15 --> Helper loaded: form_helper
INFO - 2018-02-16 15:49:15 --> Form Validation Class Initialized
INFO - 2018-02-16 15:49:15 --> Model Class Initialized
INFO - 2018-02-16 15:49:15 --> Controller Class Initialized
INFO - 2018-02-16 15:49:15 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-16 15:49:15 --> Model Class Initialized
INFO - 2018-02-16 15:49:15 --> Model Class Initialized
INFO - 2018-02-16 15:49:15 --> Model Class Initialized
INFO - 2018-02-16 15:49:18 --> Config Class Initialized
INFO - 2018-02-16 15:49:18 --> Hooks Class Initialized
DEBUG - 2018-02-16 15:49:18 --> UTF-8 Support Enabled
INFO - 2018-02-16 15:49:18 --> Utf8 Class Initialized
INFO - 2018-02-16 15:49:18 --> URI Class Initialized
INFO - 2018-02-16 15:49:18 --> Router Class Initialized
INFO - 2018-02-16 15:49:18 --> Output Class Initialized
INFO - 2018-02-16 15:49:18 --> Security Class Initialized
DEBUG - 2018-02-16 15:49:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-16 15:49:18 --> Input Class Initialized
INFO - 2018-02-16 15:49:18 --> Language Class Initialized
INFO - 2018-02-16 15:49:18 --> Loader Class Initialized
INFO - 2018-02-16 15:49:18 --> Helper loaded: url_helper
INFO - 2018-02-16 15:49:18 --> Helper loaded: file_helper
INFO - 2018-02-16 15:49:18 --> Helper loaded: email_helper
INFO - 2018-02-16 15:49:18 --> Helper loaded: common_helper
INFO - 2018-02-16 15:49:18 --> Database Driver Class Initialized
DEBUG - 2018-02-16 15:49:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-16 15:49:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-16 15:49:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-16 15:49:18 --> Pagination Class Initialized
INFO - 2018-02-16 15:49:18 --> Helper loaded: form_helper
INFO - 2018-02-16 15:49:18 --> Form Validation Class Initialized
INFO - 2018-02-16 15:49:18 --> Model Class Initialized
INFO - 2018-02-16 15:49:18 --> Controller Class Initialized
INFO - 2018-02-16 15:49:18 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-16 15:49:18 --> Model Class Initialized
INFO - 2018-02-16 15:49:18 --> Model Class Initialized
INFO - 2018-02-16 15:49:18 --> Model Class Initialized
INFO - 2018-02-16 15:49:18 --> Config Class Initialized
INFO - 2018-02-16 15:49:18 --> Hooks Class Initialized
DEBUG - 2018-02-16 15:49:18 --> UTF-8 Support Enabled
INFO - 2018-02-16 15:49:18 --> Utf8 Class Initialized
INFO - 2018-02-16 15:49:18 --> URI Class Initialized
INFO - 2018-02-16 15:49:18 --> Router Class Initialized
INFO - 2018-02-16 15:49:18 --> Output Class Initialized
INFO - 2018-02-16 15:49:18 --> Security Class Initialized
DEBUG - 2018-02-16 15:49:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-16 15:49:18 --> Input Class Initialized
INFO - 2018-02-16 15:49:18 --> Language Class Initialized
INFO - 2018-02-16 15:49:18 --> Loader Class Initialized
INFO - 2018-02-16 15:49:18 --> Helper loaded: url_helper
INFO - 2018-02-16 15:49:18 --> Helper loaded: file_helper
INFO - 2018-02-16 15:49:18 --> Helper loaded: email_helper
INFO - 2018-02-16 15:49:18 --> Helper loaded: common_helper
INFO - 2018-02-16 15:49:18 --> Database Driver Class Initialized
DEBUG - 2018-02-16 15:49:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-16 15:49:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-16 15:49:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-16 15:49:18 --> Pagination Class Initialized
INFO - 2018-02-16 15:49:18 --> Helper loaded: form_helper
INFO - 2018-02-16 15:49:18 --> Form Validation Class Initialized
INFO - 2018-02-16 15:49:18 --> Model Class Initialized
INFO - 2018-02-16 15:49:18 --> Controller Class Initialized
INFO - 2018-02-16 15:49:18 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-16 15:49:18 --> Model Class Initialized
INFO - 2018-02-16 15:49:18 --> Model Class Initialized
INFO - 2018-02-16 15:49:18 --> Model Class Initialized
INFO - 2018-02-16 15:49:18 --> Config Class Initialized
INFO - 2018-02-16 15:49:18 --> Hooks Class Initialized
DEBUG - 2018-02-16 15:49:18 --> UTF-8 Support Enabled
INFO - 2018-02-16 15:49:18 --> Utf8 Class Initialized
INFO - 2018-02-16 15:49:18 --> URI Class Initialized
INFO - 2018-02-16 15:49:18 --> Router Class Initialized
INFO - 2018-02-16 15:49:18 --> Output Class Initialized
INFO - 2018-02-16 15:49:18 --> Security Class Initialized
DEBUG - 2018-02-16 15:49:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-16 15:49:18 --> Input Class Initialized
INFO - 2018-02-16 15:49:18 --> Language Class Initialized
INFO - 2018-02-16 15:49:18 --> Loader Class Initialized
INFO - 2018-02-16 15:49:18 --> Helper loaded: url_helper
INFO - 2018-02-16 15:49:18 --> Helper loaded: file_helper
INFO - 2018-02-16 15:49:18 --> Helper loaded: email_helper
INFO - 2018-02-16 15:49:18 --> Helper loaded: common_helper
INFO - 2018-02-16 15:49:18 --> Database Driver Class Initialized
DEBUG - 2018-02-16 15:49:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-16 15:49:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-16 15:49:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-16 15:49:18 --> Pagination Class Initialized
INFO - 2018-02-16 15:49:18 --> Helper loaded: form_helper
INFO - 2018-02-16 15:49:18 --> Form Validation Class Initialized
INFO - 2018-02-16 15:49:18 --> Model Class Initialized
INFO - 2018-02-16 15:49:18 --> Controller Class Initialized
INFO - 2018-02-16 15:49:18 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-16 15:49:18 --> Model Class Initialized
INFO - 2018-02-16 15:49:18 --> Model Class Initialized
INFO - 2018-02-16 15:49:18 --> Model Class Initialized
INFO - 2018-02-16 15:49:18 --> Config Class Initialized
INFO - 2018-02-16 15:49:18 --> Hooks Class Initialized
DEBUG - 2018-02-16 15:49:18 --> UTF-8 Support Enabled
INFO - 2018-02-16 15:49:18 --> Utf8 Class Initialized
INFO - 2018-02-16 15:49:18 --> URI Class Initialized
INFO - 2018-02-16 15:49:18 --> Router Class Initialized
INFO - 2018-02-16 15:49:18 --> Output Class Initialized
INFO - 2018-02-16 15:49:18 --> Security Class Initialized
DEBUG - 2018-02-16 15:49:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-16 15:49:18 --> Input Class Initialized
INFO - 2018-02-16 15:49:18 --> Language Class Initialized
INFO - 2018-02-16 15:49:18 --> Loader Class Initialized
INFO - 2018-02-16 15:49:18 --> Helper loaded: url_helper
INFO - 2018-02-16 15:49:18 --> Helper loaded: file_helper
INFO - 2018-02-16 15:49:18 --> Helper loaded: email_helper
INFO - 2018-02-16 15:49:18 --> Helper loaded: common_helper
INFO - 2018-02-16 15:49:18 --> Database Driver Class Initialized
DEBUG - 2018-02-16 15:49:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-16 15:49:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-16 15:49:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-16 15:49:18 --> Pagination Class Initialized
INFO - 2018-02-16 15:49:18 --> Helper loaded: form_helper
INFO - 2018-02-16 15:49:18 --> Form Validation Class Initialized
INFO - 2018-02-16 15:49:18 --> Model Class Initialized
INFO - 2018-02-16 15:49:18 --> Controller Class Initialized
INFO - 2018-02-16 15:49:18 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-16 15:49:18 --> Model Class Initialized
INFO - 2018-02-16 15:49:18 --> Model Class Initialized
INFO - 2018-02-16 15:49:18 --> Model Class Initialized
INFO - 2018-02-16 15:49:25 --> Config Class Initialized
INFO - 2018-02-16 15:49:25 --> Hooks Class Initialized
DEBUG - 2018-02-16 15:49:25 --> UTF-8 Support Enabled
INFO - 2018-02-16 15:49:25 --> Utf8 Class Initialized
INFO - 2018-02-16 15:49:25 --> URI Class Initialized
INFO - 2018-02-16 15:49:25 --> Router Class Initialized
INFO - 2018-02-16 15:49:25 --> Output Class Initialized
INFO - 2018-02-16 15:49:25 --> Security Class Initialized
DEBUG - 2018-02-16 15:49:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-16 15:49:25 --> Input Class Initialized
INFO - 2018-02-16 15:49:25 --> Language Class Initialized
INFO - 2018-02-16 15:49:25 --> Loader Class Initialized
INFO - 2018-02-16 15:49:25 --> Helper loaded: url_helper
INFO - 2018-02-16 15:49:25 --> Helper loaded: file_helper
INFO - 2018-02-16 15:49:25 --> Helper loaded: email_helper
INFO - 2018-02-16 15:49:25 --> Helper loaded: common_helper
INFO - 2018-02-16 15:49:25 --> Database Driver Class Initialized
DEBUG - 2018-02-16 15:49:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-16 15:49:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-16 15:49:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-16 15:49:25 --> Pagination Class Initialized
INFO - 2018-02-16 15:49:25 --> Helper loaded: form_helper
INFO - 2018-02-16 15:49:25 --> Form Validation Class Initialized
INFO - 2018-02-16 15:49:25 --> Model Class Initialized
INFO - 2018-02-16 15:49:25 --> Controller Class Initialized
INFO - 2018-02-16 15:49:25 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-16 15:49:25 --> Model Class Initialized
INFO - 2018-02-16 15:49:25 --> Model Class Initialized
INFO - 2018-02-16 15:49:25 --> Model Class Initialized
INFO - 2018-02-16 15:49:25 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-16 15:49:25 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-16 15:49:25 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-16 15:49:25 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-16 15:49:25 --> File loaded: /var/www/html/project/radio/application/views/tracks/add_edit.php
INFO - 2018-02-16 15:49:25 --> Final output sent to browser
DEBUG - 2018-02-16 15:49:25 --> Total execution time: 0.0057
INFO - 2018-02-16 15:49:26 --> Config Class Initialized
INFO - 2018-02-16 15:49:26 --> Hooks Class Initialized
DEBUG - 2018-02-16 15:49:26 --> UTF-8 Support Enabled
INFO - 2018-02-16 15:49:26 --> Utf8 Class Initialized
INFO - 2018-02-16 15:49:26 --> URI Class Initialized
INFO - 2018-02-16 15:49:26 --> Router Class Initialized
INFO - 2018-02-16 15:49:26 --> Output Class Initialized
INFO - 2018-02-16 15:49:26 --> Security Class Initialized
DEBUG - 2018-02-16 15:49:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-16 15:49:26 --> Input Class Initialized
INFO - 2018-02-16 15:49:26 --> Language Class Initialized
INFO - 2018-02-16 15:49:26 --> Loader Class Initialized
INFO - 2018-02-16 15:49:26 --> Helper loaded: url_helper
INFO - 2018-02-16 15:49:26 --> Helper loaded: file_helper
INFO - 2018-02-16 15:49:26 --> Helper loaded: email_helper
INFO - 2018-02-16 15:49:26 --> Helper loaded: common_helper
INFO - 2018-02-16 15:49:26 --> Database Driver Class Initialized
DEBUG - 2018-02-16 15:49:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-16 15:49:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-16 15:49:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-16 15:49:27 --> Pagination Class Initialized
INFO - 2018-02-16 15:49:27 --> Helper loaded: form_helper
INFO - 2018-02-16 15:49:27 --> Form Validation Class Initialized
INFO - 2018-02-16 15:49:27 --> Model Class Initialized
INFO - 2018-02-16 15:49:27 --> Controller Class Initialized
INFO - 2018-02-16 15:49:27 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-16 15:49:27 --> Model Class Initialized
INFO - 2018-02-16 15:49:27 --> Model Class Initialized
INFO - 2018-02-16 15:49:27 --> Model Class Initialized
INFO - 2018-02-16 15:49:29 --> Config Class Initialized
INFO - 2018-02-16 15:49:29 --> Hooks Class Initialized
DEBUG - 2018-02-16 15:49:29 --> UTF-8 Support Enabled
INFO - 2018-02-16 15:49:29 --> Utf8 Class Initialized
INFO - 2018-02-16 15:49:29 --> URI Class Initialized
INFO - 2018-02-16 15:49:29 --> Router Class Initialized
INFO - 2018-02-16 15:49:29 --> Output Class Initialized
INFO - 2018-02-16 15:49:29 --> Security Class Initialized
DEBUG - 2018-02-16 15:49:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-16 15:49:29 --> Input Class Initialized
INFO - 2018-02-16 15:49:29 --> Language Class Initialized
INFO - 2018-02-16 15:49:29 --> Loader Class Initialized
INFO - 2018-02-16 15:49:29 --> Helper loaded: url_helper
INFO - 2018-02-16 15:49:29 --> Helper loaded: file_helper
INFO - 2018-02-16 15:49:29 --> Helper loaded: email_helper
INFO - 2018-02-16 15:49:29 --> Helper loaded: common_helper
INFO - 2018-02-16 15:49:29 --> Database Driver Class Initialized
DEBUG - 2018-02-16 15:49:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-16 15:49:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-16 15:49:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-16 15:49:29 --> Pagination Class Initialized
INFO - 2018-02-16 15:49:29 --> Helper loaded: form_helper
INFO - 2018-02-16 15:49:29 --> Form Validation Class Initialized
INFO - 2018-02-16 15:49:29 --> Model Class Initialized
INFO - 2018-02-16 15:49:29 --> Controller Class Initialized
INFO - 2018-02-16 15:49:29 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-16 15:49:29 --> Model Class Initialized
INFO - 2018-02-16 15:49:29 --> Model Class Initialized
INFO - 2018-02-16 15:49:29 --> Model Class Initialized
INFO - 2018-02-16 15:49:31 --> Config Class Initialized
INFO - 2018-02-16 15:49:31 --> Hooks Class Initialized
DEBUG - 2018-02-16 15:49:31 --> UTF-8 Support Enabled
INFO - 2018-02-16 15:49:31 --> Utf8 Class Initialized
INFO - 2018-02-16 15:49:31 --> URI Class Initialized
INFO - 2018-02-16 15:49:31 --> Router Class Initialized
INFO - 2018-02-16 15:49:31 --> Output Class Initialized
INFO - 2018-02-16 15:49:31 --> Security Class Initialized
DEBUG - 2018-02-16 15:49:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-16 15:49:31 --> Input Class Initialized
INFO - 2018-02-16 15:49:31 --> Language Class Initialized
INFO - 2018-02-16 15:49:31 --> Loader Class Initialized
INFO - 2018-02-16 15:49:31 --> Helper loaded: url_helper
INFO - 2018-02-16 15:49:31 --> Helper loaded: file_helper
INFO - 2018-02-16 15:49:31 --> Helper loaded: email_helper
INFO - 2018-02-16 15:49:31 --> Helper loaded: common_helper
INFO - 2018-02-16 15:49:31 --> Database Driver Class Initialized
DEBUG - 2018-02-16 15:49:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-16 15:49:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-16 15:49:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-16 15:49:31 --> Pagination Class Initialized
INFO - 2018-02-16 15:49:31 --> Helper loaded: form_helper
INFO - 2018-02-16 15:49:31 --> Form Validation Class Initialized
INFO - 2018-02-16 15:49:31 --> Model Class Initialized
INFO - 2018-02-16 15:49:31 --> Controller Class Initialized
INFO - 2018-02-16 15:49:31 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-16 15:49:31 --> Model Class Initialized
INFO - 2018-02-16 15:49:31 --> Model Class Initialized
INFO - 2018-02-16 15:49:31 --> Model Class Initialized
INFO - 2018-02-16 15:49:32 --> Config Class Initialized
INFO - 2018-02-16 15:49:32 --> Hooks Class Initialized
DEBUG - 2018-02-16 15:49:32 --> UTF-8 Support Enabled
INFO - 2018-02-16 15:49:32 --> Utf8 Class Initialized
INFO - 2018-02-16 15:49:32 --> URI Class Initialized
INFO - 2018-02-16 15:49:32 --> Router Class Initialized
INFO - 2018-02-16 15:49:32 --> Output Class Initialized
INFO - 2018-02-16 15:49:32 --> Security Class Initialized
DEBUG - 2018-02-16 15:49:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-16 15:49:32 --> Input Class Initialized
INFO - 2018-02-16 15:49:32 --> Language Class Initialized
INFO - 2018-02-16 15:49:32 --> Loader Class Initialized
INFO - 2018-02-16 15:49:32 --> Helper loaded: url_helper
INFO - 2018-02-16 15:49:32 --> Helper loaded: file_helper
INFO - 2018-02-16 15:49:32 --> Helper loaded: email_helper
INFO - 2018-02-16 15:49:32 --> Helper loaded: common_helper
INFO - 2018-02-16 15:49:32 --> Database Driver Class Initialized
DEBUG - 2018-02-16 15:49:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-16 15:49:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-16 15:49:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-16 15:49:32 --> Pagination Class Initialized
INFO - 2018-02-16 15:49:32 --> Helper loaded: form_helper
INFO - 2018-02-16 15:49:32 --> Form Validation Class Initialized
INFO - 2018-02-16 15:49:32 --> Model Class Initialized
INFO - 2018-02-16 15:49:32 --> Controller Class Initialized
INFO - 2018-02-16 15:49:32 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-16 15:49:32 --> Model Class Initialized
INFO - 2018-02-16 15:49:32 --> Model Class Initialized
INFO - 2018-02-16 15:49:32 --> Model Class Initialized
INFO - 2018-02-16 15:49:35 --> Config Class Initialized
INFO - 2018-02-16 15:49:35 --> Hooks Class Initialized
DEBUG - 2018-02-16 15:49:35 --> UTF-8 Support Enabled
INFO - 2018-02-16 15:49:35 --> Utf8 Class Initialized
INFO - 2018-02-16 15:49:35 --> URI Class Initialized
INFO - 2018-02-16 15:49:35 --> Router Class Initialized
INFO - 2018-02-16 15:49:35 --> Output Class Initialized
INFO - 2018-02-16 15:49:35 --> Security Class Initialized
DEBUG - 2018-02-16 15:49:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-16 15:49:35 --> Input Class Initialized
INFO - 2018-02-16 15:49:35 --> Language Class Initialized
INFO - 2018-02-16 15:49:35 --> Loader Class Initialized
INFO - 2018-02-16 15:49:35 --> Helper loaded: url_helper
INFO - 2018-02-16 15:49:35 --> Helper loaded: file_helper
INFO - 2018-02-16 15:49:35 --> Helper loaded: email_helper
INFO - 2018-02-16 15:49:35 --> Helper loaded: common_helper
INFO - 2018-02-16 15:49:35 --> Database Driver Class Initialized
DEBUG - 2018-02-16 15:49:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-16 15:49:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-16 15:49:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-16 15:49:35 --> Pagination Class Initialized
INFO - 2018-02-16 15:49:35 --> Helper loaded: form_helper
INFO - 2018-02-16 15:49:35 --> Form Validation Class Initialized
INFO - 2018-02-16 15:49:35 --> Model Class Initialized
INFO - 2018-02-16 15:49:35 --> Controller Class Initialized
INFO - 2018-02-16 15:49:35 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-16 15:49:35 --> Model Class Initialized
INFO - 2018-02-16 15:49:35 --> Model Class Initialized
INFO - 2018-02-16 15:49:35 --> Model Class Initialized
INFO - 2018-02-16 15:49:37 --> Config Class Initialized
INFO - 2018-02-16 15:49:37 --> Hooks Class Initialized
DEBUG - 2018-02-16 15:49:37 --> UTF-8 Support Enabled
INFO - 2018-02-16 15:49:37 --> Utf8 Class Initialized
INFO - 2018-02-16 15:49:37 --> URI Class Initialized
INFO - 2018-02-16 15:49:37 --> Router Class Initialized
INFO - 2018-02-16 15:49:37 --> Output Class Initialized
INFO - 2018-02-16 15:49:37 --> Security Class Initialized
DEBUG - 2018-02-16 15:49:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-16 15:49:37 --> Input Class Initialized
INFO - 2018-02-16 15:49:37 --> Language Class Initialized
INFO - 2018-02-16 15:49:37 --> Loader Class Initialized
INFO - 2018-02-16 15:49:37 --> Helper loaded: url_helper
INFO - 2018-02-16 15:49:37 --> Helper loaded: file_helper
INFO - 2018-02-16 15:49:37 --> Helper loaded: email_helper
INFO - 2018-02-16 15:49:37 --> Helper loaded: common_helper
INFO - 2018-02-16 15:49:37 --> Database Driver Class Initialized
DEBUG - 2018-02-16 15:49:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-16 15:49:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-16 15:49:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-16 15:49:37 --> Pagination Class Initialized
INFO - 2018-02-16 15:49:37 --> Helper loaded: form_helper
INFO - 2018-02-16 15:49:37 --> Form Validation Class Initialized
INFO - 2018-02-16 15:49:37 --> Model Class Initialized
INFO - 2018-02-16 15:49:37 --> Controller Class Initialized
INFO - 2018-02-16 15:49:37 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-16 15:49:37 --> Model Class Initialized
INFO - 2018-02-16 15:49:37 --> Model Class Initialized
INFO - 2018-02-16 15:49:37 --> Model Class Initialized
INFO - 2018-02-16 15:49:46 --> Config Class Initialized
INFO - 2018-02-16 15:49:46 --> Hooks Class Initialized
DEBUG - 2018-02-16 15:49:46 --> UTF-8 Support Enabled
INFO - 2018-02-16 15:49:46 --> Utf8 Class Initialized
INFO - 2018-02-16 15:49:46 --> URI Class Initialized
INFO - 2018-02-16 15:49:46 --> Router Class Initialized
INFO - 2018-02-16 15:49:46 --> Output Class Initialized
INFO - 2018-02-16 15:49:46 --> Security Class Initialized
DEBUG - 2018-02-16 15:49:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-16 15:49:46 --> Input Class Initialized
INFO - 2018-02-16 15:49:46 --> Language Class Initialized
INFO - 2018-02-16 15:49:46 --> Loader Class Initialized
INFO - 2018-02-16 15:49:46 --> Helper loaded: url_helper
INFO - 2018-02-16 15:49:46 --> Helper loaded: file_helper
INFO - 2018-02-16 15:49:46 --> Helper loaded: email_helper
INFO - 2018-02-16 15:49:46 --> Helper loaded: common_helper
INFO - 2018-02-16 15:49:46 --> Database Driver Class Initialized
DEBUG - 2018-02-16 15:49:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-16 15:49:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-16 15:49:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-16 15:49:46 --> Pagination Class Initialized
INFO - 2018-02-16 15:49:46 --> Helper loaded: form_helper
INFO - 2018-02-16 15:49:46 --> Form Validation Class Initialized
INFO - 2018-02-16 15:49:46 --> Model Class Initialized
INFO - 2018-02-16 15:49:46 --> Controller Class Initialized
INFO - 2018-02-16 15:49:46 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-16 15:49:46 --> Model Class Initialized
INFO - 2018-02-16 15:49:46 --> Model Class Initialized
INFO - 2018-02-16 15:49:46 --> Model Class Initialized
INFO - 2018-02-16 15:49:48 --> Config Class Initialized
INFO - 2018-02-16 15:49:48 --> Hooks Class Initialized
DEBUG - 2018-02-16 15:49:48 --> UTF-8 Support Enabled
INFO - 2018-02-16 15:49:48 --> Utf8 Class Initialized
INFO - 2018-02-16 15:49:48 --> URI Class Initialized
INFO - 2018-02-16 15:49:48 --> Router Class Initialized
INFO - 2018-02-16 15:49:48 --> Output Class Initialized
INFO - 2018-02-16 15:49:48 --> Security Class Initialized
DEBUG - 2018-02-16 15:49:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-16 15:49:48 --> Input Class Initialized
INFO - 2018-02-16 15:49:48 --> Language Class Initialized
INFO - 2018-02-16 15:49:48 --> Loader Class Initialized
INFO - 2018-02-16 15:49:48 --> Helper loaded: url_helper
INFO - 2018-02-16 15:49:48 --> Helper loaded: file_helper
INFO - 2018-02-16 15:49:48 --> Helper loaded: email_helper
INFO - 2018-02-16 15:49:48 --> Helper loaded: common_helper
INFO - 2018-02-16 15:49:48 --> Database Driver Class Initialized
DEBUG - 2018-02-16 15:49:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-16 15:49:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-16 15:49:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-16 15:49:48 --> Pagination Class Initialized
INFO - 2018-02-16 15:49:48 --> Helper loaded: form_helper
INFO - 2018-02-16 15:49:48 --> Form Validation Class Initialized
INFO - 2018-02-16 15:49:48 --> Model Class Initialized
INFO - 2018-02-16 15:49:48 --> Controller Class Initialized
INFO - 2018-02-16 15:49:48 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-16 15:49:48 --> Model Class Initialized
INFO - 2018-02-16 15:49:48 --> Model Class Initialized
INFO - 2018-02-16 15:49:48 --> Model Class Initialized
INFO - 2018-02-16 15:49:53 --> Config Class Initialized
INFO - 2018-02-16 15:49:53 --> Hooks Class Initialized
DEBUG - 2018-02-16 15:49:53 --> UTF-8 Support Enabled
INFO - 2018-02-16 15:49:53 --> Utf8 Class Initialized
INFO - 2018-02-16 15:49:53 --> URI Class Initialized
INFO - 2018-02-16 15:49:53 --> Router Class Initialized
INFO - 2018-02-16 15:49:53 --> Output Class Initialized
INFO - 2018-02-16 15:49:53 --> Security Class Initialized
DEBUG - 2018-02-16 15:49:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-16 15:49:53 --> Input Class Initialized
INFO - 2018-02-16 15:49:53 --> Language Class Initialized
INFO - 2018-02-16 15:49:53 --> Loader Class Initialized
INFO - 2018-02-16 15:49:53 --> Helper loaded: url_helper
INFO - 2018-02-16 15:49:53 --> Helper loaded: file_helper
INFO - 2018-02-16 15:49:53 --> Helper loaded: email_helper
INFO - 2018-02-16 15:49:53 --> Helper loaded: common_helper
INFO - 2018-02-16 15:49:53 --> Database Driver Class Initialized
DEBUG - 2018-02-16 15:49:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-16 15:49:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-16 15:49:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-16 15:49:53 --> Pagination Class Initialized
INFO - 2018-02-16 15:49:53 --> Helper loaded: form_helper
INFO - 2018-02-16 15:49:53 --> Form Validation Class Initialized
INFO - 2018-02-16 15:49:53 --> Model Class Initialized
INFO - 2018-02-16 15:49:53 --> Controller Class Initialized
INFO - 2018-02-16 15:49:53 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-16 15:49:53 --> Model Class Initialized
INFO - 2018-02-16 15:49:53 --> Model Class Initialized
INFO - 2018-02-16 15:49:53 --> Model Class Initialized
INFO - 2018-02-16 15:49:55 --> Config Class Initialized
INFO - 2018-02-16 15:49:55 --> Hooks Class Initialized
DEBUG - 2018-02-16 15:49:55 --> UTF-8 Support Enabled
INFO - 2018-02-16 15:49:55 --> Utf8 Class Initialized
INFO - 2018-02-16 15:49:55 --> URI Class Initialized
INFO - 2018-02-16 15:49:55 --> Router Class Initialized
INFO - 2018-02-16 15:49:55 --> Output Class Initialized
INFO - 2018-02-16 15:49:55 --> Security Class Initialized
DEBUG - 2018-02-16 15:49:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-16 15:49:55 --> Input Class Initialized
INFO - 2018-02-16 15:49:55 --> Language Class Initialized
INFO - 2018-02-16 15:49:55 --> Loader Class Initialized
INFO - 2018-02-16 15:49:55 --> Helper loaded: url_helper
INFO - 2018-02-16 15:49:55 --> Helper loaded: file_helper
INFO - 2018-02-16 15:49:55 --> Helper loaded: email_helper
INFO - 2018-02-16 15:49:55 --> Helper loaded: common_helper
INFO - 2018-02-16 15:49:55 --> Database Driver Class Initialized
DEBUG - 2018-02-16 15:49:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-16 15:49:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-16 15:49:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-16 15:49:55 --> Pagination Class Initialized
INFO - 2018-02-16 15:49:55 --> Helper loaded: form_helper
INFO - 2018-02-16 15:49:55 --> Form Validation Class Initialized
INFO - 2018-02-16 15:49:55 --> Model Class Initialized
INFO - 2018-02-16 15:49:55 --> Controller Class Initialized
INFO - 2018-02-16 15:49:55 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-16 15:49:55 --> Model Class Initialized
INFO - 2018-02-16 15:49:55 --> Model Class Initialized
INFO - 2018-02-16 15:49:55 --> Model Class Initialized
INFO - 2018-02-16 15:49:55 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-16 15:49:55 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-16 15:49:55 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-16 15:49:55 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-16 15:49:55 --> File loaded: /var/www/html/project/radio/application/views/tracks/add_edit.php
INFO - 2018-02-16 15:49:55 --> Final output sent to browser
DEBUG - 2018-02-16 15:49:55 --> Total execution time: 0.0065
INFO - 2018-02-16 15:49:57 --> Config Class Initialized
INFO - 2018-02-16 15:49:57 --> Hooks Class Initialized
DEBUG - 2018-02-16 15:49:57 --> UTF-8 Support Enabled
INFO - 2018-02-16 15:49:57 --> Utf8 Class Initialized
INFO - 2018-02-16 15:49:57 --> URI Class Initialized
INFO - 2018-02-16 15:49:57 --> Router Class Initialized
INFO - 2018-02-16 15:49:57 --> Output Class Initialized
INFO - 2018-02-16 15:49:57 --> Security Class Initialized
DEBUG - 2018-02-16 15:49:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-16 15:49:57 --> Input Class Initialized
INFO - 2018-02-16 15:49:57 --> Language Class Initialized
INFO - 2018-02-16 15:49:57 --> Loader Class Initialized
INFO - 2018-02-16 15:49:57 --> Helper loaded: url_helper
INFO - 2018-02-16 15:49:57 --> Helper loaded: file_helper
INFO - 2018-02-16 15:49:57 --> Helper loaded: email_helper
INFO - 2018-02-16 15:49:57 --> Helper loaded: common_helper
INFO - 2018-02-16 15:49:57 --> Database Driver Class Initialized
DEBUG - 2018-02-16 15:49:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-16 15:49:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-16 15:49:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-16 15:49:57 --> Pagination Class Initialized
INFO - 2018-02-16 15:49:57 --> Helper loaded: form_helper
INFO - 2018-02-16 15:49:57 --> Form Validation Class Initialized
INFO - 2018-02-16 15:49:57 --> Model Class Initialized
INFO - 2018-02-16 15:49:57 --> Controller Class Initialized
INFO - 2018-02-16 15:49:57 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-16 15:49:57 --> Model Class Initialized
INFO - 2018-02-16 15:49:57 --> Model Class Initialized
INFO - 2018-02-16 15:49:57 --> Model Class Initialized
INFO - 2018-02-16 15:49:57 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-16 15:49:57 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-16 15:49:57 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-16 15:49:57 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-16 15:49:57 --> File loaded: /var/www/html/project/radio/application/views/tracks/index.php
INFO - 2018-02-16 15:49:57 --> Final output sent to browser
DEBUG - 2018-02-16 15:49:57 --> Total execution time: 0.0060
INFO - 2018-02-16 15:49:57 --> Config Class Initialized
INFO - 2018-02-16 15:49:57 --> Hooks Class Initialized
DEBUG - 2018-02-16 15:49:57 --> UTF-8 Support Enabled
INFO - 2018-02-16 15:49:57 --> Utf8 Class Initialized
INFO - 2018-02-16 15:49:57 --> URI Class Initialized
INFO - 2018-02-16 15:49:57 --> Router Class Initialized
INFO - 2018-02-16 15:49:57 --> Output Class Initialized
INFO - 2018-02-16 15:49:57 --> Security Class Initialized
DEBUG - 2018-02-16 15:49:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-16 15:49:57 --> Input Class Initialized
INFO - 2018-02-16 15:49:57 --> Language Class Initialized
INFO - 2018-02-16 15:49:57 --> Loader Class Initialized
INFO - 2018-02-16 15:49:57 --> Helper loaded: url_helper
INFO - 2018-02-16 15:49:57 --> Helper loaded: file_helper
INFO - 2018-02-16 15:49:57 --> Helper loaded: email_helper
INFO - 2018-02-16 15:49:57 --> Helper loaded: common_helper
INFO - 2018-02-16 15:49:57 --> Database Driver Class Initialized
DEBUG - 2018-02-16 15:49:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-16 15:49:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-16 15:49:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-16 15:49:57 --> Pagination Class Initialized
INFO - 2018-02-16 15:49:57 --> Helper loaded: form_helper
INFO - 2018-02-16 15:49:57 --> Form Validation Class Initialized
INFO - 2018-02-16 15:49:57 --> Model Class Initialized
INFO - 2018-02-16 15:49:57 --> Controller Class Initialized
INFO - 2018-02-16 15:49:57 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-16 15:49:57 --> Model Class Initialized
INFO - 2018-02-16 15:49:57 --> Model Class Initialized
INFO - 2018-02-16 15:49:57 --> Model Class Initialized
INFO - 2018-02-16 15:53:15 --> Config Class Initialized
INFO - 2018-02-16 15:53:15 --> Hooks Class Initialized
DEBUG - 2018-02-16 15:53:15 --> UTF-8 Support Enabled
INFO - 2018-02-16 15:53:15 --> Utf8 Class Initialized
INFO - 2018-02-16 15:53:15 --> URI Class Initialized
INFO - 2018-02-16 15:53:15 --> Router Class Initialized
INFO - 2018-02-16 15:53:15 --> Output Class Initialized
INFO - 2018-02-16 15:53:15 --> Security Class Initialized
DEBUG - 2018-02-16 15:53:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-16 15:53:15 --> Input Class Initialized
INFO - 2018-02-16 15:53:15 --> Language Class Initialized
INFO - 2018-02-16 15:53:15 --> Loader Class Initialized
INFO - 2018-02-16 15:53:15 --> Helper loaded: url_helper
INFO - 2018-02-16 15:53:15 --> Helper loaded: file_helper
INFO - 2018-02-16 15:53:15 --> Helper loaded: email_helper
INFO - 2018-02-16 15:53:15 --> Helper loaded: common_helper
INFO - 2018-02-16 15:53:15 --> Database Driver Class Initialized
DEBUG - 2018-02-16 15:53:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-16 15:53:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-16 15:53:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-16 15:53:15 --> Pagination Class Initialized
INFO - 2018-02-16 15:53:15 --> Helper loaded: form_helper
INFO - 2018-02-16 15:53:15 --> Form Validation Class Initialized
INFO - 2018-02-16 15:53:15 --> Model Class Initialized
INFO - 2018-02-16 15:53:15 --> Controller Class Initialized
INFO - 2018-02-16 15:53:15 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-16 15:53:15 --> Model Class Initialized
INFO - 2018-02-16 15:53:15 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-16 15:53:15 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-16 15:53:15 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-16 15:53:15 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-16 15:53:15 --> File loaded: /var/www/html/project/radio/application/views/staticpages/index.php
INFO - 2018-02-16 15:53:15 --> Final output sent to browser
DEBUG - 2018-02-16 15:53:15 --> Total execution time: 0.0071
INFO - 2018-02-16 15:53:28 --> Config Class Initialized
INFO - 2018-02-16 15:53:28 --> Hooks Class Initialized
DEBUG - 2018-02-16 15:53:28 --> UTF-8 Support Enabled
INFO - 2018-02-16 15:53:28 --> Utf8 Class Initialized
INFO - 2018-02-16 15:53:28 --> URI Class Initialized
INFO - 2018-02-16 15:53:28 --> Router Class Initialized
INFO - 2018-02-16 15:53:28 --> Output Class Initialized
INFO - 2018-02-16 15:53:28 --> Security Class Initialized
DEBUG - 2018-02-16 15:53:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-16 15:53:28 --> Input Class Initialized
INFO - 2018-02-16 15:53:28 --> Language Class Initialized
INFO - 2018-02-16 15:53:28 --> Loader Class Initialized
INFO - 2018-02-16 15:53:28 --> Helper loaded: url_helper
INFO - 2018-02-16 15:53:28 --> Helper loaded: file_helper
INFO - 2018-02-16 15:53:28 --> Helper loaded: email_helper
INFO - 2018-02-16 15:53:28 --> Helper loaded: common_helper
INFO - 2018-02-16 15:53:28 --> Database Driver Class Initialized
DEBUG - 2018-02-16 15:53:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-16 15:53:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-16 15:53:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-16 15:53:28 --> Pagination Class Initialized
INFO - 2018-02-16 15:53:28 --> Helper loaded: form_helper
INFO - 2018-02-16 15:53:28 --> Form Validation Class Initialized
INFO - 2018-02-16 15:53:28 --> Model Class Initialized
INFO - 2018-02-16 15:53:28 --> Controller Class Initialized
INFO - 2018-02-16 15:53:28 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-16 15:53:28 --> Model Class Initialized
INFO - 2018-02-16 15:53:28 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-16 15:53:28 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-16 15:53:28 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-16 15:53:28 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-16 15:53:28 --> File loaded: /var/www/html/project/radio/application/views/user/index.php
INFO - 2018-02-16 15:53:28 --> Final output sent to browser
DEBUG - 2018-02-16 15:53:28 --> Total execution time: 0.0076
INFO - 2018-02-16 15:53:28 --> Config Class Initialized
INFO - 2018-02-16 15:53:28 --> Hooks Class Initialized
DEBUG - 2018-02-16 15:53:28 --> UTF-8 Support Enabled
INFO - 2018-02-16 15:53:28 --> Utf8 Class Initialized
INFO - 2018-02-16 15:53:28 --> URI Class Initialized
INFO - 2018-02-16 15:53:28 --> Router Class Initialized
INFO - 2018-02-16 15:53:28 --> Output Class Initialized
INFO - 2018-02-16 15:53:28 --> Security Class Initialized
DEBUG - 2018-02-16 15:53:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-16 15:53:28 --> Input Class Initialized
INFO - 2018-02-16 15:53:28 --> Language Class Initialized
INFO - 2018-02-16 15:53:28 --> Loader Class Initialized
INFO - 2018-02-16 15:53:28 --> Helper loaded: url_helper
INFO - 2018-02-16 15:53:28 --> Helper loaded: file_helper
INFO - 2018-02-16 15:53:28 --> Helper loaded: email_helper
INFO - 2018-02-16 15:53:28 --> Helper loaded: common_helper
INFO - 2018-02-16 15:53:28 --> Database Driver Class Initialized
DEBUG - 2018-02-16 15:53:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-16 15:53:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-16 15:53:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-16 15:53:28 --> Pagination Class Initialized
INFO - 2018-02-16 15:53:28 --> Helper loaded: form_helper
INFO - 2018-02-16 15:53:28 --> Form Validation Class Initialized
INFO - 2018-02-16 15:53:28 --> Model Class Initialized
INFO - 2018-02-16 15:53:28 --> Controller Class Initialized
INFO - 2018-02-16 15:53:28 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-16 15:53:28 --> Model Class Initialized
INFO - 2018-02-16 15:53:30 --> Config Class Initialized
INFO - 2018-02-16 15:53:30 --> Hooks Class Initialized
DEBUG - 2018-02-16 15:53:30 --> UTF-8 Support Enabled
INFO - 2018-02-16 15:53:30 --> Utf8 Class Initialized
INFO - 2018-02-16 15:53:30 --> URI Class Initialized
INFO - 2018-02-16 15:53:30 --> Router Class Initialized
INFO - 2018-02-16 15:53:30 --> Output Class Initialized
INFO - 2018-02-16 15:53:30 --> Security Class Initialized
DEBUG - 2018-02-16 15:53:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-16 15:53:30 --> Input Class Initialized
INFO - 2018-02-16 15:53:30 --> Language Class Initialized
INFO - 2018-02-16 15:53:30 --> Loader Class Initialized
INFO - 2018-02-16 15:53:30 --> Helper loaded: url_helper
INFO - 2018-02-16 15:53:30 --> Helper loaded: file_helper
INFO - 2018-02-16 15:53:30 --> Helper loaded: email_helper
INFO - 2018-02-16 15:53:30 --> Helper loaded: common_helper
INFO - 2018-02-16 15:53:30 --> Database Driver Class Initialized
DEBUG - 2018-02-16 15:53:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-16 15:53:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-16 15:53:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-16 15:53:30 --> Pagination Class Initialized
INFO - 2018-02-16 15:53:30 --> Helper loaded: form_helper
INFO - 2018-02-16 15:53:30 --> Form Validation Class Initialized
INFO - 2018-02-16 15:53:30 --> Model Class Initialized
INFO - 2018-02-16 15:53:30 --> Controller Class Initialized
INFO - 2018-02-16 15:53:30 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-16 15:53:30 --> Model Class Initialized
INFO - 2018-02-16 15:53:30 --> Config Class Initialized
INFO - 2018-02-16 15:53:30 --> Hooks Class Initialized
DEBUG - 2018-02-16 15:53:30 --> UTF-8 Support Enabled
INFO - 2018-02-16 15:53:30 --> Utf8 Class Initialized
INFO - 2018-02-16 15:53:30 --> URI Class Initialized
INFO - 2018-02-16 15:53:30 --> Router Class Initialized
INFO - 2018-02-16 15:53:30 --> Output Class Initialized
INFO - 2018-02-16 15:53:30 --> Security Class Initialized
DEBUG - 2018-02-16 15:53:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-16 15:53:30 --> Input Class Initialized
INFO - 2018-02-16 15:53:30 --> Language Class Initialized
INFO - 2018-02-16 15:53:30 --> Loader Class Initialized
INFO - 2018-02-16 15:53:30 --> Helper loaded: url_helper
INFO - 2018-02-16 15:53:30 --> Helper loaded: file_helper
INFO - 2018-02-16 15:53:30 --> Helper loaded: email_helper
INFO - 2018-02-16 15:53:30 --> Helper loaded: common_helper
INFO - 2018-02-16 15:53:30 --> Database Driver Class Initialized
DEBUG - 2018-02-16 15:53:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-16 15:53:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-16 15:53:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-16 15:53:30 --> Pagination Class Initialized
INFO - 2018-02-16 15:53:30 --> Helper loaded: form_helper
INFO - 2018-02-16 15:53:30 --> Form Validation Class Initialized
INFO - 2018-02-16 15:53:30 --> Model Class Initialized
INFO - 2018-02-16 15:53:30 --> Controller Class Initialized
INFO - 2018-02-16 15:53:30 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-16 15:53:30 --> Model Class Initialized
INFO - 2018-02-16 15:53:30 --> Config Class Initialized
INFO - 2018-02-16 15:53:30 --> Hooks Class Initialized
DEBUG - 2018-02-16 15:53:30 --> UTF-8 Support Enabled
INFO - 2018-02-16 15:53:30 --> Utf8 Class Initialized
INFO - 2018-02-16 15:53:30 --> URI Class Initialized
INFO - 2018-02-16 15:53:30 --> Router Class Initialized
INFO - 2018-02-16 15:53:30 --> Output Class Initialized
INFO - 2018-02-16 15:53:30 --> Security Class Initialized
DEBUG - 2018-02-16 15:53:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-16 15:53:30 --> Input Class Initialized
INFO - 2018-02-16 15:53:30 --> Language Class Initialized
INFO - 2018-02-16 15:53:30 --> Loader Class Initialized
INFO - 2018-02-16 15:53:30 --> Helper loaded: url_helper
INFO - 2018-02-16 15:53:30 --> Helper loaded: file_helper
INFO - 2018-02-16 15:53:30 --> Helper loaded: email_helper
INFO - 2018-02-16 15:53:30 --> Helper loaded: common_helper
INFO - 2018-02-16 15:53:30 --> Database Driver Class Initialized
DEBUG - 2018-02-16 15:53:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-16 15:53:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-16 15:53:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-16 15:53:30 --> Pagination Class Initialized
INFO - 2018-02-16 15:53:30 --> Helper loaded: form_helper
INFO - 2018-02-16 15:53:30 --> Form Validation Class Initialized
INFO - 2018-02-16 15:53:30 --> Model Class Initialized
INFO - 2018-02-16 15:53:30 --> Controller Class Initialized
INFO - 2018-02-16 15:53:30 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-16 15:53:30 --> Model Class Initialized
INFO - 2018-02-16 15:53:31 --> Config Class Initialized
INFO - 2018-02-16 15:53:31 --> Hooks Class Initialized
DEBUG - 2018-02-16 15:53:31 --> UTF-8 Support Enabled
INFO - 2018-02-16 15:53:31 --> Utf8 Class Initialized
INFO - 2018-02-16 15:53:31 --> URI Class Initialized
INFO - 2018-02-16 15:53:31 --> Router Class Initialized
INFO - 2018-02-16 15:53:31 --> Output Class Initialized
INFO - 2018-02-16 15:53:31 --> Security Class Initialized
DEBUG - 2018-02-16 15:53:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-16 15:53:31 --> Input Class Initialized
INFO - 2018-02-16 15:53:31 --> Language Class Initialized
INFO - 2018-02-16 15:53:31 --> Loader Class Initialized
INFO - 2018-02-16 15:53:31 --> Helper loaded: url_helper
INFO - 2018-02-16 15:53:31 --> Helper loaded: file_helper
INFO - 2018-02-16 15:53:31 --> Helper loaded: email_helper
INFO - 2018-02-16 15:53:31 --> Helper loaded: common_helper
INFO - 2018-02-16 15:53:31 --> Database Driver Class Initialized
DEBUG - 2018-02-16 15:53:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-16 15:53:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-16 15:53:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-16 15:53:31 --> Pagination Class Initialized
INFO - 2018-02-16 15:53:31 --> Helper loaded: form_helper
INFO - 2018-02-16 15:53:31 --> Form Validation Class Initialized
INFO - 2018-02-16 15:53:31 --> Model Class Initialized
INFO - 2018-02-16 15:53:31 --> Controller Class Initialized
INFO - 2018-02-16 15:53:31 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-16 15:53:31 --> Model Class Initialized
INFO - 2018-02-16 16:02:18 --> Config Class Initialized
INFO - 2018-02-16 16:02:18 --> Hooks Class Initialized
DEBUG - 2018-02-16 16:02:18 --> UTF-8 Support Enabled
INFO - 2018-02-16 16:02:18 --> Utf8 Class Initialized
INFO - 2018-02-16 16:02:18 --> URI Class Initialized
INFO - 2018-02-16 16:02:18 --> Router Class Initialized
INFO - 2018-02-16 16:02:18 --> Output Class Initialized
INFO - 2018-02-16 16:02:18 --> Security Class Initialized
DEBUG - 2018-02-16 16:02:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-16 16:02:18 --> Input Class Initialized
INFO - 2018-02-16 16:02:18 --> Language Class Initialized
INFO - 2018-02-16 16:02:18 --> Loader Class Initialized
INFO - 2018-02-16 16:02:18 --> Helper loaded: url_helper
INFO - 2018-02-16 16:02:18 --> Helper loaded: file_helper
INFO - 2018-02-16 16:02:18 --> Helper loaded: email_helper
INFO - 2018-02-16 16:02:18 --> Helper loaded: common_helper
INFO - 2018-02-16 16:02:18 --> Database Driver Class Initialized
DEBUG - 2018-02-16 16:02:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-16 16:02:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-16 16:02:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-16 16:02:18 --> Pagination Class Initialized
INFO - 2018-02-16 16:02:18 --> Helper loaded: form_helper
INFO - 2018-02-16 16:02:18 --> Form Validation Class Initialized
INFO - 2018-02-16 16:02:18 --> Model Class Initialized
INFO - 2018-02-16 16:02:18 --> Controller Class Initialized
INFO - 2018-02-16 16:02:18 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-16 16:02:18 --> Model Class Initialized
INFO - 2018-02-16 16:02:18 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-16 16:02:18 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-16 16:02:18 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-16 16:02:18 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-16 16:02:18 --> File loaded: /var/www/html/project/radio/application/views/user/index.php
INFO - 2018-02-16 16:02:18 --> Final output sent to browser
DEBUG - 2018-02-16 16:02:18 --> Total execution time: 0.0085
INFO - 2018-02-16 16:02:18 --> Config Class Initialized
INFO - 2018-02-16 16:02:18 --> Hooks Class Initialized
DEBUG - 2018-02-16 16:02:18 --> UTF-8 Support Enabled
INFO - 2018-02-16 16:02:18 --> Utf8 Class Initialized
INFO - 2018-02-16 16:02:18 --> URI Class Initialized
INFO - 2018-02-16 16:02:18 --> Router Class Initialized
INFO - 2018-02-16 16:02:18 --> Output Class Initialized
INFO - 2018-02-16 16:02:18 --> Security Class Initialized
DEBUG - 2018-02-16 16:02:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-16 16:02:18 --> Input Class Initialized
INFO - 2018-02-16 16:02:18 --> Language Class Initialized
INFO - 2018-02-16 16:02:18 --> Loader Class Initialized
INFO - 2018-02-16 16:02:18 --> Helper loaded: url_helper
INFO - 2018-02-16 16:02:18 --> Helper loaded: file_helper
INFO - 2018-02-16 16:02:18 --> Helper loaded: email_helper
INFO - 2018-02-16 16:02:18 --> Helper loaded: common_helper
INFO - 2018-02-16 16:02:18 --> Database Driver Class Initialized
DEBUG - 2018-02-16 16:02:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-16 16:02:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-16 16:02:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-16 16:02:18 --> Pagination Class Initialized
INFO - 2018-02-16 16:02:18 --> Helper loaded: form_helper
INFO - 2018-02-16 16:02:18 --> Form Validation Class Initialized
INFO - 2018-02-16 16:02:18 --> Model Class Initialized
INFO - 2018-02-16 16:02:18 --> Controller Class Initialized
INFO - 2018-02-16 16:02:18 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-16 16:02:18 --> Model Class Initialized
INFO - 2018-02-16 16:24:32 --> Config Class Initialized
INFO - 2018-02-16 16:24:32 --> Hooks Class Initialized
DEBUG - 2018-02-16 16:24:32 --> UTF-8 Support Enabled
INFO - 2018-02-16 16:24:32 --> Utf8 Class Initialized
INFO - 2018-02-16 16:24:32 --> URI Class Initialized
INFO - 2018-02-16 16:24:32 --> Router Class Initialized
INFO - 2018-02-16 16:24:32 --> Output Class Initialized
INFO - 2018-02-16 16:24:32 --> Security Class Initialized
DEBUG - 2018-02-16 16:24:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-16 16:24:32 --> Input Class Initialized
INFO - 2018-02-16 16:24:32 --> Language Class Initialized
INFO - 2018-02-16 16:24:32 --> Loader Class Initialized
INFO - 2018-02-16 16:24:32 --> Helper loaded: url_helper
INFO - 2018-02-16 16:24:32 --> Helper loaded: file_helper
INFO - 2018-02-16 16:24:32 --> Helper loaded: email_helper
INFO - 2018-02-16 16:24:32 --> Helper loaded: common_helper
INFO - 2018-02-16 16:24:32 --> Database Driver Class Initialized
DEBUG - 2018-02-16 16:24:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-16 16:24:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-16 16:24:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-16 16:24:32 --> Pagination Class Initialized
INFO - 2018-02-16 16:24:32 --> Helper loaded: form_helper
INFO - 2018-02-16 16:24:32 --> Form Validation Class Initialized
INFO - 2018-02-16 16:24:32 --> Model Class Initialized
INFO - 2018-02-16 16:24:32 --> Controller Class Initialized
INFO - 2018-02-16 16:24:32 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-16 16:24:32 --> Model Class Initialized
INFO - 2018-02-16 16:24:32 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-16 16:24:32 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-16 16:24:32 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-16 16:24:32 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-16 16:24:32 --> File loaded: /var/www/html/project/radio/application/views/user/index.php
INFO - 2018-02-16 16:24:32 --> Final output sent to browser
DEBUG - 2018-02-16 16:24:32 --> Total execution time: 0.0066
INFO - 2018-02-16 16:24:32 --> Config Class Initialized
INFO - 2018-02-16 16:24:32 --> Hooks Class Initialized
DEBUG - 2018-02-16 16:24:32 --> UTF-8 Support Enabled
INFO - 2018-02-16 16:24:32 --> Utf8 Class Initialized
INFO - 2018-02-16 16:24:32 --> URI Class Initialized
INFO - 2018-02-16 16:24:32 --> Router Class Initialized
INFO - 2018-02-16 16:24:32 --> Output Class Initialized
INFO - 2018-02-16 16:24:32 --> Security Class Initialized
DEBUG - 2018-02-16 16:24:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-16 16:24:32 --> Input Class Initialized
INFO - 2018-02-16 16:24:32 --> Language Class Initialized
INFO - 2018-02-16 16:24:32 --> Loader Class Initialized
INFO - 2018-02-16 16:24:32 --> Helper loaded: url_helper
INFO - 2018-02-16 16:24:32 --> Helper loaded: file_helper
INFO - 2018-02-16 16:24:32 --> Helper loaded: email_helper
INFO - 2018-02-16 16:24:32 --> Helper loaded: common_helper
INFO - 2018-02-16 16:24:32 --> Database Driver Class Initialized
DEBUG - 2018-02-16 16:24:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-16 16:24:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-16 16:24:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-16 16:24:32 --> Pagination Class Initialized
INFO - 2018-02-16 16:24:32 --> Helper loaded: form_helper
INFO - 2018-02-16 16:24:32 --> Form Validation Class Initialized
INFO - 2018-02-16 16:24:32 --> Model Class Initialized
INFO - 2018-02-16 16:24:32 --> Controller Class Initialized
INFO - 2018-02-16 16:24:32 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-16 16:24:32 --> Model Class Initialized
INFO - 2018-02-16 16:24:53 --> Config Class Initialized
INFO - 2018-02-16 16:24:53 --> Hooks Class Initialized
DEBUG - 2018-02-16 16:24:53 --> UTF-8 Support Enabled
INFO - 2018-02-16 16:24:53 --> Utf8 Class Initialized
INFO - 2018-02-16 16:24:53 --> URI Class Initialized
INFO - 2018-02-16 16:24:53 --> Router Class Initialized
INFO - 2018-02-16 16:24:53 --> Output Class Initialized
INFO - 2018-02-16 16:24:53 --> Security Class Initialized
DEBUG - 2018-02-16 16:24:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-16 16:24:53 --> Input Class Initialized
INFO - 2018-02-16 16:24:53 --> Language Class Initialized
INFO - 2018-02-16 16:24:53 --> Loader Class Initialized
INFO - 2018-02-16 16:24:53 --> Helper loaded: url_helper
INFO - 2018-02-16 16:24:53 --> Helper loaded: file_helper
INFO - 2018-02-16 16:24:53 --> Helper loaded: email_helper
INFO - 2018-02-16 16:24:53 --> Helper loaded: common_helper
INFO - 2018-02-16 16:24:53 --> Database Driver Class Initialized
DEBUG - 2018-02-16 16:24:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-16 16:24:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-16 16:24:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-16 16:24:53 --> Pagination Class Initialized
INFO - 2018-02-16 16:24:53 --> Helper loaded: form_helper
INFO - 2018-02-16 16:24:53 --> Form Validation Class Initialized
INFO - 2018-02-16 16:24:53 --> Model Class Initialized
INFO - 2018-02-16 16:24:53 --> Controller Class Initialized
INFO - 2018-02-16 16:24:53 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-16 16:24:53 --> Model Class Initialized
INFO - 2018-02-16 16:24:53 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-16 16:24:53 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-16 16:24:53 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-16 16:24:53 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-16 16:24:53 --> File loaded: /var/www/html/project/radio/application/views/user/index.php
INFO - 2018-02-16 16:24:53 --> Final output sent to browser
DEBUG - 2018-02-16 16:24:53 --> Total execution time: 0.0064
INFO - 2018-02-16 16:24:54 --> Config Class Initialized
INFO - 2018-02-16 16:24:54 --> Hooks Class Initialized
DEBUG - 2018-02-16 16:24:54 --> UTF-8 Support Enabled
INFO - 2018-02-16 16:24:54 --> Utf8 Class Initialized
INFO - 2018-02-16 16:24:54 --> URI Class Initialized
INFO - 2018-02-16 16:24:54 --> Router Class Initialized
INFO - 2018-02-16 16:24:54 --> Output Class Initialized
INFO - 2018-02-16 16:24:54 --> Security Class Initialized
DEBUG - 2018-02-16 16:24:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-16 16:24:54 --> Input Class Initialized
INFO - 2018-02-16 16:24:54 --> Language Class Initialized
INFO - 2018-02-16 16:24:54 --> Loader Class Initialized
INFO - 2018-02-16 16:24:54 --> Helper loaded: url_helper
INFO - 2018-02-16 16:24:54 --> Helper loaded: file_helper
INFO - 2018-02-16 16:24:54 --> Helper loaded: email_helper
INFO - 2018-02-16 16:24:54 --> Helper loaded: common_helper
INFO - 2018-02-16 16:24:54 --> Database Driver Class Initialized
DEBUG - 2018-02-16 16:24:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-16 16:24:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-16 16:24:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-16 16:24:54 --> Pagination Class Initialized
INFO - 2018-02-16 16:24:54 --> Helper loaded: form_helper
INFO - 2018-02-16 16:24:54 --> Form Validation Class Initialized
INFO - 2018-02-16 16:24:54 --> Model Class Initialized
INFO - 2018-02-16 16:24:54 --> Controller Class Initialized
INFO - 2018-02-16 16:24:54 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-16 16:24:54 --> Model Class Initialized
INFO - 2018-02-16 16:24:57 --> Config Class Initialized
INFO - 2018-02-16 16:24:57 --> Hooks Class Initialized
DEBUG - 2018-02-16 16:24:57 --> UTF-8 Support Enabled
INFO - 2018-02-16 16:24:57 --> Utf8 Class Initialized
INFO - 2018-02-16 16:24:57 --> URI Class Initialized
INFO - 2018-02-16 16:24:57 --> Router Class Initialized
INFO - 2018-02-16 16:24:57 --> Output Class Initialized
INFO - 2018-02-16 16:24:57 --> Security Class Initialized
DEBUG - 2018-02-16 16:24:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-16 16:24:57 --> Input Class Initialized
INFO - 2018-02-16 16:24:57 --> Language Class Initialized
INFO - 2018-02-16 16:24:57 --> Loader Class Initialized
INFO - 2018-02-16 16:24:57 --> Helper loaded: url_helper
INFO - 2018-02-16 16:24:57 --> Helper loaded: file_helper
INFO - 2018-02-16 16:24:57 --> Helper loaded: email_helper
INFO - 2018-02-16 16:24:57 --> Helper loaded: common_helper
INFO - 2018-02-16 16:24:57 --> Database Driver Class Initialized
DEBUG - 2018-02-16 16:24:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-16 16:24:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-16 16:24:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-16 16:24:57 --> Pagination Class Initialized
INFO - 2018-02-16 16:24:57 --> Helper loaded: form_helper
INFO - 2018-02-16 16:24:57 --> Form Validation Class Initialized
INFO - 2018-02-16 16:24:57 --> Model Class Initialized
INFO - 2018-02-16 16:24:57 --> Controller Class Initialized
INFO - 2018-02-16 16:24:57 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-16 16:24:57 --> Model Class Initialized
ERROR - 2018-02-16 16:24:57 --> Severity: Notice --> Undefined property: User::$Category_model /var/www/html/project/radio/application/controllers/User.php 116
ERROR - 2018-02-16 16:24:57 --> Severity: error --> Exception: Call to a member function updateData() on null /var/www/html/project/radio/application/controllers/User.php 116
INFO - 2018-02-16 16:25:01 --> Config Class Initialized
INFO - 2018-02-16 16:25:01 --> Hooks Class Initialized
DEBUG - 2018-02-16 16:25:01 --> UTF-8 Support Enabled
INFO - 2018-02-16 16:25:01 --> Utf8 Class Initialized
INFO - 2018-02-16 16:25:01 --> URI Class Initialized
INFO - 2018-02-16 16:25:01 --> Router Class Initialized
INFO - 2018-02-16 16:25:01 --> Output Class Initialized
INFO - 2018-02-16 16:25:01 --> Security Class Initialized
DEBUG - 2018-02-16 16:25:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-16 16:25:01 --> Input Class Initialized
INFO - 2018-02-16 16:25:01 --> Language Class Initialized
INFO - 2018-02-16 16:25:01 --> Loader Class Initialized
INFO - 2018-02-16 16:25:01 --> Helper loaded: url_helper
INFO - 2018-02-16 16:25:01 --> Helper loaded: file_helper
INFO - 2018-02-16 16:25:01 --> Helper loaded: email_helper
INFO - 2018-02-16 16:25:01 --> Helper loaded: common_helper
INFO - 2018-02-16 16:25:01 --> Database Driver Class Initialized
DEBUG - 2018-02-16 16:25:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-16 16:25:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-16 16:25:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-16 16:25:01 --> Pagination Class Initialized
INFO - 2018-02-16 16:25:01 --> Helper loaded: form_helper
INFO - 2018-02-16 16:25:01 --> Form Validation Class Initialized
INFO - 2018-02-16 16:25:01 --> Model Class Initialized
INFO - 2018-02-16 16:25:01 --> Controller Class Initialized
INFO - 2018-02-16 16:25:01 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-16 16:25:01 --> Model Class Initialized
INFO - 2018-02-16 16:25:01 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-16 16:25:01 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-16 16:25:01 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-16 16:25:01 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-16 16:25:01 --> File loaded: /var/www/html/project/radio/application/views/user/index.php
INFO - 2018-02-16 16:25:01 --> Final output sent to browser
DEBUG - 2018-02-16 16:25:01 --> Total execution time: 0.0060
INFO - 2018-02-16 16:25:01 --> Config Class Initialized
INFO - 2018-02-16 16:25:01 --> Hooks Class Initialized
DEBUG - 2018-02-16 16:25:01 --> UTF-8 Support Enabled
INFO - 2018-02-16 16:25:01 --> Utf8 Class Initialized
INFO - 2018-02-16 16:25:01 --> URI Class Initialized
INFO - 2018-02-16 16:25:01 --> Router Class Initialized
INFO - 2018-02-16 16:25:01 --> Output Class Initialized
INFO - 2018-02-16 16:25:01 --> Security Class Initialized
DEBUG - 2018-02-16 16:25:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-16 16:25:01 --> Input Class Initialized
INFO - 2018-02-16 16:25:01 --> Language Class Initialized
INFO - 2018-02-16 16:25:01 --> Loader Class Initialized
INFO - 2018-02-16 16:25:01 --> Helper loaded: url_helper
INFO - 2018-02-16 16:25:01 --> Helper loaded: file_helper
INFO - 2018-02-16 16:25:01 --> Helper loaded: email_helper
INFO - 2018-02-16 16:25:01 --> Helper loaded: common_helper
INFO - 2018-02-16 16:25:01 --> Database Driver Class Initialized
DEBUG - 2018-02-16 16:25:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-16 16:25:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-16 16:25:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-16 16:25:01 --> Pagination Class Initialized
INFO - 2018-02-16 16:25:01 --> Helper loaded: form_helper
INFO - 2018-02-16 16:25:01 --> Form Validation Class Initialized
INFO - 2018-02-16 16:25:01 --> Model Class Initialized
INFO - 2018-02-16 16:25:01 --> Controller Class Initialized
INFO - 2018-02-16 16:25:01 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-16 16:25:01 --> Model Class Initialized
INFO - 2018-02-16 16:25:25 --> Config Class Initialized
INFO - 2018-02-16 16:25:25 --> Hooks Class Initialized
DEBUG - 2018-02-16 16:25:25 --> UTF-8 Support Enabled
INFO - 2018-02-16 16:25:25 --> Utf8 Class Initialized
INFO - 2018-02-16 16:25:25 --> URI Class Initialized
INFO - 2018-02-16 16:25:25 --> Router Class Initialized
INFO - 2018-02-16 16:25:25 --> Output Class Initialized
INFO - 2018-02-16 16:25:25 --> Security Class Initialized
DEBUG - 2018-02-16 16:25:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-16 16:25:25 --> Input Class Initialized
INFO - 2018-02-16 16:25:25 --> Language Class Initialized
INFO - 2018-02-16 16:25:25 --> Loader Class Initialized
INFO - 2018-02-16 16:25:25 --> Helper loaded: url_helper
INFO - 2018-02-16 16:25:25 --> Helper loaded: file_helper
INFO - 2018-02-16 16:25:25 --> Helper loaded: email_helper
INFO - 2018-02-16 16:25:25 --> Helper loaded: common_helper
INFO - 2018-02-16 16:25:25 --> Database Driver Class Initialized
DEBUG - 2018-02-16 16:25:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-16 16:25:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-16 16:25:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-16 16:25:25 --> Pagination Class Initialized
INFO - 2018-02-16 16:25:25 --> Helper loaded: form_helper
INFO - 2018-02-16 16:25:25 --> Form Validation Class Initialized
INFO - 2018-02-16 16:25:25 --> Model Class Initialized
INFO - 2018-02-16 16:25:25 --> Controller Class Initialized
INFO - 2018-02-16 16:25:25 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-16 16:25:25 --> Model Class Initialized
INFO - 2018-02-16 16:25:25 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-16 16:25:25 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-16 16:25:25 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-16 16:25:25 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-16 16:25:25 --> File loaded: /var/www/html/project/radio/application/views/user/index.php
INFO - 2018-02-16 16:25:25 --> Final output sent to browser
DEBUG - 2018-02-16 16:25:25 --> Total execution time: 0.0061
INFO - 2018-02-16 16:25:25 --> Config Class Initialized
INFO - 2018-02-16 16:25:25 --> Hooks Class Initialized
DEBUG - 2018-02-16 16:25:25 --> UTF-8 Support Enabled
INFO - 2018-02-16 16:25:25 --> Utf8 Class Initialized
INFO - 2018-02-16 16:25:25 --> URI Class Initialized
INFO - 2018-02-16 16:25:25 --> Router Class Initialized
INFO - 2018-02-16 16:25:25 --> Output Class Initialized
INFO - 2018-02-16 16:25:25 --> Security Class Initialized
DEBUG - 2018-02-16 16:25:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-16 16:25:25 --> Input Class Initialized
INFO - 2018-02-16 16:25:25 --> Language Class Initialized
INFO - 2018-02-16 16:25:25 --> Loader Class Initialized
INFO - 2018-02-16 16:25:25 --> Helper loaded: url_helper
INFO - 2018-02-16 16:25:25 --> Helper loaded: file_helper
INFO - 2018-02-16 16:25:25 --> Helper loaded: email_helper
INFO - 2018-02-16 16:25:25 --> Helper loaded: common_helper
INFO - 2018-02-16 16:25:25 --> Database Driver Class Initialized
DEBUG - 2018-02-16 16:25:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-16 16:25:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-16 16:25:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-16 16:25:25 --> Pagination Class Initialized
INFO - 2018-02-16 16:25:25 --> Helper loaded: form_helper
INFO - 2018-02-16 16:25:25 --> Form Validation Class Initialized
INFO - 2018-02-16 16:25:25 --> Model Class Initialized
INFO - 2018-02-16 16:25:25 --> Controller Class Initialized
INFO - 2018-02-16 16:25:25 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-16 16:25:25 --> Model Class Initialized
INFO - 2018-02-16 16:25:27 --> Config Class Initialized
INFO - 2018-02-16 16:25:27 --> Hooks Class Initialized
DEBUG - 2018-02-16 16:25:27 --> UTF-8 Support Enabled
INFO - 2018-02-16 16:25:27 --> Utf8 Class Initialized
INFO - 2018-02-16 16:25:27 --> URI Class Initialized
INFO - 2018-02-16 16:25:27 --> Router Class Initialized
INFO - 2018-02-16 16:25:27 --> Output Class Initialized
INFO - 2018-02-16 16:25:27 --> Security Class Initialized
DEBUG - 2018-02-16 16:25:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-16 16:25:27 --> Input Class Initialized
INFO - 2018-02-16 16:25:27 --> Language Class Initialized
INFO - 2018-02-16 16:25:27 --> Loader Class Initialized
INFO - 2018-02-16 16:25:27 --> Helper loaded: url_helper
INFO - 2018-02-16 16:25:27 --> Helper loaded: file_helper
INFO - 2018-02-16 16:25:27 --> Helper loaded: email_helper
INFO - 2018-02-16 16:25:27 --> Helper loaded: common_helper
INFO - 2018-02-16 16:25:27 --> Database Driver Class Initialized
DEBUG - 2018-02-16 16:25:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-16 16:25:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-16 16:25:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-16 16:25:27 --> Pagination Class Initialized
INFO - 2018-02-16 16:25:27 --> Helper loaded: form_helper
INFO - 2018-02-16 16:25:27 --> Form Validation Class Initialized
INFO - 2018-02-16 16:25:27 --> Model Class Initialized
INFO - 2018-02-16 16:25:27 --> Controller Class Initialized
INFO - 2018-02-16 16:25:27 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-16 16:25:27 --> Model Class Initialized
INFO - 2018-02-16 16:25:28 --> Config Class Initialized
INFO - 2018-02-16 16:25:28 --> Hooks Class Initialized
DEBUG - 2018-02-16 16:25:28 --> UTF-8 Support Enabled
INFO - 2018-02-16 16:25:28 --> Utf8 Class Initialized
INFO - 2018-02-16 16:25:28 --> URI Class Initialized
INFO - 2018-02-16 16:25:28 --> Router Class Initialized
INFO - 2018-02-16 16:25:28 --> Output Class Initialized
INFO - 2018-02-16 16:25:28 --> Security Class Initialized
DEBUG - 2018-02-16 16:25:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-16 16:25:28 --> Input Class Initialized
INFO - 2018-02-16 16:25:28 --> Language Class Initialized
INFO - 2018-02-16 16:25:28 --> Loader Class Initialized
INFO - 2018-02-16 16:25:28 --> Helper loaded: url_helper
INFO - 2018-02-16 16:25:28 --> Helper loaded: file_helper
INFO - 2018-02-16 16:25:28 --> Helper loaded: email_helper
INFO - 2018-02-16 16:25:28 --> Helper loaded: common_helper
INFO - 2018-02-16 16:25:28 --> Database Driver Class Initialized
DEBUG - 2018-02-16 16:25:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-16 16:25:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-16 16:25:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-16 16:25:28 --> Pagination Class Initialized
INFO - 2018-02-16 16:25:28 --> Helper loaded: form_helper
INFO - 2018-02-16 16:25:28 --> Form Validation Class Initialized
INFO - 2018-02-16 16:25:28 --> Model Class Initialized
INFO - 2018-02-16 16:25:28 --> Controller Class Initialized
INFO - 2018-02-16 16:25:28 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-16 16:25:28 --> Model Class Initialized
INFO - 2018-02-16 16:25:47 --> Config Class Initialized
INFO - 2018-02-16 16:25:47 --> Hooks Class Initialized
DEBUG - 2018-02-16 16:25:47 --> UTF-8 Support Enabled
INFO - 2018-02-16 16:25:47 --> Utf8 Class Initialized
INFO - 2018-02-16 16:25:47 --> URI Class Initialized
INFO - 2018-02-16 16:25:47 --> Router Class Initialized
INFO - 2018-02-16 16:25:47 --> Output Class Initialized
INFO - 2018-02-16 16:25:47 --> Security Class Initialized
DEBUG - 2018-02-16 16:25:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-16 16:25:47 --> Input Class Initialized
INFO - 2018-02-16 16:25:47 --> Language Class Initialized
INFO - 2018-02-16 16:25:47 --> Loader Class Initialized
INFO - 2018-02-16 16:25:47 --> Helper loaded: url_helper
INFO - 2018-02-16 16:25:47 --> Helper loaded: file_helper
INFO - 2018-02-16 16:25:47 --> Helper loaded: email_helper
INFO - 2018-02-16 16:25:47 --> Helper loaded: common_helper
INFO - 2018-02-16 16:25:47 --> Database Driver Class Initialized
DEBUG - 2018-02-16 16:25:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-16 16:25:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-16 16:25:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-16 16:25:47 --> Pagination Class Initialized
INFO - 2018-02-16 16:25:47 --> Helper loaded: form_helper
INFO - 2018-02-16 16:25:47 --> Form Validation Class Initialized
INFO - 2018-02-16 16:25:47 --> Model Class Initialized
INFO - 2018-02-16 16:25:47 --> Controller Class Initialized
INFO - 2018-02-16 16:25:47 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-16 16:25:47 --> Model Class Initialized
INFO - 2018-02-16 16:25:47 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-16 16:25:47 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-16 16:25:47 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-16 16:25:47 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-16 16:25:47 --> File loaded: /var/www/html/project/radio/application/views/user/index.php
INFO - 2018-02-16 16:25:47 --> Final output sent to browser
DEBUG - 2018-02-16 16:25:47 --> Total execution time: 0.0068
INFO - 2018-02-16 16:25:47 --> Config Class Initialized
INFO - 2018-02-16 16:25:47 --> Hooks Class Initialized
DEBUG - 2018-02-16 16:25:47 --> UTF-8 Support Enabled
INFO - 2018-02-16 16:25:47 --> Utf8 Class Initialized
INFO - 2018-02-16 16:25:47 --> URI Class Initialized
INFO - 2018-02-16 16:25:47 --> Router Class Initialized
INFO - 2018-02-16 16:25:47 --> Output Class Initialized
INFO - 2018-02-16 16:25:47 --> Security Class Initialized
DEBUG - 2018-02-16 16:25:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-16 16:25:47 --> Input Class Initialized
INFO - 2018-02-16 16:25:47 --> Language Class Initialized
INFO - 2018-02-16 16:25:47 --> Loader Class Initialized
INFO - 2018-02-16 16:25:47 --> Helper loaded: url_helper
INFO - 2018-02-16 16:25:47 --> Helper loaded: file_helper
INFO - 2018-02-16 16:25:47 --> Helper loaded: email_helper
INFO - 2018-02-16 16:25:47 --> Helper loaded: common_helper
INFO - 2018-02-16 16:25:47 --> Database Driver Class Initialized
DEBUG - 2018-02-16 16:25:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-16 16:25:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-16 16:25:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-16 16:25:47 --> Pagination Class Initialized
INFO - 2018-02-16 16:25:47 --> Helper loaded: form_helper
INFO - 2018-02-16 16:25:47 --> Form Validation Class Initialized
INFO - 2018-02-16 16:25:47 --> Model Class Initialized
INFO - 2018-02-16 16:25:47 --> Controller Class Initialized
INFO - 2018-02-16 16:25:47 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-16 16:25:47 --> Model Class Initialized
INFO - 2018-02-16 16:41:11 --> Config Class Initialized
INFO - 2018-02-16 16:41:11 --> Hooks Class Initialized
DEBUG - 2018-02-16 16:41:11 --> UTF-8 Support Enabled
INFO - 2018-02-16 16:41:11 --> Utf8 Class Initialized
INFO - 2018-02-16 16:41:11 --> URI Class Initialized
INFO - 2018-02-16 16:41:11 --> Router Class Initialized
INFO - 2018-02-16 16:41:11 --> Output Class Initialized
INFO - 2018-02-16 16:41:11 --> Security Class Initialized
DEBUG - 2018-02-16 16:41:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-16 16:41:11 --> Input Class Initialized
INFO - 2018-02-16 16:41:11 --> Language Class Initialized
INFO - 2018-02-16 16:41:11 --> Loader Class Initialized
INFO - 2018-02-16 16:41:11 --> Helper loaded: url_helper
INFO - 2018-02-16 16:41:11 --> Helper loaded: file_helper
INFO - 2018-02-16 16:41:11 --> Helper loaded: email_helper
INFO - 2018-02-16 16:41:11 --> Helper loaded: common_helper
INFO - 2018-02-16 16:41:11 --> Database Driver Class Initialized
DEBUG - 2018-02-16 16:41:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-16 16:41:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-16 16:41:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-16 16:41:11 --> Pagination Class Initialized
INFO - 2018-02-16 16:41:11 --> Helper loaded: form_helper
INFO - 2018-02-16 16:41:11 --> Form Validation Class Initialized
INFO - 2018-02-16 16:41:11 --> Model Class Initialized
INFO - 2018-02-16 16:41:11 --> Controller Class Initialized
INFO - 2018-02-16 16:41:11 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-16 16:41:11 --> Model Class Initialized
INFO - 2018-02-16 16:41:11 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-16 16:41:11 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-16 16:41:11 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-16 16:41:11 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-16 16:41:11 --> File loaded: /var/www/html/project/radio/application/views/user/index.php
INFO - 2018-02-16 16:41:11 --> Final output sent to browser
DEBUG - 2018-02-16 16:41:11 --> Total execution time: 0.0053
INFO - 2018-02-16 16:41:11 --> Config Class Initialized
INFO - 2018-02-16 16:41:11 --> Hooks Class Initialized
DEBUG - 2018-02-16 16:41:11 --> UTF-8 Support Enabled
INFO - 2018-02-16 16:41:11 --> Utf8 Class Initialized
INFO - 2018-02-16 16:41:11 --> URI Class Initialized
INFO - 2018-02-16 16:41:11 --> Router Class Initialized
INFO - 2018-02-16 16:41:11 --> Output Class Initialized
INFO - 2018-02-16 16:41:11 --> Security Class Initialized
DEBUG - 2018-02-16 16:41:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-16 16:41:11 --> Input Class Initialized
INFO - 2018-02-16 16:41:11 --> Language Class Initialized
INFO - 2018-02-16 16:41:11 --> Loader Class Initialized
INFO - 2018-02-16 16:41:11 --> Helper loaded: url_helper
INFO - 2018-02-16 16:41:11 --> Helper loaded: file_helper
INFO - 2018-02-16 16:41:11 --> Helper loaded: email_helper
INFO - 2018-02-16 16:41:11 --> Helper loaded: common_helper
INFO - 2018-02-16 16:41:11 --> Database Driver Class Initialized
DEBUG - 2018-02-16 16:41:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-16 16:41:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-16 16:41:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-16 16:41:11 --> Pagination Class Initialized
INFO - 2018-02-16 16:41:11 --> Helper loaded: form_helper
INFO - 2018-02-16 16:41:11 --> Form Validation Class Initialized
INFO - 2018-02-16 16:41:11 --> Model Class Initialized
INFO - 2018-02-16 16:41:11 --> Controller Class Initialized
INFO - 2018-02-16 16:41:11 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-16 16:41:11 --> Model Class Initialized
INFO - 2018-02-16 16:41:17 --> Config Class Initialized
INFO - 2018-02-16 16:41:17 --> Hooks Class Initialized
DEBUG - 2018-02-16 16:41:17 --> UTF-8 Support Enabled
INFO - 2018-02-16 16:41:17 --> Utf8 Class Initialized
INFO - 2018-02-16 16:41:17 --> URI Class Initialized
INFO - 2018-02-16 16:41:17 --> Router Class Initialized
INFO - 2018-02-16 16:41:17 --> Output Class Initialized
INFO - 2018-02-16 16:41:17 --> Security Class Initialized
DEBUG - 2018-02-16 16:41:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-16 16:41:17 --> Input Class Initialized
INFO - 2018-02-16 16:41:17 --> Language Class Initialized
INFO - 2018-02-16 16:41:17 --> Loader Class Initialized
INFO - 2018-02-16 16:41:17 --> Helper loaded: url_helper
INFO - 2018-02-16 16:41:17 --> Helper loaded: file_helper
INFO - 2018-02-16 16:41:17 --> Helper loaded: email_helper
INFO - 2018-02-16 16:41:17 --> Helper loaded: common_helper
INFO - 2018-02-16 16:41:17 --> Database Driver Class Initialized
DEBUG - 2018-02-16 16:41:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-16 16:41:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-16 16:41:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-16 16:41:17 --> Pagination Class Initialized
INFO - 2018-02-16 16:41:17 --> Helper loaded: form_helper
INFO - 2018-02-16 16:41:17 --> Form Validation Class Initialized
INFO - 2018-02-16 16:41:17 --> Model Class Initialized
INFO - 2018-02-16 16:41:17 --> Controller Class Initialized
INFO - 2018-02-16 16:41:17 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-16 16:41:17 --> Model Class Initialized
INFO - 2018-02-16 16:41:17 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-16 16:41:17 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-16 16:41:17 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-16 16:41:17 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-16 16:41:17 --> File loaded: /var/www/html/project/radio/application/views/category/index.php
INFO - 2018-02-16 16:41:17 --> Final output sent to browser
DEBUG - 2018-02-16 16:41:17 --> Total execution time: 0.0072
INFO - 2018-02-16 16:41:20 --> Config Class Initialized
INFO - 2018-02-16 16:41:20 --> Hooks Class Initialized
DEBUG - 2018-02-16 16:41:20 --> UTF-8 Support Enabled
INFO - 2018-02-16 16:41:20 --> Utf8 Class Initialized
INFO - 2018-02-16 16:41:20 --> URI Class Initialized
INFO - 2018-02-16 16:41:20 --> Router Class Initialized
INFO - 2018-02-16 16:41:20 --> Output Class Initialized
INFO - 2018-02-16 16:41:20 --> Security Class Initialized
DEBUG - 2018-02-16 16:41:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-16 16:41:20 --> Input Class Initialized
INFO - 2018-02-16 16:41:20 --> Language Class Initialized
INFO - 2018-02-16 16:41:20 --> Loader Class Initialized
INFO - 2018-02-16 16:41:20 --> Helper loaded: url_helper
INFO - 2018-02-16 16:41:20 --> Helper loaded: file_helper
INFO - 2018-02-16 16:41:20 --> Helper loaded: email_helper
INFO - 2018-02-16 16:41:20 --> Helper loaded: common_helper
INFO - 2018-02-16 16:41:20 --> Database Driver Class Initialized
DEBUG - 2018-02-16 16:41:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-16 16:41:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-16 16:41:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-16 16:41:20 --> Pagination Class Initialized
INFO - 2018-02-16 16:41:20 --> Helper loaded: form_helper
INFO - 2018-02-16 16:41:20 --> Form Validation Class Initialized
INFO - 2018-02-16 16:41:20 --> Model Class Initialized
INFO - 2018-02-16 16:41:20 --> Controller Class Initialized
INFO - 2018-02-16 16:41:20 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-16 16:41:20 --> Model Class Initialized
INFO - 2018-02-16 16:41:20 --> Model Class Initialized
INFO - 2018-02-16 16:41:20 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-16 16:41:20 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-16 16:41:20 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-16 16:41:20 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-16 16:41:20 --> File loaded: /var/www/html/project/radio/application/views/subcategory/index.php
INFO - 2018-02-16 16:41:20 --> Final output sent to browser
DEBUG - 2018-02-16 16:41:20 --> Total execution time: 0.0085
INFO - 2018-02-16 16:41:21 --> Config Class Initialized
INFO - 2018-02-16 16:41:21 --> Hooks Class Initialized
DEBUG - 2018-02-16 16:41:21 --> UTF-8 Support Enabled
INFO - 2018-02-16 16:41:21 --> Utf8 Class Initialized
INFO - 2018-02-16 16:41:21 --> URI Class Initialized
INFO - 2018-02-16 16:41:21 --> Router Class Initialized
INFO - 2018-02-16 16:41:21 --> Output Class Initialized
INFO - 2018-02-16 16:41:21 --> Security Class Initialized
DEBUG - 2018-02-16 16:41:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-16 16:41:21 --> Input Class Initialized
INFO - 2018-02-16 16:41:21 --> Language Class Initialized
INFO - 2018-02-16 16:41:21 --> Loader Class Initialized
INFO - 2018-02-16 16:41:21 --> Helper loaded: url_helper
INFO - 2018-02-16 16:41:21 --> Helper loaded: file_helper
INFO - 2018-02-16 16:41:21 --> Helper loaded: email_helper
INFO - 2018-02-16 16:41:21 --> Helper loaded: common_helper
INFO - 2018-02-16 16:41:21 --> Database Driver Class Initialized
DEBUG - 2018-02-16 16:41:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-16 16:41:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-16 16:41:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-16 16:41:21 --> Pagination Class Initialized
INFO - 2018-02-16 16:41:21 --> Helper loaded: form_helper
INFO - 2018-02-16 16:41:21 --> Form Validation Class Initialized
INFO - 2018-02-16 16:41:21 --> Model Class Initialized
INFO - 2018-02-16 16:41:21 --> Controller Class Initialized
INFO - 2018-02-16 16:41:21 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-16 16:41:21 --> Model Class Initialized
INFO - 2018-02-16 16:41:21 --> Model Class Initialized
INFO - 2018-02-16 16:41:21 --> Model Class Initialized
INFO - 2018-02-16 16:41:21 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-16 16:41:21 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-16 16:41:21 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-16 16:41:21 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-16 16:41:21 --> File loaded: /var/www/html/project/radio/application/views/tracks/index.php
INFO - 2018-02-16 16:41:21 --> Final output sent to browser
DEBUG - 2018-02-16 16:41:21 --> Total execution time: 0.0048
INFO - 2018-02-16 16:41:22 --> Config Class Initialized
INFO - 2018-02-16 16:41:22 --> Hooks Class Initialized
DEBUG - 2018-02-16 16:41:22 --> UTF-8 Support Enabled
INFO - 2018-02-16 16:41:22 --> Utf8 Class Initialized
INFO - 2018-02-16 16:41:22 --> URI Class Initialized
INFO - 2018-02-16 16:41:22 --> Router Class Initialized
INFO - 2018-02-16 16:41:22 --> Output Class Initialized
INFO - 2018-02-16 16:41:22 --> Security Class Initialized
DEBUG - 2018-02-16 16:41:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-16 16:41:22 --> Input Class Initialized
INFO - 2018-02-16 16:41:22 --> Language Class Initialized
INFO - 2018-02-16 16:41:22 --> Loader Class Initialized
INFO - 2018-02-16 16:41:22 --> Helper loaded: url_helper
INFO - 2018-02-16 16:41:22 --> Helper loaded: file_helper
INFO - 2018-02-16 16:41:22 --> Helper loaded: email_helper
INFO - 2018-02-16 16:41:22 --> Helper loaded: common_helper
INFO - 2018-02-16 16:41:22 --> Database Driver Class Initialized
DEBUG - 2018-02-16 16:41:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-16 16:41:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-16 16:41:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-16 16:41:22 --> Pagination Class Initialized
INFO - 2018-02-16 16:41:22 --> Helper loaded: form_helper
INFO - 2018-02-16 16:41:22 --> Form Validation Class Initialized
INFO - 2018-02-16 16:41:22 --> Model Class Initialized
INFO - 2018-02-16 16:41:22 --> Controller Class Initialized
INFO - 2018-02-16 16:41:22 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-16 16:41:22 --> Model Class Initialized
INFO - 2018-02-16 16:41:22 --> Model Class Initialized
INFO - 2018-02-16 16:41:22 --> Model Class Initialized
INFO - 2018-02-16 16:41:45 --> Config Class Initialized
INFO - 2018-02-16 16:41:45 --> Hooks Class Initialized
DEBUG - 2018-02-16 16:41:45 --> UTF-8 Support Enabled
INFO - 2018-02-16 16:41:45 --> Utf8 Class Initialized
INFO - 2018-02-16 16:41:45 --> URI Class Initialized
INFO - 2018-02-16 16:41:45 --> Router Class Initialized
INFO - 2018-02-16 16:41:45 --> Output Class Initialized
INFO - 2018-02-16 16:41:45 --> Security Class Initialized
DEBUG - 2018-02-16 16:41:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-16 16:41:45 --> Input Class Initialized
INFO - 2018-02-16 16:41:45 --> Language Class Initialized
INFO - 2018-02-16 16:41:45 --> Loader Class Initialized
INFO - 2018-02-16 16:41:45 --> Helper loaded: url_helper
INFO - 2018-02-16 16:41:45 --> Helper loaded: file_helper
INFO - 2018-02-16 16:41:45 --> Helper loaded: email_helper
INFO - 2018-02-16 16:41:45 --> Helper loaded: common_helper
INFO - 2018-02-16 16:41:45 --> Database Driver Class Initialized
DEBUG - 2018-02-16 16:41:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-16 16:41:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-16 16:41:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-16 16:41:45 --> Pagination Class Initialized
INFO - 2018-02-16 16:41:45 --> Helper loaded: form_helper
INFO - 2018-02-16 16:41:45 --> Form Validation Class Initialized
INFO - 2018-02-16 16:41:45 --> Model Class Initialized
INFO - 2018-02-16 16:41:45 --> Controller Class Initialized
INFO - 2018-02-16 16:41:45 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-16 16:41:45 --> Model Class Initialized
INFO - 2018-02-16 16:41:45 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-16 16:41:45 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-16 16:41:45 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-16 16:41:45 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-16 16:41:45 --> File loaded: /var/www/html/project/radio/application/views/staticpages/index.php
INFO - 2018-02-16 16:41:45 --> Final output sent to browser
DEBUG - 2018-02-16 16:41:45 --> Total execution time: 0.0076
INFO - 2018-02-16 17:10:29 --> Config Class Initialized
INFO - 2018-02-16 17:10:29 --> Hooks Class Initialized
DEBUG - 2018-02-16 17:10:29 --> UTF-8 Support Enabled
INFO - 2018-02-16 17:10:29 --> Utf8 Class Initialized
INFO - 2018-02-16 17:10:29 --> URI Class Initialized
DEBUG - 2018-02-16 17:10:29 --> No URI present. Default controller set.
INFO - 2018-02-16 17:10:29 --> Router Class Initialized
INFO - 2018-02-16 17:10:29 --> Output Class Initialized
INFO - 2018-02-16 17:10:29 --> Security Class Initialized
DEBUG - 2018-02-16 17:10:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-16 17:10:29 --> Input Class Initialized
INFO - 2018-02-16 17:10:29 --> Language Class Initialized
INFO - 2018-02-16 17:10:29 --> Loader Class Initialized
INFO - 2018-02-16 17:10:29 --> Helper loaded: url_helper
INFO - 2018-02-16 17:10:29 --> Helper loaded: file_helper
INFO - 2018-02-16 17:10:29 --> Helper loaded: email_helper
INFO - 2018-02-16 17:10:29 --> Helper loaded: common_helper
INFO - 2018-02-16 17:10:29 --> Database Driver Class Initialized
DEBUG - 2018-02-16 17:10:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-16 17:10:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-16 17:10:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-16 17:10:29 --> Pagination Class Initialized
INFO - 2018-02-16 17:10:29 --> Helper loaded: form_helper
INFO - 2018-02-16 17:10:29 --> Form Validation Class Initialized
INFO - 2018-02-16 17:10:29 --> Model Class Initialized
INFO - 2018-02-16 17:10:29 --> Controller Class Initialized
INFO - 2018-02-16 17:10:29 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-16 17:10:29 --> Model Class Initialized
INFO - 2018-02-16 17:10:29 --> File loaded: /var/www/html/project/radio/application/views/index/index.php
INFO - 2018-02-16 17:10:29 --> Final output sent to browser
DEBUG - 2018-02-16 17:10:29 --> Total execution time: 0.0055
INFO - 2018-02-16 17:10:33 --> Config Class Initialized
INFO - 2018-02-16 17:10:33 --> Hooks Class Initialized
DEBUG - 2018-02-16 17:10:33 --> UTF-8 Support Enabled
INFO - 2018-02-16 17:10:33 --> Utf8 Class Initialized
INFO - 2018-02-16 17:10:33 --> URI Class Initialized
INFO - 2018-02-16 17:10:33 --> Router Class Initialized
INFO - 2018-02-16 17:10:33 --> Output Class Initialized
INFO - 2018-02-16 17:10:33 --> Security Class Initialized
DEBUG - 2018-02-16 17:10:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-16 17:10:33 --> Input Class Initialized
INFO - 2018-02-16 17:10:33 --> Language Class Initialized
INFO - 2018-02-16 17:10:33 --> Loader Class Initialized
INFO - 2018-02-16 17:10:33 --> Helper loaded: url_helper
INFO - 2018-02-16 17:10:33 --> Helper loaded: file_helper
INFO - 2018-02-16 17:10:33 --> Helper loaded: email_helper
INFO - 2018-02-16 17:10:33 --> Helper loaded: common_helper
INFO - 2018-02-16 17:10:33 --> Database Driver Class Initialized
DEBUG - 2018-02-16 17:10:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-16 17:10:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-16 17:10:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-16 17:10:33 --> Pagination Class Initialized
INFO - 2018-02-16 17:10:33 --> Helper loaded: form_helper
INFO - 2018-02-16 17:10:33 --> Form Validation Class Initialized
INFO - 2018-02-16 17:10:33 --> Model Class Initialized
INFO - 2018-02-16 17:10:33 --> Controller Class Initialized
INFO - 2018-02-16 17:10:33 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-16 17:10:33 --> Model Class Initialized
ERROR - 2018-02-16 17:10:33 --> Severity: Notice --> Undefined index: remember_me /var/www/html/project/radio/application/controllers/Index.php 73
INFO - 2018-02-16 17:10:33 --> Config Class Initialized
INFO - 2018-02-16 17:10:33 --> Hooks Class Initialized
DEBUG - 2018-02-16 17:10:33 --> UTF-8 Support Enabled
INFO - 2018-02-16 17:10:33 --> Utf8 Class Initialized
INFO - 2018-02-16 17:10:33 --> URI Class Initialized
INFO - 2018-02-16 17:10:33 --> Router Class Initialized
INFO - 2018-02-16 17:10:33 --> Output Class Initialized
INFO - 2018-02-16 17:10:33 --> Security Class Initialized
DEBUG - 2018-02-16 17:10:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-16 17:10:33 --> Input Class Initialized
INFO - 2018-02-16 17:10:33 --> Language Class Initialized
INFO - 2018-02-16 17:10:33 --> Loader Class Initialized
INFO - 2018-02-16 17:10:33 --> Helper loaded: url_helper
INFO - 2018-02-16 17:10:33 --> Helper loaded: file_helper
INFO - 2018-02-16 17:10:33 --> Helper loaded: email_helper
INFO - 2018-02-16 17:10:33 --> Helper loaded: common_helper
INFO - 2018-02-16 17:10:33 --> Database Driver Class Initialized
DEBUG - 2018-02-16 17:10:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-16 17:10:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-16 17:10:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-16 17:10:33 --> Pagination Class Initialized
INFO - 2018-02-16 17:10:33 --> Helper loaded: form_helper
INFO - 2018-02-16 17:10:33 --> Form Validation Class Initialized
INFO - 2018-02-16 17:10:33 --> Model Class Initialized
INFO - 2018-02-16 17:10:33 --> Controller Class Initialized
INFO - 2018-02-16 17:10:33 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-16 17:10:33 --> Model Class Initialized
INFO - 2018-02-16 17:10:33 --> Model Class Initialized
INFO - 2018-02-16 17:10:33 --> Model Class Initialized
INFO - 2018-02-16 17:10:33 --> Model Class Initialized
INFO - 2018-02-16 17:10:33 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-16 17:10:33 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-16 17:10:33 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-16 17:10:33 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-16 17:10:33 --> File loaded: /var/www/html/project/radio/application/views/dashboard/index.php
INFO - 2018-02-16 17:10:33 --> Final output sent to browser
DEBUG - 2018-02-16 17:10:33 --> Total execution time: 0.0064
INFO - 2018-02-16 17:10:41 --> Config Class Initialized
INFO - 2018-02-16 17:10:41 --> Hooks Class Initialized
DEBUG - 2018-02-16 17:10:41 --> UTF-8 Support Enabled
INFO - 2018-02-16 17:10:41 --> Utf8 Class Initialized
INFO - 2018-02-16 17:10:41 --> URI Class Initialized
INFO - 2018-02-16 17:10:41 --> Router Class Initialized
INFO - 2018-02-16 17:10:41 --> Output Class Initialized
INFO - 2018-02-16 17:10:41 --> Security Class Initialized
DEBUG - 2018-02-16 17:10:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-16 17:10:41 --> Input Class Initialized
INFO - 2018-02-16 17:10:41 --> Language Class Initialized
INFO - 2018-02-16 17:10:41 --> Loader Class Initialized
INFO - 2018-02-16 17:10:41 --> Helper loaded: url_helper
INFO - 2018-02-16 17:10:41 --> Helper loaded: file_helper
INFO - 2018-02-16 17:10:41 --> Helper loaded: email_helper
INFO - 2018-02-16 17:10:41 --> Helper loaded: common_helper
INFO - 2018-02-16 17:10:41 --> Database Driver Class Initialized
DEBUG - 2018-02-16 17:10:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-16 17:10:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-16 17:10:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-16 17:10:41 --> Pagination Class Initialized
INFO - 2018-02-16 17:10:41 --> Helper loaded: form_helper
INFO - 2018-02-16 17:10:41 --> Form Validation Class Initialized
INFO - 2018-02-16 17:10:41 --> Model Class Initialized
INFO - 2018-02-16 17:10:41 --> Controller Class Initialized
INFO - 2018-02-16 17:10:41 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-16 17:10:41 --> Model Class Initialized
INFO - 2018-02-16 17:10:41 --> Model Class Initialized
INFO - 2018-02-16 17:10:41 --> Model Class Initialized
INFO - 2018-02-16 17:10:41 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-16 17:10:41 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-16 17:10:41 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-16 17:10:41 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-16 17:10:41 --> File loaded: /var/www/html/project/radio/application/views/tracks/index.php
INFO - 2018-02-16 17:10:41 --> Final output sent to browser
DEBUG - 2018-02-16 17:10:41 --> Total execution time: 0.0069
INFO - 2018-02-16 17:10:41 --> Config Class Initialized
INFO - 2018-02-16 17:10:41 --> Hooks Class Initialized
DEBUG - 2018-02-16 17:10:41 --> UTF-8 Support Enabled
INFO - 2018-02-16 17:10:41 --> Utf8 Class Initialized
INFO - 2018-02-16 17:10:41 --> URI Class Initialized
INFO - 2018-02-16 17:10:41 --> Router Class Initialized
INFO - 2018-02-16 17:10:41 --> Output Class Initialized
INFO - 2018-02-16 17:10:41 --> Security Class Initialized
DEBUG - 2018-02-16 17:10:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-16 17:10:41 --> Input Class Initialized
INFO - 2018-02-16 17:10:41 --> Language Class Initialized
INFO - 2018-02-16 17:10:41 --> Loader Class Initialized
INFO - 2018-02-16 17:10:41 --> Helper loaded: url_helper
INFO - 2018-02-16 17:10:41 --> Helper loaded: file_helper
INFO - 2018-02-16 17:10:41 --> Helper loaded: email_helper
INFO - 2018-02-16 17:10:41 --> Helper loaded: common_helper
INFO - 2018-02-16 17:10:41 --> Database Driver Class Initialized
DEBUG - 2018-02-16 17:10:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-16 17:10:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-16 17:10:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-16 17:10:41 --> Pagination Class Initialized
INFO - 2018-02-16 17:10:41 --> Helper loaded: form_helper
INFO - 2018-02-16 17:10:41 --> Form Validation Class Initialized
INFO - 2018-02-16 17:10:41 --> Model Class Initialized
INFO - 2018-02-16 17:10:41 --> Controller Class Initialized
INFO - 2018-02-16 17:10:41 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-16 17:10:41 --> Model Class Initialized
INFO - 2018-02-16 17:10:41 --> Model Class Initialized
INFO - 2018-02-16 17:10:41 --> Model Class Initialized
INFO - 2018-02-16 17:14:58 --> Config Class Initialized
INFO - 2018-02-16 17:14:58 --> Hooks Class Initialized
DEBUG - 2018-02-16 17:14:58 --> UTF-8 Support Enabled
INFO - 2018-02-16 17:14:58 --> Utf8 Class Initialized
INFO - 2018-02-16 17:14:58 --> URI Class Initialized
INFO - 2018-02-16 17:14:58 --> Router Class Initialized
INFO - 2018-02-16 17:14:58 --> Output Class Initialized
INFO - 2018-02-16 17:14:58 --> Security Class Initialized
DEBUG - 2018-02-16 17:14:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-16 17:14:58 --> Input Class Initialized
INFO - 2018-02-16 17:14:58 --> Language Class Initialized
INFO - 2018-02-16 17:14:58 --> Loader Class Initialized
INFO - 2018-02-16 17:14:58 --> Helper loaded: url_helper
INFO - 2018-02-16 17:14:58 --> Helper loaded: file_helper
INFO - 2018-02-16 17:14:58 --> Helper loaded: email_helper
INFO - 2018-02-16 17:14:58 --> Helper loaded: common_helper
INFO - 2018-02-16 17:14:58 --> Database Driver Class Initialized
DEBUG - 2018-02-16 17:14:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-16 17:14:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-16 17:14:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-16 17:14:58 --> Pagination Class Initialized
INFO - 2018-02-16 17:14:58 --> Helper loaded: form_helper
INFO - 2018-02-16 17:14:58 --> Form Validation Class Initialized
INFO - 2018-02-16 17:14:58 --> Model Class Initialized
INFO - 2018-02-16 17:14:58 --> Controller Class Initialized
INFO - 2018-02-16 17:14:58 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-16 17:14:58 --> Model Class Initialized
INFO - 2018-02-16 17:14:58 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-16 17:14:58 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-16 17:14:58 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-16 17:14:58 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-16 17:14:58 --> File loaded: /var/www/html/project/radio/application/views/category/index.php
INFO - 2018-02-16 17:14:58 --> Final output sent to browser
DEBUG - 2018-02-16 17:14:58 --> Total execution time: 0.0075
INFO - 2018-02-16 17:15:00 --> Config Class Initialized
INFO - 2018-02-16 17:15:00 --> Hooks Class Initialized
DEBUG - 2018-02-16 17:15:00 --> UTF-8 Support Enabled
INFO - 2018-02-16 17:15:00 --> Utf8 Class Initialized
INFO - 2018-02-16 17:15:00 --> URI Class Initialized
INFO - 2018-02-16 17:15:00 --> Router Class Initialized
INFO - 2018-02-16 17:15:00 --> Output Class Initialized
INFO - 2018-02-16 17:15:00 --> Security Class Initialized
DEBUG - 2018-02-16 17:15:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-16 17:15:00 --> Input Class Initialized
INFO - 2018-02-16 17:15:00 --> Language Class Initialized
INFO - 2018-02-16 17:15:00 --> Loader Class Initialized
INFO - 2018-02-16 17:15:00 --> Helper loaded: url_helper
INFO - 2018-02-16 17:15:00 --> Helper loaded: file_helper
INFO - 2018-02-16 17:15:00 --> Helper loaded: email_helper
INFO - 2018-02-16 17:15:00 --> Helper loaded: common_helper
INFO - 2018-02-16 17:15:00 --> Database Driver Class Initialized
DEBUG - 2018-02-16 17:15:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-16 17:15:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-16 17:15:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-16 17:15:00 --> Pagination Class Initialized
INFO - 2018-02-16 17:15:00 --> Helper loaded: form_helper
INFO - 2018-02-16 17:15:00 --> Form Validation Class Initialized
INFO - 2018-02-16 17:15:00 --> Model Class Initialized
INFO - 2018-02-16 17:15:00 --> Controller Class Initialized
INFO - 2018-02-16 17:15:00 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-16 17:15:00 --> Model Class Initialized
INFO - 2018-02-16 17:15:00 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-16 17:15:00 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-16 17:15:00 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-16 17:15:00 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-16 17:15:00 --> File loaded: /var/www/html/project/radio/application/views/category/add_edit.php
INFO - 2018-02-16 17:15:00 --> Final output sent to browser
DEBUG - 2018-02-16 17:15:00 --> Total execution time: 0.0061
INFO - 2018-02-16 17:15:06 --> Config Class Initialized
INFO - 2018-02-16 17:15:06 --> Hooks Class Initialized
DEBUG - 2018-02-16 17:15:06 --> UTF-8 Support Enabled
INFO - 2018-02-16 17:15:06 --> Utf8 Class Initialized
INFO - 2018-02-16 17:15:06 --> URI Class Initialized
INFO - 2018-02-16 17:15:06 --> Router Class Initialized
INFO - 2018-02-16 17:15:06 --> Output Class Initialized
INFO - 2018-02-16 17:15:06 --> Security Class Initialized
DEBUG - 2018-02-16 17:15:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-16 17:15:06 --> Input Class Initialized
INFO - 2018-02-16 17:15:06 --> Language Class Initialized
INFO - 2018-02-16 17:15:06 --> Loader Class Initialized
INFO - 2018-02-16 17:15:06 --> Helper loaded: url_helper
INFO - 2018-02-16 17:15:06 --> Helper loaded: file_helper
INFO - 2018-02-16 17:15:06 --> Helper loaded: email_helper
INFO - 2018-02-16 17:15:06 --> Helper loaded: common_helper
INFO - 2018-02-16 17:15:06 --> Database Driver Class Initialized
DEBUG - 2018-02-16 17:15:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-16 17:15:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-16 17:15:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-16 17:15:06 --> Pagination Class Initialized
INFO - 2018-02-16 17:15:06 --> Helper loaded: form_helper
INFO - 2018-02-16 17:15:06 --> Form Validation Class Initialized
INFO - 2018-02-16 17:15:06 --> Model Class Initialized
INFO - 2018-02-16 17:15:06 --> Controller Class Initialized
INFO - 2018-02-16 17:15:06 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-16 17:15:06 --> Model Class Initialized
INFO - 2018-02-16 17:15:06 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-16 17:15:06 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-16 17:15:06 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-16 17:15:06 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-16 17:15:06 --> File loaded: /var/www/html/project/radio/application/views/category/index.php
INFO - 2018-02-16 17:15:06 --> Final output sent to browser
DEBUG - 2018-02-16 17:15:06 --> Total execution time: 0.0078
INFO - 2018-02-16 17:15:08 --> Config Class Initialized
INFO - 2018-02-16 17:15:08 --> Hooks Class Initialized
DEBUG - 2018-02-16 17:15:08 --> UTF-8 Support Enabled
INFO - 2018-02-16 17:15:08 --> Utf8 Class Initialized
INFO - 2018-02-16 17:15:08 --> URI Class Initialized
INFO - 2018-02-16 17:15:08 --> Router Class Initialized
INFO - 2018-02-16 17:15:08 --> Output Class Initialized
INFO - 2018-02-16 17:15:08 --> Security Class Initialized
DEBUG - 2018-02-16 17:15:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-16 17:15:08 --> Input Class Initialized
INFO - 2018-02-16 17:15:08 --> Language Class Initialized
INFO - 2018-02-16 17:15:08 --> Loader Class Initialized
INFO - 2018-02-16 17:15:08 --> Helper loaded: url_helper
INFO - 2018-02-16 17:15:08 --> Helper loaded: file_helper
INFO - 2018-02-16 17:15:08 --> Helper loaded: email_helper
INFO - 2018-02-16 17:15:08 --> Helper loaded: common_helper
INFO - 2018-02-16 17:15:08 --> Database Driver Class Initialized
DEBUG - 2018-02-16 17:15:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-16 17:15:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-16 17:15:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-16 17:15:08 --> Pagination Class Initialized
INFO - 2018-02-16 17:15:08 --> Helper loaded: form_helper
INFO - 2018-02-16 17:15:08 --> Form Validation Class Initialized
INFO - 2018-02-16 17:15:08 --> Model Class Initialized
INFO - 2018-02-16 17:15:08 --> Controller Class Initialized
INFO - 2018-02-16 17:15:08 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-16 17:15:08 --> Model Class Initialized
INFO - 2018-02-16 17:15:08 --> Model Class Initialized
INFO - 2018-02-16 17:15:08 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-16 17:15:08 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-16 17:15:08 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-16 17:15:08 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-16 17:15:08 --> File loaded: /var/www/html/project/radio/application/views/subcategory/index.php
INFO - 2018-02-16 17:15:08 --> Final output sent to browser
DEBUG - 2018-02-16 17:15:08 --> Total execution time: 0.0047
INFO - 2018-02-16 17:15:09 --> Config Class Initialized
INFO - 2018-02-16 17:15:09 --> Hooks Class Initialized
DEBUG - 2018-02-16 17:15:09 --> UTF-8 Support Enabled
INFO - 2018-02-16 17:15:09 --> Utf8 Class Initialized
INFO - 2018-02-16 17:15:09 --> URI Class Initialized
INFO - 2018-02-16 17:15:09 --> Router Class Initialized
INFO - 2018-02-16 17:15:09 --> Output Class Initialized
INFO - 2018-02-16 17:15:09 --> Security Class Initialized
DEBUG - 2018-02-16 17:15:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-16 17:15:09 --> Input Class Initialized
INFO - 2018-02-16 17:15:09 --> Language Class Initialized
INFO - 2018-02-16 17:15:09 --> Loader Class Initialized
INFO - 2018-02-16 17:15:09 --> Helper loaded: url_helper
INFO - 2018-02-16 17:15:09 --> Helper loaded: file_helper
INFO - 2018-02-16 17:15:09 --> Helper loaded: email_helper
INFO - 2018-02-16 17:15:09 --> Helper loaded: common_helper
INFO - 2018-02-16 17:15:09 --> Database Driver Class Initialized
DEBUG - 2018-02-16 17:15:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-16 17:15:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-16 17:15:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-16 17:15:09 --> Pagination Class Initialized
INFO - 2018-02-16 17:15:09 --> Helper loaded: form_helper
INFO - 2018-02-16 17:15:09 --> Form Validation Class Initialized
INFO - 2018-02-16 17:15:09 --> Model Class Initialized
INFO - 2018-02-16 17:15:09 --> Controller Class Initialized
INFO - 2018-02-16 17:15:09 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-16 17:15:09 --> Model Class Initialized
INFO - 2018-02-16 17:15:09 --> Model Class Initialized
INFO - 2018-02-16 17:15:09 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-16 17:15:09 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-16 17:15:09 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-16 17:15:09 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-16 17:15:09 --> File loaded: /var/www/html/project/radio/application/views/subcategory/add_edit.php
INFO - 2018-02-16 17:15:09 --> Final output sent to browser
DEBUG - 2018-02-16 17:15:09 --> Total execution time: 0.0078
INFO - 2018-02-16 17:15:17 --> Config Class Initialized
INFO - 2018-02-16 17:15:17 --> Hooks Class Initialized
DEBUG - 2018-02-16 17:15:17 --> UTF-8 Support Enabled
INFO - 2018-02-16 17:15:17 --> Utf8 Class Initialized
INFO - 2018-02-16 17:15:17 --> URI Class Initialized
INFO - 2018-02-16 17:15:17 --> Router Class Initialized
INFO - 2018-02-16 17:15:17 --> Output Class Initialized
INFO - 2018-02-16 17:15:17 --> Security Class Initialized
DEBUG - 2018-02-16 17:15:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-16 17:15:17 --> Input Class Initialized
INFO - 2018-02-16 17:15:17 --> Language Class Initialized
INFO - 2018-02-16 17:15:17 --> Loader Class Initialized
INFO - 2018-02-16 17:15:17 --> Helper loaded: url_helper
INFO - 2018-02-16 17:15:17 --> Helper loaded: file_helper
INFO - 2018-02-16 17:15:17 --> Helper loaded: email_helper
INFO - 2018-02-16 17:15:17 --> Helper loaded: common_helper
INFO - 2018-02-16 17:15:17 --> Database Driver Class Initialized
DEBUG - 2018-02-16 17:15:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-16 17:15:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-16 17:15:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-16 17:15:17 --> Pagination Class Initialized
INFO - 2018-02-16 17:15:17 --> Helper loaded: form_helper
INFO - 2018-02-16 17:15:17 --> Form Validation Class Initialized
INFO - 2018-02-16 17:15:17 --> Model Class Initialized
INFO - 2018-02-16 17:15:17 --> Controller Class Initialized
INFO - 2018-02-16 17:15:17 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-16 17:15:17 --> Model Class Initialized
INFO - 2018-02-16 17:15:17 --> Model Class Initialized
INFO - 2018-02-16 17:15:17 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-16 17:15:17 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-16 17:15:17 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-16 17:15:17 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-16 17:15:17 --> File loaded: /var/www/html/project/radio/application/views/subcategory/index.php
INFO - 2018-02-16 17:15:17 --> Final output sent to browser
DEBUG - 2018-02-16 17:15:17 --> Total execution time: 0.0073
INFO - 2018-02-16 17:15:18 --> Config Class Initialized
INFO - 2018-02-16 17:15:18 --> Hooks Class Initialized
DEBUG - 2018-02-16 17:15:18 --> UTF-8 Support Enabled
INFO - 2018-02-16 17:15:18 --> Utf8 Class Initialized
INFO - 2018-02-16 17:15:18 --> URI Class Initialized
INFO - 2018-02-16 17:15:18 --> Router Class Initialized
INFO - 2018-02-16 17:15:18 --> Output Class Initialized
INFO - 2018-02-16 17:15:18 --> Security Class Initialized
DEBUG - 2018-02-16 17:15:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-16 17:15:18 --> Input Class Initialized
INFO - 2018-02-16 17:15:18 --> Language Class Initialized
INFO - 2018-02-16 17:15:18 --> Loader Class Initialized
INFO - 2018-02-16 17:15:18 --> Helper loaded: url_helper
INFO - 2018-02-16 17:15:18 --> Helper loaded: file_helper
INFO - 2018-02-16 17:15:18 --> Helper loaded: email_helper
INFO - 2018-02-16 17:15:18 --> Helper loaded: common_helper
INFO - 2018-02-16 17:15:18 --> Database Driver Class Initialized
DEBUG - 2018-02-16 17:15:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-16 17:15:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-16 17:15:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-16 17:15:18 --> Pagination Class Initialized
INFO - 2018-02-16 17:15:18 --> Helper loaded: form_helper
INFO - 2018-02-16 17:15:18 --> Form Validation Class Initialized
INFO - 2018-02-16 17:15:18 --> Model Class Initialized
INFO - 2018-02-16 17:15:18 --> Controller Class Initialized
INFO - 2018-02-16 17:15:18 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-16 17:15:18 --> Model Class Initialized
INFO - 2018-02-16 17:15:18 --> Model Class Initialized
INFO - 2018-02-16 17:15:18 --> Model Class Initialized
INFO - 2018-02-16 17:15:18 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-16 17:15:18 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-16 17:15:18 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-16 17:15:18 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-16 17:15:18 --> File loaded: /var/www/html/project/radio/application/views/tracks/index.php
INFO - 2018-02-16 17:15:18 --> Final output sent to browser
DEBUG - 2018-02-16 17:15:18 --> Total execution time: 0.0040
INFO - 2018-02-16 17:15:18 --> Config Class Initialized
INFO - 2018-02-16 17:15:18 --> Hooks Class Initialized
DEBUG - 2018-02-16 17:15:18 --> UTF-8 Support Enabled
INFO - 2018-02-16 17:15:18 --> Utf8 Class Initialized
INFO - 2018-02-16 17:15:18 --> URI Class Initialized
INFO - 2018-02-16 17:15:18 --> Router Class Initialized
INFO - 2018-02-16 17:15:18 --> Output Class Initialized
INFO - 2018-02-16 17:15:18 --> Security Class Initialized
DEBUG - 2018-02-16 17:15:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-16 17:15:18 --> Input Class Initialized
INFO - 2018-02-16 17:15:18 --> Language Class Initialized
INFO - 2018-02-16 17:15:18 --> Loader Class Initialized
INFO - 2018-02-16 17:15:18 --> Helper loaded: url_helper
INFO - 2018-02-16 17:15:18 --> Helper loaded: file_helper
INFO - 2018-02-16 17:15:18 --> Helper loaded: email_helper
INFO - 2018-02-16 17:15:18 --> Helper loaded: common_helper
INFO - 2018-02-16 17:15:18 --> Database Driver Class Initialized
DEBUG - 2018-02-16 17:15:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-16 17:15:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-16 17:15:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-16 17:15:18 --> Pagination Class Initialized
INFO - 2018-02-16 17:15:18 --> Helper loaded: form_helper
INFO - 2018-02-16 17:15:18 --> Form Validation Class Initialized
INFO - 2018-02-16 17:15:18 --> Model Class Initialized
INFO - 2018-02-16 17:15:18 --> Controller Class Initialized
INFO - 2018-02-16 17:15:18 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-16 17:15:18 --> Model Class Initialized
INFO - 2018-02-16 17:15:18 --> Model Class Initialized
INFO - 2018-02-16 17:15:18 --> Model Class Initialized
INFO - 2018-02-16 17:15:21 --> Config Class Initialized
INFO - 2018-02-16 17:15:21 --> Hooks Class Initialized
DEBUG - 2018-02-16 17:15:21 --> UTF-8 Support Enabled
INFO - 2018-02-16 17:15:21 --> Utf8 Class Initialized
INFO - 2018-02-16 17:15:21 --> URI Class Initialized
INFO - 2018-02-16 17:15:21 --> Router Class Initialized
INFO - 2018-02-16 17:15:21 --> Output Class Initialized
INFO - 2018-02-16 17:15:21 --> Security Class Initialized
DEBUG - 2018-02-16 17:15:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-16 17:15:21 --> Input Class Initialized
INFO - 2018-02-16 17:15:21 --> Language Class Initialized
INFO - 2018-02-16 17:15:21 --> Loader Class Initialized
INFO - 2018-02-16 17:15:21 --> Helper loaded: url_helper
INFO - 2018-02-16 17:15:21 --> Helper loaded: file_helper
INFO - 2018-02-16 17:15:21 --> Helper loaded: email_helper
INFO - 2018-02-16 17:15:21 --> Helper loaded: common_helper
INFO - 2018-02-16 17:15:21 --> Database Driver Class Initialized
DEBUG - 2018-02-16 17:15:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-16 17:15:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-16 17:15:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-16 17:15:21 --> Pagination Class Initialized
INFO - 2018-02-16 17:15:21 --> Helper loaded: form_helper
INFO - 2018-02-16 17:15:21 --> Form Validation Class Initialized
INFO - 2018-02-16 17:15:21 --> Model Class Initialized
INFO - 2018-02-16 17:15:21 --> Controller Class Initialized
INFO - 2018-02-16 17:15:21 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-16 17:15:21 --> Model Class Initialized
INFO - 2018-02-16 17:15:21 --> Model Class Initialized
INFO - 2018-02-16 17:15:21 --> Model Class Initialized
INFO - 2018-02-16 17:15:21 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-16 17:15:21 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-16 17:15:21 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-16 17:15:21 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-16 17:15:21 --> File loaded: /var/www/html/project/radio/application/views/tracks/add_edit.php
INFO - 2018-02-16 17:15:21 --> Final output sent to browser
DEBUG - 2018-02-16 17:15:21 --> Total execution time: 0.0076
INFO - 2018-02-16 17:34:29 --> Config Class Initialized
INFO - 2018-02-16 17:34:29 --> Hooks Class Initialized
DEBUG - 2018-02-16 17:34:29 --> UTF-8 Support Enabled
INFO - 2018-02-16 17:34:29 --> Utf8 Class Initialized
INFO - 2018-02-16 17:34:29 --> URI Class Initialized
INFO - 2018-02-16 17:34:29 --> Router Class Initialized
INFO - 2018-02-16 17:34:29 --> Output Class Initialized
INFO - 2018-02-16 17:34:29 --> Security Class Initialized
DEBUG - 2018-02-16 17:34:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-16 17:34:29 --> Input Class Initialized
INFO - 2018-02-16 17:34:29 --> Language Class Initialized
INFO - 2018-02-16 17:34:29 --> Loader Class Initialized
INFO - 2018-02-16 17:34:29 --> Helper loaded: url_helper
INFO - 2018-02-16 17:34:29 --> Helper loaded: file_helper
INFO - 2018-02-16 17:34:29 --> Helper loaded: email_helper
INFO - 2018-02-16 17:34:29 --> Helper loaded: common_helper
INFO - 2018-02-16 17:34:29 --> Database Driver Class Initialized
DEBUG - 2018-02-16 17:34:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-16 17:34:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-16 17:34:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-16 17:34:29 --> Pagination Class Initialized
INFO - 2018-02-16 17:34:29 --> Helper loaded: form_helper
INFO - 2018-02-16 17:34:29 --> Form Validation Class Initialized
INFO - 2018-02-16 17:34:29 --> Model Class Initialized
INFO - 2018-02-16 17:34:29 --> Controller Class Initialized
INFO - 2018-02-16 17:34:29 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-16 17:34:29 --> Model Class Initialized
INFO - 2018-02-16 17:34:29 --> Model Class Initialized
INFO - 2018-02-16 17:34:29 --> Model Class Initialized
INFO - 2018-02-16 17:34:29 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-16 17:34:29 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-16 17:34:29 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-16 17:34:29 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-16 17:34:29 --> File loaded: /var/www/html/project/radio/application/views/tracks/index.php
INFO - 2018-02-16 17:34:29 --> Final output sent to browser
DEBUG - 2018-02-16 17:34:29 --> Total execution time: 0.0053
INFO - 2018-02-16 17:34:29 --> Config Class Initialized
INFO - 2018-02-16 17:34:29 --> Hooks Class Initialized
DEBUG - 2018-02-16 17:34:29 --> UTF-8 Support Enabled
INFO - 2018-02-16 17:34:29 --> Utf8 Class Initialized
INFO - 2018-02-16 17:34:29 --> URI Class Initialized
INFO - 2018-02-16 17:34:29 --> Router Class Initialized
INFO - 2018-02-16 17:34:29 --> Output Class Initialized
INFO - 2018-02-16 17:34:29 --> Security Class Initialized
DEBUG - 2018-02-16 17:34:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-16 17:34:29 --> Input Class Initialized
INFO - 2018-02-16 17:34:29 --> Language Class Initialized
INFO - 2018-02-16 17:34:29 --> Loader Class Initialized
INFO - 2018-02-16 17:34:29 --> Helper loaded: url_helper
INFO - 2018-02-16 17:34:29 --> Helper loaded: file_helper
INFO - 2018-02-16 17:34:29 --> Helper loaded: email_helper
INFO - 2018-02-16 17:34:29 --> Helper loaded: common_helper
INFO - 2018-02-16 17:34:29 --> Database Driver Class Initialized
DEBUG - 2018-02-16 17:34:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-16 17:34:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-16 17:34:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-16 17:34:29 --> Pagination Class Initialized
INFO - 2018-02-16 17:34:29 --> Helper loaded: form_helper
INFO - 2018-02-16 17:34:29 --> Form Validation Class Initialized
INFO - 2018-02-16 17:34:29 --> Model Class Initialized
INFO - 2018-02-16 17:34:29 --> Controller Class Initialized
INFO - 2018-02-16 17:34:29 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-16 17:34:29 --> Model Class Initialized
INFO - 2018-02-16 17:34:29 --> Model Class Initialized
INFO - 2018-02-16 17:34:29 --> Model Class Initialized
INFO - 2018-02-16 17:34:30 --> Config Class Initialized
INFO - 2018-02-16 17:34:30 --> Hooks Class Initialized
DEBUG - 2018-02-16 17:34:30 --> UTF-8 Support Enabled
INFO - 2018-02-16 17:34:30 --> Utf8 Class Initialized
INFO - 2018-02-16 17:34:30 --> URI Class Initialized
INFO - 2018-02-16 17:34:30 --> Router Class Initialized
INFO - 2018-02-16 17:34:30 --> Output Class Initialized
INFO - 2018-02-16 17:34:30 --> Security Class Initialized
DEBUG - 2018-02-16 17:34:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-16 17:34:30 --> Input Class Initialized
INFO - 2018-02-16 17:34:30 --> Language Class Initialized
INFO - 2018-02-16 17:34:30 --> Loader Class Initialized
INFO - 2018-02-16 17:34:30 --> Helper loaded: url_helper
INFO - 2018-02-16 17:34:30 --> Helper loaded: file_helper
INFO - 2018-02-16 17:34:30 --> Helper loaded: email_helper
INFO - 2018-02-16 17:34:30 --> Helper loaded: common_helper
INFO - 2018-02-16 17:34:30 --> Database Driver Class Initialized
DEBUG - 2018-02-16 17:34:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-16 17:34:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-16 17:34:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-16 17:34:30 --> Pagination Class Initialized
INFO - 2018-02-16 17:34:30 --> Helper loaded: form_helper
INFO - 2018-02-16 17:34:30 --> Form Validation Class Initialized
INFO - 2018-02-16 17:34:30 --> Model Class Initialized
INFO - 2018-02-16 17:34:30 --> Controller Class Initialized
INFO - 2018-02-16 17:34:30 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-16 17:34:30 --> Model Class Initialized
INFO - 2018-02-16 17:34:30 --> Model Class Initialized
INFO - 2018-02-16 17:34:30 --> Model Class Initialized
INFO - 2018-02-16 17:34:30 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-16 17:34:30 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-16 17:34:30 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-16 17:34:30 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-16 17:34:30 --> File loaded: /var/www/html/project/radio/application/views/tracks/add_edit.php
INFO - 2018-02-16 17:34:30 --> Final output sent to browser
DEBUG - 2018-02-16 17:34:30 --> Total execution time: 0.0060
INFO - 2018-02-16 17:43:47 --> Config Class Initialized
INFO - 2018-02-16 17:43:47 --> Hooks Class Initialized
DEBUG - 2018-02-16 17:43:47 --> UTF-8 Support Enabled
INFO - 2018-02-16 17:43:47 --> Utf8 Class Initialized
INFO - 2018-02-16 17:43:47 --> URI Class Initialized
INFO - 2018-02-16 17:43:47 --> Router Class Initialized
INFO - 2018-02-16 17:43:47 --> Output Class Initialized
INFO - 2018-02-16 17:43:47 --> Security Class Initialized
DEBUG - 2018-02-16 17:43:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-16 17:43:47 --> Input Class Initialized
INFO - 2018-02-16 17:43:47 --> Language Class Initialized
INFO - 2018-02-16 17:43:47 --> Loader Class Initialized
INFO - 2018-02-16 17:43:47 --> Helper loaded: url_helper
INFO - 2018-02-16 17:43:47 --> Helper loaded: file_helper
INFO - 2018-02-16 17:43:47 --> Helper loaded: email_helper
INFO - 2018-02-16 17:43:47 --> Helper loaded: common_helper
INFO - 2018-02-16 17:43:47 --> Database Driver Class Initialized
DEBUG - 2018-02-16 17:43:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-16 17:43:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-16 17:43:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-16 17:43:47 --> Pagination Class Initialized
INFO - 2018-02-16 17:43:47 --> Helper loaded: form_helper
INFO - 2018-02-16 17:43:47 --> Form Validation Class Initialized
INFO - 2018-02-16 17:43:47 --> Model Class Initialized
INFO - 2018-02-16 17:43:47 --> Controller Class Initialized
INFO - 2018-02-16 17:43:47 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-16 17:43:47 --> Model Class Initialized
INFO - 2018-02-16 17:43:47 --> Model Class Initialized
INFO - 2018-02-16 17:43:47 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-16 17:43:47 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-16 17:43:47 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-16 17:43:47 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-16 17:43:47 --> File loaded: /var/www/html/project/radio/application/views/subcategory/index.php
INFO - 2018-02-16 17:43:47 --> Final output sent to browser
DEBUG - 2018-02-16 17:43:47 --> Total execution time: 0.0073
INFO - 2018-02-16 17:43:48 --> Config Class Initialized
INFO - 2018-02-16 17:43:48 --> Hooks Class Initialized
DEBUG - 2018-02-16 17:43:48 --> UTF-8 Support Enabled
INFO - 2018-02-16 17:43:48 --> Utf8 Class Initialized
INFO - 2018-02-16 17:43:48 --> URI Class Initialized
INFO - 2018-02-16 17:43:48 --> Router Class Initialized
INFO - 2018-02-16 17:43:48 --> Output Class Initialized
INFO - 2018-02-16 17:43:48 --> Security Class Initialized
DEBUG - 2018-02-16 17:43:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-16 17:43:48 --> Input Class Initialized
INFO - 2018-02-16 17:43:48 --> Language Class Initialized
INFO - 2018-02-16 17:43:48 --> Loader Class Initialized
INFO - 2018-02-16 17:43:48 --> Helper loaded: url_helper
INFO - 2018-02-16 17:43:48 --> Helper loaded: file_helper
INFO - 2018-02-16 17:43:48 --> Helper loaded: email_helper
INFO - 2018-02-16 17:43:48 --> Helper loaded: common_helper
INFO - 2018-02-16 17:43:48 --> Database Driver Class Initialized
DEBUG - 2018-02-16 17:43:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-16 17:43:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-16 17:43:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-16 17:43:48 --> Pagination Class Initialized
INFO - 2018-02-16 17:43:48 --> Helper loaded: form_helper
INFO - 2018-02-16 17:43:48 --> Form Validation Class Initialized
INFO - 2018-02-16 17:43:48 --> Model Class Initialized
INFO - 2018-02-16 17:43:48 --> Controller Class Initialized
INFO - 2018-02-16 17:43:48 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-16 17:43:48 --> Model Class Initialized
INFO - 2018-02-16 17:43:48 --> Model Class Initialized
INFO - 2018-02-16 17:43:48 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-16 17:43:48 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-16 17:43:48 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-16 17:43:48 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-16 17:43:48 --> File loaded: /var/www/html/project/radio/application/views/subcategory/add_edit.php
INFO - 2018-02-16 17:43:48 --> Final output sent to browser
DEBUG - 2018-02-16 17:43:48 --> Total execution time: 0.0066
INFO - 2018-02-16 17:55:43 --> Config Class Initialized
INFO - 2018-02-16 17:55:43 --> Hooks Class Initialized
DEBUG - 2018-02-16 17:55:43 --> UTF-8 Support Enabled
INFO - 2018-02-16 17:55:43 --> Utf8 Class Initialized
INFO - 2018-02-16 17:55:43 --> URI Class Initialized
INFO - 2018-02-16 17:55:43 --> Router Class Initialized
INFO - 2018-02-16 17:55:43 --> Output Class Initialized
INFO - 2018-02-16 17:55:43 --> Security Class Initialized
DEBUG - 2018-02-16 17:55:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-16 17:55:43 --> Input Class Initialized
INFO - 2018-02-16 17:55:43 --> Language Class Initialized
INFO - 2018-02-16 17:55:43 --> Loader Class Initialized
INFO - 2018-02-16 17:55:43 --> Helper loaded: url_helper
INFO - 2018-02-16 17:55:43 --> Helper loaded: file_helper
INFO - 2018-02-16 17:55:43 --> Helper loaded: email_helper
INFO - 2018-02-16 17:55:43 --> Helper loaded: common_helper
INFO - 2018-02-16 17:55:43 --> Database Driver Class Initialized
DEBUG - 2018-02-16 17:55:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-16 17:55:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-16 17:55:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-16 17:55:43 --> Pagination Class Initialized
INFO - 2018-02-16 17:55:43 --> Helper loaded: form_helper
INFO - 2018-02-16 17:55:43 --> Form Validation Class Initialized
INFO - 2018-02-16 17:55:43 --> Model Class Initialized
INFO - 2018-02-16 17:55:43 --> Controller Class Initialized
INFO - 2018-02-16 17:55:43 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-16 17:55:43 --> Model Class Initialized
INFO - 2018-02-16 17:55:43 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-16 17:55:43 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-16 17:55:43 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-16 17:55:43 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-16 17:55:43 --> File loaded: /var/www/html/project/radio/application/views/category/index.php
INFO - 2018-02-16 17:55:43 --> Final output sent to browser
DEBUG - 2018-02-16 17:55:43 --> Total execution time: 0.0065
INFO - 2018-02-16 17:55:57 --> Config Class Initialized
INFO - 2018-02-16 17:55:57 --> Hooks Class Initialized
DEBUG - 2018-02-16 17:55:57 --> UTF-8 Support Enabled
INFO - 2018-02-16 17:55:57 --> Utf8 Class Initialized
INFO - 2018-02-16 17:55:57 --> URI Class Initialized
INFO - 2018-02-16 17:55:57 --> Router Class Initialized
INFO - 2018-02-16 17:55:57 --> Output Class Initialized
INFO - 2018-02-16 17:55:57 --> Security Class Initialized
DEBUG - 2018-02-16 17:55:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-16 17:55:57 --> Input Class Initialized
INFO - 2018-02-16 17:55:57 --> Language Class Initialized
INFO - 2018-02-16 17:55:57 --> Loader Class Initialized
INFO - 2018-02-16 17:55:57 --> Helper loaded: url_helper
INFO - 2018-02-16 17:55:57 --> Helper loaded: file_helper
INFO - 2018-02-16 17:55:57 --> Helper loaded: email_helper
INFO - 2018-02-16 17:55:57 --> Helper loaded: common_helper
INFO - 2018-02-16 17:55:57 --> Database Driver Class Initialized
DEBUG - 2018-02-16 17:55:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-16 17:55:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-16 17:55:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-16 17:55:57 --> Pagination Class Initialized
INFO - 2018-02-16 17:55:57 --> Helper loaded: form_helper
INFO - 2018-02-16 17:55:57 --> Form Validation Class Initialized
INFO - 2018-02-16 17:55:57 --> Model Class Initialized
INFO - 2018-02-16 17:55:57 --> Controller Class Initialized
INFO - 2018-02-16 17:55:57 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-16 17:55:57 --> Model Class Initialized
INFO - 2018-02-16 17:55:57 --> Model Class Initialized
INFO - 2018-02-16 17:55:57 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-16 17:55:57 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-16 17:55:57 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-16 17:55:57 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-16 17:55:57 --> File loaded: /var/www/html/project/radio/application/views/subcategory/index.php
INFO - 2018-02-16 17:55:57 --> Final output sent to browser
DEBUG - 2018-02-16 17:55:57 --> Total execution time: 0.0067
INFO - 2018-02-16 18:38:43 --> Config Class Initialized
INFO - 2018-02-16 18:38:43 --> Hooks Class Initialized
DEBUG - 2018-02-16 18:38:43 --> UTF-8 Support Enabled
INFO - 2018-02-16 18:38:43 --> Utf8 Class Initialized
INFO - 2018-02-16 18:38:43 --> URI Class Initialized
INFO - 2018-02-16 18:38:43 --> Router Class Initialized
INFO - 2018-02-16 18:38:43 --> Output Class Initialized
INFO - 2018-02-16 18:38:43 --> Security Class Initialized
DEBUG - 2018-02-16 18:38:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-16 18:38:43 --> Input Class Initialized
INFO - 2018-02-16 18:38:43 --> Language Class Initialized
INFO - 2018-02-16 18:38:43 --> Loader Class Initialized
INFO - 2018-02-16 18:38:43 --> Helper loaded: url_helper
INFO - 2018-02-16 18:38:43 --> Helper loaded: file_helper
INFO - 2018-02-16 18:38:43 --> Helper loaded: email_helper
INFO - 2018-02-16 18:38:43 --> Helper loaded: common_helper
INFO - 2018-02-16 18:38:43 --> Database Driver Class Initialized
DEBUG - 2018-02-16 18:38:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-16 18:38:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-16 18:38:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-16 18:38:43 --> Pagination Class Initialized
INFO - 2018-02-16 18:38:43 --> Helper loaded: form_helper
INFO - 2018-02-16 18:38:43 --> Form Validation Class Initialized
INFO - 2018-02-16 18:38:43 --> Model Class Initialized
INFO - 2018-02-16 18:38:43 --> Controller Class Initialized
INFO - 2018-02-16 18:38:43 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-16 18:38:43 --> Model Class Initialized
INFO - 2018-02-16 18:38:43 --> Model Class Initialized
INFO - 2018-02-16 18:38:43 --> Model Class Initialized
INFO - 2018-02-16 18:38:43 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-16 18:38:43 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-16 18:38:43 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-16 18:38:43 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-16 18:38:43 --> File loaded: /var/www/html/project/radio/application/views/tracks/index.php
INFO - 2018-02-16 18:38:43 --> Final output sent to browser
DEBUG - 2018-02-16 18:38:43 --> Total execution time: 0.0058
INFO - 2018-02-16 18:38:43 --> Config Class Initialized
INFO - 2018-02-16 18:38:43 --> Hooks Class Initialized
DEBUG - 2018-02-16 18:38:43 --> UTF-8 Support Enabled
INFO - 2018-02-16 18:38:43 --> Utf8 Class Initialized
INFO - 2018-02-16 18:38:43 --> URI Class Initialized
INFO - 2018-02-16 18:38:43 --> Router Class Initialized
INFO - 2018-02-16 18:38:43 --> Output Class Initialized
INFO - 2018-02-16 18:38:43 --> Security Class Initialized
DEBUG - 2018-02-16 18:38:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-16 18:38:43 --> Input Class Initialized
INFO - 2018-02-16 18:38:43 --> Language Class Initialized
INFO - 2018-02-16 18:38:43 --> Loader Class Initialized
INFO - 2018-02-16 18:38:43 --> Helper loaded: url_helper
INFO - 2018-02-16 18:38:43 --> Helper loaded: file_helper
INFO - 2018-02-16 18:38:43 --> Helper loaded: email_helper
INFO - 2018-02-16 18:38:43 --> Helper loaded: common_helper
INFO - 2018-02-16 18:38:43 --> Database Driver Class Initialized
DEBUG - 2018-02-16 18:38:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-16 18:38:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-16 18:38:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-16 18:38:43 --> Pagination Class Initialized
INFO - 2018-02-16 18:38:43 --> Helper loaded: form_helper
INFO - 2018-02-16 18:38:43 --> Form Validation Class Initialized
INFO - 2018-02-16 18:38:43 --> Model Class Initialized
INFO - 2018-02-16 18:38:43 --> Controller Class Initialized
INFO - 2018-02-16 18:38:43 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-16 18:38:43 --> Model Class Initialized
INFO - 2018-02-16 18:38:43 --> Model Class Initialized
INFO - 2018-02-16 18:38:43 --> Model Class Initialized
INFO - 2018-02-16 18:38:44 --> Config Class Initialized
INFO - 2018-02-16 18:38:44 --> Hooks Class Initialized
DEBUG - 2018-02-16 18:38:44 --> UTF-8 Support Enabled
INFO - 2018-02-16 18:38:44 --> Utf8 Class Initialized
INFO - 2018-02-16 18:38:44 --> URI Class Initialized
INFO - 2018-02-16 18:38:44 --> Router Class Initialized
INFO - 2018-02-16 18:38:44 --> Output Class Initialized
INFO - 2018-02-16 18:38:44 --> Security Class Initialized
DEBUG - 2018-02-16 18:38:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-16 18:38:44 --> Input Class Initialized
INFO - 2018-02-16 18:38:44 --> Language Class Initialized
INFO - 2018-02-16 18:38:44 --> Loader Class Initialized
INFO - 2018-02-16 18:38:44 --> Helper loaded: url_helper
INFO - 2018-02-16 18:38:44 --> Helper loaded: file_helper
INFO - 2018-02-16 18:38:44 --> Helper loaded: email_helper
INFO - 2018-02-16 18:38:44 --> Helper loaded: common_helper
INFO - 2018-02-16 18:38:44 --> Database Driver Class Initialized
DEBUG - 2018-02-16 18:38:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-16 18:38:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-16 18:38:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-16 18:38:44 --> Pagination Class Initialized
INFO - 2018-02-16 18:38:44 --> Helper loaded: form_helper
INFO - 2018-02-16 18:38:44 --> Form Validation Class Initialized
INFO - 2018-02-16 18:38:44 --> Model Class Initialized
INFO - 2018-02-16 18:38:44 --> Controller Class Initialized
INFO - 2018-02-16 18:38:44 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-16 18:38:44 --> Model Class Initialized
INFO - 2018-02-16 18:38:44 --> Model Class Initialized
INFO - 2018-02-16 18:38:44 --> Model Class Initialized
INFO - 2018-02-16 18:38:44 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-16 18:38:44 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-16 18:38:44 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-16 18:38:44 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-16 18:38:44 --> File loaded: /var/www/html/project/radio/application/views/tracks/add_edit.php
INFO - 2018-02-16 18:38:44 --> Final output sent to browser
DEBUG - 2018-02-16 18:38:44 --> Total execution time: 0.0060
INFO - 2018-02-16 18:58:27 --> Config Class Initialized
INFO - 2018-02-16 18:58:27 --> Hooks Class Initialized
DEBUG - 2018-02-16 18:58:27 --> UTF-8 Support Enabled
INFO - 2018-02-16 18:58:27 --> Utf8 Class Initialized
INFO - 2018-02-16 18:58:27 --> URI Class Initialized
INFO - 2018-02-16 18:58:27 --> Router Class Initialized
INFO - 2018-02-16 18:58:27 --> Output Class Initialized
INFO - 2018-02-16 18:58:27 --> Security Class Initialized
DEBUG - 2018-02-16 18:58:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-16 18:58:27 --> Input Class Initialized
INFO - 2018-02-16 18:58:27 --> Language Class Initialized
ERROR - 2018-02-16 18:58:27 --> Severity: error --> Exception: syntax error, unexpected 'foreach' (T_FOREACH) /var/www/html/project/radio/application/controllers/Tracks.php 175
INFO - 2018-02-16 18:58:51 --> Config Class Initialized
INFO - 2018-02-16 18:58:51 --> Hooks Class Initialized
DEBUG - 2018-02-16 18:58:51 --> UTF-8 Support Enabled
INFO - 2018-02-16 18:58:51 --> Utf8 Class Initialized
INFO - 2018-02-16 18:58:51 --> URI Class Initialized
INFO - 2018-02-16 18:58:51 --> Router Class Initialized
INFO - 2018-02-16 18:58:51 --> Output Class Initialized
INFO - 2018-02-16 18:58:51 --> Security Class Initialized
DEBUG - 2018-02-16 18:58:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-16 18:58:51 --> Input Class Initialized
INFO - 2018-02-16 18:58:51 --> Language Class Initialized
INFO - 2018-02-16 18:58:51 --> Loader Class Initialized
INFO - 2018-02-16 18:58:51 --> Helper loaded: url_helper
INFO - 2018-02-16 18:58:51 --> Helper loaded: file_helper
INFO - 2018-02-16 18:58:51 --> Helper loaded: email_helper
INFO - 2018-02-16 18:58:51 --> Helper loaded: common_helper
INFO - 2018-02-16 18:58:51 --> Database Driver Class Initialized
DEBUG - 2018-02-16 18:58:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-16 18:58:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-16 18:58:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-16 18:58:51 --> Pagination Class Initialized
INFO - 2018-02-16 18:58:51 --> Helper loaded: form_helper
INFO - 2018-02-16 18:58:51 --> Form Validation Class Initialized
INFO - 2018-02-16 18:58:51 --> Model Class Initialized
INFO - 2018-02-16 18:58:51 --> Controller Class Initialized
INFO - 2018-02-16 18:58:51 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-16 18:58:51 --> Model Class Initialized
INFO - 2018-02-16 18:58:51 --> Model Class Initialized
INFO - 2018-02-16 18:58:51 --> Model Class Initialized
INFO - 2018-02-16 18:58:51 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-16 18:58:51 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-16 18:58:51 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-16 18:58:51 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-16 18:58:51 --> File loaded: /var/www/html/project/radio/application/views/tracks/add_edit.php
INFO - 2018-02-16 18:58:51 --> Final output sent to browser
DEBUG - 2018-02-16 18:58:51 --> Total execution time: 0.0104
INFO - 2018-02-16 18:59:14 --> Config Class Initialized
INFO - 2018-02-16 18:59:14 --> Hooks Class Initialized
DEBUG - 2018-02-16 18:59:14 --> UTF-8 Support Enabled
INFO - 2018-02-16 18:59:14 --> Utf8 Class Initialized
INFO - 2018-02-16 18:59:14 --> URI Class Initialized
INFO - 2018-02-16 18:59:14 --> Router Class Initialized
INFO - 2018-02-16 18:59:14 --> Output Class Initialized
INFO - 2018-02-16 18:59:14 --> Security Class Initialized
DEBUG - 2018-02-16 18:59:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-16 18:59:14 --> Input Class Initialized
INFO - 2018-02-16 18:59:14 --> Language Class Initialized
INFO - 2018-02-16 18:59:14 --> Loader Class Initialized
INFO - 2018-02-16 18:59:14 --> Helper loaded: url_helper
INFO - 2018-02-16 18:59:14 --> Helper loaded: file_helper
INFO - 2018-02-16 18:59:14 --> Helper loaded: email_helper
INFO - 2018-02-16 18:59:14 --> Helper loaded: common_helper
INFO - 2018-02-16 18:59:14 --> Database Driver Class Initialized
DEBUG - 2018-02-16 18:59:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-16 18:59:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-16 18:59:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-16 18:59:14 --> Pagination Class Initialized
INFO - 2018-02-16 18:59:14 --> Helper loaded: form_helper
INFO - 2018-02-16 18:59:14 --> Form Validation Class Initialized
INFO - 2018-02-16 18:59:14 --> Model Class Initialized
INFO - 2018-02-16 18:59:14 --> Controller Class Initialized
INFO - 2018-02-16 18:59:14 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-16 18:59:14 --> Model Class Initialized
INFO - 2018-02-16 18:59:14 --> Model Class Initialized
INFO - 2018-02-16 18:59:14 --> Model Class Initialized
INFO - 2018-02-16 18:59:14 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-16 18:59:14 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-16 18:59:14 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-16 18:59:14 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-16 18:59:14 --> File loaded: /var/www/html/project/radio/application/views/tracks/add_edit.php
INFO - 2018-02-16 18:59:14 --> Final output sent to browser
DEBUG - 2018-02-16 18:59:14 --> Total execution time: 0.0092
INFO - 2018-02-16 19:01:48 --> Config Class Initialized
INFO - 2018-02-16 19:01:48 --> Hooks Class Initialized
DEBUG - 2018-02-16 19:01:48 --> UTF-8 Support Enabled
INFO - 2018-02-16 19:01:48 --> Utf8 Class Initialized
INFO - 2018-02-16 19:01:48 --> URI Class Initialized
INFO - 2018-02-16 19:01:48 --> Router Class Initialized
INFO - 2018-02-16 19:01:48 --> Output Class Initialized
INFO - 2018-02-16 19:01:48 --> Security Class Initialized
DEBUG - 2018-02-16 19:01:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-16 19:01:48 --> Input Class Initialized
INFO - 2018-02-16 19:01:48 --> Language Class Initialized
INFO - 2018-02-16 19:01:48 --> Loader Class Initialized
INFO - 2018-02-16 19:01:48 --> Helper loaded: url_helper
INFO - 2018-02-16 19:01:48 --> Helper loaded: file_helper
INFO - 2018-02-16 19:01:48 --> Helper loaded: email_helper
INFO - 2018-02-16 19:01:48 --> Helper loaded: common_helper
INFO - 2018-02-16 19:01:48 --> Database Driver Class Initialized
DEBUG - 2018-02-16 19:01:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-16 19:01:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-16 19:01:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-16 19:01:48 --> Pagination Class Initialized
INFO - 2018-02-16 19:01:48 --> Helper loaded: form_helper
INFO - 2018-02-16 19:01:48 --> Form Validation Class Initialized
INFO - 2018-02-16 19:01:48 --> Model Class Initialized
INFO - 2018-02-16 19:01:48 --> Controller Class Initialized
INFO - 2018-02-16 19:01:48 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-16 19:01:48 --> Model Class Initialized
INFO - 2018-02-16 19:01:48 --> Model Class Initialized
INFO - 2018-02-16 19:01:48 --> Model Class Initialized
INFO - 2018-02-16 19:01:48 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-16 19:01:48 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-16 19:01:48 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-16 19:01:48 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-16 19:01:48 --> File loaded: /var/www/html/project/radio/application/views/tracks/add_edit.php
INFO - 2018-02-16 19:01:48 --> Final output sent to browser
DEBUG - 2018-02-16 19:01:48 --> Total execution time: 0.0136
INFO - 2018-02-16 19:02:18 --> Config Class Initialized
INFO - 2018-02-16 19:02:18 --> Hooks Class Initialized
DEBUG - 2018-02-16 19:02:18 --> UTF-8 Support Enabled
INFO - 2018-02-16 19:02:18 --> Utf8 Class Initialized
INFO - 2018-02-16 19:02:18 --> URI Class Initialized
INFO - 2018-02-16 19:02:18 --> Router Class Initialized
INFO - 2018-02-16 19:02:18 --> Output Class Initialized
INFO - 2018-02-16 19:02:18 --> Security Class Initialized
DEBUG - 2018-02-16 19:02:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-16 19:02:18 --> Input Class Initialized
INFO - 2018-02-16 19:02:18 --> Language Class Initialized
INFO - 2018-02-16 19:02:18 --> Loader Class Initialized
INFO - 2018-02-16 19:02:18 --> Helper loaded: url_helper
INFO - 2018-02-16 19:02:18 --> Helper loaded: file_helper
INFO - 2018-02-16 19:02:18 --> Helper loaded: email_helper
INFO - 2018-02-16 19:02:18 --> Helper loaded: common_helper
INFO - 2018-02-16 19:02:18 --> Database Driver Class Initialized
DEBUG - 2018-02-16 19:02:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-16 19:02:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-16 19:02:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-16 19:02:18 --> Pagination Class Initialized
INFO - 2018-02-16 19:02:18 --> Helper loaded: form_helper
INFO - 2018-02-16 19:02:18 --> Form Validation Class Initialized
INFO - 2018-02-16 19:02:18 --> Model Class Initialized
INFO - 2018-02-16 19:02:18 --> Controller Class Initialized
INFO - 2018-02-16 19:02:18 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-16 19:02:18 --> Model Class Initialized
INFO - 2018-02-16 19:02:18 --> Model Class Initialized
INFO - 2018-02-16 19:02:18 --> Model Class Initialized
INFO - 2018-02-16 19:02:18 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-16 19:02:18 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-16 19:02:18 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-16 19:02:18 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-16 19:02:18 --> File loaded: /var/www/html/project/radio/application/views/tracks/add_edit.php
INFO - 2018-02-16 19:02:18 --> Final output sent to browser
DEBUG - 2018-02-16 19:02:18 --> Total execution time: 0.0074
INFO - 2018-02-16 19:02:21 --> Config Class Initialized
INFO - 2018-02-16 19:02:21 --> Hooks Class Initialized
DEBUG - 2018-02-16 19:02:21 --> UTF-8 Support Enabled
INFO - 2018-02-16 19:02:21 --> Utf8 Class Initialized
INFO - 2018-02-16 19:02:21 --> URI Class Initialized
INFO - 2018-02-16 19:02:21 --> Router Class Initialized
INFO - 2018-02-16 19:02:21 --> Output Class Initialized
INFO - 2018-02-16 19:02:21 --> Security Class Initialized
DEBUG - 2018-02-16 19:02:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-16 19:02:21 --> Input Class Initialized
INFO - 2018-02-16 19:02:21 --> Language Class Initialized
INFO - 2018-02-16 19:02:21 --> Loader Class Initialized
INFO - 2018-02-16 19:02:21 --> Helper loaded: url_helper
INFO - 2018-02-16 19:02:21 --> Helper loaded: file_helper
INFO - 2018-02-16 19:02:21 --> Helper loaded: email_helper
INFO - 2018-02-16 19:02:21 --> Helper loaded: common_helper
INFO - 2018-02-16 19:02:21 --> Database Driver Class Initialized
DEBUG - 2018-02-16 19:02:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-16 19:02:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-16 19:02:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-16 19:02:21 --> Pagination Class Initialized
INFO - 2018-02-16 19:02:21 --> Helper loaded: form_helper
INFO - 2018-02-16 19:02:21 --> Form Validation Class Initialized
INFO - 2018-02-16 19:02:21 --> Model Class Initialized
INFO - 2018-02-16 19:02:21 --> Controller Class Initialized
INFO - 2018-02-16 19:02:21 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-16 19:02:21 --> Model Class Initialized
INFO - 2018-02-16 19:02:21 --> Model Class Initialized
INFO - 2018-02-16 19:02:21 --> Model Class Initialized
INFO - 2018-02-16 19:02:21 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-16 19:02:21 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-16 19:02:21 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-16 19:02:21 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-16 19:02:21 --> File loaded: /var/www/html/project/radio/application/views/tracks/index.php
INFO - 2018-02-16 19:02:21 --> Final output sent to browser
DEBUG - 2018-02-16 19:02:21 --> Total execution time: 0.0060
INFO - 2018-02-16 19:02:22 --> Config Class Initialized
INFO - 2018-02-16 19:02:22 --> Hooks Class Initialized
DEBUG - 2018-02-16 19:02:22 --> UTF-8 Support Enabled
INFO - 2018-02-16 19:02:22 --> Utf8 Class Initialized
INFO - 2018-02-16 19:02:22 --> URI Class Initialized
INFO - 2018-02-16 19:02:22 --> Router Class Initialized
INFO - 2018-02-16 19:02:22 --> Output Class Initialized
INFO - 2018-02-16 19:02:22 --> Security Class Initialized
DEBUG - 2018-02-16 19:02:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-16 19:02:22 --> Input Class Initialized
INFO - 2018-02-16 19:02:22 --> Language Class Initialized
INFO - 2018-02-16 19:02:22 --> Loader Class Initialized
INFO - 2018-02-16 19:02:22 --> Helper loaded: url_helper
INFO - 2018-02-16 19:02:22 --> Helper loaded: file_helper
INFO - 2018-02-16 19:02:22 --> Helper loaded: email_helper
INFO - 2018-02-16 19:02:22 --> Helper loaded: common_helper
INFO - 2018-02-16 19:02:22 --> Database Driver Class Initialized
DEBUG - 2018-02-16 19:02:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-16 19:02:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-16 19:02:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-16 19:02:22 --> Pagination Class Initialized
INFO - 2018-02-16 19:02:22 --> Helper loaded: form_helper
INFO - 2018-02-16 19:02:22 --> Form Validation Class Initialized
INFO - 2018-02-16 19:02:22 --> Model Class Initialized
INFO - 2018-02-16 19:02:22 --> Controller Class Initialized
INFO - 2018-02-16 19:02:22 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-16 19:02:22 --> Model Class Initialized
INFO - 2018-02-16 19:02:22 --> Model Class Initialized
INFO - 2018-02-16 19:02:22 --> Model Class Initialized
INFO - 2018-02-16 19:02:27 --> Config Class Initialized
INFO - 2018-02-16 19:02:27 --> Hooks Class Initialized
DEBUG - 2018-02-16 19:02:27 --> UTF-8 Support Enabled
INFO - 2018-02-16 19:02:27 --> Utf8 Class Initialized
INFO - 2018-02-16 19:02:27 --> URI Class Initialized
INFO - 2018-02-16 19:02:27 --> Router Class Initialized
INFO - 2018-02-16 19:02:27 --> Output Class Initialized
INFO - 2018-02-16 19:02:27 --> Security Class Initialized
DEBUG - 2018-02-16 19:02:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-16 19:02:27 --> Input Class Initialized
INFO - 2018-02-16 19:02:27 --> Language Class Initialized
INFO - 2018-02-16 19:02:27 --> Loader Class Initialized
INFO - 2018-02-16 19:02:27 --> Helper loaded: url_helper
INFO - 2018-02-16 19:02:27 --> Helper loaded: file_helper
INFO - 2018-02-16 19:02:27 --> Helper loaded: email_helper
INFO - 2018-02-16 19:02:27 --> Helper loaded: common_helper
INFO - 2018-02-16 19:02:27 --> Database Driver Class Initialized
DEBUG - 2018-02-16 19:02:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-16 19:02:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-16 19:02:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-16 19:02:27 --> Pagination Class Initialized
INFO - 2018-02-16 19:02:27 --> Helper loaded: form_helper
INFO - 2018-02-16 19:02:27 --> Form Validation Class Initialized
INFO - 2018-02-16 19:02:27 --> Model Class Initialized
INFO - 2018-02-16 19:02:27 --> Controller Class Initialized
INFO - 2018-02-16 19:02:27 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-16 19:02:27 --> Model Class Initialized
INFO - 2018-02-16 19:02:27 --> Model Class Initialized
INFO - 2018-02-16 19:02:27 --> Model Class Initialized
INFO - 2018-02-16 19:02:27 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-16 19:02:27 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-16 19:02:27 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-16 19:02:27 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-16 19:02:27 --> File loaded: /var/www/html/project/radio/application/views/tracks/add_edit.php
INFO - 2018-02-16 19:02:27 --> Final output sent to browser
DEBUG - 2018-02-16 19:02:27 --> Total execution time: 0.0088
INFO - 2018-02-16 19:02:38 --> Config Class Initialized
INFO - 2018-02-16 19:02:38 --> Hooks Class Initialized
DEBUG - 2018-02-16 19:02:38 --> UTF-8 Support Enabled
INFO - 2018-02-16 19:02:38 --> Utf8 Class Initialized
INFO - 2018-02-16 19:02:38 --> URI Class Initialized
INFO - 2018-02-16 19:02:38 --> Router Class Initialized
INFO - 2018-02-16 19:02:38 --> Output Class Initialized
INFO - 2018-02-16 19:02:38 --> Security Class Initialized
DEBUG - 2018-02-16 19:02:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-16 19:02:38 --> Input Class Initialized
INFO - 2018-02-16 19:02:38 --> Language Class Initialized
INFO - 2018-02-16 19:02:38 --> Loader Class Initialized
INFO - 2018-02-16 19:02:38 --> Helper loaded: url_helper
INFO - 2018-02-16 19:02:38 --> Helper loaded: file_helper
INFO - 2018-02-16 19:02:38 --> Helper loaded: email_helper
INFO - 2018-02-16 19:02:38 --> Helper loaded: common_helper
INFO - 2018-02-16 19:02:38 --> Database Driver Class Initialized
DEBUG - 2018-02-16 19:02:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-16 19:02:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-16 19:02:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-16 19:02:38 --> Pagination Class Initialized
INFO - 2018-02-16 19:02:38 --> Helper loaded: form_helper
INFO - 2018-02-16 19:02:38 --> Form Validation Class Initialized
INFO - 2018-02-16 19:02:38 --> Model Class Initialized
INFO - 2018-02-16 19:02:38 --> Controller Class Initialized
INFO - 2018-02-16 19:02:38 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-16 19:02:38 --> Model Class Initialized
INFO - 2018-02-16 19:02:38 --> Model Class Initialized
INFO - 2018-02-16 19:02:38 --> Model Class Initialized
DEBUG - 2018-02-16 19:02:38 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-16 19:02:38 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-02-16 19:02:38 --> Config Class Initialized
INFO - 2018-02-16 19:02:38 --> Hooks Class Initialized
DEBUG - 2018-02-16 19:02:38 --> UTF-8 Support Enabled
INFO - 2018-02-16 19:02:38 --> Utf8 Class Initialized
INFO - 2018-02-16 19:02:38 --> URI Class Initialized
INFO - 2018-02-16 19:02:38 --> Router Class Initialized
INFO - 2018-02-16 19:02:38 --> Output Class Initialized
INFO - 2018-02-16 19:02:38 --> Security Class Initialized
DEBUG - 2018-02-16 19:02:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-16 19:02:38 --> Input Class Initialized
INFO - 2018-02-16 19:02:38 --> Language Class Initialized
INFO - 2018-02-16 19:02:38 --> Loader Class Initialized
INFO - 2018-02-16 19:02:38 --> Helper loaded: url_helper
INFO - 2018-02-16 19:02:38 --> Helper loaded: file_helper
INFO - 2018-02-16 19:02:38 --> Helper loaded: email_helper
INFO - 2018-02-16 19:02:38 --> Helper loaded: common_helper
INFO - 2018-02-16 19:02:38 --> Database Driver Class Initialized
DEBUG - 2018-02-16 19:02:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-16 19:02:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-16 19:02:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-16 19:02:38 --> Pagination Class Initialized
INFO - 2018-02-16 19:02:38 --> Helper loaded: form_helper
INFO - 2018-02-16 19:02:38 --> Form Validation Class Initialized
INFO - 2018-02-16 19:02:38 --> Model Class Initialized
INFO - 2018-02-16 19:02:38 --> Controller Class Initialized
INFO - 2018-02-16 19:02:38 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-16 19:02:38 --> Model Class Initialized
INFO - 2018-02-16 19:02:38 --> Model Class Initialized
INFO - 2018-02-16 19:02:38 --> Model Class Initialized
INFO - 2018-02-16 19:02:38 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-16 19:02:38 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-16 19:02:38 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-16 19:02:38 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-16 19:02:38 --> File loaded: /var/www/html/project/radio/application/views/tracks/index.php
INFO - 2018-02-16 19:02:38 --> Final output sent to browser
DEBUG - 2018-02-16 19:02:38 --> Total execution time: 0.0062
INFO - 2018-02-16 19:02:39 --> Config Class Initialized
INFO - 2018-02-16 19:02:39 --> Hooks Class Initialized
DEBUG - 2018-02-16 19:02:39 --> UTF-8 Support Enabled
INFO - 2018-02-16 19:02:39 --> Utf8 Class Initialized
INFO - 2018-02-16 19:02:39 --> URI Class Initialized
INFO - 2018-02-16 19:02:39 --> Router Class Initialized
INFO - 2018-02-16 19:02:39 --> Output Class Initialized
INFO - 2018-02-16 19:02:39 --> Security Class Initialized
DEBUG - 2018-02-16 19:02:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-16 19:02:39 --> Input Class Initialized
INFO - 2018-02-16 19:02:39 --> Language Class Initialized
INFO - 2018-02-16 19:02:39 --> Loader Class Initialized
INFO - 2018-02-16 19:02:39 --> Helper loaded: url_helper
INFO - 2018-02-16 19:02:39 --> Helper loaded: file_helper
INFO - 2018-02-16 19:02:39 --> Helper loaded: email_helper
INFO - 2018-02-16 19:02:39 --> Helper loaded: common_helper
INFO - 2018-02-16 19:02:39 --> Database Driver Class Initialized
DEBUG - 2018-02-16 19:02:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-16 19:02:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-16 19:02:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-16 19:02:39 --> Pagination Class Initialized
INFO - 2018-02-16 19:02:39 --> Helper loaded: form_helper
INFO - 2018-02-16 19:02:39 --> Form Validation Class Initialized
INFO - 2018-02-16 19:02:39 --> Model Class Initialized
INFO - 2018-02-16 19:02:39 --> Controller Class Initialized
INFO - 2018-02-16 19:02:39 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-16 19:02:39 --> Model Class Initialized
INFO - 2018-02-16 19:02:39 --> Model Class Initialized
INFO - 2018-02-16 19:02:39 --> Model Class Initialized
INFO - 2018-02-16 19:02:44 --> Config Class Initialized
INFO - 2018-02-16 19:02:44 --> Hooks Class Initialized
DEBUG - 2018-02-16 19:02:44 --> UTF-8 Support Enabled
INFO - 2018-02-16 19:02:44 --> Utf8 Class Initialized
INFO - 2018-02-16 19:02:44 --> URI Class Initialized
INFO - 2018-02-16 19:02:44 --> Router Class Initialized
INFO - 2018-02-16 19:02:44 --> Output Class Initialized
INFO - 2018-02-16 19:02:44 --> Security Class Initialized
DEBUG - 2018-02-16 19:02:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-16 19:02:44 --> Input Class Initialized
INFO - 2018-02-16 19:02:44 --> Language Class Initialized
INFO - 2018-02-16 19:02:44 --> Loader Class Initialized
INFO - 2018-02-16 19:02:44 --> Helper loaded: url_helper
INFO - 2018-02-16 19:02:44 --> Helper loaded: file_helper
INFO - 2018-02-16 19:02:44 --> Helper loaded: email_helper
INFO - 2018-02-16 19:02:44 --> Helper loaded: common_helper
INFO - 2018-02-16 19:02:44 --> Database Driver Class Initialized
DEBUG - 2018-02-16 19:02:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-16 19:02:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-16 19:02:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-16 19:02:44 --> Pagination Class Initialized
INFO - 2018-02-16 19:02:44 --> Helper loaded: form_helper
INFO - 2018-02-16 19:02:44 --> Form Validation Class Initialized
INFO - 2018-02-16 19:02:44 --> Model Class Initialized
INFO - 2018-02-16 19:02:44 --> Controller Class Initialized
INFO - 2018-02-16 19:02:44 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-16 19:02:44 --> Model Class Initialized
INFO - 2018-02-16 19:02:44 --> Model Class Initialized
INFO - 2018-02-16 19:02:44 --> Model Class Initialized
INFO - 2018-02-16 19:02:44 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-16 19:02:44 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-16 19:02:44 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-16 19:02:44 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-16 19:02:44 --> File loaded: /var/www/html/project/radio/application/views/tracks/add_edit.php
INFO - 2018-02-16 19:02:44 --> Final output sent to browser
DEBUG - 2018-02-16 19:02:44 --> Total execution time: 0.0071

<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2018-11-15 11:03:26 --> Config Class Initialized
INFO - 2018-11-15 11:03:26 --> Hooks Class Initialized
DEBUG - 2018-11-15 11:03:26 --> UTF-8 Support Enabled
INFO - 2018-11-15 11:03:26 --> Utf8 Class Initialized
INFO - 2018-11-15 11:03:26 --> URI Class Initialized
DEBUG - 2018-11-15 11:03:26 --> No URI present. Default controller set.
INFO - 2018-11-15 11:03:26 --> Router Class Initialized
INFO - 2018-11-15 11:03:26 --> Output Class Initialized
INFO - 2018-11-15 11:03:26 --> Security Class Initialized
DEBUG - 2018-11-15 11:03:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-15 11:03:26 --> Input Class Initialized
INFO - 2018-11-15 11:03:26 --> Language Class Initialized
INFO - 2018-11-15 11:03:26 --> Loader Class Initialized
INFO - 2018-11-15 11:03:26 --> Helper loaded: url_helper
INFO - 2018-11-15 11:03:26 --> Helper loaded: file_helper
INFO - 2018-11-15 11:03:26 --> Helper loaded: email_helper
INFO - 2018-11-15 11:03:26 --> Helper loaded: common_helper
INFO - 2018-11-15 11:03:26 --> Database Driver Class Initialized
DEBUG - 2018-11-15 11:03:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-15 11:03:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-15 11:03:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-15 11:03:26 --> Pagination Class Initialized
INFO - 2018-11-15 11:03:26 --> Helper loaded: form_helper
INFO - 2018-11-15 11:03:26 --> Form Validation Class Initialized
INFO - 2018-11-15 11:03:26 --> Model Class Initialized
INFO - 2018-11-15 11:03:26 --> Controller Class Initialized
INFO - 2018-11-15 11:03:26 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-15 11:03:26 --> Model Class Initialized
INFO - 2018-11-15 11:03:26 --> Model Class Initialized
INFO - 2018-11-15 11:03:26 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\template/header-menu.php
INFO - 2018-11-15 11:03:26 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\template/header.php
INFO - 2018-11-15 11:03:26 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\template/footer.php
INFO - 2018-11-15 11:03:26 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\index.php
INFO - 2018-11-15 11:03:26 --> Final output sent to browser
DEBUG - 2018-11-15 11:03:26 --> Total execution time: 0.1380
INFO - 2018-11-15 13:20:40 --> Config Class Initialized
INFO - 2018-11-15 13:20:40 --> Hooks Class Initialized
DEBUG - 2018-11-15 13:20:40 --> UTF-8 Support Enabled
INFO - 2018-11-15 13:20:40 --> Utf8 Class Initialized
INFO - 2018-11-15 13:20:40 --> URI Class Initialized
DEBUG - 2018-11-15 13:20:40 --> No URI present. Default controller set.
INFO - 2018-11-15 13:20:40 --> Router Class Initialized
INFO - 2018-11-15 13:20:40 --> Output Class Initialized
INFO - 2018-11-15 13:20:40 --> Security Class Initialized
DEBUG - 2018-11-15 13:20:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-15 13:20:40 --> Input Class Initialized
INFO - 2018-11-15 13:20:40 --> Language Class Initialized
INFO - 2018-11-15 13:20:40 --> Loader Class Initialized
INFO - 2018-11-15 13:20:40 --> Helper loaded: url_helper
INFO - 2018-11-15 13:20:40 --> Helper loaded: file_helper
INFO - 2018-11-15 13:20:40 --> Helper loaded: email_helper
INFO - 2018-11-15 13:20:40 --> Helper loaded: common_helper
INFO - 2018-11-15 13:20:40 --> Database Driver Class Initialized
DEBUG - 2018-11-15 13:20:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-15 13:20:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-15 13:20:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-15 13:20:40 --> Pagination Class Initialized
INFO - 2018-11-15 13:20:40 --> Helper loaded: form_helper
INFO - 2018-11-15 13:20:40 --> Form Validation Class Initialized
INFO - 2018-11-15 13:20:40 --> Model Class Initialized
INFO - 2018-11-15 13:20:40 --> Controller Class Initialized
INFO - 2018-11-15 13:20:40 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-15 13:20:40 --> Model Class Initialized
INFO - 2018-11-15 13:20:40 --> Model Class Initialized
INFO - 2018-11-15 13:20:40 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\template/header-menu.php
INFO - 2018-11-15 13:20:40 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\template/header.php
INFO - 2018-11-15 13:20:40 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\template/footer.php
INFO - 2018-11-15 13:20:40 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\index.php
INFO - 2018-11-15 13:20:40 --> Final output sent to browser
DEBUG - 2018-11-15 13:20:40 --> Total execution time: 0.3240

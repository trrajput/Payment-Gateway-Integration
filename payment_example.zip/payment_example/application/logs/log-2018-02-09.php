<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2018-02-09 11:05:26 --> Config Class Initialized
INFO - 2018-02-09 11:05:26 --> Hooks Class Initialized
DEBUG - 2018-02-09 11:05:26 --> UTF-8 Support Enabled
INFO - 2018-02-09 11:05:26 --> Utf8 Class Initialized
INFO - 2018-02-09 11:05:26 --> URI Class Initialized
INFO - 2018-02-09 11:05:26 --> Router Class Initialized
INFO - 2018-02-09 11:05:26 --> Output Class Initialized
INFO - 2018-02-09 11:05:26 --> Security Class Initialized
DEBUG - 2018-02-09 11:05:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-09 11:05:26 --> Input Class Initialized
INFO - 2018-02-09 11:05:26 --> Language Class Initialized
INFO - 2018-02-09 11:05:26 --> Loader Class Initialized
INFO - 2018-02-09 11:05:26 --> Helper loaded: url_helper
INFO - 2018-02-09 11:05:26 --> Helper loaded: file_helper
INFO - 2018-02-09 11:05:26 --> Helper loaded: email_helper
INFO - 2018-02-09 11:05:26 --> Helper loaded: common_helper
INFO - 2018-02-09 11:05:26 --> Database Driver Class Initialized
DEBUG - 2018-02-09 11:05:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-09 11:05:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-09 11:05:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-09 11:05:26 --> Pagination Class Initialized
INFO - 2018-02-09 11:05:26 --> Helper loaded: form_helper
INFO - 2018-02-09 11:05:26 --> Form Validation Class Initialized
INFO - 2018-02-09 11:05:26 --> Model Class Initialized
INFO - 2018-02-09 11:05:26 --> Controller Class Initialized
DEBUG - 2018-02-09 11:05:26 --> Config file loaded: /var/www/html/project/spamblocker/application/config/rest.php
INFO - 2018-02-09 11:05:26 --> Helper loaded: inflector_helper
INFO - 2018-02-09 11:05:26 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-09 11:05:26 --> Model Class Initialized
INFO - 2018-02-09 11:05:26 --> Model Class Initialized
ERROR - 2018-02-09 11:05:26 --> Severity: Notice --> Undefined variable: config /var/www/html/project/spamblocker/application/controllers/api/Oauth.php 207
INFO - 2018-02-09 11:05:51 --> Config Class Initialized
INFO - 2018-02-09 11:05:51 --> Hooks Class Initialized
DEBUG - 2018-02-09 11:05:51 --> UTF-8 Support Enabled
INFO - 2018-02-09 11:05:51 --> Utf8 Class Initialized
INFO - 2018-02-09 11:05:51 --> URI Class Initialized
INFO - 2018-02-09 11:05:51 --> Router Class Initialized
INFO - 2018-02-09 11:05:51 --> Output Class Initialized
INFO - 2018-02-09 11:05:51 --> Security Class Initialized
DEBUG - 2018-02-09 11:05:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-09 11:05:51 --> Input Class Initialized
INFO - 2018-02-09 11:05:51 --> Language Class Initialized
INFO - 2018-02-09 11:05:51 --> Loader Class Initialized
INFO - 2018-02-09 11:05:51 --> Helper loaded: url_helper
INFO - 2018-02-09 11:05:51 --> Helper loaded: file_helper
INFO - 2018-02-09 11:05:51 --> Helper loaded: email_helper
INFO - 2018-02-09 11:05:51 --> Helper loaded: common_helper
INFO - 2018-02-09 11:05:51 --> Database Driver Class Initialized
DEBUG - 2018-02-09 11:05:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-09 11:05:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-09 11:05:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-09 11:05:51 --> Pagination Class Initialized
INFO - 2018-02-09 11:05:51 --> Helper loaded: form_helper
INFO - 2018-02-09 11:05:51 --> Form Validation Class Initialized
INFO - 2018-02-09 11:05:51 --> Model Class Initialized
INFO - 2018-02-09 11:05:51 --> Controller Class Initialized
DEBUG - 2018-02-09 11:05:51 --> Config file loaded: /var/www/html/project/spamblocker/application/config/rest.php
INFO - 2018-02-09 11:05:51 --> Helper loaded: inflector_helper
INFO - 2018-02-09 11:05:51 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-09 11:05:51 --> Model Class Initialized
INFO - 2018-02-09 11:05:51 --> Model Class Initialized
INFO - 2018-02-09 11:06:20 --> Config Class Initialized
INFO - 2018-02-09 11:06:20 --> Hooks Class Initialized
DEBUG - 2018-02-09 11:06:20 --> UTF-8 Support Enabled
INFO - 2018-02-09 11:06:20 --> Utf8 Class Initialized
INFO - 2018-02-09 11:06:20 --> URI Class Initialized
INFO - 2018-02-09 11:06:20 --> Router Class Initialized
INFO - 2018-02-09 11:06:20 --> Output Class Initialized
INFO - 2018-02-09 11:06:20 --> Security Class Initialized
DEBUG - 2018-02-09 11:06:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-09 11:06:20 --> Input Class Initialized
INFO - 2018-02-09 11:06:20 --> Language Class Initialized
INFO - 2018-02-09 11:06:20 --> Loader Class Initialized
INFO - 2018-02-09 11:06:20 --> Helper loaded: url_helper
INFO - 2018-02-09 11:06:20 --> Helper loaded: file_helper
INFO - 2018-02-09 11:06:20 --> Helper loaded: email_helper
INFO - 2018-02-09 11:06:20 --> Helper loaded: common_helper
INFO - 2018-02-09 11:06:20 --> Database Driver Class Initialized
DEBUG - 2018-02-09 11:06:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-09 11:06:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-09 11:06:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-09 11:06:20 --> Pagination Class Initialized
INFO - 2018-02-09 11:06:20 --> Helper loaded: form_helper
INFO - 2018-02-09 11:06:20 --> Form Validation Class Initialized
INFO - 2018-02-09 11:06:20 --> Model Class Initialized
INFO - 2018-02-09 11:06:20 --> Controller Class Initialized
DEBUG - 2018-02-09 11:06:20 --> Config file loaded: /var/www/html/project/spamblocker/application/config/rest.php
INFO - 2018-02-09 11:06:20 --> Helper loaded: inflector_helper
INFO - 2018-02-09 11:06:20 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-09 11:06:20 --> Model Class Initialized
INFO - 2018-02-09 11:06:20 --> Model Class Initialized
INFO - 2018-02-09 11:09:11 --> Config Class Initialized
INFO - 2018-02-09 11:09:11 --> Hooks Class Initialized
DEBUG - 2018-02-09 11:09:11 --> UTF-8 Support Enabled
INFO - 2018-02-09 11:09:11 --> Utf8 Class Initialized
INFO - 2018-02-09 11:09:11 --> URI Class Initialized
INFO - 2018-02-09 11:09:11 --> Router Class Initialized
INFO - 2018-02-09 11:09:11 --> Output Class Initialized
INFO - 2018-02-09 11:09:11 --> Security Class Initialized
DEBUG - 2018-02-09 11:09:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-09 11:09:11 --> Input Class Initialized
INFO - 2018-02-09 11:09:11 --> Language Class Initialized
INFO - 2018-02-09 11:09:11 --> Loader Class Initialized
INFO - 2018-02-09 11:09:11 --> Helper loaded: url_helper
INFO - 2018-02-09 11:09:11 --> Helper loaded: file_helper
INFO - 2018-02-09 11:09:11 --> Helper loaded: email_helper
INFO - 2018-02-09 11:09:11 --> Helper loaded: common_helper
INFO - 2018-02-09 11:09:11 --> Database Driver Class Initialized
DEBUG - 2018-02-09 11:09:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-09 11:09:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-09 11:09:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-09 11:09:11 --> Pagination Class Initialized
INFO - 2018-02-09 11:09:11 --> Helper loaded: form_helper
INFO - 2018-02-09 11:09:11 --> Form Validation Class Initialized
INFO - 2018-02-09 11:09:11 --> Model Class Initialized
INFO - 2018-02-09 11:09:11 --> Controller Class Initialized
DEBUG - 2018-02-09 11:09:11 --> Config file loaded: /var/www/html/project/spamblocker/application/config/rest.php
INFO - 2018-02-09 11:09:11 --> Helper loaded: inflector_helper
INFO - 2018-02-09 11:09:11 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-09 11:09:11 --> Model Class Initialized
INFO - 2018-02-09 11:09:11 --> Model Class Initialized
INFO - 2018-02-09 11:09:11 --> Final output sent to browser
DEBUG - 2018-02-09 11:09:11 --> Total execution time: 0.0056
INFO - 2018-02-09 11:09:55 --> Config Class Initialized
INFO - 2018-02-09 11:09:55 --> Hooks Class Initialized
DEBUG - 2018-02-09 11:09:55 --> UTF-8 Support Enabled
INFO - 2018-02-09 11:09:55 --> Utf8 Class Initialized
INFO - 2018-02-09 11:09:55 --> URI Class Initialized
INFO - 2018-02-09 11:09:55 --> Router Class Initialized
INFO - 2018-02-09 11:09:55 --> Output Class Initialized
INFO - 2018-02-09 11:09:55 --> Security Class Initialized
DEBUG - 2018-02-09 11:09:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-09 11:09:55 --> Input Class Initialized
INFO - 2018-02-09 11:09:55 --> Language Class Initialized
INFO - 2018-02-09 11:09:55 --> Loader Class Initialized
INFO - 2018-02-09 11:09:55 --> Helper loaded: url_helper
INFO - 2018-02-09 11:09:55 --> Helper loaded: file_helper
INFO - 2018-02-09 11:09:55 --> Helper loaded: email_helper
INFO - 2018-02-09 11:09:55 --> Helper loaded: common_helper
INFO - 2018-02-09 11:09:55 --> Database Driver Class Initialized
DEBUG - 2018-02-09 11:09:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-09 11:09:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-09 11:09:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-09 11:09:55 --> Pagination Class Initialized
INFO - 2018-02-09 11:09:55 --> Helper loaded: form_helper
INFO - 2018-02-09 11:09:55 --> Form Validation Class Initialized
INFO - 2018-02-09 11:09:55 --> Model Class Initialized
INFO - 2018-02-09 11:09:55 --> Controller Class Initialized
DEBUG - 2018-02-09 11:09:55 --> Config file loaded: /var/www/html/project/spamblocker/application/config/rest.php
INFO - 2018-02-09 11:09:55 --> Helper loaded: inflector_helper
INFO - 2018-02-09 11:09:55 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-09 11:09:55 --> Model Class Initialized
INFO - 2018-02-09 11:09:55 --> Model Class Initialized
INFO - 2018-02-09 11:09:55 --> Final output sent to browser
DEBUG - 2018-02-09 11:09:55 --> Total execution time: 0.0081
INFO - 2018-02-09 11:25:08 --> Config Class Initialized
INFO - 2018-02-09 11:25:08 --> Hooks Class Initialized
DEBUG - 2018-02-09 11:25:08 --> UTF-8 Support Enabled
INFO - 2018-02-09 11:25:08 --> Utf8 Class Initialized
INFO - 2018-02-09 11:25:08 --> URI Class Initialized
INFO - 2018-02-09 11:25:08 --> Router Class Initialized
INFO - 2018-02-09 11:25:08 --> Output Class Initialized
INFO - 2018-02-09 11:25:08 --> Security Class Initialized
DEBUG - 2018-02-09 11:25:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-09 11:25:08 --> Input Class Initialized
INFO - 2018-02-09 11:25:08 --> Language Class Initialized
INFO - 2018-02-09 11:25:08 --> Loader Class Initialized
INFO - 2018-02-09 11:25:08 --> Helper loaded: url_helper
INFO - 2018-02-09 11:25:08 --> Helper loaded: file_helper
INFO - 2018-02-09 11:25:08 --> Helper loaded: email_helper
INFO - 2018-02-09 11:25:08 --> Helper loaded: common_helper
INFO - 2018-02-09 11:25:08 --> Database Driver Class Initialized
DEBUG - 2018-02-09 11:25:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-09 11:25:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-09 11:25:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-09 11:25:08 --> Pagination Class Initialized
INFO - 2018-02-09 11:25:08 --> Helper loaded: form_helper
INFO - 2018-02-09 11:25:08 --> Form Validation Class Initialized
INFO - 2018-02-09 11:25:08 --> Model Class Initialized
INFO - 2018-02-09 11:25:08 --> Controller Class Initialized
DEBUG - 2018-02-09 11:25:08 --> Config file loaded: /var/www/html/project/spamblocker/application/config/rest.php
INFO - 2018-02-09 11:25:08 --> Helper loaded: inflector_helper
INFO - 2018-02-09 11:25:08 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-09 11:25:08 --> Model Class Initialized
INFO - 2018-02-09 11:25:08 --> Model Class Initialized
INFO - 2018-02-09 12:12:55 --> Config Class Initialized
INFO - 2018-02-09 12:12:55 --> Hooks Class Initialized
DEBUG - 2018-02-09 12:12:55 --> UTF-8 Support Enabled
INFO - 2018-02-09 12:12:55 --> Utf8 Class Initialized
INFO - 2018-02-09 12:12:55 --> URI Class Initialized
INFO - 2018-02-09 12:12:55 --> Router Class Initialized
INFO - 2018-02-09 12:12:55 --> Output Class Initialized
INFO - 2018-02-09 12:12:55 --> Security Class Initialized
DEBUG - 2018-02-09 12:12:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-09 12:12:55 --> Input Class Initialized
INFO - 2018-02-09 12:12:55 --> Language Class Initialized
INFO - 2018-02-09 12:12:55 --> Loader Class Initialized
INFO - 2018-02-09 12:12:55 --> Helper loaded: url_helper
INFO - 2018-02-09 12:12:55 --> Helper loaded: file_helper
INFO - 2018-02-09 12:12:55 --> Helper loaded: email_helper
INFO - 2018-02-09 12:12:55 --> Helper loaded: common_helper
INFO - 2018-02-09 12:12:55 --> Database Driver Class Initialized
DEBUG - 2018-02-09 12:12:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-09 12:12:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-09 12:12:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-09 12:12:55 --> Pagination Class Initialized
INFO - 2018-02-09 12:12:55 --> Helper loaded: form_helper
INFO - 2018-02-09 12:12:55 --> Form Validation Class Initialized
INFO - 2018-02-09 12:12:55 --> Model Class Initialized
INFO - 2018-02-09 12:12:55 --> Controller Class Initialized
INFO - 2018-02-09 12:12:55 --> Model Class Initialized
INFO - 2018-02-09 12:12:55 --> Model Class Initialized
ERROR - 2018-02-09 12:12:55 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '?  ''
AND `dm`.`vDeviceType` = 1
AND `um`.`tStatus` = 2
AND `um`.`tIsVerify` = 1' at line 4 - Invalid query: SELECT `um`.*
FROM `user_master` as `um`
JOIN `device_master` as `dm` ON `dm`.`iUserId` = `um`.`iUserId`
WHERE `dm`.`vDeviceToken` != ?  ''
AND `dm`.`vDeviceType` = 1
AND `um`.`tStatus` = 2
AND `um`.`tIsVerify` = 1
INFO - 2018-02-09 12:12:55 --> Language file loaded: language/english/db_lang.php
INFO - 2018-02-09 12:13:45 --> Config Class Initialized
INFO - 2018-02-09 12:13:45 --> Hooks Class Initialized
DEBUG - 2018-02-09 12:13:45 --> UTF-8 Support Enabled
INFO - 2018-02-09 12:13:45 --> Utf8 Class Initialized
INFO - 2018-02-09 12:13:45 --> URI Class Initialized
INFO - 2018-02-09 12:13:45 --> Router Class Initialized
INFO - 2018-02-09 12:13:45 --> Output Class Initialized
INFO - 2018-02-09 12:13:45 --> Security Class Initialized
DEBUG - 2018-02-09 12:13:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-09 12:13:45 --> Input Class Initialized
INFO - 2018-02-09 12:13:45 --> Language Class Initialized
INFO - 2018-02-09 12:13:45 --> Loader Class Initialized
INFO - 2018-02-09 12:13:45 --> Helper loaded: url_helper
INFO - 2018-02-09 12:13:45 --> Helper loaded: file_helper
INFO - 2018-02-09 12:13:45 --> Helper loaded: email_helper
INFO - 2018-02-09 12:13:45 --> Helper loaded: common_helper
INFO - 2018-02-09 12:13:45 --> Database Driver Class Initialized
DEBUG - 2018-02-09 12:13:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-09 12:13:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-09 12:13:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-09 12:13:45 --> Pagination Class Initialized
INFO - 2018-02-09 12:13:45 --> Helper loaded: form_helper
INFO - 2018-02-09 12:13:45 --> Form Validation Class Initialized
INFO - 2018-02-09 12:13:45 --> Model Class Initialized
INFO - 2018-02-09 12:13:45 --> Controller Class Initialized
INFO - 2018-02-09 12:13:45 --> Model Class Initialized
INFO - 2018-02-09 12:13:45 --> Model Class Initialized
ERROR - 2018-02-09 12:13:45 --> Severity: 4096 --> Object of class CI_DB_mysqli_result could not be converted to string /var/www/html/project/spamblocker/application/models/Usermaster_model.php 241
INFO - 2018-02-09 12:14:13 --> Config Class Initialized
INFO - 2018-02-09 12:14:13 --> Hooks Class Initialized
DEBUG - 2018-02-09 12:14:13 --> UTF-8 Support Enabled
INFO - 2018-02-09 12:14:13 --> Utf8 Class Initialized
INFO - 2018-02-09 12:14:13 --> URI Class Initialized
INFO - 2018-02-09 12:14:13 --> Router Class Initialized
INFO - 2018-02-09 12:14:13 --> Output Class Initialized
INFO - 2018-02-09 12:14:13 --> Security Class Initialized
DEBUG - 2018-02-09 12:14:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-09 12:14:13 --> Input Class Initialized
INFO - 2018-02-09 12:14:13 --> Language Class Initialized
INFO - 2018-02-09 12:14:13 --> Loader Class Initialized
INFO - 2018-02-09 12:14:13 --> Helper loaded: url_helper
INFO - 2018-02-09 12:14:13 --> Helper loaded: file_helper
INFO - 2018-02-09 12:14:13 --> Helper loaded: email_helper
INFO - 2018-02-09 12:14:13 --> Helper loaded: common_helper
INFO - 2018-02-09 12:14:13 --> Database Driver Class Initialized
DEBUG - 2018-02-09 12:14:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-09 12:14:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-09 12:14:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-09 12:14:13 --> Pagination Class Initialized
INFO - 2018-02-09 12:14:13 --> Helper loaded: form_helper
INFO - 2018-02-09 12:14:13 --> Form Validation Class Initialized
INFO - 2018-02-09 12:14:13 --> Model Class Initialized
INFO - 2018-02-09 12:14:13 --> Controller Class Initialized
INFO - 2018-02-09 12:14:13 --> Model Class Initialized
INFO - 2018-02-09 12:14:13 --> Model Class Initialized
INFO - 2018-02-09 12:14:30 --> Config Class Initialized
INFO - 2018-02-09 12:14:30 --> Hooks Class Initialized
DEBUG - 2018-02-09 12:14:30 --> UTF-8 Support Enabled
INFO - 2018-02-09 12:14:30 --> Utf8 Class Initialized
INFO - 2018-02-09 12:14:30 --> URI Class Initialized
INFO - 2018-02-09 12:14:30 --> Router Class Initialized
INFO - 2018-02-09 12:14:30 --> Output Class Initialized
INFO - 2018-02-09 12:14:30 --> Security Class Initialized
DEBUG - 2018-02-09 12:14:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-09 12:14:30 --> Input Class Initialized
INFO - 2018-02-09 12:14:30 --> Language Class Initialized
INFO - 2018-02-09 12:14:30 --> Loader Class Initialized
INFO - 2018-02-09 12:14:30 --> Helper loaded: url_helper
INFO - 2018-02-09 12:14:30 --> Helper loaded: file_helper
INFO - 2018-02-09 12:14:30 --> Helper loaded: email_helper
INFO - 2018-02-09 12:14:30 --> Helper loaded: common_helper
INFO - 2018-02-09 12:14:30 --> Database Driver Class Initialized
DEBUG - 2018-02-09 12:14:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-09 12:14:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-09 12:14:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-09 12:14:30 --> Pagination Class Initialized
INFO - 2018-02-09 12:14:30 --> Helper loaded: form_helper
INFO - 2018-02-09 12:14:30 --> Form Validation Class Initialized
INFO - 2018-02-09 12:14:30 --> Model Class Initialized
INFO - 2018-02-09 12:14:30 --> Controller Class Initialized
INFO - 2018-02-09 12:14:30 --> Model Class Initialized
INFO - 2018-02-09 12:14:30 --> Model Class Initialized
INFO - 2018-02-09 12:15:35 --> Config Class Initialized
INFO - 2018-02-09 12:15:35 --> Hooks Class Initialized
DEBUG - 2018-02-09 12:15:35 --> UTF-8 Support Enabled
INFO - 2018-02-09 12:15:35 --> Utf8 Class Initialized
INFO - 2018-02-09 12:15:35 --> URI Class Initialized
INFO - 2018-02-09 12:15:35 --> Router Class Initialized
INFO - 2018-02-09 12:15:35 --> Output Class Initialized
INFO - 2018-02-09 12:15:35 --> Security Class Initialized
DEBUG - 2018-02-09 12:15:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-09 12:15:35 --> Input Class Initialized
INFO - 2018-02-09 12:15:35 --> Language Class Initialized
INFO - 2018-02-09 12:15:35 --> Loader Class Initialized
INFO - 2018-02-09 12:15:35 --> Helper loaded: url_helper
INFO - 2018-02-09 12:15:35 --> Helper loaded: file_helper
INFO - 2018-02-09 12:15:35 --> Helper loaded: email_helper
INFO - 2018-02-09 12:15:35 --> Helper loaded: common_helper
INFO - 2018-02-09 12:15:35 --> Database Driver Class Initialized
DEBUG - 2018-02-09 12:15:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-09 12:15:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-09 12:15:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-09 12:15:35 --> Pagination Class Initialized
INFO - 2018-02-09 12:15:35 --> Helper loaded: form_helper
INFO - 2018-02-09 12:15:35 --> Form Validation Class Initialized
INFO - 2018-02-09 12:15:35 --> Model Class Initialized
INFO - 2018-02-09 12:15:35 --> Controller Class Initialized
INFO - 2018-02-09 12:15:35 --> Model Class Initialized
INFO - 2018-02-09 12:15:35 --> Model Class Initialized
INFO - 2018-02-09 12:15:52 --> Config Class Initialized
INFO - 2018-02-09 12:15:52 --> Hooks Class Initialized
DEBUG - 2018-02-09 12:15:52 --> UTF-8 Support Enabled
INFO - 2018-02-09 12:15:52 --> Utf8 Class Initialized
INFO - 2018-02-09 12:15:52 --> URI Class Initialized
INFO - 2018-02-09 12:15:52 --> Router Class Initialized
INFO - 2018-02-09 12:15:52 --> Output Class Initialized
INFO - 2018-02-09 12:15:52 --> Security Class Initialized
DEBUG - 2018-02-09 12:15:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-09 12:15:52 --> Input Class Initialized
INFO - 2018-02-09 12:15:52 --> Language Class Initialized
INFO - 2018-02-09 12:15:52 --> Loader Class Initialized
INFO - 2018-02-09 12:15:52 --> Helper loaded: url_helper
INFO - 2018-02-09 12:15:52 --> Helper loaded: file_helper
INFO - 2018-02-09 12:15:52 --> Helper loaded: email_helper
INFO - 2018-02-09 12:15:52 --> Helper loaded: common_helper
INFO - 2018-02-09 12:15:52 --> Database Driver Class Initialized
DEBUG - 2018-02-09 12:15:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-09 12:15:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-09 12:15:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-09 12:15:52 --> Pagination Class Initialized
INFO - 2018-02-09 12:15:52 --> Helper loaded: form_helper
INFO - 2018-02-09 12:15:52 --> Form Validation Class Initialized
INFO - 2018-02-09 12:15:52 --> Model Class Initialized
INFO - 2018-02-09 12:15:52 --> Controller Class Initialized
INFO - 2018-02-09 12:15:52 --> Model Class Initialized
INFO - 2018-02-09 12:15:52 --> Model Class Initialized
INFO - 2018-02-09 12:17:04 --> Config Class Initialized
INFO - 2018-02-09 12:17:04 --> Hooks Class Initialized
DEBUG - 2018-02-09 12:17:04 --> UTF-8 Support Enabled
INFO - 2018-02-09 12:17:04 --> Utf8 Class Initialized
INFO - 2018-02-09 12:17:04 --> URI Class Initialized
INFO - 2018-02-09 12:17:04 --> Router Class Initialized
INFO - 2018-02-09 12:17:04 --> Output Class Initialized
INFO - 2018-02-09 12:17:04 --> Security Class Initialized
DEBUG - 2018-02-09 12:17:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-09 12:17:04 --> Input Class Initialized
INFO - 2018-02-09 12:17:04 --> Language Class Initialized
INFO - 2018-02-09 12:17:04 --> Loader Class Initialized
INFO - 2018-02-09 12:17:04 --> Helper loaded: url_helper
INFO - 2018-02-09 12:17:04 --> Helper loaded: file_helper
INFO - 2018-02-09 12:17:04 --> Helper loaded: email_helper
INFO - 2018-02-09 12:17:04 --> Helper loaded: common_helper
INFO - 2018-02-09 12:17:04 --> Database Driver Class Initialized
DEBUG - 2018-02-09 12:17:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-09 12:17:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-09 12:17:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-09 12:17:04 --> Pagination Class Initialized
INFO - 2018-02-09 12:17:04 --> Helper loaded: form_helper
INFO - 2018-02-09 12:17:04 --> Form Validation Class Initialized
INFO - 2018-02-09 12:17:04 --> Model Class Initialized
INFO - 2018-02-09 12:17:04 --> Controller Class Initialized
INFO - 2018-02-09 12:17:04 --> Model Class Initialized
INFO - 2018-02-09 12:17:04 --> Model Class Initialized
INFO - 2018-02-09 12:17:42 --> Config Class Initialized
INFO - 2018-02-09 12:17:42 --> Hooks Class Initialized
DEBUG - 2018-02-09 12:17:42 --> UTF-8 Support Enabled
INFO - 2018-02-09 12:17:42 --> Utf8 Class Initialized
INFO - 2018-02-09 12:17:42 --> URI Class Initialized
INFO - 2018-02-09 12:17:42 --> Router Class Initialized
INFO - 2018-02-09 12:17:42 --> Output Class Initialized
INFO - 2018-02-09 12:17:42 --> Security Class Initialized
DEBUG - 2018-02-09 12:17:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-09 12:17:42 --> Input Class Initialized
INFO - 2018-02-09 12:17:42 --> Language Class Initialized
INFO - 2018-02-09 12:17:42 --> Loader Class Initialized
INFO - 2018-02-09 12:17:42 --> Helper loaded: url_helper
INFO - 2018-02-09 12:17:42 --> Helper loaded: file_helper
INFO - 2018-02-09 12:17:42 --> Helper loaded: email_helper
INFO - 2018-02-09 12:17:42 --> Helper loaded: common_helper
INFO - 2018-02-09 12:17:42 --> Database Driver Class Initialized
DEBUG - 2018-02-09 12:17:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-09 12:17:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-09 12:17:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-09 12:17:42 --> Pagination Class Initialized
INFO - 2018-02-09 12:17:42 --> Helper loaded: form_helper
INFO - 2018-02-09 12:17:42 --> Form Validation Class Initialized
INFO - 2018-02-09 12:17:42 --> Model Class Initialized
INFO - 2018-02-09 12:17:42 --> Controller Class Initialized
INFO - 2018-02-09 12:17:42 --> Model Class Initialized
INFO - 2018-02-09 12:17:42 --> Model Class Initialized
INFO - 2018-02-09 12:26:19 --> Config Class Initialized
INFO - 2018-02-09 12:26:19 --> Hooks Class Initialized
DEBUG - 2018-02-09 12:26:19 --> UTF-8 Support Enabled
INFO - 2018-02-09 12:26:19 --> Utf8 Class Initialized
INFO - 2018-02-09 12:26:19 --> URI Class Initialized
INFO - 2018-02-09 12:26:19 --> Router Class Initialized
INFO - 2018-02-09 12:26:19 --> Output Class Initialized
INFO - 2018-02-09 12:26:19 --> Security Class Initialized
DEBUG - 2018-02-09 12:26:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-09 12:26:19 --> Input Class Initialized
INFO - 2018-02-09 12:26:19 --> Language Class Initialized
INFO - 2018-02-09 12:26:19 --> Loader Class Initialized
INFO - 2018-02-09 12:26:19 --> Helper loaded: url_helper
INFO - 2018-02-09 12:26:19 --> Helper loaded: file_helper
INFO - 2018-02-09 12:26:19 --> Helper loaded: email_helper
INFO - 2018-02-09 12:26:19 --> Helper loaded: common_helper
INFO - 2018-02-09 12:26:19 --> Database Driver Class Initialized
DEBUG - 2018-02-09 12:26:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-09 12:26:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-09 12:26:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-09 12:26:19 --> Pagination Class Initialized
INFO - 2018-02-09 12:26:19 --> Helper loaded: form_helper
INFO - 2018-02-09 12:26:19 --> Form Validation Class Initialized
INFO - 2018-02-09 12:26:19 --> Model Class Initialized
INFO - 2018-02-09 12:26:19 --> Controller Class Initialized
INFO - 2018-02-09 12:26:19 --> Model Class Initialized
INFO - 2018-02-09 12:26:19 --> Model Class Initialized
INFO - 2018-02-09 12:26:53 --> Config Class Initialized
INFO - 2018-02-09 12:26:53 --> Hooks Class Initialized
DEBUG - 2018-02-09 12:26:53 --> UTF-8 Support Enabled
INFO - 2018-02-09 12:26:53 --> Utf8 Class Initialized
INFO - 2018-02-09 12:26:53 --> URI Class Initialized
INFO - 2018-02-09 12:26:53 --> Router Class Initialized
INFO - 2018-02-09 12:26:53 --> Output Class Initialized
INFO - 2018-02-09 12:26:53 --> Security Class Initialized
DEBUG - 2018-02-09 12:26:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-09 12:26:53 --> Input Class Initialized
INFO - 2018-02-09 12:26:53 --> Language Class Initialized
INFO - 2018-02-09 12:26:53 --> Loader Class Initialized
INFO - 2018-02-09 12:26:53 --> Helper loaded: url_helper
INFO - 2018-02-09 12:26:53 --> Helper loaded: file_helper
INFO - 2018-02-09 12:26:53 --> Helper loaded: email_helper
INFO - 2018-02-09 12:26:53 --> Helper loaded: common_helper
INFO - 2018-02-09 12:26:53 --> Database Driver Class Initialized
DEBUG - 2018-02-09 12:26:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-09 12:26:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-09 12:26:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-09 12:26:53 --> Pagination Class Initialized
INFO - 2018-02-09 12:26:53 --> Helper loaded: form_helper
INFO - 2018-02-09 12:26:53 --> Form Validation Class Initialized
INFO - 2018-02-09 12:26:53 --> Model Class Initialized
INFO - 2018-02-09 12:26:53 --> Controller Class Initialized
INFO - 2018-02-09 12:26:53 --> Model Class Initialized
INFO - 2018-02-09 12:26:53 --> Model Class Initialized
INFO - 2018-02-09 12:48:09 --> Config Class Initialized
INFO - 2018-02-09 12:48:09 --> Hooks Class Initialized
DEBUG - 2018-02-09 12:48:09 --> UTF-8 Support Enabled
INFO - 2018-02-09 12:48:09 --> Utf8 Class Initialized
INFO - 2018-02-09 12:48:09 --> URI Class Initialized
INFO - 2018-02-09 12:48:09 --> Router Class Initialized
INFO - 2018-02-09 12:48:09 --> Output Class Initialized
INFO - 2018-02-09 12:48:09 --> Security Class Initialized
DEBUG - 2018-02-09 12:48:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-09 12:48:09 --> Input Class Initialized
INFO - 2018-02-09 12:48:09 --> Language Class Initialized
INFO - 2018-02-09 12:48:09 --> Loader Class Initialized
INFO - 2018-02-09 12:48:09 --> Helper loaded: url_helper
INFO - 2018-02-09 12:48:09 --> Helper loaded: file_helper
INFO - 2018-02-09 12:48:09 --> Helper loaded: email_helper
INFO - 2018-02-09 12:48:09 --> Helper loaded: common_helper
INFO - 2018-02-09 12:48:09 --> Database Driver Class Initialized
DEBUG - 2018-02-09 12:48:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-09 12:48:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-09 12:48:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-09 12:48:09 --> Pagination Class Initialized
INFO - 2018-02-09 12:48:09 --> Helper loaded: form_helper
INFO - 2018-02-09 12:48:09 --> Form Validation Class Initialized
INFO - 2018-02-09 12:48:09 --> Model Class Initialized
INFO - 2018-02-09 12:48:09 --> Controller Class Initialized
INFO - 2018-02-09 12:48:09 --> Model Class Initialized
INFO - 2018-02-09 12:48:09 --> Model Class Initialized
INFO - 2018-02-09 12:48:09 --> Model Class Initialized
INFO - 2018-02-09 13:23:07 --> Config Class Initialized
INFO - 2018-02-09 13:23:07 --> Hooks Class Initialized
DEBUG - 2018-02-09 13:23:07 --> UTF-8 Support Enabled
INFO - 2018-02-09 13:23:07 --> Utf8 Class Initialized
INFO - 2018-02-09 13:23:07 --> URI Class Initialized
INFO - 2018-02-09 13:23:07 --> Router Class Initialized
INFO - 2018-02-09 13:23:07 --> Output Class Initialized
INFO - 2018-02-09 13:23:07 --> Security Class Initialized
DEBUG - 2018-02-09 13:23:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-09 13:23:07 --> Input Class Initialized
INFO - 2018-02-09 13:23:07 --> Language Class Initialized
INFO - 2018-02-09 13:23:07 --> Loader Class Initialized
INFO - 2018-02-09 13:23:07 --> Helper loaded: url_helper
INFO - 2018-02-09 13:23:07 --> Helper loaded: file_helper
INFO - 2018-02-09 13:23:07 --> Helper loaded: email_helper
INFO - 2018-02-09 13:23:07 --> Helper loaded: common_helper
INFO - 2018-02-09 13:23:07 --> Database Driver Class Initialized
DEBUG - 2018-02-09 13:23:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-09 13:23:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-09 13:23:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-09 13:23:07 --> Pagination Class Initialized
INFO - 2018-02-09 13:23:07 --> Helper loaded: form_helper
INFO - 2018-02-09 13:23:07 --> Form Validation Class Initialized
INFO - 2018-02-09 13:23:07 --> Model Class Initialized
INFO - 2018-02-09 13:23:07 --> Controller Class Initialized
DEBUG - 2018-02-09 13:23:07 --> Config file loaded: /var/www/html/project/spamblocker/application/config/rest.php
INFO - 2018-02-09 13:23:07 --> Helper loaded: inflector_helper
INFO - 2018-02-09 13:23:07 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-09 13:23:07 --> Model Class Initialized
INFO - 2018-02-09 13:23:07 --> Model Class Initialized
INFO - 2018-02-09 13:23:07 --> Final output sent to browser
DEBUG - 2018-02-09 13:23:07 --> Total execution time: 0.0710
INFO - 2018-02-09 13:23:49 --> Config Class Initialized
INFO - 2018-02-09 13:23:49 --> Hooks Class Initialized
DEBUG - 2018-02-09 13:23:49 --> UTF-8 Support Enabled
INFO - 2018-02-09 13:23:49 --> Utf8 Class Initialized
INFO - 2018-02-09 13:23:49 --> URI Class Initialized
INFO - 2018-02-09 13:23:49 --> Router Class Initialized
INFO - 2018-02-09 13:23:49 --> Output Class Initialized
INFO - 2018-02-09 13:23:49 --> Security Class Initialized
DEBUG - 2018-02-09 13:23:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-09 13:23:49 --> Input Class Initialized
INFO - 2018-02-09 13:23:49 --> Language Class Initialized
INFO - 2018-02-09 13:23:49 --> Loader Class Initialized
INFO - 2018-02-09 13:23:49 --> Helper loaded: url_helper
INFO - 2018-02-09 13:23:49 --> Helper loaded: file_helper
INFO - 2018-02-09 13:23:49 --> Helper loaded: email_helper
INFO - 2018-02-09 13:23:49 --> Helper loaded: common_helper
INFO - 2018-02-09 13:23:49 --> Database Driver Class Initialized
DEBUG - 2018-02-09 13:23:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-09 13:23:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-09 13:23:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-09 13:23:49 --> Pagination Class Initialized
INFO - 2018-02-09 13:23:49 --> Helper loaded: form_helper
INFO - 2018-02-09 13:23:49 --> Form Validation Class Initialized
INFO - 2018-02-09 13:23:49 --> Model Class Initialized
INFO - 2018-02-09 13:23:49 --> Controller Class Initialized
DEBUG - 2018-02-09 13:23:49 --> Config file loaded: /var/www/html/project/spamblocker/application/config/rest.php
INFO - 2018-02-09 13:23:49 --> Helper loaded: inflector_helper
INFO - 2018-02-09 13:23:49 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-09 13:23:49 --> Model Class Initialized
INFO - 2018-02-09 13:23:49 --> Model Class Initialized
INFO - 2018-02-09 13:23:49 --> Model Class Initialized
ERROR - 2018-02-09 13:23:49 --> Severity: error --> Exception: Call to undefined method Notifaction_model::fetchNotifactionList() /var/www/html/project/spamblocker/application/controllers/api/Oauth.php 781
INFO - 2018-02-09 13:25:03 --> Config Class Initialized
INFO - 2018-02-09 13:25:03 --> Hooks Class Initialized
DEBUG - 2018-02-09 13:25:03 --> UTF-8 Support Enabled
INFO - 2018-02-09 13:25:03 --> Utf8 Class Initialized
INFO - 2018-02-09 13:25:03 --> URI Class Initialized
INFO - 2018-02-09 13:25:03 --> Router Class Initialized
INFO - 2018-02-09 13:25:03 --> Output Class Initialized
INFO - 2018-02-09 13:25:03 --> Security Class Initialized
DEBUG - 2018-02-09 13:25:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-09 13:25:03 --> Input Class Initialized
INFO - 2018-02-09 13:25:03 --> Language Class Initialized
INFO - 2018-02-09 13:25:03 --> Loader Class Initialized
INFO - 2018-02-09 13:25:03 --> Helper loaded: url_helper
INFO - 2018-02-09 13:25:03 --> Helper loaded: file_helper
INFO - 2018-02-09 13:25:03 --> Helper loaded: email_helper
INFO - 2018-02-09 13:25:03 --> Helper loaded: common_helper
INFO - 2018-02-09 13:25:03 --> Database Driver Class Initialized
DEBUG - 2018-02-09 13:25:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-09 13:25:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-09 13:25:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-09 13:25:03 --> Pagination Class Initialized
INFO - 2018-02-09 13:25:03 --> Helper loaded: form_helper
INFO - 2018-02-09 13:25:03 --> Form Validation Class Initialized
INFO - 2018-02-09 13:25:03 --> Model Class Initialized
INFO - 2018-02-09 13:25:03 --> Controller Class Initialized
DEBUG - 2018-02-09 13:25:03 --> Config file loaded: /var/www/html/project/spamblocker/application/config/rest.php
INFO - 2018-02-09 13:25:03 --> Helper loaded: inflector_helper
INFO - 2018-02-09 13:25:03 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-09 13:25:03 --> Model Class Initialized
INFO - 2018-02-09 13:25:03 --> Model Class Initialized
INFO - 2018-02-09 13:25:03 --> Model Class Initialized
INFO - 2018-02-09 13:25:37 --> Config Class Initialized
INFO - 2018-02-09 13:25:37 --> Hooks Class Initialized
DEBUG - 2018-02-09 13:25:37 --> UTF-8 Support Enabled
INFO - 2018-02-09 13:25:37 --> Utf8 Class Initialized
INFO - 2018-02-09 13:25:37 --> URI Class Initialized
INFO - 2018-02-09 13:25:37 --> Router Class Initialized
INFO - 2018-02-09 13:25:37 --> Output Class Initialized
INFO - 2018-02-09 13:25:37 --> Security Class Initialized
DEBUG - 2018-02-09 13:25:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-09 13:25:37 --> Input Class Initialized
INFO - 2018-02-09 13:25:37 --> Language Class Initialized
INFO - 2018-02-09 13:25:37 --> Loader Class Initialized
INFO - 2018-02-09 13:25:37 --> Helper loaded: url_helper
INFO - 2018-02-09 13:25:37 --> Helper loaded: file_helper
INFO - 2018-02-09 13:25:37 --> Helper loaded: email_helper
INFO - 2018-02-09 13:25:37 --> Helper loaded: common_helper
INFO - 2018-02-09 13:25:37 --> Database Driver Class Initialized
DEBUG - 2018-02-09 13:25:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-09 13:25:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-09 13:25:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-09 13:25:37 --> Pagination Class Initialized
INFO - 2018-02-09 13:25:37 --> Helper loaded: form_helper
INFO - 2018-02-09 13:25:37 --> Form Validation Class Initialized
INFO - 2018-02-09 13:25:37 --> Model Class Initialized
INFO - 2018-02-09 13:25:37 --> Controller Class Initialized
INFO - 2018-02-09 13:25:37 --> Model Class Initialized
INFO - 2018-02-09 13:25:37 --> Model Class Initialized
INFO - 2018-02-09 13:25:37 --> Model Class Initialized
INFO - 2018-02-09 13:25:41 --> Config Class Initialized
INFO - 2018-02-09 13:25:41 --> Hooks Class Initialized
DEBUG - 2018-02-09 13:25:41 --> UTF-8 Support Enabled
INFO - 2018-02-09 13:25:41 --> Utf8 Class Initialized
INFO - 2018-02-09 13:25:41 --> URI Class Initialized
INFO - 2018-02-09 13:25:41 --> Router Class Initialized
INFO - 2018-02-09 13:25:41 --> Output Class Initialized
INFO - 2018-02-09 13:25:41 --> Security Class Initialized
DEBUG - 2018-02-09 13:25:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-09 13:25:41 --> Input Class Initialized
INFO - 2018-02-09 13:25:41 --> Language Class Initialized
INFO - 2018-02-09 13:25:41 --> Loader Class Initialized
INFO - 2018-02-09 13:25:41 --> Helper loaded: url_helper
INFO - 2018-02-09 13:25:41 --> Helper loaded: file_helper
INFO - 2018-02-09 13:25:41 --> Helper loaded: email_helper
INFO - 2018-02-09 13:25:41 --> Helper loaded: common_helper
INFO - 2018-02-09 13:25:41 --> Database Driver Class Initialized
DEBUG - 2018-02-09 13:25:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-09 13:25:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-09 13:25:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-09 13:25:41 --> Pagination Class Initialized
INFO - 2018-02-09 13:25:41 --> Helper loaded: form_helper
INFO - 2018-02-09 13:25:41 --> Form Validation Class Initialized
INFO - 2018-02-09 13:25:41 --> Model Class Initialized
INFO - 2018-02-09 13:25:41 --> Controller Class Initialized
DEBUG - 2018-02-09 13:25:41 --> Config file loaded: /var/www/html/project/spamblocker/application/config/rest.php
INFO - 2018-02-09 13:25:41 --> Helper loaded: inflector_helper
INFO - 2018-02-09 13:25:41 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-09 13:25:41 --> Model Class Initialized
INFO - 2018-02-09 13:25:41 --> Model Class Initialized
INFO - 2018-02-09 13:25:41 --> Model Class Initialized
INFO - 2018-02-09 13:25:41 --> Final output sent to browser
DEBUG - 2018-02-09 13:25:41 --> Total execution time: 0.0075
INFO - 2018-02-09 14:33:09 --> Config Class Initialized
INFO - 2018-02-09 14:33:09 --> Hooks Class Initialized
DEBUG - 2018-02-09 14:33:09 --> UTF-8 Support Enabled
INFO - 2018-02-09 14:33:09 --> Utf8 Class Initialized
INFO - 2018-02-09 14:33:09 --> URI Class Initialized
INFO - 2018-02-09 14:33:09 --> Router Class Initialized
INFO - 2018-02-09 14:33:09 --> Output Class Initialized
INFO - 2018-02-09 14:33:09 --> Security Class Initialized
DEBUG - 2018-02-09 14:33:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-09 14:33:09 --> Input Class Initialized
INFO - 2018-02-09 14:33:09 --> Language Class Initialized
INFO - 2018-02-09 14:33:09 --> Loader Class Initialized
INFO - 2018-02-09 14:33:09 --> Helper loaded: url_helper
INFO - 2018-02-09 14:33:09 --> Helper loaded: file_helper
INFO - 2018-02-09 14:33:09 --> Helper loaded: email_helper
INFO - 2018-02-09 14:33:09 --> Helper loaded: common_helper
INFO - 2018-02-09 14:33:09 --> Database Driver Class Initialized
DEBUG - 2018-02-09 14:33:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-09 14:33:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-09 14:33:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-09 14:33:09 --> Pagination Class Initialized
INFO - 2018-02-09 14:33:09 --> Helper loaded: form_helper
INFO - 2018-02-09 14:33:09 --> Form Validation Class Initialized
INFO - 2018-02-09 14:33:09 --> Model Class Initialized
INFO - 2018-02-09 14:33:09 --> Controller Class Initialized
INFO - 2018-02-09 14:33:09 --> Model Class Initialized
INFO - 2018-02-09 14:33:09 --> Model Class Initialized
INFO - 2018-02-09 14:34:13 --> Config Class Initialized
INFO - 2018-02-09 14:34:13 --> Hooks Class Initialized
DEBUG - 2018-02-09 14:34:13 --> UTF-8 Support Enabled
INFO - 2018-02-09 14:34:13 --> Utf8 Class Initialized
INFO - 2018-02-09 14:34:13 --> URI Class Initialized
INFO - 2018-02-09 14:34:13 --> Router Class Initialized
INFO - 2018-02-09 14:34:13 --> Output Class Initialized
INFO - 2018-02-09 14:34:13 --> Security Class Initialized
DEBUG - 2018-02-09 14:34:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-09 14:34:13 --> Input Class Initialized
INFO - 2018-02-09 14:34:13 --> Language Class Initialized
INFO - 2018-02-09 14:34:13 --> Loader Class Initialized
INFO - 2018-02-09 14:34:13 --> Helper loaded: url_helper
INFO - 2018-02-09 14:34:13 --> Helper loaded: file_helper
INFO - 2018-02-09 14:34:13 --> Helper loaded: email_helper
INFO - 2018-02-09 14:34:13 --> Helper loaded: common_helper
INFO - 2018-02-09 14:34:13 --> Database Driver Class Initialized
DEBUG - 2018-02-09 14:34:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-09 14:34:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-09 14:34:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-09 14:34:13 --> Pagination Class Initialized
INFO - 2018-02-09 14:34:13 --> Helper loaded: form_helper
INFO - 2018-02-09 14:34:13 --> Form Validation Class Initialized
INFO - 2018-02-09 14:34:13 --> Model Class Initialized
INFO - 2018-02-09 14:34:13 --> Controller Class Initialized
INFO - 2018-02-09 14:34:13 --> Model Class Initialized
INFO - 2018-02-09 14:34:13 --> Model Class Initialized
INFO - 2018-02-09 14:35:23 --> Config Class Initialized
INFO - 2018-02-09 14:35:23 --> Hooks Class Initialized
DEBUG - 2018-02-09 14:35:23 --> UTF-8 Support Enabled
INFO - 2018-02-09 14:35:23 --> Utf8 Class Initialized
INFO - 2018-02-09 14:35:23 --> URI Class Initialized
INFO - 2018-02-09 14:35:23 --> Router Class Initialized
INFO - 2018-02-09 14:35:23 --> Output Class Initialized
INFO - 2018-02-09 14:35:23 --> Security Class Initialized
DEBUG - 2018-02-09 14:35:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-09 14:35:23 --> Input Class Initialized
INFO - 2018-02-09 14:35:23 --> Language Class Initialized
INFO - 2018-02-09 14:35:23 --> Loader Class Initialized
INFO - 2018-02-09 14:35:23 --> Helper loaded: url_helper
INFO - 2018-02-09 14:35:23 --> Helper loaded: file_helper
INFO - 2018-02-09 14:35:23 --> Helper loaded: email_helper
INFO - 2018-02-09 14:35:23 --> Helper loaded: common_helper
INFO - 2018-02-09 14:35:23 --> Database Driver Class Initialized
DEBUG - 2018-02-09 14:35:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-09 14:35:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-09 14:35:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-09 14:35:23 --> Pagination Class Initialized
INFO - 2018-02-09 14:35:23 --> Helper loaded: form_helper
INFO - 2018-02-09 14:35:23 --> Form Validation Class Initialized
INFO - 2018-02-09 14:35:23 --> Model Class Initialized
INFO - 2018-02-09 14:35:23 --> Controller Class Initialized
INFO - 2018-02-09 14:35:23 --> Model Class Initialized
INFO - 2018-02-09 14:35:23 --> Model Class Initialized
INFO - 2018-02-09 14:39:04 --> Config Class Initialized
INFO - 2018-02-09 14:39:04 --> Hooks Class Initialized
DEBUG - 2018-02-09 14:39:04 --> UTF-8 Support Enabled
INFO - 2018-02-09 14:39:04 --> Utf8 Class Initialized
INFO - 2018-02-09 14:39:04 --> URI Class Initialized
INFO - 2018-02-09 14:39:04 --> Router Class Initialized
INFO - 2018-02-09 14:39:04 --> Output Class Initialized
INFO - 2018-02-09 14:39:04 --> Security Class Initialized
DEBUG - 2018-02-09 14:39:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-09 14:39:04 --> Input Class Initialized
INFO - 2018-02-09 14:39:04 --> Language Class Initialized
INFO - 2018-02-09 14:39:04 --> Loader Class Initialized
INFO - 2018-02-09 14:39:04 --> Helper loaded: url_helper
INFO - 2018-02-09 14:39:04 --> Helper loaded: file_helper
INFO - 2018-02-09 14:39:04 --> Helper loaded: email_helper
INFO - 2018-02-09 14:39:04 --> Helper loaded: common_helper
INFO - 2018-02-09 14:39:04 --> Database Driver Class Initialized
DEBUG - 2018-02-09 14:39:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-09 14:39:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-09 14:39:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-09 14:39:04 --> Pagination Class Initialized
INFO - 2018-02-09 14:39:04 --> Helper loaded: form_helper
INFO - 2018-02-09 14:39:04 --> Form Validation Class Initialized
INFO - 2018-02-09 14:39:04 --> Model Class Initialized
INFO - 2018-02-09 14:39:04 --> Controller Class Initialized
INFO - 2018-02-09 14:39:04 --> Model Class Initialized
INFO - 2018-02-09 14:39:04 --> Model Class Initialized
INFO - 2018-02-09 14:48:24 --> Config Class Initialized
INFO - 2018-02-09 14:48:24 --> Hooks Class Initialized
DEBUG - 2018-02-09 14:48:24 --> UTF-8 Support Enabled
INFO - 2018-02-09 14:48:24 --> Utf8 Class Initialized
INFO - 2018-02-09 14:48:24 --> URI Class Initialized
INFO - 2018-02-09 14:48:24 --> Router Class Initialized
INFO - 2018-02-09 14:48:24 --> Output Class Initialized
INFO - 2018-02-09 14:48:24 --> Security Class Initialized
DEBUG - 2018-02-09 14:48:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-09 14:48:24 --> Input Class Initialized
INFO - 2018-02-09 14:48:24 --> Language Class Initialized
INFO - 2018-02-09 14:48:24 --> Loader Class Initialized
INFO - 2018-02-09 14:48:24 --> Helper loaded: url_helper
INFO - 2018-02-09 14:48:24 --> Helper loaded: file_helper
INFO - 2018-02-09 14:48:24 --> Helper loaded: email_helper
INFO - 2018-02-09 14:48:24 --> Helper loaded: common_helper
INFO - 2018-02-09 14:48:24 --> Database Driver Class Initialized
DEBUG - 2018-02-09 14:48:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-09 14:48:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-09 14:48:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-09 14:48:24 --> Pagination Class Initialized
INFO - 2018-02-09 14:48:24 --> Helper loaded: form_helper
INFO - 2018-02-09 14:48:24 --> Form Validation Class Initialized
INFO - 2018-02-09 14:48:24 --> Model Class Initialized
INFO - 2018-02-09 14:48:24 --> Controller Class Initialized
DEBUG - 2018-02-09 14:48:24 --> Config file loaded: /var/www/html/project/spamblocker/application/config/rest.php
INFO - 2018-02-09 14:48:24 --> Helper loaded: inflector_helper
INFO - 2018-02-09 14:48:24 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-09 14:48:24 --> Database Driver Class Initialized
INFO - 2018-02-09 14:48:24 --> Model Class Initialized
INFO - 2018-02-09 14:48:24 --> Model Class Initialized
INFO - 2018-02-09 14:48:24 --> Model Class Initialized
INFO - 2018-02-09 14:48:24 --> Final output sent to browser
DEBUG - 2018-02-09 14:48:24 --> Total execution time: 0.0892
INFO - 2018-02-09 14:49:27 --> Config Class Initialized
INFO - 2018-02-09 14:49:27 --> Hooks Class Initialized
DEBUG - 2018-02-09 14:49:27 --> UTF-8 Support Enabled
INFO - 2018-02-09 14:49:27 --> Utf8 Class Initialized
INFO - 2018-02-09 14:49:27 --> URI Class Initialized
INFO - 2018-02-09 14:49:27 --> Router Class Initialized
INFO - 2018-02-09 14:49:27 --> Output Class Initialized
INFO - 2018-02-09 14:49:27 --> Security Class Initialized
DEBUG - 2018-02-09 14:49:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-09 14:49:27 --> Input Class Initialized
INFO - 2018-02-09 14:49:27 --> Language Class Initialized
INFO - 2018-02-09 14:49:27 --> Loader Class Initialized
INFO - 2018-02-09 14:49:27 --> Helper loaded: url_helper
INFO - 2018-02-09 14:49:27 --> Helper loaded: file_helper
INFO - 2018-02-09 14:49:27 --> Helper loaded: email_helper
INFO - 2018-02-09 14:49:27 --> Helper loaded: common_helper
INFO - 2018-02-09 14:49:27 --> Database Driver Class Initialized
DEBUG - 2018-02-09 14:49:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-09 14:49:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-09 14:49:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-09 14:49:27 --> Pagination Class Initialized
INFO - 2018-02-09 14:49:27 --> Helper loaded: form_helper
INFO - 2018-02-09 14:49:27 --> Form Validation Class Initialized
INFO - 2018-02-09 14:49:27 --> Model Class Initialized
INFO - 2018-02-09 14:49:27 --> Controller Class Initialized
DEBUG - 2018-02-09 14:49:27 --> Config file loaded: /var/www/html/project/spamblocker/application/config/rest.php
INFO - 2018-02-09 14:49:27 --> Helper loaded: inflector_helper
INFO - 2018-02-09 14:49:27 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-09 14:49:27 --> Database Driver Class Initialized
INFO - 2018-02-09 14:49:27 --> Model Class Initialized
INFO - 2018-02-09 14:49:27 --> Model Class Initialized
INFO - 2018-02-09 14:49:27 --> Final output sent to browser
DEBUG - 2018-02-09 14:49:27 --> Total execution time: 0.1669
INFO - 2018-02-09 14:51:53 --> Config Class Initialized
INFO - 2018-02-09 14:51:53 --> Hooks Class Initialized
DEBUG - 2018-02-09 14:51:53 --> UTF-8 Support Enabled
INFO - 2018-02-09 14:51:53 --> Utf8 Class Initialized
INFO - 2018-02-09 14:51:53 --> URI Class Initialized
INFO - 2018-02-09 14:51:53 --> Router Class Initialized
INFO - 2018-02-09 14:51:53 --> Output Class Initialized
INFO - 2018-02-09 14:51:53 --> Security Class Initialized
DEBUG - 2018-02-09 14:51:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-09 14:51:53 --> Input Class Initialized
INFO - 2018-02-09 14:51:53 --> Language Class Initialized
INFO - 2018-02-09 14:51:53 --> Loader Class Initialized
INFO - 2018-02-09 14:51:53 --> Helper loaded: url_helper
INFO - 2018-02-09 14:51:53 --> Helper loaded: file_helper
INFO - 2018-02-09 14:51:53 --> Helper loaded: email_helper
INFO - 2018-02-09 14:51:53 --> Helper loaded: common_helper
INFO - 2018-02-09 14:51:53 --> Database Driver Class Initialized
DEBUG - 2018-02-09 14:51:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-09 14:51:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-09 14:51:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-09 14:51:53 --> Pagination Class Initialized
INFO - 2018-02-09 14:51:53 --> Helper loaded: form_helper
INFO - 2018-02-09 14:51:53 --> Form Validation Class Initialized
INFO - 2018-02-09 14:51:53 --> Model Class Initialized
INFO - 2018-02-09 14:51:53 --> Controller Class Initialized
DEBUG - 2018-02-09 14:51:53 --> Config file loaded: /var/www/html/project/spamblocker/application/config/rest.php
INFO - 2018-02-09 14:51:53 --> Helper loaded: inflector_helper
INFO - 2018-02-09 14:51:53 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-09 14:51:53 --> Model Class Initialized
INFO - 2018-02-09 14:51:53 --> Model Class Initialized
INFO - 2018-02-09 14:51:53 --> Final output sent to browser
DEBUG - 2018-02-09 14:51:53 --> Total execution time: 0.0046
INFO - 2018-02-09 14:52:05 --> Config Class Initialized
INFO - 2018-02-09 14:52:05 --> Hooks Class Initialized
DEBUG - 2018-02-09 14:52:05 --> UTF-8 Support Enabled
INFO - 2018-02-09 14:52:05 --> Utf8 Class Initialized
INFO - 2018-02-09 14:52:05 --> URI Class Initialized
INFO - 2018-02-09 14:52:05 --> Router Class Initialized
INFO - 2018-02-09 14:52:05 --> Output Class Initialized
INFO - 2018-02-09 14:52:05 --> Security Class Initialized
DEBUG - 2018-02-09 14:52:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-09 14:52:05 --> Input Class Initialized
INFO - 2018-02-09 14:52:05 --> Language Class Initialized
INFO - 2018-02-09 14:52:05 --> Loader Class Initialized
INFO - 2018-02-09 14:52:05 --> Helper loaded: url_helper
INFO - 2018-02-09 14:52:05 --> Helper loaded: file_helper
INFO - 2018-02-09 14:52:05 --> Helper loaded: email_helper
INFO - 2018-02-09 14:52:05 --> Helper loaded: common_helper
INFO - 2018-02-09 14:52:05 --> Database Driver Class Initialized
DEBUG - 2018-02-09 14:52:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-09 14:52:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-09 14:52:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-09 14:52:05 --> Pagination Class Initialized
INFO - 2018-02-09 14:52:05 --> Helper loaded: form_helper
INFO - 2018-02-09 14:52:05 --> Form Validation Class Initialized
INFO - 2018-02-09 14:52:05 --> Model Class Initialized
INFO - 2018-02-09 14:52:05 --> Controller Class Initialized
DEBUG - 2018-02-09 14:52:05 --> Config file loaded: /var/www/html/project/spamblocker/application/config/rest.php
INFO - 2018-02-09 14:52:05 --> Helper loaded: inflector_helper
INFO - 2018-02-09 14:52:05 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-09 14:52:05 --> Model Class Initialized
INFO - 2018-02-09 14:52:05 --> Model Class Initialized
INFO - 2018-02-09 14:52:05 --> Final output sent to browser
DEBUG - 2018-02-09 14:52:05 --> Total execution time: 0.0044
INFO - 2018-02-09 15:50:17 --> Config Class Initialized
INFO - 2018-02-09 15:50:17 --> Hooks Class Initialized
DEBUG - 2018-02-09 15:50:17 --> UTF-8 Support Enabled
INFO - 2018-02-09 15:50:17 --> Utf8 Class Initialized
INFO - 2018-02-09 15:50:17 --> URI Class Initialized
INFO - 2018-02-09 15:50:17 --> Router Class Initialized
INFO - 2018-02-09 15:50:17 --> Output Class Initialized
INFO - 2018-02-09 15:50:17 --> Security Class Initialized
DEBUG - 2018-02-09 15:50:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-09 15:50:17 --> Input Class Initialized
INFO - 2018-02-09 15:50:17 --> Language Class Initialized
INFO - 2018-02-09 15:50:17 --> Loader Class Initialized
INFO - 2018-02-09 15:50:17 --> Helper loaded: url_helper
INFO - 2018-02-09 15:50:17 --> Helper loaded: file_helper
INFO - 2018-02-09 15:50:17 --> Helper loaded: email_helper
INFO - 2018-02-09 15:50:17 --> Helper loaded: common_helper
INFO - 2018-02-09 15:50:17 --> Database Driver Class Initialized
DEBUG - 2018-02-09 15:50:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-09 15:50:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-09 15:50:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-09 15:50:17 --> Pagination Class Initialized
INFO - 2018-02-09 15:50:17 --> Helper loaded: form_helper
INFO - 2018-02-09 15:50:17 --> Form Validation Class Initialized
INFO - 2018-02-09 15:50:17 --> Model Class Initialized
INFO - 2018-02-09 15:50:17 --> Controller Class Initialized
DEBUG - 2018-02-09 15:50:17 --> Config file loaded: /var/www/html/project/spamblocker/application/config/rest.php
INFO - 2018-02-09 15:50:17 --> Helper loaded: inflector_helper
INFO - 2018-02-09 15:50:17 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-09 15:50:17 --> Model Class Initialized
INFO - 2018-02-09 15:50:17 --> Model Class Initialized
INFO - 2018-02-09 15:50:17 --> Final output sent to browser
DEBUG - 2018-02-09 15:50:17 --> Total execution time: 0.0104
INFO - 2018-02-09 15:50:58 --> Config Class Initialized
INFO - 2018-02-09 15:50:58 --> Hooks Class Initialized
DEBUG - 2018-02-09 15:50:58 --> UTF-8 Support Enabled
INFO - 2018-02-09 15:50:58 --> Utf8 Class Initialized
INFO - 2018-02-09 15:50:58 --> URI Class Initialized
INFO - 2018-02-09 15:50:58 --> Router Class Initialized
INFO - 2018-02-09 15:50:58 --> Output Class Initialized
INFO - 2018-02-09 15:50:58 --> Security Class Initialized
DEBUG - 2018-02-09 15:50:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-09 15:50:58 --> Input Class Initialized
INFO - 2018-02-09 15:50:58 --> Language Class Initialized
INFO - 2018-02-09 15:50:58 --> Loader Class Initialized
INFO - 2018-02-09 15:50:58 --> Helper loaded: url_helper
INFO - 2018-02-09 15:50:58 --> Helper loaded: file_helper
INFO - 2018-02-09 15:50:58 --> Helper loaded: email_helper
INFO - 2018-02-09 15:50:58 --> Helper loaded: common_helper
INFO - 2018-02-09 15:50:58 --> Database Driver Class Initialized
DEBUG - 2018-02-09 15:50:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-09 15:50:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-09 15:50:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-09 15:50:58 --> Pagination Class Initialized
INFO - 2018-02-09 15:50:58 --> Helper loaded: form_helper
INFO - 2018-02-09 15:50:58 --> Form Validation Class Initialized
INFO - 2018-02-09 15:50:58 --> Model Class Initialized
INFO - 2018-02-09 15:50:58 --> Controller Class Initialized
DEBUG - 2018-02-09 15:50:58 --> Config file loaded: /var/www/html/project/spamblocker/application/config/rest.php
INFO - 2018-02-09 15:50:58 --> Helper loaded: inflector_helper
INFO - 2018-02-09 15:50:58 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-09 15:50:58 --> Model Class Initialized
INFO - 2018-02-09 15:50:58 --> Model Class Initialized
INFO - 2018-02-09 15:50:58 --> Model Class Initialized
INFO - 2018-02-09 15:50:58 --> Final output sent to browser
DEBUG - 2018-02-09 15:50:58 --> Total execution time: 0.0143
INFO - 2018-02-09 15:51:04 --> Config Class Initialized
INFO - 2018-02-09 15:51:04 --> Hooks Class Initialized
DEBUG - 2018-02-09 15:51:04 --> UTF-8 Support Enabled
INFO - 2018-02-09 15:51:04 --> Utf8 Class Initialized
INFO - 2018-02-09 15:51:04 --> URI Class Initialized
INFO - 2018-02-09 15:51:04 --> Router Class Initialized
INFO - 2018-02-09 15:51:04 --> Output Class Initialized
INFO - 2018-02-09 15:51:04 --> Security Class Initialized
DEBUG - 2018-02-09 15:51:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-09 15:51:04 --> Input Class Initialized
INFO - 2018-02-09 15:51:04 --> Language Class Initialized
INFO - 2018-02-09 15:51:04 --> Loader Class Initialized
INFO - 2018-02-09 15:51:04 --> Helper loaded: url_helper
INFO - 2018-02-09 15:51:04 --> Helper loaded: file_helper
INFO - 2018-02-09 15:51:04 --> Helper loaded: email_helper
INFO - 2018-02-09 15:51:04 --> Helper loaded: common_helper
INFO - 2018-02-09 15:51:04 --> Database Driver Class Initialized
DEBUG - 2018-02-09 15:51:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-09 15:51:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-09 15:51:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-09 15:51:04 --> Pagination Class Initialized
INFO - 2018-02-09 15:51:04 --> Helper loaded: form_helper
INFO - 2018-02-09 15:51:04 --> Form Validation Class Initialized
INFO - 2018-02-09 15:51:04 --> Model Class Initialized
INFO - 2018-02-09 15:51:04 --> Controller Class Initialized
DEBUG - 2018-02-09 15:51:04 --> Config file loaded: /var/www/html/project/spamblocker/application/config/rest.php
INFO - 2018-02-09 15:51:04 --> Helper loaded: inflector_helper
INFO - 2018-02-09 15:51:04 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-09 15:51:04 --> Model Class Initialized
INFO - 2018-02-09 15:51:04 --> Model Class Initialized
INFO - 2018-02-09 15:51:04 --> Model Class Initialized
INFO - 2018-02-09 15:51:04 --> Final output sent to browser
DEBUG - 2018-02-09 15:51:04 --> Total execution time: 0.0501
INFO - 2018-02-09 16:07:39 --> Config Class Initialized
INFO - 2018-02-09 16:07:39 --> Hooks Class Initialized
DEBUG - 2018-02-09 16:07:39 --> UTF-8 Support Enabled
INFO - 2018-02-09 16:07:39 --> Utf8 Class Initialized
INFO - 2018-02-09 16:07:39 --> URI Class Initialized
INFO - 2018-02-09 16:07:39 --> Router Class Initialized
INFO - 2018-02-09 16:07:39 --> Output Class Initialized
INFO - 2018-02-09 16:07:39 --> Security Class Initialized
DEBUG - 2018-02-09 16:07:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-09 16:07:39 --> Input Class Initialized
INFO - 2018-02-09 16:07:39 --> Language Class Initialized
INFO - 2018-02-09 16:07:39 --> Loader Class Initialized
INFO - 2018-02-09 16:07:39 --> Helper loaded: url_helper
INFO - 2018-02-09 16:07:39 --> Helper loaded: file_helper
INFO - 2018-02-09 16:07:39 --> Helper loaded: email_helper
INFO - 2018-02-09 16:07:39 --> Helper loaded: common_helper
INFO - 2018-02-09 16:07:39 --> Database Driver Class Initialized
DEBUG - 2018-02-09 16:07:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-09 16:07:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-09 16:07:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-09 16:07:39 --> Pagination Class Initialized
INFO - 2018-02-09 16:07:39 --> Helper loaded: form_helper
INFO - 2018-02-09 16:07:39 --> Form Validation Class Initialized
INFO - 2018-02-09 16:07:39 --> Model Class Initialized
INFO - 2018-02-09 16:07:39 --> Controller Class Initialized
DEBUG - 2018-02-09 16:07:39 --> Config file loaded: /var/www/html/project/spamblocker/application/config/rest.php
INFO - 2018-02-09 16:07:39 --> Helper loaded: inflector_helper
INFO - 2018-02-09 16:07:39 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-09 16:07:39 --> Model Class Initialized
INFO - 2018-02-09 16:07:39 --> Model Class Initialized
INFO - 2018-02-09 16:07:39 --> Final output sent to browser
DEBUG - 2018-02-09 16:07:39 --> Total execution time: 0.0112
INFO - 2018-02-09 16:07:50 --> Config Class Initialized
INFO - 2018-02-09 16:07:50 --> Hooks Class Initialized
DEBUG - 2018-02-09 16:07:50 --> UTF-8 Support Enabled
INFO - 2018-02-09 16:07:50 --> Utf8 Class Initialized
INFO - 2018-02-09 16:07:50 --> URI Class Initialized
INFO - 2018-02-09 16:07:50 --> Router Class Initialized
INFO - 2018-02-09 16:07:50 --> Output Class Initialized
INFO - 2018-02-09 16:07:50 --> Security Class Initialized
DEBUG - 2018-02-09 16:07:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-09 16:07:50 --> Input Class Initialized
INFO - 2018-02-09 16:07:50 --> Language Class Initialized
INFO - 2018-02-09 16:07:50 --> Loader Class Initialized
INFO - 2018-02-09 16:07:50 --> Helper loaded: url_helper
INFO - 2018-02-09 16:07:50 --> Helper loaded: file_helper
INFO - 2018-02-09 16:07:50 --> Helper loaded: email_helper
INFO - 2018-02-09 16:07:50 --> Helper loaded: common_helper
INFO - 2018-02-09 16:07:50 --> Database Driver Class Initialized
DEBUG - 2018-02-09 16:07:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-09 16:07:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-09 16:07:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-09 16:07:50 --> Pagination Class Initialized
INFO - 2018-02-09 16:07:50 --> Helper loaded: form_helper
INFO - 2018-02-09 16:07:50 --> Form Validation Class Initialized
INFO - 2018-02-09 16:07:50 --> Model Class Initialized
INFO - 2018-02-09 16:07:50 --> Controller Class Initialized
DEBUG - 2018-02-09 16:07:50 --> Config file loaded: /var/www/html/project/spamblocker/application/config/rest.php
INFO - 2018-02-09 16:07:50 --> Helper loaded: inflector_helper
INFO - 2018-02-09 16:07:50 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-09 16:07:50 --> Model Class Initialized
INFO - 2018-02-09 16:07:50 --> Model Class Initialized
INFO - 2018-02-09 16:07:50 --> Final output sent to browser
DEBUG - 2018-02-09 16:07:50 --> Total execution time: 0.0047
INFO - 2018-02-09 16:08:11 --> Config Class Initialized
INFO - 2018-02-09 16:08:11 --> Hooks Class Initialized
DEBUG - 2018-02-09 16:08:11 --> UTF-8 Support Enabled
INFO - 2018-02-09 16:08:11 --> Utf8 Class Initialized
INFO - 2018-02-09 16:08:11 --> URI Class Initialized
INFO - 2018-02-09 16:08:11 --> Router Class Initialized
INFO - 2018-02-09 16:08:11 --> Output Class Initialized
INFO - 2018-02-09 16:08:11 --> Security Class Initialized
DEBUG - 2018-02-09 16:08:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-09 16:08:11 --> Input Class Initialized
INFO - 2018-02-09 16:08:11 --> Language Class Initialized
INFO - 2018-02-09 16:08:11 --> Loader Class Initialized
INFO - 2018-02-09 16:08:11 --> Helper loaded: url_helper
INFO - 2018-02-09 16:08:11 --> Helper loaded: file_helper
INFO - 2018-02-09 16:08:11 --> Helper loaded: email_helper
INFO - 2018-02-09 16:08:11 --> Helper loaded: common_helper
INFO - 2018-02-09 16:08:11 --> Database Driver Class Initialized
DEBUG - 2018-02-09 16:08:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-09 16:08:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-09 16:08:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-09 16:08:11 --> Pagination Class Initialized
INFO - 2018-02-09 16:08:11 --> Helper loaded: form_helper
INFO - 2018-02-09 16:08:11 --> Form Validation Class Initialized
INFO - 2018-02-09 16:08:11 --> Model Class Initialized
INFO - 2018-02-09 16:08:11 --> Controller Class Initialized
DEBUG - 2018-02-09 16:08:11 --> Config file loaded: /var/www/html/project/spamblocker/application/config/rest.php
INFO - 2018-02-09 16:08:11 --> Helper loaded: inflector_helper
INFO - 2018-02-09 16:08:11 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-09 16:08:11 --> Model Class Initialized
INFO - 2018-02-09 16:08:11 --> Model Class Initialized
INFO - 2018-02-09 16:08:11 --> Final output sent to browser
DEBUG - 2018-02-09 16:08:11 --> Total execution time: 0.0417
INFO - 2018-02-09 16:08:17 --> Config Class Initialized
INFO - 2018-02-09 16:08:17 --> Hooks Class Initialized
DEBUG - 2018-02-09 16:08:17 --> UTF-8 Support Enabled
INFO - 2018-02-09 16:08:17 --> Utf8 Class Initialized
INFO - 2018-02-09 16:08:17 --> URI Class Initialized
INFO - 2018-02-09 16:08:17 --> Router Class Initialized
INFO - 2018-02-09 16:08:17 --> Output Class Initialized
INFO - 2018-02-09 16:08:17 --> Security Class Initialized
DEBUG - 2018-02-09 16:08:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-09 16:08:17 --> Input Class Initialized
INFO - 2018-02-09 16:08:17 --> Language Class Initialized
INFO - 2018-02-09 16:08:17 --> Loader Class Initialized
INFO - 2018-02-09 16:08:17 --> Helper loaded: url_helper
INFO - 2018-02-09 16:08:17 --> Helper loaded: file_helper
INFO - 2018-02-09 16:08:17 --> Helper loaded: email_helper
INFO - 2018-02-09 16:08:17 --> Helper loaded: common_helper
INFO - 2018-02-09 16:08:17 --> Database Driver Class Initialized
DEBUG - 2018-02-09 16:08:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-09 16:08:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-09 16:08:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-09 16:08:17 --> Pagination Class Initialized
INFO - 2018-02-09 16:08:17 --> Helper loaded: form_helper
INFO - 2018-02-09 16:08:17 --> Form Validation Class Initialized
INFO - 2018-02-09 16:08:17 --> Model Class Initialized
INFO - 2018-02-09 16:08:17 --> Controller Class Initialized
DEBUG - 2018-02-09 16:08:17 --> Config file loaded: /var/www/html/project/spamblocker/application/config/rest.php
INFO - 2018-02-09 16:08:17 --> Helper loaded: inflector_helper
INFO - 2018-02-09 16:08:17 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-09 16:08:17 --> Model Class Initialized
INFO - 2018-02-09 16:08:17 --> Model Class Initialized
INFO - 2018-02-09 16:08:17 --> Final output sent to browser
DEBUG - 2018-02-09 16:08:17 --> Total execution time: 0.0491
INFO - 2018-02-09 16:31:24 --> Config Class Initialized
INFO - 2018-02-09 16:31:24 --> Hooks Class Initialized
DEBUG - 2018-02-09 16:31:24 --> UTF-8 Support Enabled
INFO - 2018-02-09 16:31:24 --> Utf8 Class Initialized
INFO - 2018-02-09 16:31:24 --> URI Class Initialized
INFO - 2018-02-09 16:31:24 --> Router Class Initialized
INFO - 2018-02-09 16:31:24 --> Output Class Initialized
INFO - 2018-02-09 16:31:24 --> Security Class Initialized
DEBUG - 2018-02-09 16:31:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-09 16:31:24 --> Input Class Initialized
INFO - 2018-02-09 16:31:24 --> Language Class Initialized
INFO - 2018-02-09 16:31:24 --> Loader Class Initialized
INFO - 2018-02-09 16:31:24 --> Helper loaded: url_helper
INFO - 2018-02-09 16:31:24 --> Helper loaded: file_helper
INFO - 2018-02-09 16:31:24 --> Helper loaded: email_helper
INFO - 2018-02-09 16:31:24 --> Helper loaded: common_helper
INFO - 2018-02-09 16:31:24 --> Database Driver Class Initialized
DEBUG - 2018-02-09 16:31:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-09 16:31:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-09 16:31:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-09 16:31:24 --> Pagination Class Initialized
INFO - 2018-02-09 16:31:24 --> Helper loaded: form_helper
INFO - 2018-02-09 16:31:24 --> Form Validation Class Initialized
INFO - 2018-02-09 16:31:24 --> Model Class Initialized
INFO - 2018-02-09 16:31:24 --> Controller Class Initialized
DEBUG - 2018-02-09 16:31:24 --> Config file loaded: /var/www/html/project/spamblocker/application/config/rest.php
INFO - 2018-02-09 16:31:24 --> Helper loaded: inflector_helper
INFO - 2018-02-09 16:31:24 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-09 16:31:24 --> Model Class Initialized
INFO - 2018-02-09 16:31:24 --> Model Class Initialized
INFO - 2018-02-09 16:31:24 --> Final output sent to browser
DEBUG - 2018-02-09 16:31:24 --> Total execution time: 0.0571
INFO - 2018-02-09 16:43:44 --> Config Class Initialized
INFO - 2018-02-09 16:43:44 --> Hooks Class Initialized
DEBUG - 2018-02-09 16:43:44 --> UTF-8 Support Enabled
INFO - 2018-02-09 16:43:44 --> Utf8 Class Initialized
INFO - 2018-02-09 16:43:44 --> URI Class Initialized
INFO - 2018-02-09 16:43:44 --> Router Class Initialized
INFO - 2018-02-09 16:43:44 --> Output Class Initialized
INFO - 2018-02-09 16:43:44 --> Security Class Initialized
DEBUG - 2018-02-09 16:43:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-09 16:43:44 --> Input Class Initialized
INFO - 2018-02-09 16:43:44 --> Language Class Initialized
INFO - 2018-02-09 16:43:44 --> Loader Class Initialized
INFO - 2018-02-09 16:43:44 --> Helper loaded: url_helper
INFO - 2018-02-09 16:43:44 --> Helper loaded: file_helper
INFO - 2018-02-09 16:43:44 --> Helper loaded: email_helper
INFO - 2018-02-09 16:43:44 --> Helper loaded: common_helper
INFO - 2018-02-09 16:43:44 --> Database Driver Class Initialized
DEBUG - 2018-02-09 16:43:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-09 16:43:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-09 16:43:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-09 16:43:44 --> Pagination Class Initialized
INFO - 2018-02-09 16:43:44 --> Helper loaded: form_helper
INFO - 2018-02-09 16:43:44 --> Form Validation Class Initialized
INFO - 2018-02-09 16:43:44 --> Model Class Initialized
INFO - 2018-02-09 16:43:44 --> Controller Class Initialized
DEBUG - 2018-02-09 16:43:44 --> Config file loaded: /var/www/html/project/spamblocker/application/config/rest.php
INFO - 2018-02-09 16:43:44 --> Helper loaded: inflector_helper
INFO - 2018-02-09 16:43:44 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-09 16:43:44 --> Model Class Initialized
INFO - 2018-02-09 16:43:44 --> Model Class Initialized
INFO - 2018-02-09 16:43:44 --> Final output sent to browser
DEBUG - 2018-02-09 16:43:44 --> Total execution time: 0.0458
INFO - 2018-02-09 16:44:38 --> Config Class Initialized
INFO - 2018-02-09 16:44:38 --> Hooks Class Initialized
DEBUG - 2018-02-09 16:44:38 --> UTF-8 Support Enabled
INFO - 2018-02-09 16:44:38 --> Utf8 Class Initialized
INFO - 2018-02-09 16:44:38 --> URI Class Initialized
INFO - 2018-02-09 16:44:38 --> Router Class Initialized
INFO - 2018-02-09 16:44:38 --> Output Class Initialized
INFO - 2018-02-09 16:44:38 --> Security Class Initialized
DEBUG - 2018-02-09 16:44:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-09 16:44:38 --> Input Class Initialized
INFO - 2018-02-09 16:44:38 --> Language Class Initialized
INFO - 2018-02-09 16:44:38 --> Loader Class Initialized
INFO - 2018-02-09 16:44:38 --> Helper loaded: url_helper
INFO - 2018-02-09 16:44:38 --> Helper loaded: file_helper
INFO - 2018-02-09 16:44:38 --> Helper loaded: email_helper
INFO - 2018-02-09 16:44:38 --> Helper loaded: common_helper
INFO - 2018-02-09 16:44:38 --> Database Driver Class Initialized
DEBUG - 2018-02-09 16:44:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-09 16:44:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-09 16:44:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-09 16:44:38 --> Pagination Class Initialized
INFO - 2018-02-09 16:44:38 --> Helper loaded: form_helper
INFO - 2018-02-09 16:44:38 --> Form Validation Class Initialized
INFO - 2018-02-09 16:44:38 --> Model Class Initialized
INFO - 2018-02-09 16:44:38 --> Controller Class Initialized
DEBUG - 2018-02-09 16:44:38 --> Config file loaded: /var/www/html/project/spamblocker/application/config/rest.php
INFO - 2018-02-09 16:44:38 --> Helper loaded: inflector_helper
INFO - 2018-02-09 16:44:38 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-09 16:44:38 --> Model Class Initialized
INFO - 2018-02-09 16:44:38 --> Model Class Initialized
INFO - 2018-02-09 16:44:38 --> Final output sent to browser
DEBUG - 2018-02-09 16:44:38 --> Total execution time: 0.0046
INFO - 2018-02-09 16:45:57 --> Config Class Initialized
INFO - 2018-02-09 16:45:57 --> Hooks Class Initialized
DEBUG - 2018-02-09 16:45:57 --> UTF-8 Support Enabled
INFO - 2018-02-09 16:45:57 --> Utf8 Class Initialized
INFO - 2018-02-09 16:45:57 --> URI Class Initialized
INFO - 2018-02-09 16:45:57 --> Router Class Initialized
INFO - 2018-02-09 16:45:57 --> Output Class Initialized
INFO - 2018-02-09 16:45:57 --> Security Class Initialized
DEBUG - 2018-02-09 16:45:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-09 16:45:57 --> Input Class Initialized
INFO - 2018-02-09 16:45:57 --> Language Class Initialized
INFO - 2018-02-09 16:45:57 --> Loader Class Initialized
INFO - 2018-02-09 16:45:57 --> Helper loaded: url_helper
INFO - 2018-02-09 16:45:57 --> Helper loaded: file_helper
INFO - 2018-02-09 16:45:57 --> Helper loaded: email_helper
INFO - 2018-02-09 16:45:57 --> Helper loaded: common_helper
INFO - 2018-02-09 16:45:57 --> Database Driver Class Initialized
DEBUG - 2018-02-09 16:45:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-09 16:45:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-09 16:45:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-09 16:45:57 --> Pagination Class Initialized
INFO - 2018-02-09 16:45:57 --> Helper loaded: form_helper
INFO - 2018-02-09 16:45:57 --> Form Validation Class Initialized
INFO - 2018-02-09 16:45:57 --> Model Class Initialized
INFO - 2018-02-09 16:45:57 --> Controller Class Initialized
DEBUG - 2018-02-09 16:45:57 --> Config file loaded: /var/www/html/project/spamblocker/application/config/rest.php
INFO - 2018-02-09 16:45:57 --> Helper loaded: inflector_helper
INFO - 2018-02-09 16:45:57 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-09 16:45:57 --> Model Class Initialized
INFO - 2018-02-09 16:45:57 --> Model Class Initialized
INFO - 2018-02-09 16:45:57 --> Model Class Initialized
INFO - 2018-02-09 16:45:57 --> Email Class Initialized
INFO - 2018-02-09 16:46:03 --> Language file loaded: language/english/email_lang.php
INFO - 2018-02-09 16:46:07 --> Final output sent to browser
DEBUG - 2018-02-09 16:46:07 --> Total execution time: 9.2447
INFO - 2018-02-09 16:48:46 --> Config Class Initialized
INFO - 2018-02-09 16:48:46 --> Hooks Class Initialized
DEBUG - 2018-02-09 16:48:46 --> UTF-8 Support Enabled
INFO - 2018-02-09 16:48:46 --> Utf8 Class Initialized
INFO - 2018-02-09 16:48:46 --> URI Class Initialized
INFO - 2018-02-09 16:48:46 --> Router Class Initialized
INFO - 2018-02-09 16:48:46 --> Output Class Initialized
INFO - 2018-02-09 16:48:46 --> Security Class Initialized
DEBUG - 2018-02-09 16:48:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-09 16:48:46 --> Input Class Initialized
INFO - 2018-02-09 16:48:46 --> Language Class Initialized
INFO - 2018-02-09 16:48:46 --> Loader Class Initialized
INFO - 2018-02-09 16:48:46 --> Helper loaded: url_helper
INFO - 2018-02-09 16:48:46 --> Helper loaded: file_helper
INFO - 2018-02-09 16:48:46 --> Helper loaded: email_helper
INFO - 2018-02-09 16:48:46 --> Helper loaded: common_helper
INFO - 2018-02-09 16:48:46 --> Database Driver Class Initialized
DEBUG - 2018-02-09 16:48:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-09 16:48:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-09 16:48:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-09 16:48:46 --> Pagination Class Initialized
INFO - 2018-02-09 16:48:46 --> Helper loaded: form_helper
INFO - 2018-02-09 16:48:46 --> Form Validation Class Initialized
INFO - 2018-02-09 16:48:46 --> Model Class Initialized
INFO - 2018-02-09 16:48:46 --> Controller Class Initialized
DEBUG - 2018-02-09 16:48:46 --> Config file loaded: /var/www/html/project/spamblocker/application/config/rest.php
INFO - 2018-02-09 16:48:46 --> Helper loaded: inflector_helper
INFO - 2018-02-09 16:48:46 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-09 16:48:46 --> Model Class Initialized
INFO - 2018-02-09 16:48:46 --> Model Class Initialized
INFO - 2018-02-09 16:48:46 --> Final output sent to browser
DEBUG - 2018-02-09 16:48:46 --> Total execution time: 0.0039
INFO - 2018-02-09 16:49:11 --> Config Class Initialized
INFO - 2018-02-09 16:49:11 --> Hooks Class Initialized
DEBUG - 2018-02-09 16:49:11 --> UTF-8 Support Enabled
INFO - 2018-02-09 16:49:11 --> Utf8 Class Initialized
INFO - 2018-02-09 16:49:11 --> URI Class Initialized
INFO - 2018-02-09 16:49:11 --> Router Class Initialized
INFO - 2018-02-09 16:49:11 --> Output Class Initialized
INFO - 2018-02-09 16:49:11 --> Security Class Initialized
DEBUG - 2018-02-09 16:49:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-09 16:49:11 --> Input Class Initialized
INFO - 2018-02-09 16:49:11 --> Language Class Initialized
INFO - 2018-02-09 16:49:11 --> Loader Class Initialized
INFO - 2018-02-09 16:49:11 --> Helper loaded: url_helper
INFO - 2018-02-09 16:49:11 --> Helper loaded: file_helper
INFO - 2018-02-09 16:49:11 --> Helper loaded: email_helper
INFO - 2018-02-09 16:49:11 --> Helper loaded: common_helper
INFO - 2018-02-09 16:49:11 --> Database Driver Class Initialized
DEBUG - 2018-02-09 16:49:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-09 16:49:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-09 16:49:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-09 16:49:11 --> Pagination Class Initialized
INFO - 2018-02-09 16:49:11 --> Helper loaded: form_helper
INFO - 2018-02-09 16:49:11 --> Form Validation Class Initialized
INFO - 2018-02-09 16:49:11 --> Model Class Initialized
INFO - 2018-02-09 16:49:11 --> Controller Class Initialized
DEBUG - 2018-02-09 16:49:11 --> Config file loaded: /var/www/html/project/spamblocker/application/config/rest.php
INFO - 2018-02-09 16:49:11 --> Helper loaded: inflector_helper
INFO - 2018-02-09 16:49:11 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-09 16:49:11 --> Model Class Initialized
INFO - 2018-02-09 16:49:11 --> Model Class Initialized
INFO - 2018-02-09 16:49:11 --> Final output sent to browser
DEBUG - 2018-02-09 16:49:11 --> Total execution time: 0.0053
INFO - 2018-02-09 17:00:43 --> Config Class Initialized
INFO - 2018-02-09 17:00:43 --> Hooks Class Initialized
DEBUG - 2018-02-09 17:00:43 --> UTF-8 Support Enabled
INFO - 2018-02-09 17:00:43 --> Utf8 Class Initialized
INFO - 2018-02-09 17:00:43 --> URI Class Initialized
INFO - 2018-02-09 17:00:43 --> Router Class Initialized
INFO - 2018-02-09 17:00:43 --> Output Class Initialized
INFO - 2018-02-09 17:00:43 --> Security Class Initialized
DEBUG - 2018-02-09 17:00:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-09 17:00:43 --> Input Class Initialized
INFO - 2018-02-09 17:00:43 --> Language Class Initialized
INFO - 2018-02-09 17:00:43 --> Loader Class Initialized
INFO - 2018-02-09 17:00:43 --> Helper loaded: url_helper
INFO - 2018-02-09 17:00:43 --> Helper loaded: file_helper
INFO - 2018-02-09 17:00:43 --> Helper loaded: email_helper
INFO - 2018-02-09 17:00:43 --> Helper loaded: common_helper
INFO - 2018-02-09 17:00:43 --> Database Driver Class Initialized
DEBUG - 2018-02-09 17:00:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-09 17:00:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-09 17:00:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-09 17:00:43 --> Pagination Class Initialized
INFO - 2018-02-09 17:00:43 --> Helper loaded: form_helper
INFO - 2018-02-09 17:00:43 --> Form Validation Class Initialized
INFO - 2018-02-09 17:00:43 --> Model Class Initialized
INFO - 2018-02-09 17:00:43 --> Controller Class Initialized
DEBUG - 2018-02-09 17:00:43 --> Config file loaded: /var/www/html/project/spamblocker/application/config/rest.php
INFO - 2018-02-09 17:00:43 --> Helper loaded: inflector_helper
INFO - 2018-02-09 17:00:43 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-09 17:00:43 --> Model Class Initialized
INFO - 2018-02-09 17:00:43 --> Model Class Initialized
INFO - 2018-02-09 17:00:43 --> Final output sent to browser
DEBUG - 2018-02-09 17:00:43 --> Total execution time: 0.0062
INFO - 2018-02-09 17:00:59 --> Config Class Initialized
INFO - 2018-02-09 17:00:59 --> Hooks Class Initialized
DEBUG - 2018-02-09 17:00:59 --> UTF-8 Support Enabled
INFO - 2018-02-09 17:00:59 --> Utf8 Class Initialized
INFO - 2018-02-09 17:00:59 --> URI Class Initialized
INFO - 2018-02-09 17:00:59 --> Router Class Initialized
INFO - 2018-02-09 17:00:59 --> Output Class Initialized
INFO - 2018-02-09 17:00:59 --> Security Class Initialized
DEBUG - 2018-02-09 17:00:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-09 17:00:59 --> Input Class Initialized
INFO - 2018-02-09 17:00:59 --> Language Class Initialized
INFO - 2018-02-09 17:00:59 --> Loader Class Initialized
INFO - 2018-02-09 17:00:59 --> Helper loaded: url_helper
INFO - 2018-02-09 17:00:59 --> Helper loaded: file_helper
INFO - 2018-02-09 17:00:59 --> Helper loaded: email_helper
INFO - 2018-02-09 17:00:59 --> Helper loaded: common_helper
INFO - 2018-02-09 17:00:59 --> Database Driver Class Initialized
DEBUG - 2018-02-09 17:00:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-09 17:00:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-09 17:00:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-09 17:00:59 --> Pagination Class Initialized
INFO - 2018-02-09 17:00:59 --> Helper loaded: form_helper
INFO - 2018-02-09 17:00:59 --> Form Validation Class Initialized
INFO - 2018-02-09 17:00:59 --> Model Class Initialized
INFO - 2018-02-09 17:00:59 --> Controller Class Initialized
DEBUG - 2018-02-09 17:00:59 --> Config file loaded: /var/www/html/project/spamblocker/application/config/rest.php
INFO - 2018-02-09 17:00:59 --> Helper loaded: inflector_helper
INFO - 2018-02-09 17:00:59 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-09 17:00:59 --> Model Class Initialized
INFO - 2018-02-09 17:00:59 --> Model Class Initialized
INFO - 2018-02-09 17:02:29 --> Config Class Initialized
INFO - 2018-02-09 17:02:29 --> Hooks Class Initialized
DEBUG - 2018-02-09 17:02:29 --> UTF-8 Support Enabled
INFO - 2018-02-09 17:02:29 --> Utf8 Class Initialized
INFO - 2018-02-09 17:02:29 --> URI Class Initialized
INFO - 2018-02-09 17:02:29 --> Router Class Initialized
INFO - 2018-02-09 17:02:29 --> Output Class Initialized
INFO - 2018-02-09 17:02:29 --> Security Class Initialized
DEBUG - 2018-02-09 17:02:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-09 17:02:29 --> Input Class Initialized
INFO - 2018-02-09 17:02:29 --> Language Class Initialized
INFO - 2018-02-09 17:02:29 --> Loader Class Initialized
INFO - 2018-02-09 17:02:29 --> Helper loaded: url_helper
INFO - 2018-02-09 17:02:29 --> Helper loaded: file_helper
INFO - 2018-02-09 17:02:29 --> Helper loaded: email_helper
INFO - 2018-02-09 17:02:29 --> Helper loaded: common_helper
INFO - 2018-02-09 17:02:29 --> Database Driver Class Initialized
DEBUG - 2018-02-09 17:02:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-09 17:02:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-09 17:02:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-09 17:02:29 --> Pagination Class Initialized
INFO - 2018-02-09 17:02:29 --> Helper loaded: form_helper
INFO - 2018-02-09 17:02:29 --> Form Validation Class Initialized
INFO - 2018-02-09 17:02:29 --> Model Class Initialized
INFO - 2018-02-09 17:02:29 --> Controller Class Initialized
DEBUG - 2018-02-09 17:02:29 --> Config file loaded: /var/www/html/project/spamblocker/application/config/rest.php
INFO - 2018-02-09 17:02:29 --> Helper loaded: inflector_helper
INFO - 2018-02-09 17:02:29 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-09 17:02:29 --> Model Class Initialized
INFO - 2018-02-09 17:02:29 --> Model Class Initialized
INFO - 2018-02-09 17:05:53 --> Config Class Initialized
INFO - 2018-02-09 17:05:53 --> Hooks Class Initialized
DEBUG - 2018-02-09 17:05:53 --> UTF-8 Support Enabled
INFO - 2018-02-09 17:05:53 --> Utf8 Class Initialized
INFO - 2018-02-09 17:05:53 --> URI Class Initialized
INFO - 2018-02-09 17:05:53 --> Router Class Initialized
INFO - 2018-02-09 17:05:53 --> Output Class Initialized
INFO - 2018-02-09 17:05:53 --> Security Class Initialized
DEBUG - 2018-02-09 17:05:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-09 17:05:53 --> Input Class Initialized
INFO - 2018-02-09 17:05:53 --> Language Class Initialized
INFO - 2018-02-09 17:05:53 --> Loader Class Initialized
INFO - 2018-02-09 17:05:53 --> Helper loaded: url_helper
INFO - 2018-02-09 17:05:53 --> Helper loaded: file_helper
INFO - 2018-02-09 17:05:53 --> Helper loaded: email_helper
INFO - 2018-02-09 17:05:53 --> Helper loaded: common_helper
INFO - 2018-02-09 17:05:53 --> Database Driver Class Initialized
DEBUG - 2018-02-09 17:05:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-09 17:05:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-09 17:05:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-09 17:05:53 --> Pagination Class Initialized
INFO - 2018-02-09 17:05:53 --> Helper loaded: form_helper
INFO - 2018-02-09 17:05:53 --> Form Validation Class Initialized
INFO - 2018-02-09 17:05:53 --> Model Class Initialized
INFO - 2018-02-09 17:05:53 --> Controller Class Initialized
DEBUG - 2018-02-09 17:05:53 --> Config file loaded: /var/www/html/project/spamblocker/application/config/rest.php
INFO - 2018-02-09 17:05:53 --> Helper loaded: inflector_helper
INFO - 2018-02-09 17:05:53 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-09 17:05:53 --> Model Class Initialized
INFO - 2018-02-09 17:05:53 --> Model Class Initialized
INFO - 2018-02-09 17:06:48 --> Config Class Initialized
INFO - 2018-02-09 17:06:48 --> Hooks Class Initialized
DEBUG - 2018-02-09 17:06:48 --> UTF-8 Support Enabled
INFO - 2018-02-09 17:06:48 --> Utf8 Class Initialized
INFO - 2018-02-09 17:06:48 --> URI Class Initialized
INFO - 2018-02-09 17:06:48 --> Router Class Initialized
INFO - 2018-02-09 17:06:48 --> Output Class Initialized
INFO - 2018-02-09 17:06:48 --> Security Class Initialized
DEBUG - 2018-02-09 17:06:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-09 17:06:48 --> Input Class Initialized
INFO - 2018-02-09 17:06:48 --> Language Class Initialized
INFO - 2018-02-09 17:06:48 --> Loader Class Initialized
INFO - 2018-02-09 17:06:48 --> Helper loaded: url_helper
INFO - 2018-02-09 17:06:48 --> Helper loaded: file_helper
INFO - 2018-02-09 17:06:48 --> Helper loaded: email_helper
INFO - 2018-02-09 17:06:48 --> Helper loaded: common_helper
INFO - 2018-02-09 17:06:48 --> Database Driver Class Initialized
DEBUG - 2018-02-09 17:06:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-09 17:06:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-09 17:06:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-09 17:06:48 --> Pagination Class Initialized
INFO - 2018-02-09 17:06:48 --> Helper loaded: form_helper
INFO - 2018-02-09 17:06:48 --> Form Validation Class Initialized
INFO - 2018-02-09 17:06:48 --> Model Class Initialized
INFO - 2018-02-09 17:06:48 --> Controller Class Initialized
DEBUG - 2018-02-09 17:06:48 --> Config file loaded: /var/www/html/project/spamblocker/application/config/rest.php
INFO - 2018-02-09 17:06:48 --> Helper loaded: inflector_helper
INFO - 2018-02-09 17:06:48 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-09 17:06:48 --> Model Class Initialized
INFO - 2018-02-09 17:06:48 --> Model Class Initialized
INFO - 2018-02-09 17:07:03 --> Config Class Initialized
INFO - 2018-02-09 17:07:03 --> Hooks Class Initialized
DEBUG - 2018-02-09 17:07:03 --> UTF-8 Support Enabled
INFO - 2018-02-09 17:07:03 --> Utf8 Class Initialized
INFO - 2018-02-09 17:07:03 --> URI Class Initialized
INFO - 2018-02-09 17:07:03 --> Router Class Initialized
INFO - 2018-02-09 17:07:03 --> Output Class Initialized
INFO - 2018-02-09 17:07:03 --> Security Class Initialized
DEBUG - 2018-02-09 17:07:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-09 17:07:03 --> Input Class Initialized
INFO - 2018-02-09 17:07:03 --> Language Class Initialized
INFO - 2018-02-09 17:07:03 --> Loader Class Initialized
INFO - 2018-02-09 17:07:03 --> Helper loaded: url_helper
INFO - 2018-02-09 17:07:03 --> Helper loaded: file_helper
INFO - 2018-02-09 17:07:03 --> Helper loaded: email_helper
INFO - 2018-02-09 17:07:03 --> Helper loaded: common_helper
INFO - 2018-02-09 17:07:03 --> Database Driver Class Initialized
DEBUG - 2018-02-09 17:07:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-09 17:07:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-09 17:07:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-09 17:07:03 --> Pagination Class Initialized
INFO - 2018-02-09 17:07:03 --> Helper loaded: form_helper
INFO - 2018-02-09 17:07:03 --> Form Validation Class Initialized
INFO - 2018-02-09 17:07:03 --> Model Class Initialized
INFO - 2018-02-09 17:07:03 --> Controller Class Initialized
DEBUG - 2018-02-09 17:07:03 --> Config file loaded: /var/www/html/project/spamblocker/application/config/rest.php
INFO - 2018-02-09 17:07:03 --> Helper loaded: inflector_helper
INFO - 2018-02-09 17:07:03 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-09 17:07:03 --> Model Class Initialized
INFO - 2018-02-09 17:07:03 --> Model Class Initialized
ERROR - 2018-02-09 17:07:03 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '? '919173508626'' at line 3 - Invalid query: SELECT *
FROM `user_master`
WHERE `vNumber` like ? '919173508626'
INFO - 2018-02-09 17:07:03 --> Language file loaded: language/english/db_lang.php
INFO - 2018-02-09 17:07:10 --> Config Class Initialized
INFO - 2018-02-09 17:07:10 --> Hooks Class Initialized
DEBUG - 2018-02-09 17:07:10 --> UTF-8 Support Enabled
INFO - 2018-02-09 17:07:10 --> Utf8 Class Initialized
INFO - 2018-02-09 17:07:10 --> URI Class Initialized
INFO - 2018-02-09 17:07:10 --> Router Class Initialized
INFO - 2018-02-09 17:07:10 --> Output Class Initialized
INFO - 2018-02-09 17:07:10 --> Security Class Initialized
DEBUG - 2018-02-09 17:07:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-09 17:07:10 --> Input Class Initialized
INFO - 2018-02-09 17:07:10 --> Language Class Initialized
INFO - 2018-02-09 17:07:10 --> Loader Class Initialized
INFO - 2018-02-09 17:07:10 --> Helper loaded: url_helper
INFO - 2018-02-09 17:07:10 --> Helper loaded: file_helper
INFO - 2018-02-09 17:07:10 --> Helper loaded: email_helper
INFO - 2018-02-09 17:07:10 --> Helper loaded: common_helper
INFO - 2018-02-09 17:07:10 --> Database Driver Class Initialized
DEBUG - 2018-02-09 17:07:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-09 17:07:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-09 17:07:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-09 17:07:10 --> Pagination Class Initialized
INFO - 2018-02-09 17:07:10 --> Helper loaded: form_helper
INFO - 2018-02-09 17:07:10 --> Form Validation Class Initialized
INFO - 2018-02-09 17:07:10 --> Model Class Initialized
INFO - 2018-02-09 17:07:10 --> Controller Class Initialized
DEBUG - 2018-02-09 17:07:10 --> Config file loaded: /var/www/html/project/spamblocker/application/config/rest.php
INFO - 2018-02-09 17:07:10 --> Helper loaded: inflector_helper
INFO - 2018-02-09 17:07:10 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-09 17:07:10 --> Model Class Initialized
INFO - 2018-02-09 17:07:10 --> Model Class Initialized
ERROR - 2018-02-09 17:07:10 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '% '919173508626'' at line 3 - Invalid query: SELECT *
FROM `user_master`
WHERE `vNumber` like % '919173508626'
INFO - 2018-02-09 17:07:10 --> Language file loaded: language/english/db_lang.php
INFO - 2018-02-09 17:07:15 --> Config Class Initialized
INFO - 2018-02-09 17:07:15 --> Hooks Class Initialized
DEBUG - 2018-02-09 17:07:15 --> UTF-8 Support Enabled
INFO - 2018-02-09 17:07:15 --> Utf8 Class Initialized
INFO - 2018-02-09 17:07:15 --> URI Class Initialized
INFO - 2018-02-09 17:07:15 --> Router Class Initialized
INFO - 2018-02-09 17:07:15 --> Output Class Initialized
INFO - 2018-02-09 17:07:15 --> Security Class Initialized
DEBUG - 2018-02-09 17:07:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-09 17:07:15 --> Input Class Initialized
INFO - 2018-02-09 17:07:15 --> Language Class Initialized
INFO - 2018-02-09 17:07:15 --> Loader Class Initialized
INFO - 2018-02-09 17:07:15 --> Helper loaded: url_helper
INFO - 2018-02-09 17:07:15 --> Helper loaded: file_helper
INFO - 2018-02-09 17:07:15 --> Helper loaded: email_helper
INFO - 2018-02-09 17:07:15 --> Helper loaded: common_helper
INFO - 2018-02-09 17:07:15 --> Database Driver Class Initialized
DEBUG - 2018-02-09 17:07:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-09 17:07:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-09 17:07:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-09 17:07:15 --> Pagination Class Initialized
INFO - 2018-02-09 17:07:15 --> Helper loaded: form_helper
INFO - 2018-02-09 17:07:15 --> Form Validation Class Initialized
INFO - 2018-02-09 17:07:15 --> Model Class Initialized
INFO - 2018-02-09 17:07:15 --> Controller Class Initialized
DEBUG - 2018-02-09 17:07:15 --> Config file loaded: /var/www/html/project/spamblocker/application/config/rest.php
INFO - 2018-02-09 17:07:15 --> Helper loaded: inflector_helper
INFO - 2018-02-09 17:07:15 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-09 17:07:15 --> Model Class Initialized
INFO - 2018-02-09 17:07:15 --> Model Class Initialized
INFO - 2018-02-09 17:07:26 --> Config Class Initialized
INFO - 2018-02-09 17:07:26 --> Hooks Class Initialized
DEBUG - 2018-02-09 17:07:26 --> UTF-8 Support Enabled
INFO - 2018-02-09 17:07:26 --> Utf8 Class Initialized
INFO - 2018-02-09 17:07:26 --> URI Class Initialized
INFO - 2018-02-09 17:07:26 --> Router Class Initialized
INFO - 2018-02-09 17:07:26 --> Output Class Initialized
INFO - 2018-02-09 17:07:26 --> Security Class Initialized
DEBUG - 2018-02-09 17:07:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-09 17:07:26 --> Input Class Initialized
INFO - 2018-02-09 17:07:26 --> Language Class Initialized
INFO - 2018-02-09 17:07:26 --> Loader Class Initialized
INFO - 2018-02-09 17:07:26 --> Helper loaded: url_helper
INFO - 2018-02-09 17:07:26 --> Helper loaded: file_helper
INFO - 2018-02-09 17:07:26 --> Helper loaded: email_helper
INFO - 2018-02-09 17:07:26 --> Helper loaded: common_helper
INFO - 2018-02-09 17:07:26 --> Database Driver Class Initialized
DEBUG - 2018-02-09 17:07:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-09 17:07:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-09 17:07:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-09 17:07:26 --> Pagination Class Initialized
INFO - 2018-02-09 17:07:26 --> Helper loaded: form_helper
INFO - 2018-02-09 17:07:26 --> Form Validation Class Initialized
INFO - 2018-02-09 17:07:26 --> Model Class Initialized
INFO - 2018-02-09 17:07:26 --> Controller Class Initialized
DEBUG - 2018-02-09 17:07:26 --> Config file loaded: /var/www/html/project/spamblocker/application/config/rest.php
INFO - 2018-02-09 17:07:26 --> Helper loaded: inflector_helper
INFO - 2018-02-09 17:07:26 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-09 17:07:26 --> Model Class Initialized
INFO - 2018-02-09 17:07:26 --> Model Class Initialized
INFO - 2018-02-09 17:07:35 --> Config Class Initialized
INFO - 2018-02-09 17:07:35 --> Hooks Class Initialized
DEBUG - 2018-02-09 17:07:35 --> UTF-8 Support Enabled
INFO - 2018-02-09 17:07:35 --> Utf8 Class Initialized
INFO - 2018-02-09 17:07:35 --> URI Class Initialized
INFO - 2018-02-09 17:07:35 --> Router Class Initialized
INFO - 2018-02-09 17:07:35 --> Output Class Initialized
INFO - 2018-02-09 17:07:35 --> Security Class Initialized
DEBUG - 2018-02-09 17:07:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-09 17:07:35 --> Input Class Initialized
INFO - 2018-02-09 17:07:35 --> Language Class Initialized
INFO - 2018-02-09 17:07:35 --> Loader Class Initialized
INFO - 2018-02-09 17:07:35 --> Helper loaded: url_helper
INFO - 2018-02-09 17:07:35 --> Helper loaded: file_helper
INFO - 2018-02-09 17:07:35 --> Helper loaded: email_helper
INFO - 2018-02-09 17:07:35 --> Helper loaded: common_helper
INFO - 2018-02-09 17:07:35 --> Database Driver Class Initialized
DEBUG - 2018-02-09 17:07:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-09 17:07:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-09 17:07:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-09 17:07:35 --> Pagination Class Initialized
INFO - 2018-02-09 17:07:35 --> Helper loaded: form_helper
INFO - 2018-02-09 17:07:35 --> Form Validation Class Initialized
INFO - 2018-02-09 17:07:35 --> Model Class Initialized
INFO - 2018-02-09 17:07:35 --> Controller Class Initialized
DEBUG - 2018-02-09 17:07:35 --> Config file loaded: /var/www/html/project/spamblocker/application/config/rest.php
INFO - 2018-02-09 17:07:35 --> Helper loaded: inflector_helper
INFO - 2018-02-09 17:07:35 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-09 17:07:35 --> Model Class Initialized
INFO - 2018-02-09 17:07:35 --> Model Class Initialized
INFO - 2018-02-09 17:07:41 --> Config Class Initialized
INFO - 2018-02-09 17:07:41 --> Hooks Class Initialized
DEBUG - 2018-02-09 17:07:41 --> UTF-8 Support Enabled
INFO - 2018-02-09 17:07:41 --> Utf8 Class Initialized
INFO - 2018-02-09 17:07:41 --> URI Class Initialized
INFO - 2018-02-09 17:07:41 --> Router Class Initialized
INFO - 2018-02-09 17:07:41 --> Output Class Initialized
INFO - 2018-02-09 17:07:41 --> Security Class Initialized
DEBUG - 2018-02-09 17:07:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-09 17:07:41 --> Input Class Initialized
INFO - 2018-02-09 17:07:41 --> Language Class Initialized
INFO - 2018-02-09 17:07:41 --> Loader Class Initialized
INFO - 2018-02-09 17:07:41 --> Helper loaded: url_helper
INFO - 2018-02-09 17:07:41 --> Helper loaded: file_helper
INFO - 2018-02-09 17:07:41 --> Helper loaded: email_helper
INFO - 2018-02-09 17:07:41 --> Helper loaded: common_helper
INFO - 2018-02-09 17:07:41 --> Database Driver Class Initialized
DEBUG - 2018-02-09 17:07:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-09 17:07:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-09 17:07:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-09 17:07:41 --> Pagination Class Initialized
INFO - 2018-02-09 17:07:41 --> Helper loaded: form_helper
INFO - 2018-02-09 17:07:41 --> Form Validation Class Initialized
INFO - 2018-02-09 17:07:41 --> Model Class Initialized
INFO - 2018-02-09 17:07:41 --> Controller Class Initialized
DEBUG - 2018-02-09 17:07:41 --> Config file loaded: /var/www/html/project/spamblocker/application/config/rest.php
INFO - 2018-02-09 17:07:41 --> Helper loaded: inflector_helper
INFO - 2018-02-09 17:07:41 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-09 17:07:42 --> Model Class Initialized
INFO - 2018-02-09 17:07:42 --> Model Class Initialized
INFO - 2018-02-09 17:07:47 --> Config Class Initialized
INFO - 2018-02-09 17:07:47 --> Hooks Class Initialized
DEBUG - 2018-02-09 17:07:47 --> UTF-8 Support Enabled
INFO - 2018-02-09 17:07:47 --> Utf8 Class Initialized
INFO - 2018-02-09 17:07:47 --> URI Class Initialized
INFO - 2018-02-09 17:07:47 --> Router Class Initialized
INFO - 2018-02-09 17:07:47 --> Output Class Initialized
INFO - 2018-02-09 17:07:47 --> Security Class Initialized
DEBUG - 2018-02-09 17:07:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-09 17:07:47 --> Input Class Initialized
INFO - 2018-02-09 17:07:47 --> Language Class Initialized
INFO - 2018-02-09 17:07:47 --> Loader Class Initialized
INFO - 2018-02-09 17:07:47 --> Helper loaded: url_helper
INFO - 2018-02-09 17:07:47 --> Helper loaded: file_helper
INFO - 2018-02-09 17:07:47 --> Helper loaded: email_helper
INFO - 2018-02-09 17:07:47 --> Helper loaded: common_helper
INFO - 2018-02-09 17:07:47 --> Database Driver Class Initialized
DEBUG - 2018-02-09 17:07:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-09 17:07:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-09 17:07:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-09 17:07:47 --> Pagination Class Initialized
INFO - 2018-02-09 17:07:47 --> Helper loaded: form_helper
INFO - 2018-02-09 17:07:47 --> Form Validation Class Initialized
INFO - 2018-02-09 17:07:47 --> Model Class Initialized
INFO - 2018-02-09 17:07:47 --> Controller Class Initialized
DEBUG - 2018-02-09 17:07:47 --> Config file loaded: /var/www/html/project/spamblocker/application/config/rest.php
INFO - 2018-02-09 17:07:47 --> Helper loaded: inflector_helper
INFO - 2018-02-09 17:07:47 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-09 17:07:47 --> Model Class Initialized
INFO - 2018-02-09 17:07:47 --> Model Class Initialized
INFO - 2018-02-09 17:07:53 --> Config Class Initialized
INFO - 2018-02-09 17:07:53 --> Hooks Class Initialized
DEBUG - 2018-02-09 17:07:53 --> UTF-8 Support Enabled
INFO - 2018-02-09 17:07:53 --> Utf8 Class Initialized
INFO - 2018-02-09 17:07:53 --> URI Class Initialized
INFO - 2018-02-09 17:07:53 --> Router Class Initialized
INFO - 2018-02-09 17:07:53 --> Output Class Initialized
INFO - 2018-02-09 17:07:53 --> Security Class Initialized
DEBUG - 2018-02-09 17:07:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-09 17:07:53 --> Input Class Initialized
INFO - 2018-02-09 17:07:53 --> Language Class Initialized
INFO - 2018-02-09 17:07:53 --> Loader Class Initialized
INFO - 2018-02-09 17:07:53 --> Helper loaded: url_helper
INFO - 2018-02-09 17:07:53 --> Helper loaded: file_helper
INFO - 2018-02-09 17:07:53 --> Helper loaded: email_helper
INFO - 2018-02-09 17:07:53 --> Helper loaded: common_helper
INFO - 2018-02-09 17:07:53 --> Database Driver Class Initialized
DEBUG - 2018-02-09 17:07:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-09 17:07:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-09 17:07:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-09 17:07:53 --> Pagination Class Initialized
INFO - 2018-02-09 17:07:53 --> Helper loaded: form_helper
INFO - 2018-02-09 17:07:53 --> Form Validation Class Initialized
INFO - 2018-02-09 17:07:53 --> Model Class Initialized
INFO - 2018-02-09 17:07:53 --> Controller Class Initialized
DEBUG - 2018-02-09 17:07:53 --> Config file loaded: /var/www/html/project/spamblocker/application/config/rest.php
INFO - 2018-02-09 17:07:53 --> Helper loaded: inflector_helper
INFO - 2018-02-09 17:07:53 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-09 17:07:53 --> Model Class Initialized
INFO - 2018-02-09 17:07:53 --> Model Class Initialized
INFO - 2018-02-09 17:08:30 --> Config Class Initialized
INFO - 2018-02-09 17:08:30 --> Hooks Class Initialized
DEBUG - 2018-02-09 17:08:30 --> UTF-8 Support Enabled
INFO - 2018-02-09 17:08:30 --> Utf8 Class Initialized
INFO - 2018-02-09 17:08:30 --> URI Class Initialized
INFO - 2018-02-09 17:08:30 --> Router Class Initialized
INFO - 2018-02-09 17:08:30 --> Output Class Initialized
INFO - 2018-02-09 17:08:30 --> Security Class Initialized
DEBUG - 2018-02-09 17:08:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-09 17:08:30 --> Input Class Initialized
INFO - 2018-02-09 17:08:30 --> Language Class Initialized
INFO - 2018-02-09 17:08:30 --> Loader Class Initialized
INFO - 2018-02-09 17:08:30 --> Helper loaded: url_helper
INFO - 2018-02-09 17:08:30 --> Helper loaded: file_helper
INFO - 2018-02-09 17:08:30 --> Helper loaded: email_helper
INFO - 2018-02-09 17:08:30 --> Helper loaded: common_helper
INFO - 2018-02-09 17:08:30 --> Database Driver Class Initialized
DEBUG - 2018-02-09 17:08:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-09 17:08:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-09 17:08:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-09 17:08:30 --> Pagination Class Initialized
INFO - 2018-02-09 17:08:30 --> Helper loaded: form_helper
INFO - 2018-02-09 17:08:30 --> Form Validation Class Initialized
INFO - 2018-02-09 17:08:30 --> Model Class Initialized
INFO - 2018-02-09 17:08:30 --> Controller Class Initialized
DEBUG - 2018-02-09 17:08:30 --> Config file loaded: /var/www/html/project/spamblocker/application/config/rest.php
INFO - 2018-02-09 17:08:30 --> Helper loaded: inflector_helper
INFO - 2018-02-09 17:08:30 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-09 17:08:30 --> Model Class Initialized
INFO - 2018-02-09 17:08:30 --> Model Class Initialized
INFO - 2018-02-09 17:08:57 --> Config Class Initialized
INFO - 2018-02-09 17:08:57 --> Hooks Class Initialized
DEBUG - 2018-02-09 17:08:57 --> UTF-8 Support Enabled
INFO - 2018-02-09 17:08:57 --> Utf8 Class Initialized
INFO - 2018-02-09 17:08:57 --> URI Class Initialized
INFO - 2018-02-09 17:08:57 --> Router Class Initialized
INFO - 2018-02-09 17:08:57 --> Output Class Initialized
INFO - 2018-02-09 17:08:57 --> Security Class Initialized
DEBUG - 2018-02-09 17:08:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-09 17:08:57 --> Input Class Initialized
INFO - 2018-02-09 17:08:57 --> Language Class Initialized
INFO - 2018-02-09 17:08:57 --> Loader Class Initialized
INFO - 2018-02-09 17:08:57 --> Helper loaded: url_helper
INFO - 2018-02-09 17:08:57 --> Helper loaded: file_helper
INFO - 2018-02-09 17:08:57 --> Helper loaded: email_helper
INFO - 2018-02-09 17:08:57 --> Helper loaded: common_helper
INFO - 2018-02-09 17:08:57 --> Database Driver Class Initialized
DEBUG - 2018-02-09 17:08:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-09 17:08:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-09 17:08:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-09 17:08:57 --> Pagination Class Initialized
INFO - 2018-02-09 17:08:57 --> Helper loaded: form_helper
INFO - 2018-02-09 17:08:57 --> Form Validation Class Initialized
INFO - 2018-02-09 17:08:57 --> Model Class Initialized
INFO - 2018-02-09 17:08:57 --> Controller Class Initialized
DEBUG - 2018-02-09 17:08:57 --> Config file loaded: /var/www/html/project/spamblocker/application/config/rest.php
INFO - 2018-02-09 17:08:57 --> Helper loaded: inflector_helper
INFO - 2018-02-09 17:08:57 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-09 17:08:57 --> Model Class Initialized
INFO - 2018-02-09 17:08:57 --> Model Class Initialized
ERROR - 2018-02-09 17:08:57 --> Severity: Notice --> Undefined index: tIsVerify /var/www/html/project/spamblocker/application/controllers/api/Oauth.php 221
ERROR - 2018-02-09 17:08:57 --> Severity: Notice --> Undefined index: iUserId /var/www/html/project/spamblocker/application/controllers/api/Oauth.php 465
ERROR - 2018-02-09 17:08:57 --> Severity: Notice --> Undefined index: vNumber /var/www/html/project/spamblocker/application/controllers/api/Oauth.php 467
INFO - 2018-02-09 17:08:57 --> Model Class Initialized
INFO - 2018-02-09 17:08:57 --> Email Class Initialized
INFO - 2018-02-09 17:08:57 --> Language file loaded: language/english/email_lang.php
ERROR - 2018-02-09 17:08:59 --> Severity: Notice --> Undefined index: vAuthKey /var/www/html/project/spamblocker/application/controllers/api/Oauth.php 473
INFO - 2018-02-09 17:08:59 --> Final output sent to browser
DEBUG - 2018-02-09 17:08:59 --> Total execution time: 1.8734
INFO - 2018-02-09 17:09:38 --> Config Class Initialized
INFO - 2018-02-09 17:09:38 --> Hooks Class Initialized
DEBUG - 2018-02-09 17:09:38 --> UTF-8 Support Enabled
INFO - 2018-02-09 17:09:38 --> Utf8 Class Initialized
INFO - 2018-02-09 17:09:38 --> URI Class Initialized
INFO - 2018-02-09 17:09:38 --> Router Class Initialized
INFO - 2018-02-09 17:09:38 --> Output Class Initialized
INFO - 2018-02-09 17:09:38 --> Security Class Initialized
DEBUG - 2018-02-09 17:09:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-09 17:09:38 --> Input Class Initialized
INFO - 2018-02-09 17:09:38 --> Language Class Initialized
INFO - 2018-02-09 17:09:38 --> Loader Class Initialized
INFO - 2018-02-09 17:09:38 --> Helper loaded: url_helper
INFO - 2018-02-09 17:09:38 --> Helper loaded: file_helper
INFO - 2018-02-09 17:09:38 --> Helper loaded: email_helper
INFO - 2018-02-09 17:09:38 --> Helper loaded: common_helper
INFO - 2018-02-09 17:09:38 --> Database Driver Class Initialized
DEBUG - 2018-02-09 17:09:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-09 17:09:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-09 17:09:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-09 17:09:38 --> Pagination Class Initialized
INFO - 2018-02-09 17:09:38 --> Helper loaded: form_helper
INFO - 2018-02-09 17:09:38 --> Form Validation Class Initialized
INFO - 2018-02-09 17:09:38 --> Model Class Initialized
INFO - 2018-02-09 17:09:38 --> Controller Class Initialized
DEBUG - 2018-02-09 17:09:38 --> Config file loaded: /var/www/html/project/spamblocker/application/config/rest.php
INFO - 2018-02-09 17:09:38 --> Helper loaded: inflector_helper
INFO - 2018-02-09 17:09:38 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-09 17:09:38 --> Model Class Initialized
INFO - 2018-02-09 17:09:38 --> Model Class Initialized
INFO - 2018-02-09 17:09:38 --> Final output sent to browser
DEBUG - 2018-02-09 17:09:38 --> Total execution time: 0.0076
INFO - 2018-02-09 17:47:27 --> Config Class Initialized
INFO - 2018-02-09 17:47:27 --> Hooks Class Initialized
DEBUG - 2018-02-09 17:47:27 --> UTF-8 Support Enabled
INFO - 2018-02-09 17:47:27 --> Utf8 Class Initialized
INFO - 2018-02-09 17:47:27 --> URI Class Initialized
INFO - 2018-02-09 17:47:27 --> Router Class Initialized
INFO - 2018-02-09 17:47:27 --> Output Class Initialized
INFO - 2018-02-09 17:47:27 --> Security Class Initialized
DEBUG - 2018-02-09 17:47:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-09 17:47:27 --> Input Class Initialized
INFO - 2018-02-09 17:47:27 --> Language Class Initialized
INFO - 2018-02-09 17:47:27 --> Loader Class Initialized
INFO - 2018-02-09 17:47:27 --> Helper loaded: url_helper
INFO - 2018-02-09 17:47:27 --> Helper loaded: file_helper
INFO - 2018-02-09 17:47:27 --> Helper loaded: email_helper
INFO - 2018-02-09 17:47:27 --> Helper loaded: common_helper
INFO - 2018-02-09 17:47:27 --> Database Driver Class Initialized
DEBUG - 2018-02-09 17:47:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-09 17:47:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-09 17:47:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-09 17:47:27 --> Pagination Class Initialized
INFO - 2018-02-09 17:47:27 --> Helper loaded: form_helper
INFO - 2018-02-09 17:47:27 --> Form Validation Class Initialized
INFO - 2018-02-09 17:47:27 --> Model Class Initialized
INFO - 2018-02-09 17:47:27 --> Controller Class Initialized
DEBUG - 2018-02-09 17:47:27 --> Config file loaded: /var/www/html/project/spamblocker/application/config/rest.php
INFO - 2018-02-09 17:47:27 --> Helper loaded: inflector_helper
INFO - 2018-02-09 17:47:27 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-09 17:47:27 --> Model Class Initialized
INFO - 2018-02-09 17:47:27 --> Model Class Initialized
INFO - 2018-02-09 17:47:27 --> Final output sent to browser
DEBUG - 2018-02-09 17:47:27 --> Total execution time: 0.0061
INFO - 2018-02-09 17:48:04 --> Config Class Initialized
INFO - 2018-02-09 17:48:04 --> Hooks Class Initialized
DEBUG - 2018-02-09 17:48:04 --> UTF-8 Support Enabled
INFO - 2018-02-09 17:48:04 --> Utf8 Class Initialized
INFO - 2018-02-09 17:48:04 --> URI Class Initialized
INFO - 2018-02-09 17:48:04 --> Router Class Initialized
INFO - 2018-02-09 17:48:04 --> Output Class Initialized
INFO - 2018-02-09 17:48:04 --> Security Class Initialized
DEBUG - 2018-02-09 17:48:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-09 17:48:04 --> Input Class Initialized
INFO - 2018-02-09 17:48:04 --> Language Class Initialized
INFO - 2018-02-09 17:48:04 --> Loader Class Initialized
INFO - 2018-02-09 17:48:04 --> Helper loaded: url_helper
INFO - 2018-02-09 17:48:04 --> Helper loaded: file_helper
INFO - 2018-02-09 17:48:04 --> Helper loaded: email_helper
INFO - 2018-02-09 17:48:04 --> Helper loaded: common_helper
INFO - 2018-02-09 17:48:04 --> Database Driver Class Initialized
DEBUG - 2018-02-09 17:48:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-09 17:48:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-09 17:48:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-09 17:48:04 --> Pagination Class Initialized
INFO - 2018-02-09 17:48:04 --> Helper loaded: form_helper
INFO - 2018-02-09 17:48:04 --> Form Validation Class Initialized
INFO - 2018-02-09 17:48:04 --> Model Class Initialized
INFO - 2018-02-09 17:48:04 --> Controller Class Initialized
DEBUG - 2018-02-09 17:48:04 --> Config file loaded: /var/www/html/project/spamblocker/application/config/rest.php
INFO - 2018-02-09 17:48:04 --> Helper loaded: inflector_helper
INFO - 2018-02-09 17:48:04 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-09 17:48:04 --> Model Class Initialized
INFO - 2018-02-09 17:48:04 --> Model Class Initialized
INFO - 2018-02-09 17:48:04 --> Final output sent to browser
DEBUG - 2018-02-09 17:48:04 --> Total execution time: 0.0041
INFO - 2018-02-09 17:49:00 --> Config Class Initialized
INFO - 2018-02-09 17:49:00 --> Hooks Class Initialized
DEBUG - 2018-02-09 17:49:00 --> UTF-8 Support Enabled
INFO - 2018-02-09 17:49:00 --> Utf8 Class Initialized
INFO - 2018-02-09 17:49:00 --> URI Class Initialized
INFO - 2018-02-09 17:49:00 --> Router Class Initialized
INFO - 2018-02-09 17:49:00 --> Output Class Initialized
INFO - 2018-02-09 17:49:00 --> Security Class Initialized
DEBUG - 2018-02-09 17:49:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-09 17:49:00 --> Input Class Initialized
INFO - 2018-02-09 17:49:00 --> Language Class Initialized
INFO - 2018-02-09 17:49:00 --> Loader Class Initialized
INFO - 2018-02-09 17:49:00 --> Helper loaded: url_helper
INFO - 2018-02-09 17:49:00 --> Helper loaded: file_helper
INFO - 2018-02-09 17:49:00 --> Helper loaded: email_helper
INFO - 2018-02-09 17:49:00 --> Helper loaded: common_helper
INFO - 2018-02-09 17:49:00 --> Database Driver Class Initialized
DEBUG - 2018-02-09 17:49:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-09 17:49:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-09 17:49:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-09 17:49:00 --> Pagination Class Initialized
INFO - 2018-02-09 17:49:00 --> Helper loaded: form_helper
INFO - 2018-02-09 17:49:00 --> Form Validation Class Initialized
INFO - 2018-02-09 17:49:00 --> Model Class Initialized
INFO - 2018-02-09 17:49:00 --> Controller Class Initialized
DEBUG - 2018-02-09 17:49:00 --> Config file loaded: /var/www/html/project/spamblocker/application/config/rest.php
INFO - 2018-02-09 17:49:00 --> Helper loaded: inflector_helper
INFO - 2018-02-09 17:49:00 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-09 17:49:00 --> Model Class Initialized
INFO - 2018-02-09 17:49:00 --> Model Class Initialized
INFO - 2018-02-09 17:49:00 --> Model Class Initialized
INFO - 2018-02-09 17:49:00 --> Email Class Initialized
ERROR - 2018-02-09 17:49:00 --> Severity: error --> Exception: Call to undefined function fastcgi_finish_request() /var/www/html/project/spamblocker/application/helpers/common_helper.php 178
INFO - 2018-02-09 17:49:24 --> Config Class Initialized
INFO - 2018-02-09 17:49:24 --> Hooks Class Initialized
DEBUG - 2018-02-09 17:49:24 --> UTF-8 Support Enabled
INFO - 2018-02-09 17:49:24 --> Utf8 Class Initialized
INFO - 2018-02-09 17:49:24 --> URI Class Initialized
INFO - 2018-02-09 17:49:24 --> Router Class Initialized
INFO - 2018-02-09 17:49:24 --> Output Class Initialized
INFO - 2018-02-09 17:49:24 --> Security Class Initialized
DEBUG - 2018-02-09 17:49:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-09 17:49:24 --> Input Class Initialized
INFO - 2018-02-09 17:49:24 --> Language Class Initialized
INFO - 2018-02-09 17:49:24 --> Loader Class Initialized
INFO - 2018-02-09 17:49:24 --> Helper loaded: url_helper
INFO - 2018-02-09 17:49:24 --> Helper loaded: file_helper
INFO - 2018-02-09 17:49:24 --> Helper loaded: email_helper
INFO - 2018-02-09 17:49:24 --> Helper loaded: common_helper
INFO - 2018-02-09 17:49:24 --> Database Driver Class Initialized
DEBUG - 2018-02-09 17:49:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-09 17:49:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-09 17:49:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-09 17:49:24 --> Pagination Class Initialized
INFO - 2018-02-09 17:49:24 --> Helper loaded: form_helper
INFO - 2018-02-09 17:49:24 --> Form Validation Class Initialized
INFO - 2018-02-09 17:49:24 --> Model Class Initialized
INFO - 2018-02-09 17:49:24 --> Controller Class Initialized
DEBUG - 2018-02-09 17:49:24 --> Config file loaded: /var/www/html/project/spamblocker/application/config/rest.php
INFO - 2018-02-09 17:49:24 --> Helper loaded: inflector_helper
INFO - 2018-02-09 17:49:24 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-09 17:49:24 --> Model Class Initialized
INFO - 2018-02-09 17:49:24 --> Model Class Initialized
INFO - 2018-02-09 17:49:24 --> Model Class Initialized
INFO - 2018-02-09 17:49:24 --> Email Class Initialized
INFO - 2018-02-09 17:49:30 --> Language file loaded: language/english/email_lang.php
INFO - 2018-02-09 17:49:33 --> Final output sent to browser
DEBUG - 2018-02-09 17:49:33 --> Total execution time: 9.2903
INFO - 2018-02-09 17:49:46 --> Config Class Initialized
INFO - 2018-02-09 17:49:46 --> Hooks Class Initialized
DEBUG - 2018-02-09 17:49:46 --> UTF-8 Support Enabled
INFO - 2018-02-09 17:49:46 --> Utf8 Class Initialized
INFO - 2018-02-09 17:49:46 --> URI Class Initialized
INFO - 2018-02-09 17:49:46 --> Router Class Initialized
INFO - 2018-02-09 17:49:46 --> Output Class Initialized
INFO - 2018-02-09 17:49:46 --> Security Class Initialized
DEBUG - 2018-02-09 17:49:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-09 17:49:46 --> Input Class Initialized
INFO - 2018-02-09 17:49:46 --> Language Class Initialized
INFO - 2018-02-09 17:49:46 --> Loader Class Initialized
INFO - 2018-02-09 17:49:46 --> Helper loaded: url_helper
INFO - 2018-02-09 17:49:46 --> Helper loaded: file_helper
INFO - 2018-02-09 17:49:46 --> Helper loaded: email_helper
INFO - 2018-02-09 17:49:46 --> Helper loaded: common_helper
INFO - 2018-02-09 17:49:46 --> Database Driver Class Initialized
DEBUG - 2018-02-09 17:49:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-09 17:49:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-09 17:49:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-09 17:49:46 --> Pagination Class Initialized
INFO - 2018-02-09 17:49:46 --> Helper loaded: form_helper
INFO - 2018-02-09 17:49:46 --> Form Validation Class Initialized
INFO - 2018-02-09 17:49:46 --> Model Class Initialized
INFO - 2018-02-09 17:49:46 --> Controller Class Initialized
DEBUG - 2018-02-09 17:49:46 --> Config file loaded: /var/www/html/project/spamblocker/application/config/rest.php
INFO - 2018-02-09 17:49:46 --> Helper loaded: inflector_helper
INFO - 2018-02-09 17:49:46 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-09 17:49:46 --> Model Class Initialized
INFO - 2018-02-09 17:49:46 --> Model Class Initialized
INFO - 2018-02-09 17:49:46 --> Final output sent to browser
DEBUG - 2018-02-09 17:49:46 --> Total execution time: 0.0057
INFO - 2018-02-09 17:50:14 --> Config Class Initialized
INFO - 2018-02-09 17:50:14 --> Hooks Class Initialized
DEBUG - 2018-02-09 17:50:14 --> UTF-8 Support Enabled
INFO - 2018-02-09 17:50:14 --> Utf8 Class Initialized
INFO - 2018-02-09 17:50:14 --> URI Class Initialized
INFO - 2018-02-09 17:50:14 --> Router Class Initialized
INFO - 2018-02-09 17:50:14 --> Output Class Initialized
INFO - 2018-02-09 17:50:14 --> Security Class Initialized
DEBUG - 2018-02-09 17:50:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-09 17:50:14 --> Input Class Initialized
INFO - 2018-02-09 17:50:14 --> Language Class Initialized
INFO - 2018-02-09 17:50:14 --> Loader Class Initialized
INFO - 2018-02-09 17:50:14 --> Helper loaded: url_helper
INFO - 2018-02-09 17:50:14 --> Helper loaded: file_helper
INFO - 2018-02-09 17:50:14 --> Helper loaded: email_helper
INFO - 2018-02-09 17:50:14 --> Helper loaded: common_helper
INFO - 2018-02-09 17:50:14 --> Database Driver Class Initialized
DEBUG - 2018-02-09 17:50:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-09 17:50:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-09 17:50:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-09 17:50:14 --> Pagination Class Initialized
INFO - 2018-02-09 17:50:14 --> Helper loaded: form_helper
INFO - 2018-02-09 17:50:14 --> Form Validation Class Initialized
INFO - 2018-02-09 17:50:14 --> Model Class Initialized
INFO - 2018-02-09 17:50:14 --> Controller Class Initialized
DEBUG - 2018-02-09 17:50:14 --> Config file loaded: /var/www/html/project/spamblocker/application/config/rest.php
INFO - 2018-02-09 17:50:14 --> Helper loaded: inflector_helper
INFO - 2018-02-09 17:50:14 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-09 17:50:14 --> Model Class Initialized
INFO - 2018-02-09 17:50:14 --> Model Class Initialized
INFO - 2018-02-09 17:50:14 --> Final output sent to browser
DEBUG - 2018-02-09 17:50:14 --> Total execution time: 0.0043
INFO - 2018-02-09 17:50:38 --> Config Class Initialized
INFO - 2018-02-09 17:50:38 --> Hooks Class Initialized
DEBUG - 2018-02-09 17:50:38 --> UTF-8 Support Enabled
INFO - 2018-02-09 17:50:38 --> Utf8 Class Initialized
INFO - 2018-02-09 17:50:38 --> URI Class Initialized
INFO - 2018-02-09 17:50:38 --> Router Class Initialized
INFO - 2018-02-09 17:50:38 --> Output Class Initialized
INFO - 2018-02-09 17:50:38 --> Security Class Initialized
DEBUG - 2018-02-09 17:50:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-09 17:50:38 --> Input Class Initialized
INFO - 2018-02-09 17:50:38 --> Language Class Initialized
INFO - 2018-02-09 17:50:38 --> Loader Class Initialized
INFO - 2018-02-09 17:50:38 --> Helper loaded: url_helper
INFO - 2018-02-09 17:50:38 --> Helper loaded: file_helper
INFO - 2018-02-09 17:50:38 --> Helper loaded: email_helper
INFO - 2018-02-09 17:50:38 --> Helper loaded: common_helper
INFO - 2018-02-09 17:50:38 --> Database Driver Class Initialized
DEBUG - 2018-02-09 17:50:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-09 17:50:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-09 17:50:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-09 17:50:38 --> Pagination Class Initialized
INFO - 2018-02-09 17:50:38 --> Helper loaded: form_helper
INFO - 2018-02-09 17:50:38 --> Form Validation Class Initialized
INFO - 2018-02-09 17:50:38 --> Model Class Initialized
INFO - 2018-02-09 17:50:38 --> Controller Class Initialized
DEBUG - 2018-02-09 17:50:38 --> Config file loaded: /var/www/html/project/spamblocker/application/config/rest.php
INFO - 2018-02-09 17:50:38 --> Helper loaded: inflector_helper
INFO - 2018-02-09 17:50:38 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-09 17:50:38 --> Model Class Initialized
INFO - 2018-02-09 17:50:38 --> Model Class Initialized
INFO - 2018-02-09 17:50:38 --> Final output sent to browser
DEBUG - 2018-02-09 17:50:38 --> Total execution time: 0.0058
INFO - 2018-02-09 17:54:54 --> Config Class Initialized
INFO - 2018-02-09 17:54:54 --> Hooks Class Initialized
DEBUG - 2018-02-09 17:54:54 --> UTF-8 Support Enabled
INFO - 2018-02-09 17:54:54 --> Utf8 Class Initialized
INFO - 2018-02-09 17:54:54 --> URI Class Initialized
INFO - 2018-02-09 17:54:54 --> Router Class Initialized
INFO - 2018-02-09 17:54:54 --> Output Class Initialized
INFO - 2018-02-09 17:54:54 --> Security Class Initialized
DEBUG - 2018-02-09 17:54:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-09 17:54:54 --> Input Class Initialized
INFO - 2018-02-09 17:54:54 --> Language Class Initialized
INFO - 2018-02-09 17:54:54 --> Loader Class Initialized
INFO - 2018-02-09 17:54:54 --> Helper loaded: url_helper
INFO - 2018-02-09 17:54:54 --> Helper loaded: file_helper
INFO - 2018-02-09 17:54:54 --> Helper loaded: email_helper
INFO - 2018-02-09 17:54:54 --> Helper loaded: common_helper
INFO - 2018-02-09 17:54:54 --> Database Driver Class Initialized
DEBUG - 2018-02-09 17:54:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-09 17:54:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-09 17:54:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-09 17:54:54 --> Pagination Class Initialized
INFO - 2018-02-09 17:54:54 --> Helper loaded: form_helper
INFO - 2018-02-09 17:54:54 --> Form Validation Class Initialized
INFO - 2018-02-09 17:54:54 --> Model Class Initialized
INFO - 2018-02-09 17:54:54 --> Controller Class Initialized
DEBUG - 2018-02-09 17:54:54 --> Config file loaded: /var/www/html/project/spamblocker/application/config/rest.php
INFO - 2018-02-09 17:54:54 --> Helper loaded: inflector_helper
INFO - 2018-02-09 17:54:54 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-09 17:54:54 --> Model Class Initialized
INFO - 2018-02-09 17:54:54 --> Model Class Initialized
ERROR - 2018-02-09 17:54:54 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ''919173508626'' at line 3 - Invalid query: SELECT *
FROM `user_master`
WHERE REPLACE (vNumber , "+" ,"") '919173508626'
INFO - 2018-02-09 17:54:54 --> Language file loaded: language/english/db_lang.php
INFO - 2018-02-09 17:55:14 --> Config Class Initialized
INFO - 2018-02-09 17:55:14 --> Hooks Class Initialized
DEBUG - 2018-02-09 17:55:14 --> UTF-8 Support Enabled
INFO - 2018-02-09 17:55:14 --> Utf8 Class Initialized
INFO - 2018-02-09 17:55:14 --> URI Class Initialized
INFO - 2018-02-09 17:55:14 --> Router Class Initialized
INFO - 2018-02-09 17:55:14 --> Output Class Initialized
INFO - 2018-02-09 17:55:14 --> Security Class Initialized
DEBUG - 2018-02-09 17:55:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-09 17:55:14 --> Input Class Initialized
INFO - 2018-02-09 17:55:14 --> Language Class Initialized
INFO - 2018-02-09 17:55:14 --> Loader Class Initialized
INFO - 2018-02-09 17:55:14 --> Helper loaded: url_helper
INFO - 2018-02-09 17:55:14 --> Helper loaded: file_helper
INFO - 2018-02-09 17:55:14 --> Helper loaded: email_helper
INFO - 2018-02-09 17:55:14 --> Helper loaded: common_helper
INFO - 2018-02-09 17:55:14 --> Database Driver Class Initialized
DEBUG - 2018-02-09 17:55:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-09 17:55:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-09 17:55:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-09 17:55:14 --> Pagination Class Initialized
INFO - 2018-02-09 17:55:14 --> Helper loaded: form_helper
INFO - 2018-02-09 17:55:14 --> Form Validation Class Initialized
INFO - 2018-02-09 17:55:14 --> Model Class Initialized
INFO - 2018-02-09 17:55:14 --> Controller Class Initialized
DEBUG - 2018-02-09 17:55:14 --> Config file loaded: /var/www/html/project/spamblocker/application/config/rest.php
INFO - 2018-02-09 17:55:14 --> Helper loaded: inflector_helper
INFO - 2018-02-09 17:55:14 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-09 17:55:14 --> Model Class Initialized
INFO - 2018-02-09 17:55:14 --> Model Class Initialized
INFO - 2018-02-09 17:55:14 --> Final output sent to browser
DEBUG - 2018-02-09 17:55:14 --> Total execution time: 0.0083
INFO - 2018-02-09 17:55:22 --> Config Class Initialized
INFO - 2018-02-09 17:55:22 --> Hooks Class Initialized
DEBUG - 2018-02-09 17:55:22 --> UTF-8 Support Enabled
INFO - 2018-02-09 17:55:22 --> Utf8 Class Initialized
INFO - 2018-02-09 17:55:22 --> URI Class Initialized
INFO - 2018-02-09 17:55:22 --> Router Class Initialized
INFO - 2018-02-09 17:55:22 --> Output Class Initialized
INFO - 2018-02-09 17:55:22 --> Security Class Initialized
DEBUG - 2018-02-09 17:55:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-09 17:55:22 --> Input Class Initialized
INFO - 2018-02-09 17:55:22 --> Language Class Initialized
INFO - 2018-02-09 17:55:22 --> Loader Class Initialized
INFO - 2018-02-09 17:55:22 --> Helper loaded: url_helper
INFO - 2018-02-09 17:55:22 --> Helper loaded: file_helper
INFO - 2018-02-09 17:55:22 --> Helper loaded: email_helper
INFO - 2018-02-09 17:55:22 --> Helper loaded: common_helper
INFO - 2018-02-09 17:55:22 --> Database Driver Class Initialized
DEBUG - 2018-02-09 17:55:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-09 17:55:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-09 17:55:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-09 17:55:22 --> Pagination Class Initialized
INFO - 2018-02-09 17:55:22 --> Helper loaded: form_helper
INFO - 2018-02-09 17:55:22 --> Form Validation Class Initialized
INFO - 2018-02-09 17:55:22 --> Model Class Initialized
INFO - 2018-02-09 17:55:22 --> Controller Class Initialized
DEBUG - 2018-02-09 17:55:22 --> Config file loaded: /var/www/html/project/spamblocker/application/config/rest.php
INFO - 2018-02-09 17:55:22 --> Helper loaded: inflector_helper
INFO - 2018-02-09 17:55:22 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-09 17:55:22 --> Model Class Initialized
INFO - 2018-02-09 17:55:22 --> Model Class Initialized
INFO - 2018-02-09 17:55:22 --> Final output sent to browser
DEBUG - 2018-02-09 17:55:22 --> Total execution time: 0.0052
INFO - 2018-02-09 17:55:28 --> Config Class Initialized
INFO - 2018-02-09 17:55:28 --> Hooks Class Initialized
DEBUG - 2018-02-09 17:55:28 --> UTF-8 Support Enabled
INFO - 2018-02-09 17:55:28 --> Utf8 Class Initialized
INFO - 2018-02-09 17:55:28 --> URI Class Initialized
INFO - 2018-02-09 17:55:28 --> Router Class Initialized
INFO - 2018-02-09 17:55:28 --> Output Class Initialized
INFO - 2018-02-09 17:55:28 --> Security Class Initialized
DEBUG - 2018-02-09 17:55:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-09 17:55:28 --> Input Class Initialized
INFO - 2018-02-09 17:55:28 --> Language Class Initialized
INFO - 2018-02-09 17:55:28 --> Loader Class Initialized
INFO - 2018-02-09 17:55:28 --> Helper loaded: url_helper
INFO - 2018-02-09 17:55:28 --> Helper loaded: file_helper
INFO - 2018-02-09 17:55:28 --> Helper loaded: email_helper
INFO - 2018-02-09 17:55:28 --> Helper loaded: common_helper
INFO - 2018-02-09 17:55:28 --> Database Driver Class Initialized
DEBUG - 2018-02-09 17:55:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-09 17:55:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-09 17:55:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-09 17:55:28 --> Pagination Class Initialized
INFO - 2018-02-09 17:55:28 --> Helper loaded: form_helper
INFO - 2018-02-09 17:55:28 --> Form Validation Class Initialized
INFO - 2018-02-09 17:55:28 --> Model Class Initialized
INFO - 2018-02-09 17:55:28 --> Controller Class Initialized
DEBUG - 2018-02-09 17:55:28 --> Config file loaded: /var/www/html/project/spamblocker/application/config/rest.php
INFO - 2018-02-09 17:55:28 --> Helper loaded: inflector_helper
INFO - 2018-02-09 17:55:28 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-09 17:55:28 --> Model Class Initialized
INFO - 2018-02-09 17:55:28 --> Model Class Initialized
INFO - 2018-02-09 17:55:28 --> Final output sent to browser
DEBUG - 2018-02-09 17:55:28 --> Total execution time: 0.0058
INFO - 2018-02-09 17:55:36 --> Config Class Initialized
INFO - 2018-02-09 17:55:36 --> Hooks Class Initialized
DEBUG - 2018-02-09 17:55:36 --> UTF-8 Support Enabled
INFO - 2018-02-09 17:55:36 --> Utf8 Class Initialized
INFO - 2018-02-09 17:55:36 --> URI Class Initialized
INFO - 2018-02-09 17:55:36 --> Router Class Initialized
INFO - 2018-02-09 17:55:36 --> Output Class Initialized
INFO - 2018-02-09 17:55:36 --> Security Class Initialized
DEBUG - 2018-02-09 17:55:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-09 17:55:36 --> Input Class Initialized
INFO - 2018-02-09 17:55:36 --> Language Class Initialized
INFO - 2018-02-09 17:55:36 --> Loader Class Initialized
INFO - 2018-02-09 17:55:36 --> Helper loaded: url_helper
INFO - 2018-02-09 17:55:36 --> Helper loaded: file_helper
INFO - 2018-02-09 17:55:36 --> Helper loaded: email_helper
INFO - 2018-02-09 17:55:36 --> Helper loaded: common_helper
INFO - 2018-02-09 17:55:36 --> Database Driver Class Initialized
DEBUG - 2018-02-09 17:55:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-09 17:55:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-09 17:55:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-09 17:55:36 --> Pagination Class Initialized
INFO - 2018-02-09 17:55:36 --> Helper loaded: form_helper
INFO - 2018-02-09 17:55:36 --> Form Validation Class Initialized
INFO - 2018-02-09 17:55:36 --> Model Class Initialized
INFO - 2018-02-09 17:55:36 --> Controller Class Initialized
DEBUG - 2018-02-09 17:55:36 --> Config file loaded: /var/www/html/project/spamblocker/application/config/rest.php
INFO - 2018-02-09 17:55:36 --> Helper loaded: inflector_helper
INFO - 2018-02-09 17:55:36 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-09 17:55:36 --> Model Class Initialized
INFO - 2018-02-09 17:55:36 --> Model Class Initialized
INFO - 2018-02-09 17:55:36 --> Final output sent to browser
DEBUG - 2018-02-09 17:55:36 --> Total execution time: 0.0062
INFO - 2018-02-09 17:55:50 --> Config Class Initialized
INFO - 2018-02-09 17:55:50 --> Hooks Class Initialized
DEBUG - 2018-02-09 17:55:50 --> UTF-8 Support Enabled
INFO - 2018-02-09 17:55:50 --> Utf8 Class Initialized
INFO - 2018-02-09 17:55:50 --> URI Class Initialized
INFO - 2018-02-09 17:55:50 --> Router Class Initialized
INFO - 2018-02-09 17:55:50 --> Output Class Initialized
INFO - 2018-02-09 17:55:50 --> Security Class Initialized
DEBUG - 2018-02-09 17:55:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-09 17:55:50 --> Input Class Initialized
INFO - 2018-02-09 17:55:50 --> Language Class Initialized
INFO - 2018-02-09 17:55:50 --> Loader Class Initialized
INFO - 2018-02-09 17:55:50 --> Helper loaded: url_helper
INFO - 2018-02-09 17:55:50 --> Helper loaded: file_helper
INFO - 2018-02-09 17:55:50 --> Helper loaded: email_helper
INFO - 2018-02-09 17:55:50 --> Helper loaded: common_helper
INFO - 2018-02-09 17:55:50 --> Database Driver Class Initialized
DEBUG - 2018-02-09 17:55:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-09 17:55:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-09 17:55:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-09 17:55:50 --> Pagination Class Initialized
INFO - 2018-02-09 17:55:50 --> Helper loaded: form_helper
INFO - 2018-02-09 17:55:50 --> Form Validation Class Initialized
INFO - 2018-02-09 17:55:50 --> Model Class Initialized
INFO - 2018-02-09 17:55:50 --> Controller Class Initialized
DEBUG - 2018-02-09 17:55:50 --> Config file loaded: /var/www/html/project/spamblocker/application/config/rest.php
INFO - 2018-02-09 17:55:50 --> Helper loaded: inflector_helper
INFO - 2018-02-09 17:55:50 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-09 17:55:50 --> Model Class Initialized
INFO - 2018-02-09 17:55:50 --> Model Class Initialized
INFO - 2018-02-09 17:55:50 --> Final output sent to browser
DEBUG - 2018-02-09 17:55:50 --> Total execution time: 0.0059
INFO - 2018-02-09 17:55:55 --> Config Class Initialized
INFO - 2018-02-09 17:55:55 --> Hooks Class Initialized
DEBUG - 2018-02-09 17:55:55 --> UTF-8 Support Enabled
INFO - 2018-02-09 17:55:55 --> Utf8 Class Initialized
INFO - 2018-02-09 17:55:55 --> URI Class Initialized
INFO - 2018-02-09 17:55:55 --> Router Class Initialized
INFO - 2018-02-09 17:55:55 --> Output Class Initialized
INFO - 2018-02-09 17:55:55 --> Security Class Initialized
DEBUG - 2018-02-09 17:55:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-09 17:55:55 --> Input Class Initialized
INFO - 2018-02-09 17:55:55 --> Language Class Initialized
INFO - 2018-02-09 17:55:55 --> Loader Class Initialized
INFO - 2018-02-09 17:55:55 --> Helper loaded: url_helper
INFO - 2018-02-09 17:55:55 --> Helper loaded: file_helper
INFO - 2018-02-09 17:55:55 --> Helper loaded: email_helper
INFO - 2018-02-09 17:55:55 --> Helper loaded: common_helper
INFO - 2018-02-09 17:55:55 --> Database Driver Class Initialized
DEBUG - 2018-02-09 17:55:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-09 17:55:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-09 17:55:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-09 17:55:55 --> Pagination Class Initialized
INFO - 2018-02-09 17:55:55 --> Helper loaded: form_helper
INFO - 2018-02-09 17:55:55 --> Form Validation Class Initialized
INFO - 2018-02-09 17:55:55 --> Model Class Initialized
INFO - 2018-02-09 17:55:55 --> Controller Class Initialized
DEBUG - 2018-02-09 17:55:55 --> Config file loaded: /var/www/html/project/spamblocker/application/config/rest.php
INFO - 2018-02-09 17:55:55 --> Helper loaded: inflector_helper
INFO - 2018-02-09 17:55:55 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-09 17:55:55 --> Model Class Initialized
INFO - 2018-02-09 17:55:55 --> Model Class Initialized
INFO - 2018-02-09 17:55:55 --> Final output sent to browser
DEBUG - 2018-02-09 17:55:55 --> Total execution time: 0.0055
INFO - 2018-02-09 17:56:11 --> Config Class Initialized
INFO - 2018-02-09 17:56:11 --> Hooks Class Initialized
DEBUG - 2018-02-09 17:56:11 --> UTF-8 Support Enabled
INFO - 2018-02-09 17:56:11 --> Utf8 Class Initialized
INFO - 2018-02-09 17:56:11 --> URI Class Initialized
INFO - 2018-02-09 17:56:11 --> Router Class Initialized
INFO - 2018-02-09 17:56:11 --> Output Class Initialized
INFO - 2018-02-09 17:56:11 --> Security Class Initialized
DEBUG - 2018-02-09 17:56:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-09 17:56:11 --> Input Class Initialized
INFO - 2018-02-09 17:56:11 --> Language Class Initialized
INFO - 2018-02-09 17:56:11 --> Loader Class Initialized
INFO - 2018-02-09 17:56:11 --> Helper loaded: url_helper
INFO - 2018-02-09 17:56:11 --> Helper loaded: file_helper
INFO - 2018-02-09 17:56:11 --> Helper loaded: email_helper
INFO - 2018-02-09 17:56:11 --> Helper loaded: common_helper
INFO - 2018-02-09 17:56:11 --> Database Driver Class Initialized
DEBUG - 2018-02-09 17:56:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-09 17:56:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-09 17:56:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-09 17:56:11 --> Pagination Class Initialized
INFO - 2018-02-09 17:56:11 --> Helper loaded: form_helper
INFO - 2018-02-09 17:56:11 --> Form Validation Class Initialized
INFO - 2018-02-09 17:56:11 --> Model Class Initialized
INFO - 2018-02-09 17:56:11 --> Controller Class Initialized
DEBUG - 2018-02-09 17:56:11 --> Config file loaded: /var/www/html/project/spamblocker/application/config/rest.php
INFO - 2018-02-09 17:56:11 --> Helper loaded: inflector_helper
INFO - 2018-02-09 17:56:11 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-09 17:56:11 --> Model Class Initialized
INFO - 2018-02-09 17:56:11 --> Model Class Initialized
INFO - 2018-02-09 17:56:11 --> Final output sent to browser
DEBUG - 2018-02-09 17:56:11 --> Total execution time: 0.0051
INFO - 2018-02-09 17:56:25 --> Config Class Initialized
INFO - 2018-02-09 17:56:25 --> Hooks Class Initialized
DEBUG - 2018-02-09 17:56:25 --> UTF-8 Support Enabled
INFO - 2018-02-09 17:56:25 --> Utf8 Class Initialized
INFO - 2018-02-09 17:56:25 --> URI Class Initialized
INFO - 2018-02-09 17:56:25 --> Router Class Initialized
INFO - 2018-02-09 17:56:25 --> Output Class Initialized
INFO - 2018-02-09 17:56:25 --> Security Class Initialized
DEBUG - 2018-02-09 17:56:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-09 17:56:25 --> Input Class Initialized
INFO - 2018-02-09 17:56:25 --> Language Class Initialized
INFO - 2018-02-09 17:56:25 --> Loader Class Initialized
INFO - 2018-02-09 17:56:25 --> Helper loaded: url_helper
INFO - 2018-02-09 17:56:25 --> Helper loaded: file_helper
INFO - 2018-02-09 17:56:25 --> Helper loaded: email_helper
INFO - 2018-02-09 17:56:25 --> Helper loaded: common_helper
INFO - 2018-02-09 17:56:25 --> Database Driver Class Initialized
DEBUG - 2018-02-09 17:56:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-09 17:56:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-09 17:56:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-09 17:56:25 --> Pagination Class Initialized
INFO - 2018-02-09 17:56:25 --> Helper loaded: form_helper
INFO - 2018-02-09 17:56:25 --> Form Validation Class Initialized
INFO - 2018-02-09 17:56:25 --> Model Class Initialized
INFO - 2018-02-09 17:56:25 --> Controller Class Initialized
DEBUG - 2018-02-09 17:56:25 --> Config file loaded: /var/www/html/project/spamblocker/application/config/rest.php
INFO - 2018-02-09 17:56:25 --> Helper loaded: inflector_helper
INFO - 2018-02-09 17:56:25 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-09 17:56:25 --> Model Class Initialized
INFO - 2018-02-09 17:56:25 --> Model Class Initialized
INFO - 2018-02-09 17:56:25 --> Model Class Initialized
INFO - 2018-02-09 17:56:25 --> Email Class Initialized
INFO - 2018-02-09 17:56:25 --> Language file loaded: language/english/email_lang.php
INFO - 2018-02-09 17:56:29 --> Final output sent to browser
DEBUG - 2018-02-09 17:56:29 --> Total execution time: 3.6618

<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2018-02-14 10:05:48 --> Config Class Initialized
INFO - 2018-02-14 10:05:48 --> Hooks Class Initialized
DEBUG - 2018-02-14 10:05:48 --> UTF-8 Support Enabled
INFO - 2018-02-14 10:05:48 --> Utf8 Class Initialized
INFO - 2018-02-14 10:05:48 --> URI Class Initialized
DEBUG - 2018-02-14 10:05:48 --> No URI present. Default controller set.
INFO - 2018-02-14 10:05:48 --> Router Class Initialized
INFO - 2018-02-14 10:05:48 --> Output Class Initialized
INFO - 2018-02-14 10:05:48 --> Security Class Initialized
DEBUG - 2018-02-14 10:05:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 10:05:48 --> Input Class Initialized
INFO - 2018-02-14 10:05:48 --> Language Class Initialized
INFO - 2018-02-14 10:05:48 --> Loader Class Initialized
INFO - 2018-02-14 10:05:48 --> Helper loaded: url_helper
INFO - 2018-02-14 10:05:48 --> Helper loaded: file_helper
INFO - 2018-02-14 10:05:48 --> Helper loaded: email_helper
INFO - 2018-02-14 10:05:48 --> Helper loaded: common_helper
INFO - 2018-02-14 10:05:48 --> Database Driver Class Initialized
DEBUG - 2018-02-14 10:05:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 10:05:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 10:05:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-14 10:05:48 --> Pagination Class Initialized
INFO - 2018-02-14 10:05:48 --> Helper loaded: form_helper
INFO - 2018-02-14 10:05:48 --> Form Validation Class Initialized
INFO - 2018-02-14 10:05:48 --> Model Class Initialized
INFO - 2018-02-14 10:05:48 --> Controller Class Initialized
INFO - 2018-02-14 10:05:48 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-14 10:05:48 --> Model Class Initialized
INFO - 2018-02-14 10:05:48 --> File loaded: /var/www/html/project/radio/application/views/index/index.php
INFO - 2018-02-14 10:05:48 --> Final output sent to browser
DEBUG - 2018-02-14 10:05:48 --> Total execution time: 0.2995
INFO - 2018-02-14 10:06:01 --> Config Class Initialized
INFO - 2018-02-14 10:06:01 --> Hooks Class Initialized
DEBUG - 2018-02-14 10:06:01 --> UTF-8 Support Enabled
INFO - 2018-02-14 10:06:01 --> Utf8 Class Initialized
INFO - 2018-02-14 10:06:01 --> URI Class Initialized
INFO - 2018-02-14 10:06:01 --> Router Class Initialized
INFO - 2018-02-14 10:06:01 --> Output Class Initialized
INFO - 2018-02-14 10:06:01 --> Security Class Initialized
DEBUG - 2018-02-14 10:06:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 10:06:01 --> Input Class Initialized
INFO - 2018-02-14 10:06:01 --> Language Class Initialized
INFO - 2018-02-14 10:06:01 --> Loader Class Initialized
INFO - 2018-02-14 10:06:01 --> Helper loaded: url_helper
INFO - 2018-02-14 10:06:01 --> Helper loaded: file_helper
INFO - 2018-02-14 10:06:01 --> Helper loaded: email_helper
INFO - 2018-02-14 10:06:01 --> Helper loaded: common_helper
INFO - 2018-02-14 10:06:01 --> Database Driver Class Initialized
DEBUG - 2018-02-14 10:06:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 10:06:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 10:06:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-14 10:06:01 --> Pagination Class Initialized
INFO - 2018-02-14 10:06:01 --> Helper loaded: form_helper
INFO - 2018-02-14 10:06:01 --> Form Validation Class Initialized
INFO - 2018-02-14 10:06:01 --> Model Class Initialized
INFO - 2018-02-14 10:06:01 --> Controller Class Initialized
INFO - 2018-02-14 10:06:01 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-14 10:06:01 --> Model Class Initialized
INFO - 2018-02-14 10:06:01 --> File loaded: /var/www/html/project/radio/application/views/index/index.php
INFO - 2018-02-14 10:06:01 --> Final output sent to browser
DEBUG - 2018-02-14 10:06:01 --> Total execution time: 0.0582
INFO - 2018-02-14 10:06:07 --> Config Class Initialized
INFO - 2018-02-14 10:06:07 --> Hooks Class Initialized
DEBUG - 2018-02-14 10:06:07 --> UTF-8 Support Enabled
INFO - 2018-02-14 10:06:07 --> Utf8 Class Initialized
INFO - 2018-02-14 10:06:07 --> URI Class Initialized
INFO - 2018-02-14 10:06:07 --> Router Class Initialized
INFO - 2018-02-14 10:06:07 --> Output Class Initialized
INFO - 2018-02-14 10:06:07 --> Security Class Initialized
DEBUG - 2018-02-14 10:06:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 10:06:07 --> Input Class Initialized
INFO - 2018-02-14 10:06:07 --> Language Class Initialized
INFO - 2018-02-14 10:06:07 --> Loader Class Initialized
INFO - 2018-02-14 10:06:07 --> Helper loaded: url_helper
INFO - 2018-02-14 10:06:07 --> Helper loaded: file_helper
INFO - 2018-02-14 10:06:07 --> Helper loaded: email_helper
INFO - 2018-02-14 10:06:07 --> Helper loaded: common_helper
INFO - 2018-02-14 10:06:07 --> Database Driver Class Initialized
DEBUG - 2018-02-14 10:06:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 10:06:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 10:06:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-14 10:06:07 --> Pagination Class Initialized
INFO - 2018-02-14 10:06:07 --> Helper loaded: form_helper
INFO - 2018-02-14 10:06:07 --> Form Validation Class Initialized
INFO - 2018-02-14 10:06:07 --> Model Class Initialized
INFO - 2018-02-14 10:06:07 --> Controller Class Initialized
INFO - 2018-02-14 10:06:07 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-14 10:06:07 --> Model Class Initialized
INFO - 2018-02-14 10:06:07 --> Config Class Initialized
INFO - 2018-02-14 10:06:07 --> Hooks Class Initialized
DEBUG - 2018-02-14 10:06:07 --> UTF-8 Support Enabled
INFO - 2018-02-14 10:06:07 --> Utf8 Class Initialized
INFO - 2018-02-14 10:06:07 --> URI Class Initialized
INFO - 2018-02-14 10:06:07 --> Router Class Initialized
INFO - 2018-02-14 10:06:07 --> Output Class Initialized
INFO - 2018-02-14 10:06:07 --> Security Class Initialized
DEBUG - 2018-02-14 10:06:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 10:06:07 --> Input Class Initialized
INFO - 2018-02-14 10:06:07 --> Language Class Initialized
INFO - 2018-02-14 10:06:07 --> Loader Class Initialized
INFO - 2018-02-14 10:06:07 --> Helper loaded: url_helper
INFO - 2018-02-14 10:06:07 --> Helper loaded: file_helper
INFO - 2018-02-14 10:06:07 --> Helper loaded: email_helper
INFO - 2018-02-14 10:06:07 --> Helper loaded: common_helper
INFO - 2018-02-14 10:06:07 --> Database Driver Class Initialized
DEBUG - 2018-02-14 10:06:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 10:06:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 10:06:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-14 10:06:07 --> Pagination Class Initialized
INFO - 2018-02-14 10:06:07 --> Helper loaded: form_helper
INFO - 2018-02-14 10:06:07 --> Form Validation Class Initialized
INFO - 2018-02-14 10:06:07 --> Model Class Initialized
INFO - 2018-02-14 10:06:07 --> Controller Class Initialized
INFO - 2018-02-14 10:06:07 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-14 10:06:07 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-14 10:06:07 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-14 10:06:07 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-14 10:06:07 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-14 10:06:07 --> File loaded: /var/www/html/project/radio/application/views/dashboard/index.php
INFO - 2018-02-14 10:06:07 --> Final output sent to browser
DEBUG - 2018-02-14 10:06:07 --> Total execution time: 0.1477
INFO - 2018-02-14 10:06:11 --> Config Class Initialized
INFO - 2018-02-14 10:06:11 --> Hooks Class Initialized
DEBUG - 2018-02-14 10:06:11 --> UTF-8 Support Enabled
INFO - 2018-02-14 10:06:11 --> Utf8 Class Initialized
INFO - 2018-02-14 10:06:11 --> URI Class Initialized
INFO - 2018-02-14 10:06:11 --> Router Class Initialized
INFO - 2018-02-14 10:06:11 --> Output Class Initialized
INFO - 2018-02-14 10:06:11 --> Security Class Initialized
DEBUG - 2018-02-14 10:06:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 10:06:11 --> Input Class Initialized
INFO - 2018-02-14 10:06:11 --> Language Class Initialized
INFO - 2018-02-14 10:06:11 --> Loader Class Initialized
INFO - 2018-02-14 10:06:11 --> Helper loaded: url_helper
INFO - 2018-02-14 10:06:11 --> Helper loaded: file_helper
INFO - 2018-02-14 10:06:11 --> Helper loaded: email_helper
INFO - 2018-02-14 10:06:11 --> Helper loaded: common_helper
INFO - 2018-02-14 10:06:11 --> Database Driver Class Initialized
DEBUG - 2018-02-14 10:06:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 10:06:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 10:06:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-14 10:06:11 --> Pagination Class Initialized
INFO - 2018-02-14 10:06:11 --> Helper loaded: form_helper
INFO - 2018-02-14 10:06:11 --> Form Validation Class Initialized
INFO - 2018-02-14 10:06:11 --> Model Class Initialized
INFO - 2018-02-14 10:06:11 --> Controller Class Initialized
INFO - 2018-02-14 10:06:11 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-14 10:06:11 --> Model Class Initialized
INFO - 2018-02-14 10:06:11 --> Config Class Initialized
INFO - 2018-02-14 10:06:11 --> Hooks Class Initialized
DEBUG - 2018-02-14 10:06:11 --> UTF-8 Support Enabled
INFO - 2018-02-14 10:06:11 --> Utf8 Class Initialized
INFO - 2018-02-14 10:06:11 --> URI Class Initialized
INFO - 2018-02-14 10:06:11 --> Router Class Initialized
INFO - 2018-02-14 10:06:11 --> Output Class Initialized
INFO - 2018-02-14 10:06:11 --> Security Class Initialized
DEBUG - 2018-02-14 10:06:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 10:06:11 --> Input Class Initialized
INFO - 2018-02-14 10:06:11 --> Language Class Initialized
INFO - 2018-02-14 10:06:11 --> Loader Class Initialized
INFO - 2018-02-14 10:06:11 --> Helper loaded: url_helper
INFO - 2018-02-14 10:06:11 --> Helper loaded: file_helper
INFO - 2018-02-14 10:06:11 --> Helper loaded: email_helper
INFO - 2018-02-14 10:06:11 --> Helper loaded: common_helper
INFO - 2018-02-14 10:06:11 --> Database Driver Class Initialized
DEBUG - 2018-02-14 10:06:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 10:06:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 10:06:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-14 10:06:11 --> Pagination Class Initialized
INFO - 2018-02-14 10:06:11 --> Helper loaded: form_helper
INFO - 2018-02-14 10:06:11 --> Form Validation Class Initialized
INFO - 2018-02-14 10:06:11 --> Model Class Initialized
INFO - 2018-02-14 10:06:11 --> Controller Class Initialized
INFO - 2018-02-14 10:06:11 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-14 10:06:11 --> Model Class Initialized
INFO - 2018-02-14 10:06:11 --> File loaded: /var/www/html/project/radio/application/views/index/index.php
INFO - 2018-02-14 10:06:11 --> Final output sent to browser
DEBUG - 2018-02-14 10:06:11 --> Total execution time: 0.0254
INFO - 2018-02-14 10:06:12 --> Config Class Initialized
INFO - 2018-02-14 10:06:12 --> Hooks Class Initialized
DEBUG - 2018-02-14 10:06:12 --> UTF-8 Support Enabled
INFO - 2018-02-14 10:06:12 --> Utf8 Class Initialized
INFO - 2018-02-14 10:06:12 --> URI Class Initialized
INFO - 2018-02-14 10:06:12 --> Router Class Initialized
INFO - 2018-02-14 10:06:12 --> Output Class Initialized
INFO - 2018-02-14 10:06:12 --> Security Class Initialized
DEBUG - 2018-02-14 10:06:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 10:06:12 --> Input Class Initialized
INFO - 2018-02-14 10:06:12 --> Language Class Initialized
INFO - 2018-02-14 10:06:12 --> Loader Class Initialized
INFO - 2018-02-14 10:06:12 --> Helper loaded: url_helper
INFO - 2018-02-14 10:06:12 --> Helper loaded: file_helper
INFO - 2018-02-14 10:06:12 --> Helper loaded: email_helper
INFO - 2018-02-14 10:06:12 --> Helper loaded: common_helper
INFO - 2018-02-14 10:06:12 --> Database Driver Class Initialized
DEBUG - 2018-02-14 10:06:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 10:06:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 10:06:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-14 10:06:12 --> Pagination Class Initialized
INFO - 2018-02-14 10:06:12 --> Helper loaded: form_helper
INFO - 2018-02-14 10:06:12 --> Form Validation Class Initialized
INFO - 2018-02-14 10:06:12 --> Model Class Initialized
INFO - 2018-02-14 10:06:12 --> Controller Class Initialized
INFO - 2018-02-14 10:06:12 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-14 10:06:12 --> Model Class Initialized
ERROR - 2018-02-14 10:06:12 --> Severity: Notice --> Undefined index: remember_me /var/www/html/project/radio/application/controllers/Index.php 73
INFO - 2018-02-14 10:06:12 --> Config Class Initialized
INFO - 2018-02-14 10:06:12 --> Hooks Class Initialized
DEBUG - 2018-02-14 10:06:12 --> UTF-8 Support Enabled
INFO - 2018-02-14 10:06:12 --> Utf8 Class Initialized
INFO - 2018-02-14 10:06:12 --> URI Class Initialized
INFO - 2018-02-14 10:06:12 --> Router Class Initialized
INFO - 2018-02-14 10:06:12 --> Output Class Initialized
INFO - 2018-02-14 10:06:12 --> Security Class Initialized
DEBUG - 2018-02-14 10:06:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 10:06:12 --> Input Class Initialized
INFO - 2018-02-14 10:06:12 --> Language Class Initialized
INFO - 2018-02-14 10:06:12 --> Loader Class Initialized
INFO - 2018-02-14 10:06:12 --> Helper loaded: url_helper
INFO - 2018-02-14 10:06:12 --> Helper loaded: file_helper
INFO - 2018-02-14 10:06:12 --> Helper loaded: email_helper
INFO - 2018-02-14 10:06:12 --> Helper loaded: common_helper
INFO - 2018-02-14 10:06:12 --> Database Driver Class Initialized
DEBUG - 2018-02-14 10:06:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 10:06:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 10:06:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-14 10:06:12 --> Pagination Class Initialized
INFO - 2018-02-14 10:06:12 --> Helper loaded: form_helper
INFO - 2018-02-14 10:06:12 --> Form Validation Class Initialized
INFO - 2018-02-14 10:06:12 --> Model Class Initialized
INFO - 2018-02-14 10:06:12 --> Controller Class Initialized
INFO - 2018-02-14 10:06:12 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-14 10:06:12 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-14 10:06:12 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-14 10:06:12 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-14 10:06:12 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-14 10:06:12 --> File loaded: /var/www/html/project/radio/application/views/dashboard/index.php
INFO - 2018-02-14 10:06:12 --> Final output sent to browser
DEBUG - 2018-02-14 10:06:12 --> Total execution time: 0.0032
INFO - 2018-02-14 10:13:04 --> Config Class Initialized
INFO - 2018-02-14 10:13:04 --> Hooks Class Initialized
DEBUG - 2018-02-14 10:13:04 --> UTF-8 Support Enabled
INFO - 2018-02-14 10:13:04 --> Utf8 Class Initialized
INFO - 2018-02-14 10:13:04 --> URI Class Initialized
INFO - 2018-02-14 10:13:04 --> Router Class Initialized
INFO - 2018-02-14 10:13:04 --> Output Class Initialized
INFO - 2018-02-14 10:13:04 --> Security Class Initialized
DEBUG - 2018-02-14 10:13:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 10:13:04 --> Input Class Initialized
INFO - 2018-02-14 10:13:04 --> Language Class Initialized
INFO - 2018-02-14 10:13:04 --> Loader Class Initialized
INFO - 2018-02-14 10:13:04 --> Helper loaded: url_helper
INFO - 2018-02-14 10:13:04 --> Helper loaded: file_helper
INFO - 2018-02-14 10:13:04 --> Helper loaded: email_helper
INFO - 2018-02-14 10:13:04 --> Helper loaded: common_helper
INFO - 2018-02-14 10:13:04 --> Database Driver Class Initialized
DEBUG - 2018-02-14 10:13:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 10:13:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 10:13:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-14 10:13:04 --> Pagination Class Initialized
INFO - 2018-02-14 10:13:04 --> Helper loaded: form_helper
INFO - 2018-02-14 10:13:04 --> Form Validation Class Initialized
INFO - 2018-02-14 10:13:04 --> Model Class Initialized
INFO - 2018-02-14 10:13:04 --> Controller Class Initialized
INFO - 2018-02-14 10:13:04 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-14 10:13:04 --> Model Class Initialized
INFO - 2018-02-14 10:13:04 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-14 10:13:04 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-14 10:13:04 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-14 10:13:04 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-14 10:13:04 --> File loaded: /var/www/html/project/radio/application/views/user/index.php
INFO - 2018-02-14 10:13:04 --> Final output sent to browser
DEBUG - 2018-02-14 10:13:04 --> Total execution time: 0.0455
INFO - 2018-02-14 10:13:04 --> Config Class Initialized
INFO - 2018-02-14 10:13:04 --> Hooks Class Initialized
DEBUG - 2018-02-14 10:13:04 --> UTF-8 Support Enabled
INFO - 2018-02-14 10:13:04 --> Utf8 Class Initialized
INFO - 2018-02-14 10:13:04 --> URI Class Initialized
INFO - 2018-02-14 10:13:04 --> Router Class Initialized
INFO - 2018-02-14 10:13:04 --> Output Class Initialized
INFO - 2018-02-14 10:13:04 --> Security Class Initialized
DEBUG - 2018-02-14 10:13:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 10:13:04 --> Input Class Initialized
INFO - 2018-02-14 10:13:04 --> Language Class Initialized
INFO - 2018-02-14 10:13:04 --> Loader Class Initialized
INFO - 2018-02-14 10:13:04 --> Helper loaded: url_helper
INFO - 2018-02-14 10:13:04 --> Helper loaded: file_helper
INFO - 2018-02-14 10:13:04 --> Helper loaded: email_helper
INFO - 2018-02-14 10:13:04 --> Helper loaded: common_helper
INFO - 2018-02-14 10:13:04 --> Database Driver Class Initialized
DEBUG - 2018-02-14 10:13:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 10:13:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 10:13:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-14 10:13:04 --> Pagination Class Initialized
INFO - 2018-02-14 10:13:04 --> Helper loaded: form_helper
INFO - 2018-02-14 10:13:04 --> Form Validation Class Initialized
INFO - 2018-02-14 10:13:04 --> Model Class Initialized
INFO - 2018-02-14 10:13:04 --> Controller Class Initialized
INFO - 2018-02-14 10:13:04 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-14 10:13:04 --> Model Class Initialized
INFO - 2018-02-14 10:54:43 --> Config Class Initialized
INFO - 2018-02-14 10:54:43 --> Hooks Class Initialized
DEBUG - 2018-02-14 10:54:43 --> UTF-8 Support Enabled
INFO - 2018-02-14 10:54:43 --> Utf8 Class Initialized
INFO - 2018-02-14 10:54:43 --> URI Class Initialized
INFO - 2018-02-14 10:54:43 --> Router Class Initialized
INFO - 2018-02-14 10:54:43 --> Output Class Initialized
INFO - 2018-02-14 10:54:43 --> Security Class Initialized
DEBUG - 2018-02-14 10:54:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 10:54:43 --> Input Class Initialized
INFO - 2018-02-14 10:54:43 --> Language Class Initialized
INFO - 2018-02-14 10:54:43 --> Loader Class Initialized
INFO - 2018-02-14 10:54:43 --> Helper loaded: url_helper
INFO - 2018-02-14 10:54:43 --> Helper loaded: file_helper
INFO - 2018-02-14 10:54:43 --> Helper loaded: email_helper
INFO - 2018-02-14 10:54:43 --> Helper loaded: common_helper
INFO - 2018-02-14 10:54:43 --> Database Driver Class Initialized
DEBUG - 2018-02-14 10:54:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 10:54:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 10:54:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-14 10:54:43 --> Pagination Class Initialized
INFO - 2018-02-14 10:54:43 --> Helper loaded: form_helper
INFO - 2018-02-14 10:54:43 --> Form Validation Class Initialized
INFO - 2018-02-14 10:54:43 --> Model Class Initialized
INFO - 2018-02-14 10:54:43 --> Controller Class Initialized
INFO - 2018-02-14 10:54:43 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-14 10:54:43 --> Model Class Initialized
INFO - 2018-02-14 10:54:43 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-14 10:54:43 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-14 10:54:43 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-14 10:54:43 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-14 10:54:43 --> File loaded: /var/www/html/project/radio/application/views/user/index.php
INFO - 2018-02-14 10:54:43 --> Final output sent to browser
DEBUG - 2018-02-14 10:54:43 --> Total execution time: 0.2329
INFO - 2018-02-14 10:54:44 --> Config Class Initialized
INFO - 2018-02-14 10:54:44 --> Hooks Class Initialized
DEBUG - 2018-02-14 10:54:44 --> UTF-8 Support Enabled
INFO - 2018-02-14 10:54:44 --> Utf8 Class Initialized
INFO - 2018-02-14 10:54:44 --> URI Class Initialized
INFO - 2018-02-14 10:54:44 --> Router Class Initialized
INFO - 2018-02-14 10:54:44 --> Output Class Initialized
INFO - 2018-02-14 10:54:44 --> Security Class Initialized
DEBUG - 2018-02-14 10:54:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 10:54:44 --> Input Class Initialized
INFO - 2018-02-14 10:54:44 --> Language Class Initialized
INFO - 2018-02-14 10:54:44 --> Loader Class Initialized
INFO - 2018-02-14 10:54:44 --> Helper loaded: url_helper
INFO - 2018-02-14 10:54:44 --> Helper loaded: file_helper
INFO - 2018-02-14 10:54:44 --> Helper loaded: email_helper
INFO - 2018-02-14 10:54:44 --> Helper loaded: common_helper
INFO - 2018-02-14 10:54:44 --> Database Driver Class Initialized
DEBUG - 2018-02-14 10:54:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 10:54:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 10:54:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-14 10:54:44 --> Pagination Class Initialized
INFO - 2018-02-14 10:54:44 --> Helper loaded: form_helper
INFO - 2018-02-14 10:54:44 --> Form Validation Class Initialized
INFO - 2018-02-14 10:54:44 --> Model Class Initialized
INFO - 2018-02-14 10:54:44 --> Controller Class Initialized
INFO - 2018-02-14 10:54:44 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-14 10:54:44 --> Model Class Initialized
INFO - 2018-02-14 11:52:06 --> Config Class Initialized
INFO - 2018-02-14 11:52:06 --> Hooks Class Initialized
DEBUG - 2018-02-14 11:52:06 --> UTF-8 Support Enabled
INFO - 2018-02-14 11:52:06 --> Utf8 Class Initialized
INFO - 2018-02-14 11:52:06 --> URI Class Initialized
INFO - 2018-02-14 11:52:06 --> Router Class Initialized
INFO - 2018-02-14 11:52:06 --> Output Class Initialized
INFO - 2018-02-14 11:52:06 --> Security Class Initialized
DEBUG - 2018-02-14 11:52:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 11:52:06 --> Input Class Initialized
INFO - 2018-02-14 11:52:06 --> Language Class Initialized
INFO - 2018-02-14 11:52:06 --> Loader Class Initialized
INFO - 2018-02-14 11:52:06 --> Helper loaded: url_helper
INFO - 2018-02-14 11:52:06 --> Helper loaded: file_helper
INFO - 2018-02-14 11:52:06 --> Helper loaded: email_helper
INFO - 2018-02-14 11:52:06 --> Helper loaded: common_helper
INFO - 2018-02-14 11:52:06 --> Database Driver Class Initialized
DEBUG - 2018-02-14 11:52:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 11:52:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 11:52:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-14 11:52:06 --> Pagination Class Initialized
INFO - 2018-02-14 11:52:06 --> Helper loaded: form_helper
INFO - 2018-02-14 11:52:06 --> Form Validation Class Initialized
INFO - 2018-02-14 11:52:06 --> Model Class Initialized
INFO - 2018-02-14 11:52:06 --> Controller Class Initialized
INFO - 2018-02-14 11:52:06 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-14 11:52:06 --> Model Class Initialized
INFO - 2018-02-14 11:52:06 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-14 11:52:06 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-14 11:52:06 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-14 11:52:06 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-14 11:52:06 --> File loaded: /var/www/html/project/radio/application/views/user/index.php
INFO - 2018-02-14 11:52:06 --> Final output sent to browser
DEBUG - 2018-02-14 11:52:06 --> Total execution time: 0.0101
INFO - 2018-02-14 11:52:06 --> Config Class Initialized
INFO - 2018-02-14 11:52:06 --> Hooks Class Initialized
DEBUG - 2018-02-14 11:52:06 --> UTF-8 Support Enabled
INFO - 2018-02-14 11:52:06 --> Utf8 Class Initialized
INFO - 2018-02-14 11:52:06 --> URI Class Initialized
INFO - 2018-02-14 11:52:06 --> Router Class Initialized
INFO - 2018-02-14 11:52:06 --> Output Class Initialized
INFO - 2018-02-14 11:52:06 --> Security Class Initialized
DEBUG - 2018-02-14 11:52:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 11:52:06 --> Input Class Initialized
INFO - 2018-02-14 11:52:06 --> Language Class Initialized
INFO - 2018-02-14 11:52:06 --> Loader Class Initialized
INFO - 2018-02-14 11:52:06 --> Helper loaded: url_helper
INFO - 2018-02-14 11:52:06 --> Helper loaded: file_helper
INFO - 2018-02-14 11:52:06 --> Helper loaded: email_helper
INFO - 2018-02-14 11:52:06 --> Helper loaded: common_helper
INFO - 2018-02-14 11:52:06 --> Database Driver Class Initialized
DEBUG - 2018-02-14 11:52:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 11:52:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 11:52:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-14 11:52:06 --> Pagination Class Initialized
INFO - 2018-02-14 11:52:06 --> Helper loaded: form_helper
INFO - 2018-02-14 11:52:06 --> Form Validation Class Initialized
INFO - 2018-02-14 11:52:06 --> Model Class Initialized
INFO - 2018-02-14 11:52:06 --> Controller Class Initialized
INFO - 2018-02-14 11:52:06 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-14 11:52:06 --> Model Class Initialized
INFO - 2018-02-14 11:52:08 --> Config Class Initialized
INFO - 2018-02-14 11:52:08 --> Hooks Class Initialized
DEBUG - 2018-02-14 11:52:08 --> UTF-8 Support Enabled
INFO - 2018-02-14 11:52:08 --> Utf8 Class Initialized
INFO - 2018-02-14 11:52:08 --> URI Class Initialized
INFO - 2018-02-14 11:52:08 --> Router Class Initialized
INFO - 2018-02-14 11:52:08 --> Output Class Initialized
INFO - 2018-02-14 11:52:08 --> Security Class Initialized
DEBUG - 2018-02-14 11:52:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 11:52:08 --> Input Class Initialized
INFO - 2018-02-14 11:52:08 --> Language Class Initialized
INFO - 2018-02-14 11:52:08 --> Loader Class Initialized
INFO - 2018-02-14 11:52:08 --> Helper loaded: url_helper
INFO - 2018-02-14 11:52:08 --> Helper loaded: file_helper
INFO - 2018-02-14 11:52:08 --> Helper loaded: email_helper
INFO - 2018-02-14 11:52:08 --> Helper loaded: common_helper
INFO - 2018-02-14 11:52:08 --> Database Driver Class Initialized
DEBUG - 2018-02-14 11:52:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 11:52:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 11:52:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-14 11:52:08 --> Pagination Class Initialized
INFO - 2018-02-14 11:52:08 --> Helper loaded: form_helper
INFO - 2018-02-14 11:52:08 --> Form Validation Class Initialized
INFO - 2018-02-14 11:52:08 --> Model Class Initialized
INFO - 2018-02-14 11:52:08 --> Controller Class Initialized
INFO - 2018-02-14 11:52:08 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-14 11:52:08 --> Model Class Initialized
INFO - 2018-02-14 11:52:08 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-14 11:52:08 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-14 11:52:08 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-14 11:52:08 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-14 11:52:08 --> File loaded: /var/www/html/project/radio/application/views/category/index.php
INFO - 2018-02-14 11:52:08 --> Final output sent to browser
DEBUG - 2018-02-14 11:52:08 --> Total execution time: 0.0063
INFO - 2018-02-14 11:52:08 --> Config Class Initialized
INFO - 2018-02-14 11:52:08 --> Hooks Class Initialized
DEBUG - 2018-02-14 11:52:08 --> UTF-8 Support Enabled
INFO - 2018-02-14 11:52:08 --> Utf8 Class Initialized
INFO - 2018-02-14 11:52:08 --> URI Class Initialized
INFO - 2018-02-14 11:52:08 --> Router Class Initialized
INFO - 2018-02-14 11:52:08 --> Output Class Initialized
INFO - 2018-02-14 11:52:08 --> Security Class Initialized
DEBUG - 2018-02-14 11:52:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 11:52:08 --> Input Class Initialized
INFO - 2018-02-14 11:52:08 --> Language Class Initialized
INFO - 2018-02-14 11:52:08 --> Loader Class Initialized
INFO - 2018-02-14 11:52:08 --> Helper loaded: url_helper
INFO - 2018-02-14 11:52:08 --> Helper loaded: file_helper
INFO - 2018-02-14 11:52:08 --> Helper loaded: email_helper
INFO - 2018-02-14 11:52:08 --> Helper loaded: common_helper
INFO - 2018-02-14 11:52:08 --> Database Driver Class Initialized
DEBUG - 2018-02-14 11:52:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 11:52:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 11:52:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-14 11:52:08 --> Pagination Class Initialized
INFO - 2018-02-14 11:52:08 --> Helper loaded: form_helper
INFO - 2018-02-14 11:52:08 --> Form Validation Class Initialized
INFO - 2018-02-14 11:52:08 --> Model Class Initialized
INFO - 2018-02-14 11:52:08 --> Controller Class Initialized
INFO - 2018-02-14 11:52:08 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-14 11:52:08 --> Model Class Initialized
INFO - 2018-02-14 11:53:43 --> Config Class Initialized
INFO - 2018-02-14 11:53:43 --> Hooks Class Initialized
DEBUG - 2018-02-14 11:53:43 --> UTF-8 Support Enabled
INFO - 2018-02-14 11:53:43 --> Utf8 Class Initialized
INFO - 2018-02-14 11:53:43 --> URI Class Initialized
INFO - 2018-02-14 11:53:43 --> Router Class Initialized
INFO - 2018-02-14 11:53:43 --> Output Class Initialized
INFO - 2018-02-14 11:53:43 --> Security Class Initialized
DEBUG - 2018-02-14 11:53:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 11:53:43 --> Input Class Initialized
INFO - 2018-02-14 11:53:43 --> Language Class Initialized
INFO - 2018-02-14 11:53:43 --> Loader Class Initialized
INFO - 2018-02-14 11:53:43 --> Helper loaded: url_helper
INFO - 2018-02-14 11:53:43 --> Helper loaded: file_helper
INFO - 2018-02-14 11:53:43 --> Helper loaded: email_helper
INFO - 2018-02-14 11:53:43 --> Helper loaded: common_helper
INFO - 2018-02-14 11:53:43 --> Database Driver Class Initialized
DEBUG - 2018-02-14 11:53:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 11:53:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 11:53:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-14 11:53:43 --> Pagination Class Initialized
INFO - 2018-02-14 11:53:43 --> Helper loaded: form_helper
INFO - 2018-02-14 11:53:43 --> Form Validation Class Initialized
INFO - 2018-02-14 11:53:43 --> Model Class Initialized
INFO - 2018-02-14 11:53:43 --> Controller Class Initialized
INFO - 2018-02-14 11:53:43 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-14 11:53:43 --> Model Class Initialized
INFO - 2018-02-14 11:53:43 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-14 11:53:43 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-14 11:53:43 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-14 11:53:43 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-14 11:53:43 --> File loaded: /var/www/html/project/radio/application/views/category/index.php
INFO - 2018-02-14 11:53:43 --> Final output sent to browser
DEBUG - 2018-02-14 11:53:43 --> Total execution time: 0.0088
INFO - 2018-02-14 12:32:47 --> Config Class Initialized
INFO - 2018-02-14 12:32:47 --> Hooks Class Initialized
DEBUG - 2018-02-14 12:32:47 --> UTF-8 Support Enabled
INFO - 2018-02-14 12:32:47 --> Utf8 Class Initialized
INFO - 2018-02-14 12:32:47 --> URI Class Initialized
INFO - 2018-02-14 12:32:47 --> Router Class Initialized
INFO - 2018-02-14 12:32:47 --> Output Class Initialized
INFO - 2018-02-14 12:32:47 --> Security Class Initialized
DEBUG - 2018-02-14 12:32:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 12:32:47 --> Input Class Initialized
INFO - 2018-02-14 12:32:47 --> Language Class Initialized
INFO - 2018-02-14 12:32:47 --> Loader Class Initialized
INFO - 2018-02-14 12:32:47 --> Helper loaded: url_helper
INFO - 2018-02-14 12:32:47 --> Helper loaded: file_helper
INFO - 2018-02-14 12:32:47 --> Helper loaded: email_helper
INFO - 2018-02-14 12:32:47 --> Helper loaded: common_helper
INFO - 2018-02-14 12:32:47 --> Database Driver Class Initialized
DEBUG - 2018-02-14 12:32:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 12:32:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 12:32:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-14 12:32:47 --> Pagination Class Initialized
INFO - 2018-02-14 12:32:47 --> Helper loaded: form_helper
INFO - 2018-02-14 12:32:47 --> Form Validation Class Initialized
INFO - 2018-02-14 12:32:47 --> Model Class Initialized
INFO - 2018-02-14 12:32:47 --> Controller Class Initialized
INFO - 2018-02-14 12:32:47 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-14 12:32:47 --> Model Class Initialized
INFO - 2018-02-14 12:32:47 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-14 12:32:47 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-14 12:32:47 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-14 12:32:47 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-14 12:32:47 --> File loaded: /var/www/html/project/radio/application/views/category/index.php
INFO - 2018-02-14 12:32:47 --> Final output sent to browser
DEBUG - 2018-02-14 12:32:47 --> Total execution time: 0.0075
INFO - 2018-02-14 12:32:49 --> Config Class Initialized
INFO - 2018-02-14 12:32:49 --> Hooks Class Initialized
DEBUG - 2018-02-14 12:32:49 --> UTF-8 Support Enabled
INFO - 2018-02-14 12:32:49 --> Utf8 Class Initialized
INFO - 2018-02-14 12:32:49 --> URI Class Initialized
INFO - 2018-02-14 12:32:49 --> Router Class Initialized
INFO - 2018-02-14 12:32:49 --> Output Class Initialized
INFO - 2018-02-14 12:32:49 --> Security Class Initialized
DEBUG - 2018-02-14 12:32:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 12:32:49 --> Input Class Initialized
INFO - 2018-02-14 12:32:49 --> Language Class Initialized
INFO - 2018-02-14 12:32:49 --> Loader Class Initialized
INFO - 2018-02-14 12:32:49 --> Helper loaded: url_helper
INFO - 2018-02-14 12:32:49 --> Helper loaded: file_helper
INFO - 2018-02-14 12:32:49 --> Helper loaded: email_helper
INFO - 2018-02-14 12:32:49 --> Helper loaded: common_helper
INFO - 2018-02-14 12:32:49 --> Database Driver Class Initialized
DEBUG - 2018-02-14 12:32:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 12:32:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 12:32:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-14 12:32:49 --> Pagination Class Initialized
INFO - 2018-02-14 12:32:49 --> Helper loaded: form_helper
INFO - 2018-02-14 12:32:49 --> Form Validation Class Initialized
INFO - 2018-02-14 12:32:49 --> Model Class Initialized
INFO - 2018-02-14 12:32:49 --> Controller Class Initialized
INFO - 2018-02-14 12:32:49 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-14 12:32:49 --> Model Class Initialized
INFO - 2018-02-14 12:32:49 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-14 12:32:49 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-14 12:32:49 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-14 12:32:49 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-14 12:32:49 --> File loaded: /var/www/html/project/radio/application/views/category/add_edit.php
INFO - 2018-02-14 12:32:49 --> Final output sent to browser
DEBUG - 2018-02-14 12:32:49 --> Total execution time: 0.0053
INFO - 2018-02-14 12:33:17 --> Config Class Initialized
INFO - 2018-02-14 12:33:17 --> Hooks Class Initialized
DEBUG - 2018-02-14 12:33:17 --> UTF-8 Support Enabled
INFO - 2018-02-14 12:33:17 --> Utf8 Class Initialized
INFO - 2018-02-14 12:33:17 --> URI Class Initialized
INFO - 2018-02-14 12:33:17 --> Router Class Initialized
INFO - 2018-02-14 12:33:17 --> Output Class Initialized
INFO - 2018-02-14 12:33:17 --> Security Class Initialized
DEBUG - 2018-02-14 12:33:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 12:33:17 --> Input Class Initialized
INFO - 2018-02-14 12:33:17 --> Language Class Initialized
INFO - 2018-02-14 12:33:17 --> Loader Class Initialized
INFO - 2018-02-14 12:33:17 --> Helper loaded: url_helper
INFO - 2018-02-14 12:33:17 --> Helper loaded: file_helper
INFO - 2018-02-14 12:33:17 --> Helper loaded: email_helper
INFO - 2018-02-14 12:33:17 --> Helper loaded: common_helper
INFO - 2018-02-14 12:33:17 --> Database Driver Class Initialized
DEBUG - 2018-02-14 12:33:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 12:33:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 12:33:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-14 12:33:17 --> Pagination Class Initialized
INFO - 2018-02-14 12:33:17 --> Helper loaded: form_helper
INFO - 2018-02-14 12:33:17 --> Form Validation Class Initialized
INFO - 2018-02-14 12:33:17 --> Model Class Initialized
INFO - 2018-02-14 12:33:17 --> Controller Class Initialized
INFO - 2018-02-14 12:33:17 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-14 12:33:17 --> Model Class Initialized
INFO - 2018-02-14 12:33:17 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-14 12:33:17 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-14 12:33:17 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-14 12:33:17 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-14 12:33:17 --> File loaded: /var/www/html/project/radio/application/views/category/add_edit.php
INFO - 2018-02-14 12:33:17 --> Final output sent to browser
DEBUG - 2018-02-14 12:33:17 --> Total execution time: 0.0082
INFO - 2018-02-14 12:34:10 --> Config Class Initialized
INFO - 2018-02-14 12:34:10 --> Hooks Class Initialized
DEBUG - 2018-02-14 12:34:10 --> UTF-8 Support Enabled
INFO - 2018-02-14 12:34:10 --> Utf8 Class Initialized
INFO - 2018-02-14 12:34:10 --> URI Class Initialized
INFO - 2018-02-14 12:34:10 --> Router Class Initialized
INFO - 2018-02-14 12:34:10 --> Output Class Initialized
INFO - 2018-02-14 12:34:10 --> Security Class Initialized
DEBUG - 2018-02-14 12:34:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 12:34:10 --> Input Class Initialized
INFO - 2018-02-14 12:34:10 --> Language Class Initialized
INFO - 2018-02-14 12:34:10 --> Loader Class Initialized
INFO - 2018-02-14 12:34:10 --> Helper loaded: url_helper
INFO - 2018-02-14 12:34:10 --> Helper loaded: file_helper
INFO - 2018-02-14 12:34:10 --> Helper loaded: email_helper
INFO - 2018-02-14 12:34:10 --> Helper loaded: common_helper
INFO - 2018-02-14 12:34:10 --> Database Driver Class Initialized
DEBUG - 2018-02-14 12:34:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 12:34:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 12:34:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-14 12:34:10 --> Pagination Class Initialized
INFO - 2018-02-14 12:34:10 --> Helper loaded: form_helper
INFO - 2018-02-14 12:34:10 --> Form Validation Class Initialized
INFO - 2018-02-14 12:34:10 --> Model Class Initialized
INFO - 2018-02-14 12:34:10 --> Controller Class Initialized
INFO - 2018-02-14 12:34:10 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-14 12:34:10 --> Model Class Initialized
INFO - 2018-02-14 12:34:10 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-14 12:34:10 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-14 12:34:10 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-14 12:34:10 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-14 12:34:10 --> File loaded: /var/www/html/project/radio/application/views/category/add_edit.php
INFO - 2018-02-14 12:34:10 --> Final output sent to browser
DEBUG - 2018-02-14 12:34:10 --> Total execution time: 0.0051
INFO - 2018-02-14 12:37:27 --> Config Class Initialized
INFO - 2018-02-14 12:37:27 --> Hooks Class Initialized
DEBUG - 2018-02-14 12:37:27 --> UTF-8 Support Enabled
INFO - 2018-02-14 12:37:27 --> Utf8 Class Initialized
INFO - 2018-02-14 12:37:27 --> URI Class Initialized
INFO - 2018-02-14 12:37:27 --> Router Class Initialized
INFO - 2018-02-14 12:37:27 --> Output Class Initialized
INFO - 2018-02-14 12:37:27 --> Security Class Initialized
DEBUG - 2018-02-14 12:37:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 12:37:27 --> Input Class Initialized
INFO - 2018-02-14 12:37:27 --> Language Class Initialized
INFO - 2018-02-14 12:37:27 --> Loader Class Initialized
INFO - 2018-02-14 12:37:27 --> Helper loaded: url_helper
INFO - 2018-02-14 12:37:27 --> Helper loaded: file_helper
INFO - 2018-02-14 12:37:27 --> Helper loaded: email_helper
INFO - 2018-02-14 12:37:27 --> Helper loaded: common_helper
INFO - 2018-02-14 12:37:27 --> Database Driver Class Initialized
DEBUG - 2018-02-14 12:37:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 12:37:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 12:37:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-14 12:37:27 --> Pagination Class Initialized
INFO - 2018-02-14 12:37:27 --> Helper loaded: form_helper
INFO - 2018-02-14 12:37:27 --> Form Validation Class Initialized
INFO - 2018-02-14 12:37:27 --> Model Class Initialized
INFO - 2018-02-14 12:37:27 --> Controller Class Initialized
INFO - 2018-02-14 12:37:27 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-14 12:37:27 --> Model Class Initialized
INFO - 2018-02-14 12:37:27 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-14 12:37:27 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-14 12:37:27 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-14 12:37:27 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-14 12:37:27 --> File loaded: /var/www/html/project/radio/application/views/category/add_edit.php
INFO - 2018-02-14 12:37:27 --> Final output sent to browser
DEBUG - 2018-02-14 12:37:27 --> Total execution time: 0.0056
INFO - 2018-02-14 12:38:14 --> Config Class Initialized
INFO - 2018-02-14 12:38:14 --> Hooks Class Initialized
DEBUG - 2018-02-14 12:38:14 --> UTF-8 Support Enabled
INFO - 2018-02-14 12:38:14 --> Utf8 Class Initialized
INFO - 2018-02-14 12:38:14 --> URI Class Initialized
INFO - 2018-02-14 12:38:14 --> Router Class Initialized
INFO - 2018-02-14 12:38:14 --> Output Class Initialized
INFO - 2018-02-14 12:38:14 --> Security Class Initialized
DEBUG - 2018-02-14 12:38:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 12:38:14 --> Input Class Initialized
INFO - 2018-02-14 12:38:14 --> Language Class Initialized
INFO - 2018-02-14 12:38:14 --> Loader Class Initialized
INFO - 2018-02-14 12:38:14 --> Helper loaded: url_helper
INFO - 2018-02-14 12:38:14 --> Helper loaded: file_helper
INFO - 2018-02-14 12:38:14 --> Helper loaded: email_helper
INFO - 2018-02-14 12:38:14 --> Helper loaded: common_helper
INFO - 2018-02-14 12:38:14 --> Database Driver Class Initialized
DEBUG - 2018-02-14 12:38:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 12:38:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 12:38:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-14 12:38:14 --> Pagination Class Initialized
INFO - 2018-02-14 12:38:14 --> Helper loaded: form_helper
INFO - 2018-02-14 12:38:14 --> Form Validation Class Initialized
INFO - 2018-02-14 12:38:14 --> Model Class Initialized
INFO - 2018-02-14 12:38:14 --> Controller Class Initialized
INFO - 2018-02-14 12:38:14 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-14 12:38:14 --> Model Class Initialized
INFO - 2018-02-14 12:38:14 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-14 12:38:14 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-14 12:38:14 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-14 12:38:14 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-14 12:38:14 --> File loaded: /var/www/html/project/radio/application/views/category/add_edit.php
INFO - 2018-02-14 12:38:14 --> Final output sent to browser
DEBUG - 2018-02-14 12:38:14 --> Total execution time: 0.0066
INFO - 2018-02-14 12:39:00 --> Config Class Initialized
INFO - 2018-02-14 12:39:00 --> Hooks Class Initialized
DEBUG - 2018-02-14 12:39:00 --> UTF-8 Support Enabled
INFO - 2018-02-14 12:39:00 --> Utf8 Class Initialized
INFO - 2018-02-14 12:39:00 --> URI Class Initialized
INFO - 2018-02-14 12:39:00 --> Router Class Initialized
INFO - 2018-02-14 12:39:00 --> Output Class Initialized
INFO - 2018-02-14 12:39:00 --> Security Class Initialized
DEBUG - 2018-02-14 12:39:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 12:39:00 --> Input Class Initialized
INFO - 2018-02-14 12:39:00 --> Language Class Initialized
INFO - 2018-02-14 12:39:00 --> Loader Class Initialized
INFO - 2018-02-14 12:39:00 --> Helper loaded: url_helper
INFO - 2018-02-14 12:39:00 --> Helper loaded: file_helper
INFO - 2018-02-14 12:39:00 --> Helper loaded: email_helper
INFO - 2018-02-14 12:39:00 --> Helper loaded: common_helper
INFO - 2018-02-14 12:39:00 --> Database Driver Class Initialized
DEBUG - 2018-02-14 12:39:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 12:39:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 12:39:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-14 12:39:00 --> Pagination Class Initialized
INFO - 2018-02-14 12:39:00 --> Helper loaded: form_helper
INFO - 2018-02-14 12:39:00 --> Form Validation Class Initialized
INFO - 2018-02-14 12:39:00 --> Model Class Initialized
INFO - 2018-02-14 12:39:00 --> Controller Class Initialized
INFO - 2018-02-14 12:39:00 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-14 12:39:00 --> Model Class Initialized
INFO - 2018-02-14 12:39:00 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-14 12:39:00 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-14 12:39:00 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-14 12:39:00 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-14 12:39:00 --> File loaded: /var/www/html/project/radio/application/views/category/add_edit.php
INFO - 2018-02-14 12:39:00 --> Final output sent to browser
DEBUG - 2018-02-14 12:39:00 --> Total execution time: 0.0093
INFO - 2018-02-14 12:39:11 --> Config Class Initialized
INFO - 2018-02-14 12:39:11 --> Hooks Class Initialized
DEBUG - 2018-02-14 12:39:11 --> UTF-8 Support Enabled
INFO - 2018-02-14 12:39:11 --> Utf8 Class Initialized
INFO - 2018-02-14 12:39:11 --> URI Class Initialized
INFO - 2018-02-14 12:39:11 --> Router Class Initialized
INFO - 2018-02-14 12:39:11 --> Output Class Initialized
INFO - 2018-02-14 12:39:11 --> Security Class Initialized
DEBUG - 2018-02-14 12:39:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 12:39:11 --> Input Class Initialized
INFO - 2018-02-14 12:39:11 --> Language Class Initialized
INFO - 2018-02-14 12:39:11 --> Loader Class Initialized
INFO - 2018-02-14 12:39:11 --> Helper loaded: url_helper
INFO - 2018-02-14 12:39:11 --> Helper loaded: file_helper
INFO - 2018-02-14 12:39:11 --> Helper loaded: email_helper
INFO - 2018-02-14 12:39:11 --> Helper loaded: common_helper
INFO - 2018-02-14 12:39:11 --> Database Driver Class Initialized
DEBUG - 2018-02-14 12:39:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 12:39:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 12:39:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-14 12:39:11 --> Pagination Class Initialized
INFO - 2018-02-14 12:39:11 --> Helper loaded: form_helper
INFO - 2018-02-14 12:39:11 --> Form Validation Class Initialized
INFO - 2018-02-14 12:39:11 --> Model Class Initialized
INFO - 2018-02-14 12:39:11 --> Controller Class Initialized
INFO - 2018-02-14 12:39:11 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-14 12:39:11 --> Model Class Initialized
INFO - 2018-02-14 12:39:11 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-14 12:39:11 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-14 12:39:11 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-14 12:39:11 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-14 12:39:11 --> File loaded: /var/www/html/project/radio/application/views/category/add_edit.php
INFO - 2018-02-14 12:39:11 --> Final output sent to browser
DEBUG - 2018-02-14 12:39:11 --> Total execution time: 0.0063
INFO - 2018-02-14 12:39:16 --> Config Class Initialized
INFO - 2018-02-14 12:39:16 --> Hooks Class Initialized
DEBUG - 2018-02-14 12:39:16 --> UTF-8 Support Enabled
INFO - 2018-02-14 12:39:16 --> Utf8 Class Initialized
INFO - 2018-02-14 12:39:16 --> URI Class Initialized
INFO - 2018-02-14 12:39:16 --> Router Class Initialized
INFO - 2018-02-14 12:39:16 --> Output Class Initialized
INFO - 2018-02-14 12:39:16 --> Security Class Initialized
DEBUG - 2018-02-14 12:39:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 12:39:16 --> Input Class Initialized
INFO - 2018-02-14 12:39:16 --> Language Class Initialized
INFO - 2018-02-14 12:39:16 --> Loader Class Initialized
INFO - 2018-02-14 12:39:16 --> Helper loaded: url_helper
INFO - 2018-02-14 12:39:16 --> Helper loaded: file_helper
INFO - 2018-02-14 12:39:16 --> Helper loaded: email_helper
INFO - 2018-02-14 12:39:16 --> Helper loaded: common_helper
INFO - 2018-02-14 12:39:16 --> Database Driver Class Initialized
DEBUG - 2018-02-14 12:39:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 12:39:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 12:39:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-14 12:39:16 --> Pagination Class Initialized
INFO - 2018-02-14 12:39:16 --> Helper loaded: form_helper
INFO - 2018-02-14 12:39:16 --> Form Validation Class Initialized
INFO - 2018-02-14 12:39:16 --> Model Class Initialized
INFO - 2018-02-14 12:39:16 --> Controller Class Initialized
INFO - 2018-02-14 12:39:16 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-14 12:39:16 --> Model Class Initialized
INFO - 2018-02-14 12:39:16 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-14 12:39:16 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-14 12:39:16 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-14 12:39:16 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-14 12:39:16 --> File loaded: /var/www/html/project/radio/application/views/category/add_edit.php
INFO - 2018-02-14 12:39:16 --> Final output sent to browser
DEBUG - 2018-02-14 12:39:16 --> Total execution time: 0.0089
INFO - 2018-02-14 12:39:19 --> Config Class Initialized
INFO - 2018-02-14 12:39:19 --> Hooks Class Initialized
DEBUG - 2018-02-14 12:39:19 --> UTF-8 Support Enabled
INFO - 2018-02-14 12:39:19 --> Utf8 Class Initialized
INFO - 2018-02-14 12:39:19 --> URI Class Initialized
INFO - 2018-02-14 12:39:19 --> Router Class Initialized
INFO - 2018-02-14 12:39:19 --> Output Class Initialized
INFO - 2018-02-14 12:39:19 --> Security Class Initialized
DEBUG - 2018-02-14 12:39:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 12:39:19 --> Input Class Initialized
INFO - 2018-02-14 12:39:19 --> Language Class Initialized
INFO - 2018-02-14 12:39:19 --> Loader Class Initialized
INFO - 2018-02-14 12:39:19 --> Helper loaded: url_helper
INFO - 2018-02-14 12:39:19 --> Helper loaded: file_helper
INFO - 2018-02-14 12:39:19 --> Helper loaded: email_helper
INFO - 2018-02-14 12:39:19 --> Helper loaded: common_helper
INFO - 2018-02-14 12:39:19 --> Database Driver Class Initialized
DEBUG - 2018-02-14 12:39:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 12:39:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 12:39:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-14 12:39:19 --> Pagination Class Initialized
INFO - 2018-02-14 12:39:19 --> Helper loaded: form_helper
INFO - 2018-02-14 12:39:19 --> Form Validation Class Initialized
INFO - 2018-02-14 12:39:19 --> Model Class Initialized
INFO - 2018-02-14 12:39:19 --> Controller Class Initialized
INFO - 2018-02-14 12:39:19 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-14 12:39:19 --> Model Class Initialized
INFO - 2018-02-14 12:39:19 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-14 12:39:19 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-14 12:39:19 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-14 12:39:19 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-14 12:39:19 --> File loaded: /var/www/html/project/radio/application/views/category/add_edit.php
INFO - 2018-02-14 12:39:19 --> Final output sent to browser
DEBUG - 2018-02-14 12:39:19 --> Total execution time: 0.0051
INFO - 2018-02-14 12:39:31 --> Config Class Initialized
INFO - 2018-02-14 12:39:31 --> Hooks Class Initialized
DEBUG - 2018-02-14 12:39:31 --> UTF-8 Support Enabled
INFO - 2018-02-14 12:39:31 --> Utf8 Class Initialized
INFO - 2018-02-14 12:39:31 --> URI Class Initialized
INFO - 2018-02-14 12:39:31 --> Router Class Initialized
INFO - 2018-02-14 12:39:31 --> Output Class Initialized
INFO - 2018-02-14 12:39:31 --> Security Class Initialized
DEBUG - 2018-02-14 12:39:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 12:39:31 --> Input Class Initialized
INFO - 2018-02-14 12:39:31 --> Language Class Initialized
INFO - 2018-02-14 12:39:31 --> Loader Class Initialized
INFO - 2018-02-14 12:39:31 --> Helper loaded: url_helper
INFO - 2018-02-14 12:39:31 --> Helper loaded: file_helper
INFO - 2018-02-14 12:39:31 --> Helper loaded: email_helper
INFO - 2018-02-14 12:39:31 --> Helper loaded: common_helper
INFO - 2018-02-14 12:39:31 --> Database Driver Class Initialized
DEBUG - 2018-02-14 12:39:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 12:39:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 12:39:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-14 12:39:31 --> Pagination Class Initialized
INFO - 2018-02-14 12:39:31 --> Helper loaded: form_helper
INFO - 2018-02-14 12:39:31 --> Form Validation Class Initialized
INFO - 2018-02-14 12:39:31 --> Model Class Initialized
INFO - 2018-02-14 12:39:31 --> Controller Class Initialized
INFO - 2018-02-14 12:39:31 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-14 12:39:31 --> Model Class Initialized
INFO - 2018-02-14 12:39:31 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-14 12:39:31 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-14 12:39:31 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-14 12:39:31 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-14 12:39:31 --> File loaded: /var/www/html/project/radio/application/views/category/add_edit.php
INFO - 2018-02-14 12:39:31 --> Final output sent to browser
DEBUG - 2018-02-14 12:39:31 --> Total execution time: 0.0096
INFO - 2018-02-14 12:39:40 --> Config Class Initialized
INFO - 2018-02-14 12:39:40 --> Hooks Class Initialized
DEBUG - 2018-02-14 12:39:40 --> UTF-8 Support Enabled
INFO - 2018-02-14 12:39:40 --> Utf8 Class Initialized
INFO - 2018-02-14 12:39:40 --> URI Class Initialized
INFO - 2018-02-14 12:39:40 --> Router Class Initialized
INFO - 2018-02-14 12:39:40 --> Output Class Initialized
INFO - 2018-02-14 12:39:40 --> Security Class Initialized
DEBUG - 2018-02-14 12:39:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 12:39:40 --> Input Class Initialized
INFO - 2018-02-14 12:39:40 --> Language Class Initialized
INFO - 2018-02-14 12:39:40 --> Loader Class Initialized
INFO - 2018-02-14 12:39:40 --> Helper loaded: url_helper
INFO - 2018-02-14 12:39:40 --> Helper loaded: file_helper
INFO - 2018-02-14 12:39:40 --> Helper loaded: email_helper
INFO - 2018-02-14 12:39:40 --> Helper loaded: common_helper
INFO - 2018-02-14 12:39:40 --> Database Driver Class Initialized
DEBUG - 2018-02-14 12:39:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 12:39:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 12:39:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-14 12:39:40 --> Pagination Class Initialized
INFO - 2018-02-14 12:39:40 --> Helper loaded: form_helper
INFO - 2018-02-14 12:39:40 --> Form Validation Class Initialized
INFO - 2018-02-14 12:39:40 --> Model Class Initialized
INFO - 2018-02-14 12:39:40 --> Controller Class Initialized
INFO - 2018-02-14 12:39:40 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-14 12:39:40 --> Model Class Initialized
INFO - 2018-02-14 12:39:40 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-14 12:39:40 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-14 12:39:40 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-14 12:39:40 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-14 12:39:40 --> File loaded: /var/www/html/project/radio/application/views/category/add_edit.php
INFO - 2018-02-14 12:39:40 --> Final output sent to browser
DEBUG - 2018-02-14 12:39:40 --> Total execution time: 0.0069
INFO - 2018-02-14 12:40:02 --> Config Class Initialized
INFO - 2018-02-14 12:40:02 --> Hooks Class Initialized
DEBUG - 2018-02-14 12:40:02 --> UTF-8 Support Enabled
INFO - 2018-02-14 12:40:02 --> Utf8 Class Initialized
INFO - 2018-02-14 12:40:02 --> URI Class Initialized
INFO - 2018-02-14 12:40:02 --> Router Class Initialized
INFO - 2018-02-14 12:40:02 --> Output Class Initialized
INFO - 2018-02-14 12:40:02 --> Security Class Initialized
DEBUG - 2018-02-14 12:40:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 12:40:02 --> Input Class Initialized
INFO - 2018-02-14 12:40:02 --> Language Class Initialized
INFO - 2018-02-14 12:40:02 --> Loader Class Initialized
INFO - 2018-02-14 12:40:02 --> Helper loaded: url_helper
INFO - 2018-02-14 12:40:02 --> Helper loaded: file_helper
INFO - 2018-02-14 12:40:02 --> Helper loaded: email_helper
INFO - 2018-02-14 12:40:02 --> Helper loaded: common_helper
INFO - 2018-02-14 12:40:02 --> Database Driver Class Initialized
DEBUG - 2018-02-14 12:40:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 12:40:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 12:40:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-14 12:40:02 --> Pagination Class Initialized
INFO - 2018-02-14 12:40:02 --> Helper loaded: form_helper
INFO - 2018-02-14 12:40:02 --> Form Validation Class Initialized
INFO - 2018-02-14 12:40:02 --> Model Class Initialized
INFO - 2018-02-14 12:40:02 --> Controller Class Initialized
INFO - 2018-02-14 12:40:02 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-14 12:40:02 --> Model Class Initialized
INFO - 2018-02-14 12:40:02 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-14 12:40:02 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-14 12:40:02 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-14 12:40:02 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-14 12:40:02 --> File loaded: /var/www/html/project/radio/application/views/category/index.php
INFO - 2018-02-14 12:40:02 --> Final output sent to browser
DEBUG - 2018-02-14 12:40:02 --> Total execution time: 0.0068
INFO - 2018-02-14 12:40:03 --> Config Class Initialized
INFO - 2018-02-14 12:40:03 --> Hooks Class Initialized
DEBUG - 2018-02-14 12:40:03 --> UTF-8 Support Enabled
INFO - 2018-02-14 12:40:03 --> Utf8 Class Initialized
INFO - 2018-02-14 12:40:03 --> URI Class Initialized
INFO - 2018-02-14 12:40:03 --> Router Class Initialized
INFO - 2018-02-14 12:40:03 --> Output Class Initialized
INFO - 2018-02-14 12:40:03 --> Security Class Initialized
DEBUG - 2018-02-14 12:40:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 12:40:03 --> Input Class Initialized
INFO - 2018-02-14 12:40:03 --> Language Class Initialized
INFO - 2018-02-14 12:40:03 --> Loader Class Initialized
INFO - 2018-02-14 12:40:03 --> Helper loaded: url_helper
INFO - 2018-02-14 12:40:03 --> Helper loaded: file_helper
INFO - 2018-02-14 12:40:03 --> Helper loaded: email_helper
INFO - 2018-02-14 12:40:03 --> Helper loaded: common_helper
INFO - 2018-02-14 12:40:03 --> Database Driver Class Initialized
DEBUG - 2018-02-14 12:40:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 12:40:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 12:40:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-14 12:40:03 --> Pagination Class Initialized
INFO - 2018-02-14 12:40:03 --> Helper loaded: form_helper
INFO - 2018-02-14 12:40:03 --> Form Validation Class Initialized
INFO - 2018-02-14 12:40:03 --> Model Class Initialized
INFO - 2018-02-14 12:40:03 --> Controller Class Initialized
INFO - 2018-02-14 12:40:03 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-14 12:40:03 --> Model Class Initialized
INFO - 2018-02-14 12:40:03 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-14 12:40:03 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-14 12:40:03 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-14 12:40:03 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-14 12:40:03 --> File loaded: /var/www/html/project/radio/application/views/category/index.php
INFO - 2018-02-14 12:40:03 --> Final output sent to browser
DEBUG - 2018-02-14 12:40:03 --> Total execution time: 0.0057
INFO - 2018-02-14 12:40:04 --> Config Class Initialized
INFO - 2018-02-14 12:40:04 --> Hooks Class Initialized
DEBUG - 2018-02-14 12:40:04 --> UTF-8 Support Enabled
INFO - 2018-02-14 12:40:04 --> Utf8 Class Initialized
INFO - 2018-02-14 12:40:04 --> URI Class Initialized
INFO - 2018-02-14 12:40:04 --> Router Class Initialized
INFO - 2018-02-14 12:40:04 --> Output Class Initialized
INFO - 2018-02-14 12:40:04 --> Security Class Initialized
DEBUG - 2018-02-14 12:40:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 12:40:04 --> Input Class Initialized
INFO - 2018-02-14 12:40:04 --> Language Class Initialized
INFO - 2018-02-14 12:40:04 --> Loader Class Initialized
INFO - 2018-02-14 12:40:04 --> Helper loaded: url_helper
INFO - 2018-02-14 12:40:04 --> Helper loaded: file_helper
INFO - 2018-02-14 12:40:04 --> Helper loaded: email_helper
INFO - 2018-02-14 12:40:04 --> Helper loaded: common_helper
INFO - 2018-02-14 12:40:04 --> Database Driver Class Initialized
DEBUG - 2018-02-14 12:40:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 12:40:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 12:40:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-14 12:40:04 --> Pagination Class Initialized
INFO - 2018-02-14 12:40:04 --> Helper loaded: form_helper
INFO - 2018-02-14 12:40:04 --> Form Validation Class Initialized
INFO - 2018-02-14 12:40:04 --> Model Class Initialized
INFO - 2018-02-14 12:40:04 --> Controller Class Initialized
INFO - 2018-02-14 12:40:04 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-14 12:40:04 --> Model Class Initialized
INFO - 2018-02-14 12:40:04 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-14 12:40:04 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-14 12:40:04 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-14 12:40:04 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-14 12:40:04 --> File loaded: /var/www/html/project/radio/application/views/category/index.php
INFO - 2018-02-14 12:40:04 --> Final output sent to browser
DEBUG - 2018-02-14 12:40:04 --> Total execution time: 0.0067
INFO - 2018-02-14 12:40:04 --> Config Class Initialized
INFO - 2018-02-14 12:40:04 --> Hooks Class Initialized
DEBUG - 2018-02-14 12:40:04 --> UTF-8 Support Enabled
INFO - 2018-02-14 12:40:04 --> Utf8 Class Initialized
INFO - 2018-02-14 12:40:04 --> URI Class Initialized
INFO - 2018-02-14 12:40:04 --> Router Class Initialized
INFO - 2018-02-14 12:40:04 --> Output Class Initialized
INFO - 2018-02-14 12:40:04 --> Security Class Initialized
DEBUG - 2018-02-14 12:40:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 12:40:04 --> Input Class Initialized
INFO - 2018-02-14 12:40:04 --> Language Class Initialized
INFO - 2018-02-14 12:40:04 --> Loader Class Initialized
INFO - 2018-02-14 12:40:04 --> Helper loaded: url_helper
INFO - 2018-02-14 12:40:04 --> Helper loaded: file_helper
INFO - 2018-02-14 12:40:04 --> Helper loaded: email_helper
INFO - 2018-02-14 12:40:04 --> Helper loaded: common_helper
INFO - 2018-02-14 12:40:04 --> Database Driver Class Initialized
DEBUG - 2018-02-14 12:40:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 12:40:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 12:40:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-14 12:40:04 --> Pagination Class Initialized
INFO - 2018-02-14 12:40:04 --> Helper loaded: form_helper
INFO - 2018-02-14 12:40:04 --> Form Validation Class Initialized
INFO - 2018-02-14 12:40:04 --> Model Class Initialized
INFO - 2018-02-14 12:40:04 --> Controller Class Initialized
INFO - 2018-02-14 12:40:04 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-14 12:40:04 --> Model Class Initialized
INFO - 2018-02-14 12:40:04 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-14 12:40:04 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-14 12:40:04 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-14 12:40:04 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-14 12:40:04 --> File loaded: /var/www/html/project/radio/application/views/category/index.php
INFO - 2018-02-14 12:40:04 --> Final output sent to browser
DEBUG - 2018-02-14 12:40:04 --> Total execution time: 0.0059
INFO - 2018-02-14 12:40:05 --> Config Class Initialized
INFO - 2018-02-14 12:40:05 --> Hooks Class Initialized
DEBUG - 2018-02-14 12:40:05 --> UTF-8 Support Enabled
INFO - 2018-02-14 12:40:05 --> Utf8 Class Initialized
INFO - 2018-02-14 12:40:05 --> URI Class Initialized
INFO - 2018-02-14 12:40:05 --> Router Class Initialized
INFO - 2018-02-14 12:40:05 --> Output Class Initialized
INFO - 2018-02-14 12:40:05 --> Security Class Initialized
DEBUG - 2018-02-14 12:40:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 12:40:05 --> Input Class Initialized
INFO - 2018-02-14 12:40:05 --> Language Class Initialized
INFO - 2018-02-14 12:40:05 --> Loader Class Initialized
INFO - 2018-02-14 12:40:05 --> Helper loaded: url_helper
INFO - 2018-02-14 12:40:05 --> Helper loaded: file_helper
INFO - 2018-02-14 12:40:05 --> Helper loaded: email_helper
INFO - 2018-02-14 12:40:05 --> Helper loaded: common_helper
INFO - 2018-02-14 12:40:05 --> Database Driver Class Initialized
DEBUG - 2018-02-14 12:40:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 12:40:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 12:40:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-14 12:40:05 --> Pagination Class Initialized
INFO - 2018-02-14 12:40:05 --> Helper loaded: form_helper
INFO - 2018-02-14 12:40:05 --> Form Validation Class Initialized
INFO - 2018-02-14 12:40:05 --> Model Class Initialized
INFO - 2018-02-14 12:40:05 --> Controller Class Initialized
INFO - 2018-02-14 12:40:05 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-14 12:40:05 --> Model Class Initialized
INFO - 2018-02-14 12:40:05 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-14 12:40:05 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-14 12:40:05 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-14 12:40:05 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-14 12:40:05 --> File loaded: /var/www/html/project/radio/application/views/category/index.php
INFO - 2018-02-14 12:40:05 --> Final output sent to browser
DEBUG - 2018-02-14 12:40:05 --> Total execution time: 0.0043
INFO - 2018-02-14 12:40:07 --> Config Class Initialized
INFO - 2018-02-14 12:40:07 --> Hooks Class Initialized
DEBUG - 2018-02-14 12:40:07 --> UTF-8 Support Enabled
INFO - 2018-02-14 12:40:07 --> Utf8 Class Initialized
INFO - 2018-02-14 12:40:07 --> URI Class Initialized
INFO - 2018-02-14 12:40:07 --> Router Class Initialized
INFO - 2018-02-14 12:40:07 --> Output Class Initialized
INFO - 2018-02-14 12:40:07 --> Security Class Initialized
DEBUG - 2018-02-14 12:40:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 12:40:07 --> Input Class Initialized
INFO - 2018-02-14 12:40:07 --> Language Class Initialized
INFO - 2018-02-14 12:40:07 --> Loader Class Initialized
INFO - 2018-02-14 12:40:07 --> Helper loaded: url_helper
INFO - 2018-02-14 12:40:07 --> Helper loaded: file_helper
INFO - 2018-02-14 12:40:07 --> Helper loaded: email_helper
INFO - 2018-02-14 12:40:07 --> Helper loaded: common_helper
INFO - 2018-02-14 12:40:07 --> Database Driver Class Initialized
DEBUG - 2018-02-14 12:40:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 12:40:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 12:40:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-14 12:40:07 --> Pagination Class Initialized
INFO - 2018-02-14 12:40:07 --> Helper loaded: form_helper
INFO - 2018-02-14 12:40:07 --> Form Validation Class Initialized
INFO - 2018-02-14 12:40:07 --> Model Class Initialized
INFO - 2018-02-14 12:40:07 --> Controller Class Initialized
INFO - 2018-02-14 12:40:07 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-14 12:40:07 --> Model Class Initialized
INFO - 2018-02-14 12:40:07 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-14 12:40:07 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-14 12:40:07 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-14 12:40:07 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-14 12:40:07 --> File loaded: /var/www/html/project/radio/application/views/category/index.php
INFO - 2018-02-14 12:40:07 --> Final output sent to browser
DEBUG - 2018-02-14 12:40:07 --> Total execution time: 0.0040
INFO - 2018-02-14 12:40:09 --> Config Class Initialized
INFO - 2018-02-14 12:40:09 --> Hooks Class Initialized
DEBUG - 2018-02-14 12:40:09 --> UTF-8 Support Enabled
INFO - 2018-02-14 12:40:09 --> Utf8 Class Initialized
INFO - 2018-02-14 12:40:09 --> URI Class Initialized
INFO - 2018-02-14 12:40:09 --> Router Class Initialized
INFO - 2018-02-14 12:40:09 --> Output Class Initialized
INFO - 2018-02-14 12:40:09 --> Security Class Initialized
DEBUG - 2018-02-14 12:40:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 12:40:09 --> Input Class Initialized
INFO - 2018-02-14 12:40:09 --> Language Class Initialized
INFO - 2018-02-14 12:40:09 --> Loader Class Initialized
INFO - 2018-02-14 12:40:09 --> Helper loaded: url_helper
INFO - 2018-02-14 12:40:09 --> Helper loaded: file_helper
INFO - 2018-02-14 12:40:09 --> Helper loaded: email_helper
INFO - 2018-02-14 12:40:09 --> Helper loaded: common_helper
INFO - 2018-02-14 12:40:09 --> Database Driver Class Initialized
DEBUG - 2018-02-14 12:40:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 12:40:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 12:40:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-14 12:40:09 --> Pagination Class Initialized
INFO - 2018-02-14 12:40:09 --> Helper loaded: form_helper
INFO - 2018-02-14 12:40:09 --> Form Validation Class Initialized
INFO - 2018-02-14 12:40:09 --> Model Class Initialized
INFO - 2018-02-14 12:40:09 --> Controller Class Initialized
INFO - 2018-02-14 12:40:09 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-14 12:40:09 --> Model Class Initialized
INFO - 2018-02-14 12:40:09 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-14 12:40:09 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-14 12:40:09 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-14 12:40:09 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-14 12:40:09 --> File loaded: /var/www/html/project/radio/application/views/user/index.php
INFO - 2018-02-14 12:40:09 --> Final output sent to browser
DEBUG - 2018-02-14 12:40:09 --> Total execution time: 0.0064
INFO - 2018-02-14 12:40:09 --> Config Class Initialized
INFO - 2018-02-14 12:40:09 --> Hooks Class Initialized
DEBUG - 2018-02-14 12:40:09 --> UTF-8 Support Enabled
INFO - 2018-02-14 12:40:09 --> Utf8 Class Initialized
INFO - 2018-02-14 12:40:09 --> URI Class Initialized
INFO - 2018-02-14 12:40:09 --> Router Class Initialized
INFO - 2018-02-14 12:40:09 --> Output Class Initialized
INFO - 2018-02-14 12:40:09 --> Security Class Initialized
DEBUG - 2018-02-14 12:40:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 12:40:09 --> Input Class Initialized
INFO - 2018-02-14 12:40:09 --> Language Class Initialized
INFO - 2018-02-14 12:40:09 --> Loader Class Initialized
INFO - 2018-02-14 12:40:09 --> Helper loaded: url_helper
INFO - 2018-02-14 12:40:09 --> Helper loaded: file_helper
INFO - 2018-02-14 12:40:09 --> Helper loaded: email_helper
INFO - 2018-02-14 12:40:09 --> Helper loaded: common_helper
INFO - 2018-02-14 12:40:09 --> Database Driver Class Initialized
DEBUG - 2018-02-14 12:40:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 12:40:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 12:40:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-14 12:40:09 --> Pagination Class Initialized
INFO - 2018-02-14 12:40:09 --> Helper loaded: form_helper
INFO - 2018-02-14 12:40:09 --> Form Validation Class Initialized
INFO - 2018-02-14 12:40:09 --> Model Class Initialized
INFO - 2018-02-14 12:40:09 --> Controller Class Initialized
INFO - 2018-02-14 12:40:09 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-14 12:40:09 --> Model Class Initialized
INFO - 2018-02-14 12:40:41 --> Config Class Initialized
INFO - 2018-02-14 12:40:41 --> Hooks Class Initialized
DEBUG - 2018-02-14 12:40:41 --> UTF-8 Support Enabled
INFO - 2018-02-14 12:40:41 --> Utf8 Class Initialized
INFO - 2018-02-14 12:40:41 --> URI Class Initialized
INFO - 2018-02-14 12:40:41 --> Router Class Initialized
INFO - 2018-02-14 12:40:41 --> Output Class Initialized
INFO - 2018-02-14 12:40:41 --> Security Class Initialized
DEBUG - 2018-02-14 12:40:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 12:40:41 --> Input Class Initialized
INFO - 2018-02-14 12:40:41 --> Language Class Initialized
INFO - 2018-02-14 12:40:41 --> Loader Class Initialized
INFO - 2018-02-14 12:40:41 --> Helper loaded: url_helper
INFO - 2018-02-14 12:40:41 --> Helper loaded: file_helper
INFO - 2018-02-14 12:40:41 --> Helper loaded: email_helper
INFO - 2018-02-14 12:40:41 --> Helper loaded: common_helper
INFO - 2018-02-14 12:40:41 --> Database Driver Class Initialized
DEBUG - 2018-02-14 12:40:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 12:40:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 12:40:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-14 12:40:41 --> Pagination Class Initialized
INFO - 2018-02-14 12:40:41 --> Helper loaded: form_helper
INFO - 2018-02-14 12:40:41 --> Form Validation Class Initialized
INFO - 2018-02-14 12:40:41 --> Model Class Initialized
INFO - 2018-02-14 12:40:41 --> Controller Class Initialized
INFO - 2018-02-14 12:40:41 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-14 12:40:41 --> Model Class Initialized
INFO - 2018-02-14 12:40:41 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-14 12:40:41 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-14 12:40:41 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-14 12:40:41 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-14 12:40:41 --> File loaded: /var/www/html/project/radio/application/views/user/index.php
INFO - 2018-02-14 12:40:41 --> Final output sent to browser
DEBUG - 2018-02-14 12:40:41 --> Total execution time: 0.0100
INFO - 2018-02-14 12:40:42 --> Config Class Initialized
INFO - 2018-02-14 12:40:42 --> Hooks Class Initialized
DEBUG - 2018-02-14 12:40:42 --> UTF-8 Support Enabled
INFO - 2018-02-14 12:40:42 --> Utf8 Class Initialized
INFO - 2018-02-14 12:40:42 --> URI Class Initialized
INFO - 2018-02-14 12:40:42 --> Router Class Initialized
INFO - 2018-02-14 12:40:42 --> Output Class Initialized
INFO - 2018-02-14 12:40:42 --> Security Class Initialized
DEBUG - 2018-02-14 12:40:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 12:40:42 --> Input Class Initialized
INFO - 2018-02-14 12:40:42 --> Language Class Initialized
INFO - 2018-02-14 12:40:42 --> Loader Class Initialized
INFO - 2018-02-14 12:40:42 --> Helper loaded: url_helper
INFO - 2018-02-14 12:40:42 --> Helper loaded: file_helper
INFO - 2018-02-14 12:40:42 --> Helper loaded: email_helper
INFO - 2018-02-14 12:40:42 --> Helper loaded: common_helper
INFO - 2018-02-14 12:40:42 --> Database Driver Class Initialized
DEBUG - 2018-02-14 12:40:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 12:40:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 12:40:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-14 12:40:42 --> Pagination Class Initialized
INFO - 2018-02-14 12:40:42 --> Helper loaded: form_helper
INFO - 2018-02-14 12:40:42 --> Form Validation Class Initialized
INFO - 2018-02-14 12:40:42 --> Model Class Initialized
INFO - 2018-02-14 12:40:42 --> Controller Class Initialized
INFO - 2018-02-14 12:40:42 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-14 12:40:42 --> Model Class Initialized
INFO - 2018-02-14 12:40:43 --> Config Class Initialized
INFO - 2018-02-14 12:40:43 --> Hooks Class Initialized
DEBUG - 2018-02-14 12:40:43 --> UTF-8 Support Enabled
INFO - 2018-02-14 12:40:43 --> Utf8 Class Initialized
INFO - 2018-02-14 12:40:43 --> URI Class Initialized
INFO - 2018-02-14 12:40:43 --> Router Class Initialized
INFO - 2018-02-14 12:40:43 --> Output Class Initialized
INFO - 2018-02-14 12:40:43 --> Security Class Initialized
DEBUG - 2018-02-14 12:40:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 12:40:43 --> Input Class Initialized
INFO - 2018-02-14 12:40:43 --> Language Class Initialized
INFO - 2018-02-14 12:40:43 --> Loader Class Initialized
INFO - 2018-02-14 12:40:43 --> Helper loaded: url_helper
INFO - 2018-02-14 12:40:43 --> Helper loaded: file_helper
INFO - 2018-02-14 12:40:43 --> Helper loaded: email_helper
INFO - 2018-02-14 12:40:43 --> Helper loaded: common_helper
INFO - 2018-02-14 12:40:43 --> Database Driver Class Initialized
DEBUG - 2018-02-14 12:40:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 12:40:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 12:40:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-14 12:40:43 --> Pagination Class Initialized
INFO - 2018-02-14 12:40:43 --> Helper loaded: form_helper
INFO - 2018-02-14 12:40:43 --> Form Validation Class Initialized
INFO - 2018-02-14 12:40:43 --> Model Class Initialized
INFO - 2018-02-14 12:40:43 --> Controller Class Initialized
INFO - 2018-02-14 12:40:43 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-14 12:40:43 --> Model Class Initialized
INFO - 2018-02-14 12:40:43 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-14 12:40:43 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-14 12:40:43 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-14 12:40:43 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-14 12:40:43 --> File loaded: /var/www/html/project/radio/application/views/category/index.php
INFO - 2018-02-14 12:40:43 --> Final output sent to browser
DEBUG - 2018-02-14 12:40:43 --> Total execution time: 0.0080
INFO - 2018-02-14 12:40:45 --> Config Class Initialized
INFO - 2018-02-14 12:40:45 --> Hooks Class Initialized
DEBUG - 2018-02-14 12:40:45 --> UTF-8 Support Enabled
INFO - 2018-02-14 12:40:45 --> Utf8 Class Initialized
INFO - 2018-02-14 12:40:45 --> URI Class Initialized
INFO - 2018-02-14 12:40:45 --> Router Class Initialized
INFO - 2018-02-14 12:40:45 --> Output Class Initialized
INFO - 2018-02-14 12:40:45 --> Security Class Initialized
DEBUG - 2018-02-14 12:40:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 12:40:45 --> Input Class Initialized
INFO - 2018-02-14 12:40:45 --> Language Class Initialized
INFO - 2018-02-14 12:40:45 --> Loader Class Initialized
INFO - 2018-02-14 12:40:45 --> Helper loaded: url_helper
INFO - 2018-02-14 12:40:45 --> Helper loaded: file_helper
INFO - 2018-02-14 12:40:45 --> Helper loaded: email_helper
INFO - 2018-02-14 12:40:45 --> Helper loaded: common_helper
INFO - 2018-02-14 12:40:45 --> Database Driver Class Initialized
DEBUG - 2018-02-14 12:40:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 12:40:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 12:40:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-14 12:40:45 --> Pagination Class Initialized
INFO - 2018-02-14 12:40:45 --> Helper loaded: form_helper
INFO - 2018-02-14 12:40:45 --> Form Validation Class Initialized
INFO - 2018-02-14 12:40:45 --> Model Class Initialized
INFO - 2018-02-14 12:40:45 --> Controller Class Initialized
INFO - 2018-02-14 12:40:45 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-14 12:40:45 --> Model Class Initialized
INFO - 2018-02-14 12:40:45 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-14 12:40:45 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-14 12:40:45 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-14 12:40:45 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-14 12:40:45 --> File loaded: /var/www/html/project/radio/application/views/category/add_edit.php
INFO - 2018-02-14 12:40:45 --> Final output sent to browser
DEBUG - 2018-02-14 12:40:45 --> Total execution time: 0.0054
INFO - 2018-02-14 12:48:00 --> Config Class Initialized
INFO - 2018-02-14 12:48:00 --> Hooks Class Initialized
DEBUG - 2018-02-14 12:48:00 --> UTF-8 Support Enabled
INFO - 2018-02-14 12:48:00 --> Utf8 Class Initialized
INFO - 2018-02-14 12:48:00 --> URI Class Initialized
INFO - 2018-02-14 12:48:00 --> Router Class Initialized
INFO - 2018-02-14 12:48:00 --> Output Class Initialized
INFO - 2018-02-14 12:48:00 --> Security Class Initialized
DEBUG - 2018-02-14 12:48:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 12:48:00 --> Input Class Initialized
INFO - 2018-02-14 12:48:00 --> Language Class Initialized
INFO - 2018-02-14 12:48:00 --> Loader Class Initialized
INFO - 2018-02-14 12:48:00 --> Helper loaded: url_helper
INFO - 2018-02-14 12:48:00 --> Helper loaded: file_helper
INFO - 2018-02-14 12:48:00 --> Helper loaded: email_helper
INFO - 2018-02-14 12:48:00 --> Helper loaded: common_helper
INFO - 2018-02-14 12:48:00 --> Database Driver Class Initialized
DEBUG - 2018-02-14 12:48:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 12:48:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 12:48:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-14 12:48:00 --> Pagination Class Initialized
INFO - 2018-02-14 12:48:00 --> Helper loaded: form_helper
INFO - 2018-02-14 12:48:00 --> Form Validation Class Initialized
INFO - 2018-02-14 12:48:00 --> Model Class Initialized
INFO - 2018-02-14 12:48:00 --> Controller Class Initialized
INFO - 2018-02-14 12:48:00 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-14 12:48:00 --> Model Class Initialized
INFO - 2018-02-14 12:48:00 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-14 12:48:00 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-14 12:48:00 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-14 12:48:00 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-14 12:48:00 --> File loaded: /var/www/html/project/radio/application/views/category/add_edit.php
INFO - 2018-02-14 12:48:00 --> Final output sent to browser
DEBUG - 2018-02-14 12:48:00 --> Total execution time: 0.0065
INFO - 2018-02-14 12:48:14 --> Config Class Initialized
INFO - 2018-02-14 12:48:14 --> Hooks Class Initialized
DEBUG - 2018-02-14 12:48:14 --> UTF-8 Support Enabled
INFO - 2018-02-14 12:48:14 --> Utf8 Class Initialized
INFO - 2018-02-14 12:48:14 --> URI Class Initialized
INFO - 2018-02-14 12:48:14 --> Router Class Initialized
INFO - 2018-02-14 12:48:14 --> Output Class Initialized
INFO - 2018-02-14 12:48:14 --> Security Class Initialized
DEBUG - 2018-02-14 12:48:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 12:48:14 --> Input Class Initialized
INFO - 2018-02-14 12:48:14 --> Language Class Initialized
INFO - 2018-02-14 12:48:14 --> Loader Class Initialized
INFO - 2018-02-14 12:48:14 --> Helper loaded: url_helper
INFO - 2018-02-14 12:48:14 --> Helper loaded: file_helper
INFO - 2018-02-14 12:48:14 --> Helper loaded: email_helper
INFO - 2018-02-14 12:48:14 --> Helper loaded: common_helper
INFO - 2018-02-14 12:48:14 --> Database Driver Class Initialized
DEBUG - 2018-02-14 12:48:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 12:48:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 12:48:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-14 12:48:14 --> Pagination Class Initialized
INFO - 2018-02-14 12:48:14 --> Helper loaded: form_helper
INFO - 2018-02-14 12:48:14 --> Form Validation Class Initialized
INFO - 2018-02-14 12:48:14 --> Model Class Initialized
INFO - 2018-02-14 12:48:14 --> Controller Class Initialized
INFO - 2018-02-14 12:48:14 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-14 12:48:14 --> Model Class Initialized
INFO - 2018-02-14 12:48:14 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-14 12:48:14 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-14 12:48:14 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-14 12:48:14 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-14 12:48:14 --> File loaded: /var/www/html/project/radio/application/views/category/add_edit.php
INFO - 2018-02-14 12:48:14 --> Final output sent to browser
DEBUG - 2018-02-14 12:48:14 --> Total execution time: 0.0050
INFO - 2018-02-14 12:53:38 --> Config Class Initialized
INFO - 2018-02-14 12:53:38 --> Hooks Class Initialized
DEBUG - 2018-02-14 12:53:38 --> UTF-8 Support Enabled
INFO - 2018-02-14 12:53:38 --> Utf8 Class Initialized
INFO - 2018-02-14 12:53:38 --> URI Class Initialized
INFO - 2018-02-14 12:53:38 --> Router Class Initialized
INFO - 2018-02-14 12:53:38 --> Output Class Initialized
INFO - 2018-02-14 12:53:38 --> Security Class Initialized
DEBUG - 2018-02-14 12:53:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 12:53:38 --> Input Class Initialized
INFO - 2018-02-14 12:53:38 --> Language Class Initialized
INFO - 2018-02-14 12:53:38 --> Loader Class Initialized
INFO - 2018-02-14 12:53:38 --> Helper loaded: url_helper
INFO - 2018-02-14 12:53:38 --> Helper loaded: file_helper
INFO - 2018-02-14 12:53:38 --> Helper loaded: email_helper
INFO - 2018-02-14 12:53:38 --> Helper loaded: common_helper
INFO - 2018-02-14 12:53:38 --> Database Driver Class Initialized
DEBUG - 2018-02-14 12:53:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 12:53:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 12:53:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-14 12:53:38 --> Pagination Class Initialized
INFO - 2018-02-14 12:53:38 --> Helper loaded: form_helper
INFO - 2018-02-14 12:53:38 --> Form Validation Class Initialized
INFO - 2018-02-14 12:53:38 --> Model Class Initialized
INFO - 2018-02-14 12:53:38 --> Controller Class Initialized
INFO - 2018-02-14 12:53:38 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-14 12:53:38 --> Model Class Initialized
INFO - 2018-02-14 12:53:38 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-14 12:53:38 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-14 12:53:38 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-14 12:53:38 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-14 12:53:38 --> File loaded: /var/www/html/project/radio/application/views/category/add_edit.php
INFO - 2018-02-14 12:53:38 --> Final output sent to browser
DEBUG - 2018-02-14 12:53:38 --> Total execution time: 0.0060
INFO - 2018-02-14 12:54:34 --> Config Class Initialized
INFO - 2018-02-14 12:54:34 --> Hooks Class Initialized
DEBUG - 2018-02-14 12:54:34 --> UTF-8 Support Enabled
INFO - 2018-02-14 12:54:34 --> Utf8 Class Initialized
INFO - 2018-02-14 12:54:34 --> URI Class Initialized
INFO - 2018-02-14 12:54:34 --> Router Class Initialized
INFO - 2018-02-14 12:54:34 --> Output Class Initialized
INFO - 2018-02-14 12:54:34 --> Security Class Initialized
DEBUG - 2018-02-14 12:54:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 12:54:34 --> Input Class Initialized
INFO - 2018-02-14 12:54:34 --> Language Class Initialized
INFO - 2018-02-14 12:54:34 --> Loader Class Initialized
INFO - 2018-02-14 12:54:34 --> Helper loaded: url_helper
INFO - 2018-02-14 12:54:34 --> Helper loaded: file_helper
INFO - 2018-02-14 12:54:34 --> Helper loaded: email_helper
INFO - 2018-02-14 12:54:34 --> Helper loaded: common_helper
INFO - 2018-02-14 12:54:34 --> Database Driver Class Initialized
DEBUG - 2018-02-14 12:54:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 12:54:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 12:54:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-14 12:54:34 --> Pagination Class Initialized
INFO - 2018-02-14 12:54:34 --> Helper loaded: form_helper
INFO - 2018-02-14 12:54:34 --> Form Validation Class Initialized
INFO - 2018-02-14 12:54:34 --> Model Class Initialized
INFO - 2018-02-14 12:54:34 --> Controller Class Initialized
INFO - 2018-02-14 12:54:34 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-14 12:54:34 --> Model Class Initialized
INFO - 2018-02-14 12:54:34 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-14 12:54:34 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-14 12:54:34 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-14 12:54:34 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-14 12:54:34 --> File loaded: /var/www/html/project/radio/application/views/category/add_edit.php
INFO - 2018-02-14 12:54:34 --> Final output sent to browser
DEBUG - 2018-02-14 12:54:34 --> Total execution time: 0.0046
INFO - 2018-02-14 12:55:46 --> Config Class Initialized
INFO - 2018-02-14 12:55:46 --> Hooks Class Initialized
DEBUG - 2018-02-14 12:55:46 --> UTF-8 Support Enabled
INFO - 2018-02-14 12:55:46 --> Utf8 Class Initialized
INFO - 2018-02-14 12:55:46 --> URI Class Initialized
INFO - 2018-02-14 12:55:46 --> Router Class Initialized
INFO - 2018-02-14 12:55:46 --> Output Class Initialized
INFO - 2018-02-14 12:55:46 --> Security Class Initialized
DEBUG - 2018-02-14 12:55:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 12:55:46 --> Input Class Initialized
INFO - 2018-02-14 12:55:46 --> Language Class Initialized
INFO - 2018-02-14 12:55:46 --> Loader Class Initialized
INFO - 2018-02-14 12:55:46 --> Helper loaded: url_helper
INFO - 2018-02-14 12:55:46 --> Helper loaded: file_helper
INFO - 2018-02-14 12:55:46 --> Helper loaded: email_helper
INFO - 2018-02-14 12:55:46 --> Helper loaded: common_helper
INFO - 2018-02-14 12:55:46 --> Database Driver Class Initialized
DEBUG - 2018-02-14 12:55:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 12:55:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 12:55:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-14 12:55:46 --> Pagination Class Initialized
INFO - 2018-02-14 12:55:46 --> Helper loaded: form_helper
INFO - 2018-02-14 12:55:46 --> Form Validation Class Initialized
INFO - 2018-02-14 12:55:46 --> Model Class Initialized
INFO - 2018-02-14 12:55:46 --> Controller Class Initialized
INFO - 2018-02-14 12:55:46 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-14 12:55:46 --> Model Class Initialized
INFO - 2018-02-14 12:55:46 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-14 12:55:46 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-14 12:55:46 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-14 12:55:46 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-14 12:55:46 --> File loaded: /var/www/html/project/radio/application/views/category/add_edit.php
INFO - 2018-02-14 12:55:46 --> Final output sent to browser
DEBUG - 2018-02-14 12:55:46 --> Total execution time: 0.0085
INFO - 2018-02-14 13:01:47 --> Config Class Initialized
INFO - 2018-02-14 13:01:47 --> Hooks Class Initialized
DEBUG - 2018-02-14 13:01:47 --> UTF-8 Support Enabled
INFO - 2018-02-14 13:01:47 --> Utf8 Class Initialized
INFO - 2018-02-14 13:01:47 --> URI Class Initialized
INFO - 2018-02-14 13:01:47 --> Router Class Initialized
INFO - 2018-02-14 13:01:47 --> Output Class Initialized
INFO - 2018-02-14 13:01:47 --> Security Class Initialized
DEBUG - 2018-02-14 13:01:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 13:01:47 --> Input Class Initialized
INFO - 2018-02-14 13:01:47 --> Language Class Initialized
INFO - 2018-02-14 13:01:47 --> Loader Class Initialized
INFO - 2018-02-14 13:01:47 --> Helper loaded: url_helper
INFO - 2018-02-14 13:01:47 --> Helper loaded: file_helper
INFO - 2018-02-14 13:01:47 --> Helper loaded: email_helper
INFO - 2018-02-14 13:01:47 --> Helper loaded: common_helper
INFO - 2018-02-14 13:01:47 --> Database Driver Class Initialized
DEBUG - 2018-02-14 13:01:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 13:01:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 13:01:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-14 13:01:47 --> Pagination Class Initialized
INFO - 2018-02-14 13:01:47 --> Helper loaded: form_helper
INFO - 2018-02-14 13:01:47 --> Form Validation Class Initialized
INFO - 2018-02-14 13:01:47 --> Model Class Initialized
INFO - 2018-02-14 13:01:47 --> Controller Class Initialized
INFO - 2018-02-14 13:01:47 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-14 13:01:47 --> Model Class Initialized
INFO - 2018-02-14 13:01:47 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-14 13:01:47 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-14 13:01:47 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-14 13:01:47 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-14 13:01:47 --> File loaded: /var/www/html/project/radio/application/views/category/add_edit.php
INFO - 2018-02-14 13:01:47 --> Final output sent to browser
DEBUG - 2018-02-14 13:01:47 --> Total execution time: 0.0045
INFO - 2018-02-14 13:03:09 --> Config Class Initialized
INFO - 2018-02-14 13:03:09 --> Hooks Class Initialized
DEBUG - 2018-02-14 13:03:09 --> UTF-8 Support Enabled
INFO - 2018-02-14 13:03:09 --> Utf8 Class Initialized
INFO - 2018-02-14 13:03:09 --> URI Class Initialized
INFO - 2018-02-14 13:03:09 --> Router Class Initialized
INFO - 2018-02-14 13:03:09 --> Output Class Initialized
INFO - 2018-02-14 13:03:09 --> Security Class Initialized
DEBUG - 2018-02-14 13:03:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 13:03:09 --> Input Class Initialized
INFO - 2018-02-14 13:03:09 --> Language Class Initialized
INFO - 2018-02-14 13:03:09 --> Loader Class Initialized
INFO - 2018-02-14 13:03:09 --> Helper loaded: url_helper
INFO - 2018-02-14 13:03:09 --> Helper loaded: file_helper
INFO - 2018-02-14 13:03:09 --> Helper loaded: email_helper
INFO - 2018-02-14 13:03:09 --> Helper loaded: common_helper
INFO - 2018-02-14 13:03:09 --> Database Driver Class Initialized
DEBUG - 2018-02-14 13:03:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 13:03:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 13:03:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-14 13:03:09 --> Pagination Class Initialized
INFO - 2018-02-14 13:03:09 --> Helper loaded: form_helper
INFO - 2018-02-14 13:03:09 --> Form Validation Class Initialized
INFO - 2018-02-14 13:03:09 --> Model Class Initialized
INFO - 2018-02-14 13:03:09 --> Controller Class Initialized
INFO - 2018-02-14 13:03:09 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-14 13:03:09 --> Model Class Initialized
INFO - 2018-02-14 13:03:09 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-14 13:03:09 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-14 13:03:09 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-14 13:03:09 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-14 13:03:09 --> File loaded: /var/www/html/project/radio/application/views/category/add_edit.php
INFO - 2018-02-14 13:03:09 --> Final output sent to browser
DEBUG - 2018-02-14 13:03:09 --> Total execution time: 0.0042
INFO - 2018-02-14 13:03:17 --> Config Class Initialized
INFO - 2018-02-14 13:03:17 --> Hooks Class Initialized
DEBUG - 2018-02-14 13:03:17 --> UTF-8 Support Enabled
INFO - 2018-02-14 13:03:17 --> Utf8 Class Initialized
INFO - 2018-02-14 13:03:17 --> URI Class Initialized
INFO - 2018-02-14 13:03:17 --> Router Class Initialized
INFO - 2018-02-14 13:03:17 --> Output Class Initialized
INFO - 2018-02-14 13:03:17 --> Security Class Initialized
DEBUG - 2018-02-14 13:03:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 13:03:17 --> Input Class Initialized
INFO - 2018-02-14 13:03:17 --> Language Class Initialized
INFO - 2018-02-14 13:03:17 --> Loader Class Initialized
INFO - 2018-02-14 13:03:17 --> Helper loaded: url_helper
INFO - 2018-02-14 13:03:17 --> Helper loaded: file_helper
INFO - 2018-02-14 13:03:17 --> Helper loaded: email_helper
INFO - 2018-02-14 13:03:17 --> Helper loaded: common_helper
INFO - 2018-02-14 13:03:17 --> Database Driver Class Initialized
DEBUG - 2018-02-14 13:03:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 13:03:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 13:03:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-14 13:03:17 --> Pagination Class Initialized
INFO - 2018-02-14 13:03:17 --> Helper loaded: form_helper
INFO - 2018-02-14 13:03:17 --> Form Validation Class Initialized
INFO - 2018-02-14 13:03:17 --> Model Class Initialized
INFO - 2018-02-14 13:03:17 --> Controller Class Initialized
INFO - 2018-02-14 13:03:17 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-14 13:03:17 --> Model Class Initialized
INFO - 2018-02-14 13:03:17 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-14 13:03:17 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-14 13:03:17 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-14 13:03:17 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-14 13:03:17 --> File loaded: /var/www/html/project/radio/application/views/category/add_edit.php
INFO - 2018-02-14 13:03:17 --> Final output sent to browser
DEBUG - 2018-02-14 13:03:17 --> Total execution time: 0.0044
INFO - 2018-02-14 13:05:46 --> Config Class Initialized
INFO - 2018-02-14 13:05:46 --> Hooks Class Initialized
DEBUG - 2018-02-14 13:05:46 --> UTF-8 Support Enabled
INFO - 2018-02-14 13:05:46 --> Utf8 Class Initialized
INFO - 2018-02-14 13:05:46 --> URI Class Initialized
INFO - 2018-02-14 13:05:46 --> Router Class Initialized
INFO - 2018-02-14 13:05:46 --> Output Class Initialized
INFO - 2018-02-14 13:05:46 --> Security Class Initialized
DEBUG - 2018-02-14 13:05:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 13:05:46 --> Input Class Initialized
INFO - 2018-02-14 13:05:46 --> Language Class Initialized
INFO - 2018-02-14 13:05:46 --> Loader Class Initialized
INFO - 2018-02-14 13:05:46 --> Helper loaded: url_helper
INFO - 2018-02-14 13:05:46 --> Helper loaded: file_helper
INFO - 2018-02-14 13:05:46 --> Helper loaded: email_helper
INFO - 2018-02-14 13:05:46 --> Helper loaded: common_helper
INFO - 2018-02-14 13:05:46 --> Database Driver Class Initialized
DEBUG - 2018-02-14 13:05:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 13:05:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 13:05:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-14 13:05:46 --> Pagination Class Initialized
INFO - 2018-02-14 13:05:46 --> Helper loaded: form_helper
INFO - 2018-02-14 13:05:46 --> Form Validation Class Initialized
INFO - 2018-02-14 13:05:46 --> Model Class Initialized
INFO - 2018-02-14 13:05:46 --> Controller Class Initialized
INFO - 2018-02-14 13:05:46 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-14 13:05:46 --> Model Class Initialized
INFO - 2018-02-14 13:05:46 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-14 13:05:46 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-14 13:05:46 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-14 13:05:46 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-14 13:05:46 --> File loaded: /var/www/html/project/radio/application/views/category/add_edit.php
INFO - 2018-02-14 13:05:46 --> Final output sent to browser
DEBUG - 2018-02-14 13:05:46 --> Total execution time: 0.0064
INFO - 2018-02-14 13:11:36 --> Config Class Initialized
INFO - 2018-02-14 13:11:36 --> Hooks Class Initialized
DEBUG - 2018-02-14 13:11:36 --> UTF-8 Support Enabled
INFO - 2018-02-14 13:11:36 --> Utf8 Class Initialized
INFO - 2018-02-14 13:11:36 --> URI Class Initialized
INFO - 2018-02-14 13:11:36 --> Router Class Initialized
INFO - 2018-02-14 13:11:36 --> Output Class Initialized
INFO - 2018-02-14 13:11:36 --> Security Class Initialized
DEBUG - 2018-02-14 13:11:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 13:11:36 --> Input Class Initialized
INFO - 2018-02-14 13:11:36 --> Language Class Initialized
INFO - 2018-02-14 13:11:36 --> Loader Class Initialized
INFO - 2018-02-14 13:11:36 --> Helper loaded: url_helper
INFO - 2018-02-14 13:11:36 --> Helper loaded: file_helper
INFO - 2018-02-14 13:11:36 --> Helper loaded: email_helper
INFO - 2018-02-14 13:11:36 --> Helper loaded: common_helper
INFO - 2018-02-14 13:11:36 --> Database Driver Class Initialized
DEBUG - 2018-02-14 13:11:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 13:11:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 13:11:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-14 13:11:36 --> Pagination Class Initialized
INFO - 2018-02-14 13:11:36 --> Helper loaded: form_helper
INFO - 2018-02-14 13:11:36 --> Form Validation Class Initialized
INFO - 2018-02-14 13:11:36 --> Model Class Initialized
INFO - 2018-02-14 13:11:36 --> Controller Class Initialized
INFO - 2018-02-14 13:11:36 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-14 13:11:36 --> Model Class Initialized
INFO - 2018-02-14 13:11:36 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-14 13:11:36 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-14 13:11:36 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-14 13:11:36 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-14 13:11:36 --> File loaded: /var/www/html/project/radio/application/views/category/add_edit.php
INFO - 2018-02-14 13:11:36 --> Final output sent to browser
DEBUG - 2018-02-14 13:11:36 --> Total execution time: 0.0056
INFO - 2018-02-14 13:12:02 --> Config Class Initialized
INFO - 2018-02-14 13:12:02 --> Hooks Class Initialized
DEBUG - 2018-02-14 13:12:02 --> UTF-8 Support Enabled
INFO - 2018-02-14 13:12:02 --> Utf8 Class Initialized
INFO - 2018-02-14 13:12:02 --> URI Class Initialized
INFO - 2018-02-14 13:12:02 --> Router Class Initialized
INFO - 2018-02-14 13:12:02 --> Output Class Initialized
INFO - 2018-02-14 13:12:02 --> Security Class Initialized
DEBUG - 2018-02-14 13:12:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 13:12:02 --> Input Class Initialized
INFO - 2018-02-14 13:12:02 --> Language Class Initialized
INFO - 2018-02-14 13:12:02 --> Loader Class Initialized
INFO - 2018-02-14 13:12:02 --> Helper loaded: url_helper
INFO - 2018-02-14 13:12:02 --> Helper loaded: file_helper
INFO - 2018-02-14 13:12:02 --> Helper loaded: email_helper
INFO - 2018-02-14 13:12:02 --> Helper loaded: common_helper
INFO - 2018-02-14 13:12:02 --> Database Driver Class Initialized
DEBUG - 2018-02-14 13:12:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 13:12:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 13:12:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-14 13:12:02 --> Pagination Class Initialized
INFO - 2018-02-14 13:12:02 --> Helper loaded: form_helper
INFO - 2018-02-14 13:12:02 --> Form Validation Class Initialized
INFO - 2018-02-14 13:12:02 --> Model Class Initialized
INFO - 2018-02-14 13:12:02 --> Controller Class Initialized
INFO - 2018-02-14 13:12:02 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-14 13:12:02 --> Model Class Initialized
INFO - 2018-02-14 13:12:02 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-14 13:12:02 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-14 13:12:02 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-14 13:12:02 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-14 13:12:02 --> File loaded: /var/www/html/project/radio/application/views/category/add_edit.php
INFO - 2018-02-14 13:12:02 --> Final output sent to browser
DEBUG - 2018-02-14 13:12:02 --> Total execution time: 0.0045
INFO - 2018-02-14 13:14:18 --> Config Class Initialized
INFO - 2018-02-14 13:14:18 --> Hooks Class Initialized
DEBUG - 2018-02-14 13:14:18 --> UTF-8 Support Enabled
INFO - 2018-02-14 13:14:18 --> Utf8 Class Initialized
INFO - 2018-02-14 13:14:18 --> URI Class Initialized
INFO - 2018-02-14 13:14:18 --> Router Class Initialized
INFO - 2018-02-14 13:14:18 --> Output Class Initialized
INFO - 2018-02-14 13:14:18 --> Security Class Initialized
DEBUG - 2018-02-14 13:14:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 13:14:18 --> Input Class Initialized
INFO - 2018-02-14 13:14:18 --> Language Class Initialized
INFO - 2018-02-14 13:14:18 --> Loader Class Initialized
INFO - 2018-02-14 13:14:18 --> Helper loaded: url_helper
INFO - 2018-02-14 13:14:18 --> Helper loaded: file_helper
INFO - 2018-02-14 13:14:18 --> Helper loaded: email_helper
INFO - 2018-02-14 13:14:18 --> Helper loaded: common_helper
INFO - 2018-02-14 13:14:18 --> Database Driver Class Initialized
DEBUG - 2018-02-14 13:14:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 13:14:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 13:14:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-14 13:14:18 --> Pagination Class Initialized
INFO - 2018-02-14 13:14:18 --> Helper loaded: form_helper
INFO - 2018-02-14 13:14:18 --> Form Validation Class Initialized
INFO - 2018-02-14 13:14:18 --> Model Class Initialized
INFO - 2018-02-14 13:14:18 --> Controller Class Initialized
INFO - 2018-02-14 13:14:18 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-14 13:14:18 --> Model Class Initialized
INFO - 2018-02-14 13:16:46 --> Config Class Initialized
INFO - 2018-02-14 13:16:46 --> Hooks Class Initialized
DEBUG - 2018-02-14 13:16:46 --> UTF-8 Support Enabled
INFO - 2018-02-14 13:16:46 --> Utf8 Class Initialized
INFO - 2018-02-14 13:16:46 --> URI Class Initialized
INFO - 2018-02-14 13:16:46 --> Router Class Initialized
INFO - 2018-02-14 13:16:46 --> Output Class Initialized
INFO - 2018-02-14 13:16:46 --> Security Class Initialized
DEBUG - 2018-02-14 13:16:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 13:16:46 --> Input Class Initialized
INFO - 2018-02-14 13:16:46 --> Language Class Initialized
INFO - 2018-02-14 13:16:46 --> Loader Class Initialized
INFO - 2018-02-14 13:16:46 --> Helper loaded: url_helper
INFO - 2018-02-14 13:16:46 --> Helper loaded: file_helper
INFO - 2018-02-14 13:16:46 --> Helper loaded: email_helper
INFO - 2018-02-14 13:16:46 --> Helper loaded: common_helper
INFO - 2018-02-14 13:16:46 --> Database Driver Class Initialized
DEBUG - 2018-02-14 13:16:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 13:16:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 13:16:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-14 13:16:46 --> Pagination Class Initialized
INFO - 2018-02-14 13:16:46 --> Helper loaded: form_helper
INFO - 2018-02-14 13:16:46 --> Form Validation Class Initialized
INFO - 2018-02-14 13:16:46 --> Model Class Initialized
INFO - 2018-02-14 13:16:46 --> Controller Class Initialized
INFO - 2018-02-14 13:16:46 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-14 13:16:46 --> Model Class Initialized
INFO - 2018-02-14 13:16:46 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-14 13:16:46 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-14 13:16:46 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-14 13:16:46 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-14 13:16:46 --> File loaded: /var/www/html/project/radio/application/views/category/add_edit.php
INFO - 2018-02-14 13:16:46 --> Final output sent to browser
DEBUG - 2018-02-14 13:16:46 --> Total execution time: 0.0056
INFO - 2018-02-14 13:26:52 --> Config Class Initialized
INFO - 2018-02-14 13:26:52 --> Hooks Class Initialized
DEBUG - 2018-02-14 13:26:52 --> UTF-8 Support Enabled
INFO - 2018-02-14 13:26:52 --> Utf8 Class Initialized
INFO - 2018-02-14 13:26:52 --> URI Class Initialized
INFO - 2018-02-14 13:26:52 --> Router Class Initialized
INFO - 2018-02-14 13:26:52 --> Output Class Initialized
INFO - 2018-02-14 13:26:52 --> Security Class Initialized
DEBUG - 2018-02-14 13:26:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 13:26:52 --> Input Class Initialized
INFO - 2018-02-14 13:26:52 --> Language Class Initialized
INFO - 2018-02-14 13:26:52 --> Loader Class Initialized
INFO - 2018-02-14 13:26:52 --> Helper loaded: url_helper
INFO - 2018-02-14 13:26:52 --> Helper loaded: file_helper
INFO - 2018-02-14 13:26:52 --> Helper loaded: email_helper
INFO - 2018-02-14 13:26:52 --> Helper loaded: common_helper
INFO - 2018-02-14 13:26:52 --> Database Driver Class Initialized
DEBUG - 2018-02-14 13:26:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 13:26:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 13:26:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-14 13:26:52 --> Pagination Class Initialized
INFO - 2018-02-14 13:26:52 --> Helper loaded: form_helper
INFO - 2018-02-14 13:26:52 --> Form Validation Class Initialized
INFO - 2018-02-14 13:26:52 --> Model Class Initialized
INFO - 2018-02-14 13:26:52 --> Controller Class Initialized
INFO - 2018-02-14 13:26:52 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-14 13:26:52 --> Model Class Initialized
INFO - 2018-02-14 13:26:52 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-14 13:26:52 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-14 13:26:52 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-14 13:26:52 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-14 13:26:52 --> File loaded: /var/www/html/project/radio/application/views/category/add_edit.php
INFO - 2018-02-14 13:26:52 --> Final output sent to browser
DEBUG - 2018-02-14 13:26:52 --> Total execution time: 0.0074
INFO - 2018-02-14 13:26:55 --> Config Class Initialized
INFO - 2018-02-14 13:26:55 --> Hooks Class Initialized
DEBUG - 2018-02-14 13:26:55 --> UTF-8 Support Enabled
INFO - 2018-02-14 13:26:55 --> Utf8 Class Initialized
INFO - 2018-02-14 13:26:55 --> URI Class Initialized
INFO - 2018-02-14 13:26:55 --> Router Class Initialized
INFO - 2018-02-14 13:26:55 --> Output Class Initialized
INFO - 2018-02-14 13:26:55 --> Security Class Initialized
DEBUG - 2018-02-14 13:26:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 13:26:55 --> Input Class Initialized
INFO - 2018-02-14 13:26:55 --> Language Class Initialized
INFO - 2018-02-14 13:26:55 --> Loader Class Initialized
INFO - 2018-02-14 13:26:55 --> Helper loaded: url_helper
INFO - 2018-02-14 13:26:55 --> Helper loaded: file_helper
INFO - 2018-02-14 13:26:55 --> Helper loaded: email_helper
INFO - 2018-02-14 13:26:55 --> Helper loaded: common_helper
INFO - 2018-02-14 13:26:55 --> Database Driver Class Initialized
DEBUG - 2018-02-14 13:26:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 13:26:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 13:26:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-14 13:26:55 --> Pagination Class Initialized
INFO - 2018-02-14 13:26:55 --> Helper loaded: form_helper
INFO - 2018-02-14 13:26:55 --> Form Validation Class Initialized
INFO - 2018-02-14 13:26:55 --> Model Class Initialized
INFO - 2018-02-14 13:26:55 --> Controller Class Initialized
INFO - 2018-02-14 13:26:55 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-14 13:26:55 --> Model Class Initialized
DEBUG - 2018-02-14 13:26:55 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-14 13:26:55 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-02-14 13:26:55 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-14 13:26:55 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-14 13:26:55 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-14 13:26:55 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-14 13:26:55 --> File loaded: /var/www/html/project/radio/application/views/category/add_edit.php
INFO - 2018-02-14 13:26:55 --> Final output sent to browser
DEBUG - 2018-02-14 13:26:55 --> Total execution time: 0.1051
INFO - 2018-02-14 13:27:50 --> Config Class Initialized
INFO - 2018-02-14 13:27:50 --> Hooks Class Initialized
DEBUG - 2018-02-14 13:27:50 --> UTF-8 Support Enabled
INFO - 2018-02-14 13:27:50 --> Utf8 Class Initialized
INFO - 2018-02-14 13:27:50 --> URI Class Initialized
INFO - 2018-02-14 13:27:50 --> Router Class Initialized
INFO - 2018-02-14 13:27:50 --> Output Class Initialized
INFO - 2018-02-14 13:27:50 --> Security Class Initialized
DEBUG - 2018-02-14 13:27:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 13:27:50 --> Input Class Initialized
INFO - 2018-02-14 13:27:50 --> Language Class Initialized
INFO - 2018-02-14 13:27:50 --> Loader Class Initialized
INFO - 2018-02-14 13:27:50 --> Helper loaded: url_helper
INFO - 2018-02-14 13:27:50 --> Helper loaded: file_helper
INFO - 2018-02-14 13:27:50 --> Helper loaded: email_helper
INFO - 2018-02-14 13:27:50 --> Helper loaded: common_helper
INFO - 2018-02-14 13:27:50 --> Database Driver Class Initialized
DEBUG - 2018-02-14 13:27:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 13:27:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 13:27:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-14 13:27:50 --> Pagination Class Initialized
INFO - 2018-02-14 13:27:50 --> Helper loaded: form_helper
INFO - 2018-02-14 13:27:50 --> Form Validation Class Initialized
INFO - 2018-02-14 13:27:50 --> Model Class Initialized
INFO - 2018-02-14 13:27:50 --> Controller Class Initialized
INFO - 2018-02-14 13:27:50 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-14 13:27:50 --> Model Class Initialized
DEBUG - 2018-02-14 13:27:50 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-14 13:27:50 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-02-14 13:27:50 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-14 13:27:50 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-14 13:27:50 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-14 13:27:50 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-14 13:27:50 --> File loaded: /var/www/html/project/radio/application/views/category/add_edit.php
INFO - 2018-02-14 13:27:50 --> Final output sent to browser
DEBUG - 2018-02-14 13:27:50 --> Total execution time: 0.0112
INFO - 2018-02-14 13:27:56 --> Config Class Initialized
INFO - 2018-02-14 13:27:56 --> Hooks Class Initialized
DEBUG - 2018-02-14 13:27:56 --> UTF-8 Support Enabled
INFO - 2018-02-14 13:27:56 --> Utf8 Class Initialized
INFO - 2018-02-14 13:27:56 --> URI Class Initialized
INFO - 2018-02-14 13:27:56 --> Router Class Initialized
INFO - 2018-02-14 13:27:56 --> Output Class Initialized
INFO - 2018-02-14 13:27:56 --> Security Class Initialized
DEBUG - 2018-02-14 13:27:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 13:27:56 --> Input Class Initialized
INFO - 2018-02-14 13:27:56 --> Language Class Initialized
INFO - 2018-02-14 13:27:56 --> Loader Class Initialized
INFO - 2018-02-14 13:27:56 --> Helper loaded: url_helper
INFO - 2018-02-14 13:27:56 --> Helper loaded: file_helper
INFO - 2018-02-14 13:27:56 --> Helper loaded: email_helper
INFO - 2018-02-14 13:27:56 --> Helper loaded: common_helper
INFO - 2018-02-14 13:27:56 --> Database Driver Class Initialized
DEBUG - 2018-02-14 13:27:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 13:27:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 13:27:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-14 13:27:56 --> Pagination Class Initialized
INFO - 2018-02-14 13:27:56 --> Helper loaded: form_helper
INFO - 2018-02-14 13:27:56 --> Form Validation Class Initialized
INFO - 2018-02-14 13:27:56 --> Model Class Initialized
INFO - 2018-02-14 13:27:56 --> Controller Class Initialized
INFO - 2018-02-14 13:27:56 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-14 13:27:56 --> Model Class Initialized
INFO - 2018-02-14 13:27:56 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-14 13:27:56 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-14 13:27:56 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-14 13:27:56 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-14 13:27:56 --> File loaded: /var/www/html/project/radio/application/views/category/add_edit.php
INFO - 2018-02-14 13:27:56 --> Final output sent to browser
DEBUG - 2018-02-14 13:27:56 --> Total execution time: 0.0051
INFO - 2018-02-14 13:27:58 --> Config Class Initialized
INFO - 2018-02-14 13:27:58 --> Hooks Class Initialized
DEBUG - 2018-02-14 13:27:58 --> UTF-8 Support Enabled
INFO - 2018-02-14 13:27:58 --> Utf8 Class Initialized
INFO - 2018-02-14 13:27:58 --> URI Class Initialized
INFO - 2018-02-14 13:27:58 --> Router Class Initialized
INFO - 2018-02-14 13:27:58 --> Output Class Initialized
INFO - 2018-02-14 13:27:58 --> Security Class Initialized
DEBUG - 2018-02-14 13:27:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 13:27:58 --> Input Class Initialized
INFO - 2018-02-14 13:27:58 --> Language Class Initialized
INFO - 2018-02-14 13:27:58 --> Loader Class Initialized
INFO - 2018-02-14 13:27:58 --> Helper loaded: url_helper
INFO - 2018-02-14 13:27:58 --> Helper loaded: file_helper
INFO - 2018-02-14 13:27:58 --> Helper loaded: email_helper
INFO - 2018-02-14 13:27:58 --> Helper loaded: common_helper
INFO - 2018-02-14 13:27:58 --> Database Driver Class Initialized
DEBUG - 2018-02-14 13:27:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 13:27:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 13:27:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-14 13:27:58 --> Pagination Class Initialized
INFO - 2018-02-14 13:27:58 --> Helper loaded: form_helper
INFO - 2018-02-14 13:27:58 --> Form Validation Class Initialized
INFO - 2018-02-14 13:27:58 --> Model Class Initialized
INFO - 2018-02-14 13:27:58 --> Controller Class Initialized
INFO - 2018-02-14 13:27:58 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-14 13:27:58 --> Model Class Initialized
DEBUG - 2018-02-14 13:27:58 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-14 13:27:58 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-02-14 13:27:58 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-14 13:27:58 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-14 13:27:58 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-14 13:27:58 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-14 13:27:58 --> File loaded: /var/www/html/project/radio/application/views/category/add_edit.php
INFO - 2018-02-14 13:27:58 --> Final output sent to browser
DEBUG - 2018-02-14 13:27:58 --> Total execution time: 0.0046
INFO - 2018-02-14 13:30:01 --> Config Class Initialized
INFO - 2018-02-14 13:30:01 --> Hooks Class Initialized
DEBUG - 2018-02-14 13:30:01 --> UTF-8 Support Enabled
INFO - 2018-02-14 13:30:01 --> Utf8 Class Initialized
INFO - 2018-02-14 13:30:01 --> URI Class Initialized
INFO - 2018-02-14 13:30:01 --> Router Class Initialized
INFO - 2018-02-14 13:30:01 --> Output Class Initialized
INFO - 2018-02-14 13:30:01 --> Security Class Initialized
DEBUG - 2018-02-14 13:30:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 13:30:01 --> Input Class Initialized
INFO - 2018-02-14 13:30:01 --> Language Class Initialized
INFO - 2018-02-14 13:30:01 --> Loader Class Initialized
INFO - 2018-02-14 13:30:01 --> Helper loaded: url_helper
INFO - 2018-02-14 13:30:01 --> Helper loaded: file_helper
INFO - 2018-02-14 13:30:01 --> Helper loaded: email_helper
INFO - 2018-02-14 13:30:01 --> Helper loaded: common_helper
INFO - 2018-02-14 13:30:01 --> Database Driver Class Initialized
DEBUG - 2018-02-14 13:30:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 13:30:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 13:30:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-14 13:30:01 --> Pagination Class Initialized
INFO - 2018-02-14 13:30:01 --> Helper loaded: form_helper
INFO - 2018-02-14 13:30:01 --> Form Validation Class Initialized
INFO - 2018-02-14 13:30:01 --> Model Class Initialized
INFO - 2018-02-14 13:30:01 --> Controller Class Initialized
INFO - 2018-02-14 13:30:01 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-14 13:30:01 --> Model Class Initialized
DEBUG - 2018-02-14 13:30:01 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-14 13:30:01 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-02-14 13:30:01 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-14 13:30:01 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-14 13:30:01 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-14 13:30:01 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-14 13:30:01 --> File loaded: /var/www/html/project/radio/application/views/category/add_edit.php
INFO - 2018-02-14 13:30:01 --> Final output sent to browser
DEBUG - 2018-02-14 13:30:01 --> Total execution time: 0.0097
INFO - 2018-02-14 13:30:05 --> Config Class Initialized
INFO - 2018-02-14 13:30:05 --> Hooks Class Initialized
DEBUG - 2018-02-14 13:30:05 --> UTF-8 Support Enabled
INFO - 2018-02-14 13:30:05 --> Utf8 Class Initialized
INFO - 2018-02-14 13:30:05 --> URI Class Initialized
INFO - 2018-02-14 13:30:05 --> Router Class Initialized
INFO - 2018-02-14 13:30:05 --> Output Class Initialized
INFO - 2018-02-14 13:30:05 --> Security Class Initialized
DEBUG - 2018-02-14 13:30:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 13:30:05 --> Input Class Initialized
INFO - 2018-02-14 13:30:05 --> Language Class Initialized
INFO - 2018-02-14 13:30:05 --> Loader Class Initialized
INFO - 2018-02-14 13:30:05 --> Helper loaded: url_helper
INFO - 2018-02-14 13:30:05 --> Helper loaded: file_helper
INFO - 2018-02-14 13:30:05 --> Helper loaded: email_helper
INFO - 2018-02-14 13:30:05 --> Helper loaded: common_helper
INFO - 2018-02-14 13:30:05 --> Database Driver Class Initialized
DEBUG - 2018-02-14 13:30:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 13:30:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 13:30:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-14 13:30:05 --> Pagination Class Initialized
INFO - 2018-02-14 13:30:05 --> Helper loaded: form_helper
INFO - 2018-02-14 13:30:05 --> Form Validation Class Initialized
INFO - 2018-02-14 13:30:05 --> Model Class Initialized
INFO - 2018-02-14 13:30:05 --> Controller Class Initialized
INFO - 2018-02-14 13:30:05 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-14 13:30:05 --> Model Class Initialized
DEBUG - 2018-02-14 13:30:05 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-14 13:30:05 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-02-14 13:30:05 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-14 13:30:05 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-14 13:30:05 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-14 13:30:05 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-14 13:30:05 --> File loaded: /var/www/html/project/radio/application/views/category/add_edit.php
INFO - 2018-02-14 13:30:05 --> Final output sent to browser
DEBUG - 2018-02-14 13:30:05 --> Total execution time: 0.0054
INFO - 2018-02-14 13:30:09 --> Config Class Initialized
INFO - 2018-02-14 13:30:09 --> Hooks Class Initialized
DEBUG - 2018-02-14 13:30:09 --> UTF-8 Support Enabled
INFO - 2018-02-14 13:30:09 --> Utf8 Class Initialized
INFO - 2018-02-14 13:30:09 --> URI Class Initialized
INFO - 2018-02-14 13:30:09 --> Router Class Initialized
INFO - 2018-02-14 13:30:09 --> Output Class Initialized
INFO - 2018-02-14 13:30:09 --> Security Class Initialized
DEBUG - 2018-02-14 13:30:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 13:30:09 --> Input Class Initialized
INFO - 2018-02-14 13:30:09 --> Language Class Initialized
INFO - 2018-02-14 13:30:09 --> Loader Class Initialized
INFO - 2018-02-14 13:30:09 --> Helper loaded: url_helper
INFO - 2018-02-14 13:30:09 --> Helper loaded: file_helper
INFO - 2018-02-14 13:30:09 --> Helper loaded: email_helper
INFO - 2018-02-14 13:30:09 --> Helper loaded: common_helper
INFO - 2018-02-14 13:30:09 --> Database Driver Class Initialized
DEBUG - 2018-02-14 13:30:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 13:30:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 13:30:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-14 13:30:09 --> Pagination Class Initialized
INFO - 2018-02-14 13:30:09 --> Helper loaded: form_helper
INFO - 2018-02-14 13:30:09 --> Form Validation Class Initialized
INFO - 2018-02-14 13:30:09 --> Model Class Initialized
INFO - 2018-02-14 13:30:09 --> Controller Class Initialized
INFO - 2018-02-14 13:30:09 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-14 13:30:09 --> Model Class Initialized
INFO - 2018-02-14 13:30:09 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-14 13:30:09 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-14 13:30:09 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-14 13:30:09 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-14 13:30:09 --> File loaded: /var/www/html/project/radio/application/views/category/add_edit.php
INFO - 2018-02-14 13:30:09 --> Final output sent to browser
DEBUG - 2018-02-14 13:30:09 --> Total execution time: 0.0062
INFO - 2018-02-14 13:30:13 --> Config Class Initialized
INFO - 2018-02-14 13:30:13 --> Hooks Class Initialized
DEBUG - 2018-02-14 13:30:13 --> UTF-8 Support Enabled
INFO - 2018-02-14 13:30:13 --> Utf8 Class Initialized
INFO - 2018-02-14 13:30:13 --> URI Class Initialized
INFO - 2018-02-14 13:30:13 --> Router Class Initialized
INFO - 2018-02-14 13:30:13 --> Output Class Initialized
INFO - 2018-02-14 13:30:13 --> Security Class Initialized
DEBUG - 2018-02-14 13:30:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 13:30:13 --> Input Class Initialized
INFO - 2018-02-14 13:30:13 --> Language Class Initialized
INFO - 2018-02-14 13:30:13 --> Loader Class Initialized
INFO - 2018-02-14 13:30:13 --> Helper loaded: url_helper
INFO - 2018-02-14 13:30:13 --> Helper loaded: file_helper
INFO - 2018-02-14 13:30:13 --> Helper loaded: email_helper
INFO - 2018-02-14 13:30:13 --> Helper loaded: common_helper
INFO - 2018-02-14 13:30:13 --> Database Driver Class Initialized
DEBUG - 2018-02-14 13:30:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 13:30:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 13:30:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-14 13:30:13 --> Pagination Class Initialized
INFO - 2018-02-14 13:30:13 --> Helper loaded: form_helper
INFO - 2018-02-14 13:30:13 --> Form Validation Class Initialized
INFO - 2018-02-14 13:30:13 --> Model Class Initialized
INFO - 2018-02-14 13:30:13 --> Controller Class Initialized
INFO - 2018-02-14 13:30:13 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-14 13:30:13 --> Model Class Initialized
INFO - 2018-02-14 13:30:13 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-14 13:30:13 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-14 13:30:13 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-14 13:30:13 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-14 13:30:13 --> File loaded: /var/www/html/project/radio/application/views/category/add_edit.php
INFO - 2018-02-14 13:30:13 --> Final output sent to browser
DEBUG - 2018-02-14 13:30:13 --> Total execution time: 0.0046
INFO - 2018-02-14 13:30:16 --> Config Class Initialized
INFO - 2018-02-14 13:30:16 --> Hooks Class Initialized
DEBUG - 2018-02-14 13:30:16 --> UTF-8 Support Enabled
INFO - 2018-02-14 13:30:16 --> Utf8 Class Initialized
INFO - 2018-02-14 13:30:16 --> URI Class Initialized
INFO - 2018-02-14 13:30:16 --> Router Class Initialized
INFO - 2018-02-14 13:30:16 --> Output Class Initialized
INFO - 2018-02-14 13:30:16 --> Security Class Initialized
DEBUG - 2018-02-14 13:30:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 13:30:16 --> Input Class Initialized
INFO - 2018-02-14 13:30:16 --> Language Class Initialized
INFO - 2018-02-14 13:30:16 --> Loader Class Initialized
INFO - 2018-02-14 13:30:16 --> Helper loaded: url_helper
INFO - 2018-02-14 13:30:16 --> Helper loaded: file_helper
INFO - 2018-02-14 13:30:16 --> Helper loaded: email_helper
INFO - 2018-02-14 13:30:16 --> Helper loaded: common_helper
INFO - 2018-02-14 13:30:16 --> Database Driver Class Initialized
DEBUG - 2018-02-14 13:30:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 13:30:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 13:30:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-14 13:30:16 --> Pagination Class Initialized
INFO - 2018-02-14 13:30:16 --> Helper loaded: form_helper
INFO - 2018-02-14 13:30:16 --> Form Validation Class Initialized
INFO - 2018-02-14 13:30:16 --> Model Class Initialized
INFO - 2018-02-14 13:30:16 --> Controller Class Initialized
INFO - 2018-02-14 13:30:16 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-14 13:30:16 --> Model Class Initialized
DEBUG - 2018-02-14 13:30:16 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-14 13:30:16 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-02-14 13:30:16 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-14 13:30:16 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-14 13:30:16 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-14 13:30:16 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-14 13:30:16 --> File loaded: /var/www/html/project/radio/application/views/category/add_edit.php
INFO - 2018-02-14 13:30:16 --> Final output sent to browser
DEBUG - 2018-02-14 13:30:16 --> Total execution time: 0.0048
INFO - 2018-02-14 13:30:27 --> Config Class Initialized
INFO - 2018-02-14 13:30:27 --> Hooks Class Initialized
DEBUG - 2018-02-14 13:30:27 --> UTF-8 Support Enabled
INFO - 2018-02-14 13:30:27 --> Utf8 Class Initialized
INFO - 2018-02-14 13:30:27 --> URI Class Initialized
INFO - 2018-02-14 13:30:27 --> Router Class Initialized
INFO - 2018-02-14 13:30:27 --> Output Class Initialized
INFO - 2018-02-14 13:30:27 --> Security Class Initialized
DEBUG - 2018-02-14 13:30:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 13:30:27 --> Input Class Initialized
INFO - 2018-02-14 13:30:27 --> Language Class Initialized
INFO - 2018-02-14 13:30:27 --> Loader Class Initialized
INFO - 2018-02-14 13:30:27 --> Helper loaded: url_helper
INFO - 2018-02-14 13:30:27 --> Helper loaded: file_helper
INFO - 2018-02-14 13:30:27 --> Helper loaded: email_helper
INFO - 2018-02-14 13:30:27 --> Helper loaded: common_helper
INFO - 2018-02-14 13:30:27 --> Database Driver Class Initialized
DEBUG - 2018-02-14 13:30:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 13:30:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 13:30:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-14 13:30:27 --> Pagination Class Initialized
INFO - 2018-02-14 13:30:27 --> Helper loaded: form_helper
INFO - 2018-02-14 13:30:27 --> Form Validation Class Initialized
INFO - 2018-02-14 13:30:27 --> Model Class Initialized
INFO - 2018-02-14 13:30:27 --> Controller Class Initialized
INFO - 2018-02-14 13:30:27 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-14 13:30:27 --> Model Class Initialized
DEBUG - 2018-02-14 13:30:27 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-14 13:30:27 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-02-14 13:30:27 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-14 13:30:27 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-14 13:30:27 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-14 13:30:27 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-14 13:30:27 --> File loaded: /var/www/html/project/radio/application/views/category/add_edit.php
INFO - 2018-02-14 13:30:27 --> Final output sent to browser
DEBUG - 2018-02-14 13:30:27 --> Total execution time: 0.0067
INFO - 2018-02-14 13:30:29 --> Config Class Initialized
INFO - 2018-02-14 13:30:29 --> Hooks Class Initialized
DEBUG - 2018-02-14 13:30:29 --> UTF-8 Support Enabled
INFO - 2018-02-14 13:30:29 --> Utf8 Class Initialized
INFO - 2018-02-14 13:30:29 --> URI Class Initialized
INFO - 2018-02-14 13:30:29 --> Router Class Initialized
INFO - 2018-02-14 13:30:29 --> Output Class Initialized
INFO - 2018-02-14 13:30:29 --> Security Class Initialized
DEBUG - 2018-02-14 13:30:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 13:30:29 --> Input Class Initialized
INFO - 2018-02-14 13:30:29 --> Language Class Initialized
INFO - 2018-02-14 13:30:29 --> Loader Class Initialized
INFO - 2018-02-14 13:30:29 --> Helper loaded: url_helper
INFO - 2018-02-14 13:30:29 --> Helper loaded: file_helper
INFO - 2018-02-14 13:30:29 --> Helper loaded: email_helper
INFO - 2018-02-14 13:30:29 --> Helper loaded: common_helper
INFO - 2018-02-14 13:30:29 --> Database Driver Class Initialized
DEBUG - 2018-02-14 13:30:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 13:30:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 13:30:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-14 13:30:29 --> Pagination Class Initialized
INFO - 2018-02-14 13:30:29 --> Helper loaded: form_helper
INFO - 2018-02-14 13:30:29 --> Form Validation Class Initialized
INFO - 2018-02-14 13:30:29 --> Model Class Initialized
INFO - 2018-02-14 13:30:29 --> Controller Class Initialized
INFO - 2018-02-14 13:30:29 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-14 13:30:29 --> Model Class Initialized
INFO - 2018-02-14 13:30:29 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-14 13:30:29 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-14 13:30:29 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-14 13:30:29 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-14 13:30:29 --> File loaded: /var/www/html/project/radio/application/views/category/add_edit.php
INFO - 2018-02-14 13:30:29 --> Final output sent to browser
DEBUG - 2018-02-14 13:30:29 --> Total execution time: 0.0053
INFO - 2018-02-14 14:22:38 --> Config Class Initialized
INFO - 2018-02-14 14:22:38 --> Hooks Class Initialized
DEBUG - 2018-02-14 14:22:38 --> UTF-8 Support Enabled
INFO - 2018-02-14 14:22:38 --> Utf8 Class Initialized
INFO - 2018-02-14 14:22:38 --> URI Class Initialized
INFO - 2018-02-14 14:22:38 --> Router Class Initialized
INFO - 2018-02-14 14:22:38 --> Output Class Initialized
INFO - 2018-02-14 14:22:38 --> Security Class Initialized
DEBUG - 2018-02-14 14:22:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 14:22:38 --> Input Class Initialized
INFO - 2018-02-14 14:22:38 --> Language Class Initialized
INFO - 2018-02-14 14:22:38 --> Loader Class Initialized
INFO - 2018-02-14 14:22:38 --> Helper loaded: url_helper
INFO - 2018-02-14 14:22:38 --> Helper loaded: file_helper
INFO - 2018-02-14 14:22:38 --> Helper loaded: email_helper
INFO - 2018-02-14 14:22:38 --> Helper loaded: common_helper
INFO - 2018-02-14 14:22:38 --> Database Driver Class Initialized
DEBUG - 2018-02-14 14:22:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 14:22:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 14:22:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-14 14:22:38 --> Pagination Class Initialized
INFO - 2018-02-14 14:22:38 --> Helper loaded: form_helper
INFO - 2018-02-14 14:22:38 --> Form Validation Class Initialized
INFO - 2018-02-14 14:22:38 --> Model Class Initialized
INFO - 2018-02-14 14:22:38 --> Controller Class Initialized
INFO - 2018-02-14 14:22:38 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-14 14:22:38 --> Model Class Initialized
INFO - 2018-02-14 14:22:38 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-14 14:22:38 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-14 14:22:38 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-14 14:22:38 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-14 14:22:38 --> File loaded: /var/www/html/project/radio/application/views/category/add_edit.php
INFO - 2018-02-14 14:22:38 --> Final output sent to browser
DEBUG - 2018-02-14 14:22:38 --> Total execution time: 0.0072
INFO - 2018-02-14 14:23:14 --> Config Class Initialized
INFO - 2018-02-14 14:23:14 --> Hooks Class Initialized
DEBUG - 2018-02-14 14:23:14 --> UTF-8 Support Enabled
INFO - 2018-02-14 14:23:14 --> Utf8 Class Initialized
INFO - 2018-02-14 14:23:14 --> URI Class Initialized
INFO - 2018-02-14 14:23:14 --> Router Class Initialized
INFO - 2018-02-14 14:23:14 --> Output Class Initialized
INFO - 2018-02-14 14:23:14 --> Security Class Initialized
DEBUG - 2018-02-14 14:23:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 14:23:14 --> Input Class Initialized
INFO - 2018-02-14 14:23:14 --> Language Class Initialized
INFO - 2018-02-14 14:23:14 --> Loader Class Initialized
INFO - 2018-02-14 14:23:14 --> Helper loaded: url_helper
INFO - 2018-02-14 14:23:14 --> Helper loaded: file_helper
INFO - 2018-02-14 14:23:14 --> Helper loaded: email_helper
INFO - 2018-02-14 14:23:14 --> Helper loaded: common_helper
INFO - 2018-02-14 14:23:14 --> Database Driver Class Initialized
DEBUG - 2018-02-14 14:23:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 14:23:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 14:23:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-14 14:23:14 --> Pagination Class Initialized
INFO - 2018-02-14 14:23:14 --> Helper loaded: form_helper
INFO - 2018-02-14 14:23:14 --> Form Validation Class Initialized
INFO - 2018-02-14 14:23:14 --> Model Class Initialized
INFO - 2018-02-14 14:23:14 --> Controller Class Initialized
INFO - 2018-02-14 14:23:14 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-14 14:23:14 --> Model Class Initialized
INFO - 2018-02-14 14:23:14 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-14 14:23:14 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-14 14:23:14 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-14 14:23:14 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-14 14:23:14 --> File loaded: /var/www/html/project/radio/application/views/category/add_edit.php
INFO - 2018-02-14 14:23:14 --> Final output sent to browser
DEBUG - 2018-02-14 14:23:14 --> Total execution time: 0.0085
INFO - 2018-02-14 14:25:07 --> Config Class Initialized
INFO - 2018-02-14 14:25:07 --> Hooks Class Initialized
DEBUG - 2018-02-14 14:25:07 --> UTF-8 Support Enabled
INFO - 2018-02-14 14:25:07 --> Utf8 Class Initialized
INFO - 2018-02-14 14:25:07 --> URI Class Initialized
INFO - 2018-02-14 14:25:07 --> Router Class Initialized
INFO - 2018-02-14 14:25:07 --> Output Class Initialized
INFO - 2018-02-14 14:25:07 --> Security Class Initialized
DEBUG - 2018-02-14 14:25:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 14:25:07 --> Input Class Initialized
INFO - 2018-02-14 14:25:07 --> Language Class Initialized
INFO - 2018-02-14 14:25:07 --> Loader Class Initialized
INFO - 2018-02-14 14:25:07 --> Helper loaded: url_helper
INFO - 2018-02-14 14:25:07 --> Helper loaded: file_helper
INFO - 2018-02-14 14:25:07 --> Helper loaded: email_helper
INFO - 2018-02-14 14:25:07 --> Helper loaded: common_helper
INFO - 2018-02-14 14:25:07 --> Database Driver Class Initialized
DEBUG - 2018-02-14 14:25:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 14:25:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 14:25:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-14 14:25:07 --> Pagination Class Initialized
INFO - 2018-02-14 14:25:07 --> Helper loaded: form_helper
INFO - 2018-02-14 14:25:07 --> Form Validation Class Initialized
INFO - 2018-02-14 14:25:07 --> Model Class Initialized
INFO - 2018-02-14 14:25:07 --> Controller Class Initialized
INFO - 2018-02-14 14:25:07 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-14 14:25:07 --> Model Class Initialized
INFO - 2018-02-14 14:25:07 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-14 14:25:07 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-14 14:25:07 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-14 14:25:07 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-14 14:25:07 --> File loaded: /var/www/html/project/radio/application/views/category/add_edit.php
INFO - 2018-02-14 14:25:07 --> Final output sent to browser
DEBUG - 2018-02-14 14:25:07 --> Total execution time: 0.0049
INFO - 2018-02-14 14:26:06 --> Config Class Initialized
INFO - 2018-02-14 14:26:06 --> Hooks Class Initialized
DEBUG - 2018-02-14 14:26:06 --> UTF-8 Support Enabled
INFO - 2018-02-14 14:26:06 --> Utf8 Class Initialized
INFO - 2018-02-14 14:26:06 --> URI Class Initialized
INFO - 2018-02-14 14:26:06 --> Router Class Initialized
INFO - 2018-02-14 14:26:06 --> Output Class Initialized
INFO - 2018-02-14 14:26:06 --> Security Class Initialized
DEBUG - 2018-02-14 14:26:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 14:26:06 --> Input Class Initialized
INFO - 2018-02-14 14:26:06 --> Language Class Initialized
INFO - 2018-02-14 14:26:06 --> Loader Class Initialized
INFO - 2018-02-14 14:26:06 --> Helper loaded: url_helper
INFO - 2018-02-14 14:26:06 --> Helper loaded: file_helper
INFO - 2018-02-14 14:26:06 --> Helper loaded: email_helper
INFO - 2018-02-14 14:26:06 --> Helper loaded: common_helper
INFO - 2018-02-14 14:26:06 --> Database Driver Class Initialized
DEBUG - 2018-02-14 14:26:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 14:26:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 14:26:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-14 14:26:06 --> Pagination Class Initialized
INFO - 2018-02-14 14:26:06 --> Helper loaded: form_helper
INFO - 2018-02-14 14:26:06 --> Form Validation Class Initialized
INFO - 2018-02-14 14:26:06 --> Model Class Initialized
INFO - 2018-02-14 14:26:06 --> Controller Class Initialized
INFO - 2018-02-14 14:26:06 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-14 14:26:06 --> Model Class Initialized
INFO - 2018-02-14 14:26:06 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-14 14:26:06 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-14 14:26:06 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-14 14:26:06 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-14 14:26:06 --> File loaded: /var/www/html/project/radio/application/views/category/add_edit.php
INFO - 2018-02-14 14:26:06 --> Final output sent to browser
DEBUG - 2018-02-14 14:26:06 --> Total execution time: 0.0088
INFO - 2018-02-14 14:26:08 --> Config Class Initialized
INFO - 2018-02-14 14:26:08 --> Hooks Class Initialized
DEBUG - 2018-02-14 14:26:08 --> UTF-8 Support Enabled
INFO - 2018-02-14 14:26:08 --> Utf8 Class Initialized
INFO - 2018-02-14 14:26:08 --> URI Class Initialized
INFO - 2018-02-14 14:26:08 --> Router Class Initialized
INFO - 2018-02-14 14:26:08 --> Output Class Initialized
INFO - 2018-02-14 14:26:08 --> Security Class Initialized
DEBUG - 2018-02-14 14:26:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 14:26:08 --> Input Class Initialized
INFO - 2018-02-14 14:26:08 --> Language Class Initialized
INFO - 2018-02-14 14:26:08 --> Loader Class Initialized
INFO - 2018-02-14 14:26:08 --> Helper loaded: url_helper
INFO - 2018-02-14 14:26:08 --> Helper loaded: file_helper
INFO - 2018-02-14 14:26:08 --> Helper loaded: email_helper
INFO - 2018-02-14 14:26:08 --> Helper loaded: common_helper
INFO - 2018-02-14 14:26:08 --> Database Driver Class Initialized
DEBUG - 2018-02-14 14:26:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 14:26:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 14:26:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-14 14:26:08 --> Pagination Class Initialized
INFO - 2018-02-14 14:26:08 --> Helper loaded: form_helper
INFO - 2018-02-14 14:26:08 --> Form Validation Class Initialized
INFO - 2018-02-14 14:26:08 --> Model Class Initialized
INFO - 2018-02-14 14:26:08 --> Controller Class Initialized
INFO - 2018-02-14 14:26:08 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-14 14:26:08 --> Model Class Initialized
INFO - 2018-02-14 14:26:15 --> Config Class Initialized
INFO - 2018-02-14 14:26:15 --> Hooks Class Initialized
DEBUG - 2018-02-14 14:26:15 --> UTF-8 Support Enabled
INFO - 2018-02-14 14:26:15 --> Utf8 Class Initialized
INFO - 2018-02-14 14:26:15 --> URI Class Initialized
INFO - 2018-02-14 14:26:15 --> Router Class Initialized
INFO - 2018-02-14 14:26:15 --> Output Class Initialized
INFO - 2018-02-14 14:26:15 --> Security Class Initialized
DEBUG - 2018-02-14 14:26:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 14:26:15 --> Input Class Initialized
INFO - 2018-02-14 14:26:15 --> Language Class Initialized
INFO - 2018-02-14 14:26:15 --> Loader Class Initialized
INFO - 2018-02-14 14:26:15 --> Helper loaded: url_helper
INFO - 2018-02-14 14:26:15 --> Helper loaded: file_helper
INFO - 2018-02-14 14:26:15 --> Helper loaded: email_helper
INFO - 2018-02-14 14:26:15 --> Helper loaded: common_helper
INFO - 2018-02-14 14:26:15 --> Database Driver Class Initialized
DEBUG - 2018-02-14 14:26:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 14:26:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 14:26:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-14 14:26:15 --> Pagination Class Initialized
INFO - 2018-02-14 14:26:15 --> Helper loaded: form_helper
INFO - 2018-02-14 14:26:15 --> Form Validation Class Initialized
INFO - 2018-02-14 14:26:15 --> Model Class Initialized
INFO - 2018-02-14 14:26:15 --> Controller Class Initialized
INFO - 2018-02-14 14:26:15 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-14 14:26:15 --> Model Class Initialized
INFO - 2018-02-14 14:26:15 --> Config Class Initialized
INFO - 2018-02-14 14:26:15 --> Hooks Class Initialized
DEBUG - 2018-02-14 14:26:15 --> UTF-8 Support Enabled
INFO - 2018-02-14 14:26:15 --> Utf8 Class Initialized
INFO - 2018-02-14 14:26:15 --> URI Class Initialized
INFO - 2018-02-14 14:26:15 --> Router Class Initialized
INFO - 2018-02-14 14:26:15 --> Output Class Initialized
INFO - 2018-02-14 14:26:15 --> Security Class Initialized
DEBUG - 2018-02-14 14:26:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 14:26:15 --> Input Class Initialized
INFO - 2018-02-14 14:26:15 --> Language Class Initialized
INFO - 2018-02-14 14:26:15 --> Loader Class Initialized
INFO - 2018-02-14 14:26:15 --> Helper loaded: url_helper
INFO - 2018-02-14 14:26:15 --> Helper loaded: file_helper
INFO - 2018-02-14 14:26:15 --> Helper loaded: email_helper
INFO - 2018-02-14 14:26:15 --> Helper loaded: common_helper
INFO - 2018-02-14 14:26:15 --> Database Driver Class Initialized
DEBUG - 2018-02-14 14:26:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 14:26:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 14:26:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-14 14:26:15 --> Pagination Class Initialized
INFO - 2018-02-14 14:26:15 --> Helper loaded: form_helper
INFO - 2018-02-14 14:26:15 --> Form Validation Class Initialized
INFO - 2018-02-14 14:26:15 --> Model Class Initialized
INFO - 2018-02-14 14:26:15 --> Controller Class Initialized
INFO - 2018-02-14 14:26:15 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-14 14:26:15 --> Model Class Initialized
DEBUG - 2018-02-14 14:26:15 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-14 14:26:15 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-02-14 14:26:15 --> Config Class Initialized
INFO - 2018-02-14 14:26:15 --> Hooks Class Initialized
DEBUG - 2018-02-14 14:26:15 --> UTF-8 Support Enabled
INFO - 2018-02-14 14:26:15 --> Utf8 Class Initialized
INFO - 2018-02-14 14:26:15 --> URI Class Initialized
INFO - 2018-02-14 14:26:15 --> Router Class Initialized
INFO - 2018-02-14 14:26:15 --> Output Class Initialized
INFO - 2018-02-14 14:26:15 --> Security Class Initialized
DEBUG - 2018-02-14 14:26:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 14:26:15 --> Input Class Initialized
INFO - 2018-02-14 14:26:15 --> Language Class Initialized
INFO - 2018-02-14 14:26:15 --> Loader Class Initialized
INFO - 2018-02-14 14:26:15 --> Helper loaded: url_helper
INFO - 2018-02-14 14:26:15 --> Helper loaded: file_helper
INFO - 2018-02-14 14:26:15 --> Helper loaded: email_helper
INFO - 2018-02-14 14:26:15 --> Helper loaded: common_helper
INFO - 2018-02-14 14:26:15 --> Database Driver Class Initialized
DEBUG - 2018-02-14 14:26:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 14:26:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 14:26:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-14 14:26:15 --> Pagination Class Initialized
INFO - 2018-02-14 14:26:15 --> Helper loaded: form_helper
INFO - 2018-02-14 14:26:15 --> Form Validation Class Initialized
INFO - 2018-02-14 14:26:15 --> Model Class Initialized
INFO - 2018-02-14 14:26:15 --> Controller Class Initialized
INFO - 2018-02-14 14:26:15 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-14 14:26:15 --> Model Class Initialized
INFO - 2018-02-14 14:26:15 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-14 14:26:15 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-14 14:26:15 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-14 14:26:15 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-14 14:26:15 --> File loaded: /var/www/html/project/radio/application/views/category/add_edit.php
INFO - 2018-02-14 14:26:15 --> Final output sent to browser
DEBUG - 2018-02-14 14:26:15 --> Total execution time: 0.0042
INFO - 2018-02-14 14:26:49 --> Config Class Initialized
INFO - 2018-02-14 14:26:49 --> Hooks Class Initialized
DEBUG - 2018-02-14 14:26:49 --> UTF-8 Support Enabled
INFO - 2018-02-14 14:26:49 --> Utf8 Class Initialized
INFO - 2018-02-14 14:26:49 --> URI Class Initialized
INFO - 2018-02-14 14:26:49 --> Router Class Initialized
INFO - 2018-02-14 14:26:49 --> Output Class Initialized
INFO - 2018-02-14 14:26:49 --> Security Class Initialized
DEBUG - 2018-02-14 14:26:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 14:26:49 --> Input Class Initialized
INFO - 2018-02-14 14:26:49 --> Language Class Initialized
INFO - 2018-02-14 14:26:49 --> Loader Class Initialized
INFO - 2018-02-14 14:26:49 --> Helper loaded: url_helper
INFO - 2018-02-14 14:26:49 --> Helper loaded: file_helper
INFO - 2018-02-14 14:26:49 --> Helper loaded: email_helper
INFO - 2018-02-14 14:26:49 --> Helper loaded: common_helper
INFO - 2018-02-14 14:26:49 --> Database Driver Class Initialized
DEBUG - 2018-02-14 14:26:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 14:26:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 14:26:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-14 14:26:49 --> Pagination Class Initialized
INFO - 2018-02-14 14:26:49 --> Helper loaded: form_helper
INFO - 2018-02-14 14:26:49 --> Form Validation Class Initialized
INFO - 2018-02-14 14:26:49 --> Model Class Initialized
INFO - 2018-02-14 14:26:49 --> Controller Class Initialized
INFO - 2018-02-14 14:26:49 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-14 14:26:49 --> Model Class Initialized
INFO - 2018-02-14 14:26:49 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-14 14:26:49 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-14 14:26:49 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-14 14:26:49 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-14 14:26:49 --> File loaded: /var/www/html/project/radio/application/views/category/add_edit.php
INFO - 2018-02-14 14:26:49 --> Final output sent to browser
DEBUG - 2018-02-14 14:26:49 --> Total execution time: 0.0061
INFO - 2018-02-14 14:26:55 --> Config Class Initialized
INFO - 2018-02-14 14:26:55 --> Hooks Class Initialized
DEBUG - 2018-02-14 14:26:55 --> UTF-8 Support Enabled
INFO - 2018-02-14 14:26:55 --> Utf8 Class Initialized
INFO - 2018-02-14 14:26:55 --> URI Class Initialized
INFO - 2018-02-14 14:26:55 --> Router Class Initialized
INFO - 2018-02-14 14:26:55 --> Output Class Initialized
INFO - 2018-02-14 14:26:55 --> Security Class Initialized
DEBUG - 2018-02-14 14:26:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 14:26:55 --> Input Class Initialized
INFO - 2018-02-14 14:26:55 --> Language Class Initialized
INFO - 2018-02-14 14:26:55 --> Loader Class Initialized
INFO - 2018-02-14 14:26:55 --> Helper loaded: url_helper
INFO - 2018-02-14 14:26:55 --> Helper loaded: file_helper
INFO - 2018-02-14 14:26:55 --> Helper loaded: email_helper
INFO - 2018-02-14 14:26:55 --> Helper loaded: common_helper
INFO - 2018-02-14 14:26:55 --> Database Driver Class Initialized
DEBUG - 2018-02-14 14:26:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 14:26:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 14:26:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-14 14:26:55 --> Pagination Class Initialized
INFO - 2018-02-14 14:26:55 --> Helper loaded: form_helper
INFO - 2018-02-14 14:26:55 --> Form Validation Class Initialized
INFO - 2018-02-14 14:26:55 --> Model Class Initialized
INFO - 2018-02-14 14:26:55 --> Controller Class Initialized
INFO - 2018-02-14 14:26:55 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-14 14:26:55 --> Model Class Initialized
INFO - 2018-02-14 14:26:55 --> Config Class Initialized
INFO - 2018-02-14 14:26:55 --> Hooks Class Initialized
DEBUG - 2018-02-14 14:26:55 --> UTF-8 Support Enabled
INFO - 2018-02-14 14:26:55 --> Utf8 Class Initialized
INFO - 2018-02-14 14:26:55 --> URI Class Initialized
INFO - 2018-02-14 14:26:55 --> Router Class Initialized
INFO - 2018-02-14 14:26:55 --> Output Class Initialized
INFO - 2018-02-14 14:26:55 --> Security Class Initialized
DEBUG - 2018-02-14 14:26:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 14:26:55 --> Input Class Initialized
INFO - 2018-02-14 14:26:55 --> Language Class Initialized
INFO - 2018-02-14 14:26:55 --> Loader Class Initialized
INFO - 2018-02-14 14:26:55 --> Helper loaded: url_helper
INFO - 2018-02-14 14:26:55 --> Helper loaded: file_helper
INFO - 2018-02-14 14:26:55 --> Helper loaded: email_helper
INFO - 2018-02-14 14:26:55 --> Helper loaded: common_helper
INFO - 2018-02-14 14:26:55 --> Database Driver Class Initialized
DEBUG - 2018-02-14 14:26:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 14:26:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 14:26:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-14 14:26:55 --> Pagination Class Initialized
INFO - 2018-02-14 14:26:55 --> Helper loaded: form_helper
INFO - 2018-02-14 14:26:55 --> Form Validation Class Initialized
INFO - 2018-02-14 14:26:55 --> Model Class Initialized
INFO - 2018-02-14 14:26:55 --> Controller Class Initialized
INFO - 2018-02-14 14:26:55 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-14 14:26:55 --> Model Class Initialized
DEBUG - 2018-02-14 14:26:55 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-14 14:26:55 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-02-14 14:26:56 --> Config Class Initialized
INFO - 2018-02-14 14:26:56 --> Hooks Class Initialized
DEBUG - 2018-02-14 14:26:56 --> UTF-8 Support Enabled
INFO - 2018-02-14 14:26:56 --> Utf8 Class Initialized
INFO - 2018-02-14 14:26:56 --> URI Class Initialized
INFO - 2018-02-14 14:26:56 --> Router Class Initialized
INFO - 2018-02-14 14:26:56 --> Output Class Initialized
INFO - 2018-02-14 14:26:56 --> Security Class Initialized
DEBUG - 2018-02-14 14:26:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 14:26:56 --> Input Class Initialized
INFO - 2018-02-14 14:26:56 --> Language Class Initialized
INFO - 2018-02-14 14:26:56 --> Loader Class Initialized
INFO - 2018-02-14 14:26:56 --> Helper loaded: url_helper
INFO - 2018-02-14 14:26:56 --> Helper loaded: file_helper
INFO - 2018-02-14 14:26:56 --> Helper loaded: email_helper
INFO - 2018-02-14 14:26:56 --> Helper loaded: common_helper
INFO - 2018-02-14 14:26:56 --> Database Driver Class Initialized
DEBUG - 2018-02-14 14:26:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 14:26:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 14:26:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-14 14:26:56 --> Pagination Class Initialized
INFO - 2018-02-14 14:26:56 --> Helper loaded: form_helper
INFO - 2018-02-14 14:26:56 --> Form Validation Class Initialized
INFO - 2018-02-14 14:26:56 --> Model Class Initialized
INFO - 2018-02-14 14:26:56 --> Controller Class Initialized
INFO - 2018-02-14 14:26:56 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-14 14:26:56 --> Model Class Initialized
INFO - 2018-02-14 14:26:56 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-14 14:26:56 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-14 14:26:56 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-14 14:26:56 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-14 14:26:56 --> File loaded: /var/www/html/project/radio/application/views/category/index.php
INFO - 2018-02-14 14:26:56 --> Final output sent to browser
DEBUG - 2018-02-14 14:26:56 --> Total execution time: 0.0048
INFO - 2018-02-14 14:39:38 --> Config Class Initialized
INFO - 2018-02-14 14:39:38 --> Hooks Class Initialized
DEBUG - 2018-02-14 14:39:38 --> UTF-8 Support Enabled
INFO - 2018-02-14 14:39:38 --> Utf8 Class Initialized
INFO - 2018-02-14 14:39:38 --> URI Class Initialized
INFO - 2018-02-14 14:39:38 --> Router Class Initialized
INFO - 2018-02-14 14:39:38 --> Output Class Initialized
INFO - 2018-02-14 14:39:38 --> Security Class Initialized
DEBUG - 2018-02-14 14:39:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 14:39:38 --> Input Class Initialized
INFO - 2018-02-14 14:39:38 --> Language Class Initialized
INFO - 2018-02-14 14:39:38 --> Loader Class Initialized
INFO - 2018-02-14 14:39:38 --> Helper loaded: url_helper
INFO - 2018-02-14 14:39:38 --> Helper loaded: file_helper
INFO - 2018-02-14 14:39:38 --> Helper loaded: email_helper
INFO - 2018-02-14 14:39:38 --> Helper loaded: common_helper
INFO - 2018-02-14 14:39:38 --> Database Driver Class Initialized
DEBUG - 2018-02-14 14:39:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 14:39:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 14:39:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-14 14:39:38 --> Pagination Class Initialized
INFO - 2018-02-14 14:39:38 --> Helper loaded: form_helper
INFO - 2018-02-14 14:39:38 --> Form Validation Class Initialized
INFO - 2018-02-14 14:39:38 --> Model Class Initialized
INFO - 2018-02-14 14:39:38 --> Controller Class Initialized
INFO - 2018-02-14 14:39:38 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-14 14:39:38 --> Model Class Initialized
INFO - 2018-02-14 14:39:38 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-14 14:39:38 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-14 14:39:38 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-14 14:39:38 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-14 14:39:38 --> File loaded: /var/www/html/project/radio/application/views/category/index.php
INFO - 2018-02-14 14:39:38 --> Final output sent to browser
DEBUG - 2018-02-14 14:39:38 --> Total execution time: 0.0053
INFO - 2018-02-14 14:39:39 --> Config Class Initialized
INFO - 2018-02-14 14:39:39 --> Hooks Class Initialized
DEBUG - 2018-02-14 14:39:39 --> UTF-8 Support Enabled
INFO - 2018-02-14 14:39:39 --> Utf8 Class Initialized
INFO - 2018-02-14 14:39:39 --> URI Class Initialized
INFO - 2018-02-14 14:39:39 --> Router Class Initialized
INFO - 2018-02-14 14:39:39 --> Output Class Initialized
INFO - 2018-02-14 14:39:39 --> Security Class Initialized
DEBUG - 2018-02-14 14:39:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 14:39:39 --> Input Class Initialized
INFO - 2018-02-14 14:39:39 --> Language Class Initialized
INFO - 2018-02-14 14:39:39 --> Loader Class Initialized
INFO - 2018-02-14 14:39:39 --> Helper loaded: url_helper
INFO - 2018-02-14 14:39:39 --> Helper loaded: file_helper
INFO - 2018-02-14 14:39:39 --> Helper loaded: email_helper
INFO - 2018-02-14 14:39:40 --> Helper loaded: common_helper
INFO - 2018-02-14 14:39:40 --> Database Driver Class Initialized
DEBUG - 2018-02-14 14:39:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 14:39:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 14:39:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-14 14:39:40 --> Pagination Class Initialized
INFO - 2018-02-14 14:39:40 --> Helper loaded: form_helper
INFO - 2018-02-14 14:39:40 --> Form Validation Class Initialized
INFO - 2018-02-14 14:39:40 --> Model Class Initialized
INFO - 2018-02-14 14:39:40 --> Controller Class Initialized
INFO - 2018-02-14 14:39:40 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-14 14:39:40 --> Model Class Initialized
INFO - 2018-02-14 14:39:40 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-14 14:39:40 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-14 14:39:40 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-14 14:39:40 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-14 14:39:40 --> File loaded: /var/www/html/project/radio/application/views/category/add_edit.php
INFO - 2018-02-14 14:39:40 --> Final output sent to browser
DEBUG - 2018-02-14 14:39:40 --> Total execution time: 0.0074
INFO - 2018-02-14 14:40:04 --> Config Class Initialized
INFO - 2018-02-14 14:40:04 --> Hooks Class Initialized
DEBUG - 2018-02-14 14:40:04 --> UTF-8 Support Enabled
INFO - 2018-02-14 14:40:04 --> Utf8 Class Initialized
INFO - 2018-02-14 14:40:04 --> URI Class Initialized
INFO - 2018-02-14 14:40:04 --> Router Class Initialized
INFO - 2018-02-14 14:40:04 --> Output Class Initialized
INFO - 2018-02-14 14:40:04 --> Security Class Initialized
DEBUG - 2018-02-14 14:40:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 14:40:04 --> Input Class Initialized
INFO - 2018-02-14 14:40:04 --> Language Class Initialized
INFO - 2018-02-14 14:40:04 --> Loader Class Initialized
INFO - 2018-02-14 14:40:04 --> Helper loaded: url_helper
INFO - 2018-02-14 14:40:04 --> Helper loaded: file_helper
INFO - 2018-02-14 14:40:04 --> Helper loaded: email_helper
INFO - 2018-02-14 14:40:04 --> Helper loaded: common_helper
INFO - 2018-02-14 14:40:04 --> Database Driver Class Initialized
DEBUG - 2018-02-14 14:40:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 14:40:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 14:40:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-14 14:40:04 --> Pagination Class Initialized
INFO - 2018-02-14 14:40:04 --> Helper loaded: form_helper
INFO - 2018-02-14 14:40:04 --> Form Validation Class Initialized
INFO - 2018-02-14 14:40:04 --> Model Class Initialized
INFO - 2018-02-14 14:40:04 --> Controller Class Initialized
INFO - 2018-02-14 14:40:04 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-14 14:40:04 --> Model Class Initialized
INFO - 2018-02-14 14:40:16 --> Config Class Initialized
INFO - 2018-02-14 14:40:16 --> Hooks Class Initialized
DEBUG - 2018-02-14 14:40:16 --> UTF-8 Support Enabled
INFO - 2018-02-14 14:40:16 --> Utf8 Class Initialized
INFO - 2018-02-14 14:40:16 --> URI Class Initialized
INFO - 2018-02-14 14:40:16 --> Router Class Initialized
INFO - 2018-02-14 14:40:16 --> Output Class Initialized
INFO - 2018-02-14 14:40:16 --> Security Class Initialized
DEBUG - 2018-02-14 14:40:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 14:40:16 --> Input Class Initialized
INFO - 2018-02-14 14:40:16 --> Language Class Initialized
INFO - 2018-02-14 14:40:16 --> Loader Class Initialized
INFO - 2018-02-14 14:40:16 --> Helper loaded: url_helper
INFO - 2018-02-14 14:40:16 --> Helper loaded: file_helper
INFO - 2018-02-14 14:40:16 --> Helper loaded: email_helper
INFO - 2018-02-14 14:40:16 --> Helper loaded: common_helper
INFO - 2018-02-14 14:40:16 --> Database Driver Class Initialized
DEBUG - 2018-02-14 14:40:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 14:40:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 14:40:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-14 14:40:16 --> Pagination Class Initialized
INFO - 2018-02-14 14:40:16 --> Helper loaded: form_helper
INFO - 2018-02-14 14:40:16 --> Form Validation Class Initialized
INFO - 2018-02-14 14:40:16 --> Model Class Initialized
INFO - 2018-02-14 14:40:16 --> Controller Class Initialized
INFO - 2018-02-14 14:40:16 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-14 14:40:16 --> Model Class Initialized
INFO - 2018-02-14 14:40:16 --> Config Class Initialized
INFO - 2018-02-14 14:40:16 --> Hooks Class Initialized
DEBUG - 2018-02-14 14:40:16 --> UTF-8 Support Enabled
INFO - 2018-02-14 14:40:16 --> Utf8 Class Initialized
INFO - 2018-02-14 14:40:16 --> URI Class Initialized
INFO - 2018-02-14 14:40:16 --> Router Class Initialized
INFO - 2018-02-14 14:40:16 --> Output Class Initialized
INFO - 2018-02-14 14:40:16 --> Security Class Initialized
DEBUG - 2018-02-14 14:40:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 14:40:16 --> Input Class Initialized
INFO - 2018-02-14 14:40:16 --> Language Class Initialized
INFO - 2018-02-14 14:40:16 --> Loader Class Initialized
INFO - 2018-02-14 14:40:16 --> Helper loaded: url_helper
INFO - 2018-02-14 14:40:16 --> Helper loaded: file_helper
INFO - 2018-02-14 14:40:16 --> Helper loaded: email_helper
INFO - 2018-02-14 14:40:16 --> Helper loaded: common_helper
INFO - 2018-02-14 14:40:16 --> Database Driver Class Initialized
DEBUG - 2018-02-14 14:40:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 14:40:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 14:40:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-14 14:40:16 --> Pagination Class Initialized
INFO - 2018-02-14 14:40:16 --> Helper loaded: form_helper
INFO - 2018-02-14 14:40:16 --> Form Validation Class Initialized
INFO - 2018-02-14 14:40:16 --> Model Class Initialized
INFO - 2018-02-14 14:40:16 --> Controller Class Initialized
INFO - 2018-02-14 14:40:16 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-14 14:40:16 --> Model Class Initialized
DEBUG - 2018-02-14 14:40:16 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-14 14:40:16 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-02-14 14:40:16 --> Upload Class Initialized
INFO - 2018-02-14 14:40:16 --> Config Class Initialized
INFO - 2018-02-14 14:40:16 --> Hooks Class Initialized
DEBUG - 2018-02-14 14:40:16 --> UTF-8 Support Enabled
INFO - 2018-02-14 14:40:16 --> Utf8 Class Initialized
INFO - 2018-02-14 14:40:16 --> URI Class Initialized
INFO - 2018-02-14 14:40:16 --> Router Class Initialized
INFO - 2018-02-14 14:40:16 --> Output Class Initialized
INFO - 2018-02-14 14:40:16 --> Security Class Initialized
DEBUG - 2018-02-14 14:40:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 14:40:16 --> Input Class Initialized
INFO - 2018-02-14 14:40:16 --> Language Class Initialized
INFO - 2018-02-14 14:40:16 --> Loader Class Initialized
INFO - 2018-02-14 14:40:16 --> Helper loaded: url_helper
INFO - 2018-02-14 14:40:16 --> Helper loaded: file_helper
INFO - 2018-02-14 14:40:16 --> Helper loaded: email_helper
INFO - 2018-02-14 14:40:16 --> Helper loaded: common_helper
INFO - 2018-02-14 14:40:16 --> Database Driver Class Initialized
DEBUG - 2018-02-14 14:40:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 14:40:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 14:40:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-14 14:40:16 --> Pagination Class Initialized
INFO - 2018-02-14 14:40:16 --> Helper loaded: form_helper
INFO - 2018-02-14 14:40:16 --> Form Validation Class Initialized
INFO - 2018-02-14 14:40:16 --> Model Class Initialized
INFO - 2018-02-14 14:40:16 --> Controller Class Initialized
INFO - 2018-02-14 14:40:16 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-14 14:40:16 --> Model Class Initialized
INFO - 2018-02-14 14:40:16 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-14 14:40:16 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-14 14:40:16 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-14 14:40:16 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-14 14:40:16 --> File loaded: /var/www/html/project/radio/application/views/category/index.php
INFO - 2018-02-14 14:40:16 --> Final output sent to browser
DEBUG - 2018-02-14 14:40:16 --> Total execution time: 0.0055
INFO - 2018-02-14 14:41:26 --> Config Class Initialized
INFO - 2018-02-14 14:41:26 --> Hooks Class Initialized
DEBUG - 2018-02-14 14:41:26 --> UTF-8 Support Enabled
INFO - 2018-02-14 14:41:26 --> Utf8 Class Initialized
INFO - 2018-02-14 14:41:26 --> URI Class Initialized
INFO - 2018-02-14 14:41:26 --> Router Class Initialized
INFO - 2018-02-14 14:41:26 --> Output Class Initialized
INFO - 2018-02-14 14:41:26 --> Security Class Initialized
DEBUG - 2018-02-14 14:41:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 14:41:26 --> Input Class Initialized
INFO - 2018-02-14 14:41:26 --> Language Class Initialized
INFO - 2018-02-14 14:41:26 --> Loader Class Initialized
INFO - 2018-02-14 14:41:26 --> Helper loaded: url_helper
INFO - 2018-02-14 14:41:26 --> Helper loaded: file_helper
INFO - 2018-02-14 14:41:26 --> Helper loaded: email_helper
INFO - 2018-02-14 14:41:26 --> Helper loaded: common_helper
INFO - 2018-02-14 14:41:26 --> Database Driver Class Initialized
DEBUG - 2018-02-14 14:41:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 14:41:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 14:41:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-14 14:41:26 --> Pagination Class Initialized
INFO - 2018-02-14 14:41:26 --> Helper loaded: form_helper
INFO - 2018-02-14 14:41:26 --> Form Validation Class Initialized
INFO - 2018-02-14 14:41:26 --> Model Class Initialized
INFO - 2018-02-14 14:41:26 --> Controller Class Initialized
INFO - 2018-02-14 14:41:26 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-14 14:41:26 --> Model Class Initialized
INFO - 2018-02-14 14:41:26 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-14 14:41:26 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-14 14:41:26 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-14 14:41:26 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-14 14:41:26 --> File loaded: /var/www/html/project/radio/application/views/category/index.php
INFO - 2018-02-14 14:41:26 --> Final output sent to browser
DEBUG - 2018-02-14 14:41:26 --> Total execution time: 0.0069
INFO - 2018-02-14 14:42:05 --> Config Class Initialized
INFO - 2018-02-14 14:42:05 --> Hooks Class Initialized
DEBUG - 2018-02-14 14:42:05 --> UTF-8 Support Enabled
INFO - 2018-02-14 14:42:05 --> Utf8 Class Initialized
INFO - 2018-02-14 14:42:05 --> URI Class Initialized
INFO - 2018-02-14 14:42:05 --> Router Class Initialized
INFO - 2018-02-14 14:42:05 --> Output Class Initialized
INFO - 2018-02-14 14:42:05 --> Security Class Initialized
DEBUG - 2018-02-14 14:42:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 14:42:05 --> Input Class Initialized
INFO - 2018-02-14 14:42:05 --> Language Class Initialized
INFO - 2018-02-14 14:42:05 --> Loader Class Initialized
INFO - 2018-02-14 14:42:05 --> Helper loaded: url_helper
INFO - 2018-02-14 14:42:05 --> Helper loaded: file_helper
INFO - 2018-02-14 14:42:05 --> Helper loaded: email_helper
INFO - 2018-02-14 14:42:05 --> Helper loaded: common_helper
INFO - 2018-02-14 14:42:05 --> Database Driver Class Initialized
DEBUG - 2018-02-14 14:42:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 14:42:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 14:42:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-14 14:42:05 --> Pagination Class Initialized
INFO - 2018-02-14 14:42:05 --> Helper loaded: form_helper
INFO - 2018-02-14 14:42:05 --> Form Validation Class Initialized
INFO - 2018-02-14 14:42:05 --> Model Class Initialized
INFO - 2018-02-14 14:42:05 --> Controller Class Initialized
INFO - 2018-02-14 14:42:05 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-14 14:42:05 --> Model Class Initialized
INFO - 2018-02-14 14:42:05 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-14 14:42:05 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-14 14:42:05 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-14 14:42:05 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-14 14:42:05 --> File loaded: /var/www/html/project/radio/application/views/category/index.php
INFO - 2018-02-14 14:42:05 --> Final output sent to browser
DEBUG - 2018-02-14 14:42:05 --> Total execution time: 0.0065
INFO - 2018-02-14 14:42:23 --> Config Class Initialized
INFO - 2018-02-14 14:42:23 --> Hooks Class Initialized
DEBUG - 2018-02-14 14:42:23 --> UTF-8 Support Enabled
INFO - 2018-02-14 14:42:23 --> Utf8 Class Initialized
INFO - 2018-02-14 14:42:23 --> URI Class Initialized
INFO - 2018-02-14 14:42:23 --> Router Class Initialized
INFO - 2018-02-14 14:42:23 --> Output Class Initialized
INFO - 2018-02-14 14:42:23 --> Security Class Initialized
DEBUG - 2018-02-14 14:42:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 14:42:23 --> Input Class Initialized
INFO - 2018-02-14 14:42:23 --> Language Class Initialized
INFO - 2018-02-14 14:42:23 --> Loader Class Initialized
INFO - 2018-02-14 14:42:23 --> Helper loaded: url_helper
INFO - 2018-02-14 14:42:23 --> Helper loaded: file_helper
INFO - 2018-02-14 14:42:23 --> Helper loaded: email_helper
INFO - 2018-02-14 14:42:23 --> Helper loaded: common_helper
INFO - 2018-02-14 14:42:23 --> Database Driver Class Initialized
DEBUG - 2018-02-14 14:42:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 14:42:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 14:42:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-14 14:42:23 --> Pagination Class Initialized
INFO - 2018-02-14 14:42:23 --> Helper loaded: form_helper
INFO - 2018-02-14 14:42:23 --> Form Validation Class Initialized
INFO - 2018-02-14 14:42:23 --> Model Class Initialized
INFO - 2018-02-14 14:42:23 --> Controller Class Initialized
INFO - 2018-02-14 14:42:23 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-14 14:42:23 --> Model Class Initialized
INFO - 2018-02-14 14:42:23 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-14 14:42:23 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-14 14:42:23 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-14 14:42:23 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-14 14:42:23 --> File loaded: /var/www/html/project/radio/application/views/category/index.php
INFO - 2018-02-14 14:42:23 --> Final output sent to browser
DEBUG - 2018-02-14 14:42:23 --> Total execution time: 0.0068
INFO - 2018-02-14 14:42:29 --> Config Class Initialized
INFO - 2018-02-14 14:42:29 --> Hooks Class Initialized
DEBUG - 2018-02-14 14:42:29 --> UTF-8 Support Enabled
INFO - 2018-02-14 14:42:29 --> Utf8 Class Initialized
INFO - 2018-02-14 14:42:29 --> URI Class Initialized
INFO - 2018-02-14 14:42:29 --> Router Class Initialized
INFO - 2018-02-14 14:42:29 --> Output Class Initialized
INFO - 2018-02-14 14:42:29 --> Security Class Initialized
DEBUG - 2018-02-14 14:42:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 14:42:29 --> Input Class Initialized
INFO - 2018-02-14 14:42:29 --> Language Class Initialized
INFO - 2018-02-14 14:42:29 --> Loader Class Initialized
INFO - 2018-02-14 14:42:29 --> Helper loaded: url_helper
INFO - 2018-02-14 14:42:29 --> Helper loaded: file_helper
INFO - 2018-02-14 14:42:29 --> Helper loaded: email_helper
INFO - 2018-02-14 14:42:29 --> Helper loaded: common_helper
INFO - 2018-02-14 14:42:29 --> Database Driver Class Initialized
DEBUG - 2018-02-14 14:42:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 14:42:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 14:42:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-14 14:42:29 --> Pagination Class Initialized
INFO - 2018-02-14 14:42:29 --> Helper loaded: form_helper
INFO - 2018-02-14 14:42:29 --> Form Validation Class Initialized
INFO - 2018-02-14 14:42:29 --> Model Class Initialized
INFO - 2018-02-14 14:42:29 --> Controller Class Initialized
INFO - 2018-02-14 14:42:29 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-14 14:42:29 --> Model Class Initialized
INFO - 2018-02-14 14:42:29 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-14 14:42:29 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-14 14:42:29 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-14 14:42:29 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-14 14:42:29 --> File loaded: /var/www/html/project/radio/application/views/category/index.php
INFO - 2018-02-14 14:42:29 --> Final output sent to browser
DEBUG - 2018-02-14 14:42:29 --> Total execution time: 0.0098
INFO - 2018-02-14 14:46:28 --> Config Class Initialized
INFO - 2018-02-14 14:46:28 --> Hooks Class Initialized
DEBUG - 2018-02-14 14:46:28 --> UTF-8 Support Enabled
INFO - 2018-02-14 14:46:28 --> Utf8 Class Initialized
INFO - 2018-02-14 14:46:28 --> URI Class Initialized
INFO - 2018-02-14 14:46:28 --> Router Class Initialized
INFO - 2018-02-14 14:46:28 --> Output Class Initialized
INFO - 2018-02-14 14:46:28 --> Security Class Initialized
DEBUG - 2018-02-14 14:46:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 14:46:28 --> Input Class Initialized
INFO - 2018-02-14 14:46:28 --> Language Class Initialized
INFO - 2018-02-14 14:46:28 --> Loader Class Initialized
INFO - 2018-02-14 14:46:28 --> Helper loaded: url_helper
INFO - 2018-02-14 14:46:28 --> Helper loaded: file_helper
INFO - 2018-02-14 14:46:28 --> Helper loaded: email_helper
INFO - 2018-02-14 14:46:28 --> Helper loaded: common_helper
INFO - 2018-02-14 14:46:28 --> Database Driver Class Initialized
DEBUG - 2018-02-14 14:46:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 14:46:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 14:46:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-14 14:46:28 --> Pagination Class Initialized
INFO - 2018-02-14 14:46:28 --> Helper loaded: form_helper
INFO - 2018-02-14 14:46:28 --> Form Validation Class Initialized
INFO - 2018-02-14 14:46:28 --> Model Class Initialized
INFO - 2018-02-14 14:46:28 --> Controller Class Initialized
INFO - 2018-02-14 14:46:28 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-14 14:46:28 --> Model Class Initialized
INFO - 2018-02-14 14:46:28 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-14 14:46:28 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-14 14:46:28 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-14 14:46:28 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-14 14:46:28 --> File loaded: /var/www/html/project/radio/application/views/category/index.php
INFO - 2018-02-14 14:46:28 --> Final output sent to browser
DEBUG - 2018-02-14 14:46:28 --> Total execution time: 0.0074
INFO - 2018-02-14 14:52:46 --> Config Class Initialized
INFO - 2018-02-14 14:52:46 --> Hooks Class Initialized
DEBUG - 2018-02-14 14:52:46 --> UTF-8 Support Enabled
INFO - 2018-02-14 14:52:46 --> Utf8 Class Initialized
INFO - 2018-02-14 14:52:46 --> URI Class Initialized
INFO - 2018-02-14 14:52:46 --> Router Class Initialized
INFO - 2018-02-14 14:52:46 --> Output Class Initialized
INFO - 2018-02-14 14:52:46 --> Security Class Initialized
DEBUG - 2018-02-14 14:52:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 14:52:46 --> Input Class Initialized
INFO - 2018-02-14 14:52:46 --> Language Class Initialized
INFO - 2018-02-14 14:52:46 --> Loader Class Initialized
INFO - 2018-02-14 14:52:46 --> Helper loaded: url_helper
INFO - 2018-02-14 14:52:46 --> Helper loaded: file_helper
INFO - 2018-02-14 14:52:46 --> Helper loaded: email_helper
INFO - 2018-02-14 14:52:46 --> Helper loaded: common_helper
INFO - 2018-02-14 14:52:46 --> Database Driver Class Initialized
DEBUG - 2018-02-14 14:52:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 14:52:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 14:52:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-14 14:52:46 --> Pagination Class Initialized
INFO - 2018-02-14 14:52:46 --> Helper loaded: form_helper
INFO - 2018-02-14 14:52:46 --> Form Validation Class Initialized
INFO - 2018-02-14 14:52:46 --> Model Class Initialized
INFO - 2018-02-14 14:52:46 --> Controller Class Initialized
INFO - 2018-02-14 14:52:46 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-14 14:52:46 --> Model Class Initialized
INFO - 2018-02-14 14:52:46 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-14 14:52:46 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-14 14:52:46 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-14 14:52:46 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-14 14:52:46 --> File loaded: /var/www/html/project/radio/application/views/category/index.php
INFO - 2018-02-14 14:52:46 --> Final output sent to browser
DEBUG - 2018-02-14 14:52:46 --> Total execution time: 0.0077
INFO - 2018-02-14 14:52:47 --> Config Class Initialized
INFO - 2018-02-14 14:52:47 --> Hooks Class Initialized
DEBUG - 2018-02-14 14:52:47 --> UTF-8 Support Enabled
INFO - 2018-02-14 14:52:47 --> Utf8 Class Initialized
INFO - 2018-02-14 14:52:47 --> URI Class Initialized
INFO - 2018-02-14 14:52:47 --> Router Class Initialized
INFO - 2018-02-14 14:52:47 --> Output Class Initialized
INFO - 2018-02-14 14:52:47 --> Security Class Initialized
DEBUG - 2018-02-14 14:52:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 14:52:47 --> Input Class Initialized
INFO - 2018-02-14 14:52:47 --> Language Class Initialized
INFO - 2018-02-14 14:52:47 --> Loader Class Initialized
INFO - 2018-02-14 14:52:47 --> Helper loaded: url_helper
INFO - 2018-02-14 14:52:47 --> Helper loaded: file_helper
INFO - 2018-02-14 14:52:47 --> Helper loaded: email_helper
INFO - 2018-02-14 14:52:47 --> Helper loaded: common_helper
INFO - 2018-02-14 14:52:47 --> Database Driver Class Initialized
DEBUG - 2018-02-14 14:52:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 14:52:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 14:52:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-14 14:52:47 --> Pagination Class Initialized
INFO - 2018-02-14 14:52:47 --> Helper loaded: form_helper
INFO - 2018-02-14 14:52:47 --> Form Validation Class Initialized
INFO - 2018-02-14 14:52:47 --> Model Class Initialized
INFO - 2018-02-14 14:52:47 --> Controller Class Initialized
INFO - 2018-02-14 14:52:47 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-14 14:52:47 --> Model Class Initialized
INFO - 2018-02-14 14:52:47 --> Config Class Initialized
INFO - 2018-02-14 14:52:47 --> Hooks Class Initialized
DEBUG - 2018-02-14 14:52:47 --> UTF-8 Support Enabled
INFO - 2018-02-14 14:52:47 --> Utf8 Class Initialized
INFO - 2018-02-14 14:52:47 --> URI Class Initialized
INFO - 2018-02-14 14:52:47 --> Router Class Initialized
INFO - 2018-02-14 14:52:47 --> Output Class Initialized
INFO - 2018-02-14 14:52:47 --> Security Class Initialized
DEBUG - 2018-02-14 14:52:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 14:52:47 --> Input Class Initialized
INFO - 2018-02-14 14:52:47 --> Language Class Initialized
INFO - 2018-02-14 14:52:47 --> Loader Class Initialized
INFO - 2018-02-14 14:52:47 --> Helper loaded: url_helper
INFO - 2018-02-14 14:52:47 --> Helper loaded: file_helper
INFO - 2018-02-14 14:52:47 --> Helper loaded: email_helper
INFO - 2018-02-14 14:52:47 --> Helper loaded: common_helper
INFO - 2018-02-14 14:52:47 --> Database Driver Class Initialized
DEBUG - 2018-02-14 14:52:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 14:52:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 14:52:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-14 14:52:47 --> Pagination Class Initialized
INFO - 2018-02-14 14:52:47 --> Helper loaded: form_helper
INFO - 2018-02-14 14:52:47 --> Form Validation Class Initialized
INFO - 2018-02-14 14:52:47 --> Model Class Initialized
INFO - 2018-02-14 14:52:47 --> Controller Class Initialized
INFO - 2018-02-14 14:52:47 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-14 14:52:47 --> Model Class Initialized
INFO - 2018-02-14 14:52:47 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-14 14:52:47 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-14 14:52:47 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-14 14:52:47 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-14 14:52:47 --> File loaded: /var/www/html/project/radio/application/views/category/index.php
INFO - 2018-02-14 14:52:47 --> Final output sent to browser
DEBUG - 2018-02-14 14:52:47 --> Total execution time: 0.0050
INFO - 2018-02-14 14:52:53 --> Config Class Initialized
INFO - 2018-02-14 14:52:53 --> Hooks Class Initialized
DEBUG - 2018-02-14 14:52:53 --> UTF-8 Support Enabled
INFO - 2018-02-14 14:52:53 --> Utf8 Class Initialized
INFO - 2018-02-14 14:52:53 --> URI Class Initialized
INFO - 2018-02-14 14:52:53 --> Router Class Initialized
INFO - 2018-02-14 14:52:53 --> Output Class Initialized
INFO - 2018-02-14 14:52:53 --> Security Class Initialized
DEBUG - 2018-02-14 14:52:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 14:52:53 --> Input Class Initialized
INFO - 2018-02-14 14:52:53 --> Language Class Initialized
INFO - 2018-02-14 14:52:53 --> Loader Class Initialized
INFO - 2018-02-14 14:52:53 --> Helper loaded: url_helper
INFO - 2018-02-14 14:52:53 --> Helper loaded: file_helper
INFO - 2018-02-14 14:52:53 --> Helper loaded: email_helper
INFO - 2018-02-14 14:52:53 --> Helper loaded: common_helper
INFO - 2018-02-14 14:52:53 --> Database Driver Class Initialized
DEBUG - 2018-02-14 14:52:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 14:52:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 14:52:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-14 14:52:53 --> Pagination Class Initialized
INFO - 2018-02-14 14:52:53 --> Helper loaded: form_helper
INFO - 2018-02-14 14:52:53 --> Form Validation Class Initialized
INFO - 2018-02-14 14:52:53 --> Model Class Initialized
INFO - 2018-02-14 14:52:53 --> Controller Class Initialized
INFO - 2018-02-14 14:52:53 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-14 14:52:53 --> Model Class Initialized
INFO - 2018-02-14 14:52:53 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-14 14:52:53 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-14 14:52:53 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-14 14:52:53 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-14 14:52:53 --> File loaded: /var/www/html/project/radio/application/views/category/index.php
INFO - 2018-02-14 14:52:53 --> Final output sent to browser
DEBUG - 2018-02-14 14:52:53 --> Total execution time: 0.0055
INFO - 2018-02-14 14:52:54 --> Config Class Initialized
INFO - 2018-02-14 14:52:54 --> Hooks Class Initialized
DEBUG - 2018-02-14 14:52:54 --> UTF-8 Support Enabled
INFO - 2018-02-14 14:52:54 --> Utf8 Class Initialized
INFO - 2018-02-14 14:52:54 --> URI Class Initialized
INFO - 2018-02-14 14:52:54 --> Router Class Initialized
INFO - 2018-02-14 14:52:54 --> Output Class Initialized
INFO - 2018-02-14 14:52:54 --> Security Class Initialized
DEBUG - 2018-02-14 14:52:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 14:52:54 --> Input Class Initialized
INFO - 2018-02-14 14:52:54 --> Language Class Initialized
INFO - 2018-02-14 14:52:54 --> Loader Class Initialized
INFO - 2018-02-14 14:52:54 --> Helper loaded: url_helper
INFO - 2018-02-14 14:52:54 --> Helper loaded: file_helper
INFO - 2018-02-14 14:52:54 --> Helper loaded: email_helper
INFO - 2018-02-14 14:52:54 --> Helper loaded: common_helper
INFO - 2018-02-14 14:52:54 --> Database Driver Class Initialized
DEBUG - 2018-02-14 14:52:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 14:52:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 14:52:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-14 14:52:54 --> Pagination Class Initialized
INFO - 2018-02-14 14:52:54 --> Helper loaded: form_helper
INFO - 2018-02-14 14:52:54 --> Form Validation Class Initialized
INFO - 2018-02-14 14:52:54 --> Model Class Initialized
INFO - 2018-02-14 14:52:54 --> Controller Class Initialized
INFO - 2018-02-14 14:52:54 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-14 14:52:54 --> Model Class Initialized
INFO - 2018-02-14 14:52:54 --> Config Class Initialized
INFO - 2018-02-14 14:52:54 --> Hooks Class Initialized
DEBUG - 2018-02-14 14:52:54 --> UTF-8 Support Enabled
INFO - 2018-02-14 14:52:54 --> Utf8 Class Initialized
INFO - 2018-02-14 14:52:54 --> URI Class Initialized
INFO - 2018-02-14 14:52:54 --> Router Class Initialized
INFO - 2018-02-14 14:52:54 --> Output Class Initialized
INFO - 2018-02-14 14:52:54 --> Security Class Initialized
DEBUG - 2018-02-14 14:52:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 14:52:54 --> Input Class Initialized
INFO - 2018-02-14 14:52:54 --> Language Class Initialized
INFO - 2018-02-14 14:52:54 --> Loader Class Initialized
INFO - 2018-02-14 14:52:54 --> Helper loaded: url_helper
INFO - 2018-02-14 14:52:54 --> Helper loaded: file_helper
INFO - 2018-02-14 14:52:54 --> Helper loaded: email_helper
INFO - 2018-02-14 14:52:54 --> Helper loaded: common_helper
INFO - 2018-02-14 14:52:54 --> Database Driver Class Initialized
DEBUG - 2018-02-14 14:52:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 14:52:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 14:52:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-14 14:52:54 --> Pagination Class Initialized
INFO - 2018-02-14 14:52:54 --> Helper loaded: form_helper
INFO - 2018-02-14 14:52:54 --> Form Validation Class Initialized
INFO - 2018-02-14 14:52:54 --> Model Class Initialized
INFO - 2018-02-14 14:52:54 --> Controller Class Initialized
INFO - 2018-02-14 14:52:54 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-14 14:52:54 --> Model Class Initialized
INFO - 2018-02-14 14:52:54 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-14 14:52:54 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-14 14:52:54 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-14 14:52:54 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-14 14:52:54 --> File loaded: /var/www/html/project/radio/application/views/category/index.php
INFO - 2018-02-14 14:52:54 --> Final output sent to browser
DEBUG - 2018-02-14 14:52:54 --> Total execution time: 0.0040
INFO - 2018-02-14 14:53:13 --> Config Class Initialized
INFO - 2018-02-14 14:53:13 --> Hooks Class Initialized
DEBUG - 2018-02-14 14:53:13 --> UTF-8 Support Enabled
INFO - 2018-02-14 14:53:13 --> Utf8 Class Initialized
INFO - 2018-02-14 14:53:13 --> URI Class Initialized
INFO - 2018-02-14 14:53:13 --> Router Class Initialized
INFO - 2018-02-14 14:53:13 --> Output Class Initialized
INFO - 2018-02-14 14:53:13 --> Security Class Initialized
DEBUG - 2018-02-14 14:53:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 14:53:13 --> Input Class Initialized
INFO - 2018-02-14 14:53:13 --> Language Class Initialized
INFO - 2018-02-14 14:53:13 --> Loader Class Initialized
INFO - 2018-02-14 14:53:13 --> Helper loaded: url_helper
INFO - 2018-02-14 14:53:13 --> Helper loaded: file_helper
INFO - 2018-02-14 14:53:13 --> Helper loaded: email_helper
INFO - 2018-02-14 14:53:13 --> Helper loaded: common_helper
INFO - 2018-02-14 14:53:13 --> Database Driver Class Initialized
DEBUG - 2018-02-14 14:53:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 14:53:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 14:53:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-14 14:53:13 --> Pagination Class Initialized
INFO - 2018-02-14 14:53:13 --> Helper loaded: form_helper
INFO - 2018-02-14 14:53:13 --> Form Validation Class Initialized
INFO - 2018-02-14 14:53:13 --> Model Class Initialized
INFO - 2018-02-14 14:53:13 --> Controller Class Initialized
INFO - 2018-02-14 14:53:13 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-14 14:53:13 --> Model Class Initialized
INFO - 2018-02-14 14:53:29 --> Config Class Initialized
INFO - 2018-02-14 14:53:29 --> Hooks Class Initialized
DEBUG - 2018-02-14 14:53:29 --> UTF-8 Support Enabled
INFO - 2018-02-14 14:53:29 --> Utf8 Class Initialized
INFO - 2018-02-14 14:53:29 --> URI Class Initialized
INFO - 2018-02-14 14:53:29 --> Router Class Initialized
INFO - 2018-02-14 14:53:29 --> Output Class Initialized
INFO - 2018-02-14 14:53:29 --> Security Class Initialized
DEBUG - 2018-02-14 14:53:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 14:53:29 --> Input Class Initialized
INFO - 2018-02-14 14:53:29 --> Language Class Initialized
INFO - 2018-02-14 14:53:29 --> Loader Class Initialized
INFO - 2018-02-14 14:53:29 --> Helper loaded: url_helper
INFO - 2018-02-14 14:53:29 --> Helper loaded: file_helper
INFO - 2018-02-14 14:53:29 --> Helper loaded: email_helper
INFO - 2018-02-14 14:53:29 --> Helper loaded: common_helper
INFO - 2018-02-14 14:53:29 --> Database Driver Class Initialized
DEBUG - 2018-02-14 14:53:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 14:53:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 14:53:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-14 14:53:29 --> Pagination Class Initialized
INFO - 2018-02-14 14:53:29 --> Helper loaded: form_helper
INFO - 2018-02-14 14:53:29 --> Form Validation Class Initialized
INFO - 2018-02-14 14:53:29 --> Model Class Initialized
INFO - 2018-02-14 14:53:29 --> Controller Class Initialized
INFO - 2018-02-14 14:53:29 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-14 14:53:29 --> Model Class Initialized
INFO - 2018-02-14 14:53:29 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-14 14:53:29 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-14 14:53:29 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-14 14:53:29 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-14 14:53:29 --> File loaded: /var/www/html/project/radio/application/views/category/index.php
INFO - 2018-02-14 14:53:29 --> Final output sent to browser
DEBUG - 2018-02-14 14:53:29 --> Total execution time: 0.0064
INFO - 2018-02-14 14:53:31 --> Config Class Initialized
INFO - 2018-02-14 14:53:31 --> Hooks Class Initialized
DEBUG - 2018-02-14 14:53:31 --> UTF-8 Support Enabled
INFO - 2018-02-14 14:53:31 --> Utf8 Class Initialized
INFO - 2018-02-14 14:53:31 --> URI Class Initialized
INFO - 2018-02-14 14:53:31 --> Router Class Initialized
INFO - 2018-02-14 14:53:31 --> Output Class Initialized
INFO - 2018-02-14 14:53:31 --> Security Class Initialized
DEBUG - 2018-02-14 14:53:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 14:53:31 --> Input Class Initialized
INFO - 2018-02-14 14:53:31 --> Language Class Initialized
INFO - 2018-02-14 14:53:31 --> Loader Class Initialized
INFO - 2018-02-14 14:53:31 --> Helper loaded: url_helper
INFO - 2018-02-14 14:53:31 --> Helper loaded: file_helper
INFO - 2018-02-14 14:53:31 --> Helper loaded: email_helper
INFO - 2018-02-14 14:53:31 --> Helper loaded: common_helper
INFO - 2018-02-14 14:53:31 --> Database Driver Class Initialized
DEBUG - 2018-02-14 14:53:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 14:53:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 14:53:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-14 14:53:31 --> Pagination Class Initialized
INFO - 2018-02-14 14:53:31 --> Helper loaded: form_helper
INFO - 2018-02-14 14:53:31 --> Form Validation Class Initialized
INFO - 2018-02-14 14:53:31 --> Model Class Initialized
INFO - 2018-02-14 14:53:31 --> Controller Class Initialized
INFO - 2018-02-14 14:53:31 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-14 14:53:31 --> Model Class Initialized
INFO - 2018-02-14 14:53:31 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-14 14:53:31 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-14 14:53:31 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-14 14:53:31 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-14 14:53:31 --> File loaded: /var/www/html/project/radio/application/views/category/index.php
INFO - 2018-02-14 14:53:31 --> Final output sent to browser
DEBUG - 2018-02-14 14:53:31 --> Total execution time: 0.0050
INFO - 2018-02-14 14:53:53 --> Config Class Initialized
INFO - 2018-02-14 14:53:53 --> Hooks Class Initialized
DEBUG - 2018-02-14 14:53:53 --> UTF-8 Support Enabled
INFO - 2018-02-14 14:53:53 --> Utf8 Class Initialized
INFO - 2018-02-14 14:53:53 --> URI Class Initialized
INFO - 2018-02-14 14:53:53 --> Router Class Initialized
INFO - 2018-02-14 14:53:53 --> Output Class Initialized
INFO - 2018-02-14 14:53:53 --> Security Class Initialized
DEBUG - 2018-02-14 14:53:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 14:53:53 --> Input Class Initialized
INFO - 2018-02-14 14:53:53 --> Language Class Initialized
INFO - 2018-02-14 14:53:53 --> Loader Class Initialized
INFO - 2018-02-14 14:53:53 --> Helper loaded: url_helper
INFO - 2018-02-14 14:53:53 --> Helper loaded: file_helper
INFO - 2018-02-14 14:53:53 --> Helper loaded: email_helper
INFO - 2018-02-14 14:53:53 --> Helper loaded: common_helper
INFO - 2018-02-14 14:53:53 --> Database Driver Class Initialized
DEBUG - 2018-02-14 14:53:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 14:53:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 14:53:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-14 14:53:53 --> Pagination Class Initialized
INFO - 2018-02-14 14:53:53 --> Helper loaded: form_helper
INFO - 2018-02-14 14:53:53 --> Form Validation Class Initialized
INFO - 2018-02-14 14:53:53 --> Model Class Initialized
INFO - 2018-02-14 14:53:53 --> Controller Class Initialized
INFO - 2018-02-14 14:53:53 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-14 14:53:53 --> Model Class Initialized
INFO - 2018-02-14 14:53:53 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-14 14:53:53 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-14 14:53:53 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-14 14:53:53 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-14 14:53:53 --> File loaded: /var/www/html/project/radio/application/views/category/index.php
INFO - 2018-02-14 14:53:53 --> Final output sent to browser
DEBUG - 2018-02-14 14:53:53 --> Total execution time: 0.0067
INFO - 2018-02-14 14:53:55 --> Config Class Initialized
INFO - 2018-02-14 14:53:55 --> Hooks Class Initialized
DEBUG - 2018-02-14 14:53:55 --> UTF-8 Support Enabled
INFO - 2018-02-14 14:53:55 --> Utf8 Class Initialized
INFO - 2018-02-14 14:53:55 --> URI Class Initialized
INFO - 2018-02-14 14:53:55 --> Router Class Initialized
INFO - 2018-02-14 14:53:55 --> Output Class Initialized
INFO - 2018-02-14 14:53:55 --> Security Class Initialized
DEBUG - 2018-02-14 14:53:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 14:53:55 --> Input Class Initialized
INFO - 2018-02-14 14:53:55 --> Language Class Initialized
INFO - 2018-02-14 14:53:55 --> Loader Class Initialized
INFO - 2018-02-14 14:53:55 --> Helper loaded: url_helper
INFO - 2018-02-14 14:53:55 --> Helper loaded: file_helper
INFO - 2018-02-14 14:53:55 --> Helper loaded: email_helper
INFO - 2018-02-14 14:53:55 --> Helper loaded: common_helper
INFO - 2018-02-14 14:53:55 --> Database Driver Class Initialized
DEBUG - 2018-02-14 14:53:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 14:53:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 14:53:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-14 14:53:55 --> Pagination Class Initialized
INFO - 2018-02-14 14:53:55 --> Helper loaded: form_helper
INFO - 2018-02-14 14:53:55 --> Form Validation Class Initialized
INFO - 2018-02-14 14:53:55 --> Model Class Initialized
INFO - 2018-02-14 14:53:55 --> Controller Class Initialized
INFO - 2018-02-14 14:53:55 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-14 14:53:55 --> Model Class Initialized
INFO - 2018-02-14 14:54:01 --> Config Class Initialized
INFO - 2018-02-14 14:54:01 --> Hooks Class Initialized
DEBUG - 2018-02-14 14:54:01 --> UTF-8 Support Enabled
INFO - 2018-02-14 14:54:01 --> Utf8 Class Initialized
INFO - 2018-02-14 14:54:01 --> URI Class Initialized
INFO - 2018-02-14 14:54:01 --> Router Class Initialized
INFO - 2018-02-14 14:54:01 --> Output Class Initialized
INFO - 2018-02-14 14:54:01 --> Security Class Initialized
DEBUG - 2018-02-14 14:54:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 14:54:01 --> Input Class Initialized
INFO - 2018-02-14 14:54:01 --> Language Class Initialized
INFO - 2018-02-14 14:54:01 --> Loader Class Initialized
INFO - 2018-02-14 14:54:01 --> Helper loaded: url_helper
INFO - 2018-02-14 14:54:01 --> Helper loaded: file_helper
INFO - 2018-02-14 14:54:01 --> Helper loaded: email_helper
INFO - 2018-02-14 14:54:01 --> Helper loaded: common_helper
INFO - 2018-02-14 14:54:01 --> Database Driver Class Initialized
DEBUG - 2018-02-14 14:54:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 14:54:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 14:54:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-14 14:54:01 --> Pagination Class Initialized
INFO - 2018-02-14 14:54:01 --> Helper loaded: form_helper
INFO - 2018-02-14 14:54:01 --> Form Validation Class Initialized
INFO - 2018-02-14 14:54:01 --> Model Class Initialized
INFO - 2018-02-14 14:54:01 --> Controller Class Initialized
INFO - 2018-02-14 14:54:01 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-14 14:54:01 --> Model Class Initialized
ERROR - 2018-02-14 14:54:01 --> Severity: Warning --> Missing argument 1 for Category::edit(), called in /var/www/html/project/radio/system/core/CodeIgniter.php on line 532 and defined /var/www/html/project/radio/application/controllers/Category.php 102
ERROR - 2018-02-14 14:54:01 --> Severity: Notice --> Undefined variable: Id /var/www/html/project/radio/application/controllers/Category.php 104
INFO - 2018-02-14 14:54:01 --> Config Class Initialized
INFO - 2018-02-14 14:54:01 --> Hooks Class Initialized
DEBUG - 2018-02-14 14:54:01 --> UTF-8 Support Enabled
INFO - 2018-02-14 14:54:01 --> Utf8 Class Initialized
INFO - 2018-02-14 14:54:01 --> URI Class Initialized
INFO - 2018-02-14 14:54:01 --> Router Class Initialized
INFO - 2018-02-14 14:54:01 --> Output Class Initialized
INFO - 2018-02-14 14:54:01 --> Security Class Initialized
DEBUG - 2018-02-14 14:54:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 14:54:01 --> Input Class Initialized
INFO - 2018-02-14 14:54:01 --> Language Class Initialized
INFO - 2018-02-14 14:54:01 --> Loader Class Initialized
INFO - 2018-02-14 14:54:01 --> Helper loaded: url_helper
INFO - 2018-02-14 14:54:01 --> Helper loaded: file_helper
INFO - 2018-02-14 14:54:01 --> Helper loaded: email_helper
INFO - 2018-02-14 14:54:01 --> Helper loaded: common_helper
INFO - 2018-02-14 14:54:01 --> Database Driver Class Initialized
DEBUG - 2018-02-14 14:54:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 14:54:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 14:54:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-14 14:54:01 --> Pagination Class Initialized
INFO - 2018-02-14 14:54:01 --> Helper loaded: form_helper
INFO - 2018-02-14 14:54:01 --> Form Validation Class Initialized
INFO - 2018-02-14 14:54:01 --> Model Class Initialized
INFO - 2018-02-14 14:54:01 --> Controller Class Initialized
INFO - 2018-02-14 14:54:01 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-14 14:54:01 --> Model Class Initialized
INFO - 2018-02-14 14:54:01 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-14 14:54:01 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-14 14:54:01 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-14 14:54:01 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-14 14:54:01 --> File loaded: /var/www/html/project/radio/application/views/category/index.php
INFO - 2018-02-14 14:54:01 --> Final output sent to browser
DEBUG - 2018-02-14 14:54:01 --> Total execution time: 0.0064
INFO - 2018-02-14 14:54:09 --> Config Class Initialized
INFO - 2018-02-14 14:54:09 --> Hooks Class Initialized
DEBUG - 2018-02-14 14:54:09 --> UTF-8 Support Enabled
INFO - 2018-02-14 14:54:09 --> Utf8 Class Initialized
INFO - 2018-02-14 14:54:09 --> URI Class Initialized
INFO - 2018-02-14 14:54:09 --> Router Class Initialized
INFO - 2018-02-14 14:54:09 --> Output Class Initialized
INFO - 2018-02-14 14:54:09 --> Security Class Initialized
DEBUG - 2018-02-14 14:54:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 14:54:09 --> Input Class Initialized
INFO - 2018-02-14 14:54:09 --> Language Class Initialized
INFO - 2018-02-14 14:54:09 --> Loader Class Initialized
INFO - 2018-02-14 14:54:09 --> Helper loaded: url_helper
INFO - 2018-02-14 14:54:09 --> Helper loaded: file_helper
INFO - 2018-02-14 14:54:09 --> Helper loaded: email_helper
INFO - 2018-02-14 14:54:09 --> Helper loaded: common_helper
INFO - 2018-02-14 14:54:09 --> Database Driver Class Initialized
DEBUG - 2018-02-14 14:54:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 14:54:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 14:54:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-14 14:54:09 --> Pagination Class Initialized
INFO - 2018-02-14 14:54:09 --> Helper loaded: form_helper
INFO - 2018-02-14 14:54:09 --> Form Validation Class Initialized
INFO - 2018-02-14 14:54:09 --> Model Class Initialized
INFO - 2018-02-14 14:54:09 --> Controller Class Initialized
INFO - 2018-02-14 14:54:09 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-14 14:54:09 --> Model Class Initialized
ERROR - 2018-02-14 14:54:09 --> Severity: Warning --> Missing argument 1 for Category::edit(), called in /var/www/html/project/radio/system/core/CodeIgniter.php on line 532 and defined /var/www/html/project/radio/application/controllers/Category.php 102
ERROR - 2018-02-14 14:54:09 --> Severity: Notice --> Undefined variable: Id /var/www/html/project/radio/application/controllers/Category.php 104
INFO - 2018-02-14 14:54:09 --> Config Class Initialized
INFO - 2018-02-14 14:54:09 --> Hooks Class Initialized
DEBUG - 2018-02-14 14:54:09 --> UTF-8 Support Enabled
INFO - 2018-02-14 14:54:09 --> Utf8 Class Initialized
INFO - 2018-02-14 14:54:09 --> URI Class Initialized
INFO - 2018-02-14 14:54:09 --> Router Class Initialized
INFO - 2018-02-14 14:54:09 --> Output Class Initialized
INFO - 2018-02-14 14:54:09 --> Security Class Initialized
DEBUG - 2018-02-14 14:54:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 14:54:09 --> Input Class Initialized
INFO - 2018-02-14 14:54:09 --> Language Class Initialized
INFO - 2018-02-14 14:54:09 --> Loader Class Initialized
INFO - 2018-02-14 14:54:09 --> Helper loaded: url_helper
INFO - 2018-02-14 14:54:09 --> Helper loaded: file_helper
INFO - 2018-02-14 14:54:09 --> Helper loaded: email_helper
INFO - 2018-02-14 14:54:09 --> Helper loaded: common_helper
INFO - 2018-02-14 14:54:09 --> Database Driver Class Initialized
DEBUG - 2018-02-14 14:54:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 14:54:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 14:54:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-14 14:54:09 --> Pagination Class Initialized
INFO - 2018-02-14 14:54:09 --> Helper loaded: form_helper
INFO - 2018-02-14 14:54:09 --> Form Validation Class Initialized
INFO - 2018-02-14 14:54:09 --> Model Class Initialized
INFO - 2018-02-14 14:54:09 --> Controller Class Initialized
INFO - 2018-02-14 14:54:09 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-14 14:54:09 --> Model Class Initialized
INFO - 2018-02-14 14:54:09 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-14 14:54:09 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-14 14:54:09 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-14 14:54:09 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-14 14:54:09 --> File loaded: /var/www/html/project/radio/application/views/category/index.php
INFO - 2018-02-14 14:54:09 --> Final output sent to browser
DEBUG - 2018-02-14 14:54:09 --> Total execution time: 0.0038
INFO - 2018-02-14 14:54:35 --> Config Class Initialized
INFO - 2018-02-14 14:54:35 --> Hooks Class Initialized
DEBUG - 2018-02-14 14:54:35 --> UTF-8 Support Enabled
INFO - 2018-02-14 14:54:35 --> Utf8 Class Initialized
INFO - 2018-02-14 14:54:35 --> URI Class Initialized
INFO - 2018-02-14 14:54:35 --> Router Class Initialized
INFO - 2018-02-14 14:54:35 --> Output Class Initialized
INFO - 2018-02-14 14:54:35 --> Security Class Initialized
DEBUG - 2018-02-14 14:54:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 14:54:35 --> Input Class Initialized
INFO - 2018-02-14 14:54:35 --> Language Class Initialized
INFO - 2018-02-14 14:54:35 --> Loader Class Initialized
INFO - 2018-02-14 14:54:35 --> Helper loaded: url_helper
INFO - 2018-02-14 14:54:35 --> Helper loaded: file_helper
INFO - 2018-02-14 14:54:35 --> Helper loaded: email_helper
INFO - 2018-02-14 14:54:35 --> Helper loaded: common_helper
INFO - 2018-02-14 14:54:35 --> Database Driver Class Initialized
DEBUG - 2018-02-14 14:54:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 14:54:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 14:54:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-14 14:54:35 --> Pagination Class Initialized
INFO - 2018-02-14 14:54:35 --> Helper loaded: form_helper
INFO - 2018-02-14 14:54:35 --> Form Validation Class Initialized
INFO - 2018-02-14 14:54:35 --> Model Class Initialized
INFO - 2018-02-14 14:54:35 --> Controller Class Initialized
INFO - 2018-02-14 14:54:35 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-14 14:54:35 --> Model Class Initialized
INFO - 2018-02-14 14:54:35 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-14 14:54:35 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-14 14:54:35 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-14 14:54:35 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-14 14:54:35 --> File loaded: /var/www/html/project/radio/application/views/category/index.php
INFO - 2018-02-14 14:54:35 --> Final output sent to browser
DEBUG - 2018-02-14 14:54:35 --> Total execution time: 0.0074
INFO - 2018-02-14 14:54:36 --> Config Class Initialized
INFO - 2018-02-14 14:54:36 --> Hooks Class Initialized
DEBUG - 2018-02-14 14:54:36 --> UTF-8 Support Enabled
INFO - 2018-02-14 14:54:36 --> Utf8 Class Initialized
INFO - 2018-02-14 14:54:36 --> URI Class Initialized
INFO - 2018-02-14 14:54:36 --> Router Class Initialized
INFO - 2018-02-14 14:54:36 --> Output Class Initialized
INFO - 2018-02-14 14:54:36 --> Security Class Initialized
DEBUG - 2018-02-14 14:54:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 14:54:36 --> Input Class Initialized
INFO - 2018-02-14 14:54:36 --> Language Class Initialized
INFO - 2018-02-14 14:54:36 --> Loader Class Initialized
INFO - 2018-02-14 14:54:36 --> Helper loaded: url_helper
INFO - 2018-02-14 14:54:36 --> Helper loaded: file_helper
INFO - 2018-02-14 14:54:36 --> Helper loaded: email_helper
INFO - 2018-02-14 14:54:36 --> Helper loaded: common_helper
INFO - 2018-02-14 14:54:36 --> Database Driver Class Initialized
DEBUG - 2018-02-14 14:54:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 14:54:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 14:54:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-14 14:54:36 --> Pagination Class Initialized
INFO - 2018-02-14 14:54:36 --> Helper loaded: form_helper
INFO - 2018-02-14 14:54:36 --> Form Validation Class Initialized
INFO - 2018-02-14 14:54:36 --> Model Class Initialized
INFO - 2018-02-14 14:54:36 --> Controller Class Initialized
INFO - 2018-02-14 14:54:36 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-14 14:54:36 --> Model Class Initialized
INFO - 2018-02-14 14:54:38 --> Config Class Initialized
INFO - 2018-02-14 14:54:38 --> Hooks Class Initialized
DEBUG - 2018-02-14 14:54:38 --> UTF-8 Support Enabled
INFO - 2018-02-14 14:54:38 --> Utf8 Class Initialized
INFO - 2018-02-14 14:54:38 --> URI Class Initialized
INFO - 2018-02-14 14:54:38 --> Router Class Initialized
INFO - 2018-02-14 14:54:38 --> Output Class Initialized
INFO - 2018-02-14 14:54:38 --> Security Class Initialized
DEBUG - 2018-02-14 14:54:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 14:54:38 --> Input Class Initialized
INFO - 2018-02-14 14:54:38 --> Language Class Initialized
INFO - 2018-02-14 14:54:38 --> Loader Class Initialized
INFO - 2018-02-14 14:54:38 --> Helper loaded: url_helper
INFO - 2018-02-14 14:54:38 --> Helper loaded: file_helper
INFO - 2018-02-14 14:54:38 --> Helper loaded: email_helper
INFO - 2018-02-14 14:54:38 --> Helper loaded: common_helper
INFO - 2018-02-14 14:54:38 --> Database Driver Class Initialized
DEBUG - 2018-02-14 14:54:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 14:54:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 14:54:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-14 14:54:38 --> Pagination Class Initialized
INFO - 2018-02-14 14:54:38 --> Helper loaded: form_helper
INFO - 2018-02-14 14:54:38 --> Form Validation Class Initialized
INFO - 2018-02-14 14:54:38 --> Model Class Initialized
INFO - 2018-02-14 14:54:38 --> Controller Class Initialized
INFO - 2018-02-14 14:54:38 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-14 14:54:38 --> Model Class Initialized
INFO - 2018-02-14 14:54:38 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-14 14:54:38 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-14 14:54:38 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-14 14:54:38 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-14 14:54:38 --> File loaded: /var/www/html/project/radio/application/views/category/index.php
INFO - 2018-02-14 14:54:38 --> Final output sent to browser
DEBUG - 2018-02-14 14:54:38 --> Total execution time: 0.0070
INFO - 2018-02-14 14:54:42 --> Config Class Initialized
INFO - 2018-02-14 14:54:42 --> Hooks Class Initialized
DEBUG - 2018-02-14 14:54:42 --> UTF-8 Support Enabled
INFO - 2018-02-14 14:54:42 --> Utf8 Class Initialized
INFO - 2018-02-14 14:54:42 --> URI Class Initialized
INFO - 2018-02-14 14:54:42 --> Router Class Initialized
INFO - 2018-02-14 14:54:42 --> Output Class Initialized
INFO - 2018-02-14 14:54:42 --> Security Class Initialized
DEBUG - 2018-02-14 14:54:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 14:54:42 --> Input Class Initialized
INFO - 2018-02-14 14:54:42 --> Language Class Initialized
INFO - 2018-02-14 14:54:42 --> Loader Class Initialized
INFO - 2018-02-14 14:54:42 --> Helper loaded: url_helper
INFO - 2018-02-14 14:54:42 --> Helper loaded: file_helper
INFO - 2018-02-14 14:54:42 --> Helper loaded: email_helper
INFO - 2018-02-14 14:54:42 --> Helper loaded: common_helper
INFO - 2018-02-14 14:54:42 --> Database Driver Class Initialized
DEBUG - 2018-02-14 14:54:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 14:54:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 14:54:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-14 14:54:42 --> Pagination Class Initialized
INFO - 2018-02-14 14:54:42 --> Helper loaded: form_helper
INFO - 2018-02-14 14:54:42 --> Form Validation Class Initialized
INFO - 2018-02-14 14:54:42 --> Model Class Initialized
INFO - 2018-02-14 14:54:42 --> Controller Class Initialized
INFO - 2018-02-14 14:54:42 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-14 14:54:42 --> Model Class Initialized
ERROR - 2018-02-14 14:54:42 --> Severity: Warning --> Missing argument 1 for Category::edit(), called in /var/www/html/project/radio/system/core/CodeIgniter.php on line 532 and defined /var/www/html/project/radio/application/controllers/Category.php 102
ERROR - 2018-02-14 14:54:42 --> Severity: Notice --> Undefined variable: Id /var/www/html/project/radio/application/controllers/Category.php 104
INFO - 2018-02-14 14:54:42 --> Config Class Initialized
INFO - 2018-02-14 14:54:42 --> Hooks Class Initialized
DEBUG - 2018-02-14 14:54:42 --> UTF-8 Support Enabled
INFO - 2018-02-14 14:54:42 --> Utf8 Class Initialized
INFO - 2018-02-14 14:54:42 --> URI Class Initialized
INFO - 2018-02-14 14:54:42 --> Router Class Initialized
INFO - 2018-02-14 14:54:42 --> Output Class Initialized
INFO - 2018-02-14 14:54:42 --> Security Class Initialized
DEBUG - 2018-02-14 14:54:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 14:54:42 --> Input Class Initialized
INFO - 2018-02-14 14:54:42 --> Language Class Initialized
INFO - 2018-02-14 14:54:42 --> Loader Class Initialized
INFO - 2018-02-14 14:54:42 --> Helper loaded: url_helper
INFO - 2018-02-14 14:54:42 --> Helper loaded: file_helper
INFO - 2018-02-14 14:54:42 --> Helper loaded: email_helper
INFO - 2018-02-14 14:54:42 --> Helper loaded: common_helper
INFO - 2018-02-14 14:54:42 --> Database Driver Class Initialized
DEBUG - 2018-02-14 14:54:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 14:54:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 14:54:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-14 14:54:42 --> Pagination Class Initialized
INFO - 2018-02-14 14:54:42 --> Helper loaded: form_helper
INFO - 2018-02-14 14:54:42 --> Form Validation Class Initialized
INFO - 2018-02-14 14:54:42 --> Model Class Initialized
INFO - 2018-02-14 14:54:42 --> Controller Class Initialized
INFO - 2018-02-14 14:54:42 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-14 14:54:42 --> Model Class Initialized
INFO - 2018-02-14 14:54:42 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-14 14:54:42 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-14 14:54:42 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-14 14:54:42 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-14 14:54:42 --> File loaded: /var/www/html/project/radio/application/views/category/index.php
INFO - 2018-02-14 14:54:42 --> Final output sent to browser
DEBUG - 2018-02-14 14:54:42 --> Total execution time: 0.0042
INFO - 2018-02-14 14:58:08 --> Config Class Initialized
INFO - 2018-02-14 14:58:08 --> Hooks Class Initialized
DEBUG - 2018-02-14 14:58:08 --> UTF-8 Support Enabled
INFO - 2018-02-14 14:58:08 --> Utf8 Class Initialized
INFO - 2018-02-14 14:58:08 --> URI Class Initialized
INFO - 2018-02-14 14:58:08 --> Router Class Initialized
INFO - 2018-02-14 14:58:08 --> Output Class Initialized
INFO - 2018-02-14 14:58:08 --> Security Class Initialized
DEBUG - 2018-02-14 14:58:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 14:58:08 --> Input Class Initialized
INFO - 2018-02-14 14:58:08 --> Language Class Initialized
INFO - 2018-02-14 14:58:08 --> Loader Class Initialized
INFO - 2018-02-14 14:58:08 --> Helper loaded: url_helper
INFO - 2018-02-14 14:58:08 --> Helper loaded: file_helper
INFO - 2018-02-14 14:58:08 --> Helper loaded: email_helper
INFO - 2018-02-14 14:58:08 --> Helper loaded: common_helper
INFO - 2018-02-14 14:58:08 --> Database Driver Class Initialized
DEBUG - 2018-02-14 14:58:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 14:58:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 14:58:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-14 14:58:08 --> Pagination Class Initialized
INFO - 2018-02-14 14:58:08 --> Helper loaded: form_helper
INFO - 2018-02-14 14:58:08 --> Form Validation Class Initialized
INFO - 2018-02-14 14:58:08 --> Model Class Initialized
INFO - 2018-02-14 14:58:08 --> Controller Class Initialized
INFO - 2018-02-14 14:58:08 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-14 14:58:08 --> Model Class Initialized
INFO - 2018-02-14 14:58:08 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-14 14:58:08 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-14 14:58:08 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-14 14:58:08 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-14 14:58:08 --> File loaded: /var/www/html/project/radio/application/views/category/index.php
INFO - 2018-02-14 14:58:08 --> Final output sent to browser
DEBUG - 2018-02-14 14:58:08 --> Total execution time: 0.0120
INFO - 2018-02-14 14:58:11 --> Config Class Initialized
INFO - 2018-02-14 14:58:11 --> Hooks Class Initialized
DEBUG - 2018-02-14 14:58:11 --> UTF-8 Support Enabled
INFO - 2018-02-14 14:58:11 --> Utf8 Class Initialized
INFO - 2018-02-14 14:58:11 --> URI Class Initialized
INFO - 2018-02-14 14:58:11 --> Router Class Initialized
INFO - 2018-02-14 14:58:11 --> Output Class Initialized
INFO - 2018-02-14 14:58:11 --> Security Class Initialized
DEBUG - 2018-02-14 14:58:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 14:58:11 --> Input Class Initialized
INFO - 2018-02-14 14:58:11 --> Language Class Initialized
INFO - 2018-02-14 14:58:11 --> Loader Class Initialized
INFO - 2018-02-14 14:58:11 --> Helper loaded: url_helper
INFO - 2018-02-14 14:58:11 --> Helper loaded: file_helper
INFO - 2018-02-14 14:58:11 --> Helper loaded: email_helper
INFO - 2018-02-14 14:58:11 --> Helper loaded: common_helper
INFO - 2018-02-14 14:58:11 --> Database Driver Class Initialized
DEBUG - 2018-02-14 14:58:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 14:58:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 14:58:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-14 14:58:11 --> Pagination Class Initialized
INFO - 2018-02-14 14:58:11 --> Helper loaded: form_helper
INFO - 2018-02-14 14:58:11 --> Form Validation Class Initialized
INFO - 2018-02-14 14:58:11 --> Model Class Initialized
INFO - 2018-02-14 14:58:11 --> Controller Class Initialized
INFO - 2018-02-14 14:58:11 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-14 14:58:11 --> Model Class Initialized
ERROR - 2018-02-14 14:58:11 --> Severity: Warning --> Missing argument 1 for Category::edit(), called in /var/www/html/project/radio/system/core/CodeIgniter.php on line 532 and defined /var/www/html/project/radio/application/controllers/Category.php 102
ERROR - 2018-02-14 14:58:11 --> Severity: Notice --> Undefined variable: Id /var/www/html/project/radio/application/controllers/Category.php 104
INFO - 2018-02-14 14:58:12 --> Config Class Initialized
INFO - 2018-02-14 14:58:12 --> Hooks Class Initialized
DEBUG - 2018-02-14 14:58:12 --> UTF-8 Support Enabled
INFO - 2018-02-14 14:58:12 --> Utf8 Class Initialized
INFO - 2018-02-14 14:58:12 --> URI Class Initialized
INFO - 2018-02-14 14:58:12 --> Router Class Initialized
INFO - 2018-02-14 14:58:12 --> Output Class Initialized
INFO - 2018-02-14 14:58:12 --> Security Class Initialized
DEBUG - 2018-02-14 14:58:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 14:58:12 --> Input Class Initialized
INFO - 2018-02-14 14:58:12 --> Language Class Initialized
INFO - 2018-02-14 14:58:12 --> Loader Class Initialized
INFO - 2018-02-14 14:58:12 --> Helper loaded: url_helper
INFO - 2018-02-14 14:58:12 --> Helper loaded: file_helper
INFO - 2018-02-14 14:58:12 --> Helper loaded: email_helper
INFO - 2018-02-14 14:58:12 --> Helper loaded: common_helper
INFO - 2018-02-14 14:58:12 --> Database Driver Class Initialized
DEBUG - 2018-02-14 14:58:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 14:58:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 14:58:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-14 14:58:12 --> Pagination Class Initialized
INFO - 2018-02-14 14:58:12 --> Helper loaded: form_helper
INFO - 2018-02-14 14:58:12 --> Form Validation Class Initialized
INFO - 2018-02-14 14:58:12 --> Model Class Initialized
INFO - 2018-02-14 14:58:12 --> Controller Class Initialized
INFO - 2018-02-14 14:58:12 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-14 14:58:12 --> Model Class Initialized
ERROR - 2018-02-14 14:58:12 --> Severity: Warning --> Missing argument 1 for Category::edit(), called in /var/www/html/project/radio/system/core/CodeIgniter.php on line 532 and defined /var/www/html/project/radio/application/controllers/Category.php 102
ERROR - 2018-02-14 14:58:12 --> Severity: Notice --> Undefined variable: Id /var/www/html/project/radio/application/controllers/Category.php 104
INFO - 2018-02-14 14:58:12 --> Config Class Initialized
INFO - 2018-02-14 14:58:12 --> Hooks Class Initialized
DEBUG - 2018-02-14 14:58:12 --> UTF-8 Support Enabled
INFO - 2018-02-14 14:58:12 --> Utf8 Class Initialized
INFO - 2018-02-14 14:58:12 --> URI Class Initialized
INFO - 2018-02-14 14:58:12 --> Router Class Initialized
INFO - 2018-02-14 14:58:12 --> Output Class Initialized
INFO - 2018-02-14 14:58:12 --> Security Class Initialized
DEBUG - 2018-02-14 14:58:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 14:58:12 --> Input Class Initialized
INFO - 2018-02-14 14:58:12 --> Language Class Initialized
INFO - 2018-02-14 14:58:12 --> Loader Class Initialized
INFO - 2018-02-14 14:58:12 --> Helper loaded: url_helper
INFO - 2018-02-14 14:58:12 --> Helper loaded: file_helper
INFO - 2018-02-14 14:58:12 --> Helper loaded: email_helper
INFO - 2018-02-14 14:58:12 --> Helper loaded: common_helper
INFO - 2018-02-14 14:58:12 --> Database Driver Class Initialized
DEBUG - 2018-02-14 14:58:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 14:58:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 14:58:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-14 14:58:12 --> Pagination Class Initialized
INFO - 2018-02-14 14:58:12 --> Helper loaded: form_helper
INFO - 2018-02-14 14:58:12 --> Form Validation Class Initialized
INFO - 2018-02-14 14:58:12 --> Model Class Initialized
INFO - 2018-02-14 14:58:12 --> Controller Class Initialized
INFO - 2018-02-14 14:58:12 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-14 14:58:12 --> Model Class Initialized
INFO - 2018-02-14 14:58:12 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-14 14:58:12 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-14 14:58:12 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-14 14:58:12 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-14 14:58:12 --> File loaded: /var/www/html/project/radio/application/views/category/index.php
INFO - 2018-02-14 14:58:12 --> Final output sent to browser
DEBUG - 2018-02-14 14:58:12 --> Total execution time: 0.0044
INFO - 2018-02-14 15:06:00 --> Config Class Initialized
INFO - 2018-02-14 15:06:00 --> Hooks Class Initialized
DEBUG - 2018-02-14 15:06:00 --> UTF-8 Support Enabled
INFO - 2018-02-14 15:06:00 --> Utf8 Class Initialized
INFO - 2018-02-14 15:06:00 --> URI Class Initialized
INFO - 2018-02-14 15:06:00 --> Router Class Initialized
INFO - 2018-02-14 15:06:00 --> Output Class Initialized
INFO - 2018-02-14 15:06:00 --> Security Class Initialized
DEBUG - 2018-02-14 15:06:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 15:06:00 --> Input Class Initialized
INFO - 2018-02-14 15:06:00 --> Language Class Initialized
INFO - 2018-02-14 15:06:00 --> Loader Class Initialized
INFO - 2018-02-14 15:06:00 --> Helper loaded: url_helper
INFO - 2018-02-14 15:06:00 --> Helper loaded: file_helper
INFO - 2018-02-14 15:06:00 --> Helper loaded: email_helper
INFO - 2018-02-14 15:06:00 --> Helper loaded: common_helper
INFO - 2018-02-14 15:06:00 --> Database Driver Class Initialized
DEBUG - 2018-02-14 15:06:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 15:06:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 15:06:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-14 15:06:00 --> Pagination Class Initialized
INFO - 2018-02-14 15:06:00 --> Helper loaded: form_helper
INFO - 2018-02-14 15:06:00 --> Form Validation Class Initialized
INFO - 2018-02-14 15:06:00 --> Model Class Initialized
INFO - 2018-02-14 15:06:00 --> Controller Class Initialized
INFO - 2018-02-14 15:06:00 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-14 15:06:00 --> Model Class Initialized
INFO - 2018-02-14 15:06:00 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-14 15:06:00 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-14 15:06:00 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-14 15:06:00 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-14 15:06:00 --> File loaded: /var/www/html/project/radio/application/views/category/add_edit.php
INFO - 2018-02-14 15:06:00 --> Final output sent to browser
DEBUG - 2018-02-14 15:06:00 --> Total execution time: 0.0070
INFO - 2018-02-14 15:06:31 --> Config Class Initialized
INFO - 2018-02-14 15:06:31 --> Hooks Class Initialized
DEBUG - 2018-02-14 15:06:31 --> UTF-8 Support Enabled
INFO - 2018-02-14 15:06:31 --> Utf8 Class Initialized
INFO - 2018-02-14 15:06:31 --> URI Class Initialized
INFO - 2018-02-14 15:06:31 --> Router Class Initialized
INFO - 2018-02-14 15:06:31 --> Output Class Initialized
INFO - 2018-02-14 15:06:31 --> Security Class Initialized
DEBUG - 2018-02-14 15:06:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 15:06:31 --> Input Class Initialized
INFO - 2018-02-14 15:06:31 --> Language Class Initialized
INFO - 2018-02-14 15:06:31 --> Loader Class Initialized
INFO - 2018-02-14 15:06:31 --> Helper loaded: url_helper
INFO - 2018-02-14 15:06:31 --> Helper loaded: file_helper
INFO - 2018-02-14 15:06:31 --> Helper loaded: email_helper
INFO - 2018-02-14 15:06:31 --> Helper loaded: common_helper
INFO - 2018-02-14 15:06:31 --> Database Driver Class Initialized
DEBUG - 2018-02-14 15:06:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 15:06:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 15:06:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-14 15:06:31 --> Pagination Class Initialized
INFO - 2018-02-14 15:06:31 --> Helper loaded: form_helper
INFO - 2018-02-14 15:06:31 --> Form Validation Class Initialized
INFO - 2018-02-14 15:06:31 --> Model Class Initialized
INFO - 2018-02-14 15:06:31 --> Controller Class Initialized
INFO - 2018-02-14 15:06:31 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-14 15:06:31 --> Model Class Initialized
INFO - 2018-02-14 15:06:38 --> Config Class Initialized
INFO - 2018-02-14 15:06:38 --> Hooks Class Initialized
DEBUG - 2018-02-14 15:06:38 --> UTF-8 Support Enabled
INFO - 2018-02-14 15:06:38 --> Utf8 Class Initialized
INFO - 2018-02-14 15:06:38 --> URI Class Initialized
INFO - 2018-02-14 15:06:38 --> Router Class Initialized
INFO - 2018-02-14 15:06:38 --> Output Class Initialized
INFO - 2018-02-14 15:06:38 --> Security Class Initialized
DEBUG - 2018-02-14 15:06:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 15:06:38 --> Input Class Initialized
INFO - 2018-02-14 15:06:38 --> Language Class Initialized
INFO - 2018-02-14 15:06:38 --> Loader Class Initialized
INFO - 2018-02-14 15:06:38 --> Helper loaded: url_helper
INFO - 2018-02-14 15:06:38 --> Helper loaded: file_helper
INFO - 2018-02-14 15:06:38 --> Helper loaded: email_helper
INFO - 2018-02-14 15:06:38 --> Helper loaded: common_helper
INFO - 2018-02-14 15:06:38 --> Database Driver Class Initialized
DEBUG - 2018-02-14 15:06:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 15:06:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 15:06:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-14 15:06:38 --> Pagination Class Initialized
INFO - 2018-02-14 15:06:38 --> Helper loaded: form_helper
INFO - 2018-02-14 15:06:38 --> Form Validation Class Initialized
INFO - 2018-02-14 15:06:38 --> Model Class Initialized
INFO - 2018-02-14 15:06:38 --> Controller Class Initialized
INFO - 2018-02-14 15:06:38 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-14 15:06:38 --> Model Class Initialized
INFO - 2018-02-14 15:07:10 --> Config Class Initialized
INFO - 2018-02-14 15:07:10 --> Hooks Class Initialized
DEBUG - 2018-02-14 15:07:10 --> UTF-8 Support Enabled
INFO - 2018-02-14 15:07:10 --> Utf8 Class Initialized
INFO - 2018-02-14 15:07:10 --> URI Class Initialized
INFO - 2018-02-14 15:07:10 --> Router Class Initialized
INFO - 2018-02-14 15:07:10 --> Output Class Initialized
INFO - 2018-02-14 15:07:10 --> Security Class Initialized
DEBUG - 2018-02-14 15:07:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 15:07:10 --> Input Class Initialized
INFO - 2018-02-14 15:07:10 --> Language Class Initialized
INFO - 2018-02-14 15:07:10 --> Loader Class Initialized
INFO - 2018-02-14 15:07:10 --> Helper loaded: url_helper
INFO - 2018-02-14 15:07:10 --> Helper loaded: file_helper
INFO - 2018-02-14 15:07:10 --> Helper loaded: email_helper
INFO - 2018-02-14 15:07:10 --> Helper loaded: common_helper
INFO - 2018-02-14 15:07:10 --> Database Driver Class Initialized
DEBUG - 2018-02-14 15:07:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 15:07:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 15:07:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-14 15:07:10 --> Pagination Class Initialized
INFO - 2018-02-14 15:07:10 --> Helper loaded: form_helper
INFO - 2018-02-14 15:07:10 --> Form Validation Class Initialized
INFO - 2018-02-14 15:07:10 --> Model Class Initialized
INFO - 2018-02-14 15:07:10 --> Controller Class Initialized
INFO - 2018-02-14 15:07:10 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-14 15:07:10 --> Model Class Initialized
INFO - 2018-02-14 15:07:10 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-14 15:07:10 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-14 15:07:10 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-14 15:07:10 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-14 15:07:10 --> File loaded: /var/www/html/project/radio/application/views/category/add_edit.php
INFO - 2018-02-14 15:07:10 --> Final output sent to browser
DEBUG - 2018-02-14 15:07:10 --> Total execution time: 0.0061
INFO - 2018-02-14 15:07:15 --> Config Class Initialized
INFO - 2018-02-14 15:07:15 --> Hooks Class Initialized
DEBUG - 2018-02-14 15:07:15 --> UTF-8 Support Enabled
INFO - 2018-02-14 15:07:15 --> Utf8 Class Initialized
INFO - 2018-02-14 15:07:15 --> URI Class Initialized
INFO - 2018-02-14 15:07:15 --> Router Class Initialized
INFO - 2018-02-14 15:07:15 --> Output Class Initialized
INFO - 2018-02-14 15:07:15 --> Security Class Initialized
DEBUG - 2018-02-14 15:07:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 15:07:15 --> Input Class Initialized
INFO - 2018-02-14 15:07:15 --> Language Class Initialized
INFO - 2018-02-14 15:07:15 --> Loader Class Initialized
INFO - 2018-02-14 15:07:15 --> Helper loaded: url_helper
INFO - 2018-02-14 15:07:15 --> Helper loaded: file_helper
INFO - 2018-02-14 15:07:15 --> Helper loaded: email_helper
INFO - 2018-02-14 15:07:15 --> Helper loaded: common_helper
INFO - 2018-02-14 15:07:15 --> Database Driver Class Initialized
DEBUG - 2018-02-14 15:07:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 15:07:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 15:07:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-14 15:07:15 --> Pagination Class Initialized
INFO - 2018-02-14 15:07:15 --> Helper loaded: form_helper
INFO - 2018-02-14 15:07:15 --> Form Validation Class Initialized
INFO - 2018-02-14 15:07:15 --> Model Class Initialized
INFO - 2018-02-14 15:07:15 --> Controller Class Initialized
INFO - 2018-02-14 15:07:15 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-14 15:07:15 --> Model Class Initialized
INFO - 2018-02-14 15:07:33 --> Config Class Initialized
INFO - 2018-02-14 15:07:33 --> Hooks Class Initialized
DEBUG - 2018-02-14 15:07:33 --> UTF-8 Support Enabled
INFO - 2018-02-14 15:07:33 --> Utf8 Class Initialized
INFO - 2018-02-14 15:07:33 --> URI Class Initialized
INFO - 2018-02-14 15:07:33 --> Router Class Initialized
INFO - 2018-02-14 15:07:33 --> Output Class Initialized
INFO - 2018-02-14 15:07:33 --> Security Class Initialized
DEBUG - 2018-02-14 15:07:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 15:07:33 --> Input Class Initialized
INFO - 2018-02-14 15:07:33 --> Language Class Initialized
INFO - 2018-02-14 15:07:33 --> Loader Class Initialized
INFO - 2018-02-14 15:07:33 --> Helper loaded: url_helper
INFO - 2018-02-14 15:07:33 --> Helper loaded: file_helper
INFO - 2018-02-14 15:07:33 --> Helper loaded: email_helper
INFO - 2018-02-14 15:07:33 --> Helper loaded: common_helper
INFO - 2018-02-14 15:07:33 --> Database Driver Class Initialized
DEBUG - 2018-02-14 15:07:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 15:07:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 15:07:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-14 15:07:33 --> Pagination Class Initialized
INFO - 2018-02-14 15:07:33 --> Helper loaded: form_helper
INFO - 2018-02-14 15:07:33 --> Form Validation Class Initialized
INFO - 2018-02-14 15:07:33 --> Model Class Initialized
INFO - 2018-02-14 15:07:33 --> Controller Class Initialized
INFO - 2018-02-14 15:07:33 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-14 15:07:33 --> Model Class Initialized
INFO - 2018-02-14 15:07:33 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-14 15:07:33 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-14 15:07:33 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-14 15:07:33 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-14 15:07:33 --> File loaded: /var/www/html/project/radio/application/views/category/add_edit.php
INFO - 2018-02-14 15:07:33 --> Final output sent to browser
DEBUG - 2018-02-14 15:07:33 --> Total execution time: 0.0078
INFO - 2018-02-14 15:07:37 --> Config Class Initialized
INFO - 2018-02-14 15:07:37 --> Hooks Class Initialized
DEBUG - 2018-02-14 15:07:37 --> UTF-8 Support Enabled
INFO - 2018-02-14 15:07:37 --> Utf8 Class Initialized
INFO - 2018-02-14 15:07:37 --> URI Class Initialized
INFO - 2018-02-14 15:07:37 --> Router Class Initialized
INFO - 2018-02-14 15:07:37 --> Output Class Initialized
INFO - 2018-02-14 15:07:37 --> Security Class Initialized
DEBUG - 2018-02-14 15:07:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 15:07:37 --> Input Class Initialized
INFO - 2018-02-14 15:07:37 --> Language Class Initialized
INFO - 2018-02-14 15:07:37 --> Loader Class Initialized
INFO - 2018-02-14 15:07:37 --> Helper loaded: url_helper
INFO - 2018-02-14 15:07:37 --> Helper loaded: file_helper
INFO - 2018-02-14 15:07:37 --> Helper loaded: email_helper
INFO - 2018-02-14 15:07:37 --> Helper loaded: common_helper
INFO - 2018-02-14 15:07:37 --> Database Driver Class Initialized
DEBUG - 2018-02-14 15:07:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 15:07:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 15:07:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-14 15:07:37 --> Pagination Class Initialized
INFO - 2018-02-14 15:07:37 --> Helper loaded: form_helper
INFO - 2018-02-14 15:07:37 --> Form Validation Class Initialized
INFO - 2018-02-14 15:07:37 --> Model Class Initialized
INFO - 2018-02-14 15:07:37 --> Controller Class Initialized
INFO - 2018-02-14 15:07:37 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-14 15:07:37 --> Model Class Initialized
INFO - 2018-02-14 15:07:56 --> Config Class Initialized
INFO - 2018-02-14 15:07:56 --> Hooks Class Initialized
DEBUG - 2018-02-14 15:07:56 --> UTF-8 Support Enabled
INFO - 2018-02-14 15:07:56 --> Utf8 Class Initialized
INFO - 2018-02-14 15:07:56 --> URI Class Initialized
INFO - 2018-02-14 15:07:56 --> Router Class Initialized
INFO - 2018-02-14 15:07:56 --> Output Class Initialized
INFO - 2018-02-14 15:07:56 --> Security Class Initialized
DEBUG - 2018-02-14 15:07:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 15:07:56 --> Input Class Initialized
INFO - 2018-02-14 15:07:56 --> Language Class Initialized
INFO - 2018-02-14 15:07:56 --> Loader Class Initialized
INFO - 2018-02-14 15:07:56 --> Helper loaded: url_helper
INFO - 2018-02-14 15:07:56 --> Helper loaded: file_helper
INFO - 2018-02-14 15:07:56 --> Helper loaded: email_helper
INFO - 2018-02-14 15:07:56 --> Helper loaded: common_helper
INFO - 2018-02-14 15:07:56 --> Database Driver Class Initialized
DEBUG - 2018-02-14 15:07:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 15:07:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 15:07:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-14 15:07:56 --> Pagination Class Initialized
INFO - 2018-02-14 15:07:56 --> Helper loaded: form_helper
INFO - 2018-02-14 15:07:56 --> Form Validation Class Initialized
INFO - 2018-02-14 15:07:56 --> Model Class Initialized
INFO - 2018-02-14 15:07:56 --> Controller Class Initialized
INFO - 2018-02-14 15:07:56 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-14 15:07:56 --> Model Class Initialized
INFO - 2018-02-14 15:08:34 --> Config Class Initialized
INFO - 2018-02-14 15:08:34 --> Hooks Class Initialized
DEBUG - 2018-02-14 15:08:34 --> UTF-8 Support Enabled
INFO - 2018-02-14 15:08:34 --> Utf8 Class Initialized
INFO - 2018-02-14 15:08:34 --> URI Class Initialized
INFO - 2018-02-14 15:08:34 --> Router Class Initialized
INFO - 2018-02-14 15:08:34 --> Output Class Initialized
INFO - 2018-02-14 15:08:34 --> Security Class Initialized
DEBUG - 2018-02-14 15:08:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 15:08:34 --> Input Class Initialized
INFO - 2018-02-14 15:08:34 --> Language Class Initialized
INFO - 2018-02-14 15:08:34 --> Loader Class Initialized
INFO - 2018-02-14 15:08:34 --> Helper loaded: url_helper
INFO - 2018-02-14 15:08:34 --> Helper loaded: file_helper
INFO - 2018-02-14 15:08:34 --> Helper loaded: email_helper
INFO - 2018-02-14 15:08:34 --> Helper loaded: common_helper
INFO - 2018-02-14 15:08:34 --> Database Driver Class Initialized
DEBUG - 2018-02-14 15:08:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 15:08:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 15:08:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-14 15:08:34 --> Pagination Class Initialized
INFO - 2018-02-14 15:08:34 --> Helper loaded: form_helper
INFO - 2018-02-14 15:08:34 --> Form Validation Class Initialized
INFO - 2018-02-14 15:08:34 --> Model Class Initialized
INFO - 2018-02-14 15:08:34 --> Controller Class Initialized
INFO - 2018-02-14 15:08:34 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-14 15:08:34 --> Model Class Initialized
INFO - 2018-02-14 15:08:34 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-14 15:08:34 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-14 15:08:34 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-14 15:08:34 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-14 15:08:34 --> File loaded: /var/www/html/project/radio/application/views/category/add_edit.php
INFO - 2018-02-14 15:08:34 --> Final output sent to browser
DEBUG - 2018-02-14 15:08:34 --> Total execution time: 0.0065
INFO - 2018-02-14 15:08:44 --> Config Class Initialized
INFO - 2018-02-14 15:08:44 --> Hooks Class Initialized
DEBUG - 2018-02-14 15:08:44 --> UTF-8 Support Enabled
INFO - 2018-02-14 15:08:44 --> Utf8 Class Initialized
INFO - 2018-02-14 15:08:44 --> URI Class Initialized
INFO - 2018-02-14 15:08:44 --> Router Class Initialized
INFO - 2018-02-14 15:08:44 --> Output Class Initialized
INFO - 2018-02-14 15:08:44 --> Security Class Initialized
DEBUG - 2018-02-14 15:08:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 15:08:44 --> Input Class Initialized
INFO - 2018-02-14 15:08:44 --> Language Class Initialized
INFO - 2018-02-14 15:08:44 --> Loader Class Initialized
INFO - 2018-02-14 15:08:44 --> Helper loaded: url_helper
INFO - 2018-02-14 15:08:44 --> Helper loaded: file_helper
INFO - 2018-02-14 15:08:44 --> Helper loaded: email_helper
INFO - 2018-02-14 15:08:44 --> Helper loaded: common_helper
INFO - 2018-02-14 15:08:44 --> Database Driver Class Initialized
DEBUG - 2018-02-14 15:08:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 15:08:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 15:08:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-14 15:08:44 --> Pagination Class Initialized
INFO - 2018-02-14 15:08:44 --> Helper loaded: form_helper
INFO - 2018-02-14 15:08:44 --> Form Validation Class Initialized
INFO - 2018-02-14 15:08:44 --> Model Class Initialized
INFO - 2018-02-14 15:08:44 --> Controller Class Initialized
INFO - 2018-02-14 15:08:44 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-14 15:08:44 --> Model Class Initialized
INFO - 2018-02-14 15:13:48 --> Config Class Initialized
INFO - 2018-02-14 15:13:48 --> Hooks Class Initialized
DEBUG - 2018-02-14 15:13:48 --> UTF-8 Support Enabled
INFO - 2018-02-14 15:13:48 --> Utf8 Class Initialized
INFO - 2018-02-14 15:13:48 --> URI Class Initialized
INFO - 2018-02-14 15:13:48 --> Router Class Initialized
INFO - 2018-02-14 15:13:48 --> Output Class Initialized
INFO - 2018-02-14 15:13:48 --> Security Class Initialized
DEBUG - 2018-02-14 15:13:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 15:13:48 --> Input Class Initialized
INFO - 2018-02-14 15:13:48 --> Language Class Initialized
INFO - 2018-02-14 15:13:48 --> Loader Class Initialized
INFO - 2018-02-14 15:13:48 --> Helper loaded: url_helper
INFO - 2018-02-14 15:13:48 --> Helper loaded: file_helper
INFO - 2018-02-14 15:13:48 --> Helper loaded: email_helper
INFO - 2018-02-14 15:13:48 --> Helper loaded: common_helper
INFO - 2018-02-14 15:13:48 --> Database Driver Class Initialized
DEBUG - 2018-02-14 15:13:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 15:13:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 15:13:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-14 15:13:48 --> Pagination Class Initialized
INFO - 2018-02-14 15:13:48 --> Helper loaded: form_helper
INFO - 2018-02-14 15:13:48 --> Form Validation Class Initialized
INFO - 2018-02-14 15:13:48 --> Model Class Initialized
INFO - 2018-02-14 15:13:48 --> Controller Class Initialized
INFO - 2018-02-14 15:13:48 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-14 15:13:48 --> Model Class Initialized
INFO - 2018-02-14 15:13:48 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-14 15:13:48 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-14 15:13:48 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-14 15:13:48 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-14 15:13:48 --> File loaded: /var/www/html/project/radio/application/views/category/add_edit.php
INFO - 2018-02-14 15:13:48 --> Final output sent to browser
DEBUG - 2018-02-14 15:13:48 --> Total execution time: 0.0061
INFO - 2018-02-14 15:17:28 --> Config Class Initialized
INFO - 2018-02-14 15:17:28 --> Hooks Class Initialized
DEBUG - 2018-02-14 15:17:28 --> UTF-8 Support Enabled
INFO - 2018-02-14 15:17:28 --> Utf8 Class Initialized
INFO - 2018-02-14 15:17:28 --> URI Class Initialized
INFO - 2018-02-14 15:17:28 --> Router Class Initialized
INFO - 2018-02-14 15:17:28 --> Output Class Initialized
INFO - 2018-02-14 15:17:28 --> Security Class Initialized
DEBUG - 2018-02-14 15:17:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 15:17:28 --> Input Class Initialized
INFO - 2018-02-14 15:17:28 --> Language Class Initialized
INFO - 2018-02-14 15:17:28 --> Loader Class Initialized
INFO - 2018-02-14 15:17:28 --> Helper loaded: url_helper
INFO - 2018-02-14 15:17:28 --> Helper loaded: file_helper
INFO - 2018-02-14 15:17:28 --> Helper loaded: email_helper
INFO - 2018-02-14 15:17:28 --> Helper loaded: common_helper
INFO - 2018-02-14 15:17:28 --> Database Driver Class Initialized
DEBUG - 2018-02-14 15:17:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 15:17:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 15:17:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-14 15:17:28 --> Pagination Class Initialized
INFO - 2018-02-14 15:17:28 --> Helper loaded: form_helper
INFO - 2018-02-14 15:17:28 --> Form Validation Class Initialized
INFO - 2018-02-14 15:17:28 --> Model Class Initialized
INFO - 2018-02-14 15:17:28 --> Controller Class Initialized
INFO - 2018-02-14 15:17:28 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-14 15:17:28 --> Model Class Initialized
INFO - 2018-02-14 15:17:28 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-14 15:17:28 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-14 15:17:28 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-14 15:17:28 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-14 15:17:28 --> File loaded: /var/www/html/project/radio/application/views/category/add_edit.php
INFO - 2018-02-14 15:17:28 --> Final output sent to browser
DEBUG - 2018-02-14 15:17:28 --> Total execution time: 0.0064
INFO - 2018-02-14 15:17:59 --> Config Class Initialized
INFO - 2018-02-14 15:17:59 --> Hooks Class Initialized
DEBUG - 2018-02-14 15:17:59 --> UTF-8 Support Enabled
INFO - 2018-02-14 15:17:59 --> Utf8 Class Initialized
INFO - 2018-02-14 15:17:59 --> URI Class Initialized
INFO - 2018-02-14 15:17:59 --> Router Class Initialized
INFO - 2018-02-14 15:17:59 --> Output Class Initialized
INFO - 2018-02-14 15:17:59 --> Security Class Initialized
DEBUG - 2018-02-14 15:17:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 15:17:59 --> Input Class Initialized
INFO - 2018-02-14 15:17:59 --> Language Class Initialized
INFO - 2018-02-14 15:17:59 --> Loader Class Initialized
INFO - 2018-02-14 15:17:59 --> Helper loaded: url_helper
INFO - 2018-02-14 15:17:59 --> Helper loaded: file_helper
INFO - 2018-02-14 15:17:59 --> Helper loaded: email_helper
INFO - 2018-02-14 15:17:59 --> Helper loaded: common_helper
INFO - 2018-02-14 15:17:59 --> Database Driver Class Initialized
DEBUG - 2018-02-14 15:17:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 15:17:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 15:17:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-14 15:17:59 --> Pagination Class Initialized
INFO - 2018-02-14 15:17:59 --> Helper loaded: form_helper
INFO - 2018-02-14 15:17:59 --> Form Validation Class Initialized
INFO - 2018-02-14 15:17:59 --> Model Class Initialized
INFO - 2018-02-14 15:17:59 --> Controller Class Initialized
INFO - 2018-02-14 15:17:59 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-14 15:17:59 --> Model Class Initialized
INFO - 2018-02-14 15:17:59 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-14 15:17:59 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-14 15:17:59 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-14 15:17:59 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-14 15:17:59 --> File loaded: /var/www/html/project/radio/application/views/category/add_edit.php
INFO - 2018-02-14 15:17:59 --> Final output sent to browser
DEBUG - 2018-02-14 15:17:59 --> Total execution time: 0.0079
INFO - 2018-02-14 15:18:45 --> Config Class Initialized
INFO - 2018-02-14 15:18:45 --> Hooks Class Initialized
DEBUG - 2018-02-14 15:18:45 --> UTF-8 Support Enabled
INFO - 2018-02-14 15:18:45 --> Utf8 Class Initialized
INFO - 2018-02-14 15:18:45 --> URI Class Initialized
INFO - 2018-02-14 15:18:45 --> Router Class Initialized
INFO - 2018-02-14 15:18:45 --> Output Class Initialized
INFO - 2018-02-14 15:18:45 --> Security Class Initialized
DEBUG - 2018-02-14 15:18:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 15:18:45 --> Input Class Initialized
INFO - 2018-02-14 15:18:45 --> Language Class Initialized
INFO - 2018-02-14 15:18:45 --> Loader Class Initialized
INFO - 2018-02-14 15:18:45 --> Helper loaded: url_helper
INFO - 2018-02-14 15:18:45 --> Helper loaded: file_helper
INFO - 2018-02-14 15:18:45 --> Helper loaded: email_helper
INFO - 2018-02-14 15:18:45 --> Helper loaded: common_helper
INFO - 2018-02-14 15:18:45 --> Database Driver Class Initialized
DEBUG - 2018-02-14 15:18:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 15:18:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 15:18:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-14 15:18:45 --> Pagination Class Initialized
INFO - 2018-02-14 15:18:45 --> Helper loaded: form_helper
INFO - 2018-02-14 15:18:45 --> Form Validation Class Initialized
INFO - 2018-02-14 15:18:45 --> Model Class Initialized
INFO - 2018-02-14 15:18:45 --> Controller Class Initialized
INFO - 2018-02-14 15:18:45 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-14 15:18:45 --> Model Class Initialized
INFO - 2018-02-14 15:18:45 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-14 15:18:45 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-14 15:18:45 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-14 15:18:45 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-14 15:18:45 --> File loaded: /var/www/html/project/radio/application/views/category/add_edit.php
INFO - 2018-02-14 15:18:45 --> Final output sent to browser
DEBUG - 2018-02-14 15:18:45 --> Total execution time: 0.0053
INFO - 2018-02-14 15:19:02 --> Config Class Initialized
INFO - 2018-02-14 15:19:02 --> Hooks Class Initialized
DEBUG - 2018-02-14 15:19:02 --> UTF-8 Support Enabled
INFO - 2018-02-14 15:19:02 --> Utf8 Class Initialized
INFO - 2018-02-14 15:19:02 --> URI Class Initialized
INFO - 2018-02-14 15:19:02 --> Router Class Initialized
INFO - 2018-02-14 15:19:02 --> Output Class Initialized
INFO - 2018-02-14 15:19:02 --> Security Class Initialized
DEBUG - 2018-02-14 15:19:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 15:19:02 --> Input Class Initialized
INFO - 2018-02-14 15:19:02 --> Language Class Initialized
INFO - 2018-02-14 15:19:02 --> Loader Class Initialized
INFO - 2018-02-14 15:19:02 --> Helper loaded: url_helper
INFO - 2018-02-14 15:19:02 --> Helper loaded: file_helper
INFO - 2018-02-14 15:19:02 --> Helper loaded: email_helper
INFO - 2018-02-14 15:19:02 --> Helper loaded: common_helper
INFO - 2018-02-14 15:19:02 --> Database Driver Class Initialized
DEBUG - 2018-02-14 15:19:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 15:19:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 15:19:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-14 15:19:02 --> Pagination Class Initialized
INFO - 2018-02-14 15:19:02 --> Helper loaded: form_helper
INFO - 2018-02-14 15:19:02 --> Form Validation Class Initialized
INFO - 2018-02-14 15:19:02 --> Model Class Initialized
INFO - 2018-02-14 15:19:02 --> Controller Class Initialized
INFO - 2018-02-14 15:19:02 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-14 15:19:02 --> Model Class Initialized
INFO - 2018-02-14 15:19:02 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-14 15:19:02 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-14 15:19:02 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-14 15:19:02 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-14 15:19:02 --> File loaded: /var/www/html/project/radio/application/views/category/add_edit.php
INFO - 2018-02-14 15:19:02 --> Final output sent to browser
DEBUG - 2018-02-14 15:19:02 --> Total execution time: 0.0105
INFO - 2018-02-14 15:20:07 --> Config Class Initialized
INFO - 2018-02-14 15:20:07 --> Hooks Class Initialized
DEBUG - 2018-02-14 15:20:07 --> UTF-8 Support Enabled
INFO - 2018-02-14 15:20:07 --> Utf8 Class Initialized
INFO - 2018-02-14 15:20:07 --> URI Class Initialized
INFO - 2018-02-14 15:20:07 --> Router Class Initialized
INFO - 2018-02-14 15:20:07 --> Output Class Initialized
INFO - 2018-02-14 15:20:07 --> Security Class Initialized
DEBUG - 2018-02-14 15:20:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 15:20:07 --> Input Class Initialized
INFO - 2018-02-14 15:20:07 --> Language Class Initialized
INFO - 2018-02-14 15:20:07 --> Loader Class Initialized
INFO - 2018-02-14 15:20:07 --> Helper loaded: url_helper
INFO - 2018-02-14 15:20:07 --> Helper loaded: file_helper
INFO - 2018-02-14 15:20:07 --> Helper loaded: email_helper
INFO - 2018-02-14 15:20:07 --> Helper loaded: common_helper
INFO - 2018-02-14 15:20:07 --> Database Driver Class Initialized
DEBUG - 2018-02-14 15:20:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 15:20:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 15:20:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-14 15:20:07 --> Pagination Class Initialized
INFO - 2018-02-14 15:20:07 --> Helper loaded: form_helper
INFO - 2018-02-14 15:20:07 --> Form Validation Class Initialized
INFO - 2018-02-14 15:20:07 --> Model Class Initialized
INFO - 2018-02-14 15:20:07 --> Controller Class Initialized
INFO - 2018-02-14 15:20:07 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-14 15:20:07 --> Model Class Initialized
INFO - 2018-02-14 15:20:07 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-14 15:20:07 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-14 15:20:07 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-14 15:20:07 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-14 15:20:07 --> File loaded: /var/www/html/project/radio/application/views/category/add_edit.php
INFO - 2018-02-14 15:20:07 --> Final output sent to browser
DEBUG - 2018-02-14 15:20:07 --> Total execution time: 0.0095
INFO - 2018-02-14 15:20:54 --> Config Class Initialized
INFO - 2018-02-14 15:20:54 --> Hooks Class Initialized
DEBUG - 2018-02-14 15:20:54 --> UTF-8 Support Enabled
INFO - 2018-02-14 15:20:54 --> Utf8 Class Initialized
INFO - 2018-02-14 15:20:54 --> URI Class Initialized
INFO - 2018-02-14 15:20:54 --> Router Class Initialized
INFO - 2018-02-14 15:20:54 --> Output Class Initialized
INFO - 2018-02-14 15:20:54 --> Security Class Initialized
DEBUG - 2018-02-14 15:20:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 15:20:54 --> Input Class Initialized
INFO - 2018-02-14 15:20:54 --> Language Class Initialized
INFO - 2018-02-14 15:20:54 --> Loader Class Initialized
INFO - 2018-02-14 15:20:54 --> Helper loaded: url_helper
INFO - 2018-02-14 15:20:54 --> Helper loaded: file_helper
INFO - 2018-02-14 15:20:54 --> Helper loaded: email_helper
INFO - 2018-02-14 15:20:54 --> Helper loaded: common_helper
INFO - 2018-02-14 15:20:54 --> Database Driver Class Initialized
DEBUG - 2018-02-14 15:20:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 15:20:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 15:20:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-14 15:20:54 --> Pagination Class Initialized
INFO - 2018-02-14 15:20:54 --> Helper loaded: form_helper
INFO - 2018-02-14 15:20:54 --> Form Validation Class Initialized
INFO - 2018-02-14 15:20:54 --> Model Class Initialized
INFO - 2018-02-14 15:20:54 --> Controller Class Initialized
INFO - 2018-02-14 15:20:54 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-14 15:20:54 --> Model Class Initialized
INFO - 2018-02-14 15:20:54 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-14 15:20:54 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-14 15:20:54 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-14 15:20:54 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-14 15:20:54 --> File loaded: /var/www/html/project/radio/application/views/category/add_edit.php
INFO - 2018-02-14 15:20:54 --> Final output sent to browser
DEBUG - 2018-02-14 15:20:54 --> Total execution time: 0.0068
INFO - 2018-02-14 15:20:59 --> Config Class Initialized
INFO - 2018-02-14 15:20:59 --> Hooks Class Initialized
DEBUG - 2018-02-14 15:20:59 --> UTF-8 Support Enabled
INFO - 2018-02-14 15:20:59 --> Utf8 Class Initialized
INFO - 2018-02-14 15:20:59 --> URI Class Initialized
INFO - 2018-02-14 15:20:59 --> Router Class Initialized
INFO - 2018-02-14 15:20:59 --> Output Class Initialized
INFO - 2018-02-14 15:20:59 --> Security Class Initialized
DEBUG - 2018-02-14 15:20:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 15:20:59 --> Input Class Initialized
INFO - 2018-02-14 15:20:59 --> Language Class Initialized
INFO - 2018-02-14 15:20:59 --> Loader Class Initialized
INFO - 2018-02-14 15:20:59 --> Helper loaded: url_helper
INFO - 2018-02-14 15:20:59 --> Helper loaded: file_helper
INFO - 2018-02-14 15:20:59 --> Helper loaded: email_helper
INFO - 2018-02-14 15:20:59 --> Helper loaded: common_helper
INFO - 2018-02-14 15:20:59 --> Database Driver Class Initialized
DEBUG - 2018-02-14 15:20:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 15:20:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 15:20:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-14 15:20:59 --> Pagination Class Initialized
INFO - 2018-02-14 15:20:59 --> Helper loaded: form_helper
INFO - 2018-02-14 15:20:59 --> Form Validation Class Initialized
INFO - 2018-02-14 15:20:59 --> Model Class Initialized
INFO - 2018-02-14 15:20:59 --> Controller Class Initialized
INFO - 2018-02-14 15:20:59 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-14 15:20:59 --> Model Class Initialized
INFO - 2018-02-14 15:20:59 --> Config Class Initialized
INFO - 2018-02-14 15:20:59 --> Hooks Class Initialized
DEBUG - 2018-02-14 15:20:59 --> UTF-8 Support Enabled
INFO - 2018-02-14 15:20:59 --> Utf8 Class Initialized
INFO - 2018-02-14 15:20:59 --> URI Class Initialized
INFO - 2018-02-14 15:20:59 --> Router Class Initialized
INFO - 2018-02-14 15:20:59 --> Output Class Initialized
INFO - 2018-02-14 15:20:59 --> Security Class Initialized
DEBUG - 2018-02-14 15:20:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 15:20:59 --> Input Class Initialized
INFO - 2018-02-14 15:20:59 --> Language Class Initialized
INFO - 2018-02-14 15:20:59 --> Loader Class Initialized
INFO - 2018-02-14 15:20:59 --> Helper loaded: url_helper
INFO - 2018-02-14 15:20:59 --> Helper loaded: file_helper
INFO - 2018-02-14 15:20:59 --> Helper loaded: email_helper
INFO - 2018-02-14 15:20:59 --> Helper loaded: common_helper
INFO - 2018-02-14 15:20:59 --> Database Driver Class Initialized
DEBUG - 2018-02-14 15:20:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 15:20:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 15:20:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-14 15:20:59 --> Pagination Class Initialized
INFO - 2018-02-14 15:20:59 --> Helper loaded: form_helper
INFO - 2018-02-14 15:20:59 --> Form Validation Class Initialized
INFO - 2018-02-14 15:20:59 --> Model Class Initialized
INFO - 2018-02-14 15:20:59 --> Controller Class Initialized
INFO - 2018-02-14 15:20:59 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-14 15:20:59 --> Model Class Initialized
INFO - 2018-02-14 15:21:02 --> Config Class Initialized
INFO - 2018-02-14 15:21:02 --> Hooks Class Initialized
DEBUG - 2018-02-14 15:21:02 --> UTF-8 Support Enabled
INFO - 2018-02-14 15:21:02 --> Utf8 Class Initialized
INFO - 2018-02-14 15:21:02 --> URI Class Initialized
INFO - 2018-02-14 15:21:02 --> Router Class Initialized
INFO - 2018-02-14 15:21:02 --> Output Class Initialized
INFO - 2018-02-14 15:21:02 --> Security Class Initialized
DEBUG - 2018-02-14 15:21:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 15:21:02 --> Input Class Initialized
INFO - 2018-02-14 15:21:02 --> Language Class Initialized
INFO - 2018-02-14 15:21:02 --> Loader Class Initialized
INFO - 2018-02-14 15:21:02 --> Helper loaded: url_helper
INFO - 2018-02-14 15:21:02 --> Helper loaded: file_helper
INFO - 2018-02-14 15:21:02 --> Helper loaded: email_helper
INFO - 2018-02-14 15:21:02 --> Helper loaded: common_helper
INFO - 2018-02-14 15:21:02 --> Database Driver Class Initialized
DEBUG - 2018-02-14 15:21:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 15:21:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 15:21:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-14 15:21:02 --> Pagination Class Initialized
INFO - 2018-02-14 15:21:02 --> Helper loaded: form_helper
INFO - 2018-02-14 15:21:02 --> Form Validation Class Initialized
INFO - 2018-02-14 15:21:02 --> Model Class Initialized
INFO - 2018-02-14 15:21:02 --> Controller Class Initialized
INFO - 2018-02-14 15:21:02 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-14 15:21:02 --> Model Class Initialized
INFO - 2018-02-14 15:21:02 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-14 15:21:02 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-14 15:21:02 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-14 15:21:02 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-14 15:21:02 --> File loaded: /var/www/html/project/radio/application/views/category/add_edit.php
INFO - 2018-02-14 15:21:02 --> Final output sent to browser
DEBUG - 2018-02-14 15:21:02 --> Total execution time: 0.0068
INFO - 2018-02-14 15:21:06 --> Config Class Initialized
INFO - 2018-02-14 15:21:06 --> Hooks Class Initialized
DEBUG - 2018-02-14 15:21:06 --> UTF-8 Support Enabled
INFO - 2018-02-14 15:21:06 --> Utf8 Class Initialized
INFO - 2018-02-14 15:21:06 --> URI Class Initialized
INFO - 2018-02-14 15:21:06 --> Router Class Initialized
INFO - 2018-02-14 15:21:06 --> Output Class Initialized
INFO - 2018-02-14 15:21:06 --> Security Class Initialized
DEBUG - 2018-02-14 15:21:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 15:21:06 --> Input Class Initialized
INFO - 2018-02-14 15:21:06 --> Language Class Initialized
INFO - 2018-02-14 15:21:06 --> Loader Class Initialized
INFO - 2018-02-14 15:21:06 --> Helper loaded: url_helper
INFO - 2018-02-14 15:21:06 --> Helper loaded: file_helper
INFO - 2018-02-14 15:21:06 --> Helper loaded: email_helper
INFO - 2018-02-14 15:21:06 --> Helper loaded: common_helper
INFO - 2018-02-14 15:21:06 --> Database Driver Class Initialized
DEBUG - 2018-02-14 15:21:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 15:21:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 15:21:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-14 15:21:06 --> Pagination Class Initialized
INFO - 2018-02-14 15:21:06 --> Helper loaded: form_helper
INFO - 2018-02-14 15:21:06 --> Form Validation Class Initialized
INFO - 2018-02-14 15:21:06 --> Model Class Initialized
INFO - 2018-02-14 15:21:06 --> Controller Class Initialized
INFO - 2018-02-14 15:21:06 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-14 15:21:06 --> Model Class Initialized
INFO - 2018-02-14 15:21:23 --> Config Class Initialized
INFO - 2018-02-14 15:21:23 --> Hooks Class Initialized
DEBUG - 2018-02-14 15:21:23 --> UTF-8 Support Enabled
INFO - 2018-02-14 15:21:23 --> Utf8 Class Initialized
INFO - 2018-02-14 15:21:23 --> URI Class Initialized
INFO - 2018-02-14 15:21:23 --> Router Class Initialized
INFO - 2018-02-14 15:21:23 --> Output Class Initialized
INFO - 2018-02-14 15:21:23 --> Security Class Initialized
DEBUG - 2018-02-14 15:21:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 15:21:23 --> Input Class Initialized
INFO - 2018-02-14 15:21:23 --> Language Class Initialized
INFO - 2018-02-14 15:21:23 --> Loader Class Initialized
INFO - 2018-02-14 15:21:23 --> Helper loaded: url_helper
INFO - 2018-02-14 15:21:23 --> Helper loaded: file_helper
INFO - 2018-02-14 15:21:23 --> Helper loaded: email_helper
INFO - 2018-02-14 15:21:23 --> Helper loaded: common_helper
INFO - 2018-02-14 15:21:23 --> Database Driver Class Initialized
DEBUG - 2018-02-14 15:21:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 15:21:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 15:21:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-14 15:21:23 --> Pagination Class Initialized
INFO - 2018-02-14 15:21:23 --> Helper loaded: form_helper
INFO - 2018-02-14 15:21:23 --> Form Validation Class Initialized
INFO - 2018-02-14 15:21:23 --> Model Class Initialized
INFO - 2018-02-14 15:21:23 --> Controller Class Initialized
INFO - 2018-02-14 15:21:23 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-14 15:21:23 --> Model Class Initialized
INFO - 2018-02-14 15:21:23 --> Config Class Initialized
INFO - 2018-02-14 15:21:23 --> Hooks Class Initialized
DEBUG - 2018-02-14 15:21:23 --> UTF-8 Support Enabled
INFO - 2018-02-14 15:21:23 --> Utf8 Class Initialized
INFO - 2018-02-14 15:21:23 --> URI Class Initialized
INFO - 2018-02-14 15:21:23 --> Router Class Initialized
INFO - 2018-02-14 15:21:23 --> Output Class Initialized
INFO - 2018-02-14 15:21:23 --> Security Class Initialized
DEBUG - 2018-02-14 15:21:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 15:21:23 --> Input Class Initialized
INFO - 2018-02-14 15:21:23 --> Language Class Initialized
INFO - 2018-02-14 15:21:23 --> Loader Class Initialized
INFO - 2018-02-14 15:21:23 --> Helper loaded: url_helper
INFO - 2018-02-14 15:21:23 --> Helper loaded: file_helper
INFO - 2018-02-14 15:21:23 --> Helper loaded: email_helper
INFO - 2018-02-14 15:21:23 --> Helper loaded: common_helper
INFO - 2018-02-14 15:21:23 --> Database Driver Class Initialized
DEBUG - 2018-02-14 15:21:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 15:21:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 15:21:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-14 15:21:23 --> Pagination Class Initialized
INFO - 2018-02-14 15:21:23 --> Helper loaded: form_helper
INFO - 2018-02-14 15:21:23 --> Form Validation Class Initialized
INFO - 2018-02-14 15:21:23 --> Model Class Initialized
INFO - 2018-02-14 15:21:23 --> Controller Class Initialized
INFO - 2018-02-14 15:21:23 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-14 15:21:23 --> Model Class Initialized
INFO - 2018-02-14 15:23:20 --> Config Class Initialized
INFO - 2018-02-14 15:23:20 --> Hooks Class Initialized
DEBUG - 2018-02-14 15:23:20 --> UTF-8 Support Enabled
INFO - 2018-02-14 15:23:20 --> Utf8 Class Initialized
INFO - 2018-02-14 15:23:20 --> URI Class Initialized
INFO - 2018-02-14 15:23:20 --> Router Class Initialized
INFO - 2018-02-14 15:23:20 --> Output Class Initialized
INFO - 2018-02-14 15:23:20 --> Security Class Initialized
DEBUG - 2018-02-14 15:23:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 15:23:20 --> Input Class Initialized
INFO - 2018-02-14 15:23:20 --> Language Class Initialized
INFO - 2018-02-14 15:23:20 --> Loader Class Initialized
INFO - 2018-02-14 15:23:20 --> Helper loaded: url_helper
INFO - 2018-02-14 15:23:20 --> Helper loaded: file_helper
INFO - 2018-02-14 15:23:20 --> Helper loaded: email_helper
INFO - 2018-02-14 15:23:20 --> Helper loaded: common_helper
INFO - 2018-02-14 15:23:20 --> Database Driver Class Initialized
DEBUG - 2018-02-14 15:23:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 15:23:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 15:23:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-14 15:23:20 --> Pagination Class Initialized
INFO - 2018-02-14 15:23:20 --> Helper loaded: form_helper
INFO - 2018-02-14 15:23:20 --> Form Validation Class Initialized
INFO - 2018-02-14 15:23:20 --> Model Class Initialized
INFO - 2018-02-14 15:23:20 --> Controller Class Initialized
INFO - 2018-02-14 15:23:20 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-14 15:23:20 --> Model Class Initialized
INFO - 2018-02-14 15:23:20 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-14 15:23:20 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-14 15:23:20 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-14 15:23:20 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-14 15:23:20 --> File loaded: /var/www/html/project/radio/application/views/category/add_edit.php
INFO - 2018-02-14 15:23:20 --> Final output sent to browser
DEBUG - 2018-02-14 15:23:20 --> Total execution time: 0.0081
INFO - 2018-02-14 15:23:25 --> Config Class Initialized
INFO - 2018-02-14 15:23:25 --> Hooks Class Initialized
DEBUG - 2018-02-14 15:23:25 --> UTF-8 Support Enabled
INFO - 2018-02-14 15:23:25 --> Utf8 Class Initialized
INFO - 2018-02-14 15:23:25 --> URI Class Initialized
INFO - 2018-02-14 15:23:25 --> Router Class Initialized
INFO - 2018-02-14 15:23:25 --> Output Class Initialized
INFO - 2018-02-14 15:23:25 --> Security Class Initialized
DEBUG - 2018-02-14 15:23:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 15:23:25 --> Input Class Initialized
INFO - 2018-02-14 15:23:25 --> Language Class Initialized
INFO - 2018-02-14 15:23:25 --> Loader Class Initialized
INFO - 2018-02-14 15:23:25 --> Helper loaded: url_helper
INFO - 2018-02-14 15:23:25 --> Helper loaded: file_helper
INFO - 2018-02-14 15:23:25 --> Helper loaded: email_helper
INFO - 2018-02-14 15:23:25 --> Helper loaded: common_helper
INFO - 2018-02-14 15:23:25 --> Database Driver Class Initialized
DEBUG - 2018-02-14 15:23:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 15:23:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 15:23:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-14 15:23:25 --> Pagination Class Initialized
INFO - 2018-02-14 15:23:25 --> Helper loaded: form_helper
INFO - 2018-02-14 15:23:25 --> Form Validation Class Initialized
INFO - 2018-02-14 15:23:25 --> Model Class Initialized
INFO - 2018-02-14 15:23:25 --> Controller Class Initialized
INFO - 2018-02-14 15:23:25 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-14 15:23:25 --> Model Class Initialized
INFO - 2018-02-14 15:23:25 --> Config Class Initialized
INFO - 2018-02-14 15:23:25 --> Hooks Class Initialized
DEBUG - 2018-02-14 15:23:25 --> UTF-8 Support Enabled
INFO - 2018-02-14 15:23:25 --> Utf8 Class Initialized
INFO - 2018-02-14 15:23:25 --> URI Class Initialized
INFO - 2018-02-14 15:23:25 --> Router Class Initialized
INFO - 2018-02-14 15:23:25 --> Output Class Initialized
INFO - 2018-02-14 15:23:25 --> Security Class Initialized
DEBUG - 2018-02-14 15:23:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 15:23:25 --> Input Class Initialized
INFO - 2018-02-14 15:23:25 --> Language Class Initialized
INFO - 2018-02-14 15:23:25 --> Loader Class Initialized
INFO - 2018-02-14 15:23:25 --> Helper loaded: url_helper
INFO - 2018-02-14 15:23:25 --> Helper loaded: file_helper
INFO - 2018-02-14 15:23:25 --> Helper loaded: email_helper
INFO - 2018-02-14 15:23:25 --> Helper loaded: common_helper
INFO - 2018-02-14 15:23:25 --> Database Driver Class Initialized
DEBUG - 2018-02-14 15:23:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 15:23:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 15:23:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-14 15:23:25 --> Pagination Class Initialized
INFO - 2018-02-14 15:23:25 --> Helper loaded: form_helper
INFO - 2018-02-14 15:23:25 --> Form Validation Class Initialized
INFO - 2018-02-14 15:23:25 --> Model Class Initialized
INFO - 2018-02-14 15:23:25 --> Controller Class Initialized
INFO - 2018-02-14 15:23:25 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-14 15:23:25 --> Model Class Initialized
DEBUG - 2018-02-14 15:23:25 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-14 15:23:25 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2018-02-14 15:23:25 --> Severity: Notice --> Undefined offset: 1 /var/www/html/project/radio/application/controllers/Category.php 232
INFO - 2018-02-14 15:23:25 --> Upload Class Initialized
INFO - 2018-02-14 15:23:25 --> Language file loaded: language/english/upload_lang.php
DEBUG - 2018-02-14 15:23:25 --> You did not select a file to upload.
ERROR - 2018-02-14 15:23:25 --> Severity: Notice --> Undefined index: status /var/www/html/project/radio/application/controllers/Category.php 136
INFO - 2018-02-14 15:23:25 --> Config Class Initialized
INFO - 2018-02-14 15:23:25 --> Hooks Class Initialized
DEBUG - 2018-02-14 15:23:25 --> UTF-8 Support Enabled
INFO - 2018-02-14 15:23:25 --> Utf8 Class Initialized
INFO - 2018-02-14 15:23:25 --> URI Class Initialized
INFO - 2018-02-14 15:23:25 --> Router Class Initialized
INFO - 2018-02-14 15:23:25 --> Output Class Initialized
INFO - 2018-02-14 15:23:25 --> Security Class Initialized
DEBUG - 2018-02-14 15:23:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 15:23:25 --> Input Class Initialized
INFO - 2018-02-14 15:23:25 --> Language Class Initialized
INFO - 2018-02-14 15:23:25 --> Loader Class Initialized
INFO - 2018-02-14 15:23:25 --> Helper loaded: url_helper
INFO - 2018-02-14 15:23:25 --> Helper loaded: file_helper
INFO - 2018-02-14 15:23:25 --> Helper loaded: email_helper
INFO - 2018-02-14 15:23:25 --> Helper loaded: common_helper
INFO - 2018-02-14 15:23:25 --> Database Driver Class Initialized
DEBUG - 2018-02-14 15:23:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 15:23:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 15:23:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-14 15:23:25 --> Pagination Class Initialized
INFO - 2018-02-14 15:23:25 --> Helper loaded: form_helper
INFO - 2018-02-14 15:23:25 --> Form Validation Class Initialized
INFO - 2018-02-14 15:23:25 --> Model Class Initialized
INFO - 2018-02-14 15:23:25 --> Controller Class Initialized
INFO - 2018-02-14 15:23:25 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-14 15:23:25 --> Model Class Initialized
INFO - 2018-02-14 15:23:25 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-14 15:23:25 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-14 15:23:25 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-14 15:23:25 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-14 15:23:25 --> File loaded: /var/www/html/project/radio/application/views/category/index.php
INFO - 2018-02-14 15:23:25 --> Final output sent to browser
DEBUG - 2018-02-14 15:23:25 --> Total execution time: 0.0062
INFO - 2018-02-14 15:24:20 --> Config Class Initialized
INFO - 2018-02-14 15:24:20 --> Hooks Class Initialized
DEBUG - 2018-02-14 15:24:20 --> UTF-8 Support Enabled
INFO - 2018-02-14 15:24:20 --> Utf8 Class Initialized
INFO - 2018-02-14 15:24:20 --> URI Class Initialized
INFO - 2018-02-14 15:24:20 --> Router Class Initialized
INFO - 2018-02-14 15:24:20 --> Output Class Initialized
INFO - 2018-02-14 15:24:20 --> Security Class Initialized
DEBUG - 2018-02-14 15:24:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 15:24:20 --> Input Class Initialized
INFO - 2018-02-14 15:24:20 --> Language Class Initialized
INFO - 2018-02-14 15:24:20 --> Loader Class Initialized
INFO - 2018-02-14 15:24:20 --> Helper loaded: url_helper
INFO - 2018-02-14 15:24:20 --> Helper loaded: file_helper
INFO - 2018-02-14 15:24:20 --> Helper loaded: email_helper
INFO - 2018-02-14 15:24:20 --> Helper loaded: common_helper
INFO - 2018-02-14 15:24:20 --> Database Driver Class Initialized
DEBUG - 2018-02-14 15:24:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 15:24:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 15:24:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-14 15:24:20 --> Pagination Class Initialized
INFO - 2018-02-14 15:24:20 --> Helper loaded: form_helper
INFO - 2018-02-14 15:24:20 --> Form Validation Class Initialized
INFO - 2018-02-14 15:24:20 --> Model Class Initialized
INFO - 2018-02-14 15:24:20 --> Controller Class Initialized
INFO - 2018-02-14 15:24:20 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-14 15:24:20 --> Model Class Initialized
INFO - 2018-02-14 15:24:20 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-14 15:24:20 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-14 15:24:20 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-14 15:24:20 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-14 15:24:20 --> File loaded: /var/www/html/project/radio/application/views/category/index.php
INFO - 2018-02-14 15:24:20 --> Final output sent to browser
DEBUG - 2018-02-14 15:24:20 --> Total execution time: 0.0069
INFO - 2018-02-14 15:24:21 --> Config Class Initialized
INFO - 2018-02-14 15:24:21 --> Hooks Class Initialized
DEBUG - 2018-02-14 15:24:21 --> UTF-8 Support Enabled
INFO - 2018-02-14 15:24:21 --> Utf8 Class Initialized
INFO - 2018-02-14 15:24:21 --> URI Class Initialized
INFO - 2018-02-14 15:24:21 --> Router Class Initialized
INFO - 2018-02-14 15:24:21 --> Output Class Initialized
INFO - 2018-02-14 15:24:21 --> Security Class Initialized
DEBUG - 2018-02-14 15:24:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 15:24:21 --> Input Class Initialized
INFO - 2018-02-14 15:24:21 --> Language Class Initialized
INFO - 2018-02-14 15:24:21 --> Loader Class Initialized
INFO - 2018-02-14 15:24:21 --> Helper loaded: url_helper
INFO - 2018-02-14 15:24:21 --> Helper loaded: file_helper
INFO - 2018-02-14 15:24:21 --> Helper loaded: email_helper
INFO - 2018-02-14 15:24:21 --> Helper loaded: common_helper
INFO - 2018-02-14 15:24:21 --> Database Driver Class Initialized
DEBUG - 2018-02-14 15:24:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 15:24:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 15:24:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-14 15:24:21 --> Pagination Class Initialized
INFO - 2018-02-14 15:24:21 --> Helper loaded: form_helper
INFO - 2018-02-14 15:24:21 --> Form Validation Class Initialized
INFO - 2018-02-14 15:24:21 --> Model Class Initialized
INFO - 2018-02-14 15:24:21 --> Controller Class Initialized
INFO - 2018-02-14 15:24:21 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-14 15:24:21 --> Model Class Initialized
INFO - 2018-02-14 15:24:21 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-14 15:24:21 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-14 15:24:21 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-14 15:24:21 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-14 15:24:21 --> File loaded: /var/www/html/project/radio/application/views/category/add_edit.php
INFO - 2018-02-14 15:24:21 --> Final output sent to browser
DEBUG - 2018-02-14 15:24:21 --> Total execution time: 0.0088
INFO - 2018-02-14 15:24:23 --> Config Class Initialized
INFO - 2018-02-14 15:24:23 --> Hooks Class Initialized
DEBUG - 2018-02-14 15:24:23 --> UTF-8 Support Enabled
INFO - 2018-02-14 15:24:23 --> Utf8 Class Initialized
INFO - 2018-02-14 15:24:23 --> URI Class Initialized
INFO - 2018-02-14 15:24:23 --> Router Class Initialized
INFO - 2018-02-14 15:24:23 --> Output Class Initialized
INFO - 2018-02-14 15:24:23 --> Security Class Initialized
DEBUG - 2018-02-14 15:24:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 15:24:23 --> Input Class Initialized
INFO - 2018-02-14 15:24:23 --> Language Class Initialized
INFO - 2018-02-14 15:24:23 --> Loader Class Initialized
INFO - 2018-02-14 15:24:23 --> Helper loaded: url_helper
INFO - 2018-02-14 15:24:23 --> Helper loaded: file_helper
INFO - 2018-02-14 15:24:23 --> Helper loaded: email_helper
INFO - 2018-02-14 15:24:23 --> Helper loaded: common_helper
INFO - 2018-02-14 15:24:23 --> Database Driver Class Initialized
DEBUG - 2018-02-14 15:24:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 15:24:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 15:24:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-14 15:24:23 --> Pagination Class Initialized
INFO - 2018-02-14 15:24:23 --> Helper loaded: form_helper
INFO - 2018-02-14 15:24:23 --> Form Validation Class Initialized
INFO - 2018-02-14 15:24:23 --> Model Class Initialized
INFO - 2018-02-14 15:24:23 --> Controller Class Initialized
INFO - 2018-02-14 15:24:23 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-14 15:24:23 --> Model Class Initialized
INFO - 2018-02-14 15:24:23 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-14 15:24:23 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-14 15:24:23 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-14 15:24:23 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-14 15:24:23 --> File loaded: /var/www/html/project/radio/application/views/category/index.php
INFO - 2018-02-14 15:24:23 --> Final output sent to browser
DEBUG - 2018-02-14 15:24:23 --> Total execution time: 0.0057
INFO - 2018-02-14 15:24:24 --> Config Class Initialized
INFO - 2018-02-14 15:24:24 --> Hooks Class Initialized
DEBUG - 2018-02-14 15:24:24 --> UTF-8 Support Enabled
INFO - 2018-02-14 15:24:24 --> Utf8 Class Initialized
INFO - 2018-02-14 15:24:24 --> URI Class Initialized
INFO - 2018-02-14 15:24:24 --> Router Class Initialized
INFO - 2018-02-14 15:24:24 --> Output Class Initialized
INFO - 2018-02-14 15:24:24 --> Security Class Initialized
DEBUG - 2018-02-14 15:24:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 15:24:24 --> Input Class Initialized
INFO - 2018-02-14 15:24:24 --> Language Class Initialized
INFO - 2018-02-14 15:24:24 --> Loader Class Initialized
INFO - 2018-02-14 15:24:24 --> Helper loaded: url_helper
INFO - 2018-02-14 15:24:24 --> Helper loaded: file_helper
INFO - 2018-02-14 15:24:24 --> Helper loaded: email_helper
INFO - 2018-02-14 15:24:24 --> Helper loaded: common_helper
INFO - 2018-02-14 15:24:24 --> Database Driver Class Initialized
DEBUG - 2018-02-14 15:24:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 15:24:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 15:24:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-14 15:24:24 --> Pagination Class Initialized
INFO - 2018-02-14 15:24:24 --> Helper loaded: form_helper
INFO - 2018-02-14 15:24:24 --> Form Validation Class Initialized
INFO - 2018-02-14 15:24:24 --> Model Class Initialized
INFO - 2018-02-14 15:24:24 --> Controller Class Initialized
INFO - 2018-02-14 15:24:24 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-14 15:24:24 --> Model Class Initialized
INFO - 2018-02-14 15:24:24 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-14 15:24:24 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-14 15:24:24 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-14 15:24:24 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-14 15:24:24 --> File loaded: /var/www/html/project/radio/application/views/category/add_edit.php
INFO - 2018-02-14 15:24:24 --> Final output sent to browser
DEBUG - 2018-02-14 15:24:24 --> Total execution time: 0.0056
INFO - 2018-02-14 15:24:27 --> Config Class Initialized
INFO - 2018-02-14 15:24:27 --> Hooks Class Initialized
DEBUG - 2018-02-14 15:24:27 --> UTF-8 Support Enabled
INFO - 2018-02-14 15:24:27 --> Utf8 Class Initialized
INFO - 2018-02-14 15:24:27 --> URI Class Initialized
INFO - 2018-02-14 15:24:27 --> Router Class Initialized
INFO - 2018-02-14 15:24:27 --> Output Class Initialized
INFO - 2018-02-14 15:24:27 --> Security Class Initialized
DEBUG - 2018-02-14 15:24:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 15:24:27 --> Input Class Initialized
INFO - 2018-02-14 15:24:27 --> Language Class Initialized
INFO - 2018-02-14 15:24:27 --> Loader Class Initialized
INFO - 2018-02-14 15:24:27 --> Helper loaded: url_helper
INFO - 2018-02-14 15:24:27 --> Helper loaded: file_helper
INFO - 2018-02-14 15:24:27 --> Helper loaded: email_helper
INFO - 2018-02-14 15:24:27 --> Helper loaded: common_helper
INFO - 2018-02-14 15:24:27 --> Database Driver Class Initialized
DEBUG - 2018-02-14 15:24:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 15:24:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 15:24:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-14 15:24:27 --> Pagination Class Initialized
INFO - 2018-02-14 15:24:27 --> Helper loaded: form_helper
INFO - 2018-02-14 15:24:27 --> Form Validation Class Initialized
INFO - 2018-02-14 15:24:27 --> Model Class Initialized
INFO - 2018-02-14 15:24:27 --> Controller Class Initialized
INFO - 2018-02-14 15:24:27 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-14 15:24:27 --> Model Class Initialized
INFO - 2018-02-14 15:24:27 --> Config Class Initialized
INFO - 2018-02-14 15:24:27 --> Hooks Class Initialized
DEBUG - 2018-02-14 15:24:27 --> UTF-8 Support Enabled
INFO - 2018-02-14 15:24:27 --> Utf8 Class Initialized
INFO - 2018-02-14 15:24:27 --> URI Class Initialized
INFO - 2018-02-14 15:24:27 --> Router Class Initialized
INFO - 2018-02-14 15:24:27 --> Output Class Initialized
INFO - 2018-02-14 15:24:27 --> Security Class Initialized
DEBUG - 2018-02-14 15:24:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 15:24:27 --> Input Class Initialized
INFO - 2018-02-14 15:24:27 --> Language Class Initialized
INFO - 2018-02-14 15:24:27 --> Loader Class Initialized
INFO - 2018-02-14 15:24:27 --> Helper loaded: url_helper
INFO - 2018-02-14 15:24:27 --> Helper loaded: file_helper
INFO - 2018-02-14 15:24:27 --> Helper loaded: email_helper
INFO - 2018-02-14 15:24:27 --> Helper loaded: common_helper
INFO - 2018-02-14 15:24:27 --> Database Driver Class Initialized
DEBUG - 2018-02-14 15:24:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 15:24:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 15:24:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-14 15:24:27 --> Pagination Class Initialized
INFO - 2018-02-14 15:24:27 --> Helper loaded: form_helper
INFO - 2018-02-14 15:24:27 --> Form Validation Class Initialized
INFO - 2018-02-14 15:24:27 --> Model Class Initialized
INFO - 2018-02-14 15:24:27 --> Controller Class Initialized
INFO - 2018-02-14 15:24:27 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-14 15:24:27 --> Model Class Initialized
INFO - 2018-02-14 15:24:59 --> Config Class Initialized
INFO - 2018-02-14 15:24:59 --> Hooks Class Initialized
DEBUG - 2018-02-14 15:24:59 --> UTF-8 Support Enabled
INFO - 2018-02-14 15:24:59 --> Utf8 Class Initialized
INFO - 2018-02-14 15:24:59 --> URI Class Initialized
INFO - 2018-02-14 15:24:59 --> Router Class Initialized
INFO - 2018-02-14 15:24:59 --> Output Class Initialized
INFO - 2018-02-14 15:24:59 --> Security Class Initialized
DEBUG - 2018-02-14 15:24:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 15:24:59 --> Input Class Initialized
INFO - 2018-02-14 15:24:59 --> Language Class Initialized
INFO - 2018-02-14 15:24:59 --> Loader Class Initialized
INFO - 2018-02-14 15:24:59 --> Helper loaded: url_helper
INFO - 2018-02-14 15:24:59 --> Helper loaded: file_helper
INFO - 2018-02-14 15:24:59 --> Helper loaded: email_helper
INFO - 2018-02-14 15:24:59 --> Helper loaded: common_helper
INFO - 2018-02-14 15:24:59 --> Database Driver Class Initialized
DEBUG - 2018-02-14 15:24:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 15:24:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 15:24:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-14 15:24:59 --> Pagination Class Initialized
INFO - 2018-02-14 15:24:59 --> Helper loaded: form_helper
INFO - 2018-02-14 15:24:59 --> Form Validation Class Initialized
INFO - 2018-02-14 15:24:59 --> Model Class Initialized
INFO - 2018-02-14 15:24:59 --> Controller Class Initialized
INFO - 2018-02-14 15:24:59 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-14 15:24:59 --> Model Class Initialized
INFO - 2018-02-14 15:24:59 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-14 15:24:59 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-14 15:24:59 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-14 15:24:59 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-14 15:24:59 --> File loaded: /var/www/html/project/radio/application/views/category/add_edit.php
INFO - 2018-02-14 15:24:59 --> Final output sent to browser
DEBUG - 2018-02-14 15:24:59 --> Total execution time: 0.0083
INFO - 2018-02-14 15:25:06 --> Config Class Initialized
INFO - 2018-02-14 15:25:06 --> Hooks Class Initialized
DEBUG - 2018-02-14 15:25:06 --> UTF-8 Support Enabled
INFO - 2018-02-14 15:25:06 --> Utf8 Class Initialized
INFO - 2018-02-14 15:25:06 --> URI Class Initialized
INFO - 2018-02-14 15:25:06 --> Router Class Initialized
INFO - 2018-02-14 15:25:06 --> Output Class Initialized
INFO - 2018-02-14 15:25:06 --> Security Class Initialized
DEBUG - 2018-02-14 15:25:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 15:25:06 --> Input Class Initialized
INFO - 2018-02-14 15:25:06 --> Language Class Initialized
INFO - 2018-02-14 15:25:06 --> Loader Class Initialized
INFO - 2018-02-14 15:25:06 --> Helper loaded: url_helper
INFO - 2018-02-14 15:25:06 --> Helper loaded: file_helper
INFO - 2018-02-14 15:25:06 --> Helper loaded: email_helper
INFO - 2018-02-14 15:25:06 --> Helper loaded: common_helper
INFO - 2018-02-14 15:25:06 --> Database Driver Class Initialized
DEBUG - 2018-02-14 15:25:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 15:25:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 15:25:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-14 15:25:06 --> Pagination Class Initialized
INFO - 2018-02-14 15:25:06 --> Helper loaded: form_helper
INFO - 2018-02-14 15:25:06 --> Form Validation Class Initialized
INFO - 2018-02-14 15:25:06 --> Model Class Initialized
INFO - 2018-02-14 15:25:06 --> Controller Class Initialized
INFO - 2018-02-14 15:25:06 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-14 15:25:06 --> Model Class Initialized
INFO - 2018-02-14 15:25:06 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-14 15:25:06 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-14 15:25:06 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-14 15:25:06 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-14 15:25:06 --> File loaded: /var/www/html/project/radio/application/views/category/add_edit.php
INFO - 2018-02-14 15:25:06 --> Final output sent to browser
DEBUG - 2018-02-14 15:25:06 --> Total execution time: 0.0104
INFO - 2018-02-14 15:25:07 --> Config Class Initialized
INFO - 2018-02-14 15:25:07 --> Hooks Class Initialized
DEBUG - 2018-02-14 15:25:07 --> UTF-8 Support Enabled
INFO - 2018-02-14 15:25:07 --> Utf8 Class Initialized
INFO - 2018-02-14 15:25:07 --> URI Class Initialized
INFO - 2018-02-14 15:25:07 --> Router Class Initialized
INFO - 2018-02-14 15:25:07 --> Output Class Initialized
INFO - 2018-02-14 15:25:07 --> Security Class Initialized
DEBUG - 2018-02-14 15:25:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 15:25:07 --> Input Class Initialized
INFO - 2018-02-14 15:25:07 --> Language Class Initialized
INFO - 2018-02-14 15:25:07 --> Loader Class Initialized
INFO - 2018-02-14 15:25:07 --> Helper loaded: url_helper
INFO - 2018-02-14 15:25:07 --> Helper loaded: file_helper
INFO - 2018-02-14 15:25:07 --> Helper loaded: email_helper
INFO - 2018-02-14 15:25:07 --> Helper loaded: common_helper
INFO - 2018-02-14 15:25:07 --> Database Driver Class Initialized
DEBUG - 2018-02-14 15:25:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 15:25:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 15:25:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-14 15:25:07 --> Pagination Class Initialized
INFO - 2018-02-14 15:25:07 --> Helper loaded: form_helper
INFO - 2018-02-14 15:25:07 --> Form Validation Class Initialized
INFO - 2018-02-14 15:25:07 --> Model Class Initialized
INFO - 2018-02-14 15:25:07 --> Controller Class Initialized
INFO - 2018-02-14 15:25:07 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-14 15:25:07 --> Model Class Initialized
INFO - 2018-02-14 15:25:07 --> Config Class Initialized
INFO - 2018-02-14 15:25:07 --> Hooks Class Initialized
DEBUG - 2018-02-14 15:25:07 --> UTF-8 Support Enabled
INFO - 2018-02-14 15:25:07 --> Utf8 Class Initialized
INFO - 2018-02-14 15:25:07 --> URI Class Initialized
INFO - 2018-02-14 15:25:07 --> Router Class Initialized
INFO - 2018-02-14 15:25:07 --> Output Class Initialized
INFO - 2018-02-14 15:25:07 --> Security Class Initialized
DEBUG - 2018-02-14 15:25:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 15:25:07 --> Input Class Initialized
INFO - 2018-02-14 15:25:07 --> Language Class Initialized
INFO - 2018-02-14 15:25:07 --> Loader Class Initialized
INFO - 2018-02-14 15:25:07 --> Helper loaded: url_helper
INFO - 2018-02-14 15:25:07 --> Helper loaded: file_helper
INFO - 2018-02-14 15:25:07 --> Helper loaded: email_helper
INFO - 2018-02-14 15:25:07 --> Helper loaded: common_helper
INFO - 2018-02-14 15:25:07 --> Database Driver Class Initialized
DEBUG - 2018-02-14 15:25:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 15:25:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 15:25:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-14 15:25:07 --> Pagination Class Initialized
INFO - 2018-02-14 15:25:07 --> Helper loaded: form_helper
INFO - 2018-02-14 15:25:07 --> Form Validation Class Initialized
INFO - 2018-02-14 15:25:07 --> Model Class Initialized
INFO - 2018-02-14 15:25:07 --> Controller Class Initialized
INFO - 2018-02-14 15:25:07 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-14 15:25:07 --> Model Class Initialized
DEBUG - 2018-02-14 15:25:07 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-14 15:25:07 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-02-14 15:25:07 --> Config Class Initialized
INFO - 2018-02-14 15:25:07 --> Hooks Class Initialized
DEBUG - 2018-02-14 15:25:07 --> UTF-8 Support Enabled
INFO - 2018-02-14 15:25:07 --> Utf8 Class Initialized
INFO - 2018-02-14 15:25:07 --> URI Class Initialized
INFO - 2018-02-14 15:25:07 --> Router Class Initialized
INFO - 2018-02-14 15:25:07 --> Output Class Initialized
INFO - 2018-02-14 15:25:07 --> Security Class Initialized
DEBUG - 2018-02-14 15:25:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 15:25:07 --> Input Class Initialized
INFO - 2018-02-14 15:25:07 --> Language Class Initialized
INFO - 2018-02-14 15:25:07 --> Loader Class Initialized
INFO - 2018-02-14 15:25:07 --> Helper loaded: url_helper
INFO - 2018-02-14 15:25:07 --> Helper loaded: file_helper
INFO - 2018-02-14 15:25:07 --> Helper loaded: email_helper
INFO - 2018-02-14 15:25:07 --> Helper loaded: common_helper
INFO - 2018-02-14 15:25:07 --> Database Driver Class Initialized
DEBUG - 2018-02-14 15:25:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 15:25:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 15:25:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-14 15:25:07 --> Pagination Class Initialized
INFO - 2018-02-14 15:25:07 --> Helper loaded: form_helper
INFO - 2018-02-14 15:25:07 --> Form Validation Class Initialized
INFO - 2018-02-14 15:25:07 --> Model Class Initialized
INFO - 2018-02-14 15:25:07 --> Controller Class Initialized
INFO - 2018-02-14 15:25:07 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-14 15:25:07 --> Model Class Initialized
INFO - 2018-02-14 15:25:07 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-14 15:25:07 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-14 15:25:07 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-14 15:25:07 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-14 15:25:07 --> File loaded: /var/www/html/project/radio/application/views/category/index.php
INFO - 2018-02-14 15:25:07 --> Final output sent to browser
DEBUG - 2018-02-14 15:25:07 --> Total execution time: 0.0048
INFO - 2018-02-14 15:25:10 --> Config Class Initialized
INFO - 2018-02-14 15:25:10 --> Hooks Class Initialized
DEBUG - 2018-02-14 15:25:10 --> UTF-8 Support Enabled
INFO - 2018-02-14 15:25:10 --> Utf8 Class Initialized
INFO - 2018-02-14 15:25:10 --> URI Class Initialized
INFO - 2018-02-14 15:25:10 --> Router Class Initialized
INFO - 2018-02-14 15:25:10 --> Output Class Initialized
INFO - 2018-02-14 15:25:10 --> Security Class Initialized
DEBUG - 2018-02-14 15:25:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 15:25:10 --> Input Class Initialized
INFO - 2018-02-14 15:25:10 --> Language Class Initialized
INFO - 2018-02-14 15:25:10 --> Loader Class Initialized
INFO - 2018-02-14 15:25:10 --> Helper loaded: url_helper
INFO - 2018-02-14 15:25:10 --> Helper loaded: file_helper
INFO - 2018-02-14 15:25:10 --> Helper loaded: email_helper
INFO - 2018-02-14 15:25:10 --> Helper loaded: common_helper
INFO - 2018-02-14 15:25:10 --> Database Driver Class Initialized
DEBUG - 2018-02-14 15:25:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 15:25:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 15:25:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-14 15:25:10 --> Pagination Class Initialized
INFO - 2018-02-14 15:25:10 --> Helper loaded: form_helper
INFO - 2018-02-14 15:25:10 --> Form Validation Class Initialized
INFO - 2018-02-14 15:25:10 --> Model Class Initialized
INFO - 2018-02-14 15:25:10 --> Controller Class Initialized
INFO - 2018-02-14 15:25:10 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-14 15:25:10 --> Model Class Initialized
INFO - 2018-02-14 15:25:10 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-14 15:25:10 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-14 15:25:10 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-14 15:25:10 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-14 15:25:10 --> File loaded: /var/www/html/project/radio/application/views/category/add_edit.php
INFO - 2018-02-14 15:25:10 --> Final output sent to browser
DEBUG - 2018-02-14 15:25:10 --> Total execution time: 0.0065
INFO - 2018-02-14 15:25:11 --> Config Class Initialized
INFO - 2018-02-14 15:25:11 --> Hooks Class Initialized
DEBUG - 2018-02-14 15:25:11 --> UTF-8 Support Enabled
INFO - 2018-02-14 15:25:11 --> Utf8 Class Initialized
INFO - 2018-02-14 15:25:11 --> URI Class Initialized
INFO - 2018-02-14 15:25:11 --> Router Class Initialized
INFO - 2018-02-14 15:25:11 --> Output Class Initialized
INFO - 2018-02-14 15:25:11 --> Security Class Initialized
DEBUG - 2018-02-14 15:25:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 15:25:11 --> Input Class Initialized
INFO - 2018-02-14 15:25:11 --> Language Class Initialized
INFO - 2018-02-14 15:25:11 --> Loader Class Initialized
INFO - 2018-02-14 15:25:11 --> Helper loaded: url_helper
INFO - 2018-02-14 15:25:11 --> Helper loaded: file_helper
INFO - 2018-02-14 15:25:11 --> Helper loaded: email_helper
INFO - 2018-02-14 15:25:11 --> Helper loaded: common_helper
INFO - 2018-02-14 15:25:11 --> Database Driver Class Initialized
DEBUG - 2018-02-14 15:25:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 15:25:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 15:25:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-14 15:25:11 --> Pagination Class Initialized
INFO - 2018-02-14 15:25:11 --> Helper loaded: form_helper
INFO - 2018-02-14 15:25:11 --> Form Validation Class Initialized
INFO - 2018-02-14 15:25:11 --> Model Class Initialized
INFO - 2018-02-14 15:25:11 --> Controller Class Initialized
INFO - 2018-02-14 15:25:11 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-14 15:25:11 --> Model Class Initialized
INFO - 2018-02-14 15:25:11 --> Config Class Initialized
INFO - 2018-02-14 15:25:11 --> Hooks Class Initialized
DEBUG - 2018-02-14 15:25:11 --> UTF-8 Support Enabled
INFO - 2018-02-14 15:25:11 --> Utf8 Class Initialized
INFO - 2018-02-14 15:25:11 --> URI Class Initialized
INFO - 2018-02-14 15:25:11 --> Router Class Initialized
INFO - 2018-02-14 15:25:11 --> Output Class Initialized
INFO - 2018-02-14 15:25:11 --> Security Class Initialized
DEBUG - 2018-02-14 15:25:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 15:25:11 --> Input Class Initialized
INFO - 2018-02-14 15:25:11 --> Language Class Initialized
INFO - 2018-02-14 15:25:11 --> Loader Class Initialized
INFO - 2018-02-14 15:25:11 --> Helper loaded: url_helper
INFO - 2018-02-14 15:25:11 --> Helper loaded: file_helper
INFO - 2018-02-14 15:25:11 --> Helper loaded: email_helper
INFO - 2018-02-14 15:25:11 --> Helper loaded: common_helper
INFO - 2018-02-14 15:25:11 --> Database Driver Class Initialized
DEBUG - 2018-02-14 15:25:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 15:25:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 15:25:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-14 15:25:11 --> Pagination Class Initialized
INFO - 2018-02-14 15:25:11 --> Helper loaded: form_helper
INFO - 2018-02-14 15:25:11 --> Form Validation Class Initialized
INFO - 2018-02-14 15:25:11 --> Model Class Initialized
INFO - 2018-02-14 15:25:11 --> Controller Class Initialized
INFO - 2018-02-14 15:25:11 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-14 15:25:11 --> Model Class Initialized
DEBUG - 2018-02-14 15:25:11 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-14 15:25:11 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-02-14 15:25:11 --> Config Class Initialized
INFO - 2018-02-14 15:25:11 --> Hooks Class Initialized
DEBUG - 2018-02-14 15:25:11 --> UTF-8 Support Enabled
INFO - 2018-02-14 15:25:11 --> Utf8 Class Initialized
INFO - 2018-02-14 15:25:11 --> URI Class Initialized
INFO - 2018-02-14 15:25:11 --> Router Class Initialized
INFO - 2018-02-14 15:25:11 --> Output Class Initialized
INFO - 2018-02-14 15:25:11 --> Security Class Initialized
DEBUG - 2018-02-14 15:25:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 15:25:11 --> Input Class Initialized
INFO - 2018-02-14 15:25:11 --> Language Class Initialized
INFO - 2018-02-14 15:25:11 --> Loader Class Initialized
INFO - 2018-02-14 15:25:11 --> Helper loaded: url_helper
INFO - 2018-02-14 15:25:11 --> Helper loaded: file_helper
INFO - 2018-02-14 15:25:11 --> Helper loaded: email_helper
INFO - 2018-02-14 15:25:11 --> Helper loaded: common_helper
INFO - 2018-02-14 15:25:11 --> Database Driver Class Initialized
DEBUG - 2018-02-14 15:25:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 15:25:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 15:25:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-14 15:25:11 --> Pagination Class Initialized
INFO - 2018-02-14 15:25:11 --> Helper loaded: form_helper
INFO - 2018-02-14 15:25:11 --> Form Validation Class Initialized
INFO - 2018-02-14 15:25:11 --> Model Class Initialized
INFO - 2018-02-14 15:25:11 --> Controller Class Initialized
INFO - 2018-02-14 15:25:11 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-14 15:25:11 --> Model Class Initialized
INFO - 2018-02-14 15:25:11 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-14 15:25:11 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-14 15:25:11 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-14 15:25:11 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-14 15:25:11 --> File loaded: /var/www/html/project/radio/application/views/category/index.php
INFO - 2018-02-14 15:25:11 --> Final output sent to browser
DEBUG - 2018-02-14 15:25:11 --> Total execution time: 0.0064
INFO - 2018-02-14 15:25:14 --> Config Class Initialized
INFO - 2018-02-14 15:25:14 --> Hooks Class Initialized
DEBUG - 2018-02-14 15:25:14 --> UTF-8 Support Enabled
INFO - 2018-02-14 15:25:14 --> Utf8 Class Initialized
INFO - 2018-02-14 15:25:14 --> URI Class Initialized
INFO - 2018-02-14 15:25:14 --> Router Class Initialized
INFO - 2018-02-14 15:25:14 --> Output Class Initialized
INFO - 2018-02-14 15:25:14 --> Security Class Initialized
DEBUG - 2018-02-14 15:25:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 15:25:14 --> Input Class Initialized
INFO - 2018-02-14 15:25:14 --> Language Class Initialized
INFO - 2018-02-14 15:25:14 --> Loader Class Initialized
INFO - 2018-02-14 15:25:14 --> Helper loaded: url_helper
INFO - 2018-02-14 15:25:14 --> Helper loaded: file_helper
INFO - 2018-02-14 15:25:14 --> Helper loaded: email_helper
INFO - 2018-02-14 15:25:14 --> Helper loaded: common_helper
INFO - 2018-02-14 15:25:14 --> Database Driver Class Initialized
DEBUG - 2018-02-14 15:25:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 15:25:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 15:25:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-14 15:25:14 --> Pagination Class Initialized
INFO - 2018-02-14 15:25:14 --> Helper loaded: form_helper
INFO - 2018-02-14 15:25:14 --> Form Validation Class Initialized
INFO - 2018-02-14 15:25:14 --> Model Class Initialized
INFO - 2018-02-14 15:25:14 --> Controller Class Initialized
INFO - 2018-02-14 15:25:14 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-14 15:25:14 --> Model Class Initialized
INFO - 2018-02-14 15:25:14 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-14 15:25:14 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-14 15:25:14 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-14 15:25:14 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-14 15:25:14 --> File loaded: /var/www/html/project/radio/application/views/category/add_edit.php
INFO - 2018-02-14 15:25:14 --> Final output sent to browser
DEBUG - 2018-02-14 15:25:14 --> Total execution time: 0.0054
INFO - 2018-02-14 15:25:19 --> Config Class Initialized
INFO - 2018-02-14 15:25:19 --> Hooks Class Initialized
DEBUG - 2018-02-14 15:25:19 --> UTF-8 Support Enabled
INFO - 2018-02-14 15:25:19 --> Utf8 Class Initialized
INFO - 2018-02-14 15:25:19 --> URI Class Initialized
INFO - 2018-02-14 15:25:19 --> Router Class Initialized
INFO - 2018-02-14 15:25:19 --> Output Class Initialized
INFO - 2018-02-14 15:25:19 --> Security Class Initialized
DEBUG - 2018-02-14 15:25:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 15:25:19 --> Input Class Initialized
INFO - 2018-02-14 15:25:19 --> Language Class Initialized
INFO - 2018-02-14 15:25:19 --> Loader Class Initialized
INFO - 2018-02-14 15:25:19 --> Helper loaded: url_helper
INFO - 2018-02-14 15:25:19 --> Helper loaded: file_helper
INFO - 2018-02-14 15:25:19 --> Helper loaded: email_helper
INFO - 2018-02-14 15:25:19 --> Helper loaded: common_helper
INFO - 2018-02-14 15:25:19 --> Database Driver Class Initialized
DEBUG - 2018-02-14 15:25:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 15:25:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 15:25:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-14 15:25:19 --> Pagination Class Initialized
INFO - 2018-02-14 15:25:19 --> Helper loaded: form_helper
INFO - 2018-02-14 15:25:19 --> Form Validation Class Initialized
INFO - 2018-02-14 15:25:19 --> Model Class Initialized
INFO - 2018-02-14 15:25:19 --> Controller Class Initialized
INFO - 2018-02-14 15:25:19 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-14 15:25:19 --> Model Class Initialized
INFO - 2018-02-14 15:25:19 --> Config Class Initialized
INFO - 2018-02-14 15:25:19 --> Hooks Class Initialized
DEBUG - 2018-02-14 15:25:19 --> UTF-8 Support Enabled
INFO - 2018-02-14 15:25:19 --> Utf8 Class Initialized
INFO - 2018-02-14 15:25:19 --> URI Class Initialized
INFO - 2018-02-14 15:25:19 --> Router Class Initialized
INFO - 2018-02-14 15:25:19 --> Output Class Initialized
INFO - 2018-02-14 15:25:19 --> Security Class Initialized
DEBUG - 2018-02-14 15:25:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 15:25:19 --> Input Class Initialized
INFO - 2018-02-14 15:25:19 --> Language Class Initialized
INFO - 2018-02-14 15:25:19 --> Loader Class Initialized
INFO - 2018-02-14 15:25:19 --> Helper loaded: url_helper
INFO - 2018-02-14 15:25:19 --> Helper loaded: file_helper
INFO - 2018-02-14 15:25:19 --> Helper loaded: email_helper
INFO - 2018-02-14 15:25:19 --> Helper loaded: common_helper
INFO - 2018-02-14 15:25:19 --> Database Driver Class Initialized
DEBUG - 2018-02-14 15:25:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 15:25:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 15:25:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-14 15:25:19 --> Pagination Class Initialized
INFO - 2018-02-14 15:25:19 --> Helper loaded: form_helper
INFO - 2018-02-14 15:25:19 --> Form Validation Class Initialized
INFO - 2018-02-14 15:25:19 --> Model Class Initialized
INFO - 2018-02-14 15:25:19 --> Controller Class Initialized
INFO - 2018-02-14 15:25:19 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-14 15:25:19 --> Model Class Initialized
DEBUG - 2018-02-14 15:25:19 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-14 15:25:19 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-02-14 15:25:19 --> Upload Class Initialized
INFO - 2018-02-14 15:25:19 --> Config Class Initialized
INFO - 2018-02-14 15:25:19 --> Hooks Class Initialized
DEBUG - 2018-02-14 15:25:19 --> UTF-8 Support Enabled
INFO - 2018-02-14 15:25:19 --> Utf8 Class Initialized
INFO - 2018-02-14 15:25:19 --> URI Class Initialized
INFO - 2018-02-14 15:25:19 --> Router Class Initialized
INFO - 2018-02-14 15:25:19 --> Output Class Initialized
INFO - 2018-02-14 15:25:19 --> Security Class Initialized
DEBUG - 2018-02-14 15:25:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 15:25:19 --> Input Class Initialized
INFO - 2018-02-14 15:25:19 --> Language Class Initialized
INFO - 2018-02-14 15:25:19 --> Loader Class Initialized
INFO - 2018-02-14 15:25:19 --> Helper loaded: url_helper
INFO - 2018-02-14 15:25:19 --> Helper loaded: file_helper
INFO - 2018-02-14 15:25:19 --> Helper loaded: email_helper
INFO - 2018-02-14 15:25:19 --> Helper loaded: common_helper
INFO - 2018-02-14 15:25:19 --> Database Driver Class Initialized
DEBUG - 2018-02-14 15:25:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 15:25:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 15:25:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-14 15:25:19 --> Pagination Class Initialized
INFO - 2018-02-14 15:25:19 --> Helper loaded: form_helper
INFO - 2018-02-14 15:25:19 --> Form Validation Class Initialized
INFO - 2018-02-14 15:25:19 --> Model Class Initialized
INFO - 2018-02-14 15:25:19 --> Controller Class Initialized
INFO - 2018-02-14 15:25:19 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-14 15:25:19 --> Model Class Initialized
INFO - 2018-02-14 15:25:19 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-14 15:25:19 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-14 15:25:19 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-14 15:25:19 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-14 15:25:19 --> File loaded: /var/www/html/project/radio/application/views/category/index.php
INFO - 2018-02-14 15:25:19 --> Final output sent to browser
DEBUG - 2018-02-14 15:25:19 --> Total execution time: 0.0068
INFO - 2018-02-14 15:25:24 --> Config Class Initialized
INFO - 2018-02-14 15:25:24 --> Hooks Class Initialized
DEBUG - 2018-02-14 15:25:24 --> UTF-8 Support Enabled
INFO - 2018-02-14 15:25:24 --> Utf8 Class Initialized
INFO - 2018-02-14 15:25:24 --> URI Class Initialized
INFO - 2018-02-14 15:25:24 --> Router Class Initialized
INFO - 2018-02-14 15:25:24 --> Output Class Initialized
INFO - 2018-02-14 15:25:24 --> Security Class Initialized
DEBUG - 2018-02-14 15:25:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 15:25:24 --> Input Class Initialized
INFO - 2018-02-14 15:25:24 --> Language Class Initialized
INFO - 2018-02-14 15:25:24 --> Loader Class Initialized
INFO - 2018-02-14 15:25:24 --> Helper loaded: url_helper
INFO - 2018-02-14 15:25:24 --> Helper loaded: file_helper
INFO - 2018-02-14 15:25:24 --> Helper loaded: email_helper
INFO - 2018-02-14 15:25:24 --> Helper loaded: common_helper
INFO - 2018-02-14 15:25:24 --> Database Driver Class Initialized
DEBUG - 2018-02-14 15:25:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 15:25:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 15:25:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-14 15:25:24 --> Pagination Class Initialized
INFO - 2018-02-14 15:25:24 --> Helper loaded: form_helper
INFO - 2018-02-14 15:25:24 --> Form Validation Class Initialized
INFO - 2018-02-14 15:25:24 --> Model Class Initialized
INFO - 2018-02-14 15:25:24 --> Controller Class Initialized
INFO - 2018-02-14 15:25:24 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-14 15:25:24 --> Model Class Initialized
INFO - 2018-02-14 15:25:24 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-14 15:25:24 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-14 15:25:24 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-14 15:25:24 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-14 15:25:24 --> File loaded: /var/www/html/project/radio/application/views/category/add_edit.php
INFO - 2018-02-14 15:25:24 --> Final output sent to browser
DEBUG - 2018-02-14 15:25:24 --> Total execution time: 0.0059
INFO - 2018-02-14 15:25:27 --> Config Class Initialized
INFO - 2018-02-14 15:25:27 --> Hooks Class Initialized
DEBUG - 2018-02-14 15:25:27 --> UTF-8 Support Enabled
INFO - 2018-02-14 15:25:27 --> Utf8 Class Initialized
INFO - 2018-02-14 15:25:27 --> URI Class Initialized
INFO - 2018-02-14 15:25:27 --> Router Class Initialized
INFO - 2018-02-14 15:25:27 --> Output Class Initialized
INFO - 2018-02-14 15:25:27 --> Security Class Initialized
DEBUG - 2018-02-14 15:25:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 15:25:27 --> Input Class Initialized
INFO - 2018-02-14 15:25:27 --> Language Class Initialized
INFO - 2018-02-14 15:25:27 --> Loader Class Initialized
INFO - 2018-02-14 15:25:27 --> Helper loaded: url_helper
INFO - 2018-02-14 15:25:27 --> Helper loaded: file_helper
INFO - 2018-02-14 15:25:27 --> Helper loaded: email_helper
INFO - 2018-02-14 15:25:27 --> Helper loaded: common_helper
INFO - 2018-02-14 15:25:27 --> Database Driver Class Initialized
DEBUG - 2018-02-14 15:25:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 15:25:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 15:25:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-14 15:25:27 --> Pagination Class Initialized
INFO - 2018-02-14 15:25:27 --> Helper loaded: form_helper
INFO - 2018-02-14 15:25:27 --> Form Validation Class Initialized
INFO - 2018-02-14 15:25:27 --> Model Class Initialized
INFO - 2018-02-14 15:25:27 --> Controller Class Initialized
INFO - 2018-02-14 15:25:27 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-14 15:25:27 --> Model Class Initialized
INFO - 2018-02-14 15:25:27 --> Config Class Initialized
INFO - 2018-02-14 15:25:27 --> Hooks Class Initialized
DEBUG - 2018-02-14 15:25:27 --> UTF-8 Support Enabled
INFO - 2018-02-14 15:25:27 --> Utf8 Class Initialized
INFO - 2018-02-14 15:25:27 --> URI Class Initialized
INFO - 2018-02-14 15:25:27 --> Router Class Initialized
INFO - 2018-02-14 15:25:27 --> Output Class Initialized
INFO - 2018-02-14 15:25:27 --> Security Class Initialized
DEBUG - 2018-02-14 15:25:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 15:25:27 --> Input Class Initialized
INFO - 2018-02-14 15:25:27 --> Language Class Initialized
INFO - 2018-02-14 15:25:27 --> Loader Class Initialized
INFO - 2018-02-14 15:25:27 --> Helper loaded: url_helper
INFO - 2018-02-14 15:25:27 --> Helper loaded: file_helper
INFO - 2018-02-14 15:25:27 --> Helper loaded: email_helper
INFO - 2018-02-14 15:25:27 --> Helper loaded: common_helper
INFO - 2018-02-14 15:25:27 --> Database Driver Class Initialized
DEBUG - 2018-02-14 15:25:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 15:25:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 15:25:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-14 15:25:27 --> Pagination Class Initialized
INFO - 2018-02-14 15:25:27 --> Helper loaded: form_helper
INFO - 2018-02-14 15:25:27 --> Form Validation Class Initialized
INFO - 2018-02-14 15:25:27 --> Model Class Initialized
INFO - 2018-02-14 15:25:27 --> Controller Class Initialized
INFO - 2018-02-14 15:25:27 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-14 15:25:27 --> Model Class Initialized
DEBUG - 2018-02-14 15:25:27 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-14 15:25:27 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-02-14 15:25:27 --> Config Class Initialized
INFO - 2018-02-14 15:25:27 --> Hooks Class Initialized
DEBUG - 2018-02-14 15:25:27 --> UTF-8 Support Enabled
INFO - 2018-02-14 15:25:27 --> Utf8 Class Initialized
INFO - 2018-02-14 15:25:27 --> URI Class Initialized
INFO - 2018-02-14 15:25:27 --> Router Class Initialized
INFO - 2018-02-14 15:25:27 --> Output Class Initialized
INFO - 2018-02-14 15:25:27 --> Security Class Initialized
DEBUG - 2018-02-14 15:25:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 15:25:27 --> Input Class Initialized
INFO - 2018-02-14 15:25:27 --> Language Class Initialized
INFO - 2018-02-14 15:25:27 --> Loader Class Initialized
INFO - 2018-02-14 15:25:27 --> Helper loaded: url_helper
INFO - 2018-02-14 15:25:27 --> Helper loaded: file_helper
INFO - 2018-02-14 15:25:27 --> Helper loaded: email_helper
INFO - 2018-02-14 15:25:27 --> Helper loaded: common_helper
INFO - 2018-02-14 15:25:27 --> Database Driver Class Initialized
DEBUG - 2018-02-14 15:25:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 15:25:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 15:25:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-14 15:25:27 --> Pagination Class Initialized
INFO - 2018-02-14 15:25:27 --> Helper loaded: form_helper
INFO - 2018-02-14 15:25:27 --> Form Validation Class Initialized
INFO - 2018-02-14 15:25:27 --> Model Class Initialized
INFO - 2018-02-14 15:25:27 --> Controller Class Initialized
INFO - 2018-02-14 15:25:27 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-14 15:25:27 --> Model Class Initialized
INFO - 2018-02-14 15:25:27 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-14 15:25:27 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-14 15:25:27 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-14 15:25:27 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-14 15:25:27 --> File loaded: /var/www/html/project/radio/application/views/category/index.php
INFO - 2018-02-14 15:25:27 --> Final output sent to browser
DEBUG - 2018-02-14 15:25:27 --> Total execution time: 0.0045
INFO - 2018-02-14 15:25:28 --> Config Class Initialized
INFO - 2018-02-14 15:25:28 --> Hooks Class Initialized
DEBUG - 2018-02-14 15:25:28 --> UTF-8 Support Enabled
INFO - 2018-02-14 15:25:28 --> Utf8 Class Initialized
INFO - 2018-02-14 15:25:28 --> URI Class Initialized
INFO - 2018-02-14 15:25:28 --> Router Class Initialized
INFO - 2018-02-14 15:25:28 --> Output Class Initialized
INFO - 2018-02-14 15:25:28 --> Security Class Initialized
DEBUG - 2018-02-14 15:25:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 15:25:28 --> Input Class Initialized
INFO - 2018-02-14 15:25:28 --> Language Class Initialized
INFO - 2018-02-14 15:25:28 --> Loader Class Initialized
INFO - 2018-02-14 15:25:28 --> Helper loaded: url_helper
INFO - 2018-02-14 15:25:28 --> Helper loaded: file_helper
INFO - 2018-02-14 15:25:28 --> Helper loaded: email_helper
INFO - 2018-02-14 15:25:28 --> Helper loaded: common_helper
INFO - 2018-02-14 15:25:28 --> Database Driver Class Initialized
DEBUG - 2018-02-14 15:25:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 15:25:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 15:25:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-14 15:25:28 --> Pagination Class Initialized
INFO - 2018-02-14 15:25:28 --> Helper loaded: form_helper
INFO - 2018-02-14 15:25:28 --> Form Validation Class Initialized
INFO - 2018-02-14 15:25:28 --> Model Class Initialized
INFO - 2018-02-14 15:25:28 --> Controller Class Initialized
INFO - 2018-02-14 15:25:28 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-14 15:25:28 --> Model Class Initialized
INFO - 2018-02-14 15:25:28 --> Config Class Initialized
INFO - 2018-02-14 15:25:28 --> Hooks Class Initialized
DEBUG - 2018-02-14 15:25:28 --> UTF-8 Support Enabled
INFO - 2018-02-14 15:25:28 --> Utf8 Class Initialized
INFO - 2018-02-14 15:25:28 --> URI Class Initialized
INFO - 2018-02-14 15:25:28 --> Router Class Initialized
INFO - 2018-02-14 15:25:28 --> Output Class Initialized
INFO - 2018-02-14 15:25:28 --> Security Class Initialized
DEBUG - 2018-02-14 15:25:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 15:25:28 --> Input Class Initialized
INFO - 2018-02-14 15:25:28 --> Language Class Initialized
INFO - 2018-02-14 15:25:28 --> Loader Class Initialized
INFO - 2018-02-14 15:25:28 --> Helper loaded: url_helper
INFO - 2018-02-14 15:25:28 --> Helper loaded: file_helper
INFO - 2018-02-14 15:25:28 --> Helper loaded: email_helper
INFO - 2018-02-14 15:25:28 --> Helper loaded: common_helper
INFO - 2018-02-14 15:25:28 --> Database Driver Class Initialized
DEBUG - 2018-02-14 15:25:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 15:25:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 15:25:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-14 15:25:28 --> Pagination Class Initialized
INFO - 2018-02-14 15:25:28 --> Helper loaded: form_helper
INFO - 2018-02-14 15:25:28 --> Form Validation Class Initialized
INFO - 2018-02-14 15:25:28 --> Model Class Initialized
INFO - 2018-02-14 15:25:28 --> Controller Class Initialized
INFO - 2018-02-14 15:25:28 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-14 15:25:28 --> Model Class Initialized
INFO - 2018-02-14 15:25:28 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-14 15:25:28 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-14 15:25:28 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-14 15:25:28 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-14 15:25:28 --> File loaded: /var/www/html/project/radio/application/views/category/index.php
INFO - 2018-02-14 15:25:28 --> Final output sent to browser
DEBUG - 2018-02-14 15:25:28 --> Total execution time: 0.0042
INFO - 2018-02-14 15:25:30 --> Config Class Initialized
INFO - 2018-02-14 15:25:30 --> Hooks Class Initialized
DEBUG - 2018-02-14 15:25:30 --> UTF-8 Support Enabled
INFO - 2018-02-14 15:25:30 --> Utf8 Class Initialized
INFO - 2018-02-14 15:25:30 --> URI Class Initialized
INFO - 2018-02-14 15:25:30 --> Router Class Initialized
INFO - 2018-02-14 15:25:30 --> Output Class Initialized
INFO - 2018-02-14 15:25:30 --> Security Class Initialized
DEBUG - 2018-02-14 15:25:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 15:25:30 --> Input Class Initialized
INFO - 2018-02-14 15:25:30 --> Language Class Initialized
INFO - 2018-02-14 15:25:30 --> Loader Class Initialized
INFO - 2018-02-14 15:25:30 --> Helper loaded: url_helper
INFO - 2018-02-14 15:25:30 --> Helper loaded: file_helper
INFO - 2018-02-14 15:25:30 --> Helper loaded: email_helper
INFO - 2018-02-14 15:25:30 --> Helper loaded: common_helper
INFO - 2018-02-14 15:25:30 --> Database Driver Class Initialized
DEBUG - 2018-02-14 15:25:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 15:25:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 15:25:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-14 15:25:30 --> Pagination Class Initialized
INFO - 2018-02-14 15:25:30 --> Helper loaded: form_helper
INFO - 2018-02-14 15:25:30 --> Form Validation Class Initialized
INFO - 2018-02-14 15:25:30 --> Model Class Initialized
INFO - 2018-02-14 15:25:30 --> Controller Class Initialized
INFO - 2018-02-14 15:25:30 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-14 15:25:30 --> Model Class Initialized
INFO - 2018-02-14 15:25:30 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-14 15:25:30 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-14 15:25:30 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-14 15:25:30 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-14 15:25:30 --> File loaded: /var/www/html/project/radio/application/views/category/index.php
INFO - 2018-02-14 15:25:30 --> Final output sent to browser
DEBUG - 2018-02-14 15:25:30 --> Total execution time: 0.0058
INFO - 2018-02-14 15:31:14 --> Config Class Initialized
INFO - 2018-02-14 15:31:14 --> Hooks Class Initialized
DEBUG - 2018-02-14 15:31:14 --> UTF-8 Support Enabled
INFO - 2018-02-14 15:31:14 --> Utf8 Class Initialized
INFO - 2018-02-14 15:31:14 --> URI Class Initialized
INFO - 2018-02-14 15:31:14 --> Router Class Initialized
INFO - 2018-02-14 15:31:14 --> Output Class Initialized
INFO - 2018-02-14 15:31:14 --> Security Class Initialized
DEBUG - 2018-02-14 15:31:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 15:31:14 --> Input Class Initialized
INFO - 2018-02-14 15:31:14 --> Language Class Initialized
INFO - 2018-02-14 15:31:14 --> Loader Class Initialized
INFO - 2018-02-14 15:31:14 --> Helper loaded: url_helper
INFO - 2018-02-14 15:31:14 --> Helper loaded: file_helper
INFO - 2018-02-14 15:31:14 --> Helper loaded: email_helper
INFO - 2018-02-14 15:31:14 --> Helper loaded: common_helper
INFO - 2018-02-14 15:31:14 --> Database Driver Class Initialized
DEBUG - 2018-02-14 15:31:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 15:31:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 15:31:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-14 15:31:14 --> Pagination Class Initialized
INFO - 2018-02-14 15:31:14 --> Helper loaded: form_helper
INFO - 2018-02-14 15:31:14 --> Form Validation Class Initialized
INFO - 2018-02-14 15:31:14 --> Model Class Initialized
INFO - 2018-02-14 15:31:14 --> Controller Class Initialized
INFO - 2018-02-14 15:31:14 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-14 15:31:14 --> Model Class Initialized
INFO - 2018-02-14 15:31:14 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-14 15:31:14 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-14 15:31:14 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-14 15:31:14 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-14 15:31:14 --> File loaded: /var/www/html/project/radio/application/views/category/add_edit.php
INFO - 2018-02-14 15:31:14 --> Final output sent to browser
DEBUG - 2018-02-14 15:31:14 --> Total execution time: 0.0052
INFO - 2018-02-14 15:31:18 --> Config Class Initialized
INFO - 2018-02-14 15:31:18 --> Hooks Class Initialized
DEBUG - 2018-02-14 15:31:18 --> UTF-8 Support Enabled
INFO - 2018-02-14 15:31:18 --> Utf8 Class Initialized
INFO - 2018-02-14 15:31:18 --> URI Class Initialized
INFO - 2018-02-14 15:31:18 --> Router Class Initialized
INFO - 2018-02-14 15:31:18 --> Output Class Initialized
INFO - 2018-02-14 15:31:18 --> Security Class Initialized
DEBUG - 2018-02-14 15:31:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 15:31:18 --> Input Class Initialized
INFO - 2018-02-14 15:31:18 --> Language Class Initialized
INFO - 2018-02-14 15:31:18 --> Loader Class Initialized
INFO - 2018-02-14 15:31:18 --> Helper loaded: url_helper
INFO - 2018-02-14 15:31:18 --> Helper loaded: file_helper
INFO - 2018-02-14 15:31:18 --> Helper loaded: email_helper
INFO - 2018-02-14 15:31:18 --> Helper loaded: common_helper
INFO - 2018-02-14 15:31:18 --> Database Driver Class Initialized
DEBUG - 2018-02-14 15:31:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 15:31:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 15:31:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-14 15:31:18 --> Pagination Class Initialized
INFO - 2018-02-14 15:31:18 --> Helper loaded: form_helper
INFO - 2018-02-14 15:31:18 --> Form Validation Class Initialized
INFO - 2018-02-14 15:31:18 --> Model Class Initialized
INFO - 2018-02-14 15:31:18 --> Controller Class Initialized
INFO - 2018-02-14 15:31:18 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-14 15:31:18 --> Model Class Initialized
INFO - 2018-02-14 15:31:18 --> Config Class Initialized
INFO - 2018-02-14 15:31:18 --> Hooks Class Initialized
DEBUG - 2018-02-14 15:31:18 --> UTF-8 Support Enabled
INFO - 2018-02-14 15:31:18 --> Utf8 Class Initialized
INFO - 2018-02-14 15:31:18 --> URI Class Initialized
INFO - 2018-02-14 15:31:18 --> Router Class Initialized
INFO - 2018-02-14 15:31:18 --> Output Class Initialized
INFO - 2018-02-14 15:31:18 --> Security Class Initialized
DEBUG - 2018-02-14 15:31:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 15:31:18 --> Input Class Initialized
INFO - 2018-02-14 15:31:18 --> Language Class Initialized
INFO - 2018-02-14 15:31:18 --> Loader Class Initialized
INFO - 2018-02-14 15:31:18 --> Helper loaded: url_helper
INFO - 2018-02-14 15:31:18 --> Helper loaded: file_helper
INFO - 2018-02-14 15:31:18 --> Helper loaded: email_helper
INFO - 2018-02-14 15:31:18 --> Helper loaded: common_helper
INFO - 2018-02-14 15:31:18 --> Database Driver Class Initialized
DEBUG - 2018-02-14 15:31:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 15:31:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 15:31:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-14 15:31:18 --> Pagination Class Initialized
INFO - 2018-02-14 15:31:18 --> Helper loaded: form_helper
INFO - 2018-02-14 15:31:18 --> Form Validation Class Initialized
INFO - 2018-02-14 15:31:18 --> Model Class Initialized
INFO - 2018-02-14 15:31:18 --> Controller Class Initialized
INFO - 2018-02-14 15:31:18 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-14 15:31:18 --> Model Class Initialized
DEBUG - 2018-02-14 15:31:18 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-14 15:31:18 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-02-14 15:31:18 --> Config Class Initialized
INFO - 2018-02-14 15:31:18 --> Hooks Class Initialized
DEBUG - 2018-02-14 15:31:18 --> UTF-8 Support Enabled
INFO - 2018-02-14 15:31:18 --> Utf8 Class Initialized
INFO - 2018-02-14 15:31:18 --> URI Class Initialized
INFO - 2018-02-14 15:31:18 --> Router Class Initialized
INFO - 2018-02-14 15:31:18 --> Output Class Initialized
INFO - 2018-02-14 15:31:18 --> Security Class Initialized
DEBUG - 2018-02-14 15:31:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 15:31:18 --> Input Class Initialized
INFO - 2018-02-14 15:31:18 --> Language Class Initialized
INFO - 2018-02-14 15:31:18 --> Loader Class Initialized
INFO - 2018-02-14 15:31:18 --> Helper loaded: url_helper
INFO - 2018-02-14 15:31:18 --> Helper loaded: file_helper
INFO - 2018-02-14 15:31:18 --> Helper loaded: email_helper
INFO - 2018-02-14 15:31:18 --> Helper loaded: common_helper
INFO - 2018-02-14 15:31:18 --> Database Driver Class Initialized
DEBUG - 2018-02-14 15:31:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 15:31:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 15:31:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-14 15:31:18 --> Pagination Class Initialized
INFO - 2018-02-14 15:31:18 --> Helper loaded: form_helper
INFO - 2018-02-14 15:31:18 --> Form Validation Class Initialized
INFO - 2018-02-14 15:31:18 --> Model Class Initialized
INFO - 2018-02-14 15:31:18 --> Controller Class Initialized
INFO - 2018-02-14 15:31:18 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-14 15:31:18 --> Model Class Initialized
INFO - 2018-02-14 15:31:18 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-14 15:31:18 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-14 15:31:18 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-14 15:31:18 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-14 15:31:18 --> File loaded: /var/www/html/project/radio/application/views/category/index.php
INFO - 2018-02-14 15:31:18 --> Final output sent to browser
DEBUG - 2018-02-14 15:31:18 --> Total execution time: 0.0081
INFO - 2018-02-14 15:33:13 --> Config Class Initialized
INFO - 2018-02-14 15:33:13 --> Hooks Class Initialized
DEBUG - 2018-02-14 15:33:13 --> UTF-8 Support Enabled
INFO - 2018-02-14 15:33:13 --> Utf8 Class Initialized
INFO - 2018-02-14 15:33:13 --> URI Class Initialized
INFO - 2018-02-14 15:33:13 --> Router Class Initialized
INFO - 2018-02-14 15:33:13 --> Output Class Initialized
INFO - 2018-02-14 15:33:13 --> Security Class Initialized
DEBUG - 2018-02-14 15:33:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 15:33:13 --> Input Class Initialized
INFO - 2018-02-14 15:33:13 --> Language Class Initialized
INFO - 2018-02-14 15:33:13 --> Loader Class Initialized
INFO - 2018-02-14 15:33:13 --> Helper loaded: url_helper
INFO - 2018-02-14 15:33:13 --> Helper loaded: file_helper
INFO - 2018-02-14 15:33:13 --> Helper loaded: email_helper
INFO - 2018-02-14 15:33:13 --> Helper loaded: common_helper
INFO - 2018-02-14 15:33:13 --> Database Driver Class Initialized
DEBUG - 2018-02-14 15:33:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 15:33:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 15:33:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-14 15:33:13 --> Pagination Class Initialized
INFO - 2018-02-14 15:33:13 --> Helper loaded: form_helper
INFO - 2018-02-14 15:33:13 --> Form Validation Class Initialized
INFO - 2018-02-14 15:33:13 --> Model Class Initialized
INFO - 2018-02-14 15:33:13 --> Controller Class Initialized
INFO - 2018-02-14 15:33:13 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-14 15:33:13 --> Model Class Initialized
INFO - 2018-02-14 15:33:13 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-14 15:33:13 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-14 15:33:13 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-14 15:33:13 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-14 15:33:13 --> File loaded: /var/www/html/project/radio/application/views/category/index.php
INFO - 2018-02-14 15:33:13 --> Final output sent to browser
DEBUG - 2018-02-14 15:33:13 --> Total execution time: 0.0084
INFO - 2018-02-14 15:33:14 --> Config Class Initialized
INFO - 2018-02-14 15:33:14 --> Hooks Class Initialized
DEBUG - 2018-02-14 15:33:14 --> UTF-8 Support Enabled
INFO - 2018-02-14 15:33:14 --> Utf8 Class Initialized
INFO - 2018-02-14 15:33:14 --> URI Class Initialized
INFO - 2018-02-14 15:33:14 --> Router Class Initialized
INFO - 2018-02-14 15:33:14 --> Output Class Initialized
INFO - 2018-02-14 15:33:14 --> Security Class Initialized
DEBUG - 2018-02-14 15:33:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 15:33:14 --> Input Class Initialized
INFO - 2018-02-14 15:33:14 --> Language Class Initialized
INFO - 2018-02-14 15:33:14 --> Loader Class Initialized
INFO - 2018-02-14 15:33:14 --> Helper loaded: url_helper
INFO - 2018-02-14 15:33:14 --> Helper loaded: file_helper
INFO - 2018-02-14 15:33:14 --> Helper loaded: email_helper
INFO - 2018-02-14 15:33:14 --> Helper loaded: common_helper
INFO - 2018-02-14 15:33:14 --> Database Driver Class Initialized
DEBUG - 2018-02-14 15:33:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 15:33:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 15:33:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-14 15:33:14 --> Pagination Class Initialized
INFO - 2018-02-14 15:33:14 --> Helper loaded: form_helper
INFO - 2018-02-14 15:33:14 --> Form Validation Class Initialized
INFO - 2018-02-14 15:33:14 --> Model Class Initialized
INFO - 2018-02-14 15:33:14 --> Controller Class Initialized
INFO - 2018-02-14 15:33:14 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-14 15:33:14 --> Model Class Initialized
ERROR - 2018-02-14 15:33:14 --> Severity: Notice --> Undefined property: Category::$User_model /var/www/html/project/radio/application/controllers/Category.php 278
ERROR - 2018-02-14 15:33:14 --> Severity: error --> Exception: Call to a member function updateData() on null /var/www/html/project/radio/application/controllers/Category.php 278
INFO - 2018-02-14 15:33:18 --> Config Class Initialized
INFO - 2018-02-14 15:33:18 --> Hooks Class Initialized
DEBUG - 2018-02-14 15:33:18 --> UTF-8 Support Enabled
INFO - 2018-02-14 15:33:18 --> Utf8 Class Initialized
INFO - 2018-02-14 15:33:18 --> URI Class Initialized
INFO - 2018-02-14 15:33:18 --> Router Class Initialized
INFO - 2018-02-14 15:33:18 --> Output Class Initialized
INFO - 2018-02-14 15:33:18 --> Security Class Initialized
DEBUG - 2018-02-14 15:33:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 15:33:18 --> Input Class Initialized
INFO - 2018-02-14 15:33:18 --> Language Class Initialized
INFO - 2018-02-14 15:33:18 --> Loader Class Initialized
INFO - 2018-02-14 15:33:18 --> Helper loaded: url_helper
INFO - 2018-02-14 15:33:18 --> Helper loaded: file_helper
INFO - 2018-02-14 15:33:18 --> Helper loaded: email_helper
INFO - 2018-02-14 15:33:18 --> Helper loaded: common_helper
INFO - 2018-02-14 15:33:18 --> Database Driver Class Initialized
DEBUG - 2018-02-14 15:33:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 15:33:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 15:33:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-14 15:33:18 --> Pagination Class Initialized
INFO - 2018-02-14 15:33:18 --> Helper loaded: form_helper
INFO - 2018-02-14 15:33:18 --> Form Validation Class Initialized
INFO - 2018-02-14 15:33:18 --> Model Class Initialized
INFO - 2018-02-14 15:33:18 --> Controller Class Initialized
INFO - 2018-02-14 15:33:18 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-14 15:33:18 --> Model Class Initialized
INFO - 2018-02-14 15:33:18 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-14 15:33:18 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-14 15:33:18 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-14 15:33:18 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-14 15:33:18 --> File loaded: /var/www/html/project/radio/application/views/category/index.php
INFO - 2018-02-14 15:33:18 --> Final output sent to browser
DEBUG - 2018-02-14 15:33:18 --> Total execution time: 0.0078
INFO - 2018-02-14 15:33:22 --> Config Class Initialized
INFO - 2018-02-14 15:33:22 --> Hooks Class Initialized
DEBUG - 2018-02-14 15:33:22 --> UTF-8 Support Enabled
INFO - 2018-02-14 15:33:22 --> Utf8 Class Initialized
INFO - 2018-02-14 15:33:22 --> URI Class Initialized
INFO - 2018-02-14 15:33:22 --> Router Class Initialized
INFO - 2018-02-14 15:33:22 --> Output Class Initialized
INFO - 2018-02-14 15:33:22 --> Security Class Initialized
DEBUG - 2018-02-14 15:33:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 15:33:22 --> Input Class Initialized
INFO - 2018-02-14 15:33:22 --> Language Class Initialized
INFO - 2018-02-14 15:33:22 --> Loader Class Initialized
INFO - 2018-02-14 15:33:22 --> Helper loaded: url_helper
INFO - 2018-02-14 15:33:22 --> Helper loaded: file_helper
INFO - 2018-02-14 15:33:22 --> Helper loaded: email_helper
INFO - 2018-02-14 15:33:22 --> Helper loaded: common_helper
INFO - 2018-02-14 15:33:22 --> Database Driver Class Initialized
DEBUG - 2018-02-14 15:33:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 15:33:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 15:33:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-14 15:33:22 --> Pagination Class Initialized
INFO - 2018-02-14 15:33:22 --> Helper loaded: form_helper
INFO - 2018-02-14 15:33:22 --> Form Validation Class Initialized
INFO - 2018-02-14 15:33:22 --> Model Class Initialized
INFO - 2018-02-14 15:33:22 --> Controller Class Initialized
INFO - 2018-02-14 15:33:22 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-14 15:33:22 --> Model Class Initialized
ERROR - 2018-02-14 15:33:22 --> Severity: Notice --> Undefined property: Category::$User_model /var/www/html/project/radio/application/controllers/Category.php 278
ERROR - 2018-02-14 15:33:22 --> Severity: error --> Exception: Call to a member function updateData() on null /var/www/html/project/radio/application/controllers/Category.php 278
INFO - 2018-02-14 15:33:34 --> Config Class Initialized
INFO - 2018-02-14 15:33:34 --> Hooks Class Initialized
DEBUG - 2018-02-14 15:33:34 --> UTF-8 Support Enabled
INFO - 2018-02-14 15:33:34 --> Utf8 Class Initialized
INFO - 2018-02-14 15:33:34 --> URI Class Initialized
INFO - 2018-02-14 15:33:34 --> Router Class Initialized
INFO - 2018-02-14 15:33:34 --> Output Class Initialized
INFO - 2018-02-14 15:33:34 --> Security Class Initialized
DEBUG - 2018-02-14 15:33:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 15:33:34 --> Input Class Initialized
INFO - 2018-02-14 15:33:34 --> Language Class Initialized
INFO - 2018-02-14 15:33:34 --> Loader Class Initialized
INFO - 2018-02-14 15:33:34 --> Helper loaded: url_helper
INFO - 2018-02-14 15:33:34 --> Helper loaded: file_helper
INFO - 2018-02-14 15:33:34 --> Helper loaded: email_helper
INFO - 2018-02-14 15:33:34 --> Helper loaded: common_helper
INFO - 2018-02-14 15:33:34 --> Database Driver Class Initialized
DEBUG - 2018-02-14 15:33:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 15:33:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 15:33:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-14 15:33:34 --> Pagination Class Initialized
INFO - 2018-02-14 15:33:34 --> Helper loaded: form_helper
INFO - 2018-02-14 15:33:34 --> Form Validation Class Initialized
INFO - 2018-02-14 15:33:34 --> Model Class Initialized
INFO - 2018-02-14 15:33:34 --> Controller Class Initialized
INFO - 2018-02-14 15:33:34 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-14 15:33:34 --> Model Class Initialized
INFO - 2018-02-14 15:33:34 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-14 15:33:34 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-14 15:33:34 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-14 15:33:34 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-14 15:33:34 --> File loaded: /var/www/html/project/radio/application/views/category/index.php
INFO - 2018-02-14 15:33:34 --> Final output sent to browser
DEBUG - 2018-02-14 15:33:34 --> Total execution time: 0.0069
INFO - 2018-02-14 15:33:38 --> Config Class Initialized
INFO - 2018-02-14 15:33:38 --> Hooks Class Initialized
DEBUG - 2018-02-14 15:33:38 --> UTF-8 Support Enabled
INFO - 2018-02-14 15:33:38 --> Utf8 Class Initialized
INFO - 2018-02-14 15:33:38 --> URI Class Initialized
INFO - 2018-02-14 15:33:38 --> Router Class Initialized
INFO - 2018-02-14 15:33:38 --> Output Class Initialized
INFO - 2018-02-14 15:33:38 --> Security Class Initialized
DEBUG - 2018-02-14 15:33:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 15:33:38 --> Input Class Initialized
INFO - 2018-02-14 15:33:38 --> Language Class Initialized
INFO - 2018-02-14 15:33:38 --> Loader Class Initialized
INFO - 2018-02-14 15:33:38 --> Helper loaded: url_helper
INFO - 2018-02-14 15:33:38 --> Helper loaded: file_helper
INFO - 2018-02-14 15:33:38 --> Helper loaded: email_helper
INFO - 2018-02-14 15:33:38 --> Helper loaded: common_helper
INFO - 2018-02-14 15:33:38 --> Database Driver Class Initialized
DEBUG - 2018-02-14 15:33:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 15:33:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 15:33:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-14 15:33:38 --> Pagination Class Initialized
INFO - 2018-02-14 15:33:38 --> Helper loaded: form_helper
INFO - 2018-02-14 15:33:38 --> Form Validation Class Initialized
INFO - 2018-02-14 15:33:38 --> Model Class Initialized
INFO - 2018-02-14 15:33:38 --> Controller Class Initialized
INFO - 2018-02-14 15:33:38 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-14 15:33:38 --> Model Class Initialized
INFO - 2018-02-14 15:33:39 --> Config Class Initialized
INFO - 2018-02-14 15:33:39 --> Hooks Class Initialized
DEBUG - 2018-02-14 15:33:39 --> UTF-8 Support Enabled
INFO - 2018-02-14 15:33:39 --> Utf8 Class Initialized
INFO - 2018-02-14 15:33:39 --> URI Class Initialized
INFO - 2018-02-14 15:33:39 --> Router Class Initialized
INFO - 2018-02-14 15:33:39 --> Output Class Initialized
INFO - 2018-02-14 15:33:39 --> Security Class Initialized
DEBUG - 2018-02-14 15:33:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 15:33:39 --> Input Class Initialized
INFO - 2018-02-14 15:33:39 --> Language Class Initialized
INFO - 2018-02-14 15:33:39 --> Loader Class Initialized
INFO - 2018-02-14 15:33:39 --> Helper loaded: url_helper
INFO - 2018-02-14 15:33:39 --> Helper loaded: file_helper
INFO - 2018-02-14 15:33:39 --> Helper loaded: email_helper
INFO - 2018-02-14 15:33:39 --> Helper loaded: common_helper
INFO - 2018-02-14 15:33:39 --> Database Driver Class Initialized
DEBUG - 2018-02-14 15:33:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 15:33:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 15:33:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-14 15:33:39 --> Pagination Class Initialized
INFO - 2018-02-14 15:33:39 --> Helper loaded: form_helper
INFO - 2018-02-14 15:33:39 --> Form Validation Class Initialized
INFO - 2018-02-14 15:33:39 --> Model Class Initialized
INFO - 2018-02-14 15:33:39 --> Controller Class Initialized
INFO - 2018-02-14 15:33:39 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-14 15:33:39 --> Model Class Initialized
INFO - 2018-02-14 15:33:39 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-14 15:33:39 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-14 15:33:39 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-14 15:33:39 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-14 15:33:39 --> File loaded: /var/www/html/project/radio/application/views/category/index.php
INFO - 2018-02-14 15:33:39 --> Final output sent to browser
DEBUG - 2018-02-14 15:33:39 --> Total execution time: 0.0054
INFO - 2018-02-14 15:33:43 --> Config Class Initialized
INFO - 2018-02-14 15:33:43 --> Hooks Class Initialized
DEBUG - 2018-02-14 15:33:43 --> UTF-8 Support Enabled
INFO - 2018-02-14 15:33:43 --> Utf8 Class Initialized
INFO - 2018-02-14 15:33:43 --> URI Class Initialized
INFO - 2018-02-14 15:33:43 --> Router Class Initialized
INFO - 2018-02-14 15:33:43 --> Output Class Initialized
INFO - 2018-02-14 15:33:43 --> Security Class Initialized
DEBUG - 2018-02-14 15:33:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 15:33:43 --> Input Class Initialized
INFO - 2018-02-14 15:33:43 --> Language Class Initialized
INFO - 2018-02-14 15:33:43 --> Loader Class Initialized
INFO - 2018-02-14 15:33:43 --> Helper loaded: url_helper
INFO - 2018-02-14 15:33:43 --> Helper loaded: file_helper
INFO - 2018-02-14 15:33:43 --> Helper loaded: email_helper
INFO - 2018-02-14 15:33:43 --> Helper loaded: common_helper
INFO - 2018-02-14 15:33:43 --> Database Driver Class Initialized
DEBUG - 2018-02-14 15:33:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 15:33:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 15:33:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-14 15:33:43 --> Pagination Class Initialized
INFO - 2018-02-14 15:33:43 --> Helper loaded: form_helper
INFO - 2018-02-14 15:33:43 --> Form Validation Class Initialized
INFO - 2018-02-14 15:33:43 --> Model Class Initialized
INFO - 2018-02-14 15:33:43 --> Controller Class Initialized
INFO - 2018-02-14 15:33:43 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-14 15:33:43 --> Model Class Initialized
INFO - 2018-02-14 15:33:51 --> Config Class Initialized
INFO - 2018-02-14 15:33:51 --> Hooks Class Initialized
DEBUG - 2018-02-14 15:33:51 --> UTF-8 Support Enabled
INFO - 2018-02-14 15:33:51 --> Utf8 Class Initialized
INFO - 2018-02-14 15:33:51 --> URI Class Initialized
INFO - 2018-02-14 15:33:51 --> Router Class Initialized
INFO - 2018-02-14 15:33:51 --> Output Class Initialized
INFO - 2018-02-14 15:33:51 --> Security Class Initialized
DEBUG - 2018-02-14 15:33:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 15:33:51 --> Input Class Initialized
INFO - 2018-02-14 15:33:51 --> Language Class Initialized
INFO - 2018-02-14 15:33:51 --> Loader Class Initialized
INFO - 2018-02-14 15:33:51 --> Helper loaded: url_helper
INFO - 2018-02-14 15:33:51 --> Helper loaded: file_helper
INFO - 2018-02-14 15:33:51 --> Helper loaded: email_helper
INFO - 2018-02-14 15:33:51 --> Helper loaded: common_helper
INFO - 2018-02-14 15:33:51 --> Database Driver Class Initialized
DEBUG - 2018-02-14 15:33:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 15:33:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 15:33:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-14 15:33:51 --> Pagination Class Initialized
INFO - 2018-02-14 15:33:51 --> Helper loaded: form_helper
INFO - 2018-02-14 15:33:51 --> Form Validation Class Initialized
INFO - 2018-02-14 15:33:51 --> Model Class Initialized
INFO - 2018-02-14 15:33:51 --> Controller Class Initialized
INFO - 2018-02-14 15:33:51 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-14 15:33:51 --> Model Class Initialized
INFO - 2018-02-14 15:33:51 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-14 15:33:51 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-14 15:33:51 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-14 15:33:51 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-14 15:33:51 --> File loaded: /var/www/html/project/radio/application/views/category/index.php
INFO - 2018-02-14 15:33:51 --> Final output sent to browser
DEBUG - 2018-02-14 15:33:51 --> Total execution time: 0.0111
INFO - 2018-02-14 15:33:53 --> Config Class Initialized
INFO - 2018-02-14 15:33:53 --> Hooks Class Initialized
DEBUG - 2018-02-14 15:33:53 --> UTF-8 Support Enabled
INFO - 2018-02-14 15:33:53 --> Utf8 Class Initialized
INFO - 2018-02-14 15:33:53 --> URI Class Initialized
INFO - 2018-02-14 15:33:53 --> Router Class Initialized
INFO - 2018-02-14 15:33:53 --> Output Class Initialized
INFO - 2018-02-14 15:33:53 --> Security Class Initialized
DEBUG - 2018-02-14 15:33:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 15:33:53 --> Input Class Initialized
INFO - 2018-02-14 15:33:53 --> Language Class Initialized
INFO - 2018-02-14 15:33:53 --> Loader Class Initialized
INFO - 2018-02-14 15:33:53 --> Helper loaded: url_helper
INFO - 2018-02-14 15:33:53 --> Helper loaded: file_helper
INFO - 2018-02-14 15:33:53 --> Helper loaded: email_helper
INFO - 2018-02-14 15:33:53 --> Helper loaded: common_helper
INFO - 2018-02-14 15:33:53 --> Database Driver Class Initialized
DEBUG - 2018-02-14 15:33:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 15:33:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 15:33:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-14 15:33:53 --> Pagination Class Initialized
INFO - 2018-02-14 15:33:53 --> Helper loaded: form_helper
INFO - 2018-02-14 15:33:53 --> Form Validation Class Initialized
INFO - 2018-02-14 15:33:53 --> Model Class Initialized
INFO - 2018-02-14 15:33:53 --> Controller Class Initialized
INFO - 2018-02-14 15:33:53 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-14 15:33:53 --> Model Class Initialized
INFO - 2018-02-14 15:34:28 --> Config Class Initialized
INFO - 2018-02-14 15:34:28 --> Hooks Class Initialized
DEBUG - 2018-02-14 15:34:28 --> UTF-8 Support Enabled
INFO - 2018-02-14 15:34:28 --> Utf8 Class Initialized
INFO - 2018-02-14 15:34:28 --> URI Class Initialized
INFO - 2018-02-14 15:34:28 --> Router Class Initialized
INFO - 2018-02-14 15:34:28 --> Output Class Initialized
INFO - 2018-02-14 15:34:28 --> Security Class Initialized
DEBUG - 2018-02-14 15:34:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 15:34:28 --> Input Class Initialized
INFO - 2018-02-14 15:34:28 --> Language Class Initialized
INFO - 2018-02-14 15:34:28 --> Loader Class Initialized
INFO - 2018-02-14 15:34:28 --> Helper loaded: url_helper
INFO - 2018-02-14 15:34:28 --> Helper loaded: file_helper
INFO - 2018-02-14 15:34:28 --> Helper loaded: email_helper
INFO - 2018-02-14 15:34:28 --> Helper loaded: common_helper
INFO - 2018-02-14 15:34:28 --> Database Driver Class Initialized
DEBUG - 2018-02-14 15:34:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 15:34:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 15:34:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-14 15:34:28 --> Pagination Class Initialized
INFO - 2018-02-14 15:34:28 --> Helper loaded: form_helper
INFO - 2018-02-14 15:34:28 --> Form Validation Class Initialized
INFO - 2018-02-14 15:34:28 --> Model Class Initialized
INFO - 2018-02-14 15:34:28 --> Controller Class Initialized
INFO - 2018-02-14 15:34:28 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-14 15:34:28 --> Model Class Initialized
INFO - 2018-02-14 15:34:28 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-14 15:34:28 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-14 15:34:28 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-14 15:34:28 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-14 15:34:28 --> File loaded: /var/www/html/project/radio/application/views/category/index.php
INFO - 2018-02-14 15:34:28 --> Final output sent to browser
DEBUG - 2018-02-14 15:34:28 --> Total execution time: 0.0061
INFO - 2018-02-14 15:34:29 --> Config Class Initialized
INFO - 2018-02-14 15:34:29 --> Hooks Class Initialized
DEBUG - 2018-02-14 15:34:29 --> UTF-8 Support Enabled
INFO - 2018-02-14 15:34:29 --> Utf8 Class Initialized
INFO - 2018-02-14 15:34:29 --> URI Class Initialized
INFO - 2018-02-14 15:34:29 --> Router Class Initialized
INFO - 2018-02-14 15:34:29 --> Output Class Initialized
INFO - 2018-02-14 15:34:29 --> Security Class Initialized
DEBUG - 2018-02-14 15:34:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 15:34:29 --> Input Class Initialized
INFO - 2018-02-14 15:34:29 --> Language Class Initialized
INFO - 2018-02-14 15:34:29 --> Loader Class Initialized
INFO - 2018-02-14 15:34:29 --> Helper loaded: url_helper
INFO - 2018-02-14 15:34:29 --> Helper loaded: file_helper
INFO - 2018-02-14 15:34:29 --> Helper loaded: email_helper
INFO - 2018-02-14 15:34:29 --> Helper loaded: common_helper
INFO - 2018-02-14 15:34:29 --> Database Driver Class Initialized
DEBUG - 2018-02-14 15:34:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 15:34:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 15:34:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-14 15:34:29 --> Pagination Class Initialized
INFO - 2018-02-14 15:34:29 --> Helper loaded: form_helper
INFO - 2018-02-14 15:34:29 --> Form Validation Class Initialized
INFO - 2018-02-14 15:34:29 --> Model Class Initialized
INFO - 2018-02-14 15:34:29 --> Controller Class Initialized
INFO - 2018-02-14 15:34:29 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-14 15:34:29 --> Model Class Initialized
INFO - 2018-02-14 15:34:29 --> Config Class Initialized
INFO - 2018-02-14 15:34:29 --> Hooks Class Initialized
DEBUG - 2018-02-14 15:34:29 --> UTF-8 Support Enabled
INFO - 2018-02-14 15:34:29 --> Utf8 Class Initialized
INFO - 2018-02-14 15:34:29 --> URI Class Initialized
INFO - 2018-02-14 15:34:29 --> Router Class Initialized
INFO - 2018-02-14 15:34:29 --> Output Class Initialized
INFO - 2018-02-14 15:34:29 --> Security Class Initialized
DEBUG - 2018-02-14 15:34:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 15:34:29 --> Input Class Initialized
INFO - 2018-02-14 15:34:29 --> Language Class Initialized
INFO - 2018-02-14 15:34:29 --> Loader Class Initialized
INFO - 2018-02-14 15:34:29 --> Helper loaded: url_helper
INFO - 2018-02-14 15:34:29 --> Helper loaded: file_helper
INFO - 2018-02-14 15:34:29 --> Helper loaded: email_helper
INFO - 2018-02-14 15:34:29 --> Helper loaded: common_helper
INFO - 2018-02-14 15:34:29 --> Database Driver Class Initialized
DEBUG - 2018-02-14 15:34:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 15:34:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 15:34:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-14 15:34:29 --> Pagination Class Initialized
INFO - 2018-02-14 15:34:29 --> Helper loaded: form_helper
INFO - 2018-02-14 15:34:29 --> Form Validation Class Initialized
INFO - 2018-02-14 15:34:29 --> Model Class Initialized
INFO - 2018-02-14 15:34:29 --> Controller Class Initialized
INFO - 2018-02-14 15:34:29 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-14 15:34:29 --> Model Class Initialized
INFO - 2018-02-14 15:34:29 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-14 15:34:29 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-14 15:34:29 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-14 15:34:29 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-14 15:34:29 --> File loaded: /var/www/html/project/radio/application/views/category/index.php
INFO - 2018-02-14 15:34:29 --> Final output sent to browser
DEBUG - 2018-02-14 15:34:29 --> Total execution time: 0.0043
INFO - 2018-02-14 15:34:31 --> Config Class Initialized
INFO - 2018-02-14 15:34:31 --> Hooks Class Initialized
DEBUG - 2018-02-14 15:34:31 --> UTF-8 Support Enabled
INFO - 2018-02-14 15:34:31 --> Utf8 Class Initialized
INFO - 2018-02-14 15:34:31 --> URI Class Initialized
INFO - 2018-02-14 15:34:31 --> Router Class Initialized
INFO - 2018-02-14 15:34:31 --> Output Class Initialized
INFO - 2018-02-14 15:34:31 --> Security Class Initialized
DEBUG - 2018-02-14 15:34:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 15:34:31 --> Input Class Initialized
INFO - 2018-02-14 15:34:31 --> Language Class Initialized
INFO - 2018-02-14 15:34:31 --> Loader Class Initialized
INFO - 2018-02-14 15:34:31 --> Helper loaded: url_helper
INFO - 2018-02-14 15:34:31 --> Helper loaded: file_helper
INFO - 2018-02-14 15:34:31 --> Helper loaded: email_helper
INFO - 2018-02-14 15:34:31 --> Helper loaded: common_helper
INFO - 2018-02-14 15:34:31 --> Database Driver Class Initialized
DEBUG - 2018-02-14 15:34:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 15:34:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 15:34:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-14 15:34:31 --> Pagination Class Initialized
INFO - 2018-02-14 15:34:31 --> Helper loaded: form_helper
INFO - 2018-02-14 15:34:31 --> Form Validation Class Initialized
INFO - 2018-02-14 15:34:31 --> Model Class Initialized
INFO - 2018-02-14 15:34:31 --> Controller Class Initialized
INFO - 2018-02-14 15:34:31 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-14 15:34:31 --> Model Class Initialized
INFO - 2018-02-14 15:34:31 --> Config Class Initialized
INFO - 2018-02-14 15:34:31 --> Hooks Class Initialized
DEBUG - 2018-02-14 15:34:31 --> UTF-8 Support Enabled
INFO - 2018-02-14 15:34:31 --> Utf8 Class Initialized
INFO - 2018-02-14 15:34:31 --> URI Class Initialized
INFO - 2018-02-14 15:34:31 --> Router Class Initialized
INFO - 2018-02-14 15:34:31 --> Output Class Initialized
INFO - 2018-02-14 15:34:31 --> Security Class Initialized
DEBUG - 2018-02-14 15:34:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 15:34:31 --> Input Class Initialized
INFO - 2018-02-14 15:34:31 --> Language Class Initialized
INFO - 2018-02-14 15:34:31 --> Loader Class Initialized
INFO - 2018-02-14 15:34:31 --> Helper loaded: url_helper
INFO - 2018-02-14 15:34:31 --> Helper loaded: file_helper
INFO - 2018-02-14 15:34:31 --> Helper loaded: email_helper
INFO - 2018-02-14 15:34:31 --> Helper loaded: common_helper
INFO - 2018-02-14 15:34:31 --> Database Driver Class Initialized
DEBUG - 2018-02-14 15:34:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 15:34:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 15:34:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-14 15:34:31 --> Pagination Class Initialized
INFO - 2018-02-14 15:34:31 --> Helper loaded: form_helper
INFO - 2018-02-14 15:34:31 --> Form Validation Class Initialized
INFO - 2018-02-14 15:34:31 --> Model Class Initialized
INFO - 2018-02-14 15:34:31 --> Controller Class Initialized
INFO - 2018-02-14 15:34:31 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-14 15:34:31 --> Model Class Initialized
INFO - 2018-02-14 15:34:31 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-14 15:34:31 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-14 15:34:31 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-14 15:34:31 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-14 15:34:31 --> File loaded: /var/www/html/project/radio/application/views/category/index.php
INFO - 2018-02-14 15:34:31 --> Final output sent to browser
DEBUG - 2018-02-14 15:34:31 --> Total execution time: 0.0067
INFO - 2018-02-14 15:35:32 --> Config Class Initialized
INFO - 2018-02-14 15:35:32 --> Hooks Class Initialized
DEBUG - 2018-02-14 15:35:32 --> UTF-8 Support Enabled
INFO - 2018-02-14 15:35:32 --> Utf8 Class Initialized
INFO - 2018-02-14 15:35:32 --> URI Class Initialized
INFO - 2018-02-14 15:35:32 --> Router Class Initialized
INFO - 2018-02-14 15:35:32 --> Output Class Initialized
INFO - 2018-02-14 15:35:32 --> Security Class Initialized
DEBUG - 2018-02-14 15:35:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 15:35:32 --> Input Class Initialized
INFO - 2018-02-14 15:35:32 --> Language Class Initialized
INFO - 2018-02-14 15:35:32 --> Loader Class Initialized
INFO - 2018-02-14 15:35:32 --> Helper loaded: url_helper
INFO - 2018-02-14 15:35:32 --> Helper loaded: file_helper
INFO - 2018-02-14 15:35:32 --> Helper loaded: email_helper
INFO - 2018-02-14 15:35:32 --> Helper loaded: common_helper
INFO - 2018-02-14 15:35:32 --> Database Driver Class Initialized
DEBUG - 2018-02-14 15:35:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 15:35:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 15:35:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-14 15:35:32 --> Pagination Class Initialized
INFO - 2018-02-14 15:35:32 --> Helper loaded: form_helper
INFO - 2018-02-14 15:35:32 --> Form Validation Class Initialized
INFO - 2018-02-14 15:35:32 --> Model Class Initialized
INFO - 2018-02-14 15:35:32 --> Controller Class Initialized
INFO - 2018-02-14 15:35:32 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-14 15:35:32 --> Model Class Initialized
INFO - 2018-02-14 15:35:32 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-14 15:35:32 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-14 15:35:32 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-14 15:35:32 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-14 15:35:32 --> File loaded: /var/www/html/project/radio/application/views/category/index.php
INFO - 2018-02-14 15:35:32 --> Final output sent to browser
DEBUG - 2018-02-14 15:35:32 --> Total execution time: 0.0097
INFO - 2018-02-14 15:35:34 --> Config Class Initialized
INFO - 2018-02-14 15:35:34 --> Hooks Class Initialized
DEBUG - 2018-02-14 15:35:34 --> UTF-8 Support Enabled
INFO - 2018-02-14 15:35:34 --> Utf8 Class Initialized
INFO - 2018-02-14 15:35:34 --> URI Class Initialized
INFO - 2018-02-14 15:35:34 --> Router Class Initialized
INFO - 2018-02-14 15:35:34 --> Output Class Initialized
INFO - 2018-02-14 15:35:34 --> Security Class Initialized
DEBUG - 2018-02-14 15:35:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 15:35:34 --> Input Class Initialized
INFO - 2018-02-14 15:35:34 --> Language Class Initialized
INFO - 2018-02-14 15:35:34 --> Loader Class Initialized
INFO - 2018-02-14 15:35:34 --> Helper loaded: url_helper
INFO - 2018-02-14 15:35:34 --> Helper loaded: file_helper
INFO - 2018-02-14 15:35:34 --> Helper loaded: email_helper
INFO - 2018-02-14 15:35:34 --> Helper loaded: common_helper
INFO - 2018-02-14 15:35:34 --> Database Driver Class Initialized
DEBUG - 2018-02-14 15:35:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 15:35:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 15:35:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-14 15:35:34 --> Pagination Class Initialized
INFO - 2018-02-14 15:35:34 --> Helper loaded: form_helper
INFO - 2018-02-14 15:35:34 --> Form Validation Class Initialized
INFO - 2018-02-14 15:35:34 --> Model Class Initialized
INFO - 2018-02-14 15:35:34 --> Controller Class Initialized
INFO - 2018-02-14 15:35:34 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-14 15:35:34 --> Model Class Initialized
INFO - 2018-02-14 15:35:34 --> Config Class Initialized
INFO - 2018-02-14 15:35:34 --> Hooks Class Initialized
DEBUG - 2018-02-14 15:35:34 --> UTF-8 Support Enabled
INFO - 2018-02-14 15:35:34 --> Utf8 Class Initialized
INFO - 2018-02-14 15:35:34 --> URI Class Initialized
INFO - 2018-02-14 15:35:34 --> Router Class Initialized
INFO - 2018-02-14 15:35:34 --> Output Class Initialized
INFO - 2018-02-14 15:35:34 --> Security Class Initialized
DEBUG - 2018-02-14 15:35:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 15:35:34 --> Input Class Initialized
INFO - 2018-02-14 15:35:34 --> Language Class Initialized
INFO - 2018-02-14 15:35:34 --> Loader Class Initialized
INFO - 2018-02-14 15:35:34 --> Helper loaded: url_helper
INFO - 2018-02-14 15:35:34 --> Helper loaded: file_helper
INFO - 2018-02-14 15:35:34 --> Helper loaded: email_helper
INFO - 2018-02-14 15:35:34 --> Helper loaded: common_helper
INFO - 2018-02-14 15:35:34 --> Database Driver Class Initialized
DEBUG - 2018-02-14 15:35:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 15:35:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 15:35:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-14 15:35:34 --> Pagination Class Initialized
INFO - 2018-02-14 15:35:34 --> Helper loaded: form_helper
INFO - 2018-02-14 15:35:34 --> Form Validation Class Initialized
INFO - 2018-02-14 15:35:34 --> Model Class Initialized
INFO - 2018-02-14 15:35:34 --> Controller Class Initialized
INFO - 2018-02-14 15:35:34 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-14 15:35:34 --> Model Class Initialized
INFO - 2018-02-14 15:35:34 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-14 15:35:34 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-14 15:35:34 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-14 15:35:34 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-14 15:35:34 --> File loaded: /var/www/html/project/radio/application/views/category/index.php
INFO - 2018-02-14 15:35:34 --> Final output sent to browser
DEBUG - 2018-02-14 15:35:34 --> Total execution time: 0.0057
INFO - 2018-02-14 15:35:36 --> Config Class Initialized
INFO - 2018-02-14 15:35:36 --> Hooks Class Initialized
DEBUG - 2018-02-14 15:35:36 --> UTF-8 Support Enabled
INFO - 2018-02-14 15:35:36 --> Utf8 Class Initialized
INFO - 2018-02-14 15:35:36 --> URI Class Initialized
INFO - 2018-02-14 15:35:36 --> Router Class Initialized
INFO - 2018-02-14 15:35:36 --> Output Class Initialized
INFO - 2018-02-14 15:35:36 --> Security Class Initialized
DEBUG - 2018-02-14 15:35:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 15:35:36 --> Input Class Initialized
INFO - 2018-02-14 15:35:36 --> Language Class Initialized
INFO - 2018-02-14 15:35:36 --> Loader Class Initialized
INFO - 2018-02-14 15:35:36 --> Helper loaded: url_helper
INFO - 2018-02-14 15:35:36 --> Helper loaded: file_helper
INFO - 2018-02-14 15:35:36 --> Helper loaded: email_helper
INFO - 2018-02-14 15:35:36 --> Helper loaded: common_helper
INFO - 2018-02-14 15:35:36 --> Database Driver Class Initialized
DEBUG - 2018-02-14 15:35:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 15:35:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 15:35:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-14 15:35:36 --> Pagination Class Initialized
INFO - 2018-02-14 15:35:36 --> Helper loaded: form_helper
INFO - 2018-02-14 15:35:36 --> Form Validation Class Initialized
INFO - 2018-02-14 15:35:36 --> Model Class Initialized
INFO - 2018-02-14 15:35:36 --> Controller Class Initialized
INFO - 2018-02-14 15:35:36 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-14 15:35:36 --> Model Class Initialized
INFO - 2018-02-14 15:35:36 --> Config Class Initialized
INFO - 2018-02-14 15:35:36 --> Hooks Class Initialized
DEBUG - 2018-02-14 15:35:36 --> UTF-8 Support Enabled
INFO - 2018-02-14 15:35:36 --> Utf8 Class Initialized
INFO - 2018-02-14 15:35:36 --> URI Class Initialized
INFO - 2018-02-14 15:35:36 --> Router Class Initialized
INFO - 2018-02-14 15:35:36 --> Output Class Initialized
INFO - 2018-02-14 15:35:36 --> Security Class Initialized
DEBUG - 2018-02-14 15:35:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 15:35:36 --> Input Class Initialized
INFO - 2018-02-14 15:35:36 --> Language Class Initialized
INFO - 2018-02-14 15:35:36 --> Loader Class Initialized
INFO - 2018-02-14 15:35:36 --> Helper loaded: url_helper
INFO - 2018-02-14 15:35:36 --> Helper loaded: file_helper
INFO - 2018-02-14 15:35:36 --> Helper loaded: email_helper
INFO - 2018-02-14 15:35:36 --> Helper loaded: common_helper
INFO - 2018-02-14 15:35:36 --> Database Driver Class Initialized
DEBUG - 2018-02-14 15:35:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 15:35:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 15:35:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-14 15:35:36 --> Pagination Class Initialized
INFO - 2018-02-14 15:35:36 --> Helper loaded: form_helper
INFO - 2018-02-14 15:35:36 --> Form Validation Class Initialized
INFO - 2018-02-14 15:35:36 --> Model Class Initialized
INFO - 2018-02-14 15:35:36 --> Controller Class Initialized
INFO - 2018-02-14 15:35:36 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-14 15:35:36 --> Model Class Initialized
INFO - 2018-02-14 15:35:36 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-14 15:35:36 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-14 15:35:36 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-14 15:35:36 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-14 15:35:36 --> File loaded: /var/www/html/project/radio/application/views/category/index.php
INFO - 2018-02-14 15:35:36 --> Final output sent to browser
DEBUG - 2018-02-14 15:35:36 --> Total execution time: 0.0051
INFO - 2018-02-14 15:35:39 --> Config Class Initialized
INFO - 2018-02-14 15:35:39 --> Hooks Class Initialized
DEBUG - 2018-02-14 15:35:39 --> UTF-8 Support Enabled
INFO - 2018-02-14 15:35:39 --> Utf8 Class Initialized
INFO - 2018-02-14 15:35:39 --> URI Class Initialized
INFO - 2018-02-14 15:35:39 --> Router Class Initialized
INFO - 2018-02-14 15:35:39 --> Output Class Initialized
INFO - 2018-02-14 15:35:39 --> Security Class Initialized
DEBUG - 2018-02-14 15:35:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 15:35:39 --> Input Class Initialized
INFO - 2018-02-14 15:35:39 --> Language Class Initialized
INFO - 2018-02-14 15:35:39 --> Loader Class Initialized
INFO - 2018-02-14 15:35:39 --> Helper loaded: url_helper
INFO - 2018-02-14 15:35:39 --> Helper loaded: file_helper
INFO - 2018-02-14 15:35:39 --> Helper loaded: email_helper
INFO - 2018-02-14 15:35:39 --> Helper loaded: common_helper
INFO - 2018-02-14 15:35:39 --> Database Driver Class Initialized
DEBUG - 2018-02-14 15:35:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 15:35:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 15:35:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-14 15:35:39 --> Pagination Class Initialized
INFO - 2018-02-14 15:35:39 --> Helper loaded: form_helper
INFO - 2018-02-14 15:35:39 --> Form Validation Class Initialized
INFO - 2018-02-14 15:35:39 --> Model Class Initialized
INFO - 2018-02-14 15:35:39 --> Controller Class Initialized
INFO - 2018-02-14 15:35:39 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-14 15:35:39 --> Model Class Initialized
INFO - 2018-02-14 15:35:39 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-14 15:35:39 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-14 15:35:39 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-14 15:35:39 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-14 15:35:39 --> File loaded: /var/www/html/project/radio/application/views/category/add_edit.php
INFO - 2018-02-14 15:35:39 --> Final output sent to browser
DEBUG - 2018-02-14 15:35:39 --> Total execution time: 0.0061
INFO - 2018-02-14 15:35:44 --> Config Class Initialized
INFO - 2018-02-14 15:35:44 --> Hooks Class Initialized
DEBUG - 2018-02-14 15:35:44 --> UTF-8 Support Enabled
INFO - 2018-02-14 15:35:44 --> Utf8 Class Initialized
INFO - 2018-02-14 15:35:44 --> URI Class Initialized
INFO - 2018-02-14 15:35:44 --> Router Class Initialized
INFO - 2018-02-14 15:35:44 --> Output Class Initialized
INFO - 2018-02-14 15:35:44 --> Security Class Initialized
DEBUG - 2018-02-14 15:35:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 15:35:44 --> Input Class Initialized
INFO - 2018-02-14 15:35:44 --> Language Class Initialized
INFO - 2018-02-14 15:35:44 --> Loader Class Initialized
INFO - 2018-02-14 15:35:44 --> Helper loaded: url_helper
INFO - 2018-02-14 15:35:44 --> Helper loaded: file_helper
INFO - 2018-02-14 15:35:44 --> Helper loaded: email_helper
INFO - 2018-02-14 15:35:44 --> Helper loaded: common_helper
INFO - 2018-02-14 15:35:44 --> Database Driver Class Initialized
DEBUG - 2018-02-14 15:35:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 15:35:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 15:35:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-14 15:35:44 --> Pagination Class Initialized
INFO - 2018-02-14 15:35:44 --> Helper loaded: form_helper
INFO - 2018-02-14 15:35:44 --> Form Validation Class Initialized
INFO - 2018-02-14 15:35:44 --> Model Class Initialized
INFO - 2018-02-14 15:35:44 --> Controller Class Initialized
INFO - 2018-02-14 15:35:44 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-14 15:35:44 --> Model Class Initialized
INFO - 2018-02-14 15:35:44 --> Config Class Initialized
INFO - 2018-02-14 15:35:44 --> Hooks Class Initialized
DEBUG - 2018-02-14 15:35:44 --> UTF-8 Support Enabled
INFO - 2018-02-14 15:35:44 --> Utf8 Class Initialized
INFO - 2018-02-14 15:35:44 --> URI Class Initialized
INFO - 2018-02-14 15:35:44 --> Router Class Initialized
INFO - 2018-02-14 15:35:44 --> Output Class Initialized
INFO - 2018-02-14 15:35:44 --> Security Class Initialized
DEBUG - 2018-02-14 15:35:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 15:35:44 --> Input Class Initialized
INFO - 2018-02-14 15:35:44 --> Language Class Initialized
INFO - 2018-02-14 15:35:44 --> Loader Class Initialized
INFO - 2018-02-14 15:35:44 --> Helper loaded: url_helper
INFO - 2018-02-14 15:35:44 --> Helper loaded: file_helper
INFO - 2018-02-14 15:35:44 --> Helper loaded: email_helper
INFO - 2018-02-14 15:35:44 --> Helper loaded: common_helper
INFO - 2018-02-14 15:35:44 --> Database Driver Class Initialized
DEBUG - 2018-02-14 15:35:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 15:35:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 15:35:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-14 15:35:44 --> Pagination Class Initialized
INFO - 2018-02-14 15:35:44 --> Helper loaded: form_helper
INFO - 2018-02-14 15:35:44 --> Form Validation Class Initialized
INFO - 2018-02-14 15:35:44 --> Model Class Initialized
INFO - 2018-02-14 15:35:44 --> Controller Class Initialized
INFO - 2018-02-14 15:35:44 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-14 15:35:44 --> Model Class Initialized
DEBUG - 2018-02-14 15:35:44 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-14 15:35:44 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-02-14 15:35:44 --> Upload Class Initialized
INFO - 2018-02-14 15:35:45 --> Config Class Initialized
INFO - 2018-02-14 15:35:45 --> Hooks Class Initialized
DEBUG - 2018-02-14 15:35:45 --> UTF-8 Support Enabled
INFO - 2018-02-14 15:35:45 --> Utf8 Class Initialized
INFO - 2018-02-14 15:35:45 --> URI Class Initialized
INFO - 2018-02-14 15:35:45 --> Router Class Initialized
INFO - 2018-02-14 15:35:45 --> Output Class Initialized
INFO - 2018-02-14 15:35:45 --> Security Class Initialized
DEBUG - 2018-02-14 15:35:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 15:35:45 --> Input Class Initialized
INFO - 2018-02-14 15:35:45 --> Language Class Initialized
INFO - 2018-02-14 15:35:45 --> Loader Class Initialized
INFO - 2018-02-14 15:35:45 --> Helper loaded: url_helper
INFO - 2018-02-14 15:35:45 --> Helper loaded: file_helper
INFO - 2018-02-14 15:35:45 --> Helper loaded: email_helper
INFO - 2018-02-14 15:35:45 --> Helper loaded: common_helper
INFO - 2018-02-14 15:35:45 --> Database Driver Class Initialized
DEBUG - 2018-02-14 15:35:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 15:35:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 15:35:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-14 15:35:45 --> Pagination Class Initialized
INFO - 2018-02-14 15:35:45 --> Helper loaded: form_helper
INFO - 2018-02-14 15:35:45 --> Form Validation Class Initialized
INFO - 2018-02-14 15:35:45 --> Model Class Initialized
INFO - 2018-02-14 15:35:45 --> Controller Class Initialized
INFO - 2018-02-14 15:35:45 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-14 15:35:45 --> Model Class Initialized
INFO - 2018-02-14 15:35:45 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-14 15:35:45 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-14 15:35:45 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-14 15:35:45 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-14 15:35:45 --> File loaded: /var/www/html/project/radio/application/views/category/index.php
INFO - 2018-02-14 15:35:45 --> Final output sent to browser
DEBUG - 2018-02-14 15:35:45 --> Total execution time: 0.0088
INFO - 2018-02-14 15:38:12 --> Config Class Initialized
INFO - 2018-02-14 15:38:12 --> Hooks Class Initialized
DEBUG - 2018-02-14 15:38:12 --> UTF-8 Support Enabled
INFO - 2018-02-14 15:38:12 --> Utf8 Class Initialized
INFO - 2018-02-14 15:38:12 --> URI Class Initialized
INFO - 2018-02-14 15:38:12 --> Router Class Initialized
INFO - 2018-02-14 15:38:12 --> Output Class Initialized
INFO - 2018-02-14 15:38:12 --> Security Class Initialized
DEBUG - 2018-02-14 15:38:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 15:38:12 --> Input Class Initialized
INFO - 2018-02-14 15:38:12 --> Language Class Initialized
INFO - 2018-02-14 15:38:12 --> Loader Class Initialized
INFO - 2018-02-14 15:38:12 --> Helper loaded: url_helper
INFO - 2018-02-14 15:38:12 --> Helper loaded: file_helper
INFO - 2018-02-14 15:38:12 --> Helper loaded: email_helper
INFO - 2018-02-14 15:38:12 --> Helper loaded: common_helper
INFO - 2018-02-14 15:38:12 --> Database Driver Class Initialized
DEBUG - 2018-02-14 15:38:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 15:38:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 15:38:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-14 15:38:12 --> Pagination Class Initialized
INFO - 2018-02-14 15:38:12 --> Helper loaded: form_helper
INFO - 2018-02-14 15:38:12 --> Form Validation Class Initialized
INFO - 2018-02-14 15:38:12 --> Model Class Initialized
INFO - 2018-02-14 15:38:12 --> Controller Class Initialized
INFO - 2018-02-14 15:38:12 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-14 15:38:12 --> Model Class Initialized
INFO - 2018-02-14 15:38:12 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-14 15:38:12 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-14 15:38:12 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-14 15:38:12 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-14 15:38:12 --> File loaded: /var/www/html/project/radio/application/views/category/add_edit.php
INFO - 2018-02-14 15:38:12 --> Final output sent to browser
DEBUG - 2018-02-14 15:38:12 --> Total execution time: 0.0152
INFO - 2018-02-14 15:38:26 --> Config Class Initialized
INFO - 2018-02-14 15:38:26 --> Hooks Class Initialized
DEBUG - 2018-02-14 15:38:26 --> UTF-8 Support Enabled
INFO - 2018-02-14 15:38:26 --> Utf8 Class Initialized
INFO - 2018-02-14 15:38:26 --> URI Class Initialized
INFO - 2018-02-14 15:38:26 --> Router Class Initialized
INFO - 2018-02-14 15:38:26 --> Output Class Initialized
INFO - 2018-02-14 15:38:26 --> Security Class Initialized
DEBUG - 2018-02-14 15:38:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 15:38:26 --> Input Class Initialized
INFO - 2018-02-14 15:38:26 --> Language Class Initialized
INFO - 2018-02-14 15:38:26 --> Loader Class Initialized
INFO - 2018-02-14 15:38:26 --> Helper loaded: url_helper
INFO - 2018-02-14 15:38:26 --> Helper loaded: file_helper
INFO - 2018-02-14 15:38:26 --> Helper loaded: email_helper
INFO - 2018-02-14 15:38:26 --> Helper loaded: common_helper
INFO - 2018-02-14 15:38:26 --> Database Driver Class Initialized
DEBUG - 2018-02-14 15:38:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 15:38:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 15:38:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-14 15:38:26 --> Pagination Class Initialized
INFO - 2018-02-14 15:38:26 --> Helper loaded: form_helper
INFO - 2018-02-14 15:38:26 --> Form Validation Class Initialized
INFO - 2018-02-14 15:38:26 --> Model Class Initialized
INFO - 2018-02-14 15:38:26 --> Controller Class Initialized
INFO - 2018-02-14 15:38:26 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-14 15:38:26 --> Model Class Initialized
INFO - 2018-02-14 15:38:26 --> Config Class Initialized
INFO - 2018-02-14 15:38:26 --> Hooks Class Initialized
DEBUG - 2018-02-14 15:38:26 --> UTF-8 Support Enabled
INFO - 2018-02-14 15:38:26 --> Utf8 Class Initialized
INFO - 2018-02-14 15:38:26 --> URI Class Initialized
INFO - 2018-02-14 15:38:26 --> Router Class Initialized
INFO - 2018-02-14 15:38:26 --> Output Class Initialized
INFO - 2018-02-14 15:38:26 --> Security Class Initialized
DEBUG - 2018-02-14 15:38:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 15:38:26 --> Input Class Initialized
INFO - 2018-02-14 15:38:26 --> Language Class Initialized
INFO - 2018-02-14 15:38:26 --> Loader Class Initialized
INFO - 2018-02-14 15:38:26 --> Helper loaded: url_helper
INFO - 2018-02-14 15:38:26 --> Helper loaded: file_helper
INFO - 2018-02-14 15:38:26 --> Helper loaded: email_helper
INFO - 2018-02-14 15:38:26 --> Helper loaded: common_helper
INFO - 2018-02-14 15:38:26 --> Database Driver Class Initialized
DEBUG - 2018-02-14 15:38:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 15:38:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 15:38:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-14 15:38:26 --> Pagination Class Initialized
INFO - 2018-02-14 15:38:26 --> Helper loaded: form_helper
INFO - 2018-02-14 15:38:26 --> Form Validation Class Initialized
INFO - 2018-02-14 15:38:26 --> Model Class Initialized
INFO - 2018-02-14 15:38:26 --> Controller Class Initialized
INFO - 2018-02-14 15:38:26 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-14 15:38:26 --> Model Class Initialized
DEBUG - 2018-02-14 15:38:26 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-14 15:38:26 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-02-14 15:38:26 --> Config Class Initialized
INFO - 2018-02-14 15:38:26 --> Hooks Class Initialized
DEBUG - 2018-02-14 15:38:26 --> UTF-8 Support Enabled
INFO - 2018-02-14 15:38:26 --> Utf8 Class Initialized
INFO - 2018-02-14 15:38:26 --> URI Class Initialized
INFO - 2018-02-14 15:38:26 --> Router Class Initialized
INFO - 2018-02-14 15:38:26 --> Output Class Initialized
INFO - 2018-02-14 15:38:26 --> Security Class Initialized
DEBUG - 2018-02-14 15:38:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 15:38:26 --> Input Class Initialized
INFO - 2018-02-14 15:38:26 --> Language Class Initialized
INFO - 2018-02-14 15:38:26 --> Loader Class Initialized
INFO - 2018-02-14 15:38:26 --> Helper loaded: url_helper
INFO - 2018-02-14 15:38:26 --> Helper loaded: file_helper
INFO - 2018-02-14 15:38:26 --> Helper loaded: email_helper
INFO - 2018-02-14 15:38:26 --> Helper loaded: common_helper
INFO - 2018-02-14 15:38:26 --> Database Driver Class Initialized
DEBUG - 2018-02-14 15:38:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 15:38:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 15:38:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-14 15:38:26 --> Pagination Class Initialized
INFO - 2018-02-14 15:38:26 --> Helper loaded: form_helper
INFO - 2018-02-14 15:38:26 --> Form Validation Class Initialized
INFO - 2018-02-14 15:38:26 --> Model Class Initialized
INFO - 2018-02-14 15:38:26 --> Controller Class Initialized
INFO - 2018-02-14 15:38:26 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-14 15:38:26 --> Model Class Initialized
INFO - 2018-02-14 15:38:26 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-14 15:38:26 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-14 15:38:26 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-14 15:38:26 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-14 15:38:26 --> File loaded: /var/www/html/project/radio/application/views/category/index.php
INFO - 2018-02-14 15:38:26 --> Final output sent to browser
DEBUG - 2018-02-14 15:38:26 --> Total execution time: 0.0054
INFO - 2018-02-14 15:38:29 --> Config Class Initialized
INFO - 2018-02-14 15:38:29 --> Hooks Class Initialized
DEBUG - 2018-02-14 15:38:29 --> UTF-8 Support Enabled
INFO - 2018-02-14 15:38:29 --> Utf8 Class Initialized
INFO - 2018-02-14 15:38:29 --> URI Class Initialized
INFO - 2018-02-14 15:38:29 --> Router Class Initialized
INFO - 2018-02-14 15:38:29 --> Output Class Initialized
INFO - 2018-02-14 15:38:29 --> Security Class Initialized
DEBUG - 2018-02-14 15:38:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 15:38:29 --> Input Class Initialized
INFO - 2018-02-14 15:38:29 --> Language Class Initialized
INFO - 2018-02-14 15:38:29 --> Loader Class Initialized
INFO - 2018-02-14 15:38:29 --> Helper loaded: url_helper
INFO - 2018-02-14 15:38:29 --> Helper loaded: file_helper
INFO - 2018-02-14 15:38:29 --> Helper loaded: email_helper
INFO - 2018-02-14 15:38:29 --> Helper loaded: common_helper
INFO - 2018-02-14 15:38:29 --> Database Driver Class Initialized
DEBUG - 2018-02-14 15:38:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 15:38:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 15:38:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-14 15:38:29 --> Pagination Class Initialized
INFO - 2018-02-14 15:38:29 --> Helper loaded: form_helper
INFO - 2018-02-14 15:38:29 --> Form Validation Class Initialized
INFO - 2018-02-14 15:38:29 --> Model Class Initialized
INFO - 2018-02-14 15:38:29 --> Controller Class Initialized
INFO - 2018-02-14 15:38:29 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-14 15:38:29 --> Model Class Initialized
INFO - 2018-02-14 15:38:29 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-14 15:38:29 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-14 15:38:29 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-14 15:38:29 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-14 15:38:29 --> File loaded: /var/www/html/project/radio/application/views/category/add_edit.php
INFO - 2018-02-14 15:38:29 --> Final output sent to browser
DEBUG - 2018-02-14 15:38:29 --> Total execution time: 0.0061
INFO - 2018-02-14 15:38:43 --> Config Class Initialized
INFO - 2018-02-14 15:38:43 --> Hooks Class Initialized
DEBUG - 2018-02-14 15:38:43 --> UTF-8 Support Enabled
INFO - 2018-02-14 15:38:43 --> Utf8 Class Initialized
INFO - 2018-02-14 15:38:43 --> URI Class Initialized
INFO - 2018-02-14 15:38:43 --> Router Class Initialized
INFO - 2018-02-14 15:38:43 --> Output Class Initialized
INFO - 2018-02-14 15:38:43 --> Security Class Initialized
DEBUG - 2018-02-14 15:38:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 15:38:43 --> Input Class Initialized
INFO - 2018-02-14 15:38:43 --> Language Class Initialized
INFO - 2018-02-14 15:38:43 --> Loader Class Initialized
INFO - 2018-02-14 15:38:43 --> Helper loaded: url_helper
INFO - 2018-02-14 15:38:43 --> Helper loaded: file_helper
INFO - 2018-02-14 15:38:43 --> Helper loaded: email_helper
INFO - 2018-02-14 15:38:43 --> Helper loaded: common_helper
INFO - 2018-02-14 15:38:43 --> Database Driver Class Initialized
DEBUG - 2018-02-14 15:38:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 15:38:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 15:38:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-14 15:38:43 --> Pagination Class Initialized
INFO - 2018-02-14 15:38:43 --> Helper loaded: form_helper
INFO - 2018-02-14 15:38:43 --> Form Validation Class Initialized
INFO - 2018-02-14 15:38:43 --> Model Class Initialized
INFO - 2018-02-14 15:38:43 --> Controller Class Initialized
INFO - 2018-02-14 15:38:43 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-14 15:38:43 --> Model Class Initialized
INFO - 2018-02-14 15:38:43 --> Config Class Initialized
INFO - 2018-02-14 15:38:43 --> Hooks Class Initialized
DEBUG - 2018-02-14 15:38:43 --> UTF-8 Support Enabled
INFO - 2018-02-14 15:38:43 --> Utf8 Class Initialized
INFO - 2018-02-14 15:38:43 --> URI Class Initialized
INFO - 2018-02-14 15:38:43 --> Router Class Initialized
INFO - 2018-02-14 15:38:43 --> Output Class Initialized
INFO - 2018-02-14 15:38:43 --> Security Class Initialized
DEBUG - 2018-02-14 15:38:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 15:38:43 --> Input Class Initialized
INFO - 2018-02-14 15:38:43 --> Language Class Initialized
INFO - 2018-02-14 15:38:43 --> Loader Class Initialized
INFO - 2018-02-14 15:38:43 --> Helper loaded: url_helper
INFO - 2018-02-14 15:38:43 --> Helper loaded: file_helper
INFO - 2018-02-14 15:38:43 --> Helper loaded: email_helper
INFO - 2018-02-14 15:38:43 --> Helper loaded: common_helper
INFO - 2018-02-14 15:38:43 --> Database Driver Class Initialized
DEBUG - 2018-02-14 15:38:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 15:38:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 15:38:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-14 15:38:43 --> Pagination Class Initialized
INFO - 2018-02-14 15:38:43 --> Helper loaded: form_helper
INFO - 2018-02-14 15:38:43 --> Form Validation Class Initialized
INFO - 2018-02-14 15:38:43 --> Model Class Initialized
INFO - 2018-02-14 15:38:43 --> Controller Class Initialized
INFO - 2018-02-14 15:38:43 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-14 15:38:43 --> Model Class Initialized
DEBUG - 2018-02-14 15:38:43 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-14 15:38:43 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-02-14 15:38:43 --> Config Class Initialized
INFO - 2018-02-14 15:38:43 --> Hooks Class Initialized
DEBUG - 2018-02-14 15:38:43 --> UTF-8 Support Enabled
INFO - 2018-02-14 15:38:43 --> Utf8 Class Initialized
INFO - 2018-02-14 15:38:43 --> URI Class Initialized
INFO - 2018-02-14 15:38:43 --> Router Class Initialized
INFO - 2018-02-14 15:38:43 --> Output Class Initialized
INFO - 2018-02-14 15:38:43 --> Security Class Initialized
DEBUG - 2018-02-14 15:38:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 15:38:43 --> Input Class Initialized
INFO - 2018-02-14 15:38:43 --> Language Class Initialized
INFO - 2018-02-14 15:38:43 --> Loader Class Initialized
INFO - 2018-02-14 15:38:43 --> Helper loaded: url_helper
INFO - 2018-02-14 15:38:43 --> Helper loaded: file_helper
INFO - 2018-02-14 15:38:43 --> Helper loaded: email_helper
INFO - 2018-02-14 15:38:43 --> Helper loaded: common_helper
INFO - 2018-02-14 15:38:43 --> Database Driver Class Initialized
DEBUG - 2018-02-14 15:38:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 15:38:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 15:38:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-14 15:38:43 --> Pagination Class Initialized
INFO - 2018-02-14 15:38:43 --> Helper loaded: form_helper
INFO - 2018-02-14 15:38:43 --> Form Validation Class Initialized
INFO - 2018-02-14 15:38:43 --> Model Class Initialized
INFO - 2018-02-14 15:38:43 --> Controller Class Initialized
INFO - 2018-02-14 15:38:43 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-14 15:38:43 --> Model Class Initialized
INFO - 2018-02-14 15:38:43 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-14 15:38:43 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-14 15:38:43 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-14 15:38:43 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-14 15:38:43 --> File loaded: /var/www/html/project/radio/application/views/category/index.php
INFO - 2018-02-14 15:38:43 --> Final output sent to browser
DEBUG - 2018-02-14 15:38:43 --> Total execution time: 0.0055
INFO - 2018-02-14 15:38:47 --> Config Class Initialized
INFO - 2018-02-14 15:38:47 --> Hooks Class Initialized
DEBUG - 2018-02-14 15:38:47 --> UTF-8 Support Enabled
INFO - 2018-02-14 15:38:47 --> Utf8 Class Initialized
INFO - 2018-02-14 15:38:47 --> URI Class Initialized
INFO - 2018-02-14 15:38:47 --> Router Class Initialized
INFO - 2018-02-14 15:38:47 --> Output Class Initialized
INFO - 2018-02-14 15:38:47 --> Security Class Initialized
DEBUG - 2018-02-14 15:38:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 15:38:47 --> Input Class Initialized
INFO - 2018-02-14 15:38:47 --> Language Class Initialized
INFO - 2018-02-14 15:38:47 --> Loader Class Initialized
INFO - 2018-02-14 15:38:47 --> Helper loaded: url_helper
INFO - 2018-02-14 15:38:47 --> Helper loaded: file_helper
INFO - 2018-02-14 15:38:47 --> Helper loaded: email_helper
INFO - 2018-02-14 15:38:47 --> Helper loaded: common_helper
INFO - 2018-02-14 15:38:47 --> Database Driver Class Initialized
DEBUG - 2018-02-14 15:38:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 15:38:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 15:38:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-14 15:38:47 --> Pagination Class Initialized
INFO - 2018-02-14 15:38:47 --> Helper loaded: form_helper
INFO - 2018-02-14 15:38:47 --> Form Validation Class Initialized
INFO - 2018-02-14 15:38:47 --> Model Class Initialized
INFO - 2018-02-14 15:38:47 --> Controller Class Initialized
INFO - 2018-02-14 15:38:47 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-14 15:38:47 --> Model Class Initialized
INFO - 2018-02-14 15:38:47 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-14 15:38:47 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-14 15:38:47 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-14 15:38:47 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-14 15:38:47 --> File loaded: /var/www/html/project/radio/application/views/category/add_edit.php
INFO - 2018-02-14 15:38:47 --> Final output sent to browser
DEBUG - 2018-02-14 15:38:47 --> Total execution time: 0.0053
INFO - 2018-02-14 15:38:56 --> Config Class Initialized
INFO - 2018-02-14 15:38:56 --> Hooks Class Initialized
DEBUG - 2018-02-14 15:38:56 --> UTF-8 Support Enabled
INFO - 2018-02-14 15:38:56 --> Utf8 Class Initialized
INFO - 2018-02-14 15:38:56 --> URI Class Initialized
INFO - 2018-02-14 15:38:56 --> Router Class Initialized
INFO - 2018-02-14 15:38:56 --> Output Class Initialized
INFO - 2018-02-14 15:38:56 --> Security Class Initialized
DEBUG - 2018-02-14 15:38:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 15:38:56 --> Input Class Initialized
INFO - 2018-02-14 15:38:56 --> Language Class Initialized
INFO - 2018-02-14 15:38:56 --> Loader Class Initialized
INFO - 2018-02-14 15:38:56 --> Helper loaded: url_helper
INFO - 2018-02-14 15:38:56 --> Helper loaded: file_helper
INFO - 2018-02-14 15:38:56 --> Helper loaded: email_helper
INFO - 2018-02-14 15:38:56 --> Helper loaded: common_helper
INFO - 2018-02-14 15:38:56 --> Database Driver Class Initialized
DEBUG - 2018-02-14 15:38:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 15:38:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 15:38:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-14 15:38:56 --> Pagination Class Initialized
INFO - 2018-02-14 15:38:56 --> Helper loaded: form_helper
INFO - 2018-02-14 15:38:56 --> Form Validation Class Initialized
INFO - 2018-02-14 15:38:56 --> Model Class Initialized
INFO - 2018-02-14 15:38:56 --> Controller Class Initialized
INFO - 2018-02-14 15:38:56 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-14 15:38:56 --> Model Class Initialized
INFO - 2018-02-14 15:38:56 --> Config Class Initialized
INFO - 2018-02-14 15:38:56 --> Hooks Class Initialized
DEBUG - 2018-02-14 15:38:56 --> UTF-8 Support Enabled
INFO - 2018-02-14 15:38:56 --> Utf8 Class Initialized
INFO - 2018-02-14 15:38:56 --> URI Class Initialized
INFO - 2018-02-14 15:38:56 --> Router Class Initialized
INFO - 2018-02-14 15:38:56 --> Output Class Initialized
INFO - 2018-02-14 15:38:56 --> Security Class Initialized
DEBUG - 2018-02-14 15:38:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 15:38:56 --> Input Class Initialized
INFO - 2018-02-14 15:38:56 --> Language Class Initialized
INFO - 2018-02-14 15:38:56 --> Loader Class Initialized
INFO - 2018-02-14 15:38:56 --> Helper loaded: url_helper
INFO - 2018-02-14 15:38:56 --> Helper loaded: file_helper
INFO - 2018-02-14 15:38:56 --> Helper loaded: email_helper
INFO - 2018-02-14 15:38:56 --> Helper loaded: common_helper
INFO - 2018-02-14 15:38:56 --> Database Driver Class Initialized
DEBUG - 2018-02-14 15:38:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 15:38:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 15:38:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-14 15:38:56 --> Pagination Class Initialized
INFO - 2018-02-14 15:38:56 --> Helper loaded: form_helper
INFO - 2018-02-14 15:38:56 --> Form Validation Class Initialized
INFO - 2018-02-14 15:38:56 --> Model Class Initialized
INFO - 2018-02-14 15:38:56 --> Controller Class Initialized
INFO - 2018-02-14 15:38:56 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-14 15:38:56 --> Model Class Initialized
DEBUG - 2018-02-14 15:38:56 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-14 15:38:56 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2018-02-14 15:38:56 --> Severity: Notice --> Undefined offset: 1 /var/www/html/project/radio/application/controllers/Category.php 232
INFO - 2018-02-14 15:38:56 --> Upload Class Initialized
INFO - 2018-02-14 15:38:56 --> Language file loaded: language/english/upload_lang.php
DEBUG - 2018-02-14 15:38:56 --> You did not select a file to upload.
ERROR - 2018-02-14 15:38:56 --> Severity: Notice --> Undefined index: status /var/www/html/project/radio/application/controllers/Category.php 49
INFO - 2018-02-14 15:38:56 --> Config Class Initialized
INFO - 2018-02-14 15:38:56 --> Hooks Class Initialized
DEBUG - 2018-02-14 15:38:56 --> UTF-8 Support Enabled
INFO - 2018-02-14 15:38:56 --> Utf8 Class Initialized
INFO - 2018-02-14 15:38:56 --> URI Class Initialized
INFO - 2018-02-14 15:38:56 --> Router Class Initialized
INFO - 2018-02-14 15:38:56 --> Output Class Initialized
INFO - 2018-02-14 15:38:56 --> Security Class Initialized
DEBUG - 2018-02-14 15:38:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 15:38:56 --> Input Class Initialized
INFO - 2018-02-14 15:38:56 --> Language Class Initialized
INFO - 2018-02-14 15:38:56 --> Loader Class Initialized
INFO - 2018-02-14 15:38:56 --> Helper loaded: url_helper
INFO - 2018-02-14 15:38:56 --> Helper loaded: file_helper
INFO - 2018-02-14 15:38:56 --> Helper loaded: email_helper
INFO - 2018-02-14 15:38:56 --> Helper loaded: common_helper
INFO - 2018-02-14 15:38:56 --> Database Driver Class Initialized
DEBUG - 2018-02-14 15:38:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 15:38:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 15:38:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-14 15:38:56 --> Pagination Class Initialized
INFO - 2018-02-14 15:38:56 --> Helper loaded: form_helper
INFO - 2018-02-14 15:38:56 --> Form Validation Class Initialized
INFO - 2018-02-14 15:38:56 --> Model Class Initialized
INFO - 2018-02-14 15:38:56 --> Controller Class Initialized
INFO - 2018-02-14 15:38:56 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-14 15:38:56 --> Model Class Initialized
INFO - 2018-02-14 15:38:56 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-14 15:38:56 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-14 15:38:56 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-14 15:38:56 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-14 15:38:56 --> File loaded: /var/www/html/project/radio/application/views/category/index.php
INFO - 2018-02-14 15:38:56 --> Final output sent to browser
DEBUG - 2018-02-14 15:38:56 --> Total execution time: 0.0036
INFO - 2018-02-14 15:39:02 --> Config Class Initialized
INFO - 2018-02-14 15:39:02 --> Hooks Class Initialized
DEBUG - 2018-02-14 15:39:02 --> UTF-8 Support Enabled
INFO - 2018-02-14 15:39:02 --> Utf8 Class Initialized
INFO - 2018-02-14 15:39:02 --> URI Class Initialized
INFO - 2018-02-14 15:39:02 --> Router Class Initialized
INFO - 2018-02-14 15:39:02 --> Output Class Initialized
INFO - 2018-02-14 15:39:02 --> Security Class Initialized
DEBUG - 2018-02-14 15:39:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 15:39:02 --> Input Class Initialized
INFO - 2018-02-14 15:39:02 --> Language Class Initialized
INFO - 2018-02-14 15:39:02 --> Loader Class Initialized
INFO - 2018-02-14 15:39:02 --> Helper loaded: url_helper
INFO - 2018-02-14 15:39:02 --> Helper loaded: file_helper
INFO - 2018-02-14 15:39:02 --> Helper loaded: email_helper
INFO - 2018-02-14 15:39:02 --> Helper loaded: common_helper
INFO - 2018-02-14 15:39:02 --> Database Driver Class Initialized
DEBUG - 2018-02-14 15:39:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 15:39:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 15:39:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-14 15:39:02 --> Pagination Class Initialized
INFO - 2018-02-14 15:39:02 --> Helper loaded: form_helper
INFO - 2018-02-14 15:39:02 --> Form Validation Class Initialized
INFO - 2018-02-14 15:39:02 --> Model Class Initialized
INFO - 2018-02-14 15:39:02 --> Controller Class Initialized
INFO - 2018-02-14 15:39:02 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-14 15:39:02 --> Model Class Initialized
INFO - 2018-02-14 15:39:02 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-14 15:39:02 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-14 15:39:02 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-14 15:39:02 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-14 15:39:02 --> File loaded: /var/www/html/project/radio/application/views/category/add_edit.php
INFO - 2018-02-14 15:39:02 --> Final output sent to browser
DEBUG - 2018-02-14 15:39:02 --> Total execution time: 0.0043
INFO - 2018-02-14 15:39:50 --> Config Class Initialized
INFO - 2018-02-14 15:39:50 --> Hooks Class Initialized
DEBUG - 2018-02-14 15:39:50 --> UTF-8 Support Enabled
INFO - 2018-02-14 15:39:50 --> Utf8 Class Initialized
INFO - 2018-02-14 15:39:50 --> URI Class Initialized
INFO - 2018-02-14 15:39:50 --> Router Class Initialized
INFO - 2018-02-14 15:39:50 --> Output Class Initialized
INFO - 2018-02-14 15:39:50 --> Security Class Initialized
DEBUG - 2018-02-14 15:39:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 15:39:50 --> Input Class Initialized
INFO - 2018-02-14 15:39:50 --> Language Class Initialized
INFO - 2018-02-14 15:39:50 --> Loader Class Initialized
INFO - 2018-02-14 15:39:50 --> Helper loaded: url_helper
INFO - 2018-02-14 15:39:50 --> Helper loaded: file_helper
INFO - 2018-02-14 15:39:50 --> Helper loaded: email_helper
INFO - 2018-02-14 15:39:50 --> Helper loaded: common_helper
INFO - 2018-02-14 15:39:50 --> Database Driver Class Initialized
DEBUG - 2018-02-14 15:39:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 15:39:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 15:39:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-14 15:39:50 --> Pagination Class Initialized
INFO - 2018-02-14 15:39:50 --> Helper loaded: form_helper
INFO - 2018-02-14 15:39:50 --> Form Validation Class Initialized
INFO - 2018-02-14 15:39:50 --> Model Class Initialized
INFO - 2018-02-14 15:39:50 --> Controller Class Initialized
INFO - 2018-02-14 15:39:50 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-14 15:39:50 --> Model Class Initialized
INFO - 2018-02-14 15:39:50 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-14 15:39:50 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-14 15:39:50 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-14 15:39:50 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-14 15:39:50 --> File loaded: /var/www/html/project/radio/application/views/category/add_edit.php
INFO - 2018-02-14 15:39:50 --> Final output sent to browser
DEBUG - 2018-02-14 15:39:50 --> Total execution time: 0.0052
INFO - 2018-02-14 15:39:52 --> Config Class Initialized
INFO - 2018-02-14 15:39:52 --> Hooks Class Initialized
DEBUG - 2018-02-14 15:39:52 --> UTF-8 Support Enabled
INFO - 2018-02-14 15:39:52 --> Utf8 Class Initialized
INFO - 2018-02-14 15:39:52 --> URI Class Initialized
INFO - 2018-02-14 15:39:52 --> Router Class Initialized
INFO - 2018-02-14 15:39:52 --> Output Class Initialized
INFO - 2018-02-14 15:39:52 --> Security Class Initialized
DEBUG - 2018-02-14 15:39:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 15:39:52 --> Input Class Initialized
INFO - 2018-02-14 15:39:52 --> Language Class Initialized
INFO - 2018-02-14 15:39:52 --> Loader Class Initialized
INFO - 2018-02-14 15:39:52 --> Helper loaded: url_helper
INFO - 2018-02-14 15:39:52 --> Helper loaded: file_helper
INFO - 2018-02-14 15:39:52 --> Helper loaded: email_helper
INFO - 2018-02-14 15:39:52 --> Helper loaded: common_helper
INFO - 2018-02-14 15:39:52 --> Database Driver Class Initialized
DEBUG - 2018-02-14 15:39:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 15:39:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 15:39:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-14 15:39:52 --> Pagination Class Initialized
INFO - 2018-02-14 15:39:52 --> Helper loaded: form_helper
INFO - 2018-02-14 15:39:52 --> Form Validation Class Initialized
INFO - 2018-02-14 15:39:52 --> Model Class Initialized
INFO - 2018-02-14 15:39:52 --> Controller Class Initialized
INFO - 2018-02-14 15:39:52 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-14 15:39:52 --> Model Class Initialized
INFO - 2018-02-14 15:39:52 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-14 15:39:52 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-14 15:39:52 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-14 15:39:52 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-14 15:39:52 --> File loaded: /var/www/html/project/radio/application/views/category/index.php
INFO - 2018-02-14 15:39:52 --> Final output sent to browser
DEBUG - 2018-02-14 15:39:52 --> Total execution time: 0.0065
INFO - 2018-02-14 15:39:54 --> Config Class Initialized
INFO - 2018-02-14 15:39:54 --> Hooks Class Initialized
DEBUG - 2018-02-14 15:39:54 --> UTF-8 Support Enabled
INFO - 2018-02-14 15:39:54 --> Utf8 Class Initialized
INFO - 2018-02-14 15:39:54 --> URI Class Initialized
INFO - 2018-02-14 15:39:54 --> Router Class Initialized
INFO - 2018-02-14 15:39:54 --> Output Class Initialized
INFO - 2018-02-14 15:39:54 --> Security Class Initialized
DEBUG - 2018-02-14 15:39:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 15:39:54 --> Input Class Initialized
INFO - 2018-02-14 15:39:54 --> Language Class Initialized
INFO - 2018-02-14 15:39:54 --> Loader Class Initialized
INFO - 2018-02-14 15:39:54 --> Helper loaded: url_helper
INFO - 2018-02-14 15:39:54 --> Helper loaded: file_helper
INFO - 2018-02-14 15:39:54 --> Helper loaded: email_helper
INFO - 2018-02-14 15:39:54 --> Helper loaded: common_helper
INFO - 2018-02-14 15:39:54 --> Database Driver Class Initialized
DEBUG - 2018-02-14 15:39:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 15:39:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 15:39:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-14 15:39:54 --> Pagination Class Initialized
INFO - 2018-02-14 15:39:54 --> Helper loaded: form_helper
INFO - 2018-02-14 15:39:54 --> Form Validation Class Initialized
INFO - 2018-02-14 15:39:54 --> Model Class Initialized
INFO - 2018-02-14 15:39:54 --> Controller Class Initialized
INFO - 2018-02-14 15:39:54 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-14 15:39:54 --> Model Class Initialized
INFO - 2018-02-14 15:39:54 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-14 15:39:54 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-14 15:39:54 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-14 15:39:54 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-14 15:39:54 --> File loaded: /var/www/html/project/radio/application/views/category/add_edit.php
INFO - 2018-02-14 15:39:54 --> Final output sent to browser
DEBUG - 2018-02-14 15:39:54 --> Total execution time: 0.0052
INFO - 2018-02-14 15:40:03 --> Config Class Initialized
INFO - 2018-02-14 15:40:03 --> Hooks Class Initialized
DEBUG - 2018-02-14 15:40:03 --> UTF-8 Support Enabled
INFO - 2018-02-14 15:40:03 --> Utf8 Class Initialized
INFO - 2018-02-14 15:40:03 --> URI Class Initialized
INFO - 2018-02-14 15:40:03 --> Router Class Initialized
INFO - 2018-02-14 15:40:03 --> Output Class Initialized
INFO - 2018-02-14 15:40:03 --> Security Class Initialized
DEBUG - 2018-02-14 15:40:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 15:40:03 --> Input Class Initialized
INFO - 2018-02-14 15:40:03 --> Language Class Initialized
INFO - 2018-02-14 15:40:03 --> Loader Class Initialized
INFO - 2018-02-14 15:40:03 --> Helper loaded: url_helper
INFO - 2018-02-14 15:40:03 --> Helper loaded: file_helper
INFO - 2018-02-14 15:40:03 --> Helper loaded: email_helper
INFO - 2018-02-14 15:40:03 --> Helper loaded: common_helper
INFO - 2018-02-14 15:40:03 --> Database Driver Class Initialized
DEBUG - 2018-02-14 15:40:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 15:40:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 15:40:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-14 15:40:03 --> Pagination Class Initialized
INFO - 2018-02-14 15:40:03 --> Helper loaded: form_helper
INFO - 2018-02-14 15:40:03 --> Form Validation Class Initialized
INFO - 2018-02-14 15:40:03 --> Model Class Initialized
INFO - 2018-02-14 15:40:03 --> Controller Class Initialized
INFO - 2018-02-14 15:40:03 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-14 15:40:03 --> Model Class Initialized
INFO - 2018-02-14 15:40:03 --> Config Class Initialized
INFO - 2018-02-14 15:40:03 --> Hooks Class Initialized
DEBUG - 2018-02-14 15:40:03 --> UTF-8 Support Enabled
INFO - 2018-02-14 15:40:03 --> Utf8 Class Initialized
INFO - 2018-02-14 15:40:03 --> URI Class Initialized
INFO - 2018-02-14 15:40:03 --> Router Class Initialized
INFO - 2018-02-14 15:40:03 --> Output Class Initialized
INFO - 2018-02-14 15:40:03 --> Security Class Initialized
DEBUG - 2018-02-14 15:40:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 15:40:03 --> Input Class Initialized
INFO - 2018-02-14 15:40:03 --> Language Class Initialized
INFO - 2018-02-14 15:40:03 --> Loader Class Initialized
INFO - 2018-02-14 15:40:03 --> Helper loaded: url_helper
INFO - 2018-02-14 15:40:03 --> Helper loaded: file_helper
INFO - 2018-02-14 15:40:03 --> Helper loaded: email_helper
INFO - 2018-02-14 15:40:03 --> Helper loaded: common_helper
INFO - 2018-02-14 15:40:03 --> Database Driver Class Initialized
DEBUG - 2018-02-14 15:40:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 15:40:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 15:40:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-14 15:40:03 --> Pagination Class Initialized
INFO - 2018-02-14 15:40:03 --> Helper loaded: form_helper
INFO - 2018-02-14 15:40:03 --> Form Validation Class Initialized
INFO - 2018-02-14 15:40:03 --> Model Class Initialized
INFO - 2018-02-14 15:40:03 --> Controller Class Initialized
INFO - 2018-02-14 15:40:03 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-14 15:40:03 --> Model Class Initialized
DEBUG - 2018-02-14 15:40:03 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-14 15:40:03 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-02-14 15:40:03 --> Config Class Initialized
INFO - 2018-02-14 15:40:03 --> Hooks Class Initialized
DEBUG - 2018-02-14 15:40:03 --> UTF-8 Support Enabled
INFO - 2018-02-14 15:40:03 --> Utf8 Class Initialized
INFO - 2018-02-14 15:40:03 --> URI Class Initialized
INFO - 2018-02-14 15:40:03 --> Router Class Initialized
INFO - 2018-02-14 15:40:03 --> Output Class Initialized
INFO - 2018-02-14 15:40:03 --> Security Class Initialized
DEBUG - 2018-02-14 15:40:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 15:40:03 --> Input Class Initialized
INFO - 2018-02-14 15:40:03 --> Language Class Initialized
INFO - 2018-02-14 15:40:03 --> Loader Class Initialized
INFO - 2018-02-14 15:40:03 --> Helper loaded: url_helper
INFO - 2018-02-14 15:40:03 --> Helper loaded: file_helper
INFO - 2018-02-14 15:40:03 --> Helper loaded: email_helper
INFO - 2018-02-14 15:40:03 --> Helper loaded: common_helper
INFO - 2018-02-14 15:40:03 --> Database Driver Class Initialized
DEBUG - 2018-02-14 15:40:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 15:40:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 15:40:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-14 15:40:03 --> Pagination Class Initialized
INFO - 2018-02-14 15:40:03 --> Helper loaded: form_helper
INFO - 2018-02-14 15:40:03 --> Form Validation Class Initialized
INFO - 2018-02-14 15:40:03 --> Model Class Initialized
INFO - 2018-02-14 15:40:03 --> Controller Class Initialized
INFO - 2018-02-14 15:40:03 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-14 15:40:03 --> Model Class Initialized
INFO - 2018-02-14 15:40:03 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-14 15:40:03 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-14 15:40:03 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-14 15:40:03 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-14 15:40:03 --> File loaded: /var/www/html/project/radio/application/views/category/index.php
INFO - 2018-02-14 15:40:03 --> Final output sent to browser
DEBUG - 2018-02-14 15:40:03 --> Total execution time: 0.0062
INFO - 2018-02-14 15:44:29 --> Config Class Initialized
INFO - 2018-02-14 15:44:29 --> Hooks Class Initialized
DEBUG - 2018-02-14 15:44:29 --> UTF-8 Support Enabled
INFO - 2018-02-14 15:44:29 --> Utf8 Class Initialized
INFO - 2018-02-14 15:44:29 --> URI Class Initialized
INFO - 2018-02-14 15:44:29 --> Router Class Initialized
INFO - 2018-02-14 15:44:29 --> Output Class Initialized
INFO - 2018-02-14 15:44:29 --> Security Class Initialized
DEBUG - 2018-02-14 15:44:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 15:44:29 --> Input Class Initialized
INFO - 2018-02-14 15:44:29 --> Language Class Initialized
INFO - 2018-02-14 15:44:29 --> Loader Class Initialized
INFO - 2018-02-14 15:44:29 --> Helper loaded: url_helper
INFO - 2018-02-14 15:44:29 --> Helper loaded: file_helper
INFO - 2018-02-14 15:44:29 --> Helper loaded: email_helper
INFO - 2018-02-14 15:44:29 --> Helper loaded: common_helper
INFO - 2018-02-14 15:44:29 --> Database Driver Class Initialized
DEBUG - 2018-02-14 15:44:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 15:44:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 15:44:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-14 15:44:29 --> Pagination Class Initialized
INFO - 2018-02-14 15:44:29 --> Helper loaded: form_helper
INFO - 2018-02-14 15:44:29 --> Form Validation Class Initialized
INFO - 2018-02-14 15:44:29 --> Model Class Initialized
INFO - 2018-02-14 15:44:29 --> Controller Class Initialized
INFO - 2018-02-14 15:44:29 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-14 15:44:29 --> Model Class Initialized
INFO - 2018-02-14 15:44:29 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-14 15:44:29 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-14 15:44:29 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-14 15:44:29 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-14 15:44:29 --> File loaded: /var/www/html/project/radio/application/views/category/index.php
INFO - 2018-02-14 15:44:29 --> Final output sent to browser
DEBUG - 2018-02-14 15:44:29 --> Total execution time: 0.0076
INFO - 2018-02-14 15:52:55 --> Config Class Initialized
INFO - 2018-02-14 15:52:55 --> Hooks Class Initialized
DEBUG - 2018-02-14 15:52:55 --> UTF-8 Support Enabled
INFO - 2018-02-14 15:52:55 --> Utf8 Class Initialized
INFO - 2018-02-14 15:52:55 --> URI Class Initialized
INFO - 2018-02-14 15:52:55 --> Router Class Initialized
INFO - 2018-02-14 15:52:55 --> Output Class Initialized
INFO - 2018-02-14 15:52:55 --> Security Class Initialized
DEBUG - 2018-02-14 15:52:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 15:52:55 --> Input Class Initialized
INFO - 2018-02-14 15:52:55 --> Language Class Initialized
INFO - 2018-02-14 15:52:55 --> Loader Class Initialized
INFO - 2018-02-14 15:52:55 --> Helper loaded: url_helper
INFO - 2018-02-14 15:52:55 --> Helper loaded: file_helper
INFO - 2018-02-14 15:52:55 --> Helper loaded: email_helper
INFO - 2018-02-14 15:52:55 --> Helper loaded: common_helper
INFO - 2018-02-14 15:52:55 --> Database Driver Class Initialized
DEBUG - 2018-02-14 15:52:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 15:52:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 15:52:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-14 15:52:55 --> Pagination Class Initialized
INFO - 2018-02-14 15:52:55 --> Helper loaded: form_helper
INFO - 2018-02-14 15:52:55 --> Form Validation Class Initialized
INFO - 2018-02-14 15:52:55 --> Model Class Initialized
INFO - 2018-02-14 15:52:55 --> Controller Class Initialized
INFO - 2018-02-14 15:52:55 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-14 15:52:55 --> Model Class Initialized
INFO - 2018-02-14 15:52:55 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-14 15:52:55 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-14 15:52:55 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-14 15:52:55 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-14 15:52:55 --> File loaded: /var/www/html/project/radio/application/views/category/index.php
INFO - 2018-02-14 15:52:55 --> Final output sent to browser
DEBUG - 2018-02-14 15:52:55 --> Total execution time: 0.2293
INFO - 2018-02-14 15:52:56 --> Config Class Initialized
INFO - 2018-02-14 15:52:56 --> Hooks Class Initialized
DEBUG - 2018-02-14 15:52:56 --> UTF-8 Support Enabled
INFO - 2018-02-14 15:52:56 --> Utf8 Class Initialized
INFO - 2018-02-14 15:52:56 --> URI Class Initialized
INFO - 2018-02-14 15:52:56 --> Router Class Initialized
INFO - 2018-02-14 15:52:56 --> Output Class Initialized
INFO - 2018-02-14 15:52:56 --> Security Class Initialized
DEBUG - 2018-02-14 15:52:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 15:52:56 --> Input Class Initialized
INFO - 2018-02-14 15:52:56 --> Language Class Initialized
INFO - 2018-02-14 15:52:56 --> Loader Class Initialized
INFO - 2018-02-14 15:52:56 --> Helper loaded: url_helper
INFO - 2018-02-14 15:52:56 --> Helper loaded: file_helper
INFO - 2018-02-14 15:52:56 --> Helper loaded: email_helper
INFO - 2018-02-14 15:52:56 --> Helper loaded: common_helper
INFO - 2018-02-14 15:52:56 --> Database Driver Class Initialized
DEBUG - 2018-02-14 15:52:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 15:52:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 15:52:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-14 15:52:56 --> Pagination Class Initialized
INFO - 2018-02-14 15:52:56 --> Helper loaded: form_helper
INFO - 2018-02-14 15:52:56 --> Form Validation Class Initialized
INFO - 2018-02-14 15:52:56 --> Model Class Initialized
INFO - 2018-02-14 15:52:56 --> Controller Class Initialized
INFO - 2018-02-14 15:52:56 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-14 15:52:56 --> Model Class Initialized
INFO - 2018-02-14 15:52:56 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-14 15:52:56 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-14 15:52:56 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-14 15:52:56 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-14 15:52:56 --> File loaded: /var/www/html/project/radio/application/views/category/add_edit.php
INFO - 2018-02-14 15:52:56 --> Final output sent to browser
DEBUG - 2018-02-14 15:52:56 --> Total execution time: 0.0037
INFO - 2018-02-14 15:52:58 --> Config Class Initialized
INFO - 2018-02-14 15:52:58 --> Hooks Class Initialized
DEBUG - 2018-02-14 15:52:58 --> UTF-8 Support Enabled
INFO - 2018-02-14 15:52:58 --> Utf8 Class Initialized
INFO - 2018-02-14 15:52:58 --> URI Class Initialized
INFO - 2018-02-14 15:52:58 --> Router Class Initialized
INFO - 2018-02-14 15:52:58 --> Output Class Initialized
INFO - 2018-02-14 15:52:58 --> Security Class Initialized
DEBUG - 2018-02-14 15:52:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 15:52:58 --> Input Class Initialized
INFO - 2018-02-14 15:52:58 --> Language Class Initialized
INFO - 2018-02-14 15:52:58 --> Loader Class Initialized
INFO - 2018-02-14 15:52:58 --> Helper loaded: url_helper
INFO - 2018-02-14 15:52:58 --> Helper loaded: file_helper
INFO - 2018-02-14 15:52:58 --> Helper loaded: email_helper
INFO - 2018-02-14 15:52:58 --> Helper loaded: common_helper
INFO - 2018-02-14 15:52:58 --> Database Driver Class Initialized
DEBUG - 2018-02-14 15:52:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 15:52:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 15:52:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-14 15:52:58 --> Pagination Class Initialized
INFO - 2018-02-14 15:52:58 --> Helper loaded: form_helper
INFO - 2018-02-14 15:52:58 --> Form Validation Class Initialized
INFO - 2018-02-14 15:52:58 --> Model Class Initialized
INFO - 2018-02-14 15:52:58 --> Controller Class Initialized
INFO - 2018-02-14 15:52:58 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-14 15:52:58 --> Model Class Initialized
INFO - 2018-02-14 15:52:58 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-14 15:52:58 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-14 15:52:58 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-14 15:52:58 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-14 15:52:58 --> File loaded: /var/www/html/project/radio/application/views/category/index.php
INFO - 2018-02-14 15:52:58 --> Final output sent to browser
DEBUG - 2018-02-14 15:52:58 --> Total execution time: 0.0042
INFO - 2018-02-14 15:53:00 --> Config Class Initialized
INFO - 2018-02-14 15:53:00 --> Hooks Class Initialized
DEBUG - 2018-02-14 15:53:00 --> UTF-8 Support Enabled
INFO - 2018-02-14 15:53:00 --> Utf8 Class Initialized
INFO - 2018-02-14 15:53:00 --> URI Class Initialized
INFO - 2018-02-14 15:53:00 --> Router Class Initialized
INFO - 2018-02-14 15:53:00 --> Output Class Initialized
INFO - 2018-02-14 15:53:00 --> Security Class Initialized
DEBUG - 2018-02-14 15:53:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 15:53:00 --> Input Class Initialized
INFO - 2018-02-14 15:53:00 --> Language Class Initialized
INFO - 2018-02-14 15:53:00 --> Loader Class Initialized
INFO - 2018-02-14 15:53:00 --> Helper loaded: url_helper
INFO - 2018-02-14 15:53:00 --> Helper loaded: file_helper
INFO - 2018-02-14 15:53:00 --> Helper loaded: email_helper
INFO - 2018-02-14 15:53:00 --> Helper loaded: common_helper
INFO - 2018-02-14 15:53:00 --> Database Driver Class Initialized
DEBUG - 2018-02-14 15:53:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 15:53:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 15:53:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-14 15:53:00 --> Pagination Class Initialized
INFO - 2018-02-14 15:53:00 --> Helper loaded: form_helper
INFO - 2018-02-14 15:53:00 --> Form Validation Class Initialized
INFO - 2018-02-14 15:53:00 --> Model Class Initialized
INFO - 2018-02-14 15:53:00 --> Controller Class Initialized
INFO - 2018-02-14 15:53:00 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-14 15:53:00 --> Model Class Initialized
INFO - 2018-02-14 15:53:00 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-14 15:53:00 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-14 15:53:00 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-14 15:53:00 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-14 15:53:00 --> File loaded: /var/www/html/project/radio/application/views/category/add_edit.php
INFO - 2018-02-14 15:53:00 --> Final output sent to browser
DEBUG - 2018-02-14 15:53:00 --> Total execution time: 0.0046
INFO - 2018-02-14 15:53:49 --> Config Class Initialized
INFO - 2018-02-14 15:53:49 --> Hooks Class Initialized
DEBUG - 2018-02-14 15:53:49 --> UTF-8 Support Enabled
INFO - 2018-02-14 15:53:49 --> Utf8 Class Initialized
INFO - 2018-02-14 15:53:49 --> URI Class Initialized
INFO - 2018-02-14 15:53:49 --> Router Class Initialized
INFO - 2018-02-14 15:53:49 --> Output Class Initialized
INFO - 2018-02-14 15:53:49 --> Security Class Initialized
DEBUG - 2018-02-14 15:53:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 15:53:49 --> Input Class Initialized
INFO - 2018-02-14 15:53:49 --> Language Class Initialized
INFO - 2018-02-14 15:53:49 --> Loader Class Initialized
INFO - 2018-02-14 15:53:49 --> Helper loaded: url_helper
INFO - 2018-02-14 15:53:49 --> Helper loaded: file_helper
INFO - 2018-02-14 15:53:49 --> Helper loaded: email_helper
INFO - 2018-02-14 15:53:49 --> Helper loaded: common_helper
INFO - 2018-02-14 15:53:49 --> Database Driver Class Initialized
DEBUG - 2018-02-14 15:53:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 15:53:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 15:53:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-14 15:53:49 --> Pagination Class Initialized
INFO - 2018-02-14 15:53:49 --> Helper loaded: form_helper
INFO - 2018-02-14 15:53:49 --> Form Validation Class Initialized
INFO - 2018-02-14 15:53:49 --> Model Class Initialized
INFO - 2018-02-14 15:53:49 --> Controller Class Initialized
INFO - 2018-02-14 15:53:49 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-14 15:53:49 --> Model Class Initialized
INFO - 2018-02-14 15:53:49 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-14 15:53:49 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-14 15:53:49 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-14 15:53:49 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-14 15:53:49 --> File loaded: /var/www/html/project/radio/application/views/category/index.php
INFO - 2018-02-14 15:53:49 --> Final output sent to browser
DEBUG - 2018-02-14 15:53:49 --> Total execution time: 0.0099
INFO - 2018-02-14 15:53:54 --> Config Class Initialized
INFO - 2018-02-14 15:53:54 --> Hooks Class Initialized
DEBUG - 2018-02-14 15:53:54 --> UTF-8 Support Enabled
INFO - 2018-02-14 15:53:54 --> Utf8 Class Initialized
INFO - 2018-02-14 15:53:54 --> URI Class Initialized
INFO - 2018-02-14 15:53:54 --> Router Class Initialized
INFO - 2018-02-14 15:53:54 --> Output Class Initialized
INFO - 2018-02-14 15:53:54 --> Security Class Initialized
DEBUG - 2018-02-14 15:53:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 15:53:54 --> Input Class Initialized
INFO - 2018-02-14 15:53:54 --> Language Class Initialized
INFO - 2018-02-14 15:53:54 --> Loader Class Initialized
INFO - 2018-02-14 15:53:54 --> Helper loaded: url_helper
INFO - 2018-02-14 15:53:54 --> Helper loaded: file_helper
INFO - 2018-02-14 15:53:54 --> Helper loaded: email_helper
INFO - 2018-02-14 15:53:54 --> Helper loaded: common_helper
INFO - 2018-02-14 15:53:54 --> Database Driver Class Initialized
DEBUG - 2018-02-14 15:53:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 15:53:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 15:53:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-14 15:53:54 --> Pagination Class Initialized
INFO - 2018-02-14 15:53:54 --> Helper loaded: form_helper
INFO - 2018-02-14 15:53:54 --> Form Validation Class Initialized
INFO - 2018-02-14 15:53:54 --> Model Class Initialized
INFO - 2018-02-14 15:53:54 --> Controller Class Initialized
INFO - 2018-02-14 15:53:54 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-14 15:53:54 --> Model Class Initialized
ERROR - 2018-02-14 15:53:54 --> Query error: Unknown column 'success' in 'field list' - Invalid query: UPDATE `Category` SET `success` = 1
WHERE `iCategoryId` = '3'
INFO - 2018-02-14 15:53:54 --> Language file loaded: language/english/db_lang.php
INFO - 2018-02-14 15:54:02 --> Config Class Initialized
INFO - 2018-02-14 15:54:02 --> Hooks Class Initialized
DEBUG - 2018-02-14 15:54:02 --> UTF-8 Support Enabled
INFO - 2018-02-14 15:54:02 --> Utf8 Class Initialized
INFO - 2018-02-14 15:54:02 --> URI Class Initialized
INFO - 2018-02-14 15:54:02 --> Router Class Initialized
INFO - 2018-02-14 15:54:02 --> Output Class Initialized
INFO - 2018-02-14 15:54:02 --> Security Class Initialized
DEBUG - 2018-02-14 15:54:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 15:54:02 --> Input Class Initialized
INFO - 2018-02-14 15:54:02 --> Language Class Initialized
INFO - 2018-02-14 15:54:02 --> Loader Class Initialized
INFO - 2018-02-14 15:54:02 --> Helper loaded: url_helper
INFO - 2018-02-14 15:54:02 --> Helper loaded: file_helper
INFO - 2018-02-14 15:54:02 --> Helper loaded: email_helper
INFO - 2018-02-14 15:54:02 --> Helper loaded: common_helper
INFO - 2018-02-14 15:54:02 --> Database Driver Class Initialized
DEBUG - 2018-02-14 15:54:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 15:54:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 15:54:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-14 15:54:02 --> Pagination Class Initialized
INFO - 2018-02-14 15:54:02 --> Helper loaded: form_helper
INFO - 2018-02-14 15:54:02 --> Form Validation Class Initialized
INFO - 2018-02-14 15:54:02 --> Model Class Initialized
INFO - 2018-02-14 15:54:02 --> Controller Class Initialized
INFO - 2018-02-14 15:54:02 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-14 15:54:02 --> Model Class Initialized
INFO - 2018-02-14 15:54:02 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-14 15:54:02 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-14 15:54:02 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-14 15:54:02 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-14 15:54:02 --> File loaded: /var/www/html/project/radio/application/views/category/index.php
INFO - 2018-02-14 15:54:02 --> Final output sent to browser
DEBUG - 2018-02-14 15:54:02 --> Total execution time: 0.0079
INFO - 2018-02-14 15:54:33 --> Config Class Initialized
INFO - 2018-02-14 15:54:33 --> Hooks Class Initialized
DEBUG - 2018-02-14 15:54:33 --> UTF-8 Support Enabled
INFO - 2018-02-14 15:54:33 --> Utf8 Class Initialized
INFO - 2018-02-14 15:54:33 --> URI Class Initialized
INFO - 2018-02-14 15:54:33 --> Router Class Initialized
INFO - 2018-02-14 15:54:33 --> Output Class Initialized
INFO - 2018-02-14 15:54:33 --> Security Class Initialized
DEBUG - 2018-02-14 15:54:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 15:54:33 --> Input Class Initialized
INFO - 2018-02-14 15:54:33 --> Language Class Initialized
INFO - 2018-02-14 15:54:33 --> Loader Class Initialized
INFO - 2018-02-14 15:54:33 --> Helper loaded: url_helper
INFO - 2018-02-14 15:54:33 --> Helper loaded: file_helper
INFO - 2018-02-14 15:54:33 --> Helper loaded: email_helper
INFO - 2018-02-14 15:54:33 --> Helper loaded: common_helper
INFO - 2018-02-14 15:54:33 --> Database Driver Class Initialized
DEBUG - 2018-02-14 15:54:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 15:54:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 15:54:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-14 15:54:33 --> Pagination Class Initialized
INFO - 2018-02-14 15:54:33 --> Helper loaded: form_helper
INFO - 2018-02-14 15:54:33 --> Form Validation Class Initialized
INFO - 2018-02-14 15:54:33 --> Model Class Initialized
INFO - 2018-02-14 15:54:33 --> Controller Class Initialized
INFO - 2018-02-14 15:54:33 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-14 15:54:33 --> Model Class Initialized
INFO - 2018-02-14 15:55:09 --> Config Class Initialized
INFO - 2018-02-14 15:55:09 --> Hooks Class Initialized
DEBUG - 2018-02-14 15:55:09 --> UTF-8 Support Enabled
INFO - 2018-02-14 15:55:09 --> Utf8 Class Initialized
INFO - 2018-02-14 15:55:09 --> URI Class Initialized
INFO - 2018-02-14 15:55:09 --> Router Class Initialized
INFO - 2018-02-14 15:55:09 --> Output Class Initialized
INFO - 2018-02-14 15:55:09 --> Security Class Initialized
DEBUG - 2018-02-14 15:55:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 15:55:09 --> Input Class Initialized
INFO - 2018-02-14 15:55:09 --> Language Class Initialized
INFO - 2018-02-14 15:55:09 --> Loader Class Initialized
INFO - 2018-02-14 15:55:09 --> Helper loaded: url_helper
INFO - 2018-02-14 15:55:09 --> Helper loaded: file_helper
INFO - 2018-02-14 15:55:09 --> Helper loaded: email_helper
INFO - 2018-02-14 15:55:09 --> Helper loaded: common_helper
INFO - 2018-02-14 15:55:09 --> Database Driver Class Initialized
DEBUG - 2018-02-14 15:55:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 15:55:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 15:55:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-14 15:55:09 --> Pagination Class Initialized
INFO - 2018-02-14 15:55:09 --> Helper loaded: form_helper
INFO - 2018-02-14 15:55:09 --> Form Validation Class Initialized
INFO - 2018-02-14 15:55:09 --> Model Class Initialized
INFO - 2018-02-14 15:55:09 --> Controller Class Initialized
INFO - 2018-02-14 15:55:09 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-14 15:55:09 --> Model Class Initialized
INFO - 2018-02-14 15:55:09 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-14 15:55:09 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-14 15:55:09 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-14 15:55:09 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-14 15:55:09 --> File loaded: /var/www/html/project/radio/application/views/category/index.php
INFO - 2018-02-14 15:55:09 --> Final output sent to browser
DEBUG - 2018-02-14 15:55:09 --> Total execution time: 0.0106
INFO - 2018-02-14 15:55:12 --> Config Class Initialized
INFO - 2018-02-14 15:55:12 --> Hooks Class Initialized
DEBUG - 2018-02-14 15:55:12 --> UTF-8 Support Enabled
INFO - 2018-02-14 15:55:12 --> Utf8 Class Initialized
INFO - 2018-02-14 15:55:12 --> URI Class Initialized
INFO - 2018-02-14 15:55:12 --> Router Class Initialized
INFO - 2018-02-14 15:55:12 --> Output Class Initialized
INFO - 2018-02-14 15:55:12 --> Security Class Initialized
DEBUG - 2018-02-14 15:55:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 15:55:12 --> Input Class Initialized
INFO - 2018-02-14 15:55:12 --> Language Class Initialized
INFO - 2018-02-14 15:55:12 --> Loader Class Initialized
INFO - 2018-02-14 15:55:12 --> Helper loaded: url_helper
INFO - 2018-02-14 15:55:12 --> Helper loaded: file_helper
INFO - 2018-02-14 15:55:12 --> Helper loaded: email_helper
INFO - 2018-02-14 15:55:12 --> Helper loaded: common_helper
INFO - 2018-02-14 15:55:12 --> Database Driver Class Initialized
DEBUG - 2018-02-14 15:55:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 15:55:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 15:55:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-14 15:55:12 --> Pagination Class Initialized
INFO - 2018-02-14 15:55:12 --> Helper loaded: form_helper
INFO - 2018-02-14 15:55:12 --> Form Validation Class Initialized
INFO - 2018-02-14 15:55:12 --> Model Class Initialized
INFO - 2018-02-14 15:55:12 --> Controller Class Initialized
INFO - 2018-02-14 15:55:12 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-14 15:55:12 --> Model Class Initialized
INFO - 2018-02-14 15:55:12 --> Config Class Initialized
INFO - 2018-02-14 15:55:12 --> Hooks Class Initialized
DEBUG - 2018-02-14 15:55:12 --> UTF-8 Support Enabled
INFO - 2018-02-14 15:55:12 --> Utf8 Class Initialized
INFO - 2018-02-14 15:55:12 --> URI Class Initialized
INFO - 2018-02-14 15:55:12 --> Router Class Initialized
INFO - 2018-02-14 15:55:12 --> Output Class Initialized
INFO - 2018-02-14 15:55:12 --> Security Class Initialized
DEBUG - 2018-02-14 15:55:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 15:55:12 --> Input Class Initialized
INFO - 2018-02-14 15:55:12 --> Language Class Initialized
INFO - 2018-02-14 15:55:12 --> Loader Class Initialized
INFO - 2018-02-14 15:55:12 --> Helper loaded: url_helper
INFO - 2018-02-14 15:55:12 --> Helper loaded: file_helper
INFO - 2018-02-14 15:55:12 --> Helper loaded: email_helper
INFO - 2018-02-14 15:55:12 --> Helper loaded: common_helper
INFO - 2018-02-14 15:55:12 --> Database Driver Class Initialized
DEBUG - 2018-02-14 15:55:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 15:55:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 15:55:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-14 15:55:12 --> Pagination Class Initialized
INFO - 2018-02-14 15:55:12 --> Helper loaded: form_helper
INFO - 2018-02-14 15:55:12 --> Form Validation Class Initialized
INFO - 2018-02-14 15:55:12 --> Model Class Initialized
INFO - 2018-02-14 15:55:12 --> Controller Class Initialized
INFO - 2018-02-14 15:55:12 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-14 15:55:12 --> Model Class Initialized
INFO - 2018-02-14 15:55:12 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-14 15:55:12 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-14 15:55:12 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-14 15:55:12 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-14 15:55:12 --> File loaded: /var/www/html/project/radio/application/views/category/index.php
INFO - 2018-02-14 15:55:12 --> Final output sent to browser
DEBUG - 2018-02-14 15:55:12 --> Total execution time: 0.0062
INFO - 2018-02-14 15:55:26 --> Config Class Initialized
INFO - 2018-02-14 15:55:26 --> Hooks Class Initialized
DEBUG - 2018-02-14 15:55:26 --> UTF-8 Support Enabled
INFO - 2018-02-14 15:55:26 --> Utf8 Class Initialized
INFO - 2018-02-14 15:55:26 --> URI Class Initialized
INFO - 2018-02-14 15:55:26 --> Router Class Initialized
INFO - 2018-02-14 15:55:26 --> Output Class Initialized
INFO - 2018-02-14 15:55:26 --> Security Class Initialized
DEBUG - 2018-02-14 15:55:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 15:55:26 --> Input Class Initialized
INFO - 2018-02-14 15:55:26 --> Language Class Initialized
INFO - 2018-02-14 15:55:26 --> Loader Class Initialized
INFO - 2018-02-14 15:55:26 --> Helper loaded: url_helper
INFO - 2018-02-14 15:55:26 --> Helper loaded: file_helper
INFO - 2018-02-14 15:55:26 --> Helper loaded: email_helper
INFO - 2018-02-14 15:55:26 --> Helper loaded: common_helper
INFO - 2018-02-14 15:55:26 --> Database Driver Class Initialized
DEBUG - 2018-02-14 15:55:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 15:55:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 15:55:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-14 15:55:26 --> Pagination Class Initialized
INFO - 2018-02-14 15:55:26 --> Helper loaded: form_helper
INFO - 2018-02-14 15:55:26 --> Form Validation Class Initialized
INFO - 2018-02-14 15:55:26 --> Model Class Initialized
INFO - 2018-02-14 15:55:26 --> Controller Class Initialized
INFO - 2018-02-14 15:55:26 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-14 15:55:26 --> Model Class Initialized
INFO - 2018-02-14 15:55:26 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-14 15:55:26 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-14 15:55:26 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-14 15:55:26 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-14 15:55:26 --> File loaded: /var/www/html/project/radio/application/views/category/index.php
INFO - 2018-02-14 15:55:26 --> Final output sent to browser
DEBUG - 2018-02-14 15:55:26 --> Total execution time: 0.0057
INFO - 2018-02-14 16:20:44 --> Config Class Initialized
INFO - 2018-02-14 16:20:44 --> Hooks Class Initialized
DEBUG - 2018-02-14 16:20:44 --> UTF-8 Support Enabled
INFO - 2018-02-14 16:20:44 --> Utf8 Class Initialized
INFO - 2018-02-14 16:20:44 --> URI Class Initialized
DEBUG - 2018-02-14 16:20:44 --> No URI present. Default controller set.
INFO - 2018-02-14 16:20:44 --> Router Class Initialized
INFO - 2018-02-14 16:20:44 --> Output Class Initialized
INFO - 2018-02-14 16:20:44 --> Security Class Initialized
DEBUG - 2018-02-14 16:20:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 16:20:44 --> Input Class Initialized
INFO - 2018-02-14 16:20:44 --> Language Class Initialized
INFO - 2018-02-14 16:20:44 --> Loader Class Initialized
INFO - 2018-02-14 16:20:44 --> Helper loaded: url_helper
INFO - 2018-02-14 16:20:44 --> Helper loaded: file_helper
INFO - 2018-02-14 16:20:44 --> Helper loaded: email_helper
INFO - 2018-02-14 16:20:44 --> Helper loaded: common_helper
INFO - 2018-02-14 16:20:44 --> Database Driver Class Initialized
DEBUG - 2018-02-14 16:20:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 16:20:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 16:20:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-14 16:20:44 --> Pagination Class Initialized
INFO - 2018-02-14 16:20:44 --> Helper loaded: form_helper
INFO - 2018-02-14 16:20:44 --> Form Validation Class Initialized
INFO - 2018-02-14 16:20:44 --> Model Class Initialized
INFO - 2018-02-14 16:20:44 --> Controller Class Initialized
INFO - 2018-02-14 16:20:44 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-14 16:20:44 --> Model Class Initialized
INFO - 2018-02-14 16:20:44 --> Config Class Initialized
INFO - 2018-02-14 16:20:44 --> Hooks Class Initialized
DEBUG - 2018-02-14 16:20:44 --> UTF-8 Support Enabled
INFO - 2018-02-14 16:20:44 --> Utf8 Class Initialized
INFO - 2018-02-14 16:20:44 --> URI Class Initialized
INFO - 2018-02-14 16:20:44 --> Router Class Initialized
INFO - 2018-02-14 16:20:44 --> Output Class Initialized
INFO - 2018-02-14 16:20:44 --> Security Class Initialized
DEBUG - 2018-02-14 16:20:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 16:20:44 --> Input Class Initialized
INFO - 2018-02-14 16:20:44 --> Language Class Initialized
INFO - 2018-02-14 16:20:44 --> Loader Class Initialized
INFO - 2018-02-14 16:20:44 --> Helper loaded: url_helper
INFO - 2018-02-14 16:20:44 --> Helper loaded: file_helper
INFO - 2018-02-14 16:20:44 --> Helper loaded: email_helper
INFO - 2018-02-14 16:20:44 --> Helper loaded: common_helper
INFO - 2018-02-14 16:20:44 --> Database Driver Class Initialized
DEBUG - 2018-02-14 16:20:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 16:20:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 16:20:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-14 16:20:44 --> Pagination Class Initialized
INFO - 2018-02-14 16:20:44 --> Helper loaded: form_helper
INFO - 2018-02-14 16:20:44 --> Form Validation Class Initialized
INFO - 2018-02-14 16:20:44 --> Model Class Initialized
INFO - 2018-02-14 16:20:44 --> Controller Class Initialized
INFO - 2018-02-14 16:20:44 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-14 16:20:44 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-14 16:20:44 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-14 16:20:44 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-14 16:20:44 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-14 16:20:44 --> File loaded: /var/www/html/project/radio/application/views/dashboard/index.php
INFO - 2018-02-14 16:20:44 --> Final output sent to browser
DEBUG - 2018-02-14 16:20:44 --> Total execution time: 0.0623
INFO - 2018-02-14 16:20:46 --> Config Class Initialized
INFO - 2018-02-14 16:20:46 --> Hooks Class Initialized
DEBUG - 2018-02-14 16:20:46 --> UTF-8 Support Enabled
INFO - 2018-02-14 16:20:46 --> Utf8 Class Initialized
INFO - 2018-02-14 16:20:46 --> URI Class Initialized
INFO - 2018-02-14 16:20:46 --> Router Class Initialized
INFO - 2018-02-14 16:20:46 --> Output Class Initialized
INFO - 2018-02-14 16:20:46 --> Security Class Initialized
DEBUG - 2018-02-14 16:20:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 16:20:46 --> Input Class Initialized
INFO - 2018-02-14 16:20:46 --> Language Class Initialized
INFO - 2018-02-14 16:20:46 --> Loader Class Initialized
INFO - 2018-02-14 16:20:46 --> Helper loaded: url_helper
INFO - 2018-02-14 16:20:46 --> Helper loaded: file_helper
INFO - 2018-02-14 16:20:46 --> Helper loaded: email_helper
INFO - 2018-02-14 16:20:46 --> Helper loaded: common_helper
INFO - 2018-02-14 16:20:46 --> Database Driver Class Initialized
DEBUG - 2018-02-14 16:20:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 16:20:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 16:20:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-14 16:20:46 --> Pagination Class Initialized
INFO - 2018-02-14 16:20:46 --> Helper loaded: form_helper
INFO - 2018-02-14 16:20:46 --> Form Validation Class Initialized
INFO - 2018-02-14 16:20:46 --> Model Class Initialized
INFO - 2018-02-14 16:20:46 --> Controller Class Initialized
INFO - 2018-02-14 16:20:46 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-14 16:20:46 --> Model Class Initialized
INFO - 2018-02-14 16:20:46 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-14 16:20:46 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-14 16:20:46 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-14 16:20:46 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-14 16:20:46 --> File loaded: /var/www/html/project/radio/application/views/category/index.php
INFO - 2018-02-14 16:20:46 --> Final output sent to browser
DEBUG - 2018-02-14 16:20:46 --> Total execution time: 0.0072
INFO - 2018-02-14 16:20:47 --> Config Class Initialized
INFO - 2018-02-14 16:20:47 --> Hooks Class Initialized
DEBUG - 2018-02-14 16:20:47 --> UTF-8 Support Enabled
INFO - 2018-02-14 16:20:47 --> Utf8 Class Initialized
INFO - 2018-02-14 16:20:47 --> URI Class Initialized
INFO - 2018-02-14 16:20:47 --> Router Class Initialized
INFO - 2018-02-14 16:20:47 --> Output Class Initialized
INFO - 2018-02-14 16:20:47 --> Security Class Initialized
DEBUG - 2018-02-14 16:20:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 16:20:47 --> Input Class Initialized
INFO - 2018-02-14 16:20:47 --> Language Class Initialized
INFO - 2018-02-14 16:20:47 --> Loader Class Initialized
INFO - 2018-02-14 16:20:47 --> Helper loaded: url_helper
INFO - 2018-02-14 16:20:47 --> Helper loaded: file_helper
INFO - 2018-02-14 16:20:47 --> Helper loaded: email_helper
INFO - 2018-02-14 16:20:47 --> Helper loaded: common_helper
INFO - 2018-02-14 16:20:47 --> Database Driver Class Initialized
DEBUG - 2018-02-14 16:20:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 16:20:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 16:20:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-14 16:20:47 --> Pagination Class Initialized
INFO - 2018-02-14 16:20:47 --> Helper loaded: form_helper
INFO - 2018-02-14 16:20:47 --> Form Validation Class Initialized
INFO - 2018-02-14 16:20:47 --> Model Class Initialized
INFO - 2018-02-14 16:20:47 --> Controller Class Initialized
INFO - 2018-02-14 16:20:47 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-14 16:20:47 --> Model Class Initialized
INFO - 2018-02-14 16:20:47 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-14 16:20:47 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-14 16:20:47 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-14 16:20:47 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-14 16:20:47 --> File loaded: /var/www/html/project/radio/application/views/category/index.php
INFO - 2018-02-14 16:20:47 --> Final output sent to browser
DEBUG - 2018-02-14 16:20:47 --> Total execution time: 0.0041
INFO - 2018-02-14 16:20:48 --> Config Class Initialized
INFO - 2018-02-14 16:20:48 --> Hooks Class Initialized
DEBUG - 2018-02-14 16:20:48 --> UTF-8 Support Enabled
INFO - 2018-02-14 16:20:48 --> Utf8 Class Initialized
INFO - 2018-02-14 16:20:48 --> URI Class Initialized
INFO - 2018-02-14 16:20:48 --> Router Class Initialized
INFO - 2018-02-14 16:20:48 --> Output Class Initialized
INFO - 2018-02-14 16:20:48 --> Security Class Initialized
DEBUG - 2018-02-14 16:20:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 16:20:48 --> Input Class Initialized
INFO - 2018-02-14 16:20:48 --> Language Class Initialized
INFO - 2018-02-14 16:20:48 --> Loader Class Initialized
INFO - 2018-02-14 16:20:48 --> Helper loaded: url_helper
INFO - 2018-02-14 16:20:48 --> Helper loaded: file_helper
INFO - 2018-02-14 16:20:48 --> Helper loaded: email_helper
INFO - 2018-02-14 16:20:48 --> Helper loaded: common_helper
INFO - 2018-02-14 16:20:48 --> Database Driver Class Initialized
DEBUG - 2018-02-14 16:20:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 16:20:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 16:20:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-14 16:20:48 --> Pagination Class Initialized
INFO - 2018-02-14 16:20:48 --> Helper loaded: form_helper
INFO - 2018-02-14 16:20:48 --> Form Validation Class Initialized
INFO - 2018-02-14 16:20:48 --> Model Class Initialized
INFO - 2018-02-14 16:20:48 --> Controller Class Initialized
INFO - 2018-02-14 16:20:48 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-14 16:20:48 --> Model Class Initialized
INFO - 2018-02-14 16:20:48 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-14 16:20:48 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-14 16:20:48 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-14 16:20:48 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-14 16:20:48 --> File loaded: /var/www/html/project/radio/application/views/category/add_edit.php
INFO - 2018-02-14 16:20:48 --> Final output sent to browser
DEBUG - 2018-02-14 16:20:48 --> Total execution time: 0.0047
INFO - 2018-02-14 16:20:51 --> Config Class Initialized
INFO - 2018-02-14 16:20:51 --> Hooks Class Initialized
DEBUG - 2018-02-14 16:20:51 --> UTF-8 Support Enabled
INFO - 2018-02-14 16:20:51 --> Utf8 Class Initialized
INFO - 2018-02-14 16:20:51 --> URI Class Initialized
INFO - 2018-02-14 16:20:51 --> Router Class Initialized
INFO - 2018-02-14 16:20:51 --> Output Class Initialized
INFO - 2018-02-14 16:20:51 --> Security Class Initialized
DEBUG - 2018-02-14 16:20:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 16:20:51 --> Input Class Initialized
INFO - 2018-02-14 16:20:51 --> Language Class Initialized
ERROR - 2018-02-14 16:20:51 --> 404 Page Not Found: Category/category
INFO - 2018-02-14 16:20:54 --> Config Class Initialized
INFO - 2018-02-14 16:20:54 --> Hooks Class Initialized
DEBUG - 2018-02-14 16:20:54 --> UTF-8 Support Enabled
INFO - 2018-02-14 16:20:54 --> Utf8 Class Initialized
INFO - 2018-02-14 16:20:54 --> URI Class Initialized
INFO - 2018-02-14 16:20:54 --> Router Class Initialized
INFO - 2018-02-14 16:20:54 --> Output Class Initialized
INFO - 2018-02-14 16:20:54 --> Security Class Initialized
DEBUG - 2018-02-14 16:20:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 16:20:54 --> Input Class Initialized
INFO - 2018-02-14 16:20:54 --> Language Class Initialized
INFO - 2018-02-14 16:20:54 --> Loader Class Initialized
INFO - 2018-02-14 16:20:54 --> Helper loaded: url_helper
INFO - 2018-02-14 16:20:54 --> Helper loaded: file_helper
INFO - 2018-02-14 16:20:54 --> Helper loaded: email_helper
INFO - 2018-02-14 16:20:54 --> Helper loaded: common_helper
INFO - 2018-02-14 16:20:54 --> Database Driver Class Initialized
DEBUG - 2018-02-14 16:20:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 16:20:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 16:20:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-14 16:20:54 --> Pagination Class Initialized
INFO - 2018-02-14 16:20:54 --> Helper loaded: form_helper
INFO - 2018-02-14 16:20:54 --> Form Validation Class Initialized
INFO - 2018-02-14 16:20:54 --> Model Class Initialized
INFO - 2018-02-14 16:20:54 --> Controller Class Initialized
INFO - 2018-02-14 16:20:54 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-14 16:20:54 --> Model Class Initialized
INFO - 2018-02-14 16:20:54 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-14 16:20:54 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-14 16:20:54 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-14 16:20:54 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-14 16:20:54 --> File loaded: /var/www/html/project/radio/application/views/category/add_edit.php
INFO - 2018-02-14 16:20:54 --> Final output sent to browser
DEBUG - 2018-02-14 16:20:54 --> Total execution time: 0.0057
INFO - 2018-02-14 16:24:38 --> Config Class Initialized
INFO - 2018-02-14 16:24:38 --> Hooks Class Initialized
DEBUG - 2018-02-14 16:24:38 --> UTF-8 Support Enabled
INFO - 2018-02-14 16:24:38 --> Utf8 Class Initialized
INFO - 2018-02-14 16:24:38 --> URI Class Initialized
INFO - 2018-02-14 16:24:38 --> Router Class Initialized
INFO - 2018-02-14 16:24:38 --> Output Class Initialized
INFO - 2018-02-14 16:24:38 --> Security Class Initialized
DEBUG - 2018-02-14 16:24:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 16:24:38 --> Input Class Initialized
INFO - 2018-02-14 16:24:38 --> Language Class Initialized
INFO - 2018-02-14 16:24:38 --> Loader Class Initialized
INFO - 2018-02-14 16:24:38 --> Helper loaded: url_helper
INFO - 2018-02-14 16:24:38 --> Helper loaded: file_helper
INFO - 2018-02-14 16:24:38 --> Helper loaded: email_helper
INFO - 2018-02-14 16:24:38 --> Helper loaded: common_helper
INFO - 2018-02-14 16:24:38 --> Database Driver Class Initialized
DEBUG - 2018-02-14 16:24:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 16:24:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 16:24:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-14 16:24:38 --> Pagination Class Initialized
INFO - 2018-02-14 16:24:38 --> Helper loaded: form_helper
INFO - 2018-02-14 16:24:38 --> Form Validation Class Initialized
INFO - 2018-02-14 16:24:38 --> Model Class Initialized
INFO - 2018-02-14 16:24:38 --> Controller Class Initialized
INFO - 2018-02-14 16:24:38 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-14 16:24:38 --> Model Class Initialized
INFO - 2018-02-14 16:24:38 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-14 16:24:38 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-14 16:24:38 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-14 16:24:38 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-14 16:24:38 --> File loaded: /var/www/html/project/radio/application/views/category/add_edit.php
INFO - 2018-02-14 16:24:38 --> Final output sent to browser
DEBUG - 2018-02-14 16:24:38 --> Total execution time: 0.0051
INFO - 2018-02-14 16:24:40 --> Config Class Initialized
INFO - 2018-02-14 16:24:40 --> Hooks Class Initialized
DEBUG - 2018-02-14 16:24:40 --> UTF-8 Support Enabled
INFO - 2018-02-14 16:24:40 --> Utf8 Class Initialized
INFO - 2018-02-14 16:24:40 --> URI Class Initialized
INFO - 2018-02-14 16:24:40 --> Router Class Initialized
INFO - 2018-02-14 16:24:40 --> Output Class Initialized
INFO - 2018-02-14 16:24:40 --> Security Class Initialized
DEBUG - 2018-02-14 16:24:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 16:24:40 --> Input Class Initialized
INFO - 2018-02-14 16:24:40 --> Language Class Initialized
INFO - 2018-02-14 16:24:40 --> Loader Class Initialized
INFO - 2018-02-14 16:24:40 --> Helper loaded: url_helper
INFO - 2018-02-14 16:24:40 --> Helper loaded: file_helper
INFO - 2018-02-14 16:24:40 --> Helper loaded: email_helper
INFO - 2018-02-14 16:24:40 --> Helper loaded: common_helper
INFO - 2018-02-14 16:24:40 --> Database Driver Class Initialized
DEBUG - 2018-02-14 16:24:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 16:24:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 16:24:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-14 16:24:40 --> Pagination Class Initialized
INFO - 2018-02-14 16:24:40 --> Helper loaded: form_helper
INFO - 2018-02-14 16:24:40 --> Form Validation Class Initialized
INFO - 2018-02-14 16:24:40 --> Model Class Initialized
INFO - 2018-02-14 16:24:40 --> Controller Class Initialized
INFO - 2018-02-14 16:24:40 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-14 16:24:40 --> Model Class Initialized
INFO - 2018-02-14 16:24:40 --> Config Class Initialized
INFO - 2018-02-14 16:24:40 --> Hooks Class Initialized
DEBUG - 2018-02-14 16:24:40 --> UTF-8 Support Enabled
INFO - 2018-02-14 16:24:40 --> Utf8 Class Initialized
INFO - 2018-02-14 16:24:40 --> URI Class Initialized
INFO - 2018-02-14 16:24:40 --> Router Class Initialized
INFO - 2018-02-14 16:24:40 --> Output Class Initialized
INFO - 2018-02-14 16:24:40 --> Security Class Initialized
DEBUG - 2018-02-14 16:24:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 16:24:40 --> Input Class Initialized
INFO - 2018-02-14 16:24:40 --> Language Class Initialized
INFO - 2018-02-14 16:24:40 --> Loader Class Initialized
INFO - 2018-02-14 16:24:40 --> Helper loaded: url_helper
INFO - 2018-02-14 16:24:40 --> Helper loaded: file_helper
INFO - 2018-02-14 16:24:40 --> Helper loaded: email_helper
INFO - 2018-02-14 16:24:40 --> Helper loaded: common_helper
INFO - 2018-02-14 16:24:40 --> Database Driver Class Initialized
DEBUG - 2018-02-14 16:24:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 16:24:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 16:24:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-14 16:24:40 --> Pagination Class Initialized
INFO - 2018-02-14 16:24:40 --> Helper loaded: form_helper
INFO - 2018-02-14 16:24:40 --> Form Validation Class Initialized
INFO - 2018-02-14 16:24:40 --> Model Class Initialized
INFO - 2018-02-14 16:24:40 --> Controller Class Initialized
INFO - 2018-02-14 16:24:40 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-14 16:24:40 --> Model Class Initialized
INFO - 2018-02-14 16:24:40 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-14 16:24:40 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-14 16:24:40 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-14 16:24:40 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-14 16:24:40 --> File loaded: /var/www/html/project/radio/application/views/category/index.php
INFO - 2018-02-14 16:24:40 --> Final output sent to browser
DEBUG - 2018-02-14 16:24:40 --> Total execution time: 0.0057
INFO - 2018-02-14 16:37:58 --> Config Class Initialized
INFO - 2018-02-14 16:37:58 --> Hooks Class Initialized
DEBUG - 2018-02-14 16:37:58 --> UTF-8 Support Enabled
INFO - 2018-02-14 16:37:58 --> Utf8 Class Initialized
INFO - 2018-02-14 16:37:58 --> URI Class Initialized
INFO - 2018-02-14 16:37:58 --> Router Class Initialized
INFO - 2018-02-14 16:37:58 --> Output Class Initialized
INFO - 2018-02-14 16:37:58 --> Security Class Initialized
DEBUG - 2018-02-14 16:37:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 16:37:58 --> Input Class Initialized
INFO - 2018-02-14 16:37:58 --> Language Class Initialized
INFO - 2018-02-14 16:37:58 --> Loader Class Initialized
INFO - 2018-02-14 16:37:58 --> Helper loaded: url_helper
INFO - 2018-02-14 16:37:58 --> Helper loaded: file_helper
INFO - 2018-02-14 16:37:58 --> Helper loaded: email_helper
INFO - 2018-02-14 16:37:58 --> Helper loaded: common_helper
INFO - 2018-02-14 16:37:58 --> Database Driver Class Initialized
DEBUG - 2018-02-14 16:37:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 16:37:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 16:37:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-14 16:37:58 --> Pagination Class Initialized
INFO - 2018-02-14 16:37:58 --> Helper loaded: form_helper
INFO - 2018-02-14 16:37:58 --> Form Validation Class Initialized
INFO - 2018-02-14 16:37:58 --> Model Class Initialized
INFO - 2018-02-14 16:37:58 --> Controller Class Initialized
INFO - 2018-02-14 16:37:58 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-14 16:37:58 --> Model Class Initialized
INFO - 2018-02-14 16:37:58 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-14 16:37:58 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-14 16:37:58 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-14 16:37:58 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-14 16:37:58 --> File loaded: /var/www/html/project/radio/application/views/category/index.php
INFO - 2018-02-14 16:37:58 --> Final output sent to browser
DEBUG - 2018-02-14 16:37:58 --> Total execution time: 0.0076
INFO - 2018-02-14 16:38:00 --> Config Class Initialized
INFO - 2018-02-14 16:38:00 --> Hooks Class Initialized
DEBUG - 2018-02-14 16:38:00 --> UTF-8 Support Enabled
INFO - 2018-02-14 16:38:00 --> Utf8 Class Initialized
INFO - 2018-02-14 16:38:00 --> URI Class Initialized
INFO - 2018-02-14 16:38:00 --> Router Class Initialized
INFO - 2018-02-14 16:38:00 --> Output Class Initialized
INFO - 2018-02-14 16:38:00 --> Security Class Initialized
DEBUG - 2018-02-14 16:38:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 16:38:00 --> Input Class Initialized
INFO - 2018-02-14 16:38:00 --> Language Class Initialized
INFO - 2018-02-14 16:38:00 --> Loader Class Initialized
INFO - 2018-02-14 16:38:00 --> Helper loaded: url_helper
INFO - 2018-02-14 16:38:00 --> Helper loaded: file_helper
INFO - 2018-02-14 16:38:00 --> Helper loaded: email_helper
INFO - 2018-02-14 16:38:00 --> Helper loaded: common_helper
INFO - 2018-02-14 16:38:00 --> Database Driver Class Initialized
DEBUG - 2018-02-14 16:38:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 16:38:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 16:38:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-14 16:38:00 --> Pagination Class Initialized
INFO - 2018-02-14 16:38:00 --> Helper loaded: form_helper
INFO - 2018-02-14 16:38:00 --> Form Validation Class Initialized
INFO - 2018-02-14 16:38:00 --> Model Class Initialized
INFO - 2018-02-14 16:38:00 --> Controller Class Initialized
INFO - 2018-02-14 16:38:00 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-14 16:38:00 --> Model Class Initialized
INFO - 2018-02-14 16:38:00 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-14 16:38:00 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-14 16:38:00 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-14 16:38:00 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-14 16:38:00 --> File loaded: /var/www/html/project/radio/application/views/subcategory/index.php
INFO - 2018-02-14 16:38:00 --> Final output sent to browser
DEBUG - 2018-02-14 16:38:00 --> Total execution time: 0.0180
INFO - 2018-02-14 16:53:44 --> Config Class Initialized
INFO - 2018-02-14 16:53:44 --> Hooks Class Initialized
DEBUG - 2018-02-14 16:53:44 --> UTF-8 Support Enabled
INFO - 2018-02-14 16:53:44 --> Utf8 Class Initialized
INFO - 2018-02-14 16:53:44 --> URI Class Initialized
INFO - 2018-02-14 16:53:44 --> Router Class Initialized
INFO - 2018-02-14 16:53:44 --> Output Class Initialized
INFO - 2018-02-14 16:53:44 --> Security Class Initialized
DEBUG - 2018-02-14 16:53:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 16:53:44 --> Input Class Initialized
INFO - 2018-02-14 16:53:44 --> Language Class Initialized
INFO - 2018-02-14 16:53:44 --> Loader Class Initialized
INFO - 2018-02-14 16:53:44 --> Helper loaded: url_helper
INFO - 2018-02-14 16:53:44 --> Helper loaded: file_helper
INFO - 2018-02-14 16:53:44 --> Helper loaded: email_helper
INFO - 2018-02-14 16:53:44 --> Helper loaded: common_helper
INFO - 2018-02-14 16:53:44 --> Database Driver Class Initialized
DEBUG - 2018-02-14 16:53:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 16:53:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 16:53:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-14 16:53:44 --> Pagination Class Initialized
INFO - 2018-02-14 16:53:44 --> Helper loaded: form_helper
INFO - 2018-02-14 16:53:44 --> Form Validation Class Initialized
INFO - 2018-02-14 16:53:44 --> Model Class Initialized
INFO - 2018-02-14 16:53:44 --> Controller Class Initialized
INFO - 2018-02-14 16:53:44 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-14 16:53:44 --> Model Class Initialized
INFO - 2018-02-14 16:53:44 --> Model Class Initialized
INFO - 2018-02-14 16:53:53 --> Config Class Initialized
INFO - 2018-02-14 16:53:53 --> Hooks Class Initialized
DEBUG - 2018-02-14 16:53:53 --> UTF-8 Support Enabled
INFO - 2018-02-14 16:53:53 --> Utf8 Class Initialized
INFO - 2018-02-14 16:53:53 --> URI Class Initialized
INFO - 2018-02-14 16:53:53 --> Router Class Initialized
INFO - 2018-02-14 16:53:53 --> Output Class Initialized
INFO - 2018-02-14 16:53:53 --> Security Class Initialized
DEBUG - 2018-02-14 16:53:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 16:53:53 --> Input Class Initialized
INFO - 2018-02-14 16:53:53 --> Language Class Initialized
INFO - 2018-02-14 16:53:53 --> Loader Class Initialized
INFO - 2018-02-14 16:53:53 --> Helper loaded: url_helper
INFO - 2018-02-14 16:53:53 --> Helper loaded: file_helper
INFO - 2018-02-14 16:53:53 --> Helper loaded: email_helper
INFO - 2018-02-14 16:53:53 --> Helper loaded: common_helper
INFO - 2018-02-14 16:53:53 --> Database Driver Class Initialized
DEBUG - 2018-02-14 16:53:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 16:53:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 16:53:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-14 16:53:53 --> Pagination Class Initialized
INFO - 2018-02-14 16:53:53 --> Helper loaded: form_helper
INFO - 2018-02-14 16:53:53 --> Form Validation Class Initialized
INFO - 2018-02-14 16:53:53 --> Model Class Initialized
INFO - 2018-02-14 16:53:53 --> Controller Class Initialized
INFO - 2018-02-14 16:53:53 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-14 16:53:53 --> Model Class Initialized
INFO - 2018-02-14 16:53:53 --> Model Class Initialized
ERROR - 2018-02-14 16:53:53 --> Severity: error --> Exception: Call to undefined method CI_DB_mysqli_result::pluck() /var/www/html/project/radio/application/models/Category_model.php 232
INFO - 2018-02-14 16:54:58 --> Config Class Initialized
INFO - 2018-02-14 16:54:58 --> Hooks Class Initialized
DEBUG - 2018-02-14 16:54:58 --> UTF-8 Support Enabled
INFO - 2018-02-14 16:54:58 --> Utf8 Class Initialized
INFO - 2018-02-14 16:54:58 --> URI Class Initialized
INFO - 2018-02-14 16:54:58 --> Router Class Initialized
INFO - 2018-02-14 16:54:58 --> Output Class Initialized
INFO - 2018-02-14 16:54:58 --> Security Class Initialized
DEBUG - 2018-02-14 16:54:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 16:54:58 --> Input Class Initialized
INFO - 2018-02-14 16:54:58 --> Language Class Initialized
INFO - 2018-02-14 16:54:58 --> Loader Class Initialized
INFO - 2018-02-14 16:54:58 --> Helper loaded: url_helper
INFO - 2018-02-14 16:54:58 --> Helper loaded: file_helper
INFO - 2018-02-14 16:54:58 --> Helper loaded: email_helper
INFO - 2018-02-14 16:54:58 --> Helper loaded: common_helper
INFO - 2018-02-14 16:54:58 --> Database Driver Class Initialized
DEBUG - 2018-02-14 16:54:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 16:54:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 16:54:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-14 16:54:58 --> Pagination Class Initialized
INFO - 2018-02-14 16:54:58 --> Helper loaded: form_helper
INFO - 2018-02-14 16:54:58 --> Form Validation Class Initialized
INFO - 2018-02-14 16:54:58 --> Model Class Initialized
INFO - 2018-02-14 16:54:58 --> Controller Class Initialized
INFO - 2018-02-14 16:54:58 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-14 16:54:58 --> Model Class Initialized
INFO - 2018-02-14 16:54:58 --> Model Class Initialized
ERROR - 2018-02-14 16:54:58 --> Severity: Warning --> Missing argument 1 for CI_DB_result::custom_result_object(), called in /var/www/html/project/radio/application/models/Category_model.php on line 232 and defined /var/www/html/project/radio/system/database/DB_result.php 180
ERROR - 2018-02-14 16:54:58 --> Severity: Notice --> Undefined variable: class_name /var/www/html/project/radio/system/database/DB_result.php 182
ERROR - 2018-02-14 16:54:58 --> Severity: Notice --> Undefined variable: class_name /var/www/html/project/radio/system/database/DB_result.php 218
ERROR - 2018-02-14 16:54:58 --> Severity: Notice --> Undefined variable: class_name /var/www/html/project/radio/system/database/DB_result.php 220
ERROR - 2018-02-14 16:54:58 --> Severity: Error --> Class '' not found /var/www/html/project/radio/system/database/drivers/mysqli/mysqli_result.php 237
INFO - 2018-02-14 16:55:06 --> Config Class Initialized
INFO - 2018-02-14 16:55:06 --> Hooks Class Initialized
DEBUG - 2018-02-14 16:55:06 --> UTF-8 Support Enabled
INFO - 2018-02-14 16:55:06 --> Utf8 Class Initialized
INFO - 2018-02-14 16:55:06 --> URI Class Initialized
INFO - 2018-02-14 16:55:06 --> Router Class Initialized
INFO - 2018-02-14 16:55:06 --> Output Class Initialized
INFO - 2018-02-14 16:55:06 --> Security Class Initialized
DEBUG - 2018-02-14 16:55:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 16:55:06 --> Input Class Initialized
INFO - 2018-02-14 16:55:06 --> Language Class Initialized
INFO - 2018-02-14 16:55:06 --> Loader Class Initialized
INFO - 2018-02-14 16:55:06 --> Helper loaded: url_helper
INFO - 2018-02-14 16:55:06 --> Helper loaded: file_helper
INFO - 2018-02-14 16:55:06 --> Helper loaded: email_helper
INFO - 2018-02-14 16:55:06 --> Helper loaded: common_helper
INFO - 2018-02-14 16:55:06 --> Database Driver Class Initialized
DEBUG - 2018-02-14 16:55:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 16:55:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 16:55:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-14 16:55:06 --> Pagination Class Initialized
INFO - 2018-02-14 16:55:06 --> Helper loaded: form_helper
INFO - 2018-02-14 16:55:06 --> Form Validation Class Initialized
INFO - 2018-02-14 16:55:06 --> Model Class Initialized
INFO - 2018-02-14 16:55:06 --> Controller Class Initialized
INFO - 2018-02-14 16:55:06 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-14 16:55:06 --> Model Class Initialized
INFO - 2018-02-14 16:55:06 --> Model Class Initialized
ERROR - 2018-02-14 16:55:06 --> Severity: Error --> Class 'Category' not found /var/www/html/project/radio/system/database/drivers/mysqli/mysqli_result.php 237
INFO - 2018-02-14 16:55:35 --> Config Class Initialized
INFO - 2018-02-14 16:55:35 --> Hooks Class Initialized
DEBUG - 2018-02-14 16:55:35 --> UTF-8 Support Enabled
INFO - 2018-02-14 16:55:35 --> Utf8 Class Initialized
INFO - 2018-02-14 16:55:35 --> URI Class Initialized
INFO - 2018-02-14 16:55:35 --> Router Class Initialized
INFO - 2018-02-14 16:55:35 --> Output Class Initialized
INFO - 2018-02-14 16:55:35 --> Security Class Initialized
DEBUG - 2018-02-14 16:55:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 16:55:35 --> Input Class Initialized
INFO - 2018-02-14 16:55:35 --> Language Class Initialized
INFO - 2018-02-14 16:55:35 --> Loader Class Initialized
INFO - 2018-02-14 16:55:35 --> Helper loaded: url_helper
INFO - 2018-02-14 16:55:35 --> Helper loaded: file_helper
INFO - 2018-02-14 16:55:35 --> Helper loaded: email_helper
INFO - 2018-02-14 16:55:35 --> Helper loaded: common_helper
INFO - 2018-02-14 16:55:35 --> Database Driver Class Initialized
DEBUG - 2018-02-14 16:55:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 16:55:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 16:55:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-14 16:55:35 --> Pagination Class Initialized
INFO - 2018-02-14 16:55:35 --> Helper loaded: form_helper
INFO - 2018-02-14 16:55:35 --> Form Validation Class Initialized
INFO - 2018-02-14 16:55:35 --> Model Class Initialized
INFO - 2018-02-14 16:55:35 --> Controller Class Initialized
INFO - 2018-02-14 16:55:35 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-14 16:55:35 --> Model Class Initialized
INFO - 2018-02-14 16:55:35 --> Model Class Initialized
ERROR - 2018-02-14 16:55:35 --> Severity: Error --> Class 'iCategoryId' not found /var/www/html/project/radio/system/database/drivers/mysqli/mysqli_result.php 237
INFO - 2018-02-14 16:55:38 --> Config Class Initialized
INFO - 2018-02-14 16:55:38 --> Hooks Class Initialized
DEBUG - 2018-02-14 16:55:38 --> UTF-8 Support Enabled
INFO - 2018-02-14 16:55:38 --> Utf8 Class Initialized
INFO - 2018-02-14 16:55:38 --> URI Class Initialized
INFO - 2018-02-14 16:55:38 --> Router Class Initialized
INFO - 2018-02-14 16:55:38 --> Output Class Initialized
INFO - 2018-02-14 16:55:38 --> Security Class Initialized
DEBUG - 2018-02-14 16:55:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 16:55:38 --> Input Class Initialized
INFO - 2018-02-14 16:55:38 --> Language Class Initialized
INFO - 2018-02-14 16:55:38 --> Loader Class Initialized
INFO - 2018-02-14 16:55:38 --> Helper loaded: url_helper
INFO - 2018-02-14 16:55:38 --> Helper loaded: file_helper
INFO - 2018-02-14 16:55:38 --> Helper loaded: email_helper
INFO - 2018-02-14 16:55:38 --> Helper loaded: common_helper
INFO - 2018-02-14 16:55:38 --> Database Driver Class Initialized
DEBUG - 2018-02-14 16:55:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 16:55:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 16:55:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-14 16:55:38 --> Pagination Class Initialized
INFO - 2018-02-14 16:55:38 --> Helper loaded: form_helper
INFO - 2018-02-14 16:55:38 --> Form Validation Class Initialized
INFO - 2018-02-14 16:55:38 --> Model Class Initialized
INFO - 2018-02-14 16:55:38 --> Controller Class Initialized
INFO - 2018-02-14 16:55:38 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-14 16:55:38 --> Model Class Initialized
INFO - 2018-02-14 16:55:38 --> Model Class Initialized
INFO - 2018-02-14 16:58:17 --> Config Class Initialized
INFO - 2018-02-14 16:58:17 --> Hooks Class Initialized
DEBUG - 2018-02-14 16:58:17 --> UTF-8 Support Enabled
INFO - 2018-02-14 16:58:17 --> Utf8 Class Initialized
INFO - 2018-02-14 16:58:17 --> URI Class Initialized
INFO - 2018-02-14 16:58:17 --> Router Class Initialized
INFO - 2018-02-14 16:58:17 --> Output Class Initialized
INFO - 2018-02-14 16:58:17 --> Security Class Initialized
DEBUG - 2018-02-14 16:58:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 16:58:17 --> Input Class Initialized
INFO - 2018-02-14 16:58:17 --> Language Class Initialized
INFO - 2018-02-14 16:58:17 --> Loader Class Initialized
INFO - 2018-02-14 16:58:17 --> Helper loaded: url_helper
INFO - 2018-02-14 16:58:17 --> Helper loaded: file_helper
INFO - 2018-02-14 16:58:17 --> Helper loaded: email_helper
INFO - 2018-02-14 16:58:17 --> Helper loaded: common_helper
INFO - 2018-02-14 16:58:17 --> Database Driver Class Initialized
DEBUG - 2018-02-14 16:58:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 16:58:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 16:58:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-14 16:58:17 --> Pagination Class Initialized
INFO - 2018-02-14 16:58:17 --> Helper loaded: form_helper
INFO - 2018-02-14 16:58:17 --> Form Validation Class Initialized
INFO - 2018-02-14 16:58:17 --> Model Class Initialized
INFO - 2018-02-14 16:58:17 --> Controller Class Initialized
INFO - 2018-02-14 16:58:17 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-14 16:58:17 --> Model Class Initialized
INFO - 2018-02-14 16:58:17 --> Model Class Initialized
INFO - 2018-02-14 16:58:22 --> Config Class Initialized
INFO - 2018-02-14 16:58:22 --> Hooks Class Initialized
DEBUG - 2018-02-14 16:58:22 --> UTF-8 Support Enabled
INFO - 2018-02-14 16:58:22 --> Utf8 Class Initialized
INFO - 2018-02-14 16:58:22 --> URI Class Initialized
INFO - 2018-02-14 16:58:22 --> Router Class Initialized
INFO - 2018-02-14 16:58:22 --> Output Class Initialized
INFO - 2018-02-14 16:58:22 --> Security Class Initialized
DEBUG - 2018-02-14 16:58:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 16:58:22 --> Input Class Initialized
INFO - 2018-02-14 16:58:22 --> Language Class Initialized
INFO - 2018-02-14 16:58:22 --> Loader Class Initialized
INFO - 2018-02-14 16:58:22 --> Helper loaded: url_helper
INFO - 2018-02-14 16:58:22 --> Helper loaded: file_helper
INFO - 2018-02-14 16:58:22 --> Helper loaded: email_helper
INFO - 2018-02-14 16:58:22 --> Helper loaded: common_helper
INFO - 2018-02-14 16:58:22 --> Database Driver Class Initialized
DEBUG - 2018-02-14 16:58:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 16:58:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 16:58:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-14 16:58:22 --> Pagination Class Initialized
INFO - 2018-02-14 16:58:22 --> Helper loaded: form_helper
INFO - 2018-02-14 16:58:22 --> Form Validation Class Initialized
INFO - 2018-02-14 16:58:22 --> Model Class Initialized
INFO - 2018-02-14 16:58:22 --> Controller Class Initialized
INFO - 2018-02-14 16:58:22 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-14 16:58:22 --> Model Class Initialized
INFO - 2018-02-14 16:58:22 --> Model Class Initialized
INFO - 2018-02-14 16:58:22 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-14 16:58:22 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-14 16:58:22 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-14 16:58:22 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-14 16:58:22 --> File loaded: /var/www/html/project/radio/application/views/category/add_edit.php
INFO - 2018-02-14 16:58:22 --> Final output sent to browser
DEBUG - 2018-02-14 16:58:22 --> Total execution time: 0.0079
INFO - 2018-02-14 16:58:53 --> Config Class Initialized
INFO - 2018-02-14 16:58:53 --> Hooks Class Initialized
DEBUG - 2018-02-14 16:58:53 --> UTF-8 Support Enabled
INFO - 2018-02-14 16:58:53 --> Utf8 Class Initialized
INFO - 2018-02-14 16:58:53 --> URI Class Initialized
INFO - 2018-02-14 16:58:53 --> Router Class Initialized
INFO - 2018-02-14 16:58:53 --> Output Class Initialized
INFO - 2018-02-14 16:58:53 --> Security Class Initialized
DEBUG - 2018-02-14 16:58:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 16:58:53 --> Input Class Initialized
INFO - 2018-02-14 16:58:53 --> Language Class Initialized
INFO - 2018-02-14 16:58:53 --> Loader Class Initialized
INFO - 2018-02-14 16:58:53 --> Helper loaded: url_helper
INFO - 2018-02-14 16:58:53 --> Helper loaded: file_helper
INFO - 2018-02-14 16:58:53 --> Helper loaded: email_helper
INFO - 2018-02-14 16:58:53 --> Helper loaded: common_helper
INFO - 2018-02-14 16:58:53 --> Database Driver Class Initialized
DEBUG - 2018-02-14 16:58:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 16:58:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 16:58:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-14 16:58:53 --> Pagination Class Initialized
INFO - 2018-02-14 16:58:53 --> Helper loaded: form_helper
INFO - 2018-02-14 16:58:53 --> Form Validation Class Initialized
INFO - 2018-02-14 16:58:53 --> Model Class Initialized
INFO - 2018-02-14 16:58:53 --> Controller Class Initialized
INFO - 2018-02-14 16:58:53 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-14 16:58:53 --> Model Class Initialized
INFO - 2018-02-14 16:58:53 --> Model Class Initialized
INFO - 2018-02-14 16:58:53 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-14 16:58:53 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-14 16:58:53 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-14 16:58:53 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-14 16:58:53 --> File loaded: /var/www/html/project/radio/application/views/category/add_edit.php
INFO - 2018-02-14 16:58:53 --> Final output sent to browser
DEBUG - 2018-02-14 16:58:53 --> Total execution time: 0.0085
INFO - 2018-02-14 16:58:58 --> Config Class Initialized
INFO - 2018-02-14 16:58:58 --> Hooks Class Initialized
DEBUG - 2018-02-14 16:58:58 --> UTF-8 Support Enabled
INFO - 2018-02-14 16:58:58 --> Utf8 Class Initialized
INFO - 2018-02-14 16:58:58 --> URI Class Initialized
INFO - 2018-02-14 16:58:58 --> Router Class Initialized
INFO - 2018-02-14 16:58:58 --> Output Class Initialized
INFO - 2018-02-14 16:58:58 --> Security Class Initialized
DEBUG - 2018-02-14 16:58:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 16:58:58 --> Input Class Initialized
INFO - 2018-02-14 16:58:58 --> Language Class Initialized
INFO - 2018-02-14 16:58:58 --> Loader Class Initialized
INFO - 2018-02-14 16:58:58 --> Helper loaded: url_helper
INFO - 2018-02-14 16:58:58 --> Helper loaded: file_helper
INFO - 2018-02-14 16:58:58 --> Helper loaded: email_helper
INFO - 2018-02-14 16:58:58 --> Helper loaded: common_helper
INFO - 2018-02-14 16:58:58 --> Database Driver Class Initialized
DEBUG - 2018-02-14 16:58:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 16:58:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 16:58:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-14 16:58:58 --> Pagination Class Initialized
INFO - 2018-02-14 16:58:58 --> Helper loaded: form_helper
INFO - 2018-02-14 16:58:58 --> Form Validation Class Initialized
INFO - 2018-02-14 16:58:58 --> Model Class Initialized
INFO - 2018-02-14 16:58:58 --> Controller Class Initialized
INFO - 2018-02-14 16:58:58 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-14 16:58:58 --> Model Class Initialized
INFO - 2018-02-14 16:58:58 --> Model Class Initialized
INFO - 2018-02-14 16:58:58 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-14 16:58:58 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-14 16:58:58 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-14 16:58:58 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-14 16:58:58 --> File loaded: /var/www/html/project/radio/application/views/category/add_edit.php
INFO - 2018-02-14 16:58:58 --> Final output sent to browser
DEBUG - 2018-02-14 16:58:58 --> Total execution time: 0.0091
INFO - 2018-02-14 16:59:32 --> Config Class Initialized
INFO - 2018-02-14 16:59:32 --> Hooks Class Initialized
DEBUG - 2018-02-14 16:59:32 --> UTF-8 Support Enabled
INFO - 2018-02-14 16:59:32 --> Utf8 Class Initialized
INFO - 2018-02-14 16:59:32 --> URI Class Initialized
INFO - 2018-02-14 16:59:32 --> Router Class Initialized
INFO - 2018-02-14 16:59:32 --> Output Class Initialized
INFO - 2018-02-14 16:59:32 --> Security Class Initialized
DEBUG - 2018-02-14 16:59:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 16:59:32 --> Input Class Initialized
INFO - 2018-02-14 16:59:32 --> Language Class Initialized
INFO - 2018-02-14 16:59:32 --> Loader Class Initialized
INFO - 2018-02-14 16:59:32 --> Helper loaded: url_helper
INFO - 2018-02-14 16:59:32 --> Helper loaded: file_helper
INFO - 2018-02-14 16:59:32 --> Helper loaded: email_helper
INFO - 2018-02-14 16:59:32 --> Helper loaded: common_helper
INFO - 2018-02-14 16:59:32 --> Database Driver Class Initialized
DEBUG - 2018-02-14 16:59:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 16:59:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 16:59:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-14 16:59:32 --> Pagination Class Initialized
INFO - 2018-02-14 16:59:32 --> Helper loaded: form_helper
INFO - 2018-02-14 16:59:32 --> Form Validation Class Initialized
INFO - 2018-02-14 16:59:32 --> Model Class Initialized
INFO - 2018-02-14 16:59:32 --> Controller Class Initialized
INFO - 2018-02-14 16:59:32 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-14 16:59:32 --> Model Class Initialized
INFO - 2018-02-14 16:59:32 --> Model Class Initialized
INFO - 2018-02-14 16:59:32 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-14 16:59:32 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-14 16:59:32 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-14 16:59:32 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-14 16:59:32 --> File loaded: /var/www/html/project/radio/application/views/subcategory/add_edit.php
INFO - 2018-02-14 16:59:32 --> Final output sent to browser
DEBUG - 2018-02-14 16:59:32 --> Total execution time: 0.0108
INFO - 2018-02-14 17:12:10 --> Config Class Initialized
INFO - 2018-02-14 17:12:10 --> Hooks Class Initialized
DEBUG - 2018-02-14 17:12:10 --> UTF-8 Support Enabled
INFO - 2018-02-14 17:12:10 --> Utf8 Class Initialized
INFO - 2018-02-14 17:12:10 --> URI Class Initialized
INFO - 2018-02-14 17:12:10 --> Router Class Initialized
INFO - 2018-02-14 17:12:10 --> Output Class Initialized
INFO - 2018-02-14 17:12:10 --> Security Class Initialized
DEBUG - 2018-02-14 17:12:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 17:12:10 --> Input Class Initialized
INFO - 2018-02-14 17:12:10 --> Language Class Initialized
INFO - 2018-02-14 17:12:10 --> Loader Class Initialized
INFO - 2018-02-14 17:12:10 --> Helper loaded: url_helper
INFO - 2018-02-14 17:12:10 --> Helper loaded: file_helper
INFO - 2018-02-14 17:12:10 --> Helper loaded: email_helper
INFO - 2018-02-14 17:12:10 --> Helper loaded: common_helper
INFO - 2018-02-14 17:12:10 --> Database Driver Class Initialized
DEBUG - 2018-02-14 17:12:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 17:12:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 17:12:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-14 17:12:10 --> Pagination Class Initialized
INFO - 2018-02-14 17:12:10 --> Helper loaded: form_helper
INFO - 2018-02-14 17:12:10 --> Form Validation Class Initialized
INFO - 2018-02-14 17:12:10 --> Model Class Initialized
INFO - 2018-02-14 17:12:10 --> Controller Class Initialized
INFO - 2018-02-14 17:12:10 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-14 17:12:10 --> Model Class Initialized
INFO - 2018-02-14 17:12:10 --> Model Class Initialized
INFO - 2018-02-14 17:12:10 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-14 17:12:10 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-14 17:12:10 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-14 17:12:10 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-14 17:12:10 --> File loaded: /var/www/html/project/radio/application/views/subcategory/add_edit.php
INFO - 2018-02-14 17:12:10 --> Final output sent to browser
DEBUG - 2018-02-14 17:12:10 --> Total execution time: 0.0091
INFO - 2018-02-14 17:12:52 --> Config Class Initialized
INFO - 2018-02-14 17:12:52 --> Hooks Class Initialized
DEBUG - 2018-02-14 17:12:52 --> UTF-8 Support Enabled
INFO - 2018-02-14 17:12:52 --> Utf8 Class Initialized
INFO - 2018-02-14 17:12:52 --> URI Class Initialized
INFO - 2018-02-14 17:12:52 --> Router Class Initialized
INFO - 2018-02-14 17:12:52 --> Output Class Initialized
INFO - 2018-02-14 17:12:52 --> Security Class Initialized
DEBUG - 2018-02-14 17:12:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 17:12:52 --> Input Class Initialized
INFO - 2018-02-14 17:12:52 --> Language Class Initialized
INFO - 2018-02-14 17:12:52 --> Loader Class Initialized
INFO - 2018-02-14 17:12:52 --> Helper loaded: url_helper
INFO - 2018-02-14 17:12:52 --> Helper loaded: file_helper
INFO - 2018-02-14 17:12:52 --> Helper loaded: email_helper
INFO - 2018-02-14 17:12:52 --> Helper loaded: common_helper
INFO - 2018-02-14 17:12:52 --> Database Driver Class Initialized
DEBUG - 2018-02-14 17:12:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 17:12:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 17:12:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-14 17:12:52 --> Pagination Class Initialized
INFO - 2018-02-14 17:12:52 --> Helper loaded: form_helper
INFO - 2018-02-14 17:12:52 --> Form Validation Class Initialized
INFO - 2018-02-14 17:12:52 --> Model Class Initialized
INFO - 2018-02-14 17:12:52 --> Controller Class Initialized
INFO - 2018-02-14 17:12:52 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-14 17:12:52 --> Model Class Initialized
INFO - 2018-02-14 17:12:52 --> Model Class Initialized
INFO - 2018-02-14 17:12:52 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-14 17:12:52 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-14 17:12:52 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-14 17:12:52 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-14 17:12:52 --> File loaded: /var/www/html/project/radio/application/views/subcategory/add_edit.php
INFO - 2018-02-14 17:12:52 --> Final output sent to browser
DEBUG - 2018-02-14 17:12:52 --> Total execution time: 0.0067
INFO - 2018-02-14 17:12:54 --> Config Class Initialized
INFO - 2018-02-14 17:12:54 --> Hooks Class Initialized
DEBUG - 2018-02-14 17:12:54 --> UTF-8 Support Enabled
INFO - 2018-02-14 17:12:54 --> Utf8 Class Initialized
INFO - 2018-02-14 17:12:54 --> URI Class Initialized
INFO - 2018-02-14 17:12:54 --> Router Class Initialized
INFO - 2018-02-14 17:12:54 --> Output Class Initialized
INFO - 2018-02-14 17:12:54 --> Security Class Initialized
DEBUG - 2018-02-14 17:12:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 17:12:54 --> Input Class Initialized
INFO - 2018-02-14 17:12:54 --> Language Class Initialized
INFO - 2018-02-14 17:12:54 --> Loader Class Initialized
INFO - 2018-02-14 17:12:54 --> Helper loaded: url_helper
INFO - 2018-02-14 17:12:54 --> Helper loaded: file_helper
INFO - 2018-02-14 17:12:54 --> Helper loaded: email_helper
INFO - 2018-02-14 17:12:54 --> Helper loaded: common_helper
INFO - 2018-02-14 17:12:54 --> Database Driver Class Initialized
DEBUG - 2018-02-14 17:12:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 17:12:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 17:12:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-14 17:12:54 --> Pagination Class Initialized
INFO - 2018-02-14 17:12:54 --> Helper loaded: form_helper
INFO - 2018-02-14 17:12:54 --> Form Validation Class Initialized
INFO - 2018-02-14 17:12:54 --> Model Class Initialized
INFO - 2018-02-14 17:12:54 --> Controller Class Initialized
INFO - 2018-02-14 17:12:54 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-14 17:12:54 --> Model Class Initialized
INFO - 2018-02-14 17:12:54 --> Model Class Initialized
INFO - 2018-02-14 17:13:03 --> Config Class Initialized
INFO - 2018-02-14 17:13:03 --> Hooks Class Initialized
DEBUG - 2018-02-14 17:13:03 --> UTF-8 Support Enabled
INFO - 2018-02-14 17:13:03 --> Utf8 Class Initialized
INFO - 2018-02-14 17:13:03 --> URI Class Initialized
INFO - 2018-02-14 17:13:03 --> Router Class Initialized
INFO - 2018-02-14 17:13:03 --> Output Class Initialized
INFO - 2018-02-14 17:13:03 --> Security Class Initialized
DEBUG - 2018-02-14 17:13:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 17:13:03 --> Input Class Initialized
INFO - 2018-02-14 17:13:03 --> Language Class Initialized
INFO - 2018-02-14 17:13:03 --> Loader Class Initialized
INFO - 2018-02-14 17:13:03 --> Helper loaded: url_helper
INFO - 2018-02-14 17:13:03 --> Helper loaded: file_helper
INFO - 2018-02-14 17:13:03 --> Helper loaded: email_helper
INFO - 2018-02-14 17:13:03 --> Helper loaded: common_helper
INFO - 2018-02-14 17:13:03 --> Database Driver Class Initialized
DEBUG - 2018-02-14 17:13:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 17:13:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 17:13:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-14 17:13:03 --> Pagination Class Initialized
INFO - 2018-02-14 17:13:03 --> Helper loaded: form_helper
INFO - 2018-02-14 17:13:03 --> Form Validation Class Initialized
INFO - 2018-02-14 17:13:03 --> Model Class Initialized
INFO - 2018-02-14 17:13:03 --> Controller Class Initialized
INFO - 2018-02-14 17:13:03 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-14 17:13:03 --> Model Class Initialized
INFO - 2018-02-14 17:13:03 --> Model Class Initialized
INFO - 2018-02-14 17:13:03 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-14 17:13:03 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-14 17:13:03 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-14 17:13:03 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-14 17:13:03 --> File loaded: /var/www/html/project/radio/application/views/subcategory/add_edit.php
INFO - 2018-02-14 17:13:03 --> Final output sent to browser
DEBUG - 2018-02-14 17:13:03 --> Total execution time: 0.0100
INFO - 2018-02-14 17:13:03 --> Config Class Initialized
INFO - 2018-02-14 17:13:03 --> Hooks Class Initialized
DEBUG - 2018-02-14 17:13:03 --> UTF-8 Support Enabled
INFO - 2018-02-14 17:13:03 --> Utf8 Class Initialized
INFO - 2018-02-14 17:13:03 --> URI Class Initialized
INFO - 2018-02-14 17:13:03 --> Router Class Initialized
INFO - 2018-02-14 17:13:03 --> Output Class Initialized
INFO - 2018-02-14 17:13:03 --> Security Class Initialized
DEBUG - 2018-02-14 17:13:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 17:13:03 --> Input Class Initialized
INFO - 2018-02-14 17:13:03 --> Language Class Initialized
INFO - 2018-02-14 17:13:03 --> Loader Class Initialized
INFO - 2018-02-14 17:13:03 --> Helper loaded: url_helper
INFO - 2018-02-14 17:13:03 --> Helper loaded: file_helper
INFO - 2018-02-14 17:13:03 --> Helper loaded: email_helper
INFO - 2018-02-14 17:13:03 --> Helper loaded: common_helper
INFO - 2018-02-14 17:13:03 --> Database Driver Class Initialized
DEBUG - 2018-02-14 17:13:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 17:13:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 17:13:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-14 17:13:03 --> Pagination Class Initialized
INFO - 2018-02-14 17:13:03 --> Helper loaded: form_helper
INFO - 2018-02-14 17:13:03 --> Form Validation Class Initialized
INFO - 2018-02-14 17:13:03 --> Model Class Initialized
INFO - 2018-02-14 17:13:03 --> Controller Class Initialized
INFO - 2018-02-14 17:13:03 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-14 17:13:03 --> Model Class Initialized
INFO - 2018-02-14 17:13:03 --> Model Class Initialized
INFO - 2018-02-14 17:13:03 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-14 17:13:03 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-14 17:13:03 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-14 17:13:03 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-14 17:13:03 --> File loaded: /var/www/html/project/radio/application/views/subcategory/add_edit.php
INFO - 2018-02-14 17:13:03 --> Final output sent to browser
DEBUG - 2018-02-14 17:13:03 --> Total execution time: 0.0060
INFO - 2018-02-14 17:13:04 --> Config Class Initialized
INFO - 2018-02-14 17:13:04 --> Hooks Class Initialized
DEBUG - 2018-02-14 17:13:04 --> UTF-8 Support Enabled
INFO - 2018-02-14 17:13:04 --> Utf8 Class Initialized
INFO - 2018-02-14 17:13:04 --> URI Class Initialized
INFO - 2018-02-14 17:13:04 --> Router Class Initialized
INFO - 2018-02-14 17:13:04 --> Output Class Initialized
INFO - 2018-02-14 17:13:04 --> Security Class Initialized
DEBUG - 2018-02-14 17:13:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 17:13:04 --> Input Class Initialized
INFO - 2018-02-14 17:13:04 --> Language Class Initialized
INFO - 2018-02-14 17:13:04 --> Loader Class Initialized
INFO - 2018-02-14 17:13:04 --> Helper loaded: url_helper
INFO - 2018-02-14 17:13:04 --> Helper loaded: file_helper
INFO - 2018-02-14 17:13:04 --> Helper loaded: email_helper
INFO - 2018-02-14 17:13:04 --> Helper loaded: common_helper
INFO - 2018-02-14 17:13:04 --> Database Driver Class Initialized
DEBUG - 2018-02-14 17:13:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 17:13:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 17:13:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-14 17:13:04 --> Pagination Class Initialized
INFO - 2018-02-14 17:13:04 --> Helper loaded: form_helper
INFO - 2018-02-14 17:13:04 --> Form Validation Class Initialized
INFO - 2018-02-14 17:13:04 --> Model Class Initialized
INFO - 2018-02-14 17:13:04 --> Controller Class Initialized
INFO - 2018-02-14 17:13:04 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-14 17:13:04 --> Model Class Initialized
INFO - 2018-02-14 17:13:04 --> Model Class Initialized
INFO - 2018-02-14 17:13:04 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-14 17:13:04 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-14 17:13:04 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-14 17:13:04 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-14 17:13:04 --> File loaded: /var/www/html/project/radio/application/views/subcategory/add_edit.php
INFO - 2018-02-14 17:13:04 --> Final output sent to browser
DEBUG - 2018-02-14 17:13:04 --> Total execution time: 0.0066
INFO - 2018-02-14 17:13:06 --> Config Class Initialized
INFO - 2018-02-14 17:13:06 --> Hooks Class Initialized
DEBUG - 2018-02-14 17:13:06 --> UTF-8 Support Enabled
INFO - 2018-02-14 17:13:06 --> Utf8 Class Initialized
INFO - 2018-02-14 17:13:06 --> URI Class Initialized
INFO - 2018-02-14 17:13:06 --> Router Class Initialized
INFO - 2018-02-14 17:13:06 --> Output Class Initialized
INFO - 2018-02-14 17:13:06 --> Security Class Initialized
DEBUG - 2018-02-14 17:13:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 17:13:06 --> Input Class Initialized
INFO - 2018-02-14 17:13:06 --> Language Class Initialized
INFO - 2018-02-14 17:13:06 --> Loader Class Initialized
INFO - 2018-02-14 17:13:06 --> Helper loaded: url_helper
INFO - 2018-02-14 17:13:06 --> Helper loaded: file_helper
INFO - 2018-02-14 17:13:06 --> Helper loaded: email_helper
INFO - 2018-02-14 17:13:06 --> Helper loaded: common_helper
INFO - 2018-02-14 17:13:06 --> Database Driver Class Initialized
DEBUG - 2018-02-14 17:13:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 17:13:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 17:13:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-14 17:13:06 --> Pagination Class Initialized
INFO - 2018-02-14 17:13:06 --> Helper loaded: form_helper
INFO - 2018-02-14 17:13:06 --> Form Validation Class Initialized
INFO - 2018-02-14 17:13:06 --> Model Class Initialized
INFO - 2018-02-14 17:13:06 --> Controller Class Initialized
INFO - 2018-02-14 17:13:06 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-14 17:13:06 --> Model Class Initialized
INFO - 2018-02-14 17:13:06 --> Model Class Initialized
INFO - 2018-02-14 17:13:08 --> Config Class Initialized
INFO - 2018-02-14 17:13:08 --> Hooks Class Initialized
DEBUG - 2018-02-14 17:13:08 --> UTF-8 Support Enabled
INFO - 2018-02-14 17:13:08 --> Utf8 Class Initialized
INFO - 2018-02-14 17:13:08 --> URI Class Initialized
INFO - 2018-02-14 17:13:08 --> Router Class Initialized
INFO - 2018-02-14 17:13:08 --> Output Class Initialized
INFO - 2018-02-14 17:13:08 --> Security Class Initialized
DEBUG - 2018-02-14 17:13:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 17:13:08 --> Input Class Initialized
INFO - 2018-02-14 17:13:08 --> Language Class Initialized
INFO - 2018-02-14 17:13:08 --> Loader Class Initialized
INFO - 2018-02-14 17:13:08 --> Helper loaded: url_helper
INFO - 2018-02-14 17:13:08 --> Helper loaded: file_helper
INFO - 2018-02-14 17:13:08 --> Helper loaded: email_helper
INFO - 2018-02-14 17:13:08 --> Helper loaded: common_helper
INFO - 2018-02-14 17:13:08 --> Database Driver Class Initialized
DEBUG - 2018-02-14 17:13:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 17:13:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 17:13:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-14 17:13:08 --> Pagination Class Initialized
INFO - 2018-02-14 17:13:08 --> Helper loaded: form_helper
INFO - 2018-02-14 17:13:08 --> Form Validation Class Initialized
INFO - 2018-02-14 17:13:08 --> Model Class Initialized
INFO - 2018-02-14 17:13:08 --> Controller Class Initialized
INFO - 2018-02-14 17:13:08 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-14 17:13:08 --> Model Class Initialized
INFO - 2018-02-14 17:13:08 --> Model Class Initialized
INFO - 2018-02-14 17:13:08 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-14 17:13:08 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-14 17:13:08 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-14 17:13:08 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-14 17:13:08 --> File loaded: /var/www/html/project/radio/application/views/subcategory/add_edit.php
INFO - 2018-02-14 17:13:08 --> Final output sent to browser
DEBUG - 2018-02-14 17:13:08 --> Total execution time: 0.0062
INFO - 2018-02-14 17:14:28 --> Config Class Initialized
INFO - 2018-02-14 17:14:28 --> Hooks Class Initialized
DEBUG - 2018-02-14 17:14:28 --> UTF-8 Support Enabled
INFO - 2018-02-14 17:14:28 --> Utf8 Class Initialized
INFO - 2018-02-14 17:14:28 --> URI Class Initialized
INFO - 2018-02-14 17:14:28 --> Router Class Initialized
INFO - 2018-02-14 17:14:28 --> Output Class Initialized
INFO - 2018-02-14 17:14:28 --> Security Class Initialized
DEBUG - 2018-02-14 17:14:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 17:14:28 --> Input Class Initialized
INFO - 2018-02-14 17:14:28 --> Language Class Initialized
INFO - 2018-02-14 17:14:28 --> Loader Class Initialized
INFO - 2018-02-14 17:14:28 --> Helper loaded: url_helper
INFO - 2018-02-14 17:14:28 --> Helper loaded: file_helper
INFO - 2018-02-14 17:14:28 --> Helper loaded: email_helper
INFO - 2018-02-14 17:14:28 --> Helper loaded: common_helper
INFO - 2018-02-14 17:14:28 --> Database Driver Class Initialized
DEBUG - 2018-02-14 17:14:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 17:14:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 17:14:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-14 17:14:28 --> Pagination Class Initialized
INFO - 2018-02-14 17:14:28 --> Helper loaded: form_helper
INFO - 2018-02-14 17:14:28 --> Form Validation Class Initialized
INFO - 2018-02-14 17:14:28 --> Model Class Initialized
INFO - 2018-02-14 17:14:28 --> Controller Class Initialized
INFO - 2018-02-14 17:14:28 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-14 17:14:28 --> Model Class Initialized
INFO - 2018-02-14 17:14:28 --> Model Class Initialized
INFO - 2018-02-14 17:14:28 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-14 17:14:28 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-14 17:14:28 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-14 17:14:28 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-14 17:14:28 --> File loaded: /var/www/html/project/radio/application/views/subcategory/add_edit.php
INFO - 2018-02-14 17:14:28 --> Final output sent to browser
DEBUG - 2018-02-14 17:14:28 --> Total execution time: 0.0093
INFO - 2018-02-14 17:14:28 --> Config Class Initialized
INFO - 2018-02-14 17:14:28 --> Hooks Class Initialized
DEBUG - 2018-02-14 17:14:28 --> UTF-8 Support Enabled
INFO - 2018-02-14 17:14:28 --> Utf8 Class Initialized
INFO - 2018-02-14 17:14:28 --> URI Class Initialized
INFO - 2018-02-14 17:14:28 --> Router Class Initialized
INFO - 2018-02-14 17:14:28 --> Output Class Initialized
INFO - 2018-02-14 17:14:28 --> Security Class Initialized
DEBUG - 2018-02-14 17:14:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 17:14:28 --> Input Class Initialized
INFO - 2018-02-14 17:14:28 --> Language Class Initialized
INFO - 2018-02-14 17:14:28 --> Loader Class Initialized
INFO - 2018-02-14 17:14:28 --> Helper loaded: url_helper
INFO - 2018-02-14 17:14:28 --> Helper loaded: file_helper
INFO - 2018-02-14 17:14:28 --> Helper loaded: email_helper
INFO - 2018-02-14 17:14:28 --> Helper loaded: common_helper
INFO - 2018-02-14 17:14:28 --> Database Driver Class Initialized
DEBUG - 2018-02-14 17:14:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 17:14:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 17:14:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-14 17:14:28 --> Pagination Class Initialized
INFO - 2018-02-14 17:14:28 --> Helper loaded: form_helper
INFO - 2018-02-14 17:14:28 --> Form Validation Class Initialized
INFO - 2018-02-14 17:14:28 --> Model Class Initialized
INFO - 2018-02-14 17:14:28 --> Controller Class Initialized
INFO - 2018-02-14 17:14:28 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-14 17:14:28 --> Model Class Initialized
INFO - 2018-02-14 17:14:28 --> Model Class Initialized
INFO - 2018-02-14 17:14:28 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-14 17:14:28 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-14 17:14:28 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-14 17:14:28 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-14 17:14:28 --> File loaded: /var/www/html/project/radio/application/views/subcategory/add_edit.php
INFO - 2018-02-14 17:14:28 --> Final output sent to browser
DEBUG - 2018-02-14 17:14:28 --> Total execution time: 0.0054
INFO - 2018-02-14 17:14:30 --> Config Class Initialized
INFO - 2018-02-14 17:14:30 --> Hooks Class Initialized
DEBUG - 2018-02-14 17:14:30 --> UTF-8 Support Enabled
INFO - 2018-02-14 17:14:30 --> Utf8 Class Initialized
INFO - 2018-02-14 17:14:30 --> URI Class Initialized
INFO - 2018-02-14 17:14:30 --> Router Class Initialized
INFO - 2018-02-14 17:14:30 --> Output Class Initialized
INFO - 2018-02-14 17:14:30 --> Security Class Initialized
DEBUG - 2018-02-14 17:14:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 17:14:30 --> Input Class Initialized
INFO - 2018-02-14 17:14:30 --> Language Class Initialized
INFO - 2018-02-14 17:14:30 --> Loader Class Initialized
INFO - 2018-02-14 17:14:30 --> Helper loaded: url_helper
INFO - 2018-02-14 17:14:30 --> Helper loaded: file_helper
INFO - 2018-02-14 17:14:30 --> Helper loaded: email_helper
INFO - 2018-02-14 17:14:30 --> Helper loaded: common_helper
INFO - 2018-02-14 17:14:30 --> Database Driver Class Initialized
DEBUG - 2018-02-14 17:14:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 17:14:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 17:14:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-14 17:14:30 --> Pagination Class Initialized
INFO - 2018-02-14 17:14:30 --> Helper loaded: form_helper
INFO - 2018-02-14 17:14:30 --> Form Validation Class Initialized
INFO - 2018-02-14 17:14:30 --> Model Class Initialized
INFO - 2018-02-14 17:14:30 --> Controller Class Initialized
INFO - 2018-02-14 17:14:30 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-14 17:14:30 --> Model Class Initialized
INFO - 2018-02-14 17:14:30 --> Model Class Initialized
INFO - 2018-02-14 17:14:55 --> Config Class Initialized
INFO - 2018-02-14 17:14:55 --> Hooks Class Initialized
DEBUG - 2018-02-14 17:14:55 --> UTF-8 Support Enabled
INFO - 2018-02-14 17:14:55 --> Utf8 Class Initialized
INFO - 2018-02-14 17:14:55 --> URI Class Initialized
INFO - 2018-02-14 17:14:55 --> Router Class Initialized
INFO - 2018-02-14 17:14:55 --> Output Class Initialized
INFO - 2018-02-14 17:14:55 --> Security Class Initialized
DEBUG - 2018-02-14 17:14:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 17:14:55 --> Input Class Initialized
INFO - 2018-02-14 17:14:55 --> Language Class Initialized
INFO - 2018-02-14 17:14:55 --> Loader Class Initialized
INFO - 2018-02-14 17:14:55 --> Helper loaded: url_helper
INFO - 2018-02-14 17:14:55 --> Helper loaded: file_helper
INFO - 2018-02-14 17:14:55 --> Helper loaded: email_helper
INFO - 2018-02-14 17:14:55 --> Helper loaded: common_helper
INFO - 2018-02-14 17:14:55 --> Database Driver Class Initialized
DEBUG - 2018-02-14 17:14:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 17:14:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 17:14:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-14 17:14:55 --> Pagination Class Initialized
INFO - 2018-02-14 17:14:55 --> Helper loaded: form_helper
INFO - 2018-02-14 17:14:55 --> Form Validation Class Initialized
INFO - 2018-02-14 17:14:55 --> Model Class Initialized
INFO - 2018-02-14 17:14:55 --> Controller Class Initialized
INFO - 2018-02-14 17:14:55 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-14 17:14:55 --> Model Class Initialized
INFO - 2018-02-14 17:14:55 --> Model Class Initialized
INFO - 2018-02-14 17:14:55 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-14 17:14:55 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-14 17:14:55 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-14 17:14:55 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-14 17:14:55 --> File loaded: /var/www/html/project/radio/application/views/subcategory/add_edit.php
INFO - 2018-02-14 17:14:55 --> Final output sent to browser
DEBUG - 2018-02-14 17:14:55 --> Total execution time: 0.0060
INFO - 2018-02-14 17:15:00 --> Config Class Initialized
INFO - 2018-02-14 17:15:00 --> Hooks Class Initialized
DEBUG - 2018-02-14 17:15:00 --> UTF-8 Support Enabled
INFO - 2018-02-14 17:15:00 --> Utf8 Class Initialized
INFO - 2018-02-14 17:15:00 --> URI Class Initialized
INFO - 2018-02-14 17:15:00 --> Router Class Initialized
INFO - 2018-02-14 17:15:00 --> Output Class Initialized
INFO - 2018-02-14 17:15:00 --> Security Class Initialized
DEBUG - 2018-02-14 17:15:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 17:15:00 --> Input Class Initialized
INFO - 2018-02-14 17:15:00 --> Language Class Initialized
INFO - 2018-02-14 17:15:00 --> Loader Class Initialized
INFO - 2018-02-14 17:15:00 --> Helper loaded: url_helper
INFO - 2018-02-14 17:15:00 --> Helper loaded: file_helper
INFO - 2018-02-14 17:15:00 --> Helper loaded: email_helper
INFO - 2018-02-14 17:15:00 --> Helper loaded: common_helper
INFO - 2018-02-14 17:15:00 --> Database Driver Class Initialized
DEBUG - 2018-02-14 17:15:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 17:15:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 17:15:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-14 17:15:00 --> Pagination Class Initialized
INFO - 2018-02-14 17:15:00 --> Helper loaded: form_helper
INFO - 2018-02-14 17:15:00 --> Form Validation Class Initialized
INFO - 2018-02-14 17:15:00 --> Model Class Initialized
INFO - 2018-02-14 17:15:00 --> Controller Class Initialized
INFO - 2018-02-14 17:15:00 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-14 17:15:00 --> Model Class Initialized
INFO - 2018-02-14 17:15:00 --> Model Class Initialized
INFO - 2018-02-14 17:15:00 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-14 17:15:00 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-14 17:15:00 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-14 17:15:00 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-14 17:15:00 --> File loaded: /var/www/html/project/radio/application/views/subcategory/add_edit.php
INFO - 2018-02-14 17:15:00 --> Final output sent to browser
DEBUG - 2018-02-14 17:15:00 --> Total execution time: 0.0062
INFO - 2018-02-14 17:15:01 --> Config Class Initialized
INFO - 2018-02-14 17:15:01 --> Hooks Class Initialized
DEBUG - 2018-02-14 17:15:01 --> UTF-8 Support Enabled
INFO - 2018-02-14 17:15:01 --> Utf8 Class Initialized
INFO - 2018-02-14 17:15:01 --> URI Class Initialized
INFO - 2018-02-14 17:15:01 --> Router Class Initialized
INFO - 2018-02-14 17:15:01 --> Output Class Initialized
INFO - 2018-02-14 17:15:01 --> Security Class Initialized
DEBUG - 2018-02-14 17:15:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 17:15:01 --> Input Class Initialized
INFO - 2018-02-14 17:15:01 --> Language Class Initialized
INFO - 2018-02-14 17:15:01 --> Loader Class Initialized
INFO - 2018-02-14 17:15:01 --> Helper loaded: url_helper
INFO - 2018-02-14 17:15:01 --> Helper loaded: file_helper
INFO - 2018-02-14 17:15:01 --> Helper loaded: email_helper
INFO - 2018-02-14 17:15:01 --> Helper loaded: common_helper
INFO - 2018-02-14 17:15:01 --> Database Driver Class Initialized
DEBUG - 2018-02-14 17:15:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 17:15:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 17:15:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-14 17:15:01 --> Pagination Class Initialized
INFO - 2018-02-14 17:15:01 --> Helper loaded: form_helper
INFO - 2018-02-14 17:15:01 --> Form Validation Class Initialized
INFO - 2018-02-14 17:15:01 --> Model Class Initialized
INFO - 2018-02-14 17:15:01 --> Controller Class Initialized
INFO - 2018-02-14 17:15:01 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-14 17:15:01 --> Model Class Initialized
INFO - 2018-02-14 17:15:01 --> Model Class Initialized
INFO - 2018-02-14 17:15:07 --> Config Class Initialized
INFO - 2018-02-14 17:15:07 --> Hooks Class Initialized
DEBUG - 2018-02-14 17:15:07 --> UTF-8 Support Enabled
INFO - 2018-02-14 17:15:07 --> Utf8 Class Initialized
INFO - 2018-02-14 17:15:07 --> URI Class Initialized
INFO - 2018-02-14 17:15:07 --> Router Class Initialized
INFO - 2018-02-14 17:15:07 --> Output Class Initialized
INFO - 2018-02-14 17:15:07 --> Security Class Initialized
DEBUG - 2018-02-14 17:15:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 17:15:07 --> Input Class Initialized
INFO - 2018-02-14 17:15:07 --> Language Class Initialized
INFO - 2018-02-14 17:15:07 --> Loader Class Initialized
INFO - 2018-02-14 17:15:07 --> Helper loaded: url_helper
INFO - 2018-02-14 17:15:07 --> Helper loaded: file_helper
INFO - 2018-02-14 17:15:07 --> Helper loaded: email_helper
INFO - 2018-02-14 17:15:07 --> Helper loaded: common_helper
INFO - 2018-02-14 17:15:07 --> Database Driver Class Initialized
DEBUG - 2018-02-14 17:15:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 17:15:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 17:15:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-14 17:15:07 --> Pagination Class Initialized
INFO - 2018-02-14 17:15:07 --> Helper loaded: form_helper
INFO - 2018-02-14 17:15:07 --> Form Validation Class Initialized
INFO - 2018-02-14 17:15:07 --> Model Class Initialized
INFO - 2018-02-14 17:15:07 --> Controller Class Initialized
INFO - 2018-02-14 17:15:07 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-14 17:15:07 --> Model Class Initialized
INFO - 2018-02-14 17:15:07 --> Model Class Initialized
INFO - 2018-02-14 17:15:07 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-14 17:15:07 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-14 17:15:07 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-14 17:15:07 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-14 17:15:07 --> File loaded: /var/www/html/project/radio/application/views/subcategory/add_edit.php
INFO - 2018-02-14 17:15:07 --> Final output sent to browser
DEBUG - 2018-02-14 17:15:07 --> Total execution time: 0.0065
INFO - 2018-02-14 17:15:11 --> Config Class Initialized
INFO - 2018-02-14 17:15:11 --> Hooks Class Initialized
DEBUG - 2018-02-14 17:15:11 --> UTF-8 Support Enabled
INFO - 2018-02-14 17:15:11 --> Utf8 Class Initialized
INFO - 2018-02-14 17:15:11 --> URI Class Initialized
INFO - 2018-02-14 17:15:11 --> Router Class Initialized
INFO - 2018-02-14 17:15:11 --> Output Class Initialized
INFO - 2018-02-14 17:15:11 --> Security Class Initialized
DEBUG - 2018-02-14 17:15:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 17:15:11 --> Input Class Initialized
INFO - 2018-02-14 17:15:11 --> Language Class Initialized
INFO - 2018-02-14 17:15:11 --> Loader Class Initialized
INFO - 2018-02-14 17:15:11 --> Helper loaded: url_helper
INFO - 2018-02-14 17:15:11 --> Helper loaded: file_helper
INFO - 2018-02-14 17:15:11 --> Helper loaded: email_helper
INFO - 2018-02-14 17:15:11 --> Helper loaded: common_helper
INFO - 2018-02-14 17:15:11 --> Database Driver Class Initialized
DEBUG - 2018-02-14 17:15:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 17:15:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 17:15:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-14 17:15:11 --> Pagination Class Initialized
INFO - 2018-02-14 17:15:11 --> Helper loaded: form_helper
INFO - 2018-02-14 17:15:11 --> Form Validation Class Initialized
INFO - 2018-02-14 17:15:11 --> Model Class Initialized
INFO - 2018-02-14 17:15:11 --> Controller Class Initialized
INFO - 2018-02-14 17:15:11 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-14 17:15:11 --> Model Class Initialized
INFO - 2018-02-14 17:15:11 --> Model Class Initialized
INFO - 2018-02-14 17:15:46 --> Config Class Initialized
INFO - 2018-02-14 17:15:46 --> Hooks Class Initialized
DEBUG - 2018-02-14 17:15:46 --> UTF-8 Support Enabled
INFO - 2018-02-14 17:15:46 --> Utf8 Class Initialized
INFO - 2018-02-14 17:15:46 --> URI Class Initialized
INFO - 2018-02-14 17:15:46 --> Router Class Initialized
INFO - 2018-02-14 17:15:46 --> Output Class Initialized
INFO - 2018-02-14 17:15:46 --> Security Class Initialized
DEBUG - 2018-02-14 17:15:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 17:15:46 --> Input Class Initialized
INFO - 2018-02-14 17:15:46 --> Language Class Initialized
INFO - 2018-02-14 17:15:46 --> Loader Class Initialized
INFO - 2018-02-14 17:15:46 --> Helper loaded: url_helper
INFO - 2018-02-14 17:15:46 --> Helper loaded: file_helper
INFO - 2018-02-14 17:15:46 --> Helper loaded: email_helper
INFO - 2018-02-14 17:15:46 --> Helper loaded: common_helper
INFO - 2018-02-14 17:15:46 --> Database Driver Class Initialized
DEBUG - 2018-02-14 17:15:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 17:15:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 17:15:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-14 17:15:46 --> Pagination Class Initialized
INFO - 2018-02-14 17:15:46 --> Helper loaded: form_helper
INFO - 2018-02-14 17:15:46 --> Form Validation Class Initialized
INFO - 2018-02-14 17:15:46 --> Model Class Initialized
INFO - 2018-02-14 17:15:46 --> Controller Class Initialized
INFO - 2018-02-14 17:15:46 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-14 17:15:46 --> Model Class Initialized
INFO - 2018-02-14 17:15:46 --> Model Class Initialized
INFO - 2018-02-14 17:15:46 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-14 17:15:46 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-14 17:15:46 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-14 17:15:46 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-14 17:15:46 --> File loaded: /var/www/html/project/radio/application/views/subcategory/add_edit.php
INFO - 2018-02-14 17:15:46 --> Final output sent to browser
DEBUG - 2018-02-14 17:15:46 --> Total execution time: 0.0074
INFO - 2018-02-14 17:18:23 --> Config Class Initialized
INFO - 2018-02-14 17:18:23 --> Hooks Class Initialized
DEBUG - 2018-02-14 17:18:23 --> UTF-8 Support Enabled
INFO - 2018-02-14 17:18:23 --> Utf8 Class Initialized
INFO - 2018-02-14 17:18:23 --> URI Class Initialized
INFO - 2018-02-14 17:18:23 --> Router Class Initialized
INFO - 2018-02-14 17:18:23 --> Output Class Initialized
INFO - 2018-02-14 17:18:23 --> Security Class Initialized
DEBUG - 2018-02-14 17:18:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 17:18:23 --> Input Class Initialized
INFO - 2018-02-14 17:18:23 --> Language Class Initialized
INFO - 2018-02-14 17:18:23 --> Loader Class Initialized
INFO - 2018-02-14 17:18:23 --> Helper loaded: url_helper
INFO - 2018-02-14 17:18:23 --> Helper loaded: file_helper
INFO - 2018-02-14 17:18:23 --> Helper loaded: email_helper
INFO - 2018-02-14 17:18:23 --> Helper loaded: common_helper
INFO - 2018-02-14 17:18:23 --> Database Driver Class Initialized
DEBUG - 2018-02-14 17:18:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 17:18:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 17:18:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-14 17:18:23 --> Pagination Class Initialized
INFO - 2018-02-14 17:18:23 --> Helper loaded: form_helper
INFO - 2018-02-14 17:18:23 --> Form Validation Class Initialized
INFO - 2018-02-14 17:18:23 --> Model Class Initialized
INFO - 2018-02-14 17:18:23 --> Controller Class Initialized
INFO - 2018-02-14 17:18:23 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-14 17:18:23 --> Model Class Initialized
INFO - 2018-02-14 17:18:23 --> Model Class Initialized
INFO - 2018-02-14 17:18:23 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-14 17:18:23 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-14 17:18:23 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-14 17:18:23 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-14 17:18:23 --> File loaded: /var/www/html/project/radio/application/views/subcategory/add_edit.php
INFO - 2018-02-14 17:18:23 --> Final output sent to browser
DEBUG - 2018-02-14 17:18:23 --> Total execution time: 0.0051
INFO - 2018-02-14 17:26:16 --> Config Class Initialized
INFO - 2018-02-14 17:26:16 --> Hooks Class Initialized
DEBUG - 2018-02-14 17:26:16 --> UTF-8 Support Enabled
INFO - 2018-02-14 17:26:16 --> Utf8 Class Initialized
INFO - 2018-02-14 17:26:16 --> URI Class Initialized
INFO - 2018-02-14 17:26:16 --> Router Class Initialized
INFO - 2018-02-14 17:26:16 --> Output Class Initialized
INFO - 2018-02-14 17:26:16 --> Security Class Initialized
DEBUG - 2018-02-14 17:26:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 17:26:16 --> Input Class Initialized
INFO - 2018-02-14 17:26:16 --> Language Class Initialized
INFO - 2018-02-14 17:26:16 --> Loader Class Initialized
INFO - 2018-02-14 17:26:16 --> Helper loaded: url_helper
INFO - 2018-02-14 17:26:16 --> Helper loaded: file_helper
INFO - 2018-02-14 17:26:16 --> Helper loaded: email_helper
INFO - 2018-02-14 17:26:16 --> Helper loaded: common_helper
INFO - 2018-02-14 17:26:16 --> Database Driver Class Initialized
DEBUG - 2018-02-14 17:26:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 17:26:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 17:26:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-14 17:26:16 --> Pagination Class Initialized
INFO - 2018-02-14 17:26:16 --> Helper loaded: form_helper
INFO - 2018-02-14 17:26:16 --> Form Validation Class Initialized
INFO - 2018-02-14 17:26:16 --> Model Class Initialized
INFO - 2018-02-14 17:26:16 --> Controller Class Initialized
INFO - 2018-02-14 17:26:16 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-14 17:26:16 --> Model Class Initialized
INFO - 2018-02-14 17:26:16 --> Model Class Initialized
INFO - 2018-02-14 17:26:16 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-14 17:26:16 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-14 17:26:16 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-14 17:26:16 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-14 17:26:16 --> File loaded: /var/www/html/project/radio/application/views/subcategory/add_edit.php
INFO - 2018-02-14 17:26:16 --> Final output sent to browser
DEBUG - 2018-02-14 17:26:16 --> Total execution time: 0.0110
INFO - 2018-02-14 17:27:08 --> Config Class Initialized
INFO - 2018-02-14 17:27:08 --> Hooks Class Initialized
DEBUG - 2018-02-14 17:27:08 --> UTF-8 Support Enabled
INFO - 2018-02-14 17:27:08 --> Utf8 Class Initialized
INFO - 2018-02-14 17:27:08 --> URI Class Initialized
INFO - 2018-02-14 17:27:08 --> Router Class Initialized
INFO - 2018-02-14 17:27:08 --> Output Class Initialized
INFO - 2018-02-14 17:27:08 --> Security Class Initialized
DEBUG - 2018-02-14 17:27:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 17:27:08 --> Input Class Initialized
INFO - 2018-02-14 17:27:08 --> Language Class Initialized
INFO - 2018-02-14 17:27:08 --> Loader Class Initialized
INFO - 2018-02-14 17:27:08 --> Helper loaded: url_helper
INFO - 2018-02-14 17:27:08 --> Helper loaded: file_helper
INFO - 2018-02-14 17:27:08 --> Helper loaded: email_helper
INFO - 2018-02-14 17:27:08 --> Helper loaded: common_helper
INFO - 2018-02-14 17:27:08 --> Database Driver Class Initialized
DEBUG - 2018-02-14 17:27:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 17:27:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 17:27:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-14 17:27:08 --> Pagination Class Initialized
INFO - 2018-02-14 17:27:08 --> Helper loaded: form_helper
INFO - 2018-02-14 17:27:08 --> Form Validation Class Initialized
INFO - 2018-02-14 17:27:08 --> Model Class Initialized
INFO - 2018-02-14 17:27:08 --> Controller Class Initialized
INFO - 2018-02-14 17:27:08 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-14 17:27:08 --> Model Class Initialized
INFO - 2018-02-14 17:27:08 --> Model Class Initialized
INFO - 2018-02-14 17:27:08 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-14 17:27:08 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-14 17:27:08 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-14 17:27:08 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-14 17:27:08 --> File loaded: /var/www/html/project/radio/application/views/subcategory/add_edit.php
INFO - 2018-02-14 17:27:08 --> Final output sent to browser
DEBUG - 2018-02-14 17:27:08 --> Total execution time: 0.0069
INFO - 2018-02-14 17:27:22 --> Config Class Initialized
INFO - 2018-02-14 17:27:22 --> Hooks Class Initialized
DEBUG - 2018-02-14 17:27:22 --> UTF-8 Support Enabled
INFO - 2018-02-14 17:27:22 --> Utf8 Class Initialized
INFO - 2018-02-14 17:27:22 --> URI Class Initialized
INFO - 2018-02-14 17:27:22 --> Router Class Initialized
INFO - 2018-02-14 17:27:22 --> Output Class Initialized
INFO - 2018-02-14 17:27:22 --> Security Class Initialized
DEBUG - 2018-02-14 17:27:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 17:27:22 --> Input Class Initialized
INFO - 2018-02-14 17:27:22 --> Language Class Initialized
INFO - 2018-02-14 17:27:22 --> Loader Class Initialized
INFO - 2018-02-14 17:27:22 --> Helper loaded: url_helper
INFO - 2018-02-14 17:27:22 --> Helper loaded: file_helper
INFO - 2018-02-14 17:27:22 --> Helper loaded: email_helper
INFO - 2018-02-14 17:27:22 --> Helper loaded: common_helper
INFO - 2018-02-14 17:27:22 --> Database Driver Class Initialized
DEBUG - 2018-02-14 17:27:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 17:27:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 17:27:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-14 17:27:22 --> Pagination Class Initialized
INFO - 2018-02-14 17:27:22 --> Helper loaded: form_helper
INFO - 2018-02-14 17:27:22 --> Form Validation Class Initialized
INFO - 2018-02-14 17:27:22 --> Model Class Initialized
INFO - 2018-02-14 17:27:22 --> Controller Class Initialized
INFO - 2018-02-14 17:27:22 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-14 17:27:22 --> Model Class Initialized
INFO - 2018-02-14 17:27:22 --> Model Class Initialized
INFO - 2018-02-14 17:27:22 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-14 17:27:22 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-14 17:27:22 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-14 17:27:22 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-14 17:27:22 --> File loaded: /var/www/html/project/radio/application/views/subcategory/add_edit.php
INFO - 2018-02-14 17:27:22 --> Final output sent to browser
DEBUG - 2018-02-14 17:27:22 --> Total execution time: 0.0073
INFO - 2018-02-14 17:27:22 --> Config Class Initialized
INFO - 2018-02-14 17:27:22 --> Hooks Class Initialized
DEBUG - 2018-02-14 17:27:22 --> UTF-8 Support Enabled
INFO - 2018-02-14 17:27:22 --> Utf8 Class Initialized
INFO - 2018-02-14 17:27:22 --> URI Class Initialized
INFO - 2018-02-14 17:27:22 --> Router Class Initialized
INFO - 2018-02-14 17:27:22 --> Output Class Initialized
INFO - 2018-02-14 17:27:22 --> Security Class Initialized
DEBUG - 2018-02-14 17:27:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 17:27:22 --> Input Class Initialized
INFO - 2018-02-14 17:27:22 --> Language Class Initialized
INFO - 2018-02-14 17:27:22 --> Loader Class Initialized
INFO - 2018-02-14 17:27:22 --> Helper loaded: url_helper
INFO - 2018-02-14 17:27:22 --> Helper loaded: file_helper
INFO - 2018-02-14 17:27:22 --> Helper loaded: email_helper
INFO - 2018-02-14 17:27:22 --> Helper loaded: common_helper
INFO - 2018-02-14 17:27:22 --> Database Driver Class Initialized
DEBUG - 2018-02-14 17:27:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 17:27:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 17:27:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-14 17:27:22 --> Pagination Class Initialized
INFO - 2018-02-14 17:27:22 --> Helper loaded: form_helper
INFO - 2018-02-14 17:27:22 --> Form Validation Class Initialized
INFO - 2018-02-14 17:27:22 --> Model Class Initialized
INFO - 2018-02-14 17:27:22 --> Controller Class Initialized
INFO - 2018-02-14 17:27:22 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-14 17:27:22 --> Model Class Initialized
INFO - 2018-02-14 17:27:22 --> Model Class Initialized
INFO - 2018-02-14 17:27:22 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-14 17:27:22 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-14 17:27:22 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-14 17:27:22 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-14 17:27:22 --> File loaded: /var/www/html/project/radio/application/views/subcategory/add_edit.php
INFO - 2018-02-14 17:27:22 --> Final output sent to browser
DEBUG - 2018-02-14 17:27:22 --> Total execution time: 0.0070
INFO - 2018-02-14 17:33:11 --> Config Class Initialized
INFO - 2018-02-14 17:33:11 --> Hooks Class Initialized
DEBUG - 2018-02-14 17:33:11 --> UTF-8 Support Enabled
INFO - 2018-02-14 17:33:11 --> Utf8 Class Initialized
INFO - 2018-02-14 17:33:11 --> URI Class Initialized
INFO - 2018-02-14 17:33:11 --> Router Class Initialized
INFO - 2018-02-14 17:33:11 --> Output Class Initialized
INFO - 2018-02-14 17:33:11 --> Security Class Initialized
DEBUG - 2018-02-14 17:33:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 17:33:11 --> Input Class Initialized
INFO - 2018-02-14 17:33:11 --> Language Class Initialized
INFO - 2018-02-14 17:33:11 --> Loader Class Initialized
INFO - 2018-02-14 17:33:11 --> Helper loaded: url_helper
INFO - 2018-02-14 17:33:11 --> Helper loaded: file_helper
INFO - 2018-02-14 17:33:11 --> Helper loaded: email_helper
INFO - 2018-02-14 17:33:11 --> Helper loaded: common_helper
INFO - 2018-02-14 17:33:11 --> Database Driver Class Initialized
DEBUG - 2018-02-14 17:33:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 17:33:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 17:33:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-14 17:33:11 --> Pagination Class Initialized
INFO - 2018-02-14 17:33:11 --> Helper loaded: form_helper
INFO - 2018-02-14 17:33:11 --> Form Validation Class Initialized
INFO - 2018-02-14 17:33:11 --> Model Class Initialized
INFO - 2018-02-14 17:33:11 --> Controller Class Initialized
INFO - 2018-02-14 17:33:11 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-14 17:33:11 --> Model Class Initialized
INFO - 2018-02-14 17:33:11 --> Model Class Initialized
INFO - 2018-02-14 17:33:11 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-14 17:33:11 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-14 17:33:11 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-14 17:33:11 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-14 17:33:11 --> File loaded: /var/www/html/project/radio/application/views/subcategory/add_edit.php
INFO - 2018-02-14 17:33:11 --> Final output sent to browser
DEBUG - 2018-02-14 17:33:11 --> Total execution time: 0.0069
INFO - 2018-02-14 17:34:28 --> Config Class Initialized
INFO - 2018-02-14 17:34:28 --> Hooks Class Initialized
DEBUG - 2018-02-14 17:34:28 --> UTF-8 Support Enabled
INFO - 2018-02-14 17:34:28 --> Utf8 Class Initialized
INFO - 2018-02-14 17:34:28 --> URI Class Initialized
INFO - 2018-02-14 17:34:28 --> Router Class Initialized
INFO - 2018-02-14 17:34:28 --> Output Class Initialized
INFO - 2018-02-14 17:34:28 --> Security Class Initialized
DEBUG - 2018-02-14 17:34:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 17:34:28 --> Input Class Initialized
INFO - 2018-02-14 17:34:28 --> Language Class Initialized
INFO - 2018-02-14 17:34:28 --> Loader Class Initialized
INFO - 2018-02-14 17:34:28 --> Helper loaded: url_helper
INFO - 2018-02-14 17:34:28 --> Helper loaded: file_helper
INFO - 2018-02-14 17:34:28 --> Helper loaded: email_helper
INFO - 2018-02-14 17:34:28 --> Helper loaded: common_helper
INFO - 2018-02-14 17:34:28 --> Database Driver Class Initialized
DEBUG - 2018-02-14 17:34:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 17:34:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 17:34:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-14 17:34:28 --> Pagination Class Initialized
INFO - 2018-02-14 17:34:28 --> Helper loaded: form_helper
INFO - 2018-02-14 17:34:28 --> Form Validation Class Initialized
INFO - 2018-02-14 17:34:28 --> Model Class Initialized
INFO - 2018-02-14 17:34:28 --> Controller Class Initialized
INFO - 2018-02-14 17:34:28 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-14 17:34:28 --> Model Class Initialized
INFO - 2018-02-14 17:34:28 --> Model Class Initialized
INFO - 2018-02-14 17:34:28 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-14 17:34:28 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-14 17:34:28 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-14 17:34:28 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-14 17:34:28 --> File loaded: /var/www/html/project/radio/application/views/subcategory/add_edit.php
INFO - 2018-02-14 17:34:28 --> Final output sent to browser
DEBUG - 2018-02-14 17:34:28 --> Total execution time: 0.0046
INFO - 2018-02-14 17:34:56 --> Config Class Initialized
INFO - 2018-02-14 17:34:56 --> Hooks Class Initialized
DEBUG - 2018-02-14 17:34:56 --> UTF-8 Support Enabled
INFO - 2018-02-14 17:34:56 --> Utf8 Class Initialized
INFO - 2018-02-14 17:34:56 --> URI Class Initialized
INFO - 2018-02-14 17:34:56 --> Router Class Initialized
INFO - 2018-02-14 17:34:56 --> Output Class Initialized
INFO - 2018-02-14 17:34:56 --> Security Class Initialized
DEBUG - 2018-02-14 17:34:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 17:34:56 --> Input Class Initialized
INFO - 2018-02-14 17:34:56 --> Language Class Initialized
INFO - 2018-02-14 17:34:56 --> Loader Class Initialized
INFO - 2018-02-14 17:34:56 --> Helper loaded: url_helper
INFO - 2018-02-14 17:34:56 --> Helper loaded: file_helper
INFO - 2018-02-14 17:34:56 --> Helper loaded: email_helper
INFO - 2018-02-14 17:34:56 --> Helper loaded: common_helper
INFO - 2018-02-14 17:34:56 --> Database Driver Class Initialized
DEBUG - 2018-02-14 17:34:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 17:34:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 17:34:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-14 17:34:56 --> Pagination Class Initialized
INFO - 2018-02-14 17:34:56 --> Helper loaded: form_helper
INFO - 2018-02-14 17:34:56 --> Form Validation Class Initialized
INFO - 2018-02-14 17:34:56 --> Model Class Initialized
INFO - 2018-02-14 17:34:56 --> Controller Class Initialized
INFO - 2018-02-14 17:34:56 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-14 17:34:56 --> Model Class Initialized
INFO - 2018-02-14 17:34:56 --> Model Class Initialized
INFO - 2018-02-14 17:34:56 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-14 17:34:56 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-14 17:34:56 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-14 17:34:56 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-14 17:34:56 --> File loaded: /var/www/html/project/radio/application/views/subcategory/add_edit.php
INFO - 2018-02-14 17:34:56 --> Final output sent to browser
DEBUG - 2018-02-14 17:34:56 --> Total execution time: 0.0077
INFO - 2018-02-14 17:35:26 --> Config Class Initialized
INFO - 2018-02-14 17:35:26 --> Hooks Class Initialized
DEBUG - 2018-02-14 17:35:26 --> UTF-8 Support Enabled
INFO - 2018-02-14 17:35:26 --> Utf8 Class Initialized
INFO - 2018-02-14 17:35:26 --> URI Class Initialized
INFO - 2018-02-14 17:35:26 --> Router Class Initialized
INFO - 2018-02-14 17:35:26 --> Output Class Initialized
INFO - 2018-02-14 17:35:26 --> Security Class Initialized
DEBUG - 2018-02-14 17:35:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 17:35:26 --> Input Class Initialized
INFO - 2018-02-14 17:35:26 --> Language Class Initialized
INFO - 2018-02-14 17:35:26 --> Loader Class Initialized
INFO - 2018-02-14 17:35:26 --> Helper loaded: url_helper
INFO - 2018-02-14 17:35:26 --> Helper loaded: file_helper
INFO - 2018-02-14 17:35:26 --> Helper loaded: email_helper
INFO - 2018-02-14 17:35:26 --> Helper loaded: common_helper
INFO - 2018-02-14 17:35:26 --> Database Driver Class Initialized
DEBUG - 2018-02-14 17:35:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 17:35:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 17:35:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-14 17:35:26 --> Pagination Class Initialized
INFO - 2018-02-14 17:35:26 --> Helper loaded: form_helper
INFO - 2018-02-14 17:35:26 --> Form Validation Class Initialized
INFO - 2018-02-14 17:35:26 --> Model Class Initialized
INFO - 2018-02-14 17:35:26 --> Controller Class Initialized
INFO - 2018-02-14 17:35:26 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-14 17:35:26 --> Model Class Initialized
INFO - 2018-02-14 17:35:26 --> Model Class Initialized
INFO - 2018-02-14 17:35:26 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-14 17:35:26 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-14 17:35:26 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-14 17:35:26 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-14 17:35:26 --> File loaded: /var/www/html/project/radio/application/views/subcategory/add_edit.php
INFO - 2018-02-14 17:35:26 --> Final output sent to browser
DEBUG - 2018-02-14 17:35:26 --> Total execution time: 0.0091
INFO - 2018-02-14 17:38:35 --> Config Class Initialized
INFO - 2018-02-14 17:38:35 --> Hooks Class Initialized
DEBUG - 2018-02-14 17:38:35 --> UTF-8 Support Enabled
INFO - 2018-02-14 17:38:35 --> Utf8 Class Initialized
INFO - 2018-02-14 17:38:35 --> URI Class Initialized
INFO - 2018-02-14 17:38:35 --> Router Class Initialized
INFO - 2018-02-14 17:38:35 --> Output Class Initialized
INFO - 2018-02-14 17:38:35 --> Security Class Initialized
DEBUG - 2018-02-14 17:38:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 17:38:35 --> Input Class Initialized
INFO - 2018-02-14 17:38:35 --> Language Class Initialized
INFO - 2018-02-14 17:38:35 --> Loader Class Initialized
INFO - 2018-02-14 17:38:35 --> Helper loaded: url_helper
INFO - 2018-02-14 17:38:35 --> Helper loaded: file_helper
INFO - 2018-02-14 17:38:35 --> Helper loaded: email_helper
INFO - 2018-02-14 17:38:35 --> Helper loaded: common_helper
INFO - 2018-02-14 17:38:35 --> Database Driver Class Initialized
DEBUG - 2018-02-14 17:38:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 17:38:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 17:38:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-14 17:38:35 --> Pagination Class Initialized
INFO - 2018-02-14 17:38:35 --> Helper loaded: form_helper
INFO - 2018-02-14 17:38:35 --> Form Validation Class Initialized
INFO - 2018-02-14 17:38:35 --> Model Class Initialized
INFO - 2018-02-14 17:38:35 --> Controller Class Initialized
INFO - 2018-02-14 17:38:35 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-14 17:38:35 --> Model Class Initialized
INFO - 2018-02-14 17:38:35 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-14 17:38:35 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-14 17:38:35 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-14 17:38:35 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-14 17:38:35 --> File loaded: /var/www/html/project/radio/application/views/category/index.php
INFO - 2018-02-14 17:38:35 --> Final output sent to browser
DEBUG - 2018-02-14 17:38:35 --> Total execution time: 0.0118
INFO - 2018-02-14 17:38:37 --> Config Class Initialized
INFO - 2018-02-14 17:38:37 --> Hooks Class Initialized
DEBUG - 2018-02-14 17:38:37 --> UTF-8 Support Enabled
INFO - 2018-02-14 17:38:37 --> Utf8 Class Initialized
INFO - 2018-02-14 17:38:37 --> URI Class Initialized
INFO - 2018-02-14 17:38:37 --> Router Class Initialized
INFO - 2018-02-14 17:38:37 --> Output Class Initialized
INFO - 2018-02-14 17:38:37 --> Security Class Initialized
DEBUG - 2018-02-14 17:38:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 17:38:37 --> Input Class Initialized
INFO - 2018-02-14 17:38:37 --> Language Class Initialized
INFO - 2018-02-14 17:38:37 --> Loader Class Initialized
INFO - 2018-02-14 17:38:37 --> Helper loaded: url_helper
INFO - 2018-02-14 17:38:37 --> Helper loaded: file_helper
INFO - 2018-02-14 17:38:37 --> Helper loaded: email_helper
INFO - 2018-02-14 17:38:37 --> Helper loaded: common_helper
INFO - 2018-02-14 17:38:37 --> Database Driver Class Initialized
DEBUG - 2018-02-14 17:38:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 17:38:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 17:38:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-14 17:38:37 --> Pagination Class Initialized
INFO - 2018-02-14 17:38:37 --> Helper loaded: form_helper
INFO - 2018-02-14 17:38:37 --> Form Validation Class Initialized
INFO - 2018-02-14 17:38:37 --> Model Class Initialized
INFO - 2018-02-14 17:38:37 --> Controller Class Initialized
INFO - 2018-02-14 17:38:37 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-14 17:38:37 --> Model Class Initialized
INFO - 2018-02-14 17:38:37 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-14 17:38:37 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-14 17:38:37 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-14 17:38:37 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-14 17:38:37 --> File loaded: /var/www/html/project/radio/application/views/category/add_edit.php
INFO - 2018-02-14 17:38:37 --> Final output sent to browser
DEBUG - 2018-02-14 17:38:37 --> Total execution time: 0.0035
INFO - 2018-02-14 17:38:39 --> Config Class Initialized
INFO - 2018-02-14 17:38:39 --> Hooks Class Initialized
DEBUG - 2018-02-14 17:38:39 --> UTF-8 Support Enabled
INFO - 2018-02-14 17:38:39 --> Utf8 Class Initialized
INFO - 2018-02-14 17:38:39 --> URI Class Initialized
INFO - 2018-02-14 17:38:39 --> Router Class Initialized
INFO - 2018-02-14 17:38:39 --> Output Class Initialized
INFO - 2018-02-14 17:38:39 --> Security Class Initialized
DEBUG - 2018-02-14 17:38:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 17:38:39 --> Input Class Initialized
INFO - 2018-02-14 17:38:39 --> Language Class Initialized
INFO - 2018-02-14 17:38:39 --> Loader Class Initialized
INFO - 2018-02-14 17:38:39 --> Helper loaded: url_helper
INFO - 2018-02-14 17:38:39 --> Helper loaded: file_helper
INFO - 2018-02-14 17:38:39 --> Helper loaded: email_helper
INFO - 2018-02-14 17:38:39 --> Helper loaded: common_helper
INFO - 2018-02-14 17:38:39 --> Database Driver Class Initialized
DEBUG - 2018-02-14 17:38:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 17:38:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 17:38:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-14 17:38:39 --> Pagination Class Initialized
INFO - 2018-02-14 17:38:39 --> Helper loaded: form_helper
INFO - 2018-02-14 17:38:39 --> Form Validation Class Initialized
INFO - 2018-02-14 17:38:39 --> Model Class Initialized
INFO - 2018-02-14 17:38:39 --> Controller Class Initialized
INFO - 2018-02-14 17:38:39 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-14 17:38:39 --> Model Class Initialized
INFO - 2018-02-14 17:38:39 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-14 17:38:39 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-14 17:38:39 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-14 17:38:39 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-14 17:38:39 --> File loaded: /var/www/html/project/radio/application/views/category/add_edit.php
INFO - 2018-02-14 17:38:39 --> Final output sent to browser
DEBUG - 2018-02-14 17:38:39 --> Total execution time: 0.0043
INFO - 2018-02-14 17:38:41 --> Config Class Initialized
INFO - 2018-02-14 17:38:41 --> Hooks Class Initialized
DEBUG - 2018-02-14 17:38:41 --> UTF-8 Support Enabled
INFO - 2018-02-14 17:38:41 --> Utf8 Class Initialized
INFO - 2018-02-14 17:38:41 --> URI Class Initialized
INFO - 2018-02-14 17:38:41 --> Router Class Initialized
INFO - 2018-02-14 17:38:41 --> Output Class Initialized
INFO - 2018-02-14 17:38:41 --> Security Class Initialized
DEBUG - 2018-02-14 17:38:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 17:38:41 --> Input Class Initialized
INFO - 2018-02-14 17:38:41 --> Language Class Initialized
INFO - 2018-02-14 17:38:41 --> Loader Class Initialized
INFO - 2018-02-14 17:38:41 --> Helper loaded: url_helper
INFO - 2018-02-14 17:38:41 --> Helper loaded: file_helper
INFO - 2018-02-14 17:38:41 --> Helper loaded: email_helper
INFO - 2018-02-14 17:38:41 --> Helper loaded: common_helper
INFO - 2018-02-14 17:38:41 --> Database Driver Class Initialized
DEBUG - 2018-02-14 17:38:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 17:38:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 17:38:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-14 17:38:41 --> Pagination Class Initialized
INFO - 2018-02-14 17:38:41 --> Helper loaded: form_helper
INFO - 2018-02-14 17:38:41 --> Form Validation Class Initialized
INFO - 2018-02-14 17:38:41 --> Model Class Initialized
INFO - 2018-02-14 17:38:41 --> Controller Class Initialized
INFO - 2018-02-14 17:38:41 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-14 17:38:41 --> Model Class Initialized
INFO - 2018-02-14 17:38:41 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-14 17:38:41 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-14 17:38:41 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-14 17:38:41 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-14 17:38:41 --> File loaded: /var/www/html/project/radio/application/views/category/add_edit.php
INFO - 2018-02-14 17:38:41 --> Final output sent to browser
DEBUG - 2018-02-14 17:38:41 --> Total execution time: 0.0041
INFO - 2018-02-14 17:38:45 --> Config Class Initialized
INFO - 2018-02-14 17:38:45 --> Hooks Class Initialized
DEBUG - 2018-02-14 17:38:45 --> UTF-8 Support Enabled
INFO - 2018-02-14 17:38:45 --> Utf8 Class Initialized
INFO - 2018-02-14 17:38:45 --> URI Class Initialized
INFO - 2018-02-14 17:38:45 --> Router Class Initialized
INFO - 2018-02-14 17:38:45 --> Output Class Initialized
INFO - 2018-02-14 17:38:45 --> Security Class Initialized
DEBUG - 2018-02-14 17:38:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 17:38:45 --> Input Class Initialized
INFO - 2018-02-14 17:38:45 --> Language Class Initialized
INFO - 2018-02-14 17:38:45 --> Loader Class Initialized
INFO - 2018-02-14 17:38:45 --> Helper loaded: url_helper
INFO - 2018-02-14 17:38:45 --> Helper loaded: file_helper
INFO - 2018-02-14 17:38:45 --> Helper loaded: email_helper
INFO - 2018-02-14 17:38:45 --> Helper loaded: common_helper
INFO - 2018-02-14 17:38:45 --> Database Driver Class Initialized
DEBUG - 2018-02-14 17:38:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 17:38:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 17:38:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-14 17:38:45 --> Pagination Class Initialized
INFO - 2018-02-14 17:38:45 --> Helper loaded: form_helper
INFO - 2018-02-14 17:38:45 --> Form Validation Class Initialized
INFO - 2018-02-14 17:38:45 --> Model Class Initialized
INFO - 2018-02-14 17:38:45 --> Controller Class Initialized
INFO - 2018-02-14 17:38:45 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-14 17:38:45 --> Model Class Initialized
INFO - 2018-02-14 17:38:45 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-14 17:38:45 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-14 17:38:45 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-14 17:38:45 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-14 17:38:45 --> File loaded: /var/www/html/project/radio/application/views/category/add_edit.php
INFO - 2018-02-14 17:38:45 --> Final output sent to browser
DEBUG - 2018-02-14 17:38:45 --> Total execution time: 0.0056
INFO - 2018-02-14 17:39:40 --> Config Class Initialized
INFO - 2018-02-14 17:39:40 --> Hooks Class Initialized
DEBUG - 2018-02-14 17:39:40 --> UTF-8 Support Enabled
INFO - 2018-02-14 17:39:40 --> Utf8 Class Initialized
INFO - 2018-02-14 17:39:40 --> URI Class Initialized
INFO - 2018-02-14 17:39:40 --> Router Class Initialized
INFO - 2018-02-14 17:39:40 --> Output Class Initialized
INFO - 2018-02-14 17:39:40 --> Security Class Initialized
DEBUG - 2018-02-14 17:39:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 17:39:40 --> Input Class Initialized
INFO - 2018-02-14 17:39:40 --> Language Class Initialized
INFO - 2018-02-14 17:39:40 --> Loader Class Initialized
INFO - 2018-02-14 17:39:40 --> Helper loaded: url_helper
INFO - 2018-02-14 17:39:40 --> Helper loaded: file_helper
INFO - 2018-02-14 17:39:40 --> Helper loaded: email_helper
INFO - 2018-02-14 17:39:40 --> Helper loaded: common_helper
INFO - 2018-02-14 17:39:40 --> Database Driver Class Initialized
DEBUG - 2018-02-14 17:39:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 17:39:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 17:39:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-14 17:39:40 --> Pagination Class Initialized
INFO - 2018-02-14 17:39:40 --> Helper loaded: form_helper
INFO - 2018-02-14 17:39:40 --> Form Validation Class Initialized
INFO - 2018-02-14 17:39:40 --> Model Class Initialized
INFO - 2018-02-14 17:39:40 --> Controller Class Initialized
INFO - 2018-02-14 17:39:40 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-14 17:39:40 --> Model Class Initialized
INFO - 2018-02-14 17:39:40 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-14 17:39:40 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-14 17:39:40 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-14 17:39:40 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-14 17:39:40 --> File loaded: /var/www/html/project/radio/application/views/category/add_edit.php
INFO - 2018-02-14 17:39:40 --> Final output sent to browser
DEBUG - 2018-02-14 17:39:40 --> Total execution time: 0.0061
INFO - 2018-02-14 17:40:20 --> Config Class Initialized
INFO - 2018-02-14 17:40:20 --> Hooks Class Initialized
DEBUG - 2018-02-14 17:40:20 --> UTF-8 Support Enabled
INFO - 2018-02-14 17:40:20 --> Utf8 Class Initialized
INFO - 2018-02-14 17:40:20 --> URI Class Initialized
INFO - 2018-02-14 17:40:20 --> Router Class Initialized
INFO - 2018-02-14 17:40:20 --> Output Class Initialized
INFO - 2018-02-14 17:40:20 --> Security Class Initialized
DEBUG - 2018-02-14 17:40:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 17:40:20 --> Input Class Initialized
INFO - 2018-02-14 17:40:20 --> Language Class Initialized
INFO - 2018-02-14 17:40:20 --> Loader Class Initialized
INFO - 2018-02-14 17:40:20 --> Helper loaded: url_helper
INFO - 2018-02-14 17:40:20 --> Helper loaded: file_helper
INFO - 2018-02-14 17:40:20 --> Helper loaded: email_helper
INFO - 2018-02-14 17:40:20 --> Helper loaded: common_helper
INFO - 2018-02-14 17:40:20 --> Database Driver Class Initialized
DEBUG - 2018-02-14 17:40:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 17:40:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 17:40:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-14 17:40:20 --> Pagination Class Initialized
INFO - 2018-02-14 17:40:20 --> Helper loaded: form_helper
INFO - 2018-02-14 17:40:20 --> Form Validation Class Initialized
INFO - 2018-02-14 17:40:20 --> Model Class Initialized
INFO - 2018-02-14 17:40:20 --> Controller Class Initialized
INFO - 2018-02-14 17:40:20 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-14 17:40:20 --> Model Class Initialized
INFO - 2018-02-14 17:40:20 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-14 17:40:20 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-14 17:40:20 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-14 17:40:20 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-14 17:40:20 --> File loaded: /var/www/html/project/radio/application/views/category/add_edit.php
INFO - 2018-02-14 17:40:20 --> Final output sent to browser
DEBUG - 2018-02-14 17:40:20 --> Total execution time: 0.0069
INFO - 2018-02-14 17:40:22 --> Config Class Initialized
INFO - 2018-02-14 17:40:22 --> Hooks Class Initialized
DEBUG - 2018-02-14 17:40:22 --> UTF-8 Support Enabled
INFO - 2018-02-14 17:40:22 --> Utf8 Class Initialized
INFO - 2018-02-14 17:40:22 --> URI Class Initialized
INFO - 2018-02-14 17:40:22 --> Router Class Initialized
INFO - 2018-02-14 17:40:22 --> Output Class Initialized
INFO - 2018-02-14 17:40:22 --> Security Class Initialized
DEBUG - 2018-02-14 17:40:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 17:40:22 --> Input Class Initialized
INFO - 2018-02-14 17:40:22 --> Language Class Initialized
INFO - 2018-02-14 17:40:22 --> Loader Class Initialized
INFO - 2018-02-14 17:40:22 --> Helper loaded: url_helper
INFO - 2018-02-14 17:40:22 --> Helper loaded: file_helper
INFO - 2018-02-14 17:40:22 --> Helper loaded: email_helper
INFO - 2018-02-14 17:40:22 --> Helper loaded: common_helper
INFO - 2018-02-14 17:40:22 --> Database Driver Class Initialized
DEBUG - 2018-02-14 17:40:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 17:40:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 17:40:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-14 17:40:22 --> Pagination Class Initialized
INFO - 2018-02-14 17:40:22 --> Helper loaded: form_helper
INFO - 2018-02-14 17:40:22 --> Form Validation Class Initialized
INFO - 2018-02-14 17:40:22 --> Model Class Initialized
INFO - 2018-02-14 17:40:22 --> Controller Class Initialized
INFO - 2018-02-14 17:40:22 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-14 17:40:22 --> Model Class Initialized
INFO - 2018-02-14 17:40:22 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-14 17:40:22 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-14 17:40:22 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-14 17:40:22 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-14 17:40:22 --> File loaded: /var/www/html/project/radio/application/views/category/add_edit.php
INFO - 2018-02-14 17:40:22 --> Final output sent to browser
DEBUG - 2018-02-14 17:40:22 --> Total execution time: 0.0081
INFO - 2018-02-14 17:40:32 --> Config Class Initialized
INFO - 2018-02-14 17:40:32 --> Hooks Class Initialized
DEBUG - 2018-02-14 17:40:32 --> UTF-8 Support Enabled
INFO - 2018-02-14 17:40:32 --> Utf8 Class Initialized
INFO - 2018-02-14 17:40:32 --> URI Class Initialized
INFO - 2018-02-14 17:40:32 --> Router Class Initialized
INFO - 2018-02-14 17:40:32 --> Output Class Initialized
INFO - 2018-02-14 17:40:32 --> Security Class Initialized
DEBUG - 2018-02-14 17:40:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 17:40:32 --> Input Class Initialized
INFO - 2018-02-14 17:40:32 --> Language Class Initialized
INFO - 2018-02-14 17:40:32 --> Loader Class Initialized
INFO - 2018-02-14 17:40:32 --> Helper loaded: url_helper
INFO - 2018-02-14 17:40:32 --> Helper loaded: file_helper
INFO - 2018-02-14 17:40:32 --> Helper loaded: email_helper
INFO - 2018-02-14 17:40:32 --> Helper loaded: common_helper
INFO - 2018-02-14 17:40:32 --> Database Driver Class Initialized
DEBUG - 2018-02-14 17:40:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 17:40:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 17:40:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-14 17:40:32 --> Pagination Class Initialized
INFO - 2018-02-14 17:40:32 --> Helper loaded: form_helper
INFO - 2018-02-14 17:40:32 --> Form Validation Class Initialized
INFO - 2018-02-14 17:40:32 --> Model Class Initialized
INFO - 2018-02-14 17:40:32 --> Controller Class Initialized
INFO - 2018-02-14 17:40:32 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-14 17:40:32 --> Model Class Initialized
INFO - 2018-02-14 17:40:32 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-14 17:40:32 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-14 17:40:32 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-14 17:40:32 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-14 17:40:32 --> File loaded: /var/www/html/project/radio/application/views/category/add_edit.php
INFO - 2018-02-14 17:40:32 --> Final output sent to browser
DEBUG - 2018-02-14 17:40:32 --> Total execution time: 0.0056
INFO - 2018-02-14 17:40:35 --> Config Class Initialized
INFO - 2018-02-14 17:40:35 --> Hooks Class Initialized
DEBUG - 2018-02-14 17:40:35 --> UTF-8 Support Enabled
INFO - 2018-02-14 17:40:35 --> Utf8 Class Initialized
INFO - 2018-02-14 17:40:35 --> URI Class Initialized
INFO - 2018-02-14 17:40:35 --> Router Class Initialized
INFO - 2018-02-14 17:40:35 --> Output Class Initialized
INFO - 2018-02-14 17:40:35 --> Security Class Initialized
DEBUG - 2018-02-14 17:40:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 17:40:35 --> Input Class Initialized
INFO - 2018-02-14 17:40:35 --> Language Class Initialized
INFO - 2018-02-14 17:40:35 --> Loader Class Initialized
INFO - 2018-02-14 17:40:35 --> Helper loaded: url_helper
INFO - 2018-02-14 17:40:35 --> Helper loaded: file_helper
INFO - 2018-02-14 17:40:35 --> Helper loaded: email_helper
INFO - 2018-02-14 17:40:35 --> Helper loaded: common_helper
INFO - 2018-02-14 17:40:35 --> Database Driver Class Initialized
DEBUG - 2018-02-14 17:40:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 17:40:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 17:40:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-14 17:40:35 --> Pagination Class Initialized
INFO - 2018-02-14 17:40:35 --> Helper loaded: form_helper
INFO - 2018-02-14 17:40:35 --> Form Validation Class Initialized
INFO - 2018-02-14 17:40:35 --> Model Class Initialized
INFO - 2018-02-14 17:40:35 --> Controller Class Initialized
INFO - 2018-02-14 17:40:35 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-14 17:40:35 --> Model Class Initialized
INFO - 2018-02-14 17:40:35 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-14 17:40:35 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-14 17:40:35 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-14 17:40:35 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-14 17:40:35 --> File loaded: /var/www/html/project/radio/application/views/category/add_edit.php
INFO - 2018-02-14 17:40:35 --> Final output sent to browser
DEBUG - 2018-02-14 17:40:35 --> Total execution time: 0.0065
INFO - 2018-02-14 17:41:44 --> Config Class Initialized
INFO - 2018-02-14 17:41:44 --> Hooks Class Initialized
DEBUG - 2018-02-14 17:41:44 --> UTF-8 Support Enabled
INFO - 2018-02-14 17:41:44 --> Utf8 Class Initialized
INFO - 2018-02-14 17:41:44 --> URI Class Initialized
INFO - 2018-02-14 17:41:44 --> Router Class Initialized
INFO - 2018-02-14 17:41:44 --> Output Class Initialized
INFO - 2018-02-14 17:41:44 --> Security Class Initialized
DEBUG - 2018-02-14 17:41:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 17:41:44 --> Input Class Initialized
INFO - 2018-02-14 17:41:44 --> Language Class Initialized
INFO - 2018-02-14 17:41:44 --> Loader Class Initialized
INFO - 2018-02-14 17:41:44 --> Helper loaded: url_helper
INFO - 2018-02-14 17:41:44 --> Helper loaded: file_helper
INFO - 2018-02-14 17:41:44 --> Helper loaded: email_helper
INFO - 2018-02-14 17:41:44 --> Helper loaded: common_helper
INFO - 2018-02-14 17:41:44 --> Database Driver Class Initialized
DEBUG - 2018-02-14 17:41:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 17:41:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 17:41:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-14 17:41:44 --> Pagination Class Initialized
INFO - 2018-02-14 17:41:44 --> Helper loaded: form_helper
INFO - 2018-02-14 17:41:44 --> Form Validation Class Initialized
INFO - 2018-02-14 17:41:44 --> Model Class Initialized
INFO - 2018-02-14 17:41:44 --> Controller Class Initialized
INFO - 2018-02-14 17:41:44 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-14 17:41:44 --> Model Class Initialized
INFO - 2018-02-14 17:41:44 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-14 17:41:44 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-14 17:41:44 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-14 17:41:44 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-14 17:41:44 --> File loaded: /var/www/html/project/radio/application/views/category/add_edit.php
INFO - 2018-02-14 17:41:44 --> Final output sent to browser
DEBUG - 2018-02-14 17:41:44 --> Total execution time: 0.0041
INFO - 2018-02-14 17:41:46 --> Config Class Initialized
INFO - 2018-02-14 17:41:46 --> Hooks Class Initialized
DEBUG - 2018-02-14 17:41:46 --> UTF-8 Support Enabled
INFO - 2018-02-14 17:41:46 --> Utf8 Class Initialized
INFO - 2018-02-14 17:41:46 --> URI Class Initialized
INFO - 2018-02-14 17:41:46 --> Router Class Initialized
INFO - 2018-02-14 17:41:46 --> Output Class Initialized
INFO - 2018-02-14 17:41:46 --> Security Class Initialized
DEBUG - 2018-02-14 17:41:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 17:41:46 --> Input Class Initialized
INFO - 2018-02-14 17:41:46 --> Language Class Initialized
INFO - 2018-02-14 17:41:46 --> Loader Class Initialized
INFO - 2018-02-14 17:41:46 --> Helper loaded: url_helper
INFO - 2018-02-14 17:41:46 --> Helper loaded: file_helper
INFO - 2018-02-14 17:41:46 --> Helper loaded: email_helper
INFO - 2018-02-14 17:41:46 --> Helper loaded: common_helper
INFO - 2018-02-14 17:41:46 --> Database Driver Class Initialized
DEBUG - 2018-02-14 17:41:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 17:41:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 17:41:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-14 17:41:46 --> Pagination Class Initialized
INFO - 2018-02-14 17:41:46 --> Helper loaded: form_helper
INFO - 2018-02-14 17:41:46 --> Form Validation Class Initialized
INFO - 2018-02-14 17:41:46 --> Model Class Initialized
INFO - 2018-02-14 17:41:46 --> Controller Class Initialized
INFO - 2018-02-14 17:41:46 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-14 17:41:46 --> Model Class Initialized
INFO - 2018-02-14 17:41:46 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-14 17:41:46 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-14 17:41:46 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-14 17:41:46 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-14 17:41:46 --> File loaded: /var/www/html/project/radio/application/views/category/add_edit.php
INFO - 2018-02-14 17:41:46 --> Final output sent to browser
DEBUG - 2018-02-14 17:41:46 --> Total execution time: 0.0051
INFO - 2018-02-14 17:41:57 --> Config Class Initialized
INFO - 2018-02-14 17:41:57 --> Hooks Class Initialized
DEBUG - 2018-02-14 17:41:57 --> UTF-8 Support Enabled
INFO - 2018-02-14 17:41:57 --> Utf8 Class Initialized
INFO - 2018-02-14 17:41:57 --> URI Class Initialized
INFO - 2018-02-14 17:41:57 --> Router Class Initialized
INFO - 2018-02-14 17:41:57 --> Output Class Initialized
INFO - 2018-02-14 17:41:57 --> Security Class Initialized
DEBUG - 2018-02-14 17:41:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 17:41:57 --> Input Class Initialized
INFO - 2018-02-14 17:41:57 --> Language Class Initialized
INFO - 2018-02-14 17:41:57 --> Loader Class Initialized
INFO - 2018-02-14 17:41:57 --> Helper loaded: url_helper
INFO - 2018-02-14 17:41:57 --> Helper loaded: file_helper
INFO - 2018-02-14 17:41:57 --> Helper loaded: email_helper
INFO - 2018-02-14 17:41:57 --> Helper loaded: common_helper
INFO - 2018-02-14 17:41:57 --> Database Driver Class Initialized
DEBUG - 2018-02-14 17:41:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 17:41:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 17:41:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-14 17:41:57 --> Pagination Class Initialized
INFO - 2018-02-14 17:41:57 --> Helper loaded: form_helper
INFO - 2018-02-14 17:41:57 --> Form Validation Class Initialized
INFO - 2018-02-14 17:41:57 --> Model Class Initialized
INFO - 2018-02-14 17:41:57 --> Controller Class Initialized
INFO - 2018-02-14 17:41:57 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-14 17:41:57 --> Model Class Initialized
INFO - 2018-02-14 17:41:57 --> Model Class Initialized
INFO - 2018-02-14 17:41:57 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-14 17:41:57 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-14 17:41:57 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-14 17:41:57 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-14 17:41:57 --> File loaded: /var/www/html/project/radio/application/views/subcategory/index.php
INFO - 2018-02-14 17:41:57 --> Final output sent to browser
DEBUG - 2018-02-14 17:41:57 --> Total execution time: 0.0104
INFO - 2018-02-14 17:41:59 --> Config Class Initialized
INFO - 2018-02-14 17:41:59 --> Hooks Class Initialized
DEBUG - 2018-02-14 17:41:59 --> UTF-8 Support Enabled
INFO - 2018-02-14 17:41:59 --> Utf8 Class Initialized
INFO - 2018-02-14 17:41:59 --> URI Class Initialized
INFO - 2018-02-14 17:41:59 --> Router Class Initialized
INFO - 2018-02-14 17:41:59 --> Output Class Initialized
INFO - 2018-02-14 17:41:59 --> Security Class Initialized
DEBUG - 2018-02-14 17:41:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 17:41:59 --> Input Class Initialized
INFO - 2018-02-14 17:41:59 --> Language Class Initialized
INFO - 2018-02-14 17:41:59 --> Loader Class Initialized
INFO - 2018-02-14 17:41:59 --> Helper loaded: url_helper
INFO - 2018-02-14 17:41:59 --> Helper loaded: file_helper
INFO - 2018-02-14 17:41:59 --> Helper loaded: email_helper
INFO - 2018-02-14 17:41:59 --> Helper loaded: common_helper
INFO - 2018-02-14 17:41:59 --> Database Driver Class Initialized
DEBUG - 2018-02-14 17:41:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 17:41:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 17:41:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-14 17:41:59 --> Pagination Class Initialized
INFO - 2018-02-14 17:41:59 --> Helper loaded: form_helper
INFO - 2018-02-14 17:41:59 --> Form Validation Class Initialized
INFO - 2018-02-14 17:41:59 --> Model Class Initialized
INFO - 2018-02-14 17:41:59 --> Controller Class Initialized
INFO - 2018-02-14 17:41:59 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-14 17:41:59 --> Model Class Initialized
INFO - 2018-02-14 17:41:59 --> Model Class Initialized
INFO - 2018-02-14 17:41:59 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-14 17:41:59 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-14 17:41:59 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-14 17:41:59 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-14 17:41:59 --> File loaded: /var/www/html/project/radio/application/views/subcategory/add_edit.php
INFO - 2018-02-14 17:41:59 --> Final output sent to browser
DEBUG - 2018-02-14 17:41:59 --> Total execution time: 0.0065
INFO - 2018-02-14 17:42:26 --> Config Class Initialized
INFO - 2018-02-14 17:42:26 --> Hooks Class Initialized
DEBUG - 2018-02-14 17:42:26 --> UTF-8 Support Enabled
INFO - 2018-02-14 17:42:26 --> Utf8 Class Initialized
INFO - 2018-02-14 17:42:26 --> URI Class Initialized
INFO - 2018-02-14 17:42:26 --> Router Class Initialized
INFO - 2018-02-14 17:42:26 --> Output Class Initialized
INFO - 2018-02-14 17:42:26 --> Security Class Initialized
DEBUG - 2018-02-14 17:42:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 17:42:26 --> Input Class Initialized
INFO - 2018-02-14 17:42:26 --> Language Class Initialized
INFO - 2018-02-14 17:42:26 --> Loader Class Initialized
INFO - 2018-02-14 17:42:26 --> Helper loaded: url_helper
INFO - 2018-02-14 17:42:26 --> Helper loaded: file_helper
INFO - 2018-02-14 17:42:26 --> Helper loaded: email_helper
INFO - 2018-02-14 17:42:26 --> Helper loaded: common_helper
INFO - 2018-02-14 17:42:26 --> Database Driver Class Initialized
DEBUG - 2018-02-14 17:42:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 17:42:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 17:42:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-14 17:42:26 --> Pagination Class Initialized
INFO - 2018-02-14 17:42:26 --> Helper loaded: form_helper
INFO - 2018-02-14 17:42:26 --> Form Validation Class Initialized
INFO - 2018-02-14 17:42:26 --> Model Class Initialized
INFO - 2018-02-14 17:42:26 --> Controller Class Initialized
INFO - 2018-02-14 17:42:26 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-14 17:42:26 --> Model Class Initialized
INFO - 2018-02-14 17:42:26 --> Model Class Initialized
INFO - 2018-02-14 17:42:26 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-14 17:42:26 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-14 17:42:26 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-14 17:42:26 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-14 17:42:26 --> File loaded: /var/www/html/project/radio/application/views/subcategory/add_edit.php
INFO - 2018-02-14 17:42:26 --> Final output sent to browser
DEBUG - 2018-02-14 17:42:26 --> Total execution time: 0.0120
INFO - 2018-02-14 17:49:44 --> Config Class Initialized
INFO - 2018-02-14 17:49:44 --> Hooks Class Initialized
DEBUG - 2018-02-14 17:49:44 --> UTF-8 Support Enabled
INFO - 2018-02-14 17:49:44 --> Utf8 Class Initialized
INFO - 2018-02-14 17:49:44 --> URI Class Initialized
INFO - 2018-02-14 17:49:44 --> Router Class Initialized
INFO - 2018-02-14 17:49:44 --> Output Class Initialized
INFO - 2018-02-14 17:49:44 --> Security Class Initialized
DEBUG - 2018-02-14 17:49:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 17:49:44 --> Input Class Initialized
INFO - 2018-02-14 17:49:44 --> Language Class Initialized
INFO - 2018-02-14 17:49:44 --> Loader Class Initialized
INFO - 2018-02-14 17:49:44 --> Helper loaded: url_helper
INFO - 2018-02-14 17:49:44 --> Helper loaded: file_helper
INFO - 2018-02-14 17:49:44 --> Helper loaded: email_helper
INFO - 2018-02-14 17:49:44 --> Helper loaded: common_helper
INFO - 2018-02-14 17:49:44 --> Database Driver Class Initialized
DEBUG - 2018-02-14 17:49:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 17:49:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 17:49:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-14 17:49:44 --> Pagination Class Initialized
INFO - 2018-02-14 17:49:44 --> Helper loaded: form_helper
INFO - 2018-02-14 17:49:44 --> Form Validation Class Initialized
INFO - 2018-02-14 17:49:44 --> Model Class Initialized
INFO - 2018-02-14 17:49:44 --> Controller Class Initialized
INFO - 2018-02-14 17:49:44 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-14 17:49:44 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-14 17:49:44 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-14 17:49:44 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-14 17:49:44 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-14 17:49:44 --> File loaded: /var/www/html/project/radio/application/views/dashboard/index.php
INFO - 2018-02-14 17:49:44 --> Final output sent to browser
DEBUG - 2018-02-14 17:49:44 --> Total execution time: 0.0055
INFO - 2018-02-14 17:49:47 --> Config Class Initialized
INFO - 2018-02-14 17:49:47 --> Hooks Class Initialized
DEBUG - 2018-02-14 17:49:47 --> UTF-8 Support Enabled
INFO - 2018-02-14 17:49:47 --> Utf8 Class Initialized
INFO - 2018-02-14 17:49:47 --> URI Class Initialized
INFO - 2018-02-14 17:49:47 --> Router Class Initialized
INFO - 2018-02-14 17:49:47 --> Output Class Initialized
INFO - 2018-02-14 17:49:47 --> Security Class Initialized
DEBUG - 2018-02-14 17:49:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 17:49:47 --> Input Class Initialized
INFO - 2018-02-14 17:49:47 --> Language Class Initialized
INFO - 2018-02-14 17:49:47 --> Loader Class Initialized
INFO - 2018-02-14 17:49:47 --> Helper loaded: url_helper
INFO - 2018-02-14 17:49:47 --> Helper loaded: file_helper
INFO - 2018-02-14 17:49:47 --> Helper loaded: email_helper
INFO - 2018-02-14 17:49:47 --> Helper loaded: common_helper
INFO - 2018-02-14 17:49:47 --> Database Driver Class Initialized
DEBUG - 2018-02-14 17:49:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 17:49:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 17:49:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-14 17:49:47 --> Pagination Class Initialized
INFO - 2018-02-14 17:49:47 --> Helper loaded: form_helper
INFO - 2018-02-14 17:49:47 --> Form Validation Class Initialized
INFO - 2018-02-14 17:49:47 --> Model Class Initialized
INFO - 2018-02-14 17:49:47 --> Controller Class Initialized
INFO - 2018-02-14 17:49:47 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-14 17:49:47 --> Model Class Initialized
INFO - 2018-02-14 17:49:47 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-14 17:49:47 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-14 17:49:47 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-14 17:49:47 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-14 17:49:47 --> File loaded: /var/www/html/project/radio/application/views/category/index.php
INFO - 2018-02-14 17:49:47 --> Final output sent to browser
DEBUG - 2018-02-14 17:49:47 --> Total execution time: 0.0072
INFO - 2018-02-14 17:54:39 --> Config Class Initialized
INFO - 2018-02-14 17:54:39 --> Hooks Class Initialized
DEBUG - 2018-02-14 17:54:39 --> UTF-8 Support Enabled
INFO - 2018-02-14 17:54:39 --> Utf8 Class Initialized
INFO - 2018-02-14 17:54:39 --> URI Class Initialized
INFO - 2018-02-14 17:54:39 --> Router Class Initialized
INFO - 2018-02-14 17:54:39 --> Output Class Initialized
INFO - 2018-02-14 17:54:39 --> Security Class Initialized
DEBUG - 2018-02-14 17:54:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 17:54:39 --> Input Class Initialized
INFO - 2018-02-14 17:54:39 --> Language Class Initialized
INFO - 2018-02-14 17:54:39 --> Loader Class Initialized
INFO - 2018-02-14 17:54:39 --> Helper loaded: url_helper
INFO - 2018-02-14 17:54:39 --> Helper loaded: file_helper
INFO - 2018-02-14 17:54:39 --> Helper loaded: email_helper
INFO - 2018-02-14 17:54:39 --> Helper loaded: common_helper
INFO - 2018-02-14 17:54:39 --> Database Driver Class Initialized
DEBUG - 2018-02-14 17:54:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 17:54:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 17:54:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-14 17:54:39 --> Pagination Class Initialized
INFO - 2018-02-14 17:54:39 --> Helper loaded: form_helper
INFO - 2018-02-14 17:54:39 --> Form Validation Class Initialized
INFO - 2018-02-14 17:54:39 --> Model Class Initialized
INFO - 2018-02-14 17:54:39 --> Controller Class Initialized
INFO - 2018-02-14 17:54:39 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-14 17:54:39 --> Model Class Initialized
INFO - 2018-02-14 17:54:39 --> Model Class Initialized
INFO - 2018-02-14 17:54:39 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-14 17:54:39 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-14 17:54:39 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-14 17:54:39 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-14 17:54:39 --> File loaded: /var/www/html/project/radio/application/views/subcategory/index.php
INFO - 2018-02-14 17:54:39 --> Final output sent to browser
DEBUG - 2018-02-14 17:54:39 --> Total execution time: 0.0081
INFO - 2018-02-14 17:54:40 --> Config Class Initialized
INFO - 2018-02-14 17:54:40 --> Hooks Class Initialized
DEBUG - 2018-02-14 17:54:40 --> UTF-8 Support Enabled
INFO - 2018-02-14 17:54:40 --> Utf8 Class Initialized
INFO - 2018-02-14 17:54:40 --> URI Class Initialized
INFO - 2018-02-14 17:54:40 --> Router Class Initialized
INFO - 2018-02-14 17:54:40 --> Output Class Initialized
INFO - 2018-02-14 17:54:40 --> Security Class Initialized
DEBUG - 2018-02-14 17:54:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 17:54:40 --> Input Class Initialized
INFO - 2018-02-14 17:54:40 --> Language Class Initialized
INFO - 2018-02-14 17:54:40 --> Loader Class Initialized
INFO - 2018-02-14 17:54:40 --> Helper loaded: url_helper
INFO - 2018-02-14 17:54:40 --> Helper loaded: file_helper
INFO - 2018-02-14 17:54:40 --> Helper loaded: email_helper
INFO - 2018-02-14 17:54:40 --> Helper loaded: common_helper
INFO - 2018-02-14 17:54:40 --> Database Driver Class Initialized
DEBUG - 2018-02-14 17:54:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 17:54:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 17:54:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-14 17:54:40 --> Pagination Class Initialized
INFO - 2018-02-14 17:54:40 --> Helper loaded: form_helper
INFO - 2018-02-14 17:54:40 --> Form Validation Class Initialized
INFO - 2018-02-14 17:54:40 --> Model Class Initialized
INFO - 2018-02-14 17:54:40 --> Controller Class Initialized
INFO - 2018-02-14 17:54:40 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-14 17:54:40 --> Model Class Initialized
INFO - 2018-02-14 17:54:40 --> Model Class Initialized
INFO - 2018-02-14 17:54:40 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-14 17:54:40 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-14 17:54:40 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-14 17:54:40 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-14 17:54:40 --> File loaded: /var/www/html/project/radio/application/views/subcategory/add_edit.php
INFO - 2018-02-14 17:54:40 --> Final output sent to browser
DEBUG - 2018-02-14 17:54:40 --> Total execution time: 0.0100
INFO - 2018-02-14 17:55:00 --> Config Class Initialized
INFO - 2018-02-14 17:55:00 --> Hooks Class Initialized
DEBUG - 2018-02-14 17:55:00 --> UTF-8 Support Enabled
INFO - 2018-02-14 17:55:00 --> Utf8 Class Initialized
INFO - 2018-02-14 17:55:00 --> URI Class Initialized
INFO - 2018-02-14 17:55:00 --> Router Class Initialized
INFO - 2018-02-14 17:55:00 --> Output Class Initialized
INFO - 2018-02-14 17:55:00 --> Security Class Initialized
DEBUG - 2018-02-14 17:55:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 17:55:00 --> Input Class Initialized
INFO - 2018-02-14 17:55:00 --> Language Class Initialized
INFO - 2018-02-14 17:55:00 --> Loader Class Initialized
INFO - 2018-02-14 17:55:00 --> Helper loaded: url_helper
INFO - 2018-02-14 17:55:00 --> Helper loaded: file_helper
INFO - 2018-02-14 17:55:00 --> Helper loaded: email_helper
INFO - 2018-02-14 17:55:00 --> Helper loaded: common_helper
INFO - 2018-02-14 17:55:00 --> Database Driver Class Initialized
DEBUG - 2018-02-14 17:55:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 17:55:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 17:55:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-14 17:55:00 --> Pagination Class Initialized
INFO - 2018-02-14 17:55:00 --> Helper loaded: form_helper
INFO - 2018-02-14 17:55:00 --> Form Validation Class Initialized
INFO - 2018-02-14 17:55:00 --> Model Class Initialized
INFO - 2018-02-14 17:55:00 --> Controller Class Initialized
INFO - 2018-02-14 17:55:00 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-14 17:55:00 --> Model Class Initialized
INFO - 2018-02-14 17:55:00 --> Model Class Initialized
INFO - 2018-02-14 17:55:00 --> Config Class Initialized
INFO - 2018-02-14 17:55:00 --> Hooks Class Initialized
DEBUG - 2018-02-14 17:55:00 --> UTF-8 Support Enabled
INFO - 2018-02-14 17:55:00 --> Utf8 Class Initialized
INFO - 2018-02-14 17:55:00 --> URI Class Initialized
INFO - 2018-02-14 17:55:00 --> Router Class Initialized
INFO - 2018-02-14 17:55:00 --> Output Class Initialized
INFO - 2018-02-14 17:55:00 --> Security Class Initialized
DEBUG - 2018-02-14 17:55:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 17:55:00 --> Input Class Initialized
INFO - 2018-02-14 17:55:00 --> Language Class Initialized
INFO - 2018-02-14 17:55:00 --> Loader Class Initialized
INFO - 2018-02-14 17:55:00 --> Helper loaded: url_helper
INFO - 2018-02-14 17:55:00 --> Helper loaded: file_helper
INFO - 2018-02-14 17:55:00 --> Helper loaded: email_helper
INFO - 2018-02-14 17:55:00 --> Helper loaded: common_helper
INFO - 2018-02-14 17:55:00 --> Database Driver Class Initialized
DEBUG - 2018-02-14 17:55:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 17:55:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 17:55:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-14 17:55:00 --> Pagination Class Initialized
INFO - 2018-02-14 17:55:00 --> Helper loaded: form_helper
INFO - 2018-02-14 17:55:00 --> Form Validation Class Initialized
INFO - 2018-02-14 17:55:00 --> Model Class Initialized
INFO - 2018-02-14 17:55:00 --> Controller Class Initialized
INFO - 2018-02-14 17:55:00 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-14 17:55:00 --> Model Class Initialized
INFO - 2018-02-14 17:55:00 --> Model Class Initialized
DEBUG - 2018-02-14 17:55:00 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-14 17:55:00 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-02-14 17:55:00 --> Config Class Initialized
INFO - 2018-02-14 17:55:00 --> Hooks Class Initialized
DEBUG - 2018-02-14 17:55:00 --> UTF-8 Support Enabled
INFO - 2018-02-14 17:55:00 --> Utf8 Class Initialized
INFO - 2018-02-14 17:55:00 --> URI Class Initialized
INFO - 2018-02-14 17:55:00 --> Router Class Initialized
INFO - 2018-02-14 17:55:00 --> Output Class Initialized
INFO - 2018-02-14 17:55:00 --> Security Class Initialized
DEBUG - 2018-02-14 17:55:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 17:55:00 --> Input Class Initialized
INFO - 2018-02-14 17:55:00 --> Language Class Initialized
INFO - 2018-02-14 17:55:00 --> Loader Class Initialized
INFO - 2018-02-14 17:55:00 --> Helper loaded: url_helper
INFO - 2018-02-14 17:55:00 --> Helper loaded: file_helper
INFO - 2018-02-14 17:55:00 --> Helper loaded: email_helper
INFO - 2018-02-14 17:55:00 --> Helper loaded: common_helper
INFO - 2018-02-14 17:55:00 --> Database Driver Class Initialized
DEBUG - 2018-02-14 17:55:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 17:55:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 17:55:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-14 17:55:00 --> Pagination Class Initialized
INFO - 2018-02-14 17:55:00 --> Helper loaded: form_helper
INFO - 2018-02-14 17:55:00 --> Form Validation Class Initialized
INFO - 2018-02-14 17:55:00 --> Model Class Initialized
INFO - 2018-02-14 17:55:00 --> Controller Class Initialized
INFO - 2018-02-14 17:55:00 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-14 17:55:00 --> Model Class Initialized
INFO - 2018-02-14 17:55:00 --> Model Class Initialized
INFO - 2018-02-14 17:55:00 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-14 17:55:00 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-14 17:55:00 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-14 17:55:00 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-14 17:55:00 --> File loaded: /var/www/html/project/radio/application/views/subcategory/index.php
INFO - 2018-02-14 17:55:00 --> Final output sent to browser
DEBUG - 2018-02-14 17:55:00 --> Total execution time: 0.0059
INFO - 2018-02-14 17:55:06 --> Config Class Initialized
INFO - 2018-02-14 17:55:06 --> Hooks Class Initialized
DEBUG - 2018-02-14 17:55:06 --> UTF-8 Support Enabled
INFO - 2018-02-14 17:55:06 --> Utf8 Class Initialized
INFO - 2018-02-14 17:55:06 --> URI Class Initialized
INFO - 2018-02-14 17:55:06 --> Router Class Initialized
INFO - 2018-02-14 17:55:06 --> Output Class Initialized
INFO - 2018-02-14 17:55:06 --> Security Class Initialized
DEBUG - 2018-02-14 17:55:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 17:55:06 --> Input Class Initialized
INFO - 2018-02-14 17:55:06 --> Language Class Initialized
INFO - 2018-02-14 17:55:06 --> Loader Class Initialized
INFO - 2018-02-14 17:55:06 --> Helper loaded: url_helper
INFO - 2018-02-14 17:55:06 --> Helper loaded: file_helper
INFO - 2018-02-14 17:55:06 --> Helper loaded: email_helper
INFO - 2018-02-14 17:55:06 --> Helper loaded: common_helper
INFO - 2018-02-14 17:55:06 --> Database Driver Class Initialized
DEBUG - 2018-02-14 17:55:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 17:55:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 17:55:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-14 17:55:06 --> Pagination Class Initialized
INFO - 2018-02-14 17:55:06 --> Helper loaded: form_helper
INFO - 2018-02-14 17:55:06 --> Form Validation Class Initialized
INFO - 2018-02-14 17:55:06 --> Model Class Initialized
INFO - 2018-02-14 17:55:06 --> Controller Class Initialized
INFO - 2018-02-14 17:55:06 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-14 17:55:06 --> Model Class Initialized
INFO - 2018-02-14 17:55:06 --> Model Class Initialized
INFO - 2018-02-14 17:55:06 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-14 17:55:06 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-14 17:55:06 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-14 17:55:06 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-14 17:55:06 --> File loaded: /var/www/html/project/radio/application/views/subcategory/add_edit.php
INFO - 2018-02-14 17:55:06 --> Final output sent to browser
DEBUG - 2018-02-14 17:55:06 --> Total execution time: 0.0106
INFO - 2018-02-14 17:55:13 --> Config Class Initialized
INFO - 2018-02-14 17:55:13 --> Hooks Class Initialized
DEBUG - 2018-02-14 17:55:13 --> UTF-8 Support Enabled
INFO - 2018-02-14 17:55:13 --> Utf8 Class Initialized
INFO - 2018-02-14 17:55:13 --> URI Class Initialized
INFO - 2018-02-14 17:55:13 --> Router Class Initialized
INFO - 2018-02-14 17:55:13 --> Output Class Initialized
INFO - 2018-02-14 17:55:13 --> Security Class Initialized
DEBUG - 2018-02-14 17:55:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 17:55:13 --> Input Class Initialized
INFO - 2018-02-14 17:55:13 --> Language Class Initialized
INFO - 2018-02-14 17:55:13 --> Loader Class Initialized
INFO - 2018-02-14 17:55:13 --> Helper loaded: url_helper
INFO - 2018-02-14 17:55:13 --> Helper loaded: file_helper
INFO - 2018-02-14 17:55:13 --> Helper loaded: email_helper
INFO - 2018-02-14 17:55:13 --> Helper loaded: common_helper
INFO - 2018-02-14 17:55:13 --> Database Driver Class Initialized
DEBUG - 2018-02-14 17:55:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 17:55:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 17:55:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-14 17:55:13 --> Pagination Class Initialized
INFO - 2018-02-14 17:55:13 --> Helper loaded: form_helper
INFO - 2018-02-14 17:55:13 --> Form Validation Class Initialized
INFO - 2018-02-14 17:55:13 --> Model Class Initialized
INFO - 2018-02-14 17:55:13 --> Controller Class Initialized
INFO - 2018-02-14 17:55:13 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-14 17:55:13 --> Model Class Initialized
INFO - 2018-02-14 17:55:13 --> Model Class Initialized
INFO - 2018-02-14 17:55:32 --> Config Class Initialized
INFO - 2018-02-14 17:55:32 --> Hooks Class Initialized
DEBUG - 2018-02-14 17:55:32 --> UTF-8 Support Enabled
INFO - 2018-02-14 17:55:32 --> Utf8 Class Initialized
INFO - 2018-02-14 17:55:32 --> URI Class Initialized
INFO - 2018-02-14 17:55:32 --> Router Class Initialized
INFO - 2018-02-14 17:55:32 --> Output Class Initialized
INFO - 2018-02-14 17:55:32 --> Security Class Initialized
DEBUG - 2018-02-14 17:55:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 17:55:32 --> Input Class Initialized
INFO - 2018-02-14 17:55:32 --> Language Class Initialized
INFO - 2018-02-14 17:55:32 --> Loader Class Initialized
INFO - 2018-02-14 17:55:32 --> Helper loaded: url_helper
INFO - 2018-02-14 17:55:32 --> Helper loaded: file_helper
INFO - 2018-02-14 17:55:32 --> Helper loaded: email_helper
INFO - 2018-02-14 17:55:32 --> Helper loaded: common_helper
INFO - 2018-02-14 17:55:32 --> Database Driver Class Initialized
DEBUG - 2018-02-14 17:55:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 17:55:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 17:55:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-14 17:55:32 --> Pagination Class Initialized
INFO - 2018-02-14 17:55:32 --> Helper loaded: form_helper
INFO - 2018-02-14 17:55:32 --> Form Validation Class Initialized
INFO - 2018-02-14 17:55:32 --> Model Class Initialized
INFO - 2018-02-14 17:55:32 --> Controller Class Initialized
INFO - 2018-02-14 17:55:32 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-14 17:55:32 --> Model Class Initialized
INFO - 2018-02-14 17:55:32 --> Model Class Initialized
INFO - 2018-02-14 17:55:32 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-14 17:55:32 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-14 17:55:32 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-14 17:55:32 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-14 17:55:32 --> File loaded: /var/www/html/project/radio/application/views/subcategory/index.php
INFO - 2018-02-14 17:55:32 --> Final output sent to browser
DEBUG - 2018-02-14 17:55:32 --> Total execution time: 0.0070
INFO - 2018-02-14 17:55:36 --> Config Class Initialized
INFO - 2018-02-14 17:55:36 --> Hooks Class Initialized
DEBUG - 2018-02-14 17:55:36 --> UTF-8 Support Enabled
INFO - 2018-02-14 17:55:36 --> Utf8 Class Initialized
INFO - 2018-02-14 17:55:36 --> URI Class Initialized
INFO - 2018-02-14 17:55:36 --> Router Class Initialized
INFO - 2018-02-14 17:55:36 --> Output Class Initialized
INFO - 2018-02-14 17:55:36 --> Security Class Initialized
DEBUG - 2018-02-14 17:55:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 17:55:36 --> Input Class Initialized
INFO - 2018-02-14 17:55:36 --> Language Class Initialized
INFO - 2018-02-14 17:55:36 --> Loader Class Initialized
INFO - 2018-02-14 17:55:36 --> Helper loaded: url_helper
INFO - 2018-02-14 17:55:36 --> Helper loaded: file_helper
INFO - 2018-02-14 17:55:36 --> Helper loaded: email_helper
INFO - 2018-02-14 17:55:36 --> Helper loaded: common_helper
INFO - 2018-02-14 17:55:36 --> Database Driver Class Initialized
DEBUG - 2018-02-14 17:55:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 17:55:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 17:55:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-14 17:55:36 --> Pagination Class Initialized
INFO - 2018-02-14 17:55:36 --> Helper loaded: form_helper
INFO - 2018-02-14 17:55:36 --> Form Validation Class Initialized
INFO - 2018-02-14 17:55:36 --> Model Class Initialized
INFO - 2018-02-14 17:55:36 --> Controller Class Initialized
INFO - 2018-02-14 17:55:36 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-14 17:55:36 --> Model Class Initialized
INFO - 2018-02-14 17:55:36 --> Model Class Initialized
INFO - 2018-02-14 17:55:36 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-14 17:55:36 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-14 17:55:36 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-14 17:55:36 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-14 17:55:36 --> File loaded: /var/www/html/project/radio/application/views/category/add_edit.php
INFO - 2018-02-14 17:55:36 --> Final output sent to browser
DEBUG - 2018-02-14 17:55:36 --> Total execution time: 0.0060
INFO - 2018-02-14 17:55:39 --> Config Class Initialized
INFO - 2018-02-14 17:55:39 --> Hooks Class Initialized
DEBUG - 2018-02-14 17:55:39 --> UTF-8 Support Enabled
INFO - 2018-02-14 17:55:39 --> Utf8 Class Initialized
INFO - 2018-02-14 17:55:39 --> URI Class Initialized
INFO - 2018-02-14 17:55:39 --> Router Class Initialized
INFO - 2018-02-14 17:55:39 --> Output Class Initialized
INFO - 2018-02-14 17:55:39 --> Security Class Initialized
DEBUG - 2018-02-14 17:55:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 17:55:39 --> Input Class Initialized
INFO - 2018-02-14 17:55:39 --> Language Class Initialized
INFO - 2018-02-14 17:55:39 --> Loader Class Initialized
INFO - 2018-02-14 17:55:39 --> Helper loaded: url_helper
INFO - 2018-02-14 17:55:39 --> Helper loaded: file_helper
INFO - 2018-02-14 17:55:39 --> Helper loaded: email_helper
INFO - 2018-02-14 17:55:39 --> Helper loaded: common_helper
INFO - 2018-02-14 17:55:39 --> Database Driver Class Initialized
DEBUG - 2018-02-14 17:55:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 17:55:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 17:55:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-14 17:55:39 --> Pagination Class Initialized
INFO - 2018-02-14 17:55:39 --> Helper loaded: form_helper
INFO - 2018-02-14 17:55:39 --> Form Validation Class Initialized
INFO - 2018-02-14 17:55:39 --> Model Class Initialized
INFO - 2018-02-14 17:55:39 --> Controller Class Initialized
INFO - 2018-02-14 17:55:39 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-14 17:55:39 --> Model Class Initialized
INFO - 2018-02-14 17:55:39 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-14 17:55:39 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-14 17:55:39 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-14 17:55:39 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-14 17:55:39 --> File loaded: /var/www/html/project/radio/application/views/category/index.php
INFO - 2018-02-14 17:55:39 --> Final output sent to browser
DEBUG - 2018-02-14 17:55:39 --> Total execution time: 0.0059
INFO - 2018-02-14 17:55:42 --> Config Class Initialized
INFO - 2018-02-14 17:55:42 --> Hooks Class Initialized
DEBUG - 2018-02-14 17:55:42 --> UTF-8 Support Enabled
INFO - 2018-02-14 17:55:42 --> Utf8 Class Initialized
INFO - 2018-02-14 17:55:42 --> URI Class Initialized
INFO - 2018-02-14 17:55:42 --> Router Class Initialized
INFO - 2018-02-14 17:55:42 --> Output Class Initialized
INFO - 2018-02-14 17:55:42 --> Security Class Initialized
DEBUG - 2018-02-14 17:55:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 17:55:42 --> Input Class Initialized
INFO - 2018-02-14 17:55:42 --> Language Class Initialized
INFO - 2018-02-14 17:55:42 --> Loader Class Initialized
INFO - 2018-02-14 17:55:42 --> Helper loaded: url_helper
INFO - 2018-02-14 17:55:42 --> Helper loaded: file_helper
INFO - 2018-02-14 17:55:42 --> Helper loaded: email_helper
INFO - 2018-02-14 17:55:42 --> Helper loaded: common_helper
INFO - 2018-02-14 17:55:42 --> Database Driver Class Initialized
DEBUG - 2018-02-14 17:55:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 17:55:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 17:55:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-14 17:55:42 --> Pagination Class Initialized
INFO - 2018-02-14 17:55:42 --> Helper loaded: form_helper
INFO - 2018-02-14 17:55:42 --> Form Validation Class Initialized
INFO - 2018-02-14 17:55:42 --> Model Class Initialized
INFO - 2018-02-14 17:55:42 --> Controller Class Initialized
INFO - 2018-02-14 17:55:42 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-14 17:55:42 --> Model Class Initialized
INFO - 2018-02-14 17:55:42 --> Model Class Initialized
INFO - 2018-02-14 17:55:42 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-14 17:55:42 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-14 17:55:42 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-14 17:55:42 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-14 17:55:42 --> File loaded: /var/www/html/project/radio/application/views/subcategory/index.php
INFO - 2018-02-14 17:55:42 --> Final output sent to browser
DEBUG - 2018-02-14 17:55:42 --> Total execution time: 0.0069
INFO - 2018-02-14 17:56:01 --> Config Class Initialized
INFO - 2018-02-14 17:56:01 --> Hooks Class Initialized
DEBUG - 2018-02-14 17:56:01 --> UTF-8 Support Enabled
INFO - 2018-02-14 17:56:01 --> Utf8 Class Initialized
INFO - 2018-02-14 17:56:01 --> URI Class Initialized
INFO - 2018-02-14 17:56:01 --> Router Class Initialized
INFO - 2018-02-14 17:56:01 --> Output Class Initialized
INFO - 2018-02-14 17:56:01 --> Security Class Initialized
DEBUG - 2018-02-14 17:56:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 17:56:01 --> Input Class Initialized
INFO - 2018-02-14 17:56:01 --> Language Class Initialized
INFO - 2018-02-14 17:56:01 --> Loader Class Initialized
INFO - 2018-02-14 17:56:01 --> Helper loaded: url_helper
INFO - 2018-02-14 17:56:01 --> Helper loaded: file_helper
INFO - 2018-02-14 17:56:01 --> Helper loaded: email_helper
INFO - 2018-02-14 17:56:01 --> Helper loaded: common_helper
INFO - 2018-02-14 17:56:01 --> Database Driver Class Initialized
DEBUG - 2018-02-14 17:56:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 17:56:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 17:56:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-14 17:56:01 --> Pagination Class Initialized
INFO - 2018-02-14 17:56:01 --> Helper loaded: form_helper
INFO - 2018-02-14 17:56:01 --> Form Validation Class Initialized
INFO - 2018-02-14 17:56:01 --> Model Class Initialized
INFO - 2018-02-14 17:56:01 --> Controller Class Initialized
INFO - 2018-02-14 17:56:01 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-14 17:56:01 --> Model Class Initialized
INFO - 2018-02-14 17:56:01 --> Model Class Initialized
INFO - 2018-02-14 17:56:01 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-14 17:56:01 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-14 17:56:01 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-14 17:56:01 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-14 17:56:01 --> File loaded: /var/www/html/project/radio/application/views/subcategory/add_edit.php
INFO - 2018-02-14 17:56:01 --> Final output sent to browser
DEBUG - 2018-02-14 17:56:01 --> Total execution time: 0.0103
INFO - 2018-02-14 17:56:34 --> Config Class Initialized
INFO - 2018-02-14 17:56:34 --> Hooks Class Initialized
DEBUG - 2018-02-14 17:56:34 --> UTF-8 Support Enabled
INFO - 2018-02-14 17:56:34 --> Utf8 Class Initialized
INFO - 2018-02-14 17:56:34 --> URI Class Initialized
INFO - 2018-02-14 17:56:34 --> Router Class Initialized
INFO - 2018-02-14 17:56:34 --> Output Class Initialized
INFO - 2018-02-14 17:56:34 --> Security Class Initialized
DEBUG - 2018-02-14 17:56:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 17:56:34 --> Input Class Initialized
INFO - 2018-02-14 17:56:34 --> Language Class Initialized
INFO - 2018-02-14 17:56:34 --> Loader Class Initialized
INFO - 2018-02-14 17:56:34 --> Helper loaded: url_helper
INFO - 2018-02-14 17:56:34 --> Helper loaded: file_helper
INFO - 2018-02-14 17:56:34 --> Helper loaded: email_helper
INFO - 2018-02-14 17:56:34 --> Helper loaded: common_helper
INFO - 2018-02-14 17:56:34 --> Database Driver Class Initialized
DEBUG - 2018-02-14 17:56:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 17:56:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 17:56:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-14 17:56:34 --> Pagination Class Initialized
INFO - 2018-02-14 17:56:34 --> Helper loaded: form_helper
INFO - 2018-02-14 17:56:34 --> Form Validation Class Initialized
INFO - 2018-02-14 17:56:34 --> Model Class Initialized
INFO - 2018-02-14 17:56:34 --> Controller Class Initialized
INFO - 2018-02-14 17:56:34 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-14 17:56:34 --> Model Class Initialized
INFO - 2018-02-14 17:56:34 --> Model Class Initialized
INFO - 2018-02-14 17:56:34 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-14 17:56:34 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-14 17:56:34 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-14 17:56:34 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-14 17:56:34 --> File loaded: /var/www/html/project/radio/application/views/subcategory/add_edit.php
INFO - 2018-02-14 17:56:34 --> Final output sent to browser
DEBUG - 2018-02-14 17:56:34 --> Total execution time: 0.0077
INFO - 2018-02-14 17:56:53 --> Config Class Initialized
INFO - 2018-02-14 17:56:53 --> Hooks Class Initialized
DEBUG - 2018-02-14 17:56:53 --> UTF-8 Support Enabled
INFO - 2018-02-14 17:56:53 --> Utf8 Class Initialized
INFO - 2018-02-14 17:56:53 --> URI Class Initialized
INFO - 2018-02-14 17:56:53 --> Router Class Initialized
INFO - 2018-02-14 17:56:53 --> Output Class Initialized
INFO - 2018-02-14 17:56:53 --> Security Class Initialized
DEBUG - 2018-02-14 17:56:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 17:56:53 --> Input Class Initialized
INFO - 2018-02-14 17:56:53 --> Language Class Initialized
INFO - 2018-02-14 17:56:53 --> Loader Class Initialized
INFO - 2018-02-14 17:56:53 --> Helper loaded: url_helper
INFO - 2018-02-14 17:56:53 --> Helper loaded: file_helper
INFO - 2018-02-14 17:56:53 --> Helper loaded: email_helper
INFO - 2018-02-14 17:56:53 --> Helper loaded: common_helper
INFO - 2018-02-14 17:56:53 --> Database Driver Class Initialized
DEBUG - 2018-02-14 17:56:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 17:56:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 17:56:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-14 17:56:53 --> Pagination Class Initialized
INFO - 2018-02-14 17:56:53 --> Helper loaded: form_helper
INFO - 2018-02-14 17:56:53 --> Form Validation Class Initialized
INFO - 2018-02-14 17:56:53 --> Model Class Initialized
INFO - 2018-02-14 17:56:53 --> Controller Class Initialized
INFO - 2018-02-14 17:56:53 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-14 17:56:53 --> Model Class Initialized
INFO - 2018-02-14 17:56:53 --> Model Class Initialized
INFO - 2018-02-14 17:56:53 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-14 17:56:53 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-14 17:56:53 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-14 17:56:53 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-14 17:56:53 --> File loaded: /var/www/html/project/radio/application/views/subcategory/index.php
INFO - 2018-02-14 17:56:53 --> Final output sent to browser
DEBUG - 2018-02-14 17:56:53 --> Total execution time: 0.0075
INFO - 2018-02-14 17:56:55 --> Config Class Initialized
INFO - 2018-02-14 17:56:55 --> Hooks Class Initialized
DEBUG - 2018-02-14 17:56:55 --> UTF-8 Support Enabled
INFO - 2018-02-14 17:56:55 --> Utf8 Class Initialized
INFO - 2018-02-14 17:56:55 --> URI Class Initialized
INFO - 2018-02-14 17:56:55 --> Router Class Initialized
INFO - 2018-02-14 17:56:55 --> Output Class Initialized
INFO - 2018-02-14 17:56:55 --> Security Class Initialized
DEBUG - 2018-02-14 17:56:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 17:56:55 --> Input Class Initialized
INFO - 2018-02-14 17:56:55 --> Language Class Initialized
INFO - 2018-02-14 17:56:55 --> Loader Class Initialized
INFO - 2018-02-14 17:56:55 --> Helper loaded: url_helper
INFO - 2018-02-14 17:56:55 --> Helper loaded: file_helper
INFO - 2018-02-14 17:56:55 --> Helper loaded: email_helper
INFO - 2018-02-14 17:56:55 --> Helper loaded: common_helper
INFO - 2018-02-14 17:56:55 --> Database Driver Class Initialized
DEBUG - 2018-02-14 17:56:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 17:56:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 17:56:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-14 17:56:55 --> Pagination Class Initialized
INFO - 2018-02-14 17:56:55 --> Helper loaded: form_helper
INFO - 2018-02-14 17:56:55 --> Form Validation Class Initialized
INFO - 2018-02-14 17:56:55 --> Model Class Initialized
INFO - 2018-02-14 17:56:55 --> Controller Class Initialized
INFO - 2018-02-14 17:56:55 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-14 17:56:55 --> Model Class Initialized
INFO - 2018-02-14 17:56:55 --> Model Class Initialized
INFO - 2018-02-14 17:56:55 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-14 17:56:55 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-14 17:56:55 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-14 17:56:55 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-14 17:56:55 --> File loaded: /var/www/html/project/radio/application/views/subcategory/add_edit.php
INFO - 2018-02-14 17:56:55 --> Final output sent to browser
DEBUG - 2018-02-14 17:56:55 --> Total execution time: 0.0048
INFO - 2018-02-14 17:56:56 --> Config Class Initialized
INFO - 2018-02-14 17:56:56 --> Hooks Class Initialized
DEBUG - 2018-02-14 17:56:56 --> UTF-8 Support Enabled
INFO - 2018-02-14 17:56:56 --> Utf8 Class Initialized
INFO - 2018-02-14 17:56:56 --> URI Class Initialized
INFO - 2018-02-14 17:56:56 --> Router Class Initialized
INFO - 2018-02-14 17:56:56 --> Output Class Initialized
INFO - 2018-02-14 17:56:56 --> Security Class Initialized
DEBUG - 2018-02-14 17:56:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 17:56:56 --> Input Class Initialized
INFO - 2018-02-14 17:56:56 --> Language Class Initialized
INFO - 2018-02-14 17:56:56 --> Loader Class Initialized
INFO - 2018-02-14 17:56:56 --> Helper loaded: url_helper
INFO - 2018-02-14 17:56:56 --> Helper loaded: file_helper
INFO - 2018-02-14 17:56:56 --> Helper loaded: email_helper
INFO - 2018-02-14 17:56:56 --> Helper loaded: common_helper
INFO - 2018-02-14 17:56:56 --> Database Driver Class Initialized
DEBUG - 2018-02-14 17:56:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 17:56:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 17:56:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-14 17:56:56 --> Pagination Class Initialized
INFO - 2018-02-14 17:56:56 --> Helper loaded: form_helper
INFO - 2018-02-14 17:56:56 --> Form Validation Class Initialized
INFO - 2018-02-14 17:56:56 --> Model Class Initialized
INFO - 2018-02-14 17:56:56 --> Controller Class Initialized
INFO - 2018-02-14 17:56:56 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-14 17:56:56 --> Model Class Initialized
INFO - 2018-02-14 17:56:56 --> Model Class Initialized
INFO - 2018-02-14 17:56:56 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-14 17:56:56 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-14 17:56:56 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-14 17:56:56 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-14 17:56:56 --> File loaded: /var/www/html/project/radio/application/views/subcategory/index.php
INFO - 2018-02-14 17:56:56 --> Final output sent to browser
DEBUG - 2018-02-14 17:56:56 --> Total execution time: 0.0063
INFO - 2018-02-14 17:56:58 --> Config Class Initialized
INFO - 2018-02-14 17:56:58 --> Hooks Class Initialized
DEBUG - 2018-02-14 17:56:58 --> UTF-8 Support Enabled
INFO - 2018-02-14 17:56:58 --> Utf8 Class Initialized
INFO - 2018-02-14 17:56:58 --> URI Class Initialized
INFO - 2018-02-14 17:56:58 --> Router Class Initialized
INFO - 2018-02-14 17:56:58 --> Output Class Initialized
INFO - 2018-02-14 17:56:58 --> Security Class Initialized
DEBUG - 2018-02-14 17:56:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 17:56:58 --> Input Class Initialized
INFO - 2018-02-14 17:56:58 --> Language Class Initialized
INFO - 2018-02-14 17:56:58 --> Loader Class Initialized
INFO - 2018-02-14 17:56:58 --> Helper loaded: url_helper
INFO - 2018-02-14 17:56:58 --> Helper loaded: file_helper
INFO - 2018-02-14 17:56:58 --> Helper loaded: email_helper
INFO - 2018-02-14 17:56:58 --> Helper loaded: common_helper
INFO - 2018-02-14 17:56:58 --> Database Driver Class Initialized
DEBUG - 2018-02-14 17:56:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 17:56:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 17:56:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-14 17:56:58 --> Pagination Class Initialized
INFO - 2018-02-14 17:56:58 --> Helper loaded: form_helper
INFO - 2018-02-14 17:56:58 --> Form Validation Class Initialized
INFO - 2018-02-14 17:56:58 --> Model Class Initialized
INFO - 2018-02-14 17:56:58 --> Controller Class Initialized
INFO - 2018-02-14 17:56:58 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-14 17:56:58 --> Model Class Initialized
INFO - 2018-02-14 17:56:58 --> Model Class Initialized
INFO - 2018-02-14 17:56:58 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-14 17:56:58 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-14 17:56:58 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-14 17:56:58 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-14 17:56:58 --> File loaded: /var/www/html/project/radio/application/views/subcategory/add_edit.php
INFO - 2018-02-14 17:56:58 --> Final output sent to browser
DEBUG - 2018-02-14 17:56:58 --> Total execution time: 0.0058
INFO - 2018-02-14 17:57:00 --> Config Class Initialized
INFO - 2018-02-14 17:57:00 --> Hooks Class Initialized
DEBUG - 2018-02-14 17:57:00 --> UTF-8 Support Enabled
INFO - 2018-02-14 17:57:00 --> Utf8 Class Initialized
INFO - 2018-02-14 17:57:00 --> URI Class Initialized
INFO - 2018-02-14 17:57:00 --> Router Class Initialized
INFO - 2018-02-14 17:57:00 --> Output Class Initialized
INFO - 2018-02-14 17:57:00 --> Security Class Initialized
DEBUG - 2018-02-14 17:57:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 17:57:00 --> Input Class Initialized
INFO - 2018-02-14 17:57:00 --> Language Class Initialized
INFO - 2018-02-14 17:57:00 --> Loader Class Initialized
INFO - 2018-02-14 17:57:00 --> Helper loaded: url_helper
INFO - 2018-02-14 17:57:00 --> Helper loaded: file_helper
INFO - 2018-02-14 17:57:00 --> Helper loaded: email_helper
INFO - 2018-02-14 17:57:00 --> Helper loaded: common_helper
INFO - 2018-02-14 17:57:00 --> Database Driver Class Initialized
DEBUG - 2018-02-14 17:57:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 17:57:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 17:57:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-14 17:57:00 --> Pagination Class Initialized
INFO - 2018-02-14 17:57:00 --> Helper loaded: form_helper
INFO - 2018-02-14 17:57:00 --> Form Validation Class Initialized
INFO - 2018-02-14 17:57:00 --> Model Class Initialized
INFO - 2018-02-14 17:57:00 --> Controller Class Initialized
INFO - 2018-02-14 17:57:00 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-14 17:57:00 --> Model Class Initialized
INFO - 2018-02-14 17:57:00 --> Model Class Initialized
INFO - 2018-02-14 17:57:00 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-14 17:57:00 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-14 17:57:00 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-14 17:57:00 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-14 17:57:00 --> File loaded: /var/www/html/project/radio/application/views/subcategory/index.php
INFO - 2018-02-14 17:57:00 --> Final output sent to browser
DEBUG - 2018-02-14 17:57:00 --> Total execution time: 0.0048
INFO - 2018-02-14 17:57:02 --> Config Class Initialized
INFO - 2018-02-14 17:57:02 --> Hooks Class Initialized
DEBUG - 2018-02-14 17:57:02 --> UTF-8 Support Enabled
INFO - 2018-02-14 17:57:02 --> Utf8 Class Initialized
INFO - 2018-02-14 17:57:02 --> URI Class Initialized
INFO - 2018-02-14 17:57:02 --> Router Class Initialized
INFO - 2018-02-14 17:57:02 --> Output Class Initialized
INFO - 2018-02-14 17:57:02 --> Security Class Initialized
DEBUG - 2018-02-14 17:57:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 17:57:02 --> Input Class Initialized
INFO - 2018-02-14 17:57:02 --> Language Class Initialized
INFO - 2018-02-14 17:57:02 --> Loader Class Initialized
INFO - 2018-02-14 17:57:02 --> Helper loaded: url_helper
INFO - 2018-02-14 17:57:02 --> Helper loaded: file_helper
INFO - 2018-02-14 17:57:02 --> Helper loaded: email_helper
INFO - 2018-02-14 17:57:02 --> Helper loaded: common_helper
INFO - 2018-02-14 17:57:02 --> Database Driver Class Initialized
DEBUG - 2018-02-14 17:57:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 17:57:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 17:57:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-14 17:57:02 --> Pagination Class Initialized
INFO - 2018-02-14 17:57:02 --> Helper loaded: form_helper
INFO - 2018-02-14 17:57:02 --> Form Validation Class Initialized
INFO - 2018-02-14 17:57:02 --> Model Class Initialized
INFO - 2018-02-14 17:57:02 --> Controller Class Initialized
INFO - 2018-02-14 17:57:02 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-14 17:57:02 --> Model Class Initialized
INFO - 2018-02-14 17:57:02 --> Model Class Initialized
INFO - 2018-02-14 17:57:02 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-14 17:57:02 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-14 17:57:02 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-14 17:57:02 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-14 17:57:02 --> File loaded: /var/www/html/project/radio/application/views/category/add_edit.php
INFO - 2018-02-14 17:57:02 --> Final output sent to browser
DEBUG - 2018-02-14 17:57:02 --> Total execution time: 0.0053
INFO - 2018-02-14 17:57:15 --> Config Class Initialized
INFO - 2018-02-14 17:57:15 --> Hooks Class Initialized
DEBUG - 2018-02-14 17:57:15 --> UTF-8 Support Enabled
INFO - 2018-02-14 17:57:15 --> Utf8 Class Initialized
INFO - 2018-02-14 17:57:15 --> URI Class Initialized
INFO - 2018-02-14 17:57:15 --> Router Class Initialized
INFO - 2018-02-14 17:57:15 --> Output Class Initialized
INFO - 2018-02-14 17:57:15 --> Security Class Initialized
DEBUG - 2018-02-14 17:57:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 17:57:15 --> Input Class Initialized
INFO - 2018-02-14 17:57:15 --> Language Class Initialized
INFO - 2018-02-14 17:57:15 --> Loader Class Initialized
INFO - 2018-02-14 17:57:15 --> Helper loaded: url_helper
INFO - 2018-02-14 17:57:15 --> Helper loaded: file_helper
INFO - 2018-02-14 17:57:15 --> Helper loaded: email_helper
INFO - 2018-02-14 17:57:15 --> Helper loaded: common_helper
INFO - 2018-02-14 17:57:15 --> Database Driver Class Initialized
DEBUG - 2018-02-14 17:57:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 17:57:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 17:57:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-14 17:57:15 --> Pagination Class Initialized
INFO - 2018-02-14 17:57:15 --> Helper loaded: form_helper
INFO - 2018-02-14 17:57:15 --> Form Validation Class Initialized
INFO - 2018-02-14 17:57:15 --> Model Class Initialized
INFO - 2018-02-14 17:57:15 --> Controller Class Initialized
INFO - 2018-02-14 17:57:15 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-14 17:57:15 --> Model Class Initialized
INFO - 2018-02-14 17:57:15 --> Model Class Initialized
INFO - 2018-02-14 17:57:15 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-14 17:57:15 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-14 17:57:15 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-14 17:57:15 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-14 17:57:15 --> File loaded: /var/www/html/project/radio/application/views/subcategory/index.php
INFO - 2018-02-14 17:57:15 --> Final output sent to browser
DEBUG - 2018-02-14 17:57:15 --> Total execution time: 0.0076
INFO - 2018-02-14 17:59:29 --> Config Class Initialized
INFO - 2018-02-14 17:59:29 --> Hooks Class Initialized
DEBUG - 2018-02-14 17:59:29 --> UTF-8 Support Enabled
INFO - 2018-02-14 17:59:29 --> Utf8 Class Initialized
INFO - 2018-02-14 17:59:29 --> URI Class Initialized
INFO - 2018-02-14 17:59:29 --> Router Class Initialized
INFO - 2018-02-14 17:59:29 --> Output Class Initialized
INFO - 2018-02-14 17:59:29 --> Security Class Initialized
DEBUG - 2018-02-14 17:59:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 17:59:29 --> Input Class Initialized
INFO - 2018-02-14 17:59:29 --> Language Class Initialized
INFO - 2018-02-14 17:59:29 --> Loader Class Initialized
INFO - 2018-02-14 17:59:29 --> Helper loaded: url_helper
INFO - 2018-02-14 17:59:29 --> Helper loaded: file_helper
INFO - 2018-02-14 17:59:29 --> Helper loaded: email_helper
INFO - 2018-02-14 17:59:29 --> Helper loaded: common_helper
INFO - 2018-02-14 17:59:29 --> Database Driver Class Initialized
DEBUG - 2018-02-14 17:59:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 17:59:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 17:59:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-14 17:59:29 --> Pagination Class Initialized
INFO - 2018-02-14 17:59:29 --> Helper loaded: form_helper
INFO - 2018-02-14 17:59:29 --> Form Validation Class Initialized
INFO - 2018-02-14 17:59:29 --> Model Class Initialized
INFO - 2018-02-14 17:59:29 --> Controller Class Initialized
INFO - 2018-02-14 17:59:29 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-14 17:59:29 --> Model Class Initialized
INFO - 2018-02-14 17:59:29 --> Model Class Initialized
INFO - 2018-02-14 17:59:29 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-14 17:59:29 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-14 17:59:29 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-14 17:59:29 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-14 17:59:29 --> File loaded: /var/www/html/project/radio/application/views/subcategory/index.php
INFO - 2018-02-14 17:59:29 --> Final output sent to browser
DEBUG - 2018-02-14 17:59:29 --> Total execution time: 0.0065
INFO - 2018-02-14 17:59:30 --> Config Class Initialized
INFO - 2018-02-14 17:59:30 --> Hooks Class Initialized
DEBUG - 2018-02-14 17:59:30 --> UTF-8 Support Enabled
INFO - 2018-02-14 17:59:30 --> Utf8 Class Initialized
INFO - 2018-02-14 17:59:30 --> URI Class Initialized
INFO - 2018-02-14 17:59:30 --> Router Class Initialized
INFO - 2018-02-14 17:59:30 --> Output Class Initialized
INFO - 2018-02-14 17:59:30 --> Security Class Initialized
DEBUG - 2018-02-14 17:59:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 17:59:30 --> Input Class Initialized
INFO - 2018-02-14 17:59:30 --> Language Class Initialized
INFO - 2018-02-14 17:59:30 --> Loader Class Initialized
INFO - 2018-02-14 17:59:30 --> Helper loaded: url_helper
INFO - 2018-02-14 17:59:30 --> Helper loaded: file_helper
INFO - 2018-02-14 17:59:30 --> Helper loaded: email_helper
INFO - 2018-02-14 17:59:30 --> Helper loaded: common_helper
INFO - 2018-02-14 17:59:30 --> Database Driver Class Initialized
DEBUG - 2018-02-14 17:59:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 17:59:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 17:59:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-14 17:59:30 --> Pagination Class Initialized
INFO - 2018-02-14 17:59:30 --> Helper loaded: form_helper
INFO - 2018-02-14 17:59:30 --> Form Validation Class Initialized
INFO - 2018-02-14 17:59:30 --> Model Class Initialized
INFO - 2018-02-14 17:59:30 --> Controller Class Initialized
INFO - 2018-02-14 17:59:30 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-14 17:59:30 --> Model Class Initialized
INFO - 2018-02-14 17:59:30 --> Model Class Initialized
INFO - 2018-02-14 17:59:30 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-14 17:59:30 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-14 17:59:30 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
ERROR - 2018-02-14 17:59:30 --> Severity: Notice --> Undefined variable: categoryData /var/www/html/project/radio/application/views/subcategory/add_edit.php 38
INFO - 2018-02-14 17:59:30 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-14 17:59:30 --> File loaded: /var/www/html/project/radio/application/views/subcategory/add_edit.php
INFO - 2018-02-14 17:59:30 --> Final output sent to browser
DEBUG - 2018-02-14 17:59:30 --> Total execution time: 0.0053
INFO - 2018-02-14 18:00:50 --> Config Class Initialized
INFO - 2018-02-14 18:00:50 --> Hooks Class Initialized
DEBUG - 2018-02-14 18:00:50 --> UTF-8 Support Enabled
INFO - 2018-02-14 18:00:50 --> Utf8 Class Initialized
INFO - 2018-02-14 18:00:50 --> URI Class Initialized
INFO - 2018-02-14 18:00:50 --> Router Class Initialized
INFO - 2018-02-14 18:00:50 --> Output Class Initialized
INFO - 2018-02-14 18:00:50 --> Security Class Initialized
DEBUG - 2018-02-14 18:00:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 18:00:50 --> Input Class Initialized
INFO - 2018-02-14 18:00:50 --> Language Class Initialized
INFO - 2018-02-14 18:00:50 --> Loader Class Initialized
INFO - 2018-02-14 18:00:50 --> Helper loaded: url_helper
INFO - 2018-02-14 18:00:50 --> Helper loaded: file_helper
INFO - 2018-02-14 18:00:50 --> Helper loaded: email_helper
INFO - 2018-02-14 18:00:50 --> Helper loaded: common_helper
INFO - 2018-02-14 18:00:50 --> Database Driver Class Initialized
DEBUG - 2018-02-14 18:00:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 18:00:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 18:00:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-14 18:00:50 --> Pagination Class Initialized
INFO - 2018-02-14 18:00:50 --> Helper loaded: form_helper
INFO - 2018-02-14 18:00:50 --> Form Validation Class Initialized
INFO - 2018-02-14 18:00:50 --> Model Class Initialized
INFO - 2018-02-14 18:00:50 --> Controller Class Initialized
INFO - 2018-02-14 18:00:50 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-14 18:00:50 --> Model Class Initialized
INFO - 2018-02-14 18:00:50 --> Model Class Initialized
INFO - 2018-02-14 18:00:50 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-14 18:00:50 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-14 18:00:50 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-14 18:00:50 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-14 18:00:50 --> File loaded: /var/www/html/project/radio/application/views/subcategory/add_edit.php
INFO - 2018-02-14 18:00:50 --> Final output sent to browser
DEBUG - 2018-02-14 18:00:50 --> Total execution time: 0.0090
INFO - 2018-02-14 18:10:29 --> Config Class Initialized
INFO - 2018-02-14 18:10:29 --> Hooks Class Initialized
DEBUG - 2018-02-14 18:10:29 --> UTF-8 Support Enabled
INFO - 2018-02-14 18:10:29 --> Utf8 Class Initialized
INFO - 2018-02-14 18:10:29 --> URI Class Initialized
INFO - 2018-02-14 18:10:29 --> Router Class Initialized
INFO - 2018-02-14 18:10:29 --> Output Class Initialized
INFO - 2018-02-14 18:10:29 --> Security Class Initialized
DEBUG - 2018-02-14 18:10:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 18:10:29 --> Input Class Initialized
INFO - 2018-02-14 18:10:29 --> Language Class Initialized
INFO - 2018-02-14 18:10:29 --> Loader Class Initialized
INFO - 2018-02-14 18:10:29 --> Helper loaded: url_helper
INFO - 2018-02-14 18:10:29 --> Helper loaded: file_helper
INFO - 2018-02-14 18:10:29 --> Helper loaded: email_helper
INFO - 2018-02-14 18:10:29 --> Helper loaded: common_helper
INFO - 2018-02-14 18:10:29 --> Database Driver Class Initialized
DEBUG - 2018-02-14 18:10:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 18:10:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 18:10:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-14 18:10:29 --> Pagination Class Initialized
INFO - 2018-02-14 18:10:29 --> Helper loaded: form_helper
INFO - 2018-02-14 18:10:29 --> Form Validation Class Initialized
INFO - 2018-02-14 18:10:29 --> Model Class Initialized
INFO - 2018-02-14 18:10:29 --> Controller Class Initialized
INFO - 2018-02-14 18:10:29 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-14 18:10:29 --> Model Class Initialized
INFO - 2018-02-14 18:10:29 --> Model Class Initialized
INFO - 2018-02-14 18:10:29 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-14 18:10:29 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-14 18:10:29 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-14 18:10:29 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-14 18:10:29 --> File loaded: /var/www/html/project/radio/application/views/subcategory/add_edit.php
INFO - 2018-02-14 18:10:29 --> Final output sent to browser
DEBUG - 2018-02-14 18:10:29 --> Total execution time: 0.0134
INFO - 2018-02-14 18:10:32 --> Config Class Initialized
INFO - 2018-02-14 18:10:32 --> Hooks Class Initialized
DEBUG - 2018-02-14 18:10:32 --> UTF-8 Support Enabled
INFO - 2018-02-14 18:10:32 --> Utf8 Class Initialized
INFO - 2018-02-14 18:10:32 --> URI Class Initialized
INFO - 2018-02-14 18:10:32 --> Router Class Initialized
INFO - 2018-02-14 18:10:32 --> Output Class Initialized
INFO - 2018-02-14 18:10:32 --> Security Class Initialized
DEBUG - 2018-02-14 18:10:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 18:10:32 --> Input Class Initialized
INFO - 2018-02-14 18:10:32 --> Language Class Initialized
INFO - 2018-02-14 18:10:32 --> Loader Class Initialized
INFO - 2018-02-14 18:10:32 --> Helper loaded: url_helper
INFO - 2018-02-14 18:10:32 --> Helper loaded: file_helper
INFO - 2018-02-14 18:10:32 --> Helper loaded: email_helper
INFO - 2018-02-14 18:10:32 --> Helper loaded: common_helper
INFO - 2018-02-14 18:10:32 --> Database Driver Class Initialized
DEBUG - 2018-02-14 18:10:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 18:10:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 18:10:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-14 18:10:32 --> Pagination Class Initialized
INFO - 2018-02-14 18:10:32 --> Helper loaded: form_helper
INFO - 2018-02-14 18:10:32 --> Form Validation Class Initialized
INFO - 2018-02-14 18:10:32 --> Model Class Initialized
INFO - 2018-02-14 18:10:32 --> Controller Class Initialized
INFO - 2018-02-14 18:10:32 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-14 18:10:32 --> Model Class Initialized
INFO - 2018-02-14 18:10:32 --> Model Class Initialized
INFO - 2018-02-14 18:10:32 --> Config Class Initialized
INFO - 2018-02-14 18:10:32 --> Hooks Class Initialized
DEBUG - 2018-02-14 18:10:32 --> UTF-8 Support Enabled
INFO - 2018-02-14 18:10:32 --> Utf8 Class Initialized
INFO - 2018-02-14 18:10:32 --> URI Class Initialized
INFO - 2018-02-14 18:10:32 --> Router Class Initialized
INFO - 2018-02-14 18:10:32 --> Output Class Initialized
INFO - 2018-02-14 18:10:32 --> Security Class Initialized
DEBUG - 2018-02-14 18:10:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 18:10:32 --> Input Class Initialized
INFO - 2018-02-14 18:10:32 --> Language Class Initialized
INFO - 2018-02-14 18:10:32 --> Loader Class Initialized
INFO - 2018-02-14 18:10:32 --> Helper loaded: url_helper
INFO - 2018-02-14 18:10:32 --> Helper loaded: file_helper
INFO - 2018-02-14 18:10:32 --> Helper loaded: email_helper
INFO - 2018-02-14 18:10:32 --> Helper loaded: common_helper
INFO - 2018-02-14 18:10:32 --> Database Driver Class Initialized
DEBUG - 2018-02-14 18:10:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 18:10:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 18:10:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-14 18:10:32 --> Pagination Class Initialized
INFO - 2018-02-14 18:10:32 --> Helper loaded: form_helper
INFO - 2018-02-14 18:10:32 --> Form Validation Class Initialized
INFO - 2018-02-14 18:10:32 --> Model Class Initialized
INFO - 2018-02-14 18:10:32 --> Controller Class Initialized
INFO - 2018-02-14 18:10:32 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-14 18:10:32 --> Model Class Initialized
INFO - 2018-02-14 18:10:32 --> Model Class Initialized
DEBUG - 2018-02-14 18:10:32 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-14 18:10:32 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2018-02-14 18:10:32 --> Query error: Unknown column 'iSubCategoryId' in 'where clause' - Invalid query: UPDATE `Category` SET `iCategoryId` = '1', `vTitle` = 'test1', `txDescription` = 'asdsad', `tStatus` = '1'
WHERE `iSubCategoryId` = '1'
INFO - 2018-02-14 18:10:32 --> Language file loaded: language/english/db_lang.php
INFO - 2018-02-14 18:11:18 --> Config Class Initialized
INFO - 2018-02-14 18:11:18 --> Hooks Class Initialized
DEBUG - 2018-02-14 18:11:18 --> UTF-8 Support Enabled
INFO - 2018-02-14 18:11:18 --> Utf8 Class Initialized
INFO - 2018-02-14 18:11:18 --> URI Class Initialized
INFO - 2018-02-14 18:11:18 --> Router Class Initialized
INFO - 2018-02-14 18:11:18 --> Output Class Initialized
INFO - 2018-02-14 18:11:18 --> Security Class Initialized
DEBUG - 2018-02-14 18:11:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 18:11:18 --> Input Class Initialized
INFO - 2018-02-14 18:11:18 --> Language Class Initialized
INFO - 2018-02-14 18:11:18 --> Loader Class Initialized
INFO - 2018-02-14 18:11:18 --> Helper loaded: url_helper
INFO - 2018-02-14 18:11:18 --> Helper loaded: file_helper
INFO - 2018-02-14 18:11:18 --> Helper loaded: email_helper
INFO - 2018-02-14 18:11:18 --> Helper loaded: common_helper
INFO - 2018-02-14 18:11:18 --> Database Driver Class Initialized
DEBUG - 2018-02-14 18:11:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 18:11:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 18:11:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-14 18:11:18 --> Pagination Class Initialized
INFO - 2018-02-14 18:11:18 --> Helper loaded: form_helper
INFO - 2018-02-14 18:11:18 --> Form Validation Class Initialized
INFO - 2018-02-14 18:11:18 --> Model Class Initialized
INFO - 2018-02-14 18:11:18 --> Controller Class Initialized
INFO - 2018-02-14 18:11:18 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-14 18:11:18 --> Model Class Initialized
INFO - 2018-02-14 18:11:18 --> Model Class Initialized
INFO - 2018-02-14 18:11:18 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-14 18:11:18 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-14 18:11:18 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-14 18:11:18 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-14 18:11:18 --> File loaded: /var/www/html/project/radio/application/views/subcategory/add_edit.php
INFO - 2018-02-14 18:11:18 --> Final output sent to browser
DEBUG - 2018-02-14 18:11:18 --> Total execution time: 0.0094
INFO - 2018-02-14 18:11:20 --> Config Class Initialized
INFO - 2018-02-14 18:11:20 --> Hooks Class Initialized
DEBUG - 2018-02-14 18:11:20 --> UTF-8 Support Enabled
INFO - 2018-02-14 18:11:20 --> Utf8 Class Initialized
INFO - 2018-02-14 18:11:20 --> URI Class Initialized
INFO - 2018-02-14 18:11:20 --> Router Class Initialized
INFO - 2018-02-14 18:11:20 --> Output Class Initialized
INFO - 2018-02-14 18:11:20 --> Security Class Initialized
DEBUG - 2018-02-14 18:11:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 18:11:20 --> Input Class Initialized
INFO - 2018-02-14 18:11:20 --> Language Class Initialized
INFO - 2018-02-14 18:11:20 --> Loader Class Initialized
INFO - 2018-02-14 18:11:20 --> Helper loaded: url_helper
INFO - 2018-02-14 18:11:20 --> Helper loaded: file_helper
INFO - 2018-02-14 18:11:20 --> Helper loaded: email_helper
INFO - 2018-02-14 18:11:20 --> Helper loaded: common_helper
INFO - 2018-02-14 18:11:20 --> Database Driver Class Initialized
DEBUG - 2018-02-14 18:11:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 18:11:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 18:11:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-14 18:11:20 --> Pagination Class Initialized
INFO - 2018-02-14 18:11:20 --> Helper loaded: form_helper
INFO - 2018-02-14 18:11:20 --> Form Validation Class Initialized
INFO - 2018-02-14 18:11:20 --> Model Class Initialized
INFO - 2018-02-14 18:11:20 --> Controller Class Initialized
INFO - 2018-02-14 18:11:20 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-14 18:11:20 --> Model Class Initialized
INFO - 2018-02-14 18:11:20 --> Model Class Initialized
INFO - 2018-02-14 18:11:20 --> Config Class Initialized
INFO - 2018-02-14 18:11:20 --> Hooks Class Initialized
DEBUG - 2018-02-14 18:11:20 --> UTF-8 Support Enabled
INFO - 2018-02-14 18:11:20 --> Utf8 Class Initialized
INFO - 2018-02-14 18:11:20 --> URI Class Initialized
INFO - 2018-02-14 18:11:20 --> Router Class Initialized
INFO - 2018-02-14 18:11:20 --> Output Class Initialized
INFO - 2018-02-14 18:11:20 --> Security Class Initialized
DEBUG - 2018-02-14 18:11:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 18:11:20 --> Input Class Initialized
INFO - 2018-02-14 18:11:20 --> Language Class Initialized
INFO - 2018-02-14 18:11:20 --> Loader Class Initialized
INFO - 2018-02-14 18:11:20 --> Helper loaded: url_helper
INFO - 2018-02-14 18:11:20 --> Helper loaded: file_helper
INFO - 2018-02-14 18:11:20 --> Helper loaded: email_helper
INFO - 2018-02-14 18:11:20 --> Helper loaded: common_helper
INFO - 2018-02-14 18:11:20 --> Database Driver Class Initialized
DEBUG - 2018-02-14 18:11:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 18:11:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 18:11:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-14 18:11:20 --> Pagination Class Initialized
INFO - 2018-02-14 18:11:20 --> Helper loaded: form_helper
INFO - 2018-02-14 18:11:20 --> Form Validation Class Initialized
INFO - 2018-02-14 18:11:20 --> Model Class Initialized
INFO - 2018-02-14 18:11:20 --> Controller Class Initialized
INFO - 2018-02-14 18:11:20 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-14 18:11:20 --> Model Class Initialized
INFO - 2018-02-14 18:11:20 --> Model Class Initialized
DEBUG - 2018-02-14 18:11:20 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-14 18:11:20 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-02-14 18:11:20 --> Config Class Initialized
INFO - 2018-02-14 18:11:20 --> Hooks Class Initialized
DEBUG - 2018-02-14 18:11:20 --> UTF-8 Support Enabled
INFO - 2018-02-14 18:11:20 --> Utf8 Class Initialized
INFO - 2018-02-14 18:11:20 --> URI Class Initialized
INFO - 2018-02-14 18:11:20 --> Router Class Initialized
INFO - 2018-02-14 18:11:20 --> Output Class Initialized
INFO - 2018-02-14 18:11:20 --> Security Class Initialized
DEBUG - 2018-02-14 18:11:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 18:11:20 --> Input Class Initialized
INFO - 2018-02-14 18:11:20 --> Language Class Initialized
INFO - 2018-02-14 18:11:20 --> Loader Class Initialized
INFO - 2018-02-14 18:11:20 --> Helper loaded: url_helper
INFO - 2018-02-14 18:11:20 --> Helper loaded: file_helper
INFO - 2018-02-14 18:11:20 --> Helper loaded: email_helper
INFO - 2018-02-14 18:11:20 --> Helper loaded: common_helper
INFO - 2018-02-14 18:11:20 --> Database Driver Class Initialized
DEBUG - 2018-02-14 18:11:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 18:11:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 18:11:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-14 18:11:20 --> Pagination Class Initialized
INFO - 2018-02-14 18:11:20 --> Helper loaded: form_helper
INFO - 2018-02-14 18:11:20 --> Form Validation Class Initialized
INFO - 2018-02-14 18:11:20 --> Model Class Initialized
INFO - 2018-02-14 18:11:20 --> Controller Class Initialized
INFO - 2018-02-14 18:11:20 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-14 18:11:20 --> Model Class Initialized
INFO - 2018-02-14 18:11:20 --> Model Class Initialized
INFO - 2018-02-14 18:11:20 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-14 18:11:20 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-14 18:11:20 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-14 18:11:20 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-14 18:11:20 --> File loaded: /var/www/html/project/radio/application/views/subcategory/index.php
INFO - 2018-02-14 18:11:20 --> Final output sent to browser
DEBUG - 2018-02-14 18:11:20 --> Total execution time: 0.0044
INFO - 2018-02-14 18:11:22 --> Config Class Initialized
INFO - 2018-02-14 18:11:22 --> Hooks Class Initialized
DEBUG - 2018-02-14 18:11:22 --> UTF-8 Support Enabled
INFO - 2018-02-14 18:11:22 --> Utf8 Class Initialized
INFO - 2018-02-14 18:11:22 --> URI Class Initialized
INFO - 2018-02-14 18:11:22 --> Router Class Initialized
INFO - 2018-02-14 18:11:22 --> Output Class Initialized
INFO - 2018-02-14 18:11:22 --> Security Class Initialized
DEBUG - 2018-02-14 18:11:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 18:11:22 --> Input Class Initialized
INFO - 2018-02-14 18:11:22 --> Language Class Initialized
INFO - 2018-02-14 18:11:22 --> Loader Class Initialized
INFO - 2018-02-14 18:11:22 --> Helper loaded: url_helper
INFO - 2018-02-14 18:11:22 --> Helper loaded: file_helper
INFO - 2018-02-14 18:11:22 --> Helper loaded: email_helper
INFO - 2018-02-14 18:11:22 --> Helper loaded: common_helper
INFO - 2018-02-14 18:11:22 --> Database Driver Class Initialized
DEBUG - 2018-02-14 18:11:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 18:11:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 18:11:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-14 18:11:22 --> Pagination Class Initialized
INFO - 2018-02-14 18:11:22 --> Helper loaded: form_helper
INFO - 2018-02-14 18:11:22 --> Form Validation Class Initialized
INFO - 2018-02-14 18:11:22 --> Model Class Initialized
INFO - 2018-02-14 18:11:22 --> Controller Class Initialized
INFO - 2018-02-14 18:11:22 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-14 18:11:22 --> Model Class Initialized
INFO - 2018-02-14 18:11:22 --> Model Class Initialized
INFO - 2018-02-14 18:11:22 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-14 18:11:22 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-14 18:11:22 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-14 18:11:22 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-14 18:11:22 --> File loaded: /var/www/html/project/radio/application/views/subcategory/add_edit.php
INFO - 2018-02-14 18:11:22 --> Final output sent to browser
DEBUG - 2018-02-14 18:11:22 --> Total execution time: 0.0073
INFO - 2018-02-14 18:11:27 --> Config Class Initialized
INFO - 2018-02-14 18:11:27 --> Hooks Class Initialized
DEBUG - 2018-02-14 18:11:27 --> UTF-8 Support Enabled
INFO - 2018-02-14 18:11:27 --> Utf8 Class Initialized
INFO - 2018-02-14 18:11:27 --> URI Class Initialized
INFO - 2018-02-14 18:11:27 --> Router Class Initialized
INFO - 2018-02-14 18:11:27 --> Output Class Initialized
INFO - 2018-02-14 18:11:27 --> Security Class Initialized
DEBUG - 2018-02-14 18:11:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 18:11:27 --> Input Class Initialized
INFO - 2018-02-14 18:11:27 --> Language Class Initialized
INFO - 2018-02-14 18:11:27 --> Loader Class Initialized
INFO - 2018-02-14 18:11:27 --> Helper loaded: url_helper
INFO - 2018-02-14 18:11:27 --> Helper loaded: file_helper
INFO - 2018-02-14 18:11:27 --> Helper loaded: email_helper
INFO - 2018-02-14 18:11:27 --> Helper loaded: common_helper
INFO - 2018-02-14 18:11:27 --> Database Driver Class Initialized
DEBUG - 2018-02-14 18:11:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 18:11:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 18:11:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-14 18:11:27 --> Pagination Class Initialized
INFO - 2018-02-14 18:11:27 --> Helper loaded: form_helper
INFO - 2018-02-14 18:11:27 --> Form Validation Class Initialized
INFO - 2018-02-14 18:11:27 --> Model Class Initialized
INFO - 2018-02-14 18:11:27 --> Controller Class Initialized
INFO - 2018-02-14 18:11:27 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-14 18:11:27 --> Model Class Initialized
INFO - 2018-02-14 18:11:27 --> Model Class Initialized
INFO - 2018-02-14 18:11:27 --> Config Class Initialized
INFO - 2018-02-14 18:11:27 --> Hooks Class Initialized
DEBUG - 2018-02-14 18:11:27 --> UTF-8 Support Enabled
INFO - 2018-02-14 18:11:27 --> Utf8 Class Initialized
INFO - 2018-02-14 18:11:27 --> URI Class Initialized
INFO - 2018-02-14 18:11:27 --> Router Class Initialized
INFO - 2018-02-14 18:11:27 --> Output Class Initialized
INFO - 2018-02-14 18:11:27 --> Security Class Initialized
DEBUG - 2018-02-14 18:11:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 18:11:27 --> Input Class Initialized
INFO - 2018-02-14 18:11:27 --> Language Class Initialized
INFO - 2018-02-14 18:11:27 --> Loader Class Initialized
INFO - 2018-02-14 18:11:27 --> Helper loaded: url_helper
INFO - 2018-02-14 18:11:27 --> Helper loaded: file_helper
INFO - 2018-02-14 18:11:27 --> Helper loaded: email_helper
INFO - 2018-02-14 18:11:27 --> Helper loaded: common_helper
INFO - 2018-02-14 18:11:27 --> Database Driver Class Initialized
DEBUG - 2018-02-14 18:11:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 18:11:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 18:11:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-14 18:11:27 --> Pagination Class Initialized
INFO - 2018-02-14 18:11:27 --> Helper loaded: form_helper
INFO - 2018-02-14 18:11:27 --> Form Validation Class Initialized
INFO - 2018-02-14 18:11:27 --> Model Class Initialized
INFO - 2018-02-14 18:11:27 --> Controller Class Initialized
INFO - 2018-02-14 18:11:27 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-14 18:11:27 --> Model Class Initialized
INFO - 2018-02-14 18:11:27 --> Model Class Initialized
DEBUG - 2018-02-14 18:11:27 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-14 18:11:27 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-02-14 18:11:27 --> Upload Class Initialized
INFO - 2018-02-14 18:11:27 --> Config Class Initialized
INFO - 2018-02-14 18:11:27 --> Hooks Class Initialized
DEBUG - 2018-02-14 18:11:27 --> UTF-8 Support Enabled
INFO - 2018-02-14 18:11:27 --> Utf8 Class Initialized
INFO - 2018-02-14 18:11:27 --> URI Class Initialized
INFO - 2018-02-14 18:11:27 --> Router Class Initialized
INFO - 2018-02-14 18:11:27 --> Output Class Initialized
INFO - 2018-02-14 18:11:27 --> Security Class Initialized
DEBUG - 2018-02-14 18:11:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 18:11:27 --> Input Class Initialized
INFO - 2018-02-14 18:11:27 --> Language Class Initialized
INFO - 2018-02-14 18:11:27 --> Loader Class Initialized
INFO - 2018-02-14 18:11:27 --> Helper loaded: url_helper
INFO - 2018-02-14 18:11:27 --> Helper loaded: file_helper
INFO - 2018-02-14 18:11:27 --> Helper loaded: email_helper
INFO - 2018-02-14 18:11:27 --> Helper loaded: common_helper
INFO - 2018-02-14 18:11:27 --> Database Driver Class Initialized
DEBUG - 2018-02-14 18:11:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 18:11:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 18:11:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-14 18:11:27 --> Pagination Class Initialized
INFO - 2018-02-14 18:11:27 --> Helper loaded: form_helper
INFO - 2018-02-14 18:11:27 --> Form Validation Class Initialized
INFO - 2018-02-14 18:11:27 --> Model Class Initialized
INFO - 2018-02-14 18:11:27 --> Controller Class Initialized
INFO - 2018-02-14 18:11:27 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-14 18:11:27 --> Model Class Initialized
INFO - 2018-02-14 18:11:27 --> Model Class Initialized
INFO - 2018-02-14 18:11:27 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-14 18:11:27 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-14 18:11:27 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-14 18:11:27 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-14 18:11:27 --> File loaded: /var/www/html/project/radio/application/views/subcategory/index.php
INFO - 2018-02-14 18:11:27 --> Final output sent to browser
DEBUG - 2018-02-14 18:11:27 --> Total execution time: 0.0065
INFO - 2018-02-14 18:11:43 --> Config Class Initialized
INFO - 2018-02-14 18:11:43 --> Hooks Class Initialized
DEBUG - 2018-02-14 18:11:43 --> UTF-8 Support Enabled
INFO - 2018-02-14 18:11:43 --> Utf8 Class Initialized
INFO - 2018-02-14 18:11:43 --> URI Class Initialized
INFO - 2018-02-14 18:11:43 --> Router Class Initialized
INFO - 2018-02-14 18:11:43 --> Output Class Initialized
INFO - 2018-02-14 18:11:43 --> Security Class Initialized
DEBUG - 2018-02-14 18:11:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 18:11:43 --> Input Class Initialized
INFO - 2018-02-14 18:11:43 --> Language Class Initialized
INFO - 2018-02-14 18:11:43 --> Loader Class Initialized
INFO - 2018-02-14 18:11:43 --> Helper loaded: url_helper
INFO - 2018-02-14 18:11:43 --> Helper loaded: file_helper
INFO - 2018-02-14 18:11:43 --> Helper loaded: email_helper
INFO - 2018-02-14 18:11:43 --> Helper loaded: common_helper
INFO - 2018-02-14 18:11:43 --> Database Driver Class Initialized
DEBUG - 2018-02-14 18:11:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 18:11:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 18:11:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-14 18:11:43 --> Pagination Class Initialized
INFO - 2018-02-14 18:11:43 --> Helper loaded: form_helper
INFO - 2018-02-14 18:11:43 --> Form Validation Class Initialized
INFO - 2018-02-14 18:11:43 --> Model Class Initialized
INFO - 2018-02-14 18:11:43 --> Controller Class Initialized
INFO - 2018-02-14 18:11:43 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-14 18:11:43 --> Model Class Initialized
INFO - 2018-02-14 18:11:43 --> Model Class Initialized
INFO - 2018-02-14 18:11:43 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-14 18:11:43 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-14 18:11:43 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-14 18:11:43 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-14 18:11:43 --> File loaded: /var/www/html/project/radio/application/views/subcategory/add_edit.php
INFO - 2018-02-14 18:11:43 --> Final output sent to browser
DEBUG - 2018-02-14 18:11:43 --> Total execution time: 0.0073
INFO - 2018-02-14 18:11:45 --> Config Class Initialized
INFO - 2018-02-14 18:11:45 --> Hooks Class Initialized
DEBUG - 2018-02-14 18:11:45 --> UTF-8 Support Enabled
INFO - 2018-02-14 18:11:45 --> Utf8 Class Initialized
INFO - 2018-02-14 18:11:45 --> URI Class Initialized
INFO - 2018-02-14 18:11:45 --> Router Class Initialized
INFO - 2018-02-14 18:11:45 --> Output Class Initialized
INFO - 2018-02-14 18:11:45 --> Security Class Initialized
DEBUG - 2018-02-14 18:11:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 18:11:45 --> Input Class Initialized
INFO - 2018-02-14 18:11:45 --> Language Class Initialized
INFO - 2018-02-14 18:11:45 --> Loader Class Initialized
INFO - 2018-02-14 18:11:45 --> Helper loaded: url_helper
INFO - 2018-02-14 18:11:45 --> Helper loaded: file_helper
INFO - 2018-02-14 18:11:45 --> Helper loaded: email_helper
INFO - 2018-02-14 18:11:45 --> Helper loaded: common_helper
INFO - 2018-02-14 18:11:45 --> Database Driver Class Initialized
DEBUG - 2018-02-14 18:11:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 18:11:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 18:11:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-14 18:11:45 --> Pagination Class Initialized
INFO - 2018-02-14 18:11:45 --> Helper loaded: form_helper
INFO - 2018-02-14 18:11:45 --> Form Validation Class Initialized
INFO - 2018-02-14 18:11:45 --> Model Class Initialized
INFO - 2018-02-14 18:11:45 --> Controller Class Initialized
INFO - 2018-02-14 18:11:45 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-14 18:11:45 --> Model Class Initialized
INFO - 2018-02-14 18:11:45 --> Model Class Initialized
INFO - 2018-02-14 18:11:45 --> Config Class Initialized
INFO - 2018-02-14 18:11:45 --> Hooks Class Initialized
DEBUG - 2018-02-14 18:11:45 --> UTF-8 Support Enabled
INFO - 2018-02-14 18:11:45 --> Utf8 Class Initialized
INFO - 2018-02-14 18:11:45 --> URI Class Initialized
INFO - 2018-02-14 18:11:45 --> Router Class Initialized
INFO - 2018-02-14 18:11:45 --> Output Class Initialized
INFO - 2018-02-14 18:11:45 --> Security Class Initialized
DEBUG - 2018-02-14 18:11:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 18:11:45 --> Input Class Initialized
INFO - 2018-02-14 18:11:45 --> Language Class Initialized
INFO - 2018-02-14 18:11:45 --> Loader Class Initialized
INFO - 2018-02-14 18:11:45 --> Helper loaded: url_helper
INFO - 2018-02-14 18:11:45 --> Helper loaded: file_helper
INFO - 2018-02-14 18:11:45 --> Helper loaded: email_helper
INFO - 2018-02-14 18:11:45 --> Helper loaded: common_helper
INFO - 2018-02-14 18:11:45 --> Database Driver Class Initialized
DEBUG - 2018-02-14 18:11:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 18:11:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 18:11:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-14 18:11:45 --> Pagination Class Initialized
INFO - 2018-02-14 18:11:45 --> Helper loaded: form_helper
INFO - 2018-02-14 18:11:45 --> Form Validation Class Initialized
INFO - 2018-02-14 18:11:45 --> Model Class Initialized
INFO - 2018-02-14 18:11:45 --> Controller Class Initialized
INFO - 2018-02-14 18:11:45 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-14 18:11:45 --> Model Class Initialized
INFO - 2018-02-14 18:11:45 --> Model Class Initialized
DEBUG - 2018-02-14 18:11:45 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-14 18:11:45 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-02-14 18:11:45 --> Config Class Initialized
INFO - 2018-02-14 18:11:45 --> Hooks Class Initialized
DEBUG - 2018-02-14 18:11:45 --> UTF-8 Support Enabled
INFO - 2018-02-14 18:11:45 --> Utf8 Class Initialized
INFO - 2018-02-14 18:11:45 --> URI Class Initialized
INFO - 2018-02-14 18:11:45 --> Router Class Initialized
INFO - 2018-02-14 18:11:45 --> Output Class Initialized
INFO - 2018-02-14 18:11:45 --> Security Class Initialized
DEBUG - 2018-02-14 18:11:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 18:11:45 --> Input Class Initialized
INFO - 2018-02-14 18:11:45 --> Language Class Initialized
INFO - 2018-02-14 18:11:45 --> Loader Class Initialized
INFO - 2018-02-14 18:11:45 --> Helper loaded: url_helper
INFO - 2018-02-14 18:11:45 --> Helper loaded: file_helper
INFO - 2018-02-14 18:11:45 --> Helper loaded: email_helper
INFO - 2018-02-14 18:11:45 --> Helper loaded: common_helper
INFO - 2018-02-14 18:11:45 --> Database Driver Class Initialized
DEBUG - 2018-02-14 18:11:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 18:11:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 18:11:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-14 18:11:45 --> Pagination Class Initialized
INFO - 2018-02-14 18:11:45 --> Helper loaded: form_helper
INFO - 2018-02-14 18:11:45 --> Form Validation Class Initialized
INFO - 2018-02-14 18:11:45 --> Model Class Initialized
INFO - 2018-02-14 18:11:45 --> Controller Class Initialized
INFO - 2018-02-14 18:11:45 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-14 18:11:45 --> Model Class Initialized
INFO - 2018-02-14 18:11:45 --> Model Class Initialized
INFO - 2018-02-14 18:11:45 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-14 18:11:45 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-14 18:11:45 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-14 18:11:45 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-14 18:11:45 --> File loaded: /var/www/html/project/radio/application/views/subcategory/index.php
INFO - 2018-02-14 18:11:45 --> Final output sent to browser
DEBUG - 2018-02-14 18:11:45 --> Total execution time: 0.0050
INFO - 2018-02-14 18:11:47 --> Config Class Initialized
INFO - 2018-02-14 18:11:47 --> Hooks Class Initialized
DEBUG - 2018-02-14 18:11:47 --> UTF-8 Support Enabled
INFO - 2018-02-14 18:11:47 --> Utf8 Class Initialized
INFO - 2018-02-14 18:11:47 --> URI Class Initialized
INFO - 2018-02-14 18:11:47 --> Router Class Initialized
INFO - 2018-02-14 18:11:47 --> Output Class Initialized
INFO - 2018-02-14 18:11:47 --> Security Class Initialized
DEBUG - 2018-02-14 18:11:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 18:11:47 --> Input Class Initialized
INFO - 2018-02-14 18:11:47 --> Language Class Initialized
INFO - 2018-02-14 18:11:47 --> Loader Class Initialized
INFO - 2018-02-14 18:11:47 --> Helper loaded: url_helper
INFO - 2018-02-14 18:11:47 --> Helper loaded: file_helper
INFO - 2018-02-14 18:11:47 --> Helper loaded: email_helper
INFO - 2018-02-14 18:11:47 --> Helper loaded: common_helper
INFO - 2018-02-14 18:11:47 --> Database Driver Class Initialized
DEBUG - 2018-02-14 18:11:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 18:11:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 18:11:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-14 18:11:47 --> Pagination Class Initialized
INFO - 2018-02-14 18:11:47 --> Helper loaded: form_helper
INFO - 2018-02-14 18:11:47 --> Form Validation Class Initialized
INFO - 2018-02-14 18:11:47 --> Model Class Initialized
INFO - 2018-02-14 18:11:47 --> Controller Class Initialized
INFO - 2018-02-14 18:11:47 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-14 18:11:47 --> Model Class Initialized
INFO - 2018-02-14 18:11:47 --> Model Class Initialized
INFO - 2018-02-14 18:11:47 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-14 18:11:47 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-14 18:11:47 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-14 18:11:47 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-14 18:11:47 --> File loaded: /var/www/html/project/radio/application/views/subcategory/add_edit.php
INFO - 2018-02-14 18:11:47 --> Final output sent to browser
DEBUG - 2018-02-14 18:11:47 --> Total execution time: 0.0056
INFO - 2018-02-14 18:11:51 --> Config Class Initialized
INFO - 2018-02-14 18:11:51 --> Hooks Class Initialized
DEBUG - 2018-02-14 18:11:51 --> UTF-8 Support Enabled
INFO - 2018-02-14 18:11:51 --> Utf8 Class Initialized
INFO - 2018-02-14 18:11:51 --> URI Class Initialized
INFO - 2018-02-14 18:11:51 --> Router Class Initialized
INFO - 2018-02-14 18:11:51 --> Output Class Initialized
INFO - 2018-02-14 18:11:51 --> Security Class Initialized
DEBUG - 2018-02-14 18:11:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 18:11:51 --> Input Class Initialized
INFO - 2018-02-14 18:11:51 --> Language Class Initialized
INFO - 2018-02-14 18:11:51 --> Loader Class Initialized
INFO - 2018-02-14 18:11:51 --> Helper loaded: url_helper
INFO - 2018-02-14 18:11:51 --> Helper loaded: file_helper
INFO - 2018-02-14 18:11:51 --> Helper loaded: email_helper
INFO - 2018-02-14 18:11:51 --> Helper loaded: common_helper
INFO - 2018-02-14 18:11:51 --> Database Driver Class Initialized
DEBUG - 2018-02-14 18:11:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 18:11:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 18:11:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-14 18:11:51 --> Pagination Class Initialized
INFO - 2018-02-14 18:11:51 --> Helper loaded: form_helper
INFO - 2018-02-14 18:11:51 --> Form Validation Class Initialized
INFO - 2018-02-14 18:11:51 --> Model Class Initialized
INFO - 2018-02-14 18:11:51 --> Controller Class Initialized
INFO - 2018-02-14 18:11:51 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-14 18:11:51 --> Model Class Initialized
INFO - 2018-02-14 18:11:51 --> Model Class Initialized
INFO - 2018-02-14 18:11:51 --> Config Class Initialized
INFO - 2018-02-14 18:11:51 --> Hooks Class Initialized
DEBUG - 2018-02-14 18:11:51 --> UTF-8 Support Enabled
INFO - 2018-02-14 18:11:51 --> Utf8 Class Initialized
INFO - 2018-02-14 18:11:51 --> URI Class Initialized
INFO - 2018-02-14 18:11:51 --> Router Class Initialized
INFO - 2018-02-14 18:11:51 --> Output Class Initialized
INFO - 2018-02-14 18:11:51 --> Security Class Initialized
DEBUG - 2018-02-14 18:11:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 18:11:51 --> Input Class Initialized
INFO - 2018-02-14 18:11:51 --> Language Class Initialized
INFO - 2018-02-14 18:11:51 --> Loader Class Initialized
INFO - 2018-02-14 18:11:51 --> Helper loaded: url_helper
INFO - 2018-02-14 18:11:51 --> Helper loaded: file_helper
INFO - 2018-02-14 18:11:51 --> Helper loaded: email_helper
INFO - 2018-02-14 18:11:51 --> Helper loaded: common_helper
INFO - 2018-02-14 18:11:51 --> Database Driver Class Initialized
DEBUG - 2018-02-14 18:11:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 18:11:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 18:11:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-14 18:11:51 --> Pagination Class Initialized
INFO - 2018-02-14 18:11:51 --> Helper loaded: form_helper
INFO - 2018-02-14 18:11:51 --> Form Validation Class Initialized
INFO - 2018-02-14 18:11:51 --> Model Class Initialized
INFO - 2018-02-14 18:11:51 --> Controller Class Initialized
INFO - 2018-02-14 18:11:51 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-14 18:11:51 --> Model Class Initialized
INFO - 2018-02-14 18:11:51 --> Model Class Initialized
DEBUG - 2018-02-14 18:11:51 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-14 18:11:51 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-02-14 18:11:51 --> Config Class Initialized
INFO - 2018-02-14 18:11:51 --> Hooks Class Initialized
DEBUG - 2018-02-14 18:11:51 --> UTF-8 Support Enabled
INFO - 2018-02-14 18:11:51 --> Utf8 Class Initialized
INFO - 2018-02-14 18:11:51 --> URI Class Initialized
INFO - 2018-02-14 18:11:51 --> Router Class Initialized
INFO - 2018-02-14 18:11:51 --> Output Class Initialized
INFO - 2018-02-14 18:11:51 --> Security Class Initialized
DEBUG - 2018-02-14 18:11:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 18:11:51 --> Input Class Initialized
INFO - 2018-02-14 18:11:51 --> Language Class Initialized
INFO - 2018-02-14 18:11:51 --> Loader Class Initialized
INFO - 2018-02-14 18:11:51 --> Helper loaded: url_helper
INFO - 2018-02-14 18:11:51 --> Helper loaded: file_helper
INFO - 2018-02-14 18:11:51 --> Helper loaded: email_helper
INFO - 2018-02-14 18:11:51 --> Helper loaded: common_helper
INFO - 2018-02-14 18:11:51 --> Database Driver Class Initialized
DEBUG - 2018-02-14 18:11:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 18:11:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 18:11:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-14 18:11:51 --> Pagination Class Initialized
INFO - 2018-02-14 18:11:51 --> Helper loaded: form_helper
INFO - 2018-02-14 18:11:51 --> Form Validation Class Initialized
INFO - 2018-02-14 18:11:51 --> Model Class Initialized
INFO - 2018-02-14 18:11:51 --> Controller Class Initialized
INFO - 2018-02-14 18:11:51 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-14 18:11:51 --> Model Class Initialized
INFO - 2018-02-14 18:11:51 --> Model Class Initialized
INFO - 2018-02-14 18:11:51 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-14 18:11:51 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-14 18:11:51 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-14 18:11:51 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-14 18:11:51 --> File loaded: /var/www/html/project/radio/application/views/subcategory/index.php
INFO - 2018-02-14 18:11:51 --> Final output sent to browser
DEBUG - 2018-02-14 18:11:51 --> Total execution time: 0.0064
INFO - 2018-02-14 18:12:46 --> Config Class Initialized
INFO - 2018-02-14 18:12:46 --> Hooks Class Initialized
DEBUG - 2018-02-14 18:12:46 --> UTF-8 Support Enabled
INFO - 2018-02-14 18:12:46 --> Utf8 Class Initialized
INFO - 2018-02-14 18:12:46 --> URI Class Initialized
INFO - 2018-02-14 18:12:46 --> Router Class Initialized
INFO - 2018-02-14 18:12:46 --> Output Class Initialized
INFO - 2018-02-14 18:12:46 --> Security Class Initialized
DEBUG - 2018-02-14 18:12:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 18:12:46 --> Input Class Initialized
INFO - 2018-02-14 18:12:46 --> Language Class Initialized
INFO - 2018-02-14 18:12:46 --> Loader Class Initialized
INFO - 2018-02-14 18:12:46 --> Helper loaded: url_helper
INFO - 2018-02-14 18:12:46 --> Helper loaded: file_helper
INFO - 2018-02-14 18:12:46 --> Helper loaded: email_helper
INFO - 2018-02-14 18:12:46 --> Helper loaded: common_helper
INFO - 2018-02-14 18:12:46 --> Database Driver Class Initialized
DEBUG - 2018-02-14 18:12:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 18:12:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 18:12:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-14 18:12:46 --> Pagination Class Initialized
INFO - 2018-02-14 18:12:46 --> Helper loaded: form_helper
INFO - 2018-02-14 18:12:46 --> Form Validation Class Initialized
INFO - 2018-02-14 18:12:46 --> Model Class Initialized
INFO - 2018-02-14 18:12:46 --> Controller Class Initialized
INFO - 2018-02-14 18:12:46 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-14 18:12:46 --> Model Class Initialized
INFO - 2018-02-14 18:12:46 --> Model Class Initialized
INFO - 2018-02-14 18:12:46 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-14 18:12:46 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-14 18:12:46 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-14 18:12:46 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-14 18:12:46 --> File loaded: /var/www/html/project/radio/application/views/subcategory/index.php
INFO - 2018-02-14 18:12:46 --> Final output sent to browser
DEBUG - 2018-02-14 18:12:46 --> Total execution time: 0.0076
INFO - 2018-02-14 18:12:52 --> Config Class Initialized
INFO - 2018-02-14 18:12:52 --> Hooks Class Initialized
DEBUG - 2018-02-14 18:12:52 --> UTF-8 Support Enabled
INFO - 2018-02-14 18:12:52 --> Utf8 Class Initialized
INFO - 2018-02-14 18:12:52 --> URI Class Initialized
INFO - 2018-02-14 18:12:52 --> Router Class Initialized
INFO - 2018-02-14 18:12:52 --> Output Class Initialized
INFO - 2018-02-14 18:12:52 --> Security Class Initialized
DEBUG - 2018-02-14 18:12:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 18:12:52 --> Input Class Initialized
INFO - 2018-02-14 18:12:52 --> Language Class Initialized
INFO - 2018-02-14 18:12:52 --> Loader Class Initialized
INFO - 2018-02-14 18:12:52 --> Helper loaded: url_helper
INFO - 2018-02-14 18:12:52 --> Helper loaded: file_helper
INFO - 2018-02-14 18:12:52 --> Helper loaded: email_helper
INFO - 2018-02-14 18:12:52 --> Helper loaded: common_helper
INFO - 2018-02-14 18:12:52 --> Database Driver Class Initialized
DEBUG - 2018-02-14 18:12:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 18:12:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 18:12:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-14 18:12:52 --> Pagination Class Initialized
INFO - 2018-02-14 18:12:52 --> Helper loaded: form_helper
INFO - 2018-02-14 18:12:52 --> Form Validation Class Initialized
INFO - 2018-02-14 18:12:52 --> Model Class Initialized
INFO - 2018-02-14 18:12:52 --> Controller Class Initialized
INFO - 2018-02-14 18:12:52 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-14 18:12:52 --> Model Class Initialized
INFO - 2018-02-14 18:12:52 --> Model Class Initialized
INFO - 2018-02-14 18:12:52 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-14 18:12:52 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-14 18:12:52 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-14 18:12:52 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-14 18:12:52 --> File loaded: /var/www/html/project/radio/application/views/subcategory/add_edit.php
INFO - 2018-02-14 18:12:52 --> Final output sent to browser
DEBUG - 2018-02-14 18:12:52 --> Total execution time: 0.0085
INFO - 2018-02-14 18:12:56 --> Config Class Initialized
INFO - 2018-02-14 18:12:56 --> Hooks Class Initialized
DEBUG - 2018-02-14 18:12:56 --> UTF-8 Support Enabled
INFO - 2018-02-14 18:12:56 --> Utf8 Class Initialized
INFO - 2018-02-14 18:12:56 --> URI Class Initialized
INFO - 2018-02-14 18:12:56 --> Router Class Initialized
INFO - 2018-02-14 18:12:56 --> Output Class Initialized
INFO - 2018-02-14 18:12:56 --> Security Class Initialized
DEBUG - 2018-02-14 18:12:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 18:12:56 --> Input Class Initialized
INFO - 2018-02-14 18:12:56 --> Language Class Initialized
INFO - 2018-02-14 18:12:56 --> Loader Class Initialized
INFO - 2018-02-14 18:12:56 --> Helper loaded: url_helper
INFO - 2018-02-14 18:12:56 --> Helper loaded: file_helper
INFO - 2018-02-14 18:12:56 --> Helper loaded: email_helper
INFO - 2018-02-14 18:12:56 --> Helper loaded: common_helper
INFO - 2018-02-14 18:12:56 --> Database Driver Class Initialized
DEBUG - 2018-02-14 18:12:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 18:12:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 18:12:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-14 18:12:56 --> Pagination Class Initialized
INFO - 2018-02-14 18:12:56 --> Helper loaded: form_helper
INFO - 2018-02-14 18:12:56 --> Form Validation Class Initialized
INFO - 2018-02-14 18:12:56 --> Model Class Initialized
INFO - 2018-02-14 18:12:56 --> Controller Class Initialized
INFO - 2018-02-14 18:12:56 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-14 18:12:56 --> Model Class Initialized
INFO - 2018-02-14 18:12:56 --> Model Class Initialized
INFO - 2018-02-14 18:12:56 --> Config Class Initialized
INFO - 2018-02-14 18:12:56 --> Hooks Class Initialized
DEBUG - 2018-02-14 18:12:56 --> UTF-8 Support Enabled
INFO - 2018-02-14 18:12:56 --> Utf8 Class Initialized
INFO - 2018-02-14 18:12:56 --> URI Class Initialized
INFO - 2018-02-14 18:12:56 --> Router Class Initialized
INFO - 2018-02-14 18:12:56 --> Output Class Initialized
INFO - 2018-02-14 18:12:56 --> Security Class Initialized
DEBUG - 2018-02-14 18:12:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 18:12:56 --> Input Class Initialized
INFO - 2018-02-14 18:12:56 --> Language Class Initialized
INFO - 2018-02-14 18:12:56 --> Loader Class Initialized
INFO - 2018-02-14 18:12:56 --> Helper loaded: url_helper
INFO - 2018-02-14 18:12:56 --> Helper loaded: file_helper
INFO - 2018-02-14 18:12:56 --> Helper loaded: email_helper
INFO - 2018-02-14 18:12:56 --> Helper loaded: common_helper
INFO - 2018-02-14 18:12:56 --> Database Driver Class Initialized
DEBUG - 2018-02-14 18:12:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 18:12:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 18:12:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-14 18:12:56 --> Pagination Class Initialized
INFO - 2018-02-14 18:12:56 --> Helper loaded: form_helper
INFO - 2018-02-14 18:12:56 --> Form Validation Class Initialized
INFO - 2018-02-14 18:12:56 --> Model Class Initialized
INFO - 2018-02-14 18:12:56 --> Controller Class Initialized
INFO - 2018-02-14 18:12:56 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-14 18:12:56 --> Model Class Initialized
INFO - 2018-02-14 18:12:56 --> Model Class Initialized
DEBUG - 2018-02-14 18:12:56 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-14 18:12:56 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-02-14 18:12:56 --> Upload Class Initialized
INFO - 2018-02-14 18:12:56 --> Config Class Initialized
INFO - 2018-02-14 18:12:56 --> Hooks Class Initialized
DEBUG - 2018-02-14 18:12:56 --> UTF-8 Support Enabled
INFO - 2018-02-14 18:12:56 --> Utf8 Class Initialized
INFO - 2018-02-14 18:12:56 --> URI Class Initialized
INFO - 2018-02-14 18:12:56 --> Router Class Initialized
INFO - 2018-02-14 18:12:56 --> Output Class Initialized
INFO - 2018-02-14 18:12:56 --> Security Class Initialized
DEBUG - 2018-02-14 18:12:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 18:12:56 --> Input Class Initialized
INFO - 2018-02-14 18:12:56 --> Language Class Initialized
INFO - 2018-02-14 18:12:56 --> Loader Class Initialized
INFO - 2018-02-14 18:12:56 --> Helper loaded: url_helper
INFO - 2018-02-14 18:12:56 --> Helper loaded: file_helper
INFO - 2018-02-14 18:12:56 --> Helper loaded: email_helper
INFO - 2018-02-14 18:12:56 --> Helper loaded: common_helper
INFO - 2018-02-14 18:12:56 --> Database Driver Class Initialized
DEBUG - 2018-02-14 18:12:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 18:12:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 18:12:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-14 18:12:56 --> Pagination Class Initialized
INFO - 2018-02-14 18:12:56 --> Helper loaded: form_helper
INFO - 2018-02-14 18:12:56 --> Form Validation Class Initialized
INFO - 2018-02-14 18:12:56 --> Model Class Initialized
INFO - 2018-02-14 18:12:56 --> Controller Class Initialized
INFO - 2018-02-14 18:12:56 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-14 18:12:56 --> Model Class Initialized
INFO - 2018-02-14 18:12:56 --> Model Class Initialized
INFO - 2018-02-14 18:12:56 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-14 18:12:56 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-14 18:12:56 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-14 18:12:56 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-14 18:12:56 --> File loaded: /var/www/html/project/radio/application/views/subcategory/index.php
INFO - 2018-02-14 18:12:56 --> Final output sent to browser
DEBUG - 2018-02-14 18:12:56 --> Total execution time: 0.0068
INFO - 2018-02-14 18:13:11 --> Config Class Initialized
INFO - 2018-02-14 18:13:11 --> Hooks Class Initialized
DEBUG - 2018-02-14 18:13:11 --> UTF-8 Support Enabled
INFO - 2018-02-14 18:13:11 --> Utf8 Class Initialized
INFO - 2018-02-14 18:13:11 --> URI Class Initialized
INFO - 2018-02-14 18:13:11 --> Router Class Initialized
INFO - 2018-02-14 18:13:11 --> Output Class Initialized
INFO - 2018-02-14 18:13:11 --> Security Class Initialized
DEBUG - 2018-02-14 18:13:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 18:13:11 --> Input Class Initialized
INFO - 2018-02-14 18:13:11 --> Language Class Initialized
INFO - 2018-02-14 18:13:11 --> Loader Class Initialized
INFO - 2018-02-14 18:13:11 --> Helper loaded: url_helper
INFO - 2018-02-14 18:13:11 --> Helper loaded: file_helper
INFO - 2018-02-14 18:13:11 --> Helper loaded: email_helper
INFO - 2018-02-14 18:13:11 --> Helper loaded: common_helper
INFO - 2018-02-14 18:13:11 --> Database Driver Class Initialized
DEBUG - 2018-02-14 18:13:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 18:13:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 18:13:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-14 18:13:11 --> Pagination Class Initialized
INFO - 2018-02-14 18:13:11 --> Helper loaded: form_helper
INFO - 2018-02-14 18:13:11 --> Form Validation Class Initialized
INFO - 2018-02-14 18:13:11 --> Model Class Initialized
INFO - 2018-02-14 18:13:11 --> Controller Class Initialized
INFO - 2018-02-14 18:13:11 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-14 18:13:11 --> Model Class Initialized
INFO - 2018-02-14 18:13:11 --> Model Class Initialized
INFO - 2018-02-14 18:13:11 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-14 18:13:11 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-14 18:13:11 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-14 18:13:11 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-14 18:13:11 --> File loaded: /var/www/html/project/radio/application/views/subcategory/add_edit.php
INFO - 2018-02-14 18:13:11 --> Final output sent to browser
DEBUG - 2018-02-14 18:13:11 --> Total execution time: 0.0055
INFO - 2018-02-14 18:13:19 --> Config Class Initialized
INFO - 2018-02-14 18:13:19 --> Hooks Class Initialized
DEBUG - 2018-02-14 18:13:19 --> UTF-8 Support Enabled
INFO - 2018-02-14 18:13:19 --> Utf8 Class Initialized
INFO - 2018-02-14 18:13:19 --> URI Class Initialized
INFO - 2018-02-14 18:13:19 --> Router Class Initialized
INFO - 2018-02-14 18:13:19 --> Output Class Initialized
INFO - 2018-02-14 18:13:19 --> Security Class Initialized
DEBUG - 2018-02-14 18:13:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 18:13:19 --> Input Class Initialized
INFO - 2018-02-14 18:13:19 --> Language Class Initialized
INFO - 2018-02-14 18:13:19 --> Loader Class Initialized
INFO - 2018-02-14 18:13:19 --> Helper loaded: url_helper
INFO - 2018-02-14 18:13:19 --> Helper loaded: file_helper
INFO - 2018-02-14 18:13:19 --> Helper loaded: email_helper
INFO - 2018-02-14 18:13:19 --> Helper loaded: common_helper
INFO - 2018-02-14 18:13:19 --> Database Driver Class Initialized
DEBUG - 2018-02-14 18:13:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 18:13:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 18:13:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-14 18:13:19 --> Pagination Class Initialized
INFO - 2018-02-14 18:13:19 --> Helper loaded: form_helper
INFO - 2018-02-14 18:13:19 --> Form Validation Class Initialized
INFO - 2018-02-14 18:13:19 --> Model Class Initialized
INFO - 2018-02-14 18:13:19 --> Controller Class Initialized
INFO - 2018-02-14 18:13:19 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-14 18:13:19 --> Model Class Initialized
INFO - 2018-02-14 18:13:19 --> Model Class Initialized
INFO - 2018-02-14 18:13:20 --> Config Class Initialized
INFO - 2018-02-14 18:13:20 --> Hooks Class Initialized
DEBUG - 2018-02-14 18:13:20 --> UTF-8 Support Enabled
INFO - 2018-02-14 18:13:20 --> Utf8 Class Initialized
INFO - 2018-02-14 18:13:20 --> URI Class Initialized
INFO - 2018-02-14 18:13:20 --> Router Class Initialized
INFO - 2018-02-14 18:13:20 --> Output Class Initialized
INFO - 2018-02-14 18:13:20 --> Security Class Initialized
DEBUG - 2018-02-14 18:13:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 18:13:20 --> Input Class Initialized
INFO - 2018-02-14 18:13:20 --> Language Class Initialized
INFO - 2018-02-14 18:13:20 --> Loader Class Initialized
INFO - 2018-02-14 18:13:20 --> Helper loaded: url_helper
INFO - 2018-02-14 18:13:20 --> Helper loaded: file_helper
INFO - 2018-02-14 18:13:20 --> Helper loaded: email_helper
INFO - 2018-02-14 18:13:20 --> Helper loaded: common_helper
INFO - 2018-02-14 18:13:20 --> Database Driver Class Initialized
DEBUG - 2018-02-14 18:13:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 18:13:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 18:13:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-14 18:13:20 --> Pagination Class Initialized
INFO - 2018-02-14 18:13:20 --> Helper loaded: form_helper
INFO - 2018-02-14 18:13:20 --> Form Validation Class Initialized
INFO - 2018-02-14 18:13:20 --> Model Class Initialized
INFO - 2018-02-14 18:13:20 --> Controller Class Initialized
INFO - 2018-02-14 18:13:20 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-14 18:13:20 --> Model Class Initialized
INFO - 2018-02-14 18:13:20 --> Model Class Initialized
DEBUG - 2018-02-14 18:13:20 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-14 18:13:20 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-02-14 18:13:20 --> Config Class Initialized
INFO - 2018-02-14 18:13:20 --> Hooks Class Initialized
DEBUG - 2018-02-14 18:13:20 --> UTF-8 Support Enabled
INFO - 2018-02-14 18:13:20 --> Utf8 Class Initialized
INFO - 2018-02-14 18:13:20 --> URI Class Initialized
INFO - 2018-02-14 18:13:20 --> Router Class Initialized
INFO - 2018-02-14 18:13:20 --> Output Class Initialized
INFO - 2018-02-14 18:13:20 --> Security Class Initialized
DEBUG - 2018-02-14 18:13:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 18:13:20 --> Input Class Initialized
INFO - 2018-02-14 18:13:20 --> Language Class Initialized
INFO - 2018-02-14 18:13:20 --> Loader Class Initialized
INFO - 2018-02-14 18:13:20 --> Helper loaded: url_helper
INFO - 2018-02-14 18:13:20 --> Helper loaded: file_helper
INFO - 2018-02-14 18:13:20 --> Helper loaded: email_helper
INFO - 2018-02-14 18:13:20 --> Helper loaded: common_helper
INFO - 2018-02-14 18:13:20 --> Database Driver Class Initialized
DEBUG - 2018-02-14 18:13:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 18:13:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 18:13:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-14 18:13:20 --> Pagination Class Initialized
INFO - 2018-02-14 18:13:20 --> Helper loaded: form_helper
INFO - 2018-02-14 18:13:20 --> Form Validation Class Initialized
INFO - 2018-02-14 18:13:20 --> Model Class Initialized
INFO - 2018-02-14 18:13:20 --> Controller Class Initialized
INFO - 2018-02-14 18:13:20 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-14 18:13:20 --> Model Class Initialized
INFO - 2018-02-14 18:13:20 --> Model Class Initialized
INFO - 2018-02-14 18:13:20 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-14 18:13:20 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-14 18:13:20 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-14 18:13:20 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-14 18:13:20 --> File loaded: /var/www/html/project/radio/application/views/subcategory/index.php
INFO - 2018-02-14 18:13:20 --> Final output sent to browser
DEBUG - 2018-02-14 18:13:20 --> Total execution time: 0.0046
INFO - 2018-02-14 18:13:22 --> Config Class Initialized
INFO - 2018-02-14 18:13:22 --> Hooks Class Initialized
DEBUG - 2018-02-14 18:13:22 --> UTF-8 Support Enabled
INFO - 2018-02-14 18:13:22 --> Utf8 Class Initialized
INFO - 2018-02-14 18:13:22 --> URI Class Initialized
INFO - 2018-02-14 18:13:22 --> Router Class Initialized
INFO - 2018-02-14 18:13:22 --> Output Class Initialized
INFO - 2018-02-14 18:13:22 --> Security Class Initialized
DEBUG - 2018-02-14 18:13:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 18:13:22 --> Input Class Initialized
INFO - 2018-02-14 18:13:22 --> Language Class Initialized
INFO - 2018-02-14 18:13:22 --> Loader Class Initialized
INFO - 2018-02-14 18:13:22 --> Helper loaded: url_helper
INFO - 2018-02-14 18:13:22 --> Helper loaded: file_helper
INFO - 2018-02-14 18:13:22 --> Helper loaded: email_helper
INFO - 2018-02-14 18:13:22 --> Helper loaded: common_helper
INFO - 2018-02-14 18:13:22 --> Database Driver Class Initialized
DEBUG - 2018-02-14 18:13:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 18:13:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 18:13:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-14 18:13:22 --> Pagination Class Initialized
INFO - 2018-02-14 18:13:22 --> Helper loaded: form_helper
INFO - 2018-02-14 18:13:22 --> Form Validation Class Initialized
INFO - 2018-02-14 18:13:22 --> Model Class Initialized
INFO - 2018-02-14 18:13:22 --> Controller Class Initialized
INFO - 2018-02-14 18:13:22 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-14 18:13:22 --> Model Class Initialized
INFO - 2018-02-14 18:13:22 --> Model Class Initialized
INFO - 2018-02-14 18:13:22 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-14 18:13:22 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-14 18:13:22 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-14 18:13:22 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-14 18:13:22 --> File loaded: /var/www/html/project/radio/application/views/subcategory/add_edit.php
INFO - 2018-02-14 18:13:22 --> Final output sent to browser
DEBUG - 2018-02-14 18:13:22 --> Total execution time: 0.0048
INFO - 2018-02-14 18:13:27 --> Config Class Initialized
INFO - 2018-02-14 18:13:27 --> Hooks Class Initialized
DEBUG - 2018-02-14 18:13:27 --> UTF-8 Support Enabled
INFO - 2018-02-14 18:13:27 --> Utf8 Class Initialized
INFO - 2018-02-14 18:13:27 --> URI Class Initialized
INFO - 2018-02-14 18:13:27 --> Router Class Initialized
INFO - 2018-02-14 18:13:27 --> Output Class Initialized
INFO - 2018-02-14 18:13:27 --> Security Class Initialized
DEBUG - 2018-02-14 18:13:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 18:13:27 --> Input Class Initialized
INFO - 2018-02-14 18:13:27 --> Language Class Initialized
INFO - 2018-02-14 18:13:27 --> Loader Class Initialized
INFO - 2018-02-14 18:13:27 --> Helper loaded: url_helper
INFO - 2018-02-14 18:13:27 --> Helper loaded: file_helper
INFO - 2018-02-14 18:13:27 --> Helper loaded: email_helper
INFO - 2018-02-14 18:13:27 --> Helper loaded: common_helper
INFO - 2018-02-14 18:13:27 --> Database Driver Class Initialized
DEBUG - 2018-02-14 18:13:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 18:13:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 18:13:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-14 18:13:27 --> Pagination Class Initialized
INFO - 2018-02-14 18:13:27 --> Helper loaded: form_helper
INFO - 2018-02-14 18:13:27 --> Form Validation Class Initialized
INFO - 2018-02-14 18:13:27 --> Model Class Initialized
INFO - 2018-02-14 18:13:27 --> Controller Class Initialized
INFO - 2018-02-14 18:13:27 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-14 18:13:27 --> Model Class Initialized
INFO - 2018-02-14 18:13:27 --> Model Class Initialized
INFO - 2018-02-14 18:13:33 --> Config Class Initialized
INFO - 2018-02-14 18:13:33 --> Hooks Class Initialized
DEBUG - 2018-02-14 18:13:33 --> UTF-8 Support Enabled
INFO - 2018-02-14 18:13:33 --> Utf8 Class Initialized
INFO - 2018-02-14 18:13:33 --> URI Class Initialized
INFO - 2018-02-14 18:13:33 --> Router Class Initialized
INFO - 2018-02-14 18:13:33 --> Output Class Initialized
INFO - 2018-02-14 18:13:33 --> Security Class Initialized
DEBUG - 2018-02-14 18:13:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 18:13:33 --> Input Class Initialized
INFO - 2018-02-14 18:13:33 --> Language Class Initialized
INFO - 2018-02-14 18:13:33 --> Loader Class Initialized
INFO - 2018-02-14 18:13:33 --> Helper loaded: url_helper
INFO - 2018-02-14 18:13:33 --> Helper loaded: file_helper
INFO - 2018-02-14 18:13:33 --> Helper loaded: email_helper
INFO - 2018-02-14 18:13:33 --> Helper loaded: common_helper
INFO - 2018-02-14 18:13:33 --> Database Driver Class Initialized
DEBUG - 2018-02-14 18:13:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 18:13:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 18:13:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-14 18:13:33 --> Pagination Class Initialized
INFO - 2018-02-14 18:13:33 --> Helper loaded: form_helper
INFO - 2018-02-14 18:13:33 --> Form Validation Class Initialized
INFO - 2018-02-14 18:13:33 --> Model Class Initialized
INFO - 2018-02-14 18:13:33 --> Controller Class Initialized
INFO - 2018-02-14 18:13:33 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-14 18:13:33 --> Model Class Initialized
INFO - 2018-02-14 18:13:33 --> Model Class Initialized
INFO - 2018-02-14 18:13:33 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-14 18:13:33 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-14 18:13:33 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-14 18:13:33 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-14 18:13:33 --> File loaded: /var/www/html/project/radio/application/views/subcategory/index.php
INFO - 2018-02-14 18:13:33 --> Final output sent to browser
DEBUG - 2018-02-14 18:13:33 --> Total execution time: 0.0102
INFO - 2018-02-14 18:13:39 --> Config Class Initialized
INFO - 2018-02-14 18:13:39 --> Hooks Class Initialized
DEBUG - 2018-02-14 18:13:39 --> UTF-8 Support Enabled
INFO - 2018-02-14 18:13:39 --> Utf8 Class Initialized
INFO - 2018-02-14 18:13:39 --> URI Class Initialized
INFO - 2018-02-14 18:13:39 --> Router Class Initialized
INFO - 2018-02-14 18:13:39 --> Output Class Initialized
INFO - 2018-02-14 18:13:39 --> Security Class Initialized
DEBUG - 2018-02-14 18:13:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 18:13:39 --> Input Class Initialized
INFO - 2018-02-14 18:13:39 --> Language Class Initialized
INFO - 2018-02-14 18:13:39 --> Loader Class Initialized
INFO - 2018-02-14 18:13:39 --> Helper loaded: url_helper
INFO - 2018-02-14 18:13:39 --> Helper loaded: file_helper
INFO - 2018-02-14 18:13:39 --> Helper loaded: email_helper
INFO - 2018-02-14 18:13:39 --> Helper loaded: common_helper
INFO - 2018-02-14 18:13:39 --> Database Driver Class Initialized
DEBUG - 2018-02-14 18:13:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 18:13:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 18:13:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-14 18:13:39 --> Pagination Class Initialized
INFO - 2018-02-14 18:13:39 --> Helper loaded: form_helper
INFO - 2018-02-14 18:13:39 --> Form Validation Class Initialized
INFO - 2018-02-14 18:13:39 --> Model Class Initialized
INFO - 2018-02-14 18:13:39 --> Controller Class Initialized
INFO - 2018-02-14 18:13:39 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-14 18:13:39 --> Model Class Initialized
INFO - 2018-02-14 18:13:39 --> Model Class Initialized
INFO - 2018-02-14 18:13:39 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-14 18:13:39 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-14 18:13:39 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-14 18:13:39 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-14 18:13:39 --> File loaded: /var/www/html/project/radio/application/views/subcategory/add_edit.php
INFO - 2018-02-14 18:13:39 --> Final output sent to browser
DEBUG - 2018-02-14 18:13:39 --> Total execution time: 0.0081
INFO - 2018-02-14 18:13:42 --> Config Class Initialized
INFO - 2018-02-14 18:13:42 --> Hooks Class Initialized
DEBUG - 2018-02-14 18:13:42 --> UTF-8 Support Enabled
INFO - 2018-02-14 18:13:42 --> Utf8 Class Initialized
INFO - 2018-02-14 18:13:42 --> URI Class Initialized
INFO - 2018-02-14 18:13:42 --> Router Class Initialized
INFO - 2018-02-14 18:13:42 --> Output Class Initialized
INFO - 2018-02-14 18:13:42 --> Security Class Initialized
DEBUG - 2018-02-14 18:13:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 18:13:42 --> Input Class Initialized
INFO - 2018-02-14 18:13:42 --> Language Class Initialized
INFO - 2018-02-14 18:13:42 --> Loader Class Initialized
INFO - 2018-02-14 18:13:42 --> Helper loaded: url_helper
INFO - 2018-02-14 18:13:42 --> Helper loaded: file_helper
INFO - 2018-02-14 18:13:42 --> Helper loaded: email_helper
INFO - 2018-02-14 18:13:42 --> Helper loaded: common_helper
INFO - 2018-02-14 18:13:42 --> Database Driver Class Initialized
DEBUG - 2018-02-14 18:13:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 18:13:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 18:13:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-14 18:13:42 --> Pagination Class Initialized
INFO - 2018-02-14 18:13:42 --> Helper loaded: form_helper
INFO - 2018-02-14 18:13:42 --> Form Validation Class Initialized
INFO - 2018-02-14 18:13:42 --> Model Class Initialized
INFO - 2018-02-14 18:13:42 --> Controller Class Initialized
INFO - 2018-02-14 18:13:42 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-14 18:13:42 --> Model Class Initialized
INFO - 2018-02-14 18:13:42 --> Model Class Initialized
INFO - 2018-02-14 18:13:42 --> Config Class Initialized
INFO - 2018-02-14 18:13:42 --> Hooks Class Initialized
DEBUG - 2018-02-14 18:13:42 --> UTF-8 Support Enabled
INFO - 2018-02-14 18:13:42 --> Utf8 Class Initialized
INFO - 2018-02-14 18:13:42 --> URI Class Initialized
INFO - 2018-02-14 18:13:42 --> Router Class Initialized
INFO - 2018-02-14 18:13:42 --> Output Class Initialized
INFO - 2018-02-14 18:13:42 --> Security Class Initialized
DEBUG - 2018-02-14 18:13:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 18:13:42 --> Input Class Initialized
INFO - 2018-02-14 18:13:42 --> Language Class Initialized
INFO - 2018-02-14 18:13:42 --> Loader Class Initialized
INFO - 2018-02-14 18:13:42 --> Helper loaded: url_helper
INFO - 2018-02-14 18:13:42 --> Helper loaded: file_helper
INFO - 2018-02-14 18:13:42 --> Helper loaded: email_helper
INFO - 2018-02-14 18:13:42 --> Helper loaded: common_helper
INFO - 2018-02-14 18:13:42 --> Database Driver Class Initialized
DEBUG - 2018-02-14 18:13:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 18:13:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 18:13:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-14 18:13:42 --> Pagination Class Initialized
INFO - 2018-02-14 18:13:42 --> Helper loaded: form_helper
INFO - 2018-02-14 18:13:42 --> Form Validation Class Initialized
INFO - 2018-02-14 18:13:42 --> Model Class Initialized
INFO - 2018-02-14 18:13:42 --> Controller Class Initialized
INFO - 2018-02-14 18:13:42 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-14 18:13:42 --> Model Class Initialized
INFO - 2018-02-14 18:13:42 --> Model Class Initialized
DEBUG - 2018-02-14 18:13:42 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-14 18:13:42 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-02-14 18:13:42 --> Config Class Initialized
INFO - 2018-02-14 18:13:42 --> Hooks Class Initialized
DEBUG - 2018-02-14 18:13:42 --> UTF-8 Support Enabled
INFO - 2018-02-14 18:13:42 --> Utf8 Class Initialized
INFO - 2018-02-14 18:13:42 --> URI Class Initialized
INFO - 2018-02-14 18:13:42 --> Router Class Initialized
INFO - 2018-02-14 18:13:42 --> Output Class Initialized
INFO - 2018-02-14 18:13:42 --> Security Class Initialized
DEBUG - 2018-02-14 18:13:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 18:13:42 --> Input Class Initialized
INFO - 2018-02-14 18:13:42 --> Language Class Initialized
INFO - 2018-02-14 18:13:42 --> Loader Class Initialized
INFO - 2018-02-14 18:13:42 --> Helper loaded: url_helper
INFO - 2018-02-14 18:13:42 --> Helper loaded: file_helper
INFO - 2018-02-14 18:13:42 --> Helper loaded: email_helper
INFO - 2018-02-14 18:13:42 --> Helper loaded: common_helper
INFO - 2018-02-14 18:13:42 --> Database Driver Class Initialized
DEBUG - 2018-02-14 18:13:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 18:13:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 18:13:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-14 18:13:42 --> Pagination Class Initialized
INFO - 2018-02-14 18:13:42 --> Helper loaded: form_helper
INFO - 2018-02-14 18:13:42 --> Form Validation Class Initialized
INFO - 2018-02-14 18:13:42 --> Model Class Initialized
INFO - 2018-02-14 18:13:42 --> Controller Class Initialized
INFO - 2018-02-14 18:13:42 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-14 18:13:42 --> Model Class Initialized
INFO - 2018-02-14 18:13:42 --> Model Class Initialized
INFO - 2018-02-14 18:13:42 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-14 18:13:42 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-14 18:13:42 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-14 18:13:42 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-14 18:13:42 --> File loaded: /var/www/html/project/radio/application/views/subcategory/index.php
INFO - 2018-02-14 18:13:42 --> Final output sent to browser
DEBUG - 2018-02-14 18:13:42 --> Total execution time: 0.0056
INFO - 2018-02-14 18:13:45 --> Config Class Initialized
INFO - 2018-02-14 18:13:45 --> Hooks Class Initialized
DEBUG - 2018-02-14 18:13:45 --> UTF-8 Support Enabled
INFO - 2018-02-14 18:13:45 --> Utf8 Class Initialized
INFO - 2018-02-14 18:13:45 --> URI Class Initialized
INFO - 2018-02-14 18:13:45 --> Router Class Initialized
INFO - 2018-02-14 18:13:45 --> Output Class Initialized
INFO - 2018-02-14 18:13:45 --> Security Class Initialized
DEBUG - 2018-02-14 18:13:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 18:13:45 --> Input Class Initialized
INFO - 2018-02-14 18:13:45 --> Language Class Initialized
INFO - 2018-02-14 18:13:45 --> Loader Class Initialized
INFO - 2018-02-14 18:13:45 --> Helper loaded: url_helper
INFO - 2018-02-14 18:13:45 --> Helper loaded: file_helper
INFO - 2018-02-14 18:13:45 --> Helper loaded: email_helper
INFO - 2018-02-14 18:13:45 --> Helper loaded: common_helper
INFO - 2018-02-14 18:13:45 --> Database Driver Class Initialized
DEBUG - 2018-02-14 18:13:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 18:13:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 18:13:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-14 18:13:45 --> Pagination Class Initialized
INFO - 2018-02-14 18:13:45 --> Helper loaded: form_helper
INFO - 2018-02-14 18:13:45 --> Form Validation Class Initialized
INFO - 2018-02-14 18:13:45 --> Model Class Initialized
INFO - 2018-02-14 18:13:45 --> Controller Class Initialized
INFO - 2018-02-14 18:13:45 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-14 18:13:45 --> Model Class Initialized
INFO - 2018-02-14 18:13:45 --> Model Class Initialized
INFO - 2018-02-14 18:13:45 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-14 18:13:45 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-14 18:13:45 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-14 18:13:45 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-14 18:13:45 --> File loaded: /var/www/html/project/radio/application/views/subcategory/add_edit.php
INFO - 2018-02-14 18:13:45 --> Final output sent to browser
DEBUG - 2018-02-14 18:13:45 --> Total execution time: 0.0049
INFO - 2018-02-14 18:13:50 --> Config Class Initialized
INFO - 2018-02-14 18:13:50 --> Hooks Class Initialized
DEBUG - 2018-02-14 18:13:50 --> UTF-8 Support Enabled
INFO - 2018-02-14 18:13:50 --> Utf8 Class Initialized
INFO - 2018-02-14 18:13:50 --> URI Class Initialized
INFO - 2018-02-14 18:13:50 --> Router Class Initialized
INFO - 2018-02-14 18:13:50 --> Output Class Initialized
INFO - 2018-02-14 18:13:50 --> Security Class Initialized
DEBUG - 2018-02-14 18:13:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 18:13:50 --> Input Class Initialized
INFO - 2018-02-14 18:13:50 --> Language Class Initialized
INFO - 2018-02-14 18:13:50 --> Loader Class Initialized
INFO - 2018-02-14 18:13:50 --> Helper loaded: url_helper
INFO - 2018-02-14 18:13:50 --> Helper loaded: file_helper
INFO - 2018-02-14 18:13:50 --> Helper loaded: email_helper
INFO - 2018-02-14 18:13:50 --> Helper loaded: common_helper
INFO - 2018-02-14 18:13:50 --> Database Driver Class Initialized
DEBUG - 2018-02-14 18:13:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 18:13:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 18:13:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-14 18:13:50 --> Pagination Class Initialized
INFO - 2018-02-14 18:13:50 --> Helper loaded: form_helper
INFO - 2018-02-14 18:13:50 --> Form Validation Class Initialized
INFO - 2018-02-14 18:13:50 --> Model Class Initialized
INFO - 2018-02-14 18:13:50 --> Controller Class Initialized
INFO - 2018-02-14 18:13:50 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-14 18:13:50 --> Model Class Initialized
INFO - 2018-02-14 18:13:50 --> Model Class Initialized
INFO - 2018-02-14 18:13:50 --> Config Class Initialized
INFO - 2018-02-14 18:13:50 --> Hooks Class Initialized
DEBUG - 2018-02-14 18:13:50 --> UTF-8 Support Enabled
INFO - 2018-02-14 18:13:50 --> Utf8 Class Initialized
INFO - 2018-02-14 18:13:50 --> URI Class Initialized
INFO - 2018-02-14 18:13:50 --> Router Class Initialized
INFO - 2018-02-14 18:13:50 --> Output Class Initialized
INFO - 2018-02-14 18:13:50 --> Security Class Initialized
DEBUG - 2018-02-14 18:13:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 18:13:50 --> Input Class Initialized
INFO - 2018-02-14 18:13:50 --> Language Class Initialized
INFO - 2018-02-14 18:13:50 --> Loader Class Initialized
INFO - 2018-02-14 18:13:50 --> Helper loaded: url_helper
INFO - 2018-02-14 18:13:50 --> Helper loaded: file_helper
INFO - 2018-02-14 18:13:50 --> Helper loaded: email_helper
INFO - 2018-02-14 18:13:50 --> Helper loaded: common_helper
INFO - 2018-02-14 18:13:50 --> Database Driver Class Initialized
DEBUG - 2018-02-14 18:13:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 18:13:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 18:13:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-14 18:13:50 --> Pagination Class Initialized
INFO - 2018-02-14 18:13:50 --> Helper loaded: form_helper
INFO - 2018-02-14 18:13:50 --> Form Validation Class Initialized
INFO - 2018-02-14 18:13:50 --> Model Class Initialized
INFO - 2018-02-14 18:13:50 --> Controller Class Initialized
INFO - 2018-02-14 18:13:50 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-14 18:13:50 --> Model Class Initialized
INFO - 2018-02-14 18:13:50 --> Model Class Initialized
DEBUG - 2018-02-14 18:13:50 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-14 18:13:50 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-02-14 18:13:50 --> Config Class Initialized
INFO - 2018-02-14 18:13:50 --> Hooks Class Initialized
DEBUG - 2018-02-14 18:13:50 --> UTF-8 Support Enabled
INFO - 2018-02-14 18:13:50 --> Utf8 Class Initialized
INFO - 2018-02-14 18:13:50 --> URI Class Initialized
INFO - 2018-02-14 18:13:50 --> Router Class Initialized
INFO - 2018-02-14 18:13:50 --> Output Class Initialized
INFO - 2018-02-14 18:13:50 --> Security Class Initialized
DEBUG - 2018-02-14 18:13:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 18:13:50 --> Input Class Initialized
INFO - 2018-02-14 18:13:50 --> Language Class Initialized
INFO - 2018-02-14 18:13:50 --> Loader Class Initialized
INFO - 2018-02-14 18:13:50 --> Helper loaded: url_helper
INFO - 2018-02-14 18:13:50 --> Helper loaded: file_helper
INFO - 2018-02-14 18:13:50 --> Helper loaded: email_helper
INFO - 2018-02-14 18:13:50 --> Helper loaded: common_helper
INFO - 2018-02-14 18:13:50 --> Database Driver Class Initialized
DEBUG - 2018-02-14 18:13:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 18:13:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 18:13:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-14 18:13:50 --> Pagination Class Initialized
INFO - 2018-02-14 18:13:50 --> Helper loaded: form_helper
INFO - 2018-02-14 18:13:50 --> Form Validation Class Initialized
INFO - 2018-02-14 18:13:50 --> Model Class Initialized
INFO - 2018-02-14 18:13:50 --> Controller Class Initialized
INFO - 2018-02-14 18:13:50 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-14 18:13:50 --> Model Class Initialized
INFO - 2018-02-14 18:13:50 --> Model Class Initialized
INFO - 2018-02-14 18:13:50 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-14 18:13:50 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-14 18:13:50 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-14 18:13:50 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-14 18:13:50 --> File loaded: /var/www/html/project/radio/application/views/subcategory/index.php
INFO - 2018-02-14 18:13:50 --> Final output sent to browser
DEBUG - 2018-02-14 18:13:50 --> Total execution time: 0.0043
INFO - 2018-02-14 18:13:54 --> Config Class Initialized
INFO - 2018-02-14 18:13:54 --> Hooks Class Initialized
DEBUG - 2018-02-14 18:13:54 --> UTF-8 Support Enabled
INFO - 2018-02-14 18:13:54 --> Utf8 Class Initialized
INFO - 2018-02-14 18:13:54 --> URI Class Initialized
INFO - 2018-02-14 18:13:54 --> Router Class Initialized
INFO - 2018-02-14 18:13:54 --> Output Class Initialized
INFO - 2018-02-14 18:13:54 --> Security Class Initialized
DEBUG - 2018-02-14 18:13:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 18:13:54 --> Input Class Initialized
INFO - 2018-02-14 18:13:54 --> Language Class Initialized
INFO - 2018-02-14 18:13:54 --> Loader Class Initialized
INFO - 2018-02-14 18:13:54 --> Helper loaded: url_helper
INFO - 2018-02-14 18:13:54 --> Helper loaded: file_helper
INFO - 2018-02-14 18:13:54 --> Helper loaded: email_helper
INFO - 2018-02-14 18:13:54 --> Helper loaded: common_helper
INFO - 2018-02-14 18:13:54 --> Database Driver Class Initialized
DEBUG - 2018-02-14 18:13:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 18:13:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 18:13:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-14 18:13:54 --> Pagination Class Initialized
INFO - 2018-02-14 18:13:54 --> Helper loaded: form_helper
INFO - 2018-02-14 18:13:54 --> Form Validation Class Initialized
INFO - 2018-02-14 18:13:54 --> Model Class Initialized
INFO - 2018-02-14 18:13:54 --> Controller Class Initialized
INFO - 2018-02-14 18:13:54 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-14 18:13:54 --> Model Class Initialized
INFO - 2018-02-14 18:13:54 --> Model Class Initialized
INFO - 2018-02-14 18:13:54 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-14 18:13:54 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-14 18:13:54 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-14 18:13:54 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-14 18:13:54 --> File loaded: /var/www/html/project/radio/application/views/subcategory/add_edit.php
INFO - 2018-02-14 18:13:54 --> Final output sent to browser
DEBUG - 2018-02-14 18:13:54 --> Total execution time: 0.0063
INFO - 2018-02-14 18:13:56 --> Config Class Initialized
INFO - 2018-02-14 18:13:56 --> Hooks Class Initialized
DEBUG - 2018-02-14 18:13:56 --> UTF-8 Support Enabled
INFO - 2018-02-14 18:13:56 --> Utf8 Class Initialized
INFO - 2018-02-14 18:13:56 --> URI Class Initialized
INFO - 2018-02-14 18:13:56 --> Router Class Initialized
INFO - 2018-02-14 18:13:56 --> Output Class Initialized
INFO - 2018-02-14 18:13:56 --> Security Class Initialized
DEBUG - 2018-02-14 18:13:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 18:13:56 --> Input Class Initialized
INFO - 2018-02-14 18:13:56 --> Language Class Initialized
INFO - 2018-02-14 18:13:56 --> Loader Class Initialized
INFO - 2018-02-14 18:13:56 --> Helper loaded: url_helper
INFO - 2018-02-14 18:13:56 --> Helper loaded: file_helper
INFO - 2018-02-14 18:13:56 --> Helper loaded: email_helper
INFO - 2018-02-14 18:13:56 --> Helper loaded: common_helper
INFO - 2018-02-14 18:13:56 --> Database Driver Class Initialized
DEBUG - 2018-02-14 18:13:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 18:13:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 18:13:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-14 18:13:56 --> Pagination Class Initialized
INFO - 2018-02-14 18:13:56 --> Helper loaded: form_helper
INFO - 2018-02-14 18:13:56 --> Form Validation Class Initialized
INFO - 2018-02-14 18:13:56 --> Model Class Initialized
INFO - 2018-02-14 18:13:56 --> Controller Class Initialized
INFO - 2018-02-14 18:13:56 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-14 18:13:56 --> Model Class Initialized
INFO - 2018-02-14 18:13:56 --> Model Class Initialized
INFO - 2018-02-14 18:14:00 --> Config Class Initialized
INFO - 2018-02-14 18:14:00 --> Hooks Class Initialized
DEBUG - 2018-02-14 18:14:00 --> UTF-8 Support Enabled
INFO - 2018-02-14 18:14:00 --> Utf8 Class Initialized
INFO - 2018-02-14 18:14:00 --> URI Class Initialized
INFO - 2018-02-14 18:14:00 --> Router Class Initialized
INFO - 2018-02-14 18:14:00 --> Output Class Initialized
INFO - 2018-02-14 18:14:00 --> Security Class Initialized
DEBUG - 2018-02-14 18:14:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 18:14:00 --> Input Class Initialized
INFO - 2018-02-14 18:14:00 --> Language Class Initialized
INFO - 2018-02-14 18:14:00 --> Loader Class Initialized
INFO - 2018-02-14 18:14:00 --> Helper loaded: url_helper
INFO - 2018-02-14 18:14:00 --> Helper loaded: file_helper
INFO - 2018-02-14 18:14:00 --> Helper loaded: email_helper
INFO - 2018-02-14 18:14:00 --> Helper loaded: common_helper
INFO - 2018-02-14 18:14:00 --> Database Driver Class Initialized
DEBUG - 2018-02-14 18:14:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 18:14:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 18:14:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-14 18:14:00 --> Pagination Class Initialized
INFO - 2018-02-14 18:14:00 --> Helper loaded: form_helper
INFO - 2018-02-14 18:14:00 --> Form Validation Class Initialized
INFO - 2018-02-14 18:14:00 --> Model Class Initialized
INFO - 2018-02-14 18:14:00 --> Controller Class Initialized
INFO - 2018-02-14 18:14:00 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-14 18:14:00 --> Model Class Initialized
INFO - 2018-02-14 18:14:00 --> Model Class Initialized
INFO - 2018-02-14 18:14:00 --> Config Class Initialized
INFO - 2018-02-14 18:14:00 --> Hooks Class Initialized
DEBUG - 2018-02-14 18:14:00 --> UTF-8 Support Enabled
INFO - 2018-02-14 18:14:00 --> Utf8 Class Initialized
INFO - 2018-02-14 18:14:00 --> URI Class Initialized
INFO - 2018-02-14 18:14:00 --> Router Class Initialized
INFO - 2018-02-14 18:14:00 --> Output Class Initialized
INFO - 2018-02-14 18:14:00 --> Security Class Initialized
DEBUG - 2018-02-14 18:14:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 18:14:00 --> Input Class Initialized
INFO - 2018-02-14 18:14:00 --> Language Class Initialized
INFO - 2018-02-14 18:14:00 --> Loader Class Initialized
INFO - 2018-02-14 18:14:00 --> Helper loaded: url_helper
INFO - 2018-02-14 18:14:00 --> Helper loaded: file_helper
INFO - 2018-02-14 18:14:00 --> Helper loaded: email_helper
INFO - 2018-02-14 18:14:00 --> Helper loaded: common_helper
INFO - 2018-02-14 18:14:00 --> Database Driver Class Initialized
DEBUG - 2018-02-14 18:14:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 18:14:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 18:14:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-14 18:14:00 --> Pagination Class Initialized
INFO - 2018-02-14 18:14:00 --> Helper loaded: form_helper
INFO - 2018-02-14 18:14:00 --> Form Validation Class Initialized
INFO - 2018-02-14 18:14:00 --> Model Class Initialized
INFO - 2018-02-14 18:14:00 --> Controller Class Initialized
INFO - 2018-02-14 18:14:00 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-14 18:14:00 --> Model Class Initialized
INFO - 2018-02-14 18:14:00 --> Model Class Initialized
DEBUG - 2018-02-14 18:14:00 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-14 18:14:00 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-02-14 18:14:00 --> Config Class Initialized
INFO - 2018-02-14 18:14:00 --> Hooks Class Initialized
DEBUG - 2018-02-14 18:14:00 --> UTF-8 Support Enabled
INFO - 2018-02-14 18:14:00 --> Utf8 Class Initialized
INFO - 2018-02-14 18:14:00 --> URI Class Initialized
INFO - 2018-02-14 18:14:00 --> Router Class Initialized
INFO - 2018-02-14 18:14:00 --> Output Class Initialized
INFO - 2018-02-14 18:14:00 --> Security Class Initialized
DEBUG - 2018-02-14 18:14:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 18:14:00 --> Input Class Initialized
INFO - 2018-02-14 18:14:00 --> Language Class Initialized
INFO - 2018-02-14 18:14:00 --> Loader Class Initialized
INFO - 2018-02-14 18:14:00 --> Helper loaded: url_helper
INFO - 2018-02-14 18:14:00 --> Helper loaded: file_helper
INFO - 2018-02-14 18:14:00 --> Helper loaded: email_helper
INFO - 2018-02-14 18:14:00 --> Helper loaded: common_helper
INFO - 2018-02-14 18:14:00 --> Database Driver Class Initialized
DEBUG - 2018-02-14 18:14:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 18:14:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 18:14:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-14 18:14:00 --> Pagination Class Initialized
INFO - 2018-02-14 18:14:00 --> Helper loaded: form_helper
INFO - 2018-02-14 18:14:00 --> Form Validation Class Initialized
INFO - 2018-02-14 18:14:00 --> Model Class Initialized
INFO - 2018-02-14 18:14:00 --> Controller Class Initialized
INFO - 2018-02-14 18:14:00 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-14 18:14:00 --> Model Class Initialized
INFO - 2018-02-14 18:14:00 --> Model Class Initialized
INFO - 2018-02-14 18:14:00 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-14 18:14:00 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-14 18:14:00 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-14 18:14:00 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-14 18:14:00 --> File loaded: /var/www/html/project/radio/application/views/subcategory/index.php
INFO - 2018-02-14 18:14:00 --> Final output sent to browser
DEBUG - 2018-02-14 18:14:00 --> Total execution time: 0.0052
INFO - 2018-02-14 18:17:47 --> Config Class Initialized
INFO - 2018-02-14 18:17:47 --> Hooks Class Initialized
DEBUG - 2018-02-14 18:17:47 --> UTF-8 Support Enabled
INFO - 2018-02-14 18:17:47 --> Utf8 Class Initialized
INFO - 2018-02-14 18:17:47 --> URI Class Initialized
INFO - 2018-02-14 18:17:47 --> Router Class Initialized
INFO - 2018-02-14 18:17:47 --> Output Class Initialized
INFO - 2018-02-14 18:17:47 --> Security Class Initialized
DEBUG - 2018-02-14 18:17:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 18:17:47 --> Input Class Initialized
INFO - 2018-02-14 18:17:47 --> Language Class Initialized
INFO - 2018-02-14 18:17:47 --> Loader Class Initialized
INFO - 2018-02-14 18:17:47 --> Helper loaded: url_helper
INFO - 2018-02-14 18:17:47 --> Helper loaded: file_helper
INFO - 2018-02-14 18:17:47 --> Helper loaded: email_helper
INFO - 2018-02-14 18:17:47 --> Helper loaded: common_helper
INFO - 2018-02-14 18:17:47 --> Database Driver Class Initialized
DEBUG - 2018-02-14 18:17:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 18:17:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 18:17:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-14 18:17:47 --> Pagination Class Initialized
INFO - 2018-02-14 18:17:47 --> Helper loaded: form_helper
INFO - 2018-02-14 18:17:47 --> Form Validation Class Initialized
INFO - 2018-02-14 18:17:47 --> Model Class Initialized
INFO - 2018-02-14 18:17:47 --> Controller Class Initialized
INFO - 2018-02-14 18:17:47 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-14 18:17:47 --> Model Class Initialized
INFO - 2018-02-14 18:17:47 --> Model Class Initialized
INFO - 2018-02-14 18:17:47 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-14 18:17:47 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-14 18:17:47 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-14 18:17:47 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-14 18:17:47 --> File loaded: /var/www/html/project/radio/application/views/subcategory/index.php
INFO - 2018-02-14 18:17:47 --> Final output sent to browser
DEBUG - 2018-02-14 18:17:47 --> Total execution time: 0.0077
INFO - 2018-02-14 18:17:48 --> Config Class Initialized
INFO - 2018-02-14 18:17:48 --> Hooks Class Initialized
DEBUG - 2018-02-14 18:17:48 --> UTF-8 Support Enabled
INFO - 2018-02-14 18:17:48 --> Utf8 Class Initialized
INFO - 2018-02-14 18:17:48 --> URI Class Initialized
INFO - 2018-02-14 18:17:48 --> Router Class Initialized
INFO - 2018-02-14 18:17:48 --> Output Class Initialized
INFO - 2018-02-14 18:17:48 --> Security Class Initialized
DEBUG - 2018-02-14 18:17:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 18:17:48 --> Input Class Initialized
INFO - 2018-02-14 18:17:48 --> Language Class Initialized
INFO - 2018-02-14 18:17:48 --> Loader Class Initialized
INFO - 2018-02-14 18:17:48 --> Helper loaded: url_helper
INFO - 2018-02-14 18:17:48 --> Helper loaded: file_helper
INFO - 2018-02-14 18:17:48 --> Helper loaded: email_helper
INFO - 2018-02-14 18:17:48 --> Helper loaded: common_helper
INFO - 2018-02-14 18:17:48 --> Database Driver Class Initialized
DEBUG - 2018-02-14 18:17:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 18:17:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 18:17:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-14 18:17:48 --> Pagination Class Initialized
INFO - 2018-02-14 18:17:48 --> Helper loaded: form_helper
INFO - 2018-02-14 18:17:48 --> Form Validation Class Initialized
INFO - 2018-02-14 18:17:48 --> Model Class Initialized
INFO - 2018-02-14 18:17:48 --> Controller Class Initialized
INFO - 2018-02-14 18:17:48 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-14 18:17:48 --> Model Class Initialized
INFO - 2018-02-14 18:17:48 --> Model Class Initialized
INFO - 2018-02-14 18:17:48 --> Config Class Initialized
INFO - 2018-02-14 18:17:48 --> Hooks Class Initialized
DEBUG - 2018-02-14 18:17:48 --> UTF-8 Support Enabled
INFO - 2018-02-14 18:17:48 --> Utf8 Class Initialized
INFO - 2018-02-14 18:17:48 --> URI Class Initialized
INFO - 2018-02-14 18:17:48 --> Router Class Initialized
INFO - 2018-02-14 18:17:48 --> Output Class Initialized
INFO - 2018-02-14 18:17:48 --> Security Class Initialized
DEBUG - 2018-02-14 18:17:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 18:17:48 --> Input Class Initialized
INFO - 2018-02-14 18:17:48 --> Language Class Initialized
INFO - 2018-02-14 18:17:48 --> Loader Class Initialized
INFO - 2018-02-14 18:17:48 --> Helper loaded: url_helper
INFO - 2018-02-14 18:17:48 --> Helper loaded: file_helper
INFO - 2018-02-14 18:17:48 --> Helper loaded: email_helper
INFO - 2018-02-14 18:17:48 --> Helper loaded: common_helper
INFO - 2018-02-14 18:17:48 --> Database Driver Class Initialized
DEBUG - 2018-02-14 18:17:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 18:17:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 18:17:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-14 18:17:48 --> Pagination Class Initialized
INFO - 2018-02-14 18:17:48 --> Helper loaded: form_helper
INFO - 2018-02-14 18:17:48 --> Form Validation Class Initialized
INFO - 2018-02-14 18:17:48 --> Model Class Initialized
INFO - 2018-02-14 18:17:48 --> Controller Class Initialized
INFO - 2018-02-14 18:17:48 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-14 18:17:48 --> Model Class Initialized
INFO - 2018-02-14 18:17:48 --> Model Class Initialized
INFO - 2018-02-14 18:17:48 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-14 18:17:48 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-14 18:17:48 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-14 18:17:48 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-14 18:17:48 --> File loaded: /var/www/html/project/radio/application/views/subcategory/index.php
INFO - 2018-02-14 18:17:48 --> Final output sent to browser
DEBUG - 2018-02-14 18:17:48 --> Total execution time: 0.0062
INFO - 2018-02-14 18:17:54 --> Config Class Initialized
INFO - 2018-02-14 18:17:54 --> Hooks Class Initialized
DEBUG - 2018-02-14 18:17:54 --> UTF-8 Support Enabled
INFO - 2018-02-14 18:17:54 --> Utf8 Class Initialized
INFO - 2018-02-14 18:17:54 --> URI Class Initialized
INFO - 2018-02-14 18:17:54 --> Router Class Initialized
INFO - 2018-02-14 18:17:54 --> Output Class Initialized
INFO - 2018-02-14 18:17:54 --> Security Class Initialized
DEBUG - 2018-02-14 18:17:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 18:17:54 --> Input Class Initialized
INFO - 2018-02-14 18:17:54 --> Language Class Initialized
INFO - 2018-02-14 18:17:54 --> Loader Class Initialized
INFO - 2018-02-14 18:17:54 --> Helper loaded: url_helper
INFO - 2018-02-14 18:17:54 --> Helper loaded: file_helper
INFO - 2018-02-14 18:17:54 --> Helper loaded: email_helper
INFO - 2018-02-14 18:17:54 --> Helper loaded: common_helper
INFO - 2018-02-14 18:17:54 --> Database Driver Class Initialized
DEBUG - 2018-02-14 18:17:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 18:17:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 18:17:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-14 18:17:54 --> Pagination Class Initialized
INFO - 2018-02-14 18:17:54 --> Helper loaded: form_helper
INFO - 2018-02-14 18:17:54 --> Form Validation Class Initialized
INFO - 2018-02-14 18:17:54 --> Model Class Initialized
INFO - 2018-02-14 18:17:54 --> Controller Class Initialized
INFO - 2018-02-14 18:17:54 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-14 18:17:54 --> Model Class Initialized
INFO - 2018-02-14 18:17:54 --> Model Class Initialized
INFO - 2018-02-14 18:17:54 --> Config Class Initialized
INFO - 2018-02-14 18:17:54 --> Hooks Class Initialized
DEBUG - 2018-02-14 18:17:54 --> UTF-8 Support Enabled
INFO - 2018-02-14 18:17:54 --> Utf8 Class Initialized
INFO - 2018-02-14 18:17:54 --> URI Class Initialized
INFO - 2018-02-14 18:17:54 --> Router Class Initialized
INFO - 2018-02-14 18:17:54 --> Output Class Initialized
INFO - 2018-02-14 18:17:54 --> Security Class Initialized
DEBUG - 2018-02-14 18:17:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 18:17:54 --> Input Class Initialized
INFO - 2018-02-14 18:17:54 --> Language Class Initialized
INFO - 2018-02-14 18:17:54 --> Loader Class Initialized
INFO - 2018-02-14 18:17:54 --> Helper loaded: url_helper
INFO - 2018-02-14 18:17:54 --> Helper loaded: file_helper
INFO - 2018-02-14 18:17:54 --> Helper loaded: email_helper
INFO - 2018-02-14 18:17:54 --> Helper loaded: common_helper
INFO - 2018-02-14 18:17:54 --> Database Driver Class Initialized
DEBUG - 2018-02-14 18:17:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 18:17:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 18:17:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-14 18:17:54 --> Pagination Class Initialized
INFO - 2018-02-14 18:17:54 --> Helper loaded: form_helper
INFO - 2018-02-14 18:17:54 --> Form Validation Class Initialized
INFO - 2018-02-14 18:17:54 --> Model Class Initialized
INFO - 2018-02-14 18:17:54 --> Controller Class Initialized
INFO - 2018-02-14 18:17:54 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-14 18:17:54 --> Model Class Initialized
INFO - 2018-02-14 18:17:54 --> Model Class Initialized
INFO - 2018-02-14 18:17:54 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-14 18:17:54 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-14 18:17:54 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-14 18:17:54 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-14 18:17:54 --> File loaded: /var/www/html/project/radio/application/views/subcategory/index.php
INFO - 2018-02-14 18:17:54 --> Final output sent to browser
DEBUG - 2018-02-14 18:17:54 --> Total execution time: 0.0080
INFO - 2018-02-14 18:18:28 --> Config Class Initialized
INFO - 2018-02-14 18:18:28 --> Hooks Class Initialized
DEBUG - 2018-02-14 18:18:28 --> UTF-8 Support Enabled
INFO - 2018-02-14 18:18:28 --> Utf8 Class Initialized
INFO - 2018-02-14 18:18:28 --> URI Class Initialized
INFO - 2018-02-14 18:18:28 --> Router Class Initialized
INFO - 2018-02-14 18:18:28 --> Output Class Initialized
INFO - 2018-02-14 18:18:28 --> Security Class Initialized
DEBUG - 2018-02-14 18:18:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 18:18:28 --> Input Class Initialized
INFO - 2018-02-14 18:18:28 --> Language Class Initialized
INFO - 2018-02-14 18:18:28 --> Loader Class Initialized
INFO - 2018-02-14 18:18:28 --> Helper loaded: url_helper
INFO - 2018-02-14 18:18:28 --> Helper loaded: file_helper
INFO - 2018-02-14 18:18:28 --> Helper loaded: email_helper
INFO - 2018-02-14 18:18:28 --> Helper loaded: common_helper
INFO - 2018-02-14 18:18:28 --> Database Driver Class Initialized
DEBUG - 2018-02-14 18:18:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 18:18:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 18:18:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-14 18:18:28 --> Pagination Class Initialized
INFO - 2018-02-14 18:18:28 --> Helper loaded: form_helper
INFO - 2018-02-14 18:18:28 --> Form Validation Class Initialized
INFO - 2018-02-14 18:18:28 --> Model Class Initialized
INFO - 2018-02-14 18:18:28 --> Controller Class Initialized
INFO - 2018-02-14 18:18:28 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-14 18:18:28 --> Model Class Initialized
INFO - 2018-02-14 18:18:29 --> Model Class Initialized
INFO - 2018-02-14 18:18:29 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-14 18:18:29 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-14 18:18:29 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-14 18:18:29 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-14 18:18:29 --> File loaded: /var/www/html/project/radio/application/views/subcategory/index.php
INFO - 2018-02-14 18:18:29 --> Final output sent to browser
DEBUG - 2018-02-14 18:18:29 --> Total execution time: 0.0059
INFO - 2018-02-14 18:18:31 --> Config Class Initialized
INFO - 2018-02-14 18:18:31 --> Hooks Class Initialized
DEBUG - 2018-02-14 18:18:31 --> UTF-8 Support Enabled
INFO - 2018-02-14 18:18:31 --> Utf8 Class Initialized
INFO - 2018-02-14 18:18:31 --> URI Class Initialized
INFO - 2018-02-14 18:18:31 --> Router Class Initialized
INFO - 2018-02-14 18:18:31 --> Output Class Initialized
INFO - 2018-02-14 18:18:31 --> Security Class Initialized
DEBUG - 2018-02-14 18:18:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 18:18:31 --> Input Class Initialized
INFO - 2018-02-14 18:18:31 --> Language Class Initialized
INFO - 2018-02-14 18:18:31 --> Loader Class Initialized
INFO - 2018-02-14 18:18:31 --> Helper loaded: url_helper
INFO - 2018-02-14 18:18:31 --> Helper loaded: file_helper
INFO - 2018-02-14 18:18:31 --> Helper loaded: email_helper
INFO - 2018-02-14 18:18:31 --> Helper loaded: common_helper
INFO - 2018-02-14 18:18:31 --> Database Driver Class Initialized
DEBUG - 2018-02-14 18:18:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 18:18:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 18:18:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-14 18:18:31 --> Pagination Class Initialized
INFO - 2018-02-14 18:18:31 --> Helper loaded: form_helper
INFO - 2018-02-14 18:18:31 --> Form Validation Class Initialized
INFO - 2018-02-14 18:18:31 --> Model Class Initialized
INFO - 2018-02-14 18:18:31 --> Controller Class Initialized
INFO - 2018-02-14 18:18:31 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-14 18:18:31 --> Model Class Initialized
INFO - 2018-02-14 18:18:31 --> Model Class Initialized
INFO - 2018-02-14 18:18:31 --> Config Class Initialized
INFO - 2018-02-14 18:18:31 --> Hooks Class Initialized
DEBUG - 2018-02-14 18:18:31 --> UTF-8 Support Enabled
INFO - 2018-02-14 18:18:31 --> Utf8 Class Initialized
INFO - 2018-02-14 18:18:31 --> URI Class Initialized
INFO - 2018-02-14 18:18:31 --> Router Class Initialized
INFO - 2018-02-14 18:18:31 --> Output Class Initialized
INFO - 2018-02-14 18:18:31 --> Security Class Initialized
DEBUG - 2018-02-14 18:18:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 18:18:31 --> Input Class Initialized
INFO - 2018-02-14 18:18:31 --> Language Class Initialized
INFO - 2018-02-14 18:18:31 --> Loader Class Initialized
INFO - 2018-02-14 18:18:31 --> Helper loaded: url_helper
INFO - 2018-02-14 18:18:31 --> Helper loaded: file_helper
INFO - 2018-02-14 18:18:31 --> Helper loaded: email_helper
INFO - 2018-02-14 18:18:31 --> Helper loaded: common_helper
INFO - 2018-02-14 18:18:31 --> Database Driver Class Initialized
DEBUG - 2018-02-14 18:18:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 18:18:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 18:18:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-14 18:18:31 --> Pagination Class Initialized
INFO - 2018-02-14 18:18:31 --> Helper loaded: form_helper
INFO - 2018-02-14 18:18:31 --> Form Validation Class Initialized
INFO - 2018-02-14 18:18:31 --> Model Class Initialized
INFO - 2018-02-14 18:18:31 --> Controller Class Initialized
INFO - 2018-02-14 18:18:31 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-14 18:18:31 --> Model Class Initialized
INFO - 2018-02-14 18:18:31 --> Model Class Initialized
INFO - 2018-02-14 18:18:31 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-14 18:18:31 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-14 18:18:31 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-14 18:18:31 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-14 18:18:31 --> File loaded: /var/www/html/project/radio/application/views/subcategory/index.php
INFO - 2018-02-14 18:18:31 --> Final output sent to browser
DEBUG - 2018-02-14 18:18:31 --> Total execution time: 0.0049
INFO - 2018-02-14 18:18:53 --> Config Class Initialized
INFO - 2018-02-14 18:18:53 --> Hooks Class Initialized
DEBUG - 2018-02-14 18:18:53 --> UTF-8 Support Enabled
INFO - 2018-02-14 18:18:53 --> Utf8 Class Initialized
INFO - 2018-02-14 18:18:53 --> URI Class Initialized
INFO - 2018-02-14 18:18:53 --> Router Class Initialized
INFO - 2018-02-14 18:18:53 --> Output Class Initialized
INFO - 2018-02-14 18:18:53 --> Security Class Initialized
DEBUG - 2018-02-14 18:18:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 18:18:53 --> Input Class Initialized
INFO - 2018-02-14 18:18:53 --> Language Class Initialized
INFO - 2018-02-14 18:18:53 --> Loader Class Initialized
INFO - 2018-02-14 18:18:53 --> Helper loaded: url_helper
INFO - 2018-02-14 18:18:53 --> Helper loaded: file_helper
INFO - 2018-02-14 18:18:53 --> Helper loaded: email_helper
INFO - 2018-02-14 18:18:53 --> Helper loaded: common_helper
INFO - 2018-02-14 18:18:53 --> Database Driver Class Initialized
DEBUG - 2018-02-14 18:18:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 18:18:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 18:18:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-14 18:18:53 --> Pagination Class Initialized
INFO - 2018-02-14 18:18:53 --> Helper loaded: form_helper
INFO - 2018-02-14 18:18:53 --> Form Validation Class Initialized
INFO - 2018-02-14 18:18:53 --> Model Class Initialized
INFO - 2018-02-14 18:18:53 --> Controller Class Initialized
INFO - 2018-02-14 18:18:53 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-14 18:18:53 --> Model Class Initialized
INFO - 2018-02-14 18:18:53 --> Model Class Initialized
INFO - 2018-02-14 18:18:53 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-14 18:18:53 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-14 18:18:53 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-14 18:18:53 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-14 18:18:53 --> File loaded: /var/www/html/project/radio/application/views/subcategory/index.php
INFO - 2018-02-14 18:18:53 --> Final output sent to browser
DEBUG - 2018-02-14 18:18:53 --> Total execution time: 0.0064
INFO - 2018-02-14 18:28:46 --> Config Class Initialized
INFO - 2018-02-14 18:28:46 --> Hooks Class Initialized
DEBUG - 2018-02-14 18:28:46 --> UTF-8 Support Enabled
INFO - 2018-02-14 18:28:46 --> Utf8 Class Initialized
INFO - 2018-02-14 18:28:46 --> URI Class Initialized
INFO - 2018-02-14 18:28:46 --> Router Class Initialized
INFO - 2018-02-14 18:28:46 --> Output Class Initialized
INFO - 2018-02-14 18:28:46 --> Security Class Initialized
DEBUG - 2018-02-14 18:28:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 18:28:46 --> Input Class Initialized
INFO - 2018-02-14 18:28:46 --> Language Class Initialized
INFO - 2018-02-14 18:28:46 --> Loader Class Initialized
INFO - 2018-02-14 18:28:46 --> Helper loaded: url_helper
INFO - 2018-02-14 18:28:46 --> Helper loaded: file_helper
INFO - 2018-02-14 18:28:46 --> Helper loaded: email_helper
INFO - 2018-02-14 18:28:46 --> Helper loaded: common_helper
INFO - 2018-02-14 18:28:46 --> Database Driver Class Initialized
DEBUG - 2018-02-14 18:28:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 18:28:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 18:28:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-14 18:28:46 --> Pagination Class Initialized
INFO - 2018-02-14 18:28:46 --> Helper loaded: form_helper
INFO - 2018-02-14 18:28:46 --> Form Validation Class Initialized
INFO - 2018-02-14 18:28:46 --> Model Class Initialized
INFO - 2018-02-14 18:28:46 --> Controller Class Initialized
INFO - 2018-02-14 18:28:46 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-14 18:28:46 --> Model Class Initialized
INFO - 2018-02-14 18:28:46 --> Model Class Initialized
INFO - 2018-02-14 18:28:46 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-14 18:28:46 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-14 18:28:46 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-14 18:28:46 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-14 18:28:46 --> File loaded: /var/www/html/project/radio/application/views/subcategory/index.php
INFO - 2018-02-14 18:28:46 --> Final output sent to browser
DEBUG - 2018-02-14 18:28:46 --> Total execution time: 0.0071
INFO - 2018-02-14 18:35:53 --> Config Class Initialized
INFO - 2018-02-14 18:35:53 --> Hooks Class Initialized
DEBUG - 2018-02-14 18:35:53 --> UTF-8 Support Enabled
INFO - 2018-02-14 18:35:53 --> Utf8 Class Initialized
INFO - 2018-02-14 18:35:53 --> URI Class Initialized
INFO - 2018-02-14 18:35:53 --> Router Class Initialized
INFO - 2018-02-14 18:35:53 --> Output Class Initialized
INFO - 2018-02-14 18:35:53 --> Security Class Initialized
DEBUG - 2018-02-14 18:35:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 18:35:53 --> Input Class Initialized
INFO - 2018-02-14 18:35:53 --> Language Class Initialized
INFO - 2018-02-14 18:35:53 --> Loader Class Initialized
INFO - 2018-02-14 18:35:53 --> Helper loaded: url_helper
INFO - 2018-02-14 18:35:53 --> Helper loaded: file_helper
INFO - 2018-02-14 18:35:53 --> Helper loaded: email_helper
INFO - 2018-02-14 18:35:53 --> Helper loaded: common_helper
INFO - 2018-02-14 18:35:53 --> Database Driver Class Initialized
DEBUG - 2018-02-14 18:35:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 18:35:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 18:35:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-14 18:35:53 --> Pagination Class Initialized
INFO - 2018-02-14 18:35:53 --> Helper loaded: form_helper
INFO - 2018-02-14 18:35:53 --> Form Validation Class Initialized
INFO - 2018-02-14 18:35:53 --> Model Class Initialized
INFO - 2018-02-14 18:35:53 --> Controller Class Initialized
INFO - 2018-02-14 18:35:53 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-14 18:35:53 --> Model Class Initialized
INFO - 2018-02-14 18:35:53 --> Config Class Initialized
INFO - 2018-02-14 18:35:53 --> Hooks Class Initialized
DEBUG - 2018-02-14 18:35:53 --> UTF-8 Support Enabled
INFO - 2018-02-14 18:35:53 --> Utf8 Class Initialized
INFO - 2018-02-14 18:35:53 --> URI Class Initialized
INFO - 2018-02-14 18:35:53 --> Router Class Initialized
INFO - 2018-02-14 18:35:53 --> Output Class Initialized
INFO - 2018-02-14 18:35:53 --> Security Class Initialized
DEBUG - 2018-02-14 18:35:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 18:35:53 --> Input Class Initialized
INFO - 2018-02-14 18:35:53 --> Language Class Initialized
INFO - 2018-02-14 18:35:53 --> Loader Class Initialized
INFO - 2018-02-14 18:35:53 --> Helper loaded: url_helper
INFO - 2018-02-14 18:35:53 --> Helper loaded: file_helper
INFO - 2018-02-14 18:35:53 --> Helper loaded: email_helper
INFO - 2018-02-14 18:35:53 --> Helper loaded: common_helper
INFO - 2018-02-14 18:35:53 --> Database Driver Class Initialized
DEBUG - 2018-02-14 18:35:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 18:35:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 18:35:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-14 18:35:53 --> Pagination Class Initialized
INFO - 2018-02-14 18:35:53 --> Helper loaded: form_helper
INFO - 2018-02-14 18:35:53 --> Form Validation Class Initialized
INFO - 2018-02-14 18:35:53 --> Model Class Initialized
INFO - 2018-02-14 18:35:53 --> Controller Class Initialized
INFO - 2018-02-14 18:35:53 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-14 18:35:53 --> Model Class Initialized
INFO - 2018-02-14 18:35:53 --> File loaded: /var/www/html/project/radio/application/views/index/index.php
INFO - 2018-02-14 18:35:53 --> Final output sent to browser
DEBUG - 2018-02-14 18:35:53 --> Total execution time: 0.0270
INFO - 2018-02-14 18:35:55 --> Config Class Initialized
INFO - 2018-02-14 18:35:55 --> Hooks Class Initialized
DEBUG - 2018-02-14 18:35:55 --> UTF-8 Support Enabled
INFO - 2018-02-14 18:35:55 --> Utf8 Class Initialized
INFO - 2018-02-14 18:35:55 --> URI Class Initialized
INFO - 2018-02-14 18:35:55 --> Router Class Initialized
INFO - 2018-02-14 18:35:55 --> Output Class Initialized
INFO - 2018-02-14 18:35:55 --> Security Class Initialized
DEBUG - 2018-02-14 18:35:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 18:35:55 --> Input Class Initialized
INFO - 2018-02-14 18:35:55 --> Language Class Initialized
INFO - 2018-02-14 18:35:55 --> Loader Class Initialized
INFO - 2018-02-14 18:35:55 --> Helper loaded: url_helper
INFO - 2018-02-14 18:35:55 --> Helper loaded: file_helper
INFO - 2018-02-14 18:35:55 --> Helper loaded: email_helper
INFO - 2018-02-14 18:35:55 --> Helper loaded: common_helper
INFO - 2018-02-14 18:35:55 --> Database Driver Class Initialized
DEBUG - 2018-02-14 18:35:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 18:35:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 18:35:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-14 18:35:55 --> Pagination Class Initialized
INFO - 2018-02-14 18:35:55 --> Helper loaded: form_helper
INFO - 2018-02-14 18:35:55 --> Form Validation Class Initialized
INFO - 2018-02-14 18:35:55 --> Model Class Initialized
INFO - 2018-02-14 18:35:55 --> Controller Class Initialized
INFO - 2018-02-14 18:35:55 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-14 18:35:55 --> Model Class Initialized
ERROR - 2018-02-14 18:35:55 --> Severity: Notice --> Undefined index: remember_me /var/www/html/project/radio/application/controllers/Index.php 73
INFO - 2018-02-14 18:35:55 --> Config Class Initialized
INFO - 2018-02-14 18:35:55 --> Hooks Class Initialized
DEBUG - 2018-02-14 18:35:55 --> UTF-8 Support Enabled
INFO - 2018-02-14 18:35:55 --> Utf8 Class Initialized
INFO - 2018-02-14 18:35:55 --> URI Class Initialized
INFO - 2018-02-14 18:35:55 --> Router Class Initialized
INFO - 2018-02-14 18:35:55 --> Output Class Initialized
INFO - 2018-02-14 18:35:55 --> Security Class Initialized
DEBUG - 2018-02-14 18:35:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 18:35:55 --> Input Class Initialized
INFO - 2018-02-14 18:35:55 --> Language Class Initialized
INFO - 2018-02-14 18:35:55 --> Loader Class Initialized
INFO - 2018-02-14 18:35:55 --> Helper loaded: url_helper
INFO - 2018-02-14 18:35:55 --> Helper loaded: file_helper
INFO - 2018-02-14 18:35:55 --> Helper loaded: email_helper
INFO - 2018-02-14 18:35:55 --> Helper loaded: common_helper
INFO - 2018-02-14 18:35:55 --> Database Driver Class Initialized
DEBUG - 2018-02-14 18:35:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 18:35:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 18:35:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-14 18:35:55 --> Pagination Class Initialized
INFO - 2018-02-14 18:35:55 --> Helper loaded: form_helper
INFO - 2018-02-14 18:35:55 --> Form Validation Class Initialized
INFO - 2018-02-14 18:35:55 --> Model Class Initialized
INFO - 2018-02-14 18:35:55 --> Controller Class Initialized
INFO - 2018-02-14 18:35:55 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-14 18:35:55 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-14 18:35:55 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-14 18:35:55 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-14 18:35:55 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-14 18:35:55 --> File loaded: /var/www/html/project/radio/application/views/dashboard/index.php
INFO - 2018-02-14 18:35:55 --> Final output sent to browser
DEBUG - 2018-02-14 18:35:55 --> Total execution time: 0.0052
INFO - 2018-02-14 18:35:58 --> Config Class Initialized
INFO - 2018-02-14 18:35:58 --> Hooks Class Initialized
DEBUG - 2018-02-14 18:35:58 --> UTF-8 Support Enabled
INFO - 2018-02-14 18:35:58 --> Utf8 Class Initialized
INFO - 2018-02-14 18:35:58 --> URI Class Initialized
INFO - 2018-02-14 18:35:58 --> Router Class Initialized
INFO - 2018-02-14 18:35:58 --> Output Class Initialized
INFO - 2018-02-14 18:35:58 --> Security Class Initialized
DEBUG - 2018-02-14 18:35:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 18:35:58 --> Input Class Initialized
INFO - 2018-02-14 18:35:58 --> Language Class Initialized
INFO - 2018-02-14 18:35:58 --> Loader Class Initialized
INFO - 2018-02-14 18:35:58 --> Helper loaded: url_helper
INFO - 2018-02-14 18:35:58 --> Helper loaded: file_helper
INFO - 2018-02-14 18:35:58 --> Helper loaded: email_helper
INFO - 2018-02-14 18:35:58 --> Helper loaded: common_helper
INFO - 2018-02-14 18:35:58 --> Database Driver Class Initialized
DEBUG - 2018-02-14 18:35:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 18:35:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 18:35:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-14 18:35:58 --> Pagination Class Initialized
INFO - 2018-02-14 18:35:58 --> Helper loaded: form_helper
INFO - 2018-02-14 18:35:58 --> Form Validation Class Initialized
INFO - 2018-02-14 18:35:58 --> Model Class Initialized
INFO - 2018-02-14 18:35:58 --> Controller Class Initialized
INFO - 2018-02-14 18:35:58 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-14 18:35:58 --> Model Class Initialized
INFO - 2018-02-14 18:35:58 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-14 18:35:58 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-14 18:35:58 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-14 18:35:58 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-14 18:35:58 --> File loaded: /var/www/html/project/radio/application/views/category/index.php
INFO - 2018-02-14 18:35:58 --> Final output sent to browser
DEBUG - 2018-02-14 18:35:58 --> Total execution time: 0.0068
INFO - 2018-02-14 18:42:00 --> Config Class Initialized
INFO - 2018-02-14 18:42:00 --> Hooks Class Initialized
DEBUG - 2018-02-14 18:42:00 --> UTF-8 Support Enabled
INFO - 2018-02-14 18:42:00 --> Utf8 Class Initialized
INFO - 2018-02-14 18:42:00 --> URI Class Initialized
INFO - 2018-02-14 18:42:00 --> Router Class Initialized
INFO - 2018-02-14 18:42:00 --> Output Class Initialized
INFO - 2018-02-14 18:42:00 --> Security Class Initialized
DEBUG - 2018-02-14 18:42:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 18:42:00 --> Input Class Initialized
INFO - 2018-02-14 18:42:00 --> Language Class Initialized
INFO - 2018-02-14 18:42:00 --> Loader Class Initialized
INFO - 2018-02-14 18:42:00 --> Helper loaded: url_helper
INFO - 2018-02-14 18:42:00 --> Helper loaded: file_helper
INFO - 2018-02-14 18:42:00 --> Helper loaded: email_helper
INFO - 2018-02-14 18:42:00 --> Helper loaded: common_helper
INFO - 2018-02-14 18:42:00 --> Database Driver Class Initialized
DEBUG - 2018-02-14 18:42:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 18:42:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 18:42:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-14 18:42:00 --> Pagination Class Initialized
INFO - 2018-02-14 18:42:00 --> Helper loaded: form_helper
INFO - 2018-02-14 18:42:00 --> Form Validation Class Initialized
INFO - 2018-02-14 18:42:00 --> Model Class Initialized
INFO - 2018-02-14 18:42:00 --> Controller Class Initialized
INFO - 2018-02-14 18:42:00 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-14 18:42:00 --> Model Class Initialized
INFO - 2018-02-14 18:42:00 --> Model Class Initialized
INFO - 2018-02-14 18:42:00 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-14 18:42:00 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-14 18:42:00 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-14 18:42:00 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-14 18:42:00 --> File loaded: /var/www/html/project/radio/application/views/subcategory/index.php
INFO - 2018-02-14 18:42:00 --> Final output sent to browser
DEBUG - 2018-02-14 18:42:00 --> Total execution time: 0.0071
INFO - 2018-02-14 18:42:01 --> Config Class Initialized
INFO - 2018-02-14 18:42:01 --> Hooks Class Initialized
DEBUG - 2018-02-14 18:42:01 --> UTF-8 Support Enabled
INFO - 2018-02-14 18:42:01 --> Utf8 Class Initialized
INFO - 2018-02-14 18:42:01 --> URI Class Initialized
INFO - 2018-02-14 18:42:01 --> Router Class Initialized
INFO - 2018-02-14 18:42:01 --> Output Class Initialized
INFO - 2018-02-14 18:42:01 --> Security Class Initialized
DEBUG - 2018-02-14 18:42:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 18:42:01 --> Input Class Initialized
INFO - 2018-02-14 18:42:01 --> Language Class Initialized
INFO - 2018-02-14 18:42:01 --> Loader Class Initialized
INFO - 2018-02-14 18:42:01 --> Helper loaded: url_helper
INFO - 2018-02-14 18:42:01 --> Helper loaded: file_helper
INFO - 2018-02-14 18:42:01 --> Helper loaded: email_helper
INFO - 2018-02-14 18:42:01 --> Helper loaded: common_helper
INFO - 2018-02-14 18:42:01 --> Database Driver Class Initialized
DEBUG - 2018-02-14 18:42:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 18:42:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 18:42:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-14 18:42:01 --> Pagination Class Initialized
INFO - 2018-02-14 18:42:01 --> Helper loaded: form_helper
INFO - 2018-02-14 18:42:01 --> Form Validation Class Initialized
INFO - 2018-02-14 18:42:01 --> Model Class Initialized
INFO - 2018-02-14 18:42:01 --> Controller Class Initialized
INFO - 2018-02-14 18:42:01 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-14 18:42:01 --> Model Class Initialized
INFO - 2018-02-14 18:42:01 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-14 18:42:01 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-14 18:42:01 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-14 18:42:01 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-14 18:42:01 --> File loaded: /var/www/html/project/radio/application/views/category/index.php
INFO - 2018-02-14 18:42:01 --> Final output sent to browser
DEBUG - 2018-02-14 18:42:01 --> Total execution time: 0.0061
INFO - 2018-02-14 18:42:04 --> Config Class Initialized
INFO - 2018-02-14 18:42:04 --> Hooks Class Initialized
DEBUG - 2018-02-14 18:42:04 --> UTF-8 Support Enabled
INFO - 2018-02-14 18:42:04 --> Utf8 Class Initialized
INFO - 2018-02-14 18:42:04 --> URI Class Initialized
INFO - 2018-02-14 18:42:04 --> Router Class Initialized
INFO - 2018-02-14 18:42:04 --> Output Class Initialized
INFO - 2018-02-14 18:42:04 --> Security Class Initialized
DEBUG - 2018-02-14 18:42:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 18:42:04 --> Input Class Initialized
INFO - 2018-02-14 18:42:04 --> Language Class Initialized
INFO - 2018-02-14 18:42:04 --> Loader Class Initialized
INFO - 2018-02-14 18:42:04 --> Helper loaded: url_helper
INFO - 2018-02-14 18:42:04 --> Helper loaded: file_helper
INFO - 2018-02-14 18:42:04 --> Helper loaded: email_helper
INFO - 2018-02-14 18:42:04 --> Helper loaded: common_helper
INFO - 2018-02-14 18:42:04 --> Database Driver Class Initialized
DEBUG - 2018-02-14 18:42:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 18:42:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 18:42:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-14 18:42:04 --> Pagination Class Initialized
INFO - 2018-02-14 18:42:04 --> Helper loaded: form_helper
INFO - 2018-02-14 18:42:04 --> Form Validation Class Initialized
INFO - 2018-02-14 18:42:04 --> Model Class Initialized
INFO - 2018-02-14 18:42:04 --> Controller Class Initialized
INFO - 2018-02-14 18:42:04 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-14 18:42:04 --> Model Class Initialized
INFO - 2018-02-14 18:42:04 --> Model Class Initialized
INFO - 2018-02-14 18:42:04 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-14 18:42:04 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-14 18:42:04 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-14 18:42:04 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-14 18:42:04 --> File loaded: /var/www/html/project/radio/application/views/subcategory/index.php
INFO - 2018-02-14 18:42:04 --> Final output sent to browser
DEBUG - 2018-02-14 18:42:04 --> Total execution time: 0.0048
INFO - 2018-02-14 18:42:56 --> Config Class Initialized
INFO - 2018-02-14 18:42:56 --> Hooks Class Initialized
DEBUG - 2018-02-14 18:42:56 --> UTF-8 Support Enabled
INFO - 2018-02-14 18:42:56 --> Utf8 Class Initialized
INFO - 2018-02-14 18:42:56 --> URI Class Initialized
INFO - 2018-02-14 18:42:56 --> Router Class Initialized
INFO - 2018-02-14 18:42:56 --> Output Class Initialized
INFO - 2018-02-14 18:42:56 --> Security Class Initialized
DEBUG - 2018-02-14 18:42:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 18:42:56 --> Input Class Initialized
INFO - 2018-02-14 18:42:56 --> Language Class Initialized
INFO - 2018-02-14 18:42:56 --> Loader Class Initialized
INFO - 2018-02-14 18:42:56 --> Helper loaded: url_helper
INFO - 2018-02-14 18:42:56 --> Helper loaded: file_helper
INFO - 2018-02-14 18:42:56 --> Helper loaded: email_helper
INFO - 2018-02-14 18:42:56 --> Helper loaded: common_helper
INFO - 2018-02-14 18:42:56 --> Database Driver Class Initialized
DEBUG - 2018-02-14 18:42:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 18:42:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 18:42:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-14 18:42:56 --> Pagination Class Initialized
INFO - 2018-02-14 18:42:56 --> Helper loaded: form_helper
INFO - 2018-02-14 18:42:56 --> Form Validation Class Initialized
INFO - 2018-02-14 18:42:56 --> Model Class Initialized
INFO - 2018-02-14 18:42:56 --> Controller Class Initialized
INFO - 2018-02-14 18:42:56 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-14 18:42:56 --> Model Class Initialized
INFO - 2018-02-14 18:42:56 --> Model Class Initialized
INFO - 2018-02-14 18:42:56 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-14 18:42:56 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-14 18:42:56 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-14 18:42:56 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-14 18:42:56 --> File loaded: /var/www/html/project/radio/application/views/subcategory/index.php
INFO - 2018-02-14 18:42:56 --> Final output sent to browser
DEBUG - 2018-02-14 18:42:56 --> Total execution time: 0.0072
INFO - 2018-02-14 18:42:58 --> Config Class Initialized
INFO - 2018-02-14 18:42:58 --> Hooks Class Initialized
DEBUG - 2018-02-14 18:42:58 --> UTF-8 Support Enabled
INFO - 2018-02-14 18:42:58 --> Utf8 Class Initialized
INFO - 2018-02-14 18:42:58 --> URI Class Initialized
INFO - 2018-02-14 18:42:58 --> Router Class Initialized
INFO - 2018-02-14 18:42:58 --> Output Class Initialized
INFO - 2018-02-14 18:42:58 --> Security Class Initialized
DEBUG - 2018-02-14 18:42:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 18:42:58 --> Input Class Initialized
INFO - 2018-02-14 18:42:58 --> Language Class Initialized
INFO - 2018-02-14 18:42:58 --> Loader Class Initialized
INFO - 2018-02-14 18:42:58 --> Helper loaded: url_helper
INFO - 2018-02-14 18:42:58 --> Helper loaded: file_helper
INFO - 2018-02-14 18:42:58 --> Helper loaded: email_helper
INFO - 2018-02-14 18:42:58 --> Helper loaded: common_helper
INFO - 2018-02-14 18:42:58 --> Database Driver Class Initialized
DEBUG - 2018-02-14 18:42:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 18:42:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 18:42:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-14 18:42:59 --> Pagination Class Initialized
INFO - 2018-02-14 18:42:59 --> Helper loaded: form_helper
INFO - 2018-02-14 18:42:59 --> Form Validation Class Initialized
INFO - 2018-02-14 18:42:59 --> Model Class Initialized
INFO - 2018-02-14 18:42:59 --> Controller Class Initialized
INFO - 2018-02-14 18:42:59 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-14 18:42:59 --> Model Class Initialized
INFO - 2018-02-14 18:42:59 --> Model Class Initialized
INFO - 2018-02-14 18:42:59 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-14 18:42:59 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-14 18:42:59 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-14 18:42:59 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-14 18:42:59 --> File loaded: /var/www/html/project/radio/application/views/subcategory/add_edit.php
INFO - 2018-02-14 18:42:59 --> Final output sent to browser
DEBUG - 2018-02-14 18:42:59 --> Total execution time: 0.0055
INFO - 2018-02-14 18:42:59 --> Config Class Initialized
INFO - 2018-02-14 18:42:59 --> Hooks Class Initialized
DEBUG - 2018-02-14 18:42:59 --> UTF-8 Support Enabled
INFO - 2018-02-14 18:42:59 --> Utf8 Class Initialized
INFO - 2018-02-14 18:42:59 --> URI Class Initialized
INFO - 2018-02-14 18:42:59 --> Router Class Initialized
INFO - 2018-02-14 18:42:59 --> Output Class Initialized
INFO - 2018-02-14 18:42:59 --> Security Class Initialized
DEBUG - 2018-02-14 18:42:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 18:42:59 --> Input Class Initialized
INFO - 2018-02-14 18:42:59 --> Language Class Initialized
INFO - 2018-02-14 18:42:59 --> Loader Class Initialized
INFO - 2018-02-14 18:42:59 --> Helper loaded: url_helper
INFO - 2018-02-14 18:42:59 --> Helper loaded: file_helper
INFO - 2018-02-14 18:42:59 --> Helper loaded: email_helper
INFO - 2018-02-14 18:42:59 --> Helper loaded: common_helper
INFO - 2018-02-14 18:42:59 --> Database Driver Class Initialized
DEBUG - 2018-02-14 18:42:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 18:42:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 18:42:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-14 18:42:59 --> Pagination Class Initialized
INFO - 2018-02-14 18:42:59 --> Helper loaded: form_helper
INFO - 2018-02-14 18:42:59 --> Form Validation Class Initialized
INFO - 2018-02-14 18:42:59 --> Model Class Initialized
INFO - 2018-02-14 18:42:59 --> Controller Class Initialized
INFO - 2018-02-14 18:42:59 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-14 18:42:59 --> Model Class Initialized
INFO - 2018-02-14 18:42:59 --> Model Class Initialized
INFO - 2018-02-14 18:42:59 --> Config Class Initialized
INFO - 2018-02-14 18:42:59 --> Hooks Class Initialized
DEBUG - 2018-02-14 18:42:59 --> UTF-8 Support Enabled
INFO - 2018-02-14 18:42:59 --> Utf8 Class Initialized
INFO - 2018-02-14 18:42:59 --> URI Class Initialized
INFO - 2018-02-14 18:42:59 --> Router Class Initialized
INFO - 2018-02-14 18:42:59 --> Output Class Initialized
INFO - 2018-02-14 18:42:59 --> Security Class Initialized
DEBUG - 2018-02-14 18:42:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 18:42:59 --> Input Class Initialized
INFO - 2018-02-14 18:42:59 --> Language Class Initialized
INFO - 2018-02-14 18:42:59 --> Loader Class Initialized
INFO - 2018-02-14 18:42:59 --> Helper loaded: url_helper
INFO - 2018-02-14 18:42:59 --> Helper loaded: file_helper
INFO - 2018-02-14 18:42:59 --> Helper loaded: email_helper
INFO - 2018-02-14 18:42:59 --> Helper loaded: common_helper
INFO - 2018-02-14 18:42:59 --> Database Driver Class Initialized
DEBUG - 2018-02-14 18:42:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 18:42:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 18:42:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-14 18:42:59 --> Pagination Class Initialized
INFO - 2018-02-14 18:42:59 --> Helper loaded: form_helper
INFO - 2018-02-14 18:42:59 --> Form Validation Class Initialized
INFO - 2018-02-14 18:42:59 --> Model Class Initialized
INFO - 2018-02-14 18:42:59 --> Controller Class Initialized
INFO - 2018-02-14 18:42:59 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-14 18:42:59 --> Model Class Initialized
INFO - 2018-02-14 18:42:59 --> Model Class Initialized
INFO - 2018-02-14 18:42:59 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-14 18:42:59 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-14 18:42:59 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-14 18:42:59 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-14 18:42:59 --> File loaded: /var/www/html/project/radio/application/views/subcategory/index.php
INFO - 2018-02-14 18:42:59 --> Final output sent to browser
DEBUG - 2018-02-14 18:42:59 --> Total execution time: 0.0065
INFO - 2018-02-14 18:43:01 --> Config Class Initialized
INFO - 2018-02-14 18:43:01 --> Hooks Class Initialized
DEBUG - 2018-02-14 18:43:01 --> UTF-8 Support Enabled
INFO - 2018-02-14 18:43:01 --> Utf8 Class Initialized
INFO - 2018-02-14 18:43:01 --> URI Class Initialized
INFO - 2018-02-14 18:43:01 --> Router Class Initialized
INFO - 2018-02-14 18:43:01 --> Output Class Initialized
INFO - 2018-02-14 18:43:01 --> Security Class Initialized
DEBUG - 2018-02-14 18:43:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 18:43:01 --> Input Class Initialized
INFO - 2018-02-14 18:43:01 --> Language Class Initialized
INFO - 2018-02-14 18:43:01 --> Loader Class Initialized
INFO - 2018-02-14 18:43:01 --> Helper loaded: url_helper
INFO - 2018-02-14 18:43:01 --> Helper loaded: file_helper
INFO - 2018-02-14 18:43:01 --> Helper loaded: email_helper
INFO - 2018-02-14 18:43:01 --> Helper loaded: common_helper
INFO - 2018-02-14 18:43:01 --> Database Driver Class Initialized
DEBUG - 2018-02-14 18:43:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 18:43:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 18:43:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-14 18:43:01 --> Pagination Class Initialized
INFO - 2018-02-14 18:43:01 --> Helper loaded: form_helper
INFO - 2018-02-14 18:43:01 --> Form Validation Class Initialized
INFO - 2018-02-14 18:43:01 --> Model Class Initialized
INFO - 2018-02-14 18:43:01 --> Controller Class Initialized
INFO - 2018-02-14 18:43:01 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-14 18:43:01 --> Model Class Initialized
INFO - 2018-02-14 18:43:01 --> Model Class Initialized
INFO - 2018-02-14 18:43:01 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-14 18:43:01 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-14 18:43:01 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-14 18:43:01 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-14 18:43:01 --> File loaded: /var/www/html/project/radio/application/views/subcategory/add_edit.php
INFO - 2018-02-14 18:43:01 --> Final output sent to browser
DEBUG - 2018-02-14 18:43:01 --> Total execution time: 0.0053
INFO - 2018-02-14 18:43:02 --> Config Class Initialized
INFO - 2018-02-14 18:43:02 --> Hooks Class Initialized
DEBUG - 2018-02-14 18:43:02 --> UTF-8 Support Enabled
INFO - 2018-02-14 18:43:02 --> Utf8 Class Initialized
INFO - 2018-02-14 18:43:02 --> URI Class Initialized
INFO - 2018-02-14 18:43:02 --> Router Class Initialized
INFO - 2018-02-14 18:43:02 --> Output Class Initialized
INFO - 2018-02-14 18:43:02 --> Security Class Initialized
DEBUG - 2018-02-14 18:43:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 18:43:02 --> Input Class Initialized
INFO - 2018-02-14 18:43:02 --> Language Class Initialized
INFO - 2018-02-14 18:43:02 --> Loader Class Initialized
INFO - 2018-02-14 18:43:02 --> Helper loaded: url_helper
INFO - 2018-02-14 18:43:02 --> Helper loaded: file_helper
INFO - 2018-02-14 18:43:02 --> Helper loaded: email_helper
INFO - 2018-02-14 18:43:02 --> Helper loaded: common_helper
INFO - 2018-02-14 18:43:02 --> Database Driver Class Initialized
DEBUG - 2018-02-14 18:43:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 18:43:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 18:43:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-14 18:43:02 --> Pagination Class Initialized
INFO - 2018-02-14 18:43:02 --> Helper loaded: form_helper
INFO - 2018-02-14 18:43:02 --> Form Validation Class Initialized
INFO - 2018-02-14 18:43:02 --> Model Class Initialized
INFO - 2018-02-14 18:43:02 --> Controller Class Initialized
INFO - 2018-02-14 18:43:02 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-14 18:43:02 --> Model Class Initialized
INFO - 2018-02-14 18:43:02 --> Model Class Initialized
INFO - 2018-02-14 18:43:02 --> Config Class Initialized
INFO - 2018-02-14 18:43:02 --> Hooks Class Initialized
DEBUG - 2018-02-14 18:43:02 --> UTF-8 Support Enabled
INFO - 2018-02-14 18:43:02 --> Utf8 Class Initialized
INFO - 2018-02-14 18:43:02 --> URI Class Initialized
INFO - 2018-02-14 18:43:02 --> Router Class Initialized
INFO - 2018-02-14 18:43:02 --> Output Class Initialized
INFO - 2018-02-14 18:43:02 --> Security Class Initialized
DEBUG - 2018-02-14 18:43:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 18:43:02 --> Input Class Initialized
INFO - 2018-02-14 18:43:02 --> Language Class Initialized
INFO - 2018-02-14 18:43:02 --> Loader Class Initialized
INFO - 2018-02-14 18:43:02 --> Helper loaded: url_helper
INFO - 2018-02-14 18:43:02 --> Helper loaded: file_helper
INFO - 2018-02-14 18:43:02 --> Helper loaded: email_helper
INFO - 2018-02-14 18:43:02 --> Helper loaded: common_helper
INFO - 2018-02-14 18:43:02 --> Database Driver Class Initialized
DEBUG - 2018-02-14 18:43:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 18:43:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 18:43:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-14 18:43:02 --> Pagination Class Initialized
INFO - 2018-02-14 18:43:02 --> Helper loaded: form_helper
INFO - 2018-02-14 18:43:02 --> Form Validation Class Initialized
INFO - 2018-02-14 18:43:02 --> Model Class Initialized
INFO - 2018-02-14 18:43:02 --> Controller Class Initialized
INFO - 2018-02-14 18:43:02 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-14 18:43:02 --> Model Class Initialized
INFO - 2018-02-14 18:43:02 --> Model Class Initialized
INFO - 2018-02-14 18:43:02 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-14 18:43:02 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-14 18:43:02 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-14 18:43:02 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-14 18:43:02 --> File loaded: /var/www/html/project/radio/application/views/subcategory/index.php
INFO - 2018-02-14 18:43:02 --> Final output sent to browser
DEBUG - 2018-02-14 18:43:02 --> Total execution time: 0.0067
INFO - 2018-02-14 18:43:07 --> Config Class Initialized
INFO - 2018-02-14 18:43:07 --> Hooks Class Initialized
DEBUG - 2018-02-14 18:43:07 --> UTF-8 Support Enabled
INFO - 2018-02-14 18:43:07 --> Utf8 Class Initialized
INFO - 2018-02-14 18:43:07 --> URI Class Initialized
INFO - 2018-02-14 18:43:07 --> Router Class Initialized
INFO - 2018-02-14 18:43:07 --> Output Class Initialized
INFO - 2018-02-14 18:43:07 --> Security Class Initialized
DEBUG - 2018-02-14 18:43:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 18:43:07 --> Input Class Initialized
INFO - 2018-02-14 18:43:07 --> Language Class Initialized
INFO - 2018-02-14 18:43:07 --> Loader Class Initialized
INFO - 2018-02-14 18:43:07 --> Helper loaded: url_helper
INFO - 2018-02-14 18:43:07 --> Helper loaded: file_helper
INFO - 2018-02-14 18:43:07 --> Helper loaded: email_helper
INFO - 2018-02-14 18:43:07 --> Helper loaded: common_helper
INFO - 2018-02-14 18:43:07 --> Database Driver Class Initialized
DEBUG - 2018-02-14 18:43:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 18:43:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 18:43:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-14 18:43:07 --> Pagination Class Initialized
INFO - 2018-02-14 18:43:07 --> Helper loaded: form_helper
INFO - 2018-02-14 18:43:07 --> Form Validation Class Initialized
INFO - 2018-02-14 18:43:07 --> Model Class Initialized
INFO - 2018-02-14 18:43:07 --> Controller Class Initialized
INFO - 2018-02-14 18:43:07 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-14 18:43:07 --> Model Class Initialized
INFO - 2018-02-14 18:43:07 --> Model Class Initialized
INFO - 2018-02-14 18:43:07 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-14 18:43:07 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-14 18:43:07 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-14 18:43:07 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-14 18:43:07 --> File loaded: /var/www/html/project/radio/application/views/subcategory/add_edit.php
INFO - 2018-02-14 18:43:07 --> Final output sent to browser
DEBUG - 2018-02-14 18:43:07 --> Total execution time: 0.0062
INFO - 2018-02-14 18:43:09 --> Config Class Initialized
INFO - 2018-02-14 18:43:09 --> Hooks Class Initialized
DEBUG - 2018-02-14 18:43:09 --> UTF-8 Support Enabled
INFO - 2018-02-14 18:43:09 --> Utf8 Class Initialized
INFO - 2018-02-14 18:43:09 --> URI Class Initialized
INFO - 2018-02-14 18:43:09 --> Router Class Initialized
INFO - 2018-02-14 18:43:09 --> Output Class Initialized
INFO - 2018-02-14 18:43:09 --> Security Class Initialized
DEBUG - 2018-02-14 18:43:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 18:43:09 --> Input Class Initialized
INFO - 2018-02-14 18:43:09 --> Language Class Initialized
INFO - 2018-02-14 18:43:09 --> Loader Class Initialized
INFO - 2018-02-14 18:43:09 --> Helper loaded: url_helper
INFO - 2018-02-14 18:43:09 --> Helper loaded: file_helper
INFO - 2018-02-14 18:43:09 --> Helper loaded: email_helper
INFO - 2018-02-14 18:43:09 --> Helper loaded: common_helper
INFO - 2018-02-14 18:43:09 --> Database Driver Class Initialized
DEBUG - 2018-02-14 18:43:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 18:43:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 18:43:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-14 18:43:09 --> Pagination Class Initialized
INFO - 2018-02-14 18:43:09 --> Helper loaded: form_helper
INFO - 2018-02-14 18:43:09 --> Form Validation Class Initialized
INFO - 2018-02-14 18:43:09 --> Model Class Initialized
INFO - 2018-02-14 18:43:09 --> Controller Class Initialized
INFO - 2018-02-14 18:43:09 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-14 18:43:09 --> Model Class Initialized
INFO - 2018-02-14 18:43:09 --> Model Class Initialized
INFO - 2018-02-14 18:43:09 --> Config Class Initialized
INFO - 2018-02-14 18:43:09 --> Hooks Class Initialized
DEBUG - 2018-02-14 18:43:09 --> UTF-8 Support Enabled
INFO - 2018-02-14 18:43:09 --> Utf8 Class Initialized
INFO - 2018-02-14 18:43:09 --> URI Class Initialized
INFO - 2018-02-14 18:43:09 --> Router Class Initialized
INFO - 2018-02-14 18:43:09 --> Output Class Initialized
INFO - 2018-02-14 18:43:09 --> Security Class Initialized
DEBUG - 2018-02-14 18:43:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 18:43:09 --> Input Class Initialized
INFO - 2018-02-14 18:43:09 --> Language Class Initialized
INFO - 2018-02-14 18:43:09 --> Loader Class Initialized
INFO - 2018-02-14 18:43:09 --> Helper loaded: url_helper
INFO - 2018-02-14 18:43:09 --> Helper loaded: file_helper
INFO - 2018-02-14 18:43:09 --> Helper loaded: email_helper
INFO - 2018-02-14 18:43:09 --> Helper loaded: common_helper
INFO - 2018-02-14 18:43:09 --> Database Driver Class Initialized
DEBUG - 2018-02-14 18:43:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 18:43:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 18:43:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-14 18:43:09 --> Pagination Class Initialized
INFO - 2018-02-14 18:43:09 --> Helper loaded: form_helper
INFO - 2018-02-14 18:43:09 --> Form Validation Class Initialized
INFO - 2018-02-14 18:43:09 --> Model Class Initialized
INFO - 2018-02-14 18:43:09 --> Controller Class Initialized
INFO - 2018-02-14 18:43:09 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-14 18:43:09 --> Model Class Initialized
INFO - 2018-02-14 18:43:09 --> Model Class Initialized
INFO - 2018-02-14 18:43:09 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-14 18:43:09 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-14 18:43:09 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-14 18:43:09 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-14 18:43:09 --> File loaded: /var/www/html/project/radio/application/views/subcategory/index.php
INFO - 2018-02-14 18:43:09 --> Final output sent to browser
DEBUG - 2018-02-14 18:43:09 --> Total execution time: 0.0060
INFO - 2018-02-14 18:43:12 --> Config Class Initialized
INFO - 2018-02-14 18:43:12 --> Hooks Class Initialized
DEBUG - 2018-02-14 18:43:12 --> UTF-8 Support Enabled
INFO - 2018-02-14 18:43:12 --> Utf8 Class Initialized
INFO - 2018-02-14 18:43:12 --> URI Class Initialized
INFO - 2018-02-14 18:43:12 --> Router Class Initialized
INFO - 2018-02-14 18:43:12 --> Output Class Initialized
INFO - 2018-02-14 18:43:12 --> Security Class Initialized
DEBUG - 2018-02-14 18:43:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 18:43:12 --> Input Class Initialized
INFO - 2018-02-14 18:43:12 --> Language Class Initialized
INFO - 2018-02-14 18:43:12 --> Loader Class Initialized
INFO - 2018-02-14 18:43:12 --> Helper loaded: url_helper
INFO - 2018-02-14 18:43:12 --> Helper loaded: file_helper
INFO - 2018-02-14 18:43:12 --> Helper loaded: email_helper
INFO - 2018-02-14 18:43:12 --> Helper loaded: common_helper
INFO - 2018-02-14 18:43:12 --> Database Driver Class Initialized
DEBUG - 2018-02-14 18:43:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 18:43:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 18:43:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-14 18:43:12 --> Pagination Class Initialized
INFO - 2018-02-14 18:43:12 --> Helper loaded: form_helper
INFO - 2018-02-14 18:43:12 --> Form Validation Class Initialized
INFO - 2018-02-14 18:43:12 --> Model Class Initialized
INFO - 2018-02-14 18:43:12 --> Controller Class Initialized
INFO - 2018-02-14 18:43:12 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-14 18:43:12 --> Model Class Initialized
INFO - 2018-02-14 18:43:12 --> Model Class Initialized
INFO - 2018-02-14 18:43:12 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-14 18:43:12 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-14 18:43:12 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-14 18:43:12 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-14 18:43:12 --> File loaded: /var/www/html/project/radio/application/views/subcategory/add_edit.php
INFO - 2018-02-14 18:43:12 --> Final output sent to browser
DEBUG - 2018-02-14 18:43:12 --> Total execution time: 0.0055
INFO - 2018-02-14 18:44:41 --> Config Class Initialized
INFO - 2018-02-14 18:44:41 --> Hooks Class Initialized
DEBUG - 2018-02-14 18:44:41 --> UTF-8 Support Enabled
INFO - 2018-02-14 18:44:41 --> Utf8 Class Initialized
INFO - 2018-02-14 18:44:41 --> URI Class Initialized
INFO - 2018-02-14 18:44:41 --> Router Class Initialized
INFO - 2018-02-14 18:44:41 --> Output Class Initialized
INFO - 2018-02-14 18:44:41 --> Security Class Initialized
DEBUG - 2018-02-14 18:44:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 18:44:41 --> Input Class Initialized
INFO - 2018-02-14 18:44:41 --> Language Class Initialized
INFO - 2018-02-14 18:44:41 --> Loader Class Initialized
INFO - 2018-02-14 18:44:41 --> Helper loaded: url_helper
INFO - 2018-02-14 18:44:41 --> Helper loaded: file_helper
INFO - 2018-02-14 18:44:41 --> Helper loaded: email_helper
INFO - 2018-02-14 18:44:41 --> Helper loaded: common_helper
INFO - 2018-02-14 18:44:41 --> Database Driver Class Initialized
DEBUG - 2018-02-14 18:44:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 18:44:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 18:44:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-14 18:44:41 --> Pagination Class Initialized
INFO - 2018-02-14 18:44:41 --> Helper loaded: form_helper
INFO - 2018-02-14 18:44:41 --> Form Validation Class Initialized
INFO - 2018-02-14 18:44:41 --> Model Class Initialized
INFO - 2018-02-14 18:44:41 --> Controller Class Initialized
INFO - 2018-02-14 18:44:41 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-14 18:44:41 --> Model Class Initialized
INFO - 2018-02-14 18:44:41 --> Model Class Initialized
INFO - 2018-02-14 18:44:41 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-14 18:44:41 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-14 18:44:41 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-14 18:44:41 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-14 18:44:41 --> File loaded: /var/www/html/project/radio/application/views/subcategory/index.php
INFO - 2018-02-14 18:44:41 --> Final output sent to browser
DEBUG - 2018-02-14 18:44:41 --> Total execution time: 0.0110
INFO - 2018-02-14 18:44:43 --> Config Class Initialized
INFO - 2018-02-14 18:44:43 --> Hooks Class Initialized
DEBUG - 2018-02-14 18:44:43 --> UTF-8 Support Enabled
INFO - 2018-02-14 18:44:43 --> Utf8 Class Initialized
INFO - 2018-02-14 18:44:43 --> URI Class Initialized
INFO - 2018-02-14 18:44:43 --> Router Class Initialized
INFO - 2018-02-14 18:44:43 --> Output Class Initialized
INFO - 2018-02-14 18:44:43 --> Security Class Initialized
DEBUG - 2018-02-14 18:44:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 18:44:43 --> Input Class Initialized
INFO - 2018-02-14 18:44:43 --> Language Class Initialized
INFO - 2018-02-14 18:44:43 --> Loader Class Initialized
INFO - 2018-02-14 18:44:43 --> Helper loaded: url_helper
INFO - 2018-02-14 18:44:43 --> Helper loaded: file_helper
INFO - 2018-02-14 18:44:43 --> Helper loaded: email_helper
INFO - 2018-02-14 18:44:43 --> Helper loaded: common_helper
INFO - 2018-02-14 18:44:43 --> Database Driver Class Initialized
DEBUG - 2018-02-14 18:44:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 18:44:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 18:44:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-14 18:44:43 --> Pagination Class Initialized
INFO - 2018-02-14 18:44:43 --> Helper loaded: form_helper
INFO - 2018-02-14 18:44:43 --> Form Validation Class Initialized
INFO - 2018-02-14 18:44:43 --> Model Class Initialized
INFO - 2018-02-14 18:44:43 --> Controller Class Initialized
INFO - 2018-02-14 18:44:43 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-14 18:44:43 --> Model Class Initialized
INFO - 2018-02-14 18:44:43 --> Model Class Initialized
INFO - 2018-02-14 18:44:43 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-14 18:44:43 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-14 18:44:43 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-14 18:44:43 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-14 18:44:43 --> File loaded: /var/www/html/project/radio/application/views/subcategory/add_edit.php
INFO - 2018-02-14 18:44:43 --> Final output sent to browser
DEBUG - 2018-02-14 18:44:43 --> Total execution time: 0.0069
INFO - 2018-02-14 18:50:33 --> Config Class Initialized
INFO - 2018-02-14 18:50:33 --> Hooks Class Initialized
DEBUG - 2018-02-14 18:50:33 --> UTF-8 Support Enabled
INFO - 2018-02-14 18:50:33 --> Utf8 Class Initialized
INFO - 2018-02-14 18:50:33 --> URI Class Initialized
INFO - 2018-02-14 18:50:33 --> Router Class Initialized
INFO - 2018-02-14 18:50:33 --> Output Class Initialized
INFO - 2018-02-14 18:50:33 --> Security Class Initialized
DEBUG - 2018-02-14 18:50:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 18:50:33 --> Input Class Initialized
INFO - 2018-02-14 18:50:33 --> Language Class Initialized
INFO - 2018-02-14 18:50:33 --> Loader Class Initialized
INFO - 2018-02-14 18:50:33 --> Helper loaded: url_helper
INFO - 2018-02-14 18:50:33 --> Helper loaded: file_helper
INFO - 2018-02-14 18:50:33 --> Helper loaded: email_helper
INFO - 2018-02-14 18:50:33 --> Helper loaded: common_helper
INFO - 2018-02-14 18:50:33 --> Database Driver Class Initialized
DEBUG - 2018-02-14 18:50:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 18:50:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 18:50:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-14 18:50:33 --> Pagination Class Initialized
INFO - 2018-02-14 18:50:33 --> Helper loaded: form_helper
INFO - 2018-02-14 18:50:33 --> Form Validation Class Initialized
INFO - 2018-02-14 18:50:33 --> Model Class Initialized
INFO - 2018-02-14 18:50:33 --> Controller Class Initialized
INFO - 2018-02-14 18:50:33 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-14 18:50:33 --> Model Class Initialized
INFO - 2018-02-14 18:50:33 --> Model Class Initialized
INFO - 2018-02-14 18:50:33 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-14 18:50:33 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-14 18:50:33 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-14 18:50:33 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-14 18:50:33 --> File loaded: /var/www/html/project/radio/application/views/subcategory/index.php
INFO - 2018-02-14 18:50:33 --> Final output sent to browser
DEBUG - 2018-02-14 18:50:33 --> Total execution time: 0.0071
INFO - 2018-02-14 18:50:34 --> Config Class Initialized
INFO - 2018-02-14 18:50:34 --> Hooks Class Initialized
DEBUG - 2018-02-14 18:50:34 --> UTF-8 Support Enabled
INFO - 2018-02-14 18:50:34 --> Utf8 Class Initialized
INFO - 2018-02-14 18:50:34 --> URI Class Initialized
INFO - 2018-02-14 18:50:34 --> Router Class Initialized
INFO - 2018-02-14 18:50:34 --> Output Class Initialized
INFO - 2018-02-14 18:50:34 --> Security Class Initialized
DEBUG - 2018-02-14 18:50:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 18:50:34 --> Input Class Initialized
INFO - 2018-02-14 18:50:34 --> Language Class Initialized
INFO - 2018-02-14 18:50:34 --> Loader Class Initialized
INFO - 2018-02-14 18:50:34 --> Helper loaded: url_helper
INFO - 2018-02-14 18:50:34 --> Helper loaded: file_helper
INFO - 2018-02-14 18:50:34 --> Helper loaded: email_helper
INFO - 2018-02-14 18:50:34 --> Helper loaded: common_helper
INFO - 2018-02-14 18:50:34 --> Database Driver Class Initialized
DEBUG - 2018-02-14 18:50:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 18:50:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 18:50:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-14 18:50:34 --> Pagination Class Initialized
INFO - 2018-02-14 18:50:34 --> Helper loaded: form_helper
INFO - 2018-02-14 18:50:34 --> Form Validation Class Initialized
INFO - 2018-02-14 18:50:34 --> Model Class Initialized
INFO - 2018-02-14 18:50:34 --> Controller Class Initialized
INFO - 2018-02-14 18:50:34 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-14 18:50:34 --> Model Class Initialized
INFO - 2018-02-14 18:50:34 --> Model Class Initialized
INFO - 2018-02-14 18:50:51 --> Config Class Initialized
INFO - 2018-02-14 18:50:51 --> Hooks Class Initialized
DEBUG - 2018-02-14 18:50:51 --> UTF-8 Support Enabled
INFO - 2018-02-14 18:50:51 --> Utf8 Class Initialized
INFO - 2018-02-14 18:50:51 --> URI Class Initialized
INFO - 2018-02-14 18:50:51 --> Router Class Initialized
INFO - 2018-02-14 18:50:51 --> Output Class Initialized
INFO - 2018-02-14 18:50:51 --> Security Class Initialized
DEBUG - 2018-02-14 18:50:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 18:50:51 --> Input Class Initialized
INFO - 2018-02-14 18:50:51 --> Language Class Initialized
INFO - 2018-02-14 18:50:51 --> Loader Class Initialized
INFO - 2018-02-14 18:50:51 --> Helper loaded: url_helper
INFO - 2018-02-14 18:50:51 --> Helper loaded: file_helper
INFO - 2018-02-14 18:50:51 --> Helper loaded: email_helper
INFO - 2018-02-14 18:50:51 --> Helper loaded: common_helper
INFO - 2018-02-14 18:50:51 --> Database Driver Class Initialized
DEBUG - 2018-02-14 18:50:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 18:50:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 18:50:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-14 18:50:51 --> Pagination Class Initialized
INFO - 2018-02-14 18:50:51 --> Helper loaded: form_helper
INFO - 2018-02-14 18:50:51 --> Form Validation Class Initialized
INFO - 2018-02-14 18:50:51 --> Model Class Initialized
INFO - 2018-02-14 18:50:51 --> Controller Class Initialized
INFO - 2018-02-14 18:50:51 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-14 18:50:51 --> Model Class Initialized
INFO - 2018-02-14 18:50:51 --> Model Class Initialized
INFO - 2018-02-14 18:51:24 --> Config Class Initialized
INFO - 2018-02-14 18:51:24 --> Hooks Class Initialized
DEBUG - 2018-02-14 18:51:24 --> UTF-8 Support Enabled
INFO - 2018-02-14 18:51:24 --> Utf8 Class Initialized
INFO - 2018-02-14 18:51:24 --> URI Class Initialized
INFO - 2018-02-14 18:51:24 --> Router Class Initialized
INFO - 2018-02-14 18:51:24 --> Output Class Initialized
INFO - 2018-02-14 18:51:24 --> Security Class Initialized
DEBUG - 2018-02-14 18:51:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 18:51:24 --> Input Class Initialized
INFO - 2018-02-14 18:51:24 --> Language Class Initialized
INFO - 2018-02-14 18:51:24 --> Loader Class Initialized
INFO - 2018-02-14 18:51:24 --> Helper loaded: url_helper
INFO - 2018-02-14 18:51:24 --> Helper loaded: file_helper
INFO - 2018-02-14 18:51:24 --> Helper loaded: email_helper
INFO - 2018-02-14 18:51:24 --> Helper loaded: common_helper
INFO - 2018-02-14 18:51:24 --> Database Driver Class Initialized
DEBUG - 2018-02-14 18:51:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 18:51:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 18:51:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-14 18:51:24 --> Pagination Class Initialized
INFO - 2018-02-14 18:51:24 --> Helper loaded: form_helper
INFO - 2018-02-14 18:51:24 --> Form Validation Class Initialized
INFO - 2018-02-14 18:51:24 --> Model Class Initialized
INFO - 2018-02-14 18:51:24 --> Controller Class Initialized
INFO - 2018-02-14 18:51:24 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-14 18:51:24 --> Model Class Initialized
INFO - 2018-02-14 18:51:24 --> Model Class Initialized
INFO - 2018-02-14 18:51:24 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-14 18:51:24 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-14 18:51:24 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-14 18:51:24 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-14 18:51:24 --> File loaded: /var/www/html/project/radio/application/views/subcategory/add_edit.php
INFO - 2018-02-14 18:51:24 --> Final output sent to browser
DEBUG - 2018-02-14 18:51:24 --> Total execution time: 0.0076
INFO - 2018-02-14 18:51:27 --> Config Class Initialized
INFO - 2018-02-14 18:51:27 --> Hooks Class Initialized
DEBUG - 2018-02-14 18:51:27 --> UTF-8 Support Enabled
INFO - 2018-02-14 18:51:27 --> Utf8 Class Initialized
INFO - 2018-02-14 18:51:27 --> URI Class Initialized
INFO - 2018-02-14 18:51:27 --> Router Class Initialized
INFO - 2018-02-14 18:51:27 --> Output Class Initialized
INFO - 2018-02-14 18:51:27 --> Security Class Initialized
DEBUG - 2018-02-14 18:51:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 18:51:27 --> Input Class Initialized
INFO - 2018-02-14 18:51:27 --> Language Class Initialized
INFO - 2018-02-14 18:51:27 --> Loader Class Initialized
INFO - 2018-02-14 18:51:27 --> Helper loaded: url_helper
INFO - 2018-02-14 18:51:27 --> Helper loaded: file_helper
INFO - 2018-02-14 18:51:27 --> Helper loaded: email_helper
INFO - 2018-02-14 18:51:27 --> Helper loaded: common_helper
INFO - 2018-02-14 18:51:27 --> Database Driver Class Initialized
DEBUG - 2018-02-14 18:51:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 18:51:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 18:51:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-14 18:51:27 --> Pagination Class Initialized
INFO - 2018-02-14 18:51:27 --> Helper loaded: form_helper
INFO - 2018-02-14 18:51:27 --> Form Validation Class Initialized
INFO - 2018-02-14 18:51:27 --> Model Class Initialized
INFO - 2018-02-14 18:51:27 --> Controller Class Initialized
INFO - 2018-02-14 18:51:27 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-14 18:51:27 --> Model Class Initialized
INFO - 2018-02-14 18:51:27 --> Model Class Initialized
INFO - 2018-02-14 18:51:27 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-14 18:51:27 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-14 18:51:27 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-14 18:51:27 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-14 18:51:27 --> File loaded: /var/www/html/project/radio/application/views/subcategory/index.php
INFO - 2018-02-14 18:51:27 --> Final output sent to browser
DEBUG - 2018-02-14 18:51:27 --> Total execution time: 0.0071
INFO - 2018-02-14 18:51:29 --> Config Class Initialized
INFO - 2018-02-14 18:51:29 --> Hooks Class Initialized
DEBUG - 2018-02-14 18:51:29 --> UTF-8 Support Enabled
INFO - 2018-02-14 18:51:29 --> Utf8 Class Initialized
INFO - 2018-02-14 18:51:29 --> URI Class Initialized
INFO - 2018-02-14 18:51:29 --> Router Class Initialized
INFO - 2018-02-14 18:51:29 --> Output Class Initialized
INFO - 2018-02-14 18:51:29 --> Security Class Initialized
DEBUG - 2018-02-14 18:51:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 18:51:29 --> Input Class Initialized
INFO - 2018-02-14 18:51:29 --> Language Class Initialized
INFO - 2018-02-14 18:51:29 --> Loader Class Initialized
INFO - 2018-02-14 18:51:29 --> Helper loaded: url_helper
INFO - 2018-02-14 18:51:29 --> Helper loaded: file_helper
INFO - 2018-02-14 18:51:29 --> Helper loaded: email_helper
INFO - 2018-02-14 18:51:29 --> Helper loaded: common_helper
INFO - 2018-02-14 18:51:29 --> Database Driver Class Initialized
DEBUG - 2018-02-14 18:51:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 18:51:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 18:51:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-14 18:51:29 --> Pagination Class Initialized
INFO - 2018-02-14 18:51:29 --> Helper loaded: form_helper
INFO - 2018-02-14 18:51:29 --> Form Validation Class Initialized
INFO - 2018-02-14 18:51:29 --> Model Class Initialized
INFO - 2018-02-14 18:51:29 --> Controller Class Initialized
INFO - 2018-02-14 18:51:29 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-14 18:51:29 --> Model Class Initialized
INFO - 2018-02-14 18:51:29 --> Model Class Initialized
INFO - 2018-02-14 18:51:29 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-14 18:51:29 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-14 18:51:29 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-14 18:51:29 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-14 18:51:29 --> File loaded: /var/www/html/project/radio/application/views/subcategory/add_edit.php
INFO - 2018-02-14 18:51:29 --> Final output sent to browser
DEBUG - 2018-02-14 18:51:29 --> Total execution time: 0.0055
INFO - 2018-02-14 18:51:33 --> Config Class Initialized
INFO - 2018-02-14 18:51:33 --> Hooks Class Initialized
DEBUG - 2018-02-14 18:51:33 --> UTF-8 Support Enabled
INFO - 2018-02-14 18:51:33 --> Utf8 Class Initialized
INFO - 2018-02-14 18:51:33 --> URI Class Initialized
INFO - 2018-02-14 18:51:33 --> Router Class Initialized
INFO - 2018-02-14 18:51:33 --> Output Class Initialized
INFO - 2018-02-14 18:51:33 --> Security Class Initialized
DEBUG - 2018-02-14 18:51:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 18:51:33 --> Input Class Initialized
INFO - 2018-02-14 18:51:33 --> Language Class Initialized
INFO - 2018-02-14 18:51:33 --> Loader Class Initialized
INFO - 2018-02-14 18:51:33 --> Helper loaded: url_helper
INFO - 2018-02-14 18:51:33 --> Helper loaded: file_helper
INFO - 2018-02-14 18:51:33 --> Helper loaded: email_helper
INFO - 2018-02-14 18:51:33 --> Helper loaded: common_helper
INFO - 2018-02-14 18:51:33 --> Database Driver Class Initialized
DEBUG - 2018-02-14 18:51:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 18:51:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 18:51:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-14 18:51:33 --> Pagination Class Initialized
INFO - 2018-02-14 18:51:33 --> Helper loaded: form_helper
INFO - 2018-02-14 18:51:33 --> Form Validation Class Initialized
INFO - 2018-02-14 18:51:33 --> Model Class Initialized
INFO - 2018-02-14 18:51:33 --> Controller Class Initialized
INFO - 2018-02-14 18:51:33 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-14 18:51:33 --> Model Class Initialized
INFO - 2018-02-14 18:51:33 --> Model Class Initialized
INFO - 2018-02-14 18:51:33 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-14 18:51:33 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-14 18:51:33 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-14 18:51:33 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-14 18:51:33 --> File loaded: /var/www/html/project/radio/application/views/subcategory/index.php
INFO - 2018-02-14 18:51:33 --> Final output sent to browser
DEBUG - 2018-02-14 18:51:33 --> Total execution time: 0.0073
INFO - 2018-02-14 18:51:35 --> Config Class Initialized
INFO - 2018-02-14 18:51:35 --> Hooks Class Initialized
DEBUG - 2018-02-14 18:51:35 --> UTF-8 Support Enabled
INFO - 2018-02-14 18:51:35 --> Utf8 Class Initialized
INFO - 2018-02-14 18:51:35 --> URI Class Initialized
INFO - 2018-02-14 18:51:35 --> Router Class Initialized
INFO - 2018-02-14 18:51:35 --> Output Class Initialized
INFO - 2018-02-14 18:51:35 --> Security Class Initialized
DEBUG - 2018-02-14 18:51:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 18:51:35 --> Input Class Initialized
INFO - 2018-02-14 18:51:35 --> Language Class Initialized
INFO - 2018-02-14 18:51:35 --> Loader Class Initialized
INFO - 2018-02-14 18:51:35 --> Helper loaded: url_helper
INFO - 2018-02-14 18:51:35 --> Helper loaded: file_helper
INFO - 2018-02-14 18:51:35 --> Helper loaded: email_helper
INFO - 2018-02-14 18:51:35 --> Helper loaded: common_helper
INFO - 2018-02-14 18:51:35 --> Database Driver Class Initialized
DEBUG - 2018-02-14 18:51:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 18:51:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 18:51:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-14 18:51:35 --> Pagination Class Initialized
INFO - 2018-02-14 18:51:35 --> Helper loaded: form_helper
INFO - 2018-02-14 18:51:35 --> Form Validation Class Initialized
INFO - 2018-02-14 18:51:35 --> Model Class Initialized
INFO - 2018-02-14 18:51:35 --> Controller Class Initialized
INFO - 2018-02-14 18:51:35 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-14 18:51:35 --> Model Class Initialized
INFO - 2018-02-14 18:51:35 --> Model Class Initialized
INFO - 2018-02-14 18:51:35 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-14 18:51:35 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-14 18:51:35 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-14 18:51:35 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-14 18:51:35 --> File loaded: /var/www/html/project/radio/application/views/subcategory/add_edit.php
INFO - 2018-02-14 18:51:35 --> Final output sent to browser
DEBUG - 2018-02-14 18:51:35 --> Total execution time: 0.0063
INFO - 2018-02-14 18:51:36 --> Config Class Initialized
INFO - 2018-02-14 18:51:36 --> Hooks Class Initialized
DEBUG - 2018-02-14 18:51:36 --> UTF-8 Support Enabled
INFO - 2018-02-14 18:51:36 --> Utf8 Class Initialized
INFO - 2018-02-14 18:51:36 --> URI Class Initialized
INFO - 2018-02-14 18:51:36 --> Router Class Initialized
INFO - 2018-02-14 18:51:36 --> Output Class Initialized
INFO - 2018-02-14 18:51:36 --> Security Class Initialized
DEBUG - 2018-02-14 18:51:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 18:51:36 --> Input Class Initialized
INFO - 2018-02-14 18:51:36 --> Language Class Initialized
INFO - 2018-02-14 18:51:36 --> Loader Class Initialized
INFO - 2018-02-14 18:51:36 --> Helper loaded: url_helper
INFO - 2018-02-14 18:51:36 --> Helper loaded: file_helper
INFO - 2018-02-14 18:51:36 --> Helper loaded: email_helper
INFO - 2018-02-14 18:51:36 --> Helper loaded: common_helper
INFO - 2018-02-14 18:51:36 --> Database Driver Class Initialized
DEBUG - 2018-02-14 18:51:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 18:51:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 18:51:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-14 18:51:36 --> Pagination Class Initialized
INFO - 2018-02-14 18:51:36 --> Helper loaded: form_helper
INFO - 2018-02-14 18:51:36 --> Form Validation Class Initialized
INFO - 2018-02-14 18:51:36 --> Model Class Initialized
INFO - 2018-02-14 18:51:36 --> Controller Class Initialized
INFO - 2018-02-14 18:51:36 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-14 18:51:36 --> Model Class Initialized
INFO - 2018-02-14 18:51:36 --> Model Class Initialized
INFO - 2018-02-14 18:51:36 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-14 18:51:36 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-14 18:51:36 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-14 18:51:36 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-14 18:51:36 --> File loaded: /var/www/html/project/radio/application/views/subcategory/index.php
INFO - 2018-02-14 18:51:36 --> Final output sent to browser
DEBUG - 2018-02-14 18:51:36 --> Total execution time: 0.0064
INFO - 2018-02-14 18:51:38 --> Config Class Initialized
INFO - 2018-02-14 18:51:38 --> Hooks Class Initialized
DEBUG - 2018-02-14 18:51:38 --> UTF-8 Support Enabled
INFO - 2018-02-14 18:51:38 --> Utf8 Class Initialized
INFO - 2018-02-14 18:51:38 --> URI Class Initialized
INFO - 2018-02-14 18:51:38 --> Router Class Initialized
INFO - 2018-02-14 18:51:38 --> Output Class Initialized
INFO - 2018-02-14 18:51:38 --> Security Class Initialized
DEBUG - 2018-02-14 18:51:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 18:51:38 --> Input Class Initialized
INFO - 2018-02-14 18:51:38 --> Language Class Initialized
INFO - 2018-02-14 18:51:38 --> Loader Class Initialized
INFO - 2018-02-14 18:51:38 --> Helper loaded: url_helper
INFO - 2018-02-14 18:51:38 --> Helper loaded: file_helper
INFO - 2018-02-14 18:51:38 --> Helper loaded: email_helper
INFO - 2018-02-14 18:51:38 --> Helper loaded: common_helper
INFO - 2018-02-14 18:51:38 --> Database Driver Class Initialized
DEBUG - 2018-02-14 18:51:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 18:51:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 18:51:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-14 18:51:38 --> Pagination Class Initialized
INFO - 2018-02-14 18:51:38 --> Helper loaded: form_helper
INFO - 2018-02-14 18:51:38 --> Form Validation Class Initialized
INFO - 2018-02-14 18:51:38 --> Model Class Initialized
INFO - 2018-02-14 18:51:38 --> Controller Class Initialized
INFO - 2018-02-14 18:51:38 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-14 18:51:38 --> Model Class Initialized
INFO - 2018-02-14 18:51:38 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-14 18:51:38 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-14 18:51:38 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-14 18:51:38 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-14 18:51:38 --> File loaded: /var/www/html/project/radio/application/views/category/index.php
INFO - 2018-02-14 18:51:38 --> Final output sent to browser
DEBUG - 2018-02-14 18:51:38 --> Total execution time: 0.0043
INFO - 2018-02-14 18:51:40 --> Config Class Initialized
INFO - 2018-02-14 18:51:40 --> Hooks Class Initialized
DEBUG - 2018-02-14 18:51:40 --> UTF-8 Support Enabled
INFO - 2018-02-14 18:51:40 --> Utf8 Class Initialized
INFO - 2018-02-14 18:51:40 --> URI Class Initialized
INFO - 2018-02-14 18:51:40 --> Router Class Initialized
INFO - 2018-02-14 18:51:40 --> Output Class Initialized
INFO - 2018-02-14 18:51:40 --> Security Class Initialized
DEBUG - 2018-02-14 18:51:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 18:51:40 --> Input Class Initialized
INFO - 2018-02-14 18:51:40 --> Language Class Initialized
INFO - 2018-02-14 18:51:40 --> Loader Class Initialized
INFO - 2018-02-14 18:51:40 --> Helper loaded: url_helper
INFO - 2018-02-14 18:51:40 --> Helper loaded: file_helper
INFO - 2018-02-14 18:51:40 --> Helper loaded: email_helper
INFO - 2018-02-14 18:51:40 --> Helper loaded: common_helper
INFO - 2018-02-14 18:51:40 --> Database Driver Class Initialized
DEBUG - 2018-02-14 18:51:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 18:51:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 18:51:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-14 18:51:40 --> Pagination Class Initialized
INFO - 2018-02-14 18:51:40 --> Helper loaded: form_helper
INFO - 2018-02-14 18:51:40 --> Form Validation Class Initialized
INFO - 2018-02-14 18:51:40 --> Model Class Initialized
INFO - 2018-02-14 18:51:40 --> Controller Class Initialized
INFO - 2018-02-14 18:51:40 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-14 18:51:40 --> Model Class Initialized
INFO - 2018-02-14 18:51:40 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-14 18:51:40 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-14 18:51:40 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-14 18:51:40 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-14 18:51:40 --> File loaded: /var/www/html/project/radio/application/views/category/index.php
INFO - 2018-02-14 18:51:40 --> Final output sent to browser
DEBUG - 2018-02-14 18:51:40 --> Total execution time: 0.0051
INFO - 2018-02-14 18:51:42 --> Config Class Initialized
INFO - 2018-02-14 18:51:42 --> Hooks Class Initialized
DEBUG - 2018-02-14 18:51:42 --> UTF-8 Support Enabled
INFO - 2018-02-14 18:51:42 --> Utf8 Class Initialized
INFO - 2018-02-14 18:51:42 --> URI Class Initialized
INFO - 2018-02-14 18:51:42 --> Router Class Initialized
INFO - 2018-02-14 18:51:42 --> Output Class Initialized
INFO - 2018-02-14 18:51:42 --> Security Class Initialized
DEBUG - 2018-02-14 18:51:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 18:51:42 --> Input Class Initialized
INFO - 2018-02-14 18:51:42 --> Language Class Initialized
INFO - 2018-02-14 18:51:42 --> Loader Class Initialized
INFO - 2018-02-14 18:51:42 --> Helper loaded: url_helper
INFO - 2018-02-14 18:51:42 --> Helper loaded: file_helper
INFO - 2018-02-14 18:51:42 --> Helper loaded: email_helper
INFO - 2018-02-14 18:51:42 --> Helper loaded: common_helper
INFO - 2018-02-14 18:51:42 --> Database Driver Class Initialized
DEBUG - 2018-02-14 18:51:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 18:51:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 18:51:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-14 18:51:42 --> Pagination Class Initialized
INFO - 2018-02-14 18:51:42 --> Helper loaded: form_helper
INFO - 2018-02-14 18:51:42 --> Form Validation Class Initialized
INFO - 2018-02-14 18:51:42 --> Model Class Initialized
INFO - 2018-02-14 18:51:42 --> Controller Class Initialized
INFO - 2018-02-14 18:51:42 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-14 18:51:42 --> Model Class Initialized
INFO - 2018-02-14 18:51:42 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-14 18:51:42 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-14 18:51:42 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-14 18:51:42 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-14 18:51:42 --> File loaded: /var/www/html/project/radio/application/views/category/add_edit.php
INFO - 2018-02-14 18:51:42 --> Final output sent to browser
DEBUG - 2018-02-14 18:51:42 --> Total execution time: 0.0053
INFO - 2018-02-14 18:51:48 --> Config Class Initialized
INFO - 2018-02-14 18:51:48 --> Hooks Class Initialized
DEBUG - 2018-02-14 18:51:48 --> UTF-8 Support Enabled
INFO - 2018-02-14 18:51:48 --> Utf8 Class Initialized
INFO - 2018-02-14 18:51:48 --> URI Class Initialized
INFO - 2018-02-14 18:51:48 --> Router Class Initialized
INFO - 2018-02-14 18:51:48 --> Output Class Initialized
INFO - 2018-02-14 18:51:48 --> Security Class Initialized
DEBUG - 2018-02-14 18:51:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-14 18:51:48 --> Input Class Initialized
INFO - 2018-02-14 18:51:48 --> Language Class Initialized
INFO - 2018-02-14 18:51:48 --> Loader Class Initialized
INFO - 2018-02-14 18:51:48 --> Helper loaded: url_helper
INFO - 2018-02-14 18:51:48 --> Helper loaded: file_helper
INFO - 2018-02-14 18:51:48 --> Helper loaded: email_helper
INFO - 2018-02-14 18:51:48 --> Helper loaded: common_helper
INFO - 2018-02-14 18:51:48 --> Database Driver Class Initialized
DEBUG - 2018-02-14 18:51:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-14 18:51:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-14 18:51:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-14 18:51:48 --> Pagination Class Initialized
INFO - 2018-02-14 18:51:48 --> Helper loaded: form_helper
INFO - 2018-02-14 18:51:48 --> Form Validation Class Initialized
INFO - 2018-02-14 18:51:48 --> Model Class Initialized
INFO - 2018-02-14 18:51:48 --> Controller Class Initialized
INFO - 2018-02-14 18:51:48 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-14 18:51:48 --> Model Class Initialized
INFO - 2018-02-14 18:51:48 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-14 18:51:48 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-14 18:51:48 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-14 18:51:48 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-14 18:51:48 --> File loaded: /var/www/html/project/radio/application/views/category/index.php
INFO - 2018-02-14 18:51:48 --> Final output sent to browser
DEBUG - 2018-02-14 18:51:48 --> Total execution time: 0.0106

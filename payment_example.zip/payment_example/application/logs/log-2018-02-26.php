<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2018-02-26 09:56:36 --> Config Class Initialized
INFO - 2018-02-26 09:56:36 --> Hooks Class Initialized
DEBUG - 2018-02-26 09:56:36 --> UTF-8 Support Enabled
INFO - 2018-02-26 09:56:36 --> Utf8 Class Initialized
INFO - 2018-02-26 09:56:36 --> URI Class Initialized
INFO - 2018-02-26 09:56:36 --> Router Class Initialized
INFO - 2018-02-26 09:56:36 --> Output Class Initialized
INFO - 2018-02-26 09:56:36 --> Security Class Initialized
DEBUG - 2018-02-26 09:56:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-26 09:56:36 --> Input Class Initialized
INFO - 2018-02-26 09:56:36 --> Language Class Initialized
INFO - 2018-02-26 09:56:36 --> Loader Class Initialized
INFO - 2018-02-26 09:56:36 --> Helper loaded: url_helper
INFO - 2018-02-26 09:56:36 --> Helper loaded: file_helper
INFO - 2018-02-26 09:56:36 --> Helper loaded: email_helper
INFO - 2018-02-26 09:56:36 --> Helper loaded: common_helper
INFO - 2018-02-26 09:56:36 --> Database Driver Class Initialized
DEBUG - 2018-02-26 09:56:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-26 09:56:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-26 09:56:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-26 09:56:36 --> Pagination Class Initialized
INFO - 2018-02-26 09:56:36 --> Helper loaded: form_helper
INFO - 2018-02-26 09:56:36 --> Form Validation Class Initialized
INFO - 2018-02-26 09:56:36 --> Model Class Initialized
INFO - 2018-02-26 09:56:36 --> Controller Class Initialized
INFO - 2018-02-26 09:56:36 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-26 09:56:36 --> Model Class Initialized
INFO - 2018-02-26 09:56:36 --> Model Class Initialized
INFO - 2018-02-26 09:56:36 --> File loaded: /var/www/html/project/radio/application/views/index/index.php
INFO - 2018-02-26 09:56:36 --> Final output sent to browser
DEBUG - 2018-02-26 09:56:36 --> Total execution time: 0.0303
INFO - 2018-02-26 14:29:10 --> Config Class Initialized
INFO - 2018-02-26 14:29:10 --> Hooks Class Initialized
DEBUG - 2018-02-26 14:29:10 --> UTF-8 Support Enabled
INFO - 2018-02-26 14:29:10 --> Utf8 Class Initialized
INFO - 2018-02-26 14:29:10 --> URI Class Initialized
INFO - 2018-02-26 14:29:10 --> Router Class Initialized
INFO - 2018-02-26 14:29:10 --> Output Class Initialized
INFO - 2018-02-26 14:29:10 --> Security Class Initialized
DEBUG - 2018-02-26 14:29:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-26 14:29:10 --> Input Class Initialized
INFO - 2018-02-26 14:29:10 --> Language Class Initialized
INFO - 2018-02-26 14:29:10 --> Loader Class Initialized
INFO - 2018-02-26 14:29:10 --> Helper loaded: url_helper
INFO - 2018-02-26 14:29:10 --> Helper loaded: file_helper
INFO - 2018-02-26 14:29:10 --> Helper loaded: email_helper
INFO - 2018-02-26 14:29:10 --> Helper loaded: common_helper
INFO - 2018-02-26 14:29:10 --> Database Driver Class Initialized
DEBUG - 2018-02-26 14:29:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-26 14:29:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-26 14:29:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-26 14:29:10 --> Pagination Class Initialized
INFO - 2018-02-26 14:29:10 --> Helper loaded: form_helper
INFO - 2018-02-26 14:29:10 --> Form Validation Class Initialized
INFO - 2018-02-26 14:29:10 --> Model Class Initialized
INFO - 2018-02-26 14:29:10 --> Controller Class Initialized
INFO - 2018-02-26 14:29:10 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-26 14:29:10 --> Config Class Initialized
INFO - 2018-02-26 14:29:10 --> Hooks Class Initialized
DEBUG - 2018-02-26 14:29:10 --> UTF-8 Support Enabled
INFO - 2018-02-26 14:29:10 --> Utf8 Class Initialized
INFO - 2018-02-26 14:29:10 --> URI Class Initialized
DEBUG - 2018-02-26 14:29:10 --> No URI present. Default controller set.
INFO - 2018-02-26 14:29:10 --> Router Class Initialized
INFO - 2018-02-26 14:29:10 --> Output Class Initialized
INFO - 2018-02-26 14:29:10 --> Security Class Initialized
DEBUG - 2018-02-26 14:29:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-26 14:29:10 --> Input Class Initialized
INFO - 2018-02-26 14:29:10 --> Language Class Initialized
INFO - 2018-02-26 14:29:10 --> Loader Class Initialized
INFO - 2018-02-26 14:29:10 --> Helper loaded: url_helper
INFO - 2018-02-26 14:29:10 --> Helper loaded: file_helper
INFO - 2018-02-26 14:29:10 --> Helper loaded: email_helper
INFO - 2018-02-26 14:29:10 --> Helper loaded: common_helper
INFO - 2018-02-26 14:29:10 --> Database Driver Class Initialized
DEBUG - 2018-02-26 14:29:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-26 14:29:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-26 14:29:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-26 14:29:10 --> Pagination Class Initialized
INFO - 2018-02-26 14:29:10 --> Helper loaded: form_helper
INFO - 2018-02-26 14:29:10 --> Form Validation Class Initialized
INFO - 2018-02-26 14:29:10 --> Model Class Initialized
INFO - 2018-02-26 14:29:10 --> Controller Class Initialized
INFO - 2018-02-26 14:29:10 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-26 14:29:10 --> Model Class Initialized
INFO - 2018-02-26 14:29:10 --> Model Class Initialized
INFO - 2018-02-26 14:29:10 --> File loaded: /var/www/html/project/radio/application/views/index/index.php
INFO - 2018-02-26 14:29:10 --> Final output sent to browser
DEBUG - 2018-02-26 14:29:10 --> Total execution time: 0.0042
INFO - 2018-02-26 14:29:26 --> Config Class Initialized
INFO - 2018-02-26 14:29:26 --> Hooks Class Initialized
DEBUG - 2018-02-26 14:29:26 --> UTF-8 Support Enabled
INFO - 2018-02-26 14:29:26 --> Utf8 Class Initialized
INFO - 2018-02-26 14:29:26 --> URI Class Initialized
INFO - 2018-02-26 14:29:26 --> Router Class Initialized
INFO - 2018-02-26 14:29:26 --> Output Class Initialized
INFO - 2018-02-26 14:29:26 --> Security Class Initialized
DEBUG - 2018-02-26 14:29:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-26 14:29:26 --> Input Class Initialized
INFO - 2018-02-26 14:29:26 --> Language Class Initialized
INFO - 2018-02-26 14:29:26 --> Loader Class Initialized
INFO - 2018-02-26 14:29:26 --> Helper loaded: url_helper
INFO - 2018-02-26 14:29:26 --> Helper loaded: file_helper
INFO - 2018-02-26 14:29:26 --> Helper loaded: email_helper
INFO - 2018-02-26 14:29:26 --> Helper loaded: common_helper
INFO - 2018-02-26 14:29:26 --> Database Driver Class Initialized
DEBUG - 2018-02-26 14:29:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-26 14:29:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-26 14:29:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-26 14:29:26 --> Pagination Class Initialized
INFO - 2018-02-26 14:29:26 --> Helper loaded: form_helper
INFO - 2018-02-26 14:29:26 --> Form Validation Class Initialized
INFO - 2018-02-26 14:29:26 --> Model Class Initialized
INFO - 2018-02-26 14:29:26 --> Controller Class Initialized
INFO - 2018-02-26 14:29:26 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-26 14:29:26 --> Model Class Initialized
INFO - 2018-02-26 14:29:26 --> Model Class Initialized
ERROR - 2018-02-26 14:29:26 --> Severity: Notice --> Undefined index: remember_me /var/www/html/project/radio/application/controllers/Index.php 74
INFO - 2018-02-26 14:29:26 --> Config Class Initialized
INFO - 2018-02-26 14:29:26 --> Hooks Class Initialized
DEBUG - 2018-02-26 14:29:26 --> UTF-8 Support Enabled
INFO - 2018-02-26 14:29:26 --> Utf8 Class Initialized
INFO - 2018-02-26 14:29:26 --> URI Class Initialized
INFO - 2018-02-26 14:29:26 --> Router Class Initialized
INFO - 2018-02-26 14:29:26 --> Output Class Initialized
INFO - 2018-02-26 14:29:26 --> Security Class Initialized
DEBUG - 2018-02-26 14:29:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-26 14:29:26 --> Input Class Initialized
INFO - 2018-02-26 14:29:26 --> Language Class Initialized
INFO - 2018-02-26 14:29:26 --> Loader Class Initialized
INFO - 2018-02-26 14:29:26 --> Helper loaded: url_helper
INFO - 2018-02-26 14:29:26 --> Helper loaded: file_helper
INFO - 2018-02-26 14:29:26 --> Helper loaded: email_helper
INFO - 2018-02-26 14:29:26 --> Helper loaded: common_helper
INFO - 2018-02-26 14:29:26 --> Database Driver Class Initialized
DEBUG - 2018-02-26 14:29:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-26 14:29:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-26 14:29:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-26 14:29:26 --> Pagination Class Initialized
INFO - 2018-02-26 14:29:26 --> Helper loaded: form_helper
INFO - 2018-02-26 14:29:26 --> Form Validation Class Initialized
INFO - 2018-02-26 14:29:26 --> Model Class Initialized
INFO - 2018-02-26 14:29:26 --> Controller Class Initialized
INFO - 2018-02-26 14:29:26 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-26 14:29:26 --> Model Class Initialized
INFO - 2018-02-26 14:29:26 --> Model Class Initialized
INFO - 2018-02-26 14:29:26 --> Model Class Initialized
INFO - 2018-02-26 14:29:26 --> Model Class Initialized
INFO - 2018-02-26 14:29:26 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-26 14:29:26 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-26 14:29:26 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-26 14:29:26 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-26 14:29:26 --> File loaded: /var/www/html/project/radio/application/views/dashboard/index.php
INFO - 2018-02-26 14:29:26 --> Final output sent to browser
DEBUG - 2018-02-26 14:29:26 --> Total execution time: 0.0088
INFO - 2018-02-26 16:49:31 --> Config Class Initialized
INFO - 2018-02-26 16:49:31 --> Hooks Class Initialized
DEBUG - 2018-02-26 16:49:31 --> UTF-8 Support Enabled
INFO - 2018-02-26 16:49:31 --> Utf8 Class Initialized
INFO - 2018-02-26 16:49:31 --> URI Class Initialized
INFO - 2018-02-26 16:49:31 --> Router Class Initialized
INFO - 2018-02-26 16:49:31 --> Output Class Initialized
INFO - 2018-02-26 16:49:31 --> Security Class Initialized
DEBUG - 2018-02-26 16:49:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-26 16:49:31 --> Input Class Initialized
INFO - 2018-02-26 16:49:31 --> Language Class Initialized
INFO - 2018-02-26 16:49:31 --> Loader Class Initialized
INFO - 2018-02-26 16:49:31 --> Helper loaded: url_helper
INFO - 2018-02-26 16:49:31 --> Helper loaded: file_helper
INFO - 2018-02-26 16:49:31 --> Helper loaded: email_helper
INFO - 2018-02-26 16:49:31 --> Helper loaded: common_helper
INFO - 2018-02-26 16:49:31 --> Database Driver Class Initialized
DEBUG - 2018-02-26 16:49:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-26 16:49:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-26 16:49:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-26 16:49:31 --> Pagination Class Initialized
INFO - 2018-02-26 16:49:31 --> Helper loaded: form_helper
INFO - 2018-02-26 16:49:31 --> Form Validation Class Initialized
INFO - 2018-02-26 16:49:31 --> Model Class Initialized
INFO - 2018-02-26 16:49:31 --> Controller Class Initialized
INFO - 2018-02-26 16:49:31 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-26 16:49:31 --> Config Class Initialized
INFO - 2018-02-26 16:49:31 --> Hooks Class Initialized
DEBUG - 2018-02-26 16:49:31 --> UTF-8 Support Enabled
INFO - 2018-02-26 16:49:31 --> Utf8 Class Initialized
INFO - 2018-02-26 16:49:31 --> URI Class Initialized
DEBUG - 2018-02-26 16:49:31 --> No URI present. Default controller set.
INFO - 2018-02-26 16:49:31 --> Router Class Initialized
INFO - 2018-02-26 16:49:31 --> Output Class Initialized
INFO - 2018-02-26 16:49:31 --> Security Class Initialized
DEBUG - 2018-02-26 16:49:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-26 16:49:31 --> Input Class Initialized
INFO - 2018-02-26 16:49:31 --> Language Class Initialized
INFO - 2018-02-26 16:49:31 --> Loader Class Initialized
INFO - 2018-02-26 16:49:31 --> Helper loaded: url_helper
INFO - 2018-02-26 16:49:31 --> Helper loaded: file_helper
INFO - 2018-02-26 16:49:31 --> Helper loaded: email_helper
INFO - 2018-02-26 16:49:31 --> Helper loaded: common_helper
INFO - 2018-02-26 16:49:31 --> Database Driver Class Initialized
DEBUG - 2018-02-26 16:49:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-26 16:49:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-26 16:49:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-26 16:49:31 --> Pagination Class Initialized
INFO - 2018-02-26 16:49:31 --> Helper loaded: form_helper
INFO - 2018-02-26 16:49:31 --> Form Validation Class Initialized
INFO - 2018-02-26 16:49:31 --> Model Class Initialized
INFO - 2018-02-26 16:49:31 --> Controller Class Initialized
INFO - 2018-02-26 16:49:31 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-26 16:49:31 --> Model Class Initialized
INFO - 2018-02-26 16:49:31 --> Model Class Initialized
INFO - 2018-02-26 16:49:31 --> File loaded: /var/www/html/project/radio/application/views/index/index.php
INFO - 2018-02-26 16:49:31 --> Final output sent to browser
DEBUG - 2018-02-26 16:49:31 --> Total execution time: 0.0054
INFO - 2018-02-26 16:49:32 --> Config Class Initialized
INFO - 2018-02-26 16:49:32 --> Hooks Class Initialized
DEBUG - 2018-02-26 16:49:32 --> UTF-8 Support Enabled
INFO - 2018-02-26 16:49:32 --> Utf8 Class Initialized
INFO - 2018-02-26 16:49:32 --> URI Class Initialized
INFO - 2018-02-26 16:49:32 --> Router Class Initialized
INFO - 2018-02-26 16:49:32 --> Output Class Initialized
INFO - 2018-02-26 16:49:32 --> Security Class Initialized
DEBUG - 2018-02-26 16:49:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-26 16:49:32 --> Input Class Initialized
INFO - 2018-02-26 16:49:32 --> Language Class Initialized
INFO - 2018-02-26 16:49:32 --> Loader Class Initialized
INFO - 2018-02-26 16:49:32 --> Helper loaded: url_helper
INFO - 2018-02-26 16:49:32 --> Helper loaded: file_helper
INFO - 2018-02-26 16:49:32 --> Helper loaded: email_helper
INFO - 2018-02-26 16:49:32 --> Helper loaded: common_helper
INFO - 2018-02-26 16:49:32 --> Database Driver Class Initialized
DEBUG - 2018-02-26 16:49:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-26 16:49:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-26 16:49:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-26 16:49:32 --> Pagination Class Initialized
INFO - 2018-02-26 16:49:32 --> Helper loaded: form_helper
INFO - 2018-02-26 16:49:32 --> Form Validation Class Initialized
INFO - 2018-02-26 16:49:32 --> Model Class Initialized
INFO - 2018-02-26 16:49:32 --> Controller Class Initialized
INFO - 2018-02-26 16:49:32 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-26 16:49:32 --> Model Class Initialized
INFO - 2018-02-26 16:49:32 --> Model Class Initialized
ERROR - 2018-02-26 16:49:32 --> Severity: Notice --> Undefined index: remember_me /var/www/html/project/radio/application/controllers/Index.php 74
INFO - 2018-02-26 16:49:32 --> Config Class Initialized
INFO - 2018-02-26 16:49:32 --> Hooks Class Initialized
DEBUG - 2018-02-26 16:49:32 --> UTF-8 Support Enabled
INFO - 2018-02-26 16:49:32 --> Utf8 Class Initialized
INFO - 2018-02-26 16:49:32 --> URI Class Initialized
INFO - 2018-02-26 16:49:32 --> Router Class Initialized
INFO - 2018-02-26 16:49:32 --> Output Class Initialized
INFO - 2018-02-26 16:49:32 --> Security Class Initialized
DEBUG - 2018-02-26 16:49:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-26 16:49:32 --> Input Class Initialized
INFO - 2018-02-26 16:49:32 --> Language Class Initialized
INFO - 2018-02-26 16:49:32 --> Loader Class Initialized
INFO - 2018-02-26 16:49:32 --> Helper loaded: url_helper
INFO - 2018-02-26 16:49:32 --> Helper loaded: file_helper
INFO - 2018-02-26 16:49:32 --> Helper loaded: email_helper
INFO - 2018-02-26 16:49:32 --> Helper loaded: common_helper
INFO - 2018-02-26 16:49:32 --> Database Driver Class Initialized
DEBUG - 2018-02-26 16:49:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-26 16:49:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-26 16:49:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-26 16:49:32 --> Pagination Class Initialized
INFO - 2018-02-26 16:49:32 --> Helper loaded: form_helper
INFO - 2018-02-26 16:49:32 --> Form Validation Class Initialized
INFO - 2018-02-26 16:49:32 --> Model Class Initialized
INFO - 2018-02-26 16:49:32 --> Controller Class Initialized
INFO - 2018-02-26 16:49:32 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-26 16:49:32 --> Model Class Initialized
INFO - 2018-02-26 16:49:32 --> Model Class Initialized
INFO - 2018-02-26 16:49:32 --> Model Class Initialized
INFO - 2018-02-26 16:49:32 --> Model Class Initialized
INFO - 2018-02-26 16:49:32 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-26 16:49:32 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-26 16:49:32 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-26 16:49:32 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-26 16:49:32 --> File loaded: /var/www/html/project/radio/application/views/dashboard/index.php
INFO - 2018-02-26 16:49:32 --> Final output sent to browser
DEBUG - 2018-02-26 16:49:32 --> Total execution time: 0.0075
INFO - 2018-02-26 16:49:33 --> Config Class Initialized
INFO - 2018-02-26 16:49:33 --> Hooks Class Initialized
DEBUG - 2018-02-26 16:49:33 --> UTF-8 Support Enabled
INFO - 2018-02-26 16:49:33 --> Utf8 Class Initialized
INFO - 2018-02-26 16:49:33 --> URI Class Initialized
INFO - 2018-02-26 16:49:33 --> Router Class Initialized
INFO - 2018-02-26 16:49:33 --> Output Class Initialized
INFO - 2018-02-26 16:49:33 --> Security Class Initialized
DEBUG - 2018-02-26 16:49:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-26 16:49:33 --> Input Class Initialized
INFO - 2018-02-26 16:49:33 --> Language Class Initialized
INFO - 2018-02-26 16:49:33 --> Loader Class Initialized
INFO - 2018-02-26 16:49:33 --> Helper loaded: url_helper
INFO - 2018-02-26 16:49:33 --> Helper loaded: file_helper
INFO - 2018-02-26 16:49:33 --> Helper loaded: email_helper
INFO - 2018-02-26 16:49:33 --> Helper loaded: common_helper
INFO - 2018-02-26 16:49:33 --> Database Driver Class Initialized
DEBUG - 2018-02-26 16:49:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-26 16:49:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-26 16:49:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-26 16:49:33 --> Pagination Class Initialized
INFO - 2018-02-26 16:49:33 --> Helper loaded: form_helper
INFO - 2018-02-26 16:49:33 --> Form Validation Class Initialized
INFO - 2018-02-26 16:49:33 --> Model Class Initialized
INFO - 2018-02-26 16:49:33 --> Controller Class Initialized
INFO - 2018-02-26 16:49:33 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-26 16:49:33 --> Model Class Initialized
INFO - 2018-02-26 16:49:33 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-26 16:49:33 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-26 16:49:33 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-26 16:49:33 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-26 16:49:33 --> File loaded: /var/www/html/project/radio/application/views/category/index.php
INFO - 2018-02-26 16:49:33 --> Final output sent to browser
DEBUG - 2018-02-26 16:49:33 --> Total execution time: 0.0047
INFO - 2018-02-26 16:49:34 --> Config Class Initialized
INFO - 2018-02-26 16:49:34 --> Hooks Class Initialized
DEBUG - 2018-02-26 16:49:34 --> UTF-8 Support Enabled
INFO - 2018-02-26 16:49:34 --> Utf8 Class Initialized
INFO - 2018-02-26 16:49:34 --> URI Class Initialized
INFO - 2018-02-26 16:49:34 --> Router Class Initialized
INFO - 2018-02-26 16:49:34 --> Output Class Initialized
INFO - 2018-02-26 16:49:34 --> Security Class Initialized
DEBUG - 2018-02-26 16:49:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-26 16:49:34 --> Input Class Initialized
INFO - 2018-02-26 16:49:34 --> Language Class Initialized
INFO - 2018-02-26 16:49:34 --> Loader Class Initialized
INFO - 2018-02-26 16:49:34 --> Helper loaded: url_helper
INFO - 2018-02-26 16:49:34 --> Helper loaded: file_helper
INFO - 2018-02-26 16:49:34 --> Helper loaded: email_helper
INFO - 2018-02-26 16:49:34 --> Helper loaded: common_helper
INFO - 2018-02-26 16:49:34 --> Database Driver Class Initialized
DEBUG - 2018-02-26 16:49:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-26 16:49:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-26 16:49:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-26 16:49:34 --> Pagination Class Initialized
INFO - 2018-02-26 16:49:34 --> Helper loaded: form_helper
INFO - 2018-02-26 16:49:34 --> Form Validation Class Initialized
INFO - 2018-02-26 16:49:34 --> Model Class Initialized
INFO - 2018-02-26 16:49:34 --> Controller Class Initialized
INFO - 2018-02-26 16:49:34 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-26 16:49:34 --> Model Class Initialized
INFO - 2018-02-26 16:49:34 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-26 16:49:34 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-26 16:49:34 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-26 16:49:34 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-26 16:49:34 --> File loaded: /var/www/html/project/radio/application/views/category/add_edit.php
INFO - 2018-02-26 16:49:34 --> Final output sent to browser
DEBUG - 2018-02-26 16:49:34 --> Total execution time: 0.0054
INFO - 2018-02-26 16:49:43 --> Config Class Initialized
INFO - 2018-02-26 16:49:43 --> Hooks Class Initialized
DEBUG - 2018-02-26 16:49:43 --> UTF-8 Support Enabled
INFO - 2018-02-26 16:49:43 --> Utf8 Class Initialized
INFO - 2018-02-26 16:49:43 --> URI Class Initialized
INFO - 2018-02-26 16:49:43 --> Router Class Initialized
INFO - 2018-02-26 16:49:43 --> Output Class Initialized
INFO - 2018-02-26 16:49:43 --> Security Class Initialized
DEBUG - 2018-02-26 16:49:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-26 16:49:43 --> Input Class Initialized
INFO - 2018-02-26 16:49:43 --> Language Class Initialized
INFO - 2018-02-26 16:49:43 --> Loader Class Initialized
INFO - 2018-02-26 16:49:43 --> Helper loaded: url_helper
INFO - 2018-02-26 16:49:43 --> Helper loaded: file_helper
INFO - 2018-02-26 16:49:43 --> Helper loaded: email_helper
INFO - 2018-02-26 16:49:43 --> Helper loaded: common_helper
INFO - 2018-02-26 16:49:43 --> Database Driver Class Initialized
DEBUG - 2018-02-26 16:49:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-26 16:49:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-26 16:49:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-26 16:49:43 --> Pagination Class Initialized
INFO - 2018-02-26 16:49:43 --> Helper loaded: form_helper
INFO - 2018-02-26 16:49:43 --> Form Validation Class Initialized
INFO - 2018-02-26 16:49:43 --> Model Class Initialized
INFO - 2018-02-26 16:49:43 --> Controller Class Initialized
INFO - 2018-02-26 16:49:43 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-26 16:49:43 --> Model Class Initialized
INFO - 2018-02-26 16:49:43 --> Config Class Initialized
INFO - 2018-02-26 16:49:43 --> Hooks Class Initialized
DEBUG - 2018-02-26 16:49:43 --> UTF-8 Support Enabled
INFO - 2018-02-26 16:49:43 --> Utf8 Class Initialized
INFO - 2018-02-26 16:49:43 --> URI Class Initialized
INFO - 2018-02-26 16:49:43 --> Router Class Initialized
INFO - 2018-02-26 16:49:43 --> Output Class Initialized
INFO - 2018-02-26 16:49:43 --> Security Class Initialized
DEBUG - 2018-02-26 16:49:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-26 16:49:43 --> Input Class Initialized
INFO - 2018-02-26 16:49:43 --> Language Class Initialized
INFO - 2018-02-26 16:49:43 --> Loader Class Initialized
INFO - 2018-02-26 16:49:43 --> Helper loaded: url_helper
INFO - 2018-02-26 16:49:43 --> Helper loaded: file_helper
INFO - 2018-02-26 16:49:43 --> Helper loaded: email_helper
INFO - 2018-02-26 16:49:43 --> Helper loaded: common_helper
INFO - 2018-02-26 16:49:43 --> Database Driver Class Initialized
DEBUG - 2018-02-26 16:49:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-26 16:49:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-26 16:49:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-26 16:49:43 --> Pagination Class Initialized
INFO - 2018-02-26 16:49:43 --> Helper loaded: form_helper
INFO - 2018-02-26 16:49:43 --> Form Validation Class Initialized
INFO - 2018-02-26 16:49:43 --> Model Class Initialized
INFO - 2018-02-26 16:49:43 --> Controller Class Initialized
INFO - 2018-02-26 16:49:43 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-26 16:49:43 --> Model Class Initialized
DEBUG - 2018-02-26 16:49:43 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-26 16:49:43 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-02-26 16:49:43 --> Config Class Initialized
INFO - 2018-02-26 16:49:43 --> Hooks Class Initialized
DEBUG - 2018-02-26 16:49:43 --> UTF-8 Support Enabled
INFO - 2018-02-26 16:49:43 --> Utf8 Class Initialized
INFO - 2018-02-26 16:49:43 --> URI Class Initialized
INFO - 2018-02-26 16:49:43 --> Router Class Initialized
INFO - 2018-02-26 16:49:43 --> Output Class Initialized
INFO - 2018-02-26 16:49:43 --> Security Class Initialized
DEBUG - 2018-02-26 16:49:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-26 16:49:43 --> Input Class Initialized
INFO - 2018-02-26 16:49:43 --> Language Class Initialized
INFO - 2018-02-26 16:49:43 --> Loader Class Initialized
INFO - 2018-02-26 16:49:43 --> Helper loaded: url_helper
INFO - 2018-02-26 16:49:43 --> Helper loaded: file_helper
INFO - 2018-02-26 16:49:43 --> Helper loaded: email_helper
INFO - 2018-02-26 16:49:43 --> Helper loaded: common_helper
INFO - 2018-02-26 16:49:43 --> Database Driver Class Initialized
DEBUG - 2018-02-26 16:49:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-26 16:49:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-26 16:49:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-26 16:49:43 --> Pagination Class Initialized
INFO - 2018-02-26 16:49:43 --> Helper loaded: form_helper
INFO - 2018-02-26 16:49:43 --> Form Validation Class Initialized
INFO - 2018-02-26 16:49:43 --> Model Class Initialized
INFO - 2018-02-26 16:49:43 --> Controller Class Initialized
INFO - 2018-02-26 16:49:43 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-26 16:49:43 --> Model Class Initialized
INFO - 2018-02-26 16:49:43 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-26 16:49:43 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-26 16:49:43 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-26 16:49:43 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-26 16:49:43 --> File loaded: /var/www/html/project/radio/application/views/category/index.php
INFO - 2018-02-26 16:49:43 --> Final output sent to browser
DEBUG - 2018-02-26 16:49:43 --> Total execution time: 0.0076
INFO - 2018-02-26 16:50:02 --> Config Class Initialized
INFO - 2018-02-26 16:50:02 --> Hooks Class Initialized
DEBUG - 2018-02-26 16:50:02 --> UTF-8 Support Enabled
INFO - 2018-02-26 16:50:02 --> Utf8 Class Initialized
INFO - 2018-02-26 16:50:02 --> URI Class Initialized
INFO - 2018-02-26 16:50:02 --> Router Class Initialized
INFO - 2018-02-26 16:50:02 --> Output Class Initialized
INFO - 2018-02-26 16:50:02 --> Security Class Initialized
DEBUG - 2018-02-26 16:50:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-26 16:50:02 --> Input Class Initialized
INFO - 2018-02-26 16:50:02 --> Language Class Initialized
INFO - 2018-02-26 16:50:02 --> Loader Class Initialized
INFO - 2018-02-26 16:50:02 --> Helper loaded: url_helper
INFO - 2018-02-26 16:50:02 --> Helper loaded: file_helper
INFO - 2018-02-26 16:50:02 --> Helper loaded: email_helper
INFO - 2018-02-26 16:50:02 --> Helper loaded: common_helper
INFO - 2018-02-26 16:50:02 --> Database Driver Class Initialized
DEBUG - 2018-02-26 16:50:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-26 16:50:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-26 16:50:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-26 16:50:02 --> Pagination Class Initialized
INFO - 2018-02-26 16:50:02 --> Helper loaded: form_helper
INFO - 2018-02-26 16:50:02 --> Form Validation Class Initialized
INFO - 2018-02-26 16:50:02 --> Model Class Initialized
INFO - 2018-02-26 16:50:02 --> Controller Class Initialized
INFO - 2018-02-26 16:50:02 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-26 16:50:02 --> Model Class Initialized
INFO - 2018-02-26 16:50:02 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-26 16:50:02 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-26 16:50:02 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-26 16:50:02 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-26 16:50:02 --> File loaded: /var/www/html/project/radio/application/views/category/add_edit.php
INFO - 2018-02-26 16:50:02 --> Final output sent to browser
DEBUG - 2018-02-26 16:50:02 --> Total execution time: 0.0068
INFO - 2018-02-26 16:50:16 --> Config Class Initialized
INFO - 2018-02-26 16:50:16 --> Hooks Class Initialized
DEBUG - 2018-02-26 16:50:16 --> UTF-8 Support Enabled
INFO - 2018-02-26 16:50:16 --> Utf8 Class Initialized
INFO - 2018-02-26 16:50:16 --> URI Class Initialized
INFO - 2018-02-26 16:50:16 --> Router Class Initialized
INFO - 2018-02-26 16:50:16 --> Output Class Initialized
INFO - 2018-02-26 16:50:16 --> Security Class Initialized
DEBUG - 2018-02-26 16:50:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-26 16:50:16 --> Input Class Initialized
INFO - 2018-02-26 16:50:16 --> Language Class Initialized
INFO - 2018-02-26 16:50:16 --> Loader Class Initialized
INFO - 2018-02-26 16:50:16 --> Helper loaded: url_helper
INFO - 2018-02-26 16:50:16 --> Helper loaded: file_helper
INFO - 2018-02-26 16:50:16 --> Helper loaded: email_helper
INFO - 2018-02-26 16:50:16 --> Helper loaded: common_helper
INFO - 2018-02-26 16:50:16 --> Database Driver Class Initialized
DEBUG - 2018-02-26 16:50:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-26 16:50:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-26 16:50:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-26 16:50:16 --> Pagination Class Initialized
INFO - 2018-02-26 16:50:16 --> Helper loaded: form_helper
INFO - 2018-02-26 16:50:16 --> Form Validation Class Initialized
INFO - 2018-02-26 16:50:16 --> Model Class Initialized
INFO - 2018-02-26 16:50:16 --> Controller Class Initialized
INFO - 2018-02-26 16:50:16 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-26 16:50:16 --> Model Class Initialized
INFO - 2018-02-26 16:50:16 --> Config Class Initialized
INFO - 2018-02-26 16:50:16 --> Hooks Class Initialized
DEBUG - 2018-02-26 16:50:16 --> UTF-8 Support Enabled
INFO - 2018-02-26 16:50:16 --> Utf8 Class Initialized
INFO - 2018-02-26 16:50:16 --> URI Class Initialized
INFO - 2018-02-26 16:50:16 --> Router Class Initialized
INFO - 2018-02-26 16:50:16 --> Output Class Initialized
INFO - 2018-02-26 16:50:16 --> Security Class Initialized
DEBUG - 2018-02-26 16:50:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-26 16:50:16 --> Input Class Initialized
INFO - 2018-02-26 16:50:16 --> Language Class Initialized
INFO - 2018-02-26 16:50:16 --> Loader Class Initialized
INFO - 2018-02-26 16:50:16 --> Helper loaded: url_helper
INFO - 2018-02-26 16:50:16 --> Helper loaded: file_helper
INFO - 2018-02-26 16:50:16 --> Helper loaded: email_helper
INFO - 2018-02-26 16:50:16 --> Helper loaded: common_helper
INFO - 2018-02-26 16:50:16 --> Database Driver Class Initialized
DEBUG - 2018-02-26 16:50:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-26 16:50:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-26 16:50:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-26 16:50:16 --> Pagination Class Initialized
INFO - 2018-02-26 16:50:16 --> Helper loaded: form_helper
INFO - 2018-02-26 16:50:16 --> Form Validation Class Initialized
INFO - 2018-02-26 16:50:16 --> Model Class Initialized
INFO - 2018-02-26 16:50:16 --> Controller Class Initialized
INFO - 2018-02-26 16:50:16 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-26 16:50:16 --> Model Class Initialized
DEBUG - 2018-02-26 16:50:16 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-26 16:50:16 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-02-26 16:50:16 --> Config Class Initialized
INFO - 2018-02-26 16:50:16 --> Hooks Class Initialized
DEBUG - 2018-02-26 16:50:16 --> UTF-8 Support Enabled
INFO - 2018-02-26 16:50:16 --> Utf8 Class Initialized
INFO - 2018-02-26 16:50:16 --> URI Class Initialized
INFO - 2018-02-26 16:50:16 --> Router Class Initialized
INFO - 2018-02-26 16:50:16 --> Output Class Initialized
INFO - 2018-02-26 16:50:16 --> Security Class Initialized
DEBUG - 2018-02-26 16:50:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-26 16:50:16 --> Input Class Initialized
INFO - 2018-02-26 16:50:16 --> Language Class Initialized
INFO - 2018-02-26 16:50:16 --> Loader Class Initialized
INFO - 2018-02-26 16:50:16 --> Helper loaded: url_helper
INFO - 2018-02-26 16:50:16 --> Helper loaded: file_helper
INFO - 2018-02-26 16:50:16 --> Helper loaded: email_helper
INFO - 2018-02-26 16:50:16 --> Helper loaded: common_helper
INFO - 2018-02-26 16:50:16 --> Database Driver Class Initialized
DEBUG - 2018-02-26 16:50:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-26 16:50:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-26 16:50:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-26 16:50:16 --> Pagination Class Initialized
INFO - 2018-02-26 16:50:16 --> Helper loaded: form_helper
INFO - 2018-02-26 16:50:16 --> Form Validation Class Initialized
INFO - 2018-02-26 16:50:16 --> Model Class Initialized
INFO - 2018-02-26 16:50:16 --> Controller Class Initialized
INFO - 2018-02-26 16:50:16 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-26 16:50:16 --> Model Class Initialized
INFO - 2018-02-26 16:50:16 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-26 16:50:16 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-26 16:50:16 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-26 16:50:16 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-26 16:50:16 --> File loaded: /var/www/html/project/radio/application/views/category/index.php
INFO - 2018-02-26 16:50:16 --> Final output sent to browser
DEBUG - 2018-02-26 16:50:16 --> Total execution time: 0.0068
INFO - 2018-02-26 16:50:31 --> Config Class Initialized
INFO - 2018-02-26 16:50:31 --> Hooks Class Initialized
DEBUG - 2018-02-26 16:50:31 --> UTF-8 Support Enabled
INFO - 2018-02-26 16:50:31 --> Utf8 Class Initialized
INFO - 2018-02-26 16:50:31 --> URI Class Initialized
INFO - 2018-02-26 16:50:31 --> Router Class Initialized
INFO - 2018-02-26 16:50:31 --> Output Class Initialized
INFO - 2018-02-26 16:50:31 --> Security Class Initialized
DEBUG - 2018-02-26 16:50:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-26 16:50:31 --> Input Class Initialized
INFO - 2018-02-26 16:50:31 --> Language Class Initialized
INFO - 2018-02-26 16:50:31 --> Loader Class Initialized
INFO - 2018-02-26 16:50:31 --> Helper loaded: url_helper
INFO - 2018-02-26 16:50:31 --> Helper loaded: file_helper
INFO - 2018-02-26 16:50:31 --> Helper loaded: email_helper
INFO - 2018-02-26 16:50:31 --> Helper loaded: common_helper
INFO - 2018-02-26 16:50:31 --> Database Driver Class Initialized
DEBUG - 2018-02-26 16:50:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-26 16:50:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-26 16:50:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-26 16:50:31 --> Pagination Class Initialized
INFO - 2018-02-26 16:50:31 --> Helper loaded: form_helper
INFO - 2018-02-26 16:50:31 --> Form Validation Class Initialized
INFO - 2018-02-26 16:50:31 --> Model Class Initialized
INFO - 2018-02-26 16:50:31 --> Controller Class Initialized
INFO - 2018-02-26 16:50:31 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-26 16:50:31 --> Model Class Initialized
INFO - 2018-02-26 16:50:31 --> Model Class Initialized
INFO - 2018-02-26 16:50:31 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-26 16:50:31 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-26 16:50:31 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-26 16:50:31 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-26 16:50:31 --> File loaded: /var/www/html/project/radio/application/views/subcategory/index.php
INFO - 2018-02-26 16:50:31 --> Final output sent to browser
DEBUG - 2018-02-26 16:50:31 --> Total execution time: 0.0081
INFO - 2018-02-26 16:50:34 --> Config Class Initialized
INFO - 2018-02-26 16:50:34 --> Hooks Class Initialized
DEBUG - 2018-02-26 16:50:34 --> UTF-8 Support Enabled
INFO - 2018-02-26 16:50:34 --> Utf8 Class Initialized
INFO - 2018-02-26 16:50:34 --> URI Class Initialized
INFO - 2018-02-26 16:50:34 --> Router Class Initialized
INFO - 2018-02-26 16:50:34 --> Output Class Initialized
INFO - 2018-02-26 16:50:34 --> Security Class Initialized
DEBUG - 2018-02-26 16:50:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-26 16:50:34 --> Input Class Initialized
INFO - 2018-02-26 16:50:34 --> Language Class Initialized
INFO - 2018-02-26 16:50:34 --> Loader Class Initialized
INFO - 2018-02-26 16:50:34 --> Helper loaded: url_helper
INFO - 2018-02-26 16:50:34 --> Helper loaded: file_helper
INFO - 2018-02-26 16:50:34 --> Helper loaded: email_helper
INFO - 2018-02-26 16:50:34 --> Helper loaded: common_helper
INFO - 2018-02-26 16:50:34 --> Database Driver Class Initialized
DEBUG - 2018-02-26 16:50:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-26 16:50:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-26 16:50:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-26 16:50:34 --> Pagination Class Initialized
INFO - 2018-02-26 16:50:34 --> Helper loaded: form_helper
INFO - 2018-02-26 16:50:34 --> Form Validation Class Initialized
INFO - 2018-02-26 16:50:34 --> Model Class Initialized
INFO - 2018-02-26 16:50:34 --> Controller Class Initialized
INFO - 2018-02-26 16:50:34 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-26 16:50:34 --> Model Class Initialized
INFO - 2018-02-26 16:50:34 --> Model Class Initialized
INFO - 2018-02-26 16:50:34 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-26 16:50:34 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-26 16:50:34 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-26 16:50:34 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-26 16:50:34 --> File loaded: /var/www/html/project/radio/application/views/subcategory/add_edit.php
INFO - 2018-02-26 16:50:34 --> Final output sent to browser
DEBUG - 2018-02-26 16:50:34 --> Total execution time: 0.0058
INFO - 2018-02-26 16:50:42 --> Config Class Initialized
INFO - 2018-02-26 16:50:42 --> Hooks Class Initialized
DEBUG - 2018-02-26 16:50:42 --> UTF-8 Support Enabled
INFO - 2018-02-26 16:50:42 --> Utf8 Class Initialized
INFO - 2018-02-26 16:50:42 --> URI Class Initialized
INFO - 2018-02-26 16:50:42 --> Router Class Initialized
INFO - 2018-02-26 16:50:42 --> Output Class Initialized
INFO - 2018-02-26 16:50:42 --> Security Class Initialized
DEBUG - 2018-02-26 16:50:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-26 16:50:42 --> Input Class Initialized
INFO - 2018-02-26 16:50:42 --> Language Class Initialized
INFO - 2018-02-26 16:50:42 --> Loader Class Initialized
INFO - 2018-02-26 16:50:42 --> Helper loaded: url_helper
INFO - 2018-02-26 16:50:42 --> Helper loaded: file_helper
INFO - 2018-02-26 16:50:42 --> Helper loaded: email_helper
INFO - 2018-02-26 16:50:42 --> Helper loaded: common_helper
INFO - 2018-02-26 16:50:42 --> Database Driver Class Initialized
DEBUG - 2018-02-26 16:50:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-26 16:50:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-26 16:50:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-26 16:50:42 --> Pagination Class Initialized
INFO - 2018-02-26 16:50:42 --> Helper loaded: form_helper
INFO - 2018-02-26 16:50:42 --> Form Validation Class Initialized
INFO - 2018-02-26 16:50:42 --> Model Class Initialized
INFO - 2018-02-26 16:50:42 --> Controller Class Initialized
INFO - 2018-02-26 16:50:42 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-26 16:50:42 --> Model Class Initialized
INFO - 2018-02-26 16:50:42 --> Model Class Initialized
INFO - 2018-02-26 16:50:42 --> Config Class Initialized
INFO - 2018-02-26 16:50:42 --> Hooks Class Initialized
DEBUG - 2018-02-26 16:50:42 --> UTF-8 Support Enabled
INFO - 2018-02-26 16:50:42 --> Utf8 Class Initialized
INFO - 2018-02-26 16:50:42 --> URI Class Initialized
INFO - 2018-02-26 16:50:42 --> Router Class Initialized
INFO - 2018-02-26 16:50:42 --> Output Class Initialized
INFO - 2018-02-26 16:50:42 --> Security Class Initialized
DEBUG - 2018-02-26 16:50:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-26 16:50:42 --> Input Class Initialized
INFO - 2018-02-26 16:50:42 --> Language Class Initialized
INFO - 2018-02-26 16:50:42 --> Loader Class Initialized
INFO - 2018-02-26 16:50:42 --> Helper loaded: url_helper
INFO - 2018-02-26 16:50:42 --> Helper loaded: file_helper
INFO - 2018-02-26 16:50:42 --> Helper loaded: email_helper
INFO - 2018-02-26 16:50:42 --> Helper loaded: common_helper
INFO - 2018-02-26 16:50:42 --> Database Driver Class Initialized
DEBUG - 2018-02-26 16:50:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-26 16:50:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-26 16:50:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-26 16:50:42 --> Pagination Class Initialized
INFO - 2018-02-26 16:50:42 --> Helper loaded: form_helper
INFO - 2018-02-26 16:50:42 --> Form Validation Class Initialized
INFO - 2018-02-26 16:50:42 --> Model Class Initialized
INFO - 2018-02-26 16:50:42 --> Controller Class Initialized
INFO - 2018-02-26 16:50:42 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-26 16:50:42 --> Model Class Initialized
INFO - 2018-02-26 16:50:42 --> Model Class Initialized
DEBUG - 2018-02-26 16:50:42 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-26 16:50:42 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-02-26 16:50:42 --> Config Class Initialized
INFO - 2018-02-26 16:50:42 --> Hooks Class Initialized
DEBUG - 2018-02-26 16:50:42 --> UTF-8 Support Enabled
INFO - 2018-02-26 16:50:42 --> Utf8 Class Initialized
INFO - 2018-02-26 16:50:42 --> URI Class Initialized
INFO - 2018-02-26 16:50:42 --> Router Class Initialized
INFO - 2018-02-26 16:50:42 --> Output Class Initialized
INFO - 2018-02-26 16:50:42 --> Security Class Initialized
DEBUG - 2018-02-26 16:50:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-26 16:50:42 --> Input Class Initialized
INFO - 2018-02-26 16:50:42 --> Language Class Initialized
INFO - 2018-02-26 16:50:42 --> Loader Class Initialized
INFO - 2018-02-26 16:50:42 --> Helper loaded: url_helper
INFO - 2018-02-26 16:50:42 --> Helper loaded: file_helper
INFO - 2018-02-26 16:50:42 --> Helper loaded: email_helper
INFO - 2018-02-26 16:50:42 --> Helper loaded: common_helper
INFO - 2018-02-26 16:50:42 --> Database Driver Class Initialized
DEBUG - 2018-02-26 16:50:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-26 16:50:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-26 16:50:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-26 16:50:42 --> Pagination Class Initialized
INFO - 2018-02-26 16:50:42 --> Helper loaded: form_helper
INFO - 2018-02-26 16:50:42 --> Form Validation Class Initialized
INFO - 2018-02-26 16:50:42 --> Model Class Initialized
INFO - 2018-02-26 16:50:42 --> Controller Class Initialized
INFO - 2018-02-26 16:50:42 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-26 16:50:42 --> Model Class Initialized
INFO - 2018-02-26 16:50:42 --> Model Class Initialized
INFO - 2018-02-26 16:50:42 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-26 16:50:42 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-26 16:50:42 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-26 16:50:42 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-26 16:50:42 --> File loaded: /var/www/html/project/radio/application/views/subcategory/index.php
INFO - 2018-02-26 16:50:42 --> Final output sent to browser
DEBUG - 2018-02-26 16:50:42 --> Total execution time: 0.0070
INFO - 2018-02-26 16:50:58 --> Config Class Initialized
INFO - 2018-02-26 16:50:58 --> Hooks Class Initialized
DEBUG - 2018-02-26 16:50:58 --> UTF-8 Support Enabled
INFO - 2018-02-26 16:50:58 --> Utf8 Class Initialized
INFO - 2018-02-26 16:50:58 --> URI Class Initialized
INFO - 2018-02-26 16:50:58 --> Router Class Initialized
INFO - 2018-02-26 16:50:58 --> Output Class Initialized
INFO - 2018-02-26 16:50:58 --> Security Class Initialized
DEBUG - 2018-02-26 16:50:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-26 16:50:58 --> Input Class Initialized
INFO - 2018-02-26 16:50:58 --> Language Class Initialized
INFO - 2018-02-26 16:50:58 --> Loader Class Initialized
INFO - 2018-02-26 16:50:58 --> Helper loaded: url_helper
INFO - 2018-02-26 16:50:58 --> Helper loaded: file_helper
INFO - 2018-02-26 16:50:58 --> Helper loaded: email_helper
INFO - 2018-02-26 16:50:58 --> Helper loaded: common_helper
INFO - 2018-02-26 16:50:58 --> Database Driver Class Initialized
DEBUG - 2018-02-26 16:50:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-26 16:50:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-26 16:50:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-26 16:50:58 --> Pagination Class Initialized
INFO - 2018-02-26 16:50:58 --> Helper loaded: form_helper
INFO - 2018-02-26 16:50:58 --> Form Validation Class Initialized
INFO - 2018-02-26 16:50:58 --> Model Class Initialized
INFO - 2018-02-26 16:50:58 --> Controller Class Initialized
INFO - 2018-02-26 16:50:58 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-26 16:50:58 --> Model Class Initialized
INFO - 2018-02-26 16:50:58 --> Model Class Initialized
INFO - 2018-02-26 16:50:58 --> Config Class Initialized
INFO - 2018-02-26 16:50:58 --> Hooks Class Initialized
DEBUG - 2018-02-26 16:50:58 --> UTF-8 Support Enabled
INFO - 2018-02-26 16:50:58 --> Utf8 Class Initialized
INFO - 2018-02-26 16:50:58 --> URI Class Initialized
INFO - 2018-02-26 16:50:58 --> Router Class Initialized
INFO - 2018-02-26 16:50:58 --> Output Class Initialized
INFO - 2018-02-26 16:50:58 --> Security Class Initialized
DEBUG - 2018-02-26 16:50:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-26 16:50:58 --> Input Class Initialized
INFO - 2018-02-26 16:50:58 --> Language Class Initialized
INFO - 2018-02-26 16:50:58 --> Loader Class Initialized
INFO - 2018-02-26 16:50:58 --> Helper loaded: url_helper
INFO - 2018-02-26 16:50:58 --> Helper loaded: file_helper
INFO - 2018-02-26 16:50:58 --> Helper loaded: email_helper
INFO - 2018-02-26 16:50:58 --> Helper loaded: common_helper
INFO - 2018-02-26 16:50:58 --> Database Driver Class Initialized
DEBUG - 2018-02-26 16:50:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-26 16:50:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-26 16:50:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-26 16:50:58 --> Pagination Class Initialized
INFO - 2018-02-26 16:50:58 --> Helper loaded: form_helper
INFO - 2018-02-26 16:50:58 --> Form Validation Class Initialized
INFO - 2018-02-26 16:50:58 --> Model Class Initialized
INFO - 2018-02-26 16:50:58 --> Controller Class Initialized
INFO - 2018-02-26 16:50:58 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-26 16:50:58 --> Model Class Initialized
INFO - 2018-02-26 16:50:58 --> Model Class Initialized
INFO - 2018-02-26 16:50:58 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-26 16:50:58 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-26 16:50:58 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-26 16:50:58 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-26 16:50:58 --> File loaded: /var/www/html/project/radio/application/views/subcategory/index.php
INFO - 2018-02-26 16:50:58 --> Final output sent to browser
DEBUG - 2018-02-26 16:50:58 --> Total execution time: 0.0060
INFO - 2018-02-26 16:51:00 --> Config Class Initialized
INFO - 2018-02-26 16:51:00 --> Hooks Class Initialized
DEBUG - 2018-02-26 16:51:00 --> UTF-8 Support Enabled
INFO - 2018-02-26 16:51:00 --> Utf8 Class Initialized
INFO - 2018-02-26 16:51:00 --> URI Class Initialized
INFO - 2018-02-26 16:51:00 --> Router Class Initialized
INFO - 2018-02-26 16:51:00 --> Output Class Initialized
INFO - 2018-02-26 16:51:00 --> Security Class Initialized
DEBUG - 2018-02-26 16:51:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-26 16:51:00 --> Input Class Initialized
INFO - 2018-02-26 16:51:00 --> Language Class Initialized
INFO - 2018-02-26 16:51:00 --> Loader Class Initialized
INFO - 2018-02-26 16:51:00 --> Helper loaded: url_helper
INFO - 2018-02-26 16:51:00 --> Helper loaded: file_helper
INFO - 2018-02-26 16:51:00 --> Helper loaded: email_helper
INFO - 2018-02-26 16:51:00 --> Helper loaded: common_helper
INFO - 2018-02-26 16:51:00 --> Database Driver Class Initialized
DEBUG - 2018-02-26 16:51:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-26 16:51:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-26 16:51:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-26 16:51:00 --> Pagination Class Initialized
INFO - 2018-02-26 16:51:00 --> Helper loaded: form_helper
INFO - 2018-02-26 16:51:00 --> Form Validation Class Initialized
INFO - 2018-02-26 16:51:00 --> Model Class Initialized
INFO - 2018-02-26 16:51:00 --> Controller Class Initialized
INFO - 2018-02-26 16:51:00 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-26 16:51:00 --> Model Class Initialized
INFO - 2018-02-26 16:51:00 --> Model Class Initialized
INFO - 2018-02-26 16:51:01 --> Config Class Initialized
INFO - 2018-02-26 16:51:01 --> Hooks Class Initialized
DEBUG - 2018-02-26 16:51:01 --> UTF-8 Support Enabled
INFO - 2018-02-26 16:51:01 --> Utf8 Class Initialized
INFO - 2018-02-26 16:51:01 --> URI Class Initialized
INFO - 2018-02-26 16:51:01 --> Router Class Initialized
INFO - 2018-02-26 16:51:01 --> Output Class Initialized
INFO - 2018-02-26 16:51:01 --> Security Class Initialized
DEBUG - 2018-02-26 16:51:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-26 16:51:01 --> Input Class Initialized
INFO - 2018-02-26 16:51:01 --> Language Class Initialized
INFO - 2018-02-26 16:51:01 --> Loader Class Initialized
INFO - 2018-02-26 16:51:01 --> Helper loaded: url_helper
INFO - 2018-02-26 16:51:01 --> Helper loaded: file_helper
INFO - 2018-02-26 16:51:01 --> Helper loaded: email_helper
INFO - 2018-02-26 16:51:01 --> Helper loaded: common_helper
INFO - 2018-02-26 16:51:01 --> Database Driver Class Initialized
DEBUG - 2018-02-26 16:51:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-26 16:51:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-26 16:51:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-26 16:51:01 --> Pagination Class Initialized
INFO - 2018-02-26 16:51:01 --> Helper loaded: form_helper
INFO - 2018-02-26 16:51:01 --> Form Validation Class Initialized
INFO - 2018-02-26 16:51:01 --> Model Class Initialized
INFO - 2018-02-26 16:51:01 --> Controller Class Initialized
INFO - 2018-02-26 16:51:01 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-26 16:51:01 --> Model Class Initialized
INFO - 2018-02-26 16:51:01 --> Model Class Initialized
INFO - 2018-02-26 16:51:01 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-26 16:51:01 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-26 16:51:01 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-26 16:51:01 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-26 16:51:01 --> File loaded: /var/www/html/project/radio/application/views/subcategory/index.php
INFO - 2018-02-26 16:51:01 --> Final output sent to browser
DEBUG - 2018-02-26 16:51:01 --> Total execution time: 0.0061
INFO - 2018-02-26 16:51:16 --> Config Class Initialized
INFO - 2018-02-26 16:51:16 --> Hooks Class Initialized
DEBUG - 2018-02-26 16:51:16 --> UTF-8 Support Enabled
INFO - 2018-02-26 16:51:16 --> Utf8 Class Initialized
INFO - 2018-02-26 16:51:16 --> URI Class Initialized
INFO - 2018-02-26 16:51:16 --> Router Class Initialized
INFO - 2018-02-26 16:51:16 --> Output Class Initialized
INFO - 2018-02-26 16:51:16 --> Security Class Initialized
DEBUG - 2018-02-26 16:51:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-26 16:51:16 --> Input Class Initialized
INFO - 2018-02-26 16:51:16 --> Language Class Initialized
INFO - 2018-02-26 16:51:16 --> Loader Class Initialized
INFO - 2018-02-26 16:51:16 --> Helper loaded: url_helper
INFO - 2018-02-26 16:51:16 --> Helper loaded: file_helper
INFO - 2018-02-26 16:51:16 --> Helper loaded: email_helper
INFO - 2018-02-26 16:51:16 --> Helper loaded: common_helper
INFO - 2018-02-26 16:51:16 --> Database Driver Class Initialized
DEBUG - 2018-02-26 16:51:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-26 16:51:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-26 16:51:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-26 16:51:16 --> Pagination Class Initialized
INFO - 2018-02-26 16:51:16 --> Helper loaded: form_helper
INFO - 2018-02-26 16:51:16 --> Form Validation Class Initialized
INFO - 2018-02-26 16:51:16 --> Model Class Initialized
INFO - 2018-02-26 16:51:16 --> Controller Class Initialized
INFO - 2018-02-26 16:51:16 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-26 16:51:16 --> Model Class Initialized
INFO - 2018-02-26 16:51:16 --> Model Class Initialized
INFO - 2018-02-26 16:51:16 --> Config Class Initialized
INFO - 2018-02-26 16:51:16 --> Hooks Class Initialized
DEBUG - 2018-02-26 16:51:16 --> UTF-8 Support Enabled
INFO - 2018-02-26 16:51:16 --> Utf8 Class Initialized
INFO - 2018-02-26 16:51:16 --> URI Class Initialized
INFO - 2018-02-26 16:51:16 --> Router Class Initialized
INFO - 2018-02-26 16:51:16 --> Output Class Initialized
INFO - 2018-02-26 16:51:16 --> Security Class Initialized
DEBUG - 2018-02-26 16:51:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-26 16:51:16 --> Input Class Initialized
INFO - 2018-02-26 16:51:16 --> Language Class Initialized
INFO - 2018-02-26 16:51:16 --> Loader Class Initialized
INFO - 2018-02-26 16:51:16 --> Helper loaded: url_helper
INFO - 2018-02-26 16:51:16 --> Helper loaded: file_helper
INFO - 2018-02-26 16:51:16 --> Helper loaded: email_helper
INFO - 2018-02-26 16:51:16 --> Helper loaded: common_helper
INFO - 2018-02-26 16:51:16 --> Database Driver Class Initialized
DEBUG - 2018-02-26 16:51:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-26 16:51:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-26 16:51:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-26 16:51:16 --> Pagination Class Initialized
INFO - 2018-02-26 16:51:16 --> Helper loaded: form_helper
INFO - 2018-02-26 16:51:16 --> Form Validation Class Initialized
INFO - 2018-02-26 16:51:16 --> Model Class Initialized
INFO - 2018-02-26 16:51:16 --> Controller Class Initialized
INFO - 2018-02-26 16:51:16 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-26 16:51:16 --> Model Class Initialized
INFO - 2018-02-26 16:51:16 --> Model Class Initialized
INFO - 2018-02-26 16:51:16 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-26 16:51:16 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-26 16:51:16 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-26 16:51:16 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-26 16:51:16 --> File loaded: /var/www/html/project/radio/application/views/subcategory/index.php
INFO - 2018-02-26 16:51:16 --> Final output sent to browser
DEBUG - 2018-02-26 16:51:16 --> Total execution time: 0.0065
INFO - 2018-02-26 16:51:26 --> Config Class Initialized
INFO - 2018-02-26 16:51:26 --> Hooks Class Initialized
DEBUG - 2018-02-26 16:51:26 --> UTF-8 Support Enabled
INFO - 2018-02-26 16:51:26 --> Utf8 Class Initialized
INFO - 2018-02-26 16:51:26 --> URI Class Initialized
INFO - 2018-02-26 16:51:26 --> Router Class Initialized
INFO - 2018-02-26 16:51:26 --> Output Class Initialized
INFO - 2018-02-26 16:51:26 --> Security Class Initialized
DEBUG - 2018-02-26 16:51:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-26 16:51:26 --> Input Class Initialized
INFO - 2018-02-26 16:51:26 --> Language Class Initialized
INFO - 2018-02-26 16:51:26 --> Loader Class Initialized
INFO - 2018-02-26 16:51:26 --> Helper loaded: url_helper
INFO - 2018-02-26 16:51:26 --> Helper loaded: file_helper
INFO - 2018-02-26 16:51:26 --> Helper loaded: email_helper
INFO - 2018-02-26 16:51:26 --> Helper loaded: common_helper
INFO - 2018-02-26 16:51:26 --> Database Driver Class Initialized
DEBUG - 2018-02-26 16:51:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-26 16:51:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-26 16:51:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-26 16:51:26 --> Pagination Class Initialized
INFO - 2018-02-26 16:51:26 --> Helper loaded: form_helper
INFO - 2018-02-26 16:51:26 --> Form Validation Class Initialized
INFO - 2018-02-26 16:51:26 --> Model Class Initialized
INFO - 2018-02-26 16:51:26 --> Controller Class Initialized
INFO - 2018-02-26 16:51:26 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-26 16:51:26 --> Model Class Initialized
INFO - 2018-02-26 16:51:26 --> Model Class Initialized
INFO - 2018-02-26 16:51:26 --> Config Class Initialized
INFO - 2018-02-26 16:51:26 --> Hooks Class Initialized
DEBUG - 2018-02-26 16:51:26 --> UTF-8 Support Enabled
INFO - 2018-02-26 16:51:26 --> Utf8 Class Initialized
INFO - 2018-02-26 16:51:26 --> URI Class Initialized
INFO - 2018-02-26 16:51:26 --> Router Class Initialized
INFO - 2018-02-26 16:51:26 --> Output Class Initialized
INFO - 2018-02-26 16:51:26 --> Security Class Initialized
DEBUG - 2018-02-26 16:51:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-26 16:51:26 --> Input Class Initialized
INFO - 2018-02-26 16:51:26 --> Language Class Initialized
INFO - 2018-02-26 16:51:26 --> Loader Class Initialized
INFO - 2018-02-26 16:51:26 --> Helper loaded: url_helper
INFO - 2018-02-26 16:51:26 --> Helper loaded: file_helper
INFO - 2018-02-26 16:51:26 --> Helper loaded: email_helper
INFO - 2018-02-26 16:51:26 --> Helper loaded: common_helper
INFO - 2018-02-26 16:51:26 --> Database Driver Class Initialized
DEBUG - 2018-02-26 16:51:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-26 16:51:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-26 16:51:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-26 16:51:26 --> Pagination Class Initialized
INFO - 2018-02-26 16:51:26 --> Helper loaded: form_helper
INFO - 2018-02-26 16:51:26 --> Form Validation Class Initialized
INFO - 2018-02-26 16:51:26 --> Model Class Initialized
INFO - 2018-02-26 16:51:26 --> Controller Class Initialized
INFO - 2018-02-26 16:51:26 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-26 16:51:26 --> Model Class Initialized
INFO - 2018-02-26 16:51:26 --> Model Class Initialized
INFO - 2018-02-26 16:51:26 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-26 16:51:26 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-26 16:51:26 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-26 16:51:26 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-26 16:51:26 --> File loaded: /var/www/html/project/radio/application/views/subcategory/index.php
INFO - 2018-02-26 16:51:26 --> Final output sent to browser
DEBUG - 2018-02-26 16:51:26 --> Total execution time: 0.0052
INFO - 2018-02-26 16:52:28 --> Config Class Initialized
INFO - 2018-02-26 16:52:28 --> Hooks Class Initialized
DEBUG - 2018-02-26 16:52:28 --> UTF-8 Support Enabled
INFO - 2018-02-26 16:52:28 --> Utf8 Class Initialized
INFO - 2018-02-26 16:52:28 --> URI Class Initialized
INFO - 2018-02-26 16:52:28 --> Router Class Initialized
INFO - 2018-02-26 16:52:28 --> Output Class Initialized
INFO - 2018-02-26 16:52:28 --> Security Class Initialized
DEBUG - 2018-02-26 16:52:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-26 16:52:28 --> Input Class Initialized
INFO - 2018-02-26 16:52:28 --> Language Class Initialized
INFO - 2018-02-26 16:52:28 --> Loader Class Initialized
INFO - 2018-02-26 16:52:28 --> Helper loaded: url_helper
INFO - 2018-02-26 16:52:28 --> Helper loaded: file_helper
INFO - 2018-02-26 16:52:28 --> Helper loaded: email_helper
INFO - 2018-02-26 16:52:28 --> Helper loaded: common_helper
INFO - 2018-02-26 16:52:28 --> Database Driver Class Initialized
DEBUG - 2018-02-26 16:52:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-26 16:52:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-26 16:52:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-26 16:52:28 --> Pagination Class Initialized
INFO - 2018-02-26 16:52:28 --> Helper loaded: form_helper
INFO - 2018-02-26 16:52:28 --> Form Validation Class Initialized
INFO - 2018-02-26 16:52:28 --> Model Class Initialized
INFO - 2018-02-26 16:52:28 --> Controller Class Initialized
INFO - 2018-02-26 16:52:28 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-26 16:52:28 --> Model Class Initialized
INFO - 2018-02-26 16:52:28 --> Model Class Initialized
INFO - 2018-02-26 16:52:28 --> Config Class Initialized
INFO - 2018-02-26 16:52:28 --> Hooks Class Initialized
DEBUG - 2018-02-26 16:52:28 --> UTF-8 Support Enabled
INFO - 2018-02-26 16:52:28 --> Utf8 Class Initialized
INFO - 2018-02-26 16:52:28 --> URI Class Initialized
INFO - 2018-02-26 16:52:28 --> Router Class Initialized
INFO - 2018-02-26 16:52:28 --> Output Class Initialized
INFO - 2018-02-26 16:52:28 --> Security Class Initialized
DEBUG - 2018-02-26 16:52:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-26 16:52:28 --> Input Class Initialized
INFO - 2018-02-26 16:52:28 --> Language Class Initialized
INFO - 2018-02-26 16:52:28 --> Loader Class Initialized
INFO - 2018-02-26 16:52:28 --> Helper loaded: url_helper
INFO - 2018-02-26 16:52:28 --> Helper loaded: file_helper
INFO - 2018-02-26 16:52:28 --> Helper loaded: email_helper
INFO - 2018-02-26 16:52:28 --> Helper loaded: common_helper
INFO - 2018-02-26 16:52:28 --> Database Driver Class Initialized
DEBUG - 2018-02-26 16:52:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-26 16:52:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-26 16:52:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-26 16:52:28 --> Pagination Class Initialized
INFO - 2018-02-26 16:52:28 --> Helper loaded: form_helper
INFO - 2018-02-26 16:52:28 --> Form Validation Class Initialized
INFO - 2018-02-26 16:52:28 --> Model Class Initialized
INFO - 2018-02-26 16:52:28 --> Controller Class Initialized
INFO - 2018-02-26 16:52:28 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-26 16:52:28 --> Model Class Initialized
INFO - 2018-02-26 16:52:28 --> Model Class Initialized
INFO - 2018-02-26 16:52:28 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-26 16:52:28 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-26 16:52:28 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-26 16:52:28 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-26 16:52:28 --> File loaded: /var/www/html/project/radio/application/views/subcategory/index.php
INFO - 2018-02-26 16:52:28 --> Final output sent to browser
DEBUG - 2018-02-26 16:52:28 --> Total execution time: 0.0059
INFO - 2018-02-26 16:52:38 --> Config Class Initialized
INFO - 2018-02-26 16:52:38 --> Hooks Class Initialized
DEBUG - 2018-02-26 16:52:38 --> UTF-8 Support Enabled
INFO - 2018-02-26 16:52:38 --> Utf8 Class Initialized
INFO - 2018-02-26 16:52:38 --> URI Class Initialized
INFO - 2018-02-26 16:52:38 --> Router Class Initialized
INFO - 2018-02-26 16:52:38 --> Output Class Initialized
INFO - 2018-02-26 16:52:38 --> Security Class Initialized
DEBUG - 2018-02-26 16:52:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-26 16:52:38 --> Input Class Initialized
INFO - 2018-02-26 16:52:38 --> Language Class Initialized
INFO - 2018-02-26 16:52:38 --> Loader Class Initialized
INFO - 2018-02-26 16:52:38 --> Helper loaded: url_helper
INFO - 2018-02-26 16:52:38 --> Helper loaded: file_helper
INFO - 2018-02-26 16:52:38 --> Helper loaded: email_helper
INFO - 2018-02-26 16:52:38 --> Helper loaded: common_helper
INFO - 2018-02-26 16:52:38 --> Database Driver Class Initialized
DEBUG - 2018-02-26 16:52:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-26 16:52:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-26 16:52:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-26 16:52:38 --> Pagination Class Initialized
INFO - 2018-02-26 16:52:38 --> Helper loaded: form_helper
INFO - 2018-02-26 16:52:38 --> Form Validation Class Initialized
INFO - 2018-02-26 16:52:38 --> Model Class Initialized
INFO - 2018-02-26 16:52:38 --> Controller Class Initialized
INFO - 2018-02-26 16:52:38 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-26 16:52:38 --> Model Class Initialized
INFO - 2018-02-26 16:52:38 --> Model Class Initialized
INFO - 2018-02-26 16:52:38 --> Config Class Initialized
INFO - 2018-02-26 16:52:38 --> Hooks Class Initialized
DEBUG - 2018-02-26 16:52:38 --> UTF-8 Support Enabled
INFO - 2018-02-26 16:52:38 --> Utf8 Class Initialized
INFO - 2018-02-26 16:52:38 --> URI Class Initialized
INFO - 2018-02-26 16:52:38 --> Router Class Initialized
INFO - 2018-02-26 16:52:38 --> Output Class Initialized
INFO - 2018-02-26 16:52:38 --> Security Class Initialized
DEBUG - 2018-02-26 16:52:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-26 16:52:38 --> Input Class Initialized
INFO - 2018-02-26 16:52:38 --> Language Class Initialized
INFO - 2018-02-26 16:52:38 --> Loader Class Initialized
INFO - 2018-02-26 16:52:38 --> Helper loaded: url_helper
INFO - 2018-02-26 16:52:38 --> Helper loaded: file_helper
INFO - 2018-02-26 16:52:38 --> Helper loaded: email_helper
INFO - 2018-02-26 16:52:38 --> Helper loaded: common_helper
INFO - 2018-02-26 16:52:38 --> Database Driver Class Initialized
DEBUG - 2018-02-26 16:52:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-26 16:52:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-26 16:52:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-26 16:52:38 --> Pagination Class Initialized
INFO - 2018-02-26 16:52:38 --> Helper loaded: form_helper
INFO - 2018-02-26 16:52:38 --> Form Validation Class Initialized
INFO - 2018-02-26 16:52:38 --> Model Class Initialized
INFO - 2018-02-26 16:52:38 --> Controller Class Initialized
INFO - 2018-02-26 16:52:38 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-26 16:52:38 --> Model Class Initialized
INFO - 2018-02-26 16:52:38 --> Model Class Initialized
INFO - 2018-02-26 16:52:38 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-26 16:52:38 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-26 16:52:38 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-26 16:52:38 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-26 16:52:38 --> File loaded: /var/www/html/project/radio/application/views/subcategory/index.php
INFO - 2018-02-26 16:52:38 --> Final output sent to browser
DEBUG - 2018-02-26 16:52:38 --> Total execution time: 0.0053
INFO - 2018-02-26 16:52:48 --> Config Class Initialized
INFO - 2018-02-26 16:52:48 --> Hooks Class Initialized
DEBUG - 2018-02-26 16:52:48 --> UTF-8 Support Enabled
INFO - 2018-02-26 16:52:48 --> Utf8 Class Initialized
INFO - 2018-02-26 16:52:48 --> URI Class Initialized
INFO - 2018-02-26 16:52:48 --> Router Class Initialized
INFO - 2018-02-26 16:52:48 --> Output Class Initialized
INFO - 2018-02-26 16:52:48 --> Security Class Initialized
DEBUG - 2018-02-26 16:52:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-26 16:52:48 --> Input Class Initialized
INFO - 2018-02-26 16:52:48 --> Language Class Initialized
INFO - 2018-02-26 16:52:48 --> Loader Class Initialized
INFO - 2018-02-26 16:52:48 --> Helper loaded: url_helper
INFO - 2018-02-26 16:52:48 --> Helper loaded: file_helper
INFO - 2018-02-26 16:52:48 --> Helper loaded: email_helper
INFO - 2018-02-26 16:52:48 --> Helper loaded: common_helper
INFO - 2018-02-26 16:52:48 --> Database Driver Class Initialized
DEBUG - 2018-02-26 16:52:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-26 16:52:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-26 16:52:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-26 16:52:48 --> Pagination Class Initialized
INFO - 2018-02-26 16:52:48 --> Helper loaded: form_helper
INFO - 2018-02-26 16:52:48 --> Form Validation Class Initialized
INFO - 2018-02-26 16:52:48 --> Model Class Initialized
INFO - 2018-02-26 16:52:48 --> Controller Class Initialized
INFO - 2018-02-26 16:52:48 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-26 16:52:48 --> Model Class Initialized
INFO - 2018-02-26 16:52:48 --> Model Class Initialized
INFO - 2018-02-26 16:52:48 --> Config Class Initialized
INFO - 2018-02-26 16:52:48 --> Hooks Class Initialized
DEBUG - 2018-02-26 16:52:48 --> UTF-8 Support Enabled
INFO - 2018-02-26 16:52:48 --> Utf8 Class Initialized
INFO - 2018-02-26 16:52:48 --> URI Class Initialized
INFO - 2018-02-26 16:52:48 --> Router Class Initialized
INFO - 2018-02-26 16:52:48 --> Output Class Initialized
INFO - 2018-02-26 16:52:48 --> Security Class Initialized
DEBUG - 2018-02-26 16:52:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-26 16:52:48 --> Input Class Initialized
INFO - 2018-02-26 16:52:48 --> Language Class Initialized
INFO - 2018-02-26 16:52:48 --> Loader Class Initialized
INFO - 2018-02-26 16:52:48 --> Helper loaded: url_helper
INFO - 2018-02-26 16:52:48 --> Helper loaded: file_helper
INFO - 2018-02-26 16:52:48 --> Helper loaded: email_helper
INFO - 2018-02-26 16:52:48 --> Helper loaded: common_helper
INFO - 2018-02-26 16:52:48 --> Database Driver Class Initialized
DEBUG - 2018-02-26 16:52:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-26 16:52:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-26 16:52:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-26 16:52:48 --> Pagination Class Initialized
INFO - 2018-02-26 16:52:48 --> Helper loaded: form_helper
INFO - 2018-02-26 16:52:48 --> Form Validation Class Initialized
INFO - 2018-02-26 16:52:48 --> Model Class Initialized
INFO - 2018-02-26 16:52:48 --> Controller Class Initialized
INFO - 2018-02-26 16:52:48 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-26 16:52:48 --> Model Class Initialized
INFO - 2018-02-26 16:52:48 --> Model Class Initialized
INFO - 2018-02-26 16:52:48 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-26 16:52:48 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-26 16:52:48 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-26 16:52:48 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-26 16:52:48 --> File loaded: /var/www/html/project/radio/application/views/subcategory/index.php
INFO - 2018-02-26 16:52:48 --> Final output sent to browser
DEBUG - 2018-02-26 16:52:48 --> Total execution time: 0.0063
INFO - 2018-02-26 16:54:29 --> Config Class Initialized
INFO - 2018-02-26 16:54:29 --> Hooks Class Initialized
DEBUG - 2018-02-26 16:54:29 --> UTF-8 Support Enabled
INFO - 2018-02-26 16:54:29 --> Utf8 Class Initialized
INFO - 2018-02-26 16:54:29 --> URI Class Initialized
INFO - 2018-02-26 16:54:29 --> Router Class Initialized
INFO - 2018-02-26 16:54:29 --> Output Class Initialized
INFO - 2018-02-26 16:54:29 --> Security Class Initialized
DEBUG - 2018-02-26 16:54:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-26 16:54:29 --> Input Class Initialized
INFO - 2018-02-26 16:54:29 --> Language Class Initialized
INFO - 2018-02-26 16:54:29 --> Loader Class Initialized
INFO - 2018-02-26 16:54:29 --> Helper loaded: url_helper
INFO - 2018-02-26 16:54:29 --> Helper loaded: file_helper
INFO - 2018-02-26 16:54:29 --> Helper loaded: email_helper
INFO - 2018-02-26 16:54:29 --> Helper loaded: common_helper
INFO - 2018-02-26 16:54:29 --> Database Driver Class Initialized
DEBUG - 2018-02-26 16:54:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-26 16:54:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-26 16:54:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-26 16:54:29 --> Pagination Class Initialized
INFO - 2018-02-26 16:54:29 --> Helper loaded: form_helper
INFO - 2018-02-26 16:54:29 --> Form Validation Class Initialized
INFO - 2018-02-26 16:54:29 --> Model Class Initialized
INFO - 2018-02-26 16:54:29 --> Controller Class Initialized
INFO - 2018-02-26 16:54:29 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-26 16:54:29 --> Model Class Initialized
INFO - 2018-02-26 16:54:29 --> Model Class Initialized
INFO - 2018-02-26 16:54:29 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-26 16:54:29 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-26 16:54:29 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-26 16:54:29 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-26 16:54:29 --> File loaded: /var/www/html/project/radio/application/views/subcategory/add_edit.php
INFO - 2018-02-26 16:54:29 --> Final output sent to browser
DEBUG - 2018-02-26 16:54:29 --> Total execution time: 0.0065
INFO - 2018-02-26 16:54:30 --> Config Class Initialized
INFO - 2018-02-26 16:54:30 --> Hooks Class Initialized
DEBUG - 2018-02-26 16:54:30 --> UTF-8 Support Enabled
INFO - 2018-02-26 16:54:30 --> Utf8 Class Initialized
INFO - 2018-02-26 16:54:30 --> URI Class Initialized
INFO - 2018-02-26 16:54:30 --> Router Class Initialized
INFO - 2018-02-26 16:54:30 --> Output Class Initialized
INFO - 2018-02-26 16:54:30 --> Security Class Initialized
DEBUG - 2018-02-26 16:54:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-26 16:54:30 --> Input Class Initialized
INFO - 2018-02-26 16:54:30 --> Language Class Initialized
INFO - 2018-02-26 16:54:30 --> Loader Class Initialized
INFO - 2018-02-26 16:54:30 --> Helper loaded: url_helper
INFO - 2018-02-26 16:54:30 --> Helper loaded: file_helper
INFO - 2018-02-26 16:54:30 --> Helper loaded: email_helper
INFO - 2018-02-26 16:54:30 --> Helper loaded: common_helper
INFO - 2018-02-26 16:54:30 --> Database Driver Class Initialized
DEBUG - 2018-02-26 16:54:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-26 16:54:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-26 16:54:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-26 16:54:30 --> Pagination Class Initialized
INFO - 2018-02-26 16:54:30 --> Helper loaded: form_helper
INFO - 2018-02-26 16:54:30 --> Form Validation Class Initialized
INFO - 2018-02-26 16:54:30 --> Model Class Initialized
INFO - 2018-02-26 16:54:30 --> Controller Class Initialized
INFO - 2018-02-26 16:54:30 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-26 16:54:30 --> Model Class Initialized
INFO - 2018-02-26 16:54:30 --> Model Class Initialized
INFO - 2018-02-26 16:54:30 --> Model Class Initialized
INFO - 2018-02-26 16:54:30 --> Model Class Initialized
INFO - 2018-02-26 16:54:30 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-26 16:54:30 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-26 16:54:30 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-26 16:54:30 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-26 16:54:30 --> File loaded: /var/www/html/project/radio/application/views/tracks/index.php
INFO - 2018-02-26 16:54:30 --> Final output sent to browser
DEBUG - 2018-02-26 16:54:30 --> Total execution time: 0.0073
INFO - 2018-02-26 16:54:31 --> Config Class Initialized
INFO - 2018-02-26 16:54:31 --> Hooks Class Initialized
DEBUG - 2018-02-26 16:54:31 --> UTF-8 Support Enabled
INFO - 2018-02-26 16:54:31 --> Utf8 Class Initialized
INFO - 2018-02-26 16:54:31 --> URI Class Initialized
INFO - 2018-02-26 16:54:31 --> Router Class Initialized
INFO - 2018-02-26 16:54:31 --> Output Class Initialized
INFO - 2018-02-26 16:54:31 --> Security Class Initialized
DEBUG - 2018-02-26 16:54:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-26 16:54:31 --> Input Class Initialized
INFO - 2018-02-26 16:54:31 --> Language Class Initialized
INFO - 2018-02-26 16:54:31 --> Loader Class Initialized
INFO - 2018-02-26 16:54:31 --> Helper loaded: url_helper
INFO - 2018-02-26 16:54:31 --> Helper loaded: file_helper
INFO - 2018-02-26 16:54:31 --> Helper loaded: email_helper
INFO - 2018-02-26 16:54:31 --> Helper loaded: common_helper
INFO - 2018-02-26 16:54:31 --> Database Driver Class Initialized
DEBUG - 2018-02-26 16:54:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-26 16:54:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-26 16:54:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-26 16:54:31 --> Pagination Class Initialized
INFO - 2018-02-26 16:54:31 --> Helper loaded: form_helper
INFO - 2018-02-26 16:54:31 --> Form Validation Class Initialized
INFO - 2018-02-26 16:54:31 --> Model Class Initialized
INFO - 2018-02-26 16:54:31 --> Controller Class Initialized
INFO - 2018-02-26 16:54:31 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-26 16:54:31 --> Model Class Initialized
INFO - 2018-02-26 16:54:31 --> Model Class Initialized
INFO - 2018-02-26 16:54:31 --> Model Class Initialized
INFO - 2018-02-26 16:54:31 --> Model Class Initialized
INFO - 2018-02-26 16:54:33 --> Config Class Initialized
INFO - 2018-02-26 16:54:33 --> Hooks Class Initialized
DEBUG - 2018-02-26 16:54:33 --> UTF-8 Support Enabled
INFO - 2018-02-26 16:54:33 --> Utf8 Class Initialized
INFO - 2018-02-26 16:54:33 --> URI Class Initialized
INFO - 2018-02-26 16:54:33 --> Router Class Initialized
INFO - 2018-02-26 16:54:33 --> Output Class Initialized
INFO - 2018-02-26 16:54:33 --> Security Class Initialized
DEBUG - 2018-02-26 16:54:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-26 16:54:33 --> Input Class Initialized
INFO - 2018-02-26 16:54:33 --> Language Class Initialized
INFO - 2018-02-26 16:54:33 --> Loader Class Initialized
INFO - 2018-02-26 16:54:33 --> Helper loaded: url_helper
INFO - 2018-02-26 16:54:33 --> Helper loaded: file_helper
INFO - 2018-02-26 16:54:33 --> Helper loaded: email_helper
INFO - 2018-02-26 16:54:33 --> Helper loaded: common_helper
INFO - 2018-02-26 16:54:33 --> Database Driver Class Initialized
DEBUG - 2018-02-26 16:54:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-26 16:54:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-26 16:54:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-26 16:54:33 --> Pagination Class Initialized
INFO - 2018-02-26 16:54:33 --> Helper loaded: form_helper
INFO - 2018-02-26 16:54:33 --> Form Validation Class Initialized
INFO - 2018-02-26 16:54:33 --> Model Class Initialized
INFO - 2018-02-26 16:54:33 --> Controller Class Initialized
INFO - 2018-02-26 16:54:33 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-26 16:54:33 --> Model Class Initialized
INFO - 2018-02-26 16:54:33 --> Model Class Initialized
INFO - 2018-02-26 16:54:33 --> Model Class Initialized
INFO - 2018-02-26 16:54:33 --> Model Class Initialized
INFO - 2018-02-26 16:54:33 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-26 16:54:33 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-26 16:54:33 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-26 16:54:33 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-26 16:54:33 --> File loaded: /var/www/html/project/radio/application/views/tracks/add_edit.php
INFO - 2018-02-26 16:54:33 --> Final output sent to browser
DEBUG - 2018-02-26 16:54:33 --> Total execution time: 0.0102
INFO - 2018-02-26 16:54:35 --> Config Class Initialized
INFO - 2018-02-26 16:54:35 --> Hooks Class Initialized
DEBUG - 2018-02-26 16:54:35 --> UTF-8 Support Enabled
INFO - 2018-02-26 16:54:35 --> Utf8 Class Initialized
INFO - 2018-02-26 16:54:35 --> URI Class Initialized
INFO - 2018-02-26 16:54:35 --> Router Class Initialized
INFO - 2018-02-26 16:54:35 --> Output Class Initialized
INFO - 2018-02-26 16:54:35 --> Security Class Initialized
DEBUG - 2018-02-26 16:54:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-26 16:54:35 --> Input Class Initialized
INFO - 2018-02-26 16:54:35 --> Language Class Initialized
INFO - 2018-02-26 16:54:35 --> Loader Class Initialized
INFO - 2018-02-26 16:54:35 --> Helper loaded: url_helper
INFO - 2018-02-26 16:54:35 --> Helper loaded: file_helper
INFO - 2018-02-26 16:54:35 --> Helper loaded: email_helper
INFO - 2018-02-26 16:54:35 --> Helper loaded: common_helper
INFO - 2018-02-26 16:54:35 --> Database Driver Class Initialized
DEBUG - 2018-02-26 16:54:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-26 16:54:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-26 16:54:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-26 16:54:35 --> Pagination Class Initialized
INFO - 2018-02-26 16:54:35 --> Helper loaded: form_helper
INFO - 2018-02-26 16:54:35 --> Form Validation Class Initialized
INFO - 2018-02-26 16:54:35 --> Model Class Initialized
INFO - 2018-02-26 16:54:35 --> Controller Class Initialized
INFO - 2018-02-26 16:54:35 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-26 16:54:35 --> Model Class Initialized
INFO - 2018-02-26 16:54:35 --> Model Class Initialized
INFO - 2018-02-26 16:54:35 --> Model Class Initialized
INFO - 2018-02-26 16:54:35 --> Model Class Initialized
INFO - 2018-02-26 16:55:10 --> Config Class Initialized
INFO - 2018-02-26 16:55:10 --> Hooks Class Initialized
DEBUG - 2018-02-26 16:55:10 --> UTF-8 Support Enabled
INFO - 2018-02-26 16:55:10 --> Utf8 Class Initialized
INFO - 2018-02-26 16:55:10 --> URI Class Initialized
INFO - 2018-02-26 16:55:10 --> Router Class Initialized
INFO - 2018-02-26 16:55:10 --> Output Class Initialized
INFO - 2018-02-26 16:55:10 --> Security Class Initialized
DEBUG - 2018-02-26 16:55:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-26 16:55:10 --> Input Class Initialized
INFO - 2018-02-26 16:55:10 --> Language Class Initialized
INFO - 2018-02-26 16:55:10 --> Loader Class Initialized
INFO - 2018-02-26 16:55:10 --> Helper loaded: url_helper
INFO - 2018-02-26 16:55:10 --> Helper loaded: file_helper
INFO - 2018-02-26 16:55:10 --> Helper loaded: email_helper
INFO - 2018-02-26 16:55:10 --> Helper loaded: common_helper
INFO - 2018-02-26 16:55:10 --> Database Driver Class Initialized
DEBUG - 2018-02-26 16:55:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-26 16:55:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-26 16:55:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-26 16:55:10 --> Pagination Class Initialized
INFO - 2018-02-26 16:55:10 --> Helper loaded: form_helper
INFO - 2018-02-26 16:55:10 --> Form Validation Class Initialized
INFO - 2018-02-26 16:55:10 --> Model Class Initialized
INFO - 2018-02-26 16:55:10 --> Controller Class Initialized
INFO - 2018-02-26 16:55:10 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-26 16:55:10 --> Model Class Initialized
INFO - 2018-02-26 16:55:10 --> Model Class Initialized
INFO - 2018-02-26 16:55:10 --> Model Class Initialized
INFO - 2018-02-26 16:55:10 --> Model Class Initialized
DEBUG - 2018-02-26 16:55:10 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-26 16:55:10 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-02-26 16:55:10 --> Config Class Initialized
INFO - 2018-02-26 16:55:10 --> Hooks Class Initialized
DEBUG - 2018-02-26 16:55:10 --> UTF-8 Support Enabled
INFO - 2018-02-26 16:55:10 --> Utf8 Class Initialized
INFO - 2018-02-26 16:55:10 --> URI Class Initialized
INFO - 2018-02-26 16:55:10 --> Router Class Initialized
INFO - 2018-02-26 16:55:10 --> Output Class Initialized
INFO - 2018-02-26 16:55:10 --> Security Class Initialized
DEBUG - 2018-02-26 16:55:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-26 16:55:10 --> Input Class Initialized
INFO - 2018-02-26 16:55:10 --> Language Class Initialized
INFO - 2018-02-26 16:55:10 --> Loader Class Initialized
INFO - 2018-02-26 16:55:10 --> Helper loaded: url_helper
INFO - 2018-02-26 16:55:10 --> Helper loaded: file_helper
INFO - 2018-02-26 16:55:10 --> Helper loaded: email_helper
INFO - 2018-02-26 16:55:10 --> Helper loaded: common_helper
INFO - 2018-02-26 16:55:10 --> Database Driver Class Initialized
DEBUG - 2018-02-26 16:55:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-26 16:55:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-26 16:55:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-26 16:55:10 --> Pagination Class Initialized
INFO - 2018-02-26 16:55:10 --> Helper loaded: form_helper
INFO - 2018-02-26 16:55:10 --> Form Validation Class Initialized
INFO - 2018-02-26 16:55:10 --> Model Class Initialized
INFO - 2018-02-26 16:55:10 --> Controller Class Initialized
INFO - 2018-02-26 16:55:10 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-26 16:55:10 --> Model Class Initialized
INFO - 2018-02-26 16:55:10 --> Model Class Initialized
INFO - 2018-02-26 16:55:10 --> Model Class Initialized
INFO - 2018-02-26 16:55:10 --> Model Class Initialized
INFO - 2018-02-26 16:55:10 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-26 16:55:10 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-26 16:55:10 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-26 16:55:10 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-26 16:55:10 --> File loaded: /var/www/html/project/radio/application/views/tracks/index.php
INFO - 2018-02-26 16:55:10 --> Final output sent to browser
DEBUG - 2018-02-26 16:55:10 --> Total execution time: 0.0038
INFO - 2018-02-26 16:55:11 --> Config Class Initialized
INFO - 2018-02-26 16:55:11 --> Hooks Class Initialized
DEBUG - 2018-02-26 16:55:11 --> UTF-8 Support Enabled
INFO - 2018-02-26 16:55:11 --> Utf8 Class Initialized
INFO - 2018-02-26 16:55:11 --> URI Class Initialized
INFO - 2018-02-26 16:55:11 --> Router Class Initialized
INFO - 2018-02-26 16:55:11 --> Output Class Initialized
INFO - 2018-02-26 16:55:11 --> Security Class Initialized
DEBUG - 2018-02-26 16:55:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-26 16:55:11 --> Input Class Initialized
INFO - 2018-02-26 16:55:11 --> Language Class Initialized
INFO - 2018-02-26 16:55:11 --> Loader Class Initialized
INFO - 2018-02-26 16:55:11 --> Helper loaded: url_helper
INFO - 2018-02-26 16:55:11 --> Helper loaded: file_helper
INFO - 2018-02-26 16:55:11 --> Helper loaded: email_helper
INFO - 2018-02-26 16:55:11 --> Helper loaded: common_helper
INFO - 2018-02-26 16:55:11 --> Database Driver Class Initialized
DEBUG - 2018-02-26 16:55:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-26 16:55:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-26 16:55:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-26 16:55:11 --> Pagination Class Initialized
INFO - 2018-02-26 16:55:11 --> Helper loaded: form_helper
INFO - 2018-02-26 16:55:11 --> Form Validation Class Initialized
INFO - 2018-02-26 16:55:11 --> Model Class Initialized
INFO - 2018-02-26 16:55:11 --> Controller Class Initialized
INFO - 2018-02-26 16:55:11 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-26 16:55:11 --> Model Class Initialized
INFO - 2018-02-26 16:55:11 --> Model Class Initialized
INFO - 2018-02-26 16:55:11 --> Model Class Initialized
INFO - 2018-02-26 16:55:11 --> Model Class Initialized
INFO - 2018-02-26 17:22:10 --> Config Class Initialized
INFO - 2018-02-26 17:22:10 --> Hooks Class Initialized
DEBUG - 2018-02-26 17:22:10 --> UTF-8 Support Enabled
INFO - 2018-02-26 17:22:10 --> Utf8 Class Initialized
INFO - 2018-02-26 17:22:10 --> URI Class Initialized
INFO - 2018-02-26 17:22:10 --> Router Class Initialized
INFO - 2018-02-26 17:22:10 --> Output Class Initialized
INFO - 2018-02-26 17:22:10 --> Security Class Initialized
DEBUG - 2018-02-26 17:22:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-26 17:22:10 --> Input Class Initialized
INFO - 2018-02-26 17:22:10 --> Language Class Initialized
INFO - 2018-02-26 17:22:10 --> Loader Class Initialized
INFO - 2018-02-26 17:22:10 --> Helper loaded: url_helper
INFO - 2018-02-26 17:22:10 --> Helper loaded: file_helper
INFO - 2018-02-26 17:22:10 --> Helper loaded: email_helper
INFO - 2018-02-26 17:22:10 --> Helper loaded: common_helper
INFO - 2018-02-26 17:22:10 --> Database Driver Class Initialized
DEBUG - 2018-02-26 17:22:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-26 17:22:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-26 17:22:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-26 17:22:10 --> Pagination Class Initialized
INFO - 2018-02-26 17:22:10 --> Helper loaded: form_helper
INFO - 2018-02-26 17:22:10 --> Form Validation Class Initialized
INFO - 2018-02-26 17:22:10 --> Model Class Initialized
INFO - 2018-02-26 17:22:10 --> Controller Class Initialized
INFO - 2018-02-26 17:22:10 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-26 17:22:10 --> Model Class Initialized
INFO - 2018-02-26 17:22:10 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-26 17:22:10 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-26 17:22:10 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-26 17:22:10 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-26 17:22:10 --> File loaded: /var/www/html/project/radio/application/views/category/index.php
INFO - 2018-02-26 17:22:10 --> Final output sent to browser
DEBUG - 2018-02-26 17:22:10 --> Total execution time: 0.0057
INFO - 2018-02-26 17:22:11 --> Config Class Initialized
INFO - 2018-02-26 17:22:11 --> Hooks Class Initialized
DEBUG - 2018-02-26 17:22:11 --> UTF-8 Support Enabled
INFO - 2018-02-26 17:22:11 --> Utf8 Class Initialized
INFO - 2018-02-26 17:22:11 --> URI Class Initialized
INFO - 2018-02-26 17:22:11 --> Router Class Initialized
INFO - 2018-02-26 17:22:11 --> Output Class Initialized
INFO - 2018-02-26 17:22:11 --> Security Class Initialized
DEBUG - 2018-02-26 17:22:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-26 17:22:11 --> Input Class Initialized
INFO - 2018-02-26 17:22:11 --> Language Class Initialized
INFO - 2018-02-26 17:22:11 --> Loader Class Initialized
INFO - 2018-02-26 17:22:11 --> Helper loaded: url_helper
INFO - 2018-02-26 17:22:11 --> Helper loaded: file_helper
INFO - 2018-02-26 17:22:11 --> Helper loaded: email_helper
INFO - 2018-02-26 17:22:11 --> Helper loaded: common_helper
INFO - 2018-02-26 17:22:11 --> Database Driver Class Initialized
DEBUG - 2018-02-26 17:22:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-26 17:22:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-26 17:22:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-26 17:22:11 --> Pagination Class Initialized
INFO - 2018-02-26 17:22:11 --> Helper loaded: form_helper
INFO - 2018-02-26 17:22:11 --> Form Validation Class Initialized
INFO - 2018-02-26 17:22:11 --> Model Class Initialized
INFO - 2018-02-26 17:22:11 --> Controller Class Initialized
INFO - 2018-02-26 17:22:11 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-26 17:22:11 --> Model Class Initialized
INFO - 2018-02-26 17:22:11 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-26 17:22:11 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-26 17:22:11 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-26 17:22:11 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-26 17:22:11 --> File loaded: /var/www/html/project/radio/application/views/category/add_edit.php
INFO - 2018-02-26 17:22:11 --> Final output sent to browser
DEBUG - 2018-02-26 17:22:11 --> Total execution time: 0.0041
INFO - 2018-02-26 17:22:19 --> Config Class Initialized
INFO - 2018-02-26 17:22:19 --> Hooks Class Initialized
DEBUG - 2018-02-26 17:22:19 --> UTF-8 Support Enabled
INFO - 2018-02-26 17:22:19 --> Utf8 Class Initialized
INFO - 2018-02-26 17:22:19 --> URI Class Initialized
INFO - 2018-02-26 17:22:19 --> Router Class Initialized
INFO - 2018-02-26 17:22:19 --> Output Class Initialized
INFO - 2018-02-26 17:22:19 --> Security Class Initialized
DEBUG - 2018-02-26 17:22:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-26 17:22:19 --> Input Class Initialized
INFO - 2018-02-26 17:22:19 --> Language Class Initialized
INFO - 2018-02-26 17:22:19 --> Loader Class Initialized
INFO - 2018-02-26 17:22:19 --> Helper loaded: url_helper
INFO - 2018-02-26 17:22:19 --> Helper loaded: file_helper
INFO - 2018-02-26 17:22:19 --> Helper loaded: email_helper
INFO - 2018-02-26 17:22:19 --> Helper loaded: common_helper
INFO - 2018-02-26 17:22:19 --> Database Driver Class Initialized
DEBUG - 2018-02-26 17:22:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-26 17:22:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-26 17:22:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-26 17:22:19 --> Pagination Class Initialized
INFO - 2018-02-26 17:22:19 --> Helper loaded: form_helper
INFO - 2018-02-26 17:22:19 --> Form Validation Class Initialized
INFO - 2018-02-26 17:22:19 --> Model Class Initialized
INFO - 2018-02-26 17:22:19 --> Controller Class Initialized
INFO - 2018-02-26 17:22:19 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-26 17:22:19 --> Model Class Initialized
INFO - 2018-02-26 17:22:19 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-26 17:22:19 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-26 17:22:19 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-26 17:22:19 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-26 17:22:19 --> File loaded: /var/www/html/project/radio/application/views/category/add_edit.php
INFO - 2018-02-26 17:22:19 --> Final output sent to browser
DEBUG - 2018-02-26 17:22:19 --> Total execution time: 0.0061
INFO - 2018-02-26 17:22:20 --> Config Class Initialized
INFO - 2018-02-26 17:22:20 --> Hooks Class Initialized
DEBUG - 2018-02-26 17:22:20 --> UTF-8 Support Enabled
INFO - 2018-02-26 17:22:20 --> Utf8 Class Initialized
INFO - 2018-02-26 17:22:20 --> URI Class Initialized
INFO - 2018-02-26 17:22:20 --> Router Class Initialized
INFO - 2018-02-26 17:22:20 --> Output Class Initialized
INFO - 2018-02-26 17:22:20 --> Security Class Initialized
DEBUG - 2018-02-26 17:22:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-26 17:22:20 --> Input Class Initialized
INFO - 2018-02-26 17:22:20 --> Language Class Initialized
INFO - 2018-02-26 17:22:20 --> Loader Class Initialized
INFO - 2018-02-26 17:22:20 --> Helper loaded: url_helper
INFO - 2018-02-26 17:22:20 --> Helper loaded: file_helper
INFO - 2018-02-26 17:22:20 --> Helper loaded: email_helper
INFO - 2018-02-26 17:22:20 --> Helper loaded: common_helper
INFO - 2018-02-26 17:22:20 --> Database Driver Class Initialized
DEBUG - 2018-02-26 17:22:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-26 17:22:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-26 17:22:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-26 17:22:20 --> Pagination Class Initialized
INFO - 2018-02-26 17:22:20 --> Helper loaded: form_helper
INFO - 2018-02-26 17:22:20 --> Form Validation Class Initialized
INFO - 2018-02-26 17:22:20 --> Model Class Initialized
INFO - 2018-02-26 17:22:20 --> Controller Class Initialized
INFO - 2018-02-26 17:22:20 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-26 17:22:20 --> Model Class Initialized
INFO - 2018-02-26 17:22:20 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-26 17:22:20 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-26 17:22:20 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-26 17:22:20 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-26 17:22:20 --> File loaded: /var/www/html/project/radio/application/views/category/add_edit.php
INFO - 2018-02-26 17:22:20 --> Final output sent to browser
DEBUG - 2018-02-26 17:22:20 --> Total execution time: 0.0059
INFO - 2018-02-26 17:22:27 --> Config Class Initialized
INFO - 2018-02-26 17:22:27 --> Hooks Class Initialized
DEBUG - 2018-02-26 17:22:27 --> UTF-8 Support Enabled
INFO - 2018-02-26 17:22:27 --> Utf8 Class Initialized
INFO - 2018-02-26 17:22:27 --> URI Class Initialized
INFO - 2018-02-26 17:22:27 --> Router Class Initialized
INFO - 2018-02-26 17:22:27 --> Output Class Initialized
INFO - 2018-02-26 17:22:27 --> Security Class Initialized
DEBUG - 2018-02-26 17:22:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-26 17:22:27 --> Input Class Initialized
INFO - 2018-02-26 17:22:27 --> Language Class Initialized
INFO - 2018-02-26 17:22:27 --> Loader Class Initialized
INFO - 2018-02-26 17:22:27 --> Helper loaded: url_helper
INFO - 2018-02-26 17:22:27 --> Helper loaded: file_helper
INFO - 2018-02-26 17:22:27 --> Helper loaded: email_helper
INFO - 2018-02-26 17:22:27 --> Helper loaded: common_helper
INFO - 2018-02-26 17:22:27 --> Database Driver Class Initialized
DEBUG - 2018-02-26 17:22:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-26 17:22:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-26 17:22:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-26 17:22:27 --> Pagination Class Initialized
INFO - 2018-02-26 17:22:27 --> Helper loaded: form_helper
INFO - 2018-02-26 17:22:27 --> Form Validation Class Initialized
INFO - 2018-02-26 17:22:27 --> Model Class Initialized
INFO - 2018-02-26 17:22:27 --> Controller Class Initialized
INFO - 2018-02-26 17:22:27 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-26 17:22:27 --> Model Class Initialized
INFO - 2018-02-26 17:22:27 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-26 17:22:27 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-26 17:22:27 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-26 17:22:27 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-26 17:22:27 --> File loaded: /var/www/html/project/radio/application/views/category/add_edit.php
INFO - 2018-02-26 17:22:27 --> Final output sent to browser
DEBUG - 2018-02-26 17:22:27 --> Total execution time: 0.0068
INFO - 2018-02-26 17:23:00 --> Config Class Initialized
INFO - 2018-02-26 17:23:00 --> Hooks Class Initialized
DEBUG - 2018-02-26 17:23:00 --> UTF-8 Support Enabled
INFO - 2018-02-26 17:23:00 --> Utf8 Class Initialized
INFO - 2018-02-26 17:23:00 --> URI Class Initialized
INFO - 2018-02-26 17:23:00 --> Router Class Initialized
INFO - 2018-02-26 17:23:00 --> Output Class Initialized
INFO - 2018-02-26 17:23:00 --> Security Class Initialized
DEBUG - 2018-02-26 17:23:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-26 17:23:00 --> Input Class Initialized
INFO - 2018-02-26 17:23:00 --> Language Class Initialized
INFO - 2018-02-26 17:23:00 --> Loader Class Initialized
INFO - 2018-02-26 17:23:00 --> Helper loaded: url_helper
INFO - 2018-02-26 17:23:00 --> Helper loaded: file_helper
INFO - 2018-02-26 17:23:00 --> Helper loaded: email_helper
INFO - 2018-02-26 17:23:00 --> Helper loaded: common_helper
INFO - 2018-02-26 17:23:00 --> Database Driver Class Initialized
DEBUG - 2018-02-26 17:23:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-26 17:23:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-26 17:23:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-26 17:23:00 --> Pagination Class Initialized
INFO - 2018-02-26 17:23:00 --> Helper loaded: form_helper
INFO - 2018-02-26 17:23:00 --> Form Validation Class Initialized
INFO - 2018-02-26 17:23:00 --> Model Class Initialized
INFO - 2018-02-26 17:23:00 --> Controller Class Initialized
INFO - 2018-02-26 17:23:00 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-26 17:23:00 --> Model Class Initialized
INFO - 2018-02-26 17:23:00 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-26 17:23:00 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-26 17:23:00 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-26 17:23:00 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-26 17:23:00 --> File loaded: /var/www/html/project/radio/application/views/category/add_edit.php
INFO - 2018-02-26 17:23:00 --> Final output sent to browser
DEBUG - 2018-02-26 17:23:00 --> Total execution time: 0.0043
INFO - 2018-02-26 17:23:41 --> Config Class Initialized
INFO - 2018-02-26 17:23:41 --> Hooks Class Initialized
DEBUG - 2018-02-26 17:23:41 --> UTF-8 Support Enabled
INFO - 2018-02-26 17:23:41 --> Utf8 Class Initialized
INFO - 2018-02-26 17:23:41 --> URI Class Initialized
INFO - 2018-02-26 17:23:41 --> Router Class Initialized
INFO - 2018-02-26 17:23:41 --> Output Class Initialized
INFO - 2018-02-26 17:23:41 --> Security Class Initialized
DEBUG - 2018-02-26 17:23:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-26 17:23:41 --> Input Class Initialized
INFO - 2018-02-26 17:23:41 --> Language Class Initialized
INFO - 2018-02-26 17:23:41 --> Loader Class Initialized
INFO - 2018-02-26 17:23:41 --> Helper loaded: url_helper
INFO - 2018-02-26 17:23:41 --> Helper loaded: file_helper
INFO - 2018-02-26 17:23:41 --> Helper loaded: email_helper
INFO - 2018-02-26 17:23:41 --> Helper loaded: common_helper
INFO - 2018-02-26 17:23:41 --> Database Driver Class Initialized
DEBUG - 2018-02-26 17:23:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-26 17:23:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-26 17:23:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-26 17:23:41 --> Pagination Class Initialized
INFO - 2018-02-26 17:23:41 --> Helper loaded: form_helper
INFO - 2018-02-26 17:23:41 --> Form Validation Class Initialized
INFO - 2018-02-26 17:23:41 --> Model Class Initialized
INFO - 2018-02-26 17:23:41 --> Controller Class Initialized
INFO - 2018-02-26 17:23:41 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-26 17:23:41 --> Model Class Initialized
INFO - 2018-02-26 17:23:41 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-26 17:23:41 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-26 17:23:41 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-26 17:23:41 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-26 17:23:41 --> File loaded: /var/www/html/project/radio/application/views/category/add_edit.php
INFO - 2018-02-26 17:23:41 --> Final output sent to browser
DEBUG - 2018-02-26 17:23:41 --> Total execution time: 0.0048
INFO - 2018-02-26 17:25:11 --> Config Class Initialized
INFO - 2018-02-26 17:25:11 --> Hooks Class Initialized
DEBUG - 2018-02-26 17:25:11 --> UTF-8 Support Enabled
INFO - 2018-02-26 17:25:11 --> Utf8 Class Initialized
INFO - 2018-02-26 17:25:11 --> URI Class Initialized
INFO - 2018-02-26 17:25:11 --> Router Class Initialized
INFO - 2018-02-26 17:25:11 --> Output Class Initialized
INFO - 2018-02-26 17:25:11 --> Security Class Initialized
DEBUG - 2018-02-26 17:25:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-26 17:25:11 --> Input Class Initialized
INFO - 2018-02-26 17:25:11 --> Language Class Initialized
INFO - 2018-02-26 17:25:11 --> Loader Class Initialized
INFO - 2018-02-26 17:25:11 --> Helper loaded: url_helper
INFO - 2018-02-26 17:25:11 --> Helper loaded: file_helper
INFO - 2018-02-26 17:25:11 --> Helper loaded: email_helper
INFO - 2018-02-26 17:25:11 --> Helper loaded: common_helper
INFO - 2018-02-26 17:25:11 --> Database Driver Class Initialized
DEBUG - 2018-02-26 17:25:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-26 17:25:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-26 17:25:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-26 17:25:11 --> Pagination Class Initialized
INFO - 2018-02-26 17:25:11 --> Helper loaded: form_helper
INFO - 2018-02-26 17:25:11 --> Form Validation Class Initialized
INFO - 2018-02-26 17:25:11 --> Model Class Initialized
INFO - 2018-02-26 17:25:11 --> Controller Class Initialized
INFO - 2018-02-26 17:25:11 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-26 17:25:11 --> Model Class Initialized
INFO - 2018-02-26 17:25:11 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-26 17:25:11 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-26 17:25:11 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-26 17:25:11 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-26 17:25:11 --> File loaded: /var/www/html/project/radio/application/views/category/add_edit.php
INFO - 2018-02-26 17:25:11 --> Final output sent to browser
DEBUG - 2018-02-26 17:25:11 --> Total execution time: 0.0068
INFO - 2018-02-26 17:25:58 --> Config Class Initialized
INFO - 2018-02-26 17:25:58 --> Hooks Class Initialized
DEBUG - 2018-02-26 17:25:58 --> UTF-8 Support Enabled
INFO - 2018-02-26 17:25:58 --> Utf8 Class Initialized
INFO - 2018-02-26 17:25:58 --> URI Class Initialized
INFO - 2018-02-26 17:25:58 --> Router Class Initialized
INFO - 2018-02-26 17:25:58 --> Output Class Initialized
INFO - 2018-02-26 17:25:58 --> Security Class Initialized
DEBUG - 2018-02-26 17:25:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-26 17:25:58 --> Input Class Initialized
INFO - 2018-02-26 17:25:58 --> Language Class Initialized
INFO - 2018-02-26 17:25:58 --> Loader Class Initialized
INFO - 2018-02-26 17:25:58 --> Helper loaded: url_helper
INFO - 2018-02-26 17:25:58 --> Helper loaded: file_helper
INFO - 2018-02-26 17:25:58 --> Helper loaded: email_helper
INFO - 2018-02-26 17:25:58 --> Helper loaded: common_helper
INFO - 2018-02-26 17:25:58 --> Database Driver Class Initialized
DEBUG - 2018-02-26 17:25:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-26 17:25:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-26 17:25:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-26 17:25:58 --> Pagination Class Initialized
INFO - 2018-02-26 17:25:58 --> Helper loaded: form_helper
INFO - 2018-02-26 17:25:58 --> Form Validation Class Initialized
INFO - 2018-02-26 17:25:58 --> Model Class Initialized
INFO - 2018-02-26 17:25:58 --> Controller Class Initialized
INFO - 2018-02-26 17:25:58 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-26 17:25:58 --> Model Class Initialized
INFO - 2018-02-26 17:25:58 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-26 17:25:58 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-26 17:25:58 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-26 17:25:58 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-26 17:25:58 --> File loaded: /var/www/html/project/radio/application/views/category/add_edit.php
INFO - 2018-02-26 17:25:58 --> Final output sent to browser
DEBUG - 2018-02-26 17:25:58 --> Total execution time: 0.0047
INFO - 2018-02-26 17:25:59 --> Config Class Initialized
INFO - 2018-02-26 17:25:59 --> Hooks Class Initialized
DEBUG - 2018-02-26 17:25:59 --> UTF-8 Support Enabled
INFO - 2018-02-26 17:25:59 --> Utf8 Class Initialized
INFO - 2018-02-26 17:25:59 --> URI Class Initialized
INFO - 2018-02-26 17:25:59 --> Router Class Initialized
INFO - 2018-02-26 17:25:59 --> Output Class Initialized
INFO - 2018-02-26 17:25:59 --> Security Class Initialized
DEBUG - 2018-02-26 17:25:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-26 17:25:59 --> Input Class Initialized
INFO - 2018-02-26 17:25:59 --> Language Class Initialized
INFO - 2018-02-26 17:25:59 --> Loader Class Initialized
INFO - 2018-02-26 17:25:59 --> Helper loaded: url_helper
INFO - 2018-02-26 17:25:59 --> Helper loaded: file_helper
INFO - 2018-02-26 17:25:59 --> Helper loaded: email_helper
INFO - 2018-02-26 17:25:59 --> Helper loaded: common_helper
INFO - 2018-02-26 17:25:59 --> Database Driver Class Initialized
DEBUG - 2018-02-26 17:25:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-26 17:25:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-26 17:25:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-26 17:25:59 --> Pagination Class Initialized
INFO - 2018-02-26 17:25:59 --> Helper loaded: form_helper
INFO - 2018-02-26 17:25:59 --> Form Validation Class Initialized
INFO - 2018-02-26 17:25:59 --> Model Class Initialized
INFO - 2018-02-26 17:25:59 --> Controller Class Initialized
INFO - 2018-02-26 17:25:59 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-26 17:25:59 --> Model Class Initialized
INFO - 2018-02-26 17:25:59 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-26 17:25:59 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-26 17:25:59 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-26 17:25:59 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-26 17:25:59 --> File loaded: /var/www/html/project/radio/application/views/category/add_edit.php
INFO - 2018-02-26 17:25:59 --> Final output sent to browser
DEBUG - 2018-02-26 17:25:59 --> Total execution time: 0.0047
INFO - 2018-02-26 17:26:05 --> Config Class Initialized
INFO - 2018-02-26 17:26:05 --> Hooks Class Initialized
DEBUG - 2018-02-26 17:26:05 --> UTF-8 Support Enabled
INFO - 2018-02-26 17:26:05 --> Utf8 Class Initialized
INFO - 2018-02-26 17:26:05 --> URI Class Initialized
INFO - 2018-02-26 17:26:05 --> Router Class Initialized
INFO - 2018-02-26 17:26:05 --> Output Class Initialized
INFO - 2018-02-26 17:26:05 --> Security Class Initialized
DEBUG - 2018-02-26 17:26:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-26 17:26:05 --> Input Class Initialized
INFO - 2018-02-26 17:26:05 --> Language Class Initialized
INFO - 2018-02-26 17:26:05 --> Loader Class Initialized
INFO - 2018-02-26 17:26:05 --> Helper loaded: url_helper
INFO - 2018-02-26 17:26:05 --> Helper loaded: file_helper
INFO - 2018-02-26 17:26:05 --> Helper loaded: email_helper
INFO - 2018-02-26 17:26:05 --> Helper loaded: common_helper
INFO - 2018-02-26 17:26:05 --> Database Driver Class Initialized
DEBUG - 2018-02-26 17:26:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-26 17:26:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-26 17:26:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-26 17:26:05 --> Pagination Class Initialized
INFO - 2018-02-26 17:26:05 --> Helper loaded: form_helper
INFO - 2018-02-26 17:26:05 --> Form Validation Class Initialized
INFO - 2018-02-26 17:26:05 --> Model Class Initialized
INFO - 2018-02-26 17:26:05 --> Controller Class Initialized
INFO - 2018-02-26 17:26:05 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-26 17:26:05 --> Model Class Initialized
INFO - 2018-02-26 17:26:05 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-26 17:26:05 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-26 17:26:05 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-26 17:26:05 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-26 17:26:05 --> File loaded: /var/www/html/project/radio/application/views/category/add_edit.php
INFO - 2018-02-26 17:26:05 --> Final output sent to browser
DEBUG - 2018-02-26 17:26:05 --> Total execution time: 0.0048
INFO - 2018-02-26 17:27:22 --> Config Class Initialized
INFO - 2018-02-26 17:27:22 --> Hooks Class Initialized
DEBUG - 2018-02-26 17:27:22 --> UTF-8 Support Enabled
INFO - 2018-02-26 17:27:22 --> Utf8 Class Initialized
INFO - 2018-02-26 17:27:22 --> URI Class Initialized
INFO - 2018-02-26 17:27:22 --> Router Class Initialized
INFO - 2018-02-26 17:27:22 --> Output Class Initialized
INFO - 2018-02-26 17:27:22 --> Security Class Initialized
DEBUG - 2018-02-26 17:27:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-26 17:27:22 --> Input Class Initialized
INFO - 2018-02-26 17:27:22 --> Language Class Initialized
INFO - 2018-02-26 17:27:22 --> Loader Class Initialized
INFO - 2018-02-26 17:27:22 --> Helper loaded: url_helper
INFO - 2018-02-26 17:27:22 --> Helper loaded: file_helper
INFO - 2018-02-26 17:27:22 --> Helper loaded: email_helper
INFO - 2018-02-26 17:27:22 --> Helper loaded: common_helper
INFO - 2018-02-26 17:27:22 --> Database Driver Class Initialized
DEBUG - 2018-02-26 17:27:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-26 17:27:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-26 17:27:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-26 17:27:22 --> Pagination Class Initialized
INFO - 2018-02-26 17:27:22 --> Helper loaded: form_helper
INFO - 2018-02-26 17:27:22 --> Form Validation Class Initialized
INFO - 2018-02-26 17:27:22 --> Model Class Initialized
INFO - 2018-02-26 17:27:22 --> Controller Class Initialized
INFO - 2018-02-26 17:27:22 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-26 17:27:22 --> Model Class Initialized
INFO - 2018-02-26 17:27:22 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-26 17:27:22 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-26 17:27:22 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-26 17:27:22 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-26 17:27:22 --> File loaded: /var/www/html/project/radio/application/views/category/add_edit.php
INFO - 2018-02-26 17:27:22 --> Final output sent to browser
DEBUG - 2018-02-26 17:27:22 --> Total execution time: 0.0059
INFO - 2018-02-26 17:34:26 --> Config Class Initialized
INFO - 2018-02-26 17:34:26 --> Hooks Class Initialized
DEBUG - 2018-02-26 17:34:26 --> UTF-8 Support Enabled
INFO - 2018-02-26 17:34:26 --> Utf8 Class Initialized
INFO - 2018-02-26 17:34:26 --> URI Class Initialized
INFO - 2018-02-26 17:34:26 --> Router Class Initialized
INFO - 2018-02-26 17:34:26 --> Output Class Initialized
INFO - 2018-02-26 17:34:26 --> Security Class Initialized
DEBUG - 2018-02-26 17:34:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-26 17:34:26 --> Input Class Initialized
INFO - 2018-02-26 17:34:26 --> Language Class Initialized
INFO - 2018-02-26 17:34:26 --> Loader Class Initialized
INFO - 2018-02-26 17:34:26 --> Helper loaded: url_helper
INFO - 2018-02-26 17:34:26 --> Helper loaded: file_helper
INFO - 2018-02-26 17:34:26 --> Helper loaded: email_helper
INFO - 2018-02-26 17:34:26 --> Helper loaded: common_helper
INFO - 2018-02-26 17:34:26 --> Database Driver Class Initialized
DEBUG - 2018-02-26 17:34:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-26 17:34:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-26 17:34:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-26 17:34:26 --> Pagination Class Initialized
INFO - 2018-02-26 17:34:26 --> Helper loaded: form_helper
INFO - 2018-02-26 17:34:26 --> Form Validation Class Initialized
INFO - 2018-02-26 17:34:26 --> Model Class Initialized
INFO - 2018-02-26 17:34:26 --> Controller Class Initialized
INFO - 2018-02-26 17:34:26 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-26 17:34:26 --> Model Class Initialized
INFO - 2018-02-26 17:34:26 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-26 17:34:26 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-26 17:34:26 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-26 17:34:26 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-26 17:34:26 --> File loaded: /var/www/html/project/radio/application/views/category/add_edit.php
INFO - 2018-02-26 17:34:26 --> Final output sent to browser
DEBUG - 2018-02-26 17:34:26 --> Total execution time: 0.0050
INFO - 2018-02-26 17:34:33 --> Config Class Initialized
INFO - 2018-02-26 17:34:33 --> Hooks Class Initialized
DEBUG - 2018-02-26 17:34:33 --> UTF-8 Support Enabled
INFO - 2018-02-26 17:34:33 --> Utf8 Class Initialized
INFO - 2018-02-26 17:34:33 --> URI Class Initialized
INFO - 2018-02-26 17:34:33 --> Router Class Initialized
INFO - 2018-02-26 17:34:33 --> Output Class Initialized
INFO - 2018-02-26 17:34:33 --> Security Class Initialized
DEBUG - 2018-02-26 17:34:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-26 17:34:33 --> Input Class Initialized
INFO - 2018-02-26 17:34:33 --> Language Class Initialized
INFO - 2018-02-26 17:34:33 --> Loader Class Initialized
INFO - 2018-02-26 17:34:33 --> Helper loaded: url_helper
INFO - 2018-02-26 17:34:33 --> Helper loaded: file_helper
INFO - 2018-02-26 17:34:33 --> Helper loaded: email_helper
INFO - 2018-02-26 17:34:33 --> Helper loaded: common_helper
INFO - 2018-02-26 17:34:33 --> Database Driver Class Initialized
DEBUG - 2018-02-26 17:34:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-26 17:34:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-26 17:34:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-26 17:34:33 --> Pagination Class Initialized
INFO - 2018-02-26 17:34:33 --> Helper loaded: form_helper
INFO - 2018-02-26 17:34:33 --> Form Validation Class Initialized
INFO - 2018-02-26 17:34:33 --> Model Class Initialized
INFO - 2018-02-26 17:34:33 --> Controller Class Initialized
INFO - 2018-02-26 17:34:33 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-26 17:34:33 --> Model Class Initialized
INFO - 2018-02-26 17:34:33 --> Model Class Initialized
INFO - 2018-02-26 17:34:33 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-26 17:34:33 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-26 17:34:33 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-26 17:34:33 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-26 17:34:33 --> File loaded: /var/www/html/project/radio/application/views/subcategory/index.php
INFO - 2018-02-26 17:34:33 --> Final output sent to browser
DEBUG - 2018-02-26 17:34:33 --> Total execution time: 0.0066
INFO - 2018-02-26 17:34:35 --> Config Class Initialized
INFO - 2018-02-26 17:34:35 --> Hooks Class Initialized
DEBUG - 2018-02-26 17:34:35 --> UTF-8 Support Enabled
INFO - 2018-02-26 17:34:35 --> Utf8 Class Initialized
INFO - 2018-02-26 17:34:35 --> URI Class Initialized
INFO - 2018-02-26 17:34:35 --> Router Class Initialized
INFO - 2018-02-26 17:34:35 --> Output Class Initialized
INFO - 2018-02-26 17:34:35 --> Security Class Initialized
DEBUG - 2018-02-26 17:34:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-26 17:34:35 --> Input Class Initialized
INFO - 2018-02-26 17:34:35 --> Language Class Initialized
INFO - 2018-02-26 17:34:35 --> Loader Class Initialized
INFO - 2018-02-26 17:34:35 --> Helper loaded: url_helper
INFO - 2018-02-26 17:34:35 --> Helper loaded: file_helper
INFO - 2018-02-26 17:34:35 --> Helper loaded: email_helper
INFO - 2018-02-26 17:34:35 --> Helper loaded: common_helper
INFO - 2018-02-26 17:34:35 --> Database Driver Class Initialized
DEBUG - 2018-02-26 17:34:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-26 17:34:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-26 17:34:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-26 17:34:35 --> Pagination Class Initialized
INFO - 2018-02-26 17:34:35 --> Helper loaded: form_helper
INFO - 2018-02-26 17:34:35 --> Form Validation Class Initialized
INFO - 2018-02-26 17:34:35 --> Model Class Initialized
INFO - 2018-02-26 17:34:35 --> Controller Class Initialized
INFO - 2018-02-26 17:34:35 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-26 17:34:35 --> Model Class Initialized
INFO - 2018-02-26 17:34:35 --> Model Class Initialized
INFO - 2018-02-26 17:34:35 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-26 17:34:35 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-26 17:34:35 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-26 17:34:35 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-26 17:34:35 --> File loaded: /var/www/html/project/radio/application/views/subcategory/add_edit.php
INFO - 2018-02-26 17:34:35 --> Final output sent to browser
DEBUG - 2018-02-26 17:34:35 --> Total execution time: 0.0065
INFO - 2018-02-26 17:34:42 --> Config Class Initialized
INFO - 2018-02-26 17:34:42 --> Hooks Class Initialized
DEBUG - 2018-02-26 17:34:42 --> UTF-8 Support Enabled
INFO - 2018-02-26 17:34:42 --> Utf8 Class Initialized
INFO - 2018-02-26 17:34:42 --> URI Class Initialized
INFO - 2018-02-26 17:34:42 --> Router Class Initialized
INFO - 2018-02-26 17:34:42 --> Output Class Initialized
INFO - 2018-02-26 17:34:42 --> Security Class Initialized
DEBUG - 2018-02-26 17:34:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-26 17:34:42 --> Input Class Initialized
INFO - 2018-02-26 17:34:42 --> Language Class Initialized
INFO - 2018-02-26 17:34:42 --> Loader Class Initialized
INFO - 2018-02-26 17:34:42 --> Helper loaded: url_helper
INFO - 2018-02-26 17:34:42 --> Helper loaded: file_helper
INFO - 2018-02-26 17:34:42 --> Helper loaded: email_helper
INFO - 2018-02-26 17:34:42 --> Helper loaded: common_helper
INFO - 2018-02-26 17:34:42 --> Database Driver Class Initialized
DEBUG - 2018-02-26 17:34:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-26 17:34:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-26 17:34:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-26 17:34:42 --> Pagination Class Initialized
INFO - 2018-02-26 17:34:42 --> Helper loaded: form_helper
INFO - 2018-02-26 17:34:42 --> Form Validation Class Initialized
INFO - 2018-02-26 17:34:42 --> Model Class Initialized
INFO - 2018-02-26 17:34:42 --> Controller Class Initialized
INFO - 2018-02-26 17:34:42 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-26 17:34:42 --> Model Class Initialized
INFO - 2018-02-26 17:34:42 --> Model Class Initialized
INFO - 2018-02-26 17:34:42 --> Model Class Initialized
INFO - 2018-02-26 17:34:42 --> Model Class Initialized
INFO - 2018-02-26 17:34:42 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-26 17:34:42 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-26 17:34:42 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-26 17:34:42 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-26 17:34:42 --> File loaded: /var/www/html/project/radio/application/views/tracks/index.php
INFO - 2018-02-26 17:34:42 --> Final output sent to browser
DEBUG - 2018-02-26 17:34:42 --> Total execution time: 0.0096
INFO - 2018-02-26 17:34:42 --> Config Class Initialized
INFO - 2018-02-26 17:34:42 --> Hooks Class Initialized
DEBUG - 2018-02-26 17:34:42 --> UTF-8 Support Enabled
INFO - 2018-02-26 17:34:42 --> Utf8 Class Initialized
INFO - 2018-02-26 17:34:42 --> URI Class Initialized
INFO - 2018-02-26 17:34:42 --> Router Class Initialized
INFO - 2018-02-26 17:34:42 --> Output Class Initialized
INFO - 2018-02-26 17:34:42 --> Security Class Initialized
DEBUG - 2018-02-26 17:34:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-26 17:34:42 --> Input Class Initialized
INFO - 2018-02-26 17:34:42 --> Language Class Initialized
INFO - 2018-02-26 17:34:42 --> Loader Class Initialized
INFO - 2018-02-26 17:34:42 --> Helper loaded: url_helper
INFO - 2018-02-26 17:34:42 --> Helper loaded: file_helper
INFO - 2018-02-26 17:34:42 --> Helper loaded: email_helper
INFO - 2018-02-26 17:34:42 --> Helper loaded: common_helper
INFO - 2018-02-26 17:34:42 --> Database Driver Class Initialized
DEBUG - 2018-02-26 17:34:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-26 17:34:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-26 17:34:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-26 17:34:42 --> Pagination Class Initialized
INFO - 2018-02-26 17:34:42 --> Helper loaded: form_helper
INFO - 2018-02-26 17:34:42 --> Form Validation Class Initialized
INFO - 2018-02-26 17:34:42 --> Model Class Initialized
INFO - 2018-02-26 17:34:42 --> Controller Class Initialized
INFO - 2018-02-26 17:34:42 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-26 17:34:42 --> Model Class Initialized
INFO - 2018-02-26 17:34:42 --> Model Class Initialized
INFO - 2018-02-26 17:34:42 --> Model Class Initialized
INFO - 2018-02-26 17:34:42 --> Model Class Initialized
INFO - 2018-02-26 17:34:43 --> Config Class Initialized
INFO - 2018-02-26 17:34:43 --> Hooks Class Initialized
DEBUG - 2018-02-26 17:34:43 --> UTF-8 Support Enabled
INFO - 2018-02-26 17:34:43 --> Utf8 Class Initialized
INFO - 2018-02-26 17:34:43 --> URI Class Initialized
INFO - 2018-02-26 17:34:43 --> Router Class Initialized
INFO - 2018-02-26 17:34:43 --> Output Class Initialized
INFO - 2018-02-26 17:34:43 --> Security Class Initialized
DEBUG - 2018-02-26 17:34:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-26 17:34:43 --> Input Class Initialized
INFO - 2018-02-26 17:34:43 --> Language Class Initialized
INFO - 2018-02-26 17:34:43 --> Loader Class Initialized
INFO - 2018-02-26 17:34:43 --> Helper loaded: url_helper
INFO - 2018-02-26 17:34:43 --> Helper loaded: file_helper
INFO - 2018-02-26 17:34:43 --> Helper loaded: email_helper
INFO - 2018-02-26 17:34:43 --> Helper loaded: common_helper
INFO - 2018-02-26 17:34:43 --> Database Driver Class Initialized
DEBUG - 2018-02-26 17:34:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-26 17:34:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-26 17:34:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-26 17:34:43 --> Pagination Class Initialized
INFO - 2018-02-26 17:34:43 --> Helper loaded: form_helper
INFO - 2018-02-26 17:34:43 --> Form Validation Class Initialized
INFO - 2018-02-26 17:34:43 --> Model Class Initialized
INFO - 2018-02-26 17:34:43 --> Controller Class Initialized
INFO - 2018-02-26 17:34:43 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-26 17:34:43 --> Model Class Initialized
INFO - 2018-02-26 17:34:43 --> Model Class Initialized
INFO - 2018-02-26 17:34:43 --> Model Class Initialized
INFO - 2018-02-26 17:34:43 --> Model Class Initialized
INFO - 2018-02-26 17:34:43 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-26 17:34:43 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-26 17:34:43 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-26 17:34:43 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-26 17:34:43 --> File loaded: /var/www/html/project/radio/application/views/tracks/add_edit.php
INFO - 2018-02-26 17:34:43 --> Final output sent to browser
DEBUG - 2018-02-26 17:34:43 --> Total execution time: 0.0077
INFO - 2018-02-26 17:38:00 --> Config Class Initialized
INFO - 2018-02-26 17:38:00 --> Hooks Class Initialized
DEBUG - 2018-02-26 17:38:00 --> UTF-8 Support Enabled
INFO - 2018-02-26 17:38:00 --> Utf8 Class Initialized
INFO - 2018-02-26 17:38:00 --> URI Class Initialized
INFO - 2018-02-26 17:38:00 --> Router Class Initialized
INFO - 2018-02-26 17:38:00 --> Output Class Initialized
INFO - 2018-02-26 17:38:00 --> Security Class Initialized
DEBUG - 2018-02-26 17:38:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-26 17:38:00 --> Input Class Initialized
INFO - 2018-02-26 17:38:00 --> Language Class Initialized
INFO - 2018-02-26 17:38:00 --> Loader Class Initialized
INFO - 2018-02-26 17:38:00 --> Helper loaded: url_helper
INFO - 2018-02-26 17:38:00 --> Helper loaded: file_helper
INFO - 2018-02-26 17:38:00 --> Helper loaded: email_helper
INFO - 2018-02-26 17:38:00 --> Helper loaded: common_helper
INFO - 2018-02-26 17:38:00 --> Database Driver Class Initialized
DEBUG - 2018-02-26 17:38:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-26 17:38:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-26 17:38:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-26 17:38:00 --> Pagination Class Initialized
INFO - 2018-02-26 17:38:00 --> Helper loaded: form_helper
INFO - 2018-02-26 17:38:00 --> Form Validation Class Initialized
INFO - 2018-02-26 17:38:00 --> Model Class Initialized
INFO - 2018-02-26 17:38:00 --> Controller Class Initialized
INFO - 2018-02-26 17:38:00 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-26 17:38:00 --> Model Class Initialized
INFO - 2018-02-26 17:38:00 --> Model Class Initialized
INFO - 2018-02-26 17:38:00 --> Model Class Initialized
INFO - 2018-02-26 17:38:00 --> Model Class Initialized
INFO - 2018-02-26 17:38:00 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-26 17:38:00 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-26 17:38:00 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-26 17:38:00 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-26 17:38:00 --> File loaded: /var/www/html/project/radio/application/views/tracks/add_edit.php
INFO - 2018-02-26 17:38:00 --> Final output sent to browser
DEBUG - 2018-02-26 17:38:00 --> Total execution time: 0.0088
INFO - 2018-02-26 17:38:01 --> Config Class Initialized
INFO - 2018-02-26 17:38:01 --> Hooks Class Initialized
DEBUG - 2018-02-26 17:38:01 --> UTF-8 Support Enabled
INFO - 2018-02-26 17:38:01 --> Utf8 Class Initialized
INFO - 2018-02-26 17:38:01 --> URI Class Initialized
INFO - 2018-02-26 17:38:01 --> Router Class Initialized
INFO - 2018-02-26 17:38:01 --> Output Class Initialized
INFO - 2018-02-26 17:38:01 --> Security Class Initialized
DEBUG - 2018-02-26 17:38:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-26 17:38:01 --> Input Class Initialized
INFO - 2018-02-26 17:38:01 --> Language Class Initialized
INFO - 2018-02-26 17:38:01 --> Loader Class Initialized
INFO - 2018-02-26 17:38:01 --> Helper loaded: url_helper
INFO - 2018-02-26 17:38:01 --> Helper loaded: file_helper
INFO - 2018-02-26 17:38:01 --> Helper loaded: email_helper
INFO - 2018-02-26 17:38:01 --> Helper loaded: common_helper
INFO - 2018-02-26 17:38:01 --> Database Driver Class Initialized
DEBUG - 2018-02-26 17:38:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-26 17:38:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-26 17:38:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-26 17:38:01 --> Pagination Class Initialized
INFO - 2018-02-26 17:38:01 --> Helper loaded: form_helper
INFO - 2018-02-26 17:38:01 --> Form Validation Class Initialized
INFO - 2018-02-26 17:38:01 --> Model Class Initialized
INFO - 2018-02-26 17:38:01 --> Controller Class Initialized
INFO - 2018-02-26 17:38:01 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-26 17:38:01 --> Model Class Initialized
INFO - 2018-02-26 17:38:01 --> Model Class Initialized
INFO - 2018-02-26 17:38:01 --> Model Class Initialized
INFO - 2018-02-26 17:38:01 --> Model Class Initialized
INFO - 2018-02-26 17:38:01 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-26 17:38:01 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-26 17:38:01 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-26 17:38:01 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-26 17:38:01 --> File loaded: /var/www/html/project/radio/application/views/tracks/add_edit.php
INFO - 2018-02-26 17:38:01 --> Final output sent to browser
DEBUG - 2018-02-26 17:38:01 --> Total execution time: 0.0086
INFO - 2018-02-26 17:38:05 --> Config Class Initialized
INFO - 2018-02-26 17:38:05 --> Hooks Class Initialized
DEBUG - 2018-02-26 17:38:05 --> UTF-8 Support Enabled
INFO - 2018-02-26 17:38:05 --> Utf8 Class Initialized
INFO - 2018-02-26 17:38:05 --> URI Class Initialized
INFO - 2018-02-26 17:38:05 --> Router Class Initialized
INFO - 2018-02-26 17:38:05 --> Output Class Initialized
INFO - 2018-02-26 17:38:05 --> Security Class Initialized
DEBUG - 2018-02-26 17:38:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-26 17:38:05 --> Input Class Initialized
INFO - 2018-02-26 17:38:05 --> Language Class Initialized
INFO - 2018-02-26 17:38:05 --> Loader Class Initialized
INFO - 2018-02-26 17:38:05 --> Helper loaded: url_helper
INFO - 2018-02-26 17:38:05 --> Helper loaded: file_helper
INFO - 2018-02-26 17:38:05 --> Helper loaded: email_helper
INFO - 2018-02-26 17:38:05 --> Helper loaded: common_helper
INFO - 2018-02-26 17:38:05 --> Database Driver Class Initialized
DEBUG - 2018-02-26 17:38:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-26 17:38:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-26 17:38:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-26 17:38:05 --> Pagination Class Initialized
INFO - 2018-02-26 17:38:05 --> Helper loaded: form_helper
INFO - 2018-02-26 17:38:05 --> Form Validation Class Initialized
INFO - 2018-02-26 17:38:05 --> Model Class Initialized
INFO - 2018-02-26 17:38:05 --> Controller Class Initialized
INFO - 2018-02-26 17:38:05 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-26 17:38:05 --> Model Class Initialized
INFO - 2018-02-26 17:38:05 --> Model Class Initialized
INFO - 2018-02-26 17:38:05 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-26 17:38:05 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-26 17:38:05 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-26 17:38:05 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-26 17:38:05 --> File loaded: /var/www/html/project/radio/application/views/subcategory/index.php
INFO - 2018-02-26 17:38:05 --> Final output sent to browser
DEBUG - 2018-02-26 17:38:05 --> Total execution time: 0.0103
INFO - 2018-02-26 17:38:06 --> Config Class Initialized
INFO - 2018-02-26 17:38:06 --> Hooks Class Initialized
DEBUG - 2018-02-26 17:38:06 --> UTF-8 Support Enabled
INFO - 2018-02-26 17:38:06 --> Utf8 Class Initialized
INFO - 2018-02-26 17:38:06 --> URI Class Initialized
INFO - 2018-02-26 17:38:06 --> Router Class Initialized
INFO - 2018-02-26 17:38:06 --> Output Class Initialized
INFO - 2018-02-26 17:38:06 --> Security Class Initialized
DEBUG - 2018-02-26 17:38:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-26 17:38:06 --> Input Class Initialized
INFO - 2018-02-26 17:38:06 --> Language Class Initialized
INFO - 2018-02-26 17:38:06 --> Loader Class Initialized
INFO - 2018-02-26 17:38:06 --> Helper loaded: url_helper
INFO - 2018-02-26 17:38:06 --> Helper loaded: file_helper
INFO - 2018-02-26 17:38:06 --> Helper loaded: email_helper
INFO - 2018-02-26 17:38:06 --> Helper loaded: common_helper
INFO - 2018-02-26 17:38:06 --> Database Driver Class Initialized
DEBUG - 2018-02-26 17:38:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-26 17:38:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-26 17:38:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-26 17:38:06 --> Pagination Class Initialized
INFO - 2018-02-26 17:38:06 --> Helper loaded: form_helper
INFO - 2018-02-26 17:38:06 --> Form Validation Class Initialized
INFO - 2018-02-26 17:38:06 --> Model Class Initialized
INFO - 2018-02-26 17:38:06 --> Controller Class Initialized
INFO - 2018-02-26 17:38:06 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-26 17:38:06 --> Model Class Initialized
INFO - 2018-02-26 17:38:06 --> Model Class Initialized
INFO - 2018-02-26 17:38:06 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-26 17:38:06 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-26 17:38:06 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-26 17:38:06 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-26 17:38:06 --> File loaded: /var/www/html/project/radio/application/views/subcategory/add_edit.php
INFO - 2018-02-26 17:38:06 --> Final output sent to browser
DEBUG - 2018-02-26 17:38:06 --> Total execution time: 0.0060

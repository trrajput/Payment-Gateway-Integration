<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2018-02-20 10:20:40 --> Config Class Initialized
INFO - 2018-02-20 10:20:40 --> Hooks Class Initialized
DEBUG - 2018-02-20 10:20:40 --> UTF-8 Support Enabled
INFO - 2018-02-20 10:20:40 --> Utf8 Class Initialized
INFO - 2018-02-20 10:20:40 --> URI Class Initialized
INFO - 2018-02-20 10:20:40 --> Router Class Initialized
INFO - 2018-02-20 10:20:40 --> Output Class Initialized
INFO - 2018-02-20 10:20:40 --> Security Class Initialized
DEBUG - 2018-02-20 10:20:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-20 10:20:40 --> Input Class Initialized
INFO - 2018-02-20 10:20:40 --> Language Class Initialized
INFO - 2018-02-20 10:20:40 --> Loader Class Initialized
INFO - 2018-02-20 10:20:40 --> Helper loaded: url_helper
INFO - 2018-02-20 10:20:40 --> Helper loaded: file_helper
INFO - 2018-02-20 10:20:40 --> Helper loaded: email_helper
INFO - 2018-02-20 10:20:40 --> Helper loaded: common_helper
INFO - 2018-02-20 10:20:40 --> Database Driver Class Initialized
DEBUG - 2018-02-20 10:20:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-20 10:20:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-20 10:20:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-20 10:20:40 --> Pagination Class Initialized
INFO - 2018-02-20 10:20:40 --> Helper loaded: form_helper
INFO - 2018-02-20 10:20:40 --> Form Validation Class Initialized
INFO - 2018-02-20 10:20:40 --> Model Class Initialized
INFO - 2018-02-20 10:20:40 --> Controller Class Initialized
DEBUG - 2018-02-20 10:20:40 --> Config file loaded: /var/www/html/project/radio/application/config/rest.php
INFO - 2018-02-20 10:20:40 --> Helper loaded: inflector_helper
INFO - 2018-02-20 10:20:40 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-20 10:20:40 --> Model Class Initialized
INFO - 2018-02-20 10:20:40 --> Model Class Initialized
INFO - 2018-02-20 10:22:02 --> Config Class Initialized
INFO - 2018-02-20 10:22:02 --> Hooks Class Initialized
DEBUG - 2018-02-20 10:22:02 --> UTF-8 Support Enabled
INFO - 2018-02-20 10:22:02 --> Utf8 Class Initialized
INFO - 2018-02-20 10:22:02 --> URI Class Initialized
INFO - 2018-02-20 10:22:02 --> Router Class Initialized
INFO - 2018-02-20 10:22:02 --> Output Class Initialized
INFO - 2018-02-20 10:22:02 --> Security Class Initialized
DEBUG - 2018-02-20 10:22:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-20 10:22:02 --> Input Class Initialized
INFO - 2018-02-20 10:22:02 --> Language Class Initialized
INFO - 2018-02-20 10:22:02 --> Loader Class Initialized
INFO - 2018-02-20 10:22:02 --> Helper loaded: url_helper
INFO - 2018-02-20 10:22:02 --> Helper loaded: file_helper
INFO - 2018-02-20 10:22:02 --> Helper loaded: email_helper
INFO - 2018-02-20 10:22:02 --> Helper loaded: common_helper
INFO - 2018-02-20 10:22:02 --> Database Driver Class Initialized
DEBUG - 2018-02-20 10:22:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-20 10:22:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-20 10:22:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-20 10:22:02 --> Pagination Class Initialized
INFO - 2018-02-20 10:22:02 --> Helper loaded: form_helper
INFO - 2018-02-20 10:22:02 --> Form Validation Class Initialized
INFO - 2018-02-20 10:22:02 --> Model Class Initialized
INFO - 2018-02-20 10:22:02 --> Controller Class Initialized
DEBUG - 2018-02-20 10:22:02 --> Config file loaded: /var/www/html/project/radio/application/config/rest.php
INFO - 2018-02-20 10:22:02 --> Helper loaded: inflector_helper
INFO - 2018-02-20 10:22:02 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-20 10:22:02 --> Model Class Initialized
INFO - 2018-02-20 10:22:02 --> Model Class Initialized
ERROR - 2018-02-20 10:22:02 --> Severity: Notice --> Undefined index: tGender /var/www/html/project/radio/application/controllers/api/Oauth.php 48
ERROR - 2018-02-20 10:22:02 --> Query error: Column 'tGender' cannot be null - Invalid query: INSERT INTO `user_master` (`vName`, `vEmail`, `vPassword`, `tGender`, `dtDob`, `dlatitude`, `dlongitude`, `vAuthKey`, `tStatus`, `tRegisterType`) VALUES ('Maulik Raval', 'maulik@parextech.com', 'e10adc3949ba59abbe56e057f20f883e', NULL, NULL, '52.265565', '51.6565454', '85090d38592cee55af071d3640d60526', 1, 1)
INFO - 2018-02-20 10:22:02 --> Language file loaded: language/english/db_lang.php
INFO - 2018-02-20 10:24:33 --> Config Class Initialized
INFO - 2018-02-20 10:24:33 --> Hooks Class Initialized
DEBUG - 2018-02-20 10:24:33 --> UTF-8 Support Enabled
INFO - 2018-02-20 10:24:33 --> Utf8 Class Initialized
INFO - 2018-02-20 10:24:33 --> URI Class Initialized
INFO - 2018-02-20 10:24:33 --> Router Class Initialized
INFO - 2018-02-20 10:24:33 --> Output Class Initialized
INFO - 2018-02-20 10:24:33 --> Security Class Initialized
DEBUG - 2018-02-20 10:24:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-20 10:24:33 --> Input Class Initialized
INFO - 2018-02-20 10:24:33 --> Language Class Initialized
INFO - 2018-02-20 10:24:33 --> Loader Class Initialized
INFO - 2018-02-20 10:24:33 --> Helper loaded: url_helper
INFO - 2018-02-20 10:24:33 --> Helper loaded: file_helper
INFO - 2018-02-20 10:24:33 --> Helper loaded: email_helper
INFO - 2018-02-20 10:24:33 --> Helper loaded: common_helper
INFO - 2018-02-20 10:24:33 --> Database Driver Class Initialized
DEBUG - 2018-02-20 10:24:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-20 10:24:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-20 10:24:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-20 10:24:33 --> Pagination Class Initialized
INFO - 2018-02-20 10:24:33 --> Helper loaded: form_helper
INFO - 2018-02-20 10:24:33 --> Form Validation Class Initialized
INFO - 2018-02-20 10:24:33 --> Model Class Initialized
INFO - 2018-02-20 10:24:33 --> Controller Class Initialized
DEBUG - 2018-02-20 10:24:33 --> Config file loaded: /var/www/html/project/radio/application/config/rest.php
INFO - 2018-02-20 10:24:33 --> Helper loaded: inflector_helper
INFO - 2018-02-20 10:24:33 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-20 10:24:33 --> Model Class Initialized
INFO - 2018-02-20 10:24:33 --> Model Class Initialized
ERROR - 2018-02-20 10:24:33 --> Query error: Unknown column 'vDeviceType' in 'field list' - Invalid query: INSERT INTO `device_master` (`vDeviceToken`, `vDeviceName`, `vDeviceType`, `iUserId`) VALUES ('saasfew3wfwewffew', 'IPhone 7', '1', 1)
INFO - 2018-02-20 10:24:33 --> Language file loaded: language/english/db_lang.php
INFO - 2018-02-20 10:26:19 --> Config Class Initialized
INFO - 2018-02-20 10:26:19 --> Hooks Class Initialized
DEBUG - 2018-02-20 10:26:19 --> UTF-8 Support Enabled
INFO - 2018-02-20 10:26:19 --> Utf8 Class Initialized
INFO - 2018-02-20 10:26:19 --> URI Class Initialized
INFO - 2018-02-20 10:26:19 --> Router Class Initialized
INFO - 2018-02-20 10:26:19 --> Output Class Initialized
INFO - 2018-02-20 10:26:19 --> Security Class Initialized
DEBUG - 2018-02-20 10:26:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-20 10:26:19 --> Input Class Initialized
INFO - 2018-02-20 10:26:19 --> Language Class Initialized
INFO - 2018-02-20 10:26:19 --> Loader Class Initialized
INFO - 2018-02-20 10:26:19 --> Helper loaded: url_helper
INFO - 2018-02-20 10:26:19 --> Helper loaded: file_helper
INFO - 2018-02-20 10:26:19 --> Helper loaded: email_helper
INFO - 2018-02-20 10:26:19 --> Helper loaded: common_helper
INFO - 2018-02-20 10:26:19 --> Database Driver Class Initialized
DEBUG - 2018-02-20 10:26:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-20 10:26:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-20 10:26:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-20 10:26:19 --> Pagination Class Initialized
INFO - 2018-02-20 10:26:19 --> Helper loaded: form_helper
INFO - 2018-02-20 10:26:19 --> Form Validation Class Initialized
INFO - 2018-02-20 10:26:19 --> Model Class Initialized
INFO - 2018-02-20 10:26:19 --> Controller Class Initialized
DEBUG - 2018-02-20 10:26:19 --> Config file loaded: /var/www/html/project/radio/application/config/rest.php
INFO - 2018-02-20 10:26:19 --> Helper loaded: inflector_helper
INFO - 2018-02-20 10:26:19 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-20 10:26:19 --> Model Class Initialized
INFO - 2018-02-20 10:26:19 --> Model Class Initialized
INFO - 2018-02-20 10:26:19 --> Final output sent to browser
DEBUG - 2018-02-20 10:26:19 --> Total execution time: 0.0471
INFO - 2018-02-20 10:26:28 --> Config Class Initialized
INFO - 2018-02-20 10:26:28 --> Hooks Class Initialized
DEBUG - 2018-02-20 10:26:28 --> UTF-8 Support Enabled
INFO - 2018-02-20 10:26:28 --> Utf8 Class Initialized
INFO - 2018-02-20 10:26:28 --> URI Class Initialized
INFO - 2018-02-20 10:26:28 --> Router Class Initialized
INFO - 2018-02-20 10:26:28 --> Output Class Initialized
INFO - 2018-02-20 10:26:28 --> Security Class Initialized
DEBUG - 2018-02-20 10:26:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-20 10:26:28 --> Input Class Initialized
INFO - 2018-02-20 10:26:28 --> Language Class Initialized
INFO - 2018-02-20 10:26:28 --> Loader Class Initialized
INFO - 2018-02-20 10:26:28 --> Helper loaded: url_helper
INFO - 2018-02-20 10:26:28 --> Helper loaded: file_helper
INFO - 2018-02-20 10:26:28 --> Helper loaded: email_helper
INFO - 2018-02-20 10:26:28 --> Helper loaded: common_helper
INFO - 2018-02-20 10:26:28 --> Database Driver Class Initialized
DEBUG - 2018-02-20 10:26:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-20 10:26:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-20 10:26:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-20 10:26:28 --> Pagination Class Initialized
INFO - 2018-02-20 10:26:28 --> Helper loaded: form_helper
INFO - 2018-02-20 10:26:28 --> Form Validation Class Initialized
INFO - 2018-02-20 10:26:28 --> Model Class Initialized
INFO - 2018-02-20 10:26:28 --> Controller Class Initialized
DEBUG - 2018-02-20 10:26:28 --> Config file loaded: /var/www/html/project/radio/application/config/rest.php
INFO - 2018-02-20 10:26:28 --> Helper loaded: inflector_helper
INFO - 2018-02-20 10:26:28 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-20 10:26:28 --> Model Class Initialized
INFO - 2018-02-20 10:26:28 --> Model Class Initialized
INFO - 2018-02-20 10:26:28 --> Final output sent to browser
DEBUG - 2018-02-20 10:26:28 --> Total execution time: 0.0117
INFO - 2018-02-20 10:26:34 --> Config Class Initialized
INFO - 2018-02-20 10:26:34 --> Hooks Class Initialized
DEBUG - 2018-02-20 10:26:34 --> UTF-8 Support Enabled
INFO - 2018-02-20 10:26:34 --> Utf8 Class Initialized
INFO - 2018-02-20 10:26:34 --> URI Class Initialized
INFO - 2018-02-20 10:26:34 --> Router Class Initialized
INFO - 2018-02-20 10:26:34 --> Output Class Initialized
INFO - 2018-02-20 10:26:34 --> Security Class Initialized
DEBUG - 2018-02-20 10:26:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-20 10:26:34 --> Input Class Initialized
INFO - 2018-02-20 10:26:34 --> Language Class Initialized
INFO - 2018-02-20 10:26:34 --> Loader Class Initialized
INFO - 2018-02-20 10:26:34 --> Helper loaded: url_helper
INFO - 2018-02-20 10:26:34 --> Helper loaded: file_helper
INFO - 2018-02-20 10:26:34 --> Helper loaded: email_helper
INFO - 2018-02-20 10:26:34 --> Helper loaded: common_helper
INFO - 2018-02-20 10:26:34 --> Database Driver Class Initialized
DEBUG - 2018-02-20 10:26:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-20 10:26:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-20 10:26:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-20 10:26:34 --> Pagination Class Initialized
INFO - 2018-02-20 10:26:34 --> Helper loaded: form_helper
INFO - 2018-02-20 10:26:34 --> Form Validation Class Initialized
INFO - 2018-02-20 10:26:34 --> Model Class Initialized
INFO - 2018-02-20 10:26:34 --> Controller Class Initialized
DEBUG - 2018-02-20 10:26:34 --> Config file loaded: /var/www/html/project/radio/application/config/rest.php
INFO - 2018-02-20 10:26:34 --> Helper loaded: inflector_helper
INFO - 2018-02-20 10:26:34 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-20 10:26:34 --> Model Class Initialized
INFO - 2018-02-20 10:26:34 --> Model Class Initialized
INFO - 2018-02-20 10:26:34 --> Final output sent to browser
DEBUG - 2018-02-20 10:26:34 --> Total execution time: 0.0502
INFO - 2018-02-20 10:27:41 --> Config Class Initialized
INFO - 2018-02-20 10:27:41 --> Hooks Class Initialized
DEBUG - 2018-02-20 10:27:41 --> UTF-8 Support Enabled
INFO - 2018-02-20 10:27:41 --> Utf8 Class Initialized
INFO - 2018-02-20 10:27:41 --> URI Class Initialized
INFO - 2018-02-20 10:27:41 --> Router Class Initialized
INFO - 2018-02-20 10:27:41 --> Output Class Initialized
INFO - 2018-02-20 10:27:41 --> Security Class Initialized
DEBUG - 2018-02-20 10:27:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-20 10:27:41 --> Input Class Initialized
INFO - 2018-02-20 10:27:41 --> Language Class Initialized
INFO - 2018-02-20 10:27:41 --> Loader Class Initialized
INFO - 2018-02-20 10:27:41 --> Helper loaded: url_helper
INFO - 2018-02-20 10:27:41 --> Helper loaded: file_helper
INFO - 2018-02-20 10:27:41 --> Helper loaded: email_helper
INFO - 2018-02-20 10:27:41 --> Helper loaded: common_helper
INFO - 2018-02-20 10:27:41 --> Database Driver Class Initialized
DEBUG - 2018-02-20 10:27:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-20 10:27:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-20 10:27:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-20 10:27:41 --> Pagination Class Initialized
INFO - 2018-02-20 10:27:41 --> Helper loaded: form_helper
INFO - 2018-02-20 10:27:41 --> Form Validation Class Initialized
INFO - 2018-02-20 10:27:41 --> Model Class Initialized
INFO - 2018-02-20 10:27:41 --> Controller Class Initialized
DEBUG - 2018-02-20 10:27:41 --> Config file loaded: /var/www/html/project/radio/application/config/rest.php
INFO - 2018-02-20 10:27:41 --> Helper loaded: inflector_helper
INFO - 2018-02-20 10:27:41 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-20 10:27:41 --> Model Class Initialized
INFO - 2018-02-20 10:27:41 --> Model Class Initialized
INFO - 2018-02-20 10:27:41 --> Final output sent to browser
DEBUG - 2018-02-20 10:27:41 --> Total execution time: 0.0045
INFO - 2018-02-20 10:27:46 --> Config Class Initialized
INFO - 2018-02-20 10:27:46 --> Hooks Class Initialized
DEBUG - 2018-02-20 10:27:46 --> UTF-8 Support Enabled
INFO - 2018-02-20 10:27:46 --> Utf8 Class Initialized
INFO - 2018-02-20 10:27:46 --> URI Class Initialized
INFO - 2018-02-20 10:27:46 --> Router Class Initialized
INFO - 2018-02-20 10:27:46 --> Output Class Initialized
INFO - 2018-02-20 10:27:46 --> Security Class Initialized
DEBUG - 2018-02-20 10:27:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-20 10:27:46 --> Input Class Initialized
INFO - 2018-02-20 10:27:46 --> Language Class Initialized
INFO - 2018-02-20 10:27:46 --> Loader Class Initialized
INFO - 2018-02-20 10:27:46 --> Helper loaded: url_helper
INFO - 2018-02-20 10:27:46 --> Helper loaded: file_helper
INFO - 2018-02-20 10:27:46 --> Helper loaded: email_helper
INFO - 2018-02-20 10:27:46 --> Helper loaded: common_helper
INFO - 2018-02-20 10:27:46 --> Database Driver Class Initialized
DEBUG - 2018-02-20 10:27:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-20 10:27:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-20 10:27:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-20 10:27:46 --> Pagination Class Initialized
INFO - 2018-02-20 10:27:46 --> Helper loaded: form_helper
INFO - 2018-02-20 10:27:46 --> Form Validation Class Initialized
INFO - 2018-02-20 10:27:46 --> Model Class Initialized
INFO - 2018-02-20 10:27:46 --> Controller Class Initialized
DEBUG - 2018-02-20 10:27:46 --> Config file loaded: /var/www/html/project/radio/application/config/rest.php
INFO - 2018-02-20 10:27:46 --> Helper loaded: inflector_helper
INFO - 2018-02-20 10:27:46 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-20 10:27:46 --> Model Class Initialized
INFO - 2018-02-20 10:27:46 --> Model Class Initialized
INFO - 2018-02-20 10:27:46 --> Final output sent to browser
DEBUG - 2018-02-20 10:27:46 --> Total execution time: 0.0044
INFO - 2018-02-20 10:28:00 --> Config Class Initialized
INFO - 2018-02-20 10:28:00 --> Hooks Class Initialized
DEBUG - 2018-02-20 10:28:00 --> UTF-8 Support Enabled
INFO - 2018-02-20 10:28:00 --> Utf8 Class Initialized
INFO - 2018-02-20 10:28:00 --> URI Class Initialized
INFO - 2018-02-20 10:28:00 --> Router Class Initialized
INFO - 2018-02-20 10:28:00 --> Output Class Initialized
INFO - 2018-02-20 10:28:00 --> Security Class Initialized
DEBUG - 2018-02-20 10:28:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-20 10:28:00 --> Input Class Initialized
INFO - 2018-02-20 10:28:00 --> Language Class Initialized
INFO - 2018-02-20 10:28:00 --> Loader Class Initialized
INFO - 2018-02-20 10:28:00 --> Helper loaded: url_helper
INFO - 2018-02-20 10:28:00 --> Helper loaded: file_helper
INFO - 2018-02-20 10:28:00 --> Helper loaded: email_helper
INFO - 2018-02-20 10:28:00 --> Helper loaded: common_helper
INFO - 2018-02-20 10:28:00 --> Database Driver Class Initialized
DEBUG - 2018-02-20 10:28:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-20 10:28:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-20 10:28:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-20 10:28:00 --> Pagination Class Initialized
INFO - 2018-02-20 10:28:00 --> Helper loaded: form_helper
INFO - 2018-02-20 10:28:00 --> Form Validation Class Initialized
INFO - 2018-02-20 10:28:00 --> Model Class Initialized
INFO - 2018-02-20 10:28:00 --> Controller Class Initialized
DEBUG - 2018-02-20 10:28:00 --> Config file loaded: /var/www/html/project/radio/application/config/rest.php
INFO - 2018-02-20 10:28:00 --> Helper loaded: inflector_helper
INFO - 2018-02-20 10:28:00 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-20 10:28:00 --> Model Class Initialized
INFO - 2018-02-20 10:28:00 --> Model Class Initialized
INFO - 2018-02-20 10:28:00 --> Final output sent to browser
DEBUG - 2018-02-20 10:28:00 --> Total execution time: 0.0398
INFO - 2018-02-20 10:29:25 --> Config Class Initialized
INFO - 2018-02-20 10:29:25 --> Hooks Class Initialized
DEBUG - 2018-02-20 10:29:25 --> UTF-8 Support Enabled
INFO - 2018-02-20 10:29:25 --> Utf8 Class Initialized
INFO - 2018-02-20 10:29:25 --> URI Class Initialized
INFO - 2018-02-20 10:29:25 --> Router Class Initialized
INFO - 2018-02-20 10:29:25 --> Output Class Initialized
INFO - 2018-02-20 10:29:25 --> Security Class Initialized
DEBUG - 2018-02-20 10:29:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-20 10:29:25 --> Input Class Initialized
INFO - 2018-02-20 10:29:25 --> Language Class Initialized
INFO - 2018-02-20 10:29:25 --> Loader Class Initialized
INFO - 2018-02-20 10:29:25 --> Helper loaded: url_helper
INFO - 2018-02-20 10:29:25 --> Helper loaded: file_helper
INFO - 2018-02-20 10:29:25 --> Helper loaded: email_helper
INFO - 2018-02-20 10:29:25 --> Helper loaded: common_helper
INFO - 2018-02-20 10:29:25 --> Database Driver Class Initialized
DEBUG - 2018-02-20 10:29:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-20 10:29:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-20 10:29:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-20 10:29:25 --> Pagination Class Initialized
INFO - 2018-02-20 10:29:25 --> Helper loaded: form_helper
INFO - 2018-02-20 10:29:25 --> Form Validation Class Initialized
INFO - 2018-02-20 10:29:25 --> Model Class Initialized
INFO - 2018-02-20 10:29:25 --> Controller Class Initialized
DEBUG - 2018-02-20 10:29:25 --> Config file loaded: /var/www/html/project/radio/application/config/rest.php
INFO - 2018-02-20 10:29:25 --> Helper loaded: inflector_helper
INFO - 2018-02-20 10:29:25 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-20 10:29:25 --> Model Class Initialized
INFO - 2018-02-20 10:29:25 --> Model Class Initialized
INFO - 2018-02-20 10:29:43 --> Config Class Initialized
INFO - 2018-02-20 10:29:43 --> Hooks Class Initialized
DEBUG - 2018-02-20 10:29:43 --> UTF-8 Support Enabled
INFO - 2018-02-20 10:29:43 --> Utf8 Class Initialized
INFO - 2018-02-20 10:29:43 --> URI Class Initialized
INFO - 2018-02-20 10:29:43 --> Router Class Initialized
INFO - 2018-02-20 10:29:43 --> Output Class Initialized
INFO - 2018-02-20 10:29:43 --> Security Class Initialized
DEBUG - 2018-02-20 10:29:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-20 10:29:43 --> Input Class Initialized
INFO - 2018-02-20 10:29:43 --> Language Class Initialized
INFO - 2018-02-20 10:29:43 --> Loader Class Initialized
INFO - 2018-02-20 10:29:43 --> Helper loaded: url_helper
INFO - 2018-02-20 10:29:43 --> Helper loaded: file_helper
INFO - 2018-02-20 10:29:43 --> Helper loaded: email_helper
INFO - 2018-02-20 10:29:43 --> Helper loaded: common_helper
INFO - 2018-02-20 10:29:43 --> Database Driver Class Initialized
DEBUG - 2018-02-20 10:29:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-20 10:29:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-20 10:29:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-20 10:29:43 --> Pagination Class Initialized
INFO - 2018-02-20 10:29:43 --> Helper loaded: form_helper
INFO - 2018-02-20 10:29:43 --> Form Validation Class Initialized
INFO - 2018-02-20 10:29:43 --> Model Class Initialized
INFO - 2018-02-20 10:29:43 --> Controller Class Initialized
DEBUG - 2018-02-20 10:29:43 --> Config file loaded: /var/www/html/project/radio/application/config/rest.php
INFO - 2018-02-20 10:29:43 --> Helper loaded: inflector_helper
INFO - 2018-02-20 10:29:43 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-20 10:29:43 --> Model Class Initialized
INFO - 2018-02-20 10:29:43 --> Model Class Initialized
INFO - 2018-02-20 10:29:43 --> Final output sent to browser
DEBUG - 2018-02-20 10:29:43 --> Total execution time: 0.0435
INFO - 2018-02-20 10:30:02 --> Config Class Initialized
INFO - 2018-02-20 10:30:02 --> Hooks Class Initialized
DEBUG - 2018-02-20 10:30:02 --> UTF-8 Support Enabled
INFO - 2018-02-20 10:30:02 --> Utf8 Class Initialized
INFO - 2018-02-20 10:30:02 --> URI Class Initialized
INFO - 2018-02-20 10:30:02 --> Router Class Initialized
INFO - 2018-02-20 10:30:02 --> Output Class Initialized
INFO - 2018-02-20 10:30:02 --> Security Class Initialized
DEBUG - 2018-02-20 10:30:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-20 10:30:02 --> Input Class Initialized
INFO - 2018-02-20 10:30:02 --> Language Class Initialized
INFO - 2018-02-20 10:30:02 --> Loader Class Initialized
INFO - 2018-02-20 10:30:02 --> Helper loaded: url_helper
INFO - 2018-02-20 10:30:02 --> Helper loaded: file_helper
INFO - 2018-02-20 10:30:02 --> Helper loaded: email_helper
INFO - 2018-02-20 10:30:02 --> Helper loaded: common_helper
INFO - 2018-02-20 10:30:02 --> Database Driver Class Initialized
DEBUG - 2018-02-20 10:30:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-20 10:30:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-20 10:30:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-20 10:30:02 --> Pagination Class Initialized
INFO - 2018-02-20 10:30:02 --> Helper loaded: form_helper
INFO - 2018-02-20 10:30:02 --> Form Validation Class Initialized
INFO - 2018-02-20 10:30:02 --> Model Class Initialized
INFO - 2018-02-20 10:30:02 --> Controller Class Initialized
DEBUG - 2018-02-20 10:30:02 --> Config file loaded: /var/www/html/project/radio/application/config/rest.php
INFO - 2018-02-20 10:30:02 --> Helper loaded: inflector_helper
INFO - 2018-02-20 10:30:02 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-20 10:30:02 --> Model Class Initialized
INFO - 2018-02-20 10:30:02 --> Model Class Initialized
INFO - 2018-02-20 10:30:52 --> Config Class Initialized
INFO - 2018-02-20 10:30:52 --> Hooks Class Initialized
DEBUG - 2018-02-20 10:30:52 --> UTF-8 Support Enabled
INFO - 2018-02-20 10:30:52 --> Utf8 Class Initialized
INFO - 2018-02-20 10:30:52 --> URI Class Initialized
INFO - 2018-02-20 10:30:52 --> Router Class Initialized
INFO - 2018-02-20 10:30:52 --> Output Class Initialized
INFO - 2018-02-20 10:30:52 --> Security Class Initialized
DEBUG - 2018-02-20 10:30:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-20 10:30:52 --> Input Class Initialized
INFO - 2018-02-20 10:30:52 --> Language Class Initialized
INFO - 2018-02-20 10:30:52 --> Loader Class Initialized
INFO - 2018-02-20 10:30:52 --> Helper loaded: url_helper
INFO - 2018-02-20 10:30:52 --> Helper loaded: file_helper
INFO - 2018-02-20 10:30:52 --> Helper loaded: email_helper
INFO - 2018-02-20 10:30:52 --> Helper loaded: common_helper
INFO - 2018-02-20 10:30:52 --> Database Driver Class Initialized
DEBUG - 2018-02-20 10:30:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-20 10:30:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-20 10:30:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-20 10:30:52 --> Pagination Class Initialized
INFO - 2018-02-20 10:30:52 --> Helper loaded: form_helper
INFO - 2018-02-20 10:30:52 --> Form Validation Class Initialized
INFO - 2018-02-20 10:30:52 --> Model Class Initialized
INFO - 2018-02-20 10:30:52 --> Controller Class Initialized
DEBUG - 2018-02-20 10:30:52 --> Config file loaded: /var/www/html/project/radio/application/config/rest.php
INFO - 2018-02-20 10:30:52 --> Helper loaded: inflector_helper
INFO - 2018-02-20 10:30:52 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-20 10:30:52 --> Model Class Initialized
INFO - 2018-02-20 10:30:52 --> Model Class Initialized
INFO - 2018-02-20 10:30:52 --> Final output sent to browser
DEBUG - 2018-02-20 10:30:52 --> Total execution time: 0.0859
INFO - 2018-02-20 10:31:25 --> Config Class Initialized
INFO - 2018-02-20 10:31:25 --> Hooks Class Initialized
DEBUG - 2018-02-20 10:31:25 --> UTF-8 Support Enabled
INFO - 2018-02-20 10:31:25 --> Utf8 Class Initialized
INFO - 2018-02-20 10:31:25 --> URI Class Initialized
INFO - 2018-02-20 10:31:25 --> Router Class Initialized
INFO - 2018-02-20 10:31:25 --> Output Class Initialized
INFO - 2018-02-20 10:31:25 --> Security Class Initialized
DEBUG - 2018-02-20 10:31:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-20 10:31:25 --> Input Class Initialized
INFO - 2018-02-20 10:31:25 --> Language Class Initialized
INFO - 2018-02-20 10:31:25 --> Loader Class Initialized
INFO - 2018-02-20 10:31:25 --> Helper loaded: url_helper
INFO - 2018-02-20 10:31:25 --> Helper loaded: file_helper
INFO - 2018-02-20 10:31:25 --> Helper loaded: email_helper
INFO - 2018-02-20 10:31:25 --> Helper loaded: common_helper
INFO - 2018-02-20 10:31:25 --> Database Driver Class Initialized
DEBUG - 2018-02-20 10:31:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-20 10:31:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-20 10:31:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-20 10:31:25 --> Pagination Class Initialized
INFO - 2018-02-20 10:31:25 --> Helper loaded: form_helper
INFO - 2018-02-20 10:31:25 --> Form Validation Class Initialized
INFO - 2018-02-20 10:31:25 --> Model Class Initialized
INFO - 2018-02-20 10:31:25 --> Controller Class Initialized
DEBUG - 2018-02-20 10:31:25 --> Config file loaded: /var/www/html/project/radio/application/config/rest.php
INFO - 2018-02-20 10:31:25 --> Helper loaded: inflector_helper
INFO - 2018-02-20 10:31:25 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-20 10:31:25 --> Model Class Initialized
INFO - 2018-02-20 10:31:25 --> Model Class Initialized
INFO - 2018-02-20 10:31:25 --> Final output sent to browser
DEBUG - 2018-02-20 10:31:25 --> Total execution time: 0.1200
INFO - 2018-02-20 10:31:37 --> Config Class Initialized
INFO - 2018-02-20 10:31:37 --> Hooks Class Initialized
DEBUG - 2018-02-20 10:31:37 --> UTF-8 Support Enabled
INFO - 2018-02-20 10:31:37 --> Utf8 Class Initialized
INFO - 2018-02-20 10:31:37 --> URI Class Initialized
INFO - 2018-02-20 10:31:37 --> Router Class Initialized
INFO - 2018-02-20 10:31:37 --> Output Class Initialized
INFO - 2018-02-20 10:31:37 --> Security Class Initialized
DEBUG - 2018-02-20 10:31:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-20 10:31:37 --> Input Class Initialized
INFO - 2018-02-20 10:31:37 --> Language Class Initialized
INFO - 2018-02-20 10:31:37 --> Loader Class Initialized
INFO - 2018-02-20 10:31:37 --> Helper loaded: url_helper
INFO - 2018-02-20 10:31:37 --> Helper loaded: file_helper
INFO - 2018-02-20 10:31:37 --> Helper loaded: email_helper
INFO - 2018-02-20 10:31:37 --> Helper loaded: common_helper
INFO - 2018-02-20 10:31:37 --> Database Driver Class Initialized
DEBUG - 2018-02-20 10:31:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-20 10:31:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-20 10:31:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-20 10:31:37 --> Pagination Class Initialized
INFO - 2018-02-20 10:31:37 --> Helper loaded: form_helper
INFO - 2018-02-20 10:31:37 --> Form Validation Class Initialized
INFO - 2018-02-20 10:31:37 --> Model Class Initialized
INFO - 2018-02-20 10:31:37 --> Controller Class Initialized
DEBUG - 2018-02-20 10:31:37 --> Config file loaded: /var/www/html/project/radio/application/config/rest.php
INFO - 2018-02-20 10:31:37 --> Helper loaded: inflector_helper
INFO - 2018-02-20 10:31:37 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-20 10:31:37 --> Model Class Initialized
INFO - 2018-02-20 10:31:37 --> Model Class Initialized
INFO - 2018-02-20 10:31:37 --> Final output sent to browser
DEBUG - 2018-02-20 10:31:37 --> Total execution time: 0.0361
INFO - 2018-02-20 10:36:51 --> Config Class Initialized
INFO - 2018-02-20 10:36:51 --> Hooks Class Initialized
DEBUG - 2018-02-20 10:36:51 --> UTF-8 Support Enabled
INFO - 2018-02-20 10:36:51 --> Utf8 Class Initialized
INFO - 2018-02-20 10:36:51 --> URI Class Initialized
INFO - 2018-02-20 10:36:51 --> Router Class Initialized
INFO - 2018-02-20 10:36:51 --> Output Class Initialized
INFO - 2018-02-20 10:36:51 --> Security Class Initialized
DEBUG - 2018-02-20 10:36:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-20 10:36:51 --> Input Class Initialized
INFO - 2018-02-20 10:36:51 --> Language Class Initialized
INFO - 2018-02-20 10:36:51 --> Loader Class Initialized
INFO - 2018-02-20 10:36:51 --> Helper loaded: url_helper
INFO - 2018-02-20 10:36:51 --> Helper loaded: file_helper
INFO - 2018-02-20 10:36:51 --> Helper loaded: email_helper
INFO - 2018-02-20 10:36:51 --> Helper loaded: common_helper
INFO - 2018-02-20 10:36:51 --> Database Driver Class Initialized
DEBUG - 2018-02-20 10:36:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-20 10:36:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-20 10:36:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-20 10:36:51 --> Pagination Class Initialized
INFO - 2018-02-20 10:36:51 --> Helper loaded: form_helper
INFO - 2018-02-20 10:36:51 --> Form Validation Class Initialized
INFO - 2018-02-20 10:36:51 --> Model Class Initialized
INFO - 2018-02-20 10:36:51 --> Controller Class Initialized
DEBUG - 2018-02-20 10:36:51 --> Config file loaded: /var/www/html/project/radio/application/config/rest.php
INFO - 2018-02-20 10:36:51 --> Helper loaded: inflector_helper
INFO - 2018-02-20 10:36:51 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-20 10:36:51 --> Model Class Initialized
INFO - 2018-02-20 10:36:51 --> Model Class Initialized
ERROR - 2018-02-20 10:36:51 --> Query error: Column 'vEmail' cannot be null - Invalid query: INSERT INTO `user_master` (`vName`, `vEmail`, `tGender`, `dtDob`, `dlatitude`, `dlongitude`, `vFacebookId`, `vAuthKey`, `tStatus`, `tRegisterType`) VALUES ('Maulik Raval', NULL, NULL, NULL, '52.265565', '51.6565454', '12345678910', '6e4cfb4cffe36acd346c08a9a3257a2f', 1, 2)
INFO - 2018-02-20 10:36:51 --> Language file loaded: language/english/db_lang.php
INFO - 2018-02-20 10:37:46 --> Config Class Initialized
INFO - 2018-02-20 10:37:46 --> Hooks Class Initialized
DEBUG - 2018-02-20 10:37:46 --> UTF-8 Support Enabled
INFO - 2018-02-20 10:37:46 --> Utf8 Class Initialized
INFO - 2018-02-20 10:37:46 --> URI Class Initialized
INFO - 2018-02-20 10:37:46 --> Router Class Initialized
INFO - 2018-02-20 10:37:46 --> Output Class Initialized
INFO - 2018-02-20 10:37:46 --> Security Class Initialized
DEBUG - 2018-02-20 10:37:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-20 10:37:46 --> Input Class Initialized
INFO - 2018-02-20 10:37:46 --> Language Class Initialized
INFO - 2018-02-20 10:37:46 --> Loader Class Initialized
INFO - 2018-02-20 10:37:46 --> Helper loaded: url_helper
INFO - 2018-02-20 10:37:46 --> Helper loaded: file_helper
INFO - 2018-02-20 10:37:46 --> Helper loaded: email_helper
INFO - 2018-02-20 10:37:46 --> Helper loaded: common_helper
INFO - 2018-02-20 10:37:46 --> Database Driver Class Initialized
DEBUG - 2018-02-20 10:37:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-20 10:37:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-20 10:37:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-20 10:37:46 --> Pagination Class Initialized
INFO - 2018-02-20 10:37:46 --> Helper loaded: form_helper
INFO - 2018-02-20 10:37:46 --> Form Validation Class Initialized
INFO - 2018-02-20 10:37:46 --> Model Class Initialized
INFO - 2018-02-20 10:37:46 --> Controller Class Initialized
DEBUG - 2018-02-20 10:37:46 --> Config file loaded: /var/www/html/project/radio/application/config/rest.php
INFO - 2018-02-20 10:37:46 --> Helper loaded: inflector_helper
INFO - 2018-02-20 10:37:46 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-20 10:37:46 --> Model Class Initialized
INFO - 2018-02-20 10:37:46 --> Model Class Initialized
INFO - 2018-02-20 10:37:47 --> Final output sent to browser
DEBUG - 2018-02-20 10:37:47 --> Total execution time: 0.0687
INFO - 2018-02-20 10:38:58 --> Config Class Initialized
INFO - 2018-02-20 10:38:58 --> Hooks Class Initialized
DEBUG - 2018-02-20 10:38:58 --> UTF-8 Support Enabled
INFO - 2018-02-20 10:38:58 --> Utf8 Class Initialized
INFO - 2018-02-20 10:38:58 --> URI Class Initialized
INFO - 2018-02-20 10:38:58 --> Router Class Initialized
INFO - 2018-02-20 10:38:58 --> Output Class Initialized
INFO - 2018-02-20 10:38:58 --> Security Class Initialized
DEBUG - 2018-02-20 10:38:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-20 10:38:58 --> Input Class Initialized
INFO - 2018-02-20 10:38:58 --> Language Class Initialized
INFO - 2018-02-20 10:38:58 --> Loader Class Initialized
INFO - 2018-02-20 10:38:58 --> Helper loaded: url_helper
INFO - 2018-02-20 10:38:58 --> Helper loaded: file_helper
INFO - 2018-02-20 10:38:58 --> Helper loaded: email_helper
INFO - 2018-02-20 10:38:58 --> Helper loaded: common_helper
INFO - 2018-02-20 10:38:58 --> Database Driver Class Initialized
DEBUG - 2018-02-20 10:38:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-20 10:38:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-20 10:38:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-20 10:38:58 --> Pagination Class Initialized
INFO - 2018-02-20 10:38:58 --> Helper loaded: form_helper
INFO - 2018-02-20 10:38:58 --> Form Validation Class Initialized
INFO - 2018-02-20 10:38:58 --> Model Class Initialized
INFO - 2018-02-20 10:38:58 --> Controller Class Initialized
DEBUG - 2018-02-20 10:38:58 --> Config file loaded: /var/www/html/project/radio/application/config/rest.php
INFO - 2018-02-20 10:38:58 --> Helper loaded: inflector_helper
INFO - 2018-02-20 10:38:58 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-20 10:38:58 --> Model Class Initialized
INFO - 2018-02-20 10:38:58 --> Model Class Initialized
ERROR - 2018-02-20 10:38:58 --> Severity: Notice --> Undefined variable: 4 /var/www/html/project/radio/application/controllers/api/Oauth.php 140
INFO - 2018-02-20 10:38:58 --> Final output sent to browser
DEBUG - 2018-02-20 10:38:58 --> Total execution time: 0.0512
INFO - 2018-02-20 10:39:23 --> Config Class Initialized
INFO - 2018-02-20 10:39:23 --> Hooks Class Initialized
DEBUG - 2018-02-20 10:39:23 --> UTF-8 Support Enabled
INFO - 2018-02-20 10:39:23 --> Utf8 Class Initialized
INFO - 2018-02-20 10:39:23 --> URI Class Initialized
INFO - 2018-02-20 10:39:23 --> Router Class Initialized
INFO - 2018-02-20 10:39:23 --> Output Class Initialized
INFO - 2018-02-20 10:39:23 --> Security Class Initialized
DEBUG - 2018-02-20 10:39:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-20 10:39:23 --> Input Class Initialized
INFO - 2018-02-20 10:39:23 --> Language Class Initialized
INFO - 2018-02-20 10:39:23 --> Loader Class Initialized
INFO - 2018-02-20 10:39:23 --> Helper loaded: url_helper
INFO - 2018-02-20 10:39:23 --> Helper loaded: file_helper
INFO - 2018-02-20 10:39:23 --> Helper loaded: email_helper
INFO - 2018-02-20 10:39:23 --> Helper loaded: common_helper
INFO - 2018-02-20 10:39:23 --> Database Driver Class Initialized
DEBUG - 2018-02-20 10:39:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-20 10:39:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-20 10:39:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-20 10:39:23 --> Pagination Class Initialized
INFO - 2018-02-20 10:39:23 --> Helper loaded: form_helper
INFO - 2018-02-20 10:39:23 --> Form Validation Class Initialized
INFO - 2018-02-20 10:39:23 --> Model Class Initialized
INFO - 2018-02-20 10:39:23 --> Controller Class Initialized
DEBUG - 2018-02-20 10:39:23 --> Config file loaded: /var/www/html/project/radio/application/config/rest.php
INFO - 2018-02-20 10:39:23 --> Helper loaded: inflector_helper
INFO - 2018-02-20 10:39:23 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-20 10:39:23 --> Model Class Initialized
INFO - 2018-02-20 10:39:23 --> Model Class Initialized
INFO - 2018-02-20 10:39:23 --> Final output sent to browser
DEBUG - 2018-02-20 10:39:23 --> Total execution time: 0.0421
INFO - 2018-02-20 10:40:07 --> Config Class Initialized
INFO - 2018-02-20 10:40:07 --> Hooks Class Initialized
DEBUG - 2018-02-20 10:40:07 --> UTF-8 Support Enabled
INFO - 2018-02-20 10:40:07 --> Utf8 Class Initialized
INFO - 2018-02-20 10:40:07 --> URI Class Initialized
INFO - 2018-02-20 10:40:07 --> Router Class Initialized
INFO - 2018-02-20 10:40:07 --> Output Class Initialized
INFO - 2018-02-20 10:40:07 --> Security Class Initialized
DEBUG - 2018-02-20 10:40:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-20 10:40:07 --> Input Class Initialized
INFO - 2018-02-20 10:40:07 --> Language Class Initialized
INFO - 2018-02-20 10:40:07 --> Loader Class Initialized
INFO - 2018-02-20 10:40:07 --> Helper loaded: url_helper
INFO - 2018-02-20 10:40:07 --> Helper loaded: file_helper
INFO - 2018-02-20 10:40:07 --> Helper loaded: email_helper
INFO - 2018-02-20 10:40:07 --> Helper loaded: common_helper
INFO - 2018-02-20 10:40:07 --> Database Driver Class Initialized
DEBUG - 2018-02-20 10:40:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-20 10:40:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-20 10:40:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-20 10:40:07 --> Pagination Class Initialized
INFO - 2018-02-20 10:40:07 --> Helper loaded: form_helper
INFO - 2018-02-20 10:40:07 --> Form Validation Class Initialized
INFO - 2018-02-20 10:40:07 --> Model Class Initialized
INFO - 2018-02-20 10:40:07 --> Controller Class Initialized
DEBUG - 2018-02-20 10:40:07 --> Config file loaded: /var/www/html/project/radio/application/config/rest.php
INFO - 2018-02-20 10:40:07 --> Helper loaded: inflector_helper
INFO - 2018-02-20 10:40:07 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-20 10:40:07 --> Model Class Initialized
INFO - 2018-02-20 10:40:07 --> Model Class Initialized
INFO - 2018-02-20 10:40:07 --> Final output sent to browser
DEBUG - 2018-02-20 10:40:07 --> Total execution time: 0.0397
INFO - 2018-02-20 10:40:34 --> Config Class Initialized
INFO - 2018-02-20 10:40:34 --> Hooks Class Initialized
DEBUG - 2018-02-20 10:40:34 --> UTF-8 Support Enabled
INFO - 2018-02-20 10:40:34 --> Utf8 Class Initialized
INFO - 2018-02-20 10:40:34 --> URI Class Initialized
INFO - 2018-02-20 10:40:34 --> Router Class Initialized
INFO - 2018-02-20 10:40:34 --> Output Class Initialized
INFO - 2018-02-20 10:40:34 --> Security Class Initialized
DEBUG - 2018-02-20 10:40:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-20 10:40:34 --> Input Class Initialized
INFO - 2018-02-20 10:40:34 --> Language Class Initialized
INFO - 2018-02-20 10:40:34 --> Loader Class Initialized
INFO - 2018-02-20 10:40:34 --> Helper loaded: url_helper
INFO - 2018-02-20 10:40:34 --> Helper loaded: file_helper
INFO - 2018-02-20 10:40:34 --> Helper loaded: email_helper
INFO - 2018-02-20 10:40:34 --> Helper loaded: common_helper
INFO - 2018-02-20 10:40:34 --> Database Driver Class Initialized
DEBUG - 2018-02-20 10:40:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-20 10:40:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-20 10:40:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-20 10:40:34 --> Pagination Class Initialized
INFO - 2018-02-20 10:40:34 --> Helper loaded: form_helper
INFO - 2018-02-20 10:40:34 --> Form Validation Class Initialized
INFO - 2018-02-20 10:40:34 --> Model Class Initialized
INFO - 2018-02-20 10:40:34 --> Controller Class Initialized
DEBUG - 2018-02-20 10:40:34 --> Config file loaded: /var/www/html/project/radio/application/config/rest.php
INFO - 2018-02-20 10:40:34 --> Helper loaded: inflector_helper
INFO - 2018-02-20 10:40:34 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-20 10:40:34 --> Model Class Initialized
INFO - 2018-02-20 10:40:34 --> Model Class Initialized
INFO - 2018-02-20 10:40:34 --> Final output sent to browser
DEBUG - 2018-02-20 10:40:34 --> Total execution time: 0.0052
INFO - 2018-02-20 10:55:57 --> Config Class Initialized
INFO - 2018-02-20 10:55:57 --> Hooks Class Initialized
DEBUG - 2018-02-20 10:55:57 --> UTF-8 Support Enabled
INFO - 2018-02-20 10:55:57 --> Utf8 Class Initialized
INFO - 2018-02-20 10:55:57 --> URI Class Initialized
INFO - 2018-02-20 10:55:57 --> Router Class Initialized
INFO - 2018-02-20 10:55:57 --> Output Class Initialized
INFO - 2018-02-20 10:55:57 --> Security Class Initialized
DEBUG - 2018-02-20 10:55:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-20 10:55:57 --> Input Class Initialized
INFO - 2018-02-20 10:55:57 --> Language Class Initialized
INFO - 2018-02-20 10:55:57 --> Loader Class Initialized
INFO - 2018-02-20 10:55:57 --> Helper loaded: url_helper
INFO - 2018-02-20 10:55:57 --> Helper loaded: file_helper
INFO - 2018-02-20 10:55:57 --> Helper loaded: email_helper
INFO - 2018-02-20 10:55:57 --> Helper loaded: common_helper
INFO - 2018-02-20 10:55:57 --> Database Driver Class Initialized
DEBUG - 2018-02-20 10:55:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-20 10:55:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-20 10:55:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-20 10:55:57 --> Pagination Class Initialized
INFO - 2018-02-20 10:55:57 --> Helper loaded: form_helper
INFO - 2018-02-20 10:55:57 --> Form Validation Class Initialized
INFO - 2018-02-20 10:55:57 --> Model Class Initialized
INFO - 2018-02-20 10:55:57 --> Controller Class Initialized
DEBUG - 2018-02-20 10:55:57 --> Config file loaded: /var/www/html/project/radio/application/config/rest.php
INFO - 2018-02-20 10:55:57 --> Helper loaded: inflector_helper
INFO - 2018-02-20 10:55:57 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-20 10:55:57 --> Model Class Initialized
INFO - 2018-02-20 10:55:57 --> Model Class Initialized
INFO - 2018-02-20 10:55:57 --> Final output sent to browser
DEBUG - 2018-02-20 10:55:57 --> Total execution time: 0.0049
INFO - 2018-02-20 10:56:31 --> Config Class Initialized
INFO - 2018-02-20 10:56:31 --> Hooks Class Initialized
DEBUG - 2018-02-20 10:56:31 --> UTF-8 Support Enabled
INFO - 2018-02-20 10:56:31 --> Utf8 Class Initialized
INFO - 2018-02-20 10:56:31 --> URI Class Initialized
INFO - 2018-02-20 10:56:31 --> Router Class Initialized
INFO - 2018-02-20 10:56:31 --> Output Class Initialized
INFO - 2018-02-20 10:56:31 --> Security Class Initialized
DEBUG - 2018-02-20 10:56:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-20 10:56:31 --> Input Class Initialized
INFO - 2018-02-20 10:56:31 --> Language Class Initialized
INFO - 2018-02-20 10:56:31 --> Loader Class Initialized
INFO - 2018-02-20 10:56:31 --> Helper loaded: url_helper
INFO - 2018-02-20 10:56:31 --> Helper loaded: file_helper
INFO - 2018-02-20 10:56:31 --> Helper loaded: email_helper
INFO - 2018-02-20 10:56:31 --> Helper loaded: common_helper
INFO - 2018-02-20 10:56:31 --> Database Driver Class Initialized
DEBUG - 2018-02-20 10:56:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-20 10:56:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-20 10:56:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-20 10:56:31 --> Pagination Class Initialized
INFO - 2018-02-20 10:56:31 --> Helper loaded: form_helper
INFO - 2018-02-20 10:56:31 --> Form Validation Class Initialized
INFO - 2018-02-20 10:56:31 --> Model Class Initialized
INFO - 2018-02-20 10:56:31 --> Controller Class Initialized
DEBUG - 2018-02-20 10:56:31 --> Config file loaded: /var/www/html/project/radio/application/config/rest.php
INFO - 2018-02-20 10:56:31 --> Helper loaded: inflector_helper
INFO - 2018-02-20 10:56:31 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-20 10:56:31 --> Model Class Initialized
INFO - 2018-02-20 10:56:31 --> Model Class Initialized
INFO - 2018-02-20 10:56:31 --> Final output sent to browser
DEBUG - 2018-02-20 10:56:31 --> Total execution time: 0.0042
INFO - 2018-02-20 10:56:43 --> Config Class Initialized
INFO - 2018-02-20 10:56:43 --> Hooks Class Initialized
DEBUG - 2018-02-20 10:56:43 --> UTF-8 Support Enabled
INFO - 2018-02-20 10:56:43 --> Utf8 Class Initialized
INFO - 2018-02-20 10:56:43 --> URI Class Initialized
INFO - 2018-02-20 10:56:43 --> Router Class Initialized
INFO - 2018-02-20 10:56:43 --> Output Class Initialized
INFO - 2018-02-20 10:56:43 --> Security Class Initialized
DEBUG - 2018-02-20 10:56:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-20 10:56:43 --> Input Class Initialized
INFO - 2018-02-20 10:56:43 --> Language Class Initialized
INFO - 2018-02-20 10:56:43 --> Loader Class Initialized
INFO - 2018-02-20 10:56:43 --> Helper loaded: url_helper
INFO - 2018-02-20 10:56:43 --> Helper loaded: file_helper
INFO - 2018-02-20 10:56:43 --> Helper loaded: email_helper
INFO - 2018-02-20 10:56:43 --> Helper loaded: common_helper
INFO - 2018-02-20 10:56:43 --> Database Driver Class Initialized
DEBUG - 2018-02-20 10:56:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-20 10:56:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-20 10:56:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-20 10:56:43 --> Pagination Class Initialized
INFO - 2018-02-20 10:56:43 --> Helper loaded: form_helper
INFO - 2018-02-20 10:56:43 --> Form Validation Class Initialized
INFO - 2018-02-20 10:56:43 --> Model Class Initialized
INFO - 2018-02-20 10:56:43 --> Controller Class Initialized
DEBUG - 2018-02-20 10:56:43 --> Config file loaded: /var/www/html/project/radio/application/config/rest.php
INFO - 2018-02-20 10:56:43 --> Helper loaded: inflector_helper
INFO - 2018-02-20 10:56:43 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-20 10:56:43 --> Model Class Initialized
INFO - 2018-02-20 10:56:43 --> Model Class Initialized
INFO - 2018-02-20 10:56:43 --> Final output sent to browser
DEBUG - 2018-02-20 10:56:43 --> Total execution time: 0.0034
INFO - 2018-02-20 10:57:00 --> Config Class Initialized
INFO - 2018-02-20 10:57:00 --> Hooks Class Initialized
DEBUG - 2018-02-20 10:57:00 --> UTF-8 Support Enabled
INFO - 2018-02-20 10:57:00 --> Utf8 Class Initialized
INFO - 2018-02-20 10:57:00 --> URI Class Initialized
INFO - 2018-02-20 10:57:00 --> Router Class Initialized
INFO - 2018-02-20 10:57:00 --> Output Class Initialized
INFO - 2018-02-20 10:57:00 --> Security Class Initialized
DEBUG - 2018-02-20 10:57:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-20 10:57:00 --> Input Class Initialized
INFO - 2018-02-20 10:57:00 --> Language Class Initialized
INFO - 2018-02-20 10:57:00 --> Loader Class Initialized
INFO - 2018-02-20 10:57:00 --> Helper loaded: url_helper
INFO - 2018-02-20 10:57:00 --> Helper loaded: file_helper
INFO - 2018-02-20 10:57:00 --> Helper loaded: email_helper
INFO - 2018-02-20 10:57:00 --> Helper loaded: common_helper
INFO - 2018-02-20 10:57:00 --> Database Driver Class Initialized
DEBUG - 2018-02-20 10:57:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-20 10:57:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-20 10:57:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-20 10:57:00 --> Pagination Class Initialized
INFO - 2018-02-20 10:57:00 --> Helper loaded: form_helper
INFO - 2018-02-20 10:57:00 --> Form Validation Class Initialized
INFO - 2018-02-20 10:57:00 --> Model Class Initialized
INFO - 2018-02-20 10:57:00 --> Controller Class Initialized
DEBUG - 2018-02-20 10:57:00 --> Config file loaded: /var/www/html/project/radio/application/config/rest.php
INFO - 2018-02-20 10:57:00 --> Helper loaded: inflector_helper
INFO - 2018-02-20 10:57:00 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-20 10:57:00 --> Model Class Initialized
INFO - 2018-02-20 10:57:00 --> Model Class Initialized
INFO - 2018-02-20 10:57:00 --> Final output sent to browser
DEBUG - 2018-02-20 10:57:00 --> Total execution time: 0.0051
INFO - 2018-02-20 10:57:06 --> Config Class Initialized
INFO - 2018-02-20 10:57:06 --> Hooks Class Initialized
DEBUG - 2018-02-20 10:57:06 --> UTF-8 Support Enabled
INFO - 2018-02-20 10:57:06 --> Utf8 Class Initialized
INFO - 2018-02-20 10:57:06 --> URI Class Initialized
INFO - 2018-02-20 10:57:06 --> Router Class Initialized
INFO - 2018-02-20 10:57:06 --> Output Class Initialized
INFO - 2018-02-20 10:57:06 --> Security Class Initialized
DEBUG - 2018-02-20 10:57:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-20 10:57:06 --> Input Class Initialized
INFO - 2018-02-20 10:57:06 --> Language Class Initialized
INFO - 2018-02-20 10:57:06 --> Loader Class Initialized
INFO - 2018-02-20 10:57:06 --> Helper loaded: url_helper
INFO - 2018-02-20 10:57:06 --> Helper loaded: file_helper
INFO - 2018-02-20 10:57:06 --> Helper loaded: email_helper
INFO - 2018-02-20 10:57:06 --> Helper loaded: common_helper
INFO - 2018-02-20 10:57:06 --> Database Driver Class Initialized
DEBUG - 2018-02-20 10:57:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-20 10:57:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-20 10:57:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-20 10:57:06 --> Pagination Class Initialized
INFO - 2018-02-20 10:57:06 --> Helper loaded: form_helper
INFO - 2018-02-20 10:57:06 --> Form Validation Class Initialized
INFO - 2018-02-20 10:57:06 --> Model Class Initialized
INFO - 2018-02-20 10:57:06 --> Controller Class Initialized
DEBUG - 2018-02-20 10:57:06 --> Config file loaded: /var/www/html/project/radio/application/config/rest.php
INFO - 2018-02-20 10:57:06 --> Helper loaded: inflector_helper
INFO - 2018-02-20 10:57:06 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-20 10:57:06 --> Model Class Initialized
INFO - 2018-02-20 10:57:06 --> Model Class Initialized
INFO - 2018-02-20 10:57:06 --> Final output sent to browser
DEBUG - 2018-02-20 10:57:06 --> Total execution time: 0.0055
INFO - 2018-02-20 10:57:23 --> Config Class Initialized
INFO - 2018-02-20 10:57:23 --> Hooks Class Initialized
DEBUG - 2018-02-20 10:57:23 --> UTF-8 Support Enabled
INFO - 2018-02-20 10:57:23 --> Utf8 Class Initialized
INFO - 2018-02-20 10:57:23 --> URI Class Initialized
INFO - 2018-02-20 10:57:23 --> Router Class Initialized
INFO - 2018-02-20 10:57:23 --> Output Class Initialized
INFO - 2018-02-20 10:57:23 --> Security Class Initialized
DEBUG - 2018-02-20 10:57:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-20 10:57:23 --> Input Class Initialized
INFO - 2018-02-20 10:57:23 --> Language Class Initialized
INFO - 2018-02-20 10:57:23 --> Loader Class Initialized
INFO - 2018-02-20 10:57:23 --> Helper loaded: url_helper
INFO - 2018-02-20 10:57:23 --> Helper loaded: file_helper
INFO - 2018-02-20 10:57:23 --> Helper loaded: email_helper
INFO - 2018-02-20 10:57:23 --> Helper loaded: common_helper
INFO - 2018-02-20 10:57:23 --> Database Driver Class Initialized
DEBUG - 2018-02-20 10:57:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-20 10:57:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-20 10:57:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-20 10:57:23 --> Pagination Class Initialized
INFO - 2018-02-20 10:57:23 --> Helper loaded: form_helper
INFO - 2018-02-20 10:57:23 --> Form Validation Class Initialized
INFO - 2018-02-20 10:57:23 --> Model Class Initialized
INFO - 2018-02-20 10:57:23 --> Controller Class Initialized
DEBUG - 2018-02-20 10:57:23 --> Config file loaded: /var/www/html/project/radio/application/config/rest.php
INFO - 2018-02-20 10:57:23 --> Helper loaded: inflector_helper
INFO - 2018-02-20 10:57:23 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-20 10:57:23 --> Model Class Initialized
INFO - 2018-02-20 10:57:23 --> Model Class Initialized
INFO - 2018-02-20 10:57:23 --> Final output sent to browser
DEBUG - 2018-02-20 10:57:23 --> Total execution time: 0.0049
INFO - 2018-02-20 10:57:28 --> Config Class Initialized
INFO - 2018-02-20 10:57:28 --> Hooks Class Initialized
DEBUG - 2018-02-20 10:57:28 --> UTF-8 Support Enabled
INFO - 2018-02-20 10:57:28 --> Utf8 Class Initialized
INFO - 2018-02-20 10:57:28 --> URI Class Initialized
INFO - 2018-02-20 10:57:28 --> Router Class Initialized
INFO - 2018-02-20 10:57:28 --> Output Class Initialized
INFO - 2018-02-20 10:57:28 --> Security Class Initialized
DEBUG - 2018-02-20 10:57:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-20 10:57:28 --> Input Class Initialized
INFO - 2018-02-20 10:57:28 --> Language Class Initialized
INFO - 2018-02-20 10:57:28 --> Loader Class Initialized
INFO - 2018-02-20 10:57:28 --> Helper loaded: url_helper
INFO - 2018-02-20 10:57:28 --> Helper loaded: file_helper
INFO - 2018-02-20 10:57:28 --> Helper loaded: email_helper
INFO - 2018-02-20 10:57:28 --> Helper loaded: common_helper
INFO - 2018-02-20 10:57:28 --> Database Driver Class Initialized
DEBUG - 2018-02-20 10:57:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-20 10:57:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-20 10:57:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-20 10:57:28 --> Pagination Class Initialized
INFO - 2018-02-20 10:57:28 --> Helper loaded: form_helper
INFO - 2018-02-20 10:57:28 --> Form Validation Class Initialized
INFO - 2018-02-20 10:57:28 --> Model Class Initialized
INFO - 2018-02-20 10:57:28 --> Controller Class Initialized
DEBUG - 2018-02-20 10:57:28 --> Config file loaded: /var/www/html/project/radio/application/config/rest.php
INFO - 2018-02-20 10:57:28 --> Helper loaded: inflector_helper
INFO - 2018-02-20 10:57:28 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-20 10:57:28 --> Model Class Initialized
INFO - 2018-02-20 10:57:28 --> Model Class Initialized
INFO - 2018-02-20 10:57:28 --> Final output sent to browser
DEBUG - 2018-02-20 10:57:28 --> Total execution time: 0.0058
INFO - 2018-02-20 10:58:48 --> Config Class Initialized
INFO - 2018-02-20 10:58:48 --> Hooks Class Initialized
DEBUG - 2018-02-20 10:58:48 --> UTF-8 Support Enabled
INFO - 2018-02-20 10:58:48 --> Utf8 Class Initialized
INFO - 2018-02-20 10:58:48 --> URI Class Initialized
INFO - 2018-02-20 10:58:48 --> Router Class Initialized
INFO - 2018-02-20 10:58:48 --> Output Class Initialized
INFO - 2018-02-20 10:58:48 --> Security Class Initialized
DEBUG - 2018-02-20 10:58:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-20 10:58:48 --> Input Class Initialized
INFO - 2018-02-20 10:58:48 --> Language Class Initialized
INFO - 2018-02-20 10:58:48 --> Loader Class Initialized
INFO - 2018-02-20 10:58:48 --> Helper loaded: url_helper
INFO - 2018-02-20 10:58:48 --> Helper loaded: file_helper
INFO - 2018-02-20 10:58:48 --> Helper loaded: email_helper
INFO - 2018-02-20 10:58:48 --> Helper loaded: common_helper
INFO - 2018-02-20 10:58:48 --> Database Driver Class Initialized
DEBUG - 2018-02-20 10:58:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-20 10:58:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-20 10:58:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-20 10:58:48 --> Pagination Class Initialized
INFO - 2018-02-20 10:58:48 --> Helper loaded: form_helper
INFO - 2018-02-20 10:58:48 --> Form Validation Class Initialized
INFO - 2018-02-20 10:58:48 --> Model Class Initialized
INFO - 2018-02-20 10:58:48 --> Controller Class Initialized
DEBUG - 2018-02-20 10:58:48 --> Config file loaded: /var/www/html/project/radio/application/config/rest.php
INFO - 2018-02-20 10:58:48 --> Helper loaded: inflector_helper
INFO - 2018-02-20 10:58:48 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-20 10:58:48 --> Model Class Initialized
INFO - 2018-02-20 10:58:48 --> Model Class Initialized
ERROR - 2018-02-20 10:58:48 --> Severity: Notice --> Undefined property: Oauth::$Usermaster_model /var/www/html/project/radio/application/controllers/api/Oauth.php 205
ERROR - 2018-02-20 10:58:48 --> Severity: error --> Exception: Call to a member function updateData() on null /var/www/html/project/radio/application/controllers/api/Oauth.php 205
INFO - 2018-02-20 10:59:13 --> Config Class Initialized
INFO - 2018-02-20 10:59:13 --> Hooks Class Initialized
DEBUG - 2018-02-20 10:59:13 --> UTF-8 Support Enabled
INFO - 2018-02-20 10:59:13 --> Utf8 Class Initialized
INFO - 2018-02-20 10:59:13 --> URI Class Initialized
INFO - 2018-02-20 10:59:13 --> Router Class Initialized
INFO - 2018-02-20 10:59:13 --> Output Class Initialized
INFO - 2018-02-20 10:59:13 --> Security Class Initialized
DEBUG - 2018-02-20 10:59:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-20 10:59:13 --> Input Class Initialized
INFO - 2018-02-20 10:59:13 --> Language Class Initialized
INFO - 2018-02-20 10:59:13 --> Loader Class Initialized
INFO - 2018-02-20 10:59:13 --> Helper loaded: url_helper
INFO - 2018-02-20 10:59:13 --> Helper loaded: file_helper
INFO - 2018-02-20 10:59:13 --> Helper loaded: email_helper
INFO - 2018-02-20 10:59:13 --> Helper loaded: common_helper
INFO - 2018-02-20 10:59:13 --> Database Driver Class Initialized
DEBUG - 2018-02-20 10:59:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-20 10:59:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-20 10:59:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-20 10:59:13 --> Pagination Class Initialized
INFO - 2018-02-20 10:59:13 --> Helper loaded: form_helper
INFO - 2018-02-20 10:59:13 --> Form Validation Class Initialized
INFO - 2018-02-20 10:59:13 --> Model Class Initialized
INFO - 2018-02-20 10:59:13 --> Controller Class Initialized
DEBUG - 2018-02-20 10:59:13 --> Config file loaded: /var/www/html/project/radio/application/config/rest.php
INFO - 2018-02-20 10:59:13 --> Helper loaded: inflector_helper
INFO - 2018-02-20 10:59:13 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-20 10:59:13 --> Model Class Initialized
INFO - 2018-02-20 10:59:13 --> Model Class Initialized
INFO - 2018-02-20 10:59:13 --> Final output sent to browser
DEBUG - 2018-02-20 10:59:13 --> Total execution time: 0.0555
INFO - 2018-02-20 11:01:59 --> Config Class Initialized
INFO - 2018-02-20 11:01:59 --> Hooks Class Initialized
DEBUG - 2018-02-20 11:01:59 --> UTF-8 Support Enabled
INFO - 2018-02-20 11:01:59 --> Utf8 Class Initialized
INFO - 2018-02-20 11:01:59 --> URI Class Initialized
INFO - 2018-02-20 11:01:59 --> Router Class Initialized
INFO - 2018-02-20 11:01:59 --> Output Class Initialized
INFO - 2018-02-20 11:01:59 --> Security Class Initialized
DEBUG - 2018-02-20 11:01:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-20 11:01:59 --> Input Class Initialized
INFO - 2018-02-20 11:01:59 --> Language Class Initialized
INFO - 2018-02-20 11:01:59 --> Loader Class Initialized
INFO - 2018-02-20 11:01:59 --> Helper loaded: url_helper
INFO - 2018-02-20 11:01:59 --> Helper loaded: file_helper
INFO - 2018-02-20 11:01:59 --> Helper loaded: email_helper
INFO - 2018-02-20 11:01:59 --> Helper loaded: common_helper
INFO - 2018-02-20 11:01:59 --> Database Driver Class Initialized
DEBUG - 2018-02-20 11:01:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-20 11:01:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-20 11:01:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-20 11:01:59 --> Pagination Class Initialized
INFO - 2018-02-20 11:01:59 --> Helper loaded: form_helper
INFO - 2018-02-20 11:01:59 --> Form Validation Class Initialized
INFO - 2018-02-20 11:01:59 --> Model Class Initialized
INFO - 2018-02-20 11:01:59 --> Controller Class Initialized
DEBUG - 2018-02-20 11:01:59 --> Config file loaded: /var/www/html/project/radio/application/config/rest.php
INFO - 2018-02-20 11:01:59 --> Helper loaded: inflector_helper
INFO - 2018-02-20 11:01:59 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-20 11:01:59 --> Model Class Initialized
INFO - 2018-02-20 11:01:59 --> Model Class Initialized
INFO - 2018-02-20 11:01:59 --> Final output sent to browser
DEBUG - 2018-02-20 11:01:59 --> Total execution time: 0.0040
INFO - 2018-02-20 11:02:07 --> Config Class Initialized
INFO - 2018-02-20 11:02:07 --> Hooks Class Initialized
DEBUG - 2018-02-20 11:02:07 --> UTF-8 Support Enabled
INFO - 2018-02-20 11:02:07 --> Utf8 Class Initialized
INFO - 2018-02-20 11:02:07 --> URI Class Initialized
INFO - 2018-02-20 11:02:07 --> Router Class Initialized
INFO - 2018-02-20 11:02:07 --> Output Class Initialized
INFO - 2018-02-20 11:02:07 --> Security Class Initialized
DEBUG - 2018-02-20 11:02:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-20 11:02:07 --> Input Class Initialized
INFO - 2018-02-20 11:02:07 --> Language Class Initialized
INFO - 2018-02-20 11:02:07 --> Loader Class Initialized
INFO - 2018-02-20 11:02:07 --> Helper loaded: url_helper
INFO - 2018-02-20 11:02:07 --> Helper loaded: file_helper
INFO - 2018-02-20 11:02:07 --> Helper loaded: email_helper
INFO - 2018-02-20 11:02:07 --> Helper loaded: common_helper
INFO - 2018-02-20 11:02:07 --> Database Driver Class Initialized
DEBUG - 2018-02-20 11:02:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-20 11:02:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-20 11:02:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-20 11:02:07 --> Pagination Class Initialized
INFO - 2018-02-20 11:02:07 --> Helper loaded: form_helper
INFO - 2018-02-20 11:02:07 --> Form Validation Class Initialized
INFO - 2018-02-20 11:02:07 --> Model Class Initialized
INFO - 2018-02-20 11:02:07 --> Controller Class Initialized
DEBUG - 2018-02-20 11:02:07 --> Config file loaded: /var/www/html/project/radio/application/config/rest.php
INFO - 2018-02-20 11:02:07 --> Helper loaded: inflector_helper
INFO - 2018-02-20 11:02:07 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-20 11:02:07 --> Model Class Initialized
INFO - 2018-02-20 11:02:07 --> Model Class Initialized
INFO - 2018-02-20 11:02:07 --> Final output sent to browser
DEBUG - 2018-02-20 11:02:07 --> Total execution time: 0.0449
INFO - 2018-02-20 11:02:11 --> Config Class Initialized
INFO - 2018-02-20 11:02:11 --> Hooks Class Initialized
DEBUG - 2018-02-20 11:02:11 --> UTF-8 Support Enabled
INFO - 2018-02-20 11:02:11 --> Utf8 Class Initialized
INFO - 2018-02-20 11:02:11 --> URI Class Initialized
INFO - 2018-02-20 11:02:11 --> Router Class Initialized
INFO - 2018-02-20 11:02:11 --> Output Class Initialized
INFO - 2018-02-20 11:02:11 --> Security Class Initialized
DEBUG - 2018-02-20 11:02:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-20 11:02:11 --> Input Class Initialized
INFO - 2018-02-20 11:02:11 --> Language Class Initialized
INFO - 2018-02-20 11:02:11 --> Loader Class Initialized
INFO - 2018-02-20 11:02:11 --> Helper loaded: url_helper
INFO - 2018-02-20 11:02:11 --> Helper loaded: file_helper
INFO - 2018-02-20 11:02:11 --> Helper loaded: email_helper
INFO - 2018-02-20 11:02:11 --> Helper loaded: common_helper
INFO - 2018-02-20 11:02:11 --> Database Driver Class Initialized
DEBUG - 2018-02-20 11:02:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-20 11:02:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-20 11:02:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-20 11:02:11 --> Pagination Class Initialized
INFO - 2018-02-20 11:02:11 --> Helper loaded: form_helper
INFO - 2018-02-20 11:02:11 --> Form Validation Class Initialized
INFO - 2018-02-20 11:02:11 --> Model Class Initialized
INFO - 2018-02-20 11:02:11 --> Controller Class Initialized
DEBUG - 2018-02-20 11:02:11 --> Config file loaded: /var/www/html/project/radio/application/config/rest.php
INFO - 2018-02-20 11:02:11 --> Helper loaded: inflector_helper
INFO - 2018-02-20 11:02:11 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-20 11:02:11 --> Model Class Initialized
INFO - 2018-02-20 11:02:11 --> Model Class Initialized
INFO - 2018-02-20 11:02:11 --> Final output sent to browser
DEBUG - 2018-02-20 11:02:11 --> Total execution time: 0.0049
INFO - 2018-02-20 11:02:14 --> Config Class Initialized
INFO - 2018-02-20 11:02:14 --> Hooks Class Initialized
DEBUG - 2018-02-20 11:02:14 --> UTF-8 Support Enabled
INFO - 2018-02-20 11:02:14 --> Utf8 Class Initialized
INFO - 2018-02-20 11:02:14 --> URI Class Initialized
INFO - 2018-02-20 11:02:14 --> Router Class Initialized
INFO - 2018-02-20 11:02:14 --> Output Class Initialized
INFO - 2018-02-20 11:02:14 --> Security Class Initialized
DEBUG - 2018-02-20 11:02:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-20 11:02:14 --> Input Class Initialized
INFO - 2018-02-20 11:02:14 --> Language Class Initialized
INFO - 2018-02-20 11:02:14 --> Loader Class Initialized
INFO - 2018-02-20 11:02:14 --> Helper loaded: url_helper
INFO - 2018-02-20 11:02:14 --> Helper loaded: file_helper
INFO - 2018-02-20 11:02:14 --> Helper loaded: email_helper
INFO - 2018-02-20 11:02:14 --> Helper loaded: common_helper
INFO - 2018-02-20 11:02:14 --> Database Driver Class Initialized
DEBUG - 2018-02-20 11:02:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-20 11:02:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-20 11:02:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-20 11:02:14 --> Pagination Class Initialized
INFO - 2018-02-20 11:02:14 --> Helper loaded: form_helper
INFO - 2018-02-20 11:02:14 --> Form Validation Class Initialized
INFO - 2018-02-20 11:02:14 --> Model Class Initialized
INFO - 2018-02-20 11:02:14 --> Controller Class Initialized
DEBUG - 2018-02-20 11:02:14 --> Config file loaded: /var/www/html/project/radio/application/config/rest.php
INFO - 2018-02-20 11:02:14 --> Helper loaded: inflector_helper
INFO - 2018-02-20 11:02:14 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-20 11:02:14 --> Model Class Initialized
INFO - 2018-02-20 11:02:14 --> Model Class Initialized
INFO - 2018-02-20 11:02:14 --> Final output sent to browser
DEBUG - 2018-02-20 11:02:14 --> Total execution time: 0.0340
INFO - 2018-02-20 11:03:59 --> Config Class Initialized
INFO - 2018-02-20 11:03:59 --> Hooks Class Initialized
DEBUG - 2018-02-20 11:03:59 --> UTF-8 Support Enabled
INFO - 2018-02-20 11:03:59 --> Utf8 Class Initialized
INFO - 2018-02-20 11:03:59 --> URI Class Initialized
INFO - 2018-02-20 11:03:59 --> Router Class Initialized
INFO - 2018-02-20 11:03:59 --> Output Class Initialized
INFO - 2018-02-20 11:03:59 --> Security Class Initialized
DEBUG - 2018-02-20 11:03:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-20 11:03:59 --> Input Class Initialized
INFO - 2018-02-20 11:03:59 --> Language Class Initialized
INFO - 2018-02-20 11:03:59 --> Loader Class Initialized
INFO - 2018-02-20 11:03:59 --> Helper loaded: url_helper
INFO - 2018-02-20 11:03:59 --> Helper loaded: file_helper
INFO - 2018-02-20 11:03:59 --> Helper loaded: email_helper
INFO - 2018-02-20 11:03:59 --> Helper loaded: common_helper
INFO - 2018-02-20 11:03:59 --> Database Driver Class Initialized
DEBUG - 2018-02-20 11:03:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-20 11:03:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-20 11:03:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-20 11:03:59 --> Pagination Class Initialized
INFO - 2018-02-20 11:03:59 --> Helper loaded: form_helper
INFO - 2018-02-20 11:03:59 --> Form Validation Class Initialized
INFO - 2018-02-20 11:03:59 --> Model Class Initialized
INFO - 2018-02-20 11:03:59 --> Controller Class Initialized
INFO - 2018-02-20 11:03:59 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-20 11:03:59 --> Config Class Initialized
INFO - 2018-02-20 11:03:59 --> Hooks Class Initialized
DEBUG - 2018-02-20 11:03:59 --> UTF-8 Support Enabled
INFO - 2018-02-20 11:03:59 --> Utf8 Class Initialized
INFO - 2018-02-20 11:03:59 --> URI Class Initialized
DEBUG - 2018-02-20 11:03:59 --> No URI present. Default controller set.
INFO - 2018-02-20 11:03:59 --> Router Class Initialized
INFO - 2018-02-20 11:03:59 --> Output Class Initialized
INFO - 2018-02-20 11:03:59 --> Security Class Initialized
DEBUG - 2018-02-20 11:03:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-20 11:03:59 --> Input Class Initialized
INFO - 2018-02-20 11:03:59 --> Language Class Initialized
INFO - 2018-02-20 11:03:59 --> Loader Class Initialized
INFO - 2018-02-20 11:03:59 --> Helper loaded: url_helper
INFO - 2018-02-20 11:03:59 --> Helper loaded: file_helper
INFO - 2018-02-20 11:03:59 --> Helper loaded: email_helper
INFO - 2018-02-20 11:03:59 --> Helper loaded: common_helper
INFO - 2018-02-20 11:03:59 --> Database Driver Class Initialized
DEBUG - 2018-02-20 11:03:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-20 11:03:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-20 11:03:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-20 11:03:59 --> Pagination Class Initialized
INFO - 2018-02-20 11:03:59 --> Helper loaded: form_helper
INFO - 2018-02-20 11:03:59 --> Form Validation Class Initialized
INFO - 2018-02-20 11:03:59 --> Model Class Initialized
INFO - 2018-02-20 11:03:59 --> Controller Class Initialized
INFO - 2018-02-20 11:03:59 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-20 11:03:59 --> Model Class Initialized
INFO - 2018-02-20 11:03:59 --> File loaded: /var/www/html/project/radio/application/views/index/index.php
INFO - 2018-02-20 11:03:59 --> Final output sent to browser
DEBUG - 2018-02-20 11:03:59 --> Total execution time: 0.0630
INFO - 2018-02-20 11:04:01 --> Config Class Initialized
INFO - 2018-02-20 11:04:01 --> Hooks Class Initialized
DEBUG - 2018-02-20 11:04:01 --> UTF-8 Support Enabled
INFO - 2018-02-20 11:04:01 --> Utf8 Class Initialized
INFO - 2018-02-20 11:04:01 --> URI Class Initialized
INFO - 2018-02-20 11:04:01 --> Router Class Initialized
INFO - 2018-02-20 11:04:01 --> Output Class Initialized
INFO - 2018-02-20 11:04:01 --> Security Class Initialized
DEBUG - 2018-02-20 11:04:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-20 11:04:01 --> Input Class Initialized
INFO - 2018-02-20 11:04:01 --> Language Class Initialized
INFO - 2018-02-20 11:04:01 --> Loader Class Initialized
INFO - 2018-02-20 11:04:01 --> Helper loaded: url_helper
INFO - 2018-02-20 11:04:01 --> Helper loaded: file_helper
INFO - 2018-02-20 11:04:01 --> Helper loaded: email_helper
INFO - 2018-02-20 11:04:01 --> Helper loaded: common_helper
INFO - 2018-02-20 11:04:01 --> Database Driver Class Initialized
DEBUG - 2018-02-20 11:04:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-20 11:04:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-20 11:04:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-20 11:04:01 --> Pagination Class Initialized
INFO - 2018-02-20 11:04:01 --> Helper loaded: form_helper
INFO - 2018-02-20 11:04:01 --> Form Validation Class Initialized
INFO - 2018-02-20 11:04:01 --> Model Class Initialized
INFO - 2018-02-20 11:04:01 --> Controller Class Initialized
INFO - 2018-02-20 11:04:01 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-20 11:04:01 --> Model Class Initialized
ERROR - 2018-02-20 11:04:01 --> Severity: Notice --> Undefined index: remember_me /var/www/html/project/radio/application/controllers/Index.php 73
INFO - 2018-02-20 11:04:01 --> Config Class Initialized
INFO - 2018-02-20 11:04:01 --> Hooks Class Initialized
DEBUG - 2018-02-20 11:04:01 --> UTF-8 Support Enabled
INFO - 2018-02-20 11:04:01 --> Utf8 Class Initialized
INFO - 2018-02-20 11:04:01 --> URI Class Initialized
INFO - 2018-02-20 11:04:01 --> Router Class Initialized
INFO - 2018-02-20 11:04:01 --> Output Class Initialized
INFO - 2018-02-20 11:04:01 --> Security Class Initialized
DEBUG - 2018-02-20 11:04:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-20 11:04:01 --> Input Class Initialized
INFO - 2018-02-20 11:04:01 --> Language Class Initialized
INFO - 2018-02-20 11:04:01 --> Loader Class Initialized
INFO - 2018-02-20 11:04:01 --> Helper loaded: url_helper
INFO - 2018-02-20 11:04:01 --> Helper loaded: file_helper
INFO - 2018-02-20 11:04:01 --> Helper loaded: email_helper
INFO - 2018-02-20 11:04:01 --> Helper loaded: common_helper
INFO - 2018-02-20 11:04:01 --> Database Driver Class Initialized
DEBUG - 2018-02-20 11:04:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-20 11:04:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-20 11:04:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-20 11:04:01 --> Pagination Class Initialized
INFO - 2018-02-20 11:04:01 --> Helper loaded: form_helper
INFO - 2018-02-20 11:04:01 --> Form Validation Class Initialized
INFO - 2018-02-20 11:04:01 --> Model Class Initialized
INFO - 2018-02-20 11:04:01 --> Controller Class Initialized
INFO - 2018-02-20 11:04:01 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-20 11:04:01 --> Model Class Initialized
INFO - 2018-02-20 11:04:01 --> Model Class Initialized
INFO - 2018-02-20 11:04:01 --> Model Class Initialized
INFO - 2018-02-20 11:04:01 --> Model Class Initialized
INFO - 2018-02-20 11:04:01 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-20 11:04:01 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-20 11:04:01 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-20 11:04:01 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-20 11:04:01 --> File loaded: /var/www/html/project/radio/application/views/dashboard/index.php
INFO - 2018-02-20 11:04:01 --> Final output sent to browser
DEBUG - 2018-02-20 11:04:01 --> Total execution time: 0.0922
INFO - 2018-02-20 11:04:03 --> Config Class Initialized
INFO - 2018-02-20 11:04:03 --> Hooks Class Initialized
DEBUG - 2018-02-20 11:04:03 --> UTF-8 Support Enabled
INFO - 2018-02-20 11:04:03 --> Utf8 Class Initialized
INFO - 2018-02-20 11:04:03 --> URI Class Initialized
INFO - 2018-02-20 11:04:03 --> Router Class Initialized
INFO - 2018-02-20 11:04:03 --> Output Class Initialized
INFO - 2018-02-20 11:04:03 --> Security Class Initialized
DEBUG - 2018-02-20 11:04:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-20 11:04:03 --> Input Class Initialized
INFO - 2018-02-20 11:04:03 --> Language Class Initialized
INFO - 2018-02-20 11:04:03 --> Loader Class Initialized
INFO - 2018-02-20 11:04:03 --> Helper loaded: url_helper
INFO - 2018-02-20 11:04:03 --> Helper loaded: file_helper
INFO - 2018-02-20 11:04:03 --> Helper loaded: email_helper
INFO - 2018-02-20 11:04:03 --> Helper loaded: common_helper
INFO - 2018-02-20 11:04:03 --> Database Driver Class Initialized
DEBUG - 2018-02-20 11:04:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-20 11:04:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-20 11:04:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-20 11:04:03 --> Pagination Class Initialized
INFO - 2018-02-20 11:04:03 --> Helper loaded: form_helper
INFO - 2018-02-20 11:04:03 --> Form Validation Class Initialized
INFO - 2018-02-20 11:04:03 --> Model Class Initialized
INFO - 2018-02-20 11:04:03 --> Controller Class Initialized
INFO - 2018-02-20 11:04:03 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-20 11:04:03 --> Model Class Initialized
INFO - 2018-02-20 11:04:03 --> Model Class Initialized
INFO - 2018-02-20 11:04:03 --> Model Class Initialized
INFO - 2018-02-20 11:04:03 --> Model Class Initialized
INFO - 2018-02-20 11:04:03 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-20 11:04:03 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-20 11:04:03 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-20 11:04:03 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-20 11:04:03 --> File loaded: /var/www/html/project/radio/application/views/tracks/index.php
INFO - 2018-02-20 11:04:03 --> Final output sent to browser
DEBUG - 2018-02-20 11:04:03 --> Total execution time: 0.0243
INFO - 2018-02-20 11:04:04 --> Config Class Initialized
INFO - 2018-02-20 11:04:04 --> Hooks Class Initialized
DEBUG - 2018-02-20 11:04:04 --> UTF-8 Support Enabled
INFO - 2018-02-20 11:04:04 --> Utf8 Class Initialized
INFO - 2018-02-20 11:04:04 --> URI Class Initialized
INFO - 2018-02-20 11:04:04 --> Router Class Initialized
INFO - 2018-02-20 11:04:04 --> Output Class Initialized
INFO - 2018-02-20 11:04:04 --> Security Class Initialized
DEBUG - 2018-02-20 11:04:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-20 11:04:04 --> Input Class Initialized
INFO - 2018-02-20 11:04:04 --> Language Class Initialized
INFO - 2018-02-20 11:04:04 --> Loader Class Initialized
INFO - 2018-02-20 11:04:04 --> Helper loaded: url_helper
INFO - 2018-02-20 11:04:04 --> Helper loaded: file_helper
INFO - 2018-02-20 11:04:04 --> Helper loaded: email_helper
INFO - 2018-02-20 11:04:04 --> Helper loaded: common_helper
INFO - 2018-02-20 11:04:04 --> Database Driver Class Initialized
DEBUG - 2018-02-20 11:04:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-20 11:04:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-20 11:04:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-20 11:04:04 --> Pagination Class Initialized
INFO - 2018-02-20 11:04:04 --> Helper loaded: form_helper
INFO - 2018-02-20 11:04:04 --> Form Validation Class Initialized
INFO - 2018-02-20 11:04:04 --> Model Class Initialized
INFO - 2018-02-20 11:04:04 --> Controller Class Initialized
INFO - 2018-02-20 11:04:04 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-20 11:04:04 --> Model Class Initialized
INFO - 2018-02-20 11:04:04 --> Model Class Initialized
INFO - 2018-02-20 11:04:04 --> Model Class Initialized
INFO - 2018-02-20 11:04:04 --> Model Class Initialized
INFO - 2018-02-20 11:31:00 --> Config Class Initialized
INFO - 2018-02-20 11:31:00 --> Hooks Class Initialized
DEBUG - 2018-02-20 11:31:00 --> UTF-8 Support Enabled
INFO - 2018-02-20 11:31:00 --> Utf8 Class Initialized
INFO - 2018-02-20 11:31:00 --> URI Class Initialized
INFO - 2018-02-20 11:31:00 --> Router Class Initialized
INFO - 2018-02-20 11:31:00 --> Output Class Initialized
INFO - 2018-02-20 11:31:00 --> Security Class Initialized
DEBUG - 2018-02-20 11:31:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-20 11:31:00 --> Input Class Initialized
INFO - 2018-02-20 11:31:00 --> Language Class Initialized
INFO - 2018-02-20 11:31:00 --> Loader Class Initialized
INFO - 2018-02-20 11:31:00 --> Helper loaded: url_helper
INFO - 2018-02-20 11:31:00 --> Helper loaded: file_helper
INFO - 2018-02-20 11:31:00 --> Helper loaded: email_helper
INFO - 2018-02-20 11:31:00 --> Helper loaded: common_helper
INFO - 2018-02-20 11:31:00 --> Database Driver Class Initialized
DEBUG - 2018-02-20 11:31:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-20 11:31:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-20 11:31:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-20 11:31:00 --> Pagination Class Initialized
INFO - 2018-02-20 11:31:00 --> Helper loaded: form_helper
INFO - 2018-02-20 11:31:00 --> Form Validation Class Initialized
INFO - 2018-02-20 11:31:00 --> Model Class Initialized
INFO - 2018-02-20 11:31:00 --> Controller Class Initialized
DEBUG - 2018-02-20 11:31:00 --> Config file loaded: /var/www/html/project/radio/application/config/rest.php
INFO - 2018-02-20 11:31:00 --> Helper loaded: inflector_helper
INFO - 2018-02-20 11:31:00 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-20 11:31:00 --> Model Class Initialized
INFO - 2018-02-20 11:31:00 --> Model Class Initialized
INFO - 2018-02-20 11:31:00 --> Final output sent to browser
DEBUG - 2018-02-20 11:31:00 --> Total execution time: 0.0075
INFO - 2018-02-20 11:31:04 --> Config Class Initialized
INFO - 2018-02-20 11:31:04 --> Hooks Class Initialized
DEBUG - 2018-02-20 11:31:04 --> UTF-8 Support Enabled
INFO - 2018-02-20 11:31:04 --> Utf8 Class Initialized
INFO - 2018-02-20 11:31:04 --> URI Class Initialized
INFO - 2018-02-20 11:31:04 --> Router Class Initialized
INFO - 2018-02-20 11:31:04 --> Output Class Initialized
INFO - 2018-02-20 11:31:04 --> Security Class Initialized
DEBUG - 2018-02-20 11:31:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-20 11:31:04 --> Input Class Initialized
INFO - 2018-02-20 11:31:04 --> Language Class Initialized
INFO - 2018-02-20 11:31:04 --> Loader Class Initialized
INFO - 2018-02-20 11:31:04 --> Helper loaded: url_helper
INFO - 2018-02-20 11:31:04 --> Helper loaded: file_helper
INFO - 2018-02-20 11:31:04 --> Helper loaded: email_helper
INFO - 2018-02-20 11:31:04 --> Helper loaded: common_helper
INFO - 2018-02-20 11:31:04 --> Database Driver Class Initialized
DEBUG - 2018-02-20 11:31:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-20 11:31:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-20 11:31:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-20 11:31:04 --> Pagination Class Initialized
INFO - 2018-02-20 11:31:04 --> Helper loaded: form_helper
INFO - 2018-02-20 11:31:04 --> Form Validation Class Initialized
INFO - 2018-02-20 11:31:04 --> Model Class Initialized
INFO - 2018-02-20 11:31:04 --> Controller Class Initialized
DEBUG - 2018-02-20 11:31:04 --> Config file loaded: /var/www/html/project/radio/application/config/rest.php
INFO - 2018-02-20 11:31:04 --> Helper loaded: inflector_helper
INFO - 2018-02-20 11:31:04 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-20 11:31:04 --> Model Class Initialized
INFO - 2018-02-20 11:31:04 --> Model Class Initialized
INFO - 2018-02-20 11:31:04 --> Final output sent to browser
DEBUG - 2018-02-20 11:31:04 --> Total execution time: 0.0051
INFO - 2018-02-20 11:31:28 --> Config Class Initialized
INFO - 2018-02-20 11:31:28 --> Hooks Class Initialized
DEBUG - 2018-02-20 11:31:28 --> UTF-8 Support Enabled
INFO - 2018-02-20 11:31:28 --> Utf8 Class Initialized
INFO - 2018-02-20 11:31:28 --> URI Class Initialized
INFO - 2018-02-20 11:31:28 --> Router Class Initialized
INFO - 2018-02-20 11:31:28 --> Output Class Initialized
INFO - 2018-02-20 11:31:28 --> Security Class Initialized
DEBUG - 2018-02-20 11:31:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-20 11:31:28 --> Input Class Initialized
INFO - 2018-02-20 11:31:28 --> Language Class Initialized
INFO - 2018-02-20 11:31:28 --> Loader Class Initialized
INFO - 2018-02-20 11:31:28 --> Helper loaded: url_helper
INFO - 2018-02-20 11:31:28 --> Helper loaded: file_helper
INFO - 2018-02-20 11:31:28 --> Helper loaded: email_helper
INFO - 2018-02-20 11:31:28 --> Helper loaded: common_helper
INFO - 2018-02-20 11:31:28 --> Database Driver Class Initialized
DEBUG - 2018-02-20 11:31:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-20 11:31:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-20 11:31:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-20 11:31:28 --> Pagination Class Initialized
INFO - 2018-02-20 11:31:28 --> Helper loaded: form_helper
INFO - 2018-02-20 11:31:28 --> Form Validation Class Initialized
INFO - 2018-02-20 11:31:28 --> Model Class Initialized
INFO - 2018-02-20 11:31:28 --> Controller Class Initialized
DEBUG - 2018-02-20 11:31:28 --> Config file loaded: /var/www/html/project/radio/application/config/rest.php
INFO - 2018-02-20 11:31:28 --> Helper loaded: inflector_helper
INFO - 2018-02-20 11:31:28 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-20 11:31:28 --> Model Class Initialized
INFO - 2018-02-20 11:31:28 --> Model Class Initialized
INFO - 2018-02-20 11:31:28 --> Final output sent to browser
DEBUG - 2018-02-20 11:31:28 --> Total execution time: 0.0345
INFO - 2018-02-20 11:31:28 --> Config Class Initialized
INFO - 2018-02-20 11:31:28 --> Hooks Class Initialized
DEBUG - 2018-02-20 11:31:28 --> UTF-8 Support Enabled
INFO - 2018-02-20 11:31:28 --> Utf8 Class Initialized
INFO - 2018-02-20 11:31:28 --> URI Class Initialized
INFO - 2018-02-20 11:31:28 --> Router Class Initialized
INFO - 2018-02-20 11:31:28 --> Output Class Initialized
INFO - 2018-02-20 11:31:28 --> Security Class Initialized
DEBUG - 2018-02-20 11:31:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-20 11:31:28 --> Input Class Initialized
INFO - 2018-02-20 11:31:28 --> Language Class Initialized
INFO - 2018-02-20 11:31:28 --> Loader Class Initialized
INFO - 2018-02-20 11:31:28 --> Helper loaded: url_helper
INFO - 2018-02-20 11:31:28 --> Helper loaded: file_helper
INFO - 2018-02-20 11:31:28 --> Helper loaded: email_helper
INFO - 2018-02-20 11:31:28 --> Helper loaded: common_helper
INFO - 2018-02-20 11:31:28 --> Database Driver Class Initialized
DEBUG - 2018-02-20 11:31:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-20 11:31:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-20 11:31:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-20 11:31:28 --> Pagination Class Initialized
INFO - 2018-02-20 11:31:28 --> Helper loaded: form_helper
INFO - 2018-02-20 11:31:28 --> Form Validation Class Initialized
INFO - 2018-02-20 11:31:28 --> Model Class Initialized
INFO - 2018-02-20 11:31:28 --> Controller Class Initialized
DEBUG - 2018-02-20 11:31:28 --> Config file loaded: /var/www/html/project/radio/application/config/rest.php
INFO - 2018-02-20 11:31:28 --> Helper loaded: inflector_helper
INFO - 2018-02-20 11:31:28 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-20 11:31:28 --> Model Class Initialized
INFO - 2018-02-20 11:31:28 --> Model Class Initialized
INFO - 2018-02-20 11:31:28 --> Model Class Initialized
INFO - 2018-02-20 11:31:28 --> Email Class Initialized
INFO - 2018-02-20 11:31:29 --> Language file loaded: language/english/email_lang.php
INFO - 2018-02-20 11:31:33 --> Final output sent to browser
DEBUG - 2018-02-20 11:31:33 --> Total execution time: 5.0306
INFO - 2018-02-20 11:34:28 --> Config Class Initialized
INFO - 2018-02-20 11:34:28 --> Hooks Class Initialized
DEBUG - 2018-02-20 11:34:28 --> UTF-8 Support Enabled
INFO - 2018-02-20 11:34:28 --> Utf8 Class Initialized
INFO - 2018-02-20 11:34:28 --> URI Class Initialized
INFO - 2018-02-20 11:34:28 --> Router Class Initialized
INFO - 2018-02-20 11:34:28 --> Output Class Initialized
INFO - 2018-02-20 11:34:28 --> Security Class Initialized
DEBUG - 2018-02-20 11:34:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-20 11:34:28 --> Input Class Initialized
INFO - 2018-02-20 11:34:28 --> Language Class Initialized
INFO - 2018-02-20 11:34:28 --> Loader Class Initialized
INFO - 2018-02-20 11:34:28 --> Helper loaded: url_helper
INFO - 2018-02-20 11:34:28 --> Helper loaded: file_helper
INFO - 2018-02-20 11:34:28 --> Helper loaded: email_helper
INFO - 2018-02-20 11:34:28 --> Helper loaded: common_helper
INFO - 2018-02-20 11:34:28 --> Database Driver Class Initialized
DEBUG - 2018-02-20 11:34:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-20 11:34:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-20 11:34:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-20 11:34:28 --> Pagination Class Initialized
INFO - 2018-02-20 11:34:28 --> Helper loaded: form_helper
INFO - 2018-02-20 11:34:28 --> Form Validation Class Initialized
INFO - 2018-02-20 11:34:28 --> Model Class Initialized
INFO - 2018-02-20 11:34:28 --> Controller Class Initialized
INFO - 2018-02-20 11:34:28 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-20 11:34:28 --> Model Class Initialized
INFO - 2018-02-20 11:34:28 --> Model Class Initialized
INFO - 2018-02-20 11:34:28 --> File loaded: /var/www/html/project/radio/application/views/index/resetPassword.php
INFO - 2018-02-20 11:34:28 --> Final output sent to browser
DEBUG - 2018-02-20 11:34:28 --> Total execution time: 0.0054
INFO - 2018-02-20 11:34:45 --> Config Class Initialized
INFO - 2018-02-20 11:34:45 --> Hooks Class Initialized
DEBUG - 2018-02-20 11:34:45 --> UTF-8 Support Enabled
INFO - 2018-02-20 11:34:45 --> Utf8 Class Initialized
INFO - 2018-02-20 11:34:45 --> URI Class Initialized
INFO - 2018-02-20 11:34:45 --> Router Class Initialized
INFO - 2018-02-20 11:34:45 --> Output Class Initialized
INFO - 2018-02-20 11:34:45 --> Security Class Initialized
DEBUG - 2018-02-20 11:34:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-20 11:34:45 --> Input Class Initialized
INFO - 2018-02-20 11:34:45 --> Language Class Initialized
INFO - 2018-02-20 11:34:45 --> Loader Class Initialized
INFO - 2018-02-20 11:34:45 --> Helper loaded: url_helper
INFO - 2018-02-20 11:34:45 --> Helper loaded: file_helper
INFO - 2018-02-20 11:34:45 --> Helper loaded: email_helper
INFO - 2018-02-20 11:34:45 --> Helper loaded: common_helper
INFO - 2018-02-20 11:34:45 --> Database Driver Class Initialized
DEBUG - 2018-02-20 11:34:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-20 11:34:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-20 11:34:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-20 11:34:45 --> Pagination Class Initialized
INFO - 2018-02-20 11:34:45 --> Helper loaded: form_helper
INFO - 2018-02-20 11:34:45 --> Form Validation Class Initialized
INFO - 2018-02-20 11:34:45 --> Model Class Initialized
INFO - 2018-02-20 11:34:45 --> Controller Class Initialized
INFO - 2018-02-20 11:34:45 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-20 11:34:45 --> Model Class Initialized
INFO - 2018-02-20 11:34:45 --> Model Class Initialized
INFO - 2018-02-20 11:34:45 --> File loaded: /var/www/html/project/radio/application/views/index/resetPassword.php
INFO - 2018-02-20 11:34:45 --> Final output sent to browser
DEBUG - 2018-02-20 11:34:45 --> Total execution time: 0.0046
INFO - 2018-02-20 11:35:38 --> Config Class Initialized
INFO - 2018-02-20 11:35:38 --> Hooks Class Initialized
DEBUG - 2018-02-20 11:35:38 --> UTF-8 Support Enabled
INFO - 2018-02-20 11:35:38 --> Utf8 Class Initialized
INFO - 2018-02-20 11:35:38 --> URI Class Initialized
INFO - 2018-02-20 11:35:38 --> Router Class Initialized
INFO - 2018-02-20 11:35:38 --> Output Class Initialized
INFO - 2018-02-20 11:35:38 --> Security Class Initialized
DEBUG - 2018-02-20 11:35:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-20 11:35:38 --> Input Class Initialized
INFO - 2018-02-20 11:35:38 --> Language Class Initialized
INFO - 2018-02-20 11:35:38 --> Loader Class Initialized
INFO - 2018-02-20 11:35:38 --> Helper loaded: url_helper
INFO - 2018-02-20 11:35:38 --> Helper loaded: file_helper
INFO - 2018-02-20 11:35:38 --> Helper loaded: email_helper
INFO - 2018-02-20 11:35:38 --> Helper loaded: common_helper
INFO - 2018-02-20 11:35:38 --> Database Driver Class Initialized
DEBUG - 2018-02-20 11:35:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-20 11:35:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-20 11:35:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-20 11:35:38 --> Pagination Class Initialized
INFO - 2018-02-20 11:35:38 --> Helper loaded: form_helper
INFO - 2018-02-20 11:35:38 --> Form Validation Class Initialized
INFO - 2018-02-20 11:35:38 --> Model Class Initialized
INFO - 2018-02-20 11:35:38 --> Controller Class Initialized
INFO - 2018-02-20 11:35:38 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-20 11:35:38 --> Model Class Initialized
INFO - 2018-02-20 11:35:38 --> Model Class Initialized
INFO - 2018-02-20 11:35:38 --> File loaded: /var/www/html/project/radio/application/views/index/resetPassword.php
INFO - 2018-02-20 11:35:38 --> Final output sent to browser
DEBUG - 2018-02-20 11:35:38 --> Total execution time: 0.0047
INFO - 2018-02-20 11:35:47 --> Config Class Initialized
INFO - 2018-02-20 11:35:47 --> Hooks Class Initialized
DEBUG - 2018-02-20 11:35:47 --> UTF-8 Support Enabled
INFO - 2018-02-20 11:35:47 --> Utf8 Class Initialized
INFO - 2018-02-20 11:35:47 --> URI Class Initialized
INFO - 2018-02-20 11:35:47 --> Router Class Initialized
INFO - 2018-02-20 11:35:47 --> Output Class Initialized
INFO - 2018-02-20 11:35:47 --> Security Class Initialized
DEBUG - 2018-02-20 11:35:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-20 11:35:47 --> Input Class Initialized
INFO - 2018-02-20 11:35:47 --> Language Class Initialized
INFO - 2018-02-20 11:35:47 --> Loader Class Initialized
INFO - 2018-02-20 11:35:47 --> Helper loaded: url_helper
INFO - 2018-02-20 11:35:47 --> Helper loaded: file_helper
INFO - 2018-02-20 11:35:47 --> Helper loaded: email_helper
INFO - 2018-02-20 11:35:47 --> Helper loaded: common_helper
INFO - 2018-02-20 11:35:47 --> Database Driver Class Initialized
DEBUG - 2018-02-20 11:35:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-20 11:35:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-20 11:35:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-20 11:35:47 --> Pagination Class Initialized
INFO - 2018-02-20 11:35:47 --> Helper loaded: form_helper
INFO - 2018-02-20 11:35:47 --> Form Validation Class Initialized
INFO - 2018-02-20 11:35:47 --> Model Class Initialized
INFO - 2018-02-20 11:35:47 --> Controller Class Initialized
INFO - 2018-02-20 11:35:47 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-20 11:35:47 --> Model Class Initialized
INFO - 2018-02-20 11:35:47 --> Model Class Initialized
INFO - 2018-02-20 11:35:47 --> File loaded: /var/www/html/project/radio/application/views/index/resetPassword.php
INFO - 2018-02-20 11:35:47 --> Final output sent to browser
DEBUG - 2018-02-20 11:35:47 --> Total execution time: 0.0061
INFO - 2018-02-20 11:36:18 --> Config Class Initialized
INFO - 2018-02-20 11:36:18 --> Hooks Class Initialized
DEBUG - 2018-02-20 11:36:18 --> UTF-8 Support Enabled
INFO - 2018-02-20 11:36:18 --> Utf8 Class Initialized
INFO - 2018-02-20 11:36:18 --> URI Class Initialized
INFO - 2018-02-20 11:36:18 --> Router Class Initialized
INFO - 2018-02-20 11:36:18 --> Output Class Initialized
INFO - 2018-02-20 11:36:18 --> Security Class Initialized
DEBUG - 2018-02-20 11:36:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-20 11:36:18 --> Input Class Initialized
INFO - 2018-02-20 11:36:18 --> Language Class Initialized
INFO - 2018-02-20 11:36:18 --> Loader Class Initialized
INFO - 2018-02-20 11:36:18 --> Helper loaded: url_helper
INFO - 2018-02-20 11:36:18 --> Helper loaded: file_helper
INFO - 2018-02-20 11:36:18 --> Helper loaded: email_helper
INFO - 2018-02-20 11:36:18 --> Helper loaded: common_helper
INFO - 2018-02-20 11:36:18 --> Database Driver Class Initialized
DEBUG - 2018-02-20 11:36:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-20 11:36:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-20 11:36:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-20 11:36:18 --> Pagination Class Initialized
INFO - 2018-02-20 11:36:18 --> Helper loaded: form_helper
INFO - 2018-02-20 11:36:18 --> Form Validation Class Initialized
INFO - 2018-02-20 11:36:18 --> Model Class Initialized
INFO - 2018-02-20 11:36:18 --> Controller Class Initialized
INFO - 2018-02-20 11:36:18 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-20 11:36:18 --> Model Class Initialized
INFO - 2018-02-20 11:36:18 --> Model Class Initialized
INFO - 2018-02-20 11:36:18 --> File loaded: /var/www/html/project/radio/application/views/index/resetPassword.php
INFO - 2018-02-20 11:36:18 --> Final output sent to browser
DEBUG - 2018-02-20 11:36:18 --> Total execution time: 0.0066
INFO - 2018-02-20 11:36:21 --> Config Class Initialized
INFO - 2018-02-20 11:36:21 --> Hooks Class Initialized
DEBUG - 2018-02-20 11:36:21 --> UTF-8 Support Enabled
INFO - 2018-02-20 11:36:21 --> Utf8 Class Initialized
INFO - 2018-02-20 11:36:21 --> URI Class Initialized
INFO - 2018-02-20 11:36:21 --> Router Class Initialized
INFO - 2018-02-20 11:36:21 --> Output Class Initialized
INFO - 2018-02-20 11:36:21 --> Security Class Initialized
DEBUG - 2018-02-20 11:36:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-20 11:36:21 --> Input Class Initialized
INFO - 2018-02-20 11:36:21 --> Language Class Initialized
INFO - 2018-02-20 11:36:21 --> Loader Class Initialized
INFO - 2018-02-20 11:36:21 --> Helper loaded: url_helper
INFO - 2018-02-20 11:36:21 --> Helper loaded: file_helper
INFO - 2018-02-20 11:36:21 --> Helper loaded: email_helper
INFO - 2018-02-20 11:36:21 --> Helper loaded: common_helper
INFO - 2018-02-20 11:36:21 --> Database Driver Class Initialized
DEBUG - 2018-02-20 11:36:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-20 11:36:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-20 11:36:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-20 11:36:21 --> Pagination Class Initialized
INFO - 2018-02-20 11:36:21 --> Helper loaded: form_helper
INFO - 2018-02-20 11:36:21 --> Form Validation Class Initialized
INFO - 2018-02-20 11:36:21 --> Model Class Initialized
INFO - 2018-02-20 11:36:21 --> Controller Class Initialized
INFO - 2018-02-20 11:36:21 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-20 11:36:21 --> Model Class Initialized
INFO - 2018-02-20 11:36:21 --> Model Class Initialized
INFO - 2018-02-20 11:36:21 --> File loaded: /var/www/html/project/radio/application/views/index/resetPassword.php
INFO - 2018-02-20 11:36:21 --> Final output sent to browser
DEBUG - 2018-02-20 11:36:21 --> Total execution time: 0.0895
INFO - 2018-02-20 11:36:25 --> Config Class Initialized
INFO - 2018-02-20 11:36:25 --> Hooks Class Initialized
DEBUG - 2018-02-20 11:36:25 --> UTF-8 Support Enabled
INFO - 2018-02-20 11:36:25 --> Utf8 Class Initialized
INFO - 2018-02-20 11:36:25 --> URI Class Initialized
INFO - 2018-02-20 11:36:25 --> Router Class Initialized
INFO - 2018-02-20 11:36:25 --> Output Class Initialized
INFO - 2018-02-20 11:36:25 --> Security Class Initialized
DEBUG - 2018-02-20 11:36:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-20 11:36:25 --> Input Class Initialized
INFO - 2018-02-20 11:36:25 --> Language Class Initialized
INFO - 2018-02-20 11:36:25 --> Loader Class Initialized
INFO - 2018-02-20 11:36:25 --> Helper loaded: url_helper
INFO - 2018-02-20 11:36:25 --> Helper loaded: file_helper
INFO - 2018-02-20 11:36:25 --> Helper loaded: email_helper
INFO - 2018-02-20 11:36:25 --> Helper loaded: common_helper
INFO - 2018-02-20 11:36:25 --> Database Driver Class Initialized
DEBUG - 2018-02-20 11:36:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-20 11:36:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-20 11:36:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-20 11:36:25 --> Pagination Class Initialized
INFO - 2018-02-20 11:36:25 --> Helper loaded: form_helper
INFO - 2018-02-20 11:36:25 --> Form Validation Class Initialized
INFO - 2018-02-20 11:36:25 --> Model Class Initialized
INFO - 2018-02-20 11:36:25 --> Controller Class Initialized
INFO - 2018-02-20 11:36:25 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-20 11:36:25 --> Model Class Initialized
INFO - 2018-02-20 11:36:25 --> Model Class Initialized
INFO - 2018-02-20 11:36:25 --> File loaded: /var/www/html/project/radio/application/views/index/resetPassword.php
INFO - 2018-02-20 11:36:25 --> Final output sent to browser
DEBUG - 2018-02-20 11:36:25 --> Total execution time: 0.0050
INFO - 2018-02-20 11:37:37 --> Config Class Initialized
INFO - 2018-02-20 11:37:37 --> Hooks Class Initialized
DEBUG - 2018-02-20 11:37:37 --> UTF-8 Support Enabled
INFO - 2018-02-20 11:37:37 --> Utf8 Class Initialized
INFO - 2018-02-20 11:37:37 --> URI Class Initialized
INFO - 2018-02-20 11:37:37 --> Router Class Initialized
INFO - 2018-02-20 11:37:37 --> Output Class Initialized
INFO - 2018-02-20 11:37:37 --> Security Class Initialized
DEBUG - 2018-02-20 11:37:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-20 11:37:37 --> Input Class Initialized
INFO - 2018-02-20 11:37:37 --> Language Class Initialized
INFO - 2018-02-20 11:37:37 --> Loader Class Initialized
INFO - 2018-02-20 11:37:37 --> Helper loaded: url_helper
INFO - 2018-02-20 11:37:37 --> Helper loaded: file_helper
INFO - 2018-02-20 11:37:37 --> Helper loaded: email_helper
INFO - 2018-02-20 11:37:37 --> Helper loaded: common_helper
INFO - 2018-02-20 11:37:37 --> Database Driver Class Initialized
DEBUG - 2018-02-20 11:37:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-20 11:37:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-20 11:37:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-20 11:37:37 --> Pagination Class Initialized
INFO - 2018-02-20 11:37:37 --> Helper loaded: form_helper
INFO - 2018-02-20 11:37:37 --> Form Validation Class Initialized
INFO - 2018-02-20 11:37:37 --> Model Class Initialized
INFO - 2018-02-20 11:37:37 --> Controller Class Initialized
INFO - 2018-02-20 11:37:37 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-20 11:37:37 --> Model Class Initialized
INFO - 2018-02-20 11:37:37 --> Model Class Initialized
INFO - 2018-02-20 11:37:37 --> File loaded: /var/www/html/project/radio/application/views/index/resetPassword.php
INFO - 2018-02-20 11:37:37 --> Final output sent to browser
DEBUG - 2018-02-20 11:37:37 --> Total execution time: 0.0075
INFO - 2018-02-20 11:37:45 --> Config Class Initialized
INFO - 2018-02-20 11:37:45 --> Hooks Class Initialized
DEBUG - 2018-02-20 11:37:45 --> UTF-8 Support Enabled
INFO - 2018-02-20 11:37:45 --> Utf8 Class Initialized
INFO - 2018-02-20 11:37:45 --> URI Class Initialized
INFO - 2018-02-20 11:37:45 --> Router Class Initialized
INFO - 2018-02-20 11:37:45 --> Output Class Initialized
INFO - 2018-02-20 11:37:45 --> Security Class Initialized
DEBUG - 2018-02-20 11:37:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-20 11:37:45 --> Input Class Initialized
INFO - 2018-02-20 11:37:45 --> Language Class Initialized
INFO - 2018-02-20 11:37:45 --> Loader Class Initialized
INFO - 2018-02-20 11:37:45 --> Helper loaded: url_helper
INFO - 2018-02-20 11:37:45 --> Helper loaded: file_helper
INFO - 2018-02-20 11:37:45 --> Helper loaded: email_helper
INFO - 2018-02-20 11:37:45 --> Helper loaded: common_helper
INFO - 2018-02-20 11:37:45 --> Database Driver Class Initialized
DEBUG - 2018-02-20 11:37:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-20 11:37:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-20 11:37:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-20 11:37:45 --> Pagination Class Initialized
INFO - 2018-02-20 11:37:45 --> Helper loaded: form_helper
INFO - 2018-02-20 11:37:45 --> Form Validation Class Initialized
INFO - 2018-02-20 11:37:45 --> Model Class Initialized
INFO - 2018-02-20 11:37:45 --> Controller Class Initialized
DEBUG - 2018-02-20 11:37:45 --> Config file loaded: /var/www/html/project/radio/application/config/rest.php
INFO - 2018-02-20 11:37:45 --> Helper loaded: inflector_helper
INFO - 2018-02-20 11:37:45 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-20 11:37:45 --> Model Class Initialized
INFO - 2018-02-20 11:37:45 --> Model Class Initialized
INFO - 2018-02-20 11:37:45 --> Final output sent to browser
DEBUG - 2018-02-20 11:37:45 --> Total execution time: 0.0789
INFO - 2018-02-20 11:37:45 --> Config Class Initialized
INFO - 2018-02-20 11:37:45 --> Hooks Class Initialized
DEBUG - 2018-02-20 11:37:45 --> UTF-8 Support Enabled
INFO - 2018-02-20 11:37:45 --> Utf8 Class Initialized
INFO - 2018-02-20 11:37:45 --> URI Class Initialized
INFO - 2018-02-20 11:37:45 --> Router Class Initialized
INFO - 2018-02-20 11:37:45 --> Output Class Initialized
INFO - 2018-02-20 11:37:45 --> Security Class Initialized
DEBUG - 2018-02-20 11:37:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-20 11:37:45 --> Input Class Initialized
INFO - 2018-02-20 11:37:45 --> Language Class Initialized
INFO - 2018-02-20 11:37:45 --> Loader Class Initialized
INFO - 2018-02-20 11:37:45 --> Helper loaded: url_helper
INFO - 2018-02-20 11:37:45 --> Helper loaded: file_helper
INFO - 2018-02-20 11:37:45 --> Helper loaded: email_helper
INFO - 2018-02-20 11:37:45 --> Helper loaded: common_helper
INFO - 2018-02-20 11:37:45 --> Database Driver Class Initialized
DEBUG - 2018-02-20 11:37:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-20 11:37:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-20 11:37:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-20 11:37:45 --> Pagination Class Initialized
INFO - 2018-02-20 11:37:45 --> Helper loaded: form_helper
INFO - 2018-02-20 11:37:45 --> Form Validation Class Initialized
INFO - 2018-02-20 11:37:45 --> Model Class Initialized
INFO - 2018-02-20 11:37:45 --> Controller Class Initialized
DEBUG - 2018-02-20 11:37:45 --> Config file loaded: /var/www/html/project/radio/application/config/rest.php
INFO - 2018-02-20 11:37:45 --> Helper loaded: inflector_helper
INFO - 2018-02-20 11:37:45 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-20 11:37:45 --> Model Class Initialized
INFO - 2018-02-20 11:37:45 --> Model Class Initialized
INFO - 2018-02-20 11:37:45 --> Model Class Initialized
INFO - 2018-02-20 11:37:45 --> Email Class Initialized
INFO - 2018-02-20 11:37:51 --> Language file loaded: language/english/email_lang.php
INFO - 2018-02-20 11:37:54 --> Final output sent to browser
DEBUG - 2018-02-20 11:37:54 --> Total execution time: 8.6989
INFO - 2018-02-20 11:38:02 --> Config Class Initialized
INFO - 2018-02-20 11:38:02 --> Hooks Class Initialized
DEBUG - 2018-02-20 11:38:02 --> UTF-8 Support Enabled
INFO - 2018-02-20 11:38:02 --> Utf8 Class Initialized
INFO - 2018-02-20 11:38:02 --> URI Class Initialized
INFO - 2018-02-20 11:38:02 --> Router Class Initialized
INFO - 2018-02-20 11:38:02 --> Output Class Initialized
INFO - 2018-02-20 11:38:02 --> Security Class Initialized
DEBUG - 2018-02-20 11:38:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-20 11:38:02 --> Input Class Initialized
INFO - 2018-02-20 11:38:02 --> Language Class Initialized
INFO - 2018-02-20 11:38:02 --> Loader Class Initialized
INFO - 2018-02-20 11:38:02 --> Helper loaded: url_helper
INFO - 2018-02-20 11:38:02 --> Helper loaded: file_helper
INFO - 2018-02-20 11:38:02 --> Helper loaded: email_helper
INFO - 2018-02-20 11:38:02 --> Helper loaded: common_helper
INFO - 2018-02-20 11:38:02 --> Database Driver Class Initialized
DEBUG - 2018-02-20 11:38:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-20 11:38:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-20 11:38:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-20 11:38:02 --> Pagination Class Initialized
INFO - 2018-02-20 11:38:02 --> Helper loaded: form_helper
INFO - 2018-02-20 11:38:02 --> Form Validation Class Initialized
INFO - 2018-02-20 11:38:02 --> Model Class Initialized
INFO - 2018-02-20 11:38:02 --> Controller Class Initialized
INFO - 2018-02-20 11:38:02 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-20 11:38:02 --> Model Class Initialized
INFO - 2018-02-20 11:38:02 --> Model Class Initialized
INFO - 2018-02-20 11:38:02 --> File loaded: /var/www/html/project/radio/application/views/index/resetPassword.php
INFO - 2018-02-20 11:38:02 --> Final output sent to browser
DEBUG - 2018-02-20 11:38:02 --> Total execution time: 0.0065
INFO - 2018-02-20 11:38:23 --> Config Class Initialized
INFO - 2018-02-20 11:38:23 --> Hooks Class Initialized
DEBUG - 2018-02-20 11:38:23 --> UTF-8 Support Enabled
INFO - 2018-02-20 11:38:23 --> Utf8 Class Initialized
INFO - 2018-02-20 11:38:23 --> URI Class Initialized
INFO - 2018-02-20 11:38:23 --> Router Class Initialized
INFO - 2018-02-20 11:38:23 --> Output Class Initialized
INFO - 2018-02-20 11:38:23 --> Security Class Initialized
DEBUG - 2018-02-20 11:38:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-20 11:38:23 --> Input Class Initialized
INFO - 2018-02-20 11:38:23 --> Language Class Initialized
INFO - 2018-02-20 11:38:23 --> Loader Class Initialized
INFO - 2018-02-20 11:38:23 --> Helper loaded: url_helper
INFO - 2018-02-20 11:38:23 --> Helper loaded: file_helper
INFO - 2018-02-20 11:38:23 --> Helper loaded: email_helper
INFO - 2018-02-20 11:38:23 --> Helper loaded: common_helper
INFO - 2018-02-20 11:38:23 --> Database Driver Class Initialized
DEBUG - 2018-02-20 11:38:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-20 11:38:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-20 11:38:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-20 11:38:23 --> Pagination Class Initialized
INFO - 2018-02-20 11:38:23 --> Helper loaded: form_helper
INFO - 2018-02-20 11:38:23 --> Form Validation Class Initialized
INFO - 2018-02-20 11:38:23 --> Model Class Initialized
INFO - 2018-02-20 11:38:23 --> Controller Class Initialized
INFO - 2018-02-20 11:38:23 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-20 11:38:23 --> Model Class Initialized
INFO - 2018-02-20 11:38:23 --> Model Class Initialized
INFO - 2018-02-20 11:38:23 --> File loaded: /var/www/html/project/radio/application/views/index/resetPassword.php
INFO - 2018-02-20 11:38:23 --> Final output sent to browser
DEBUG - 2018-02-20 11:38:23 --> Total execution time: 0.0089
INFO - 2018-02-20 11:40:19 --> Config Class Initialized
INFO - 2018-02-20 11:40:19 --> Hooks Class Initialized
DEBUG - 2018-02-20 11:40:19 --> UTF-8 Support Enabled
INFO - 2018-02-20 11:40:19 --> Utf8 Class Initialized
INFO - 2018-02-20 11:40:19 --> URI Class Initialized
INFO - 2018-02-20 11:40:19 --> Router Class Initialized
INFO - 2018-02-20 11:40:19 --> Output Class Initialized
INFO - 2018-02-20 11:40:19 --> Security Class Initialized
DEBUG - 2018-02-20 11:40:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-20 11:40:19 --> Input Class Initialized
INFO - 2018-02-20 11:40:19 --> Language Class Initialized
INFO - 2018-02-20 11:40:19 --> Loader Class Initialized
INFO - 2018-02-20 11:40:19 --> Helper loaded: url_helper
INFO - 2018-02-20 11:40:19 --> Helper loaded: file_helper
INFO - 2018-02-20 11:40:19 --> Helper loaded: email_helper
INFO - 2018-02-20 11:40:19 --> Helper loaded: common_helper
INFO - 2018-02-20 11:40:19 --> Database Driver Class Initialized
DEBUG - 2018-02-20 11:40:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-20 11:40:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-20 11:40:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-20 11:40:19 --> Pagination Class Initialized
INFO - 2018-02-20 11:40:19 --> Helper loaded: form_helper
INFO - 2018-02-20 11:40:19 --> Form Validation Class Initialized
INFO - 2018-02-20 11:40:19 --> Model Class Initialized
INFO - 2018-02-20 11:40:19 --> Controller Class Initialized
INFO - 2018-02-20 11:40:19 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-20 11:40:19 --> Model Class Initialized
INFO - 2018-02-20 11:40:19 --> Model Class Initialized
INFO - 2018-02-20 11:40:19 --> File loaded: /var/www/html/project/radio/application/views/index/resetPassword.php
INFO - 2018-02-20 11:40:19 --> Final output sent to browser
DEBUG - 2018-02-20 11:40:19 --> Total execution time: 0.0534
INFO - 2018-02-20 11:40:21 --> Config Class Initialized
INFO - 2018-02-20 11:40:21 --> Hooks Class Initialized
DEBUG - 2018-02-20 11:40:21 --> UTF-8 Support Enabled
INFO - 2018-02-20 11:40:21 --> Utf8 Class Initialized
INFO - 2018-02-20 11:40:21 --> URI Class Initialized
INFO - 2018-02-20 11:40:21 --> Router Class Initialized
INFO - 2018-02-20 11:40:21 --> Output Class Initialized
INFO - 2018-02-20 11:40:21 --> Security Class Initialized
DEBUG - 2018-02-20 11:40:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-20 11:40:21 --> Input Class Initialized
INFO - 2018-02-20 11:40:21 --> Language Class Initialized
INFO - 2018-02-20 11:40:21 --> Loader Class Initialized
INFO - 2018-02-20 11:40:21 --> Helper loaded: url_helper
INFO - 2018-02-20 11:40:21 --> Helper loaded: file_helper
INFO - 2018-02-20 11:40:21 --> Helper loaded: email_helper
INFO - 2018-02-20 11:40:21 --> Helper loaded: common_helper
INFO - 2018-02-20 11:40:21 --> Database Driver Class Initialized
DEBUG - 2018-02-20 11:40:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-20 11:40:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-20 11:40:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-20 11:40:21 --> Pagination Class Initialized
INFO - 2018-02-20 11:40:21 --> Helper loaded: form_helper
INFO - 2018-02-20 11:40:21 --> Form Validation Class Initialized
INFO - 2018-02-20 11:40:21 --> Model Class Initialized
INFO - 2018-02-20 11:40:21 --> Controller Class Initialized
INFO - 2018-02-20 11:40:21 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-20 11:40:21 --> Model Class Initialized
INFO - 2018-02-20 11:40:21 --> Model Class Initialized
INFO - 2018-02-20 11:40:21 --> File loaded: /var/www/html/project/radio/application/views/index/resetPassword.php
INFO - 2018-02-20 11:40:21 --> Final output sent to browser
DEBUG - 2018-02-20 11:40:21 --> Total execution time: 0.0067
INFO - 2018-02-20 11:40:27 --> Config Class Initialized
INFO - 2018-02-20 11:40:27 --> Hooks Class Initialized
DEBUG - 2018-02-20 11:40:27 --> UTF-8 Support Enabled
INFO - 2018-02-20 11:40:27 --> Utf8 Class Initialized
INFO - 2018-02-20 11:40:27 --> URI Class Initialized
INFO - 2018-02-20 11:40:27 --> Router Class Initialized
INFO - 2018-02-20 11:40:27 --> Output Class Initialized
INFO - 2018-02-20 11:40:27 --> Security Class Initialized
DEBUG - 2018-02-20 11:40:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-20 11:40:27 --> Input Class Initialized
INFO - 2018-02-20 11:40:27 --> Language Class Initialized
INFO - 2018-02-20 11:40:27 --> Loader Class Initialized
INFO - 2018-02-20 11:40:27 --> Helper loaded: url_helper
INFO - 2018-02-20 11:40:27 --> Helper loaded: file_helper
INFO - 2018-02-20 11:40:27 --> Helper loaded: email_helper
INFO - 2018-02-20 11:40:27 --> Helper loaded: common_helper
INFO - 2018-02-20 11:40:27 --> Database Driver Class Initialized
DEBUG - 2018-02-20 11:40:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-20 11:40:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-20 11:40:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-20 11:40:27 --> Pagination Class Initialized
INFO - 2018-02-20 11:40:27 --> Helper loaded: form_helper
INFO - 2018-02-20 11:40:27 --> Form Validation Class Initialized
INFO - 2018-02-20 11:40:27 --> Model Class Initialized
INFO - 2018-02-20 11:40:27 --> Controller Class Initialized
DEBUG - 2018-02-20 11:40:27 --> Config file loaded: /var/www/html/project/radio/application/config/rest.php
INFO - 2018-02-20 11:40:27 --> Helper loaded: inflector_helper
INFO - 2018-02-20 11:40:27 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-20 11:40:27 --> Model Class Initialized
INFO - 2018-02-20 11:40:27 --> Model Class Initialized
INFO - 2018-02-20 11:40:27 --> Final output sent to browser
DEBUG - 2018-02-20 11:40:27 --> Total execution time: 0.0079
INFO - 2018-02-20 11:40:31 --> Config Class Initialized
INFO - 2018-02-20 11:40:31 --> Hooks Class Initialized
DEBUG - 2018-02-20 11:40:31 --> UTF-8 Support Enabled
INFO - 2018-02-20 11:40:31 --> Utf8 Class Initialized
INFO - 2018-02-20 11:40:31 --> URI Class Initialized
INFO - 2018-02-20 11:40:31 --> Router Class Initialized
INFO - 2018-02-20 11:40:31 --> Output Class Initialized
INFO - 2018-02-20 11:40:31 --> Security Class Initialized
DEBUG - 2018-02-20 11:40:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-20 11:40:31 --> Input Class Initialized
INFO - 2018-02-20 11:40:31 --> Language Class Initialized
INFO - 2018-02-20 11:40:31 --> Loader Class Initialized
INFO - 2018-02-20 11:40:31 --> Helper loaded: url_helper
INFO - 2018-02-20 11:40:31 --> Helper loaded: file_helper
INFO - 2018-02-20 11:40:31 --> Helper loaded: email_helper
INFO - 2018-02-20 11:40:31 --> Helper loaded: common_helper
INFO - 2018-02-20 11:40:31 --> Database Driver Class Initialized
DEBUG - 2018-02-20 11:40:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-20 11:40:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-20 11:40:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-20 11:40:31 --> Pagination Class Initialized
INFO - 2018-02-20 11:40:31 --> Helper loaded: form_helper
INFO - 2018-02-20 11:40:31 --> Form Validation Class Initialized
INFO - 2018-02-20 11:40:31 --> Model Class Initialized
INFO - 2018-02-20 11:40:31 --> Controller Class Initialized
DEBUG - 2018-02-20 11:40:31 --> Config file loaded: /var/www/html/project/radio/application/config/rest.php
INFO - 2018-02-20 11:40:31 --> Helper loaded: inflector_helper
INFO - 2018-02-20 11:40:31 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-20 11:40:31 --> Model Class Initialized
INFO - 2018-02-20 11:40:31 --> Model Class Initialized
INFO - 2018-02-20 11:40:31 --> Final output sent to browser
DEBUG - 2018-02-20 11:40:31 --> Total execution time: 0.0443
INFO - 2018-02-20 11:53:40 --> Config Class Initialized
INFO - 2018-02-20 11:53:40 --> Hooks Class Initialized
DEBUG - 2018-02-20 11:53:40 --> UTF-8 Support Enabled
INFO - 2018-02-20 11:53:40 --> Utf8 Class Initialized
INFO - 2018-02-20 11:53:40 --> URI Class Initialized
DEBUG - 2018-02-20 11:53:40 --> No URI present. Default controller set.
INFO - 2018-02-20 11:53:40 --> Router Class Initialized
INFO - 2018-02-20 11:53:40 --> Output Class Initialized
INFO - 2018-02-20 11:53:40 --> Security Class Initialized
DEBUG - 2018-02-20 11:53:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-20 11:53:40 --> Input Class Initialized
INFO - 2018-02-20 11:53:40 --> Language Class Initialized
INFO - 2018-02-20 11:53:40 --> Loader Class Initialized
INFO - 2018-02-20 11:53:40 --> Helper loaded: url_helper
INFO - 2018-02-20 11:53:40 --> Helper loaded: file_helper
INFO - 2018-02-20 11:53:40 --> Helper loaded: email_helper
INFO - 2018-02-20 11:53:40 --> Helper loaded: common_helper
INFO - 2018-02-20 11:53:40 --> Database Driver Class Initialized
DEBUG - 2018-02-20 11:53:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-20 11:53:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-20 11:53:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-20 11:53:40 --> Pagination Class Initialized
INFO - 2018-02-20 11:53:40 --> Helper loaded: form_helper
INFO - 2018-02-20 11:53:40 --> Form Validation Class Initialized
INFO - 2018-02-20 11:53:40 --> Model Class Initialized
INFO - 2018-02-20 11:53:40 --> Controller Class Initialized
INFO - 2018-02-20 11:53:40 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-20 11:53:40 --> Model Class Initialized
INFO - 2018-02-20 11:53:40 --> Model Class Initialized
INFO - 2018-02-20 11:53:40 --> File loaded: /var/www/html/project/radio/application/views/index/index.php
INFO - 2018-02-20 11:53:40 --> Final output sent to browser
DEBUG - 2018-02-20 11:53:40 --> Total execution time: 0.0064
INFO - 2018-02-20 11:53:50 --> Config Class Initialized
INFO - 2018-02-20 11:53:50 --> Hooks Class Initialized
DEBUG - 2018-02-20 11:53:50 --> UTF-8 Support Enabled
INFO - 2018-02-20 11:53:50 --> Utf8 Class Initialized
INFO - 2018-02-20 11:53:50 --> URI Class Initialized
INFO - 2018-02-20 11:53:50 --> Router Class Initialized
INFO - 2018-02-20 11:53:50 --> Output Class Initialized
INFO - 2018-02-20 11:53:50 --> Security Class Initialized
DEBUG - 2018-02-20 11:53:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-20 11:53:50 --> Input Class Initialized
INFO - 2018-02-20 11:53:50 --> Language Class Initialized
INFO - 2018-02-20 11:53:50 --> Loader Class Initialized
INFO - 2018-02-20 11:53:50 --> Helper loaded: url_helper
INFO - 2018-02-20 11:53:50 --> Helper loaded: file_helper
INFO - 2018-02-20 11:53:50 --> Helper loaded: email_helper
INFO - 2018-02-20 11:53:50 --> Helper loaded: common_helper
INFO - 2018-02-20 11:53:50 --> Database Driver Class Initialized
DEBUG - 2018-02-20 11:53:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-20 11:53:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-20 11:53:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-20 11:53:50 --> Pagination Class Initialized
INFO - 2018-02-20 11:53:50 --> Helper loaded: form_helper
INFO - 2018-02-20 11:53:50 --> Form Validation Class Initialized
INFO - 2018-02-20 11:53:50 --> Model Class Initialized
INFO - 2018-02-20 11:53:50 --> Controller Class Initialized
INFO - 2018-02-20 11:53:50 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-20 11:53:50 --> Model Class Initialized
INFO - 2018-02-20 11:53:50 --> Model Class Initialized
ERROR - 2018-02-20 11:53:50 --> Severity: Notice --> Undefined index: remember_me /var/www/html/project/radio/application/controllers/Index.php 74
INFO - 2018-02-20 11:53:50 --> Config Class Initialized
INFO - 2018-02-20 11:53:50 --> Hooks Class Initialized
DEBUG - 2018-02-20 11:53:50 --> UTF-8 Support Enabled
INFO - 2018-02-20 11:53:50 --> Utf8 Class Initialized
INFO - 2018-02-20 11:53:50 --> URI Class Initialized
INFO - 2018-02-20 11:53:50 --> Router Class Initialized
INFO - 2018-02-20 11:53:50 --> Output Class Initialized
INFO - 2018-02-20 11:53:50 --> Security Class Initialized
DEBUG - 2018-02-20 11:53:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-20 11:53:50 --> Input Class Initialized
INFO - 2018-02-20 11:53:50 --> Language Class Initialized
INFO - 2018-02-20 11:53:50 --> Loader Class Initialized
INFO - 2018-02-20 11:53:50 --> Helper loaded: url_helper
INFO - 2018-02-20 11:53:50 --> Helper loaded: file_helper
INFO - 2018-02-20 11:53:50 --> Helper loaded: email_helper
INFO - 2018-02-20 11:53:50 --> Helper loaded: common_helper
INFO - 2018-02-20 11:53:50 --> Database Driver Class Initialized
DEBUG - 2018-02-20 11:53:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-20 11:53:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-20 11:53:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-20 11:53:50 --> Pagination Class Initialized
INFO - 2018-02-20 11:53:50 --> Helper loaded: form_helper
INFO - 2018-02-20 11:53:50 --> Form Validation Class Initialized
INFO - 2018-02-20 11:53:50 --> Model Class Initialized
INFO - 2018-02-20 11:53:50 --> Controller Class Initialized
INFO - 2018-02-20 11:53:50 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-20 11:53:50 --> Model Class Initialized
INFO - 2018-02-20 11:53:50 --> Model Class Initialized
INFO - 2018-02-20 11:53:50 --> Model Class Initialized
INFO - 2018-02-20 11:53:50 --> Model Class Initialized
INFO - 2018-02-20 11:53:50 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-20 11:53:50 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-20 11:53:50 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-20 11:53:50 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-20 11:53:50 --> File loaded: /var/www/html/project/radio/application/views/dashboard/index.php
INFO - 2018-02-20 11:53:50 --> Final output sent to browser
DEBUG - 2018-02-20 11:53:50 --> Total execution time: 0.0086
INFO - 2018-02-20 11:54:03 --> Config Class Initialized
INFO - 2018-02-20 11:54:03 --> Hooks Class Initialized
DEBUG - 2018-02-20 11:54:03 --> UTF-8 Support Enabled
INFO - 2018-02-20 11:54:03 --> Utf8 Class Initialized
INFO - 2018-02-20 11:54:03 --> URI Class Initialized
INFO - 2018-02-20 11:54:03 --> Router Class Initialized
INFO - 2018-02-20 11:54:03 --> Output Class Initialized
INFO - 2018-02-20 11:54:03 --> Security Class Initialized
DEBUG - 2018-02-20 11:54:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-20 11:54:03 --> Input Class Initialized
INFO - 2018-02-20 11:54:03 --> Language Class Initialized
INFO - 2018-02-20 11:54:03 --> Loader Class Initialized
INFO - 2018-02-20 11:54:03 --> Helper loaded: url_helper
INFO - 2018-02-20 11:54:03 --> Helper loaded: file_helper
INFO - 2018-02-20 11:54:03 --> Helper loaded: email_helper
INFO - 2018-02-20 11:54:03 --> Helper loaded: common_helper
INFO - 2018-02-20 11:54:03 --> Database Driver Class Initialized
DEBUG - 2018-02-20 11:54:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-20 11:54:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-20 11:54:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-20 11:54:03 --> Pagination Class Initialized
INFO - 2018-02-20 11:54:03 --> Helper loaded: form_helper
INFO - 2018-02-20 11:54:03 --> Form Validation Class Initialized
INFO - 2018-02-20 11:54:03 --> Model Class Initialized
INFO - 2018-02-20 11:54:03 --> Controller Class Initialized
INFO - 2018-02-20 11:54:03 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-20 11:54:03 --> Model Class Initialized
INFO - 2018-02-20 11:54:03 --> Model Class Initialized
INFO - 2018-02-20 11:54:03 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-20 11:54:03 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-20 11:54:03 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-20 11:54:03 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-20 11:54:03 --> File loaded: /var/www/html/project/radio/application/views/subcategory/index.php
INFO - 2018-02-20 11:54:03 --> Final output sent to browser
DEBUG - 2018-02-20 11:54:03 --> Total execution time: 0.0279
INFO - 2018-02-20 11:54:04 --> Config Class Initialized
INFO - 2018-02-20 11:54:04 --> Hooks Class Initialized
DEBUG - 2018-02-20 11:54:04 --> UTF-8 Support Enabled
INFO - 2018-02-20 11:54:04 --> Utf8 Class Initialized
INFO - 2018-02-20 11:54:04 --> URI Class Initialized
INFO - 2018-02-20 11:54:04 --> Router Class Initialized
INFO - 2018-02-20 11:54:04 --> Output Class Initialized
INFO - 2018-02-20 11:54:04 --> Security Class Initialized
DEBUG - 2018-02-20 11:54:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-20 11:54:04 --> Input Class Initialized
INFO - 2018-02-20 11:54:04 --> Language Class Initialized
INFO - 2018-02-20 11:54:04 --> Loader Class Initialized
INFO - 2018-02-20 11:54:04 --> Helper loaded: url_helper
INFO - 2018-02-20 11:54:04 --> Helper loaded: file_helper
INFO - 2018-02-20 11:54:04 --> Helper loaded: email_helper
INFO - 2018-02-20 11:54:04 --> Helper loaded: common_helper
INFO - 2018-02-20 11:54:04 --> Database Driver Class Initialized
DEBUG - 2018-02-20 11:54:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-20 11:54:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-20 11:54:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-20 11:54:04 --> Pagination Class Initialized
INFO - 2018-02-20 11:54:04 --> Helper loaded: form_helper
INFO - 2018-02-20 11:54:04 --> Form Validation Class Initialized
INFO - 2018-02-20 11:54:04 --> Model Class Initialized
INFO - 2018-02-20 11:54:04 --> Controller Class Initialized
INFO - 2018-02-20 11:54:04 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-20 11:54:04 --> Model Class Initialized
INFO - 2018-02-20 11:54:04 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-20 11:54:04 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-20 11:54:04 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-20 11:54:04 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-20 11:54:04 --> File loaded: /var/www/html/project/radio/application/views/category/index.php
INFO - 2018-02-20 11:54:04 --> Final output sent to browser
DEBUG - 2018-02-20 11:54:04 --> Total execution time: 0.0348
INFO - 2018-02-20 11:54:04 --> Config Class Initialized
INFO - 2018-02-20 11:54:04 --> Hooks Class Initialized
DEBUG - 2018-02-20 11:54:04 --> UTF-8 Support Enabled
INFO - 2018-02-20 11:54:04 --> Utf8 Class Initialized
INFO - 2018-02-20 11:54:04 --> URI Class Initialized
INFO - 2018-02-20 11:54:04 --> Router Class Initialized
INFO - 2018-02-20 11:54:04 --> Output Class Initialized
INFO - 2018-02-20 11:54:04 --> Security Class Initialized
DEBUG - 2018-02-20 11:54:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-20 11:54:04 --> Input Class Initialized
INFO - 2018-02-20 11:54:04 --> Language Class Initialized
INFO - 2018-02-20 11:54:04 --> Loader Class Initialized
INFO - 2018-02-20 11:54:04 --> Helper loaded: url_helper
INFO - 2018-02-20 11:54:04 --> Helper loaded: file_helper
INFO - 2018-02-20 11:54:04 --> Helper loaded: email_helper
INFO - 2018-02-20 11:54:04 --> Helper loaded: common_helper
INFO - 2018-02-20 11:54:04 --> Database Driver Class Initialized
DEBUG - 2018-02-20 11:54:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-20 11:54:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-20 11:54:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-20 11:54:04 --> Pagination Class Initialized
INFO - 2018-02-20 11:54:04 --> Helper loaded: form_helper
INFO - 2018-02-20 11:54:04 --> Form Validation Class Initialized
INFO - 2018-02-20 11:54:04 --> Model Class Initialized
INFO - 2018-02-20 11:54:04 --> Controller Class Initialized
INFO - 2018-02-20 11:54:04 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-20 11:54:04 --> Model Class Initialized
INFO - 2018-02-20 11:54:04 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-20 11:54:04 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-20 11:54:04 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-20 11:54:04 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-20 11:54:04 --> File loaded: /var/www/html/project/radio/application/views/category/index.php
INFO - 2018-02-20 11:54:04 --> Final output sent to browser
DEBUG - 2018-02-20 11:54:04 --> Total execution time: 0.0065
INFO - 2018-02-20 11:54:50 --> Config Class Initialized
INFO - 2018-02-20 11:54:50 --> Hooks Class Initialized
DEBUG - 2018-02-20 11:54:50 --> UTF-8 Support Enabled
INFO - 2018-02-20 11:54:50 --> Utf8 Class Initialized
INFO - 2018-02-20 11:54:50 --> URI Class Initialized
INFO - 2018-02-20 11:54:50 --> Router Class Initialized
INFO - 2018-02-20 11:54:50 --> Output Class Initialized
INFO - 2018-02-20 11:54:50 --> Security Class Initialized
DEBUG - 2018-02-20 11:54:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-20 11:54:50 --> Input Class Initialized
INFO - 2018-02-20 11:54:50 --> Language Class Initialized
INFO - 2018-02-20 11:54:50 --> Loader Class Initialized
INFO - 2018-02-20 11:54:50 --> Helper loaded: url_helper
INFO - 2018-02-20 11:54:50 --> Helper loaded: file_helper
INFO - 2018-02-20 11:54:50 --> Helper loaded: email_helper
INFO - 2018-02-20 11:54:50 --> Helper loaded: common_helper
INFO - 2018-02-20 11:54:50 --> Database Driver Class Initialized
DEBUG - 2018-02-20 11:54:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-20 11:54:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-20 11:54:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-20 11:54:50 --> Pagination Class Initialized
INFO - 2018-02-20 11:54:50 --> Helper loaded: form_helper
INFO - 2018-02-20 11:54:50 --> Form Validation Class Initialized
INFO - 2018-02-20 11:54:50 --> Model Class Initialized
INFO - 2018-02-20 11:54:50 --> Controller Class Initialized
INFO - 2018-02-20 11:54:50 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-20 11:54:50 --> Model Class Initialized
INFO - 2018-02-20 11:54:50 --> Model Class Initialized
INFO - 2018-02-20 11:54:50 --> Model Class Initialized
INFO - 2018-02-20 11:54:50 --> Model Class Initialized
INFO - 2018-02-20 11:54:50 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-20 11:54:50 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-20 11:54:50 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-20 11:54:50 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-20 11:54:50 --> File loaded: /var/www/html/project/radio/application/views/tracks/index.php
INFO - 2018-02-20 11:54:50 --> Final output sent to browser
DEBUG - 2018-02-20 11:54:50 --> Total execution time: 0.0063
INFO - 2018-02-20 11:54:50 --> Config Class Initialized
INFO - 2018-02-20 11:54:50 --> Hooks Class Initialized
DEBUG - 2018-02-20 11:54:50 --> UTF-8 Support Enabled
INFO - 2018-02-20 11:54:50 --> Utf8 Class Initialized
INFO - 2018-02-20 11:54:50 --> URI Class Initialized
INFO - 2018-02-20 11:54:50 --> Router Class Initialized
INFO - 2018-02-20 11:54:50 --> Output Class Initialized
INFO - 2018-02-20 11:54:50 --> Security Class Initialized
DEBUG - 2018-02-20 11:54:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-20 11:54:50 --> Input Class Initialized
INFO - 2018-02-20 11:54:50 --> Language Class Initialized
INFO - 2018-02-20 11:54:50 --> Loader Class Initialized
INFO - 2018-02-20 11:54:50 --> Helper loaded: url_helper
INFO - 2018-02-20 11:54:50 --> Helper loaded: file_helper
INFO - 2018-02-20 11:54:50 --> Helper loaded: email_helper
INFO - 2018-02-20 11:54:50 --> Helper loaded: common_helper
INFO - 2018-02-20 11:54:50 --> Database Driver Class Initialized
DEBUG - 2018-02-20 11:54:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-20 11:54:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-20 11:54:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-20 11:54:50 --> Pagination Class Initialized
INFO - 2018-02-20 11:54:50 --> Helper loaded: form_helper
INFO - 2018-02-20 11:54:50 --> Form Validation Class Initialized
INFO - 2018-02-20 11:54:50 --> Model Class Initialized
INFO - 2018-02-20 11:54:50 --> Controller Class Initialized
INFO - 2018-02-20 11:54:50 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-20 11:54:50 --> Model Class Initialized
INFO - 2018-02-20 11:54:50 --> Model Class Initialized
INFO - 2018-02-20 11:54:50 --> Model Class Initialized
INFO - 2018-02-20 11:54:50 --> Model Class Initialized
INFO - 2018-02-20 11:54:52 --> Config Class Initialized
INFO - 2018-02-20 11:54:52 --> Hooks Class Initialized
DEBUG - 2018-02-20 11:54:52 --> UTF-8 Support Enabled
INFO - 2018-02-20 11:54:52 --> Utf8 Class Initialized
INFO - 2018-02-20 11:54:52 --> URI Class Initialized
INFO - 2018-02-20 11:54:52 --> Router Class Initialized
INFO - 2018-02-20 11:54:52 --> Output Class Initialized
INFO - 2018-02-20 11:54:52 --> Security Class Initialized
DEBUG - 2018-02-20 11:54:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-20 11:54:52 --> Input Class Initialized
INFO - 2018-02-20 11:54:52 --> Language Class Initialized
INFO - 2018-02-20 11:54:52 --> Loader Class Initialized
INFO - 2018-02-20 11:54:52 --> Helper loaded: url_helper
INFO - 2018-02-20 11:54:52 --> Helper loaded: file_helper
INFO - 2018-02-20 11:54:52 --> Helper loaded: email_helper
INFO - 2018-02-20 11:54:52 --> Helper loaded: common_helper
INFO - 2018-02-20 11:54:52 --> Database Driver Class Initialized
DEBUG - 2018-02-20 11:54:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-20 11:54:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-20 11:54:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-20 11:54:52 --> Pagination Class Initialized
INFO - 2018-02-20 11:54:52 --> Helper loaded: form_helper
INFO - 2018-02-20 11:54:52 --> Form Validation Class Initialized
INFO - 2018-02-20 11:54:52 --> Model Class Initialized
INFO - 2018-02-20 11:54:52 --> Controller Class Initialized
INFO - 2018-02-20 11:54:52 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-20 11:54:52 --> Model Class Initialized
INFO - 2018-02-20 11:54:52 --> Model Class Initialized
INFO - 2018-02-20 11:54:52 --> Model Class Initialized
INFO - 2018-02-20 11:54:52 --> Model Class Initialized
INFO - 2018-02-20 11:54:52 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-20 11:54:52 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-20 11:54:52 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-20 11:54:52 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-20 11:54:52 --> File loaded: /var/www/html/project/radio/application/views/tracks/add_edit.php
INFO - 2018-02-20 11:54:52 --> Final output sent to browser
DEBUG - 2018-02-20 11:54:52 --> Total execution time: 0.0120
INFO - 2018-02-20 11:54:56 --> Config Class Initialized
INFO - 2018-02-20 11:54:56 --> Hooks Class Initialized
DEBUG - 2018-02-20 11:54:56 --> UTF-8 Support Enabled
INFO - 2018-02-20 11:54:56 --> Utf8 Class Initialized
INFO - 2018-02-20 11:54:56 --> URI Class Initialized
INFO - 2018-02-20 11:54:56 --> Router Class Initialized
INFO - 2018-02-20 11:54:56 --> Output Class Initialized
INFO - 2018-02-20 11:54:56 --> Security Class Initialized
DEBUG - 2018-02-20 11:54:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-20 11:54:56 --> Input Class Initialized
INFO - 2018-02-20 11:54:56 --> Language Class Initialized
INFO - 2018-02-20 11:54:56 --> Loader Class Initialized
INFO - 2018-02-20 11:54:56 --> Helper loaded: url_helper
INFO - 2018-02-20 11:54:56 --> Helper loaded: file_helper
INFO - 2018-02-20 11:54:56 --> Helper loaded: email_helper
INFO - 2018-02-20 11:54:56 --> Helper loaded: common_helper
INFO - 2018-02-20 11:54:56 --> Database Driver Class Initialized
DEBUG - 2018-02-20 11:54:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-20 11:54:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-20 11:54:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-20 11:54:56 --> Pagination Class Initialized
INFO - 2018-02-20 11:54:56 --> Helper loaded: form_helper
INFO - 2018-02-20 11:54:56 --> Form Validation Class Initialized
INFO - 2018-02-20 11:54:56 --> Model Class Initialized
INFO - 2018-02-20 11:54:56 --> Controller Class Initialized
INFO - 2018-02-20 11:54:56 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-20 11:54:56 --> Model Class Initialized
INFO - 2018-02-20 11:54:56 --> Model Class Initialized
INFO - 2018-02-20 11:54:56 --> Model Class Initialized
INFO - 2018-02-20 11:54:56 --> Model Class Initialized
INFO - 2018-02-20 11:56:47 --> Config Class Initialized
INFO - 2018-02-20 11:56:47 --> Hooks Class Initialized
DEBUG - 2018-02-20 11:56:47 --> UTF-8 Support Enabled
INFO - 2018-02-20 11:56:47 --> Utf8 Class Initialized
INFO - 2018-02-20 11:56:47 --> URI Class Initialized
INFO - 2018-02-20 11:56:47 --> Router Class Initialized
INFO - 2018-02-20 11:56:47 --> Output Class Initialized
INFO - 2018-02-20 11:56:47 --> Security Class Initialized
DEBUG - 2018-02-20 11:56:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-20 11:56:47 --> Input Class Initialized
INFO - 2018-02-20 11:56:47 --> Language Class Initialized
INFO - 2018-02-20 11:56:47 --> Loader Class Initialized
INFO - 2018-02-20 11:56:47 --> Helper loaded: url_helper
INFO - 2018-02-20 11:56:47 --> Helper loaded: file_helper
INFO - 2018-02-20 11:56:47 --> Helper loaded: email_helper
INFO - 2018-02-20 11:56:47 --> Helper loaded: common_helper
INFO - 2018-02-20 11:56:47 --> Database Driver Class Initialized
DEBUG - 2018-02-20 11:56:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-20 11:56:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-20 11:56:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-20 11:56:47 --> Pagination Class Initialized
INFO - 2018-02-20 11:56:47 --> Helper loaded: form_helper
INFO - 2018-02-20 11:56:47 --> Form Validation Class Initialized
INFO - 2018-02-20 11:56:47 --> Model Class Initialized
INFO - 2018-02-20 11:56:47 --> Controller Class Initialized
INFO - 2018-02-20 11:56:47 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-20 11:56:47 --> Model Class Initialized
INFO - 2018-02-20 11:56:47 --> Model Class Initialized
INFO - 2018-02-20 11:56:47 --> Model Class Initialized
INFO - 2018-02-20 11:56:47 --> Model Class Initialized
INFO - 2018-02-20 13:26:35 --> Config Class Initialized
INFO - 2018-02-20 13:26:35 --> Hooks Class Initialized
DEBUG - 2018-02-20 13:26:35 --> UTF-8 Support Enabled
INFO - 2018-02-20 13:26:35 --> Utf8 Class Initialized
INFO - 2018-02-20 13:26:35 --> URI Class Initialized
INFO - 2018-02-20 13:26:35 --> Router Class Initialized
INFO - 2018-02-20 13:26:35 --> Output Class Initialized
INFO - 2018-02-20 13:26:35 --> Security Class Initialized
DEBUG - 2018-02-20 13:26:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-20 13:26:35 --> Input Class Initialized
INFO - 2018-02-20 13:26:35 --> Language Class Initialized
INFO - 2018-02-20 13:26:35 --> Loader Class Initialized
INFO - 2018-02-20 13:26:35 --> Helper loaded: url_helper
INFO - 2018-02-20 13:26:35 --> Helper loaded: file_helper
INFO - 2018-02-20 13:26:35 --> Helper loaded: email_helper
INFO - 2018-02-20 13:26:35 --> Helper loaded: common_helper
INFO - 2018-02-20 13:26:35 --> Database Driver Class Initialized
DEBUG - 2018-02-20 13:26:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-20 13:26:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-20 13:26:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-20 13:26:35 --> Pagination Class Initialized
INFO - 2018-02-20 13:26:35 --> Helper loaded: form_helper
INFO - 2018-02-20 13:26:35 --> Form Validation Class Initialized
INFO - 2018-02-20 13:26:35 --> Model Class Initialized
INFO - 2018-02-20 13:26:35 --> Controller Class Initialized
INFO - 2018-02-20 13:26:35 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-20 13:26:35 --> Model Class Initialized
INFO - 2018-02-20 13:26:35 --> Model Class Initialized
INFO - 2018-02-20 13:26:35 --> Model Class Initialized
INFO - 2018-02-20 13:26:35 --> Model Class Initialized
INFO - 2018-02-20 13:26:37 --> Config Class Initialized
INFO - 2018-02-20 13:26:37 --> Hooks Class Initialized
DEBUG - 2018-02-20 13:26:37 --> UTF-8 Support Enabled
INFO - 2018-02-20 13:26:37 --> Utf8 Class Initialized
INFO - 2018-02-20 13:26:37 --> URI Class Initialized
INFO - 2018-02-20 13:26:37 --> Router Class Initialized
INFO - 2018-02-20 13:26:37 --> Output Class Initialized
INFO - 2018-02-20 13:26:37 --> Security Class Initialized
DEBUG - 2018-02-20 13:26:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-20 13:26:37 --> Input Class Initialized
INFO - 2018-02-20 13:26:37 --> Language Class Initialized
INFO - 2018-02-20 13:26:37 --> Loader Class Initialized
INFO - 2018-02-20 13:26:37 --> Helper loaded: url_helper
INFO - 2018-02-20 13:26:37 --> Helper loaded: file_helper
INFO - 2018-02-20 13:26:37 --> Helper loaded: email_helper
INFO - 2018-02-20 13:26:37 --> Helper loaded: common_helper
INFO - 2018-02-20 13:26:37 --> Database Driver Class Initialized
DEBUG - 2018-02-20 13:26:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-20 13:26:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-20 13:26:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-20 13:26:37 --> Pagination Class Initialized
INFO - 2018-02-20 13:26:37 --> Helper loaded: form_helper
INFO - 2018-02-20 13:26:37 --> Form Validation Class Initialized
INFO - 2018-02-20 13:26:37 --> Model Class Initialized
INFO - 2018-02-20 13:26:37 --> Controller Class Initialized
INFO - 2018-02-20 13:26:37 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-20 13:26:37 --> Model Class Initialized
INFO - 2018-02-20 13:26:37 --> Model Class Initialized
INFO - 2018-02-20 13:26:37 --> Model Class Initialized
INFO - 2018-02-20 13:26:37 --> Model Class Initialized
INFO - 2018-02-20 16:11:06 --> Config Class Initialized
INFO - 2018-02-20 16:11:06 --> Hooks Class Initialized
DEBUG - 2018-02-20 16:11:06 --> UTF-8 Support Enabled
INFO - 2018-02-20 16:11:06 --> Utf8 Class Initialized
INFO - 2018-02-20 16:11:06 --> URI Class Initialized
INFO - 2018-02-20 16:11:06 --> Router Class Initialized
INFO - 2018-02-20 16:11:06 --> Output Class Initialized
INFO - 2018-02-20 16:11:06 --> Security Class Initialized
DEBUG - 2018-02-20 16:11:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-20 16:11:06 --> Input Class Initialized
INFO - 2018-02-20 16:11:06 --> Language Class Initialized
INFO - 2018-02-20 16:11:06 --> Loader Class Initialized
INFO - 2018-02-20 16:11:06 --> Helper loaded: url_helper
INFO - 2018-02-20 16:11:06 --> Helper loaded: file_helper
INFO - 2018-02-20 16:11:06 --> Helper loaded: email_helper
INFO - 2018-02-20 16:11:06 --> Helper loaded: common_helper
INFO - 2018-02-20 16:11:06 --> Database Driver Class Initialized
DEBUG - 2018-02-20 16:11:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-20 16:11:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-20 16:11:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-20 16:11:06 --> Pagination Class Initialized
INFO - 2018-02-20 16:11:06 --> Helper loaded: form_helper
INFO - 2018-02-20 16:11:06 --> Form Validation Class Initialized
INFO - 2018-02-20 16:11:06 --> Model Class Initialized
INFO - 2018-02-20 16:11:06 --> Controller Class Initialized
DEBUG - 2018-02-20 16:11:06 --> Config file loaded: /var/www/html/project/radio/application/config/rest.php
INFO - 2018-02-20 16:11:06 --> Helper loaded: inflector_helper
INFO - 2018-02-20 16:11:06 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-20 16:11:06 --> Model Class Initialized
INFO - 2018-02-20 16:11:06 --> Model Class Initialized
INFO - 2018-02-20 16:11:06 --> Final output sent to browser
DEBUG - 2018-02-20 16:11:06 --> Total execution time: 0.0074
INFO - 2018-02-20 16:11:36 --> Config Class Initialized
INFO - 2018-02-20 16:11:36 --> Hooks Class Initialized
DEBUG - 2018-02-20 16:11:36 --> UTF-8 Support Enabled
INFO - 2018-02-20 16:11:36 --> Utf8 Class Initialized
INFO - 2018-02-20 16:11:36 --> URI Class Initialized
INFO - 2018-02-20 16:11:36 --> Router Class Initialized
INFO - 2018-02-20 16:11:36 --> Output Class Initialized
INFO - 2018-02-20 16:11:36 --> Security Class Initialized
DEBUG - 2018-02-20 16:11:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-20 16:11:36 --> Input Class Initialized
INFO - 2018-02-20 16:11:36 --> Language Class Initialized
INFO - 2018-02-20 16:11:36 --> Loader Class Initialized
INFO - 2018-02-20 16:11:36 --> Helper loaded: url_helper
INFO - 2018-02-20 16:11:36 --> Helper loaded: file_helper
INFO - 2018-02-20 16:11:36 --> Helper loaded: email_helper
INFO - 2018-02-20 16:11:36 --> Helper loaded: common_helper
INFO - 2018-02-20 16:11:36 --> Database Driver Class Initialized
DEBUG - 2018-02-20 16:11:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-20 16:11:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-20 16:11:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-20 16:11:36 --> Pagination Class Initialized
INFO - 2018-02-20 16:11:36 --> Helper loaded: form_helper
INFO - 2018-02-20 16:11:36 --> Form Validation Class Initialized
INFO - 2018-02-20 16:11:36 --> Model Class Initialized
INFO - 2018-02-20 16:11:36 --> Controller Class Initialized
DEBUG - 2018-02-20 16:11:36 --> Config file loaded: /var/www/html/project/radio/application/config/rest.php
INFO - 2018-02-20 16:11:36 --> Helper loaded: inflector_helper
INFO - 2018-02-20 16:11:36 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-20 16:11:36 --> Model Class Initialized
INFO - 2018-02-20 16:11:36 --> Model Class Initialized
INFO - 2018-02-20 16:11:36 --> Final output sent to browser
DEBUG - 2018-02-20 16:11:36 --> Total execution time: 0.0041
INFO - 2018-02-20 16:12:25 --> Config Class Initialized
INFO - 2018-02-20 16:12:25 --> Hooks Class Initialized
DEBUG - 2018-02-20 16:12:25 --> UTF-8 Support Enabled
INFO - 2018-02-20 16:12:25 --> Utf8 Class Initialized
INFO - 2018-02-20 16:12:25 --> URI Class Initialized
INFO - 2018-02-20 16:12:25 --> Router Class Initialized
INFO - 2018-02-20 16:12:25 --> Output Class Initialized
INFO - 2018-02-20 16:12:25 --> Security Class Initialized
DEBUG - 2018-02-20 16:12:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-20 16:12:25 --> Input Class Initialized
INFO - 2018-02-20 16:12:25 --> Language Class Initialized
INFO - 2018-02-20 16:12:25 --> Loader Class Initialized
INFO - 2018-02-20 16:12:25 --> Helper loaded: url_helper
INFO - 2018-02-20 16:12:25 --> Helper loaded: file_helper
INFO - 2018-02-20 16:12:25 --> Helper loaded: email_helper
INFO - 2018-02-20 16:12:25 --> Helper loaded: common_helper
INFO - 2018-02-20 16:12:25 --> Database Driver Class Initialized
DEBUG - 2018-02-20 16:12:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-20 16:12:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-20 16:12:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-20 16:12:25 --> Pagination Class Initialized
INFO - 2018-02-20 16:12:25 --> Helper loaded: form_helper
INFO - 2018-02-20 16:12:25 --> Form Validation Class Initialized
INFO - 2018-02-20 16:12:25 --> Model Class Initialized
INFO - 2018-02-20 16:12:25 --> Controller Class Initialized
DEBUG - 2018-02-20 16:12:25 --> Config file loaded: /var/www/html/project/radio/application/config/rest.php
INFO - 2018-02-20 16:12:25 --> Helper loaded: inflector_helper
INFO - 2018-02-20 16:12:25 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-20 16:12:25 --> Model Class Initialized
INFO - 2018-02-20 16:12:25 --> Model Class Initialized
INFO - 2018-02-20 16:12:25 --> Final output sent to browser
DEBUG - 2018-02-20 16:12:25 --> Total execution time: 0.0046
INFO - 2018-02-20 16:12:33 --> Config Class Initialized
INFO - 2018-02-20 16:12:33 --> Hooks Class Initialized
DEBUG - 2018-02-20 16:12:33 --> UTF-8 Support Enabled
INFO - 2018-02-20 16:12:33 --> Utf8 Class Initialized
INFO - 2018-02-20 16:12:33 --> URI Class Initialized
INFO - 2018-02-20 16:12:33 --> Router Class Initialized
INFO - 2018-02-20 16:12:33 --> Output Class Initialized
INFO - 2018-02-20 16:12:33 --> Security Class Initialized
DEBUG - 2018-02-20 16:12:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-20 16:12:33 --> Input Class Initialized
INFO - 2018-02-20 16:12:33 --> Language Class Initialized
INFO - 2018-02-20 16:12:33 --> Loader Class Initialized
INFO - 2018-02-20 16:12:33 --> Helper loaded: url_helper
INFO - 2018-02-20 16:12:33 --> Helper loaded: file_helper
INFO - 2018-02-20 16:12:33 --> Helper loaded: email_helper
INFO - 2018-02-20 16:12:33 --> Helper loaded: common_helper
INFO - 2018-02-20 16:12:33 --> Database Driver Class Initialized
DEBUG - 2018-02-20 16:12:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-20 16:12:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-20 16:12:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-20 16:12:33 --> Pagination Class Initialized
INFO - 2018-02-20 16:12:33 --> Helper loaded: form_helper
INFO - 2018-02-20 16:12:33 --> Form Validation Class Initialized
INFO - 2018-02-20 16:12:33 --> Model Class Initialized
INFO - 2018-02-20 16:12:33 --> Controller Class Initialized
DEBUG - 2018-02-20 16:12:33 --> Config file loaded: /var/www/html/project/radio/application/config/rest.php
INFO - 2018-02-20 16:12:33 --> Helper loaded: inflector_helper
INFO - 2018-02-20 16:12:33 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-20 16:12:33 --> Model Class Initialized
INFO - 2018-02-20 16:12:33 --> Model Class Initialized
ERROR - 2018-02-20 16:12:33 --> Severity: Notice --> Undefined property: Oauth::$Usermaster_model /var/www/html/project/radio/application/controllers/api/Oauth.php 446
ERROR - 2018-02-20 16:12:33 --> Severity: error --> Exception: Call to a member function updateData() on null /var/www/html/project/radio/application/controllers/api/Oauth.php 446
INFO - 2018-02-20 16:13:01 --> Config Class Initialized
INFO - 2018-02-20 16:13:01 --> Hooks Class Initialized
DEBUG - 2018-02-20 16:13:01 --> UTF-8 Support Enabled
INFO - 2018-02-20 16:13:01 --> Utf8 Class Initialized
INFO - 2018-02-20 16:13:01 --> URI Class Initialized
INFO - 2018-02-20 16:13:01 --> Router Class Initialized
INFO - 2018-02-20 16:13:01 --> Output Class Initialized
INFO - 2018-02-20 16:13:01 --> Security Class Initialized
DEBUG - 2018-02-20 16:13:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-20 16:13:01 --> Input Class Initialized
INFO - 2018-02-20 16:13:01 --> Language Class Initialized
INFO - 2018-02-20 16:13:01 --> Loader Class Initialized
INFO - 2018-02-20 16:13:01 --> Helper loaded: url_helper
INFO - 2018-02-20 16:13:01 --> Helper loaded: file_helper
INFO - 2018-02-20 16:13:01 --> Helper loaded: email_helper
INFO - 2018-02-20 16:13:01 --> Helper loaded: common_helper
INFO - 2018-02-20 16:13:01 --> Database Driver Class Initialized
DEBUG - 2018-02-20 16:13:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-20 16:13:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-20 16:13:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-20 16:13:01 --> Pagination Class Initialized
INFO - 2018-02-20 16:13:01 --> Helper loaded: form_helper
INFO - 2018-02-20 16:13:01 --> Form Validation Class Initialized
INFO - 2018-02-20 16:13:01 --> Model Class Initialized
INFO - 2018-02-20 16:13:01 --> Controller Class Initialized
DEBUG - 2018-02-20 16:13:01 --> Config file loaded: /var/www/html/project/radio/application/config/rest.php
INFO - 2018-02-20 16:13:01 --> Helper loaded: inflector_helper
INFO - 2018-02-20 16:13:01 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-20 16:13:01 --> Model Class Initialized
INFO - 2018-02-20 16:13:01 --> Model Class Initialized
INFO - 2018-02-20 16:13:01 --> Final output sent to browser
DEBUG - 2018-02-20 16:13:01 --> Total execution time: 0.0604
INFO - 2018-02-20 16:15:50 --> Config Class Initialized
INFO - 2018-02-20 16:15:50 --> Hooks Class Initialized
DEBUG - 2018-02-20 16:15:50 --> UTF-8 Support Enabled
INFO - 2018-02-20 16:15:50 --> Utf8 Class Initialized
INFO - 2018-02-20 16:15:50 --> URI Class Initialized
INFO - 2018-02-20 16:15:50 --> Router Class Initialized
INFO - 2018-02-20 16:15:50 --> Output Class Initialized
INFO - 2018-02-20 16:15:50 --> Security Class Initialized
DEBUG - 2018-02-20 16:15:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-20 16:15:50 --> Input Class Initialized
INFO - 2018-02-20 16:15:50 --> Language Class Initialized
INFO - 2018-02-20 16:15:50 --> Loader Class Initialized
INFO - 2018-02-20 16:15:50 --> Helper loaded: url_helper
INFO - 2018-02-20 16:15:50 --> Helper loaded: file_helper
INFO - 2018-02-20 16:15:50 --> Helper loaded: email_helper
INFO - 2018-02-20 16:15:50 --> Helper loaded: common_helper
INFO - 2018-02-20 16:15:50 --> Database Driver Class Initialized
DEBUG - 2018-02-20 16:15:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-20 16:15:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-20 16:15:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-20 16:15:50 --> Pagination Class Initialized
INFO - 2018-02-20 16:15:50 --> Helper loaded: form_helper
INFO - 2018-02-20 16:15:50 --> Form Validation Class Initialized
INFO - 2018-02-20 16:15:50 --> Model Class Initialized
INFO - 2018-02-20 16:15:50 --> Controller Class Initialized
DEBUG - 2018-02-20 16:15:50 --> Config file loaded: /var/www/html/project/radio/application/config/rest.php
INFO - 2018-02-20 16:15:50 --> Helper loaded: inflector_helper
INFO - 2018-02-20 16:15:50 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-20 16:15:50 --> Model Class Initialized
INFO - 2018-02-20 16:15:50 --> Model Class Initialized
INFO - 2018-02-20 16:15:50 --> Final output sent to browser
DEBUG - 2018-02-20 16:15:50 --> Total execution time: 0.0046
INFO - 2018-02-20 16:16:16 --> Config Class Initialized
INFO - 2018-02-20 16:16:16 --> Hooks Class Initialized
DEBUG - 2018-02-20 16:16:16 --> UTF-8 Support Enabled
INFO - 2018-02-20 16:16:16 --> Utf8 Class Initialized
INFO - 2018-02-20 16:16:16 --> URI Class Initialized
INFO - 2018-02-20 16:16:16 --> Router Class Initialized
INFO - 2018-02-20 16:16:16 --> Output Class Initialized
INFO - 2018-02-20 16:16:16 --> Security Class Initialized
DEBUG - 2018-02-20 16:16:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-20 16:16:16 --> Input Class Initialized
INFO - 2018-02-20 16:16:16 --> Language Class Initialized
INFO - 2018-02-20 16:16:16 --> Loader Class Initialized
INFO - 2018-02-20 16:16:16 --> Helper loaded: url_helper
INFO - 2018-02-20 16:16:16 --> Helper loaded: file_helper
INFO - 2018-02-20 16:16:16 --> Helper loaded: email_helper
INFO - 2018-02-20 16:16:16 --> Helper loaded: common_helper
INFO - 2018-02-20 16:16:16 --> Database Driver Class Initialized
DEBUG - 2018-02-20 16:16:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-20 16:16:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-20 16:16:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-20 16:16:16 --> Pagination Class Initialized
INFO - 2018-02-20 16:16:16 --> Helper loaded: form_helper
INFO - 2018-02-20 16:16:16 --> Form Validation Class Initialized
INFO - 2018-02-20 16:16:16 --> Model Class Initialized
INFO - 2018-02-20 16:16:16 --> Controller Class Initialized
DEBUG - 2018-02-20 16:16:16 --> Config file loaded: /var/www/html/project/radio/application/config/rest.php
INFO - 2018-02-20 16:16:16 --> Helper loaded: inflector_helper
INFO - 2018-02-20 16:16:16 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-20 16:16:16 --> Model Class Initialized
INFO - 2018-02-20 16:16:16 --> Model Class Initialized
INFO - 2018-02-20 16:16:16 --> Final output sent to browser
DEBUG - 2018-02-20 16:16:16 --> Total execution time: 0.0047
INFO - 2018-02-20 16:16:29 --> Config Class Initialized
INFO - 2018-02-20 16:16:29 --> Hooks Class Initialized
DEBUG - 2018-02-20 16:16:29 --> UTF-8 Support Enabled
INFO - 2018-02-20 16:16:29 --> Utf8 Class Initialized
INFO - 2018-02-20 16:16:29 --> URI Class Initialized
INFO - 2018-02-20 16:16:29 --> Router Class Initialized
INFO - 2018-02-20 16:16:29 --> Output Class Initialized
INFO - 2018-02-20 16:16:29 --> Security Class Initialized
DEBUG - 2018-02-20 16:16:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-20 16:16:29 --> Input Class Initialized
INFO - 2018-02-20 16:16:29 --> Language Class Initialized
INFO - 2018-02-20 16:16:29 --> Loader Class Initialized
INFO - 2018-02-20 16:16:29 --> Helper loaded: url_helper
INFO - 2018-02-20 16:16:29 --> Helper loaded: file_helper
INFO - 2018-02-20 16:16:29 --> Helper loaded: email_helper
INFO - 2018-02-20 16:16:29 --> Helper loaded: common_helper
INFO - 2018-02-20 16:16:29 --> Database Driver Class Initialized
DEBUG - 2018-02-20 16:16:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-20 16:16:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-20 16:16:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-20 16:16:29 --> Pagination Class Initialized
INFO - 2018-02-20 16:16:29 --> Helper loaded: form_helper
INFO - 2018-02-20 16:16:29 --> Form Validation Class Initialized
INFO - 2018-02-20 16:16:29 --> Model Class Initialized
INFO - 2018-02-20 16:16:29 --> Controller Class Initialized
DEBUG - 2018-02-20 16:16:29 --> Config file loaded: /var/www/html/project/radio/application/config/rest.php
INFO - 2018-02-20 16:16:29 --> Helper loaded: inflector_helper
INFO - 2018-02-20 16:16:29 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-20 16:16:29 --> Model Class Initialized
INFO - 2018-02-20 16:16:29 --> Model Class Initialized
INFO - 2018-02-20 16:16:29 --> Final output sent to browser
DEBUG - 2018-02-20 16:16:29 --> Total execution time: 0.0046
INFO - 2018-02-20 16:16:35 --> Config Class Initialized
INFO - 2018-02-20 16:16:35 --> Hooks Class Initialized
DEBUG - 2018-02-20 16:16:35 --> UTF-8 Support Enabled
INFO - 2018-02-20 16:16:35 --> Utf8 Class Initialized
INFO - 2018-02-20 16:16:35 --> URI Class Initialized
INFO - 2018-02-20 16:16:35 --> Router Class Initialized
INFO - 2018-02-20 16:16:35 --> Output Class Initialized
INFO - 2018-02-20 16:16:35 --> Security Class Initialized
DEBUG - 2018-02-20 16:16:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-20 16:16:35 --> Input Class Initialized
INFO - 2018-02-20 16:16:35 --> Language Class Initialized
INFO - 2018-02-20 16:16:35 --> Loader Class Initialized
INFO - 2018-02-20 16:16:35 --> Helper loaded: url_helper
INFO - 2018-02-20 16:16:35 --> Helper loaded: file_helper
INFO - 2018-02-20 16:16:35 --> Helper loaded: email_helper
INFO - 2018-02-20 16:16:35 --> Helper loaded: common_helper
INFO - 2018-02-20 16:16:35 --> Database Driver Class Initialized
DEBUG - 2018-02-20 16:16:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-20 16:16:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-20 16:16:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-20 16:16:35 --> Pagination Class Initialized
INFO - 2018-02-20 16:16:35 --> Helper loaded: form_helper
INFO - 2018-02-20 16:16:35 --> Form Validation Class Initialized
INFO - 2018-02-20 16:16:35 --> Model Class Initialized
INFO - 2018-02-20 16:16:35 --> Controller Class Initialized
DEBUG - 2018-02-20 16:16:35 --> Config file loaded: /var/www/html/project/radio/application/config/rest.php
INFO - 2018-02-20 16:16:35 --> Helper loaded: inflector_helper
INFO - 2018-02-20 16:16:35 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-20 16:16:35 --> Model Class Initialized
INFO - 2018-02-20 16:16:35 --> Model Class Initialized
INFO - 2018-02-20 16:16:35 --> Final output sent to browser
DEBUG - 2018-02-20 16:16:35 --> Total execution time: 0.0351
INFO - 2018-02-20 16:22:53 --> Config Class Initialized
INFO - 2018-02-20 16:22:53 --> Hooks Class Initialized
DEBUG - 2018-02-20 16:22:53 --> UTF-8 Support Enabled
INFO - 2018-02-20 16:22:53 --> Utf8 Class Initialized
INFO - 2018-02-20 16:22:53 --> URI Class Initialized
INFO - 2018-02-20 16:22:53 --> Router Class Initialized
INFO - 2018-02-20 16:22:53 --> Output Class Initialized
INFO - 2018-02-20 16:22:53 --> Security Class Initialized
DEBUG - 2018-02-20 16:22:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-20 16:22:53 --> Input Class Initialized
INFO - 2018-02-20 16:22:53 --> Language Class Initialized
INFO - 2018-02-20 16:22:53 --> Loader Class Initialized
INFO - 2018-02-20 16:22:53 --> Helper loaded: url_helper
INFO - 2018-02-20 16:22:53 --> Helper loaded: file_helper
INFO - 2018-02-20 16:22:53 --> Helper loaded: email_helper
INFO - 2018-02-20 16:22:53 --> Helper loaded: common_helper
INFO - 2018-02-20 16:22:53 --> Database Driver Class Initialized
DEBUG - 2018-02-20 16:22:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-20 16:22:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-20 16:22:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-20 16:22:53 --> Pagination Class Initialized
INFO - 2018-02-20 16:22:53 --> Helper loaded: form_helper
INFO - 2018-02-20 16:22:53 --> Form Validation Class Initialized
INFO - 2018-02-20 16:22:53 --> Model Class Initialized
INFO - 2018-02-20 16:22:53 --> Controller Class Initialized
DEBUG - 2018-02-20 16:22:53 --> Config file loaded: /var/www/html/project/radio/application/config/rest.php
INFO - 2018-02-20 16:22:53 --> Helper loaded: inflector_helper
INFO - 2018-02-20 16:22:53 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-20 16:22:53 --> Model Class Initialized
INFO - 2018-02-20 16:22:53 --> Model Class Initialized
INFO - 2018-02-20 16:22:53 --> Final output sent to browser
DEBUG - 2018-02-20 16:22:53 --> Total execution time: 0.0049
INFO - 2018-02-20 16:22:55 --> Config Class Initialized
INFO - 2018-02-20 16:22:55 --> Hooks Class Initialized
DEBUG - 2018-02-20 16:22:55 --> UTF-8 Support Enabled
INFO - 2018-02-20 16:22:55 --> Utf8 Class Initialized
INFO - 2018-02-20 16:22:55 --> URI Class Initialized
INFO - 2018-02-20 16:22:55 --> Router Class Initialized
INFO - 2018-02-20 16:22:55 --> Output Class Initialized
INFO - 2018-02-20 16:22:55 --> Security Class Initialized
DEBUG - 2018-02-20 16:22:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-20 16:22:55 --> Input Class Initialized
INFO - 2018-02-20 16:22:55 --> Language Class Initialized
INFO - 2018-02-20 16:22:55 --> Loader Class Initialized
INFO - 2018-02-20 16:22:55 --> Helper loaded: url_helper
INFO - 2018-02-20 16:22:55 --> Helper loaded: file_helper
INFO - 2018-02-20 16:22:55 --> Helper loaded: email_helper
INFO - 2018-02-20 16:22:55 --> Helper loaded: common_helper
INFO - 2018-02-20 16:22:55 --> Database Driver Class Initialized
DEBUG - 2018-02-20 16:22:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-20 16:22:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-20 16:22:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-20 16:22:55 --> Pagination Class Initialized
INFO - 2018-02-20 16:22:55 --> Helper loaded: form_helper
INFO - 2018-02-20 16:22:55 --> Form Validation Class Initialized
INFO - 2018-02-20 16:22:55 --> Model Class Initialized
INFO - 2018-02-20 16:22:55 --> Controller Class Initialized
DEBUG - 2018-02-20 16:22:55 --> Config file loaded: /var/www/html/project/radio/application/config/rest.php
INFO - 2018-02-20 16:22:55 --> Helper loaded: inflector_helper
INFO - 2018-02-20 16:22:55 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-20 16:22:55 --> Model Class Initialized
INFO - 2018-02-20 16:22:55 --> Model Class Initialized
INFO - 2018-02-20 16:22:56 --> Final output sent to browser
DEBUG - 2018-02-20 16:22:56 --> Total execution time: 0.0385
INFO - 2018-02-20 17:24:09 --> Config Class Initialized
INFO - 2018-02-20 17:24:09 --> Hooks Class Initialized
DEBUG - 2018-02-20 17:24:09 --> UTF-8 Support Enabled
INFO - 2018-02-20 17:24:09 --> Utf8 Class Initialized
INFO - 2018-02-20 17:24:09 --> URI Class Initialized
INFO - 2018-02-20 17:24:09 --> Router Class Initialized
INFO - 2018-02-20 17:24:09 --> Output Class Initialized
INFO - 2018-02-20 17:24:09 --> Security Class Initialized
DEBUG - 2018-02-20 17:24:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-20 17:24:09 --> Input Class Initialized
INFO - 2018-02-20 17:24:09 --> Language Class Initialized
INFO - 2018-02-20 17:24:09 --> Loader Class Initialized
INFO - 2018-02-20 17:24:09 --> Helper loaded: url_helper
INFO - 2018-02-20 17:24:09 --> Helper loaded: file_helper
INFO - 2018-02-20 17:24:09 --> Helper loaded: email_helper
INFO - 2018-02-20 17:24:09 --> Helper loaded: common_helper
INFO - 2018-02-20 17:24:09 --> Database Driver Class Initialized
DEBUG - 2018-02-20 17:24:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-20 17:24:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-20 17:24:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-20 17:24:09 --> Pagination Class Initialized
INFO - 2018-02-20 17:24:09 --> Helper loaded: form_helper
INFO - 2018-02-20 17:24:09 --> Form Validation Class Initialized
INFO - 2018-02-20 17:24:09 --> Model Class Initialized
INFO - 2018-02-20 17:24:09 --> Controller Class Initialized
DEBUG - 2018-02-20 17:24:09 --> Config file loaded: /var/www/html/project/radio/application/config/rest.php
INFO - 2018-02-20 17:24:09 --> Helper loaded: inflector_helper
INFO - 2018-02-20 17:24:09 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-20 17:24:09 --> Model Class Initialized
INFO - 2018-02-20 17:24:09 --> Model Class Initialized
INFO - 2018-02-20 17:24:09 --> Model Class Initialized
INFO - 2018-02-20 17:24:09 --> Final output sent to browser
DEBUG - 2018-02-20 17:24:09 --> Total execution time: 0.0063
INFO - 2018-02-20 17:24:14 --> Config Class Initialized
INFO - 2018-02-20 17:24:14 --> Hooks Class Initialized
DEBUG - 2018-02-20 17:24:14 --> UTF-8 Support Enabled
INFO - 2018-02-20 17:24:14 --> Utf8 Class Initialized
INFO - 2018-02-20 17:24:14 --> URI Class Initialized
INFO - 2018-02-20 17:24:14 --> Router Class Initialized
INFO - 2018-02-20 17:24:14 --> Output Class Initialized
INFO - 2018-02-20 17:24:14 --> Security Class Initialized
DEBUG - 2018-02-20 17:24:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-20 17:24:14 --> Input Class Initialized
INFO - 2018-02-20 17:24:14 --> Language Class Initialized
INFO - 2018-02-20 17:24:14 --> Loader Class Initialized
INFO - 2018-02-20 17:24:14 --> Helper loaded: url_helper
INFO - 2018-02-20 17:24:14 --> Helper loaded: file_helper
INFO - 2018-02-20 17:24:14 --> Helper loaded: email_helper
INFO - 2018-02-20 17:24:14 --> Helper loaded: common_helper
INFO - 2018-02-20 17:24:14 --> Database Driver Class Initialized
DEBUG - 2018-02-20 17:24:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-20 17:24:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-20 17:24:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-20 17:24:14 --> Pagination Class Initialized
INFO - 2018-02-20 17:24:14 --> Helper loaded: form_helper
INFO - 2018-02-20 17:24:14 --> Form Validation Class Initialized
INFO - 2018-02-20 17:24:14 --> Model Class Initialized
INFO - 2018-02-20 17:24:14 --> Controller Class Initialized
DEBUG - 2018-02-20 17:24:14 --> Config file loaded: /var/www/html/project/radio/application/config/rest.php
INFO - 2018-02-20 17:24:14 --> Helper loaded: inflector_helper
INFO - 2018-02-20 17:24:14 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-20 17:24:14 --> Model Class Initialized
INFO - 2018-02-20 17:24:14 --> Model Class Initialized
INFO - 2018-02-20 17:24:14 --> Model Class Initialized
INFO - 2018-02-20 17:24:14 --> Final output sent to browser
DEBUG - 2018-02-20 17:24:14 --> Total execution time: 0.0050
INFO - 2018-02-20 17:25:36 --> Config Class Initialized
INFO - 2018-02-20 17:25:36 --> Hooks Class Initialized
DEBUG - 2018-02-20 17:25:36 --> UTF-8 Support Enabled
INFO - 2018-02-20 17:25:36 --> Utf8 Class Initialized
INFO - 2018-02-20 17:25:36 --> URI Class Initialized
INFO - 2018-02-20 17:25:36 --> Router Class Initialized
INFO - 2018-02-20 17:25:36 --> Output Class Initialized
INFO - 2018-02-20 17:25:36 --> Security Class Initialized
DEBUG - 2018-02-20 17:25:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-20 17:25:36 --> Input Class Initialized
INFO - 2018-02-20 17:25:36 --> Language Class Initialized
INFO - 2018-02-20 17:25:36 --> Loader Class Initialized
INFO - 2018-02-20 17:25:36 --> Helper loaded: url_helper
INFO - 2018-02-20 17:25:36 --> Helper loaded: file_helper
INFO - 2018-02-20 17:25:36 --> Helper loaded: email_helper
INFO - 2018-02-20 17:25:36 --> Helper loaded: common_helper
INFO - 2018-02-20 17:25:36 --> Database Driver Class Initialized
DEBUG - 2018-02-20 17:25:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-20 17:25:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-20 17:25:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-20 17:25:36 --> Pagination Class Initialized
INFO - 2018-02-20 17:25:36 --> Helper loaded: form_helper
INFO - 2018-02-20 17:25:36 --> Form Validation Class Initialized
INFO - 2018-02-20 17:25:36 --> Model Class Initialized
INFO - 2018-02-20 17:25:36 --> Controller Class Initialized
DEBUG - 2018-02-20 17:25:36 --> Config file loaded: /var/www/html/project/radio/application/config/rest.php
INFO - 2018-02-20 17:25:36 --> Helper loaded: inflector_helper
INFO - 2018-02-20 17:25:36 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-20 17:25:36 --> Model Class Initialized
INFO - 2018-02-20 17:25:36 --> Model Class Initialized
INFO - 2018-02-20 17:25:36 --> Model Class Initialized
ERROR - 2018-02-20 17:25:36 --> Severity: Notice --> Undefined index: timestamp /var/www/html/project/radio/application/controllers/api/Fetchappdata.php 44
INFO - 2018-02-20 17:25:36 --> Final output sent to browser
DEBUG - 2018-02-20 17:25:36 --> Total execution time: 0.0058
INFO - 2018-02-20 17:25:39 --> Config Class Initialized
INFO - 2018-02-20 17:25:39 --> Hooks Class Initialized
DEBUG - 2018-02-20 17:25:39 --> UTF-8 Support Enabled
INFO - 2018-02-20 17:25:39 --> Utf8 Class Initialized
INFO - 2018-02-20 17:25:39 --> URI Class Initialized
INFO - 2018-02-20 17:25:39 --> Router Class Initialized
INFO - 2018-02-20 17:25:39 --> Output Class Initialized
INFO - 2018-02-20 17:25:39 --> Security Class Initialized
DEBUG - 2018-02-20 17:25:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-20 17:25:39 --> Input Class Initialized
INFO - 2018-02-20 17:25:39 --> Language Class Initialized
INFO - 2018-02-20 17:25:39 --> Loader Class Initialized
INFO - 2018-02-20 17:25:39 --> Helper loaded: url_helper
INFO - 2018-02-20 17:25:39 --> Helper loaded: file_helper
INFO - 2018-02-20 17:25:39 --> Helper loaded: email_helper
INFO - 2018-02-20 17:25:39 --> Helper loaded: common_helper
INFO - 2018-02-20 17:25:39 --> Database Driver Class Initialized
DEBUG - 2018-02-20 17:25:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-20 17:25:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-20 17:25:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-20 17:25:39 --> Pagination Class Initialized
INFO - 2018-02-20 17:25:39 --> Helper loaded: form_helper
INFO - 2018-02-20 17:25:39 --> Form Validation Class Initialized
INFO - 2018-02-20 17:25:39 --> Model Class Initialized
INFO - 2018-02-20 17:25:39 --> Controller Class Initialized
DEBUG - 2018-02-20 17:25:39 --> Config file loaded: /var/www/html/project/radio/application/config/rest.php
INFO - 2018-02-20 17:25:39 --> Helper loaded: inflector_helper
INFO - 2018-02-20 17:25:39 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-20 17:25:39 --> Model Class Initialized
INFO - 2018-02-20 17:25:39 --> Model Class Initialized
INFO - 2018-02-20 17:25:39 --> Model Class Initialized
ERROR - 2018-02-20 17:25:39 --> Severity: Notice --> Undefined index: timestamp /var/www/html/project/radio/application/controllers/api/Fetchappdata.php 44
INFO - 2018-02-20 17:25:39 --> Final output sent to browser
DEBUG - 2018-02-20 17:25:39 --> Total execution time: 0.0055
INFO - 2018-02-20 17:25:53 --> Config Class Initialized
INFO - 2018-02-20 17:25:53 --> Hooks Class Initialized
DEBUG - 2018-02-20 17:25:53 --> UTF-8 Support Enabled
INFO - 2018-02-20 17:25:53 --> Utf8 Class Initialized
INFO - 2018-02-20 17:25:53 --> URI Class Initialized
INFO - 2018-02-20 17:25:53 --> Router Class Initialized
INFO - 2018-02-20 17:25:53 --> Output Class Initialized
INFO - 2018-02-20 17:25:53 --> Security Class Initialized
DEBUG - 2018-02-20 17:25:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-20 17:25:53 --> Input Class Initialized
INFO - 2018-02-20 17:25:53 --> Language Class Initialized
INFO - 2018-02-20 17:25:53 --> Loader Class Initialized
INFO - 2018-02-20 17:25:53 --> Helper loaded: url_helper
INFO - 2018-02-20 17:25:53 --> Helper loaded: file_helper
INFO - 2018-02-20 17:25:53 --> Helper loaded: email_helper
INFO - 2018-02-20 17:25:53 --> Helper loaded: common_helper
INFO - 2018-02-20 17:25:53 --> Database Driver Class Initialized
DEBUG - 2018-02-20 17:25:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-20 17:25:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-20 17:25:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-20 17:25:53 --> Pagination Class Initialized
INFO - 2018-02-20 17:25:53 --> Helper loaded: form_helper
INFO - 2018-02-20 17:25:53 --> Form Validation Class Initialized
INFO - 2018-02-20 17:25:53 --> Model Class Initialized
INFO - 2018-02-20 17:25:53 --> Controller Class Initialized
DEBUG - 2018-02-20 17:25:53 --> Config file loaded: /var/www/html/project/radio/application/config/rest.php
INFO - 2018-02-20 17:25:53 --> Helper loaded: inflector_helper
INFO - 2018-02-20 17:25:53 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-20 17:25:53 --> Model Class Initialized
INFO - 2018-02-20 17:25:53 --> Model Class Initialized
INFO - 2018-02-20 17:25:53 --> Model Class Initialized
INFO - 2018-02-20 17:25:53 --> Final output sent to browser
DEBUG - 2018-02-20 17:25:53 --> Total execution time: 0.0093
INFO - 2018-02-20 17:26:16 --> Config Class Initialized
INFO - 2018-02-20 17:26:16 --> Hooks Class Initialized
DEBUG - 2018-02-20 17:26:16 --> UTF-8 Support Enabled
INFO - 2018-02-20 17:26:16 --> Utf8 Class Initialized
INFO - 2018-02-20 17:26:16 --> URI Class Initialized
INFO - 2018-02-20 17:26:16 --> Router Class Initialized
INFO - 2018-02-20 17:26:16 --> Output Class Initialized
INFO - 2018-02-20 17:26:16 --> Security Class Initialized
DEBUG - 2018-02-20 17:26:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-20 17:26:16 --> Input Class Initialized
INFO - 2018-02-20 17:26:16 --> Language Class Initialized
INFO - 2018-02-20 17:26:16 --> Loader Class Initialized
INFO - 2018-02-20 17:26:16 --> Helper loaded: url_helper
INFO - 2018-02-20 17:26:16 --> Helper loaded: file_helper
INFO - 2018-02-20 17:26:16 --> Helper loaded: email_helper
INFO - 2018-02-20 17:26:16 --> Helper loaded: common_helper
INFO - 2018-02-20 17:26:16 --> Database Driver Class Initialized
DEBUG - 2018-02-20 17:26:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-20 17:26:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-20 17:26:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-20 17:26:16 --> Pagination Class Initialized
INFO - 2018-02-20 17:26:16 --> Helper loaded: form_helper
INFO - 2018-02-20 17:26:16 --> Form Validation Class Initialized
INFO - 2018-02-20 17:26:16 --> Model Class Initialized
INFO - 2018-02-20 17:26:16 --> Controller Class Initialized
DEBUG - 2018-02-20 17:26:16 --> Config file loaded: /var/www/html/project/radio/application/config/rest.php
INFO - 2018-02-20 17:26:16 --> Helper loaded: inflector_helper
INFO - 2018-02-20 17:26:16 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-20 17:26:16 --> Model Class Initialized
INFO - 2018-02-20 17:26:16 --> Model Class Initialized
INFO - 2018-02-20 17:26:16 --> Model Class Initialized
ERROR - 2018-02-20 17:26:16 --> Severity: Notice --> Undefined index: timestamp /var/www/html/project/radio/application/controllers/api/Fetchappdata.php 44
ERROR - 2018-02-20 17:26:16 --> Severity: 4096 --> Object of class CI_DB_mysqli_result could not be converted to string /var/www/html/project/radio/application/models/Subcategory_model.php 189
INFO - 2018-02-20 17:27:18 --> Config Class Initialized
INFO - 2018-02-20 17:27:18 --> Hooks Class Initialized
DEBUG - 2018-02-20 17:27:18 --> UTF-8 Support Enabled
INFO - 2018-02-20 17:27:18 --> Utf8 Class Initialized
INFO - 2018-02-20 17:27:18 --> URI Class Initialized
INFO - 2018-02-20 17:27:18 --> Router Class Initialized
INFO - 2018-02-20 17:27:18 --> Output Class Initialized
INFO - 2018-02-20 17:27:18 --> Security Class Initialized
DEBUG - 2018-02-20 17:27:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-20 17:27:18 --> Input Class Initialized
INFO - 2018-02-20 17:27:18 --> Language Class Initialized
INFO - 2018-02-20 17:27:18 --> Loader Class Initialized
INFO - 2018-02-20 17:27:18 --> Helper loaded: url_helper
INFO - 2018-02-20 17:27:18 --> Helper loaded: file_helper
INFO - 2018-02-20 17:27:18 --> Helper loaded: email_helper
INFO - 2018-02-20 17:27:18 --> Helper loaded: common_helper
INFO - 2018-02-20 17:27:18 --> Database Driver Class Initialized
DEBUG - 2018-02-20 17:27:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-20 17:27:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-20 17:27:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-20 17:27:18 --> Pagination Class Initialized
INFO - 2018-02-20 17:27:18 --> Helper loaded: form_helper
INFO - 2018-02-20 17:27:18 --> Form Validation Class Initialized
INFO - 2018-02-20 17:27:18 --> Model Class Initialized
INFO - 2018-02-20 17:27:18 --> Controller Class Initialized
DEBUG - 2018-02-20 17:27:18 --> Config file loaded: /var/www/html/project/radio/application/config/rest.php
INFO - 2018-02-20 17:27:18 --> Helper loaded: inflector_helper
INFO - 2018-02-20 17:27:18 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-20 17:27:18 --> Model Class Initialized
INFO - 2018-02-20 17:27:18 --> Model Class Initialized
INFO - 2018-02-20 17:27:18 --> Model Class Initialized
ERROR - 2018-02-20 17:27:18 --> Severity: Notice --> Undefined index: timestamp /var/www/html/project/radio/application/controllers/api/Fetchappdata.php 44
INFO - 2018-02-20 17:27:18 --> Final output sent to browser
DEBUG - 2018-02-20 17:27:18 --> Total execution time: 0.0052
INFO - 2018-02-20 17:27:21 --> Config Class Initialized
INFO - 2018-02-20 17:27:21 --> Hooks Class Initialized
DEBUG - 2018-02-20 17:27:21 --> UTF-8 Support Enabled
INFO - 2018-02-20 17:27:21 --> Utf8 Class Initialized
INFO - 2018-02-20 17:27:21 --> URI Class Initialized
INFO - 2018-02-20 17:27:21 --> Router Class Initialized
INFO - 2018-02-20 17:27:21 --> Output Class Initialized
INFO - 2018-02-20 17:27:21 --> Security Class Initialized
DEBUG - 2018-02-20 17:27:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-20 17:27:21 --> Input Class Initialized
INFO - 2018-02-20 17:27:21 --> Language Class Initialized
INFO - 2018-02-20 17:27:21 --> Loader Class Initialized
INFO - 2018-02-20 17:27:21 --> Helper loaded: url_helper
INFO - 2018-02-20 17:27:21 --> Helper loaded: file_helper
INFO - 2018-02-20 17:27:21 --> Helper loaded: email_helper
INFO - 2018-02-20 17:27:21 --> Helper loaded: common_helper
INFO - 2018-02-20 17:27:21 --> Database Driver Class Initialized
DEBUG - 2018-02-20 17:27:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-20 17:27:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-20 17:27:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-20 17:27:21 --> Pagination Class Initialized
INFO - 2018-02-20 17:27:21 --> Helper loaded: form_helper
INFO - 2018-02-20 17:27:21 --> Form Validation Class Initialized
INFO - 2018-02-20 17:27:21 --> Model Class Initialized
INFO - 2018-02-20 17:27:21 --> Controller Class Initialized
DEBUG - 2018-02-20 17:27:21 --> Config file loaded: /var/www/html/project/radio/application/config/rest.php
INFO - 2018-02-20 17:27:21 --> Helper loaded: inflector_helper
INFO - 2018-02-20 17:27:21 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-20 17:27:21 --> Model Class Initialized
INFO - 2018-02-20 17:27:21 --> Model Class Initialized
INFO - 2018-02-20 17:27:21 --> Model Class Initialized
ERROR - 2018-02-20 17:27:21 --> Severity: Notice --> Undefined index: timestamp /var/www/html/project/radio/application/controllers/api/Fetchappdata.php 44
INFO - 2018-02-20 17:27:21 --> Final output sent to browser
DEBUG - 2018-02-20 17:27:21 --> Total execution time: 0.0058
INFO - 2018-02-20 17:29:23 --> Config Class Initialized
INFO - 2018-02-20 17:29:23 --> Hooks Class Initialized
DEBUG - 2018-02-20 17:29:23 --> UTF-8 Support Enabled
INFO - 2018-02-20 17:29:23 --> Utf8 Class Initialized
INFO - 2018-02-20 17:29:23 --> URI Class Initialized
INFO - 2018-02-20 17:29:23 --> Router Class Initialized
INFO - 2018-02-20 17:29:23 --> Output Class Initialized
INFO - 2018-02-20 17:29:23 --> Security Class Initialized
DEBUG - 2018-02-20 17:29:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-20 17:29:23 --> Input Class Initialized
INFO - 2018-02-20 17:29:23 --> Language Class Initialized
INFO - 2018-02-20 17:29:23 --> Loader Class Initialized
INFO - 2018-02-20 17:29:23 --> Helper loaded: url_helper
INFO - 2018-02-20 17:29:23 --> Helper loaded: file_helper
INFO - 2018-02-20 17:29:23 --> Helper loaded: email_helper
INFO - 2018-02-20 17:29:23 --> Helper loaded: common_helper
INFO - 2018-02-20 17:29:23 --> Database Driver Class Initialized
DEBUG - 2018-02-20 17:29:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-20 17:29:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-20 17:29:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-20 17:29:23 --> Pagination Class Initialized
INFO - 2018-02-20 17:29:23 --> Helper loaded: form_helper
INFO - 2018-02-20 17:29:23 --> Form Validation Class Initialized
INFO - 2018-02-20 17:29:23 --> Model Class Initialized
INFO - 2018-02-20 17:29:23 --> Controller Class Initialized
DEBUG - 2018-02-20 17:29:23 --> Config file loaded: /var/www/html/project/radio/application/config/rest.php
INFO - 2018-02-20 17:29:23 --> Helper loaded: inflector_helper
INFO - 2018-02-20 17:29:23 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-20 17:29:23 --> Model Class Initialized
INFO - 2018-02-20 17:29:23 --> Model Class Initialized
INFO - 2018-02-20 17:29:23 --> Model Class Initialized
ERROR - 2018-02-20 17:29:23 --> Severity: 4096 --> Object of class CI_DB_mysqli_result could not be converted to string /var/www/html/project/radio/application/models/Subcategory_model.php 189
INFO - 2018-02-20 17:29:26 --> Config Class Initialized
INFO - 2018-02-20 17:29:26 --> Hooks Class Initialized
DEBUG - 2018-02-20 17:29:26 --> UTF-8 Support Enabled
INFO - 2018-02-20 17:29:26 --> Utf8 Class Initialized
INFO - 2018-02-20 17:29:26 --> URI Class Initialized
INFO - 2018-02-20 17:29:26 --> Router Class Initialized
INFO - 2018-02-20 17:29:26 --> Output Class Initialized
INFO - 2018-02-20 17:29:26 --> Security Class Initialized
DEBUG - 2018-02-20 17:29:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-20 17:29:26 --> Input Class Initialized
INFO - 2018-02-20 17:29:26 --> Language Class Initialized
INFO - 2018-02-20 17:29:26 --> Loader Class Initialized
INFO - 2018-02-20 17:29:26 --> Helper loaded: url_helper
INFO - 2018-02-20 17:29:26 --> Helper loaded: file_helper
INFO - 2018-02-20 17:29:26 --> Helper loaded: email_helper
INFO - 2018-02-20 17:29:26 --> Helper loaded: common_helper
INFO - 2018-02-20 17:29:26 --> Database Driver Class Initialized
DEBUG - 2018-02-20 17:29:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-20 17:29:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-20 17:29:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-20 17:29:26 --> Pagination Class Initialized
INFO - 2018-02-20 17:29:26 --> Helper loaded: form_helper
INFO - 2018-02-20 17:29:26 --> Form Validation Class Initialized
INFO - 2018-02-20 17:29:26 --> Model Class Initialized
INFO - 2018-02-20 17:29:26 --> Controller Class Initialized
DEBUG - 2018-02-20 17:29:26 --> Config file loaded: /var/www/html/project/radio/application/config/rest.php
INFO - 2018-02-20 17:29:26 --> Helper loaded: inflector_helper
INFO - 2018-02-20 17:29:26 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-20 17:29:26 --> Model Class Initialized
INFO - 2018-02-20 17:29:26 --> Model Class Initialized
INFO - 2018-02-20 17:29:26 --> Model Class Initialized
ERROR - 2018-02-20 17:29:26 --> Severity: 4096 --> Object of class CI_DB_mysqli_result could not be converted to string /var/www/html/project/radio/application/models/Subcategory_model.php 189
INFO - 2018-02-20 17:29:32 --> Config Class Initialized
INFO - 2018-02-20 17:29:32 --> Hooks Class Initialized
DEBUG - 2018-02-20 17:29:32 --> UTF-8 Support Enabled
INFO - 2018-02-20 17:29:32 --> Utf8 Class Initialized
INFO - 2018-02-20 17:29:32 --> URI Class Initialized
INFO - 2018-02-20 17:29:32 --> Router Class Initialized
INFO - 2018-02-20 17:29:32 --> Output Class Initialized
INFO - 2018-02-20 17:29:32 --> Security Class Initialized
DEBUG - 2018-02-20 17:29:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-20 17:29:32 --> Input Class Initialized
INFO - 2018-02-20 17:29:32 --> Language Class Initialized
INFO - 2018-02-20 17:29:32 --> Loader Class Initialized
INFO - 2018-02-20 17:29:32 --> Helper loaded: url_helper
INFO - 2018-02-20 17:29:32 --> Helper loaded: file_helper
INFO - 2018-02-20 17:29:32 --> Helper loaded: email_helper
INFO - 2018-02-20 17:29:32 --> Helper loaded: common_helper
INFO - 2018-02-20 17:29:32 --> Database Driver Class Initialized
DEBUG - 2018-02-20 17:29:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-20 17:29:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-20 17:29:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-20 17:29:32 --> Pagination Class Initialized
INFO - 2018-02-20 17:29:32 --> Helper loaded: form_helper
INFO - 2018-02-20 17:29:32 --> Form Validation Class Initialized
INFO - 2018-02-20 17:29:32 --> Model Class Initialized
INFO - 2018-02-20 17:29:32 --> Controller Class Initialized
DEBUG - 2018-02-20 17:29:32 --> Config file loaded: /var/www/html/project/radio/application/config/rest.php
INFO - 2018-02-20 17:29:32 --> Helper loaded: inflector_helper
INFO - 2018-02-20 17:29:32 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-20 17:29:32 --> Model Class Initialized
INFO - 2018-02-20 17:29:32 --> Model Class Initialized
INFO - 2018-02-20 17:29:32 --> Model Class Initialized
INFO - 2018-02-20 17:29:32 --> Final output sent to browser
DEBUG - 2018-02-20 17:29:32 --> Total execution time: 0.0054
INFO - 2018-02-20 17:29:38 --> Config Class Initialized
INFO - 2018-02-20 17:29:38 --> Hooks Class Initialized
DEBUG - 2018-02-20 17:29:38 --> UTF-8 Support Enabled
INFO - 2018-02-20 17:29:38 --> Utf8 Class Initialized
INFO - 2018-02-20 17:29:38 --> URI Class Initialized
INFO - 2018-02-20 17:29:38 --> Router Class Initialized
INFO - 2018-02-20 17:29:38 --> Output Class Initialized
INFO - 2018-02-20 17:29:38 --> Security Class Initialized
DEBUG - 2018-02-20 17:29:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-20 17:29:38 --> Input Class Initialized
INFO - 2018-02-20 17:29:38 --> Language Class Initialized
INFO - 2018-02-20 17:29:38 --> Loader Class Initialized
INFO - 2018-02-20 17:29:38 --> Helper loaded: url_helper
INFO - 2018-02-20 17:29:38 --> Helper loaded: file_helper
INFO - 2018-02-20 17:29:38 --> Helper loaded: email_helper
INFO - 2018-02-20 17:29:38 --> Helper loaded: common_helper
INFO - 2018-02-20 17:29:38 --> Database Driver Class Initialized
DEBUG - 2018-02-20 17:29:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-20 17:29:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-20 17:29:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-20 17:29:38 --> Pagination Class Initialized
INFO - 2018-02-20 17:29:38 --> Helper loaded: form_helper
INFO - 2018-02-20 17:29:38 --> Form Validation Class Initialized
INFO - 2018-02-20 17:29:38 --> Model Class Initialized
INFO - 2018-02-20 17:29:38 --> Controller Class Initialized
DEBUG - 2018-02-20 17:29:38 --> Config file loaded: /var/www/html/project/radio/application/config/rest.php
INFO - 2018-02-20 17:29:38 --> Helper loaded: inflector_helper
INFO - 2018-02-20 17:29:38 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-20 17:29:38 --> Model Class Initialized
INFO - 2018-02-20 17:29:38 --> Model Class Initialized
INFO - 2018-02-20 17:29:38 --> Model Class Initialized
ERROR - 2018-02-20 17:29:38 --> Severity: 4096 --> Object of class CI_DB_mysqli_result could not be converted to string /var/www/html/project/radio/application/models/Subcategory_model.php 189
INFO - 2018-02-20 17:30:04 --> Config Class Initialized
INFO - 2018-02-20 17:30:04 --> Hooks Class Initialized
DEBUG - 2018-02-20 17:30:04 --> UTF-8 Support Enabled
INFO - 2018-02-20 17:30:04 --> Utf8 Class Initialized
INFO - 2018-02-20 17:30:04 --> URI Class Initialized
INFO - 2018-02-20 17:30:04 --> Router Class Initialized
INFO - 2018-02-20 17:30:04 --> Output Class Initialized
INFO - 2018-02-20 17:30:04 --> Security Class Initialized
DEBUG - 2018-02-20 17:30:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-20 17:30:04 --> Input Class Initialized
INFO - 2018-02-20 17:30:04 --> Language Class Initialized
INFO - 2018-02-20 17:30:04 --> Loader Class Initialized
INFO - 2018-02-20 17:30:04 --> Helper loaded: url_helper
INFO - 2018-02-20 17:30:04 --> Helper loaded: file_helper
INFO - 2018-02-20 17:30:04 --> Helper loaded: email_helper
INFO - 2018-02-20 17:30:04 --> Helper loaded: common_helper
INFO - 2018-02-20 17:30:04 --> Database Driver Class Initialized
DEBUG - 2018-02-20 17:30:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-20 17:30:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-20 17:30:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-20 17:30:04 --> Pagination Class Initialized
INFO - 2018-02-20 17:30:04 --> Helper loaded: form_helper
INFO - 2018-02-20 17:30:04 --> Form Validation Class Initialized
INFO - 2018-02-20 17:30:04 --> Model Class Initialized
INFO - 2018-02-20 17:30:04 --> Controller Class Initialized
DEBUG - 2018-02-20 17:30:04 --> Config file loaded: /var/www/html/project/radio/application/config/rest.php
INFO - 2018-02-20 17:30:04 --> Helper loaded: inflector_helper
INFO - 2018-02-20 17:30:04 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-20 17:30:04 --> Model Class Initialized
INFO - 2018-02-20 17:30:04 --> Model Class Initialized
INFO - 2018-02-20 17:30:04 --> Model Class Initialized
INFO - 2018-02-20 17:30:25 --> Config Class Initialized
INFO - 2018-02-20 17:30:25 --> Hooks Class Initialized
DEBUG - 2018-02-20 17:30:25 --> UTF-8 Support Enabled
INFO - 2018-02-20 17:30:25 --> Utf8 Class Initialized
INFO - 2018-02-20 17:30:25 --> URI Class Initialized
INFO - 2018-02-20 17:30:25 --> Router Class Initialized
INFO - 2018-02-20 17:30:25 --> Output Class Initialized
INFO - 2018-02-20 17:30:25 --> Security Class Initialized
DEBUG - 2018-02-20 17:30:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-20 17:30:25 --> Input Class Initialized
INFO - 2018-02-20 17:30:25 --> Language Class Initialized
INFO - 2018-02-20 17:30:25 --> Loader Class Initialized
INFO - 2018-02-20 17:30:25 --> Helper loaded: url_helper
INFO - 2018-02-20 17:30:25 --> Helper loaded: file_helper
INFO - 2018-02-20 17:30:25 --> Helper loaded: email_helper
INFO - 2018-02-20 17:30:25 --> Helper loaded: common_helper
INFO - 2018-02-20 17:30:25 --> Database Driver Class Initialized
DEBUG - 2018-02-20 17:30:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-20 17:30:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-20 17:30:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-20 17:30:25 --> Pagination Class Initialized
INFO - 2018-02-20 17:30:25 --> Helper loaded: form_helper
INFO - 2018-02-20 17:30:25 --> Form Validation Class Initialized
INFO - 2018-02-20 17:30:25 --> Model Class Initialized
INFO - 2018-02-20 17:30:25 --> Controller Class Initialized
DEBUG - 2018-02-20 17:30:25 --> Config file loaded: /var/www/html/project/radio/application/config/rest.php
INFO - 2018-02-20 17:30:25 --> Helper loaded: inflector_helper
INFO - 2018-02-20 17:30:25 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-20 17:30:25 --> Model Class Initialized
INFO - 2018-02-20 17:30:25 --> Model Class Initialized
INFO - 2018-02-20 17:30:25 --> Model Class Initialized
INFO - 2018-02-20 17:30:25 --> Final output sent to browser
DEBUG - 2018-02-20 17:30:25 --> Total execution time: 0.0067
INFO - 2018-02-20 17:30:33 --> Config Class Initialized
INFO - 2018-02-20 17:30:33 --> Hooks Class Initialized
DEBUG - 2018-02-20 17:30:33 --> UTF-8 Support Enabled
INFO - 2018-02-20 17:30:33 --> Utf8 Class Initialized
INFO - 2018-02-20 17:30:33 --> URI Class Initialized
INFO - 2018-02-20 17:30:33 --> Router Class Initialized
INFO - 2018-02-20 17:30:33 --> Output Class Initialized
INFO - 2018-02-20 17:30:33 --> Security Class Initialized
DEBUG - 2018-02-20 17:30:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-20 17:30:33 --> Input Class Initialized
INFO - 2018-02-20 17:30:33 --> Language Class Initialized
INFO - 2018-02-20 17:30:33 --> Loader Class Initialized
INFO - 2018-02-20 17:30:33 --> Helper loaded: url_helper
INFO - 2018-02-20 17:30:33 --> Helper loaded: file_helper
INFO - 2018-02-20 17:30:33 --> Helper loaded: email_helper
INFO - 2018-02-20 17:30:33 --> Helper loaded: common_helper
INFO - 2018-02-20 17:30:33 --> Database Driver Class Initialized
DEBUG - 2018-02-20 17:30:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-20 17:30:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-20 17:30:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-20 17:30:33 --> Pagination Class Initialized
INFO - 2018-02-20 17:30:33 --> Helper loaded: form_helper
INFO - 2018-02-20 17:30:33 --> Form Validation Class Initialized
INFO - 2018-02-20 17:30:33 --> Model Class Initialized
INFO - 2018-02-20 17:30:33 --> Controller Class Initialized
DEBUG - 2018-02-20 17:30:33 --> Config file loaded: /var/www/html/project/radio/application/config/rest.php
INFO - 2018-02-20 17:30:33 --> Helper loaded: inflector_helper
INFO - 2018-02-20 17:30:33 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-20 17:30:33 --> Model Class Initialized
INFO - 2018-02-20 17:30:33 --> Model Class Initialized
INFO - 2018-02-20 17:30:33 --> Model Class Initialized
ERROR - 2018-02-20 17:30:33 --> Query error: Unknown column 'sc.tStatus1' in 'where clause' - Invalid query: SELECT `c`.`iCategoryId` `catId`, `c`.`vTitle` as `catName`, `c`.`txDescription` as `catDesc`, `c`.`vIconImage` as `catImg`, `c`.`tStatus` as `catStatus`, `c`.`tsCreatedAt` as `catCreated`, `sc`.`iSubCategoryId` as `subCatId`, `sc`.`iCategoryId` `relCatId`, `sc`.`vTitle` as `subCatName`, `sc`.`txDescription` as `subCatDesc`, `sc`.`vIconImage` as `subCatImg`, `sc`.`tStatus` as `subCatStatus`, `sc`.`tsCreatedAt` as `subCatCreated`
FROM `category` as `c`
LEFT JOIN `subcategory` as `sc` ON `c`.`iCategoryId` = `sc`.`iCategoryId`
WHERE `c`.`is_deleted` =0
AND `sc`.`is_deleted` =0
AND `c`.`tStatus` = 1
AND `sc`.`tStatus1` = 1
INFO - 2018-02-20 17:30:33 --> Language file loaded: language/english/db_lang.php
INFO - 2018-02-20 17:31:09 --> Config Class Initialized
INFO - 2018-02-20 17:31:09 --> Hooks Class Initialized
DEBUG - 2018-02-20 17:31:09 --> UTF-8 Support Enabled
INFO - 2018-02-20 17:31:09 --> Utf8 Class Initialized
INFO - 2018-02-20 17:31:09 --> URI Class Initialized
INFO - 2018-02-20 17:31:09 --> Router Class Initialized
INFO - 2018-02-20 17:31:09 --> Output Class Initialized
INFO - 2018-02-20 17:31:09 --> Security Class Initialized
DEBUG - 2018-02-20 17:31:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-20 17:31:09 --> Input Class Initialized
INFO - 2018-02-20 17:31:09 --> Language Class Initialized
INFO - 2018-02-20 17:31:09 --> Loader Class Initialized
INFO - 2018-02-20 17:31:09 --> Helper loaded: url_helper
INFO - 2018-02-20 17:31:09 --> Helper loaded: file_helper
INFO - 2018-02-20 17:31:09 --> Helper loaded: email_helper
INFO - 2018-02-20 17:31:09 --> Helper loaded: common_helper
INFO - 2018-02-20 17:31:09 --> Database Driver Class Initialized
DEBUG - 2018-02-20 17:31:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-20 17:31:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-20 17:31:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-20 17:31:09 --> Pagination Class Initialized
INFO - 2018-02-20 17:31:09 --> Helper loaded: form_helper
INFO - 2018-02-20 17:31:09 --> Form Validation Class Initialized
INFO - 2018-02-20 17:31:09 --> Model Class Initialized
INFO - 2018-02-20 17:31:09 --> Controller Class Initialized
DEBUG - 2018-02-20 17:31:09 --> Config file loaded: /var/www/html/project/radio/application/config/rest.php
INFO - 2018-02-20 17:31:09 --> Helper loaded: inflector_helper
INFO - 2018-02-20 17:31:09 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-20 17:31:09 --> Model Class Initialized
INFO - 2018-02-20 17:31:09 --> Model Class Initialized
INFO - 2018-02-20 17:31:09 --> Model Class Initialized
ERROR - 2018-02-20 17:31:09 --> Query error: Unknown column 'sc.tStatusa' in 'where clause' - Invalid query: SELECT `c`.`iCategoryId` `catId`, `c`.`vTitle` as `catName`, `c`.`txDescription` as `catDesc`, `c`.`vIconImage` as `catImg`, `c`.`tStatus` as `catStatus`, `c`.`tsCreatedAt` as `catCreated`, `sc`.`iSubCategoryId` as `subCatId`, `sc`.`iCategoryId` `relCatId`, `sc`.`vTitle` as `subCatName`, `sc`.`txDescription` as `subCatDesc`, `sc`.`vIconImage` as `subCatImg`, `sc`.`tStatus` as `subCatStatus`, `sc`.`tsCreatedAt` as `subCatCreated`
FROM `category` as `c`
LEFT JOIN `subcategory` as `sc` ON `c`.`iCategoryId` = `sc`.`iCategoryId`
WHERE `c`.`is_deleted` =0
AND `sc`.`is_deleted` =0
AND `c`.`tStatus` = 1
AND `sc`.`tStatusa` = 1
AND `c`.`tsCreatedAt` > '2018-02-20 16:50:52'
OR `sc`.`tsCreatedAt` > '2018-02-20 16:50:52'
INFO - 2018-02-20 17:31:09 --> Language file loaded: language/english/db_lang.php
INFO - 2018-02-20 17:32:19 --> Config Class Initialized
INFO - 2018-02-20 17:32:19 --> Hooks Class Initialized
DEBUG - 2018-02-20 17:32:19 --> UTF-8 Support Enabled
INFO - 2018-02-20 17:32:19 --> Utf8 Class Initialized
INFO - 2018-02-20 17:32:19 --> URI Class Initialized
INFO - 2018-02-20 17:32:19 --> Router Class Initialized
INFO - 2018-02-20 17:32:19 --> Output Class Initialized
INFO - 2018-02-20 17:32:19 --> Security Class Initialized
DEBUG - 2018-02-20 17:32:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-20 17:32:19 --> Input Class Initialized
INFO - 2018-02-20 17:32:19 --> Language Class Initialized
INFO - 2018-02-20 17:32:19 --> Loader Class Initialized
INFO - 2018-02-20 17:32:19 --> Helper loaded: url_helper
INFO - 2018-02-20 17:32:19 --> Helper loaded: file_helper
INFO - 2018-02-20 17:32:19 --> Helper loaded: email_helper
INFO - 2018-02-20 17:32:19 --> Helper loaded: common_helper
INFO - 2018-02-20 17:32:19 --> Database Driver Class Initialized
DEBUG - 2018-02-20 17:32:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-20 17:32:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-20 17:32:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-20 17:32:19 --> Pagination Class Initialized
INFO - 2018-02-20 17:32:19 --> Helper loaded: form_helper
INFO - 2018-02-20 17:32:19 --> Form Validation Class Initialized
INFO - 2018-02-20 17:32:19 --> Model Class Initialized
INFO - 2018-02-20 17:32:19 --> Controller Class Initialized
DEBUG - 2018-02-20 17:32:19 --> Config file loaded: /var/www/html/project/radio/application/config/rest.php
INFO - 2018-02-20 17:32:19 --> Helper loaded: inflector_helper
INFO - 2018-02-20 17:32:19 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-20 17:32:19 --> Model Class Initialized
INFO - 2018-02-20 17:32:19 --> Model Class Initialized
INFO - 2018-02-20 17:32:19 --> Model Class Initialized
ERROR - 2018-02-20 17:32:19 --> Query error: Unknown column 'sc.tStatus2' in 'where clause' - Invalid query: SELECT `c`.`iCategoryId` `catId`, `c`.`vTitle` as `catName`, `c`.`txDescription` as `catDesc`, `c`.`vIconImage` as `catImg`, `c`.`tStatus` as `catStatus`, `c`.`tsCreatedAt` as `catCreated`, `sc`.`iSubCategoryId` as `subCatId`, `sc`.`iCategoryId` `relCatId`, `sc`.`vTitle` as `subCatName`, `sc`.`txDescription` as `subCatDesc`, `sc`.`vIconImage` as `subCatImg`, `sc`.`tStatus` as `subCatStatus`, `sc`.`tsCreatedAt` as `subCatCreated`
FROM `category` as `c`
LEFT JOIN `subcategory` as `sc` ON `c`.`iCategoryId` = `sc`.`iCategoryId`
WHERE `c`.`is_deleted` =0
AND `sc`.`is_deleted` =0
AND `c`.`tStatus` = 1
AND `sc`.`tStatus2` = 1
AND `c`.`tsCreatedAt` > '2018-02-20 16:50:52' OR `sc`.`tsCreatedAt` > '2018-02-20 16:50:52'
INFO - 2018-02-20 17:32:19 --> Language file loaded: language/english/db_lang.php
INFO - 2018-02-20 17:32:46 --> Config Class Initialized
INFO - 2018-02-20 17:32:46 --> Hooks Class Initialized
DEBUG - 2018-02-20 17:32:46 --> UTF-8 Support Enabled
INFO - 2018-02-20 17:32:46 --> Utf8 Class Initialized
INFO - 2018-02-20 17:32:46 --> URI Class Initialized
INFO - 2018-02-20 17:32:46 --> Router Class Initialized
INFO - 2018-02-20 17:32:46 --> Output Class Initialized
INFO - 2018-02-20 17:32:46 --> Security Class Initialized
DEBUG - 2018-02-20 17:32:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-20 17:32:46 --> Input Class Initialized
INFO - 2018-02-20 17:32:46 --> Language Class Initialized
INFO - 2018-02-20 17:32:46 --> Loader Class Initialized
INFO - 2018-02-20 17:32:46 --> Helper loaded: url_helper
INFO - 2018-02-20 17:32:46 --> Helper loaded: file_helper
INFO - 2018-02-20 17:32:46 --> Helper loaded: email_helper
INFO - 2018-02-20 17:32:46 --> Helper loaded: common_helper
INFO - 2018-02-20 17:32:46 --> Database Driver Class Initialized
DEBUG - 2018-02-20 17:32:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-20 17:32:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-20 17:32:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-20 17:32:46 --> Pagination Class Initialized
INFO - 2018-02-20 17:32:46 --> Helper loaded: form_helper
INFO - 2018-02-20 17:32:46 --> Form Validation Class Initialized
INFO - 2018-02-20 17:32:46 --> Model Class Initialized
INFO - 2018-02-20 17:32:46 --> Controller Class Initialized
DEBUG - 2018-02-20 17:32:46 --> Config file loaded: /var/www/html/project/radio/application/config/rest.php
INFO - 2018-02-20 17:32:46 --> Helper loaded: inflector_helper
INFO - 2018-02-20 17:32:46 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-20 17:32:46 --> Model Class Initialized
INFO - 2018-02-20 17:32:46 --> Model Class Initialized
INFO - 2018-02-20 17:32:46 --> Model Class Initialized
ERROR - 2018-02-20 17:32:46 --> Query error: Unknown column 'sc.tStatus2' in 'where clause' - Invalid query: SELECT `c`.`iCategoryId` `catId`, `c`.`vTitle` as `catName`, `c`.`txDescription` as `catDesc`, `c`.`vIconImage` as `catImg`, `c`.`tStatus` as `catStatus`, `c`.`tsCreatedAt` as `catCreated`, `sc`.`iSubCategoryId` as `subCatId`, `sc`.`iCategoryId` `relCatId`, `sc`.`vTitle` as `subCatName`, `sc`.`txDescription` as `subCatDesc`, `sc`.`vIconImage` as `subCatImg`, `sc`.`tStatus` as `subCatStatus`, `sc`.`tsCreatedAt` as `subCatCreated`
FROM `category` as `c`
LEFT JOIN `subcategory` as `sc` ON `c`.`iCategoryId` = `sc`.`iCategoryId`
WHERE `c`.`is_deleted` =0
AND `sc`.`is_deleted` =0
AND `c`.`tStatus` = 1
AND `sc`.`tStatus2` = 1
AND  (`c`.`tsCreatedAt` > '2018-02-20 16:50:52' OR `sc`.`tsCreatedAt` > '2018-02-20 16:50:52' )
INFO - 2018-02-20 17:32:46 --> Language file loaded: language/english/db_lang.php
INFO - 2018-02-20 17:33:46 --> Config Class Initialized
INFO - 2018-02-20 17:33:46 --> Hooks Class Initialized
DEBUG - 2018-02-20 17:33:46 --> UTF-8 Support Enabled
INFO - 2018-02-20 17:33:46 --> Utf8 Class Initialized
INFO - 2018-02-20 17:33:46 --> URI Class Initialized
INFO - 2018-02-20 17:33:46 --> Router Class Initialized
INFO - 2018-02-20 17:33:46 --> Output Class Initialized
INFO - 2018-02-20 17:33:46 --> Security Class Initialized
DEBUG - 2018-02-20 17:33:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-20 17:33:46 --> Input Class Initialized
INFO - 2018-02-20 17:33:46 --> Language Class Initialized
INFO - 2018-02-20 17:33:46 --> Loader Class Initialized
INFO - 2018-02-20 17:33:46 --> Helper loaded: url_helper
INFO - 2018-02-20 17:33:46 --> Helper loaded: file_helper
INFO - 2018-02-20 17:33:46 --> Helper loaded: email_helper
INFO - 2018-02-20 17:33:46 --> Helper loaded: common_helper
INFO - 2018-02-20 17:33:46 --> Database Driver Class Initialized
DEBUG - 2018-02-20 17:33:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-20 17:33:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-20 17:33:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-20 17:33:46 --> Pagination Class Initialized
INFO - 2018-02-20 17:33:46 --> Helper loaded: form_helper
INFO - 2018-02-20 17:33:46 --> Form Validation Class Initialized
INFO - 2018-02-20 17:33:46 --> Model Class Initialized
INFO - 2018-02-20 17:33:46 --> Controller Class Initialized
DEBUG - 2018-02-20 17:33:46 --> Config file loaded: /var/www/html/project/radio/application/config/rest.php
INFO - 2018-02-20 17:33:46 --> Helper loaded: inflector_helper
INFO - 2018-02-20 17:33:46 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-20 17:33:46 --> Model Class Initialized
INFO - 2018-02-20 17:33:46 --> Model Class Initialized
INFO - 2018-02-20 17:33:46 --> Model Class Initialized
INFO - 2018-02-20 17:34:31 --> Config Class Initialized
INFO - 2018-02-20 17:34:31 --> Hooks Class Initialized
DEBUG - 2018-02-20 17:34:31 --> UTF-8 Support Enabled
INFO - 2018-02-20 17:34:31 --> Utf8 Class Initialized
INFO - 2018-02-20 17:34:31 --> URI Class Initialized
INFO - 2018-02-20 17:34:31 --> Router Class Initialized
INFO - 2018-02-20 17:34:31 --> Output Class Initialized
INFO - 2018-02-20 17:34:31 --> Security Class Initialized
DEBUG - 2018-02-20 17:34:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-20 17:34:31 --> Input Class Initialized
INFO - 2018-02-20 17:34:31 --> Language Class Initialized
INFO - 2018-02-20 17:34:31 --> Loader Class Initialized
INFO - 2018-02-20 17:34:31 --> Helper loaded: url_helper
INFO - 2018-02-20 17:34:31 --> Helper loaded: file_helper
INFO - 2018-02-20 17:34:31 --> Helper loaded: email_helper
INFO - 2018-02-20 17:34:31 --> Helper loaded: common_helper
INFO - 2018-02-20 17:34:31 --> Database Driver Class Initialized
DEBUG - 2018-02-20 17:34:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-20 17:34:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-20 17:34:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-20 17:34:31 --> Pagination Class Initialized
INFO - 2018-02-20 17:34:31 --> Helper loaded: form_helper
INFO - 2018-02-20 17:34:31 --> Form Validation Class Initialized
INFO - 2018-02-20 17:34:31 --> Model Class Initialized
INFO - 2018-02-20 17:34:31 --> Controller Class Initialized
DEBUG - 2018-02-20 17:34:31 --> Config file loaded: /var/www/html/project/radio/application/config/rest.php
INFO - 2018-02-20 17:34:31 --> Helper loaded: inflector_helper
INFO - 2018-02-20 17:34:31 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-20 17:34:31 --> Model Class Initialized
INFO - 2018-02-20 17:34:31 --> Model Class Initialized
INFO - 2018-02-20 17:34:31 --> Model Class Initialized
INFO - 2018-02-20 17:35:29 --> Config Class Initialized
INFO - 2018-02-20 17:35:29 --> Hooks Class Initialized
DEBUG - 2018-02-20 17:35:29 --> UTF-8 Support Enabled
INFO - 2018-02-20 17:35:29 --> Utf8 Class Initialized
INFO - 2018-02-20 17:35:29 --> URI Class Initialized
INFO - 2018-02-20 17:35:29 --> Router Class Initialized
INFO - 2018-02-20 17:35:29 --> Output Class Initialized
INFO - 2018-02-20 17:35:29 --> Security Class Initialized
DEBUG - 2018-02-20 17:35:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-20 17:35:29 --> Input Class Initialized
INFO - 2018-02-20 17:35:29 --> Language Class Initialized
INFO - 2018-02-20 17:35:29 --> Loader Class Initialized
INFO - 2018-02-20 17:35:29 --> Helper loaded: url_helper
INFO - 2018-02-20 17:35:29 --> Helper loaded: file_helper
INFO - 2018-02-20 17:35:29 --> Helper loaded: email_helper
INFO - 2018-02-20 17:35:29 --> Helper loaded: common_helper
INFO - 2018-02-20 17:35:29 --> Database Driver Class Initialized
DEBUG - 2018-02-20 17:35:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-20 17:35:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-20 17:35:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-20 17:35:29 --> Pagination Class Initialized
INFO - 2018-02-20 17:35:29 --> Helper loaded: form_helper
INFO - 2018-02-20 17:35:29 --> Form Validation Class Initialized
INFO - 2018-02-20 17:35:29 --> Model Class Initialized
INFO - 2018-02-20 17:35:29 --> Controller Class Initialized
DEBUG - 2018-02-20 17:35:29 --> Config file loaded: /var/www/html/project/radio/application/config/rest.php
INFO - 2018-02-20 17:35:29 --> Helper loaded: inflector_helper
INFO - 2018-02-20 17:35:29 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-20 17:35:29 --> Model Class Initialized
INFO - 2018-02-20 17:35:29 --> Model Class Initialized
INFO - 2018-02-20 17:35:29 --> Model Class Initialized
INFO - 2018-02-20 17:35:40 --> Config Class Initialized
INFO - 2018-02-20 17:35:40 --> Hooks Class Initialized
DEBUG - 2018-02-20 17:35:40 --> UTF-8 Support Enabled
INFO - 2018-02-20 17:35:40 --> Utf8 Class Initialized
INFO - 2018-02-20 17:35:40 --> URI Class Initialized
INFO - 2018-02-20 17:35:40 --> Router Class Initialized
INFO - 2018-02-20 17:35:40 --> Output Class Initialized
INFO - 2018-02-20 17:35:40 --> Security Class Initialized
DEBUG - 2018-02-20 17:35:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-20 17:35:40 --> Input Class Initialized
INFO - 2018-02-20 17:35:40 --> Language Class Initialized
INFO - 2018-02-20 17:35:40 --> Loader Class Initialized
INFO - 2018-02-20 17:35:40 --> Helper loaded: url_helper
INFO - 2018-02-20 17:35:40 --> Helper loaded: file_helper
INFO - 2018-02-20 17:35:40 --> Helper loaded: email_helper
INFO - 2018-02-20 17:35:40 --> Helper loaded: common_helper
INFO - 2018-02-20 17:35:40 --> Database Driver Class Initialized
DEBUG - 2018-02-20 17:35:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-20 17:35:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-20 17:35:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-20 17:35:40 --> Pagination Class Initialized
INFO - 2018-02-20 17:35:40 --> Helper loaded: form_helper
INFO - 2018-02-20 17:35:40 --> Form Validation Class Initialized
INFO - 2018-02-20 17:35:40 --> Model Class Initialized
INFO - 2018-02-20 17:35:40 --> Controller Class Initialized
DEBUG - 2018-02-20 17:35:40 --> Config file loaded: /var/www/html/project/radio/application/config/rest.php
INFO - 2018-02-20 17:35:40 --> Helper loaded: inflector_helper
INFO - 2018-02-20 17:35:40 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-20 17:35:40 --> Model Class Initialized
INFO - 2018-02-20 17:35:40 --> Model Class Initialized
INFO - 2018-02-20 17:35:40 --> Model Class Initialized
INFO - 2018-02-20 17:36:04 --> Config Class Initialized
INFO - 2018-02-20 17:36:04 --> Hooks Class Initialized
DEBUG - 2018-02-20 17:36:04 --> UTF-8 Support Enabled
INFO - 2018-02-20 17:36:04 --> Utf8 Class Initialized
INFO - 2018-02-20 17:36:04 --> URI Class Initialized
INFO - 2018-02-20 17:36:04 --> Router Class Initialized
INFO - 2018-02-20 17:36:04 --> Output Class Initialized
INFO - 2018-02-20 17:36:04 --> Security Class Initialized
DEBUG - 2018-02-20 17:36:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-20 17:36:04 --> Input Class Initialized
INFO - 2018-02-20 17:36:04 --> Language Class Initialized
INFO - 2018-02-20 17:36:04 --> Loader Class Initialized
INFO - 2018-02-20 17:36:04 --> Helper loaded: url_helper
INFO - 2018-02-20 17:36:04 --> Helper loaded: file_helper
INFO - 2018-02-20 17:36:04 --> Helper loaded: email_helper
INFO - 2018-02-20 17:36:04 --> Helper loaded: common_helper
INFO - 2018-02-20 17:36:04 --> Database Driver Class Initialized
DEBUG - 2018-02-20 17:36:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-20 17:36:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-20 17:36:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-20 17:36:04 --> Pagination Class Initialized
INFO - 2018-02-20 17:36:04 --> Helper loaded: form_helper
INFO - 2018-02-20 17:36:04 --> Form Validation Class Initialized
INFO - 2018-02-20 17:36:04 --> Model Class Initialized
INFO - 2018-02-20 17:36:04 --> Controller Class Initialized
DEBUG - 2018-02-20 17:36:05 --> Config file loaded: /var/www/html/project/radio/application/config/rest.php
INFO - 2018-02-20 17:36:05 --> Helper loaded: inflector_helper
INFO - 2018-02-20 17:36:05 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-20 17:36:05 --> Model Class Initialized
INFO - 2018-02-20 17:36:05 --> Model Class Initialized
INFO - 2018-02-20 17:36:05 --> Model Class Initialized
INFO - 2018-02-20 17:41:37 --> Config Class Initialized
INFO - 2018-02-20 17:41:37 --> Hooks Class Initialized
DEBUG - 2018-02-20 17:41:37 --> UTF-8 Support Enabled
INFO - 2018-02-20 17:41:37 --> Utf8 Class Initialized
INFO - 2018-02-20 17:41:37 --> URI Class Initialized
INFO - 2018-02-20 17:41:37 --> Router Class Initialized
INFO - 2018-02-20 17:41:37 --> Output Class Initialized
INFO - 2018-02-20 17:41:37 --> Security Class Initialized
DEBUG - 2018-02-20 17:41:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-20 17:41:37 --> Input Class Initialized
INFO - 2018-02-20 17:41:37 --> Language Class Initialized
INFO - 2018-02-20 17:41:37 --> Loader Class Initialized
INFO - 2018-02-20 17:41:37 --> Helper loaded: url_helper
INFO - 2018-02-20 17:41:37 --> Helper loaded: file_helper
INFO - 2018-02-20 17:41:37 --> Helper loaded: email_helper
INFO - 2018-02-20 17:41:37 --> Helper loaded: common_helper
INFO - 2018-02-20 17:41:37 --> Database Driver Class Initialized
DEBUG - 2018-02-20 17:41:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-20 17:41:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-20 17:41:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-20 17:41:37 --> Pagination Class Initialized
INFO - 2018-02-20 17:41:37 --> Helper loaded: form_helper
INFO - 2018-02-20 17:41:37 --> Form Validation Class Initialized
INFO - 2018-02-20 17:41:37 --> Model Class Initialized
INFO - 2018-02-20 17:41:37 --> Controller Class Initialized
DEBUG - 2018-02-20 17:41:37 --> Config file loaded: /var/www/html/project/radio/application/config/rest.php
INFO - 2018-02-20 17:41:37 --> Helper loaded: inflector_helper
INFO - 2018-02-20 17:41:37 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-20 17:41:37 --> Model Class Initialized
INFO - 2018-02-20 17:41:37 --> Model Class Initialized
INFO - 2018-02-20 17:41:37 --> Model Class Initialized
INFO - 2018-02-20 17:41:57 --> Config Class Initialized
INFO - 2018-02-20 17:41:57 --> Hooks Class Initialized
DEBUG - 2018-02-20 17:41:57 --> UTF-8 Support Enabled
INFO - 2018-02-20 17:41:57 --> Utf8 Class Initialized
INFO - 2018-02-20 17:41:57 --> URI Class Initialized
INFO - 2018-02-20 17:41:57 --> Router Class Initialized
INFO - 2018-02-20 17:41:57 --> Output Class Initialized
INFO - 2018-02-20 17:41:57 --> Security Class Initialized
DEBUG - 2018-02-20 17:41:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-20 17:41:57 --> Input Class Initialized
INFO - 2018-02-20 17:41:57 --> Language Class Initialized
INFO - 2018-02-20 17:41:57 --> Loader Class Initialized
INFO - 2018-02-20 17:41:57 --> Helper loaded: url_helper
INFO - 2018-02-20 17:41:57 --> Helper loaded: file_helper
INFO - 2018-02-20 17:41:57 --> Helper loaded: email_helper
INFO - 2018-02-20 17:41:57 --> Helper loaded: common_helper
INFO - 2018-02-20 17:41:57 --> Database Driver Class Initialized
DEBUG - 2018-02-20 17:41:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-20 17:41:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-20 17:41:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-20 17:41:57 --> Pagination Class Initialized
INFO - 2018-02-20 17:41:57 --> Helper loaded: form_helper
INFO - 2018-02-20 17:41:57 --> Form Validation Class Initialized
INFO - 2018-02-20 17:41:57 --> Model Class Initialized
INFO - 2018-02-20 17:41:57 --> Controller Class Initialized
DEBUG - 2018-02-20 17:41:57 --> Config file loaded: /var/www/html/project/radio/application/config/rest.php
INFO - 2018-02-20 17:41:57 --> Helper loaded: inflector_helper
INFO - 2018-02-20 17:41:57 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-20 17:41:57 --> Model Class Initialized
INFO - 2018-02-20 17:41:57 --> Model Class Initialized
INFO - 2018-02-20 17:41:57 --> Model Class Initialized
INFO - 2018-02-20 17:42:31 --> Config Class Initialized
INFO - 2018-02-20 17:42:31 --> Hooks Class Initialized
DEBUG - 2018-02-20 17:42:31 --> UTF-8 Support Enabled
INFO - 2018-02-20 17:42:31 --> Utf8 Class Initialized
INFO - 2018-02-20 17:42:31 --> URI Class Initialized
INFO - 2018-02-20 17:42:31 --> Router Class Initialized
INFO - 2018-02-20 17:42:31 --> Output Class Initialized
INFO - 2018-02-20 17:42:31 --> Security Class Initialized
DEBUG - 2018-02-20 17:42:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-20 17:42:31 --> Input Class Initialized
INFO - 2018-02-20 17:42:31 --> Language Class Initialized
INFO - 2018-02-20 17:42:31 --> Loader Class Initialized
INFO - 2018-02-20 17:42:31 --> Helper loaded: url_helper
INFO - 2018-02-20 17:42:31 --> Helper loaded: file_helper
INFO - 2018-02-20 17:42:31 --> Helper loaded: email_helper
INFO - 2018-02-20 17:42:31 --> Helper loaded: common_helper
INFO - 2018-02-20 17:42:31 --> Database Driver Class Initialized
DEBUG - 2018-02-20 17:42:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-20 17:42:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-20 17:42:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-20 17:42:31 --> Pagination Class Initialized
INFO - 2018-02-20 17:42:31 --> Helper loaded: form_helper
INFO - 2018-02-20 17:42:31 --> Form Validation Class Initialized
INFO - 2018-02-20 17:42:31 --> Model Class Initialized
INFO - 2018-02-20 17:42:31 --> Controller Class Initialized
DEBUG - 2018-02-20 17:42:31 --> Config file loaded: /var/www/html/project/radio/application/config/rest.php
INFO - 2018-02-20 17:42:31 --> Helper loaded: inflector_helper
INFO - 2018-02-20 17:42:31 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-20 17:42:31 --> Model Class Initialized
INFO - 2018-02-20 17:42:31 --> Model Class Initialized
INFO - 2018-02-20 17:42:31 --> Model Class Initialized
INFO - 2018-02-20 18:01:26 --> Config Class Initialized
INFO - 2018-02-20 18:01:26 --> Hooks Class Initialized
DEBUG - 2018-02-20 18:01:26 --> UTF-8 Support Enabled
INFO - 2018-02-20 18:01:26 --> Utf8 Class Initialized
INFO - 2018-02-20 18:01:26 --> URI Class Initialized
INFO - 2018-02-20 18:01:26 --> Router Class Initialized
INFO - 2018-02-20 18:01:26 --> Output Class Initialized
INFO - 2018-02-20 18:01:26 --> Security Class Initialized
DEBUG - 2018-02-20 18:01:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-20 18:01:26 --> Input Class Initialized
INFO - 2018-02-20 18:01:26 --> Language Class Initialized
INFO - 2018-02-20 18:01:26 --> Loader Class Initialized
INFO - 2018-02-20 18:01:26 --> Helper loaded: url_helper
INFO - 2018-02-20 18:01:26 --> Helper loaded: file_helper
INFO - 2018-02-20 18:01:26 --> Helper loaded: email_helper
INFO - 2018-02-20 18:01:26 --> Helper loaded: common_helper
INFO - 2018-02-20 18:01:26 --> Database Driver Class Initialized
DEBUG - 2018-02-20 18:01:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-20 18:01:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-20 18:01:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-20 18:01:26 --> Pagination Class Initialized
INFO - 2018-02-20 18:01:26 --> Helper loaded: form_helper
INFO - 2018-02-20 18:01:26 --> Form Validation Class Initialized
INFO - 2018-02-20 18:01:26 --> Model Class Initialized
INFO - 2018-02-20 18:01:26 --> Controller Class Initialized
DEBUG - 2018-02-20 18:01:26 --> Config file loaded: /var/www/html/project/radio/application/config/rest.php
INFO - 2018-02-20 18:01:26 --> Helper loaded: inflector_helper
INFO - 2018-02-20 18:01:26 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-20 18:01:26 --> Model Class Initialized
INFO - 2018-02-20 18:01:26 --> Model Class Initialized
INFO - 2018-02-20 18:01:26 --> Model Class Initialized
INFO - 2018-02-20 18:03:55 --> Config Class Initialized
INFO - 2018-02-20 18:03:55 --> Hooks Class Initialized
DEBUG - 2018-02-20 18:03:55 --> UTF-8 Support Enabled
INFO - 2018-02-20 18:03:55 --> Utf8 Class Initialized
INFO - 2018-02-20 18:03:55 --> URI Class Initialized
INFO - 2018-02-20 18:03:55 --> Router Class Initialized
INFO - 2018-02-20 18:03:55 --> Output Class Initialized
INFO - 2018-02-20 18:03:55 --> Security Class Initialized
DEBUG - 2018-02-20 18:03:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-20 18:03:55 --> Input Class Initialized
INFO - 2018-02-20 18:03:55 --> Language Class Initialized
INFO - 2018-02-20 18:03:55 --> Loader Class Initialized
INFO - 2018-02-20 18:03:55 --> Helper loaded: url_helper
INFO - 2018-02-20 18:03:55 --> Helper loaded: file_helper
INFO - 2018-02-20 18:03:55 --> Helper loaded: email_helper
INFO - 2018-02-20 18:03:55 --> Helper loaded: common_helper
INFO - 2018-02-20 18:03:55 --> Database Driver Class Initialized
DEBUG - 2018-02-20 18:03:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-20 18:03:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-20 18:03:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-20 18:03:55 --> Pagination Class Initialized
INFO - 2018-02-20 18:03:55 --> Helper loaded: form_helper
INFO - 2018-02-20 18:03:55 --> Form Validation Class Initialized
INFO - 2018-02-20 18:03:55 --> Model Class Initialized
INFO - 2018-02-20 18:03:55 --> Controller Class Initialized
DEBUG - 2018-02-20 18:03:55 --> Config file loaded: /var/www/html/project/radio/application/config/rest.php
INFO - 2018-02-20 18:03:55 --> Helper loaded: inflector_helper
INFO - 2018-02-20 18:03:55 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-20 18:03:55 --> Model Class Initialized
INFO - 2018-02-20 18:03:55 --> Model Class Initialized
INFO - 2018-02-20 18:03:55 --> Model Class Initialized
ERROR - 2018-02-20 18:03:55 --> Severity: Warning --> array_push() expects parameter 1 to be array, null given /var/www/html/project/radio/application/controllers/api/Fetchappdata.php 72
ERROR - 2018-02-20 18:03:55 --> Severity: Warning --> array_push() expects parameter 1 to be array, null given /var/www/html/project/radio/application/controllers/api/Fetchappdata.php 72
ERROR - 2018-02-20 18:03:55 --> Severity: Warning --> array_push() expects parameter 1 to be array, null given /var/www/html/project/radio/application/controllers/api/Fetchappdata.php 72
ERROR - 2018-02-20 18:03:55 --> Severity: Warning --> array_push() expects parameter 1 to be array, null given /var/www/html/project/radio/application/controllers/api/Fetchappdata.php 72
INFO - 2018-02-20 18:07:45 --> Config Class Initialized
INFO - 2018-02-20 18:07:45 --> Hooks Class Initialized
DEBUG - 2018-02-20 18:07:45 --> UTF-8 Support Enabled
INFO - 2018-02-20 18:07:45 --> Utf8 Class Initialized
INFO - 2018-02-20 18:07:45 --> URI Class Initialized
INFO - 2018-02-20 18:07:45 --> Router Class Initialized
INFO - 2018-02-20 18:07:45 --> Output Class Initialized
INFO - 2018-02-20 18:07:45 --> Security Class Initialized
DEBUG - 2018-02-20 18:07:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-20 18:07:45 --> Input Class Initialized
INFO - 2018-02-20 18:07:45 --> Language Class Initialized
INFO - 2018-02-20 18:07:45 --> Loader Class Initialized
INFO - 2018-02-20 18:07:45 --> Helper loaded: url_helper
INFO - 2018-02-20 18:07:45 --> Helper loaded: file_helper
INFO - 2018-02-20 18:07:45 --> Helper loaded: email_helper
INFO - 2018-02-20 18:07:45 --> Helper loaded: common_helper
INFO - 2018-02-20 18:07:45 --> Database Driver Class Initialized
DEBUG - 2018-02-20 18:07:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-20 18:07:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-20 18:07:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-20 18:07:45 --> Pagination Class Initialized
INFO - 2018-02-20 18:07:45 --> Helper loaded: form_helper
INFO - 2018-02-20 18:07:45 --> Form Validation Class Initialized
INFO - 2018-02-20 18:07:45 --> Model Class Initialized
INFO - 2018-02-20 18:07:45 --> Controller Class Initialized
DEBUG - 2018-02-20 18:07:45 --> Config file loaded: /var/www/html/project/radio/application/config/rest.php
INFO - 2018-02-20 18:07:45 --> Helper loaded: inflector_helper
INFO - 2018-02-20 18:07:45 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-20 18:07:45 --> Model Class Initialized
INFO - 2018-02-20 18:07:45 --> Model Class Initialized
INFO - 2018-02-20 18:07:45 --> Model Class Initialized
INFO - 2018-02-20 18:08:28 --> Config Class Initialized
INFO - 2018-02-20 18:08:28 --> Hooks Class Initialized
DEBUG - 2018-02-20 18:08:28 --> UTF-8 Support Enabled
INFO - 2018-02-20 18:08:28 --> Utf8 Class Initialized
INFO - 2018-02-20 18:08:28 --> URI Class Initialized
INFO - 2018-02-20 18:08:28 --> Router Class Initialized
INFO - 2018-02-20 18:08:28 --> Output Class Initialized
INFO - 2018-02-20 18:08:28 --> Security Class Initialized
DEBUG - 2018-02-20 18:08:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-20 18:08:28 --> Input Class Initialized
INFO - 2018-02-20 18:08:28 --> Language Class Initialized
INFO - 2018-02-20 18:08:28 --> Loader Class Initialized
INFO - 2018-02-20 18:08:28 --> Helper loaded: url_helper
INFO - 2018-02-20 18:08:28 --> Helper loaded: file_helper
INFO - 2018-02-20 18:08:28 --> Helper loaded: email_helper
INFO - 2018-02-20 18:08:28 --> Helper loaded: common_helper
INFO - 2018-02-20 18:08:28 --> Database Driver Class Initialized
DEBUG - 2018-02-20 18:08:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-20 18:08:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-20 18:08:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-20 18:08:28 --> Pagination Class Initialized
INFO - 2018-02-20 18:08:28 --> Helper loaded: form_helper
INFO - 2018-02-20 18:08:28 --> Form Validation Class Initialized
INFO - 2018-02-20 18:08:28 --> Model Class Initialized
INFO - 2018-02-20 18:08:28 --> Controller Class Initialized
DEBUG - 2018-02-20 18:08:28 --> Config file loaded: /var/www/html/project/radio/application/config/rest.php
INFO - 2018-02-20 18:08:28 --> Helper loaded: inflector_helper
INFO - 2018-02-20 18:08:28 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-20 18:08:28 --> Model Class Initialized
INFO - 2018-02-20 18:08:28 --> Model Class Initialized
INFO - 2018-02-20 18:08:28 --> Model Class Initialized
INFO - 2018-02-20 18:10:47 --> Config Class Initialized
INFO - 2018-02-20 18:10:47 --> Hooks Class Initialized
DEBUG - 2018-02-20 18:10:47 --> UTF-8 Support Enabled
INFO - 2018-02-20 18:10:47 --> Utf8 Class Initialized
INFO - 2018-02-20 18:10:47 --> URI Class Initialized
INFO - 2018-02-20 18:10:47 --> Router Class Initialized
INFO - 2018-02-20 18:10:47 --> Output Class Initialized
INFO - 2018-02-20 18:10:47 --> Security Class Initialized
DEBUG - 2018-02-20 18:10:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-20 18:10:47 --> Input Class Initialized
INFO - 2018-02-20 18:10:47 --> Language Class Initialized
INFO - 2018-02-20 18:10:47 --> Loader Class Initialized
INFO - 2018-02-20 18:10:47 --> Helper loaded: url_helper
INFO - 2018-02-20 18:10:47 --> Helper loaded: file_helper
INFO - 2018-02-20 18:10:47 --> Helper loaded: email_helper
INFO - 2018-02-20 18:10:47 --> Helper loaded: common_helper
INFO - 2018-02-20 18:10:47 --> Database Driver Class Initialized
DEBUG - 2018-02-20 18:10:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-20 18:10:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-20 18:10:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-20 18:10:47 --> Pagination Class Initialized
INFO - 2018-02-20 18:10:47 --> Helper loaded: form_helper
INFO - 2018-02-20 18:10:47 --> Form Validation Class Initialized
INFO - 2018-02-20 18:10:47 --> Model Class Initialized
INFO - 2018-02-20 18:10:47 --> Controller Class Initialized
DEBUG - 2018-02-20 18:10:47 --> Config file loaded: /var/www/html/project/radio/application/config/rest.php
INFO - 2018-02-20 18:10:47 --> Helper loaded: inflector_helper
INFO - 2018-02-20 18:10:47 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-20 18:10:47 --> Model Class Initialized
INFO - 2018-02-20 18:10:47 --> Model Class Initialized
INFO - 2018-02-20 18:10:47 --> Model Class Initialized
INFO - 2018-02-20 18:20:43 --> Config Class Initialized
INFO - 2018-02-20 18:20:43 --> Hooks Class Initialized
DEBUG - 2018-02-20 18:20:43 --> UTF-8 Support Enabled
INFO - 2018-02-20 18:20:43 --> Utf8 Class Initialized
INFO - 2018-02-20 18:20:43 --> URI Class Initialized
INFO - 2018-02-20 18:20:43 --> Router Class Initialized
INFO - 2018-02-20 18:20:43 --> Output Class Initialized
INFO - 2018-02-20 18:20:43 --> Security Class Initialized
DEBUG - 2018-02-20 18:20:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-20 18:20:43 --> Input Class Initialized
INFO - 2018-02-20 18:20:43 --> Language Class Initialized
INFO - 2018-02-20 18:20:43 --> Loader Class Initialized
INFO - 2018-02-20 18:20:43 --> Helper loaded: url_helper
INFO - 2018-02-20 18:20:43 --> Helper loaded: file_helper
INFO - 2018-02-20 18:20:43 --> Helper loaded: email_helper
INFO - 2018-02-20 18:20:43 --> Helper loaded: common_helper
INFO - 2018-02-20 18:20:43 --> Database Driver Class Initialized
DEBUG - 2018-02-20 18:20:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-20 18:20:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-20 18:20:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-20 18:20:43 --> Pagination Class Initialized
INFO - 2018-02-20 18:20:43 --> Helper loaded: form_helper
INFO - 2018-02-20 18:20:43 --> Form Validation Class Initialized
INFO - 2018-02-20 18:20:43 --> Model Class Initialized
INFO - 2018-02-20 18:20:43 --> Controller Class Initialized
DEBUG - 2018-02-20 18:20:43 --> Config file loaded: /var/www/html/project/radio/application/config/rest.php
INFO - 2018-02-20 18:20:43 --> Helper loaded: inflector_helper
INFO - 2018-02-20 18:20:43 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-20 18:20:43 --> Model Class Initialized
INFO - 2018-02-20 18:20:43 --> Model Class Initialized
INFO - 2018-02-20 18:20:43 --> Model Class Initialized
ERROR - 2018-02-20 18:20:43 --> Severity: Notice --> Undefined variable: dateTime /var/www/html/project/radio/application/models/Subcategory_model.php 206
ERROR - 2018-02-20 18:20:43 --> Severity: Notice --> Undefined variable: dateTime /var/www/html/project/radio/application/models/Subcategory_model.php 207
ERROR - 2018-02-20 18:20:43 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'AND `sc`.`tsCreatedAt` <
AND  (`c`.`tsUpdatedAt` > '2018-02-15 20:40:00' OR `sc`' at line 9 - Invalid query: SELECT `c`.`iCategoryId` `catId`, `c`.`vTitle` as `catName`, `c`.`txDescription` as `catDesc`, `c`.`vIconImage` as `catImg`, `c`.`tStatus` as `catStatus`, `c`.`tsCreatedAt` as `catCreated`, `sc`.`iSubCategoryId` as `subCatId`, `sc`.`iCategoryId` `relCatId`, `sc`.`vTitle` as `subCatName`, `sc`.`txDescription` as `subCatDesc`, `sc`.`vIconImage` as `subCatImg`, `sc`.`tStatus` as `subCatStatus`, `sc`.`tsCreatedAt` as `subCatCreated`
FROM `category` as `c`
LEFT JOIN `subcategory` as `sc` ON `c`.`iCategoryId` = `sc`.`iCategoryId`
WHERE `c`.`is_deleted` =0
AND `sc`.`is_deleted` =0
AND `c`.`tStatus` = 1
AND `sc`.`tStatus` = 1
AND `c`.`tsCreatedAt` <
AND `sc`.`tsCreatedAt` <
AND  (`c`.`tsUpdatedAt` > '2018-02-15 20:40:00' OR `sc`.`tsUpdatedAt` > '2018-02-15 20:40:00' )
INFO - 2018-02-20 18:20:43 --> Language file loaded: language/english/db_lang.php
INFO - 2018-02-20 18:21:06 --> Config Class Initialized
INFO - 2018-02-20 18:21:06 --> Hooks Class Initialized
DEBUG - 2018-02-20 18:21:06 --> UTF-8 Support Enabled
INFO - 2018-02-20 18:21:06 --> Utf8 Class Initialized
INFO - 2018-02-20 18:21:06 --> URI Class Initialized
INFO - 2018-02-20 18:21:06 --> Router Class Initialized
INFO - 2018-02-20 18:21:06 --> Output Class Initialized
INFO - 2018-02-20 18:21:06 --> Security Class Initialized
DEBUG - 2018-02-20 18:21:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-20 18:21:06 --> Input Class Initialized
INFO - 2018-02-20 18:21:06 --> Language Class Initialized
INFO - 2018-02-20 18:21:06 --> Loader Class Initialized
INFO - 2018-02-20 18:21:06 --> Helper loaded: url_helper
INFO - 2018-02-20 18:21:06 --> Helper loaded: file_helper
INFO - 2018-02-20 18:21:06 --> Helper loaded: email_helper
INFO - 2018-02-20 18:21:06 --> Helper loaded: common_helper
INFO - 2018-02-20 18:21:06 --> Database Driver Class Initialized
DEBUG - 2018-02-20 18:21:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-20 18:21:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-20 18:21:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-20 18:21:06 --> Pagination Class Initialized
INFO - 2018-02-20 18:21:06 --> Helper loaded: form_helper
INFO - 2018-02-20 18:21:06 --> Form Validation Class Initialized
INFO - 2018-02-20 18:21:06 --> Model Class Initialized
INFO - 2018-02-20 18:21:06 --> Controller Class Initialized
DEBUG - 2018-02-20 18:21:06 --> Config file loaded: /var/www/html/project/radio/application/config/rest.php
INFO - 2018-02-20 18:21:06 --> Helper loaded: inflector_helper
INFO - 2018-02-20 18:21:06 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-20 18:21:06 --> Model Class Initialized
INFO - 2018-02-20 18:21:06 --> Model Class Initialized
INFO - 2018-02-20 18:21:06 --> Model Class Initialized
ERROR - 2018-02-20 18:21:06 --> Severity: error --> Exception: Call to undefined method Subcategory_model::getDeletedCatSubCat() /var/www/html/project/radio/application/controllers/api/Fetchappdata.php 58
INFO - 2018-02-20 18:21:15 --> Config Class Initialized
INFO - 2018-02-20 18:21:15 --> Hooks Class Initialized
DEBUG - 2018-02-20 18:21:15 --> UTF-8 Support Enabled
INFO - 2018-02-20 18:21:15 --> Utf8 Class Initialized
INFO - 2018-02-20 18:21:15 --> URI Class Initialized
INFO - 2018-02-20 18:21:15 --> Router Class Initialized
INFO - 2018-02-20 18:21:15 --> Output Class Initialized
INFO - 2018-02-20 18:21:15 --> Security Class Initialized
DEBUG - 2018-02-20 18:21:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-20 18:21:15 --> Input Class Initialized
INFO - 2018-02-20 18:21:15 --> Language Class Initialized
INFO - 2018-02-20 18:21:15 --> Loader Class Initialized
INFO - 2018-02-20 18:21:15 --> Helper loaded: url_helper
INFO - 2018-02-20 18:21:15 --> Helper loaded: file_helper
INFO - 2018-02-20 18:21:15 --> Helper loaded: email_helper
INFO - 2018-02-20 18:21:15 --> Helper loaded: common_helper
INFO - 2018-02-20 18:21:15 --> Database Driver Class Initialized
DEBUG - 2018-02-20 18:21:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-20 18:21:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-20 18:21:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-20 18:21:15 --> Pagination Class Initialized
INFO - 2018-02-20 18:21:15 --> Helper loaded: form_helper
INFO - 2018-02-20 18:21:15 --> Form Validation Class Initialized
INFO - 2018-02-20 18:21:15 --> Model Class Initialized
INFO - 2018-02-20 18:21:15 --> Controller Class Initialized
DEBUG - 2018-02-20 18:21:15 --> Config file loaded: /var/www/html/project/radio/application/config/rest.php
INFO - 2018-02-20 18:21:15 --> Helper loaded: inflector_helper
INFO - 2018-02-20 18:21:15 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-20 18:21:15 --> Model Class Initialized
INFO - 2018-02-20 18:21:15 --> Model Class Initialized
INFO - 2018-02-20 18:21:15 --> Model Class Initialized
INFO - 2018-02-20 18:23:23 --> Config Class Initialized
INFO - 2018-02-20 18:23:23 --> Hooks Class Initialized
DEBUG - 2018-02-20 18:23:23 --> UTF-8 Support Enabled
INFO - 2018-02-20 18:23:23 --> Utf8 Class Initialized
INFO - 2018-02-20 18:23:23 --> URI Class Initialized
INFO - 2018-02-20 18:23:23 --> Router Class Initialized
INFO - 2018-02-20 18:23:23 --> Output Class Initialized
INFO - 2018-02-20 18:23:23 --> Security Class Initialized
DEBUG - 2018-02-20 18:23:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-20 18:23:23 --> Input Class Initialized
INFO - 2018-02-20 18:23:23 --> Language Class Initialized
INFO - 2018-02-20 18:23:23 --> Loader Class Initialized
INFO - 2018-02-20 18:23:23 --> Helper loaded: url_helper
INFO - 2018-02-20 18:23:23 --> Helper loaded: file_helper
INFO - 2018-02-20 18:23:23 --> Helper loaded: email_helper
INFO - 2018-02-20 18:23:23 --> Helper loaded: common_helper
INFO - 2018-02-20 18:23:23 --> Database Driver Class Initialized
DEBUG - 2018-02-20 18:23:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-20 18:23:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-20 18:23:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-20 18:23:23 --> Pagination Class Initialized
INFO - 2018-02-20 18:23:23 --> Helper loaded: form_helper
INFO - 2018-02-20 18:23:23 --> Form Validation Class Initialized
INFO - 2018-02-20 18:23:23 --> Model Class Initialized
INFO - 2018-02-20 18:23:23 --> Controller Class Initialized
DEBUG - 2018-02-20 18:23:23 --> Config file loaded: /var/www/html/project/radio/application/config/rest.php
INFO - 2018-02-20 18:23:23 --> Helper loaded: inflector_helper
INFO - 2018-02-20 18:23:23 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-20 18:23:23 --> Model Class Initialized
INFO - 2018-02-20 18:23:23 --> Model Class Initialized
INFO - 2018-02-20 18:23:23 --> Model Class Initialized
INFO - 2018-02-20 18:24:55 --> Config Class Initialized
INFO - 2018-02-20 18:24:55 --> Hooks Class Initialized
DEBUG - 2018-02-20 18:24:55 --> UTF-8 Support Enabled
INFO - 2018-02-20 18:24:55 --> Utf8 Class Initialized
INFO - 2018-02-20 18:24:55 --> URI Class Initialized
INFO - 2018-02-20 18:24:55 --> Router Class Initialized
INFO - 2018-02-20 18:24:55 --> Output Class Initialized
INFO - 2018-02-20 18:24:55 --> Security Class Initialized
DEBUG - 2018-02-20 18:24:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-20 18:24:55 --> Input Class Initialized
INFO - 2018-02-20 18:24:55 --> Language Class Initialized
INFO - 2018-02-20 18:24:55 --> Loader Class Initialized
INFO - 2018-02-20 18:24:55 --> Helper loaded: url_helper
INFO - 2018-02-20 18:24:55 --> Helper loaded: file_helper
INFO - 2018-02-20 18:24:55 --> Helper loaded: email_helper
INFO - 2018-02-20 18:24:55 --> Helper loaded: common_helper
INFO - 2018-02-20 18:24:55 --> Database Driver Class Initialized
DEBUG - 2018-02-20 18:24:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-20 18:24:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-20 18:24:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-20 18:24:55 --> Pagination Class Initialized
INFO - 2018-02-20 18:24:55 --> Helper loaded: form_helper
INFO - 2018-02-20 18:24:55 --> Form Validation Class Initialized
INFO - 2018-02-20 18:24:55 --> Model Class Initialized
INFO - 2018-02-20 18:24:55 --> Controller Class Initialized
DEBUG - 2018-02-20 18:24:55 --> Config file loaded: /var/www/html/project/radio/application/config/rest.php
INFO - 2018-02-20 18:24:55 --> Helper loaded: inflector_helper
INFO - 2018-02-20 18:24:55 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-20 18:24:55 --> Model Class Initialized
INFO - 2018-02-20 18:24:55 --> Model Class Initialized
INFO - 2018-02-20 18:24:55 --> Model Class Initialized
INFO - 2018-02-20 18:26:12 --> Config Class Initialized
INFO - 2018-02-20 18:26:12 --> Hooks Class Initialized
DEBUG - 2018-02-20 18:26:12 --> UTF-8 Support Enabled
INFO - 2018-02-20 18:26:12 --> Utf8 Class Initialized
INFO - 2018-02-20 18:26:12 --> URI Class Initialized
INFO - 2018-02-20 18:26:12 --> Router Class Initialized
INFO - 2018-02-20 18:26:12 --> Output Class Initialized
INFO - 2018-02-20 18:26:12 --> Security Class Initialized
DEBUG - 2018-02-20 18:26:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-20 18:26:12 --> Input Class Initialized
INFO - 2018-02-20 18:26:12 --> Language Class Initialized
INFO - 2018-02-20 18:26:12 --> Loader Class Initialized
INFO - 2018-02-20 18:26:12 --> Helper loaded: url_helper
INFO - 2018-02-20 18:26:12 --> Helper loaded: file_helper
INFO - 2018-02-20 18:26:12 --> Helper loaded: email_helper
INFO - 2018-02-20 18:26:12 --> Helper loaded: common_helper
INFO - 2018-02-20 18:26:12 --> Database Driver Class Initialized
DEBUG - 2018-02-20 18:26:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-20 18:26:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-20 18:26:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-20 18:26:12 --> Pagination Class Initialized
INFO - 2018-02-20 18:26:12 --> Helper loaded: form_helper
INFO - 2018-02-20 18:26:12 --> Form Validation Class Initialized
INFO - 2018-02-20 18:26:12 --> Model Class Initialized
INFO - 2018-02-20 18:26:12 --> Controller Class Initialized
DEBUG - 2018-02-20 18:26:12 --> Config file loaded: /var/www/html/project/radio/application/config/rest.php
INFO - 2018-02-20 18:26:12 --> Helper loaded: inflector_helper
INFO - 2018-02-20 18:26:12 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-20 18:26:12 --> Model Class Initialized
INFO - 2018-02-20 18:26:12 --> Model Class Initialized
INFO - 2018-02-20 18:26:12 --> Model Class Initialized
INFO - 2018-02-20 18:26:37 --> Config Class Initialized
INFO - 2018-02-20 18:26:37 --> Hooks Class Initialized
DEBUG - 2018-02-20 18:26:37 --> UTF-8 Support Enabled
INFO - 2018-02-20 18:26:37 --> Utf8 Class Initialized
INFO - 2018-02-20 18:26:37 --> URI Class Initialized
INFO - 2018-02-20 18:26:37 --> Router Class Initialized
INFO - 2018-02-20 18:26:37 --> Output Class Initialized
INFO - 2018-02-20 18:26:37 --> Security Class Initialized
DEBUG - 2018-02-20 18:26:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-20 18:26:37 --> Input Class Initialized
INFO - 2018-02-20 18:26:37 --> Language Class Initialized
INFO - 2018-02-20 18:26:37 --> Loader Class Initialized
INFO - 2018-02-20 18:26:37 --> Helper loaded: url_helper
INFO - 2018-02-20 18:26:37 --> Helper loaded: file_helper
INFO - 2018-02-20 18:26:37 --> Helper loaded: email_helper
INFO - 2018-02-20 18:26:37 --> Helper loaded: common_helper
INFO - 2018-02-20 18:26:37 --> Database Driver Class Initialized
DEBUG - 2018-02-20 18:26:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-20 18:26:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-20 18:26:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-20 18:26:37 --> Pagination Class Initialized
INFO - 2018-02-20 18:26:37 --> Helper loaded: form_helper
INFO - 2018-02-20 18:26:37 --> Form Validation Class Initialized
INFO - 2018-02-20 18:26:37 --> Model Class Initialized
INFO - 2018-02-20 18:26:37 --> Controller Class Initialized
DEBUG - 2018-02-20 18:26:37 --> Config file loaded: /var/www/html/project/radio/application/config/rest.php
INFO - 2018-02-20 18:26:37 --> Helper loaded: inflector_helper
INFO - 2018-02-20 18:26:37 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-20 18:26:37 --> Model Class Initialized
INFO - 2018-02-20 18:26:37 --> Model Class Initialized
INFO - 2018-02-20 18:26:37 --> Model Class Initialized
INFO - 2018-02-20 18:31:04 --> Config Class Initialized
INFO - 2018-02-20 18:31:04 --> Hooks Class Initialized
DEBUG - 2018-02-20 18:31:04 --> UTF-8 Support Enabled
INFO - 2018-02-20 18:31:04 --> Utf8 Class Initialized
INFO - 2018-02-20 18:31:04 --> URI Class Initialized
INFO - 2018-02-20 18:31:04 --> Router Class Initialized
INFO - 2018-02-20 18:31:04 --> Output Class Initialized
INFO - 2018-02-20 18:31:04 --> Security Class Initialized
DEBUG - 2018-02-20 18:31:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-20 18:31:04 --> Input Class Initialized
INFO - 2018-02-20 18:31:04 --> Language Class Initialized
INFO - 2018-02-20 18:31:04 --> Loader Class Initialized
INFO - 2018-02-20 18:31:04 --> Helper loaded: url_helper
INFO - 2018-02-20 18:31:04 --> Helper loaded: file_helper
INFO - 2018-02-20 18:31:04 --> Helper loaded: email_helper
INFO - 2018-02-20 18:31:04 --> Helper loaded: common_helper
INFO - 2018-02-20 18:31:04 --> Database Driver Class Initialized
DEBUG - 2018-02-20 18:31:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-20 18:31:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-20 18:31:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-20 18:31:04 --> Pagination Class Initialized
INFO - 2018-02-20 18:31:04 --> Helper loaded: form_helper
INFO - 2018-02-20 18:31:04 --> Form Validation Class Initialized
INFO - 2018-02-20 18:31:04 --> Model Class Initialized
INFO - 2018-02-20 18:31:04 --> Controller Class Initialized
DEBUG - 2018-02-20 18:31:04 --> Config file loaded: /var/www/html/project/radio/application/config/rest.php
INFO - 2018-02-20 18:31:04 --> Helper loaded: inflector_helper
INFO - 2018-02-20 18:31:04 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-20 18:31:04 --> Model Class Initialized
INFO - 2018-02-20 18:31:04 --> Model Class Initialized
INFO - 2018-02-20 18:31:04 --> Model Class Initialized
INFO - 2018-02-20 18:31:30 --> Config Class Initialized
INFO - 2018-02-20 18:31:30 --> Hooks Class Initialized
DEBUG - 2018-02-20 18:31:30 --> UTF-8 Support Enabled
INFO - 2018-02-20 18:31:30 --> Utf8 Class Initialized
INFO - 2018-02-20 18:31:30 --> URI Class Initialized
INFO - 2018-02-20 18:31:30 --> Router Class Initialized
INFO - 2018-02-20 18:31:30 --> Output Class Initialized
INFO - 2018-02-20 18:31:30 --> Security Class Initialized
DEBUG - 2018-02-20 18:31:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-20 18:31:30 --> Input Class Initialized
INFO - 2018-02-20 18:31:30 --> Language Class Initialized
INFO - 2018-02-20 18:31:30 --> Loader Class Initialized
INFO - 2018-02-20 18:31:30 --> Helper loaded: url_helper
INFO - 2018-02-20 18:31:30 --> Helper loaded: file_helper
INFO - 2018-02-20 18:31:30 --> Helper loaded: email_helper
INFO - 2018-02-20 18:31:30 --> Helper loaded: common_helper
INFO - 2018-02-20 18:31:30 --> Database Driver Class Initialized
DEBUG - 2018-02-20 18:31:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-20 18:31:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-20 18:31:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-20 18:31:30 --> Pagination Class Initialized
INFO - 2018-02-20 18:31:30 --> Helper loaded: form_helper
INFO - 2018-02-20 18:31:30 --> Form Validation Class Initialized
INFO - 2018-02-20 18:31:30 --> Model Class Initialized
INFO - 2018-02-20 18:31:30 --> Controller Class Initialized
DEBUG - 2018-02-20 18:31:30 --> Config file loaded: /var/www/html/project/radio/application/config/rest.php
INFO - 2018-02-20 18:31:30 --> Helper loaded: inflector_helper
INFO - 2018-02-20 18:31:30 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-20 18:31:30 --> Model Class Initialized
INFO - 2018-02-20 18:31:30 --> Model Class Initialized
INFO - 2018-02-20 18:31:30 --> Model Class Initialized
INFO - 2018-02-20 18:31:44 --> Config Class Initialized
INFO - 2018-02-20 18:31:44 --> Hooks Class Initialized
DEBUG - 2018-02-20 18:31:44 --> UTF-8 Support Enabled
INFO - 2018-02-20 18:31:44 --> Utf8 Class Initialized
INFO - 2018-02-20 18:31:44 --> URI Class Initialized
INFO - 2018-02-20 18:31:44 --> Router Class Initialized
INFO - 2018-02-20 18:31:44 --> Output Class Initialized
INFO - 2018-02-20 18:31:44 --> Security Class Initialized
DEBUG - 2018-02-20 18:31:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-20 18:31:44 --> Input Class Initialized
INFO - 2018-02-20 18:31:44 --> Language Class Initialized
INFO - 2018-02-20 18:31:44 --> Loader Class Initialized
INFO - 2018-02-20 18:31:44 --> Helper loaded: url_helper
INFO - 2018-02-20 18:31:44 --> Helper loaded: file_helper
INFO - 2018-02-20 18:31:44 --> Helper loaded: email_helper
INFO - 2018-02-20 18:31:44 --> Helper loaded: common_helper
INFO - 2018-02-20 18:31:44 --> Database Driver Class Initialized
DEBUG - 2018-02-20 18:31:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-20 18:31:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-20 18:31:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-20 18:31:44 --> Pagination Class Initialized
INFO - 2018-02-20 18:31:44 --> Helper loaded: form_helper
INFO - 2018-02-20 18:31:44 --> Form Validation Class Initialized
INFO - 2018-02-20 18:31:44 --> Model Class Initialized
INFO - 2018-02-20 18:31:44 --> Controller Class Initialized
DEBUG - 2018-02-20 18:31:44 --> Config file loaded: /var/www/html/project/radio/application/config/rest.php
INFO - 2018-02-20 18:31:44 --> Helper loaded: inflector_helper
INFO - 2018-02-20 18:31:44 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-20 18:31:44 --> Model Class Initialized
INFO - 2018-02-20 18:31:44 --> Model Class Initialized
INFO - 2018-02-20 18:31:44 --> Model Class Initialized
INFO - 2018-02-20 18:32:01 --> Config Class Initialized
INFO - 2018-02-20 18:32:01 --> Hooks Class Initialized
DEBUG - 2018-02-20 18:32:01 --> UTF-8 Support Enabled
INFO - 2018-02-20 18:32:01 --> Utf8 Class Initialized
INFO - 2018-02-20 18:32:01 --> URI Class Initialized
INFO - 2018-02-20 18:32:01 --> Router Class Initialized
INFO - 2018-02-20 18:32:01 --> Output Class Initialized
INFO - 2018-02-20 18:32:01 --> Security Class Initialized
DEBUG - 2018-02-20 18:32:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-20 18:32:01 --> Input Class Initialized
INFO - 2018-02-20 18:32:01 --> Language Class Initialized
INFO - 2018-02-20 18:32:01 --> Loader Class Initialized
INFO - 2018-02-20 18:32:01 --> Helper loaded: url_helper
INFO - 2018-02-20 18:32:01 --> Helper loaded: file_helper
INFO - 2018-02-20 18:32:01 --> Helper loaded: email_helper
INFO - 2018-02-20 18:32:01 --> Helper loaded: common_helper
INFO - 2018-02-20 18:32:01 --> Database Driver Class Initialized
DEBUG - 2018-02-20 18:32:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-20 18:32:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-20 18:32:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-20 18:32:01 --> Pagination Class Initialized
INFO - 2018-02-20 18:32:01 --> Helper loaded: form_helper
INFO - 2018-02-20 18:32:01 --> Form Validation Class Initialized
INFO - 2018-02-20 18:32:01 --> Model Class Initialized
INFO - 2018-02-20 18:32:01 --> Controller Class Initialized
DEBUG - 2018-02-20 18:32:01 --> Config file loaded: /var/www/html/project/radio/application/config/rest.php
INFO - 2018-02-20 18:32:01 --> Helper loaded: inflector_helper
INFO - 2018-02-20 18:32:01 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-20 18:32:01 --> Model Class Initialized
INFO - 2018-02-20 18:32:01 --> Model Class Initialized
INFO - 2018-02-20 18:32:01 --> Model Class Initialized
INFO - 2018-02-20 18:32:13 --> Config Class Initialized
INFO - 2018-02-20 18:32:13 --> Hooks Class Initialized
DEBUG - 2018-02-20 18:32:13 --> UTF-8 Support Enabled
INFO - 2018-02-20 18:32:13 --> Utf8 Class Initialized
INFO - 2018-02-20 18:32:13 --> URI Class Initialized
INFO - 2018-02-20 18:32:13 --> Router Class Initialized
INFO - 2018-02-20 18:32:13 --> Output Class Initialized
INFO - 2018-02-20 18:32:13 --> Security Class Initialized
DEBUG - 2018-02-20 18:32:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-20 18:32:13 --> Input Class Initialized
INFO - 2018-02-20 18:32:13 --> Language Class Initialized
INFO - 2018-02-20 18:32:13 --> Loader Class Initialized
INFO - 2018-02-20 18:32:13 --> Helper loaded: url_helper
INFO - 2018-02-20 18:32:13 --> Helper loaded: file_helper
INFO - 2018-02-20 18:32:13 --> Helper loaded: email_helper
INFO - 2018-02-20 18:32:13 --> Helper loaded: common_helper
INFO - 2018-02-20 18:32:13 --> Database Driver Class Initialized
DEBUG - 2018-02-20 18:32:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-20 18:32:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-20 18:32:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-20 18:32:13 --> Pagination Class Initialized
INFO - 2018-02-20 18:32:13 --> Helper loaded: form_helper
INFO - 2018-02-20 18:32:13 --> Form Validation Class Initialized
INFO - 2018-02-20 18:32:13 --> Model Class Initialized
INFO - 2018-02-20 18:32:13 --> Controller Class Initialized
DEBUG - 2018-02-20 18:32:13 --> Config file loaded: /var/www/html/project/radio/application/config/rest.php
INFO - 2018-02-20 18:32:13 --> Helper loaded: inflector_helper
INFO - 2018-02-20 18:32:13 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-20 18:32:13 --> Model Class Initialized
INFO - 2018-02-20 18:32:13 --> Model Class Initialized
INFO - 2018-02-20 18:32:13 --> Model Class Initialized
INFO - 2018-02-20 18:32:38 --> Config Class Initialized
INFO - 2018-02-20 18:32:38 --> Hooks Class Initialized
DEBUG - 2018-02-20 18:32:38 --> UTF-8 Support Enabled
INFO - 2018-02-20 18:32:38 --> Utf8 Class Initialized
INFO - 2018-02-20 18:32:38 --> URI Class Initialized
INFO - 2018-02-20 18:32:38 --> Router Class Initialized
INFO - 2018-02-20 18:32:38 --> Output Class Initialized
INFO - 2018-02-20 18:32:38 --> Security Class Initialized
DEBUG - 2018-02-20 18:32:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-20 18:32:38 --> Input Class Initialized
INFO - 2018-02-20 18:32:38 --> Language Class Initialized
INFO - 2018-02-20 18:32:38 --> Loader Class Initialized
INFO - 2018-02-20 18:32:38 --> Helper loaded: url_helper
INFO - 2018-02-20 18:32:38 --> Helper loaded: file_helper
INFO - 2018-02-20 18:32:38 --> Helper loaded: email_helper
INFO - 2018-02-20 18:32:38 --> Helper loaded: common_helper
INFO - 2018-02-20 18:32:38 --> Database Driver Class Initialized
DEBUG - 2018-02-20 18:32:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-20 18:32:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-20 18:32:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-20 18:32:38 --> Pagination Class Initialized
INFO - 2018-02-20 18:32:38 --> Helper loaded: form_helper
INFO - 2018-02-20 18:32:38 --> Form Validation Class Initialized
INFO - 2018-02-20 18:32:38 --> Model Class Initialized
INFO - 2018-02-20 18:32:38 --> Controller Class Initialized
DEBUG - 2018-02-20 18:32:38 --> Config file loaded: /var/www/html/project/radio/application/config/rest.php
INFO - 2018-02-20 18:32:38 --> Helper loaded: inflector_helper
INFO - 2018-02-20 18:32:38 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-20 18:32:38 --> Model Class Initialized
INFO - 2018-02-20 18:32:38 --> Model Class Initialized
INFO - 2018-02-20 18:32:38 --> Model Class Initialized
INFO - 2018-02-20 18:32:51 --> Config Class Initialized
INFO - 2018-02-20 18:32:51 --> Hooks Class Initialized
DEBUG - 2018-02-20 18:32:51 --> UTF-8 Support Enabled
INFO - 2018-02-20 18:32:51 --> Utf8 Class Initialized
INFO - 2018-02-20 18:32:51 --> URI Class Initialized
INFO - 2018-02-20 18:32:51 --> Router Class Initialized
INFO - 2018-02-20 18:32:51 --> Output Class Initialized
INFO - 2018-02-20 18:32:51 --> Security Class Initialized
DEBUG - 2018-02-20 18:32:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-20 18:32:51 --> Input Class Initialized
INFO - 2018-02-20 18:32:51 --> Language Class Initialized
INFO - 2018-02-20 18:32:51 --> Loader Class Initialized
INFO - 2018-02-20 18:32:51 --> Helper loaded: url_helper
INFO - 2018-02-20 18:32:51 --> Helper loaded: file_helper
INFO - 2018-02-20 18:32:51 --> Helper loaded: email_helper
INFO - 2018-02-20 18:32:51 --> Helper loaded: common_helper
INFO - 2018-02-20 18:32:51 --> Database Driver Class Initialized
DEBUG - 2018-02-20 18:32:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-20 18:32:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-20 18:32:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-20 18:32:51 --> Pagination Class Initialized
INFO - 2018-02-20 18:32:51 --> Helper loaded: form_helper
INFO - 2018-02-20 18:32:51 --> Form Validation Class Initialized
INFO - 2018-02-20 18:32:51 --> Model Class Initialized
INFO - 2018-02-20 18:32:51 --> Controller Class Initialized
DEBUG - 2018-02-20 18:32:51 --> Config file loaded: /var/www/html/project/radio/application/config/rest.php
INFO - 2018-02-20 18:32:51 --> Helper loaded: inflector_helper
INFO - 2018-02-20 18:32:51 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-20 18:32:51 --> Model Class Initialized
INFO - 2018-02-20 18:32:51 --> Model Class Initialized
INFO - 2018-02-20 18:32:51 --> Model Class Initialized
INFO - 2018-02-20 18:34:24 --> Config Class Initialized
INFO - 2018-02-20 18:34:24 --> Hooks Class Initialized
DEBUG - 2018-02-20 18:34:24 --> UTF-8 Support Enabled
INFO - 2018-02-20 18:34:24 --> Utf8 Class Initialized
INFO - 2018-02-20 18:34:24 --> URI Class Initialized
INFO - 2018-02-20 18:34:24 --> Router Class Initialized
INFO - 2018-02-20 18:34:24 --> Output Class Initialized
INFO - 2018-02-20 18:34:24 --> Security Class Initialized
DEBUG - 2018-02-20 18:34:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-20 18:34:24 --> Input Class Initialized
INFO - 2018-02-20 18:34:24 --> Language Class Initialized
INFO - 2018-02-20 18:34:24 --> Loader Class Initialized
INFO - 2018-02-20 18:34:24 --> Helper loaded: url_helper
INFO - 2018-02-20 18:34:24 --> Helper loaded: file_helper
INFO - 2018-02-20 18:34:24 --> Helper loaded: email_helper
INFO - 2018-02-20 18:34:24 --> Helper loaded: common_helper
INFO - 2018-02-20 18:34:24 --> Database Driver Class Initialized
DEBUG - 2018-02-20 18:34:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-20 18:34:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-20 18:34:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-20 18:34:24 --> Pagination Class Initialized
INFO - 2018-02-20 18:34:24 --> Helper loaded: form_helper
INFO - 2018-02-20 18:34:24 --> Form Validation Class Initialized
INFO - 2018-02-20 18:34:24 --> Model Class Initialized
INFO - 2018-02-20 18:34:24 --> Controller Class Initialized
DEBUG - 2018-02-20 18:34:24 --> Config file loaded: /var/www/html/project/radio/application/config/rest.php
INFO - 2018-02-20 18:34:24 --> Helper loaded: inflector_helper
INFO - 2018-02-20 18:34:24 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-20 18:34:24 --> Model Class Initialized
INFO - 2018-02-20 18:34:24 --> Model Class Initialized
INFO - 2018-02-20 18:34:24 --> Model Class Initialized
INFO - 2018-02-20 18:35:52 --> Config Class Initialized
INFO - 2018-02-20 18:35:52 --> Hooks Class Initialized
DEBUG - 2018-02-20 18:35:52 --> UTF-8 Support Enabled
INFO - 2018-02-20 18:35:52 --> Utf8 Class Initialized
INFO - 2018-02-20 18:35:52 --> URI Class Initialized
INFO - 2018-02-20 18:35:52 --> Router Class Initialized
INFO - 2018-02-20 18:35:52 --> Output Class Initialized
INFO - 2018-02-20 18:35:52 --> Security Class Initialized
DEBUG - 2018-02-20 18:35:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-20 18:35:52 --> Input Class Initialized
INFO - 2018-02-20 18:35:52 --> Language Class Initialized
INFO - 2018-02-20 18:35:52 --> Loader Class Initialized
INFO - 2018-02-20 18:35:52 --> Helper loaded: url_helper
INFO - 2018-02-20 18:35:52 --> Helper loaded: file_helper
INFO - 2018-02-20 18:35:52 --> Helper loaded: email_helper
INFO - 2018-02-20 18:35:52 --> Helper loaded: common_helper
INFO - 2018-02-20 18:35:52 --> Database Driver Class Initialized
DEBUG - 2018-02-20 18:35:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-20 18:35:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-20 18:35:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-20 18:35:52 --> Pagination Class Initialized
INFO - 2018-02-20 18:35:52 --> Helper loaded: form_helper
INFO - 2018-02-20 18:35:52 --> Form Validation Class Initialized
INFO - 2018-02-20 18:35:52 --> Model Class Initialized
INFO - 2018-02-20 18:35:52 --> Controller Class Initialized
DEBUG - 2018-02-20 18:35:52 --> Config file loaded: /var/www/html/project/radio/application/config/rest.php
INFO - 2018-02-20 18:35:52 --> Helper loaded: inflector_helper
INFO - 2018-02-20 18:35:52 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-20 18:35:52 --> Model Class Initialized
INFO - 2018-02-20 18:35:52 --> Model Class Initialized
INFO - 2018-02-20 18:35:52 --> Model Class Initialized
INFO - 2018-02-20 18:38:38 --> Config Class Initialized
INFO - 2018-02-20 18:38:38 --> Hooks Class Initialized
DEBUG - 2018-02-20 18:38:38 --> UTF-8 Support Enabled
INFO - 2018-02-20 18:38:38 --> Utf8 Class Initialized
INFO - 2018-02-20 18:38:38 --> URI Class Initialized
INFO - 2018-02-20 18:38:38 --> Router Class Initialized
INFO - 2018-02-20 18:38:38 --> Output Class Initialized
INFO - 2018-02-20 18:38:38 --> Security Class Initialized
DEBUG - 2018-02-20 18:38:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-20 18:38:38 --> Input Class Initialized
INFO - 2018-02-20 18:38:38 --> Language Class Initialized
INFO - 2018-02-20 18:38:38 --> Loader Class Initialized
INFO - 2018-02-20 18:38:38 --> Helper loaded: url_helper
INFO - 2018-02-20 18:38:38 --> Helper loaded: file_helper
INFO - 2018-02-20 18:38:38 --> Helper loaded: email_helper
INFO - 2018-02-20 18:38:38 --> Helper loaded: common_helper
INFO - 2018-02-20 18:38:38 --> Database Driver Class Initialized
DEBUG - 2018-02-20 18:38:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-20 18:38:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-20 18:38:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-20 18:38:38 --> Pagination Class Initialized
INFO - 2018-02-20 18:38:38 --> Helper loaded: form_helper
INFO - 2018-02-20 18:38:38 --> Form Validation Class Initialized
INFO - 2018-02-20 18:38:38 --> Model Class Initialized
INFO - 2018-02-20 18:38:38 --> Controller Class Initialized
DEBUG - 2018-02-20 18:38:38 --> Config file loaded: /var/www/html/project/radio/application/config/rest.php
INFO - 2018-02-20 18:38:38 --> Helper loaded: inflector_helper
INFO - 2018-02-20 18:38:38 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-20 18:38:38 --> Model Class Initialized
INFO - 2018-02-20 18:38:38 --> Model Class Initialized
INFO - 2018-02-20 18:38:38 --> Model Class Initialized
INFO - 2018-02-20 18:38:38 --> Final output sent to browser
DEBUG - 2018-02-20 18:38:38 --> Total execution time: 0.0071
INFO - 2018-02-20 18:52:14 --> Config Class Initialized
INFO - 2018-02-20 18:52:14 --> Hooks Class Initialized
DEBUG - 2018-02-20 18:52:14 --> UTF-8 Support Enabled
INFO - 2018-02-20 18:52:14 --> Utf8 Class Initialized
INFO - 2018-02-20 18:52:14 --> URI Class Initialized
INFO - 2018-02-20 18:52:14 --> Router Class Initialized
INFO - 2018-02-20 18:52:14 --> Output Class Initialized
INFO - 2018-02-20 18:52:14 --> Security Class Initialized
DEBUG - 2018-02-20 18:52:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-20 18:52:14 --> Input Class Initialized
INFO - 2018-02-20 18:52:14 --> Language Class Initialized
INFO - 2018-02-20 18:52:14 --> Loader Class Initialized
INFO - 2018-02-20 18:52:14 --> Helper loaded: url_helper
INFO - 2018-02-20 18:52:14 --> Helper loaded: file_helper
INFO - 2018-02-20 18:52:14 --> Helper loaded: email_helper
INFO - 2018-02-20 18:52:14 --> Helper loaded: common_helper
INFO - 2018-02-20 18:52:14 --> Database Driver Class Initialized
DEBUG - 2018-02-20 18:52:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-20 18:52:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-20 18:52:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-20 18:52:14 --> Pagination Class Initialized
INFO - 2018-02-20 18:52:14 --> Helper loaded: form_helper
INFO - 2018-02-20 18:52:14 --> Form Validation Class Initialized
INFO - 2018-02-20 18:52:14 --> Model Class Initialized
INFO - 2018-02-20 18:52:14 --> Controller Class Initialized
DEBUG - 2018-02-20 18:52:14 --> Config file loaded: /var/www/html/project/radio/application/config/rest.php
INFO - 2018-02-20 18:52:14 --> Helper loaded: inflector_helper
INFO - 2018-02-20 18:52:14 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-20 18:52:14 --> Model Class Initialized
INFO - 2018-02-20 18:52:14 --> Model Class Initialized
INFO - 2018-02-20 18:52:14 --> Model Class Initialized
INFO - 2018-02-20 18:52:14 --> Final output sent to browser
DEBUG - 2018-02-20 18:52:14 --> Total execution time: 0.0074
INFO - 2018-02-20 18:52:35 --> Config Class Initialized
INFO - 2018-02-20 18:52:35 --> Hooks Class Initialized
DEBUG - 2018-02-20 18:52:35 --> UTF-8 Support Enabled
INFO - 2018-02-20 18:52:35 --> Utf8 Class Initialized
INFO - 2018-02-20 18:52:35 --> URI Class Initialized
INFO - 2018-02-20 18:52:35 --> Router Class Initialized
INFO - 2018-02-20 18:52:35 --> Output Class Initialized
INFO - 2018-02-20 18:52:35 --> Security Class Initialized
DEBUG - 2018-02-20 18:52:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-20 18:52:35 --> Input Class Initialized
INFO - 2018-02-20 18:52:35 --> Language Class Initialized
INFO - 2018-02-20 18:52:35 --> Loader Class Initialized
INFO - 2018-02-20 18:52:35 --> Helper loaded: url_helper
INFO - 2018-02-20 18:52:35 --> Helper loaded: file_helper
INFO - 2018-02-20 18:52:35 --> Helper loaded: email_helper
INFO - 2018-02-20 18:52:35 --> Helper loaded: common_helper
INFO - 2018-02-20 18:52:35 --> Database Driver Class Initialized
DEBUG - 2018-02-20 18:52:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-20 18:52:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-20 18:52:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-20 18:52:35 --> Pagination Class Initialized
INFO - 2018-02-20 18:52:35 --> Helper loaded: form_helper
INFO - 2018-02-20 18:52:35 --> Form Validation Class Initialized
INFO - 2018-02-20 18:52:35 --> Model Class Initialized
INFO - 2018-02-20 18:52:35 --> Controller Class Initialized
DEBUG - 2018-02-20 18:52:35 --> Config file loaded: /var/www/html/project/radio/application/config/rest.php
INFO - 2018-02-20 18:52:35 --> Helper loaded: inflector_helper
INFO - 2018-02-20 18:52:35 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-20 18:52:35 --> Model Class Initialized
INFO - 2018-02-20 18:52:35 --> Model Class Initialized
INFO - 2018-02-20 18:52:35 --> Model Class Initialized
INFO - 2018-02-20 18:52:35 --> Final output sent to browser
DEBUG - 2018-02-20 18:52:35 --> Total execution time: 0.0064
INFO - 2018-02-20 18:52:43 --> Config Class Initialized
INFO - 2018-02-20 18:52:43 --> Hooks Class Initialized
DEBUG - 2018-02-20 18:52:43 --> UTF-8 Support Enabled
INFO - 2018-02-20 18:52:43 --> Utf8 Class Initialized
INFO - 2018-02-20 18:52:43 --> URI Class Initialized
INFO - 2018-02-20 18:52:43 --> Router Class Initialized
INFO - 2018-02-20 18:52:43 --> Output Class Initialized
INFO - 2018-02-20 18:52:43 --> Security Class Initialized
DEBUG - 2018-02-20 18:52:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-20 18:52:43 --> Input Class Initialized
INFO - 2018-02-20 18:52:43 --> Language Class Initialized
INFO - 2018-02-20 18:52:43 --> Loader Class Initialized
INFO - 2018-02-20 18:52:43 --> Helper loaded: url_helper
INFO - 2018-02-20 18:52:43 --> Helper loaded: file_helper
INFO - 2018-02-20 18:52:43 --> Helper loaded: email_helper
INFO - 2018-02-20 18:52:43 --> Helper loaded: common_helper
INFO - 2018-02-20 18:52:43 --> Database Driver Class Initialized
DEBUG - 2018-02-20 18:52:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-20 18:52:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-20 18:52:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-20 18:52:43 --> Pagination Class Initialized
INFO - 2018-02-20 18:52:43 --> Helper loaded: form_helper
INFO - 2018-02-20 18:52:43 --> Form Validation Class Initialized
INFO - 2018-02-20 18:52:43 --> Model Class Initialized
INFO - 2018-02-20 18:52:43 --> Controller Class Initialized
DEBUG - 2018-02-20 18:52:43 --> Config file loaded: /var/www/html/project/radio/application/config/rest.php
INFO - 2018-02-20 18:52:43 --> Helper loaded: inflector_helper
INFO - 2018-02-20 18:52:43 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-20 18:52:43 --> Model Class Initialized
INFO - 2018-02-20 18:52:43 --> Model Class Initialized
INFO - 2018-02-20 18:52:43 --> Model Class Initialized
INFO - 2018-02-20 18:52:43 --> Final output sent to browser
DEBUG - 2018-02-20 18:52:43 --> Total execution time: 0.0086
INFO - 2018-02-20 18:54:58 --> Config Class Initialized
INFO - 2018-02-20 18:54:58 --> Hooks Class Initialized
DEBUG - 2018-02-20 18:54:58 --> UTF-8 Support Enabled
INFO - 2018-02-20 18:54:58 --> Utf8 Class Initialized
INFO - 2018-02-20 18:54:58 --> URI Class Initialized
INFO - 2018-02-20 18:54:58 --> Router Class Initialized
INFO - 2018-02-20 18:54:58 --> Output Class Initialized
INFO - 2018-02-20 18:54:58 --> Security Class Initialized
DEBUG - 2018-02-20 18:54:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-20 18:54:58 --> Input Class Initialized
INFO - 2018-02-20 18:54:58 --> Language Class Initialized
INFO - 2018-02-20 18:54:58 --> Loader Class Initialized
INFO - 2018-02-20 18:54:58 --> Helper loaded: url_helper
INFO - 2018-02-20 18:54:58 --> Helper loaded: file_helper
INFO - 2018-02-20 18:54:58 --> Helper loaded: email_helper
INFO - 2018-02-20 18:54:58 --> Helper loaded: common_helper
INFO - 2018-02-20 18:54:58 --> Database Driver Class Initialized
DEBUG - 2018-02-20 18:54:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-20 18:54:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-20 18:54:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-20 18:54:58 --> Pagination Class Initialized
INFO - 2018-02-20 18:54:58 --> Helper loaded: form_helper
INFO - 2018-02-20 18:54:58 --> Form Validation Class Initialized
INFO - 2018-02-20 18:54:58 --> Model Class Initialized
INFO - 2018-02-20 18:54:58 --> Controller Class Initialized
DEBUG - 2018-02-20 18:54:58 --> Config file loaded: /var/www/html/project/radio/application/config/rest.php
INFO - 2018-02-20 18:54:58 --> Helper loaded: inflector_helper
INFO - 2018-02-20 18:54:58 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-20 18:54:58 --> Model Class Initialized
INFO - 2018-02-20 18:54:58 --> Model Class Initialized
INFO - 2018-02-20 18:54:58 --> Model Class Initialized
INFO - 2018-02-20 18:54:58 --> Final output sent to browser
DEBUG - 2018-02-20 18:54:58 --> Total execution time: 0.0090

<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2018-02-15 10:00:04 --> Config Class Initialized
INFO - 2018-02-15 10:00:04 --> Hooks Class Initialized
DEBUG - 2018-02-15 10:00:04 --> UTF-8 Support Enabled
INFO - 2018-02-15 10:00:04 --> Utf8 Class Initialized
INFO - 2018-02-15 10:00:04 --> URI Class Initialized
INFO - 2018-02-15 10:00:04 --> Router Class Initialized
INFO - 2018-02-15 10:00:04 --> Output Class Initialized
INFO - 2018-02-15 10:00:04 --> Security Class Initialized
DEBUG - 2018-02-15 10:00:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 10:00:04 --> Input Class Initialized
INFO - 2018-02-15 10:00:04 --> Language Class Initialized
INFO - 2018-02-15 10:00:04 --> Loader Class Initialized
INFO - 2018-02-15 10:00:04 --> Helper loaded: url_helper
INFO - 2018-02-15 10:00:04 --> Helper loaded: file_helper
INFO - 2018-02-15 10:00:04 --> Helper loaded: email_helper
INFO - 2018-02-15 10:00:04 --> Helper loaded: common_helper
INFO - 2018-02-15 10:00:04 --> Database Driver Class Initialized
DEBUG - 2018-02-15 10:00:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 10:00:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 10:00:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 10:00:04 --> Pagination Class Initialized
INFO - 2018-02-15 10:00:04 --> Helper loaded: form_helper
INFO - 2018-02-15 10:00:04 --> Form Validation Class Initialized
INFO - 2018-02-15 10:00:04 --> Model Class Initialized
INFO - 2018-02-15 10:00:04 --> Controller Class Initialized
INFO - 2018-02-15 10:00:05 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 10:00:05 --> Config Class Initialized
INFO - 2018-02-15 10:00:05 --> Hooks Class Initialized
DEBUG - 2018-02-15 10:00:05 --> UTF-8 Support Enabled
INFO - 2018-02-15 10:00:05 --> Utf8 Class Initialized
INFO - 2018-02-15 10:00:05 --> URI Class Initialized
DEBUG - 2018-02-15 10:00:05 --> No URI present. Default controller set.
INFO - 2018-02-15 10:00:05 --> Router Class Initialized
INFO - 2018-02-15 10:00:05 --> Output Class Initialized
INFO - 2018-02-15 10:00:05 --> Security Class Initialized
DEBUG - 2018-02-15 10:00:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 10:00:05 --> Input Class Initialized
INFO - 2018-02-15 10:00:05 --> Language Class Initialized
INFO - 2018-02-15 10:00:05 --> Loader Class Initialized
INFO - 2018-02-15 10:00:05 --> Helper loaded: url_helper
INFO - 2018-02-15 10:00:05 --> Helper loaded: file_helper
INFO - 2018-02-15 10:00:05 --> Helper loaded: email_helper
INFO - 2018-02-15 10:00:05 --> Helper loaded: common_helper
INFO - 2018-02-15 10:00:05 --> Database Driver Class Initialized
DEBUG - 2018-02-15 10:00:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 10:00:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 10:00:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 10:00:05 --> Pagination Class Initialized
INFO - 2018-02-15 10:00:05 --> Helper loaded: form_helper
INFO - 2018-02-15 10:00:05 --> Form Validation Class Initialized
INFO - 2018-02-15 10:00:05 --> Model Class Initialized
INFO - 2018-02-15 10:00:05 --> Controller Class Initialized
INFO - 2018-02-15 10:00:05 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 10:00:05 --> Model Class Initialized
INFO - 2018-02-15 10:00:05 --> File loaded: /var/www/html/project/radio/application/views/index/index.php
INFO - 2018-02-15 10:00:05 --> Final output sent to browser
DEBUG - 2018-02-15 10:00:05 --> Total execution time: 0.0313
INFO - 2018-02-15 10:00:07 --> Config Class Initialized
INFO - 2018-02-15 10:00:07 --> Hooks Class Initialized
DEBUG - 2018-02-15 10:00:07 --> UTF-8 Support Enabled
INFO - 2018-02-15 10:00:07 --> Utf8 Class Initialized
INFO - 2018-02-15 10:00:07 --> URI Class Initialized
INFO - 2018-02-15 10:00:07 --> Router Class Initialized
INFO - 2018-02-15 10:00:07 --> Output Class Initialized
INFO - 2018-02-15 10:00:07 --> Security Class Initialized
DEBUG - 2018-02-15 10:00:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 10:00:07 --> Input Class Initialized
INFO - 2018-02-15 10:00:07 --> Language Class Initialized
INFO - 2018-02-15 10:00:07 --> Loader Class Initialized
INFO - 2018-02-15 10:00:07 --> Helper loaded: url_helper
INFO - 2018-02-15 10:00:07 --> Helper loaded: file_helper
INFO - 2018-02-15 10:00:07 --> Helper loaded: email_helper
INFO - 2018-02-15 10:00:07 --> Helper loaded: common_helper
INFO - 2018-02-15 10:00:07 --> Database Driver Class Initialized
DEBUG - 2018-02-15 10:00:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 10:00:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 10:00:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 10:00:07 --> Pagination Class Initialized
INFO - 2018-02-15 10:00:07 --> Helper loaded: form_helper
INFO - 2018-02-15 10:00:07 --> Form Validation Class Initialized
INFO - 2018-02-15 10:00:07 --> Model Class Initialized
INFO - 2018-02-15 10:00:07 --> Controller Class Initialized
INFO - 2018-02-15 10:00:07 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 10:00:07 --> Model Class Initialized
ERROR - 2018-02-15 10:00:07 --> Severity: Notice --> Undefined index: remember_me /var/www/html/project/radio/application/controllers/Index.php 73
INFO - 2018-02-15 10:00:07 --> Config Class Initialized
INFO - 2018-02-15 10:00:07 --> Hooks Class Initialized
DEBUG - 2018-02-15 10:00:07 --> UTF-8 Support Enabled
INFO - 2018-02-15 10:00:07 --> Utf8 Class Initialized
INFO - 2018-02-15 10:00:07 --> URI Class Initialized
INFO - 2018-02-15 10:00:07 --> Router Class Initialized
INFO - 2018-02-15 10:00:07 --> Output Class Initialized
INFO - 2018-02-15 10:00:07 --> Security Class Initialized
DEBUG - 2018-02-15 10:00:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 10:00:07 --> Input Class Initialized
INFO - 2018-02-15 10:00:07 --> Language Class Initialized
INFO - 2018-02-15 10:00:07 --> Loader Class Initialized
INFO - 2018-02-15 10:00:07 --> Helper loaded: url_helper
INFO - 2018-02-15 10:00:07 --> Helper loaded: file_helper
INFO - 2018-02-15 10:00:07 --> Helper loaded: email_helper
INFO - 2018-02-15 10:00:07 --> Helper loaded: common_helper
INFO - 2018-02-15 10:00:07 --> Database Driver Class Initialized
DEBUG - 2018-02-15 10:00:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 10:00:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 10:00:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 10:00:07 --> Pagination Class Initialized
INFO - 2018-02-15 10:00:07 --> Helper loaded: form_helper
INFO - 2018-02-15 10:00:07 --> Form Validation Class Initialized
INFO - 2018-02-15 10:00:07 --> Model Class Initialized
INFO - 2018-02-15 10:00:07 --> Controller Class Initialized
INFO - 2018-02-15 10:00:07 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 10:00:07 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-15 10:00:07 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-15 10:00:07 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-15 10:00:07 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-15 10:00:07 --> File loaded: /var/www/html/project/radio/application/views/dashboard/index.php
INFO - 2018-02-15 10:00:07 --> Final output sent to browser
DEBUG - 2018-02-15 10:00:07 --> Total execution time: 0.0250
INFO - 2018-02-15 10:00:41 --> Config Class Initialized
INFO - 2018-02-15 10:00:41 --> Hooks Class Initialized
DEBUG - 2018-02-15 10:00:41 --> UTF-8 Support Enabled
INFO - 2018-02-15 10:00:41 --> Utf8 Class Initialized
INFO - 2018-02-15 10:00:41 --> URI Class Initialized
INFO - 2018-02-15 10:00:41 --> Router Class Initialized
INFO - 2018-02-15 10:00:41 --> Output Class Initialized
INFO - 2018-02-15 10:00:41 --> Security Class Initialized
DEBUG - 2018-02-15 10:00:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 10:00:41 --> Input Class Initialized
INFO - 2018-02-15 10:00:41 --> Language Class Initialized
INFO - 2018-02-15 10:00:41 --> Loader Class Initialized
INFO - 2018-02-15 10:00:41 --> Helper loaded: url_helper
INFO - 2018-02-15 10:00:41 --> Helper loaded: file_helper
INFO - 2018-02-15 10:00:41 --> Helper loaded: email_helper
INFO - 2018-02-15 10:00:41 --> Helper loaded: common_helper
INFO - 2018-02-15 10:00:41 --> Database Driver Class Initialized
DEBUG - 2018-02-15 10:00:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 10:00:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 10:00:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 10:00:41 --> Pagination Class Initialized
INFO - 2018-02-15 10:00:41 --> Helper loaded: form_helper
INFO - 2018-02-15 10:00:41 --> Form Validation Class Initialized
INFO - 2018-02-15 10:00:41 --> Model Class Initialized
INFO - 2018-02-15 10:00:41 --> Controller Class Initialized
INFO - 2018-02-15 10:00:41 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 10:00:41 --> Model Class Initialized
INFO - 2018-02-15 10:00:41 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-15 10:00:41 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-15 10:00:41 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-15 10:00:41 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-15 10:00:41 --> File loaded: /var/www/html/project/radio/application/views/category/index.php
INFO - 2018-02-15 10:00:41 --> Final output sent to browser
DEBUG - 2018-02-15 10:00:41 --> Total execution time: 0.0398
INFO - 2018-02-15 10:01:53 --> Config Class Initialized
INFO - 2018-02-15 10:01:53 --> Hooks Class Initialized
DEBUG - 2018-02-15 10:01:53 --> UTF-8 Support Enabled
INFO - 2018-02-15 10:01:53 --> Utf8 Class Initialized
INFO - 2018-02-15 10:01:53 --> URI Class Initialized
INFO - 2018-02-15 10:01:53 --> Router Class Initialized
INFO - 2018-02-15 10:01:53 --> Output Class Initialized
INFO - 2018-02-15 10:01:53 --> Security Class Initialized
DEBUG - 2018-02-15 10:01:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 10:01:53 --> Input Class Initialized
INFO - 2018-02-15 10:01:53 --> Language Class Initialized
INFO - 2018-02-15 10:01:53 --> Loader Class Initialized
INFO - 2018-02-15 10:01:53 --> Helper loaded: url_helper
INFO - 2018-02-15 10:01:53 --> Helper loaded: file_helper
INFO - 2018-02-15 10:01:53 --> Helper loaded: email_helper
INFO - 2018-02-15 10:01:53 --> Helper loaded: common_helper
INFO - 2018-02-15 10:01:53 --> Database Driver Class Initialized
DEBUG - 2018-02-15 10:01:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 10:01:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 10:01:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 10:01:53 --> Pagination Class Initialized
INFO - 2018-02-15 10:01:53 --> Helper loaded: form_helper
INFO - 2018-02-15 10:01:53 --> Form Validation Class Initialized
INFO - 2018-02-15 10:01:53 --> Model Class Initialized
INFO - 2018-02-15 10:01:53 --> Controller Class Initialized
INFO - 2018-02-15 10:01:53 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 10:01:53 --> Model Class Initialized
INFO - 2018-02-15 10:01:53 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-15 10:01:53 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-15 10:01:53 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-15 10:01:53 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-15 10:01:53 --> File loaded: /var/www/html/project/radio/application/views/category/index.php
INFO - 2018-02-15 10:01:53 --> Final output sent to browser
DEBUG - 2018-02-15 10:01:53 --> Total execution time: 0.0335
INFO - 2018-02-15 10:04:01 --> Config Class Initialized
INFO - 2018-02-15 10:04:01 --> Hooks Class Initialized
DEBUG - 2018-02-15 10:04:01 --> UTF-8 Support Enabled
INFO - 2018-02-15 10:04:01 --> Utf8 Class Initialized
INFO - 2018-02-15 10:04:01 --> URI Class Initialized
INFO - 2018-02-15 10:04:01 --> Router Class Initialized
INFO - 2018-02-15 10:04:01 --> Output Class Initialized
INFO - 2018-02-15 10:04:01 --> Security Class Initialized
DEBUG - 2018-02-15 10:04:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 10:04:01 --> Input Class Initialized
INFO - 2018-02-15 10:04:01 --> Language Class Initialized
INFO - 2018-02-15 10:04:01 --> Loader Class Initialized
INFO - 2018-02-15 10:04:01 --> Helper loaded: url_helper
INFO - 2018-02-15 10:04:01 --> Helper loaded: file_helper
INFO - 2018-02-15 10:04:01 --> Helper loaded: email_helper
INFO - 2018-02-15 10:04:01 --> Helper loaded: common_helper
INFO - 2018-02-15 10:04:01 --> Database Driver Class Initialized
DEBUG - 2018-02-15 10:04:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 10:04:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 10:04:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 10:04:01 --> Pagination Class Initialized
INFO - 2018-02-15 10:04:01 --> Helper loaded: form_helper
INFO - 2018-02-15 10:04:01 --> Form Validation Class Initialized
INFO - 2018-02-15 10:04:01 --> Model Class Initialized
INFO - 2018-02-15 10:04:01 --> Controller Class Initialized
INFO - 2018-02-15 10:04:01 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 10:04:01 --> Model Class Initialized
INFO - 2018-02-15 10:04:01 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-15 10:04:01 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-15 10:04:01 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-15 10:04:01 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-15 10:04:01 --> File loaded: /var/www/html/project/radio/application/views/category/add_edit.php
INFO - 2018-02-15 10:04:01 --> Final output sent to browser
DEBUG - 2018-02-15 10:04:01 --> Total execution time: 0.0228
INFO - 2018-02-15 10:05:19 --> Config Class Initialized
INFO - 2018-02-15 10:05:19 --> Hooks Class Initialized
DEBUG - 2018-02-15 10:05:19 --> UTF-8 Support Enabled
INFO - 2018-02-15 10:05:19 --> Utf8 Class Initialized
INFO - 2018-02-15 10:05:19 --> URI Class Initialized
INFO - 2018-02-15 10:05:19 --> Router Class Initialized
INFO - 2018-02-15 10:05:19 --> Output Class Initialized
INFO - 2018-02-15 10:05:19 --> Security Class Initialized
DEBUG - 2018-02-15 10:05:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 10:05:19 --> Input Class Initialized
INFO - 2018-02-15 10:05:19 --> Language Class Initialized
INFO - 2018-02-15 10:05:19 --> Loader Class Initialized
INFO - 2018-02-15 10:05:19 --> Helper loaded: url_helper
INFO - 2018-02-15 10:05:19 --> Helper loaded: file_helper
INFO - 2018-02-15 10:05:19 --> Helper loaded: email_helper
INFO - 2018-02-15 10:05:19 --> Helper loaded: common_helper
INFO - 2018-02-15 10:05:19 --> Database Driver Class Initialized
DEBUG - 2018-02-15 10:05:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 10:05:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 10:05:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 10:05:19 --> Pagination Class Initialized
INFO - 2018-02-15 10:05:19 --> Helper loaded: form_helper
INFO - 2018-02-15 10:05:19 --> Form Validation Class Initialized
INFO - 2018-02-15 10:05:19 --> Model Class Initialized
INFO - 2018-02-15 10:05:19 --> Controller Class Initialized
INFO - 2018-02-15 10:05:19 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 10:05:19 --> Model Class Initialized
INFO - 2018-02-15 10:05:19 --> Model Class Initialized
INFO - 2018-02-15 10:05:19 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-15 10:05:19 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-15 10:05:19 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-15 10:05:19 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-15 10:05:19 --> File loaded: /var/www/html/project/radio/application/views/subcategory/index.php
INFO - 2018-02-15 10:05:19 --> Final output sent to browser
DEBUG - 2018-02-15 10:05:19 --> Total execution time: 0.0349
INFO - 2018-02-15 10:05:23 --> Config Class Initialized
INFO - 2018-02-15 10:05:23 --> Hooks Class Initialized
DEBUG - 2018-02-15 10:05:23 --> UTF-8 Support Enabled
INFO - 2018-02-15 10:05:23 --> Utf8 Class Initialized
INFO - 2018-02-15 10:05:23 --> URI Class Initialized
INFO - 2018-02-15 10:05:23 --> Router Class Initialized
INFO - 2018-02-15 10:05:23 --> Output Class Initialized
INFO - 2018-02-15 10:05:23 --> Security Class Initialized
DEBUG - 2018-02-15 10:05:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 10:05:23 --> Input Class Initialized
INFO - 2018-02-15 10:05:23 --> Language Class Initialized
INFO - 2018-02-15 10:05:23 --> Loader Class Initialized
INFO - 2018-02-15 10:05:23 --> Helper loaded: url_helper
INFO - 2018-02-15 10:05:23 --> Helper loaded: file_helper
INFO - 2018-02-15 10:05:23 --> Helper loaded: email_helper
INFO - 2018-02-15 10:05:23 --> Helper loaded: common_helper
INFO - 2018-02-15 10:05:23 --> Database Driver Class Initialized
DEBUG - 2018-02-15 10:05:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 10:05:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 10:05:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 10:05:23 --> Pagination Class Initialized
INFO - 2018-02-15 10:05:23 --> Helper loaded: form_helper
INFO - 2018-02-15 10:05:23 --> Form Validation Class Initialized
INFO - 2018-02-15 10:05:23 --> Model Class Initialized
INFO - 2018-02-15 10:05:23 --> Controller Class Initialized
INFO - 2018-02-15 10:05:23 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 10:05:23 --> Model Class Initialized
INFO - 2018-02-15 10:05:23 --> Model Class Initialized
INFO - 2018-02-15 10:05:23 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-15 10:05:23 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-15 10:05:23 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-15 10:05:23 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-15 10:05:23 --> File loaded: /var/www/html/project/radio/application/views/subcategory/add_edit.php
INFO - 2018-02-15 10:05:23 --> Final output sent to browser
DEBUG - 2018-02-15 10:05:23 --> Total execution time: 0.0063
INFO - 2018-02-15 10:05:50 --> Config Class Initialized
INFO - 2018-02-15 10:05:50 --> Hooks Class Initialized
DEBUG - 2018-02-15 10:05:50 --> UTF-8 Support Enabled
INFO - 2018-02-15 10:05:50 --> Utf8 Class Initialized
INFO - 2018-02-15 10:05:50 --> URI Class Initialized
INFO - 2018-02-15 10:05:50 --> Router Class Initialized
INFO - 2018-02-15 10:05:50 --> Output Class Initialized
INFO - 2018-02-15 10:05:50 --> Security Class Initialized
DEBUG - 2018-02-15 10:05:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 10:05:50 --> Input Class Initialized
INFO - 2018-02-15 10:05:50 --> Language Class Initialized
INFO - 2018-02-15 10:05:50 --> Loader Class Initialized
INFO - 2018-02-15 10:05:50 --> Helper loaded: url_helper
INFO - 2018-02-15 10:05:50 --> Helper loaded: file_helper
INFO - 2018-02-15 10:05:50 --> Helper loaded: email_helper
INFO - 2018-02-15 10:05:50 --> Helper loaded: common_helper
INFO - 2018-02-15 10:05:50 --> Database Driver Class Initialized
DEBUG - 2018-02-15 10:05:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 10:05:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 10:05:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 10:05:50 --> Pagination Class Initialized
INFO - 2018-02-15 10:05:50 --> Helper loaded: form_helper
INFO - 2018-02-15 10:05:50 --> Form Validation Class Initialized
INFO - 2018-02-15 10:05:50 --> Model Class Initialized
INFO - 2018-02-15 10:05:50 --> Controller Class Initialized
INFO - 2018-02-15 10:05:50 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 10:05:50 --> Model Class Initialized
INFO - 2018-02-15 10:05:50 --> Model Class Initialized
INFO - 2018-02-15 10:05:50 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-15 10:05:50 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-15 10:05:50 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-15 10:05:50 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-15 10:05:50 --> File loaded: /var/www/html/project/radio/application/views/subcategory/add_edit.php
INFO - 2018-02-15 10:05:50 --> Final output sent to browser
DEBUG - 2018-02-15 10:05:50 --> Total execution time: 0.0095
INFO - 2018-02-15 10:05:56 --> Config Class Initialized
INFO - 2018-02-15 10:05:56 --> Hooks Class Initialized
DEBUG - 2018-02-15 10:05:56 --> UTF-8 Support Enabled
INFO - 2018-02-15 10:05:56 --> Utf8 Class Initialized
INFO - 2018-02-15 10:05:56 --> URI Class Initialized
INFO - 2018-02-15 10:05:56 --> Router Class Initialized
INFO - 2018-02-15 10:05:56 --> Output Class Initialized
INFO - 2018-02-15 10:05:56 --> Security Class Initialized
DEBUG - 2018-02-15 10:05:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 10:05:56 --> Input Class Initialized
INFO - 2018-02-15 10:05:56 --> Language Class Initialized
INFO - 2018-02-15 10:05:56 --> Loader Class Initialized
INFO - 2018-02-15 10:05:56 --> Helper loaded: url_helper
INFO - 2018-02-15 10:05:56 --> Helper loaded: file_helper
INFO - 2018-02-15 10:05:56 --> Helper loaded: email_helper
INFO - 2018-02-15 10:05:56 --> Helper loaded: common_helper
INFO - 2018-02-15 10:05:56 --> Database Driver Class Initialized
DEBUG - 2018-02-15 10:05:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 10:05:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 10:05:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 10:05:56 --> Pagination Class Initialized
INFO - 2018-02-15 10:05:56 --> Helper loaded: form_helper
INFO - 2018-02-15 10:05:56 --> Form Validation Class Initialized
INFO - 2018-02-15 10:05:56 --> Model Class Initialized
INFO - 2018-02-15 10:05:56 --> Controller Class Initialized
INFO - 2018-02-15 10:05:56 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 10:05:56 --> Model Class Initialized
INFO - 2018-02-15 10:05:56 --> Model Class Initialized
INFO - 2018-02-15 10:05:56 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-15 10:05:56 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-15 10:05:56 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-15 10:05:56 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-15 10:05:56 --> File loaded: /var/www/html/project/radio/application/views/subcategory/index.php
INFO - 2018-02-15 10:05:56 --> Final output sent to browser
DEBUG - 2018-02-15 10:05:56 --> Total execution time: 0.0094
INFO - 2018-02-15 10:06:00 --> Config Class Initialized
INFO - 2018-02-15 10:06:00 --> Hooks Class Initialized
DEBUG - 2018-02-15 10:06:00 --> UTF-8 Support Enabled
INFO - 2018-02-15 10:06:00 --> Utf8 Class Initialized
INFO - 2018-02-15 10:06:00 --> URI Class Initialized
INFO - 2018-02-15 10:06:00 --> Router Class Initialized
INFO - 2018-02-15 10:06:00 --> Output Class Initialized
INFO - 2018-02-15 10:06:00 --> Security Class Initialized
DEBUG - 2018-02-15 10:06:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 10:06:00 --> Input Class Initialized
INFO - 2018-02-15 10:06:00 --> Language Class Initialized
INFO - 2018-02-15 10:06:00 --> Loader Class Initialized
INFO - 2018-02-15 10:06:00 --> Helper loaded: url_helper
INFO - 2018-02-15 10:06:00 --> Helper loaded: file_helper
INFO - 2018-02-15 10:06:00 --> Helper loaded: email_helper
INFO - 2018-02-15 10:06:00 --> Helper loaded: common_helper
INFO - 2018-02-15 10:06:00 --> Database Driver Class Initialized
DEBUG - 2018-02-15 10:06:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 10:06:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 10:06:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 10:06:00 --> Pagination Class Initialized
INFO - 2018-02-15 10:06:00 --> Helper loaded: form_helper
INFO - 2018-02-15 10:06:00 --> Form Validation Class Initialized
INFO - 2018-02-15 10:06:00 --> Model Class Initialized
INFO - 2018-02-15 10:06:00 --> Controller Class Initialized
INFO - 2018-02-15 10:06:00 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 10:06:00 --> Model Class Initialized
INFO - 2018-02-15 10:06:00 --> Model Class Initialized
INFO - 2018-02-15 10:06:00 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-15 10:06:00 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-15 10:06:00 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-15 10:06:00 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-15 10:06:00 --> File loaded: /var/www/html/project/radio/application/views/subcategory/add_edit.php
INFO - 2018-02-15 10:06:00 --> Final output sent to browser
DEBUG - 2018-02-15 10:06:00 --> Total execution time: 0.0070
INFO - 2018-02-15 10:06:07 --> Config Class Initialized
INFO - 2018-02-15 10:06:07 --> Hooks Class Initialized
DEBUG - 2018-02-15 10:06:07 --> UTF-8 Support Enabled
INFO - 2018-02-15 10:06:07 --> Utf8 Class Initialized
INFO - 2018-02-15 10:06:07 --> URI Class Initialized
INFO - 2018-02-15 10:06:07 --> Router Class Initialized
INFO - 2018-02-15 10:06:07 --> Output Class Initialized
INFO - 2018-02-15 10:06:07 --> Security Class Initialized
DEBUG - 2018-02-15 10:06:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 10:06:07 --> Input Class Initialized
INFO - 2018-02-15 10:06:07 --> Language Class Initialized
INFO - 2018-02-15 10:06:07 --> Loader Class Initialized
INFO - 2018-02-15 10:06:07 --> Helper loaded: url_helper
INFO - 2018-02-15 10:06:07 --> Helper loaded: file_helper
INFO - 2018-02-15 10:06:07 --> Helper loaded: email_helper
INFO - 2018-02-15 10:06:07 --> Helper loaded: common_helper
INFO - 2018-02-15 10:06:07 --> Database Driver Class Initialized
DEBUG - 2018-02-15 10:06:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 10:06:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 10:06:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 10:06:07 --> Pagination Class Initialized
INFO - 2018-02-15 10:06:07 --> Helper loaded: form_helper
INFO - 2018-02-15 10:06:07 --> Form Validation Class Initialized
INFO - 2018-02-15 10:06:07 --> Model Class Initialized
INFO - 2018-02-15 10:06:07 --> Controller Class Initialized
INFO - 2018-02-15 10:06:07 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 10:06:07 --> Model Class Initialized
INFO - 2018-02-15 10:06:07 --> Model Class Initialized
INFO - 2018-02-15 10:06:07 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-15 10:06:07 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-15 10:06:07 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-15 10:06:07 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-15 10:06:07 --> File loaded: /var/www/html/project/radio/application/views/subcategory/index.php
INFO - 2018-02-15 10:06:07 --> Final output sent to browser
DEBUG - 2018-02-15 10:06:07 --> Total execution time: 0.0100
INFO - 2018-02-15 10:12:39 --> Config Class Initialized
INFO - 2018-02-15 10:12:39 --> Hooks Class Initialized
DEBUG - 2018-02-15 10:12:39 --> UTF-8 Support Enabled
INFO - 2018-02-15 10:12:39 --> Utf8 Class Initialized
INFO - 2018-02-15 10:12:39 --> URI Class Initialized
INFO - 2018-02-15 10:12:39 --> Router Class Initialized
INFO - 2018-02-15 10:12:39 --> Output Class Initialized
INFO - 2018-02-15 10:12:39 --> Security Class Initialized
DEBUG - 2018-02-15 10:12:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 10:12:39 --> Input Class Initialized
INFO - 2018-02-15 10:12:39 --> Language Class Initialized
INFO - 2018-02-15 10:12:39 --> Loader Class Initialized
INFO - 2018-02-15 10:12:39 --> Helper loaded: url_helper
INFO - 2018-02-15 10:12:39 --> Helper loaded: file_helper
INFO - 2018-02-15 10:12:39 --> Helper loaded: email_helper
INFO - 2018-02-15 10:12:39 --> Helper loaded: common_helper
INFO - 2018-02-15 10:12:39 --> Database Driver Class Initialized
DEBUG - 2018-02-15 10:12:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 10:12:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 10:12:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 10:12:39 --> Pagination Class Initialized
INFO - 2018-02-15 10:12:39 --> Helper loaded: form_helper
INFO - 2018-02-15 10:12:39 --> Form Validation Class Initialized
INFO - 2018-02-15 10:12:39 --> Model Class Initialized
INFO - 2018-02-15 10:12:39 --> Controller Class Initialized
INFO - 2018-02-15 10:12:39 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 10:12:39 --> Model Class Initialized
INFO - 2018-02-15 10:12:39 --> Model Class Initialized
INFO - 2018-02-15 10:12:39 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-15 10:12:39 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-15 10:12:39 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-15 10:12:39 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-15 10:12:39 --> File loaded: /var/www/html/project/radio/application/views/subcategory/add_edit.php
INFO - 2018-02-15 10:12:39 --> Final output sent to browser
DEBUG - 2018-02-15 10:12:39 --> Total execution time: 0.0077
INFO - 2018-02-15 10:12:42 --> Config Class Initialized
INFO - 2018-02-15 10:12:42 --> Hooks Class Initialized
DEBUG - 2018-02-15 10:12:42 --> UTF-8 Support Enabled
INFO - 2018-02-15 10:12:42 --> Utf8 Class Initialized
INFO - 2018-02-15 10:12:42 --> URI Class Initialized
INFO - 2018-02-15 10:12:42 --> Router Class Initialized
INFO - 2018-02-15 10:12:42 --> Output Class Initialized
INFO - 2018-02-15 10:12:42 --> Security Class Initialized
DEBUG - 2018-02-15 10:12:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 10:12:42 --> Input Class Initialized
INFO - 2018-02-15 10:12:42 --> Language Class Initialized
INFO - 2018-02-15 10:12:42 --> Loader Class Initialized
INFO - 2018-02-15 10:12:42 --> Helper loaded: url_helper
INFO - 2018-02-15 10:12:42 --> Helper loaded: file_helper
INFO - 2018-02-15 10:12:42 --> Helper loaded: email_helper
INFO - 2018-02-15 10:12:42 --> Helper loaded: common_helper
INFO - 2018-02-15 10:12:42 --> Database Driver Class Initialized
DEBUG - 2018-02-15 10:12:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 10:12:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 10:12:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 10:12:42 --> Pagination Class Initialized
INFO - 2018-02-15 10:12:42 --> Helper loaded: form_helper
INFO - 2018-02-15 10:12:42 --> Form Validation Class Initialized
INFO - 2018-02-15 10:12:42 --> Model Class Initialized
INFO - 2018-02-15 10:12:42 --> Controller Class Initialized
INFO - 2018-02-15 10:12:42 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 10:12:42 --> Model Class Initialized
INFO - 2018-02-15 10:12:42 --> Model Class Initialized
INFO - 2018-02-15 10:12:42 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-15 10:12:42 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-15 10:12:42 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-15 10:12:42 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-15 10:12:42 --> File loaded: /var/www/html/project/radio/application/views/subcategory/index.php
INFO - 2018-02-15 10:12:42 --> Final output sent to browser
DEBUG - 2018-02-15 10:12:42 --> Total execution time: 0.0056
INFO - 2018-02-15 10:12:44 --> Config Class Initialized
INFO - 2018-02-15 10:12:44 --> Hooks Class Initialized
DEBUG - 2018-02-15 10:12:44 --> UTF-8 Support Enabled
INFO - 2018-02-15 10:12:44 --> Utf8 Class Initialized
INFO - 2018-02-15 10:12:44 --> URI Class Initialized
INFO - 2018-02-15 10:12:44 --> Router Class Initialized
INFO - 2018-02-15 10:12:44 --> Output Class Initialized
INFO - 2018-02-15 10:12:44 --> Security Class Initialized
DEBUG - 2018-02-15 10:12:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 10:12:44 --> Input Class Initialized
INFO - 2018-02-15 10:12:44 --> Language Class Initialized
INFO - 2018-02-15 10:12:44 --> Loader Class Initialized
INFO - 2018-02-15 10:12:44 --> Helper loaded: url_helper
INFO - 2018-02-15 10:12:44 --> Helper loaded: file_helper
INFO - 2018-02-15 10:12:44 --> Helper loaded: email_helper
INFO - 2018-02-15 10:12:44 --> Helper loaded: common_helper
INFO - 2018-02-15 10:12:44 --> Database Driver Class Initialized
DEBUG - 2018-02-15 10:12:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 10:12:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 10:12:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 10:12:44 --> Pagination Class Initialized
INFO - 2018-02-15 10:12:44 --> Helper loaded: form_helper
INFO - 2018-02-15 10:12:44 --> Form Validation Class Initialized
INFO - 2018-02-15 10:12:44 --> Model Class Initialized
INFO - 2018-02-15 10:12:44 --> Controller Class Initialized
INFO - 2018-02-15 10:12:44 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 10:12:44 --> Model Class Initialized
INFO - 2018-02-15 10:12:44 --> Model Class Initialized
INFO - 2018-02-15 10:12:44 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-15 10:12:44 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-15 10:12:44 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-15 10:12:44 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-15 10:12:44 --> File loaded: /var/www/html/project/radio/application/views/subcategory/add_edit.php
INFO - 2018-02-15 10:12:44 --> Final output sent to browser
DEBUG - 2018-02-15 10:12:44 --> Total execution time: 0.0046
INFO - 2018-02-15 10:12:54 --> Config Class Initialized
INFO - 2018-02-15 10:12:54 --> Hooks Class Initialized
DEBUG - 2018-02-15 10:12:54 --> UTF-8 Support Enabled
INFO - 2018-02-15 10:12:54 --> Utf8 Class Initialized
INFO - 2018-02-15 10:12:54 --> URI Class Initialized
INFO - 2018-02-15 10:12:54 --> Router Class Initialized
INFO - 2018-02-15 10:12:54 --> Output Class Initialized
INFO - 2018-02-15 10:12:54 --> Security Class Initialized
DEBUG - 2018-02-15 10:12:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 10:12:54 --> Input Class Initialized
INFO - 2018-02-15 10:12:54 --> Language Class Initialized
INFO - 2018-02-15 10:12:54 --> Loader Class Initialized
INFO - 2018-02-15 10:12:54 --> Helper loaded: url_helper
INFO - 2018-02-15 10:12:54 --> Helper loaded: file_helper
INFO - 2018-02-15 10:12:54 --> Helper loaded: email_helper
INFO - 2018-02-15 10:12:54 --> Helper loaded: common_helper
INFO - 2018-02-15 10:12:54 --> Database Driver Class Initialized
DEBUG - 2018-02-15 10:12:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 10:12:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 10:12:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 10:12:54 --> Pagination Class Initialized
INFO - 2018-02-15 10:12:54 --> Helper loaded: form_helper
INFO - 2018-02-15 10:12:54 --> Form Validation Class Initialized
INFO - 2018-02-15 10:12:54 --> Model Class Initialized
INFO - 2018-02-15 10:12:54 --> Controller Class Initialized
INFO - 2018-02-15 10:12:54 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 10:12:54 --> Model Class Initialized
INFO - 2018-02-15 10:12:54 --> Model Class Initialized
INFO - 2018-02-15 10:12:54 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-15 10:12:54 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-15 10:12:54 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-15 10:12:54 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-15 10:12:54 --> File loaded: /var/www/html/project/radio/application/views/subcategory/add_edit.php
INFO - 2018-02-15 10:12:54 --> Final output sent to browser
DEBUG - 2018-02-15 10:12:54 --> Total execution time: 0.0064
INFO - 2018-02-15 10:12:56 --> Config Class Initialized
INFO - 2018-02-15 10:12:56 --> Hooks Class Initialized
DEBUG - 2018-02-15 10:12:56 --> UTF-8 Support Enabled
INFO - 2018-02-15 10:12:56 --> Utf8 Class Initialized
INFO - 2018-02-15 10:12:56 --> URI Class Initialized
INFO - 2018-02-15 10:12:56 --> Router Class Initialized
INFO - 2018-02-15 10:12:56 --> Output Class Initialized
INFO - 2018-02-15 10:12:56 --> Security Class Initialized
DEBUG - 2018-02-15 10:12:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 10:12:56 --> Input Class Initialized
INFO - 2018-02-15 10:12:56 --> Language Class Initialized
INFO - 2018-02-15 10:12:56 --> Loader Class Initialized
INFO - 2018-02-15 10:12:56 --> Helper loaded: url_helper
INFO - 2018-02-15 10:12:56 --> Helper loaded: file_helper
INFO - 2018-02-15 10:12:56 --> Helper loaded: email_helper
INFO - 2018-02-15 10:12:56 --> Helper loaded: common_helper
INFO - 2018-02-15 10:12:56 --> Database Driver Class Initialized
DEBUG - 2018-02-15 10:12:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 10:12:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 10:12:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 10:12:56 --> Pagination Class Initialized
INFO - 2018-02-15 10:12:56 --> Helper loaded: form_helper
INFO - 2018-02-15 10:12:56 --> Form Validation Class Initialized
INFO - 2018-02-15 10:12:56 --> Model Class Initialized
INFO - 2018-02-15 10:12:56 --> Controller Class Initialized
INFO - 2018-02-15 10:12:56 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 10:12:56 --> Model Class Initialized
INFO - 2018-02-15 10:12:56 --> Model Class Initialized
INFO - 2018-02-15 10:12:56 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-15 10:12:56 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-15 10:12:56 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-15 10:12:56 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-15 10:12:56 --> File loaded: /var/www/html/project/radio/application/views/subcategory/index.php
INFO - 2018-02-15 10:12:56 --> Final output sent to browser
DEBUG - 2018-02-15 10:12:56 --> Total execution time: 0.0091
INFO - 2018-02-15 10:12:58 --> Config Class Initialized
INFO - 2018-02-15 10:12:58 --> Hooks Class Initialized
DEBUG - 2018-02-15 10:12:58 --> UTF-8 Support Enabled
INFO - 2018-02-15 10:12:58 --> Utf8 Class Initialized
INFO - 2018-02-15 10:12:58 --> URI Class Initialized
INFO - 2018-02-15 10:12:58 --> Router Class Initialized
INFO - 2018-02-15 10:12:58 --> Output Class Initialized
INFO - 2018-02-15 10:12:58 --> Security Class Initialized
DEBUG - 2018-02-15 10:12:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 10:12:58 --> Input Class Initialized
INFO - 2018-02-15 10:12:58 --> Language Class Initialized
INFO - 2018-02-15 10:12:58 --> Loader Class Initialized
INFO - 2018-02-15 10:12:58 --> Helper loaded: url_helper
INFO - 2018-02-15 10:12:58 --> Helper loaded: file_helper
INFO - 2018-02-15 10:12:58 --> Helper loaded: email_helper
INFO - 2018-02-15 10:12:58 --> Helper loaded: common_helper
INFO - 2018-02-15 10:12:58 --> Database Driver Class Initialized
DEBUG - 2018-02-15 10:12:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 10:12:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 10:12:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 10:12:58 --> Pagination Class Initialized
INFO - 2018-02-15 10:12:58 --> Helper loaded: form_helper
INFO - 2018-02-15 10:12:58 --> Form Validation Class Initialized
INFO - 2018-02-15 10:12:58 --> Model Class Initialized
INFO - 2018-02-15 10:12:58 --> Controller Class Initialized
INFO - 2018-02-15 10:12:58 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 10:12:58 --> Model Class Initialized
INFO - 2018-02-15 10:12:58 --> Model Class Initialized
INFO - 2018-02-15 10:12:58 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-15 10:12:58 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-15 10:12:58 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-15 10:12:58 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-15 10:12:58 --> File loaded: /var/www/html/project/radio/application/views/subcategory/add_edit.php
INFO - 2018-02-15 10:12:58 --> Final output sent to browser
DEBUG - 2018-02-15 10:12:58 --> Total execution time: 0.0051
INFO - 2018-02-15 10:12:59 --> Config Class Initialized
INFO - 2018-02-15 10:12:59 --> Hooks Class Initialized
DEBUG - 2018-02-15 10:12:59 --> UTF-8 Support Enabled
INFO - 2018-02-15 10:12:59 --> Utf8 Class Initialized
INFO - 2018-02-15 10:12:59 --> URI Class Initialized
INFO - 2018-02-15 10:12:59 --> Router Class Initialized
INFO - 2018-02-15 10:12:59 --> Output Class Initialized
INFO - 2018-02-15 10:12:59 --> Security Class Initialized
DEBUG - 2018-02-15 10:12:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 10:12:59 --> Input Class Initialized
INFO - 2018-02-15 10:12:59 --> Language Class Initialized
INFO - 2018-02-15 10:12:59 --> Loader Class Initialized
INFO - 2018-02-15 10:12:59 --> Helper loaded: url_helper
INFO - 2018-02-15 10:12:59 --> Helper loaded: file_helper
INFO - 2018-02-15 10:12:59 --> Helper loaded: email_helper
INFO - 2018-02-15 10:12:59 --> Helper loaded: common_helper
INFO - 2018-02-15 10:12:59 --> Database Driver Class Initialized
DEBUG - 2018-02-15 10:12:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 10:12:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 10:12:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 10:12:59 --> Pagination Class Initialized
INFO - 2018-02-15 10:12:59 --> Helper loaded: form_helper
INFO - 2018-02-15 10:12:59 --> Form Validation Class Initialized
INFO - 2018-02-15 10:12:59 --> Model Class Initialized
INFO - 2018-02-15 10:12:59 --> Controller Class Initialized
INFO - 2018-02-15 10:12:59 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 10:12:59 --> Model Class Initialized
INFO - 2018-02-15 10:12:59 --> Model Class Initialized
INFO - 2018-02-15 10:12:59 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-15 10:12:59 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-15 10:12:59 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-15 10:12:59 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-15 10:12:59 --> File loaded: /var/www/html/project/radio/application/views/subcategory/index.php
INFO - 2018-02-15 10:12:59 --> Final output sent to browser
DEBUG - 2018-02-15 10:12:59 --> Total execution time: 0.0063
INFO - 2018-02-15 10:13:00 --> Config Class Initialized
INFO - 2018-02-15 10:13:00 --> Hooks Class Initialized
DEBUG - 2018-02-15 10:13:00 --> UTF-8 Support Enabled
INFO - 2018-02-15 10:13:00 --> Utf8 Class Initialized
INFO - 2018-02-15 10:13:00 --> URI Class Initialized
INFO - 2018-02-15 10:13:00 --> Router Class Initialized
INFO - 2018-02-15 10:13:00 --> Output Class Initialized
INFO - 2018-02-15 10:13:00 --> Security Class Initialized
DEBUG - 2018-02-15 10:13:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 10:13:00 --> Input Class Initialized
INFO - 2018-02-15 10:13:00 --> Language Class Initialized
INFO - 2018-02-15 10:13:00 --> Loader Class Initialized
INFO - 2018-02-15 10:13:00 --> Helper loaded: url_helper
INFO - 2018-02-15 10:13:00 --> Helper loaded: file_helper
INFO - 2018-02-15 10:13:00 --> Helper loaded: email_helper
INFO - 2018-02-15 10:13:00 --> Helper loaded: common_helper
INFO - 2018-02-15 10:13:00 --> Database Driver Class Initialized
DEBUG - 2018-02-15 10:13:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 10:13:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 10:13:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 10:13:00 --> Pagination Class Initialized
INFO - 2018-02-15 10:13:00 --> Helper loaded: form_helper
INFO - 2018-02-15 10:13:00 --> Form Validation Class Initialized
INFO - 2018-02-15 10:13:00 --> Model Class Initialized
INFO - 2018-02-15 10:13:00 --> Controller Class Initialized
INFO - 2018-02-15 10:13:00 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 10:13:00 --> Model Class Initialized
INFO - 2018-02-15 10:13:00 --> Model Class Initialized
INFO - 2018-02-15 10:13:00 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-15 10:13:00 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-15 10:13:00 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-15 10:13:00 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-15 10:13:00 --> File loaded: /var/www/html/project/radio/application/views/subcategory/add_edit.php
INFO - 2018-02-15 10:13:00 --> Final output sent to browser
DEBUG - 2018-02-15 10:13:00 --> Total execution time: 0.0051
INFO - 2018-02-15 10:13:01 --> Config Class Initialized
INFO - 2018-02-15 10:13:01 --> Hooks Class Initialized
DEBUG - 2018-02-15 10:13:01 --> UTF-8 Support Enabled
INFO - 2018-02-15 10:13:01 --> Utf8 Class Initialized
INFO - 2018-02-15 10:13:01 --> URI Class Initialized
INFO - 2018-02-15 10:13:01 --> Router Class Initialized
INFO - 2018-02-15 10:13:01 --> Output Class Initialized
INFO - 2018-02-15 10:13:01 --> Security Class Initialized
DEBUG - 2018-02-15 10:13:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 10:13:01 --> Input Class Initialized
INFO - 2018-02-15 10:13:01 --> Language Class Initialized
INFO - 2018-02-15 10:13:01 --> Loader Class Initialized
INFO - 2018-02-15 10:13:01 --> Helper loaded: url_helper
INFO - 2018-02-15 10:13:01 --> Helper loaded: file_helper
INFO - 2018-02-15 10:13:01 --> Helper loaded: email_helper
INFO - 2018-02-15 10:13:01 --> Helper loaded: common_helper
INFO - 2018-02-15 10:13:01 --> Database Driver Class Initialized
DEBUG - 2018-02-15 10:13:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 10:13:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 10:13:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 10:13:01 --> Pagination Class Initialized
INFO - 2018-02-15 10:13:01 --> Helper loaded: form_helper
INFO - 2018-02-15 10:13:01 --> Form Validation Class Initialized
INFO - 2018-02-15 10:13:01 --> Model Class Initialized
INFO - 2018-02-15 10:13:01 --> Controller Class Initialized
INFO - 2018-02-15 10:13:01 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 10:13:01 --> Model Class Initialized
INFO - 2018-02-15 10:13:01 --> Model Class Initialized
INFO - 2018-02-15 10:13:01 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-15 10:13:01 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-15 10:13:01 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-15 10:13:01 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-15 10:13:01 --> File loaded: /var/www/html/project/radio/application/views/subcategory/index.php
INFO - 2018-02-15 10:13:01 --> Final output sent to browser
DEBUG - 2018-02-15 10:13:01 --> Total execution time: 0.0053
INFO - 2018-02-15 10:13:02 --> Config Class Initialized
INFO - 2018-02-15 10:13:02 --> Hooks Class Initialized
DEBUG - 2018-02-15 10:13:02 --> UTF-8 Support Enabled
INFO - 2018-02-15 10:13:02 --> Utf8 Class Initialized
INFO - 2018-02-15 10:13:02 --> URI Class Initialized
INFO - 2018-02-15 10:13:02 --> Router Class Initialized
INFO - 2018-02-15 10:13:02 --> Output Class Initialized
INFO - 2018-02-15 10:13:02 --> Security Class Initialized
DEBUG - 2018-02-15 10:13:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 10:13:02 --> Input Class Initialized
INFO - 2018-02-15 10:13:02 --> Language Class Initialized
INFO - 2018-02-15 10:13:02 --> Loader Class Initialized
INFO - 2018-02-15 10:13:02 --> Helper loaded: url_helper
INFO - 2018-02-15 10:13:02 --> Helper loaded: file_helper
INFO - 2018-02-15 10:13:02 --> Helper loaded: email_helper
INFO - 2018-02-15 10:13:02 --> Helper loaded: common_helper
INFO - 2018-02-15 10:13:02 --> Database Driver Class Initialized
DEBUG - 2018-02-15 10:13:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 10:13:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 10:13:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 10:13:02 --> Pagination Class Initialized
INFO - 2018-02-15 10:13:02 --> Helper loaded: form_helper
INFO - 2018-02-15 10:13:02 --> Form Validation Class Initialized
INFO - 2018-02-15 10:13:02 --> Model Class Initialized
INFO - 2018-02-15 10:13:02 --> Controller Class Initialized
INFO - 2018-02-15 10:13:02 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 10:13:02 --> Model Class Initialized
INFO - 2018-02-15 10:13:02 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-15 10:13:02 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-15 10:13:02 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-15 10:13:02 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-15 10:13:02 --> File loaded: /var/www/html/project/radio/application/views/category/index.php
INFO - 2018-02-15 10:13:02 --> Final output sent to browser
DEBUG - 2018-02-15 10:13:02 --> Total execution time: 0.0063
INFO - 2018-02-15 10:13:04 --> Config Class Initialized
INFO - 2018-02-15 10:13:04 --> Hooks Class Initialized
DEBUG - 2018-02-15 10:13:04 --> UTF-8 Support Enabled
INFO - 2018-02-15 10:13:04 --> Utf8 Class Initialized
INFO - 2018-02-15 10:13:04 --> URI Class Initialized
INFO - 2018-02-15 10:13:04 --> Router Class Initialized
INFO - 2018-02-15 10:13:04 --> Output Class Initialized
INFO - 2018-02-15 10:13:04 --> Security Class Initialized
DEBUG - 2018-02-15 10:13:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 10:13:04 --> Input Class Initialized
INFO - 2018-02-15 10:13:04 --> Language Class Initialized
INFO - 2018-02-15 10:13:04 --> Loader Class Initialized
INFO - 2018-02-15 10:13:04 --> Helper loaded: url_helper
INFO - 2018-02-15 10:13:04 --> Helper loaded: file_helper
INFO - 2018-02-15 10:13:04 --> Helper loaded: email_helper
INFO - 2018-02-15 10:13:04 --> Helper loaded: common_helper
INFO - 2018-02-15 10:13:04 --> Database Driver Class Initialized
DEBUG - 2018-02-15 10:13:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 10:13:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 10:13:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 10:13:04 --> Pagination Class Initialized
INFO - 2018-02-15 10:13:04 --> Helper loaded: form_helper
INFO - 2018-02-15 10:13:04 --> Form Validation Class Initialized
INFO - 2018-02-15 10:13:04 --> Model Class Initialized
INFO - 2018-02-15 10:13:04 --> Controller Class Initialized
INFO - 2018-02-15 10:13:04 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 10:13:04 --> Model Class Initialized
INFO - 2018-02-15 10:13:04 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-15 10:13:04 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-15 10:13:04 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-15 10:13:04 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-15 10:13:04 --> File loaded: /var/www/html/project/radio/application/views/category/index.php
INFO - 2018-02-15 10:13:04 --> Final output sent to browser
DEBUG - 2018-02-15 10:13:04 --> Total execution time: 0.0071
INFO - 2018-02-15 10:13:06 --> Config Class Initialized
INFO - 2018-02-15 10:13:06 --> Hooks Class Initialized
DEBUG - 2018-02-15 10:13:06 --> UTF-8 Support Enabled
INFO - 2018-02-15 10:13:06 --> Utf8 Class Initialized
INFO - 2018-02-15 10:13:06 --> URI Class Initialized
INFO - 2018-02-15 10:13:06 --> Router Class Initialized
INFO - 2018-02-15 10:13:06 --> Output Class Initialized
INFO - 2018-02-15 10:13:06 --> Security Class Initialized
DEBUG - 2018-02-15 10:13:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 10:13:06 --> Input Class Initialized
INFO - 2018-02-15 10:13:06 --> Language Class Initialized
INFO - 2018-02-15 10:13:06 --> Loader Class Initialized
INFO - 2018-02-15 10:13:06 --> Helper loaded: url_helper
INFO - 2018-02-15 10:13:06 --> Helper loaded: file_helper
INFO - 2018-02-15 10:13:06 --> Helper loaded: email_helper
INFO - 2018-02-15 10:13:06 --> Helper loaded: common_helper
INFO - 2018-02-15 10:13:06 --> Database Driver Class Initialized
DEBUG - 2018-02-15 10:13:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 10:13:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 10:13:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 10:13:06 --> Pagination Class Initialized
INFO - 2018-02-15 10:13:06 --> Helper loaded: form_helper
INFO - 2018-02-15 10:13:06 --> Form Validation Class Initialized
INFO - 2018-02-15 10:13:06 --> Model Class Initialized
INFO - 2018-02-15 10:13:06 --> Controller Class Initialized
INFO - 2018-02-15 10:13:06 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 10:13:06 --> Model Class Initialized
INFO - 2018-02-15 10:13:06 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-15 10:13:06 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-15 10:13:06 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-15 10:13:06 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-15 10:13:06 --> File loaded: /var/www/html/project/radio/application/views/category/add_edit.php
INFO - 2018-02-15 10:13:06 --> Final output sent to browser
DEBUG - 2018-02-15 10:13:06 --> Total execution time: 0.0037
INFO - 2018-02-15 10:13:07 --> Config Class Initialized
INFO - 2018-02-15 10:13:07 --> Hooks Class Initialized
DEBUG - 2018-02-15 10:13:07 --> UTF-8 Support Enabled
INFO - 2018-02-15 10:13:07 --> Utf8 Class Initialized
INFO - 2018-02-15 10:13:07 --> URI Class Initialized
INFO - 2018-02-15 10:13:07 --> Router Class Initialized
INFO - 2018-02-15 10:13:07 --> Output Class Initialized
INFO - 2018-02-15 10:13:07 --> Security Class Initialized
DEBUG - 2018-02-15 10:13:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 10:13:07 --> Input Class Initialized
INFO - 2018-02-15 10:13:07 --> Language Class Initialized
INFO - 2018-02-15 10:13:07 --> Loader Class Initialized
INFO - 2018-02-15 10:13:07 --> Helper loaded: url_helper
INFO - 2018-02-15 10:13:07 --> Helper loaded: file_helper
INFO - 2018-02-15 10:13:07 --> Helper loaded: email_helper
INFO - 2018-02-15 10:13:07 --> Helper loaded: common_helper
INFO - 2018-02-15 10:13:07 --> Database Driver Class Initialized
DEBUG - 2018-02-15 10:13:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 10:13:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 10:13:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 10:13:07 --> Pagination Class Initialized
INFO - 2018-02-15 10:13:07 --> Helper loaded: form_helper
INFO - 2018-02-15 10:13:07 --> Form Validation Class Initialized
INFO - 2018-02-15 10:13:07 --> Model Class Initialized
INFO - 2018-02-15 10:13:07 --> Controller Class Initialized
INFO - 2018-02-15 10:13:07 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 10:13:07 --> Model Class Initialized
INFO - 2018-02-15 10:13:07 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-15 10:13:07 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-15 10:13:07 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-15 10:13:07 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-15 10:13:07 --> File loaded: /var/www/html/project/radio/application/views/category/index.php
INFO - 2018-02-15 10:13:07 --> Final output sent to browser
DEBUG - 2018-02-15 10:13:07 --> Total execution time: 0.0059
INFO - 2018-02-15 10:13:08 --> Config Class Initialized
INFO - 2018-02-15 10:13:08 --> Hooks Class Initialized
DEBUG - 2018-02-15 10:13:08 --> UTF-8 Support Enabled
INFO - 2018-02-15 10:13:08 --> Utf8 Class Initialized
INFO - 2018-02-15 10:13:08 --> URI Class Initialized
INFO - 2018-02-15 10:13:08 --> Router Class Initialized
INFO - 2018-02-15 10:13:08 --> Output Class Initialized
INFO - 2018-02-15 10:13:08 --> Security Class Initialized
DEBUG - 2018-02-15 10:13:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 10:13:08 --> Input Class Initialized
INFO - 2018-02-15 10:13:08 --> Language Class Initialized
INFO - 2018-02-15 10:13:08 --> Loader Class Initialized
INFO - 2018-02-15 10:13:08 --> Helper loaded: url_helper
INFO - 2018-02-15 10:13:08 --> Helper loaded: file_helper
INFO - 2018-02-15 10:13:08 --> Helper loaded: email_helper
INFO - 2018-02-15 10:13:08 --> Helper loaded: common_helper
INFO - 2018-02-15 10:13:08 --> Database Driver Class Initialized
DEBUG - 2018-02-15 10:13:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 10:13:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 10:13:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 10:13:08 --> Pagination Class Initialized
INFO - 2018-02-15 10:13:08 --> Helper loaded: form_helper
INFO - 2018-02-15 10:13:08 --> Form Validation Class Initialized
INFO - 2018-02-15 10:13:08 --> Model Class Initialized
INFO - 2018-02-15 10:13:08 --> Controller Class Initialized
INFO - 2018-02-15 10:13:08 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 10:13:08 --> Model Class Initialized
INFO - 2018-02-15 10:13:08 --> Model Class Initialized
INFO - 2018-02-15 10:13:08 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-15 10:13:08 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-15 10:13:08 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-15 10:13:08 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-15 10:13:08 --> File loaded: /var/www/html/project/radio/application/views/subcategory/index.php
INFO - 2018-02-15 10:13:08 --> Final output sent to browser
DEBUG - 2018-02-15 10:13:08 --> Total execution time: 0.0051
INFO - 2018-02-15 11:37:06 --> Config Class Initialized
INFO - 2018-02-15 11:37:06 --> Hooks Class Initialized
DEBUG - 2018-02-15 11:37:06 --> UTF-8 Support Enabled
INFO - 2018-02-15 11:37:06 --> Utf8 Class Initialized
INFO - 2018-02-15 11:37:06 --> URI Class Initialized
INFO - 2018-02-15 11:37:06 --> Router Class Initialized
INFO - 2018-02-15 11:37:06 --> Output Class Initialized
INFO - 2018-02-15 11:37:06 --> Security Class Initialized
DEBUG - 2018-02-15 11:37:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 11:37:06 --> Input Class Initialized
INFO - 2018-02-15 11:37:06 --> Language Class Initialized
INFO - 2018-02-15 11:37:06 --> Loader Class Initialized
INFO - 2018-02-15 11:37:06 --> Helper loaded: url_helper
INFO - 2018-02-15 11:37:06 --> Helper loaded: file_helper
INFO - 2018-02-15 11:37:06 --> Helper loaded: email_helper
INFO - 2018-02-15 11:37:06 --> Helper loaded: common_helper
INFO - 2018-02-15 11:37:06 --> Database Driver Class Initialized
DEBUG - 2018-02-15 11:37:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 11:37:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 11:37:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 11:37:06 --> Pagination Class Initialized
INFO - 2018-02-15 11:37:06 --> Helper loaded: form_helper
INFO - 2018-02-15 11:37:06 --> Form Validation Class Initialized
INFO - 2018-02-15 11:37:06 --> Model Class Initialized
INFO - 2018-02-15 11:37:06 --> Controller Class Initialized
INFO - 2018-02-15 11:37:06 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 11:37:06 --> Model Class Initialized
INFO - 2018-02-15 11:37:06 --> Model Class Initialized
INFO - 2018-02-15 11:37:06 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-15 11:37:06 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-15 11:37:06 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-15 11:37:06 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-15 11:37:06 --> File loaded: /var/www/html/project/radio/application/views/subcategory/index.php
INFO - 2018-02-15 11:37:06 --> Final output sent to browser
DEBUG - 2018-02-15 11:37:06 --> Total execution time: 0.0076
INFO - 2018-02-15 11:37:07 --> Config Class Initialized
INFO - 2018-02-15 11:37:07 --> Hooks Class Initialized
DEBUG - 2018-02-15 11:37:07 --> UTF-8 Support Enabled
INFO - 2018-02-15 11:37:07 --> Utf8 Class Initialized
INFO - 2018-02-15 11:37:07 --> URI Class Initialized
INFO - 2018-02-15 11:37:07 --> Router Class Initialized
INFO - 2018-02-15 11:37:07 --> Output Class Initialized
INFO - 2018-02-15 11:37:07 --> Security Class Initialized
DEBUG - 2018-02-15 11:37:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 11:37:07 --> Input Class Initialized
INFO - 2018-02-15 11:37:07 --> Language Class Initialized
INFO - 2018-02-15 11:37:07 --> Loader Class Initialized
INFO - 2018-02-15 11:37:07 --> Helper loaded: url_helper
INFO - 2018-02-15 11:37:07 --> Helper loaded: file_helper
INFO - 2018-02-15 11:37:07 --> Helper loaded: email_helper
INFO - 2018-02-15 11:37:07 --> Helper loaded: common_helper
INFO - 2018-02-15 11:37:07 --> Database Driver Class Initialized
DEBUG - 2018-02-15 11:37:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 11:37:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 11:37:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 11:37:07 --> Pagination Class Initialized
INFO - 2018-02-15 11:37:07 --> Helper loaded: form_helper
INFO - 2018-02-15 11:37:07 --> Form Validation Class Initialized
INFO - 2018-02-15 11:37:07 --> Model Class Initialized
INFO - 2018-02-15 11:37:07 --> Controller Class Initialized
INFO - 2018-02-15 11:37:07 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 11:37:07 --> Model Class Initialized
INFO - 2018-02-15 11:37:07 --> Model Class Initialized
INFO - 2018-02-15 11:37:07 --> Model Class Initialized
INFO - 2018-02-15 11:37:07 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-15 11:37:07 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-15 11:37:07 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-15 11:37:07 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-15 11:37:07 --> File loaded: /var/www/html/project/radio/application/views/tracks/index.php
INFO - 2018-02-15 11:37:07 --> Final output sent to browser
DEBUG - 2018-02-15 11:37:07 --> Total execution time: 0.0054
INFO - 2018-02-15 11:37:07 --> Config Class Initialized
INFO - 2018-02-15 11:37:07 --> Hooks Class Initialized
DEBUG - 2018-02-15 11:37:07 --> UTF-8 Support Enabled
INFO - 2018-02-15 11:37:07 --> Utf8 Class Initialized
INFO - 2018-02-15 11:37:07 --> URI Class Initialized
INFO - 2018-02-15 11:37:07 --> Router Class Initialized
INFO - 2018-02-15 11:37:07 --> Output Class Initialized
INFO - 2018-02-15 11:37:07 --> Security Class Initialized
DEBUG - 2018-02-15 11:37:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 11:37:07 --> Input Class Initialized
INFO - 2018-02-15 11:37:07 --> Language Class Initialized
INFO - 2018-02-15 11:37:07 --> Loader Class Initialized
INFO - 2018-02-15 11:37:07 --> Helper loaded: url_helper
INFO - 2018-02-15 11:37:07 --> Helper loaded: file_helper
INFO - 2018-02-15 11:37:07 --> Helper loaded: email_helper
INFO - 2018-02-15 11:37:07 --> Helper loaded: common_helper
INFO - 2018-02-15 11:37:07 --> Database Driver Class Initialized
DEBUG - 2018-02-15 11:37:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 11:37:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 11:37:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 11:37:07 --> Pagination Class Initialized
INFO - 2018-02-15 11:37:07 --> Helper loaded: form_helper
INFO - 2018-02-15 11:37:07 --> Form Validation Class Initialized
INFO - 2018-02-15 11:37:07 --> Model Class Initialized
INFO - 2018-02-15 11:37:07 --> Controller Class Initialized
INFO - 2018-02-15 11:37:07 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 11:37:07 --> Model Class Initialized
INFO - 2018-02-15 11:37:07 --> Model Class Initialized
INFO - 2018-02-15 11:37:07 --> Model Class Initialized
INFO - 2018-02-15 12:04:42 --> Config Class Initialized
INFO - 2018-02-15 12:04:42 --> Hooks Class Initialized
DEBUG - 2018-02-15 12:04:42 --> UTF-8 Support Enabled
INFO - 2018-02-15 12:04:42 --> Utf8 Class Initialized
INFO - 2018-02-15 12:04:42 --> URI Class Initialized
INFO - 2018-02-15 12:04:42 --> Router Class Initialized
INFO - 2018-02-15 12:04:42 --> Output Class Initialized
INFO - 2018-02-15 12:04:42 --> Security Class Initialized
DEBUG - 2018-02-15 12:04:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 12:04:42 --> Input Class Initialized
INFO - 2018-02-15 12:04:42 --> Language Class Initialized
INFO - 2018-02-15 12:04:42 --> Loader Class Initialized
INFO - 2018-02-15 12:04:42 --> Helper loaded: url_helper
INFO - 2018-02-15 12:04:42 --> Helper loaded: file_helper
INFO - 2018-02-15 12:04:42 --> Helper loaded: email_helper
INFO - 2018-02-15 12:04:42 --> Helper loaded: common_helper
INFO - 2018-02-15 12:04:42 --> Database Driver Class Initialized
DEBUG - 2018-02-15 12:04:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 12:04:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 12:04:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 12:04:42 --> Pagination Class Initialized
INFO - 2018-02-15 12:04:42 --> Helper loaded: form_helper
INFO - 2018-02-15 12:04:42 --> Form Validation Class Initialized
INFO - 2018-02-15 12:04:42 --> Model Class Initialized
INFO - 2018-02-15 12:04:42 --> Controller Class Initialized
INFO - 2018-02-15 12:04:42 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 12:04:42 --> Model Class Initialized
INFO - 2018-02-15 12:04:42 --> Model Class Initialized
INFO - 2018-02-15 12:04:42 --> Model Class Initialized
INFO - 2018-02-15 12:04:42 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-15 12:04:42 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-15 12:04:42 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-15 12:04:42 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-15 12:04:42 --> File loaded: /var/www/html/project/radio/application/views/tracks/add_edit.php
INFO - 2018-02-15 12:04:42 --> Final output sent to browser
DEBUG - 2018-02-15 12:04:42 --> Total execution time: 0.0108
INFO - 2018-02-15 12:05:20 --> Config Class Initialized
INFO - 2018-02-15 12:05:20 --> Hooks Class Initialized
DEBUG - 2018-02-15 12:05:20 --> UTF-8 Support Enabled
INFO - 2018-02-15 12:05:20 --> Utf8 Class Initialized
INFO - 2018-02-15 12:05:20 --> URI Class Initialized
INFO - 2018-02-15 12:05:20 --> Router Class Initialized
INFO - 2018-02-15 12:05:20 --> Output Class Initialized
INFO - 2018-02-15 12:05:20 --> Security Class Initialized
DEBUG - 2018-02-15 12:05:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 12:05:20 --> Input Class Initialized
INFO - 2018-02-15 12:05:20 --> Language Class Initialized
INFO - 2018-02-15 12:05:20 --> Loader Class Initialized
INFO - 2018-02-15 12:05:20 --> Helper loaded: url_helper
INFO - 2018-02-15 12:05:20 --> Helper loaded: file_helper
INFO - 2018-02-15 12:05:20 --> Helper loaded: email_helper
INFO - 2018-02-15 12:05:20 --> Helper loaded: common_helper
INFO - 2018-02-15 12:05:20 --> Database Driver Class Initialized
DEBUG - 2018-02-15 12:05:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 12:05:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 12:05:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 12:05:20 --> Pagination Class Initialized
INFO - 2018-02-15 12:05:20 --> Helper loaded: form_helper
INFO - 2018-02-15 12:05:20 --> Form Validation Class Initialized
INFO - 2018-02-15 12:05:20 --> Model Class Initialized
INFO - 2018-02-15 12:05:20 --> Controller Class Initialized
INFO - 2018-02-15 12:05:20 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 12:05:20 --> Model Class Initialized
INFO - 2018-02-15 12:05:20 --> Model Class Initialized
INFO - 2018-02-15 12:05:20 --> Model Class Initialized
INFO - 2018-02-15 12:05:20 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-15 12:05:20 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-15 12:05:20 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-15 12:05:20 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-15 12:05:20 --> File loaded: /var/www/html/project/radio/application/views/tracks/add_edit.php
INFO - 2018-02-15 12:05:20 --> Final output sent to browser
DEBUG - 2018-02-15 12:05:20 --> Total execution time: 0.0095
INFO - 2018-02-15 12:05:38 --> Config Class Initialized
INFO - 2018-02-15 12:05:38 --> Hooks Class Initialized
DEBUG - 2018-02-15 12:05:38 --> UTF-8 Support Enabled
INFO - 2018-02-15 12:05:38 --> Utf8 Class Initialized
INFO - 2018-02-15 12:05:38 --> URI Class Initialized
INFO - 2018-02-15 12:05:38 --> Router Class Initialized
INFO - 2018-02-15 12:05:38 --> Output Class Initialized
INFO - 2018-02-15 12:05:38 --> Security Class Initialized
DEBUG - 2018-02-15 12:05:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 12:05:38 --> Input Class Initialized
INFO - 2018-02-15 12:05:38 --> Language Class Initialized
INFO - 2018-02-15 12:05:38 --> Loader Class Initialized
INFO - 2018-02-15 12:05:38 --> Helper loaded: url_helper
INFO - 2018-02-15 12:05:38 --> Helper loaded: file_helper
INFO - 2018-02-15 12:05:38 --> Helper loaded: email_helper
INFO - 2018-02-15 12:05:38 --> Helper loaded: common_helper
INFO - 2018-02-15 12:05:38 --> Database Driver Class Initialized
DEBUG - 2018-02-15 12:05:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 12:05:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 12:05:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 12:05:38 --> Pagination Class Initialized
INFO - 2018-02-15 12:05:38 --> Helper loaded: form_helper
INFO - 2018-02-15 12:05:38 --> Form Validation Class Initialized
INFO - 2018-02-15 12:05:38 --> Model Class Initialized
INFO - 2018-02-15 12:05:38 --> Controller Class Initialized
INFO - 2018-02-15 12:05:38 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 12:05:38 --> Model Class Initialized
INFO - 2018-02-15 12:05:38 --> Model Class Initialized
INFO - 2018-02-15 12:05:38 --> Model Class Initialized
INFO - 2018-02-15 12:05:38 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-15 12:05:38 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-15 12:05:38 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-15 12:05:38 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-15 12:05:38 --> File loaded: /var/www/html/project/radio/application/views/tracks/add_edit.php
INFO - 2018-02-15 12:05:38 --> Final output sent to browser
DEBUG - 2018-02-15 12:05:38 --> Total execution time: 0.0056
INFO - 2018-02-15 12:05:51 --> Config Class Initialized
INFO - 2018-02-15 12:05:51 --> Hooks Class Initialized
DEBUG - 2018-02-15 12:05:51 --> UTF-8 Support Enabled
INFO - 2018-02-15 12:05:51 --> Utf8 Class Initialized
INFO - 2018-02-15 12:05:51 --> URI Class Initialized
INFO - 2018-02-15 12:05:51 --> Router Class Initialized
INFO - 2018-02-15 12:05:51 --> Output Class Initialized
INFO - 2018-02-15 12:05:51 --> Security Class Initialized
DEBUG - 2018-02-15 12:05:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 12:05:51 --> Input Class Initialized
INFO - 2018-02-15 12:05:51 --> Language Class Initialized
INFO - 2018-02-15 12:05:51 --> Loader Class Initialized
INFO - 2018-02-15 12:05:51 --> Helper loaded: url_helper
INFO - 2018-02-15 12:05:51 --> Helper loaded: file_helper
INFO - 2018-02-15 12:05:51 --> Helper loaded: email_helper
INFO - 2018-02-15 12:05:51 --> Helper loaded: common_helper
INFO - 2018-02-15 12:05:51 --> Database Driver Class Initialized
DEBUG - 2018-02-15 12:05:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 12:05:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 12:05:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 12:05:51 --> Pagination Class Initialized
INFO - 2018-02-15 12:05:51 --> Helper loaded: form_helper
INFO - 2018-02-15 12:05:51 --> Form Validation Class Initialized
INFO - 2018-02-15 12:05:51 --> Model Class Initialized
INFO - 2018-02-15 12:05:51 --> Controller Class Initialized
INFO - 2018-02-15 12:05:51 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 12:05:51 --> Model Class Initialized
INFO - 2018-02-15 12:05:51 --> Model Class Initialized
INFO - 2018-02-15 12:05:51 --> Model Class Initialized
INFO - 2018-02-15 12:05:51 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-15 12:05:51 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-15 12:05:51 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-15 12:05:51 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-15 12:05:51 --> File loaded: /var/www/html/project/radio/application/views/tracks/add_edit.php
INFO - 2018-02-15 12:05:51 --> Final output sent to browser
DEBUG - 2018-02-15 12:05:51 --> Total execution time: 0.0077
INFO - 2018-02-15 12:05:58 --> Config Class Initialized
INFO - 2018-02-15 12:05:58 --> Hooks Class Initialized
DEBUG - 2018-02-15 12:05:58 --> UTF-8 Support Enabled
INFO - 2018-02-15 12:05:58 --> Utf8 Class Initialized
INFO - 2018-02-15 12:05:58 --> URI Class Initialized
INFO - 2018-02-15 12:05:58 --> Router Class Initialized
INFO - 2018-02-15 12:05:58 --> Output Class Initialized
INFO - 2018-02-15 12:05:58 --> Security Class Initialized
DEBUG - 2018-02-15 12:05:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 12:05:58 --> Input Class Initialized
INFO - 2018-02-15 12:05:58 --> Language Class Initialized
INFO - 2018-02-15 12:05:58 --> Loader Class Initialized
INFO - 2018-02-15 12:05:58 --> Helper loaded: url_helper
INFO - 2018-02-15 12:05:58 --> Helper loaded: file_helper
INFO - 2018-02-15 12:05:58 --> Helper loaded: email_helper
INFO - 2018-02-15 12:05:58 --> Helper loaded: common_helper
INFO - 2018-02-15 12:05:58 --> Database Driver Class Initialized
DEBUG - 2018-02-15 12:05:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 12:05:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 12:05:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 12:05:58 --> Pagination Class Initialized
INFO - 2018-02-15 12:05:58 --> Helper loaded: form_helper
INFO - 2018-02-15 12:05:58 --> Form Validation Class Initialized
INFO - 2018-02-15 12:05:58 --> Model Class Initialized
INFO - 2018-02-15 12:05:58 --> Controller Class Initialized
INFO - 2018-02-15 12:05:58 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 12:05:58 --> Model Class Initialized
INFO - 2018-02-15 12:05:58 --> Model Class Initialized
INFO - 2018-02-15 12:05:58 --> Model Class Initialized
INFO - 2018-02-15 12:05:58 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-15 12:05:58 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-15 12:05:58 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-15 12:05:58 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-15 12:05:58 --> File loaded: /var/www/html/project/radio/application/views/tracks/add_edit.php
INFO - 2018-02-15 12:05:58 --> Final output sent to browser
DEBUG - 2018-02-15 12:05:58 --> Total execution time: 0.0061
INFO - 2018-02-15 12:06:02 --> Config Class Initialized
INFO - 2018-02-15 12:06:02 --> Hooks Class Initialized
DEBUG - 2018-02-15 12:06:02 --> UTF-8 Support Enabled
INFO - 2018-02-15 12:06:02 --> Utf8 Class Initialized
INFO - 2018-02-15 12:06:02 --> URI Class Initialized
INFO - 2018-02-15 12:06:02 --> Router Class Initialized
INFO - 2018-02-15 12:06:02 --> Output Class Initialized
INFO - 2018-02-15 12:06:02 --> Security Class Initialized
DEBUG - 2018-02-15 12:06:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 12:06:02 --> Input Class Initialized
INFO - 2018-02-15 12:06:02 --> Language Class Initialized
INFO - 2018-02-15 12:06:02 --> Loader Class Initialized
INFO - 2018-02-15 12:06:02 --> Helper loaded: url_helper
INFO - 2018-02-15 12:06:02 --> Helper loaded: file_helper
INFO - 2018-02-15 12:06:02 --> Helper loaded: email_helper
INFO - 2018-02-15 12:06:02 --> Helper loaded: common_helper
INFO - 2018-02-15 12:06:02 --> Database Driver Class Initialized
DEBUG - 2018-02-15 12:06:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 12:06:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 12:06:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 12:06:02 --> Pagination Class Initialized
INFO - 2018-02-15 12:06:02 --> Helper loaded: form_helper
INFO - 2018-02-15 12:06:02 --> Form Validation Class Initialized
INFO - 2018-02-15 12:06:02 --> Model Class Initialized
INFO - 2018-02-15 12:06:02 --> Controller Class Initialized
INFO - 2018-02-15 12:06:02 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 12:06:02 --> Model Class Initialized
INFO - 2018-02-15 12:06:02 --> Model Class Initialized
INFO - 2018-02-15 12:06:02 --> Model Class Initialized
INFO - 2018-02-15 12:06:02 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-15 12:06:02 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-15 12:06:02 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-15 12:06:02 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-15 12:06:02 --> File loaded: /var/www/html/project/radio/application/views/tracks/add_edit.php
INFO - 2018-02-15 12:06:02 --> Final output sent to browser
DEBUG - 2018-02-15 12:06:02 --> Total execution time: 0.0076
INFO - 2018-02-15 12:26:51 --> Config Class Initialized
INFO - 2018-02-15 12:26:51 --> Hooks Class Initialized
DEBUG - 2018-02-15 12:26:51 --> UTF-8 Support Enabled
INFO - 2018-02-15 12:26:51 --> Utf8 Class Initialized
INFO - 2018-02-15 12:26:51 --> URI Class Initialized
INFO - 2018-02-15 12:26:51 --> Router Class Initialized
INFO - 2018-02-15 12:26:51 --> Output Class Initialized
INFO - 2018-02-15 12:26:51 --> Security Class Initialized
DEBUG - 2018-02-15 12:26:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 12:26:51 --> Input Class Initialized
INFO - 2018-02-15 12:26:51 --> Language Class Initialized
INFO - 2018-02-15 12:26:51 --> Loader Class Initialized
INFO - 2018-02-15 12:26:51 --> Helper loaded: url_helper
INFO - 2018-02-15 12:26:51 --> Helper loaded: file_helper
INFO - 2018-02-15 12:26:51 --> Helper loaded: email_helper
INFO - 2018-02-15 12:26:51 --> Helper loaded: common_helper
INFO - 2018-02-15 12:26:51 --> Database Driver Class Initialized
DEBUG - 2018-02-15 12:26:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 12:26:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 12:26:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 12:26:51 --> Pagination Class Initialized
INFO - 2018-02-15 12:26:51 --> Helper loaded: form_helper
INFO - 2018-02-15 12:26:51 --> Form Validation Class Initialized
INFO - 2018-02-15 12:26:51 --> Model Class Initialized
INFO - 2018-02-15 12:26:51 --> Controller Class Initialized
INFO - 2018-02-15 12:26:51 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 12:26:51 --> Model Class Initialized
INFO - 2018-02-15 12:26:51 --> Model Class Initialized
INFO - 2018-02-15 12:26:51 --> Model Class Initialized
INFO - 2018-02-15 12:26:51 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-15 12:26:51 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-15 12:26:51 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-15 12:26:51 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-15 12:26:51 --> File loaded: /var/www/html/project/radio/application/views/tracks/add_edit.php
INFO - 2018-02-15 12:26:51 --> Final output sent to browser
DEBUG - 2018-02-15 12:26:51 --> Total execution time: 0.0117
INFO - 2018-02-15 12:26:55 --> Config Class Initialized
INFO - 2018-02-15 12:26:55 --> Hooks Class Initialized
DEBUG - 2018-02-15 12:26:55 --> UTF-8 Support Enabled
INFO - 2018-02-15 12:26:55 --> Utf8 Class Initialized
INFO - 2018-02-15 12:26:55 --> URI Class Initialized
INFO - 2018-02-15 12:26:55 --> Router Class Initialized
INFO - 2018-02-15 12:26:55 --> Output Class Initialized
INFO - 2018-02-15 12:26:55 --> Security Class Initialized
DEBUG - 2018-02-15 12:26:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 12:26:55 --> Input Class Initialized
INFO - 2018-02-15 12:26:55 --> Language Class Initialized
INFO - 2018-02-15 12:26:55 --> Loader Class Initialized
INFO - 2018-02-15 12:26:55 --> Helper loaded: url_helper
INFO - 2018-02-15 12:26:55 --> Helper loaded: file_helper
INFO - 2018-02-15 12:26:55 --> Helper loaded: email_helper
INFO - 2018-02-15 12:26:55 --> Helper loaded: common_helper
INFO - 2018-02-15 12:26:55 --> Database Driver Class Initialized
DEBUG - 2018-02-15 12:26:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 12:26:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 12:26:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 12:26:55 --> Pagination Class Initialized
INFO - 2018-02-15 12:26:55 --> Helper loaded: form_helper
INFO - 2018-02-15 12:26:55 --> Form Validation Class Initialized
INFO - 2018-02-15 12:26:55 --> Model Class Initialized
INFO - 2018-02-15 12:26:55 --> Controller Class Initialized
INFO - 2018-02-15 12:26:55 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 12:26:55 --> Model Class Initialized
INFO - 2018-02-15 12:26:55 --> Model Class Initialized
INFO - 2018-02-15 12:26:55 --> Model Class Initialized
INFO - 2018-02-15 12:26:58 --> Config Class Initialized
INFO - 2018-02-15 12:26:58 --> Hooks Class Initialized
DEBUG - 2018-02-15 12:26:58 --> UTF-8 Support Enabled
INFO - 2018-02-15 12:26:58 --> Utf8 Class Initialized
INFO - 2018-02-15 12:26:58 --> URI Class Initialized
INFO - 2018-02-15 12:26:58 --> Router Class Initialized
INFO - 2018-02-15 12:26:58 --> Output Class Initialized
INFO - 2018-02-15 12:26:58 --> Security Class Initialized
DEBUG - 2018-02-15 12:26:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 12:26:58 --> Input Class Initialized
INFO - 2018-02-15 12:26:58 --> Language Class Initialized
INFO - 2018-02-15 12:26:58 --> Loader Class Initialized
INFO - 2018-02-15 12:26:58 --> Helper loaded: url_helper
INFO - 2018-02-15 12:26:58 --> Helper loaded: file_helper
INFO - 2018-02-15 12:26:58 --> Helper loaded: email_helper
INFO - 2018-02-15 12:26:58 --> Helper loaded: common_helper
INFO - 2018-02-15 12:26:58 --> Database Driver Class Initialized
DEBUG - 2018-02-15 12:26:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 12:26:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 12:26:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 12:26:58 --> Pagination Class Initialized
INFO - 2018-02-15 12:26:58 --> Helper loaded: form_helper
INFO - 2018-02-15 12:26:58 --> Form Validation Class Initialized
INFO - 2018-02-15 12:26:58 --> Model Class Initialized
INFO - 2018-02-15 12:26:58 --> Controller Class Initialized
INFO - 2018-02-15 12:26:58 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 12:26:58 --> Model Class Initialized
INFO - 2018-02-15 12:26:58 --> Model Class Initialized
INFO - 2018-02-15 12:26:58 --> Model Class Initialized
INFO - 2018-02-15 12:27:01 --> Config Class Initialized
INFO - 2018-02-15 12:27:01 --> Hooks Class Initialized
DEBUG - 2018-02-15 12:27:01 --> UTF-8 Support Enabled
INFO - 2018-02-15 12:27:01 --> Utf8 Class Initialized
INFO - 2018-02-15 12:27:01 --> URI Class Initialized
INFO - 2018-02-15 12:27:01 --> Router Class Initialized
INFO - 2018-02-15 12:27:01 --> Output Class Initialized
INFO - 2018-02-15 12:27:01 --> Security Class Initialized
DEBUG - 2018-02-15 12:27:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 12:27:01 --> Input Class Initialized
INFO - 2018-02-15 12:27:01 --> Language Class Initialized
INFO - 2018-02-15 12:27:01 --> Loader Class Initialized
INFO - 2018-02-15 12:27:01 --> Helper loaded: url_helper
INFO - 2018-02-15 12:27:01 --> Helper loaded: file_helper
INFO - 2018-02-15 12:27:01 --> Helper loaded: email_helper
INFO - 2018-02-15 12:27:01 --> Helper loaded: common_helper
INFO - 2018-02-15 12:27:01 --> Database Driver Class Initialized
DEBUG - 2018-02-15 12:27:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 12:27:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 12:27:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 12:27:01 --> Pagination Class Initialized
INFO - 2018-02-15 12:27:01 --> Helper loaded: form_helper
INFO - 2018-02-15 12:27:01 --> Form Validation Class Initialized
INFO - 2018-02-15 12:27:01 --> Model Class Initialized
INFO - 2018-02-15 12:27:01 --> Controller Class Initialized
INFO - 2018-02-15 12:27:01 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 12:27:01 --> Model Class Initialized
INFO - 2018-02-15 12:27:01 --> Model Class Initialized
INFO - 2018-02-15 12:27:01 --> Model Class Initialized
INFO - 2018-02-15 12:27:03 --> Config Class Initialized
INFO - 2018-02-15 12:27:03 --> Hooks Class Initialized
DEBUG - 2018-02-15 12:27:03 --> UTF-8 Support Enabled
INFO - 2018-02-15 12:27:03 --> Utf8 Class Initialized
INFO - 2018-02-15 12:27:03 --> URI Class Initialized
INFO - 2018-02-15 12:27:03 --> Router Class Initialized
INFO - 2018-02-15 12:27:03 --> Output Class Initialized
INFO - 2018-02-15 12:27:03 --> Security Class Initialized
DEBUG - 2018-02-15 12:27:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 12:27:03 --> Input Class Initialized
INFO - 2018-02-15 12:27:03 --> Language Class Initialized
INFO - 2018-02-15 12:27:03 --> Loader Class Initialized
INFO - 2018-02-15 12:27:03 --> Helper loaded: url_helper
INFO - 2018-02-15 12:27:03 --> Helper loaded: file_helper
INFO - 2018-02-15 12:27:03 --> Helper loaded: email_helper
INFO - 2018-02-15 12:27:03 --> Helper loaded: common_helper
INFO - 2018-02-15 12:27:03 --> Database Driver Class Initialized
DEBUG - 2018-02-15 12:27:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 12:27:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 12:27:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 12:27:03 --> Pagination Class Initialized
INFO - 2018-02-15 12:27:03 --> Helper loaded: form_helper
INFO - 2018-02-15 12:27:03 --> Form Validation Class Initialized
INFO - 2018-02-15 12:27:03 --> Model Class Initialized
INFO - 2018-02-15 12:27:03 --> Controller Class Initialized
INFO - 2018-02-15 12:27:03 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 12:27:03 --> Model Class Initialized
INFO - 2018-02-15 12:27:03 --> Model Class Initialized
INFO - 2018-02-15 12:27:03 --> Model Class Initialized
INFO - 2018-02-15 12:59:42 --> Config Class Initialized
INFO - 2018-02-15 12:59:42 --> Hooks Class Initialized
DEBUG - 2018-02-15 12:59:42 --> UTF-8 Support Enabled
INFO - 2018-02-15 12:59:42 --> Utf8 Class Initialized
INFO - 2018-02-15 12:59:42 --> URI Class Initialized
INFO - 2018-02-15 12:59:42 --> Router Class Initialized
INFO - 2018-02-15 12:59:42 --> Output Class Initialized
INFO - 2018-02-15 12:59:42 --> Security Class Initialized
DEBUG - 2018-02-15 12:59:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 12:59:42 --> Input Class Initialized
INFO - 2018-02-15 12:59:42 --> Language Class Initialized
INFO - 2018-02-15 12:59:42 --> Loader Class Initialized
INFO - 2018-02-15 12:59:42 --> Helper loaded: url_helper
INFO - 2018-02-15 12:59:42 --> Helper loaded: file_helper
INFO - 2018-02-15 12:59:42 --> Helper loaded: email_helper
INFO - 2018-02-15 12:59:42 --> Helper loaded: common_helper
INFO - 2018-02-15 12:59:42 --> Database Driver Class Initialized
DEBUG - 2018-02-15 12:59:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 12:59:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 12:59:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 12:59:42 --> Pagination Class Initialized
INFO - 2018-02-15 12:59:42 --> Helper loaded: form_helper
INFO - 2018-02-15 12:59:42 --> Form Validation Class Initialized
INFO - 2018-02-15 12:59:42 --> Model Class Initialized
INFO - 2018-02-15 12:59:42 --> Controller Class Initialized
INFO - 2018-02-15 12:59:42 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 12:59:42 --> Model Class Initialized
INFO - 2018-02-15 12:59:42 --> Model Class Initialized
INFO - 2018-02-15 12:59:42 --> Model Class Initialized
INFO - 2018-02-15 12:59:42 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-15 12:59:42 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-15 12:59:42 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-15 12:59:42 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-15 12:59:42 --> File loaded: /var/www/html/project/radio/application/views/tracks/add_edit.php
INFO - 2018-02-15 12:59:42 --> Final output sent to browser
DEBUG - 2018-02-15 12:59:42 --> Total execution time: 0.0066
INFO - 2018-02-15 12:59:47 --> Config Class Initialized
INFO - 2018-02-15 12:59:47 --> Hooks Class Initialized
DEBUG - 2018-02-15 12:59:47 --> UTF-8 Support Enabled
INFO - 2018-02-15 12:59:47 --> Utf8 Class Initialized
INFO - 2018-02-15 12:59:47 --> URI Class Initialized
INFO - 2018-02-15 12:59:47 --> Router Class Initialized
INFO - 2018-02-15 12:59:47 --> Output Class Initialized
INFO - 2018-02-15 12:59:47 --> Security Class Initialized
DEBUG - 2018-02-15 12:59:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 12:59:47 --> Input Class Initialized
INFO - 2018-02-15 12:59:47 --> Language Class Initialized
INFO - 2018-02-15 12:59:47 --> Loader Class Initialized
INFO - 2018-02-15 12:59:47 --> Helper loaded: url_helper
INFO - 2018-02-15 12:59:47 --> Helper loaded: file_helper
INFO - 2018-02-15 12:59:47 --> Helper loaded: email_helper
INFO - 2018-02-15 12:59:47 --> Helper loaded: common_helper
INFO - 2018-02-15 12:59:47 --> Database Driver Class Initialized
DEBUG - 2018-02-15 12:59:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 12:59:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 12:59:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 12:59:47 --> Pagination Class Initialized
INFO - 2018-02-15 12:59:47 --> Helper loaded: form_helper
INFO - 2018-02-15 12:59:47 --> Form Validation Class Initialized
INFO - 2018-02-15 12:59:47 --> Model Class Initialized
INFO - 2018-02-15 12:59:47 --> Controller Class Initialized
INFO - 2018-02-15 12:59:47 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 12:59:47 --> Model Class Initialized
INFO - 2018-02-15 12:59:47 --> Model Class Initialized
INFO - 2018-02-15 12:59:47 --> Model Class Initialized
INFO - 2018-02-15 13:28:03 --> Config Class Initialized
INFO - 2018-02-15 13:28:03 --> Hooks Class Initialized
DEBUG - 2018-02-15 13:28:03 --> UTF-8 Support Enabled
INFO - 2018-02-15 13:28:03 --> Utf8 Class Initialized
INFO - 2018-02-15 13:28:03 --> URI Class Initialized
INFO - 2018-02-15 13:28:03 --> Router Class Initialized
INFO - 2018-02-15 13:28:03 --> Output Class Initialized
INFO - 2018-02-15 13:28:03 --> Security Class Initialized
DEBUG - 2018-02-15 13:28:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 13:28:03 --> Input Class Initialized
INFO - 2018-02-15 13:28:03 --> Language Class Initialized
INFO - 2018-02-15 13:28:03 --> Loader Class Initialized
INFO - 2018-02-15 13:28:03 --> Helper loaded: url_helper
INFO - 2018-02-15 13:28:03 --> Helper loaded: file_helper
INFO - 2018-02-15 13:28:03 --> Helper loaded: email_helper
INFO - 2018-02-15 13:28:03 --> Helper loaded: common_helper
INFO - 2018-02-15 13:28:03 --> Database Driver Class Initialized
DEBUG - 2018-02-15 13:28:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 13:28:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 13:28:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 13:28:03 --> Pagination Class Initialized
INFO - 2018-02-15 13:28:03 --> Helper loaded: form_helper
INFO - 2018-02-15 13:28:03 --> Form Validation Class Initialized
INFO - 2018-02-15 13:28:03 --> Model Class Initialized
INFO - 2018-02-15 13:28:03 --> Controller Class Initialized
INFO - 2018-02-15 13:28:03 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 13:28:03 --> Model Class Initialized
INFO - 2018-02-15 13:28:03 --> Model Class Initialized
INFO - 2018-02-15 13:28:03 --> Model Class Initialized
INFO - 2018-02-15 13:28:09 --> Config Class Initialized
INFO - 2018-02-15 13:28:09 --> Hooks Class Initialized
DEBUG - 2018-02-15 13:28:09 --> UTF-8 Support Enabled
INFO - 2018-02-15 13:28:09 --> Utf8 Class Initialized
INFO - 2018-02-15 13:28:09 --> URI Class Initialized
INFO - 2018-02-15 13:28:09 --> Router Class Initialized
INFO - 2018-02-15 13:28:09 --> Output Class Initialized
INFO - 2018-02-15 13:28:09 --> Security Class Initialized
DEBUG - 2018-02-15 13:28:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 13:28:09 --> Input Class Initialized
INFO - 2018-02-15 13:28:09 --> Language Class Initialized
INFO - 2018-02-15 13:28:09 --> Loader Class Initialized
INFO - 2018-02-15 13:28:09 --> Helper loaded: url_helper
INFO - 2018-02-15 13:28:09 --> Helper loaded: file_helper
INFO - 2018-02-15 13:28:09 --> Helper loaded: email_helper
INFO - 2018-02-15 13:28:09 --> Helper loaded: common_helper
INFO - 2018-02-15 13:28:09 --> Database Driver Class Initialized
DEBUG - 2018-02-15 13:28:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 13:28:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 13:28:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 13:28:09 --> Pagination Class Initialized
INFO - 2018-02-15 13:28:09 --> Helper loaded: form_helper
INFO - 2018-02-15 13:28:09 --> Form Validation Class Initialized
INFO - 2018-02-15 13:28:09 --> Model Class Initialized
INFO - 2018-02-15 13:28:09 --> Controller Class Initialized
INFO - 2018-02-15 13:28:09 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 13:28:09 --> Model Class Initialized
INFO - 2018-02-15 13:28:09 --> Model Class Initialized
INFO - 2018-02-15 13:28:09 --> Model Class Initialized
INFO - 2018-02-15 13:28:09 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-15 13:28:09 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-15 13:28:09 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-15 13:28:09 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-15 13:28:09 --> File loaded: /var/www/html/project/radio/application/views/tracks/add_edit.php
INFO - 2018-02-15 13:28:09 --> Final output sent to browser
DEBUG - 2018-02-15 13:28:09 --> Total execution time: 0.0105
INFO - 2018-02-15 13:28:10 --> Config Class Initialized
INFO - 2018-02-15 13:28:10 --> Hooks Class Initialized
DEBUG - 2018-02-15 13:28:10 --> UTF-8 Support Enabled
INFO - 2018-02-15 13:28:10 --> Utf8 Class Initialized
INFO - 2018-02-15 13:28:10 --> URI Class Initialized
INFO - 2018-02-15 13:28:10 --> Router Class Initialized
INFO - 2018-02-15 13:28:10 --> Output Class Initialized
INFO - 2018-02-15 13:28:10 --> Security Class Initialized
DEBUG - 2018-02-15 13:28:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 13:28:10 --> Input Class Initialized
INFO - 2018-02-15 13:28:10 --> Language Class Initialized
INFO - 2018-02-15 13:28:10 --> Loader Class Initialized
INFO - 2018-02-15 13:28:10 --> Helper loaded: url_helper
INFO - 2018-02-15 13:28:10 --> Helper loaded: file_helper
INFO - 2018-02-15 13:28:10 --> Helper loaded: email_helper
INFO - 2018-02-15 13:28:10 --> Helper loaded: common_helper
INFO - 2018-02-15 13:28:10 --> Database Driver Class Initialized
DEBUG - 2018-02-15 13:28:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 13:28:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 13:28:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 13:28:10 --> Pagination Class Initialized
INFO - 2018-02-15 13:28:10 --> Helper loaded: form_helper
INFO - 2018-02-15 13:28:10 --> Form Validation Class Initialized
INFO - 2018-02-15 13:28:10 --> Model Class Initialized
INFO - 2018-02-15 13:28:10 --> Controller Class Initialized
INFO - 2018-02-15 13:28:10 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 13:28:10 --> Model Class Initialized
INFO - 2018-02-15 13:28:10 --> Model Class Initialized
INFO - 2018-02-15 13:28:10 --> Model Class Initialized
INFO - 2018-02-15 13:28:20 --> Config Class Initialized
INFO - 2018-02-15 13:28:20 --> Hooks Class Initialized
DEBUG - 2018-02-15 13:28:20 --> UTF-8 Support Enabled
INFO - 2018-02-15 13:28:20 --> Utf8 Class Initialized
INFO - 2018-02-15 13:28:20 --> URI Class Initialized
INFO - 2018-02-15 13:28:20 --> Router Class Initialized
INFO - 2018-02-15 13:28:20 --> Output Class Initialized
INFO - 2018-02-15 13:28:20 --> Security Class Initialized
DEBUG - 2018-02-15 13:28:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 13:28:20 --> Input Class Initialized
INFO - 2018-02-15 13:28:20 --> Language Class Initialized
INFO - 2018-02-15 13:28:20 --> Loader Class Initialized
INFO - 2018-02-15 13:28:20 --> Helper loaded: url_helper
INFO - 2018-02-15 13:28:20 --> Helper loaded: file_helper
INFO - 2018-02-15 13:28:20 --> Helper loaded: email_helper
INFO - 2018-02-15 13:28:20 --> Helper loaded: common_helper
INFO - 2018-02-15 13:28:20 --> Database Driver Class Initialized
DEBUG - 2018-02-15 13:28:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 13:28:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 13:28:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 13:28:20 --> Pagination Class Initialized
INFO - 2018-02-15 13:28:20 --> Helper loaded: form_helper
INFO - 2018-02-15 13:28:20 --> Form Validation Class Initialized
INFO - 2018-02-15 13:28:20 --> Model Class Initialized
INFO - 2018-02-15 13:28:20 --> Controller Class Initialized
INFO - 2018-02-15 13:28:20 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 13:28:20 --> Model Class Initialized
INFO - 2018-02-15 13:28:20 --> Model Class Initialized
INFO - 2018-02-15 13:28:20 --> Model Class Initialized
INFO - 2018-02-15 13:28:58 --> Config Class Initialized
INFO - 2018-02-15 13:28:58 --> Hooks Class Initialized
DEBUG - 2018-02-15 13:28:58 --> UTF-8 Support Enabled
INFO - 2018-02-15 13:28:58 --> Utf8 Class Initialized
INFO - 2018-02-15 13:28:58 --> URI Class Initialized
INFO - 2018-02-15 13:28:58 --> Router Class Initialized
INFO - 2018-02-15 13:28:58 --> Output Class Initialized
INFO - 2018-02-15 13:28:58 --> Security Class Initialized
DEBUG - 2018-02-15 13:28:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 13:28:58 --> Input Class Initialized
INFO - 2018-02-15 13:28:58 --> Language Class Initialized
INFO - 2018-02-15 13:28:58 --> Loader Class Initialized
INFO - 2018-02-15 13:28:58 --> Helper loaded: url_helper
INFO - 2018-02-15 13:28:58 --> Helper loaded: file_helper
INFO - 2018-02-15 13:28:58 --> Helper loaded: email_helper
INFO - 2018-02-15 13:28:58 --> Helper loaded: common_helper
INFO - 2018-02-15 13:28:58 --> Database Driver Class Initialized
DEBUG - 2018-02-15 13:28:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 13:28:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 13:28:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 13:28:58 --> Pagination Class Initialized
INFO - 2018-02-15 13:28:58 --> Helper loaded: form_helper
INFO - 2018-02-15 13:28:58 --> Form Validation Class Initialized
INFO - 2018-02-15 13:28:58 --> Model Class Initialized
INFO - 2018-02-15 13:28:58 --> Controller Class Initialized
INFO - 2018-02-15 13:28:58 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 13:28:58 --> Model Class Initialized
INFO - 2018-02-15 13:28:58 --> Model Class Initialized
INFO - 2018-02-15 13:28:58 --> Model Class Initialized
INFO - 2018-02-15 13:28:58 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-15 13:28:58 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-15 13:28:58 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-15 13:28:58 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-15 13:28:58 --> File loaded: /var/www/html/project/radio/application/views/tracks/add_edit.php
INFO - 2018-02-15 13:28:58 --> Final output sent to browser
DEBUG - 2018-02-15 13:28:58 --> Total execution time: 0.0084
INFO - 2018-02-15 14:19:57 --> Config Class Initialized
INFO - 2018-02-15 14:19:57 --> Hooks Class Initialized
DEBUG - 2018-02-15 14:19:57 --> UTF-8 Support Enabled
INFO - 2018-02-15 14:19:57 --> Utf8 Class Initialized
INFO - 2018-02-15 14:19:57 --> URI Class Initialized
INFO - 2018-02-15 14:19:57 --> Router Class Initialized
INFO - 2018-02-15 14:19:57 --> Output Class Initialized
INFO - 2018-02-15 14:19:57 --> Security Class Initialized
DEBUG - 2018-02-15 14:19:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 14:19:57 --> Input Class Initialized
INFO - 2018-02-15 14:19:57 --> Language Class Initialized
INFO - 2018-02-15 14:19:57 --> Loader Class Initialized
INFO - 2018-02-15 14:19:57 --> Helper loaded: url_helper
INFO - 2018-02-15 14:19:57 --> Helper loaded: file_helper
INFO - 2018-02-15 14:19:57 --> Helper loaded: email_helper
INFO - 2018-02-15 14:19:57 --> Helper loaded: common_helper
INFO - 2018-02-15 14:19:57 --> Database Driver Class Initialized
DEBUG - 2018-02-15 14:19:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 14:19:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 14:19:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 14:19:57 --> Pagination Class Initialized
INFO - 2018-02-15 14:19:57 --> Helper loaded: form_helper
INFO - 2018-02-15 14:19:57 --> Form Validation Class Initialized
INFO - 2018-02-15 14:19:57 --> Model Class Initialized
INFO - 2018-02-15 14:19:57 --> Controller Class Initialized
INFO - 2018-02-15 14:19:57 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 14:19:57 --> Model Class Initialized
INFO - 2018-02-15 14:19:57 --> Model Class Initialized
INFO - 2018-02-15 14:19:57 --> Model Class Initialized
INFO - 2018-02-15 14:19:57 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-15 14:19:57 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-15 14:19:57 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-15 14:19:57 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-15 14:19:57 --> File loaded: /var/www/html/project/radio/application/views/tracks/add_edit.php
INFO - 2018-02-15 14:19:57 --> Final output sent to browser
DEBUG - 2018-02-15 14:19:57 --> Total execution time: 0.0088
INFO - 2018-02-15 14:20:36 --> Config Class Initialized
INFO - 2018-02-15 14:20:36 --> Hooks Class Initialized
DEBUG - 2018-02-15 14:20:36 --> UTF-8 Support Enabled
INFO - 2018-02-15 14:20:36 --> Utf8 Class Initialized
INFO - 2018-02-15 14:20:36 --> URI Class Initialized
INFO - 2018-02-15 14:20:36 --> Router Class Initialized
INFO - 2018-02-15 14:20:36 --> Output Class Initialized
INFO - 2018-02-15 14:20:36 --> Security Class Initialized
DEBUG - 2018-02-15 14:20:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 14:20:36 --> Input Class Initialized
INFO - 2018-02-15 14:20:36 --> Language Class Initialized
INFO - 2018-02-15 14:20:36 --> Loader Class Initialized
INFO - 2018-02-15 14:20:36 --> Helper loaded: url_helper
INFO - 2018-02-15 14:20:36 --> Helper loaded: file_helper
INFO - 2018-02-15 14:20:36 --> Helper loaded: email_helper
INFO - 2018-02-15 14:20:36 --> Helper loaded: common_helper
INFO - 2018-02-15 14:20:36 --> Database Driver Class Initialized
DEBUG - 2018-02-15 14:20:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 14:20:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 14:20:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 14:20:36 --> Pagination Class Initialized
INFO - 2018-02-15 14:20:36 --> Helper loaded: form_helper
INFO - 2018-02-15 14:20:36 --> Form Validation Class Initialized
INFO - 2018-02-15 14:20:36 --> Model Class Initialized
INFO - 2018-02-15 14:20:36 --> Controller Class Initialized
INFO - 2018-02-15 14:20:36 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 14:20:36 --> Model Class Initialized
INFO - 2018-02-15 14:20:36 --> Model Class Initialized
INFO - 2018-02-15 14:20:36 --> Model Class Initialized
INFO - 2018-02-15 14:20:36 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-15 14:20:36 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-15 14:20:36 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-15 14:20:36 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-15 14:20:36 --> File loaded: /var/www/html/project/radio/application/views/tracks/add_edit.php
INFO - 2018-02-15 14:20:36 --> Final output sent to browser
DEBUG - 2018-02-15 14:20:36 --> Total execution time: 0.0073
INFO - 2018-02-15 14:20:39 --> Config Class Initialized
INFO - 2018-02-15 14:20:39 --> Hooks Class Initialized
DEBUG - 2018-02-15 14:20:39 --> UTF-8 Support Enabled
INFO - 2018-02-15 14:20:39 --> Utf8 Class Initialized
INFO - 2018-02-15 14:20:39 --> URI Class Initialized
INFO - 2018-02-15 14:20:39 --> Router Class Initialized
INFO - 2018-02-15 14:20:39 --> Output Class Initialized
INFO - 2018-02-15 14:20:39 --> Security Class Initialized
DEBUG - 2018-02-15 14:20:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 14:20:39 --> Input Class Initialized
INFO - 2018-02-15 14:20:39 --> Language Class Initialized
INFO - 2018-02-15 14:20:39 --> Loader Class Initialized
INFO - 2018-02-15 14:20:39 --> Helper loaded: url_helper
INFO - 2018-02-15 14:20:39 --> Helper loaded: file_helper
INFO - 2018-02-15 14:20:39 --> Helper loaded: email_helper
INFO - 2018-02-15 14:20:39 --> Helper loaded: common_helper
INFO - 2018-02-15 14:20:39 --> Database Driver Class Initialized
DEBUG - 2018-02-15 14:20:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 14:20:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 14:20:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 14:20:39 --> Pagination Class Initialized
INFO - 2018-02-15 14:20:39 --> Helper loaded: form_helper
INFO - 2018-02-15 14:20:39 --> Form Validation Class Initialized
INFO - 2018-02-15 14:20:39 --> Model Class Initialized
INFO - 2018-02-15 14:20:39 --> Controller Class Initialized
INFO - 2018-02-15 14:20:39 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 14:20:39 --> Model Class Initialized
INFO - 2018-02-15 14:20:39 --> Model Class Initialized
INFO - 2018-02-15 14:20:39 --> Model Class Initialized
INFO - 2018-02-15 14:20:42 --> Config Class Initialized
INFO - 2018-02-15 14:20:42 --> Hooks Class Initialized
DEBUG - 2018-02-15 14:20:42 --> UTF-8 Support Enabled
INFO - 2018-02-15 14:20:42 --> Utf8 Class Initialized
INFO - 2018-02-15 14:20:42 --> URI Class Initialized
INFO - 2018-02-15 14:20:42 --> Router Class Initialized
INFO - 2018-02-15 14:20:42 --> Output Class Initialized
INFO - 2018-02-15 14:20:42 --> Security Class Initialized
DEBUG - 2018-02-15 14:20:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 14:20:42 --> Input Class Initialized
INFO - 2018-02-15 14:20:42 --> Language Class Initialized
INFO - 2018-02-15 14:20:42 --> Loader Class Initialized
INFO - 2018-02-15 14:20:42 --> Helper loaded: url_helper
INFO - 2018-02-15 14:20:42 --> Helper loaded: file_helper
INFO - 2018-02-15 14:20:42 --> Helper loaded: email_helper
INFO - 2018-02-15 14:20:42 --> Helper loaded: common_helper
INFO - 2018-02-15 14:20:42 --> Database Driver Class Initialized
DEBUG - 2018-02-15 14:20:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 14:20:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 14:20:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 14:20:42 --> Pagination Class Initialized
INFO - 2018-02-15 14:20:42 --> Helper loaded: form_helper
INFO - 2018-02-15 14:20:42 --> Form Validation Class Initialized
INFO - 2018-02-15 14:20:42 --> Model Class Initialized
INFO - 2018-02-15 14:20:42 --> Controller Class Initialized
INFO - 2018-02-15 14:20:42 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 14:20:42 --> Model Class Initialized
INFO - 2018-02-15 14:20:42 --> Model Class Initialized
INFO - 2018-02-15 14:20:42 --> Model Class Initialized
INFO - 2018-02-15 14:20:48 --> Config Class Initialized
INFO - 2018-02-15 14:20:48 --> Hooks Class Initialized
DEBUG - 2018-02-15 14:20:48 --> UTF-8 Support Enabled
INFO - 2018-02-15 14:20:48 --> Utf8 Class Initialized
INFO - 2018-02-15 14:20:48 --> URI Class Initialized
INFO - 2018-02-15 14:20:48 --> Router Class Initialized
INFO - 2018-02-15 14:20:48 --> Output Class Initialized
INFO - 2018-02-15 14:20:48 --> Security Class Initialized
DEBUG - 2018-02-15 14:20:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 14:20:48 --> Input Class Initialized
INFO - 2018-02-15 14:20:48 --> Language Class Initialized
INFO - 2018-02-15 14:20:48 --> Loader Class Initialized
INFO - 2018-02-15 14:20:48 --> Helper loaded: url_helper
INFO - 2018-02-15 14:20:48 --> Helper loaded: file_helper
INFO - 2018-02-15 14:20:48 --> Helper loaded: email_helper
INFO - 2018-02-15 14:20:48 --> Helper loaded: common_helper
INFO - 2018-02-15 14:20:48 --> Database Driver Class Initialized
DEBUG - 2018-02-15 14:20:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 14:20:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 14:20:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 14:20:48 --> Pagination Class Initialized
INFO - 2018-02-15 14:20:48 --> Helper loaded: form_helper
INFO - 2018-02-15 14:20:48 --> Form Validation Class Initialized
INFO - 2018-02-15 14:20:48 --> Model Class Initialized
INFO - 2018-02-15 14:20:48 --> Controller Class Initialized
INFO - 2018-02-15 14:20:48 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 14:20:48 --> Model Class Initialized
INFO - 2018-02-15 14:20:48 --> Model Class Initialized
INFO - 2018-02-15 14:20:48 --> Model Class Initialized
INFO - 2018-02-15 14:21:19 --> Config Class Initialized
INFO - 2018-02-15 14:21:19 --> Hooks Class Initialized
DEBUG - 2018-02-15 14:21:19 --> UTF-8 Support Enabled
INFO - 2018-02-15 14:21:19 --> Utf8 Class Initialized
INFO - 2018-02-15 14:21:19 --> URI Class Initialized
INFO - 2018-02-15 14:21:19 --> Router Class Initialized
INFO - 2018-02-15 14:21:19 --> Output Class Initialized
INFO - 2018-02-15 14:21:19 --> Security Class Initialized
DEBUG - 2018-02-15 14:21:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 14:21:19 --> Input Class Initialized
INFO - 2018-02-15 14:21:19 --> Language Class Initialized
INFO - 2018-02-15 14:21:19 --> Loader Class Initialized
INFO - 2018-02-15 14:21:19 --> Helper loaded: url_helper
INFO - 2018-02-15 14:21:19 --> Helper loaded: file_helper
INFO - 2018-02-15 14:21:19 --> Helper loaded: email_helper
INFO - 2018-02-15 14:21:19 --> Helper loaded: common_helper
INFO - 2018-02-15 14:21:19 --> Database Driver Class Initialized
DEBUG - 2018-02-15 14:21:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 14:21:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 14:21:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 14:21:19 --> Pagination Class Initialized
INFO - 2018-02-15 14:21:19 --> Helper loaded: form_helper
INFO - 2018-02-15 14:21:19 --> Form Validation Class Initialized
INFO - 2018-02-15 14:21:19 --> Model Class Initialized
INFO - 2018-02-15 14:21:19 --> Controller Class Initialized
INFO - 2018-02-15 14:21:19 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 14:21:19 --> Model Class Initialized
INFO - 2018-02-15 14:21:19 --> Model Class Initialized
INFO - 2018-02-15 14:21:19 --> Model Class Initialized
DEBUG - 2018-02-15 14:21:19 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-15 14:21:19 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-02-15 14:21:19 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-15 14:21:19 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-15 14:21:19 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-15 14:21:19 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-15 14:21:19 --> File loaded: /var/www/html/project/radio/application/views/tracks/add_edit.php
INFO - 2018-02-15 14:21:19 --> Final output sent to browser
DEBUG - 2018-02-15 14:21:19 --> Total execution time: 0.0257
INFO - 2018-02-15 14:21:23 --> Config Class Initialized
INFO - 2018-02-15 14:21:23 --> Hooks Class Initialized
DEBUG - 2018-02-15 14:21:23 --> UTF-8 Support Enabled
INFO - 2018-02-15 14:21:23 --> Utf8 Class Initialized
INFO - 2018-02-15 14:21:23 --> URI Class Initialized
INFO - 2018-02-15 14:21:23 --> Router Class Initialized
INFO - 2018-02-15 14:21:23 --> Output Class Initialized
INFO - 2018-02-15 14:21:23 --> Security Class Initialized
DEBUG - 2018-02-15 14:21:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 14:21:23 --> Input Class Initialized
INFO - 2018-02-15 14:21:23 --> Language Class Initialized
INFO - 2018-02-15 14:21:23 --> Loader Class Initialized
INFO - 2018-02-15 14:21:23 --> Helper loaded: url_helper
INFO - 2018-02-15 14:21:23 --> Helper loaded: file_helper
INFO - 2018-02-15 14:21:23 --> Helper loaded: email_helper
INFO - 2018-02-15 14:21:23 --> Helper loaded: common_helper
INFO - 2018-02-15 14:21:23 --> Database Driver Class Initialized
DEBUG - 2018-02-15 14:21:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 14:21:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 14:21:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 14:21:23 --> Pagination Class Initialized
INFO - 2018-02-15 14:21:23 --> Helper loaded: form_helper
INFO - 2018-02-15 14:21:23 --> Form Validation Class Initialized
INFO - 2018-02-15 14:21:23 --> Model Class Initialized
INFO - 2018-02-15 14:21:23 --> Controller Class Initialized
INFO - 2018-02-15 14:21:23 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 14:21:23 --> Model Class Initialized
INFO - 2018-02-15 14:21:23 --> Model Class Initialized
INFO - 2018-02-15 14:21:23 --> Model Class Initialized
INFO - 2018-02-15 14:21:28 --> Config Class Initialized
INFO - 2018-02-15 14:21:28 --> Hooks Class Initialized
DEBUG - 2018-02-15 14:21:28 --> UTF-8 Support Enabled
INFO - 2018-02-15 14:21:28 --> Utf8 Class Initialized
INFO - 2018-02-15 14:21:28 --> URI Class Initialized
INFO - 2018-02-15 14:21:28 --> Router Class Initialized
INFO - 2018-02-15 14:21:28 --> Output Class Initialized
INFO - 2018-02-15 14:21:28 --> Security Class Initialized
DEBUG - 2018-02-15 14:21:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 14:21:28 --> Input Class Initialized
INFO - 2018-02-15 14:21:28 --> Language Class Initialized
INFO - 2018-02-15 14:21:28 --> Loader Class Initialized
INFO - 2018-02-15 14:21:28 --> Helper loaded: url_helper
INFO - 2018-02-15 14:21:28 --> Helper loaded: file_helper
INFO - 2018-02-15 14:21:28 --> Helper loaded: email_helper
INFO - 2018-02-15 14:21:28 --> Helper loaded: common_helper
INFO - 2018-02-15 14:21:28 --> Database Driver Class Initialized
DEBUG - 2018-02-15 14:21:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 14:21:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 14:21:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 14:21:28 --> Pagination Class Initialized
INFO - 2018-02-15 14:21:28 --> Helper loaded: form_helper
INFO - 2018-02-15 14:21:28 --> Form Validation Class Initialized
INFO - 2018-02-15 14:21:28 --> Model Class Initialized
INFO - 2018-02-15 14:21:28 --> Controller Class Initialized
INFO - 2018-02-15 14:21:28 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 14:21:28 --> Model Class Initialized
INFO - 2018-02-15 14:21:28 --> Model Class Initialized
INFO - 2018-02-15 14:21:28 --> Model Class Initialized
DEBUG - 2018-02-15 14:21:28 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-15 14:21:28 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-02-15 14:21:28 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-15 14:21:28 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-15 14:21:28 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-15 14:21:28 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-15 14:21:28 --> File loaded: /var/www/html/project/radio/application/views/tracks/add_edit.php
INFO - 2018-02-15 14:21:28 --> Final output sent to browser
DEBUG - 2018-02-15 14:21:28 --> Total execution time: 0.0055
INFO - 2018-02-15 14:23:31 --> Config Class Initialized
INFO - 2018-02-15 14:23:31 --> Hooks Class Initialized
DEBUG - 2018-02-15 14:23:31 --> UTF-8 Support Enabled
INFO - 2018-02-15 14:23:31 --> Utf8 Class Initialized
INFO - 2018-02-15 14:23:31 --> URI Class Initialized
INFO - 2018-02-15 14:23:31 --> Router Class Initialized
INFO - 2018-02-15 14:23:31 --> Output Class Initialized
INFO - 2018-02-15 14:23:31 --> Security Class Initialized
DEBUG - 2018-02-15 14:23:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 14:23:31 --> Input Class Initialized
INFO - 2018-02-15 14:23:31 --> Language Class Initialized
INFO - 2018-02-15 14:23:31 --> Loader Class Initialized
INFO - 2018-02-15 14:23:31 --> Helper loaded: url_helper
INFO - 2018-02-15 14:23:31 --> Helper loaded: file_helper
INFO - 2018-02-15 14:23:31 --> Helper loaded: email_helper
INFO - 2018-02-15 14:23:31 --> Helper loaded: common_helper
INFO - 2018-02-15 14:23:31 --> Database Driver Class Initialized
DEBUG - 2018-02-15 14:23:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 14:23:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 14:23:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 14:23:31 --> Pagination Class Initialized
INFO - 2018-02-15 14:23:31 --> Helper loaded: form_helper
INFO - 2018-02-15 14:23:31 --> Form Validation Class Initialized
INFO - 2018-02-15 14:23:31 --> Model Class Initialized
INFO - 2018-02-15 14:23:31 --> Controller Class Initialized
INFO - 2018-02-15 14:23:31 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 14:23:31 --> Model Class Initialized
INFO - 2018-02-15 14:23:31 --> Model Class Initialized
INFO - 2018-02-15 14:23:31 --> Model Class Initialized
INFO - 2018-02-15 14:23:31 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-15 14:23:31 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-15 14:23:31 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-15 14:23:31 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-15 14:23:31 --> File loaded: /var/www/html/project/radio/application/views/tracks/add_edit.php
INFO - 2018-02-15 14:23:31 --> Final output sent to browser
DEBUG - 2018-02-15 14:23:31 --> Total execution time: 0.0084
INFO - 2018-02-15 14:23:35 --> Config Class Initialized
INFO - 2018-02-15 14:23:35 --> Hooks Class Initialized
DEBUG - 2018-02-15 14:23:35 --> UTF-8 Support Enabled
INFO - 2018-02-15 14:23:35 --> Utf8 Class Initialized
INFO - 2018-02-15 14:23:35 --> URI Class Initialized
INFO - 2018-02-15 14:23:35 --> Router Class Initialized
INFO - 2018-02-15 14:23:35 --> Output Class Initialized
INFO - 2018-02-15 14:23:35 --> Security Class Initialized
DEBUG - 2018-02-15 14:23:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 14:23:35 --> Input Class Initialized
INFO - 2018-02-15 14:23:35 --> Language Class Initialized
INFO - 2018-02-15 14:23:35 --> Loader Class Initialized
INFO - 2018-02-15 14:23:35 --> Helper loaded: url_helper
INFO - 2018-02-15 14:23:35 --> Helper loaded: file_helper
INFO - 2018-02-15 14:23:35 --> Helper loaded: email_helper
INFO - 2018-02-15 14:23:35 --> Helper loaded: common_helper
INFO - 2018-02-15 14:23:35 --> Database Driver Class Initialized
DEBUG - 2018-02-15 14:23:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 14:23:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 14:23:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 14:23:35 --> Pagination Class Initialized
INFO - 2018-02-15 14:23:35 --> Helper loaded: form_helper
INFO - 2018-02-15 14:23:35 --> Form Validation Class Initialized
INFO - 2018-02-15 14:23:35 --> Model Class Initialized
INFO - 2018-02-15 14:23:35 --> Controller Class Initialized
INFO - 2018-02-15 14:23:35 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 14:23:35 --> Model Class Initialized
INFO - 2018-02-15 14:23:35 --> Model Class Initialized
INFO - 2018-02-15 14:23:35 --> Model Class Initialized
INFO - 2018-02-15 14:23:38 --> Config Class Initialized
INFO - 2018-02-15 14:23:38 --> Hooks Class Initialized
DEBUG - 2018-02-15 14:23:38 --> UTF-8 Support Enabled
INFO - 2018-02-15 14:23:38 --> Utf8 Class Initialized
INFO - 2018-02-15 14:23:38 --> URI Class Initialized
INFO - 2018-02-15 14:23:38 --> Router Class Initialized
INFO - 2018-02-15 14:23:38 --> Output Class Initialized
INFO - 2018-02-15 14:23:38 --> Security Class Initialized
DEBUG - 2018-02-15 14:23:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 14:23:38 --> Input Class Initialized
INFO - 2018-02-15 14:23:38 --> Language Class Initialized
INFO - 2018-02-15 14:23:38 --> Loader Class Initialized
INFO - 2018-02-15 14:23:38 --> Helper loaded: url_helper
INFO - 2018-02-15 14:23:38 --> Helper loaded: file_helper
INFO - 2018-02-15 14:23:38 --> Helper loaded: email_helper
INFO - 2018-02-15 14:23:38 --> Helper loaded: common_helper
INFO - 2018-02-15 14:23:38 --> Database Driver Class Initialized
DEBUG - 2018-02-15 14:23:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 14:23:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 14:23:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 14:23:38 --> Pagination Class Initialized
INFO - 2018-02-15 14:23:38 --> Helper loaded: form_helper
INFO - 2018-02-15 14:23:38 --> Form Validation Class Initialized
INFO - 2018-02-15 14:23:38 --> Model Class Initialized
INFO - 2018-02-15 14:23:38 --> Controller Class Initialized
INFO - 2018-02-15 14:23:38 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 14:23:38 --> Model Class Initialized
INFO - 2018-02-15 14:23:38 --> Model Class Initialized
INFO - 2018-02-15 14:23:38 --> Model Class Initialized
INFO - 2018-02-15 14:24:01 --> Config Class Initialized
INFO - 2018-02-15 14:24:01 --> Hooks Class Initialized
DEBUG - 2018-02-15 14:24:01 --> UTF-8 Support Enabled
INFO - 2018-02-15 14:24:01 --> Utf8 Class Initialized
INFO - 2018-02-15 14:24:01 --> URI Class Initialized
INFO - 2018-02-15 14:24:01 --> Router Class Initialized
INFO - 2018-02-15 14:24:01 --> Output Class Initialized
INFO - 2018-02-15 14:24:01 --> Security Class Initialized
DEBUG - 2018-02-15 14:24:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 14:24:01 --> Input Class Initialized
INFO - 2018-02-15 14:24:01 --> Language Class Initialized
INFO - 2018-02-15 14:24:01 --> Loader Class Initialized
INFO - 2018-02-15 14:24:01 --> Helper loaded: url_helper
INFO - 2018-02-15 14:24:01 --> Helper loaded: file_helper
INFO - 2018-02-15 14:24:01 --> Helper loaded: email_helper
INFO - 2018-02-15 14:24:01 --> Helper loaded: common_helper
INFO - 2018-02-15 14:24:01 --> Database Driver Class Initialized
DEBUG - 2018-02-15 14:24:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 14:24:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 14:24:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 14:24:01 --> Pagination Class Initialized
INFO - 2018-02-15 14:24:01 --> Helper loaded: form_helper
INFO - 2018-02-15 14:24:01 --> Form Validation Class Initialized
INFO - 2018-02-15 14:24:01 --> Model Class Initialized
INFO - 2018-02-15 14:24:01 --> Controller Class Initialized
INFO - 2018-02-15 14:24:01 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 14:24:01 --> Model Class Initialized
INFO - 2018-02-15 14:24:01 --> Model Class Initialized
INFO - 2018-02-15 14:24:01 --> Model Class Initialized
DEBUG - 2018-02-15 14:24:01 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-15 14:24:01 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-02-15 14:24:01 --> Config Class Initialized
INFO - 2018-02-15 14:24:01 --> Hooks Class Initialized
DEBUG - 2018-02-15 14:24:01 --> UTF-8 Support Enabled
INFO - 2018-02-15 14:24:01 --> Utf8 Class Initialized
INFO - 2018-02-15 14:24:01 --> URI Class Initialized
INFO - 2018-02-15 14:24:01 --> Router Class Initialized
INFO - 2018-02-15 14:24:01 --> Output Class Initialized
INFO - 2018-02-15 14:24:01 --> Security Class Initialized
DEBUG - 2018-02-15 14:24:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 14:24:01 --> Input Class Initialized
INFO - 2018-02-15 14:24:01 --> Language Class Initialized
INFO - 2018-02-15 14:24:01 --> Loader Class Initialized
INFO - 2018-02-15 14:24:01 --> Helper loaded: url_helper
INFO - 2018-02-15 14:24:01 --> Helper loaded: file_helper
INFO - 2018-02-15 14:24:01 --> Helper loaded: email_helper
INFO - 2018-02-15 14:24:01 --> Helper loaded: common_helper
INFO - 2018-02-15 14:24:01 --> Database Driver Class Initialized
DEBUG - 2018-02-15 14:24:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 14:24:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 14:24:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 14:24:01 --> Pagination Class Initialized
INFO - 2018-02-15 14:24:01 --> Helper loaded: form_helper
INFO - 2018-02-15 14:24:01 --> Form Validation Class Initialized
INFO - 2018-02-15 14:24:01 --> Model Class Initialized
INFO - 2018-02-15 14:24:01 --> Controller Class Initialized
INFO - 2018-02-15 14:24:01 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 14:24:01 --> Model Class Initialized
INFO - 2018-02-15 14:24:01 --> Model Class Initialized
INFO - 2018-02-15 14:24:01 --> Model Class Initialized
INFO - 2018-02-15 14:24:01 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-15 14:24:01 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-15 14:24:01 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-15 14:24:01 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-15 14:24:01 --> File loaded: /var/www/html/project/radio/application/views/tracks/index.php
INFO - 2018-02-15 14:24:01 --> Final output sent to browser
DEBUG - 2018-02-15 14:24:01 --> Total execution time: 0.0067
INFO - 2018-02-15 14:24:02 --> Config Class Initialized
INFO - 2018-02-15 14:24:02 --> Hooks Class Initialized
DEBUG - 2018-02-15 14:24:02 --> UTF-8 Support Enabled
INFO - 2018-02-15 14:24:02 --> Utf8 Class Initialized
INFO - 2018-02-15 14:24:02 --> URI Class Initialized
INFO - 2018-02-15 14:24:02 --> Router Class Initialized
INFO - 2018-02-15 14:24:02 --> Output Class Initialized
INFO - 2018-02-15 14:24:02 --> Security Class Initialized
DEBUG - 2018-02-15 14:24:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 14:24:02 --> Input Class Initialized
INFO - 2018-02-15 14:24:02 --> Language Class Initialized
INFO - 2018-02-15 14:24:02 --> Loader Class Initialized
INFO - 2018-02-15 14:24:02 --> Helper loaded: url_helper
INFO - 2018-02-15 14:24:02 --> Helper loaded: file_helper
INFO - 2018-02-15 14:24:02 --> Helper loaded: email_helper
INFO - 2018-02-15 14:24:02 --> Helper loaded: common_helper
INFO - 2018-02-15 14:24:02 --> Database Driver Class Initialized
DEBUG - 2018-02-15 14:24:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 14:24:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 14:24:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 14:24:02 --> Pagination Class Initialized
INFO - 2018-02-15 14:24:02 --> Helper loaded: form_helper
INFO - 2018-02-15 14:24:02 --> Form Validation Class Initialized
INFO - 2018-02-15 14:24:02 --> Model Class Initialized
INFO - 2018-02-15 14:24:02 --> Controller Class Initialized
INFO - 2018-02-15 14:24:02 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 14:24:02 --> Model Class Initialized
INFO - 2018-02-15 14:24:02 --> Model Class Initialized
INFO - 2018-02-15 14:24:02 --> Model Class Initialized
INFO - 2018-02-15 14:24:23 --> Config Class Initialized
INFO - 2018-02-15 14:24:23 --> Hooks Class Initialized
DEBUG - 2018-02-15 14:24:23 --> UTF-8 Support Enabled
INFO - 2018-02-15 14:24:23 --> Utf8 Class Initialized
INFO - 2018-02-15 14:24:23 --> URI Class Initialized
INFO - 2018-02-15 14:24:23 --> Router Class Initialized
INFO - 2018-02-15 14:24:23 --> Output Class Initialized
INFO - 2018-02-15 14:24:23 --> Security Class Initialized
DEBUG - 2018-02-15 14:24:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 14:24:23 --> Input Class Initialized
INFO - 2018-02-15 14:24:23 --> Language Class Initialized
INFO - 2018-02-15 14:24:23 --> Loader Class Initialized
INFO - 2018-02-15 14:24:23 --> Helper loaded: url_helper
INFO - 2018-02-15 14:24:23 --> Helper loaded: file_helper
INFO - 2018-02-15 14:24:23 --> Helper loaded: email_helper
INFO - 2018-02-15 14:24:23 --> Helper loaded: common_helper
INFO - 2018-02-15 14:24:23 --> Database Driver Class Initialized
DEBUG - 2018-02-15 14:24:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 14:24:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 14:24:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 14:24:23 --> Pagination Class Initialized
INFO - 2018-02-15 14:24:23 --> Helper loaded: form_helper
INFO - 2018-02-15 14:24:23 --> Form Validation Class Initialized
INFO - 2018-02-15 14:24:23 --> Model Class Initialized
INFO - 2018-02-15 14:24:23 --> Controller Class Initialized
INFO - 2018-02-15 14:24:23 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 14:24:23 --> Model Class Initialized
INFO - 2018-02-15 14:24:23 --> Model Class Initialized
INFO - 2018-02-15 14:24:23 --> Model Class Initialized
INFO - 2018-02-15 14:24:23 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-15 14:24:23 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-15 14:24:23 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-15 14:24:23 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-15 14:24:23 --> File loaded: /var/www/html/project/radio/application/views/tracks/add_edit.php
INFO - 2018-02-15 14:24:23 --> Final output sent to browser
DEBUG - 2018-02-15 14:24:23 --> Total execution time: 0.0089
INFO - 2018-02-15 14:24:26 --> Config Class Initialized
INFO - 2018-02-15 14:24:26 --> Hooks Class Initialized
DEBUG - 2018-02-15 14:24:26 --> UTF-8 Support Enabled
INFO - 2018-02-15 14:24:26 --> Utf8 Class Initialized
INFO - 2018-02-15 14:24:26 --> URI Class Initialized
INFO - 2018-02-15 14:24:26 --> Router Class Initialized
INFO - 2018-02-15 14:24:26 --> Output Class Initialized
INFO - 2018-02-15 14:24:26 --> Security Class Initialized
DEBUG - 2018-02-15 14:24:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 14:24:26 --> Input Class Initialized
INFO - 2018-02-15 14:24:26 --> Language Class Initialized
INFO - 2018-02-15 14:24:26 --> Loader Class Initialized
INFO - 2018-02-15 14:24:26 --> Helper loaded: url_helper
INFO - 2018-02-15 14:24:26 --> Helper loaded: file_helper
INFO - 2018-02-15 14:24:26 --> Helper loaded: email_helper
INFO - 2018-02-15 14:24:26 --> Helper loaded: common_helper
INFO - 2018-02-15 14:24:26 --> Database Driver Class Initialized
DEBUG - 2018-02-15 14:24:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 14:24:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 14:24:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 14:24:26 --> Pagination Class Initialized
INFO - 2018-02-15 14:24:26 --> Helper loaded: form_helper
INFO - 2018-02-15 14:24:26 --> Form Validation Class Initialized
INFO - 2018-02-15 14:24:26 --> Model Class Initialized
INFO - 2018-02-15 14:24:26 --> Controller Class Initialized
INFO - 2018-02-15 14:24:26 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 14:24:26 --> Model Class Initialized
INFO - 2018-02-15 14:24:26 --> Model Class Initialized
INFO - 2018-02-15 14:24:26 --> Model Class Initialized
INFO - 2018-02-15 14:25:07 --> Config Class Initialized
INFO - 2018-02-15 14:25:07 --> Hooks Class Initialized
DEBUG - 2018-02-15 14:25:07 --> UTF-8 Support Enabled
INFO - 2018-02-15 14:25:07 --> Utf8 Class Initialized
INFO - 2018-02-15 14:25:07 --> URI Class Initialized
INFO - 2018-02-15 14:25:07 --> Router Class Initialized
INFO - 2018-02-15 14:25:07 --> Output Class Initialized
INFO - 2018-02-15 14:25:07 --> Security Class Initialized
DEBUG - 2018-02-15 14:25:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 14:25:07 --> Input Class Initialized
INFO - 2018-02-15 14:25:07 --> Language Class Initialized
INFO - 2018-02-15 14:25:07 --> Loader Class Initialized
INFO - 2018-02-15 14:25:07 --> Helper loaded: url_helper
INFO - 2018-02-15 14:25:07 --> Helper loaded: file_helper
INFO - 2018-02-15 14:25:07 --> Helper loaded: email_helper
INFO - 2018-02-15 14:25:07 --> Helper loaded: common_helper
INFO - 2018-02-15 14:25:07 --> Database Driver Class Initialized
DEBUG - 2018-02-15 14:25:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 14:25:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 14:25:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 14:25:07 --> Pagination Class Initialized
INFO - 2018-02-15 14:25:07 --> Helper loaded: form_helper
INFO - 2018-02-15 14:25:07 --> Form Validation Class Initialized
INFO - 2018-02-15 14:25:07 --> Model Class Initialized
INFO - 2018-02-15 14:25:07 --> Controller Class Initialized
INFO - 2018-02-15 14:25:07 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 14:25:07 --> Model Class Initialized
INFO - 2018-02-15 14:25:07 --> Model Class Initialized
INFO - 2018-02-15 14:25:07 --> Model Class Initialized
DEBUG - 2018-02-15 14:25:07 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-15 14:25:07 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-02-15 14:25:07 --> Upload Class Initialized
INFO - 2018-02-15 14:25:07 --> Config Class Initialized
INFO - 2018-02-15 14:25:07 --> Hooks Class Initialized
DEBUG - 2018-02-15 14:25:07 --> UTF-8 Support Enabled
INFO - 2018-02-15 14:25:07 --> Utf8 Class Initialized
INFO - 2018-02-15 14:25:07 --> URI Class Initialized
INFO - 2018-02-15 14:25:07 --> Router Class Initialized
INFO - 2018-02-15 14:25:07 --> Output Class Initialized
INFO - 2018-02-15 14:25:07 --> Security Class Initialized
DEBUG - 2018-02-15 14:25:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 14:25:07 --> Input Class Initialized
INFO - 2018-02-15 14:25:07 --> Language Class Initialized
INFO - 2018-02-15 14:25:07 --> Loader Class Initialized
INFO - 2018-02-15 14:25:07 --> Helper loaded: url_helper
INFO - 2018-02-15 14:25:07 --> Helper loaded: file_helper
INFO - 2018-02-15 14:25:07 --> Helper loaded: email_helper
INFO - 2018-02-15 14:25:07 --> Helper loaded: common_helper
INFO - 2018-02-15 14:25:07 --> Database Driver Class Initialized
DEBUG - 2018-02-15 14:25:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 14:25:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 14:25:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 14:25:07 --> Pagination Class Initialized
INFO - 2018-02-15 14:25:07 --> Helper loaded: form_helper
INFO - 2018-02-15 14:25:07 --> Form Validation Class Initialized
INFO - 2018-02-15 14:25:07 --> Model Class Initialized
INFO - 2018-02-15 14:25:07 --> Controller Class Initialized
INFO - 2018-02-15 14:25:07 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 14:25:07 --> Model Class Initialized
INFO - 2018-02-15 14:25:07 --> Model Class Initialized
INFO - 2018-02-15 14:25:07 --> Model Class Initialized
INFO - 2018-02-15 14:25:07 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-15 14:25:07 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-15 14:25:07 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-15 14:25:07 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-15 14:25:07 --> File loaded: /var/www/html/project/radio/application/views/tracks/index.php
INFO - 2018-02-15 14:25:07 --> Final output sent to browser
DEBUG - 2018-02-15 14:25:07 --> Total execution time: 0.0037
INFO - 2018-02-15 14:25:07 --> Config Class Initialized
INFO - 2018-02-15 14:25:07 --> Hooks Class Initialized
DEBUG - 2018-02-15 14:25:07 --> UTF-8 Support Enabled
INFO - 2018-02-15 14:25:07 --> Utf8 Class Initialized
INFO - 2018-02-15 14:25:07 --> URI Class Initialized
INFO - 2018-02-15 14:25:07 --> Router Class Initialized
INFO - 2018-02-15 14:25:07 --> Output Class Initialized
INFO - 2018-02-15 14:25:07 --> Security Class Initialized
DEBUG - 2018-02-15 14:25:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 14:25:07 --> Input Class Initialized
INFO - 2018-02-15 14:25:07 --> Language Class Initialized
INFO - 2018-02-15 14:25:07 --> Loader Class Initialized
INFO - 2018-02-15 14:25:07 --> Helper loaded: url_helper
INFO - 2018-02-15 14:25:07 --> Helper loaded: file_helper
INFO - 2018-02-15 14:25:07 --> Helper loaded: email_helper
INFO - 2018-02-15 14:25:07 --> Helper loaded: common_helper
INFO - 2018-02-15 14:25:07 --> Database Driver Class Initialized
DEBUG - 2018-02-15 14:25:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 14:25:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 14:25:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 14:25:07 --> Pagination Class Initialized
INFO - 2018-02-15 14:25:07 --> Helper loaded: form_helper
INFO - 2018-02-15 14:25:07 --> Form Validation Class Initialized
INFO - 2018-02-15 14:25:07 --> Model Class Initialized
INFO - 2018-02-15 14:25:07 --> Controller Class Initialized
INFO - 2018-02-15 14:25:07 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 14:25:07 --> Model Class Initialized
INFO - 2018-02-15 14:25:07 --> Model Class Initialized
INFO - 2018-02-15 14:25:07 --> Model Class Initialized
INFO - 2018-02-15 14:26:09 --> Config Class Initialized
INFO - 2018-02-15 14:26:09 --> Hooks Class Initialized
DEBUG - 2018-02-15 14:26:09 --> UTF-8 Support Enabled
INFO - 2018-02-15 14:26:09 --> Utf8 Class Initialized
INFO - 2018-02-15 14:26:09 --> URI Class Initialized
INFO - 2018-02-15 14:26:09 --> Router Class Initialized
INFO - 2018-02-15 14:26:09 --> Output Class Initialized
INFO - 2018-02-15 14:26:09 --> Security Class Initialized
DEBUG - 2018-02-15 14:26:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 14:26:09 --> Input Class Initialized
INFO - 2018-02-15 14:26:09 --> Language Class Initialized
INFO - 2018-02-15 14:26:09 --> Loader Class Initialized
INFO - 2018-02-15 14:26:09 --> Helper loaded: url_helper
INFO - 2018-02-15 14:26:09 --> Helper loaded: file_helper
INFO - 2018-02-15 14:26:09 --> Helper loaded: email_helper
INFO - 2018-02-15 14:26:09 --> Helper loaded: common_helper
INFO - 2018-02-15 14:26:09 --> Database Driver Class Initialized
DEBUG - 2018-02-15 14:26:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 14:26:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 14:26:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 14:26:09 --> Pagination Class Initialized
INFO - 2018-02-15 14:26:09 --> Helper loaded: form_helper
INFO - 2018-02-15 14:26:09 --> Form Validation Class Initialized
INFO - 2018-02-15 14:26:09 --> Model Class Initialized
INFO - 2018-02-15 14:26:09 --> Controller Class Initialized
INFO - 2018-02-15 14:26:09 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 14:26:09 --> Model Class Initialized
INFO - 2018-02-15 14:26:09 --> Model Class Initialized
INFO - 2018-02-15 14:26:09 --> Model Class Initialized
INFO - 2018-02-15 14:26:09 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-15 14:26:09 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-15 14:26:09 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-15 14:26:09 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-15 14:26:09 --> File loaded: /var/www/html/project/radio/application/views/tracks/index.php
INFO - 2018-02-15 14:26:09 --> Final output sent to browser
DEBUG - 2018-02-15 14:26:09 --> Total execution time: 0.0070
INFO - 2018-02-15 14:26:09 --> Config Class Initialized
INFO - 2018-02-15 14:26:09 --> Hooks Class Initialized
DEBUG - 2018-02-15 14:26:09 --> UTF-8 Support Enabled
INFO - 2018-02-15 14:26:09 --> Utf8 Class Initialized
INFO - 2018-02-15 14:26:09 --> URI Class Initialized
INFO - 2018-02-15 14:26:09 --> Router Class Initialized
INFO - 2018-02-15 14:26:09 --> Output Class Initialized
INFO - 2018-02-15 14:26:09 --> Security Class Initialized
DEBUG - 2018-02-15 14:26:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 14:26:09 --> Input Class Initialized
INFO - 2018-02-15 14:26:09 --> Language Class Initialized
INFO - 2018-02-15 14:26:09 --> Loader Class Initialized
INFO - 2018-02-15 14:26:09 --> Helper loaded: url_helper
INFO - 2018-02-15 14:26:09 --> Helper loaded: file_helper
INFO - 2018-02-15 14:26:09 --> Helper loaded: email_helper
INFO - 2018-02-15 14:26:09 --> Helper loaded: common_helper
INFO - 2018-02-15 14:26:09 --> Database Driver Class Initialized
DEBUG - 2018-02-15 14:26:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 14:26:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 14:26:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 14:26:09 --> Pagination Class Initialized
INFO - 2018-02-15 14:26:09 --> Helper loaded: form_helper
INFO - 2018-02-15 14:26:09 --> Form Validation Class Initialized
INFO - 2018-02-15 14:26:09 --> Model Class Initialized
INFO - 2018-02-15 14:26:09 --> Controller Class Initialized
INFO - 2018-02-15 14:26:09 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 14:26:09 --> Model Class Initialized
INFO - 2018-02-15 14:26:09 --> Model Class Initialized
INFO - 2018-02-15 14:26:09 --> Model Class Initialized
INFO - 2018-02-15 14:27:04 --> Config Class Initialized
INFO - 2018-02-15 14:27:04 --> Hooks Class Initialized
DEBUG - 2018-02-15 14:27:04 --> UTF-8 Support Enabled
INFO - 2018-02-15 14:27:04 --> Utf8 Class Initialized
INFO - 2018-02-15 14:27:04 --> URI Class Initialized
INFO - 2018-02-15 14:27:04 --> Router Class Initialized
INFO - 2018-02-15 14:27:04 --> Output Class Initialized
INFO - 2018-02-15 14:27:04 --> Security Class Initialized
DEBUG - 2018-02-15 14:27:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 14:27:04 --> Input Class Initialized
INFO - 2018-02-15 14:27:04 --> Language Class Initialized
INFO - 2018-02-15 14:27:04 --> Loader Class Initialized
INFO - 2018-02-15 14:27:04 --> Helper loaded: url_helper
INFO - 2018-02-15 14:27:04 --> Helper loaded: file_helper
INFO - 2018-02-15 14:27:04 --> Helper loaded: email_helper
INFO - 2018-02-15 14:27:04 --> Helper loaded: common_helper
INFO - 2018-02-15 14:27:04 --> Database Driver Class Initialized
DEBUG - 2018-02-15 14:27:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 14:27:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 14:27:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 14:27:04 --> Pagination Class Initialized
INFO - 2018-02-15 14:27:04 --> Helper loaded: form_helper
INFO - 2018-02-15 14:27:04 --> Form Validation Class Initialized
INFO - 2018-02-15 14:27:04 --> Model Class Initialized
INFO - 2018-02-15 14:27:04 --> Controller Class Initialized
INFO - 2018-02-15 14:27:04 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 14:27:04 --> Model Class Initialized
INFO - 2018-02-15 14:27:04 --> Model Class Initialized
INFO - 2018-02-15 14:27:04 --> Model Class Initialized
INFO - 2018-02-15 14:27:04 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-15 14:27:04 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-15 14:27:04 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-15 14:27:04 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-15 14:27:04 --> File loaded: /var/www/html/project/radio/application/views/tracks/index.php
INFO - 2018-02-15 14:27:04 --> Final output sent to browser
DEBUG - 2018-02-15 14:27:04 --> Total execution time: 0.0067
INFO - 2018-02-15 14:27:04 --> Config Class Initialized
INFO - 2018-02-15 14:27:04 --> Hooks Class Initialized
DEBUG - 2018-02-15 14:27:04 --> UTF-8 Support Enabled
INFO - 2018-02-15 14:27:04 --> Utf8 Class Initialized
INFO - 2018-02-15 14:27:04 --> URI Class Initialized
INFO - 2018-02-15 14:27:04 --> Router Class Initialized
INFO - 2018-02-15 14:27:04 --> Output Class Initialized
INFO - 2018-02-15 14:27:04 --> Security Class Initialized
DEBUG - 2018-02-15 14:27:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 14:27:04 --> Input Class Initialized
INFO - 2018-02-15 14:27:04 --> Language Class Initialized
INFO - 2018-02-15 14:27:04 --> Loader Class Initialized
INFO - 2018-02-15 14:27:04 --> Helper loaded: url_helper
INFO - 2018-02-15 14:27:04 --> Helper loaded: file_helper
INFO - 2018-02-15 14:27:04 --> Helper loaded: email_helper
INFO - 2018-02-15 14:27:04 --> Helper loaded: common_helper
INFO - 2018-02-15 14:27:04 --> Database Driver Class Initialized
DEBUG - 2018-02-15 14:27:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 14:27:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 14:27:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 14:27:04 --> Pagination Class Initialized
INFO - 2018-02-15 14:27:04 --> Helper loaded: form_helper
INFO - 2018-02-15 14:27:04 --> Form Validation Class Initialized
INFO - 2018-02-15 14:27:04 --> Model Class Initialized
INFO - 2018-02-15 14:27:04 --> Controller Class Initialized
INFO - 2018-02-15 14:27:04 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 14:27:04 --> Model Class Initialized
INFO - 2018-02-15 14:27:04 --> Model Class Initialized
INFO - 2018-02-15 14:27:04 --> Model Class Initialized
INFO - 2018-02-15 14:27:32 --> Config Class Initialized
INFO - 2018-02-15 14:27:32 --> Hooks Class Initialized
DEBUG - 2018-02-15 14:27:32 --> UTF-8 Support Enabled
INFO - 2018-02-15 14:27:32 --> Utf8 Class Initialized
INFO - 2018-02-15 14:27:32 --> URI Class Initialized
INFO - 2018-02-15 14:27:32 --> Router Class Initialized
INFO - 2018-02-15 14:27:32 --> Output Class Initialized
INFO - 2018-02-15 14:27:32 --> Security Class Initialized
DEBUG - 2018-02-15 14:27:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 14:27:32 --> Input Class Initialized
INFO - 2018-02-15 14:27:32 --> Language Class Initialized
INFO - 2018-02-15 14:27:32 --> Loader Class Initialized
INFO - 2018-02-15 14:27:32 --> Helper loaded: url_helper
INFO - 2018-02-15 14:27:32 --> Helper loaded: file_helper
INFO - 2018-02-15 14:27:32 --> Helper loaded: email_helper
INFO - 2018-02-15 14:27:32 --> Helper loaded: common_helper
INFO - 2018-02-15 14:27:32 --> Database Driver Class Initialized
DEBUG - 2018-02-15 14:27:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 14:27:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 14:27:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 14:27:32 --> Pagination Class Initialized
INFO - 2018-02-15 14:27:32 --> Helper loaded: form_helper
INFO - 2018-02-15 14:27:32 --> Form Validation Class Initialized
INFO - 2018-02-15 14:27:32 --> Model Class Initialized
INFO - 2018-02-15 14:27:32 --> Controller Class Initialized
INFO - 2018-02-15 14:27:32 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 14:27:32 --> Model Class Initialized
INFO - 2018-02-15 14:27:32 --> Model Class Initialized
INFO - 2018-02-15 14:27:32 --> Model Class Initialized
INFO - 2018-02-15 14:28:23 --> Config Class Initialized
INFO - 2018-02-15 14:28:23 --> Hooks Class Initialized
DEBUG - 2018-02-15 14:28:23 --> UTF-8 Support Enabled
INFO - 2018-02-15 14:28:23 --> Utf8 Class Initialized
INFO - 2018-02-15 14:28:23 --> URI Class Initialized
INFO - 2018-02-15 14:28:23 --> Router Class Initialized
INFO - 2018-02-15 14:28:23 --> Output Class Initialized
INFO - 2018-02-15 14:28:23 --> Security Class Initialized
DEBUG - 2018-02-15 14:28:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 14:28:23 --> Input Class Initialized
INFO - 2018-02-15 14:28:23 --> Language Class Initialized
INFO - 2018-02-15 14:28:23 --> Loader Class Initialized
INFO - 2018-02-15 14:28:23 --> Helper loaded: url_helper
INFO - 2018-02-15 14:28:23 --> Helper loaded: file_helper
INFO - 2018-02-15 14:28:23 --> Helper loaded: email_helper
INFO - 2018-02-15 14:28:23 --> Helper loaded: common_helper
INFO - 2018-02-15 14:28:23 --> Database Driver Class Initialized
DEBUG - 2018-02-15 14:28:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 14:28:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 14:28:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 14:28:24 --> Pagination Class Initialized
INFO - 2018-02-15 14:28:24 --> Helper loaded: form_helper
INFO - 2018-02-15 14:28:24 --> Form Validation Class Initialized
INFO - 2018-02-15 14:28:24 --> Model Class Initialized
INFO - 2018-02-15 14:28:24 --> Controller Class Initialized
INFO - 2018-02-15 14:28:24 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 14:28:24 --> Model Class Initialized
INFO - 2018-02-15 14:28:24 --> Model Class Initialized
INFO - 2018-02-15 14:28:24 --> Model Class Initialized
INFO - 2018-02-15 14:28:24 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-15 14:28:24 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-15 14:28:24 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-15 14:28:24 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-15 14:28:24 --> File loaded: /var/www/html/project/radio/application/views/tracks/index.php
INFO - 2018-02-15 14:28:24 --> Final output sent to browser
DEBUG - 2018-02-15 14:28:24 --> Total execution time: 0.0062
INFO - 2018-02-15 14:28:24 --> Config Class Initialized
INFO - 2018-02-15 14:28:24 --> Hooks Class Initialized
DEBUG - 2018-02-15 14:28:24 --> UTF-8 Support Enabled
INFO - 2018-02-15 14:28:24 --> Utf8 Class Initialized
INFO - 2018-02-15 14:28:24 --> URI Class Initialized
INFO - 2018-02-15 14:28:24 --> Router Class Initialized
INFO - 2018-02-15 14:28:24 --> Output Class Initialized
INFO - 2018-02-15 14:28:24 --> Security Class Initialized
DEBUG - 2018-02-15 14:28:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 14:28:24 --> Input Class Initialized
INFO - 2018-02-15 14:28:24 --> Language Class Initialized
INFO - 2018-02-15 14:28:24 --> Loader Class Initialized
INFO - 2018-02-15 14:28:24 --> Helper loaded: url_helper
INFO - 2018-02-15 14:28:24 --> Helper loaded: file_helper
INFO - 2018-02-15 14:28:24 --> Helper loaded: email_helper
INFO - 2018-02-15 14:28:24 --> Helper loaded: common_helper
INFO - 2018-02-15 14:28:24 --> Database Driver Class Initialized
DEBUG - 2018-02-15 14:28:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 14:28:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 14:28:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 14:28:24 --> Pagination Class Initialized
INFO - 2018-02-15 14:28:24 --> Helper loaded: form_helper
INFO - 2018-02-15 14:28:24 --> Form Validation Class Initialized
INFO - 2018-02-15 14:28:24 --> Model Class Initialized
INFO - 2018-02-15 14:28:24 --> Controller Class Initialized
INFO - 2018-02-15 14:28:24 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 14:28:24 --> Model Class Initialized
INFO - 2018-02-15 14:28:24 --> Model Class Initialized
INFO - 2018-02-15 14:28:24 --> Model Class Initialized
INFO - 2018-02-15 14:28:30 --> Config Class Initialized
INFO - 2018-02-15 14:28:30 --> Hooks Class Initialized
DEBUG - 2018-02-15 14:28:30 --> UTF-8 Support Enabled
INFO - 2018-02-15 14:28:30 --> Utf8 Class Initialized
INFO - 2018-02-15 14:28:30 --> URI Class Initialized
INFO - 2018-02-15 14:28:30 --> Router Class Initialized
INFO - 2018-02-15 14:28:30 --> Output Class Initialized
INFO - 2018-02-15 14:28:30 --> Security Class Initialized
DEBUG - 2018-02-15 14:28:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 14:28:30 --> Input Class Initialized
INFO - 2018-02-15 14:28:30 --> Language Class Initialized
INFO - 2018-02-15 14:28:30 --> Loader Class Initialized
INFO - 2018-02-15 14:28:30 --> Helper loaded: url_helper
INFO - 2018-02-15 14:28:30 --> Helper loaded: file_helper
INFO - 2018-02-15 14:28:30 --> Helper loaded: email_helper
INFO - 2018-02-15 14:28:30 --> Helper loaded: common_helper
INFO - 2018-02-15 14:28:30 --> Database Driver Class Initialized
DEBUG - 2018-02-15 14:28:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 14:28:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 14:28:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 14:28:30 --> Pagination Class Initialized
INFO - 2018-02-15 14:28:30 --> Helper loaded: form_helper
INFO - 2018-02-15 14:28:30 --> Form Validation Class Initialized
INFO - 2018-02-15 14:28:30 --> Model Class Initialized
INFO - 2018-02-15 14:28:30 --> Controller Class Initialized
INFO - 2018-02-15 14:28:30 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 14:28:30 --> Model Class Initialized
INFO - 2018-02-15 14:28:30 --> Model Class Initialized
INFO - 2018-02-15 14:28:30 --> Model Class Initialized
INFO - 2018-02-15 14:28:30 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-15 14:28:30 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-15 14:28:30 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-15 14:28:30 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-15 14:28:30 --> File loaded: /var/www/html/project/radio/application/views/tracks/index.php
INFO - 2018-02-15 14:28:30 --> Final output sent to browser
DEBUG - 2018-02-15 14:28:30 --> Total execution time: 0.0107
INFO - 2018-02-15 14:28:30 --> Config Class Initialized
INFO - 2018-02-15 14:28:30 --> Hooks Class Initialized
DEBUG - 2018-02-15 14:28:30 --> UTF-8 Support Enabled
INFO - 2018-02-15 14:28:30 --> Utf8 Class Initialized
INFO - 2018-02-15 14:28:30 --> URI Class Initialized
INFO - 2018-02-15 14:28:30 --> Router Class Initialized
INFO - 2018-02-15 14:28:30 --> Output Class Initialized
INFO - 2018-02-15 14:28:30 --> Security Class Initialized
DEBUG - 2018-02-15 14:28:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 14:28:30 --> Input Class Initialized
INFO - 2018-02-15 14:28:30 --> Language Class Initialized
INFO - 2018-02-15 14:28:30 --> Loader Class Initialized
INFO - 2018-02-15 14:28:30 --> Helper loaded: url_helper
INFO - 2018-02-15 14:28:30 --> Helper loaded: file_helper
INFO - 2018-02-15 14:28:30 --> Helper loaded: email_helper
INFO - 2018-02-15 14:28:30 --> Helper loaded: common_helper
INFO - 2018-02-15 14:28:30 --> Database Driver Class Initialized
DEBUG - 2018-02-15 14:28:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 14:28:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 14:28:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 14:28:30 --> Pagination Class Initialized
INFO - 2018-02-15 14:28:30 --> Helper loaded: form_helper
INFO - 2018-02-15 14:28:30 --> Form Validation Class Initialized
INFO - 2018-02-15 14:28:30 --> Model Class Initialized
INFO - 2018-02-15 14:28:30 --> Controller Class Initialized
INFO - 2018-02-15 14:28:30 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 14:28:30 --> Model Class Initialized
INFO - 2018-02-15 14:28:30 --> Model Class Initialized
INFO - 2018-02-15 14:28:30 --> Model Class Initialized
INFO - 2018-02-15 14:28:39 --> Config Class Initialized
INFO - 2018-02-15 14:28:39 --> Hooks Class Initialized
DEBUG - 2018-02-15 14:28:39 --> UTF-8 Support Enabled
INFO - 2018-02-15 14:28:39 --> Utf8 Class Initialized
INFO - 2018-02-15 14:28:39 --> URI Class Initialized
INFO - 2018-02-15 14:28:39 --> Router Class Initialized
INFO - 2018-02-15 14:28:39 --> Output Class Initialized
INFO - 2018-02-15 14:28:39 --> Security Class Initialized
DEBUG - 2018-02-15 14:28:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 14:28:39 --> Input Class Initialized
INFO - 2018-02-15 14:28:39 --> Language Class Initialized
INFO - 2018-02-15 14:28:39 --> Loader Class Initialized
INFO - 2018-02-15 14:28:39 --> Helper loaded: url_helper
INFO - 2018-02-15 14:28:39 --> Helper loaded: file_helper
INFO - 2018-02-15 14:28:39 --> Helper loaded: email_helper
INFO - 2018-02-15 14:28:39 --> Helper loaded: common_helper
INFO - 2018-02-15 14:28:39 --> Database Driver Class Initialized
DEBUG - 2018-02-15 14:28:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 14:28:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 14:28:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 14:28:39 --> Pagination Class Initialized
INFO - 2018-02-15 14:28:39 --> Helper loaded: form_helper
INFO - 2018-02-15 14:28:39 --> Form Validation Class Initialized
INFO - 2018-02-15 14:28:39 --> Model Class Initialized
INFO - 2018-02-15 14:28:39 --> Controller Class Initialized
INFO - 2018-02-15 14:28:39 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 14:28:39 --> Model Class Initialized
INFO - 2018-02-15 14:28:39 --> Model Class Initialized
INFO - 2018-02-15 14:28:39 --> Model Class Initialized
INFO - 2018-02-15 14:28:41 --> Config Class Initialized
INFO - 2018-02-15 14:28:41 --> Hooks Class Initialized
DEBUG - 2018-02-15 14:28:41 --> UTF-8 Support Enabled
INFO - 2018-02-15 14:28:41 --> Utf8 Class Initialized
INFO - 2018-02-15 14:28:41 --> URI Class Initialized
INFO - 2018-02-15 14:28:41 --> Router Class Initialized
INFO - 2018-02-15 14:28:41 --> Output Class Initialized
INFO - 2018-02-15 14:28:41 --> Security Class Initialized
DEBUG - 2018-02-15 14:28:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 14:28:41 --> Input Class Initialized
INFO - 2018-02-15 14:28:41 --> Language Class Initialized
INFO - 2018-02-15 14:28:41 --> Loader Class Initialized
INFO - 2018-02-15 14:28:41 --> Helper loaded: url_helper
INFO - 2018-02-15 14:28:41 --> Helper loaded: file_helper
INFO - 2018-02-15 14:28:41 --> Helper loaded: email_helper
INFO - 2018-02-15 14:28:41 --> Helper loaded: common_helper
INFO - 2018-02-15 14:28:41 --> Database Driver Class Initialized
DEBUG - 2018-02-15 14:28:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 14:28:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 14:28:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 14:28:41 --> Pagination Class Initialized
INFO - 2018-02-15 14:28:41 --> Helper loaded: form_helper
INFO - 2018-02-15 14:28:41 --> Form Validation Class Initialized
INFO - 2018-02-15 14:28:41 --> Model Class Initialized
INFO - 2018-02-15 14:28:41 --> Controller Class Initialized
INFO - 2018-02-15 14:28:41 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 14:28:41 --> Model Class Initialized
INFO - 2018-02-15 14:28:41 --> Model Class Initialized
INFO - 2018-02-15 14:28:41 --> Model Class Initialized
INFO - 2018-02-15 14:28:41 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-15 14:28:41 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-15 14:28:41 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-15 14:28:41 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-15 14:28:41 --> File loaded: /var/www/html/project/radio/application/views/tracks/index.php
INFO - 2018-02-15 14:28:41 --> Final output sent to browser
DEBUG - 2018-02-15 14:28:41 --> Total execution time: 0.0059
INFO - 2018-02-15 14:28:42 --> Config Class Initialized
INFO - 2018-02-15 14:28:42 --> Hooks Class Initialized
DEBUG - 2018-02-15 14:28:42 --> UTF-8 Support Enabled
INFO - 2018-02-15 14:28:42 --> Utf8 Class Initialized
INFO - 2018-02-15 14:28:42 --> URI Class Initialized
INFO - 2018-02-15 14:28:42 --> Router Class Initialized
INFO - 2018-02-15 14:28:42 --> Output Class Initialized
INFO - 2018-02-15 14:28:42 --> Security Class Initialized
DEBUG - 2018-02-15 14:28:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 14:28:42 --> Input Class Initialized
INFO - 2018-02-15 14:28:42 --> Language Class Initialized
INFO - 2018-02-15 14:28:42 --> Loader Class Initialized
INFO - 2018-02-15 14:28:42 --> Helper loaded: url_helper
INFO - 2018-02-15 14:28:42 --> Helper loaded: file_helper
INFO - 2018-02-15 14:28:42 --> Helper loaded: email_helper
INFO - 2018-02-15 14:28:42 --> Helper loaded: common_helper
INFO - 2018-02-15 14:28:42 --> Database Driver Class Initialized
DEBUG - 2018-02-15 14:28:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 14:28:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 14:28:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 14:28:42 --> Pagination Class Initialized
INFO - 2018-02-15 14:28:42 --> Helper loaded: form_helper
INFO - 2018-02-15 14:28:42 --> Form Validation Class Initialized
INFO - 2018-02-15 14:28:42 --> Model Class Initialized
INFO - 2018-02-15 14:28:42 --> Controller Class Initialized
INFO - 2018-02-15 14:28:42 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 14:28:42 --> Model Class Initialized
INFO - 2018-02-15 14:28:42 --> Model Class Initialized
INFO - 2018-02-15 14:28:42 --> Model Class Initialized
INFO - 2018-02-15 14:30:00 --> Config Class Initialized
INFO - 2018-02-15 14:30:00 --> Hooks Class Initialized
DEBUG - 2018-02-15 14:30:00 --> UTF-8 Support Enabled
INFO - 2018-02-15 14:30:00 --> Utf8 Class Initialized
INFO - 2018-02-15 14:30:00 --> URI Class Initialized
INFO - 2018-02-15 14:30:00 --> Router Class Initialized
INFO - 2018-02-15 14:30:00 --> Output Class Initialized
INFO - 2018-02-15 14:30:00 --> Security Class Initialized
DEBUG - 2018-02-15 14:30:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 14:30:00 --> Input Class Initialized
INFO - 2018-02-15 14:30:00 --> Language Class Initialized
INFO - 2018-02-15 14:30:00 --> Loader Class Initialized
INFO - 2018-02-15 14:30:00 --> Helper loaded: url_helper
INFO - 2018-02-15 14:30:00 --> Helper loaded: file_helper
INFO - 2018-02-15 14:30:00 --> Helper loaded: email_helper
INFO - 2018-02-15 14:30:00 --> Helper loaded: common_helper
INFO - 2018-02-15 14:30:00 --> Database Driver Class Initialized
DEBUG - 2018-02-15 14:30:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 14:30:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 14:30:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 14:30:00 --> Pagination Class Initialized
INFO - 2018-02-15 14:30:00 --> Helper loaded: form_helper
INFO - 2018-02-15 14:30:00 --> Form Validation Class Initialized
INFO - 2018-02-15 14:30:00 --> Model Class Initialized
INFO - 2018-02-15 14:30:00 --> Controller Class Initialized
INFO - 2018-02-15 14:30:00 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 14:30:00 --> Model Class Initialized
INFO - 2018-02-15 14:30:00 --> Model Class Initialized
INFO - 2018-02-15 14:30:00 --> Model Class Initialized
INFO - 2018-02-15 14:30:00 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-15 14:30:00 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-15 14:30:00 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-15 14:30:00 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-15 14:30:00 --> File loaded: /var/www/html/project/radio/application/views/tracks/add_edit.php
INFO - 2018-02-15 14:30:00 --> Final output sent to browser
DEBUG - 2018-02-15 14:30:00 --> Total execution time: 0.0105
INFO - 2018-02-15 14:30:01 --> Config Class Initialized
INFO - 2018-02-15 14:30:01 --> Hooks Class Initialized
DEBUG - 2018-02-15 14:30:01 --> UTF-8 Support Enabled
INFO - 2018-02-15 14:30:01 --> Utf8 Class Initialized
INFO - 2018-02-15 14:30:01 --> URI Class Initialized
INFO - 2018-02-15 14:30:01 --> Router Class Initialized
INFO - 2018-02-15 14:30:01 --> Output Class Initialized
INFO - 2018-02-15 14:30:01 --> Security Class Initialized
DEBUG - 2018-02-15 14:30:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 14:30:01 --> Input Class Initialized
INFO - 2018-02-15 14:30:01 --> Language Class Initialized
INFO - 2018-02-15 14:30:01 --> Loader Class Initialized
INFO - 2018-02-15 14:30:01 --> Helper loaded: url_helper
INFO - 2018-02-15 14:30:01 --> Helper loaded: file_helper
INFO - 2018-02-15 14:30:01 --> Helper loaded: email_helper
INFO - 2018-02-15 14:30:01 --> Helper loaded: common_helper
INFO - 2018-02-15 14:30:01 --> Database Driver Class Initialized
DEBUG - 2018-02-15 14:30:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 14:30:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 14:30:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 14:30:01 --> Pagination Class Initialized
INFO - 2018-02-15 14:30:01 --> Helper loaded: form_helper
INFO - 2018-02-15 14:30:01 --> Form Validation Class Initialized
INFO - 2018-02-15 14:30:01 --> Model Class Initialized
INFO - 2018-02-15 14:30:01 --> Controller Class Initialized
INFO - 2018-02-15 14:30:01 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 14:30:01 --> Model Class Initialized
INFO - 2018-02-15 14:30:01 --> Model Class Initialized
INFO - 2018-02-15 14:30:01 --> Model Class Initialized
INFO - 2018-02-15 14:30:28 --> Config Class Initialized
INFO - 2018-02-15 14:30:28 --> Hooks Class Initialized
DEBUG - 2018-02-15 14:30:28 --> UTF-8 Support Enabled
INFO - 2018-02-15 14:30:28 --> Utf8 Class Initialized
INFO - 2018-02-15 14:30:28 --> URI Class Initialized
INFO - 2018-02-15 14:30:28 --> Router Class Initialized
INFO - 2018-02-15 14:30:28 --> Output Class Initialized
INFO - 2018-02-15 14:30:28 --> Security Class Initialized
DEBUG - 2018-02-15 14:30:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 14:30:28 --> Input Class Initialized
INFO - 2018-02-15 14:30:28 --> Language Class Initialized
INFO - 2018-02-15 14:30:28 --> Loader Class Initialized
INFO - 2018-02-15 14:30:28 --> Helper loaded: url_helper
INFO - 2018-02-15 14:30:28 --> Helper loaded: file_helper
INFO - 2018-02-15 14:30:28 --> Helper loaded: email_helper
INFO - 2018-02-15 14:30:28 --> Helper loaded: common_helper
INFO - 2018-02-15 14:30:28 --> Database Driver Class Initialized
DEBUG - 2018-02-15 14:30:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 14:30:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 14:30:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 14:30:28 --> Pagination Class Initialized
INFO - 2018-02-15 14:30:28 --> Helper loaded: form_helper
INFO - 2018-02-15 14:30:28 --> Form Validation Class Initialized
INFO - 2018-02-15 14:30:28 --> Model Class Initialized
INFO - 2018-02-15 14:30:28 --> Controller Class Initialized
INFO - 2018-02-15 14:30:28 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 14:30:28 --> Model Class Initialized
INFO - 2018-02-15 14:30:28 --> Model Class Initialized
INFO - 2018-02-15 14:30:28 --> Model Class Initialized
INFO - 2018-02-15 14:30:28 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-15 14:30:28 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-15 14:30:28 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-15 14:30:28 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-15 14:30:28 --> File loaded: /var/www/html/project/radio/application/views/tracks/add_edit.php
INFO - 2018-02-15 14:30:28 --> Final output sent to browser
DEBUG - 2018-02-15 14:30:28 --> Total execution time: 0.0064
INFO - 2018-02-15 14:30:32 --> Config Class Initialized
INFO - 2018-02-15 14:30:32 --> Hooks Class Initialized
DEBUG - 2018-02-15 14:30:32 --> UTF-8 Support Enabled
INFO - 2018-02-15 14:30:32 --> Utf8 Class Initialized
INFO - 2018-02-15 14:30:32 --> URI Class Initialized
INFO - 2018-02-15 14:30:32 --> Router Class Initialized
INFO - 2018-02-15 14:30:32 --> Output Class Initialized
INFO - 2018-02-15 14:30:32 --> Security Class Initialized
DEBUG - 2018-02-15 14:30:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 14:30:32 --> Input Class Initialized
INFO - 2018-02-15 14:30:32 --> Language Class Initialized
INFO - 2018-02-15 14:30:32 --> Loader Class Initialized
INFO - 2018-02-15 14:30:32 --> Helper loaded: url_helper
INFO - 2018-02-15 14:30:32 --> Helper loaded: file_helper
INFO - 2018-02-15 14:30:32 --> Helper loaded: email_helper
INFO - 2018-02-15 14:30:32 --> Helper loaded: common_helper
INFO - 2018-02-15 14:30:32 --> Database Driver Class Initialized
DEBUG - 2018-02-15 14:30:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 14:30:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 14:30:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 14:30:32 --> Pagination Class Initialized
INFO - 2018-02-15 14:30:32 --> Helper loaded: form_helper
INFO - 2018-02-15 14:30:32 --> Form Validation Class Initialized
INFO - 2018-02-15 14:30:32 --> Model Class Initialized
INFO - 2018-02-15 14:30:32 --> Controller Class Initialized
INFO - 2018-02-15 14:30:32 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 14:30:32 --> Model Class Initialized
INFO - 2018-02-15 14:30:32 --> Model Class Initialized
INFO - 2018-02-15 14:30:32 --> Model Class Initialized
INFO - 2018-02-15 14:30:45 --> Config Class Initialized
INFO - 2018-02-15 14:30:45 --> Hooks Class Initialized
DEBUG - 2018-02-15 14:30:45 --> UTF-8 Support Enabled
INFO - 2018-02-15 14:30:45 --> Utf8 Class Initialized
INFO - 2018-02-15 14:30:45 --> URI Class Initialized
INFO - 2018-02-15 14:30:45 --> Router Class Initialized
INFO - 2018-02-15 14:30:45 --> Output Class Initialized
INFO - 2018-02-15 14:30:45 --> Security Class Initialized
DEBUG - 2018-02-15 14:30:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 14:30:45 --> Input Class Initialized
INFO - 2018-02-15 14:30:45 --> Language Class Initialized
INFO - 2018-02-15 14:30:45 --> Loader Class Initialized
INFO - 2018-02-15 14:30:45 --> Helper loaded: url_helper
INFO - 2018-02-15 14:30:45 --> Helper loaded: file_helper
INFO - 2018-02-15 14:30:45 --> Helper loaded: email_helper
INFO - 2018-02-15 14:30:45 --> Helper loaded: common_helper
INFO - 2018-02-15 14:30:45 --> Database Driver Class Initialized
DEBUG - 2018-02-15 14:30:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 14:30:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 14:30:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 14:30:45 --> Pagination Class Initialized
INFO - 2018-02-15 14:30:45 --> Helper loaded: form_helper
INFO - 2018-02-15 14:30:45 --> Form Validation Class Initialized
INFO - 2018-02-15 14:30:45 --> Model Class Initialized
INFO - 2018-02-15 14:30:45 --> Controller Class Initialized
INFO - 2018-02-15 14:30:45 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 14:30:45 --> Model Class Initialized
INFO - 2018-02-15 14:30:45 --> Model Class Initialized
INFO - 2018-02-15 14:30:45 --> Model Class Initialized
DEBUG - 2018-02-15 14:30:45 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-15 14:30:45 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-02-15 14:30:45 --> Config Class Initialized
INFO - 2018-02-15 14:30:45 --> Hooks Class Initialized
DEBUG - 2018-02-15 14:30:45 --> UTF-8 Support Enabled
INFO - 2018-02-15 14:30:45 --> Utf8 Class Initialized
INFO - 2018-02-15 14:30:45 --> URI Class Initialized
INFO - 2018-02-15 14:30:45 --> Router Class Initialized
INFO - 2018-02-15 14:30:45 --> Output Class Initialized
INFO - 2018-02-15 14:30:45 --> Security Class Initialized
DEBUG - 2018-02-15 14:30:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 14:30:45 --> Input Class Initialized
INFO - 2018-02-15 14:30:45 --> Language Class Initialized
INFO - 2018-02-15 14:30:45 --> Loader Class Initialized
INFO - 2018-02-15 14:30:45 --> Helper loaded: url_helper
INFO - 2018-02-15 14:30:45 --> Helper loaded: file_helper
INFO - 2018-02-15 14:30:45 --> Helper loaded: email_helper
INFO - 2018-02-15 14:30:45 --> Helper loaded: common_helper
INFO - 2018-02-15 14:30:45 --> Database Driver Class Initialized
DEBUG - 2018-02-15 14:30:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 14:30:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 14:30:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 14:30:45 --> Pagination Class Initialized
INFO - 2018-02-15 14:30:45 --> Helper loaded: form_helper
INFO - 2018-02-15 14:30:45 --> Form Validation Class Initialized
INFO - 2018-02-15 14:30:45 --> Model Class Initialized
INFO - 2018-02-15 14:30:45 --> Controller Class Initialized
INFO - 2018-02-15 14:30:45 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 14:30:45 --> Model Class Initialized
INFO - 2018-02-15 14:30:45 --> Model Class Initialized
INFO - 2018-02-15 14:30:45 --> Model Class Initialized
INFO - 2018-02-15 14:30:45 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-15 14:30:45 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-15 14:30:45 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-15 14:30:45 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-15 14:30:45 --> File loaded: /var/www/html/project/radio/application/views/tracks/index.php
INFO - 2018-02-15 14:30:45 --> Final output sent to browser
DEBUG - 2018-02-15 14:30:45 --> Total execution time: 0.0059
INFO - 2018-02-15 14:30:45 --> Config Class Initialized
INFO - 2018-02-15 14:30:45 --> Hooks Class Initialized
DEBUG - 2018-02-15 14:30:45 --> UTF-8 Support Enabled
INFO - 2018-02-15 14:30:45 --> Utf8 Class Initialized
INFO - 2018-02-15 14:30:45 --> URI Class Initialized
INFO - 2018-02-15 14:30:45 --> Router Class Initialized
INFO - 2018-02-15 14:30:45 --> Output Class Initialized
INFO - 2018-02-15 14:30:45 --> Security Class Initialized
DEBUG - 2018-02-15 14:30:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 14:30:45 --> Input Class Initialized
INFO - 2018-02-15 14:30:45 --> Language Class Initialized
INFO - 2018-02-15 14:30:45 --> Loader Class Initialized
INFO - 2018-02-15 14:30:45 --> Helper loaded: url_helper
INFO - 2018-02-15 14:30:45 --> Helper loaded: file_helper
INFO - 2018-02-15 14:30:45 --> Helper loaded: email_helper
INFO - 2018-02-15 14:30:45 --> Helper loaded: common_helper
INFO - 2018-02-15 14:30:45 --> Database Driver Class Initialized
DEBUG - 2018-02-15 14:30:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 14:30:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 14:30:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 14:30:45 --> Pagination Class Initialized
INFO - 2018-02-15 14:30:45 --> Helper loaded: form_helper
INFO - 2018-02-15 14:30:45 --> Form Validation Class Initialized
INFO - 2018-02-15 14:30:45 --> Model Class Initialized
INFO - 2018-02-15 14:30:45 --> Controller Class Initialized
INFO - 2018-02-15 14:30:45 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 14:30:45 --> Model Class Initialized
INFO - 2018-02-15 14:30:45 --> Model Class Initialized
INFO - 2018-02-15 14:30:45 --> Model Class Initialized
INFO - 2018-02-15 14:31:59 --> Config Class Initialized
INFO - 2018-02-15 14:31:59 --> Hooks Class Initialized
DEBUG - 2018-02-15 14:31:59 --> UTF-8 Support Enabled
INFO - 2018-02-15 14:31:59 --> Utf8 Class Initialized
INFO - 2018-02-15 14:31:59 --> URI Class Initialized
INFO - 2018-02-15 14:31:59 --> Router Class Initialized
INFO - 2018-02-15 14:31:59 --> Output Class Initialized
INFO - 2018-02-15 14:31:59 --> Security Class Initialized
DEBUG - 2018-02-15 14:31:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 14:31:59 --> Input Class Initialized
INFO - 2018-02-15 14:31:59 --> Language Class Initialized
INFO - 2018-02-15 14:31:59 --> Loader Class Initialized
INFO - 2018-02-15 14:31:59 --> Helper loaded: url_helper
INFO - 2018-02-15 14:31:59 --> Helper loaded: file_helper
INFO - 2018-02-15 14:31:59 --> Helper loaded: email_helper
INFO - 2018-02-15 14:31:59 --> Helper loaded: common_helper
INFO - 2018-02-15 14:31:59 --> Database Driver Class Initialized
DEBUG - 2018-02-15 14:31:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 14:31:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 14:31:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 14:31:59 --> Pagination Class Initialized
INFO - 2018-02-15 14:31:59 --> Helper loaded: form_helper
INFO - 2018-02-15 14:31:59 --> Form Validation Class Initialized
INFO - 2018-02-15 14:31:59 --> Model Class Initialized
INFO - 2018-02-15 14:31:59 --> Controller Class Initialized
INFO - 2018-02-15 14:31:59 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 14:31:59 --> Model Class Initialized
INFO - 2018-02-15 14:31:59 --> Model Class Initialized
INFO - 2018-02-15 14:31:59 --> Model Class Initialized
INFO - 2018-02-15 14:31:59 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-15 14:31:59 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-15 14:31:59 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-15 14:31:59 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-15 14:31:59 --> File loaded: /var/www/html/project/radio/application/views/tracks/index.php
INFO - 2018-02-15 14:31:59 --> Final output sent to browser
DEBUG - 2018-02-15 14:31:59 --> Total execution time: 0.0057
INFO - 2018-02-15 14:32:00 --> Config Class Initialized
INFO - 2018-02-15 14:32:00 --> Hooks Class Initialized
DEBUG - 2018-02-15 14:32:00 --> UTF-8 Support Enabled
INFO - 2018-02-15 14:32:00 --> Utf8 Class Initialized
INFO - 2018-02-15 14:32:00 --> URI Class Initialized
INFO - 2018-02-15 14:32:00 --> Router Class Initialized
INFO - 2018-02-15 14:32:00 --> Output Class Initialized
INFO - 2018-02-15 14:32:00 --> Security Class Initialized
DEBUG - 2018-02-15 14:32:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 14:32:00 --> Input Class Initialized
INFO - 2018-02-15 14:32:00 --> Language Class Initialized
INFO - 2018-02-15 14:32:00 --> Loader Class Initialized
INFO - 2018-02-15 14:32:00 --> Helper loaded: url_helper
INFO - 2018-02-15 14:32:00 --> Helper loaded: file_helper
INFO - 2018-02-15 14:32:00 --> Helper loaded: email_helper
INFO - 2018-02-15 14:32:00 --> Helper loaded: common_helper
INFO - 2018-02-15 14:32:00 --> Database Driver Class Initialized
DEBUG - 2018-02-15 14:32:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 14:32:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 14:32:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 14:32:00 --> Pagination Class Initialized
INFO - 2018-02-15 14:32:00 --> Helper loaded: form_helper
INFO - 2018-02-15 14:32:00 --> Form Validation Class Initialized
INFO - 2018-02-15 14:32:00 --> Model Class Initialized
INFO - 2018-02-15 14:32:00 --> Controller Class Initialized
INFO - 2018-02-15 14:32:00 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 14:32:00 --> Model Class Initialized
INFO - 2018-02-15 14:32:00 --> Model Class Initialized
INFO - 2018-02-15 14:32:00 --> Model Class Initialized
INFO - 2018-02-15 14:32:08 --> Config Class Initialized
INFO - 2018-02-15 14:32:08 --> Hooks Class Initialized
DEBUG - 2018-02-15 14:32:08 --> UTF-8 Support Enabled
INFO - 2018-02-15 14:32:08 --> Utf8 Class Initialized
INFO - 2018-02-15 14:32:08 --> URI Class Initialized
INFO - 2018-02-15 14:32:08 --> Router Class Initialized
INFO - 2018-02-15 14:32:08 --> Output Class Initialized
INFO - 2018-02-15 14:32:08 --> Security Class Initialized
DEBUG - 2018-02-15 14:32:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 14:32:08 --> Input Class Initialized
INFO - 2018-02-15 14:32:08 --> Language Class Initialized
INFO - 2018-02-15 14:32:08 --> Loader Class Initialized
INFO - 2018-02-15 14:32:08 --> Helper loaded: url_helper
INFO - 2018-02-15 14:32:08 --> Helper loaded: file_helper
INFO - 2018-02-15 14:32:08 --> Helper loaded: email_helper
INFO - 2018-02-15 14:32:08 --> Helper loaded: common_helper
INFO - 2018-02-15 14:32:08 --> Database Driver Class Initialized
DEBUG - 2018-02-15 14:32:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 14:32:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 14:32:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 14:32:08 --> Pagination Class Initialized
INFO - 2018-02-15 14:32:08 --> Helper loaded: form_helper
INFO - 2018-02-15 14:32:08 --> Form Validation Class Initialized
INFO - 2018-02-15 14:32:08 --> Model Class Initialized
INFO - 2018-02-15 14:32:08 --> Controller Class Initialized
INFO - 2018-02-15 14:32:08 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 14:32:08 --> Model Class Initialized
INFO - 2018-02-15 14:32:08 --> Model Class Initialized
INFO - 2018-02-15 14:32:08 --> Model Class Initialized
INFO - 2018-02-15 14:32:08 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-15 14:32:08 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-15 14:32:08 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-15 14:32:08 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-15 14:32:08 --> File loaded: /var/www/html/project/radio/application/views/tracks/index.php
INFO - 2018-02-15 14:32:08 --> Final output sent to browser
DEBUG - 2018-02-15 14:32:08 --> Total execution time: 0.0051
INFO - 2018-02-15 14:32:08 --> Config Class Initialized
INFO - 2018-02-15 14:32:08 --> Hooks Class Initialized
DEBUG - 2018-02-15 14:32:08 --> UTF-8 Support Enabled
INFO - 2018-02-15 14:32:08 --> Utf8 Class Initialized
INFO - 2018-02-15 14:32:08 --> URI Class Initialized
INFO - 2018-02-15 14:32:08 --> Router Class Initialized
INFO - 2018-02-15 14:32:08 --> Output Class Initialized
INFO - 2018-02-15 14:32:08 --> Security Class Initialized
DEBUG - 2018-02-15 14:32:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 14:32:08 --> Input Class Initialized
INFO - 2018-02-15 14:32:08 --> Language Class Initialized
INFO - 2018-02-15 14:32:08 --> Loader Class Initialized
INFO - 2018-02-15 14:32:08 --> Helper loaded: url_helper
INFO - 2018-02-15 14:32:08 --> Helper loaded: file_helper
INFO - 2018-02-15 14:32:08 --> Helper loaded: email_helper
INFO - 2018-02-15 14:32:08 --> Helper loaded: common_helper
INFO - 2018-02-15 14:32:08 --> Database Driver Class Initialized
DEBUG - 2018-02-15 14:32:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 14:32:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 14:32:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 14:32:08 --> Pagination Class Initialized
INFO - 2018-02-15 14:32:08 --> Helper loaded: form_helper
INFO - 2018-02-15 14:32:08 --> Form Validation Class Initialized
INFO - 2018-02-15 14:32:08 --> Model Class Initialized
INFO - 2018-02-15 14:32:08 --> Controller Class Initialized
INFO - 2018-02-15 14:32:08 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 14:32:08 --> Model Class Initialized
INFO - 2018-02-15 14:32:08 --> Model Class Initialized
INFO - 2018-02-15 14:32:08 --> Model Class Initialized
INFO - 2018-02-15 14:32:12 --> Config Class Initialized
INFO - 2018-02-15 14:32:12 --> Hooks Class Initialized
DEBUG - 2018-02-15 14:32:12 --> UTF-8 Support Enabled
INFO - 2018-02-15 14:32:12 --> Utf8 Class Initialized
INFO - 2018-02-15 14:32:12 --> URI Class Initialized
INFO - 2018-02-15 14:32:12 --> Router Class Initialized
INFO - 2018-02-15 14:32:12 --> Output Class Initialized
INFO - 2018-02-15 14:32:12 --> Security Class Initialized
DEBUG - 2018-02-15 14:32:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 14:32:12 --> Input Class Initialized
INFO - 2018-02-15 14:32:12 --> Language Class Initialized
INFO - 2018-02-15 14:32:12 --> Loader Class Initialized
INFO - 2018-02-15 14:32:12 --> Helper loaded: url_helper
INFO - 2018-02-15 14:32:12 --> Helper loaded: file_helper
INFO - 2018-02-15 14:32:12 --> Helper loaded: email_helper
INFO - 2018-02-15 14:32:12 --> Helper loaded: common_helper
INFO - 2018-02-15 14:32:12 --> Database Driver Class Initialized
DEBUG - 2018-02-15 14:32:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 14:32:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 14:32:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 14:32:12 --> Pagination Class Initialized
INFO - 2018-02-15 14:32:12 --> Helper loaded: form_helper
INFO - 2018-02-15 14:32:12 --> Form Validation Class Initialized
INFO - 2018-02-15 14:32:12 --> Model Class Initialized
INFO - 2018-02-15 14:32:12 --> Controller Class Initialized
INFO - 2018-02-15 14:32:12 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 14:32:12 --> Model Class Initialized
INFO - 2018-02-15 14:32:12 --> Model Class Initialized
INFO - 2018-02-15 14:32:12 --> Model Class Initialized
INFO - 2018-02-15 14:32:12 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-15 14:32:12 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-15 14:32:12 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-15 14:32:12 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-15 14:32:12 --> File loaded: /var/www/html/project/radio/application/views/tracks/index.php
INFO - 2018-02-15 14:32:12 --> Final output sent to browser
DEBUG - 2018-02-15 14:32:12 --> Total execution time: 0.0076
INFO - 2018-02-15 14:32:12 --> Config Class Initialized
INFO - 2018-02-15 14:32:12 --> Hooks Class Initialized
DEBUG - 2018-02-15 14:32:12 --> UTF-8 Support Enabled
INFO - 2018-02-15 14:32:12 --> Utf8 Class Initialized
INFO - 2018-02-15 14:32:12 --> URI Class Initialized
INFO - 2018-02-15 14:32:12 --> Router Class Initialized
INFO - 2018-02-15 14:32:12 --> Output Class Initialized
INFO - 2018-02-15 14:32:12 --> Security Class Initialized
DEBUG - 2018-02-15 14:32:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 14:32:12 --> Input Class Initialized
INFO - 2018-02-15 14:32:12 --> Language Class Initialized
INFO - 2018-02-15 14:32:12 --> Loader Class Initialized
INFO - 2018-02-15 14:32:12 --> Helper loaded: url_helper
INFO - 2018-02-15 14:32:12 --> Helper loaded: file_helper
INFO - 2018-02-15 14:32:12 --> Helper loaded: email_helper
INFO - 2018-02-15 14:32:12 --> Helper loaded: common_helper
INFO - 2018-02-15 14:32:12 --> Database Driver Class Initialized
DEBUG - 2018-02-15 14:32:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 14:32:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 14:32:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 14:32:12 --> Pagination Class Initialized
INFO - 2018-02-15 14:32:12 --> Helper loaded: form_helper
INFO - 2018-02-15 14:32:12 --> Form Validation Class Initialized
INFO - 2018-02-15 14:32:12 --> Model Class Initialized
INFO - 2018-02-15 14:32:12 --> Controller Class Initialized
INFO - 2018-02-15 14:32:12 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 14:32:12 --> Model Class Initialized
INFO - 2018-02-15 14:32:12 --> Model Class Initialized
INFO - 2018-02-15 14:32:12 --> Model Class Initialized
INFO - 2018-02-15 14:32:15 --> Config Class Initialized
INFO - 2018-02-15 14:32:15 --> Hooks Class Initialized
DEBUG - 2018-02-15 14:32:15 --> UTF-8 Support Enabled
INFO - 2018-02-15 14:32:15 --> Utf8 Class Initialized
INFO - 2018-02-15 14:32:15 --> URI Class Initialized
INFO - 2018-02-15 14:32:15 --> Router Class Initialized
INFO - 2018-02-15 14:32:15 --> Output Class Initialized
INFO - 2018-02-15 14:32:15 --> Security Class Initialized
DEBUG - 2018-02-15 14:32:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 14:32:15 --> Input Class Initialized
INFO - 2018-02-15 14:32:15 --> Language Class Initialized
INFO - 2018-02-15 14:32:15 --> Loader Class Initialized
INFO - 2018-02-15 14:32:15 --> Helper loaded: url_helper
INFO - 2018-02-15 14:32:15 --> Helper loaded: file_helper
INFO - 2018-02-15 14:32:15 --> Helper loaded: email_helper
INFO - 2018-02-15 14:32:15 --> Helper loaded: common_helper
INFO - 2018-02-15 14:32:15 --> Database Driver Class Initialized
DEBUG - 2018-02-15 14:32:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 14:32:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 14:32:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 14:32:15 --> Pagination Class Initialized
INFO - 2018-02-15 14:32:15 --> Helper loaded: form_helper
INFO - 2018-02-15 14:32:15 --> Form Validation Class Initialized
INFO - 2018-02-15 14:32:15 --> Model Class Initialized
INFO - 2018-02-15 14:32:15 --> Controller Class Initialized
INFO - 2018-02-15 14:32:15 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 14:32:15 --> Model Class Initialized
INFO - 2018-02-15 14:32:15 --> Model Class Initialized
INFO - 2018-02-15 14:32:15 --> Model Class Initialized
INFO - 2018-02-15 14:32:15 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-15 14:32:15 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-15 14:32:15 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-15 14:32:15 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-15 14:32:15 --> File loaded: /var/www/html/project/radio/application/views/tracks/index.php
INFO - 2018-02-15 14:32:15 --> Final output sent to browser
DEBUG - 2018-02-15 14:32:15 --> Total execution time: 0.0067
INFO - 2018-02-15 14:32:16 --> Config Class Initialized
INFO - 2018-02-15 14:32:16 --> Hooks Class Initialized
DEBUG - 2018-02-15 14:32:16 --> UTF-8 Support Enabled
INFO - 2018-02-15 14:32:16 --> Utf8 Class Initialized
INFO - 2018-02-15 14:32:16 --> URI Class Initialized
INFO - 2018-02-15 14:32:16 --> Router Class Initialized
INFO - 2018-02-15 14:32:16 --> Output Class Initialized
INFO - 2018-02-15 14:32:16 --> Security Class Initialized
DEBUG - 2018-02-15 14:32:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 14:32:16 --> Input Class Initialized
INFO - 2018-02-15 14:32:16 --> Language Class Initialized
INFO - 2018-02-15 14:32:16 --> Loader Class Initialized
INFO - 2018-02-15 14:32:16 --> Helper loaded: url_helper
INFO - 2018-02-15 14:32:16 --> Helper loaded: file_helper
INFO - 2018-02-15 14:32:16 --> Helper loaded: email_helper
INFO - 2018-02-15 14:32:16 --> Helper loaded: common_helper
INFO - 2018-02-15 14:32:16 --> Database Driver Class Initialized
DEBUG - 2018-02-15 14:32:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 14:32:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 14:32:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 14:32:16 --> Pagination Class Initialized
INFO - 2018-02-15 14:32:16 --> Helper loaded: form_helper
INFO - 2018-02-15 14:32:16 --> Form Validation Class Initialized
INFO - 2018-02-15 14:32:16 --> Model Class Initialized
INFO - 2018-02-15 14:32:16 --> Controller Class Initialized
INFO - 2018-02-15 14:32:16 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 14:32:16 --> Model Class Initialized
INFO - 2018-02-15 14:32:16 --> Model Class Initialized
INFO - 2018-02-15 14:32:16 --> Model Class Initialized
INFO - 2018-02-15 14:32:37 --> Config Class Initialized
INFO - 2018-02-15 14:32:37 --> Hooks Class Initialized
DEBUG - 2018-02-15 14:32:37 --> UTF-8 Support Enabled
INFO - 2018-02-15 14:32:37 --> Utf8 Class Initialized
INFO - 2018-02-15 14:32:37 --> URI Class Initialized
INFO - 2018-02-15 14:32:37 --> Router Class Initialized
INFO - 2018-02-15 14:32:37 --> Output Class Initialized
INFO - 2018-02-15 14:32:37 --> Security Class Initialized
DEBUG - 2018-02-15 14:32:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 14:32:37 --> Input Class Initialized
INFO - 2018-02-15 14:32:37 --> Language Class Initialized
INFO - 2018-02-15 14:32:37 --> Loader Class Initialized
INFO - 2018-02-15 14:32:37 --> Helper loaded: url_helper
INFO - 2018-02-15 14:32:37 --> Helper loaded: file_helper
INFO - 2018-02-15 14:32:37 --> Helper loaded: email_helper
INFO - 2018-02-15 14:32:37 --> Helper loaded: common_helper
INFO - 2018-02-15 14:32:37 --> Database Driver Class Initialized
DEBUG - 2018-02-15 14:32:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 14:32:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 14:32:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 14:32:37 --> Pagination Class Initialized
INFO - 2018-02-15 14:32:37 --> Helper loaded: form_helper
INFO - 2018-02-15 14:32:37 --> Form Validation Class Initialized
INFO - 2018-02-15 14:32:37 --> Model Class Initialized
INFO - 2018-02-15 14:32:37 --> Controller Class Initialized
INFO - 2018-02-15 14:32:37 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 14:32:37 --> Model Class Initialized
INFO - 2018-02-15 14:32:37 --> Model Class Initialized
INFO - 2018-02-15 14:32:37 --> Model Class Initialized
INFO - 2018-02-15 14:32:37 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-15 14:32:37 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-15 14:32:37 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-15 14:32:37 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-15 14:32:37 --> File loaded: /var/www/html/project/radio/application/views/tracks/index.php
INFO - 2018-02-15 14:32:37 --> Final output sent to browser
DEBUG - 2018-02-15 14:32:37 --> Total execution time: 0.0049
INFO - 2018-02-15 14:32:38 --> Config Class Initialized
INFO - 2018-02-15 14:32:38 --> Hooks Class Initialized
DEBUG - 2018-02-15 14:32:38 --> UTF-8 Support Enabled
INFO - 2018-02-15 14:32:38 --> Utf8 Class Initialized
INFO - 2018-02-15 14:32:38 --> URI Class Initialized
INFO - 2018-02-15 14:32:38 --> Router Class Initialized
INFO - 2018-02-15 14:32:38 --> Output Class Initialized
INFO - 2018-02-15 14:32:38 --> Security Class Initialized
DEBUG - 2018-02-15 14:32:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 14:32:38 --> Input Class Initialized
INFO - 2018-02-15 14:32:38 --> Language Class Initialized
INFO - 2018-02-15 14:32:38 --> Loader Class Initialized
INFO - 2018-02-15 14:32:38 --> Helper loaded: url_helper
INFO - 2018-02-15 14:32:38 --> Helper loaded: file_helper
INFO - 2018-02-15 14:32:38 --> Helper loaded: email_helper
INFO - 2018-02-15 14:32:38 --> Helper loaded: common_helper
INFO - 2018-02-15 14:32:38 --> Database Driver Class Initialized
DEBUG - 2018-02-15 14:32:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 14:32:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 14:32:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 14:32:38 --> Pagination Class Initialized
INFO - 2018-02-15 14:32:38 --> Helper loaded: form_helper
INFO - 2018-02-15 14:32:38 --> Form Validation Class Initialized
INFO - 2018-02-15 14:32:38 --> Model Class Initialized
INFO - 2018-02-15 14:32:38 --> Controller Class Initialized
INFO - 2018-02-15 14:32:38 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 14:32:38 --> Model Class Initialized
INFO - 2018-02-15 14:32:38 --> Model Class Initialized
INFO - 2018-02-15 14:32:38 --> Model Class Initialized
INFO - 2018-02-15 14:33:21 --> Config Class Initialized
INFO - 2018-02-15 14:33:21 --> Hooks Class Initialized
DEBUG - 2018-02-15 14:33:21 --> UTF-8 Support Enabled
INFO - 2018-02-15 14:33:21 --> Utf8 Class Initialized
INFO - 2018-02-15 14:33:21 --> URI Class Initialized
INFO - 2018-02-15 14:33:21 --> Router Class Initialized
INFO - 2018-02-15 14:33:21 --> Output Class Initialized
INFO - 2018-02-15 14:33:21 --> Security Class Initialized
DEBUG - 2018-02-15 14:33:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 14:33:21 --> Input Class Initialized
INFO - 2018-02-15 14:33:21 --> Language Class Initialized
INFO - 2018-02-15 14:33:21 --> Loader Class Initialized
INFO - 2018-02-15 14:33:21 --> Helper loaded: url_helper
INFO - 2018-02-15 14:33:21 --> Helper loaded: file_helper
INFO - 2018-02-15 14:33:21 --> Helper loaded: email_helper
INFO - 2018-02-15 14:33:21 --> Helper loaded: common_helper
INFO - 2018-02-15 14:33:21 --> Database Driver Class Initialized
DEBUG - 2018-02-15 14:33:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 14:33:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 14:33:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 14:33:21 --> Pagination Class Initialized
INFO - 2018-02-15 14:33:21 --> Helper loaded: form_helper
INFO - 2018-02-15 14:33:21 --> Form Validation Class Initialized
INFO - 2018-02-15 14:33:21 --> Model Class Initialized
INFO - 2018-02-15 14:33:21 --> Controller Class Initialized
INFO - 2018-02-15 14:33:21 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 14:33:21 --> Model Class Initialized
INFO - 2018-02-15 14:33:21 --> Model Class Initialized
INFO - 2018-02-15 14:33:21 --> Model Class Initialized
INFO - 2018-02-15 14:33:21 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-15 14:33:21 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-15 14:33:21 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-15 14:33:21 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-15 14:33:21 --> File loaded: /var/www/html/project/radio/application/views/tracks/index.php
INFO - 2018-02-15 14:33:21 --> Final output sent to browser
DEBUG - 2018-02-15 14:33:21 --> Total execution time: 0.0063
INFO - 2018-02-15 14:33:21 --> Config Class Initialized
INFO - 2018-02-15 14:33:21 --> Hooks Class Initialized
DEBUG - 2018-02-15 14:33:21 --> UTF-8 Support Enabled
INFO - 2018-02-15 14:33:21 --> Utf8 Class Initialized
INFO - 2018-02-15 14:33:21 --> URI Class Initialized
INFO - 2018-02-15 14:33:21 --> Router Class Initialized
INFO - 2018-02-15 14:33:21 --> Output Class Initialized
INFO - 2018-02-15 14:33:21 --> Security Class Initialized
DEBUG - 2018-02-15 14:33:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 14:33:21 --> Input Class Initialized
INFO - 2018-02-15 14:33:21 --> Language Class Initialized
INFO - 2018-02-15 14:33:21 --> Loader Class Initialized
INFO - 2018-02-15 14:33:21 --> Helper loaded: url_helper
INFO - 2018-02-15 14:33:21 --> Helper loaded: file_helper
INFO - 2018-02-15 14:33:21 --> Helper loaded: email_helper
INFO - 2018-02-15 14:33:21 --> Helper loaded: common_helper
INFO - 2018-02-15 14:33:21 --> Database Driver Class Initialized
DEBUG - 2018-02-15 14:33:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 14:33:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 14:33:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 14:33:21 --> Pagination Class Initialized
INFO - 2018-02-15 14:33:21 --> Helper loaded: form_helper
INFO - 2018-02-15 14:33:21 --> Form Validation Class Initialized
INFO - 2018-02-15 14:33:21 --> Model Class Initialized
INFO - 2018-02-15 14:33:21 --> Controller Class Initialized
INFO - 2018-02-15 14:33:21 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 14:33:21 --> Model Class Initialized
INFO - 2018-02-15 14:33:21 --> Model Class Initialized
INFO - 2018-02-15 14:33:21 --> Model Class Initialized
INFO - 2018-02-15 14:34:11 --> Config Class Initialized
INFO - 2018-02-15 14:34:11 --> Hooks Class Initialized
DEBUG - 2018-02-15 14:34:11 --> UTF-8 Support Enabled
INFO - 2018-02-15 14:34:11 --> Utf8 Class Initialized
INFO - 2018-02-15 14:34:11 --> URI Class Initialized
INFO - 2018-02-15 14:34:11 --> Router Class Initialized
INFO - 2018-02-15 14:34:11 --> Output Class Initialized
INFO - 2018-02-15 14:34:11 --> Security Class Initialized
DEBUG - 2018-02-15 14:34:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 14:34:11 --> Input Class Initialized
INFO - 2018-02-15 14:34:11 --> Language Class Initialized
INFO - 2018-02-15 14:34:11 --> Loader Class Initialized
INFO - 2018-02-15 14:34:11 --> Helper loaded: url_helper
INFO - 2018-02-15 14:34:11 --> Helper loaded: file_helper
INFO - 2018-02-15 14:34:11 --> Helper loaded: email_helper
INFO - 2018-02-15 14:34:11 --> Helper loaded: common_helper
INFO - 2018-02-15 14:34:11 --> Database Driver Class Initialized
DEBUG - 2018-02-15 14:34:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 14:34:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 14:34:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 14:34:11 --> Pagination Class Initialized
INFO - 2018-02-15 14:34:11 --> Helper loaded: form_helper
INFO - 2018-02-15 14:34:11 --> Form Validation Class Initialized
INFO - 2018-02-15 14:34:11 --> Model Class Initialized
INFO - 2018-02-15 14:34:11 --> Controller Class Initialized
INFO - 2018-02-15 14:34:11 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 14:34:11 --> Model Class Initialized
INFO - 2018-02-15 14:34:11 --> Model Class Initialized
INFO - 2018-02-15 14:34:11 --> Model Class Initialized
INFO - 2018-02-15 14:34:11 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-15 14:34:11 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-15 14:34:11 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-15 14:34:11 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-15 14:34:11 --> File loaded: /var/www/html/project/radio/application/views/tracks/index.php
INFO - 2018-02-15 14:34:11 --> Final output sent to browser
DEBUG - 2018-02-15 14:34:11 --> Total execution time: 0.0064
INFO - 2018-02-15 14:34:11 --> Config Class Initialized
INFO - 2018-02-15 14:34:11 --> Hooks Class Initialized
DEBUG - 2018-02-15 14:34:11 --> UTF-8 Support Enabled
INFO - 2018-02-15 14:34:11 --> Utf8 Class Initialized
INFO - 2018-02-15 14:34:11 --> URI Class Initialized
INFO - 2018-02-15 14:34:11 --> Router Class Initialized
INFO - 2018-02-15 14:34:11 --> Output Class Initialized
INFO - 2018-02-15 14:34:11 --> Security Class Initialized
DEBUG - 2018-02-15 14:34:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 14:34:11 --> Input Class Initialized
INFO - 2018-02-15 14:34:11 --> Language Class Initialized
INFO - 2018-02-15 14:34:11 --> Loader Class Initialized
INFO - 2018-02-15 14:34:11 --> Helper loaded: url_helper
INFO - 2018-02-15 14:34:11 --> Helper loaded: file_helper
INFO - 2018-02-15 14:34:11 --> Helper loaded: email_helper
INFO - 2018-02-15 14:34:11 --> Helper loaded: common_helper
INFO - 2018-02-15 14:34:11 --> Database Driver Class Initialized
DEBUG - 2018-02-15 14:34:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 14:34:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 14:34:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 14:34:11 --> Pagination Class Initialized
INFO - 2018-02-15 14:34:11 --> Helper loaded: form_helper
INFO - 2018-02-15 14:34:11 --> Form Validation Class Initialized
INFO - 2018-02-15 14:34:11 --> Model Class Initialized
INFO - 2018-02-15 14:34:11 --> Controller Class Initialized
INFO - 2018-02-15 14:34:11 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 14:34:11 --> Model Class Initialized
INFO - 2018-02-15 14:34:11 --> Model Class Initialized
INFO - 2018-02-15 14:34:11 --> Model Class Initialized
INFO - 2018-02-15 14:34:29 --> Config Class Initialized
INFO - 2018-02-15 14:34:29 --> Hooks Class Initialized
DEBUG - 2018-02-15 14:34:29 --> UTF-8 Support Enabled
INFO - 2018-02-15 14:34:29 --> Utf8 Class Initialized
INFO - 2018-02-15 14:34:29 --> URI Class Initialized
INFO - 2018-02-15 14:34:29 --> Router Class Initialized
INFO - 2018-02-15 14:34:29 --> Output Class Initialized
INFO - 2018-02-15 14:34:29 --> Security Class Initialized
DEBUG - 2018-02-15 14:34:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 14:34:29 --> Input Class Initialized
INFO - 2018-02-15 14:34:29 --> Language Class Initialized
INFO - 2018-02-15 14:34:29 --> Loader Class Initialized
INFO - 2018-02-15 14:34:29 --> Helper loaded: url_helper
INFO - 2018-02-15 14:34:29 --> Helper loaded: file_helper
INFO - 2018-02-15 14:34:29 --> Helper loaded: email_helper
INFO - 2018-02-15 14:34:29 --> Helper loaded: common_helper
INFO - 2018-02-15 14:34:29 --> Database Driver Class Initialized
DEBUG - 2018-02-15 14:34:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 14:34:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 14:34:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 14:34:29 --> Pagination Class Initialized
INFO - 2018-02-15 14:34:29 --> Helper loaded: form_helper
INFO - 2018-02-15 14:34:29 --> Form Validation Class Initialized
INFO - 2018-02-15 14:34:29 --> Model Class Initialized
INFO - 2018-02-15 14:34:29 --> Controller Class Initialized
INFO - 2018-02-15 14:34:29 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 14:34:29 --> Model Class Initialized
INFO - 2018-02-15 14:34:29 --> Model Class Initialized
INFO - 2018-02-15 14:34:29 --> Model Class Initialized
INFO - 2018-02-15 14:34:29 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-15 14:34:29 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-15 14:34:29 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-15 14:34:29 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-15 14:34:29 --> File loaded: /var/www/html/project/radio/application/views/tracks/index.php
INFO - 2018-02-15 14:34:29 --> Final output sent to browser
DEBUG - 2018-02-15 14:34:29 --> Total execution time: 0.0098
INFO - 2018-02-15 14:34:29 --> Config Class Initialized
INFO - 2018-02-15 14:34:29 --> Hooks Class Initialized
DEBUG - 2018-02-15 14:34:29 --> UTF-8 Support Enabled
INFO - 2018-02-15 14:34:29 --> Utf8 Class Initialized
INFO - 2018-02-15 14:34:29 --> URI Class Initialized
INFO - 2018-02-15 14:34:29 --> Router Class Initialized
INFO - 2018-02-15 14:34:29 --> Output Class Initialized
INFO - 2018-02-15 14:34:29 --> Security Class Initialized
DEBUG - 2018-02-15 14:34:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 14:34:29 --> Input Class Initialized
INFO - 2018-02-15 14:34:29 --> Language Class Initialized
INFO - 2018-02-15 14:34:29 --> Loader Class Initialized
INFO - 2018-02-15 14:34:29 --> Helper loaded: url_helper
INFO - 2018-02-15 14:34:29 --> Helper loaded: file_helper
INFO - 2018-02-15 14:34:29 --> Helper loaded: email_helper
INFO - 2018-02-15 14:34:29 --> Helper loaded: common_helper
INFO - 2018-02-15 14:34:29 --> Database Driver Class Initialized
DEBUG - 2018-02-15 14:34:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 14:34:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 14:34:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 14:34:29 --> Pagination Class Initialized
INFO - 2018-02-15 14:34:29 --> Helper loaded: form_helper
INFO - 2018-02-15 14:34:29 --> Form Validation Class Initialized
INFO - 2018-02-15 14:34:29 --> Model Class Initialized
INFO - 2018-02-15 14:34:29 --> Controller Class Initialized
INFO - 2018-02-15 14:34:29 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 14:34:29 --> Model Class Initialized
INFO - 2018-02-15 14:34:29 --> Model Class Initialized
INFO - 2018-02-15 14:34:29 --> Model Class Initialized
INFO - 2018-02-15 14:34:32 --> Config Class Initialized
INFO - 2018-02-15 14:34:32 --> Hooks Class Initialized
DEBUG - 2018-02-15 14:34:32 --> UTF-8 Support Enabled
INFO - 2018-02-15 14:34:32 --> Utf8 Class Initialized
INFO - 2018-02-15 14:34:32 --> URI Class Initialized
INFO - 2018-02-15 14:34:32 --> Router Class Initialized
INFO - 2018-02-15 14:34:32 --> Output Class Initialized
INFO - 2018-02-15 14:34:32 --> Security Class Initialized
DEBUG - 2018-02-15 14:34:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 14:34:32 --> Input Class Initialized
INFO - 2018-02-15 14:34:32 --> Language Class Initialized
INFO - 2018-02-15 14:34:32 --> Loader Class Initialized
INFO - 2018-02-15 14:34:32 --> Helper loaded: url_helper
INFO - 2018-02-15 14:34:32 --> Helper loaded: file_helper
INFO - 2018-02-15 14:34:32 --> Helper loaded: email_helper
INFO - 2018-02-15 14:34:32 --> Helper loaded: common_helper
INFO - 2018-02-15 14:34:32 --> Database Driver Class Initialized
DEBUG - 2018-02-15 14:34:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 14:34:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 14:34:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 14:34:32 --> Pagination Class Initialized
INFO - 2018-02-15 14:34:32 --> Helper loaded: form_helper
INFO - 2018-02-15 14:34:32 --> Form Validation Class Initialized
INFO - 2018-02-15 14:34:32 --> Model Class Initialized
INFO - 2018-02-15 14:34:32 --> Controller Class Initialized
INFO - 2018-02-15 14:34:32 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 14:34:32 --> Model Class Initialized
INFO - 2018-02-15 14:34:32 --> Model Class Initialized
INFO - 2018-02-15 14:34:32 --> Model Class Initialized
INFO - 2018-02-15 14:34:32 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-15 14:34:32 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-15 14:34:32 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-15 14:34:32 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-15 14:34:32 --> File loaded: /var/www/html/project/radio/application/views/tracks/index.php
INFO - 2018-02-15 14:34:32 --> Final output sent to browser
DEBUG - 2018-02-15 14:34:32 --> Total execution time: 0.0053
INFO - 2018-02-15 14:36:22 --> Config Class Initialized
INFO - 2018-02-15 14:36:22 --> Hooks Class Initialized
DEBUG - 2018-02-15 14:36:22 --> UTF-8 Support Enabled
INFO - 2018-02-15 14:36:22 --> Utf8 Class Initialized
INFO - 2018-02-15 14:36:22 --> URI Class Initialized
INFO - 2018-02-15 14:36:22 --> Router Class Initialized
INFO - 2018-02-15 14:36:22 --> Output Class Initialized
INFO - 2018-02-15 14:36:22 --> Security Class Initialized
DEBUG - 2018-02-15 14:36:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 14:36:22 --> Input Class Initialized
INFO - 2018-02-15 14:36:22 --> Language Class Initialized
INFO - 2018-02-15 14:36:22 --> Loader Class Initialized
INFO - 2018-02-15 14:36:22 --> Helper loaded: url_helper
INFO - 2018-02-15 14:36:22 --> Helper loaded: file_helper
INFO - 2018-02-15 14:36:22 --> Helper loaded: email_helper
INFO - 2018-02-15 14:36:22 --> Helper loaded: common_helper
INFO - 2018-02-15 14:36:22 --> Database Driver Class Initialized
DEBUG - 2018-02-15 14:36:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 14:36:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 14:36:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 14:36:22 --> Pagination Class Initialized
INFO - 2018-02-15 14:36:22 --> Helper loaded: form_helper
INFO - 2018-02-15 14:36:22 --> Form Validation Class Initialized
INFO - 2018-02-15 14:36:22 --> Model Class Initialized
INFO - 2018-02-15 14:36:22 --> Controller Class Initialized
INFO - 2018-02-15 14:36:22 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 14:36:22 --> Model Class Initialized
INFO - 2018-02-15 14:36:22 --> Model Class Initialized
INFO - 2018-02-15 14:36:22 --> Model Class Initialized
INFO - 2018-02-15 14:36:22 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-15 14:36:22 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-15 14:36:22 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-15 14:36:22 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-15 14:36:22 --> File loaded: /var/www/html/project/radio/application/views/tracks/index.php
INFO - 2018-02-15 14:36:22 --> Final output sent to browser
DEBUG - 2018-02-15 14:36:22 --> Total execution time: 0.0084
INFO - 2018-02-15 14:36:23 --> Config Class Initialized
INFO - 2018-02-15 14:36:23 --> Hooks Class Initialized
DEBUG - 2018-02-15 14:36:23 --> UTF-8 Support Enabled
INFO - 2018-02-15 14:36:23 --> Utf8 Class Initialized
INFO - 2018-02-15 14:36:23 --> URI Class Initialized
INFO - 2018-02-15 14:36:23 --> Router Class Initialized
INFO - 2018-02-15 14:36:23 --> Output Class Initialized
INFO - 2018-02-15 14:36:23 --> Security Class Initialized
DEBUG - 2018-02-15 14:36:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 14:36:23 --> Input Class Initialized
INFO - 2018-02-15 14:36:23 --> Language Class Initialized
INFO - 2018-02-15 14:36:23 --> Loader Class Initialized
INFO - 2018-02-15 14:36:23 --> Helper loaded: url_helper
INFO - 2018-02-15 14:36:23 --> Helper loaded: file_helper
INFO - 2018-02-15 14:36:23 --> Helper loaded: email_helper
INFO - 2018-02-15 14:36:23 --> Helper loaded: common_helper
INFO - 2018-02-15 14:36:23 --> Database Driver Class Initialized
DEBUG - 2018-02-15 14:36:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 14:36:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 14:36:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 14:36:23 --> Pagination Class Initialized
INFO - 2018-02-15 14:36:23 --> Helper loaded: form_helper
INFO - 2018-02-15 14:36:23 --> Form Validation Class Initialized
INFO - 2018-02-15 14:36:23 --> Model Class Initialized
INFO - 2018-02-15 14:36:23 --> Controller Class Initialized
INFO - 2018-02-15 14:36:23 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 14:36:23 --> Model Class Initialized
INFO - 2018-02-15 14:36:23 --> Model Class Initialized
INFO - 2018-02-15 14:36:23 --> Model Class Initialized
INFO - 2018-02-15 14:37:56 --> Config Class Initialized
INFO - 2018-02-15 14:37:56 --> Hooks Class Initialized
DEBUG - 2018-02-15 14:37:56 --> UTF-8 Support Enabled
INFO - 2018-02-15 14:37:56 --> Utf8 Class Initialized
INFO - 2018-02-15 14:37:56 --> URI Class Initialized
INFO - 2018-02-15 14:37:56 --> Router Class Initialized
INFO - 2018-02-15 14:37:56 --> Output Class Initialized
INFO - 2018-02-15 14:37:56 --> Security Class Initialized
DEBUG - 2018-02-15 14:37:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 14:37:56 --> Input Class Initialized
INFO - 2018-02-15 14:37:56 --> Language Class Initialized
INFO - 2018-02-15 14:37:56 --> Loader Class Initialized
INFO - 2018-02-15 14:37:56 --> Helper loaded: url_helper
INFO - 2018-02-15 14:37:56 --> Helper loaded: file_helper
INFO - 2018-02-15 14:37:56 --> Helper loaded: email_helper
INFO - 2018-02-15 14:37:56 --> Helper loaded: common_helper
INFO - 2018-02-15 14:37:56 --> Database Driver Class Initialized
DEBUG - 2018-02-15 14:37:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 14:37:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 14:37:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 14:37:56 --> Pagination Class Initialized
INFO - 2018-02-15 14:37:56 --> Helper loaded: form_helper
INFO - 2018-02-15 14:37:56 --> Form Validation Class Initialized
INFO - 2018-02-15 14:37:56 --> Model Class Initialized
INFO - 2018-02-15 14:37:56 --> Controller Class Initialized
INFO - 2018-02-15 14:37:56 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 14:37:56 --> Model Class Initialized
INFO - 2018-02-15 14:37:56 --> Model Class Initialized
INFO - 2018-02-15 14:37:56 --> Model Class Initialized
INFO - 2018-02-15 14:37:56 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-15 14:37:56 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-15 14:37:56 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-15 14:37:56 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-15 14:37:56 --> File loaded: /var/www/html/project/radio/application/views/tracks/index.php
INFO - 2018-02-15 14:37:56 --> Final output sent to browser
DEBUG - 2018-02-15 14:37:56 --> Total execution time: 0.0076
INFO - 2018-02-15 14:37:56 --> Config Class Initialized
INFO - 2018-02-15 14:37:56 --> Hooks Class Initialized
DEBUG - 2018-02-15 14:37:56 --> UTF-8 Support Enabled
INFO - 2018-02-15 14:37:56 --> Utf8 Class Initialized
INFO - 2018-02-15 14:37:56 --> URI Class Initialized
INFO - 2018-02-15 14:37:56 --> Router Class Initialized
INFO - 2018-02-15 14:37:56 --> Output Class Initialized
INFO - 2018-02-15 14:37:56 --> Security Class Initialized
DEBUG - 2018-02-15 14:37:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 14:37:56 --> Input Class Initialized
INFO - 2018-02-15 14:37:56 --> Language Class Initialized
INFO - 2018-02-15 14:37:56 --> Loader Class Initialized
INFO - 2018-02-15 14:37:56 --> Helper loaded: url_helper
INFO - 2018-02-15 14:37:56 --> Helper loaded: file_helper
INFO - 2018-02-15 14:37:56 --> Helper loaded: email_helper
INFO - 2018-02-15 14:37:56 --> Helper loaded: common_helper
INFO - 2018-02-15 14:37:56 --> Database Driver Class Initialized
DEBUG - 2018-02-15 14:37:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 14:37:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 14:37:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 14:37:56 --> Pagination Class Initialized
INFO - 2018-02-15 14:37:56 --> Helper loaded: form_helper
INFO - 2018-02-15 14:37:56 --> Form Validation Class Initialized
INFO - 2018-02-15 14:37:56 --> Model Class Initialized
INFO - 2018-02-15 14:37:56 --> Controller Class Initialized
INFO - 2018-02-15 14:37:56 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 14:37:56 --> Model Class Initialized
INFO - 2018-02-15 14:37:56 --> Model Class Initialized
INFO - 2018-02-15 14:37:56 --> Model Class Initialized
INFO - 2018-02-15 14:40:37 --> Config Class Initialized
INFO - 2018-02-15 14:40:37 --> Hooks Class Initialized
DEBUG - 2018-02-15 14:40:37 --> UTF-8 Support Enabled
INFO - 2018-02-15 14:40:37 --> Utf8 Class Initialized
INFO - 2018-02-15 14:40:37 --> URI Class Initialized
INFO - 2018-02-15 14:40:37 --> Router Class Initialized
INFO - 2018-02-15 14:40:37 --> Output Class Initialized
INFO - 2018-02-15 14:40:37 --> Security Class Initialized
DEBUG - 2018-02-15 14:40:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 14:40:37 --> Input Class Initialized
INFO - 2018-02-15 14:40:37 --> Language Class Initialized
INFO - 2018-02-15 14:40:37 --> Loader Class Initialized
INFO - 2018-02-15 14:40:37 --> Helper loaded: url_helper
INFO - 2018-02-15 14:40:37 --> Helper loaded: file_helper
INFO - 2018-02-15 14:40:37 --> Helper loaded: email_helper
INFO - 2018-02-15 14:40:37 --> Helper loaded: common_helper
INFO - 2018-02-15 14:40:37 --> Database Driver Class Initialized
DEBUG - 2018-02-15 14:40:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 14:40:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 14:40:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 14:40:37 --> Pagination Class Initialized
INFO - 2018-02-15 14:40:37 --> Helper loaded: form_helper
INFO - 2018-02-15 14:40:37 --> Form Validation Class Initialized
INFO - 2018-02-15 14:40:37 --> Model Class Initialized
INFO - 2018-02-15 14:40:37 --> Controller Class Initialized
INFO - 2018-02-15 14:40:37 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 14:40:37 --> Model Class Initialized
INFO - 2018-02-15 14:40:37 --> Model Class Initialized
INFO - 2018-02-15 14:40:37 --> Model Class Initialized
INFO - 2018-02-15 14:40:37 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-15 14:40:37 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-15 14:40:37 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-15 14:40:37 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-15 14:40:37 --> File loaded: /var/www/html/project/radio/application/views/tracks/index.php
INFO - 2018-02-15 14:40:37 --> Final output sent to browser
DEBUG - 2018-02-15 14:40:37 --> Total execution time: 0.0044
INFO - 2018-02-15 14:40:37 --> Config Class Initialized
INFO - 2018-02-15 14:40:37 --> Hooks Class Initialized
DEBUG - 2018-02-15 14:40:37 --> UTF-8 Support Enabled
INFO - 2018-02-15 14:40:37 --> Utf8 Class Initialized
INFO - 2018-02-15 14:40:37 --> URI Class Initialized
INFO - 2018-02-15 14:40:37 --> Router Class Initialized
INFO - 2018-02-15 14:40:37 --> Output Class Initialized
INFO - 2018-02-15 14:40:37 --> Security Class Initialized
DEBUG - 2018-02-15 14:40:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 14:40:37 --> Input Class Initialized
INFO - 2018-02-15 14:40:37 --> Language Class Initialized
INFO - 2018-02-15 14:40:37 --> Loader Class Initialized
INFO - 2018-02-15 14:40:37 --> Helper loaded: url_helper
INFO - 2018-02-15 14:40:37 --> Helper loaded: file_helper
INFO - 2018-02-15 14:40:37 --> Helper loaded: email_helper
INFO - 2018-02-15 14:40:37 --> Helper loaded: common_helper
INFO - 2018-02-15 14:40:37 --> Database Driver Class Initialized
DEBUG - 2018-02-15 14:40:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 14:40:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 14:40:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 14:40:37 --> Pagination Class Initialized
INFO - 2018-02-15 14:40:37 --> Helper loaded: form_helper
INFO - 2018-02-15 14:40:37 --> Form Validation Class Initialized
INFO - 2018-02-15 14:40:37 --> Model Class Initialized
INFO - 2018-02-15 14:40:37 --> Controller Class Initialized
INFO - 2018-02-15 14:40:37 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 14:40:37 --> Model Class Initialized
INFO - 2018-02-15 14:40:37 --> Model Class Initialized
INFO - 2018-02-15 14:40:37 --> Model Class Initialized
INFO - 2018-02-15 14:44:19 --> Config Class Initialized
INFO - 2018-02-15 14:44:19 --> Hooks Class Initialized
DEBUG - 2018-02-15 14:44:19 --> UTF-8 Support Enabled
INFO - 2018-02-15 14:44:19 --> Utf8 Class Initialized
INFO - 2018-02-15 14:44:19 --> URI Class Initialized
INFO - 2018-02-15 14:44:19 --> Router Class Initialized
INFO - 2018-02-15 14:44:19 --> Output Class Initialized
INFO - 2018-02-15 14:44:19 --> Security Class Initialized
DEBUG - 2018-02-15 14:44:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 14:44:19 --> Input Class Initialized
INFO - 2018-02-15 14:44:19 --> Language Class Initialized
INFO - 2018-02-15 14:44:19 --> Loader Class Initialized
INFO - 2018-02-15 14:44:19 --> Helper loaded: url_helper
INFO - 2018-02-15 14:44:19 --> Helper loaded: file_helper
INFO - 2018-02-15 14:44:19 --> Helper loaded: email_helper
INFO - 2018-02-15 14:44:19 --> Helper loaded: common_helper
INFO - 2018-02-15 14:44:19 --> Database Driver Class Initialized
DEBUG - 2018-02-15 14:44:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 14:44:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 14:44:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 14:44:19 --> Pagination Class Initialized
INFO - 2018-02-15 14:44:20 --> Helper loaded: form_helper
INFO - 2018-02-15 14:44:20 --> Form Validation Class Initialized
INFO - 2018-02-15 14:44:20 --> Model Class Initialized
INFO - 2018-02-15 14:44:20 --> Controller Class Initialized
INFO - 2018-02-15 14:44:20 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 14:44:20 --> Model Class Initialized
INFO - 2018-02-15 14:44:20 --> Model Class Initialized
INFO - 2018-02-15 14:44:20 --> Model Class Initialized
INFO - 2018-02-15 14:44:20 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-15 14:44:20 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-15 14:44:20 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-15 14:44:20 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-15 14:44:20 --> File loaded: /var/www/html/project/radio/application/views/tracks/index.php
INFO - 2018-02-15 14:44:20 --> Final output sent to browser
DEBUG - 2018-02-15 14:44:20 --> Total execution time: 0.0059
INFO - 2018-02-15 14:44:20 --> Config Class Initialized
INFO - 2018-02-15 14:44:20 --> Hooks Class Initialized
DEBUG - 2018-02-15 14:44:20 --> UTF-8 Support Enabled
INFO - 2018-02-15 14:44:20 --> Utf8 Class Initialized
INFO - 2018-02-15 14:44:20 --> URI Class Initialized
INFO - 2018-02-15 14:44:20 --> Router Class Initialized
INFO - 2018-02-15 14:44:20 --> Output Class Initialized
INFO - 2018-02-15 14:44:20 --> Security Class Initialized
DEBUG - 2018-02-15 14:44:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 14:44:20 --> Input Class Initialized
INFO - 2018-02-15 14:44:20 --> Language Class Initialized
INFO - 2018-02-15 14:44:20 --> Loader Class Initialized
INFO - 2018-02-15 14:44:20 --> Helper loaded: url_helper
INFO - 2018-02-15 14:44:20 --> Helper loaded: file_helper
INFO - 2018-02-15 14:44:20 --> Helper loaded: email_helper
INFO - 2018-02-15 14:44:20 --> Helper loaded: common_helper
INFO - 2018-02-15 14:44:20 --> Database Driver Class Initialized
DEBUG - 2018-02-15 14:44:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 14:44:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 14:44:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 14:44:20 --> Pagination Class Initialized
INFO - 2018-02-15 14:44:20 --> Helper loaded: form_helper
INFO - 2018-02-15 14:44:20 --> Form Validation Class Initialized
INFO - 2018-02-15 14:44:20 --> Model Class Initialized
INFO - 2018-02-15 14:44:20 --> Controller Class Initialized
INFO - 2018-02-15 14:44:20 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 14:44:20 --> Model Class Initialized
INFO - 2018-02-15 14:44:20 --> Model Class Initialized
INFO - 2018-02-15 14:44:20 --> Model Class Initialized
INFO - 2018-02-15 14:45:15 --> Config Class Initialized
INFO - 2018-02-15 14:45:15 --> Hooks Class Initialized
DEBUG - 2018-02-15 14:45:15 --> UTF-8 Support Enabled
INFO - 2018-02-15 14:45:15 --> Utf8 Class Initialized
INFO - 2018-02-15 14:45:15 --> URI Class Initialized
INFO - 2018-02-15 14:45:15 --> Router Class Initialized
INFO - 2018-02-15 14:45:15 --> Output Class Initialized
INFO - 2018-02-15 14:45:15 --> Security Class Initialized
DEBUG - 2018-02-15 14:45:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 14:45:15 --> Input Class Initialized
INFO - 2018-02-15 14:45:15 --> Language Class Initialized
INFO - 2018-02-15 14:45:15 --> Loader Class Initialized
INFO - 2018-02-15 14:45:15 --> Helper loaded: url_helper
INFO - 2018-02-15 14:45:15 --> Helper loaded: file_helper
INFO - 2018-02-15 14:45:15 --> Helper loaded: email_helper
INFO - 2018-02-15 14:45:15 --> Helper loaded: common_helper
INFO - 2018-02-15 14:45:15 --> Database Driver Class Initialized
DEBUG - 2018-02-15 14:45:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 14:45:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 14:45:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 14:45:15 --> Pagination Class Initialized
INFO - 2018-02-15 14:45:15 --> Helper loaded: form_helper
INFO - 2018-02-15 14:45:15 --> Form Validation Class Initialized
INFO - 2018-02-15 14:45:15 --> Model Class Initialized
INFO - 2018-02-15 14:45:15 --> Controller Class Initialized
INFO - 2018-02-15 14:45:15 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 14:45:15 --> Model Class Initialized
INFO - 2018-02-15 14:45:15 --> Model Class Initialized
INFO - 2018-02-15 14:45:15 --> Model Class Initialized
INFO - 2018-02-15 14:45:15 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-15 14:45:15 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-15 14:45:15 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-15 14:45:15 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-15 14:45:15 --> File loaded: /var/www/html/project/radio/application/views/tracks/index.php
INFO - 2018-02-15 14:45:15 --> Final output sent to browser
DEBUG - 2018-02-15 14:45:15 --> Total execution time: 0.0057
INFO - 2018-02-15 14:45:16 --> Config Class Initialized
INFO - 2018-02-15 14:45:16 --> Hooks Class Initialized
DEBUG - 2018-02-15 14:45:16 --> UTF-8 Support Enabled
INFO - 2018-02-15 14:45:16 --> Utf8 Class Initialized
INFO - 2018-02-15 14:45:16 --> URI Class Initialized
INFO - 2018-02-15 14:45:16 --> Router Class Initialized
INFO - 2018-02-15 14:45:16 --> Output Class Initialized
INFO - 2018-02-15 14:45:16 --> Security Class Initialized
DEBUG - 2018-02-15 14:45:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 14:45:16 --> Input Class Initialized
INFO - 2018-02-15 14:45:16 --> Language Class Initialized
INFO - 2018-02-15 14:45:16 --> Loader Class Initialized
INFO - 2018-02-15 14:45:16 --> Helper loaded: url_helper
INFO - 2018-02-15 14:45:16 --> Helper loaded: file_helper
INFO - 2018-02-15 14:45:16 --> Helper loaded: email_helper
INFO - 2018-02-15 14:45:16 --> Helper loaded: common_helper
INFO - 2018-02-15 14:45:16 --> Database Driver Class Initialized
DEBUG - 2018-02-15 14:45:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 14:45:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 14:45:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 14:45:16 --> Pagination Class Initialized
INFO - 2018-02-15 14:45:16 --> Helper loaded: form_helper
INFO - 2018-02-15 14:45:16 --> Form Validation Class Initialized
INFO - 2018-02-15 14:45:16 --> Model Class Initialized
INFO - 2018-02-15 14:45:16 --> Controller Class Initialized
INFO - 2018-02-15 14:45:16 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 14:45:16 --> Model Class Initialized
INFO - 2018-02-15 14:45:16 --> Model Class Initialized
INFO - 2018-02-15 14:45:16 --> Model Class Initialized
INFO - 2018-02-15 14:45:24 --> Config Class Initialized
INFO - 2018-02-15 14:45:24 --> Hooks Class Initialized
DEBUG - 2018-02-15 14:45:24 --> UTF-8 Support Enabled
INFO - 2018-02-15 14:45:24 --> Utf8 Class Initialized
INFO - 2018-02-15 14:45:24 --> URI Class Initialized
INFO - 2018-02-15 14:45:24 --> Router Class Initialized
INFO - 2018-02-15 14:45:24 --> Output Class Initialized
INFO - 2018-02-15 14:45:24 --> Security Class Initialized
DEBUG - 2018-02-15 14:45:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 14:45:24 --> Input Class Initialized
INFO - 2018-02-15 14:45:24 --> Language Class Initialized
INFO - 2018-02-15 14:45:24 --> Loader Class Initialized
INFO - 2018-02-15 14:45:24 --> Helper loaded: url_helper
INFO - 2018-02-15 14:45:24 --> Helper loaded: file_helper
INFO - 2018-02-15 14:45:24 --> Helper loaded: email_helper
INFO - 2018-02-15 14:45:24 --> Helper loaded: common_helper
INFO - 2018-02-15 14:45:24 --> Database Driver Class Initialized
DEBUG - 2018-02-15 14:45:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 14:45:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 14:45:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 14:45:24 --> Pagination Class Initialized
INFO - 2018-02-15 14:45:24 --> Helper loaded: form_helper
INFO - 2018-02-15 14:45:24 --> Form Validation Class Initialized
INFO - 2018-02-15 14:45:24 --> Model Class Initialized
INFO - 2018-02-15 14:45:24 --> Controller Class Initialized
INFO - 2018-02-15 14:45:24 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 14:45:24 --> Model Class Initialized
INFO - 2018-02-15 14:45:24 --> Model Class Initialized
INFO - 2018-02-15 14:45:24 --> Model Class Initialized
INFO - 2018-02-15 14:45:24 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-15 14:45:24 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-15 14:45:24 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-15 14:45:24 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-15 14:45:24 --> File loaded: /var/www/html/project/radio/application/views/tracks/index.php
INFO - 2018-02-15 14:45:24 --> Final output sent to browser
DEBUG - 2018-02-15 14:45:24 --> Total execution time: 0.0078
INFO - 2018-02-15 14:45:24 --> Config Class Initialized
INFO - 2018-02-15 14:45:24 --> Hooks Class Initialized
DEBUG - 2018-02-15 14:45:24 --> UTF-8 Support Enabled
INFO - 2018-02-15 14:45:24 --> Utf8 Class Initialized
INFO - 2018-02-15 14:45:24 --> URI Class Initialized
INFO - 2018-02-15 14:45:24 --> Router Class Initialized
INFO - 2018-02-15 14:45:24 --> Output Class Initialized
INFO - 2018-02-15 14:45:24 --> Security Class Initialized
DEBUG - 2018-02-15 14:45:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 14:45:24 --> Input Class Initialized
INFO - 2018-02-15 14:45:24 --> Language Class Initialized
INFO - 2018-02-15 14:45:24 --> Loader Class Initialized
INFO - 2018-02-15 14:45:24 --> Helper loaded: url_helper
INFO - 2018-02-15 14:45:24 --> Helper loaded: file_helper
INFO - 2018-02-15 14:45:24 --> Helper loaded: email_helper
INFO - 2018-02-15 14:45:24 --> Helper loaded: common_helper
INFO - 2018-02-15 14:45:24 --> Database Driver Class Initialized
DEBUG - 2018-02-15 14:45:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 14:45:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 14:45:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 14:45:24 --> Pagination Class Initialized
INFO - 2018-02-15 14:45:24 --> Helper loaded: form_helper
INFO - 2018-02-15 14:45:24 --> Form Validation Class Initialized
INFO - 2018-02-15 14:45:24 --> Model Class Initialized
INFO - 2018-02-15 14:45:24 --> Controller Class Initialized
INFO - 2018-02-15 14:45:24 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 14:45:24 --> Model Class Initialized
INFO - 2018-02-15 14:45:24 --> Model Class Initialized
INFO - 2018-02-15 14:45:24 --> Model Class Initialized
INFO - 2018-02-15 14:45:39 --> Config Class Initialized
INFO - 2018-02-15 14:45:39 --> Hooks Class Initialized
DEBUG - 2018-02-15 14:45:39 --> UTF-8 Support Enabled
INFO - 2018-02-15 14:45:39 --> Utf8 Class Initialized
INFO - 2018-02-15 14:45:39 --> URI Class Initialized
INFO - 2018-02-15 14:45:39 --> Router Class Initialized
INFO - 2018-02-15 14:45:39 --> Output Class Initialized
INFO - 2018-02-15 14:45:39 --> Security Class Initialized
DEBUG - 2018-02-15 14:45:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 14:45:39 --> Input Class Initialized
INFO - 2018-02-15 14:45:39 --> Language Class Initialized
INFO - 2018-02-15 14:45:39 --> Loader Class Initialized
INFO - 2018-02-15 14:45:39 --> Helper loaded: url_helper
INFO - 2018-02-15 14:45:39 --> Helper loaded: file_helper
INFO - 2018-02-15 14:45:39 --> Helper loaded: email_helper
INFO - 2018-02-15 14:45:39 --> Helper loaded: common_helper
INFO - 2018-02-15 14:45:39 --> Database Driver Class Initialized
DEBUG - 2018-02-15 14:45:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 14:45:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 14:45:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 14:45:39 --> Pagination Class Initialized
INFO - 2018-02-15 14:45:39 --> Helper loaded: form_helper
INFO - 2018-02-15 14:45:39 --> Form Validation Class Initialized
INFO - 2018-02-15 14:45:39 --> Model Class Initialized
INFO - 2018-02-15 14:45:39 --> Controller Class Initialized
INFO - 2018-02-15 14:45:39 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 14:45:39 --> Model Class Initialized
INFO - 2018-02-15 14:45:39 --> Model Class Initialized
INFO - 2018-02-15 14:45:39 --> Model Class Initialized
INFO - 2018-02-15 14:45:39 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-15 14:45:39 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-15 14:45:39 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-15 14:45:39 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-15 14:45:39 --> File loaded: /var/www/html/project/radio/application/views/tracks/index.php
INFO - 2018-02-15 14:45:39 --> Final output sent to browser
DEBUG - 2018-02-15 14:45:39 --> Total execution time: 0.0067
INFO - 2018-02-15 14:45:39 --> Config Class Initialized
INFO - 2018-02-15 14:45:39 --> Hooks Class Initialized
DEBUG - 2018-02-15 14:45:39 --> UTF-8 Support Enabled
INFO - 2018-02-15 14:45:39 --> Utf8 Class Initialized
INFO - 2018-02-15 14:45:39 --> URI Class Initialized
INFO - 2018-02-15 14:45:39 --> Router Class Initialized
INFO - 2018-02-15 14:45:39 --> Output Class Initialized
INFO - 2018-02-15 14:45:39 --> Security Class Initialized
DEBUG - 2018-02-15 14:45:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 14:45:39 --> Input Class Initialized
INFO - 2018-02-15 14:45:39 --> Language Class Initialized
INFO - 2018-02-15 14:45:39 --> Loader Class Initialized
INFO - 2018-02-15 14:45:39 --> Helper loaded: url_helper
INFO - 2018-02-15 14:45:39 --> Helper loaded: file_helper
INFO - 2018-02-15 14:45:39 --> Helper loaded: email_helper
INFO - 2018-02-15 14:45:39 --> Helper loaded: common_helper
INFO - 2018-02-15 14:45:39 --> Database Driver Class Initialized
DEBUG - 2018-02-15 14:45:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 14:45:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 14:45:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 14:45:39 --> Pagination Class Initialized
INFO - 2018-02-15 14:45:39 --> Helper loaded: form_helper
INFO - 2018-02-15 14:45:39 --> Form Validation Class Initialized
INFO - 2018-02-15 14:45:39 --> Model Class Initialized
INFO - 2018-02-15 14:45:39 --> Controller Class Initialized
INFO - 2018-02-15 14:45:39 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 14:45:39 --> Model Class Initialized
INFO - 2018-02-15 14:45:39 --> Model Class Initialized
INFO - 2018-02-15 14:45:39 --> Model Class Initialized
INFO - 2018-02-15 14:46:06 --> Config Class Initialized
INFO - 2018-02-15 14:46:06 --> Hooks Class Initialized
DEBUG - 2018-02-15 14:46:06 --> UTF-8 Support Enabled
INFO - 2018-02-15 14:46:06 --> Utf8 Class Initialized
INFO - 2018-02-15 14:46:06 --> URI Class Initialized
INFO - 2018-02-15 14:46:06 --> Router Class Initialized
INFO - 2018-02-15 14:46:06 --> Output Class Initialized
INFO - 2018-02-15 14:46:06 --> Security Class Initialized
DEBUG - 2018-02-15 14:46:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 14:46:06 --> Input Class Initialized
INFO - 2018-02-15 14:46:06 --> Language Class Initialized
INFO - 2018-02-15 14:46:06 --> Loader Class Initialized
INFO - 2018-02-15 14:46:06 --> Helper loaded: url_helper
INFO - 2018-02-15 14:46:06 --> Helper loaded: file_helper
INFO - 2018-02-15 14:46:06 --> Helper loaded: email_helper
INFO - 2018-02-15 14:46:06 --> Helper loaded: common_helper
INFO - 2018-02-15 14:46:06 --> Database Driver Class Initialized
DEBUG - 2018-02-15 14:46:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 14:46:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 14:46:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 14:46:06 --> Pagination Class Initialized
INFO - 2018-02-15 14:46:06 --> Helper loaded: form_helper
INFO - 2018-02-15 14:46:06 --> Form Validation Class Initialized
INFO - 2018-02-15 14:46:06 --> Model Class Initialized
INFO - 2018-02-15 14:46:06 --> Controller Class Initialized
INFO - 2018-02-15 14:46:06 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 14:46:06 --> Model Class Initialized
INFO - 2018-02-15 14:46:06 --> Model Class Initialized
INFO - 2018-02-15 14:46:06 --> Model Class Initialized
INFO - 2018-02-15 14:46:06 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-15 14:46:06 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-15 14:46:06 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-15 14:46:06 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-15 14:46:06 --> File loaded: /var/www/html/project/radio/application/views/tracks/index.php
INFO - 2018-02-15 14:46:06 --> Final output sent to browser
DEBUG - 2018-02-15 14:46:06 --> Total execution time: 0.0093
INFO - 2018-02-15 14:46:06 --> Config Class Initialized
INFO - 2018-02-15 14:46:06 --> Hooks Class Initialized
DEBUG - 2018-02-15 14:46:06 --> UTF-8 Support Enabled
INFO - 2018-02-15 14:46:06 --> Utf8 Class Initialized
INFO - 2018-02-15 14:46:06 --> URI Class Initialized
INFO - 2018-02-15 14:46:06 --> Router Class Initialized
INFO - 2018-02-15 14:46:06 --> Output Class Initialized
INFO - 2018-02-15 14:46:06 --> Security Class Initialized
DEBUG - 2018-02-15 14:46:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 14:46:06 --> Input Class Initialized
INFO - 2018-02-15 14:46:06 --> Language Class Initialized
INFO - 2018-02-15 14:46:06 --> Loader Class Initialized
INFO - 2018-02-15 14:46:06 --> Helper loaded: url_helper
INFO - 2018-02-15 14:46:06 --> Helper loaded: file_helper
INFO - 2018-02-15 14:46:06 --> Helper loaded: email_helper
INFO - 2018-02-15 14:46:06 --> Helper loaded: common_helper
INFO - 2018-02-15 14:46:06 --> Database Driver Class Initialized
DEBUG - 2018-02-15 14:46:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 14:46:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 14:46:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 14:46:06 --> Pagination Class Initialized
INFO - 2018-02-15 14:46:06 --> Helper loaded: form_helper
INFO - 2018-02-15 14:46:06 --> Form Validation Class Initialized
INFO - 2018-02-15 14:46:06 --> Model Class Initialized
INFO - 2018-02-15 14:46:06 --> Controller Class Initialized
INFO - 2018-02-15 14:46:06 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 14:46:06 --> Model Class Initialized
INFO - 2018-02-15 14:46:06 --> Model Class Initialized
INFO - 2018-02-15 14:46:06 --> Model Class Initialized
INFO - 2018-02-15 14:46:10 --> Config Class Initialized
INFO - 2018-02-15 14:46:10 --> Hooks Class Initialized
DEBUG - 2018-02-15 14:46:10 --> UTF-8 Support Enabled
INFO - 2018-02-15 14:46:10 --> Utf8 Class Initialized
INFO - 2018-02-15 14:46:10 --> URI Class Initialized
INFO - 2018-02-15 14:46:10 --> Router Class Initialized
INFO - 2018-02-15 14:46:10 --> Output Class Initialized
INFO - 2018-02-15 14:46:10 --> Security Class Initialized
DEBUG - 2018-02-15 14:46:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 14:46:10 --> Input Class Initialized
INFO - 2018-02-15 14:46:10 --> Language Class Initialized
INFO - 2018-02-15 14:46:10 --> Loader Class Initialized
INFO - 2018-02-15 14:46:10 --> Helper loaded: url_helper
INFO - 2018-02-15 14:46:10 --> Helper loaded: file_helper
INFO - 2018-02-15 14:46:10 --> Helper loaded: email_helper
INFO - 2018-02-15 14:46:10 --> Helper loaded: common_helper
INFO - 2018-02-15 14:46:10 --> Database Driver Class Initialized
DEBUG - 2018-02-15 14:46:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 14:46:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 14:46:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 14:46:10 --> Pagination Class Initialized
INFO - 2018-02-15 14:46:10 --> Helper loaded: form_helper
INFO - 2018-02-15 14:46:10 --> Form Validation Class Initialized
INFO - 2018-02-15 14:46:10 --> Model Class Initialized
INFO - 2018-02-15 14:46:10 --> Controller Class Initialized
INFO - 2018-02-15 14:46:10 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 14:46:10 --> Model Class Initialized
INFO - 2018-02-15 14:46:10 --> Model Class Initialized
INFO - 2018-02-15 14:46:10 --> Model Class Initialized
INFO - 2018-02-15 14:46:11 --> Config Class Initialized
INFO - 2018-02-15 14:46:11 --> Hooks Class Initialized
DEBUG - 2018-02-15 14:46:11 --> UTF-8 Support Enabled
INFO - 2018-02-15 14:46:11 --> Utf8 Class Initialized
INFO - 2018-02-15 14:46:11 --> URI Class Initialized
INFO - 2018-02-15 14:46:11 --> Router Class Initialized
INFO - 2018-02-15 14:46:11 --> Output Class Initialized
INFO - 2018-02-15 14:46:11 --> Security Class Initialized
DEBUG - 2018-02-15 14:46:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 14:46:11 --> Input Class Initialized
INFO - 2018-02-15 14:46:11 --> Language Class Initialized
INFO - 2018-02-15 14:46:11 --> Loader Class Initialized
INFO - 2018-02-15 14:46:11 --> Helper loaded: url_helper
INFO - 2018-02-15 14:46:11 --> Helper loaded: file_helper
INFO - 2018-02-15 14:46:11 --> Helper loaded: email_helper
INFO - 2018-02-15 14:46:11 --> Helper loaded: common_helper
INFO - 2018-02-15 14:46:11 --> Database Driver Class Initialized
DEBUG - 2018-02-15 14:46:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 14:46:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 14:46:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 14:46:11 --> Pagination Class Initialized
INFO - 2018-02-15 14:46:11 --> Helper loaded: form_helper
INFO - 2018-02-15 14:46:11 --> Form Validation Class Initialized
INFO - 2018-02-15 14:46:11 --> Model Class Initialized
INFO - 2018-02-15 14:46:11 --> Controller Class Initialized
INFO - 2018-02-15 14:46:11 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 14:46:11 --> Model Class Initialized
INFO - 2018-02-15 14:46:11 --> Model Class Initialized
INFO - 2018-02-15 14:46:11 --> Model Class Initialized
INFO - 2018-02-15 14:46:12 --> Config Class Initialized
INFO - 2018-02-15 14:46:12 --> Hooks Class Initialized
DEBUG - 2018-02-15 14:46:12 --> UTF-8 Support Enabled
INFO - 2018-02-15 14:46:12 --> Utf8 Class Initialized
INFO - 2018-02-15 14:46:12 --> URI Class Initialized
INFO - 2018-02-15 14:46:12 --> Router Class Initialized
INFO - 2018-02-15 14:46:12 --> Output Class Initialized
INFO - 2018-02-15 14:46:12 --> Security Class Initialized
DEBUG - 2018-02-15 14:46:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 14:46:12 --> Input Class Initialized
INFO - 2018-02-15 14:46:12 --> Language Class Initialized
INFO - 2018-02-15 14:46:12 --> Loader Class Initialized
INFO - 2018-02-15 14:46:12 --> Helper loaded: url_helper
INFO - 2018-02-15 14:46:12 --> Helper loaded: file_helper
INFO - 2018-02-15 14:46:12 --> Helper loaded: email_helper
INFO - 2018-02-15 14:46:12 --> Helper loaded: common_helper
INFO - 2018-02-15 14:46:12 --> Database Driver Class Initialized
DEBUG - 2018-02-15 14:46:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 14:46:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 14:46:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 14:46:12 --> Pagination Class Initialized
INFO - 2018-02-15 14:46:12 --> Helper loaded: form_helper
INFO - 2018-02-15 14:46:12 --> Form Validation Class Initialized
INFO - 2018-02-15 14:46:12 --> Model Class Initialized
INFO - 2018-02-15 14:46:12 --> Controller Class Initialized
INFO - 2018-02-15 14:46:12 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 14:46:12 --> Model Class Initialized
INFO - 2018-02-15 14:46:12 --> Model Class Initialized
INFO - 2018-02-15 14:46:12 --> Model Class Initialized
INFO - 2018-02-15 14:46:14 --> Config Class Initialized
INFO - 2018-02-15 14:46:14 --> Hooks Class Initialized
DEBUG - 2018-02-15 14:46:14 --> UTF-8 Support Enabled
INFO - 2018-02-15 14:46:14 --> Utf8 Class Initialized
INFO - 2018-02-15 14:46:14 --> URI Class Initialized
INFO - 2018-02-15 14:46:14 --> Router Class Initialized
INFO - 2018-02-15 14:46:14 --> Output Class Initialized
INFO - 2018-02-15 14:46:14 --> Security Class Initialized
DEBUG - 2018-02-15 14:46:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 14:46:14 --> Input Class Initialized
INFO - 2018-02-15 14:46:14 --> Language Class Initialized
INFO - 2018-02-15 14:46:14 --> Loader Class Initialized
INFO - 2018-02-15 14:46:14 --> Helper loaded: url_helper
INFO - 2018-02-15 14:46:14 --> Helper loaded: file_helper
INFO - 2018-02-15 14:46:14 --> Helper loaded: email_helper
INFO - 2018-02-15 14:46:14 --> Helper loaded: common_helper
INFO - 2018-02-15 14:46:14 --> Database Driver Class Initialized
DEBUG - 2018-02-15 14:46:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 14:46:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 14:46:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 14:46:14 --> Pagination Class Initialized
INFO - 2018-02-15 14:46:14 --> Helper loaded: form_helper
INFO - 2018-02-15 14:46:14 --> Form Validation Class Initialized
INFO - 2018-02-15 14:46:14 --> Model Class Initialized
INFO - 2018-02-15 14:46:14 --> Controller Class Initialized
INFO - 2018-02-15 14:46:14 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 14:46:14 --> Model Class Initialized
INFO - 2018-02-15 14:46:14 --> Model Class Initialized
INFO - 2018-02-15 14:46:14 --> Model Class Initialized
INFO - 2018-02-15 14:46:15 --> Config Class Initialized
INFO - 2018-02-15 14:46:15 --> Hooks Class Initialized
DEBUG - 2018-02-15 14:46:15 --> UTF-8 Support Enabled
INFO - 2018-02-15 14:46:15 --> Utf8 Class Initialized
INFO - 2018-02-15 14:46:15 --> URI Class Initialized
INFO - 2018-02-15 14:46:15 --> Router Class Initialized
INFO - 2018-02-15 14:46:15 --> Output Class Initialized
INFO - 2018-02-15 14:46:15 --> Security Class Initialized
DEBUG - 2018-02-15 14:46:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 14:46:15 --> Input Class Initialized
INFO - 2018-02-15 14:46:15 --> Language Class Initialized
INFO - 2018-02-15 14:46:15 --> Loader Class Initialized
INFO - 2018-02-15 14:46:15 --> Helper loaded: url_helper
INFO - 2018-02-15 14:46:15 --> Helper loaded: file_helper
INFO - 2018-02-15 14:46:15 --> Helper loaded: email_helper
INFO - 2018-02-15 14:46:15 --> Helper loaded: common_helper
INFO - 2018-02-15 14:46:15 --> Database Driver Class Initialized
DEBUG - 2018-02-15 14:46:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 14:46:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 14:46:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 14:46:15 --> Pagination Class Initialized
INFO - 2018-02-15 14:46:15 --> Helper loaded: form_helper
INFO - 2018-02-15 14:46:15 --> Form Validation Class Initialized
INFO - 2018-02-15 14:46:15 --> Model Class Initialized
INFO - 2018-02-15 14:46:15 --> Controller Class Initialized
INFO - 2018-02-15 14:46:15 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 14:46:15 --> Model Class Initialized
INFO - 2018-02-15 14:46:15 --> Model Class Initialized
INFO - 2018-02-15 14:46:15 --> Model Class Initialized
INFO - 2018-02-15 14:46:15 --> Config Class Initialized
INFO - 2018-02-15 14:46:15 --> Hooks Class Initialized
DEBUG - 2018-02-15 14:46:15 --> UTF-8 Support Enabled
INFO - 2018-02-15 14:46:15 --> Utf8 Class Initialized
INFO - 2018-02-15 14:46:15 --> URI Class Initialized
INFO - 2018-02-15 14:46:15 --> Router Class Initialized
INFO - 2018-02-15 14:46:15 --> Output Class Initialized
INFO - 2018-02-15 14:46:15 --> Security Class Initialized
DEBUG - 2018-02-15 14:46:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 14:46:15 --> Input Class Initialized
INFO - 2018-02-15 14:46:15 --> Language Class Initialized
INFO - 2018-02-15 14:46:15 --> Loader Class Initialized
INFO - 2018-02-15 14:46:15 --> Helper loaded: url_helper
INFO - 2018-02-15 14:46:15 --> Helper loaded: file_helper
INFO - 2018-02-15 14:46:15 --> Helper loaded: email_helper
INFO - 2018-02-15 14:46:15 --> Helper loaded: common_helper
INFO - 2018-02-15 14:46:15 --> Database Driver Class Initialized
DEBUG - 2018-02-15 14:46:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 14:46:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 14:46:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 14:46:15 --> Pagination Class Initialized
INFO - 2018-02-15 14:46:15 --> Helper loaded: form_helper
INFO - 2018-02-15 14:46:15 --> Form Validation Class Initialized
INFO - 2018-02-15 14:46:15 --> Model Class Initialized
INFO - 2018-02-15 14:46:15 --> Controller Class Initialized
INFO - 2018-02-15 14:46:15 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 14:46:15 --> Model Class Initialized
INFO - 2018-02-15 14:46:15 --> Model Class Initialized
INFO - 2018-02-15 14:46:15 --> Model Class Initialized
INFO - 2018-02-15 14:46:16 --> Config Class Initialized
INFO - 2018-02-15 14:46:16 --> Hooks Class Initialized
DEBUG - 2018-02-15 14:46:16 --> UTF-8 Support Enabled
INFO - 2018-02-15 14:46:16 --> Utf8 Class Initialized
INFO - 2018-02-15 14:46:16 --> URI Class Initialized
INFO - 2018-02-15 14:46:16 --> Router Class Initialized
INFO - 2018-02-15 14:46:16 --> Output Class Initialized
INFO - 2018-02-15 14:46:16 --> Security Class Initialized
DEBUG - 2018-02-15 14:46:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 14:46:16 --> Input Class Initialized
INFO - 2018-02-15 14:46:16 --> Language Class Initialized
INFO - 2018-02-15 14:46:16 --> Loader Class Initialized
INFO - 2018-02-15 14:46:16 --> Helper loaded: url_helper
INFO - 2018-02-15 14:46:16 --> Helper loaded: file_helper
INFO - 2018-02-15 14:46:16 --> Helper loaded: email_helper
INFO - 2018-02-15 14:46:16 --> Helper loaded: common_helper
INFO - 2018-02-15 14:46:16 --> Database Driver Class Initialized
DEBUG - 2018-02-15 14:46:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 14:46:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 14:46:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 14:46:16 --> Pagination Class Initialized
INFO - 2018-02-15 14:46:16 --> Helper loaded: form_helper
INFO - 2018-02-15 14:46:16 --> Form Validation Class Initialized
INFO - 2018-02-15 14:46:16 --> Model Class Initialized
INFO - 2018-02-15 14:46:16 --> Controller Class Initialized
INFO - 2018-02-15 14:46:16 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 14:46:16 --> Model Class Initialized
INFO - 2018-02-15 14:46:16 --> Model Class Initialized
INFO - 2018-02-15 14:46:16 --> Model Class Initialized
INFO - 2018-02-15 14:46:17 --> Config Class Initialized
INFO - 2018-02-15 14:46:17 --> Hooks Class Initialized
DEBUG - 2018-02-15 14:46:17 --> UTF-8 Support Enabled
INFO - 2018-02-15 14:46:17 --> Utf8 Class Initialized
INFO - 2018-02-15 14:46:17 --> URI Class Initialized
INFO - 2018-02-15 14:46:17 --> Router Class Initialized
INFO - 2018-02-15 14:46:17 --> Output Class Initialized
INFO - 2018-02-15 14:46:17 --> Security Class Initialized
DEBUG - 2018-02-15 14:46:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 14:46:17 --> Input Class Initialized
INFO - 2018-02-15 14:46:17 --> Language Class Initialized
INFO - 2018-02-15 14:46:17 --> Loader Class Initialized
INFO - 2018-02-15 14:46:17 --> Helper loaded: url_helper
INFO - 2018-02-15 14:46:17 --> Helper loaded: file_helper
INFO - 2018-02-15 14:46:17 --> Helper loaded: email_helper
INFO - 2018-02-15 14:46:17 --> Helper loaded: common_helper
INFO - 2018-02-15 14:46:17 --> Database Driver Class Initialized
DEBUG - 2018-02-15 14:46:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 14:46:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 14:46:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 14:46:17 --> Pagination Class Initialized
INFO - 2018-02-15 14:46:17 --> Helper loaded: form_helper
INFO - 2018-02-15 14:46:17 --> Form Validation Class Initialized
INFO - 2018-02-15 14:46:17 --> Model Class Initialized
INFO - 2018-02-15 14:46:17 --> Controller Class Initialized
INFO - 2018-02-15 14:46:17 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 14:46:17 --> Model Class Initialized
INFO - 2018-02-15 14:46:17 --> Model Class Initialized
INFO - 2018-02-15 14:46:17 --> Model Class Initialized
INFO - 2018-02-15 14:46:18 --> Config Class Initialized
INFO - 2018-02-15 14:46:18 --> Hooks Class Initialized
DEBUG - 2018-02-15 14:46:18 --> UTF-8 Support Enabled
INFO - 2018-02-15 14:46:18 --> Utf8 Class Initialized
INFO - 2018-02-15 14:46:18 --> URI Class Initialized
INFO - 2018-02-15 14:46:18 --> Router Class Initialized
INFO - 2018-02-15 14:46:18 --> Output Class Initialized
INFO - 2018-02-15 14:46:18 --> Security Class Initialized
DEBUG - 2018-02-15 14:46:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 14:46:18 --> Input Class Initialized
INFO - 2018-02-15 14:46:18 --> Language Class Initialized
INFO - 2018-02-15 14:46:18 --> Loader Class Initialized
INFO - 2018-02-15 14:46:18 --> Helper loaded: url_helper
INFO - 2018-02-15 14:46:18 --> Helper loaded: file_helper
INFO - 2018-02-15 14:46:18 --> Helper loaded: email_helper
INFO - 2018-02-15 14:46:18 --> Helper loaded: common_helper
INFO - 2018-02-15 14:46:18 --> Database Driver Class Initialized
DEBUG - 2018-02-15 14:46:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 14:46:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 14:46:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 14:46:18 --> Pagination Class Initialized
INFO - 2018-02-15 14:46:18 --> Helper loaded: form_helper
INFO - 2018-02-15 14:46:18 --> Form Validation Class Initialized
INFO - 2018-02-15 14:46:18 --> Model Class Initialized
INFO - 2018-02-15 14:46:18 --> Controller Class Initialized
INFO - 2018-02-15 14:46:18 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 14:46:18 --> Model Class Initialized
INFO - 2018-02-15 14:46:18 --> Model Class Initialized
INFO - 2018-02-15 14:46:18 --> Model Class Initialized
INFO - 2018-02-15 14:46:18 --> Config Class Initialized
INFO - 2018-02-15 14:46:18 --> Hooks Class Initialized
DEBUG - 2018-02-15 14:46:18 --> UTF-8 Support Enabled
INFO - 2018-02-15 14:46:18 --> Utf8 Class Initialized
INFO - 2018-02-15 14:46:18 --> URI Class Initialized
INFO - 2018-02-15 14:46:18 --> Router Class Initialized
INFO - 2018-02-15 14:46:18 --> Output Class Initialized
INFO - 2018-02-15 14:46:18 --> Security Class Initialized
DEBUG - 2018-02-15 14:46:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 14:46:18 --> Input Class Initialized
INFO - 2018-02-15 14:46:18 --> Language Class Initialized
INFO - 2018-02-15 14:46:18 --> Loader Class Initialized
INFO - 2018-02-15 14:46:18 --> Helper loaded: url_helper
INFO - 2018-02-15 14:46:18 --> Helper loaded: file_helper
INFO - 2018-02-15 14:46:18 --> Helper loaded: email_helper
INFO - 2018-02-15 14:46:18 --> Helper loaded: common_helper
INFO - 2018-02-15 14:46:18 --> Database Driver Class Initialized
DEBUG - 2018-02-15 14:46:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 14:46:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 14:46:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 14:46:18 --> Pagination Class Initialized
INFO - 2018-02-15 14:46:18 --> Helper loaded: form_helper
INFO - 2018-02-15 14:46:18 --> Form Validation Class Initialized
INFO - 2018-02-15 14:46:18 --> Model Class Initialized
INFO - 2018-02-15 14:46:18 --> Controller Class Initialized
INFO - 2018-02-15 14:46:18 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 14:46:18 --> Model Class Initialized
INFO - 2018-02-15 14:46:18 --> Model Class Initialized
INFO - 2018-02-15 14:46:18 --> Model Class Initialized
INFO - 2018-02-15 14:46:19 --> Config Class Initialized
INFO - 2018-02-15 14:46:19 --> Hooks Class Initialized
DEBUG - 2018-02-15 14:46:19 --> UTF-8 Support Enabled
INFO - 2018-02-15 14:46:19 --> Utf8 Class Initialized
INFO - 2018-02-15 14:46:19 --> URI Class Initialized
INFO - 2018-02-15 14:46:19 --> Router Class Initialized
INFO - 2018-02-15 14:46:19 --> Output Class Initialized
INFO - 2018-02-15 14:46:19 --> Security Class Initialized
DEBUG - 2018-02-15 14:46:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 14:46:19 --> Input Class Initialized
INFO - 2018-02-15 14:46:19 --> Language Class Initialized
INFO - 2018-02-15 14:46:19 --> Loader Class Initialized
INFO - 2018-02-15 14:46:19 --> Helper loaded: url_helper
INFO - 2018-02-15 14:46:19 --> Helper loaded: file_helper
INFO - 2018-02-15 14:46:19 --> Helper loaded: email_helper
INFO - 2018-02-15 14:46:19 --> Helper loaded: common_helper
INFO - 2018-02-15 14:46:19 --> Database Driver Class Initialized
DEBUG - 2018-02-15 14:46:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 14:46:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 14:46:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 14:46:19 --> Pagination Class Initialized
INFO - 2018-02-15 14:46:19 --> Helper loaded: form_helper
INFO - 2018-02-15 14:46:19 --> Form Validation Class Initialized
INFO - 2018-02-15 14:46:19 --> Model Class Initialized
INFO - 2018-02-15 14:46:19 --> Controller Class Initialized
INFO - 2018-02-15 14:46:19 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 14:46:19 --> Model Class Initialized
INFO - 2018-02-15 14:46:19 --> Model Class Initialized
INFO - 2018-02-15 14:46:19 --> Model Class Initialized
INFO - 2018-02-15 14:46:20 --> Config Class Initialized
INFO - 2018-02-15 14:46:20 --> Hooks Class Initialized
DEBUG - 2018-02-15 14:46:20 --> UTF-8 Support Enabled
INFO - 2018-02-15 14:46:20 --> Utf8 Class Initialized
INFO - 2018-02-15 14:46:20 --> URI Class Initialized
INFO - 2018-02-15 14:46:20 --> Router Class Initialized
INFO - 2018-02-15 14:46:20 --> Output Class Initialized
INFO - 2018-02-15 14:46:20 --> Security Class Initialized
DEBUG - 2018-02-15 14:46:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 14:46:20 --> Input Class Initialized
INFO - 2018-02-15 14:46:20 --> Language Class Initialized
INFO - 2018-02-15 14:46:20 --> Loader Class Initialized
INFO - 2018-02-15 14:46:20 --> Helper loaded: url_helper
INFO - 2018-02-15 14:46:20 --> Helper loaded: file_helper
INFO - 2018-02-15 14:46:20 --> Helper loaded: email_helper
INFO - 2018-02-15 14:46:20 --> Helper loaded: common_helper
INFO - 2018-02-15 14:46:20 --> Database Driver Class Initialized
DEBUG - 2018-02-15 14:46:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 14:46:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 14:46:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 14:46:20 --> Pagination Class Initialized
INFO - 2018-02-15 14:46:20 --> Helper loaded: form_helper
INFO - 2018-02-15 14:46:20 --> Form Validation Class Initialized
INFO - 2018-02-15 14:46:20 --> Model Class Initialized
INFO - 2018-02-15 14:46:20 --> Controller Class Initialized
INFO - 2018-02-15 14:46:20 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 14:46:20 --> Model Class Initialized
INFO - 2018-02-15 14:46:20 --> Model Class Initialized
INFO - 2018-02-15 14:46:20 --> Model Class Initialized
INFO - 2018-02-15 14:46:21 --> Config Class Initialized
INFO - 2018-02-15 14:46:21 --> Hooks Class Initialized
DEBUG - 2018-02-15 14:46:21 --> UTF-8 Support Enabled
INFO - 2018-02-15 14:46:21 --> Utf8 Class Initialized
INFO - 2018-02-15 14:46:21 --> URI Class Initialized
INFO - 2018-02-15 14:46:21 --> Router Class Initialized
INFO - 2018-02-15 14:46:21 --> Output Class Initialized
INFO - 2018-02-15 14:46:21 --> Security Class Initialized
DEBUG - 2018-02-15 14:46:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 14:46:21 --> Input Class Initialized
INFO - 2018-02-15 14:46:21 --> Language Class Initialized
INFO - 2018-02-15 14:46:21 --> Loader Class Initialized
INFO - 2018-02-15 14:46:21 --> Helper loaded: url_helper
INFO - 2018-02-15 14:46:21 --> Helper loaded: file_helper
INFO - 2018-02-15 14:46:21 --> Helper loaded: email_helper
INFO - 2018-02-15 14:46:21 --> Helper loaded: common_helper
INFO - 2018-02-15 14:46:21 --> Database Driver Class Initialized
DEBUG - 2018-02-15 14:46:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 14:46:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 14:46:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 14:46:21 --> Pagination Class Initialized
INFO - 2018-02-15 14:46:21 --> Helper loaded: form_helper
INFO - 2018-02-15 14:46:21 --> Form Validation Class Initialized
INFO - 2018-02-15 14:46:21 --> Model Class Initialized
INFO - 2018-02-15 14:46:21 --> Controller Class Initialized
INFO - 2018-02-15 14:46:21 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 14:46:21 --> Model Class Initialized
INFO - 2018-02-15 14:46:21 --> Model Class Initialized
INFO - 2018-02-15 14:46:21 --> Model Class Initialized
INFO - 2018-02-15 14:46:21 --> Config Class Initialized
INFO - 2018-02-15 14:46:21 --> Hooks Class Initialized
DEBUG - 2018-02-15 14:46:21 --> UTF-8 Support Enabled
INFO - 2018-02-15 14:46:21 --> Utf8 Class Initialized
INFO - 2018-02-15 14:46:21 --> URI Class Initialized
INFO - 2018-02-15 14:46:21 --> Router Class Initialized
INFO - 2018-02-15 14:46:21 --> Output Class Initialized
INFO - 2018-02-15 14:46:21 --> Security Class Initialized
DEBUG - 2018-02-15 14:46:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 14:46:21 --> Input Class Initialized
INFO - 2018-02-15 14:46:21 --> Language Class Initialized
INFO - 2018-02-15 14:46:21 --> Loader Class Initialized
INFO - 2018-02-15 14:46:21 --> Helper loaded: url_helper
INFO - 2018-02-15 14:46:21 --> Helper loaded: file_helper
INFO - 2018-02-15 14:46:21 --> Helper loaded: email_helper
INFO - 2018-02-15 14:46:21 --> Helper loaded: common_helper
INFO - 2018-02-15 14:46:21 --> Database Driver Class Initialized
DEBUG - 2018-02-15 14:46:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 14:46:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 14:46:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 14:46:21 --> Pagination Class Initialized
INFO - 2018-02-15 14:46:21 --> Helper loaded: form_helper
INFO - 2018-02-15 14:46:21 --> Form Validation Class Initialized
INFO - 2018-02-15 14:46:21 --> Model Class Initialized
INFO - 2018-02-15 14:46:21 --> Controller Class Initialized
INFO - 2018-02-15 14:46:21 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 14:46:21 --> Model Class Initialized
INFO - 2018-02-15 14:46:21 --> Model Class Initialized
INFO - 2018-02-15 14:46:21 --> Model Class Initialized
INFO - 2018-02-15 14:46:22 --> Config Class Initialized
INFO - 2018-02-15 14:46:22 --> Hooks Class Initialized
DEBUG - 2018-02-15 14:46:22 --> UTF-8 Support Enabled
INFO - 2018-02-15 14:46:22 --> Utf8 Class Initialized
INFO - 2018-02-15 14:46:22 --> URI Class Initialized
INFO - 2018-02-15 14:46:22 --> Router Class Initialized
INFO - 2018-02-15 14:46:22 --> Output Class Initialized
INFO - 2018-02-15 14:46:22 --> Security Class Initialized
DEBUG - 2018-02-15 14:46:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 14:46:22 --> Input Class Initialized
INFO - 2018-02-15 14:46:22 --> Language Class Initialized
INFO - 2018-02-15 14:46:22 --> Loader Class Initialized
INFO - 2018-02-15 14:46:22 --> Helper loaded: url_helper
INFO - 2018-02-15 14:46:22 --> Helper loaded: file_helper
INFO - 2018-02-15 14:46:22 --> Helper loaded: email_helper
INFO - 2018-02-15 14:46:22 --> Helper loaded: common_helper
INFO - 2018-02-15 14:46:22 --> Database Driver Class Initialized
DEBUG - 2018-02-15 14:46:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 14:46:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 14:46:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 14:46:22 --> Pagination Class Initialized
INFO - 2018-02-15 14:46:22 --> Helper loaded: form_helper
INFO - 2018-02-15 14:46:22 --> Form Validation Class Initialized
INFO - 2018-02-15 14:46:22 --> Model Class Initialized
INFO - 2018-02-15 14:46:22 --> Controller Class Initialized
INFO - 2018-02-15 14:46:22 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 14:46:22 --> Model Class Initialized
INFO - 2018-02-15 14:46:22 --> Model Class Initialized
INFO - 2018-02-15 14:46:22 --> Model Class Initialized
INFO - 2018-02-15 14:46:23 --> Config Class Initialized
INFO - 2018-02-15 14:46:23 --> Hooks Class Initialized
DEBUG - 2018-02-15 14:46:23 --> UTF-8 Support Enabled
INFO - 2018-02-15 14:46:23 --> Utf8 Class Initialized
INFO - 2018-02-15 14:46:23 --> URI Class Initialized
INFO - 2018-02-15 14:46:23 --> Router Class Initialized
INFO - 2018-02-15 14:46:23 --> Output Class Initialized
INFO - 2018-02-15 14:46:23 --> Security Class Initialized
DEBUG - 2018-02-15 14:46:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 14:46:23 --> Input Class Initialized
INFO - 2018-02-15 14:46:23 --> Language Class Initialized
INFO - 2018-02-15 14:46:23 --> Loader Class Initialized
INFO - 2018-02-15 14:46:23 --> Helper loaded: url_helper
INFO - 2018-02-15 14:46:23 --> Helper loaded: file_helper
INFO - 2018-02-15 14:46:23 --> Helper loaded: email_helper
INFO - 2018-02-15 14:46:23 --> Helper loaded: common_helper
INFO - 2018-02-15 14:46:23 --> Database Driver Class Initialized
DEBUG - 2018-02-15 14:46:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 14:46:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 14:46:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 14:46:23 --> Pagination Class Initialized
INFO - 2018-02-15 14:46:23 --> Helper loaded: form_helper
INFO - 2018-02-15 14:46:23 --> Form Validation Class Initialized
INFO - 2018-02-15 14:46:23 --> Model Class Initialized
INFO - 2018-02-15 14:46:23 --> Controller Class Initialized
INFO - 2018-02-15 14:46:23 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 14:46:23 --> Model Class Initialized
INFO - 2018-02-15 14:46:23 --> Model Class Initialized
INFO - 2018-02-15 14:46:23 --> Model Class Initialized
INFO - 2018-02-15 14:46:23 --> Config Class Initialized
INFO - 2018-02-15 14:46:23 --> Hooks Class Initialized
DEBUG - 2018-02-15 14:46:23 --> UTF-8 Support Enabled
INFO - 2018-02-15 14:46:23 --> Utf8 Class Initialized
INFO - 2018-02-15 14:46:23 --> URI Class Initialized
INFO - 2018-02-15 14:46:23 --> Router Class Initialized
INFO - 2018-02-15 14:46:23 --> Output Class Initialized
INFO - 2018-02-15 14:46:23 --> Security Class Initialized
DEBUG - 2018-02-15 14:46:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 14:46:23 --> Input Class Initialized
INFO - 2018-02-15 14:46:23 --> Language Class Initialized
INFO - 2018-02-15 14:46:23 --> Loader Class Initialized
INFO - 2018-02-15 14:46:23 --> Helper loaded: url_helper
INFO - 2018-02-15 14:46:23 --> Helper loaded: file_helper
INFO - 2018-02-15 14:46:23 --> Helper loaded: email_helper
INFO - 2018-02-15 14:46:23 --> Helper loaded: common_helper
INFO - 2018-02-15 14:46:23 --> Database Driver Class Initialized
DEBUG - 2018-02-15 14:46:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 14:46:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 14:46:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 14:46:23 --> Pagination Class Initialized
INFO - 2018-02-15 14:46:23 --> Helper loaded: form_helper
INFO - 2018-02-15 14:46:23 --> Form Validation Class Initialized
INFO - 2018-02-15 14:46:23 --> Model Class Initialized
INFO - 2018-02-15 14:46:23 --> Controller Class Initialized
INFO - 2018-02-15 14:46:23 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 14:46:23 --> Model Class Initialized
INFO - 2018-02-15 14:46:23 --> Model Class Initialized
INFO - 2018-02-15 14:46:23 --> Model Class Initialized
INFO - 2018-02-15 14:46:24 --> Config Class Initialized
INFO - 2018-02-15 14:46:24 --> Hooks Class Initialized
DEBUG - 2018-02-15 14:46:24 --> UTF-8 Support Enabled
INFO - 2018-02-15 14:46:24 --> Utf8 Class Initialized
INFO - 2018-02-15 14:46:24 --> URI Class Initialized
INFO - 2018-02-15 14:46:24 --> Router Class Initialized
INFO - 2018-02-15 14:46:24 --> Output Class Initialized
INFO - 2018-02-15 14:46:24 --> Security Class Initialized
DEBUG - 2018-02-15 14:46:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 14:46:24 --> Input Class Initialized
INFO - 2018-02-15 14:46:24 --> Language Class Initialized
INFO - 2018-02-15 14:46:24 --> Loader Class Initialized
INFO - 2018-02-15 14:46:24 --> Helper loaded: url_helper
INFO - 2018-02-15 14:46:24 --> Helper loaded: file_helper
INFO - 2018-02-15 14:46:24 --> Helper loaded: email_helper
INFO - 2018-02-15 14:46:24 --> Helper loaded: common_helper
INFO - 2018-02-15 14:46:24 --> Database Driver Class Initialized
DEBUG - 2018-02-15 14:46:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 14:46:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 14:46:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 14:46:24 --> Pagination Class Initialized
INFO - 2018-02-15 14:46:24 --> Helper loaded: form_helper
INFO - 2018-02-15 14:46:24 --> Form Validation Class Initialized
INFO - 2018-02-15 14:46:24 --> Model Class Initialized
INFO - 2018-02-15 14:46:24 --> Controller Class Initialized
INFO - 2018-02-15 14:46:24 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 14:46:24 --> Model Class Initialized
INFO - 2018-02-15 14:46:24 --> Model Class Initialized
INFO - 2018-02-15 14:46:24 --> Model Class Initialized
INFO - 2018-02-15 14:46:25 --> Config Class Initialized
INFO - 2018-02-15 14:46:25 --> Hooks Class Initialized
DEBUG - 2018-02-15 14:46:25 --> UTF-8 Support Enabled
INFO - 2018-02-15 14:46:25 --> Utf8 Class Initialized
INFO - 2018-02-15 14:46:25 --> URI Class Initialized
INFO - 2018-02-15 14:46:25 --> Router Class Initialized
INFO - 2018-02-15 14:46:25 --> Output Class Initialized
INFO - 2018-02-15 14:46:25 --> Security Class Initialized
DEBUG - 2018-02-15 14:46:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 14:46:25 --> Input Class Initialized
INFO - 2018-02-15 14:46:25 --> Language Class Initialized
INFO - 2018-02-15 14:46:25 --> Loader Class Initialized
INFO - 2018-02-15 14:46:25 --> Helper loaded: url_helper
INFO - 2018-02-15 14:46:25 --> Helper loaded: file_helper
INFO - 2018-02-15 14:46:25 --> Helper loaded: email_helper
INFO - 2018-02-15 14:46:25 --> Helper loaded: common_helper
INFO - 2018-02-15 14:46:25 --> Database Driver Class Initialized
DEBUG - 2018-02-15 14:46:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 14:46:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 14:46:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 14:46:25 --> Pagination Class Initialized
INFO - 2018-02-15 14:46:25 --> Helper loaded: form_helper
INFO - 2018-02-15 14:46:25 --> Form Validation Class Initialized
INFO - 2018-02-15 14:46:25 --> Model Class Initialized
INFO - 2018-02-15 14:46:25 --> Controller Class Initialized
INFO - 2018-02-15 14:46:25 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 14:46:25 --> Model Class Initialized
INFO - 2018-02-15 14:46:25 --> Model Class Initialized
INFO - 2018-02-15 14:46:25 --> Model Class Initialized
INFO - 2018-02-15 14:46:26 --> Config Class Initialized
INFO - 2018-02-15 14:46:26 --> Hooks Class Initialized
DEBUG - 2018-02-15 14:46:26 --> UTF-8 Support Enabled
INFO - 2018-02-15 14:46:26 --> Utf8 Class Initialized
INFO - 2018-02-15 14:46:26 --> URI Class Initialized
INFO - 2018-02-15 14:46:26 --> Router Class Initialized
INFO - 2018-02-15 14:46:26 --> Output Class Initialized
INFO - 2018-02-15 14:46:26 --> Security Class Initialized
DEBUG - 2018-02-15 14:46:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 14:46:26 --> Input Class Initialized
INFO - 2018-02-15 14:46:26 --> Language Class Initialized
INFO - 2018-02-15 14:46:26 --> Loader Class Initialized
INFO - 2018-02-15 14:46:26 --> Helper loaded: url_helper
INFO - 2018-02-15 14:46:26 --> Helper loaded: file_helper
INFO - 2018-02-15 14:46:26 --> Helper loaded: email_helper
INFO - 2018-02-15 14:46:26 --> Helper loaded: common_helper
INFO - 2018-02-15 14:46:26 --> Database Driver Class Initialized
DEBUG - 2018-02-15 14:46:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 14:46:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 14:46:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 14:46:26 --> Pagination Class Initialized
INFO - 2018-02-15 14:46:26 --> Helper loaded: form_helper
INFO - 2018-02-15 14:46:26 --> Form Validation Class Initialized
INFO - 2018-02-15 14:46:26 --> Model Class Initialized
INFO - 2018-02-15 14:46:26 --> Controller Class Initialized
INFO - 2018-02-15 14:46:26 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 14:46:26 --> Model Class Initialized
INFO - 2018-02-15 14:46:26 --> Model Class Initialized
INFO - 2018-02-15 14:46:26 --> Model Class Initialized
INFO - 2018-02-15 14:46:27 --> Config Class Initialized
INFO - 2018-02-15 14:46:27 --> Hooks Class Initialized
DEBUG - 2018-02-15 14:46:27 --> UTF-8 Support Enabled
INFO - 2018-02-15 14:46:27 --> Utf8 Class Initialized
INFO - 2018-02-15 14:46:27 --> URI Class Initialized
INFO - 2018-02-15 14:46:27 --> Router Class Initialized
INFO - 2018-02-15 14:46:27 --> Output Class Initialized
INFO - 2018-02-15 14:46:27 --> Security Class Initialized
DEBUG - 2018-02-15 14:46:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 14:46:27 --> Input Class Initialized
INFO - 2018-02-15 14:46:27 --> Language Class Initialized
INFO - 2018-02-15 14:46:27 --> Loader Class Initialized
INFO - 2018-02-15 14:46:27 --> Helper loaded: url_helper
INFO - 2018-02-15 14:46:27 --> Helper loaded: file_helper
INFO - 2018-02-15 14:46:27 --> Helper loaded: email_helper
INFO - 2018-02-15 14:46:27 --> Helper loaded: common_helper
INFO - 2018-02-15 14:46:27 --> Database Driver Class Initialized
DEBUG - 2018-02-15 14:46:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 14:46:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 14:46:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 14:46:27 --> Pagination Class Initialized
INFO - 2018-02-15 14:46:27 --> Helper loaded: form_helper
INFO - 2018-02-15 14:46:27 --> Form Validation Class Initialized
INFO - 2018-02-15 14:46:27 --> Model Class Initialized
INFO - 2018-02-15 14:46:27 --> Controller Class Initialized
INFO - 2018-02-15 14:46:27 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 14:46:27 --> Model Class Initialized
INFO - 2018-02-15 14:46:27 --> Model Class Initialized
INFO - 2018-02-15 14:46:27 --> Model Class Initialized
INFO - 2018-02-15 14:46:29 --> Config Class Initialized
INFO - 2018-02-15 14:46:29 --> Hooks Class Initialized
DEBUG - 2018-02-15 14:46:29 --> UTF-8 Support Enabled
INFO - 2018-02-15 14:46:29 --> Utf8 Class Initialized
INFO - 2018-02-15 14:46:29 --> URI Class Initialized
INFO - 2018-02-15 14:46:29 --> Router Class Initialized
INFO - 2018-02-15 14:46:29 --> Output Class Initialized
INFO - 2018-02-15 14:46:29 --> Security Class Initialized
DEBUG - 2018-02-15 14:46:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 14:46:29 --> Input Class Initialized
INFO - 2018-02-15 14:46:29 --> Language Class Initialized
INFO - 2018-02-15 14:46:29 --> Loader Class Initialized
INFO - 2018-02-15 14:46:29 --> Helper loaded: url_helper
INFO - 2018-02-15 14:46:29 --> Helper loaded: file_helper
INFO - 2018-02-15 14:46:29 --> Helper loaded: email_helper
INFO - 2018-02-15 14:46:29 --> Helper loaded: common_helper
INFO - 2018-02-15 14:46:29 --> Database Driver Class Initialized
DEBUG - 2018-02-15 14:46:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 14:46:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 14:46:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 14:46:29 --> Pagination Class Initialized
INFO - 2018-02-15 14:46:29 --> Helper loaded: form_helper
INFO - 2018-02-15 14:46:29 --> Form Validation Class Initialized
INFO - 2018-02-15 14:46:29 --> Model Class Initialized
INFO - 2018-02-15 14:46:29 --> Controller Class Initialized
INFO - 2018-02-15 14:46:29 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 14:46:29 --> Model Class Initialized
INFO - 2018-02-15 14:46:29 --> Model Class Initialized
INFO - 2018-02-15 14:46:29 --> Model Class Initialized
INFO - 2018-02-15 14:46:30 --> Config Class Initialized
INFO - 2018-02-15 14:46:30 --> Hooks Class Initialized
DEBUG - 2018-02-15 14:46:30 --> UTF-8 Support Enabled
INFO - 2018-02-15 14:46:30 --> Utf8 Class Initialized
INFO - 2018-02-15 14:46:30 --> URI Class Initialized
INFO - 2018-02-15 14:46:30 --> Router Class Initialized
INFO - 2018-02-15 14:46:30 --> Output Class Initialized
INFO - 2018-02-15 14:46:30 --> Security Class Initialized
DEBUG - 2018-02-15 14:46:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 14:46:30 --> Input Class Initialized
INFO - 2018-02-15 14:46:30 --> Language Class Initialized
INFO - 2018-02-15 14:46:30 --> Loader Class Initialized
INFO - 2018-02-15 14:46:30 --> Helper loaded: url_helper
INFO - 2018-02-15 14:46:30 --> Helper loaded: file_helper
INFO - 2018-02-15 14:46:30 --> Helper loaded: email_helper
INFO - 2018-02-15 14:46:30 --> Helper loaded: common_helper
INFO - 2018-02-15 14:46:30 --> Database Driver Class Initialized
DEBUG - 2018-02-15 14:46:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 14:46:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 14:46:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 14:46:30 --> Pagination Class Initialized
INFO - 2018-02-15 14:46:30 --> Helper loaded: form_helper
INFO - 2018-02-15 14:46:30 --> Form Validation Class Initialized
INFO - 2018-02-15 14:46:30 --> Model Class Initialized
INFO - 2018-02-15 14:46:30 --> Controller Class Initialized
INFO - 2018-02-15 14:46:30 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 14:46:30 --> Model Class Initialized
INFO - 2018-02-15 14:46:30 --> Model Class Initialized
INFO - 2018-02-15 14:46:30 --> Model Class Initialized
INFO - 2018-02-15 14:46:33 --> Config Class Initialized
INFO - 2018-02-15 14:46:33 --> Hooks Class Initialized
DEBUG - 2018-02-15 14:46:33 --> UTF-8 Support Enabled
INFO - 2018-02-15 14:46:33 --> Utf8 Class Initialized
INFO - 2018-02-15 14:46:33 --> URI Class Initialized
INFO - 2018-02-15 14:46:33 --> Router Class Initialized
INFO - 2018-02-15 14:46:33 --> Output Class Initialized
INFO - 2018-02-15 14:46:33 --> Security Class Initialized
DEBUG - 2018-02-15 14:46:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 14:46:33 --> Input Class Initialized
INFO - 2018-02-15 14:46:33 --> Language Class Initialized
INFO - 2018-02-15 14:46:33 --> Loader Class Initialized
INFO - 2018-02-15 14:46:33 --> Helper loaded: url_helper
INFO - 2018-02-15 14:46:33 --> Helper loaded: file_helper
INFO - 2018-02-15 14:46:33 --> Helper loaded: email_helper
INFO - 2018-02-15 14:46:33 --> Helper loaded: common_helper
INFO - 2018-02-15 14:46:33 --> Database Driver Class Initialized
DEBUG - 2018-02-15 14:46:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 14:46:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 14:46:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 14:46:33 --> Pagination Class Initialized
INFO - 2018-02-15 14:46:33 --> Helper loaded: form_helper
INFO - 2018-02-15 14:46:33 --> Form Validation Class Initialized
INFO - 2018-02-15 14:46:33 --> Model Class Initialized
INFO - 2018-02-15 14:46:33 --> Controller Class Initialized
INFO - 2018-02-15 14:46:33 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 14:46:33 --> Model Class Initialized
INFO - 2018-02-15 14:46:33 --> Model Class Initialized
INFO - 2018-02-15 14:46:33 --> Model Class Initialized
INFO - 2018-02-15 14:46:34 --> Config Class Initialized
INFO - 2018-02-15 14:46:34 --> Hooks Class Initialized
DEBUG - 2018-02-15 14:46:34 --> UTF-8 Support Enabled
INFO - 2018-02-15 14:46:34 --> Utf8 Class Initialized
INFO - 2018-02-15 14:46:34 --> URI Class Initialized
INFO - 2018-02-15 14:46:34 --> Router Class Initialized
INFO - 2018-02-15 14:46:34 --> Output Class Initialized
INFO - 2018-02-15 14:46:34 --> Security Class Initialized
DEBUG - 2018-02-15 14:46:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 14:46:34 --> Input Class Initialized
INFO - 2018-02-15 14:46:34 --> Language Class Initialized
INFO - 2018-02-15 14:46:34 --> Loader Class Initialized
INFO - 2018-02-15 14:46:34 --> Helper loaded: url_helper
INFO - 2018-02-15 14:46:34 --> Helper loaded: file_helper
INFO - 2018-02-15 14:46:34 --> Helper loaded: email_helper
INFO - 2018-02-15 14:46:34 --> Helper loaded: common_helper
INFO - 2018-02-15 14:46:34 --> Database Driver Class Initialized
DEBUG - 2018-02-15 14:46:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 14:46:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 14:46:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 14:46:34 --> Pagination Class Initialized
INFO - 2018-02-15 14:46:34 --> Helper loaded: form_helper
INFO - 2018-02-15 14:46:34 --> Form Validation Class Initialized
INFO - 2018-02-15 14:46:34 --> Model Class Initialized
INFO - 2018-02-15 14:46:34 --> Controller Class Initialized
INFO - 2018-02-15 14:46:34 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 14:46:34 --> Model Class Initialized
INFO - 2018-02-15 14:46:34 --> Model Class Initialized
INFO - 2018-02-15 14:46:34 --> Model Class Initialized
INFO - 2018-02-15 14:46:34 --> Config Class Initialized
INFO - 2018-02-15 14:46:34 --> Hooks Class Initialized
DEBUG - 2018-02-15 14:46:34 --> UTF-8 Support Enabled
INFO - 2018-02-15 14:46:34 --> Utf8 Class Initialized
INFO - 2018-02-15 14:46:34 --> URI Class Initialized
INFO - 2018-02-15 14:46:34 --> Router Class Initialized
INFO - 2018-02-15 14:46:34 --> Output Class Initialized
INFO - 2018-02-15 14:46:34 --> Security Class Initialized
DEBUG - 2018-02-15 14:46:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 14:46:34 --> Input Class Initialized
INFO - 2018-02-15 14:46:34 --> Language Class Initialized
INFO - 2018-02-15 14:46:34 --> Loader Class Initialized
INFO - 2018-02-15 14:46:34 --> Helper loaded: url_helper
INFO - 2018-02-15 14:46:34 --> Helper loaded: file_helper
INFO - 2018-02-15 14:46:34 --> Helper loaded: email_helper
INFO - 2018-02-15 14:46:34 --> Helper loaded: common_helper
INFO - 2018-02-15 14:46:34 --> Database Driver Class Initialized
DEBUG - 2018-02-15 14:46:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 14:46:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 14:46:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 14:46:34 --> Pagination Class Initialized
INFO - 2018-02-15 14:46:34 --> Helper loaded: form_helper
INFO - 2018-02-15 14:46:34 --> Form Validation Class Initialized
INFO - 2018-02-15 14:46:34 --> Model Class Initialized
INFO - 2018-02-15 14:46:34 --> Controller Class Initialized
INFO - 2018-02-15 14:46:34 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 14:46:34 --> Model Class Initialized
INFO - 2018-02-15 14:46:34 --> Model Class Initialized
INFO - 2018-02-15 14:46:34 --> Model Class Initialized
INFO - 2018-02-15 14:46:35 --> Config Class Initialized
INFO - 2018-02-15 14:46:35 --> Hooks Class Initialized
DEBUG - 2018-02-15 14:46:35 --> UTF-8 Support Enabled
INFO - 2018-02-15 14:46:35 --> Utf8 Class Initialized
INFO - 2018-02-15 14:46:35 --> URI Class Initialized
INFO - 2018-02-15 14:46:35 --> Router Class Initialized
INFO - 2018-02-15 14:46:35 --> Output Class Initialized
INFO - 2018-02-15 14:46:35 --> Security Class Initialized
DEBUG - 2018-02-15 14:46:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 14:46:35 --> Input Class Initialized
INFO - 2018-02-15 14:46:35 --> Language Class Initialized
INFO - 2018-02-15 14:46:35 --> Loader Class Initialized
INFO - 2018-02-15 14:46:35 --> Helper loaded: url_helper
INFO - 2018-02-15 14:46:35 --> Helper loaded: file_helper
INFO - 2018-02-15 14:46:35 --> Helper loaded: email_helper
INFO - 2018-02-15 14:46:35 --> Helper loaded: common_helper
INFO - 2018-02-15 14:46:35 --> Database Driver Class Initialized
DEBUG - 2018-02-15 14:46:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 14:46:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 14:46:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 14:46:35 --> Pagination Class Initialized
INFO - 2018-02-15 14:46:35 --> Helper loaded: form_helper
INFO - 2018-02-15 14:46:35 --> Form Validation Class Initialized
INFO - 2018-02-15 14:46:35 --> Model Class Initialized
INFO - 2018-02-15 14:46:35 --> Controller Class Initialized
INFO - 2018-02-15 14:46:35 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 14:46:35 --> Model Class Initialized
INFO - 2018-02-15 14:46:35 --> Model Class Initialized
INFO - 2018-02-15 14:46:35 --> Model Class Initialized
INFO - 2018-02-15 14:46:36 --> Config Class Initialized
INFO - 2018-02-15 14:46:36 --> Hooks Class Initialized
DEBUG - 2018-02-15 14:46:36 --> UTF-8 Support Enabled
INFO - 2018-02-15 14:46:36 --> Utf8 Class Initialized
INFO - 2018-02-15 14:46:36 --> URI Class Initialized
INFO - 2018-02-15 14:46:36 --> Router Class Initialized
INFO - 2018-02-15 14:46:36 --> Output Class Initialized
INFO - 2018-02-15 14:46:36 --> Security Class Initialized
DEBUG - 2018-02-15 14:46:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 14:46:36 --> Input Class Initialized
INFO - 2018-02-15 14:46:36 --> Language Class Initialized
INFO - 2018-02-15 14:46:36 --> Loader Class Initialized
INFO - 2018-02-15 14:46:36 --> Helper loaded: url_helper
INFO - 2018-02-15 14:46:36 --> Helper loaded: file_helper
INFO - 2018-02-15 14:46:36 --> Helper loaded: email_helper
INFO - 2018-02-15 14:46:36 --> Helper loaded: common_helper
INFO - 2018-02-15 14:46:36 --> Database Driver Class Initialized
DEBUG - 2018-02-15 14:46:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 14:46:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 14:46:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 14:46:36 --> Pagination Class Initialized
INFO - 2018-02-15 14:46:36 --> Helper loaded: form_helper
INFO - 2018-02-15 14:46:36 --> Form Validation Class Initialized
INFO - 2018-02-15 14:46:36 --> Model Class Initialized
INFO - 2018-02-15 14:46:36 --> Controller Class Initialized
INFO - 2018-02-15 14:46:36 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 14:46:36 --> Model Class Initialized
INFO - 2018-02-15 14:46:36 --> Model Class Initialized
INFO - 2018-02-15 14:46:36 --> Model Class Initialized
INFO - 2018-02-15 14:46:38 --> Config Class Initialized
INFO - 2018-02-15 14:46:38 --> Hooks Class Initialized
DEBUG - 2018-02-15 14:46:38 --> UTF-8 Support Enabled
INFO - 2018-02-15 14:46:38 --> Utf8 Class Initialized
INFO - 2018-02-15 14:46:38 --> URI Class Initialized
INFO - 2018-02-15 14:46:38 --> Router Class Initialized
INFO - 2018-02-15 14:46:38 --> Output Class Initialized
INFO - 2018-02-15 14:46:38 --> Security Class Initialized
DEBUG - 2018-02-15 14:46:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 14:46:38 --> Input Class Initialized
INFO - 2018-02-15 14:46:38 --> Language Class Initialized
INFO - 2018-02-15 14:46:38 --> Loader Class Initialized
INFO - 2018-02-15 14:46:38 --> Helper loaded: url_helper
INFO - 2018-02-15 14:46:38 --> Helper loaded: file_helper
INFO - 2018-02-15 14:46:38 --> Helper loaded: email_helper
INFO - 2018-02-15 14:46:38 --> Helper loaded: common_helper
INFO - 2018-02-15 14:46:38 --> Database Driver Class Initialized
DEBUG - 2018-02-15 14:46:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 14:46:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 14:46:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 14:46:38 --> Pagination Class Initialized
INFO - 2018-02-15 14:46:38 --> Helper loaded: form_helper
INFO - 2018-02-15 14:46:38 --> Form Validation Class Initialized
INFO - 2018-02-15 14:46:38 --> Model Class Initialized
INFO - 2018-02-15 14:46:38 --> Controller Class Initialized
INFO - 2018-02-15 14:46:38 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 14:46:38 --> Model Class Initialized
INFO - 2018-02-15 14:46:38 --> Model Class Initialized
INFO - 2018-02-15 14:46:38 --> Model Class Initialized
INFO - 2018-02-15 14:46:38 --> Config Class Initialized
INFO - 2018-02-15 14:46:38 --> Hooks Class Initialized
DEBUG - 2018-02-15 14:46:38 --> UTF-8 Support Enabled
INFO - 2018-02-15 14:46:38 --> Utf8 Class Initialized
INFO - 2018-02-15 14:46:38 --> URI Class Initialized
INFO - 2018-02-15 14:46:38 --> Router Class Initialized
INFO - 2018-02-15 14:46:38 --> Output Class Initialized
INFO - 2018-02-15 14:46:38 --> Security Class Initialized
DEBUG - 2018-02-15 14:46:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 14:46:38 --> Input Class Initialized
INFO - 2018-02-15 14:46:39 --> Language Class Initialized
INFO - 2018-02-15 14:46:39 --> Loader Class Initialized
INFO - 2018-02-15 14:46:39 --> Helper loaded: url_helper
INFO - 2018-02-15 14:46:39 --> Helper loaded: file_helper
INFO - 2018-02-15 14:46:39 --> Helper loaded: email_helper
INFO - 2018-02-15 14:46:39 --> Helper loaded: common_helper
INFO - 2018-02-15 14:46:39 --> Database Driver Class Initialized
DEBUG - 2018-02-15 14:46:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 14:46:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 14:46:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 14:46:39 --> Pagination Class Initialized
INFO - 2018-02-15 14:46:39 --> Helper loaded: form_helper
INFO - 2018-02-15 14:46:39 --> Form Validation Class Initialized
INFO - 2018-02-15 14:46:39 --> Model Class Initialized
INFO - 2018-02-15 14:46:39 --> Controller Class Initialized
INFO - 2018-02-15 14:46:39 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 14:46:39 --> Model Class Initialized
INFO - 2018-02-15 14:46:39 --> Model Class Initialized
INFO - 2018-02-15 14:46:39 --> Model Class Initialized
INFO - 2018-02-15 14:46:39 --> Config Class Initialized
INFO - 2018-02-15 14:46:39 --> Hooks Class Initialized
DEBUG - 2018-02-15 14:46:39 --> UTF-8 Support Enabled
INFO - 2018-02-15 14:46:39 --> Utf8 Class Initialized
INFO - 2018-02-15 14:46:39 --> URI Class Initialized
INFO - 2018-02-15 14:46:39 --> Router Class Initialized
INFO - 2018-02-15 14:46:39 --> Output Class Initialized
INFO - 2018-02-15 14:46:39 --> Security Class Initialized
DEBUG - 2018-02-15 14:46:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 14:46:39 --> Input Class Initialized
INFO - 2018-02-15 14:46:39 --> Language Class Initialized
INFO - 2018-02-15 14:46:39 --> Loader Class Initialized
INFO - 2018-02-15 14:46:39 --> Helper loaded: url_helper
INFO - 2018-02-15 14:46:39 --> Helper loaded: file_helper
INFO - 2018-02-15 14:46:39 --> Helper loaded: email_helper
INFO - 2018-02-15 14:46:39 --> Helper loaded: common_helper
INFO - 2018-02-15 14:46:39 --> Database Driver Class Initialized
DEBUG - 2018-02-15 14:46:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 14:46:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 14:46:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 14:46:39 --> Pagination Class Initialized
INFO - 2018-02-15 14:46:39 --> Helper loaded: form_helper
INFO - 2018-02-15 14:46:39 --> Form Validation Class Initialized
INFO - 2018-02-15 14:46:39 --> Model Class Initialized
INFO - 2018-02-15 14:46:39 --> Controller Class Initialized
INFO - 2018-02-15 14:46:39 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 14:46:39 --> Model Class Initialized
INFO - 2018-02-15 14:46:39 --> Model Class Initialized
INFO - 2018-02-15 14:46:39 --> Model Class Initialized
INFO - 2018-02-15 14:46:40 --> Config Class Initialized
INFO - 2018-02-15 14:46:40 --> Hooks Class Initialized
DEBUG - 2018-02-15 14:46:40 --> UTF-8 Support Enabled
INFO - 2018-02-15 14:46:40 --> Utf8 Class Initialized
INFO - 2018-02-15 14:46:40 --> URI Class Initialized
INFO - 2018-02-15 14:46:40 --> Router Class Initialized
INFO - 2018-02-15 14:46:40 --> Output Class Initialized
INFO - 2018-02-15 14:46:40 --> Security Class Initialized
DEBUG - 2018-02-15 14:46:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 14:46:40 --> Input Class Initialized
INFO - 2018-02-15 14:46:40 --> Language Class Initialized
INFO - 2018-02-15 14:46:40 --> Loader Class Initialized
INFO - 2018-02-15 14:46:40 --> Helper loaded: url_helper
INFO - 2018-02-15 14:46:40 --> Helper loaded: file_helper
INFO - 2018-02-15 14:46:40 --> Helper loaded: email_helper
INFO - 2018-02-15 14:46:40 --> Helper loaded: common_helper
INFO - 2018-02-15 14:46:40 --> Database Driver Class Initialized
DEBUG - 2018-02-15 14:46:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 14:46:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 14:46:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 14:46:40 --> Pagination Class Initialized
INFO - 2018-02-15 14:46:40 --> Helper loaded: form_helper
INFO - 2018-02-15 14:46:40 --> Form Validation Class Initialized
INFO - 2018-02-15 14:46:40 --> Model Class Initialized
INFO - 2018-02-15 14:46:40 --> Controller Class Initialized
INFO - 2018-02-15 14:46:40 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 14:46:40 --> Model Class Initialized
INFO - 2018-02-15 14:46:40 --> Model Class Initialized
INFO - 2018-02-15 14:46:40 --> Model Class Initialized
INFO - 2018-02-15 14:46:56 --> Config Class Initialized
INFO - 2018-02-15 14:46:56 --> Hooks Class Initialized
DEBUG - 2018-02-15 14:46:56 --> UTF-8 Support Enabled
INFO - 2018-02-15 14:46:56 --> Utf8 Class Initialized
INFO - 2018-02-15 14:46:56 --> URI Class Initialized
INFO - 2018-02-15 14:46:56 --> Router Class Initialized
INFO - 2018-02-15 14:46:56 --> Output Class Initialized
INFO - 2018-02-15 14:46:56 --> Security Class Initialized
DEBUG - 2018-02-15 14:46:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 14:46:56 --> Input Class Initialized
INFO - 2018-02-15 14:46:56 --> Language Class Initialized
INFO - 2018-02-15 14:46:56 --> Loader Class Initialized
INFO - 2018-02-15 14:46:56 --> Helper loaded: url_helper
INFO - 2018-02-15 14:46:56 --> Helper loaded: file_helper
INFO - 2018-02-15 14:46:56 --> Helper loaded: email_helper
INFO - 2018-02-15 14:46:56 --> Helper loaded: common_helper
INFO - 2018-02-15 14:46:56 --> Database Driver Class Initialized
DEBUG - 2018-02-15 14:46:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 14:46:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 14:46:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 14:46:56 --> Pagination Class Initialized
INFO - 2018-02-15 14:46:56 --> Helper loaded: form_helper
INFO - 2018-02-15 14:46:56 --> Form Validation Class Initialized
INFO - 2018-02-15 14:46:56 --> Model Class Initialized
INFO - 2018-02-15 14:46:56 --> Controller Class Initialized
INFO - 2018-02-15 14:46:56 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 14:46:56 --> Model Class Initialized
INFO - 2018-02-15 14:46:56 --> Model Class Initialized
INFO - 2018-02-15 14:46:56 --> Model Class Initialized
INFO - 2018-02-15 14:46:57 --> Config Class Initialized
INFO - 2018-02-15 14:46:57 --> Hooks Class Initialized
DEBUG - 2018-02-15 14:46:57 --> UTF-8 Support Enabled
INFO - 2018-02-15 14:46:57 --> Utf8 Class Initialized
INFO - 2018-02-15 14:46:57 --> URI Class Initialized
INFO - 2018-02-15 14:46:57 --> Router Class Initialized
INFO - 2018-02-15 14:46:57 --> Output Class Initialized
INFO - 2018-02-15 14:46:57 --> Security Class Initialized
DEBUG - 2018-02-15 14:46:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 14:46:57 --> Input Class Initialized
INFO - 2018-02-15 14:46:57 --> Language Class Initialized
INFO - 2018-02-15 14:46:57 --> Loader Class Initialized
INFO - 2018-02-15 14:46:57 --> Helper loaded: url_helper
INFO - 2018-02-15 14:46:57 --> Helper loaded: file_helper
INFO - 2018-02-15 14:46:57 --> Helper loaded: email_helper
INFO - 2018-02-15 14:46:57 --> Helper loaded: common_helper
INFO - 2018-02-15 14:46:57 --> Database Driver Class Initialized
DEBUG - 2018-02-15 14:46:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 14:46:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 14:46:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 14:46:57 --> Pagination Class Initialized
INFO - 2018-02-15 14:46:57 --> Helper loaded: form_helper
INFO - 2018-02-15 14:46:57 --> Form Validation Class Initialized
INFO - 2018-02-15 14:46:57 --> Model Class Initialized
INFO - 2018-02-15 14:46:57 --> Controller Class Initialized
INFO - 2018-02-15 14:46:57 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 14:46:57 --> Model Class Initialized
INFO - 2018-02-15 14:46:57 --> Model Class Initialized
INFO - 2018-02-15 14:46:57 --> Model Class Initialized
INFO - 2018-02-15 14:46:57 --> Config Class Initialized
INFO - 2018-02-15 14:46:57 --> Hooks Class Initialized
DEBUG - 2018-02-15 14:46:57 --> UTF-8 Support Enabled
INFO - 2018-02-15 14:46:57 --> Utf8 Class Initialized
INFO - 2018-02-15 14:46:57 --> URI Class Initialized
INFO - 2018-02-15 14:46:57 --> Router Class Initialized
INFO - 2018-02-15 14:46:57 --> Output Class Initialized
INFO - 2018-02-15 14:46:57 --> Security Class Initialized
DEBUG - 2018-02-15 14:46:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 14:46:57 --> Input Class Initialized
INFO - 2018-02-15 14:46:57 --> Language Class Initialized
INFO - 2018-02-15 14:46:57 --> Loader Class Initialized
INFO - 2018-02-15 14:46:57 --> Helper loaded: url_helper
INFO - 2018-02-15 14:46:57 --> Helper loaded: file_helper
INFO - 2018-02-15 14:46:57 --> Helper loaded: email_helper
INFO - 2018-02-15 14:46:57 --> Helper loaded: common_helper
INFO - 2018-02-15 14:46:57 --> Database Driver Class Initialized
DEBUG - 2018-02-15 14:46:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 14:46:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 14:46:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 14:46:57 --> Pagination Class Initialized
INFO - 2018-02-15 14:46:57 --> Helper loaded: form_helper
INFO - 2018-02-15 14:46:57 --> Form Validation Class Initialized
INFO - 2018-02-15 14:46:57 --> Model Class Initialized
INFO - 2018-02-15 14:46:57 --> Controller Class Initialized
INFO - 2018-02-15 14:46:57 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 14:46:57 --> Model Class Initialized
INFO - 2018-02-15 14:46:57 --> Model Class Initialized
INFO - 2018-02-15 14:46:57 --> Model Class Initialized
INFO - 2018-02-15 14:46:58 --> Config Class Initialized
INFO - 2018-02-15 14:46:58 --> Hooks Class Initialized
DEBUG - 2018-02-15 14:46:58 --> UTF-8 Support Enabled
INFO - 2018-02-15 14:46:58 --> Utf8 Class Initialized
INFO - 2018-02-15 14:46:58 --> URI Class Initialized
INFO - 2018-02-15 14:46:58 --> Router Class Initialized
INFO - 2018-02-15 14:46:58 --> Output Class Initialized
INFO - 2018-02-15 14:46:58 --> Security Class Initialized
DEBUG - 2018-02-15 14:46:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 14:46:58 --> Input Class Initialized
INFO - 2018-02-15 14:46:58 --> Language Class Initialized
INFO - 2018-02-15 14:46:58 --> Loader Class Initialized
INFO - 2018-02-15 14:46:58 --> Helper loaded: url_helper
INFO - 2018-02-15 14:46:58 --> Helper loaded: file_helper
INFO - 2018-02-15 14:46:58 --> Helper loaded: email_helper
INFO - 2018-02-15 14:46:58 --> Helper loaded: common_helper
INFO - 2018-02-15 14:46:58 --> Database Driver Class Initialized
DEBUG - 2018-02-15 14:46:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 14:46:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 14:46:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 14:46:58 --> Pagination Class Initialized
INFO - 2018-02-15 14:46:58 --> Helper loaded: form_helper
INFO - 2018-02-15 14:46:58 --> Form Validation Class Initialized
INFO - 2018-02-15 14:46:58 --> Model Class Initialized
INFO - 2018-02-15 14:46:58 --> Controller Class Initialized
INFO - 2018-02-15 14:46:58 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 14:46:58 --> Model Class Initialized
INFO - 2018-02-15 14:46:58 --> Model Class Initialized
INFO - 2018-02-15 14:46:58 --> Model Class Initialized
INFO - 2018-02-15 14:47:42 --> Config Class Initialized
INFO - 2018-02-15 14:47:42 --> Hooks Class Initialized
DEBUG - 2018-02-15 14:47:42 --> UTF-8 Support Enabled
INFO - 2018-02-15 14:47:42 --> Utf8 Class Initialized
INFO - 2018-02-15 14:47:42 --> URI Class Initialized
INFO - 2018-02-15 14:47:42 --> Router Class Initialized
INFO - 2018-02-15 14:47:42 --> Output Class Initialized
INFO - 2018-02-15 14:47:42 --> Security Class Initialized
DEBUG - 2018-02-15 14:47:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 14:47:42 --> Input Class Initialized
INFO - 2018-02-15 14:47:42 --> Language Class Initialized
INFO - 2018-02-15 14:47:42 --> Loader Class Initialized
INFO - 2018-02-15 14:47:42 --> Helper loaded: url_helper
INFO - 2018-02-15 14:47:42 --> Helper loaded: file_helper
INFO - 2018-02-15 14:47:42 --> Helper loaded: email_helper
INFO - 2018-02-15 14:47:42 --> Helper loaded: common_helper
INFO - 2018-02-15 14:47:42 --> Database Driver Class Initialized
DEBUG - 2018-02-15 14:47:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 14:47:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 14:47:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 14:47:42 --> Pagination Class Initialized
INFO - 2018-02-15 14:47:42 --> Helper loaded: form_helper
INFO - 2018-02-15 14:47:42 --> Form Validation Class Initialized
INFO - 2018-02-15 14:47:42 --> Model Class Initialized
INFO - 2018-02-15 14:47:42 --> Controller Class Initialized
INFO - 2018-02-15 14:47:42 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 14:47:42 --> Model Class Initialized
INFO - 2018-02-15 14:47:42 --> Model Class Initialized
INFO - 2018-02-15 14:47:42 --> Model Class Initialized
INFO - 2018-02-15 14:47:42 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-15 14:47:42 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-15 14:47:42 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-15 14:47:42 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-15 14:47:42 --> File loaded: /var/www/html/project/radio/application/views/tracks/index.php
INFO - 2018-02-15 14:47:42 --> Final output sent to browser
DEBUG - 2018-02-15 14:47:42 --> Total execution time: 0.0054
INFO - 2018-02-15 14:47:43 --> Config Class Initialized
INFO - 2018-02-15 14:47:43 --> Hooks Class Initialized
DEBUG - 2018-02-15 14:47:43 --> UTF-8 Support Enabled
INFO - 2018-02-15 14:47:43 --> Utf8 Class Initialized
INFO - 2018-02-15 14:47:43 --> URI Class Initialized
INFO - 2018-02-15 14:47:43 --> Router Class Initialized
INFO - 2018-02-15 14:47:43 --> Output Class Initialized
INFO - 2018-02-15 14:47:43 --> Security Class Initialized
DEBUG - 2018-02-15 14:47:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 14:47:43 --> Input Class Initialized
INFO - 2018-02-15 14:47:43 --> Language Class Initialized
INFO - 2018-02-15 14:47:43 --> Loader Class Initialized
INFO - 2018-02-15 14:47:43 --> Helper loaded: url_helper
INFO - 2018-02-15 14:47:43 --> Helper loaded: file_helper
INFO - 2018-02-15 14:47:43 --> Helper loaded: email_helper
INFO - 2018-02-15 14:47:43 --> Helper loaded: common_helper
INFO - 2018-02-15 14:47:43 --> Database Driver Class Initialized
DEBUG - 2018-02-15 14:47:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 14:47:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 14:47:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 14:47:43 --> Pagination Class Initialized
INFO - 2018-02-15 14:47:43 --> Helper loaded: form_helper
INFO - 2018-02-15 14:47:43 --> Form Validation Class Initialized
INFO - 2018-02-15 14:47:43 --> Model Class Initialized
INFO - 2018-02-15 14:47:43 --> Controller Class Initialized
INFO - 2018-02-15 14:47:43 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 14:47:43 --> Model Class Initialized
INFO - 2018-02-15 14:47:43 --> Model Class Initialized
INFO - 2018-02-15 14:47:43 --> Model Class Initialized
INFO - 2018-02-15 14:47:48 --> Config Class Initialized
INFO - 2018-02-15 14:47:48 --> Hooks Class Initialized
DEBUG - 2018-02-15 14:47:48 --> UTF-8 Support Enabled
INFO - 2018-02-15 14:47:48 --> Utf8 Class Initialized
INFO - 2018-02-15 14:47:48 --> URI Class Initialized
INFO - 2018-02-15 14:47:48 --> Router Class Initialized
INFO - 2018-02-15 14:47:48 --> Output Class Initialized
INFO - 2018-02-15 14:47:48 --> Security Class Initialized
DEBUG - 2018-02-15 14:47:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 14:47:48 --> Input Class Initialized
INFO - 2018-02-15 14:47:48 --> Language Class Initialized
INFO - 2018-02-15 14:47:48 --> Loader Class Initialized
INFO - 2018-02-15 14:47:48 --> Helper loaded: url_helper
INFO - 2018-02-15 14:47:48 --> Helper loaded: file_helper
INFO - 2018-02-15 14:47:48 --> Helper loaded: email_helper
INFO - 2018-02-15 14:47:48 --> Helper loaded: common_helper
INFO - 2018-02-15 14:47:48 --> Database Driver Class Initialized
DEBUG - 2018-02-15 14:47:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 14:47:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 14:47:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 14:47:48 --> Pagination Class Initialized
INFO - 2018-02-15 14:47:48 --> Helper loaded: form_helper
INFO - 2018-02-15 14:47:48 --> Form Validation Class Initialized
INFO - 2018-02-15 14:47:48 --> Model Class Initialized
INFO - 2018-02-15 14:47:48 --> Controller Class Initialized
INFO - 2018-02-15 14:47:48 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 14:47:48 --> Model Class Initialized
INFO - 2018-02-15 14:47:48 --> Model Class Initialized
INFO - 2018-02-15 14:47:48 --> Model Class Initialized
INFO - 2018-02-15 14:47:48 --> Config Class Initialized
INFO - 2018-02-15 14:47:48 --> Hooks Class Initialized
DEBUG - 2018-02-15 14:47:48 --> UTF-8 Support Enabled
INFO - 2018-02-15 14:47:48 --> Utf8 Class Initialized
INFO - 2018-02-15 14:47:48 --> URI Class Initialized
INFO - 2018-02-15 14:47:48 --> Router Class Initialized
INFO - 2018-02-15 14:47:48 --> Output Class Initialized
INFO - 2018-02-15 14:47:48 --> Security Class Initialized
DEBUG - 2018-02-15 14:47:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 14:47:48 --> Input Class Initialized
INFO - 2018-02-15 14:47:48 --> Language Class Initialized
INFO - 2018-02-15 14:47:48 --> Loader Class Initialized
INFO - 2018-02-15 14:47:48 --> Helper loaded: url_helper
INFO - 2018-02-15 14:47:48 --> Helper loaded: file_helper
INFO - 2018-02-15 14:47:48 --> Helper loaded: email_helper
INFO - 2018-02-15 14:47:48 --> Helper loaded: common_helper
INFO - 2018-02-15 14:47:48 --> Database Driver Class Initialized
DEBUG - 2018-02-15 14:47:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 14:47:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 14:47:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 14:47:48 --> Pagination Class Initialized
INFO - 2018-02-15 14:47:48 --> Helper loaded: form_helper
INFO - 2018-02-15 14:47:48 --> Form Validation Class Initialized
INFO - 2018-02-15 14:47:48 --> Model Class Initialized
INFO - 2018-02-15 14:47:48 --> Controller Class Initialized
INFO - 2018-02-15 14:47:48 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 14:47:48 --> Model Class Initialized
INFO - 2018-02-15 14:47:48 --> Model Class Initialized
INFO - 2018-02-15 14:47:48 --> Model Class Initialized
INFO - 2018-02-15 14:47:48 --> Config Class Initialized
INFO - 2018-02-15 14:47:48 --> Hooks Class Initialized
DEBUG - 2018-02-15 14:47:48 --> UTF-8 Support Enabled
INFO - 2018-02-15 14:47:48 --> Utf8 Class Initialized
INFO - 2018-02-15 14:47:48 --> URI Class Initialized
INFO - 2018-02-15 14:47:48 --> Router Class Initialized
INFO - 2018-02-15 14:47:48 --> Output Class Initialized
INFO - 2018-02-15 14:47:48 --> Security Class Initialized
DEBUG - 2018-02-15 14:47:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 14:47:48 --> Input Class Initialized
INFO - 2018-02-15 14:47:48 --> Language Class Initialized
INFO - 2018-02-15 14:47:48 --> Loader Class Initialized
INFO - 2018-02-15 14:47:48 --> Helper loaded: url_helper
INFO - 2018-02-15 14:47:48 --> Helper loaded: file_helper
INFO - 2018-02-15 14:47:48 --> Helper loaded: email_helper
INFO - 2018-02-15 14:47:48 --> Helper loaded: common_helper
INFO - 2018-02-15 14:47:48 --> Database Driver Class Initialized
DEBUG - 2018-02-15 14:47:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 14:47:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 14:47:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 14:47:48 --> Pagination Class Initialized
INFO - 2018-02-15 14:47:48 --> Helper loaded: form_helper
INFO - 2018-02-15 14:47:48 --> Form Validation Class Initialized
INFO - 2018-02-15 14:47:48 --> Model Class Initialized
INFO - 2018-02-15 14:47:48 --> Controller Class Initialized
INFO - 2018-02-15 14:47:48 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 14:47:48 --> Model Class Initialized
INFO - 2018-02-15 14:47:48 --> Model Class Initialized
INFO - 2018-02-15 14:47:48 --> Model Class Initialized
INFO - 2018-02-15 14:47:49 --> Config Class Initialized
INFO - 2018-02-15 14:47:49 --> Hooks Class Initialized
DEBUG - 2018-02-15 14:47:49 --> UTF-8 Support Enabled
INFO - 2018-02-15 14:47:49 --> Utf8 Class Initialized
INFO - 2018-02-15 14:47:49 --> URI Class Initialized
INFO - 2018-02-15 14:47:49 --> Router Class Initialized
INFO - 2018-02-15 14:47:49 --> Output Class Initialized
INFO - 2018-02-15 14:47:49 --> Security Class Initialized
DEBUG - 2018-02-15 14:47:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 14:47:49 --> Input Class Initialized
INFO - 2018-02-15 14:47:49 --> Language Class Initialized
INFO - 2018-02-15 14:47:49 --> Loader Class Initialized
INFO - 2018-02-15 14:47:49 --> Helper loaded: url_helper
INFO - 2018-02-15 14:47:49 --> Helper loaded: file_helper
INFO - 2018-02-15 14:47:49 --> Helper loaded: email_helper
INFO - 2018-02-15 14:47:49 --> Helper loaded: common_helper
INFO - 2018-02-15 14:47:49 --> Database Driver Class Initialized
DEBUG - 2018-02-15 14:47:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 14:47:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 14:47:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 14:47:49 --> Pagination Class Initialized
INFO - 2018-02-15 14:47:49 --> Helper loaded: form_helper
INFO - 2018-02-15 14:47:49 --> Form Validation Class Initialized
INFO - 2018-02-15 14:47:49 --> Model Class Initialized
INFO - 2018-02-15 14:47:49 --> Controller Class Initialized
INFO - 2018-02-15 14:47:49 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 14:47:49 --> Model Class Initialized
INFO - 2018-02-15 14:47:49 --> Model Class Initialized
INFO - 2018-02-15 14:47:49 --> Model Class Initialized
INFO - 2018-02-15 14:47:50 --> Config Class Initialized
INFO - 2018-02-15 14:47:50 --> Hooks Class Initialized
DEBUG - 2018-02-15 14:47:50 --> UTF-8 Support Enabled
INFO - 2018-02-15 14:47:50 --> Utf8 Class Initialized
INFO - 2018-02-15 14:47:50 --> URI Class Initialized
INFO - 2018-02-15 14:47:50 --> Router Class Initialized
INFO - 2018-02-15 14:47:50 --> Output Class Initialized
INFO - 2018-02-15 14:47:50 --> Security Class Initialized
DEBUG - 2018-02-15 14:47:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 14:47:50 --> Input Class Initialized
INFO - 2018-02-15 14:47:50 --> Language Class Initialized
INFO - 2018-02-15 14:47:50 --> Loader Class Initialized
INFO - 2018-02-15 14:47:50 --> Helper loaded: url_helper
INFO - 2018-02-15 14:47:50 --> Helper loaded: file_helper
INFO - 2018-02-15 14:47:50 --> Helper loaded: email_helper
INFO - 2018-02-15 14:47:50 --> Helper loaded: common_helper
INFO - 2018-02-15 14:47:50 --> Database Driver Class Initialized
DEBUG - 2018-02-15 14:47:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 14:47:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 14:47:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 14:47:50 --> Pagination Class Initialized
INFO - 2018-02-15 14:47:50 --> Helper loaded: form_helper
INFO - 2018-02-15 14:47:50 --> Form Validation Class Initialized
INFO - 2018-02-15 14:47:50 --> Model Class Initialized
INFO - 2018-02-15 14:47:50 --> Controller Class Initialized
INFO - 2018-02-15 14:47:50 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 14:47:50 --> Model Class Initialized
INFO - 2018-02-15 14:47:50 --> Model Class Initialized
INFO - 2018-02-15 14:47:50 --> Model Class Initialized
INFO - 2018-02-15 14:47:50 --> Config Class Initialized
INFO - 2018-02-15 14:47:50 --> Hooks Class Initialized
DEBUG - 2018-02-15 14:47:50 --> UTF-8 Support Enabled
INFO - 2018-02-15 14:47:50 --> Utf8 Class Initialized
INFO - 2018-02-15 14:47:50 --> URI Class Initialized
INFO - 2018-02-15 14:47:50 --> Router Class Initialized
INFO - 2018-02-15 14:47:50 --> Output Class Initialized
INFO - 2018-02-15 14:47:50 --> Security Class Initialized
DEBUG - 2018-02-15 14:47:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 14:47:50 --> Input Class Initialized
INFO - 2018-02-15 14:47:50 --> Language Class Initialized
INFO - 2018-02-15 14:47:50 --> Loader Class Initialized
INFO - 2018-02-15 14:47:50 --> Helper loaded: url_helper
INFO - 2018-02-15 14:47:50 --> Helper loaded: file_helper
INFO - 2018-02-15 14:47:50 --> Helper loaded: email_helper
INFO - 2018-02-15 14:47:50 --> Helper loaded: common_helper
INFO - 2018-02-15 14:47:50 --> Database Driver Class Initialized
DEBUG - 2018-02-15 14:47:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 14:47:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 14:47:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 14:47:50 --> Pagination Class Initialized
INFO - 2018-02-15 14:47:50 --> Helper loaded: form_helper
INFO - 2018-02-15 14:47:50 --> Form Validation Class Initialized
INFO - 2018-02-15 14:47:50 --> Model Class Initialized
INFO - 2018-02-15 14:47:50 --> Controller Class Initialized
INFO - 2018-02-15 14:47:50 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 14:47:50 --> Model Class Initialized
INFO - 2018-02-15 14:47:50 --> Model Class Initialized
INFO - 2018-02-15 14:47:50 --> Model Class Initialized
INFO - 2018-02-15 14:47:50 --> Config Class Initialized
INFO - 2018-02-15 14:47:50 --> Hooks Class Initialized
DEBUG - 2018-02-15 14:47:50 --> UTF-8 Support Enabled
INFO - 2018-02-15 14:47:50 --> Utf8 Class Initialized
INFO - 2018-02-15 14:47:50 --> URI Class Initialized
INFO - 2018-02-15 14:47:50 --> Router Class Initialized
INFO - 2018-02-15 14:47:50 --> Output Class Initialized
INFO - 2018-02-15 14:47:50 --> Security Class Initialized
DEBUG - 2018-02-15 14:47:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 14:47:50 --> Input Class Initialized
INFO - 2018-02-15 14:47:50 --> Language Class Initialized
INFO - 2018-02-15 14:47:50 --> Loader Class Initialized
INFO - 2018-02-15 14:47:50 --> Helper loaded: url_helper
INFO - 2018-02-15 14:47:50 --> Helper loaded: file_helper
INFO - 2018-02-15 14:47:50 --> Helper loaded: email_helper
INFO - 2018-02-15 14:47:50 --> Helper loaded: common_helper
INFO - 2018-02-15 14:47:50 --> Database Driver Class Initialized
DEBUG - 2018-02-15 14:47:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 14:47:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 14:47:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 14:47:50 --> Pagination Class Initialized
INFO - 2018-02-15 14:47:50 --> Helper loaded: form_helper
INFO - 2018-02-15 14:47:50 --> Form Validation Class Initialized
INFO - 2018-02-15 14:47:50 --> Model Class Initialized
INFO - 2018-02-15 14:47:50 --> Controller Class Initialized
INFO - 2018-02-15 14:47:50 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 14:47:50 --> Model Class Initialized
INFO - 2018-02-15 14:47:50 --> Model Class Initialized
INFO - 2018-02-15 14:47:50 --> Model Class Initialized
INFO - 2018-02-15 14:47:51 --> Config Class Initialized
INFO - 2018-02-15 14:47:51 --> Hooks Class Initialized
DEBUG - 2018-02-15 14:47:51 --> UTF-8 Support Enabled
INFO - 2018-02-15 14:47:51 --> Utf8 Class Initialized
INFO - 2018-02-15 14:47:51 --> URI Class Initialized
INFO - 2018-02-15 14:47:51 --> Router Class Initialized
INFO - 2018-02-15 14:47:51 --> Output Class Initialized
INFO - 2018-02-15 14:47:51 --> Security Class Initialized
DEBUG - 2018-02-15 14:47:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 14:47:51 --> Input Class Initialized
INFO - 2018-02-15 14:47:51 --> Language Class Initialized
INFO - 2018-02-15 14:47:51 --> Loader Class Initialized
INFO - 2018-02-15 14:47:51 --> Helper loaded: url_helper
INFO - 2018-02-15 14:47:51 --> Helper loaded: file_helper
INFO - 2018-02-15 14:47:51 --> Helper loaded: email_helper
INFO - 2018-02-15 14:47:51 --> Helper loaded: common_helper
INFO - 2018-02-15 14:47:51 --> Database Driver Class Initialized
DEBUG - 2018-02-15 14:47:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 14:47:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 14:47:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 14:47:51 --> Pagination Class Initialized
INFO - 2018-02-15 14:47:51 --> Helper loaded: form_helper
INFO - 2018-02-15 14:47:51 --> Form Validation Class Initialized
INFO - 2018-02-15 14:47:51 --> Model Class Initialized
INFO - 2018-02-15 14:47:51 --> Controller Class Initialized
INFO - 2018-02-15 14:47:51 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 14:47:51 --> Model Class Initialized
INFO - 2018-02-15 14:47:51 --> Model Class Initialized
INFO - 2018-02-15 14:47:51 --> Model Class Initialized
INFO - 2018-02-15 14:48:33 --> Config Class Initialized
INFO - 2018-02-15 14:48:33 --> Hooks Class Initialized
DEBUG - 2018-02-15 14:48:33 --> UTF-8 Support Enabled
INFO - 2018-02-15 14:48:33 --> Utf8 Class Initialized
INFO - 2018-02-15 14:48:33 --> URI Class Initialized
INFO - 2018-02-15 14:48:33 --> Router Class Initialized
INFO - 2018-02-15 14:48:33 --> Output Class Initialized
INFO - 2018-02-15 14:48:33 --> Security Class Initialized
DEBUG - 2018-02-15 14:48:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 14:48:33 --> Input Class Initialized
INFO - 2018-02-15 14:48:33 --> Language Class Initialized
INFO - 2018-02-15 14:48:33 --> Loader Class Initialized
INFO - 2018-02-15 14:48:33 --> Helper loaded: url_helper
INFO - 2018-02-15 14:48:33 --> Helper loaded: file_helper
INFO - 2018-02-15 14:48:33 --> Helper loaded: email_helper
INFO - 2018-02-15 14:48:33 --> Helper loaded: common_helper
INFO - 2018-02-15 14:48:33 --> Database Driver Class Initialized
DEBUG - 2018-02-15 14:48:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 14:48:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 14:48:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 14:48:33 --> Pagination Class Initialized
INFO - 2018-02-15 14:48:33 --> Helper loaded: form_helper
INFO - 2018-02-15 14:48:33 --> Form Validation Class Initialized
INFO - 2018-02-15 14:48:33 --> Model Class Initialized
INFO - 2018-02-15 14:48:33 --> Controller Class Initialized
INFO - 2018-02-15 14:48:33 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 14:48:33 --> Model Class Initialized
INFO - 2018-02-15 14:48:33 --> Model Class Initialized
INFO - 2018-02-15 14:48:33 --> Model Class Initialized
INFO - 2018-02-15 14:48:35 --> Config Class Initialized
INFO - 2018-02-15 14:48:35 --> Hooks Class Initialized
DEBUG - 2018-02-15 14:48:35 --> UTF-8 Support Enabled
INFO - 2018-02-15 14:48:35 --> Utf8 Class Initialized
INFO - 2018-02-15 14:48:35 --> URI Class Initialized
INFO - 2018-02-15 14:48:35 --> Router Class Initialized
INFO - 2018-02-15 14:48:35 --> Output Class Initialized
INFO - 2018-02-15 14:48:35 --> Security Class Initialized
DEBUG - 2018-02-15 14:48:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 14:48:35 --> Input Class Initialized
INFO - 2018-02-15 14:48:35 --> Language Class Initialized
INFO - 2018-02-15 14:48:35 --> Loader Class Initialized
INFO - 2018-02-15 14:48:35 --> Helper loaded: url_helper
INFO - 2018-02-15 14:48:35 --> Helper loaded: file_helper
INFO - 2018-02-15 14:48:35 --> Helper loaded: email_helper
INFO - 2018-02-15 14:48:35 --> Helper loaded: common_helper
INFO - 2018-02-15 14:48:35 --> Database Driver Class Initialized
DEBUG - 2018-02-15 14:48:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 14:48:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 14:48:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 14:48:35 --> Pagination Class Initialized
INFO - 2018-02-15 14:48:35 --> Helper loaded: form_helper
INFO - 2018-02-15 14:48:35 --> Form Validation Class Initialized
INFO - 2018-02-15 14:48:35 --> Model Class Initialized
INFO - 2018-02-15 14:48:35 --> Controller Class Initialized
INFO - 2018-02-15 14:48:35 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 14:48:35 --> Model Class Initialized
INFO - 2018-02-15 14:48:35 --> Model Class Initialized
INFO - 2018-02-15 14:48:35 --> Model Class Initialized
INFO - 2018-02-15 14:48:55 --> Config Class Initialized
INFO - 2018-02-15 14:48:55 --> Hooks Class Initialized
DEBUG - 2018-02-15 14:48:55 --> UTF-8 Support Enabled
INFO - 2018-02-15 14:48:55 --> Utf8 Class Initialized
INFO - 2018-02-15 14:48:55 --> URI Class Initialized
INFO - 2018-02-15 14:48:55 --> Router Class Initialized
INFO - 2018-02-15 14:48:55 --> Output Class Initialized
INFO - 2018-02-15 14:48:55 --> Security Class Initialized
DEBUG - 2018-02-15 14:48:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 14:48:55 --> Input Class Initialized
INFO - 2018-02-15 14:48:55 --> Language Class Initialized
INFO - 2018-02-15 14:48:55 --> Loader Class Initialized
INFO - 2018-02-15 14:48:55 --> Helper loaded: url_helper
INFO - 2018-02-15 14:48:55 --> Helper loaded: file_helper
INFO - 2018-02-15 14:48:55 --> Helper loaded: email_helper
INFO - 2018-02-15 14:48:55 --> Helper loaded: common_helper
INFO - 2018-02-15 14:48:55 --> Database Driver Class Initialized
DEBUG - 2018-02-15 14:48:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 14:48:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 14:48:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 14:48:55 --> Pagination Class Initialized
INFO - 2018-02-15 14:48:55 --> Helper loaded: form_helper
INFO - 2018-02-15 14:48:55 --> Form Validation Class Initialized
INFO - 2018-02-15 14:48:55 --> Model Class Initialized
INFO - 2018-02-15 14:48:55 --> Controller Class Initialized
INFO - 2018-02-15 14:48:55 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 14:48:55 --> Model Class Initialized
INFO - 2018-02-15 14:48:55 --> Model Class Initialized
INFO - 2018-02-15 14:48:55 --> Model Class Initialized
ERROR - 2018-02-15 14:48:55 --> Severity: Notice --> Undefined index: order /var/www/html/project/radio/application/controllers/Tracks.php 29
ERROR - 2018-02-15 14:48:55 --> Severity: Notice --> Undefined index: order /var/www/html/project/radio/application/controllers/Tracks.php 31
ERROR - 2018-02-15 14:48:55 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'DESC' at line 5 - Invalid query: SELECT `t`.*, `c`.`vTitle` as `category`, `sc`.`vTitle` as `subcategory`
FROM `Tracks` as `t`
JOIN `SubCategory` as `sc` ON `sc`.`iSubCategoryId` = `t`.`iSubCategoryId`
JOIN `Category` as `c` ON `c`.`iCategoryId` = `t`.`iCategoryId`
ORDER BY  DESC
INFO - 2018-02-15 14:48:55 --> Language file loaded: language/english/db_lang.php
INFO - 2018-02-15 14:49:23 --> Config Class Initialized
INFO - 2018-02-15 14:49:23 --> Hooks Class Initialized
DEBUG - 2018-02-15 14:49:23 --> UTF-8 Support Enabled
INFO - 2018-02-15 14:49:23 --> Utf8 Class Initialized
INFO - 2018-02-15 14:49:23 --> URI Class Initialized
INFO - 2018-02-15 14:49:23 --> Router Class Initialized
INFO - 2018-02-15 14:49:23 --> Output Class Initialized
INFO - 2018-02-15 14:49:23 --> Security Class Initialized
DEBUG - 2018-02-15 14:49:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 14:49:23 --> Input Class Initialized
INFO - 2018-02-15 14:49:23 --> Language Class Initialized
INFO - 2018-02-15 14:49:23 --> Loader Class Initialized
INFO - 2018-02-15 14:49:23 --> Helper loaded: url_helper
INFO - 2018-02-15 14:49:23 --> Helper loaded: file_helper
INFO - 2018-02-15 14:49:23 --> Helper loaded: email_helper
INFO - 2018-02-15 14:49:23 --> Helper loaded: common_helper
INFO - 2018-02-15 14:49:23 --> Database Driver Class Initialized
DEBUG - 2018-02-15 14:49:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 14:49:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 14:49:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 14:49:23 --> Pagination Class Initialized
INFO - 2018-02-15 14:49:23 --> Helper loaded: form_helper
INFO - 2018-02-15 14:49:23 --> Form Validation Class Initialized
INFO - 2018-02-15 14:49:23 --> Model Class Initialized
INFO - 2018-02-15 14:49:23 --> Controller Class Initialized
INFO - 2018-02-15 14:49:23 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 14:49:23 --> Model Class Initialized
INFO - 2018-02-15 14:49:23 --> Model Class Initialized
INFO - 2018-02-15 14:49:23 --> Model Class Initialized
INFO - 2018-02-15 14:50:03 --> Config Class Initialized
INFO - 2018-02-15 14:50:03 --> Hooks Class Initialized
DEBUG - 2018-02-15 14:50:03 --> UTF-8 Support Enabled
INFO - 2018-02-15 14:50:03 --> Utf8 Class Initialized
INFO - 2018-02-15 14:50:03 --> URI Class Initialized
INFO - 2018-02-15 14:50:03 --> Router Class Initialized
INFO - 2018-02-15 14:50:03 --> Output Class Initialized
INFO - 2018-02-15 14:50:03 --> Security Class Initialized
DEBUG - 2018-02-15 14:50:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 14:50:03 --> Input Class Initialized
INFO - 2018-02-15 14:50:03 --> Language Class Initialized
INFO - 2018-02-15 14:50:03 --> Loader Class Initialized
INFO - 2018-02-15 14:50:03 --> Helper loaded: url_helper
INFO - 2018-02-15 14:50:03 --> Helper loaded: file_helper
INFO - 2018-02-15 14:50:03 --> Helper loaded: email_helper
INFO - 2018-02-15 14:50:03 --> Helper loaded: common_helper
INFO - 2018-02-15 14:50:03 --> Database Driver Class Initialized
DEBUG - 2018-02-15 14:50:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 14:50:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 14:50:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 14:50:03 --> Pagination Class Initialized
INFO - 2018-02-15 14:50:03 --> Helper loaded: form_helper
INFO - 2018-02-15 14:50:03 --> Form Validation Class Initialized
INFO - 2018-02-15 14:50:03 --> Model Class Initialized
INFO - 2018-02-15 14:50:03 --> Controller Class Initialized
INFO - 2018-02-15 14:50:03 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 14:50:03 --> Model Class Initialized
INFO - 2018-02-15 14:50:03 --> Model Class Initialized
INFO - 2018-02-15 14:50:03 --> Model Class Initialized
INFO - 2018-02-15 14:50:03 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-15 14:50:03 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-15 14:50:03 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-15 14:50:03 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-15 14:50:03 --> File loaded: /var/www/html/project/radio/application/views/tracks/index.php
INFO - 2018-02-15 14:50:03 --> Final output sent to browser
DEBUG - 2018-02-15 14:50:03 --> Total execution time: 0.0061
INFO - 2018-02-15 14:50:04 --> Config Class Initialized
INFO - 2018-02-15 14:50:04 --> Hooks Class Initialized
DEBUG - 2018-02-15 14:50:04 --> UTF-8 Support Enabled
INFO - 2018-02-15 14:50:04 --> Utf8 Class Initialized
INFO - 2018-02-15 14:50:04 --> URI Class Initialized
INFO - 2018-02-15 14:50:04 --> Router Class Initialized
INFO - 2018-02-15 14:50:04 --> Output Class Initialized
INFO - 2018-02-15 14:50:04 --> Security Class Initialized
DEBUG - 2018-02-15 14:50:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 14:50:04 --> Input Class Initialized
INFO - 2018-02-15 14:50:04 --> Language Class Initialized
INFO - 2018-02-15 14:50:04 --> Loader Class Initialized
INFO - 2018-02-15 14:50:04 --> Helper loaded: url_helper
INFO - 2018-02-15 14:50:04 --> Helper loaded: file_helper
INFO - 2018-02-15 14:50:04 --> Helper loaded: email_helper
INFO - 2018-02-15 14:50:04 --> Helper loaded: common_helper
INFO - 2018-02-15 14:50:04 --> Database Driver Class Initialized
DEBUG - 2018-02-15 14:50:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 14:50:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 14:50:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 14:50:04 --> Pagination Class Initialized
INFO - 2018-02-15 14:50:04 --> Helper loaded: form_helper
INFO - 2018-02-15 14:50:04 --> Form Validation Class Initialized
INFO - 2018-02-15 14:50:04 --> Model Class Initialized
INFO - 2018-02-15 14:50:04 --> Controller Class Initialized
INFO - 2018-02-15 14:50:04 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 14:50:04 --> Model Class Initialized
INFO - 2018-02-15 14:50:04 --> Model Class Initialized
INFO - 2018-02-15 14:50:04 --> Model Class Initialized
INFO - 2018-02-15 14:50:07 --> Config Class Initialized
INFO - 2018-02-15 14:50:07 --> Hooks Class Initialized
DEBUG - 2018-02-15 14:50:07 --> UTF-8 Support Enabled
INFO - 2018-02-15 14:50:07 --> Utf8 Class Initialized
INFO - 2018-02-15 14:50:07 --> URI Class Initialized
INFO - 2018-02-15 14:50:07 --> Router Class Initialized
INFO - 2018-02-15 14:50:07 --> Output Class Initialized
INFO - 2018-02-15 14:50:07 --> Security Class Initialized
DEBUG - 2018-02-15 14:50:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 14:50:07 --> Input Class Initialized
INFO - 2018-02-15 14:50:07 --> Language Class Initialized
INFO - 2018-02-15 14:50:07 --> Loader Class Initialized
INFO - 2018-02-15 14:50:07 --> Helper loaded: url_helper
INFO - 2018-02-15 14:50:07 --> Helper loaded: file_helper
INFO - 2018-02-15 14:50:07 --> Helper loaded: email_helper
INFO - 2018-02-15 14:50:07 --> Helper loaded: common_helper
INFO - 2018-02-15 14:50:07 --> Database Driver Class Initialized
DEBUG - 2018-02-15 14:50:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 14:50:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 14:50:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 14:50:07 --> Pagination Class Initialized
INFO - 2018-02-15 14:50:07 --> Helper loaded: form_helper
INFO - 2018-02-15 14:50:07 --> Form Validation Class Initialized
INFO - 2018-02-15 14:50:07 --> Model Class Initialized
INFO - 2018-02-15 14:50:07 --> Controller Class Initialized
INFO - 2018-02-15 14:50:07 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 14:50:07 --> Model Class Initialized
INFO - 2018-02-15 14:50:07 --> Model Class Initialized
INFO - 2018-02-15 14:50:07 --> Model Class Initialized
INFO - 2018-02-15 14:50:07 --> Config Class Initialized
INFO - 2018-02-15 14:50:07 --> Hooks Class Initialized
DEBUG - 2018-02-15 14:50:07 --> UTF-8 Support Enabled
INFO - 2018-02-15 14:50:07 --> Utf8 Class Initialized
INFO - 2018-02-15 14:50:07 --> URI Class Initialized
INFO - 2018-02-15 14:50:07 --> Router Class Initialized
INFO - 2018-02-15 14:50:07 --> Output Class Initialized
INFO - 2018-02-15 14:50:07 --> Security Class Initialized
DEBUG - 2018-02-15 14:50:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 14:50:07 --> Input Class Initialized
INFO - 2018-02-15 14:50:07 --> Language Class Initialized
INFO - 2018-02-15 14:50:07 --> Loader Class Initialized
INFO - 2018-02-15 14:50:07 --> Helper loaded: url_helper
INFO - 2018-02-15 14:50:07 --> Helper loaded: file_helper
INFO - 2018-02-15 14:50:07 --> Helper loaded: email_helper
INFO - 2018-02-15 14:50:07 --> Helper loaded: common_helper
INFO - 2018-02-15 14:50:07 --> Database Driver Class Initialized
DEBUG - 2018-02-15 14:50:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 14:50:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 14:50:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 14:50:07 --> Pagination Class Initialized
INFO - 2018-02-15 14:50:07 --> Helper loaded: form_helper
INFO - 2018-02-15 14:50:07 --> Form Validation Class Initialized
INFO - 2018-02-15 14:50:07 --> Model Class Initialized
INFO - 2018-02-15 14:50:07 --> Controller Class Initialized
INFO - 2018-02-15 14:50:07 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 14:50:07 --> Model Class Initialized
INFO - 2018-02-15 14:50:07 --> Model Class Initialized
INFO - 2018-02-15 14:50:07 --> Model Class Initialized
INFO - 2018-02-15 14:50:47 --> Config Class Initialized
INFO - 2018-02-15 14:50:47 --> Hooks Class Initialized
DEBUG - 2018-02-15 14:50:47 --> UTF-8 Support Enabled
INFO - 2018-02-15 14:50:47 --> Utf8 Class Initialized
INFO - 2018-02-15 14:50:47 --> URI Class Initialized
INFO - 2018-02-15 14:50:47 --> Router Class Initialized
INFO - 2018-02-15 14:50:47 --> Output Class Initialized
INFO - 2018-02-15 14:50:47 --> Security Class Initialized
DEBUG - 2018-02-15 14:50:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 14:50:47 --> Input Class Initialized
INFO - 2018-02-15 14:50:47 --> Language Class Initialized
INFO - 2018-02-15 14:50:47 --> Loader Class Initialized
INFO - 2018-02-15 14:50:47 --> Helper loaded: url_helper
INFO - 2018-02-15 14:50:47 --> Helper loaded: file_helper
INFO - 2018-02-15 14:50:47 --> Helper loaded: email_helper
INFO - 2018-02-15 14:50:47 --> Helper loaded: common_helper
INFO - 2018-02-15 14:50:47 --> Database Driver Class Initialized
DEBUG - 2018-02-15 14:50:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 14:50:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 14:50:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 14:50:47 --> Pagination Class Initialized
INFO - 2018-02-15 14:50:47 --> Helper loaded: form_helper
INFO - 2018-02-15 14:50:47 --> Form Validation Class Initialized
INFO - 2018-02-15 14:50:47 --> Model Class Initialized
INFO - 2018-02-15 14:50:47 --> Controller Class Initialized
INFO - 2018-02-15 14:50:47 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 14:50:47 --> Model Class Initialized
INFO - 2018-02-15 14:50:47 --> Model Class Initialized
INFO - 2018-02-15 14:50:47 --> Model Class Initialized
INFO - 2018-02-15 14:50:47 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-15 14:50:47 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-15 14:50:47 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-15 14:50:47 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-15 14:50:47 --> File loaded: /var/www/html/project/radio/application/views/tracks/index.php
INFO - 2018-02-15 14:50:47 --> Final output sent to browser
DEBUG - 2018-02-15 14:50:47 --> Total execution time: 0.0049
INFO - 2018-02-15 14:50:47 --> Config Class Initialized
INFO - 2018-02-15 14:50:47 --> Hooks Class Initialized
DEBUG - 2018-02-15 14:50:47 --> UTF-8 Support Enabled
INFO - 2018-02-15 14:50:47 --> Utf8 Class Initialized
INFO - 2018-02-15 14:50:47 --> URI Class Initialized
INFO - 2018-02-15 14:50:47 --> Router Class Initialized
INFO - 2018-02-15 14:50:47 --> Output Class Initialized
INFO - 2018-02-15 14:50:47 --> Security Class Initialized
DEBUG - 2018-02-15 14:50:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 14:50:47 --> Input Class Initialized
INFO - 2018-02-15 14:50:47 --> Language Class Initialized
INFO - 2018-02-15 14:50:47 --> Loader Class Initialized
INFO - 2018-02-15 14:50:47 --> Helper loaded: url_helper
INFO - 2018-02-15 14:50:47 --> Helper loaded: file_helper
INFO - 2018-02-15 14:50:47 --> Helper loaded: email_helper
INFO - 2018-02-15 14:50:47 --> Helper loaded: common_helper
INFO - 2018-02-15 14:50:47 --> Database Driver Class Initialized
DEBUG - 2018-02-15 14:50:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 14:50:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 14:50:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 14:50:47 --> Pagination Class Initialized
INFO - 2018-02-15 14:50:47 --> Helper loaded: form_helper
INFO - 2018-02-15 14:50:47 --> Form Validation Class Initialized
INFO - 2018-02-15 14:50:47 --> Model Class Initialized
INFO - 2018-02-15 14:50:47 --> Controller Class Initialized
INFO - 2018-02-15 14:50:47 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 14:50:47 --> Model Class Initialized
INFO - 2018-02-15 14:50:47 --> Model Class Initialized
INFO - 2018-02-15 14:50:47 --> Model Class Initialized
INFO - 2018-02-15 14:50:50 --> Config Class Initialized
INFO - 2018-02-15 14:50:50 --> Hooks Class Initialized
DEBUG - 2018-02-15 14:50:50 --> UTF-8 Support Enabled
INFO - 2018-02-15 14:50:50 --> Utf8 Class Initialized
INFO - 2018-02-15 14:50:50 --> URI Class Initialized
INFO - 2018-02-15 14:50:50 --> Router Class Initialized
INFO - 2018-02-15 14:50:50 --> Output Class Initialized
INFO - 2018-02-15 14:50:50 --> Security Class Initialized
DEBUG - 2018-02-15 14:50:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 14:50:50 --> Input Class Initialized
INFO - 2018-02-15 14:50:50 --> Language Class Initialized
INFO - 2018-02-15 14:50:50 --> Loader Class Initialized
INFO - 2018-02-15 14:50:50 --> Helper loaded: url_helper
INFO - 2018-02-15 14:50:50 --> Helper loaded: file_helper
INFO - 2018-02-15 14:50:50 --> Helper loaded: email_helper
INFO - 2018-02-15 14:50:50 --> Helper loaded: common_helper
INFO - 2018-02-15 14:50:50 --> Database Driver Class Initialized
DEBUG - 2018-02-15 14:50:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 14:50:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 14:50:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 14:50:50 --> Pagination Class Initialized
INFO - 2018-02-15 14:50:50 --> Helper loaded: form_helper
INFO - 2018-02-15 14:50:50 --> Form Validation Class Initialized
INFO - 2018-02-15 14:50:50 --> Model Class Initialized
INFO - 2018-02-15 14:50:50 --> Controller Class Initialized
INFO - 2018-02-15 14:50:50 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 14:50:50 --> Model Class Initialized
INFO - 2018-02-15 14:50:50 --> Model Class Initialized
INFO - 2018-02-15 14:50:50 --> Model Class Initialized
INFO - 2018-02-15 14:50:51 --> Config Class Initialized
INFO - 2018-02-15 14:50:51 --> Hooks Class Initialized
DEBUG - 2018-02-15 14:50:51 --> UTF-8 Support Enabled
INFO - 2018-02-15 14:50:51 --> Utf8 Class Initialized
INFO - 2018-02-15 14:50:51 --> URI Class Initialized
INFO - 2018-02-15 14:50:51 --> Router Class Initialized
INFO - 2018-02-15 14:50:51 --> Output Class Initialized
INFO - 2018-02-15 14:50:51 --> Security Class Initialized
DEBUG - 2018-02-15 14:50:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 14:50:51 --> Input Class Initialized
INFO - 2018-02-15 14:50:51 --> Language Class Initialized
INFO - 2018-02-15 14:50:51 --> Loader Class Initialized
INFO - 2018-02-15 14:50:51 --> Helper loaded: url_helper
INFO - 2018-02-15 14:50:51 --> Helper loaded: file_helper
INFO - 2018-02-15 14:50:51 --> Helper loaded: email_helper
INFO - 2018-02-15 14:50:51 --> Helper loaded: common_helper
INFO - 2018-02-15 14:50:51 --> Database Driver Class Initialized
DEBUG - 2018-02-15 14:50:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 14:50:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 14:50:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 14:50:51 --> Pagination Class Initialized
INFO - 2018-02-15 14:50:51 --> Helper loaded: form_helper
INFO - 2018-02-15 14:50:51 --> Form Validation Class Initialized
INFO - 2018-02-15 14:50:51 --> Model Class Initialized
INFO - 2018-02-15 14:50:51 --> Controller Class Initialized
INFO - 2018-02-15 14:50:51 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 14:50:51 --> Model Class Initialized
INFO - 2018-02-15 14:50:51 --> Model Class Initialized
INFO - 2018-02-15 14:50:51 --> Model Class Initialized
INFO - 2018-02-15 14:51:39 --> Config Class Initialized
INFO - 2018-02-15 14:51:39 --> Hooks Class Initialized
DEBUG - 2018-02-15 14:51:39 --> UTF-8 Support Enabled
INFO - 2018-02-15 14:51:39 --> Utf8 Class Initialized
INFO - 2018-02-15 14:51:39 --> URI Class Initialized
INFO - 2018-02-15 14:51:39 --> Router Class Initialized
INFO - 2018-02-15 14:51:39 --> Output Class Initialized
INFO - 2018-02-15 14:51:39 --> Security Class Initialized
DEBUG - 2018-02-15 14:51:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 14:51:39 --> Input Class Initialized
INFO - 2018-02-15 14:51:39 --> Language Class Initialized
INFO - 2018-02-15 14:51:39 --> Loader Class Initialized
INFO - 2018-02-15 14:51:39 --> Helper loaded: url_helper
INFO - 2018-02-15 14:51:39 --> Helper loaded: file_helper
INFO - 2018-02-15 14:51:39 --> Helper loaded: email_helper
INFO - 2018-02-15 14:51:39 --> Helper loaded: common_helper
INFO - 2018-02-15 14:51:39 --> Database Driver Class Initialized
DEBUG - 2018-02-15 14:51:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 14:51:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 14:51:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 14:51:39 --> Pagination Class Initialized
INFO - 2018-02-15 14:51:39 --> Helper loaded: form_helper
INFO - 2018-02-15 14:51:39 --> Form Validation Class Initialized
INFO - 2018-02-15 14:51:39 --> Model Class Initialized
INFO - 2018-02-15 14:51:39 --> Controller Class Initialized
INFO - 2018-02-15 14:51:39 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 14:51:39 --> Model Class Initialized
INFO - 2018-02-15 14:51:39 --> Model Class Initialized
INFO - 2018-02-15 14:51:39 --> Model Class Initialized
INFO - 2018-02-15 14:51:39 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-15 14:51:39 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-15 14:51:39 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-15 14:51:39 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-15 14:51:39 --> File loaded: /var/www/html/project/radio/application/views/tracks/index.php
INFO - 2018-02-15 14:51:39 --> Final output sent to browser
DEBUG - 2018-02-15 14:51:39 --> Total execution time: 0.0054
INFO - 2018-02-15 14:51:39 --> Config Class Initialized
INFO - 2018-02-15 14:51:39 --> Hooks Class Initialized
DEBUG - 2018-02-15 14:51:39 --> UTF-8 Support Enabled
INFO - 2018-02-15 14:51:39 --> Utf8 Class Initialized
INFO - 2018-02-15 14:51:39 --> URI Class Initialized
INFO - 2018-02-15 14:51:39 --> Router Class Initialized
INFO - 2018-02-15 14:51:39 --> Output Class Initialized
INFO - 2018-02-15 14:51:39 --> Security Class Initialized
DEBUG - 2018-02-15 14:51:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 14:51:39 --> Input Class Initialized
INFO - 2018-02-15 14:51:39 --> Language Class Initialized
INFO - 2018-02-15 14:51:39 --> Loader Class Initialized
INFO - 2018-02-15 14:51:39 --> Helper loaded: url_helper
INFO - 2018-02-15 14:51:39 --> Helper loaded: file_helper
INFO - 2018-02-15 14:51:39 --> Helper loaded: email_helper
INFO - 2018-02-15 14:51:39 --> Helper loaded: common_helper
INFO - 2018-02-15 14:51:39 --> Database Driver Class Initialized
DEBUG - 2018-02-15 14:51:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 14:51:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 14:51:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 14:51:39 --> Pagination Class Initialized
INFO - 2018-02-15 14:51:39 --> Helper loaded: form_helper
INFO - 2018-02-15 14:51:39 --> Form Validation Class Initialized
INFO - 2018-02-15 14:51:39 --> Model Class Initialized
INFO - 2018-02-15 14:51:39 --> Controller Class Initialized
INFO - 2018-02-15 14:51:39 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 14:51:39 --> Model Class Initialized
INFO - 2018-02-15 14:51:39 --> Model Class Initialized
INFO - 2018-02-15 14:51:39 --> Model Class Initialized
INFO - 2018-02-15 14:51:43 --> Config Class Initialized
INFO - 2018-02-15 14:51:43 --> Hooks Class Initialized
DEBUG - 2018-02-15 14:51:43 --> UTF-8 Support Enabled
INFO - 2018-02-15 14:51:43 --> Utf8 Class Initialized
INFO - 2018-02-15 14:51:43 --> URI Class Initialized
INFO - 2018-02-15 14:51:43 --> Router Class Initialized
INFO - 2018-02-15 14:51:43 --> Output Class Initialized
INFO - 2018-02-15 14:51:43 --> Security Class Initialized
DEBUG - 2018-02-15 14:51:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 14:51:43 --> Input Class Initialized
INFO - 2018-02-15 14:51:43 --> Language Class Initialized
INFO - 2018-02-15 14:51:43 --> Loader Class Initialized
INFO - 2018-02-15 14:51:43 --> Helper loaded: url_helper
INFO - 2018-02-15 14:51:43 --> Helper loaded: file_helper
INFO - 2018-02-15 14:51:43 --> Helper loaded: email_helper
INFO - 2018-02-15 14:51:43 --> Helper loaded: common_helper
INFO - 2018-02-15 14:51:43 --> Database Driver Class Initialized
DEBUG - 2018-02-15 14:51:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 14:51:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 14:51:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 14:51:43 --> Pagination Class Initialized
INFO - 2018-02-15 14:51:43 --> Helper loaded: form_helper
INFO - 2018-02-15 14:51:43 --> Form Validation Class Initialized
INFO - 2018-02-15 14:51:43 --> Model Class Initialized
INFO - 2018-02-15 14:51:43 --> Controller Class Initialized
INFO - 2018-02-15 14:51:43 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 14:51:43 --> Model Class Initialized
INFO - 2018-02-15 14:51:43 --> Model Class Initialized
INFO - 2018-02-15 14:51:43 --> Model Class Initialized
INFO - 2018-02-15 14:51:43 --> Config Class Initialized
INFO - 2018-02-15 14:51:43 --> Hooks Class Initialized
DEBUG - 2018-02-15 14:51:43 --> UTF-8 Support Enabled
INFO - 2018-02-15 14:51:43 --> Utf8 Class Initialized
INFO - 2018-02-15 14:51:43 --> URI Class Initialized
INFO - 2018-02-15 14:51:43 --> Router Class Initialized
INFO - 2018-02-15 14:51:43 --> Output Class Initialized
INFO - 2018-02-15 14:51:43 --> Security Class Initialized
DEBUG - 2018-02-15 14:51:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 14:51:43 --> Input Class Initialized
INFO - 2018-02-15 14:51:43 --> Language Class Initialized
INFO - 2018-02-15 14:51:43 --> Loader Class Initialized
INFO - 2018-02-15 14:51:43 --> Helper loaded: url_helper
INFO - 2018-02-15 14:51:43 --> Helper loaded: file_helper
INFO - 2018-02-15 14:51:43 --> Helper loaded: email_helper
INFO - 2018-02-15 14:51:43 --> Helper loaded: common_helper
INFO - 2018-02-15 14:51:43 --> Database Driver Class Initialized
DEBUG - 2018-02-15 14:51:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 14:51:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 14:51:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 14:51:43 --> Pagination Class Initialized
INFO - 2018-02-15 14:51:43 --> Helper loaded: form_helper
INFO - 2018-02-15 14:51:43 --> Form Validation Class Initialized
INFO - 2018-02-15 14:51:43 --> Model Class Initialized
INFO - 2018-02-15 14:51:43 --> Controller Class Initialized
INFO - 2018-02-15 14:51:43 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 14:51:43 --> Model Class Initialized
INFO - 2018-02-15 14:51:43 --> Model Class Initialized
INFO - 2018-02-15 14:51:43 --> Model Class Initialized
INFO - 2018-02-15 14:52:23 --> Config Class Initialized
INFO - 2018-02-15 14:52:23 --> Hooks Class Initialized
DEBUG - 2018-02-15 14:52:23 --> UTF-8 Support Enabled
INFO - 2018-02-15 14:52:23 --> Utf8 Class Initialized
INFO - 2018-02-15 14:52:23 --> URI Class Initialized
INFO - 2018-02-15 14:52:23 --> Router Class Initialized
INFO - 2018-02-15 14:52:23 --> Output Class Initialized
INFO - 2018-02-15 14:52:23 --> Security Class Initialized
DEBUG - 2018-02-15 14:52:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 14:52:23 --> Input Class Initialized
INFO - 2018-02-15 14:52:23 --> Language Class Initialized
INFO - 2018-02-15 14:52:23 --> Loader Class Initialized
INFO - 2018-02-15 14:52:23 --> Helper loaded: url_helper
INFO - 2018-02-15 14:52:23 --> Helper loaded: file_helper
INFO - 2018-02-15 14:52:23 --> Helper loaded: email_helper
INFO - 2018-02-15 14:52:23 --> Helper loaded: common_helper
INFO - 2018-02-15 14:52:23 --> Database Driver Class Initialized
DEBUG - 2018-02-15 14:52:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 14:52:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 14:52:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 14:52:23 --> Pagination Class Initialized
INFO - 2018-02-15 14:52:23 --> Helper loaded: form_helper
INFO - 2018-02-15 14:52:23 --> Form Validation Class Initialized
INFO - 2018-02-15 14:52:23 --> Model Class Initialized
INFO - 2018-02-15 14:52:23 --> Controller Class Initialized
INFO - 2018-02-15 14:52:23 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 14:52:23 --> Model Class Initialized
INFO - 2018-02-15 14:52:23 --> Model Class Initialized
INFO - 2018-02-15 14:52:23 --> Model Class Initialized
INFO - 2018-02-15 14:52:23 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-15 14:52:23 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-15 14:52:23 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-15 14:52:23 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-15 14:52:23 --> File loaded: /var/www/html/project/radio/application/views/tracks/index.php
INFO - 2018-02-15 14:52:23 --> Final output sent to browser
DEBUG - 2018-02-15 14:52:23 --> Total execution time: 0.0056
INFO - 2018-02-15 14:52:24 --> Config Class Initialized
INFO - 2018-02-15 14:52:24 --> Hooks Class Initialized
DEBUG - 2018-02-15 14:52:24 --> UTF-8 Support Enabled
INFO - 2018-02-15 14:52:24 --> Utf8 Class Initialized
INFO - 2018-02-15 14:52:24 --> URI Class Initialized
INFO - 2018-02-15 14:52:24 --> Router Class Initialized
INFO - 2018-02-15 14:52:24 --> Output Class Initialized
INFO - 2018-02-15 14:52:24 --> Security Class Initialized
DEBUG - 2018-02-15 14:52:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 14:52:24 --> Input Class Initialized
INFO - 2018-02-15 14:52:24 --> Language Class Initialized
INFO - 2018-02-15 14:52:24 --> Loader Class Initialized
INFO - 2018-02-15 14:52:24 --> Helper loaded: url_helper
INFO - 2018-02-15 14:52:24 --> Helper loaded: file_helper
INFO - 2018-02-15 14:52:24 --> Helper loaded: email_helper
INFO - 2018-02-15 14:52:24 --> Helper loaded: common_helper
INFO - 2018-02-15 14:52:24 --> Database Driver Class Initialized
DEBUG - 2018-02-15 14:52:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 14:52:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 14:52:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 14:52:24 --> Pagination Class Initialized
INFO - 2018-02-15 14:52:24 --> Helper loaded: form_helper
INFO - 2018-02-15 14:52:24 --> Form Validation Class Initialized
INFO - 2018-02-15 14:52:24 --> Model Class Initialized
INFO - 2018-02-15 14:52:24 --> Controller Class Initialized
INFO - 2018-02-15 14:52:24 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 14:52:24 --> Model Class Initialized
INFO - 2018-02-15 14:52:24 --> Model Class Initialized
INFO - 2018-02-15 14:52:24 --> Model Class Initialized
INFO - 2018-02-15 14:52:26 --> Config Class Initialized
INFO - 2018-02-15 14:52:26 --> Hooks Class Initialized
DEBUG - 2018-02-15 14:52:26 --> UTF-8 Support Enabled
INFO - 2018-02-15 14:52:26 --> Utf8 Class Initialized
INFO - 2018-02-15 14:52:26 --> URI Class Initialized
INFO - 2018-02-15 14:52:26 --> Router Class Initialized
INFO - 2018-02-15 14:52:26 --> Output Class Initialized
INFO - 2018-02-15 14:52:26 --> Security Class Initialized
DEBUG - 2018-02-15 14:52:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 14:52:26 --> Input Class Initialized
INFO - 2018-02-15 14:52:26 --> Language Class Initialized
INFO - 2018-02-15 14:52:26 --> Loader Class Initialized
INFO - 2018-02-15 14:52:26 --> Helper loaded: url_helper
INFO - 2018-02-15 14:52:26 --> Helper loaded: file_helper
INFO - 2018-02-15 14:52:26 --> Helper loaded: email_helper
INFO - 2018-02-15 14:52:26 --> Helper loaded: common_helper
INFO - 2018-02-15 14:52:26 --> Database Driver Class Initialized
DEBUG - 2018-02-15 14:52:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 14:52:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 14:52:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 14:52:26 --> Pagination Class Initialized
INFO - 2018-02-15 14:52:26 --> Helper loaded: form_helper
INFO - 2018-02-15 14:52:26 --> Form Validation Class Initialized
INFO - 2018-02-15 14:52:26 --> Model Class Initialized
INFO - 2018-02-15 14:52:26 --> Controller Class Initialized
INFO - 2018-02-15 14:52:26 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 14:52:26 --> Model Class Initialized
INFO - 2018-02-15 14:52:26 --> Model Class Initialized
INFO - 2018-02-15 14:52:26 --> Model Class Initialized
INFO - 2018-02-15 14:52:26 --> Config Class Initialized
INFO - 2018-02-15 14:52:26 --> Hooks Class Initialized
DEBUG - 2018-02-15 14:52:26 --> UTF-8 Support Enabled
INFO - 2018-02-15 14:52:26 --> Utf8 Class Initialized
INFO - 2018-02-15 14:52:26 --> URI Class Initialized
INFO - 2018-02-15 14:52:26 --> Router Class Initialized
INFO - 2018-02-15 14:52:26 --> Output Class Initialized
INFO - 2018-02-15 14:52:26 --> Security Class Initialized
DEBUG - 2018-02-15 14:52:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 14:52:26 --> Input Class Initialized
INFO - 2018-02-15 14:52:26 --> Language Class Initialized
INFO - 2018-02-15 14:52:26 --> Loader Class Initialized
INFO - 2018-02-15 14:52:26 --> Helper loaded: url_helper
INFO - 2018-02-15 14:52:26 --> Helper loaded: file_helper
INFO - 2018-02-15 14:52:26 --> Helper loaded: email_helper
INFO - 2018-02-15 14:52:26 --> Helper loaded: common_helper
INFO - 2018-02-15 14:52:26 --> Database Driver Class Initialized
DEBUG - 2018-02-15 14:52:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 14:52:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 14:52:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 14:52:26 --> Pagination Class Initialized
INFO - 2018-02-15 14:52:26 --> Helper loaded: form_helper
INFO - 2018-02-15 14:52:26 --> Form Validation Class Initialized
INFO - 2018-02-15 14:52:26 --> Model Class Initialized
INFO - 2018-02-15 14:52:26 --> Controller Class Initialized
INFO - 2018-02-15 14:52:26 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 14:52:26 --> Model Class Initialized
INFO - 2018-02-15 14:52:26 --> Model Class Initialized
INFO - 2018-02-15 14:52:26 --> Model Class Initialized
INFO - 2018-02-15 14:52:27 --> Config Class Initialized
INFO - 2018-02-15 14:52:27 --> Hooks Class Initialized
DEBUG - 2018-02-15 14:52:27 --> UTF-8 Support Enabled
INFO - 2018-02-15 14:52:27 --> Utf8 Class Initialized
INFO - 2018-02-15 14:52:27 --> URI Class Initialized
INFO - 2018-02-15 14:52:27 --> Router Class Initialized
INFO - 2018-02-15 14:52:27 --> Output Class Initialized
INFO - 2018-02-15 14:52:27 --> Security Class Initialized
DEBUG - 2018-02-15 14:52:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 14:52:27 --> Input Class Initialized
INFO - 2018-02-15 14:52:27 --> Language Class Initialized
INFO - 2018-02-15 14:52:27 --> Loader Class Initialized
INFO - 2018-02-15 14:52:27 --> Helper loaded: url_helper
INFO - 2018-02-15 14:52:27 --> Helper loaded: file_helper
INFO - 2018-02-15 14:52:27 --> Helper loaded: email_helper
INFO - 2018-02-15 14:52:27 --> Helper loaded: common_helper
INFO - 2018-02-15 14:52:27 --> Database Driver Class Initialized
DEBUG - 2018-02-15 14:52:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 14:52:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 14:52:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 14:52:27 --> Pagination Class Initialized
INFO - 2018-02-15 14:52:27 --> Helper loaded: form_helper
INFO - 2018-02-15 14:52:27 --> Form Validation Class Initialized
INFO - 2018-02-15 14:52:27 --> Model Class Initialized
INFO - 2018-02-15 14:52:27 --> Controller Class Initialized
INFO - 2018-02-15 14:52:27 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 14:52:27 --> Model Class Initialized
INFO - 2018-02-15 14:52:27 --> Model Class Initialized
INFO - 2018-02-15 14:52:27 --> Model Class Initialized
INFO - 2018-02-15 14:52:27 --> Config Class Initialized
INFO - 2018-02-15 14:52:27 --> Hooks Class Initialized
DEBUG - 2018-02-15 14:52:27 --> UTF-8 Support Enabled
INFO - 2018-02-15 14:52:27 --> Utf8 Class Initialized
INFO - 2018-02-15 14:52:27 --> URI Class Initialized
INFO - 2018-02-15 14:52:27 --> Router Class Initialized
INFO - 2018-02-15 14:52:27 --> Output Class Initialized
INFO - 2018-02-15 14:52:27 --> Security Class Initialized
DEBUG - 2018-02-15 14:52:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 14:52:27 --> Input Class Initialized
INFO - 2018-02-15 14:52:27 --> Language Class Initialized
INFO - 2018-02-15 14:52:27 --> Loader Class Initialized
INFO - 2018-02-15 14:52:27 --> Helper loaded: url_helper
INFO - 2018-02-15 14:52:27 --> Helper loaded: file_helper
INFO - 2018-02-15 14:52:27 --> Helper loaded: email_helper
INFO - 2018-02-15 14:52:27 --> Helper loaded: common_helper
INFO - 2018-02-15 14:52:27 --> Database Driver Class Initialized
DEBUG - 2018-02-15 14:52:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 14:52:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 14:52:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 14:52:27 --> Pagination Class Initialized
INFO - 2018-02-15 14:52:27 --> Helper loaded: form_helper
INFO - 2018-02-15 14:52:27 --> Form Validation Class Initialized
INFO - 2018-02-15 14:52:27 --> Model Class Initialized
INFO - 2018-02-15 14:52:27 --> Controller Class Initialized
INFO - 2018-02-15 14:52:27 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 14:52:27 --> Model Class Initialized
INFO - 2018-02-15 14:52:27 --> Model Class Initialized
INFO - 2018-02-15 14:52:27 --> Model Class Initialized
INFO - 2018-02-15 14:52:28 --> Config Class Initialized
INFO - 2018-02-15 14:52:28 --> Hooks Class Initialized
DEBUG - 2018-02-15 14:52:28 --> UTF-8 Support Enabled
INFO - 2018-02-15 14:52:28 --> Utf8 Class Initialized
INFO - 2018-02-15 14:52:28 --> URI Class Initialized
INFO - 2018-02-15 14:52:28 --> Router Class Initialized
INFO - 2018-02-15 14:52:28 --> Output Class Initialized
INFO - 2018-02-15 14:52:28 --> Security Class Initialized
DEBUG - 2018-02-15 14:52:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 14:52:28 --> Input Class Initialized
INFO - 2018-02-15 14:52:28 --> Language Class Initialized
INFO - 2018-02-15 14:52:28 --> Loader Class Initialized
INFO - 2018-02-15 14:52:28 --> Helper loaded: url_helper
INFO - 2018-02-15 14:52:28 --> Helper loaded: file_helper
INFO - 2018-02-15 14:52:28 --> Helper loaded: email_helper
INFO - 2018-02-15 14:52:28 --> Helper loaded: common_helper
INFO - 2018-02-15 14:52:28 --> Database Driver Class Initialized
DEBUG - 2018-02-15 14:52:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 14:52:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 14:52:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 14:52:28 --> Pagination Class Initialized
INFO - 2018-02-15 14:52:28 --> Helper loaded: form_helper
INFO - 2018-02-15 14:52:28 --> Form Validation Class Initialized
INFO - 2018-02-15 14:52:28 --> Model Class Initialized
INFO - 2018-02-15 14:52:28 --> Controller Class Initialized
INFO - 2018-02-15 14:52:28 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 14:52:28 --> Model Class Initialized
INFO - 2018-02-15 14:52:28 --> Model Class Initialized
INFO - 2018-02-15 14:52:28 --> Model Class Initialized
INFO - 2018-02-15 14:52:29 --> Config Class Initialized
INFO - 2018-02-15 14:52:29 --> Hooks Class Initialized
DEBUG - 2018-02-15 14:52:29 --> UTF-8 Support Enabled
INFO - 2018-02-15 14:52:29 --> Utf8 Class Initialized
INFO - 2018-02-15 14:52:29 --> URI Class Initialized
INFO - 2018-02-15 14:52:29 --> Router Class Initialized
INFO - 2018-02-15 14:52:29 --> Output Class Initialized
INFO - 2018-02-15 14:52:29 --> Security Class Initialized
DEBUG - 2018-02-15 14:52:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 14:52:29 --> Input Class Initialized
INFO - 2018-02-15 14:52:29 --> Language Class Initialized
INFO - 2018-02-15 14:52:29 --> Loader Class Initialized
INFO - 2018-02-15 14:52:29 --> Helper loaded: url_helper
INFO - 2018-02-15 14:52:29 --> Helper loaded: file_helper
INFO - 2018-02-15 14:52:29 --> Helper loaded: email_helper
INFO - 2018-02-15 14:52:29 --> Helper loaded: common_helper
INFO - 2018-02-15 14:52:29 --> Database Driver Class Initialized
DEBUG - 2018-02-15 14:52:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 14:52:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 14:52:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 14:52:29 --> Pagination Class Initialized
INFO - 2018-02-15 14:52:29 --> Helper loaded: form_helper
INFO - 2018-02-15 14:52:29 --> Form Validation Class Initialized
INFO - 2018-02-15 14:52:29 --> Model Class Initialized
INFO - 2018-02-15 14:52:29 --> Controller Class Initialized
INFO - 2018-02-15 14:52:29 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 14:52:29 --> Model Class Initialized
INFO - 2018-02-15 14:52:29 --> Model Class Initialized
INFO - 2018-02-15 14:52:29 --> Model Class Initialized
INFO - 2018-02-15 14:52:29 --> Config Class Initialized
INFO - 2018-02-15 14:52:29 --> Hooks Class Initialized
DEBUG - 2018-02-15 14:52:29 --> UTF-8 Support Enabled
INFO - 2018-02-15 14:52:29 --> Utf8 Class Initialized
INFO - 2018-02-15 14:52:29 --> URI Class Initialized
INFO - 2018-02-15 14:52:29 --> Router Class Initialized
INFO - 2018-02-15 14:52:29 --> Output Class Initialized
INFO - 2018-02-15 14:52:29 --> Security Class Initialized
DEBUG - 2018-02-15 14:52:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 14:52:29 --> Input Class Initialized
INFO - 2018-02-15 14:52:29 --> Language Class Initialized
INFO - 2018-02-15 14:52:29 --> Loader Class Initialized
INFO - 2018-02-15 14:52:29 --> Helper loaded: url_helper
INFO - 2018-02-15 14:52:29 --> Helper loaded: file_helper
INFO - 2018-02-15 14:52:29 --> Helper loaded: email_helper
INFO - 2018-02-15 14:52:29 --> Helper loaded: common_helper
INFO - 2018-02-15 14:52:29 --> Database Driver Class Initialized
DEBUG - 2018-02-15 14:52:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 14:52:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 14:52:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 14:52:29 --> Pagination Class Initialized
INFO - 2018-02-15 14:52:29 --> Helper loaded: form_helper
INFO - 2018-02-15 14:52:29 --> Form Validation Class Initialized
INFO - 2018-02-15 14:52:29 --> Model Class Initialized
INFO - 2018-02-15 14:52:29 --> Controller Class Initialized
INFO - 2018-02-15 14:52:29 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 14:52:29 --> Model Class Initialized
INFO - 2018-02-15 14:52:29 --> Model Class Initialized
INFO - 2018-02-15 14:52:29 --> Model Class Initialized
INFO - 2018-02-15 14:52:29 --> Config Class Initialized
INFO - 2018-02-15 14:52:29 --> Hooks Class Initialized
DEBUG - 2018-02-15 14:52:29 --> UTF-8 Support Enabled
INFO - 2018-02-15 14:52:29 --> Utf8 Class Initialized
INFO - 2018-02-15 14:52:29 --> URI Class Initialized
INFO - 2018-02-15 14:52:29 --> Router Class Initialized
INFO - 2018-02-15 14:52:29 --> Output Class Initialized
INFO - 2018-02-15 14:52:29 --> Security Class Initialized
DEBUG - 2018-02-15 14:52:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 14:52:29 --> Input Class Initialized
INFO - 2018-02-15 14:52:29 --> Language Class Initialized
INFO - 2018-02-15 14:52:29 --> Loader Class Initialized
INFO - 2018-02-15 14:52:29 --> Helper loaded: url_helper
INFO - 2018-02-15 14:52:29 --> Helper loaded: file_helper
INFO - 2018-02-15 14:52:29 --> Helper loaded: email_helper
INFO - 2018-02-15 14:52:29 --> Helper loaded: common_helper
INFO - 2018-02-15 14:52:29 --> Database Driver Class Initialized
DEBUG - 2018-02-15 14:52:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 14:52:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 14:52:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 14:52:29 --> Pagination Class Initialized
INFO - 2018-02-15 14:52:29 --> Helper loaded: form_helper
INFO - 2018-02-15 14:52:29 --> Form Validation Class Initialized
INFO - 2018-02-15 14:52:29 --> Model Class Initialized
INFO - 2018-02-15 14:52:29 --> Controller Class Initialized
INFO - 2018-02-15 14:52:29 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 14:52:29 --> Model Class Initialized
INFO - 2018-02-15 14:52:29 --> Model Class Initialized
INFO - 2018-02-15 14:52:29 --> Model Class Initialized
INFO - 2018-02-15 14:59:13 --> Config Class Initialized
INFO - 2018-02-15 14:59:13 --> Hooks Class Initialized
DEBUG - 2018-02-15 14:59:13 --> UTF-8 Support Enabled
INFO - 2018-02-15 14:59:13 --> Utf8 Class Initialized
INFO - 2018-02-15 14:59:13 --> URI Class Initialized
INFO - 2018-02-15 14:59:13 --> Router Class Initialized
INFO - 2018-02-15 14:59:13 --> Output Class Initialized
INFO - 2018-02-15 14:59:13 --> Security Class Initialized
DEBUG - 2018-02-15 14:59:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 14:59:13 --> Input Class Initialized
INFO - 2018-02-15 14:59:13 --> Language Class Initialized
ERROR - 2018-02-15 14:59:13 --> Severity: error --> Exception: syntax error, unexpected '$records' (T_VARIABLE) /var/www/html/project/radio/application/controllers/Tracks.php 62
INFO - 2018-02-15 14:59:24 --> Config Class Initialized
INFO - 2018-02-15 14:59:24 --> Hooks Class Initialized
DEBUG - 2018-02-15 14:59:24 --> UTF-8 Support Enabled
INFO - 2018-02-15 14:59:24 --> Utf8 Class Initialized
INFO - 2018-02-15 14:59:24 --> URI Class Initialized
INFO - 2018-02-15 14:59:24 --> Router Class Initialized
INFO - 2018-02-15 14:59:24 --> Output Class Initialized
INFO - 2018-02-15 14:59:24 --> Security Class Initialized
DEBUG - 2018-02-15 14:59:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 14:59:24 --> Input Class Initialized
INFO - 2018-02-15 14:59:24 --> Language Class Initialized
INFO - 2018-02-15 14:59:24 --> Loader Class Initialized
INFO - 2018-02-15 14:59:24 --> Helper loaded: url_helper
INFO - 2018-02-15 14:59:24 --> Helper loaded: file_helper
INFO - 2018-02-15 14:59:24 --> Helper loaded: email_helper
INFO - 2018-02-15 14:59:24 --> Helper loaded: common_helper
INFO - 2018-02-15 14:59:24 --> Database Driver Class Initialized
DEBUG - 2018-02-15 14:59:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 14:59:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 14:59:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 14:59:24 --> Pagination Class Initialized
INFO - 2018-02-15 14:59:24 --> Helper loaded: form_helper
INFO - 2018-02-15 14:59:24 --> Form Validation Class Initialized
INFO - 2018-02-15 14:59:24 --> Model Class Initialized
INFO - 2018-02-15 14:59:24 --> Controller Class Initialized
INFO - 2018-02-15 14:59:24 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 14:59:24 --> Model Class Initialized
INFO - 2018-02-15 14:59:24 --> Model Class Initialized
INFO - 2018-02-15 14:59:24 --> Model Class Initialized
INFO - 2018-02-15 14:59:24 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-15 14:59:24 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-15 14:59:24 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-15 14:59:24 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-15 14:59:24 --> File loaded: /var/www/html/project/radio/application/views/tracks/index.php
INFO - 2018-02-15 14:59:24 --> Final output sent to browser
DEBUG - 2018-02-15 14:59:24 --> Total execution time: 0.0094
INFO - 2018-02-15 14:59:24 --> Config Class Initialized
INFO - 2018-02-15 14:59:24 --> Hooks Class Initialized
DEBUG - 2018-02-15 14:59:24 --> UTF-8 Support Enabled
INFO - 2018-02-15 14:59:24 --> Utf8 Class Initialized
INFO - 2018-02-15 14:59:24 --> URI Class Initialized
INFO - 2018-02-15 14:59:24 --> Router Class Initialized
INFO - 2018-02-15 14:59:24 --> Output Class Initialized
INFO - 2018-02-15 14:59:24 --> Security Class Initialized
DEBUG - 2018-02-15 14:59:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 14:59:24 --> Input Class Initialized
INFO - 2018-02-15 14:59:24 --> Language Class Initialized
INFO - 2018-02-15 14:59:24 --> Loader Class Initialized
INFO - 2018-02-15 14:59:24 --> Helper loaded: url_helper
INFO - 2018-02-15 14:59:24 --> Helper loaded: file_helper
INFO - 2018-02-15 14:59:24 --> Helper loaded: email_helper
INFO - 2018-02-15 14:59:24 --> Helper loaded: common_helper
INFO - 2018-02-15 14:59:24 --> Database Driver Class Initialized
DEBUG - 2018-02-15 14:59:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 14:59:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 14:59:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 14:59:24 --> Pagination Class Initialized
INFO - 2018-02-15 14:59:24 --> Helper loaded: form_helper
INFO - 2018-02-15 14:59:24 --> Form Validation Class Initialized
INFO - 2018-02-15 14:59:24 --> Model Class Initialized
INFO - 2018-02-15 14:59:24 --> Controller Class Initialized
INFO - 2018-02-15 14:59:24 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 14:59:24 --> Model Class Initialized
INFO - 2018-02-15 14:59:24 --> Model Class Initialized
INFO - 2018-02-15 14:59:24 --> Model Class Initialized
INFO - 2018-02-15 15:04:10 --> Config Class Initialized
INFO - 2018-02-15 15:04:10 --> Hooks Class Initialized
DEBUG - 2018-02-15 15:04:10 --> UTF-8 Support Enabled
INFO - 2018-02-15 15:04:10 --> Utf8 Class Initialized
INFO - 2018-02-15 15:04:10 --> URI Class Initialized
INFO - 2018-02-15 15:04:10 --> Router Class Initialized
INFO - 2018-02-15 15:04:10 --> Output Class Initialized
INFO - 2018-02-15 15:04:10 --> Security Class Initialized
DEBUG - 2018-02-15 15:04:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 15:04:10 --> Input Class Initialized
INFO - 2018-02-15 15:04:10 --> Language Class Initialized
INFO - 2018-02-15 15:04:10 --> Loader Class Initialized
INFO - 2018-02-15 15:04:10 --> Helper loaded: url_helper
INFO - 2018-02-15 15:04:10 --> Helper loaded: file_helper
INFO - 2018-02-15 15:04:10 --> Helper loaded: email_helper
INFO - 2018-02-15 15:04:10 --> Helper loaded: common_helper
INFO - 2018-02-15 15:04:10 --> Database Driver Class Initialized
DEBUG - 2018-02-15 15:04:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 15:04:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 15:04:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 15:04:10 --> Pagination Class Initialized
INFO - 2018-02-15 15:04:10 --> Helper loaded: form_helper
INFO - 2018-02-15 15:04:10 --> Form Validation Class Initialized
INFO - 2018-02-15 15:04:10 --> Model Class Initialized
INFO - 2018-02-15 15:04:10 --> Controller Class Initialized
INFO - 2018-02-15 15:04:10 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 15:04:10 --> Model Class Initialized
INFO - 2018-02-15 15:04:10 --> Model Class Initialized
INFO - 2018-02-15 15:04:10 --> Model Class Initialized
INFO - 2018-02-15 15:04:10 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-15 15:04:10 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-15 15:04:10 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-15 15:04:10 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-15 15:04:10 --> File loaded: /var/www/html/project/radio/application/views/tracks/add_edit.php
INFO - 2018-02-15 15:04:10 --> Final output sent to browser
DEBUG - 2018-02-15 15:04:10 --> Total execution time: 0.0146
INFO - 2018-02-15 15:04:23 --> Config Class Initialized
INFO - 2018-02-15 15:04:23 --> Hooks Class Initialized
DEBUG - 2018-02-15 15:04:23 --> UTF-8 Support Enabled
INFO - 2018-02-15 15:04:23 --> Utf8 Class Initialized
INFO - 2018-02-15 15:04:23 --> URI Class Initialized
INFO - 2018-02-15 15:04:23 --> Router Class Initialized
INFO - 2018-02-15 15:04:23 --> Output Class Initialized
INFO - 2018-02-15 15:04:23 --> Security Class Initialized
DEBUG - 2018-02-15 15:04:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 15:04:23 --> Input Class Initialized
INFO - 2018-02-15 15:04:23 --> Language Class Initialized
INFO - 2018-02-15 15:04:23 --> Loader Class Initialized
INFO - 2018-02-15 15:04:23 --> Helper loaded: url_helper
INFO - 2018-02-15 15:04:23 --> Helper loaded: file_helper
INFO - 2018-02-15 15:04:23 --> Helper loaded: email_helper
INFO - 2018-02-15 15:04:23 --> Helper loaded: common_helper
INFO - 2018-02-15 15:04:23 --> Database Driver Class Initialized
DEBUG - 2018-02-15 15:04:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 15:04:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 15:04:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 15:04:23 --> Pagination Class Initialized
INFO - 2018-02-15 15:04:23 --> Helper loaded: form_helper
INFO - 2018-02-15 15:04:23 --> Form Validation Class Initialized
INFO - 2018-02-15 15:04:23 --> Model Class Initialized
INFO - 2018-02-15 15:04:23 --> Controller Class Initialized
INFO - 2018-02-15 15:04:23 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 15:04:23 --> Model Class Initialized
INFO - 2018-02-15 15:04:23 --> Model Class Initialized
INFO - 2018-02-15 15:04:23 --> Model Class Initialized
INFO - 2018-02-15 15:04:23 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-15 15:04:23 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-15 15:04:23 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-15 15:04:23 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-15 15:04:23 --> File loaded: /var/www/html/project/radio/application/views/tracks/add_edit.php
INFO - 2018-02-15 15:04:23 --> Final output sent to browser
DEBUG - 2018-02-15 15:04:23 --> Total execution time: 0.0067
INFO - 2018-02-15 15:04:38 --> Config Class Initialized
INFO - 2018-02-15 15:04:38 --> Hooks Class Initialized
DEBUG - 2018-02-15 15:04:38 --> UTF-8 Support Enabled
INFO - 2018-02-15 15:04:38 --> Utf8 Class Initialized
INFO - 2018-02-15 15:04:38 --> URI Class Initialized
INFO - 2018-02-15 15:04:38 --> Router Class Initialized
INFO - 2018-02-15 15:04:38 --> Output Class Initialized
INFO - 2018-02-15 15:04:38 --> Security Class Initialized
DEBUG - 2018-02-15 15:04:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 15:04:38 --> Input Class Initialized
INFO - 2018-02-15 15:04:38 --> Language Class Initialized
INFO - 2018-02-15 15:04:38 --> Loader Class Initialized
INFO - 2018-02-15 15:04:38 --> Helper loaded: url_helper
INFO - 2018-02-15 15:04:38 --> Helper loaded: file_helper
INFO - 2018-02-15 15:04:38 --> Helper loaded: email_helper
INFO - 2018-02-15 15:04:38 --> Helper loaded: common_helper
INFO - 2018-02-15 15:04:38 --> Database Driver Class Initialized
DEBUG - 2018-02-15 15:04:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 15:04:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 15:04:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 15:04:38 --> Pagination Class Initialized
INFO - 2018-02-15 15:04:38 --> Helper loaded: form_helper
INFO - 2018-02-15 15:04:38 --> Form Validation Class Initialized
INFO - 2018-02-15 15:04:38 --> Model Class Initialized
INFO - 2018-02-15 15:04:38 --> Controller Class Initialized
INFO - 2018-02-15 15:04:38 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 15:04:38 --> Model Class Initialized
INFO - 2018-02-15 15:04:38 --> Model Class Initialized
INFO - 2018-02-15 15:04:38 --> Model Class Initialized
INFO - 2018-02-15 15:04:38 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-15 15:04:38 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-15 15:04:38 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-15 15:04:38 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-15 15:04:38 --> File loaded: /var/www/html/project/radio/application/views/tracks/add_edit.php
INFO - 2018-02-15 15:04:38 --> Final output sent to browser
DEBUG - 2018-02-15 15:04:38 --> Total execution time: 0.0118
INFO - 2018-02-15 15:04:41 --> Config Class Initialized
INFO - 2018-02-15 15:04:41 --> Hooks Class Initialized
DEBUG - 2018-02-15 15:04:41 --> UTF-8 Support Enabled
INFO - 2018-02-15 15:04:41 --> Utf8 Class Initialized
INFO - 2018-02-15 15:04:41 --> URI Class Initialized
INFO - 2018-02-15 15:04:41 --> Router Class Initialized
INFO - 2018-02-15 15:04:41 --> Output Class Initialized
INFO - 2018-02-15 15:04:41 --> Security Class Initialized
DEBUG - 2018-02-15 15:04:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 15:04:41 --> Input Class Initialized
INFO - 2018-02-15 15:04:41 --> Language Class Initialized
INFO - 2018-02-15 15:04:41 --> Loader Class Initialized
INFO - 2018-02-15 15:04:41 --> Helper loaded: url_helper
INFO - 2018-02-15 15:04:41 --> Helper loaded: file_helper
INFO - 2018-02-15 15:04:41 --> Helper loaded: email_helper
INFO - 2018-02-15 15:04:41 --> Helper loaded: common_helper
INFO - 2018-02-15 15:04:41 --> Database Driver Class Initialized
DEBUG - 2018-02-15 15:04:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 15:04:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 15:04:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 15:04:41 --> Pagination Class Initialized
INFO - 2018-02-15 15:04:41 --> Helper loaded: form_helper
INFO - 2018-02-15 15:04:41 --> Form Validation Class Initialized
INFO - 2018-02-15 15:04:41 --> Model Class Initialized
INFO - 2018-02-15 15:04:41 --> Controller Class Initialized
INFO - 2018-02-15 15:04:41 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 15:04:41 --> Model Class Initialized
INFO - 2018-02-15 15:04:41 --> Model Class Initialized
INFO - 2018-02-15 15:04:41 --> Model Class Initialized
INFO - 2018-02-15 15:04:44 --> Config Class Initialized
INFO - 2018-02-15 15:04:44 --> Hooks Class Initialized
DEBUG - 2018-02-15 15:04:44 --> UTF-8 Support Enabled
INFO - 2018-02-15 15:04:44 --> Utf8 Class Initialized
INFO - 2018-02-15 15:04:44 --> URI Class Initialized
INFO - 2018-02-15 15:04:44 --> Router Class Initialized
INFO - 2018-02-15 15:04:44 --> Output Class Initialized
INFO - 2018-02-15 15:04:44 --> Security Class Initialized
DEBUG - 2018-02-15 15:04:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 15:04:44 --> Input Class Initialized
INFO - 2018-02-15 15:04:44 --> Language Class Initialized
INFO - 2018-02-15 15:04:44 --> Loader Class Initialized
INFO - 2018-02-15 15:04:44 --> Helper loaded: url_helper
INFO - 2018-02-15 15:04:44 --> Helper loaded: file_helper
INFO - 2018-02-15 15:04:44 --> Helper loaded: email_helper
INFO - 2018-02-15 15:04:44 --> Helper loaded: common_helper
INFO - 2018-02-15 15:04:44 --> Database Driver Class Initialized
DEBUG - 2018-02-15 15:04:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 15:04:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 15:04:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 15:04:44 --> Pagination Class Initialized
INFO - 2018-02-15 15:04:44 --> Helper loaded: form_helper
INFO - 2018-02-15 15:04:44 --> Form Validation Class Initialized
INFO - 2018-02-15 15:04:44 --> Model Class Initialized
INFO - 2018-02-15 15:04:44 --> Controller Class Initialized
INFO - 2018-02-15 15:04:44 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 15:04:44 --> Model Class Initialized
INFO - 2018-02-15 15:04:44 --> Model Class Initialized
INFO - 2018-02-15 15:04:44 --> Model Class Initialized
INFO - 2018-02-15 15:04:46 --> Config Class Initialized
INFO - 2018-02-15 15:04:46 --> Hooks Class Initialized
DEBUG - 2018-02-15 15:04:46 --> UTF-8 Support Enabled
INFO - 2018-02-15 15:04:46 --> Utf8 Class Initialized
INFO - 2018-02-15 15:04:46 --> URI Class Initialized
INFO - 2018-02-15 15:04:46 --> Router Class Initialized
INFO - 2018-02-15 15:04:46 --> Output Class Initialized
INFO - 2018-02-15 15:04:46 --> Security Class Initialized
DEBUG - 2018-02-15 15:04:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 15:04:46 --> Input Class Initialized
INFO - 2018-02-15 15:04:46 --> Language Class Initialized
INFO - 2018-02-15 15:04:46 --> Loader Class Initialized
INFO - 2018-02-15 15:04:46 --> Helper loaded: url_helper
INFO - 2018-02-15 15:04:46 --> Helper loaded: file_helper
INFO - 2018-02-15 15:04:46 --> Helper loaded: email_helper
INFO - 2018-02-15 15:04:46 --> Helper loaded: common_helper
INFO - 2018-02-15 15:04:46 --> Database Driver Class Initialized
DEBUG - 2018-02-15 15:04:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 15:04:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 15:04:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 15:04:46 --> Pagination Class Initialized
INFO - 2018-02-15 15:04:46 --> Helper loaded: form_helper
INFO - 2018-02-15 15:04:46 --> Form Validation Class Initialized
INFO - 2018-02-15 15:04:46 --> Model Class Initialized
INFO - 2018-02-15 15:04:46 --> Controller Class Initialized
INFO - 2018-02-15 15:04:46 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 15:04:46 --> Model Class Initialized
INFO - 2018-02-15 15:04:46 --> Model Class Initialized
INFO - 2018-02-15 15:04:46 --> Model Class Initialized
INFO - 2018-02-15 15:04:46 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-15 15:04:46 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-15 15:04:46 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-15 15:04:46 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-15 15:04:46 --> File loaded: /var/www/html/project/radio/application/views/tracks/add_edit.php
INFO - 2018-02-15 15:04:46 --> Final output sent to browser
DEBUG - 2018-02-15 15:04:46 --> Total execution time: 0.0068
INFO - 2018-02-15 15:20:57 --> Config Class Initialized
INFO - 2018-02-15 15:20:57 --> Hooks Class Initialized
DEBUG - 2018-02-15 15:20:57 --> UTF-8 Support Enabled
INFO - 2018-02-15 15:20:57 --> Utf8 Class Initialized
INFO - 2018-02-15 15:20:57 --> URI Class Initialized
INFO - 2018-02-15 15:20:57 --> Router Class Initialized
INFO - 2018-02-15 15:20:57 --> Output Class Initialized
INFO - 2018-02-15 15:20:57 --> Security Class Initialized
DEBUG - 2018-02-15 15:20:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 15:20:57 --> Input Class Initialized
INFO - 2018-02-15 15:20:57 --> Language Class Initialized
INFO - 2018-02-15 15:20:57 --> Loader Class Initialized
INFO - 2018-02-15 15:20:57 --> Helper loaded: url_helper
INFO - 2018-02-15 15:20:57 --> Helper loaded: file_helper
INFO - 2018-02-15 15:20:57 --> Helper loaded: email_helper
INFO - 2018-02-15 15:20:57 --> Helper loaded: common_helper
INFO - 2018-02-15 15:20:57 --> Database Driver Class Initialized
DEBUG - 2018-02-15 15:20:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 15:20:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 15:20:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 15:20:57 --> Pagination Class Initialized
INFO - 2018-02-15 15:20:57 --> Helper loaded: form_helper
INFO - 2018-02-15 15:20:57 --> Form Validation Class Initialized
INFO - 2018-02-15 15:20:57 --> Model Class Initialized
INFO - 2018-02-15 15:20:57 --> Controller Class Initialized
INFO - 2018-02-15 15:20:57 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 15:20:57 --> Model Class Initialized
INFO - 2018-02-15 15:20:57 --> Model Class Initialized
INFO - 2018-02-15 15:20:57 --> Model Class Initialized
INFO - 2018-02-15 15:20:57 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-15 15:20:57 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-15 15:20:57 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-15 15:20:57 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-15 15:20:57 --> File loaded: /var/www/html/project/radio/application/views/tracks/add_edit.php
INFO - 2018-02-15 15:20:57 --> Final output sent to browser
DEBUG - 2018-02-15 15:20:57 --> Total execution time: 0.0101
INFO - 2018-02-15 15:21:08 --> Config Class Initialized
INFO - 2018-02-15 15:21:08 --> Hooks Class Initialized
DEBUG - 2018-02-15 15:21:08 --> UTF-8 Support Enabled
INFO - 2018-02-15 15:21:08 --> Utf8 Class Initialized
INFO - 2018-02-15 15:21:08 --> URI Class Initialized
INFO - 2018-02-15 15:21:08 --> Router Class Initialized
INFO - 2018-02-15 15:21:08 --> Output Class Initialized
INFO - 2018-02-15 15:21:08 --> Security Class Initialized
DEBUG - 2018-02-15 15:21:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 15:21:08 --> Input Class Initialized
INFO - 2018-02-15 15:21:08 --> Language Class Initialized
INFO - 2018-02-15 15:21:08 --> Loader Class Initialized
INFO - 2018-02-15 15:21:08 --> Helper loaded: url_helper
INFO - 2018-02-15 15:21:08 --> Helper loaded: file_helper
INFO - 2018-02-15 15:21:08 --> Helper loaded: email_helper
INFO - 2018-02-15 15:21:08 --> Helper loaded: common_helper
INFO - 2018-02-15 15:21:08 --> Database Driver Class Initialized
DEBUG - 2018-02-15 15:21:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 15:21:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 15:21:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 15:21:08 --> Pagination Class Initialized
INFO - 2018-02-15 15:21:08 --> Helper loaded: form_helper
INFO - 2018-02-15 15:21:08 --> Form Validation Class Initialized
INFO - 2018-02-15 15:21:08 --> Model Class Initialized
INFO - 2018-02-15 15:21:08 --> Controller Class Initialized
INFO - 2018-02-15 15:21:08 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 15:21:08 --> Model Class Initialized
INFO - 2018-02-15 15:21:08 --> Model Class Initialized
INFO - 2018-02-15 15:21:08 --> Model Class Initialized
DEBUG - 2018-02-15 15:21:08 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-15 15:21:08 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-02-15 15:21:08 --> Config Class Initialized
INFO - 2018-02-15 15:21:08 --> Hooks Class Initialized
DEBUG - 2018-02-15 15:21:08 --> UTF-8 Support Enabled
INFO - 2018-02-15 15:21:08 --> Utf8 Class Initialized
INFO - 2018-02-15 15:21:08 --> URI Class Initialized
INFO - 2018-02-15 15:21:08 --> Router Class Initialized
INFO - 2018-02-15 15:21:08 --> Output Class Initialized
INFO - 2018-02-15 15:21:08 --> Security Class Initialized
DEBUG - 2018-02-15 15:21:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 15:21:08 --> Input Class Initialized
INFO - 2018-02-15 15:21:08 --> Language Class Initialized
INFO - 2018-02-15 15:21:08 --> Loader Class Initialized
INFO - 2018-02-15 15:21:08 --> Helper loaded: url_helper
INFO - 2018-02-15 15:21:08 --> Helper loaded: file_helper
INFO - 2018-02-15 15:21:08 --> Helper loaded: email_helper
INFO - 2018-02-15 15:21:08 --> Helper loaded: common_helper
INFO - 2018-02-15 15:21:08 --> Database Driver Class Initialized
DEBUG - 2018-02-15 15:21:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 15:21:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 15:21:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 15:21:08 --> Pagination Class Initialized
INFO - 2018-02-15 15:21:08 --> Helper loaded: form_helper
INFO - 2018-02-15 15:21:08 --> Form Validation Class Initialized
INFO - 2018-02-15 15:21:08 --> Model Class Initialized
INFO - 2018-02-15 15:21:08 --> Controller Class Initialized
INFO - 2018-02-15 15:21:08 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 15:21:08 --> Model Class Initialized
INFO - 2018-02-15 15:21:08 --> Model Class Initialized
INFO - 2018-02-15 15:21:08 --> Model Class Initialized
INFO - 2018-02-15 15:21:08 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-15 15:21:08 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-15 15:21:08 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-15 15:21:08 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-15 15:21:08 --> File loaded: /var/www/html/project/radio/application/views/tracks/index.php
INFO - 2018-02-15 15:21:08 --> Final output sent to browser
DEBUG - 2018-02-15 15:21:08 --> Total execution time: 0.0065
INFO - 2018-02-15 15:21:09 --> Config Class Initialized
INFO - 2018-02-15 15:21:09 --> Hooks Class Initialized
DEBUG - 2018-02-15 15:21:09 --> UTF-8 Support Enabled
INFO - 2018-02-15 15:21:09 --> Utf8 Class Initialized
INFO - 2018-02-15 15:21:09 --> URI Class Initialized
INFO - 2018-02-15 15:21:09 --> Router Class Initialized
INFO - 2018-02-15 15:21:09 --> Output Class Initialized
INFO - 2018-02-15 15:21:09 --> Security Class Initialized
DEBUG - 2018-02-15 15:21:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 15:21:09 --> Input Class Initialized
INFO - 2018-02-15 15:21:09 --> Language Class Initialized
INFO - 2018-02-15 15:21:09 --> Loader Class Initialized
INFO - 2018-02-15 15:21:09 --> Helper loaded: url_helper
INFO - 2018-02-15 15:21:09 --> Helper loaded: file_helper
INFO - 2018-02-15 15:21:09 --> Helper loaded: email_helper
INFO - 2018-02-15 15:21:09 --> Helper loaded: common_helper
INFO - 2018-02-15 15:21:09 --> Database Driver Class Initialized
DEBUG - 2018-02-15 15:21:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 15:21:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 15:21:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 15:21:09 --> Pagination Class Initialized
INFO - 2018-02-15 15:21:09 --> Helper loaded: form_helper
INFO - 2018-02-15 15:21:09 --> Form Validation Class Initialized
INFO - 2018-02-15 15:21:09 --> Model Class Initialized
INFO - 2018-02-15 15:21:09 --> Controller Class Initialized
INFO - 2018-02-15 15:21:09 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 15:21:09 --> Model Class Initialized
INFO - 2018-02-15 15:21:09 --> Model Class Initialized
INFO - 2018-02-15 15:21:09 --> Model Class Initialized
INFO - 2018-02-15 15:21:15 --> Config Class Initialized
INFO - 2018-02-15 15:21:15 --> Hooks Class Initialized
DEBUG - 2018-02-15 15:21:15 --> UTF-8 Support Enabled
INFO - 2018-02-15 15:21:15 --> Utf8 Class Initialized
INFO - 2018-02-15 15:21:15 --> URI Class Initialized
INFO - 2018-02-15 15:21:15 --> Router Class Initialized
INFO - 2018-02-15 15:21:15 --> Output Class Initialized
INFO - 2018-02-15 15:21:15 --> Security Class Initialized
DEBUG - 2018-02-15 15:21:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 15:21:15 --> Input Class Initialized
INFO - 2018-02-15 15:21:15 --> Language Class Initialized
INFO - 2018-02-15 15:21:15 --> Loader Class Initialized
INFO - 2018-02-15 15:21:15 --> Helper loaded: url_helper
INFO - 2018-02-15 15:21:15 --> Helper loaded: file_helper
INFO - 2018-02-15 15:21:15 --> Helper loaded: email_helper
INFO - 2018-02-15 15:21:15 --> Helper loaded: common_helper
INFO - 2018-02-15 15:21:15 --> Database Driver Class Initialized
DEBUG - 2018-02-15 15:21:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 15:21:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 15:21:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 15:21:15 --> Pagination Class Initialized
INFO - 2018-02-15 15:21:15 --> Helper loaded: form_helper
INFO - 2018-02-15 15:21:15 --> Form Validation Class Initialized
INFO - 2018-02-15 15:21:15 --> Model Class Initialized
INFO - 2018-02-15 15:21:15 --> Controller Class Initialized
INFO - 2018-02-15 15:21:15 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 15:21:15 --> Model Class Initialized
INFO - 2018-02-15 15:21:15 --> Model Class Initialized
INFO - 2018-02-15 15:21:15 --> Model Class Initialized
INFO - 2018-02-15 15:21:15 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-15 15:21:15 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-15 15:21:15 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-15 15:21:15 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-15 15:21:15 --> File loaded: /var/www/html/project/radio/application/views/tracks/add_edit.php
INFO - 2018-02-15 15:21:15 --> Final output sent to browser
DEBUG - 2018-02-15 15:21:15 --> Total execution time: 0.0076
INFO - 2018-02-15 15:21:19 --> Config Class Initialized
INFO - 2018-02-15 15:21:19 --> Hooks Class Initialized
DEBUG - 2018-02-15 15:21:19 --> UTF-8 Support Enabled
INFO - 2018-02-15 15:21:19 --> Utf8 Class Initialized
INFO - 2018-02-15 15:21:19 --> URI Class Initialized
INFO - 2018-02-15 15:21:19 --> Router Class Initialized
INFO - 2018-02-15 15:21:19 --> Output Class Initialized
INFO - 2018-02-15 15:21:19 --> Security Class Initialized
DEBUG - 2018-02-15 15:21:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 15:21:19 --> Input Class Initialized
INFO - 2018-02-15 15:21:19 --> Language Class Initialized
INFO - 2018-02-15 15:21:19 --> Loader Class Initialized
INFO - 2018-02-15 15:21:19 --> Helper loaded: url_helper
INFO - 2018-02-15 15:21:19 --> Helper loaded: file_helper
INFO - 2018-02-15 15:21:19 --> Helper loaded: email_helper
INFO - 2018-02-15 15:21:19 --> Helper loaded: common_helper
INFO - 2018-02-15 15:21:19 --> Database Driver Class Initialized
DEBUG - 2018-02-15 15:21:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 15:21:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 15:21:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 15:21:19 --> Pagination Class Initialized
INFO - 2018-02-15 15:21:19 --> Helper loaded: form_helper
INFO - 2018-02-15 15:21:19 --> Form Validation Class Initialized
INFO - 2018-02-15 15:21:19 --> Model Class Initialized
INFO - 2018-02-15 15:21:19 --> Controller Class Initialized
INFO - 2018-02-15 15:21:19 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 15:21:19 --> Model Class Initialized
INFO - 2018-02-15 15:21:19 --> Model Class Initialized
INFO - 2018-02-15 15:21:19 --> Model Class Initialized
INFO - 2018-02-15 15:21:23 --> Config Class Initialized
INFO - 2018-02-15 15:21:23 --> Hooks Class Initialized
DEBUG - 2018-02-15 15:21:23 --> UTF-8 Support Enabled
INFO - 2018-02-15 15:21:23 --> Utf8 Class Initialized
INFO - 2018-02-15 15:21:23 --> URI Class Initialized
INFO - 2018-02-15 15:21:23 --> Router Class Initialized
INFO - 2018-02-15 15:21:23 --> Output Class Initialized
INFO - 2018-02-15 15:21:23 --> Security Class Initialized
DEBUG - 2018-02-15 15:21:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 15:21:23 --> Input Class Initialized
INFO - 2018-02-15 15:21:23 --> Language Class Initialized
INFO - 2018-02-15 15:21:23 --> Loader Class Initialized
INFO - 2018-02-15 15:21:23 --> Helper loaded: url_helper
INFO - 2018-02-15 15:21:23 --> Helper loaded: file_helper
INFO - 2018-02-15 15:21:23 --> Helper loaded: email_helper
INFO - 2018-02-15 15:21:23 --> Helper loaded: common_helper
INFO - 2018-02-15 15:21:23 --> Database Driver Class Initialized
DEBUG - 2018-02-15 15:21:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 15:21:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 15:21:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 15:21:23 --> Pagination Class Initialized
INFO - 2018-02-15 15:21:23 --> Helper loaded: form_helper
INFO - 2018-02-15 15:21:23 --> Form Validation Class Initialized
INFO - 2018-02-15 15:21:23 --> Model Class Initialized
INFO - 2018-02-15 15:21:23 --> Controller Class Initialized
INFO - 2018-02-15 15:21:23 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 15:21:23 --> Model Class Initialized
INFO - 2018-02-15 15:21:23 --> Model Class Initialized
INFO - 2018-02-15 15:21:23 --> Model Class Initialized
DEBUG - 2018-02-15 15:21:23 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-15 15:21:23 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-02-15 15:21:23 --> Config Class Initialized
INFO - 2018-02-15 15:21:23 --> Hooks Class Initialized
DEBUG - 2018-02-15 15:21:23 --> UTF-8 Support Enabled
INFO - 2018-02-15 15:21:23 --> Utf8 Class Initialized
INFO - 2018-02-15 15:21:23 --> URI Class Initialized
INFO - 2018-02-15 15:21:23 --> Router Class Initialized
INFO - 2018-02-15 15:21:23 --> Output Class Initialized
INFO - 2018-02-15 15:21:23 --> Security Class Initialized
DEBUG - 2018-02-15 15:21:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 15:21:23 --> Input Class Initialized
INFO - 2018-02-15 15:21:23 --> Language Class Initialized
INFO - 2018-02-15 15:21:23 --> Loader Class Initialized
INFO - 2018-02-15 15:21:23 --> Helper loaded: url_helper
INFO - 2018-02-15 15:21:23 --> Helper loaded: file_helper
INFO - 2018-02-15 15:21:23 --> Helper loaded: email_helper
INFO - 2018-02-15 15:21:23 --> Helper loaded: common_helper
INFO - 2018-02-15 15:21:23 --> Database Driver Class Initialized
DEBUG - 2018-02-15 15:21:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 15:21:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 15:21:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 15:21:23 --> Pagination Class Initialized
INFO - 2018-02-15 15:21:23 --> Helper loaded: form_helper
INFO - 2018-02-15 15:21:23 --> Form Validation Class Initialized
INFO - 2018-02-15 15:21:23 --> Model Class Initialized
INFO - 2018-02-15 15:21:23 --> Controller Class Initialized
INFO - 2018-02-15 15:21:23 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 15:21:23 --> Model Class Initialized
INFO - 2018-02-15 15:21:23 --> Model Class Initialized
INFO - 2018-02-15 15:21:23 --> Model Class Initialized
INFO - 2018-02-15 15:21:23 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-15 15:21:23 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-15 15:21:23 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-15 15:21:23 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-15 15:21:23 --> File loaded: /var/www/html/project/radio/application/views/tracks/index.php
INFO - 2018-02-15 15:21:23 --> Final output sent to browser
DEBUG - 2018-02-15 15:21:23 --> Total execution time: 0.0041
INFO - 2018-02-15 15:21:23 --> Config Class Initialized
INFO - 2018-02-15 15:21:23 --> Hooks Class Initialized
DEBUG - 2018-02-15 15:21:23 --> UTF-8 Support Enabled
INFO - 2018-02-15 15:21:23 --> Utf8 Class Initialized
INFO - 2018-02-15 15:21:23 --> URI Class Initialized
INFO - 2018-02-15 15:21:23 --> Router Class Initialized
INFO - 2018-02-15 15:21:23 --> Output Class Initialized
INFO - 2018-02-15 15:21:23 --> Security Class Initialized
DEBUG - 2018-02-15 15:21:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 15:21:23 --> Input Class Initialized
INFO - 2018-02-15 15:21:23 --> Language Class Initialized
INFO - 2018-02-15 15:21:23 --> Loader Class Initialized
INFO - 2018-02-15 15:21:23 --> Helper loaded: url_helper
INFO - 2018-02-15 15:21:23 --> Helper loaded: file_helper
INFO - 2018-02-15 15:21:23 --> Helper loaded: email_helper
INFO - 2018-02-15 15:21:23 --> Helper loaded: common_helper
INFO - 2018-02-15 15:21:23 --> Database Driver Class Initialized
DEBUG - 2018-02-15 15:21:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 15:21:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 15:21:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 15:21:23 --> Pagination Class Initialized
INFO - 2018-02-15 15:21:23 --> Helper loaded: form_helper
INFO - 2018-02-15 15:21:23 --> Form Validation Class Initialized
INFO - 2018-02-15 15:21:23 --> Model Class Initialized
INFO - 2018-02-15 15:21:23 --> Controller Class Initialized
INFO - 2018-02-15 15:21:23 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 15:21:23 --> Model Class Initialized
INFO - 2018-02-15 15:21:23 --> Model Class Initialized
INFO - 2018-02-15 15:21:23 --> Model Class Initialized
INFO - 2018-02-15 15:35:41 --> Config Class Initialized
INFO - 2018-02-15 15:35:41 --> Hooks Class Initialized
DEBUG - 2018-02-15 15:35:41 --> UTF-8 Support Enabled
INFO - 2018-02-15 15:35:41 --> Utf8 Class Initialized
INFO - 2018-02-15 15:35:41 --> URI Class Initialized
INFO - 2018-02-15 15:35:41 --> Router Class Initialized
INFO - 2018-02-15 15:35:41 --> Output Class Initialized
INFO - 2018-02-15 15:35:41 --> Security Class Initialized
DEBUG - 2018-02-15 15:35:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 15:35:41 --> Input Class Initialized
INFO - 2018-02-15 15:35:41 --> Language Class Initialized
INFO - 2018-02-15 15:35:41 --> Loader Class Initialized
INFO - 2018-02-15 15:35:41 --> Helper loaded: url_helper
INFO - 2018-02-15 15:35:41 --> Helper loaded: file_helper
INFO - 2018-02-15 15:35:41 --> Helper loaded: email_helper
INFO - 2018-02-15 15:35:41 --> Helper loaded: common_helper
INFO - 2018-02-15 15:35:41 --> Database Driver Class Initialized
DEBUG - 2018-02-15 15:35:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 15:35:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 15:35:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 15:35:41 --> Pagination Class Initialized
INFO - 2018-02-15 15:35:41 --> Helper loaded: form_helper
INFO - 2018-02-15 15:35:41 --> Form Validation Class Initialized
INFO - 2018-02-15 15:35:41 --> Model Class Initialized
INFO - 2018-02-15 15:35:41 --> Controller Class Initialized
INFO - 2018-02-15 15:35:41 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 15:35:41 --> Model Class Initialized
INFO - 2018-02-15 15:35:41 --> Model Class Initialized
INFO - 2018-02-15 15:35:41 --> Model Class Initialized
INFO - 2018-02-15 15:35:41 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-15 15:35:41 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-15 15:35:41 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-15 15:35:41 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-15 15:35:41 --> File loaded: /var/www/html/project/radio/application/views/tracks/index.php
INFO - 2018-02-15 15:35:41 --> Final output sent to browser
DEBUG - 2018-02-15 15:35:41 --> Total execution time: 0.0107
INFO - 2018-02-15 15:35:42 --> Config Class Initialized
INFO - 2018-02-15 15:35:42 --> Hooks Class Initialized
DEBUG - 2018-02-15 15:35:42 --> UTF-8 Support Enabled
INFO - 2018-02-15 15:35:42 --> Utf8 Class Initialized
INFO - 2018-02-15 15:35:42 --> URI Class Initialized
INFO - 2018-02-15 15:35:42 --> Router Class Initialized
INFO - 2018-02-15 15:35:42 --> Output Class Initialized
INFO - 2018-02-15 15:35:42 --> Security Class Initialized
DEBUG - 2018-02-15 15:35:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 15:35:42 --> Input Class Initialized
INFO - 2018-02-15 15:35:42 --> Language Class Initialized
INFO - 2018-02-15 15:35:42 --> Loader Class Initialized
INFO - 2018-02-15 15:35:42 --> Helper loaded: url_helper
INFO - 2018-02-15 15:35:42 --> Helper loaded: file_helper
INFO - 2018-02-15 15:35:42 --> Helper loaded: email_helper
INFO - 2018-02-15 15:35:42 --> Helper loaded: common_helper
INFO - 2018-02-15 15:35:42 --> Database Driver Class Initialized
DEBUG - 2018-02-15 15:35:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 15:35:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 15:35:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 15:35:42 --> Pagination Class Initialized
INFO - 2018-02-15 15:35:42 --> Helper loaded: form_helper
INFO - 2018-02-15 15:35:42 --> Form Validation Class Initialized
INFO - 2018-02-15 15:35:42 --> Model Class Initialized
INFO - 2018-02-15 15:35:42 --> Controller Class Initialized
INFO - 2018-02-15 15:35:42 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 15:35:42 --> Model Class Initialized
INFO - 2018-02-15 15:35:42 --> Model Class Initialized
INFO - 2018-02-15 15:35:42 --> Model Class Initialized
INFO - 2018-02-15 15:35:47 --> Config Class Initialized
INFO - 2018-02-15 15:35:47 --> Hooks Class Initialized
DEBUG - 2018-02-15 15:35:47 --> UTF-8 Support Enabled
INFO - 2018-02-15 15:35:47 --> Utf8 Class Initialized
INFO - 2018-02-15 15:35:47 --> URI Class Initialized
INFO - 2018-02-15 15:35:47 --> Router Class Initialized
INFO - 2018-02-15 15:35:47 --> Output Class Initialized
INFO - 2018-02-15 15:35:47 --> Security Class Initialized
DEBUG - 2018-02-15 15:35:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 15:35:47 --> Input Class Initialized
INFO - 2018-02-15 15:35:47 --> Language Class Initialized
INFO - 2018-02-15 15:35:47 --> Loader Class Initialized
INFO - 2018-02-15 15:35:47 --> Helper loaded: url_helper
INFO - 2018-02-15 15:35:47 --> Helper loaded: file_helper
INFO - 2018-02-15 15:35:47 --> Helper loaded: email_helper
INFO - 2018-02-15 15:35:47 --> Helper loaded: common_helper
INFO - 2018-02-15 15:35:47 --> Database Driver Class Initialized
DEBUG - 2018-02-15 15:35:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 15:35:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 15:35:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 15:35:47 --> Pagination Class Initialized
INFO - 2018-02-15 15:35:47 --> Helper loaded: form_helper
INFO - 2018-02-15 15:35:47 --> Form Validation Class Initialized
INFO - 2018-02-15 15:35:47 --> Model Class Initialized
INFO - 2018-02-15 15:35:47 --> Controller Class Initialized
INFO - 2018-02-15 15:35:47 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 15:35:47 --> Model Class Initialized
INFO - 2018-02-15 15:35:47 --> Model Class Initialized
INFO - 2018-02-15 15:35:47 --> Model Class Initialized
INFO - 2018-02-15 15:35:47 --> Config Class Initialized
INFO - 2018-02-15 15:35:47 --> Hooks Class Initialized
DEBUG - 2018-02-15 15:35:47 --> UTF-8 Support Enabled
INFO - 2018-02-15 15:35:47 --> Utf8 Class Initialized
INFO - 2018-02-15 15:35:47 --> URI Class Initialized
INFO - 2018-02-15 15:35:47 --> Router Class Initialized
INFO - 2018-02-15 15:35:47 --> Output Class Initialized
INFO - 2018-02-15 15:35:47 --> Security Class Initialized
DEBUG - 2018-02-15 15:35:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 15:35:47 --> Input Class Initialized
INFO - 2018-02-15 15:35:47 --> Language Class Initialized
INFO - 2018-02-15 15:35:47 --> Loader Class Initialized
INFO - 2018-02-15 15:35:47 --> Helper loaded: url_helper
INFO - 2018-02-15 15:35:47 --> Helper loaded: file_helper
INFO - 2018-02-15 15:35:47 --> Helper loaded: email_helper
INFO - 2018-02-15 15:35:47 --> Helper loaded: common_helper
INFO - 2018-02-15 15:35:47 --> Database Driver Class Initialized
DEBUG - 2018-02-15 15:35:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 15:35:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 15:35:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 15:35:47 --> Pagination Class Initialized
INFO - 2018-02-15 15:35:47 --> Helper loaded: form_helper
INFO - 2018-02-15 15:35:47 --> Form Validation Class Initialized
INFO - 2018-02-15 15:35:47 --> Model Class Initialized
INFO - 2018-02-15 15:35:47 --> Controller Class Initialized
INFO - 2018-02-15 15:35:47 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 15:35:47 --> Model Class Initialized
INFO - 2018-02-15 15:35:47 --> Model Class Initialized
INFO - 2018-02-15 15:35:47 --> Model Class Initialized
INFO - 2018-02-15 15:35:48 --> Config Class Initialized
INFO - 2018-02-15 15:35:48 --> Hooks Class Initialized
DEBUG - 2018-02-15 15:35:48 --> UTF-8 Support Enabled
INFO - 2018-02-15 15:35:48 --> Utf8 Class Initialized
INFO - 2018-02-15 15:35:48 --> URI Class Initialized
INFO - 2018-02-15 15:35:48 --> Router Class Initialized
INFO - 2018-02-15 15:35:48 --> Output Class Initialized
INFO - 2018-02-15 15:35:48 --> Security Class Initialized
DEBUG - 2018-02-15 15:35:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 15:35:48 --> Input Class Initialized
INFO - 2018-02-15 15:35:48 --> Language Class Initialized
INFO - 2018-02-15 15:35:48 --> Loader Class Initialized
INFO - 2018-02-15 15:35:48 --> Helper loaded: url_helper
INFO - 2018-02-15 15:35:48 --> Helper loaded: file_helper
INFO - 2018-02-15 15:35:48 --> Helper loaded: email_helper
INFO - 2018-02-15 15:35:48 --> Helper loaded: common_helper
INFO - 2018-02-15 15:35:48 --> Database Driver Class Initialized
DEBUG - 2018-02-15 15:35:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 15:35:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 15:35:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 15:35:48 --> Pagination Class Initialized
INFO - 2018-02-15 15:35:48 --> Helper loaded: form_helper
INFO - 2018-02-15 15:35:48 --> Form Validation Class Initialized
INFO - 2018-02-15 15:35:48 --> Model Class Initialized
INFO - 2018-02-15 15:35:48 --> Controller Class Initialized
INFO - 2018-02-15 15:35:48 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 15:35:48 --> Model Class Initialized
INFO - 2018-02-15 15:35:48 --> Model Class Initialized
INFO - 2018-02-15 15:35:48 --> Model Class Initialized
INFO - 2018-02-15 15:35:48 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-15 15:35:48 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-15 15:35:48 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-15 15:35:48 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-15 15:35:48 --> File loaded: /var/www/html/project/radio/application/views/tracks/index.php
INFO - 2018-02-15 15:35:48 --> Final output sent to browser
DEBUG - 2018-02-15 15:35:48 --> Total execution time: 0.0046
INFO - 2018-02-15 15:35:49 --> Config Class Initialized
INFO - 2018-02-15 15:35:49 --> Hooks Class Initialized
DEBUG - 2018-02-15 15:35:49 --> UTF-8 Support Enabled
INFO - 2018-02-15 15:35:49 --> Utf8 Class Initialized
INFO - 2018-02-15 15:35:49 --> URI Class Initialized
INFO - 2018-02-15 15:35:49 --> Router Class Initialized
INFO - 2018-02-15 15:35:49 --> Output Class Initialized
INFO - 2018-02-15 15:35:49 --> Security Class Initialized
DEBUG - 2018-02-15 15:35:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 15:35:49 --> Input Class Initialized
INFO - 2018-02-15 15:35:49 --> Language Class Initialized
INFO - 2018-02-15 15:35:49 --> Loader Class Initialized
INFO - 2018-02-15 15:35:49 --> Helper loaded: url_helper
INFO - 2018-02-15 15:35:49 --> Helper loaded: file_helper
INFO - 2018-02-15 15:35:49 --> Helper loaded: email_helper
INFO - 2018-02-15 15:35:49 --> Helper loaded: common_helper
INFO - 2018-02-15 15:35:49 --> Database Driver Class Initialized
DEBUG - 2018-02-15 15:35:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 15:35:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 15:35:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 15:35:49 --> Pagination Class Initialized
INFO - 2018-02-15 15:35:49 --> Helper loaded: form_helper
INFO - 2018-02-15 15:35:49 --> Form Validation Class Initialized
INFO - 2018-02-15 15:35:49 --> Model Class Initialized
INFO - 2018-02-15 15:35:49 --> Controller Class Initialized
INFO - 2018-02-15 15:35:49 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 15:35:49 --> Model Class Initialized
INFO - 2018-02-15 15:35:49 --> Model Class Initialized
INFO - 2018-02-15 15:35:49 --> Model Class Initialized
INFO - 2018-02-15 15:35:52 --> Config Class Initialized
INFO - 2018-02-15 15:35:52 --> Hooks Class Initialized
DEBUG - 2018-02-15 15:35:52 --> UTF-8 Support Enabled
INFO - 2018-02-15 15:35:52 --> Utf8 Class Initialized
INFO - 2018-02-15 15:35:52 --> URI Class Initialized
INFO - 2018-02-15 15:35:52 --> Router Class Initialized
INFO - 2018-02-15 15:35:52 --> Output Class Initialized
INFO - 2018-02-15 15:35:52 --> Security Class Initialized
DEBUG - 2018-02-15 15:35:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 15:35:52 --> Input Class Initialized
INFO - 2018-02-15 15:35:52 --> Language Class Initialized
INFO - 2018-02-15 15:35:52 --> Loader Class Initialized
INFO - 2018-02-15 15:35:52 --> Helper loaded: url_helper
INFO - 2018-02-15 15:35:52 --> Helper loaded: file_helper
INFO - 2018-02-15 15:35:52 --> Helper loaded: email_helper
INFO - 2018-02-15 15:35:52 --> Helper loaded: common_helper
INFO - 2018-02-15 15:35:52 --> Database Driver Class Initialized
DEBUG - 2018-02-15 15:35:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 15:35:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 15:35:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 15:35:52 --> Pagination Class Initialized
INFO - 2018-02-15 15:35:52 --> Helper loaded: form_helper
INFO - 2018-02-15 15:35:52 --> Form Validation Class Initialized
INFO - 2018-02-15 15:35:52 --> Model Class Initialized
INFO - 2018-02-15 15:35:52 --> Controller Class Initialized
INFO - 2018-02-15 15:35:52 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 15:35:52 --> Model Class Initialized
INFO - 2018-02-15 15:35:52 --> Model Class Initialized
INFO - 2018-02-15 15:35:52 --> Model Class Initialized
INFO - 2018-02-15 15:35:52 --> Config Class Initialized
INFO - 2018-02-15 15:35:52 --> Hooks Class Initialized
DEBUG - 2018-02-15 15:35:52 --> UTF-8 Support Enabled
INFO - 2018-02-15 15:35:52 --> Utf8 Class Initialized
INFO - 2018-02-15 15:35:52 --> URI Class Initialized
INFO - 2018-02-15 15:35:52 --> Router Class Initialized
INFO - 2018-02-15 15:35:52 --> Output Class Initialized
INFO - 2018-02-15 15:35:52 --> Security Class Initialized
DEBUG - 2018-02-15 15:35:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 15:35:52 --> Input Class Initialized
INFO - 2018-02-15 15:35:52 --> Language Class Initialized
INFO - 2018-02-15 15:35:52 --> Loader Class Initialized
INFO - 2018-02-15 15:35:52 --> Helper loaded: url_helper
INFO - 2018-02-15 15:35:52 --> Helper loaded: file_helper
INFO - 2018-02-15 15:35:52 --> Helper loaded: email_helper
INFO - 2018-02-15 15:35:52 --> Helper loaded: common_helper
INFO - 2018-02-15 15:35:52 --> Database Driver Class Initialized
DEBUG - 2018-02-15 15:35:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 15:35:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 15:35:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 15:35:52 --> Pagination Class Initialized
INFO - 2018-02-15 15:35:52 --> Helper loaded: form_helper
INFO - 2018-02-15 15:35:52 --> Form Validation Class Initialized
INFO - 2018-02-15 15:35:52 --> Model Class Initialized
INFO - 2018-02-15 15:35:52 --> Controller Class Initialized
INFO - 2018-02-15 15:35:52 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 15:35:52 --> Model Class Initialized
INFO - 2018-02-15 15:35:52 --> Model Class Initialized
INFO - 2018-02-15 15:35:52 --> Model Class Initialized
INFO - 2018-02-15 15:35:53 --> Config Class Initialized
INFO - 2018-02-15 15:35:53 --> Hooks Class Initialized
DEBUG - 2018-02-15 15:35:53 --> UTF-8 Support Enabled
INFO - 2018-02-15 15:35:53 --> Utf8 Class Initialized
INFO - 2018-02-15 15:35:53 --> URI Class Initialized
INFO - 2018-02-15 15:35:53 --> Router Class Initialized
INFO - 2018-02-15 15:35:53 --> Output Class Initialized
INFO - 2018-02-15 15:35:53 --> Security Class Initialized
DEBUG - 2018-02-15 15:35:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 15:35:53 --> Input Class Initialized
INFO - 2018-02-15 15:35:53 --> Language Class Initialized
INFO - 2018-02-15 15:35:53 --> Loader Class Initialized
INFO - 2018-02-15 15:35:53 --> Helper loaded: url_helper
INFO - 2018-02-15 15:35:53 --> Helper loaded: file_helper
INFO - 2018-02-15 15:35:53 --> Helper loaded: email_helper
INFO - 2018-02-15 15:35:53 --> Helper loaded: common_helper
INFO - 2018-02-15 15:35:53 --> Database Driver Class Initialized
DEBUG - 2018-02-15 15:35:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 15:35:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 15:35:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 15:35:53 --> Pagination Class Initialized
INFO - 2018-02-15 15:35:53 --> Helper loaded: form_helper
INFO - 2018-02-15 15:35:53 --> Form Validation Class Initialized
INFO - 2018-02-15 15:35:53 --> Model Class Initialized
INFO - 2018-02-15 15:35:53 --> Controller Class Initialized
INFO - 2018-02-15 15:35:53 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 15:35:53 --> Model Class Initialized
INFO - 2018-02-15 15:35:53 --> Model Class Initialized
INFO - 2018-02-15 15:35:53 --> Model Class Initialized
INFO - 2018-02-15 15:35:53 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-15 15:35:53 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-15 15:35:53 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-15 15:35:53 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-15 15:35:53 --> File loaded: /var/www/html/project/radio/application/views/tracks/index.php
INFO - 2018-02-15 15:35:53 --> Final output sent to browser
DEBUG - 2018-02-15 15:35:53 --> Total execution time: 0.0052
INFO - 2018-02-15 15:35:53 --> Config Class Initialized
INFO - 2018-02-15 15:35:53 --> Hooks Class Initialized
DEBUG - 2018-02-15 15:35:53 --> UTF-8 Support Enabled
INFO - 2018-02-15 15:35:53 --> Utf8 Class Initialized
INFO - 2018-02-15 15:35:53 --> URI Class Initialized
INFO - 2018-02-15 15:35:53 --> Router Class Initialized
INFO - 2018-02-15 15:35:53 --> Output Class Initialized
INFO - 2018-02-15 15:35:53 --> Security Class Initialized
DEBUG - 2018-02-15 15:35:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 15:35:53 --> Input Class Initialized
INFO - 2018-02-15 15:35:53 --> Language Class Initialized
INFO - 2018-02-15 15:35:53 --> Loader Class Initialized
INFO - 2018-02-15 15:35:53 --> Helper loaded: url_helper
INFO - 2018-02-15 15:35:53 --> Helper loaded: file_helper
INFO - 2018-02-15 15:35:53 --> Helper loaded: email_helper
INFO - 2018-02-15 15:35:53 --> Helper loaded: common_helper
INFO - 2018-02-15 15:35:53 --> Database Driver Class Initialized
DEBUG - 2018-02-15 15:35:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 15:35:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 15:35:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 15:35:53 --> Pagination Class Initialized
INFO - 2018-02-15 15:35:53 --> Helper loaded: form_helper
INFO - 2018-02-15 15:35:53 --> Form Validation Class Initialized
INFO - 2018-02-15 15:35:53 --> Model Class Initialized
INFO - 2018-02-15 15:35:53 --> Controller Class Initialized
INFO - 2018-02-15 15:35:53 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 15:35:53 --> Model Class Initialized
INFO - 2018-02-15 15:35:53 --> Model Class Initialized
INFO - 2018-02-15 15:35:53 --> Model Class Initialized
INFO - 2018-02-15 15:35:55 --> Config Class Initialized
INFO - 2018-02-15 15:35:55 --> Hooks Class Initialized
DEBUG - 2018-02-15 15:35:55 --> UTF-8 Support Enabled
INFO - 2018-02-15 15:35:55 --> Utf8 Class Initialized
INFO - 2018-02-15 15:35:55 --> URI Class Initialized
INFO - 2018-02-15 15:35:55 --> Router Class Initialized
INFO - 2018-02-15 15:35:55 --> Output Class Initialized
INFO - 2018-02-15 15:35:55 --> Security Class Initialized
DEBUG - 2018-02-15 15:35:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 15:35:55 --> Input Class Initialized
INFO - 2018-02-15 15:35:55 --> Language Class Initialized
INFO - 2018-02-15 15:35:55 --> Loader Class Initialized
INFO - 2018-02-15 15:35:55 --> Helper loaded: url_helper
INFO - 2018-02-15 15:35:55 --> Helper loaded: file_helper
INFO - 2018-02-15 15:35:55 --> Helper loaded: email_helper
INFO - 2018-02-15 15:35:55 --> Helper loaded: common_helper
INFO - 2018-02-15 15:35:55 --> Database Driver Class Initialized
DEBUG - 2018-02-15 15:35:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 15:35:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 15:35:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 15:35:55 --> Pagination Class Initialized
INFO - 2018-02-15 15:35:55 --> Helper loaded: form_helper
INFO - 2018-02-15 15:35:55 --> Form Validation Class Initialized
INFO - 2018-02-15 15:35:55 --> Model Class Initialized
INFO - 2018-02-15 15:35:55 --> Controller Class Initialized
INFO - 2018-02-15 15:35:55 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 15:35:55 --> Model Class Initialized
INFO - 2018-02-15 15:35:55 --> Model Class Initialized
INFO - 2018-02-15 15:35:55 --> Model Class Initialized
INFO - 2018-02-15 15:35:55 --> Config Class Initialized
INFO - 2018-02-15 15:35:55 --> Hooks Class Initialized
DEBUG - 2018-02-15 15:35:55 --> UTF-8 Support Enabled
INFO - 2018-02-15 15:35:55 --> Utf8 Class Initialized
INFO - 2018-02-15 15:35:55 --> URI Class Initialized
INFO - 2018-02-15 15:35:55 --> Router Class Initialized
INFO - 2018-02-15 15:35:55 --> Output Class Initialized
INFO - 2018-02-15 15:35:55 --> Security Class Initialized
DEBUG - 2018-02-15 15:35:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 15:35:55 --> Input Class Initialized
INFO - 2018-02-15 15:35:55 --> Language Class Initialized
INFO - 2018-02-15 15:35:55 --> Loader Class Initialized
INFO - 2018-02-15 15:35:55 --> Helper loaded: url_helper
INFO - 2018-02-15 15:35:55 --> Helper loaded: file_helper
INFO - 2018-02-15 15:35:55 --> Helper loaded: email_helper
INFO - 2018-02-15 15:35:55 --> Helper loaded: common_helper
INFO - 2018-02-15 15:35:55 --> Database Driver Class Initialized
DEBUG - 2018-02-15 15:35:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 15:35:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 15:35:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 15:35:55 --> Pagination Class Initialized
INFO - 2018-02-15 15:35:55 --> Helper loaded: form_helper
INFO - 2018-02-15 15:35:55 --> Form Validation Class Initialized
INFO - 2018-02-15 15:35:55 --> Model Class Initialized
INFO - 2018-02-15 15:35:55 --> Controller Class Initialized
INFO - 2018-02-15 15:35:55 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 15:35:55 --> Model Class Initialized
INFO - 2018-02-15 15:35:55 --> Model Class Initialized
INFO - 2018-02-15 15:35:55 --> Model Class Initialized
INFO - 2018-02-15 15:35:56 --> Config Class Initialized
INFO - 2018-02-15 15:35:56 --> Hooks Class Initialized
DEBUG - 2018-02-15 15:35:56 --> UTF-8 Support Enabled
INFO - 2018-02-15 15:35:56 --> Utf8 Class Initialized
INFO - 2018-02-15 15:35:56 --> URI Class Initialized
INFO - 2018-02-15 15:35:56 --> Router Class Initialized
INFO - 2018-02-15 15:35:56 --> Output Class Initialized
INFO - 2018-02-15 15:35:56 --> Security Class Initialized
DEBUG - 2018-02-15 15:35:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 15:35:56 --> Input Class Initialized
INFO - 2018-02-15 15:35:56 --> Language Class Initialized
INFO - 2018-02-15 15:35:56 --> Loader Class Initialized
INFO - 2018-02-15 15:35:56 --> Helper loaded: url_helper
INFO - 2018-02-15 15:35:56 --> Helper loaded: file_helper
INFO - 2018-02-15 15:35:56 --> Helper loaded: email_helper
INFO - 2018-02-15 15:35:56 --> Helper loaded: common_helper
INFO - 2018-02-15 15:35:56 --> Database Driver Class Initialized
DEBUG - 2018-02-15 15:35:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 15:35:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 15:35:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 15:35:56 --> Pagination Class Initialized
INFO - 2018-02-15 15:35:56 --> Helper loaded: form_helper
INFO - 2018-02-15 15:35:56 --> Form Validation Class Initialized
INFO - 2018-02-15 15:35:56 --> Model Class Initialized
INFO - 2018-02-15 15:35:56 --> Controller Class Initialized
INFO - 2018-02-15 15:35:56 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 15:35:56 --> Model Class Initialized
INFO - 2018-02-15 15:35:56 --> Model Class Initialized
INFO - 2018-02-15 15:35:56 --> Model Class Initialized
INFO - 2018-02-15 15:35:56 --> Config Class Initialized
INFO - 2018-02-15 15:35:56 --> Hooks Class Initialized
DEBUG - 2018-02-15 15:35:56 --> UTF-8 Support Enabled
INFO - 2018-02-15 15:35:56 --> Utf8 Class Initialized
INFO - 2018-02-15 15:35:56 --> URI Class Initialized
INFO - 2018-02-15 15:35:56 --> Router Class Initialized
INFO - 2018-02-15 15:35:56 --> Output Class Initialized
INFO - 2018-02-15 15:35:56 --> Security Class Initialized
DEBUG - 2018-02-15 15:35:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 15:35:56 --> Input Class Initialized
INFO - 2018-02-15 15:35:56 --> Language Class Initialized
INFO - 2018-02-15 15:35:56 --> Loader Class Initialized
INFO - 2018-02-15 15:35:56 --> Helper loaded: url_helper
INFO - 2018-02-15 15:35:56 --> Helper loaded: file_helper
INFO - 2018-02-15 15:35:56 --> Helper loaded: email_helper
INFO - 2018-02-15 15:35:56 --> Helper loaded: common_helper
INFO - 2018-02-15 15:35:56 --> Database Driver Class Initialized
DEBUG - 2018-02-15 15:35:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 15:35:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 15:35:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 15:35:56 --> Pagination Class Initialized
INFO - 2018-02-15 15:35:56 --> Helper loaded: form_helper
INFO - 2018-02-15 15:35:56 --> Form Validation Class Initialized
INFO - 2018-02-15 15:35:56 --> Model Class Initialized
INFO - 2018-02-15 15:35:56 --> Controller Class Initialized
INFO - 2018-02-15 15:35:56 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 15:35:56 --> Model Class Initialized
INFO - 2018-02-15 15:35:56 --> Model Class Initialized
INFO - 2018-02-15 15:35:56 --> Model Class Initialized
INFO - 2018-02-15 15:35:57 --> Config Class Initialized
INFO - 2018-02-15 15:35:57 --> Hooks Class Initialized
DEBUG - 2018-02-15 15:35:57 --> UTF-8 Support Enabled
INFO - 2018-02-15 15:35:57 --> Utf8 Class Initialized
INFO - 2018-02-15 15:35:57 --> URI Class Initialized
INFO - 2018-02-15 15:35:57 --> Router Class Initialized
INFO - 2018-02-15 15:35:57 --> Output Class Initialized
INFO - 2018-02-15 15:35:57 --> Security Class Initialized
DEBUG - 2018-02-15 15:35:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 15:35:57 --> Input Class Initialized
INFO - 2018-02-15 15:35:57 --> Language Class Initialized
INFO - 2018-02-15 15:35:57 --> Loader Class Initialized
INFO - 2018-02-15 15:35:57 --> Helper loaded: url_helper
INFO - 2018-02-15 15:35:57 --> Helper loaded: file_helper
INFO - 2018-02-15 15:35:57 --> Helper loaded: email_helper
INFO - 2018-02-15 15:35:57 --> Helper loaded: common_helper
INFO - 2018-02-15 15:35:57 --> Database Driver Class Initialized
DEBUG - 2018-02-15 15:35:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 15:35:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 15:35:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 15:35:57 --> Pagination Class Initialized
INFO - 2018-02-15 15:35:57 --> Helper loaded: form_helper
INFO - 2018-02-15 15:35:57 --> Form Validation Class Initialized
INFO - 2018-02-15 15:35:57 --> Model Class Initialized
INFO - 2018-02-15 15:35:57 --> Controller Class Initialized
INFO - 2018-02-15 15:35:57 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 15:35:57 --> Model Class Initialized
INFO - 2018-02-15 15:35:57 --> Model Class Initialized
INFO - 2018-02-15 15:35:57 --> Model Class Initialized
INFO - 2018-02-15 15:35:57 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-15 15:35:57 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-15 15:35:57 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-15 15:35:57 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-15 15:35:57 --> File loaded: /var/www/html/project/radio/application/views/tracks/index.php
INFO - 2018-02-15 15:35:57 --> Final output sent to browser
DEBUG - 2018-02-15 15:35:57 --> Total execution time: 0.0059
INFO - 2018-02-15 15:35:57 --> Config Class Initialized
INFO - 2018-02-15 15:35:57 --> Hooks Class Initialized
DEBUG - 2018-02-15 15:35:57 --> UTF-8 Support Enabled
INFO - 2018-02-15 15:35:57 --> Utf8 Class Initialized
INFO - 2018-02-15 15:35:57 --> URI Class Initialized
INFO - 2018-02-15 15:35:57 --> Router Class Initialized
INFO - 2018-02-15 15:35:57 --> Output Class Initialized
INFO - 2018-02-15 15:35:57 --> Security Class Initialized
DEBUG - 2018-02-15 15:35:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 15:35:57 --> Input Class Initialized
INFO - 2018-02-15 15:35:57 --> Language Class Initialized
INFO - 2018-02-15 15:35:57 --> Loader Class Initialized
INFO - 2018-02-15 15:35:57 --> Helper loaded: url_helper
INFO - 2018-02-15 15:35:57 --> Helper loaded: file_helper
INFO - 2018-02-15 15:35:57 --> Helper loaded: email_helper
INFO - 2018-02-15 15:35:57 --> Helper loaded: common_helper
INFO - 2018-02-15 15:35:57 --> Database Driver Class Initialized
DEBUG - 2018-02-15 15:35:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 15:35:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 15:35:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 15:35:57 --> Pagination Class Initialized
INFO - 2018-02-15 15:35:57 --> Helper loaded: form_helper
INFO - 2018-02-15 15:35:57 --> Form Validation Class Initialized
INFO - 2018-02-15 15:35:57 --> Model Class Initialized
INFO - 2018-02-15 15:35:57 --> Controller Class Initialized
INFO - 2018-02-15 15:35:57 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 15:35:57 --> Model Class Initialized
INFO - 2018-02-15 15:35:57 --> Model Class Initialized
INFO - 2018-02-15 15:35:57 --> Model Class Initialized
INFO - 2018-02-15 15:36:06 --> Config Class Initialized
INFO - 2018-02-15 15:36:06 --> Hooks Class Initialized
DEBUG - 2018-02-15 15:36:06 --> UTF-8 Support Enabled
INFO - 2018-02-15 15:36:06 --> Utf8 Class Initialized
INFO - 2018-02-15 15:36:06 --> URI Class Initialized
INFO - 2018-02-15 15:36:06 --> Router Class Initialized
INFO - 2018-02-15 15:36:06 --> Output Class Initialized
INFO - 2018-02-15 15:36:06 --> Security Class Initialized
DEBUG - 2018-02-15 15:36:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 15:36:06 --> Input Class Initialized
INFO - 2018-02-15 15:36:06 --> Language Class Initialized
INFO - 2018-02-15 15:36:06 --> Loader Class Initialized
INFO - 2018-02-15 15:36:06 --> Helper loaded: url_helper
INFO - 2018-02-15 15:36:06 --> Helper loaded: file_helper
INFO - 2018-02-15 15:36:06 --> Helper loaded: email_helper
INFO - 2018-02-15 15:36:06 --> Helper loaded: common_helper
INFO - 2018-02-15 15:36:06 --> Database Driver Class Initialized
DEBUG - 2018-02-15 15:36:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 15:36:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 15:36:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 15:36:06 --> Pagination Class Initialized
INFO - 2018-02-15 15:36:06 --> Helper loaded: form_helper
INFO - 2018-02-15 15:36:06 --> Form Validation Class Initialized
INFO - 2018-02-15 15:36:06 --> Model Class Initialized
INFO - 2018-02-15 15:36:06 --> Controller Class Initialized
INFO - 2018-02-15 15:36:06 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 15:36:06 --> Model Class Initialized
INFO - 2018-02-15 15:36:06 --> Model Class Initialized
INFO - 2018-02-15 15:36:06 --> Model Class Initialized
INFO - 2018-02-15 15:36:06 --> Config Class Initialized
INFO - 2018-02-15 15:36:06 --> Hooks Class Initialized
DEBUG - 2018-02-15 15:36:06 --> UTF-8 Support Enabled
INFO - 2018-02-15 15:36:06 --> Utf8 Class Initialized
INFO - 2018-02-15 15:36:06 --> URI Class Initialized
INFO - 2018-02-15 15:36:06 --> Router Class Initialized
INFO - 2018-02-15 15:36:06 --> Output Class Initialized
INFO - 2018-02-15 15:36:06 --> Security Class Initialized
DEBUG - 2018-02-15 15:36:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 15:36:06 --> Input Class Initialized
INFO - 2018-02-15 15:36:06 --> Language Class Initialized
INFO - 2018-02-15 15:36:06 --> Loader Class Initialized
INFO - 2018-02-15 15:36:06 --> Helper loaded: url_helper
INFO - 2018-02-15 15:36:06 --> Helper loaded: file_helper
INFO - 2018-02-15 15:36:06 --> Helper loaded: email_helper
INFO - 2018-02-15 15:36:06 --> Helper loaded: common_helper
INFO - 2018-02-15 15:36:06 --> Database Driver Class Initialized
DEBUG - 2018-02-15 15:36:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 15:36:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 15:36:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 15:36:06 --> Pagination Class Initialized
INFO - 2018-02-15 15:36:06 --> Helper loaded: form_helper
INFO - 2018-02-15 15:36:06 --> Form Validation Class Initialized
INFO - 2018-02-15 15:36:06 --> Model Class Initialized
INFO - 2018-02-15 15:36:06 --> Controller Class Initialized
INFO - 2018-02-15 15:36:06 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 15:36:06 --> Model Class Initialized
INFO - 2018-02-15 15:36:06 --> Model Class Initialized
INFO - 2018-02-15 15:36:06 --> Model Class Initialized
INFO - 2018-02-15 15:36:09 --> Config Class Initialized
INFO - 2018-02-15 15:36:09 --> Hooks Class Initialized
DEBUG - 2018-02-15 15:36:09 --> UTF-8 Support Enabled
INFO - 2018-02-15 15:36:09 --> Utf8 Class Initialized
INFO - 2018-02-15 15:36:09 --> URI Class Initialized
INFO - 2018-02-15 15:36:09 --> Router Class Initialized
INFO - 2018-02-15 15:36:09 --> Output Class Initialized
INFO - 2018-02-15 15:36:09 --> Security Class Initialized
DEBUG - 2018-02-15 15:36:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 15:36:09 --> Input Class Initialized
INFO - 2018-02-15 15:36:09 --> Language Class Initialized
INFO - 2018-02-15 15:36:09 --> Loader Class Initialized
INFO - 2018-02-15 15:36:09 --> Helper loaded: url_helper
INFO - 2018-02-15 15:36:09 --> Helper loaded: file_helper
INFO - 2018-02-15 15:36:09 --> Helper loaded: email_helper
INFO - 2018-02-15 15:36:09 --> Helper loaded: common_helper
INFO - 2018-02-15 15:36:09 --> Database Driver Class Initialized
DEBUG - 2018-02-15 15:36:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 15:36:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 15:36:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 15:36:09 --> Pagination Class Initialized
INFO - 2018-02-15 15:36:09 --> Helper loaded: form_helper
INFO - 2018-02-15 15:36:09 --> Form Validation Class Initialized
INFO - 2018-02-15 15:36:09 --> Model Class Initialized
INFO - 2018-02-15 15:36:09 --> Controller Class Initialized
INFO - 2018-02-15 15:36:09 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 15:36:09 --> Model Class Initialized
INFO - 2018-02-15 15:36:09 --> Model Class Initialized
INFO - 2018-02-15 15:36:09 --> Model Class Initialized
INFO - 2018-02-15 15:36:09 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-15 15:36:09 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-15 15:36:09 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-15 15:36:09 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-15 15:36:09 --> File loaded: /var/www/html/project/radio/application/views/tracks/index.php
INFO - 2018-02-15 15:36:09 --> Final output sent to browser
DEBUG - 2018-02-15 15:36:09 --> Total execution time: 0.0062
INFO - 2018-02-15 15:36:10 --> Config Class Initialized
INFO - 2018-02-15 15:36:10 --> Hooks Class Initialized
DEBUG - 2018-02-15 15:36:10 --> UTF-8 Support Enabled
INFO - 2018-02-15 15:36:10 --> Utf8 Class Initialized
INFO - 2018-02-15 15:36:10 --> URI Class Initialized
INFO - 2018-02-15 15:36:10 --> Router Class Initialized
INFO - 2018-02-15 15:36:10 --> Output Class Initialized
INFO - 2018-02-15 15:36:10 --> Security Class Initialized
DEBUG - 2018-02-15 15:36:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 15:36:10 --> Input Class Initialized
INFO - 2018-02-15 15:36:10 --> Language Class Initialized
INFO - 2018-02-15 15:36:10 --> Loader Class Initialized
INFO - 2018-02-15 15:36:10 --> Helper loaded: url_helper
INFO - 2018-02-15 15:36:10 --> Helper loaded: file_helper
INFO - 2018-02-15 15:36:10 --> Helper loaded: email_helper
INFO - 2018-02-15 15:36:10 --> Helper loaded: common_helper
INFO - 2018-02-15 15:36:10 --> Database Driver Class Initialized
DEBUG - 2018-02-15 15:36:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 15:36:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 15:36:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 15:36:10 --> Pagination Class Initialized
INFO - 2018-02-15 15:36:10 --> Helper loaded: form_helper
INFO - 2018-02-15 15:36:10 --> Form Validation Class Initialized
INFO - 2018-02-15 15:36:10 --> Model Class Initialized
INFO - 2018-02-15 15:36:10 --> Controller Class Initialized
INFO - 2018-02-15 15:36:10 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 15:36:10 --> Model Class Initialized
INFO - 2018-02-15 15:36:10 --> Model Class Initialized
INFO - 2018-02-15 15:36:10 --> Model Class Initialized
INFO - 2018-02-15 15:37:33 --> Config Class Initialized
INFO - 2018-02-15 15:37:33 --> Hooks Class Initialized
DEBUG - 2018-02-15 15:37:33 --> UTF-8 Support Enabled
INFO - 2018-02-15 15:37:33 --> Utf8 Class Initialized
INFO - 2018-02-15 15:37:33 --> URI Class Initialized
INFO - 2018-02-15 15:37:33 --> Router Class Initialized
INFO - 2018-02-15 15:37:33 --> Output Class Initialized
INFO - 2018-02-15 15:37:33 --> Security Class Initialized
DEBUG - 2018-02-15 15:37:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 15:37:33 --> Input Class Initialized
INFO - 2018-02-15 15:37:33 --> Language Class Initialized
INFO - 2018-02-15 15:37:33 --> Loader Class Initialized
INFO - 2018-02-15 15:37:33 --> Helper loaded: url_helper
INFO - 2018-02-15 15:37:33 --> Helper loaded: file_helper
INFO - 2018-02-15 15:37:33 --> Helper loaded: email_helper
INFO - 2018-02-15 15:37:33 --> Helper loaded: common_helper
INFO - 2018-02-15 15:37:33 --> Database Driver Class Initialized
DEBUG - 2018-02-15 15:37:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 15:37:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 15:37:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 15:37:33 --> Pagination Class Initialized
INFO - 2018-02-15 15:37:33 --> Helper loaded: form_helper
INFO - 2018-02-15 15:37:33 --> Form Validation Class Initialized
INFO - 2018-02-15 15:37:33 --> Model Class Initialized
INFO - 2018-02-15 15:37:33 --> Controller Class Initialized
INFO - 2018-02-15 15:37:33 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 15:37:33 --> Model Class Initialized
INFO - 2018-02-15 15:37:33 --> Model Class Initialized
INFO - 2018-02-15 15:37:33 --> Model Class Initialized
INFO - 2018-02-15 15:37:33 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-15 15:37:33 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-15 15:37:33 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-15 15:37:33 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-15 15:37:33 --> File loaded: /var/www/html/project/radio/application/views/tracks/index.php
INFO - 2018-02-15 15:37:33 --> Final output sent to browser
DEBUG - 2018-02-15 15:37:33 --> Total execution time: 0.0107
INFO - 2018-02-15 15:37:34 --> Config Class Initialized
INFO - 2018-02-15 15:37:34 --> Hooks Class Initialized
DEBUG - 2018-02-15 15:37:34 --> UTF-8 Support Enabled
INFO - 2018-02-15 15:37:34 --> Utf8 Class Initialized
INFO - 2018-02-15 15:37:34 --> URI Class Initialized
INFO - 2018-02-15 15:37:34 --> Router Class Initialized
INFO - 2018-02-15 15:37:34 --> Output Class Initialized
INFO - 2018-02-15 15:37:34 --> Security Class Initialized
DEBUG - 2018-02-15 15:37:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 15:37:34 --> Input Class Initialized
INFO - 2018-02-15 15:37:34 --> Language Class Initialized
INFO - 2018-02-15 15:37:34 --> Loader Class Initialized
INFO - 2018-02-15 15:37:34 --> Helper loaded: url_helper
INFO - 2018-02-15 15:37:34 --> Helper loaded: file_helper
INFO - 2018-02-15 15:37:34 --> Helper loaded: email_helper
INFO - 2018-02-15 15:37:34 --> Helper loaded: common_helper
INFO - 2018-02-15 15:37:34 --> Database Driver Class Initialized
DEBUG - 2018-02-15 15:37:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 15:37:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 15:37:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 15:37:34 --> Pagination Class Initialized
INFO - 2018-02-15 15:37:34 --> Helper loaded: form_helper
INFO - 2018-02-15 15:37:34 --> Form Validation Class Initialized
INFO - 2018-02-15 15:37:34 --> Model Class Initialized
INFO - 2018-02-15 15:37:34 --> Controller Class Initialized
INFO - 2018-02-15 15:37:34 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 15:37:34 --> Model Class Initialized
INFO - 2018-02-15 15:37:34 --> Model Class Initialized
INFO - 2018-02-15 15:37:34 --> Model Class Initialized
INFO - 2018-02-15 15:37:37 --> Config Class Initialized
INFO - 2018-02-15 15:37:37 --> Hooks Class Initialized
DEBUG - 2018-02-15 15:37:37 --> UTF-8 Support Enabled
INFO - 2018-02-15 15:37:37 --> Utf8 Class Initialized
INFO - 2018-02-15 15:37:37 --> URI Class Initialized
INFO - 2018-02-15 15:37:37 --> Router Class Initialized
INFO - 2018-02-15 15:37:37 --> Output Class Initialized
INFO - 2018-02-15 15:37:37 --> Security Class Initialized
DEBUG - 2018-02-15 15:37:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 15:37:37 --> Input Class Initialized
INFO - 2018-02-15 15:37:37 --> Language Class Initialized
INFO - 2018-02-15 15:37:37 --> Loader Class Initialized
INFO - 2018-02-15 15:37:37 --> Helper loaded: url_helper
INFO - 2018-02-15 15:37:37 --> Helper loaded: file_helper
INFO - 2018-02-15 15:37:37 --> Helper loaded: email_helper
INFO - 2018-02-15 15:37:37 --> Helper loaded: common_helper
INFO - 2018-02-15 15:37:37 --> Database Driver Class Initialized
DEBUG - 2018-02-15 15:37:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 15:37:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 15:37:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 15:37:37 --> Pagination Class Initialized
INFO - 2018-02-15 15:37:37 --> Helper loaded: form_helper
INFO - 2018-02-15 15:37:37 --> Form Validation Class Initialized
INFO - 2018-02-15 15:37:37 --> Model Class Initialized
INFO - 2018-02-15 15:37:37 --> Controller Class Initialized
INFO - 2018-02-15 15:37:37 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 15:37:37 --> Model Class Initialized
INFO - 2018-02-15 15:37:37 --> Model Class Initialized
INFO - 2018-02-15 15:37:37 --> Model Class Initialized
INFO - 2018-02-15 15:37:37 --> Config Class Initialized
INFO - 2018-02-15 15:37:37 --> Hooks Class Initialized
DEBUG - 2018-02-15 15:37:37 --> UTF-8 Support Enabled
INFO - 2018-02-15 15:37:37 --> Utf8 Class Initialized
INFO - 2018-02-15 15:37:37 --> URI Class Initialized
INFO - 2018-02-15 15:37:37 --> Router Class Initialized
INFO - 2018-02-15 15:37:37 --> Output Class Initialized
INFO - 2018-02-15 15:37:37 --> Security Class Initialized
DEBUG - 2018-02-15 15:37:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 15:37:37 --> Input Class Initialized
INFO - 2018-02-15 15:37:37 --> Language Class Initialized
INFO - 2018-02-15 15:37:37 --> Loader Class Initialized
INFO - 2018-02-15 15:37:37 --> Helper loaded: url_helper
INFO - 2018-02-15 15:37:37 --> Helper loaded: file_helper
INFO - 2018-02-15 15:37:37 --> Helper loaded: email_helper
INFO - 2018-02-15 15:37:37 --> Helper loaded: common_helper
INFO - 2018-02-15 15:37:37 --> Database Driver Class Initialized
DEBUG - 2018-02-15 15:37:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 15:37:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 15:37:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 15:37:37 --> Pagination Class Initialized
INFO - 2018-02-15 15:37:37 --> Helper loaded: form_helper
INFO - 2018-02-15 15:37:37 --> Form Validation Class Initialized
INFO - 2018-02-15 15:37:37 --> Model Class Initialized
INFO - 2018-02-15 15:37:37 --> Controller Class Initialized
INFO - 2018-02-15 15:37:37 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 15:37:37 --> Model Class Initialized
INFO - 2018-02-15 15:37:37 --> Model Class Initialized
INFO - 2018-02-15 15:37:37 --> Model Class Initialized
INFO - 2018-02-15 15:38:08 --> Config Class Initialized
INFO - 2018-02-15 15:38:08 --> Hooks Class Initialized
DEBUG - 2018-02-15 15:38:08 --> UTF-8 Support Enabled
INFO - 2018-02-15 15:38:08 --> Utf8 Class Initialized
INFO - 2018-02-15 15:38:08 --> URI Class Initialized
INFO - 2018-02-15 15:38:08 --> Router Class Initialized
INFO - 2018-02-15 15:38:08 --> Output Class Initialized
INFO - 2018-02-15 15:38:08 --> Security Class Initialized
DEBUG - 2018-02-15 15:38:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 15:38:08 --> Input Class Initialized
INFO - 2018-02-15 15:38:08 --> Language Class Initialized
INFO - 2018-02-15 15:38:08 --> Loader Class Initialized
INFO - 2018-02-15 15:38:08 --> Helper loaded: url_helper
INFO - 2018-02-15 15:38:08 --> Helper loaded: file_helper
INFO - 2018-02-15 15:38:08 --> Helper loaded: email_helper
INFO - 2018-02-15 15:38:08 --> Helper loaded: common_helper
INFO - 2018-02-15 15:38:08 --> Database Driver Class Initialized
DEBUG - 2018-02-15 15:38:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 15:38:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 15:38:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 15:38:08 --> Pagination Class Initialized
INFO - 2018-02-15 15:38:08 --> Helper loaded: form_helper
INFO - 2018-02-15 15:38:08 --> Form Validation Class Initialized
INFO - 2018-02-15 15:38:08 --> Model Class Initialized
INFO - 2018-02-15 15:38:08 --> Controller Class Initialized
INFO - 2018-02-15 15:38:08 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 15:38:08 --> Model Class Initialized
INFO - 2018-02-15 15:38:08 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-15 15:38:08 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-15 15:38:08 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-15 15:38:08 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-15 15:38:08 --> File loaded: /var/www/html/project/radio/application/views/category/index.php
INFO - 2018-02-15 15:38:08 --> Final output sent to browser
DEBUG - 2018-02-15 15:38:08 --> Total execution time: 0.0076
INFO - 2018-02-15 15:38:11 --> Config Class Initialized
INFO - 2018-02-15 15:38:11 --> Hooks Class Initialized
DEBUG - 2018-02-15 15:38:11 --> UTF-8 Support Enabled
INFO - 2018-02-15 15:38:11 --> Utf8 Class Initialized
INFO - 2018-02-15 15:38:11 --> URI Class Initialized
INFO - 2018-02-15 15:38:11 --> Router Class Initialized
INFO - 2018-02-15 15:38:11 --> Output Class Initialized
INFO - 2018-02-15 15:38:11 --> Security Class Initialized
DEBUG - 2018-02-15 15:38:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 15:38:11 --> Input Class Initialized
INFO - 2018-02-15 15:38:11 --> Language Class Initialized
INFO - 2018-02-15 15:38:11 --> Loader Class Initialized
INFO - 2018-02-15 15:38:11 --> Helper loaded: url_helper
INFO - 2018-02-15 15:38:11 --> Helper loaded: file_helper
INFO - 2018-02-15 15:38:11 --> Helper loaded: email_helper
INFO - 2018-02-15 15:38:11 --> Helper loaded: common_helper
INFO - 2018-02-15 15:38:11 --> Database Driver Class Initialized
DEBUG - 2018-02-15 15:38:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 15:38:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 15:38:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 15:38:11 --> Pagination Class Initialized
INFO - 2018-02-15 15:38:11 --> Helper loaded: form_helper
INFO - 2018-02-15 15:38:11 --> Form Validation Class Initialized
INFO - 2018-02-15 15:38:11 --> Model Class Initialized
INFO - 2018-02-15 15:38:11 --> Controller Class Initialized
INFO - 2018-02-15 15:38:11 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 15:38:11 --> Model Class Initialized
INFO - 2018-02-15 15:38:11 --> Config Class Initialized
INFO - 2018-02-15 15:38:11 --> Hooks Class Initialized
DEBUG - 2018-02-15 15:38:11 --> UTF-8 Support Enabled
INFO - 2018-02-15 15:38:11 --> Utf8 Class Initialized
INFO - 2018-02-15 15:38:11 --> URI Class Initialized
INFO - 2018-02-15 15:38:11 --> Router Class Initialized
INFO - 2018-02-15 15:38:11 --> Output Class Initialized
INFO - 2018-02-15 15:38:11 --> Security Class Initialized
DEBUG - 2018-02-15 15:38:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 15:38:11 --> Input Class Initialized
INFO - 2018-02-15 15:38:11 --> Language Class Initialized
INFO - 2018-02-15 15:38:11 --> Loader Class Initialized
INFO - 2018-02-15 15:38:11 --> Helper loaded: url_helper
INFO - 2018-02-15 15:38:11 --> Helper loaded: file_helper
INFO - 2018-02-15 15:38:11 --> Helper loaded: email_helper
INFO - 2018-02-15 15:38:11 --> Helper loaded: common_helper
INFO - 2018-02-15 15:38:11 --> Database Driver Class Initialized
DEBUG - 2018-02-15 15:38:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 15:38:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 15:38:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 15:38:11 --> Pagination Class Initialized
INFO - 2018-02-15 15:38:11 --> Helper loaded: form_helper
INFO - 2018-02-15 15:38:11 --> Form Validation Class Initialized
INFO - 2018-02-15 15:38:11 --> Model Class Initialized
INFO - 2018-02-15 15:38:11 --> Controller Class Initialized
INFO - 2018-02-15 15:38:11 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 15:38:11 --> Model Class Initialized
INFO - 2018-02-15 15:38:11 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-15 15:38:11 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-15 15:38:11 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-15 15:38:11 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-15 15:38:11 --> File loaded: /var/www/html/project/radio/application/views/category/index.php
INFO - 2018-02-15 15:38:11 --> Final output sent to browser
DEBUG - 2018-02-15 15:38:11 --> Total execution time: 0.0048
INFO - 2018-02-15 15:38:21 --> Config Class Initialized
INFO - 2018-02-15 15:38:21 --> Hooks Class Initialized
DEBUG - 2018-02-15 15:38:21 --> UTF-8 Support Enabled
INFO - 2018-02-15 15:38:21 --> Utf8 Class Initialized
INFO - 2018-02-15 15:38:21 --> URI Class Initialized
INFO - 2018-02-15 15:38:21 --> Router Class Initialized
INFO - 2018-02-15 15:38:21 --> Output Class Initialized
INFO - 2018-02-15 15:38:21 --> Security Class Initialized
DEBUG - 2018-02-15 15:38:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 15:38:21 --> Input Class Initialized
INFO - 2018-02-15 15:38:21 --> Language Class Initialized
INFO - 2018-02-15 15:38:21 --> Loader Class Initialized
INFO - 2018-02-15 15:38:21 --> Helper loaded: url_helper
INFO - 2018-02-15 15:38:21 --> Helper loaded: file_helper
INFO - 2018-02-15 15:38:21 --> Helper loaded: email_helper
INFO - 2018-02-15 15:38:21 --> Helper loaded: common_helper
INFO - 2018-02-15 15:38:21 --> Database Driver Class Initialized
DEBUG - 2018-02-15 15:38:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 15:38:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 15:38:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 15:38:21 --> Pagination Class Initialized
INFO - 2018-02-15 15:38:21 --> Helper loaded: form_helper
INFO - 2018-02-15 15:38:21 --> Form Validation Class Initialized
INFO - 2018-02-15 15:38:21 --> Model Class Initialized
INFO - 2018-02-15 15:38:21 --> Controller Class Initialized
INFO - 2018-02-15 15:38:21 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 15:38:21 --> Model Class Initialized
INFO - 2018-02-15 15:38:21 --> Model Class Initialized
INFO - 2018-02-15 15:38:21 --> Model Class Initialized
INFO - 2018-02-15 15:38:21 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-15 15:38:21 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-15 15:38:21 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-15 15:38:21 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-15 15:38:21 --> File loaded: /var/www/html/project/radio/application/views/tracks/index.php
INFO - 2018-02-15 15:38:21 --> Final output sent to browser
DEBUG - 2018-02-15 15:38:21 --> Total execution time: 0.0055
INFO - 2018-02-15 15:38:21 --> Config Class Initialized
INFO - 2018-02-15 15:38:21 --> Hooks Class Initialized
DEBUG - 2018-02-15 15:38:21 --> UTF-8 Support Enabled
INFO - 2018-02-15 15:38:21 --> Utf8 Class Initialized
INFO - 2018-02-15 15:38:21 --> URI Class Initialized
INFO - 2018-02-15 15:38:21 --> Router Class Initialized
INFO - 2018-02-15 15:38:21 --> Output Class Initialized
INFO - 2018-02-15 15:38:21 --> Security Class Initialized
DEBUG - 2018-02-15 15:38:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 15:38:21 --> Input Class Initialized
INFO - 2018-02-15 15:38:21 --> Language Class Initialized
INFO - 2018-02-15 15:38:21 --> Loader Class Initialized
INFO - 2018-02-15 15:38:21 --> Helper loaded: url_helper
INFO - 2018-02-15 15:38:21 --> Helper loaded: file_helper
INFO - 2018-02-15 15:38:21 --> Helper loaded: email_helper
INFO - 2018-02-15 15:38:21 --> Helper loaded: common_helper
INFO - 2018-02-15 15:38:21 --> Database Driver Class Initialized
DEBUG - 2018-02-15 15:38:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 15:38:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 15:38:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 15:38:21 --> Pagination Class Initialized
INFO - 2018-02-15 15:38:21 --> Helper loaded: form_helper
INFO - 2018-02-15 15:38:21 --> Form Validation Class Initialized
INFO - 2018-02-15 15:38:21 --> Model Class Initialized
INFO - 2018-02-15 15:38:21 --> Controller Class Initialized
INFO - 2018-02-15 15:38:21 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 15:38:21 --> Model Class Initialized
INFO - 2018-02-15 15:38:21 --> Model Class Initialized
INFO - 2018-02-15 15:38:21 --> Model Class Initialized
INFO - 2018-02-15 15:38:35 --> Config Class Initialized
INFO - 2018-02-15 15:38:35 --> Hooks Class Initialized
DEBUG - 2018-02-15 15:38:35 --> UTF-8 Support Enabled
INFO - 2018-02-15 15:38:35 --> Utf8 Class Initialized
INFO - 2018-02-15 15:38:35 --> URI Class Initialized
INFO - 2018-02-15 15:38:35 --> Router Class Initialized
INFO - 2018-02-15 15:38:35 --> Output Class Initialized
INFO - 2018-02-15 15:38:35 --> Security Class Initialized
DEBUG - 2018-02-15 15:38:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 15:38:35 --> Input Class Initialized
INFO - 2018-02-15 15:38:35 --> Language Class Initialized
INFO - 2018-02-15 15:38:35 --> Loader Class Initialized
INFO - 2018-02-15 15:38:35 --> Helper loaded: url_helper
INFO - 2018-02-15 15:38:35 --> Helper loaded: file_helper
INFO - 2018-02-15 15:38:35 --> Helper loaded: email_helper
INFO - 2018-02-15 15:38:35 --> Helper loaded: common_helper
INFO - 2018-02-15 15:38:35 --> Database Driver Class Initialized
DEBUG - 2018-02-15 15:38:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 15:38:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 15:38:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 15:38:35 --> Pagination Class Initialized
INFO - 2018-02-15 15:38:35 --> Helper loaded: form_helper
INFO - 2018-02-15 15:38:35 --> Form Validation Class Initialized
INFO - 2018-02-15 15:38:35 --> Model Class Initialized
INFO - 2018-02-15 15:38:35 --> Controller Class Initialized
INFO - 2018-02-15 15:38:35 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 15:38:35 --> Model Class Initialized
INFO - 2018-02-15 15:38:35 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-15 15:38:35 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-15 15:38:35 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-15 15:38:35 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-15 15:38:35 --> File loaded: /var/www/html/project/radio/application/views/category/index.php
INFO - 2018-02-15 15:38:35 --> Final output sent to browser
DEBUG - 2018-02-15 15:38:35 --> Total execution time: 0.0060
INFO - 2018-02-15 15:38:38 --> Config Class Initialized
INFO - 2018-02-15 15:38:38 --> Hooks Class Initialized
DEBUG - 2018-02-15 15:38:38 --> UTF-8 Support Enabled
INFO - 2018-02-15 15:38:38 --> Utf8 Class Initialized
INFO - 2018-02-15 15:38:38 --> URI Class Initialized
INFO - 2018-02-15 15:38:38 --> Router Class Initialized
INFO - 2018-02-15 15:38:38 --> Output Class Initialized
INFO - 2018-02-15 15:38:38 --> Security Class Initialized
DEBUG - 2018-02-15 15:38:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 15:38:38 --> Input Class Initialized
INFO - 2018-02-15 15:38:38 --> Language Class Initialized
INFO - 2018-02-15 15:38:38 --> Loader Class Initialized
INFO - 2018-02-15 15:38:38 --> Helper loaded: url_helper
INFO - 2018-02-15 15:38:38 --> Helper loaded: file_helper
INFO - 2018-02-15 15:38:38 --> Helper loaded: email_helper
INFO - 2018-02-15 15:38:38 --> Helper loaded: common_helper
INFO - 2018-02-15 15:38:38 --> Database Driver Class Initialized
DEBUG - 2018-02-15 15:38:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 15:38:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 15:38:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 15:38:38 --> Pagination Class Initialized
INFO - 2018-02-15 15:38:38 --> Helper loaded: form_helper
INFO - 2018-02-15 15:38:38 --> Form Validation Class Initialized
INFO - 2018-02-15 15:38:38 --> Model Class Initialized
INFO - 2018-02-15 15:38:38 --> Controller Class Initialized
INFO - 2018-02-15 15:38:38 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 15:38:38 --> Model Class Initialized
INFO - 2018-02-15 15:38:38 --> Model Class Initialized
INFO - 2018-02-15 15:38:38 --> Model Class Initialized
INFO - 2018-02-15 15:38:38 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-15 15:38:38 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-15 15:38:38 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-15 15:38:38 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-15 15:38:38 --> File loaded: /var/www/html/project/radio/application/views/tracks/index.php
INFO - 2018-02-15 15:38:38 --> Final output sent to browser
DEBUG - 2018-02-15 15:38:38 --> Total execution time: 0.0065
INFO - 2018-02-15 15:38:39 --> Config Class Initialized
INFO - 2018-02-15 15:38:39 --> Hooks Class Initialized
DEBUG - 2018-02-15 15:38:39 --> UTF-8 Support Enabled
INFO - 2018-02-15 15:38:39 --> Utf8 Class Initialized
INFO - 2018-02-15 15:38:39 --> URI Class Initialized
INFO - 2018-02-15 15:38:39 --> Router Class Initialized
INFO - 2018-02-15 15:38:39 --> Output Class Initialized
INFO - 2018-02-15 15:38:39 --> Security Class Initialized
DEBUG - 2018-02-15 15:38:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 15:38:39 --> Input Class Initialized
INFO - 2018-02-15 15:38:39 --> Language Class Initialized
INFO - 2018-02-15 15:38:39 --> Loader Class Initialized
INFO - 2018-02-15 15:38:39 --> Helper loaded: url_helper
INFO - 2018-02-15 15:38:39 --> Helper loaded: file_helper
INFO - 2018-02-15 15:38:39 --> Helper loaded: email_helper
INFO - 2018-02-15 15:38:39 --> Helper loaded: common_helper
INFO - 2018-02-15 15:38:39 --> Database Driver Class Initialized
DEBUG - 2018-02-15 15:38:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 15:38:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 15:38:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 15:38:39 --> Pagination Class Initialized
INFO - 2018-02-15 15:38:39 --> Helper loaded: form_helper
INFO - 2018-02-15 15:38:39 --> Form Validation Class Initialized
INFO - 2018-02-15 15:38:39 --> Model Class Initialized
INFO - 2018-02-15 15:38:39 --> Controller Class Initialized
INFO - 2018-02-15 15:38:39 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 15:38:39 --> Model Class Initialized
INFO - 2018-02-15 15:38:39 --> Model Class Initialized
INFO - 2018-02-15 15:38:39 --> Model Class Initialized
INFO - 2018-02-15 15:38:40 --> Config Class Initialized
INFO - 2018-02-15 15:38:40 --> Hooks Class Initialized
DEBUG - 2018-02-15 15:38:40 --> UTF-8 Support Enabled
INFO - 2018-02-15 15:38:40 --> Utf8 Class Initialized
INFO - 2018-02-15 15:38:40 --> URI Class Initialized
INFO - 2018-02-15 15:38:40 --> Router Class Initialized
INFO - 2018-02-15 15:38:40 --> Output Class Initialized
INFO - 2018-02-15 15:38:40 --> Security Class Initialized
DEBUG - 2018-02-15 15:38:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 15:38:40 --> Input Class Initialized
INFO - 2018-02-15 15:38:40 --> Language Class Initialized
INFO - 2018-02-15 15:38:40 --> Loader Class Initialized
INFO - 2018-02-15 15:38:40 --> Helper loaded: url_helper
INFO - 2018-02-15 15:38:40 --> Helper loaded: file_helper
INFO - 2018-02-15 15:38:40 --> Helper loaded: email_helper
INFO - 2018-02-15 15:38:40 --> Helper loaded: common_helper
INFO - 2018-02-15 15:38:40 --> Database Driver Class Initialized
DEBUG - 2018-02-15 15:38:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 15:38:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 15:38:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 15:38:40 --> Pagination Class Initialized
INFO - 2018-02-15 15:38:40 --> Helper loaded: form_helper
INFO - 2018-02-15 15:38:40 --> Form Validation Class Initialized
INFO - 2018-02-15 15:38:40 --> Model Class Initialized
INFO - 2018-02-15 15:38:40 --> Controller Class Initialized
INFO - 2018-02-15 15:38:40 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 15:38:40 --> Model Class Initialized
INFO - 2018-02-15 15:38:40 --> Model Class Initialized
INFO - 2018-02-15 15:38:40 --> Model Class Initialized
INFO - 2018-02-15 15:38:40 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-15 15:38:40 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-15 15:38:40 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-15 15:38:40 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-15 15:38:40 --> File loaded: /var/www/html/project/radio/application/views/tracks/index.php
INFO - 2018-02-15 15:38:40 --> Final output sent to browser
DEBUG - 2018-02-15 15:38:40 --> Total execution time: 0.0040
INFO - 2018-02-15 15:38:40 --> Config Class Initialized
INFO - 2018-02-15 15:38:40 --> Hooks Class Initialized
DEBUG - 2018-02-15 15:38:40 --> UTF-8 Support Enabled
INFO - 2018-02-15 15:38:40 --> Utf8 Class Initialized
INFO - 2018-02-15 15:38:40 --> URI Class Initialized
INFO - 2018-02-15 15:38:40 --> Router Class Initialized
INFO - 2018-02-15 15:38:40 --> Output Class Initialized
INFO - 2018-02-15 15:38:40 --> Security Class Initialized
DEBUG - 2018-02-15 15:38:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 15:38:40 --> Input Class Initialized
INFO - 2018-02-15 15:38:40 --> Language Class Initialized
INFO - 2018-02-15 15:38:40 --> Loader Class Initialized
INFO - 2018-02-15 15:38:40 --> Helper loaded: url_helper
INFO - 2018-02-15 15:38:40 --> Helper loaded: file_helper
INFO - 2018-02-15 15:38:40 --> Helper loaded: email_helper
INFO - 2018-02-15 15:38:40 --> Helper loaded: common_helper
INFO - 2018-02-15 15:38:40 --> Database Driver Class Initialized
DEBUG - 2018-02-15 15:38:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 15:38:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 15:38:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 15:38:40 --> Pagination Class Initialized
INFO - 2018-02-15 15:38:40 --> Helper loaded: form_helper
INFO - 2018-02-15 15:38:40 --> Form Validation Class Initialized
INFO - 2018-02-15 15:38:40 --> Model Class Initialized
INFO - 2018-02-15 15:38:40 --> Controller Class Initialized
INFO - 2018-02-15 15:38:40 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 15:38:40 --> Model Class Initialized
INFO - 2018-02-15 15:38:40 --> Model Class Initialized
INFO - 2018-02-15 15:38:40 --> Model Class Initialized
INFO - 2018-02-15 15:38:43 --> Config Class Initialized
INFO - 2018-02-15 15:38:43 --> Hooks Class Initialized
DEBUG - 2018-02-15 15:38:43 --> UTF-8 Support Enabled
INFO - 2018-02-15 15:38:43 --> Utf8 Class Initialized
INFO - 2018-02-15 15:38:43 --> URI Class Initialized
INFO - 2018-02-15 15:38:43 --> Router Class Initialized
INFO - 2018-02-15 15:38:43 --> Output Class Initialized
INFO - 2018-02-15 15:38:43 --> Security Class Initialized
DEBUG - 2018-02-15 15:38:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 15:38:43 --> Input Class Initialized
INFO - 2018-02-15 15:38:43 --> Language Class Initialized
INFO - 2018-02-15 15:38:43 --> Loader Class Initialized
INFO - 2018-02-15 15:38:43 --> Helper loaded: url_helper
INFO - 2018-02-15 15:38:43 --> Helper loaded: file_helper
INFO - 2018-02-15 15:38:43 --> Helper loaded: email_helper
INFO - 2018-02-15 15:38:43 --> Helper loaded: common_helper
INFO - 2018-02-15 15:38:43 --> Database Driver Class Initialized
DEBUG - 2018-02-15 15:38:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 15:38:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 15:38:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 15:38:43 --> Pagination Class Initialized
INFO - 2018-02-15 15:38:43 --> Helper loaded: form_helper
INFO - 2018-02-15 15:38:43 --> Form Validation Class Initialized
INFO - 2018-02-15 15:38:43 --> Model Class Initialized
INFO - 2018-02-15 15:38:43 --> Controller Class Initialized
INFO - 2018-02-15 15:38:43 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 15:38:43 --> Model Class Initialized
INFO - 2018-02-15 15:38:43 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-15 15:38:43 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-15 15:38:43 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-15 15:38:43 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-15 15:38:43 --> File loaded: /var/www/html/project/radio/application/views/category/index.php
INFO - 2018-02-15 15:38:43 --> Final output sent to browser
DEBUG - 2018-02-15 15:38:43 --> Total execution time: 0.0061
INFO - 2018-02-15 15:38:47 --> Config Class Initialized
INFO - 2018-02-15 15:38:47 --> Hooks Class Initialized
DEBUG - 2018-02-15 15:38:47 --> UTF-8 Support Enabled
INFO - 2018-02-15 15:38:47 --> Utf8 Class Initialized
INFO - 2018-02-15 15:38:47 --> URI Class Initialized
INFO - 2018-02-15 15:38:47 --> Router Class Initialized
INFO - 2018-02-15 15:38:47 --> Output Class Initialized
INFO - 2018-02-15 15:38:47 --> Security Class Initialized
DEBUG - 2018-02-15 15:38:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 15:38:47 --> Input Class Initialized
INFO - 2018-02-15 15:38:47 --> Language Class Initialized
INFO - 2018-02-15 15:38:47 --> Loader Class Initialized
INFO - 2018-02-15 15:38:47 --> Helper loaded: url_helper
INFO - 2018-02-15 15:38:47 --> Helper loaded: file_helper
INFO - 2018-02-15 15:38:47 --> Helper loaded: email_helper
INFO - 2018-02-15 15:38:47 --> Helper loaded: common_helper
INFO - 2018-02-15 15:38:47 --> Database Driver Class Initialized
DEBUG - 2018-02-15 15:38:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 15:38:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 15:38:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 15:38:47 --> Pagination Class Initialized
INFO - 2018-02-15 15:38:47 --> Helper loaded: form_helper
INFO - 2018-02-15 15:38:47 --> Form Validation Class Initialized
INFO - 2018-02-15 15:38:47 --> Model Class Initialized
INFO - 2018-02-15 15:38:47 --> Controller Class Initialized
INFO - 2018-02-15 15:38:47 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 15:38:47 --> Model Class Initialized
INFO - 2018-02-15 15:38:47 --> Model Class Initialized
INFO - 2018-02-15 15:38:47 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-15 15:38:47 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-15 15:38:47 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-15 15:38:47 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-15 15:38:47 --> File loaded: /var/www/html/project/radio/application/views/subcategory/index.php
INFO - 2018-02-15 15:38:47 --> Final output sent to browser
DEBUG - 2018-02-15 15:38:47 --> Total execution time: 0.0063
INFO - 2018-02-15 15:38:49 --> Config Class Initialized
INFO - 2018-02-15 15:38:49 --> Hooks Class Initialized
DEBUG - 2018-02-15 15:38:49 --> UTF-8 Support Enabled
INFO - 2018-02-15 15:38:49 --> Utf8 Class Initialized
INFO - 2018-02-15 15:38:49 --> URI Class Initialized
INFO - 2018-02-15 15:38:49 --> Router Class Initialized
INFO - 2018-02-15 15:38:49 --> Output Class Initialized
INFO - 2018-02-15 15:38:49 --> Security Class Initialized
DEBUG - 2018-02-15 15:38:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 15:38:49 --> Input Class Initialized
INFO - 2018-02-15 15:38:49 --> Language Class Initialized
INFO - 2018-02-15 15:38:49 --> Loader Class Initialized
INFO - 2018-02-15 15:38:49 --> Helper loaded: url_helper
INFO - 2018-02-15 15:38:49 --> Helper loaded: file_helper
INFO - 2018-02-15 15:38:49 --> Helper loaded: email_helper
INFO - 2018-02-15 15:38:49 --> Helper loaded: common_helper
INFO - 2018-02-15 15:38:49 --> Database Driver Class Initialized
DEBUG - 2018-02-15 15:38:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 15:38:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 15:38:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 15:38:49 --> Pagination Class Initialized
INFO - 2018-02-15 15:38:49 --> Helper loaded: form_helper
INFO - 2018-02-15 15:38:49 --> Form Validation Class Initialized
INFO - 2018-02-15 15:38:49 --> Model Class Initialized
INFO - 2018-02-15 15:38:49 --> Controller Class Initialized
INFO - 2018-02-15 15:38:49 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 15:38:49 --> Model Class Initialized
INFO - 2018-02-15 15:38:49 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-15 15:38:49 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-15 15:38:49 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-15 15:38:49 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-15 15:38:49 --> File loaded: /var/www/html/project/radio/application/views/category/index.php
INFO - 2018-02-15 15:38:49 --> Final output sent to browser
DEBUG - 2018-02-15 15:38:49 --> Total execution time: 0.0068
INFO - 2018-02-15 15:39:04 --> Config Class Initialized
INFO - 2018-02-15 15:39:04 --> Hooks Class Initialized
DEBUG - 2018-02-15 15:39:04 --> UTF-8 Support Enabled
INFO - 2018-02-15 15:39:04 --> Utf8 Class Initialized
INFO - 2018-02-15 15:39:04 --> URI Class Initialized
INFO - 2018-02-15 15:39:04 --> Router Class Initialized
INFO - 2018-02-15 15:39:04 --> Output Class Initialized
INFO - 2018-02-15 15:39:04 --> Security Class Initialized
DEBUG - 2018-02-15 15:39:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 15:39:04 --> Input Class Initialized
INFO - 2018-02-15 15:39:04 --> Language Class Initialized
INFO - 2018-02-15 15:39:04 --> Loader Class Initialized
INFO - 2018-02-15 15:39:04 --> Helper loaded: url_helper
INFO - 2018-02-15 15:39:04 --> Helper loaded: file_helper
INFO - 2018-02-15 15:39:04 --> Helper loaded: email_helper
INFO - 2018-02-15 15:39:04 --> Helper loaded: common_helper
INFO - 2018-02-15 15:39:04 --> Database Driver Class Initialized
DEBUG - 2018-02-15 15:39:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 15:39:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 15:39:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 15:39:04 --> Pagination Class Initialized
INFO - 2018-02-15 15:39:04 --> Helper loaded: form_helper
INFO - 2018-02-15 15:39:04 --> Form Validation Class Initialized
INFO - 2018-02-15 15:39:04 --> Model Class Initialized
INFO - 2018-02-15 15:39:04 --> Controller Class Initialized
INFO - 2018-02-15 15:39:04 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 15:39:04 --> Model Class Initialized
INFO - 2018-02-15 15:39:04 --> Model Class Initialized
INFO - 2018-02-15 15:39:04 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-15 15:39:04 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-15 15:39:04 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-15 15:39:04 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-15 15:39:04 --> File loaded: /var/www/html/project/radio/application/views/subcategory/index.php
INFO - 2018-02-15 15:39:04 --> Final output sent to browser
DEBUG - 2018-02-15 15:39:04 --> Total execution time: 0.0058
INFO - 2018-02-15 15:39:06 --> Config Class Initialized
INFO - 2018-02-15 15:39:06 --> Hooks Class Initialized
DEBUG - 2018-02-15 15:39:06 --> UTF-8 Support Enabled
INFO - 2018-02-15 15:39:06 --> Utf8 Class Initialized
INFO - 2018-02-15 15:39:06 --> URI Class Initialized
INFO - 2018-02-15 15:39:06 --> Router Class Initialized
INFO - 2018-02-15 15:39:06 --> Output Class Initialized
INFO - 2018-02-15 15:39:06 --> Security Class Initialized
DEBUG - 2018-02-15 15:39:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 15:39:06 --> Input Class Initialized
INFO - 2018-02-15 15:39:06 --> Language Class Initialized
INFO - 2018-02-15 15:39:06 --> Loader Class Initialized
INFO - 2018-02-15 15:39:06 --> Helper loaded: url_helper
INFO - 2018-02-15 15:39:06 --> Helper loaded: file_helper
INFO - 2018-02-15 15:39:06 --> Helper loaded: email_helper
INFO - 2018-02-15 15:39:06 --> Helper loaded: common_helper
INFO - 2018-02-15 15:39:06 --> Database Driver Class Initialized
DEBUG - 2018-02-15 15:39:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 15:39:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 15:39:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 15:39:06 --> Pagination Class Initialized
INFO - 2018-02-15 15:39:06 --> Helper loaded: form_helper
INFO - 2018-02-15 15:39:06 --> Form Validation Class Initialized
INFO - 2018-02-15 15:39:06 --> Model Class Initialized
INFO - 2018-02-15 15:39:06 --> Controller Class Initialized
INFO - 2018-02-15 15:39:06 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 15:39:06 --> Model Class Initialized
INFO - 2018-02-15 15:39:06 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-15 15:39:06 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-15 15:39:06 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-15 15:39:06 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-15 15:39:06 --> File loaded: /var/www/html/project/radio/application/views/category/index.php
INFO - 2018-02-15 15:39:06 --> Final output sent to browser
DEBUG - 2018-02-15 15:39:06 --> Total execution time: 0.0064
INFO - 2018-02-15 15:39:08 --> Config Class Initialized
INFO - 2018-02-15 15:39:08 --> Hooks Class Initialized
DEBUG - 2018-02-15 15:39:08 --> UTF-8 Support Enabled
INFO - 2018-02-15 15:39:08 --> Utf8 Class Initialized
INFO - 2018-02-15 15:39:08 --> URI Class Initialized
INFO - 2018-02-15 15:39:08 --> Router Class Initialized
INFO - 2018-02-15 15:39:08 --> Output Class Initialized
INFO - 2018-02-15 15:39:08 --> Security Class Initialized
DEBUG - 2018-02-15 15:39:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 15:39:08 --> Input Class Initialized
INFO - 2018-02-15 15:39:08 --> Language Class Initialized
INFO - 2018-02-15 15:39:08 --> Loader Class Initialized
INFO - 2018-02-15 15:39:08 --> Helper loaded: url_helper
INFO - 2018-02-15 15:39:08 --> Helper loaded: file_helper
INFO - 2018-02-15 15:39:08 --> Helper loaded: email_helper
INFO - 2018-02-15 15:39:08 --> Helper loaded: common_helper
INFO - 2018-02-15 15:39:08 --> Database Driver Class Initialized
DEBUG - 2018-02-15 15:39:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 15:39:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 15:39:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 15:39:08 --> Pagination Class Initialized
INFO - 2018-02-15 15:39:08 --> Helper loaded: form_helper
INFO - 2018-02-15 15:39:08 --> Form Validation Class Initialized
INFO - 2018-02-15 15:39:08 --> Model Class Initialized
INFO - 2018-02-15 15:39:08 --> Controller Class Initialized
INFO - 2018-02-15 15:39:08 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 15:39:08 --> Model Class Initialized
INFO - 2018-02-15 15:39:08 --> Model Class Initialized
INFO - 2018-02-15 15:39:08 --> Model Class Initialized
INFO - 2018-02-15 15:39:08 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-15 15:39:08 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-15 15:39:08 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-15 15:39:08 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-15 15:39:08 --> File loaded: /var/www/html/project/radio/application/views/tracks/index.php
INFO - 2018-02-15 15:39:08 --> Final output sent to browser
DEBUG - 2018-02-15 15:39:08 --> Total execution time: 0.0039
INFO - 2018-02-15 15:39:09 --> Config Class Initialized
INFO - 2018-02-15 15:39:09 --> Hooks Class Initialized
DEBUG - 2018-02-15 15:39:09 --> UTF-8 Support Enabled
INFO - 2018-02-15 15:39:09 --> Utf8 Class Initialized
INFO - 2018-02-15 15:39:09 --> URI Class Initialized
INFO - 2018-02-15 15:39:09 --> Router Class Initialized
INFO - 2018-02-15 15:39:09 --> Output Class Initialized
INFO - 2018-02-15 15:39:09 --> Security Class Initialized
DEBUG - 2018-02-15 15:39:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 15:39:09 --> Input Class Initialized
INFO - 2018-02-15 15:39:09 --> Language Class Initialized
INFO - 2018-02-15 15:39:09 --> Loader Class Initialized
INFO - 2018-02-15 15:39:09 --> Helper loaded: url_helper
INFO - 2018-02-15 15:39:09 --> Helper loaded: file_helper
INFO - 2018-02-15 15:39:09 --> Helper loaded: email_helper
INFO - 2018-02-15 15:39:09 --> Helper loaded: common_helper
INFO - 2018-02-15 15:39:09 --> Database Driver Class Initialized
DEBUG - 2018-02-15 15:39:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 15:39:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 15:39:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 15:39:09 --> Pagination Class Initialized
INFO - 2018-02-15 15:39:09 --> Helper loaded: form_helper
INFO - 2018-02-15 15:39:09 --> Form Validation Class Initialized
INFO - 2018-02-15 15:39:09 --> Model Class Initialized
INFO - 2018-02-15 15:39:09 --> Controller Class Initialized
INFO - 2018-02-15 15:39:09 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 15:39:09 --> Model Class Initialized
INFO - 2018-02-15 15:39:09 --> Model Class Initialized
INFO - 2018-02-15 15:39:09 --> Model Class Initialized
INFO - 2018-02-15 15:42:02 --> Config Class Initialized
INFO - 2018-02-15 15:42:02 --> Hooks Class Initialized
DEBUG - 2018-02-15 15:42:02 --> UTF-8 Support Enabled
INFO - 2018-02-15 15:42:02 --> Utf8 Class Initialized
INFO - 2018-02-15 15:42:02 --> URI Class Initialized
INFO - 2018-02-15 15:42:02 --> Router Class Initialized
INFO - 2018-02-15 15:42:02 --> Output Class Initialized
INFO - 2018-02-15 15:42:02 --> Security Class Initialized
DEBUG - 2018-02-15 15:42:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 15:42:02 --> Input Class Initialized
INFO - 2018-02-15 15:42:02 --> Language Class Initialized
INFO - 2018-02-15 15:42:02 --> Loader Class Initialized
INFO - 2018-02-15 15:42:02 --> Helper loaded: url_helper
INFO - 2018-02-15 15:42:02 --> Helper loaded: file_helper
INFO - 2018-02-15 15:42:02 --> Helper loaded: email_helper
INFO - 2018-02-15 15:42:02 --> Helper loaded: common_helper
INFO - 2018-02-15 15:42:02 --> Database Driver Class Initialized
DEBUG - 2018-02-15 15:42:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 15:42:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 15:42:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 15:42:02 --> Pagination Class Initialized
INFO - 2018-02-15 15:42:02 --> Helper loaded: form_helper
INFO - 2018-02-15 15:42:02 --> Form Validation Class Initialized
INFO - 2018-02-15 15:42:02 --> Model Class Initialized
INFO - 2018-02-15 15:42:02 --> Controller Class Initialized
INFO - 2018-02-15 15:42:02 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 15:42:02 --> Model Class Initialized
INFO - 2018-02-15 15:42:02 --> Model Class Initialized
INFO - 2018-02-15 15:42:02 --> Model Class Initialized
INFO - 2018-02-15 15:42:02 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-15 15:42:02 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-15 15:42:02 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-15 15:42:02 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-15 15:42:02 --> File loaded: /var/www/html/project/radio/application/views/tracks/index.php
INFO - 2018-02-15 15:42:02 --> Final output sent to browser
DEBUG - 2018-02-15 15:42:02 --> Total execution time: 0.0054
INFO - 2018-02-15 15:42:03 --> Config Class Initialized
INFO - 2018-02-15 15:42:03 --> Hooks Class Initialized
DEBUG - 2018-02-15 15:42:03 --> UTF-8 Support Enabled
INFO - 2018-02-15 15:42:03 --> Utf8 Class Initialized
INFO - 2018-02-15 15:42:03 --> URI Class Initialized
INFO - 2018-02-15 15:42:03 --> Router Class Initialized
INFO - 2018-02-15 15:42:03 --> Output Class Initialized
INFO - 2018-02-15 15:42:03 --> Security Class Initialized
DEBUG - 2018-02-15 15:42:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 15:42:03 --> Input Class Initialized
INFO - 2018-02-15 15:42:03 --> Language Class Initialized
INFO - 2018-02-15 15:42:03 --> Loader Class Initialized
INFO - 2018-02-15 15:42:03 --> Helper loaded: url_helper
INFO - 2018-02-15 15:42:03 --> Helper loaded: file_helper
INFO - 2018-02-15 15:42:03 --> Helper loaded: email_helper
INFO - 2018-02-15 15:42:03 --> Helper loaded: common_helper
INFO - 2018-02-15 15:42:03 --> Database Driver Class Initialized
DEBUG - 2018-02-15 15:42:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 15:42:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 15:42:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 15:42:03 --> Pagination Class Initialized
INFO - 2018-02-15 15:42:03 --> Helper loaded: form_helper
INFO - 2018-02-15 15:42:03 --> Form Validation Class Initialized
INFO - 2018-02-15 15:42:03 --> Model Class Initialized
INFO - 2018-02-15 15:42:03 --> Controller Class Initialized
INFO - 2018-02-15 15:42:03 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 15:42:03 --> Model Class Initialized
INFO - 2018-02-15 15:42:03 --> Model Class Initialized
INFO - 2018-02-15 15:42:03 --> Model Class Initialized
INFO - 2018-02-15 15:47:40 --> Config Class Initialized
INFO - 2018-02-15 15:47:40 --> Hooks Class Initialized
DEBUG - 2018-02-15 15:47:40 --> UTF-8 Support Enabled
INFO - 2018-02-15 15:47:40 --> Utf8 Class Initialized
INFO - 2018-02-15 15:47:40 --> URI Class Initialized
INFO - 2018-02-15 15:47:40 --> Router Class Initialized
INFO - 2018-02-15 15:47:40 --> Output Class Initialized
INFO - 2018-02-15 15:47:40 --> Security Class Initialized
DEBUG - 2018-02-15 15:47:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 15:47:40 --> Input Class Initialized
INFO - 2018-02-15 15:47:40 --> Language Class Initialized
INFO - 2018-02-15 15:47:40 --> Loader Class Initialized
INFO - 2018-02-15 15:47:40 --> Helper loaded: url_helper
INFO - 2018-02-15 15:47:40 --> Helper loaded: file_helper
INFO - 2018-02-15 15:47:40 --> Helper loaded: email_helper
INFO - 2018-02-15 15:47:40 --> Helper loaded: common_helper
INFO - 2018-02-15 15:47:40 --> Database Driver Class Initialized
DEBUG - 2018-02-15 15:47:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 15:47:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 15:47:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 15:47:40 --> Pagination Class Initialized
INFO - 2018-02-15 15:47:40 --> Helper loaded: form_helper
INFO - 2018-02-15 15:47:40 --> Form Validation Class Initialized
INFO - 2018-02-15 15:47:40 --> Model Class Initialized
INFO - 2018-02-15 15:47:40 --> Controller Class Initialized
INFO - 2018-02-15 15:47:40 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 15:47:40 --> Model Class Initialized
INFO - 2018-02-15 15:47:40 --> Model Class Initialized
INFO - 2018-02-15 15:47:40 --> Model Class Initialized
INFO - 2018-02-15 15:47:40 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-15 15:47:40 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-15 15:47:40 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-15 15:47:40 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-15 15:47:40 --> File loaded: /var/www/html/project/radio/application/views/tracks/index.php
INFO - 2018-02-15 15:47:40 --> Final output sent to browser
DEBUG - 2018-02-15 15:47:40 --> Total execution time: 0.0062
INFO - 2018-02-15 15:47:41 --> Config Class Initialized
INFO - 2018-02-15 15:47:41 --> Hooks Class Initialized
DEBUG - 2018-02-15 15:47:41 --> UTF-8 Support Enabled
INFO - 2018-02-15 15:47:41 --> Utf8 Class Initialized
INFO - 2018-02-15 15:47:41 --> URI Class Initialized
INFO - 2018-02-15 15:47:41 --> Router Class Initialized
INFO - 2018-02-15 15:47:41 --> Output Class Initialized
INFO - 2018-02-15 15:47:41 --> Security Class Initialized
DEBUG - 2018-02-15 15:47:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 15:47:41 --> Input Class Initialized
INFO - 2018-02-15 15:47:41 --> Language Class Initialized
INFO - 2018-02-15 15:47:41 --> Loader Class Initialized
INFO - 2018-02-15 15:47:41 --> Helper loaded: url_helper
INFO - 2018-02-15 15:47:41 --> Helper loaded: file_helper
INFO - 2018-02-15 15:47:41 --> Helper loaded: email_helper
INFO - 2018-02-15 15:47:41 --> Helper loaded: common_helper
INFO - 2018-02-15 15:47:41 --> Database Driver Class Initialized
DEBUG - 2018-02-15 15:47:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 15:47:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 15:47:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 15:47:41 --> Pagination Class Initialized
INFO - 2018-02-15 15:47:41 --> Helper loaded: form_helper
INFO - 2018-02-15 15:47:41 --> Form Validation Class Initialized
INFO - 2018-02-15 15:47:41 --> Model Class Initialized
INFO - 2018-02-15 15:47:41 --> Controller Class Initialized
INFO - 2018-02-15 15:47:41 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 15:47:41 --> Model Class Initialized
INFO - 2018-02-15 15:47:41 --> Model Class Initialized
INFO - 2018-02-15 15:47:41 --> Model Class Initialized
INFO - 2018-02-15 15:48:35 --> Config Class Initialized
INFO - 2018-02-15 15:48:35 --> Hooks Class Initialized
DEBUG - 2018-02-15 15:48:35 --> UTF-8 Support Enabled
INFO - 2018-02-15 15:48:35 --> Utf8 Class Initialized
INFO - 2018-02-15 15:48:35 --> URI Class Initialized
INFO - 2018-02-15 15:48:35 --> Router Class Initialized
INFO - 2018-02-15 15:48:35 --> Output Class Initialized
INFO - 2018-02-15 15:48:35 --> Security Class Initialized
DEBUG - 2018-02-15 15:48:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 15:48:35 --> Input Class Initialized
INFO - 2018-02-15 15:48:35 --> Language Class Initialized
INFO - 2018-02-15 15:48:35 --> Loader Class Initialized
INFO - 2018-02-15 15:48:35 --> Helper loaded: url_helper
INFO - 2018-02-15 15:48:35 --> Helper loaded: file_helper
INFO - 2018-02-15 15:48:35 --> Helper loaded: email_helper
INFO - 2018-02-15 15:48:35 --> Helper loaded: common_helper
INFO - 2018-02-15 15:48:35 --> Database Driver Class Initialized
DEBUG - 2018-02-15 15:48:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 15:48:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 15:48:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 15:48:35 --> Pagination Class Initialized
INFO - 2018-02-15 15:48:35 --> Helper loaded: form_helper
INFO - 2018-02-15 15:48:35 --> Form Validation Class Initialized
INFO - 2018-02-15 15:48:35 --> Model Class Initialized
INFO - 2018-02-15 15:48:35 --> Controller Class Initialized
INFO - 2018-02-15 15:48:35 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 15:48:35 --> Model Class Initialized
INFO - 2018-02-15 15:48:35 --> Model Class Initialized
INFO - 2018-02-15 15:48:35 --> Model Class Initialized
INFO - 2018-02-15 15:48:35 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-15 15:48:35 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-15 15:48:35 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-15 15:48:35 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-15 15:48:35 --> File loaded: /var/www/html/project/radio/application/views/tracks/index.php
INFO - 2018-02-15 15:48:35 --> Final output sent to browser
DEBUG - 2018-02-15 15:48:35 --> Total execution time: 0.0059
INFO - 2018-02-15 15:48:36 --> Config Class Initialized
INFO - 2018-02-15 15:48:36 --> Hooks Class Initialized
DEBUG - 2018-02-15 15:48:36 --> UTF-8 Support Enabled
INFO - 2018-02-15 15:48:36 --> Utf8 Class Initialized
INFO - 2018-02-15 15:48:36 --> URI Class Initialized
INFO - 2018-02-15 15:48:36 --> Router Class Initialized
INFO - 2018-02-15 15:48:36 --> Output Class Initialized
INFO - 2018-02-15 15:48:36 --> Security Class Initialized
DEBUG - 2018-02-15 15:48:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 15:48:36 --> Input Class Initialized
INFO - 2018-02-15 15:48:36 --> Language Class Initialized
INFO - 2018-02-15 15:48:36 --> Loader Class Initialized
INFO - 2018-02-15 15:48:36 --> Helper loaded: url_helper
INFO - 2018-02-15 15:48:36 --> Helper loaded: file_helper
INFO - 2018-02-15 15:48:36 --> Helper loaded: email_helper
INFO - 2018-02-15 15:48:36 --> Helper loaded: common_helper
INFO - 2018-02-15 15:48:36 --> Database Driver Class Initialized
DEBUG - 2018-02-15 15:48:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 15:48:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 15:48:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 15:48:36 --> Pagination Class Initialized
INFO - 2018-02-15 15:48:36 --> Helper loaded: form_helper
INFO - 2018-02-15 15:48:36 --> Form Validation Class Initialized
INFO - 2018-02-15 15:48:36 --> Model Class Initialized
INFO - 2018-02-15 15:48:36 --> Controller Class Initialized
INFO - 2018-02-15 15:48:36 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 15:48:36 --> Model Class Initialized
INFO - 2018-02-15 15:48:36 --> Model Class Initialized
INFO - 2018-02-15 15:48:36 --> Model Class Initialized
INFO - 2018-02-15 15:48:39 --> Config Class Initialized
INFO - 2018-02-15 15:48:39 --> Hooks Class Initialized
DEBUG - 2018-02-15 15:48:39 --> UTF-8 Support Enabled
INFO - 2018-02-15 15:48:39 --> Utf8 Class Initialized
INFO - 2018-02-15 15:48:39 --> URI Class Initialized
INFO - 2018-02-15 15:48:39 --> Router Class Initialized
INFO - 2018-02-15 15:48:39 --> Output Class Initialized
INFO - 2018-02-15 15:48:39 --> Security Class Initialized
DEBUG - 2018-02-15 15:48:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 15:48:39 --> Input Class Initialized
INFO - 2018-02-15 15:48:39 --> Language Class Initialized
INFO - 2018-02-15 15:48:39 --> Loader Class Initialized
INFO - 2018-02-15 15:48:39 --> Helper loaded: url_helper
INFO - 2018-02-15 15:48:39 --> Helper loaded: file_helper
INFO - 2018-02-15 15:48:39 --> Helper loaded: email_helper
INFO - 2018-02-15 15:48:39 --> Helper loaded: common_helper
INFO - 2018-02-15 15:48:39 --> Database Driver Class Initialized
DEBUG - 2018-02-15 15:48:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 15:48:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 15:48:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 15:48:39 --> Pagination Class Initialized
INFO - 2018-02-15 15:48:39 --> Helper loaded: form_helper
INFO - 2018-02-15 15:48:39 --> Form Validation Class Initialized
INFO - 2018-02-15 15:48:39 --> Model Class Initialized
INFO - 2018-02-15 15:48:39 --> Controller Class Initialized
INFO - 2018-02-15 15:48:39 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 15:48:39 --> Model Class Initialized
INFO - 2018-02-15 15:48:39 --> Model Class Initialized
INFO - 2018-02-15 15:48:39 --> Model Class Initialized
INFO - 2018-02-15 15:48:39 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-15 15:48:39 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-15 15:48:39 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-15 15:48:39 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-15 15:48:39 --> File loaded: /var/www/html/project/radio/application/views/tracks/index.php
INFO - 2018-02-15 15:48:39 --> Final output sent to browser
DEBUG - 2018-02-15 15:48:39 --> Total execution time: 0.0049
INFO - 2018-02-15 15:48:39 --> Config Class Initialized
INFO - 2018-02-15 15:48:39 --> Hooks Class Initialized
DEBUG - 2018-02-15 15:48:39 --> UTF-8 Support Enabled
INFO - 2018-02-15 15:48:39 --> Utf8 Class Initialized
INFO - 2018-02-15 15:48:39 --> URI Class Initialized
INFO - 2018-02-15 15:48:39 --> Router Class Initialized
INFO - 2018-02-15 15:48:39 --> Output Class Initialized
INFO - 2018-02-15 15:48:39 --> Security Class Initialized
DEBUG - 2018-02-15 15:48:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 15:48:39 --> Input Class Initialized
INFO - 2018-02-15 15:48:39 --> Language Class Initialized
INFO - 2018-02-15 15:48:39 --> Loader Class Initialized
INFO - 2018-02-15 15:48:39 --> Helper loaded: url_helper
INFO - 2018-02-15 15:48:39 --> Helper loaded: file_helper
INFO - 2018-02-15 15:48:39 --> Helper loaded: email_helper
INFO - 2018-02-15 15:48:39 --> Helper loaded: common_helper
INFO - 2018-02-15 15:48:39 --> Database Driver Class Initialized
DEBUG - 2018-02-15 15:48:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 15:48:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 15:48:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 15:48:39 --> Pagination Class Initialized
INFO - 2018-02-15 15:48:39 --> Helper loaded: form_helper
INFO - 2018-02-15 15:48:39 --> Form Validation Class Initialized
INFO - 2018-02-15 15:48:39 --> Model Class Initialized
INFO - 2018-02-15 15:48:39 --> Controller Class Initialized
INFO - 2018-02-15 15:48:39 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 15:48:39 --> Model Class Initialized
INFO - 2018-02-15 15:48:39 --> Model Class Initialized
INFO - 2018-02-15 15:48:39 --> Model Class Initialized
INFO - 2018-02-15 15:48:40 --> Config Class Initialized
INFO - 2018-02-15 15:48:40 --> Hooks Class Initialized
DEBUG - 2018-02-15 15:48:40 --> UTF-8 Support Enabled
INFO - 2018-02-15 15:48:40 --> Utf8 Class Initialized
INFO - 2018-02-15 15:48:40 --> URI Class Initialized
INFO - 2018-02-15 15:48:40 --> Router Class Initialized
INFO - 2018-02-15 15:48:40 --> Output Class Initialized
INFO - 2018-02-15 15:48:40 --> Security Class Initialized
DEBUG - 2018-02-15 15:48:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 15:48:40 --> Input Class Initialized
INFO - 2018-02-15 15:48:40 --> Language Class Initialized
INFO - 2018-02-15 15:48:40 --> Loader Class Initialized
INFO - 2018-02-15 15:48:40 --> Helper loaded: url_helper
INFO - 2018-02-15 15:48:40 --> Helper loaded: file_helper
INFO - 2018-02-15 15:48:40 --> Helper loaded: email_helper
INFO - 2018-02-15 15:48:40 --> Helper loaded: common_helper
INFO - 2018-02-15 15:48:40 --> Database Driver Class Initialized
DEBUG - 2018-02-15 15:48:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 15:48:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 15:48:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 15:48:40 --> Pagination Class Initialized
INFO - 2018-02-15 15:48:40 --> Helper loaded: form_helper
INFO - 2018-02-15 15:48:40 --> Form Validation Class Initialized
INFO - 2018-02-15 15:48:40 --> Model Class Initialized
INFO - 2018-02-15 15:48:40 --> Controller Class Initialized
INFO - 2018-02-15 15:48:40 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 15:48:40 --> Model Class Initialized
INFO - 2018-02-15 15:48:40 --> Model Class Initialized
INFO - 2018-02-15 15:48:40 --> Model Class Initialized
INFO - 2018-02-15 15:48:40 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-15 15:48:40 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-15 15:48:40 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-15 15:48:40 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-15 15:48:40 --> File loaded: /var/www/html/project/radio/application/views/tracks/index.php
INFO - 2018-02-15 15:48:40 --> Final output sent to browser
DEBUG - 2018-02-15 15:48:40 --> Total execution time: 0.0064
INFO - 2018-02-15 15:48:40 --> Config Class Initialized
INFO - 2018-02-15 15:48:40 --> Hooks Class Initialized
DEBUG - 2018-02-15 15:48:40 --> UTF-8 Support Enabled
INFO - 2018-02-15 15:48:40 --> Utf8 Class Initialized
INFO - 2018-02-15 15:48:40 --> URI Class Initialized
INFO - 2018-02-15 15:48:40 --> Router Class Initialized
INFO - 2018-02-15 15:48:40 --> Output Class Initialized
INFO - 2018-02-15 15:48:40 --> Security Class Initialized
DEBUG - 2018-02-15 15:48:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 15:48:40 --> Input Class Initialized
INFO - 2018-02-15 15:48:40 --> Language Class Initialized
INFO - 2018-02-15 15:48:40 --> Loader Class Initialized
INFO - 2018-02-15 15:48:40 --> Helper loaded: url_helper
INFO - 2018-02-15 15:48:40 --> Helper loaded: file_helper
INFO - 2018-02-15 15:48:40 --> Helper loaded: email_helper
INFO - 2018-02-15 15:48:40 --> Helper loaded: common_helper
INFO - 2018-02-15 15:48:40 --> Database Driver Class Initialized
DEBUG - 2018-02-15 15:48:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 15:48:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 15:48:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 15:48:40 --> Pagination Class Initialized
INFO - 2018-02-15 15:48:40 --> Helper loaded: form_helper
INFO - 2018-02-15 15:48:40 --> Form Validation Class Initialized
INFO - 2018-02-15 15:48:40 --> Model Class Initialized
INFO - 2018-02-15 15:48:40 --> Controller Class Initialized
INFO - 2018-02-15 15:48:40 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 15:48:40 --> Model Class Initialized
INFO - 2018-02-15 15:48:40 --> Model Class Initialized
INFO - 2018-02-15 15:48:40 --> Model Class Initialized
INFO - 2018-02-15 15:48:41 --> Config Class Initialized
INFO - 2018-02-15 15:48:41 --> Hooks Class Initialized
DEBUG - 2018-02-15 15:48:41 --> UTF-8 Support Enabled
INFO - 2018-02-15 15:48:41 --> Utf8 Class Initialized
INFO - 2018-02-15 15:48:41 --> URI Class Initialized
INFO - 2018-02-15 15:48:41 --> Router Class Initialized
INFO - 2018-02-15 15:48:41 --> Output Class Initialized
INFO - 2018-02-15 15:48:41 --> Security Class Initialized
DEBUG - 2018-02-15 15:48:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 15:48:41 --> Input Class Initialized
INFO - 2018-02-15 15:48:41 --> Language Class Initialized
INFO - 2018-02-15 15:48:41 --> Loader Class Initialized
INFO - 2018-02-15 15:48:41 --> Helper loaded: url_helper
INFO - 2018-02-15 15:48:41 --> Helper loaded: file_helper
INFO - 2018-02-15 15:48:41 --> Helper loaded: email_helper
INFO - 2018-02-15 15:48:41 --> Helper loaded: common_helper
INFO - 2018-02-15 15:48:41 --> Database Driver Class Initialized
DEBUG - 2018-02-15 15:48:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 15:48:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 15:48:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 15:48:41 --> Pagination Class Initialized
INFO - 2018-02-15 15:48:41 --> Helper loaded: form_helper
INFO - 2018-02-15 15:48:41 --> Form Validation Class Initialized
INFO - 2018-02-15 15:48:41 --> Model Class Initialized
INFO - 2018-02-15 15:48:41 --> Controller Class Initialized
INFO - 2018-02-15 15:48:41 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 15:48:41 --> Model Class Initialized
INFO - 2018-02-15 15:48:41 --> Model Class Initialized
INFO - 2018-02-15 15:48:41 --> Model Class Initialized
INFO - 2018-02-15 15:48:41 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-15 15:48:41 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-15 15:48:41 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-15 15:48:41 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-15 15:48:41 --> File loaded: /var/www/html/project/radio/application/views/tracks/index.php
INFO - 2018-02-15 15:48:41 --> Final output sent to browser
DEBUG - 2018-02-15 15:48:41 --> Total execution time: 0.0053
INFO - 2018-02-15 15:48:41 --> Config Class Initialized
INFO - 2018-02-15 15:48:41 --> Hooks Class Initialized
DEBUG - 2018-02-15 15:48:41 --> UTF-8 Support Enabled
INFO - 2018-02-15 15:48:41 --> Utf8 Class Initialized
INFO - 2018-02-15 15:48:41 --> URI Class Initialized
INFO - 2018-02-15 15:48:41 --> Router Class Initialized
INFO - 2018-02-15 15:48:41 --> Output Class Initialized
INFO - 2018-02-15 15:48:41 --> Security Class Initialized
DEBUG - 2018-02-15 15:48:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 15:48:41 --> Input Class Initialized
INFO - 2018-02-15 15:48:41 --> Language Class Initialized
INFO - 2018-02-15 15:48:41 --> Loader Class Initialized
INFO - 2018-02-15 15:48:41 --> Helper loaded: url_helper
INFO - 2018-02-15 15:48:41 --> Helper loaded: file_helper
INFO - 2018-02-15 15:48:41 --> Helper loaded: email_helper
INFO - 2018-02-15 15:48:41 --> Helper loaded: common_helper
INFO - 2018-02-15 15:48:41 --> Database Driver Class Initialized
DEBUG - 2018-02-15 15:48:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 15:48:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 15:48:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 15:48:41 --> Pagination Class Initialized
INFO - 2018-02-15 15:48:41 --> Helper loaded: form_helper
INFO - 2018-02-15 15:48:41 --> Form Validation Class Initialized
INFO - 2018-02-15 15:48:41 --> Model Class Initialized
INFO - 2018-02-15 15:48:41 --> Controller Class Initialized
INFO - 2018-02-15 15:48:41 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 15:48:41 --> Model Class Initialized
INFO - 2018-02-15 15:48:41 --> Model Class Initialized
INFO - 2018-02-15 15:48:41 --> Model Class Initialized
INFO - 2018-02-15 15:48:42 --> Config Class Initialized
INFO - 2018-02-15 15:48:42 --> Hooks Class Initialized
DEBUG - 2018-02-15 15:48:42 --> UTF-8 Support Enabled
INFO - 2018-02-15 15:48:42 --> Utf8 Class Initialized
INFO - 2018-02-15 15:48:42 --> URI Class Initialized
INFO - 2018-02-15 15:48:42 --> Router Class Initialized
INFO - 2018-02-15 15:48:42 --> Output Class Initialized
INFO - 2018-02-15 15:48:42 --> Security Class Initialized
DEBUG - 2018-02-15 15:48:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 15:48:42 --> Input Class Initialized
INFO - 2018-02-15 15:48:42 --> Language Class Initialized
INFO - 2018-02-15 15:48:42 --> Loader Class Initialized
INFO - 2018-02-15 15:48:42 --> Helper loaded: url_helper
INFO - 2018-02-15 15:48:42 --> Helper loaded: file_helper
INFO - 2018-02-15 15:48:42 --> Helper loaded: email_helper
INFO - 2018-02-15 15:48:42 --> Helper loaded: common_helper
INFO - 2018-02-15 15:48:42 --> Database Driver Class Initialized
DEBUG - 2018-02-15 15:48:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 15:48:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 15:48:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 15:48:42 --> Pagination Class Initialized
INFO - 2018-02-15 15:48:42 --> Helper loaded: form_helper
INFO - 2018-02-15 15:48:42 --> Form Validation Class Initialized
INFO - 2018-02-15 15:48:42 --> Model Class Initialized
INFO - 2018-02-15 15:48:42 --> Controller Class Initialized
INFO - 2018-02-15 15:48:42 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 15:48:42 --> Model Class Initialized
INFO - 2018-02-15 15:48:42 --> Model Class Initialized
INFO - 2018-02-15 15:48:42 --> Model Class Initialized
INFO - 2018-02-15 15:48:42 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-15 15:48:42 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-15 15:48:42 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-15 15:48:42 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-15 15:48:42 --> File loaded: /var/www/html/project/radio/application/views/tracks/index.php
INFO - 2018-02-15 15:48:42 --> Final output sent to browser
DEBUG - 2018-02-15 15:48:42 --> Total execution time: 0.0043
INFO - 2018-02-15 15:48:42 --> Config Class Initialized
INFO - 2018-02-15 15:48:42 --> Hooks Class Initialized
DEBUG - 2018-02-15 15:48:42 --> UTF-8 Support Enabled
INFO - 2018-02-15 15:48:42 --> Utf8 Class Initialized
INFO - 2018-02-15 15:48:42 --> URI Class Initialized
INFO - 2018-02-15 15:48:42 --> Router Class Initialized
INFO - 2018-02-15 15:48:42 --> Output Class Initialized
INFO - 2018-02-15 15:48:42 --> Security Class Initialized
DEBUG - 2018-02-15 15:48:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 15:48:42 --> Input Class Initialized
INFO - 2018-02-15 15:48:42 --> Language Class Initialized
INFO - 2018-02-15 15:48:42 --> Loader Class Initialized
INFO - 2018-02-15 15:48:42 --> Helper loaded: url_helper
INFO - 2018-02-15 15:48:42 --> Helper loaded: file_helper
INFO - 2018-02-15 15:48:42 --> Helper loaded: email_helper
INFO - 2018-02-15 15:48:42 --> Helper loaded: common_helper
INFO - 2018-02-15 15:48:42 --> Database Driver Class Initialized
DEBUG - 2018-02-15 15:48:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 15:48:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 15:48:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 15:48:42 --> Pagination Class Initialized
INFO - 2018-02-15 15:48:42 --> Helper loaded: form_helper
INFO - 2018-02-15 15:48:42 --> Form Validation Class Initialized
INFO - 2018-02-15 15:48:42 --> Model Class Initialized
INFO - 2018-02-15 15:48:42 --> Controller Class Initialized
INFO - 2018-02-15 15:48:42 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 15:48:42 --> Model Class Initialized
INFO - 2018-02-15 15:48:42 --> Model Class Initialized
INFO - 2018-02-15 15:48:42 --> Model Class Initialized
INFO - 2018-02-15 15:48:42 --> Config Class Initialized
INFO - 2018-02-15 15:48:42 --> Hooks Class Initialized
DEBUG - 2018-02-15 15:48:42 --> UTF-8 Support Enabled
INFO - 2018-02-15 15:48:42 --> Utf8 Class Initialized
INFO - 2018-02-15 15:48:42 --> URI Class Initialized
INFO - 2018-02-15 15:48:42 --> Router Class Initialized
INFO - 2018-02-15 15:48:42 --> Output Class Initialized
INFO - 2018-02-15 15:48:42 --> Security Class Initialized
DEBUG - 2018-02-15 15:48:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 15:48:42 --> Input Class Initialized
INFO - 2018-02-15 15:48:42 --> Language Class Initialized
INFO - 2018-02-15 15:48:42 --> Loader Class Initialized
INFO - 2018-02-15 15:48:42 --> Helper loaded: url_helper
INFO - 2018-02-15 15:48:42 --> Helper loaded: file_helper
INFO - 2018-02-15 15:48:42 --> Helper loaded: email_helper
INFO - 2018-02-15 15:48:42 --> Helper loaded: common_helper
INFO - 2018-02-15 15:48:42 --> Database Driver Class Initialized
DEBUG - 2018-02-15 15:48:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 15:48:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 15:48:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 15:48:42 --> Pagination Class Initialized
INFO - 2018-02-15 15:48:42 --> Helper loaded: form_helper
INFO - 2018-02-15 15:48:42 --> Form Validation Class Initialized
INFO - 2018-02-15 15:48:42 --> Model Class Initialized
INFO - 2018-02-15 15:48:42 --> Controller Class Initialized
INFO - 2018-02-15 15:48:42 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 15:48:42 --> Model Class Initialized
INFO - 2018-02-15 15:48:42 --> Model Class Initialized
INFO - 2018-02-15 15:48:42 --> Model Class Initialized
INFO - 2018-02-15 15:48:42 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-15 15:48:42 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-15 15:48:42 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-15 15:48:42 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-15 15:48:42 --> File loaded: /var/www/html/project/radio/application/views/tracks/index.php
INFO - 2018-02-15 15:48:42 --> Final output sent to browser
DEBUG - 2018-02-15 15:48:42 --> Total execution time: 0.0066
INFO - 2018-02-15 15:48:43 --> Config Class Initialized
INFO - 2018-02-15 15:48:43 --> Hooks Class Initialized
DEBUG - 2018-02-15 15:48:43 --> UTF-8 Support Enabled
INFO - 2018-02-15 15:48:43 --> Utf8 Class Initialized
INFO - 2018-02-15 15:48:43 --> URI Class Initialized
INFO - 2018-02-15 15:48:43 --> Router Class Initialized
INFO - 2018-02-15 15:48:43 --> Output Class Initialized
INFO - 2018-02-15 15:48:43 --> Security Class Initialized
DEBUG - 2018-02-15 15:48:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 15:48:43 --> Input Class Initialized
INFO - 2018-02-15 15:48:43 --> Language Class Initialized
INFO - 2018-02-15 15:48:43 --> Loader Class Initialized
INFO - 2018-02-15 15:48:43 --> Helper loaded: url_helper
INFO - 2018-02-15 15:48:43 --> Helper loaded: file_helper
INFO - 2018-02-15 15:48:43 --> Helper loaded: email_helper
INFO - 2018-02-15 15:48:43 --> Helper loaded: common_helper
INFO - 2018-02-15 15:48:43 --> Database Driver Class Initialized
DEBUG - 2018-02-15 15:48:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 15:48:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 15:48:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 15:48:43 --> Pagination Class Initialized
INFO - 2018-02-15 15:48:43 --> Helper loaded: form_helper
INFO - 2018-02-15 15:48:43 --> Form Validation Class Initialized
INFO - 2018-02-15 15:48:43 --> Model Class Initialized
INFO - 2018-02-15 15:48:43 --> Controller Class Initialized
INFO - 2018-02-15 15:48:43 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 15:48:43 --> Model Class Initialized
INFO - 2018-02-15 15:48:43 --> Model Class Initialized
INFO - 2018-02-15 15:48:43 --> Model Class Initialized
INFO - 2018-02-15 15:48:48 --> Config Class Initialized
INFO - 2018-02-15 15:48:48 --> Hooks Class Initialized
DEBUG - 2018-02-15 15:48:48 --> UTF-8 Support Enabled
INFO - 2018-02-15 15:48:48 --> Utf8 Class Initialized
INFO - 2018-02-15 15:48:48 --> URI Class Initialized
INFO - 2018-02-15 15:48:48 --> Router Class Initialized
INFO - 2018-02-15 15:48:48 --> Output Class Initialized
INFO - 2018-02-15 15:48:48 --> Security Class Initialized
DEBUG - 2018-02-15 15:48:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 15:48:48 --> Input Class Initialized
INFO - 2018-02-15 15:48:48 --> Language Class Initialized
INFO - 2018-02-15 15:48:48 --> Loader Class Initialized
INFO - 2018-02-15 15:48:48 --> Helper loaded: url_helper
INFO - 2018-02-15 15:48:48 --> Helper loaded: file_helper
INFO - 2018-02-15 15:48:48 --> Helper loaded: email_helper
INFO - 2018-02-15 15:48:48 --> Helper loaded: common_helper
INFO - 2018-02-15 15:48:48 --> Database Driver Class Initialized
DEBUG - 2018-02-15 15:48:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 15:48:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 15:48:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 15:48:48 --> Pagination Class Initialized
INFO - 2018-02-15 15:48:48 --> Helper loaded: form_helper
INFO - 2018-02-15 15:48:48 --> Form Validation Class Initialized
INFO - 2018-02-15 15:48:48 --> Model Class Initialized
INFO - 2018-02-15 15:48:48 --> Controller Class Initialized
INFO - 2018-02-15 15:48:48 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 15:48:48 --> Model Class Initialized
INFO - 2018-02-15 15:48:48 --> Model Class Initialized
INFO - 2018-02-15 15:48:48 --> Model Class Initialized
INFO - 2018-02-15 15:48:48 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-15 15:48:48 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-15 15:48:48 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-15 15:48:48 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-15 15:48:48 --> File loaded: /var/www/html/project/radio/application/views/tracks/index.php
INFO - 2018-02-15 15:48:48 --> Final output sent to browser
DEBUG - 2018-02-15 15:48:48 --> Total execution time: 0.0056
INFO - 2018-02-15 15:48:48 --> Config Class Initialized
INFO - 2018-02-15 15:48:48 --> Hooks Class Initialized
DEBUG - 2018-02-15 15:48:48 --> UTF-8 Support Enabled
INFO - 2018-02-15 15:48:48 --> Utf8 Class Initialized
INFO - 2018-02-15 15:48:48 --> URI Class Initialized
INFO - 2018-02-15 15:48:48 --> Router Class Initialized
INFO - 2018-02-15 15:48:48 --> Output Class Initialized
INFO - 2018-02-15 15:48:48 --> Security Class Initialized
DEBUG - 2018-02-15 15:48:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 15:48:48 --> Input Class Initialized
INFO - 2018-02-15 15:48:48 --> Language Class Initialized
INFO - 2018-02-15 15:48:48 --> Loader Class Initialized
INFO - 2018-02-15 15:48:48 --> Helper loaded: url_helper
INFO - 2018-02-15 15:48:48 --> Helper loaded: file_helper
INFO - 2018-02-15 15:48:48 --> Helper loaded: email_helper
INFO - 2018-02-15 15:48:48 --> Helper loaded: common_helper
INFO - 2018-02-15 15:48:48 --> Database Driver Class Initialized
DEBUG - 2018-02-15 15:48:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 15:48:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 15:48:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 15:48:48 --> Pagination Class Initialized
INFO - 2018-02-15 15:48:48 --> Helper loaded: form_helper
INFO - 2018-02-15 15:48:48 --> Form Validation Class Initialized
INFO - 2018-02-15 15:48:48 --> Model Class Initialized
INFO - 2018-02-15 15:48:48 --> Controller Class Initialized
INFO - 2018-02-15 15:48:48 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 15:48:48 --> Model Class Initialized
INFO - 2018-02-15 15:48:48 --> Model Class Initialized
INFO - 2018-02-15 15:48:48 --> Model Class Initialized
INFO - 2018-02-15 15:49:08 --> Config Class Initialized
INFO - 2018-02-15 15:49:08 --> Hooks Class Initialized
DEBUG - 2018-02-15 15:49:08 --> UTF-8 Support Enabled
INFO - 2018-02-15 15:49:08 --> Utf8 Class Initialized
INFO - 2018-02-15 15:49:08 --> URI Class Initialized
INFO - 2018-02-15 15:49:08 --> Router Class Initialized
INFO - 2018-02-15 15:49:08 --> Output Class Initialized
INFO - 2018-02-15 15:49:08 --> Security Class Initialized
DEBUG - 2018-02-15 15:49:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 15:49:08 --> Input Class Initialized
INFO - 2018-02-15 15:49:08 --> Language Class Initialized
INFO - 2018-02-15 15:49:08 --> Loader Class Initialized
INFO - 2018-02-15 15:49:08 --> Helper loaded: url_helper
INFO - 2018-02-15 15:49:08 --> Helper loaded: file_helper
INFO - 2018-02-15 15:49:08 --> Helper loaded: email_helper
INFO - 2018-02-15 15:49:08 --> Helper loaded: common_helper
INFO - 2018-02-15 15:49:08 --> Database Driver Class Initialized
DEBUG - 2018-02-15 15:49:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 15:49:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 15:49:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 15:49:08 --> Pagination Class Initialized
INFO - 2018-02-15 15:49:08 --> Helper loaded: form_helper
INFO - 2018-02-15 15:49:08 --> Form Validation Class Initialized
INFO - 2018-02-15 15:49:08 --> Model Class Initialized
INFO - 2018-02-15 15:49:08 --> Controller Class Initialized
INFO - 2018-02-15 15:49:08 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 15:49:08 --> Model Class Initialized
INFO - 2018-02-15 15:49:08 --> Model Class Initialized
INFO - 2018-02-15 15:49:08 --> Model Class Initialized
INFO - 2018-02-15 15:49:08 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-15 15:49:08 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-15 15:49:08 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-15 15:49:08 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-15 15:49:08 --> File loaded: /var/www/html/project/radio/application/views/tracks/index.php
INFO - 2018-02-15 15:49:08 --> Final output sent to browser
DEBUG - 2018-02-15 15:49:08 --> Total execution time: 0.0064
INFO - 2018-02-15 15:49:08 --> Config Class Initialized
INFO - 2018-02-15 15:49:08 --> Hooks Class Initialized
DEBUG - 2018-02-15 15:49:08 --> UTF-8 Support Enabled
INFO - 2018-02-15 15:49:08 --> Utf8 Class Initialized
INFO - 2018-02-15 15:49:08 --> URI Class Initialized
INFO - 2018-02-15 15:49:08 --> Router Class Initialized
INFO - 2018-02-15 15:49:08 --> Output Class Initialized
INFO - 2018-02-15 15:49:08 --> Security Class Initialized
DEBUG - 2018-02-15 15:49:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 15:49:08 --> Input Class Initialized
INFO - 2018-02-15 15:49:08 --> Language Class Initialized
INFO - 2018-02-15 15:49:08 --> Loader Class Initialized
INFO - 2018-02-15 15:49:08 --> Helper loaded: url_helper
INFO - 2018-02-15 15:49:08 --> Helper loaded: file_helper
INFO - 2018-02-15 15:49:08 --> Helper loaded: email_helper
INFO - 2018-02-15 15:49:08 --> Helper loaded: common_helper
INFO - 2018-02-15 15:49:08 --> Database Driver Class Initialized
DEBUG - 2018-02-15 15:49:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 15:49:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 15:49:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 15:49:08 --> Pagination Class Initialized
INFO - 2018-02-15 15:49:08 --> Helper loaded: form_helper
INFO - 2018-02-15 15:49:08 --> Form Validation Class Initialized
INFO - 2018-02-15 15:49:08 --> Model Class Initialized
INFO - 2018-02-15 15:49:08 --> Controller Class Initialized
INFO - 2018-02-15 15:49:08 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 15:49:08 --> Model Class Initialized
INFO - 2018-02-15 15:49:08 --> Model Class Initialized
INFO - 2018-02-15 15:49:08 --> Model Class Initialized
INFO - 2018-02-15 15:49:27 --> Config Class Initialized
INFO - 2018-02-15 15:49:27 --> Hooks Class Initialized
DEBUG - 2018-02-15 15:49:27 --> UTF-8 Support Enabled
INFO - 2018-02-15 15:49:27 --> Utf8 Class Initialized
INFO - 2018-02-15 15:49:27 --> URI Class Initialized
INFO - 2018-02-15 15:49:27 --> Router Class Initialized
INFO - 2018-02-15 15:49:27 --> Output Class Initialized
INFO - 2018-02-15 15:49:27 --> Security Class Initialized
DEBUG - 2018-02-15 15:49:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 15:49:27 --> Input Class Initialized
INFO - 2018-02-15 15:49:27 --> Language Class Initialized
INFO - 2018-02-15 15:49:27 --> Loader Class Initialized
INFO - 2018-02-15 15:49:27 --> Helper loaded: url_helper
INFO - 2018-02-15 15:49:27 --> Helper loaded: file_helper
INFO - 2018-02-15 15:49:27 --> Helper loaded: email_helper
INFO - 2018-02-15 15:49:27 --> Helper loaded: common_helper
INFO - 2018-02-15 15:49:27 --> Database Driver Class Initialized
DEBUG - 2018-02-15 15:49:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 15:49:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 15:49:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 15:49:27 --> Pagination Class Initialized
INFO - 2018-02-15 15:49:27 --> Helper loaded: form_helper
INFO - 2018-02-15 15:49:27 --> Form Validation Class Initialized
INFO - 2018-02-15 15:49:27 --> Model Class Initialized
INFO - 2018-02-15 15:49:27 --> Controller Class Initialized
INFO - 2018-02-15 15:49:27 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 15:49:27 --> Model Class Initialized
INFO - 2018-02-15 15:49:27 --> Model Class Initialized
INFO - 2018-02-15 15:49:27 --> Model Class Initialized
INFO - 2018-02-15 15:49:27 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-15 15:49:27 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-15 15:49:27 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-15 15:49:27 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-15 15:49:27 --> File loaded: /var/www/html/project/radio/application/views/tracks/index.php
INFO - 2018-02-15 15:49:27 --> Final output sent to browser
DEBUG - 2018-02-15 15:49:27 --> Total execution time: 0.0062
INFO - 2018-02-15 15:49:27 --> Config Class Initialized
INFO - 2018-02-15 15:49:27 --> Hooks Class Initialized
DEBUG - 2018-02-15 15:49:27 --> UTF-8 Support Enabled
INFO - 2018-02-15 15:49:27 --> Utf8 Class Initialized
INFO - 2018-02-15 15:49:27 --> URI Class Initialized
INFO - 2018-02-15 15:49:27 --> Router Class Initialized
INFO - 2018-02-15 15:49:27 --> Output Class Initialized
INFO - 2018-02-15 15:49:27 --> Security Class Initialized
DEBUG - 2018-02-15 15:49:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 15:49:27 --> Input Class Initialized
INFO - 2018-02-15 15:49:27 --> Language Class Initialized
INFO - 2018-02-15 15:49:27 --> Loader Class Initialized
INFO - 2018-02-15 15:49:27 --> Helper loaded: url_helper
INFO - 2018-02-15 15:49:27 --> Helper loaded: file_helper
INFO - 2018-02-15 15:49:27 --> Helper loaded: email_helper
INFO - 2018-02-15 15:49:27 --> Helper loaded: common_helper
INFO - 2018-02-15 15:49:27 --> Database Driver Class Initialized
DEBUG - 2018-02-15 15:49:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 15:49:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 15:49:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 15:49:27 --> Pagination Class Initialized
INFO - 2018-02-15 15:49:27 --> Helper loaded: form_helper
INFO - 2018-02-15 15:49:27 --> Form Validation Class Initialized
INFO - 2018-02-15 15:49:27 --> Model Class Initialized
INFO - 2018-02-15 15:49:27 --> Controller Class Initialized
INFO - 2018-02-15 15:49:27 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 15:49:27 --> Model Class Initialized
INFO - 2018-02-15 15:49:27 --> Model Class Initialized
INFO - 2018-02-15 15:49:27 --> Model Class Initialized
INFO - 2018-02-15 15:49:38 --> Config Class Initialized
INFO - 2018-02-15 15:49:38 --> Hooks Class Initialized
DEBUG - 2018-02-15 15:49:38 --> UTF-8 Support Enabled
INFO - 2018-02-15 15:49:38 --> Utf8 Class Initialized
INFO - 2018-02-15 15:49:38 --> URI Class Initialized
INFO - 2018-02-15 15:49:38 --> Router Class Initialized
INFO - 2018-02-15 15:49:38 --> Output Class Initialized
INFO - 2018-02-15 15:49:38 --> Security Class Initialized
DEBUG - 2018-02-15 15:49:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 15:49:38 --> Input Class Initialized
INFO - 2018-02-15 15:49:38 --> Language Class Initialized
INFO - 2018-02-15 15:49:38 --> Loader Class Initialized
INFO - 2018-02-15 15:49:38 --> Helper loaded: url_helper
INFO - 2018-02-15 15:49:38 --> Helper loaded: file_helper
INFO - 2018-02-15 15:49:38 --> Helper loaded: email_helper
INFO - 2018-02-15 15:49:38 --> Helper loaded: common_helper
INFO - 2018-02-15 15:49:38 --> Database Driver Class Initialized
DEBUG - 2018-02-15 15:49:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 15:49:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 15:49:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 15:49:38 --> Pagination Class Initialized
INFO - 2018-02-15 15:49:38 --> Helper loaded: form_helper
INFO - 2018-02-15 15:49:38 --> Form Validation Class Initialized
INFO - 2018-02-15 15:49:38 --> Model Class Initialized
INFO - 2018-02-15 15:49:38 --> Controller Class Initialized
INFO - 2018-02-15 15:49:38 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 15:49:38 --> Model Class Initialized
INFO - 2018-02-15 15:49:38 --> Model Class Initialized
INFO - 2018-02-15 15:49:38 --> Model Class Initialized
INFO - 2018-02-15 15:49:38 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-15 15:49:38 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-15 15:49:38 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-15 15:49:38 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-15 15:49:38 --> File loaded: /var/www/html/project/radio/application/views/tracks/index.php
INFO - 2018-02-15 15:49:38 --> Final output sent to browser
DEBUG - 2018-02-15 15:49:38 --> Total execution time: 0.0087
INFO - 2018-02-15 15:49:38 --> Config Class Initialized
INFO - 2018-02-15 15:49:38 --> Hooks Class Initialized
DEBUG - 2018-02-15 15:49:38 --> UTF-8 Support Enabled
INFO - 2018-02-15 15:49:38 --> Utf8 Class Initialized
INFO - 2018-02-15 15:49:38 --> URI Class Initialized
INFO - 2018-02-15 15:49:38 --> Router Class Initialized
INFO - 2018-02-15 15:49:38 --> Output Class Initialized
INFO - 2018-02-15 15:49:38 --> Security Class Initialized
DEBUG - 2018-02-15 15:49:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 15:49:38 --> Input Class Initialized
INFO - 2018-02-15 15:49:38 --> Language Class Initialized
INFO - 2018-02-15 15:49:38 --> Loader Class Initialized
INFO - 2018-02-15 15:49:38 --> Helper loaded: url_helper
INFO - 2018-02-15 15:49:38 --> Helper loaded: file_helper
INFO - 2018-02-15 15:49:38 --> Helper loaded: email_helper
INFO - 2018-02-15 15:49:38 --> Helper loaded: common_helper
INFO - 2018-02-15 15:49:38 --> Database Driver Class Initialized
DEBUG - 2018-02-15 15:49:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 15:49:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 15:49:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 15:49:38 --> Pagination Class Initialized
INFO - 2018-02-15 15:49:38 --> Helper loaded: form_helper
INFO - 2018-02-15 15:49:38 --> Form Validation Class Initialized
INFO - 2018-02-15 15:49:38 --> Model Class Initialized
INFO - 2018-02-15 15:49:38 --> Controller Class Initialized
INFO - 2018-02-15 15:49:38 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 15:49:38 --> Model Class Initialized
INFO - 2018-02-15 15:49:38 --> Model Class Initialized
INFO - 2018-02-15 15:49:38 --> Model Class Initialized
INFO - 2018-02-15 15:52:11 --> Config Class Initialized
INFO - 2018-02-15 15:52:11 --> Hooks Class Initialized
DEBUG - 2018-02-15 15:52:11 --> UTF-8 Support Enabled
INFO - 2018-02-15 15:52:11 --> Utf8 Class Initialized
INFO - 2018-02-15 15:52:11 --> URI Class Initialized
INFO - 2018-02-15 15:52:11 --> Router Class Initialized
INFO - 2018-02-15 15:52:11 --> Output Class Initialized
INFO - 2018-02-15 15:52:11 --> Security Class Initialized
DEBUG - 2018-02-15 15:52:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 15:52:11 --> Input Class Initialized
INFO - 2018-02-15 15:52:11 --> Language Class Initialized
INFO - 2018-02-15 15:52:11 --> Loader Class Initialized
INFO - 2018-02-15 15:52:11 --> Helper loaded: url_helper
INFO - 2018-02-15 15:52:11 --> Helper loaded: file_helper
INFO - 2018-02-15 15:52:11 --> Helper loaded: email_helper
INFO - 2018-02-15 15:52:11 --> Helper loaded: common_helper
INFO - 2018-02-15 15:52:11 --> Database Driver Class Initialized
DEBUG - 2018-02-15 15:52:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 15:52:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 15:52:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 15:52:11 --> Pagination Class Initialized
INFO - 2018-02-15 15:52:11 --> Helper loaded: form_helper
INFO - 2018-02-15 15:52:11 --> Form Validation Class Initialized
INFO - 2018-02-15 15:52:11 --> Model Class Initialized
INFO - 2018-02-15 15:52:11 --> Controller Class Initialized
INFO - 2018-02-15 15:52:11 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 15:52:11 --> Model Class Initialized
INFO - 2018-02-15 15:52:11 --> Model Class Initialized
INFO - 2018-02-15 15:52:11 --> Model Class Initialized
INFO - 2018-02-15 15:52:11 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-15 15:52:11 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-15 15:52:11 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-15 15:52:11 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-15 15:52:11 --> File loaded: /var/www/html/project/radio/application/views/tracks/index.php
INFO - 2018-02-15 15:52:11 --> Final output sent to browser
DEBUG - 2018-02-15 15:52:11 --> Total execution time: 0.0067
INFO - 2018-02-15 15:52:11 --> Config Class Initialized
INFO - 2018-02-15 15:52:11 --> Hooks Class Initialized
DEBUG - 2018-02-15 15:52:11 --> UTF-8 Support Enabled
INFO - 2018-02-15 15:52:11 --> Utf8 Class Initialized
INFO - 2018-02-15 15:52:11 --> URI Class Initialized
INFO - 2018-02-15 15:52:11 --> Router Class Initialized
INFO - 2018-02-15 15:52:11 --> Output Class Initialized
INFO - 2018-02-15 15:52:11 --> Security Class Initialized
DEBUG - 2018-02-15 15:52:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 15:52:11 --> Input Class Initialized
INFO - 2018-02-15 15:52:11 --> Language Class Initialized
INFO - 2018-02-15 15:52:11 --> Loader Class Initialized
INFO - 2018-02-15 15:52:11 --> Helper loaded: url_helper
INFO - 2018-02-15 15:52:11 --> Helper loaded: file_helper
INFO - 2018-02-15 15:52:11 --> Helper loaded: email_helper
INFO - 2018-02-15 15:52:11 --> Helper loaded: common_helper
INFO - 2018-02-15 15:52:11 --> Database Driver Class Initialized
DEBUG - 2018-02-15 15:52:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 15:52:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 15:52:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 15:52:11 --> Pagination Class Initialized
INFO - 2018-02-15 15:52:11 --> Helper loaded: form_helper
INFO - 2018-02-15 15:52:11 --> Form Validation Class Initialized
INFO - 2018-02-15 15:52:11 --> Model Class Initialized
INFO - 2018-02-15 15:52:11 --> Controller Class Initialized
INFO - 2018-02-15 15:52:11 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 15:52:11 --> Model Class Initialized
INFO - 2018-02-15 15:52:11 --> Model Class Initialized
INFO - 2018-02-15 15:52:11 --> Model Class Initialized
INFO - 2018-02-15 15:52:27 --> Config Class Initialized
INFO - 2018-02-15 15:52:27 --> Hooks Class Initialized
DEBUG - 2018-02-15 15:52:27 --> UTF-8 Support Enabled
INFO - 2018-02-15 15:52:27 --> Utf8 Class Initialized
INFO - 2018-02-15 15:52:27 --> URI Class Initialized
INFO - 2018-02-15 15:52:27 --> Router Class Initialized
INFO - 2018-02-15 15:52:27 --> Output Class Initialized
INFO - 2018-02-15 15:52:27 --> Security Class Initialized
DEBUG - 2018-02-15 15:52:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 15:52:27 --> Input Class Initialized
INFO - 2018-02-15 15:52:27 --> Language Class Initialized
INFO - 2018-02-15 15:52:27 --> Loader Class Initialized
INFO - 2018-02-15 15:52:27 --> Helper loaded: url_helper
INFO - 2018-02-15 15:52:27 --> Helper loaded: file_helper
INFO - 2018-02-15 15:52:27 --> Helper loaded: email_helper
INFO - 2018-02-15 15:52:27 --> Helper loaded: common_helper
INFO - 2018-02-15 15:52:27 --> Database Driver Class Initialized
DEBUG - 2018-02-15 15:52:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 15:52:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 15:52:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 15:52:27 --> Pagination Class Initialized
INFO - 2018-02-15 15:52:27 --> Helper loaded: form_helper
INFO - 2018-02-15 15:52:27 --> Form Validation Class Initialized
INFO - 2018-02-15 15:52:27 --> Model Class Initialized
INFO - 2018-02-15 15:52:27 --> Controller Class Initialized
INFO - 2018-02-15 15:52:27 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 15:52:27 --> Model Class Initialized
INFO - 2018-02-15 15:52:27 --> Model Class Initialized
INFO - 2018-02-15 15:52:27 --> Model Class Initialized
INFO - 2018-02-15 15:52:27 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-15 15:52:27 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-15 15:52:27 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-15 15:52:27 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-15 15:52:27 --> File loaded: /var/www/html/project/radio/application/views/tracks/index.php
INFO - 2018-02-15 15:52:27 --> Final output sent to browser
DEBUG - 2018-02-15 15:52:27 --> Total execution time: 0.0061
INFO - 2018-02-15 15:52:28 --> Config Class Initialized
INFO - 2018-02-15 15:52:28 --> Hooks Class Initialized
DEBUG - 2018-02-15 15:52:28 --> UTF-8 Support Enabled
INFO - 2018-02-15 15:52:28 --> Utf8 Class Initialized
INFO - 2018-02-15 15:52:28 --> URI Class Initialized
INFO - 2018-02-15 15:52:28 --> Router Class Initialized
INFO - 2018-02-15 15:52:28 --> Output Class Initialized
INFO - 2018-02-15 15:52:28 --> Security Class Initialized
DEBUG - 2018-02-15 15:52:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 15:52:28 --> Input Class Initialized
INFO - 2018-02-15 15:52:28 --> Language Class Initialized
INFO - 2018-02-15 15:52:28 --> Loader Class Initialized
INFO - 2018-02-15 15:52:28 --> Helper loaded: url_helper
INFO - 2018-02-15 15:52:28 --> Helper loaded: file_helper
INFO - 2018-02-15 15:52:28 --> Helper loaded: email_helper
INFO - 2018-02-15 15:52:28 --> Helper loaded: common_helper
INFO - 2018-02-15 15:52:28 --> Database Driver Class Initialized
DEBUG - 2018-02-15 15:52:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 15:52:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 15:52:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 15:52:28 --> Pagination Class Initialized
INFO - 2018-02-15 15:52:28 --> Helper loaded: form_helper
INFO - 2018-02-15 15:52:28 --> Form Validation Class Initialized
INFO - 2018-02-15 15:52:28 --> Model Class Initialized
INFO - 2018-02-15 15:52:28 --> Controller Class Initialized
INFO - 2018-02-15 15:52:28 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 15:52:28 --> Model Class Initialized
INFO - 2018-02-15 15:52:28 --> Model Class Initialized
INFO - 2018-02-15 15:52:28 --> Model Class Initialized
INFO - 2018-02-15 15:52:59 --> Config Class Initialized
INFO - 2018-02-15 15:52:59 --> Hooks Class Initialized
DEBUG - 2018-02-15 15:52:59 --> UTF-8 Support Enabled
INFO - 2018-02-15 15:52:59 --> Utf8 Class Initialized
INFO - 2018-02-15 15:52:59 --> URI Class Initialized
INFO - 2018-02-15 15:52:59 --> Router Class Initialized
INFO - 2018-02-15 15:52:59 --> Output Class Initialized
INFO - 2018-02-15 15:52:59 --> Security Class Initialized
DEBUG - 2018-02-15 15:52:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 15:52:59 --> Input Class Initialized
INFO - 2018-02-15 15:52:59 --> Language Class Initialized
INFO - 2018-02-15 15:52:59 --> Loader Class Initialized
INFO - 2018-02-15 15:52:59 --> Helper loaded: url_helper
INFO - 2018-02-15 15:52:59 --> Helper loaded: file_helper
INFO - 2018-02-15 15:52:59 --> Helper loaded: email_helper
INFO - 2018-02-15 15:52:59 --> Helper loaded: common_helper
INFO - 2018-02-15 15:52:59 --> Database Driver Class Initialized
DEBUG - 2018-02-15 15:52:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 15:52:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 15:52:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 15:52:59 --> Pagination Class Initialized
INFO - 2018-02-15 15:52:59 --> Helper loaded: form_helper
INFO - 2018-02-15 15:52:59 --> Form Validation Class Initialized
INFO - 2018-02-15 15:52:59 --> Model Class Initialized
INFO - 2018-02-15 15:52:59 --> Controller Class Initialized
INFO - 2018-02-15 15:52:59 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 15:52:59 --> Model Class Initialized
INFO - 2018-02-15 15:52:59 --> Model Class Initialized
INFO - 2018-02-15 15:52:59 --> Model Class Initialized
INFO - 2018-02-15 15:52:59 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-15 15:52:59 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-15 15:52:59 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-15 15:52:59 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-15 15:52:59 --> File loaded: /var/www/html/project/radio/application/views/tracks/index.php
INFO - 2018-02-15 15:52:59 --> Final output sent to browser
DEBUG - 2018-02-15 15:52:59 --> Total execution time: 0.0059
INFO - 2018-02-15 15:53:00 --> Config Class Initialized
INFO - 2018-02-15 15:53:00 --> Hooks Class Initialized
DEBUG - 2018-02-15 15:53:00 --> UTF-8 Support Enabled
INFO - 2018-02-15 15:53:00 --> Utf8 Class Initialized
INFO - 2018-02-15 15:53:00 --> URI Class Initialized
INFO - 2018-02-15 15:53:00 --> Router Class Initialized
INFO - 2018-02-15 15:53:00 --> Output Class Initialized
INFO - 2018-02-15 15:53:00 --> Security Class Initialized
DEBUG - 2018-02-15 15:53:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 15:53:00 --> Input Class Initialized
INFO - 2018-02-15 15:53:00 --> Language Class Initialized
INFO - 2018-02-15 15:53:00 --> Loader Class Initialized
INFO - 2018-02-15 15:53:00 --> Helper loaded: url_helper
INFO - 2018-02-15 15:53:00 --> Helper loaded: file_helper
INFO - 2018-02-15 15:53:00 --> Helper loaded: email_helper
INFO - 2018-02-15 15:53:00 --> Helper loaded: common_helper
INFO - 2018-02-15 15:53:00 --> Database Driver Class Initialized
DEBUG - 2018-02-15 15:53:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 15:53:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 15:53:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 15:53:00 --> Pagination Class Initialized
INFO - 2018-02-15 15:53:00 --> Helper loaded: form_helper
INFO - 2018-02-15 15:53:00 --> Form Validation Class Initialized
INFO - 2018-02-15 15:53:00 --> Model Class Initialized
INFO - 2018-02-15 15:53:00 --> Controller Class Initialized
INFO - 2018-02-15 15:53:00 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 15:53:00 --> Model Class Initialized
INFO - 2018-02-15 15:53:00 --> Model Class Initialized
INFO - 2018-02-15 15:53:00 --> Model Class Initialized
INFO - 2018-02-15 15:56:15 --> Config Class Initialized
INFO - 2018-02-15 15:56:15 --> Hooks Class Initialized
DEBUG - 2018-02-15 15:56:15 --> UTF-8 Support Enabled
INFO - 2018-02-15 15:56:15 --> Utf8 Class Initialized
INFO - 2018-02-15 15:56:15 --> URI Class Initialized
INFO - 2018-02-15 15:56:15 --> Router Class Initialized
INFO - 2018-02-15 15:56:15 --> Output Class Initialized
INFO - 2018-02-15 15:56:15 --> Security Class Initialized
DEBUG - 2018-02-15 15:56:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 15:56:15 --> Input Class Initialized
INFO - 2018-02-15 15:56:15 --> Language Class Initialized
INFO - 2018-02-15 15:56:15 --> Loader Class Initialized
INFO - 2018-02-15 15:56:15 --> Helper loaded: url_helper
INFO - 2018-02-15 15:56:15 --> Helper loaded: file_helper
INFO - 2018-02-15 15:56:15 --> Helper loaded: email_helper
INFO - 2018-02-15 15:56:15 --> Helper loaded: common_helper
INFO - 2018-02-15 15:56:15 --> Database Driver Class Initialized
DEBUG - 2018-02-15 15:56:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 15:56:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 15:56:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 15:56:15 --> Pagination Class Initialized
INFO - 2018-02-15 15:56:15 --> Helper loaded: form_helper
INFO - 2018-02-15 15:56:15 --> Form Validation Class Initialized
INFO - 2018-02-15 15:56:15 --> Model Class Initialized
INFO - 2018-02-15 15:56:15 --> Controller Class Initialized
INFO - 2018-02-15 15:56:15 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 15:56:15 --> Model Class Initialized
INFO - 2018-02-15 15:56:15 --> Model Class Initialized
INFO - 2018-02-15 15:56:15 --> Model Class Initialized
INFO - 2018-02-15 15:56:15 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-15 15:56:15 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-15 15:56:15 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-15 15:56:15 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-15 15:56:15 --> File loaded: /var/www/html/project/radio/application/views/tracks/index.php
INFO - 2018-02-15 15:56:15 --> Final output sent to browser
DEBUG - 2018-02-15 15:56:15 --> Total execution time: 0.0095
INFO - 2018-02-15 15:56:15 --> Config Class Initialized
INFO - 2018-02-15 15:56:15 --> Hooks Class Initialized
DEBUG - 2018-02-15 15:56:15 --> UTF-8 Support Enabled
INFO - 2018-02-15 15:56:15 --> Utf8 Class Initialized
INFO - 2018-02-15 15:56:15 --> URI Class Initialized
INFO - 2018-02-15 15:56:15 --> Router Class Initialized
INFO - 2018-02-15 15:56:15 --> Output Class Initialized
INFO - 2018-02-15 15:56:15 --> Security Class Initialized
DEBUG - 2018-02-15 15:56:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 15:56:15 --> Input Class Initialized
INFO - 2018-02-15 15:56:15 --> Language Class Initialized
INFO - 2018-02-15 15:56:15 --> Loader Class Initialized
INFO - 2018-02-15 15:56:15 --> Helper loaded: url_helper
INFO - 2018-02-15 15:56:15 --> Helper loaded: file_helper
INFO - 2018-02-15 15:56:15 --> Helper loaded: email_helper
INFO - 2018-02-15 15:56:15 --> Helper loaded: common_helper
INFO - 2018-02-15 15:56:15 --> Database Driver Class Initialized
DEBUG - 2018-02-15 15:56:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 15:56:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 15:56:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 15:56:15 --> Pagination Class Initialized
INFO - 2018-02-15 15:56:15 --> Helper loaded: form_helper
INFO - 2018-02-15 15:56:15 --> Form Validation Class Initialized
INFO - 2018-02-15 15:56:15 --> Model Class Initialized
INFO - 2018-02-15 15:56:15 --> Controller Class Initialized
INFO - 2018-02-15 15:56:15 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 15:56:15 --> Model Class Initialized
INFO - 2018-02-15 15:56:15 --> Model Class Initialized
INFO - 2018-02-15 15:56:15 --> Model Class Initialized
INFO - 2018-02-15 15:56:36 --> Config Class Initialized
INFO - 2018-02-15 15:56:36 --> Hooks Class Initialized
DEBUG - 2018-02-15 15:56:36 --> UTF-8 Support Enabled
INFO - 2018-02-15 15:56:36 --> Utf8 Class Initialized
INFO - 2018-02-15 15:56:36 --> URI Class Initialized
INFO - 2018-02-15 15:56:36 --> Router Class Initialized
INFO - 2018-02-15 15:56:36 --> Output Class Initialized
INFO - 2018-02-15 15:56:36 --> Security Class Initialized
DEBUG - 2018-02-15 15:56:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 15:56:36 --> Input Class Initialized
INFO - 2018-02-15 15:56:36 --> Language Class Initialized
INFO - 2018-02-15 15:56:36 --> Loader Class Initialized
INFO - 2018-02-15 15:56:36 --> Helper loaded: url_helper
INFO - 2018-02-15 15:56:36 --> Helper loaded: file_helper
INFO - 2018-02-15 15:56:36 --> Helper loaded: email_helper
INFO - 2018-02-15 15:56:36 --> Helper loaded: common_helper
INFO - 2018-02-15 15:56:36 --> Database Driver Class Initialized
DEBUG - 2018-02-15 15:56:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 15:56:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 15:56:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 15:56:36 --> Pagination Class Initialized
INFO - 2018-02-15 15:56:36 --> Helper loaded: form_helper
INFO - 2018-02-15 15:56:36 --> Form Validation Class Initialized
INFO - 2018-02-15 15:56:36 --> Model Class Initialized
INFO - 2018-02-15 15:56:36 --> Controller Class Initialized
INFO - 2018-02-15 15:56:36 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 15:56:36 --> Model Class Initialized
INFO - 2018-02-15 15:56:36 --> Model Class Initialized
INFO - 2018-02-15 15:56:36 --> Model Class Initialized
INFO - 2018-02-15 15:56:36 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-15 15:56:36 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-15 15:56:36 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-15 15:56:36 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-15 15:56:36 --> File loaded: /var/www/html/project/radio/application/views/tracks/index.php
INFO - 2018-02-15 15:56:36 --> Final output sent to browser
DEBUG - 2018-02-15 15:56:36 --> Total execution time: 0.0054
INFO - 2018-02-15 15:56:37 --> Config Class Initialized
INFO - 2018-02-15 15:56:37 --> Hooks Class Initialized
DEBUG - 2018-02-15 15:56:37 --> UTF-8 Support Enabled
INFO - 2018-02-15 15:56:37 --> Utf8 Class Initialized
INFO - 2018-02-15 15:56:37 --> URI Class Initialized
INFO - 2018-02-15 15:56:37 --> Router Class Initialized
INFO - 2018-02-15 15:56:37 --> Output Class Initialized
INFO - 2018-02-15 15:56:37 --> Security Class Initialized
DEBUG - 2018-02-15 15:56:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 15:56:37 --> Input Class Initialized
INFO - 2018-02-15 15:56:37 --> Language Class Initialized
INFO - 2018-02-15 15:56:37 --> Loader Class Initialized
INFO - 2018-02-15 15:56:37 --> Helper loaded: url_helper
INFO - 2018-02-15 15:56:37 --> Helper loaded: file_helper
INFO - 2018-02-15 15:56:37 --> Helper loaded: email_helper
INFO - 2018-02-15 15:56:37 --> Helper loaded: common_helper
INFO - 2018-02-15 15:56:37 --> Database Driver Class Initialized
DEBUG - 2018-02-15 15:56:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 15:56:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 15:56:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 15:56:37 --> Pagination Class Initialized
INFO - 2018-02-15 15:56:37 --> Helper loaded: form_helper
INFO - 2018-02-15 15:56:37 --> Form Validation Class Initialized
INFO - 2018-02-15 15:56:37 --> Model Class Initialized
INFO - 2018-02-15 15:56:37 --> Controller Class Initialized
INFO - 2018-02-15 15:56:37 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 15:56:37 --> Model Class Initialized
INFO - 2018-02-15 15:56:37 --> Model Class Initialized
INFO - 2018-02-15 15:56:37 --> Model Class Initialized
INFO - 2018-02-15 15:56:42 --> Config Class Initialized
INFO - 2018-02-15 15:56:42 --> Hooks Class Initialized
DEBUG - 2018-02-15 15:56:42 --> UTF-8 Support Enabled
INFO - 2018-02-15 15:56:42 --> Utf8 Class Initialized
INFO - 2018-02-15 15:56:42 --> URI Class Initialized
INFO - 2018-02-15 15:56:42 --> Router Class Initialized
INFO - 2018-02-15 15:56:42 --> Output Class Initialized
INFO - 2018-02-15 15:56:42 --> Security Class Initialized
DEBUG - 2018-02-15 15:56:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 15:56:42 --> Input Class Initialized
INFO - 2018-02-15 15:56:42 --> Language Class Initialized
INFO - 2018-02-15 15:56:42 --> Loader Class Initialized
INFO - 2018-02-15 15:56:42 --> Helper loaded: url_helper
INFO - 2018-02-15 15:56:42 --> Helper loaded: file_helper
INFO - 2018-02-15 15:56:42 --> Helper loaded: email_helper
INFO - 2018-02-15 15:56:42 --> Helper loaded: common_helper
INFO - 2018-02-15 15:56:42 --> Database Driver Class Initialized
DEBUG - 2018-02-15 15:56:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 15:56:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 15:56:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 15:56:42 --> Pagination Class Initialized
INFO - 2018-02-15 15:56:42 --> Helper loaded: form_helper
INFO - 2018-02-15 15:56:42 --> Form Validation Class Initialized
INFO - 2018-02-15 15:56:42 --> Model Class Initialized
INFO - 2018-02-15 15:56:42 --> Controller Class Initialized
INFO - 2018-02-15 15:56:42 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 15:56:42 --> Model Class Initialized
INFO - 2018-02-15 15:56:42 --> Model Class Initialized
INFO - 2018-02-15 15:56:42 --> Model Class Initialized
INFO - 2018-02-15 15:56:42 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-15 15:56:42 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-15 15:56:42 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-15 15:56:42 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-15 15:56:42 --> File loaded: /var/www/html/project/radio/application/views/tracks/index.php
INFO - 2018-02-15 15:56:42 --> Final output sent to browser
DEBUG - 2018-02-15 15:56:42 --> Total execution time: 0.0062
INFO - 2018-02-15 15:56:43 --> Config Class Initialized
INFO - 2018-02-15 15:56:43 --> Hooks Class Initialized
DEBUG - 2018-02-15 15:56:43 --> UTF-8 Support Enabled
INFO - 2018-02-15 15:56:43 --> Utf8 Class Initialized
INFO - 2018-02-15 15:56:43 --> URI Class Initialized
INFO - 2018-02-15 15:56:43 --> Router Class Initialized
INFO - 2018-02-15 15:56:43 --> Output Class Initialized
INFO - 2018-02-15 15:56:43 --> Security Class Initialized
DEBUG - 2018-02-15 15:56:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 15:56:43 --> Input Class Initialized
INFO - 2018-02-15 15:56:43 --> Language Class Initialized
INFO - 2018-02-15 15:56:43 --> Loader Class Initialized
INFO - 2018-02-15 15:56:43 --> Helper loaded: url_helper
INFO - 2018-02-15 15:56:43 --> Helper loaded: file_helper
INFO - 2018-02-15 15:56:43 --> Helper loaded: email_helper
INFO - 2018-02-15 15:56:43 --> Helper loaded: common_helper
INFO - 2018-02-15 15:56:43 --> Database Driver Class Initialized
DEBUG - 2018-02-15 15:56:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 15:56:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 15:56:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 15:56:43 --> Pagination Class Initialized
INFO - 2018-02-15 15:56:43 --> Helper loaded: form_helper
INFO - 2018-02-15 15:56:43 --> Form Validation Class Initialized
INFO - 2018-02-15 15:56:43 --> Model Class Initialized
INFO - 2018-02-15 15:56:43 --> Controller Class Initialized
INFO - 2018-02-15 15:56:43 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 15:56:43 --> Model Class Initialized
INFO - 2018-02-15 15:56:43 --> Model Class Initialized
INFO - 2018-02-15 15:56:43 --> Model Class Initialized
INFO - 2018-02-15 15:56:55 --> Config Class Initialized
INFO - 2018-02-15 15:56:55 --> Hooks Class Initialized
DEBUG - 2018-02-15 15:56:55 --> UTF-8 Support Enabled
INFO - 2018-02-15 15:56:55 --> Utf8 Class Initialized
INFO - 2018-02-15 15:56:55 --> URI Class Initialized
INFO - 2018-02-15 15:56:55 --> Router Class Initialized
INFO - 2018-02-15 15:56:55 --> Output Class Initialized
INFO - 2018-02-15 15:56:55 --> Security Class Initialized
DEBUG - 2018-02-15 15:56:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 15:56:55 --> Input Class Initialized
INFO - 2018-02-15 15:56:55 --> Language Class Initialized
INFO - 2018-02-15 15:56:55 --> Loader Class Initialized
INFO - 2018-02-15 15:56:55 --> Helper loaded: url_helper
INFO - 2018-02-15 15:56:55 --> Helper loaded: file_helper
INFO - 2018-02-15 15:56:55 --> Helper loaded: email_helper
INFO - 2018-02-15 15:56:55 --> Helper loaded: common_helper
INFO - 2018-02-15 15:56:55 --> Database Driver Class Initialized
DEBUG - 2018-02-15 15:56:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 15:56:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 15:56:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 15:56:55 --> Pagination Class Initialized
INFO - 2018-02-15 15:56:55 --> Helper loaded: form_helper
INFO - 2018-02-15 15:56:55 --> Form Validation Class Initialized
INFO - 2018-02-15 15:56:55 --> Model Class Initialized
INFO - 2018-02-15 15:56:55 --> Controller Class Initialized
INFO - 2018-02-15 15:56:55 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 15:56:55 --> Model Class Initialized
INFO - 2018-02-15 15:56:55 --> Model Class Initialized
INFO - 2018-02-15 15:56:55 --> Model Class Initialized
INFO - 2018-02-15 15:56:55 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-15 15:56:55 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-15 15:56:55 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-15 15:56:55 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-15 15:56:55 --> File loaded: /var/www/html/project/radio/application/views/tracks/index.php
INFO - 2018-02-15 15:56:55 --> Final output sent to browser
DEBUG - 2018-02-15 15:56:55 --> Total execution time: 0.0052
INFO - 2018-02-15 15:56:56 --> Config Class Initialized
INFO - 2018-02-15 15:56:56 --> Hooks Class Initialized
DEBUG - 2018-02-15 15:56:56 --> UTF-8 Support Enabled
INFO - 2018-02-15 15:56:56 --> Utf8 Class Initialized
INFO - 2018-02-15 15:56:56 --> URI Class Initialized
INFO - 2018-02-15 15:56:56 --> Router Class Initialized
INFO - 2018-02-15 15:56:56 --> Output Class Initialized
INFO - 2018-02-15 15:56:56 --> Security Class Initialized
DEBUG - 2018-02-15 15:56:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 15:56:56 --> Input Class Initialized
INFO - 2018-02-15 15:56:56 --> Language Class Initialized
INFO - 2018-02-15 15:56:56 --> Loader Class Initialized
INFO - 2018-02-15 15:56:56 --> Helper loaded: url_helper
INFO - 2018-02-15 15:56:56 --> Helper loaded: file_helper
INFO - 2018-02-15 15:56:56 --> Helper loaded: email_helper
INFO - 2018-02-15 15:56:56 --> Helper loaded: common_helper
INFO - 2018-02-15 15:56:56 --> Database Driver Class Initialized
DEBUG - 2018-02-15 15:56:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 15:56:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 15:56:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 15:56:56 --> Pagination Class Initialized
INFO - 2018-02-15 15:56:56 --> Helper loaded: form_helper
INFO - 2018-02-15 15:56:56 --> Form Validation Class Initialized
INFO - 2018-02-15 15:56:56 --> Model Class Initialized
INFO - 2018-02-15 15:56:56 --> Controller Class Initialized
INFO - 2018-02-15 15:56:56 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 15:56:56 --> Model Class Initialized
INFO - 2018-02-15 15:56:56 --> Model Class Initialized
INFO - 2018-02-15 15:56:56 --> Model Class Initialized
INFO - 2018-02-15 16:06:48 --> Config Class Initialized
INFO - 2018-02-15 16:06:48 --> Hooks Class Initialized
DEBUG - 2018-02-15 16:06:48 --> UTF-8 Support Enabled
INFO - 2018-02-15 16:06:48 --> Utf8 Class Initialized
INFO - 2018-02-15 16:06:48 --> URI Class Initialized
INFO - 2018-02-15 16:06:48 --> Router Class Initialized
INFO - 2018-02-15 16:06:48 --> Output Class Initialized
INFO - 2018-02-15 16:06:48 --> Security Class Initialized
DEBUG - 2018-02-15 16:06:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 16:06:48 --> Input Class Initialized
INFO - 2018-02-15 16:06:48 --> Language Class Initialized
INFO - 2018-02-15 16:06:48 --> Loader Class Initialized
INFO - 2018-02-15 16:06:48 --> Helper loaded: url_helper
INFO - 2018-02-15 16:06:48 --> Helper loaded: file_helper
INFO - 2018-02-15 16:06:48 --> Helper loaded: email_helper
INFO - 2018-02-15 16:06:48 --> Helper loaded: common_helper
INFO - 2018-02-15 16:06:48 --> Database Driver Class Initialized
DEBUG - 2018-02-15 16:06:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 16:06:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 16:06:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 16:06:48 --> Pagination Class Initialized
INFO - 2018-02-15 16:06:48 --> Helper loaded: form_helper
INFO - 2018-02-15 16:06:48 --> Form Validation Class Initialized
INFO - 2018-02-15 16:06:48 --> Model Class Initialized
INFO - 2018-02-15 16:06:48 --> Controller Class Initialized
INFO - 2018-02-15 16:06:48 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 16:06:48 --> Model Class Initialized
INFO - 2018-02-15 16:06:48 --> Model Class Initialized
INFO - 2018-02-15 16:06:48 --> Model Class Initialized
INFO - 2018-02-15 16:06:48 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-15 16:06:48 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-15 16:06:48 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-15 16:06:48 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-15 16:06:48 --> File loaded: /var/www/html/project/radio/application/views/tracks/index.php
INFO - 2018-02-15 16:06:48 --> Final output sent to browser
DEBUG - 2018-02-15 16:06:48 --> Total execution time: 0.0073
INFO - 2018-02-15 16:06:48 --> Config Class Initialized
INFO - 2018-02-15 16:06:48 --> Hooks Class Initialized
DEBUG - 2018-02-15 16:06:48 --> UTF-8 Support Enabled
INFO - 2018-02-15 16:06:48 --> Utf8 Class Initialized
INFO - 2018-02-15 16:06:48 --> URI Class Initialized
INFO - 2018-02-15 16:06:48 --> Router Class Initialized
INFO - 2018-02-15 16:06:48 --> Output Class Initialized
INFO - 2018-02-15 16:06:48 --> Security Class Initialized
DEBUG - 2018-02-15 16:06:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 16:06:48 --> Input Class Initialized
INFO - 2018-02-15 16:06:48 --> Language Class Initialized
INFO - 2018-02-15 16:06:48 --> Loader Class Initialized
INFO - 2018-02-15 16:06:48 --> Helper loaded: url_helper
INFO - 2018-02-15 16:06:48 --> Helper loaded: file_helper
INFO - 2018-02-15 16:06:48 --> Helper loaded: email_helper
INFO - 2018-02-15 16:06:48 --> Helper loaded: common_helper
INFO - 2018-02-15 16:06:48 --> Database Driver Class Initialized
DEBUG - 2018-02-15 16:06:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 16:06:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 16:06:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 16:06:48 --> Pagination Class Initialized
INFO - 2018-02-15 16:06:48 --> Helper loaded: form_helper
INFO - 2018-02-15 16:06:48 --> Form Validation Class Initialized
INFO - 2018-02-15 16:06:48 --> Model Class Initialized
INFO - 2018-02-15 16:06:48 --> Controller Class Initialized
INFO - 2018-02-15 16:06:48 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 16:06:48 --> Model Class Initialized
INFO - 2018-02-15 16:06:48 --> Model Class Initialized
INFO - 2018-02-15 16:06:48 --> Model Class Initialized
INFO - 2018-02-15 16:06:52 --> Config Class Initialized
INFO - 2018-02-15 16:06:52 --> Hooks Class Initialized
DEBUG - 2018-02-15 16:06:52 --> UTF-8 Support Enabled
INFO - 2018-02-15 16:06:52 --> Utf8 Class Initialized
INFO - 2018-02-15 16:06:52 --> URI Class Initialized
INFO - 2018-02-15 16:06:52 --> Router Class Initialized
INFO - 2018-02-15 16:06:52 --> Output Class Initialized
INFO - 2018-02-15 16:06:52 --> Security Class Initialized
DEBUG - 2018-02-15 16:06:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 16:06:52 --> Input Class Initialized
INFO - 2018-02-15 16:06:52 --> Language Class Initialized
INFO - 2018-02-15 16:06:52 --> Loader Class Initialized
INFO - 2018-02-15 16:06:52 --> Helper loaded: url_helper
INFO - 2018-02-15 16:06:52 --> Helper loaded: file_helper
INFO - 2018-02-15 16:06:52 --> Helper loaded: email_helper
INFO - 2018-02-15 16:06:52 --> Helper loaded: common_helper
INFO - 2018-02-15 16:06:52 --> Database Driver Class Initialized
DEBUG - 2018-02-15 16:06:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 16:06:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 16:06:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 16:06:52 --> Pagination Class Initialized
INFO - 2018-02-15 16:06:52 --> Helper loaded: form_helper
INFO - 2018-02-15 16:06:52 --> Form Validation Class Initialized
INFO - 2018-02-15 16:06:52 --> Model Class Initialized
INFO - 2018-02-15 16:06:52 --> Controller Class Initialized
INFO - 2018-02-15 16:06:52 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 16:06:52 --> Model Class Initialized
INFO - 2018-02-15 16:06:52 --> Model Class Initialized
INFO - 2018-02-15 16:06:52 --> Model Class Initialized
INFO - 2018-02-15 16:06:52 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-15 16:06:52 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-15 16:06:52 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-15 16:06:52 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-15 16:06:52 --> File loaded: /var/www/html/project/radio/application/views/tracks/index.php
INFO - 2018-02-15 16:06:52 --> Final output sent to browser
DEBUG - 2018-02-15 16:06:52 --> Total execution time: 0.0068
INFO - 2018-02-15 16:06:53 --> Config Class Initialized
INFO - 2018-02-15 16:06:53 --> Hooks Class Initialized
DEBUG - 2018-02-15 16:06:53 --> UTF-8 Support Enabled
INFO - 2018-02-15 16:06:53 --> Utf8 Class Initialized
INFO - 2018-02-15 16:06:53 --> URI Class Initialized
INFO - 2018-02-15 16:06:53 --> Router Class Initialized
INFO - 2018-02-15 16:06:53 --> Output Class Initialized
INFO - 2018-02-15 16:06:53 --> Security Class Initialized
DEBUG - 2018-02-15 16:06:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 16:06:53 --> Input Class Initialized
INFO - 2018-02-15 16:06:53 --> Language Class Initialized
INFO - 2018-02-15 16:06:53 --> Loader Class Initialized
INFO - 2018-02-15 16:06:53 --> Helper loaded: url_helper
INFO - 2018-02-15 16:06:53 --> Helper loaded: file_helper
INFO - 2018-02-15 16:06:53 --> Helper loaded: email_helper
INFO - 2018-02-15 16:06:53 --> Helper loaded: common_helper
INFO - 2018-02-15 16:06:53 --> Database Driver Class Initialized
DEBUG - 2018-02-15 16:06:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 16:06:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 16:06:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 16:06:53 --> Pagination Class Initialized
INFO - 2018-02-15 16:06:53 --> Helper loaded: form_helper
INFO - 2018-02-15 16:06:53 --> Form Validation Class Initialized
INFO - 2018-02-15 16:06:53 --> Model Class Initialized
INFO - 2018-02-15 16:06:53 --> Controller Class Initialized
INFO - 2018-02-15 16:06:53 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 16:06:53 --> Model Class Initialized
INFO - 2018-02-15 16:06:53 --> Model Class Initialized
INFO - 2018-02-15 16:06:53 --> Model Class Initialized
INFO - 2018-02-15 16:06:53 --> Config Class Initialized
INFO - 2018-02-15 16:06:53 --> Hooks Class Initialized
DEBUG - 2018-02-15 16:06:53 --> UTF-8 Support Enabled
INFO - 2018-02-15 16:06:53 --> Utf8 Class Initialized
INFO - 2018-02-15 16:06:53 --> URI Class Initialized
INFO - 2018-02-15 16:06:53 --> Router Class Initialized
INFO - 2018-02-15 16:06:53 --> Output Class Initialized
INFO - 2018-02-15 16:06:53 --> Security Class Initialized
DEBUG - 2018-02-15 16:06:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 16:06:53 --> Input Class Initialized
INFO - 2018-02-15 16:06:53 --> Language Class Initialized
INFO - 2018-02-15 16:06:53 --> Loader Class Initialized
INFO - 2018-02-15 16:06:53 --> Helper loaded: url_helper
INFO - 2018-02-15 16:06:53 --> Helper loaded: file_helper
INFO - 2018-02-15 16:06:53 --> Helper loaded: email_helper
INFO - 2018-02-15 16:06:53 --> Helper loaded: common_helper
INFO - 2018-02-15 16:06:53 --> Database Driver Class Initialized
DEBUG - 2018-02-15 16:06:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 16:06:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 16:06:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 16:06:53 --> Pagination Class Initialized
INFO - 2018-02-15 16:06:53 --> Helper loaded: form_helper
INFO - 2018-02-15 16:06:53 --> Form Validation Class Initialized
INFO - 2018-02-15 16:06:53 --> Model Class Initialized
INFO - 2018-02-15 16:06:53 --> Controller Class Initialized
INFO - 2018-02-15 16:06:53 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 16:06:53 --> Model Class Initialized
INFO - 2018-02-15 16:06:53 --> Model Class Initialized
INFO - 2018-02-15 16:06:53 --> Model Class Initialized
INFO - 2018-02-15 16:06:53 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-15 16:06:53 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-15 16:06:53 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-15 16:06:53 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-15 16:06:53 --> File loaded: /var/www/html/project/radio/application/views/tracks/index.php
INFO - 2018-02-15 16:06:53 --> Final output sent to browser
DEBUG - 2018-02-15 16:06:53 --> Total execution time: 0.0057
INFO - 2018-02-15 16:06:53 --> Config Class Initialized
INFO - 2018-02-15 16:06:53 --> Hooks Class Initialized
DEBUG - 2018-02-15 16:06:53 --> UTF-8 Support Enabled
INFO - 2018-02-15 16:06:53 --> Utf8 Class Initialized
INFO - 2018-02-15 16:06:53 --> URI Class Initialized
INFO - 2018-02-15 16:06:53 --> Router Class Initialized
INFO - 2018-02-15 16:06:53 --> Output Class Initialized
INFO - 2018-02-15 16:06:53 --> Security Class Initialized
DEBUG - 2018-02-15 16:06:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 16:06:53 --> Input Class Initialized
INFO - 2018-02-15 16:06:53 --> Language Class Initialized
INFO - 2018-02-15 16:06:53 --> Loader Class Initialized
INFO - 2018-02-15 16:06:53 --> Helper loaded: url_helper
INFO - 2018-02-15 16:06:53 --> Helper loaded: file_helper
INFO - 2018-02-15 16:06:53 --> Helper loaded: email_helper
INFO - 2018-02-15 16:06:53 --> Helper loaded: common_helper
INFO - 2018-02-15 16:06:53 --> Database Driver Class Initialized
DEBUG - 2018-02-15 16:06:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 16:06:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 16:06:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 16:06:53 --> Pagination Class Initialized
INFO - 2018-02-15 16:06:53 --> Helper loaded: form_helper
INFO - 2018-02-15 16:06:53 --> Form Validation Class Initialized
INFO - 2018-02-15 16:06:53 --> Model Class Initialized
INFO - 2018-02-15 16:06:53 --> Controller Class Initialized
INFO - 2018-02-15 16:06:53 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 16:06:53 --> Model Class Initialized
INFO - 2018-02-15 16:06:53 --> Model Class Initialized
INFO - 2018-02-15 16:06:53 --> Model Class Initialized
INFO - 2018-02-15 16:06:53 --> Config Class Initialized
INFO - 2018-02-15 16:06:53 --> Hooks Class Initialized
DEBUG - 2018-02-15 16:06:53 --> UTF-8 Support Enabled
INFO - 2018-02-15 16:06:53 --> Utf8 Class Initialized
INFO - 2018-02-15 16:06:53 --> URI Class Initialized
INFO - 2018-02-15 16:06:53 --> Router Class Initialized
INFO - 2018-02-15 16:06:53 --> Output Class Initialized
INFO - 2018-02-15 16:06:53 --> Security Class Initialized
DEBUG - 2018-02-15 16:06:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 16:06:53 --> Input Class Initialized
INFO - 2018-02-15 16:06:53 --> Language Class Initialized
INFO - 2018-02-15 16:06:53 --> Loader Class Initialized
INFO - 2018-02-15 16:06:53 --> Helper loaded: url_helper
INFO - 2018-02-15 16:06:53 --> Helper loaded: file_helper
INFO - 2018-02-15 16:06:53 --> Helper loaded: email_helper
INFO - 2018-02-15 16:06:53 --> Helper loaded: common_helper
INFO - 2018-02-15 16:06:53 --> Database Driver Class Initialized
DEBUG - 2018-02-15 16:06:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 16:06:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 16:06:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 16:06:53 --> Pagination Class Initialized
INFO - 2018-02-15 16:06:53 --> Helper loaded: form_helper
INFO - 2018-02-15 16:06:53 --> Form Validation Class Initialized
INFO - 2018-02-15 16:06:53 --> Model Class Initialized
INFO - 2018-02-15 16:06:53 --> Controller Class Initialized
INFO - 2018-02-15 16:06:53 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 16:06:53 --> Model Class Initialized
INFO - 2018-02-15 16:06:53 --> Model Class Initialized
INFO - 2018-02-15 16:06:53 --> Model Class Initialized
INFO - 2018-02-15 16:06:53 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-15 16:06:53 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-15 16:06:53 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-15 16:06:53 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-15 16:06:53 --> File loaded: /var/www/html/project/radio/application/views/tracks/index.php
INFO - 2018-02-15 16:06:53 --> Final output sent to browser
DEBUG - 2018-02-15 16:06:53 --> Total execution time: 0.0061
INFO - 2018-02-15 16:06:53 --> Config Class Initialized
INFO - 2018-02-15 16:06:53 --> Hooks Class Initialized
DEBUG - 2018-02-15 16:06:53 --> UTF-8 Support Enabled
INFO - 2018-02-15 16:06:53 --> Utf8 Class Initialized
INFO - 2018-02-15 16:06:53 --> URI Class Initialized
INFO - 2018-02-15 16:06:53 --> Router Class Initialized
INFO - 2018-02-15 16:06:53 --> Output Class Initialized
INFO - 2018-02-15 16:06:53 --> Security Class Initialized
DEBUG - 2018-02-15 16:06:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 16:06:53 --> Input Class Initialized
INFO - 2018-02-15 16:06:53 --> Language Class Initialized
INFO - 2018-02-15 16:06:53 --> Loader Class Initialized
INFO - 2018-02-15 16:06:53 --> Helper loaded: url_helper
INFO - 2018-02-15 16:06:53 --> Helper loaded: file_helper
INFO - 2018-02-15 16:06:53 --> Helper loaded: email_helper
INFO - 2018-02-15 16:06:53 --> Helper loaded: common_helper
INFO - 2018-02-15 16:06:53 --> Database Driver Class Initialized
DEBUG - 2018-02-15 16:06:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 16:06:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 16:06:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 16:06:53 --> Pagination Class Initialized
INFO - 2018-02-15 16:06:53 --> Helper loaded: form_helper
INFO - 2018-02-15 16:06:53 --> Form Validation Class Initialized
INFO - 2018-02-15 16:06:53 --> Model Class Initialized
INFO - 2018-02-15 16:06:53 --> Controller Class Initialized
INFO - 2018-02-15 16:06:53 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 16:06:53 --> Model Class Initialized
INFO - 2018-02-15 16:06:53 --> Model Class Initialized
INFO - 2018-02-15 16:06:53 --> Model Class Initialized
INFO - 2018-02-15 16:06:53 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-15 16:06:53 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-15 16:06:53 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-15 16:06:53 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-15 16:06:53 --> File loaded: /var/www/html/project/radio/application/views/tracks/index.php
INFO - 2018-02-15 16:06:53 --> Final output sent to browser
DEBUG - 2018-02-15 16:06:53 --> Total execution time: 0.0046
INFO - 2018-02-15 16:06:53 --> Config Class Initialized
INFO - 2018-02-15 16:06:53 --> Hooks Class Initialized
DEBUG - 2018-02-15 16:06:53 --> UTF-8 Support Enabled
INFO - 2018-02-15 16:06:53 --> Utf8 Class Initialized
INFO - 2018-02-15 16:06:53 --> URI Class Initialized
INFO - 2018-02-15 16:06:53 --> Router Class Initialized
INFO - 2018-02-15 16:06:53 --> Output Class Initialized
INFO - 2018-02-15 16:06:53 --> Security Class Initialized
DEBUG - 2018-02-15 16:06:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 16:06:53 --> Input Class Initialized
INFO - 2018-02-15 16:06:53 --> Language Class Initialized
INFO - 2018-02-15 16:06:53 --> Loader Class Initialized
INFO - 2018-02-15 16:06:53 --> Helper loaded: url_helper
INFO - 2018-02-15 16:06:53 --> Helper loaded: file_helper
INFO - 2018-02-15 16:06:53 --> Helper loaded: email_helper
INFO - 2018-02-15 16:06:53 --> Helper loaded: common_helper
INFO - 2018-02-15 16:06:53 --> Database Driver Class Initialized
DEBUG - 2018-02-15 16:06:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 16:06:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 16:06:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 16:06:53 --> Pagination Class Initialized
INFO - 2018-02-15 16:06:53 --> Helper loaded: form_helper
INFO - 2018-02-15 16:06:53 --> Form Validation Class Initialized
INFO - 2018-02-15 16:06:53 --> Model Class Initialized
INFO - 2018-02-15 16:06:53 --> Controller Class Initialized
INFO - 2018-02-15 16:06:53 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 16:06:53 --> Model Class Initialized
INFO - 2018-02-15 16:06:53 --> Model Class Initialized
INFO - 2018-02-15 16:06:53 --> Model Class Initialized
INFO - 2018-02-15 16:06:53 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-15 16:06:53 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-15 16:06:53 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-15 16:06:53 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-15 16:06:53 --> File loaded: /var/www/html/project/radio/application/views/tracks/index.php
INFO - 2018-02-15 16:06:53 --> Final output sent to browser
DEBUG - 2018-02-15 16:06:53 --> Total execution time: 0.0043
INFO - 2018-02-15 16:06:53 --> Config Class Initialized
INFO - 2018-02-15 16:06:53 --> Hooks Class Initialized
DEBUG - 2018-02-15 16:06:53 --> UTF-8 Support Enabled
INFO - 2018-02-15 16:06:53 --> Utf8 Class Initialized
INFO - 2018-02-15 16:06:53 --> URI Class Initialized
INFO - 2018-02-15 16:06:53 --> Router Class Initialized
INFO - 2018-02-15 16:06:53 --> Output Class Initialized
INFO - 2018-02-15 16:06:53 --> Security Class Initialized
DEBUG - 2018-02-15 16:06:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 16:06:53 --> Input Class Initialized
INFO - 2018-02-15 16:06:53 --> Language Class Initialized
INFO - 2018-02-15 16:06:53 --> Loader Class Initialized
INFO - 2018-02-15 16:06:53 --> Helper loaded: url_helper
INFO - 2018-02-15 16:06:53 --> Helper loaded: file_helper
INFO - 2018-02-15 16:06:53 --> Helper loaded: email_helper
INFO - 2018-02-15 16:06:53 --> Helper loaded: common_helper
INFO - 2018-02-15 16:06:53 --> Database Driver Class Initialized
DEBUG - 2018-02-15 16:06:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 16:06:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 16:06:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 16:06:53 --> Pagination Class Initialized
INFO - 2018-02-15 16:06:53 --> Helper loaded: form_helper
INFO - 2018-02-15 16:06:53 --> Form Validation Class Initialized
INFO - 2018-02-15 16:06:53 --> Model Class Initialized
INFO - 2018-02-15 16:06:53 --> Controller Class Initialized
INFO - 2018-02-15 16:06:53 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 16:06:53 --> Model Class Initialized
INFO - 2018-02-15 16:06:53 --> Model Class Initialized
INFO - 2018-02-15 16:06:53 --> Model Class Initialized
INFO - 2018-02-15 16:06:53 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-15 16:06:53 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-15 16:06:53 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-15 16:06:53 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-15 16:06:53 --> File loaded: /var/www/html/project/radio/application/views/tracks/index.php
INFO - 2018-02-15 16:06:53 --> Final output sent to browser
DEBUG - 2018-02-15 16:06:53 --> Total execution time: 0.0029
INFO - 2018-02-15 16:06:53 --> Config Class Initialized
INFO - 2018-02-15 16:06:53 --> Hooks Class Initialized
DEBUG - 2018-02-15 16:06:53 --> UTF-8 Support Enabled
INFO - 2018-02-15 16:06:53 --> Utf8 Class Initialized
INFO - 2018-02-15 16:06:53 --> URI Class Initialized
INFO - 2018-02-15 16:06:53 --> Router Class Initialized
INFO - 2018-02-15 16:06:53 --> Output Class Initialized
INFO - 2018-02-15 16:06:53 --> Security Class Initialized
DEBUG - 2018-02-15 16:06:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 16:06:53 --> Input Class Initialized
INFO - 2018-02-15 16:06:53 --> Language Class Initialized
INFO - 2018-02-15 16:06:53 --> Loader Class Initialized
INFO - 2018-02-15 16:06:53 --> Helper loaded: url_helper
INFO - 2018-02-15 16:06:53 --> Helper loaded: file_helper
INFO - 2018-02-15 16:06:53 --> Helper loaded: email_helper
INFO - 2018-02-15 16:06:53 --> Helper loaded: common_helper
INFO - 2018-02-15 16:06:53 --> Database Driver Class Initialized
DEBUG - 2018-02-15 16:06:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 16:06:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 16:06:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 16:06:53 --> Pagination Class Initialized
INFO - 2018-02-15 16:06:53 --> Helper loaded: form_helper
INFO - 2018-02-15 16:06:53 --> Form Validation Class Initialized
INFO - 2018-02-15 16:06:53 --> Model Class Initialized
INFO - 2018-02-15 16:06:53 --> Controller Class Initialized
INFO - 2018-02-15 16:06:53 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 16:06:53 --> Model Class Initialized
INFO - 2018-02-15 16:06:53 --> Model Class Initialized
INFO - 2018-02-15 16:06:53 --> Model Class Initialized
INFO - 2018-02-15 16:06:53 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-15 16:06:53 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-15 16:06:53 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-15 16:06:53 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-15 16:06:53 --> File loaded: /var/www/html/project/radio/application/views/tracks/index.php
INFO - 2018-02-15 16:06:53 --> Final output sent to browser
DEBUG - 2018-02-15 16:06:53 --> Total execution time: 0.0049
INFO - 2018-02-15 16:06:53 --> Config Class Initialized
INFO - 2018-02-15 16:06:53 --> Hooks Class Initialized
DEBUG - 2018-02-15 16:06:53 --> UTF-8 Support Enabled
INFO - 2018-02-15 16:06:53 --> Utf8 Class Initialized
INFO - 2018-02-15 16:06:53 --> URI Class Initialized
INFO - 2018-02-15 16:06:53 --> Router Class Initialized
INFO - 2018-02-15 16:06:53 --> Output Class Initialized
INFO - 2018-02-15 16:06:53 --> Security Class Initialized
DEBUG - 2018-02-15 16:06:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 16:06:53 --> Input Class Initialized
INFO - 2018-02-15 16:06:53 --> Language Class Initialized
INFO - 2018-02-15 16:06:53 --> Loader Class Initialized
INFO - 2018-02-15 16:06:53 --> Helper loaded: url_helper
INFO - 2018-02-15 16:06:53 --> Helper loaded: file_helper
INFO - 2018-02-15 16:06:53 --> Helper loaded: email_helper
INFO - 2018-02-15 16:06:53 --> Helper loaded: common_helper
INFO - 2018-02-15 16:06:53 --> Database Driver Class Initialized
DEBUG - 2018-02-15 16:06:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 16:06:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 16:06:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 16:06:53 --> Pagination Class Initialized
INFO - 2018-02-15 16:06:53 --> Helper loaded: form_helper
INFO - 2018-02-15 16:06:53 --> Form Validation Class Initialized
INFO - 2018-02-15 16:06:53 --> Model Class Initialized
INFO - 2018-02-15 16:06:53 --> Controller Class Initialized
INFO - 2018-02-15 16:06:53 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 16:06:53 --> Model Class Initialized
INFO - 2018-02-15 16:06:53 --> Model Class Initialized
INFO - 2018-02-15 16:06:53 --> Model Class Initialized
INFO - 2018-02-15 16:06:53 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-15 16:06:53 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-15 16:06:53 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-15 16:06:53 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-15 16:06:53 --> File loaded: /var/www/html/project/radio/application/views/tracks/index.php
INFO - 2018-02-15 16:06:53 --> Final output sent to browser
DEBUG - 2018-02-15 16:06:53 --> Total execution time: 0.0036
INFO - 2018-02-15 16:06:53 --> Config Class Initialized
INFO - 2018-02-15 16:06:53 --> Hooks Class Initialized
DEBUG - 2018-02-15 16:06:53 --> UTF-8 Support Enabled
INFO - 2018-02-15 16:06:53 --> Utf8 Class Initialized
INFO - 2018-02-15 16:06:53 --> URI Class Initialized
INFO - 2018-02-15 16:06:53 --> Router Class Initialized
INFO - 2018-02-15 16:06:53 --> Output Class Initialized
INFO - 2018-02-15 16:06:53 --> Security Class Initialized
DEBUG - 2018-02-15 16:06:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 16:06:53 --> Input Class Initialized
INFO - 2018-02-15 16:06:53 --> Language Class Initialized
INFO - 2018-02-15 16:06:53 --> Loader Class Initialized
INFO - 2018-02-15 16:06:53 --> Helper loaded: url_helper
INFO - 2018-02-15 16:06:53 --> Helper loaded: file_helper
INFO - 2018-02-15 16:06:53 --> Helper loaded: email_helper
INFO - 2018-02-15 16:06:53 --> Helper loaded: common_helper
INFO - 2018-02-15 16:06:53 --> Database Driver Class Initialized
DEBUG - 2018-02-15 16:06:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 16:06:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 16:06:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 16:06:53 --> Pagination Class Initialized
INFO - 2018-02-15 16:06:53 --> Helper loaded: form_helper
INFO - 2018-02-15 16:06:53 --> Form Validation Class Initialized
INFO - 2018-02-15 16:06:53 --> Model Class Initialized
INFO - 2018-02-15 16:06:53 --> Controller Class Initialized
INFO - 2018-02-15 16:06:53 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 16:06:53 --> Model Class Initialized
INFO - 2018-02-15 16:06:53 --> Model Class Initialized
INFO - 2018-02-15 16:06:53 --> Model Class Initialized
INFO - 2018-02-15 16:06:53 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-15 16:06:53 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-15 16:06:53 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-15 16:06:53 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-15 16:06:53 --> File loaded: /var/www/html/project/radio/application/views/tracks/index.php
INFO - 2018-02-15 16:06:53 --> Final output sent to browser
DEBUG - 2018-02-15 16:06:53 --> Total execution time: 0.0046
INFO - 2018-02-15 16:06:53 --> Config Class Initialized
INFO - 2018-02-15 16:06:53 --> Hooks Class Initialized
DEBUG - 2018-02-15 16:06:53 --> UTF-8 Support Enabled
INFO - 2018-02-15 16:06:53 --> Utf8 Class Initialized
INFO - 2018-02-15 16:06:53 --> URI Class Initialized
INFO - 2018-02-15 16:06:53 --> Router Class Initialized
INFO - 2018-02-15 16:06:53 --> Output Class Initialized
INFO - 2018-02-15 16:06:53 --> Security Class Initialized
DEBUG - 2018-02-15 16:06:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 16:06:53 --> Input Class Initialized
INFO - 2018-02-15 16:06:53 --> Language Class Initialized
INFO - 2018-02-15 16:06:53 --> Loader Class Initialized
INFO - 2018-02-15 16:06:53 --> Helper loaded: url_helper
INFO - 2018-02-15 16:06:53 --> Helper loaded: file_helper
INFO - 2018-02-15 16:06:53 --> Helper loaded: email_helper
INFO - 2018-02-15 16:06:53 --> Helper loaded: common_helper
INFO - 2018-02-15 16:06:53 --> Database Driver Class Initialized
DEBUG - 2018-02-15 16:06:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 16:06:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 16:06:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 16:06:53 --> Pagination Class Initialized
INFO - 2018-02-15 16:06:53 --> Helper loaded: form_helper
INFO - 2018-02-15 16:06:53 --> Form Validation Class Initialized
INFO - 2018-02-15 16:06:53 --> Model Class Initialized
INFO - 2018-02-15 16:06:53 --> Controller Class Initialized
INFO - 2018-02-15 16:06:53 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 16:06:53 --> Model Class Initialized
INFO - 2018-02-15 16:06:53 --> Model Class Initialized
INFO - 2018-02-15 16:06:53 --> Model Class Initialized
INFO - 2018-02-15 16:06:53 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-15 16:06:53 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-15 16:06:53 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-15 16:06:53 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-15 16:06:53 --> File loaded: /var/www/html/project/radio/application/views/tracks/index.php
INFO - 2018-02-15 16:06:53 --> Final output sent to browser
DEBUG - 2018-02-15 16:06:53 --> Total execution time: 0.0043
INFO - 2018-02-15 16:06:53 --> Config Class Initialized
INFO - 2018-02-15 16:06:53 --> Hooks Class Initialized
DEBUG - 2018-02-15 16:06:53 --> UTF-8 Support Enabled
INFO - 2018-02-15 16:06:53 --> Utf8 Class Initialized
INFO - 2018-02-15 16:06:53 --> URI Class Initialized
INFO - 2018-02-15 16:06:53 --> Router Class Initialized
INFO - 2018-02-15 16:06:53 --> Output Class Initialized
INFO - 2018-02-15 16:06:53 --> Security Class Initialized
DEBUG - 2018-02-15 16:06:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 16:06:53 --> Input Class Initialized
INFO - 2018-02-15 16:06:53 --> Language Class Initialized
INFO - 2018-02-15 16:06:53 --> Loader Class Initialized
INFO - 2018-02-15 16:06:53 --> Helper loaded: url_helper
INFO - 2018-02-15 16:06:53 --> Helper loaded: file_helper
INFO - 2018-02-15 16:06:53 --> Helper loaded: email_helper
INFO - 2018-02-15 16:06:53 --> Helper loaded: common_helper
INFO - 2018-02-15 16:06:53 --> Database Driver Class Initialized
DEBUG - 2018-02-15 16:06:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 16:06:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 16:06:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 16:06:53 --> Pagination Class Initialized
INFO - 2018-02-15 16:06:53 --> Helper loaded: form_helper
INFO - 2018-02-15 16:06:53 --> Form Validation Class Initialized
INFO - 2018-02-15 16:06:53 --> Model Class Initialized
INFO - 2018-02-15 16:06:53 --> Controller Class Initialized
INFO - 2018-02-15 16:06:53 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 16:06:53 --> Model Class Initialized
INFO - 2018-02-15 16:06:53 --> Model Class Initialized
INFO - 2018-02-15 16:06:53 --> Model Class Initialized
INFO - 2018-02-15 16:06:53 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-15 16:06:53 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-15 16:06:53 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-15 16:06:53 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-15 16:06:53 --> File loaded: /var/www/html/project/radio/application/views/tracks/index.php
INFO - 2018-02-15 16:06:53 --> Final output sent to browser
DEBUG - 2018-02-15 16:06:53 --> Total execution time: 0.0039
INFO - 2018-02-15 16:06:53 --> Config Class Initialized
INFO - 2018-02-15 16:06:53 --> Hooks Class Initialized
DEBUG - 2018-02-15 16:06:53 --> UTF-8 Support Enabled
INFO - 2018-02-15 16:06:53 --> Utf8 Class Initialized
INFO - 2018-02-15 16:06:53 --> URI Class Initialized
INFO - 2018-02-15 16:06:53 --> Router Class Initialized
INFO - 2018-02-15 16:06:53 --> Output Class Initialized
INFO - 2018-02-15 16:06:53 --> Security Class Initialized
DEBUG - 2018-02-15 16:06:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 16:06:53 --> Input Class Initialized
INFO - 2018-02-15 16:06:53 --> Language Class Initialized
INFO - 2018-02-15 16:06:53 --> Loader Class Initialized
INFO - 2018-02-15 16:06:53 --> Helper loaded: url_helper
INFO - 2018-02-15 16:06:53 --> Helper loaded: file_helper
INFO - 2018-02-15 16:06:53 --> Helper loaded: email_helper
INFO - 2018-02-15 16:06:53 --> Helper loaded: common_helper
INFO - 2018-02-15 16:06:53 --> Database Driver Class Initialized
DEBUG - 2018-02-15 16:06:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 16:06:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 16:06:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 16:06:53 --> Pagination Class Initialized
INFO - 2018-02-15 16:06:53 --> Helper loaded: form_helper
INFO - 2018-02-15 16:06:53 --> Form Validation Class Initialized
INFO - 2018-02-15 16:06:53 --> Model Class Initialized
INFO - 2018-02-15 16:06:53 --> Controller Class Initialized
INFO - 2018-02-15 16:06:53 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 16:06:53 --> Model Class Initialized
INFO - 2018-02-15 16:06:53 --> Model Class Initialized
INFO - 2018-02-15 16:06:53 --> Model Class Initialized
INFO - 2018-02-15 16:06:53 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-15 16:06:53 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-15 16:06:53 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-15 16:06:53 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-15 16:06:53 --> File loaded: /var/www/html/project/radio/application/views/tracks/index.php
INFO - 2018-02-15 16:06:53 --> Final output sent to browser
DEBUG - 2018-02-15 16:06:53 --> Total execution time: 0.0044
INFO - 2018-02-15 16:06:54 --> Config Class Initialized
INFO - 2018-02-15 16:06:54 --> Hooks Class Initialized
DEBUG - 2018-02-15 16:06:54 --> UTF-8 Support Enabled
INFO - 2018-02-15 16:06:54 --> Utf8 Class Initialized
INFO - 2018-02-15 16:06:54 --> URI Class Initialized
INFO - 2018-02-15 16:06:54 --> Router Class Initialized
INFO - 2018-02-15 16:06:54 --> Output Class Initialized
INFO - 2018-02-15 16:06:54 --> Security Class Initialized
DEBUG - 2018-02-15 16:06:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 16:06:54 --> Input Class Initialized
INFO - 2018-02-15 16:06:54 --> Language Class Initialized
INFO - 2018-02-15 16:06:54 --> Loader Class Initialized
INFO - 2018-02-15 16:06:54 --> Helper loaded: url_helper
INFO - 2018-02-15 16:06:54 --> Helper loaded: file_helper
INFO - 2018-02-15 16:06:54 --> Helper loaded: email_helper
INFO - 2018-02-15 16:06:54 --> Helper loaded: common_helper
INFO - 2018-02-15 16:06:54 --> Database Driver Class Initialized
DEBUG - 2018-02-15 16:06:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 16:06:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 16:06:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 16:06:54 --> Pagination Class Initialized
INFO - 2018-02-15 16:06:54 --> Helper loaded: form_helper
INFO - 2018-02-15 16:06:54 --> Form Validation Class Initialized
INFO - 2018-02-15 16:06:54 --> Model Class Initialized
INFO - 2018-02-15 16:06:54 --> Controller Class Initialized
INFO - 2018-02-15 16:06:54 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 16:06:54 --> Model Class Initialized
INFO - 2018-02-15 16:06:54 --> Model Class Initialized
INFO - 2018-02-15 16:06:54 --> Model Class Initialized
INFO - 2018-02-15 16:06:54 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-15 16:06:54 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-15 16:06:54 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-15 16:06:54 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-15 16:06:54 --> File loaded: /var/www/html/project/radio/application/views/tracks/index.php
INFO - 2018-02-15 16:06:54 --> Final output sent to browser
DEBUG - 2018-02-15 16:06:54 --> Total execution time: 0.0042
INFO - 2018-02-15 16:06:54 --> Config Class Initialized
INFO - 2018-02-15 16:06:54 --> Hooks Class Initialized
DEBUG - 2018-02-15 16:06:54 --> UTF-8 Support Enabled
INFO - 2018-02-15 16:06:54 --> Utf8 Class Initialized
INFO - 2018-02-15 16:06:54 --> URI Class Initialized
INFO - 2018-02-15 16:06:54 --> Router Class Initialized
INFO - 2018-02-15 16:06:54 --> Output Class Initialized
INFO - 2018-02-15 16:06:54 --> Security Class Initialized
DEBUG - 2018-02-15 16:06:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 16:06:54 --> Input Class Initialized
INFO - 2018-02-15 16:06:54 --> Language Class Initialized
INFO - 2018-02-15 16:06:54 --> Loader Class Initialized
INFO - 2018-02-15 16:06:54 --> Helper loaded: url_helper
INFO - 2018-02-15 16:06:54 --> Helper loaded: file_helper
INFO - 2018-02-15 16:06:54 --> Helper loaded: email_helper
INFO - 2018-02-15 16:06:54 --> Helper loaded: common_helper
INFO - 2018-02-15 16:06:54 --> Database Driver Class Initialized
DEBUG - 2018-02-15 16:06:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 16:06:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 16:06:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 16:06:54 --> Pagination Class Initialized
INFO - 2018-02-15 16:06:54 --> Helper loaded: form_helper
INFO - 2018-02-15 16:06:54 --> Form Validation Class Initialized
INFO - 2018-02-15 16:06:54 --> Model Class Initialized
INFO - 2018-02-15 16:06:54 --> Controller Class Initialized
INFO - 2018-02-15 16:06:54 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 16:06:54 --> Model Class Initialized
INFO - 2018-02-15 16:06:54 --> Model Class Initialized
INFO - 2018-02-15 16:06:54 --> Model Class Initialized
INFO - 2018-02-15 16:06:54 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-15 16:06:54 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-15 16:06:54 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-15 16:06:54 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-15 16:06:54 --> File loaded: /var/www/html/project/radio/application/views/tracks/index.php
INFO - 2018-02-15 16:06:54 --> Final output sent to browser
DEBUG - 2018-02-15 16:06:54 --> Total execution time: 0.0046
INFO - 2018-02-15 16:06:54 --> Config Class Initialized
INFO - 2018-02-15 16:06:54 --> Hooks Class Initialized
DEBUG - 2018-02-15 16:06:54 --> UTF-8 Support Enabled
INFO - 2018-02-15 16:06:54 --> Utf8 Class Initialized
INFO - 2018-02-15 16:06:54 --> URI Class Initialized
INFO - 2018-02-15 16:06:54 --> Router Class Initialized
INFO - 2018-02-15 16:06:54 --> Output Class Initialized
INFO - 2018-02-15 16:06:54 --> Security Class Initialized
DEBUG - 2018-02-15 16:06:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 16:06:54 --> Input Class Initialized
INFO - 2018-02-15 16:06:54 --> Language Class Initialized
INFO - 2018-02-15 16:06:54 --> Loader Class Initialized
INFO - 2018-02-15 16:06:54 --> Helper loaded: url_helper
INFO - 2018-02-15 16:06:54 --> Helper loaded: file_helper
INFO - 2018-02-15 16:06:54 --> Helper loaded: email_helper
INFO - 2018-02-15 16:06:54 --> Helper loaded: common_helper
INFO - 2018-02-15 16:06:54 --> Database Driver Class Initialized
DEBUG - 2018-02-15 16:06:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 16:06:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 16:06:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 16:06:54 --> Pagination Class Initialized
INFO - 2018-02-15 16:06:54 --> Helper loaded: form_helper
INFO - 2018-02-15 16:06:54 --> Form Validation Class Initialized
INFO - 2018-02-15 16:06:54 --> Model Class Initialized
INFO - 2018-02-15 16:06:54 --> Controller Class Initialized
INFO - 2018-02-15 16:06:54 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 16:06:54 --> Model Class Initialized
INFO - 2018-02-15 16:06:54 --> Model Class Initialized
INFO - 2018-02-15 16:06:54 --> Model Class Initialized
INFO - 2018-02-15 16:06:54 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-15 16:06:54 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-15 16:06:54 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-15 16:06:54 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-15 16:06:54 --> File loaded: /var/www/html/project/radio/application/views/tracks/index.php
INFO - 2018-02-15 16:06:54 --> Final output sent to browser
DEBUG - 2018-02-15 16:06:54 --> Total execution time: 0.0043
INFO - 2018-02-15 16:06:54 --> Config Class Initialized
INFO - 2018-02-15 16:06:54 --> Hooks Class Initialized
DEBUG - 2018-02-15 16:06:54 --> UTF-8 Support Enabled
INFO - 2018-02-15 16:06:54 --> Utf8 Class Initialized
INFO - 2018-02-15 16:06:54 --> URI Class Initialized
INFO - 2018-02-15 16:06:54 --> Router Class Initialized
INFO - 2018-02-15 16:06:54 --> Output Class Initialized
INFO - 2018-02-15 16:06:54 --> Security Class Initialized
DEBUG - 2018-02-15 16:06:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 16:06:54 --> Input Class Initialized
INFO - 2018-02-15 16:06:54 --> Language Class Initialized
INFO - 2018-02-15 16:06:54 --> Loader Class Initialized
INFO - 2018-02-15 16:06:54 --> Helper loaded: url_helper
INFO - 2018-02-15 16:06:54 --> Helper loaded: file_helper
INFO - 2018-02-15 16:06:54 --> Helper loaded: email_helper
INFO - 2018-02-15 16:06:54 --> Helper loaded: common_helper
INFO - 2018-02-15 16:06:54 --> Database Driver Class Initialized
DEBUG - 2018-02-15 16:06:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 16:06:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 16:06:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 16:06:54 --> Pagination Class Initialized
INFO - 2018-02-15 16:06:54 --> Helper loaded: form_helper
INFO - 2018-02-15 16:06:54 --> Form Validation Class Initialized
INFO - 2018-02-15 16:06:54 --> Model Class Initialized
INFO - 2018-02-15 16:06:54 --> Controller Class Initialized
INFO - 2018-02-15 16:06:54 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 16:06:54 --> Model Class Initialized
INFO - 2018-02-15 16:06:54 --> Model Class Initialized
INFO - 2018-02-15 16:06:54 --> Model Class Initialized
INFO - 2018-02-15 16:06:54 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-15 16:06:54 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-15 16:06:54 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-15 16:06:54 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-15 16:06:54 --> File loaded: /var/www/html/project/radio/application/views/tracks/index.php
INFO - 2018-02-15 16:06:54 --> Final output sent to browser
DEBUG - 2018-02-15 16:06:54 --> Total execution time: 0.0042
INFO - 2018-02-15 16:06:54 --> Config Class Initialized
INFO - 2018-02-15 16:06:54 --> Hooks Class Initialized
DEBUG - 2018-02-15 16:06:54 --> UTF-8 Support Enabled
INFO - 2018-02-15 16:06:54 --> Utf8 Class Initialized
INFO - 2018-02-15 16:06:54 --> URI Class Initialized
INFO - 2018-02-15 16:06:54 --> Router Class Initialized
INFO - 2018-02-15 16:06:54 --> Output Class Initialized
INFO - 2018-02-15 16:06:54 --> Security Class Initialized
DEBUG - 2018-02-15 16:06:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 16:06:54 --> Input Class Initialized
INFO - 2018-02-15 16:06:54 --> Language Class Initialized
INFO - 2018-02-15 16:06:54 --> Loader Class Initialized
INFO - 2018-02-15 16:06:54 --> Helper loaded: url_helper
INFO - 2018-02-15 16:06:54 --> Helper loaded: file_helper
INFO - 2018-02-15 16:06:54 --> Helper loaded: email_helper
INFO - 2018-02-15 16:06:54 --> Helper loaded: common_helper
INFO - 2018-02-15 16:06:54 --> Database Driver Class Initialized
DEBUG - 2018-02-15 16:06:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 16:06:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 16:06:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 16:06:54 --> Pagination Class Initialized
INFO - 2018-02-15 16:06:54 --> Helper loaded: form_helper
INFO - 2018-02-15 16:06:54 --> Form Validation Class Initialized
INFO - 2018-02-15 16:06:54 --> Model Class Initialized
INFO - 2018-02-15 16:06:54 --> Controller Class Initialized
INFO - 2018-02-15 16:06:54 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 16:06:54 --> Model Class Initialized
INFO - 2018-02-15 16:06:54 --> Model Class Initialized
INFO - 2018-02-15 16:06:54 --> Model Class Initialized
INFO - 2018-02-15 16:06:54 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-15 16:06:54 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-15 16:06:54 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-15 16:06:54 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-15 16:06:54 --> File loaded: /var/www/html/project/radio/application/views/tracks/index.php
INFO - 2018-02-15 16:06:54 --> Final output sent to browser
DEBUG - 2018-02-15 16:06:54 --> Total execution time: 0.0051
INFO - 2018-02-15 16:06:54 --> Config Class Initialized
INFO - 2018-02-15 16:06:54 --> Hooks Class Initialized
DEBUG - 2018-02-15 16:06:54 --> UTF-8 Support Enabled
INFO - 2018-02-15 16:06:54 --> Utf8 Class Initialized
INFO - 2018-02-15 16:06:54 --> URI Class Initialized
INFO - 2018-02-15 16:06:54 --> Router Class Initialized
INFO - 2018-02-15 16:06:54 --> Output Class Initialized
INFO - 2018-02-15 16:06:54 --> Security Class Initialized
DEBUG - 2018-02-15 16:06:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 16:06:54 --> Input Class Initialized
INFO - 2018-02-15 16:06:54 --> Language Class Initialized
INFO - 2018-02-15 16:06:54 --> Loader Class Initialized
INFO - 2018-02-15 16:06:54 --> Helper loaded: url_helper
INFO - 2018-02-15 16:06:54 --> Helper loaded: file_helper
INFO - 2018-02-15 16:06:54 --> Helper loaded: email_helper
INFO - 2018-02-15 16:06:54 --> Helper loaded: common_helper
INFO - 2018-02-15 16:06:54 --> Database Driver Class Initialized
DEBUG - 2018-02-15 16:06:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 16:06:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 16:06:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 16:06:54 --> Pagination Class Initialized
INFO - 2018-02-15 16:06:54 --> Helper loaded: form_helper
INFO - 2018-02-15 16:06:54 --> Form Validation Class Initialized
INFO - 2018-02-15 16:06:54 --> Model Class Initialized
INFO - 2018-02-15 16:06:54 --> Controller Class Initialized
INFO - 2018-02-15 16:06:54 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 16:06:54 --> Model Class Initialized
INFO - 2018-02-15 16:06:54 --> Model Class Initialized
INFO - 2018-02-15 16:06:54 --> Model Class Initialized
INFO - 2018-02-15 16:06:54 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-15 16:06:54 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-15 16:06:54 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-15 16:06:54 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-15 16:06:54 --> File loaded: /var/www/html/project/radio/application/views/tracks/index.php
INFO - 2018-02-15 16:06:54 --> Final output sent to browser
DEBUG - 2018-02-15 16:06:54 --> Total execution time: 0.0055
INFO - 2018-02-15 16:06:54 --> Config Class Initialized
INFO - 2018-02-15 16:06:54 --> Hooks Class Initialized
DEBUG - 2018-02-15 16:06:54 --> UTF-8 Support Enabled
INFO - 2018-02-15 16:06:54 --> Utf8 Class Initialized
INFO - 2018-02-15 16:06:54 --> URI Class Initialized
INFO - 2018-02-15 16:06:54 --> Router Class Initialized
INFO - 2018-02-15 16:06:54 --> Output Class Initialized
INFO - 2018-02-15 16:06:54 --> Security Class Initialized
DEBUG - 2018-02-15 16:06:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 16:06:54 --> Input Class Initialized
INFO - 2018-02-15 16:06:54 --> Language Class Initialized
INFO - 2018-02-15 16:06:54 --> Loader Class Initialized
INFO - 2018-02-15 16:06:54 --> Helper loaded: url_helper
INFO - 2018-02-15 16:06:54 --> Helper loaded: file_helper
INFO - 2018-02-15 16:06:54 --> Helper loaded: email_helper
INFO - 2018-02-15 16:06:54 --> Helper loaded: common_helper
INFO - 2018-02-15 16:06:54 --> Database Driver Class Initialized
DEBUG - 2018-02-15 16:06:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 16:06:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 16:06:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 16:06:54 --> Pagination Class Initialized
INFO - 2018-02-15 16:06:54 --> Helper loaded: form_helper
INFO - 2018-02-15 16:06:54 --> Form Validation Class Initialized
INFO - 2018-02-15 16:06:54 --> Model Class Initialized
INFO - 2018-02-15 16:06:54 --> Controller Class Initialized
INFO - 2018-02-15 16:06:54 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 16:06:54 --> Model Class Initialized
INFO - 2018-02-15 16:06:54 --> Model Class Initialized
INFO - 2018-02-15 16:06:54 --> Model Class Initialized
INFO - 2018-02-15 16:06:54 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-15 16:06:54 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-15 16:06:54 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-15 16:06:54 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-15 16:06:54 --> File loaded: /var/www/html/project/radio/application/views/tracks/index.php
INFO - 2018-02-15 16:06:54 --> Final output sent to browser
DEBUG - 2018-02-15 16:06:54 --> Total execution time: 0.0041
INFO - 2018-02-15 16:06:54 --> Config Class Initialized
INFO - 2018-02-15 16:06:54 --> Hooks Class Initialized
DEBUG - 2018-02-15 16:06:54 --> UTF-8 Support Enabled
INFO - 2018-02-15 16:06:54 --> Utf8 Class Initialized
INFO - 2018-02-15 16:06:54 --> URI Class Initialized
INFO - 2018-02-15 16:06:54 --> Router Class Initialized
INFO - 2018-02-15 16:06:54 --> Output Class Initialized
INFO - 2018-02-15 16:06:54 --> Security Class Initialized
DEBUG - 2018-02-15 16:06:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 16:06:54 --> Input Class Initialized
INFO - 2018-02-15 16:06:54 --> Language Class Initialized
INFO - 2018-02-15 16:06:54 --> Loader Class Initialized
INFO - 2018-02-15 16:06:54 --> Helper loaded: url_helper
INFO - 2018-02-15 16:06:54 --> Helper loaded: file_helper
INFO - 2018-02-15 16:06:54 --> Helper loaded: email_helper
INFO - 2018-02-15 16:06:54 --> Helper loaded: common_helper
INFO - 2018-02-15 16:06:54 --> Database Driver Class Initialized
DEBUG - 2018-02-15 16:06:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 16:06:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 16:06:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 16:06:54 --> Pagination Class Initialized
INFO - 2018-02-15 16:06:54 --> Helper loaded: form_helper
INFO - 2018-02-15 16:06:54 --> Form Validation Class Initialized
INFO - 2018-02-15 16:06:54 --> Model Class Initialized
INFO - 2018-02-15 16:06:54 --> Controller Class Initialized
INFO - 2018-02-15 16:06:54 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 16:06:54 --> Model Class Initialized
INFO - 2018-02-15 16:06:54 --> Model Class Initialized
INFO - 2018-02-15 16:06:54 --> Model Class Initialized
INFO - 2018-02-15 16:06:54 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-15 16:06:54 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-15 16:06:54 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-15 16:06:54 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-15 16:06:54 --> File loaded: /var/www/html/project/radio/application/views/tracks/index.php
INFO - 2018-02-15 16:06:54 --> Final output sent to browser
DEBUG - 2018-02-15 16:06:54 --> Total execution time: 0.0040
INFO - 2018-02-15 16:06:54 --> Config Class Initialized
INFO - 2018-02-15 16:06:54 --> Hooks Class Initialized
DEBUG - 2018-02-15 16:06:54 --> UTF-8 Support Enabled
INFO - 2018-02-15 16:06:54 --> Utf8 Class Initialized
INFO - 2018-02-15 16:06:54 --> URI Class Initialized
INFO - 2018-02-15 16:06:54 --> Router Class Initialized
INFO - 2018-02-15 16:06:54 --> Output Class Initialized
INFO - 2018-02-15 16:06:54 --> Security Class Initialized
DEBUG - 2018-02-15 16:06:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 16:06:54 --> Input Class Initialized
INFO - 2018-02-15 16:06:54 --> Language Class Initialized
INFO - 2018-02-15 16:06:54 --> Loader Class Initialized
INFO - 2018-02-15 16:06:54 --> Helper loaded: url_helper
INFO - 2018-02-15 16:06:54 --> Helper loaded: file_helper
INFO - 2018-02-15 16:06:54 --> Helper loaded: email_helper
INFO - 2018-02-15 16:06:54 --> Helper loaded: common_helper
INFO - 2018-02-15 16:06:54 --> Database Driver Class Initialized
DEBUG - 2018-02-15 16:06:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 16:06:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 16:06:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 16:06:54 --> Pagination Class Initialized
INFO - 2018-02-15 16:06:54 --> Helper loaded: form_helper
INFO - 2018-02-15 16:06:54 --> Form Validation Class Initialized
INFO - 2018-02-15 16:06:54 --> Model Class Initialized
INFO - 2018-02-15 16:06:54 --> Controller Class Initialized
INFO - 2018-02-15 16:06:54 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 16:06:54 --> Model Class Initialized
INFO - 2018-02-15 16:06:54 --> Model Class Initialized
INFO - 2018-02-15 16:06:54 --> Model Class Initialized
INFO - 2018-02-15 16:06:54 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-15 16:06:54 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-15 16:06:54 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-15 16:06:54 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-15 16:06:54 --> File loaded: /var/www/html/project/radio/application/views/tracks/index.php
INFO - 2018-02-15 16:06:54 --> Final output sent to browser
DEBUG - 2018-02-15 16:06:54 --> Total execution time: 0.0043
INFO - 2018-02-15 16:06:54 --> Config Class Initialized
INFO - 2018-02-15 16:06:54 --> Hooks Class Initialized
DEBUG - 2018-02-15 16:06:54 --> UTF-8 Support Enabled
INFO - 2018-02-15 16:06:54 --> Utf8 Class Initialized
INFO - 2018-02-15 16:06:54 --> URI Class Initialized
INFO - 2018-02-15 16:06:54 --> Router Class Initialized
INFO - 2018-02-15 16:06:54 --> Output Class Initialized
INFO - 2018-02-15 16:06:54 --> Security Class Initialized
DEBUG - 2018-02-15 16:06:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 16:06:54 --> Input Class Initialized
INFO - 2018-02-15 16:06:54 --> Language Class Initialized
INFO - 2018-02-15 16:06:54 --> Loader Class Initialized
INFO - 2018-02-15 16:06:54 --> Helper loaded: url_helper
INFO - 2018-02-15 16:06:54 --> Helper loaded: file_helper
INFO - 2018-02-15 16:06:54 --> Helper loaded: email_helper
INFO - 2018-02-15 16:06:54 --> Helper loaded: common_helper
INFO - 2018-02-15 16:06:54 --> Database Driver Class Initialized
DEBUG - 2018-02-15 16:06:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 16:06:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 16:06:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 16:06:54 --> Pagination Class Initialized
INFO - 2018-02-15 16:06:54 --> Helper loaded: form_helper
INFO - 2018-02-15 16:06:54 --> Form Validation Class Initialized
INFO - 2018-02-15 16:06:54 --> Model Class Initialized
INFO - 2018-02-15 16:06:54 --> Controller Class Initialized
INFO - 2018-02-15 16:06:54 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 16:06:54 --> Model Class Initialized
INFO - 2018-02-15 16:06:54 --> Model Class Initialized
INFO - 2018-02-15 16:06:54 --> Model Class Initialized
INFO - 2018-02-15 16:06:54 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-15 16:06:54 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-15 16:06:54 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-15 16:06:54 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-15 16:06:54 --> File loaded: /var/www/html/project/radio/application/views/tracks/index.php
INFO - 2018-02-15 16:06:54 --> Final output sent to browser
DEBUG - 2018-02-15 16:06:54 --> Total execution time: 0.0046
INFO - 2018-02-15 16:06:54 --> Config Class Initialized
INFO - 2018-02-15 16:06:54 --> Hooks Class Initialized
DEBUG - 2018-02-15 16:06:54 --> UTF-8 Support Enabled
INFO - 2018-02-15 16:06:54 --> Utf8 Class Initialized
INFO - 2018-02-15 16:06:54 --> URI Class Initialized
INFO - 2018-02-15 16:06:54 --> Router Class Initialized
INFO - 2018-02-15 16:06:54 --> Output Class Initialized
INFO - 2018-02-15 16:06:54 --> Security Class Initialized
DEBUG - 2018-02-15 16:06:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 16:06:54 --> Input Class Initialized
INFO - 2018-02-15 16:06:54 --> Language Class Initialized
INFO - 2018-02-15 16:06:54 --> Loader Class Initialized
INFO - 2018-02-15 16:06:54 --> Helper loaded: url_helper
INFO - 2018-02-15 16:06:54 --> Helper loaded: file_helper
INFO - 2018-02-15 16:06:54 --> Helper loaded: email_helper
INFO - 2018-02-15 16:06:54 --> Helper loaded: common_helper
INFO - 2018-02-15 16:06:54 --> Database Driver Class Initialized
DEBUG - 2018-02-15 16:06:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 16:06:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 16:06:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 16:06:54 --> Pagination Class Initialized
INFO - 2018-02-15 16:06:54 --> Helper loaded: form_helper
INFO - 2018-02-15 16:06:54 --> Form Validation Class Initialized
INFO - 2018-02-15 16:06:54 --> Model Class Initialized
INFO - 2018-02-15 16:06:54 --> Controller Class Initialized
INFO - 2018-02-15 16:06:54 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 16:06:54 --> Model Class Initialized
INFO - 2018-02-15 16:06:54 --> Model Class Initialized
INFO - 2018-02-15 16:06:54 --> Model Class Initialized
INFO - 2018-02-15 16:06:54 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-15 16:06:54 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-15 16:06:54 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-15 16:06:54 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-15 16:06:54 --> File loaded: /var/www/html/project/radio/application/views/tracks/index.php
INFO - 2018-02-15 16:06:54 --> Final output sent to browser
DEBUG - 2018-02-15 16:06:54 --> Total execution time: 0.0048
INFO - 2018-02-15 16:06:54 --> Config Class Initialized
INFO - 2018-02-15 16:06:54 --> Hooks Class Initialized
DEBUG - 2018-02-15 16:06:54 --> UTF-8 Support Enabled
INFO - 2018-02-15 16:06:54 --> Utf8 Class Initialized
INFO - 2018-02-15 16:06:54 --> URI Class Initialized
INFO - 2018-02-15 16:06:54 --> Router Class Initialized
INFO - 2018-02-15 16:06:54 --> Output Class Initialized
INFO - 2018-02-15 16:06:54 --> Security Class Initialized
DEBUG - 2018-02-15 16:06:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 16:06:54 --> Input Class Initialized
INFO - 2018-02-15 16:06:54 --> Language Class Initialized
INFO - 2018-02-15 16:06:54 --> Loader Class Initialized
INFO - 2018-02-15 16:06:54 --> Helper loaded: url_helper
INFO - 2018-02-15 16:06:54 --> Helper loaded: file_helper
INFO - 2018-02-15 16:06:54 --> Helper loaded: email_helper
INFO - 2018-02-15 16:06:54 --> Helper loaded: common_helper
INFO - 2018-02-15 16:06:54 --> Database Driver Class Initialized
DEBUG - 2018-02-15 16:06:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 16:06:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 16:06:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 16:06:54 --> Pagination Class Initialized
INFO - 2018-02-15 16:06:54 --> Helper loaded: form_helper
INFO - 2018-02-15 16:06:54 --> Form Validation Class Initialized
INFO - 2018-02-15 16:06:54 --> Model Class Initialized
INFO - 2018-02-15 16:06:54 --> Controller Class Initialized
INFO - 2018-02-15 16:06:54 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 16:06:54 --> Model Class Initialized
INFO - 2018-02-15 16:06:54 --> Model Class Initialized
INFO - 2018-02-15 16:06:54 --> Model Class Initialized
INFO - 2018-02-15 16:06:54 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-15 16:06:54 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-15 16:06:54 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-15 16:06:54 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-15 16:06:54 --> File loaded: /var/www/html/project/radio/application/views/tracks/index.php
INFO - 2018-02-15 16:06:54 --> Final output sent to browser
DEBUG - 2018-02-15 16:06:54 --> Total execution time: 0.0041
INFO - 2018-02-15 16:06:54 --> Config Class Initialized
INFO - 2018-02-15 16:06:54 --> Hooks Class Initialized
DEBUG - 2018-02-15 16:06:54 --> UTF-8 Support Enabled
INFO - 2018-02-15 16:06:54 --> Utf8 Class Initialized
INFO - 2018-02-15 16:06:54 --> URI Class Initialized
INFO - 2018-02-15 16:06:54 --> Router Class Initialized
INFO - 2018-02-15 16:06:54 --> Output Class Initialized
INFO - 2018-02-15 16:06:54 --> Security Class Initialized
DEBUG - 2018-02-15 16:06:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 16:06:54 --> Input Class Initialized
INFO - 2018-02-15 16:06:54 --> Language Class Initialized
INFO - 2018-02-15 16:06:54 --> Loader Class Initialized
INFO - 2018-02-15 16:06:54 --> Helper loaded: url_helper
INFO - 2018-02-15 16:06:54 --> Helper loaded: file_helper
INFO - 2018-02-15 16:06:54 --> Helper loaded: email_helper
INFO - 2018-02-15 16:06:54 --> Helper loaded: common_helper
INFO - 2018-02-15 16:06:54 --> Database Driver Class Initialized
DEBUG - 2018-02-15 16:06:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 16:06:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 16:06:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 16:06:54 --> Pagination Class Initialized
INFO - 2018-02-15 16:06:54 --> Helper loaded: form_helper
INFO - 2018-02-15 16:06:54 --> Form Validation Class Initialized
INFO - 2018-02-15 16:06:54 --> Model Class Initialized
INFO - 2018-02-15 16:06:54 --> Controller Class Initialized
INFO - 2018-02-15 16:06:54 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 16:06:54 --> Model Class Initialized
INFO - 2018-02-15 16:06:54 --> Model Class Initialized
INFO - 2018-02-15 16:06:54 --> Model Class Initialized
INFO - 2018-02-15 16:06:54 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-15 16:06:54 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-15 16:06:54 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-15 16:06:54 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-15 16:06:54 --> File loaded: /var/www/html/project/radio/application/views/tracks/index.php
INFO - 2018-02-15 16:06:54 --> Final output sent to browser
DEBUG - 2018-02-15 16:06:54 --> Total execution time: 0.0050
INFO - 2018-02-15 16:06:54 --> Config Class Initialized
INFO - 2018-02-15 16:06:54 --> Hooks Class Initialized
DEBUG - 2018-02-15 16:06:54 --> UTF-8 Support Enabled
INFO - 2018-02-15 16:06:54 --> Utf8 Class Initialized
INFO - 2018-02-15 16:06:54 --> URI Class Initialized
INFO - 2018-02-15 16:06:54 --> Router Class Initialized
INFO - 2018-02-15 16:06:54 --> Output Class Initialized
INFO - 2018-02-15 16:06:54 --> Security Class Initialized
DEBUG - 2018-02-15 16:06:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 16:06:54 --> Input Class Initialized
INFO - 2018-02-15 16:06:54 --> Language Class Initialized
INFO - 2018-02-15 16:06:54 --> Loader Class Initialized
INFO - 2018-02-15 16:06:54 --> Helper loaded: url_helper
INFO - 2018-02-15 16:06:54 --> Helper loaded: file_helper
INFO - 2018-02-15 16:06:54 --> Helper loaded: email_helper
INFO - 2018-02-15 16:06:54 --> Helper loaded: common_helper
INFO - 2018-02-15 16:06:54 --> Database Driver Class Initialized
DEBUG - 2018-02-15 16:06:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 16:06:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 16:06:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 16:06:54 --> Pagination Class Initialized
INFO - 2018-02-15 16:06:54 --> Helper loaded: form_helper
INFO - 2018-02-15 16:06:54 --> Form Validation Class Initialized
INFO - 2018-02-15 16:06:54 --> Model Class Initialized
INFO - 2018-02-15 16:06:54 --> Controller Class Initialized
INFO - 2018-02-15 16:06:54 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 16:06:54 --> Model Class Initialized
INFO - 2018-02-15 16:06:54 --> Model Class Initialized
INFO - 2018-02-15 16:06:54 --> Model Class Initialized
INFO - 2018-02-15 16:06:54 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-15 16:06:54 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-15 16:06:54 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-15 16:06:54 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-15 16:06:54 --> File loaded: /var/www/html/project/radio/application/views/tracks/index.php
INFO - 2018-02-15 16:06:54 --> Final output sent to browser
DEBUG - 2018-02-15 16:06:54 --> Total execution time: 0.0049
INFO - 2018-02-15 16:06:54 --> Config Class Initialized
INFO - 2018-02-15 16:06:54 --> Hooks Class Initialized
DEBUG - 2018-02-15 16:06:54 --> UTF-8 Support Enabled
INFO - 2018-02-15 16:06:54 --> Utf8 Class Initialized
INFO - 2018-02-15 16:06:54 --> URI Class Initialized
INFO - 2018-02-15 16:06:54 --> Router Class Initialized
INFO - 2018-02-15 16:06:54 --> Output Class Initialized
INFO - 2018-02-15 16:06:54 --> Security Class Initialized
DEBUG - 2018-02-15 16:06:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 16:06:54 --> Input Class Initialized
INFO - 2018-02-15 16:06:54 --> Language Class Initialized
INFO - 2018-02-15 16:06:54 --> Loader Class Initialized
INFO - 2018-02-15 16:06:54 --> Helper loaded: url_helper
INFO - 2018-02-15 16:06:54 --> Helper loaded: file_helper
INFO - 2018-02-15 16:06:54 --> Helper loaded: email_helper
INFO - 2018-02-15 16:06:54 --> Helper loaded: common_helper
INFO - 2018-02-15 16:06:54 --> Database Driver Class Initialized
DEBUG - 2018-02-15 16:06:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 16:06:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 16:06:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 16:06:54 --> Pagination Class Initialized
INFO - 2018-02-15 16:06:54 --> Helper loaded: form_helper
INFO - 2018-02-15 16:06:54 --> Form Validation Class Initialized
INFO - 2018-02-15 16:06:54 --> Model Class Initialized
INFO - 2018-02-15 16:06:54 --> Controller Class Initialized
INFO - 2018-02-15 16:06:54 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 16:06:54 --> Model Class Initialized
INFO - 2018-02-15 16:06:54 --> Model Class Initialized
INFO - 2018-02-15 16:06:54 --> Model Class Initialized
INFO - 2018-02-15 16:06:54 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-15 16:06:54 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-15 16:06:54 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-15 16:06:54 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-15 16:06:54 --> File loaded: /var/www/html/project/radio/application/views/tracks/index.php
INFO - 2018-02-15 16:06:54 --> Final output sent to browser
DEBUG - 2018-02-15 16:06:54 --> Total execution time: 0.0044
INFO - 2018-02-15 16:06:54 --> Config Class Initialized
INFO - 2018-02-15 16:06:54 --> Hooks Class Initialized
DEBUG - 2018-02-15 16:06:54 --> UTF-8 Support Enabled
INFO - 2018-02-15 16:06:54 --> Utf8 Class Initialized
INFO - 2018-02-15 16:06:54 --> URI Class Initialized
INFO - 2018-02-15 16:06:54 --> Router Class Initialized
INFO - 2018-02-15 16:06:54 --> Output Class Initialized
INFO - 2018-02-15 16:06:54 --> Security Class Initialized
DEBUG - 2018-02-15 16:06:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 16:06:54 --> Input Class Initialized
INFO - 2018-02-15 16:06:54 --> Language Class Initialized
INFO - 2018-02-15 16:06:54 --> Loader Class Initialized
INFO - 2018-02-15 16:06:54 --> Helper loaded: url_helper
INFO - 2018-02-15 16:06:54 --> Helper loaded: file_helper
INFO - 2018-02-15 16:06:54 --> Helper loaded: email_helper
INFO - 2018-02-15 16:06:54 --> Helper loaded: common_helper
INFO - 2018-02-15 16:06:54 --> Database Driver Class Initialized
DEBUG - 2018-02-15 16:06:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 16:06:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 16:06:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 16:06:54 --> Pagination Class Initialized
INFO - 2018-02-15 16:06:54 --> Helper loaded: form_helper
INFO - 2018-02-15 16:06:54 --> Form Validation Class Initialized
INFO - 2018-02-15 16:06:54 --> Model Class Initialized
INFO - 2018-02-15 16:06:54 --> Controller Class Initialized
INFO - 2018-02-15 16:06:54 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 16:06:54 --> Model Class Initialized
INFO - 2018-02-15 16:06:54 --> Model Class Initialized
INFO - 2018-02-15 16:06:54 --> Model Class Initialized
INFO - 2018-02-15 16:06:54 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-15 16:06:54 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-15 16:06:54 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-15 16:06:54 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-15 16:06:54 --> File loaded: /var/www/html/project/radio/application/views/tracks/index.php
INFO - 2018-02-15 16:06:54 --> Final output sent to browser
DEBUG - 2018-02-15 16:06:54 --> Total execution time: 0.0051
INFO - 2018-02-15 16:06:54 --> Config Class Initialized
INFO - 2018-02-15 16:06:54 --> Hooks Class Initialized
DEBUG - 2018-02-15 16:06:54 --> UTF-8 Support Enabled
INFO - 2018-02-15 16:06:54 --> Utf8 Class Initialized
INFO - 2018-02-15 16:06:54 --> URI Class Initialized
INFO - 2018-02-15 16:06:54 --> Router Class Initialized
INFO - 2018-02-15 16:06:54 --> Output Class Initialized
INFO - 2018-02-15 16:06:54 --> Security Class Initialized
DEBUG - 2018-02-15 16:06:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 16:06:54 --> Input Class Initialized
INFO - 2018-02-15 16:06:54 --> Language Class Initialized
INFO - 2018-02-15 16:06:54 --> Loader Class Initialized
INFO - 2018-02-15 16:06:54 --> Helper loaded: url_helper
INFO - 2018-02-15 16:06:54 --> Helper loaded: file_helper
INFO - 2018-02-15 16:06:54 --> Helper loaded: email_helper
INFO - 2018-02-15 16:06:54 --> Helper loaded: common_helper
INFO - 2018-02-15 16:06:54 --> Database Driver Class Initialized
DEBUG - 2018-02-15 16:06:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 16:06:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 16:06:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 16:06:54 --> Pagination Class Initialized
INFO - 2018-02-15 16:06:54 --> Helper loaded: form_helper
INFO - 2018-02-15 16:06:54 --> Form Validation Class Initialized
INFO - 2018-02-15 16:06:54 --> Model Class Initialized
INFO - 2018-02-15 16:06:54 --> Controller Class Initialized
INFO - 2018-02-15 16:06:54 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 16:06:54 --> Model Class Initialized
INFO - 2018-02-15 16:06:54 --> Model Class Initialized
INFO - 2018-02-15 16:06:54 --> Model Class Initialized
INFO - 2018-02-15 16:06:54 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-15 16:06:54 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-15 16:06:54 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-15 16:06:54 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-15 16:06:54 --> File loaded: /var/www/html/project/radio/application/views/tracks/index.php
INFO - 2018-02-15 16:06:54 --> Final output sent to browser
DEBUG - 2018-02-15 16:06:54 --> Total execution time: 0.0046
INFO - 2018-02-15 16:06:54 --> Config Class Initialized
INFO - 2018-02-15 16:06:54 --> Hooks Class Initialized
DEBUG - 2018-02-15 16:06:54 --> UTF-8 Support Enabled
INFO - 2018-02-15 16:06:54 --> Utf8 Class Initialized
INFO - 2018-02-15 16:06:54 --> URI Class Initialized
INFO - 2018-02-15 16:06:54 --> Router Class Initialized
INFO - 2018-02-15 16:06:54 --> Output Class Initialized
INFO - 2018-02-15 16:06:54 --> Security Class Initialized
DEBUG - 2018-02-15 16:06:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 16:06:54 --> Input Class Initialized
INFO - 2018-02-15 16:06:54 --> Language Class Initialized
INFO - 2018-02-15 16:06:54 --> Loader Class Initialized
INFO - 2018-02-15 16:06:54 --> Helper loaded: url_helper
INFO - 2018-02-15 16:06:54 --> Helper loaded: file_helper
INFO - 2018-02-15 16:06:54 --> Helper loaded: email_helper
INFO - 2018-02-15 16:06:54 --> Helper loaded: common_helper
INFO - 2018-02-15 16:06:54 --> Database Driver Class Initialized
DEBUG - 2018-02-15 16:06:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 16:06:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 16:06:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 16:06:54 --> Pagination Class Initialized
INFO - 2018-02-15 16:06:54 --> Helper loaded: form_helper
INFO - 2018-02-15 16:06:54 --> Form Validation Class Initialized
INFO - 2018-02-15 16:06:54 --> Model Class Initialized
INFO - 2018-02-15 16:06:54 --> Controller Class Initialized
INFO - 2018-02-15 16:06:54 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 16:06:54 --> Model Class Initialized
INFO - 2018-02-15 16:06:54 --> Model Class Initialized
INFO - 2018-02-15 16:06:54 --> Model Class Initialized
INFO - 2018-02-15 16:06:54 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-15 16:06:54 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-15 16:06:54 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-15 16:06:54 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-15 16:06:54 --> File loaded: /var/www/html/project/radio/application/views/tracks/index.php
INFO - 2018-02-15 16:06:54 --> Final output sent to browser
DEBUG - 2018-02-15 16:06:54 --> Total execution time: 0.0050
INFO - 2018-02-15 16:06:54 --> Config Class Initialized
INFO - 2018-02-15 16:06:54 --> Hooks Class Initialized
DEBUG - 2018-02-15 16:06:54 --> UTF-8 Support Enabled
INFO - 2018-02-15 16:06:54 --> Utf8 Class Initialized
INFO - 2018-02-15 16:06:54 --> URI Class Initialized
INFO - 2018-02-15 16:06:54 --> Router Class Initialized
INFO - 2018-02-15 16:06:54 --> Output Class Initialized
INFO - 2018-02-15 16:06:54 --> Security Class Initialized
DEBUG - 2018-02-15 16:06:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 16:06:54 --> Input Class Initialized
INFO - 2018-02-15 16:06:54 --> Language Class Initialized
INFO - 2018-02-15 16:06:54 --> Loader Class Initialized
INFO - 2018-02-15 16:06:54 --> Helper loaded: url_helper
INFO - 2018-02-15 16:06:54 --> Helper loaded: file_helper
INFO - 2018-02-15 16:06:54 --> Helper loaded: email_helper
INFO - 2018-02-15 16:06:54 --> Helper loaded: common_helper
INFO - 2018-02-15 16:06:54 --> Database Driver Class Initialized
DEBUG - 2018-02-15 16:06:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 16:06:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 16:06:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 16:06:54 --> Pagination Class Initialized
INFO - 2018-02-15 16:06:54 --> Helper loaded: form_helper
INFO - 2018-02-15 16:06:54 --> Form Validation Class Initialized
INFO - 2018-02-15 16:06:54 --> Model Class Initialized
INFO - 2018-02-15 16:06:54 --> Controller Class Initialized
INFO - 2018-02-15 16:06:54 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 16:06:54 --> Model Class Initialized
INFO - 2018-02-15 16:06:54 --> Model Class Initialized
INFO - 2018-02-15 16:06:54 --> Model Class Initialized
INFO - 2018-02-15 16:06:54 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-15 16:06:54 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-15 16:06:54 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-15 16:06:54 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-15 16:06:54 --> File loaded: /var/www/html/project/radio/application/views/tracks/index.php
INFO - 2018-02-15 16:06:54 --> Final output sent to browser
DEBUG - 2018-02-15 16:06:54 --> Total execution time: 0.0032
INFO - 2018-02-15 16:06:54 --> Config Class Initialized
INFO - 2018-02-15 16:06:54 --> Hooks Class Initialized
DEBUG - 2018-02-15 16:06:54 --> UTF-8 Support Enabled
INFO - 2018-02-15 16:06:54 --> Utf8 Class Initialized
INFO - 2018-02-15 16:06:54 --> URI Class Initialized
INFO - 2018-02-15 16:06:54 --> Router Class Initialized
INFO - 2018-02-15 16:06:54 --> Output Class Initialized
INFO - 2018-02-15 16:06:54 --> Security Class Initialized
DEBUG - 2018-02-15 16:06:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 16:06:54 --> Input Class Initialized
INFO - 2018-02-15 16:06:54 --> Language Class Initialized
INFO - 2018-02-15 16:06:54 --> Loader Class Initialized
INFO - 2018-02-15 16:06:54 --> Helper loaded: url_helper
INFO - 2018-02-15 16:06:54 --> Helper loaded: file_helper
INFO - 2018-02-15 16:06:54 --> Helper loaded: email_helper
INFO - 2018-02-15 16:06:54 --> Helper loaded: common_helper
INFO - 2018-02-15 16:06:54 --> Database Driver Class Initialized
DEBUG - 2018-02-15 16:06:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 16:06:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 16:06:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 16:06:54 --> Pagination Class Initialized
INFO - 2018-02-15 16:06:54 --> Helper loaded: form_helper
INFO - 2018-02-15 16:06:54 --> Form Validation Class Initialized
INFO - 2018-02-15 16:06:54 --> Model Class Initialized
INFO - 2018-02-15 16:06:54 --> Controller Class Initialized
INFO - 2018-02-15 16:06:54 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 16:06:54 --> Model Class Initialized
INFO - 2018-02-15 16:06:54 --> Model Class Initialized
INFO - 2018-02-15 16:06:54 --> Model Class Initialized
INFO - 2018-02-15 16:06:54 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-15 16:06:54 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-15 16:06:54 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-15 16:06:54 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-15 16:06:54 --> File loaded: /var/www/html/project/radio/application/views/tracks/index.php
INFO - 2018-02-15 16:06:54 --> Final output sent to browser
DEBUG - 2018-02-15 16:06:54 --> Total execution time: 0.0044
INFO - 2018-02-15 16:06:54 --> Config Class Initialized
INFO - 2018-02-15 16:06:54 --> Hooks Class Initialized
DEBUG - 2018-02-15 16:06:54 --> UTF-8 Support Enabled
INFO - 2018-02-15 16:06:54 --> Utf8 Class Initialized
INFO - 2018-02-15 16:06:54 --> URI Class Initialized
INFO - 2018-02-15 16:06:54 --> Router Class Initialized
INFO - 2018-02-15 16:06:54 --> Output Class Initialized
INFO - 2018-02-15 16:06:54 --> Security Class Initialized
DEBUG - 2018-02-15 16:06:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 16:06:54 --> Input Class Initialized
INFO - 2018-02-15 16:06:54 --> Language Class Initialized
INFO - 2018-02-15 16:06:54 --> Loader Class Initialized
INFO - 2018-02-15 16:06:54 --> Helper loaded: url_helper
INFO - 2018-02-15 16:06:54 --> Helper loaded: file_helper
INFO - 2018-02-15 16:06:54 --> Helper loaded: email_helper
INFO - 2018-02-15 16:06:54 --> Helper loaded: common_helper
INFO - 2018-02-15 16:06:54 --> Database Driver Class Initialized
DEBUG - 2018-02-15 16:06:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 16:06:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 16:06:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 16:06:54 --> Pagination Class Initialized
INFO - 2018-02-15 16:06:54 --> Helper loaded: form_helper
INFO - 2018-02-15 16:06:54 --> Form Validation Class Initialized
INFO - 2018-02-15 16:06:54 --> Model Class Initialized
INFO - 2018-02-15 16:06:54 --> Controller Class Initialized
INFO - 2018-02-15 16:06:54 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 16:06:54 --> Model Class Initialized
INFO - 2018-02-15 16:06:54 --> Model Class Initialized
INFO - 2018-02-15 16:06:54 --> Model Class Initialized
INFO - 2018-02-15 16:06:54 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-15 16:06:54 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-15 16:06:54 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-15 16:06:54 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-15 16:06:54 --> File loaded: /var/www/html/project/radio/application/views/tracks/index.php
INFO - 2018-02-15 16:06:54 --> Final output sent to browser
DEBUG - 2018-02-15 16:06:54 --> Total execution time: 0.0045
INFO - 2018-02-15 16:06:54 --> Config Class Initialized
INFO - 2018-02-15 16:06:54 --> Hooks Class Initialized
DEBUG - 2018-02-15 16:06:54 --> UTF-8 Support Enabled
INFO - 2018-02-15 16:06:54 --> Utf8 Class Initialized
INFO - 2018-02-15 16:06:54 --> URI Class Initialized
INFO - 2018-02-15 16:06:54 --> Router Class Initialized
INFO - 2018-02-15 16:06:54 --> Output Class Initialized
INFO - 2018-02-15 16:06:54 --> Security Class Initialized
DEBUG - 2018-02-15 16:06:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 16:06:54 --> Input Class Initialized
INFO - 2018-02-15 16:06:54 --> Language Class Initialized
INFO - 2018-02-15 16:06:54 --> Loader Class Initialized
INFO - 2018-02-15 16:06:54 --> Helper loaded: url_helper
INFO - 2018-02-15 16:06:54 --> Helper loaded: file_helper
INFO - 2018-02-15 16:06:54 --> Helper loaded: email_helper
INFO - 2018-02-15 16:06:54 --> Helper loaded: common_helper
INFO - 2018-02-15 16:06:54 --> Database Driver Class Initialized
DEBUG - 2018-02-15 16:06:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 16:06:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 16:06:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 16:06:54 --> Pagination Class Initialized
INFO - 2018-02-15 16:06:54 --> Helper loaded: form_helper
INFO - 2018-02-15 16:06:54 --> Form Validation Class Initialized
INFO - 2018-02-15 16:06:54 --> Model Class Initialized
INFO - 2018-02-15 16:06:54 --> Controller Class Initialized
INFO - 2018-02-15 16:06:54 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 16:06:54 --> Model Class Initialized
INFO - 2018-02-15 16:06:54 --> Model Class Initialized
INFO - 2018-02-15 16:06:54 --> Model Class Initialized
INFO - 2018-02-15 16:06:54 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-15 16:06:54 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-15 16:06:54 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-15 16:06:54 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-15 16:06:54 --> File loaded: /var/www/html/project/radio/application/views/tracks/index.php
INFO - 2018-02-15 16:06:54 --> Final output sent to browser
DEBUG - 2018-02-15 16:06:54 --> Total execution time: 0.0056
INFO - 2018-02-15 16:06:54 --> Config Class Initialized
INFO - 2018-02-15 16:06:54 --> Hooks Class Initialized
DEBUG - 2018-02-15 16:06:54 --> UTF-8 Support Enabled
INFO - 2018-02-15 16:06:54 --> Utf8 Class Initialized
INFO - 2018-02-15 16:06:54 --> URI Class Initialized
INFO - 2018-02-15 16:06:54 --> Router Class Initialized
INFO - 2018-02-15 16:06:54 --> Output Class Initialized
INFO - 2018-02-15 16:06:54 --> Security Class Initialized
DEBUG - 2018-02-15 16:06:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 16:06:54 --> Input Class Initialized
INFO - 2018-02-15 16:06:54 --> Language Class Initialized
INFO - 2018-02-15 16:06:54 --> Loader Class Initialized
INFO - 2018-02-15 16:06:54 --> Helper loaded: url_helper
INFO - 2018-02-15 16:06:54 --> Helper loaded: file_helper
INFO - 2018-02-15 16:06:54 --> Helper loaded: email_helper
INFO - 2018-02-15 16:06:54 --> Helper loaded: common_helper
INFO - 2018-02-15 16:06:54 --> Database Driver Class Initialized
DEBUG - 2018-02-15 16:06:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 16:06:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 16:06:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 16:06:54 --> Pagination Class Initialized
INFO - 2018-02-15 16:06:54 --> Helper loaded: form_helper
INFO - 2018-02-15 16:06:54 --> Form Validation Class Initialized
INFO - 2018-02-15 16:06:54 --> Model Class Initialized
INFO - 2018-02-15 16:06:54 --> Controller Class Initialized
INFO - 2018-02-15 16:06:54 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 16:06:54 --> Model Class Initialized
INFO - 2018-02-15 16:06:54 --> Model Class Initialized
INFO - 2018-02-15 16:06:54 --> Model Class Initialized
INFO - 2018-02-15 16:06:54 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-15 16:06:54 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-15 16:06:54 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-15 16:06:54 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-15 16:06:54 --> File loaded: /var/www/html/project/radio/application/views/tracks/index.php
INFO - 2018-02-15 16:06:54 --> Final output sent to browser
DEBUG - 2018-02-15 16:06:54 --> Total execution time: 0.0033
INFO - 2018-02-15 16:06:54 --> Config Class Initialized
INFO - 2018-02-15 16:06:54 --> Hooks Class Initialized
DEBUG - 2018-02-15 16:06:54 --> UTF-8 Support Enabled
INFO - 2018-02-15 16:06:54 --> Utf8 Class Initialized
INFO - 2018-02-15 16:06:54 --> URI Class Initialized
INFO - 2018-02-15 16:06:54 --> Router Class Initialized
INFO - 2018-02-15 16:06:54 --> Output Class Initialized
INFO - 2018-02-15 16:06:54 --> Security Class Initialized
DEBUG - 2018-02-15 16:06:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 16:06:54 --> Input Class Initialized
INFO - 2018-02-15 16:06:54 --> Language Class Initialized
INFO - 2018-02-15 16:06:54 --> Loader Class Initialized
INFO - 2018-02-15 16:06:54 --> Helper loaded: url_helper
INFO - 2018-02-15 16:06:54 --> Helper loaded: file_helper
INFO - 2018-02-15 16:06:54 --> Helper loaded: email_helper
INFO - 2018-02-15 16:06:54 --> Helper loaded: common_helper
INFO - 2018-02-15 16:06:54 --> Database Driver Class Initialized
DEBUG - 2018-02-15 16:06:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 16:06:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 16:06:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 16:06:54 --> Pagination Class Initialized
INFO - 2018-02-15 16:06:54 --> Helper loaded: form_helper
INFO - 2018-02-15 16:06:54 --> Form Validation Class Initialized
INFO - 2018-02-15 16:06:54 --> Model Class Initialized
INFO - 2018-02-15 16:06:54 --> Controller Class Initialized
INFO - 2018-02-15 16:06:54 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 16:06:54 --> Model Class Initialized
INFO - 2018-02-15 16:06:54 --> Model Class Initialized
INFO - 2018-02-15 16:06:54 --> Model Class Initialized
INFO - 2018-02-15 16:07:01 --> Config Class Initialized
INFO - 2018-02-15 16:07:01 --> Hooks Class Initialized
DEBUG - 2018-02-15 16:07:01 --> UTF-8 Support Enabled
INFO - 2018-02-15 16:07:01 --> Utf8 Class Initialized
INFO - 2018-02-15 16:07:01 --> URI Class Initialized
INFO - 2018-02-15 16:07:01 --> Router Class Initialized
INFO - 2018-02-15 16:07:01 --> Output Class Initialized
INFO - 2018-02-15 16:07:01 --> Security Class Initialized
DEBUG - 2018-02-15 16:07:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 16:07:01 --> Input Class Initialized
INFO - 2018-02-15 16:07:01 --> Language Class Initialized
INFO - 2018-02-15 16:07:01 --> Loader Class Initialized
INFO - 2018-02-15 16:07:01 --> Helper loaded: url_helper
INFO - 2018-02-15 16:07:01 --> Helper loaded: file_helper
INFO - 2018-02-15 16:07:01 --> Helper loaded: email_helper
INFO - 2018-02-15 16:07:01 --> Helper loaded: common_helper
INFO - 2018-02-15 16:07:01 --> Database Driver Class Initialized
DEBUG - 2018-02-15 16:07:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 16:07:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 16:07:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 16:07:01 --> Pagination Class Initialized
INFO - 2018-02-15 16:07:01 --> Helper loaded: form_helper
INFO - 2018-02-15 16:07:01 --> Form Validation Class Initialized
INFO - 2018-02-15 16:07:01 --> Model Class Initialized
INFO - 2018-02-15 16:07:01 --> Controller Class Initialized
INFO - 2018-02-15 16:07:01 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 16:07:01 --> Model Class Initialized
INFO - 2018-02-15 16:07:01 --> Model Class Initialized
INFO - 2018-02-15 16:07:01 --> Model Class Initialized
INFO - 2018-02-15 16:07:01 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-15 16:07:01 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-15 16:07:01 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-15 16:07:01 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-15 16:07:01 --> File loaded: /var/www/html/project/radio/application/views/tracks/index.php
INFO - 2018-02-15 16:07:01 --> Final output sent to browser
DEBUG - 2018-02-15 16:07:01 --> Total execution time: 0.0059
INFO - 2018-02-15 16:07:01 --> Config Class Initialized
INFO - 2018-02-15 16:07:01 --> Hooks Class Initialized
DEBUG - 2018-02-15 16:07:01 --> UTF-8 Support Enabled
INFO - 2018-02-15 16:07:01 --> Utf8 Class Initialized
INFO - 2018-02-15 16:07:01 --> URI Class Initialized
INFO - 2018-02-15 16:07:01 --> Router Class Initialized
INFO - 2018-02-15 16:07:01 --> Output Class Initialized
INFO - 2018-02-15 16:07:01 --> Security Class Initialized
DEBUG - 2018-02-15 16:07:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 16:07:01 --> Input Class Initialized
INFO - 2018-02-15 16:07:01 --> Language Class Initialized
INFO - 2018-02-15 16:07:01 --> Loader Class Initialized
INFO - 2018-02-15 16:07:01 --> Helper loaded: url_helper
INFO - 2018-02-15 16:07:01 --> Helper loaded: file_helper
INFO - 2018-02-15 16:07:01 --> Helper loaded: email_helper
INFO - 2018-02-15 16:07:01 --> Helper loaded: common_helper
INFO - 2018-02-15 16:07:01 --> Database Driver Class Initialized
DEBUG - 2018-02-15 16:07:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 16:07:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 16:07:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 16:07:01 --> Pagination Class Initialized
INFO - 2018-02-15 16:07:01 --> Helper loaded: form_helper
INFO - 2018-02-15 16:07:01 --> Form Validation Class Initialized
INFO - 2018-02-15 16:07:01 --> Model Class Initialized
INFO - 2018-02-15 16:07:01 --> Controller Class Initialized
INFO - 2018-02-15 16:07:01 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 16:07:01 --> Model Class Initialized
INFO - 2018-02-15 16:07:01 --> Model Class Initialized
INFO - 2018-02-15 16:07:01 --> Model Class Initialized
INFO - 2018-02-15 16:07:19 --> Config Class Initialized
INFO - 2018-02-15 16:07:19 --> Hooks Class Initialized
DEBUG - 2018-02-15 16:07:19 --> UTF-8 Support Enabled
INFO - 2018-02-15 16:07:19 --> Utf8 Class Initialized
INFO - 2018-02-15 16:07:19 --> URI Class Initialized
INFO - 2018-02-15 16:07:19 --> Router Class Initialized
INFO - 2018-02-15 16:07:19 --> Output Class Initialized
INFO - 2018-02-15 16:07:19 --> Security Class Initialized
DEBUG - 2018-02-15 16:07:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 16:07:19 --> Input Class Initialized
INFO - 2018-02-15 16:07:19 --> Language Class Initialized
INFO - 2018-02-15 16:07:19 --> Loader Class Initialized
INFO - 2018-02-15 16:07:19 --> Helper loaded: url_helper
INFO - 2018-02-15 16:07:19 --> Helper loaded: file_helper
INFO - 2018-02-15 16:07:19 --> Helper loaded: email_helper
INFO - 2018-02-15 16:07:19 --> Helper loaded: common_helper
INFO - 2018-02-15 16:07:19 --> Database Driver Class Initialized
DEBUG - 2018-02-15 16:07:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 16:07:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 16:07:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 16:07:19 --> Pagination Class Initialized
INFO - 2018-02-15 16:07:19 --> Helper loaded: form_helper
INFO - 2018-02-15 16:07:19 --> Form Validation Class Initialized
INFO - 2018-02-15 16:07:19 --> Model Class Initialized
INFO - 2018-02-15 16:07:19 --> Controller Class Initialized
INFO - 2018-02-15 16:07:19 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 16:07:19 --> Model Class Initialized
INFO - 2018-02-15 16:07:19 --> Model Class Initialized
INFO - 2018-02-15 16:07:19 --> Model Class Initialized
INFO - 2018-02-15 16:07:19 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-15 16:07:19 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-15 16:07:19 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-15 16:07:19 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-15 16:07:19 --> File loaded: /var/www/html/project/radio/application/views/tracks/index.php
INFO - 2018-02-15 16:07:19 --> Final output sent to browser
DEBUG - 2018-02-15 16:07:19 --> Total execution time: 0.0063
INFO - 2018-02-15 16:07:19 --> Config Class Initialized
INFO - 2018-02-15 16:07:19 --> Hooks Class Initialized
DEBUG - 2018-02-15 16:07:19 --> UTF-8 Support Enabled
INFO - 2018-02-15 16:07:19 --> Utf8 Class Initialized
INFO - 2018-02-15 16:07:19 --> URI Class Initialized
INFO - 2018-02-15 16:07:19 --> Router Class Initialized
INFO - 2018-02-15 16:07:19 --> Output Class Initialized
INFO - 2018-02-15 16:07:19 --> Security Class Initialized
DEBUG - 2018-02-15 16:07:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 16:07:19 --> Input Class Initialized
INFO - 2018-02-15 16:07:19 --> Language Class Initialized
INFO - 2018-02-15 16:07:19 --> Loader Class Initialized
INFO - 2018-02-15 16:07:19 --> Helper loaded: url_helper
INFO - 2018-02-15 16:07:19 --> Helper loaded: file_helper
INFO - 2018-02-15 16:07:19 --> Helper loaded: email_helper
INFO - 2018-02-15 16:07:19 --> Helper loaded: common_helper
INFO - 2018-02-15 16:07:19 --> Database Driver Class Initialized
DEBUG - 2018-02-15 16:07:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 16:07:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 16:07:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 16:07:19 --> Pagination Class Initialized
INFO - 2018-02-15 16:07:19 --> Helper loaded: form_helper
INFO - 2018-02-15 16:07:19 --> Form Validation Class Initialized
INFO - 2018-02-15 16:07:19 --> Model Class Initialized
INFO - 2018-02-15 16:07:19 --> Controller Class Initialized
INFO - 2018-02-15 16:07:19 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 16:07:19 --> Model Class Initialized
INFO - 2018-02-15 16:07:19 --> Model Class Initialized
INFO - 2018-02-15 16:07:19 --> Model Class Initialized
INFO - 2018-02-15 16:07:29 --> Config Class Initialized
INFO - 2018-02-15 16:07:29 --> Hooks Class Initialized
DEBUG - 2018-02-15 16:07:29 --> UTF-8 Support Enabled
INFO - 2018-02-15 16:07:29 --> Utf8 Class Initialized
INFO - 2018-02-15 16:07:29 --> URI Class Initialized
INFO - 2018-02-15 16:07:29 --> Router Class Initialized
INFO - 2018-02-15 16:07:29 --> Output Class Initialized
INFO - 2018-02-15 16:07:29 --> Security Class Initialized
DEBUG - 2018-02-15 16:07:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 16:07:29 --> Input Class Initialized
INFO - 2018-02-15 16:07:29 --> Language Class Initialized
INFO - 2018-02-15 16:07:29 --> Loader Class Initialized
INFO - 2018-02-15 16:07:29 --> Helper loaded: url_helper
INFO - 2018-02-15 16:07:29 --> Helper loaded: file_helper
INFO - 2018-02-15 16:07:29 --> Helper loaded: email_helper
INFO - 2018-02-15 16:07:29 --> Helper loaded: common_helper
INFO - 2018-02-15 16:07:29 --> Database Driver Class Initialized
DEBUG - 2018-02-15 16:07:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 16:07:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 16:07:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 16:07:29 --> Pagination Class Initialized
INFO - 2018-02-15 16:07:29 --> Helper loaded: form_helper
INFO - 2018-02-15 16:07:29 --> Form Validation Class Initialized
INFO - 2018-02-15 16:07:29 --> Model Class Initialized
INFO - 2018-02-15 16:07:29 --> Controller Class Initialized
INFO - 2018-02-15 16:07:29 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 16:07:29 --> Model Class Initialized
INFO - 2018-02-15 16:07:29 --> Model Class Initialized
INFO - 2018-02-15 16:07:29 --> Model Class Initialized
INFO - 2018-02-15 16:07:29 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-15 16:07:29 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-15 16:07:29 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-15 16:07:29 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-15 16:07:29 --> File loaded: /var/www/html/project/radio/application/views/tracks/index.php
INFO - 2018-02-15 16:07:29 --> Final output sent to browser
DEBUG - 2018-02-15 16:07:29 --> Total execution time: 0.0050
INFO - 2018-02-15 16:07:29 --> Config Class Initialized
INFO - 2018-02-15 16:07:29 --> Hooks Class Initialized
DEBUG - 2018-02-15 16:07:29 --> UTF-8 Support Enabled
INFO - 2018-02-15 16:07:29 --> Utf8 Class Initialized
INFO - 2018-02-15 16:07:29 --> URI Class Initialized
INFO - 2018-02-15 16:07:29 --> Router Class Initialized
INFO - 2018-02-15 16:07:29 --> Output Class Initialized
INFO - 2018-02-15 16:07:29 --> Security Class Initialized
DEBUG - 2018-02-15 16:07:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 16:07:29 --> Input Class Initialized
INFO - 2018-02-15 16:07:29 --> Language Class Initialized
INFO - 2018-02-15 16:07:29 --> Loader Class Initialized
INFO - 2018-02-15 16:07:29 --> Helper loaded: url_helper
INFO - 2018-02-15 16:07:29 --> Helper loaded: file_helper
INFO - 2018-02-15 16:07:29 --> Helper loaded: email_helper
INFO - 2018-02-15 16:07:29 --> Helper loaded: common_helper
INFO - 2018-02-15 16:07:29 --> Database Driver Class Initialized
DEBUG - 2018-02-15 16:07:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 16:07:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 16:07:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 16:07:29 --> Pagination Class Initialized
INFO - 2018-02-15 16:07:29 --> Helper loaded: form_helper
INFO - 2018-02-15 16:07:29 --> Form Validation Class Initialized
INFO - 2018-02-15 16:07:29 --> Model Class Initialized
INFO - 2018-02-15 16:07:29 --> Controller Class Initialized
INFO - 2018-02-15 16:07:29 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 16:07:29 --> Model Class Initialized
INFO - 2018-02-15 16:07:29 --> Model Class Initialized
INFO - 2018-02-15 16:07:29 --> Model Class Initialized
INFO - 2018-02-15 16:08:55 --> Config Class Initialized
INFO - 2018-02-15 16:08:55 --> Hooks Class Initialized
DEBUG - 2018-02-15 16:08:55 --> UTF-8 Support Enabled
INFO - 2018-02-15 16:08:55 --> Utf8 Class Initialized
INFO - 2018-02-15 16:08:55 --> URI Class Initialized
INFO - 2018-02-15 16:08:55 --> Router Class Initialized
INFO - 2018-02-15 16:08:55 --> Output Class Initialized
INFO - 2018-02-15 16:08:55 --> Security Class Initialized
DEBUG - 2018-02-15 16:08:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 16:08:55 --> Input Class Initialized
INFO - 2018-02-15 16:08:55 --> Language Class Initialized
INFO - 2018-02-15 16:08:55 --> Loader Class Initialized
INFO - 2018-02-15 16:08:55 --> Helper loaded: url_helper
INFO - 2018-02-15 16:08:55 --> Helper loaded: file_helper
INFO - 2018-02-15 16:08:55 --> Helper loaded: email_helper
INFO - 2018-02-15 16:08:55 --> Helper loaded: common_helper
INFO - 2018-02-15 16:08:55 --> Database Driver Class Initialized
DEBUG - 2018-02-15 16:08:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 16:08:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 16:08:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 16:08:55 --> Pagination Class Initialized
INFO - 2018-02-15 16:08:55 --> Helper loaded: form_helper
INFO - 2018-02-15 16:08:55 --> Form Validation Class Initialized
INFO - 2018-02-15 16:08:55 --> Model Class Initialized
INFO - 2018-02-15 16:08:55 --> Controller Class Initialized
INFO - 2018-02-15 16:08:55 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 16:08:55 --> Model Class Initialized
INFO - 2018-02-15 16:08:55 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-15 16:08:55 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-15 16:08:55 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-15 16:08:55 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-15 16:08:55 --> File loaded: /var/www/html/project/radio/application/views/category/index.php
INFO - 2018-02-15 16:08:55 --> Final output sent to browser
DEBUG - 2018-02-15 16:08:55 --> Total execution time: 0.0075
INFO - 2018-02-15 16:08:58 --> Config Class Initialized
INFO - 2018-02-15 16:08:58 --> Hooks Class Initialized
DEBUG - 2018-02-15 16:08:58 --> UTF-8 Support Enabled
INFO - 2018-02-15 16:08:58 --> Utf8 Class Initialized
INFO - 2018-02-15 16:08:58 --> URI Class Initialized
INFO - 2018-02-15 16:08:58 --> Router Class Initialized
INFO - 2018-02-15 16:08:58 --> Output Class Initialized
INFO - 2018-02-15 16:08:58 --> Security Class Initialized
DEBUG - 2018-02-15 16:08:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 16:08:58 --> Input Class Initialized
INFO - 2018-02-15 16:08:58 --> Language Class Initialized
INFO - 2018-02-15 16:08:58 --> Loader Class Initialized
INFO - 2018-02-15 16:08:58 --> Helper loaded: url_helper
INFO - 2018-02-15 16:08:58 --> Helper loaded: file_helper
INFO - 2018-02-15 16:08:58 --> Helper loaded: email_helper
INFO - 2018-02-15 16:08:58 --> Helper loaded: common_helper
INFO - 2018-02-15 16:08:58 --> Database Driver Class Initialized
DEBUG - 2018-02-15 16:08:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 16:08:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 16:08:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 16:08:58 --> Pagination Class Initialized
INFO - 2018-02-15 16:08:58 --> Helper loaded: form_helper
INFO - 2018-02-15 16:08:58 --> Form Validation Class Initialized
INFO - 2018-02-15 16:08:58 --> Model Class Initialized
INFO - 2018-02-15 16:08:58 --> Controller Class Initialized
INFO - 2018-02-15 16:08:58 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 16:08:58 --> Model Class Initialized
INFO - 2018-02-15 16:08:58 --> Model Class Initialized
INFO - 2018-02-15 16:08:58 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-15 16:08:58 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-15 16:08:58 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-15 16:08:58 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-15 16:08:58 --> File loaded: /var/www/html/project/radio/application/views/subcategory/index.php
INFO - 2018-02-15 16:08:58 --> Final output sent to browser
DEBUG - 2018-02-15 16:08:58 --> Total execution time: 0.0048
INFO - 2018-02-15 16:09:00 --> Config Class Initialized
INFO - 2018-02-15 16:09:00 --> Hooks Class Initialized
DEBUG - 2018-02-15 16:09:00 --> UTF-8 Support Enabled
INFO - 2018-02-15 16:09:00 --> Utf8 Class Initialized
INFO - 2018-02-15 16:09:00 --> URI Class Initialized
INFO - 2018-02-15 16:09:00 --> Router Class Initialized
INFO - 2018-02-15 16:09:00 --> Output Class Initialized
INFO - 2018-02-15 16:09:00 --> Security Class Initialized
DEBUG - 2018-02-15 16:09:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 16:09:00 --> Input Class Initialized
INFO - 2018-02-15 16:09:00 --> Language Class Initialized
INFO - 2018-02-15 16:09:00 --> Loader Class Initialized
INFO - 2018-02-15 16:09:00 --> Helper loaded: url_helper
INFO - 2018-02-15 16:09:00 --> Helper loaded: file_helper
INFO - 2018-02-15 16:09:00 --> Helper loaded: email_helper
INFO - 2018-02-15 16:09:00 --> Helper loaded: common_helper
INFO - 2018-02-15 16:09:00 --> Database Driver Class Initialized
DEBUG - 2018-02-15 16:09:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 16:09:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 16:09:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 16:09:00 --> Pagination Class Initialized
INFO - 2018-02-15 16:09:00 --> Helper loaded: form_helper
INFO - 2018-02-15 16:09:00 --> Form Validation Class Initialized
INFO - 2018-02-15 16:09:00 --> Model Class Initialized
INFO - 2018-02-15 16:09:00 --> Controller Class Initialized
INFO - 2018-02-15 16:09:00 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 16:09:00 --> Model Class Initialized
INFO - 2018-02-15 16:09:00 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-15 16:09:00 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-15 16:09:00 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-15 16:09:00 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-15 16:09:00 --> File loaded: /var/www/html/project/radio/application/views/user/index.php
INFO - 2018-02-15 16:09:00 --> Final output sent to browser
DEBUG - 2018-02-15 16:09:00 --> Total execution time: 0.0158
INFO - 2018-02-15 16:09:00 --> Config Class Initialized
INFO - 2018-02-15 16:09:00 --> Hooks Class Initialized
DEBUG - 2018-02-15 16:09:00 --> UTF-8 Support Enabled
INFO - 2018-02-15 16:09:00 --> Utf8 Class Initialized
INFO - 2018-02-15 16:09:00 --> URI Class Initialized
INFO - 2018-02-15 16:09:00 --> Router Class Initialized
INFO - 2018-02-15 16:09:00 --> Output Class Initialized
INFO - 2018-02-15 16:09:00 --> Security Class Initialized
DEBUG - 2018-02-15 16:09:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 16:09:00 --> Input Class Initialized
INFO - 2018-02-15 16:09:00 --> Language Class Initialized
INFO - 2018-02-15 16:09:00 --> Loader Class Initialized
INFO - 2018-02-15 16:09:00 --> Helper loaded: url_helper
INFO - 2018-02-15 16:09:00 --> Helper loaded: file_helper
INFO - 2018-02-15 16:09:00 --> Helper loaded: email_helper
INFO - 2018-02-15 16:09:00 --> Helper loaded: common_helper
INFO - 2018-02-15 16:09:00 --> Database Driver Class Initialized
DEBUG - 2018-02-15 16:09:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 16:09:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 16:09:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 16:09:00 --> Pagination Class Initialized
INFO - 2018-02-15 16:09:00 --> Helper loaded: form_helper
INFO - 2018-02-15 16:09:00 --> Form Validation Class Initialized
INFO - 2018-02-15 16:09:00 --> Model Class Initialized
INFO - 2018-02-15 16:09:00 --> Controller Class Initialized
INFO - 2018-02-15 16:09:00 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 16:09:00 --> Model Class Initialized
INFO - 2018-02-15 16:09:03 --> Config Class Initialized
INFO - 2018-02-15 16:09:03 --> Hooks Class Initialized
DEBUG - 2018-02-15 16:09:03 --> UTF-8 Support Enabled
INFO - 2018-02-15 16:09:03 --> Utf8 Class Initialized
INFO - 2018-02-15 16:09:03 --> URI Class Initialized
INFO - 2018-02-15 16:09:03 --> Router Class Initialized
INFO - 2018-02-15 16:09:03 --> Output Class Initialized
INFO - 2018-02-15 16:09:03 --> Security Class Initialized
DEBUG - 2018-02-15 16:09:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 16:09:03 --> Input Class Initialized
INFO - 2018-02-15 16:09:03 --> Language Class Initialized
INFO - 2018-02-15 16:09:03 --> Loader Class Initialized
INFO - 2018-02-15 16:09:03 --> Helper loaded: url_helper
INFO - 2018-02-15 16:09:03 --> Helper loaded: file_helper
INFO - 2018-02-15 16:09:03 --> Helper loaded: email_helper
INFO - 2018-02-15 16:09:03 --> Helper loaded: common_helper
INFO - 2018-02-15 16:09:03 --> Database Driver Class Initialized
DEBUG - 2018-02-15 16:09:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 16:09:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 16:09:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 16:09:03 --> Pagination Class Initialized
INFO - 2018-02-15 16:09:03 --> Helper loaded: form_helper
INFO - 2018-02-15 16:09:03 --> Form Validation Class Initialized
INFO - 2018-02-15 16:09:03 --> Model Class Initialized
INFO - 2018-02-15 16:09:03 --> Controller Class Initialized
INFO - 2018-02-15 16:09:03 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 16:09:03 --> Model Class Initialized
INFO - 2018-02-15 16:09:03 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-15 16:09:03 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-15 16:09:03 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-15 16:09:03 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-15 16:09:03 --> File loaded: /var/www/html/project/radio/application/views/category/index.php
INFO - 2018-02-15 16:09:03 --> Final output sent to browser
DEBUG - 2018-02-15 16:09:03 --> Total execution time: 0.0059
INFO - 2018-02-15 16:09:12 --> Config Class Initialized
INFO - 2018-02-15 16:09:12 --> Hooks Class Initialized
DEBUG - 2018-02-15 16:09:12 --> UTF-8 Support Enabled
INFO - 2018-02-15 16:09:12 --> Utf8 Class Initialized
INFO - 2018-02-15 16:09:12 --> URI Class Initialized
INFO - 2018-02-15 16:09:12 --> Router Class Initialized
INFO - 2018-02-15 16:09:12 --> Output Class Initialized
INFO - 2018-02-15 16:09:12 --> Security Class Initialized
DEBUG - 2018-02-15 16:09:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 16:09:12 --> Input Class Initialized
INFO - 2018-02-15 16:09:12 --> Language Class Initialized
INFO - 2018-02-15 16:09:12 --> Loader Class Initialized
INFO - 2018-02-15 16:09:12 --> Helper loaded: url_helper
INFO - 2018-02-15 16:09:12 --> Helper loaded: file_helper
INFO - 2018-02-15 16:09:12 --> Helper loaded: email_helper
INFO - 2018-02-15 16:09:12 --> Helper loaded: common_helper
INFO - 2018-02-15 16:09:12 --> Database Driver Class Initialized
DEBUG - 2018-02-15 16:09:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 16:09:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 16:09:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 16:09:12 --> Pagination Class Initialized
INFO - 2018-02-15 16:09:12 --> Helper loaded: form_helper
INFO - 2018-02-15 16:09:12 --> Form Validation Class Initialized
INFO - 2018-02-15 16:09:12 --> Model Class Initialized
INFO - 2018-02-15 16:09:12 --> Controller Class Initialized
INFO - 2018-02-15 16:09:12 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 16:09:12 --> Model Class Initialized
INFO - 2018-02-15 16:09:12 --> Model Class Initialized
INFO - 2018-02-15 16:09:12 --> Model Class Initialized
INFO - 2018-02-15 16:09:12 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-15 16:09:12 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-15 16:09:12 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-15 16:09:12 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-15 16:09:12 --> File loaded: /var/www/html/project/radio/application/views/tracks/index.php
INFO - 2018-02-15 16:09:12 --> Final output sent to browser
DEBUG - 2018-02-15 16:09:12 --> Total execution time: 0.0046
INFO - 2018-02-15 16:09:12 --> Config Class Initialized
INFO - 2018-02-15 16:09:12 --> Hooks Class Initialized
DEBUG - 2018-02-15 16:09:12 --> UTF-8 Support Enabled
INFO - 2018-02-15 16:09:12 --> Utf8 Class Initialized
INFO - 2018-02-15 16:09:12 --> URI Class Initialized
INFO - 2018-02-15 16:09:12 --> Router Class Initialized
INFO - 2018-02-15 16:09:12 --> Output Class Initialized
INFO - 2018-02-15 16:09:12 --> Security Class Initialized
DEBUG - 2018-02-15 16:09:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 16:09:12 --> Input Class Initialized
INFO - 2018-02-15 16:09:12 --> Language Class Initialized
INFO - 2018-02-15 16:09:12 --> Loader Class Initialized
INFO - 2018-02-15 16:09:12 --> Helper loaded: url_helper
INFO - 2018-02-15 16:09:12 --> Helper loaded: file_helper
INFO - 2018-02-15 16:09:12 --> Helper loaded: email_helper
INFO - 2018-02-15 16:09:12 --> Helper loaded: common_helper
INFO - 2018-02-15 16:09:12 --> Database Driver Class Initialized
DEBUG - 2018-02-15 16:09:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 16:09:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 16:09:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 16:09:12 --> Pagination Class Initialized
INFO - 2018-02-15 16:09:12 --> Helper loaded: form_helper
INFO - 2018-02-15 16:09:12 --> Form Validation Class Initialized
INFO - 2018-02-15 16:09:12 --> Model Class Initialized
INFO - 2018-02-15 16:09:12 --> Controller Class Initialized
INFO - 2018-02-15 16:09:12 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 16:09:12 --> Model Class Initialized
INFO - 2018-02-15 16:09:12 --> Model Class Initialized
INFO - 2018-02-15 16:09:12 --> Model Class Initialized
INFO - 2018-02-15 16:09:13 --> Config Class Initialized
INFO - 2018-02-15 16:09:13 --> Hooks Class Initialized
DEBUG - 2018-02-15 16:09:13 --> UTF-8 Support Enabled
INFO - 2018-02-15 16:09:13 --> Utf8 Class Initialized
INFO - 2018-02-15 16:09:13 --> URI Class Initialized
INFO - 2018-02-15 16:09:13 --> Router Class Initialized
INFO - 2018-02-15 16:09:13 --> Output Class Initialized
INFO - 2018-02-15 16:09:13 --> Security Class Initialized
DEBUG - 2018-02-15 16:09:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 16:09:13 --> Input Class Initialized
INFO - 2018-02-15 16:09:13 --> Language Class Initialized
INFO - 2018-02-15 16:09:13 --> Loader Class Initialized
INFO - 2018-02-15 16:09:13 --> Helper loaded: url_helper
INFO - 2018-02-15 16:09:13 --> Helper loaded: file_helper
INFO - 2018-02-15 16:09:13 --> Helper loaded: email_helper
INFO - 2018-02-15 16:09:13 --> Helper loaded: common_helper
INFO - 2018-02-15 16:09:13 --> Database Driver Class Initialized
DEBUG - 2018-02-15 16:09:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 16:09:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 16:09:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 16:09:13 --> Pagination Class Initialized
INFO - 2018-02-15 16:09:13 --> Helper loaded: form_helper
INFO - 2018-02-15 16:09:13 --> Form Validation Class Initialized
INFO - 2018-02-15 16:09:13 --> Model Class Initialized
INFO - 2018-02-15 16:09:13 --> Controller Class Initialized
INFO - 2018-02-15 16:09:13 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 16:09:13 --> Model Class Initialized
INFO - 2018-02-15 16:09:13 --> Model Class Initialized
INFO - 2018-02-15 16:09:13 --> Model Class Initialized
INFO - 2018-02-15 16:09:13 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-15 16:09:13 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-15 16:09:13 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-15 16:09:13 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-15 16:09:13 --> File loaded: /var/www/html/project/radio/application/views/tracks/index.php
INFO - 2018-02-15 16:09:13 --> Final output sent to browser
DEBUG - 2018-02-15 16:09:13 --> Total execution time: 0.0043
INFO - 2018-02-15 16:09:13 --> Config Class Initialized
INFO - 2018-02-15 16:09:13 --> Hooks Class Initialized
DEBUG - 2018-02-15 16:09:13 --> UTF-8 Support Enabled
INFO - 2018-02-15 16:09:13 --> Utf8 Class Initialized
INFO - 2018-02-15 16:09:13 --> URI Class Initialized
INFO - 2018-02-15 16:09:13 --> Router Class Initialized
INFO - 2018-02-15 16:09:13 --> Output Class Initialized
INFO - 2018-02-15 16:09:13 --> Security Class Initialized
DEBUG - 2018-02-15 16:09:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 16:09:13 --> Input Class Initialized
INFO - 2018-02-15 16:09:13 --> Language Class Initialized
INFO - 2018-02-15 16:09:13 --> Loader Class Initialized
INFO - 2018-02-15 16:09:13 --> Helper loaded: url_helper
INFO - 2018-02-15 16:09:13 --> Helper loaded: file_helper
INFO - 2018-02-15 16:09:13 --> Helper loaded: email_helper
INFO - 2018-02-15 16:09:13 --> Helper loaded: common_helper
INFO - 2018-02-15 16:09:13 --> Database Driver Class Initialized
DEBUG - 2018-02-15 16:09:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 16:09:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 16:09:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 16:09:13 --> Pagination Class Initialized
INFO - 2018-02-15 16:09:13 --> Helper loaded: form_helper
INFO - 2018-02-15 16:09:13 --> Form Validation Class Initialized
INFO - 2018-02-15 16:09:13 --> Model Class Initialized
INFO - 2018-02-15 16:09:13 --> Controller Class Initialized
INFO - 2018-02-15 16:09:13 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 16:09:13 --> Model Class Initialized
INFO - 2018-02-15 16:09:13 --> Model Class Initialized
INFO - 2018-02-15 16:09:13 --> Model Class Initialized
INFO - 2018-02-15 16:09:14 --> Config Class Initialized
INFO - 2018-02-15 16:09:14 --> Hooks Class Initialized
DEBUG - 2018-02-15 16:09:14 --> UTF-8 Support Enabled
INFO - 2018-02-15 16:09:14 --> Utf8 Class Initialized
INFO - 2018-02-15 16:09:14 --> URI Class Initialized
INFO - 2018-02-15 16:09:14 --> Router Class Initialized
INFO - 2018-02-15 16:09:14 --> Output Class Initialized
INFO - 2018-02-15 16:09:14 --> Security Class Initialized
DEBUG - 2018-02-15 16:09:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 16:09:14 --> Input Class Initialized
INFO - 2018-02-15 16:09:14 --> Language Class Initialized
INFO - 2018-02-15 16:09:14 --> Loader Class Initialized
INFO - 2018-02-15 16:09:14 --> Helper loaded: url_helper
INFO - 2018-02-15 16:09:14 --> Helper loaded: file_helper
INFO - 2018-02-15 16:09:14 --> Helper loaded: email_helper
INFO - 2018-02-15 16:09:14 --> Helper loaded: common_helper
INFO - 2018-02-15 16:09:14 --> Database Driver Class Initialized
DEBUG - 2018-02-15 16:09:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 16:09:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 16:09:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 16:09:14 --> Pagination Class Initialized
INFO - 2018-02-15 16:09:14 --> Helper loaded: form_helper
INFO - 2018-02-15 16:09:14 --> Form Validation Class Initialized
INFO - 2018-02-15 16:09:14 --> Model Class Initialized
INFO - 2018-02-15 16:09:14 --> Controller Class Initialized
INFO - 2018-02-15 16:09:14 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 16:09:14 --> Model Class Initialized
INFO - 2018-02-15 16:09:14 --> Model Class Initialized
INFO - 2018-02-15 16:09:14 --> Model Class Initialized
INFO - 2018-02-15 16:09:14 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-15 16:09:14 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-15 16:09:14 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-15 16:09:14 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-15 16:09:14 --> File loaded: /var/www/html/project/radio/application/views/tracks/index.php
INFO - 2018-02-15 16:09:14 --> Final output sent to browser
DEBUG - 2018-02-15 16:09:14 --> Total execution time: 0.0048
INFO - 2018-02-15 16:09:14 --> Config Class Initialized
INFO - 2018-02-15 16:09:14 --> Hooks Class Initialized
DEBUG - 2018-02-15 16:09:14 --> UTF-8 Support Enabled
INFO - 2018-02-15 16:09:14 --> Utf8 Class Initialized
INFO - 2018-02-15 16:09:14 --> URI Class Initialized
INFO - 2018-02-15 16:09:14 --> Router Class Initialized
INFO - 2018-02-15 16:09:14 --> Output Class Initialized
INFO - 2018-02-15 16:09:14 --> Security Class Initialized
DEBUG - 2018-02-15 16:09:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 16:09:14 --> Input Class Initialized
INFO - 2018-02-15 16:09:14 --> Language Class Initialized
INFO - 2018-02-15 16:09:14 --> Loader Class Initialized
INFO - 2018-02-15 16:09:14 --> Helper loaded: url_helper
INFO - 2018-02-15 16:09:14 --> Helper loaded: file_helper
INFO - 2018-02-15 16:09:14 --> Helper loaded: email_helper
INFO - 2018-02-15 16:09:14 --> Helper loaded: common_helper
INFO - 2018-02-15 16:09:14 --> Database Driver Class Initialized
DEBUG - 2018-02-15 16:09:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 16:09:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 16:09:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 16:09:14 --> Pagination Class Initialized
INFO - 2018-02-15 16:09:14 --> Helper loaded: form_helper
INFO - 2018-02-15 16:09:14 --> Form Validation Class Initialized
INFO - 2018-02-15 16:09:14 --> Model Class Initialized
INFO - 2018-02-15 16:09:14 --> Controller Class Initialized
INFO - 2018-02-15 16:09:14 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 16:09:14 --> Model Class Initialized
INFO - 2018-02-15 16:09:14 --> Model Class Initialized
INFO - 2018-02-15 16:09:14 --> Model Class Initialized
INFO - 2018-02-15 16:09:14 --> Config Class Initialized
INFO - 2018-02-15 16:09:14 --> Hooks Class Initialized
DEBUG - 2018-02-15 16:09:14 --> UTF-8 Support Enabled
INFO - 2018-02-15 16:09:14 --> Utf8 Class Initialized
INFO - 2018-02-15 16:09:14 --> URI Class Initialized
INFO - 2018-02-15 16:09:14 --> Router Class Initialized
INFO - 2018-02-15 16:09:14 --> Output Class Initialized
INFO - 2018-02-15 16:09:14 --> Security Class Initialized
DEBUG - 2018-02-15 16:09:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 16:09:14 --> Input Class Initialized
INFO - 2018-02-15 16:09:14 --> Language Class Initialized
INFO - 2018-02-15 16:09:14 --> Loader Class Initialized
INFO - 2018-02-15 16:09:14 --> Helper loaded: url_helper
INFO - 2018-02-15 16:09:14 --> Helper loaded: file_helper
INFO - 2018-02-15 16:09:14 --> Helper loaded: email_helper
INFO - 2018-02-15 16:09:14 --> Helper loaded: common_helper
INFO - 2018-02-15 16:09:14 --> Database Driver Class Initialized
DEBUG - 2018-02-15 16:09:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 16:09:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 16:09:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 16:09:14 --> Pagination Class Initialized
INFO - 2018-02-15 16:09:14 --> Helper loaded: form_helper
INFO - 2018-02-15 16:09:14 --> Form Validation Class Initialized
INFO - 2018-02-15 16:09:14 --> Model Class Initialized
INFO - 2018-02-15 16:09:14 --> Controller Class Initialized
INFO - 2018-02-15 16:09:14 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 16:09:14 --> Model Class Initialized
INFO - 2018-02-15 16:09:14 --> Model Class Initialized
INFO - 2018-02-15 16:09:14 --> Model Class Initialized
INFO - 2018-02-15 16:09:14 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-15 16:09:14 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-15 16:09:14 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-15 16:09:14 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-15 16:09:14 --> File loaded: /var/www/html/project/radio/application/views/tracks/index.php
INFO - 2018-02-15 16:09:14 --> Final output sent to browser
DEBUG - 2018-02-15 16:09:14 --> Total execution time: 0.0043
INFO - 2018-02-15 16:09:14 --> Config Class Initialized
INFO - 2018-02-15 16:09:14 --> Hooks Class Initialized
DEBUG - 2018-02-15 16:09:14 --> UTF-8 Support Enabled
INFO - 2018-02-15 16:09:14 --> Utf8 Class Initialized
INFO - 2018-02-15 16:09:14 --> URI Class Initialized
INFO - 2018-02-15 16:09:14 --> Router Class Initialized
INFO - 2018-02-15 16:09:14 --> Output Class Initialized
INFO - 2018-02-15 16:09:14 --> Security Class Initialized
DEBUG - 2018-02-15 16:09:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 16:09:14 --> Input Class Initialized
INFO - 2018-02-15 16:09:14 --> Language Class Initialized
INFO - 2018-02-15 16:09:14 --> Loader Class Initialized
INFO - 2018-02-15 16:09:14 --> Helper loaded: url_helper
INFO - 2018-02-15 16:09:14 --> Helper loaded: file_helper
INFO - 2018-02-15 16:09:14 --> Helper loaded: email_helper
INFO - 2018-02-15 16:09:14 --> Helper loaded: common_helper
INFO - 2018-02-15 16:09:14 --> Database Driver Class Initialized
DEBUG - 2018-02-15 16:09:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 16:09:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 16:09:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 16:09:14 --> Pagination Class Initialized
INFO - 2018-02-15 16:09:14 --> Helper loaded: form_helper
INFO - 2018-02-15 16:09:14 --> Form Validation Class Initialized
INFO - 2018-02-15 16:09:14 --> Model Class Initialized
INFO - 2018-02-15 16:09:14 --> Controller Class Initialized
INFO - 2018-02-15 16:09:14 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 16:09:14 --> Model Class Initialized
INFO - 2018-02-15 16:09:14 --> Model Class Initialized
INFO - 2018-02-15 16:09:14 --> Model Class Initialized
INFO - 2018-02-15 16:09:26 --> Config Class Initialized
INFO - 2018-02-15 16:09:26 --> Hooks Class Initialized
DEBUG - 2018-02-15 16:09:26 --> UTF-8 Support Enabled
INFO - 2018-02-15 16:09:26 --> Utf8 Class Initialized
INFO - 2018-02-15 16:09:26 --> URI Class Initialized
INFO - 2018-02-15 16:09:26 --> Router Class Initialized
INFO - 2018-02-15 16:09:26 --> Output Class Initialized
INFO - 2018-02-15 16:09:26 --> Security Class Initialized
DEBUG - 2018-02-15 16:09:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 16:09:26 --> Input Class Initialized
INFO - 2018-02-15 16:09:26 --> Language Class Initialized
INFO - 2018-02-15 16:09:26 --> Loader Class Initialized
INFO - 2018-02-15 16:09:26 --> Helper loaded: url_helper
INFO - 2018-02-15 16:09:26 --> Helper loaded: file_helper
INFO - 2018-02-15 16:09:26 --> Helper loaded: email_helper
INFO - 2018-02-15 16:09:26 --> Helper loaded: common_helper
INFO - 2018-02-15 16:09:26 --> Database Driver Class Initialized
DEBUG - 2018-02-15 16:09:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 16:09:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 16:09:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 16:09:26 --> Pagination Class Initialized
INFO - 2018-02-15 16:09:26 --> Helper loaded: form_helper
INFO - 2018-02-15 16:09:26 --> Form Validation Class Initialized
INFO - 2018-02-15 16:09:26 --> Model Class Initialized
INFO - 2018-02-15 16:09:26 --> Controller Class Initialized
INFO - 2018-02-15 16:09:26 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 16:09:26 --> Model Class Initialized
INFO - 2018-02-15 16:09:26 --> Model Class Initialized
INFO - 2018-02-15 16:09:26 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-15 16:09:26 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-15 16:09:26 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-15 16:09:26 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-15 16:09:26 --> File loaded: /var/www/html/project/radio/application/views/subcategory/index.php
INFO - 2018-02-15 16:09:26 --> Final output sent to browser
DEBUG - 2018-02-15 16:09:26 --> Total execution time: 0.0111
INFO - 2018-02-15 16:09:28 --> Config Class Initialized
INFO - 2018-02-15 16:09:28 --> Hooks Class Initialized
DEBUG - 2018-02-15 16:09:28 --> UTF-8 Support Enabled
INFO - 2018-02-15 16:09:28 --> Utf8 Class Initialized
INFO - 2018-02-15 16:09:28 --> URI Class Initialized
INFO - 2018-02-15 16:09:28 --> Router Class Initialized
INFO - 2018-02-15 16:09:28 --> Output Class Initialized
INFO - 2018-02-15 16:09:28 --> Security Class Initialized
DEBUG - 2018-02-15 16:09:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 16:09:28 --> Input Class Initialized
INFO - 2018-02-15 16:09:28 --> Language Class Initialized
INFO - 2018-02-15 16:09:28 --> Loader Class Initialized
INFO - 2018-02-15 16:09:28 --> Helper loaded: url_helper
INFO - 2018-02-15 16:09:28 --> Helper loaded: file_helper
INFO - 2018-02-15 16:09:28 --> Helper loaded: email_helper
INFO - 2018-02-15 16:09:28 --> Helper loaded: common_helper
INFO - 2018-02-15 16:09:28 --> Database Driver Class Initialized
DEBUG - 2018-02-15 16:09:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 16:09:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 16:09:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 16:09:28 --> Pagination Class Initialized
INFO - 2018-02-15 16:09:28 --> Helper loaded: form_helper
INFO - 2018-02-15 16:09:28 --> Form Validation Class Initialized
INFO - 2018-02-15 16:09:28 --> Model Class Initialized
INFO - 2018-02-15 16:09:28 --> Controller Class Initialized
INFO - 2018-02-15 16:09:28 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 16:09:28 --> Model Class Initialized
INFO - 2018-02-15 16:09:28 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-15 16:09:28 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-15 16:09:28 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-15 16:09:28 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-15 16:09:28 --> File loaded: /var/www/html/project/radio/application/views/category/index.php
INFO - 2018-02-15 16:09:28 --> Final output sent to browser
DEBUG - 2018-02-15 16:09:28 --> Total execution time: 0.0053
INFO - 2018-02-15 16:09:29 --> Config Class Initialized
INFO - 2018-02-15 16:09:29 --> Hooks Class Initialized
DEBUG - 2018-02-15 16:09:29 --> UTF-8 Support Enabled
INFO - 2018-02-15 16:09:29 --> Utf8 Class Initialized
INFO - 2018-02-15 16:09:29 --> URI Class Initialized
INFO - 2018-02-15 16:09:29 --> Router Class Initialized
INFO - 2018-02-15 16:09:29 --> Output Class Initialized
INFO - 2018-02-15 16:09:29 --> Security Class Initialized
DEBUG - 2018-02-15 16:09:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 16:09:29 --> Input Class Initialized
INFO - 2018-02-15 16:09:29 --> Language Class Initialized
INFO - 2018-02-15 16:09:29 --> Loader Class Initialized
INFO - 2018-02-15 16:09:29 --> Helper loaded: url_helper
INFO - 2018-02-15 16:09:29 --> Helper loaded: file_helper
INFO - 2018-02-15 16:09:29 --> Helper loaded: email_helper
INFO - 2018-02-15 16:09:29 --> Helper loaded: common_helper
INFO - 2018-02-15 16:09:29 --> Database Driver Class Initialized
DEBUG - 2018-02-15 16:09:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 16:09:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 16:09:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 16:09:29 --> Pagination Class Initialized
INFO - 2018-02-15 16:09:29 --> Helper loaded: form_helper
INFO - 2018-02-15 16:09:29 --> Form Validation Class Initialized
INFO - 2018-02-15 16:09:29 --> Model Class Initialized
INFO - 2018-02-15 16:09:29 --> Controller Class Initialized
INFO - 2018-02-15 16:09:29 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 16:09:29 --> Model Class Initialized
INFO - 2018-02-15 16:09:29 --> Model Class Initialized
INFO - 2018-02-15 16:09:29 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-15 16:09:29 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-15 16:09:29 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-15 16:09:29 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-15 16:09:29 --> File loaded: /var/www/html/project/radio/application/views/subcategory/index.php
INFO - 2018-02-15 16:09:29 --> Final output sent to browser
DEBUG - 2018-02-15 16:09:29 --> Total execution time: 0.0067
INFO - 2018-02-15 16:09:32 --> Config Class Initialized
INFO - 2018-02-15 16:09:32 --> Hooks Class Initialized
DEBUG - 2018-02-15 16:09:32 --> UTF-8 Support Enabled
INFO - 2018-02-15 16:09:32 --> Utf8 Class Initialized
INFO - 2018-02-15 16:09:32 --> URI Class Initialized
INFO - 2018-02-15 16:09:32 --> Router Class Initialized
INFO - 2018-02-15 16:09:32 --> Output Class Initialized
INFO - 2018-02-15 16:09:32 --> Security Class Initialized
DEBUG - 2018-02-15 16:09:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 16:09:32 --> Input Class Initialized
INFO - 2018-02-15 16:09:32 --> Language Class Initialized
INFO - 2018-02-15 16:09:32 --> Loader Class Initialized
INFO - 2018-02-15 16:09:32 --> Helper loaded: url_helper
INFO - 2018-02-15 16:09:32 --> Helper loaded: file_helper
INFO - 2018-02-15 16:09:32 --> Helper loaded: email_helper
INFO - 2018-02-15 16:09:32 --> Helper loaded: common_helper
INFO - 2018-02-15 16:09:32 --> Database Driver Class Initialized
DEBUG - 2018-02-15 16:09:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 16:09:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 16:09:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 16:09:32 --> Pagination Class Initialized
INFO - 2018-02-15 16:09:32 --> Helper loaded: form_helper
INFO - 2018-02-15 16:09:32 --> Form Validation Class Initialized
INFO - 2018-02-15 16:09:32 --> Model Class Initialized
INFO - 2018-02-15 16:09:32 --> Controller Class Initialized
INFO - 2018-02-15 16:09:32 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 16:09:32 --> Model Class Initialized
INFO - 2018-02-15 16:09:32 --> Model Class Initialized
INFO - 2018-02-15 16:09:32 --> Model Class Initialized
INFO - 2018-02-15 16:09:32 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-15 16:09:32 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-15 16:09:32 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-15 16:09:32 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-15 16:09:32 --> File loaded: /var/www/html/project/radio/application/views/tracks/index.php
INFO - 2018-02-15 16:09:32 --> Final output sent to browser
DEBUG - 2018-02-15 16:09:32 --> Total execution time: 0.0057
INFO - 2018-02-15 16:09:32 --> Config Class Initialized
INFO - 2018-02-15 16:09:32 --> Hooks Class Initialized
DEBUG - 2018-02-15 16:09:32 --> UTF-8 Support Enabled
INFO - 2018-02-15 16:09:32 --> Utf8 Class Initialized
INFO - 2018-02-15 16:09:32 --> URI Class Initialized
INFO - 2018-02-15 16:09:32 --> Router Class Initialized
INFO - 2018-02-15 16:09:32 --> Output Class Initialized
INFO - 2018-02-15 16:09:32 --> Security Class Initialized
DEBUG - 2018-02-15 16:09:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 16:09:32 --> Input Class Initialized
INFO - 2018-02-15 16:09:32 --> Language Class Initialized
INFO - 2018-02-15 16:09:32 --> Loader Class Initialized
INFO - 2018-02-15 16:09:32 --> Helper loaded: url_helper
INFO - 2018-02-15 16:09:32 --> Helper loaded: file_helper
INFO - 2018-02-15 16:09:32 --> Helper loaded: email_helper
INFO - 2018-02-15 16:09:32 --> Helper loaded: common_helper
INFO - 2018-02-15 16:09:32 --> Database Driver Class Initialized
DEBUG - 2018-02-15 16:09:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 16:09:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 16:09:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 16:09:32 --> Pagination Class Initialized
INFO - 2018-02-15 16:09:32 --> Helper loaded: form_helper
INFO - 2018-02-15 16:09:32 --> Form Validation Class Initialized
INFO - 2018-02-15 16:09:32 --> Model Class Initialized
INFO - 2018-02-15 16:09:32 --> Controller Class Initialized
INFO - 2018-02-15 16:09:32 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 16:09:32 --> Model Class Initialized
INFO - 2018-02-15 16:09:32 --> Model Class Initialized
INFO - 2018-02-15 16:09:32 --> Model Class Initialized
INFO - 2018-02-15 16:10:21 --> Config Class Initialized
INFO - 2018-02-15 16:10:21 --> Hooks Class Initialized
DEBUG - 2018-02-15 16:10:21 --> UTF-8 Support Enabled
INFO - 2018-02-15 16:10:21 --> Utf8 Class Initialized
INFO - 2018-02-15 16:10:21 --> URI Class Initialized
INFO - 2018-02-15 16:10:21 --> Router Class Initialized
INFO - 2018-02-15 16:10:21 --> Output Class Initialized
INFO - 2018-02-15 16:10:21 --> Security Class Initialized
DEBUG - 2018-02-15 16:10:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 16:10:21 --> Input Class Initialized
INFO - 2018-02-15 16:10:21 --> Language Class Initialized
INFO - 2018-02-15 16:10:21 --> Loader Class Initialized
INFO - 2018-02-15 16:10:21 --> Helper loaded: url_helper
INFO - 2018-02-15 16:10:21 --> Helper loaded: file_helper
INFO - 2018-02-15 16:10:21 --> Helper loaded: email_helper
INFO - 2018-02-15 16:10:21 --> Helper loaded: common_helper
INFO - 2018-02-15 16:10:21 --> Database Driver Class Initialized
DEBUG - 2018-02-15 16:10:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 16:10:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 16:10:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 16:10:21 --> Pagination Class Initialized
INFO - 2018-02-15 16:10:21 --> Helper loaded: form_helper
INFO - 2018-02-15 16:10:21 --> Form Validation Class Initialized
INFO - 2018-02-15 16:10:21 --> Model Class Initialized
INFO - 2018-02-15 16:10:21 --> Controller Class Initialized
INFO - 2018-02-15 16:10:21 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 16:10:21 --> Model Class Initialized
INFO - 2018-02-15 16:10:21 --> Model Class Initialized
INFO - 2018-02-15 16:10:21 --> Model Class Initialized
INFO - 2018-02-15 16:10:21 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-15 16:10:21 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-15 16:10:21 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-15 16:10:21 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-15 16:10:21 --> File loaded: /var/www/html/project/radio/application/views/tracks/index.php
INFO - 2018-02-15 16:10:21 --> Final output sent to browser
DEBUG - 2018-02-15 16:10:21 --> Total execution time: 0.0087
INFO - 2018-02-15 16:10:22 --> Config Class Initialized
INFO - 2018-02-15 16:10:22 --> Hooks Class Initialized
DEBUG - 2018-02-15 16:10:22 --> UTF-8 Support Enabled
INFO - 2018-02-15 16:10:22 --> Utf8 Class Initialized
INFO - 2018-02-15 16:10:22 --> URI Class Initialized
INFO - 2018-02-15 16:10:22 --> Router Class Initialized
INFO - 2018-02-15 16:10:22 --> Output Class Initialized
INFO - 2018-02-15 16:10:22 --> Security Class Initialized
DEBUG - 2018-02-15 16:10:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 16:10:22 --> Input Class Initialized
INFO - 2018-02-15 16:10:22 --> Language Class Initialized
INFO - 2018-02-15 16:10:22 --> Loader Class Initialized
INFO - 2018-02-15 16:10:22 --> Helper loaded: url_helper
INFO - 2018-02-15 16:10:22 --> Helper loaded: file_helper
INFO - 2018-02-15 16:10:22 --> Helper loaded: email_helper
INFO - 2018-02-15 16:10:22 --> Helper loaded: common_helper
INFO - 2018-02-15 16:10:22 --> Database Driver Class Initialized
DEBUG - 2018-02-15 16:10:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 16:10:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 16:10:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 16:10:22 --> Pagination Class Initialized
INFO - 2018-02-15 16:10:22 --> Helper loaded: form_helper
INFO - 2018-02-15 16:10:22 --> Form Validation Class Initialized
INFO - 2018-02-15 16:10:22 --> Model Class Initialized
INFO - 2018-02-15 16:10:22 --> Controller Class Initialized
INFO - 2018-02-15 16:10:22 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 16:10:22 --> Model Class Initialized
INFO - 2018-02-15 16:10:22 --> Model Class Initialized
INFO - 2018-02-15 16:10:22 --> Model Class Initialized
INFO - 2018-02-15 16:10:30 --> Config Class Initialized
INFO - 2018-02-15 16:10:30 --> Hooks Class Initialized
DEBUG - 2018-02-15 16:10:30 --> UTF-8 Support Enabled
INFO - 2018-02-15 16:10:30 --> Utf8 Class Initialized
INFO - 2018-02-15 16:10:30 --> URI Class Initialized
INFO - 2018-02-15 16:10:30 --> Router Class Initialized
INFO - 2018-02-15 16:10:30 --> Output Class Initialized
INFO - 2018-02-15 16:10:30 --> Security Class Initialized
DEBUG - 2018-02-15 16:10:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 16:10:30 --> Input Class Initialized
INFO - 2018-02-15 16:10:30 --> Language Class Initialized
INFO - 2018-02-15 16:10:30 --> Loader Class Initialized
INFO - 2018-02-15 16:10:30 --> Helper loaded: url_helper
INFO - 2018-02-15 16:10:30 --> Helper loaded: file_helper
INFO - 2018-02-15 16:10:30 --> Helper loaded: email_helper
INFO - 2018-02-15 16:10:30 --> Helper loaded: common_helper
INFO - 2018-02-15 16:10:30 --> Database Driver Class Initialized
DEBUG - 2018-02-15 16:10:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 16:10:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 16:10:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 16:10:30 --> Pagination Class Initialized
INFO - 2018-02-15 16:10:30 --> Helper loaded: form_helper
INFO - 2018-02-15 16:10:30 --> Form Validation Class Initialized
INFO - 2018-02-15 16:10:30 --> Model Class Initialized
INFO - 2018-02-15 16:10:30 --> Controller Class Initialized
INFO - 2018-02-15 16:10:30 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 16:10:30 --> Model Class Initialized
INFO - 2018-02-15 16:10:30 --> Model Class Initialized
INFO - 2018-02-15 16:10:30 --> Model Class Initialized
INFO - 2018-02-15 16:10:30 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-15 16:10:30 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-15 16:10:30 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-15 16:10:30 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-15 16:10:30 --> File loaded: /var/www/html/project/radio/application/views/tracks/index.php
INFO - 2018-02-15 16:10:30 --> Final output sent to browser
DEBUG - 2018-02-15 16:10:30 --> Total execution time: 0.0058
INFO - 2018-02-15 16:10:30 --> Config Class Initialized
INFO - 2018-02-15 16:10:30 --> Hooks Class Initialized
DEBUG - 2018-02-15 16:10:30 --> UTF-8 Support Enabled
INFO - 2018-02-15 16:10:30 --> Utf8 Class Initialized
INFO - 2018-02-15 16:10:30 --> URI Class Initialized
INFO - 2018-02-15 16:10:30 --> Router Class Initialized
INFO - 2018-02-15 16:10:30 --> Output Class Initialized
INFO - 2018-02-15 16:10:30 --> Security Class Initialized
DEBUG - 2018-02-15 16:10:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 16:10:30 --> Input Class Initialized
INFO - 2018-02-15 16:10:30 --> Language Class Initialized
INFO - 2018-02-15 16:10:30 --> Loader Class Initialized
INFO - 2018-02-15 16:10:30 --> Helper loaded: url_helper
INFO - 2018-02-15 16:10:30 --> Helper loaded: file_helper
INFO - 2018-02-15 16:10:30 --> Helper loaded: email_helper
INFO - 2018-02-15 16:10:30 --> Helper loaded: common_helper
INFO - 2018-02-15 16:10:30 --> Database Driver Class Initialized
DEBUG - 2018-02-15 16:10:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 16:10:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 16:10:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 16:10:30 --> Pagination Class Initialized
INFO - 2018-02-15 16:10:30 --> Helper loaded: form_helper
INFO - 2018-02-15 16:10:30 --> Form Validation Class Initialized
INFO - 2018-02-15 16:10:30 --> Model Class Initialized
INFO - 2018-02-15 16:10:30 --> Controller Class Initialized
INFO - 2018-02-15 16:10:30 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 16:10:30 --> Model Class Initialized
INFO - 2018-02-15 16:10:30 --> Model Class Initialized
INFO - 2018-02-15 16:10:30 --> Model Class Initialized
INFO - 2018-02-15 16:21:40 --> Config Class Initialized
INFO - 2018-02-15 16:21:40 --> Hooks Class Initialized
DEBUG - 2018-02-15 16:21:40 --> UTF-8 Support Enabled
INFO - 2018-02-15 16:21:40 --> Utf8 Class Initialized
INFO - 2018-02-15 16:21:40 --> URI Class Initialized
INFO - 2018-02-15 16:21:40 --> Router Class Initialized
INFO - 2018-02-15 16:21:40 --> Output Class Initialized
INFO - 2018-02-15 16:21:40 --> Security Class Initialized
DEBUG - 2018-02-15 16:21:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 16:21:40 --> Input Class Initialized
INFO - 2018-02-15 16:21:40 --> Language Class Initialized
INFO - 2018-02-15 16:21:40 --> Loader Class Initialized
INFO - 2018-02-15 16:21:40 --> Helper loaded: url_helper
INFO - 2018-02-15 16:21:40 --> Helper loaded: file_helper
INFO - 2018-02-15 16:21:40 --> Helper loaded: email_helper
INFO - 2018-02-15 16:21:40 --> Helper loaded: common_helper
INFO - 2018-02-15 16:21:40 --> Database Driver Class Initialized
DEBUG - 2018-02-15 16:21:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 16:21:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 16:21:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 16:21:40 --> Pagination Class Initialized
INFO - 2018-02-15 16:21:40 --> Helper loaded: form_helper
INFO - 2018-02-15 16:21:40 --> Form Validation Class Initialized
INFO - 2018-02-15 16:21:40 --> Model Class Initialized
INFO - 2018-02-15 16:21:40 --> Controller Class Initialized
INFO - 2018-02-15 16:21:40 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 16:21:40 --> Model Class Initialized
INFO - 2018-02-15 16:21:40 --> Model Class Initialized
INFO - 2018-02-15 16:21:40 --> Model Class Initialized
INFO - 2018-02-15 16:21:40 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-15 16:21:40 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-15 16:21:40 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-15 16:21:40 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-15 16:21:40 --> File loaded: /var/www/html/project/radio/application/views/tracks/add_edit.php
INFO - 2018-02-15 16:21:40 --> Final output sent to browser
DEBUG - 2018-02-15 16:21:40 --> Total execution time: 0.0065
INFO - 2018-02-15 16:22:29 --> Config Class Initialized
INFO - 2018-02-15 16:22:29 --> Hooks Class Initialized
DEBUG - 2018-02-15 16:22:29 --> UTF-8 Support Enabled
INFO - 2018-02-15 16:22:29 --> Utf8 Class Initialized
INFO - 2018-02-15 16:22:29 --> URI Class Initialized
INFO - 2018-02-15 16:22:29 --> Router Class Initialized
INFO - 2018-02-15 16:22:29 --> Output Class Initialized
INFO - 2018-02-15 16:22:29 --> Security Class Initialized
DEBUG - 2018-02-15 16:22:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 16:22:29 --> Input Class Initialized
INFO - 2018-02-15 16:22:29 --> Language Class Initialized
INFO - 2018-02-15 16:22:29 --> Loader Class Initialized
INFO - 2018-02-15 16:22:29 --> Helper loaded: url_helper
INFO - 2018-02-15 16:22:29 --> Helper loaded: file_helper
INFO - 2018-02-15 16:22:29 --> Helper loaded: email_helper
INFO - 2018-02-15 16:22:29 --> Helper loaded: common_helper
INFO - 2018-02-15 16:22:29 --> Database Driver Class Initialized
DEBUG - 2018-02-15 16:22:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 16:22:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 16:22:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 16:22:29 --> Pagination Class Initialized
INFO - 2018-02-15 16:22:29 --> Helper loaded: form_helper
INFO - 2018-02-15 16:22:29 --> Form Validation Class Initialized
INFO - 2018-02-15 16:22:29 --> Model Class Initialized
INFO - 2018-02-15 16:22:29 --> Controller Class Initialized
INFO - 2018-02-15 16:22:29 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 16:22:29 --> Model Class Initialized
INFO - 2018-02-15 16:22:29 --> Model Class Initialized
INFO - 2018-02-15 16:22:29 --> Model Class Initialized
INFO - 2018-02-15 16:22:29 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-15 16:22:29 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-15 16:22:29 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-15 16:22:29 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-15 16:22:29 --> File loaded: /var/www/html/project/radio/application/views/tracks/add_edit.php
INFO - 2018-02-15 16:22:29 --> Final output sent to browser
DEBUG - 2018-02-15 16:22:29 --> Total execution time: 0.0053
INFO - 2018-02-15 16:22:46 --> Config Class Initialized
INFO - 2018-02-15 16:22:46 --> Hooks Class Initialized
DEBUG - 2018-02-15 16:22:46 --> UTF-8 Support Enabled
INFO - 2018-02-15 16:22:46 --> Utf8 Class Initialized
INFO - 2018-02-15 16:22:46 --> URI Class Initialized
INFO - 2018-02-15 16:22:46 --> Router Class Initialized
INFO - 2018-02-15 16:22:46 --> Output Class Initialized
INFO - 2018-02-15 16:22:46 --> Security Class Initialized
DEBUG - 2018-02-15 16:22:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 16:22:46 --> Input Class Initialized
INFO - 2018-02-15 16:22:46 --> Language Class Initialized
INFO - 2018-02-15 16:22:46 --> Loader Class Initialized
INFO - 2018-02-15 16:22:46 --> Helper loaded: url_helper
INFO - 2018-02-15 16:22:46 --> Helper loaded: file_helper
INFO - 2018-02-15 16:22:46 --> Helper loaded: email_helper
INFO - 2018-02-15 16:22:46 --> Helper loaded: common_helper
INFO - 2018-02-15 16:22:46 --> Database Driver Class Initialized
DEBUG - 2018-02-15 16:22:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 16:22:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 16:22:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 16:22:46 --> Pagination Class Initialized
INFO - 2018-02-15 16:22:46 --> Helper loaded: form_helper
INFO - 2018-02-15 16:22:46 --> Form Validation Class Initialized
INFO - 2018-02-15 16:22:46 --> Model Class Initialized
INFO - 2018-02-15 16:22:46 --> Controller Class Initialized
INFO - 2018-02-15 16:22:46 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 16:22:46 --> Model Class Initialized
INFO - 2018-02-15 16:22:46 --> Model Class Initialized
INFO - 2018-02-15 16:22:46 --> Model Class Initialized
INFO - 2018-02-15 16:22:46 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-15 16:22:46 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-15 16:22:46 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-15 16:22:46 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-15 16:22:46 --> File loaded: /var/www/html/project/radio/application/views/tracks/add_edit.php
INFO - 2018-02-15 16:22:46 --> Final output sent to browser
DEBUG - 2018-02-15 16:22:46 --> Total execution time: 0.0072
INFO - 2018-02-15 16:23:27 --> Config Class Initialized
INFO - 2018-02-15 16:23:27 --> Hooks Class Initialized
DEBUG - 2018-02-15 16:23:27 --> UTF-8 Support Enabled
INFO - 2018-02-15 16:23:27 --> Utf8 Class Initialized
INFO - 2018-02-15 16:23:27 --> URI Class Initialized
INFO - 2018-02-15 16:23:27 --> Router Class Initialized
INFO - 2018-02-15 16:23:27 --> Output Class Initialized
INFO - 2018-02-15 16:23:27 --> Security Class Initialized
DEBUG - 2018-02-15 16:23:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 16:23:27 --> Input Class Initialized
INFO - 2018-02-15 16:23:27 --> Language Class Initialized
INFO - 2018-02-15 16:23:27 --> Loader Class Initialized
INFO - 2018-02-15 16:23:27 --> Helper loaded: url_helper
INFO - 2018-02-15 16:23:27 --> Helper loaded: file_helper
INFO - 2018-02-15 16:23:27 --> Helper loaded: email_helper
INFO - 2018-02-15 16:23:27 --> Helper loaded: common_helper
INFO - 2018-02-15 16:23:27 --> Database Driver Class Initialized
DEBUG - 2018-02-15 16:23:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 16:23:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 16:23:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 16:23:27 --> Pagination Class Initialized
INFO - 2018-02-15 16:23:27 --> Helper loaded: form_helper
INFO - 2018-02-15 16:23:27 --> Form Validation Class Initialized
INFO - 2018-02-15 16:23:27 --> Model Class Initialized
INFO - 2018-02-15 16:23:27 --> Controller Class Initialized
INFO - 2018-02-15 16:23:27 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 16:23:27 --> Model Class Initialized
INFO - 2018-02-15 16:23:27 --> Model Class Initialized
INFO - 2018-02-15 16:23:27 --> Model Class Initialized
INFO - 2018-02-15 16:23:27 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-15 16:23:27 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-15 16:23:27 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-15 16:23:27 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-15 16:23:27 --> File loaded: /var/www/html/project/radio/application/views/tracks/index.php
INFO - 2018-02-15 16:23:27 --> Final output sent to browser
DEBUG - 2018-02-15 16:23:27 --> Total execution time: 0.0044
INFO - 2018-02-15 16:23:27 --> Config Class Initialized
INFO - 2018-02-15 16:23:27 --> Hooks Class Initialized
DEBUG - 2018-02-15 16:23:27 --> UTF-8 Support Enabled
INFO - 2018-02-15 16:23:27 --> Utf8 Class Initialized
INFO - 2018-02-15 16:23:27 --> URI Class Initialized
INFO - 2018-02-15 16:23:27 --> Router Class Initialized
INFO - 2018-02-15 16:23:27 --> Output Class Initialized
INFO - 2018-02-15 16:23:27 --> Security Class Initialized
DEBUG - 2018-02-15 16:23:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 16:23:27 --> Input Class Initialized
INFO - 2018-02-15 16:23:27 --> Language Class Initialized
INFO - 2018-02-15 16:23:27 --> Loader Class Initialized
INFO - 2018-02-15 16:23:27 --> Helper loaded: url_helper
INFO - 2018-02-15 16:23:27 --> Helper loaded: file_helper
INFO - 2018-02-15 16:23:27 --> Helper loaded: email_helper
INFO - 2018-02-15 16:23:27 --> Helper loaded: common_helper
INFO - 2018-02-15 16:23:27 --> Database Driver Class Initialized
DEBUG - 2018-02-15 16:23:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 16:23:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 16:23:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 16:23:27 --> Pagination Class Initialized
INFO - 2018-02-15 16:23:27 --> Helper loaded: form_helper
INFO - 2018-02-15 16:23:27 --> Form Validation Class Initialized
INFO - 2018-02-15 16:23:27 --> Model Class Initialized
INFO - 2018-02-15 16:23:27 --> Controller Class Initialized
INFO - 2018-02-15 16:23:27 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 16:23:27 --> Model Class Initialized
INFO - 2018-02-15 16:23:27 --> Model Class Initialized
INFO - 2018-02-15 16:23:27 --> Model Class Initialized
INFO - 2018-02-15 16:23:28 --> Config Class Initialized
INFO - 2018-02-15 16:23:28 --> Hooks Class Initialized
DEBUG - 2018-02-15 16:23:28 --> UTF-8 Support Enabled
INFO - 2018-02-15 16:23:28 --> Utf8 Class Initialized
INFO - 2018-02-15 16:23:28 --> URI Class Initialized
INFO - 2018-02-15 16:23:28 --> Router Class Initialized
INFO - 2018-02-15 16:23:28 --> Output Class Initialized
INFO - 2018-02-15 16:23:28 --> Security Class Initialized
DEBUG - 2018-02-15 16:23:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 16:23:28 --> Input Class Initialized
INFO - 2018-02-15 16:23:28 --> Language Class Initialized
INFO - 2018-02-15 16:23:28 --> Loader Class Initialized
INFO - 2018-02-15 16:23:28 --> Helper loaded: url_helper
INFO - 2018-02-15 16:23:28 --> Helper loaded: file_helper
INFO - 2018-02-15 16:23:28 --> Helper loaded: email_helper
INFO - 2018-02-15 16:23:28 --> Helper loaded: common_helper
INFO - 2018-02-15 16:23:28 --> Database Driver Class Initialized
DEBUG - 2018-02-15 16:23:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 16:23:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 16:23:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 16:23:28 --> Pagination Class Initialized
INFO - 2018-02-15 16:23:28 --> Helper loaded: form_helper
INFO - 2018-02-15 16:23:28 --> Form Validation Class Initialized
INFO - 2018-02-15 16:23:28 --> Model Class Initialized
INFO - 2018-02-15 16:23:28 --> Controller Class Initialized
INFO - 2018-02-15 16:23:28 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 16:23:28 --> Model Class Initialized
INFO - 2018-02-15 16:23:28 --> Model Class Initialized
INFO - 2018-02-15 16:23:28 --> Model Class Initialized
INFO - 2018-02-15 16:23:28 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-15 16:23:28 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-15 16:23:28 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-15 16:23:28 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-15 16:23:28 --> File loaded: /var/www/html/project/radio/application/views/tracks/add_edit.php
INFO - 2018-02-15 16:23:28 --> Final output sent to browser
DEBUG - 2018-02-15 16:23:28 --> Total execution time: 0.0048
INFO - 2018-02-15 16:23:35 --> Config Class Initialized
INFO - 2018-02-15 16:23:35 --> Hooks Class Initialized
DEBUG - 2018-02-15 16:23:35 --> UTF-8 Support Enabled
INFO - 2018-02-15 16:23:35 --> Utf8 Class Initialized
INFO - 2018-02-15 16:23:35 --> URI Class Initialized
INFO - 2018-02-15 16:23:35 --> Router Class Initialized
INFO - 2018-02-15 16:23:35 --> Output Class Initialized
INFO - 2018-02-15 16:23:35 --> Security Class Initialized
DEBUG - 2018-02-15 16:23:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 16:23:35 --> Input Class Initialized
INFO - 2018-02-15 16:23:35 --> Language Class Initialized
INFO - 2018-02-15 16:23:35 --> Loader Class Initialized
INFO - 2018-02-15 16:23:35 --> Helper loaded: url_helper
INFO - 2018-02-15 16:23:35 --> Helper loaded: file_helper
INFO - 2018-02-15 16:23:35 --> Helper loaded: email_helper
INFO - 2018-02-15 16:23:35 --> Helper loaded: common_helper
INFO - 2018-02-15 16:23:35 --> Database Driver Class Initialized
DEBUG - 2018-02-15 16:23:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 16:23:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 16:23:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 16:23:35 --> Pagination Class Initialized
INFO - 2018-02-15 16:23:35 --> Helper loaded: form_helper
INFO - 2018-02-15 16:23:35 --> Form Validation Class Initialized
INFO - 2018-02-15 16:23:35 --> Model Class Initialized
INFO - 2018-02-15 16:23:35 --> Controller Class Initialized
INFO - 2018-02-15 16:23:35 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 16:23:35 --> Model Class Initialized
INFO - 2018-02-15 16:23:35 --> Model Class Initialized
INFO - 2018-02-15 16:23:35 --> Model Class Initialized
INFO - 2018-02-15 16:23:35 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-15 16:23:35 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-15 16:23:35 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-15 16:23:35 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-15 16:23:35 --> File loaded: /var/www/html/project/radio/application/views/tracks/add_edit.php
INFO - 2018-02-15 16:23:35 --> Final output sent to browser
DEBUG - 2018-02-15 16:23:35 --> Total execution time: 0.0071
INFO - 2018-02-15 16:24:22 --> Config Class Initialized
INFO - 2018-02-15 16:24:22 --> Hooks Class Initialized
DEBUG - 2018-02-15 16:24:22 --> UTF-8 Support Enabled
INFO - 2018-02-15 16:24:22 --> Utf8 Class Initialized
INFO - 2018-02-15 16:24:22 --> URI Class Initialized
INFO - 2018-02-15 16:24:22 --> Router Class Initialized
INFO - 2018-02-15 16:24:22 --> Output Class Initialized
INFO - 2018-02-15 16:24:22 --> Security Class Initialized
DEBUG - 2018-02-15 16:24:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 16:24:22 --> Input Class Initialized
INFO - 2018-02-15 16:24:22 --> Language Class Initialized
INFO - 2018-02-15 16:24:22 --> Loader Class Initialized
INFO - 2018-02-15 16:24:22 --> Helper loaded: url_helper
INFO - 2018-02-15 16:24:22 --> Helper loaded: file_helper
INFO - 2018-02-15 16:24:22 --> Helper loaded: email_helper
INFO - 2018-02-15 16:24:22 --> Helper loaded: common_helper
INFO - 2018-02-15 16:24:22 --> Database Driver Class Initialized
DEBUG - 2018-02-15 16:24:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 16:24:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 16:24:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 16:24:22 --> Pagination Class Initialized
INFO - 2018-02-15 16:24:22 --> Helper loaded: form_helper
INFO - 2018-02-15 16:24:22 --> Form Validation Class Initialized
INFO - 2018-02-15 16:24:22 --> Model Class Initialized
INFO - 2018-02-15 16:24:22 --> Controller Class Initialized
INFO - 2018-02-15 16:24:22 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 16:24:22 --> Model Class Initialized
INFO - 2018-02-15 16:24:22 --> Model Class Initialized
INFO - 2018-02-15 16:24:22 --> Model Class Initialized
INFO - 2018-02-15 16:24:22 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-15 16:24:22 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-15 16:24:22 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-15 16:24:22 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-15 16:24:22 --> File loaded: /var/www/html/project/radio/application/views/tracks/add_edit.php
INFO - 2018-02-15 16:24:22 --> Final output sent to browser
DEBUG - 2018-02-15 16:24:22 --> Total execution time: 0.0055
INFO - 2018-02-15 16:24:36 --> Config Class Initialized
INFO - 2018-02-15 16:24:36 --> Hooks Class Initialized
DEBUG - 2018-02-15 16:24:36 --> UTF-8 Support Enabled
INFO - 2018-02-15 16:24:36 --> Utf8 Class Initialized
INFO - 2018-02-15 16:24:36 --> URI Class Initialized
INFO - 2018-02-15 16:24:36 --> Router Class Initialized
INFO - 2018-02-15 16:24:36 --> Output Class Initialized
INFO - 2018-02-15 16:24:36 --> Security Class Initialized
DEBUG - 2018-02-15 16:24:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 16:24:36 --> Input Class Initialized
INFO - 2018-02-15 16:24:36 --> Language Class Initialized
INFO - 2018-02-15 16:24:36 --> Loader Class Initialized
INFO - 2018-02-15 16:24:36 --> Helper loaded: url_helper
INFO - 2018-02-15 16:24:36 --> Helper loaded: file_helper
INFO - 2018-02-15 16:24:36 --> Helper loaded: email_helper
INFO - 2018-02-15 16:24:36 --> Helper loaded: common_helper
INFO - 2018-02-15 16:24:36 --> Database Driver Class Initialized
DEBUG - 2018-02-15 16:24:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 16:24:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 16:24:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 16:24:36 --> Pagination Class Initialized
INFO - 2018-02-15 16:24:36 --> Helper loaded: form_helper
INFO - 2018-02-15 16:24:36 --> Form Validation Class Initialized
INFO - 2018-02-15 16:24:36 --> Model Class Initialized
INFO - 2018-02-15 16:24:36 --> Controller Class Initialized
INFO - 2018-02-15 16:24:36 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 16:24:36 --> Model Class Initialized
INFO - 2018-02-15 16:24:36 --> Model Class Initialized
INFO - 2018-02-15 16:24:36 --> Model Class Initialized
INFO - 2018-02-15 16:24:36 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-15 16:24:36 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-15 16:24:36 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-15 16:24:36 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-15 16:24:36 --> File loaded: /var/www/html/project/radio/application/views/tracks/add_edit.php
INFO - 2018-02-15 16:24:36 --> Final output sent to browser
DEBUG - 2018-02-15 16:24:36 --> Total execution time: 0.0144
INFO - 2018-02-15 17:31:37 --> Config Class Initialized
INFO - 2018-02-15 17:31:37 --> Hooks Class Initialized
DEBUG - 2018-02-15 17:31:37 --> UTF-8 Support Enabled
INFO - 2018-02-15 17:31:37 --> Utf8 Class Initialized
INFO - 2018-02-15 17:31:37 --> URI Class Initialized
INFO - 2018-02-15 17:31:37 --> Router Class Initialized
INFO - 2018-02-15 17:31:37 --> Output Class Initialized
INFO - 2018-02-15 17:31:37 --> Security Class Initialized
DEBUG - 2018-02-15 17:31:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 17:31:37 --> Input Class Initialized
INFO - 2018-02-15 17:31:37 --> Language Class Initialized
INFO - 2018-02-15 17:31:37 --> Loader Class Initialized
INFO - 2018-02-15 17:31:37 --> Helper loaded: url_helper
INFO - 2018-02-15 17:31:37 --> Helper loaded: file_helper
INFO - 2018-02-15 17:31:37 --> Helper loaded: email_helper
INFO - 2018-02-15 17:31:37 --> Helper loaded: common_helper
INFO - 2018-02-15 17:31:37 --> Database Driver Class Initialized
DEBUG - 2018-02-15 17:31:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 17:31:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 17:31:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 17:31:37 --> Pagination Class Initialized
INFO - 2018-02-15 17:31:37 --> Helper loaded: form_helper
INFO - 2018-02-15 17:31:37 --> Form Validation Class Initialized
INFO - 2018-02-15 17:31:37 --> Model Class Initialized
INFO - 2018-02-15 17:31:37 --> Controller Class Initialized
INFO - 2018-02-15 17:31:37 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 17:31:37 --> Model Class Initialized
INFO - 2018-02-15 17:31:37 --> Model Class Initialized
INFO - 2018-02-15 17:31:37 --> Model Class Initialized
INFO - 2018-02-15 17:31:37 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-15 17:31:37 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-15 17:31:37 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-15 17:31:37 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-15 17:31:37 --> File loaded: /var/www/html/project/radio/application/views/tracks/add_edit.php
INFO - 2018-02-15 17:31:37 --> Final output sent to browser
DEBUG - 2018-02-15 17:31:37 --> Total execution time: 0.0085
INFO - 2018-02-15 17:32:39 --> Config Class Initialized
INFO - 2018-02-15 17:32:39 --> Hooks Class Initialized
DEBUG - 2018-02-15 17:32:39 --> UTF-8 Support Enabled
INFO - 2018-02-15 17:32:39 --> Utf8 Class Initialized
INFO - 2018-02-15 17:32:39 --> URI Class Initialized
INFO - 2018-02-15 17:32:39 --> Router Class Initialized
INFO - 2018-02-15 17:32:39 --> Output Class Initialized
INFO - 2018-02-15 17:32:39 --> Security Class Initialized
DEBUG - 2018-02-15 17:32:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 17:32:39 --> Input Class Initialized
INFO - 2018-02-15 17:32:39 --> Language Class Initialized
INFO - 2018-02-15 17:32:39 --> Loader Class Initialized
INFO - 2018-02-15 17:32:39 --> Helper loaded: url_helper
INFO - 2018-02-15 17:32:39 --> Helper loaded: file_helper
INFO - 2018-02-15 17:32:39 --> Helper loaded: email_helper
INFO - 2018-02-15 17:32:39 --> Helper loaded: common_helper
INFO - 2018-02-15 17:32:39 --> Database Driver Class Initialized
DEBUG - 2018-02-15 17:32:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 17:32:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 17:32:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 17:32:39 --> Pagination Class Initialized
INFO - 2018-02-15 17:32:39 --> Helper loaded: form_helper
INFO - 2018-02-15 17:32:39 --> Form Validation Class Initialized
INFO - 2018-02-15 17:32:39 --> Model Class Initialized
INFO - 2018-02-15 17:32:39 --> Controller Class Initialized
INFO - 2018-02-15 17:32:39 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 17:32:39 --> Model Class Initialized
INFO - 2018-02-15 17:32:39 --> Model Class Initialized
INFO - 2018-02-15 17:32:39 --> Model Class Initialized
INFO - 2018-02-15 17:32:39 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-15 17:32:39 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-15 17:32:39 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-15 17:32:39 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-15 17:32:39 --> File loaded: /var/www/html/project/radio/application/views/tracks/add_edit.php
INFO - 2018-02-15 17:32:39 --> Final output sent to browser
DEBUG - 2018-02-15 17:32:39 --> Total execution time: 0.0059
INFO - 2018-02-15 17:42:20 --> Config Class Initialized
INFO - 2018-02-15 17:42:20 --> Hooks Class Initialized
DEBUG - 2018-02-15 17:42:20 --> UTF-8 Support Enabled
INFO - 2018-02-15 17:42:20 --> Utf8 Class Initialized
INFO - 2018-02-15 17:42:20 --> URI Class Initialized
INFO - 2018-02-15 17:42:20 --> Router Class Initialized
INFO - 2018-02-15 17:42:20 --> Output Class Initialized
INFO - 2018-02-15 17:42:20 --> Security Class Initialized
DEBUG - 2018-02-15 17:42:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 17:42:20 --> Input Class Initialized
INFO - 2018-02-15 17:42:20 --> Language Class Initialized
INFO - 2018-02-15 17:42:20 --> Loader Class Initialized
INFO - 2018-02-15 17:42:20 --> Helper loaded: url_helper
INFO - 2018-02-15 17:42:20 --> Helper loaded: file_helper
INFO - 2018-02-15 17:42:20 --> Helper loaded: email_helper
INFO - 2018-02-15 17:42:20 --> Helper loaded: common_helper
INFO - 2018-02-15 17:42:20 --> Database Driver Class Initialized
DEBUG - 2018-02-15 17:42:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 17:42:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 17:42:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 17:42:20 --> Pagination Class Initialized
INFO - 2018-02-15 17:42:20 --> Helper loaded: form_helper
INFO - 2018-02-15 17:42:20 --> Form Validation Class Initialized
INFO - 2018-02-15 17:42:20 --> Model Class Initialized
INFO - 2018-02-15 17:42:20 --> Controller Class Initialized
INFO - 2018-02-15 17:42:20 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 17:42:20 --> Model Class Initialized
INFO - 2018-02-15 17:42:20 --> Model Class Initialized
INFO - 2018-02-15 17:42:20 --> Model Class Initialized
INFO - 2018-02-15 17:42:20 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-15 17:42:20 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-15 17:42:20 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
ERROR - 2018-02-15 17:42:20 --> Severity: Notice --> Undefined variable: track /var/www/html/project/radio/application/views/tracks/add_edit.php 166
ERROR - 2018-02-15 17:42:20 --> Severity: Notice --> Undefined variable: track /var/www/html/project/radio/application/views/tracks/add_edit.php 167
INFO - 2018-02-15 17:42:20 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-15 17:42:20 --> File loaded: /var/www/html/project/radio/application/views/tracks/add_edit.php
INFO - 2018-02-15 17:42:20 --> Final output sent to browser
DEBUG - 2018-02-15 17:42:20 --> Total execution time: 0.0058
INFO - 2018-02-15 17:43:35 --> Config Class Initialized
INFO - 2018-02-15 17:43:35 --> Hooks Class Initialized
DEBUG - 2018-02-15 17:43:35 --> UTF-8 Support Enabled
INFO - 2018-02-15 17:43:35 --> Utf8 Class Initialized
INFO - 2018-02-15 17:43:35 --> URI Class Initialized
INFO - 2018-02-15 17:43:35 --> Router Class Initialized
INFO - 2018-02-15 17:43:35 --> Output Class Initialized
INFO - 2018-02-15 17:43:35 --> Security Class Initialized
DEBUG - 2018-02-15 17:43:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 17:43:35 --> Input Class Initialized
INFO - 2018-02-15 17:43:35 --> Language Class Initialized
INFO - 2018-02-15 17:43:35 --> Loader Class Initialized
INFO - 2018-02-15 17:43:35 --> Helper loaded: url_helper
INFO - 2018-02-15 17:43:35 --> Helper loaded: file_helper
INFO - 2018-02-15 17:43:35 --> Helper loaded: email_helper
INFO - 2018-02-15 17:43:35 --> Helper loaded: common_helper
INFO - 2018-02-15 17:43:35 --> Database Driver Class Initialized
DEBUG - 2018-02-15 17:43:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 17:43:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 17:43:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 17:43:35 --> Pagination Class Initialized
INFO - 2018-02-15 17:43:35 --> Helper loaded: form_helper
INFO - 2018-02-15 17:43:35 --> Form Validation Class Initialized
INFO - 2018-02-15 17:43:35 --> Model Class Initialized
INFO - 2018-02-15 17:43:35 --> Controller Class Initialized
INFO - 2018-02-15 17:43:35 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 17:43:35 --> Model Class Initialized
INFO - 2018-02-15 17:43:35 --> Model Class Initialized
INFO - 2018-02-15 17:43:35 --> Model Class Initialized
INFO - 2018-02-15 17:43:35 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-15 17:43:35 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-15 17:43:35 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-15 17:43:35 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-15 17:43:35 --> File loaded: /var/www/html/project/radio/application/views/tracks/add_edit.php
INFO - 2018-02-15 17:43:35 --> Final output sent to browser
DEBUG - 2018-02-15 17:43:35 --> Total execution time: 0.0049
INFO - 2018-02-15 17:44:21 --> Config Class Initialized
INFO - 2018-02-15 17:44:21 --> Hooks Class Initialized
DEBUG - 2018-02-15 17:44:21 --> UTF-8 Support Enabled
INFO - 2018-02-15 17:44:21 --> Utf8 Class Initialized
INFO - 2018-02-15 17:44:21 --> URI Class Initialized
INFO - 2018-02-15 17:44:21 --> Router Class Initialized
INFO - 2018-02-15 17:44:21 --> Output Class Initialized
INFO - 2018-02-15 17:44:21 --> Security Class Initialized
DEBUG - 2018-02-15 17:44:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 17:44:21 --> Input Class Initialized
INFO - 2018-02-15 17:44:21 --> Language Class Initialized
INFO - 2018-02-15 17:44:21 --> Loader Class Initialized
INFO - 2018-02-15 17:44:21 --> Helper loaded: url_helper
INFO - 2018-02-15 17:44:21 --> Helper loaded: file_helper
INFO - 2018-02-15 17:44:21 --> Helper loaded: email_helper
INFO - 2018-02-15 17:44:21 --> Helper loaded: common_helper
INFO - 2018-02-15 17:44:21 --> Database Driver Class Initialized
DEBUG - 2018-02-15 17:44:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 17:44:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 17:44:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 17:44:21 --> Pagination Class Initialized
INFO - 2018-02-15 17:44:21 --> Helper loaded: form_helper
INFO - 2018-02-15 17:44:21 --> Form Validation Class Initialized
INFO - 2018-02-15 17:44:21 --> Model Class Initialized
INFO - 2018-02-15 17:44:21 --> Controller Class Initialized
INFO - 2018-02-15 17:44:21 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 17:44:21 --> Model Class Initialized
INFO - 2018-02-15 17:44:21 --> Model Class Initialized
INFO - 2018-02-15 17:44:21 --> Model Class Initialized
INFO - 2018-02-15 17:44:52 --> Config Class Initialized
INFO - 2018-02-15 17:44:52 --> Hooks Class Initialized
DEBUG - 2018-02-15 17:44:52 --> UTF-8 Support Enabled
INFO - 2018-02-15 17:44:52 --> Utf8 Class Initialized
INFO - 2018-02-15 17:44:52 --> URI Class Initialized
INFO - 2018-02-15 17:44:52 --> Router Class Initialized
INFO - 2018-02-15 17:44:52 --> Output Class Initialized
INFO - 2018-02-15 17:44:52 --> Security Class Initialized
DEBUG - 2018-02-15 17:44:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 17:44:52 --> Input Class Initialized
INFO - 2018-02-15 17:44:52 --> Language Class Initialized
INFO - 2018-02-15 17:44:52 --> Loader Class Initialized
INFO - 2018-02-15 17:44:52 --> Helper loaded: url_helper
INFO - 2018-02-15 17:44:52 --> Helper loaded: file_helper
INFO - 2018-02-15 17:44:52 --> Helper loaded: email_helper
INFO - 2018-02-15 17:44:52 --> Helper loaded: common_helper
INFO - 2018-02-15 17:44:52 --> Database Driver Class Initialized
DEBUG - 2018-02-15 17:44:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 17:44:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 17:44:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 17:44:52 --> Pagination Class Initialized
INFO - 2018-02-15 17:44:52 --> Helper loaded: form_helper
INFO - 2018-02-15 17:44:52 --> Form Validation Class Initialized
INFO - 2018-02-15 17:44:52 --> Model Class Initialized
INFO - 2018-02-15 17:44:52 --> Controller Class Initialized
INFO - 2018-02-15 17:44:52 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 17:44:52 --> Model Class Initialized
INFO - 2018-02-15 17:44:52 --> Model Class Initialized
INFO - 2018-02-15 17:44:52 --> Model Class Initialized
INFO - 2018-02-15 17:44:58 --> Config Class Initialized
INFO - 2018-02-15 17:44:58 --> Hooks Class Initialized
DEBUG - 2018-02-15 17:44:58 --> UTF-8 Support Enabled
INFO - 2018-02-15 17:44:58 --> Utf8 Class Initialized
INFO - 2018-02-15 17:44:58 --> URI Class Initialized
INFO - 2018-02-15 17:44:58 --> Router Class Initialized
INFO - 2018-02-15 17:44:58 --> Output Class Initialized
INFO - 2018-02-15 17:44:58 --> Security Class Initialized
DEBUG - 2018-02-15 17:44:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 17:44:58 --> Input Class Initialized
INFO - 2018-02-15 17:44:58 --> Language Class Initialized
INFO - 2018-02-15 17:44:58 --> Loader Class Initialized
INFO - 2018-02-15 17:44:58 --> Helper loaded: url_helper
INFO - 2018-02-15 17:44:58 --> Helper loaded: file_helper
INFO - 2018-02-15 17:44:58 --> Helper loaded: email_helper
INFO - 2018-02-15 17:44:58 --> Helper loaded: common_helper
INFO - 2018-02-15 17:44:58 --> Database Driver Class Initialized
DEBUG - 2018-02-15 17:44:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 17:44:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 17:44:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 17:44:58 --> Pagination Class Initialized
INFO - 2018-02-15 17:44:58 --> Helper loaded: form_helper
INFO - 2018-02-15 17:44:58 --> Form Validation Class Initialized
INFO - 2018-02-15 17:44:58 --> Model Class Initialized
INFO - 2018-02-15 17:44:58 --> Controller Class Initialized
INFO - 2018-02-15 17:44:58 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 17:44:58 --> Model Class Initialized
INFO - 2018-02-15 17:44:58 --> Model Class Initialized
INFO - 2018-02-15 17:44:58 --> Model Class Initialized
INFO - 2018-02-15 17:44:58 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-15 17:44:58 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-15 17:44:58 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-15 17:44:58 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-15 17:44:58 --> File loaded: /var/www/html/project/radio/application/views/tracks/add_edit.php
INFO - 2018-02-15 17:44:58 --> Final output sent to browser
DEBUG - 2018-02-15 17:44:58 --> Total execution time: 0.0052
INFO - 2018-02-15 17:45:00 --> Config Class Initialized
INFO - 2018-02-15 17:45:00 --> Hooks Class Initialized
DEBUG - 2018-02-15 17:45:00 --> UTF-8 Support Enabled
INFO - 2018-02-15 17:45:00 --> Utf8 Class Initialized
INFO - 2018-02-15 17:45:00 --> URI Class Initialized
INFO - 2018-02-15 17:45:00 --> Router Class Initialized
INFO - 2018-02-15 17:45:00 --> Output Class Initialized
INFO - 2018-02-15 17:45:00 --> Security Class Initialized
DEBUG - 2018-02-15 17:45:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 17:45:00 --> Input Class Initialized
INFO - 2018-02-15 17:45:00 --> Language Class Initialized
INFO - 2018-02-15 17:45:00 --> Loader Class Initialized
INFO - 2018-02-15 17:45:00 --> Helper loaded: url_helper
INFO - 2018-02-15 17:45:00 --> Helper loaded: file_helper
INFO - 2018-02-15 17:45:00 --> Helper loaded: email_helper
INFO - 2018-02-15 17:45:00 --> Helper loaded: common_helper
INFO - 2018-02-15 17:45:00 --> Database Driver Class Initialized
DEBUG - 2018-02-15 17:45:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 17:45:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 17:45:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 17:45:00 --> Pagination Class Initialized
INFO - 2018-02-15 17:45:00 --> Helper loaded: form_helper
INFO - 2018-02-15 17:45:00 --> Form Validation Class Initialized
INFO - 2018-02-15 17:45:00 --> Model Class Initialized
INFO - 2018-02-15 17:45:00 --> Controller Class Initialized
INFO - 2018-02-15 17:45:00 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 17:45:00 --> Model Class Initialized
INFO - 2018-02-15 17:45:00 --> Model Class Initialized
INFO - 2018-02-15 17:45:00 --> Model Class Initialized
INFO - 2018-02-15 17:45:07 --> Config Class Initialized
INFO - 2018-02-15 17:45:07 --> Hooks Class Initialized
DEBUG - 2018-02-15 17:45:07 --> UTF-8 Support Enabled
INFO - 2018-02-15 17:45:07 --> Utf8 Class Initialized
INFO - 2018-02-15 17:45:07 --> URI Class Initialized
INFO - 2018-02-15 17:45:07 --> Router Class Initialized
INFO - 2018-02-15 17:45:07 --> Output Class Initialized
INFO - 2018-02-15 17:45:07 --> Security Class Initialized
DEBUG - 2018-02-15 17:45:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 17:45:07 --> Input Class Initialized
INFO - 2018-02-15 17:45:07 --> Language Class Initialized
INFO - 2018-02-15 17:45:07 --> Loader Class Initialized
INFO - 2018-02-15 17:45:07 --> Helper loaded: url_helper
INFO - 2018-02-15 17:45:07 --> Helper loaded: file_helper
INFO - 2018-02-15 17:45:07 --> Helper loaded: email_helper
INFO - 2018-02-15 17:45:07 --> Helper loaded: common_helper
INFO - 2018-02-15 17:45:07 --> Database Driver Class Initialized
DEBUG - 2018-02-15 17:45:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 17:45:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 17:45:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 17:45:07 --> Pagination Class Initialized
INFO - 2018-02-15 17:45:07 --> Helper loaded: form_helper
INFO - 2018-02-15 17:45:07 --> Form Validation Class Initialized
INFO - 2018-02-15 17:45:07 --> Model Class Initialized
INFO - 2018-02-15 17:45:07 --> Controller Class Initialized
INFO - 2018-02-15 17:45:07 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 17:45:07 --> Model Class Initialized
INFO - 2018-02-15 17:45:07 --> Model Class Initialized
INFO - 2018-02-15 17:45:07 --> Model Class Initialized
INFO - 2018-02-15 17:45:08 --> Config Class Initialized
INFO - 2018-02-15 17:45:08 --> Hooks Class Initialized
DEBUG - 2018-02-15 17:45:08 --> UTF-8 Support Enabled
INFO - 2018-02-15 17:45:08 --> Utf8 Class Initialized
INFO - 2018-02-15 17:45:08 --> URI Class Initialized
INFO - 2018-02-15 17:45:08 --> Router Class Initialized
INFO - 2018-02-15 17:45:08 --> Output Class Initialized
INFO - 2018-02-15 17:45:08 --> Security Class Initialized
DEBUG - 2018-02-15 17:45:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 17:45:08 --> Input Class Initialized
INFO - 2018-02-15 17:45:08 --> Language Class Initialized
INFO - 2018-02-15 17:45:08 --> Loader Class Initialized
INFO - 2018-02-15 17:45:08 --> Helper loaded: url_helper
INFO - 2018-02-15 17:45:08 --> Helper loaded: file_helper
INFO - 2018-02-15 17:45:08 --> Helper loaded: email_helper
INFO - 2018-02-15 17:45:08 --> Helper loaded: common_helper
INFO - 2018-02-15 17:45:08 --> Database Driver Class Initialized
DEBUG - 2018-02-15 17:45:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 17:45:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 17:45:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 17:45:08 --> Pagination Class Initialized
INFO - 2018-02-15 17:45:08 --> Helper loaded: form_helper
INFO - 2018-02-15 17:45:08 --> Form Validation Class Initialized
INFO - 2018-02-15 17:45:08 --> Model Class Initialized
INFO - 2018-02-15 17:45:08 --> Controller Class Initialized
INFO - 2018-02-15 17:45:08 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 17:45:08 --> Model Class Initialized
INFO - 2018-02-15 17:45:08 --> Model Class Initialized
INFO - 2018-02-15 17:45:08 --> Model Class Initialized
INFO - 2018-02-15 17:45:08 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-15 17:45:08 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-15 17:45:08 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-15 17:45:08 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-15 17:45:08 --> File loaded: /var/www/html/project/radio/application/views/tracks/add_edit.php
INFO - 2018-02-15 17:45:08 --> Final output sent to browser
DEBUG - 2018-02-15 17:45:08 --> Total execution time: 0.0058
INFO - 2018-02-15 17:45:26 --> Config Class Initialized
INFO - 2018-02-15 17:45:26 --> Hooks Class Initialized
DEBUG - 2018-02-15 17:45:26 --> UTF-8 Support Enabled
INFO - 2018-02-15 17:45:26 --> Utf8 Class Initialized
INFO - 2018-02-15 17:45:26 --> URI Class Initialized
INFO - 2018-02-15 17:45:26 --> Router Class Initialized
INFO - 2018-02-15 17:45:26 --> Output Class Initialized
INFO - 2018-02-15 17:45:26 --> Security Class Initialized
DEBUG - 2018-02-15 17:45:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 17:45:26 --> Input Class Initialized
INFO - 2018-02-15 17:45:26 --> Language Class Initialized
INFO - 2018-02-15 17:45:26 --> Loader Class Initialized
INFO - 2018-02-15 17:45:26 --> Helper loaded: url_helper
INFO - 2018-02-15 17:45:26 --> Helper loaded: file_helper
INFO - 2018-02-15 17:45:26 --> Helper loaded: email_helper
INFO - 2018-02-15 17:45:26 --> Helper loaded: common_helper
INFO - 2018-02-15 17:45:26 --> Database Driver Class Initialized
DEBUG - 2018-02-15 17:45:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 17:45:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 17:45:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 17:45:26 --> Pagination Class Initialized
INFO - 2018-02-15 17:45:26 --> Helper loaded: form_helper
INFO - 2018-02-15 17:45:26 --> Form Validation Class Initialized
INFO - 2018-02-15 17:45:26 --> Model Class Initialized
INFO - 2018-02-15 17:45:26 --> Controller Class Initialized
INFO - 2018-02-15 17:45:26 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 17:45:26 --> Model Class Initialized
INFO - 2018-02-15 17:45:26 --> Model Class Initialized
INFO - 2018-02-15 17:45:26 --> Model Class Initialized
INFO - 2018-02-15 17:45:42 --> Config Class Initialized
INFO - 2018-02-15 17:45:42 --> Hooks Class Initialized
DEBUG - 2018-02-15 17:45:42 --> UTF-8 Support Enabled
INFO - 2018-02-15 17:45:42 --> Utf8 Class Initialized
INFO - 2018-02-15 17:45:42 --> URI Class Initialized
INFO - 2018-02-15 17:45:42 --> Router Class Initialized
INFO - 2018-02-15 17:45:42 --> Output Class Initialized
INFO - 2018-02-15 17:45:42 --> Security Class Initialized
DEBUG - 2018-02-15 17:45:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 17:45:42 --> Input Class Initialized
INFO - 2018-02-15 17:45:42 --> Language Class Initialized
INFO - 2018-02-15 17:45:42 --> Loader Class Initialized
INFO - 2018-02-15 17:45:42 --> Helper loaded: url_helper
INFO - 2018-02-15 17:45:42 --> Helper loaded: file_helper
INFO - 2018-02-15 17:45:42 --> Helper loaded: email_helper
INFO - 2018-02-15 17:45:42 --> Helper loaded: common_helper
INFO - 2018-02-15 17:45:42 --> Database Driver Class Initialized
DEBUG - 2018-02-15 17:45:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 17:45:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 17:45:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 17:45:42 --> Pagination Class Initialized
INFO - 2018-02-15 17:45:42 --> Helper loaded: form_helper
INFO - 2018-02-15 17:45:42 --> Form Validation Class Initialized
INFO - 2018-02-15 17:45:42 --> Model Class Initialized
INFO - 2018-02-15 17:45:42 --> Controller Class Initialized
INFO - 2018-02-15 17:45:42 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 17:45:42 --> Model Class Initialized
INFO - 2018-02-15 17:45:42 --> Model Class Initialized
INFO - 2018-02-15 17:45:42 --> Model Class Initialized
INFO - 2018-02-15 17:46:56 --> Config Class Initialized
INFO - 2018-02-15 17:46:56 --> Hooks Class Initialized
DEBUG - 2018-02-15 17:46:56 --> UTF-8 Support Enabled
INFO - 2018-02-15 17:46:56 --> Utf8 Class Initialized
INFO - 2018-02-15 17:46:56 --> URI Class Initialized
INFO - 2018-02-15 17:46:56 --> Router Class Initialized
INFO - 2018-02-15 17:46:56 --> Output Class Initialized
INFO - 2018-02-15 17:46:56 --> Security Class Initialized
DEBUG - 2018-02-15 17:46:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 17:46:56 --> Input Class Initialized
INFO - 2018-02-15 17:46:56 --> Language Class Initialized
INFO - 2018-02-15 17:46:56 --> Loader Class Initialized
INFO - 2018-02-15 17:46:56 --> Helper loaded: url_helper
INFO - 2018-02-15 17:46:56 --> Helper loaded: file_helper
INFO - 2018-02-15 17:46:56 --> Helper loaded: email_helper
INFO - 2018-02-15 17:46:56 --> Helper loaded: common_helper
INFO - 2018-02-15 17:46:56 --> Database Driver Class Initialized
DEBUG - 2018-02-15 17:46:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 17:46:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 17:46:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 17:46:56 --> Pagination Class Initialized
INFO - 2018-02-15 17:46:56 --> Helper loaded: form_helper
INFO - 2018-02-15 17:46:56 --> Form Validation Class Initialized
INFO - 2018-02-15 17:46:56 --> Model Class Initialized
INFO - 2018-02-15 17:46:56 --> Controller Class Initialized
INFO - 2018-02-15 17:46:56 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 17:46:56 --> Model Class Initialized
INFO - 2018-02-15 17:46:56 --> Model Class Initialized
INFO - 2018-02-15 17:46:56 --> Model Class Initialized
INFO - 2018-02-15 17:46:56 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-15 17:46:56 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-15 17:46:56 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-15 17:46:56 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-15 17:46:56 --> File loaded: /var/www/html/project/radio/application/views/tracks/add_edit.php
INFO - 2018-02-15 17:46:56 --> Final output sent to browser
DEBUG - 2018-02-15 17:46:56 --> Total execution time: 0.0058
INFO - 2018-02-15 17:48:54 --> Config Class Initialized
INFO - 2018-02-15 17:48:54 --> Hooks Class Initialized
DEBUG - 2018-02-15 17:48:54 --> UTF-8 Support Enabled
INFO - 2018-02-15 17:48:54 --> Utf8 Class Initialized
INFO - 2018-02-15 17:48:54 --> URI Class Initialized
INFO - 2018-02-15 17:48:54 --> Router Class Initialized
INFO - 2018-02-15 17:48:54 --> Output Class Initialized
INFO - 2018-02-15 17:48:54 --> Security Class Initialized
DEBUG - 2018-02-15 17:48:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 17:48:54 --> Input Class Initialized
INFO - 2018-02-15 17:48:54 --> Language Class Initialized
INFO - 2018-02-15 17:48:54 --> Loader Class Initialized
INFO - 2018-02-15 17:48:54 --> Helper loaded: url_helper
INFO - 2018-02-15 17:48:54 --> Helper loaded: file_helper
INFO - 2018-02-15 17:48:54 --> Helper loaded: email_helper
INFO - 2018-02-15 17:48:54 --> Helper loaded: common_helper
INFO - 2018-02-15 17:48:54 --> Database Driver Class Initialized
DEBUG - 2018-02-15 17:48:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 17:48:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 17:48:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 17:48:54 --> Pagination Class Initialized
INFO - 2018-02-15 17:48:54 --> Helper loaded: form_helper
INFO - 2018-02-15 17:48:54 --> Form Validation Class Initialized
INFO - 2018-02-15 17:48:54 --> Model Class Initialized
INFO - 2018-02-15 17:48:54 --> Controller Class Initialized
INFO - 2018-02-15 17:48:54 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 17:48:54 --> Model Class Initialized
INFO - 2018-02-15 17:48:54 --> Model Class Initialized
INFO - 2018-02-15 17:48:54 --> Model Class Initialized
INFO - 2018-02-15 17:48:54 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-15 17:48:54 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-15 17:48:54 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-15 17:48:54 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-15 17:48:54 --> File loaded: /var/www/html/project/radio/application/views/tracks/add_edit.php
INFO - 2018-02-15 17:48:54 --> Final output sent to browser
DEBUG - 2018-02-15 17:48:54 --> Total execution time: 0.0124
INFO - 2018-02-15 17:50:34 --> Config Class Initialized
INFO - 2018-02-15 17:50:34 --> Hooks Class Initialized
DEBUG - 2018-02-15 17:50:34 --> UTF-8 Support Enabled
INFO - 2018-02-15 17:50:34 --> Utf8 Class Initialized
INFO - 2018-02-15 17:50:34 --> URI Class Initialized
INFO - 2018-02-15 17:50:34 --> Router Class Initialized
INFO - 2018-02-15 17:50:34 --> Output Class Initialized
INFO - 2018-02-15 17:50:34 --> Security Class Initialized
DEBUG - 2018-02-15 17:50:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 17:50:34 --> Input Class Initialized
INFO - 2018-02-15 17:50:34 --> Language Class Initialized
INFO - 2018-02-15 17:50:34 --> Loader Class Initialized
INFO - 2018-02-15 17:50:34 --> Helper loaded: url_helper
INFO - 2018-02-15 17:50:34 --> Helper loaded: file_helper
INFO - 2018-02-15 17:50:34 --> Helper loaded: email_helper
INFO - 2018-02-15 17:50:34 --> Helper loaded: common_helper
INFO - 2018-02-15 17:50:34 --> Database Driver Class Initialized
DEBUG - 2018-02-15 17:50:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 17:50:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 17:50:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 17:50:34 --> Pagination Class Initialized
INFO - 2018-02-15 17:50:34 --> Helper loaded: form_helper
INFO - 2018-02-15 17:50:34 --> Form Validation Class Initialized
INFO - 2018-02-15 17:50:34 --> Model Class Initialized
INFO - 2018-02-15 17:50:34 --> Controller Class Initialized
INFO - 2018-02-15 17:50:34 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 17:50:34 --> Model Class Initialized
INFO - 2018-02-15 17:50:34 --> Model Class Initialized
INFO - 2018-02-15 17:50:34 --> Model Class Initialized
INFO - 2018-02-15 17:50:34 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-15 17:50:34 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-15 17:50:34 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-15 17:50:34 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-15 17:50:34 --> File loaded: /var/www/html/project/radio/application/views/tracks/add_edit.php
INFO - 2018-02-15 17:50:34 --> Final output sent to browser
DEBUG - 2018-02-15 17:50:34 --> Total execution time: 0.0065
INFO - 2018-02-15 17:50:43 --> Config Class Initialized
INFO - 2018-02-15 17:50:43 --> Hooks Class Initialized
DEBUG - 2018-02-15 17:50:43 --> UTF-8 Support Enabled
INFO - 2018-02-15 17:50:43 --> Utf8 Class Initialized
INFO - 2018-02-15 17:50:43 --> URI Class Initialized
INFO - 2018-02-15 17:50:43 --> Router Class Initialized
INFO - 2018-02-15 17:50:43 --> Output Class Initialized
INFO - 2018-02-15 17:50:43 --> Security Class Initialized
DEBUG - 2018-02-15 17:50:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 17:50:43 --> Input Class Initialized
INFO - 2018-02-15 17:50:43 --> Language Class Initialized
INFO - 2018-02-15 17:50:43 --> Loader Class Initialized
INFO - 2018-02-15 17:50:43 --> Helper loaded: url_helper
INFO - 2018-02-15 17:50:43 --> Helper loaded: file_helper
INFO - 2018-02-15 17:50:43 --> Helper loaded: email_helper
INFO - 2018-02-15 17:50:43 --> Helper loaded: common_helper
INFO - 2018-02-15 17:50:43 --> Database Driver Class Initialized
DEBUG - 2018-02-15 17:50:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 17:50:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 17:50:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 17:50:43 --> Pagination Class Initialized
INFO - 2018-02-15 17:50:43 --> Helper loaded: form_helper
INFO - 2018-02-15 17:50:43 --> Form Validation Class Initialized
INFO - 2018-02-15 17:50:43 --> Model Class Initialized
INFO - 2018-02-15 17:50:43 --> Controller Class Initialized
INFO - 2018-02-15 17:50:43 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 17:50:43 --> Model Class Initialized
INFO - 2018-02-15 17:50:43 --> Model Class Initialized
INFO - 2018-02-15 17:50:43 --> Model Class Initialized
INFO - 2018-02-15 17:50:54 --> Config Class Initialized
INFO - 2018-02-15 17:50:54 --> Hooks Class Initialized
DEBUG - 2018-02-15 17:50:54 --> UTF-8 Support Enabled
INFO - 2018-02-15 17:50:54 --> Utf8 Class Initialized
INFO - 2018-02-15 17:50:54 --> URI Class Initialized
INFO - 2018-02-15 17:50:54 --> Router Class Initialized
INFO - 2018-02-15 17:50:54 --> Output Class Initialized
INFO - 2018-02-15 17:50:54 --> Security Class Initialized
DEBUG - 2018-02-15 17:50:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 17:50:54 --> Input Class Initialized
INFO - 2018-02-15 17:50:54 --> Language Class Initialized
INFO - 2018-02-15 17:50:54 --> Loader Class Initialized
INFO - 2018-02-15 17:50:54 --> Helper loaded: url_helper
INFO - 2018-02-15 17:50:54 --> Helper loaded: file_helper
INFO - 2018-02-15 17:50:54 --> Helper loaded: email_helper
INFO - 2018-02-15 17:50:54 --> Helper loaded: common_helper
INFO - 2018-02-15 17:50:54 --> Database Driver Class Initialized
DEBUG - 2018-02-15 17:50:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 17:50:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 17:50:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 17:50:54 --> Pagination Class Initialized
INFO - 2018-02-15 17:50:54 --> Helper loaded: form_helper
INFO - 2018-02-15 17:50:54 --> Form Validation Class Initialized
INFO - 2018-02-15 17:50:54 --> Model Class Initialized
INFO - 2018-02-15 17:50:54 --> Controller Class Initialized
INFO - 2018-02-15 17:50:54 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 17:50:54 --> Model Class Initialized
INFO - 2018-02-15 17:50:54 --> Model Class Initialized
INFO - 2018-02-15 17:50:54 --> Model Class Initialized
INFO - 2018-02-15 17:50:55 --> Config Class Initialized
INFO - 2018-02-15 17:50:55 --> Hooks Class Initialized
DEBUG - 2018-02-15 17:50:55 --> UTF-8 Support Enabled
INFO - 2018-02-15 17:50:55 --> Utf8 Class Initialized
INFO - 2018-02-15 17:50:55 --> URI Class Initialized
INFO - 2018-02-15 17:50:55 --> Router Class Initialized
INFO - 2018-02-15 17:50:55 --> Output Class Initialized
INFO - 2018-02-15 17:50:55 --> Security Class Initialized
DEBUG - 2018-02-15 17:50:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 17:50:55 --> Input Class Initialized
INFO - 2018-02-15 17:50:55 --> Language Class Initialized
INFO - 2018-02-15 17:50:55 --> Loader Class Initialized
INFO - 2018-02-15 17:50:55 --> Helper loaded: url_helper
INFO - 2018-02-15 17:50:55 --> Helper loaded: file_helper
INFO - 2018-02-15 17:50:55 --> Helper loaded: email_helper
INFO - 2018-02-15 17:50:55 --> Helper loaded: common_helper
INFO - 2018-02-15 17:50:55 --> Database Driver Class Initialized
DEBUG - 2018-02-15 17:50:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 17:50:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 17:50:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 17:50:55 --> Pagination Class Initialized
INFO - 2018-02-15 17:50:55 --> Helper loaded: form_helper
INFO - 2018-02-15 17:50:55 --> Form Validation Class Initialized
INFO - 2018-02-15 17:50:55 --> Model Class Initialized
INFO - 2018-02-15 17:50:55 --> Controller Class Initialized
INFO - 2018-02-15 17:50:55 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 17:50:55 --> Model Class Initialized
INFO - 2018-02-15 17:50:55 --> Model Class Initialized
INFO - 2018-02-15 17:50:55 --> Model Class Initialized
INFO - 2018-02-15 17:50:55 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-15 17:50:55 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-15 17:50:55 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-15 17:50:55 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-15 17:50:55 --> File loaded: /var/www/html/project/radio/application/views/tracks/add_edit.php
INFO - 2018-02-15 17:50:55 --> Final output sent to browser
DEBUG - 2018-02-15 17:50:55 --> Total execution time: 0.0053
INFO - 2018-02-15 17:50:57 --> Config Class Initialized
INFO - 2018-02-15 17:50:57 --> Hooks Class Initialized
DEBUG - 2018-02-15 17:50:57 --> UTF-8 Support Enabled
INFO - 2018-02-15 17:50:57 --> Utf8 Class Initialized
INFO - 2018-02-15 17:50:57 --> URI Class Initialized
INFO - 2018-02-15 17:50:57 --> Router Class Initialized
INFO - 2018-02-15 17:50:57 --> Output Class Initialized
INFO - 2018-02-15 17:50:57 --> Security Class Initialized
DEBUG - 2018-02-15 17:50:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 17:50:57 --> Input Class Initialized
INFO - 2018-02-15 17:50:57 --> Language Class Initialized
INFO - 2018-02-15 17:50:57 --> Loader Class Initialized
INFO - 2018-02-15 17:50:57 --> Helper loaded: url_helper
INFO - 2018-02-15 17:50:57 --> Helper loaded: file_helper
INFO - 2018-02-15 17:50:57 --> Helper loaded: email_helper
INFO - 2018-02-15 17:50:57 --> Helper loaded: common_helper
INFO - 2018-02-15 17:50:57 --> Database Driver Class Initialized
DEBUG - 2018-02-15 17:50:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 17:50:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 17:50:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 17:50:57 --> Pagination Class Initialized
INFO - 2018-02-15 17:50:57 --> Helper loaded: form_helper
INFO - 2018-02-15 17:50:57 --> Form Validation Class Initialized
INFO - 2018-02-15 17:50:57 --> Model Class Initialized
INFO - 2018-02-15 17:50:57 --> Controller Class Initialized
INFO - 2018-02-15 17:50:57 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 17:50:57 --> Model Class Initialized
INFO - 2018-02-15 17:50:57 --> Model Class Initialized
INFO - 2018-02-15 17:50:57 --> Model Class Initialized
INFO - 2018-02-15 17:51:10 --> Config Class Initialized
INFO - 2018-02-15 17:51:10 --> Hooks Class Initialized
DEBUG - 2018-02-15 17:51:10 --> UTF-8 Support Enabled
INFO - 2018-02-15 17:51:10 --> Utf8 Class Initialized
INFO - 2018-02-15 17:51:10 --> URI Class Initialized
INFO - 2018-02-15 17:51:10 --> Router Class Initialized
INFO - 2018-02-15 17:51:10 --> Output Class Initialized
INFO - 2018-02-15 17:51:10 --> Security Class Initialized
DEBUG - 2018-02-15 17:51:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 17:51:10 --> Input Class Initialized
INFO - 2018-02-15 17:51:10 --> Language Class Initialized
INFO - 2018-02-15 17:51:10 --> Loader Class Initialized
INFO - 2018-02-15 17:51:10 --> Helper loaded: url_helper
INFO - 2018-02-15 17:51:10 --> Helper loaded: file_helper
INFO - 2018-02-15 17:51:10 --> Helper loaded: email_helper
INFO - 2018-02-15 17:51:10 --> Helper loaded: common_helper
INFO - 2018-02-15 17:51:10 --> Database Driver Class Initialized
DEBUG - 2018-02-15 17:51:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 17:51:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 17:51:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 17:51:10 --> Pagination Class Initialized
INFO - 2018-02-15 17:51:10 --> Helper loaded: form_helper
INFO - 2018-02-15 17:51:10 --> Form Validation Class Initialized
INFO - 2018-02-15 17:51:10 --> Model Class Initialized
INFO - 2018-02-15 17:51:10 --> Controller Class Initialized
INFO - 2018-02-15 17:51:10 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 17:51:10 --> Model Class Initialized
INFO - 2018-02-15 17:51:10 --> Model Class Initialized
INFO - 2018-02-15 17:51:10 --> Model Class Initialized
INFO - 2018-02-15 17:51:11 --> Config Class Initialized
INFO - 2018-02-15 17:51:11 --> Hooks Class Initialized
DEBUG - 2018-02-15 17:51:11 --> UTF-8 Support Enabled
INFO - 2018-02-15 17:51:11 --> Utf8 Class Initialized
INFO - 2018-02-15 17:51:11 --> URI Class Initialized
INFO - 2018-02-15 17:51:11 --> Router Class Initialized
INFO - 2018-02-15 17:51:11 --> Output Class Initialized
INFO - 2018-02-15 17:51:11 --> Security Class Initialized
DEBUG - 2018-02-15 17:51:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 17:51:11 --> Input Class Initialized
INFO - 2018-02-15 17:51:11 --> Language Class Initialized
INFO - 2018-02-15 17:51:11 --> Loader Class Initialized
INFO - 2018-02-15 17:51:11 --> Helper loaded: url_helper
INFO - 2018-02-15 17:51:11 --> Helper loaded: file_helper
INFO - 2018-02-15 17:51:11 --> Helper loaded: email_helper
INFO - 2018-02-15 17:51:11 --> Helper loaded: common_helper
INFO - 2018-02-15 17:51:11 --> Database Driver Class Initialized
DEBUG - 2018-02-15 17:51:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 17:51:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 17:51:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 17:51:11 --> Pagination Class Initialized
INFO - 2018-02-15 17:51:11 --> Helper loaded: form_helper
INFO - 2018-02-15 17:51:11 --> Form Validation Class Initialized
INFO - 2018-02-15 17:51:11 --> Model Class Initialized
INFO - 2018-02-15 17:51:11 --> Controller Class Initialized
INFO - 2018-02-15 17:51:11 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 17:51:11 --> Model Class Initialized
INFO - 2018-02-15 17:51:11 --> Model Class Initialized
INFO - 2018-02-15 17:51:11 --> Model Class Initialized
INFO - 2018-02-15 17:51:11 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-15 17:51:11 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-15 17:51:11 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-15 17:51:11 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-15 17:51:11 --> File loaded: /var/www/html/project/radio/application/views/tracks/add_edit.php
INFO - 2018-02-15 17:51:11 --> Final output sent to browser
DEBUG - 2018-02-15 17:51:11 --> Total execution time: 0.0051
INFO - 2018-02-15 17:51:13 --> Config Class Initialized
INFO - 2018-02-15 17:51:13 --> Hooks Class Initialized
DEBUG - 2018-02-15 17:51:13 --> UTF-8 Support Enabled
INFO - 2018-02-15 17:51:13 --> Utf8 Class Initialized
INFO - 2018-02-15 17:51:13 --> URI Class Initialized
INFO - 2018-02-15 17:51:13 --> Router Class Initialized
INFO - 2018-02-15 17:51:13 --> Output Class Initialized
INFO - 2018-02-15 17:51:13 --> Security Class Initialized
DEBUG - 2018-02-15 17:51:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 17:51:13 --> Input Class Initialized
INFO - 2018-02-15 17:51:13 --> Language Class Initialized
INFO - 2018-02-15 17:51:13 --> Loader Class Initialized
INFO - 2018-02-15 17:51:13 --> Helper loaded: url_helper
INFO - 2018-02-15 17:51:13 --> Helper loaded: file_helper
INFO - 2018-02-15 17:51:13 --> Helper loaded: email_helper
INFO - 2018-02-15 17:51:13 --> Helper loaded: common_helper
INFO - 2018-02-15 17:51:13 --> Database Driver Class Initialized
DEBUG - 2018-02-15 17:51:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 17:51:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 17:51:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 17:51:13 --> Pagination Class Initialized
INFO - 2018-02-15 17:51:13 --> Helper loaded: form_helper
INFO - 2018-02-15 17:51:13 --> Form Validation Class Initialized
INFO - 2018-02-15 17:51:13 --> Model Class Initialized
INFO - 2018-02-15 17:51:13 --> Controller Class Initialized
INFO - 2018-02-15 17:51:13 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 17:51:13 --> Model Class Initialized
INFO - 2018-02-15 17:51:13 --> Model Class Initialized
INFO - 2018-02-15 17:51:13 --> Model Class Initialized
INFO - 2018-02-15 17:51:25 --> Config Class Initialized
INFO - 2018-02-15 17:51:25 --> Hooks Class Initialized
DEBUG - 2018-02-15 17:51:25 --> UTF-8 Support Enabled
INFO - 2018-02-15 17:51:25 --> Utf8 Class Initialized
INFO - 2018-02-15 17:51:25 --> URI Class Initialized
INFO - 2018-02-15 17:51:25 --> Router Class Initialized
INFO - 2018-02-15 17:51:25 --> Output Class Initialized
INFO - 2018-02-15 17:51:25 --> Security Class Initialized
DEBUG - 2018-02-15 17:51:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 17:51:25 --> Input Class Initialized
INFO - 2018-02-15 17:51:25 --> Language Class Initialized
INFO - 2018-02-15 17:51:25 --> Loader Class Initialized
INFO - 2018-02-15 17:51:25 --> Helper loaded: url_helper
INFO - 2018-02-15 17:51:25 --> Helper loaded: file_helper
INFO - 2018-02-15 17:51:25 --> Helper loaded: email_helper
INFO - 2018-02-15 17:51:25 --> Helper loaded: common_helper
INFO - 2018-02-15 17:51:25 --> Database Driver Class Initialized
DEBUG - 2018-02-15 17:51:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 17:51:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 17:51:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 17:51:25 --> Pagination Class Initialized
INFO - 2018-02-15 17:51:25 --> Helper loaded: form_helper
INFO - 2018-02-15 17:51:25 --> Form Validation Class Initialized
INFO - 2018-02-15 17:51:25 --> Model Class Initialized
INFO - 2018-02-15 17:51:25 --> Controller Class Initialized
INFO - 2018-02-15 17:51:25 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 17:51:25 --> Model Class Initialized
INFO - 2018-02-15 17:51:25 --> Model Class Initialized
INFO - 2018-02-15 17:51:25 --> Model Class Initialized
INFO - 2018-02-15 17:52:46 --> Config Class Initialized
INFO - 2018-02-15 17:52:46 --> Hooks Class Initialized
DEBUG - 2018-02-15 17:52:46 --> UTF-8 Support Enabled
INFO - 2018-02-15 17:52:46 --> Utf8 Class Initialized
INFO - 2018-02-15 17:52:46 --> URI Class Initialized
INFO - 2018-02-15 17:52:46 --> Router Class Initialized
INFO - 2018-02-15 17:52:46 --> Output Class Initialized
INFO - 2018-02-15 17:52:46 --> Security Class Initialized
DEBUG - 2018-02-15 17:52:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 17:52:46 --> Input Class Initialized
INFO - 2018-02-15 17:52:46 --> Language Class Initialized
INFO - 2018-02-15 17:52:46 --> Loader Class Initialized
INFO - 2018-02-15 17:52:46 --> Helper loaded: url_helper
INFO - 2018-02-15 17:52:46 --> Helper loaded: file_helper
INFO - 2018-02-15 17:52:46 --> Helper loaded: email_helper
INFO - 2018-02-15 17:52:46 --> Helper loaded: common_helper
INFO - 2018-02-15 17:52:46 --> Database Driver Class Initialized
DEBUG - 2018-02-15 17:52:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 17:52:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 17:52:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 17:52:46 --> Pagination Class Initialized
INFO - 2018-02-15 17:52:46 --> Helper loaded: form_helper
INFO - 2018-02-15 17:52:46 --> Form Validation Class Initialized
INFO - 2018-02-15 17:52:46 --> Model Class Initialized
INFO - 2018-02-15 17:52:46 --> Controller Class Initialized
INFO - 2018-02-15 17:52:46 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 17:52:46 --> Model Class Initialized
INFO - 2018-02-15 17:52:46 --> Model Class Initialized
INFO - 2018-02-15 17:52:46 --> Model Class Initialized
INFO - 2018-02-15 17:52:46 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-15 17:52:46 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-15 17:52:46 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-15 17:52:46 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-15 17:52:46 --> File loaded: /var/www/html/project/radio/application/views/tracks/add_edit.php
INFO - 2018-02-15 17:52:46 --> Final output sent to browser
DEBUG - 2018-02-15 17:52:46 --> Total execution time: 0.0068
INFO - 2018-02-15 17:52:48 --> Config Class Initialized
INFO - 2018-02-15 17:52:48 --> Hooks Class Initialized
DEBUG - 2018-02-15 17:52:48 --> UTF-8 Support Enabled
INFO - 2018-02-15 17:52:48 --> Utf8 Class Initialized
INFO - 2018-02-15 17:52:48 --> URI Class Initialized
INFO - 2018-02-15 17:52:48 --> Router Class Initialized
INFO - 2018-02-15 17:52:48 --> Output Class Initialized
INFO - 2018-02-15 17:52:48 --> Security Class Initialized
DEBUG - 2018-02-15 17:52:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 17:52:48 --> Input Class Initialized
INFO - 2018-02-15 17:52:48 --> Language Class Initialized
INFO - 2018-02-15 17:52:48 --> Loader Class Initialized
INFO - 2018-02-15 17:52:48 --> Helper loaded: url_helper
INFO - 2018-02-15 17:52:48 --> Helper loaded: file_helper
INFO - 2018-02-15 17:52:48 --> Helper loaded: email_helper
INFO - 2018-02-15 17:52:48 --> Helper loaded: common_helper
INFO - 2018-02-15 17:52:48 --> Database Driver Class Initialized
DEBUG - 2018-02-15 17:52:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 17:52:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 17:52:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 17:52:48 --> Pagination Class Initialized
INFO - 2018-02-15 17:52:48 --> Helper loaded: form_helper
INFO - 2018-02-15 17:52:48 --> Form Validation Class Initialized
INFO - 2018-02-15 17:52:48 --> Model Class Initialized
INFO - 2018-02-15 17:52:48 --> Controller Class Initialized
INFO - 2018-02-15 17:52:48 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 17:52:48 --> Model Class Initialized
INFO - 2018-02-15 17:52:48 --> Model Class Initialized
INFO - 2018-02-15 17:52:48 --> Model Class Initialized
INFO - 2018-02-15 17:52:54 --> Config Class Initialized
INFO - 2018-02-15 17:52:54 --> Hooks Class Initialized
DEBUG - 2018-02-15 17:52:54 --> UTF-8 Support Enabled
INFO - 2018-02-15 17:52:54 --> Utf8 Class Initialized
INFO - 2018-02-15 17:52:54 --> URI Class Initialized
INFO - 2018-02-15 17:52:54 --> Router Class Initialized
INFO - 2018-02-15 17:52:54 --> Output Class Initialized
INFO - 2018-02-15 17:52:54 --> Security Class Initialized
DEBUG - 2018-02-15 17:52:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 17:52:54 --> Input Class Initialized
INFO - 2018-02-15 17:52:54 --> Language Class Initialized
INFO - 2018-02-15 17:52:54 --> Loader Class Initialized
INFO - 2018-02-15 17:52:54 --> Helper loaded: url_helper
INFO - 2018-02-15 17:52:54 --> Helper loaded: file_helper
INFO - 2018-02-15 17:52:54 --> Helper loaded: email_helper
INFO - 2018-02-15 17:52:54 --> Helper loaded: common_helper
INFO - 2018-02-15 17:52:54 --> Database Driver Class Initialized
DEBUG - 2018-02-15 17:52:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 17:52:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 17:52:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 17:52:54 --> Pagination Class Initialized
INFO - 2018-02-15 17:52:54 --> Helper loaded: form_helper
INFO - 2018-02-15 17:52:54 --> Form Validation Class Initialized
INFO - 2018-02-15 17:52:54 --> Model Class Initialized
INFO - 2018-02-15 17:52:54 --> Controller Class Initialized
INFO - 2018-02-15 17:52:54 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 17:52:54 --> Model Class Initialized
INFO - 2018-02-15 17:52:54 --> Model Class Initialized
INFO - 2018-02-15 17:52:54 --> Model Class Initialized
DEBUG - 2018-02-15 17:52:54 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-15 17:52:54 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-02-15 17:52:54 --> Config Class Initialized
INFO - 2018-02-15 17:52:54 --> Hooks Class Initialized
DEBUG - 2018-02-15 17:52:54 --> UTF-8 Support Enabled
INFO - 2018-02-15 17:52:54 --> Utf8 Class Initialized
INFO - 2018-02-15 17:52:54 --> URI Class Initialized
INFO - 2018-02-15 17:52:54 --> Router Class Initialized
INFO - 2018-02-15 17:52:54 --> Output Class Initialized
INFO - 2018-02-15 17:52:54 --> Security Class Initialized
DEBUG - 2018-02-15 17:52:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 17:52:54 --> Input Class Initialized
INFO - 2018-02-15 17:52:54 --> Language Class Initialized
INFO - 2018-02-15 17:52:54 --> Loader Class Initialized
INFO - 2018-02-15 17:52:54 --> Helper loaded: url_helper
INFO - 2018-02-15 17:52:54 --> Helper loaded: file_helper
INFO - 2018-02-15 17:52:54 --> Helper loaded: email_helper
INFO - 2018-02-15 17:52:54 --> Helper loaded: common_helper
INFO - 2018-02-15 17:52:54 --> Database Driver Class Initialized
DEBUG - 2018-02-15 17:52:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 17:52:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 17:52:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 17:52:54 --> Pagination Class Initialized
INFO - 2018-02-15 17:52:54 --> Helper loaded: form_helper
INFO - 2018-02-15 17:52:54 --> Form Validation Class Initialized
INFO - 2018-02-15 17:52:54 --> Model Class Initialized
INFO - 2018-02-15 17:52:54 --> Controller Class Initialized
INFO - 2018-02-15 17:52:54 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 17:52:54 --> Model Class Initialized
INFO - 2018-02-15 17:52:54 --> Model Class Initialized
INFO - 2018-02-15 17:52:54 --> Model Class Initialized
INFO - 2018-02-15 17:52:54 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-15 17:52:54 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-15 17:52:54 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-15 17:52:54 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-15 17:52:54 --> File loaded: /var/www/html/project/radio/application/views/tracks/index.php
INFO - 2018-02-15 17:52:54 --> Final output sent to browser
DEBUG - 2018-02-15 17:52:54 --> Total execution time: 0.0048
INFO - 2018-02-15 17:52:55 --> Config Class Initialized
INFO - 2018-02-15 17:52:55 --> Hooks Class Initialized
DEBUG - 2018-02-15 17:52:55 --> UTF-8 Support Enabled
INFO - 2018-02-15 17:52:55 --> Utf8 Class Initialized
INFO - 2018-02-15 17:52:55 --> URI Class Initialized
INFO - 2018-02-15 17:52:55 --> Router Class Initialized
INFO - 2018-02-15 17:52:55 --> Output Class Initialized
INFO - 2018-02-15 17:52:55 --> Security Class Initialized
DEBUG - 2018-02-15 17:52:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 17:52:55 --> Input Class Initialized
INFO - 2018-02-15 17:52:55 --> Language Class Initialized
INFO - 2018-02-15 17:52:55 --> Loader Class Initialized
INFO - 2018-02-15 17:52:55 --> Helper loaded: url_helper
INFO - 2018-02-15 17:52:55 --> Helper loaded: file_helper
INFO - 2018-02-15 17:52:55 --> Helper loaded: email_helper
INFO - 2018-02-15 17:52:55 --> Helper loaded: common_helper
INFO - 2018-02-15 17:52:55 --> Database Driver Class Initialized
DEBUG - 2018-02-15 17:52:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 17:52:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 17:52:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 17:52:55 --> Pagination Class Initialized
INFO - 2018-02-15 17:52:55 --> Helper loaded: form_helper
INFO - 2018-02-15 17:52:55 --> Form Validation Class Initialized
INFO - 2018-02-15 17:52:55 --> Model Class Initialized
INFO - 2018-02-15 17:52:55 --> Controller Class Initialized
INFO - 2018-02-15 17:52:55 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 17:52:55 --> Model Class Initialized
INFO - 2018-02-15 17:52:55 --> Model Class Initialized
INFO - 2018-02-15 17:52:55 --> Model Class Initialized
INFO - 2018-02-15 17:53:06 --> Config Class Initialized
INFO - 2018-02-15 17:53:06 --> Hooks Class Initialized
DEBUG - 2018-02-15 17:53:06 --> UTF-8 Support Enabled
INFO - 2018-02-15 17:53:06 --> Utf8 Class Initialized
INFO - 2018-02-15 17:53:06 --> URI Class Initialized
INFO - 2018-02-15 17:53:06 --> Router Class Initialized
INFO - 2018-02-15 17:53:06 --> Output Class Initialized
INFO - 2018-02-15 17:53:06 --> Security Class Initialized
DEBUG - 2018-02-15 17:53:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 17:53:06 --> Input Class Initialized
INFO - 2018-02-15 17:53:06 --> Language Class Initialized
INFO - 2018-02-15 17:53:06 --> Loader Class Initialized
INFO - 2018-02-15 17:53:06 --> Helper loaded: url_helper
INFO - 2018-02-15 17:53:06 --> Helper loaded: file_helper
INFO - 2018-02-15 17:53:06 --> Helper loaded: email_helper
INFO - 2018-02-15 17:53:06 --> Helper loaded: common_helper
INFO - 2018-02-15 17:53:06 --> Database Driver Class Initialized
DEBUG - 2018-02-15 17:53:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 17:53:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 17:53:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 17:53:06 --> Pagination Class Initialized
INFO - 2018-02-15 17:53:06 --> Helper loaded: form_helper
INFO - 2018-02-15 17:53:06 --> Form Validation Class Initialized
INFO - 2018-02-15 17:53:06 --> Model Class Initialized
INFO - 2018-02-15 17:53:06 --> Controller Class Initialized
INFO - 2018-02-15 17:53:06 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 17:53:06 --> Model Class Initialized
INFO - 2018-02-15 17:53:06 --> Model Class Initialized
INFO - 2018-02-15 17:53:06 --> Model Class Initialized
INFO - 2018-02-15 17:53:06 --> Config Class Initialized
INFO - 2018-02-15 17:53:06 --> Hooks Class Initialized
DEBUG - 2018-02-15 17:53:06 --> UTF-8 Support Enabled
INFO - 2018-02-15 17:53:06 --> Utf8 Class Initialized
INFO - 2018-02-15 17:53:06 --> URI Class Initialized
INFO - 2018-02-15 17:53:06 --> Router Class Initialized
INFO - 2018-02-15 17:53:06 --> Output Class Initialized
INFO - 2018-02-15 17:53:06 --> Security Class Initialized
DEBUG - 2018-02-15 17:53:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 17:53:06 --> Input Class Initialized
INFO - 2018-02-15 17:53:06 --> Language Class Initialized
INFO - 2018-02-15 17:53:06 --> Loader Class Initialized
INFO - 2018-02-15 17:53:06 --> Helper loaded: url_helper
INFO - 2018-02-15 17:53:06 --> Helper loaded: file_helper
INFO - 2018-02-15 17:53:06 --> Helper loaded: email_helper
INFO - 2018-02-15 17:53:06 --> Helper loaded: common_helper
INFO - 2018-02-15 17:53:06 --> Database Driver Class Initialized
DEBUG - 2018-02-15 17:53:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 17:53:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 17:53:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 17:53:06 --> Pagination Class Initialized
INFO - 2018-02-15 17:53:06 --> Helper loaded: form_helper
INFO - 2018-02-15 17:53:06 --> Form Validation Class Initialized
INFO - 2018-02-15 17:53:06 --> Model Class Initialized
INFO - 2018-02-15 17:53:06 --> Controller Class Initialized
INFO - 2018-02-15 17:53:06 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 17:53:06 --> Model Class Initialized
INFO - 2018-02-15 17:53:06 --> Model Class Initialized
INFO - 2018-02-15 17:53:06 --> Model Class Initialized
INFO - 2018-02-15 17:53:07 --> Config Class Initialized
INFO - 2018-02-15 17:53:07 --> Hooks Class Initialized
DEBUG - 2018-02-15 17:53:07 --> UTF-8 Support Enabled
INFO - 2018-02-15 17:53:07 --> Utf8 Class Initialized
INFO - 2018-02-15 17:53:07 --> URI Class Initialized
INFO - 2018-02-15 17:53:07 --> Router Class Initialized
INFO - 2018-02-15 17:53:07 --> Output Class Initialized
INFO - 2018-02-15 17:53:07 --> Security Class Initialized
DEBUG - 2018-02-15 17:53:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 17:53:07 --> Input Class Initialized
INFO - 2018-02-15 17:53:07 --> Language Class Initialized
INFO - 2018-02-15 17:53:07 --> Loader Class Initialized
INFO - 2018-02-15 17:53:07 --> Helper loaded: url_helper
INFO - 2018-02-15 17:53:07 --> Helper loaded: file_helper
INFO - 2018-02-15 17:53:07 --> Helper loaded: email_helper
INFO - 2018-02-15 17:53:07 --> Helper loaded: common_helper
INFO - 2018-02-15 17:53:07 --> Database Driver Class Initialized
DEBUG - 2018-02-15 17:53:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 17:53:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 17:53:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 17:53:07 --> Pagination Class Initialized
INFO - 2018-02-15 17:53:07 --> Helper loaded: form_helper
INFO - 2018-02-15 17:53:07 --> Form Validation Class Initialized
INFO - 2018-02-15 17:53:07 --> Model Class Initialized
INFO - 2018-02-15 17:53:07 --> Controller Class Initialized
INFO - 2018-02-15 17:53:07 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 17:53:07 --> Model Class Initialized
INFO - 2018-02-15 17:53:07 --> Model Class Initialized
INFO - 2018-02-15 17:53:07 --> Model Class Initialized
INFO - 2018-02-15 17:53:07 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-15 17:53:07 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-15 17:53:07 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-15 17:53:07 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-15 17:53:07 --> File loaded: /var/www/html/project/radio/application/views/tracks/add_edit.php
INFO - 2018-02-15 17:53:07 --> Final output sent to browser
DEBUG - 2018-02-15 17:53:07 --> Total execution time: 0.0053
INFO - 2018-02-15 17:53:50 --> Config Class Initialized
INFO - 2018-02-15 17:53:50 --> Hooks Class Initialized
DEBUG - 2018-02-15 17:53:50 --> UTF-8 Support Enabled
INFO - 2018-02-15 17:53:50 --> Utf8 Class Initialized
INFO - 2018-02-15 17:53:50 --> URI Class Initialized
INFO - 2018-02-15 17:53:50 --> Router Class Initialized
INFO - 2018-02-15 17:53:50 --> Output Class Initialized
INFO - 2018-02-15 17:53:50 --> Security Class Initialized
DEBUG - 2018-02-15 17:53:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 17:53:50 --> Input Class Initialized
INFO - 2018-02-15 17:53:50 --> Language Class Initialized
INFO - 2018-02-15 17:53:50 --> Loader Class Initialized
INFO - 2018-02-15 17:53:50 --> Helper loaded: url_helper
INFO - 2018-02-15 17:53:50 --> Helper loaded: file_helper
INFO - 2018-02-15 17:53:50 --> Helper loaded: email_helper
INFO - 2018-02-15 17:53:50 --> Helper loaded: common_helper
INFO - 2018-02-15 17:53:50 --> Database Driver Class Initialized
DEBUG - 2018-02-15 17:53:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 17:53:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 17:53:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 17:53:50 --> Pagination Class Initialized
INFO - 2018-02-15 17:53:50 --> Helper loaded: form_helper
INFO - 2018-02-15 17:53:50 --> Form Validation Class Initialized
INFO - 2018-02-15 17:53:50 --> Model Class Initialized
INFO - 2018-02-15 17:53:50 --> Controller Class Initialized
INFO - 2018-02-15 17:53:50 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 17:53:50 --> Model Class Initialized
INFO - 2018-02-15 17:53:50 --> Model Class Initialized
INFO - 2018-02-15 17:53:50 --> Model Class Initialized
INFO - 2018-02-15 17:53:50 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-15 17:53:50 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-15 17:53:50 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-15 17:53:50 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-15 17:53:50 --> File loaded: /var/www/html/project/radio/application/views/tracks/add_edit.php
INFO - 2018-02-15 17:53:50 --> Final output sent to browser
DEBUG - 2018-02-15 17:53:50 --> Total execution time: 0.0070
INFO - 2018-02-15 17:53:55 --> Config Class Initialized
INFO - 2018-02-15 17:53:55 --> Hooks Class Initialized
DEBUG - 2018-02-15 17:53:55 --> UTF-8 Support Enabled
INFO - 2018-02-15 17:53:55 --> Utf8 Class Initialized
INFO - 2018-02-15 17:53:55 --> URI Class Initialized
INFO - 2018-02-15 17:53:55 --> Router Class Initialized
INFO - 2018-02-15 17:53:55 --> Output Class Initialized
INFO - 2018-02-15 17:53:55 --> Security Class Initialized
DEBUG - 2018-02-15 17:53:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 17:53:55 --> Input Class Initialized
INFO - 2018-02-15 17:53:55 --> Language Class Initialized
INFO - 2018-02-15 17:53:55 --> Loader Class Initialized
INFO - 2018-02-15 17:53:55 --> Helper loaded: url_helper
INFO - 2018-02-15 17:53:55 --> Helper loaded: file_helper
INFO - 2018-02-15 17:53:55 --> Helper loaded: email_helper
INFO - 2018-02-15 17:53:55 --> Helper loaded: common_helper
INFO - 2018-02-15 17:53:55 --> Database Driver Class Initialized
DEBUG - 2018-02-15 17:53:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 17:53:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 17:53:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 17:53:55 --> Pagination Class Initialized
INFO - 2018-02-15 17:53:55 --> Helper loaded: form_helper
INFO - 2018-02-15 17:53:55 --> Form Validation Class Initialized
INFO - 2018-02-15 17:53:55 --> Model Class Initialized
INFO - 2018-02-15 17:53:55 --> Controller Class Initialized
INFO - 2018-02-15 17:53:55 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 17:53:55 --> Model Class Initialized
INFO - 2018-02-15 17:53:55 --> Model Class Initialized
INFO - 2018-02-15 17:53:55 --> Model Class Initialized
INFO - 2018-02-15 17:54:02 --> Config Class Initialized
INFO - 2018-02-15 17:54:02 --> Hooks Class Initialized
DEBUG - 2018-02-15 17:54:02 --> UTF-8 Support Enabled
INFO - 2018-02-15 17:54:02 --> Utf8 Class Initialized
INFO - 2018-02-15 17:54:02 --> URI Class Initialized
INFO - 2018-02-15 17:54:02 --> Router Class Initialized
INFO - 2018-02-15 17:54:02 --> Output Class Initialized
INFO - 2018-02-15 17:54:02 --> Security Class Initialized
DEBUG - 2018-02-15 17:54:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 17:54:02 --> Input Class Initialized
INFO - 2018-02-15 17:54:02 --> Language Class Initialized
INFO - 2018-02-15 17:54:02 --> Loader Class Initialized
INFO - 2018-02-15 17:54:02 --> Helper loaded: url_helper
INFO - 2018-02-15 17:54:02 --> Helper loaded: file_helper
INFO - 2018-02-15 17:54:02 --> Helper loaded: email_helper
INFO - 2018-02-15 17:54:02 --> Helper loaded: common_helper
INFO - 2018-02-15 17:54:02 --> Database Driver Class Initialized
DEBUG - 2018-02-15 17:54:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 17:54:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 17:54:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 17:54:02 --> Pagination Class Initialized
INFO - 2018-02-15 17:54:02 --> Helper loaded: form_helper
INFO - 2018-02-15 17:54:02 --> Form Validation Class Initialized
INFO - 2018-02-15 17:54:02 --> Model Class Initialized
INFO - 2018-02-15 17:54:02 --> Controller Class Initialized
INFO - 2018-02-15 17:54:02 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 17:54:02 --> Model Class Initialized
INFO - 2018-02-15 17:54:02 --> Model Class Initialized
INFO - 2018-02-15 17:54:02 --> Model Class Initialized
DEBUG - 2018-02-15 17:54:02 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-15 17:54:02 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-02-15 17:54:02 --> Config Class Initialized
INFO - 2018-02-15 17:54:02 --> Hooks Class Initialized
DEBUG - 2018-02-15 17:54:02 --> UTF-8 Support Enabled
INFO - 2018-02-15 17:54:02 --> Utf8 Class Initialized
INFO - 2018-02-15 17:54:02 --> URI Class Initialized
INFO - 2018-02-15 17:54:02 --> Router Class Initialized
INFO - 2018-02-15 17:54:02 --> Output Class Initialized
INFO - 2018-02-15 17:54:02 --> Security Class Initialized
DEBUG - 2018-02-15 17:54:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 17:54:02 --> Input Class Initialized
INFO - 2018-02-15 17:54:02 --> Language Class Initialized
INFO - 2018-02-15 17:54:02 --> Loader Class Initialized
INFO - 2018-02-15 17:54:02 --> Helper loaded: url_helper
INFO - 2018-02-15 17:54:02 --> Helper loaded: file_helper
INFO - 2018-02-15 17:54:02 --> Helper loaded: email_helper
INFO - 2018-02-15 17:54:02 --> Helper loaded: common_helper
INFO - 2018-02-15 17:54:02 --> Database Driver Class Initialized
DEBUG - 2018-02-15 17:54:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 17:54:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 17:54:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 17:54:02 --> Pagination Class Initialized
INFO - 2018-02-15 17:54:02 --> Helper loaded: form_helper
INFO - 2018-02-15 17:54:02 --> Form Validation Class Initialized
INFO - 2018-02-15 17:54:02 --> Model Class Initialized
INFO - 2018-02-15 17:54:02 --> Controller Class Initialized
INFO - 2018-02-15 17:54:02 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 17:54:02 --> Model Class Initialized
INFO - 2018-02-15 17:54:02 --> Model Class Initialized
INFO - 2018-02-15 17:54:02 --> Model Class Initialized
INFO - 2018-02-15 17:54:02 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-15 17:54:02 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-15 17:54:02 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-15 17:54:02 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-15 17:54:02 --> File loaded: /var/www/html/project/radio/application/views/tracks/index.php
INFO - 2018-02-15 17:54:02 --> Final output sent to browser
DEBUG - 2018-02-15 17:54:02 --> Total execution time: 0.0040
INFO - 2018-02-15 17:54:02 --> Config Class Initialized
INFO - 2018-02-15 17:54:02 --> Hooks Class Initialized
DEBUG - 2018-02-15 17:54:02 --> UTF-8 Support Enabled
INFO - 2018-02-15 17:54:02 --> Utf8 Class Initialized
INFO - 2018-02-15 17:54:02 --> URI Class Initialized
INFO - 2018-02-15 17:54:02 --> Router Class Initialized
INFO - 2018-02-15 17:54:02 --> Output Class Initialized
INFO - 2018-02-15 17:54:02 --> Security Class Initialized
DEBUG - 2018-02-15 17:54:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 17:54:02 --> Input Class Initialized
INFO - 2018-02-15 17:54:02 --> Language Class Initialized
INFO - 2018-02-15 17:54:02 --> Loader Class Initialized
INFO - 2018-02-15 17:54:02 --> Helper loaded: url_helper
INFO - 2018-02-15 17:54:02 --> Helper loaded: file_helper
INFO - 2018-02-15 17:54:02 --> Helper loaded: email_helper
INFO - 2018-02-15 17:54:02 --> Helper loaded: common_helper
INFO - 2018-02-15 17:54:02 --> Database Driver Class Initialized
DEBUG - 2018-02-15 17:54:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 17:54:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 17:54:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 17:54:02 --> Pagination Class Initialized
INFO - 2018-02-15 17:54:02 --> Helper loaded: form_helper
INFO - 2018-02-15 17:54:02 --> Form Validation Class Initialized
INFO - 2018-02-15 17:54:02 --> Model Class Initialized
INFO - 2018-02-15 17:54:02 --> Controller Class Initialized
INFO - 2018-02-15 17:54:02 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 17:54:02 --> Model Class Initialized
INFO - 2018-02-15 17:54:02 --> Model Class Initialized
INFO - 2018-02-15 17:54:02 --> Model Class Initialized
INFO - 2018-02-15 17:54:04 --> Config Class Initialized
INFO - 2018-02-15 17:54:04 --> Hooks Class Initialized
DEBUG - 2018-02-15 17:54:04 --> UTF-8 Support Enabled
INFO - 2018-02-15 17:54:04 --> Utf8 Class Initialized
INFO - 2018-02-15 17:54:04 --> URI Class Initialized
INFO - 2018-02-15 17:54:04 --> Router Class Initialized
INFO - 2018-02-15 17:54:04 --> Output Class Initialized
INFO - 2018-02-15 17:54:04 --> Security Class Initialized
DEBUG - 2018-02-15 17:54:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 17:54:04 --> Input Class Initialized
INFO - 2018-02-15 17:54:04 --> Language Class Initialized
INFO - 2018-02-15 17:54:04 --> Loader Class Initialized
INFO - 2018-02-15 17:54:04 --> Helper loaded: url_helper
INFO - 2018-02-15 17:54:04 --> Helper loaded: file_helper
INFO - 2018-02-15 17:54:04 --> Helper loaded: email_helper
INFO - 2018-02-15 17:54:04 --> Helper loaded: common_helper
INFO - 2018-02-15 17:54:04 --> Database Driver Class Initialized
DEBUG - 2018-02-15 17:54:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 17:54:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 17:54:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 17:54:04 --> Pagination Class Initialized
INFO - 2018-02-15 17:54:04 --> Helper loaded: form_helper
INFO - 2018-02-15 17:54:04 --> Form Validation Class Initialized
INFO - 2018-02-15 17:54:04 --> Model Class Initialized
INFO - 2018-02-15 17:54:04 --> Controller Class Initialized
INFO - 2018-02-15 17:54:04 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 17:54:04 --> Model Class Initialized
INFO - 2018-02-15 17:54:04 --> Model Class Initialized
INFO - 2018-02-15 17:54:04 --> Model Class Initialized
INFO - 2018-02-15 17:54:04 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-15 17:54:04 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-15 17:54:04 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-15 17:54:04 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-15 17:54:04 --> File loaded: /var/www/html/project/radio/application/views/tracks/add_edit.php
INFO - 2018-02-15 17:54:04 --> Final output sent to browser
DEBUG - 2018-02-15 17:54:04 --> Total execution time: 0.0048
INFO - 2018-02-15 17:54:06 --> Config Class Initialized
INFO - 2018-02-15 17:54:06 --> Hooks Class Initialized
DEBUG - 2018-02-15 17:54:06 --> UTF-8 Support Enabled
INFO - 2018-02-15 17:54:06 --> Utf8 Class Initialized
INFO - 2018-02-15 17:54:06 --> URI Class Initialized
INFO - 2018-02-15 17:54:06 --> Router Class Initialized
INFO - 2018-02-15 17:54:06 --> Output Class Initialized
INFO - 2018-02-15 17:54:06 --> Security Class Initialized
DEBUG - 2018-02-15 17:54:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 17:54:06 --> Input Class Initialized
INFO - 2018-02-15 17:54:06 --> Language Class Initialized
INFO - 2018-02-15 17:54:06 --> Loader Class Initialized
INFO - 2018-02-15 17:54:06 --> Helper loaded: url_helper
INFO - 2018-02-15 17:54:06 --> Helper loaded: file_helper
INFO - 2018-02-15 17:54:06 --> Helper loaded: email_helper
INFO - 2018-02-15 17:54:06 --> Helper loaded: common_helper
INFO - 2018-02-15 17:54:06 --> Database Driver Class Initialized
DEBUG - 2018-02-15 17:54:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 17:54:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 17:54:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 17:54:06 --> Pagination Class Initialized
INFO - 2018-02-15 17:54:06 --> Helper loaded: form_helper
INFO - 2018-02-15 17:54:06 --> Form Validation Class Initialized
INFO - 2018-02-15 17:54:06 --> Model Class Initialized
INFO - 2018-02-15 17:54:06 --> Controller Class Initialized
INFO - 2018-02-15 17:54:06 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 17:54:06 --> Model Class Initialized
INFO - 2018-02-15 17:54:06 --> Model Class Initialized
INFO - 2018-02-15 17:54:06 --> Model Class Initialized
INFO - 2018-02-15 17:54:39 --> Config Class Initialized
INFO - 2018-02-15 17:54:39 --> Hooks Class Initialized
DEBUG - 2018-02-15 17:54:39 --> UTF-8 Support Enabled
INFO - 2018-02-15 17:54:39 --> Utf8 Class Initialized
INFO - 2018-02-15 17:54:39 --> URI Class Initialized
INFO - 2018-02-15 17:54:39 --> Router Class Initialized
INFO - 2018-02-15 17:54:39 --> Output Class Initialized
INFO - 2018-02-15 17:54:39 --> Security Class Initialized
DEBUG - 2018-02-15 17:54:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 17:54:39 --> Input Class Initialized
INFO - 2018-02-15 17:54:39 --> Language Class Initialized
INFO - 2018-02-15 17:54:39 --> Loader Class Initialized
INFO - 2018-02-15 17:54:39 --> Helper loaded: url_helper
INFO - 2018-02-15 17:54:39 --> Helper loaded: file_helper
INFO - 2018-02-15 17:54:39 --> Helper loaded: email_helper
INFO - 2018-02-15 17:54:39 --> Helper loaded: common_helper
INFO - 2018-02-15 17:54:39 --> Database Driver Class Initialized
DEBUG - 2018-02-15 17:54:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 17:54:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 17:54:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 17:54:39 --> Pagination Class Initialized
INFO - 2018-02-15 17:54:39 --> Helper loaded: form_helper
INFO - 2018-02-15 17:54:39 --> Form Validation Class Initialized
INFO - 2018-02-15 17:54:39 --> Model Class Initialized
INFO - 2018-02-15 17:54:39 --> Controller Class Initialized
INFO - 2018-02-15 17:54:39 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 17:54:39 --> Model Class Initialized
INFO - 2018-02-15 17:54:39 --> Model Class Initialized
INFO - 2018-02-15 17:54:39 --> Model Class Initialized
DEBUG - 2018-02-15 17:54:39 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-15 17:54:39 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-02-15 17:54:39 --> Config Class Initialized
INFO - 2018-02-15 17:54:39 --> Hooks Class Initialized
DEBUG - 2018-02-15 17:54:39 --> UTF-8 Support Enabled
INFO - 2018-02-15 17:54:39 --> Utf8 Class Initialized
INFO - 2018-02-15 17:54:39 --> URI Class Initialized
INFO - 2018-02-15 17:54:39 --> Router Class Initialized
INFO - 2018-02-15 17:54:39 --> Output Class Initialized
INFO - 2018-02-15 17:54:39 --> Security Class Initialized
DEBUG - 2018-02-15 17:54:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 17:54:39 --> Input Class Initialized
INFO - 2018-02-15 17:54:39 --> Language Class Initialized
INFO - 2018-02-15 17:54:39 --> Loader Class Initialized
INFO - 2018-02-15 17:54:39 --> Helper loaded: url_helper
INFO - 2018-02-15 17:54:39 --> Helper loaded: file_helper
INFO - 2018-02-15 17:54:39 --> Helper loaded: email_helper
INFO - 2018-02-15 17:54:39 --> Helper loaded: common_helper
INFO - 2018-02-15 17:54:39 --> Database Driver Class Initialized
DEBUG - 2018-02-15 17:54:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 17:54:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 17:54:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 17:54:39 --> Pagination Class Initialized
INFO - 2018-02-15 17:54:39 --> Helper loaded: form_helper
INFO - 2018-02-15 17:54:39 --> Form Validation Class Initialized
INFO - 2018-02-15 17:54:39 --> Model Class Initialized
INFO - 2018-02-15 17:54:39 --> Controller Class Initialized
INFO - 2018-02-15 17:54:39 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 17:54:39 --> Model Class Initialized
INFO - 2018-02-15 17:54:39 --> Model Class Initialized
INFO - 2018-02-15 17:54:39 --> Model Class Initialized
INFO - 2018-02-15 17:54:39 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-15 17:54:39 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-15 17:54:39 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-15 17:54:39 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-15 17:54:39 --> File loaded: /var/www/html/project/radio/application/views/tracks/index.php
INFO - 2018-02-15 17:54:39 --> Final output sent to browser
DEBUG - 2018-02-15 17:54:39 --> Total execution time: 0.0037
INFO - 2018-02-15 17:54:40 --> Config Class Initialized
INFO - 2018-02-15 17:54:40 --> Hooks Class Initialized
DEBUG - 2018-02-15 17:54:40 --> UTF-8 Support Enabled
INFO - 2018-02-15 17:54:40 --> Utf8 Class Initialized
INFO - 2018-02-15 17:54:40 --> URI Class Initialized
INFO - 2018-02-15 17:54:40 --> Router Class Initialized
INFO - 2018-02-15 17:54:40 --> Output Class Initialized
INFO - 2018-02-15 17:54:40 --> Security Class Initialized
DEBUG - 2018-02-15 17:54:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 17:54:40 --> Input Class Initialized
INFO - 2018-02-15 17:54:40 --> Language Class Initialized
INFO - 2018-02-15 17:54:40 --> Loader Class Initialized
INFO - 2018-02-15 17:54:40 --> Helper loaded: url_helper
INFO - 2018-02-15 17:54:40 --> Helper loaded: file_helper
INFO - 2018-02-15 17:54:40 --> Helper loaded: email_helper
INFO - 2018-02-15 17:54:40 --> Helper loaded: common_helper
INFO - 2018-02-15 17:54:40 --> Database Driver Class Initialized
DEBUG - 2018-02-15 17:54:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 17:54:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 17:54:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 17:54:40 --> Pagination Class Initialized
INFO - 2018-02-15 17:54:40 --> Helper loaded: form_helper
INFO - 2018-02-15 17:54:40 --> Form Validation Class Initialized
INFO - 2018-02-15 17:54:40 --> Model Class Initialized
INFO - 2018-02-15 17:54:40 --> Controller Class Initialized
INFO - 2018-02-15 17:54:40 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 17:54:40 --> Model Class Initialized
INFO - 2018-02-15 17:54:40 --> Model Class Initialized
INFO - 2018-02-15 17:54:40 --> Model Class Initialized
INFO - 2018-02-15 17:55:54 --> Config Class Initialized
INFO - 2018-02-15 17:55:54 --> Hooks Class Initialized
DEBUG - 2018-02-15 17:55:54 --> UTF-8 Support Enabled
INFO - 2018-02-15 17:55:54 --> Utf8 Class Initialized
INFO - 2018-02-15 17:55:54 --> URI Class Initialized
INFO - 2018-02-15 17:55:54 --> Router Class Initialized
INFO - 2018-02-15 17:55:54 --> Output Class Initialized
INFO - 2018-02-15 17:55:54 --> Security Class Initialized
DEBUG - 2018-02-15 17:55:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 17:55:54 --> Input Class Initialized
INFO - 2018-02-15 17:55:54 --> Language Class Initialized
INFO - 2018-02-15 17:55:54 --> Loader Class Initialized
INFO - 2018-02-15 17:55:54 --> Helper loaded: url_helper
INFO - 2018-02-15 17:55:54 --> Helper loaded: file_helper
INFO - 2018-02-15 17:55:54 --> Helper loaded: email_helper
INFO - 2018-02-15 17:55:54 --> Helper loaded: common_helper
INFO - 2018-02-15 17:55:54 --> Database Driver Class Initialized
DEBUG - 2018-02-15 17:55:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 17:55:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 17:55:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 17:55:54 --> Pagination Class Initialized
INFO - 2018-02-15 17:55:54 --> Helper loaded: form_helper
INFO - 2018-02-15 17:55:54 --> Form Validation Class Initialized
INFO - 2018-02-15 17:55:54 --> Model Class Initialized
INFO - 2018-02-15 17:55:54 --> Controller Class Initialized
INFO - 2018-02-15 17:55:54 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 17:55:54 --> Model Class Initialized
INFO - 2018-02-15 17:55:54 --> Model Class Initialized
INFO - 2018-02-15 17:55:54 --> Model Class Initialized
INFO - 2018-02-15 17:55:54 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-15 17:55:54 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-15 17:55:54 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-15 17:55:54 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-15 17:55:54 --> File loaded: /var/www/html/project/radio/application/views/tracks/add_edit.php
INFO - 2018-02-15 17:55:54 --> Final output sent to browser
DEBUG - 2018-02-15 17:55:54 --> Total execution time: 0.0071
INFO - 2018-02-15 17:56:02 --> Config Class Initialized
INFO - 2018-02-15 17:56:02 --> Hooks Class Initialized
DEBUG - 2018-02-15 17:56:02 --> UTF-8 Support Enabled
INFO - 2018-02-15 17:56:02 --> Utf8 Class Initialized
INFO - 2018-02-15 17:56:02 --> URI Class Initialized
INFO - 2018-02-15 17:56:02 --> Router Class Initialized
INFO - 2018-02-15 17:56:02 --> Output Class Initialized
INFO - 2018-02-15 17:56:02 --> Security Class Initialized
DEBUG - 2018-02-15 17:56:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 17:56:02 --> Input Class Initialized
INFO - 2018-02-15 17:56:02 --> Language Class Initialized
INFO - 2018-02-15 17:56:02 --> Loader Class Initialized
INFO - 2018-02-15 17:56:02 --> Helper loaded: url_helper
INFO - 2018-02-15 17:56:02 --> Helper loaded: file_helper
INFO - 2018-02-15 17:56:02 --> Helper loaded: email_helper
INFO - 2018-02-15 17:56:02 --> Helper loaded: common_helper
INFO - 2018-02-15 17:56:02 --> Database Driver Class Initialized
DEBUG - 2018-02-15 17:56:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 17:56:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 17:56:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 17:56:02 --> Pagination Class Initialized
INFO - 2018-02-15 17:56:02 --> Helper loaded: form_helper
INFO - 2018-02-15 17:56:02 --> Form Validation Class Initialized
INFO - 2018-02-15 17:56:02 --> Model Class Initialized
INFO - 2018-02-15 17:56:02 --> Controller Class Initialized
INFO - 2018-02-15 17:56:02 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 17:56:02 --> Model Class Initialized
INFO - 2018-02-15 17:56:02 --> Model Class Initialized
INFO - 2018-02-15 17:56:02 --> Model Class Initialized
DEBUG - 2018-02-15 17:56:02 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-15 17:56:02 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-02-15 17:56:02 --> Config Class Initialized
INFO - 2018-02-15 17:56:02 --> Hooks Class Initialized
DEBUG - 2018-02-15 17:56:02 --> UTF-8 Support Enabled
INFO - 2018-02-15 17:56:02 --> Utf8 Class Initialized
INFO - 2018-02-15 17:56:02 --> URI Class Initialized
INFO - 2018-02-15 17:56:02 --> Router Class Initialized
INFO - 2018-02-15 17:56:02 --> Output Class Initialized
INFO - 2018-02-15 17:56:02 --> Security Class Initialized
DEBUG - 2018-02-15 17:56:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 17:56:02 --> Input Class Initialized
INFO - 2018-02-15 17:56:02 --> Language Class Initialized
INFO - 2018-02-15 17:56:02 --> Loader Class Initialized
INFO - 2018-02-15 17:56:02 --> Helper loaded: url_helper
INFO - 2018-02-15 17:56:02 --> Helper loaded: file_helper
INFO - 2018-02-15 17:56:02 --> Helper loaded: email_helper
INFO - 2018-02-15 17:56:02 --> Helper loaded: common_helper
INFO - 2018-02-15 17:56:02 --> Database Driver Class Initialized
DEBUG - 2018-02-15 17:56:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 17:56:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 17:56:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 17:56:02 --> Pagination Class Initialized
INFO - 2018-02-15 17:56:02 --> Helper loaded: form_helper
INFO - 2018-02-15 17:56:02 --> Form Validation Class Initialized
INFO - 2018-02-15 17:56:02 --> Model Class Initialized
INFO - 2018-02-15 17:56:02 --> Controller Class Initialized
INFO - 2018-02-15 17:56:02 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 17:56:02 --> Model Class Initialized
INFO - 2018-02-15 17:56:02 --> Model Class Initialized
INFO - 2018-02-15 17:56:02 --> Model Class Initialized
INFO - 2018-02-15 17:56:02 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-15 17:56:02 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-15 17:56:02 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-15 17:56:02 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-15 17:56:02 --> File loaded: /var/www/html/project/radio/application/views/tracks/index.php
INFO - 2018-02-15 17:56:02 --> Final output sent to browser
DEBUG - 2018-02-15 17:56:02 --> Total execution time: 0.0036
INFO - 2018-02-15 17:56:03 --> Config Class Initialized
INFO - 2018-02-15 17:56:03 --> Hooks Class Initialized
DEBUG - 2018-02-15 17:56:03 --> UTF-8 Support Enabled
INFO - 2018-02-15 17:56:03 --> Utf8 Class Initialized
INFO - 2018-02-15 17:56:03 --> URI Class Initialized
INFO - 2018-02-15 17:56:03 --> Router Class Initialized
INFO - 2018-02-15 17:56:03 --> Output Class Initialized
INFO - 2018-02-15 17:56:03 --> Security Class Initialized
DEBUG - 2018-02-15 17:56:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 17:56:03 --> Input Class Initialized
INFO - 2018-02-15 17:56:03 --> Language Class Initialized
INFO - 2018-02-15 17:56:03 --> Loader Class Initialized
INFO - 2018-02-15 17:56:03 --> Helper loaded: url_helper
INFO - 2018-02-15 17:56:03 --> Helper loaded: file_helper
INFO - 2018-02-15 17:56:03 --> Helper loaded: email_helper
INFO - 2018-02-15 17:56:03 --> Helper loaded: common_helper
INFO - 2018-02-15 17:56:03 --> Database Driver Class Initialized
DEBUG - 2018-02-15 17:56:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 17:56:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 17:56:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 17:56:03 --> Pagination Class Initialized
INFO - 2018-02-15 17:56:03 --> Helper loaded: form_helper
INFO - 2018-02-15 17:56:03 --> Form Validation Class Initialized
INFO - 2018-02-15 17:56:03 --> Model Class Initialized
INFO - 2018-02-15 17:56:03 --> Controller Class Initialized
INFO - 2018-02-15 17:56:03 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 17:56:03 --> Model Class Initialized
INFO - 2018-02-15 17:56:03 --> Model Class Initialized
INFO - 2018-02-15 17:56:03 --> Model Class Initialized
INFO - 2018-02-15 17:56:16 --> Config Class Initialized
INFO - 2018-02-15 17:56:16 --> Hooks Class Initialized
DEBUG - 2018-02-15 17:56:16 --> UTF-8 Support Enabled
INFO - 2018-02-15 17:56:16 --> Utf8 Class Initialized
INFO - 2018-02-15 17:56:16 --> URI Class Initialized
INFO - 2018-02-15 17:56:16 --> Router Class Initialized
INFO - 2018-02-15 17:56:16 --> Output Class Initialized
INFO - 2018-02-15 17:56:16 --> Security Class Initialized
DEBUG - 2018-02-15 17:56:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 17:56:16 --> Input Class Initialized
INFO - 2018-02-15 17:56:16 --> Language Class Initialized
INFO - 2018-02-15 17:56:16 --> Loader Class Initialized
INFO - 2018-02-15 17:56:16 --> Helper loaded: url_helper
INFO - 2018-02-15 17:56:16 --> Helper loaded: file_helper
INFO - 2018-02-15 17:56:16 --> Helper loaded: email_helper
INFO - 2018-02-15 17:56:16 --> Helper loaded: common_helper
INFO - 2018-02-15 17:56:16 --> Database Driver Class Initialized
DEBUG - 2018-02-15 17:56:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 17:56:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 17:56:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 17:56:16 --> Pagination Class Initialized
INFO - 2018-02-15 17:56:16 --> Helper loaded: form_helper
INFO - 2018-02-15 17:56:16 --> Form Validation Class Initialized
INFO - 2018-02-15 17:56:16 --> Model Class Initialized
INFO - 2018-02-15 17:56:16 --> Controller Class Initialized
INFO - 2018-02-15 17:56:16 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 17:56:16 --> Model Class Initialized
INFO - 2018-02-15 17:56:16 --> Model Class Initialized
INFO - 2018-02-15 17:56:16 --> Model Class Initialized
INFO - 2018-02-15 17:56:16 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-15 17:56:16 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-15 17:56:16 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-15 17:56:16 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-15 17:56:16 --> File loaded: /var/www/html/project/radio/application/views/tracks/add_edit.php
INFO - 2018-02-15 17:56:16 --> Final output sent to browser
DEBUG - 2018-02-15 17:56:16 --> Total execution time: 0.0055
INFO - 2018-02-15 17:56:24 --> Config Class Initialized
INFO - 2018-02-15 17:56:24 --> Hooks Class Initialized
DEBUG - 2018-02-15 17:56:24 --> UTF-8 Support Enabled
INFO - 2018-02-15 17:56:24 --> Utf8 Class Initialized
INFO - 2018-02-15 17:56:24 --> URI Class Initialized
INFO - 2018-02-15 17:56:24 --> Router Class Initialized
INFO - 2018-02-15 17:56:24 --> Output Class Initialized
INFO - 2018-02-15 17:56:24 --> Security Class Initialized
DEBUG - 2018-02-15 17:56:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 17:56:24 --> Input Class Initialized
INFO - 2018-02-15 17:56:24 --> Language Class Initialized
INFO - 2018-02-15 17:56:24 --> Loader Class Initialized
INFO - 2018-02-15 17:56:24 --> Helper loaded: url_helper
INFO - 2018-02-15 17:56:24 --> Helper loaded: file_helper
INFO - 2018-02-15 17:56:24 --> Helper loaded: email_helper
INFO - 2018-02-15 17:56:24 --> Helper loaded: common_helper
INFO - 2018-02-15 17:56:24 --> Database Driver Class Initialized
DEBUG - 2018-02-15 17:56:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 17:56:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 17:56:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 17:56:24 --> Pagination Class Initialized
INFO - 2018-02-15 17:56:24 --> Helper loaded: form_helper
INFO - 2018-02-15 17:56:24 --> Form Validation Class Initialized
INFO - 2018-02-15 17:56:24 --> Model Class Initialized
INFO - 2018-02-15 17:56:24 --> Controller Class Initialized
INFO - 2018-02-15 17:56:24 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 17:56:24 --> Model Class Initialized
INFO - 2018-02-15 17:56:24 --> Model Class Initialized
INFO - 2018-02-15 17:56:24 --> Model Class Initialized
DEBUG - 2018-02-15 17:56:24 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-15 17:56:24 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-02-15 17:56:24 --> Config Class Initialized
INFO - 2018-02-15 17:56:24 --> Hooks Class Initialized
DEBUG - 2018-02-15 17:56:24 --> UTF-8 Support Enabled
INFO - 2018-02-15 17:56:24 --> Utf8 Class Initialized
INFO - 2018-02-15 17:56:24 --> URI Class Initialized
INFO - 2018-02-15 17:56:24 --> Router Class Initialized
INFO - 2018-02-15 17:56:24 --> Output Class Initialized
INFO - 2018-02-15 17:56:24 --> Security Class Initialized
DEBUG - 2018-02-15 17:56:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 17:56:24 --> Input Class Initialized
INFO - 2018-02-15 17:56:24 --> Language Class Initialized
INFO - 2018-02-15 17:56:24 --> Loader Class Initialized
INFO - 2018-02-15 17:56:24 --> Helper loaded: url_helper
INFO - 2018-02-15 17:56:24 --> Helper loaded: file_helper
INFO - 2018-02-15 17:56:24 --> Helper loaded: email_helper
INFO - 2018-02-15 17:56:24 --> Helper loaded: common_helper
INFO - 2018-02-15 17:56:24 --> Database Driver Class Initialized
DEBUG - 2018-02-15 17:56:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 17:56:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 17:56:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 17:56:24 --> Pagination Class Initialized
INFO - 2018-02-15 17:56:24 --> Helper loaded: form_helper
INFO - 2018-02-15 17:56:24 --> Form Validation Class Initialized
INFO - 2018-02-15 17:56:24 --> Model Class Initialized
INFO - 2018-02-15 17:56:24 --> Controller Class Initialized
INFO - 2018-02-15 17:56:24 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 17:56:24 --> Model Class Initialized
INFO - 2018-02-15 17:56:24 --> Model Class Initialized
INFO - 2018-02-15 17:56:24 --> Model Class Initialized
INFO - 2018-02-15 17:56:24 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-15 17:56:24 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-15 17:56:24 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-15 17:56:24 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-15 17:56:24 --> File loaded: /var/www/html/project/radio/application/views/tracks/index.php
INFO - 2018-02-15 17:56:24 --> Final output sent to browser
DEBUG - 2018-02-15 17:56:24 --> Total execution time: 0.0042
INFO - 2018-02-15 17:56:24 --> Config Class Initialized
INFO - 2018-02-15 17:56:24 --> Hooks Class Initialized
DEBUG - 2018-02-15 17:56:24 --> UTF-8 Support Enabled
INFO - 2018-02-15 17:56:24 --> Utf8 Class Initialized
INFO - 2018-02-15 17:56:24 --> URI Class Initialized
INFO - 2018-02-15 17:56:24 --> Router Class Initialized
INFO - 2018-02-15 17:56:24 --> Output Class Initialized
INFO - 2018-02-15 17:56:24 --> Security Class Initialized
DEBUG - 2018-02-15 17:56:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 17:56:24 --> Input Class Initialized
INFO - 2018-02-15 17:56:24 --> Language Class Initialized
INFO - 2018-02-15 17:56:24 --> Loader Class Initialized
INFO - 2018-02-15 17:56:24 --> Helper loaded: url_helper
INFO - 2018-02-15 17:56:24 --> Helper loaded: file_helper
INFO - 2018-02-15 17:56:24 --> Helper loaded: email_helper
INFO - 2018-02-15 17:56:24 --> Helper loaded: common_helper
INFO - 2018-02-15 17:56:24 --> Database Driver Class Initialized
DEBUG - 2018-02-15 17:56:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 17:56:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 17:56:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 17:56:24 --> Pagination Class Initialized
INFO - 2018-02-15 17:56:24 --> Helper loaded: form_helper
INFO - 2018-02-15 17:56:24 --> Form Validation Class Initialized
INFO - 2018-02-15 17:56:24 --> Model Class Initialized
INFO - 2018-02-15 17:56:24 --> Controller Class Initialized
INFO - 2018-02-15 17:56:24 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 17:56:24 --> Model Class Initialized
INFO - 2018-02-15 17:56:24 --> Model Class Initialized
INFO - 2018-02-15 17:56:24 --> Model Class Initialized
INFO - 2018-02-15 17:56:40 --> Config Class Initialized
INFO - 2018-02-15 17:56:40 --> Hooks Class Initialized
DEBUG - 2018-02-15 17:56:40 --> UTF-8 Support Enabled
INFO - 2018-02-15 17:56:40 --> Utf8 Class Initialized
INFO - 2018-02-15 17:56:40 --> URI Class Initialized
INFO - 2018-02-15 17:56:40 --> Router Class Initialized
INFO - 2018-02-15 17:56:40 --> Output Class Initialized
INFO - 2018-02-15 17:56:40 --> Security Class Initialized
DEBUG - 2018-02-15 17:56:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 17:56:40 --> Input Class Initialized
INFO - 2018-02-15 17:56:40 --> Language Class Initialized
INFO - 2018-02-15 17:56:40 --> Loader Class Initialized
INFO - 2018-02-15 17:56:40 --> Helper loaded: url_helper
INFO - 2018-02-15 17:56:40 --> Helper loaded: file_helper
INFO - 2018-02-15 17:56:40 --> Helper loaded: email_helper
INFO - 2018-02-15 17:56:40 --> Helper loaded: common_helper
INFO - 2018-02-15 17:56:40 --> Database Driver Class Initialized
DEBUG - 2018-02-15 17:56:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 17:56:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 17:56:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 17:56:40 --> Pagination Class Initialized
INFO - 2018-02-15 17:56:40 --> Helper loaded: form_helper
INFO - 2018-02-15 17:56:40 --> Form Validation Class Initialized
INFO - 2018-02-15 17:56:40 --> Model Class Initialized
INFO - 2018-02-15 17:56:40 --> Controller Class Initialized
INFO - 2018-02-15 17:56:40 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 17:56:40 --> Model Class Initialized
INFO - 2018-02-15 17:56:40 --> Model Class Initialized
INFO - 2018-02-15 17:56:40 --> Model Class Initialized
INFO - 2018-02-15 17:56:40 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-15 17:56:40 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-15 17:56:40 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-15 17:56:40 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-15 17:56:40 --> File loaded: /var/www/html/project/radio/application/views/tracks/add_edit.php
INFO - 2018-02-15 17:56:40 --> Final output sent to browser
DEBUG - 2018-02-15 17:56:40 --> Total execution time: 0.0045
INFO - 2018-02-15 17:56:42 --> Config Class Initialized
INFO - 2018-02-15 17:56:42 --> Hooks Class Initialized
DEBUG - 2018-02-15 17:56:42 --> UTF-8 Support Enabled
INFO - 2018-02-15 17:56:42 --> Utf8 Class Initialized
INFO - 2018-02-15 17:56:42 --> URI Class Initialized
INFO - 2018-02-15 17:56:42 --> Router Class Initialized
INFO - 2018-02-15 17:56:42 --> Output Class Initialized
INFO - 2018-02-15 17:56:42 --> Security Class Initialized
DEBUG - 2018-02-15 17:56:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 17:56:42 --> Input Class Initialized
INFO - 2018-02-15 17:56:42 --> Language Class Initialized
INFO - 2018-02-15 17:56:42 --> Loader Class Initialized
INFO - 2018-02-15 17:56:42 --> Helper loaded: url_helper
INFO - 2018-02-15 17:56:42 --> Helper loaded: file_helper
INFO - 2018-02-15 17:56:42 --> Helper loaded: email_helper
INFO - 2018-02-15 17:56:42 --> Helper loaded: common_helper
INFO - 2018-02-15 17:56:42 --> Database Driver Class Initialized
DEBUG - 2018-02-15 17:56:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 17:56:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 17:56:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 17:56:42 --> Pagination Class Initialized
INFO - 2018-02-15 17:56:42 --> Helper loaded: form_helper
INFO - 2018-02-15 17:56:42 --> Form Validation Class Initialized
INFO - 2018-02-15 17:56:42 --> Model Class Initialized
INFO - 2018-02-15 17:56:42 --> Controller Class Initialized
INFO - 2018-02-15 17:56:42 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 17:56:42 --> Model Class Initialized
INFO - 2018-02-15 17:56:42 --> Model Class Initialized
INFO - 2018-02-15 17:56:42 --> Model Class Initialized
INFO - 2018-02-15 17:56:48 --> Config Class Initialized
INFO - 2018-02-15 17:56:48 --> Hooks Class Initialized
DEBUG - 2018-02-15 17:56:48 --> UTF-8 Support Enabled
INFO - 2018-02-15 17:56:48 --> Utf8 Class Initialized
INFO - 2018-02-15 17:56:48 --> URI Class Initialized
INFO - 2018-02-15 17:56:48 --> Router Class Initialized
INFO - 2018-02-15 17:56:48 --> Output Class Initialized
INFO - 2018-02-15 17:56:48 --> Security Class Initialized
DEBUG - 2018-02-15 17:56:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 17:56:48 --> Input Class Initialized
INFO - 2018-02-15 17:56:48 --> Language Class Initialized
INFO - 2018-02-15 17:56:48 --> Loader Class Initialized
INFO - 2018-02-15 17:56:48 --> Helper loaded: url_helper
INFO - 2018-02-15 17:56:48 --> Helper loaded: file_helper
INFO - 2018-02-15 17:56:48 --> Helper loaded: email_helper
INFO - 2018-02-15 17:56:48 --> Helper loaded: common_helper
INFO - 2018-02-15 17:56:48 --> Database Driver Class Initialized
DEBUG - 2018-02-15 17:56:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 17:56:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 17:56:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 17:56:48 --> Pagination Class Initialized
INFO - 2018-02-15 17:56:48 --> Helper loaded: form_helper
INFO - 2018-02-15 17:56:48 --> Form Validation Class Initialized
INFO - 2018-02-15 17:56:48 --> Model Class Initialized
INFO - 2018-02-15 17:56:48 --> Controller Class Initialized
INFO - 2018-02-15 17:56:48 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 17:56:48 --> Model Class Initialized
INFO - 2018-02-15 17:56:48 --> Model Class Initialized
INFO - 2018-02-15 17:56:48 --> Model Class Initialized
DEBUG - 2018-02-15 17:56:48 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-15 17:56:48 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-02-15 17:56:48 --> Config Class Initialized
INFO - 2018-02-15 17:56:48 --> Hooks Class Initialized
DEBUG - 2018-02-15 17:56:48 --> UTF-8 Support Enabled
INFO - 2018-02-15 17:56:48 --> Utf8 Class Initialized
INFO - 2018-02-15 17:56:48 --> URI Class Initialized
INFO - 2018-02-15 17:56:48 --> Router Class Initialized
INFO - 2018-02-15 17:56:48 --> Output Class Initialized
INFO - 2018-02-15 17:56:48 --> Security Class Initialized
DEBUG - 2018-02-15 17:56:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 17:56:48 --> Input Class Initialized
INFO - 2018-02-15 17:56:48 --> Language Class Initialized
INFO - 2018-02-15 17:56:48 --> Loader Class Initialized
INFO - 2018-02-15 17:56:48 --> Helper loaded: url_helper
INFO - 2018-02-15 17:56:48 --> Helper loaded: file_helper
INFO - 2018-02-15 17:56:48 --> Helper loaded: email_helper
INFO - 2018-02-15 17:56:48 --> Helper loaded: common_helper
INFO - 2018-02-15 17:56:48 --> Database Driver Class Initialized
DEBUG - 2018-02-15 17:56:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 17:56:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 17:56:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 17:56:48 --> Pagination Class Initialized
INFO - 2018-02-15 17:56:48 --> Helper loaded: form_helper
INFO - 2018-02-15 17:56:48 --> Form Validation Class Initialized
INFO - 2018-02-15 17:56:48 --> Model Class Initialized
INFO - 2018-02-15 17:56:48 --> Controller Class Initialized
INFO - 2018-02-15 17:56:48 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 17:56:48 --> Model Class Initialized
INFO - 2018-02-15 17:56:48 --> Model Class Initialized
INFO - 2018-02-15 17:56:48 --> Model Class Initialized
INFO - 2018-02-15 17:56:48 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-15 17:56:48 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-15 17:56:48 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-15 17:56:48 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-15 17:56:48 --> File loaded: /var/www/html/project/radio/application/views/tracks/index.php
INFO - 2018-02-15 17:56:48 --> Final output sent to browser
DEBUG - 2018-02-15 17:56:48 --> Total execution time: 0.0036
INFO - 2018-02-15 17:56:48 --> Config Class Initialized
INFO - 2018-02-15 17:56:48 --> Hooks Class Initialized
DEBUG - 2018-02-15 17:56:48 --> UTF-8 Support Enabled
INFO - 2018-02-15 17:56:48 --> Utf8 Class Initialized
INFO - 2018-02-15 17:56:48 --> URI Class Initialized
INFO - 2018-02-15 17:56:48 --> Router Class Initialized
INFO - 2018-02-15 17:56:48 --> Output Class Initialized
INFO - 2018-02-15 17:56:48 --> Security Class Initialized
DEBUG - 2018-02-15 17:56:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 17:56:48 --> Input Class Initialized
INFO - 2018-02-15 17:56:48 --> Language Class Initialized
INFO - 2018-02-15 17:56:48 --> Loader Class Initialized
INFO - 2018-02-15 17:56:48 --> Helper loaded: url_helper
INFO - 2018-02-15 17:56:48 --> Helper loaded: file_helper
INFO - 2018-02-15 17:56:48 --> Helper loaded: email_helper
INFO - 2018-02-15 17:56:48 --> Helper loaded: common_helper
INFO - 2018-02-15 17:56:48 --> Database Driver Class Initialized
DEBUG - 2018-02-15 17:56:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 17:56:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 17:56:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 17:56:48 --> Pagination Class Initialized
INFO - 2018-02-15 17:56:48 --> Helper loaded: form_helper
INFO - 2018-02-15 17:56:48 --> Form Validation Class Initialized
INFO - 2018-02-15 17:56:48 --> Model Class Initialized
INFO - 2018-02-15 17:56:48 --> Controller Class Initialized
INFO - 2018-02-15 17:56:48 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 17:56:48 --> Model Class Initialized
INFO - 2018-02-15 17:56:48 --> Model Class Initialized
INFO - 2018-02-15 17:56:48 --> Model Class Initialized
INFO - 2018-02-15 18:23:18 --> Config Class Initialized
INFO - 2018-02-15 18:23:18 --> Hooks Class Initialized
DEBUG - 2018-02-15 18:23:18 --> UTF-8 Support Enabled
INFO - 2018-02-15 18:23:18 --> Utf8 Class Initialized
INFO - 2018-02-15 18:23:18 --> URI Class Initialized
INFO - 2018-02-15 18:23:18 --> Router Class Initialized
INFO - 2018-02-15 18:23:18 --> Output Class Initialized
INFO - 2018-02-15 18:23:18 --> Security Class Initialized
DEBUG - 2018-02-15 18:23:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 18:23:18 --> Input Class Initialized
INFO - 2018-02-15 18:23:18 --> Language Class Initialized
INFO - 2018-02-15 18:23:18 --> Loader Class Initialized
INFO - 2018-02-15 18:23:18 --> Helper loaded: url_helper
INFO - 2018-02-15 18:23:18 --> Helper loaded: file_helper
INFO - 2018-02-15 18:23:18 --> Helper loaded: email_helper
INFO - 2018-02-15 18:23:18 --> Helper loaded: common_helper
INFO - 2018-02-15 18:23:18 --> Database Driver Class Initialized
DEBUG - 2018-02-15 18:23:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 18:23:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 18:23:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 18:23:18 --> Pagination Class Initialized
INFO - 2018-02-15 18:23:18 --> Helper loaded: form_helper
INFO - 2018-02-15 18:23:18 --> Form Validation Class Initialized
INFO - 2018-02-15 18:23:18 --> Model Class Initialized
INFO - 2018-02-15 18:23:18 --> Controller Class Initialized
INFO - 2018-02-15 18:23:18 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 18:23:18 --> Model Class Initialized
INFO - 2018-02-15 18:23:18 --> Model Class Initialized
INFO - 2018-02-15 18:23:18 --> Model Class Initialized
INFO - 2018-02-15 18:23:18 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-15 18:23:18 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-15 18:23:18 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-15 18:23:18 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-15 18:23:18 --> File loaded: /var/www/html/project/radio/application/views/tracks/index.php
INFO - 2018-02-15 18:23:18 --> Final output sent to browser
DEBUG - 2018-02-15 18:23:18 --> Total execution time: 0.0048
INFO - 2018-02-15 18:23:18 --> Config Class Initialized
INFO - 2018-02-15 18:23:18 --> Hooks Class Initialized
DEBUG - 2018-02-15 18:23:18 --> UTF-8 Support Enabled
INFO - 2018-02-15 18:23:18 --> Utf8 Class Initialized
INFO - 2018-02-15 18:23:18 --> URI Class Initialized
INFO - 2018-02-15 18:23:18 --> Router Class Initialized
INFO - 2018-02-15 18:23:18 --> Output Class Initialized
INFO - 2018-02-15 18:23:18 --> Security Class Initialized
DEBUG - 2018-02-15 18:23:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 18:23:18 --> Input Class Initialized
INFO - 2018-02-15 18:23:18 --> Language Class Initialized
INFO - 2018-02-15 18:23:18 --> Loader Class Initialized
INFO - 2018-02-15 18:23:18 --> Helper loaded: url_helper
INFO - 2018-02-15 18:23:18 --> Helper loaded: file_helper
INFO - 2018-02-15 18:23:18 --> Helper loaded: email_helper
INFO - 2018-02-15 18:23:18 --> Helper loaded: common_helper
INFO - 2018-02-15 18:23:18 --> Database Driver Class Initialized
DEBUG - 2018-02-15 18:23:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 18:23:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 18:23:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 18:23:18 --> Pagination Class Initialized
INFO - 2018-02-15 18:23:18 --> Helper loaded: form_helper
INFO - 2018-02-15 18:23:18 --> Form Validation Class Initialized
INFO - 2018-02-15 18:23:18 --> Model Class Initialized
INFO - 2018-02-15 18:23:18 --> Controller Class Initialized
INFO - 2018-02-15 18:23:18 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 18:23:18 --> Model Class Initialized
INFO - 2018-02-15 18:23:18 --> Model Class Initialized
INFO - 2018-02-15 18:23:18 --> Model Class Initialized
INFO - 2018-02-15 18:23:19 --> Config Class Initialized
INFO - 2018-02-15 18:23:19 --> Hooks Class Initialized
DEBUG - 2018-02-15 18:23:19 --> UTF-8 Support Enabled
INFO - 2018-02-15 18:23:19 --> Utf8 Class Initialized
INFO - 2018-02-15 18:23:19 --> URI Class Initialized
INFO - 2018-02-15 18:23:19 --> Router Class Initialized
INFO - 2018-02-15 18:23:19 --> Output Class Initialized
INFO - 2018-02-15 18:23:19 --> Security Class Initialized
DEBUG - 2018-02-15 18:23:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 18:23:19 --> Input Class Initialized
INFO - 2018-02-15 18:23:19 --> Language Class Initialized
INFO - 2018-02-15 18:23:19 --> Loader Class Initialized
INFO - 2018-02-15 18:23:19 --> Helper loaded: url_helper
INFO - 2018-02-15 18:23:19 --> Helper loaded: file_helper
INFO - 2018-02-15 18:23:19 --> Helper loaded: email_helper
INFO - 2018-02-15 18:23:19 --> Helper loaded: common_helper
INFO - 2018-02-15 18:23:19 --> Database Driver Class Initialized
DEBUG - 2018-02-15 18:23:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 18:23:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 18:23:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 18:23:19 --> Pagination Class Initialized
INFO - 2018-02-15 18:23:19 --> Helper loaded: form_helper
INFO - 2018-02-15 18:23:19 --> Form Validation Class Initialized
INFO - 2018-02-15 18:23:19 --> Model Class Initialized
INFO - 2018-02-15 18:23:19 --> Controller Class Initialized
INFO - 2018-02-15 18:23:19 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 18:23:19 --> Model Class Initialized
INFO - 2018-02-15 18:23:19 --> Model Class Initialized
INFO - 2018-02-15 18:23:19 --> Model Class Initialized
INFO - 2018-02-15 18:23:19 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-15 18:23:19 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-15 18:23:19 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-15 18:23:19 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-15 18:23:19 --> File loaded: /var/www/html/project/radio/application/views/tracks/add_edit.php
INFO - 2018-02-15 18:23:19 --> Final output sent to browser
DEBUG - 2018-02-15 18:23:19 --> Total execution time: 0.0047
INFO - 2018-02-15 18:23:36 --> Config Class Initialized
INFO - 2018-02-15 18:23:36 --> Hooks Class Initialized
DEBUG - 2018-02-15 18:23:36 --> UTF-8 Support Enabled
INFO - 2018-02-15 18:23:36 --> Utf8 Class Initialized
INFO - 2018-02-15 18:23:36 --> URI Class Initialized
INFO - 2018-02-15 18:23:36 --> Router Class Initialized
INFO - 2018-02-15 18:23:36 --> Output Class Initialized
INFO - 2018-02-15 18:23:36 --> Security Class Initialized
DEBUG - 2018-02-15 18:23:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 18:23:36 --> Input Class Initialized
INFO - 2018-02-15 18:23:36 --> Language Class Initialized
INFO - 2018-02-15 18:23:36 --> Loader Class Initialized
INFO - 2018-02-15 18:23:36 --> Helper loaded: url_helper
INFO - 2018-02-15 18:23:36 --> Helper loaded: file_helper
INFO - 2018-02-15 18:23:36 --> Helper loaded: email_helper
INFO - 2018-02-15 18:23:36 --> Helper loaded: common_helper
INFO - 2018-02-15 18:23:36 --> Database Driver Class Initialized
DEBUG - 2018-02-15 18:23:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 18:23:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 18:23:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 18:23:36 --> Pagination Class Initialized
INFO - 2018-02-15 18:23:36 --> Helper loaded: form_helper
INFO - 2018-02-15 18:23:36 --> Form Validation Class Initialized
INFO - 2018-02-15 18:23:36 --> Model Class Initialized
INFO - 2018-02-15 18:23:36 --> Controller Class Initialized
INFO - 2018-02-15 18:23:36 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 18:23:36 --> Model Class Initialized
INFO - 2018-02-15 18:23:36 --> Model Class Initialized
INFO - 2018-02-15 18:23:36 --> Model Class Initialized
INFO - 2018-02-15 18:23:36 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-15 18:23:36 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-15 18:23:36 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-15 18:23:36 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-15 18:23:36 --> File loaded: /var/www/html/project/radio/application/views/tracks/add_edit.php
INFO - 2018-02-15 18:23:36 --> Final output sent to browser
DEBUG - 2018-02-15 18:23:36 --> Total execution time: 0.0056
INFO - 2018-02-15 18:26:37 --> Config Class Initialized
INFO - 2018-02-15 18:26:37 --> Hooks Class Initialized
DEBUG - 2018-02-15 18:26:37 --> UTF-8 Support Enabled
INFO - 2018-02-15 18:26:37 --> Utf8 Class Initialized
INFO - 2018-02-15 18:26:37 --> URI Class Initialized
INFO - 2018-02-15 18:26:37 --> Router Class Initialized
INFO - 2018-02-15 18:26:37 --> Output Class Initialized
INFO - 2018-02-15 18:26:37 --> Security Class Initialized
DEBUG - 2018-02-15 18:26:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 18:26:37 --> Input Class Initialized
INFO - 2018-02-15 18:26:37 --> Language Class Initialized
INFO - 2018-02-15 18:26:37 --> Loader Class Initialized
INFO - 2018-02-15 18:26:37 --> Helper loaded: url_helper
INFO - 2018-02-15 18:26:37 --> Helper loaded: file_helper
INFO - 2018-02-15 18:26:37 --> Helper loaded: email_helper
INFO - 2018-02-15 18:26:37 --> Helper loaded: common_helper
INFO - 2018-02-15 18:26:37 --> Database Driver Class Initialized
DEBUG - 2018-02-15 18:26:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 18:26:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 18:26:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 18:26:37 --> Pagination Class Initialized
INFO - 2018-02-15 18:26:37 --> Helper loaded: form_helper
INFO - 2018-02-15 18:26:37 --> Form Validation Class Initialized
INFO - 2018-02-15 18:26:37 --> Model Class Initialized
INFO - 2018-02-15 18:26:37 --> Controller Class Initialized
INFO - 2018-02-15 18:26:37 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 18:26:37 --> Model Class Initialized
INFO - 2018-02-15 18:26:37 --> Model Class Initialized
INFO - 2018-02-15 18:26:37 --> Model Class Initialized
INFO - 2018-02-15 18:26:37 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-15 18:26:37 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-15 18:26:37 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-15 18:26:37 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-15 18:26:37 --> File loaded: /var/www/html/project/radio/application/views/tracks/add_edit.php
INFO - 2018-02-15 18:26:37 --> Final output sent to browser
DEBUG - 2018-02-15 18:26:37 --> Total execution time: 0.0055
INFO - 2018-02-15 18:26:43 --> Config Class Initialized
INFO - 2018-02-15 18:26:43 --> Hooks Class Initialized
DEBUG - 2018-02-15 18:26:43 --> UTF-8 Support Enabled
INFO - 2018-02-15 18:26:43 --> Utf8 Class Initialized
INFO - 2018-02-15 18:26:43 --> URI Class Initialized
INFO - 2018-02-15 18:26:43 --> Router Class Initialized
INFO - 2018-02-15 18:26:43 --> Output Class Initialized
INFO - 2018-02-15 18:26:43 --> Security Class Initialized
DEBUG - 2018-02-15 18:26:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 18:26:43 --> Input Class Initialized
INFO - 2018-02-15 18:26:43 --> Language Class Initialized
INFO - 2018-02-15 18:26:43 --> Loader Class Initialized
INFO - 2018-02-15 18:26:43 --> Helper loaded: url_helper
INFO - 2018-02-15 18:26:43 --> Helper loaded: file_helper
INFO - 2018-02-15 18:26:43 --> Helper loaded: email_helper
INFO - 2018-02-15 18:26:43 --> Helper loaded: common_helper
INFO - 2018-02-15 18:26:43 --> Database Driver Class Initialized
DEBUG - 2018-02-15 18:26:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 18:26:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 18:26:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 18:26:43 --> Pagination Class Initialized
INFO - 2018-02-15 18:26:43 --> Helper loaded: form_helper
INFO - 2018-02-15 18:26:43 --> Form Validation Class Initialized
INFO - 2018-02-15 18:26:43 --> Model Class Initialized
INFO - 2018-02-15 18:26:43 --> Controller Class Initialized
INFO - 2018-02-15 18:26:43 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 18:26:43 --> Model Class Initialized
INFO - 2018-02-15 18:26:43 --> Model Class Initialized
INFO - 2018-02-15 18:26:43 --> Model Class Initialized
INFO - 2018-02-15 18:26:43 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-15 18:26:43 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-15 18:26:43 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-15 18:26:43 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-15 18:26:43 --> File loaded: /var/www/html/project/radio/application/views/tracks/add_edit.php
INFO - 2018-02-15 18:26:43 --> Final output sent to browser
DEBUG - 2018-02-15 18:26:43 --> Total execution time: 0.0045
INFO - 2018-02-15 18:44:03 --> Config Class Initialized
INFO - 2018-02-15 18:44:03 --> Hooks Class Initialized
DEBUG - 2018-02-15 18:44:03 --> UTF-8 Support Enabled
INFO - 2018-02-15 18:44:03 --> Utf8 Class Initialized
INFO - 2018-02-15 18:44:03 --> URI Class Initialized
DEBUG - 2018-02-15 18:44:03 --> No URI present. Default controller set.
INFO - 2018-02-15 18:44:03 --> Router Class Initialized
INFO - 2018-02-15 18:44:03 --> Output Class Initialized
INFO - 2018-02-15 18:44:03 --> Security Class Initialized
DEBUG - 2018-02-15 18:44:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 18:44:03 --> Input Class Initialized
INFO - 2018-02-15 18:44:03 --> Language Class Initialized
INFO - 2018-02-15 18:44:03 --> Loader Class Initialized
INFO - 2018-02-15 18:44:03 --> Helper loaded: url_helper
INFO - 2018-02-15 18:44:03 --> Helper loaded: file_helper
INFO - 2018-02-15 18:44:03 --> Helper loaded: email_helper
INFO - 2018-02-15 18:44:03 --> Helper loaded: common_helper
INFO - 2018-02-15 18:44:03 --> Database Driver Class Initialized
DEBUG - 2018-02-15 18:44:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 18:44:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 18:44:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 18:44:03 --> Pagination Class Initialized
INFO - 2018-02-15 18:44:03 --> Helper loaded: form_helper
INFO - 2018-02-15 18:44:03 --> Form Validation Class Initialized
INFO - 2018-02-15 18:44:03 --> Model Class Initialized
INFO - 2018-02-15 18:44:03 --> Controller Class Initialized
INFO - 2018-02-15 18:44:03 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 18:44:03 --> Model Class Initialized
INFO - 2018-02-15 18:44:03 --> File loaded: /var/www/html/project/radio/application/views/index/index.php
INFO - 2018-02-15 18:44:03 --> Final output sent to browser
DEBUG - 2018-02-15 18:44:03 --> Total execution time: 0.0064
INFO - 2018-02-15 18:44:09 --> Config Class Initialized
INFO - 2018-02-15 18:44:09 --> Hooks Class Initialized
DEBUG - 2018-02-15 18:44:09 --> UTF-8 Support Enabled
INFO - 2018-02-15 18:44:09 --> Utf8 Class Initialized
INFO - 2018-02-15 18:44:09 --> URI Class Initialized
INFO - 2018-02-15 18:44:09 --> Router Class Initialized
INFO - 2018-02-15 18:44:09 --> Output Class Initialized
INFO - 2018-02-15 18:44:09 --> Security Class Initialized
DEBUG - 2018-02-15 18:44:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 18:44:09 --> Input Class Initialized
INFO - 2018-02-15 18:44:09 --> Language Class Initialized
INFO - 2018-02-15 18:44:09 --> Loader Class Initialized
INFO - 2018-02-15 18:44:09 --> Helper loaded: url_helper
INFO - 2018-02-15 18:44:09 --> Helper loaded: file_helper
INFO - 2018-02-15 18:44:09 --> Helper loaded: email_helper
INFO - 2018-02-15 18:44:09 --> Helper loaded: common_helper
INFO - 2018-02-15 18:44:09 --> Database Driver Class Initialized
DEBUG - 2018-02-15 18:44:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 18:44:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 18:44:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 18:44:09 --> Pagination Class Initialized
INFO - 2018-02-15 18:44:09 --> Helper loaded: form_helper
INFO - 2018-02-15 18:44:09 --> Form Validation Class Initialized
INFO - 2018-02-15 18:44:09 --> Model Class Initialized
INFO - 2018-02-15 18:44:09 --> Controller Class Initialized
INFO - 2018-02-15 18:44:09 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 18:44:09 --> Model Class Initialized
ERROR - 2018-02-15 18:44:09 --> Severity: Notice --> Undefined index: remember_me /var/www/html/project/radio/application/controllers/Index.php 73
INFO - 2018-02-15 18:44:09 --> Config Class Initialized
INFO - 2018-02-15 18:44:09 --> Hooks Class Initialized
DEBUG - 2018-02-15 18:44:09 --> UTF-8 Support Enabled
INFO - 2018-02-15 18:44:09 --> Utf8 Class Initialized
INFO - 2018-02-15 18:44:09 --> URI Class Initialized
INFO - 2018-02-15 18:44:09 --> Router Class Initialized
INFO - 2018-02-15 18:44:09 --> Output Class Initialized
INFO - 2018-02-15 18:44:09 --> Security Class Initialized
DEBUG - 2018-02-15 18:44:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 18:44:09 --> Input Class Initialized
INFO - 2018-02-15 18:44:09 --> Language Class Initialized
INFO - 2018-02-15 18:44:09 --> Loader Class Initialized
INFO - 2018-02-15 18:44:09 --> Helper loaded: url_helper
INFO - 2018-02-15 18:44:09 --> Helper loaded: file_helper
INFO - 2018-02-15 18:44:09 --> Helper loaded: email_helper
INFO - 2018-02-15 18:44:09 --> Helper loaded: common_helper
INFO - 2018-02-15 18:44:09 --> Database Driver Class Initialized
DEBUG - 2018-02-15 18:44:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 18:44:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 18:44:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 18:44:09 --> Pagination Class Initialized
INFO - 2018-02-15 18:44:09 --> Helper loaded: form_helper
INFO - 2018-02-15 18:44:09 --> Form Validation Class Initialized
INFO - 2018-02-15 18:44:09 --> Model Class Initialized
INFO - 2018-02-15 18:44:09 --> Controller Class Initialized
INFO - 2018-02-15 18:44:09 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 18:44:09 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-15 18:44:09 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-15 18:44:09 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-15 18:44:09 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-15 18:44:09 --> File loaded: /var/www/html/project/radio/application/views/dashboard/index.php
INFO - 2018-02-15 18:44:09 --> Final output sent to browser
DEBUG - 2018-02-15 18:44:09 --> Total execution time: 0.0060
INFO - 2018-02-15 18:44:16 --> Config Class Initialized
INFO - 2018-02-15 18:44:16 --> Hooks Class Initialized
DEBUG - 2018-02-15 18:44:16 --> UTF-8 Support Enabled
INFO - 2018-02-15 18:44:16 --> Utf8 Class Initialized
INFO - 2018-02-15 18:44:16 --> URI Class Initialized
INFO - 2018-02-15 18:44:16 --> Router Class Initialized
INFO - 2018-02-15 18:44:16 --> Output Class Initialized
INFO - 2018-02-15 18:44:16 --> Security Class Initialized
DEBUG - 2018-02-15 18:44:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 18:44:16 --> Input Class Initialized
INFO - 2018-02-15 18:44:16 --> Language Class Initialized
INFO - 2018-02-15 18:44:16 --> Loader Class Initialized
INFO - 2018-02-15 18:44:16 --> Helper loaded: url_helper
INFO - 2018-02-15 18:44:16 --> Helper loaded: file_helper
INFO - 2018-02-15 18:44:16 --> Helper loaded: email_helper
INFO - 2018-02-15 18:44:16 --> Helper loaded: common_helper
INFO - 2018-02-15 18:44:16 --> Database Driver Class Initialized
DEBUG - 2018-02-15 18:44:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 18:44:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 18:44:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 18:44:16 --> Pagination Class Initialized
INFO - 2018-02-15 18:44:16 --> Helper loaded: form_helper
INFO - 2018-02-15 18:44:16 --> Form Validation Class Initialized
INFO - 2018-02-15 18:44:16 --> Model Class Initialized
INFO - 2018-02-15 18:44:16 --> Controller Class Initialized
INFO - 2018-02-15 18:44:16 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 18:44:16 --> Model Class Initialized
INFO - 2018-02-15 18:44:16 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-15 18:44:16 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-15 18:44:16 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-15 18:44:16 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-15 18:44:16 --> File loaded: /var/www/html/project/radio/application/views/user/index.php
INFO - 2018-02-15 18:44:16 --> Final output sent to browser
DEBUG - 2018-02-15 18:44:16 --> Total execution time: 0.0071
INFO - 2018-02-15 18:44:16 --> Config Class Initialized
INFO - 2018-02-15 18:44:16 --> Hooks Class Initialized
DEBUG - 2018-02-15 18:44:16 --> UTF-8 Support Enabled
INFO - 2018-02-15 18:44:16 --> Utf8 Class Initialized
INFO - 2018-02-15 18:44:16 --> URI Class Initialized
INFO - 2018-02-15 18:44:16 --> Router Class Initialized
INFO - 2018-02-15 18:44:16 --> Output Class Initialized
INFO - 2018-02-15 18:44:16 --> Security Class Initialized
DEBUG - 2018-02-15 18:44:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 18:44:16 --> Input Class Initialized
INFO - 2018-02-15 18:44:16 --> Language Class Initialized
INFO - 2018-02-15 18:44:16 --> Loader Class Initialized
INFO - 2018-02-15 18:44:16 --> Helper loaded: url_helper
INFO - 2018-02-15 18:44:16 --> Helper loaded: file_helper
INFO - 2018-02-15 18:44:16 --> Helper loaded: email_helper
INFO - 2018-02-15 18:44:16 --> Helper loaded: common_helper
INFO - 2018-02-15 18:44:16 --> Database Driver Class Initialized
DEBUG - 2018-02-15 18:44:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 18:44:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 18:44:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 18:44:16 --> Pagination Class Initialized
INFO - 2018-02-15 18:44:16 --> Helper loaded: form_helper
INFO - 2018-02-15 18:44:16 --> Form Validation Class Initialized
INFO - 2018-02-15 18:44:16 --> Model Class Initialized
INFO - 2018-02-15 18:44:16 --> Controller Class Initialized
INFO - 2018-02-15 18:44:16 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 18:44:16 --> Model Class Initialized
INFO - 2018-02-15 18:44:20 --> Config Class Initialized
INFO - 2018-02-15 18:44:20 --> Hooks Class Initialized
DEBUG - 2018-02-15 18:44:20 --> UTF-8 Support Enabled
INFO - 2018-02-15 18:44:20 --> Utf8 Class Initialized
INFO - 2018-02-15 18:44:20 --> URI Class Initialized
INFO - 2018-02-15 18:44:20 --> Router Class Initialized
INFO - 2018-02-15 18:44:20 --> Output Class Initialized
INFO - 2018-02-15 18:44:20 --> Security Class Initialized
DEBUG - 2018-02-15 18:44:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 18:44:20 --> Input Class Initialized
INFO - 2018-02-15 18:44:20 --> Language Class Initialized
INFO - 2018-02-15 18:44:20 --> Loader Class Initialized
INFO - 2018-02-15 18:44:20 --> Helper loaded: url_helper
INFO - 2018-02-15 18:44:20 --> Helper loaded: file_helper
INFO - 2018-02-15 18:44:20 --> Helper loaded: email_helper
INFO - 2018-02-15 18:44:20 --> Helper loaded: common_helper
INFO - 2018-02-15 18:44:20 --> Database Driver Class Initialized
DEBUG - 2018-02-15 18:44:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 18:44:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 18:44:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 18:44:20 --> Pagination Class Initialized
INFO - 2018-02-15 18:44:20 --> Helper loaded: form_helper
INFO - 2018-02-15 18:44:20 --> Form Validation Class Initialized
INFO - 2018-02-15 18:44:20 --> Model Class Initialized
INFO - 2018-02-15 18:44:20 --> Controller Class Initialized
INFO - 2018-02-15 18:44:20 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 18:44:20 --> Model Class Initialized
INFO - 2018-02-15 18:44:20 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-15 18:44:20 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-15 18:44:20 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-15 18:44:20 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-15 18:44:20 --> File loaded: /var/www/html/project/radio/application/views/category/index.php
INFO - 2018-02-15 18:44:20 --> Final output sent to browser
DEBUG - 2018-02-15 18:44:20 --> Total execution time: 0.0069
INFO - 2018-02-15 18:44:28 --> Config Class Initialized
INFO - 2018-02-15 18:44:28 --> Hooks Class Initialized
DEBUG - 2018-02-15 18:44:28 --> UTF-8 Support Enabled
INFO - 2018-02-15 18:44:28 --> Utf8 Class Initialized
INFO - 2018-02-15 18:44:28 --> URI Class Initialized
INFO - 2018-02-15 18:44:28 --> Router Class Initialized
INFO - 2018-02-15 18:44:28 --> Output Class Initialized
INFO - 2018-02-15 18:44:28 --> Security Class Initialized
DEBUG - 2018-02-15 18:44:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 18:44:28 --> Input Class Initialized
INFO - 2018-02-15 18:44:28 --> Language Class Initialized
INFO - 2018-02-15 18:44:28 --> Loader Class Initialized
INFO - 2018-02-15 18:44:28 --> Helper loaded: url_helper
INFO - 2018-02-15 18:44:28 --> Helper loaded: file_helper
INFO - 2018-02-15 18:44:28 --> Helper loaded: email_helper
INFO - 2018-02-15 18:44:28 --> Helper loaded: common_helper
INFO - 2018-02-15 18:44:28 --> Database Driver Class Initialized
DEBUG - 2018-02-15 18:44:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 18:44:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 18:44:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 18:44:28 --> Pagination Class Initialized
INFO - 2018-02-15 18:44:28 --> Helper loaded: form_helper
INFO - 2018-02-15 18:44:28 --> Form Validation Class Initialized
INFO - 2018-02-15 18:44:28 --> Model Class Initialized
INFO - 2018-02-15 18:44:28 --> Controller Class Initialized
INFO - 2018-02-15 18:44:28 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 18:44:28 --> Model Class Initialized
INFO - 2018-02-15 18:44:28 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-15 18:44:28 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-15 18:44:28 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-15 18:44:28 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-15 18:44:28 --> File loaded: /var/www/html/project/radio/application/views/category/add_edit.php
INFO - 2018-02-15 18:44:28 --> Final output sent to browser
DEBUG - 2018-02-15 18:44:28 --> Total execution time: 0.0073
INFO - 2018-02-15 18:44:43 --> Config Class Initialized
INFO - 2018-02-15 18:44:43 --> Hooks Class Initialized
DEBUG - 2018-02-15 18:44:43 --> UTF-8 Support Enabled
INFO - 2018-02-15 18:44:43 --> Utf8 Class Initialized
INFO - 2018-02-15 18:44:43 --> URI Class Initialized
INFO - 2018-02-15 18:44:43 --> Router Class Initialized
INFO - 2018-02-15 18:44:43 --> Output Class Initialized
INFO - 2018-02-15 18:44:43 --> Security Class Initialized
DEBUG - 2018-02-15 18:44:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 18:44:43 --> Input Class Initialized
INFO - 2018-02-15 18:44:43 --> Language Class Initialized
INFO - 2018-02-15 18:44:43 --> Loader Class Initialized
INFO - 2018-02-15 18:44:43 --> Helper loaded: url_helper
INFO - 2018-02-15 18:44:43 --> Helper loaded: file_helper
INFO - 2018-02-15 18:44:43 --> Helper loaded: email_helper
INFO - 2018-02-15 18:44:43 --> Helper loaded: common_helper
INFO - 2018-02-15 18:44:43 --> Database Driver Class Initialized
DEBUG - 2018-02-15 18:44:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 18:44:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 18:44:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 18:44:43 --> Pagination Class Initialized
INFO - 2018-02-15 18:44:43 --> Helper loaded: form_helper
INFO - 2018-02-15 18:44:43 --> Form Validation Class Initialized
INFO - 2018-02-15 18:44:43 --> Model Class Initialized
INFO - 2018-02-15 18:44:43 --> Controller Class Initialized
INFO - 2018-02-15 18:44:43 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 18:44:43 --> Model Class Initialized
INFO - 2018-02-15 18:44:43 --> Config Class Initialized
INFO - 2018-02-15 18:44:43 --> Hooks Class Initialized
DEBUG - 2018-02-15 18:44:43 --> UTF-8 Support Enabled
INFO - 2018-02-15 18:44:43 --> Utf8 Class Initialized
INFO - 2018-02-15 18:44:43 --> URI Class Initialized
INFO - 2018-02-15 18:44:43 --> Router Class Initialized
INFO - 2018-02-15 18:44:43 --> Output Class Initialized
INFO - 2018-02-15 18:44:43 --> Security Class Initialized
DEBUG - 2018-02-15 18:44:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 18:44:43 --> Input Class Initialized
INFO - 2018-02-15 18:44:43 --> Language Class Initialized
INFO - 2018-02-15 18:44:43 --> Loader Class Initialized
INFO - 2018-02-15 18:44:43 --> Helper loaded: url_helper
INFO - 2018-02-15 18:44:43 --> Helper loaded: file_helper
INFO - 2018-02-15 18:44:43 --> Helper loaded: email_helper
INFO - 2018-02-15 18:44:43 --> Helper loaded: common_helper
INFO - 2018-02-15 18:44:43 --> Database Driver Class Initialized
DEBUG - 2018-02-15 18:44:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 18:44:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 18:44:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 18:44:43 --> Pagination Class Initialized
INFO - 2018-02-15 18:44:43 --> Helper loaded: form_helper
INFO - 2018-02-15 18:44:43 --> Form Validation Class Initialized
INFO - 2018-02-15 18:44:43 --> Model Class Initialized
INFO - 2018-02-15 18:44:43 --> Controller Class Initialized
INFO - 2018-02-15 18:44:43 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 18:44:43 --> Model Class Initialized
DEBUG - 2018-02-15 18:44:43 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-15 18:44:43 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-02-15 18:44:43 --> Config Class Initialized
INFO - 2018-02-15 18:44:43 --> Hooks Class Initialized
DEBUG - 2018-02-15 18:44:43 --> UTF-8 Support Enabled
INFO - 2018-02-15 18:44:43 --> Utf8 Class Initialized
INFO - 2018-02-15 18:44:43 --> URI Class Initialized
INFO - 2018-02-15 18:44:43 --> Router Class Initialized
INFO - 2018-02-15 18:44:43 --> Output Class Initialized
INFO - 2018-02-15 18:44:43 --> Security Class Initialized
DEBUG - 2018-02-15 18:44:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 18:44:43 --> Input Class Initialized
INFO - 2018-02-15 18:44:43 --> Language Class Initialized
INFO - 2018-02-15 18:44:43 --> Loader Class Initialized
INFO - 2018-02-15 18:44:43 --> Helper loaded: url_helper
INFO - 2018-02-15 18:44:43 --> Helper loaded: file_helper
INFO - 2018-02-15 18:44:43 --> Helper loaded: email_helper
INFO - 2018-02-15 18:44:43 --> Helper loaded: common_helper
INFO - 2018-02-15 18:44:43 --> Database Driver Class Initialized
DEBUG - 2018-02-15 18:44:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 18:44:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 18:44:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 18:44:43 --> Pagination Class Initialized
INFO - 2018-02-15 18:44:43 --> Helper loaded: form_helper
INFO - 2018-02-15 18:44:43 --> Form Validation Class Initialized
INFO - 2018-02-15 18:44:43 --> Model Class Initialized
INFO - 2018-02-15 18:44:43 --> Controller Class Initialized
INFO - 2018-02-15 18:44:43 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 18:44:43 --> Model Class Initialized
INFO - 2018-02-15 18:44:43 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-15 18:44:43 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-15 18:44:43 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-15 18:44:43 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-15 18:44:43 --> File loaded: /var/www/html/project/radio/application/views/category/index.php
INFO - 2018-02-15 18:44:43 --> Final output sent to browser
DEBUG - 2018-02-15 18:44:43 --> Total execution time: 0.0072
INFO - 2018-02-15 18:44:52 --> Config Class Initialized
INFO - 2018-02-15 18:44:52 --> Hooks Class Initialized
DEBUG - 2018-02-15 18:44:52 --> UTF-8 Support Enabled
INFO - 2018-02-15 18:44:52 --> Utf8 Class Initialized
INFO - 2018-02-15 18:44:52 --> URI Class Initialized
INFO - 2018-02-15 18:44:52 --> Router Class Initialized
INFO - 2018-02-15 18:44:52 --> Output Class Initialized
INFO - 2018-02-15 18:44:52 --> Security Class Initialized
DEBUG - 2018-02-15 18:44:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 18:44:52 --> Input Class Initialized
INFO - 2018-02-15 18:44:52 --> Language Class Initialized
INFO - 2018-02-15 18:44:52 --> Loader Class Initialized
INFO - 2018-02-15 18:44:52 --> Helper loaded: url_helper
INFO - 2018-02-15 18:44:52 --> Helper loaded: file_helper
INFO - 2018-02-15 18:44:52 --> Helper loaded: email_helper
INFO - 2018-02-15 18:44:52 --> Helper loaded: common_helper
INFO - 2018-02-15 18:44:52 --> Database Driver Class Initialized
DEBUG - 2018-02-15 18:44:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 18:44:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 18:44:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 18:44:52 --> Pagination Class Initialized
INFO - 2018-02-15 18:44:52 --> Helper loaded: form_helper
INFO - 2018-02-15 18:44:52 --> Form Validation Class Initialized
INFO - 2018-02-15 18:44:52 --> Model Class Initialized
INFO - 2018-02-15 18:44:52 --> Controller Class Initialized
INFO - 2018-02-15 18:44:52 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 18:44:52 --> Model Class Initialized
INFO - 2018-02-15 18:44:52 --> Model Class Initialized
INFO - 2018-02-15 18:44:52 --> Model Class Initialized
INFO - 2018-02-15 18:44:52 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-15 18:44:52 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-15 18:44:52 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-15 18:44:52 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-15 18:44:52 --> File loaded: /var/www/html/project/radio/application/views/tracks/index.php
INFO - 2018-02-15 18:44:52 --> Final output sent to browser
DEBUG - 2018-02-15 18:44:52 --> Total execution time: 0.0102
INFO - 2018-02-15 18:44:52 --> Config Class Initialized
INFO - 2018-02-15 18:44:52 --> Hooks Class Initialized
DEBUG - 2018-02-15 18:44:52 --> UTF-8 Support Enabled
INFO - 2018-02-15 18:44:52 --> Utf8 Class Initialized
INFO - 2018-02-15 18:44:52 --> URI Class Initialized
INFO - 2018-02-15 18:44:52 --> Router Class Initialized
INFO - 2018-02-15 18:44:52 --> Output Class Initialized
INFO - 2018-02-15 18:44:52 --> Security Class Initialized
DEBUG - 2018-02-15 18:44:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 18:44:52 --> Input Class Initialized
INFO - 2018-02-15 18:44:52 --> Language Class Initialized
INFO - 2018-02-15 18:44:52 --> Loader Class Initialized
INFO - 2018-02-15 18:44:52 --> Helper loaded: url_helper
INFO - 2018-02-15 18:44:52 --> Helper loaded: file_helper
INFO - 2018-02-15 18:44:52 --> Helper loaded: email_helper
INFO - 2018-02-15 18:44:52 --> Helper loaded: common_helper
INFO - 2018-02-15 18:44:52 --> Database Driver Class Initialized
DEBUG - 2018-02-15 18:44:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 18:44:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 18:44:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 18:44:52 --> Pagination Class Initialized
INFO - 2018-02-15 18:44:52 --> Helper loaded: form_helper
INFO - 2018-02-15 18:44:52 --> Form Validation Class Initialized
INFO - 2018-02-15 18:44:52 --> Model Class Initialized
INFO - 2018-02-15 18:44:52 --> Controller Class Initialized
INFO - 2018-02-15 18:44:52 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 18:44:52 --> Model Class Initialized
INFO - 2018-02-15 18:44:52 --> Model Class Initialized
INFO - 2018-02-15 18:44:52 --> Model Class Initialized
INFO - 2018-02-15 18:44:53 --> Config Class Initialized
INFO - 2018-02-15 18:44:53 --> Hooks Class Initialized
DEBUG - 2018-02-15 18:44:53 --> UTF-8 Support Enabled
INFO - 2018-02-15 18:44:53 --> Utf8 Class Initialized
INFO - 2018-02-15 18:44:53 --> URI Class Initialized
INFO - 2018-02-15 18:44:53 --> Router Class Initialized
INFO - 2018-02-15 18:44:53 --> Output Class Initialized
INFO - 2018-02-15 18:44:53 --> Security Class Initialized
DEBUG - 2018-02-15 18:44:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 18:44:53 --> Input Class Initialized
INFO - 2018-02-15 18:44:53 --> Language Class Initialized
INFO - 2018-02-15 18:44:53 --> Loader Class Initialized
INFO - 2018-02-15 18:44:53 --> Helper loaded: url_helper
INFO - 2018-02-15 18:44:53 --> Helper loaded: file_helper
INFO - 2018-02-15 18:44:53 --> Helper loaded: email_helper
INFO - 2018-02-15 18:44:53 --> Helper loaded: common_helper
INFO - 2018-02-15 18:44:53 --> Database Driver Class Initialized
DEBUG - 2018-02-15 18:44:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 18:44:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 18:44:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 18:44:53 --> Pagination Class Initialized
INFO - 2018-02-15 18:44:53 --> Helper loaded: form_helper
INFO - 2018-02-15 18:44:53 --> Form Validation Class Initialized
INFO - 2018-02-15 18:44:53 --> Model Class Initialized
INFO - 2018-02-15 18:44:53 --> Controller Class Initialized
INFO - 2018-02-15 18:44:53 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 18:44:53 --> Model Class Initialized
INFO - 2018-02-15 18:44:53 --> Model Class Initialized
INFO - 2018-02-15 18:44:53 --> Model Class Initialized
INFO - 2018-02-15 18:44:53 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-15 18:44:53 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-15 18:44:53 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-15 18:44:53 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-15 18:44:53 --> File loaded: /var/www/html/project/radio/application/views/tracks/add_edit.php
INFO - 2018-02-15 18:44:53 --> Final output sent to browser
DEBUG - 2018-02-15 18:44:53 --> Total execution time: 0.0037
INFO - 2018-02-15 18:44:56 --> Config Class Initialized
INFO - 2018-02-15 18:44:56 --> Hooks Class Initialized
DEBUG - 2018-02-15 18:44:56 --> UTF-8 Support Enabled
INFO - 2018-02-15 18:44:56 --> Utf8 Class Initialized
INFO - 2018-02-15 18:44:56 --> URI Class Initialized
INFO - 2018-02-15 18:44:56 --> Router Class Initialized
INFO - 2018-02-15 18:44:56 --> Output Class Initialized
INFO - 2018-02-15 18:44:56 --> Security Class Initialized
DEBUG - 2018-02-15 18:44:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 18:44:56 --> Input Class Initialized
INFO - 2018-02-15 18:44:56 --> Language Class Initialized
INFO - 2018-02-15 18:44:56 --> Loader Class Initialized
INFO - 2018-02-15 18:44:56 --> Helper loaded: url_helper
INFO - 2018-02-15 18:44:56 --> Helper loaded: file_helper
INFO - 2018-02-15 18:44:56 --> Helper loaded: email_helper
INFO - 2018-02-15 18:44:56 --> Helper loaded: common_helper
INFO - 2018-02-15 18:44:56 --> Database Driver Class Initialized
DEBUG - 2018-02-15 18:44:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 18:44:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 18:44:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 18:44:56 --> Pagination Class Initialized
INFO - 2018-02-15 18:44:56 --> Helper loaded: form_helper
INFO - 2018-02-15 18:44:56 --> Form Validation Class Initialized
INFO - 2018-02-15 18:44:56 --> Model Class Initialized
INFO - 2018-02-15 18:44:56 --> Controller Class Initialized
INFO - 2018-02-15 18:44:56 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 18:44:56 --> Model Class Initialized
INFO - 2018-02-15 18:44:56 --> Model Class Initialized
INFO - 2018-02-15 18:44:56 --> Model Class Initialized
INFO - 2018-02-15 18:45:13 --> Config Class Initialized
INFO - 2018-02-15 18:45:13 --> Hooks Class Initialized
DEBUG - 2018-02-15 18:45:13 --> UTF-8 Support Enabled
INFO - 2018-02-15 18:45:13 --> Utf8 Class Initialized
INFO - 2018-02-15 18:45:13 --> URI Class Initialized
INFO - 2018-02-15 18:45:13 --> Router Class Initialized
INFO - 2018-02-15 18:45:13 --> Output Class Initialized
INFO - 2018-02-15 18:45:13 --> Security Class Initialized
DEBUG - 2018-02-15 18:45:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 18:45:13 --> Input Class Initialized
INFO - 2018-02-15 18:45:13 --> Language Class Initialized
INFO - 2018-02-15 18:45:13 --> Loader Class Initialized
INFO - 2018-02-15 18:45:13 --> Helper loaded: url_helper
INFO - 2018-02-15 18:45:13 --> Helper loaded: file_helper
INFO - 2018-02-15 18:45:13 --> Helper loaded: email_helper
INFO - 2018-02-15 18:45:13 --> Helper loaded: common_helper
INFO - 2018-02-15 18:45:13 --> Database Driver Class Initialized
DEBUG - 2018-02-15 18:45:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 18:45:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 18:45:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 18:45:13 --> Pagination Class Initialized
INFO - 2018-02-15 18:45:13 --> Helper loaded: form_helper
INFO - 2018-02-15 18:45:13 --> Form Validation Class Initialized
INFO - 2018-02-15 18:45:13 --> Model Class Initialized
INFO - 2018-02-15 18:45:13 --> Controller Class Initialized
INFO - 2018-02-15 18:45:13 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 18:45:13 --> Model Class Initialized
INFO - 2018-02-15 18:45:13 --> Model Class Initialized
INFO - 2018-02-15 18:45:13 --> Model Class Initialized
INFO - 2018-02-15 18:45:14 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-15 18:45:14 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-15 18:45:14 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-15 18:45:14 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-15 18:45:14 --> File loaded: /var/www/html/project/radio/application/views/tracks/add_edit.php
INFO - 2018-02-15 18:45:14 --> Final output sent to browser
DEBUG - 2018-02-15 18:45:14 --> Total execution time: 0.0075
INFO - 2018-02-15 18:45:17 --> Config Class Initialized
INFO - 2018-02-15 18:45:17 --> Hooks Class Initialized
DEBUG - 2018-02-15 18:45:17 --> UTF-8 Support Enabled
INFO - 2018-02-15 18:45:17 --> Utf8 Class Initialized
INFO - 2018-02-15 18:45:17 --> URI Class Initialized
INFO - 2018-02-15 18:45:17 --> Router Class Initialized
INFO - 2018-02-15 18:45:17 --> Output Class Initialized
INFO - 2018-02-15 18:45:17 --> Security Class Initialized
DEBUG - 2018-02-15 18:45:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 18:45:17 --> Input Class Initialized
INFO - 2018-02-15 18:45:17 --> Language Class Initialized
INFO - 2018-02-15 18:45:17 --> Loader Class Initialized
INFO - 2018-02-15 18:45:17 --> Helper loaded: url_helper
INFO - 2018-02-15 18:45:17 --> Helper loaded: file_helper
INFO - 2018-02-15 18:45:17 --> Helper loaded: email_helper
INFO - 2018-02-15 18:45:17 --> Helper loaded: common_helper
INFO - 2018-02-15 18:45:17 --> Database Driver Class Initialized
DEBUG - 2018-02-15 18:45:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 18:45:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 18:45:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 18:45:17 --> Pagination Class Initialized
INFO - 2018-02-15 18:45:17 --> Helper loaded: form_helper
INFO - 2018-02-15 18:45:17 --> Form Validation Class Initialized
INFO - 2018-02-15 18:45:17 --> Model Class Initialized
INFO - 2018-02-15 18:45:17 --> Controller Class Initialized
INFO - 2018-02-15 18:45:17 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 18:45:17 --> Model Class Initialized
INFO - 2018-02-15 18:45:17 --> Model Class Initialized
INFO - 2018-02-15 18:45:17 --> Model Class Initialized
INFO - 2018-02-15 18:45:42 --> Config Class Initialized
INFO - 2018-02-15 18:45:42 --> Hooks Class Initialized
DEBUG - 2018-02-15 18:45:42 --> UTF-8 Support Enabled
INFO - 2018-02-15 18:45:42 --> Utf8 Class Initialized
INFO - 2018-02-15 18:45:42 --> URI Class Initialized
INFO - 2018-02-15 18:45:42 --> Router Class Initialized
INFO - 2018-02-15 18:45:42 --> Output Class Initialized
INFO - 2018-02-15 18:45:42 --> Security Class Initialized
DEBUG - 2018-02-15 18:45:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 18:45:42 --> Input Class Initialized
INFO - 2018-02-15 18:45:42 --> Language Class Initialized
INFO - 2018-02-15 18:45:42 --> Loader Class Initialized
INFO - 2018-02-15 18:45:42 --> Helper loaded: url_helper
INFO - 2018-02-15 18:45:42 --> Helper loaded: file_helper
INFO - 2018-02-15 18:45:42 --> Helper loaded: email_helper
INFO - 2018-02-15 18:45:42 --> Helper loaded: common_helper
INFO - 2018-02-15 18:45:42 --> Database Driver Class Initialized
DEBUG - 2018-02-15 18:45:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 18:45:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 18:45:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 18:45:42 --> Pagination Class Initialized
INFO - 2018-02-15 18:45:42 --> Helper loaded: form_helper
INFO - 2018-02-15 18:45:42 --> Form Validation Class Initialized
INFO - 2018-02-15 18:45:42 --> Model Class Initialized
INFO - 2018-02-15 18:45:42 --> Controller Class Initialized
INFO - 2018-02-15 18:45:42 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 18:45:42 --> Model Class Initialized
INFO - 2018-02-15 18:45:42 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-15 18:45:42 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-15 18:45:42 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-15 18:45:42 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-15 18:45:42 --> File loaded: /var/www/html/project/radio/application/views/category/index.php
INFO - 2018-02-15 18:45:42 --> Final output sent to browser
DEBUG - 2018-02-15 18:45:42 --> Total execution time: 0.0063
INFO - 2018-02-15 18:45:49 --> Config Class Initialized
INFO - 2018-02-15 18:45:49 --> Hooks Class Initialized
DEBUG - 2018-02-15 18:45:49 --> UTF-8 Support Enabled
INFO - 2018-02-15 18:45:49 --> Utf8 Class Initialized
INFO - 2018-02-15 18:45:49 --> URI Class Initialized
INFO - 2018-02-15 18:45:49 --> Router Class Initialized
INFO - 2018-02-15 18:45:49 --> Output Class Initialized
INFO - 2018-02-15 18:45:49 --> Security Class Initialized
DEBUG - 2018-02-15 18:45:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 18:45:49 --> Input Class Initialized
INFO - 2018-02-15 18:45:49 --> Language Class Initialized
INFO - 2018-02-15 18:45:49 --> Loader Class Initialized
INFO - 2018-02-15 18:45:49 --> Helper loaded: url_helper
INFO - 2018-02-15 18:45:49 --> Helper loaded: file_helper
INFO - 2018-02-15 18:45:49 --> Helper loaded: email_helper
INFO - 2018-02-15 18:45:49 --> Helper loaded: common_helper
INFO - 2018-02-15 18:45:49 --> Database Driver Class Initialized
DEBUG - 2018-02-15 18:45:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 18:45:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 18:45:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 18:45:49 --> Pagination Class Initialized
INFO - 2018-02-15 18:45:49 --> Helper loaded: form_helper
INFO - 2018-02-15 18:45:49 --> Form Validation Class Initialized
INFO - 2018-02-15 18:45:49 --> Model Class Initialized
INFO - 2018-02-15 18:45:49 --> Controller Class Initialized
INFO - 2018-02-15 18:45:49 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 18:45:49 --> Model Class Initialized
INFO - 2018-02-15 18:45:49 --> Model Class Initialized
INFO - 2018-02-15 18:45:49 --> Model Class Initialized
INFO - 2018-02-15 18:45:49 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-15 18:45:49 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-15 18:45:49 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-15 18:45:49 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-15 18:45:49 --> File loaded: /var/www/html/project/radio/application/views/tracks/index.php
INFO - 2018-02-15 18:45:49 --> Final output sent to browser
DEBUG - 2018-02-15 18:45:49 --> Total execution time: 0.0068
INFO - 2018-02-15 18:45:49 --> Config Class Initialized
INFO - 2018-02-15 18:45:49 --> Hooks Class Initialized
DEBUG - 2018-02-15 18:45:49 --> UTF-8 Support Enabled
INFO - 2018-02-15 18:45:49 --> Utf8 Class Initialized
INFO - 2018-02-15 18:45:49 --> URI Class Initialized
INFO - 2018-02-15 18:45:49 --> Router Class Initialized
INFO - 2018-02-15 18:45:49 --> Output Class Initialized
INFO - 2018-02-15 18:45:49 --> Security Class Initialized
DEBUG - 2018-02-15 18:45:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 18:45:49 --> Input Class Initialized
INFO - 2018-02-15 18:45:49 --> Language Class Initialized
INFO - 2018-02-15 18:45:49 --> Loader Class Initialized
INFO - 2018-02-15 18:45:49 --> Helper loaded: url_helper
INFO - 2018-02-15 18:45:49 --> Helper loaded: file_helper
INFO - 2018-02-15 18:45:49 --> Helper loaded: email_helper
INFO - 2018-02-15 18:45:49 --> Helper loaded: common_helper
INFO - 2018-02-15 18:45:49 --> Database Driver Class Initialized
DEBUG - 2018-02-15 18:45:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 18:45:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 18:45:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 18:45:49 --> Pagination Class Initialized
INFO - 2018-02-15 18:45:49 --> Helper loaded: form_helper
INFO - 2018-02-15 18:45:49 --> Form Validation Class Initialized
INFO - 2018-02-15 18:45:49 --> Model Class Initialized
INFO - 2018-02-15 18:45:49 --> Controller Class Initialized
INFO - 2018-02-15 18:45:49 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 18:45:49 --> Model Class Initialized
INFO - 2018-02-15 18:45:49 --> Model Class Initialized
INFO - 2018-02-15 18:45:49 --> Model Class Initialized
INFO - 2018-02-15 18:46:02 --> Config Class Initialized
INFO - 2018-02-15 18:46:02 --> Hooks Class Initialized
DEBUG - 2018-02-15 18:46:02 --> UTF-8 Support Enabled
INFO - 2018-02-15 18:46:02 --> Utf8 Class Initialized
INFO - 2018-02-15 18:46:02 --> URI Class Initialized
INFO - 2018-02-15 18:46:02 --> Router Class Initialized
INFO - 2018-02-15 18:46:02 --> Output Class Initialized
INFO - 2018-02-15 18:46:02 --> Security Class Initialized
DEBUG - 2018-02-15 18:46:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 18:46:02 --> Input Class Initialized
INFO - 2018-02-15 18:46:02 --> Language Class Initialized
INFO - 2018-02-15 18:46:02 --> Loader Class Initialized
INFO - 2018-02-15 18:46:02 --> Helper loaded: url_helper
INFO - 2018-02-15 18:46:02 --> Helper loaded: file_helper
INFO - 2018-02-15 18:46:02 --> Helper loaded: email_helper
INFO - 2018-02-15 18:46:02 --> Helper loaded: common_helper
INFO - 2018-02-15 18:46:02 --> Database Driver Class Initialized
DEBUG - 2018-02-15 18:46:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 18:46:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 18:46:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 18:46:02 --> Pagination Class Initialized
INFO - 2018-02-15 18:46:02 --> Helper loaded: form_helper
INFO - 2018-02-15 18:46:02 --> Form Validation Class Initialized
INFO - 2018-02-15 18:46:02 --> Model Class Initialized
INFO - 2018-02-15 18:46:02 --> Controller Class Initialized
INFO - 2018-02-15 18:46:02 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 18:46:02 --> Model Class Initialized
INFO - 2018-02-15 18:46:02 --> Model Class Initialized
INFO - 2018-02-15 18:46:02 --> Model Class Initialized
INFO - 2018-02-15 18:46:02 --> Config Class Initialized
INFO - 2018-02-15 18:46:02 --> Hooks Class Initialized
DEBUG - 2018-02-15 18:46:02 --> UTF-8 Support Enabled
INFO - 2018-02-15 18:46:02 --> Utf8 Class Initialized
INFO - 2018-02-15 18:46:02 --> URI Class Initialized
INFO - 2018-02-15 18:46:02 --> Router Class Initialized
INFO - 2018-02-15 18:46:02 --> Output Class Initialized
INFO - 2018-02-15 18:46:02 --> Security Class Initialized
DEBUG - 2018-02-15 18:46:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 18:46:02 --> Input Class Initialized
INFO - 2018-02-15 18:46:02 --> Language Class Initialized
INFO - 2018-02-15 18:46:02 --> Loader Class Initialized
INFO - 2018-02-15 18:46:02 --> Helper loaded: url_helper
INFO - 2018-02-15 18:46:02 --> Helper loaded: file_helper
INFO - 2018-02-15 18:46:02 --> Helper loaded: email_helper
INFO - 2018-02-15 18:46:02 --> Helper loaded: common_helper
INFO - 2018-02-15 18:46:02 --> Database Driver Class Initialized
DEBUG - 2018-02-15 18:46:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 18:46:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 18:46:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 18:46:02 --> Pagination Class Initialized
INFO - 2018-02-15 18:46:02 --> Helper loaded: form_helper
INFO - 2018-02-15 18:46:02 --> Form Validation Class Initialized
INFO - 2018-02-15 18:46:02 --> Model Class Initialized
INFO - 2018-02-15 18:46:02 --> Controller Class Initialized
INFO - 2018-02-15 18:46:02 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 18:46:02 --> Model Class Initialized
INFO - 2018-02-15 18:46:02 --> Model Class Initialized
INFO - 2018-02-15 18:46:02 --> Model Class Initialized
INFO - 2018-02-15 18:46:03 --> Config Class Initialized
INFO - 2018-02-15 18:46:03 --> Hooks Class Initialized
DEBUG - 2018-02-15 18:46:03 --> UTF-8 Support Enabled
INFO - 2018-02-15 18:46:03 --> Utf8 Class Initialized
INFO - 2018-02-15 18:46:03 --> URI Class Initialized
INFO - 2018-02-15 18:46:03 --> Router Class Initialized
INFO - 2018-02-15 18:46:03 --> Output Class Initialized
INFO - 2018-02-15 18:46:03 --> Security Class Initialized
DEBUG - 2018-02-15 18:46:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 18:46:03 --> Input Class Initialized
INFO - 2018-02-15 18:46:03 --> Language Class Initialized
INFO - 2018-02-15 18:46:03 --> Loader Class Initialized
INFO - 2018-02-15 18:46:03 --> Helper loaded: url_helper
INFO - 2018-02-15 18:46:03 --> Helper loaded: file_helper
INFO - 2018-02-15 18:46:03 --> Helper loaded: email_helper
INFO - 2018-02-15 18:46:03 --> Helper loaded: common_helper
INFO - 2018-02-15 18:46:03 --> Database Driver Class Initialized
DEBUG - 2018-02-15 18:46:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 18:46:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 18:46:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 18:46:03 --> Pagination Class Initialized
INFO - 2018-02-15 18:46:03 --> Helper loaded: form_helper
INFO - 2018-02-15 18:46:03 --> Form Validation Class Initialized
INFO - 2018-02-15 18:46:03 --> Model Class Initialized
INFO - 2018-02-15 18:46:03 --> Controller Class Initialized
INFO - 2018-02-15 18:46:03 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 18:46:03 --> Model Class Initialized
INFO - 2018-02-15 18:46:03 --> Model Class Initialized
INFO - 2018-02-15 18:46:03 --> Model Class Initialized
INFO - 2018-02-15 18:46:04 --> Config Class Initialized
INFO - 2018-02-15 18:46:04 --> Hooks Class Initialized
DEBUG - 2018-02-15 18:46:04 --> UTF-8 Support Enabled
INFO - 2018-02-15 18:46:04 --> Utf8 Class Initialized
INFO - 2018-02-15 18:46:04 --> URI Class Initialized
INFO - 2018-02-15 18:46:04 --> Router Class Initialized
INFO - 2018-02-15 18:46:04 --> Output Class Initialized
INFO - 2018-02-15 18:46:04 --> Security Class Initialized
DEBUG - 2018-02-15 18:46:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 18:46:04 --> Input Class Initialized
INFO - 2018-02-15 18:46:04 --> Language Class Initialized
INFO - 2018-02-15 18:46:04 --> Loader Class Initialized
INFO - 2018-02-15 18:46:04 --> Helper loaded: url_helper
INFO - 2018-02-15 18:46:04 --> Helper loaded: file_helper
INFO - 2018-02-15 18:46:04 --> Helper loaded: email_helper
INFO - 2018-02-15 18:46:04 --> Helper loaded: common_helper
INFO - 2018-02-15 18:46:04 --> Database Driver Class Initialized
DEBUG - 2018-02-15 18:46:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 18:46:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 18:46:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 18:46:04 --> Pagination Class Initialized
INFO - 2018-02-15 18:46:04 --> Helper loaded: form_helper
INFO - 2018-02-15 18:46:04 --> Form Validation Class Initialized
INFO - 2018-02-15 18:46:04 --> Model Class Initialized
INFO - 2018-02-15 18:46:04 --> Controller Class Initialized
INFO - 2018-02-15 18:46:04 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 18:46:04 --> Model Class Initialized
INFO - 2018-02-15 18:46:04 --> Model Class Initialized
INFO - 2018-02-15 18:46:04 --> Model Class Initialized
INFO - 2018-02-15 18:46:34 --> Config Class Initialized
INFO - 2018-02-15 18:46:34 --> Hooks Class Initialized
DEBUG - 2018-02-15 18:46:34 --> UTF-8 Support Enabled
INFO - 2018-02-15 18:46:34 --> Utf8 Class Initialized
INFO - 2018-02-15 18:46:34 --> URI Class Initialized
INFO - 2018-02-15 18:46:34 --> Router Class Initialized
INFO - 2018-02-15 18:46:34 --> Output Class Initialized
INFO - 2018-02-15 18:46:34 --> Security Class Initialized
DEBUG - 2018-02-15 18:46:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 18:46:34 --> Input Class Initialized
INFO - 2018-02-15 18:46:34 --> Language Class Initialized
INFO - 2018-02-15 18:46:34 --> Loader Class Initialized
INFO - 2018-02-15 18:46:34 --> Helper loaded: url_helper
INFO - 2018-02-15 18:46:34 --> Helper loaded: file_helper
INFO - 2018-02-15 18:46:34 --> Helper loaded: email_helper
INFO - 2018-02-15 18:46:34 --> Helper loaded: common_helper
INFO - 2018-02-15 18:46:34 --> Database Driver Class Initialized
DEBUG - 2018-02-15 18:46:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 18:46:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 18:46:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 18:46:34 --> Pagination Class Initialized
INFO - 2018-02-15 18:46:34 --> Helper loaded: form_helper
INFO - 2018-02-15 18:46:34 --> Form Validation Class Initialized
INFO - 2018-02-15 18:46:34 --> Model Class Initialized
INFO - 2018-02-15 18:46:34 --> Controller Class Initialized
INFO - 2018-02-15 18:46:34 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 18:46:34 --> Model Class Initialized
INFO - 2018-02-15 18:46:34 --> Model Class Initialized
INFO - 2018-02-15 18:46:34 --> Model Class Initialized
INFO - 2018-02-15 18:46:34 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-15 18:46:34 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-15 18:46:34 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-15 18:46:34 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-15 18:46:34 --> File loaded: /var/www/html/project/radio/application/views/tracks/add_edit.php
INFO - 2018-02-15 18:46:34 --> Final output sent to browser
DEBUG - 2018-02-15 18:46:34 --> Total execution time: 0.0070
INFO - 2018-02-15 18:47:15 --> Config Class Initialized
INFO - 2018-02-15 18:47:15 --> Hooks Class Initialized
DEBUG - 2018-02-15 18:47:15 --> UTF-8 Support Enabled
INFO - 2018-02-15 18:47:15 --> Utf8 Class Initialized
INFO - 2018-02-15 18:47:15 --> URI Class Initialized
INFO - 2018-02-15 18:47:15 --> Router Class Initialized
INFO - 2018-02-15 18:47:15 --> Output Class Initialized
INFO - 2018-02-15 18:47:15 --> Security Class Initialized
DEBUG - 2018-02-15 18:47:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 18:47:15 --> Input Class Initialized
INFO - 2018-02-15 18:47:15 --> Language Class Initialized
INFO - 2018-02-15 18:47:15 --> Loader Class Initialized
INFO - 2018-02-15 18:47:15 --> Helper loaded: url_helper
INFO - 2018-02-15 18:47:15 --> Helper loaded: file_helper
INFO - 2018-02-15 18:47:15 --> Helper loaded: email_helper
INFO - 2018-02-15 18:47:15 --> Helper loaded: common_helper
INFO - 2018-02-15 18:47:15 --> Database Driver Class Initialized
DEBUG - 2018-02-15 18:47:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 18:47:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 18:47:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 18:47:15 --> Pagination Class Initialized
INFO - 2018-02-15 18:47:15 --> Helper loaded: form_helper
INFO - 2018-02-15 18:47:15 --> Form Validation Class Initialized
INFO - 2018-02-15 18:47:15 --> Model Class Initialized
INFO - 2018-02-15 18:47:15 --> Controller Class Initialized
INFO - 2018-02-15 18:47:15 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 18:47:15 --> Model Class Initialized
INFO - 2018-02-15 18:47:15 --> Model Class Initialized
INFO - 2018-02-15 18:47:15 --> Model Class Initialized
INFO - 2018-02-15 18:47:15 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-15 18:47:15 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-15 18:47:15 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-15 18:47:15 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-15 18:47:15 --> File loaded: /var/www/html/project/radio/application/views/tracks/add_edit.php
INFO - 2018-02-15 18:47:15 --> Final output sent to browser
DEBUG - 2018-02-15 18:47:15 --> Total execution time: 0.0066
INFO - 2018-02-15 18:47:28 --> Config Class Initialized
INFO - 2018-02-15 18:47:28 --> Hooks Class Initialized
DEBUG - 2018-02-15 18:47:28 --> UTF-8 Support Enabled
INFO - 2018-02-15 18:47:28 --> Utf8 Class Initialized
INFO - 2018-02-15 18:47:28 --> URI Class Initialized
INFO - 2018-02-15 18:47:28 --> Router Class Initialized
INFO - 2018-02-15 18:47:28 --> Output Class Initialized
INFO - 2018-02-15 18:47:28 --> Security Class Initialized
DEBUG - 2018-02-15 18:47:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 18:47:28 --> Input Class Initialized
INFO - 2018-02-15 18:47:28 --> Language Class Initialized
INFO - 2018-02-15 18:47:28 --> Loader Class Initialized
INFO - 2018-02-15 18:47:28 --> Helper loaded: url_helper
INFO - 2018-02-15 18:47:28 --> Helper loaded: file_helper
INFO - 2018-02-15 18:47:28 --> Helper loaded: email_helper
INFO - 2018-02-15 18:47:28 --> Helper loaded: common_helper
INFO - 2018-02-15 18:47:28 --> Database Driver Class Initialized
DEBUG - 2018-02-15 18:47:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 18:47:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 18:47:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 18:47:28 --> Pagination Class Initialized
INFO - 2018-02-15 18:47:28 --> Helper loaded: form_helper
INFO - 2018-02-15 18:47:28 --> Form Validation Class Initialized
INFO - 2018-02-15 18:47:28 --> Model Class Initialized
INFO - 2018-02-15 18:47:28 --> Controller Class Initialized
INFO - 2018-02-15 18:47:28 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 18:47:28 --> Model Class Initialized
INFO - 2018-02-15 18:47:28 --> Model Class Initialized
INFO - 2018-02-15 18:47:28 --> Model Class Initialized
INFO - 2018-02-15 18:47:51 --> Config Class Initialized
INFO - 2018-02-15 18:47:51 --> Hooks Class Initialized
DEBUG - 2018-02-15 18:47:51 --> UTF-8 Support Enabled
INFO - 2018-02-15 18:47:51 --> Utf8 Class Initialized
INFO - 2018-02-15 18:47:51 --> URI Class Initialized
INFO - 2018-02-15 18:47:51 --> Router Class Initialized
INFO - 2018-02-15 18:47:51 --> Output Class Initialized
INFO - 2018-02-15 18:47:51 --> Security Class Initialized
DEBUG - 2018-02-15 18:47:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 18:47:51 --> Input Class Initialized
INFO - 2018-02-15 18:47:51 --> Language Class Initialized
INFO - 2018-02-15 18:47:51 --> Loader Class Initialized
INFO - 2018-02-15 18:47:51 --> Helper loaded: url_helper
INFO - 2018-02-15 18:47:51 --> Helper loaded: file_helper
INFO - 2018-02-15 18:47:51 --> Helper loaded: email_helper
INFO - 2018-02-15 18:47:51 --> Helper loaded: common_helper
INFO - 2018-02-15 18:47:51 --> Database Driver Class Initialized
DEBUG - 2018-02-15 18:47:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 18:47:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 18:47:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 18:47:51 --> Pagination Class Initialized
INFO - 2018-02-15 18:47:51 --> Helper loaded: form_helper
INFO - 2018-02-15 18:47:51 --> Form Validation Class Initialized
INFO - 2018-02-15 18:47:51 --> Model Class Initialized
INFO - 2018-02-15 18:47:51 --> Controller Class Initialized
INFO - 2018-02-15 18:47:51 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 18:47:51 --> Model Class Initialized
INFO - 2018-02-15 18:47:51 --> Model Class Initialized
INFO - 2018-02-15 18:47:51 --> Model Class Initialized
INFO - 2018-02-15 18:47:51 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-15 18:47:51 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-15 18:47:51 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-15 18:47:51 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-15 18:47:51 --> File loaded: /var/www/html/project/radio/application/views/tracks/add_edit.php
INFO - 2018-02-15 18:47:51 --> Final output sent to browser
DEBUG - 2018-02-15 18:47:51 --> Total execution time: 0.0057
INFO - 2018-02-15 18:47:58 --> Config Class Initialized
INFO - 2018-02-15 18:47:58 --> Hooks Class Initialized
DEBUG - 2018-02-15 18:47:58 --> UTF-8 Support Enabled
INFO - 2018-02-15 18:47:58 --> Utf8 Class Initialized
INFO - 2018-02-15 18:47:58 --> URI Class Initialized
INFO - 2018-02-15 18:47:58 --> Router Class Initialized
INFO - 2018-02-15 18:47:58 --> Output Class Initialized
INFO - 2018-02-15 18:47:58 --> Security Class Initialized
DEBUG - 2018-02-15 18:47:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 18:47:58 --> Input Class Initialized
INFO - 2018-02-15 18:47:58 --> Language Class Initialized
INFO - 2018-02-15 18:47:58 --> Loader Class Initialized
INFO - 2018-02-15 18:47:58 --> Helper loaded: url_helper
INFO - 2018-02-15 18:47:58 --> Helper loaded: file_helper
INFO - 2018-02-15 18:47:58 --> Helper loaded: email_helper
INFO - 2018-02-15 18:47:58 --> Helper loaded: common_helper
INFO - 2018-02-15 18:47:58 --> Database Driver Class Initialized
DEBUG - 2018-02-15 18:47:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 18:47:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 18:47:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 18:47:58 --> Pagination Class Initialized
INFO - 2018-02-15 18:47:58 --> Helper loaded: form_helper
INFO - 2018-02-15 18:47:58 --> Form Validation Class Initialized
INFO - 2018-02-15 18:47:58 --> Model Class Initialized
INFO - 2018-02-15 18:47:58 --> Controller Class Initialized
INFO - 2018-02-15 18:47:58 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 18:47:58 --> Model Class Initialized
INFO - 2018-02-15 18:47:58 --> Model Class Initialized
INFO - 2018-02-15 18:47:58 --> Model Class Initialized
INFO - 2018-02-15 18:48:10 --> Config Class Initialized
INFO - 2018-02-15 18:48:10 --> Hooks Class Initialized
DEBUG - 2018-02-15 18:48:10 --> UTF-8 Support Enabled
INFO - 2018-02-15 18:48:10 --> Utf8 Class Initialized
INFO - 2018-02-15 18:48:10 --> URI Class Initialized
INFO - 2018-02-15 18:48:10 --> Router Class Initialized
INFO - 2018-02-15 18:48:10 --> Output Class Initialized
INFO - 2018-02-15 18:48:10 --> Security Class Initialized
DEBUG - 2018-02-15 18:48:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 18:48:10 --> Input Class Initialized
INFO - 2018-02-15 18:48:10 --> Language Class Initialized
INFO - 2018-02-15 18:48:10 --> Loader Class Initialized
INFO - 2018-02-15 18:48:10 --> Helper loaded: url_helper
INFO - 2018-02-15 18:48:10 --> Helper loaded: file_helper
INFO - 2018-02-15 18:48:10 --> Helper loaded: email_helper
INFO - 2018-02-15 18:48:10 --> Helper loaded: common_helper
INFO - 2018-02-15 18:48:10 --> Database Driver Class Initialized
DEBUG - 2018-02-15 18:48:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 18:48:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 18:48:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 18:48:10 --> Pagination Class Initialized
INFO - 2018-02-15 18:48:10 --> Helper loaded: form_helper
INFO - 2018-02-15 18:48:10 --> Form Validation Class Initialized
INFO - 2018-02-15 18:48:10 --> Model Class Initialized
INFO - 2018-02-15 18:48:10 --> Controller Class Initialized
INFO - 2018-02-15 18:48:10 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 18:48:10 --> Model Class Initialized
INFO - 2018-02-15 18:48:10 --> Model Class Initialized
INFO - 2018-02-15 18:48:10 --> Model Class Initialized
INFO - 2018-02-15 18:48:10 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-15 18:48:10 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-15 18:48:10 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-15 18:48:10 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-15 18:48:10 --> File loaded: /var/www/html/project/radio/application/views/tracks/add_edit.php
INFO - 2018-02-15 18:48:10 --> Final output sent to browser
DEBUG - 2018-02-15 18:48:10 --> Total execution time: 0.0057
INFO - 2018-02-15 18:53:59 --> Config Class Initialized
INFO - 2018-02-15 18:53:59 --> Hooks Class Initialized
DEBUG - 2018-02-15 18:53:59 --> UTF-8 Support Enabled
INFO - 2018-02-15 18:53:59 --> Utf8 Class Initialized
INFO - 2018-02-15 18:53:59 --> URI Class Initialized
INFO - 2018-02-15 18:53:59 --> Router Class Initialized
INFO - 2018-02-15 18:53:59 --> Output Class Initialized
INFO - 2018-02-15 18:53:59 --> Security Class Initialized
DEBUG - 2018-02-15 18:53:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 18:53:59 --> Input Class Initialized
INFO - 2018-02-15 18:53:59 --> Language Class Initialized
INFO - 2018-02-15 18:53:59 --> Loader Class Initialized
INFO - 2018-02-15 18:53:59 --> Helper loaded: url_helper
INFO - 2018-02-15 18:53:59 --> Helper loaded: file_helper
INFO - 2018-02-15 18:53:59 --> Helper loaded: email_helper
INFO - 2018-02-15 18:53:59 --> Helper loaded: common_helper
INFO - 2018-02-15 18:53:59 --> Database Driver Class Initialized
DEBUG - 2018-02-15 18:53:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 18:53:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 18:53:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 18:53:59 --> Pagination Class Initialized
INFO - 2018-02-15 18:53:59 --> Helper loaded: form_helper
INFO - 2018-02-15 18:53:59 --> Form Validation Class Initialized
INFO - 2018-02-15 18:53:59 --> Model Class Initialized
INFO - 2018-02-15 18:53:59 --> Controller Class Initialized
INFO - 2018-02-15 18:53:59 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 18:53:59 --> Model Class Initialized
INFO - 2018-02-15 18:53:59 --> Model Class Initialized
INFO - 2018-02-15 18:53:59 --> Model Class Initialized
INFO - 2018-02-15 18:53:59 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-15 18:53:59 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-15 18:53:59 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-15 18:53:59 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-15 18:53:59 --> File loaded: /var/www/html/project/radio/application/views/tracks/add_edit.php
INFO - 2018-02-15 18:53:59 --> Final output sent to browser
DEBUG - 2018-02-15 18:53:59 --> Total execution time: 0.0065
INFO - 2018-02-15 18:54:06 --> Config Class Initialized
INFO - 2018-02-15 18:54:06 --> Hooks Class Initialized
DEBUG - 2018-02-15 18:54:06 --> UTF-8 Support Enabled
INFO - 2018-02-15 18:54:06 --> Utf8 Class Initialized
INFO - 2018-02-15 18:54:06 --> URI Class Initialized
INFO - 2018-02-15 18:54:06 --> Router Class Initialized
INFO - 2018-02-15 18:54:06 --> Output Class Initialized
INFO - 2018-02-15 18:54:06 --> Security Class Initialized
DEBUG - 2018-02-15 18:54:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 18:54:06 --> Input Class Initialized
INFO - 2018-02-15 18:54:06 --> Language Class Initialized
INFO - 2018-02-15 18:54:06 --> Loader Class Initialized
INFO - 2018-02-15 18:54:06 --> Helper loaded: url_helper
INFO - 2018-02-15 18:54:06 --> Helper loaded: file_helper
INFO - 2018-02-15 18:54:06 --> Helper loaded: email_helper
INFO - 2018-02-15 18:54:06 --> Helper loaded: common_helper
INFO - 2018-02-15 18:54:06 --> Database Driver Class Initialized
DEBUG - 2018-02-15 18:54:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 18:54:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 18:54:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 18:54:06 --> Pagination Class Initialized
INFO - 2018-02-15 18:54:06 --> Helper loaded: form_helper
INFO - 2018-02-15 18:54:06 --> Form Validation Class Initialized
INFO - 2018-02-15 18:54:06 --> Model Class Initialized
INFO - 2018-02-15 18:54:06 --> Controller Class Initialized
INFO - 2018-02-15 18:54:06 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 18:54:06 --> Model Class Initialized
INFO - 2018-02-15 18:54:06 --> Model Class Initialized
INFO - 2018-02-15 18:54:06 --> Model Class Initialized
INFO - 2018-02-15 18:54:16 --> Config Class Initialized
INFO - 2018-02-15 18:54:16 --> Hooks Class Initialized
DEBUG - 2018-02-15 18:54:16 --> UTF-8 Support Enabled
INFO - 2018-02-15 18:54:16 --> Utf8 Class Initialized
INFO - 2018-02-15 18:54:16 --> URI Class Initialized
INFO - 2018-02-15 18:54:16 --> Router Class Initialized
INFO - 2018-02-15 18:54:16 --> Output Class Initialized
INFO - 2018-02-15 18:54:16 --> Security Class Initialized
DEBUG - 2018-02-15 18:54:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 18:54:16 --> Input Class Initialized
INFO - 2018-02-15 18:54:16 --> Language Class Initialized
INFO - 2018-02-15 18:54:16 --> Loader Class Initialized
INFO - 2018-02-15 18:54:16 --> Helper loaded: url_helper
INFO - 2018-02-15 18:54:16 --> Helper loaded: file_helper
INFO - 2018-02-15 18:54:16 --> Helper loaded: email_helper
INFO - 2018-02-15 18:54:16 --> Helper loaded: common_helper
INFO - 2018-02-15 18:54:16 --> Database Driver Class Initialized
DEBUG - 2018-02-15 18:54:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 18:54:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 18:54:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 18:54:16 --> Pagination Class Initialized
INFO - 2018-02-15 18:54:16 --> Helper loaded: form_helper
INFO - 2018-02-15 18:54:16 --> Form Validation Class Initialized
INFO - 2018-02-15 18:54:16 --> Model Class Initialized
INFO - 2018-02-15 18:54:16 --> Controller Class Initialized
INFO - 2018-02-15 18:54:16 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 18:54:16 --> Model Class Initialized
INFO - 2018-02-15 18:54:16 --> Model Class Initialized
INFO - 2018-02-15 18:54:16 --> Model Class Initialized
INFO - 2018-02-15 18:54:16 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-15 18:54:16 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-15 18:54:16 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-15 18:54:16 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-15 18:54:16 --> File loaded: /var/www/html/project/radio/application/views/tracks/add_edit.php
INFO - 2018-02-15 18:54:16 --> Final output sent to browser
DEBUG - 2018-02-15 18:54:16 --> Total execution time: 0.0069
INFO - 2018-02-15 18:54:26 --> Config Class Initialized
INFO - 2018-02-15 18:54:26 --> Hooks Class Initialized
DEBUG - 2018-02-15 18:54:26 --> UTF-8 Support Enabled
INFO - 2018-02-15 18:54:26 --> Utf8 Class Initialized
INFO - 2018-02-15 18:54:26 --> URI Class Initialized
INFO - 2018-02-15 18:54:26 --> Router Class Initialized
INFO - 2018-02-15 18:54:26 --> Output Class Initialized
INFO - 2018-02-15 18:54:26 --> Security Class Initialized
DEBUG - 2018-02-15 18:54:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 18:54:26 --> Input Class Initialized
INFO - 2018-02-15 18:54:26 --> Language Class Initialized
INFO - 2018-02-15 18:54:26 --> Loader Class Initialized
INFO - 2018-02-15 18:54:26 --> Helper loaded: url_helper
INFO - 2018-02-15 18:54:26 --> Helper loaded: file_helper
INFO - 2018-02-15 18:54:26 --> Helper loaded: email_helper
INFO - 2018-02-15 18:54:26 --> Helper loaded: common_helper
INFO - 2018-02-15 18:54:26 --> Database Driver Class Initialized
DEBUG - 2018-02-15 18:54:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 18:54:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 18:54:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 18:54:26 --> Pagination Class Initialized
INFO - 2018-02-15 18:54:26 --> Helper loaded: form_helper
INFO - 2018-02-15 18:54:26 --> Form Validation Class Initialized
INFO - 2018-02-15 18:54:26 --> Model Class Initialized
INFO - 2018-02-15 18:54:26 --> Controller Class Initialized
INFO - 2018-02-15 18:54:26 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 18:54:26 --> Model Class Initialized
INFO - 2018-02-15 18:54:26 --> Model Class Initialized
INFO - 2018-02-15 18:54:26 --> Model Class Initialized
INFO - 2018-02-15 18:54:31 --> Config Class Initialized
INFO - 2018-02-15 18:54:31 --> Hooks Class Initialized
DEBUG - 2018-02-15 18:54:31 --> UTF-8 Support Enabled
INFO - 2018-02-15 18:54:31 --> Utf8 Class Initialized
INFO - 2018-02-15 18:54:31 --> URI Class Initialized
INFO - 2018-02-15 18:54:31 --> Router Class Initialized
INFO - 2018-02-15 18:54:31 --> Output Class Initialized
INFO - 2018-02-15 18:54:31 --> Security Class Initialized
DEBUG - 2018-02-15 18:54:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 18:54:31 --> Input Class Initialized
INFO - 2018-02-15 18:54:31 --> Language Class Initialized
INFO - 2018-02-15 18:54:31 --> Loader Class Initialized
INFO - 2018-02-15 18:54:31 --> Helper loaded: url_helper
INFO - 2018-02-15 18:54:31 --> Helper loaded: file_helper
INFO - 2018-02-15 18:54:31 --> Helper loaded: email_helper
INFO - 2018-02-15 18:54:31 --> Helper loaded: common_helper
INFO - 2018-02-15 18:54:31 --> Database Driver Class Initialized
DEBUG - 2018-02-15 18:54:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 18:54:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 18:54:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 18:54:31 --> Pagination Class Initialized
INFO - 2018-02-15 18:54:31 --> Helper loaded: form_helper
INFO - 2018-02-15 18:54:31 --> Form Validation Class Initialized
INFO - 2018-02-15 18:54:31 --> Model Class Initialized
INFO - 2018-02-15 18:54:31 --> Controller Class Initialized
INFO - 2018-02-15 18:54:31 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 18:54:31 --> Model Class Initialized
INFO - 2018-02-15 18:54:31 --> Model Class Initialized
INFO - 2018-02-15 18:54:31 --> Model Class Initialized
INFO - 2018-02-15 18:54:42 --> Config Class Initialized
INFO - 2018-02-15 18:54:42 --> Hooks Class Initialized
DEBUG - 2018-02-15 18:54:42 --> UTF-8 Support Enabled
INFO - 2018-02-15 18:54:42 --> Utf8 Class Initialized
INFO - 2018-02-15 18:54:42 --> URI Class Initialized
INFO - 2018-02-15 18:54:42 --> Router Class Initialized
INFO - 2018-02-15 18:54:42 --> Output Class Initialized
INFO - 2018-02-15 18:54:42 --> Security Class Initialized
DEBUG - 2018-02-15 18:54:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 18:54:42 --> Input Class Initialized
INFO - 2018-02-15 18:54:42 --> Language Class Initialized
INFO - 2018-02-15 18:54:42 --> Loader Class Initialized
INFO - 2018-02-15 18:54:42 --> Helper loaded: url_helper
INFO - 2018-02-15 18:54:42 --> Helper loaded: file_helper
INFO - 2018-02-15 18:54:42 --> Helper loaded: email_helper
INFO - 2018-02-15 18:54:42 --> Helper loaded: common_helper
INFO - 2018-02-15 18:54:42 --> Database Driver Class Initialized
DEBUG - 2018-02-15 18:54:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 18:54:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 18:54:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 18:54:42 --> Pagination Class Initialized
INFO - 2018-02-15 18:54:42 --> Helper loaded: form_helper
INFO - 2018-02-15 18:54:42 --> Form Validation Class Initialized
INFO - 2018-02-15 18:54:42 --> Model Class Initialized
INFO - 2018-02-15 18:54:42 --> Controller Class Initialized
INFO - 2018-02-15 18:54:42 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 18:54:42 --> Model Class Initialized
INFO - 2018-02-15 18:54:42 --> Model Class Initialized
INFO - 2018-02-15 18:54:42 --> Model Class Initialized
INFO - 2018-02-15 18:54:46 --> Config Class Initialized
INFO - 2018-02-15 18:54:46 --> Hooks Class Initialized
DEBUG - 2018-02-15 18:54:46 --> UTF-8 Support Enabled
INFO - 2018-02-15 18:54:46 --> Utf8 Class Initialized
INFO - 2018-02-15 18:54:46 --> URI Class Initialized
INFO - 2018-02-15 18:54:46 --> Router Class Initialized
INFO - 2018-02-15 18:54:46 --> Output Class Initialized
INFO - 2018-02-15 18:54:46 --> Security Class Initialized
DEBUG - 2018-02-15 18:54:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 18:54:46 --> Input Class Initialized
INFO - 2018-02-15 18:54:46 --> Language Class Initialized
INFO - 2018-02-15 18:54:46 --> Loader Class Initialized
INFO - 2018-02-15 18:54:46 --> Helper loaded: url_helper
INFO - 2018-02-15 18:54:46 --> Helper loaded: file_helper
INFO - 2018-02-15 18:54:46 --> Helper loaded: email_helper
INFO - 2018-02-15 18:54:46 --> Helper loaded: common_helper
INFO - 2018-02-15 18:54:46 --> Database Driver Class Initialized
DEBUG - 2018-02-15 18:54:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 18:54:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 18:54:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 18:54:46 --> Pagination Class Initialized
INFO - 2018-02-15 18:54:46 --> Helper loaded: form_helper
INFO - 2018-02-15 18:54:46 --> Form Validation Class Initialized
INFO - 2018-02-15 18:54:46 --> Model Class Initialized
INFO - 2018-02-15 18:54:46 --> Controller Class Initialized
INFO - 2018-02-15 18:54:46 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 18:54:46 --> Model Class Initialized
INFO - 2018-02-15 18:54:46 --> Model Class Initialized
INFO - 2018-02-15 18:54:46 --> Model Class Initialized
INFO - 2018-02-15 18:55:20 --> Config Class Initialized
INFO - 2018-02-15 18:55:20 --> Hooks Class Initialized
DEBUG - 2018-02-15 18:55:20 --> UTF-8 Support Enabled
INFO - 2018-02-15 18:55:20 --> Utf8 Class Initialized
INFO - 2018-02-15 18:55:20 --> URI Class Initialized
INFO - 2018-02-15 18:55:20 --> Router Class Initialized
INFO - 2018-02-15 18:55:20 --> Output Class Initialized
INFO - 2018-02-15 18:55:20 --> Security Class Initialized
DEBUG - 2018-02-15 18:55:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 18:55:20 --> Input Class Initialized
INFO - 2018-02-15 18:55:20 --> Language Class Initialized
INFO - 2018-02-15 18:55:20 --> Loader Class Initialized
INFO - 2018-02-15 18:55:20 --> Helper loaded: url_helper
INFO - 2018-02-15 18:55:20 --> Helper loaded: file_helper
INFO - 2018-02-15 18:55:20 --> Helper loaded: email_helper
INFO - 2018-02-15 18:55:20 --> Helper loaded: common_helper
INFO - 2018-02-15 18:55:20 --> Database Driver Class Initialized
DEBUG - 2018-02-15 18:55:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 18:55:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 18:55:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 18:55:20 --> Pagination Class Initialized
INFO - 2018-02-15 18:55:20 --> Helper loaded: form_helper
INFO - 2018-02-15 18:55:20 --> Form Validation Class Initialized
INFO - 2018-02-15 18:55:20 --> Model Class Initialized
INFO - 2018-02-15 18:55:20 --> Controller Class Initialized
INFO - 2018-02-15 18:55:20 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 18:55:20 --> Model Class Initialized
INFO - 2018-02-15 18:55:20 --> Model Class Initialized
INFO - 2018-02-15 18:55:20 --> Model Class Initialized
INFO - 2018-02-15 18:55:20 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-15 18:55:20 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-15 18:55:20 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-15 18:55:20 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-15 18:55:20 --> File loaded: /var/www/html/project/radio/application/views/tracks/add_edit.php
INFO - 2018-02-15 18:55:20 --> Final output sent to browser
DEBUG - 2018-02-15 18:55:20 --> Total execution time: 0.0070
INFO - 2018-02-15 18:56:14 --> Config Class Initialized
INFO - 2018-02-15 18:56:14 --> Hooks Class Initialized
DEBUG - 2018-02-15 18:56:14 --> UTF-8 Support Enabled
INFO - 2018-02-15 18:56:14 --> Utf8 Class Initialized
INFO - 2018-02-15 18:56:14 --> URI Class Initialized
INFO - 2018-02-15 18:56:14 --> Router Class Initialized
INFO - 2018-02-15 18:56:14 --> Output Class Initialized
INFO - 2018-02-15 18:56:14 --> Security Class Initialized
DEBUG - 2018-02-15 18:56:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 18:56:14 --> Input Class Initialized
INFO - 2018-02-15 18:56:14 --> Language Class Initialized
INFO - 2018-02-15 18:56:14 --> Loader Class Initialized
INFO - 2018-02-15 18:56:14 --> Helper loaded: url_helper
INFO - 2018-02-15 18:56:14 --> Helper loaded: file_helper
INFO - 2018-02-15 18:56:14 --> Helper loaded: email_helper
INFO - 2018-02-15 18:56:14 --> Helper loaded: common_helper
INFO - 2018-02-15 18:56:14 --> Database Driver Class Initialized
DEBUG - 2018-02-15 18:56:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-15 18:56:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 18:56:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 18:56:14 --> Pagination Class Initialized
INFO - 2018-02-15 18:56:14 --> Helper loaded: form_helper
INFO - 2018-02-15 18:56:14 --> Form Validation Class Initialized
INFO - 2018-02-15 18:56:14 --> Model Class Initialized
INFO - 2018-02-15 18:56:14 --> Controller Class Initialized
INFO - 2018-02-15 18:56:14 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-15 18:56:14 --> Model Class Initialized
INFO - 2018-02-15 18:56:14 --> Model Class Initialized
INFO - 2018-02-15 18:56:14 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-15 18:56:14 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-15 18:56:14 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-15 18:56:14 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-15 18:56:14 --> File loaded: /var/www/html/project/radio/application/views/subcategory/index.php
INFO - 2018-02-15 18:56:14 --> Final output sent to browser
DEBUG - 2018-02-15 18:56:14 --> Total execution time: 0.0073

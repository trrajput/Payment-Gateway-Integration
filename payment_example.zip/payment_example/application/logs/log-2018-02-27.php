<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2018-02-27 10:16:53 --> Config Class Initialized
INFO - 2018-02-27 10:16:53 --> Hooks Class Initialized
DEBUG - 2018-02-27 10:16:53 --> UTF-8 Support Enabled
INFO - 2018-02-27 10:16:53 --> Utf8 Class Initialized
INFO - 2018-02-27 10:16:53 --> URI Class Initialized
INFO - 2018-02-27 10:16:53 --> Router Class Initialized
INFO - 2018-02-27 10:16:53 --> Output Class Initialized
INFO - 2018-02-27 10:16:53 --> Security Class Initialized
DEBUG - 2018-02-27 10:16:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-27 10:16:53 --> Input Class Initialized
INFO - 2018-02-27 10:16:53 --> Language Class Initialized
INFO - 2018-02-27 10:16:53 --> Loader Class Initialized
INFO - 2018-02-27 10:16:53 --> Helper loaded: url_helper
INFO - 2018-02-27 10:16:53 --> Helper loaded: file_helper
INFO - 2018-02-27 10:16:53 --> Helper loaded: email_helper
INFO - 2018-02-27 10:16:53 --> Helper loaded: common_helper
INFO - 2018-02-27 10:16:53 --> Database Driver Class Initialized
DEBUG - 2018-02-27 10:16:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-27 10:16:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-27 10:16:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-27 10:16:53 --> Pagination Class Initialized
INFO - 2018-02-27 10:16:53 --> Helper loaded: form_helper
INFO - 2018-02-27 10:16:53 --> Form Validation Class Initialized
INFO - 2018-02-27 10:16:53 --> Model Class Initialized
INFO - 2018-02-27 10:16:53 --> Controller Class Initialized
INFO - 2018-02-27 10:16:53 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-27 10:16:53 --> Config Class Initialized
INFO - 2018-02-27 10:16:53 --> Hooks Class Initialized
DEBUG - 2018-02-27 10:16:53 --> UTF-8 Support Enabled
INFO - 2018-02-27 10:16:53 --> Utf8 Class Initialized
INFO - 2018-02-27 10:16:53 --> URI Class Initialized
DEBUG - 2018-02-27 10:16:53 --> No URI present. Default controller set.
INFO - 2018-02-27 10:16:53 --> Router Class Initialized
INFO - 2018-02-27 10:16:53 --> Output Class Initialized
INFO - 2018-02-27 10:16:53 --> Security Class Initialized
DEBUG - 2018-02-27 10:16:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-27 10:16:53 --> Input Class Initialized
INFO - 2018-02-27 10:16:53 --> Language Class Initialized
INFO - 2018-02-27 10:16:53 --> Loader Class Initialized
INFO - 2018-02-27 10:16:53 --> Helper loaded: url_helper
INFO - 2018-02-27 10:16:53 --> Helper loaded: file_helper
INFO - 2018-02-27 10:16:53 --> Helper loaded: email_helper
INFO - 2018-02-27 10:16:53 --> Helper loaded: common_helper
INFO - 2018-02-27 10:16:53 --> Database Driver Class Initialized
DEBUG - 2018-02-27 10:16:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-27 10:16:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-27 10:16:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-27 10:16:53 --> Pagination Class Initialized
INFO - 2018-02-27 10:16:53 --> Helper loaded: form_helper
INFO - 2018-02-27 10:16:53 --> Form Validation Class Initialized
INFO - 2018-02-27 10:16:53 --> Model Class Initialized
INFO - 2018-02-27 10:16:53 --> Controller Class Initialized
INFO - 2018-02-27 10:16:53 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-27 10:16:53 --> Model Class Initialized
INFO - 2018-02-27 10:16:53 --> Model Class Initialized
INFO - 2018-02-27 10:16:53 --> File loaded: /var/www/html/project/radio/application/views/index/index.php
INFO - 2018-02-27 10:16:53 --> Final output sent to browser
DEBUG - 2018-02-27 10:16:53 --> Total execution time: 0.0377
INFO - 2018-02-27 10:16:55 --> Config Class Initialized
INFO - 2018-02-27 10:16:55 --> Hooks Class Initialized
DEBUG - 2018-02-27 10:16:55 --> UTF-8 Support Enabled
INFO - 2018-02-27 10:16:55 --> Utf8 Class Initialized
INFO - 2018-02-27 10:16:55 --> URI Class Initialized
INFO - 2018-02-27 10:16:55 --> Router Class Initialized
INFO - 2018-02-27 10:16:55 --> Output Class Initialized
INFO - 2018-02-27 10:16:55 --> Security Class Initialized
DEBUG - 2018-02-27 10:16:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-27 10:16:55 --> Input Class Initialized
INFO - 2018-02-27 10:16:55 --> Language Class Initialized
INFO - 2018-02-27 10:16:55 --> Loader Class Initialized
INFO - 2018-02-27 10:16:55 --> Helper loaded: url_helper
INFO - 2018-02-27 10:16:55 --> Helper loaded: file_helper
INFO - 2018-02-27 10:16:55 --> Helper loaded: email_helper
INFO - 2018-02-27 10:16:55 --> Helper loaded: common_helper
INFO - 2018-02-27 10:16:55 --> Database Driver Class Initialized
DEBUG - 2018-02-27 10:16:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-27 10:16:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-27 10:16:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-27 10:16:55 --> Pagination Class Initialized
INFO - 2018-02-27 10:16:55 --> Helper loaded: form_helper
INFO - 2018-02-27 10:16:55 --> Form Validation Class Initialized
INFO - 2018-02-27 10:16:55 --> Model Class Initialized
INFO - 2018-02-27 10:16:55 --> Controller Class Initialized
INFO - 2018-02-27 10:16:55 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-27 10:16:55 --> Model Class Initialized
INFO - 2018-02-27 10:16:55 --> Model Class Initialized
ERROR - 2018-02-27 10:16:55 --> Severity: Notice --> Undefined index: remember_me /var/www/html/project/radio/application/controllers/Index.php 74
INFO - 2018-02-27 10:16:55 --> Config Class Initialized
INFO - 2018-02-27 10:16:55 --> Hooks Class Initialized
DEBUG - 2018-02-27 10:16:55 --> UTF-8 Support Enabled
INFO - 2018-02-27 10:16:55 --> Utf8 Class Initialized
INFO - 2018-02-27 10:16:55 --> URI Class Initialized
INFO - 2018-02-27 10:16:55 --> Router Class Initialized
INFO - 2018-02-27 10:16:55 --> Output Class Initialized
INFO - 2018-02-27 10:16:55 --> Security Class Initialized
DEBUG - 2018-02-27 10:16:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-27 10:16:55 --> Input Class Initialized
INFO - 2018-02-27 10:16:55 --> Language Class Initialized
INFO - 2018-02-27 10:16:55 --> Loader Class Initialized
INFO - 2018-02-27 10:16:55 --> Helper loaded: url_helper
INFO - 2018-02-27 10:16:55 --> Helper loaded: file_helper
INFO - 2018-02-27 10:16:55 --> Helper loaded: email_helper
INFO - 2018-02-27 10:16:55 --> Helper loaded: common_helper
INFO - 2018-02-27 10:16:55 --> Database Driver Class Initialized
DEBUG - 2018-02-27 10:16:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-27 10:16:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-27 10:16:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-27 10:16:55 --> Pagination Class Initialized
INFO - 2018-02-27 10:16:55 --> Helper loaded: form_helper
INFO - 2018-02-27 10:16:55 --> Form Validation Class Initialized
INFO - 2018-02-27 10:16:55 --> Model Class Initialized
INFO - 2018-02-27 10:16:55 --> Controller Class Initialized
INFO - 2018-02-27 10:16:55 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-27 10:16:55 --> Model Class Initialized
INFO - 2018-02-27 10:16:55 --> Model Class Initialized
INFO - 2018-02-27 10:16:55 --> Model Class Initialized
INFO - 2018-02-27 10:16:55 --> Model Class Initialized
INFO - 2018-02-27 10:16:55 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-27 10:16:55 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-27 10:16:55 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-27 10:16:55 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-27 10:16:55 --> File loaded: /var/www/html/project/radio/application/views/dashboard/index.php
INFO - 2018-02-27 10:16:55 --> Final output sent to browser
DEBUG - 2018-02-27 10:16:55 --> Total execution time: 0.0814
INFO - 2018-02-27 10:30:18 --> Config Class Initialized
INFO - 2018-02-27 10:30:18 --> Hooks Class Initialized
DEBUG - 2018-02-27 10:30:18 --> UTF-8 Support Enabled
INFO - 2018-02-27 10:30:18 --> Utf8 Class Initialized
INFO - 2018-02-27 10:30:18 --> URI Class Initialized
INFO - 2018-02-27 10:30:18 --> Router Class Initialized
INFO - 2018-02-27 10:30:18 --> Output Class Initialized
INFO - 2018-02-27 10:30:18 --> Security Class Initialized
DEBUG - 2018-02-27 10:30:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-27 10:30:18 --> Input Class Initialized
INFO - 2018-02-27 10:30:18 --> Language Class Initialized
INFO - 2018-02-27 10:30:18 --> Loader Class Initialized
INFO - 2018-02-27 10:30:18 --> Helper loaded: url_helper
INFO - 2018-02-27 10:30:18 --> Helper loaded: file_helper
INFO - 2018-02-27 10:30:18 --> Helper loaded: email_helper
INFO - 2018-02-27 10:30:18 --> Helper loaded: common_helper
INFO - 2018-02-27 10:30:18 --> Database Driver Class Initialized
DEBUG - 2018-02-27 10:30:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-27 10:30:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-27 10:30:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-27 10:30:18 --> Pagination Class Initialized
INFO - 2018-02-27 10:30:18 --> Helper loaded: form_helper
INFO - 2018-02-27 10:30:18 --> Form Validation Class Initialized
INFO - 2018-02-27 10:30:18 --> Model Class Initialized
INFO - 2018-02-27 10:30:18 --> Controller Class Initialized
INFO - 2018-02-27 10:30:18 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-27 10:30:18 --> Model Class Initialized
INFO - 2018-02-27 10:30:18 --> Model Class Initialized
INFO - 2018-02-27 10:30:18 --> Model Class Initialized
INFO - 2018-02-27 10:30:18 --> Model Class Initialized
INFO - 2018-02-27 10:30:18 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-27 10:30:18 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-27 10:30:18 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-27 10:30:18 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-27 10:30:18 --> File loaded: /var/www/html/project/radio/application/views/dashboard/index.php
INFO - 2018-02-27 10:30:18 --> Final output sent to browser
DEBUG - 2018-02-27 10:30:18 --> Total execution time: 0.0114
INFO - 2018-02-27 10:30:20 --> Config Class Initialized
INFO - 2018-02-27 10:30:20 --> Hooks Class Initialized
DEBUG - 2018-02-27 10:30:20 --> UTF-8 Support Enabled
INFO - 2018-02-27 10:30:20 --> Utf8 Class Initialized
INFO - 2018-02-27 10:30:20 --> URI Class Initialized
INFO - 2018-02-27 10:30:20 --> Router Class Initialized
INFO - 2018-02-27 10:30:20 --> Output Class Initialized
INFO - 2018-02-27 10:30:20 --> Security Class Initialized
DEBUG - 2018-02-27 10:30:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-27 10:30:20 --> Input Class Initialized
INFO - 2018-02-27 10:30:20 --> Language Class Initialized
INFO - 2018-02-27 10:30:20 --> Loader Class Initialized
INFO - 2018-02-27 10:30:20 --> Helper loaded: url_helper
INFO - 2018-02-27 10:30:20 --> Helper loaded: file_helper
INFO - 2018-02-27 10:30:20 --> Helper loaded: email_helper
INFO - 2018-02-27 10:30:20 --> Helper loaded: common_helper
INFO - 2018-02-27 10:30:20 --> Database Driver Class Initialized
DEBUG - 2018-02-27 10:30:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-27 10:30:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-27 10:30:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-27 10:30:20 --> Pagination Class Initialized
INFO - 2018-02-27 10:30:20 --> Helper loaded: form_helper
INFO - 2018-02-27 10:30:20 --> Form Validation Class Initialized
INFO - 2018-02-27 10:30:20 --> Model Class Initialized
INFO - 2018-02-27 10:30:20 --> Controller Class Initialized
INFO - 2018-02-27 10:30:20 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-27 10:30:20 --> Model Class Initialized
INFO - 2018-02-27 10:30:20 --> Model Class Initialized
INFO - 2018-02-27 10:30:20 --> Model Class Initialized
INFO - 2018-02-27 10:30:20 --> Model Class Initialized
INFO - 2018-02-27 10:30:20 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-27 10:30:20 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-27 10:30:20 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-27 10:30:20 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-27 10:30:20 --> File loaded: /var/www/html/project/radio/application/views/tracks/index.php
INFO - 2018-02-27 10:30:20 --> Final output sent to browser
DEBUG - 2018-02-27 10:30:20 --> Total execution time: 0.0501
INFO - 2018-02-27 10:30:20 --> Config Class Initialized
INFO - 2018-02-27 10:30:20 --> Hooks Class Initialized
DEBUG - 2018-02-27 10:30:20 --> UTF-8 Support Enabled
INFO - 2018-02-27 10:30:20 --> Utf8 Class Initialized
INFO - 2018-02-27 10:30:20 --> URI Class Initialized
INFO - 2018-02-27 10:30:20 --> Router Class Initialized
INFO - 2018-02-27 10:30:20 --> Output Class Initialized
INFO - 2018-02-27 10:30:20 --> Security Class Initialized
DEBUG - 2018-02-27 10:30:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-27 10:30:20 --> Input Class Initialized
INFO - 2018-02-27 10:30:20 --> Language Class Initialized
INFO - 2018-02-27 10:30:20 --> Loader Class Initialized
INFO - 2018-02-27 10:30:20 --> Helper loaded: url_helper
INFO - 2018-02-27 10:30:20 --> Helper loaded: file_helper
INFO - 2018-02-27 10:30:20 --> Helper loaded: email_helper
INFO - 2018-02-27 10:30:20 --> Helper loaded: common_helper
INFO - 2018-02-27 10:30:20 --> Database Driver Class Initialized
DEBUG - 2018-02-27 10:30:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-27 10:30:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-27 10:30:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-27 10:30:20 --> Pagination Class Initialized
INFO - 2018-02-27 10:30:20 --> Helper loaded: form_helper
INFO - 2018-02-27 10:30:20 --> Form Validation Class Initialized
INFO - 2018-02-27 10:30:20 --> Model Class Initialized
INFO - 2018-02-27 10:30:20 --> Controller Class Initialized
INFO - 2018-02-27 10:30:20 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-27 10:30:20 --> Model Class Initialized
INFO - 2018-02-27 10:30:20 --> Model Class Initialized
INFO - 2018-02-27 10:30:20 --> Model Class Initialized
INFO - 2018-02-27 10:30:20 --> Model Class Initialized
INFO - 2018-02-27 10:30:21 --> Config Class Initialized
INFO - 2018-02-27 10:30:21 --> Hooks Class Initialized
DEBUG - 2018-02-27 10:30:21 --> UTF-8 Support Enabled
INFO - 2018-02-27 10:30:21 --> Utf8 Class Initialized
INFO - 2018-02-27 10:30:21 --> URI Class Initialized
INFO - 2018-02-27 10:30:21 --> Router Class Initialized
INFO - 2018-02-27 10:30:21 --> Output Class Initialized
INFO - 2018-02-27 10:30:21 --> Security Class Initialized
DEBUG - 2018-02-27 10:30:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-27 10:30:21 --> Input Class Initialized
INFO - 2018-02-27 10:30:21 --> Language Class Initialized
INFO - 2018-02-27 10:30:21 --> Loader Class Initialized
INFO - 2018-02-27 10:30:21 --> Helper loaded: url_helper
INFO - 2018-02-27 10:30:21 --> Helper loaded: file_helper
INFO - 2018-02-27 10:30:21 --> Helper loaded: email_helper
INFO - 2018-02-27 10:30:21 --> Helper loaded: common_helper
INFO - 2018-02-27 10:30:21 --> Database Driver Class Initialized
DEBUG - 2018-02-27 10:30:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-27 10:30:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-27 10:30:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-27 10:30:21 --> Pagination Class Initialized
INFO - 2018-02-27 10:30:21 --> Helper loaded: form_helper
INFO - 2018-02-27 10:30:21 --> Form Validation Class Initialized
INFO - 2018-02-27 10:30:21 --> Model Class Initialized
INFO - 2018-02-27 10:30:21 --> Controller Class Initialized
INFO - 2018-02-27 10:30:21 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-27 10:30:21 --> Model Class Initialized
INFO - 2018-02-27 10:30:21 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-27 10:30:21 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-27 10:30:21 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-27 10:30:21 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-27 10:30:21 --> File loaded: /var/www/html/project/radio/application/views/user/index.php
INFO - 2018-02-27 10:30:21 --> Final output sent to browser
DEBUG - 2018-02-27 10:30:21 --> Total execution time: 0.0234
INFO - 2018-02-27 10:30:21 --> Config Class Initialized
INFO - 2018-02-27 10:30:21 --> Hooks Class Initialized
DEBUG - 2018-02-27 10:30:21 --> UTF-8 Support Enabled
INFO - 2018-02-27 10:30:21 --> Utf8 Class Initialized
INFO - 2018-02-27 10:30:21 --> URI Class Initialized
INFO - 2018-02-27 10:30:21 --> Router Class Initialized
INFO - 2018-02-27 10:30:21 --> Output Class Initialized
INFO - 2018-02-27 10:30:21 --> Security Class Initialized
DEBUG - 2018-02-27 10:30:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-27 10:30:21 --> Input Class Initialized
INFO - 2018-02-27 10:30:21 --> Language Class Initialized
INFO - 2018-02-27 10:30:21 --> Loader Class Initialized
INFO - 2018-02-27 10:30:21 --> Helper loaded: url_helper
INFO - 2018-02-27 10:30:21 --> Helper loaded: file_helper
INFO - 2018-02-27 10:30:21 --> Helper loaded: email_helper
INFO - 2018-02-27 10:30:21 --> Helper loaded: common_helper
INFO - 2018-02-27 10:30:21 --> Database Driver Class Initialized
DEBUG - 2018-02-27 10:30:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-27 10:30:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-27 10:30:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-27 10:30:21 --> Pagination Class Initialized
INFO - 2018-02-27 10:30:21 --> Helper loaded: form_helper
INFO - 2018-02-27 10:30:21 --> Form Validation Class Initialized
INFO - 2018-02-27 10:30:21 --> Model Class Initialized
INFO - 2018-02-27 10:30:21 --> Controller Class Initialized
INFO - 2018-02-27 10:30:21 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-27 10:30:21 --> Model Class Initialized
INFO - 2018-02-27 16:45:31 --> Config Class Initialized
INFO - 2018-02-27 16:45:31 --> Hooks Class Initialized
DEBUG - 2018-02-27 16:45:31 --> UTF-8 Support Enabled
INFO - 2018-02-27 16:45:31 --> Utf8 Class Initialized
INFO - 2018-02-27 16:45:31 --> URI Class Initialized
DEBUG - 2018-02-27 16:45:31 --> No URI present. Default controller set.
INFO - 2018-02-27 16:45:31 --> Router Class Initialized
INFO - 2018-02-27 16:45:31 --> Output Class Initialized
INFO - 2018-02-27 16:45:31 --> Security Class Initialized
DEBUG - 2018-02-27 16:45:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-27 16:45:31 --> Input Class Initialized
INFO - 2018-02-27 16:45:31 --> Language Class Initialized
INFO - 2018-02-27 16:45:31 --> Loader Class Initialized
INFO - 2018-02-27 16:45:31 --> Helper loaded: url_helper
INFO - 2018-02-27 16:45:31 --> Helper loaded: file_helper
INFO - 2018-02-27 16:45:31 --> Helper loaded: email_helper
INFO - 2018-02-27 16:45:31 --> Helper loaded: common_helper
INFO - 2018-02-27 16:45:31 --> Database Driver Class Initialized
DEBUG - 2018-02-27 16:45:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-27 16:45:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-27 16:45:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-27 16:45:31 --> Pagination Class Initialized
INFO - 2018-02-27 16:45:31 --> Helper loaded: form_helper
INFO - 2018-02-27 16:45:31 --> Form Validation Class Initialized
INFO - 2018-02-27 16:45:31 --> Model Class Initialized
INFO - 2018-02-27 16:45:31 --> Controller Class Initialized
INFO - 2018-02-27 16:45:31 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-27 16:45:31 --> Model Class Initialized
INFO - 2018-02-27 16:45:31 --> Model Class Initialized
INFO - 2018-02-27 16:45:31 --> File loaded: /var/www/html/project/periodtracker/application/views/index/index.php
INFO - 2018-02-27 16:45:31 --> Final output sent to browser
DEBUG - 2018-02-27 16:45:31 --> Total execution time: 0.0327
INFO - 2018-02-27 16:45:44 --> Config Class Initialized
INFO - 2018-02-27 16:45:44 --> Hooks Class Initialized
DEBUG - 2018-02-27 16:45:44 --> UTF-8 Support Enabled
INFO - 2018-02-27 16:45:44 --> Utf8 Class Initialized
INFO - 2018-02-27 16:45:44 --> URI Class Initialized
INFO - 2018-02-27 16:45:44 --> Router Class Initialized
INFO - 2018-02-27 16:45:44 --> Output Class Initialized
INFO - 2018-02-27 16:45:44 --> Security Class Initialized
DEBUG - 2018-02-27 16:45:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-27 16:45:44 --> Input Class Initialized
INFO - 2018-02-27 16:45:44 --> Language Class Initialized
ERROR - 2018-02-27 16:45:44 --> 404 Page Not Found: Index/forgorpassword
INFO - 2018-02-27 16:45:56 --> Config Class Initialized
INFO - 2018-02-27 16:45:56 --> Hooks Class Initialized
DEBUG - 2018-02-27 16:45:56 --> UTF-8 Support Enabled
INFO - 2018-02-27 16:45:56 --> Utf8 Class Initialized
INFO - 2018-02-27 16:45:56 --> URI Class Initialized
INFO - 2018-02-27 16:45:56 --> Router Class Initialized
INFO - 2018-02-27 16:45:56 --> Output Class Initialized
INFO - 2018-02-27 16:45:56 --> Security Class Initialized
DEBUG - 2018-02-27 16:45:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-27 16:45:56 --> Input Class Initialized
INFO - 2018-02-27 16:45:56 --> Language Class Initialized
INFO - 2018-02-27 16:45:56 --> Loader Class Initialized
INFO - 2018-02-27 16:45:56 --> Helper loaded: url_helper
INFO - 2018-02-27 16:45:56 --> Helper loaded: file_helper
INFO - 2018-02-27 16:45:56 --> Helper loaded: email_helper
INFO - 2018-02-27 16:45:56 --> Helper loaded: common_helper
INFO - 2018-02-27 16:45:56 --> Database Driver Class Initialized
DEBUG - 2018-02-27 16:45:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-27 16:45:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-27 16:45:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-27 16:45:56 --> Pagination Class Initialized
INFO - 2018-02-27 16:45:56 --> Helper loaded: form_helper
INFO - 2018-02-27 16:45:56 --> Form Validation Class Initialized
INFO - 2018-02-27 16:45:56 --> Model Class Initialized
INFO - 2018-02-27 16:45:56 --> Controller Class Initialized
INFO - 2018-02-27 16:45:56 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-27 16:45:56 --> Model Class Initialized
INFO - 2018-02-27 16:45:56 --> Model Class Initialized
INFO - 2018-02-27 16:45:56 --> File loaded: /var/www/html/project/periodtracker/application/views/index/resetPassword.php
INFO - 2018-02-27 16:45:56 --> Final output sent to browser
DEBUG - 2018-02-27 16:45:56 --> Total execution time: 0.0059
INFO - 2018-02-27 16:46:04 --> Config Class Initialized
INFO - 2018-02-27 16:46:04 --> Hooks Class Initialized
DEBUG - 2018-02-27 16:46:04 --> UTF-8 Support Enabled
INFO - 2018-02-27 16:46:04 --> Utf8 Class Initialized
INFO - 2018-02-27 16:46:04 --> URI Class Initialized
INFO - 2018-02-27 16:46:04 --> Router Class Initialized
INFO - 2018-02-27 16:46:04 --> Output Class Initialized
INFO - 2018-02-27 16:46:04 --> Security Class Initialized
DEBUG - 2018-02-27 16:46:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-27 16:46:04 --> Input Class Initialized
INFO - 2018-02-27 16:46:04 --> Language Class Initialized
INFO - 2018-02-27 16:46:04 --> Loader Class Initialized
INFO - 2018-02-27 16:46:04 --> Helper loaded: url_helper
INFO - 2018-02-27 16:46:04 --> Helper loaded: file_helper
INFO - 2018-02-27 16:46:04 --> Helper loaded: email_helper
INFO - 2018-02-27 16:46:04 --> Helper loaded: common_helper
INFO - 2018-02-27 16:46:04 --> Database Driver Class Initialized
DEBUG - 2018-02-27 16:46:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-27 16:46:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-27 16:46:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-27 16:46:04 --> Pagination Class Initialized
INFO - 2018-02-27 16:46:04 --> Helper loaded: form_helper
INFO - 2018-02-27 16:46:04 --> Form Validation Class Initialized
INFO - 2018-02-27 16:46:04 --> Model Class Initialized
INFO - 2018-02-27 16:46:04 --> Controller Class Initialized
INFO - 2018-02-27 16:46:04 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-27 16:46:04 --> Model Class Initialized
INFO - 2018-02-27 16:46:04 --> Model Class Initialized
INFO - 2018-02-27 16:46:04 --> File loaded: /var/www/html/project/periodtracker/application/views/index/resetPassword.php
INFO - 2018-02-27 16:46:04 --> Final output sent to browser
DEBUG - 2018-02-27 16:46:04 --> Total execution time: 0.0066
INFO - 2018-02-27 16:49:56 --> Config Class Initialized
INFO - 2018-02-27 16:49:56 --> Hooks Class Initialized
DEBUG - 2018-02-27 16:49:56 --> UTF-8 Support Enabled
INFO - 2018-02-27 16:49:56 --> Utf8 Class Initialized
INFO - 2018-02-27 16:49:56 --> URI Class Initialized
INFO - 2018-02-27 16:49:56 --> Router Class Initialized
INFO - 2018-02-27 16:49:56 --> Output Class Initialized
INFO - 2018-02-27 16:49:56 --> Security Class Initialized
DEBUG - 2018-02-27 16:49:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-27 16:49:56 --> Input Class Initialized
INFO - 2018-02-27 16:49:56 --> Language Class Initialized
INFO - 2018-02-27 16:49:56 --> Loader Class Initialized
INFO - 2018-02-27 16:49:56 --> Helper loaded: url_helper
INFO - 2018-02-27 16:49:56 --> Helper loaded: file_helper
INFO - 2018-02-27 16:49:56 --> Helper loaded: email_helper
INFO - 2018-02-27 16:49:56 --> Helper loaded: common_helper
INFO - 2018-02-27 16:49:56 --> Database Driver Class Initialized
DEBUG - 2018-02-27 16:49:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-27 16:49:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-27 16:49:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-27 16:49:56 --> Pagination Class Initialized
INFO - 2018-02-27 16:49:56 --> Helper loaded: form_helper
INFO - 2018-02-27 16:49:56 --> Form Validation Class Initialized
INFO - 2018-02-27 16:49:56 --> Model Class Initialized
INFO - 2018-02-27 16:49:56 --> Controller Class Initialized
DEBUG - 2018-02-27 16:49:56 --> Config file loaded: /var/www/html/project/periodtracker/application/config/rest.php
INFO - 2018-02-27 16:49:56 --> Helper loaded: inflector_helper
INFO - 2018-02-27 16:49:56 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-27 16:49:56 --> Model Class Initialized
INFO - 2018-02-27 16:49:56 --> Model Class Initialized
INFO - 2018-02-27 16:49:56 --> Model Class Initialized
INFO - 2018-02-27 16:49:56 --> Final output sent to browser
DEBUG - 2018-02-27 16:49:56 --> Total execution time: 0.0134
INFO - 2018-02-27 16:50:44 --> Config Class Initialized
INFO - 2018-02-27 16:50:44 --> Hooks Class Initialized
DEBUG - 2018-02-27 16:50:44 --> UTF-8 Support Enabled
INFO - 2018-02-27 16:50:44 --> Utf8 Class Initialized
INFO - 2018-02-27 16:50:44 --> URI Class Initialized
INFO - 2018-02-27 16:50:44 --> Router Class Initialized
INFO - 2018-02-27 16:50:44 --> Output Class Initialized
INFO - 2018-02-27 16:50:44 --> Security Class Initialized
DEBUG - 2018-02-27 16:50:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-27 16:50:44 --> Input Class Initialized
INFO - 2018-02-27 16:50:44 --> Language Class Initialized
INFO - 2018-02-27 16:50:44 --> Loader Class Initialized
INFO - 2018-02-27 16:50:44 --> Helper loaded: url_helper
INFO - 2018-02-27 16:50:44 --> Helper loaded: file_helper
INFO - 2018-02-27 16:50:44 --> Helper loaded: email_helper
INFO - 2018-02-27 16:50:44 --> Helper loaded: common_helper
INFO - 2018-02-27 16:50:44 --> Database Driver Class Initialized
DEBUG - 2018-02-27 16:50:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-27 16:50:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-27 16:50:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-27 16:50:44 --> Pagination Class Initialized
INFO - 2018-02-27 16:50:44 --> Helper loaded: form_helper
INFO - 2018-02-27 16:50:44 --> Form Validation Class Initialized
INFO - 2018-02-27 16:50:44 --> Model Class Initialized
INFO - 2018-02-27 16:50:44 --> Controller Class Initialized
DEBUG - 2018-02-27 16:50:44 --> Config file loaded: /var/www/html/project/periodtracker/application/config/rest.php
INFO - 2018-02-27 16:50:44 --> Helper loaded: inflector_helper
INFO - 2018-02-27 16:50:44 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-27 16:50:44 --> Model Class Initialized
INFO - 2018-02-27 16:50:44 --> Model Class Initialized
INFO - 2018-02-27 16:50:44 --> Model Class Initialized
INFO - 2018-02-27 16:50:59 --> Config Class Initialized
INFO - 2018-02-27 16:50:59 --> Hooks Class Initialized
DEBUG - 2018-02-27 16:50:59 --> UTF-8 Support Enabled
INFO - 2018-02-27 16:50:59 --> Utf8 Class Initialized
INFO - 2018-02-27 16:50:59 --> URI Class Initialized
INFO - 2018-02-27 16:50:59 --> Router Class Initialized
INFO - 2018-02-27 16:50:59 --> Output Class Initialized
INFO - 2018-02-27 16:50:59 --> Security Class Initialized
DEBUG - 2018-02-27 16:50:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-27 16:50:59 --> Input Class Initialized
INFO - 2018-02-27 16:50:59 --> Language Class Initialized
INFO - 2018-02-27 16:50:59 --> Loader Class Initialized
INFO - 2018-02-27 16:50:59 --> Helper loaded: url_helper
INFO - 2018-02-27 16:50:59 --> Helper loaded: file_helper
INFO - 2018-02-27 16:50:59 --> Helper loaded: email_helper
INFO - 2018-02-27 16:50:59 --> Helper loaded: common_helper
INFO - 2018-02-27 16:50:59 --> Database Driver Class Initialized
DEBUG - 2018-02-27 16:50:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-27 16:50:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-27 16:50:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-27 16:50:59 --> Pagination Class Initialized
INFO - 2018-02-27 16:50:59 --> Helper loaded: form_helper
INFO - 2018-02-27 16:50:59 --> Form Validation Class Initialized
INFO - 2018-02-27 16:50:59 --> Model Class Initialized
INFO - 2018-02-27 16:50:59 --> Controller Class Initialized
DEBUG - 2018-02-27 16:50:59 --> Config file loaded: /var/www/html/project/periodtracker/application/config/rest.php
INFO - 2018-02-27 16:50:59 --> Helper loaded: inflector_helper
INFO - 2018-02-27 16:50:59 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-27 16:50:59 --> Model Class Initialized
INFO - 2018-02-27 16:50:59 --> Model Class Initialized
INFO - 2018-02-27 16:50:59 --> Model Class Initialized
INFO - 2018-02-27 16:50:59 --> Final output sent to browser
DEBUG - 2018-02-27 16:50:59 --> Total execution time: 0.0118
INFO - 2018-02-27 16:51:09 --> Config Class Initialized
INFO - 2018-02-27 16:51:09 --> Hooks Class Initialized
DEBUG - 2018-02-27 16:51:09 --> UTF-8 Support Enabled
INFO - 2018-02-27 16:51:09 --> Utf8 Class Initialized
INFO - 2018-02-27 16:51:09 --> URI Class Initialized
INFO - 2018-02-27 16:51:09 --> Router Class Initialized
INFO - 2018-02-27 16:51:09 --> Output Class Initialized
INFO - 2018-02-27 16:51:09 --> Security Class Initialized
DEBUG - 2018-02-27 16:51:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-27 16:51:09 --> Input Class Initialized
INFO - 2018-02-27 16:51:09 --> Language Class Initialized
INFO - 2018-02-27 16:51:09 --> Loader Class Initialized
INFO - 2018-02-27 16:51:09 --> Helper loaded: url_helper
INFO - 2018-02-27 16:51:09 --> Helper loaded: file_helper
INFO - 2018-02-27 16:51:09 --> Helper loaded: email_helper
INFO - 2018-02-27 16:51:09 --> Helper loaded: common_helper
INFO - 2018-02-27 16:51:09 --> Database Driver Class Initialized
DEBUG - 2018-02-27 16:51:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-27 16:51:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-27 16:51:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-27 16:51:09 --> Pagination Class Initialized
INFO - 2018-02-27 16:51:09 --> Helper loaded: form_helper
INFO - 2018-02-27 16:51:09 --> Form Validation Class Initialized
INFO - 2018-02-27 16:51:09 --> Model Class Initialized
INFO - 2018-02-27 16:51:09 --> Controller Class Initialized
DEBUG - 2018-02-27 16:51:09 --> Config file loaded: /var/www/html/project/periodtracker/application/config/rest.php
INFO - 2018-02-27 16:51:09 --> Helper loaded: inflector_helper
INFO - 2018-02-27 16:51:09 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-27 16:51:09 --> Model Class Initialized
INFO - 2018-02-27 16:51:09 --> Model Class Initialized
INFO - 2018-02-27 16:51:09 --> Model Class Initialized
INFO - 2018-02-27 16:51:09 --> Final output sent to browser
DEBUG - 2018-02-27 16:51:09 --> Total execution time: 0.0047
INFO - 2018-02-27 16:51:17 --> Config Class Initialized
INFO - 2018-02-27 16:51:17 --> Hooks Class Initialized
DEBUG - 2018-02-27 16:51:17 --> UTF-8 Support Enabled
INFO - 2018-02-27 16:51:17 --> Utf8 Class Initialized
INFO - 2018-02-27 16:51:17 --> URI Class Initialized
INFO - 2018-02-27 16:51:17 --> Router Class Initialized
INFO - 2018-02-27 16:51:17 --> Output Class Initialized
INFO - 2018-02-27 16:51:17 --> Security Class Initialized
DEBUG - 2018-02-27 16:51:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-27 16:51:17 --> Input Class Initialized
INFO - 2018-02-27 16:51:17 --> Language Class Initialized
INFO - 2018-02-27 16:51:17 --> Loader Class Initialized
INFO - 2018-02-27 16:51:17 --> Helper loaded: url_helper
INFO - 2018-02-27 16:51:17 --> Helper loaded: file_helper
INFO - 2018-02-27 16:51:17 --> Helper loaded: email_helper
INFO - 2018-02-27 16:51:17 --> Helper loaded: common_helper
INFO - 2018-02-27 16:51:17 --> Database Driver Class Initialized
DEBUG - 2018-02-27 16:51:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-27 16:51:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-27 16:51:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-27 16:51:17 --> Pagination Class Initialized
INFO - 2018-02-27 16:51:17 --> Helper loaded: form_helper
INFO - 2018-02-27 16:51:17 --> Form Validation Class Initialized
INFO - 2018-02-27 16:51:17 --> Model Class Initialized
INFO - 2018-02-27 16:51:17 --> Controller Class Initialized
DEBUG - 2018-02-27 16:51:17 --> Config file loaded: /var/www/html/project/periodtracker/application/config/rest.php
INFO - 2018-02-27 16:51:17 --> Helper loaded: inflector_helper
INFO - 2018-02-27 16:51:17 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-27 16:51:17 --> Model Class Initialized
INFO - 2018-02-27 16:51:17 --> Model Class Initialized
INFO - 2018-02-27 16:51:17 --> Model Class Initialized
INFO - 2018-02-27 16:51:17 --> Final output sent to browser
DEBUG - 2018-02-27 16:51:17 --> Total execution time: 0.0039
INFO - 2018-02-27 16:52:59 --> Config Class Initialized
INFO - 2018-02-27 16:52:59 --> Hooks Class Initialized
DEBUG - 2018-02-27 16:52:59 --> UTF-8 Support Enabled
INFO - 2018-02-27 16:52:59 --> Utf8 Class Initialized
INFO - 2018-02-27 16:52:59 --> URI Class Initialized
INFO - 2018-02-27 16:52:59 --> Router Class Initialized
INFO - 2018-02-27 16:52:59 --> Output Class Initialized
INFO - 2018-02-27 16:52:59 --> Security Class Initialized
DEBUG - 2018-02-27 16:52:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-27 16:52:59 --> Input Class Initialized
INFO - 2018-02-27 16:52:59 --> Language Class Initialized
INFO - 2018-02-27 16:52:59 --> Loader Class Initialized
INFO - 2018-02-27 16:52:59 --> Helper loaded: url_helper
INFO - 2018-02-27 16:52:59 --> Helper loaded: file_helper
INFO - 2018-02-27 16:52:59 --> Helper loaded: email_helper
INFO - 2018-02-27 16:52:59 --> Helper loaded: common_helper
INFO - 2018-02-27 16:52:59 --> Database Driver Class Initialized
DEBUG - 2018-02-27 16:52:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-27 16:52:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-27 16:52:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-27 16:52:59 --> Pagination Class Initialized
INFO - 2018-02-27 16:52:59 --> Helper loaded: form_helper
INFO - 2018-02-27 16:52:59 --> Form Validation Class Initialized
INFO - 2018-02-27 16:52:59 --> Model Class Initialized
INFO - 2018-02-27 16:52:59 --> Controller Class Initialized
DEBUG - 2018-02-27 16:52:59 --> Config file loaded: /var/www/html/project/periodtracker/application/config/rest.php
INFO - 2018-02-27 16:52:59 --> Helper loaded: inflector_helper
INFO - 2018-02-27 16:52:59 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-27 16:52:59 --> Model Class Initialized
INFO - 2018-02-27 16:52:59 --> Model Class Initialized
INFO - 2018-02-27 16:52:59 --> Model Class Initialized
INFO - 2018-02-27 16:52:59 --> Final output sent to browser
DEBUG - 2018-02-27 16:52:59 --> Total execution time: 0.0703
INFO - 2018-02-27 16:54:31 --> Config Class Initialized
INFO - 2018-02-27 16:54:31 --> Hooks Class Initialized
DEBUG - 2018-02-27 16:54:31 --> UTF-8 Support Enabled
INFO - 2018-02-27 16:54:31 --> Utf8 Class Initialized
INFO - 2018-02-27 16:54:31 --> URI Class Initialized
INFO - 2018-02-27 16:54:31 --> Router Class Initialized
INFO - 2018-02-27 16:54:31 --> Output Class Initialized
INFO - 2018-02-27 16:54:31 --> Security Class Initialized
DEBUG - 2018-02-27 16:54:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-27 16:54:31 --> Input Class Initialized
INFO - 2018-02-27 16:54:31 --> Language Class Initialized
INFO - 2018-02-27 16:54:31 --> Loader Class Initialized
INFO - 2018-02-27 16:54:31 --> Helper loaded: url_helper
INFO - 2018-02-27 16:54:31 --> Helper loaded: file_helper
INFO - 2018-02-27 16:54:31 --> Helper loaded: email_helper
INFO - 2018-02-27 16:54:31 --> Helper loaded: common_helper
INFO - 2018-02-27 16:54:31 --> Database Driver Class Initialized
DEBUG - 2018-02-27 16:54:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-27 16:54:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-27 16:54:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-27 16:54:31 --> Pagination Class Initialized
INFO - 2018-02-27 16:54:31 --> Helper loaded: form_helper
INFO - 2018-02-27 16:54:31 --> Form Validation Class Initialized
INFO - 2018-02-27 16:54:31 --> Model Class Initialized
INFO - 2018-02-27 16:54:31 --> Controller Class Initialized
DEBUG - 2018-02-27 16:54:31 --> Config file loaded: /var/www/html/project/periodtracker/application/config/rest.php
INFO - 2018-02-27 16:54:31 --> Helper loaded: inflector_helper
INFO - 2018-02-27 16:54:31 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-27 16:54:31 --> Model Class Initialized
INFO - 2018-02-27 16:54:31 --> Model Class Initialized
INFO - 2018-02-27 16:54:31 --> Model Class Initialized
INFO - 2018-02-27 16:54:31 --> Final output sent to browser
DEBUG - 2018-02-27 16:54:31 --> Total execution time: 0.0549
INFO - 2018-02-27 16:55:43 --> Config Class Initialized
INFO - 2018-02-27 16:55:43 --> Hooks Class Initialized
DEBUG - 2018-02-27 16:55:43 --> UTF-8 Support Enabled
INFO - 2018-02-27 16:55:43 --> Utf8 Class Initialized
INFO - 2018-02-27 16:55:43 --> URI Class Initialized
INFO - 2018-02-27 16:55:43 --> Router Class Initialized
INFO - 2018-02-27 16:55:43 --> Output Class Initialized
INFO - 2018-02-27 16:55:43 --> Security Class Initialized
DEBUG - 2018-02-27 16:55:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-27 16:55:43 --> Input Class Initialized
INFO - 2018-02-27 16:55:43 --> Language Class Initialized
INFO - 2018-02-27 16:55:43 --> Loader Class Initialized
INFO - 2018-02-27 16:55:43 --> Helper loaded: url_helper
INFO - 2018-02-27 16:55:43 --> Helper loaded: file_helper
INFO - 2018-02-27 16:55:43 --> Helper loaded: email_helper
INFO - 2018-02-27 16:55:43 --> Helper loaded: common_helper
INFO - 2018-02-27 16:55:43 --> Database Driver Class Initialized
DEBUG - 2018-02-27 16:55:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-27 16:55:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-27 16:55:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-27 16:55:43 --> Pagination Class Initialized
INFO - 2018-02-27 16:55:43 --> Helper loaded: form_helper
INFO - 2018-02-27 16:55:43 --> Form Validation Class Initialized
INFO - 2018-02-27 16:55:43 --> Model Class Initialized
INFO - 2018-02-27 16:55:43 --> Controller Class Initialized
DEBUG - 2018-02-27 16:55:43 --> Config file loaded: /var/www/html/project/periodtracker/application/config/rest.php
INFO - 2018-02-27 16:55:43 --> Helper loaded: inflector_helper
INFO - 2018-02-27 16:55:43 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-27 16:55:43 --> Model Class Initialized
INFO - 2018-02-27 16:55:43 --> Model Class Initialized
INFO - 2018-02-27 16:55:43 --> Model Class Initialized
INFO - 2018-02-27 16:55:43 --> Final output sent to browser
DEBUG - 2018-02-27 16:55:43 --> Total execution time: 0.0039
INFO - 2018-02-27 16:55:50 --> Config Class Initialized
INFO - 2018-02-27 16:55:50 --> Hooks Class Initialized
DEBUG - 2018-02-27 16:55:50 --> UTF-8 Support Enabled
INFO - 2018-02-27 16:55:50 --> Utf8 Class Initialized
INFO - 2018-02-27 16:55:50 --> URI Class Initialized
INFO - 2018-02-27 16:55:50 --> Router Class Initialized
INFO - 2018-02-27 16:55:50 --> Output Class Initialized
INFO - 2018-02-27 16:55:50 --> Security Class Initialized
DEBUG - 2018-02-27 16:55:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-27 16:55:50 --> Input Class Initialized
INFO - 2018-02-27 16:55:50 --> Language Class Initialized
INFO - 2018-02-27 16:55:50 --> Loader Class Initialized
INFO - 2018-02-27 16:55:50 --> Helper loaded: url_helper
INFO - 2018-02-27 16:55:50 --> Helper loaded: file_helper
INFO - 2018-02-27 16:55:50 --> Helper loaded: email_helper
INFO - 2018-02-27 16:55:50 --> Helper loaded: common_helper
INFO - 2018-02-27 16:55:50 --> Database Driver Class Initialized
DEBUG - 2018-02-27 16:55:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-27 16:55:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-27 16:55:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-27 16:55:50 --> Pagination Class Initialized
INFO - 2018-02-27 16:55:50 --> Helper loaded: form_helper
INFO - 2018-02-27 16:55:50 --> Form Validation Class Initialized
INFO - 2018-02-27 16:55:50 --> Model Class Initialized
INFO - 2018-02-27 16:55:50 --> Controller Class Initialized
DEBUG - 2018-02-27 16:55:50 --> Config file loaded: /var/www/html/project/periodtracker/application/config/rest.php
INFO - 2018-02-27 16:55:50 --> Helper loaded: inflector_helper
INFO - 2018-02-27 16:55:50 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-27 16:55:50 --> Model Class Initialized
INFO - 2018-02-27 16:55:50 --> Model Class Initialized
INFO - 2018-02-27 16:55:50 --> Model Class Initialized
INFO - 2018-02-27 16:55:50 --> Final output sent to browser
DEBUG - 2018-02-27 16:55:50 --> Total execution time: 0.0052
INFO - 2018-02-27 16:56:00 --> Config Class Initialized
INFO - 2018-02-27 16:56:00 --> Hooks Class Initialized
DEBUG - 2018-02-27 16:56:00 --> UTF-8 Support Enabled
INFO - 2018-02-27 16:56:00 --> Utf8 Class Initialized
INFO - 2018-02-27 16:56:00 --> URI Class Initialized
INFO - 2018-02-27 16:56:00 --> Router Class Initialized
INFO - 2018-02-27 16:56:00 --> Output Class Initialized
INFO - 2018-02-27 16:56:00 --> Security Class Initialized
DEBUG - 2018-02-27 16:56:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-27 16:56:00 --> Input Class Initialized
INFO - 2018-02-27 16:56:00 --> Language Class Initialized
INFO - 2018-02-27 16:56:00 --> Loader Class Initialized
INFO - 2018-02-27 16:56:00 --> Helper loaded: url_helper
INFO - 2018-02-27 16:56:00 --> Helper loaded: file_helper
INFO - 2018-02-27 16:56:00 --> Helper loaded: email_helper
INFO - 2018-02-27 16:56:00 --> Helper loaded: common_helper
INFO - 2018-02-27 16:56:00 --> Database Driver Class Initialized
DEBUG - 2018-02-27 16:56:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-27 16:56:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-27 16:56:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-27 16:56:00 --> Pagination Class Initialized
INFO - 2018-02-27 16:56:00 --> Helper loaded: form_helper
INFO - 2018-02-27 16:56:00 --> Form Validation Class Initialized
INFO - 2018-02-27 16:56:00 --> Model Class Initialized
INFO - 2018-02-27 16:56:00 --> Controller Class Initialized
DEBUG - 2018-02-27 16:56:00 --> Config file loaded: /var/www/html/project/periodtracker/application/config/rest.php
INFO - 2018-02-27 16:56:00 --> Helper loaded: inflector_helper
INFO - 2018-02-27 16:56:00 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-27 16:56:00 --> Model Class Initialized
INFO - 2018-02-27 16:56:00 --> Model Class Initialized
INFO - 2018-02-27 16:56:00 --> Model Class Initialized
INFO - 2018-02-27 16:56:00 --> Final output sent to browser
DEBUG - 2018-02-27 16:56:00 --> Total execution time: 0.0057
INFO - 2018-02-27 16:56:08 --> Config Class Initialized
INFO - 2018-02-27 16:56:08 --> Hooks Class Initialized
DEBUG - 2018-02-27 16:56:08 --> UTF-8 Support Enabled
INFO - 2018-02-27 16:56:08 --> Utf8 Class Initialized
INFO - 2018-02-27 16:56:08 --> URI Class Initialized
INFO - 2018-02-27 16:56:08 --> Router Class Initialized
INFO - 2018-02-27 16:56:08 --> Output Class Initialized
INFO - 2018-02-27 16:56:08 --> Security Class Initialized
DEBUG - 2018-02-27 16:56:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-27 16:56:08 --> Input Class Initialized
INFO - 2018-02-27 16:56:08 --> Language Class Initialized
INFO - 2018-02-27 16:56:08 --> Loader Class Initialized
INFO - 2018-02-27 16:56:08 --> Helper loaded: url_helper
INFO - 2018-02-27 16:56:08 --> Helper loaded: file_helper
INFO - 2018-02-27 16:56:08 --> Helper loaded: email_helper
INFO - 2018-02-27 16:56:08 --> Helper loaded: common_helper
INFO - 2018-02-27 16:56:08 --> Database Driver Class Initialized
DEBUG - 2018-02-27 16:56:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-27 16:56:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-27 16:56:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-27 16:56:08 --> Pagination Class Initialized
INFO - 2018-02-27 16:56:08 --> Helper loaded: form_helper
INFO - 2018-02-27 16:56:08 --> Form Validation Class Initialized
INFO - 2018-02-27 16:56:08 --> Model Class Initialized
INFO - 2018-02-27 16:56:08 --> Controller Class Initialized
DEBUG - 2018-02-27 16:56:08 --> Config file loaded: /var/www/html/project/periodtracker/application/config/rest.php
INFO - 2018-02-27 16:56:08 --> Helper loaded: inflector_helper
INFO - 2018-02-27 16:56:08 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-27 16:56:08 --> Model Class Initialized
INFO - 2018-02-27 16:56:08 --> Model Class Initialized
INFO - 2018-02-27 16:56:08 --> Model Class Initialized
INFO - 2018-02-27 16:56:08 --> Final output sent to browser
DEBUG - 2018-02-27 16:56:08 --> Total execution time: 0.0053
INFO - 2018-02-27 16:56:15 --> Config Class Initialized
INFO - 2018-02-27 16:56:15 --> Hooks Class Initialized
DEBUG - 2018-02-27 16:56:15 --> UTF-8 Support Enabled
INFO - 2018-02-27 16:56:15 --> Utf8 Class Initialized
INFO - 2018-02-27 16:56:15 --> URI Class Initialized
INFO - 2018-02-27 16:56:15 --> Router Class Initialized
INFO - 2018-02-27 16:56:15 --> Output Class Initialized
INFO - 2018-02-27 16:56:15 --> Security Class Initialized
DEBUG - 2018-02-27 16:56:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-27 16:56:15 --> Input Class Initialized
INFO - 2018-02-27 16:56:15 --> Language Class Initialized
INFO - 2018-02-27 16:56:15 --> Loader Class Initialized
INFO - 2018-02-27 16:56:15 --> Helper loaded: url_helper
INFO - 2018-02-27 16:56:15 --> Helper loaded: file_helper
INFO - 2018-02-27 16:56:15 --> Helper loaded: email_helper
INFO - 2018-02-27 16:56:15 --> Helper loaded: common_helper
INFO - 2018-02-27 16:56:15 --> Database Driver Class Initialized
DEBUG - 2018-02-27 16:56:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-27 16:56:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-27 16:56:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-27 16:56:15 --> Pagination Class Initialized
INFO - 2018-02-27 16:56:15 --> Helper loaded: form_helper
INFO - 2018-02-27 16:56:15 --> Form Validation Class Initialized
INFO - 2018-02-27 16:56:15 --> Model Class Initialized
INFO - 2018-02-27 16:56:15 --> Controller Class Initialized
DEBUG - 2018-02-27 16:56:15 --> Config file loaded: /var/www/html/project/periodtracker/application/config/rest.php
INFO - 2018-02-27 16:56:15 --> Helper loaded: inflector_helper
INFO - 2018-02-27 16:56:15 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-27 16:56:15 --> Model Class Initialized
INFO - 2018-02-27 16:56:15 --> Model Class Initialized
INFO - 2018-02-27 16:56:15 --> Model Class Initialized
INFO - 2018-02-27 16:56:15 --> Final output sent to browser
DEBUG - 2018-02-27 16:56:15 --> Total execution time: 0.0060
INFO - 2018-02-27 16:56:23 --> Config Class Initialized
INFO - 2018-02-27 16:56:23 --> Hooks Class Initialized
DEBUG - 2018-02-27 16:56:23 --> UTF-8 Support Enabled
INFO - 2018-02-27 16:56:23 --> Utf8 Class Initialized
INFO - 2018-02-27 16:56:23 --> URI Class Initialized
INFO - 2018-02-27 16:56:23 --> Router Class Initialized
INFO - 2018-02-27 16:56:23 --> Output Class Initialized
INFO - 2018-02-27 16:56:23 --> Security Class Initialized
DEBUG - 2018-02-27 16:56:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-27 16:56:23 --> Input Class Initialized
INFO - 2018-02-27 16:56:23 --> Language Class Initialized
INFO - 2018-02-27 16:56:23 --> Loader Class Initialized
INFO - 2018-02-27 16:56:23 --> Helper loaded: url_helper
INFO - 2018-02-27 16:56:23 --> Helper loaded: file_helper
INFO - 2018-02-27 16:56:23 --> Helper loaded: email_helper
INFO - 2018-02-27 16:56:23 --> Helper loaded: common_helper
INFO - 2018-02-27 16:56:23 --> Database Driver Class Initialized
DEBUG - 2018-02-27 16:56:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-27 16:56:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-27 16:56:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-27 16:56:23 --> Pagination Class Initialized
INFO - 2018-02-27 16:56:23 --> Helper loaded: form_helper
INFO - 2018-02-27 16:56:23 --> Form Validation Class Initialized
INFO - 2018-02-27 16:56:23 --> Model Class Initialized
INFO - 2018-02-27 16:56:23 --> Controller Class Initialized
DEBUG - 2018-02-27 16:56:23 --> Config file loaded: /var/www/html/project/periodtracker/application/config/rest.php
INFO - 2018-02-27 16:56:23 --> Helper loaded: inflector_helper
INFO - 2018-02-27 16:56:23 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-27 16:56:23 --> Model Class Initialized
INFO - 2018-02-27 16:56:23 --> Model Class Initialized
INFO - 2018-02-27 16:56:23 --> Model Class Initialized
INFO - 2018-02-27 16:56:23 --> Final output sent to browser
DEBUG - 2018-02-27 16:56:23 --> Total execution time: 0.0088
INFO - 2018-02-27 16:57:21 --> Config Class Initialized
INFO - 2018-02-27 16:57:21 --> Hooks Class Initialized
DEBUG - 2018-02-27 16:57:21 --> UTF-8 Support Enabled
INFO - 2018-02-27 16:57:21 --> Utf8 Class Initialized
INFO - 2018-02-27 16:57:21 --> URI Class Initialized
INFO - 2018-02-27 16:57:21 --> Router Class Initialized
INFO - 2018-02-27 16:57:21 --> Output Class Initialized
INFO - 2018-02-27 16:57:21 --> Security Class Initialized
DEBUG - 2018-02-27 16:57:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-27 16:57:21 --> Input Class Initialized
INFO - 2018-02-27 16:57:21 --> Language Class Initialized
INFO - 2018-02-27 16:57:21 --> Loader Class Initialized
INFO - 2018-02-27 16:57:21 --> Helper loaded: url_helper
INFO - 2018-02-27 16:57:21 --> Helper loaded: file_helper
INFO - 2018-02-27 16:57:21 --> Helper loaded: email_helper
INFO - 2018-02-27 16:57:21 --> Helper loaded: common_helper
INFO - 2018-02-27 16:57:21 --> Database Driver Class Initialized
DEBUG - 2018-02-27 16:57:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-27 16:57:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-27 16:57:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-27 16:57:21 --> Pagination Class Initialized
INFO - 2018-02-27 16:57:21 --> Helper loaded: form_helper
INFO - 2018-02-27 16:57:21 --> Form Validation Class Initialized
INFO - 2018-02-27 16:57:21 --> Model Class Initialized
INFO - 2018-02-27 16:57:21 --> Controller Class Initialized
DEBUG - 2018-02-27 16:57:21 --> Config file loaded: /var/www/html/project/periodtracker/application/config/rest.php
INFO - 2018-02-27 16:57:21 --> Helper loaded: inflector_helper
INFO - 2018-02-27 16:57:21 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-27 16:57:21 --> Model Class Initialized
INFO - 2018-02-27 16:57:21 --> Model Class Initialized
INFO - 2018-02-27 16:57:21 --> Model Class Initialized
INFO - 2018-02-27 16:57:21 --> Final output sent to browser
DEBUG - 2018-02-27 16:57:21 --> Total execution time: 0.0438
INFO - 2018-02-27 16:58:44 --> Config Class Initialized
INFO - 2018-02-27 16:58:44 --> Hooks Class Initialized
DEBUG - 2018-02-27 16:58:44 --> UTF-8 Support Enabled
INFO - 2018-02-27 16:58:44 --> Utf8 Class Initialized
INFO - 2018-02-27 16:58:44 --> URI Class Initialized
INFO - 2018-02-27 16:58:44 --> Router Class Initialized
INFO - 2018-02-27 16:58:44 --> Output Class Initialized
INFO - 2018-02-27 16:58:44 --> Security Class Initialized
DEBUG - 2018-02-27 16:58:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-27 16:58:44 --> Input Class Initialized
INFO - 2018-02-27 16:58:44 --> Language Class Initialized
INFO - 2018-02-27 16:58:44 --> Loader Class Initialized
INFO - 2018-02-27 16:58:44 --> Helper loaded: url_helper
INFO - 2018-02-27 16:58:44 --> Helper loaded: file_helper
INFO - 2018-02-27 16:58:44 --> Helper loaded: email_helper
INFO - 2018-02-27 16:58:44 --> Helper loaded: common_helper
INFO - 2018-02-27 16:58:44 --> Database Driver Class Initialized
DEBUG - 2018-02-27 16:58:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-27 16:58:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-27 16:58:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-27 16:58:44 --> Pagination Class Initialized
INFO - 2018-02-27 16:58:44 --> Helper loaded: form_helper
INFO - 2018-02-27 16:58:44 --> Form Validation Class Initialized
INFO - 2018-02-27 16:58:44 --> Model Class Initialized
INFO - 2018-02-27 16:58:44 --> Controller Class Initialized
DEBUG - 2018-02-27 16:58:44 --> Config file loaded: /var/www/html/project/periodtracker/application/config/rest.php
INFO - 2018-02-27 16:58:44 --> Helper loaded: inflector_helper
INFO - 2018-02-27 16:58:44 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-27 16:58:44 --> Model Class Initialized
INFO - 2018-02-27 16:58:44 --> Model Class Initialized
INFO - 2018-02-27 16:58:44 --> Model Class Initialized
INFO - 2018-02-27 17:00:06 --> Config Class Initialized
INFO - 2018-02-27 17:00:06 --> Hooks Class Initialized
DEBUG - 2018-02-27 17:00:06 --> UTF-8 Support Enabled
INFO - 2018-02-27 17:00:06 --> Utf8 Class Initialized
INFO - 2018-02-27 17:00:06 --> URI Class Initialized
INFO - 2018-02-27 17:00:06 --> Router Class Initialized
INFO - 2018-02-27 17:00:06 --> Output Class Initialized
INFO - 2018-02-27 17:00:06 --> Security Class Initialized
DEBUG - 2018-02-27 17:00:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-27 17:00:06 --> Input Class Initialized
INFO - 2018-02-27 17:00:06 --> Language Class Initialized
INFO - 2018-02-27 17:00:06 --> Loader Class Initialized
INFO - 2018-02-27 17:00:06 --> Helper loaded: url_helper
INFO - 2018-02-27 17:00:06 --> Helper loaded: file_helper
INFO - 2018-02-27 17:00:06 --> Helper loaded: email_helper
INFO - 2018-02-27 17:00:06 --> Helper loaded: common_helper
INFO - 2018-02-27 17:00:06 --> Database Driver Class Initialized
DEBUG - 2018-02-27 17:00:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-27 17:00:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-27 17:00:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-27 17:00:06 --> Pagination Class Initialized
INFO - 2018-02-27 17:00:06 --> Helper loaded: form_helper
INFO - 2018-02-27 17:00:06 --> Form Validation Class Initialized
INFO - 2018-02-27 17:00:06 --> Model Class Initialized
INFO - 2018-02-27 17:00:06 --> Controller Class Initialized
DEBUG - 2018-02-27 17:00:06 --> Config file loaded: /var/www/html/project/periodtracker/application/config/rest.php
INFO - 2018-02-27 17:00:06 --> Helper loaded: inflector_helper
INFO - 2018-02-27 17:00:06 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-27 17:00:06 --> Model Class Initialized
INFO - 2018-02-27 17:00:06 --> Model Class Initialized
INFO - 2018-02-27 17:00:06 --> Model Class Initialized
INFO - 2018-02-27 17:12:08 --> Config Class Initialized
INFO - 2018-02-27 17:12:08 --> Hooks Class Initialized
DEBUG - 2018-02-27 17:12:08 --> UTF-8 Support Enabled
INFO - 2018-02-27 17:12:08 --> Utf8 Class Initialized
INFO - 2018-02-27 17:12:08 --> URI Class Initialized
INFO - 2018-02-27 17:12:08 --> Router Class Initialized
INFO - 2018-02-27 17:12:08 --> Output Class Initialized
INFO - 2018-02-27 17:12:08 --> Security Class Initialized
DEBUG - 2018-02-27 17:12:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-27 17:12:08 --> Input Class Initialized
INFO - 2018-02-27 17:12:08 --> Language Class Initialized
INFO - 2018-02-27 17:12:08 --> Loader Class Initialized
INFO - 2018-02-27 17:12:08 --> Helper loaded: url_helper
INFO - 2018-02-27 17:12:08 --> Helper loaded: file_helper
INFO - 2018-02-27 17:12:08 --> Helper loaded: email_helper
INFO - 2018-02-27 17:12:08 --> Helper loaded: common_helper
INFO - 2018-02-27 17:12:08 --> Database Driver Class Initialized
DEBUG - 2018-02-27 17:12:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-27 17:12:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-27 17:12:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-27 17:12:08 --> Pagination Class Initialized
INFO - 2018-02-27 17:12:08 --> Helper loaded: form_helper
INFO - 2018-02-27 17:12:08 --> Form Validation Class Initialized
INFO - 2018-02-27 17:12:08 --> Model Class Initialized
INFO - 2018-02-27 17:12:08 --> Controller Class Initialized
DEBUG - 2018-02-27 17:12:08 --> Config file loaded: /var/www/html/project/periodtracker/application/config/rest.php
INFO - 2018-02-27 17:12:08 --> Helper loaded: inflector_helper
INFO - 2018-02-27 17:12:08 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-27 17:12:08 --> Model Class Initialized
INFO - 2018-02-27 17:12:08 --> Model Class Initialized
INFO - 2018-02-27 17:12:08 --> Model Class Initialized
INFO - 2018-02-27 17:12:35 --> Config Class Initialized
INFO - 2018-02-27 17:12:35 --> Hooks Class Initialized
DEBUG - 2018-02-27 17:12:35 --> UTF-8 Support Enabled
INFO - 2018-02-27 17:12:35 --> Utf8 Class Initialized
INFO - 2018-02-27 17:12:35 --> URI Class Initialized
INFO - 2018-02-27 17:12:35 --> Router Class Initialized
INFO - 2018-02-27 17:12:35 --> Output Class Initialized
INFO - 2018-02-27 17:12:35 --> Security Class Initialized
DEBUG - 2018-02-27 17:12:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-27 17:12:35 --> Input Class Initialized
INFO - 2018-02-27 17:12:35 --> Language Class Initialized
INFO - 2018-02-27 17:12:35 --> Loader Class Initialized
INFO - 2018-02-27 17:12:35 --> Helper loaded: url_helper
INFO - 2018-02-27 17:12:35 --> Helper loaded: file_helper
INFO - 2018-02-27 17:12:35 --> Helper loaded: email_helper
INFO - 2018-02-27 17:12:35 --> Helper loaded: common_helper
INFO - 2018-02-27 17:12:35 --> Database Driver Class Initialized
DEBUG - 2018-02-27 17:12:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-27 17:12:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-27 17:12:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-27 17:12:35 --> Pagination Class Initialized
INFO - 2018-02-27 17:12:35 --> Helper loaded: form_helper
INFO - 2018-02-27 17:12:35 --> Form Validation Class Initialized
INFO - 2018-02-27 17:12:35 --> Model Class Initialized
INFO - 2018-02-27 17:12:35 --> Controller Class Initialized
DEBUG - 2018-02-27 17:12:35 --> Config file loaded: /var/www/html/project/periodtracker/application/config/rest.php
INFO - 2018-02-27 17:12:35 --> Helper loaded: inflector_helper
INFO - 2018-02-27 17:12:35 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-27 17:12:35 --> Model Class Initialized
INFO - 2018-02-27 17:12:35 --> Model Class Initialized
INFO - 2018-02-27 17:12:35 --> Model Class Initialized
INFO - 2018-02-27 17:12:35 --> Final output sent to browser
DEBUG - 2018-02-27 17:12:35 --> Total execution time: 0.0067
INFO - 2018-02-27 17:16:17 --> Config Class Initialized
INFO - 2018-02-27 17:16:17 --> Hooks Class Initialized
DEBUG - 2018-02-27 17:16:17 --> UTF-8 Support Enabled
INFO - 2018-02-27 17:16:17 --> Utf8 Class Initialized
INFO - 2018-02-27 17:16:17 --> URI Class Initialized
INFO - 2018-02-27 17:16:17 --> Router Class Initialized
INFO - 2018-02-27 17:16:17 --> Output Class Initialized
INFO - 2018-02-27 17:16:17 --> Security Class Initialized
DEBUG - 2018-02-27 17:16:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-27 17:16:17 --> Input Class Initialized
INFO - 2018-02-27 17:16:17 --> Language Class Initialized
INFO - 2018-02-27 17:16:17 --> Loader Class Initialized
INFO - 2018-02-27 17:16:17 --> Helper loaded: url_helper
INFO - 2018-02-27 17:16:17 --> Helper loaded: file_helper
INFO - 2018-02-27 17:16:17 --> Helper loaded: email_helper
INFO - 2018-02-27 17:16:17 --> Helper loaded: common_helper
INFO - 2018-02-27 17:16:17 --> Database Driver Class Initialized
DEBUG - 2018-02-27 17:16:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-27 17:16:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-27 17:16:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-27 17:16:17 --> Pagination Class Initialized
INFO - 2018-02-27 17:16:17 --> Helper loaded: form_helper
INFO - 2018-02-27 17:16:17 --> Form Validation Class Initialized
INFO - 2018-02-27 17:16:17 --> Model Class Initialized
INFO - 2018-02-27 17:16:17 --> Controller Class Initialized
DEBUG - 2018-02-27 17:16:17 --> Config file loaded: /var/www/html/project/periodtracker/application/config/rest.php
INFO - 2018-02-27 17:16:17 --> Helper loaded: inflector_helper
INFO - 2018-02-27 17:16:17 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-27 17:16:17 --> Model Class Initialized
INFO - 2018-02-27 17:16:17 --> Model Class Initialized
INFO - 2018-02-27 17:16:17 --> Model Class Initialized
INFO - 2018-02-27 17:16:17 --> Final output sent to browser
DEBUG - 2018-02-27 17:16:17 --> Total execution time: 0.0645
INFO - 2018-02-27 17:16:48 --> Config Class Initialized
INFO - 2018-02-27 17:16:48 --> Hooks Class Initialized
DEBUG - 2018-02-27 17:16:48 --> UTF-8 Support Enabled
INFO - 2018-02-27 17:16:48 --> Utf8 Class Initialized
INFO - 2018-02-27 17:16:48 --> URI Class Initialized
INFO - 2018-02-27 17:16:48 --> Router Class Initialized
INFO - 2018-02-27 17:16:48 --> Output Class Initialized
INFO - 2018-02-27 17:16:48 --> Security Class Initialized
DEBUG - 2018-02-27 17:16:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-27 17:16:48 --> Input Class Initialized
INFO - 2018-02-27 17:16:48 --> Language Class Initialized
INFO - 2018-02-27 17:16:48 --> Loader Class Initialized
INFO - 2018-02-27 17:16:48 --> Helper loaded: url_helper
INFO - 2018-02-27 17:16:48 --> Helper loaded: file_helper
INFO - 2018-02-27 17:16:48 --> Helper loaded: email_helper
INFO - 2018-02-27 17:16:48 --> Helper loaded: common_helper
INFO - 2018-02-27 17:16:48 --> Database Driver Class Initialized
DEBUG - 2018-02-27 17:16:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-27 17:16:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-27 17:16:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-27 17:16:48 --> Pagination Class Initialized
INFO - 2018-02-27 17:16:48 --> Helper loaded: form_helper
INFO - 2018-02-27 17:16:48 --> Form Validation Class Initialized
INFO - 2018-02-27 17:16:48 --> Model Class Initialized
INFO - 2018-02-27 17:16:48 --> Controller Class Initialized
DEBUG - 2018-02-27 17:16:48 --> Config file loaded: /var/www/html/project/periodtracker/application/config/rest.php
INFO - 2018-02-27 17:16:48 --> Helper loaded: inflector_helper
INFO - 2018-02-27 17:16:48 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-27 17:16:48 --> Model Class Initialized
INFO - 2018-02-27 17:16:48 --> Model Class Initialized
INFO - 2018-02-27 17:16:48 --> Model Class Initialized
INFO - 2018-02-27 17:16:48 --> Final output sent to browser
DEBUG - 2018-02-27 17:16:48 --> Total execution time: 0.0370
INFO - 2018-02-27 17:19:11 --> Config Class Initialized
INFO - 2018-02-27 17:19:11 --> Hooks Class Initialized
DEBUG - 2018-02-27 17:19:11 --> UTF-8 Support Enabled
INFO - 2018-02-27 17:19:11 --> Utf8 Class Initialized
INFO - 2018-02-27 17:19:11 --> URI Class Initialized
INFO - 2018-02-27 17:19:11 --> Router Class Initialized
INFO - 2018-02-27 17:19:11 --> Output Class Initialized
INFO - 2018-02-27 17:19:11 --> Security Class Initialized
DEBUG - 2018-02-27 17:19:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-27 17:19:11 --> Input Class Initialized
INFO - 2018-02-27 17:19:11 --> Language Class Initialized
INFO - 2018-02-27 17:19:11 --> Loader Class Initialized
INFO - 2018-02-27 17:19:11 --> Helper loaded: url_helper
INFO - 2018-02-27 17:19:11 --> Helper loaded: file_helper
INFO - 2018-02-27 17:19:11 --> Helper loaded: email_helper
INFO - 2018-02-27 17:19:11 --> Helper loaded: common_helper
INFO - 2018-02-27 17:19:11 --> Database Driver Class Initialized
DEBUG - 2018-02-27 17:19:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-27 17:19:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-27 17:19:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-27 17:19:11 --> Pagination Class Initialized
INFO - 2018-02-27 17:19:11 --> Helper loaded: form_helper
INFO - 2018-02-27 17:19:11 --> Form Validation Class Initialized
INFO - 2018-02-27 17:19:11 --> Model Class Initialized
INFO - 2018-02-27 17:19:11 --> Controller Class Initialized
DEBUG - 2018-02-27 17:19:11 --> Config file loaded: /var/www/html/project/periodtracker/application/config/rest.php
INFO - 2018-02-27 17:19:11 --> Helper loaded: inflector_helper
INFO - 2018-02-27 17:19:11 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-27 17:19:11 --> Model Class Initialized
INFO - 2018-02-27 17:19:11 --> Model Class Initialized
INFO - 2018-02-27 17:19:11 --> Model Class Initialized
INFO - 2018-02-27 17:19:11 --> Final output sent to browser
DEBUG - 2018-02-27 17:19:11 --> Total execution time: 0.0044
INFO - 2018-02-27 17:19:46 --> Config Class Initialized
INFO - 2018-02-27 17:19:46 --> Hooks Class Initialized
DEBUG - 2018-02-27 17:19:46 --> UTF-8 Support Enabled
INFO - 2018-02-27 17:19:46 --> Utf8 Class Initialized
INFO - 2018-02-27 17:19:46 --> URI Class Initialized
INFO - 2018-02-27 17:19:46 --> Router Class Initialized
INFO - 2018-02-27 17:19:46 --> Output Class Initialized
INFO - 2018-02-27 17:19:46 --> Security Class Initialized
DEBUG - 2018-02-27 17:19:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-27 17:19:46 --> Input Class Initialized
INFO - 2018-02-27 17:19:46 --> Language Class Initialized
INFO - 2018-02-27 17:19:46 --> Loader Class Initialized
INFO - 2018-02-27 17:19:46 --> Helper loaded: url_helper
INFO - 2018-02-27 17:19:46 --> Helper loaded: file_helper
INFO - 2018-02-27 17:19:46 --> Helper loaded: email_helper
INFO - 2018-02-27 17:19:46 --> Helper loaded: common_helper
INFO - 2018-02-27 17:19:46 --> Database Driver Class Initialized
DEBUG - 2018-02-27 17:19:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-27 17:19:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-27 17:19:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-27 17:19:46 --> Pagination Class Initialized
INFO - 2018-02-27 17:19:46 --> Helper loaded: form_helper
INFO - 2018-02-27 17:19:46 --> Form Validation Class Initialized
INFO - 2018-02-27 17:19:46 --> Model Class Initialized
INFO - 2018-02-27 17:19:46 --> Controller Class Initialized
DEBUG - 2018-02-27 17:19:46 --> Config file loaded: /var/www/html/project/periodtracker/application/config/rest.php
INFO - 2018-02-27 17:19:46 --> Helper loaded: inflector_helper
INFO - 2018-02-27 17:19:46 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-27 17:19:46 --> Model Class Initialized
INFO - 2018-02-27 17:19:46 --> Model Class Initialized
INFO - 2018-02-27 17:19:46 --> Model Class Initialized
INFO - 2018-02-27 17:19:46 --> Final output sent to browser
DEBUG - 2018-02-27 17:19:46 --> Total execution time: 0.0041
INFO - 2018-02-27 17:19:51 --> Config Class Initialized
INFO - 2018-02-27 17:19:51 --> Hooks Class Initialized
DEBUG - 2018-02-27 17:19:51 --> UTF-8 Support Enabled
INFO - 2018-02-27 17:19:51 --> Utf8 Class Initialized
INFO - 2018-02-27 17:19:51 --> URI Class Initialized
INFO - 2018-02-27 17:19:51 --> Router Class Initialized
INFO - 2018-02-27 17:19:51 --> Output Class Initialized
INFO - 2018-02-27 17:19:51 --> Security Class Initialized
DEBUG - 2018-02-27 17:19:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-27 17:19:51 --> Input Class Initialized
INFO - 2018-02-27 17:19:51 --> Language Class Initialized
INFO - 2018-02-27 17:19:51 --> Loader Class Initialized
INFO - 2018-02-27 17:19:51 --> Helper loaded: url_helper
INFO - 2018-02-27 17:19:51 --> Helper loaded: file_helper
INFO - 2018-02-27 17:19:51 --> Helper loaded: email_helper
INFO - 2018-02-27 17:19:51 --> Helper loaded: common_helper
INFO - 2018-02-27 17:19:51 --> Database Driver Class Initialized
DEBUG - 2018-02-27 17:19:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-27 17:19:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-27 17:19:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-27 17:19:51 --> Pagination Class Initialized
INFO - 2018-02-27 17:19:51 --> Helper loaded: form_helper
INFO - 2018-02-27 17:19:51 --> Form Validation Class Initialized
INFO - 2018-02-27 17:19:51 --> Model Class Initialized
INFO - 2018-02-27 17:19:51 --> Controller Class Initialized
DEBUG - 2018-02-27 17:19:51 --> Config file loaded: /var/www/html/project/periodtracker/application/config/rest.php
INFO - 2018-02-27 17:19:51 --> Helper loaded: inflector_helper
INFO - 2018-02-27 17:19:51 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-27 17:19:51 --> Model Class Initialized
INFO - 2018-02-27 17:19:51 --> Model Class Initialized
INFO - 2018-02-27 17:19:51 --> Model Class Initialized
INFO - 2018-02-27 17:19:51 --> Final output sent to browser
DEBUG - 2018-02-27 17:19:51 --> Total execution time: 0.0055
INFO - 2018-02-27 17:20:02 --> Config Class Initialized
INFO - 2018-02-27 17:20:02 --> Hooks Class Initialized
DEBUG - 2018-02-27 17:20:02 --> UTF-8 Support Enabled
INFO - 2018-02-27 17:20:02 --> Utf8 Class Initialized
INFO - 2018-02-27 17:20:02 --> URI Class Initialized
INFO - 2018-02-27 17:20:02 --> Router Class Initialized
INFO - 2018-02-27 17:20:02 --> Output Class Initialized
INFO - 2018-02-27 17:20:02 --> Security Class Initialized
DEBUG - 2018-02-27 17:20:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-27 17:20:02 --> Input Class Initialized
INFO - 2018-02-27 17:20:02 --> Language Class Initialized
INFO - 2018-02-27 17:20:02 --> Loader Class Initialized
INFO - 2018-02-27 17:20:02 --> Helper loaded: url_helper
INFO - 2018-02-27 17:20:02 --> Helper loaded: file_helper
INFO - 2018-02-27 17:20:02 --> Helper loaded: email_helper
INFO - 2018-02-27 17:20:02 --> Helper loaded: common_helper
INFO - 2018-02-27 17:20:02 --> Database Driver Class Initialized
DEBUG - 2018-02-27 17:20:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-27 17:20:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-27 17:20:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-27 17:20:02 --> Pagination Class Initialized
INFO - 2018-02-27 17:20:02 --> Helper loaded: form_helper
INFO - 2018-02-27 17:20:02 --> Form Validation Class Initialized
INFO - 2018-02-27 17:20:02 --> Model Class Initialized
INFO - 2018-02-27 17:20:02 --> Controller Class Initialized
DEBUG - 2018-02-27 17:20:02 --> Config file loaded: /var/www/html/project/periodtracker/application/config/rest.php
INFO - 2018-02-27 17:20:02 --> Helper loaded: inflector_helper
INFO - 2018-02-27 17:20:02 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-27 17:20:02 --> Model Class Initialized
INFO - 2018-02-27 17:20:02 --> Model Class Initialized
INFO - 2018-02-27 17:20:02 --> Model Class Initialized
INFO - 2018-02-27 17:20:02 --> Final output sent to browser
DEBUG - 2018-02-27 17:20:02 --> Total execution time: 0.0046
INFO - 2018-02-27 17:21:17 --> Config Class Initialized
INFO - 2018-02-27 17:21:17 --> Hooks Class Initialized
DEBUG - 2018-02-27 17:21:17 --> UTF-8 Support Enabled
INFO - 2018-02-27 17:21:17 --> Utf8 Class Initialized
INFO - 2018-02-27 17:21:17 --> URI Class Initialized
INFO - 2018-02-27 17:21:17 --> Router Class Initialized
INFO - 2018-02-27 17:21:17 --> Output Class Initialized
INFO - 2018-02-27 17:21:17 --> Security Class Initialized
DEBUG - 2018-02-27 17:21:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-27 17:21:17 --> Input Class Initialized
INFO - 2018-02-27 17:21:17 --> Language Class Initialized
INFO - 2018-02-27 17:21:17 --> Loader Class Initialized
INFO - 2018-02-27 17:21:17 --> Helper loaded: url_helper
INFO - 2018-02-27 17:21:17 --> Helper loaded: file_helper
INFO - 2018-02-27 17:21:17 --> Helper loaded: email_helper
INFO - 2018-02-27 17:21:17 --> Helper loaded: common_helper
INFO - 2018-02-27 17:21:17 --> Database Driver Class Initialized
DEBUG - 2018-02-27 17:21:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-27 17:21:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-27 17:21:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-27 17:21:17 --> Pagination Class Initialized
INFO - 2018-02-27 17:21:17 --> Helper loaded: form_helper
INFO - 2018-02-27 17:21:17 --> Form Validation Class Initialized
INFO - 2018-02-27 17:21:17 --> Model Class Initialized
INFO - 2018-02-27 17:21:17 --> Controller Class Initialized
DEBUG - 2018-02-27 17:21:17 --> Config file loaded: /var/www/html/project/periodtracker/application/config/rest.php
INFO - 2018-02-27 17:21:17 --> Helper loaded: inflector_helper
INFO - 2018-02-27 17:21:17 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-27 17:21:17 --> Model Class Initialized
INFO - 2018-02-27 17:21:17 --> Model Class Initialized
INFO - 2018-02-27 17:21:17 --> Model Class Initialized
INFO - 2018-02-27 17:21:17 --> Final output sent to browser
DEBUG - 2018-02-27 17:21:17 --> Total execution time: 0.0711
INFO - 2018-02-27 17:22:12 --> Config Class Initialized
INFO - 2018-02-27 17:22:12 --> Hooks Class Initialized
DEBUG - 2018-02-27 17:22:12 --> UTF-8 Support Enabled
INFO - 2018-02-27 17:22:12 --> Utf8 Class Initialized
INFO - 2018-02-27 17:22:12 --> URI Class Initialized
INFO - 2018-02-27 17:22:12 --> Router Class Initialized
INFO - 2018-02-27 17:22:12 --> Output Class Initialized
INFO - 2018-02-27 17:22:12 --> Security Class Initialized
DEBUG - 2018-02-27 17:22:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-27 17:22:12 --> Input Class Initialized
INFO - 2018-02-27 17:22:12 --> Language Class Initialized
INFO - 2018-02-27 17:22:12 --> Loader Class Initialized
INFO - 2018-02-27 17:22:12 --> Helper loaded: url_helper
INFO - 2018-02-27 17:22:12 --> Helper loaded: file_helper
INFO - 2018-02-27 17:22:12 --> Helper loaded: email_helper
INFO - 2018-02-27 17:22:12 --> Helper loaded: common_helper
INFO - 2018-02-27 17:22:12 --> Database Driver Class Initialized
DEBUG - 2018-02-27 17:22:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-27 17:22:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-27 17:22:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-27 17:22:12 --> Pagination Class Initialized
INFO - 2018-02-27 17:22:12 --> Helper loaded: form_helper
INFO - 2018-02-27 17:22:12 --> Form Validation Class Initialized
INFO - 2018-02-27 17:22:12 --> Model Class Initialized
INFO - 2018-02-27 17:22:12 --> Controller Class Initialized
DEBUG - 2018-02-27 17:22:12 --> Config file loaded: /var/www/html/project/periodtracker/application/config/rest.php
INFO - 2018-02-27 17:22:12 --> Helper loaded: inflector_helper
INFO - 2018-02-27 17:22:12 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-27 17:22:12 --> Model Class Initialized
INFO - 2018-02-27 17:22:12 --> Model Class Initialized
INFO - 2018-02-27 17:22:12 --> Model Class Initialized
INFO - 2018-02-27 17:22:12 --> Final output sent to browser
DEBUG - 2018-02-27 17:22:12 --> Total execution time: 0.0443
INFO - 2018-02-27 17:22:17 --> Config Class Initialized
INFO - 2018-02-27 17:22:17 --> Hooks Class Initialized
DEBUG - 2018-02-27 17:22:17 --> UTF-8 Support Enabled
INFO - 2018-02-27 17:22:17 --> Utf8 Class Initialized
INFO - 2018-02-27 17:22:17 --> URI Class Initialized
INFO - 2018-02-27 17:22:17 --> Router Class Initialized
INFO - 2018-02-27 17:22:17 --> Output Class Initialized
INFO - 2018-02-27 17:22:17 --> Security Class Initialized
DEBUG - 2018-02-27 17:22:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-27 17:22:17 --> Input Class Initialized
INFO - 2018-02-27 17:22:17 --> Language Class Initialized
INFO - 2018-02-27 17:22:17 --> Loader Class Initialized
INFO - 2018-02-27 17:22:17 --> Helper loaded: url_helper
INFO - 2018-02-27 17:22:17 --> Helper loaded: file_helper
INFO - 2018-02-27 17:22:17 --> Helper loaded: email_helper
INFO - 2018-02-27 17:22:17 --> Helper loaded: common_helper
INFO - 2018-02-27 17:22:17 --> Database Driver Class Initialized
DEBUG - 2018-02-27 17:22:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-27 17:22:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-27 17:22:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-27 17:22:17 --> Pagination Class Initialized
INFO - 2018-02-27 17:22:17 --> Helper loaded: form_helper
INFO - 2018-02-27 17:22:17 --> Form Validation Class Initialized
INFO - 2018-02-27 17:22:17 --> Model Class Initialized
INFO - 2018-02-27 17:22:17 --> Controller Class Initialized
DEBUG - 2018-02-27 17:22:17 --> Config file loaded: /var/www/html/project/periodtracker/application/config/rest.php
INFO - 2018-02-27 17:22:17 --> Helper loaded: inflector_helper
INFO - 2018-02-27 17:22:17 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-27 17:22:17 --> Model Class Initialized
INFO - 2018-02-27 17:22:17 --> Model Class Initialized
INFO - 2018-02-27 17:22:17 --> Model Class Initialized
INFO - 2018-02-27 17:22:17 --> Final output sent to browser
DEBUG - 2018-02-27 17:22:17 --> Total execution time: 0.0459
INFO - 2018-02-27 17:28:40 --> Config Class Initialized
INFO - 2018-02-27 17:28:40 --> Hooks Class Initialized
DEBUG - 2018-02-27 17:28:40 --> UTF-8 Support Enabled
INFO - 2018-02-27 17:28:40 --> Utf8 Class Initialized
INFO - 2018-02-27 17:28:40 --> URI Class Initialized
INFO - 2018-02-27 17:28:40 --> Router Class Initialized
INFO - 2018-02-27 17:28:40 --> Output Class Initialized
INFO - 2018-02-27 17:28:40 --> Security Class Initialized
DEBUG - 2018-02-27 17:28:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-27 17:28:40 --> Input Class Initialized
INFO - 2018-02-27 17:28:40 --> Language Class Initialized
INFO - 2018-02-27 17:28:40 --> Loader Class Initialized
INFO - 2018-02-27 17:28:40 --> Helper loaded: url_helper
INFO - 2018-02-27 17:28:40 --> Helper loaded: file_helper
INFO - 2018-02-27 17:28:40 --> Helper loaded: email_helper
INFO - 2018-02-27 17:28:40 --> Helper loaded: common_helper
INFO - 2018-02-27 17:28:40 --> Database Driver Class Initialized
DEBUG - 2018-02-27 17:28:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-27 17:28:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-27 17:28:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-27 17:28:40 --> Pagination Class Initialized
INFO - 2018-02-27 17:28:40 --> Helper loaded: form_helper
INFO - 2018-02-27 17:28:40 --> Form Validation Class Initialized
INFO - 2018-02-27 17:28:40 --> Model Class Initialized
INFO - 2018-02-27 17:28:40 --> Controller Class Initialized
DEBUG - 2018-02-27 17:28:40 --> Config file loaded: /var/www/html/project/periodtracker/application/config/rest.php
INFO - 2018-02-27 17:28:40 --> Helper loaded: inflector_helper
INFO - 2018-02-27 17:28:40 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-27 17:28:40 --> Model Class Initialized
INFO - 2018-02-27 17:28:40 --> Model Class Initialized
INFO - 2018-02-27 17:28:40 --> Model Class Initialized
INFO - 2018-02-27 17:28:40 --> Final output sent to browser
DEBUG - 2018-02-27 17:28:40 --> Total execution time: 0.0053
INFO - 2018-02-27 17:28:46 --> Config Class Initialized
INFO - 2018-02-27 17:28:46 --> Hooks Class Initialized
DEBUG - 2018-02-27 17:28:46 --> UTF-8 Support Enabled
INFO - 2018-02-27 17:28:46 --> Utf8 Class Initialized
INFO - 2018-02-27 17:28:46 --> URI Class Initialized
INFO - 2018-02-27 17:28:46 --> Router Class Initialized
INFO - 2018-02-27 17:28:46 --> Output Class Initialized
INFO - 2018-02-27 17:28:46 --> Security Class Initialized
DEBUG - 2018-02-27 17:28:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-27 17:28:46 --> Input Class Initialized
INFO - 2018-02-27 17:28:46 --> Language Class Initialized
INFO - 2018-02-27 17:28:46 --> Loader Class Initialized
INFO - 2018-02-27 17:28:46 --> Helper loaded: url_helper
INFO - 2018-02-27 17:28:46 --> Helper loaded: file_helper
INFO - 2018-02-27 17:28:46 --> Helper loaded: email_helper
INFO - 2018-02-27 17:28:46 --> Helper loaded: common_helper
INFO - 2018-02-27 17:28:46 --> Database Driver Class Initialized
DEBUG - 2018-02-27 17:28:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-27 17:28:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-27 17:28:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-27 17:28:46 --> Pagination Class Initialized
INFO - 2018-02-27 17:28:46 --> Helper loaded: form_helper
INFO - 2018-02-27 17:28:46 --> Form Validation Class Initialized
INFO - 2018-02-27 17:28:46 --> Model Class Initialized
INFO - 2018-02-27 17:28:46 --> Controller Class Initialized
DEBUG - 2018-02-27 17:28:46 --> Config file loaded: /var/www/html/project/periodtracker/application/config/rest.php
INFO - 2018-02-27 17:28:46 --> Helper loaded: inflector_helper
INFO - 2018-02-27 17:28:46 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-27 17:28:46 --> Model Class Initialized
INFO - 2018-02-27 17:28:46 --> Model Class Initialized
INFO - 2018-02-27 17:28:46 --> Model Class Initialized
INFO - 2018-02-27 17:28:46 --> Final output sent to browser
DEBUG - 2018-02-27 17:28:46 --> Total execution time: 0.0053
INFO - 2018-02-27 17:29:07 --> Config Class Initialized
INFO - 2018-02-27 17:29:07 --> Hooks Class Initialized
DEBUG - 2018-02-27 17:29:07 --> UTF-8 Support Enabled
INFO - 2018-02-27 17:29:07 --> Utf8 Class Initialized
INFO - 2018-02-27 17:29:07 --> URI Class Initialized
INFO - 2018-02-27 17:29:07 --> Router Class Initialized
INFO - 2018-02-27 17:29:07 --> Output Class Initialized
INFO - 2018-02-27 17:29:07 --> Security Class Initialized
DEBUG - 2018-02-27 17:29:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-27 17:29:07 --> Input Class Initialized
INFO - 2018-02-27 17:29:07 --> Language Class Initialized
INFO - 2018-02-27 17:29:07 --> Loader Class Initialized
INFO - 2018-02-27 17:29:07 --> Helper loaded: url_helper
INFO - 2018-02-27 17:29:07 --> Helper loaded: file_helper
INFO - 2018-02-27 17:29:07 --> Helper loaded: email_helper
INFO - 2018-02-27 17:29:07 --> Helper loaded: common_helper
INFO - 2018-02-27 17:29:07 --> Database Driver Class Initialized
DEBUG - 2018-02-27 17:29:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-27 17:29:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-27 17:29:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-27 17:29:07 --> Pagination Class Initialized
INFO - 2018-02-27 17:29:07 --> Helper loaded: form_helper
INFO - 2018-02-27 17:29:07 --> Form Validation Class Initialized
INFO - 2018-02-27 17:29:07 --> Model Class Initialized
INFO - 2018-02-27 17:29:07 --> Controller Class Initialized
DEBUG - 2018-02-27 17:29:07 --> Config file loaded: /var/www/html/project/periodtracker/application/config/rest.php
INFO - 2018-02-27 17:29:07 --> Helper loaded: inflector_helper
INFO - 2018-02-27 17:29:07 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-27 17:29:07 --> Model Class Initialized
INFO - 2018-02-27 17:29:07 --> Model Class Initialized
INFO - 2018-02-27 17:29:07 --> Model Class Initialized
INFO - 2018-02-27 17:29:07 --> Final output sent to browser
DEBUG - 2018-02-27 17:29:07 --> Total execution time: 0.0045
INFO - 2018-02-27 17:29:13 --> Config Class Initialized
INFO - 2018-02-27 17:29:13 --> Hooks Class Initialized
DEBUG - 2018-02-27 17:29:13 --> UTF-8 Support Enabled
INFO - 2018-02-27 17:29:13 --> Utf8 Class Initialized
INFO - 2018-02-27 17:29:13 --> URI Class Initialized
INFO - 2018-02-27 17:29:13 --> Router Class Initialized
INFO - 2018-02-27 17:29:13 --> Output Class Initialized
INFO - 2018-02-27 17:29:13 --> Security Class Initialized
DEBUG - 2018-02-27 17:29:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-27 17:29:13 --> Input Class Initialized
INFO - 2018-02-27 17:29:13 --> Language Class Initialized
INFO - 2018-02-27 17:29:13 --> Loader Class Initialized
INFO - 2018-02-27 17:29:13 --> Helper loaded: url_helper
INFO - 2018-02-27 17:29:13 --> Helper loaded: file_helper
INFO - 2018-02-27 17:29:13 --> Helper loaded: email_helper
INFO - 2018-02-27 17:29:13 --> Helper loaded: common_helper
INFO - 2018-02-27 17:29:13 --> Database Driver Class Initialized
DEBUG - 2018-02-27 17:29:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-27 17:29:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-27 17:29:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-27 17:29:13 --> Pagination Class Initialized
INFO - 2018-02-27 17:29:13 --> Helper loaded: form_helper
INFO - 2018-02-27 17:29:13 --> Form Validation Class Initialized
INFO - 2018-02-27 17:29:13 --> Model Class Initialized
INFO - 2018-02-27 17:29:13 --> Controller Class Initialized
DEBUG - 2018-02-27 17:29:13 --> Config file loaded: /var/www/html/project/periodtracker/application/config/rest.php
INFO - 2018-02-27 17:29:13 --> Helper loaded: inflector_helper
INFO - 2018-02-27 17:29:13 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-27 17:29:13 --> Model Class Initialized
INFO - 2018-02-27 17:29:13 --> Model Class Initialized
INFO - 2018-02-27 17:29:13 --> Model Class Initialized
INFO - 2018-02-27 17:29:13 --> Final output sent to browser
DEBUG - 2018-02-27 17:29:13 --> Total execution time: 0.0064
INFO - 2018-02-27 17:29:16 --> Config Class Initialized
INFO - 2018-02-27 17:29:16 --> Hooks Class Initialized
DEBUG - 2018-02-27 17:29:16 --> UTF-8 Support Enabled
INFO - 2018-02-27 17:29:16 --> Utf8 Class Initialized
INFO - 2018-02-27 17:29:16 --> URI Class Initialized
INFO - 2018-02-27 17:29:16 --> Router Class Initialized
INFO - 2018-02-27 17:29:16 --> Output Class Initialized
INFO - 2018-02-27 17:29:16 --> Security Class Initialized
DEBUG - 2018-02-27 17:29:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-27 17:29:16 --> Input Class Initialized
INFO - 2018-02-27 17:29:16 --> Language Class Initialized
INFO - 2018-02-27 17:29:16 --> Loader Class Initialized
INFO - 2018-02-27 17:29:16 --> Helper loaded: url_helper
INFO - 2018-02-27 17:29:16 --> Helper loaded: file_helper
INFO - 2018-02-27 17:29:16 --> Helper loaded: email_helper
INFO - 2018-02-27 17:29:16 --> Helper loaded: common_helper
INFO - 2018-02-27 17:29:16 --> Database Driver Class Initialized
DEBUG - 2018-02-27 17:29:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-27 17:29:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-27 17:29:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-27 17:29:16 --> Pagination Class Initialized
INFO - 2018-02-27 17:29:16 --> Helper loaded: form_helper
INFO - 2018-02-27 17:29:16 --> Form Validation Class Initialized
INFO - 2018-02-27 17:29:16 --> Model Class Initialized
INFO - 2018-02-27 17:29:16 --> Controller Class Initialized
DEBUG - 2018-02-27 17:29:16 --> Config file loaded: /var/www/html/project/periodtracker/application/config/rest.php
INFO - 2018-02-27 17:29:16 --> Helper loaded: inflector_helper
INFO - 2018-02-27 17:29:16 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-27 17:29:16 --> Model Class Initialized
INFO - 2018-02-27 17:29:16 --> Model Class Initialized
INFO - 2018-02-27 17:29:16 --> Model Class Initialized
INFO - 2018-02-27 17:29:16 --> Final output sent to browser
DEBUG - 2018-02-27 17:29:16 --> Total execution time: 0.0047
INFO - 2018-02-27 17:29:32 --> Config Class Initialized
INFO - 2018-02-27 17:29:32 --> Hooks Class Initialized
DEBUG - 2018-02-27 17:29:32 --> UTF-8 Support Enabled
INFO - 2018-02-27 17:29:32 --> Utf8 Class Initialized
INFO - 2018-02-27 17:29:32 --> URI Class Initialized
INFO - 2018-02-27 17:29:32 --> Router Class Initialized
INFO - 2018-02-27 17:29:32 --> Output Class Initialized
INFO - 2018-02-27 17:29:32 --> Security Class Initialized
DEBUG - 2018-02-27 17:29:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-27 17:29:32 --> Input Class Initialized
INFO - 2018-02-27 17:29:32 --> Language Class Initialized
INFO - 2018-02-27 17:29:32 --> Loader Class Initialized
INFO - 2018-02-27 17:29:32 --> Helper loaded: url_helper
INFO - 2018-02-27 17:29:32 --> Helper loaded: file_helper
INFO - 2018-02-27 17:29:32 --> Helper loaded: email_helper
INFO - 2018-02-27 17:29:32 --> Helper loaded: common_helper
INFO - 2018-02-27 17:29:32 --> Database Driver Class Initialized
DEBUG - 2018-02-27 17:29:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-27 17:29:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-27 17:29:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-27 17:29:32 --> Pagination Class Initialized
INFO - 2018-02-27 17:29:32 --> Helper loaded: form_helper
INFO - 2018-02-27 17:29:32 --> Form Validation Class Initialized
INFO - 2018-02-27 17:29:32 --> Model Class Initialized
INFO - 2018-02-27 17:29:32 --> Controller Class Initialized
DEBUG - 2018-02-27 17:29:32 --> Config file loaded: /var/www/html/project/periodtracker/application/config/rest.php
INFO - 2018-02-27 17:29:32 --> Helper loaded: inflector_helper
INFO - 2018-02-27 17:29:32 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-27 17:29:32 --> Model Class Initialized
INFO - 2018-02-27 17:29:32 --> Model Class Initialized
INFO - 2018-02-27 17:29:32 --> Model Class Initialized
INFO - 2018-02-27 17:29:32 --> Final output sent to browser
DEBUG - 2018-02-27 17:29:32 --> Total execution time: 0.0383
INFO - 2018-02-27 17:29:38 --> Config Class Initialized
INFO - 2018-02-27 17:29:38 --> Hooks Class Initialized
DEBUG - 2018-02-27 17:29:38 --> UTF-8 Support Enabled
INFO - 2018-02-27 17:29:38 --> Utf8 Class Initialized
INFO - 2018-02-27 17:29:38 --> URI Class Initialized
INFO - 2018-02-27 17:29:38 --> Router Class Initialized
INFO - 2018-02-27 17:29:38 --> Output Class Initialized
INFO - 2018-02-27 17:29:38 --> Security Class Initialized
DEBUG - 2018-02-27 17:29:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-27 17:29:38 --> Input Class Initialized
INFO - 2018-02-27 17:29:38 --> Language Class Initialized
INFO - 2018-02-27 17:29:38 --> Loader Class Initialized
INFO - 2018-02-27 17:29:38 --> Helper loaded: url_helper
INFO - 2018-02-27 17:29:38 --> Helper loaded: file_helper
INFO - 2018-02-27 17:29:38 --> Helper loaded: email_helper
INFO - 2018-02-27 17:29:38 --> Helper loaded: common_helper
INFO - 2018-02-27 17:29:38 --> Database Driver Class Initialized
DEBUG - 2018-02-27 17:29:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-27 17:29:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-27 17:29:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-27 17:29:38 --> Pagination Class Initialized
INFO - 2018-02-27 17:29:38 --> Helper loaded: form_helper
INFO - 2018-02-27 17:29:38 --> Form Validation Class Initialized
INFO - 2018-02-27 17:29:38 --> Model Class Initialized
INFO - 2018-02-27 17:29:38 --> Controller Class Initialized
DEBUG - 2018-02-27 17:29:38 --> Config file loaded: /var/www/html/project/periodtracker/application/config/rest.php
INFO - 2018-02-27 17:29:38 --> Helper loaded: inflector_helper
INFO - 2018-02-27 17:29:38 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-27 17:29:38 --> Model Class Initialized
INFO - 2018-02-27 17:29:38 --> Model Class Initialized
INFO - 2018-02-27 17:29:38 --> Model Class Initialized
INFO - 2018-02-27 17:29:38 --> Final output sent to browser
DEBUG - 2018-02-27 17:29:38 --> Total execution time: 0.0375
INFO - 2018-02-27 17:32:17 --> Config Class Initialized
INFO - 2018-02-27 17:32:17 --> Hooks Class Initialized
DEBUG - 2018-02-27 17:32:17 --> UTF-8 Support Enabled
INFO - 2018-02-27 17:32:17 --> Utf8 Class Initialized
INFO - 2018-02-27 17:32:17 --> URI Class Initialized
INFO - 2018-02-27 17:32:17 --> Router Class Initialized
INFO - 2018-02-27 17:32:17 --> Output Class Initialized
INFO - 2018-02-27 17:32:17 --> Security Class Initialized
DEBUG - 2018-02-27 17:32:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-27 17:32:17 --> Input Class Initialized
INFO - 2018-02-27 17:32:17 --> Language Class Initialized
INFO - 2018-02-27 17:32:17 --> Loader Class Initialized
INFO - 2018-02-27 17:32:17 --> Helper loaded: url_helper
INFO - 2018-02-27 17:32:17 --> Helper loaded: file_helper
INFO - 2018-02-27 17:32:17 --> Helper loaded: email_helper
INFO - 2018-02-27 17:32:17 --> Helper loaded: common_helper
INFO - 2018-02-27 17:32:17 --> Database Driver Class Initialized
DEBUG - 2018-02-27 17:32:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-27 17:32:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-27 17:32:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-27 17:32:17 --> Pagination Class Initialized
INFO - 2018-02-27 17:32:17 --> Helper loaded: form_helper
INFO - 2018-02-27 17:32:17 --> Form Validation Class Initialized
INFO - 2018-02-27 17:32:17 --> Model Class Initialized
INFO - 2018-02-27 17:32:17 --> Controller Class Initialized
DEBUG - 2018-02-27 17:32:17 --> Config file loaded: /var/www/html/project/periodtracker/application/config/rest.php
INFO - 2018-02-27 17:32:17 --> Helper loaded: inflector_helper
INFO - 2018-02-27 17:32:17 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-27 17:32:17 --> Model Class Initialized
INFO - 2018-02-27 17:32:17 --> Model Class Initialized
INFO - 2018-02-27 17:32:17 --> Model Class Initialized
INFO - 2018-02-27 17:32:18 --> Final output sent to browser
DEBUG - 2018-02-27 17:32:18 --> Total execution time: 0.0043
INFO - 2018-02-27 17:32:36 --> Config Class Initialized
INFO - 2018-02-27 17:32:36 --> Hooks Class Initialized
DEBUG - 2018-02-27 17:32:36 --> UTF-8 Support Enabled
INFO - 2018-02-27 17:32:36 --> Utf8 Class Initialized
INFO - 2018-02-27 17:32:36 --> URI Class Initialized
INFO - 2018-02-27 17:32:36 --> Router Class Initialized
INFO - 2018-02-27 17:32:36 --> Output Class Initialized
INFO - 2018-02-27 17:32:36 --> Security Class Initialized
DEBUG - 2018-02-27 17:32:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-27 17:32:36 --> Input Class Initialized
INFO - 2018-02-27 17:32:36 --> Language Class Initialized
INFO - 2018-02-27 17:32:36 --> Loader Class Initialized
INFO - 2018-02-27 17:32:36 --> Helper loaded: url_helper
INFO - 2018-02-27 17:32:36 --> Helper loaded: file_helper
INFO - 2018-02-27 17:32:36 --> Helper loaded: email_helper
INFO - 2018-02-27 17:32:36 --> Helper loaded: common_helper
INFO - 2018-02-27 17:32:36 --> Database Driver Class Initialized
DEBUG - 2018-02-27 17:32:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-27 17:32:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-27 17:32:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-27 17:32:36 --> Pagination Class Initialized
INFO - 2018-02-27 17:32:36 --> Helper loaded: form_helper
INFO - 2018-02-27 17:32:36 --> Form Validation Class Initialized
INFO - 2018-02-27 17:32:36 --> Model Class Initialized
INFO - 2018-02-27 17:32:36 --> Controller Class Initialized
DEBUG - 2018-02-27 17:32:36 --> Config file loaded: /var/www/html/project/periodtracker/application/config/rest.php
INFO - 2018-02-27 17:32:36 --> Helper loaded: inflector_helper
INFO - 2018-02-27 17:32:36 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-27 17:32:36 --> Model Class Initialized
INFO - 2018-02-27 17:32:36 --> Model Class Initialized
INFO - 2018-02-27 17:32:36 --> Model Class Initialized
INFO - 2018-02-27 17:32:36 --> Final output sent to browser
DEBUG - 2018-02-27 17:32:36 --> Total execution time: 0.0044
INFO - 2018-02-27 17:32:40 --> Config Class Initialized
INFO - 2018-02-27 17:32:40 --> Hooks Class Initialized
DEBUG - 2018-02-27 17:32:40 --> UTF-8 Support Enabled
INFO - 2018-02-27 17:32:40 --> Utf8 Class Initialized
INFO - 2018-02-27 17:32:40 --> URI Class Initialized
INFO - 2018-02-27 17:32:40 --> Router Class Initialized
INFO - 2018-02-27 17:32:40 --> Output Class Initialized
INFO - 2018-02-27 17:32:40 --> Security Class Initialized
DEBUG - 2018-02-27 17:32:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-27 17:32:40 --> Input Class Initialized
INFO - 2018-02-27 17:32:40 --> Language Class Initialized
INFO - 2018-02-27 17:32:40 --> Loader Class Initialized
INFO - 2018-02-27 17:32:40 --> Helper loaded: url_helper
INFO - 2018-02-27 17:32:40 --> Helper loaded: file_helper
INFO - 2018-02-27 17:32:40 --> Helper loaded: email_helper
INFO - 2018-02-27 17:32:40 --> Helper loaded: common_helper
INFO - 2018-02-27 17:32:40 --> Database Driver Class Initialized
DEBUG - 2018-02-27 17:32:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-27 17:32:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-27 17:32:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-27 17:32:40 --> Pagination Class Initialized
INFO - 2018-02-27 17:32:40 --> Helper loaded: form_helper
INFO - 2018-02-27 17:32:40 --> Form Validation Class Initialized
INFO - 2018-02-27 17:32:40 --> Model Class Initialized
INFO - 2018-02-27 17:32:40 --> Controller Class Initialized
DEBUG - 2018-02-27 17:32:40 --> Config file loaded: /var/www/html/project/periodtracker/application/config/rest.php
INFO - 2018-02-27 17:32:40 --> Helper loaded: inflector_helper
INFO - 2018-02-27 17:32:40 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-27 17:32:40 --> Model Class Initialized
INFO - 2018-02-27 17:32:40 --> Model Class Initialized
INFO - 2018-02-27 17:32:40 --> Model Class Initialized
INFO - 2018-02-27 17:32:40 --> Final output sent to browser
DEBUG - 2018-02-27 17:32:40 --> Total execution time: 0.0045
INFO - 2018-02-27 17:32:45 --> Config Class Initialized
INFO - 2018-02-27 17:32:45 --> Hooks Class Initialized
DEBUG - 2018-02-27 17:32:45 --> UTF-8 Support Enabled
INFO - 2018-02-27 17:32:45 --> Utf8 Class Initialized
INFO - 2018-02-27 17:32:45 --> URI Class Initialized
INFO - 2018-02-27 17:32:45 --> Router Class Initialized
INFO - 2018-02-27 17:32:45 --> Output Class Initialized
INFO - 2018-02-27 17:32:45 --> Security Class Initialized
DEBUG - 2018-02-27 17:32:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-27 17:32:45 --> Input Class Initialized
INFO - 2018-02-27 17:32:45 --> Language Class Initialized
INFO - 2018-02-27 17:32:45 --> Loader Class Initialized
INFO - 2018-02-27 17:32:45 --> Helper loaded: url_helper
INFO - 2018-02-27 17:32:45 --> Helper loaded: file_helper
INFO - 2018-02-27 17:32:45 --> Helper loaded: email_helper
INFO - 2018-02-27 17:32:45 --> Helper loaded: common_helper
INFO - 2018-02-27 17:32:45 --> Database Driver Class Initialized
DEBUG - 2018-02-27 17:32:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-27 17:32:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-27 17:32:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-27 17:32:45 --> Pagination Class Initialized
INFO - 2018-02-27 17:32:45 --> Helper loaded: form_helper
INFO - 2018-02-27 17:32:45 --> Form Validation Class Initialized
INFO - 2018-02-27 17:32:45 --> Model Class Initialized
INFO - 2018-02-27 17:32:45 --> Controller Class Initialized
DEBUG - 2018-02-27 17:32:45 --> Config file loaded: /var/www/html/project/periodtracker/application/config/rest.php
INFO - 2018-02-27 17:32:45 --> Helper loaded: inflector_helper
INFO - 2018-02-27 17:32:45 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-27 17:32:45 --> Model Class Initialized
INFO - 2018-02-27 17:32:45 --> Model Class Initialized
INFO - 2018-02-27 17:32:45 --> Model Class Initialized
INFO - 2018-02-27 17:32:45 --> Final output sent to browser
DEBUG - 2018-02-27 17:32:45 --> Total execution time: 0.0061
INFO - 2018-02-27 17:32:47 --> Config Class Initialized
INFO - 2018-02-27 17:32:47 --> Hooks Class Initialized
DEBUG - 2018-02-27 17:32:47 --> UTF-8 Support Enabled
INFO - 2018-02-27 17:32:47 --> Utf8 Class Initialized
INFO - 2018-02-27 17:32:47 --> URI Class Initialized
INFO - 2018-02-27 17:32:47 --> Router Class Initialized
INFO - 2018-02-27 17:32:47 --> Output Class Initialized
INFO - 2018-02-27 17:32:47 --> Security Class Initialized
DEBUG - 2018-02-27 17:32:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-27 17:32:47 --> Input Class Initialized
INFO - 2018-02-27 17:32:47 --> Language Class Initialized
INFO - 2018-02-27 17:32:47 --> Loader Class Initialized
INFO - 2018-02-27 17:32:47 --> Helper loaded: url_helper
INFO - 2018-02-27 17:32:47 --> Helper loaded: file_helper
INFO - 2018-02-27 17:32:47 --> Helper loaded: email_helper
INFO - 2018-02-27 17:32:47 --> Helper loaded: common_helper
INFO - 2018-02-27 17:32:47 --> Database Driver Class Initialized
DEBUG - 2018-02-27 17:32:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-27 17:32:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-27 17:32:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-27 17:32:47 --> Pagination Class Initialized
INFO - 2018-02-27 17:32:47 --> Helper loaded: form_helper
INFO - 2018-02-27 17:32:47 --> Form Validation Class Initialized
INFO - 2018-02-27 17:32:47 --> Model Class Initialized
INFO - 2018-02-27 17:32:47 --> Controller Class Initialized
DEBUG - 2018-02-27 17:32:47 --> Config file loaded: /var/www/html/project/periodtracker/application/config/rest.php
INFO - 2018-02-27 17:32:47 --> Helper loaded: inflector_helper
INFO - 2018-02-27 17:32:47 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-27 17:32:47 --> Model Class Initialized
INFO - 2018-02-27 17:32:47 --> Model Class Initialized
INFO - 2018-02-27 17:32:47 --> Model Class Initialized
INFO - 2018-02-27 17:32:47 --> Final output sent to browser
DEBUG - 2018-02-27 17:32:47 --> Total execution time: 0.0424
INFO - 2018-02-27 17:35:45 --> Config Class Initialized
INFO - 2018-02-27 17:35:45 --> Hooks Class Initialized
DEBUG - 2018-02-27 17:35:45 --> UTF-8 Support Enabled
INFO - 2018-02-27 17:35:45 --> Utf8 Class Initialized
INFO - 2018-02-27 17:35:45 --> URI Class Initialized
INFO - 2018-02-27 17:35:45 --> Router Class Initialized
INFO - 2018-02-27 17:35:45 --> Output Class Initialized
INFO - 2018-02-27 17:35:45 --> Security Class Initialized
DEBUG - 2018-02-27 17:35:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-27 17:35:45 --> Input Class Initialized
INFO - 2018-02-27 17:35:45 --> Language Class Initialized
INFO - 2018-02-27 17:35:45 --> Loader Class Initialized
INFO - 2018-02-27 17:35:45 --> Helper loaded: url_helper
INFO - 2018-02-27 17:35:45 --> Helper loaded: file_helper
INFO - 2018-02-27 17:35:45 --> Helper loaded: email_helper
INFO - 2018-02-27 17:35:45 --> Helper loaded: common_helper
INFO - 2018-02-27 17:35:45 --> Database Driver Class Initialized
DEBUG - 2018-02-27 17:35:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-27 17:35:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-27 17:35:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-27 17:35:45 --> Pagination Class Initialized
INFO - 2018-02-27 17:35:45 --> Helper loaded: form_helper
INFO - 2018-02-27 17:35:45 --> Form Validation Class Initialized
INFO - 2018-02-27 17:35:45 --> Model Class Initialized
INFO - 2018-02-27 17:35:45 --> Controller Class Initialized
DEBUG - 2018-02-27 17:35:45 --> Config file loaded: /var/www/html/project/periodtracker/application/config/rest.php
INFO - 2018-02-27 17:35:45 --> Helper loaded: inflector_helper
INFO - 2018-02-27 17:35:45 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-27 17:35:45 --> Model Class Initialized
INFO - 2018-02-27 17:35:45 --> Model Class Initialized
INFO - 2018-02-27 17:35:45 --> Model Class Initialized
INFO - 2018-02-27 17:35:45 --> Final output sent to browser
DEBUG - 2018-02-27 17:35:45 --> Total execution time: 0.0046
INFO - 2018-02-27 17:45:09 --> Config Class Initialized
INFO - 2018-02-27 17:45:09 --> Hooks Class Initialized
DEBUG - 2018-02-27 17:45:09 --> UTF-8 Support Enabled
INFO - 2018-02-27 17:45:09 --> Utf8 Class Initialized
INFO - 2018-02-27 17:45:09 --> URI Class Initialized
INFO - 2018-02-27 17:45:09 --> Router Class Initialized
INFO - 2018-02-27 17:45:09 --> Output Class Initialized
INFO - 2018-02-27 17:45:09 --> Security Class Initialized
DEBUG - 2018-02-27 17:45:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-27 17:45:09 --> Input Class Initialized
INFO - 2018-02-27 17:45:09 --> Language Class Initialized
INFO - 2018-02-27 17:45:09 --> Loader Class Initialized
INFO - 2018-02-27 17:45:09 --> Helper loaded: url_helper
INFO - 2018-02-27 17:45:09 --> Helper loaded: file_helper
INFO - 2018-02-27 17:45:09 --> Helper loaded: email_helper
INFO - 2018-02-27 17:45:09 --> Helper loaded: common_helper
INFO - 2018-02-27 17:45:09 --> Database Driver Class Initialized
DEBUG - 2018-02-27 17:45:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-27 17:45:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-27 17:45:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-27 17:45:09 --> Pagination Class Initialized
INFO - 2018-02-27 17:45:09 --> Helper loaded: form_helper
INFO - 2018-02-27 17:45:09 --> Form Validation Class Initialized
INFO - 2018-02-27 17:45:09 --> Model Class Initialized
INFO - 2018-02-27 17:45:09 --> Controller Class Initialized
DEBUG - 2018-02-27 17:45:09 --> Config file loaded: /var/www/html/project/periodtracker/application/config/rest.php
INFO - 2018-02-27 17:45:09 --> Helper loaded: inflector_helper
INFO - 2018-02-27 17:45:09 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-27 17:45:09 --> Model Class Initialized
INFO - 2018-02-27 17:45:09 --> Model Class Initialized
INFO - 2018-02-27 17:45:09 --> Model Class Initialized
INFO - 2018-02-27 17:45:09 --> Final output sent to browser
DEBUG - 2018-02-27 17:45:09 --> Total execution time: 0.0616
INFO - 2018-02-27 17:45:09 --> Config Class Initialized
INFO - 2018-02-27 17:45:09 --> Hooks Class Initialized
DEBUG - 2018-02-27 17:45:09 --> UTF-8 Support Enabled
INFO - 2018-02-27 17:45:09 --> Utf8 Class Initialized
INFO - 2018-02-27 17:45:09 --> URI Class Initialized
INFO - 2018-02-27 17:45:09 --> Router Class Initialized
INFO - 2018-02-27 17:45:09 --> Output Class Initialized
INFO - 2018-02-27 17:45:09 --> Security Class Initialized
DEBUG - 2018-02-27 17:45:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-27 17:45:09 --> Input Class Initialized
INFO - 2018-02-27 17:45:09 --> Language Class Initialized
INFO - 2018-02-27 17:45:09 --> Loader Class Initialized
INFO - 2018-02-27 17:45:09 --> Helper loaded: url_helper
INFO - 2018-02-27 17:45:09 --> Helper loaded: file_helper
INFO - 2018-02-27 17:45:09 --> Helper loaded: email_helper
INFO - 2018-02-27 17:45:09 --> Helper loaded: common_helper
INFO - 2018-02-27 17:45:09 --> Database Driver Class Initialized
DEBUG - 2018-02-27 17:45:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-27 17:45:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-27 17:45:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-27 17:45:09 --> Pagination Class Initialized
INFO - 2018-02-27 17:45:09 --> Helper loaded: form_helper
INFO - 2018-02-27 17:45:09 --> Form Validation Class Initialized
INFO - 2018-02-27 17:45:09 --> Model Class Initialized
INFO - 2018-02-27 17:45:09 --> Controller Class Initialized
DEBUG - 2018-02-27 17:45:09 --> Config file loaded: /var/www/html/project/periodtracker/application/config/rest.php
INFO - 2018-02-27 17:45:09 --> Helper loaded: inflector_helper
INFO - 2018-02-27 17:45:09 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-27 17:45:09 --> Model Class Initialized
INFO - 2018-02-27 17:45:09 --> Model Class Initialized
INFO - 2018-02-27 17:45:09 --> Model Class Initialized
INFO - 2018-02-27 17:45:09 --> Model Class Initialized
ERROR - 2018-02-27 17:45:09 --> Query error: Table 'periodtracker.emailtemplate_master' doesn't exist - Invalid query: SELECT *
FROM `emailtemplate_master`
WHERE `vTemplateName` = 'resetPassword'
INFO - 2018-02-27 17:45:09 --> Language file loaded: language/english/db_lang.php
INFO - 2018-02-27 17:46:29 --> Config Class Initialized
INFO - 2018-02-27 17:46:29 --> Hooks Class Initialized
DEBUG - 2018-02-27 17:46:29 --> UTF-8 Support Enabled
INFO - 2018-02-27 17:46:29 --> Utf8 Class Initialized
INFO - 2018-02-27 17:46:29 --> URI Class Initialized
INFO - 2018-02-27 17:46:29 --> Router Class Initialized
INFO - 2018-02-27 17:46:29 --> Output Class Initialized
INFO - 2018-02-27 17:46:29 --> Security Class Initialized
DEBUG - 2018-02-27 17:46:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-27 17:46:29 --> Input Class Initialized
INFO - 2018-02-27 17:46:29 --> Language Class Initialized
INFO - 2018-02-27 17:46:29 --> Loader Class Initialized
INFO - 2018-02-27 17:46:29 --> Helper loaded: url_helper
INFO - 2018-02-27 17:46:29 --> Helper loaded: file_helper
INFO - 2018-02-27 17:46:29 --> Helper loaded: email_helper
INFO - 2018-02-27 17:46:29 --> Helper loaded: common_helper
INFO - 2018-02-27 17:46:29 --> Database Driver Class Initialized
DEBUG - 2018-02-27 17:46:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-27 17:46:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-27 17:46:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-27 17:46:29 --> Pagination Class Initialized
INFO - 2018-02-27 17:46:29 --> Helper loaded: form_helper
INFO - 2018-02-27 17:46:29 --> Form Validation Class Initialized
INFO - 2018-02-27 17:46:29 --> Model Class Initialized
INFO - 2018-02-27 17:46:29 --> Controller Class Initialized
DEBUG - 2018-02-27 17:46:29 --> Config file loaded: /var/www/html/project/periodtracker/application/config/rest.php
INFO - 2018-02-27 17:46:29 --> Helper loaded: inflector_helper
INFO - 2018-02-27 17:46:29 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-27 17:46:29 --> Model Class Initialized
INFO - 2018-02-27 17:46:29 --> Model Class Initialized
INFO - 2018-02-27 17:46:29 --> Model Class Initialized
INFO - 2018-02-27 17:46:29 --> Final output sent to browser
DEBUG - 2018-02-27 17:46:29 --> Total execution time: 0.0049
INFO - 2018-02-27 17:50:03 --> Config Class Initialized
INFO - 2018-02-27 17:50:03 --> Hooks Class Initialized
DEBUG - 2018-02-27 17:50:03 --> UTF-8 Support Enabled
INFO - 2018-02-27 17:50:03 --> Utf8 Class Initialized
INFO - 2018-02-27 17:50:03 --> URI Class Initialized
INFO - 2018-02-27 17:50:03 --> Router Class Initialized
INFO - 2018-02-27 17:50:03 --> Output Class Initialized
INFO - 2018-02-27 17:50:03 --> Security Class Initialized
DEBUG - 2018-02-27 17:50:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-27 17:50:03 --> Input Class Initialized
INFO - 2018-02-27 17:50:03 --> Language Class Initialized
INFO - 2018-02-27 17:50:03 --> Loader Class Initialized
INFO - 2018-02-27 17:50:03 --> Helper loaded: url_helper
INFO - 2018-02-27 17:50:03 --> Helper loaded: file_helper
INFO - 2018-02-27 17:50:03 --> Helper loaded: email_helper
INFO - 2018-02-27 17:50:03 --> Helper loaded: common_helper
INFO - 2018-02-27 17:50:03 --> Database Driver Class Initialized
DEBUG - 2018-02-27 17:50:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-27 17:50:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-27 17:50:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-27 17:50:03 --> Pagination Class Initialized
INFO - 2018-02-27 17:50:03 --> Helper loaded: form_helper
INFO - 2018-02-27 17:50:03 --> Form Validation Class Initialized
INFO - 2018-02-27 17:50:03 --> Model Class Initialized
INFO - 2018-02-27 17:50:03 --> Controller Class Initialized
DEBUG - 2018-02-27 17:50:03 --> Config file loaded: /var/www/html/project/periodtracker/application/config/rest.php
INFO - 2018-02-27 17:50:03 --> Helper loaded: inflector_helper
INFO - 2018-02-27 17:50:03 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-27 17:50:03 --> Model Class Initialized
INFO - 2018-02-27 17:50:03 --> Model Class Initialized
INFO - 2018-02-27 17:50:03 --> Model Class Initialized
INFO - 2018-02-27 17:50:03 --> Final output sent to browser
DEBUG - 2018-02-27 17:50:03 --> Total execution time: 0.0378
INFO - 2018-02-27 17:50:03 --> Config Class Initialized
INFO - 2018-02-27 17:50:03 --> Hooks Class Initialized
DEBUG - 2018-02-27 17:50:03 --> UTF-8 Support Enabled
INFO - 2018-02-27 17:50:03 --> Utf8 Class Initialized
INFO - 2018-02-27 17:50:03 --> URI Class Initialized
INFO - 2018-02-27 17:50:03 --> Router Class Initialized
INFO - 2018-02-27 17:50:03 --> Output Class Initialized
INFO - 2018-02-27 17:50:03 --> Security Class Initialized
DEBUG - 2018-02-27 17:50:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-27 17:50:03 --> Input Class Initialized
INFO - 2018-02-27 17:50:03 --> Language Class Initialized
INFO - 2018-02-27 17:50:03 --> Loader Class Initialized
INFO - 2018-02-27 17:50:03 --> Helper loaded: url_helper
INFO - 2018-02-27 17:50:03 --> Helper loaded: file_helper
INFO - 2018-02-27 17:50:03 --> Helper loaded: email_helper
INFO - 2018-02-27 17:50:03 --> Helper loaded: common_helper
INFO - 2018-02-27 17:50:03 --> Database Driver Class Initialized
DEBUG - 2018-02-27 17:50:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-27 17:50:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-27 17:50:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-27 17:50:03 --> Pagination Class Initialized
INFO - 2018-02-27 17:50:03 --> Helper loaded: form_helper
INFO - 2018-02-27 17:50:03 --> Form Validation Class Initialized
INFO - 2018-02-27 17:50:03 --> Model Class Initialized
INFO - 2018-02-27 17:50:03 --> Controller Class Initialized
DEBUG - 2018-02-27 17:50:03 --> Config file loaded: /var/www/html/project/periodtracker/application/config/rest.php
INFO - 2018-02-27 17:50:03 --> Helper loaded: inflector_helper
INFO - 2018-02-27 17:50:03 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-27 17:50:03 --> Model Class Initialized
INFO - 2018-02-27 17:50:03 --> Model Class Initialized
INFO - 2018-02-27 17:50:03 --> Model Class Initialized
INFO - 2018-02-27 17:50:03 --> Model Class Initialized
INFO - 2018-02-27 17:50:03 --> Email Class Initialized
INFO - 2018-02-27 17:50:03 --> Language file loaded: language/english/email_lang.php
INFO - 2018-02-27 17:50:07 --> Final output sent to browser
DEBUG - 2018-02-27 17:50:07 --> Total execution time: 4.2817
INFO - 2018-02-27 17:50:22 --> Config Class Initialized
INFO - 2018-02-27 17:50:22 --> Hooks Class Initialized
DEBUG - 2018-02-27 17:50:22 --> UTF-8 Support Enabled
INFO - 2018-02-27 17:50:22 --> Utf8 Class Initialized
INFO - 2018-02-27 17:50:22 --> URI Class Initialized
INFO - 2018-02-27 17:50:22 --> Router Class Initialized
INFO - 2018-02-27 17:50:22 --> Output Class Initialized
INFO - 2018-02-27 17:50:22 --> Security Class Initialized
DEBUG - 2018-02-27 17:50:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-27 17:50:22 --> Input Class Initialized
INFO - 2018-02-27 17:50:22 --> Language Class Initialized
INFO - 2018-02-27 17:50:22 --> Loader Class Initialized
INFO - 2018-02-27 17:50:22 --> Helper loaded: url_helper
INFO - 2018-02-27 17:50:22 --> Helper loaded: file_helper
INFO - 2018-02-27 17:50:22 --> Helper loaded: email_helper
INFO - 2018-02-27 17:50:22 --> Helper loaded: common_helper
INFO - 2018-02-27 17:50:22 --> Database Driver Class Initialized
DEBUG - 2018-02-27 17:50:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-27 17:50:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-27 17:50:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-27 17:50:22 --> Pagination Class Initialized
INFO - 2018-02-27 17:50:22 --> Helper loaded: form_helper
INFO - 2018-02-27 17:50:22 --> Form Validation Class Initialized
INFO - 2018-02-27 17:50:22 --> Model Class Initialized
INFO - 2018-02-27 17:50:22 --> Controller Class Initialized
INFO - 2018-02-27 17:50:22 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-27 17:50:22 --> Model Class Initialized
INFO - 2018-02-27 17:50:22 --> Model Class Initialized
INFO - 2018-02-27 17:50:22 --> File loaded: /var/www/html/project/periodtracker/application/views/index/resetPassword.php
INFO - 2018-02-27 17:50:22 --> Final output sent to browser
DEBUG - 2018-02-27 17:50:22 --> Total execution time: 0.0049
INFO - 2018-02-27 17:51:06 --> Config Class Initialized
INFO - 2018-02-27 17:51:06 --> Hooks Class Initialized
DEBUG - 2018-02-27 17:51:06 --> UTF-8 Support Enabled
INFO - 2018-02-27 17:51:06 --> Utf8 Class Initialized
INFO - 2018-02-27 17:51:06 --> URI Class Initialized
INFO - 2018-02-27 17:51:06 --> Router Class Initialized
INFO - 2018-02-27 17:51:06 --> Output Class Initialized
INFO - 2018-02-27 17:51:06 --> Security Class Initialized
DEBUG - 2018-02-27 17:51:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-27 17:51:06 --> Input Class Initialized
INFO - 2018-02-27 17:51:06 --> Language Class Initialized
INFO - 2018-02-27 17:51:06 --> Loader Class Initialized
INFO - 2018-02-27 17:51:06 --> Helper loaded: url_helper
INFO - 2018-02-27 17:51:06 --> Helper loaded: file_helper
INFO - 2018-02-27 17:51:06 --> Helper loaded: email_helper
INFO - 2018-02-27 17:51:06 --> Helper loaded: common_helper
INFO - 2018-02-27 17:51:06 --> Database Driver Class Initialized
DEBUG - 2018-02-27 17:51:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-27 17:51:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-27 17:51:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-27 17:51:06 --> Pagination Class Initialized
INFO - 2018-02-27 17:51:06 --> Helper loaded: form_helper
INFO - 2018-02-27 17:51:06 --> Form Validation Class Initialized
INFO - 2018-02-27 17:51:06 --> Model Class Initialized
INFO - 2018-02-27 17:51:06 --> Controller Class Initialized
INFO - 2018-02-27 17:51:06 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-27 17:51:06 --> Model Class Initialized
INFO - 2018-02-27 17:51:06 --> Model Class Initialized
INFO - 2018-02-27 17:51:06 --> File loaded: /var/www/html/project/periodtracker/application/views/index/resetPassword.php
INFO - 2018-02-27 17:51:06 --> Final output sent to browser
DEBUG - 2018-02-27 17:51:06 --> Total execution time: 0.0050
INFO - 2018-02-27 17:54:22 --> Config Class Initialized
INFO - 2018-02-27 17:54:22 --> Hooks Class Initialized
DEBUG - 2018-02-27 17:54:22 --> UTF-8 Support Enabled
INFO - 2018-02-27 17:54:22 --> Utf8 Class Initialized
INFO - 2018-02-27 17:54:22 --> URI Class Initialized
INFO - 2018-02-27 17:54:22 --> Router Class Initialized
INFO - 2018-02-27 17:54:22 --> Output Class Initialized
INFO - 2018-02-27 17:54:22 --> Security Class Initialized
DEBUG - 2018-02-27 17:54:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-27 17:54:22 --> Input Class Initialized
INFO - 2018-02-27 17:54:22 --> Language Class Initialized
INFO - 2018-02-27 17:54:22 --> Loader Class Initialized
INFO - 2018-02-27 17:54:22 --> Helper loaded: url_helper
INFO - 2018-02-27 17:54:22 --> Helper loaded: file_helper
INFO - 2018-02-27 17:54:22 --> Helper loaded: email_helper
INFO - 2018-02-27 17:54:22 --> Helper loaded: common_helper
INFO - 2018-02-27 17:54:22 --> Database Driver Class Initialized
DEBUG - 2018-02-27 17:54:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-27 17:54:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-27 17:54:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-27 17:54:22 --> Pagination Class Initialized
INFO - 2018-02-27 17:54:22 --> Helper loaded: form_helper
INFO - 2018-02-27 17:54:22 --> Form Validation Class Initialized
INFO - 2018-02-27 17:54:22 --> Model Class Initialized
INFO - 2018-02-27 17:54:22 --> Controller Class Initialized
INFO - 2018-02-27 17:54:22 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-27 17:54:22 --> Model Class Initialized
INFO - 2018-02-27 17:54:22 --> Model Class Initialized
INFO - 2018-02-27 17:54:22 --> File loaded: /var/www/html/project/periodtracker/application/views/index/resetPassword.php
INFO - 2018-02-27 17:54:22 --> Final output sent to browser
DEBUG - 2018-02-27 17:54:22 --> Total execution time: 0.0056
INFO - 2018-02-27 17:54:33 --> Config Class Initialized
INFO - 2018-02-27 17:54:33 --> Hooks Class Initialized
DEBUG - 2018-02-27 17:54:33 --> UTF-8 Support Enabled
INFO - 2018-02-27 17:54:33 --> Utf8 Class Initialized
INFO - 2018-02-27 17:54:33 --> URI Class Initialized
INFO - 2018-02-27 17:54:33 --> Router Class Initialized
INFO - 2018-02-27 17:54:33 --> Output Class Initialized
INFO - 2018-02-27 17:54:33 --> Security Class Initialized
DEBUG - 2018-02-27 17:54:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-27 17:54:33 --> Input Class Initialized
INFO - 2018-02-27 17:54:33 --> Language Class Initialized
INFO - 2018-02-27 17:54:33 --> Loader Class Initialized
INFO - 2018-02-27 17:54:33 --> Helper loaded: url_helper
INFO - 2018-02-27 17:54:33 --> Helper loaded: file_helper
INFO - 2018-02-27 17:54:33 --> Helper loaded: email_helper
INFO - 2018-02-27 17:54:33 --> Helper loaded: common_helper
INFO - 2018-02-27 17:54:33 --> Database Driver Class Initialized
DEBUG - 2018-02-27 17:54:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-27 17:54:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-27 17:54:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-27 17:54:33 --> Pagination Class Initialized
INFO - 2018-02-27 17:54:33 --> Helper loaded: form_helper
INFO - 2018-02-27 17:54:33 --> Form Validation Class Initialized
INFO - 2018-02-27 17:54:33 --> Model Class Initialized
INFO - 2018-02-27 17:54:33 --> Controller Class Initialized
INFO - 2018-02-27 17:54:33 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-27 17:54:33 --> Model Class Initialized
INFO - 2018-02-27 17:54:33 --> Model Class Initialized
INFO - 2018-02-27 17:54:33 --> File loaded: /var/www/html/project/periodtracker/application/views/index/resetPassword.php
INFO - 2018-02-27 17:54:33 --> Final output sent to browser
DEBUG - 2018-02-27 17:54:33 --> Total execution time: 0.0075
INFO - 2018-02-27 17:55:52 --> Config Class Initialized
INFO - 2018-02-27 17:55:52 --> Hooks Class Initialized
DEBUG - 2018-02-27 17:55:52 --> UTF-8 Support Enabled
INFO - 2018-02-27 17:55:52 --> Utf8 Class Initialized
INFO - 2018-02-27 17:55:52 --> URI Class Initialized
INFO - 2018-02-27 17:55:52 --> Router Class Initialized
INFO - 2018-02-27 17:55:52 --> Output Class Initialized
INFO - 2018-02-27 17:55:52 --> Security Class Initialized
DEBUG - 2018-02-27 17:55:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-27 17:55:52 --> Input Class Initialized
INFO - 2018-02-27 17:55:52 --> Language Class Initialized
INFO - 2018-02-27 17:55:52 --> Loader Class Initialized
INFO - 2018-02-27 17:55:52 --> Helper loaded: url_helper
INFO - 2018-02-27 17:55:52 --> Helper loaded: file_helper
INFO - 2018-02-27 17:55:52 --> Helper loaded: email_helper
INFO - 2018-02-27 17:55:52 --> Helper loaded: common_helper
INFO - 2018-02-27 17:55:52 --> Database Driver Class Initialized
DEBUG - 2018-02-27 17:55:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-27 17:55:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-27 17:55:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-27 17:55:52 --> Pagination Class Initialized
INFO - 2018-02-27 17:55:52 --> Helper loaded: form_helper
INFO - 2018-02-27 17:55:52 --> Form Validation Class Initialized
INFO - 2018-02-27 17:55:52 --> Model Class Initialized
INFO - 2018-02-27 17:55:52 --> Controller Class Initialized
INFO - 2018-02-27 17:55:52 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-27 17:55:52 --> Model Class Initialized
INFO - 2018-02-27 17:55:52 --> Model Class Initialized
INFO - 2018-02-27 17:55:52 --> File loaded: /var/www/html/project/periodtracker/application/views/index/resetPassword.php
INFO - 2018-02-27 17:55:52 --> Final output sent to browser
DEBUG - 2018-02-27 17:55:52 --> Total execution time: 0.0683
INFO - 2018-02-27 17:55:55 --> Config Class Initialized
INFO - 2018-02-27 17:55:55 --> Hooks Class Initialized
DEBUG - 2018-02-27 17:55:55 --> UTF-8 Support Enabled
INFO - 2018-02-27 17:55:55 --> Utf8 Class Initialized
INFO - 2018-02-27 17:55:55 --> URI Class Initialized
INFO - 2018-02-27 17:55:55 --> Router Class Initialized
INFO - 2018-02-27 17:55:55 --> Output Class Initialized
INFO - 2018-02-27 17:55:55 --> Security Class Initialized
DEBUG - 2018-02-27 17:55:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-27 17:55:55 --> Input Class Initialized
INFO - 2018-02-27 17:55:55 --> Language Class Initialized
INFO - 2018-02-27 17:55:55 --> Loader Class Initialized
INFO - 2018-02-27 17:55:55 --> Helper loaded: url_helper
INFO - 2018-02-27 17:55:55 --> Helper loaded: file_helper
INFO - 2018-02-27 17:55:55 --> Helper loaded: email_helper
INFO - 2018-02-27 17:55:55 --> Helper loaded: common_helper
INFO - 2018-02-27 17:55:55 --> Database Driver Class Initialized
DEBUG - 2018-02-27 17:55:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-27 17:55:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-27 17:55:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-27 17:55:55 --> Pagination Class Initialized
INFO - 2018-02-27 17:55:55 --> Helper loaded: form_helper
INFO - 2018-02-27 17:55:55 --> Form Validation Class Initialized
INFO - 2018-02-27 17:55:55 --> Model Class Initialized
INFO - 2018-02-27 17:55:55 --> Controller Class Initialized
INFO - 2018-02-27 17:55:55 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-27 17:55:55 --> Model Class Initialized
INFO - 2018-02-27 17:55:55 --> Model Class Initialized
INFO - 2018-02-27 17:55:55 --> File loaded: /var/www/html/project/periodtracker/application/views/index/resetPassword.php
INFO - 2018-02-27 17:55:55 --> Final output sent to browser
DEBUG - 2018-02-27 17:55:55 --> Total execution time: 0.0050
INFO - 2018-02-27 18:25:41 --> Config Class Initialized
INFO - 2018-02-27 18:25:41 --> Hooks Class Initialized
DEBUG - 2018-02-27 18:25:41 --> UTF-8 Support Enabled
INFO - 2018-02-27 18:25:41 --> Utf8 Class Initialized
INFO - 2018-02-27 18:25:41 --> URI Class Initialized
INFO - 2018-02-27 18:25:41 --> Router Class Initialized
INFO - 2018-02-27 18:25:41 --> Output Class Initialized
INFO - 2018-02-27 18:25:41 --> Security Class Initialized
DEBUG - 2018-02-27 18:25:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-27 18:25:41 --> Input Class Initialized
INFO - 2018-02-27 18:25:41 --> Language Class Initialized
INFO - 2018-02-27 18:25:41 --> Loader Class Initialized
INFO - 2018-02-27 18:25:41 --> Helper loaded: url_helper
INFO - 2018-02-27 18:25:41 --> Helper loaded: file_helper
INFO - 2018-02-27 18:25:41 --> Helper loaded: email_helper
INFO - 2018-02-27 18:25:41 --> Helper loaded: common_helper
INFO - 2018-02-27 18:25:41 --> Database Driver Class Initialized
DEBUG - 2018-02-27 18:25:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-27 18:25:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-27 18:25:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-27 18:25:41 --> Pagination Class Initialized
INFO - 2018-02-27 18:25:41 --> Helper loaded: form_helper
INFO - 2018-02-27 18:25:41 --> Form Validation Class Initialized
INFO - 2018-02-27 18:25:41 --> Model Class Initialized
INFO - 2018-02-27 18:25:41 --> Controller Class Initialized
DEBUG - 2018-02-27 18:25:41 --> Config file loaded: /var/www/html/project/periodtracker/application/config/rest.php
INFO - 2018-02-27 18:25:41 --> Helper loaded: inflector_helper
INFO - 2018-02-27 18:25:41 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-27 18:25:41 --> Model Class Initialized
INFO - 2018-02-27 18:25:41 --> Model Class Initialized
INFO - 2018-02-27 18:25:41 --> Model Class Initialized
INFO - 2018-02-27 18:25:41 --> Final output sent to browser
DEBUG - 2018-02-27 18:25:41 --> Total execution time: 0.0048
INFO - 2018-02-27 18:27:19 --> Config Class Initialized
INFO - 2018-02-27 18:27:19 --> Hooks Class Initialized
DEBUG - 2018-02-27 18:27:19 --> UTF-8 Support Enabled
INFO - 2018-02-27 18:27:19 --> Utf8 Class Initialized
INFO - 2018-02-27 18:27:19 --> URI Class Initialized
INFO - 2018-02-27 18:27:19 --> Router Class Initialized
INFO - 2018-02-27 18:27:19 --> Output Class Initialized
INFO - 2018-02-27 18:27:19 --> Security Class Initialized
DEBUG - 2018-02-27 18:27:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-27 18:27:19 --> Input Class Initialized
INFO - 2018-02-27 18:27:19 --> Language Class Initialized
INFO - 2018-02-27 18:27:19 --> Loader Class Initialized
INFO - 2018-02-27 18:27:19 --> Helper loaded: url_helper
INFO - 2018-02-27 18:27:19 --> Helper loaded: file_helper
INFO - 2018-02-27 18:27:19 --> Helper loaded: email_helper
INFO - 2018-02-27 18:27:19 --> Helper loaded: common_helper
INFO - 2018-02-27 18:27:19 --> Database Driver Class Initialized
DEBUG - 2018-02-27 18:27:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-27 18:27:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-27 18:27:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-27 18:27:19 --> Pagination Class Initialized
INFO - 2018-02-27 18:27:19 --> Helper loaded: form_helper
INFO - 2018-02-27 18:27:19 --> Form Validation Class Initialized
INFO - 2018-02-27 18:27:19 --> Model Class Initialized
INFO - 2018-02-27 18:27:19 --> Controller Class Initialized
DEBUG - 2018-02-27 18:27:19 --> Config file loaded: /var/www/html/project/periodtracker/application/config/rest.php
INFO - 2018-02-27 18:27:19 --> Helper loaded: inflector_helper
INFO - 2018-02-27 18:27:19 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-27 18:27:19 --> Model Class Initialized
INFO - 2018-02-27 18:27:19 --> Model Class Initialized
INFO - 2018-02-27 18:27:19 --> Model Class Initialized
INFO - 2018-02-27 18:27:19 --> Final output sent to browser
DEBUG - 2018-02-27 18:27:19 --> Total execution time: 0.0050
INFO - 2018-02-27 18:27:35 --> Config Class Initialized
INFO - 2018-02-27 18:27:35 --> Hooks Class Initialized
DEBUG - 2018-02-27 18:27:35 --> UTF-8 Support Enabled
INFO - 2018-02-27 18:27:35 --> Utf8 Class Initialized
INFO - 2018-02-27 18:27:35 --> URI Class Initialized
INFO - 2018-02-27 18:27:35 --> Router Class Initialized
INFO - 2018-02-27 18:27:35 --> Output Class Initialized
INFO - 2018-02-27 18:27:35 --> Security Class Initialized
DEBUG - 2018-02-27 18:27:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-27 18:27:35 --> Input Class Initialized
INFO - 2018-02-27 18:27:35 --> Language Class Initialized
INFO - 2018-02-27 18:27:35 --> Loader Class Initialized
INFO - 2018-02-27 18:27:35 --> Helper loaded: url_helper
INFO - 2018-02-27 18:27:35 --> Helper loaded: file_helper
INFO - 2018-02-27 18:27:35 --> Helper loaded: email_helper
INFO - 2018-02-27 18:27:35 --> Helper loaded: common_helper
INFO - 2018-02-27 18:27:35 --> Database Driver Class Initialized
DEBUG - 2018-02-27 18:27:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-27 18:27:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-27 18:27:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-27 18:27:35 --> Pagination Class Initialized
INFO - 2018-02-27 18:27:35 --> Helper loaded: form_helper
INFO - 2018-02-27 18:27:35 --> Form Validation Class Initialized
INFO - 2018-02-27 18:27:35 --> Model Class Initialized
INFO - 2018-02-27 18:27:35 --> Controller Class Initialized
DEBUG - 2018-02-27 18:27:35 --> Config file loaded: /var/www/html/project/periodtracker/application/config/rest.php
INFO - 2018-02-27 18:27:35 --> Helper loaded: inflector_helper
INFO - 2018-02-27 18:27:35 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-27 18:27:35 --> Model Class Initialized
INFO - 2018-02-27 18:27:35 --> Model Class Initialized
INFO - 2018-02-27 18:27:35 --> Model Class Initialized
INFO - 2018-02-27 18:27:35 --> Final output sent to browser
DEBUG - 2018-02-27 18:27:35 --> Total execution time: 0.0049
INFO - 2018-02-27 18:27:43 --> Config Class Initialized
INFO - 2018-02-27 18:27:43 --> Hooks Class Initialized
DEBUG - 2018-02-27 18:27:43 --> UTF-8 Support Enabled
INFO - 2018-02-27 18:27:43 --> Utf8 Class Initialized
INFO - 2018-02-27 18:27:43 --> URI Class Initialized
INFO - 2018-02-27 18:27:43 --> Router Class Initialized
INFO - 2018-02-27 18:27:43 --> Output Class Initialized
INFO - 2018-02-27 18:27:43 --> Security Class Initialized
DEBUG - 2018-02-27 18:27:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-27 18:27:43 --> Input Class Initialized
INFO - 2018-02-27 18:27:43 --> Language Class Initialized
INFO - 2018-02-27 18:27:43 --> Loader Class Initialized
INFO - 2018-02-27 18:27:43 --> Helper loaded: url_helper
INFO - 2018-02-27 18:27:43 --> Helper loaded: file_helper
INFO - 2018-02-27 18:27:43 --> Helper loaded: email_helper
INFO - 2018-02-27 18:27:43 --> Helper loaded: common_helper
INFO - 2018-02-27 18:27:43 --> Database Driver Class Initialized
DEBUG - 2018-02-27 18:27:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-27 18:27:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-27 18:27:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-27 18:27:43 --> Pagination Class Initialized
INFO - 2018-02-27 18:27:43 --> Helper loaded: form_helper
INFO - 2018-02-27 18:27:43 --> Form Validation Class Initialized
INFO - 2018-02-27 18:27:43 --> Model Class Initialized
INFO - 2018-02-27 18:27:43 --> Controller Class Initialized
DEBUG - 2018-02-27 18:27:43 --> Config file loaded: /var/www/html/project/periodtracker/application/config/rest.php
INFO - 2018-02-27 18:27:43 --> Helper loaded: inflector_helper
INFO - 2018-02-27 18:27:43 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-27 18:27:43 --> Model Class Initialized
INFO - 2018-02-27 18:27:43 --> Model Class Initialized
INFO - 2018-02-27 18:27:43 --> Model Class Initialized
INFO - 2018-02-27 18:27:43 --> Final output sent to browser
DEBUG - 2018-02-27 18:27:43 --> Total execution time: 0.0049
INFO - 2018-02-27 18:27:51 --> Config Class Initialized
INFO - 2018-02-27 18:27:51 --> Hooks Class Initialized
DEBUG - 2018-02-27 18:27:51 --> UTF-8 Support Enabled
INFO - 2018-02-27 18:27:51 --> Utf8 Class Initialized
INFO - 2018-02-27 18:27:51 --> URI Class Initialized
INFO - 2018-02-27 18:27:51 --> Router Class Initialized
INFO - 2018-02-27 18:27:51 --> Output Class Initialized
INFO - 2018-02-27 18:27:51 --> Security Class Initialized
DEBUG - 2018-02-27 18:27:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-27 18:27:51 --> Input Class Initialized
INFO - 2018-02-27 18:27:51 --> Language Class Initialized
INFO - 2018-02-27 18:27:51 --> Loader Class Initialized
INFO - 2018-02-27 18:27:51 --> Helper loaded: url_helper
INFO - 2018-02-27 18:27:51 --> Helper loaded: file_helper
INFO - 2018-02-27 18:27:51 --> Helper loaded: email_helper
INFO - 2018-02-27 18:27:51 --> Helper loaded: common_helper
INFO - 2018-02-27 18:27:51 --> Database Driver Class Initialized
DEBUG - 2018-02-27 18:27:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-27 18:27:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-27 18:27:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-27 18:27:51 --> Pagination Class Initialized
INFO - 2018-02-27 18:27:51 --> Helper loaded: form_helper
INFO - 2018-02-27 18:27:51 --> Form Validation Class Initialized
INFO - 2018-02-27 18:27:51 --> Model Class Initialized
INFO - 2018-02-27 18:27:51 --> Controller Class Initialized
DEBUG - 2018-02-27 18:27:51 --> Config file loaded: /var/www/html/project/periodtracker/application/config/rest.php
INFO - 2018-02-27 18:27:51 --> Helper loaded: inflector_helper
INFO - 2018-02-27 18:27:51 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-27 18:27:51 --> Model Class Initialized
INFO - 2018-02-27 18:27:51 --> Model Class Initialized
INFO - 2018-02-27 18:27:51 --> Model Class Initialized
INFO - 2018-02-27 18:27:51 --> Final output sent to browser
DEBUG - 2018-02-27 18:27:51 --> Total execution time: 0.0045
INFO - 2018-02-27 18:28:06 --> Config Class Initialized
INFO - 2018-02-27 18:28:06 --> Hooks Class Initialized
DEBUG - 2018-02-27 18:28:06 --> UTF-8 Support Enabled
INFO - 2018-02-27 18:28:06 --> Utf8 Class Initialized
INFO - 2018-02-27 18:28:06 --> URI Class Initialized
INFO - 2018-02-27 18:28:06 --> Router Class Initialized
INFO - 2018-02-27 18:28:06 --> Output Class Initialized
INFO - 2018-02-27 18:28:06 --> Security Class Initialized
DEBUG - 2018-02-27 18:28:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-27 18:28:06 --> Input Class Initialized
INFO - 2018-02-27 18:28:06 --> Language Class Initialized
INFO - 2018-02-27 18:28:06 --> Loader Class Initialized
INFO - 2018-02-27 18:28:06 --> Helper loaded: url_helper
INFO - 2018-02-27 18:28:06 --> Helper loaded: file_helper
INFO - 2018-02-27 18:28:06 --> Helper loaded: email_helper
INFO - 2018-02-27 18:28:06 --> Helper loaded: common_helper
INFO - 2018-02-27 18:28:06 --> Database Driver Class Initialized
DEBUG - 2018-02-27 18:28:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-27 18:28:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-27 18:28:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-27 18:28:06 --> Pagination Class Initialized
INFO - 2018-02-27 18:28:06 --> Helper loaded: form_helper
INFO - 2018-02-27 18:28:06 --> Form Validation Class Initialized
INFO - 2018-02-27 18:28:06 --> Model Class Initialized
INFO - 2018-02-27 18:28:06 --> Controller Class Initialized
DEBUG - 2018-02-27 18:28:06 --> Config file loaded: /var/www/html/project/periodtracker/application/config/rest.php
INFO - 2018-02-27 18:28:06 --> Helper loaded: inflector_helper
INFO - 2018-02-27 18:28:06 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-27 18:28:06 --> Model Class Initialized
INFO - 2018-02-27 18:28:06 --> Model Class Initialized
INFO - 2018-02-27 18:28:06 --> Model Class Initialized
INFO - 2018-02-27 18:28:06 --> Final output sent to browser
DEBUG - 2018-02-27 18:28:06 --> Total execution time: 0.0047
INFO - 2018-02-27 18:28:17 --> Config Class Initialized
INFO - 2018-02-27 18:28:17 --> Hooks Class Initialized
DEBUG - 2018-02-27 18:28:17 --> UTF-8 Support Enabled
INFO - 2018-02-27 18:28:17 --> Utf8 Class Initialized
INFO - 2018-02-27 18:28:17 --> URI Class Initialized
INFO - 2018-02-27 18:28:17 --> Router Class Initialized
INFO - 2018-02-27 18:28:17 --> Output Class Initialized
INFO - 2018-02-27 18:28:17 --> Security Class Initialized
DEBUG - 2018-02-27 18:28:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-27 18:28:17 --> Input Class Initialized
INFO - 2018-02-27 18:28:17 --> Language Class Initialized
INFO - 2018-02-27 18:28:17 --> Loader Class Initialized
INFO - 2018-02-27 18:28:17 --> Helper loaded: url_helper
INFO - 2018-02-27 18:28:17 --> Helper loaded: file_helper
INFO - 2018-02-27 18:28:17 --> Helper loaded: email_helper
INFO - 2018-02-27 18:28:17 --> Helper loaded: common_helper
INFO - 2018-02-27 18:28:17 --> Database Driver Class Initialized
DEBUG - 2018-02-27 18:28:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-27 18:28:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-27 18:28:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-27 18:28:17 --> Pagination Class Initialized
INFO - 2018-02-27 18:28:17 --> Helper loaded: form_helper
INFO - 2018-02-27 18:28:17 --> Form Validation Class Initialized
INFO - 2018-02-27 18:28:17 --> Model Class Initialized
INFO - 2018-02-27 18:28:17 --> Controller Class Initialized
DEBUG - 2018-02-27 18:28:17 --> Config file loaded: /var/www/html/project/periodtracker/application/config/rest.php
INFO - 2018-02-27 18:28:17 --> Helper loaded: inflector_helper
INFO - 2018-02-27 18:28:17 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-27 18:28:17 --> Model Class Initialized
INFO - 2018-02-27 18:28:17 --> Model Class Initialized
INFO - 2018-02-27 18:28:17 --> Model Class Initialized
INFO - 2018-02-27 18:28:17 --> Final output sent to browser
DEBUG - 2018-02-27 18:28:17 --> Total execution time: 0.0445
INFO - 2018-02-27 18:28:34 --> Config Class Initialized
INFO - 2018-02-27 18:28:34 --> Hooks Class Initialized
DEBUG - 2018-02-27 18:28:34 --> UTF-8 Support Enabled
INFO - 2018-02-27 18:28:34 --> Utf8 Class Initialized
INFO - 2018-02-27 18:28:34 --> URI Class Initialized
INFO - 2018-02-27 18:28:34 --> Router Class Initialized
INFO - 2018-02-27 18:28:34 --> Output Class Initialized
INFO - 2018-02-27 18:28:34 --> Security Class Initialized
DEBUG - 2018-02-27 18:28:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-27 18:28:34 --> Input Class Initialized
INFO - 2018-02-27 18:28:34 --> Language Class Initialized
INFO - 2018-02-27 18:28:34 --> Loader Class Initialized
INFO - 2018-02-27 18:28:34 --> Helper loaded: url_helper
INFO - 2018-02-27 18:28:34 --> Helper loaded: file_helper
INFO - 2018-02-27 18:28:34 --> Helper loaded: email_helper
INFO - 2018-02-27 18:28:34 --> Helper loaded: common_helper
INFO - 2018-02-27 18:28:34 --> Database Driver Class Initialized
DEBUG - 2018-02-27 18:28:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-27 18:28:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-27 18:28:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-27 18:28:34 --> Pagination Class Initialized
INFO - 2018-02-27 18:28:34 --> Helper loaded: form_helper
INFO - 2018-02-27 18:28:34 --> Form Validation Class Initialized
INFO - 2018-02-27 18:28:34 --> Model Class Initialized
INFO - 2018-02-27 18:28:34 --> Controller Class Initialized
DEBUG - 2018-02-27 18:28:34 --> Config file loaded: /var/www/html/project/periodtracker/application/config/rest.php
INFO - 2018-02-27 18:28:34 --> Helper loaded: inflector_helper
INFO - 2018-02-27 18:28:34 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-27 18:28:34 --> Model Class Initialized
INFO - 2018-02-27 18:28:34 --> Model Class Initialized
INFO - 2018-02-27 18:28:34 --> Model Class Initialized
INFO - 2018-02-27 18:28:34 --> Final output sent to browser
DEBUG - 2018-02-27 18:28:34 --> Total execution time: 0.0053
INFO - 2018-02-27 18:29:16 --> Config Class Initialized
INFO - 2018-02-27 18:29:16 --> Hooks Class Initialized
DEBUG - 2018-02-27 18:29:16 --> UTF-8 Support Enabled
INFO - 2018-02-27 18:29:16 --> Utf8 Class Initialized
INFO - 2018-02-27 18:29:16 --> URI Class Initialized
INFO - 2018-02-27 18:29:16 --> Router Class Initialized
INFO - 2018-02-27 18:29:16 --> Output Class Initialized
INFO - 2018-02-27 18:29:16 --> Security Class Initialized
DEBUG - 2018-02-27 18:29:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-27 18:29:16 --> Input Class Initialized
INFO - 2018-02-27 18:29:16 --> Language Class Initialized
INFO - 2018-02-27 18:29:16 --> Loader Class Initialized
INFO - 2018-02-27 18:29:16 --> Helper loaded: url_helper
INFO - 2018-02-27 18:29:16 --> Helper loaded: file_helper
INFO - 2018-02-27 18:29:16 --> Helper loaded: email_helper
INFO - 2018-02-27 18:29:16 --> Helper loaded: common_helper
INFO - 2018-02-27 18:29:16 --> Database Driver Class Initialized
DEBUG - 2018-02-27 18:29:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-27 18:29:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-27 18:29:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-27 18:29:16 --> Pagination Class Initialized
INFO - 2018-02-27 18:29:16 --> Helper loaded: form_helper
INFO - 2018-02-27 18:29:16 --> Form Validation Class Initialized
INFO - 2018-02-27 18:29:16 --> Model Class Initialized
INFO - 2018-02-27 18:29:16 --> Controller Class Initialized
DEBUG - 2018-02-27 18:29:16 --> Config file loaded: /var/www/html/project/periodtracker/application/config/rest.php
INFO - 2018-02-27 18:29:16 --> Helper loaded: inflector_helper
INFO - 2018-02-27 18:29:16 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-27 18:29:16 --> Model Class Initialized
INFO - 2018-02-27 18:29:16 --> Model Class Initialized
INFO - 2018-02-27 18:29:16 --> Model Class Initialized
INFO - 2018-02-27 18:29:41 --> Config Class Initialized
INFO - 2018-02-27 18:29:41 --> Hooks Class Initialized
DEBUG - 2018-02-27 18:29:41 --> UTF-8 Support Enabled
INFO - 2018-02-27 18:29:41 --> Utf8 Class Initialized
INFO - 2018-02-27 18:29:41 --> URI Class Initialized
INFO - 2018-02-27 18:29:41 --> Router Class Initialized
INFO - 2018-02-27 18:29:41 --> Output Class Initialized
INFO - 2018-02-27 18:29:41 --> Security Class Initialized
DEBUG - 2018-02-27 18:29:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-27 18:29:41 --> Input Class Initialized
INFO - 2018-02-27 18:29:41 --> Language Class Initialized
INFO - 2018-02-27 18:29:41 --> Loader Class Initialized
INFO - 2018-02-27 18:29:41 --> Helper loaded: url_helper
INFO - 2018-02-27 18:29:41 --> Helper loaded: file_helper
INFO - 2018-02-27 18:29:41 --> Helper loaded: email_helper
INFO - 2018-02-27 18:29:41 --> Helper loaded: common_helper
INFO - 2018-02-27 18:29:41 --> Database Driver Class Initialized
DEBUG - 2018-02-27 18:29:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-27 18:29:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-27 18:29:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-27 18:29:41 --> Pagination Class Initialized
INFO - 2018-02-27 18:29:41 --> Helper loaded: form_helper
INFO - 2018-02-27 18:29:41 --> Form Validation Class Initialized
INFO - 2018-02-27 18:29:41 --> Model Class Initialized
INFO - 2018-02-27 18:29:41 --> Controller Class Initialized
DEBUG - 2018-02-27 18:29:41 --> Config file loaded: /var/www/html/project/periodtracker/application/config/rest.php
INFO - 2018-02-27 18:29:41 --> Helper loaded: inflector_helper
INFO - 2018-02-27 18:29:41 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-27 18:29:41 --> Model Class Initialized
INFO - 2018-02-27 18:29:41 --> Model Class Initialized
INFO - 2018-02-27 18:29:41 --> Model Class Initialized
INFO - 2018-02-27 18:29:47 --> Config Class Initialized
INFO - 2018-02-27 18:29:47 --> Hooks Class Initialized
DEBUG - 2018-02-27 18:29:47 --> UTF-8 Support Enabled
INFO - 2018-02-27 18:29:47 --> Utf8 Class Initialized
INFO - 2018-02-27 18:29:47 --> URI Class Initialized
INFO - 2018-02-27 18:29:47 --> Router Class Initialized
INFO - 2018-02-27 18:29:47 --> Output Class Initialized
INFO - 2018-02-27 18:29:47 --> Security Class Initialized
DEBUG - 2018-02-27 18:29:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-27 18:29:47 --> Input Class Initialized
INFO - 2018-02-27 18:29:47 --> Language Class Initialized
INFO - 2018-02-27 18:29:47 --> Loader Class Initialized
INFO - 2018-02-27 18:29:47 --> Helper loaded: url_helper
INFO - 2018-02-27 18:29:47 --> Helper loaded: file_helper
INFO - 2018-02-27 18:29:47 --> Helper loaded: email_helper
INFO - 2018-02-27 18:29:47 --> Helper loaded: common_helper
INFO - 2018-02-27 18:29:47 --> Database Driver Class Initialized
DEBUG - 2018-02-27 18:29:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-27 18:29:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-27 18:29:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-27 18:29:47 --> Pagination Class Initialized
INFO - 2018-02-27 18:29:47 --> Helper loaded: form_helper
INFO - 2018-02-27 18:29:47 --> Form Validation Class Initialized
INFO - 2018-02-27 18:29:47 --> Model Class Initialized
INFO - 2018-02-27 18:29:47 --> Controller Class Initialized
DEBUG - 2018-02-27 18:29:47 --> Config file loaded: /var/www/html/project/periodtracker/application/config/rest.php
INFO - 2018-02-27 18:29:47 --> Helper loaded: inflector_helper
INFO - 2018-02-27 18:29:47 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-27 18:29:47 --> Model Class Initialized
INFO - 2018-02-27 18:29:47 --> Model Class Initialized
INFO - 2018-02-27 18:29:47 --> Model Class Initialized
INFO - 2018-02-27 18:30:06 --> Config Class Initialized
INFO - 2018-02-27 18:30:06 --> Hooks Class Initialized
DEBUG - 2018-02-27 18:30:06 --> UTF-8 Support Enabled
INFO - 2018-02-27 18:30:06 --> Utf8 Class Initialized
INFO - 2018-02-27 18:30:06 --> URI Class Initialized
INFO - 2018-02-27 18:30:06 --> Router Class Initialized
INFO - 2018-02-27 18:30:06 --> Output Class Initialized
INFO - 2018-02-27 18:30:06 --> Security Class Initialized
DEBUG - 2018-02-27 18:30:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-27 18:30:06 --> Input Class Initialized
INFO - 2018-02-27 18:30:06 --> Language Class Initialized
INFO - 2018-02-27 18:30:06 --> Loader Class Initialized
INFO - 2018-02-27 18:30:06 --> Helper loaded: url_helper
INFO - 2018-02-27 18:30:06 --> Helper loaded: file_helper
INFO - 2018-02-27 18:30:06 --> Helper loaded: email_helper
INFO - 2018-02-27 18:30:06 --> Helper loaded: common_helper
INFO - 2018-02-27 18:30:06 --> Database Driver Class Initialized
DEBUG - 2018-02-27 18:30:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-27 18:30:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-27 18:30:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-27 18:30:06 --> Pagination Class Initialized
INFO - 2018-02-27 18:30:06 --> Helper loaded: form_helper
INFO - 2018-02-27 18:30:06 --> Form Validation Class Initialized
INFO - 2018-02-27 18:30:06 --> Model Class Initialized
INFO - 2018-02-27 18:30:06 --> Controller Class Initialized
DEBUG - 2018-02-27 18:30:06 --> Config file loaded: /var/www/html/project/periodtracker/application/config/rest.php
INFO - 2018-02-27 18:30:06 --> Helper loaded: inflector_helper
INFO - 2018-02-27 18:30:06 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-27 18:30:06 --> Model Class Initialized
INFO - 2018-02-27 18:30:06 --> Model Class Initialized
INFO - 2018-02-27 18:30:06 --> Model Class Initialized
INFO - 2018-02-27 18:30:06 --> Final output sent to browser
DEBUG - 2018-02-27 18:30:06 --> Total execution time: 0.0061
INFO - 2018-02-27 18:30:51 --> Config Class Initialized
INFO - 2018-02-27 18:30:51 --> Hooks Class Initialized
DEBUG - 2018-02-27 18:30:51 --> UTF-8 Support Enabled
INFO - 2018-02-27 18:30:51 --> Utf8 Class Initialized
INFO - 2018-02-27 18:30:51 --> URI Class Initialized
INFO - 2018-02-27 18:30:51 --> Router Class Initialized
INFO - 2018-02-27 18:30:51 --> Output Class Initialized
INFO - 2018-02-27 18:30:51 --> Security Class Initialized
DEBUG - 2018-02-27 18:30:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-27 18:30:51 --> Input Class Initialized
INFO - 2018-02-27 18:30:51 --> Language Class Initialized
INFO - 2018-02-27 18:30:51 --> Loader Class Initialized
INFO - 2018-02-27 18:30:51 --> Helper loaded: url_helper
INFO - 2018-02-27 18:30:51 --> Helper loaded: file_helper
INFO - 2018-02-27 18:30:51 --> Helper loaded: email_helper
INFO - 2018-02-27 18:30:51 --> Helper loaded: common_helper
INFO - 2018-02-27 18:30:51 --> Database Driver Class Initialized
DEBUG - 2018-02-27 18:30:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-27 18:30:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-27 18:30:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-27 18:30:51 --> Pagination Class Initialized
INFO - 2018-02-27 18:30:51 --> Helper loaded: form_helper
INFO - 2018-02-27 18:30:51 --> Form Validation Class Initialized
INFO - 2018-02-27 18:30:51 --> Model Class Initialized
INFO - 2018-02-27 18:30:51 --> Controller Class Initialized
DEBUG - 2018-02-27 18:30:51 --> Config file loaded: /var/www/html/project/periodtracker/application/config/rest.php
INFO - 2018-02-27 18:30:51 --> Helper loaded: inflector_helper
INFO - 2018-02-27 18:30:51 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-27 18:30:51 --> Model Class Initialized
INFO - 2018-02-27 18:30:51 --> Model Class Initialized
INFO - 2018-02-27 18:30:51 --> Model Class Initialized
INFO - 2018-02-27 18:31:23 --> Config Class Initialized
INFO - 2018-02-27 18:31:23 --> Hooks Class Initialized
DEBUG - 2018-02-27 18:31:23 --> UTF-8 Support Enabled
INFO - 2018-02-27 18:31:23 --> Utf8 Class Initialized
INFO - 2018-02-27 18:31:23 --> URI Class Initialized
INFO - 2018-02-27 18:31:23 --> Router Class Initialized
INFO - 2018-02-27 18:31:23 --> Output Class Initialized
INFO - 2018-02-27 18:31:23 --> Security Class Initialized
DEBUG - 2018-02-27 18:31:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-27 18:31:23 --> Input Class Initialized
INFO - 2018-02-27 18:31:23 --> Language Class Initialized
INFO - 2018-02-27 18:31:23 --> Loader Class Initialized
INFO - 2018-02-27 18:31:23 --> Helper loaded: url_helper
INFO - 2018-02-27 18:31:23 --> Helper loaded: file_helper
INFO - 2018-02-27 18:31:23 --> Helper loaded: email_helper
INFO - 2018-02-27 18:31:23 --> Helper loaded: common_helper
INFO - 2018-02-27 18:31:23 --> Database Driver Class Initialized
DEBUG - 2018-02-27 18:31:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-27 18:31:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-27 18:31:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-27 18:31:23 --> Pagination Class Initialized
INFO - 2018-02-27 18:31:23 --> Helper loaded: form_helper
INFO - 2018-02-27 18:31:23 --> Form Validation Class Initialized
INFO - 2018-02-27 18:31:23 --> Model Class Initialized
INFO - 2018-02-27 18:31:23 --> Controller Class Initialized
DEBUG - 2018-02-27 18:31:23 --> Config file loaded: /var/www/html/project/periodtracker/application/config/rest.php
INFO - 2018-02-27 18:31:23 --> Helper loaded: inflector_helper
INFO - 2018-02-27 18:31:23 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-27 18:31:23 --> Model Class Initialized
INFO - 2018-02-27 18:31:23 --> Model Class Initialized
INFO - 2018-02-27 18:31:23 --> Model Class Initialized
INFO - 2018-02-27 18:31:23 --> Final output sent to browser
DEBUG - 2018-02-27 18:31:23 --> Total execution time: 0.0412
INFO - 2018-02-27 18:54:57 --> Config Class Initialized
INFO - 2018-02-27 18:54:57 --> Hooks Class Initialized
DEBUG - 2018-02-27 18:54:57 --> UTF-8 Support Enabled
INFO - 2018-02-27 18:54:57 --> Utf8 Class Initialized
INFO - 2018-02-27 18:54:57 --> URI Class Initialized
INFO - 2018-02-27 18:54:57 --> Router Class Initialized
INFO - 2018-02-27 18:54:57 --> Output Class Initialized
INFO - 2018-02-27 18:54:57 --> Security Class Initialized
DEBUG - 2018-02-27 18:54:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-27 18:54:57 --> Input Class Initialized
INFO - 2018-02-27 18:54:57 --> Language Class Initialized
INFO - 2018-02-27 18:54:57 --> Loader Class Initialized
INFO - 2018-02-27 18:54:57 --> Helper loaded: url_helper
INFO - 2018-02-27 18:54:57 --> Helper loaded: file_helper
INFO - 2018-02-27 18:54:57 --> Helper loaded: email_helper
INFO - 2018-02-27 18:54:57 --> Helper loaded: common_helper
INFO - 2018-02-27 18:54:57 --> Database Driver Class Initialized
DEBUG - 2018-02-27 18:54:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-27 18:54:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-27 18:54:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-27 18:54:57 --> Pagination Class Initialized
INFO - 2018-02-27 18:54:57 --> Helper loaded: form_helper
INFO - 2018-02-27 18:54:57 --> Form Validation Class Initialized
INFO - 2018-02-27 18:54:57 --> Model Class Initialized
INFO - 2018-02-27 18:54:57 --> Controller Class Initialized
DEBUG - 2018-02-27 18:54:57 --> Config file loaded: /var/www/html/project/periodtracker/application/config/rest.php
INFO - 2018-02-27 18:54:57 --> Helper loaded: inflector_helper
INFO - 2018-02-27 18:54:57 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-27 18:54:57 --> Model Class Initialized
INFO - 2018-02-27 18:54:57 --> Model Class Initialized
INFO - 2018-02-27 18:54:57 --> Model Class Initialized
INFO - 2018-02-27 18:54:57 --> Final output sent to browser
DEBUG - 2018-02-27 18:54:57 --> Total execution time: 0.0044
INFO - 2018-02-27 18:55:06 --> Config Class Initialized
INFO - 2018-02-27 18:55:06 --> Hooks Class Initialized
DEBUG - 2018-02-27 18:55:06 --> UTF-8 Support Enabled
INFO - 2018-02-27 18:55:06 --> Utf8 Class Initialized
INFO - 2018-02-27 18:55:06 --> URI Class Initialized
INFO - 2018-02-27 18:55:06 --> Router Class Initialized
INFO - 2018-02-27 18:55:06 --> Output Class Initialized
INFO - 2018-02-27 18:55:06 --> Security Class Initialized
DEBUG - 2018-02-27 18:55:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-27 18:55:06 --> Input Class Initialized
INFO - 2018-02-27 18:55:06 --> Language Class Initialized
INFO - 2018-02-27 18:55:06 --> Loader Class Initialized
INFO - 2018-02-27 18:55:06 --> Helper loaded: url_helper
INFO - 2018-02-27 18:55:06 --> Helper loaded: file_helper
INFO - 2018-02-27 18:55:06 --> Helper loaded: email_helper
INFO - 2018-02-27 18:55:06 --> Helper loaded: common_helper
INFO - 2018-02-27 18:55:06 --> Database Driver Class Initialized
DEBUG - 2018-02-27 18:55:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-27 18:55:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-27 18:55:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-27 18:55:06 --> Pagination Class Initialized
INFO - 2018-02-27 18:55:06 --> Helper loaded: form_helper
INFO - 2018-02-27 18:55:06 --> Form Validation Class Initialized
INFO - 2018-02-27 18:55:06 --> Model Class Initialized
INFO - 2018-02-27 18:55:06 --> Controller Class Initialized
DEBUG - 2018-02-27 18:55:06 --> Config file loaded: /var/www/html/project/periodtracker/application/config/rest.php
INFO - 2018-02-27 18:55:06 --> Helper loaded: inflector_helper
INFO - 2018-02-27 18:55:06 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-27 18:55:06 --> Model Class Initialized
INFO - 2018-02-27 18:55:06 --> Model Class Initialized
INFO - 2018-02-27 18:55:06 --> Model Class Initialized
INFO - 2018-02-27 18:55:06 --> Final output sent to browser
DEBUG - 2018-02-27 18:55:06 --> Total execution time: 0.0377

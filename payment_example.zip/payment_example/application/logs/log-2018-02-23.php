<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2018-02-23 10:12:41 --> Config Class Initialized
INFO - 2018-02-23 10:12:41 --> Hooks Class Initialized
DEBUG - 2018-02-23 10:12:41 --> UTF-8 Support Enabled
INFO - 2018-02-23 10:12:41 --> Utf8 Class Initialized
INFO - 2018-02-23 10:12:41 --> URI Class Initialized
INFO - 2018-02-23 10:12:41 --> Router Class Initialized
INFO - 2018-02-23 10:12:41 --> Output Class Initialized
INFO - 2018-02-23 10:12:41 --> Security Class Initialized
DEBUG - 2018-02-23 10:12:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-23 10:12:41 --> Input Class Initialized
INFO - 2018-02-23 10:12:41 --> Language Class Initialized
INFO - 2018-02-23 10:12:41 --> Loader Class Initialized
INFO - 2018-02-23 10:12:41 --> Helper loaded: url_helper
INFO - 2018-02-23 10:12:41 --> Helper loaded: file_helper
INFO - 2018-02-23 10:12:41 --> Helper loaded: email_helper
INFO - 2018-02-23 10:12:41 --> Helper loaded: common_helper
INFO - 2018-02-23 10:12:42 --> Database Driver Class Initialized
DEBUG - 2018-02-23 10:12:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-23 10:12:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-23 10:12:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-23 10:12:42 --> Pagination Class Initialized
INFO - 2018-02-23 10:12:42 --> Helper loaded: form_helper
INFO - 2018-02-23 10:12:42 --> Form Validation Class Initialized
INFO - 2018-02-23 10:12:42 --> Model Class Initialized
INFO - 2018-02-23 10:12:42 --> Controller Class Initialized
INFO - 2018-02-23 10:12:42 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-23 10:12:42 --> Config Class Initialized
INFO - 2018-02-23 10:12:42 --> Hooks Class Initialized
DEBUG - 2018-02-23 10:12:42 --> UTF-8 Support Enabled
INFO - 2018-02-23 10:12:42 --> Utf8 Class Initialized
INFO - 2018-02-23 10:12:42 --> URI Class Initialized
DEBUG - 2018-02-23 10:12:42 --> No URI present. Default controller set.
INFO - 2018-02-23 10:12:42 --> Router Class Initialized
INFO - 2018-02-23 10:12:42 --> Output Class Initialized
INFO - 2018-02-23 10:12:42 --> Security Class Initialized
DEBUG - 2018-02-23 10:12:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-23 10:12:42 --> Input Class Initialized
INFO - 2018-02-23 10:12:42 --> Language Class Initialized
INFO - 2018-02-23 10:12:42 --> Loader Class Initialized
INFO - 2018-02-23 10:12:42 --> Helper loaded: url_helper
INFO - 2018-02-23 10:12:42 --> Helper loaded: file_helper
INFO - 2018-02-23 10:12:42 --> Helper loaded: email_helper
INFO - 2018-02-23 10:12:42 --> Helper loaded: common_helper
INFO - 2018-02-23 10:12:42 --> Database Driver Class Initialized
DEBUG - 2018-02-23 10:12:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-23 10:12:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-23 10:12:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-23 10:12:42 --> Pagination Class Initialized
INFO - 2018-02-23 10:12:42 --> Helper loaded: form_helper
INFO - 2018-02-23 10:12:42 --> Form Validation Class Initialized
INFO - 2018-02-23 10:12:42 --> Model Class Initialized
INFO - 2018-02-23 10:12:42 --> Controller Class Initialized
INFO - 2018-02-23 10:12:42 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-23 10:12:42 --> Model Class Initialized
INFO - 2018-02-23 10:12:42 --> Model Class Initialized
INFO - 2018-02-23 10:12:42 --> File loaded: /var/www/html/project/radio/application/views/index/index.php
INFO - 2018-02-23 10:12:42 --> Final output sent to browser
DEBUG - 2018-02-23 10:12:42 --> Total execution time: 0.0377
INFO - 2018-02-23 10:12:49 --> Config Class Initialized
INFO - 2018-02-23 10:12:49 --> Hooks Class Initialized
DEBUG - 2018-02-23 10:12:49 --> UTF-8 Support Enabled
INFO - 2018-02-23 10:12:49 --> Utf8 Class Initialized
INFO - 2018-02-23 10:12:49 --> URI Class Initialized
INFO - 2018-02-23 10:12:49 --> Router Class Initialized
INFO - 2018-02-23 10:12:49 --> Output Class Initialized
INFO - 2018-02-23 10:12:49 --> Security Class Initialized
DEBUG - 2018-02-23 10:12:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-23 10:12:49 --> Input Class Initialized
INFO - 2018-02-23 10:12:49 --> Language Class Initialized
INFO - 2018-02-23 10:12:49 --> Loader Class Initialized
INFO - 2018-02-23 10:12:49 --> Helper loaded: url_helper
INFO - 2018-02-23 10:12:49 --> Helper loaded: file_helper
INFO - 2018-02-23 10:12:49 --> Helper loaded: email_helper
INFO - 2018-02-23 10:12:49 --> Helper loaded: common_helper
INFO - 2018-02-23 10:12:49 --> Database Driver Class Initialized
DEBUG - 2018-02-23 10:12:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-23 10:12:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-23 10:12:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-23 10:12:49 --> Pagination Class Initialized
INFO - 2018-02-23 10:12:49 --> Helper loaded: form_helper
INFO - 2018-02-23 10:12:49 --> Form Validation Class Initialized
INFO - 2018-02-23 10:12:49 --> Model Class Initialized
INFO - 2018-02-23 10:12:49 --> Controller Class Initialized
INFO - 2018-02-23 10:12:49 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-23 10:12:49 --> Model Class Initialized
INFO - 2018-02-23 10:12:49 --> Model Class Initialized
ERROR - 2018-02-23 10:12:49 --> Severity: Notice --> Undefined index: remember_me /var/www/html/project/radio/application/controllers/Index.php 74
INFO - 2018-02-23 10:12:49 --> Config Class Initialized
INFO - 2018-02-23 10:12:49 --> Hooks Class Initialized
DEBUG - 2018-02-23 10:12:49 --> UTF-8 Support Enabled
INFO - 2018-02-23 10:12:49 --> Utf8 Class Initialized
INFO - 2018-02-23 10:12:49 --> URI Class Initialized
INFO - 2018-02-23 10:12:49 --> Router Class Initialized
INFO - 2018-02-23 10:12:49 --> Output Class Initialized
INFO - 2018-02-23 10:12:49 --> Security Class Initialized
DEBUG - 2018-02-23 10:12:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-23 10:12:49 --> Input Class Initialized
INFO - 2018-02-23 10:12:49 --> Language Class Initialized
INFO - 2018-02-23 10:12:49 --> Loader Class Initialized
INFO - 2018-02-23 10:12:49 --> Helper loaded: url_helper
INFO - 2018-02-23 10:12:49 --> Helper loaded: file_helper
INFO - 2018-02-23 10:12:49 --> Helper loaded: email_helper
INFO - 2018-02-23 10:12:49 --> Helper loaded: common_helper
INFO - 2018-02-23 10:12:49 --> Database Driver Class Initialized
DEBUG - 2018-02-23 10:12:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-23 10:12:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-23 10:12:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-23 10:12:49 --> Pagination Class Initialized
INFO - 2018-02-23 10:12:49 --> Helper loaded: form_helper
INFO - 2018-02-23 10:12:49 --> Form Validation Class Initialized
INFO - 2018-02-23 10:12:49 --> Model Class Initialized
INFO - 2018-02-23 10:12:49 --> Controller Class Initialized
INFO - 2018-02-23 10:12:49 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-23 10:12:49 --> Model Class Initialized
INFO - 2018-02-23 10:12:49 --> Model Class Initialized
INFO - 2018-02-23 10:12:49 --> Model Class Initialized
INFO - 2018-02-23 10:12:49 --> Model Class Initialized
INFO - 2018-02-23 10:12:49 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-23 10:12:49 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-23 10:12:49 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-23 10:12:49 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-23 10:12:49 --> File loaded: /var/www/html/project/radio/application/views/dashboard/index.php
INFO - 2018-02-23 10:12:49 --> Final output sent to browser
DEBUG - 2018-02-23 10:12:49 --> Total execution time: 0.2247

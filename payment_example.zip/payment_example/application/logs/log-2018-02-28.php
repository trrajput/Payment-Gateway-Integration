<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2018-02-28 10:14:31 --> Config Class Initialized
INFO - 2018-02-28 10:14:31 --> Hooks Class Initialized
DEBUG - 2018-02-28 10:14:31 --> UTF-8 Support Enabled
INFO - 2018-02-28 10:14:31 --> Utf8 Class Initialized
INFO - 2018-02-28 10:14:31 --> URI Class Initialized
INFO - 2018-02-28 10:14:31 --> Router Class Initialized
INFO - 2018-02-28 10:14:31 --> Output Class Initialized
INFO - 2018-02-28 10:14:31 --> Security Class Initialized
DEBUG - 2018-02-28 10:14:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-28 10:14:31 --> Input Class Initialized
INFO - 2018-02-28 10:14:31 --> Language Class Initialized
INFO - 2018-02-28 10:14:31 --> Loader Class Initialized
INFO - 2018-02-28 10:14:31 --> Helper loaded: url_helper
INFO - 2018-02-28 10:14:31 --> Helper loaded: file_helper
INFO - 2018-02-28 10:14:31 --> Helper loaded: email_helper
INFO - 2018-02-28 10:14:31 --> Helper loaded: common_helper
INFO - 2018-02-28 10:14:31 --> Database Driver Class Initialized
DEBUG - 2018-02-28 10:14:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-28 10:14:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-28 10:14:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-28 10:14:31 --> Pagination Class Initialized
INFO - 2018-02-28 10:14:31 --> Helper loaded: form_helper
INFO - 2018-02-28 10:14:31 --> Form Validation Class Initialized
INFO - 2018-02-28 10:14:31 --> Model Class Initialized
INFO - 2018-02-28 10:14:31 --> Controller Class Initialized
DEBUG - 2018-02-28 10:14:31 --> Config file loaded: /var/www/html/project/periodtracker/application/config/rest.php
INFO - 2018-02-28 10:14:31 --> Helper loaded: inflector_helper
INFO - 2018-02-28 10:14:31 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-28 10:14:31 --> Model Class Initialized
INFO - 2018-02-28 10:14:31 --> Model Class Initialized
INFO - 2018-02-28 10:14:31 --> Model Class Initialized
INFO - 2018-02-28 10:14:31 --> Final output sent to browser
DEBUG - 2018-02-28 10:14:31 --> Total execution time: 0.1667
INFO - 2018-02-28 10:14:37 --> Config Class Initialized
INFO - 2018-02-28 10:14:37 --> Hooks Class Initialized
DEBUG - 2018-02-28 10:14:37 --> UTF-8 Support Enabled
INFO - 2018-02-28 10:14:37 --> Utf8 Class Initialized
INFO - 2018-02-28 10:14:37 --> URI Class Initialized
INFO - 2018-02-28 10:14:37 --> Router Class Initialized
INFO - 2018-02-28 10:14:37 --> Output Class Initialized
INFO - 2018-02-28 10:14:37 --> Security Class Initialized
DEBUG - 2018-02-28 10:14:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-28 10:14:37 --> Input Class Initialized
INFO - 2018-02-28 10:14:37 --> Language Class Initialized
INFO - 2018-02-28 10:14:37 --> Loader Class Initialized
INFO - 2018-02-28 10:14:37 --> Helper loaded: url_helper
INFO - 2018-02-28 10:14:37 --> Helper loaded: file_helper
INFO - 2018-02-28 10:14:37 --> Helper loaded: email_helper
INFO - 2018-02-28 10:14:37 --> Helper loaded: common_helper
INFO - 2018-02-28 10:14:37 --> Database Driver Class Initialized
DEBUG - 2018-02-28 10:14:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-28 10:14:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-28 10:14:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-28 10:14:37 --> Pagination Class Initialized
INFO - 2018-02-28 10:14:37 --> Helper loaded: form_helper
INFO - 2018-02-28 10:14:37 --> Form Validation Class Initialized
INFO - 2018-02-28 10:14:37 --> Model Class Initialized
INFO - 2018-02-28 10:14:37 --> Controller Class Initialized
DEBUG - 2018-02-28 10:14:37 --> Config file loaded: /var/www/html/project/periodtracker/application/config/rest.php
INFO - 2018-02-28 10:14:37 --> Helper loaded: inflector_helper
INFO - 2018-02-28 10:14:37 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-28 10:14:37 --> Model Class Initialized
INFO - 2018-02-28 10:14:37 --> Model Class Initialized
INFO - 2018-02-28 10:14:37 --> Model Class Initialized
INFO - 2018-02-28 10:14:37 --> Final output sent to browser
DEBUG - 2018-02-28 10:14:37 --> Total execution time: 0.0094
INFO - 2018-02-28 10:14:39 --> Config Class Initialized
INFO - 2018-02-28 10:14:39 --> Hooks Class Initialized
DEBUG - 2018-02-28 10:14:39 --> UTF-8 Support Enabled
INFO - 2018-02-28 10:14:39 --> Utf8 Class Initialized
INFO - 2018-02-28 10:14:39 --> URI Class Initialized
INFO - 2018-02-28 10:14:39 --> Router Class Initialized
INFO - 2018-02-28 10:14:39 --> Output Class Initialized
INFO - 2018-02-28 10:14:39 --> Security Class Initialized
DEBUG - 2018-02-28 10:14:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-28 10:14:39 --> Input Class Initialized
INFO - 2018-02-28 10:14:39 --> Language Class Initialized
INFO - 2018-02-28 10:14:39 --> Loader Class Initialized
INFO - 2018-02-28 10:14:39 --> Helper loaded: url_helper
INFO - 2018-02-28 10:14:39 --> Helper loaded: file_helper
INFO - 2018-02-28 10:14:39 --> Helper loaded: email_helper
INFO - 2018-02-28 10:14:39 --> Helper loaded: common_helper
INFO - 2018-02-28 10:14:39 --> Database Driver Class Initialized
DEBUG - 2018-02-28 10:14:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-28 10:14:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-28 10:14:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-28 10:14:39 --> Pagination Class Initialized
INFO - 2018-02-28 10:14:39 --> Helper loaded: form_helper
INFO - 2018-02-28 10:14:39 --> Form Validation Class Initialized
INFO - 2018-02-28 10:14:39 --> Model Class Initialized
INFO - 2018-02-28 10:14:39 --> Controller Class Initialized
DEBUG - 2018-02-28 10:14:39 --> Config file loaded: /var/www/html/project/periodtracker/application/config/rest.php
INFO - 2018-02-28 10:14:39 --> Helper loaded: inflector_helper
INFO - 2018-02-28 10:14:39 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-28 10:14:39 --> Model Class Initialized
INFO - 2018-02-28 10:14:39 --> Model Class Initialized
INFO - 2018-02-28 10:14:39 --> Model Class Initialized
INFO - 2018-02-28 10:14:39 --> Final output sent to browser
DEBUG - 2018-02-28 10:14:39 --> Total execution time: 0.0054
INFO - 2018-02-28 10:14:44 --> Config Class Initialized
INFO - 2018-02-28 10:14:44 --> Hooks Class Initialized
DEBUG - 2018-02-28 10:14:44 --> UTF-8 Support Enabled
INFO - 2018-02-28 10:14:44 --> Utf8 Class Initialized
INFO - 2018-02-28 10:14:44 --> URI Class Initialized
INFO - 2018-02-28 10:14:44 --> Router Class Initialized
INFO - 2018-02-28 10:14:44 --> Output Class Initialized
INFO - 2018-02-28 10:14:44 --> Security Class Initialized
DEBUG - 2018-02-28 10:14:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-28 10:14:44 --> Input Class Initialized
INFO - 2018-02-28 10:14:44 --> Language Class Initialized
INFO - 2018-02-28 10:14:44 --> Loader Class Initialized
INFO - 2018-02-28 10:14:44 --> Helper loaded: url_helper
INFO - 2018-02-28 10:14:44 --> Helper loaded: file_helper
INFO - 2018-02-28 10:14:44 --> Helper loaded: email_helper
INFO - 2018-02-28 10:14:44 --> Helper loaded: common_helper
INFO - 2018-02-28 10:14:44 --> Database Driver Class Initialized
DEBUG - 2018-02-28 10:14:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-28 10:14:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-28 10:14:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-28 10:14:44 --> Pagination Class Initialized
INFO - 2018-02-28 10:14:44 --> Helper loaded: form_helper
INFO - 2018-02-28 10:14:44 --> Form Validation Class Initialized
INFO - 2018-02-28 10:14:44 --> Model Class Initialized
INFO - 2018-02-28 10:14:44 --> Controller Class Initialized
DEBUG - 2018-02-28 10:14:44 --> Config file loaded: /var/www/html/project/periodtracker/application/config/rest.php
INFO - 2018-02-28 10:14:44 --> Helper loaded: inflector_helper
INFO - 2018-02-28 10:14:44 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-28 10:14:44 --> Model Class Initialized
INFO - 2018-02-28 10:14:44 --> Model Class Initialized
INFO - 2018-02-28 10:14:44 --> Model Class Initialized
INFO - 2018-02-28 10:14:44 --> Final output sent to browser
DEBUG - 2018-02-28 10:14:44 --> Total execution time: 0.0060
INFO - 2018-02-28 10:14:52 --> Config Class Initialized
INFO - 2018-02-28 10:14:52 --> Hooks Class Initialized
DEBUG - 2018-02-28 10:14:52 --> UTF-8 Support Enabled
INFO - 2018-02-28 10:14:52 --> Utf8 Class Initialized
INFO - 2018-02-28 10:14:52 --> URI Class Initialized
INFO - 2018-02-28 10:14:52 --> Router Class Initialized
INFO - 2018-02-28 10:14:52 --> Output Class Initialized
INFO - 2018-02-28 10:14:52 --> Security Class Initialized
DEBUG - 2018-02-28 10:14:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-28 10:14:52 --> Input Class Initialized
INFO - 2018-02-28 10:14:52 --> Language Class Initialized
INFO - 2018-02-28 10:14:52 --> Loader Class Initialized
INFO - 2018-02-28 10:14:52 --> Helper loaded: url_helper
INFO - 2018-02-28 10:14:52 --> Helper loaded: file_helper
INFO - 2018-02-28 10:14:52 --> Helper loaded: email_helper
INFO - 2018-02-28 10:14:52 --> Helper loaded: common_helper
INFO - 2018-02-28 10:14:52 --> Database Driver Class Initialized
DEBUG - 2018-02-28 10:14:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-28 10:14:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-28 10:14:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-28 10:14:52 --> Pagination Class Initialized
INFO - 2018-02-28 10:14:52 --> Helper loaded: form_helper
INFO - 2018-02-28 10:14:52 --> Form Validation Class Initialized
INFO - 2018-02-28 10:14:52 --> Model Class Initialized
INFO - 2018-02-28 10:14:52 --> Controller Class Initialized
DEBUG - 2018-02-28 10:14:52 --> Config file loaded: /var/www/html/project/periodtracker/application/config/rest.php
INFO - 2018-02-28 10:14:52 --> Helper loaded: inflector_helper
INFO - 2018-02-28 10:14:52 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-28 10:14:52 --> Model Class Initialized
INFO - 2018-02-28 10:14:52 --> Model Class Initialized
INFO - 2018-02-28 10:14:52 --> Model Class Initialized
INFO - 2018-02-28 10:14:52 --> Final output sent to browser
DEBUG - 2018-02-28 10:14:52 --> Total execution time: 0.0554
INFO - 2018-02-28 10:17:55 --> Config Class Initialized
INFO - 2018-02-28 10:17:55 --> Hooks Class Initialized
DEBUG - 2018-02-28 10:17:55 --> UTF-8 Support Enabled
INFO - 2018-02-28 10:17:55 --> Utf8 Class Initialized
INFO - 2018-02-28 10:17:55 --> URI Class Initialized
INFO - 2018-02-28 10:17:55 --> Router Class Initialized
INFO - 2018-02-28 10:17:55 --> Output Class Initialized
INFO - 2018-02-28 10:17:55 --> Security Class Initialized
DEBUG - 2018-02-28 10:17:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-28 10:17:55 --> Input Class Initialized
INFO - 2018-02-28 10:17:55 --> Language Class Initialized
INFO - 2018-02-28 10:17:55 --> Loader Class Initialized
INFO - 2018-02-28 10:17:55 --> Helper loaded: url_helper
INFO - 2018-02-28 10:17:55 --> Helper loaded: file_helper
INFO - 2018-02-28 10:17:55 --> Helper loaded: email_helper
INFO - 2018-02-28 10:17:55 --> Helper loaded: common_helper
INFO - 2018-02-28 10:17:55 --> Database Driver Class Initialized
DEBUG - 2018-02-28 10:17:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-28 10:17:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-28 10:17:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-28 10:17:55 --> Pagination Class Initialized
INFO - 2018-02-28 10:17:55 --> Helper loaded: form_helper
INFO - 2018-02-28 10:17:55 --> Form Validation Class Initialized
INFO - 2018-02-28 10:17:55 --> Model Class Initialized
INFO - 2018-02-28 10:17:55 --> Controller Class Initialized
DEBUG - 2018-02-28 10:17:55 --> Config file loaded: /var/www/html/project/periodtracker/application/config/rest.php
INFO - 2018-02-28 10:17:55 --> Helper loaded: inflector_helper
INFO - 2018-02-28 10:17:55 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-28 10:17:55 --> Model Class Initialized
INFO - 2018-02-28 10:17:55 --> Model Class Initialized
INFO - 2018-02-28 10:17:55 --> Model Class Initialized
ERROR - 2018-02-28 10:17:55 --> Query error: Unknown column 'd.vDeviceType' in 'field list' - Invalid query: SELECT `u`.*, `d`.`vDeviceToken`, `d`.`vDeviceType`
FROM `user_master` as `u`
LEFT JOIN `device_master` as `d` ON `u`.`iUserId` = `d`.`iUserId`
WHERE `u`.`iUserId` = '2'
AND `is_deleted` =0
INFO - 2018-02-28 10:17:55 --> Language file loaded: language/english/db_lang.php
INFO - 2018-02-28 10:18:37 --> Config Class Initialized
INFO - 2018-02-28 10:18:37 --> Hooks Class Initialized
DEBUG - 2018-02-28 10:18:37 --> UTF-8 Support Enabled
INFO - 2018-02-28 10:18:37 --> Utf8 Class Initialized
INFO - 2018-02-28 10:18:37 --> URI Class Initialized
INFO - 2018-02-28 10:18:37 --> Router Class Initialized
INFO - 2018-02-28 10:18:37 --> Output Class Initialized
INFO - 2018-02-28 10:18:37 --> Security Class Initialized
DEBUG - 2018-02-28 10:18:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-28 10:18:37 --> Input Class Initialized
INFO - 2018-02-28 10:18:37 --> Language Class Initialized
INFO - 2018-02-28 10:18:37 --> Loader Class Initialized
INFO - 2018-02-28 10:18:37 --> Helper loaded: url_helper
INFO - 2018-02-28 10:18:37 --> Helper loaded: file_helper
INFO - 2018-02-28 10:18:37 --> Helper loaded: email_helper
INFO - 2018-02-28 10:18:37 --> Helper loaded: common_helper
INFO - 2018-02-28 10:18:37 --> Database Driver Class Initialized
DEBUG - 2018-02-28 10:18:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-28 10:18:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-28 10:18:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-28 10:18:37 --> Pagination Class Initialized
INFO - 2018-02-28 10:18:37 --> Helper loaded: form_helper
INFO - 2018-02-28 10:18:37 --> Form Validation Class Initialized
INFO - 2018-02-28 10:18:37 --> Model Class Initialized
INFO - 2018-02-28 10:18:37 --> Controller Class Initialized
DEBUG - 2018-02-28 10:18:37 --> Config file loaded: /var/www/html/project/periodtracker/application/config/rest.php
INFO - 2018-02-28 10:18:37 --> Helper loaded: inflector_helper
INFO - 2018-02-28 10:18:37 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-28 10:18:37 --> Model Class Initialized
INFO - 2018-02-28 10:18:37 --> Model Class Initialized
INFO - 2018-02-28 10:18:37 --> Model Class Initialized
INFO - 2018-02-28 10:18:37 --> Final output sent to browser
DEBUG - 2018-02-28 10:18:37 --> Total execution time: 0.0063
INFO - 2018-02-28 10:27:01 --> Config Class Initialized
INFO - 2018-02-28 10:27:01 --> Hooks Class Initialized
DEBUG - 2018-02-28 10:27:01 --> UTF-8 Support Enabled
INFO - 2018-02-28 10:27:01 --> Utf8 Class Initialized
INFO - 2018-02-28 10:27:01 --> URI Class Initialized
INFO - 2018-02-28 10:27:01 --> Router Class Initialized
INFO - 2018-02-28 10:27:01 --> Output Class Initialized
INFO - 2018-02-28 10:27:01 --> Security Class Initialized
DEBUG - 2018-02-28 10:27:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-28 10:27:01 --> Input Class Initialized
INFO - 2018-02-28 10:27:01 --> Language Class Initialized
INFO - 2018-02-28 10:27:01 --> Loader Class Initialized
INFO - 2018-02-28 10:27:01 --> Helper loaded: url_helper
INFO - 2018-02-28 10:27:01 --> Helper loaded: file_helper
INFO - 2018-02-28 10:27:01 --> Helper loaded: email_helper
INFO - 2018-02-28 10:27:01 --> Helper loaded: common_helper
INFO - 2018-02-28 10:27:01 --> Database Driver Class Initialized
DEBUG - 2018-02-28 10:27:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-28 10:27:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-28 10:27:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-28 10:27:01 --> Pagination Class Initialized
INFO - 2018-02-28 10:27:01 --> Helper loaded: form_helper
INFO - 2018-02-28 10:27:01 --> Form Validation Class Initialized
INFO - 2018-02-28 10:27:01 --> Model Class Initialized
INFO - 2018-02-28 10:27:01 --> Controller Class Initialized
DEBUG - 2018-02-28 10:27:01 --> Config file loaded: /var/www/html/project/periodtracker/application/config/rest.php
INFO - 2018-02-28 10:27:01 --> Helper loaded: inflector_helper
INFO - 2018-02-28 10:27:01 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-28 10:27:01 --> Model Class Initialized
INFO - 2018-02-28 10:27:01 --> Model Class Initialized
INFO - 2018-02-28 10:27:01 --> Model Class Initialized
ERROR - 2018-02-28 10:27:01 --> Severity: Notice --> Undefined property: Oauth::$Usermaster_model /var/www/html/project/periodtracker/application/controllers/api/Oauth.php 633
ERROR - 2018-02-28 10:27:01 --> Severity: error --> Exception: Call to a member function AuthAttributes() on null /var/www/html/project/periodtracker/application/controllers/api/Oauth.php 633
INFO - 2018-02-28 10:32:39 --> Config Class Initialized
INFO - 2018-02-28 10:32:39 --> Hooks Class Initialized
DEBUG - 2018-02-28 10:32:39 --> UTF-8 Support Enabled
INFO - 2018-02-28 10:32:39 --> Utf8 Class Initialized
INFO - 2018-02-28 10:32:39 --> URI Class Initialized
INFO - 2018-02-28 10:32:39 --> Router Class Initialized
INFO - 2018-02-28 10:32:39 --> Output Class Initialized
INFO - 2018-02-28 10:32:39 --> Security Class Initialized
DEBUG - 2018-02-28 10:32:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-28 10:32:39 --> Input Class Initialized
INFO - 2018-02-28 10:32:39 --> Language Class Initialized
INFO - 2018-02-28 10:32:39 --> Loader Class Initialized
INFO - 2018-02-28 10:32:39 --> Helper loaded: url_helper
INFO - 2018-02-28 10:32:39 --> Helper loaded: file_helper
INFO - 2018-02-28 10:32:39 --> Helper loaded: email_helper
INFO - 2018-02-28 10:32:39 --> Helper loaded: common_helper
INFO - 2018-02-28 10:32:39 --> Database Driver Class Initialized
DEBUG - 2018-02-28 10:32:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-28 10:32:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-28 10:32:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-28 10:32:39 --> Pagination Class Initialized
INFO - 2018-02-28 10:32:39 --> Helper loaded: form_helper
INFO - 2018-02-28 10:32:39 --> Form Validation Class Initialized
INFO - 2018-02-28 10:32:39 --> Model Class Initialized
INFO - 2018-02-28 10:32:39 --> Controller Class Initialized
DEBUG - 2018-02-28 10:32:39 --> Config file loaded: /var/www/html/project/periodtracker/application/config/rest.php
INFO - 2018-02-28 10:32:39 --> Helper loaded: inflector_helper
INFO - 2018-02-28 10:32:39 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-28 10:32:39 --> Model Class Initialized
INFO - 2018-02-28 10:32:39 --> Model Class Initialized
INFO - 2018-02-28 10:32:39 --> Model Class Initialized
INFO - 2018-02-28 10:32:39 --> Final output sent to browser
DEBUG - 2018-02-28 10:32:39 --> Total execution time: 0.0075
INFO - 2018-02-28 10:32:45 --> Config Class Initialized
INFO - 2018-02-28 10:32:45 --> Hooks Class Initialized
DEBUG - 2018-02-28 10:32:45 --> UTF-8 Support Enabled
INFO - 2018-02-28 10:32:45 --> Utf8 Class Initialized
INFO - 2018-02-28 10:32:45 --> URI Class Initialized
INFO - 2018-02-28 10:32:45 --> Router Class Initialized
INFO - 2018-02-28 10:32:45 --> Output Class Initialized
INFO - 2018-02-28 10:32:45 --> Security Class Initialized
DEBUG - 2018-02-28 10:32:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-28 10:32:45 --> Input Class Initialized
INFO - 2018-02-28 10:32:45 --> Language Class Initialized
INFO - 2018-02-28 10:32:45 --> Loader Class Initialized
INFO - 2018-02-28 10:32:45 --> Helper loaded: url_helper
INFO - 2018-02-28 10:32:45 --> Helper loaded: file_helper
INFO - 2018-02-28 10:32:45 --> Helper loaded: email_helper
INFO - 2018-02-28 10:32:45 --> Helper loaded: common_helper
INFO - 2018-02-28 10:32:45 --> Database Driver Class Initialized
DEBUG - 2018-02-28 10:32:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-28 10:32:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-28 10:32:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-28 10:32:45 --> Pagination Class Initialized
INFO - 2018-02-28 10:32:45 --> Helper loaded: form_helper
INFO - 2018-02-28 10:32:45 --> Form Validation Class Initialized
INFO - 2018-02-28 10:32:45 --> Model Class Initialized
INFO - 2018-02-28 10:32:45 --> Controller Class Initialized
DEBUG - 2018-02-28 10:32:45 --> Config file loaded: /var/www/html/project/periodtracker/application/config/rest.php
INFO - 2018-02-28 10:32:45 --> Helper loaded: inflector_helper
INFO - 2018-02-28 10:32:45 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-28 10:32:45 --> Model Class Initialized
INFO - 2018-02-28 10:32:45 --> Model Class Initialized
INFO - 2018-02-28 10:32:45 --> Model Class Initialized
INFO - 2018-02-28 10:32:45 --> Final output sent to browser
DEBUG - 2018-02-28 10:32:45 --> Total execution time: 0.0502
INFO - 2018-02-28 10:33:16 --> Config Class Initialized
INFO - 2018-02-28 10:33:16 --> Hooks Class Initialized
DEBUG - 2018-02-28 10:33:16 --> UTF-8 Support Enabled
INFO - 2018-02-28 10:33:16 --> Utf8 Class Initialized
INFO - 2018-02-28 10:33:16 --> URI Class Initialized
INFO - 2018-02-28 10:33:16 --> Router Class Initialized
INFO - 2018-02-28 10:33:16 --> Output Class Initialized
INFO - 2018-02-28 10:33:16 --> Security Class Initialized
DEBUG - 2018-02-28 10:33:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-28 10:33:16 --> Input Class Initialized
INFO - 2018-02-28 10:33:16 --> Language Class Initialized
INFO - 2018-02-28 10:33:16 --> Loader Class Initialized
INFO - 2018-02-28 10:33:16 --> Helper loaded: url_helper
INFO - 2018-02-28 10:33:16 --> Helper loaded: file_helper
INFO - 2018-02-28 10:33:16 --> Helper loaded: email_helper
INFO - 2018-02-28 10:33:16 --> Helper loaded: common_helper
INFO - 2018-02-28 10:33:16 --> Database Driver Class Initialized
DEBUG - 2018-02-28 10:33:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-28 10:33:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-28 10:33:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-28 10:33:16 --> Pagination Class Initialized
INFO - 2018-02-28 10:33:16 --> Helper loaded: form_helper
INFO - 2018-02-28 10:33:16 --> Form Validation Class Initialized
INFO - 2018-02-28 10:33:16 --> Model Class Initialized
INFO - 2018-02-28 10:33:16 --> Controller Class Initialized
DEBUG - 2018-02-28 10:33:16 --> Config file loaded: /var/www/html/project/periodtracker/application/config/rest.php
INFO - 2018-02-28 10:33:16 --> Helper loaded: inflector_helper
INFO - 2018-02-28 10:33:16 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-28 10:33:16 --> Model Class Initialized
INFO - 2018-02-28 10:33:16 --> Model Class Initialized
INFO - 2018-02-28 10:33:16 --> Model Class Initialized
INFO - 2018-02-28 10:33:16 --> Final output sent to browser
DEBUG - 2018-02-28 10:33:16 --> Total execution time: 0.0071
INFO - 2018-02-28 10:45:29 --> Config Class Initialized
INFO - 2018-02-28 10:45:29 --> Hooks Class Initialized
DEBUG - 2018-02-28 10:45:29 --> UTF-8 Support Enabled
INFO - 2018-02-28 10:45:29 --> Utf8 Class Initialized
INFO - 2018-02-28 10:45:29 --> URI Class Initialized
INFO - 2018-02-28 10:45:29 --> Router Class Initialized
INFO - 2018-02-28 10:45:29 --> Output Class Initialized
INFO - 2018-02-28 10:45:29 --> Security Class Initialized
DEBUG - 2018-02-28 10:45:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-28 10:45:29 --> Input Class Initialized
INFO - 2018-02-28 10:45:29 --> Language Class Initialized
INFO - 2018-02-28 10:45:29 --> Loader Class Initialized
INFO - 2018-02-28 10:45:29 --> Helper loaded: url_helper
INFO - 2018-02-28 10:45:29 --> Helper loaded: file_helper
INFO - 2018-02-28 10:45:29 --> Helper loaded: email_helper
INFO - 2018-02-28 10:45:29 --> Helper loaded: common_helper
INFO - 2018-02-28 10:45:29 --> Database Driver Class Initialized
DEBUG - 2018-02-28 10:45:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-28 10:45:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-28 10:45:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-28 10:45:29 --> Pagination Class Initialized
INFO - 2018-02-28 10:45:29 --> Helper loaded: form_helper
INFO - 2018-02-28 10:45:29 --> Form Validation Class Initialized
INFO - 2018-02-28 10:45:29 --> Model Class Initialized
INFO - 2018-02-28 10:45:29 --> Controller Class Initialized
DEBUG - 2018-02-28 10:45:29 --> Config file loaded: /var/www/html/project/periodtracker/application/config/rest.php
INFO - 2018-02-28 10:45:29 --> Helper loaded: inflector_helper
INFO - 2018-02-28 10:45:29 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-28 10:45:29 --> Model Class Initialized
INFO - 2018-02-28 10:45:29 --> Model Class Initialized
INFO - 2018-02-28 10:45:29 --> Model Class Initialized
INFO - 2018-02-28 10:45:29 --> Final output sent to browser
DEBUG - 2018-02-28 10:45:29 --> Total execution time: 0.0066
INFO - 2018-02-28 10:47:04 --> Config Class Initialized
INFO - 2018-02-28 10:47:04 --> Hooks Class Initialized
DEBUG - 2018-02-28 10:47:04 --> UTF-8 Support Enabled
INFO - 2018-02-28 10:47:04 --> Utf8 Class Initialized
INFO - 2018-02-28 10:47:04 --> URI Class Initialized
INFO - 2018-02-28 10:47:04 --> Router Class Initialized
INFO - 2018-02-28 10:47:04 --> Output Class Initialized
INFO - 2018-02-28 10:47:04 --> Security Class Initialized
DEBUG - 2018-02-28 10:47:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-28 10:47:04 --> Input Class Initialized
INFO - 2018-02-28 10:47:04 --> Language Class Initialized
INFO - 2018-02-28 10:47:04 --> Loader Class Initialized
INFO - 2018-02-28 10:47:04 --> Helper loaded: url_helper
INFO - 2018-02-28 10:47:04 --> Helper loaded: file_helper
INFO - 2018-02-28 10:47:04 --> Helper loaded: email_helper
INFO - 2018-02-28 10:47:04 --> Helper loaded: common_helper
INFO - 2018-02-28 10:47:04 --> Database Driver Class Initialized
DEBUG - 2018-02-28 10:47:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-28 10:47:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-28 10:47:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-28 10:47:04 --> Pagination Class Initialized
INFO - 2018-02-28 10:47:04 --> Helper loaded: form_helper
INFO - 2018-02-28 10:47:04 --> Form Validation Class Initialized
INFO - 2018-02-28 10:47:04 --> Model Class Initialized
INFO - 2018-02-28 10:47:04 --> Controller Class Initialized
DEBUG - 2018-02-28 10:47:04 --> Config file loaded: /var/www/html/project/periodtracker/application/config/rest.php
INFO - 2018-02-28 10:47:04 --> Helper loaded: inflector_helper
INFO - 2018-02-28 10:47:04 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-28 10:47:04 --> Model Class Initialized
INFO - 2018-02-28 10:47:04 --> Model Class Initialized
INFO - 2018-02-28 10:47:04 --> Model Class Initialized
INFO - 2018-02-28 10:47:04 --> Final output sent to browser
DEBUG - 2018-02-28 10:47:04 --> Total execution time: 0.0464
INFO - 2018-02-28 10:47:08 --> Config Class Initialized
INFO - 2018-02-28 10:47:08 --> Hooks Class Initialized
DEBUG - 2018-02-28 10:47:08 --> UTF-8 Support Enabled
INFO - 2018-02-28 10:47:08 --> Utf8 Class Initialized
INFO - 2018-02-28 10:47:08 --> URI Class Initialized
INFO - 2018-02-28 10:47:08 --> Router Class Initialized
INFO - 2018-02-28 10:47:08 --> Output Class Initialized
INFO - 2018-02-28 10:47:08 --> Security Class Initialized
DEBUG - 2018-02-28 10:47:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-28 10:47:08 --> Input Class Initialized
INFO - 2018-02-28 10:47:08 --> Language Class Initialized
INFO - 2018-02-28 10:47:08 --> Loader Class Initialized
INFO - 2018-02-28 10:47:08 --> Helper loaded: url_helper
INFO - 2018-02-28 10:47:08 --> Helper loaded: file_helper
INFO - 2018-02-28 10:47:08 --> Helper loaded: email_helper
INFO - 2018-02-28 10:47:08 --> Helper loaded: common_helper
INFO - 2018-02-28 10:47:08 --> Database Driver Class Initialized
DEBUG - 2018-02-28 10:47:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-28 10:47:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-28 10:47:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-28 10:47:08 --> Pagination Class Initialized
INFO - 2018-02-28 10:47:08 --> Helper loaded: form_helper
INFO - 2018-02-28 10:47:08 --> Form Validation Class Initialized
INFO - 2018-02-28 10:47:08 --> Model Class Initialized
INFO - 2018-02-28 10:47:08 --> Controller Class Initialized
DEBUG - 2018-02-28 10:47:08 --> Config file loaded: /var/www/html/project/periodtracker/application/config/rest.php
INFO - 2018-02-28 10:47:08 --> Helper loaded: inflector_helper
INFO - 2018-02-28 10:47:08 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-28 10:47:08 --> Model Class Initialized
INFO - 2018-02-28 10:47:08 --> Model Class Initialized
INFO - 2018-02-28 10:47:08 --> Model Class Initialized
INFO - 2018-02-28 10:47:08 --> Final output sent to browser
DEBUG - 2018-02-28 10:47:08 --> Total execution time: 0.0051
INFO - 2018-02-28 10:47:11 --> Config Class Initialized
INFO - 2018-02-28 10:47:11 --> Hooks Class Initialized
DEBUG - 2018-02-28 10:47:11 --> UTF-8 Support Enabled
INFO - 2018-02-28 10:47:11 --> Utf8 Class Initialized
INFO - 2018-02-28 10:47:11 --> URI Class Initialized
INFO - 2018-02-28 10:47:11 --> Router Class Initialized
INFO - 2018-02-28 10:47:11 --> Output Class Initialized
INFO - 2018-02-28 10:47:11 --> Security Class Initialized
DEBUG - 2018-02-28 10:47:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-28 10:47:11 --> Input Class Initialized
INFO - 2018-02-28 10:47:11 --> Language Class Initialized
INFO - 2018-02-28 10:47:11 --> Loader Class Initialized
INFO - 2018-02-28 10:47:11 --> Helper loaded: url_helper
INFO - 2018-02-28 10:47:11 --> Helper loaded: file_helper
INFO - 2018-02-28 10:47:11 --> Helper loaded: email_helper
INFO - 2018-02-28 10:47:11 --> Helper loaded: common_helper
INFO - 2018-02-28 10:47:11 --> Database Driver Class Initialized
DEBUG - 2018-02-28 10:47:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-28 10:47:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-28 10:47:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-28 10:47:11 --> Pagination Class Initialized
INFO - 2018-02-28 10:47:11 --> Helper loaded: form_helper
INFO - 2018-02-28 10:47:11 --> Form Validation Class Initialized
INFO - 2018-02-28 10:47:11 --> Model Class Initialized
INFO - 2018-02-28 10:47:11 --> Controller Class Initialized
DEBUG - 2018-02-28 10:47:11 --> Config file loaded: /var/www/html/project/periodtracker/application/config/rest.php
INFO - 2018-02-28 10:47:11 --> Helper loaded: inflector_helper
INFO - 2018-02-28 10:47:11 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-28 10:47:11 --> Model Class Initialized
INFO - 2018-02-28 10:47:11 --> Model Class Initialized
INFO - 2018-02-28 10:47:11 --> Model Class Initialized
ERROR - 2018-02-28 10:47:11 --> Severity: Notice --> Undefined index: tIsSubscribe /var/www/html/project/periodtracker/application/controllers/api/Oauth.php 633
INFO - 2018-02-28 10:47:11 --> Final output sent to browser
DEBUG - 2018-02-28 10:47:11 --> Total execution time: 0.0060
INFO - 2018-02-28 10:47:20 --> Config Class Initialized
INFO - 2018-02-28 10:47:20 --> Hooks Class Initialized
DEBUG - 2018-02-28 10:47:20 --> UTF-8 Support Enabled
INFO - 2018-02-28 10:47:20 --> Utf8 Class Initialized
INFO - 2018-02-28 10:47:20 --> URI Class Initialized
INFO - 2018-02-28 10:47:20 --> Router Class Initialized
INFO - 2018-02-28 10:47:20 --> Output Class Initialized
INFO - 2018-02-28 10:47:20 --> Security Class Initialized
DEBUG - 2018-02-28 10:47:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-28 10:47:20 --> Input Class Initialized
INFO - 2018-02-28 10:47:20 --> Language Class Initialized
INFO - 2018-02-28 10:47:20 --> Loader Class Initialized
INFO - 2018-02-28 10:47:20 --> Helper loaded: url_helper
INFO - 2018-02-28 10:47:20 --> Helper loaded: file_helper
INFO - 2018-02-28 10:47:20 --> Helper loaded: email_helper
INFO - 2018-02-28 10:47:20 --> Helper loaded: common_helper
INFO - 2018-02-28 10:47:20 --> Database Driver Class Initialized
DEBUG - 2018-02-28 10:47:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-28 10:47:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-28 10:47:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-28 10:47:20 --> Pagination Class Initialized
INFO - 2018-02-28 10:47:20 --> Helper loaded: form_helper
INFO - 2018-02-28 10:47:20 --> Form Validation Class Initialized
INFO - 2018-02-28 10:47:20 --> Model Class Initialized
INFO - 2018-02-28 10:47:20 --> Controller Class Initialized
DEBUG - 2018-02-28 10:47:20 --> Config file loaded: /var/www/html/project/periodtracker/application/config/rest.php
INFO - 2018-02-28 10:47:20 --> Helper loaded: inflector_helper
INFO - 2018-02-28 10:47:20 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-28 10:47:20 --> Model Class Initialized
INFO - 2018-02-28 10:47:20 --> Model Class Initialized
INFO - 2018-02-28 10:47:20 --> Model Class Initialized
INFO - 2018-02-28 10:47:20 --> Final output sent to browser
DEBUG - 2018-02-28 10:47:20 --> Total execution time: 0.0057
INFO - 2018-02-28 10:48:46 --> Config Class Initialized
INFO - 2018-02-28 10:48:46 --> Hooks Class Initialized
DEBUG - 2018-02-28 10:48:46 --> UTF-8 Support Enabled
INFO - 2018-02-28 10:48:46 --> Utf8 Class Initialized
INFO - 2018-02-28 10:48:46 --> URI Class Initialized
INFO - 2018-02-28 10:48:46 --> Router Class Initialized
INFO - 2018-02-28 10:48:46 --> Output Class Initialized
INFO - 2018-02-28 10:48:46 --> Security Class Initialized
DEBUG - 2018-02-28 10:48:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-28 10:48:46 --> Input Class Initialized
INFO - 2018-02-28 10:48:46 --> Language Class Initialized
INFO - 2018-02-28 10:48:46 --> Loader Class Initialized
INFO - 2018-02-28 10:48:46 --> Helper loaded: url_helper
INFO - 2018-02-28 10:48:46 --> Helper loaded: file_helper
INFO - 2018-02-28 10:48:46 --> Helper loaded: email_helper
INFO - 2018-02-28 10:48:46 --> Helper loaded: common_helper
INFO - 2018-02-28 10:48:46 --> Database Driver Class Initialized
DEBUG - 2018-02-28 10:48:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-28 10:48:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-28 10:48:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-28 10:48:46 --> Pagination Class Initialized
INFO - 2018-02-28 10:48:46 --> Helper loaded: form_helper
INFO - 2018-02-28 10:48:46 --> Form Validation Class Initialized
INFO - 2018-02-28 10:48:46 --> Model Class Initialized
INFO - 2018-02-28 10:48:46 --> Controller Class Initialized
DEBUG - 2018-02-28 10:48:46 --> Config file loaded: /var/www/html/project/periodtracker/application/config/rest.php
INFO - 2018-02-28 10:48:46 --> Helper loaded: inflector_helper
INFO - 2018-02-28 10:48:46 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-28 10:48:46 --> Model Class Initialized
INFO - 2018-02-28 10:48:46 --> Model Class Initialized
INFO - 2018-02-28 10:48:46 --> Model Class Initialized
ERROR - 2018-02-28 10:48:46 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '== 0, 0, 1) as tIsSubscribe
FROM `user_master` as `u`
LEFT JOIN `device_master` ' at line 1 - Invalid query: SELECT `u`.*, `d`.`vDeviceToken`, `d`.`tDeviceType`, IF(u.tIsSubscribe == 0, 0, 1) as tIsSubscribe
FROM `user_master` as `u`
LEFT JOIN `device_master` as `d` ON `u`.`iUserId` = `d`.`iUserId`
WHERE `u`.`iUserId` = '2'
AND `is_deleted` =0
INFO - 2018-02-28 10:48:46 --> Language file loaded: language/english/db_lang.php
INFO - 2018-02-28 10:48:53 --> Config Class Initialized
INFO - 2018-02-28 10:48:53 --> Hooks Class Initialized
DEBUG - 2018-02-28 10:48:53 --> UTF-8 Support Enabled
INFO - 2018-02-28 10:48:53 --> Utf8 Class Initialized
INFO - 2018-02-28 10:48:53 --> URI Class Initialized
INFO - 2018-02-28 10:48:53 --> Router Class Initialized
INFO - 2018-02-28 10:48:53 --> Output Class Initialized
INFO - 2018-02-28 10:48:53 --> Security Class Initialized
DEBUG - 2018-02-28 10:48:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-28 10:48:53 --> Input Class Initialized
INFO - 2018-02-28 10:48:53 --> Language Class Initialized
INFO - 2018-02-28 10:48:53 --> Loader Class Initialized
INFO - 2018-02-28 10:48:53 --> Helper loaded: url_helper
INFO - 2018-02-28 10:48:53 --> Helper loaded: file_helper
INFO - 2018-02-28 10:48:53 --> Helper loaded: email_helper
INFO - 2018-02-28 10:48:53 --> Helper loaded: common_helper
INFO - 2018-02-28 10:48:53 --> Database Driver Class Initialized
DEBUG - 2018-02-28 10:48:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-28 10:48:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-28 10:48:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-28 10:48:53 --> Pagination Class Initialized
INFO - 2018-02-28 10:48:53 --> Helper loaded: form_helper
INFO - 2018-02-28 10:48:53 --> Form Validation Class Initialized
INFO - 2018-02-28 10:48:53 --> Model Class Initialized
INFO - 2018-02-28 10:48:53 --> Controller Class Initialized
DEBUG - 2018-02-28 10:48:53 --> Config file loaded: /var/www/html/project/periodtracker/application/config/rest.php
INFO - 2018-02-28 10:48:53 --> Helper loaded: inflector_helper
INFO - 2018-02-28 10:48:53 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-28 10:48:53 --> Model Class Initialized
INFO - 2018-02-28 10:48:53 --> Model Class Initialized
INFO - 2018-02-28 10:48:53 --> Model Class Initialized
INFO - 2018-02-28 10:48:53 --> Final output sent to browser
DEBUG - 2018-02-28 10:48:53 --> Total execution time: 0.0064
INFO - 2018-02-28 10:49:04 --> Config Class Initialized
INFO - 2018-02-28 10:49:04 --> Hooks Class Initialized
DEBUG - 2018-02-28 10:49:04 --> UTF-8 Support Enabled
INFO - 2018-02-28 10:49:04 --> Utf8 Class Initialized
INFO - 2018-02-28 10:49:04 --> URI Class Initialized
INFO - 2018-02-28 10:49:04 --> Router Class Initialized
INFO - 2018-02-28 10:49:04 --> Output Class Initialized
INFO - 2018-02-28 10:49:04 --> Security Class Initialized
DEBUG - 2018-02-28 10:49:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-28 10:49:04 --> Input Class Initialized
INFO - 2018-02-28 10:49:04 --> Language Class Initialized
INFO - 2018-02-28 10:49:04 --> Loader Class Initialized
INFO - 2018-02-28 10:49:04 --> Helper loaded: url_helper
INFO - 2018-02-28 10:49:04 --> Helper loaded: file_helper
INFO - 2018-02-28 10:49:04 --> Helper loaded: email_helper
INFO - 2018-02-28 10:49:04 --> Helper loaded: common_helper
INFO - 2018-02-28 10:49:04 --> Database Driver Class Initialized
DEBUG - 2018-02-28 10:49:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-28 10:49:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-28 10:49:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-28 10:49:04 --> Pagination Class Initialized
INFO - 2018-02-28 10:49:04 --> Helper loaded: form_helper
INFO - 2018-02-28 10:49:04 --> Form Validation Class Initialized
INFO - 2018-02-28 10:49:04 --> Model Class Initialized
INFO - 2018-02-28 10:49:04 --> Controller Class Initialized
DEBUG - 2018-02-28 10:49:04 --> Config file loaded: /var/www/html/project/periodtracker/application/config/rest.php
INFO - 2018-02-28 10:49:04 --> Helper loaded: inflector_helper
INFO - 2018-02-28 10:49:04 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-28 10:49:04 --> Model Class Initialized
INFO - 2018-02-28 10:49:04 --> Model Class Initialized
INFO - 2018-02-28 10:49:04 --> Model Class Initialized
INFO - 2018-02-28 10:49:04 --> Final output sent to browser
DEBUG - 2018-02-28 10:49:04 --> Total execution time: 0.0077
INFO - 2018-02-28 10:49:11 --> Config Class Initialized
INFO - 2018-02-28 10:49:11 --> Hooks Class Initialized
DEBUG - 2018-02-28 10:49:11 --> UTF-8 Support Enabled
INFO - 2018-02-28 10:49:11 --> Utf8 Class Initialized
INFO - 2018-02-28 10:49:11 --> URI Class Initialized
INFO - 2018-02-28 10:49:11 --> Router Class Initialized
INFO - 2018-02-28 10:49:11 --> Output Class Initialized
INFO - 2018-02-28 10:49:11 --> Security Class Initialized
DEBUG - 2018-02-28 10:49:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-28 10:49:11 --> Input Class Initialized
INFO - 2018-02-28 10:49:11 --> Language Class Initialized
INFO - 2018-02-28 10:49:11 --> Loader Class Initialized
INFO - 2018-02-28 10:49:11 --> Helper loaded: url_helper
INFO - 2018-02-28 10:49:11 --> Helper loaded: file_helper
INFO - 2018-02-28 10:49:11 --> Helper loaded: email_helper
INFO - 2018-02-28 10:49:11 --> Helper loaded: common_helper
INFO - 2018-02-28 10:49:11 --> Database Driver Class Initialized
DEBUG - 2018-02-28 10:49:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-28 10:49:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-28 10:49:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-28 10:49:11 --> Pagination Class Initialized
INFO - 2018-02-28 10:49:11 --> Helper loaded: form_helper
INFO - 2018-02-28 10:49:11 --> Form Validation Class Initialized
INFO - 2018-02-28 10:49:11 --> Model Class Initialized
INFO - 2018-02-28 10:49:11 --> Controller Class Initialized
DEBUG - 2018-02-28 10:49:11 --> Config file loaded: /var/www/html/project/periodtracker/application/config/rest.php
INFO - 2018-02-28 10:49:11 --> Helper loaded: inflector_helper
INFO - 2018-02-28 10:49:11 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-28 10:49:11 --> Model Class Initialized
INFO - 2018-02-28 10:49:11 --> Model Class Initialized
INFO - 2018-02-28 10:49:11 --> Model Class Initialized
INFO - 2018-02-28 10:49:11 --> Final output sent to browser
DEBUG - 2018-02-28 10:49:11 --> Total execution time: 0.0054
INFO - 2018-02-28 10:49:47 --> Config Class Initialized
INFO - 2018-02-28 10:49:47 --> Hooks Class Initialized
DEBUG - 2018-02-28 10:49:47 --> UTF-8 Support Enabled
INFO - 2018-02-28 10:49:47 --> Utf8 Class Initialized
INFO - 2018-02-28 10:49:47 --> URI Class Initialized
INFO - 2018-02-28 10:49:47 --> Router Class Initialized
INFO - 2018-02-28 10:49:47 --> Output Class Initialized
INFO - 2018-02-28 10:49:47 --> Security Class Initialized
DEBUG - 2018-02-28 10:49:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-28 10:49:47 --> Input Class Initialized
INFO - 2018-02-28 10:49:47 --> Language Class Initialized
INFO - 2018-02-28 10:49:47 --> Loader Class Initialized
INFO - 2018-02-28 10:49:47 --> Helper loaded: url_helper
INFO - 2018-02-28 10:49:47 --> Helper loaded: file_helper
INFO - 2018-02-28 10:49:47 --> Helper loaded: email_helper
INFO - 2018-02-28 10:49:47 --> Helper loaded: common_helper
INFO - 2018-02-28 10:49:47 --> Database Driver Class Initialized
DEBUG - 2018-02-28 10:49:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-28 10:49:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-28 10:49:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-28 10:49:47 --> Pagination Class Initialized
INFO - 2018-02-28 10:49:47 --> Helper loaded: form_helper
INFO - 2018-02-28 10:49:47 --> Form Validation Class Initialized
INFO - 2018-02-28 10:49:47 --> Model Class Initialized
INFO - 2018-02-28 10:49:47 --> Controller Class Initialized
DEBUG - 2018-02-28 10:49:47 --> Config file loaded: /var/www/html/project/periodtracker/application/config/rest.php
INFO - 2018-02-28 10:49:47 --> Helper loaded: inflector_helper
INFO - 2018-02-28 10:49:47 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-28 10:49:47 --> Model Class Initialized
INFO - 2018-02-28 10:49:47 --> Model Class Initialized
INFO - 2018-02-28 10:49:47 --> Model Class Initialized
INFO - 2018-02-28 10:49:56 --> Config Class Initialized
INFO - 2018-02-28 10:49:56 --> Hooks Class Initialized
DEBUG - 2018-02-28 10:49:56 --> UTF-8 Support Enabled
INFO - 2018-02-28 10:49:56 --> Utf8 Class Initialized
INFO - 2018-02-28 10:49:56 --> URI Class Initialized
INFO - 2018-02-28 10:49:56 --> Router Class Initialized
INFO - 2018-02-28 10:49:56 --> Output Class Initialized
INFO - 2018-02-28 10:49:56 --> Security Class Initialized
DEBUG - 2018-02-28 10:49:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-28 10:49:56 --> Input Class Initialized
INFO - 2018-02-28 10:49:56 --> Language Class Initialized
INFO - 2018-02-28 10:49:56 --> Loader Class Initialized
INFO - 2018-02-28 10:49:56 --> Helper loaded: url_helper
INFO - 2018-02-28 10:49:56 --> Helper loaded: file_helper
INFO - 2018-02-28 10:49:56 --> Helper loaded: email_helper
INFO - 2018-02-28 10:49:56 --> Helper loaded: common_helper
INFO - 2018-02-28 10:49:56 --> Database Driver Class Initialized
DEBUG - 2018-02-28 10:49:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-28 10:49:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-28 10:49:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-28 10:49:56 --> Pagination Class Initialized
INFO - 2018-02-28 10:49:56 --> Helper loaded: form_helper
INFO - 2018-02-28 10:49:56 --> Form Validation Class Initialized
INFO - 2018-02-28 10:49:56 --> Model Class Initialized
INFO - 2018-02-28 10:49:56 --> Controller Class Initialized
DEBUG - 2018-02-28 10:49:56 --> Config file loaded: /var/www/html/project/periodtracker/application/config/rest.php
INFO - 2018-02-28 10:49:56 --> Helper loaded: inflector_helper
INFO - 2018-02-28 10:49:56 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-28 10:49:56 --> Model Class Initialized
INFO - 2018-02-28 10:49:56 --> Model Class Initialized
INFO - 2018-02-28 10:49:56 --> Model Class Initialized
INFO - 2018-02-28 10:50:08 --> Config Class Initialized
INFO - 2018-02-28 10:50:08 --> Hooks Class Initialized
DEBUG - 2018-02-28 10:50:08 --> UTF-8 Support Enabled
INFO - 2018-02-28 10:50:08 --> Utf8 Class Initialized
INFO - 2018-02-28 10:50:08 --> URI Class Initialized
INFO - 2018-02-28 10:50:08 --> Router Class Initialized
INFO - 2018-02-28 10:50:08 --> Output Class Initialized
INFO - 2018-02-28 10:50:08 --> Security Class Initialized
DEBUG - 2018-02-28 10:50:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-28 10:50:08 --> Input Class Initialized
INFO - 2018-02-28 10:50:08 --> Language Class Initialized
INFO - 2018-02-28 10:50:08 --> Loader Class Initialized
INFO - 2018-02-28 10:50:08 --> Helper loaded: url_helper
INFO - 2018-02-28 10:50:08 --> Helper loaded: file_helper
INFO - 2018-02-28 10:50:08 --> Helper loaded: email_helper
INFO - 2018-02-28 10:50:08 --> Helper loaded: common_helper
INFO - 2018-02-28 10:50:08 --> Database Driver Class Initialized
DEBUG - 2018-02-28 10:50:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-28 10:50:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-28 10:50:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-28 10:50:08 --> Pagination Class Initialized
INFO - 2018-02-28 10:50:08 --> Helper loaded: form_helper
INFO - 2018-02-28 10:50:08 --> Form Validation Class Initialized
INFO - 2018-02-28 10:50:08 --> Model Class Initialized
INFO - 2018-02-28 10:50:08 --> Controller Class Initialized
DEBUG - 2018-02-28 10:50:08 --> Config file loaded: /var/www/html/project/periodtracker/application/config/rest.php
INFO - 2018-02-28 10:50:08 --> Helper loaded: inflector_helper
INFO - 2018-02-28 10:50:08 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-28 10:50:08 --> Model Class Initialized
INFO - 2018-02-28 10:50:08 --> Model Class Initialized
INFO - 2018-02-28 10:50:08 --> Model Class Initialized
INFO - 2018-02-28 10:52:18 --> Config Class Initialized
INFO - 2018-02-28 10:52:18 --> Hooks Class Initialized
DEBUG - 2018-02-28 10:52:18 --> UTF-8 Support Enabled
INFO - 2018-02-28 10:52:18 --> Utf8 Class Initialized
INFO - 2018-02-28 10:52:18 --> URI Class Initialized
INFO - 2018-02-28 10:52:18 --> Router Class Initialized
INFO - 2018-02-28 10:52:18 --> Output Class Initialized
INFO - 2018-02-28 10:52:18 --> Security Class Initialized
DEBUG - 2018-02-28 10:52:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-28 10:52:18 --> Input Class Initialized
INFO - 2018-02-28 10:52:18 --> Language Class Initialized
INFO - 2018-02-28 10:52:18 --> Loader Class Initialized
INFO - 2018-02-28 10:52:18 --> Helper loaded: url_helper
INFO - 2018-02-28 10:52:18 --> Helper loaded: file_helper
INFO - 2018-02-28 10:52:18 --> Helper loaded: email_helper
INFO - 2018-02-28 10:52:18 --> Helper loaded: common_helper
INFO - 2018-02-28 10:52:18 --> Database Driver Class Initialized
DEBUG - 2018-02-28 10:52:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-28 10:52:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-28 10:52:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-28 10:52:18 --> Pagination Class Initialized
INFO - 2018-02-28 10:52:18 --> Helper loaded: form_helper
INFO - 2018-02-28 10:52:18 --> Form Validation Class Initialized
INFO - 2018-02-28 10:52:18 --> Model Class Initialized
INFO - 2018-02-28 10:52:18 --> Controller Class Initialized
DEBUG - 2018-02-28 10:52:18 --> Config file loaded: /var/www/html/project/periodtracker/application/config/rest.php
INFO - 2018-02-28 10:52:18 --> Helper loaded: inflector_helper
INFO - 2018-02-28 10:52:18 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-28 10:52:18 --> Model Class Initialized
INFO - 2018-02-28 10:52:18 --> Model Class Initialized
INFO - 2018-02-28 10:52:18 --> Model Class Initialized
ERROR - 2018-02-28 10:52:18 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'int, u.tIsSubscribe) as tIsSubscribe
FROM `user_master` as `u`
LEFT JOIN `device' at line 1 - Invalid query: SELECT `u`.*, `d`.`vDeviceToken`, `d`.`tDeviceType`, CONVERT(int, u.tIsSubscribe) as tIsSubscribe
FROM `user_master` as `u`
LEFT JOIN `device_master` as `d` ON `u`.`iUserId` = `d`.`iUserId`
WHERE `u`.`iUserId` = '2'
AND `is_deleted` =0
INFO - 2018-02-28 10:52:18 --> Language file loaded: language/english/db_lang.php
INFO - 2018-02-28 10:54:13 --> Config Class Initialized
INFO - 2018-02-28 10:54:13 --> Hooks Class Initialized
DEBUG - 2018-02-28 10:54:13 --> UTF-8 Support Enabled
INFO - 2018-02-28 10:54:13 --> Utf8 Class Initialized
INFO - 2018-02-28 10:54:13 --> URI Class Initialized
INFO - 2018-02-28 10:54:13 --> Router Class Initialized
INFO - 2018-02-28 10:54:13 --> Output Class Initialized
INFO - 2018-02-28 10:54:13 --> Security Class Initialized
DEBUG - 2018-02-28 10:54:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-28 10:54:13 --> Input Class Initialized
INFO - 2018-02-28 10:54:13 --> Language Class Initialized
INFO - 2018-02-28 10:54:13 --> Loader Class Initialized
INFO - 2018-02-28 10:54:13 --> Helper loaded: url_helper
INFO - 2018-02-28 10:54:13 --> Helper loaded: file_helper
INFO - 2018-02-28 10:54:13 --> Helper loaded: email_helper
INFO - 2018-02-28 10:54:13 --> Helper loaded: common_helper
INFO - 2018-02-28 10:54:13 --> Database Driver Class Initialized
DEBUG - 2018-02-28 10:54:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-28 10:54:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-28 10:54:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-28 10:54:13 --> Pagination Class Initialized
INFO - 2018-02-28 10:54:13 --> Helper loaded: form_helper
INFO - 2018-02-28 10:54:13 --> Form Validation Class Initialized
INFO - 2018-02-28 10:54:13 --> Model Class Initialized
INFO - 2018-02-28 10:54:13 --> Controller Class Initialized
DEBUG - 2018-02-28 10:54:13 --> Config file loaded: /var/www/html/project/periodtracker/application/config/rest.php
INFO - 2018-02-28 10:54:13 --> Helper loaded: inflector_helper
INFO - 2018-02-28 10:54:13 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-28 10:54:13 --> Model Class Initialized
INFO - 2018-02-28 10:54:13 --> Model Class Initialized
INFO - 2018-02-28 10:54:13 --> Model Class Initialized
ERROR - 2018-02-28 10:54:13 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'int, 0), 1) as tIsSubscribe
FROM `user_master` as `u`
LEFT JOIN `device_master` ' at line 1 - Invalid query: SELECT `u`.*, `d`.`vDeviceToken`, `d`.`tDeviceType`, IF(u.tIsSubscribe = 0, CONVERT(int, 0), 1) as tIsSubscribe
FROM `user_master` as `u`
LEFT JOIN `device_master` as `d` ON `u`.`iUserId` = `d`.`iUserId`
WHERE `u`.`iUserId` = '2'
AND `is_deleted` =0
INFO - 2018-02-28 10:54:13 --> Language file loaded: language/english/db_lang.php
INFO - 2018-02-28 10:54:26 --> Config Class Initialized
INFO - 2018-02-28 10:54:26 --> Hooks Class Initialized
DEBUG - 2018-02-28 10:54:26 --> UTF-8 Support Enabled
INFO - 2018-02-28 10:54:26 --> Utf8 Class Initialized
INFO - 2018-02-28 10:54:26 --> URI Class Initialized
INFO - 2018-02-28 10:54:26 --> Router Class Initialized
INFO - 2018-02-28 10:54:26 --> Output Class Initialized
INFO - 2018-02-28 10:54:26 --> Security Class Initialized
DEBUG - 2018-02-28 10:54:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-28 10:54:26 --> Input Class Initialized
INFO - 2018-02-28 10:54:26 --> Language Class Initialized
INFO - 2018-02-28 10:54:26 --> Loader Class Initialized
INFO - 2018-02-28 10:54:26 --> Helper loaded: url_helper
INFO - 2018-02-28 10:54:26 --> Helper loaded: file_helper
INFO - 2018-02-28 10:54:26 --> Helper loaded: email_helper
INFO - 2018-02-28 10:54:26 --> Helper loaded: common_helper
INFO - 2018-02-28 10:54:26 --> Database Driver Class Initialized
DEBUG - 2018-02-28 10:54:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-28 10:54:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-28 10:54:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-28 10:54:26 --> Pagination Class Initialized
INFO - 2018-02-28 10:54:26 --> Helper loaded: form_helper
INFO - 2018-02-28 10:54:26 --> Form Validation Class Initialized
INFO - 2018-02-28 10:54:26 --> Model Class Initialized
INFO - 2018-02-28 10:54:26 --> Controller Class Initialized
DEBUG - 2018-02-28 10:54:26 --> Config file loaded: /var/www/html/project/periodtracker/application/config/rest.php
INFO - 2018-02-28 10:54:26 --> Helper loaded: inflector_helper
INFO - 2018-02-28 10:54:26 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-28 10:54:26 --> Model Class Initialized
INFO - 2018-02-28 10:54:26 --> Model Class Initialized
INFO - 2018-02-28 10:54:26 --> Model Class Initialized
INFO - 2018-02-28 10:54:44 --> Config Class Initialized
INFO - 2018-02-28 10:54:44 --> Hooks Class Initialized
DEBUG - 2018-02-28 10:54:44 --> UTF-8 Support Enabled
INFO - 2018-02-28 10:54:44 --> Utf8 Class Initialized
INFO - 2018-02-28 10:54:44 --> URI Class Initialized
INFO - 2018-02-28 10:54:44 --> Router Class Initialized
INFO - 2018-02-28 10:54:44 --> Output Class Initialized
INFO - 2018-02-28 10:54:44 --> Security Class Initialized
DEBUG - 2018-02-28 10:54:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-28 10:54:44 --> Input Class Initialized
INFO - 2018-02-28 10:54:44 --> Language Class Initialized
INFO - 2018-02-28 10:54:44 --> Loader Class Initialized
INFO - 2018-02-28 10:54:44 --> Helper loaded: url_helper
INFO - 2018-02-28 10:54:44 --> Helper loaded: file_helper
INFO - 2018-02-28 10:54:44 --> Helper loaded: email_helper
INFO - 2018-02-28 10:54:44 --> Helper loaded: common_helper
INFO - 2018-02-28 10:54:44 --> Database Driver Class Initialized
DEBUG - 2018-02-28 10:54:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-28 10:54:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-28 10:54:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-28 10:54:44 --> Pagination Class Initialized
INFO - 2018-02-28 10:54:44 --> Helper loaded: form_helper
INFO - 2018-02-28 10:54:44 --> Form Validation Class Initialized
INFO - 2018-02-28 10:54:44 --> Model Class Initialized
INFO - 2018-02-28 10:54:44 --> Controller Class Initialized
DEBUG - 2018-02-28 10:54:44 --> Config file loaded: /var/www/html/project/periodtracker/application/config/rest.php
INFO - 2018-02-28 10:54:44 --> Helper loaded: inflector_helper
INFO - 2018-02-28 10:54:44 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-28 10:54:44 --> Model Class Initialized
INFO - 2018-02-28 10:54:44 --> Model Class Initialized
INFO - 2018-02-28 10:54:44 --> Model Class Initialized
INFO - 2018-02-28 11:03:40 --> Config Class Initialized
INFO - 2018-02-28 11:03:40 --> Hooks Class Initialized
DEBUG - 2018-02-28 11:03:40 --> UTF-8 Support Enabled
INFO - 2018-02-28 11:03:40 --> Utf8 Class Initialized
INFO - 2018-02-28 11:03:40 --> URI Class Initialized
INFO - 2018-02-28 11:03:40 --> Router Class Initialized
INFO - 2018-02-28 11:03:40 --> Output Class Initialized
INFO - 2018-02-28 11:03:40 --> Security Class Initialized
DEBUG - 2018-02-28 11:03:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-28 11:03:40 --> Input Class Initialized
INFO - 2018-02-28 11:03:40 --> Language Class Initialized
INFO - 2018-02-28 11:03:40 --> Loader Class Initialized
INFO - 2018-02-28 11:03:40 --> Helper loaded: url_helper
INFO - 2018-02-28 11:03:40 --> Helper loaded: file_helper
INFO - 2018-02-28 11:03:40 --> Helper loaded: email_helper
INFO - 2018-02-28 11:03:40 --> Helper loaded: common_helper
INFO - 2018-02-28 11:03:40 --> Database Driver Class Initialized
DEBUG - 2018-02-28 11:03:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-28 11:03:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-28 11:03:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-28 11:03:40 --> Pagination Class Initialized
INFO - 2018-02-28 11:03:40 --> Helper loaded: form_helper
INFO - 2018-02-28 11:03:40 --> Form Validation Class Initialized
INFO - 2018-02-28 11:03:40 --> Model Class Initialized
INFO - 2018-02-28 11:03:40 --> Controller Class Initialized
DEBUG - 2018-02-28 11:03:40 --> Config file loaded: /var/www/html/project/periodtracker/application/config/rest.php
INFO - 2018-02-28 11:03:40 --> Helper loaded: inflector_helper
INFO - 2018-02-28 11:03:40 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-28 11:03:40 --> Model Class Initialized
INFO - 2018-02-28 11:03:40 --> Model Class Initialized
INFO - 2018-02-28 11:03:40 --> Model Class Initialized
INFO - 2018-02-28 11:04:00 --> Config Class Initialized
INFO - 2018-02-28 11:04:00 --> Hooks Class Initialized
DEBUG - 2018-02-28 11:04:00 --> UTF-8 Support Enabled
INFO - 2018-02-28 11:04:00 --> Utf8 Class Initialized
INFO - 2018-02-28 11:04:00 --> URI Class Initialized
INFO - 2018-02-28 11:04:00 --> Router Class Initialized
INFO - 2018-02-28 11:04:00 --> Output Class Initialized
INFO - 2018-02-28 11:04:00 --> Security Class Initialized
DEBUG - 2018-02-28 11:04:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-28 11:04:00 --> Input Class Initialized
INFO - 2018-02-28 11:04:00 --> Language Class Initialized
INFO - 2018-02-28 11:04:00 --> Loader Class Initialized
INFO - 2018-02-28 11:04:00 --> Helper loaded: url_helper
INFO - 2018-02-28 11:04:00 --> Helper loaded: file_helper
INFO - 2018-02-28 11:04:00 --> Helper loaded: email_helper
INFO - 2018-02-28 11:04:00 --> Helper loaded: common_helper
INFO - 2018-02-28 11:04:00 --> Database Driver Class Initialized
DEBUG - 2018-02-28 11:04:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-28 11:04:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-28 11:04:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-28 11:04:00 --> Pagination Class Initialized
INFO - 2018-02-28 11:04:00 --> Helper loaded: form_helper
INFO - 2018-02-28 11:04:00 --> Form Validation Class Initialized
INFO - 2018-02-28 11:04:00 --> Model Class Initialized
INFO - 2018-02-28 11:04:00 --> Controller Class Initialized
DEBUG - 2018-02-28 11:04:00 --> Config file loaded: /var/www/html/project/periodtracker/application/config/rest.php
INFO - 2018-02-28 11:04:00 --> Helper loaded: inflector_helper
INFO - 2018-02-28 11:04:00 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-28 11:04:00 --> Model Class Initialized
INFO - 2018-02-28 11:04:00 --> Model Class Initialized
INFO - 2018-02-28 11:04:00 --> Model Class Initialized
INFO - 2018-02-28 11:04:00 --> Final output sent to browser
DEBUG - 2018-02-28 11:04:00 --> Total execution time: 0.0065
INFO - 2018-02-28 11:05:39 --> Config Class Initialized
INFO - 2018-02-28 11:05:39 --> Hooks Class Initialized
DEBUG - 2018-02-28 11:05:39 --> UTF-8 Support Enabled
INFO - 2018-02-28 11:05:39 --> Utf8 Class Initialized
INFO - 2018-02-28 11:05:39 --> URI Class Initialized
INFO - 2018-02-28 11:05:39 --> Router Class Initialized
INFO - 2018-02-28 11:05:39 --> Output Class Initialized
INFO - 2018-02-28 11:05:39 --> Security Class Initialized
DEBUG - 2018-02-28 11:05:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-28 11:05:39 --> Input Class Initialized
INFO - 2018-02-28 11:05:39 --> Language Class Initialized
INFO - 2018-02-28 11:05:39 --> Loader Class Initialized
INFO - 2018-02-28 11:05:39 --> Helper loaded: url_helper
INFO - 2018-02-28 11:05:39 --> Helper loaded: file_helper
INFO - 2018-02-28 11:05:39 --> Helper loaded: email_helper
INFO - 2018-02-28 11:05:39 --> Helper loaded: common_helper
INFO - 2018-02-28 11:05:39 --> Database Driver Class Initialized
DEBUG - 2018-02-28 11:05:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-28 11:05:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-28 11:05:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-28 11:05:39 --> Pagination Class Initialized
INFO - 2018-02-28 11:05:39 --> Helper loaded: form_helper
INFO - 2018-02-28 11:05:39 --> Form Validation Class Initialized
INFO - 2018-02-28 11:05:39 --> Model Class Initialized
INFO - 2018-02-28 11:05:39 --> Controller Class Initialized
DEBUG - 2018-02-28 11:05:39 --> Config file loaded: /var/www/html/project/periodtracker/application/config/rest.php
INFO - 2018-02-28 11:05:39 --> Helper loaded: inflector_helper
INFO - 2018-02-28 11:05:39 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-28 11:05:39 --> Model Class Initialized
INFO - 2018-02-28 11:05:39 --> Model Class Initialized
INFO - 2018-02-28 11:05:39 --> Model Class Initialized
INFO - 2018-02-28 11:07:21 --> Config Class Initialized
INFO - 2018-02-28 11:07:21 --> Hooks Class Initialized
DEBUG - 2018-02-28 11:07:21 --> UTF-8 Support Enabled
INFO - 2018-02-28 11:07:21 --> Utf8 Class Initialized
INFO - 2018-02-28 11:07:21 --> URI Class Initialized
INFO - 2018-02-28 11:07:21 --> Router Class Initialized
INFO - 2018-02-28 11:07:21 --> Output Class Initialized
INFO - 2018-02-28 11:07:21 --> Security Class Initialized
DEBUG - 2018-02-28 11:07:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-28 11:07:21 --> Input Class Initialized
INFO - 2018-02-28 11:07:21 --> Language Class Initialized
INFO - 2018-02-28 11:07:21 --> Loader Class Initialized
INFO - 2018-02-28 11:07:21 --> Helper loaded: url_helper
INFO - 2018-02-28 11:07:21 --> Helper loaded: file_helper
INFO - 2018-02-28 11:07:21 --> Helper loaded: email_helper
INFO - 2018-02-28 11:07:21 --> Helper loaded: common_helper
INFO - 2018-02-28 11:07:21 --> Database Driver Class Initialized
DEBUG - 2018-02-28 11:07:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-28 11:07:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-28 11:07:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-28 11:07:21 --> Pagination Class Initialized
INFO - 2018-02-28 11:07:21 --> Helper loaded: form_helper
INFO - 2018-02-28 11:07:21 --> Form Validation Class Initialized
INFO - 2018-02-28 11:07:21 --> Model Class Initialized
INFO - 2018-02-28 11:07:21 --> Controller Class Initialized
DEBUG - 2018-02-28 11:07:21 --> Config file loaded: /var/www/html/project/periodtracker/application/config/rest.php
INFO - 2018-02-28 11:07:21 --> Helper loaded: inflector_helper
INFO - 2018-02-28 11:07:21 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-28 11:07:21 --> Model Class Initialized
INFO - 2018-02-28 11:07:21 --> Model Class Initialized
INFO - 2018-02-28 11:07:21 --> Model Class Initialized
INFO - 2018-02-28 11:08:29 --> Config Class Initialized
INFO - 2018-02-28 11:08:29 --> Hooks Class Initialized
DEBUG - 2018-02-28 11:08:29 --> UTF-8 Support Enabled
INFO - 2018-02-28 11:08:29 --> Utf8 Class Initialized
INFO - 2018-02-28 11:08:29 --> URI Class Initialized
INFO - 2018-02-28 11:08:29 --> Router Class Initialized
INFO - 2018-02-28 11:08:29 --> Output Class Initialized
INFO - 2018-02-28 11:08:29 --> Security Class Initialized
DEBUG - 2018-02-28 11:08:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-28 11:08:29 --> Input Class Initialized
INFO - 2018-02-28 11:08:29 --> Language Class Initialized
INFO - 2018-02-28 11:08:29 --> Loader Class Initialized
INFO - 2018-02-28 11:08:29 --> Helper loaded: url_helper
INFO - 2018-02-28 11:08:29 --> Helper loaded: file_helper
INFO - 2018-02-28 11:08:29 --> Helper loaded: email_helper
INFO - 2018-02-28 11:08:29 --> Helper loaded: common_helper
INFO - 2018-02-28 11:08:29 --> Database Driver Class Initialized
DEBUG - 2018-02-28 11:08:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-28 11:08:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-28 11:08:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-28 11:08:29 --> Pagination Class Initialized
INFO - 2018-02-28 11:08:29 --> Helper loaded: form_helper
INFO - 2018-02-28 11:08:29 --> Form Validation Class Initialized
INFO - 2018-02-28 11:08:29 --> Model Class Initialized
INFO - 2018-02-28 11:08:29 --> Controller Class Initialized
DEBUG - 2018-02-28 11:08:29 --> Config file loaded: /var/www/html/project/periodtracker/application/config/rest.php
INFO - 2018-02-28 11:08:29 --> Helper loaded: inflector_helper
INFO - 2018-02-28 11:08:29 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-28 11:08:29 --> Model Class Initialized
INFO - 2018-02-28 11:08:29 --> Model Class Initialized
INFO - 2018-02-28 11:08:29 --> Model Class Initialized
INFO - 2018-02-28 11:08:29 --> Final output sent to browser
DEBUG - 2018-02-28 11:08:29 --> Total execution time: 0.0057
INFO - 2018-02-28 11:09:28 --> Config Class Initialized
INFO - 2018-02-28 11:09:28 --> Hooks Class Initialized
DEBUG - 2018-02-28 11:09:28 --> UTF-8 Support Enabled
INFO - 2018-02-28 11:09:28 --> Utf8 Class Initialized
INFO - 2018-02-28 11:09:28 --> URI Class Initialized
INFO - 2018-02-28 11:09:28 --> Router Class Initialized
INFO - 2018-02-28 11:09:28 --> Output Class Initialized
INFO - 2018-02-28 11:09:28 --> Security Class Initialized
DEBUG - 2018-02-28 11:09:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-28 11:09:28 --> Input Class Initialized
INFO - 2018-02-28 11:09:28 --> Language Class Initialized
INFO - 2018-02-28 11:09:28 --> Loader Class Initialized
INFO - 2018-02-28 11:09:28 --> Helper loaded: url_helper
INFO - 2018-02-28 11:09:28 --> Helper loaded: file_helper
INFO - 2018-02-28 11:09:28 --> Helper loaded: email_helper
INFO - 2018-02-28 11:09:28 --> Helper loaded: common_helper
INFO - 2018-02-28 11:09:28 --> Database Driver Class Initialized
DEBUG - 2018-02-28 11:09:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-28 11:09:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-28 11:09:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-28 11:09:28 --> Pagination Class Initialized
INFO - 2018-02-28 11:09:28 --> Helper loaded: form_helper
INFO - 2018-02-28 11:09:28 --> Form Validation Class Initialized
INFO - 2018-02-28 11:09:28 --> Model Class Initialized
INFO - 2018-02-28 11:09:28 --> Controller Class Initialized
DEBUG - 2018-02-28 11:09:28 --> Config file loaded: /var/www/html/project/periodtracker/application/config/rest.php
INFO - 2018-02-28 11:09:28 --> Helper loaded: inflector_helper
INFO - 2018-02-28 11:09:28 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-28 11:09:28 --> Model Class Initialized
INFO - 2018-02-28 11:09:28 --> Model Class Initialized
INFO - 2018-02-28 11:09:28 --> Model Class Initialized
INFO - 2018-02-28 11:09:28 --> Final output sent to browser
DEBUG - 2018-02-28 11:09:28 --> Total execution time: 0.0067
INFO - 2018-02-28 12:01:16 --> Config Class Initialized
INFO - 2018-02-28 12:01:16 --> Hooks Class Initialized
DEBUG - 2018-02-28 12:01:16 --> UTF-8 Support Enabled
INFO - 2018-02-28 12:01:16 --> Utf8 Class Initialized
INFO - 2018-02-28 12:01:16 --> URI Class Initialized
INFO - 2018-02-28 12:01:16 --> Router Class Initialized
INFO - 2018-02-28 12:01:16 --> Output Class Initialized
INFO - 2018-02-28 12:01:16 --> Security Class Initialized
DEBUG - 2018-02-28 12:01:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-28 12:01:16 --> Input Class Initialized
INFO - 2018-02-28 12:01:16 --> Language Class Initialized
INFO - 2018-02-28 12:01:16 --> Loader Class Initialized
INFO - 2018-02-28 12:01:16 --> Helper loaded: url_helper
INFO - 2018-02-28 12:01:16 --> Helper loaded: file_helper
INFO - 2018-02-28 12:01:16 --> Helper loaded: email_helper
INFO - 2018-02-28 12:01:16 --> Helper loaded: common_helper
INFO - 2018-02-28 12:01:16 --> Database Driver Class Initialized
DEBUG - 2018-02-28 12:01:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-28 12:01:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-28 12:01:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-28 12:01:16 --> Pagination Class Initialized
INFO - 2018-02-28 12:01:16 --> Helper loaded: form_helper
INFO - 2018-02-28 12:01:16 --> Form Validation Class Initialized
INFO - 2018-02-28 12:01:16 --> Model Class Initialized
INFO - 2018-02-28 12:01:16 --> Controller Class Initialized
DEBUG - 2018-02-28 12:01:16 --> Config file loaded: /var/www/html/project/periodtracker/application/config/rest.php
INFO - 2018-02-28 12:01:16 --> Helper loaded: inflector_helper
INFO - 2018-02-28 12:01:16 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-28 12:01:16 --> Model Class Initialized
INFO - 2018-02-28 12:01:16 --> Model Class Initialized
INFO - 2018-02-28 12:01:16 --> Model Class Initialized
INFO - 2018-02-28 12:01:16 --> Final output sent to browser
DEBUG - 2018-02-28 12:01:16 --> Total execution time: 0.0084
INFO - 2018-02-28 12:02:30 --> Config Class Initialized
INFO - 2018-02-28 12:02:30 --> Hooks Class Initialized
DEBUG - 2018-02-28 12:02:30 --> UTF-8 Support Enabled
INFO - 2018-02-28 12:02:30 --> Utf8 Class Initialized
INFO - 2018-02-28 12:02:30 --> URI Class Initialized
INFO - 2018-02-28 12:02:30 --> Router Class Initialized
INFO - 2018-02-28 12:02:30 --> Output Class Initialized
INFO - 2018-02-28 12:02:30 --> Security Class Initialized
DEBUG - 2018-02-28 12:02:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-28 12:02:30 --> Input Class Initialized
INFO - 2018-02-28 12:02:30 --> Language Class Initialized
INFO - 2018-02-28 12:02:30 --> Loader Class Initialized
INFO - 2018-02-28 12:02:30 --> Helper loaded: url_helper
INFO - 2018-02-28 12:02:30 --> Helper loaded: file_helper
INFO - 2018-02-28 12:02:30 --> Helper loaded: email_helper
INFO - 2018-02-28 12:02:30 --> Helper loaded: common_helper
INFO - 2018-02-28 12:02:30 --> Database Driver Class Initialized
DEBUG - 2018-02-28 12:02:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-28 12:02:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-28 12:02:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-28 12:02:30 --> Pagination Class Initialized
INFO - 2018-02-28 12:02:30 --> Helper loaded: form_helper
INFO - 2018-02-28 12:02:30 --> Form Validation Class Initialized
INFO - 2018-02-28 12:02:30 --> Model Class Initialized
INFO - 2018-02-28 12:02:30 --> Controller Class Initialized
DEBUG - 2018-02-28 12:02:30 --> Config file loaded: /var/www/html/project/periodtracker/application/config/rest.php
INFO - 2018-02-28 12:02:30 --> Helper loaded: inflector_helper
INFO - 2018-02-28 12:02:30 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-28 12:02:30 --> Model Class Initialized
INFO - 2018-02-28 12:02:30 --> Model Class Initialized
INFO - 2018-02-28 12:02:30 --> Model Class Initialized
INFO - 2018-02-28 12:02:30 --> Final output sent to browser
DEBUG - 2018-02-28 12:02:30 --> Total execution time: 0.0064
INFO - 2018-02-28 12:03:11 --> Config Class Initialized
INFO - 2018-02-28 12:03:11 --> Hooks Class Initialized
DEBUG - 2018-02-28 12:03:11 --> UTF-8 Support Enabled
INFO - 2018-02-28 12:03:11 --> Utf8 Class Initialized
INFO - 2018-02-28 12:03:11 --> URI Class Initialized
INFO - 2018-02-28 12:03:11 --> Router Class Initialized
INFO - 2018-02-28 12:03:11 --> Output Class Initialized
INFO - 2018-02-28 12:03:11 --> Security Class Initialized
DEBUG - 2018-02-28 12:03:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-28 12:03:11 --> Input Class Initialized
INFO - 2018-02-28 12:03:11 --> Language Class Initialized
INFO - 2018-02-28 12:03:11 --> Loader Class Initialized
INFO - 2018-02-28 12:03:11 --> Helper loaded: url_helper
INFO - 2018-02-28 12:03:11 --> Helper loaded: file_helper
INFO - 2018-02-28 12:03:11 --> Helper loaded: email_helper
INFO - 2018-02-28 12:03:11 --> Helper loaded: common_helper
INFO - 2018-02-28 12:03:11 --> Database Driver Class Initialized
DEBUG - 2018-02-28 12:03:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-28 12:03:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-28 12:03:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-28 12:03:11 --> Pagination Class Initialized
INFO - 2018-02-28 12:03:11 --> Helper loaded: form_helper
INFO - 2018-02-28 12:03:11 --> Form Validation Class Initialized
INFO - 2018-02-28 12:03:11 --> Model Class Initialized
INFO - 2018-02-28 12:03:11 --> Controller Class Initialized
DEBUG - 2018-02-28 12:03:11 --> Config file loaded: /var/www/html/project/periodtracker/application/config/rest.php
INFO - 2018-02-28 12:03:11 --> Helper loaded: inflector_helper
INFO - 2018-02-28 12:03:11 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-28 12:03:11 --> Model Class Initialized
INFO - 2018-02-28 12:03:11 --> Model Class Initialized
INFO - 2018-02-28 12:03:11 --> Model Class Initialized
ERROR - 2018-02-28 12:03:11 --> Severity: Notice --> Undefined property: Oauth::$Usermaster_model /var/www/html/project/periodtracker/application/controllers/api/Oauth.php 676
ERROR - 2018-02-28 12:03:11 --> Severity: error --> Exception: Call to a member function updateData() on null /var/www/html/project/periodtracker/application/controllers/api/Oauth.php 676
INFO - 2018-02-28 12:03:23 --> Config Class Initialized
INFO - 2018-02-28 12:03:23 --> Hooks Class Initialized
DEBUG - 2018-02-28 12:03:23 --> UTF-8 Support Enabled
INFO - 2018-02-28 12:03:23 --> Utf8 Class Initialized
INFO - 2018-02-28 12:03:23 --> URI Class Initialized
INFO - 2018-02-28 12:03:23 --> Router Class Initialized
INFO - 2018-02-28 12:03:23 --> Output Class Initialized
INFO - 2018-02-28 12:03:23 --> Security Class Initialized
DEBUG - 2018-02-28 12:03:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-28 12:03:23 --> Input Class Initialized
INFO - 2018-02-28 12:03:23 --> Language Class Initialized
INFO - 2018-02-28 12:03:23 --> Loader Class Initialized
INFO - 2018-02-28 12:03:23 --> Helper loaded: url_helper
INFO - 2018-02-28 12:03:23 --> Helper loaded: file_helper
INFO - 2018-02-28 12:03:23 --> Helper loaded: email_helper
INFO - 2018-02-28 12:03:23 --> Helper loaded: common_helper
INFO - 2018-02-28 12:03:23 --> Database Driver Class Initialized
DEBUG - 2018-02-28 12:03:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-28 12:03:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-28 12:03:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-28 12:03:23 --> Pagination Class Initialized
INFO - 2018-02-28 12:03:23 --> Helper loaded: form_helper
INFO - 2018-02-28 12:03:23 --> Form Validation Class Initialized
INFO - 2018-02-28 12:03:23 --> Model Class Initialized
INFO - 2018-02-28 12:03:23 --> Controller Class Initialized
DEBUG - 2018-02-28 12:03:23 --> Config file loaded: /var/www/html/project/periodtracker/application/config/rest.php
INFO - 2018-02-28 12:03:23 --> Helper loaded: inflector_helper
INFO - 2018-02-28 12:03:23 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-28 12:03:23 --> Model Class Initialized
INFO - 2018-02-28 12:03:23 --> Model Class Initialized
INFO - 2018-02-28 12:03:23 --> Model Class Initialized
INFO - 2018-02-28 12:03:23 --> Final output sent to browser
DEBUG - 2018-02-28 12:03:23 --> Total execution time: 0.0513
INFO - 2018-02-28 12:03:26 --> Config Class Initialized
INFO - 2018-02-28 12:03:26 --> Hooks Class Initialized
DEBUG - 2018-02-28 12:03:26 --> UTF-8 Support Enabled
INFO - 2018-02-28 12:03:26 --> Utf8 Class Initialized
INFO - 2018-02-28 12:03:26 --> URI Class Initialized
INFO - 2018-02-28 12:03:26 --> Router Class Initialized
INFO - 2018-02-28 12:03:26 --> Output Class Initialized
INFO - 2018-02-28 12:03:26 --> Security Class Initialized
DEBUG - 2018-02-28 12:03:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-28 12:03:26 --> Input Class Initialized
INFO - 2018-02-28 12:03:26 --> Language Class Initialized
INFO - 2018-02-28 12:03:26 --> Loader Class Initialized
INFO - 2018-02-28 12:03:26 --> Helper loaded: url_helper
INFO - 2018-02-28 12:03:26 --> Helper loaded: file_helper
INFO - 2018-02-28 12:03:26 --> Helper loaded: email_helper
INFO - 2018-02-28 12:03:26 --> Helper loaded: common_helper
INFO - 2018-02-28 12:03:26 --> Database Driver Class Initialized
DEBUG - 2018-02-28 12:03:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-28 12:03:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-28 12:03:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-28 12:03:26 --> Pagination Class Initialized
INFO - 2018-02-28 12:03:26 --> Helper loaded: form_helper
INFO - 2018-02-28 12:03:26 --> Form Validation Class Initialized
INFO - 2018-02-28 12:03:26 --> Model Class Initialized
INFO - 2018-02-28 12:03:26 --> Controller Class Initialized
DEBUG - 2018-02-28 12:03:26 --> Config file loaded: /var/www/html/project/periodtracker/application/config/rest.php
INFO - 2018-02-28 12:03:26 --> Helper loaded: inflector_helper
INFO - 2018-02-28 12:03:26 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-28 12:03:26 --> Model Class Initialized
INFO - 2018-02-28 12:03:26 --> Model Class Initialized
INFO - 2018-02-28 12:03:26 --> Model Class Initialized
INFO - 2018-02-28 12:03:26 --> Final output sent to browser
DEBUG - 2018-02-28 12:03:26 --> Total execution time: 0.0074
INFO - 2018-02-28 15:27:24 --> Config Class Initialized
INFO - 2018-02-28 15:27:24 --> Hooks Class Initialized
DEBUG - 2018-02-28 15:27:24 --> UTF-8 Support Enabled
INFO - 2018-02-28 15:27:24 --> Utf8 Class Initialized
INFO - 2018-02-28 15:27:24 --> URI Class Initialized
INFO - 2018-02-28 15:27:24 --> Router Class Initialized
INFO - 2018-02-28 15:27:24 --> Output Class Initialized
INFO - 2018-02-28 15:27:24 --> Security Class Initialized
DEBUG - 2018-02-28 15:27:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-28 15:27:24 --> Input Class Initialized
INFO - 2018-02-28 15:27:24 --> Language Class Initialized
INFO - 2018-02-28 15:27:24 --> Loader Class Initialized
INFO - 2018-02-28 15:27:24 --> Helper loaded: url_helper
INFO - 2018-02-28 15:27:24 --> Helper loaded: file_helper
INFO - 2018-02-28 15:27:24 --> Helper loaded: email_helper
INFO - 2018-02-28 15:27:24 --> Helper loaded: common_helper
INFO - 2018-02-28 15:27:24 --> Database Driver Class Initialized
DEBUG - 2018-02-28 15:27:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-28 15:27:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-28 15:27:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-28 15:27:24 --> Pagination Class Initialized
INFO - 2018-02-28 15:27:24 --> Helper loaded: form_helper
INFO - 2018-02-28 15:27:24 --> Form Validation Class Initialized
INFO - 2018-02-28 15:27:24 --> Model Class Initialized
INFO - 2018-02-28 15:27:24 --> Controller Class Initialized
DEBUG - 2018-02-28 15:27:24 --> Config file loaded: /var/www/html/project/periodtracker/application/config/rest.php
INFO - 2018-02-28 15:27:24 --> Helper loaded: inflector_helper
INFO - 2018-02-28 15:27:24 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-28 15:27:24 --> Model Class Initialized
INFO - 2018-02-28 15:27:24 --> Model Class Initialized
INFO - 2018-02-28 15:27:24 --> Model Class Initialized
INFO - 2018-02-28 15:27:24 --> Final output sent to browser
DEBUG - 2018-02-28 15:27:24 --> Total execution time: 0.0371
INFO - 2018-02-28 15:29:12 --> Config Class Initialized
INFO - 2018-02-28 15:29:12 --> Hooks Class Initialized
DEBUG - 2018-02-28 15:29:12 --> UTF-8 Support Enabled
INFO - 2018-02-28 15:29:12 --> Utf8 Class Initialized
INFO - 2018-02-28 15:29:12 --> URI Class Initialized
INFO - 2018-02-28 15:29:12 --> Router Class Initialized
INFO - 2018-02-28 15:29:12 --> Output Class Initialized
INFO - 2018-02-28 15:29:12 --> Security Class Initialized
DEBUG - 2018-02-28 15:29:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-28 15:29:12 --> Input Class Initialized
INFO - 2018-02-28 15:29:12 --> Language Class Initialized
INFO - 2018-02-28 15:29:12 --> Loader Class Initialized
INFO - 2018-02-28 15:29:12 --> Helper loaded: url_helper
INFO - 2018-02-28 15:29:12 --> Helper loaded: file_helper
INFO - 2018-02-28 15:29:12 --> Helper loaded: email_helper
INFO - 2018-02-28 15:29:12 --> Helper loaded: common_helper
INFO - 2018-02-28 15:29:12 --> Database Driver Class Initialized
DEBUG - 2018-02-28 15:29:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-28 15:29:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-28 15:29:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-28 15:29:12 --> Pagination Class Initialized
INFO - 2018-02-28 15:29:12 --> Helper loaded: form_helper
INFO - 2018-02-28 15:29:12 --> Form Validation Class Initialized
INFO - 2018-02-28 15:29:12 --> Model Class Initialized
INFO - 2018-02-28 15:29:12 --> Controller Class Initialized
DEBUG - 2018-02-28 15:29:12 --> Config file loaded: /var/www/html/project/periodtracker/application/config/rest.php
INFO - 2018-02-28 15:29:12 --> Helper loaded: inflector_helper
INFO - 2018-02-28 15:29:12 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-28 15:29:12 --> Model Class Initialized
INFO - 2018-02-28 15:29:12 --> Model Class Initialized
INFO - 2018-02-28 15:29:12 --> Model Class Initialized
INFO - 2018-02-28 15:29:12 --> Final output sent to browser
DEBUG - 2018-02-28 15:29:12 --> Total execution time: 0.0505
INFO - 2018-02-28 15:29:26 --> Config Class Initialized
INFO - 2018-02-28 15:29:26 --> Hooks Class Initialized
DEBUG - 2018-02-28 15:29:26 --> UTF-8 Support Enabled
INFO - 2018-02-28 15:29:26 --> Utf8 Class Initialized
INFO - 2018-02-28 15:29:26 --> URI Class Initialized
INFO - 2018-02-28 15:29:26 --> Router Class Initialized
INFO - 2018-02-28 15:29:26 --> Output Class Initialized
INFO - 2018-02-28 15:29:26 --> Security Class Initialized
DEBUG - 2018-02-28 15:29:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-28 15:29:26 --> Input Class Initialized
INFO - 2018-02-28 15:29:26 --> Language Class Initialized
INFO - 2018-02-28 15:29:26 --> Loader Class Initialized
INFO - 2018-02-28 15:29:26 --> Helper loaded: url_helper
INFO - 2018-02-28 15:29:26 --> Helper loaded: file_helper
INFO - 2018-02-28 15:29:26 --> Helper loaded: email_helper
INFO - 2018-02-28 15:29:26 --> Helper loaded: common_helper
INFO - 2018-02-28 15:29:26 --> Database Driver Class Initialized
DEBUG - 2018-02-28 15:29:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-28 15:29:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-28 15:29:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-28 15:29:26 --> Pagination Class Initialized
INFO - 2018-02-28 15:29:26 --> Helper loaded: form_helper
INFO - 2018-02-28 15:29:26 --> Form Validation Class Initialized
INFO - 2018-02-28 15:29:26 --> Model Class Initialized
INFO - 2018-02-28 15:29:26 --> Controller Class Initialized
DEBUG - 2018-02-28 15:29:26 --> Config file loaded: /var/www/html/project/periodtracker/application/config/rest.php
INFO - 2018-02-28 15:29:26 --> Helper loaded: inflector_helper
INFO - 2018-02-28 15:29:26 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-28 15:29:26 --> Model Class Initialized
INFO - 2018-02-28 15:29:26 --> Model Class Initialized
INFO - 2018-02-28 15:29:26 --> Model Class Initialized
INFO - 2018-02-28 15:29:26 --> Final output sent to browser
DEBUG - 2018-02-28 15:29:26 --> Total execution time: 0.0463

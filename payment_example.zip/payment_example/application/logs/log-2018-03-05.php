<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2018-03-05 18:47:59 --> Config Class Initialized
INFO - 2018-03-05 18:47:59 --> Hooks Class Initialized
DEBUG - 2018-03-05 18:47:59 --> UTF-8 Support Enabled
INFO - 2018-03-05 18:47:59 --> Utf8 Class Initialized
INFO - 2018-03-05 18:47:59 --> URI Class Initialized
DEBUG - 2018-03-05 18:47:59 --> No URI present. Default controller set.
INFO - 2018-03-05 18:47:59 --> Router Class Initialized
INFO - 2018-03-05 18:47:59 --> Output Class Initialized
INFO - 2018-03-05 18:47:59 --> Security Class Initialized
DEBUG - 2018-03-05 18:47:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-05 18:47:59 --> Input Class Initialized
INFO - 2018-03-05 18:47:59 --> Language Class Initialized
INFO - 2018-03-05 18:47:59 --> Loader Class Initialized
INFO - 2018-03-05 18:47:59 --> Helper loaded: url_helper
INFO - 2018-03-05 18:47:59 --> Helper loaded: file_helper
INFO - 2018-03-05 18:47:59 --> Helper loaded: email_helper
INFO - 2018-03-05 18:47:59 --> Helper loaded: common_helper
INFO - 2018-03-05 18:47:59 --> Database Driver Class Initialized
DEBUG - 2018-03-05 18:47:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-05 18:47:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-05 18:47:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-03-05 18:47:59 --> Pagination Class Initialized
INFO - 2018-03-05 18:47:59 --> Helper loaded: form_helper
INFO - 2018-03-05 18:47:59 --> Form Validation Class Initialized
INFO - 2018-03-05 18:47:59 --> Model Class Initialized
INFO - 2018-03-05 18:47:59 --> Controller Class Initialized
INFO - 2018-03-05 18:47:59 --> Language file loaded: language/english/english_lang.php
INFO - 2018-03-05 18:47:59 --> Model Class Initialized
INFO - 2018-03-05 18:47:59 --> Model Class Initialized
INFO - 2018-03-05 18:47:59 --> File loaded: /var/www/html/project/periodtracker/application/views/index/index.php
INFO - 2018-03-05 18:47:59 --> Final output sent to browser
DEBUG - 2018-03-05 18:47:59 --> Total execution time: 0.0286
INFO - 2018-03-05 18:48:06 --> Config Class Initialized
INFO - 2018-03-05 18:48:06 --> Hooks Class Initialized
DEBUG - 2018-03-05 18:48:06 --> UTF-8 Support Enabled
INFO - 2018-03-05 18:48:06 --> Utf8 Class Initialized
INFO - 2018-03-05 18:48:06 --> URI Class Initialized
INFO - 2018-03-05 18:48:06 --> Router Class Initialized
INFO - 2018-03-05 18:48:06 --> Output Class Initialized
INFO - 2018-03-05 18:48:06 --> Security Class Initialized
DEBUG - 2018-03-05 18:48:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-05 18:48:06 --> Input Class Initialized
INFO - 2018-03-05 18:48:06 --> Language Class Initialized
INFO - 2018-03-05 18:48:06 --> Loader Class Initialized
INFO - 2018-03-05 18:48:06 --> Helper loaded: url_helper
INFO - 2018-03-05 18:48:06 --> Helper loaded: file_helper
INFO - 2018-03-05 18:48:06 --> Helper loaded: email_helper
INFO - 2018-03-05 18:48:06 --> Helper loaded: common_helper
INFO - 2018-03-05 18:48:06 --> Database Driver Class Initialized
DEBUG - 2018-03-05 18:48:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-05 18:48:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-05 18:48:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-03-05 18:48:06 --> Pagination Class Initialized
INFO - 2018-03-05 18:48:06 --> Helper loaded: form_helper
INFO - 2018-03-05 18:48:06 --> Form Validation Class Initialized
INFO - 2018-03-05 18:48:06 --> Model Class Initialized
INFO - 2018-03-05 18:48:06 --> Controller Class Initialized
INFO - 2018-03-05 18:48:06 --> Language file loaded: language/english/english_lang.php
INFO - 2018-03-05 18:48:06 --> Model Class Initialized
INFO - 2018-03-05 18:48:06 --> Model Class Initialized
ERROR - 2018-03-05 18:48:06 --> Query error: Table 'periodtracker.admin_master' doesn't exist - Invalid query: SELECT *
FROM `admin_master`
WHERE `vUserName` = 'admin'
AND `vPassword` = '21232f297a57a5a743894a0e4a801fc3'
AND `tStatus` = 1
INFO - 2018-03-05 18:48:06 --> Language file loaded: language/english/db_lang.php
INFO - 2018-03-05 18:49:55 --> Config Class Initialized
INFO - 2018-03-05 18:49:55 --> Hooks Class Initialized
DEBUG - 2018-03-05 18:49:55 --> UTF-8 Support Enabled
INFO - 2018-03-05 18:49:55 --> Utf8 Class Initialized
INFO - 2018-03-05 18:49:55 --> URI Class Initialized
DEBUG - 2018-03-05 18:49:55 --> No URI present. Default controller set.
INFO - 2018-03-05 18:49:55 --> Router Class Initialized
INFO - 2018-03-05 18:49:55 --> Output Class Initialized
INFO - 2018-03-05 18:49:55 --> Security Class Initialized
DEBUG - 2018-03-05 18:49:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-05 18:49:55 --> Input Class Initialized
INFO - 2018-03-05 18:49:55 --> Language Class Initialized
INFO - 2018-03-05 18:49:55 --> Loader Class Initialized
INFO - 2018-03-05 18:49:55 --> Helper loaded: url_helper
INFO - 2018-03-05 18:49:55 --> Helper loaded: file_helper
INFO - 2018-03-05 18:49:55 --> Helper loaded: email_helper
INFO - 2018-03-05 18:49:55 --> Helper loaded: common_helper
INFO - 2018-03-05 18:49:55 --> Database Driver Class Initialized
DEBUG - 2018-03-05 18:49:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-05 18:49:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-05 18:49:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-03-05 18:49:55 --> Pagination Class Initialized
INFO - 2018-03-05 18:49:55 --> Helper loaded: form_helper
INFO - 2018-03-05 18:49:55 --> Form Validation Class Initialized
INFO - 2018-03-05 18:49:55 --> Model Class Initialized
INFO - 2018-03-05 18:49:55 --> Controller Class Initialized
INFO - 2018-03-05 18:49:55 --> Language file loaded: language/english/english_lang.php
INFO - 2018-03-05 18:49:55 --> Model Class Initialized
INFO - 2018-03-05 18:49:55 --> Model Class Initialized
INFO - 2018-03-05 18:49:55 --> File loaded: /var/www/html/project/periodtracker/application/views/index/index.php
INFO - 2018-03-05 18:49:55 --> Final output sent to browser
DEBUG - 2018-03-05 18:49:55 --> Total execution time: 0.0056
INFO - 2018-03-05 18:49:59 --> Config Class Initialized
INFO - 2018-03-05 18:49:59 --> Hooks Class Initialized
DEBUG - 2018-03-05 18:49:59 --> UTF-8 Support Enabled
INFO - 2018-03-05 18:49:59 --> Utf8 Class Initialized
INFO - 2018-03-05 18:49:59 --> URI Class Initialized
INFO - 2018-03-05 18:49:59 --> Router Class Initialized
INFO - 2018-03-05 18:49:59 --> Output Class Initialized
INFO - 2018-03-05 18:49:59 --> Security Class Initialized
DEBUG - 2018-03-05 18:49:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-05 18:49:59 --> Input Class Initialized
INFO - 2018-03-05 18:49:59 --> Language Class Initialized
INFO - 2018-03-05 18:49:59 --> Loader Class Initialized
INFO - 2018-03-05 18:49:59 --> Helper loaded: url_helper
INFO - 2018-03-05 18:49:59 --> Helper loaded: file_helper
INFO - 2018-03-05 18:49:59 --> Helper loaded: email_helper
INFO - 2018-03-05 18:49:59 --> Helper loaded: common_helper
INFO - 2018-03-05 18:49:59 --> Database Driver Class Initialized
DEBUG - 2018-03-05 18:49:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-05 18:49:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-05 18:49:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-03-05 18:49:59 --> Pagination Class Initialized
INFO - 2018-03-05 18:49:59 --> Helper loaded: form_helper
INFO - 2018-03-05 18:49:59 --> Form Validation Class Initialized
INFO - 2018-03-05 18:49:59 --> Model Class Initialized
INFO - 2018-03-05 18:49:59 --> Controller Class Initialized
INFO - 2018-03-05 18:49:59 --> Language file loaded: language/english/english_lang.php
INFO - 2018-03-05 18:49:59 --> Model Class Initialized
INFO - 2018-03-05 18:49:59 --> Model Class Initialized
ERROR - 2018-03-05 18:49:59 --> Severity: Notice --> Undefined index: remember_me /var/www/html/project/periodtracker/application/controllers/Index.php 74
INFO - 2018-03-05 18:49:59 --> Config Class Initialized
INFO - 2018-03-05 18:49:59 --> Hooks Class Initialized
DEBUG - 2018-03-05 18:49:59 --> UTF-8 Support Enabled
INFO - 2018-03-05 18:49:59 --> Utf8 Class Initialized
INFO - 2018-03-05 18:49:59 --> URI Class Initialized
INFO - 2018-03-05 18:49:59 --> Router Class Initialized
INFO - 2018-03-05 18:49:59 --> Output Class Initialized
INFO - 2018-03-05 18:49:59 --> Security Class Initialized
DEBUG - 2018-03-05 18:49:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-05 18:49:59 --> Input Class Initialized
INFO - 2018-03-05 18:49:59 --> Language Class Initialized
ERROR - 2018-03-05 18:49:59 --> 404 Page Not Found: Dashboard/index
INFO - 2018-03-05 18:50:11 --> Config Class Initialized
INFO - 2018-03-05 18:50:11 --> Hooks Class Initialized
DEBUG - 2018-03-05 18:50:11 --> UTF-8 Support Enabled
INFO - 2018-03-05 18:50:11 --> Utf8 Class Initialized
INFO - 2018-03-05 18:50:11 --> URI Class Initialized
DEBUG - 2018-03-05 18:50:11 --> No URI present. Default controller set.
INFO - 2018-03-05 18:50:11 --> Router Class Initialized
INFO - 2018-03-05 18:50:11 --> Output Class Initialized
INFO - 2018-03-05 18:50:11 --> Security Class Initialized
DEBUG - 2018-03-05 18:50:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-05 18:50:11 --> Input Class Initialized
INFO - 2018-03-05 18:50:11 --> Language Class Initialized
INFO - 2018-03-05 18:50:11 --> Loader Class Initialized
INFO - 2018-03-05 18:50:11 --> Helper loaded: url_helper
INFO - 2018-03-05 18:50:11 --> Helper loaded: file_helper
INFO - 2018-03-05 18:50:11 --> Helper loaded: email_helper
INFO - 2018-03-05 18:50:11 --> Helper loaded: common_helper
INFO - 2018-03-05 18:50:11 --> Database Driver Class Initialized
DEBUG - 2018-03-05 18:50:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-05 18:50:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-05 18:50:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-03-05 18:50:11 --> Pagination Class Initialized
INFO - 2018-03-05 18:50:11 --> Helper loaded: form_helper
INFO - 2018-03-05 18:50:11 --> Form Validation Class Initialized
INFO - 2018-03-05 18:50:11 --> Model Class Initialized
INFO - 2018-03-05 18:50:11 --> Controller Class Initialized
INFO - 2018-03-05 18:50:11 --> Language file loaded: language/english/english_lang.php
INFO - 2018-03-05 18:50:11 --> Model Class Initialized
INFO - 2018-03-05 18:50:11 --> Model Class Initialized
INFO - 2018-03-05 18:50:11 --> File loaded: /var/www/html/project/periodtracker/application/views/index/index.php
INFO - 2018-03-05 18:50:11 --> Final output sent to browser
DEBUG - 2018-03-05 18:50:11 --> Total execution time: 0.0055
INFO - 2018-03-05 18:50:15 --> Config Class Initialized
INFO - 2018-03-05 18:50:15 --> Hooks Class Initialized
DEBUG - 2018-03-05 18:50:15 --> UTF-8 Support Enabled
INFO - 2018-03-05 18:50:15 --> Utf8 Class Initialized
INFO - 2018-03-05 18:50:15 --> URI Class Initialized
INFO - 2018-03-05 18:50:15 --> Router Class Initialized
INFO - 2018-03-05 18:50:15 --> Output Class Initialized
INFO - 2018-03-05 18:50:15 --> Security Class Initialized
DEBUG - 2018-03-05 18:50:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-05 18:50:15 --> Input Class Initialized
INFO - 2018-03-05 18:50:15 --> Language Class Initialized
INFO - 2018-03-05 18:50:15 --> Loader Class Initialized
INFO - 2018-03-05 18:50:15 --> Helper loaded: url_helper
INFO - 2018-03-05 18:50:15 --> Helper loaded: file_helper
INFO - 2018-03-05 18:50:15 --> Helper loaded: email_helper
INFO - 2018-03-05 18:50:15 --> Helper loaded: common_helper
INFO - 2018-03-05 18:50:15 --> Database Driver Class Initialized
DEBUG - 2018-03-05 18:50:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-05 18:50:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-05 18:50:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-03-05 18:50:15 --> Pagination Class Initialized
INFO - 2018-03-05 18:50:15 --> Helper loaded: form_helper
INFO - 2018-03-05 18:50:15 --> Form Validation Class Initialized
INFO - 2018-03-05 18:50:15 --> Model Class Initialized
INFO - 2018-03-05 18:50:15 --> Controller Class Initialized
INFO - 2018-03-05 18:50:15 --> Language file loaded: language/english/english_lang.php
INFO - 2018-03-05 18:50:15 --> Model Class Initialized
INFO - 2018-03-05 18:50:15 --> Model Class Initialized
INFO - 2018-03-05 18:50:15 --> File loaded: /var/www/html/project/periodtracker/application/views/index/index.php
INFO - 2018-03-05 18:50:15 --> Final output sent to browser
DEBUG - 2018-03-05 18:50:15 --> Total execution time: 0.0077
INFO - 2018-03-05 18:50:20 --> Config Class Initialized
INFO - 2018-03-05 18:50:20 --> Hooks Class Initialized
DEBUG - 2018-03-05 18:50:20 --> UTF-8 Support Enabled
INFO - 2018-03-05 18:50:20 --> Utf8 Class Initialized
INFO - 2018-03-05 18:50:20 --> URI Class Initialized
INFO - 2018-03-05 18:50:20 --> Router Class Initialized
INFO - 2018-03-05 18:50:20 --> Output Class Initialized
INFO - 2018-03-05 18:50:20 --> Security Class Initialized
DEBUG - 2018-03-05 18:50:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-05 18:50:20 --> Input Class Initialized
INFO - 2018-03-05 18:50:20 --> Language Class Initialized
INFO - 2018-03-05 18:50:20 --> Loader Class Initialized
INFO - 2018-03-05 18:50:20 --> Helper loaded: url_helper
INFO - 2018-03-05 18:50:20 --> Helper loaded: file_helper
INFO - 2018-03-05 18:50:20 --> Helper loaded: email_helper
INFO - 2018-03-05 18:50:20 --> Helper loaded: common_helper
INFO - 2018-03-05 18:50:20 --> Database Driver Class Initialized
DEBUG - 2018-03-05 18:50:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-05 18:50:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-05 18:50:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-03-05 18:50:20 --> Pagination Class Initialized
INFO - 2018-03-05 18:50:20 --> Helper loaded: form_helper
INFO - 2018-03-05 18:50:20 --> Form Validation Class Initialized
INFO - 2018-03-05 18:50:20 --> Model Class Initialized
INFO - 2018-03-05 18:50:20 --> Controller Class Initialized
INFO - 2018-03-05 18:50:20 --> Language file loaded: language/english/english_lang.php
INFO - 2018-03-05 18:50:20 --> Model Class Initialized
INFO - 2018-03-05 18:50:20 --> Model Class Initialized
INFO - 2018-03-05 18:50:20 --> File loaded: /var/www/html/project/periodtracker/application/views/index/index.php
INFO - 2018-03-05 18:50:20 --> Final output sent to browser
DEBUG - 2018-03-05 18:50:20 --> Total execution time: 0.0066
INFO - 2018-03-05 18:52:06 --> Config Class Initialized
INFO - 2018-03-05 18:52:06 --> Hooks Class Initialized
DEBUG - 2018-03-05 18:52:06 --> UTF-8 Support Enabled
INFO - 2018-03-05 18:52:06 --> Utf8 Class Initialized
INFO - 2018-03-05 18:52:06 --> URI Class Initialized
INFO - 2018-03-05 18:52:06 --> Router Class Initialized
INFO - 2018-03-05 18:52:06 --> Output Class Initialized
INFO - 2018-03-05 18:52:06 --> Security Class Initialized
DEBUG - 2018-03-05 18:52:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-05 18:52:06 --> Input Class Initialized
INFO - 2018-03-05 18:52:06 --> Language Class Initialized
ERROR - 2018-03-05 18:52:06 --> 404 Page Not Found: Dashboard/index
INFO - 2018-03-05 18:52:07 --> Config Class Initialized
INFO - 2018-03-05 18:52:07 --> Hooks Class Initialized
DEBUG - 2018-03-05 18:52:07 --> UTF-8 Support Enabled
INFO - 2018-03-05 18:52:07 --> Utf8 Class Initialized
INFO - 2018-03-05 18:52:07 --> URI Class Initialized
DEBUG - 2018-03-05 18:52:07 --> No URI present. Default controller set.
INFO - 2018-03-05 18:52:07 --> Router Class Initialized
INFO - 2018-03-05 18:52:07 --> Output Class Initialized
INFO - 2018-03-05 18:52:07 --> Security Class Initialized
DEBUG - 2018-03-05 18:52:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-05 18:52:07 --> Input Class Initialized
INFO - 2018-03-05 18:52:07 --> Language Class Initialized
INFO - 2018-03-05 18:52:07 --> Loader Class Initialized
INFO - 2018-03-05 18:52:07 --> Helper loaded: url_helper
INFO - 2018-03-05 18:52:07 --> Helper loaded: file_helper
INFO - 2018-03-05 18:52:07 --> Helper loaded: email_helper
INFO - 2018-03-05 18:52:07 --> Helper loaded: common_helper
INFO - 2018-03-05 18:52:07 --> Database Driver Class Initialized
DEBUG - 2018-03-05 18:52:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-05 18:52:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-05 18:52:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-03-05 18:52:07 --> Pagination Class Initialized
INFO - 2018-03-05 18:52:07 --> Helper loaded: form_helper
INFO - 2018-03-05 18:52:07 --> Form Validation Class Initialized
INFO - 2018-03-05 18:52:07 --> Model Class Initialized
INFO - 2018-03-05 18:52:07 --> Controller Class Initialized
INFO - 2018-03-05 18:52:07 --> Language file loaded: language/english/english_lang.php
INFO - 2018-03-05 18:52:07 --> Model Class Initialized
INFO - 2018-03-05 18:52:07 --> Model Class Initialized
INFO - 2018-03-05 18:52:12 --> Config Class Initialized
INFO - 2018-03-05 18:52:12 --> Hooks Class Initialized
DEBUG - 2018-03-05 18:52:12 --> UTF-8 Support Enabled
INFO - 2018-03-05 18:52:12 --> Utf8 Class Initialized
INFO - 2018-03-05 18:52:12 --> URI Class Initialized
DEBUG - 2018-03-05 18:52:12 --> No URI present. Default controller set.
INFO - 2018-03-05 18:52:12 --> Router Class Initialized
INFO - 2018-03-05 18:52:12 --> Output Class Initialized
INFO - 2018-03-05 18:52:12 --> Security Class Initialized
DEBUG - 2018-03-05 18:52:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-05 18:52:12 --> Input Class Initialized
INFO - 2018-03-05 18:52:12 --> Language Class Initialized
INFO - 2018-03-05 18:52:12 --> Loader Class Initialized
INFO - 2018-03-05 18:52:12 --> Helper loaded: url_helper
INFO - 2018-03-05 18:52:12 --> Helper loaded: file_helper
INFO - 2018-03-05 18:52:12 --> Helper loaded: email_helper
INFO - 2018-03-05 18:52:12 --> Helper loaded: common_helper
INFO - 2018-03-05 18:52:12 --> Database Driver Class Initialized
DEBUG - 2018-03-05 18:52:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-05 18:52:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-05 18:52:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-03-05 18:52:12 --> Pagination Class Initialized
INFO - 2018-03-05 18:52:12 --> Helper loaded: form_helper
INFO - 2018-03-05 18:52:12 --> Form Validation Class Initialized
INFO - 2018-03-05 18:52:12 --> Model Class Initialized
INFO - 2018-03-05 18:52:12 --> Controller Class Initialized
INFO - 2018-03-05 18:52:12 --> Language file loaded: language/english/english_lang.php
INFO - 2018-03-05 18:52:12 --> Model Class Initialized
INFO - 2018-03-05 18:52:12 --> Model Class Initialized
INFO - 2018-03-05 18:52:12 --> Config Class Initialized
INFO - 2018-03-05 18:52:12 --> Hooks Class Initialized
DEBUG - 2018-03-05 18:52:12 --> UTF-8 Support Enabled
INFO - 2018-03-05 18:52:12 --> Utf8 Class Initialized
INFO - 2018-03-05 18:52:12 --> URI Class Initialized
INFO - 2018-03-05 18:52:12 --> Router Class Initialized
INFO - 2018-03-05 18:52:12 --> Output Class Initialized
INFO - 2018-03-05 18:52:12 --> Security Class Initialized
DEBUG - 2018-03-05 18:52:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-05 18:52:12 --> Input Class Initialized
INFO - 2018-03-05 18:52:12 --> Language Class Initialized
ERROR - 2018-03-05 18:52:12 --> 404 Page Not Found: Dashboard/index

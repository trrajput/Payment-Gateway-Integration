<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2018-03-06 10:01:17 --> Config Class Initialized
INFO - 2018-03-06 10:01:17 --> Hooks Class Initialized
DEBUG - 2018-03-06 10:01:17 --> UTF-8 Support Enabled
INFO - 2018-03-06 10:01:17 --> Utf8 Class Initialized
INFO - 2018-03-06 10:01:17 --> URI Class Initialized
DEBUG - 2018-03-06 10:01:17 --> No URI present. Default controller set.
INFO - 2018-03-06 10:01:17 --> Router Class Initialized
INFO - 2018-03-06 10:01:17 --> Output Class Initialized
INFO - 2018-03-06 10:01:17 --> Security Class Initialized
DEBUG - 2018-03-06 10:01:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-06 10:01:17 --> Input Class Initialized
INFO - 2018-03-06 10:01:17 --> Language Class Initialized
INFO - 2018-03-06 10:01:17 --> Loader Class Initialized
INFO - 2018-03-06 10:01:17 --> Helper loaded: url_helper
INFO - 2018-03-06 10:01:17 --> Helper loaded: file_helper
INFO - 2018-03-06 10:01:17 --> Helper loaded: email_helper
INFO - 2018-03-06 10:01:17 --> Helper loaded: common_helper
INFO - 2018-03-06 10:01:17 --> Database Driver Class Initialized
DEBUG - 2018-03-06 10:01:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-06 10:01:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-06 10:01:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-03-06 10:01:17 --> Pagination Class Initialized
INFO - 2018-03-06 10:01:17 --> Helper loaded: form_helper
INFO - 2018-03-06 10:01:17 --> Form Validation Class Initialized
INFO - 2018-03-06 10:01:17 --> Model Class Initialized
INFO - 2018-03-06 10:01:17 --> Controller Class Initialized
INFO - 2018-03-06 10:01:17 --> Language file loaded: language/english/english_lang.php
INFO - 2018-03-06 10:01:17 --> Model Class Initialized
INFO - 2018-03-06 10:01:17 --> Model Class Initialized
INFO - 2018-03-06 10:01:17 --> File loaded: /var/www/html/project/periodtracker/application/views/index/index.php
INFO - 2018-03-06 10:01:17 --> Final output sent to browser
DEBUG - 2018-03-06 10:01:17 --> Total execution time: 0.3306
INFO - 2018-03-06 10:05:38 --> Config Class Initialized
INFO - 2018-03-06 10:05:38 --> Hooks Class Initialized
DEBUG - 2018-03-06 10:05:38 --> UTF-8 Support Enabled
INFO - 2018-03-06 10:05:38 --> Utf8 Class Initialized
INFO - 2018-03-06 10:05:38 --> URI Class Initialized
INFO - 2018-03-06 10:05:38 --> Router Class Initialized
INFO - 2018-03-06 10:05:38 --> Output Class Initialized
INFO - 2018-03-06 10:05:38 --> Security Class Initialized
DEBUG - 2018-03-06 10:05:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-06 10:05:38 --> Input Class Initialized
INFO - 2018-03-06 10:05:38 --> Language Class Initialized
INFO - 2018-03-06 10:05:38 --> Loader Class Initialized
INFO - 2018-03-06 10:05:38 --> Helper loaded: url_helper
INFO - 2018-03-06 10:05:38 --> Helper loaded: file_helper
INFO - 2018-03-06 10:05:38 --> Helper loaded: email_helper
INFO - 2018-03-06 10:05:38 --> Helper loaded: common_helper
INFO - 2018-03-06 10:05:38 --> Database Driver Class Initialized
DEBUG - 2018-03-06 10:05:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-06 10:05:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-06 10:05:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-03-06 10:05:38 --> Pagination Class Initialized
INFO - 2018-03-06 10:05:38 --> Helper loaded: form_helper
INFO - 2018-03-06 10:05:38 --> Form Validation Class Initialized
INFO - 2018-03-06 10:05:38 --> Model Class Initialized
INFO - 2018-03-06 10:05:38 --> Controller Class Initialized
INFO - 2018-03-06 10:05:38 --> Language file loaded: language/english/english_lang.php
INFO - 2018-03-06 10:05:38 --> Model Class Initialized
INFO - 2018-03-06 10:05:38 --> Model Class Initialized
ERROR - 2018-03-06 10:05:39 --> Severity: Notice --> Undefined index: remember_me /var/www/html/project/periodtracker/application/controllers/Index.php 74
INFO - 2018-03-06 10:05:39 --> Config Class Initialized
INFO - 2018-03-06 10:05:39 --> Hooks Class Initialized
DEBUG - 2018-03-06 10:05:39 --> UTF-8 Support Enabled
INFO - 2018-03-06 10:05:39 --> Utf8 Class Initialized
INFO - 2018-03-06 10:05:39 --> URI Class Initialized
INFO - 2018-03-06 10:05:39 --> Router Class Initialized
INFO - 2018-03-06 10:05:39 --> Output Class Initialized
INFO - 2018-03-06 10:05:39 --> Security Class Initialized
DEBUG - 2018-03-06 10:05:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-06 10:05:39 --> Input Class Initialized
INFO - 2018-03-06 10:05:39 --> Language Class Initialized
INFO - 2018-03-06 10:05:39 --> Loader Class Initialized
INFO - 2018-03-06 10:05:39 --> Helper loaded: url_helper
INFO - 2018-03-06 10:05:39 --> Helper loaded: file_helper
INFO - 2018-03-06 10:05:39 --> Helper loaded: email_helper
INFO - 2018-03-06 10:05:39 --> Helper loaded: common_helper
INFO - 2018-03-06 10:05:39 --> Database Driver Class Initialized
DEBUG - 2018-03-06 10:05:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-06 10:05:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-06 10:05:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-03-06 10:05:39 --> Pagination Class Initialized
INFO - 2018-03-06 10:05:39 --> Helper loaded: form_helper
INFO - 2018-03-06 10:05:39 --> Form Validation Class Initialized
INFO - 2018-03-06 10:05:39 --> Model Class Initialized
INFO - 2018-03-06 10:05:39 --> Controller Class Initialized
INFO - 2018-03-06 10:05:39 --> Language file loaded: language/english/english_lang.php
INFO - 2018-03-06 10:05:39 --> Model Class Initialized
INFO - 2018-03-06 10:05:39 --> File loaded: /var/www/html/project/periodtracker/application/views//template/side_bar.php
INFO - 2018-03-06 10:05:39 --> File loaded: /var/www/html/project/periodtracker/application/views//template/header.php
INFO - 2018-03-06 10:05:39 --> File loaded: /var/www/html/project/periodtracker/application/views//template/bread_crumb.php
INFO - 2018-03-06 10:05:39 --> File loaded: /var/www/html/project/periodtracker/application/views//template/footer.php
INFO - 2018-03-06 10:05:39 --> File loaded: /var/www/html/project/periodtracker/application/views/dashboard/index.php
INFO - 2018-03-06 10:05:39 --> Final output sent to browser
DEBUG - 2018-03-06 10:05:39 --> Total execution time: 0.0717
INFO - 2018-03-06 10:05:49 --> Config Class Initialized
INFO - 2018-03-06 10:05:49 --> Hooks Class Initialized
DEBUG - 2018-03-06 10:05:49 --> UTF-8 Support Enabled
INFO - 2018-03-06 10:05:49 --> Utf8 Class Initialized
INFO - 2018-03-06 10:05:49 --> URI Class Initialized
INFO - 2018-03-06 10:05:49 --> Router Class Initialized
INFO - 2018-03-06 10:05:49 --> Output Class Initialized
INFO - 2018-03-06 10:05:49 --> Security Class Initialized
DEBUG - 2018-03-06 10:05:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-06 10:05:49 --> Input Class Initialized
INFO - 2018-03-06 10:05:49 --> Language Class Initialized
INFO - 2018-03-06 10:05:49 --> Loader Class Initialized
INFO - 2018-03-06 10:05:49 --> Helper loaded: url_helper
INFO - 2018-03-06 10:05:49 --> Helper loaded: file_helper
INFO - 2018-03-06 10:05:49 --> Helper loaded: email_helper
INFO - 2018-03-06 10:05:49 --> Helper loaded: common_helper
INFO - 2018-03-06 10:05:49 --> Database Driver Class Initialized
DEBUG - 2018-03-06 10:05:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-06 10:05:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-06 10:05:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-03-06 10:05:49 --> Pagination Class Initialized
INFO - 2018-03-06 10:05:49 --> Helper loaded: form_helper
INFO - 2018-03-06 10:05:49 --> Form Validation Class Initialized
INFO - 2018-03-06 10:05:49 --> Model Class Initialized
INFO - 2018-03-06 10:05:49 --> Controller Class Initialized
INFO - 2018-03-06 10:05:49 --> Language file loaded: language/english/english_lang.php
INFO - 2018-03-06 10:05:49 --> Model Class Initialized
INFO - 2018-03-06 10:05:49 --> Model Class Initialized
INFO - 2018-03-06 10:05:49 --> Config Class Initialized
INFO - 2018-03-06 10:05:49 --> Hooks Class Initialized
DEBUG - 2018-03-06 10:05:49 --> UTF-8 Support Enabled
INFO - 2018-03-06 10:05:49 --> Utf8 Class Initialized
INFO - 2018-03-06 10:05:49 --> URI Class Initialized
INFO - 2018-03-06 10:05:49 --> Router Class Initialized
INFO - 2018-03-06 10:05:49 --> Output Class Initialized
INFO - 2018-03-06 10:05:49 --> Security Class Initialized
DEBUG - 2018-03-06 10:05:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-06 10:05:49 --> Input Class Initialized
INFO - 2018-03-06 10:05:49 --> Language Class Initialized
INFO - 2018-03-06 10:05:49 --> Loader Class Initialized
INFO - 2018-03-06 10:05:49 --> Helper loaded: url_helper
INFO - 2018-03-06 10:05:49 --> Helper loaded: file_helper
INFO - 2018-03-06 10:05:49 --> Helper loaded: email_helper
INFO - 2018-03-06 10:05:49 --> Helper loaded: common_helper
INFO - 2018-03-06 10:05:49 --> Database Driver Class Initialized
DEBUG - 2018-03-06 10:05:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-06 10:05:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-06 10:05:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-03-06 10:05:49 --> Pagination Class Initialized
INFO - 2018-03-06 10:05:49 --> Helper loaded: form_helper
INFO - 2018-03-06 10:05:49 --> Form Validation Class Initialized
INFO - 2018-03-06 10:05:49 --> Model Class Initialized
INFO - 2018-03-06 10:05:49 --> Controller Class Initialized
INFO - 2018-03-06 10:05:49 --> Language file loaded: language/english/english_lang.php
INFO - 2018-03-06 10:05:49 --> Model Class Initialized
INFO - 2018-03-06 10:05:49 --> Model Class Initialized
INFO - 2018-03-06 10:05:49 --> File loaded: /var/www/html/project/periodtracker/application/views/index/index.php
INFO - 2018-03-06 10:05:49 --> Final output sent to browser
DEBUG - 2018-03-06 10:05:49 --> Total execution time: 0.0042
INFO - 2018-03-06 10:06:12 --> Config Class Initialized
INFO - 2018-03-06 10:06:12 --> Hooks Class Initialized
DEBUG - 2018-03-06 10:06:12 --> UTF-8 Support Enabled
INFO - 2018-03-06 10:06:12 --> Utf8 Class Initialized
INFO - 2018-03-06 10:06:12 --> URI Class Initialized
INFO - 2018-03-06 10:06:12 --> Router Class Initialized
INFO - 2018-03-06 10:06:12 --> Output Class Initialized
INFO - 2018-03-06 10:06:12 --> Security Class Initialized
DEBUG - 2018-03-06 10:06:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-06 10:06:12 --> Input Class Initialized
INFO - 2018-03-06 10:06:12 --> Language Class Initialized
INFO - 2018-03-06 10:06:12 --> Loader Class Initialized
INFO - 2018-03-06 10:06:12 --> Helper loaded: url_helper
INFO - 2018-03-06 10:06:12 --> Helper loaded: file_helper
INFO - 2018-03-06 10:06:12 --> Helper loaded: email_helper
INFO - 2018-03-06 10:06:12 --> Helper loaded: common_helper
INFO - 2018-03-06 10:06:12 --> Database Driver Class Initialized
DEBUG - 2018-03-06 10:06:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-06 10:06:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-06 10:06:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-03-06 10:06:12 --> Pagination Class Initialized
INFO - 2018-03-06 10:06:12 --> Helper loaded: form_helper
INFO - 2018-03-06 10:06:12 --> Form Validation Class Initialized
INFO - 2018-03-06 10:06:12 --> Model Class Initialized
INFO - 2018-03-06 10:06:12 --> Controller Class Initialized
INFO - 2018-03-06 10:06:12 --> Language file loaded: language/english/english_lang.php
INFO - 2018-03-06 10:06:12 --> Model Class Initialized
INFO - 2018-03-06 10:06:12 --> Model Class Initialized
INFO - 2018-03-06 10:06:12 --> File loaded: /var/www/html/project/periodtracker/application/views/index/index.php
INFO - 2018-03-06 10:06:12 --> Final output sent to browser
DEBUG - 2018-03-06 10:06:12 --> Total execution time: 0.0088
INFO - 2018-03-06 10:07:54 --> Config Class Initialized
INFO - 2018-03-06 10:07:54 --> Hooks Class Initialized
DEBUG - 2018-03-06 10:07:54 --> UTF-8 Support Enabled
INFO - 2018-03-06 10:07:54 --> Utf8 Class Initialized
INFO - 2018-03-06 10:07:54 --> URI Class Initialized
INFO - 2018-03-06 10:07:54 --> Router Class Initialized
INFO - 2018-03-06 10:07:54 --> Output Class Initialized
INFO - 2018-03-06 10:07:54 --> Security Class Initialized
DEBUG - 2018-03-06 10:07:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-06 10:07:54 --> Input Class Initialized
INFO - 2018-03-06 10:07:54 --> Language Class Initialized
INFO - 2018-03-06 10:07:54 --> Loader Class Initialized
INFO - 2018-03-06 10:07:54 --> Helper loaded: url_helper
INFO - 2018-03-06 10:07:54 --> Helper loaded: file_helper
INFO - 2018-03-06 10:07:54 --> Helper loaded: email_helper
INFO - 2018-03-06 10:07:54 --> Helper loaded: common_helper
INFO - 2018-03-06 10:07:54 --> Database Driver Class Initialized
DEBUG - 2018-03-06 10:07:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-06 10:07:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-06 10:07:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-03-06 10:07:54 --> Pagination Class Initialized
INFO - 2018-03-06 10:07:54 --> Helper loaded: form_helper
INFO - 2018-03-06 10:07:54 --> Form Validation Class Initialized
INFO - 2018-03-06 10:07:54 --> Model Class Initialized
INFO - 2018-03-06 10:07:54 --> Controller Class Initialized
INFO - 2018-03-06 10:07:54 --> Language file loaded: language/english/english_lang.php
INFO - 2018-03-06 10:07:54 --> Model Class Initialized
INFO - 2018-03-06 10:07:54 --> Model Class Initialized
INFO - 2018-03-06 10:07:54 --> File loaded: /var/www/html/project/periodtracker/application/views/index/index.php
INFO - 2018-03-06 10:07:54 --> Final output sent to browser
DEBUG - 2018-03-06 10:07:54 --> Total execution time: 0.0100
INFO - 2018-03-06 10:08:03 --> Config Class Initialized
INFO - 2018-03-06 10:08:03 --> Hooks Class Initialized
DEBUG - 2018-03-06 10:08:03 --> UTF-8 Support Enabled
INFO - 2018-03-06 10:08:03 --> Utf8 Class Initialized
INFO - 2018-03-06 10:08:03 --> URI Class Initialized
INFO - 2018-03-06 10:08:03 --> Router Class Initialized
INFO - 2018-03-06 10:08:03 --> Output Class Initialized
INFO - 2018-03-06 10:08:03 --> Security Class Initialized
DEBUG - 2018-03-06 10:08:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-06 10:08:03 --> Input Class Initialized
INFO - 2018-03-06 10:08:03 --> Language Class Initialized
INFO - 2018-03-06 10:08:03 --> Loader Class Initialized
INFO - 2018-03-06 10:08:03 --> Helper loaded: url_helper
INFO - 2018-03-06 10:08:03 --> Helper loaded: file_helper
INFO - 2018-03-06 10:08:03 --> Helper loaded: email_helper
INFO - 2018-03-06 10:08:03 --> Helper loaded: common_helper
INFO - 2018-03-06 10:08:03 --> Database Driver Class Initialized
DEBUG - 2018-03-06 10:08:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-06 10:08:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-06 10:08:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-03-06 10:08:03 --> Pagination Class Initialized
INFO - 2018-03-06 10:08:03 --> Helper loaded: form_helper
INFO - 2018-03-06 10:08:03 --> Form Validation Class Initialized
INFO - 2018-03-06 10:08:03 --> Model Class Initialized
INFO - 2018-03-06 10:08:03 --> Controller Class Initialized
INFO - 2018-03-06 10:08:03 --> Language file loaded: language/english/english_lang.php
INFO - 2018-03-06 10:08:03 --> Model Class Initialized
INFO - 2018-03-06 10:08:03 --> Model Class Initialized
ERROR - 2018-03-06 10:08:03 --> Severity: Notice --> Undefined index: remember_me /var/www/html/project/periodtracker/application/controllers/Index.php 74
INFO - 2018-03-06 10:08:03 --> Config Class Initialized
INFO - 2018-03-06 10:08:03 --> Hooks Class Initialized
DEBUG - 2018-03-06 10:08:03 --> UTF-8 Support Enabled
INFO - 2018-03-06 10:08:03 --> Utf8 Class Initialized
INFO - 2018-03-06 10:08:03 --> URI Class Initialized
INFO - 2018-03-06 10:08:03 --> Router Class Initialized
INFO - 2018-03-06 10:08:03 --> Output Class Initialized
INFO - 2018-03-06 10:08:03 --> Security Class Initialized
DEBUG - 2018-03-06 10:08:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-06 10:08:03 --> Input Class Initialized
INFO - 2018-03-06 10:08:03 --> Language Class Initialized
INFO - 2018-03-06 10:08:03 --> Loader Class Initialized
INFO - 2018-03-06 10:08:03 --> Helper loaded: url_helper
INFO - 2018-03-06 10:08:03 --> Helper loaded: file_helper
INFO - 2018-03-06 10:08:03 --> Helper loaded: email_helper
INFO - 2018-03-06 10:08:03 --> Helper loaded: common_helper
INFO - 2018-03-06 10:08:03 --> Database Driver Class Initialized
DEBUG - 2018-03-06 10:08:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-06 10:08:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-06 10:08:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-03-06 10:08:03 --> Pagination Class Initialized
INFO - 2018-03-06 10:08:03 --> Helper loaded: form_helper
INFO - 2018-03-06 10:08:03 --> Form Validation Class Initialized
INFO - 2018-03-06 10:08:03 --> Model Class Initialized
INFO - 2018-03-06 10:08:03 --> Controller Class Initialized
INFO - 2018-03-06 10:08:03 --> Language file loaded: language/english/english_lang.php
INFO - 2018-03-06 10:08:03 --> Model Class Initialized
INFO - 2018-03-06 10:08:03 --> File loaded: /var/www/html/project/periodtracker/application/views//template/side_bar.php
INFO - 2018-03-06 10:08:03 --> File loaded: /var/www/html/project/periodtracker/application/views//template/header.php
INFO - 2018-03-06 10:08:03 --> File loaded: /var/www/html/project/periodtracker/application/views//template/bread_crumb.php
INFO - 2018-03-06 10:08:03 --> File loaded: /var/www/html/project/periodtracker/application/views//template/footer.php
INFO - 2018-03-06 10:08:03 --> File loaded: /var/www/html/project/periodtracker/application/views/dashboard/index.php
INFO - 2018-03-06 10:08:03 --> Final output sent to browser
DEBUG - 2018-03-06 10:08:03 --> Total execution time: 0.0053
INFO - 2018-03-06 10:12:01 --> Config Class Initialized
INFO - 2018-03-06 10:12:01 --> Hooks Class Initialized
DEBUG - 2018-03-06 10:12:01 --> UTF-8 Support Enabled
INFO - 2018-03-06 10:12:01 --> Utf8 Class Initialized
INFO - 2018-03-06 10:12:01 --> URI Class Initialized
INFO - 2018-03-06 10:12:01 --> Router Class Initialized
INFO - 2018-03-06 10:12:01 --> Output Class Initialized
INFO - 2018-03-06 10:12:01 --> Security Class Initialized
DEBUG - 2018-03-06 10:12:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-06 10:12:01 --> Input Class Initialized
INFO - 2018-03-06 10:12:01 --> Language Class Initialized
INFO - 2018-03-06 10:12:01 --> Loader Class Initialized
INFO - 2018-03-06 10:12:01 --> Helper loaded: url_helper
INFO - 2018-03-06 10:12:01 --> Helper loaded: file_helper
INFO - 2018-03-06 10:12:01 --> Helper loaded: email_helper
INFO - 2018-03-06 10:12:01 --> Helper loaded: common_helper
INFO - 2018-03-06 10:12:01 --> Database Driver Class Initialized
DEBUG - 2018-03-06 10:12:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-06 10:12:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-06 10:12:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-03-06 10:12:01 --> Pagination Class Initialized
INFO - 2018-03-06 10:12:01 --> Helper loaded: form_helper
INFO - 2018-03-06 10:12:01 --> Form Validation Class Initialized
INFO - 2018-03-06 10:12:01 --> Model Class Initialized
INFO - 2018-03-06 10:12:01 --> Controller Class Initialized
INFO - 2018-03-06 10:12:01 --> Language file loaded: language/english/english_lang.php
INFO - 2018-03-06 10:12:01 --> Model Class Initialized
INFO - 2018-03-06 10:12:01 --> File loaded: /var/www/html/project/periodtracker/application/views//template/side_bar.php
INFO - 2018-03-06 10:12:01 --> File loaded: /var/www/html/project/periodtracker/application/views//template/header.php
INFO - 2018-03-06 10:12:01 --> File loaded: /var/www/html/project/periodtracker/application/views//template/bread_crumb.php
INFO - 2018-03-06 10:12:01 --> File loaded: /var/www/html/project/periodtracker/application/views//template/footer.php
INFO - 2018-03-06 10:12:01 --> File loaded: /var/www/html/project/periodtracker/application/views/dashboard/index.php
INFO - 2018-03-06 10:12:01 --> Final output sent to browser
DEBUG - 2018-03-06 10:12:01 --> Total execution time: 0.0092
INFO - 2018-03-06 10:12:04 --> Config Class Initialized
INFO - 2018-03-06 10:12:04 --> Hooks Class Initialized
DEBUG - 2018-03-06 10:12:04 --> UTF-8 Support Enabled
INFO - 2018-03-06 10:12:04 --> Utf8 Class Initialized
INFO - 2018-03-06 10:12:04 --> URI Class Initialized
INFO - 2018-03-06 10:12:04 --> Router Class Initialized
INFO - 2018-03-06 10:12:04 --> Output Class Initialized
INFO - 2018-03-06 10:12:04 --> Security Class Initialized
DEBUG - 2018-03-06 10:12:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-06 10:12:04 --> Input Class Initialized
INFO - 2018-03-06 10:12:04 --> Language Class Initialized
INFO - 2018-03-06 10:12:04 --> Loader Class Initialized
INFO - 2018-03-06 10:12:04 --> Helper loaded: url_helper
INFO - 2018-03-06 10:12:04 --> Helper loaded: file_helper
INFO - 2018-03-06 10:12:04 --> Helper loaded: email_helper
INFO - 2018-03-06 10:12:04 --> Helper loaded: common_helper
INFO - 2018-03-06 10:12:04 --> Database Driver Class Initialized
DEBUG - 2018-03-06 10:12:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-06 10:12:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-06 10:12:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-03-06 10:12:04 --> Pagination Class Initialized
INFO - 2018-03-06 10:12:04 --> Helper loaded: form_helper
INFO - 2018-03-06 10:12:04 --> Form Validation Class Initialized
INFO - 2018-03-06 10:12:04 --> Model Class Initialized
INFO - 2018-03-06 10:12:04 --> Controller Class Initialized
INFO - 2018-03-06 10:12:04 --> Language file loaded: language/english/english_lang.php
INFO - 2018-03-06 10:12:04 --> Model Class Initialized
INFO - 2018-03-06 10:12:04 --> File loaded: /var/www/html/project/periodtracker/application/views//template/side_bar.php
INFO - 2018-03-06 10:12:04 --> File loaded: /var/www/html/project/periodtracker/application/views//template/header.php
INFO - 2018-03-06 10:12:04 --> File loaded: /var/www/html/project/periodtracker/application/views//template/bread_crumb.php
INFO - 2018-03-06 10:12:04 --> File loaded: /var/www/html/project/periodtracker/application/views//template/footer.php
INFO - 2018-03-06 10:12:04 --> File loaded: /var/www/html/project/periodtracker/application/views/dashboard/index.php
INFO - 2018-03-06 10:12:04 --> Final output sent to browser
DEBUG - 2018-03-06 10:12:04 --> Total execution time: 0.0056
INFO - 2018-03-06 10:12:05 --> Config Class Initialized
INFO - 2018-03-06 10:12:05 --> Hooks Class Initialized
DEBUG - 2018-03-06 10:12:05 --> UTF-8 Support Enabled
INFO - 2018-03-06 10:12:05 --> Utf8 Class Initialized
INFO - 2018-03-06 10:12:05 --> URI Class Initialized
INFO - 2018-03-06 10:12:05 --> Router Class Initialized
INFO - 2018-03-06 10:12:05 --> Output Class Initialized
INFO - 2018-03-06 10:12:05 --> Security Class Initialized
DEBUG - 2018-03-06 10:12:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-06 10:12:05 --> Input Class Initialized
INFO - 2018-03-06 10:12:05 --> Language Class Initialized
ERROR - 2018-03-06 10:12:05 --> 404 Page Not Found: User/index
INFO - 2018-03-06 10:12:06 --> Config Class Initialized
INFO - 2018-03-06 10:12:06 --> Hooks Class Initialized
DEBUG - 2018-03-06 10:12:06 --> UTF-8 Support Enabled
INFO - 2018-03-06 10:12:06 --> Utf8 Class Initialized
INFO - 2018-03-06 10:12:06 --> URI Class Initialized
INFO - 2018-03-06 10:12:06 --> Router Class Initialized
INFO - 2018-03-06 10:12:06 --> Output Class Initialized
INFO - 2018-03-06 10:12:06 --> Security Class Initialized
DEBUG - 2018-03-06 10:12:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-06 10:12:06 --> Input Class Initialized
INFO - 2018-03-06 10:12:06 --> Language Class Initialized
INFO - 2018-03-06 10:12:06 --> Loader Class Initialized
INFO - 2018-03-06 10:12:06 --> Helper loaded: url_helper
INFO - 2018-03-06 10:12:06 --> Helper loaded: file_helper
INFO - 2018-03-06 10:12:06 --> Helper loaded: email_helper
INFO - 2018-03-06 10:12:06 --> Helper loaded: common_helper
INFO - 2018-03-06 10:12:06 --> Database Driver Class Initialized
DEBUG - 2018-03-06 10:12:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-06 10:12:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-06 10:12:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-03-06 10:12:06 --> Pagination Class Initialized
INFO - 2018-03-06 10:12:06 --> Helper loaded: form_helper
INFO - 2018-03-06 10:12:06 --> Form Validation Class Initialized
INFO - 2018-03-06 10:12:06 --> Model Class Initialized
INFO - 2018-03-06 10:12:06 --> Controller Class Initialized
INFO - 2018-03-06 10:12:06 --> Language file loaded: language/english/english_lang.php
INFO - 2018-03-06 10:12:06 --> Model Class Initialized
INFO - 2018-03-06 10:12:06 --> File loaded: /var/www/html/project/periodtracker/application/views//template/side_bar.php
INFO - 2018-03-06 10:12:06 --> File loaded: /var/www/html/project/periodtracker/application/views//template/header.php
INFO - 2018-03-06 10:12:06 --> File loaded: /var/www/html/project/periodtracker/application/views//template/bread_crumb.php
INFO - 2018-03-06 10:12:06 --> File loaded: /var/www/html/project/periodtracker/application/views//template/footer.php
INFO - 2018-03-06 10:12:06 --> File loaded: /var/www/html/project/periodtracker/application/views/dashboard/index.php
INFO - 2018-03-06 10:12:06 --> Final output sent to browser
DEBUG - 2018-03-06 10:12:06 --> Total execution time: 0.0041
INFO - 2018-03-06 10:27:18 --> Config Class Initialized
INFO - 2018-03-06 10:27:18 --> Hooks Class Initialized
DEBUG - 2018-03-06 10:27:18 --> UTF-8 Support Enabled
INFO - 2018-03-06 10:27:18 --> Utf8 Class Initialized
INFO - 2018-03-06 10:27:18 --> URI Class Initialized
INFO - 2018-03-06 10:27:18 --> Router Class Initialized
INFO - 2018-03-06 10:27:18 --> Output Class Initialized
INFO - 2018-03-06 10:27:18 --> Security Class Initialized
DEBUG - 2018-03-06 10:27:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-06 10:27:18 --> Input Class Initialized
INFO - 2018-03-06 10:27:18 --> Language Class Initialized
INFO - 2018-03-06 10:27:18 --> Loader Class Initialized
INFO - 2018-03-06 10:27:18 --> Helper loaded: url_helper
INFO - 2018-03-06 10:27:18 --> Helper loaded: file_helper
INFO - 2018-03-06 10:27:18 --> Helper loaded: email_helper
INFO - 2018-03-06 10:27:18 --> Helper loaded: common_helper
INFO - 2018-03-06 10:27:18 --> Database Driver Class Initialized
DEBUG - 2018-03-06 10:27:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-06 10:27:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-06 10:27:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-03-06 10:27:18 --> Pagination Class Initialized
INFO - 2018-03-06 10:27:18 --> Helper loaded: form_helper
INFO - 2018-03-06 10:27:18 --> Form Validation Class Initialized
INFO - 2018-03-06 10:27:18 --> Model Class Initialized
INFO - 2018-03-06 10:27:18 --> Controller Class Initialized
INFO - 2018-03-06 10:27:18 --> Language file loaded: language/english/english_lang.php
INFO - 2018-03-06 10:27:18 --> Model Class Initialized
INFO - 2018-03-06 10:27:18 --> File loaded: /var/www/html/project/periodtracker/application/views//template/side_bar.php
INFO - 2018-03-06 10:27:18 --> File loaded: /var/www/html/project/periodtracker/application/views//template/header.php
INFO - 2018-03-06 10:27:18 --> File loaded: /var/www/html/project/periodtracker/application/views//template/bread_crumb.php
INFO - 2018-03-06 10:27:18 --> File loaded: /var/www/html/project/periodtracker/application/views//template/footer.php
INFO - 2018-03-06 10:27:18 --> File loaded: /var/www/html/project/periodtracker/application/views/dashboard/index.php
INFO - 2018-03-06 10:27:18 --> Final output sent to browser
DEBUG - 2018-03-06 10:27:18 --> Total execution time: 0.0113
INFO - 2018-03-06 10:27:20 --> Config Class Initialized
INFO - 2018-03-06 10:27:20 --> Hooks Class Initialized
DEBUG - 2018-03-06 10:27:20 --> UTF-8 Support Enabled
INFO - 2018-03-06 10:27:20 --> Utf8 Class Initialized
INFO - 2018-03-06 10:27:20 --> URI Class Initialized
INFO - 2018-03-06 10:27:20 --> Router Class Initialized
INFO - 2018-03-06 10:27:20 --> Output Class Initialized
INFO - 2018-03-06 10:27:20 --> Security Class Initialized
DEBUG - 2018-03-06 10:27:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-06 10:27:20 --> Input Class Initialized
INFO - 2018-03-06 10:27:20 --> Language Class Initialized
INFO - 2018-03-06 10:27:20 --> Loader Class Initialized
INFO - 2018-03-06 10:27:20 --> Helper loaded: url_helper
INFO - 2018-03-06 10:27:20 --> Helper loaded: file_helper
INFO - 2018-03-06 10:27:20 --> Helper loaded: email_helper
INFO - 2018-03-06 10:27:20 --> Helper loaded: common_helper
INFO - 2018-03-06 10:27:20 --> Database Driver Class Initialized
DEBUG - 2018-03-06 10:27:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-06 10:27:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-06 10:27:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-03-06 10:27:20 --> Pagination Class Initialized
INFO - 2018-03-06 10:27:20 --> Helper loaded: form_helper
INFO - 2018-03-06 10:27:20 --> Form Validation Class Initialized
INFO - 2018-03-06 10:27:20 --> Model Class Initialized
INFO - 2018-03-06 10:27:20 --> Controller Class Initialized
INFO - 2018-03-06 10:27:20 --> Language file loaded: language/english/english_lang.php
INFO - 2018-03-06 10:27:20 --> Model Class Initialized
INFO - 2018-03-06 10:27:20 --> File loaded: /var/www/html/project/periodtracker/application/views//template/side_bar.php
INFO - 2018-03-06 10:27:20 --> File loaded: /var/www/html/project/periodtracker/application/views//template/header.php
INFO - 2018-03-06 10:27:20 --> File loaded: /var/www/html/project/periodtracker/application/views//template/bread_crumb.php
INFO - 2018-03-06 10:27:20 --> File loaded: /var/www/html/project/periodtracker/application/views//template/footer.php
INFO - 2018-03-06 10:27:20 --> File loaded: /var/www/html/project/periodtracker/application/views/user/index.php
INFO - 2018-03-06 10:27:20 --> Final output sent to browser
DEBUG - 2018-03-06 10:27:20 --> Total execution time: 0.0055
INFO - 2018-03-06 10:27:20 --> Config Class Initialized
INFO - 2018-03-06 10:27:20 --> Hooks Class Initialized
DEBUG - 2018-03-06 10:27:20 --> UTF-8 Support Enabled
INFO - 2018-03-06 10:27:20 --> Utf8 Class Initialized
INFO - 2018-03-06 10:27:20 --> URI Class Initialized
INFO - 2018-03-06 10:27:20 --> Router Class Initialized
INFO - 2018-03-06 10:27:20 --> Output Class Initialized
INFO - 2018-03-06 10:27:20 --> Security Class Initialized
DEBUG - 2018-03-06 10:27:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-06 10:27:20 --> Input Class Initialized
INFO - 2018-03-06 10:27:20 --> Language Class Initialized
INFO - 2018-03-06 10:27:20 --> Loader Class Initialized
INFO - 2018-03-06 10:27:20 --> Helper loaded: url_helper
INFO - 2018-03-06 10:27:20 --> Helper loaded: file_helper
INFO - 2018-03-06 10:27:20 --> Helper loaded: email_helper
INFO - 2018-03-06 10:27:20 --> Helper loaded: common_helper
INFO - 2018-03-06 10:27:20 --> Database Driver Class Initialized
DEBUG - 2018-03-06 10:27:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-06 10:27:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-06 10:27:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-03-06 10:27:20 --> Pagination Class Initialized
INFO - 2018-03-06 10:27:20 --> Helper loaded: form_helper
INFO - 2018-03-06 10:27:20 --> Form Validation Class Initialized
INFO - 2018-03-06 10:27:20 --> Model Class Initialized
INFO - 2018-03-06 10:27:20 --> Controller Class Initialized
INFO - 2018-03-06 10:27:20 --> Language file loaded: language/english/english_lang.php
INFO - 2018-03-06 10:27:20 --> Model Class Initialized
INFO - 2018-03-06 10:29:11 --> Config Class Initialized
INFO - 2018-03-06 10:29:11 --> Hooks Class Initialized
DEBUG - 2018-03-06 10:29:11 --> UTF-8 Support Enabled
INFO - 2018-03-06 10:29:11 --> Utf8 Class Initialized
INFO - 2018-03-06 10:29:11 --> URI Class Initialized
INFO - 2018-03-06 10:29:11 --> Router Class Initialized
INFO - 2018-03-06 10:29:11 --> Output Class Initialized
INFO - 2018-03-06 10:29:11 --> Security Class Initialized
DEBUG - 2018-03-06 10:29:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-06 10:29:11 --> Input Class Initialized
INFO - 2018-03-06 10:29:11 --> Language Class Initialized
INFO - 2018-03-06 10:29:11 --> Loader Class Initialized
INFO - 2018-03-06 10:29:11 --> Helper loaded: url_helper
INFO - 2018-03-06 10:29:11 --> Helper loaded: file_helper
INFO - 2018-03-06 10:29:11 --> Helper loaded: email_helper
INFO - 2018-03-06 10:29:11 --> Helper loaded: common_helper
INFO - 2018-03-06 10:29:11 --> Database Driver Class Initialized
DEBUG - 2018-03-06 10:29:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-06 10:29:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-06 10:29:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-03-06 10:29:11 --> Pagination Class Initialized
INFO - 2018-03-06 10:29:11 --> Helper loaded: form_helper
INFO - 2018-03-06 10:29:11 --> Form Validation Class Initialized
INFO - 2018-03-06 10:29:11 --> Model Class Initialized
INFO - 2018-03-06 10:29:11 --> Controller Class Initialized
INFO - 2018-03-06 10:29:11 --> Language file loaded: language/english/english_lang.php
INFO - 2018-03-06 10:29:11 --> Model Class Initialized
INFO - 2018-03-06 10:29:11 --> File loaded: /var/www/html/project/periodtracker/application/views//template/side_bar.php
INFO - 2018-03-06 10:29:11 --> File loaded: /var/www/html/project/periodtracker/application/views//template/header.php
INFO - 2018-03-06 10:29:11 --> File loaded: /var/www/html/project/periodtracker/application/views//template/bread_crumb.php
INFO - 2018-03-06 10:29:11 --> File loaded: /var/www/html/project/periodtracker/application/views//template/footer.php
INFO - 2018-03-06 10:29:11 --> File loaded: /var/www/html/project/periodtracker/application/views/user/index.php
INFO - 2018-03-06 10:29:11 --> Final output sent to browser
DEBUG - 2018-03-06 10:29:11 --> Total execution time: 0.0048
INFO - 2018-03-06 10:29:11 --> Config Class Initialized
INFO - 2018-03-06 10:29:11 --> Hooks Class Initialized
DEBUG - 2018-03-06 10:29:11 --> UTF-8 Support Enabled
INFO - 2018-03-06 10:29:11 --> Utf8 Class Initialized
INFO - 2018-03-06 10:29:11 --> URI Class Initialized
INFO - 2018-03-06 10:29:11 --> Router Class Initialized
INFO - 2018-03-06 10:29:11 --> Output Class Initialized
INFO - 2018-03-06 10:29:11 --> Security Class Initialized
DEBUG - 2018-03-06 10:29:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-06 10:29:11 --> Input Class Initialized
INFO - 2018-03-06 10:29:11 --> Language Class Initialized
INFO - 2018-03-06 10:29:11 --> Loader Class Initialized
INFO - 2018-03-06 10:29:11 --> Helper loaded: url_helper
INFO - 2018-03-06 10:29:11 --> Helper loaded: file_helper
INFO - 2018-03-06 10:29:11 --> Helper loaded: email_helper
INFO - 2018-03-06 10:29:11 --> Helper loaded: common_helper
INFO - 2018-03-06 10:29:11 --> Database Driver Class Initialized
DEBUG - 2018-03-06 10:29:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-06 10:29:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-06 10:29:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-03-06 10:29:11 --> Pagination Class Initialized
INFO - 2018-03-06 10:29:11 --> Helper loaded: form_helper
INFO - 2018-03-06 10:29:11 --> Form Validation Class Initialized
INFO - 2018-03-06 10:29:11 --> Model Class Initialized
INFO - 2018-03-06 10:29:11 --> Controller Class Initialized
INFO - 2018-03-06 10:29:11 --> Language file loaded: language/english/english_lang.php
INFO - 2018-03-06 10:29:11 --> Model Class Initialized
INFO - 2018-03-06 10:41:54 --> Config Class Initialized
INFO - 2018-03-06 10:41:54 --> Hooks Class Initialized
DEBUG - 2018-03-06 10:41:54 --> UTF-8 Support Enabled
INFO - 2018-03-06 10:41:54 --> Utf8 Class Initialized
INFO - 2018-03-06 10:41:54 --> URI Class Initialized
INFO - 2018-03-06 10:41:54 --> Router Class Initialized
INFO - 2018-03-06 10:41:54 --> Output Class Initialized
INFO - 2018-03-06 10:41:54 --> Security Class Initialized
DEBUG - 2018-03-06 10:41:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-06 10:41:54 --> Input Class Initialized
INFO - 2018-03-06 10:41:54 --> Language Class Initialized
INFO - 2018-03-06 10:41:54 --> Loader Class Initialized
INFO - 2018-03-06 10:41:54 --> Helper loaded: url_helper
INFO - 2018-03-06 10:41:54 --> Helper loaded: file_helper
INFO - 2018-03-06 10:41:54 --> Helper loaded: email_helper
INFO - 2018-03-06 10:41:54 --> Helper loaded: common_helper
INFO - 2018-03-06 10:41:54 --> Database Driver Class Initialized
DEBUG - 2018-03-06 10:41:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-06 10:41:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-06 10:41:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-03-06 10:41:54 --> Pagination Class Initialized
INFO - 2018-03-06 10:41:54 --> Helper loaded: form_helper
INFO - 2018-03-06 10:41:54 --> Form Validation Class Initialized
INFO - 2018-03-06 10:41:54 --> Model Class Initialized
INFO - 2018-03-06 10:41:54 --> Controller Class Initialized
INFO - 2018-03-06 10:41:54 --> Language file loaded: language/english/english_lang.php
INFO - 2018-03-06 10:41:54 --> Model Class Initialized
INFO - 2018-03-06 10:41:54 --> File loaded: /var/www/html/project/periodtracker/application/views//template/side_bar.php
INFO - 2018-03-06 10:41:54 --> File loaded: /var/www/html/project/periodtracker/application/views//template/header.php
INFO - 2018-03-06 10:41:54 --> File loaded: /var/www/html/project/periodtracker/application/views//template/bread_crumb.php
INFO - 2018-03-06 10:41:54 --> File loaded: /var/www/html/project/periodtracker/application/views//template/footer.php
INFO - 2018-03-06 10:41:54 --> File loaded: /var/www/html/project/periodtracker/application/views/user/index.php
INFO - 2018-03-06 10:41:54 --> Final output sent to browser
DEBUG - 2018-03-06 10:41:54 --> Total execution time: 0.0085
INFO - 2018-03-06 10:41:54 --> Config Class Initialized
INFO - 2018-03-06 10:41:54 --> Hooks Class Initialized
DEBUG - 2018-03-06 10:41:54 --> UTF-8 Support Enabled
INFO - 2018-03-06 10:41:54 --> Utf8 Class Initialized
INFO - 2018-03-06 10:41:54 --> URI Class Initialized
INFO - 2018-03-06 10:41:54 --> Router Class Initialized
INFO - 2018-03-06 10:41:54 --> Output Class Initialized
INFO - 2018-03-06 10:41:54 --> Security Class Initialized
DEBUG - 2018-03-06 10:41:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-06 10:41:54 --> Input Class Initialized
INFO - 2018-03-06 10:41:54 --> Language Class Initialized
INFO - 2018-03-06 10:41:54 --> Loader Class Initialized
INFO - 2018-03-06 10:41:54 --> Helper loaded: url_helper
INFO - 2018-03-06 10:41:54 --> Helper loaded: file_helper
INFO - 2018-03-06 10:41:54 --> Helper loaded: email_helper
INFO - 2018-03-06 10:41:54 --> Helper loaded: common_helper
INFO - 2018-03-06 10:41:54 --> Database Driver Class Initialized
DEBUG - 2018-03-06 10:41:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-06 10:41:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-06 10:41:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-03-06 10:41:54 --> Pagination Class Initialized
INFO - 2018-03-06 10:41:54 --> Helper loaded: form_helper
INFO - 2018-03-06 10:41:54 --> Form Validation Class Initialized
INFO - 2018-03-06 10:41:54 --> Model Class Initialized
INFO - 2018-03-06 10:41:54 --> Controller Class Initialized
INFO - 2018-03-06 10:41:54 --> Language file loaded: language/english/english_lang.php
INFO - 2018-03-06 10:41:54 --> Model Class Initialized
INFO - 2018-03-06 10:42:09 --> Config Class Initialized
INFO - 2018-03-06 10:42:09 --> Hooks Class Initialized
DEBUG - 2018-03-06 10:42:09 --> UTF-8 Support Enabled
INFO - 2018-03-06 10:42:09 --> Utf8 Class Initialized
INFO - 2018-03-06 10:42:09 --> URI Class Initialized
INFO - 2018-03-06 10:42:09 --> Router Class Initialized
INFO - 2018-03-06 10:42:09 --> Output Class Initialized
INFO - 2018-03-06 10:42:09 --> Security Class Initialized
DEBUG - 2018-03-06 10:42:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-06 10:42:09 --> Input Class Initialized
INFO - 2018-03-06 10:42:09 --> Language Class Initialized
INFO - 2018-03-06 10:42:09 --> Loader Class Initialized
INFO - 2018-03-06 10:42:09 --> Helper loaded: url_helper
INFO - 2018-03-06 10:42:09 --> Helper loaded: file_helper
INFO - 2018-03-06 10:42:09 --> Helper loaded: email_helper
INFO - 2018-03-06 10:42:09 --> Helper loaded: common_helper
INFO - 2018-03-06 10:42:09 --> Database Driver Class Initialized
DEBUG - 2018-03-06 10:42:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-06 10:42:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-06 10:42:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-03-06 10:42:09 --> Pagination Class Initialized
INFO - 2018-03-06 10:42:09 --> Helper loaded: form_helper
INFO - 2018-03-06 10:42:09 --> Form Validation Class Initialized
INFO - 2018-03-06 10:42:09 --> Model Class Initialized
INFO - 2018-03-06 10:42:09 --> Controller Class Initialized
INFO - 2018-03-06 10:42:09 --> Language file loaded: language/english/english_lang.php
INFO - 2018-03-06 10:42:09 --> Model Class Initialized
INFO - 2018-03-06 10:42:09 --> Config Class Initialized
INFO - 2018-03-06 10:42:09 --> Hooks Class Initialized
DEBUG - 2018-03-06 10:42:09 --> UTF-8 Support Enabled
INFO - 2018-03-06 10:42:09 --> Utf8 Class Initialized
INFO - 2018-03-06 10:42:09 --> URI Class Initialized
INFO - 2018-03-06 10:42:09 --> Router Class Initialized
INFO - 2018-03-06 10:42:09 --> Output Class Initialized
INFO - 2018-03-06 10:42:09 --> Security Class Initialized
DEBUG - 2018-03-06 10:42:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-06 10:42:09 --> Input Class Initialized
INFO - 2018-03-06 10:42:09 --> Language Class Initialized
INFO - 2018-03-06 10:42:09 --> Loader Class Initialized
INFO - 2018-03-06 10:42:09 --> Helper loaded: url_helper
INFO - 2018-03-06 10:42:09 --> Helper loaded: file_helper
INFO - 2018-03-06 10:42:09 --> Helper loaded: email_helper
INFO - 2018-03-06 10:42:09 --> Helper loaded: common_helper
INFO - 2018-03-06 10:42:09 --> Database Driver Class Initialized
DEBUG - 2018-03-06 10:42:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-06 10:42:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-06 10:42:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-03-06 10:42:09 --> Pagination Class Initialized
INFO - 2018-03-06 10:42:09 --> Helper loaded: form_helper
INFO - 2018-03-06 10:42:09 --> Form Validation Class Initialized
INFO - 2018-03-06 10:42:09 --> Model Class Initialized
INFO - 2018-03-06 10:42:09 --> Controller Class Initialized
INFO - 2018-03-06 10:42:09 --> Language file loaded: language/english/english_lang.php
INFO - 2018-03-06 10:42:09 --> Model Class Initialized
INFO - 2018-03-06 10:42:17 --> Config Class Initialized
INFO - 2018-03-06 10:42:17 --> Hooks Class Initialized
DEBUG - 2018-03-06 10:42:17 --> UTF-8 Support Enabled
INFO - 2018-03-06 10:42:17 --> Utf8 Class Initialized
INFO - 2018-03-06 10:42:17 --> URI Class Initialized
INFO - 2018-03-06 10:42:17 --> Router Class Initialized
INFO - 2018-03-06 10:42:17 --> Output Class Initialized
INFO - 2018-03-06 10:42:17 --> Security Class Initialized
DEBUG - 2018-03-06 10:42:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-06 10:42:17 --> Input Class Initialized
INFO - 2018-03-06 10:42:17 --> Language Class Initialized
INFO - 2018-03-06 10:42:17 --> Loader Class Initialized
INFO - 2018-03-06 10:42:17 --> Helper loaded: url_helper
INFO - 2018-03-06 10:42:17 --> Helper loaded: file_helper
INFO - 2018-03-06 10:42:17 --> Helper loaded: email_helper
INFO - 2018-03-06 10:42:17 --> Helper loaded: common_helper
INFO - 2018-03-06 10:42:17 --> Database Driver Class Initialized
DEBUG - 2018-03-06 10:42:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-06 10:42:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-06 10:42:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-03-06 10:42:17 --> Pagination Class Initialized
INFO - 2018-03-06 10:42:17 --> Helper loaded: form_helper
INFO - 2018-03-06 10:42:17 --> Form Validation Class Initialized
INFO - 2018-03-06 10:42:17 --> Model Class Initialized
INFO - 2018-03-06 10:42:17 --> Controller Class Initialized
INFO - 2018-03-06 10:42:17 --> Language file loaded: language/english/english_lang.php
INFO - 2018-03-06 10:42:17 --> Model Class Initialized
INFO - 2018-03-06 10:42:17 --> File loaded: /var/www/html/project/periodtracker/application/views//template/side_bar.php
INFO - 2018-03-06 10:42:17 --> File loaded: /var/www/html/project/periodtracker/application/views//template/header.php
INFO - 2018-03-06 10:42:17 --> File loaded: /var/www/html/project/periodtracker/application/views//template/bread_crumb.php
INFO - 2018-03-06 10:42:17 --> File loaded: /var/www/html/project/periodtracker/application/views//template/footer.php
INFO - 2018-03-06 10:42:17 --> File loaded: /var/www/html/project/periodtracker/application/views/user/index.php
INFO - 2018-03-06 10:42:17 --> Final output sent to browser
DEBUG - 2018-03-06 10:42:17 --> Total execution time: 0.0050
INFO - 2018-03-06 10:42:17 --> Config Class Initialized
INFO - 2018-03-06 10:42:17 --> Hooks Class Initialized
DEBUG - 2018-03-06 10:42:17 --> UTF-8 Support Enabled
INFO - 2018-03-06 10:42:17 --> Utf8 Class Initialized
INFO - 2018-03-06 10:42:17 --> URI Class Initialized
INFO - 2018-03-06 10:42:17 --> Router Class Initialized
INFO - 2018-03-06 10:42:17 --> Output Class Initialized
INFO - 2018-03-06 10:42:17 --> Security Class Initialized
DEBUG - 2018-03-06 10:42:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-06 10:42:17 --> Input Class Initialized
INFO - 2018-03-06 10:42:17 --> Language Class Initialized
INFO - 2018-03-06 10:42:17 --> Loader Class Initialized
INFO - 2018-03-06 10:42:17 --> Helper loaded: url_helper
INFO - 2018-03-06 10:42:17 --> Helper loaded: file_helper
INFO - 2018-03-06 10:42:17 --> Helper loaded: email_helper
INFO - 2018-03-06 10:42:17 --> Helper loaded: common_helper
INFO - 2018-03-06 10:42:17 --> Database Driver Class Initialized
DEBUG - 2018-03-06 10:42:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-06 10:42:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-06 10:42:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-03-06 10:42:17 --> Pagination Class Initialized
INFO - 2018-03-06 10:42:17 --> Helper loaded: form_helper
INFO - 2018-03-06 10:42:17 --> Form Validation Class Initialized
INFO - 2018-03-06 10:42:17 --> Model Class Initialized
INFO - 2018-03-06 10:42:17 --> Controller Class Initialized
INFO - 2018-03-06 10:42:17 --> Language file loaded: language/english/english_lang.php
INFO - 2018-03-06 10:42:17 --> Model Class Initialized
INFO - 2018-03-06 10:42:19 --> Config Class Initialized
INFO - 2018-03-06 10:42:19 --> Hooks Class Initialized
DEBUG - 2018-03-06 10:42:19 --> UTF-8 Support Enabled
INFO - 2018-03-06 10:42:19 --> Utf8 Class Initialized
INFO - 2018-03-06 10:42:19 --> URI Class Initialized
INFO - 2018-03-06 10:42:19 --> Router Class Initialized
INFO - 2018-03-06 10:42:19 --> Output Class Initialized
INFO - 2018-03-06 10:42:19 --> Security Class Initialized
DEBUG - 2018-03-06 10:42:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-06 10:42:19 --> Input Class Initialized
INFO - 2018-03-06 10:42:19 --> Language Class Initialized
INFO - 2018-03-06 10:42:19 --> Loader Class Initialized
INFO - 2018-03-06 10:42:19 --> Helper loaded: url_helper
INFO - 2018-03-06 10:42:19 --> Helper loaded: file_helper
INFO - 2018-03-06 10:42:19 --> Helper loaded: email_helper
INFO - 2018-03-06 10:42:19 --> Helper loaded: common_helper
INFO - 2018-03-06 10:42:19 --> Database Driver Class Initialized
DEBUG - 2018-03-06 10:42:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-06 10:42:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-06 10:42:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-03-06 10:42:19 --> Pagination Class Initialized
INFO - 2018-03-06 10:42:19 --> Helper loaded: form_helper
INFO - 2018-03-06 10:42:19 --> Form Validation Class Initialized
INFO - 2018-03-06 10:42:19 --> Model Class Initialized
INFO - 2018-03-06 10:42:19 --> Controller Class Initialized
INFO - 2018-03-06 10:42:19 --> Language file loaded: language/english/english_lang.php
INFO - 2018-03-06 10:42:19 --> Model Class Initialized
INFO - 2018-03-06 10:42:19 --> Config Class Initialized
INFO - 2018-03-06 10:42:19 --> Hooks Class Initialized
DEBUG - 2018-03-06 10:42:19 --> UTF-8 Support Enabled
INFO - 2018-03-06 10:42:19 --> Utf8 Class Initialized
INFO - 2018-03-06 10:42:19 --> URI Class Initialized
INFO - 2018-03-06 10:42:19 --> Router Class Initialized
INFO - 2018-03-06 10:42:19 --> Output Class Initialized
INFO - 2018-03-06 10:42:19 --> Security Class Initialized
DEBUG - 2018-03-06 10:42:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-06 10:42:19 --> Input Class Initialized
INFO - 2018-03-06 10:42:19 --> Language Class Initialized
INFO - 2018-03-06 10:42:19 --> Loader Class Initialized
INFO - 2018-03-06 10:42:19 --> Helper loaded: url_helper
INFO - 2018-03-06 10:42:19 --> Helper loaded: file_helper
INFO - 2018-03-06 10:42:19 --> Helper loaded: email_helper
INFO - 2018-03-06 10:42:19 --> Helper loaded: common_helper
INFO - 2018-03-06 10:42:19 --> Database Driver Class Initialized
DEBUG - 2018-03-06 10:42:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-06 10:42:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-06 10:42:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-03-06 10:42:19 --> Pagination Class Initialized
INFO - 2018-03-06 10:42:19 --> Helper loaded: form_helper
INFO - 2018-03-06 10:42:19 --> Form Validation Class Initialized
INFO - 2018-03-06 10:42:19 --> Model Class Initialized
INFO - 2018-03-06 10:42:19 --> Controller Class Initialized
INFO - 2018-03-06 10:42:19 --> Language file loaded: language/english/english_lang.php
INFO - 2018-03-06 10:42:19 --> Model Class Initialized
INFO - 2018-03-06 10:42:20 --> Config Class Initialized
INFO - 2018-03-06 10:42:20 --> Hooks Class Initialized
DEBUG - 2018-03-06 10:42:20 --> UTF-8 Support Enabled
INFO - 2018-03-06 10:42:20 --> Utf8 Class Initialized
INFO - 2018-03-06 10:42:20 --> URI Class Initialized
INFO - 2018-03-06 10:42:20 --> Router Class Initialized
INFO - 2018-03-06 10:42:20 --> Output Class Initialized
INFO - 2018-03-06 10:42:20 --> Security Class Initialized
DEBUG - 2018-03-06 10:42:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-06 10:42:20 --> Input Class Initialized
INFO - 2018-03-06 10:42:20 --> Language Class Initialized
INFO - 2018-03-06 10:42:20 --> Loader Class Initialized
INFO - 2018-03-06 10:42:20 --> Helper loaded: url_helper
INFO - 2018-03-06 10:42:20 --> Helper loaded: file_helper
INFO - 2018-03-06 10:42:20 --> Helper loaded: email_helper
INFO - 2018-03-06 10:42:20 --> Helper loaded: common_helper
INFO - 2018-03-06 10:42:20 --> Database Driver Class Initialized
DEBUG - 2018-03-06 10:42:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-06 10:42:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-06 10:42:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-03-06 10:42:20 --> Pagination Class Initialized
INFO - 2018-03-06 10:42:20 --> Helper loaded: form_helper
INFO - 2018-03-06 10:42:20 --> Form Validation Class Initialized
INFO - 2018-03-06 10:42:20 --> Model Class Initialized
INFO - 2018-03-06 10:42:20 --> Controller Class Initialized
INFO - 2018-03-06 10:42:20 --> Language file loaded: language/english/english_lang.php
INFO - 2018-03-06 10:42:20 --> Model Class Initialized
INFO - 2018-03-06 10:42:20 --> File loaded: /var/www/html/project/periodtracker/application/views//template/side_bar.php
INFO - 2018-03-06 10:42:20 --> File loaded: /var/www/html/project/periodtracker/application/views//template/header.php
INFO - 2018-03-06 10:42:20 --> File loaded: /var/www/html/project/periodtracker/application/views//template/bread_crumb.php
INFO - 2018-03-06 10:42:20 --> File loaded: /var/www/html/project/periodtracker/application/views//template/footer.php
INFO - 2018-03-06 10:42:20 --> File loaded: /var/www/html/project/periodtracker/application/views/user/index.php
INFO - 2018-03-06 10:42:20 --> Final output sent to browser
DEBUG - 2018-03-06 10:42:20 --> Total execution time: 0.0047
INFO - 2018-03-06 10:42:21 --> Config Class Initialized
INFO - 2018-03-06 10:42:21 --> Hooks Class Initialized
DEBUG - 2018-03-06 10:42:21 --> UTF-8 Support Enabled
INFO - 2018-03-06 10:42:21 --> Utf8 Class Initialized
INFO - 2018-03-06 10:42:21 --> URI Class Initialized
INFO - 2018-03-06 10:42:21 --> Router Class Initialized
INFO - 2018-03-06 10:42:21 --> Output Class Initialized
INFO - 2018-03-06 10:42:21 --> Security Class Initialized
DEBUG - 2018-03-06 10:42:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-06 10:42:21 --> Input Class Initialized
INFO - 2018-03-06 10:42:21 --> Language Class Initialized
INFO - 2018-03-06 10:42:21 --> Loader Class Initialized
INFO - 2018-03-06 10:42:21 --> Helper loaded: url_helper
INFO - 2018-03-06 10:42:21 --> Helper loaded: file_helper
INFO - 2018-03-06 10:42:21 --> Helper loaded: email_helper
INFO - 2018-03-06 10:42:21 --> Helper loaded: common_helper
INFO - 2018-03-06 10:42:21 --> Database Driver Class Initialized
DEBUG - 2018-03-06 10:42:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-06 10:42:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-06 10:42:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-03-06 10:42:21 --> Pagination Class Initialized
INFO - 2018-03-06 10:42:21 --> Helper loaded: form_helper
INFO - 2018-03-06 10:42:21 --> Form Validation Class Initialized
INFO - 2018-03-06 10:42:21 --> Model Class Initialized
INFO - 2018-03-06 10:42:21 --> Controller Class Initialized
INFO - 2018-03-06 10:42:21 --> Language file loaded: language/english/english_lang.php
INFO - 2018-03-06 10:42:21 --> Model Class Initialized
INFO - 2018-03-06 10:42:31 --> Config Class Initialized
INFO - 2018-03-06 10:42:31 --> Hooks Class Initialized
DEBUG - 2018-03-06 10:42:31 --> UTF-8 Support Enabled
INFO - 2018-03-06 10:42:31 --> Utf8 Class Initialized
INFO - 2018-03-06 10:42:31 --> URI Class Initialized
INFO - 2018-03-06 10:42:31 --> Router Class Initialized
INFO - 2018-03-06 10:42:31 --> Output Class Initialized
INFO - 2018-03-06 10:42:31 --> Security Class Initialized
DEBUG - 2018-03-06 10:42:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-06 10:42:31 --> Input Class Initialized
INFO - 2018-03-06 10:42:31 --> Language Class Initialized
INFO - 2018-03-06 10:42:31 --> Loader Class Initialized
INFO - 2018-03-06 10:42:31 --> Helper loaded: url_helper
INFO - 2018-03-06 10:42:31 --> Helper loaded: file_helper
INFO - 2018-03-06 10:42:31 --> Helper loaded: email_helper
INFO - 2018-03-06 10:42:31 --> Helper loaded: common_helper
INFO - 2018-03-06 10:42:31 --> Database Driver Class Initialized
DEBUG - 2018-03-06 10:42:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-06 10:42:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-06 10:42:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-03-06 10:42:31 --> Pagination Class Initialized
INFO - 2018-03-06 10:42:31 --> Helper loaded: form_helper
INFO - 2018-03-06 10:42:31 --> Form Validation Class Initialized
INFO - 2018-03-06 10:42:31 --> Model Class Initialized
INFO - 2018-03-06 10:42:31 --> Controller Class Initialized
INFO - 2018-03-06 10:42:31 --> Language file loaded: language/english/english_lang.php
INFO - 2018-03-06 10:42:31 --> Model Class Initialized
INFO - 2018-03-06 10:42:32 --> Config Class Initialized
INFO - 2018-03-06 10:42:32 --> Hooks Class Initialized
DEBUG - 2018-03-06 10:42:32 --> UTF-8 Support Enabled
INFO - 2018-03-06 10:42:32 --> Utf8 Class Initialized
INFO - 2018-03-06 10:42:32 --> URI Class Initialized
INFO - 2018-03-06 10:42:32 --> Router Class Initialized
INFO - 2018-03-06 10:42:32 --> Output Class Initialized
INFO - 2018-03-06 10:42:32 --> Security Class Initialized
DEBUG - 2018-03-06 10:42:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-06 10:42:32 --> Input Class Initialized
INFO - 2018-03-06 10:42:32 --> Language Class Initialized
INFO - 2018-03-06 10:42:32 --> Loader Class Initialized
INFO - 2018-03-06 10:42:32 --> Helper loaded: url_helper
INFO - 2018-03-06 10:42:32 --> Helper loaded: file_helper
INFO - 2018-03-06 10:42:32 --> Helper loaded: email_helper
INFO - 2018-03-06 10:42:32 --> Helper loaded: common_helper
INFO - 2018-03-06 10:42:32 --> Database Driver Class Initialized
DEBUG - 2018-03-06 10:42:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-06 10:42:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-06 10:42:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-03-06 10:42:32 --> Pagination Class Initialized
INFO - 2018-03-06 10:42:32 --> Helper loaded: form_helper
INFO - 2018-03-06 10:42:32 --> Form Validation Class Initialized
INFO - 2018-03-06 10:42:32 --> Model Class Initialized
INFO - 2018-03-06 10:42:32 --> Controller Class Initialized
INFO - 2018-03-06 10:42:32 --> Language file loaded: language/english/english_lang.php
INFO - 2018-03-06 10:42:32 --> Model Class Initialized
INFO - 2018-03-06 10:42:46 --> Config Class Initialized
INFO - 2018-03-06 10:42:46 --> Hooks Class Initialized
DEBUG - 2018-03-06 10:42:46 --> UTF-8 Support Enabled
INFO - 2018-03-06 10:42:46 --> Utf8 Class Initialized
INFO - 2018-03-06 10:42:46 --> URI Class Initialized
INFO - 2018-03-06 10:42:46 --> Router Class Initialized
INFO - 2018-03-06 10:42:46 --> Output Class Initialized
INFO - 2018-03-06 10:42:46 --> Security Class Initialized
DEBUG - 2018-03-06 10:42:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-06 10:42:46 --> Input Class Initialized
INFO - 2018-03-06 10:42:46 --> Language Class Initialized
INFO - 2018-03-06 10:42:46 --> Loader Class Initialized
INFO - 2018-03-06 10:42:46 --> Helper loaded: url_helper
INFO - 2018-03-06 10:42:46 --> Helper loaded: file_helper
INFO - 2018-03-06 10:42:46 --> Helper loaded: email_helper
INFO - 2018-03-06 10:42:46 --> Helper loaded: common_helper
INFO - 2018-03-06 10:42:46 --> Database Driver Class Initialized
DEBUG - 2018-03-06 10:42:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-06 10:42:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-06 10:42:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-03-06 10:42:46 --> Pagination Class Initialized
INFO - 2018-03-06 10:42:46 --> Helper loaded: form_helper
INFO - 2018-03-06 10:42:46 --> Form Validation Class Initialized
INFO - 2018-03-06 10:42:46 --> Model Class Initialized
INFO - 2018-03-06 10:42:46 --> Controller Class Initialized
INFO - 2018-03-06 10:42:46 --> Language file loaded: language/english/english_lang.php
INFO - 2018-03-06 10:42:46 --> Model Class Initialized
INFO - 2018-03-06 10:42:46 --> File loaded: /var/www/html/project/periodtracker/application/views//template/side_bar.php
INFO - 2018-03-06 10:42:46 --> File loaded: /var/www/html/project/periodtracker/application/views//template/header.php
INFO - 2018-03-06 10:42:46 --> File loaded: /var/www/html/project/periodtracker/application/views//template/bread_crumb.php
INFO - 2018-03-06 10:42:46 --> File loaded: /var/www/html/project/periodtracker/application/views//template/footer.php
INFO - 2018-03-06 10:42:46 --> File loaded: /var/www/html/project/periodtracker/application/views/user/index.php
INFO - 2018-03-06 10:42:46 --> Final output sent to browser
DEBUG - 2018-03-06 10:42:46 --> Total execution time: 0.0056
INFO - 2018-03-06 10:42:46 --> Config Class Initialized
INFO - 2018-03-06 10:42:46 --> Hooks Class Initialized
DEBUG - 2018-03-06 10:42:46 --> UTF-8 Support Enabled
INFO - 2018-03-06 10:42:46 --> Utf8 Class Initialized
INFO - 2018-03-06 10:42:46 --> URI Class Initialized
INFO - 2018-03-06 10:42:46 --> Router Class Initialized
INFO - 2018-03-06 10:42:46 --> Output Class Initialized
INFO - 2018-03-06 10:42:46 --> Security Class Initialized
DEBUG - 2018-03-06 10:42:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-06 10:42:46 --> Input Class Initialized
INFO - 2018-03-06 10:42:46 --> Language Class Initialized
INFO - 2018-03-06 10:42:46 --> Loader Class Initialized
INFO - 2018-03-06 10:42:46 --> Helper loaded: url_helper
INFO - 2018-03-06 10:42:46 --> Helper loaded: file_helper
INFO - 2018-03-06 10:42:46 --> Helper loaded: email_helper
INFO - 2018-03-06 10:42:46 --> Helper loaded: common_helper
INFO - 2018-03-06 10:42:46 --> Database Driver Class Initialized
DEBUG - 2018-03-06 10:42:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-06 10:42:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-06 10:42:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-03-06 10:42:46 --> Pagination Class Initialized
INFO - 2018-03-06 10:42:46 --> Helper loaded: form_helper
INFO - 2018-03-06 10:42:46 --> Form Validation Class Initialized
INFO - 2018-03-06 10:42:46 --> Model Class Initialized
INFO - 2018-03-06 10:42:46 --> Controller Class Initialized
INFO - 2018-03-06 10:42:46 --> Language file loaded: language/english/english_lang.php
INFO - 2018-03-06 10:42:46 --> Model Class Initialized
INFO - 2018-03-06 10:42:52 --> Config Class Initialized
INFO - 2018-03-06 10:42:52 --> Hooks Class Initialized
DEBUG - 2018-03-06 10:42:52 --> UTF-8 Support Enabled
INFO - 2018-03-06 10:42:52 --> Utf8 Class Initialized
INFO - 2018-03-06 10:42:52 --> URI Class Initialized
INFO - 2018-03-06 10:42:52 --> Router Class Initialized
INFO - 2018-03-06 10:42:52 --> Output Class Initialized
INFO - 2018-03-06 10:42:52 --> Security Class Initialized
DEBUG - 2018-03-06 10:42:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-06 10:42:52 --> Input Class Initialized
INFO - 2018-03-06 10:42:52 --> Language Class Initialized
INFO - 2018-03-06 10:42:52 --> Loader Class Initialized
INFO - 2018-03-06 10:42:52 --> Helper loaded: url_helper
INFO - 2018-03-06 10:42:52 --> Helper loaded: file_helper
INFO - 2018-03-06 10:42:52 --> Helper loaded: email_helper
INFO - 2018-03-06 10:42:52 --> Helper loaded: common_helper
INFO - 2018-03-06 10:42:52 --> Database Driver Class Initialized
DEBUG - 2018-03-06 10:42:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-06 10:42:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-06 10:42:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-03-06 10:42:52 --> Pagination Class Initialized
INFO - 2018-03-06 10:42:52 --> Helper loaded: form_helper
INFO - 2018-03-06 10:42:52 --> Form Validation Class Initialized
INFO - 2018-03-06 10:42:52 --> Model Class Initialized
INFO - 2018-03-06 10:42:52 --> Controller Class Initialized
INFO - 2018-03-06 10:42:52 --> Language file loaded: language/english/english_lang.php
INFO - 2018-03-06 10:42:52 --> Model Class Initialized
INFO - 2018-03-06 10:42:52 --> Config Class Initialized
INFO - 2018-03-06 10:42:52 --> Hooks Class Initialized
DEBUG - 2018-03-06 10:42:52 --> UTF-8 Support Enabled
INFO - 2018-03-06 10:42:52 --> Utf8 Class Initialized
INFO - 2018-03-06 10:42:52 --> URI Class Initialized
INFO - 2018-03-06 10:42:52 --> Router Class Initialized
INFO - 2018-03-06 10:42:52 --> Output Class Initialized
INFO - 2018-03-06 10:42:52 --> Security Class Initialized
DEBUG - 2018-03-06 10:42:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-06 10:42:52 --> Input Class Initialized
INFO - 2018-03-06 10:42:52 --> Language Class Initialized
INFO - 2018-03-06 10:42:52 --> Loader Class Initialized
INFO - 2018-03-06 10:42:52 --> Helper loaded: url_helper
INFO - 2018-03-06 10:42:52 --> Helper loaded: file_helper
INFO - 2018-03-06 10:42:52 --> Helper loaded: email_helper
INFO - 2018-03-06 10:42:52 --> Helper loaded: common_helper
INFO - 2018-03-06 10:42:52 --> Database Driver Class Initialized
DEBUG - 2018-03-06 10:42:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-06 10:42:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-06 10:42:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-03-06 10:42:52 --> Pagination Class Initialized
INFO - 2018-03-06 10:42:52 --> Helper loaded: form_helper
INFO - 2018-03-06 10:42:52 --> Form Validation Class Initialized
INFO - 2018-03-06 10:42:52 --> Model Class Initialized
INFO - 2018-03-06 10:42:52 --> Controller Class Initialized
INFO - 2018-03-06 10:42:52 --> Language file loaded: language/english/english_lang.php
INFO - 2018-03-06 10:42:52 --> Model Class Initialized
INFO - 2018-03-06 10:42:54 --> Config Class Initialized
INFO - 2018-03-06 10:42:54 --> Hooks Class Initialized
DEBUG - 2018-03-06 10:42:54 --> UTF-8 Support Enabled
INFO - 2018-03-06 10:42:54 --> Utf8 Class Initialized
INFO - 2018-03-06 10:42:54 --> URI Class Initialized
INFO - 2018-03-06 10:42:54 --> Router Class Initialized
INFO - 2018-03-06 10:42:54 --> Output Class Initialized
INFO - 2018-03-06 10:42:54 --> Security Class Initialized
DEBUG - 2018-03-06 10:42:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-06 10:42:54 --> Input Class Initialized
INFO - 2018-03-06 10:42:54 --> Language Class Initialized
INFO - 2018-03-06 10:42:54 --> Loader Class Initialized
INFO - 2018-03-06 10:42:54 --> Helper loaded: url_helper
INFO - 2018-03-06 10:42:54 --> Helper loaded: file_helper
INFO - 2018-03-06 10:42:54 --> Helper loaded: email_helper
INFO - 2018-03-06 10:42:54 --> Helper loaded: common_helper
INFO - 2018-03-06 10:42:54 --> Database Driver Class Initialized
DEBUG - 2018-03-06 10:42:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-06 10:42:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-06 10:42:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-03-06 10:42:54 --> Pagination Class Initialized
INFO - 2018-03-06 10:42:54 --> Helper loaded: form_helper
INFO - 2018-03-06 10:42:54 --> Form Validation Class Initialized
INFO - 2018-03-06 10:42:54 --> Model Class Initialized
INFO - 2018-03-06 10:42:54 --> Controller Class Initialized
INFO - 2018-03-06 10:42:54 --> Language file loaded: language/english/english_lang.php
INFO - 2018-03-06 10:42:54 --> Model Class Initialized
INFO - 2018-03-06 10:42:54 --> Config Class Initialized
INFO - 2018-03-06 10:42:54 --> Hooks Class Initialized
DEBUG - 2018-03-06 10:42:54 --> UTF-8 Support Enabled
INFO - 2018-03-06 10:42:54 --> Utf8 Class Initialized
INFO - 2018-03-06 10:42:54 --> URI Class Initialized
INFO - 2018-03-06 10:42:54 --> Router Class Initialized
INFO - 2018-03-06 10:42:54 --> Output Class Initialized
INFO - 2018-03-06 10:42:54 --> Security Class Initialized
DEBUG - 2018-03-06 10:42:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-06 10:42:54 --> Input Class Initialized
INFO - 2018-03-06 10:42:54 --> Language Class Initialized
INFO - 2018-03-06 10:42:54 --> Loader Class Initialized
INFO - 2018-03-06 10:42:54 --> Helper loaded: url_helper
INFO - 2018-03-06 10:42:54 --> Helper loaded: file_helper
INFO - 2018-03-06 10:42:54 --> Helper loaded: email_helper
INFO - 2018-03-06 10:42:54 --> Helper loaded: common_helper
INFO - 2018-03-06 10:42:54 --> Database Driver Class Initialized
DEBUG - 2018-03-06 10:42:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-06 10:42:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-06 10:42:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-03-06 10:42:54 --> Pagination Class Initialized
INFO - 2018-03-06 10:42:54 --> Helper loaded: form_helper
INFO - 2018-03-06 10:42:54 --> Form Validation Class Initialized
INFO - 2018-03-06 10:42:54 --> Model Class Initialized
INFO - 2018-03-06 10:42:54 --> Controller Class Initialized
INFO - 2018-03-06 10:42:54 --> Language file loaded: language/english/english_lang.php
INFO - 2018-03-06 10:42:54 --> Model Class Initialized
INFO - 2018-03-06 10:42:55 --> Config Class Initialized
INFO - 2018-03-06 10:42:55 --> Hooks Class Initialized
DEBUG - 2018-03-06 10:42:55 --> UTF-8 Support Enabled
INFO - 2018-03-06 10:42:55 --> Utf8 Class Initialized
INFO - 2018-03-06 10:42:55 --> URI Class Initialized
INFO - 2018-03-06 10:42:55 --> Router Class Initialized
INFO - 2018-03-06 10:42:55 --> Output Class Initialized
INFO - 2018-03-06 10:42:55 --> Security Class Initialized
DEBUG - 2018-03-06 10:42:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-06 10:42:55 --> Input Class Initialized
INFO - 2018-03-06 10:42:55 --> Language Class Initialized
INFO - 2018-03-06 10:42:55 --> Loader Class Initialized
INFO - 2018-03-06 10:42:55 --> Helper loaded: url_helper
INFO - 2018-03-06 10:42:55 --> Helper loaded: file_helper
INFO - 2018-03-06 10:42:55 --> Helper loaded: email_helper
INFO - 2018-03-06 10:42:55 --> Helper loaded: common_helper
INFO - 2018-03-06 10:42:55 --> Database Driver Class Initialized
DEBUG - 2018-03-06 10:42:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-06 10:42:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-06 10:42:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-03-06 10:42:55 --> Pagination Class Initialized
INFO - 2018-03-06 10:42:55 --> Helper loaded: form_helper
INFO - 2018-03-06 10:42:55 --> Form Validation Class Initialized
INFO - 2018-03-06 10:42:55 --> Model Class Initialized
INFO - 2018-03-06 10:42:55 --> Controller Class Initialized
INFO - 2018-03-06 10:42:55 --> Language file loaded: language/english/english_lang.php
INFO - 2018-03-06 10:42:55 --> Model Class Initialized
INFO - 2018-03-06 10:42:55 --> Config Class Initialized
INFO - 2018-03-06 10:42:55 --> Hooks Class Initialized
DEBUG - 2018-03-06 10:42:55 --> UTF-8 Support Enabled
INFO - 2018-03-06 10:42:55 --> Utf8 Class Initialized
INFO - 2018-03-06 10:42:55 --> URI Class Initialized
INFO - 2018-03-06 10:42:55 --> Router Class Initialized
INFO - 2018-03-06 10:42:55 --> Output Class Initialized
INFO - 2018-03-06 10:42:55 --> Security Class Initialized
DEBUG - 2018-03-06 10:42:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-06 10:42:55 --> Input Class Initialized
INFO - 2018-03-06 10:42:55 --> Language Class Initialized
INFO - 2018-03-06 10:42:55 --> Loader Class Initialized
INFO - 2018-03-06 10:42:55 --> Helper loaded: url_helper
INFO - 2018-03-06 10:42:55 --> Helper loaded: file_helper
INFO - 2018-03-06 10:42:55 --> Helper loaded: email_helper
INFO - 2018-03-06 10:42:55 --> Helper loaded: common_helper
INFO - 2018-03-06 10:42:55 --> Database Driver Class Initialized
DEBUG - 2018-03-06 10:42:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-06 10:42:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-06 10:42:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-03-06 10:42:55 --> Pagination Class Initialized
INFO - 2018-03-06 10:42:55 --> Helper loaded: form_helper
INFO - 2018-03-06 10:42:55 --> Form Validation Class Initialized
INFO - 2018-03-06 10:42:55 --> Model Class Initialized
INFO - 2018-03-06 10:42:55 --> Controller Class Initialized
INFO - 2018-03-06 10:42:55 --> Language file loaded: language/english/english_lang.php
INFO - 2018-03-06 10:42:55 --> Model Class Initialized
INFO - 2018-03-06 10:42:57 --> Config Class Initialized
INFO - 2018-03-06 10:42:57 --> Hooks Class Initialized
DEBUG - 2018-03-06 10:42:57 --> UTF-8 Support Enabled
INFO - 2018-03-06 10:42:57 --> Utf8 Class Initialized
INFO - 2018-03-06 10:42:57 --> URI Class Initialized
INFO - 2018-03-06 10:42:57 --> Router Class Initialized
INFO - 2018-03-06 10:42:57 --> Output Class Initialized
INFO - 2018-03-06 10:42:57 --> Security Class Initialized
DEBUG - 2018-03-06 10:42:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-06 10:42:57 --> Input Class Initialized
INFO - 2018-03-06 10:42:57 --> Language Class Initialized
INFO - 2018-03-06 10:42:57 --> Loader Class Initialized
INFO - 2018-03-06 10:42:57 --> Helper loaded: url_helper
INFO - 2018-03-06 10:42:57 --> Helper loaded: file_helper
INFO - 2018-03-06 10:42:57 --> Helper loaded: email_helper
INFO - 2018-03-06 10:42:57 --> Helper loaded: common_helper
INFO - 2018-03-06 10:42:57 --> Database Driver Class Initialized
DEBUG - 2018-03-06 10:42:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-06 10:42:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-06 10:42:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-03-06 10:42:57 --> Pagination Class Initialized
INFO - 2018-03-06 10:42:57 --> Helper loaded: form_helper
INFO - 2018-03-06 10:42:57 --> Form Validation Class Initialized
INFO - 2018-03-06 10:42:57 --> Model Class Initialized
INFO - 2018-03-06 10:42:57 --> Controller Class Initialized
INFO - 2018-03-06 10:42:57 --> Language file loaded: language/english/english_lang.php
INFO - 2018-03-06 10:42:57 --> Model Class Initialized
INFO - 2018-03-06 10:42:57 --> Config Class Initialized
INFO - 2018-03-06 10:42:57 --> Hooks Class Initialized
DEBUG - 2018-03-06 10:42:57 --> UTF-8 Support Enabled
INFO - 2018-03-06 10:42:57 --> Utf8 Class Initialized
INFO - 2018-03-06 10:42:57 --> URI Class Initialized
INFO - 2018-03-06 10:42:57 --> Router Class Initialized
INFO - 2018-03-06 10:42:57 --> Output Class Initialized
INFO - 2018-03-06 10:42:57 --> Security Class Initialized
DEBUG - 2018-03-06 10:42:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-06 10:42:57 --> Input Class Initialized
INFO - 2018-03-06 10:42:57 --> Language Class Initialized
INFO - 2018-03-06 10:42:57 --> Loader Class Initialized
INFO - 2018-03-06 10:42:57 --> Helper loaded: url_helper
INFO - 2018-03-06 10:42:57 --> Helper loaded: file_helper
INFO - 2018-03-06 10:42:57 --> Helper loaded: email_helper
INFO - 2018-03-06 10:42:57 --> Helper loaded: common_helper
INFO - 2018-03-06 10:42:57 --> Database Driver Class Initialized
DEBUG - 2018-03-06 10:42:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-06 10:42:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-06 10:42:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-03-06 10:42:57 --> Pagination Class Initialized
INFO - 2018-03-06 10:42:57 --> Helper loaded: form_helper
INFO - 2018-03-06 10:42:57 --> Form Validation Class Initialized
INFO - 2018-03-06 10:42:57 --> Model Class Initialized
INFO - 2018-03-06 10:42:57 --> Controller Class Initialized
INFO - 2018-03-06 10:42:57 --> Language file loaded: language/english/english_lang.php
INFO - 2018-03-06 10:42:57 --> Model Class Initialized
INFO - 2018-03-06 10:42:58 --> Config Class Initialized
INFO - 2018-03-06 10:42:58 --> Hooks Class Initialized
DEBUG - 2018-03-06 10:42:58 --> UTF-8 Support Enabled
INFO - 2018-03-06 10:42:58 --> Utf8 Class Initialized
INFO - 2018-03-06 10:42:58 --> URI Class Initialized
INFO - 2018-03-06 10:42:58 --> Router Class Initialized
INFO - 2018-03-06 10:42:58 --> Output Class Initialized
INFO - 2018-03-06 10:42:58 --> Security Class Initialized
DEBUG - 2018-03-06 10:42:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-06 10:42:58 --> Input Class Initialized
INFO - 2018-03-06 10:42:58 --> Language Class Initialized
INFO - 2018-03-06 10:42:58 --> Loader Class Initialized
INFO - 2018-03-06 10:42:58 --> Helper loaded: url_helper
INFO - 2018-03-06 10:42:58 --> Helper loaded: file_helper
INFO - 2018-03-06 10:42:58 --> Helper loaded: email_helper
INFO - 2018-03-06 10:42:58 --> Helper loaded: common_helper
INFO - 2018-03-06 10:42:58 --> Database Driver Class Initialized
DEBUG - 2018-03-06 10:42:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-06 10:42:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-06 10:42:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-03-06 10:42:58 --> Pagination Class Initialized
INFO - 2018-03-06 10:42:58 --> Helper loaded: form_helper
INFO - 2018-03-06 10:42:58 --> Form Validation Class Initialized
INFO - 2018-03-06 10:42:58 --> Model Class Initialized
INFO - 2018-03-06 10:42:58 --> Controller Class Initialized
INFO - 2018-03-06 10:42:58 --> Language file loaded: language/english/english_lang.php
INFO - 2018-03-06 10:42:58 --> Model Class Initialized
INFO - 2018-03-06 10:42:58 --> Config Class Initialized
INFO - 2018-03-06 10:42:58 --> Hooks Class Initialized
DEBUG - 2018-03-06 10:42:58 --> UTF-8 Support Enabled
INFO - 2018-03-06 10:42:58 --> Utf8 Class Initialized
INFO - 2018-03-06 10:42:58 --> URI Class Initialized
INFO - 2018-03-06 10:42:58 --> Router Class Initialized
INFO - 2018-03-06 10:42:58 --> Output Class Initialized
INFO - 2018-03-06 10:42:58 --> Security Class Initialized
DEBUG - 2018-03-06 10:42:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-06 10:42:58 --> Input Class Initialized
INFO - 2018-03-06 10:42:58 --> Language Class Initialized
INFO - 2018-03-06 10:42:58 --> Loader Class Initialized
INFO - 2018-03-06 10:42:58 --> Helper loaded: url_helper
INFO - 2018-03-06 10:42:58 --> Helper loaded: file_helper
INFO - 2018-03-06 10:42:58 --> Helper loaded: email_helper
INFO - 2018-03-06 10:42:58 --> Helper loaded: common_helper
INFO - 2018-03-06 10:42:58 --> Database Driver Class Initialized
DEBUG - 2018-03-06 10:42:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-06 10:42:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-06 10:42:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-03-06 10:42:58 --> Pagination Class Initialized
INFO - 2018-03-06 10:42:58 --> Helper loaded: form_helper
INFO - 2018-03-06 10:42:58 --> Form Validation Class Initialized
INFO - 2018-03-06 10:42:58 --> Model Class Initialized
INFO - 2018-03-06 10:42:58 --> Controller Class Initialized
INFO - 2018-03-06 10:42:58 --> Language file loaded: language/english/english_lang.php
INFO - 2018-03-06 10:42:58 --> Model Class Initialized
INFO - 2018-03-06 10:42:59 --> Config Class Initialized
INFO - 2018-03-06 10:42:59 --> Hooks Class Initialized
DEBUG - 2018-03-06 10:42:59 --> UTF-8 Support Enabled
INFO - 2018-03-06 10:42:59 --> Utf8 Class Initialized
INFO - 2018-03-06 10:42:59 --> URI Class Initialized
INFO - 2018-03-06 10:42:59 --> Router Class Initialized
INFO - 2018-03-06 10:42:59 --> Output Class Initialized
INFO - 2018-03-06 10:42:59 --> Security Class Initialized
DEBUG - 2018-03-06 10:42:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-06 10:42:59 --> Input Class Initialized
INFO - 2018-03-06 10:42:59 --> Language Class Initialized
INFO - 2018-03-06 10:42:59 --> Loader Class Initialized
INFO - 2018-03-06 10:42:59 --> Helper loaded: url_helper
INFO - 2018-03-06 10:42:59 --> Helper loaded: file_helper
INFO - 2018-03-06 10:42:59 --> Helper loaded: email_helper
INFO - 2018-03-06 10:42:59 --> Helper loaded: common_helper
INFO - 2018-03-06 10:42:59 --> Database Driver Class Initialized
DEBUG - 2018-03-06 10:42:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-06 10:42:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-06 10:42:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-03-06 10:42:59 --> Pagination Class Initialized
INFO - 2018-03-06 10:42:59 --> Helper loaded: form_helper
INFO - 2018-03-06 10:42:59 --> Form Validation Class Initialized
INFO - 2018-03-06 10:42:59 --> Model Class Initialized
INFO - 2018-03-06 10:42:59 --> Controller Class Initialized
INFO - 2018-03-06 10:42:59 --> Language file loaded: language/english/english_lang.php
INFO - 2018-03-06 10:42:59 --> Model Class Initialized
INFO - 2018-03-06 11:04:20 --> Config Class Initialized
INFO - 2018-03-06 11:04:20 --> Hooks Class Initialized
DEBUG - 2018-03-06 11:04:20 --> UTF-8 Support Enabled
INFO - 2018-03-06 11:04:20 --> Utf8 Class Initialized
INFO - 2018-03-06 11:04:20 --> URI Class Initialized
INFO - 2018-03-06 11:04:20 --> Router Class Initialized
INFO - 2018-03-06 11:04:20 --> Output Class Initialized
INFO - 2018-03-06 11:04:20 --> Security Class Initialized
DEBUG - 2018-03-06 11:04:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-06 11:04:20 --> Input Class Initialized
INFO - 2018-03-06 11:04:20 --> Language Class Initialized
INFO - 2018-03-06 11:04:20 --> Loader Class Initialized
INFO - 2018-03-06 11:04:20 --> Helper loaded: url_helper
INFO - 2018-03-06 11:04:20 --> Helper loaded: file_helper
INFO - 2018-03-06 11:04:20 --> Helper loaded: email_helper
INFO - 2018-03-06 11:04:20 --> Helper loaded: common_helper
INFO - 2018-03-06 11:04:20 --> Database Driver Class Initialized
DEBUG - 2018-03-06 11:04:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-06 11:04:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-06 11:04:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-03-06 11:04:20 --> Pagination Class Initialized
INFO - 2018-03-06 11:04:20 --> Helper loaded: form_helper
INFO - 2018-03-06 11:04:20 --> Form Validation Class Initialized
INFO - 2018-03-06 11:04:20 --> Model Class Initialized
INFO - 2018-03-06 11:04:20 --> Controller Class Initialized
INFO - 2018-03-06 11:04:20 --> Language file loaded: language/english/english_lang.php
INFO - 2018-03-06 11:04:20 --> Model Class Initialized
INFO - 2018-03-06 11:04:20 --> File loaded: /var/www/html/project/periodtracker/application/views//template/side_bar.php
INFO - 2018-03-06 11:04:20 --> File loaded: /var/www/html/project/periodtracker/application/views//template/header.php
INFO - 2018-03-06 11:04:20 --> File loaded: /var/www/html/project/periodtracker/application/views//template/bread_crumb.php
INFO - 2018-03-06 11:04:20 --> File loaded: /var/www/html/project/periodtracker/application/views//template/footer.php
INFO - 2018-03-06 11:04:20 --> File loaded: /var/www/html/project/periodtracker/application/views/user/index.php
INFO - 2018-03-06 11:04:20 --> Final output sent to browser
DEBUG - 2018-03-06 11:04:20 --> Total execution time: 0.0076
INFO - 2018-03-06 11:04:20 --> Config Class Initialized
INFO - 2018-03-06 11:04:20 --> Hooks Class Initialized
DEBUG - 2018-03-06 11:04:20 --> UTF-8 Support Enabled
INFO - 2018-03-06 11:04:20 --> Utf8 Class Initialized
INFO - 2018-03-06 11:04:20 --> URI Class Initialized
INFO - 2018-03-06 11:04:20 --> Router Class Initialized
INFO - 2018-03-06 11:04:20 --> Output Class Initialized
INFO - 2018-03-06 11:04:20 --> Security Class Initialized
DEBUG - 2018-03-06 11:04:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-06 11:04:20 --> Input Class Initialized
INFO - 2018-03-06 11:04:20 --> Language Class Initialized
INFO - 2018-03-06 11:04:20 --> Loader Class Initialized
INFO - 2018-03-06 11:04:20 --> Helper loaded: url_helper
INFO - 2018-03-06 11:04:20 --> Helper loaded: file_helper
INFO - 2018-03-06 11:04:20 --> Helper loaded: email_helper
INFO - 2018-03-06 11:04:20 --> Helper loaded: common_helper
INFO - 2018-03-06 11:04:20 --> Database Driver Class Initialized
DEBUG - 2018-03-06 11:04:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-06 11:04:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-06 11:04:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-03-06 11:04:20 --> Pagination Class Initialized
INFO - 2018-03-06 11:04:20 --> Helper loaded: form_helper
INFO - 2018-03-06 11:04:20 --> Form Validation Class Initialized
INFO - 2018-03-06 11:04:20 --> Model Class Initialized
INFO - 2018-03-06 11:04:20 --> Controller Class Initialized
INFO - 2018-03-06 11:04:20 --> Language file loaded: language/english/english_lang.php
INFO - 2018-03-06 11:04:20 --> Model Class Initialized
INFO - 2018-03-06 11:23:56 --> Config Class Initialized
INFO - 2018-03-06 11:23:56 --> Hooks Class Initialized
DEBUG - 2018-03-06 11:23:56 --> UTF-8 Support Enabled
INFO - 2018-03-06 11:23:56 --> Utf8 Class Initialized
INFO - 2018-03-06 11:23:56 --> URI Class Initialized
INFO - 2018-03-06 11:23:56 --> Router Class Initialized
INFO - 2018-03-06 11:23:56 --> Output Class Initialized
INFO - 2018-03-06 11:23:56 --> Security Class Initialized
DEBUG - 2018-03-06 11:23:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-06 11:23:56 --> Input Class Initialized
INFO - 2018-03-06 11:23:56 --> Language Class Initialized
INFO - 2018-03-06 11:23:56 --> Loader Class Initialized
INFO - 2018-03-06 11:23:56 --> Helper loaded: url_helper
INFO - 2018-03-06 11:23:56 --> Helper loaded: file_helper
INFO - 2018-03-06 11:23:56 --> Helper loaded: email_helper
INFO - 2018-03-06 11:23:56 --> Helper loaded: common_helper
INFO - 2018-03-06 11:23:56 --> Database Driver Class Initialized
DEBUG - 2018-03-06 11:23:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-06 11:23:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-06 11:23:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-03-06 11:23:56 --> Pagination Class Initialized
INFO - 2018-03-06 11:23:56 --> Helper loaded: form_helper
INFO - 2018-03-06 11:23:56 --> Form Validation Class Initialized
INFO - 2018-03-06 11:23:56 --> Model Class Initialized
INFO - 2018-03-06 11:23:56 --> Controller Class Initialized
INFO - 2018-03-06 11:23:56 --> Language file loaded: language/english/english_lang.php
INFO - 2018-03-06 11:23:56 --> Model Class Initialized
INFO - 2018-03-06 11:23:56 --> File loaded: /var/www/html/project/periodtracker/application/views//template/side_bar.php
INFO - 2018-03-06 11:23:56 --> File loaded: /var/www/html/project/periodtracker/application/views//template/header.php
INFO - 2018-03-06 11:23:56 --> File loaded: /var/www/html/project/periodtracker/application/views//template/bread_crumb.php
INFO - 2018-03-06 11:23:56 --> File loaded: /var/www/html/project/periodtracker/application/views//template/footer.php
INFO - 2018-03-06 11:23:56 --> File loaded: /var/www/html/project/periodtracker/application/views/user/index.php
INFO - 2018-03-06 11:23:56 --> Final output sent to browser
DEBUG - 2018-03-06 11:23:56 --> Total execution time: 0.0049
INFO - 2018-03-06 11:23:57 --> Config Class Initialized
INFO - 2018-03-06 11:23:57 --> Hooks Class Initialized
DEBUG - 2018-03-06 11:23:57 --> UTF-8 Support Enabled
INFO - 2018-03-06 11:23:57 --> Utf8 Class Initialized
INFO - 2018-03-06 11:23:57 --> URI Class Initialized
INFO - 2018-03-06 11:23:57 --> Router Class Initialized
INFO - 2018-03-06 11:23:57 --> Output Class Initialized
INFO - 2018-03-06 11:23:57 --> Security Class Initialized
DEBUG - 2018-03-06 11:23:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-06 11:23:57 --> Input Class Initialized
INFO - 2018-03-06 11:23:57 --> Language Class Initialized
INFO - 2018-03-06 11:23:57 --> Loader Class Initialized
INFO - 2018-03-06 11:23:57 --> Helper loaded: url_helper
INFO - 2018-03-06 11:23:57 --> Helper loaded: file_helper
INFO - 2018-03-06 11:23:57 --> Helper loaded: email_helper
INFO - 2018-03-06 11:23:57 --> Helper loaded: common_helper
INFO - 2018-03-06 11:23:57 --> Database Driver Class Initialized
DEBUG - 2018-03-06 11:23:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-06 11:23:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-06 11:23:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-03-06 11:23:57 --> Pagination Class Initialized
INFO - 2018-03-06 11:23:57 --> Helper loaded: form_helper
INFO - 2018-03-06 11:23:57 --> Form Validation Class Initialized
INFO - 2018-03-06 11:23:57 --> Model Class Initialized
INFO - 2018-03-06 11:23:57 --> Controller Class Initialized
INFO - 2018-03-06 11:23:57 --> Language file loaded: language/english/english_lang.php
INFO - 2018-03-06 11:23:57 --> Model Class Initialized
INFO - 2018-03-06 11:37:06 --> Config Class Initialized
INFO - 2018-03-06 11:37:06 --> Hooks Class Initialized
DEBUG - 2018-03-06 11:37:06 --> UTF-8 Support Enabled
INFO - 2018-03-06 11:37:06 --> Utf8 Class Initialized
INFO - 2018-03-06 11:37:06 --> URI Class Initialized
INFO - 2018-03-06 11:37:06 --> Router Class Initialized
INFO - 2018-03-06 11:37:06 --> Output Class Initialized
INFO - 2018-03-06 11:37:06 --> Security Class Initialized
DEBUG - 2018-03-06 11:37:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-06 11:37:06 --> Input Class Initialized
INFO - 2018-03-06 11:37:06 --> Language Class Initialized
INFO - 2018-03-06 11:37:06 --> Loader Class Initialized
INFO - 2018-03-06 11:37:06 --> Helper loaded: url_helper
INFO - 2018-03-06 11:37:06 --> Helper loaded: file_helper
INFO - 2018-03-06 11:37:06 --> Helper loaded: email_helper
INFO - 2018-03-06 11:37:06 --> Helper loaded: common_helper
INFO - 2018-03-06 11:37:06 --> Database Driver Class Initialized
DEBUG - 2018-03-06 11:37:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-06 11:37:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-06 11:37:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-03-06 11:37:06 --> Pagination Class Initialized
INFO - 2018-03-06 11:37:06 --> Helper loaded: form_helper
INFO - 2018-03-06 11:37:06 --> Form Validation Class Initialized
INFO - 2018-03-06 11:37:06 --> Model Class Initialized
INFO - 2018-03-06 11:37:06 --> Controller Class Initialized
INFO - 2018-03-06 11:37:06 --> Language file loaded: language/english/english_lang.php
INFO - 2018-03-06 11:37:06 --> Model Class Initialized
INFO - 2018-03-06 11:37:06 --> File loaded: /var/www/html/project/periodtracker/application/views//template/side_bar.php
INFO - 2018-03-06 11:37:06 --> File loaded: /var/www/html/project/periodtracker/application/views//template/header.php
INFO - 2018-03-06 11:37:06 --> File loaded: /var/www/html/project/periodtracker/application/views//template/bread_crumb.php
INFO - 2018-03-06 11:37:06 --> File loaded: /var/www/html/project/periodtracker/application/views//template/footer.php
INFO - 2018-03-06 11:37:06 --> File loaded: /var/www/html/project/periodtracker/application/views/user/index.php
INFO - 2018-03-06 11:37:06 --> Final output sent to browser
DEBUG - 2018-03-06 11:37:06 --> Total execution time: 0.0076
INFO - 2018-03-06 11:37:07 --> Config Class Initialized
INFO - 2018-03-06 11:37:07 --> Hooks Class Initialized
DEBUG - 2018-03-06 11:37:07 --> UTF-8 Support Enabled
INFO - 2018-03-06 11:37:07 --> Utf8 Class Initialized
INFO - 2018-03-06 11:37:07 --> URI Class Initialized
INFO - 2018-03-06 11:37:07 --> Router Class Initialized
INFO - 2018-03-06 11:37:07 --> Output Class Initialized
INFO - 2018-03-06 11:37:07 --> Security Class Initialized
DEBUG - 2018-03-06 11:37:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-06 11:37:07 --> Input Class Initialized
INFO - 2018-03-06 11:37:07 --> Language Class Initialized
INFO - 2018-03-06 11:37:07 --> Loader Class Initialized
INFO - 2018-03-06 11:37:07 --> Helper loaded: url_helper
INFO - 2018-03-06 11:37:07 --> Helper loaded: file_helper
INFO - 2018-03-06 11:37:07 --> Helper loaded: email_helper
INFO - 2018-03-06 11:37:07 --> Helper loaded: common_helper
INFO - 2018-03-06 11:37:07 --> Database Driver Class Initialized
DEBUG - 2018-03-06 11:37:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-06 11:37:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-06 11:37:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-03-06 11:37:07 --> Pagination Class Initialized
INFO - 2018-03-06 11:37:07 --> Helper loaded: form_helper
INFO - 2018-03-06 11:37:07 --> Form Validation Class Initialized
INFO - 2018-03-06 11:37:07 --> Model Class Initialized
INFO - 2018-03-06 11:37:07 --> Controller Class Initialized
INFO - 2018-03-06 11:37:07 --> Language file loaded: language/english/english_lang.php
INFO - 2018-03-06 11:37:07 --> Model Class Initialized
INFO - 2018-03-06 13:15:44 --> Config Class Initialized
INFO - 2018-03-06 13:15:44 --> Hooks Class Initialized
DEBUG - 2018-03-06 13:15:44 --> UTF-8 Support Enabled
INFO - 2018-03-06 13:15:44 --> Utf8 Class Initialized
INFO - 2018-03-06 13:15:44 --> URI Class Initialized
INFO - 2018-03-06 13:15:44 --> Router Class Initialized
INFO - 2018-03-06 13:15:44 --> Output Class Initialized
INFO - 2018-03-06 13:15:44 --> Security Class Initialized
DEBUG - 2018-03-06 13:15:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-06 13:15:44 --> Input Class Initialized
INFO - 2018-03-06 13:15:44 --> Language Class Initialized
INFO - 2018-03-06 13:15:44 --> Loader Class Initialized
INFO - 2018-03-06 13:15:44 --> Helper loaded: url_helper
INFO - 2018-03-06 13:15:44 --> Helper loaded: file_helper
INFO - 2018-03-06 13:15:44 --> Helper loaded: email_helper
INFO - 2018-03-06 13:15:44 --> Helper loaded: common_helper
INFO - 2018-03-06 13:15:44 --> Database Driver Class Initialized
DEBUG - 2018-03-06 13:15:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-06 13:15:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-06 13:15:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-03-06 13:15:44 --> Pagination Class Initialized
INFO - 2018-03-06 13:15:44 --> Helper loaded: form_helper
INFO - 2018-03-06 13:15:44 --> Form Validation Class Initialized
INFO - 2018-03-06 13:15:44 --> Model Class Initialized
INFO - 2018-03-06 13:15:44 --> Controller Class Initialized
INFO - 2018-03-06 13:15:44 --> Language file loaded: language/english/english_lang.php
INFO - 2018-03-06 13:15:44 --> Model Class Initialized
INFO - 2018-03-06 13:15:44 --> File loaded: /var/www/html/project/periodtracker/application/views//template/side_bar.php
INFO - 2018-03-06 13:15:44 --> File loaded: /var/www/html/project/periodtracker/application/views//template/header.php
INFO - 2018-03-06 13:15:44 --> File loaded: /var/www/html/project/periodtracker/application/views//template/bread_crumb.php
INFO - 2018-03-06 13:15:44 --> File loaded: /var/www/html/project/periodtracker/application/views//template/footer.php
INFO - 2018-03-06 13:15:44 --> File loaded: /var/www/html/project/periodtracker/application/views/user/index.php
INFO - 2018-03-06 13:15:44 --> Final output sent to browser
DEBUG - 2018-03-06 13:15:44 --> Total execution time: 0.0049
INFO - 2018-03-06 13:21:12 --> Config Class Initialized
INFO - 2018-03-06 13:21:12 --> Hooks Class Initialized
DEBUG - 2018-03-06 13:21:12 --> UTF-8 Support Enabled
INFO - 2018-03-06 13:21:12 --> Utf8 Class Initialized
INFO - 2018-03-06 13:21:12 --> URI Class Initialized
INFO - 2018-03-06 13:21:12 --> Router Class Initialized
INFO - 2018-03-06 13:21:12 --> Output Class Initialized
INFO - 2018-03-06 13:21:12 --> Security Class Initialized
DEBUG - 2018-03-06 13:21:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-06 13:21:12 --> Input Class Initialized
INFO - 2018-03-06 13:21:12 --> Language Class Initialized
INFO - 2018-03-06 13:21:12 --> Loader Class Initialized
INFO - 2018-03-06 13:21:12 --> Helper loaded: url_helper
INFO - 2018-03-06 13:21:12 --> Helper loaded: file_helper
INFO - 2018-03-06 13:21:12 --> Helper loaded: email_helper
INFO - 2018-03-06 13:21:12 --> Helper loaded: common_helper
INFO - 2018-03-06 13:21:12 --> Database Driver Class Initialized
DEBUG - 2018-03-06 13:21:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-06 13:21:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-06 13:21:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-03-06 13:21:12 --> Pagination Class Initialized
INFO - 2018-03-06 13:21:12 --> Helper loaded: form_helper
INFO - 2018-03-06 13:21:12 --> Form Validation Class Initialized
INFO - 2018-03-06 13:21:12 --> Model Class Initialized
INFO - 2018-03-06 13:21:12 --> Controller Class Initialized
INFO - 2018-03-06 13:21:12 --> Language file loaded: language/english/english_lang.php
INFO - 2018-03-06 13:21:12 --> Model Class Initialized
INFO - 2018-03-06 13:21:12 --> File loaded: /var/www/html/project/periodtracker/application/views//template/side_bar.php
INFO - 2018-03-06 13:21:12 --> File loaded: /var/www/html/project/periodtracker/application/views//template/header.php
INFO - 2018-03-06 13:21:12 --> File loaded: /var/www/html/project/periodtracker/application/views//template/bread_crumb.php
INFO - 2018-03-06 13:21:12 --> File loaded: /var/www/html/project/periodtracker/application/views//template/footer.php
INFO - 2018-03-06 13:21:12 --> File loaded: /var/www/html/project/periodtracker/application/views/user/index.php
INFO - 2018-03-06 13:21:12 --> Final output sent to browser
DEBUG - 2018-03-06 13:21:12 --> Total execution time: 0.0092
INFO - 2018-03-06 13:21:12 --> Config Class Initialized
INFO - 2018-03-06 13:21:12 --> Hooks Class Initialized
DEBUG - 2018-03-06 13:21:12 --> UTF-8 Support Enabled
INFO - 2018-03-06 13:21:12 --> Utf8 Class Initialized
INFO - 2018-03-06 13:21:12 --> URI Class Initialized
INFO - 2018-03-06 13:21:12 --> Router Class Initialized
INFO - 2018-03-06 13:21:12 --> Output Class Initialized
INFO - 2018-03-06 13:21:12 --> Security Class Initialized
DEBUG - 2018-03-06 13:21:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-06 13:21:12 --> Input Class Initialized
INFO - 2018-03-06 13:21:12 --> Language Class Initialized
INFO - 2018-03-06 13:21:12 --> Loader Class Initialized
INFO - 2018-03-06 13:21:12 --> Helper loaded: url_helper
INFO - 2018-03-06 13:21:12 --> Helper loaded: file_helper
INFO - 2018-03-06 13:21:12 --> Helper loaded: email_helper
INFO - 2018-03-06 13:21:12 --> Helper loaded: common_helper
INFO - 2018-03-06 13:21:12 --> Database Driver Class Initialized
DEBUG - 2018-03-06 13:21:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-06 13:21:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-06 13:21:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-03-06 13:21:12 --> Pagination Class Initialized
INFO - 2018-03-06 13:21:12 --> Helper loaded: form_helper
INFO - 2018-03-06 13:21:12 --> Form Validation Class Initialized
INFO - 2018-03-06 13:21:12 --> Model Class Initialized
INFO - 2018-03-06 13:21:12 --> Controller Class Initialized
INFO - 2018-03-06 13:21:12 --> Language file loaded: language/english/english_lang.php
INFO - 2018-03-06 13:21:12 --> Model Class Initialized
INFO - 2018-03-06 13:21:14 --> Config Class Initialized
INFO - 2018-03-06 13:21:14 --> Hooks Class Initialized
DEBUG - 2018-03-06 13:21:14 --> UTF-8 Support Enabled
INFO - 2018-03-06 13:21:14 --> Utf8 Class Initialized
INFO - 2018-03-06 13:21:14 --> URI Class Initialized
INFO - 2018-03-06 13:21:14 --> Router Class Initialized
INFO - 2018-03-06 13:21:14 --> Output Class Initialized
INFO - 2018-03-06 13:21:14 --> Security Class Initialized
DEBUG - 2018-03-06 13:21:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-06 13:21:14 --> Input Class Initialized
INFO - 2018-03-06 13:21:14 --> Language Class Initialized
INFO - 2018-03-06 13:21:14 --> Loader Class Initialized
INFO - 2018-03-06 13:21:14 --> Helper loaded: url_helper
INFO - 2018-03-06 13:21:14 --> Helper loaded: file_helper
INFO - 2018-03-06 13:21:14 --> Helper loaded: email_helper
INFO - 2018-03-06 13:21:14 --> Helper loaded: common_helper
INFO - 2018-03-06 13:21:14 --> Database Driver Class Initialized
DEBUG - 2018-03-06 13:21:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-06 13:21:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-06 13:21:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-03-06 13:21:14 --> Pagination Class Initialized
INFO - 2018-03-06 13:21:14 --> Helper loaded: form_helper
INFO - 2018-03-06 13:21:14 --> Form Validation Class Initialized
INFO - 2018-03-06 13:21:14 --> Model Class Initialized
INFO - 2018-03-06 13:21:14 --> Controller Class Initialized
INFO - 2018-03-06 13:21:14 --> Language file loaded: language/english/english_lang.php
INFO - 2018-03-06 13:21:14 --> Model Class Initialized
INFO - 2018-03-06 13:21:14 --> Model Class Initialized
INFO - 2018-03-06 13:21:14 --> File loaded: /var/www/html/project/periodtracker/application/views//template/side_bar.php
INFO - 2018-03-06 13:21:14 --> File loaded: /var/www/html/project/periodtracker/application/views//template/header.php
INFO - 2018-03-06 13:21:14 --> File loaded: /var/www/html/project/periodtracker/application/views//template/bread_crumb.php
INFO - 2018-03-06 13:21:14 --> File loaded: /var/www/html/project/periodtracker/application/views//template/footer.php
INFO - 2018-03-06 13:21:14 --> File loaded: /var/www/html/project/periodtracker/application/views/user/index.php
INFO - 2018-03-06 13:21:14 --> Final output sent to browser
DEBUG - 2018-03-06 13:21:14 --> Total execution time: 0.0091
INFO - 2018-03-06 13:21:15 --> Config Class Initialized
INFO - 2018-03-06 13:21:15 --> Hooks Class Initialized
DEBUG - 2018-03-06 13:21:15 --> UTF-8 Support Enabled
INFO - 2018-03-06 13:21:15 --> Utf8 Class Initialized
INFO - 2018-03-06 13:21:15 --> URI Class Initialized
INFO - 2018-03-06 13:21:15 --> Router Class Initialized
INFO - 2018-03-06 13:21:15 --> Output Class Initialized
INFO - 2018-03-06 13:21:15 --> Security Class Initialized
DEBUG - 2018-03-06 13:21:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-06 13:21:15 --> Input Class Initialized
INFO - 2018-03-06 13:21:15 --> Language Class Initialized
INFO - 2018-03-06 13:21:15 --> Loader Class Initialized
INFO - 2018-03-06 13:21:15 --> Helper loaded: url_helper
INFO - 2018-03-06 13:21:15 --> Helper loaded: file_helper
INFO - 2018-03-06 13:21:15 --> Helper loaded: email_helper
INFO - 2018-03-06 13:21:15 --> Helper loaded: common_helper
INFO - 2018-03-06 13:21:15 --> Database Driver Class Initialized
DEBUG - 2018-03-06 13:21:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-06 13:21:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-06 13:21:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-03-06 13:21:15 --> Pagination Class Initialized
INFO - 2018-03-06 13:21:15 --> Helper loaded: form_helper
INFO - 2018-03-06 13:21:15 --> Form Validation Class Initialized
INFO - 2018-03-06 13:21:15 --> Model Class Initialized
INFO - 2018-03-06 13:21:15 --> Controller Class Initialized
INFO - 2018-03-06 13:21:15 --> Language file loaded: language/english/english_lang.php
INFO - 2018-03-06 13:21:15 --> Model Class Initialized
INFO - 2018-03-06 13:21:16 --> Config Class Initialized
INFO - 2018-03-06 13:21:16 --> Hooks Class Initialized
DEBUG - 2018-03-06 13:21:16 --> UTF-8 Support Enabled
INFO - 2018-03-06 13:21:16 --> Utf8 Class Initialized
INFO - 2018-03-06 13:21:16 --> URI Class Initialized
INFO - 2018-03-06 13:21:16 --> Router Class Initialized
INFO - 2018-03-06 13:21:16 --> Output Class Initialized
INFO - 2018-03-06 13:21:16 --> Security Class Initialized
DEBUG - 2018-03-06 13:21:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-06 13:21:16 --> Input Class Initialized
INFO - 2018-03-06 13:21:16 --> Language Class Initialized
INFO - 2018-03-06 13:21:16 --> Loader Class Initialized
INFO - 2018-03-06 13:21:16 --> Helper loaded: url_helper
INFO - 2018-03-06 13:21:16 --> Helper loaded: file_helper
INFO - 2018-03-06 13:21:16 --> Helper loaded: email_helper
INFO - 2018-03-06 13:21:16 --> Helper loaded: common_helper
INFO - 2018-03-06 13:21:16 --> Database Driver Class Initialized
DEBUG - 2018-03-06 13:21:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-06 13:21:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-06 13:21:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-03-06 13:21:16 --> Pagination Class Initialized
INFO - 2018-03-06 13:21:16 --> Helper loaded: form_helper
INFO - 2018-03-06 13:21:16 --> Form Validation Class Initialized
INFO - 2018-03-06 13:21:16 --> Model Class Initialized
INFO - 2018-03-06 13:21:16 --> Controller Class Initialized
INFO - 2018-03-06 13:21:16 --> Language file loaded: language/english/english_lang.php
INFO - 2018-03-06 13:21:16 --> Model Class Initialized
INFO - 2018-03-06 13:21:16 --> File loaded: /var/www/html/project/periodtracker/application/views//template/side_bar.php
INFO - 2018-03-06 13:21:16 --> File loaded: /var/www/html/project/periodtracker/application/views//template/header.php
INFO - 2018-03-06 13:21:16 --> File loaded: /var/www/html/project/periodtracker/application/views//template/bread_crumb.php
INFO - 2018-03-06 13:21:16 --> File loaded: /var/www/html/project/periodtracker/application/views//template/footer.php
INFO - 2018-03-06 13:21:16 --> File loaded: /var/www/html/project/periodtracker/application/views/user/index.php
INFO - 2018-03-06 13:21:16 --> Final output sent to browser
DEBUG - 2018-03-06 13:21:16 --> Total execution time: 0.0056
INFO - 2018-03-06 13:21:17 --> Config Class Initialized
INFO - 2018-03-06 13:21:17 --> Hooks Class Initialized
DEBUG - 2018-03-06 13:21:17 --> UTF-8 Support Enabled
INFO - 2018-03-06 13:21:17 --> Utf8 Class Initialized
INFO - 2018-03-06 13:21:17 --> URI Class Initialized
INFO - 2018-03-06 13:21:17 --> Router Class Initialized
INFO - 2018-03-06 13:21:17 --> Output Class Initialized
INFO - 2018-03-06 13:21:17 --> Security Class Initialized
DEBUG - 2018-03-06 13:21:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-06 13:21:17 --> Input Class Initialized
INFO - 2018-03-06 13:21:17 --> Language Class Initialized
INFO - 2018-03-06 13:21:17 --> Loader Class Initialized
INFO - 2018-03-06 13:21:17 --> Helper loaded: url_helper
INFO - 2018-03-06 13:21:17 --> Helper loaded: file_helper
INFO - 2018-03-06 13:21:17 --> Helper loaded: email_helper
INFO - 2018-03-06 13:21:17 --> Helper loaded: common_helper
INFO - 2018-03-06 13:21:17 --> Database Driver Class Initialized
DEBUG - 2018-03-06 13:21:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-06 13:21:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-06 13:21:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-03-06 13:21:17 --> Pagination Class Initialized
INFO - 2018-03-06 13:21:17 --> Helper loaded: form_helper
INFO - 2018-03-06 13:21:17 --> Form Validation Class Initialized
INFO - 2018-03-06 13:21:17 --> Model Class Initialized
INFO - 2018-03-06 13:21:17 --> Controller Class Initialized
INFO - 2018-03-06 13:21:17 --> Language file loaded: language/english/english_lang.php
INFO - 2018-03-06 13:21:17 --> Model Class Initialized
INFO - 2018-03-06 13:21:17 --> Config Class Initialized
INFO - 2018-03-06 13:21:17 --> Hooks Class Initialized
DEBUG - 2018-03-06 13:21:17 --> UTF-8 Support Enabled
INFO - 2018-03-06 13:21:17 --> Utf8 Class Initialized
INFO - 2018-03-06 13:21:17 --> URI Class Initialized
INFO - 2018-03-06 13:21:17 --> Router Class Initialized
INFO - 2018-03-06 13:21:17 --> Output Class Initialized
INFO - 2018-03-06 13:21:17 --> Security Class Initialized
DEBUG - 2018-03-06 13:21:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-06 13:21:17 --> Input Class Initialized
INFO - 2018-03-06 13:21:17 --> Language Class Initialized
INFO - 2018-03-06 13:21:17 --> Loader Class Initialized
INFO - 2018-03-06 13:21:17 --> Helper loaded: url_helper
INFO - 2018-03-06 13:21:17 --> Helper loaded: file_helper
INFO - 2018-03-06 13:21:17 --> Helper loaded: email_helper
INFO - 2018-03-06 13:21:17 --> Helper loaded: common_helper
INFO - 2018-03-06 13:21:17 --> Database Driver Class Initialized
DEBUG - 2018-03-06 13:21:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-06 13:21:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-06 13:21:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-03-06 13:21:17 --> Pagination Class Initialized
INFO - 2018-03-06 13:21:17 --> Helper loaded: form_helper
INFO - 2018-03-06 13:21:17 --> Form Validation Class Initialized
INFO - 2018-03-06 13:21:17 --> Model Class Initialized
INFO - 2018-03-06 13:21:17 --> Controller Class Initialized
INFO - 2018-03-06 13:21:17 --> Language file loaded: language/english/english_lang.php
INFO - 2018-03-06 13:21:17 --> Model Class Initialized
INFO - 2018-03-06 13:21:17 --> Model Class Initialized
INFO - 2018-03-06 13:21:17 --> File loaded: /var/www/html/project/periodtracker/application/views//template/side_bar.php
INFO - 2018-03-06 13:21:17 --> File loaded: /var/www/html/project/periodtracker/application/views//template/header.php
INFO - 2018-03-06 13:21:17 --> File loaded: /var/www/html/project/periodtracker/application/views//template/bread_crumb.php
INFO - 2018-03-06 13:21:17 --> File loaded: /var/www/html/project/periodtracker/application/views//template/footer.php
INFO - 2018-03-06 13:21:17 --> File loaded: /var/www/html/project/periodtracker/application/views/user/index.php
INFO - 2018-03-06 13:21:17 --> Final output sent to browser
DEBUG - 2018-03-06 13:21:17 --> Total execution time: 0.0065
INFO - 2018-03-06 13:21:17 --> Config Class Initialized
INFO - 2018-03-06 13:21:17 --> Hooks Class Initialized
DEBUG - 2018-03-06 13:21:17 --> UTF-8 Support Enabled
INFO - 2018-03-06 13:21:17 --> Utf8 Class Initialized
INFO - 2018-03-06 13:21:17 --> URI Class Initialized
INFO - 2018-03-06 13:21:17 --> Router Class Initialized
INFO - 2018-03-06 13:21:17 --> Output Class Initialized
INFO - 2018-03-06 13:21:17 --> Security Class Initialized
DEBUG - 2018-03-06 13:21:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-06 13:21:17 --> Input Class Initialized
INFO - 2018-03-06 13:21:17 --> Language Class Initialized
INFO - 2018-03-06 13:21:17 --> Loader Class Initialized
INFO - 2018-03-06 13:21:17 --> Helper loaded: url_helper
INFO - 2018-03-06 13:21:17 --> Helper loaded: file_helper
INFO - 2018-03-06 13:21:17 --> Helper loaded: email_helper
INFO - 2018-03-06 13:21:17 --> Helper loaded: common_helper
INFO - 2018-03-06 13:21:17 --> Database Driver Class Initialized
DEBUG - 2018-03-06 13:21:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-06 13:21:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-06 13:21:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-03-06 13:21:17 --> Pagination Class Initialized
INFO - 2018-03-06 13:21:17 --> Helper loaded: form_helper
INFO - 2018-03-06 13:21:17 --> Form Validation Class Initialized
INFO - 2018-03-06 13:21:17 --> Model Class Initialized
INFO - 2018-03-06 13:21:17 --> Controller Class Initialized
INFO - 2018-03-06 13:21:17 --> Language file loaded: language/english/english_lang.php
INFO - 2018-03-06 13:21:17 --> Model Class Initialized
INFO - 2018-03-06 13:21:31 --> Config Class Initialized
INFO - 2018-03-06 13:21:31 --> Hooks Class Initialized
DEBUG - 2018-03-06 13:21:31 --> UTF-8 Support Enabled
INFO - 2018-03-06 13:21:31 --> Utf8 Class Initialized
INFO - 2018-03-06 13:21:31 --> URI Class Initialized
INFO - 2018-03-06 13:21:31 --> Router Class Initialized
INFO - 2018-03-06 13:21:31 --> Output Class Initialized
INFO - 2018-03-06 13:21:31 --> Security Class Initialized
DEBUG - 2018-03-06 13:21:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-06 13:21:31 --> Input Class Initialized
INFO - 2018-03-06 13:21:31 --> Language Class Initialized
INFO - 2018-03-06 13:21:31 --> Loader Class Initialized
INFO - 2018-03-06 13:21:31 --> Helper loaded: url_helper
INFO - 2018-03-06 13:21:31 --> Helper loaded: file_helper
INFO - 2018-03-06 13:21:31 --> Helper loaded: email_helper
INFO - 2018-03-06 13:21:31 --> Helper loaded: common_helper
INFO - 2018-03-06 13:21:31 --> Database Driver Class Initialized
DEBUG - 2018-03-06 13:21:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-06 13:21:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-06 13:21:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-03-06 13:21:31 --> Pagination Class Initialized
INFO - 2018-03-06 13:21:31 --> Helper loaded: form_helper
INFO - 2018-03-06 13:21:31 --> Form Validation Class Initialized
INFO - 2018-03-06 13:21:31 --> Model Class Initialized
INFO - 2018-03-06 13:21:31 --> Controller Class Initialized
INFO - 2018-03-06 13:21:31 --> Language file loaded: language/english/english_lang.php
INFO - 2018-03-06 13:21:31 --> Model Class Initialized
INFO - 2018-03-06 13:21:31 --> File loaded: /var/www/html/project/periodtracker/application/views//template/side_bar.php
INFO - 2018-03-06 13:21:31 --> File loaded: /var/www/html/project/periodtracker/application/views//template/header.php
INFO - 2018-03-06 13:21:31 --> File loaded: /var/www/html/project/periodtracker/application/views//template/bread_crumb.php
INFO - 2018-03-06 13:21:31 --> File loaded: /var/www/html/project/periodtracker/application/views//template/footer.php
INFO - 2018-03-06 13:21:31 --> File loaded: /var/www/html/project/periodtracker/application/views/user/index.php
INFO - 2018-03-06 13:21:31 --> Final output sent to browser
DEBUG - 2018-03-06 13:21:31 --> Total execution time: 0.0059
INFO - 2018-03-06 13:21:32 --> Config Class Initialized
INFO - 2018-03-06 13:21:32 --> Hooks Class Initialized
DEBUG - 2018-03-06 13:21:32 --> UTF-8 Support Enabled
INFO - 2018-03-06 13:21:32 --> Utf8 Class Initialized
INFO - 2018-03-06 13:21:32 --> URI Class Initialized
INFO - 2018-03-06 13:21:32 --> Router Class Initialized
INFO - 2018-03-06 13:21:32 --> Output Class Initialized
INFO - 2018-03-06 13:21:32 --> Security Class Initialized
DEBUG - 2018-03-06 13:21:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-06 13:21:32 --> Input Class Initialized
INFO - 2018-03-06 13:21:32 --> Language Class Initialized
INFO - 2018-03-06 13:21:32 --> Loader Class Initialized
INFO - 2018-03-06 13:21:32 --> Helper loaded: url_helper
INFO - 2018-03-06 13:21:32 --> Helper loaded: file_helper
INFO - 2018-03-06 13:21:32 --> Helper loaded: email_helper
INFO - 2018-03-06 13:21:32 --> Helper loaded: common_helper
INFO - 2018-03-06 13:21:32 --> Database Driver Class Initialized
DEBUG - 2018-03-06 13:21:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-06 13:21:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-06 13:21:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-03-06 13:21:32 --> Pagination Class Initialized
INFO - 2018-03-06 13:21:32 --> Helper loaded: form_helper
INFO - 2018-03-06 13:21:32 --> Form Validation Class Initialized
INFO - 2018-03-06 13:21:32 --> Model Class Initialized
INFO - 2018-03-06 13:21:32 --> Controller Class Initialized
INFO - 2018-03-06 13:21:32 --> Language file loaded: language/english/english_lang.php
INFO - 2018-03-06 13:21:32 --> Model Class Initialized
INFO - 2018-03-06 13:21:32 --> Config Class Initialized
INFO - 2018-03-06 13:21:32 --> Hooks Class Initialized
DEBUG - 2018-03-06 13:21:32 --> UTF-8 Support Enabled
INFO - 2018-03-06 13:21:32 --> Utf8 Class Initialized
INFO - 2018-03-06 13:21:32 --> URI Class Initialized
INFO - 2018-03-06 13:21:32 --> Router Class Initialized
INFO - 2018-03-06 13:21:32 --> Output Class Initialized
INFO - 2018-03-06 13:21:32 --> Security Class Initialized
DEBUG - 2018-03-06 13:21:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-06 13:21:32 --> Input Class Initialized
INFO - 2018-03-06 13:21:32 --> Language Class Initialized
INFO - 2018-03-06 13:21:32 --> Loader Class Initialized
INFO - 2018-03-06 13:21:32 --> Helper loaded: url_helper
INFO - 2018-03-06 13:21:32 --> Helper loaded: file_helper
INFO - 2018-03-06 13:21:32 --> Helper loaded: email_helper
INFO - 2018-03-06 13:21:32 --> Helper loaded: common_helper
INFO - 2018-03-06 13:21:32 --> Database Driver Class Initialized
DEBUG - 2018-03-06 13:21:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-06 13:21:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-06 13:21:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-03-06 13:21:32 --> Pagination Class Initialized
INFO - 2018-03-06 13:21:32 --> Helper loaded: form_helper
INFO - 2018-03-06 13:21:32 --> Form Validation Class Initialized
INFO - 2018-03-06 13:21:32 --> Model Class Initialized
INFO - 2018-03-06 13:21:32 --> Controller Class Initialized
INFO - 2018-03-06 13:21:32 --> Language file loaded: language/english/english_lang.php
INFO - 2018-03-06 13:21:32 --> Model Class Initialized
INFO - 2018-03-06 13:21:32 --> Model Class Initialized
INFO - 2018-03-06 13:21:32 --> File loaded: /var/www/html/project/periodtracker/application/views//template/side_bar.php
INFO - 2018-03-06 13:21:32 --> File loaded: /var/www/html/project/periodtracker/application/views//template/header.php
INFO - 2018-03-06 13:21:32 --> File loaded: /var/www/html/project/periodtracker/application/views//template/bread_crumb.php
INFO - 2018-03-06 13:21:32 --> File loaded: /var/www/html/project/periodtracker/application/views//template/footer.php
INFO - 2018-03-06 13:21:32 --> File loaded: /var/www/html/project/periodtracker/application/views/user/index.php
INFO - 2018-03-06 13:21:32 --> Final output sent to browser
DEBUG - 2018-03-06 13:21:32 --> Total execution time: 0.0060
INFO - 2018-03-06 13:21:32 --> Config Class Initialized
INFO - 2018-03-06 13:21:32 --> Hooks Class Initialized
DEBUG - 2018-03-06 13:21:32 --> UTF-8 Support Enabled
INFO - 2018-03-06 13:21:32 --> Utf8 Class Initialized
INFO - 2018-03-06 13:21:32 --> URI Class Initialized
INFO - 2018-03-06 13:21:32 --> Router Class Initialized
INFO - 2018-03-06 13:21:32 --> Output Class Initialized
INFO - 2018-03-06 13:21:32 --> Security Class Initialized
DEBUG - 2018-03-06 13:21:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-06 13:21:32 --> Input Class Initialized
INFO - 2018-03-06 13:21:32 --> Language Class Initialized
INFO - 2018-03-06 13:21:32 --> Loader Class Initialized
INFO - 2018-03-06 13:21:32 --> Helper loaded: url_helper
INFO - 2018-03-06 13:21:32 --> Helper loaded: file_helper
INFO - 2018-03-06 13:21:32 --> Helper loaded: email_helper
INFO - 2018-03-06 13:21:32 --> Helper loaded: common_helper
INFO - 2018-03-06 13:21:32 --> Database Driver Class Initialized
DEBUG - 2018-03-06 13:21:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-06 13:21:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-06 13:21:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-03-06 13:21:32 --> Pagination Class Initialized
INFO - 2018-03-06 13:21:32 --> Helper loaded: form_helper
INFO - 2018-03-06 13:21:32 --> Form Validation Class Initialized
INFO - 2018-03-06 13:21:32 --> Model Class Initialized
INFO - 2018-03-06 13:21:32 --> Controller Class Initialized
INFO - 2018-03-06 13:21:32 --> Language file loaded: language/english/english_lang.php
INFO - 2018-03-06 13:21:32 --> Model Class Initialized
INFO - 2018-03-06 13:21:48 --> Config Class Initialized
INFO - 2018-03-06 13:21:48 --> Hooks Class Initialized
DEBUG - 2018-03-06 13:21:48 --> UTF-8 Support Enabled
INFO - 2018-03-06 13:21:48 --> Utf8 Class Initialized
INFO - 2018-03-06 13:21:48 --> URI Class Initialized
INFO - 2018-03-06 13:21:48 --> Router Class Initialized
INFO - 2018-03-06 13:21:48 --> Output Class Initialized
INFO - 2018-03-06 13:21:48 --> Security Class Initialized
DEBUG - 2018-03-06 13:21:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-06 13:21:48 --> Input Class Initialized
INFO - 2018-03-06 13:21:48 --> Language Class Initialized
INFO - 2018-03-06 13:21:48 --> Loader Class Initialized
INFO - 2018-03-06 13:21:48 --> Helper loaded: url_helper
INFO - 2018-03-06 13:21:48 --> Helper loaded: file_helper
INFO - 2018-03-06 13:21:48 --> Helper loaded: email_helper
INFO - 2018-03-06 13:21:48 --> Helper loaded: common_helper
INFO - 2018-03-06 13:21:48 --> Database Driver Class Initialized
DEBUG - 2018-03-06 13:21:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-06 13:21:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-06 13:21:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-03-06 13:21:48 --> Pagination Class Initialized
INFO - 2018-03-06 13:21:48 --> Helper loaded: form_helper
INFO - 2018-03-06 13:21:48 --> Form Validation Class Initialized
INFO - 2018-03-06 13:21:48 --> Model Class Initialized
INFO - 2018-03-06 13:21:48 --> Controller Class Initialized
INFO - 2018-03-06 13:21:48 --> Language file loaded: language/english/english_lang.php
INFO - 2018-03-06 13:21:48 --> Model Class Initialized
INFO - 2018-03-06 13:21:48 --> Model Class Initialized
INFO - 2018-03-06 13:21:48 --> File loaded: /var/www/html/project/periodtracker/application/views//template/side_bar.php
INFO - 2018-03-06 13:21:48 --> File loaded: /var/www/html/project/periodtracker/application/views//template/header.php
INFO - 2018-03-06 13:21:48 --> File loaded: /var/www/html/project/periodtracker/application/views//template/bread_crumb.php
INFO - 2018-03-06 13:21:48 --> File loaded: /var/www/html/project/periodtracker/application/views//template/footer.php
INFO - 2018-03-06 13:21:48 --> File loaded: /var/www/html/project/periodtracker/application/views/thermometersubscription/index.php
INFO - 2018-03-06 13:21:48 --> Final output sent to browser
DEBUG - 2018-03-06 13:21:48 --> Total execution time: 0.0058
INFO - 2018-03-06 13:22:01 --> Config Class Initialized
INFO - 2018-03-06 13:22:01 --> Hooks Class Initialized
DEBUG - 2018-03-06 13:22:01 --> UTF-8 Support Enabled
INFO - 2018-03-06 13:22:01 --> Utf8 Class Initialized
INFO - 2018-03-06 13:22:01 --> URI Class Initialized
INFO - 2018-03-06 13:22:01 --> Router Class Initialized
INFO - 2018-03-06 13:22:01 --> Output Class Initialized
INFO - 2018-03-06 13:22:01 --> Security Class Initialized
DEBUG - 2018-03-06 13:22:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-06 13:22:01 --> Input Class Initialized
INFO - 2018-03-06 13:22:01 --> Language Class Initialized
INFO - 2018-03-06 13:22:01 --> Loader Class Initialized
INFO - 2018-03-06 13:22:01 --> Helper loaded: url_helper
INFO - 2018-03-06 13:22:01 --> Helper loaded: file_helper
INFO - 2018-03-06 13:22:01 --> Helper loaded: email_helper
INFO - 2018-03-06 13:22:01 --> Helper loaded: common_helper
INFO - 2018-03-06 13:22:01 --> Database Driver Class Initialized
DEBUG - 2018-03-06 13:22:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-06 13:22:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-06 13:22:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-03-06 13:22:01 --> Pagination Class Initialized
INFO - 2018-03-06 13:22:01 --> Helper loaded: form_helper
INFO - 2018-03-06 13:22:01 --> Form Validation Class Initialized
INFO - 2018-03-06 13:22:01 --> Model Class Initialized
INFO - 2018-03-06 13:22:01 --> Controller Class Initialized
INFO - 2018-03-06 13:22:01 --> Language file loaded: language/english/english_lang.php
INFO - 2018-03-06 13:22:01 --> Model Class Initialized
INFO - 2018-03-06 13:22:01 --> Model Class Initialized
INFO - 2018-03-06 13:22:01 --> File loaded: /var/www/html/project/periodtracker/application/views//template/side_bar.php
INFO - 2018-03-06 13:22:01 --> File loaded: /var/www/html/project/periodtracker/application/views//template/header.php
INFO - 2018-03-06 13:22:01 --> File loaded: /var/www/html/project/periodtracker/application/views//template/bread_crumb.php
INFO - 2018-03-06 13:22:01 --> File loaded: /var/www/html/project/periodtracker/application/views//template/footer.php
INFO - 2018-03-06 13:22:01 --> File loaded: /var/www/html/project/periodtracker/application/views/thermometersubscription/index.php
INFO - 2018-03-06 13:22:01 --> Final output sent to browser
DEBUG - 2018-03-06 13:22:01 --> Total execution time: 0.0081
INFO - 2018-03-06 13:22:19 --> Config Class Initialized
INFO - 2018-03-06 13:22:19 --> Hooks Class Initialized
DEBUG - 2018-03-06 13:22:19 --> UTF-8 Support Enabled
INFO - 2018-03-06 13:22:19 --> Utf8 Class Initialized
INFO - 2018-03-06 13:22:19 --> URI Class Initialized
INFO - 2018-03-06 13:22:19 --> Router Class Initialized
INFO - 2018-03-06 13:22:19 --> Output Class Initialized
INFO - 2018-03-06 13:22:19 --> Security Class Initialized
DEBUG - 2018-03-06 13:22:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-06 13:22:19 --> Input Class Initialized
INFO - 2018-03-06 13:22:19 --> Language Class Initialized
INFO - 2018-03-06 13:22:19 --> Loader Class Initialized
INFO - 2018-03-06 13:22:19 --> Helper loaded: url_helper
INFO - 2018-03-06 13:22:19 --> Helper loaded: file_helper
INFO - 2018-03-06 13:22:19 --> Helper loaded: email_helper
INFO - 2018-03-06 13:22:19 --> Helper loaded: common_helper
INFO - 2018-03-06 13:22:19 --> Database Driver Class Initialized
DEBUG - 2018-03-06 13:22:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-06 13:22:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-06 13:22:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-03-06 13:22:19 --> Pagination Class Initialized
INFO - 2018-03-06 13:22:19 --> Helper loaded: form_helper
INFO - 2018-03-06 13:22:19 --> Form Validation Class Initialized
INFO - 2018-03-06 13:22:19 --> Model Class Initialized
INFO - 2018-03-06 13:22:19 --> Controller Class Initialized
INFO - 2018-03-06 13:22:19 --> Language file loaded: language/english/english_lang.php
INFO - 2018-03-06 13:22:19 --> Model Class Initialized
INFO - 2018-03-06 13:22:19 --> Model Class Initialized
INFO - 2018-03-06 13:22:19 --> File loaded: /var/www/html/project/periodtracker/application/views//template/side_bar.php
INFO - 2018-03-06 13:22:19 --> File loaded: /var/www/html/project/periodtracker/application/views//template/header.php
INFO - 2018-03-06 13:22:19 --> File loaded: /var/www/html/project/periodtracker/application/views//template/bread_crumb.php
INFO - 2018-03-06 13:22:19 --> File loaded: /var/www/html/project/periodtracker/application/views//template/footer.php
INFO - 2018-03-06 13:22:19 --> File loaded: /var/www/html/project/periodtracker/application/views/thermometersubscription/index.php
INFO - 2018-03-06 13:22:19 --> Final output sent to browser
DEBUG - 2018-03-06 13:22:19 --> Total execution time: 0.0065
INFO - 2018-03-06 13:22:56 --> Config Class Initialized
INFO - 2018-03-06 13:22:56 --> Hooks Class Initialized
DEBUG - 2018-03-06 13:22:56 --> UTF-8 Support Enabled
INFO - 2018-03-06 13:22:56 --> Utf8 Class Initialized
INFO - 2018-03-06 13:22:56 --> URI Class Initialized
INFO - 2018-03-06 13:22:56 --> Router Class Initialized
INFO - 2018-03-06 13:22:56 --> Output Class Initialized
INFO - 2018-03-06 13:22:56 --> Security Class Initialized
DEBUG - 2018-03-06 13:22:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-06 13:22:56 --> Input Class Initialized
INFO - 2018-03-06 13:22:56 --> Language Class Initialized
INFO - 2018-03-06 13:22:56 --> Loader Class Initialized
INFO - 2018-03-06 13:22:56 --> Helper loaded: url_helper
INFO - 2018-03-06 13:22:56 --> Helper loaded: file_helper
INFO - 2018-03-06 13:22:56 --> Helper loaded: email_helper
INFO - 2018-03-06 13:22:56 --> Helper loaded: common_helper
INFO - 2018-03-06 13:22:56 --> Database Driver Class Initialized
DEBUG - 2018-03-06 13:22:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-06 13:22:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-06 13:22:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-03-06 13:22:56 --> Pagination Class Initialized
INFO - 2018-03-06 13:22:56 --> Helper loaded: form_helper
INFO - 2018-03-06 13:22:56 --> Form Validation Class Initialized
INFO - 2018-03-06 13:22:56 --> Model Class Initialized
INFO - 2018-03-06 13:22:56 --> Controller Class Initialized
INFO - 2018-03-06 13:22:56 --> Language file loaded: language/english/english_lang.php
INFO - 2018-03-06 13:22:56 --> Model Class Initialized
INFO - 2018-03-06 13:22:56 --> Model Class Initialized
INFO - 2018-03-06 13:22:56 --> File loaded: /var/www/html/project/periodtracker/application/views//template/side_bar.php
INFO - 2018-03-06 13:22:56 --> File loaded: /var/www/html/project/periodtracker/application/views//template/header.php
INFO - 2018-03-06 13:22:56 --> File loaded: /var/www/html/project/periodtracker/application/views//template/bread_crumb.php
INFO - 2018-03-06 13:22:56 --> File loaded: /var/www/html/project/periodtracker/application/views//template/footer.php
INFO - 2018-03-06 13:22:56 --> File loaded: /var/www/html/project/periodtracker/application/views/thermometersubscription/index.php
INFO - 2018-03-06 13:22:56 --> Final output sent to browser
DEBUG - 2018-03-06 13:22:56 --> Total execution time: 0.0060
INFO - 2018-03-06 13:24:06 --> Config Class Initialized
INFO - 2018-03-06 13:24:06 --> Hooks Class Initialized
DEBUG - 2018-03-06 13:24:06 --> UTF-8 Support Enabled
INFO - 2018-03-06 13:24:06 --> Utf8 Class Initialized
INFO - 2018-03-06 13:24:06 --> URI Class Initialized
INFO - 2018-03-06 13:24:06 --> Router Class Initialized
INFO - 2018-03-06 13:24:06 --> Output Class Initialized
INFO - 2018-03-06 13:24:06 --> Security Class Initialized
DEBUG - 2018-03-06 13:24:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-06 13:24:06 --> Input Class Initialized
INFO - 2018-03-06 13:24:06 --> Language Class Initialized
INFO - 2018-03-06 13:24:06 --> Loader Class Initialized
INFO - 2018-03-06 13:24:06 --> Helper loaded: url_helper
INFO - 2018-03-06 13:24:06 --> Helper loaded: file_helper
INFO - 2018-03-06 13:24:06 --> Helper loaded: email_helper
INFO - 2018-03-06 13:24:06 --> Helper loaded: common_helper
INFO - 2018-03-06 13:24:06 --> Database Driver Class Initialized
DEBUG - 2018-03-06 13:24:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-06 13:24:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-06 13:24:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-03-06 13:24:06 --> Pagination Class Initialized
INFO - 2018-03-06 13:24:06 --> Helper loaded: form_helper
INFO - 2018-03-06 13:24:06 --> Form Validation Class Initialized
INFO - 2018-03-06 13:24:06 --> Model Class Initialized
INFO - 2018-03-06 13:24:06 --> Controller Class Initialized
INFO - 2018-03-06 13:24:06 --> Language file loaded: language/english/english_lang.php
INFO - 2018-03-06 13:24:06 --> Model Class Initialized
INFO - 2018-03-06 13:24:06 --> Model Class Initialized
INFO - 2018-03-06 13:24:06 --> File loaded: /var/www/html/project/periodtracker/application/views//template/side_bar.php
INFO - 2018-03-06 13:24:06 --> File loaded: /var/www/html/project/periodtracker/application/views//template/header.php
INFO - 2018-03-06 13:24:06 --> File loaded: /var/www/html/project/periodtracker/application/views//template/bread_crumb.php
INFO - 2018-03-06 13:24:06 --> File loaded: /var/www/html/project/periodtracker/application/views//template/footer.php
INFO - 2018-03-06 13:24:06 --> File loaded: /var/www/html/project/periodtracker/application/views/thermometersubscription/index.php
INFO - 2018-03-06 13:24:06 --> Final output sent to browser
DEBUG - 2018-03-06 13:24:06 --> Total execution time: 0.0071
INFO - 2018-03-06 13:24:24 --> Config Class Initialized
INFO - 2018-03-06 13:24:24 --> Hooks Class Initialized
DEBUG - 2018-03-06 13:24:24 --> UTF-8 Support Enabled
INFO - 2018-03-06 13:24:24 --> Utf8 Class Initialized
INFO - 2018-03-06 13:24:24 --> URI Class Initialized
INFO - 2018-03-06 13:24:24 --> Router Class Initialized
INFO - 2018-03-06 13:24:24 --> Output Class Initialized
INFO - 2018-03-06 13:24:24 --> Security Class Initialized
DEBUG - 2018-03-06 13:24:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-06 13:24:24 --> Input Class Initialized
INFO - 2018-03-06 13:24:24 --> Language Class Initialized
INFO - 2018-03-06 13:24:24 --> Loader Class Initialized
INFO - 2018-03-06 13:24:24 --> Helper loaded: url_helper
INFO - 2018-03-06 13:24:24 --> Helper loaded: file_helper
INFO - 2018-03-06 13:24:24 --> Helper loaded: email_helper
INFO - 2018-03-06 13:24:24 --> Helper loaded: common_helper
INFO - 2018-03-06 13:24:24 --> Database Driver Class Initialized
DEBUG - 2018-03-06 13:24:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-06 13:24:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-06 13:24:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-03-06 13:24:24 --> Pagination Class Initialized
INFO - 2018-03-06 13:24:24 --> Helper loaded: form_helper
INFO - 2018-03-06 13:24:24 --> Form Validation Class Initialized
INFO - 2018-03-06 13:24:24 --> Model Class Initialized
INFO - 2018-03-06 13:24:24 --> Controller Class Initialized
INFO - 2018-03-06 13:24:24 --> Language file loaded: language/english/english_lang.php
INFO - 2018-03-06 13:24:24 --> Model Class Initialized
INFO - 2018-03-06 13:24:24 --> Model Class Initialized
INFO - 2018-03-06 13:24:24 --> File loaded: /var/www/html/project/periodtracker/application/views//template/side_bar.php
INFO - 2018-03-06 13:24:24 --> File loaded: /var/www/html/project/periodtracker/application/views//template/header.php
INFO - 2018-03-06 13:24:24 --> File loaded: /var/www/html/project/periodtracker/application/views//template/bread_crumb.php
INFO - 2018-03-06 13:24:24 --> File loaded: /var/www/html/project/periodtracker/application/views//template/footer.php
INFO - 2018-03-06 13:24:24 --> File loaded: /var/www/html/project/periodtracker/application/views/thermometersubscription/index.php
INFO - 2018-03-06 13:24:24 --> Final output sent to browser
DEBUG - 2018-03-06 13:24:24 --> Total execution time: 0.0059
INFO - 2018-03-06 14:32:56 --> Config Class Initialized
INFO - 2018-03-06 14:32:56 --> Hooks Class Initialized
DEBUG - 2018-03-06 14:32:56 --> UTF-8 Support Enabled
INFO - 2018-03-06 14:32:56 --> Utf8 Class Initialized
INFO - 2018-03-06 14:32:56 --> URI Class Initialized
INFO - 2018-03-06 14:32:56 --> Router Class Initialized
INFO - 2018-03-06 14:32:56 --> Output Class Initialized
INFO - 2018-03-06 14:32:56 --> Security Class Initialized
DEBUG - 2018-03-06 14:32:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-06 14:32:56 --> Input Class Initialized
INFO - 2018-03-06 14:32:56 --> Language Class Initialized
INFO - 2018-03-06 14:32:56 --> Loader Class Initialized
INFO - 2018-03-06 14:32:56 --> Helper loaded: url_helper
INFO - 2018-03-06 14:32:56 --> Helper loaded: file_helper
INFO - 2018-03-06 14:32:56 --> Helper loaded: email_helper
INFO - 2018-03-06 14:32:56 --> Helper loaded: common_helper
INFO - 2018-03-06 14:32:56 --> Database Driver Class Initialized
DEBUG - 2018-03-06 14:32:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-06 14:32:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-06 14:32:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-03-06 14:32:56 --> Pagination Class Initialized
INFO - 2018-03-06 14:32:56 --> Helper loaded: form_helper
INFO - 2018-03-06 14:32:56 --> Form Validation Class Initialized
INFO - 2018-03-06 14:32:56 --> Model Class Initialized
INFO - 2018-03-06 14:32:56 --> Controller Class Initialized
INFO - 2018-03-06 14:32:56 --> Language file loaded: language/english/english_lang.php
INFO - 2018-03-06 14:32:56 --> Model Class Initialized
INFO - 2018-03-06 14:32:56 --> Model Class Initialized
INFO - 2018-03-06 14:32:56 --> File loaded: /var/www/html/project/periodtracker/application/views//template/side_bar.php
INFO - 2018-03-06 14:32:56 --> File loaded: /var/www/html/project/periodtracker/application/views//template/header.php
INFO - 2018-03-06 14:32:56 --> File loaded: /var/www/html/project/periodtracker/application/views//template/bread_crumb.php
INFO - 2018-03-06 14:32:56 --> File loaded: /var/www/html/project/periodtracker/application/views//template/footer.php
INFO - 2018-03-06 14:32:56 --> File loaded: /var/www/html/project/periodtracker/application/views/thermometersubscription/sendGift.php
INFO - 2018-03-06 14:32:56 --> Final output sent to browser
DEBUG - 2018-03-06 14:32:56 --> Total execution time: 0.0073
INFO - 2018-03-06 14:39:37 --> Config Class Initialized
INFO - 2018-03-06 14:39:37 --> Hooks Class Initialized
DEBUG - 2018-03-06 14:39:37 --> UTF-8 Support Enabled
INFO - 2018-03-06 14:39:37 --> Utf8 Class Initialized
INFO - 2018-03-06 14:39:37 --> URI Class Initialized
INFO - 2018-03-06 14:39:37 --> Router Class Initialized
INFO - 2018-03-06 14:39:37 --> Output Class Initialized
INFO - 2018-03-06 14:39:37 --> Security Class Initialized
DEBUG - 2018-03-06 14:39:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-06 14:39:37 --> Input Class Initialized
INFO - 2018-03-06 14:39:37 --> Language Class Initialized
INFO - 2018-03-06 14:39:37 --> Loader Class Initialized
INFO - 2018-03-06 14:39:37 --> Helper loaded: url_helper
INFO - 2018-03-06 14:39:37 --> Helper loaded: file_helper
INFO - 2018-03-06 14:39:37 --> Helper loaded: email_helper
INFO - 2018-03-06 14:39:37 --> Helper loaded: common_helper
INFO - 2018-03-06 14:39:37 --> Database Driver Class Initialized
DEBUG - 2018-03-06 14:39:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-06 14:39:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-06 14:39:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-03-06 14:39:37 --> Pagination Class Initialized
INFO - 2018-03-06 14:39:37 --> Helper loaded: form_helper
INFO - 2018-03-06 14:39:37 --> Form Validation Class Initialized
INFO - 2018-03-06 14:39:37 --> Model Class Initialized
INFO - 2018-03-06 14:39:37 --> Controller Class Initialized
INFO - 2018-03-06 14:39:37 --> Language file loaded: language/english/english_lang.php
INFO - 2018-03-06 14:39:37 --> Model Class Initialized
INFO - 2018-03-06 14:39:37 --> Model Class Initialized
INFO - 2018-03-06 14:39:37 --> File loaded: /var/www/html/project/periodtracker/application/views//template/side_bar.php
INFO - 2018-03-06 14:39:37 --> File loaded: /var/www/html/project/periodtracker/application/views//template/header.php
INFO - 2018-03-06 14:39:37 --> File loaded: /var/www/html/project/periodtracker/application/views//template/bread_crumb.php
INFO - 2018-03-06 14:39:37 --> File loaded: /var/www/html/project/periodtracker/application/views//template/footer.php
INFO - 2018-03-06 14:39:37 --> File loaded: /var/www/html/project/periodtracker/application/views/thermometersubscription/sendGift.php
INFO - 2018-03-06 14:39:37 --> Final output sent to browser
DEBUG - 2018-03-06 14:39:37 --> Total execution time: 0.0117
INFO - 2018-03-06 14:39:53 --> Config Class Initialized
INFO - 2018-03-06 14:39:53 --> Hooks Class Initialized
DEBUG - 2018-03-06 14:39:53 --> UTF-8 Support Enabled
INFO - 2018-03-06 14:39:53 --> Utf8 Class Initialized
INFO - 2018-03-06 14:39:53 --> URI Class Initialized
INFO - 2018-03-06 14:39:53 --> Router Class Initialized
INFO - 2018-03-06 14:39:53 --> Output Class Initialized
INFO - 2018-03-06 14:39:53 --> Security Class Initialized
DEBUG - 2018-03-06 14:39:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-06 14:39:53 --> Input Class Initialized
INFO - 2018-03-06 14:39:53 --> Language Class Initialized
INFO - 2018-03-06 14:39:53 --> Loader Class Initialized
INFO - 2018-03-06 14:39:53 --> Helper loaded: url_helper
INFO - 2018-03-06 14:39:53 --> Helper loaded: file_helper
INFO - 2018-03-06 14:39:53 --> Helper loaded: email_helper
INFO - 2018-03-06 14:39:53 --> Helper loaded: common_helper
INFO - 2018-03-06 14:39:53 --> Database Driver Class Initialized
DEBUG - 2018-03-06 14:39:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-06 14:39:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-06 14:39:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-03-06 14:39:53 --> Pagination Class Initialized
INFO - 2018-03-06 14:39:53 --> Helper loaded: form_helper
INFO - 2018-03-06 14:39:53 --> Form Validation Class Initialized
INFO - 2018-03-06 14:39:53 --> Model Class Initialized
INFO - 2018-03-06 14:39:53 --> Controller Class Initialized
INFO - 2018-03-06 14:39:53 --> Language file loaded: language/english/english_lang.php
INFO - 2018-03-06 14:39:53 --> Model Class Initialized
INFO - 2018-03-06 14:39:53 --> Model Class Initialized
INFO - 2018-03-06 14:39:53 --> File loaded: /var/www/html/project/periodtracker/application/views//template/side_bar.php
INFO - 2018-03-06 14:39:53 --> File loaded: /var/www/html/project/periodtracker/application/views//template/header.php
INFO - 2018-03-06 14:39:53 --> File loaded: /var/www/html/project/periodtracker/application/views//template/bread_crumb.php
INFO - 2018-03-06 14:39:53 --> File loaded: /var/www/html/project/periodtracker/application/views//template/footer.php
INFO - 2018-03-06 14:39:53 --> File loaded: /var/www/html/project/periodtracker/application/views/thermometersubscription/sendGift.php
INFO - 2018-03-06 14:39:53 --> Final output sent to browser
DEBUG - 2018-03-06 14:39:53 --> Total execution time: 0.0057
INFO - 2018-03-06 14:40:22 --> Config Class Initialized
INFO - 2018-03-06 14:40:22 --> Hooks Class Initialized
DEBUG - 2018-03-06 14:40:22 --> UTF-8 Support Enabled
INFO - 2018-03-06 14:40:22 --> Utf8 Class Initialized
INFO - 2018-03-06 14:40:22 --> URI Class Initialized
INFO - 2018-03-06 14:40:22 --> Router Class Initialized
INFO - 2018-03-06 14:40:22 --> Output Class Initialized
INFO - 2018-03-06 14:40:22 --> Security Class Initialized
DEBUG - 2018-03-06 14:40:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-06 14:40:22 --> Input Class Initialized
INFO - 2018-03-06 14:40:22 --> Language Class Initialized
INFO - 2018-03-06 14:40:22 --> Loader Class Initialized
INFO - 2018-03-06 14:40:22 --> Helper loaded: url_helper
INFO - 2018-03-06 14:40:22 --> Helper loaded: file_helper
INFO - 2018-03-06 14:40:22 --> Helper loaded: email_helper
INFO - 2018-03-06 14:40:22 --> Helper loaded: common_helper
INFO - 2018-03-06 14:40:22 --> Database Driver Class Initialized
DEBUG - 2018-03-06 14:40:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-06 14:40:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-06 14:40:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-03-06 14:40:22 --> Pagination Class Initialized
INFO - 2018-03-06 14:40:22 --> Helper loaded: form_helper
INFO - 2018-03-06 14:40:22 --> Form Validation Class Initialized
INFO - 2018-03-06 14:40:22 --> Model Class Initialized
INFO - 2018-03-06 14:40:22 --> Controller Class Initialized
INFO - 2018-03-06 14:40:22 --> Language file loaded: language/english/english_lang.php
INFO - 2018-03-06 14:40:22 --> Model Class Initialized
INFO - 2018-03-06 14:40:22 --> Model Class Initialized
INFO - 2018-03-06 14:40:22 --> File loaded: /var/www/html/project/periodtracker/application/views//template/side_bar.php
INFO - 2018-03-06 14:40:22 --> File loaded: /var/www/html/project/periodtracker/application/views//template/header.php
INFO - 2018-03-06 14:40:22 --> File loaded: /var/www/html/project/periodtracker/application/views//template/bread_crumb.php
INFO - 2018-03-06 14:40:22 --> File loaded: /var/www/html/project/periodtracker/application/views//template/footer.php
INFO - 2018-03-06 14:40:22 --> File loaded: /var/www/html/project/periodtracker/application/views/thermometersubscription/sendGift.php
INFO - 2018-03-06 14:40:22 --> Final output sent to browser
DEBUG - 2018-03-06 14:40:22 --> Total execution time: 0.0074
INFO - 2018-03-06 14:40:26 --> Config Class Initialized
INFO - 2018-03-06 14:40:26 --> Hooks Class Initialized
DEBUG - 2018-03-06 14:40:26 --> UTF-8 Support Enabled
INFO - 2018-03-06 14:40:26 --> Utf8 Class Initialized
INFO - 2018-03-06 14:40:26 --> URI Class Initialized
INFO - 2018-03-06 14:40:26 --> Router Class Initialized
INFO - 2018-03-06 14:40:26 --> Output Class Initialized
INFO - 2018-03-06 14:40:26 --> Security Class Initialized
DEBUG - 2018-03-06 14:40:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-06 14:40:26 --> Input Class Initialized
INFO - 2018-03-06 14:40:26 --> Language Class Initialized
INFO - 2018-03-06 14:40:26 --> Loader Class Initialized
INFO - 2018-03-06 14:40:26 --> Helper loaded: url_helper
INFO - 2018-03-06 14:40:26 --> Helper loaded: file_helper
INFO - 2018-03-06 14:40:26 --> Helper loaded: email_helper
INFO - 2018-03-06 14:40:26 --> Helper loaded: common_helper
INFO - 2018-03-06 14:40:26 --> Database Driver Class Initialized
DEBUG - 2018-03-06 14:40:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-06 14:40:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-06 14:40:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-03-06 14:40:26 --> Pagination Class Initialized
INFO - 2018-03-06 14:40:26 --> Helper loaded: form_helper
INFO - 2018-03-06 14:40:26 --> Form Validation Class Initialized
INFO - 2018-03-06 14:40:26 --> Model Class Initialized
INFO - 2018-03-06 14:40:26 --> Controller Class Initialized
INFO - 2018-03-06 14:40:26 --> Language file loaded: language/english/english_lang.php
INFO - 2018-03-06 14:40:26 --> Model Class Initialized
INFO - 2018-03-06 14:40:26 --> Model Class Initialized
INFO - 2018-03-06 14:40:26 --> File loaded: /var/www/html/project/periodtracker/application/views//template/side_bar.php
INFO - 2018-03-06 14:40:26 --> File loaded: /var/www/html/project/periodtracker/application/views//template/header.php
INFO - 2018-03-06 14:40:26 --> File loaded: /var/www/html/project/periodtracker/application/views//template/bread_crumb.php
INFO - 2018-03-06 14:40:26 --> File loaded: /var/www/html/project/periodtracker/application/views//template/footer.php
INFO - 2018-03-06 14:40:26 --> File loaded: /var/www/html/project/periodtracker/application/views/thermometersubscription/sendGift.php
INFO - 2018-03-06 14:40:26 --> Final output sent to browser
DEBUG - 2018-03-06 14:40:26 --> Total execution time: 0.0108
INFO - 2018-03-06 14:40:57 --> Config Class Initialized
INFO - 2018-03-06 14:40:57 --> Hooks Class Initialized
DEBUG - 2018-03-06 14:40:57 --> UTF-8 Support Enabled
INFO - 2018-03-06 14:40:57 --> Utf8 Class Initialized
INFO - 2018-03-06 14:40:57 --> URI Class Initialized
INFO - 2018-03-06 14:40:57 --> Router Class Initialized
INFO - 2018-03-06 14:40:57 --> Output Class Initialized
INFO - 2018-03-06 14:40:57 --> Security Class Initialized
DEBUG - 2018-03-06 14:40:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-06 14:40:57 --> Input Class Initialized
INFO - 2018-03-06 14:40:57 --> Language Class Initialized
INFO - 2018-03-06 14:40:57 --> Loader Class Initialized
INFO - 2018-03-06 14:40:57 --> Helper loaded: url_helper
INFO - 2018-03-06 14:40:57 --> Helper loaded: file_helper
INFO - 2018-03-06 14:40:57 --> Helper loaded: email_helper
INFO - 2018-03-06 14:40:57 --> Helper loaded: common_helper
INFO - 2018-03-06 14:40:57 --> Database Driver Class Initialized
DEBUG - 2018-03-06 14:40:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-06 14:40:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-06 14:40:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-03-06 14:40:57 --> Pagination Class Initialized
INFO - 2018-03-06 14:40:57 --> Helper loaded: form_helper
INFO - 2018-03-06 14:40:57 --> Form Validation Class Initialized
INFO - 2018-03-06 14:40:57 --> Model Class Initialized
INFO - 2018-03-06 14:40:57 --> Controller Class Initialized
INFO - 2018-03-06 14:40:57 --> Language file loaded: language/english/english_lang.php
INFO - 2018-03-06 14:40:57 --> Model Class Initialized
INFO - 2018-03-06 14:40:57 --> Model Class Initialized
INFO - 2018-03-06 14:40:57 --> File loaded: /var/www/html/project/periodtracker/application/views//template/side_bar.php
INFO - 2018-03-06 14:40:57 --> File loaded: /var/www/html/project/periodtracker/application/views//template/header.php
INFO - 2018-03-06 14:40:57 --> File loaded: /var/www/html/project/periodtracker/application/views//template/bread_crumb.php
INFO - 2018-03-06 14:40:57 --> File loaded: /var/www/html/project/periodtracker/application/views//template/footer.php
INFO - 2018-03-06 14:40:57 --> File loaded: /var/www/html/project/periodtracker/application/views/thermometersubscription/sendGift.php
INFO - 2018-03-06 14:40:57 --> Final output sent to browser
DEBUG - 2018-03-06 14:40:57 --> Total execution time: 0.0078
INFO - 2018-03-06 14:43:33 --> Config Class Initialized
INFO - 2018-03-06 14:43:33 --> Hooks Class Initialized
DEBUG - 2018-03-06 14:43:33 --> UTF-8 Support Enabled
INFO - 2018-03-06 14:43:33 --> Utf8 Class Initialized
INFO - 2018-03-06 14:43:33 --> URI Class Initialized
INFO - 2018-03-06 14:43:33 --> Router Class Initialized
INFO - 2018-03-06 14:43:33 --> Output Class Initialized
INFO - 2018-03-06 14:43:33 --> Security Class Initialized
DEBUG - 2018-03-06 14:43:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-06 14:43:33 --> Input Class Initialized
INFO - 2018-03-06 14:43:33 --> Language Class Initialized
INFO - 2018-03-06 14:43:33 --> Loader Class Initialized
INFO - 2018-03-06 14:43:33 --> Helper loaded: url_helper
INFO - 2018-03-06 14:43:33 --> Helper loaded: file_helper
INFO - 2018-03-06 14:43:33 --> Helper loaded: email_helper
INFO - 2018-03-06 14:43:33 --> Helper loaded: common_helper
INFO - 2018-03-06 14:43:33 --> Database Driver Class Initialized
DEBUG - 2018-03-06 14:43:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-06 14:43:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-06 14:43:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-03-06 14:43:33 --> Pagination Class Initialized
INFO - 2018-03-06 14:43:33 --> Helper loaded: form_helper
INFO - 2018-03-06 14:43:33 --> Form Validation Class Initialized
INFO - 2018-03-06 14:43:33 --> Model Class Initialized
INFO - 2018-03-06 14:43:33 --> Controller Class Initialized
INFO - 2018-03-06 14:43:33 --> Language file loaded: language/english/english_lang.php
INFO - 2018-03-06 14:43:33 --> Model Class Initialized
INFO - 2018-03-06 14:43:33 --> Model Class Initialized
INFO - 2018-03-06 14:43:33 --> File loaded: /var/www/html/project/periodtracker/application/views//template/side_bar.php
INFO - 2018-03-06 14:43:33 --> File loaded: /var/www/html/project/periodtracker/application/views//template/header.php
INFO - 2018-03-06 14:43:33 --> File loaded: /var/www/html/project/periodtracker/application/views//template/bread_crumb.php
INFO - 2018-03-06 14:43:33 --> File loaded: /var/www/html/project/periodtracker/application/views//template/footer.php
INFO - 2018-03-06 14:43:33 --> File loaded: /var/www/html/project/periodtracker/application/views/thermometersubscription/sendGift.php
INFO - 2018-03-06 14:43:33 --> Final output sent to browser
DEBUG - 2018-03-06 14:43:33 --> Total execution time: 0.0079
INFO - 2018-03-06 14:43:57 --> Config Class Initialized
INFO - 2018-03-06 14:43:57 --> Hooks Class Initialized
DEBUG - 2018-03-06 14:43:57 --> UTF-8 Support Enabled
INFO - 2018-03-06 14:43:57 --> Utf8 Class Initialized
INFO - 2018-03-06 14:43:57 --> URI Class Initialized
INFO - 2018-03-06 14:43:57 --> Router Class Initialized
INFO - 2018-03-06 14:43:57 --> Output Class Initialized
INFO - 2018-03-06 14:43:57 --> Security Class Initialized
DEBUG - 2018-03-06 14:43:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-06 14:43:57 --> Input Class Initialized
INFO - 2018-03-06 14:43:57 --> Language Class Initialized
INFO - 2018-03-06 14:43:57 --> Loader Class Initialized
INFO - 2018-03-06 14:43:57 --> Helper loaded: url_helper
INFO - 2018-03-06 14:43:57 --> Helper loaded: file_helper
INFO - 2018-03-06 14:43:57 --> Helper loaded: email_helper
INFO - 2018-03-06 14:43:57 --> Helper loaded: common_helper
INFO - 2018-03-06 14:43:57 --> Database Driver Class Initialized
DEBUG - 2018-03-06 14:43:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-06 14:43:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-06 14:43:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-03-06 14:43:57 --> Pagination Class Initialized
INFO - 2018-03-06 14:43:57 --> Helper loaded: form_helper
INFO - 2018-03-06 14:43:57 --> Form Validation Class Initialized
INFO - 2018-03-06 14:43:57 --> Model Class Initialized
INFO - 2018-03-06 14:43:57 --> Controller Class Initialized
INFO - 2018-03-06 14:43:57 --> Language file loaded: language/english/english_lang.php
INFO - 2018-03-06 14:43:57 --> Model Class Initialized
INFO - 2018-03-06 14:43:57 --> Model Class Initialized
INFO - 2018-03-06 14:43:57 --> File loaded: /var/www/html/project/periodtracker/application/views//template/side_bar.php
INFO - 2018-03-06 14:43:57 --> File loaded: /var/www/html/project/periodtracker/application/views//template/header.php
INFO - 2018-03-06 14:43:57 --> File loaded: /var/www/html/project/periodtracker/application/views//template/bread_crumb.php
INFO - 2018-03-06 14:43:57 --> File loaded: /var/www/html/project/periodtracker/application/views//template/footer.php
INFO - 2018-03-06 14:43:57 --> File loaded: /var/www/html/project/periodtracker/application/views/thermometersubscription/sendGift.php
INFO - 2018-03-06 14:43:57 --> Final output sent to browser
DEBUG - 2018-03-06 14:43:57 --> Total execution time: 0.0107
INFO - 2018-03-06 14:49:43 --> Config Class Initialized
INFO - 2018-03-06 14:49:43 --> Hooks Class Initialized
DEBUG - 2018-03-06 14:49:43 --> UTF-8 Support Enabled
INFO - 2018-03-06 14:49:43 --> Utf8 Class Initialized
INFO - 2018-03-06 14:49:43 --> URI Class Initialized
INFO - 2018-03-06 14:49:43 --> Router Class Initialized
INFO - 2018-03-06 14:49:43 --> Output Class Initialized
INFO - 2018-03-06 14:49:43 --> Security Class Initialized
DEBUG - 2018-03-06 14:49:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-06 14:49:43 --> Input Class Initialized
INFO - 2018-03-06 14:49:43 --> Language Class Initialized
INFO - 2018-03-06 14:49:43 --> Loader Class Initialized
INFO - 2018-03-06 14:49:43 --> Helper loaded: url_helper
INFO - 2018-03-06 14:49:43 --> Helper loaded: file_helper
INFO - 2018-03-06 14:49:43 --> Helper loaded: email_helper
INFO - 2018-03-06 14:49:43 --> Helper loaded: common_helper
INFO - 2018-03-06 14:49:43 --> Database Driver Class Initialized
DEBUG - 2018-03-06 14:49:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-06 14:49:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-06 14:49:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-03-06 14:49:43 --> Pagination Class Initialized
INFO - 2018-03-06 14:49:43 --> Helper loaded: form_helper
INFO - 2018-03-06 14:49:43 --> Form Validation Class Initialized
INFO - 2018-03-06 14:49:43 --> Model Class Initialized
INFO - 2018-03-06 14:49:43 --> Controller Class Initialized
INFO - 2018-03-06 14:49:43 --> Language file loaded: language/english/english_lang.php
INFO - 2018-03-06 14:49:43 --> Model Class Initialized
INFO - 2018-03-06 14:49:43 --> Model Class Initialized
INFO - 2018-03-06 14:49:43 --> File loaded: /var/www/html/project/periodtracker/application/views//template/side_bar.php
INFO - 2018-03-06 14:49:43 --> File loaded: /var/www/html/project/periodtracker/application/views//template/header.php
INFO - 2018-03-06 14:49:43 --> File loaded: /var/www/html/project/periodtracker/application/views//template/bread_crumb.php
INFO - 2018-03-06 14:49:43 --> File loaded: /var/www/html/project/periodtracker/application/views//template/footer.php
INFO - 2018-03-06 14:49:43 --> File loaded: /var/www/html/project/periodtracker/application/views/thermometersubscription/sendGift.php
INFO - 2018-03-06 14:49:43 --> Final output sent to browser
DEBUG - 2018-03-06 14:49:43 --> Total execution time: 0.0087
INFO - 2018-03-06 14:49:48 --> Config Class Initialized
INFO - 2018-03-06 14:49:48 --> Hooks Class Initialized
DEBUG - 2018-03-06 14:49:48 --> UTF-8 Support Enabled
INFO - 2018-03-06 14:49:48 --> Utf8 Class Initialized
INFO - 2018-03-06 14:49:48 --> URI Class Initialized
INFO - 2018-03-06 14:49:48 --> Router Class Initialized
INFO - 2018-03-06 14:49:48 --> Output Class Initialized
INFO - 2018-03-06 14:49:48 --> Security Class Initialized
DEBUG - 2018-03-06 14:49:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-06 14:49:48 --> Input Class Initialized
INFO - 2018-03-06 14:49:48 --> Language Class Initialized
INFO - 2018-03-06 14:49:48 --> Loader Class Initialized
INFO - 2018-03-06 14:49:48 --> Helper loaded: url_helper
INFO - 2018-03-06 14:49:48 --> Helper loaded: file_helper
INFO - 2018-03-06 14:49:48 --> Helper loaded: email_helper
INFO - 2018-03-06 14:49:48 --> Helper loaded: common_helper
INFO - 2018-03-06 14:49:48 --> Database Driver Class Initialized
DEBUG - 2018-03-06 14:49:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-06 14:49:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-06 14:49:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-03-06 14:49:48 --> Pagination Class Initialized
INFO - 2018-03-06 14:49:48 --> Helper loaded: form_helper
INFO - 2018-03-06 14:49:48 --> Form Validation Class Initialized
INFO - 2018-03-06 14:49:48 --> Model Class Initialized
INFO - 2018-03-06 14:49:48 --> Controller Class Initialized
INFO - 2018-03-06 14:49:48 --> Language file loaded: language/english/english_lang.php
INFO - 2018-03-06 14:49:48 --> Model Class Initialized
INFO - 2018-03-06 14:49:48 --> Model Class Initialized
INFO - 2018-03-06 15:16:29 --> Config Class Initialized
INFO - 2018-03-06 15:16:29 --> Hooks Class Initialized
DEBUG - 2018-03-06 15:16:29 --> UTF-8 Support Enabled
INFO - 2018-03-06 15:16:29 --> Utf8 Class Initialized
INFO - 2018-03-06 15:16:29 --> URI Class Initialized
INFO - 2018-03-06 15:16:29 --> Router Class Initialized
INFO - 2018-03-06 15:16:29 --> Output Class Initialized
INFO - 2018-03-06 15:16:29 --> Security Class Initialized
DEBUG - 2018-03-06 15:16:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-06 15:16:29 --> Input Class Initialized
INFO - 2018-03-06 15:16:29 --> Language Class Initialized
INFO - 2018-03-06 15:16:29 --> Loader Class Initialized
INFO - 2018-03-06 15:16:29 --> Helper loaded: url_helper
INFO - 2018-03-06 15:16:29 --> Helper loaded: file_helper
INFO - 2018-03-06 15:16:29 --> Helper loaded: email_helper
INFO - 2018-03-06 15:16:29 --> Helper loaded: common_helper
INFO - 2018-03-06 15:16:29 --> Database Driver Class Initialized
DEBUG - 2018-03-06 15:16:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-06 15:16:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-06 15:16:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-03-06 15:16:29 --> Pagination Class Initialized
INFO - 2018-03-06 15:16:29 --> Helper loaded: form_helper
INFO - 2018-03-06 15:16:29 --> Form Validation Class Initialized
INFO - 2018-03-06 15:16:29 --> Model Class Initialized
INFO - 2018-03-06 15:16:29 --> Controller Class Initialized
INFO - 2018-03-06 15:16:29 --> Language file loaded: language/english/english_lang.php
INFO - 2018-03-06 15:16:29 --> Model Class Initialized
INFO - 2018-03-06 15:16:29 --> Model Class Initialized
INFO - 2018-03-06 15:16:29 --> File loaded: /var/www/html/project/periodtracker/application/views//template/side_bar.php
INFO - 2018-03-06 15:16:29 --> File loaded: /var/www/html/project/periodtracker/application/views//template/header.php
INFO - 2018-03-06 15:16:29 --> File loaded: /var/www/html/project/periodtracker/application/views//template/bread_crumb.php
INFO - 2018-03-06 15:16:29 --> File loaded: /var/www/html/project/periodtracker/application/views//template/footer.php
INFO - 2018-03-06 15:16:29 --> File loaded: /var/www/html/project/periodtracker/application/views/thermometersubscription/sendGift.php
INFO - 2018-03-06 15:16:29 --> Final output sent to browser
DEBUG - 2018-03-06 15:16:29 --> Total execution time: 0.0092
INFO - 2018-03-06 15:16:39 --> Config Class Initialized
INFO - 2018-03-06 15:16:39 --> Hooks Class Initialized
DEBUG - 2018-03-06 15:16:39 --> UTF-8 Support Enabled
INFO - 2018-03-06 15:16:39 --> Utf8 Class Initialized
INFO - 2018-03-06 15:16:39 --> URI Class Initialized
INFO - 2018-03-06 15:16:39 --> Router Class Initialized
INFO - 2018-03-06 15:16:39 --> Output Class Initialized
INFO - 2018-03-06 15:16:39 --> Security Class Initialized
DEBUG - 2018-03-06 15:16:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-06 15:16:39 --> Input Class Initialized
INFO - 2018-03-06 15:16:39 --> Language Class Initialized
INFO - 2018-03-06 15:16:39 --> Loader Class Initialized
INFO - 2018-03-06 15:16:39 --> Helper loaded: url_helper
INFO - 2018-03-06 15:16:39 --> Helper loaded: file_helper
INFO - 2018-03-06 15:16:39 --> Helper loaded: email_helper
INFO - 2018-03-06 15:16:39 --> Helper loaded: common_helper
INFO - 2018-03-06 15:16:39 --> Database Driver Class Initialized
DEBUG - 2018-03-06 15:16:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-06 15:16:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-06 15:16:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-03-06 15:16:39 --> Pagination Class Initialized
INFO - 2018-03-06 15:16:39 --> Helper loaded: form_helper
INFO - 2018-03-06 15:16:39 --> Form Validation Class Initialized
INFO - 2018-03-06 15:16:39 --> Model Class Initialized
INFO - 2018-03-06 15:16:39 --> Controller Class Initialized
INFO - 2018-03-06 15:16:39 --> Language file loaded: language/english/english_lang.php
INFO - 2018-03-06 15:16:39 --> Model Class Initialized
INFO - 2018-03-06 15:16:39 --> Model Class Initialized
DEBUG - 2018-03-06 15:16:39 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-06 15:16:39 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-03-06 15:16:39 --> Config Class Initialized
INFO - 2018-03-06 15:16:39 --> Hooks Class Initialized
DEBUG - 2018-03-06 15:16:39 --> UTF-8 Support Enabled
INFO - 2018-03-06 15:16:39 --> Utf8 Class Initialized
INFO - 2018-03-06 15:16:39 --> URI Class Initialized
INFO - 2018-03-06 15:16:39 --> Router Class Initialized
INFO - 2018-03-06 15:16:39 --> Output Class Initialized
INFO - 2018-03-06 15:16:39 --> Security Class Initialized
DEBUG - 2018-03-06 15:16:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-06 15:16:39 --> Input Class Initialized
INFO - 2018-03-06 15:16:39 --> Language Class Initialized
INFO - 2018-03-06 15:16:39 --> Loader Class Initialized
INFO - 2018-03-06 15:16:39 --> Helper loaded: url_helper
INFO - 2018-03-06 15:16:39 --> Helper loaded: file_helper
INFO - 2018-03-06 15:16:39 --> Helper loaded: email_helper
INFO - 2018-03-06 15:16:39 --> Helper loaded: common_helper
INFO - 2018-03-06 15:16:39 --> Database Driver Class Initialized
INFO - 2018-03-06 15:16:39 --> Config Class Initialized
DEBUG - 2018-03-06 15:16:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-06 15:16:39 --> Hooks Class Initialized
DEBUG - 2018-03-06 15:16:39 --> UTF-8 Support Enabled
INFO - 2018-03-06 15:16:39 --> Utf8 Class Initialized
INFO - 2018-03-06 15:16:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-06 15:16:39 --> URI Class Initialized
INFO - 2018-03-06 15:16:39 --> Router Class Initialized
INFO - 2018-03-06 15:16:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-03-06 15:16:39 --> Output Class Initialized
INFO - 2018-03-06 15:16:39 --> Pagination Class Initialized
INFO - 2018-03-06 15:16:39 --> Security Class Initialized
DEBUG - 2018-03-06 15:16:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-06 15:16:39 --> Input Class Initialized
INFO - 2018-03-06 15:16:39 --> Helper loaded: form_helper
INFO - 2018-03-06 15:16:39 --> Language Class Initialized
INFO - 2018-03-06 15:16:39 --> Form Validation Class Initialized
INFO - 2018-03-06 15:16:39 --> Loader Class Initialized
INFO - 2018-03-06 15:16:39 --> Model Class Initialized
INFO - 2018-03-06 15:16:39 --> Helper loaded: url_helper
INFO - 2018-03-06 15:16:39 --> Controller Class Initialized
INFO - 2018-03-06 15:16:39 --> Helper loaded: file_helper
INFO - 2018-03-06 15:16:39 --> Helper loaded: email_helper
INFO - 2018-03-06 15:16:39 --> Language file loaded: language/english/english_lang.php
INFO - 2018-03-06 15:16:39 --> Helper loaded: common_helper
INFO - 2018-03-06 15:16:39 --> Database Driver Class Initialized
DEBUG - 2018-03-06 15:16:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-06 15:16:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-06 15:16:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-03-06 15:16:39 --> Pagination Class Initialized
INFO - 2018-03-06 15:16:39 --> Helper loaded: form_helper
INFO - 2018-03-06 15:16:39 --> Form Validation Class Initialized
INFO - 2018-03-06 15:16:39 --> Model Class Initialized
INFO - 2018-03-06 15:16:39 --> Controller Class Initialized
INFO - 2018-03-06 15:16:39 --> Language file loaded: language/english/english_lang.php
INFO - 2018-03-06 15:16:39 --> Model Class Initialized
INFO - 2018-03-06 15:16:39 --> Model Class Initialized
INFO - 2018-03-06 15:16:39 --> File loaded: /var/www/html/project/periodtracker/application/views//template/side_bar.php
INFO - 2018-03-06 15:16:39 --> File loaded: /var/www/html/project/periodtracker/application/views//template/header.php
INFO - 2018-03-06 15:16:39 --> File loaded: /var/www/html/project/periodtracker/application/views//template/bread_crumb.php
INFO - 2018-03-06 15:16:39 --> File loaded: /var/www/html/project/periodtracker/application/views//template/footer.php
INFO - 2018-03-06 15:16:39 --> File loaded: /var/www/html/project/periodtracker/application/views/thermometersubscription/index.php
INFO - 2018-03-06 15:16:39 --> Final output sent to browser
DEBUG - 2018-03-06 15:16:39 --> Total execution time: 0.0037
INFO - 2018-03-06 15:17:44 --> Config Class Initialized
INFO - 2018-03-06 15:17:44 --> Hooks Class Initialized
DEBUG - 2018-03-06 15:17:44 --> UTF-8 Support Enabled
INFO - 2018-03-06 15:17:44 --> Utf8 Class Initialized
INFO - 2018-03-06 15:17:44 --> URI Class Initialized
INFO - 2018-03-06 15:17:44 --> Router Class Initialized
INFO - 2018-03-06 15:17:44 --> Output Class Initialized
INFO - 2018-03-06 15:17:44 --> Security Class Initialized
DEBUG - 2018-03-06 15:17:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-06 15:17:44 --> Input Class Initialized
INFO - 2018-03-06 15:17:44 --> Language Class Initialized
ERROR - 2018-03-06 15:17:44 --> Severity: error --> Exception: syntax error, unexpected 'exit' (T_EXIT), expecting ',' or ';' /var/www/html/project/periodtracker/application/controllers/Thermometersubscription.php 53
INFO - 2018-03-06 15:17:50 --> Config Class Initialized
INFO - 2018-03-06 15:17:50 --> Hooks Class Initialized
DEBUG - 2018-03-06 15:17:50 --> UTF-8 Support Enabled
INFO - 2018-03-06 15:17:50 --> Utf8 Class Initialized
INFO - 2018-03-06 15:17:50 --> URI Class Initialized
INFO - 2018-03-06 15:17:50 --> Router Class Initialized
INFO - 2018-03-06 15:17:50 --> Output Class Initialized
INFO - 2018-03-06 15:17:50 --> Security Class Initialized
DEBUG - 2018-03-06 15:17:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-06 15:17:50 --> Input Class Initialized
INFO - 2018-03-06 15:17:50 --> Language Class Initialized
INFO - 2018-03-06 15:17:50 --> Loader Class Initialized
INFO - 2018-03-06 15:17:50 --> Helper loaded: url_helper
INFO - 2018-03-06 15:17:50 --> Helper loaded: file_helper
INFO - 2018-03-06 15:17:50 --> Helper loaded: email_helper
INFO - 2018-03-06 15:17:50 --> Helper loaded: common_helper
INFO - 2018-03-06 15:17:50 --> Database Driver Class Initialized
DEBUG - 2018-03-06 15:17:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-06 15:17:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-06 15:17:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-03-06 15:17:50 --> Pagination Class Initialized
INFO - 2018-03-06 15:17:50 --> Helper loaded: form_helper
INFO - 2018-03-06 15:17:50 --> Form Validation Class Initialized
INFO - 2018-03-06 15:17:50 --> Model Class Initialized
INFO - 2018-03-06 15:17:50 --> Controller Class Initialized
INFO - 2018-03-06 15:17:50 --> Language file loaded: language/english/english_lang.php
INFO - 2018-03-06 15:17:50 --> Model Class Initialized
INFO - 2018-03-06 15:17:50 --> Model Class Initialized
INFO - 2018-03-06 15:17:50 --> File loaded: /var/www/html/project/periodtracker/application/views//template/side_bar.php
INFO - 2018-03-06 15:17:50 --> File loaded: /var/www/html/project/periodtracker/application/views//template/header.php
INFO - 2018-03-06 15:17:50 --> File loaded: /var/www/html/project/periodtracker/application/views//template/bread_crumb.php
INFO - 2018-03-06 15:17:50 --> File loaded: /var/www/html/project/periodtracker/application/views//template/footer.php
INFO - 2018-03-06 15:17:50 --> File loaded: /var/www/html/project/periodtracker/application/views/thermometersubscription/index.php
INFO - 2018-03-06 15:17:50 --> Final output sent to browser
DEBUG - 2018-03-06 15:17:50 --> Total execution time: 0.0077
INFO - 2018-03-06 15:17:52 --> Config Class Initialized
INFO - 2018-03-06 15:17:52 --> Hooks Class Initialized
DEBUG - 2018-03-06 15:17:52 --> UTF-8 Support Enabled
INFO - 2018-03-06 15:17:52 --> Utf8 Class Initialized
INFO - 2018-03-06 15:17:52 --> URI Class Initialized
INFO - 2018-03-06 15:17:52 --> Router Class Initialized
INFO - 2018-03-06 15:17:52 --> Output Class Initialized
INFO - 2018-03-06 15:17:52 --> Security Class Initialized
DEBUG - 2018-03-06 15:17:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-06 15:17:52 --> Input Class Initialized
INFO - 2018-03-06 15:17:52 --> Language Class Initialized
INFO - 2018-03-06 15:17:52 --> Loader Class Initialized
INFO - 2018-03-06 15:17:52 --> Helper loaded: url_helper
INFO - 2018-03-06 15:17:52 --> Helper loaded: file_helper
INFO - 2018-03-06 15:17:52 --> Helper loaded: email_helper
INFO - 2018-03-06 15:17:52 --> Helper loaded: common_helper
INFO - 2018-03-06 15:17:52 --> Database Driver Class Initialized
DEBUG - 2018-03-06 15:17:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-06 15:17:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-06 15:17:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-03-06 15:17:52 --> Pagination Class Initialized
INFO - 2018-03-06 15:17:52 --> Helper loaded: form_helper
INFO - 2018-03-06 15:17:52 --> Form Validation Class Initialized
INFO - 2018-03-06 15:17:52 --> Model Class Initialized
INFO - 2018-03-06 15:17:52 --> Controller Class Initialized
INFO - 2018-03-06 15:17:52 --> Language file loaded: language/english/english_lang.php
INFO - 2018-03-06 15:17:52 --> Model Class Initialized
INFO - 2018-03-06 15:17:52 --> Model Class Initialized
INFO - 2018-03-06 15:17:52 --> File loaded: /var/www/html/project/periodtracker/application/views//template/side_bar.php
INFO - 2018-03-06 15:17:52 --> File loaded: /var/www/html/project/periodtracker/application/views//template/header.php
INFO - 2018-03-06 15:17:52 --> File loaded: /var/www/html/project/periodtracker/application/views//template/bread_crumb.php
INFO - 2018-03-06 15:17:52 --> File loaded: /var/www/html/project/periodtracker/application/views//template/footer.php
INFO - 2018-03-06 15:17:52 --> File loaded: /var/www/html/project/periodtracker/application/views/thermometersubscription/sendGift.php
INFO - 2018-03-06 15:17:52 --> Final output sent to browser
DEBUG - 2018-03-06 15:17:52 --> Total execution time: 0.0056
INFO - 2018-03-06 15:17:59 --> Config Class Initialized
INFO - 2018-03-06 15:17:59 --> Hooks Class Initialized
DEBUG - 2018-03-06 15:17:59 --> UTF-8 Support Enabled
INFO - 2018-03-06 15:17:59 --> Utf8 Class Initialized
INFO - 2018-03-06 15:17:59 --> URI Class Initialized
INFO - 2018-03-06 15:17:59 --> Router Class Initialized
INFO - 2018-03-06 15:17:59 --> Output Class Initialized
INFO - 2018-03-06 15:17:59 --> Security Class Initialized
DEBUG - 2018-03-06 15:17:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-06 15:17:59 --> Input Class Initialized
INFO - 2018-03-06 15:17:59 --> Language Class Initialized
INFO - 2018-03-06 15:17:59 --> Loader Class Initialized
INFO - 2018-03-06 15:17:59 --> Helper loaded: url_helper
INFO - 2018-03-06 15:17:59 --> Helper loaded: file_helper
INFO - 2018-03-06 15:17:59 --> Helper loaded: email_helper
INFO - 2018-03-06 15:17:59 --> Helper loaded: common_helper
INFO - 2018-03-06 15:17:59 --> Database Driver Class Initialized
DEBUG - 2018-03-06 15:17:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-06 15:17:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-06 15:17:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-03-06 15:17:59 --> Pagination Class Initialized
INFO - 2018-03-06 15:17:59 --> Helper loaded: form_helper
INFO - 2018-03-06 15:17:59 --> Form Validation Class Initialized
INFO - 2018-03-06 15:17:59 --> Model Class Initialized
INFO - 2018-03-06 15:17:59 --> Controller Class Initialized
INFO - 2018-03-06 15:17:59 --> Language file loaded: language/english/english_lang.php
INFO - 2018-03-06 15:17:59 --> Model Class Initialized
INFO - 2018-03-06 15:17:59 --> Model Class Initialized
DEBUG - 2018-03-06 15:17:59 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-06 15:17:59 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-03-06 15:18:29 --> Config Class Initialized
INFO - 2018-03-06 15:18:29 --> Hooks Class Initialized
DEBUG - 2018-03-06 15:18:29 --> UTF-8 Support Enabled
INFO - 2018-03-06 15:18:29 --> Utf8 Class Initialized
INFO - 2018-03-06 15:18:29 --> URI Class Initialized
INFO - 2018-03-06 15:18:29 --> Router Class Initialized
INFO - 2018-03-06 15:18:29 --> Output Class Initialized
INFO - 2018-03-06 15:18:29 --> Security Class Initialized
DEBUG - 2018-03-06 15:18:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-06 15:18:29 --> Input Class Initialized
INFO - 2018-03-06 15:18:29 --> Language Class Initialized
INFO - 2018-03-06 15:18:29 --> Loader Class Initialized
INFO - 2018-03-06 15:18:29 --> Helper loaded: url_helper
INFO - 2018-03-06 15:18:29 --> Helper loaded: file_helper
INFO - 2018-03-06 15:18:29 --> Helper loaded: email_helper
INFO - 2018-03-06 15:18:29 --> Helper loaded: common_helper
INFO - 2018-03-06 15:18:29 --> Database Driver Class Initialized
DEBUG - 2018-03-06 15:18:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-06 15:18:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-06 15:18:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-03-06 15:18:29 --> Pagination Class Initialized
INFO - 2018-03-06 15:18:29 --> Helper loaded: form_helper
INFO - 2018-03-06 15:18:29 --> Form Validation Class Initialized
INFO - 2018-03-06 15:18:29 --> Model Class Initialized
INFO - 2018-03-06 15:18:29 --> Controller Class Initialized
INFO - 2018-03-06 15:18:29 --> Language file loaded: language/english/english_lang.php
INFO - 2018-03-06 15:18:29 --> Model Class Initialized
INFO - 2018-03-06 15:18:29 --> Model Class Initialized
ERROR - 2018-03-06 15:18:29 --> Severity: error --> Exception: Call to undefined method Thermometersubscription::get() /var/www/html/project/periodtracker/application/controllers/Thermometersubscription.php 99
INFO - 2018-03-06 15:19:15 --> Config Class Initialized
INFO - 2018-03-06 15:19:15 --> Hooks Class Initialized
DEBUG - 2018-03-06 15:19:15 --> UTF-8 Support Enabled
INFO - 2018-03-06 15:19:15 --> Utf8 Class Initialized
INFO - 2018-03-06 15:19:15 --> URI Class Initialized
INFO - 2018-03-06 15:19:15 --> Router Class Initialized
INFO - 2018-03-06 15:19:15 --> Output Class Initialized
INFO - 2018-03-06 15:19:15 --> Security Class Initialized
DEBUG - 2018-03-06 15:19:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-06 15:19:15 --> Input Class Initialized
INFO - 2018-03-06 15:19:15 --> Language Class Initialized
INFO - 2018-03-06 15:19:15 --> Loader Class Initialized
INFO - 2018-03-06 15:19:15 --> Helper loaded: url_helper
INFO - 2018-03-06 15:19:15 --> Helper loaded: file_helper
INFO - 2018-03-06 15:19:15 --> Helper loaded: email_helper
INFO - 2018-03-06 15:19:15 --> Helper loaded: common_helper
INFO - 2018-03-06 15:19:15 --> Database Driver Class Initialized
DEBUG - 2018-03-06 15:19:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-06 15:19:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-06 15:19:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-03-06 15:19:15 --> Pagination Class Initialized
INFO - 2018-03-06 15:19:15 --> Helper loaded: form_helper
INFO - 2018-03-06 15:19:15 --> Form Validation Class Initialized
INFO - 2018-03-06 15:19:15 --> Model Class Initialized
INFO - 2018-03-06 15:19:15 --> Controller Class Initialized
INFO - 2018-03-06 15:19:15 --> Language file loaded: language/english/english_lang.php
INFO - 2018-03-06 15:19:15 --> Model Class Initialized
INFO - 2018-03-06 15:19:15 --> Model Class Initialized
ERROR - 2018-03-06 15:19:15 --> Severity: Warning --> Missing argument 1 for Thermometersubscription::sendGiftMail(), called in /var/www/html/project/periodtracker/system/core/CodeIgniter.php on line 532 and defined /var/www/html/project/periodtracker/application/controllers/Thermometersubscription.php 93
ERROR - 2018-03-06 15:19:15 --> Severity: Notice --> Undefined variable: data /var/www/html/project/periodtracker/application/controllers/Thermometersubscription.php 101
INFO - 2018-03-06 15:19:56 --> Config Class Initialized
INFO - 2018-03-06 15:19:56 --> Hooks Class Initialized
DEBUG - 2018-03-06 15:19:56 --> UTF-8 Support Enabled
INFO - 2018-03-06 15:19:56 --> Utf8 Class Initialized
INFO - 2018-03-06 15:19:56 --> URI Class Initialized
INFO - 2018-03-06 15:19:56 --> Router Class Initialized
INFO - 2018-03-06 15:19:56 --> Output Class Initialized
INFO - 2018-03-06 15:19:56 --> Security Class Initialized
DEBUG - 2018-03-06 15:19:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-06 15:19:56 --> Input Class Initialized
INFO - 2018-03-06 15:19:56 --> Language Class Initialized
INFO - 2018-03-06 15:19:56 --> Loader Class Initialized
INFO - 2018-03-06 15:19:56 --> Helper loaded: url_helper
INFO - 2018-03-06 15:19:56 --> Helper loaded: file_helper
INFO - 2018-03-06 15:19:56 --> Helper loaded: email_helper
INFO - 2018-03-06 15:19:56 --> Helper loaded: common_helper
INFO - 2018-03-06 15:19:56 --> Database Driver Class Initialized
DEBUG - 2018-03-06 15:19:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-06 15:19:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-06 15:19:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-03-06 15:19:56 --> Pagination Class Initialized
INFO - 2018-03-06 15:19:56 --> Helper loaded: form_helper
INFO - 2018-03-06 15:19:56 --> Form Validation Class Initialized
INFO - 2018-03-06 15:19:56 --> Model Class Initialized
INFO - 2018-03-06 15:19:56 --> Controller Class Initialized
INFO - 2018-03-06 15:19:56 --> Language file loaded: language/english/english_lang.php
INFO - 2018-03-06 15:19:56 --> Model Class Initialized
INFO - 2018-03-06 15:19:56 --> Model Class Initialized
INFO - 2018-03-06 15:20:08 --> Config Class Initialized
INFO - 2018-03-06 15:20:08 --> Hooks Class Initialized
DEBUG - 2018-03-06 15:20:08 --> UTF-8 Support Enabled
INFO - 2018-03-06 15:20:08 --> Utf8 Class Initialized
INFO - 2018-03-06 15:20:08 --> URI Class Initialized
INFO - 2018-03-06 15:20:08 --> Router Class Initialized
INFO - 2018-03-06 15:20:08 --> Output Class Initialized
INFO - 2018-03-06 15:20:08 --> Security Class Initialized
DEBUG - 2018-03-06 15:20:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-06 15:20:08 --> Input Class Initialized
INFO - 2018-03-06 15:20:08 --> Language Class Initialized
INFO - 2018-03-06 15:20:08 --> Loader Class Initialized
INFO - 2018-03-06 15:20:08 --> Helper loaded: url_helper
INFO - 2018-03-06 15:20:08 --> Helper loaded: file_helper
INFO - 2018-03-06 15:20:08 --> Helper loaded: email_helper
INFO - 2018-03-06 15:20:08 --> Helper loaded: common_helper
INFO - 2018-03-06 15:20:08 --> Database Driver Class Initialized
DEBUG - 2018-03-06 15:20:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-06 15:20:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-06 15:20:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-03-06 15:20:08 --> Pagination Class Initialized
INFO - 2018-03-06 15:20:08 --> Helper loaded: form_helper
INFO - 2018-03-06 15:20:08 --> Form Validation Class Initialized
INFO - 2018-03-06 15:20:08 --> Model Class Initialized
INFO - 2018-03-06 15:20:08 --> Controller Class Initialized
INFO - 2018-03-06 15:20:08 --> Language file loaded: language/english/english_lang.php
INFO - 2018-03-06 15:20:08 --> Model Class Initialized
INFO - 2018-03-06 15:20:08 --> Model Class Initialized
INFO - 2018-03-06 15:25:41 --> Config Class Initialized
INFO - 2018-03-06 15:25:41 --> Hooks Class Initialized
DEBUG - 2018-03-06 15:25:41 --> UTF-8 Support Enabled
INFO - 2018-03-06 15:25:41 --> Utf8 Class Initialized
INFO - 2018-03-06 15:25:41 --> URI Class Initialized
INFO - 2018-03-06 15:25:41 --> Router Class Initialized
INFO - 2018-03-06 15:25:41 --> Output Class Initialized
INFO - 2018-03-06 15:25:41 --> Security Class Initialized
DEBUG - 2018-03-06 15:25:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-06 15:25:41 --> Input Class Initialized
INFO - 2018-03-06 15:25:41 --> Language Class Initialized
INFO - 2018-03-06 15:25:41 --> Loader Class Initialized
INFO - 2018-03-06 15:25:41 --> Helper loaded: url_helper
INFO - 2018-03-06 15:25:41 --> Helper loaded: file_helper
INFO - 2018-03-06 15:25:41 --> Helper loaded: email_helper
INFO - 2018-03-06 15:25:41 --> Helper loaded: common_helper
INFO - 2018-03-06 15:25:41 --> Database Driver Class Initialized
DEBUG - 2018-03-06 15:25:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-06 15:25:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-06 15:25:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-03-06 15:25:41 --> Pagination Class Initialized
INFO - 2018-03-06 15:25:41 --> Helper loaded: form_helper
INFO - 2018-03-06 15:25:41 --> Form Validation Class Initialized
INFO - 2018-03-06 15:25:41 --> Model Class Initialized
INFO - 2018-03-06 15:25:41 --> Controller Class Initialized
INFO - 2018-03-06 15:25:41 --> Language file loaded: language/english/english_lang.php
INFO - 2018-03-06 15:25:41 --> Model Class Initialized
INFO - 2018-03-06 15:25:41 --> Model Class Initialized
ERROR - 2018-03-06 15:25:41 --> Severity: error --> Exception: Call to undefined method Thermometersubscription::get() /var/www/html/project/periodtracker/application/controllers/Thermometersubscription.php 101
INFO - 2018-03-06 15:25:44 --> Config Class Initialized
INFO - 2018-03-06 15:25:44 --> Hooks Class Initialized
DEBUG - 2018-03-06 15:25:44 --> UTF-8 Support Enabled
INFO - 2018-03-06 15:25:44 --> Utf8 Class Initialized
INFO - 2018-03-06 15:25:44 --> URI Class Initialized
INFO - 2018-03-06 15:25:44 --> Router Class Initialized
INFO - 2018-03-06 15:25:44 --> Output Class Initialized
INFO - 2018-03-06 15:25:44 --> Security Class Initialized
DEBUG - 2018-03-06 15:25:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-06 15:25:44 --> Input Class Initialized
INFO - 2018-03-06 15:25:44 --> Language Class Initialized
INFO - 2018-03-06 15:25:44 --> Loader Class Initialized
INFO - 2018-03-06 15:25:44 --> Helper loaded: url_helper
INFO - 2018-03-06 15:25:44 --> Helper loaded: file_helper
INFO - 2018-03-06 15:25:44 --> Helper loaded: email_helper
INFO - 2018-03-06 15:25:44 --> Helper loaded: common_helper
INFO - 2018-03-06 15:25:44 --> Database Driver Class Initialized
DEBUG - 2018-03-06 15:25:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-06 15:25:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-06 15:25:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-03-06 15:25:44 --> Pagination Class Initialized
INFO - 2018-03-06 15:25:44 --> Helper loaded: form_helper
INFO - 2018-03-06 15:25:44 --> Form Validation Class Initialized
INFO - 2018-03-06 15:25:44 --> Model Class Initialized
INFO - 2018-03-06 15:25:44 --> Controller Class Initialized
INFO - 2018-03-06 15:25:44 --> Language file loaded: language/english/english_lang.php
INFO - 2018-03-06 15:25:44 --> Model Class Initialized
INFO - 2018-03-06 15:25:44 --> Model Class Initialized
INFO - 2018-03-06 15:26:04 --> Config Class Initialized
INFO - 2018-03-06 15:26:04 --> Hooks Class Initialized
DEBUG - 2018-03-06 15:26:04 --> UTF-8 Support Enabled
INFO - 2018-03-06 15:26:04 --> Utf8 Class Initialized
INFO - 2018-03-06 15:26:04 --> URI Class Initialized
INFO - 2018-03-06 15:26:04 --> Router Class Initialized
INFO - 2018-03-06 15:26:04 --> Output Class Initialized
INFO - 2018-03-06 15:26:04 --> Security Class Initialized
DEBUG - 2018-03-06 15:26:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-06 15:26:04 --> Input Class Initialized
INFO - 2018-03-06 15:26:04 --> Language Class Initialized
INFO - 2018-03-06 15:26:04 --> Loader Class Initialized
INFO - 2018-03-06 15:26:04 --> Helper loaded: url_helper
INFO - 2018-03-06 15:26:04 --> Helper loaded: file_helper
INFO - 2018-03-06 15:26:04 --> Helper loaded: email_helper
INFO - 2018-03-06 15:26:04 --> Helper loaded: common_helper
INFO - 2018-03-06 15:26:04 --> Database Driver Class Initialized
DEBUG - 2018-03-06 15:26:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-06 15:26:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-06 15:26:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-03-06 15:26:04 --> Pagination Class Initialized
INFO - 2018-03-06 15:26:04 --> Helper loaded: form_helper
INFO - 2018-03-06 15:26:04 --> Form Validation Class Initialized
INFO - 2018-03-06 15:26:04 --> Model Class Initialized
INFO - 2018-03-06 15:26:04 --> Controller Class Initialized
INFO - 2018-03-06 15:26:04 --> Language file loaded: language/english/english_lang.php
INFO - 2018-03-06 15:26:04 --> Model Class Initialized
INFO - 2018-03-06 15:26:04 --> Model Class Initialized
INFO - 2018-03-06 15:26:16 --> Config Class Initialized
INFO - 2018-03-06 15:26:16 --> Hooks Class Initialized
DEBUG - 2018-03-06 15:26:16 --> UTF-8 Support Enabled
INFO - 2018-03-06 15:26:16 --> Utf8 Class Initialized
INFO - 2018-03-06 15:26:16 --> URI Class Initialized
INFO - 2018-03-06 15:26:16 --> Router Class Initialized
INFO - 2018-03-06 15:26:16 --> Output Class Initialized
INFO - 2018-03-06 15:26:16 --> Security Class Initialized
DEBUG - 2018-03-06 15:26:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-06 15:26:16 --> Input Class Initialized
INFO - 2018-03-06 15:26:16 --> Language Class Initialized
INFO - 2018-03-06 15:26:16 --> Loader Class Initialized
INFO - 2018-03-06 15:26:16 --> Helper loaded: url_helper
INFO - 2018-03-06 15:26:16 --> Helper loaded: file_helper
INFO - 2018-03-06 15:26:16 --> Helper loaded: email_helper
INFO - 2018-03-06 15:26:16 --> Helper loaded: common_helper
INFO - 2018-03-06 15:26:16 --> Database Driver Class Initialized
DEBUG - 2018-03-06 15:26:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-06 15:26:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-06 15:26:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-03-06 15:26:16 --> Pagination Class Initialized
INFO - 2018-03-06 15:26:16 --> Helper loaded: form_helper
INFO - 2018-03-06 15:26:16 --> Form Validation Class Initialized
INFO - 2018-03-06 15:26:16 --> Model Class Initialized
INFO - 2018-03-06 15:26:16 --> Controller Class Initialized
INFO - 2018-03-06 15:26:16 --> Language file loaded: language/english/english_lang.php
INFO - 2018-03-06 15:26:16 --> Model Class Initialized
INFO - 2018-03-06 15:26:16 --> Model Class Initialized
INFO - 2018-03-06 15:26:16 --> File loaded: /var/www/html/project/periodtracker/application/views//template/side_bar.php
INFO - 2018-03-06 15:26:16 --> File loaded: /var/www/html/project/periodtracker/application/views//template/header.php
INFO - 2018-03-06 15:26:16 --> File loaded: /var/www/html/project/periodtracker/application/views//template/bread_crumb.php
INFO - 2018-03-06 15:26:16 --> File loaded: /var/www/html/project/periodtracker/application/views//template/footer.php
INFO - 2018-03-06 15:26:16 --> File loaded: /var/www/html/project/periodtracker/application/views/thermometersubscription/sendGift.php
INFO - 2018-03-06 15:26:16 --> Final output sent to browser
DEBUG - 2018-03-06 15:26:16 --> Total execution time: 0.0085
INFO - 2018-03-06 15:26:19 --> Config Class Initialized
INFO - 2018-03-06 15:26:19 --> Hooks Class Initialized
DEBUG - 2018-03-06 15:26:19 --> UTF-8 Support Enabled
INFO - 2018-03-06 15:26:19 --> Utf8 Class Initialized
INFO - 2018-03-06 15:26:19 --> URI Class Initialized
INFO - 2018-03-06 15:26:19 --> Router Class Initialized
INFO - 2018-03-06 15:26:19 --> Output Class Initialized
INFO - 2018-03-06 15:26:19 --> Security Class Initialized
DEBUG - 2018-03-06 15:26:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-06 15:26:19 --> Input Class Initialized
INFO - 2018-03-06 15:26:19 --> Language Class Initialized
INFO - 2018-03-06 15:26:19 --> Loader Class Initialized
INFO - 2018-03-06 15:26:19 --> Helper loaded: url_helper
INFO - 2018-03-06 15:26:19 --> Helper loaded: file_helper
INFO - 2018-03-06 15:26:19 --> Helper loaded: email_helper
INFO - 2018-03-06 15:26:19 --> Helper loaded: common_helper
INFO - 2018-03-06 15:26:19 --> Database Driver Class Initialized
DEBUG - 2018-03-06 15:26:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-06 15:26:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-06 15:26:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-03-06 15:26:19 --> Pagination Class Initialized
INFO - 2018-03-06 15:26:19 --> Helper loaded: form_helper
INFO - 2018-03-06 15:26:19 --> Form Validation Class Initialized
INFO - 2018-03-06 15:26:19 --> Model Class Initialized
INFO - 2018-03-06 15:26:19 --> Controller Class Initialized
INFO - 2018-03-06 15:26:19 --> Language file loaded: language/english/english_lang.php
INFO - 2018-03-06 15:26:19 --> Model Class Initialized
INFO - 2018-03-06 15:26:19 --> Model Class Initialized
DEBUG - 2018-03-06 15:26:19 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-06 15:26:19 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-03-06 15:26:19 --> Config Class Initialized
INFO - 2018-03-06 15:26:19 --> Hooks Class Initialized
DEBUG - 2018-03-06 15:26:19 --> UTF-8 Support Enabled
INFO - 2018-03-06 15:26:19 --> Utf8 Class Initialized
INFO - 2018-03-06 15:26:19 --> URI Class Initialized
INFO - 2018-03-06 15:26:19 --> Router Class Initialized
INFO - 2018-03-06 15:26:19 --> Output Class Initialized
INFO - 2018-03-06 15:26:19 --> Security Class Initialized
DEBUG - 2018-03-06 15:26:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-06 15:26:19 --> Input Class Initialized
INFO - 2018-03-06 15:26:19 --> Language Class Initialized
INFO - 2018-03-06 15:26:19 --> Loader Class Initialized
INFO - 2018-03-06 15:26:19 --> Helper loaded: url_helper
INFO - 2018-03-06 15:26:19 --> Helper loaded: file_helper
INFO - 2018-03-06 15:26:19 --> Helper loaded: email_helper
INFO - 2018-03-06 15:26:19 --> Helper loaded: common_helper
INFO - 2018-03-06 15:26:19 --> Database Driver Class Initialized
DEBUG - 2018-03-06 15:26:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-06 15:26:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-06 15:26:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-03-06 15:26:19 --> Pagination Class Initialized
INFO - 2018-03-06 15:26:19 --> Helper loaded: form_helper
INFO - 2018-03-06 15:26:19 --> Form Validation Class Initialized
INFO - 2018-03-06 15:26:19 --> Model Class Initialized
INFO - 2018-03-06 15:26:19 --> Controller Class Initialized
INFO - 2018-03-06 15:26:19 --> Language file loaded: language/english/english_lang.php
INFO - 2018-03-06 15:26:19 --> Config Class Initialized
INFO - 2018-03-06 15:26:19 --> Hooks Class Initialized
DEBUG - 2018-03-06 15:26:19 --> UTF-8 Support Enabled
INFO - 2018-03-06 15:26:19 --> Utf8 Class Initialized
INFO - 2018-03-06 15:26:19 --> URI Class Initialized
INFO - 2018-03-06 15:26:19 --> Router Class Initialized
INFO - 2018-03-06 15:26:19 --> Output Class Initialized
INFO - 2018-03-06 15:26:19 --> Security Class Initialized
DEBUG - 2018-03-06 15:26:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-06 15:26:19 --> Input Class Initialized
INFO - 2018-03-06 15:26:19 --> Language Class Initialized
INFO - 2018-03-06 15:26:19 --> Loader Class Initialized
INFO - 2018-03-06 15:26:19 --> Helper loaded: url_helper
INFO - 2018-03-06 15:26:19 --> Helper loaded: file_helper
INFO - 2018-03-06 15:26:19 --> Helper loaded: email_helper
INFO - 2018-03-06 15:26:19 --> Helper loaded: common_helper
INFO - 2018-03-06 15:26:19 --> Database Driver Class Initialized
DEBUG - 2018-03-06 15:26:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-06 15:26:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-06 15:26:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-03-06 15:26:19 --> Pagination Class Initialized
INFO - 2018-03-06 15:26:19 --> Helper loaded: form_helper
INFO - 2018-03-06 15:26:19 --> Form Validation Class Initialized
INFO - 2018-03-06 15:26:19 --> Model Class Initialized
INFO - 2018-03-06 15:26:19 --> Controller Class Initialized
INFO - 2018-03-06 15:26:19 --> Language file loaded: language/english/english_lang.php
INFO - 2018-03-06 15:26:19 --> Model Class Initialized
INFO - 2018-03-06 15:26:19 --> Model Class Initialized
INFO - 2018-03-06 15:26:19 --> File loaded: /var/www/html/project/periodtracker/application/views//template/side_bar.php
INFO - 2018-03-06 15:26:19 --> File loaded: /var/www/html/project/periodtracker/application/views//template/header.php
INFO - 2018-03-06 15:26:19 --> File loaded: /var/www/html/project/periodtracker/application/views//template/bread_crumb.php
INFO - 2018-03-06 15:26:19 --> File loaded: /var/www/html/project/periodtracker/application/views//template/footer.php
INFO - 2018-03-06 15:26:19 --> File loaded: /var/www/html/project/periodtracker/application/views/thermometersubscription/index.php
INFO - 2018-03-06 15:26:19 --> Final output sent to browser
DEBUG - 2018-03-06 15:26:19 --> Total execution time: 0.0051
INFO - 2018-03-06 15:27:04 --> Config Class Initialized
INFO - 2018-03-06 15:27:04 --> Hooks Class Initialized
DEBUG - 2018-03-06 15:27:04 --> UTF-8 Support Enabled
INFO - 2018-03-06 15:27:04 --> Utf8 Class Initialized
INFO - 2018-03-06 15:27:04 --> URI Class Initialized
INFO - 2018-03-06 15:27:04 --> Router Class Initialized
INFO - 2018-03-06 15:27:04 --> Output Class Initialized
INFO - 2018-03-06 15:27:04 --> Security Class Initialized
DEBUG - 2018-03-06 15:27:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-06 15:27:04 --> Input Class Initialized
INFO - 2018-03-06 15:27:04 --> Language Class Initialized
INFO - 2018-03-06 15:27:04 --> Loader Class Initialized
INFO - 2018-03-06 15:27:04 --> Helper loaded: url_helper
INFO - 2018-03-06 15:27:04 --> Helper loaded: file_helper
INFO - 2018-03-06 15:27:04 --> Helper loaded: email_helper
INFO - 2018-03-06 15:27:04 --> Helper loaded: common_helper
INFO - 2018-03-06 15:27:04 --> Database Driver Class Initialized
DEBUG - 2018-03-06 15:27:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-06 15:27:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-06 15:27:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-03-06 15:27:04 --> Pagination Class Initialized
INFO - 2018-03-06 15:27:04 --> Helper loaded: form_helper
INFO - 2018-03-06 15:27:04 --> Form Validation Class Initialized
INFO - 2018-03-06 15:27:04 --> Model Class Initialized
INFO - 2018-03-06 15:27:04 --> Controller Class Initialized
INFO - 2018-03-06 15:27:04 --> Language file loaded: language/english/english_lang.php
INFO - 2018-03-06 15:27:04 --> Model Class Initialized
INFO - 2018-03-06 15:27:04 --> Model Class Initialized
INFO - 2018-03-06 15:27:04 --> Model Class Initialized
INFO - 2018-03-06 15:27:04 --> Email Class Initialized
INFO - 2018-03-06 15:27:05 --> Language file loaded: language/english/email_lang.php
INFO - 2018-03-06 15:27:08 --> Final output sent to browser
DEBUG - 2018-03-06 15:27:08 --> Total execution time: 4.0245
INFO - 2018-03-06 15:27:52 --> Config Class Initialized
INFO - 2018-03-06 15:27:52 --> Hooks Class Initialized
DEBUG - 2018-03-06 15:27:52 --> UTF-8 Support Enabled
INFO - 2018-03-06 15:27:52 --> Utf8 Class Initialized
INFO - 2018-03-06 15:27:52 --> URI Class Initialized
INFO - 2018-03-06 15:27:52 --> Router Class Initialized
INFO - 2018-03-06 15:27:52 --> Output Class Initialized
INFO - 2018-03-06 15:27:52 --> Security Class Initialized
DEBUG - 2018-03-06 15:27:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-06 15:27:52 --> Input Class Initialized
INFO - 2018-03-06 15:27:52 --> Language Class Initialized
INFO - 2018-03-06 15:27:52 --> Loader Class Initialized
INFO - 2018-03-06 15:27:52 --> Helper loaded: url_helper
INFO - 2018-03-06 15:27:52 --> Helper loaded: file_helper
INFO - 2018-03-06 15:27:52 --> Helper loaded: email_helper
INFO - 2018-03-06 15:27:52 --> Helper loaded: common_helper
INFO - 2018-03-06 15:27:52 --> Database Driver Class Initialized
DEBUG - 2018-03-06 15:27:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-06 15:27:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-06 15:27:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-03-06 15:27:52 --> Pagination Class Initialized
INFO - 2018-03-06 15:27:52 --> Helper loaded: form_helper
INFO - 2018-03-06 15:27:52 --> Form Validation Class Initialized
INFO - 2018-03-06 15:27:52 --> Model Class Initialized
INFO - 2018-03-06 15:27:52 --> Controller Class Initialized
INFO - 2018-03-06 15:27:52 --> Language file loaded: language/english/english_lang.php
INFO - 2018-03-06 15:27:52 --> Model Class Initialized
INFO - 2018-03-06 15:27:52 --> Model Class Initialized
INFO - 2018-03-06 15:27:52 --> File loaded: /var/www/html/project/periodtracker/application/views//template/side_bar.php
INFO - 2018-03-06 15:27:52 --> File loaded: /var/www/html/project/periodtracker/application/views//template/header.php
INFO - 2018-03-06 15:27:52 --> File loaded: /var/www/html/project/periodtracker/application/views//template/bread_crumb.php
INFO - 2018-03-06 15:27:52 --> File loaded: /var/www/html/project/periodtracker/application/views//template/footer.php
INFO - 2018-03-06 15:27:52 --> File loaded: /var/www/html/project/periodtracker/application/views/thermometersubscription/index.php
INFO - 2018-03-06 15:27:52 --> Final output sent to browser
DEBUG - 2018-03-06 15:27:52 --> Total execution time: 0.0077
INFO - 2018-03-06 15:27:53 --> Config Class Initialized
INFO - 2018-03-06 15:27:53 --> Hooks Class Initialized
DEBUG - 2018-03-06 15:27:53 --> UTF-8 Support Enabled
INFO - 2018-03-06 15:27:53 --> Utf8 Class Initialized
INFO - 2018-03-06 15:27:53 --> URI Class Initialized
INFO - 2018-03-06 15:27:53 --> Router Class Initialized
INFO - 2018-03-06 15:27:53 --> Output Class Initialized
INFO - 2018-03-06 15:27:53 --> Security Class Initialized
DEBUG - 2018-03-06 15:27:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-06 15:27:53 --> Input Class Initialized
INFO - 2018-03-06 15:27:53 --> Language Class Initialized
INFO - 2018-03-06 15:27:53 --> Loader Class Initialized
INFO - 2018-03-06 15:27:53 --> Helper loaded: url_helper
INFO - 2018-03-06 15:27:53 --> Helper loaded: file_helper
INFO - 2018-03-06 15:27:53 --> Helper loaded: email_helper
INFO - 2018-03-06 15:27:53 --> Helper loaded: common_helper
INFO - 2018-03-06 15:27:53 --> Database Driver Class Initialized
DEBUG - 2018-03-06 15:27:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-06 15:27:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-06 15:27:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-03-06 15:27:53 --> Pagination Class Initialized
INFO - 2018-03-06 15:27:53 --> Helper loaded: form_helper
INFO - 2018-03-06 15:27:53 --> Form Validation Class Initialized
INFO - 2018-03-06 15:27:53 --> Model Class Initialized
INFO - 2018-03-06 15:27:53 --> Controller Class Initialized
INFO - 2018-03-06 15:27:53 --> Language file loaded: language/english/english_lang.php
INFO - 2018-03-06 15:27:53 --> Model Class Initialized
INFO - 2018-03-06 15:27:53 --> Model Class Initialized
INFO - 2018-03-06 15:27:53 --> File loaded: /var/www/html/project/periodtracker/application/views//template/side_bar.php
INFO - 2018-03-06 15:27:53 --> File loaded: /var/www/html/project/periodtracker/application/views//template/header.php
INFO - 2018-03-06 15:27:53 --> File loaded: /var/www/html/project/periodtracker/application/views//template/bread_crumb.php
INFO - 2018-03-06 15:27:53 --> File loaded: /var/www/html/project/periodtracker/application/views//template/footer.php
INFO - 2018-03-06 15:27:53 --> File loaded: /var/www/html/project/periodtracker/application/views/thermometersubscription/sendGift.php
INFO - 2018-03-06 15:27:53 --> Final output sent to browser
DEBUG - 2018-03-06 15:27:53 --> Total execution time: 0.0053
INFO - 2018-03-06 15:27:56 --> Config Class Initialized
INFO - 2018-03-06 15:27:56 --> Hooks Class Initialized
DEBUG - 2018-03-06 15:27:56 --> UTF-8 Support Enabled
INFO - 2018-03-06 15:27:56 --> Utf8 Class Initialized
INFO - 2018-03-06 15:27:56 --> URI Class Initialized
INFO - 2018-03-06 15:27:56 --> Router Class Initialized
INFO - 2018-03-06 15:27:56 --> Output Class Initialized
INFO - 2018-03-06 15:27:56 --> Security Class Initialized
DEBUG - 2018-03-06 15:27:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-06 15:27:56 --> Input Class Initialized
INFO - 2018-03-06 15:27:56 --> Language Class Initialized
INFO - 2018-03-06 15:27:56 --> Loader Class Initialized
INFO - 2018-03-06 15:27:56 --> Helper loaded: url_helper
INFO - 2018-03-06 15:27:56 --> Helper loaded: file_helper
INFO - 2018-03-06 15:27:56 --> Helper loaded: email_helper
INFO - 2018-03-06 15:27:56 --> Helper loaded: common_helper
INFO - 2018-03-06 15:27:56 --> Database Driver Class Initialized
DEBUG - 2018-03-06 15:27:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-06 15:27:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-06 15:27:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-03-06 15:27:56 --> Pagination Class Initialized
INFO - 2018-03-06 15:27:56 --> Helper loaded: form_helper
INFO - 2018-03-06 15:27:56 --> Form Validation Class Initialized
INFO - 2018-03-06 15:27:56 --> Model Class Initialized
INFO - 2018-03-06 15:27:56 --> Controller Class Initialized
INFO - 2018-03-06 15:27:56 --> Language file loaded: language/english/english_lang.php
INFO - 2018-03-06 15:27:56 --> Model Class Initialized
INFO - 2018-03-06 15:27:56 --> Model Class Initialized
DEBUG - 2018-03-06 15:27:56 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-06 15:27:56 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-03-06 15:27:56 --> Config Class Initialized
INFO - 2018-03-06 15:27:56 --> Hooks Class Initialized
DEBUG - 2018-03-06 15:27:56 --> UTF-8 Support Enabled
INFO - 2018-03-06 15:27:56 --> Utf8 Class Initialized
INFO - 2018-03-06 15:27:56 --> URI Class Initialized
INFO - 2018-03-06 15:27:56 --> Router Class Initialized
INFO - 2018-03-06 15:27:56 --> Output Class Initialized
INFO - 2018-03-06 15:27:56 --> Security Class Initialized
DEBUG - 2018-03-06 15:27:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-06 15:27:56 --> Input Class Initialized
INFO - 2018-03-06 15:27:56 --> Language Class Initialized
INFO - 2018-03-06 15:27:56 --> Loader Class Initialized
INFO - 2018-03-06 15:27:56 --> Helper loaded: url_helper
INFO - 2018-03-06 15:27:56 --> Helper loaded: file_helper
INFO - 2018-03-06 15:27:56 --> Helper loaded: email_helper
INFO - 2018-03-06 15:27:56 --> Helper loaded: common_helper
INFO - 2018-03-06 15:27:56 --> Database Driver Class Initialized
DEBUG - 2018-03-06 15:27:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-06 15:27:56 --> Config Class Initialized
INFO - 2018-03-06 15:27:56 --> Hooks Class Initialized
DEBUG - 2018-03-06 15:27:56 --> UTF-8 Support Enabled
INFO - 2018-03-06 15:27:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-06 15:27:56 --> Utf8 Class Initialized
INFO - 2018-03-06 15:27:56 --> URI Class Initialized
INFO - 2018-03-06 15:27:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-03-06 15:27:56 --> Router Class Initialized
INFO - 2018-03-06 15:27:56 --> Pagination Class Initialized
INFO - 2018-03-06 15:27:56 --> Output Class Initialized
INFO - 2018-03-06 15:27:56 --> Security Class Initialized
INFO - 2018-03-06 15:27:56 --> Helper loaded: form_helper
DEBUG - 2018-03-06 15:27:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-06 15:27:56 --> Form Validation Class Initialized
INFO - 2018-03-06 15:27:56 --> Input Class Initialized
INFO - 2018-03-06 15:27:56 --> Language Class Initialized
INFO - 2018-03-06 15:27:56 --> Model Class Initialized
INFO - 2018-03-06 15:27:56 --> Controller Class Initialized
INFO - 2018-03-06 15:27:56 --> Loader Class Initialized
INFO - 2018-03-06 15:27:56 --> Language file loaded: language/english/english_lang.php
INFO - 2018-03-06 15:27:56 --> Helper loaded: url_helper
INFO - 2018-03-06 15:27:56 --> Helper loaded: file_helper
INFO - 2018-03-06 15:27:56 --> Helper loaded: email_helper
INFO - 2018-03-06 15:27:56 --> Helper loaded: common_helper
INFO - 2018-03-06 15:27:56 --> Database Driver Class Initialized
DEBUG - 2018-03-06 15:27:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-06 15:27:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-06 15:27:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-03-06 15:27:56 --> Pagination Class Initialized
INFO - 2018-03-06 15:27:56 --> Helper loaded: form_helper
INFO - 2018-03-06 15:27:56 --> Form Validation Class Initialized
INFO - 2018-03-06 15:27:56 --> Model Class Initialized
INFO - 2018-03-06 15:27:56 --> Controller Class Initialized
INFO - 2018-03-06 15:27:56 --> Language file loaded: language/english/english_lang.php
INFO - 2018-03-06 15:27:56 --> Model Class Initialized
INFO - 2018-03-06 15:27:56 --> Model Class Initialized
INFO - 2018-03-06 15:27:56 --> File loaded: /var/www/html/project/periodtracker/application/views//template/side_bar.php
INFO - 2018-03-06 15:27:56 --> File loaded: /var/www/html/project/periodtracker/application/views//template/header.php
INFO - 2018-03-06 15:27:56 --> File loaded: /var/www/html/project/periodtracker/application/views//template/bread_crumb.php
INFO - 2018-03-06 15:27:56 --> File loaded: /var/www/html/project/periodtracker/application/views//template/footer.php
INFO - 2018-03-06 15:27:56 --> File loaded: /var/www/html/project/periodtracker/application/views/thermometersubscription/index.php
INFO - 2018-03-06 15:27:56 --> Final output sent to browser
DEBUG - 2018-03-06 15:27:56 --> Total execution time: 0.0035
INFO - 2018-03-06 15:28:58 --> Config Class Initialized
INFO - 2018-03-06 15:28:58 --> Hooks Class Initialized
DEBUG - 2018-03-06 15:28:58 --> UTF-8 Support Enabled
INFO - 2018-03-06 15:28:58 --> Utf8 Class Initialized
INFO - 2018-03-06 15:28:58 --> URI Class Initialized
INFO - 2018-03-06 15:28:58 --> Router Class Initialized
INFO - 2018-03-06 15:28:58 --> Output Class Initialized
INFO - 2018-03-06 15:28:58 --> Security Class Initialized
DEBUG - 2018-03-06 15:28:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-06 15:28:58 --> Input Class Initialized
INFO - 2018-03-06 15:28:58 --> Language Class Initialized
INFO - 2018-03-06 15:28:58 --> Loader Class Initialized
INFO - 2018-03-06 15:28:58 --> Helper loaded: url_helper
INFO - 2018-03-06 15:28:58 --> Helper loaded: file_helper
INFO - 2018-03-06 15:28:58 --> Helper loaded: email_helper
INFO - 2018-03-06 15:28:58 --> Helper loaded: common_helper
INFO - 2018-03-06 15:28:58 --> Database Driver Class Initialized
DEBUG - 2018-03-06 15:28:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-06 15:28:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-06 15:28:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-03-06 15:28:58 --> Pagination Class Initialized
INFO - 2018-03-06 15:28:58 --> Helper loaded: form_helper
INFO - 2018-03-06 15:28:58 --> Form Validation Class Initialized
INFO - 2018-03-06 15:28:58 --> Model Class Initialized
INFO - 2018-03-06 15:28:58 --> Controller Class Initialized
INFO - 2018-03-06 15:28:58 --> Language file loaded: language/english/english_lang.php
INFO - 2018-03-06 15:28:58 --> Model Class Initialized
INFO - 2018-03-06 15:28:58 --> Model Class Initialized
INFO - 2018-03-06 15:28:58 --> File loaded: /var/www/html/project/periodtracker/application/views//template/side_bar.php
INFO - 2018-03-06 15:28:58 --> File loaded: /var/www/html/project/periodtracker/application/views//template/header.php
INFO - 2018-03-06 15:28:58 --> File loaded: /var/www/html/project/periodtracker/application/views//template/bread_crumb.php
INFO - 2018-03-06 15:28:58 --> File loaded: /var/www/html/project/periodtracker/application/views//template/footer.php
INFO - 2018-03-06 15:28:58 --> File loaded: /var/www/html/project/periodtracker/application/views/thermometersubscription/index.php
INFO - 2018-03-06 15:28:58 --> Final output sent to browser
DEBUG - 2018-03-06 15:28:58 --> Total execution time: 0.0064
INFO - 2018-03-06 15:29:18 --> Config Class Initialized
INFO - 2018-03-06 15:29:18 --> Hooks Class Initialized
DEBUG - 2018-03-06 15:29:18 --> UTF-8 Support Enabled
INFO - 2018-03-06 15:29:18 --> Utf8 Class Initialized
INFO - 2018-03-06 15:29:18 --> URI Class Initialized
INFO - 2018-03-06 15:29:18 --> Router Class Initialized
INFO - 2018-03-06 15:29:18 --> Output Class Initialized
INFO - 2018-03-06 15:29:18 --> Security Class Initialized
DEBUG - 2018-03-06 15:29:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-06 15:29:18 --> Input Class Initialized
INFO - 2018-03-06 15:29:18 --> Language Class Initialized
INFO - 2018-03-06 15:29:18 --> Loader Class Initialized
INFO - 2018-03-06 15:29:18 --> Helper loaded: url_helper
INFO - 2018-03-06 15:29:18 --> Helper loaded: file_helper
INFO - 2018-03-06 15:29:18 --> Helper loaded: email_helper
INFO - 2018-03-06 15:29:18 --> Helper loaded: common_helper
INFO - 2018-03-06 15:29:18 --> Database Driver Class Initialized
DEBUG - 2018-03-06 15:29:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-06 15:29:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-06 15:29:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-03-06 15:29:18 --> Pagination Class Initialized
INFO - 2018-03-06 15:29:18 --> Helper loaded: form_helper
INFO - 2018-03-06 15:29:18 --> Form Validation Class Initialized
INFO - 2018-03-06 15:29:18 --> Model Class Initialized
INFO - 2018-03-06 15:29:18 --> Controller Class Initialized
INFO - 2018-03-06 15:29:18 --> Language file loaded: language/english/english_lang.php
INFO - 2018-03-06 15:29:18 --> Model Class Initialized
INFO - 2018-03-06 15:29:18 --> Model Class Initialized
INFO - 2018-03-06 15:29:18 --> File loaded: /var/www/html/project/periodtracker/application/views//template/side_bar.php
INFO - 2018-03-06 15:29:18 --> File loaded: /var/www/html/project/periodtracker/application/views//template/header.php
INFO - 2018-03-06 15:29:18 --> File loaded: /var/www/html/project/periodtracker/application/views//template/bread_crumb.php
INFO - 2018-03-06 15:29:18 --> File loaded: /var/www/html/project/periodtracker/application/views//template/footer.php
INFO - 2018-03-06 15:29:18 --> File loaded: /var/www/html/project/periodtracker/application/views/thermometersubscription/index.php
INFO - 2018-03-06 15:29:18 --> Final output sent to browser
DEBUG - 2018-03-06 15:29:18 --> Total execution time: 0.0099
INFO - 2018-03-06 15:29:20 --> Config Class Initialized
INFO - 2018-03-06 15:29:20 --> Hooks Class Initialized
DEBUG - 2018-03-06 15:29:20 --> UTF-8 Support Enabled
INFO - 2018-03-06 15:29:20 --> Utf8 Class Initialized
INFO - 2018-03-06 15:29:20 --> URI Class Initialized
INFO - 2018-03-06 15:29:20 --> Router Class Initialized
INFO - 2018-03-06 15:29:20 --> Output Class Initialized
INFO - 2018-03-06 15:29:20 --> Security Class Initialized
DEBUG - 2018-03-06 15:29:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-06 15:29:20 --> Input Class Initialized
INFO - 2018-03-06 15:29:20 --> Language Class Initialized
INFO - 2018-03-06 15:29:20 --> Loader Class Initialized
INFO - 2018-03-06 15:29:20 --> Helper loaded: url_helper
INFO - 2018-03-06 15:29:20 --> Helper loaded: file_helper
INFO - 2018-03-06 15:29:20 --> Helper loaded: email_helper
INFO - 2018-03-06 15:29:20 --> Helper loaded: common_helper
INFO - 2018-03-06 15:29:20 --> Database Driver Class Initialized
DEBUG - 2018-03-06 15:29:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-06 15:29:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-06 15:29:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-03-06 15:29:20 --> Pagination Class Initialized
INFO - 2018-03-06 15:29:20 --> Helper loaded: form_helper
INFO - 2018-03-06 15:29:20 --> Form Validation Class Initialized
INFO - 2018-03-06 15:29:20 --> Model Class Initialized
INFO - 2018-03-06 15:29:20 --> Controller Class Initialized
INFO - 2018-03-06 15:29:20 --> Language file loaded: language/english/english_lang.php
INFO - 2018-03-06 15:29:20 --> Model Class Initialized
INFO - 2018-03-06 15:29:20 --> Model Class Initialized
INFO - 2018-03-06 15:29:20 --> File loaded: /var/www/html/project/periodtracker/application/views//template/side_bar.php
INFO - 2018-03-06 15:29:20 --> File loaded: /var/www/html/project/periodtracker/application/views//template/header.php
INFO - 2018-03-06 15:29:20 --> File loaded: /var/www/html/project/periodtracker/application/views//template/bread_crumb.php
INFO - 2018-03-06 15:29:20 --> File loaded: /var/www/html/project/periodtracker/application/views//template/footer.php
INFO - 2018-03-06 15:29:20 --> File loaded: /var/www/html/project/periodtracker/application/views/thermometersubscription/sendGift.php
INFO - 2018-03-06 15:29:20 --> Final output sent to browser
DEBUG - 2018-03-06 15:29:20 --> Total execution time: 0.0058
INFO - 2018-03-06 15:29:23 --> Config Class Initialized
INFO - 2018-03-06 15:29:23 --> Hooks Class Initialized
DEBUG - 2018-03-06 15:29:23 --> UTF-8 Support Enabled
INFO - 2018-03-06 15:29:23 --> Utf8 Class Initialized
INFO - 2018-03-06 15:29:23 --> URI Class Initialized
INFO - 2018-03-06 15:29:23 --> Router Class Initialized
INFO - 2018-03-06 15:29:23 --> Output Class Initialized
INFO - 2018-03-06 15:29:23 --> Security Class Initialized
DEBUG - 2018-03-06 15:29:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-06 15:29:23 --> Input Class Initialized
INFO - 2018-03-06 15:29:23 --> Language Class Initialized
INFO - 2018-03-06 15:29:23 --> Loader Class Initialized
INFO - 2018-03-06 15:29:23 --> Helper loaded: url_helper
INFO - 2018-03-06 15:29:23 --> Helper loaded: file_helper
INFO - 2018-03-06 15:29:23 --> Helper loaded: email_helper
INFO - 2018-03-06 15:29:23 --> Helper loaded: common_helper
INFO - 2018-03-06 15:29:23 --> Database Driver Class Initialized
DEBUG - 2018-03-06 15:29:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-06 15:29:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-06 15:29:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-03-06 15:29:23 --> Pagination Class Initialized
INFO - 2018-03-06 15:29:23 --> Helper loaded: form_helper
INFO - 2018-03-06 15:29:23 --> Form Validation Class Initialized
INFO - 2018-03-06 15:29:23 --> Model Class Initialized
INFO - 2018-03-06 15:29:23 --> Controller Class Initialized
INFO - 2018-03-06 15:29:23 --> Language file loaded: language/english/english_lang.php
INFO - 2018-03-06 15:29:23 --> Model Class Initialized
INFO - 2018-03-06 15:29:23 --> Model Class Initialized
DEBUG - 2018-03-06 15:29:23 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-06 15:29:23 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-03-06 15:29:23 --> Config Class Initialized
INFO - 2018-03-06 15:29:23 --> Hooks Class Initialized
DEBUG - 2018-03-06 15:29:23 --> UTF-8 Support Enabled
INFO - 2018-03-06 15:29:23 --> Utf8 Class Initialized
INFO - 2018-03-06 15:29:23 --> URI Class Initialized
INFO - 2018-03-06 15:29:23 --> Router Class Initialized
INFO - 2018-03-06 15:29:23 --> Output Class Initialized
INFO - 2018-03-06 15:29:23 --> Security Class Initialized
DEBUG - 2018-03-06 15:29:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-06 15:29:23 --> Input Class Initialized
INFO - 2018-03-06 15:29:23 --> Language Class Initialized
INFO - 2018-03-06 15:29:23 --> Loader Class Initialized
INFO - 2018-03-06 15:29:23 --> Helper loaded: url_helper
INFO - 2018-03-06 15:29:23 --> Helper loaded: file_helper
INFO - 2018-03-06 15:29:23 --> Helper loaded: email_helper
INFO - 2018-03-06 15:29:23 --> Helper loaded: common_helper
INFO - 2018-03-06 15:29:23 --> Database Driver Class Initialized
INFO - 2018-03-06 15:29:23 --> Config Class Initialized
INFO - 2018-03-06 15:29:23 --> Hooks Class Initialized
DEBUG - 2018-03-06 15:29:23 --> UTF-8 Support Enabled
INFO - 2018-03-06 15:29:23 --> Utf8 Class Initialized
INFO - 2018-03-06 15:29:23 --> URI Class Initialized
INFO - 2018-03-06 15:29:23 --> Router Class Initialized
DEBUG - 2018-03-06 15:29:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-06 15:29:23 --> Output Class Initialized
INFO - 2018-03-06 15:29:23 --> Security Class Initialized
INFO - 2018-03-06 15:29:23 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-03-06 15:29:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-06 15:29:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-03-06 15:29:23 --> Input Class Initialized
INFO - 2018-03-06 15:29:23 --> Pagination Class Initialized
INFO - 2018-03-06 15:29:23 --> Language Class Initialized
INFO - 2018-03-06 15:29:23 --> Helper loaded: form_helper
INFO - 2018-03-06 15:29:23 --> Loader Class Initialized
INFO - 2018-03-06 15:29:23 --> Form Validation Class Initialized
INFO - 2018-03-06 15:29:23 --> Helper loaded: url_helper
INFO - 2018-03-06 15:29:23 --> Model Class Initialized
INFO - 2018-03-06 15:29:23 --> Helper loaded: file_helper
INFO - 2018-03-06 15:29:23 --> Controller Class Initialized
INFO - 2018-03-06 15:29:23 --> Helper loaded: email_helper
INFO - 2018-03-06 15:29:23 --> Language file loaded: language/english/english_lang.php
INFO - 2018-03-06 15:29:23 --> Helper loaded: common_helper
INFO - 2018-03-06 15:29:23 --> Model Class Initialized
INFO - 2018-03-06 15:29:23 --> Model Class Initialized
INFO - 2018-03-06 15:29:23 --> Database Driver Class Initialized
INFO - 2018-03-06 15:29:23 --> Model Class Initialized
DEBUG - 2018-03-06 15:29:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-06 15:29:23 --> Email Class Initialized
INFO - 2018-03-06 15:29:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-06 15:29:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-03-06 15:29:23 --> Pagination Class Initialized
INFO - 2018-03-06 15:29:23 --> Helper loaded: form_helper
INFO - 2018-03-06 15:29:23 --> Form Validation Class Initialized
INFO - 2018-03-06 15:29:23 --> Model Class Initialized
INFO - 2018-03-06 15:29:23 --> Controller Class Initialized
INFO - 2018-03-06 15:29:23 --> Language file loaded: language/english/english_lang.php
INFO - 2018-03-06 15:29:23 --> Model Class Initialized
INFO - 2018-03-06 15:29:23 --> Model Class Initialized
INFO - 2018-03-06 15:29:23 --> File loaded: /var/www/html/project/periodtracker/application/views//template/side_bar.php
INFO - 2018-03-06 15:29:23 --> File loaded: /var/www/html/project/periodtracker/application/views//template/header.php
INFO - 2018-03-06 15:29:23 --> File loaded: /var/www/html/project/periodtracker/application/views//template/bread_crumb.php
INFO - 2018-03-06 15:29:23 --> File loaded: /var/www/html/project/periodtracker/application/views//template/footer.php
INFO - 2018-03-06 15:29:23 --> File loaded: /var/www/html/project/periodtracker/application/views/thermometersubscription/index.php
INFO - 2018-03-06 15:29:23 --> Final output sent to browser
DEBUG - 2018-03-06 15:29:23 --> Total execution time: 0.0065
INFO - 2018-03-06 15:29:23 --> Language file loaded: language/english/email_lang.php
INFO - 2018-03-06 15:30:41 --> Config Class Initialized
INFO - 2018-03-06 15:30:41 --> Hooks Class Initialized
DEBUG - 2018-03-06 15:30:41 --> UTF-8 Support Enabled
INFO - 2018-03-06 15:30:41 --> Utf8 Class Initialized
INFO - 2018-03-06 15:30:41 --> URI Class Initialized
INFO - 2018-03-06 15:30:41 --> Router Class Initialized
INFO - 2018-03-06 15:30:41 --> Output Class Initialized
INFO - 2018-03-06 15:30:41 --> Security Class Initialized
DEBUG - 2018-03-06 15:30:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-06 15:30:41 --> Input Class Initialized
INFO - 2018-03-06 15:30:41 --> Language Class Initialized
INFO - 2018-03-06 15:30:41 --> Loader Class Initialized
INFO - 2018-03-06 15:30:41 --> Helper loaded: url_helper
INFO - 2018-03-06 15:30:41 --> Helper loaded: file_helper
INFO - 2018-03-06 15:30:41 --> Helper loaded: email_helper
INFO - 2018-03-06 15:30:41 --> Helper loaded: common_helper
INFO - 2018-03-06 15:30:41 --> Database Driver Class Initialized
DEBUG - 2018-03-06 15:30:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-06 15:30:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-06 15:30:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-03-06 15:30:41 --> Pagination Class Initialized
INFO - 2018-03-06 15:30:41 --> Helper loaded: form_helper
INFO - 2018-03-06 15:30:41 --> Form Validation Class Initialized
INFO - 2018-03-06 15:30:41 --> Model Class Initialized
INFO - 2018-03-06 15:30:41 --> Controller Class Initialized
INFO - 2018-03-06 15:30:41 --> Language file loaded: language/english/english_lang.php
INFO - 2018-03-06 15:30:41 --> Model Class Initialized
INFO - 2018-03-06 15:30:41 --> Model Class Initialized
INFO - 2018-03-06 15:30:41 --> File loaded: /var/www/html/project/periodtracker/application/views//template/side_bar.php
INFO - 2018-03-06 15:30:41 --> File loaded: /var/www/html/project/periodtracker/application/views//template/header.php
INFO - 2018-03-06 15:30:41 --> File loaded: /var/www/html/project/periodtracker/application/views//template/bread_crumb.php
INFO - 2018-03-06 15:30:41 --> File loaded: /var/www/html/project/periodtracker/application/views//template/footer.php
INFO - 2018-03-06 15:30:41 --> File loaded: /var/www/html/project/periodtracker/application/views/thermometersubscription/index.php
INFO - 2018-03-06 15:30:41 --> Final output sent to browser
DEBUG - 2018-03-06 15:30:41 --> Total execution time: 0.0087
INFO - 2018-03-06 15:30:49 --> Config Class Initialized
INFO - 2018-03-06 15:30:49 --> Hooks Class Initialized
DEBUG - 2018-03-06 15:30:49 --> UTF-8 Support Enabled
INFO - 2018-03-06 15:30:49 --> Utf8 Class Initialized
INFO - 2018-03-06 15:30:49 --> URI Class Initialized
INFO - 2018-03-06 15:30:49 --> Router Class Initialized
INFO - 2018-03-06 15:30:49 --> Output Class Initialized
INFO - 2018-03-06 15:30:49 --> Security Class Initialized
DEBUG - 2018-03-06 15:30:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-06 15:30:49 --> Input Class Initialized
INFO - 2018-03-06 15:30:49 --> Language Class Initialized
INFO - 2018-03-06 15:30:49 --> Loader Class Initialized
INFO - 2018-03-06 15:30:49 --> Helper loaded: url_helper
INFO - 2018-03-06 15:30:49 --> Helper loaded: file_helper
INFO - 2018-03-06 15:30:49 --> Helper loaded: email_helper
INFO - 2018-03-06 15:30:49 --> Helper loaded: common_helper
INFO - 2018-03-06 15:30:49 --> Database Driver Class Initialized
DEBUG - 2018-03-06 15:30:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-06 15:30:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-06 15:30:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-03-06 15:30:49 --> Pagination Class Initialized
INFO - 2018-03-06 15:30:49 --> Helper loaded: form_helper
INFO - 2018-03-06 15:30:49 --> Form Validation Class Initialized
INFO - 2018-03-06 15:30:49 --> Model Class Initialized
INFO - 2018-03-06 15:30:49 --> Controller Class Initialized
INFO - 2018-03-06 15:30:49 --> Language file loaded: language/english/english_lang.php
INFO - 2018-03-06 15:30:49 --> Model Class Initialized
INFO - 2018-03-06 15:30:49 --> Model Class Initialized
INFO - 2018-03-06 15:30:49 --> File loaded: /var/www/html/project/periodtracker/application/views//template/side_bar.php
INFO - 2018-03-06 15:30:49 --> File loaded: /var/www/html/project/periodtracker/application/views//template/header.php
INFO - 2018-03-06 15:30:49 --> File loaded: /var/www/html/project/periodtracker/application/views//template/bread_crumb.php
INFO - 2018-03-06 15:30:49 --> File loaded: /var/www/html/project/periodtracker/application/views//template/footer.php
INFO - 2018-03-06 15:30:49 --> File loaded: /var/www/html/project/periodtracker/application/views/thermometersubscription/sendGift.php
INFO - 2018-03-06 15:30:49 --> Final output sent to browser
DEBUG - 2018-03-06 15:30:49 --> Total execution time: 0.0053
INFO - 2018-03-06 15:30:52 --> Config Class Initialized
INFO - 2018-03-06 15:30:52 --> Hooks Class Initialized
DEBUG - 2018-03-06 15:30:52 --> UTF-8 Support Enabled
INFO - 2018-03-06 15:30:52 --> Utf8 Class Initialized
INFO - 2018-03-06 15:30:52 --> URI Class Initialized
INFO - 2018-03-06 15:30:52 --> Router Class Initialized
INFO - 2018-03-06 15:30:52 --> Output Class Initialized
INFO - 2018-03-06 15:30:52 --> Security Class Initialized
DEBUG - 2018-03-06 15:30:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-06 15:30:52 --> Input Class Initialized
INFO - 2018-03-06 15:30:52 --> Language Class Initialized
INFO - 2018-03-06 15:30:52 --> Loader Class Initialized
INFO - 2018-03-06 15:30:52 --> Helper loaded: url_helper
INFO - 2018-03-06 15:30:52 --> Helper loaded: file_helper
INFO - 2018-03-06 15:30:52 --> Helper loaded: email_helper
INFO - 2018-03-06 15:30:52 --> Helper loaded: common_helper
INFO - 2018-03-06 15:30:52 --> Database Driver Class Initialized
DEBUG - 2018-03-06 15:30:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-06 15:30:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-06 15:30:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-03-06 15:30:52 --> Pagination Class Initialized
INFO - 2018-03-06 15:30:52 --> Helper loaded: form_helper
INFO - 2018-03-06 15:30:52 --> Form Validation Class Initialized
INFO - 2018-03-06 15:30:52 --> Model Class Initialized
INFO - 2018-03-06 15:30:52 --> Controller Class Initialized
INFO - 2018-03-06 15:30:52 --> Language file loaded: language/english/english_lang.php
INFO - 2018-03-06 15:30:52 --> Model Class Initialized
INFO - 2018-03-06 15:30:52 --> Model Class Initialized
DEBUG - 2018-03-06 15:30:52 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-06 15:30:52 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-03-06 15:30:52 --> Config Class Initialized
INFO - 2018-03-06 15:30:52 --> Hooks Class Initialized
DEBUG - 2018-03-06 15:30:52 --> UTF-8 Support Enabled
INFO - 2018-03-06 15:30:52 --> Utf8 Class Initialized
INFO - 2018-03-06 15:30:52 --> URI Class Initialized
INFO - 2018-03-06 15:30:52 --> Router Class Initialized
INFO - 2018-03-06 15:30:52 --> Output Class Initialized
INFO - 2018-03-06 15:30:52 --> Security Class Initialized
DEBUG - 2018-03-06 15:30:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-06 15:30:52 --> Input Class Initialized
INFO - 2018-03-06 15:30:52 --> Language Class Initialized
INFO - 2018-03-06 15:30:52 --> Loader Class Initialized
INFO - 2018-03-06 15:30:52 --> Helper loaded: url_helper
INFO - 2018-03-06 15:30:52 --> Helper loaded: file_helper
INFO - 2018-03-06 15:30:52 --> Helper loaded: email_helper
INFO - 2018-03-06 15:30:52 --> Helper loaded: common_helper
INFO - 2018-03-06 15:30:52 --> Database Driver Class Initialized
INFO - 2018-03-06 15:30:52 --> Config Class Initialized
INFO - 2018-03-06 15:30:52 --> Hooks Class Initialized
DEBUG - 2018-03-06 15:30:52 --> UTF-8 Support Enabled
INFO - 2018-03-06 15:30:52 --> Utf8 Class Initialized
DEBUG - 2018-03-06 15:30:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-06 15:30:52 --> URI Class Initialized
INFO - 2018-03-06 15:30:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-06 15:30:52 --> Router Class Initialized
INFO - 2018-03-06 15:30:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-03-06 15:30:52 --> Output Class Initialized
INFO - 2018-03-06 15:30:52 --> Pagination Class Initialized
INFO - 2018-03-06 15:30:52 --> Security Class Initialized
INFO - 2018-03-06 15:30:52 --> Helper loaded: form_helper
DEBUG - 2018-03-06 15:30:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-06 15:30:52 --> Form Validation Class Initialized
INFO - 2018-03-06 15:30:52 --> Input Class Initialized
INFO - 2018-03-06 15:30:52 --> Model Class Initialized
INFO - 2018-03-06 15:30:52 --> Language Class Initialized
INFO - 2018-03-06 15:30:52 --> Controller Class Initialized
INFO - 2018-03-06 15:30:52 --> Loader Class Initialized
INFO - 2018-03-06 15:30:52 --> Language file loaded: language/english/english_lang.php
INFO - 2018-03-06 15:30:52 --> Helper loaded: url_helper
INFO - 2018-03-06 15:30:52 --> Model Class Initialized
INFO - 2018-03-06 15:30:52 --> Helper loaded: file_helper
INFO - 2018-03-06 15:30:52 --> Model Class Initialized
INFO - 2018-03-06 15:30:52 --> Helper loaded: email_helper
INFO - 2018-03-06 15:30:52 --> Model Class Initialized
INFO - 2018-03-06 15:30:52 --> Helper loaded: common_helper
INFO - 2018-03-06 15:30:52 --> Database Driver Class Initialized
INFO - 2018-03-06 15:30:52 --> Email Class Initialized
DEBUG - 2018-03-06 15:30:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-06 15:30:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-06 15:30:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-03-06 15:30:52 --> Pagination Class Initialized
INFO - 2018-03-06 15:30:52 --> Helper loaded: form_helper
INFO - 2018-03-06 15:30:52 --> Form Validation Class Initialized
INFO - 2018-03-06 15:30:52 --> Model Class Initialized
INFO - 2018-03-06 15:30:52 --> Controller Class Initialized
INFO - 2018-03-06 15:30:52 --> Language file loaded: language/english/english_lang.php
INFO - 2018-03-06 15:30:52 --> Model Class Initialized
INFO - 2018-03-06 15:30:52 --> Model Class Initialized
INFO - 2018-03-06 15:30:52 --> File loaded: /var/www/html/project/periodtracker/application/views//template/side_bar.php
INFO - 2018-03-06 15:30:52 --> File loaded: /var/www/html/project/periodtracker/application/views//template/header.php
INFO - 2018-03-06 15:30:52 --> File loaded: /var/www/html/project/periodtracker/application/views//template/bread_crumb.php
INFO - 2018-03-06 15:30:52 --> File loaded: /var/www/html/project/periodtracker/application/views//template/footer.php
INFO - 2018-03-06 15:30:52 --> File loaded: /var/www/html/project/periodtracker/application/views/thermometersubscription/index.php
INFO - 2018-03-06 15:30:52 --> Final output sent to browser
DEBUG - 2018-03-06 15:30:52 --> Total execution time: 0.0072
INFO - 2018-03-06 15:30:53 --> Language file loaded: language/english/email_lang.php
INFO - 2018-03-06 15:32:49 --> Config Class Initialized
INFO - 2018-03-06 15:32:49 --> Hooks Class Initialized
DEBUG - 2018-03-06 15:32:49 --> UTF-8 Support Enabled
INFO - 2018-03-06 15:32:49 --> Utf8 Class Initialized
INFO - 2018-03-06 15:32:49 --> URI Class Initialized
INFO - 2018-03-06 15:32:49 --> Router Class Initialized
INFO - 2018-03-06 15:32:49 --> Output Class Initialized
INFO - 2018-03-06 15:32:49 --> Security Class Initialized
DEBUG - 2018-03-06 15:32:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-06 15:32:49 --> Input Class Initialized
INFO - 2018-03-06 15:32:49 --> Language Class Initialized
INFO - 2018-03-06 15:32:49 --> Loader Class Initialized
INFO - 2018-03-06 15:32:49 --> Helper loaded: url_helper
INFO - 2018-03-06 15:32:49 --> Helper loaded: file_helper
INFO - 2018-03-06 15:32:49 --> Helper loaded: email_helper
INFO - 2018-03-06 15:32:49 --> Helper loaded: common_helper
INFO - 2018-03-06 15:32:49 --> Database Driver Class Initialized
DEBUG - 2018-03-06 15:32:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-06 15:32:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-06 15:32:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-03-06 15:32:49 --> Pagination Class Initialized
INFO - 2018-03-06 15:32:49 --> Helper loaded: form_helper
INFO - 2018-03-06 15:32:49 --> Form Validation Class Initialized
INFO - 2018-03-06 15:32:49 --> Model Class Initialized
INFO - 2018-03-06 15:32:49 --> Controller Class Initialized
INFO - 2018-03-06 15:32:49 --> Language file loaded: language/english/english_lang.php
INFO - 2018-03-06 15:32:49 --> Model Class Initialized
INFO - 2018-03-06 15:32:49 --> File loaded: /var/www/html/project/periodtracker/application/views//template/side_bar.php
INFO - 2018-03-06 15:32:49 --> File loaded: /var/www/html/project/periodtracker/application/views//template/header.php
INFO - 2018-03-06 15:32:49 --> File loaded: /var/www/html/project/periodtracker/application/views//template/bread_crumb.php
INFO - 2018-03-06 15:32:49 --> File loaded: /var/www/html/project/periodtracker/application/views//template/footer.php
INFO - 2018-03-06 15:32:49 --> File loaded: /var/www/html/project/periodtracker/application/views/user/index.php
INFO - 2018-03-06 15:32:49 --> Final output sent to browser
DEBUG - 2018-03-06 15:32:49 --> Total execution time: 0.0055
INFO - 2018-03-06 15:32:49 --> Config Class Initialized
INFO - 2018-03-06 15:32:49 --> Hooks Class Initialized
DEBUG - 2018-03-06 15:32:49 --> UTF-8 Support Enabled
INFO - 2018-03-06 15:32:49 --> Utf8 Class Initialized
INFO - 2018-03-06 15:32:49 --> URI Class Initialized
INFO - 2018-03-06 15:32:49 --> Router Class Initialized
INFO - 2018-03-06 15:32:49 --> Output Class Initialized
INFO - 2018-03-06 15:32:49 --> Security Class Initialized
DEBUG - 2018-03-06 15:32:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-06 15:32:49 --> Input Class Initialized
INFO - 2018-03-06 15:32:49 --> Language Class Initialized
INFO - 2018-03-06 15:32:49 --> Loader Class Initialized
INFO - 2018-03-06 15:32:49 --> Helper loaded: url_helper
INFO - 2018-03-06 15:32:49 --> Helper loaded: file_helper
INFO - 2018-03-06 15:32:49 --> Helper loaded: email_helper
INFO - 2018-03-06 15:32:49 --> Helper loaded: common_helper
INFO - 2018-03-06 15:32:49 --> Database Driver Class Initialized
DEBUG - 2018-03-06 15:32:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-06 15:32:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-06 15:32:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-03-06 15:32:49 --> Pagination Class Initialized
INFO - 2018-03-06 15:32:49 --> Helper loaded: form_helper
INFO - 2018-03-06 15:32:49 --> Form Validation Class Initialized
INFO - 2018-03-06 15:32:49 --> Model Class Initialized
INFO - 2018-03-06 15:32:49 --> Controller Class Initialized
INFO - 2018-03-06 15:32:49 --> Language file loaded: language/english/english_lang.php
INFO - 2018-03-06 15:32:49 --> Model Class Initialized
INFO - 2018-03-06 15:32:49 --> Config Class Initialized
INFO - 2018-03-06 15:32:49 --> Hooks Class Initialized
DEBUG - 2018-03-06 15:32:49 --> UTF-8 Support Enabled
INFO - 2018-03-06 15:32:49 --> Utf8 Class Initialized
INFO - 2018-03-06 15:32:49 --> URI Class Initialized
INFO - 2018-03-06 15:32:49 --> Router Class Initialized
INFO - 2018-03-06 15:32:49 --> Output Class Initialized
INFO - 2018-03-06 15:32:49 --> Security Class Initialized
DEBUG - 2018-03-06 15:32:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-06 15:32:49 --> Input Class Initialized
INFO - 2018-03-06 15:32:49 --> Language Class Initialized
INFO - 2018-03-06 15:32:49 --> Loader Class Initialized
INFO - 2018-03-06 15:32:49 --> Helper loaded: url_helper
INFO - 2018-03-06 15:32:49 --> Helper loaded: file_helper
INFO - 2018-03-06 15:32:49 --> Helper loaded: email_helper
INFO - 2018-03-06 15:32:49 --> Helper loaded: common_helper
INFO - 2018-03-06 15:32:49 --> Database Driver Class Initialized
DEBUG - 2018-03-06 15:32:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-06 15:32:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-06 15:32:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-03-06 15:32:49 --> Pagination Class Initialized
INFO - 2018-03-06 15:32:49 --> Helper loaded: form_helper
INFO - 2018-03-06 15:32:49 --> Form Validation Class Initialized
INFO - 2018-03-06 15:32:49 --> Model Class Initialized
INFO - 2018-03-06 15:32:49 --> Controller Class Initialized
INFO - 2018-03-06 15:32:49 --> Language file loaded: language/english/english_lang.php
INFO - 2018-03-06 15:32:49 --> Model Class Initialized
INFO - 2018-03-06 15:32:49 --> Model Class Initialized
INFO - 2018-03-06 15:32:49 --> File loaded: /var/www/html/project/periodtracker/application/views//template/side_bar.php
INFO - 2018-03-06 15:32:49 --> File loaded: /var/www/html/project/periodtracker/application/views//template/header.php
INFO - 2018-03-06 15:32:49 --> File loaded: /var/www/html/project/periodtracker/application/views//template/bread_crumb.php
INFO - 2018-03-06 15:32:49 --> File loaded: /var/www/html/project/periodtracker/application/views//template/footer.php
INFO - 2018-03-06 15:32:49 --> File loaded: /var/www/html/project/periodtracker/application/views/thermometersubscription/index.php
INFO - 2018-03-06 15:32:49 --> Final output sent to browser
DEBUG - 2018-03-06 15:32:49 --> Total execution time: 0.0056
INFO - 2018-03-06 15:33:11 --> Config Class Initialized
INFO - 2018-03-06 15:33:11 --> Hooks Class Initialized
DEBUG - 2018-03-06 15:33:11 --> UTF-8 Support Enabled
INFO - 2018-03-06 15:33:11 --> Utf8 Class Initialized
INFO - 2018-03-06 15:33:11 --> URI Class Initialized
INFO - 2018-03-06 15:33:11 --> Router Class Initialized
INFO - 2018-03-06 15:33:11 --> Output Class Initialized
INFO - 2018-03-06 15:33:11 --> Security Class Initialized
DEBUG - 2018-03-06 15:33:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-06 15:33:11 --> Input Class Initialized
INFO - 2018-03-06 15:33:11 --> Language Class Initialized
INFO - 2018-03-06 15:33:11 --> Loader Class Initialized
INFO - 2018-03-06 15:33:11 --> Helper loaded: url_helper
INFO - 2018-03-06 15:33:11 --> Helper loaded: file_helper
INFO - 2018-03-06 15:33:11 --> Helper loaded: email_helper
INFO - 2018-03-06 15:33:11 --> Helper loaded: common_helper
INFO - 2018-03-06 15:33:11 --> Database Driver Class Initialized
DEBUG - 2018-03-06 15:33:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-06 15:33:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-06 15:33:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-03-06 15:33:11 --> Pagination Class Initialized
INFO - 2018-03-06 15:33:11 --> Helper loaded: form_helper
INFO - 2018-03-06 15:33:11 --> Form Validation Class Initialized
INFO - 2018-03-06 15:33:11 --> Model Class Initialized
INFO - 2018-03-06 15:33:11 --> Controller Class Initialized
INFO - 2018-03-06 15:33:11 --> Language file loaded: language/english/english_lang.php
INFO - 2018-03-06 15:33:11 --> Model Class Initialized
INFO - 2018-03-06 15:33:11 --> Model Class Initialized
INFO - 2018-03-06 15:33:11 --> File loaded: /var/www/html/project/periodtracker/application/views//template/side_bar.php
INFO - 2018-03-06 15:33:11 --> File loaded: /var/www/html/project/periodtracker/application/views//template/header.php
INFO - 2018-03-06 15:33:11 --> File loaded: /var/www/html/project/periodtracker/application/views//template/bread_crumb.php
INFO - 2018-03-06 15:33:11 --> File loaded: /var/www/html/project/periodtracker/application/views//template/footer.php
INFO - 2018-03-06 15:33:11 --> File loaded: /var/www/html/project/periodtracker/application/views/thermometersubscription/index.php
INFO - 2018-03-06 15:33:11 --> Final output sent to browser
DEBUG - 2018-03-06 15:33:11 --> Total execution time: 0.0059
INFO - 2018-03-06 15:33:55 --> Config Class Initialized
INFO - 2018-03-06 15:33:55 --> Hooks Class Initialized
DEBUG - 2018-03-06 15:33:55 --> UTF-8 Support Enabled
INFO - 2018-03-06 15:33:55 --> Utf8 Class Initialized
INFO - 2018-03-06 15:33:55 --> URI Class Initialized
INFO - 2018-03-06 15:33:55 --> Router Class Initialized
INFO - 2018-03-06 15:33:55 --> Output Class Initialized
INFO - 2018-03-06 15:33:55 --> Security Class Initialized
DEBUG - 2018-03-06 15:33:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-06 15:33:55 --> Input Class Initialized
INFO - 2018-03-06 15:33:55 --> Language Class Initialized
INFO - 2018-03-06 15:33:55 --> Loader Class Initialized
INFO - 2018-03-06 15:33:55 --> Helper loaded: url_helper
INFO - 2018-03-06 15:33:55 --> Helper loaded: file_helper
INFO - 2018-03-06 15:33:55 --> Helper loaded: email_helper
INFO - 2018-03-06 15:33:55 --> Helper loaded: common_helper
INFO - 2018-03-06 15:33:55 --> Database Driver Class Initialized
DEBUG - 2018-03-06 15:33:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-06 15:33:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-06 15:33:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-03-06 15:33:55 --> Pagination Class Initialized
INFO - 2018-03-06 15:33:55 --> Helper loaded: form_helper
INFO - 2018-03-06 15:33:55 --> Form Validation Class Initialized
INFO - 2018-03-06 15:33:55 --> Model Class Initialized
INFO - 2018-03-06 15:33:55 --> Controller Class Initialized
INFO - 2018-03-06 15:33:55 --> Language file loaded: language/english/english_lang.php
INFO - 2018-03-06 15:33:55 --> Model Class Initialized
INFO - 2018-03-06 15:33:55 --> Model Class Initialized
INFO - 2018-03-06 15:33:55 --> File loaded: /var/www/html/project/periodtracker/application/views//template/side_bar.php
INFO - 2018-03-06 15:33:55 --> File loaded: /var/www/html/project/periodtracker/application/views//template/header.php
INFO - 2018-03-06 15:33:55 --> File loaded: /var/www/html/project/periodtracker/application/views//template/bread_crumb.php
INFO - 2018-03-06 15:33:55 --> File loaded: /var/www/html/project/periodtracker/application/views//template/footer.php
INFO - 2018-03-06 15:33:55 --> File loaded: /var/www/html/project/periodtracker/application/views/thermometersubscription/index.php
INFO - 2018-03-06 15:33:55 --> Final output sent to browser
DEBUG - 2018-03-06 15:33:55 --> Total execution time: 0.0054
INFO - 2018-03-06 15:49:53 --> Config Class Initialized
INFO - 2018-03-06 15:49:53 --> Hooks Class Initialized
DEBUG - 2018-03-06 15:49:53 --> UTF-8 Support Enabled
INFO - 2018-03-06 15:49:53 --> Utf8 Class Initialized
INFO - 2018-03-06 15:49:53 --> URI Class Initialized
INFO - 2018-03-06 15:49:53 --> Router Class Initialized
INFO - 2018-03-06 15:49:53 --> Output Class Initialized
INFO - 2018-03-06 15:49:53 --> Security Class Initialized
DEBUG - 2018-03-06 15:49:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-06 15:49:53 --> Input Class Initialized
INFO - 2018-03-06 15:49:53 --> Language Class Initialized
INFO - 2018-03-06 15:49:53 --> Loader Class Initialized
INFO - 2018-03-06 15:49:53 --> Helper loaded: url_helper
INFO - 2018-03-06 15:49:53 --> Helper loaded: file_helper
INFO - 2018-03-06 15:49:53 --> Helper loaded: email_helper
INFO - 2018-03-06 15:49:53 --> Helper loaded: common_helper
INFO - 2018-03-06 15:49:53 --> Database Driver Class Initialized
DEBUG - 2018-03-06 15:49:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-06 15:49:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-06 15:49:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-03-06 15:49:53 --> Pagination Class Initialized
INFO - 2018-03-06 15:49:53 --> Helper loaded: form_helper
INFO - 2018-03-06 15:49:53 --> Form Validation Class Initialized
INFO - 2018-03-06 15:49:53 --> Model Class Initialized
INFO - 2018-03-06 15:49:53 --> Controller Class Initialized
INFO - 2018-03-06 15:49:53 --> Language file loaded: language/english/english_lang.php
INFO - 2018-03-06 15:49:53 --> Model Class Initialized
INFO - 2018-03-06 15:49:53 --> File loaded: /var/www/html/project/periodtracker/application/views//template/side_bar.php
INFO - 2018-03-06 15:49:53 --> File loaded: /var/www/html/project/periodtracker/application/views//template/header.php
INFO - 2018-03-06 15:49:53 --> File loaded: /var/www/html/project/periodtracker/application/views//template/bread_crumb.php
INFO - 2018-03-06 15:49:53 --> File loaded: /var/www/html/project/periodtracker/application/views//template/footer.php
INFO - 2018-03-06 15:49:53 --> File loaded: /var/www/html/project/periodtracker/application/views/dashboard/index.php
INFO - 2018-03-06 15:49:53 --> Final output sent to browser
DEBUG - 2018-03-06 15:49:53 --> Total execution time: 0.0063
INFO - 2018-03-06 15:49:56 --> Config Class Initialized
INFO - 2018-03-06 15:49:56 --> Hooks Class Initialized
DEBUG - 2018-03-06 15:49:56 --> UTF-8 Support Enabled
INFO - 2018-03-06 15:49:56 --> Utf8 Class Initialized
INFO - 2018-03-06 15:49:56 --> URI Class Initialized
INFO - 2018-03-06 15:49:56 --> Router Class Initialized
INFO - 2018-03-06 15:49:56 --> Output Class Initialized
INFO - 2018-03-06 15:49:56 --> Security Class Initialized
DEBUG - 2018-03-06 15:49:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-06 15:49:56 --> Input Class Initialized
INFO - 2018-03-06 15:49:56 --> Language Class Initialized
INFO - 2018-03-06 15:49:56 --> Loader Class Initialized
INFO - 2018-03-06 15:49:56 --> Helper loaded: url_helper
INFO - 2018-03-06 15:49:56 --> Helper loaded: file_helper
INFO - 2018-03-06 15:49:56 --> Helper loaded: email_helper
INFO - 2018-03-06 15:49:56 --> Helper loaded: common_helper
INFO - 2018-03-06 15:49:56 --> Database Driver Class Initialized
DEBUG - 2018-03-06 15:49:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-06 15:49:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-06 15:49:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-03-06 15:49:56 --> Pagination Class Initialized
INFO - 2018-03-06 15:49:56 --> Helper loaded: form_helper
INFO - 2018-03-06 15:49:56 --> Form Validation Class Initialized
INFO - 2018-03-06 15:49:56 --> Model Class Initialized
INFO - 2018-03-06 15:49:56 --> Controller Class Initialized
INFO - 2018-03-06 15:49:56 --> Language file loaded: language/english/english_lang.php
INFO - 2018-03-06 15:49:56 --> Model Class Initialized
INFO - 2018-03-06 15:49:56 --> File loaded: /var/www/html/project/periodtracker/application/views//template/side_bar.php
INFO - 2018-03-06 15:49:56 --> File loaded: /var/www/html/project/periodtracker/application/views//template/header.php
INFO - 2018-03-06 15:49:56 --> File loaded: /var/www/html/project/periodtracker/application/views//template/bread_crumb.php
INFO - 2018-03-06 15:49:56 --> File loaded: /var/www/html/project/periodtracker/application/views//template/footer.php
INFO - 2018-03-06 15:49:56 --> File loaded: /var/www/html/project/periodtracker/application/views/user/index.php
INFO - 2018-03-06 15:49:56 --> Final output sent to browser
DEBUG - 2018-03-06 15:49:56 --> Total execution time: 0.0046
INFO - 2018-03-06 15:49:56 --> Config Class Initialized
INFO - 2018-03-06 15:49:56 --> Hooks Class Initialized
DEBUG - 2018-03-06 15:49:56 --> UTF-8 Support Enabled
INFO - 2018-03-06 15:49:56 --> Utf8 Class Initialized
INFO - 2018-03-06 15:49:56 --> URI Class Initialized
INFO - 2018-03-06 15:49:56 --> Router Class Initialized
INFO - 2018-03-06 15:49:56 --> Output Class Initialized
INFO - 2018-03-06 15:49:56 --> Security Class Initialized
DEBUG - 2018-03-06 15:49:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-06 15:49:56 --> Input Class Initialized
INFO - 2018-03-06 15:49:56 --> Language Class Initialized
INFO - 2018-03-06 15:49:56 --> Loader Class Initialized
INFO - 2018-03-06 15:49:56 --> Helper loaded: url_helper
INFO - 2018-03-06 15:49:56 --> Helper loaded: file_helper
INFO - 2018-03-06 15:49:56 --> Helper loaded: email_helper
INFO - 2018-03-06 15:49:56 --> Helper loaded: common_helper
INFO - 2018-03-06 15:49:56 --> Database Driver Class Initialized
DEBUG - 2018-03-06 15:49:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-06 15:49:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-06 15:49:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-03-06 15:49:56 --> Pagination Class Initialized
INFO - 2018-03-06 15:49:56 --> Helper loaded: form_helper
INFO - 2018-03-06 15:49:56 --> Form Validation Class Initialized
INFO - 2018-03-06 15:49:56 --> Model Class Initialized
INFO - 2018-03-06 15:49:56 --> Controller Class Initialized
INFO - 2018-03-06 15:49:56 --> Language file loaded: language/english/english_lang.php
INFO - 2018-03-06 15:49:56 --> Model Class Initialized
INFO - 2018-03-06 15:49:59 --> Config Class Initialized
INFO - 2018-03-06 15:49:59 --> Hooks Class Initialized
DEBUG - 2018-03-06 15:49:59 --> UTF-8 Support Enabled
INFO - 2018-03-06 15:49:59 --> Utf8 Class Initialized
INFO - 2018-03-06 15:49:59 --> URI Class Initialized
INFO - 2018-03-06 15:49:59 --> Router Class Initialized
INFO - 2018-03-06 15:49:59 --> Output Class Initialized
INFO - 2018-03-06 15:49:59 --> Security Class Initialized
DEBUG - 2018-03-06 15:49:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-06 15:49:59 --> Input Class Initialized
INFO - 2018-03-06 15:49:59 --> Language Class Initialized
INFO - 2018-03-06 15:49:59 --> Loader Class Initialized
INFO - 2018-03-06 15:49:59 --> Helper loaded: url_helper
INFO - 2018-03-06 15:49:59 --> Helper loaded: file_helper
INFO - 2018-03-06 15:49:59 --> Helper loaded: email_helper
INFO - 2018-03-06 15:49:59 --> Helper loaded: common_helper
INFO - 2018-03-06 15:49:59 --> Database Driver Class Initialized
DEBUG - 2018-03-06 15:49:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-06 15:49:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-06 15:49:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-03-06 15:49:59 --> Pagination Class Initialized
INFO - 2018-03-06 15:49:59 --> Helper loaded: form_helper
INFO - 2018-03-06 15:49:59 --> Form Validation Class Initialized
INFO - 2018-03-06 15:49:59 --> Model Class Initialized
INFO - 2018-03-06 15:49:59 --> Controller Class Initialized
INFO - 2018-03-06 15:49:59 --> Language file loaded: language/english/english_lang.php
INFO - 2018-03-06 15:49:59 --> Model Class Initialized
INFO - 2018-03-06 15:49:59 --> Model Class Initialized
INFO - 2018-03-06 15:49:59 --> File loaded: /var/www/html/project/periodtracker/application/views//template/side_bar.php
INFO - 2018-03-06 15:49:59 --> File loaded: /var/www/html/project/periodtracker/application/views//template/header.php
INFO - 2018-03-06 15:49:59 --> File loaded: /var/www/html/project/periodtracker/application/views//template/bread_crumb.php
INFO - 2018-03-06 15:49:59 --> File loaded: /var/www/html/project/periodtracker/application/views//template/footer.php
INFO - 2018-03-06 15:49:59 --> File loaded: /var/www/html/project/periodtracker/application/views/thermometersubscription/index.php
INFO - 2018-03-06 15:49:59 --> Final output sent to browser
DEBUG - 2018-03-06 15:49:59 --> Total execution time: 0.0055
INFO - 2018-03-06 15:50:42 --> Config Class Initialized
INFO - 2018-03-06 15:50:42 --> Hooks Class Initialized
DEBUG - 2018-03-06 15:50:42 --> UTF-8 Support Enabled
INFO - 2018-03-06 15:50:42 --> Utf8 Class Initialized
INFO - 2018-03-06 15:50:42 --> URI Class Initialized
INFO - 2018-03-06 15:50:42 --> Router Class Initialized
INFO - 2018-03-06 15:50:42 --> Output Class Initialized
INFO - 2018-03-06 15:50:42 --> Security Class Initialized
DEBUG - 2018-03-06 15:50:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-06 15:50:42 --> Input Class Initialized
INFO - 2018-03-06 15:50:42 --> Language Class Initialized
INFO - 2018-03-06 15:50:42 --> Loader Class Initialized
INFO - 2018-03-06 15:50:42 --> Helper loaded: url_helper
INFO - 2018-03-06 15:50:42 --> Helper loaded: file_helper
INFO - 2018-03-06 15:50:42 --> Helper loaded: email_helper
INFO - 2018-03-06 15:50:42 --> Helper loaded: common_helper
INFO - 2018-03-06 15:50:42 --> Database Driver Class Initialized
DEBUG - 2018-03-06 15:50:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-06 15:50:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-06 15:50:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-03-06 15:50:42 --> Pagination Class Initialized
INFO - 2018-03-06 15:50:42 --> Helper loaded: form_helper
INFO - 2018-03-06 15:50:42 --> Form Validation Class Initialized
INFO - 2018-03-06 15:50:42 --> Model Class Initialized
INFO - 2018-03-06 15:50:42 --> Controller Class Initialized
INFO - 2018-03-06 15:50:42 --> Language file loaded: language/english/english_lang.php
INFO - 2018-03-06 15:50:42 --> Model Class Initialized
INFO - 2018-03-06 15:50:42 --> Model Class Initialized
INFO - 2018-03-06 15:50:42 --> File loaded: /var/www/html/project/periodtracker/application/views//template/side_bar.php
INFO - 2018-03-06 15:50:42 --> File loaded: /var/www/html/project/periodtracker/application/views//template/header.php
INFO - 2018-03-06 15:50:42 --> File loaded: /var/www/html/project/periodtracker/application/views//template/bread_crumb.php
INFO - 2018-03-06 15:50:42 --> File loaded: /var/www/html/project/periodtracker/application/views//template/footer.php
INFO - 2018-03-06 15:50:42 --> File loaded: /var/www/html/project/periodtracker/application/views/thermometersubscription/index.php
INFO - 2018-03-06 15:50:42 --> Final output sent to browser
DEBUG - 2018-03-06 15:50:42 --> Total execution time: 0.0067
INFO - 2018-03-06 15:50:49 --> Config Class Initialized
INFO - 2018-03-06 15:50:49 --> Hooks Class Initialized
DEBUG - 2018-03-06 15:50:49 --> UTF-8 Support Enabled
INFO - 2018-03-06 15:50:49 --> Utf8 Class Initialized
INFO - 2018-03-06 15:50:49 --> URI Class Initialized
INFO - 2018-03-06 15:50:49 --> Router Class Initialized
INFO - 2018-03-06 15:50:49 --> Output Class Initialized
INFO - 2018-03-06 15:50:49 --> Security Class Initialized
DEBUG - 2018-03-06 15:50:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-06 15:50:49 --> Input Class Initialized
INFO - 2018-03-06 15:50:49 --> Language Class Initialized
INFO - 2018-03-06 15:50:49 --> Loader Class Initialized
INFO - 2018-03-06 15:50:49 --> Helper loaded: url_helper
INFO - 2018-03-06 15:50:49 --> Helper loaded: file_helper
INFO - 2018-03-06 15:50:49 --> Helper loaded: email_helper
INFO - 2018-03-06 15:50:49 --> Helper loaded: common_helper
INFO - 2018-03-06 15:50:49 --> Database Driver Class Initialized
DEBUG - 2018-03-06 15:50:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-06 15:50:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-06 15:50:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-03-06 15:50:49 --> Pagination Class Initialized
INFO - 2018-03-06 15:50:49 --> Helper loaded: form_helper
INFO - 2018-03-06 15:50:49 --> Form Validation Class Initialized
INFO - 2018-03-06 15:50:49 --> Model Class Initialized
INFO - 2018-03-06 15:50:49 --> Controller Class Initialized
INFO - 2018-03-06 15:50:49 --> Language file loaded: language/english/english_lang.php
INFO - 2018-03-06 15:50:49 --> Model Class Initialized
INFO - 2018-03-06 15:50:49 --> Model Class Initialized
INFO - 2018-03-06 15:50:49 --> File loaded: /var/www/html/project/periodtracker/application/views//template/side_bar.php
INFO - 2018-03-06 15:50:49 --> File loaded: /var/www/html/project/periodtracker/application/views//template/header.php
INFO - 2018-03-06 15:50:49 --> File loaded: /var/www/html/project/periodtracker/application/views//template/bread_crumb.php
INFO - 2018-03-06 15:50:49 --> File loaded: /var/www/html/project/periodtracker/application/views//template/footer.php
INFO - 2018-03-06 15:50:49 --> File loaded: /var/www/html/project/periodtracker/application/views/thermometersubscription/sendGift.php
INFO - 2018-03-06 15:50:49 --> Final output sent to browser
DEBUG - 2018-03-06 15:50:49 --> Total execution time: 0.0068
INFO - 2018-03-06 15:54:37 --> Config Class Initialized
INFO - 2018-03-06 15:54:37 --> Hooks Class Initialized
DEBUG - 2018-03-06 15:54:37 --> UTF-8 Support Enabled
INFO - 2018-03-06 15:54:37 --> Utf8 Class Initialized
INFO - 2018-03-06 15:54:37 --> URI Class Initialized
INFO - 2018-03-06 15:54:37 --> Router Class Initialized
INFO - 2018-03-06 15:54:37 --> Output Class Initialized
INFO - 2018-03-06 15:54:37 --> Security Class Initialized
DEBUG - 2018-03-06 15:54:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-06 15:54:37 --> Input Class Initialized
INFO - 2018-03-06 15:54:37 --> Language Class Initialized
INFO - 2018-03-06 15:54:37 --> Loader Class Initialized
INFO - 2018-03-06 15:54:37 --> Helper loaded: url_helper
INFO - 2018-03-06 15:54:37 --> Helper loaded: file_helper
INFO - 2018-03-06 15:54:37 --> Helper loaded: email_helper
INFO - 2018-03-06 15:54:37 --> Helper loaded: common_helper
INFO - 2018-03-06 15:54:37 --> Database Driver Class Initialized
DEBUG - 2018-03-06 15:54:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-06 15:54:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-06 15:54:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-03-06 15:54:37 --> Pagination Class Initialized
INFO - 2018-03-06 15:54:37 --> Helper loaded: form_helper
INFO - 2018-03-06 15:54:37 --> Form Validation Class Initialized
INFO - 2018-03-06 15:54:37 --> Model Class Initialized
INFO - 2018-03-06 15:54:37 --> Controller Class Initialized
DEBUG - 2018-03-06 15:54:37 --> Config file loaded: /var/www/html/project/periodtracker/application/config/rest.php
INFO - 2018-03-06 15:54:37 --> Helper loaded: inflector_helper
INFO - 2018-03-06 15:54:37 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-06 15:54:37 --> Model Class Initialized
INFO - 2018-03-06 15:54:37 --> Model Class Initialized
INFO - 2018-03-06 15:54:37 --> Model Class Initialized
INFO - 2018-03-06 15:54:37 --> Final output sent to browser
DEBUG - 2018-03-06 15:54:37 --> Total execution time: 0.1008
INFO - 2018-03-06 15:54:43 --> Config Class Initialized
INFO - 2018-03-06 15:54:43 --> Hooks Class Initialized
DEBUG - 2018-03-06 15:54:43 --> UTF-8 Support Enabled
INFO - 2018-03-06 15:54:43 --> Utf8 Class Initialized
INFO - 2018-03-06 15:54:43 --> URI Class Initialized
INFO - 2018-03-06 15:54:43 --> Router Class Initialized
INFO - 2018-03-06 15:54:43 --> Output Class Initialized
INFO - 2018-03-06 15:54:43 --> Security Class Initialized
DEBUG - 2018-03-06 15:54:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-06 15:54:43 --> Input Class Initialized
INFO - 2018-03-06 15:54:43 --> Language Class Initialized
INFO - 2018-03-06 15:54:43 --> Loader Class Initialized
INFO - 2018-03-06 15:54:43 --> Helper loaded: url_helper
INFO - 2018-03-06 15:54:43 --> Helper loaded: file_helper
INFO - 2018-03-06 15:54:43 --> Helper loaded: email_helper
INFO - 2018-03-06 15:54:43 --> Helper loaded: common_helper
INFO - 2018-03-06 15:54:43 --> Database Driver Class Initialized
DEBUG - 2018-03-06 15:54:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-06 15:54:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-06 15:54:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-03-06 15:54:43 --> Pagination Class Initialized
INFO - 2018-03-06 15:54:43 --> Helper loaded: form_helper
INFO - 2018-03-06 15:54:43 --> Form Validation Class Initialized
INFO - 2018-03-06 15:54:43 --> Model Class Initialized
INFO - 2018-03-06 15:54:43 --> Controller Class Initialized
INFO - 2018-03-06 15:54:43 --> Language file loaded: language/english/english_lang.php
INFO - 2018-03-06 15:54:43 --> Model Class Initialized
INFO - 2018-03-06 15:54:43 --> Model Class Initialized
INFO - 2018-03-06 15:54:43 --> File loaded: /var/www/html/project/periodtracker/application/views//template/side_bar.php
INFO - 2018-03-06 15:54:43 --> File loaded: /var/www/html/project/periodtracker/application/views//template/header.php
INFO - 2018-03-06 15:54:43 --> File loaded: /var/www/html/project/periodtracker/application/views//template/bread_crumb.php
INFO - 2018-03-06 15:54:43 --> File loaded: /var/www/html/project/periodtracker/application/views//template/footer.php
INFO - 2018-03-06 15:54:43 --> File loaded: /var/www/html/project/periodtracker/application/views/thermometersubscription/index.php
INFO - 2018-03-06 15:54:43 --> Final output sent to browser
DEBUG - 2018-03-06 15:54:43 --> Total execution time: 0.0065
INFO - 2018-03-06 16:05:30 --> Config Class Initialized
INFO - 2018-03-06 16:05:30 --> Hooks Class Initialized
DEBUG - 2018-03-06 16:05:30 --> UTF-8 Support Enabled
INFO - 2018-03-06 16:05:30 --> Utf8 Class Initialized
INFO - 2018-03-06 16:05:30 --> URI Class Initialized
INFO - 2018-03-06 16:05:30 --> Router Class Initialized
INFO - 2018-03-06 16:05:30 --> Output Class Initialized
INFO - 2018-03-06 16:05:30 --> Security Class Initialized
DEBUG - 2018-03-06 16:05:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-06 16:05:30 --> Input Class Initialized
INFO - 2018-03-06 16:05:30 --> Language Class Initialized
ERROR - 2018-03-06 16:05:30 --> 404 Page Not Found: Thermometersubscription/sendGiftMail
INFO - 2018-03-06 16:05:50 --> Config Class Initialized
INFO - 2018-03-06 16:05:50 --> Hooks Class Initialized
DEBUG - 2018-03-06 16:05:50 --> UTF-8 Support Enabled
INFO - 2018-03-06 16:05:50 --> Utf8 Class Initialized
INFO - 2018-03-06 16:05:50 --> URI Class Initialized
INFO - 2018-03-06 16:05:50 --> Router Class Initialized
INFO - 2018-03-06 16:05:50 --> Output Class Initialized
INFO - 2018-03-06 16:05:50 --> Security Class Initialized
DEBUG - 2018-03-06 16:05:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-06 16:05:50 --> Input Class Initialized
INFO - 2018-03-06 16:05:50 --> Language Class Initialized
INFO - 2018-03-06 16:05:50 --> Loader Class Initialized
INFO - 2018-03-06 16:05:50 --> Helper loaded: url_helper
INFO - 2018-03-06 16:05:50 --> Helper loaded: file_helper
INFO - 2018-03-06 16:05:50 --> Helper loaded: email_helper
INFO - 2018-03-06 16:05:50 --> Helper loaded: common_helper
INFO - 2018-03-06 16:05:50 --> Database Driver Class Initialized
DEBUG - 2018-03-06 16:05:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-06 16:05:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-06 16:05:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-03-06 16:05:50 --> Pagination Class Initialized
INFO - 2018-03-06 16:05:50 --> Helper loaded: form_helper
INFO - 2018-03-06 16:05:50 --> Form Validation Class Initialized
INFO - 2018-03-06 16:05:50 --> Model Class Initialized
INFO - 2018-03-06 16:05:50 --> Controller Class Initialized
INFO - 2018-03-06 16:05:50 --> Language file loaded: language/english/english_lang.php
INFO - 2018-03-06 16:05:50 --> Model Class Initialized
INFO - 2018-03-06 16:05:50 --> Model Class Initialized
INFO - 2018-03-06 16:06:05 --> Config Class Initialized
INFO - 2018-03-06 16:06:05 --> Hooks Class Initialized
DEBUG - 2018-03-06 16:06:05 --> UTF-8 Support Enabled
INFO - 2018-03-06 16:06:05 --> Utf8 Class Initialized
INFO - 2018-03-06 16:06:05 --> URI Class Initialized
INFO - 2018-03-06 16:06:05 --> Router Class Initialized
INFO - 2018-03-06 16:06:05 --> Output Class Initialized
INFO - 2018-03-06 16:06:05 --> Security Class Initialized
DEBUG - 2018-03-06 16:06:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-06 16:06:05 --> Input Class Initialized
INFO - 2018-03-06 16:06:05 --> Language Class Initialized
INFO - 2018-03-06 16:06:05 --> Loader Class Initialized
INFO - 2018-03-06 16:06:05 --> Helper loaded: url_helper
INFO - 2018-03-06 16:06:05 --> Helper loaded: file_helper
INFO - 2018-03-06 16:06:05 --> Helper loaded: email_helper
INFO - 2018-03-06 16:06:05 --> Helper loaded: common_helper
INFO - 2018-03-06 16:06:05 --> Database Driver Class Initialized
DEBUG - 2018-03-06 16:06:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-06 16:06:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-06 16:06:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-03-06 16:06:05 --> Pagination Class Initialized
INFO - 2018-03-06 16:06:05 --> Helper loaded: form_helper
INFO - 2018-03-06 16:06:05 --> Form Validation Class Initialized
INFO - 2018-03-06 16:06:05 --> Model Class Initialized
INFO - 2018-03-06 16:06:05 --> Controller Class Initialized
INFO - 2018-03-06 16:06:05 --> Language file loaded: language/english/english_lang.php
INFO - 2018-03-06 16:06:05 --> Model Class Initialized
INFO - 2018-03-06 16:06:05 --> Model Class Initialized
INFO - 2018-03-06 16:06:18 --> Config Class Initialized
INFO - 2018-03-06 16:06:18 --> Hooks Class Initialized
DEBUG - 2018-03-06 16:06:18 --> UTF-8 Support Enabled
INFO - 2018-03-06 16:06:18 --> Utf8 Class Initialized
INFO - 2018-03-06 16:06:18 --> URI Class Initialized
INFO - 2018-03-06 16:06:18 --> Router Class Initialized
INFO - 2018-03-06 16:06:18 --> Output Class Initialized
INFO - 2018-03-06 16:06:18 --> Security Class Initialized
DEBUG - 2018-03-06 16:06:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-06 16:06:18 --> Input Class Initialized
INFO - 2018-03-06 16:06:18 --> Language Class Initialized
INFO - 2018-03-06 16:06:18 --> Loader Class Initialized
INFO - 2018-03-06 16:06:18 --> Helper loaded: url_helper
INFO - 2018-03-06 16:06:18 --> Helper loaded: file_helper
INFO - 2018-03-06 16:06:18 --> Helper loaded: email_helper
INFO - 2018-03-06 16:06:18 --> Helper loaded: common_helper
INFO - 2018-03-06 16:06:18 --> Database Driver Class Initialized
DEBUG - 2018-03-06 16:06:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-06 16:06:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-06 16:06:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-03-06 16:06:18 --> Pagination Class Initialized
INFO - 2018-03-06 16:06:18 --> Helper loaded: form_helper
INFO - 2018-03-06 16:06:18 --> Form Validation Class Initialized
INFO - 2018-03-06 16:06:18 --> Model Class Initialized
INFO - 2018-03-06 16:06:18 --> Controller Class Initialized
INFO - 2018-03-06 16:06:18 --> Language file loaded: language/english/english_lang.php
INFO - 2018-03-06 16:06:18 --> Model Class Initialized
INFO - 2018-03-06 16:06:18 --> Model Class Initialized
INFO - 2018-03-06 16:23:49 --> Config Class Initialized
INFO - 2018-03-06 16:23:49 --> Hooks Class Initialized
DEBUG - 2018-03-06 16:23:49 --> UTF-8 Support Enabled
INFO - 2018-03-06 16:23:49 --> Utf8 Class Initialized
INFO - 2018-03-06 16:23:49 --> URI Class Initialized
INFO - 2018-03-06 16:23:49 --> Router Class Initialized
INFO - 2018-03-06 16:23:49 --> Output Class Initialized
INFO - 2018-03-06 16:23:49 --> Security Class Initialized
DEBUG - 2018-03-06 16:23:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-06 16:23:49 --> Input Class Initialized
INFO - 2018-03-06 16:23:49 --> Language Class Initialized
INFO - 2018-03-06 16:23:49 --> Loader Class Initialized
INFO - 2018-03-06 16:23:49 --> Helper loaded: url_helper
INFO - 2018-03-06 16:23:49 --> Helper loaded: file_helper
INFO - 2018-03-06 16:23:49 --> Helper loaded: email_helper
INFO - 2018-03-06 16:23:49 --> Helper loaded: common_helper
INFO - 2018-03-06 16:23:49 --> Database Driver Class Initialized
DEBUG - 2018-03-06 16:23:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-06 16:23:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-06 16:23:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-03-06 16:23:49 --> Pagination Class Initialized
INFO - 2018-03-06 16:23:49 --> Helper loaded: form_helper
INFO - 2018-03-06 16:23:49 --> Form Validation Class Initialized
INFO - 2018-03-06 16:23:49 --> Model Class Initialized
INFO - 2018-03-06 16:23:49 --> Controller Class Initialized
INFO - 2018-03-06 16:23:49 --> Language file loaded: language/english/english_lang.php
INFO - 2018-03-06 16:23:49 --> Model Class Initialized
INFO - 2018-03-06 16:23:49 --> Model Class Initialized
INFO - 2018-03-06 16:23:49 --> File loaded: /var/www/html/project/periodtracker/application/views//template/side_bar.php
INFO - 2018-03-06 16:23:49 --> File loaded: /var/www/html/project/periodtracker/application/views//template/header.php
INFO - 2018-03-06 16:23:49 --> File loaded: /var/www/html/project/periodtracker/application/views//template/bread_crumb.php
INFO - 2018-03-06 16:23:49 --> File loaded: /var/www/html/project/periodtracker/application/views//template/footer.php
INFO - 2018-03-06 16:23:49 --> File loaded: /var/www/html/project/periodtracker/application/views/thermometersubscription/index.php
INFO - 2018-03-06 16:23:49 --> Final output sent to browser
DEBUG - 2018-03-06 16:23:49 --> Total execution time: 0.0074
INFO - 2018-03-06 17:02:37 --> Config Class Initialized
INFO - 2018-03-06 17:02:37 --> Hooks Class Initialized
DEBUG - 2018-03-06 17:02:37 --> UTF-8 Support Enabled
INFO - 2018-03-06 17:02:37 --> Utf8 Class Initialized
INFO - 2018-03-06 17:02:37 --> URI Class Initialized
INFO - 2018-03-06 17:02:37 --> Router Class Initialized
INFO - 2018-03-06 17:02:37 --> Output Class Initialized
INFO - 2018-03-06 17:02:37 --> Security Class Initialized
DEBUG - 2018-03-06 17:02:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-06 17:02:37 --> Input Class Initialized
INFO - 2018-03-06 17:02:37 --> Language Class Initialized
INFO - 2018-03-06 17:02:37 --> Loader Class Initialized
INFO - 2018-03-06 17:02:37 --> Helper loaded: url_helper
INFO - 2018-03-06 17:02:37 --> Helper loaded: file_helper
INFO - 2018-03-06 17:02:37 --> Helper loaded: email_helper
INFO - 2018-03-06 17:02:37 --> Helper loaded: common_helper
INFO - 2018-03-06 17:02:37 --> Database Driver Class Initialized
DEBUG - 2018-03-06 17:02:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-06 17:02:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-06 17:02:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-03-06 17:02:37 --> Pagination Class Initialized
INFO - 2018-03-06 17:02:37 --> Helper loaded: form_helper
INFO - 2018-03-06 17:02:37 --> Form Validation Class Initialized
INFO - 2018-03-06 17:02:37 --> Model Class Initialized
INFO - 2018-03-06 17:02:37 --> Controller Class Initialized
INFO - 2018-03-06 17:02:37 --> Language file loaded: language/english/english_lang.php
INFO - 2018-03-06 17:02:37 --> Model Class Initialized
INFO - 2018-03-06 17:02:37 --> Model Class Initialized
INFO - 2018-03-06 17:02:37 --> File loaded: /var/www/html/project/periodtracker/application/views//template/side_bar.php
INFO - 2018-03-06 17:02:37 --> File loaded: /var/www/html/project/periodtracker/application/views//template/header.php
INFO - 2018-03-06 17:02:37 --> File loaded: /var/www/html/project/periodtracker/application/views//template/bread_crumb.php
INFO - 2018-03-06 17:02:37 --> File loaded: /var/www/html/project/periodtracker/application/views//template/footer.php
INFO - 2018-03-06 17:02:37 --> File loaded: /var/www/html/project/periodtracker/application/views/thermometersubscription/index.php
INFO - 2018-03-06 17:02:37 --> Final output sent to browser
DEBUG - 2018-03-06 17:02:37 --> Total execution time: 0.0078
INFO - 2018-03-06 17:02:47 --> Config Class Initialized
INFO - 2018-03-06 17:02:47 --> Hooks Class Initialized
DEBUG - 2018-03-06 17:02:47 --> UTF-8 Support Enabled
INFO - 2018-03-06 17:02:47 --> Utf8 Class Initialized
INFO - 2018-03-06 17:02:47 --> URI Class Initialized
INFO - 2018-03-06 17:02:47 --> Router Class Initialized
INFO - 2018-03-06 17:02:47 --> Output Class Initialized
INFO - 2018-03-06 17:02:47 --> Security Class Initialized
DEBUG - 2018-03-06 17:02:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-06 17:02:47 --> Input Class Initialized
INFO - 2018-03-06 17:02:47 --> Language Class Initialized
INFO - 2018-03-06 17:02:47 --> Loader Class Initialized
INFO - 2018-03-06 17:02:47 --> Helper loaded: url_helper
INFO - 2018-03-06 17:02:47 --> Helper loaded: file_helper
INFO - 2018-03-06 17:02:47 --> Helper loaded: email_helper
INFO - 2018-03-06 17:02:47 --> Helper loaded: common_helper
INFO - 2018-03-06 17:02:47 --> Database Driver Class Initialized
DEBUG - 2018-03-06 17:02:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-06 17:02:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-06 17:02:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-03-06 17:02:47 --> Pagination Class Initialized
INFO - 2018-03-06 17:02:47 --> Helper loaded: form_helper
INFO - 2018-03-06 17:02:47 --> Form Validation Class Initialized
INFO - 2018-03-06 17:02:47 --> Model Class Initialized
INFO - 2018-03-06 17:02:47 --> Controller Class Initialized
INFO - 2018-03-06 17:02:47 --> Language file loaded: language/english/english_lang.php
INFO - 2018-03-06 17:02:47 --> Model Class Initialized
INFO - 2018-03-06 17:02:47 --> File loaded: /var/www/html/project/periodtracker/application/views//template/side_bar.php
INFO - 2018-03-06 17:02:47 --> File loaded: /var/www/html/project/periodtracker/application/views//template/header.php
INFO - 2018-03-06 17:02:47 --> File loaded: /var/www/html/project/periodtracker/application/views//template/bread_crumb.php
INFO - 2018-03-06 17:02:47 --> File loaded: /var/www/html/project/periodtracker/application/views//template/footer.php
INFO - 2018-03-06 17:02:47 --> File loaded: /var/www/html/project/periodtracker/application/views/dashboard/index.php
INFO - 2018-03-06 17:02:47 --> Final output sent to browser
DEBUG - 2018-03-06 17:02:47 --> Total execution time: 0.0057
INFO - 2018-03-06 17:02:47 --> Config Class Initialized
INFO - 2018-03-06 17:02:47 --> Hooks Class Initialized
DEBUG - 2018-03-06 17:02:47 --> UTF-8 Support Enabled
INFO - 2018-03-06 17:02:47 --> Utf8 Class Initialized
INFO - 2018-03-06 17:02:47 --> URI Class Initialized
INFO - 2018-03-06 17:02:47 --> Router Class Initialized
INFO - 2018-03-06 17:02:47 --> Output Class Initialized
INFO - 2018-03-06 17:02:47 --> Security Class Initialized
DEBUG - 2018-03-06 17:02:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-06 17:02:47 --> Input Class Initialized
INFO - 2018-03-06 17:02:47 --> Language Class Initialized
INFO - 2018-03-06 17:02:47 --> Loader Class Initialized
INFO - 2018-03-06 17:02:47 --> Helper loaded: url_helper
INFO - 2018-03-06 17:02:47 --> Helper loaded: file_helper
INFO - 2018-03-06 17:02:47 --> Helper loaded: email_helper
INFO - 2018-03-06 17:02:47 --> Helper loaded: common_helper
INFO - 2018-03-06 17:02:47 --> Database Driver Class Initialized
DEBUG - 2018-03-06 17:02:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-06 17:02:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-06 17:02:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-03-06 17:02:47 --> Pagination Class Initialized
INFO - 2018-03-06 17:02:47 --> Helper loaded: form_helper
INFO - 2018-03-06 17:02:47 --> Form Validation Class Initialized
INFO - 2018-03-06 17:02:47 --> Model Class Initialized
INFO - 2018-03-06 17:02:47 --> Controller Class Initialized
INFO - 2018-03-06 17:02:47 --> Language file loaded: language/english/english_lang.php
INFO - 2018-03-06 17:02:47 --> Model Class Initialized
INFO - 2018-03-06 17:02:47 --> File loaded: /var/www/html/project/periodtracker/application/views//template/side_bar.php
INFO - 2018-03-06 17:02:47 --> File loaded: /var/www/html/project/periodtracker/application/views//template/header.php
INFO - 2018-03-06 17:02:47 --> File loaded: /var/www/html/project/periodtracker/application/views//template/bread_crumb.php
INFO - 2018-03-06 17:02:47 --> File loaded: /var/www/html/project/periodtracker/application/views//template/footer.php
INFO - 2018-03-06 17:02:47 --> File loaded: /var/www/html/project/periodtracker/application/views/dashboard/index.php
INFO - 2018-03-06 17:02:47 --> Final output sent to browser
DEBUG - 2018-03-06 17:02:47 --> Total execution time: 0.0049
INFO - 2018-03-06 17:02:48 --> Config Class Initialized
INFO - 2018-03-06 17:02:48 --> Hooks Class Initialized
DEBUG - 2018-03-06 17:02:48 --> UTF-8 Support Enabled
INFO - 2018-03-06 17:02:48 --> Utf8 Class Initialized
INFO - 2018-03-06 17:02:48 --> URI Class Initialized
INFO - 2018-03-06 17:02:48 --> Router Class Initialized
INFO - 2018-03-06 17:02:48 --> Output Class Initialized
INFO - 2018-03-06 17:02:48 --> Security Class Initialized
DEBUG - 2018-03-06 17:02:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-06 17:02:48 --> Input Class Initialized
INFO - 2018-03-06 17:02:48 --> Language Class Initialized
INFO - 2018-03-06 17:02:48 --> Loader Class Initialized
INFO - 2018-03-06 17:02:48 --> Helper loaded: url_helper
INFO - 2018-03-06 17:02:48 --> Helper loaded: file_helper
INFO - 2018-03-06 17:02:48 --> Helper loaded: email_helper
INFO - 2018-03-06 17:02:48 --> Helper loaded: common_helper
INFO - 2018-03-06 17:02:48 --> Database Driver Class Initialized
DEBUG - 2018-03-06 17:02:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-06 17:02:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-06 17:02:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-03-06 17:02:48 --> Pagination Class Initialized
INFO - 2018-03-06 17:02:48 --> Helper loaded: form_helper
INFO - 2018-03-06 17:02:48 --> Form Validation Class Initialized
INFO - 2018-03-06 17:02:48 --> Model Class Initialized
INFO - 2018-03-06 17:02:48 --> Controller Class Initialized
INFO - 2018-03-06 17:02:48 --> Language file loaded: language/english/english_lang.php
INFO - 2018-03-06 17:02:48 --> Model Class Initialized
INFO - 2018-03-06 17:02:48 --> File loaded: /var/www/html/project/periodtracker/application/views//template/side_bar.php
INFO - 2018-03-06 17:02:48 --> File loaded: /var/www/html/project/periodtracker/application/views//template/header.php
INFO - 2018-03-06 17:02:48 --> File loaded: /var/www/html/project/periodtracker/application/views//template/bread_crumb.php
INFO - 2018-03-06 17:02:48 --> File loaded: /var/www/html/project/periodtracker/application/views//template/footer.php
INFO - 2018-03-06 17:02:48 --> File loaded: /var/www/html/project/periodtracker/application/views/user/index.php
INFO - 2018-03-06 17:02:48 --> Final output sent to browser
DEBUG - 2018-03-06 17:02:48 --> Total execution time: 0.0049
INFO - 2018-03-06 17:02:49 --> Config Class Initialized
INFO - 2018-03-06 17:02:49 --> Hooks Class Initialized
DEBUG - 2018-03-06 17:02:49 --> UTF-8 Support Enabled
INFO - 2018-03-06 17:02:49 --> Utf8 Class Initialized
INFO - 2018-03-06 17:02:49 --> URI Class Initialized
INFO - 2018-03-06 17:02:49 --> Router Class Initialized
INFO - 2018-03-06 17:02:49 --> Output Class Initialized
INFO - 2018-03-06 17:02:49 --> Security Class Initialized
DEBUG - 2018-03-06 17:02:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-06 17:02:49 --> Input Class Initialized
INFO - 2018-03-06 17:02:49 --> Language Class Initialized
INFO - 2018-03-06 17:02:49 --> Loader Class Initialized
INFO - 2018-03-06 17:02:49 --> Helper loaded: url_helper
INFO - 2018-03-06 17:02:49 --> Helper loaded: file_helper
INFO - 2018-03-06 17:02:49 --> Helper loaded: email_helper
INFO - 2018-03-06 17:02:49 --> Helper loaded: common_helper
INFO - 2018-03-06 17:02:49 --> Database Driver Class Initialized
DEBUG - 2018-03-06 17:02:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-06 17:02:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-06 17:02:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-03-06 17:02:49 --> Pagination Class Initialized
INFO - 2018-03-06 17:02:49 --> Helper loaded: form_helper
INFO - 2018-03-06 17:02:49 --> Form Validation Class Initialized
INFO - 2018-03-06 17:02:49 --> Model Class Initialized
INFO - 2018-03-06 17:02:49 --> Controller Class Initialized
INFO - 2018-03-06 17:02:49 --> Language file loaded: language/english/english_lang.php
INFO - 2018-03-06 17:02:49 --> Model Class Initialized
INFO - 2018-03-06 17:06:46 --> Config Class Initialized
INFO - 2018-03-06 17:06:46 --> Hooks Class Initialized
DEBUG - 2018-03-06 17:06:46 --> UTF-8 Support Enabled
INFO - 2018-03-06 17:06:46 --> Utf8 Class Initialized
INFO - 2018-03-06 17:06:46 --> URI Class Initialized
INFO - 2018-03-06 17:06:46 --> Router Class Initialized
INFO - 2018-03-06 17:06:46 --> Output Class Initialized
INFO - 2018-03-06 17:06:46 --> Security Class Initialized
DEBUG - 2018-03-06 17:06:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-06 17:06:46 --> Input Class Initialized
INFO - 2018-03-06 17:06:46 --> Language Class Initialized
INFO - 2018-03-06 17:06:46 --> Loader Class Initialized
INFO - 2018-03-06 17:06:46 --> Helper loaded: url_helper
INFO - 2018-03-06 17:06:46 --> Helper loaded: file_helper
INFO - 2018-03-06 17:06:46 --> Helper loaded: email_helper
INFO - 2018-03-06 17:06:46 --> Helper loaded: common_helper
INFO - 2018-03-06 17:06:46 --> Database Driver Class Initialized
DEBUG - 2018-03-06 17:06:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-06 17:06:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-06 17:06:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-03-06 17:06:46 --> Pagination Class Initialized
INFO - 2018-03-06 17:06:46 --> Helper loaded: form_helper
INFO - 2018-03-06 17:06:46 --> Form Validation Class Initialized
INFO - 2018-03-06 17:06:46 --> Model Class Initialized
INFO - 2018-03-06 17:06:46 --> Controller Class Initialized
INFO - 2018-03-06 17:06:46 --> Language file loaded: language/english/english_lang.php
INFO - 2018-03-06 17:06:46 --> Model Class Initialized
INFO - 2018-03-06 17:06:46 --> File loaded: /var/www/html/project/periodtracker/application/views//template/side_bar.php
INFO - 2018-03-06 17:06:46 --> File loaded: /var/www/html/project/periodtracker/application/views//template/header.php
INFO - 2018-03-06 17:06:46 --> File loaded: /var/www/html/project/periodtracker/application/views//template/bread_crumb.php
INFO - 2018-03-06 17:06:46 --> File loaded: /var/www/html/project/periodtracker/application/views//template/footer.php
INFO - 2018-03-06 17:06:46 --> File loaded: /var/www/html/project/periodtracker/application/views/dashboard/index.php
INFO - 2018-03-06 17:06:46 --> Final output sent to browser
DEBUG - 2018-03-06 17:06:46 --> Total execution time: 0.0056
INFO - 2018-03-06 17:06:48 --> Config Class Initialized
INFO - 2018-03-06 17:06:48 --> Hooks Class Initialized
DEBUG - 2018-03-06 17:06:48 --> UTF-8 Support Enabled
INFO - 2018-03-06 17:06:48 --> Utf8 Class Initialized
INFO - 2018-03-06 17:06:48 --> URI Class Initialized
INFO - 2018-03-06 17:06:48 --> Router Class Initialized
INFO - 2018-03-06 17:06:48 --> Output Class Initialized
INFO - 2018-03-06 17:06:48 --> Security Class Initialized
DEBUG - 2018-03-06 17:06:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-06 17:06:48 --> Input Class Initialized
INFO - 2018-03-06 17:06:48 --> Language Class Initialized
INFO - 2018-03-06 17:06:48 --> Loader Class Initialized
INFO - 2018-03-06 17:06:48 --> Helper loaded: url_helper
INFO - 2018-03-06 17:06:48 --> Helper loaded: file_helper
INFO - 2018-03-06 17:06:48 --> Helper loaded: email_helper
INFO - 2018-03-06 17:06:48 --> Helper loaded: common_helper
INFO - 2018-03-06 17:06:48 --> Database Driver Class Initialized
DEBUG - 2018-03-06 17:06:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-06 17:06:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-06 17:06:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-03-06 17:06:48 --> Pagination Class Initialized
INFO - 2018-03-06 17:06:48 --> Helper loaded: form_helper
INFO - 2018-03-06 17:06:48 --> Form Validation Class Initialized
INFO - 2018-03-06 17:06:48 --> Model Class Initialized
INFO - 2018-03-06 17:06:48 --> Controller Class Initialized
INFO - 2018-03-06 17:06:48 --> Language file loaded: language/english/english_lang.php
INFO - 2018-03-06 17:06:48 --> Model Class Initialized
INFO - 2018-03-06 17:06:48 --> File loaded: /var/www/html/project/periodtracker/application/views//template/side_bar.php
INFO - 2018-03-06 17:06:48 --> File loaded: /var/www/html/project/periodtracker/application/views//template/header.php
INFO - 2018-03-06 17:06:48 --> File loaded: /var/www/html/project/periodtracker/application/views//template/bread_crumb.php
INFO - 2018-03-06 17:06:48 --> File loaded: /var/www/html/project/periodtracker/application/views//template/footer.php
INFO - 2018-03-06 17:06:48 --> File loaded: /var/www/html/project/periodtracker/application/views/user/index.php
INFO - 2018-03-06 17:06:48 --> Final output sent to browser
DEBUG - 2018-03-06 17:06:48 --> Total execution time: 0.0067
INFO - 2018-03-06 17:06:48 --> Config Class Initialized
INFO - 2018-03-06 17:06:48 --> Hooks Class Initialized
DEBUG - 2018-03-06 17:06:48 --> UTF-8 Support Enabled
INFO - 2018-03-06 17:06:48 --> Utf8 Class Initialized
INFO - 2018-03-06 17:06:48 --> URI Class Initialized
INFO - 2018-03-06 17:06:48 --> Router Class Initialized
INFO - 2018-03-06 17:06:48 --> Output Class Initialized
INFO - 2018-03-06 17:06:48 --> Security Class Initialized
DEBUG - 2018-03-06 17:06:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-06 17:06:48 --> Input Class Initialized
INFO - 2018-03-06 17:06:48 --> Language Class Initialized
INFO - 2018-03-06 17:06:48 --> Loader Class Initialized
INFO - 2018-03-06 17:06:48 --> Helper loaded: url_helper
INFO - 2018-03-06 17:06:48 --> Helper loaded: file_helper
INFO - 2018-03-06 17:06:48 --> Helper loaded: email_helper
INFO - 2018-03-06 17:06:48 --> Helper loaded: common_helper
INFO - 2018-03-06 17:06:48 --> Database Driver Class Initialized
DEBUG - 2018-03-06 17:06:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-06 17:06:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-06 17:06:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-03-06 17:06:48 --> Pagination Class Initialized
INFO - 2018-03-06 17:06:48 --> Helper loaded: form_helper
INFO - 2018-03-06 17:06:48 --> Form Validation Class Initialized
INFO - 2018-03-06 17:06:48 --> Model Class Initialized
INFO - 2018-03-06 17:06:48 --> Controller Class Initialized
INFO - 2018-03-06 17:06:48 --> Language file loaded: language/english/english_lang.php
INFO - 2018-03-06 17:06:48 --> Model Class Initialized
INFO - 2018-03-06 17:06:52 --> Config Class Initialized
INFO - 2018-03-06 17:06:52 --> Hooks Class Initialized
DEBUG - 2018-03-06 17:06:52 --> UTF-8 Support Enabled
INFO - 2018-03-06 17:06:52 --> Utf8 Class Initialized
INFO - 2018-03-06 17:06:52 --> URI Class Initialized
INFO - 2018-03-06 17:06:52 --> Router Class Initialized
INFO - 2018-03-06 17:06:52 --> Output Class Initialized
INFO - 2018-03-06 17:06:52 --> Security Class Initialized
DEBUG - 2018-03-06 17:06:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-06 17:06:52 --> Input Class Initialized
INFO - 2018-03-06 17:06:52 --> Language Class Initialized
INFO - 2018-03-06 17:06:52 --> Loader Class Initialized
INFO - 2018-03-06 17:06:52 --> Helper loaded: url_helper
INFO - 2018-03-06 17:06:52 --> Helper loaded: file_helper
INFO - 2018-03-06 17:06:52 --> Helper loaded: email_helper
INFO - 2018-03-06 17:06:52 --> Helper loaded: common_helper
INFO - 2018-03-06 17:06:52 --> Database Driver Class Initialized
DEBUG - 2018-03-06 17:06:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-06 17:06:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-06 17:06:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-03-06 17:06:52 --> Pagination Class Initialized
INFO - 2018-03-06 17:06:52 --> Helper loaded: form_helper
INFO - 2018-03-06 17:06:52 --> Form Validation Class Initialized
INFO - 2018-03-06 17:06:52 --> Model Class Initialized
INFO - 2018-03-06 17:06:52 --> Controller Class Initialized
INFO - 2018-03-06 17:06:52 --> Language file loaded: language/english/english_lang.php
INFO - 2018-03-06 17:06:52 --> Model Class Initialized
INFO - 2018-03-06 17:06:52 --> Model Class Initialized
INFO - 2018-03-06 17:06:52 --> File loaded: /var/www/html/project/periodtracker/application/views//template/side_bar.php
INFO - 2018-03-06 17:06:52 --> File loaded: /var/www/html/project/periodtracker/application/views//template/header.php
INFO - 2018-03-06 17:06:52 --> File loaded: /var/www/html/project/periodtracker/application/views//template/bread_crumb.php
INFO - 2018-03-06 17:06:52 --> File loaded: /var/www/html/project/periodtracker/application/views//template/footer.php
INFO - 2018-03-06 17:06:52 --> File loaded: /var/www/html/project/periodtracker/application/views/thermometersubscription/index.php
INFO - 2018-03-06 17:06:52 --> Final output sent to browser
DEBUG - 2018-03-06 17:06:52 --> Total execution time: 0.0073
INFO - 2018-03-06 17:07:01 --> Config Class Initialized
INFO - 2018-03-06 17:07:01 --> Hooks Class Initialized
DEBUG - 2018-03-06 17:07:01 --> UTF-8 Support Enabled
INFO - 2018-03-06 17:07:01 --> Utf8 Class Initialized
INFO - 2018-03-06 17:07:01 --> URI Class Initialized
INFO - 2018-03-06 17:07:01 --> Router Class Initialized
INFO - 2018-03-06 17:07:01 --> Output Class Initialized
INFO - 2018-03-06 17:07:01 --> Security Class Initialized
DEBUG - 2018-03-06 17:07:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-06 17:07:01 --> Input Class Initialized
INFO - 2018-03-06 17:07:01 --> Language Class Initialized
INFO - 2018-03-06 17:07:01 --> Loader Class Initialized
INFO - 2018-03-06 17:07:01 --> Helper loaded: url_helper
INFO - 2018-03-06 17:07:01 --> Helper loaded: file_helper
INFO - 2018-03-06 17:07:01 --> Helper loaded: email_helper
INFO - 2018-03-06 17:07:01 --> Helper loaded: common_helper
INFO - 2018-03-06 17:07:01 --> Database Driver Class Initialized
DEBUG - 2018-03-06 17:07:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-06 17:07:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-06 17:07:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-03-06 17:07:01 --> Pagination Class Initialized
INFO - 2018-03-06 17:07:01 --> Helper loaded: form_helper
INFO - 2018-03-06 17:07:01 --> Form Validation Class Initialized
INFO - 2018-03-06 17:07:01 --> Model Class Initialized
INFO - 2018-03-06 17:07:01 --> Controller Class Initialized
INFO - 2018-03-06 17:07:01 --> Language file loaded: language/english/english_lang.php
INFO - 2018-03-06 17:07:01 --> Model Class Initialized
INFO - 2018-03-06 17:07:01 --> Model Class Initialized
INFO - 2018-03-06 17:07:01 --> File loaded: /var/www/html/project/periodtracker/application/views//template/side_bar.php
INFO - 2018-03-06 17:07:01 --> File loaded: /var/www/html/project/periodtracker/application/views//template/header.php
INFO - 2018-03-06 17:07:01 --> File loaded: /var/www/html/project/periodtracker/application/views//template/bread_crumb.php
INFO - 2018-03-06 17:07:01 --> File loaded: /var/www/html/project/periodtracker/application/views//template/footer.php
INFO - 2018-03-06 17:07:01 --> File loaded: /var/www/html/project/periodtracker/application/views/thermometersubscription/sendGift.php
INFO - 2018-03-06 17:07:01 --> Final output sent to browser
DEBUG - 2018-03-06 17:07:01 --> Total execution time: 0.0060
INFO - 2018-03-06 17:07:38 --> Config Class Initialized
INFO - 2018-03-06 17:07:38 --> Hooks Class Initialized
DEBUG - 2018-03-06 17:07:38 --> UTF-8 Support Enabled
INFO - 2018-03-06 17:07:38 --> Utf8 Class Initialized
INFO - 2018-03-06 17:07:38 --> URI Class Initialized
INFO - 2018-03-06 17:07:38 --> Router Class Initialized
INFO - 2018-03-06 17:07:38 --> Output Class Initialized
INFO - 2018-03-06 17:07:38 --> Security Class Initialized
DEBUG - 2018-03-06 17:07:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-06 17:07:38 --> Input Class Initialized
INFO - 2018-03-06 17:07:38 --> Language Class Initialized
INFO - 2018-03-06 17:07:38 --> Loader Class Initialized
INFO - 2018-03-06 17:07:38 --> Helper loaded: url_helper
INFO - 2018-03-06 17:07:38 --> Helper loaded: file_helper
INFO - 2018-03-06 17:07:38 --> Helper loaded: email_helper
INFO - 2018-03-06 17:07:38 --> Helper loaded: common_helper
INFO - 2018-03-06 17:07:38 --> Database Driver Class Initialized
DEBUG - 2018-03-06 17:07:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-06 17:07:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-06 17:07:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-03-06 17:07:38 --> Pagination Class Initialized
INFO - 2018-03-06 17:07:38 --> Helper loaded: form_helper
INFO - 2018-03-06 17:07:38 --> Form Validation Class Initialized
INFO - 2018-03-06 17:07:38 --> Model Class Initialized
INFO - 2018-03-06 17:07:38 --> Controller Class Initialized
INFO - 2018-03-06 17:07:38 --> Language file loaded: language/english/english_lang.php
INFO - 2018-03-06 17:07:38 --> Model Class Initialized
INFO - 2018-03-06 17:07:38 --> Model Class Initialized
INFO - 2018-03-06 17:07:38 --> File loaded: /var/www/html/project/periodtracker/application/views//template/side_bar.php
INFO - 2018-03-06 17:07:38 --> File loaded: /var/www/html/project/periodtracker/application/views//template/header.php
INFO - 2018-03-06 17:07:38 --> File loaded: /var/www/html/project/periodtracker/application/views//template/bread_crumb.php
INFO - 2018-03-06 17:07:38 --> File loaded: /var/www/html/project/periodtracker/application/views//template/footer.php
INFO - 2018-03-06 17:07:38 --> File loaded: /var/www/html/project/periodtracker/application/views/thermometersubscription/sendGift.php
INFO - 2018-03-06 17:07:38 --> Final output sent to browser
DEBUG - 2018-03-06 17:07:38 --> Total execution time: 0.0070
INFO - 2018-03-06 17:07:41 --> Config Class Initialized
INFO - 2018-03-06 17:07:41 --> Hooks Class Initialized
DEBUG - 2018-03-06 17:07:41 --> UTF-8 Support Enabled
INFO - 2018-03-06 17:07:41 --> Utf8 Class Initialized
INFO - 2018-03-06 17:07:41 --> URI Class Initialized
INFO - 2018-03-06 17:07:41 --> Router Class Initialized
INFO - 2018-03-06 17:07:41 --> Output Class Initialized
INFO - 2018-03-06 17:07:41 --> Security Class Initialized
DEBUG - 2018-03-06 17:07:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-06 17:07:41 --> Input Class Initialized
INFO - 2018-03-06 17:07:41 --> Language Class Initialized
INFO - 2018-03-06 17:07:41 --> Loader Class Initialized
INFO - 2018-03-06 17:07:41 --> Helper loaded: url_helper
INFO - 2018-03-06 17:07:41 --> Helper loaded: file_helper
INFO - 2018-03-06 17:07:41 --> Helper loaded: email_helper
INFO - 2018-03-06 17:07:41 --> Helper loaded: common_helper
INFO - 2018-03-06 17:07:41 --> Database Driver Class Initialized
DEBUG - 2018-03-06 17:07:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-06 17:07:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-06 17:07:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-03-06 17:07:41 --> Pagination Class Initialized
INFO - 2018-03-06 17:07:41 --> Helper loaded: form_helper
INFO - 2018-03-06 17:07:41 --> Form Validation Class Initialized
INFO - 2018-03-06 17:07:41 --> Model Class Initialized
INFO - 2018-03-06 17:07:41 --> Controller Class Initialized
INFO - 2018-03-06 17:07:41 --> Language file loaded: language/english/english_lang.php
INFO - 2018-03-06 17:07:41 --> Model Class Initialized
INFO - 2018-03-06 17:07:41 --> Model Class Initialized
DEBUG - 2018-03-06 17:07:41 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-06 17:07:41 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-03-06 17:07:41 --> Config Class Initialized
INFO - 2018-03-06 17:07:41 --> Hooks Class Initialized
DEBUG - 2018-03-06 17:07:41 --> UTF-8 Support Enabled
INFO - 2018-03-06 17:07:41 --> Utf8 Class Initialized
INFO - 2018-03-06 17:07:41 --> URI Class Initialized
INFO - 2018-03-06 17:07:41 --> Router Class Initialized
INFO - 2018-03-06 17:07:41 --> Output Class Initialized
INFO - 2018-03-06 17:07:41 --> Security Class Initialized
DEBUG - 2018-03-06 17:07:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-06 17:07:41 --> Input Class Initialized
INFO - 2018-03-06 17:07:41 --> Language Class Initialized
INFO - 2018-03-06 17:07:41 --> Loader Class Initialized
INFO - 2018-03-06 17:07:41 --> Helper loaded: url_helper
INFO - 2018-03-06 17:07:41 --> Helper loaded: file_helper
INFO - 2018-03-06 17:07:41 --> Helper loaded: email_helper
INFO - 2018-03-06 17:07:41 --> Config Class Initialized
INFO - 2018-03-06 17:07:41 --> Helper loaded: common_helper
INFO - 2018-03-06 17:07:41 --> Hooks Class Initialized
INFO - 2018-03-06 17:07:41 --> Database Driver Class Initialized
DEBUG - 2018-03-06 17:07:41 --> UTF-8 Support Enabled
INFO - 2018-03-06 17:07:41 --> Utf8 Class Initialized
INFO - 2018-03-06 17:07:41 --> URI Class Initialized
INFO - 2018-03-06 17:07:41 --> Router Class Initialized
INFO - 2018-03-06 17:07:41 --> Output Class Initialized
INFO - 2018-03-06 17:07:41 --> Security Class Initialized
DEBUG - 2018-03-06 17:07:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-06 17:07:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-06 17:07:41 --> Input Class Initialized
INFO - 2018-03-06 17:07:41 --> Language Class Initialized
INFO - 2018-03-06 17:07:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-06 17:07:41 --> Loader Class Initialized
INFO - 2018-03-06 17:07:41 --> Helper loaded: url_helper
INFO - 2018-03-06 17:07:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-03-06 17:07:41 --> Helper loaded: file_helper
INFO - 2018-03-06 17:07:41 --> Pagination Class Initialized
INFO - 2018-03-06 17:07:41 --> Helper loaded: email_helper
INFO - 2018-03-06 17:07:41 --> Helper loaded: common_helper
INFO - 2018-03-06 17:07:41 --> Helper loaded: form_helper
INFO - 2018-03-06 17:07:41 --> Database Driver Class Initialized
INFO - 2018-03-06 17:07:41 --> Form Validation Class Initialized
INFO - 2018-03-06 17:07:41 --> Model Class Initialized
INFO - 2018-03-06 17:07:41 --> Controller Class Initialized
INFO - 2018-03-06 17:07:41 --> Language file loaded: language/english/english_lang.php
INFO - 2018-03-06 17:07:41 --> Model Class Initialized
INFO - 2018-03-06 17:07:41 --> Model Class Initialized
DEBUG - 2018-03-06 17:07:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-06 17:07:41 --> Model Class Initialized
INFO - 2018-03-06 17:07:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-06 17:07:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-03-06 17:07:41 --> Pagination Class Initialized
INFO - 2018-03-06 17:07:41 --> Helper loaded: form_helper
INFO - 2018-03-06 17:07:41 --> Form Validation Class Initialized
INFO - 2018-03-06 17:07:41 --> Model Class Initialized
INFO - 2018-03-06 17:07:41 --> Email Class Initialized
INFO - 2018-03-06 17:07:41 --> Controller Class Initialized
INFO - 2018-03-06 17:07:41 --> Language file loaded: language/english/english_lang.php
INFO - 2018-03-06 17:07:41 --> Model Class Initialized
INFO - 2018-03-06 17:07:41 --> Model Class Initialized
INFO - 2018-03-06 17:07:41 --> File loaded: /var/www/html/project/periodtracker/application/views//template/side_bar.php
INFO - 2018-03-06 17:07:41 --> File loaded: /var/www/html/project/periodtracker/application/views//template/header.php
INFO - 2018-03-06 17:07:41 --> File loaded: /var/www/html/project/periodtracker/application/views//template/bread_crumb.php
INFO - 2018-03-06 17:07:41 --> File loaded: /var/www/html/project/periodtracker/application/views//template/footer.php
INFO - 2018-03-06 17:07:41 --> File loaded: /var/www/html/project/periodtracker/application/views/thermometersubscription/index.php
INFO - 2018-03-06 17:07:41 --> Final output sent to browser
DEBUG - 2018-03-06 17:07:41 --> Total execution time: 0.0065
INFO - 2018-03-06 17:07:42 --> Language file loaded: language/english/email_lang.php

<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2018-11-27 06:48:37 --> Config Class Initialized
INFO - 2018-11-27 06:48:37 --> Hooks Class Initialized
DEBUG - 2018-11-27 06:48:37 --> UTF-8 Support Enabled
INFO - 2018-11-27 06:48:37 --> Utf8 Class Initialized
INFO - 2018-11-27 06:48:38 --> URI Class Initialized
INFO - 2018-11-27 06:48:38 --> Router Class Initialized
INFO - 2018-11-27 06:48:38 --> Output Class Initialized
INFO - 2018-11-27 06:48:38 --> Security Class Initialized
DEBUG - 2018-11-27 06:48:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-27 06:48:38 --> Input Class Initialized
INFO - 2018-11-27 06:48:38 --> Language Class Initialized
INFO - 2018-11-27 06:48:38 --> Loader Class Initialized
INFO - 2018-11-27 06:48:38 --> Helper loaded: url_helper
INFO - 2018-11-27 06:48:38 --> Helper loaded: file_helper
INFO - 2018-11-27 06:48:38 --> Helper loaded: email_helper
INFO - 2018-11-27 06:48:38 --> Helper loaded: common_helper
INFO - 2018-11-27 06:48:38 --> Database Driver Class Initialized
DEBUG - 2018-11-27 06:48:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-27 06:48:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-27 06:48:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-27 06:48:38 --> Pagination Class Initialized
INFO - 2018-11-27 06:48:38 --> Helper loaded: form_helper
INFO - 2018-11-27 06:48:38 --> Form Validation Class Initialized
INFO - 2018-11-27 06:48:38 --> Model Class Initialized
INFO - 2018-11-27 06:48:38 --> Controller Class Initialized
INFO - 2018-11-27 06:48:38 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-27 06:48:38 --> Model Class Initialized
INFO - 2018-11-27 06:48:38 --> Model Class Initialized
INFO - 2018-11-27 06:48:38 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/index.php
INFO - 2018-11-27 06:48:38 --> Final output sent to browser
DEBUG - 2018-11-27 06:48:38 --> Total execution time: 1.3361
INFO - 2018-11-27 07:37:57 --> Config Class Initialized
INFO - 2018-11-27 07:37:57 --> Hooks Class Initialized
DEBUG - 2018-11-27 07:37:57 --> UTF-8 Support Enabled
INFO - 2018-11-27 07:37:57 --> Utf8 Class Initialized
INFO - 2018-11-27 07:37:57 --> URI Class Initialized
INFO - 2018-11-27 07:37:57 --> Router Class Initialized
INFO - 2018-11-27 07:37:57 --> Output Class Initialized
INFO - 2018-11-27 07:37:57 --> Security Class Initialized
DEBUG - 2018-11-27 07:37:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-27 07:37:57 --> Input Class Initialized
INFO - 2018-11-27 07:37:57 --> Language Class Initialized
INFO - 2018-11-27 07:37:57 --> Loader Class Initialized
INFO - 2018-11-27 07:37:57 --> Helper loaded: url_helper
INFO - 2018-11-27 07:37:57 --> Helper loaded: file_helper
INFO - 2018-11-27 07:37:57 --> Helper loaded: email_helper
INFO - 2018-11-27 07:37:57 --> Helper loaded: common_helper
INFO - 2018-11-27 07:37:57 --> Database Driver Class Initialized
DEBUG - 2018-11-27 07:37:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-27 07:37:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-27 07:37:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-27 07:37:57 --> Pagination Class Initialized
INFO - 2018-11-27 07:37:57 --> Helper loaded: form_helper
INFO - 2018-11-27 07:37:57 --> Form Validation Class Initialized
INFO - 2018-11-27 07:37:57 --> Model Class Initialized
INFO - 2018-11-27 07:37:57 --> Controller Class Initialized
INFO - 2018-11-27 07:37:57 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-27 07:37:57 --> Model Class Initialized
INFO - 2018-11-27 07:37:57 --> Model Class Initialized
INFO - 2018-11-27 07:37:57 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/index.php
INFO - 2018-11-27 07:37:57 --> Final output sent to browser
DEBUG - 2018-11-27 07:37:57 --> Total execution time: 0.1140
INFO - 2018-11-27 07:38:00 --> Config Class Initialized
INFO - 2018-11-27 07:38:00 --> Hooks Class Initialized
DEBUG - 2018-11-27 07:38:00 --> UTF-8 Support Enabled
INFO - 2018-11-27 07:38:00 --> Utf8 Class Initialized
INFO - 2018-11-27 07:38:00 --> URI Class Initialized
INFO - 2018-11-27 07:38:00 --> Router Class Initialized
INFO - 2018-11-27 07:38:00 --> Output Class Initialized
INFO - 2018-11-27 07:38:00 --> Security Class Initialized
DEBUG - 2018-11-27 07:38:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-27 07:38:00 --> Input Class Initialized
INFO - 2018-11-27 07:38:00 --> Language Class Initialized
INFO - 2018-11-27 07:38:00 --> Loader Class Initialized
INFO - 2018-11-27 07:38:00 --> Helper loaded: url_helper
INFO - 2018-11-27 07:38:00 --> Helper loaded: file_helper
INFO - 2018-11-27 07:38:00 --> Helper loaded: email_helper
INFO - 2018-11-27 07:38:00 --> Helper loaded: common_helper
INFO - 2018-11-27 07:38:00 --> Database Driver Class Initialized
DEBUG - 2018-11-27 07:38:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-27 07:38:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-27 07:38:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-27 07:38:00 --> Pagination Class Initialized
INFO - 2018-11-27 07:38:00 --> Helper loaded: form_helper
INFO - 2018-11-27 07:38:00 --> Form Validation Class Initialized
INFO - 2018-11-27 07:38:00 --> Model Class Initialized
INFO - 2018-11-27 07:38:00 --> Controller Class Initialized
INFO - 2018-11-27 07:38:00 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-27 07:38:00 --> Model Class Initialized
INFO - 2018-11-27 07:38:00 --> Model Class Initialized
ERROR - 2018-11-27 07:38:00 --> Severity: Notice --> Undefined index: remember_me C:\xampp\htdocs\wetinuneed\application\controllers\admin\Admin.php 78
INFO - 2018-11-27 07:38:00 --> Config Class Initialized
INFO - 2018-11-27 07:38:00 --> Hooks Class Initialized
DEBUG - 2018-11-27 07:38:00 --> UTF-8 Support Enabled
INFO - 2018-11-27 07:38:00 --> Utf8 Class Initialized
INFO - 2018-11-27 07:38:00 --> URI Class Initialized
INFO - 2018-11-27 07:38:00 --> Router Class Initialized
INFO - 2018-11-27 07:38:00 --> Output Class Initialized
INFO - 2018-11-27 07:38:00 --> Security Class Initialized
DEBUG - 2018-11-27 07:38:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-27 07:38:00 --> Input Class Initialized
INFO - 2018-11-27 07:38:00 --> Language Class Initialized
INFO - 2018-11-27 07:38:00 --> Loader Class Initialized
INFO - 2018-11-27 07:38:00 --> Helper loaded: url_helper
INFO - 2018-11-27 07:38:00 --> Helper loaded: file_helper
INFO - 2018-11-27 07:38:00 --> Helper loaded: email_helper
INFO - 2018-11-27 07:38:00 --> Helper loaded: common_helper
INFO - 2018-11-27 07:38:00 --> Database Driver Class Initialized
DEBUG - 2018-11-27 07:38:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-27 07:38:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-27 07:38:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-27 07:38:00 --> Pagination Class Initialized
INFO - 2018-11-27 07:38:00 --> Helper loaded: form_helper
INFO - 2018-11-27 07:38:00 --> Form Validation Class Initialized
INFO - 2018-11-27 07:38:00 --> Model Class Initialized
INFO - 2018-11-27 07:38:00 --> Controller Class Initialized
INFO - 2018-11-27 07:38:00 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-27 07:38:00 --> Model Class Initialized
INFO - 2018-11-27 07:38:00 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-27 07:38:00 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/sidebar.php
INFO - 2018-11-27 07:38:00 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/right-sidebar.php
INFO - 2018-11-27 07:38:00 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/footer.php
INFO - 2018-11-27 07:38:00 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/dashboard.php
INFO - 2018-11-27 07:38:00 --> Final output sent to browser
DEBUG - 2018-11-27 07:38:00 --> Total execution time: 0.1070
INFO - 2018-11-27 07:38:06 --> Config Class Initialized
INFO - 2018-11-27 07:38:06 --> Hooks Class Initialized
DEBUG - 2018-11-27 07:38:06 --> UTF-8 Support Enabled
INFO - 2018-11-27 07:38:06 --> Utf8 Class Initialized
INFO - 2018-11-27 07:38:06 --> URI Class Initialized
INFO - 2018-11-27 07:38:06 --> Router Class Initialized
INFO - 2018-11-27 07:38:06 --> Output Class Initialized
INFO - 2018-11-27 07:38:06 --> Security Class Initialized
DEBUG - 2018-11-27 07:38:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-27 07:38:06 --> Input Class Initialized
INFO - 2018-11-27 07:38:06 --> Language Class Initialized
ERROR - 2018-11-27 07:38:06 --> 404 Page Not Found: My_controller/index
INFO - 2018-11-27 07:38:21 --> Config Class Initialized
INFO - 2018-11-27 07:38:21 --> Hooks Class Initialized
DEBUG - 2018-11-27 07:38:21 --> UTF-8 Support Enabled
INFO - 2018-11-27 07:38:21 --> Utf8 Class Initialized
INFO - 2018-11-27 07:38:21 --> URI Class Initialized
INFO - 2018-11-27 07:38:21 --> Router Class Initialized
INFO - 2018-11-27 07:38:21 --> Output Class Initialized
INFO - 2018-11-27 07:38:21 --> Security Class Initialized
DEBUG - 2018-11-27 07:38:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-27 07:38:21 --> Input Class Initialized
INFO - 2018-11-27 07:38:21 --> Language Class Initialized
ERROR - 2018-11-27 07:38:21 --> 404 Page Not Found: Payment/My_controller
INFO - 2018-11-27 07:39:14 --> Config Class Initialized
INFO - 2018-11-27 07:39:14 --> Hooks Class Initialized
DEBUG - 2018-11-27 07:39:14 --> UTF-8 Support Enabled
INFO - 2018-11-27 07:39:14 --> Utf8 Class Initialized
INFO - 2018-11-27 07:39:14 --> URI Class Initialized
INFO - 2018-11-27 07:39:14 --> Router Class Initialized
INFO - 2018-11-27 07:39:14 --> Output Class Initialized
INFO - 2018-11-27 07:39:14 --> Security Class Initialized
DEBUG - 2018-11-27 07:39:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-27 07:39:14 --> Input Class Initialized
INFO - 2018-11-27 07:39:14 --> Language Class Initialized
INFO - 2018-11-27 07:39:14 --> Loader Class Initialized
INFO - 2018-11-27 07:39:14 --> Helper loaded: url_helper
INFO - 2018-11-27 07:39:14 --> Helper loaded: file_helper
INFO - 2018-11-27 07:39:14 --> Helper loaded: email_helper
INFO - 2018-11-27 07:39:14 --> Helper loaded: common_helper
INFO - 2018-11-27 07:39:14 --> Database Driver Class Initialized
DEBUG - 2018-11-27 07:39:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-27 07:39:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-27 07:39:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-27 07:39:14 --> Pagination Class Initialized
INFO - 2018-11-27 07:39:14 --> Helper loaded: form_helper
INFO - 2018-11-27 07:39:14 --> Form Validation Class Initialized
INFO - 2018-11-27 07:39:14 --> Model Class Initialized
INFO - 2018-11-27 07:39:14 --> Controller Class Initialized
INFO - 2018-11-27 07:39:14 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\payment/form1.php
INFO - 2018-11-27 07:39:14 --> Final output sent to browser
DEBUG - 2018-11-27 07:39:14 --> Total execution time: 0.0830
INFO - 2018-11-27 07:39:14 --> Config Class Initialized
INFO - 2018-11-27 07:39:14 --> Hooks Class Initialized
DEBUG - 2018-11-27 07:39:14 --> UTF-8 Support Enabled
INFO - 2018-11-27 07:39:14 --> Utf8 Class Initialized
INFO - 2018-11-27 07:39:14 --> URI Class Initialized
INFO - 2018-11-27 07:39:14 --> Router Class Initialized
INFO - 2018-11-27 07:39:14 --> Output Class Initialized
INFO - 2018-11-27 07:39:14 --> Security Class Initialized
DEBUG - 2018-11-27 07:39:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-27 07:39:14 --> Input Class Initialized
INFO - 2018-11-27 07:39:14 --> Language Class Initialized
ERROR - 2018-11-27 07:39:14 --> 404 Page Not Found: payment/Bootstrap/css
INFO - 2018-11-27 07:39:15 --> Config Class Initialized
INFO - 2018-11-27 07:39:15 --> Hooks Class Initialized
DEBUG - 2018-11-27 07:39:15 --> UTF-8 Support Enabled
INFO - 2018-11-27 07:39:15 --> Utf8 Class Initialized
INFO - 2018-11-27 07:39:15 --> URI Class Initialized
INFO - 2018-11-27 07:39:15 --> Router Class Initialized
INFO - 2018-11-27 07:39:15 --> Output Class Initialized
INFO - 2018-11-27 07:39:15 --> Security Class Initialized
DEBUG - 2018-11-27 07:39:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-27 07:39:15 --> Input Class Initialized
INFO - 2018-11-27 07:39:15 --> Language Class Initialized
ERROR - 2018-11-27 07:39:15 --> 404 Page Not Found: payment/Img/favicon.png
INFO - 2018-11-27 07:39:43 --> Config Class Initialized
INFO - 2018-11-27 07:39:43 --> Hooks Class Initialized
DEBUG - 2018-11-27 07:39:43 --> UTF-8 Support Enabled
INFO - 2018-11-27 07:39:43 --> Utf8 Class Initialized
INFO - 2018-11-27 07:39:43 --> URI Class Initialized
INFO - 2018-11-27 07:39:43 --> Router Class Initialized
INFO - 2018-11-27 07:39:43 --> Output Class Initialized
INFO - 2018-11-27 07:39:43 --> Security Class Initialized
DEBUG - 2018-11-27 07:39:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-27 07:39:43 --> Input Class Initialized
INFO - 2018-11-27 07:39:43 --> Language Class Initialized
ERROR - 2018-11-27 07:39:43 --> 404 Page Not Found: My_controller/check
INFO - 2018-11-27 07:40:49 --> Config Class Initialized
INFO - 2018-11-27 07:40:49 --> Hooks Class Initialized
DEBUG - 2018-11-27 07:40:49 --> UTF-8 Support Enabled
INFO - 2018-11-27 07:40:49 --> Utf8 Class Initialized
INFO - 2018-11-27 07:40:49 --> URI Class Initialized
INFO - 2018-11-27 07:40:49 --> Router Class Initialized
INFO - 2018-11-27 07:40:49 --> Output Class Initialized
INFO - 2018-11-27 07:40:49 --> Security Class Initialized
DEBUG - 2018-11-27 07:40:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-27 07:40:49 --> Input Class Initialized
INFO - 2018-11-27 07:40:49 --> Language Class Initialized
INFO - 2018-11-27 07:40:49 --> Loader Class Initialized
INFO - 2018-11-27 07:40:49 --> Helper loaded: url_helper
INFO - 2018-11-27 07:40:49 --> Helper loaded: file_helper
INFO - 2018-11-27 07:40:49 --> Helper loaded: email_helper
INFO - 2018-11-27 07:40:49 --> Helper loaded: common_helper
INFO - 2018-11-27 07:40:49 --> Database Driver Class Initialized
DEBUG - 2018-11-27 07:40:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-27 07:40:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-27 07:40:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-27 07:40:49 --> Pagination Class Initialized
INFO - 2018-11-27 07:40:49 --> Helper loaded: form_helper
INFO - 2018-11-27 07:40:49 --> Form Validation Class Initialized
INFO - 2018-11-27 07:40:49 --> Model Class Initialized
INFO - 2018-11-27 07:40:49 --> Controller Class Initialized
INFO - 2018-11-27 07:40:49 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\payment/form1.php
INFO - 2018-11-27 07:40:49 --> Final output sent to browser
DEBUG - 2018-11-27 07:40:49 --> Total execution time: 0.0600
INFO - 2018-11-27 07:40:56 --> Config Class Initialized
INFO - 2018-11-27 07:40:56 --> Hooks Class Initialized
DEBUG - 2018-11-27 07:40:56 --> UTF-8 Support Enabled
INFO - 2018-11-27 07:40:56 --> Utf8 Class Initialized
INFO - 2018-11-27 07:40:56 --> URI Class Initialized
INFO - 2018-11-27 07:40:56 --> Router Class Initialized
INFO - 2018-11-27 07:40:56 --> Output Class Initialized
INFO - 2018-11-27 07:40:56 --> Security Class Initialized
DEBUG - 2018-11-27 07:40:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-27 07:40:56 --> Input Class Initialized
INFO - 2018-11-27 07:40:56 --> Language Class Initialized
INFO - 2018-11-27 07:40:56 --> Loader Class Initialized
INFO - 2018-11-27 07:40:56 --> Helper loaded: url_helper
INFO - 2018-11-27 07:40:56 --> Helper loaded: file_helper
INFO - 2018-11-27 07:40:56 --> Helper loaded: email_helper
INFO - 2018-11-27 07:40:56 --> Helper loaded: common_helper
INFO - 2018-11-27 07:40:56 --> Database Driver Class Initialized
DEBUG - 2018-11-27 07:40:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-27 07:40:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-27 07:40:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-27 07:40:56 --> Pagination Class Initialized
INFO - 2018-11-27 07:40:56 --> Helper loaded: form_helper
INFO - 2018-11-27 07:40:56 --> Form Validation Class Initialized
INFO - 2018-11-27 07:40:56 --> Model Class Initialized
INFO - 2018-11-27 07:40:56 --> Controller Class Initialized
ERROR - 2018-11-27 07:40:56 --> Severity: Notice --> Undefined variable: pinfo C:\xampp\htdocs\wetinuneed\application\views\payment\confirmation.php 39
INFO - 2018-11-27 07:40:56 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\payment/confirmation.php
INFO - 2018-11-27 07:40:56 --> Final output sent to browser
DEBUG - 2018-11-27 07:40:56 --> Total execution time: 0.0860
INFO - 2018-11-27 07:40:56 --> Config Class Initialized
INFO - 2018-11-27 07:40:56 --> Hooks Class Initialized
DEBUG - 2018-11-27 07:40:56 --> UTF-8 Support Enabled
INFO - 2018-11-27 07:40:56 --> Utf8 Class Initialized
INFO - 2018-11-27 07:40:56 --> URI Class Initialized
INFO - 2018-11-27 07:40:56 --> Router Class Initialized
INFO - 2018-11-27 07:40:56 --> Output Class Initialized
INFO - 2018-11-27 07:40:56 --> Security Class Initialized
DEBUG - 2018-11-27 07:40:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-27 07:40:56 --> Input Class Initialized
INFO - 2018-11-27 07:40:56 --> Language Class Initialized
ERROR - 2018-11-27 07:40:56 --> 404 Page Not Found: payment/My_controller/bootstrap
INFO - 2018-11-27 07:40:57 --> Config Class Initialized
INFO - 2018-11-27 07:40:57 --> Hooks Class Initialized
DEBUG - 2018-11-27 07:40:57 --> UTF-8 Support Enabled
INFO - 2018-11-27 07:40:57 --> Utf8 Class Initialized
INFO - 2018-11-27 07:40:57 --> URI Class Initialized
INFO - 2018-11-27 07:40:57 --> Router Class Initialized
INFO - 2018-11-27 07:40:57 --> Output Class Initialized
INFO - 2018-11-27 07:40:57 --> Security Class Initialized
DEBUG - 2018-11-27 07:40:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-27 07:40:57 --> Input Class Initialized
INFO - 2018-11-27 07:40:57 --> Language Class Initialized
ERROR - 2018-11-27 07:40:57 --> 404 Page Not Found: payment/My_controller/favicon.png
INFO - 2018-11-27 07:44:40 --> Config Class Initialized
INFO - 2018-11-27 07:44:40 --> Hooks Class Initialized
DEBUG - 2018-11-27 07:44:40 --> UTF-8 Support Enabled
INFO - 2018-11-27 07:44:40 --> Utf8 Class Initialized
INFO - 2018-11-27 07:44:40 --> URI Class Initialized
INFO - 2018-11-27 07:44:40 --> Router Class Initialized
INFO - 2018-11-27 07:44:40 --> Output Class Initialized
INFO - 2018-11-27 07:44:40 --> Security Class Initialized
DEBUG - 2018-11-27 07:44:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-27 07:44:40 --> Input Class Initialized
INFO - 2018-11-27 07:44:40 --> Language Class Initialized
INFO - 2018-11-27 07:44:40 --> Loader Class Initialized
INFO - 2018-11-27 07:44:40 --> Helper loaded: url_helper
INFO - 2018-11-27 07:44:40 --> Helper loaded: file_helper
INFO - 2018-11-27 07:44:40 --> Helper loaded: email_helper
INFO - 2018-11-27 07:44:40 --> Helper loaded: common_helper
INFO - 2018-11-27 07:44:40 --> Database Driver Class Initialized
DEBUG - 2018-11-27 07:44:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-27 07:44:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-27 07:44:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-27 07:44:40 --> Pagination Class Initialized
INFO - 2018-11-27 07:44:40 --> Helper loaded: form_helper
INFO - 2018-11-27 07:44:40 --> Form Validation Class Initialized
INFO - 2018-11-27 07:44:40 --> Model Class Initialized
INFO - 2018-11-27 07:44:40 --> Controller Class Initialized
INFO - 2018-11-27 07:44:40 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\payment/form1.php
INFO - 2018-11-27 07:44:40 --> Final output sent to browser
DEBUG - 2018-11-27 07:44:40 --> Total execution time: 0.0680
INFO - 2018-11-27 07:44:40 --> Config Class Initialized
INFO - 2018-11-27 07:44:40 --> Hooks Class Initialized
DEBUG - 2018-11-27 07:44:40 --> UTF-8 Support Enabled
INFO - 2018-11-27 07:44:40 --> Utf8 Class Initialized
INFO - 2018-11-27 07:44:40 --> URI Class Initialized
INFO - 2018-11-27 07:44:40 --> Router Class Initialized
INFO - 2018-11-27 07:44:40 --> Output Class Initialized
INFO - 2018-11-27 07:44:40 --> Security Class Initialized
DEBUG - 2018-11-27 07:44:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-27 07:44:40 --> Input Class Initialized
INFO - 2018-11-27 07:44:40 --> Language Class Initialized
ERROR - 2018-11-27 07:44:40 --> 404 Page Not Found: payment/Bootstrap/css
INFO - 2018-11-27 07:44:40 --> Config Class Initialized
INFO - 2018-11-27 07:44:40 --> Hooks Class Initialized
DEBUG - 2018-11-27 07:44:40 --> UTF-8 Support Enabled
INFO - 2018-11-27 07:44:40 --> Utf8 Class Initialized
INFO - 2018-11-27 07:44:40 --> URI Class Initialized
INFO - 2018-11-27 07:44:40 --> Router Class Initialized
INFO - 2018-11-27 07:44:40 --> Output Class Initialized
INFO - 2018-11-27 07:44:40 --> Security Class Initialized
DEBUG - 2018-11-27 07:44:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-27 07:44:40 --> Input Class Initialized
INFO - 2018-11-27 07:44:40 --> Language Class Initialized
ERROR - 2018-11-27 07:44:40 --> 404 Page Not Found: payment/Bootstrap/css
INFO - 2018-11-27 07:44:52 --> Config Class Initialized
INFO - 2018-11-27 07:44:52 --> Hooks Class Initialized
DEBUG - 2018-11-27 07:44:52 --> UTF-8 Support Enabled
INFO - 2018-11-27 07:44:52 --> Utf8 Class Initialized
INFO - 2018-11-27 07:44:52 --> URI Class Initialized
INFO - 2018-11-27 07:44:52 --> Router Class Initialized
INFO - 2018-11-27 07:44:52 --> Output Class Initialized
INFO - 2018-11-27 07:44:52 --> Security Class Initialized
DEBUG - 2018-11-27 07:44:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-27 07:44:52 --> Input Class Initialized
INFO - 2018-11-27 07:44:52 --> Language Class Initialized
INFO - 2018-11-27 07:44:52 --> Loader Class Initialized
INFO - 2018-11-27 07:44:52 --> Helper loaded: url_helper
INFO - 2018-11-27 07:44:52 --> Helper loaded: file_helper
INFO - 2018-11-27 07:44:52 --> Helper loaded: email_helper
INFO - 2018-11-27 07:44:52 --> Helper loaded: common_helper
INFO - 2018-11-27 07:44:52 --> Database Driver Class Initialized
DEBUG - 2018-11-27 07:44:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-27 07:44:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-27 07:44:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-27 07:44:52 --> Pagination Class Initialized
INFO - 2018-11-27 07:44:52 --> Helper loaded: form_helper
INFO - 2018-11-27 07:44:52 --> Form Validation Class Initialized
INFO - 2018-11-27 07:44:52 --> Model Class Initialized
INFO - 2018-11-27 07:44:52 --> Controller Class Initialized
ERROR - 2018-11-27 07:44:52 --> Severity: Notice --> Undefined variable: pinfo C:\xampp\htdocs\wetinuneed\application\views\payment\confirmation.php 39
INFO - 2018-11-27 07:44:52 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\payment/confirmation.php
INFO - 2018-11-27 07:44:52 --> Final output sent to browser
DEBUG - 2018-11-27 07:44:52 --> Total execution time: 0.0610
INFO - 2018-11-27 07:44:52 --> Config Class Initialized
INFO - 2018-11-27 07:44:52 --> Hooks Class Initialized
DEBUG - 2018-11-27 07:44:52 --> UTF-8 Support Enabled
INFO - 2018-11-27 07:44:52 --> Utf8 Class Initialized
INFO - 2018-11-27 07:44:52 --> URI Class Initialized
INFO - 2018-11-27 07:44:52 --> Router Class Initialized
INFO - 2018-11-27 07:44:52 --> Output Class Initialized
INFO - 2018-11-27 07:44:52 --> Security Class Initialized
DEBUG - 2018-11-27 07:44:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-27 07:44:52 --> Input Class Initialized
INFO - 2018-11-27 07:44:52 --> Language Class Initialized
ERROR - 2018-11-27 07:44:52 --> 404 Page Not Found: payment/My_controller/bootstrap
INFO - 2018-11-27 07:47:32 --> Config Class Initialized
INFO - 2018-11-27 07:47:32 --> Hooks Class Initialized
DEBUG - 2018-11-27 07:47:32 --> UTF-8 Support Enabled
INFO - 2018-11-27 07:47:32 --> Utf8 Class Initialized
INFO - 2018-11-27 07:47:32 --> URI Class Initialized
INFO - 2018-11-27 07:47:32 --> Router Class Initialized
INFO - 2018-11-27 07:47:32 --> Output Class Initialized
INFO - 2018-11-27 07:47:32 --> Security Class Initialized
DEBUG - 2018-11-27 07:47:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-27 07:47:32 --> Input Class Initialized
INFO - 2018-11-27 07:47:32 --> Language Class Initialized
INFO - 2018-11-27 07:47:32 --> Loader Class Initialized
INFO - 2018-11-27 07:47:32 --> Helper loaded: url_helper
INFO - 2018-11-27 07:47:32 --> Helper loaded: file_helper
INFO - 2018-11-27 07:47:32 --> Helper loaded: email_helper
INFO - 2018-11-27 07:47:32 --> Helper loaded: common_helper
INFO - 2018-11-27 07:47:32 --> Database Driver Class Initialized
DEBUG - 2018-11-27 07:47:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-27 07:47:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-27 07:47:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-27 07:47:32 --> Pagination Class Initialized
INFO - 2018-11-27 07:47:32 --> Helper loaded: form_helper
INFO - 2018-11-27 07:47:32 --> Form Validation Class Initialized
INFO - 2018-11-27 07:47:32 --> Model Class Initialized
INFO - 2018-11-27 07:47:32 --> Controller Class Initialized
INFO - 2018-11-27 07:47:32 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\payment/form1.php
INFO - 2018-11-27 07:47:32 --> Final output sent to browser
DEBUG - 2018-11-27 07:47:32 --> Total execution time: 0.0710
INFO - 2018-11-27 07:47:32 --> Config Class Initialized
INFO - 2018-11-27 07:47:32 --> Hooks Class Initialized
DEBUG - 2018-11-27 07:47:32 --> UTF-8 Support Enabled
INFO - 2018-11-27 07:47:32 --> Utf8 Class Initialized
INFO - 2018-11-27 07:47:32 --> URI Class Initialized
INFO - 2018-11-27 07:47:32 --> Router Class Initialized
INFO - 2018-11-27 07:47:32 --> Output Class Initialized
INFO - 2018-11-27 07:47:32 --> Security Class Initialized
DEBUG - 2018-11-27 07:47:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-27 07:47:32 --> Input Class Initialized
INFO - 2018-11-27 07:47:32 --> Language Class Initialized
ERROR - 2018-11-27 07:47:32 --> 404 Page Not Found: payment/Bootstrap/css
INFO - 2018-11-27 07:47:33 --> Config Class Initialized
INFO - 2018-11-27 07:47:33 --> Hooks Class Initialized
DEBUG - 2018-11-27 07:47:33 --> UTF-8 Support Enabled
INFO - 2018-11-27 07:47:33 --> Utf8 Class Initialized
INFO - 2018-11-27 07:47:33 --> URI Class Initialized
INFO - 2018-11-27 07:47:33 --> Router Class Initialized
INFO - 2018-11-27 07:47:33 --> Output Class Initialized
INFO - 2018-11-27 07:47:33 --> Security Class Initialized
DEBUG - 2018-11-27 07:47:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-27 07:47:33 --> Input Class Initialized
INFO - 2018-11-27 07:47:33 --> Language Class Initialized
ERROR - 2018-11-27 07:47:33 --> 404 Page Not Found: payment/Bootstrap/css
INFO - 2018-11-27 07:47:45 --> Config Class Initialized
INFO - 2018-11-27 07:47:45 --> Hooks Class Initialized
DEBUG - 2018-11-27 07:47:45 --> UTF-8 Support Enabled
INFO - 2018-11-27 07:47:45 --> Utf8 Class Initialized
INFO - 2018-11-27 07:47:45 --> URI Class Initialized
INFO - 2018-11-27 07:47:45 --> Router Class Initialized
INFO - 2018-11-27 07:47:45 --> Output Class Initialized
INFO - 2018-11-27 07:47:45 --> Security Class Initialized
DEBUG - 2018-11-27 07:47:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-27 07:47:45 --> Input Class Initialized
INFO - 2018-11-27 07:47:45 --> Language Class Initialized
ERROR - 2018-11-27 07:47:45 --> 404 Page Not Found: payment/Bootstrap/css
INFO - 2018-11-27 07:47:49 --> Config Class Initialized
INFO - 2018-11-27 07:47:49 --> Hooks Class Initialized
DEBUG - 2018-11-27 07:47:49 --> UTF-8 Support Enabled
INFO - 2018-11-27 07:47:49 --> Utf8 Class Initialized
INFO - 2018-11-27 07:47:49 --> URI Class Initialized
INFO - 2018-11-27 07:47:49 --> Router Class Initialized
INFO - 2018-11-27 07:47:49 --> Output Class Initialized
INFO - 2018-11-27 07:47:49 --> Security Class Initialized
DEBUG - 2018-11-27 07:47:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-27 07:47:49 --> Input Class Initialized
INFO - 2018-11-27 07:47:49 --> Language Class Initialized
INFO - 2018-11-27 07:47:49 --> Loader Class Initialized
INFO - 2018-11-27 07:47:49 --> Helper loaded: url_helper
INFO - 2018-11-27 07:47:49 --> Helper loaded: file_helper
INFO - 2018-11-27 07:47:49 --> Helper loaded: email_helper
INFO - 2018-11-27 07:47:49 --> Helper loaded: common_helper
INFO - 2018-11-27 07:47:49 --> Database Driver Class Initialized
DEBUG - 2018-11-27 07:47:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-27 07:47:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-27 07:47:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-27 07:47:49 --> Pagination Class Initialized
INFO - 2018-11-27 07:47:49 --> Helper loaded: form_helper
INFO - 2018-11-27 07:47:49 --> Form Validation Class Initialized
INFO - 2018-11-27 07:47:49 --> Model Class Initialized
INFO - 2018-11-27 07:47:49 --> Controller Class Initialized
ERROR - 2018-11-27 07:47:49 --> Severity: Notice --> Undefined variable: pinfo C:\xampp\htdocs\wetinuneed\application\views\payment\confirmation.php 39
INFO - 2018-11-27 07:47:49 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\payment/confirmation.php
INFO - 2018-11-27 07:47:49 --> Final output sent to browser
DEBUG - 2018-11-27 07:47:49 --> Total execution time: 0.0490
INFO - 2018-11-27 07:47:50 --> Config Class Initialized
INFO - 2018-11-27 07:47:50 --> Hooks Class Initialized
DEBUG - 2018-11-27 07:47:50 --> UTF-8 Support Enabled
INFO - 2018-11-27 07:47:50 --> Utf8 Class Initialized
INFO - 2018-11-27 07:47:50 --> URI Class Initialized
INFO - 2018-11-27 07:47:50 --> Router Class Initialized
INFO - 2018-11-27 07:47:50 --> Output Class Initialized
INFO - 2018-11-27 07:47:50 --> Security Class Initialized
DEBUG - 2018-11-27 07:47:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-27 07:47:50 --> Input Class Initialized
INFO - 2018-11-27 07:47:50 --> Language Class Initialized
ERROR - 2018-11-27 07:47:50 --> 404 Page Not Found: payment/My_controller/bootstrap
INFO - 2018-11-27 08:08:59 --> Config Class Initialized
INFO - 2018-11-27 08:08:59 --> Hooks Class Initialized
DEBUG - 2018-11-27 08:08:59 --> UTF-8 Support Enabled
INFO - 2018-11-27 08:08:59 --> Utf8 Class Initialized
INFO - 2018-11-27 08:08:59 --> URI Class Initialized
INFO - 2018-11-27 08:08:59 --> Router Class Initialized
INFO - 2018-11-27 08:08:59 --> Output Class Initialized
INFO - 2018-11-27 08:08:59 --> Security Class Initialized
DEBUG - 2018-11-27 08:08:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-27 08:08:59 --> Input Class Initialized
INFO - 2018-11-27 08:08:59 --> Language Class Initialized
INFO - 2018-11-27 08:08:59 --> Loader Class Initialized
INFO - 2018-11-27 08:08:59 --> Helper loaded: url_helper
INFO - 2018-11-27 08:08:59 --> Helper loaded: file_helper
INFO - 2018-11-27 08:08:59 --> Helper loaded: email_helper
INFO - 2018-11-27 08:08:59 --> Helper loaded: common_helper
INFO - 2018-11-27 08:08:59 --> Database Driver Class Initialized
DEBUG - 2018-11-27 08:08:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-27 08:08:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-27 08:08:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-27 08:08:59 --> Pagination Class Initialized
INFO - 2018-11-27 08:08:59 --> Helper loaded: form_helper
INFO - 2018-11-27 08:08:59 --> Form Validation Class Initialized
INFO - 2018-11-27 08:08:59 --> Model Class Initialized
INFO - 2018-11-27 08:08:59 --> Controller Class Initialized
INFO - 2018-11-27 08:08:59 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-27 08:08:59 --> Model Class Initialized
INFO - 2018-11-27 08:08:59 --> Model Class Initialized
INFO - 2018-11-27 08:08:59 --> Config Class Initialized
INFO - 2018-11-27 08:08:59 --> Hooks Class Initialized
DEBUG - 2018-11-27 08:08:59 --> UTF-8 Support Enabled
INFO - 2018-11-27 08:08:59 --> Utf8 Class Initialized
INFO - 2018-11-27 08:08:59 --> URI Class Initialized
INFO - 2018-11-27 08:08:59 --> Router Class Initialized
INFO - 2018-11-27 08:08:59 --> Output Class Initialized
INFO - 2018-11-27 08:08:59 --> Security Class Initialized
DEBUG - 2018-11-27 08:08:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-27 08:08:59 --> Input Class Initialized
INFO - 2018-11-27 08:08:59 --> Language Class Initialized
INFO - 2018-11-27 08:08:59 --> Loader Class Initialized
INFO - 2018-11-27 08:08:59 --> Helper loaded: url_helper
INFO - 2018-11-27 08:08:59 --> Helper loaded: file_helper
INFO - 2018-11-27 08:08:59 --> Helper loaded: email_helper
INFO - 2018-11-27 08:08:59 --> Helper loaded: common_helper
INFO - 2018-11-27 08:08:59 --> Database Driver Class Initialized
DEBUG - 2018-11-27 08:08:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-27 08:08:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-27 08:08:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-27 08:08:59 --> Pagination Class Initialized
INFO - 2018-11-27 08:08:59 --> Helper loaded: form_helper
INFO - 2018-11-27 08:08:59 --> Form Validation Class Initialized
INFO - 2018-11-27 08:08:59 --> Model Class Initialized
INFO - 2018-11-27 08:08:59 --> Controller Class Initialized
INFO - 2018-11-27 08:08:59 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-27 08:08:59 --> Model Class Initialized
INFO - 2018-11-27 08:08:59 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-27 08:08:59 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/sidebar.php
INFO - 2018-11-27 08:08:59 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/right-sidebar.php
INFO - 2018-11-27 08:08:59 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/footer.php
INFO - 2018-11-27 08:08:59 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/dashboard.php
INFO - 2018-11-27 08:08:59 --> Final output sent to browser
DEBUG - 2018-11-27 08:08:59 --> Total execution time: 0.0630
INFO - 2018-11-27 08:23:47 --> Config Class Initialized
INFO - 2018-11-27 08:23:47 --> Hooks Class Initialized
DEBUG - 2018-11-27 08:23:47 --> UTF-8 Support Enabled
INFO - 2018-11-27 08:23:47 --> Utf8 Class Initialized
INFO - 2018-11-27 08:23:47 --> URI Class Initialized
INFO - 2018-11-27 08:23:47 --> Router Class Initialized
INFO - 2018-11-27 08:23:47 --> Output Class Initialized
INFO - 2018-11-27 08:23:47 --> Security Class Initialized
DEBUG - 2018-11-27 08:23:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-27 08:23:47 --> Input Class Initialized
INFO - 2018-11-27 08:23:47 --> Language Class Initialized
INFO - 2018-11-27 08:23:47 --> Loader Class Initialized
INFO - 2018-11-27 08:23:47 --> Helper loaded: url_helper
INFO - 2018-11-27 08:23:47 --> Helper loaded: file_helper
INFO - 2018-11-27 08:23:47 --> Helper loaded: email_helper
INFO - 2018-11-27 08:23:48 --> Helper loaded: common_helper
INFO - 2018-11-27 08:23:48 --> Database Driver Class Initialized
DEBUG - 2018-11-27 08:23:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-27 08:23:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-27 08:23:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-27 08:23:48 --> Pagination Class Initialized
INFO - 2018-11-27 08:23:48 --> Helper loaded: form_helper
INFO - 2018-11-27 08:23:48 --> Form Validation Class Initialized
INFO - 2018-11-27 08:23:48 --> Model Class Initialized
INFO - 2018-11-27 08:23:48 --> Controller Class Initialized
INFO - 2018-11-27 08:23:48 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-27 08:23:48 --> Model Class Initialized
INFO - 2018-11-27 08:23:48 --> Model Class Initialized
INFO - 2018-11-27 08:23:48 --> Config Class Initialized
INFO - 2018-11-27 08:23:48 --> Hooks Class Initialized
DEBUG - 2018-11-27 08:23:48 --> UTF-8 Support Enabled
INFO - 2018-11-27 08:23:48 --> Utf8 Class Initialized
INFO - 2018-11-27 08:23:48 --> URI Class Initialized
INFO - 2018-11-27 08:23:48 --> Router Class Initialized
INFO - 2018-11-27 08:23:48 --> Output Class Initialized
INFO - 2018-11-27 08:23:48 --> Security Class Initialized
DEBUG - 2018-11-27 08:23:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-27 08:23:48 --> Input Class Initialized
INFO - 2018-11-27 08:23:48 --> Language Class Initialized
INFO - 2018-11-27 08:23:48 --> Loader Class Initialized
INFO - 2018-11-27 08:23:48 --> Helper loaded: url_helper
INFO - 2018-11-27 08:23:48 --> Helper loaded: file_helper
INFO - 2018-11-27 08:23:48 --> Helper loaded: email_helper
INFO - 2018-11-27 08:23:48 --> Helper loaded: common_helper
INFO - 2018-11-27 08:23:48 --> Database Driver Class Initialized
DEBUG - 2018-11-27 08:23:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-27 08:23:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-27 08:23:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-27 08:23:48 --> Pagination Class Initialized
INFO - 2018-11-27 08:23:48 --> Helper loaded: form_helper
INFO - 2018-11-27 08:23:48 --> Form Validation Class Initialized
INFO - 2018-11-27 08:23:48 --> Model Class Initialized
INFO - 2018-11-27 08:23:48 --> Controller Class Initialized
INFO - 2018-11-27 08:23:48 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-27 08:23:48 --> Model Class Initialized
INFO - 2018-11-27 08:23:48 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-27 08:23:48 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/sidebar.php
INFO - 2018-11-27 08:23:48 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/right-sidebar.php
INFO - 2018-11-27 08:23:48 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/footer.php
INFO - 2018-11-27 08:23:48 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/dashboard.php
INFO - 2018-11-27 08:23:48 --> Final output sent to browser
DEBUG - 2018-11-27 08:23:48 --> Total execution time: 0.0810
INFO - 2018-11-27 08:23:53 --> Config Class Initialized
INFO - 2018-11-27 08:23:53 --> Hooks Class Initialized
DEBUG - 2018-11-27 08:23:53 --> UTF-8 Support Enabled
INFO - 2018-11-27 08:23:53 --> Utf8 Class Initialized
INFO - 2018-11-27 08:23:53 --> URI Class Initialized
INFO - 2018-11-27 08:23:53 --> Router Class Initialized
INFO - 2018-11-27 08:23:53 --> Output Class Initialized
INFO - 2018-11-27 08:23:53 --> Security Class Initialized
DEBUG - 2018-11-27 08:23:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-27 08:23:53 --> Input Class Initialized
INFO - 2018-11-27 08:23:53 --> Language Class Initialized
INFO - 2018-11-27 08:23:53 --> Loader Class Initialized
INFO - 2018-11-27 08:23:53 --> Helper loaded: url_helper
INFO - 2018-11-27 08:23:53 --> Helper loaded: file_helper
INFO - 2018-11-27 08:23:53 --> Helper loaded: email_helper
INFO - 2018-11-27 08:23:53 --> Helper loaded: common_helper
INFO - 2018-11-27 08:23:53 --> Database Driver Class Initialized
DEBUG - 2018-11-27 08:23:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-27 08:23:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-27 08:23:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-27 08:23:53 --> Pagination Class Initialized
INFO - 2018-11-27 08:23:54 --> Helper loaded: form_helper
INFO - 2018-11-27 08:23:54 --> Form Validation Class Initialized
INFO - 2018-11-27 08:23:54 --> Model Class Initialized
INFO - 2018-11-27 08:23:54 --> Controller Class Initialized
INFO - 2018-11-27 08:23:54 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\payment/form1.php
INFO - 2018-11-27 08:23:54 --> Final output sent to browser
DEBUG - 2018-11-27 08:23:54 --> Total execution time: 0.0700
INFO - 2018-11-27 08:23:54 --> Config Class Initialized
INFO - 2018-11-27 08:23:54 --> Hooks Class Initialized
DEBUG - 2018-11-27 08:23:54 --> UTF-8 Support Enabled
INFO - 2018-11-27 08:23:54 --> Utf8 Class Initialized
INFO - 2018-11-27 08:23:54 --> URI Class Initialized
INFO - 2018-11-27 08:23:54 --> Router Class Initialized
INFO - 2018-11-27 08:23:54 --> Output Class Initialized
INFO - 2018-11-27 08:23:54 --> Security Class Initialized
DEBUG - 2018-11-27 08:23:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-27 08:23:54 --> Input Class Initialized
INFO - 2018-11-27 08:23:54 --> Language Class Initialized
ERROR - 2018-11-27 08:23:54 --> 404 Page Not Found: payment/Bootstrap/css
INFO - 2018-11-27 08:23:54 --> Config Class Initialized
INFO - 2018-11-27 08:23:54 --> Hooks Class Initialized
DEBUG - 2018-11-27 08:23:54 --> UTF-8 Support Enabled
INFO - 2018-11-27 08:23:54 --> Utf8 Class Initialized
INFO - 2018-11-27 08:23:54 --> URI Class Initialized
INFO - 2018-11-27 08:23:54 --> Router Class Initialized
INFO - 2018-11-27 08:23:54 --> Output Class Initialized
INFO - 2018-11-27 08:23:54 --> Security Class Initialized
DEBUG - 2018-11-27 08:23:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-27 08:23:54 --> Input Class Initialized
INFO - 2018-11-27 08:23:54 --> Language Class Initialized
ERROR - 2018-11-27 08:23:54 --> 404 Page Not Found: payment/Bootstrap/css
INFO - 2018-11-27 08:23:55 --> Config Class Initialized
INFO - 2018-11-27 08:23:55 --> Hooks Class Initialized
DEBUG - 2018-11-27 08:23:55 --> UTF-8 Support Enabled
INFO - 2018-11-27 08:23:55 --> Utf8 Class Initialized
INFO - 2018-11-27 08:23:55 --> URI Class Initialized
INFO - 2018-11-27 08:23:55 --> Router Class Initialized
INFO - 2018-11-27 08:23:55 --> Output Class Initialized
INFO - 2018-11-27 08:23:55 --> Security Class Initialized
DEBUG - 2018-11-27 08:23:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-27 08:23:55 --> Input Class Initialized
INFO - 2018-11-27 08:23:55 --> Language Class Initialized
ERROR - 2018-11-27 08:23:55 --> 404 Page Not Found: payment/Img/favicon.png
INFO - 2018-11-27 08:24:02 --> Config Class Initialized
INFO - 2018-11-27 08:24:02 --> Hooks Class Initialized
DEBUG - 2018-11-27 08:24:02 --> UTF-8 Support Enabled
INFO - 2018-11-27 08:24:02 --> Utf8 Class Initialized
INFO - 2018-11-27 08:24:02 --> URI Class Initialized
INFO - 2018-11-27 08:24:02 --> Router Class Initialized
INFO - 2018-11-27 08:24:02 --> Output Class Initialized
INFO - 2018-11-27 08:24:02 --> Security Class Initialized
DEBUG - 2018-11-27 08:24:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-27 08:24:02 --> Input Class Initialized
INFO - 2018-11-27 08:24:02 --> Language Class Initialized
INFO - 2018-11-27 08:24:02 --> Loader Class Initialized
INFO - 2018-11-27 08:24:02 --> Helper loaded: url_helper
INFO - 2018-11-27 08:24:02 --> Helper loaded: file_helper
INFO - 2018-11-27 08:24:02 --> Helper loaded: email_helper
INFO - 2018-11-27 08:24:02 --> Helper loaded: common_helper
INFO - 2018-11-27 08:24:02 --> Database Driver Class Initialized
DEBUG - 2018-11-27 08:24:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-27 08:24:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-27 08:24:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-27 08:24:02 --> Pagination Class Initialized
INFO - 2018-11-27 08:24:02 --> Helper loaded: form_helper
INFO - 2018-11-27 08:24:02 --> Form Validation Class Initialized
INFO - 2018-11-27 08:24:02 --> Model Class Initialized
INFO - 2018-11-27 08:24:02 --> Controller Class Initialized
ERROR - 2018-11-27 08:24:02 --> Severity: Notice --> Undefined variable: pinfo C:\xampp\htdocs\wetinuneed\application\views\payment\confirmation.php 39
INFO - 2018-11-27 08:24:02 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\payment/confirmation.php
INFO - 2018-11-27 08:24:02 --> Final output sent to browser
DEBUG - 2018-11-27 08:24:02 --> Total execution time: 0.0800
INFO - 2018-11-27 08:24:02 --> Config Class Initialized
INFO - 2018-11-27 08:24:02 --> Hooks Class Initialized
DEBUG - 2018-11-27 08:24:02 --> UTF-8 Support Enabled
INFO - 2018-11-27 08:24:02 --> Utf8 Class Initialized
INFO - 2018-11-27 08:24:02 --> URI Class Initialized
INFO - 2018-11-27 08:24:02 --> Router Class Initialized
INFO - 2018-11-27 08:24:02 --> Output Class Initialized
INFO - 2018-11-27 08:24:02 --> Security Class Initialized
DEBUG - 2018-11-27 08:24:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-27 08:24:02 --> Input Class Initialized
INFO - 2018-11-27 08:24:02 --> Language Class Initialized
ERROR - 2018-11-27 08:24:02 --> 404 Page Not Found: payment/My_controller/bootstrap
INFO - 2018-11-27 08:24:03 --> Config Class Initialized
INFO - 2018-11-27 08:24:03 --> Hooks Class Initialized
DEBUG - 2018-11-27 08:24:03 --> UTF-8 Support Enabled
INFO - 2018-11-27 08:24:03 --> Utf8 Class Initialized
INFO - 2018-11-27 08:24:03 --> URI Class Initialized
INFO - 2018-11-27 08:24:03 --> Router Class Initialized
INFO - 2018-11-27 08:24:03 --> Output Class Initialized
INFO - 2018-11-27 08:24:03 --> Security Class Initialized
DEBUG - 2018-11-27 08:24:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-27 08:24:03 --> Input Class Initialized
INFO - 2018-11-27 08:24:03 --> Language Class Initialized
ERROR - 2018-11-27 08:24:03 --> 404 Page Not Found: payment/My_controller/favicon.png
INFO - 2018-11-27 08:27:55 --> Config Class Initialized
INFO - 2018-11-27 08:27:55 --> Hooks Class Initialized
DEBUG - 2018-11-27 08:27:55 --> UTF-8 Support Enabled
INFO - 2018-11-27 08:27:55 --> Utf8 Class Initialized
INFO - 2018-11-27 08:27:55 --> URI Class Initialized
INFO - 2018-11-27 08:27:55 --> Router Class Initialized
INFO - 2018-11-27 08:27:55 --> Output Class Initialized
INFO - 2018-11-27 08:27:55 --> Security Class Initialized
DEBUG - 2018-11-27 08:27:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-27 08:27:55 --> Input Class Initialized
INFO - 2018-11-27 08:27:55 --> Language Class Initialized
INFO - 2018-11-27 08:27:55 --> Loader Class Initialized
INFO - 2018-11-27 08:27:55 --> Helper loaded: url_helper
INFO - 2018-11-27 08:27:55 --> Helper loaded: file_helper
INFO - 2018-11-27 08:27:55 --> Helper loaded: email_helper
INFO - 2018-11-27 08:27:55 --> Helper loaded: common_helper
INFO - 2018-11-27 08:27:55 --> Database Driver Class Initialized
DEBUG - 2018-11-27 08:27:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-27 08:27:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-27 08:27:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-27 08:27:55 --> Pagination Class Initialized
INFO - 2018-11-27 08:27:55 --> Helper loaded: form_helper
INFO - 2018-11-27 08:27:55 --> Form Validation Class Initialized
INFO - 2018-11-27 08:27:55 --> Model Class Initialized
INFO - 2018-11-27 08:27:55 --> Controller Class Initialized
INFO - 2018-11-27 08:27:55 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\payment/form1.php
INFO - 2018-11-27 08:27:55 --> Final output sent to browser
DEBUG - 2018-11-27 08:27:55 --> Total execution time: 0.0640
INFO - 2018-11-27 08:27:56 --> Config Class Initialized
INFO - 2018-11-27 08:27:56 --> Hooks Class Initialized
DEBUG - 2018-11-27 08:27:56 --> UTF-8 Support Enabled
INFO - 2018-11-27 08:27:56 --> Utf8 Class Initialized
INFO - 2018-11-27 08:27:56 --> URI Class Initialized
INFO - 2018-11-27 08:27:56 --> Router Class Initialized
INFO - 2018-11-27 08:27:56 --> Output Class Initialized
INFO - 2018-11-27 08:27:56 --> Security Class Initialized
DEBUG - 2018-11-27 08:27:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-27 08:27:56 --> Input Class Initialized
INFO - 2018-11-27 08:27:56 --> Language Class Initialized
ERROR - 2018-11-27 08:27:56 --> 404 Page Not Found: payment/Bootstrap/css
INFO - 2018-11-27 08:27:58 --> Config Class Initialized
INFO - 2018-11-27 08:27:58 --> Hooks Class Initialized
DEBUG - 2018-11-27 08:27:58 --> UTF-8 Support Enabled
INFO - 2018-11-27 08:27:58 --> Utf8 Class Initialized
INFO - 2018-11-27 08:27:58 --> URI Class Initialized
INFO - 2018-11-27 08:27:58 --> Router Class Initialized
INFO - 2018-11-27 08:27:58 --> Output Class Initialized
INFO - 2018-11-27 08:27:58 --> Security Class Initialized
DEBUG - 2018-11-27 08:27:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-27 08:27:58 --> Input Class Initialized
INFO - 2018-11-27 08:27:58 --> Language Class Initialized
INFO - 2018-11-27 08:27:58 --> Loader Class Initialized
INFO - 2018-11-27 08:27:58 --> Helper loaded: url_helper
INFO - 2018-11-27 08:27:58 --> Helper loaded: file_helper
INFO - 2018-11-27 08:27:58 --> Helper loaded: email_helper
INFO - 2018-11-27 08:27:58 --> Helper loaded: common_helper
INFO - 2018-11-27 08:27:58 --> Database Driver Class Initialized
DEBUG - 2018-11-27 08:27:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-27 08:27:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-27 08:27:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-27 08:27:58 --> Pagination Class Initialized
INFO - 2018-11-27 08:27:58 --> Helper loaded: form_helper
INFO - 2018-11-27 08:27:58 --> Form Validation Class Initialized
INFO - 2018-11-27 08:27:58 --> Model Class Initialized
INFO - 2018-11-27 08:27:58 --> Controller Class Initialized
INFO - 2018-11-27 08:27:58 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\payment/form1.php
INFO - 2018-11-27 08:27:58 --> Final output sent to browser
DEBUG - 2018-11-27 08:27:58 --> Total execution time: 0.1210
INFO - 2018-11-27 08:27:58 --> Config Class Initialized
INFO - 2018-11-27 08:27:58 --> Hooks Class Initialized
DEBUG - 2018-11-27 08:27:58 --> UTF-8 Support Enabled
INFO - 2018-11-27 08:27:58 --> Utf8 Class Initialized
INFO - 2018-11-27 08:27:58 --> URI Class Initialized
INFO - 2018-11-27 08:27:58 --> Router Class Initialized
INFO - 2018-11-27 08:27:58 --> Output Class Initialized
INFO - 2018-11-27 08:27:58 --> Security Class Initialized
DEBUG - 2018-11-27 08:27:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-27 08:27:58 --> Input Class Initialized
INFO - 2018-11-27 08:27:58 --> Language Class Initialized
ERROR - 2018-11-27 08:27:58 --> 404 Page Not Found: payment/Bootstrap/css
INFO - 2018-11-27 08:27:58 --> Config Class Initialized
INFO - 2018-11-27 08:27:58 --> Hooks Class Initialized
DEBUG - 2018-11-27 08:27:58 --> UTF-8 Support Enabled
INFO - 2018-11-27 08:27:58 --> Utf8 Class Initialized
INFO - 2018-11-27 08:27:58 --> URI Class Initialized
INFO - 2018-11-27 08:27:58 --> Router Class Initialized
INFO - 2018-11-27 08:27:58 --> Output Class Initialized
INFO - 2018-11-27 08:27:58 --> Security Class Initialized
DEBUG - 2018-11-27 08:27:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-27 08:27:58 --> Input Class Initialized
INFO - 2018-11-27 08:27:58 --> Language Class Initialized
ERROR - 2018-11-27 08:27:58 --> 404 Page Not Found: payment/Img/favicon.png
INFO - 2018-11-27 08:28:32 --> Config Class Initialized
INFO - 2018-11-27 08:28:32 --> Hooks Class Initialized
DEBUG - 2018-11-27 08:28:32 --> UTF-8 Support Enabled
INFO - 2018-11-27 08:28:32 --> Utf8 Class Initialized
INFO - 2018-11-27 08:28:32 --> URI Class Initialized
INFO - 2018-11-27 08:28:32 --> Router Class Initialized
INFO - 2018-11-27 08:28:32 --> Output Class Initialized
INFO - 2018-11-27 08:28:32 --> Security Class Initialized
DEBUG - 2018-11-27 08:28:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-27 08:28:32 --> Input Class Initialized
INFO - 2018-11-27 08:28:32 --> Language Class Initialized
INFO - 2018-11-27 08:28:32 --> Loader Class Initialized
INFO - 2018-11-27 08:28:32 --> Helper loaded: url_helper
INFO - 2018-11-27 08:28:32 --> Helper loaded: file_helper
INFO - 2018-11-27 08:28:32 --> Helper loaded: email_helper
INFO - 2018-11-27 08:28:32 --> Helper loaded: common_helper
INFO - 2018-11-27 08:28:32 --> Database Driver Class Initialized
DEBUG - 2018-11-27 08:28:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-27 08:28:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-27 08:28:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-27 08:28:32 --> Pagination Class Initialized
INFO - 2018-11-27 08:28:32 --> Helper loaded: form_helper
INFO - 2018-11-27 08:28:32 --> Form Validation Class Initialized
INFO - 2018-11-27 08:28:32 --> Model Class Initialized
INFO - 2018-11-27 08:28:32 --> Controller Class Initialized
INFO - 2018-11-27 08:28:32 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\payment/form1.php
INFO - 2018-11-27 08:28:32 --> Final output sent to browser
DEBUG - 2018-11-27 08:28:32 --> Total execution time: 0.0660
INFO - 2018-11-27 08:28:32 --> Config Class Initialized
INFO - 2018-11-27 08:28:32 --> Hooks Class Initialized
DEBUG - 2018-11-27 08:28:32 --> UTF-8 Support Enabled
INFO - 2018-11-27 08:28:32 --> Utf8 Class Initialized
INFO - 2018-11-27 08:28:32 --> URI Class Initialized
INFO - 2018-11-27 08:28:32 --> Router Class Initialized
INFO - 2018-11-27 08:28:32 --> Output Class Initialized
INFO - 2018-11-27 08:28:32 --> Security Class Initialized
DEBUG - 2018-11-27 08:28:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-27 08:28:32 --> Input Class Initialized
INFO - 2018-11-27 08:28:32 --> Language Class Initialized
ERROR - 2018-11-27 08:28:32 --> 404 Page Not Found: payment/Img/favicon.png
INFO - 2018-11-27 08:28:40 --> Config Class Initialized
INFO - 2018-11-27 08:28:40 --> Hooks Class Initialized
DEBUG - 2018-11-27 08:28:40 --> UTF-8 Support Enabled
INFO - 2018-11-27 08:28:40 --> Utf8 Class Initialized
INFO - 2018-11-27 08:28:40 --> URI Class Initialized
INFO - 2018-11-27 08:28:40 --> Router Class Initialized
INFO - 2018-11-27 08:28:40 --> Output Class Initialized
INFO - 2018-11-27 08:28:40 --> Security Class Initialized
DEBUG - 2018-11-27 08:28:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-27 08:28:40 --> Input Class Initialized
INFO - 2018-11-27 08:28:40 --> Language Class Initialized
INFO - 2018-11-27 08:28:40 --> Loader Class Initialized
INFO - 2018-11-27 08:28:40 --> Helper loaded: url_helper
INFO - 2018-11-27 08:28:40 --> Helper loaded: file_helper
INFO - 2018-11-27 08:28:40 --> Helper loaded: email_helper
INFO - 2018-11-27 08:28:40 --> Helper loaded: common_helper
INFO - 2018-11-27 08:28:40 --> Database Driver Class Initialized
DEBUG - 2018-11-27 08:28:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-27 08:28:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-27 08:28:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-27 08:28:40 --> Pagination Class Initialized
INFO - 2018-11-27 08:28:40 --> Helper loaded: form_helper
INFO - 2018-11-27 08:28:40 --> Form Validation Class Initialized
INFO - 2018-11-27 08:28:40 --> Model Class Initialized
INFO - 2018-11-27 08:28:40 --> Controller Class Initialized
ERROR - 2018-11-27 08:28:40 --> Severity: Notice --> Undefined variable: product_info C:\xampp\htdocs\wetinuneed\application\views\payment\confirmation.php 38
INFO - 2018-11-27 08:28:40 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\payment/confirmation.php
INFO - 2018-11-27 08:28:40 --> Final output sent to browser
DEBUG - 2018-11-27 08:28:40 --> Total execution time: 0.0740
INFO - 2018-11-27 08:28:40 --> Config Class Initialized
INFO - 2018-11-27 08:28:40 --> Hooks Class Initialized
DEBUG - 2018-11-27 08:28:40 --> UTF-8 Support Enabled
INFO - 2018-11-27 08:28:40 --> Utf8 Class Initialized
INFO - 2018-11-27 08:28:40 --> URI Class Initialized
INFO - 2018-11-27 08:28:40 --> Router Class Initialized
INFO - 2018-11-27 08:28:40 --> Output Class Initialized
INFO - 2018-11-27 08:28:40 --> Security Class Initialized
DEBUG - 2018-11-27 08:28:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-27 08:28:40 --> Input Class Initialized
INFO - 2018-11-27 08:28:40 --> Language Class Initialized
ERROR - 2018-11-27 08:28:40 --> 404 Page Not Found: payment/My_controller/favicon.png
INFO - 2018-11-27 08:29:00 --> Config Class Initialized
INFO - 2018-11-27 08:29:00 --> Hooks Class Initialized
DEBUG - 2018-11-27 08:29:00 --> UTF-8 Support Enabled
INFO - 2018-11-27 08:29:00 --> Utf8 Class Initialized
INFO - 2018-11-27 08:29:00 --> URI Class Initialized
INFO - 2018-11-27 08:29:00 --> Router Class Initialized
INFO - 2018-11-27 08:29:00 --> Output Class Initialized
INFO - 2018-11-27 08:29:00 --> Security Class Initialized
DEBUG - 2018-11-27 08:29:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-27 08:29:00 --> Input Class Initialized
INFO - 2018-11-27 08:29:00 --> Language Class Initialized
INFO - 2018-11-27 08:29:00 --> Loader Class Initialized
INFO - 2018-11-27 08:29:00 --> Helper loaded: url_helper
INFO - 2018-11-27 08:29:00 --> Helper loaded: file_helper
INFO - 2018-11-27 08:29:00 --> Helper loaded: email_helper
INFO - 2018-11-27 08:29:00 --> Helper loaded: common_helper
INFO - 2018-11-27 08:29:00 --> Database Driver Class Initialized
DEBUG - 2018-11-27 08:29:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-27 08:29:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-27 08:29:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-27 08:29:00 --> Pagination Class Initialized
INFO - 2018-11-27 08:29:00 --> Helper loaded: form_helper
INFO - 2018-11-27 08:29:00 --> Form Validation Class Initialized
INFO - 2018-11-27 08:29:00 --> Model Class Initialized
INFO - 2018-11-27 08:29:00 --> Controller Class Initialized
INFO - 2018-11-27 08:29:00 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\payment/confirmation.php
INFO - 2018-11-27 08:29:00 --> Final output sent to browser
DEBUG - 2018-11-27 08:29:00 --> Total execution time: 0.0640
INFO - 2018-11-27 08:29:01 --> Config Class Initialized
INFO - 2018-11-27 08:29:01 --> Hooks Class Initialized
DEBUG - 2018-11-27 08:29:01 --> UTF-8 Support Enabled
INFO - 2018-11-27 08:29:01 --> Utf8 Class Initialized
INFO - 2018-11-27 08:29:01 --> URI Class Initialized
INFO - 2018-11-27 08:29:01 --> Router Class Initialized
INFO - 2018-11-27 08:29:01 --> Output Class Initialized
INFO - 2018-11-27 08:29:01 --> Security Class Initialized
DEBUG - 2018-11-27 08:29:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-27 08:29:01 --> Input Class Initialized
INFO - 2018-11-27 08:29:01 --> Language Class Initialized
ERROR - 2018-11-27 08:29:01 --> 404 Page Not Found: payment/My_controller/favicon.png
INFO - 2018-11-27 08:29:55 --> Config Class Initialized
INFO - 2018-11-27 08:29:55 --> Hooks Class Initialized
DEBUG - 2018-11-27 08:29:55 --> UTF-8 Support Enabled
INFO - 2018-11-27 08:29:55 --> Utf8 Class Initialized
INFO - 2018-11-27 08:29:55 --> URI Class Initialized
INFO - 2018-11-27 08:29:55 --> Router Class Initialized
INFO - 2018-11-27 08:29:55 --> Output Class Initialized
INFO - 2018-11-27 08:29:55 --> Security Class Initialized
DEBUG - 2018-11-27 08:29:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-27 08:29:55 --> Input Class Initialized
INFO - 2018-11-27 08:29:55 --> Language Class Initialized
INFO - 2018-11-27 08:29:55 --> Loader Class Initialized
INFO - 2018-11-27 08:29:55 --> Helper loaded: url_helper
INFO - 2018-11-27 08:29:55 --> Helper loaded: file_helper
INFO - 2018-11-27 08:29:55 --> Helper loaded: email_helper
INFO - 2018-11-27 08:29:55 --> Helper loaded: common_helper
INFO - 2018-11-27 08:29:55 --> Database Driver Class Initialized
DEBUG - 2018-11-27 08:29:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-27 08:29:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-27 08:29:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-27 08:29:55 --> Pagination Class Initialized
INFO - 2018-11-27 08:29:55 --> Helper loaded: form_helper
INFO - 2018-11-27 08:29:55 --> Form Validation Class Initialized
INFO - 2018-11-27 08:29:55 --> Model Class Initialized
INFO - 2018-11-27 08:29:55 --> Controller Class Initialized
INFO - 2018-11-27 08:29:55 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\payment/form1.php
INFO - 2018-11-27 08:29:55 --> Final output sent to browser
DEBUG - 2018-11-27 08:29:55 --> Total execution time: 0.0780
INFO - 2018-11-27 08:29:57 --> Config Class Initialized
INFO - 2018-11-27 08:29:57 --> Hooks Class Initialized
DEBUG - 2018-11-27 08:29:57 --> UTF-8 Support Enabled
INFO - 2018-11-27 08:29:57 --> Utf8 Class Initialized
INFO - 2018-11-27 08:29:57 --> URI Class Initialized
INFO - 2018-11-27 08:29:57 --> Router Class Initialized
INFO - 2018-11-27 08:29:57 --> Output Class Initialized
INFO - 2018-11-27 08:29:57 --> Security Class Initialized
DEBUG - 2018-11-27 08:29:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-27 08:29:57 --> Input Class Initialized
INFO - 2018-11-27 08:29:57 --> Language Class Initialized
ERROR - 2018-11-27 08:29:57 --> 404 Page Not Found: payment/Img/favicon.png
INFO - 2018-11-27 08:30:01 --> Config Class Initialized
INFO - 2018-11-27 08:30:01 --> Hooks Class Initialized
DEBUG - 2018-11-27 08:30:01 --> UTF-8 Support Enabled
INFO - 2018-11-27 08:30:01 --> Utf8 Class Initialized
INFO - 2018-11-27 08:30:01 --> URI Class Initialized
INFO - 2018-11-27 08:30:01 --> Router Class Initialized
INFO - 2018-11-27 08:30:01 --> Output Class Initialized
INFO - 2018-11-27 08:30:01 --> Security Class Initialized
DEBUG - 2018-11-27 08:30:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-27 08:30:01 --> Input Class Initialized
INFO - 2018-11-27 08:30:01 --> Language Class Initialized
INFO - 2018-11-27 08:30:01 --> Loader Class Initialized
INFO - 2018-11-27 08:30:01 --> Helper loaded: url_helper
INFO - 2018-11-27 08:30:01 --> Helper loaded: file_helper
INFO - 2018-11-27 08:30:01 --> Helper loaded: email_helper
INFO - 2018-11-27 08:30:01 --> Helper loaded: common_helper
INFO - 2018-11-27 08:30:01 --> Database Driver Class Initialized
DEBUG - 2018-11-27 08:30:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-27 08:30:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-27 08:30:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-27 08:30:01 --> Pagination Class Initialized
INFO - 2018-11-27 08:30:01 --> Helper loaded: form_helper
INFO - 2018-11-27 08:30:01 --> Form Validation Class Initialized
INFO - 2018-11-27 08:30:01 --> Model Class Initialized
INFO - 2018-11-27 08:30:01 --> Controller Class Initialized
INFO - 2018-11-27 08:30:01 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\payment/form1.php
INFO - 2018-11-27 08:30:01 --> Final output sent to browser
DEBUG - 2018-11-27 08:30:01 --> Total execution time: 0.0830
INFO - 2018-11-27 08:30:01 --> Config Class Initialized
INFO - 2018-11-27 08:30:01 --> Hooks Class Initialized
DEBUG - 2018-11-27 08:30:01 --> UTF-8 Support Enabled
INFO - 2018-11-27 08:30:01 --> Utf8 Class Initialized
INFO - 2018-11-27 08:30:01 --> URI Class Initialized
INFO - 2018-11-27 08:30:01 --> Router Class Initialized
INFO - 2018-11-27 08:30:01 --> Output Class Initialized
INFO - 2018-11-27 08:30:01 --> Security Class Initialized
DEBUG - 2018-11-27 08:30:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-27 08:30:01 --> Input Class Initialized
INFO - 2018-11-27 08:30:01 --> Language Class Initialized
ERROR - 2018-11-27 08:30:01 --> 404 Page Not Found: payment/Img/favicon.png
INFO - 2018-11-27 08:30:07 --> Config Class Initialized
INFO - 2018-11-27 08:30:07 --> Hooks Class Initialized
DEBUG - 2018-11-27 08:30:07 --> UTF-8 Support Enabled
INFO - 2018-11-27 08:30:07 --> Utf8 Class Initialized
INFO - 2018-11-27 08:30:07 --> URI Class Initialized
INFO - 2018-11-27 08:30:07 --> Router Class Initialized
INFO - 2018-11-27 08:30:07 --> Output Class Initialized
INFO - 2018-11-27 08:30:07 --> Security Class Initialized
DEBUG - 2018-11-27 08:30:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-27 08:30:07 --> Input Class Initialized
INFO - 2018-11-27 08:30:07 --> Language Class Initialized
INFO - 2018-11-27 08:30:07 --> Loader Class Initialized
INFO - 2018-11-27 08:30:07 --> Helper loaded: url_helper
INFO - 2018-11-27 08:30:07 --> Helper loaded: file_helper
INFO - 2018-11-27 08:30:07 --> Helper loaded: email_helper
INFO - 2018-11-27 08:30:07 --> Helper loaded: common_helper
INFO - 2018-11-27 08:30:07 --> Database Driver Class Initialized
DEBUG - 2018-11-27 08:30:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-27 08:30:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-27 08:30:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-27 08:30:07 --> Pagination Class Initialized
INFO - 2018-11-27 08:30:07 --> Helper loaded: form_helper
INFO - 2018-11-27 08:30:07 --> Form Validation Class Initialized
INFO - 2018-11-27 08:30:07 --> Model Class Initialized
INFO - 2018-11-27 08:30:07 --> Controller Class Initialized
INFO - 2018-11-27 08:30:07 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\payment/confirmation.php
INFO - 2018-11-27 08:30:07 --> Final output sent to browser
DEBUG - 2018-11-27 08:30:07 --> Total execution time: 0.0670
INFO - 2018-11-27 08:30:07 --> Config Class Initialized
INFO - 2018-11-27 08:30:07 --> Hooks Class Initialized
DEBUG - 2018-11-27 08:30:07 --> UTF-8 Support Enabled
INFO - 2018-11-27 08:30:07 --> Utf8 Class Initialized
INFO - 2018-11-27 08:30:07 --> URI Class Initialized
INFO - 2018-11-27 08:30:07 --> Router Class Initialized
INFO - 2018-11-27 08:30:07 --> Output Class Initialized
INFO - 2018-11-27 08:30:07 --> Security Class Initialized
DEBUG - 2018-11-27 08:30:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-27 08:30:07 --> Input Class Initialized
INFO - 2018-11-27 08:30:07 --> Language Class Initialized
ERROR - 2018-11-27 08:30:07 --> 404 Page Not Found: payment/My_controller/favicon.png
INFO - 2018-11-27 08:32:53 --> Config Class Initialized
INFO - 2018-11-27 08:32:53 --> Hooks Class Initialized
DEBUG - 2018-11-27 08:32:53 --> UTF-8 Support Enabled
INFO - 2018-11-27 08:32:53 --> Utf8 Class Initialized
INFO - 2018-11-27 08:32:53 --> URI Class Initialized
INFO - 2018-11-27 08:32:53 --> Router Class Initialized
INFO - 2018-11-27 08:32:53 --> Output Class Initialized
INFO - 2018-11-27 08:32:53 --> Security Class Initialized
DEBUG - 2018-11-27 08:32:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-27 08:32:53 --> Input Class Initialized
INFO - 2018-11-27 08:32:53 --> Language Class Initialized
INFO - 2018-11-27 08:32:53 --> Loader Class Initialized
INFO - 2018-11-27 08:32:53 --> Helper loaded: url_helper
INFO - 2018-11-27 08:32:53 --> Helper loaded: file_helper
INFO - 2018-11-27 08:32:53 --> Helper loaded: email_helper
INFO - 2018-11-27 08:32:53 --> Helper loaded: common_helper
INFO - 2018-11-27 08:32:53 --> Database Driver Class Initialized
DEBUG - 2018-11-27 08:32:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-27 08:32:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-27 08:32:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-27 08:32:53 --> Pagination Class Initialized
INFO - 2018-11-27 08:32:53 --> Helper loaded: form_helper
INFO - 2018-11-27 08:32:53 --> Form Validation Class Initialized
INFO - 2018-11-27 08:32:53 --> Model Class Initialized
INFO - 2018-11-27 08:32:53 --> Controller Class Initialized
INFO - 2018-11-27 08:32:53 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\payment/form1.php
INFO - 2018-11-27 08:32:53 --> Final output sent to browser
DEBUG - 2018-11-27 08:32:53 --> Total execution time: 0.0910
INFO - 2018-11-27 08:32:58 --> Config Class Initialized
INFO - 2018-11-27 08:32:58 --> Hooks Class Initialized
DEBUG - 2018-11-27 08:32:58 --> UTF-8 Support Enabled
INFO - 2018-11-27 08:32:58 --> Utf8 Class Initialized
INFO - 2018-11-27 08:32:58 --> URI Class Initialized
INFO - 2018-11-27 08:32:58 --> Router Class Initialized
INFO - 2018-11-27 08:32:58 --> Output Class Initialized
INFO - 2018-11-27 08:32:58 --> Security Class Initialized
DEBUG - 2018-11-27 08:32:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-27 08:32:58 --> Input Class Initialized
INFO - 2018-11-27 08:32:58 --> Language Class Initialized
INFO - 2018-11-27 08:32:58 --> Loader Class Initialized
INFO - 2018-11-27 08:32:58 --> Helper loaded: url_helper
INFO - 2018-11-27 08:32:58 --> Helper loaded: file_helper
INFO - 2018-11-27 08:32:58 --> Helper loaded: email_helper
INFO - 2018-11-27 08:32:58 --> Helper loaded: common_helper
INFO - 2018-11-27 08:32:58 --> Database Driver Class Initialized
DEBUG - 2018-11-27 08:32:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-27 08:32:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-27 08:32:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-27 08:32:58 --> Pagination Class Initialized
INFO - 2018-11-27 08:32:58 --> Helper loaded: form_helper
INFO - 2018-11-27 08:32:58 --> Form Validation Class Initialized
INFO - 2018-11-27 08:32:58 --> Model Class Initialized
INFO - 2018-11-27 08:32:58 --> Controller Class Initialized
INFO - 2018-11-27 08:32:58 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\payment/form1.php
INFO - 2018-11-27 08:32:58 --> Final output sent to browser
DEBUG - 2018-11-27 08:32:58 --> Total execution time: 0.0630
INFO - 2018-11-27 08:33:07 --> Config Class Initialized
INFO - 2018-11-27 08:33:07 --> Hooks Class Initialized
DEBUG - 2018-11-27 08:33:07 --> UTF-8 Support Enabled
INFO - 2018-11-27 08:33:07 --> Utf8 Class Initialized
INFO - 2018-11-27 08:33:07 --> URI Class Initialized
INFO - 2018-11-27 08:33:07 --> Router Class Initialized
INFO - 2018-11-27 08:33:07 --> Output Class Initialized
INFO - 2018-11-27 08:33:07 --> Security Class Initialized
DEBUG - 2018-11-27 08:33:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-27 08:33:07 --> Input Class Initialized
INFO - 2018-11-27 08:33:07 --> Language Class Initialized
INFO - 2018-11-27 08:33:07 --> Loader Class Initialized
INFO - 2018-11-27 08:33:07 --> Helper loaded: url_helper
INFO - 2018-11-27 08:33:07 --> Helper loaded: file_helper
INFO - 2018-11-27 08:33:07 --> Helper loaded: email_helper
INFO - 2018-11-27 08:33:07 --> Helper loaded: common_helper
INFO - 2018-11-27 08:33:07 --> Database Driver Class Initialized
DEBUG - 2018-11-27 08:33:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-27 08:33:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-27 08:33:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-27 08:33:07 --> Pagination Class Initialized
INFO - 2018-11-27 08:33:07 --> Helper loaded: form_helper
INFO - 2018-11-27 08:33:07 --> Form Validation Class Initialized
INFO - 2018-11-27 08:33:07 --> Model Class Initialized
INFO - 2018-11-27 08:33:07 --> Controller Class Initialized
INFO - 2018-11-27 08:33:07 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\payment/confirmation.php
INFO - 2018-11-27 08:33:07 --> Final output sent to browser
DEBUG - 2018-11-27 08:33:07 --> Total execution time: 0.0680
INFO - 2018-11-27 08:38:46 --> Config Class Initialized
INFO - 2018-11-27 08:38:46 --> Hooks Class Initialized
DEBUG - 2018-11-27 08:38:46 --> UTF-8 Support Enabled
INFO - 2018-11-27 08:38:46 --> Utf8 Class Initialized
INFO - 2018-11-27 08:38:46 --> URI Class Initialized
INFO - 2018-11-27 08:38:46 --> Router Class Initialized
INFO - 2018-11-27 08:38:46 --> Output Class Initialized
INFO - 2018-11-27 08:38:46 --> Security Class Initialized
DEBUG - 2018-11-27 08:38:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-27 08:38:46 --> Input Class Initialized
INFO - 2018-11-27 08:38:46 --> Language Class Initialized
INFO - 2018-11-27 08:38:46 --> Loader Class Initialized
INFO - 2018-11-27 08:38:46 --> Helper loaded: url_helper
INFO - 2018-11-27 08:38:46 --> Helper loaded: file_helper
INFO - 2018-11-27 08:38:46 --> Helper loaded: email_helper
INFO - 2018-11-27 08:38:46 --> Helper loaded: common_helper
INFO - 2018-11-27 08:38:46 --> Database Driver Class Initialized
DEBUG - 2018-11-27 08:38:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-27 08:38:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-27 08:38:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-27 08:38:46 --> Pagination Class Initialized
INFO - 2018-11-27 08:38:46 --> Helper loaded: form_helper
INFO - 2018-11-27 08:38:46 --> Form Validation Class Initialized
INFO - 2018-11-27 08:38:46 --> Model Class Initialized
INFO - 2018-11-27 08:38:46 --> Controller Class Initialized
INFO - 2018-11-27 08:38:46 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\payment/form1.php
INFO - 2018-11-27 08:38:46 --> Final output sent to browser
DEBUG - 2018-11-27 08:38:46 --> Total execution time: 0.0610
INFO - 2018-11-27 08:38:54 --> Config Class Initialized
INFO - 2018-11-27 08:38:54 --> Hooks Class Initialized
DEBUG - 2018-11-27 08:38:54 --> UTF-8 Support Enabled
INFO - 2018-11-27 08:38:54 --> Utf8 Class Initialized
INFO - 2018-11-27 08:38:54 --> URI Class Initialized
INFO - 2018-11-27 08:38:54 --> Router Class Initialized
INFO - 2018-11-27 08:38:54 --> Output Class Initialized
INFO - 2018-11-27 08:38:54 --> Security Class Initialized
DEBUG - 2018-11-27 08:38:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-27 08:38:54 --> Input Class Initialized
INFO - 2018-11-27 08:38:54 --> Language Class Initialized
INFO - 2018-11-27 08:38:54 --> Loader Class Initialized
INFO - 2018-11-27 08:38:54 --> Helper loaded: url_helper
INFO - 2018-11-27 08:38:54 --> Helper loaded: file_helper
INFO - 2018-11-27 08:38:54 --> Helper loaded: email_helper
INFO - 2018-11-27 08:38:54 --> Helper loaded: common_helper
INFO - 2018-11-27 08:38:54 --> Database Driver Class Initialized
DEBUG - 2018-11-27 08:38:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-27 08:38:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-27 08:38:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-27 08:38:54 --> Pagination Class Initialized
INFO - 2018-11-27 08:38:54 --> Helper loaded: form_helper
INFO - 2018-11-27 08:38:54 --> Form Validation Class Initialized
INFO - 2018-11-27 08:38:54 --> Model Class Initialized
INFO - 2018-11-27 08:38:54 --> Controller Class Initialized
INFO - 2018-11-27 08:38:54 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\payment/confirmation.php
INFO - 2018-11-27 08:38:54 --> Final output sent to browser
DEBUG - 2018-11-27 08:38:54 --> Total execution time: 0.0730
INFO - 2018-11-27 08:39:05 --> Config Class Initialized
INFO - 2018-11-27 08:39:05 --> Hooks Class Initialized
DEBUG - 2018-11-27 08:39:05 --> UTF-8 Support Enabled
INFO - 2018-11-27 08:39:05 --> Utf8 Class Initialized
INFO - 2018-11-27 08:39:05 --> URI Class Initialized
INFO - 2018-11-27 08:39:05 --> Router Class Initialized
INFO - 2018-11-27 08:39:05 --> Output Class Initialized
INFO - 2018-11-27 08:39:05 --> Security Class Initialized
DEBUG - 2018-11-27 08:39:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-27 08:39:05 --> Input Class Initialized
INFO - 2018-11-27 08:39:05 --> Language Class Initialized
INFO - 2018-11-27 08:39:05 --> Loader Class Initialized
INFO - 2018-11-27 08:39:05 --> Helper loaded: url_helper
INFO - 2018-11-27 08:39:05 --> Helper loaded: file_helper
INFO - 2018-11-27 08:39:05 --> Helper loaded: email_helper
INFO - 2018-11-27 08:39:05 --> Helper loaded: common_helper
INFO - 2018-11-27 08:39:05 --> Database Driver Class Initialized
DEBUG - 2018-11-27 08:39:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-27 08:39:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-27 08:39:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-27 08:39:05 --> Pagination Class Initialized
INFO - 2018-11-27 08:39:05 --> Helper loaded: form_helper
INFO - 2018-11-27 08:39:05 --> Form Validation Class Initialized
INFO - 2018-11-27 08:39:05 --> Model Class Initialized
INFO - 2018-11-27 08:39:05 --> Controller Class Initialized
INFO - 2018-11-27 08:39:05 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\payment/form1.php
INFO - 2018-11-27 08:39:05 --> Final output sent to browser
DEBUG - 2018-11-27 08:39:05 --> Total execution time: 0.0740
INFO - 2018-11-27 08:39:16 --> Config Class Initialized
INFO - 2018-11-27 08:39:16 --> Hooks Class Initialized
DEBUG - 2018-11-27 08:39:16 --> UTF-8 Support Enabled
INFO - 2018-11-27 08:39:16 --> Utf8 Class Initialized
INFO - 2018-11-27 08:39:16 --> URI Class Initialized
INFO - 2018-11-27 08:39:16 --> Router Class Initialized
INFO - 2018-11-27 08:39:16 --> Output Class Initialized
INFO - 2018-11-27 08:39:16 --> Security Class Initialized
DEBUG - 2018-11-27 08:39:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-27 08:39:16 --> Input Class Initialized
INFO - 2018-11-27 08:39:16 --> Language Class Initialized
INFO - 2018-11-27 08:39:16 --> Loader Class Initialized
INFO - 2018-11-27 08:39:16 --> Helper loaded: url_helper
INFO - 2018-11-27 08:39:16 --> Helper loaded: file_helper
INFO - 2018-11-27 08:39:16 --> Helper loaded: email_helper
INFO - 2018-11-27 08:39:16 --> Helper loaded: common_helper
INFO - 2018-11-27 08:39:16 --> Database Driver Class Initialized
DEBUG - 2018-11-27 08:39:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-27 08:39:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-27 08:39:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-27 08:39:17 --> Pagination Class Initialized
INFO - 2018-11-27 08:39:17 --> Helper loaded: form_helper
INFO - 2018-11-27 08:39:17 --> Form Validation Class Initialized
INFO - 2018-11-27 08:39:17 --> Model Class Initialized
INFO - 2018-11-27 08:39:17 --> Controller Class Initialized
INFO - 2018-11-27 08:39:17 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\payment/confirmation.php
INFO - 2018-11-27 08:39:17 --> Final output sent to browser
DEBUG - 2018-11-27 08:39:17 --> Total execution time: 0.0720
INFO - 2018-11-27 08:39:51 --> Config Class Initialized
INFO - 2018-11-27 08:39:51 --> Hooks Class Initialized
DEBUG - 2018-11-27 08:39:51 --> UTF-8 Support Enabled
INFO - 2018-11-27 08:39:51 --> Utf8 Class Initialized
INFO - 2018-11-27 08:39:51 --> URI Class Initialized
INFO - 2018-11-27 08:39:51 --> Router Class Initialized
INFO - 2018-11-27 08:39:51 --> Output Class Initialized
INFO - 2018-11-27 08:39:51 --> Security Class Initialized
DEBUG - 2018-11-27 08:39:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-27 08:39:51 --> Input Class Initialized
INFO - 2018-11-27 08:39:51 --> Language Class Initialized
INFO - 2018-11-27 08:39:51 --> Loader Class Initialized
INFO - 2018-11-27 08:39:51 --> Helper loaded: url_helper
INFO - 2018-11-27 08:39:51 --> Helper loaded: file_helper
INFO - 2018-11-27 08:39:51 --> Helper loaded: email_helper
INFO - 2018-11-27 08:39:51 --> Helper loaded: common_helper
INFO - 2018-11-27 08:39:51 --> Database Driver Class Initialized
DEBUG - 2018-11-27 08:39:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-27 08:39:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-27 08:39:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-27 08:39:51 --> Pagination Class Initialized
INFO - 2018-11-27 08:39:51 --> Helper loaded: form_helper
INFO - 2018-11-27 08:39:51 --> Form Validation Class Initialized
INFO - 2018-11-27 08:39:51 --> Model Class Initialized
INFO - 2018-11-27 08:39:51 --> Controller Class Initialized
INFO - 2018-11-27 08:39:51 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\payment/form1.php
INFO - 2018-11-27 08:39:51 --> Final output sent to browser
DEBUG - 2018-11-27 08:39:51 --> Total execution time: 0.0700
INFO - 2018-11-27 08:40:01 --> Config Class Initialized
INFO - 2018-11-27 08:40:01 --> Hooks Class Initialized
DEBUG - 2018-11-27 08:40:01 --> UTF-8 Support Enabled
INFO - 2018-11-27 08:40:01 --> Utf8 Class Initialized
INFO - 2018-11-27 08:40:01 --> URI Class Initialized
INFO - 2018-11-27 08:40:01 --> Router Class Initialized
INFO - 2018-11-27 08:40:01 --> Output Class Initialized
INFO - 2018-11-27 08:40:01 --> Security Class Initialized
DEBUG - 2018-11-27 08:40:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-27 08:40:01 --> Input Class Initialized
INFO - 2018-11-27 08:40:01 --> Language Class Initialized
INFO - 2018-11-27 08:40:01 --> Loader Class Initialized
INFO - 2018-11-27 08:40:01 --> Helper loaded: url_helper
INFO - 2018-11-27 08:40:01 --> Helper loaded: file_helper
INFO - 2018-11-27 08:40:01 --> Helper loaded: email_helper
INFO - 2018-11-27 08:40:01 --> Helper loaded: common_helper
INFO - 2018-11-27 08:40:01 --> Database Driver Class Initialized
DEBUG - 2018-11-27 08:40:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-27 08:40:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-27 08:40:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-27 08:40:01 --> Pagination Class Initialized
INFO - 2018-11-27 08:40:01 --> Helper loaded: form_helper
INFO - 2018-11-27 08:40:01 --> Form Validation Class Initialized
INFO - 2018-11-27 08:40:01 --> Model Class Initialized
INFO - 2018-11-27 08:40:01 --> Controller Class Initialized
INFO - 2018-11-27 08:40:01 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\payment/confirmation.php
INFO - 2018-11-27 08:40:01 --> Final output sent to browser
DEBUG - 2018-11-27 08:40:01 --> Total execution time: 0.0600
INFO - 2018-11-27 08:41:06 --> Config Class Initialized
INFO - 2018-11-27 08:41:06 --> Hooks Class Initialized
DEBUG - 2018-11-27 08:41:06 --> UTF-8 Support Enabled
INFO - 2018-11-27 08:41:06 --> Utf8 Class Initialized
INFO - 2018-11-27 08:41:06 --> URI Class Initialized
INFO - 2018-11-27 08:41:06 --> Router Class Initialized
INFO - 2018-11-27 08:41:06 --> Output Class Initialized
INFO - 2018-11-27 08:41:06 --> Security Class Initialized
DEBUG - 2018-11-27 08:41:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-27 08:41:06 --> Input Class Initialized
INFO - 2018-11-27 08:41:06 --> Language Class Initialized
INFO - 2018-11-27 08:41:06 --> Loader Class Initialized
INFO - 2018-11-27 08:41:06 --> Helper loaded: url_helper
INFO - 2018-11-27 08:41:06 --> Helper loaded: file_helper
INFO - 2018-11-27 08:41:06 --> Helper loaded: email_helper
INFO - 2018-11-27 08:41:06 --> Helper loaded: common_helper
INFO - 2018-11-27 08:41:06 --> Database Driver Class Initialized
DEBUG - 2018-11-27 08:41:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-27 08:41:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-27 08:41:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-27 08:41:06 --> Pagination Class Initialized
INFO - 2018-11-27 08:41:06 --> Helper loaded: form_helper
INFO - 2018-11-27 08:41:06 --> Form Validation Class Initialized
INFO - 2018-11-27 08:41:06 --> Model Class Initialized
INFO - 2018-11-27 08:41:06 --> Controller Class Initialized
INFO - 2018-11-27 08:41:06 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\payment/form1.php
INFO - 2018-11-27 08:41:06 --> Final output sent to browser
DEBUG - 2018-11-27 08:41:06 --> Total execution time: 0.0700
INFO - 2018-11-27 08:41:08 --> Config Class Initialized
INFO - 2018-11-27 08:41:08 --> Hooks Class Initialized
DEBUG - 2018-11-27 08:41:08 --> UTF-8 Support Enabled
INFO - 2018-11-27 08:41:08 --> Utf8 Class Initialized
INFO - 2018-11-27 08:41:08 --> URI Class Initialized
INFO - 2018-11-27 08:41:08 --> Router Class Initialized
INFO - 2018-11-27 08:41:08 --> Output Class Initialized
INFO - 2018-11-27 08:41:08 --> Security Class Initialized
DEBUG - 2018-11-27 08:41:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-27 08:41:08 --> Input Class Initialized
INFO - 2018-11-27 08:41:08 --> Language Class Initialized
INFO - 2018-11-27 08:41:08 --> Loader Class Initialized
INFO - 2018-11-27 08:41:08 --> Helper loaded: url_helper
INFO - 2018-11-27 08:41:08 --> Helper loaded: file_helper
INFO - 2018-11-27 08:41:08 --> Helper loaded: email_helper
INFO - 2018-11-27 08:41:08 --> Helper loaded: common_helper
INFO - 2018-11-27 08:41:08 --> Database Driver Class Initialized
DEBUG - 2018-11-27 08:41:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-27 08:41:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-27 08:41:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-27 08:41:08 --> Pagination Class Initialized
INFO - 2018-11-27 08:41:08 --> Helper loaded: form_helper
INFO - 2018-11-27 08:41:08 --> Form Validation Class Initialized
INFO - 2018-11-27 08:41:08 --> Model Class Initialized
INFO - 2018-11-27 08:41:08 --> Controller Class Initialized
INFO - 2018-11-27 08:41:08 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\payment/form1.php
INFO - 2018-11-27 08:41:08 --> Final output sent to browser
DEBUG - 2018-11-27 08:41:08 --> Total execution time: 0.0590
INFO - 2018-11-27 08:41:09 --> Config Class Initialized
INFO - 2018-11-27 08:41:09 --> Hooks Class Initialized
DEBUG - 2018-11-27 08:41:09 --> UTF-8 Support Enabled
INFO - 2018-11-27 08:41:09 --> Utf8 Class Initialized
INFO - 2018-11-27 08:41:09 --> URI Class Initialized
INFO - 2018-11-27 08:41:09 --> Router Class Initialized
INFO - 2018-11-27 08:41:09 --> Output Class Initialized
INFO - 2018-11-27 08:41:09 --> Security Class Initialized
DEBUG - 2018-11-27 08:41:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-27 08:41:09 --> Input Class Initialized
INFO - 2018-11-27 08:41:09 --> Language Class Initialized
ERROR - 2018-11-27 08:41:09 --> 404 Page Not Found: payment/Img/favicon.png
INFO - 2018-11-27 08:41:42 --> Config Class Initialized
INFO - 2018-11-27 08:41:42 --> Hooks Class Initialized
DEBUG - 2018-11-27 08:41:42 --> UTF-8 Support Enabled
INFO - 2018-11-27 08:41:42 --> Utf8 Class Initialized
INFO - 2018-11-27 08:41:42 --> URI Class Initialized
INFO - 2018-11-27 08:41:42 --> Router Class Initialized
INFO - 2018-11-27 08:41:42 --> Output Class Initialized
INFO - 2018-11-27 08:41:42 --> Security Class Initialized
DEBUG - 2018-11-27 08:41:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-27 08:41:42 --> Input Class Initialized
INFO - 2018-11-27 08:41:42 --> Language Class Initialized
INFO - 2018-11-27 08:41:42 --> Loader Class Initialized
INFO - 2018-11-27 08:41:42 --> Helper loaded: url_helper
INFO - 2018-11-27 08:41:42 --> Helper loaded: file_helper
INFO - 2018-11-27 08:41:42 --> Helper loaded: email_helper
INFO - 2018-11-27 08:41:42 --> Helper loaded: common_helper
INFO - 2018-11-27 08:41:42 --> Database Driver Class Initialized
DEBUG - 2018-11-27 08:41:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-27 08:41:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-27 08:41:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-27 08:41:42 --> Pagination Class Initialized
INFO - 2018-11-27 08:41:42 --> Helper loaded: form_helper
INFO - 2018-11-27 08:41:42 --> Form Validation Class Initialized
INFO - 2018-11-27 08:41:42 --> Model Class Initialized
INFO - 2018-11-27 08:41:42 --> Controller Class Initialized
INFO - 2018-11-27 08:41:42 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\payment/confirmation.php
INFO - 2018-11-27 08:41:42 --> Final output sent to browser
DEBUG - 2018-11-27 08:41:42 --> Total execution time: 0.0610
INFO - 2018-11-27 08:41:42 --> Config Class Initialized
INFO - 2018-11-27 08:41:42 --> Hooks Class Initialized
DEBUG - 2018-11-27 08:41:42 --> UTF-8 Support Enabled
INFO - 2018-11-27 08:41:42 --> Utf8 Class Initialized
INFO - 2018-11-27 08:41:42 --> URI Class Initialized
INFO - 2018-11-27 08:41:42 --> Router Class Initialized
INFO - 2018-11-27 08:41:42 --> Output Class Initialized
INFO - 2018-11-27 08:41:42 --> Security Class Initialized
DEBUG - 2018-11-27 08:41:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-27 08:41:42 --> Input Class Initialized
INFO - 2018-11-27 08:41:42 --> Language Class Initialized
ERROR - 2018-11-27 08:41:42 --> 404 Page Not Found: payment/My_controller/favicon.png
INFO - 2018-11-27 08:50:43 --> Config Class Initialized
INFO - 2018-11-27 08:50:43 --> Hooks Class Initialized
DEBUG - 2018-11-27 08:50:43 --> UTF-8 Support Enabled
INFO - 2018-11-27 08:50:43 --> Utf8 Class Initialized
INFO - 2018-11-27 08:50:43 --> URI Class Initialized
INFO - 2018-11-27 08:50:43 --> Router Class Initialized
INFO - 2018-11-27 08:50:43 --> Output Class Initialized
INFO - 2018-11-27 08:50:43 --> Security Class Initialized
DEBUG - 2018-11-27 08:50:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-27 08:50:43 --> Input Class Initialized
INFO - 2018-11-27 08:50:43 --> Language Class Initialized
INFO - 2018-11-27 08:50:43 --> Loader Class Initialized
INFO - 2018-11-27 08:50:43 --> Helper loaded: url_helper
INFO - 2018-11-27 08:50:43 --> Helper loaded: file_helper
INFO - 2018-11-27 08:50:43 --> Helper loaded: email_helper
INFO - 2018-11-27 08:50:43 --> Helper loaded: common_helper
INFO - 2018-11-27 08:50:43 --> Database Driver Class Initialized
DEBUG - 2018-11-27 08:50:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-27 08:50:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-27 08:50:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-27 08:50:43 --> Pagination Class Initialized
INFO - 2018-11-27 08:50:43 --> Helper loaded: form_helper
INFO - 2018-11-27 08:50:43 --> Form Validation Class Initialized
INFO - 2018-11-27 08:50:43 --> Model Class Initialized
INFO - 2018-11-27 08:50:43 --> Controller Class Initialized
INFO - 2018-11-27 08:50:43 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-27 08:50:43 --> Model Class Initialized
INFO - 2018-11-27 08:50:43 --> Model Class Initialized
INFO - 2018-11-27 08:50:43 --> Config Class Initialized
INFO - 2018-11-27 08:50:43 --> Hooks Class Initialized
DEBUG - 2018-11-27 08:50:43 --> UTF-8 Support Enabled
INFO - 2018-11-27 08:50:43 --> Utf8 Class Initialized
INFO - 2018-11-27 08:50:43 --> URI Class Initialized
INFO - 2018-11-27 08:50:43 --> Router Class Initialized
INFO - 2018-11-27 08:50:43 --> Output Class Initialized
INFO - 2018-11-27 08:50:43 --> Security Class Initialized
DEBUG - 2018-11-27 08:50:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-27 08:50:43 --> Input Class Initialized
INFO - 2018-11-27 08:50:43 --> Language Class Initialized
INFO - 2018-11-27 08:50:43 --> Loader Class Initialized
INFO - 2018-11-27 08:50:43 --> Helper loaded: url_helper
INFO - 2018-11-27 08:50:43 --> Helper loaded: file_helper
INFO - 2018-11-27 08:50:43 --> Helper loaded: email_helper
INFO - 2018-11-27 08:50:43 --> Helper loaded: common_helper
INFO - 2018-11-27 08:50:43 --> Database Driver Class Initialized
DEBUG - 2018-11-27 08:50:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-27 08:50:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-27 08:50:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-27 08:50:43 --> Pagination Class Initialized
INFO - 2018-11-27 08:50:43 --> Helper loaded: form_helper
INFO - 2018-11-27 08:50:43 --> Form Validation Class Initialized
INFO - 2018-11-27 08:50:43 --> Model Class Initialized
INFO - 2018-11-27 08:50:43 --> Controller Class Initialized
INFO - 2018-11-27 08:50:43 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-27 08:50:43 --> Model Class Initialized
INFO - 2018-11-27 08:50:43 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-27 08:50:43 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/sidebar.php
INFO - 2018-11-27 08:50:43 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/right-sidebar.php
INFO - 2018-11-27 08:50:43 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/footer.php
INFO - 2018-11-27 08:50:43 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/dashboard.php
INFO - 2018-11-27 08:50:43 --> Final output sent to browser
DEBUG - 2018-11-27 08:50:43 --> Total execution time: 0.0730
INFO - 2018-11-27 08:50:46 --> Config Class Initialized
INFO - 2018-11-27 08:50:46 --> Hooks Class Initialized
DEBUG - 2018-11-27 08:50:46 --> UTF-8 Support Enabled
INFO - 2018-11-27 08:50:46 --> Utf8 Class Initialized
INFO - 2018-11-27 08:50:46 --> URI Class Initialized
INFO - 2018-11-27 08:50:46 --> Router Class Initialized
INFO - 2018-11-27 08:50:46 --> Output Class Initialized
INFO - 2018-11-27 08:50:46 --> Security Class Initialized
DEBUG - 2018-11-27 08:50:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-27 08:50:46 --> Input Class Initialized
INFO - 2018-11-27 08:50:46 --> Language Class Initialized
INFO - 2018-11-27 08:50:46 --> Loader Class Initialized
INFO - 2018-11-27 08:50:46 --> Helper loaded: url_helper
INFO - 2018-11-27 08:50:46 --> Helper loaded: file_helper
INFO - 2018-11-27 08:50:46 --> Helper loaded: email_helper
INFO - 2018-11-27 08:50:46 --> Helper loaded: common_helper
INFO - 2018-11-27 08:50:46 --> Database Driver Class Initialized
DEBUG - 2018-11-27 08:50:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-27 08:50:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-27 08:50:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-27 08:50:46 --> Pagination Class Initialized
INFO - 2018-11-27 08:50:46 --> Helper loaded: form_helper
INFO - 2018-11-27 08:50:46 --> Form Validation Class Initialized
INFO - 2018-11-27 08:50:46 --> Model Class Initialized
INFO - 2018-11-27 08:50:46 --> Controller Class Initialized
INFO - 2018-11-27 08:50:46 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\payment/form1.php
INFO - 2018-11-27 08:50:46 --> Final output sent to browser
DEBUG - 2018-11-27 08:50:46 --> Total execution time: 0.0670
INFO - 2018-11-27 08:50:54 --> Config Class Initialized
INFO - 2018-11-27 08:50:54 --> Hooks Class Initialized
DEBUG - 2018-11-27 08:50:54 --> UTF-8 Support Enabled
INFO - 2018-11-27 08:50:54 --> Utf8 Class Initialized
INFO - 2018-11-27 08:50:54 --> URI Class Initialized
INFO - 2018-11-27 08:50:54 --> Router Class Initialized
INFO - 2018-11-27 08:50:54 --> Output Class Initialized
INFO - 2018-11-27 08:50:54 --> Security Class Initialized
DEBUG - 2018-11-27 08:50:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-27 08:50:54 --> Input Class Initialized
INFO - 2018-11-27 08:50:54 --> Language Class Initialized
INFO - 2018-11-27 08:50:54 --> Loader Class Initialized
INFO - 2018-11-27 08:50:54 --> Helper loaded: url_helper
INFO - 2018-11-27 08:50:54 --> Helper loaded: file_helper
INFO - 2018-11-27 08:50:54 --> Helper loaded: email_helper
INFO - 2018-11-27 08:50:54 --> Helper loaded: common_helper
INFO - 2018-11-27 08:50:54 --> Database Driver Class Initialized
DEBUG - 2018-11-27 08:50:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-27 08:50:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-27 08:50:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-27 08:50:54 --> Pagination Class Initialized
INFO - 2018-11-27 08:50:54 --> Helper loaded: form_helper
INFO - 2018-11-27 08:50:54 --> Form Validation Class Initialized
INFO - 2018-11-27 08:50:54 --> Model Class Initialized
INFO - 2018-11-27 08:50:54 --> Controller Class Initialized
INFO - 2018-11-27 08:50:54 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\payment/confirmation.php
INFO - 2018-11-27 08:50:54 --> Final output sent to browser
DEBUG - 2018-11-27 08:50:54 --> Total execution time: 0.0730
INFO - 2018-11-27 08:54:55 --> Config Class Initialized
INFO - 2018-11-27 08:54:55 --> Hooks Class Initialized
DEBUG - 2018-11-27 08:54:55 --> UTF-8 Support Enabled
INFO - 2018-11-27 08:54:55 --> Utf8 Class Initialized
INFO - 2018-11-27 08:54:55 --> URI Class Initialized
INFO - 2018-11-27 08:54:55 --> Router Class Initialized
INFO - 2018-11-27 08:54:55 --> Output Class Initialized
INFO - 2018-11-27 08:54:55 --> Security Class Initialized
DEBUG - 2018-11-27 08:54:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-27 08:54:55 --> Input Class Initialized
INFO - 2018-11-27 08:54:55 --> Language Class Initialized
INFO - 2018-11-27 08:54:55 --> Loader Class Initialized
INFO - 2018-11-27 08:54:55 --> Helper loaded: url_helper
INFO - 2018-11-27 08:54:55 --> Helper loaded: file_helper
INFO - 2018-11-27 08:54:55 --> Helper loaded: email_helper
INFO - 2018-11-27 08:54:55 --> Helper loaded: common_helper
INFO - 2018-11-27 08:54:55 --> Database Driver Class Initialized
DEBUG - 2018-11-27 08:54:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-27 08:54:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-27 08:54:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-27 08:54:55 --> Pagination Class Initialized
INFO - 2018-11-27 08:54:55 --> Helper loaded: form_helper
INFO - 2018-11-27 08:54:55 --> Form Validation Class Initialized
INFO - 2018-11-27 08:54:55 --> Model Class Initialized
INFO - 2018-11-27 08:54:55 --> Controller Class Initialized
INFO - 2018-11-27 08:54:55 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\payment/form1.php
INFO - 2018-11-27 08:54:55 --> Final output sent to browser
DEBUG - 2018-11-27 08:54:55 --> Total execution time: 0.0600
INFO - 2018-11-27 08:55:06 --> Config Class Initialized
INFO - 2018-11-27 08:55:06 --> Hooks Class Initialized
DEBUG - 2018-11-27 08:55:06 --> UTF-8 Support Enabled
INFO - 2018-11-27 08:55:06 --> Utf8 Class Initialized
INFO - 2018-11-27 08:55:06 --> URI Class Initialized
INFO - 2018-11-27 08:55:06 --> Router Class Initialized
INFO - 2018-11-27 08:55:06 --> Output Class Initialized
INFO - 2018-11-27 08:55:06 --> Security Class Initialized
DEBUG - 2018-11-27 08:55:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-27 08:55:06 --> Input Class Initialized
INFO - 2018-11-27 08:55:06 --> Language Class Initialized
INFO - 2018-11-27 08:55:06 --> Loader Class Initialized
INFO - 2018-11-27 08:55:06 --> Helper loaded: url_helper
INFO - 2018-11-27 08:55:06 --> Helper loaded: file_helper
INFO - 2018-11-27 08:55:06 --> Helper loaded: email_helper
INFO - 2018-11-27 08:55:06 --> Helper loaded: common_helper
INFO - 2018-11-27 08:55:06 --> Database Driver Class Initialized
DEBUG - 2018-11-27 08:55:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-27 08:55:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-27 08:55:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-27 08:55:06 --> Pagination Class Initialized
INFO - 2018-11-27 08:55:06 --> Helper loaded: form_helper
INFO - 2018-11-27 08:55:06 --> Form Validation Class Initialized
INFO - 2018-11-27 08:55:06 --> Model Class Initialized
INFO - 2018-11-27 08:55:06 --> Controller Class Initialized
INFO - 2018-11-27 08:55:06 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\payment/confirmation.php
INFO - 2018-11-27 08:55:06 --> Final output sent to browser
DEBUG - 2018-11-27 08:55:06 --> Total execution time: 0.0820
INFO - 2018-11-27 09:00:39 --> Config Class Initialized
INFO - 2018-11-27 09:00:39 --> Hooks Class Initialized
DEBUG - 2018-11-27 09:00:39 --> UTF-8 Support Enabled
INFO - 2018-11-27 09:00:39 --> Utf8 Class Initialized
INFO - 2018-11-27 09:00:39 --> URI Class Initialized
INFO - 2018-11-27 09:00:39 --> Router Class Initialized
INFO - 2018-11-27 09:00:39 --> Output Class Initialized
INFO - 2018-11-27 09:00:39 --> Security Class Initialized
DEBUG - 2018-11-27 09:00:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-27 09:00:39 --> Input Class Initialized
INFO - 2018-11-27 09:00:39 --> Language Class Initialized
INFO - 2018-11-27 09:00:39 --> Loader Class Initialized
INFO - 2018-11-27 09:00:39 --> Helper loaded: url_helper
INFO - 2018-11-27 09:00:39 --> Helper loaded: file_helper
INFO - 2018-11-27 09:00:39 --> Helper loaded: email_helper
INFO - 2018-11-27 09:00:39 --> Helper loaded: common_helper
INFO - 2018-11-27 09:00:39 --> Database Driver Class Initialized
DEBUG - 2018-11-27 09:00:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-27 09:00:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-27 09:00:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-27 09:00:39 --> Pagination Class Initialized
INFO - 2018-11-27 09:00:39 --> Helper loaded: form_helper
INFO - 2018-11-27 09:00:39 --> Form Validation Class Initialized
INFO - 2018-11-27 09:00:39 --> Model Class Initialized
INFO - 2018-11-27 09:00:39 --> Controller Class Initialized
INFO - 2018-11-27 09:00:39 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\payment/confirmation.php
INFO - 2018-11-27 09:00:39 --> Final output sent to browser
DEBUG - 2018-11-27 09:00:39 --> Total execution time: 0.0630
INFO - 2018-11-27 09:04:25 --> Config Class Initialized
INFO - 2018-11-27 09:04:25 --> Hooks Class Initialized
DEBUG - 2018-11-27 09:04:25 --> UTF-8 Support Enabled
INFO - 2018-11-27 09:04:25 --> Utf8 Class Initialized
INFO - 2018-11-27 09:04:25 --> URI Class Initialized
INFO - 2018-11-27 09:04:25 --> Router Class Initialized
INFO - 2018-11-27 09:04:25 --> Output Class Initialized
INFO - 2018-11-27 09:04:25 --> Security Class Initialized
DEBUG - 2018-11-27 09:04:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-27 09:04:25 --> Input Class Initialized
INFO - 2018-11-27 09:04:25 --> Language Class Initialized
INFO - 2018-11-27 09:04:25 --> Loader Class Initialized
INFO - 2018-11-27 09:04:25 --> Helper loaded: url_helper
INFO - 2018-11-27 09:04:25 --> Helper loaded: file_helper
INFO - 2018-11-27 09:04:25 --> Helper loaded: email_helper
INFO - 2018-11-27 09:04:25 --> Helper loaded: common_helper
INFO - 2018-11-27 09:04:25 --> Database Driver Class Initialized
DEBUG - 2018-11-27 09:04:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-27 09:04:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-27 09:04:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-27 09:04:25 --> Pagination Class Initialized
INFO - 2018-11-27 09:04:25 --> Helper loaded: form_helper
INFO - 2018-11-27 09:04:25 --> Form Validation Class Initialized
INFO - 2018-11-27 09:04:25 --> Model Class Initialized
INFO - 2018-11-27 09:04:25 --> Controller Class Initialized
INFO - 2018-11-27 09:04:25 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\payment/form1.php
INFO - 2018-11-27 09:04:25 --> Final output sent to browser
DEBUG - 2018-11-27 09:04:25 --> Total execution time: 0.0720
INFO - 2018-11-27 09:04:32 --> Config Class Initialized
INFO - 2018-11-27 09:04:32 --> Hooks Class Initialized
DEBUG - 2018-11-27 09:04:32 --> UTF-8 Support Enabled
INFO - 2018-11-27 09:04:32 --> Utf8 Class Initialized
INFO - 2018-11-27 09:04:32 --> URI Class Initialized
INFO - 2018-11-27 09:04:32 --> Router Class Initialized
INFO - 2018-11-27 09:04:32 --> Output Class Initialized
INFO - 2018-11-27 09:04:32 --> Security Class Initialized
DEBUG - 2018-11-27 09:04:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-27 09:04:32 --> Input Class Initialized
INFO - 2018-11-27 09:04:32 --> Language Class Initialized
INFO - 2018-11-27 09:04:32 --> Loader Class Initialized
INFO - 2018-11-27 09:04:32 --> Helper loaded: url_helper
INFO - 2018-11-27 09:04:32 --> Helper loaded: file_helper
INFO - 2018-11-27 09:04:32 --> Helper loaded: email_helper
INFO - 2018-11-27 09:04:32 --> Helper loaded: common_helper
INFO - 2018-11-27 09:04:32 --> Database Driver Class Initialized
DEBUG - 2018-11-27 09:04:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-27 09:04:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-27 09:04:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-27 09:04:32 --> Pagination Class Initialized
INFO - 2018-11-27 09:04:32 --> Helper loaded: form_helper
INFO - 2018-11-27 09:04:32 --> Form Validation Class Initialized
INFO - 2018-11-27 09:04:32 --> Model Class Initialized
INFO - 2018-11-27 09:04:32 --> Controller Class Initialized
INFO - 2018-11-27 09:04:32 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\payment/confirmation.php
INFO - 2018-11-27 09:04:32 --> Final output sent to browser
DEBUG - 2018-11-27 09:04:32 --> Total execution time: 0.0700
INFO - 2018-11-27 09:07:15 --> Config Class Initialized
INFO - 2018-11-27 09:07:15 --> Hooks Class Initialized
DEBUG - 2018-11-27 09:07:15 --> UTF-8 Support Enabled
INFO - 2018-11-27 09:07:15 --> Utf8 Class Initialized
INFO - 2018-11-27 09:07:15 --> URI Class Initialized
INFO - 2018-11-27 09:07:15 --> Router Class Initialized
INFO - 2018-11-27 09:07:15 --> Output Class Initialized
INFO - 2018-11-27 09:07:15 --> Security Class Initialized
DEBUG - 2018-11-27 09:07:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-27 09:07:15 --> Input Class Initialized
INFO - 2018-11-27 09:07:15 --> Language Class Initialized
INFO - 2018-11-27 09:07:15 --> Loader Class Initialized
INFO - 2018-11-27 09:07:15 --> Helper loaded: url_helper
INFO - 2018-11-27 09:07:15 --> Helper loaded: file_helper
INFO - 2018-11-27 09:07:15 --> Helper loaded: email_helper
INFO - 2018-11-27 09:07:15 --> Helper loaded: common_helper
INFO - 2018-11-27 09:07:15 --> Database Driver Class Initialized
DEBUG - 2018-11-27 09:07:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-27 09:07:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-27 09:07:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-27 09:07:15 --> Pagination Class Initialized
INFO - 2018-11-27 09:07:15 --> Helper loaded: form_helper
INFO - 2018-11-27 09:07:15 --> Form Validation Class Initialized
INFO - 2018-11-27 09:07:15 --> Model Class Initialized
INFO - 2018-11-27 09:07:15 --> Controller Class Initialized
INFO - 2018-11-27 09:07:15 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\payment/success.php
INFO - 2018-11-27 09:07:15 --> Final output sent to browser
DEBUG - 2018-11-27 09:07:15 --> Total execution time: 0.1230
INFO - 2018-11-27 09:17:38 --> Config Class Initialized
INFO - 2018-11-27 09:17:38 --> Hooks Class Initialized
DEBUG - 2018-11-27 09:17:38 --> UTF-8 Support Enabled
INFO - 2018-11-27 09:17:38 --> Utf8 Class Initialized
INFO - 2018-11-27 09:17:38 --> URI Class Initialized
INFO - 2018-11-27 09:17:38 --> Router Class Initialized
INFO - 2018-11-27 09:17:38 --> Output Class Initialized
INFO - 2018-11-27 09:17:38 --> Security Class Initialized
DEBUG - 2018-11-27 09:17:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-27 09:17:38 --> Input Class Initialized
INFO - 2018-11-27 09:17:38 --> Language Class Initialized
INFO - 2018-11-27 09:17:38 --> Loader Class Initialized
INFO - 2018-11-27 09:17:38 --> Helper loaded: url_helper
INFO - 2018-11-27 09:17:38 --> Helper loaded: file_helper
INFO - 2018-11-27 09:17:38 --> Helper loaded: email_helper
INFO - 2018-11-27 09:17:38 --> Helper loaded: common_helper
INFO - 2018-11-27 09:17:38 --> Database Driver Class Initialized
DEBUG - 2018-11-27 09:17:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-27 09:17:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-27 09:17:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-27 09:17:38 --> Pagination Class Initialized
INFO - 2018-11-27 09:17:38 --> Helper loaded: form_helper
INFO - 2018-11-27 09:17:38 --> Form Validation Class Initialized
INFO - 2018-11-27 09:17:38 --> Model Class Initialized
INFO - 2018-11-27 09:17:38 --> Controller Class Initialized
INFO - 2018-11-27 09:17:38 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\payment/success.php
INFO - 2018-11-27 09:17:38 --> Final output sent to browser
DEBUG - 2018-11-27 09:17:38 --> Total execution time: 0.0720
INFO - 2018-11-27 09:17:50 --> Config Class Initialized
INFO - 2018-11-27 09:17:50 --> Hooks Class Initialized
DEBUG - 2018-11-27 09:17:50 --> UTF-8 Support Enabled
INFO - 2018-11-27 09:17:50 --> Utf8 Class Initialized
INFO - 2018-11-27 09:17:50 --> URI Class Initialized
INFO - 2018-11-27 09:17:50 --> Router Class Initialized
INFO - 2018-11-27 09:17:50 --> Output Class Initialized
INFO - 2018-11-27 09:17:50 --> Security Class Initialized
DEBUG - 2018-11-27 09:17:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-27 09:17:50 --> Input Class Initialized
INFO - 2018-11-27 09:17:50 --> Language Class Initialized
INFO - 2018-11-27 09:17:50 --> Loader Class Initialized
INFO - 2018-11-27 09:17:50 --> Helper loaded: url_helper
INFO - 2018-11-27 09:17:50 --> Helper loaded: file_helper
INFO - 2018-11-27 09:17:50 --> Helper loaded: email_helper
INFO - 2018-11-27 09:17:50 --> Helper loaded: common_helper
INFO - 2018-11-27 09:17:50 --> Database Driver Class Initialized
DEBUG - 2018-11-27 09:17:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-27 09:17:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-27 09:17:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-27 09:17:50 --> Pagination Class Initialized
INFO - 2018-11-27 09:17:50 --> Helper loaded: form_helper
INFO - 2018-11-27 09:17:50 --> Form Validation Class Initialized
INFO - 2018-11-27 09:17:50 --> Model Class Initialized
INFO - 2018-11-27 09:17:50 --> Controller Class Initialized
INFO - 2018-11-27 09:17:50 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\payment/form1.php
INFO - 2018-11-27 09:17:50 --> Final output sent to browser
DEBUG - 2018-11-27 09:17:50 --> Total execution time: 0.0760
INFO - 2018-11-27 09:18:07 --> Config Class Initialized
INFO - 2018-11-27 09:18:07 --> Hooks Class Initialized
DEBUG - 2018-11-27 09:18:07 --> UTF-8 Support Enabled
INFO - 2018-11-27 09:18:07 --> Utf8 Class Initialized
INFO - 2018-11-27 09:18:07 --> URI Class Initialized
INFO - 2018-11-27 09:18:07 --> Router Class Initialized
INFO - 2018-11-27 09:18:07 --> Output Class Initialized
INFO - 2018-11-27 09:18:07 --> Security Class Initialized
DEBUG - 2018-11-27 09:18:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-27 09:18:07 --> Input Class Initialized
INFO - 2018-11-27 09:18:07 --> Language Class Initialized
INFO - 2018-11-27 09:18:07 --> Loader Class Initialized
INFO - 2018-11-27 09:18:07 --> Helper loaded: url_helper
INFO - 2018-11-27 09:18:07 --> Helper loaded: file_helper
INFO - 2018-11-27 09:18:07 --> Helper loaded: email_helper
INFO - 2018-11-27 09:18:07 --> Helper loaded: common_helper
INFO - 2018-11-27 09:18:07 --> Database Driver Class Initialized
DEBUG - 2018-11-27 09:18:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-27 09:18:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-27 09:18:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-27 09:18:07 --> Pagination Class Initialized
INFO - 2018-11-27 09:18:07 --> Helper loaded: form_helper
INFO - 2018-11-27 09:18:07 --> Form Validation Class Initialized
INFO - 2018-11-27 09:18:07 --> Model Class Initialized
INFO - 2018-11-27 09:18:07 --> Controller Class Initialized
ERROR - 2018-11-27 09:18:07 --> Severity: Notice --> Undefined variable: udf1 C:\xampp\htdocs\wetinuneed\application\views\payment\confirmation.php 20
ERROR - 2018-11-27 09:18:07 --> Severity: Notice --> Undefined variable: udf2 C:\xampp\htdocs\wetinuneed\application\views\payment\confirmation.php 21
INFO - 2018-11-27 09:18:07 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\payment/confirmation.php
INFO - 2018-11-27 09:18:07 --> Final output sent to browser
DEBUG - 2018-11-27 09:18:07 --> Total execution time: 0.0600
INFO - 2018-11-27 09:18:13 --> Config Class Initialized
INFO - 2018-11-27 09:18:13 --> Hooks Class Initialized
DEBUG - 2018-11-27 09:18:13 --> UTF-8 Support Enabled
INFO - 2018-11-27 09:18:13 --> Utf8 Class Initialized
INFO - 2018-11-27 09:18:13 --> URI Class Initialized
INFO - 2018-11-27 09:18:13 --> Router Class Initialized
INFO - 2018-11-27 09:18:13 --> Output Class Initialized
INFO - 2018-11-27 09:18:13 --> Security Class Initialized
DEBUG - 2018-11-27 09:18:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-27 09:18:13 --> Input Class Initialized
INFO - 2018-11-27 09:18:13 --> Language Class Initialized
INFO - 2018-11-27 09:18:13 --> Loader Class Initialized
INFO - 2018-11-27 09:18:13 --> Helper loaded: url_helper
INFO - 2018-11-27 09:18:13 --> Helper loaded: file_helper
INFO - 2018-11-27 09:18:13 --> Helper loaded: email_helper
INFO - 2018-11-27 09:18:13 --> Helper loaded: common_helper
INFO - 2018-11-27 09:18:13 --> Database Driver Class Initialized
DEBUG - 2018-11-27 09:18:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-27 09:18:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-27 09:18:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-27 09:18:13 --> Pagination Class Initialized
INFO - 2018-11-27 09:18:13 --> Helper loaded: form_helper
INFO - 2018-11-27 09:18:13 --> Form Validation Class Initialized
INFO - 2018-11-27 09:18:13 --> Model Class Initialized
INFO - 2018-11-27 09:18:13 --> Controller Class Initialized
INFO - 2018-11-27 09:18:13 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\payment/form1.php
INFO - 2018-11-27 09:18:13 --> Final output sent to browser
DEBUG - 2018-11-27 09:18:13 --> Total execution time: 0.0520
INFO - 2018-11-27 09:18:30 --> Config Class Initialized
INFO - 2018-11-27 09:18:30 --> Hooks Class Initialized
DEBUG - 2018-11-27 09:18:30 --> UTF-8 Support Enabled
INFO - 2018-11-27 09:18:30 --> Utf8 Class Initialized
INFO - 2018-11-27 09:18:30 --> URI Class Initialized
INFO - 2018-11-27 09:18:30 --> Router Class Initialized
INFO - 2018-11-27 09:18:30 --> Output Class Initialized
INFO - 2018-11-27 09:18:30 --> Security Class Initialized
DEBUG - 2018-11-27 09:18:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-27 09:18:30 --> Input Class Initialized
INFO - 2018-11-27 09:18:30 --> Language Class Initialized
INFO - 2018-11-27 09:18:30 --> Loader Class Initialized
INFO - 2018-11-27 09:18:30 --> Helper loaded: url_helper
INFO - 2018-11-27 09:18:30 --> Helper loaded: file_helper
INFO - 2018-11-27 09:18:30 --> Helper loaded: email_helper
INFO - 2018-11-27 09:18:30 --> Helper loaded: common_helper
INFO - 2018-11-27 09:18:30 --> Database Driver Class Initialized
DEBUG - 2018-11-27 09:18:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-27 09:18:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-27 09:18:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-27 09:18:30 --> Pagination Class Initialized
INFO - 2018-11-27 09:18:30 --> Helper loaded: form_helper
INFO - 2018-11-27 09:18:30 --> Form Validation Class Initialized
INFO - 2018-11-27 09:18:30 --> Model Class Initialized
INFO - 2018-11-27 09:18:30 --> Controller Class Initialized
ERROR - 2018-11-27 09:18:30 --> Severity: Notice --> Undefined variable: udf1 C:\xampp\htdocs\wetinuneed\application\views\payment\confirmation.php 20
ERROR - 2018-11-27 09:18:30 --> Severity: Notice --> Undefined variable: udf2 C:\xampp\htdocs\wetinuneed\application\views\payment\confirmation.php 21
INFO - 2018-11-27 09:18:30 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\payment/confirmation.php
INFO - 2018-11-27 09:18:30 --> Final output sent to browser
DEBUG - 2018-11-27 09:18:30 --> Total execution time: 0.0840
INFO - 2018-11-27 09:19:05 --> Config Class Initialized
INFO - 2018-11-27 09:19:05 --> Hooks Class Initialized
DEBUG - 2018-11-27 09:19:05 --> UTF-8 Support Enabled
INFO - 2018-11-27 09:19:05 --> Utf8 Class Initialized
INFO - 2018-11-27 09:19:05 --> URI Class Initialized
INFO - 2018-11-27 09:19:05 --> Router Class Initialized
INFO - 2018-11-27 09:19:05 --> Output Class Initialized
INFO - 2018-11-27 09:19:05 --> Security Class Initialized
DEBUG - 2018-11-27 09:19:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-27 09:19:05 --> Input Class Initialized
INFO - 2018-11-27 09:19:05 --> Language Class Initialized
INFO - 2018-11-27 09:19:05 --> Loader Class Initialized
INFO - 2018-11-27 09:19:05 --> Helper loaded: url_helper
INFO - 2018-11-27 09:19:05 --> Helper loaded: file_helper
INFO - 2018-11-27 09:19:05 --> Helper loaded: email_helper
INFO - 2018-11-27 09:19:05 --> Helper loaded: common_helper
INFO - 2018-11-27 09:19:05 --> Database Driver Class Initialized
DEBUG - 2018-11-27 09:19:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-27 09:19:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-27 09:19:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-27 09:19:05 --> Pagination Class Initialized
INFO - 2018-11-27 09:19:05 --> Helper loaded: form_helper
INFO - 2018-11-27 09:19:05 --> Form Validation Class Initialized
INFO - 2018-11-27 09:19:05 --> Model Class Initialized
INFO - 2018-11-27 09:19:05 --> Controller Class Initialized
INFO - 2018-11-27 09:19:05 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\payment/confirmation.php
INFO - 2018-11-27 09:19:05 --> Final output sent to browser
DEBUG - 2018-11-27 09:19:05 --> Total execution time: 0.0650
INFO - 2018-11-27 09:19:06 --> Config Class Initialized
INFO - 2018-11-27 09:19:06 --> Hooks Class Initialized
DEBUG - 2018-11-27 09:19:06 --> UTF-8 Support Enabled
INFO - 2018-11-27 09:19:06 --> Utf8 Class Initialized
INFO - 2018-11-27 09:19:06 --> URI Class Initialized
INFO - 2018-11-27 09:19:06 --> Router Class Initialized
INFO - 2018-11-27 09:19:06 --> Output Class Initialized
INFO - 2018-11-27 09:19:06 --> Security Class Initialized
DEBUG - 2018-11-27 09:19:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-27 09:19:06 --> Input Class Initialized
INFO - 2018-11-27 09:19:06 --> Language Class Initialized
ERROR - 2018-11-27 09:19:06 --> 404 Page Not Found: payment/My_controller/favicon.png
INFO - 2018-11-27 09:19:18 --> Config Class Initialized
INFO - 2018-11-27 09:19:18 --> Hooks Class Initialized
DEBUG - 2018-11-27 09:19:18 --> UTF-8 Support Enabled
INFO - 2018-11-27 09:19:18 --> Utf8 Class Initialized
INFO - 2018-11-27 09:19:18 --> URI Class Initialized
INFO - 2018-11-27 09:19:18 --> Router Class Initialized
INFO - 2018-11-27 09:19:18 --> Output Class Initialized
INFO - 2018-11-27 09:19:18 --> Security Class Initialized
DEBUG - 2018-11-27 09:19:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-27 09:19:18 --> Input Class Initialized
INFO - 2018-11-27 09:19:18 --> Language Class Initialized
INFO - 2018-11-27 09:19:18 --> Loader Class Initialized
INFO - 2018-11-27 09:19:18 --> Helper loaded: url_helper
INFO - 2018-11-27 09:19:18 --> Helper loaded: file_helper
INFO - 2018-11-27 09:19:18 --> Helper loaded: email_helper
INFO - 2018-11-27 09:19:18 --> Helper loaded: common_helper
INFO - 2018-11-27 09:19:18 --> Database Driver Class Initialized
DEBUG - 2018-11-27 09:19:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-27 09:19:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-27 09:19:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-27 09:19:18 --> Pagination Class Initialized
INFO - 2018-11-27 09:19:18 --> Helper loaded: form_helper
INFO - 2018-11-27 09:19:18 --> Form Validation Class Initialized
INFO - 2018-11-27 09:19:18 --> Model Class Initialized
INFO - 2018-11-27 09:19:18 --> Controller Class Initialized
INFO - 2018-11-27 09:19:18 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\payment/confirmation.php
INFO - 2018-11-27 09:19:18 --> Final output sent to browser
DEBUG - 2018-11-27 09:19:18 --> Total execution time: 0.0660
INFO - 2018-11-27 09:19:19 --> Config Class Initialized
INFO - 2018-11-27 09:19:19 --> Hooks Class Initialized
DEBUG - 2018-11-27 09:19:19 --> UTF-8 Support Enabled
INFO - 2018-11-27 09:19:19 --> Utf8 Class Initialized
INFO - 2018-11-27 09:19:19 --> URI Class Initialized
INFO - 2018-11-27 09:19:19 --> Router Class Initialized
INFO - 2018-11-27 09:19:19 --> Output Class Initialized
INFO - 2018-11-27 09:19:19 --> Security Class Initialized
DEBUG - 2018-11-27 09:19:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-27 09:19:19 --> Input Class Initialized
INFO - 2018-11-27 09:19:19 --> Language Class Initialized
ERROR - 2018-11-27 09:19:19 --> 404 Page Not Found: payment/My_controller/favicon.png
INFO - 2018-11-27 10:39:18 --> Config Class Initialized
INFO - 2018-11-27 10:39:18 --> Hooks Class Initialized
DEBUG - 2018-11-27 10:39:18 --> UTF-8 Support Enabled
INFO - 2018-11-27 10:39:18 --> Utf8 Class Initialized
INFO - 2018-11-27 10:39:18 --> URI Class Initialized
INFO - 2018-11-27 10:39:18 --> Router Class Initialized
INFO - 2018-11-27 10:39:18 --> Output Class Initialized
INFO - 2018-11-27 10:39:18 --> Security Class Initialized
DEBUG - 2018-11-27 10:39:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-27 10:39:18 --> Input Class Initialized
INFO - 2018-11-27 10:39:18 --> Language Class Initialized
INFO - 2018-11-27 10:39:18 --> Loader Class Initialized
INFO - 2018-11-27 10:39:18 --> Helper loaded: url_helper
INFO - 2018-11-27 10:39:18 --> Helper loaded: file_helper
INFO - 2018-11-27 10:39:18 --> Helper loaded: email_helper
INFO - 2018-11-27 10:39:18 --> Helper loaded: common_helper
INFO - 2018-11-27 10:39:18 --> Database Driver Class Initialized
DEBUG - 2018-11-27 10:39:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-27 10:39:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-27 10:39:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-27 10:39:18 --> Pagination Class Initialized
INFO - 2018-11-27 10:39:18 --> Helper loaded: form_helper
INFO - 2018-11-27 10:39:18 --> Form Validation Class Initialized
INFO - 2018-11-27 10:39:18 --> Model Class Initialized
INFO - 2018-11-27 10:39:18 --> Controller Class Initialized
INFO - 2018-11-27 10:39:18 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\payment/form1.php
INFO - 2018-11-27 10:39:18 --> Final output sent to browser
DEBUG - 2018-11-27 10:39:18 --> Total execution time: 0.0880
INFO - 2018-11-27 10:39:19 --> Config Class Initialized
INFO - 2018-11-27 10:39:19 --> Hooks Class Initialized
DEBUG - 2018-11-27 10:39:19 --> UTF-8 Support Enabled
INFO - 2018-11-27 10:39:19 --> Utf8 Class Initialized
INFO - 2018-11-27 10:39:19 --> URI Class Initialized
INFO - 2018-11-27 10:39:19 --> Router Class Initialized
INFO - 2018-11-27 10:39:19 --> Output Class Initialized
INFO - 2018-11-27 10:39:19 --> Security Class Initialized
DEBUG - 2018-11-27 10:39:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-27 10:39:19 --> Input Class Initialized
INFO - 2018-11-27 10:39:19 --> Language Class Initialized
ERROR - 2018-11-27 10:39:19 --> 404 Page Not Found: payment/Img/favicon.png
INFO - 2018-11-27 10:40:01 --> Config Class Initialized
INFO - 2018-11-27 10:40:01 --> Hooks Class Initialized
DEBUG - 2018-11-27 10:40:01 --> UTF-8 Support Enabled
INFO - 2018-11-27 10:40:01 --> Utf8 Class Initialized
INFO - 2018-11-27 10:40:01 --> URI Class Initialized
INFO - 2018-11-27 10:40:01 --> Router Class Initialized
INFO - 2018-11-27 10:40:01 --> Output Class Initialized
INFO - 2018-11-27 10:40:01 --> Security Class Initialized
DEBUG - 2018-11-27 10:40:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-27 10:40:01 --> Input Class Initialized
INFO - 2018-11-27 10:40:01 --> Language Class Initialized
INFO - 2018-11-27 10:40:01 --> Loader Class Initialized
INFO - 2018-11-27 10:40:01 --> Helper loaded: url_helper
INFO - 2018-11-27 10:40:01 --> Helper loaded: file_helper
INFO - 2018-11-27 10:40:01 --> Helper loaded: email_helper
INFO - 2018-11-27 10:40:01 --> Helper loaded: common_helper
INFO - 2018-11-27 10:40:01 --> Database Driver Class Initialized
DEBUG - 2018-11-27 10:40:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-27 10:40:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-27 10:40:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-27 10:40:01 --> Pagination Class Initialized
INFO - 2018-11-27 10:40:01 --> Helper loaded: form_helper
INFO - 2018-11-27 10:40:01 --> Form Validation Class Initialized
INFO - 2018-11-27 10:40:01 --> Model Class Initialized
INFO - 2018-11-27 10:40:01 --> Controller Class Initialized
INFO - 2018-11-27 10:40:01 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\payment/confirmation.php
INFO - 2018-11-27 10:40:01 --> Final output sent to browser
DEBUG - 2018-11-27 10:40:01 --> Total execution time: 0.0690
INFO - 2018-11-27 10:40:02 --> Config Class Initialized
INFO - 2018-11-27 10:40:02 --> Hooks Class Initialized
DEBUG - 2018-11-27 10:40:02 --> UTF-8 Support Enabled
INFO - 2018-11-27 10:40:02 --> Utf8 Class Initialized
INFO - 2018-11-27 10:40:02 --> URI Class Initialized
INFO - 2018-11-27 10:40:02 --> Router Class Initialized
INFO - 2018-11-27 10:40:02 --> Output Class Initialized
INFO - 2018-11-27 10:40:02 --> Security Class Initialized
DEBUG - 2018-11-27 10:40:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-27 10:40:02 --> Input Class Initialized
INFO - 2018-11-27 10:40:02 --> Language Class Initialized
ERROR - 2018-11-27 10:40:02 --> 404 Page Not Found: payment/My_controller/favicon.png
INFO - 2018-11-27 10:40:15 --> Config Class Initialized
INFO - 2018-11-27 10:40:15 --> Hooks Class Initialized
DEBUG - 2018-11-27 10:40:15 --> UTF-8 Support Enabled
INFO - 2018-11-27 10:40:15 --> Utf8 Class Initialized
INFO - 2018-11-27 10:40:15 --> URI Class Initialized
INFO - 2018-11-27 10:40:15 --> Router Class Initialized
INFO - 2018-11-27 10:40:15 --> Output Class Initialized
INFO - 2018-11-27 10:40:15 --> Security Class Initialized
DEBUG - 2018-11-27 10:40:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-27 10:40:15 --> Input Class Initialized
INFO - 2018-11-27 10:40:15 --> Language Class Initialized
INFO - 2018-11-27 10:40:15 --> Loader Class Initialized
INFO - 2018-11-27 10:40:15 --> Helper loaded: url_helper
INFO - 2018-11-27 10:40:15 --> Helper loaded: file_helper
INFO - 2018-11-27 10:40:15 --> Helper loaded: email_helper
INFO - 2018-11-27 10:40:15 --> Helper loaded: common_helper
INFO - 2018-11-27 10:40:15 --> Database Driver Class Initialized
DEBUG - 2018-11-27 10:40:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-27 10:40:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-27 10:40:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-27 10:40:15 --> Pagination Class Initialized
INFO - 2018-11-27 10:40:15 --> Helper loaded: form_helper
INFO - 2018-11-27 10:40:15 --> Form Validation Class Initialized
INFO - 2018-11-27 10:40:15 --> Model Class Initialized
INFO - 2018-11-27 10:40:15 --> Controller Class Initialized
INFO - 2018-11-27 10:40:15 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\payment/form1.php
INFO - 2018-11-27 10:40:15 --> Final output sent to browser
DEBUG - 2018-11-27 10:40:15 --> Total execution time: 0.0710
INFO - 2018-11-27 10:40:22 --> Config Class Initialized
INFO - 2018-11-27 10:40:22 --> Hooks Class Initialized
DEBUG - 2018-11-27 10:40:22 --> UTF-8 Support Enabled
INFO - 2018-11-27 10:40:22 --> Utf8 Class Initialized
INFO - 2018-11-27 10:40:22 --> URI Class Initialized
INFO - 2018-11-27 10:40:22 --> Router Class Initialized
INFO - 2018-11-27 10:40:22 --> Output Class Initialized
INFO - 2018-11-27 10:40:22 --> Security Class Initialized
DEBUG - 2018-11-27 10:40:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-27 10:40:22 --> Input Class Initialized
INFO - 2018-11-27 10:40:22 --> Language Class Initialized
INFO - 2018-11-27 10:40:22 --> Loader Class Initialized
INFO - 2018-11-27 10:40:22 --> Helper loaded: url_helper
INFO - 2018-11-27 10:40:22 --> Helper loaded: file_helper
INFO - 2018-11-27 10:40:22 --> Helper loaded: email_helper
INFO - 2018-11-27 10:40:22 --> Helper loaded: common_helper
INFO - 2018-11-27 10:40:22 --> Database Driver Class Initialized
DEBUG - 2018-11-27 10:40:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-27 10:40:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-27 10:40:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-27 10:40:22 --> Pagination Class Initialized
INFO - 2018-11-27 10:40:22 --> Helper loaded: form_helper
INFO - 2018-11-27 10:40:22 --> Form Validation Class Initialized
INFO - 2018-11-27 10:40:22 --> Model Class Initialized
INFO - 2018-11-27 10:40:22 --> Controller Class Initialized
INFO - 2018-11-27 10:40:22 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\payment/confirmation.php
INFO - 2018-11-27 10:40:22 --> Final output sent to browser
DEBUG - 2018-11-27 10:40:22 --> Total execution time: 0.0720
INFO - 2018-11-27 11:03:29 --> Config Class Initialized
INFO - 2018-11-27 11:03:29 --> Hooks Class Initialized
DEBUG - 2018-11-27 11:03:29 --> UTF-8 Support Enabled
INFO - 2018-11-27 11:03:29 --> Utf8 Class Initialized
INFO - 2018-11-27 11:03:29 --> URI Class Initialized
INFO - 2018-11-27 11:03:29 --> Router Class Initialized
INFO - 2018-11-27 11:03:29 --> Output Class Initialized
INFO - 2018-11-27 11:03:29 --> Security Class Initialized
DEBUG - 2018-11-27 11:03:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-27 11:03:29 --> Input Class Initialized
INFO - 2018-11-27 11:03:29 --> Language Class Initialized
ERROR - 2018-11-27 11:03:29 --> 404 Page Not Found: /index
INFO - 2018-11-27 11:03:55 --> Config Class Initialized
INFO - 2018-11-27 11:03:55 --> Hooks Class Initialized
DEBUG - 2018-11-27 11:03:55 --> UTF-8 Support Enabled
INFO - 2018-11-27 11:03:55 --> Utf8 Class Initialized
INFO - 2018-11-27 11:03:55 --> URI Class Initialized
INFO - 2018-11-27 11:03:55 --> Router Class Initialized
INFO - 2018-11-27 11:03:55 --> Output Class Initialized
INFO - 2018-11-27 11:03:55 --> Security Class Initialized
DEBUG - 2018-11-27 11:03:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-27 11:03:55 --> Input Class Initialized
INFO - 2018-11-27 11:03:55 --> Language Class Initialized
ERROR - 2018-11-27 11:03:55 --> 404 Page Not Found: /index
INFO - 2018-11-27 11:03:58 --> Config Class Initialized
INFO - 2018-11-27 11:03:58 --> Hooks Class Initialized
DEBUG - 2018-11-27 11:03:58 --> UTF-8 Support Enabled
INFO - 2018-11-27 11:03:58 --> Utf8 Class Initialized
INFO - 2018-11-27 11:03:58 --> URI Class Initialized
INFO - 2018-11-27 11:03:58 --> Router Class Initialized
INFO - 2018-11-27 11:03:58 --> Output Class Initialized
INFO - 2018-11-27 11:03:58 --> Security Class Initialized
DEBUG - 2018-11-27 11:03:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-27 11:03:58 --> Input Class Initialized
INFO - 2018-11-27 11:03:58 --> Language Class Initialized
ERROR - 2018-11-27 11:03:58 --> 404 Page Not Found: /index
INFO - 2018-11-27 11:04:04 --> Config Class Initialized
INFO - 2018-11-27 11:04:04 --> Hooks Class Initialized
DEBUG - 2018-11-27 11:04:04 --> UTF-8 Support Enabled
INFO - 2018-11-27 11:04:04 --> Utf8 Class Initialized
INFO - 2018-11-27 11:04:04 --> URI Class Initialized
INFO - 2018-11-27 11:04:04 --> Router Class Initialized
INFO - 2018-11-27 11:04:04 --> Output Class Initialized
INFO - 2018-11-27 11:04:04 --> Security Class Initialized
DEBUG - 2018-11-27 11:04:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-27 11:04:04 --> Input Class Initialized
INFO - 2018-11-27 11:04:04 --> Language Class Initialized
ERROR - 2018-11-27 11:04:04 --> 404 Page Not Found: /index
INFO - 2018-11-27 11:05:01 --> Config Class Initialized
INFO - 2018-11-27 11:05:01 --> Hooks Class Initialized
DEBUG - 2018-11-27 11:05:01 --> UTF-8 Support Enabled
INFO - 2018-11-27 11:05:01 --> Utf8 Class Initialized
INFO - 2018-11-27 11:05:01 --> URI Class Initialized
INFO - 2018-11-27 11:05:01 --> Router Class Initialized
INFO - 2018-11-27 11:05:01 --> Output Class Initialized
INFO - 2018-11-27 11:05:01 --> Security Class Initialized
DEBUG - 2018-11-27 11:05:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-27 11:05:01 --> Input Class Initialized
INFO - 2018-11-27 11:05:01 --> Language Class Initialized
ERROR - 2018-11-27 11:05:01 --> 404 Page Not Found: /index
INFO - 2018-11-27 11:13:25 --> Config Class Initialized
INFO - 2018-11-27 11:13:25 --> Hooks Class Initialized
DEBUG - 2018-11-27 11:13:25 --> UTF-8 Support Enabled
INFO - 2018-11-27 11:13:25 --> Utf8 Class Initialized
INFO - 2018-11-27 11:13:25 --> URI Class Initialized
INFO - 2018-11-27 11:13:25 --> Router Class Initialized
INFO - 2018-11-27 11:13:25 --> Output Class Initialized
INFO - 2018-11-27 11:13:25 --> Security Class Initialized
DEBUG - 2018-11-27 11:13:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-27 11:13:25 --> Input Class Initialized
INFO - 2018-11-27 11:13:25 --> Language Class Initialized
ERROR - 2018-11-27 11:13:25 --> 404 Page Not Found: /index
INFO - 2018-11-27 11:15:13 --> Config Class Initialized
INFO - 2018-11-27 11:15:13 --> Hooks Class Initialized
DEBUG - 2018-11-27 11:15:13 --> UTF-8 Support Enabled
INFO - 2018-11-27 11:15:13 --> Utf8 Class Initialized
INFO - 2018-11-27 11:15:13 --> URI Class Initialized
DEBUG - 2018-11-27 11:15:13 --> No URI present. Default controller set.
INFO - 2018-11-27 11:15:13 --> Router Class Initialized
INFO - 2018-11-27 11:15:13 --> Output Class Initialized
INFO - 2018-11-27 11:15:13 --> Security Class Initialized
DEBUG - 2018-11-27 11:15:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-27 11:15:13 --> Input Class Initialized
INFO - 2018-11-27 11:15:13 --> Language Class Initialized
INFO - 2018-11-27 11:15:13 --> Loader Class Initialized
INFO - 2018-11-27 11:15:13 --> Helper loaded: url_helper
INFO - 2018-11-27 11:15:13 --> Helper loaded: file_helper
INFO - 2018-11-27 11:15:13 --> Helper loaded: email_helper
INFO - 2018-11-27 11:15:13 --> Helper loaded: common_helper
INFO - 2018-11-27 11:15:13 --> Database Driver Class Initialized
DEBUG - 2018-11-27 11:15:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-27 11:15:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-27 11:15:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-27 11:15:13 --> Pagination Class Initialized
INFO - 2018-11-27 11:15:13 --> Helper loaded: form_helper
INFO - 2018-11-27 11:15:13 --> Form Validation Class Initialized
ERROR - 2018-11-27 11:15:13 --> Severity: error --> Exception: Unable to locate the model you have specified: Common_model C:\xampp\htdocs\payment_example\system\core\Loader.php 344
INFO - 2018-11-27 11:17:29 --> Config Class Initialized
INFO - 2018-11-27 11:17:29 --> Hooks Class Initialized
DEBUG - 2018-11-27 11:17:29 --> UTF-8 Support Enabled
INFO - 2018-11-27 11:17:29 --> Utf8 Class Initialized
INFO - 2018-11-27 11:17:29 --> URI Class Initialized
DEBUG - 2018-11-27 11:17:29 --> No URI present. Default controller set.
INFO - 2018-11-27 11:17:29 --> Router Class Initialized
INFO - 2018-11-27 11:17:29 --> Output Class Initialized
INFO - 2018-11-27 11:17:29 --> Security Class Initialized
DEBUG - 2018-11-27 11:17:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-27 11:17:29 --> Input Class Initialized
INFO - 2018-11-27 11:17:29 --> Language Class Initialized
INFO - 2018-11-27 11:17:29 --> Loader Class Initialized
INFO - 2018-11-27 11:17:29 --> Helper loaded: url_helper
INFO - 2018-11-27 11:17:29 --> Helper loaded: file_helper
INFO - 2018-11-27 11:17:29 --> Helper loaded: email_helper
INFO - 2018-11-27 11:17:29 --> Helper loaded: common_helper
INFO - 2018-11-27 11:17:29 --> Database Driver Class Initialized
DEBUG - 2018-11-27 11:17:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-27 11:17:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-27 11:17:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-27 11:17:29 --> Pagination Class Initialized
INFO - 2018-11-27 11:17:29 --> Helper loaded: form_helper
INFO - 2018-11-27 11:17:29 --> Form Validation Class Initialized
ERROR - 2018-11-27 11:17:29 --> Severity: error --> Exception: Unable to locate the model you have specified: Common_model C:\xampp\htdocs\payment_example\system\core\Loader.php 344
INFO - 2018-11-27 11:18:38 --> Config Class Initialized
INFO - 2018-11-27 11:18:38 --> Hooks Class Initialized
DEBUG - 2018-11-27 11:18:38 --> UTF-8 Support Enabled
INFO - 2018-11-27 11:18:38 --> Utf8 Class Initialized
INFO - 2018-11-27 11:18:38 --> URI Class Initialized
DEBUG - 2018-11-27 11:18:38 --> No URI present. Default controller set.
INFO - 2018-11-27 11:18:38 --> Router Class Initialized
INFO - 2018-11-27 11:18:38 --> Output Class Initialized
INFO - 2018-11-27 11:18:38 --> Security Class Initialized
DEBUG - 2018-11-27 11:18:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-27 11:18:38 --> Input Class Initialized
INFO - 2018-11-27 11:18:38 --> Language Class Initialized
INFO - 2018-11-27 11:18:38 --> Loader Class Initialized
INFO - 2018-11-27 11:18:38 --> Helper loaded: url_helper
INFO - 2018-11-27 11:18:38 --> Helper loaded: file_helper
INFO - 2018-11-27 11:18:38 --> Helper loaded: email_helper
INFO - 2018-11-27 11:18:38 --> Helper loaded: common_helper
INFO - 2018-11-27 11:18:38 --> Database Driver Class Initialized
DEBUG - 2018-11-27 11:18:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-27 11:18:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-27 11:18:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-27 11:18:38 --> Pagination Class Initialized
INFO - 2018-11-27 11:18:38 --> Helper loaded: form_helper
INFO - 2018-11-27 11:18:38 --> Form Validation Class Initialized
INFO - 2018-11-27 11:18:38 --> Controller Class Initialized
INFO - 2018-11-27 11:18:38 --> File loaded: C:\xampp\htdocs\payment_example\application\views\payu_payment/form1.php
INFO - 2018-11-27 11:18:38 --> Final output sent to browser
DEBUG - 2018-11-27 11:18:38 --> Total execution time: 0.0580
INFO - 2018-11-27 11:18:39 --> Config Class Initialized
INFO - 2018-11-27 11:18:39 --> Hooks Class Initialized
DEBUG - 2018-11-27 11:18:39 --> UTF-8 Support Enabled
INFO - 2018-11-27 11:18:39 --> Utf8 Class Initialized
INFO - 2018-11-27 11:18:39 --> URI Class Initialized
INFO - 2018-11-27 11:18:39 --> Router Class Initialized
INFO - 2018-11-27 11:18:39 --> Output Class Initialized
INFO - 2018-11-27 11:18:39 --> Security Class Initialized
DEBUG - 2018-11-27 11:18:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-27 11:18:39 --> Input Class Initialized
INFO - 2018-11-27 11:18:39 --> Language Class Initialized
ERROR - 2018-11-27 11:18:39 --> 404 Page Not Found: Img/favicon.png
INFO - 2018-11-27 11:18:46 --> Config Class Initialized
INFO - 2018-11-27 11:18:46 --> Hooks Class Initialized
DEBUG - 2018-11-27 11:18:46 --> UTF-8 Support Enabled
INFO - 2018-11-27 11:18:46 --> Utf8 Class Initialized
INFO - 2018-11-27 11:18:46 --> URI Class Initialized
DEBUG - 2018-11-27 11:18:46 --> No URI present. Default controller set.
INFO - 2018-11-27 11:18:46 --> Router Class Initialized
INFO - 2018-11-27 11:18:46 --> Output Class Initialized
INFO - 2018-11-27 11:18:46 --> Security Class Initialized
DEBUG - 2018-11-27 11:18:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-27 11:18:46 --> Input Class Initialized
INFO - 2018-11-27 11:18:46 --> Language Class Initialized
INFO - 2018-11-27 11:18:46 --> Loader Class Initialized
INFO - 2018-11-27 11:18:46 --> Helper loaded: url_helper
INFO - 2018-11-27 11:18:46 --> Helper loaded: file_helper
INFO - 2018-11-27 11:18:46 --> Helper loaded: email_helper
INFO - 2018-11-27 11:18:46 --> Helper loaded: common_helper
INFO - 2018-11-27 11:18:46 --> Database Driver Class Initialized
DEBUG - 2018-11-27 11:18:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-27 11:18:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-27 11:18:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-27 11:18:46 --> Pagination Class Initialized
INFO - 2018-11-27 11:18:46 --> Helper loaded: form_helper
INFO - 2018-11-27 11:18:46 --> Form Validation Class Initialized
INFO - 2018-11-27 11:18:46 --> Controller Class Initialized
INFO - 2018-11-27 11:18:46 --> File loaded: C:\xampp\htdocs\payment_example\application\views\payu_payment/form1.php
INFO - 2018-11-27 11:18:46 --> Final output sent to browser
DEBUG - 2018-11-27 11:18:46 --> Total execution time: 0.0610
INFO - 2018-11-27 11:18:46 --> Config Class Initialized
INFO - 2018-11-27 11:18:46 --> Hooks Class Initialized
DEBUG - 2018-11-27 11:18:46 --> UTF-8 Support Enabled
INFO - 2018-11-27 11:18:46 --> Utf8 Class Initialized
INFO - 2018-11-27 11:18:46 --> URI Class Initialized
INFO - 2018-11-27 11:18:46 --> Router Class Initialized
INFO - 2018-11-27 11:18:46 --> Output Class Initialized
INFO - 2018-11-27 11:18:46 --> Security Class Initialized
DEBUG - 2018-11-27 11:18:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-27 11:18:46 --> Input Class Initialized
INFO - 2018-11-27 11:18:46 --> Language Class Initialized
ERROR - 2018-11-27 11:18:47 --> 404 Page Not Found: Img/favicon.png
INFO - 2018-11-27 11:18:48 --> Config Class Initialized
INFO - 2018-11-27 11:18:48 --> Hooks Class Initialized
DEBUG - 2018-11-27 11:18:48 --> UTF-8 Support Enabled
INFO - 2018-11-27 11:18:48 --> Utf8 Class Initialized
INFO - 2018-11-27 11:18:48 --> URI Class Initialized
INFO - 2018-11-27 11:18:48 --> Router Class Initialized
INFO - 2018-11-27 11:18:48 --> Output Class Initialized
INFO - 2018-11-27 11:18:48 --> Security Class Initialized
DEBUG - 2018-11-27 11:18:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-27 11:18:48 --> Input Class Initialized
INFO - 2018-11-27 11:18:48 --> Language Class Initialized
INFO - 2018-11-27 11:18:48 --> Loader Class Initialized
INFO - 2018-11-27 11:18:48 --> Helper loaded: url_helper
INFO - 2018-11-27 11:18:48 --> Helper loaded: file_helper
INFO - 2018-11-27 11:18:48 --> Helper loaded: email_helper
INFO - 2018-11-27 11:18:48 --> Helper loaded: common_helper
INFO - 2018-11-27 11:18:48 --> Database Driver Class Initialized
DEBUG - 2018-11-27 11:18:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-27 11:18:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-27 11:18:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-27 11:18:48 --> Pagination Class Initialized
INFO - 2018-11-27 11:18:48 --> Helper loaded: form_helper
INFO - 2018-11-27 11:18:48 --> Form Validation Class Initialized
INFO - 2018-11-27 11:18:48 --> Controller Class Initialized
INFO - 2018-11-27 11:18:48 --> File loaded: C:\xampp\htdocs\payment_example\application\views\payu_payment/confirmation.php
INFO - 2018-11-27 11:18:48 --> Final output sent to browser
DEBUG - 2018-11-27 11:18:48 --> Total execution time: 0.0670
INFO - 2018-11-27 11:18:48 --> Config Class Initialized
INFO - 2018-11-27 11:18:48 --> Hooks Class Initialized
DEBUG - 2018-11-27 11:18:48 --> UTF-8 Support Enabled
INFO - 2018-11-27 11:18:48 --> Utf8 Class Initialized
INFO - 2018-11-27 11:18:48 --> URI Class Initialized
INFO - 2018-11-27 11:18:48 --> Router Class Initialized
INFO - 2018-11-27 11:18:48 --> Output Class Initialized
INFO - 2018-11-27 11:18:48 --> Security Class Initialized
DEBUG - 2018-11-27 11:18:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-27 11:18:48 --> Input Class Initialized
INFO - 2018-11-27 11:18:48 --> Language Class Initialized
ERROR - 2018-11-27 11:18:48 --> 404 Page Not Found: My_controller/favicon.png
INFO - 2018-11-27 11:19:23 --> Config Class Initialized
INFO - 2018-11-27 11:19:23 --> Hooks Class Initialized
DEBUG - 2018-11-27 11:19:23 --> UTF-8 Support Enabled
INFO - 2018-11-27 11:19:23 --> Utf8 Class Initialized
INFO - 2018-11-27 11:19:23 --> URI Class Initialized
DEBUG - 2018-11-27 11:19:23 --> No URI present. Default controller set.
INFO - 2018-11-27 11:19:23 --> Router Class Initialized
INFO - 2018-11-27 11:19:23 --> Output Class Initialized
INFO - 2018-11-27 11:19:23 --> Security Class Initialized
DEBUG - 2018-11-27 11:19:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-27 11:19:23 --> Input Class Initialized
INFO - 2018-11-27 11:19:23 --> Language Class Initialized
INFO - 2018-11-27 11:19:23 --> Loader Class Initialized
INFO - 2018-11-27 11:19:23 --> Helper loaded: url_helper
INFO - 2018-11-27 11:19:23 --> Helper loaded: file_helper
INFO - 2018-11-27 11:19:23 --> Helper loaded: email_helper
INFO - 2018-11-27 11:19:23 --> Helper loaded: common_helper
INFO - 2018-11-27 11:19:23 --> Database Driver Class Initialized
DEBUG - 2018-11-27 11:19:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-27 11:19:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-27 11:19:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-27 11:19:24 --> Pagination Class Initialized
INFO - 2018-11-27 11:19:24 --> Helper loaded: form_helper
INFO - 2018-11-27 11:19:24 --> Form Validation Class Initialized
INFO - 2018-11-27 11:19:24 --> Controller Class Initialized
INFO - 2018-11-27 11:19:24 --> File loaded: C:\xampp\htdocs\payment_example\application\views\payu_payment/form1.php
INFO - 2018-11-27 11:19:24 --> Final output sent to browser
DEBUG - 2018-11-27 11:19:24 --> Total execution time: 0.0660
INFO - 2018-11-27 11:27:47 --> Config Class Initialized
INFO - 2018-11-27 11:27:47 --> Hooks Class Initialized
DEBUG - 2018-11-27 11:27:47 --> UTF-8 Support Enabled
INFO - 2018-11-27 11:27:47 --> Utf8 Class Initialized
INFO - 2018-11-27 11:27:47 --> URI Class Initialized
DEBUG - 2018-11-27 11:27:47 --> No URI present. Default controller set.
INFO - 2018-11-27 11:27:47 --> Router Class Initialized
INFO - 2018-11-27 11:27:47 --> Output Class Initialized
INFO - 2018-11-27 11:27:47 --> Security Class Initialized
DEBUG - 2018-11-27 11:27:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-27 11:27:47 --> Input Class Initialized
INFO - 2018-11-27 11:27:47 --> Language Class Initialized
INFO - 2018-11-27 11:27:47 --> Loader Class Initialized
INFO - 2018-11-27 11:27:47 --> Helper loaded: url_helper
INFO - 2018-11-27 11:27:47 --> Helper loaded: file_helper
INFO - 2018-11-27 11:27:47 --> Helper loaded: email_helper
INFO - 2018-11-27 11:27:47 --> Helper loaded: common_helper
INFO - 2018-11-27 11:27:47 --> Database Driver Class Initialized
DEBUG - 2018-11-27 11:27:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-27 11:27:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-27 11:27:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-27 11:27:47 --> Pagination Class Initialized
INFO - 2018-11-27 11:27:47 --> Helper loaded: form_helper
INFO - 2018-11-27 11:27:47 --> Form Validation Class Initialized
INFO - 2018-11-27 11:27:47 --> Controller Class Initialized
INFO - 2018-11-27 11:27:47 --> File loaded: C:\xampp\htdocs\payment_example\application\views\payu_payment/index.php
INFO - 2018-11-27 11:27:47 --> Final output sent to browser
DEBUG - 2018-11-27 11:27:47 --> Total execution time: 0.0540
INFO - 2018-11-27 11:27:49 --> Config Class Initialized
INFO - 2018-11-27 11:27:49 --> Hooks Class Initialized
DEBUG - 2018-11-27 11:27:49 --> UTF-8 Support Enabled
INFO - 2018-11-27 11:27:49 --> Utf8 Class Initialized
INFO - 2018-11-27 11:27:49 --> URI Class Initialized
INFO - 2018-11-27 11:27:49 --> Router Class Initialized
INFO - 2018-11-27 11:27:49 --> Output Class Initialized
INFO - 2018-11-27 11:27:49 --> Security Class Initialized
DEBUG - 2018-11-27 11:27:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-27 11:27:49 --> Input Class Initialized
INFO - 2018-11-27 11:27:49 --> Language Class Initialized
ERROR - 2018-11-27 11:27:49 --> 404 Page Not Found: Img/favicon.png
INFO - 2018-11-27 11:30:04 --> Config Class Initialized
INFO - 2018-11-27 11:30:04 --> Hooks Class Initialized
DEBUG - 2018-11-27 11:30:04 --> UTF-8 Support Enabled
INFO - 2018-11-27 11:30:04 --> Utf8 Class Initialized
INFO - 2018-11-27 11:30:04 --> URI Class Initialized
DEBUG - 2018-11-27 11:30:04 --> No URI present. Default controller set.
INFO - 2018-11-27 11:30:04 --> Router Class Initialized
INFO - 2018-11-27 11:30:04 --> Output Class Initialized
INFO - 2018-11-27 11:30:04 --> Security Class Initialized
DEBUG - 2018-11-27 11:30:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-27 11:30:04 --> Input Class Initialized
INFO - 2018-11-27 11:30:04 --> Language Class Initialized
INFO - 2018-11-27 11:30:05 --> Loader Class Initialized
INFO - 2018-11-27 11:30:05 --> Helper loaded: url_helper
INFO - 2018-11-27 11:30:05 --> Helper loaded: file_helper
INFO - 2018-11-27 11:30:05 --> Helper loaded: email_helper
INFO - 2018-11-27 11:30:05 --> Helper loaded: common_helper
INFO - 2018-11-27 11:30:05 --> Database Driver Class Initialized
DEBUG - 2018-11-27 11:30:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-27 11:30:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-27 11:30:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-27 11:30:05 --> Pagination Class Initialized
INFO - 2018-11-27 11:30:05 --> Helper loaded: form_helper
INFO - 2018-11-27 11:30:05 --> Form Validation Class Initialized
INFO - 2018-11-27 11:30:05 --> Controller Class Initialized
INFO - 2018-11-27 11:30:05 --> File loaded: C:\xampp\htdocs\payment_example\application\views\payu_payment/index.php
INFO - 2018-11-27 11:30:05 --> Final output sent to browser
DEBUG - 2018-11-27 11:30:05 --> Total execution time: 0.0830
INFO - 2018-11-27 11:30:06 --> Config Class Initialized
INFO - 2018-11-27 11:30:06 --> Hooks Class Initialized
DEBUG - 2018-11-27 11:30:06 --> UTF-8 Support Enabled
INFO - 2018-11-27 11:30:06 --> Utf8 Class Initialized
INFO - 2018-11-27 11:30:06 --> URI Class Initialized
INFO - 2018-11-27 11:30:06 --> Router Class Initialized
INFO - 2018-11-27 11:30:06 --> Output Class Initialized
INFO - 2018-11-27 11:30:06 --> Security Class Initialized
DEBUG - 2018-11-27 11:30:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-27 11:30:06 --> Input Class Initialized
INFO - 2018-11-27 11:30:06 --> Language Class Initialized
ERROR - 2018-11-27 11:30:06 --> 404 Page Not Found: Img/favicon.png
INFO - 2018-11-27 11:30:56 --> Config Class Initialized
INFO - 2018-11-27 11:30:56 --> Hooks Class Initialized
DEBUG - 2018-11-27 11:30:56 --> UTF-8 Support Enabled
INFO - 2018-11-27 11:30:56 --> Utf8 Class Initialized
INFO - 2018-11-27 11:30:56 --> URI Class Initialized
DEBUG - 2018-11-27 11:30:56 --> No URI present. Default controller set.
INFO - 2018-11-27 11:30:56 --> Router Class Initialized
INFO - 2018-11-27 11:30:56 --> Output Class Initialized
INFO - 2018-11-27 11:30:56 --> Security Class Initialized
DEBUG - 2018-11-27 11:30:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-27 11:30:56 --> Input Class Initialized
INFO - 2018-11-27 11:30:56 --> Language Class Initialized
INFO - 2018-11-27 11:30:56 --> Loader Class Initialized
INFO - 2018-11-27 11:30:56 --> Helper loaded: url_helper
INFO - 2018-11-27 11:30:56 --> Helper loaded: file_helper
INFO - 2018-11-27 11:30:56 --> Helper loaded: email_helper
INFO - 2018-11-27 11:30:56 --> Helper loaded: common_helper
INFO - 2018-11-27 11:30:56 --> Database Driver Class Initialized
DEBUG - 2018-11-27 11:30:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-27 11:30:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-27 11:30:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-27 11:30:56 --> Pagination Class Initialized
INFO - 2018-11-27 11:30:56 --> Helper loaded: form_helper
INFO - 2018-11-27 11:30:56 --> Form Validation Class Initialized
INFO - 2018-11-27 11:30:56 --> Controller Class Initialized
INFO - 2018-11-27 11:30:56 --> File loaded: C:\xampp\htdocs\payment_example\application\views\payu_payment/index.php
INFO - 2018-11-27 11:30:56 --> Final output sent to browser
DEBUG - 2018-11-27 11:30:56 --> Total execution time: 0.0450
INFO - 2018-11-27 11:30:58 --> Config Class Initialized
INFO - 2018-11-27 11:30:58 --> Hooks Class Initialized
DEBUG - 2018-11-27 11:30:58 --> UTF-8 Support Enabled
INFO - 2018-11-27 11:30:58 --> Utf8 Class Initialized
INFO - 2018-11-27 11:30:58 --> URI Class Initialized
INFO - 2018-11-27 11:30:58 --> Router Class Initialized
INFO - 2018-11-27 11:30:58 --> Output Class Initialized
INFO - 2018-11-27 11:30:58 --> Security Class Initialized
DEBUG - 2018-11-27 11:30:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-27 11:30:58 --> Input Class Initialized
INFO - 2018-11-27 11:30:58 --> Language Class Initialized
ERROR - 2018-11-27 11:30:58 --> 404 Page Not Found: Img/favicon.png
INFO - 2018-11-27 11:31:27 --> Config Class Initialized
INFO - 2018-11-27 11:31:27 --> Hooks Class Initialized
DEBUG - 2018-11-27 11:31:27 --> UTF-8 Support Enabled
INFO - 2018-11-27 11:31:27 --> Utf8 Class Initialized
INFO - 2018-11-27 11:31:27 --> URI Class Initialized
DEBUG - 2018-11-27 11:31:27 --> No URI present. Default controller set.
INFO - 2018-11-27 11:31:27 --> Router Class Initialized
INFO - 2018-11-27 11:31:27 --> Output Class Initialized
INFO - 2018-11-27 11:31:27 --> Security Class Initialized
DEBUG - 2018-11-27 11:31:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-27 11:31:27 --> Input Class Initialized
INFO - 2018-11-27 11:31:27 --> Language Class Initialized
INFO - 2018-11-27 11:31:27 --> Loader Class Initialized
INFO - 2018-11-27 11:31:27 --> Helper loaded: url_helper
INFO - 2018-11-27 11:31:27 --> Helper loaded: file_helper
INFO - 2018-11-27 11:31:27 --> Helper loaded: email_helper
INFO - 2018-11-27 11:31:27 --> Helper loaded: common_helper
INFO - 2018-11-27 11:31:27 --> Database Driver Class Initialized
DEBUG - 2018-11-27 11:31:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-27 11:31:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-27 11:31:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-27 11:31:27 --> Pagination Class Initialized
INFO - 2018-11-27 11:31:27 --> Helper loaded: form_helper
INFO - 2018-11-27 11:31:27 --> Form Validation Class Initialized
INFO - 2018-11-27 11:31:27 --> Controller Class Initialized
INFO - 2018-11-27 11:31:27 --> File loaded: C:\xampp\htdocs\payment_example\application\views\payu_payment/index.php
INFO - 2018-11-27 11:31:27 --> Final output sent to browser
DEBUG - 2018-11-27 11:31:27 --> Total execution time: 0.0470
INFO - 2018-11-27 11:31:29 --> Config Class Initialized
INFO - 2018-11-27 11:31:29 --> Hooks Class Initialized
DEBUG - 2018-11-27 11:31:29 --> UTF-8 Support Enabled
INFO - 2018-11-27 11:31:29 --> Utf8 Class Initialized
INFO - 2018-11-27 11:31:29 --> URI Class Initialized
INFO - 2018-11-27 11:31:29 --> Router Class Initialized
INFO - 2018-11-27 11:31:29 --> Output Class Initialized
INFO - 2018-11-27 11:31:29 --> Security Class Initialized
DEBUG - 2018-11-27 11:31:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-27 11:31:29 --> Input Class Initialized
INFO - 2018-11-27 11:31:29 --> Language Class Initialized
ERROR - 2018-11-27 11:31:29 --> 404 Page Not Found: Img/favicon.png
INFO - 2018-11-27 11:33:40 --> Config Class Initialized
INFO - 2018-11-27 11:33:40 --> Hooks Class Initialized
DEBUG - 2018-11-27 11:33:40 --> UTF-8 Support Enabled
INFO - 2018-11-27 11:33:40 --> Utf8 Class Initialized
INFO - 2018-11-27 11:33:40 --> URI Class Initialized
DEBUG - 2018-11-27 11:33:40 --> No URI present. Default controller set.
INFO - 2018-11-27 11:33:40 --> Router Class Initialized
INFO - 2018-11-27 11:33:40 --> Output Class Initialized
INFO - 2018-11-27 11:33:40 --> Security Class Initialized
DEBUG - 2018-11-27 11:33:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-27 11:33:40 --> Input Class Initialized
INFO - 2018-11-27 11:33:40 --> Language Class Initialized
INFO - 2018-11-27 11:33:40 --> Loader Class Initialized
INFO - 2018-11-27 11:33:40 --> Helper loaded: url_helper
INFO - 2018-11-27 11:33:40 --> Helper loaded: file_helper
INFO - 2018-11-27 11:33:40 --> Helper loaded: email_helper
INFO - 2018-11-27 11:33:40 --> Helper loaded: common_helper
INFO - 2018-11-27 11:33:40 --> Database Driver Class Initialized
DEBUG - 2018-11-27 11:33:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-27 11:33:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-27 11:33:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-27 11:33:40 --> Pagination Class Initialized
INFO - 2018-11-27 11:33:40 --> Helper loaded: form_helper
INFO - 2018-11-27 11:33:40 --> Form Validation Class Initialized
INFO - 2018-11-27 11:33:40 --> Controller Class Initialized
INFO - 2018-11-27 11:33:40 --> File loaded: C:\xampp\htdocs\payment_example\application\views\payu_payment/index.php
INFO - 2018-11-27 11:33:40 --> Final output sent to browser
DEBUG - 2018-11-27 11:33:40 --> Total execution time: 0.0670
INFO - 2018-11-27 11:33:43 --> Config Class Initialized
INFO - 2018-11-27 11:33:43 --> Hooks Class Initialized
DEBUG - 2018-11-27 11:33:43 --> UTF-8 Support Enabled
INFO - 2018-11-27 11:33:43 --> Utf8 Class Initialized
INFO - 2018-11-27 11:33:43 --> URI Class Initialized
INFO - 2018-11-27 11:33:43 --> Router Class Initialized
INFO - 2018-11-27 11:33:43 --> Output Class Initialized
INFO - 2018-11-27 11:33:43 --> Security Class Initialized
DEBUG - 2018-11-27 11:33:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-27 11:33:43 --> Input Class Initialized
INFO - 2018-11-27 11:33:43 --> Language Class Initialized
ERROR - 2018-11-27 11:33:43 --> 404 Page Not Found: Img/favicon.png
INFO - 2018-11-27 11:34:09 --> Config Class Initialized
INFO - 2018-11-27 11:34:09 --> Hooks Class Initialized
DEBUG - 2018-11-27 11:34:09 --> UTF-8 Support Enabled
INFO - 2018-11-27 11:34:09 --> Utf8 Class Initialized
INFO - 2018-11-27 11:34:09 --> URI Class Initialized
DEBUG - 2018-11-27 11:34:09 --> No URI present. Default controller set.
INFO - 2018-11-27 11:34:09 --> Router Class Initialized
INFO - 2018-11-27 11:34:09 --> Output Class Initialized
INFO - 2018-11-27 11:34:09 --> Security Class Initialized
DEBUG - 2018-11-27 11:34:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-27 11:34:09 --> Input Class Initialized
INFO - 2018-11-27 11:34:09 --> Language Class Initialized
INFO - 2018-11-27 11:34:09 --> Loader Class Initialized
INFO - 2018-11-27 11:34:09 --> Helper loaded: url_helper
INFO - 2018-11-27 11:34:09 --> Helper loaded: file_helper
INFO - 2018-11-27 11:34:09 --> Helper loaded: email_helper
INFO - 2018-11-27 11:34:09 --> Helper loaded: common_helper
INFO - 2018-11-27 11:34:09 --> Database Driver Class Initialized
DEBUG - 2018-11-27 11:34:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-27 11:34:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-27 11:34:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-27 11:34:09 --> Pagination Class Initialized
INFO - 2018-11-27 11:34:09 --> Helper loaded: form_helper
INFO - 2018-11-27 11:34:09 --> Form Validation Class Initialized
INFO - 2018-11-27 11:34:09 --> Controller Class Initialized
INFO - 2018-11-27 11:34:09 --> File loaded: C:\xampp\htdocs\payment_example\application\views\payu_payment/index.php
INFO - 2018-11-27 11:34:09 --> Final output sent to browser
DEBUG - 2018-11-27 11:34:09 --> Total execution time: 0.0610
INFO - 2018-11-27 11:34:13 --> Config Class Initialized
INFO - 2018-11-27 11:34:13 --> Hooks Class Initialized
DEBUG - 2018-11-27 11:34:13 --> UTF-8 Support Enabled
INFO - 2018-11-27 11:34:13 --> Utf8 Class Initialized
INFO - 2018-11-27 11:34:13 --> URI Class Initialized
INFO - 2018-11-27 11:34:13 --> Router Class Initialized
INFO - 2018-11-27 11:34:13 --> Output Class Initialized
INFO - 2018-11-27 11:34:13 --> Security Class Initialized
DEBUG - 2018-11-27 11:34:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-27 11:34:13 --> Input Class Initialized
INFO - 2018-11-27 11:34:13 --> Language Class Initialized
ERROR - 2018-11-27 11:34:13 --> 404 Page Not Found: Img/favicon.png
INFO - 2018-11-27 11:34:26 --> Config Class Initialized
INFO - 2018-11-27 11:34:26 --> Hooks Class Initialized
DEBUG - 2018-11-27 11:34:26 --> UTF-8 Support Enabled
INFO - 2018-11-27 11:34:26 --> Utf8 Class Initialized
INFO - 2018-11-27 11:34:26 --> URI Class Initialized
DEBUG - 2018-11-27 11:34:26 --> No URI present. Default controller set.
INFO - 2018-11-27 11:34:26 --> Router Class Initialized
INFO - 2018-11-27 11:34:26 --> Output Class Initialized
INFO - 2018-11-27 11:34:26 --> Security Class Initialized
DEBUG - 2018-11-27 11:34:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-27 11:34:26 --> Input Class Initialized
INFO - 2018-11-27 11:34:26 --> Language Class Initialized
INFO - 2018-11-27 11:34:26 --> Loader Class Initialized
INFO - 2018-11-27 11:34:26 --> Helper loaded: url_helper
INFO - 2018-11-27 11:34:26 --> Helper loaded: file_helper
INFO - 2018-11-27 11:34:26 --> Helper loaded: email_helper
INFO - 2018-11-27 11:34:26 --> Helper loaded: common_helper
INFO - 2018-11-27 11:34:26 --> Database Driver Class Initialized
DEBUG - 2018-11-27 11:34:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-27 11:34:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-27 11:34:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-27 11:34:26 --> Pagination Class Initialized
INFO - 2018-11-27 11:34:26 --> Helper loaded: form_helper
INFO - 2018-11-27 11:34:26 --> Form Validation Class Initialized
INFO - 2018-11-27 11:34:26 --> Controller Class Initialized
INFO - 2018-11-27 11:34:26 --> File loaded: C:\xampp\htdocs\payment_example\application\views\payu_payment/index.php
INFO - 2018-11-27 11:34:26 --> Final output sent to browser
DEBUG - 2018-11-27 11:34:26 --> Total execution time: 0.0810
INFO - 2018-11-27 11:35:28 --> Config Class Initialized
INFO - 2018-11-27 11:35:28 --> Hooks Class Initialized
DEBUG - 2018-11-27 11:35:28 --> UTF-8 Support Enabled
INFO - 2018-11-27 11:35:28 --> Utf8 Class Initialized
INFO - 2018-11-27 11:35:28 --> URI Class Initialized
DEBUG - 2018-11-27 11:35:28 --> No URI present. Default controller set.
INFO - 2018-11-27 11:35:28 --> Router Class Initialized
INFO - 2018-11-27 11:35:28 --> Output Class Initialized
INFO - 2018-11-27 11:35:28 --> Security Class Initialized
DEBUG - 2018-11-27 11:35:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-27 11:35:28 --> Input Class Initialized
INFO - 2018-11-27 11:35:28 --> Language Class Initialized
INFO - 2018-11-27 11:35:28 --> Loader Class Initialized
INFO - 2018-11-27 11:35:28 --> Helper loaded: url_helper
INFO - 2018-11-27 11:35:28 --> Helper loaded: file_helper
INFO - 2018-11-27 11:35:28 --> Helper loaded: email_helper
INFO - 2018-11-27 11:35:28 --> Helper loaded: common_helper
INFO - 2018-11-27 11:35:28 --> Database Driver Class Initialized
DEBUG - 2018-11-27 11:35:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-27 11:35:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-27 11:35:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-27 11:35:28 --> Pagination Class Initialized
INFO - 2018-11-27 11:35:28 --> Helper loaded: form_helper
INFO - 2018-11-27 11:35:28 --> Form Validation Class Initialized
INFO - 2018-11-27 11:35:28 --> Controller Class Initialized
INFO - 2018-11-27 11:35:28 --> File loaded: C:\xampp\htdocs\payment_example\application\views\payu_payment/index.php
INFO - 2018-11-27 11:35:28 --> Final output sent to browser
DEBUG - 2018-11-27 11:35:28 --> Total execution time: 0.0510
INFO - 2018-11-27 11:42:45 --> Config Class Initialized
INFO - 2018-11-27 11:42:45 --> Hooks Class Initialized
DEBUG - 2018-11-27 11:42:45 --> UTF-8 Support Enabled
INFO - 2018-11-27 11:42:45 --> Utf8 Class Initialized
INFO - 2018-11-27 11:42:45 --> URI Class Initialized
DEBUG - 2018-11-27 11:42:45 --> No URI present. Default controller set.
INFO - 2018-11-27 11:42:45 --> Router Class Initialized
INFO - 2018-11-27 11:42:45 --> Output Class Initialized
INFO - 2018-11-27 11:42:45 --> Security Class Initialized
DEBUG - 2018-11-27 11:42:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-27 11:42:45 --> Input Class Initialized
INFO - 2018-11-27 11:42:45 --> Language Class Initialized
INFO - 2018-11-27 11:42:45 --> Loader Class Initialized
INFO - 2018-11-27 11:42:45 --> Helper loaded: url_helper
INFO - 2018-11-27 11:42:45 --> Helper loaded: file_helper
INFO - 2018-11-27 11:42:45 --> Helper loaded: email_helper
INFO - 2018-11-27 11:42:45 --> Helper loaded: common_helper
INFO - 2018-11-27 11:42:45 --> Database Driver Class Initialized
DEBUG - 2018-11-27 11:42:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-27 11:42:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-27 11:42:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-27 11:42:45 --> Pagination Class Initialized
INFO - 2018-11-27 11:42:45 --> Helper loaded: form_helper
INFO - 2018-11-27 11:42:45 --> Form Validation Class Initialized
INFO - 2018-11-27 11:42:45 --> Controller Class Initialized
INFO - 2018-11-27 11:42:45 --> File loaded: C:\xampp\htdocs\payment_example\application\views\payu_payment/index.php
INFO - 2018-11-27 11:42:45 --> Final output sent to browser
DEBUG - 2018-11-27 11:42:45 --> Total execution time: 0.0650
INFO - 2018-11-27 11:43:38 --> Config Class Initialized
INFO - 2018-11-27 11:43:38 --> Hooks Class Initialized
DEBUG - 2018-11-27 11:43:38 --> UTF-8 Support Enabled
INFO - 2018-11-27 11:43:38 --> Utf8 Class Initialized
INFO - 2018-11-27 11:43:38 --> URI Class Initialized
DEBUG - 2018-11-27 11:43:38 --> No URI present. Default controller set.
INFO - 2018-11-27 11:43:38 --> Router Class Initialized
INFO - 2018-11-27 11:43:38 --> Output Class Initialized
INFO - 2018-11-27 11:43:38 --> Security Class Initialized
DEBUG - 2018-11-27 11:43:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-27 11:43:38 --> Input Class Initialized
INFO - 2018-11-27 11:43:38 --> Language Class Initialized
INFO - 2018-11-27 11:43:38 --> Loader Class Initialized
INFO - 2018-11-27 11:43:38 --> Helper loaded: url_helper
INFO - 2018-11-27 11:43:38 --> Helper loaded: file_helper
INFO - 2018-11-27 11:43:38 --> Helper loaded: email_helper
INFO - 2018-11-27 11:43:38 --> Helper loaded: common_helper
INFO - 2018-11-27 11:43:38 --> Database Driver Class Initialized
DEBUG - 2018-11-27 11:43:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-27 11:43:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-27 11:43:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-27 11:43:38 --> Pagination Class Initialized
INFO - 2018-11-27 11:43:38 --> Helper loaded: form_helper
INFO - 2018-11-27 11:43:38 --> Form Validation Class Initialized
INFO - 2018-11-27 11:43:38 --> Controller Class Initialized
INFO - 2018-11-27 11:43:38 --> File loaded: C:\xampp\htdocs\payment_example\application\views\payu_payment/index.php
INFO - 2018-11-27 11:43:38 --> Final output sent to browser
DEBUG - 2018-11-27 11:43:38 --> Total execution time: 0.0860
INFO - 2018-11-27 11:44:09 --> Config Class Initialized
INFO - 2018-11-27 11:44:09 --> Hooks Class Initialized
DEBUG - 2018-11-27 11:44:09 --> UTF-8 Support Enabled
INFO - 2018-11-27 11:44:09 --> Utf8 Class Initialized
INFO - 2018-11-27 11:44:09 --> URI Class Initialized
DEBUG - 2018-11-27 11:44:09 --> No URI present. Default controller set.
INFO - 2018-11-27 11:44:09 --> Router Class Initialized
INFO - 2018-11-27 11:44:09 --> Output Class Initialized
INFO - 2018-11-27 11:44:09 --> Security Class Initialized
DEBUG - 2018-11-27 11:44:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-27 11:44:09 --> Input Class Initialized
INFO - 2018-11-27 11:44:09 --> Language Class Initialized
INFO - 2018-11-27 11:44:09 --> Loader Class Initialized
INFO - 2018-11-27 11:44:09 --> Helper loaded: url_helper
INFO - 2018-11-27 11:44:09 --> Helper loaded: file_helper
INFO - 2018-11-27 11:44:09 --> Helper loaded: email_helper
INFO - 2018-11-27 11:44:09 --> Helper loaded: common_helper
INFO - 2018-11-27 11:44:09 --> Database Driver Class Initialized
DEBUG - 2018-11-27 11:44:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-27 11:44:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-27 11:44:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-27 11:44:09 --> Pagination Class Initialized
INFO - 2018-11-27 11:44:09 --> Helper loaded: form_helper
INFO - 2018-11-27 11:44:09 --> Form Validation Class Initialized
INFO - 2018-11-27 11:44:09 --> Controller Class Initialized
INFO - 2018-11-27 11:44:09 --> File loaded: C:\xampp\htdocs\payment_example\application\views\payu_payment/index.php
INFO - 2018-11-27 11:44:09 --> Final output sent to browser
DEBUG - 2018-11-27 11:44:09 --> Total execution time: 0.0720
INFO - 2018-11-27 11:46:34 --> Config Class Initialized
INFO - 2018-11-27 11:46:34 --> Hooks Class Initialized
DEBUG - 2018-11-27 11:46:34 --> UTF-8 Support Enabled
INFO - 2018-11-27 11:46:34 --> Utf8 Class Initialized
INFO - 2018-11-27 11:46:34 --> URI Class Initialized
DEBUG - 2018-11-27 11:46:34 --> No URI present. Default controller set.
INFO - 2018-11-27 11:46:34 --> Router Class Initialized
INFO - 2018-11-27 11:46:34 --> Output Class Initialized
INFO - 2018-11-27 11:46:34 --> Security Class Initialized
DEBUG - 2018-11-27 11:46:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-27 11:46:34 --> Input Class Initialized
INFO - 2018-11-27 11:46:34 --> Language Class Initialized
INFO - 2018-11-27 11:46:34 --> Loader Class Initialized
INFO - 2018-11-27 11:46:34 --> Helper loaded: url_helper
INFO - 2018-11-27 11:46:34 --> Helper loaded: file_helper
INFO - 2018-11-27 11:46:34 --> Helper loaded: email_helper
INFO - 2018-11-27 11:46:34 --> Helper loaded: common_helper
INFO - 2018-11-27 11:46:34 --> Database Driver Class Initialized
DEBUG - 2018-11-27 11:46:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-27 11:46:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-27 11:46:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-27 11:46:34 --> Pagination Class Initialized
INFO - 2018-11-27 11:46:34 --> Helper loaded: form_helper
INFO - 2018-11-27 11:46:34 --> Form Validation Class Initialized
INFO - 2018-11-27 11:46:34 --> Controller Class Initialized
INFO - 2018-11-27 11:46:34 --> File loaded: C:\xampp\htdocs\payment_example\application\views\payu_payment/index.php
INFO - 2018-11-27 11:46:34 --> Final output sent to browser
DEBUG - 2018-11-27 11:46:34 --> Total execution time: 0.0780
INFO - 2018-11-27 11:47:13 --> Config Class Initialized
INFO - 2018-11-27 11:47:13 --> Hooks Class Initialized
DEBUG - 2018-11-27 11:47:13 --> UTF-8 Support Enabled
INFO - 2018-11-27 11:47:13 --> Utf8 Class Initialized
INFO - 2018-11-27 11:47:13 --> URI Class Initialized
DEBUG - 2018-11-27 11:47:13 --> No URI present. Default controller set.
INFO - 2018-11-27 11:47:13 --> Router Class Initialized
INFO - 2018-11-27 11:47:13 --> Output Class Initialized
INFO - 2018-11-27 11:47:13 --> Security Class Initialized
DEBUG - 2018-11-27 11:47:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-27 11:47:13 --> Input Class Initialized
INFO - 2018-11-27 11:47:13 --> Language Class Initialized
INFO - 2018-11-27 11:47:13 --> Loader Class Initialized
INFO - 2018-11-27 11:47:13 --> Helper loaded: url_helper
INFO - 2018-11-27 11:47:13 --> Helper loaded: file_helper
INFO - 2018-11-27 11:47:13 --> Helper loaded: email_helper
INFO - 2018-11-27 11:47:13 --> Helper loaded: common_helper
INFO - 2018-11-27 11:47:13 --> Database Driver Class Initialized
DEBUG - 2018-11-27 11:47:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-27 11:47:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-27 11:47:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-27 11:47:13 --> Pagination Class Initialized
INFO - 2018-11-27 11:47:13 --> Helper loaded: form_helper
INFO - 2018-11-27 11:47:13 --> Form Validation Class Initialized
INFO - 2018-11-27 11:47:13 --> Controller Class Initialized
INFO - 2018-11-27 11:47:13 --> File loaded: C:\xampp\htdocs\payment_example\application\views\payu_payment/index.php
INFO - 2018-11-27 11:47:13 --> Final output sent to browser
DEBUG - 2018-11-27 11:47:13 --> Total execution time: 0.0610
INFO - 2018-11-27 11:48:48 --> Config Class Initialized
INFO - 2018-11-27 11:48:48 --> Hooks Class Initialized
DEBUG - 2018-11-27 11:48:48 --> UTF-8 Support Enabled
INFO - 2018-11-27 11:48:48 --> Utf8 Class Initialized
INFO - 2018-11-27 11:48:48 --> URI Class Initialized
DEBUG - 2018-11-27 11:48:48 --> No URI present. Default controller set.
INFO - 2018-11-27 11:48:48 --> Router Class Initialized
INFO - 2018-11-27 11:48:48 --> Output Class Initialized
INFO - 2018-11-27 11:48:48 --> Security Class Initialized
DEBUG - 2018-11-27 11:48:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-27 11:48:48 --> Input Class Initialized
INFO - 2018-11-27 11:48:48 --> Language Class Initialized
INFO - 2018-11-27 11:48:48 --> Loader Class Initialized
INFO - 2018-11-27 11:48:48 --> Helper loaded: url_helper
INFO - 2018-11-27 11:48:48 --> Helper loaded: file_helper
INFO - 2018-11-27 11:48:48 --> Helper loaded: email_helper
INFO - 2018-11-27 11:48:48 --> Helper loaded: common_helper
INFO - 2018-11-27 11:48:48 --> Database Driver Class Initialized
DEBUG - 2018-11-27 11:48:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-27 11:48:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-27 11:48:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-27 11:48:48 --> Pagination Class Initialized
INFO - 2018-11-27 11:48:48 --> Helper loaded: form_helper
INFO - 2018-11-27 11:48:48 --> Form Validation Class Initialized
INFO - 2018-11-27 11:48:48 --> Controller Class Initialized
INFO - 2018-11-27 11:48:48 --> File loaded: C:\xampp\htdocs\payment_example\application\views\payu_payment/index.php
INFO - 2018-11-27 11:48:48 --> Final output sent to browser
DEBUG - 2018-11-27 11:48:48 --> Total execution time: 0.0690
INFO - 2018-11-27 11:51:58 --> Config Class Initialized
INFO - 2018-11-27 11:51:58 --> Hooks Class Initialized
DEBUG - 2018-11-27 11:51:58 --> UTF-8 Support Enabled
INFO - 2018-11-27 11:51:58 --> Utf8 Class Initialized
INFO - 2018-11-27 11:51:58 --> URI Class Initialized
DEBUG - 2018-11-27 11:51:58 --> No URI present. Default controller set.
INFO - 2018-11-27 11:51:58 --> Router Class Initialized
INFO - 2018-11-27 11:51:58 --> Output Class Initialized
INFO - 2018-11-27 11:51:58 --> Security Class Initialized
DEBUG - 2018-11-27 11:51:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-27 11:51:58 --> Input Class Initialized
INFO - 2018-11-27 11:51:58 --> Language Class Initialized
INFO - 2018-11-27 11:51:58 --> Loader Class Initialized
INFO - 2018-11-27 11:51:58 --> Helper loaded: url_helper
INFO - 2018-11-27 11:51:58 --> Helper loaded: file_helper
INFO - 2018-11-27 11:51:58 --> Helper loaded: email_helper
INFO - 2018-11-27 11:51:58 --> Helper loaded: common_helper
INFO - 2018-11-27 11:51:58 --> Database Driver Class Initialized
DEBUG - 2018-11-27 11:51:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-27 11:51:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-27 11:51:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-27 11:51:58 --> Pagination Class Initialized
INFO - 2018-11-27 11:51:58 --> Helper loaded: form_helper
INFO - 2018-11-27 11:51:58 --> Form Validation Class Initialized
INFO - 2018-11-27 11:51:58 --> Controller Class Initialized
INFO - 2018-11-27 11:51:58 --> File loaded: C:\xampp\htdocs\payment_example\application\views\payu_payment/index.php
INFO - 2018-11-27 11:51:58 --> Final output sent to browser
DEBUG - 2018-11-27 11:51:58 --> Total execution time: 0.0800
INFO - 2018-11-27 11:54:59 --> Config Class Initialized
INFO - 2018-11-27 11:54:59 --> Hooks Class Initialized
DEBUG - 2018-11-27 11:54:59 --> UTF-8 Support Enabled
INFO - 2018-11-27 11:54:59 --> Utf8 Class Initialized
INFO - 2018-11-27 11:54:59 --> URI Class Initialized
INFO - 2018-11-27 11:54:59 --> Router Class Initialized
INFO - 2018-11-27 11:54:59 --> Output Class Initialized
INFO - 2018-11-27 11:54:59 --> Security Class Initialized
DEBUG - 2018-11-27 11:54:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-27 11:54:59 --> Input Class Initialized
INFO - 2018-11-27 11:54:59 --> Language Class Initialized
INFO - 2018-11-27 11:54:59 --> Loader Class Initialized
INFO - 2018-11-27 11:54:59 --> Helper loaded: url_helper
INFO - 2018-11-27 11:54:59 --> Helper loaded: file_helper
INFO - 2018-11-27 11:54:59 --> Helper loaded: email_helper
INFO - 2018-11-27 11:54:59 --> Helper loaded: common_helper
INFO - 2018-11-27 11:54:59 --> Database Driver Class Initialized
DEBUG - 2018-11-27 11:54:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-27 11:54:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-27 11:54:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-27 11:54:59 --> Pagination Class Initialized
INFO - 2018-11-27 11:54:59 --> Helper loaded: form_helper
INFO - 2018-11-27 11:54:59 --> Form Validation Class Initialized
INFO - 2018-11-27 11:54:59 --> Controller Class Initialized
INFO - 2018-11-27 11:54:59 --> File loaded: C:\xampp\htdocs\payment_example\application\views\payu_payment/confirmation.php
INFO - 2018-11-27 11:54:59 --> Final output sent to browser
DEBUG - 2018-11-27 11:54:59 --> Total execution time: 0.0620
INFO - 2018-11-27 11:55:00 --> Config Class Initialized
INFO - 2018-11-27 11:55:00 --> Hooks Class Initialized
DEBUG - 2018-11-27 11:55:00 --> UTF-8 Support Enabled
INFO - 2018-11-27 11:55:00 --> Utf8 Class Initialized
INFO - 2018-11-27 11:55:00 --> URI Class Initialized
INFO - 2018-11-27 11:55:00 --> Router Class Initialized
INFO - 2018-11-27 11:55:00 --> Output Class Initialized
INFO - 2018-11-27 11:55:00 --> Security Class Initialized
DEBUG - 2018-11-27 11:55:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-27 11:55:00 --> Input Class Initialized
INFO - 2018-11-27 11:55:00 --> Language Class Initialized
ERROR - 2018-11-27 11:55:00 --> 404 Page Not Found: My_controller/favicon.png
INFO - 2018-11-27 11:55:10 --> Config Class Initialized
INFO - 2018-11-27 11:55:10 --> Hooks Class Initialized
DEBUG - 2018-11-27 11:55:10 --> UTF-8 Support Enabled
INFO - 2018-11-27 11:55:10 --> Utf8 Class Initialized
INFO - 2018-11-27 11:55:10 --> URI Class Initialized
DEBUG - 2018-11-27 11:55:10 --> No URI present. Default controller set.
INFO - 2018-11-27 11:55:10 --> Router Class Initialized
INFO - 2018-11-27 11:55:10 --> Output Class Initialized
INFO - 2018-11-27 11:55:10 --> Security Class Initialized
DEBUG - 2018-11-27 11:55:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-27 11:55:10 --> Input Class Initialized
INFO - 2018-11-27 11:55:10 --> Language Class Initialized
INFO - 2018-11-27 11:55:10 --> Loader Class Initialized
INFO - 2018-11-27 11:55:10 --> Helper loaded: url_helper
INFO - 2018-11-27 11:55:10 --> Helper loaded: file_helper
INFO - 2018-11-27 11:55:10 --> Helper loaded: email_helper
INFO - 2018-11-27 11:55:10 --> Helper loaded: common_helper
INFO - 2018-11-27 11:55:10 --> Database Driver Class Initialized
DEBUG - 2018-11-27 11:55:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-27 11:55:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-27 11:55:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-27 11:55:10 --> Pagination Class Initialized
INFO - 2018-11-27 11:55:10 --> Helper loaded: form_helper
INFO - 2018-11-27 11:55:10 --> Form Validation Class Initialized
INFO - 2018-11-27 11:55:10 --> Controller Class Initialized
INFO - 2018-11-27 11:55:10 --> File loaded: C:\xampp\htdocs\payment_example\application\views\payu_payment/index.php
INFO - 2018-11-27 11:55:10 --> Final output sent to browser
DEBUG - 2018-11-27 11:55:10 --> Total execution time: 0.0630
INFO - 2018-11-27 11:59:32 --> Config Class Initialized
INFO - 2018-11-27 11:59:32 --> Hooks Class Initialized
DEBUG - 2018-11-27 11:59:32 --> UTF-8 Support Enabled
INFO - 2018-11-27 11:59:32 --> Utf8 Class Initialized
INFO - 2018-11-27 11:59:32 --> URI Class Initialized
DEBUG - 2018-11-27 11:59:32 --> No URI present. Default controller set.
INFO - 2018-11-27 11:59:32 --> Router Class Initialized
INFO - 2018-11-27 11:59:32 --> Output Class Initialized
INFO - 2018-11-27 11:59:32 --> Security Class Initialized
DEBUG - 2018-11-27 11:59:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-27 11:59:32 --> Input Class Initialized
INFO - 2018-11-27 11:59:32 --> Language Class Initialized
INFO - 2018-11-27 11:59:32 --> Loader Class Initialized
INFO - 2018-11-27 11:59:32 --> Helper loaded: url_helper
INFO - 2018-11-27 11:59:32 --> Helper loaded: file_helper
INFO - 2018-11-27 11:59:32 --> Helper loaded: email_helper
INFO - 2018-11-27 11:59:32 --> Helper loaded: common_helper
INFO - 2018-11-27 11:59:32 --> Database Driver Class Initialized
DEBUG - 2018-11-27 11:59:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-27 11:59:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-27 11:59:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-27 11:59:32 --> Pagination Class Initialized
INFO - 2018-11-27 11:59:32 --> Helper loaded: form_helper
INFO - 2018-11-27 11:59:32 --> Form Validation Class Initialized
INFO - 2018-11-27 11:59:32 --> Controller Class Initialized
INFO - 2018-11-27 11:59:32 --> File loaded: C:\xampp\htdocs\payment_example\application\views\payu_payment/index.php
INFO - 2018-11-27 11:59:32 --> Final output sent to browser
DEBUG - 2018-11-27 11:59:32 --> Total execution time: 0.0590
INFO - 2018-11-27 11:59:51 --> Config Class Initialized
INFO - 2018-11-27 11:59:51 --> Hooks Class Initialized
DEBUG - 2018-11-27 11:59:51 --> UTF-8 Support Enabled
INFO - 2018-11-27 11:59:51 --> Utf8 Class Initialized
INFO - 2018-11-27 11:59:51 --> URI Class Initialized
DEBUG - 2018-11-27 11:59:51 --> No URI present. Default controller set.
INFO - 2018-11-27 11:59:51 --> Router Class Initialized
INFO - 2018-11-27 11:59:51 --> Output Class Initialized
INFO - 2018-11-27 11:59:51 --> Security Class Initialized
DEBUG - 2018-11-27 11:59:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-27 11:59:51 --> Input Class Initialized
INFO - 2018-11-27 11:59:51 --> Language Class Initialized
INFO - 2018-11-27 11:59:51 --> Loader Class Initialized
INFO - 2018-11-27 11:59:51 --> Helper loaded: url_helper
INFO - 2018-11-27 11:59:51 --> Helper loaded: file_helper
INFO - 2018-11-27 11:59:51 --> Helper loaded: email_helper
INFO - 2018-11-27 11:59:51 --> Helper loaded: common_helper
INFO - 2018-11-27 11:59:51 --> Database Driver Class Initialized
DEBUG - 2018-11-27 11:59:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-27 11:59:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-27 11:59:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-27 11:59:51 --> Pagination Class Initialized
INFO - 2018-11-27 11:59:51 --> Helper loaded: form_helper
INFO - 2018-11-27 11:59:51 --> Form Validation Class Initialized
INFO - 2018-11-27 11:59:51 --> Controller Class Initialized
INFO - 2018-11-27 11:59:51 --> File loaded: C:\xampp\htdocs\payment_example\application\views\payu_payment/index.php
INFO - 2018-11-27 11:59:51 --> Final output sent to browser
DEBUG - 2018-11-27 11:59:51 --> Total execution time: 0.0910
INFO - 2018-11-27 12:01:08 --> Config Class Initialized
INFO - 2018-11-27 12:01:08 --> Hooks Class Initialized
DEBUG - 2018-11-27 12:01:08 --> UTF-8 Support Enabled
INFO - 2018-11-27 12:01:08 --> Utf8 Class Initialized
INFO - 2018-11-27 12:01:08 --> URI Class Initialized
DEBUG - 2018-11-27 12:01:08 --> No URI present. Default controller set.
INFO - 2018-11-27 12:01:08 --> Router Class Initialized
INFO - 2018-11-27 12:01:08 --> Output Class Initialized
INFO - 2018-11-27 12:01:08 --> Security Class Initialized
DEBUG - 2018-11-27 12:01:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-27 12:01:08 --> Input Class Initialized
INFO - 2018-11-27 12:01:08 --> Language Class Initialized
INFO - 2018-11-27 12:01:08 --> Loader Class Initialized
INFO - 2018-11-27 12:01:08 --> Helper loaded: url_helper
INFO - 2018-11-27 12:01:08 --> Helper loaded: file_helper
INFO - 2018-11-27 12:01:08 --> Helper loaded: email_helper
INFO - 2018-11-27 12:01:08 --> Helper loaded: common_helper
INFO - 2018-11-27 12:01:08 --> Database Driver Class Initialized
DEBUG - 2018-11-27 12:01:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-27 12:01:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-27 12:01:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-27 12:01:08 --> Pagination Class Initialized
INFO - 2018-11-27 12:01:08 --> Helper loaded: form_helper
INFO - 2018-11-27 12:01:08 --> Form Validation Class Initialized
INFO - 2018-11-27 12:01:08 --> Controller Class Initialized
INFO - 2018-11-27 12:01:08 --> File loaded: C:\xampp\htdocs\payment_example\application\views\payu_payment/index.php
INFO - 2018-11-27 12:01:08 --> Final output sent to browser
DEBUG - 2018-11-27 12:01:08 --> Total execution time: 0.0450
INFO - 2018-11-27 12:12:22 --> Config Class Initialized
INFO - 2018-11-27 12:12:22 --> Hooks Class Initialized
DEBUG - 2018-11-27 12:12:22 --> UTF-8 Support Enabled
INFO - 2018-11-27 12:12:22 --> Utf8 Class Initialized
INFO - 2018-11-27 12:12:22 --> URI Class Initialized
DEBUG - 2018-11-27 12:12:22 --> No URI present. Default controller set.
INFO - 2018-11-27 12:12:22 --> Router Class Initialized
INFO - 2018-11-27 12:12:22 --> Output Class Initialized
INFO - 2018-11-27 12:12:22 --> Security Class Initialized
DEBUG - 2018-11-27 12:12:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-27 12:12:22 --> Input Class Initialized
INFO - 2018-11-27 12:12:22 --> Language Class Initialized
INFO - 2018-11-27 12:12:22 --> Loader Class Initialized
INFO - 2018-11-27 12:12:22 --> Helper loaded: url_helper
INFO - 2018-11-27 12:12:22 --> Helper loaded: file_helper
INFO - 2018-11-27 12:12:22 --> Helper loaded: email_helper
INFO - 2018-11-27 12:12:22 --> Helper loaded: common_helper
INFO - 2018-11-27 12:12:22 --> Database Driver Class Initialized
DEBUG - 2018-11-27 12:12:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-27 12:12:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-27 12:12:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-27 12:12:22 --> Pagination Class Initialized
INFO - 2018-11-27 12:12:22 --> Helper loaded: form_helper
INFO - 2018-11-27 12:12:22 --> Form Validation Class Initialized
INFO - 2018-11-27 12:12:22 --> Controller Class Initialized
INFO - 2018-11-27 12:12:22 --> File loaded: C:\xampp\htdocs\payment_example\application\views\payu_payment/index.php
INFO - 2018-11-27 12:12:22 --> Final output sent to browser
DEBUG - 2018-11-27 12:12:22 --> Total execution time: 0.0780
INFO - 2018-11-27 12:12:52 --> Config Class Initialized
INFO - 2018-11-27 12:12:52 --> Hooks Class Initialized
DEBUG - 2018-11-27 12:12:52 --> UTF-8 Support Enabled
INFO - 2018-11-27 12:12:52 --> Utf8 Class Initialized
INFO - 2018-11-27 12:12:52 --> URI Class Initialized
DEBUG - 2018-11-27 12:12:52 --> No URI present. Default controller set.
INFO - 2018-11-27 12:12:52 --> Router Class Initialized
INFO - 2018-11-27 12:12:52 --> Output Class Initialized
INFO - 2018-11-27 12:12:52 --> Security Class Initialized
DEBUG - 2018-11-27 12:12:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-27 12:12:52 --> Input Class Initialized
INFO - 2018-11-27 12:12:52 --> Language Class Initialized
INFO - 2018-11-27 12:12:52 --> Loader Class Initialized
INFO - 2018-11-27 12:12:52 --> Helper loaded: url_helper
INFO - 2018-11-27 12:12:52 --> Helper loaded: file_helper
INFO - 2018-11-27 12:12:52 --> Helper loaded: email_helper
INFO - 2018-11-27 12:12:52 --> Helper loaded: common_helper
INFO - 2018-11-27 12:12:52 --> Database Driver Class Initialized
DEBUG - 2018-11-27 12:12:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-27 12:12:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-27 12:12:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-27 12:12:52 --> Pagination Class Initialized
INFO - 2018-11-27 12:12:52 --> Helper loaded: form_helper
INFO - 2018-11-27 12:12:52 --> Form Validation Class Initialized
INFO - 2018-11-27 12:12:52 --> Controller Class Initialized
INFO - 2018-11-27 12:12:52 --> File loaded: C:\xampp\htdocs\payment_example\application\views\payu_payment/index.php
INFO - 2018-11-27 12:12:52 --> Final output sent to browser
DEBUG - 2018-11-27 12:12:52 --> Total execution time: 0.0730
INFO - 2018-11-27 12:13:05 --> Config Class Initialized
INFO - 2018-11-27 12:13:05 --> Hooks Class Initialized
DEBUG - 2018-11-27 12:13:05 --> UTF-8 Support Enabled
INFO - 2018-11-27 12:13:05 --> Utf8 Class Initialized
INFO - 2018-11-27 12:13:05 --> URI Class Initialized
INFO - 2018-11-27 12:13:05 --> Router Class Initialized
INFO - 2018-11-27 12:13:05 --> Output Class Initialized
INFO - 2018-11-27 12:13:05 --> Security Class Initialized
DEBUG - 2018-11-27 12:13:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-27 12:13:05 --> Input Class Initialized
INFO - 2018-11-27 12:13:05 --> Language Class Initialized
INFO - 2018-11-27 12:13:05 --> Loader Class Initialized
INFO - 2018-11-27 12:13:05 --> Helper loaded: url_helper
INFO - 2018-11-27 12:13:05 --> Helper loaded: file_helper
INFO - 2018-11-27 12:13:05 --> Helper loaded: email_helper
INFO - 2018-11-27 12:13:05 --> Helper loaded: common_helper
INFO - 2018-11-27 12:13:05 --> Database Driver Class Initialized
DEBUG - 2018-11-27 12:13:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-27 12:13:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-27 12:13:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-27 12:13:05 --> Pagination Class Initialized
INFO - 2018-11-27 12:13:05 --> Helper loaded: form_helper
INFO - 2018-11-27 12:13:05 --> Form Validation Class Initialized
INFO - 2018-11-27 12:13:05 --> Controller Class Initialized
INFO - 2018-11-27 12:13:05 --> File loaded: C:\xampp\htdocs\payment_example\application\views\payu_payment/confirmation.php
INFO - 2018-11-27 12:13:05 --> Final output sent to browser
DEBUG - 2018-11-27 12:13:05 --> Total execution time: 0.0530
INFO - 2018-11-27 12:13:06 --> Config Class Initialized
INFO - 2018-11-27 12:13:06 --> Hooks Class Initialized
DEBUG - 2018-11-27 12:13:06 --> UTF-8 Support Enabled
INFO - 2018-11-27 12:13:06 --> Utf8 Class Initialized
INFO - 2018-11-27 12:13:06 --> URI Class Initialized
INFO - 2018-11-27 12:13:06 --> Router Class Initialized
INFO - 2018-11-27 12:13:06 --> Output Class Initialized
INFO - 2018-11-27 12:13:06 --> Security Class Initialized
DEBUG - 2018-11-27 12:13:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-27 12:13:06 --> Input Class Initialized
INFO - 2018-11-27 12:13:06 --> Language Class Initialized
ERROR - 2018-11-27 12:13:06 --> 404 Page Not Found: My_controller/favicon.png
INFO - 2018-11-27 12:19:57 --> Config Class Initialized
INFO - 2018-11-27 12:19:57 --> Hooks Class Initialized
DEBUG - 2018-11-27 12:19:57 --> UTF-8 Support Enabled
INFO - 2018-11-27 12:19:57 --> Utf8 Class Initialized
INFO - 2018-11-27 12:19:57 --> URI Class Initialized
DEBUG - 2018-11-27 12:19:57 --> No URI present. Default controller set.
INFO - 2018-11-27 12:19:57 --> Router Class Initialized
INFO - 2018-11-27 12:19:57 --> Output Class Initialized
INFO - 2018-11-27 12:19:57 --> Security Class Initialized
DEBUG - 2018-11-27 12:19:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-27 12:19:57 --> Input Class Initialized
INFO - 2018-11-27 12:19:57 --> Language Class Initialized
INFO - 2018-11-27 12:19:57 --> Loader Class Initialized
INFO - 2018-11-27 12:19:57 --> Helper loaded: url_helper
INFO - 2018-11-27 12:19:57 --> Helper loaded: file_helper
INFO - 2018-11-27 12:19:58 --> Helper loaded: email_helper
INFO - 2018-11-27 12:19:58 --> Helper loaded: common_helper
INFO - 2018-11-27 12:19:58 --> Database Driver Class Initialized
DEBUG - 2018-11-27 12:19:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-27 12:19:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-27 12:19:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-27 12:19:58 --> Pagination Class Initialized
INFO - 2018-11-27 12:19:58 --> Helper loaded: form_helper
INFO - 2018-11-27 12:19:58 --> Form Validation Class Initialized
INFO - 2018-11-27 12:19:58 --> Controller Class Initialized
INFO - 2018-11-27 12:19:58 --> File loaded: C:\xampp\htdocs\payment_example\application\views\payu_payment/index.php
INFO - 2018-11-27 12:19:58 --> Final output sent to browser
DEBUG - 2018-11-27 12:19:58 --> Total execution time: 0.0770
INFO - 2018-11-27 12:47:00 --> Config Class Initialized
INFO - 2018-11-27 12:47:00 --> Hooks Class Initialized
DEBUG - 2018-11-27 12:47:00 --> UTF-8 Support Enabled
INFO - 2018-11-27 12:47:00 --> Utf8 Class Initialized
INFO - 2018-11-27 12:47:00 --> URI Class Initialized
DEBUG - 2018-11-27 12:47:00 --> No URI present. Default controller set.
INFO - 2018-11-27 12:47:00 --> Router Class Initialized
INFO - 2018-11-27 12:47:00 --> Output Class Initialized
INFO - 2018-11-27 12:47:00 --> Security Class Initialized
DEBUG - 2018-11-27 12:47:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-27 12:47:00 --> Input Class Initialized
INFO - 2018-11-27 12:47:00 --> Language Class Initialized
INFO - 2018-11-27 12:47:00 --> Loader Class Initialized
INFO - 2018-11-27 12:47:00 --> Helper loaded: url_helper
INFO - 2018-11-27 12:47:00 --> Helper loaded: file_helper
INFO - 2018-11-27 12:47:00 --> Helper loaded: email_helper
INFO - 2018-11-27 12:47:00 --> Helper loaded: common_helper
INFO - 2018-11-27 12:47:00 --> Database Driver Class Initialized
DEBUG - 2018-11-27 12:47:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-27 12:47:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-27 12:47:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-27 12:47:00 --> Pagination Class Initialized
INFO - 2018-11-27 12:47:00 --> Helper loaded: form_helper
INFO - 2018-11-27 12:47:00 --> Form Validation Class Initialized
INFO - 2018-11-27 12:47:00 --> Controller Class Initialized
ERROR - 2018-11-27 12:47:00 --> Severity: Parsing Error --> syntax error, unexpected '}' C:\xampp\htdocs\payment_example\application\views\payu_payment\index.php 51
INFO - 2018-11-27 12:48:43 --> Config Class Initialized
INFO - 2018-11-27 12:48:43 --> Hooks Class Initialized
DEBUG - 2018-11-27 12:48:43 --> UTF-8 Support Enabled
INFO - 2018-11-27 12:48:43 --> Utf8 Class Initialized
INFO - 2018-11-27 12:48:43 --> URI Class Initialized
DEBUG - 2018-11-27 12:48:43 --> No URI present. Default controller set.
INFO - 2018-11-27 12:48:43 --> Router Class Initialized
INFO - 2018-11-27 12:48:43 --> Output Class Initialized
INFO - 2018-11-27 12:48:43 --> Security Class Initialized
DEBUG - 2018-11-27 12:48:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-27 12:48:43 --> Input Class Initialized
INFO - 2018-11-27 12:48:43 --> Language Class Initialized
INFO - 2018-11-27 12:48:43 --> Loader Class Initialized
INFO - 2018-11-27 12:48:43 --> Helper loaded: url_helper
INFO - 2018-11-27 12:48:43 --> Helper loaded: file_helper
INFO - 2018-11-27 12:48:43 --> Helper loaded: email_helper
INFO - 2018-11-27 12:48:43 --> Helper loaded: common_helper
INFO - 2018-11-27 12:48:43 --> Database Driver Class Initialized
DEBUG - 2018-11-27 12:48:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-27 12:48:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-27 12:48:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-27 12:48:43 --> Pagination Class Initialized
INFO - 2018-11-27 12:48:43 --> Helper loaded: form_helper
INFO - 2018-11-27 12:48:43 --> Form Validation Class Initialized
INFO - 2018-11-27 12:48:43 --> Controller Class Initialized
INFO - 2018-11-27 12:48:43 --> File loaded: C:\xampp\htdocs\payment_example\application\views\payu_payment/index.php
INFO - 2018-11-27 12:48:43 --> Final output sent to browser
DEBUG - 2018-11-27 12:48:43 --> Total execution time: 0.1130
INFO - 2018-11-27 12:55:18 --> Config Class Initialized
INFO - 2018-11-27 12:55:18 --> Hooks Class Initialized
DEBUG - 2018-11-27 12:55:18 --> UTF-8 Support Enabled
INFO - 2018-11-27 12:55:18 --> Utf8 Class Initialized
INFO - 2018-11-27 12:55:18 --> URI Class Initialized
DEBUG - 2018-11-27 12:55:18 --> No URI present. Default controller set.
INFO - 2018-11-27 12:55:18 --> Router Class Initialized
INFO - 2018-11-27 12:55:18 --> Output Class Initialized
INFO - 2018-11-27 12:55:18 --> Security Class Initialized
DEBUG - 2018-11-27 12:55:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-27 12:55:18 --> Input Class Initialized
INFO - 2018-11-27 12:55:18 --> Language Class Initialized
INFO - 2018-11-27 12:55:18 --> Loader Class Initialized
INFO - 2018-11-27 12:55:18 --> Helper loaded: url_helper
INFO - 2018-11-27 12:55:18 --> Helper loaded: file_helper
INFO - 2018-11-27 12:55:18 --> Helper loaded: email_helper
INFO - 2018-11-27 12:55:18 --> Helper loaded: common_helper
INFO - 2018-11-27 12:55:18 --> Database Driver Class Initialized
DEBUG - 2018-11-27 12:55:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-27 12:55:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-27 12:55:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-27 12:55:19 --> Pagination Class Initialized
INFO - 2018-11-27 12:55:19 --> Helper loaded: form_helper
INFO - 2018-11-27 12:55:19 --> Form Validation Class Initialized
INFO - 2018-11-27 12:55:19 --> Controller Class Initialized
INFO - 2018-11-27 12:55:19 --> File loaded: C:\xampp\htdocs\payment_example\application\views\payu_payment/index.php
INFO - 2018-11-27 12:55:19 --> Final output sent to browser
DEBUG - 2018-11-27 12:55:19 --> Total execution time: 0.0710
INFO - 2018-11-27 12:55:50 --> Config Class Initialized
INFO - 2018-11-27 12:55:50 --> Hooks Class Initialized
DEBUG - 2018-11-27 12:55:50 --> UTF-8 Support Enabled
INFO - 2018-11-27 12:55:50 --> Utf8 Class Initialized
INFO - 2018-11-27 12:55:50 --> URI Class Initialized
DEBUG - 2018-11-27 12:55:50 --> No URI present. Default controller set.
INFO - 2018-11-27 12:55:50 --> Router Class Initialized
INFO - 2018-11-27 12:55:50 --> Output Class Initialized
INFO - 2018-11-27 12:55:50 --> Security Class Initialized
DEBUG - 2018-11-27 12:55:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-27 12:55:50 --> Input Class Initialized
INFO - 2018-11-27 12:55:50 --> Language Class Initialized
INFO - 2018-11-27 12:55:50 --> Loader Class Initialized
INFO - 2018-11-27 12:55:50 --> Helper loaded: url_helper
INFO - 2018-11-27 12:55:50 --> Helper loaded: file_helper
INFO - 2018-11-27 12:55:50 --> Helper loaded: email_helper
INFO - 2018-11-27 12:55:50 --> Helper loaded: common_helper
INFO - 2018-11-27 12:55:50 --> Database Driver Class Initialized
DEBUG - 2018-11-27 12:55:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-27 12:55:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-27 12:55:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-27 12:55:50 --> Pagination Class Initialized
INFO - 2018-11-27 12:55:50 --> Helper loaded: form_helper
INFO - 2018-11-27 12:55:50 --> Form Validation Class Initialized
INFO - 2018-11-27 12:55:50 --> Controller Class Initialized
INFO - 2018-11-27 12:55:50 --> File loaded: C:\xampp\htdocs\payment_example\application\views\payu_payment/index.php
INFO - 2018-11-27 12:55:50 --> Final output sent to browser
DEBUG - 2018-11-27 12:55:50 --> Total execution time: 0.0650
INFO - 2018-11-27 12:56:18 --> Config Class Initialized
INFO - 2018-11-27 12:56:18 --> Hooks Class Initialized
DEBUG - 2018-11-27 12:56:18 --> UTF-8 Support Enabled
INFO - 2018-11-27 12:56:18 --> Utf8 Class Initialized
INFO - 2018-11-27 12:56:18 --> URI Class Initialized
DEBUG - 2018-11-27 12:56:18 --> No URI present. Default controller set.
INFO - 2018-11-27 12:56:18 --> Router Class Initialized
INFO - 2018-11-27 12:56:18 --> Output Class Initialized
INFO - 2018-11-27 12:56:18 --> Security Class Initialized
DEBUG - 2018-11-27 12:56:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-27 12:56:18 --> Input Class Initialized
INFO - 2018-11-27 12:56:18 --> Language Class Initialized
INFO - 2018-11-27 12:56:18 --> Loader Class Initialized
INFO - 2018-11-27 12:56:18 --> Helper loaded: url_helper
INFO - 2018-11-27 12:56:18 --> Helper loaded: file_helper
INFO - 2018-11-27 12:56:18 --> Helper loaded: email_helper
INFO - 2018-11-27 12:56:18 --> Helper loaded: common_helper
INFO - 2018-11-27 12:56:18 --> Database Driver Class Initialized
DEBUG - 2018-11-27 12:56:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-27 12:56:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-27 12:56:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-27 12:56:18 --> Pagination Class Initialized
INFO - 2018-11-27 12:56:18 --> Helper loaded: form_helper
INFO - 2018-11-27 12:56:18 --> Form Validation Class Initialized
INFO - 2018-11-27 12:56:18 --> Controller Class Initialized
INFO - 2018-11-27 12:56:18 --> File loaded: C:\xampp\htdocs\payment_example\application\views\payu_payment/index.php
INFO - 2018-11-27 12:56:18 --> Final output sent to browser
DEBUG - 2018-11-27 12:56:18 --> Total execution time: 0.1320
INFO - 2018-11-27 12:56:20 --> Config Class Initialized
INFO - 2018-11-27 12:56:20 --> Hooks Class Initialized
DEBUG - 2018-11-27 12:56:20 --> UTF-8 Support Enabled
INFO - 2018-11-27 12:56:20 --> Utf8 Class Initialized
INFO - 2018-11-27 12:56:20 --> URI Class Initialized
INFO - 2018-11-27 12:56:20 --> Router Class Initialized
INFO - 2018-11-27 12:56:20 --> Output Class Initialized
INFO - 2018-11-27 12:56:20 --> Security Class Initialized
DEBUG - 2018-11-27 12:56:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-27 12:56:20 --> Input Class Initialized
INFO - 2018-11-27 12:56:20 --> Language Class Initialized
ERROR - 2018-11-27 12:56:20 --> 404 Page Not Found: Verify/1
INFO - 2018-11-27 12:57:04 --> Config Class Initialized
INFO - 2018-11-27 12:57:04 --> Hooks Class Initialized
DEBUG - 2018-11-27 12:57:04 --> UTF-8 Support Enabled
INFO - 2018-11-27 12:57:04 --> Utf8 Class Initialized
INFO - 2018-11-27 12:57:04 --> URI Class Initialized
INFO - 2018-11-27 12:57:04 --> Router Class Initialized
INFO - 2018-11-27 12:57:04 --> Output Class Initialized
INFO - 2018-11-27 12:57:04 --> Security Class Initialized
DEBUG - 2018-11-27 12:57:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-27 12:57:04 --> Input Class Initialized
INFO - 2018-11-27 12:57:04 --> Language Class Initialized
ERROR - 2018-11-27 12:57:04 --> 404 Page Not Found: Verify/1
INFO - 2018-11-27 12:58:53 --> Config Class Initialized
INFO - 2018-11-27 12:58:53 --> Hooks Class Initialized
DEBUG - 2018-11-27 12:58:53 --> UTF-8 Support Enabled
INFO - 2018-11-27 12:58:53 --> Utf8 Class Initialized
INFO - 2018-11-27 12:58:53 --> URI Class Initialized
INFO - 2018-11-27 12:58:53 --> Router Class Initialized
INFO - 2018-11-27 12:58:53 --> Output Class Initialized
INFO - 2018-11-27 12:58:53 --> Security Class Initialized
DEBUG - 2018-11-27 12:58:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-27 12:58:53 --> Input Class Initialized
INFO - 2018-11-27 12:58:53 --> Language Class Initialized
INFO - 2018-11-27 12:58:53 --> Loader Class Initialized
INFO - 2018-11-27 12:58:53 --> Helper loaded: url_helper
INFO - 2018-11-27 12:58:53 --> Helper loaded: file_helper
INFO - 2018-11-27 12:58:53 --> Helper loaded: email_helper
INFO - 2018-11-27 12:58:53 --> Helper loaded: common_helper
INFO - 2018-11-27 12:58:53 --> Database Driver Class Initialized
DEBUG - 2018-11-27 12:58:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-27 12:58:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-27 12:58:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-27 12:58:53 --> Pagination Class Initialized
INFO - 2018-11-27 12:58:53 --> Helper loaded: form_helper
INFO - 2018-11-27 12:58:53 --> Form Validation Class Initialized
INFO - 2018-11-27 12:58:53 --> Controller Class Initialized
ERROR - 2018-11-27 12:58:53 --> Severity: Notice --> Undefined property: stdClass::$emp_amount C:\xampp\htdocs\payment_example\application\controllers\My_controller.php 27
INFO - 2018-11-27 12:58:53 --> File loaded: C:\xampp\htdocs\payment_example\application\views\payu_payment/confirmation.php
INFO - 2018-11-27 12:58:53 --> Final output sent to browser
DEBUG - 2018-11-27 12:58:53 --> Total execution time: 0.0750
INFO - 2018-11-27 12:59:15 --> Config Class Initialized
INFO - 2018-11-27 12:59:15 --> Hooks Class Initialized
DEBUG - 2018-11-27 12:59:15 --> UTF-8 Support Enabled
INFO - 2018-11-27 12:59:15 --> Utf8 Class Initialized
INFO - 2018-11-27 12:59:15 --> URI Class Initialized
INFO - 2018-11-27 12:59:15 --> Router Class Initialized
INFO - 2018-11-27 12:59:15 --> Output Class Initialized
INFO - 2018-11-27 12:59:15 --> Security Class Initialized
DEBUG - 2018-11-27 12:59:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-27 12:59:15 --> Input Class Initialized
INFO - 2018-11-27 12:59:15 --> Language Class Initialized
INFO - 2018-11-27 12:59:15 --> Loader Class Initialized
INFO - 2018-11-27 12:59:15 --> Helper loaded: url_helper
INFO - 2018-11-27 12:59:15 --> Helper loaded: file_helper
INFO - 2018-11-27 12:59:15 --> Helper loaded: email_helper
INFO - 2018-11-27 12:59:15 --> Helper loaded: common_helper
INFO - 2018-11-27 12:59:15 --> Database Driver Class Initialized
DEBUG - 2018-11-27 12:59:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-27 12:59:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-27 12:59:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-27 12:59:15 --> Pagination Class Initialized
INFO - 2018-11-27 12:59:15 --> Helper loaded: form_helper
INFO - 2018-11-27 12:59:15 --> Form Validation Class Initialized
INFO - 2018-11-27 12:59:15 --> Controller Class Initialized
INFO - 2018-11-27 12:59:15 --> File loaded: C:\xampp\htdocs\payment_example\application\views\payu_payment/confirmation.php
INFO - 2018-11-27 12:59:15 --> Final output sent to browser
DEBUG - 2018-11-27 12:59:15 --> Total execution time: 0.0640
INFO - 2018-11-27 12:59:16 --> Config Class Initialized
INFO - 2018-11-27 12:59:16 --> Hooks Class Initialized
DEBUG - 2018-11-27 12:59:16 --> UTF-8 Support Enabled
INFO - 2018-11-27 12:59:16 --> Utf8 Class Initialized
INFO - 2018-11-27 12:59:16 --> URI Class Initialized
INFO - 2018-11-27 12:59:16 --> Router Class Initialized
INFO - 2018-11-27 12:59:16 --> Output Class Initialized
INFO - 2018-11-27 12:59:16 --> Security Class Initialized
DEBUG - 2018-11-27 12:59:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-27 12:59:16 --> Input Class Initialized
INFO - 2018-11-27 12:59:16 --> Language Class Initialized
ERROR - 2018-11-27 12:59:16 --> 404 Page Not Found: Verify/favicon.png
INFO - 2018-11-27 13:01:39 --> Config Class Initialized
INFO - 2018-11-27 13:01:39 --> Hooks Class Initialized
DEBUG - 2018-11-27 13:01:39 --> UTF-8 Support Enabled
INFO - 2018-11-27 13:01:39 --> Utf8 Class Initialized
INFO - 2018-11-27 13:01:39 --> URI Class Initialized
INFO - 2018-11-27 13:01:39 --> Router Class Initialized
INFO - 2018-11-27 13:01:39 --> Output Class Initialized
INFO - 2018-11-27 13:01:39 --> Security Class Initialized
DEBUG - 2018-11-27 13:01:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-27 13:01:39 --> Input Class Initialized
INFO - 2018-11-27 13:01:39 --> Language Class Initialized
INFO - 2018-11-27 13:01:39 --> Loader Class Initialized
INFO - 2018-11-27 13:01:39 --> Helper loaded: url_helper
INFO - 2018-11-27 13:01:39 --> Helper loaded: file_helper
INFO - 2018-11-27 13:01:39 --> Helper loaded: email_helper
INFO - 2018-11-27 13:01:39 --> Helper loaded: common_helper
INFO - 2018-11-27 13:01:39 --> Database Driver Class Initialized
DEBUG - 2018-11-27 13:01:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-27 13:01:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-27 13:01:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-27 13:01:39 --> Pagination Class Initialized
INFO - 2018-11-27 13:01:39 --> Helper loaded: form_helper
INFO - 2018-11-27 13:01:39 --> Form Validation Class Initialized
INFO - 2018-11-27 13:01:39 --> Controller Class Initialized
INFO - 2018-11-27 13:01:39 --> File loaded: C:\xampp\htdocs\payment_example\application\views\payu_payment/confirmation.php
INFO - 2018-11-27 13:01:39 --> Final output sent to browser
DEBUG - 2018-11-27 13:01:39 --> Total execution time: 0.0580
INFO - 2018-11-27 13:03:27 --> Config Class Initialized
INFO - 2018-11-27 13:03:27 --> Hooks Class Initialized
DEBUG - 2018-11-27 13:03:27 --> UTF-8 Support Enabled
INFO - 2018-11-27 13:03:27 --> Utf8 Class Initialized
INFO - 2018-11-27 13:03:27 --> URI Class Initialized
INFO - 2018-11-27 13:03:27 --> Router Class Initialized
INFO - 2018-11-27 13:03:27 --> Output Class Initialized
INFO - 2018-11-27 13:03:27 --> Security Class Initialized
DEBUG - 2018-11-27 13:03:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-27 13:03:27 --> Input Class Initialized
INFO - 2018-11-27 13:03:27 --> Language Class Initialized
INFO - 2018-11-27 13:03:27 --> Loader Class Initialized
INFO - 2018-11-27 13:03:27 --> Helper loaded: url_helper
INFO - 2018-11-27 13:03:27 --> Helper loaded: file_helper
INFO - 2018-11-27 13:03:27 --> Helper loaded: email_helper
INFO - 2018-11-27 13:03:27 --> Helper loaded: common_helper
INFO - 2018-11-27 13:03:27 --> Database Driver Class Initialized
DEBUG - 2018-11-27 13:03:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-27 13:03:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-27 13:03:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-27 13:03:27 --> Pagination Class Initialized
INFO - 2018-11-27 13:03:27 --> Helper loaded: form_helper
INFO - 2018-11-27 13:03:27 --> Form Validation Class Initialized
INFO - 2018-11-27 13:03:27 --> Controller Class Initialized
INFO - 2018-11-27 13:03:27 --> File loaded: C:\xampp\htdocs\payment_example\application\views\payu_payment/confirmation.php
INFO - 2018-11-27 13:03:27 --> Final output sent to browser
DEBUG - 2018-11-27 13:03:27 --> Total execution time: 0.0680
INFO - 2018-11-27 13:03:28 --> Config Class Initialized
INFO - 2018-11-27 13:03:28 --> Hooks Class Initialized
DEBUG - 2018-11-27 13:03:28 --> UTF-8 Support Enabled
INFO - 2018-11-27 13:03:28 --> Utf8 Class Initialized
INFO - 2018-11-27 13:03:28 --> URI Class Initialized
INFO - 2018-11-27 13:03:28 --> Router Class Initialized
INFO - 2018-11-27 13:03:28 --> Output Class Initialized
INFO - 2018-11-27 13:03:28 --> Security Class Initialized
DEBUG - 2018-11-27 13:03:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-27 13:03:28 --> Input Class Initialized
INFO - 2018-11-27 13:03:28 --> Language Class Initialized
ERROR - 2018-11-27 13:03:28 --> 404 Page Not Found: Verify/favicon.png
INFO - 2018-11-27 13:05:28 --> Config Class Initialized
INFO - 2018-11-27 13:05:28 --> Hooks Class Initialized
DEBUG - 2018-11-27 13:05:28 --> UTF-8 Support Enabled
INFO - 2018-11-27 13:05:28 --> Utf8 Class Initialized
INFO - 2018-11-27 13:05:28 --> URI Class Initialized
INFO - 2018-11-27 13:05:28 --> Router Class Initialized
INFO - 2018-11-27 13:05:28 --> Output Class Initialized
INFO - 2018-11-27 13:05:28 --> Security Class Initialized
DEBUG - 2018-11-27 13:05:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-27 13:05:28 --> Input Class Initialized
INFO - 2018-11-27 13:05:28 --> Language Class Initialized
INFO - 2018-11-27 13:05:28 --> Loader Class Initialized
INFO - 2018-11-27 13:05:28 --> Helper loaded: url_helper
INFO - 2018-11-27 13:05:28 --> Helper loaded: file_helper
INFO - 2018-11-27 13:05:28 --> Helper loaded: email_helper
INFO - 2018-11-27 13:05:28 --> Helper loaded: common_helper
INFO - 2018-11-27 13:05:28 --> Database Driver Class Initialized
DEBUG - 2018-11-27 13:05:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-27 13:05:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-27 13:05:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-27 13:05:28 --> Pagination Class Initialized
INFO - 2018-11-27 13:05:28 --> Helper loaded: form_helper
INFO - 2018-11-27 13:05:28 --> Form Validation Class Initialized
INFO - 2018-11-27 13:05:28 --> Controller Class Initialized
INFO - 2018-11-27 13:05:28 --> File loaded: C:\xampp\htdocs\payment_example\application\views\payu_payment/confirmation.php
INFO - 2018-11-27 13:05:28 --> Final output sent to browser
DEBUG - 2018-11-27 13:05:28 --> Total execution time: 0.0570
INFO - 2018-11-27 13:05:30 --> Config Class Initialized
INFO - 2018-11-27 13:05:30 --> Hooks Class Initialized
DEBUG - 2018-11-27 13:05:30 --> UTF-8 Support Enabled
INFO - 2018-11-27 13:05:30 --> Utf8 Class Initialized
INFO - 2018-11-27 13:05:30 --> URI Class Initialized
INFO - 2018-11-27 13:05:30 --> Router Class Initialized
INFO - 2018-11-27 13:05:30 --> Output Class Initialized
INFO - 2018-11-27 13:05:30 --> Security Class Initialized
DEBUG - 2018-11-27 13:05:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-27 13:05:30 --> Input Class Initialized
INFO - 2018-11-27 13:05:30 --> Language Class Initialized
ERROR - 2018-11-27 13:05:30 --> 404 Page Not Found: Verify/favicon.png
INFO - 2018-11-27 13:05:57 --> Config Class Initialized
INFO - 2018-11-27 13:05:57 --> Hooks Class Initialized
DEBUG - 2018-11-27 13:05:57 --> UTF-8 Support Enabled
INFO - 2018-11-27 13:05:57 --> Utf8 Class Initialized
INFO - 2018-11-27 13:05:57 --> URI Class Initialized
INFO - 2018-11-27 13:05:57 --> Router Class Initialized
INFO - 2018-11-27 13:05:57 --> Output Class Initialized
INFO - 2018-11-27 13:05:57 --> Security Class Initialized
DEBUG - 2018-11-27 13:05:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-27 13:05:57 --> Input Class Initialized
INFO - 2018-11-27 13:05:57 --> Language Class Initialized
INFO - 2018-11-27 13:05:57 --> Loader Class Initialized
INFO - 2018-11-27 13:05:57 --> Helper loaded: url_helper
INFO - 2018-11-27 13:05:57 --> Helper loaded: file_helper
INFO - 2018-11-27 13:05:57 --> Helper loaded: email_helper
INFO - 2018-11-27 13:05:57 --> Helper loaded: common_helper
INFO - 2018-11-27 13:05:57 --> Database Driver Class Initialized
DEBUG - 2018-11-27 13:05:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-27 13:05:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-27 13:05:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-27 13:05:57 --> Pagination Class Initialized
INFO - 2018-11-27 13:05:57 --> Helper loaded: form_helper
INFO - 2018-11-27 13:05:57 --> Form Validation Class Initialized
INFO - 2018-11-27 13:05:57 --> Controller Class Initialized
INFO - 2018-11-27 13:05:57 --> File loaded: C:\xampp\htdocs\payment_example\application\views\payu_payment/confirmation.php
INFO - 2018-11-27 13:05:57 --> Final output sent to browser
DEBUG - 2018-11-27 13:05:57 --> Total execution time: 0.0650
INFO - 2018-11-27 13:05:58 --> Config Class Initialized
INFO - 2018-11-27 13:05:58 --> Hooks Class Initialized
DEBUG - 2018-11-27 13:05:58 --> UTF-8 Support Enabled
INFO - 2018-11-27 13:05:58 --> Utf8 Class Initialized
INFO - 2018-11-27 13:05:58 --> URI Class Initialized
INFO - 2018-11-27 13:05:58 --> Router Class Initialized
INFO - 2018-11-27 13:05:58 --> Output Class Initialized
INFO - 2018-11-27 13:05:58 --> Security Class Initialized
DEBUG - 2018-11-27 13:05:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-27 13:05:58 --> Input Class Initialized
INFO - 2018-11-27 13:05:58 --> Language Class Initialized
ERROR - 2018-11-27 13:05:58 --> 404 Page Not Found: Verify/favicon.png
INFO - 2018-11-27 13:06:34 --> Config Class Initialized
INFO - 2018-11-27 13:06:34 --> Hooks Class Initialized
DEBUG - 2018-11-27 13:06:34 --> UTF-8 Support Enabled
INFO - 2018-11-27 13:06:34 --> Utf8 Class Initialized
INFO - 2018-11-27 13:06:34 --> URI Class Initialized
INFO - 2018-11-27 13:06:34 --> Router Class Initialized
INFO - 2018-11-27 13:06:34 --> Output Class Initialized
INFO - 2018-11-27 13:06:34 --> Security Class Initialized
DEBUG - 2018-11-27 13:06:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-27 13:06:34 --> Input Class Initialized
INFO - 2018-11-27 13:06:34 --> Language Class Initialized
INFO - 2018-11-27 13:06:34 --> Loader Class Initialized
INFO - 2018-11-27 13:06:34 --> Helper loaded: url_helper
INFO - 2018-11-27 13:06:34 --> Helper loaded: file_helper
INFO - 2018-11-27 13:06:34 --> Helper loaded: email_helper
INFO - 2018-11-27 13:06:34 --> Helper loaded: common_helper
INFO - 2018-11-27 13:06:34 --> Database Driver Class Initialized
DEBUG - 2018-11-27 13:06:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-27 13:06:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-27 13:06:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-27 13:06:34 --> Pagination Class Initialized
INFO - 2018-11-27 13:06:34 --> Helper loaded: form_helper
INFO - 2018-11-27 13:06:34 --> Form Validation Class Initialized
INFO - 2018-11-27 13:06:34 --> Controller Class Initialized
INFO - 2018-11-27 13:06:34 --> File loaded: C:\xampp\htdocs\payment_example\application\views\payu_payment/confirmation.php
INFO - 2018-11-27 13:06:34 --> Final output sent to browser
DEBUG - 2018-11-27 13:06:34 --> Total execution time: 0.0660
INFO - 2018-11-27 13:06:35 --> Config Class Initialized
INFO - 2018-11-27 13:06:35 --> Hooks Class Initialized
DEBUG - 2018-11-27 13:06:35 --> UTF-8 Support Enabled
INFO - 2018-11-27 13:06:35 --> Utf8 Class Initialized
INFO - 2018-11-27 13:06:35 --> URI Class Initialized
INFO - 2018-11-27 13:06:35 --> Router Class Initialized
INFO - 2018-11-27 13:06:35 --> Output Class Initialized
INFO - 2018-11-27 13:06:35 --> Security Class Initialized
DEBUG - 2018-11-27 13:06:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-27 13:06:35 --> Input Class Initialized
INFO - 2018-11-27 13:06:35 --> Language Class Initialized
ERROR - 2018-11-27 13:06:35 --> 404 Page Not Found: Verify/favicon.png
INFO - 2018-11-27 13:06:42 --> Config Class Initialized
INFO - 2018-11-27 13:06:42 --> Hooks Class Initialized
DEBUG - 2018-11-27 13:06:42 --> UTF-8 Support Enabled
INFO - 2018-11-27 13:06:42 --> Utf8 Class Initialized
INFO - 2018-11-27 13:06:42 --> URI Class Initialized
INFO - 2018-11-27 13:06:42 --> Router Class Initialized
INFO - 2018-11-27 13:06:42 --> Output Class Initialized
INFO - 2018-11-27 13:06:42 --> Security Class Initialized
DEBUG - 2018-11-27 13:06:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-27 13:06:42 --> Input Class Initialized
INFO - 2018-11-27 13:06:42 --> Language Class Initialized
INFO - 2018-11-27 13:06:42 --> Loader Class Initialized
INFO - 2018-11-27 13:06:42 --> Helper loaded: url_helper
INFO - 2018-11-27 13:06:42 --> Helper loaded: file_helper
INFO - 2018-11-27 13:06:42 --> Helper loaded: email_helper
INFO - 2018-11-27 13:06:42 --> Helper loaded: common_helper
INFO - 2018-11-27 13:06:42 --> Database Driver Class Initialized
DEBUG - 2018-11-27 13:06:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-27 13:06:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-27 13:06:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-27 13:06:42 --> Pagination Class Initialized
INFO - 2018-11-27 13:06:42 --> Helper loaded: form_helper
INFO - 2018-11-27 13:06:42 --> Form Validation Class Initialized
INFO - 2018-11-27 13:06:42 --> Controller Class Initialized
INFO - 2018-11-27 13:06:42 --> File loaded: C:\xampp\htdocs\payment_example\application\views\payu_payment/confirmation.php
INFO - 2018-11-27 13:06:42 --> Final output sent to browser
DEBUG - 2018-11-27 13:06:42 --> Total execution time: 0.0750
INFO - 2018-11-27 13:06:43 --> Config Class Initialized
INFO - 2018-11-27 13:06:43 --> Hooks Class Initialized
DEBUG - 2018-11-27 13:06:43 --> UTF-8 Support Enabled
INFO - 2018-11-27 13:06:43 --> Utf8 Class Initialized
INFO - 2018-11-27 13:06:43 --> URI Class Initialized
INFO - 2018-11-27 13:06:43 --> Router Class Initialized
INFO - 2018-11-27 13:06:43 --> Output Class Initialized
INFO - 2018-11-27 13:06:43 --> Security Class Initialized
DEBUG - 2018-11-27 13:06:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-27 13:06:43 --> Input Class Initialized
INFO - 2018-11-27 13:06:43 --> Language Class Initialized
ERROR - 2018-11-27 13:06:43 --> 404 Page Not Found: Verify/favicon.png
INFO - 2018-11-27 13:08:41 --> Config Class Initialized
INFO - 2018-11-27 13:08:41 --> Hooks Class Initialized
DEBUG - 2018-11-27 13:08:41 --> UTF-8 Support Enabled
INFO - 2018-11-27 13:08:41 --> Utf8 Class Initialized
INFO - 2018-11-27 13:08:41 --> URI Class Initialized
INFO - 2018-11-27 13:08:41 --> Router Class Initialized
INFO - 2018-11-27 13:08:41 --> Output Class Initialized
INFO - 2018-11-27 13:08:41 --> Security Class Initialized
DEBUG - 2018-11-27 13:08:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-27 13:08:41 --> Input Class Initialized
INFO - 2018-11-27 13:08:41 --> Language Class Initialized
INFO - 2018-11-27 13:08:41 --> Loader Class Initialized
INFO - 2018-11-27 13:08:41 --> Helper loaded: url_helper
INFO - 2018-11-27 13:08:41 --> Helper loaded: file_helper
INFO - 2018-11-27 13:08:41 --> Helper loaded: email_helper
INFO - 2018-11-27 13:08:41 --> Helper loaded: common_helper
INFO - 2018-11-27 13:08:41 --> Database Driver Class Initialized
DEBUG - 2018-11-27 13:08:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-27 13:08:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-27 13:08:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-27 13:08:41 --> Pagination Class Initialized
INFO - 2018-11-27 13:08:41 --> Helper loaded: form_helper
INFO - 2018-11-27 13:08:41 --> Form Validation Class Initialized
INFO - 2018-11-27 13:08:41 --> Controller Class Initialized
INFO - 2018-11-27 13:08:41 --> File loaded: C:\xampp\htdocs\payment_example\application\views\payu_payment/confirmation.php
INFO - 2018-11-27 13:08:41 --> Final output sent to browser
DEBUG - 2018-11-27 13:08:41 --> Total execution time: 0.0580
INFO - 2018-11-27 13:08:42 --> Config Class Initialized
INFO - 2018-11-27 13:08:42 --> Hooks Class Initialized
DEBUG - 2018-11-27 13:08:42 --> UTF-8 Support Enabled
INFO - 2018-11-27 13:08:42 --> Utf8 Class Initialized
INFO - 2018-11-27 13:08:42 --> URI Class Initialized
INFO - 2018-11-27 13:08:42 --> Router Class Initialized
INFO - 2018-11-27 13:08:42 --> Output Class Initialized
INFO - 2018-11-27 13:08:42 --> Security Class Initialized
DEBUG - 2018-11-27 13:08:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-27 13:08:42 --> Input Class Initialized
INFO - 2018-11-27 13:08:42 --> Language Class Initialized
ERROR - 2018-11-27 13:08:42 --> 404 Page Not Found: Verify/favicon.png
INFO - 2018-11-27 13:09:44 --> Config Class Initialized
INFO - 2018-11-27 13:09:44 --> Hooks Class Initialized
DEBUG - 2018-11-27 13:09:44 --> UTF-8 Support Enabled
INFO - 2018-11-27 13:09:44 --> Utf8 Class Initialized
INFO - 2018-11-27 13:09:44 --> URI Class Initialized
INFO - 2018-11-27 13:09:44 --> Router Class Initialized
INFO - 2018-11-27 13:09:44 --> Output Class Initialized
INFO - 2018-11-27 13:09:44 --> Security Class Initialized
DEBUG - 2018-11-27 13:09:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-27 13:09:44 --> Input Class Initialized
INFO - 2018-11-27 13:09:44 --> Language Class Initialized
INFO - 2018-11-27 13:09:44 --> Loader Class Initialized
INFO - 2018-11-27 13:09:44 --> Helper loaded: url_helper
INFO - 2018-11-27 13:09:44 --> Helper loaded: file_helper
INFO - 2018-11-27 13:09:44 --> Helper loaded: email_helper
INFO - 2018-11-27 13:09:44 --> Helper loaded: common_helper
INFO - 2018-11-27 13:09:45 --> Database Driver Class Initialized
DEBUG - 2018-11-27 13:09:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-27 13:09:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-27 13:09:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-27 13:09:45 --> Pagination Class Initialized
INFO - 2018-11-27 13:09:45 --> Helper loaded: form_helper
INFO - 2018-11-27 13:09:45 --> Form Validation Class Initialized
INFO - 2018-11-27 13:09:45 --> Controller Class Initialized
INFO - 2018-11-27 13:09:45 --> File loaded: C:\xampp\htdocs\payment_example\application\views\payu_payment/confirmation.php
INFO - 2018-11-27 13:09:45 --> Final output sent to browser
DEBUG - 2018-11-27 13:09:45 --> Total execution time: 0.0580
INFO - 2018-11-27 13:09:47 --> Config Class Initialized
INFO - 2018-11-27 13:09:47 --> Hooks Class Initialized
DEBUG - 2018-11-27 13:09:47 --> UTF-8 Support Enabled
INFO - 2018-11-27 13:09:47 --> Utf8 Class Initialized
INFO - 2018-11-27 13:09:47 --> URI Class Initialized
INFO - 2018-11-27 13:09:47 --> Router Class Initialized
INFO - 2018-11-27 13:09:47 --> Output Class Initialized
INFO - 2018-11-27 13:09:47 --> Security Class Initialized
DEBUG - 2018-11-27 13:09:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-27 13:09:47 --> Input Class Initialized
INFO - 2018-11-27 13:09:47 --> Language Class Initialized
ERROR - 2018-11-27 13:09:47 --> 404 Page Not Found: Verify/favicon.png
INFO - 2018-11-27 13:10:29 --> Config Class Initialized
INFO - 2018-11-27 13:10:29 --> Hooks Class Initialized
DEBUG - 2018-11-27 13:10:29 --> UTF-8 Support Enabled
INFO - 2018-11-27 13:10:29 --> Utf8 Class Initialized
INFO - 2018-11-27 13:10:29 --> URI Class Initialized
INFO - 2018-11-27 13:10:29 --> Router Class Initialized
INFO - 2018-11-27 13:10:29 --> Output Class Initialized
INFO - 2018-11-27 13:10:29 --> Security Class Initialized
DEBUG - 2018-11-27 13:10:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-27 13:10:29 --> Input Class Initialized
INFO - 2018-11-27 13:10:29 --> Language Class Initialized
INFO - 2018-11-27 13:10:29 --> Loader Class Initialized
INFO - 2018-11-27 13:10:29 --> Helper loaded: url_helper
INFO - 2018-11-27 13:10:29 --> Helper loaded: file_helper
INFO - 2018-11-27 13:10:29 --> Helper loaded: email_helper
INFO - 2018-11-27 13:10:29 --> Helper loaded: common_helper
INFO - 2018-11-27 13:10:29 --> Database Driver Class Initialized
DEBUG - 2018-11-27 13:10:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-27 13:10:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-27 13:10:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-27 13:10:29 --> Pagination Class Initialized
INFO - 2018-11-27 13:10:29 --> Helper loaded: form_helper
INFO - 2018-11-27 13:10:29 --> Form Validation Class Initialized
INFO - 2018-11-27 13:10:29 --> Controller Class Initialized
INFO - 2018-11-27 13:10:29 --> File loaded: C:\xampp\htdocs\payment_example\application\views\payu_payment/confirmation.php
INFO - 2018-11-27 13:10:29 --> Final output sent to browser
DEBUG - 2018-11-27 13:10:29 --> Total execution time: 0.0760
INFO - 2018-11-27 13:10:30 --> Config Class Initialized
INFO - 2018-11-27 13:10:30 --> Hooks Class Initialized
DEBUG - 2018-11-27 13:10:30 --> UTF-8 Support Enabled
INFO - 2018-11-27 13:10:30 --> Utf8 Class Initialized
INFO - 2018-11-27 13:10:30 --> URI Class Initialized
INFO - 2018-11-27 13:10:30 --> Router Class Initialized
INFO - 2018-11-27 13:10:30 --> Output Class Initialized
INFO - 2018-11-27 13:10:30 --> Security Class Initialized
DEBUG - 2018-11-27 13:10:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-27 13:10:30 --> Input Class Initialized
INFO - 2018-11-27 13:10:30 --> Language Class Initialized
ERROR - 2018-11-27 13:10:30 --> 404 Page Not Found: Verify/favicon.png
INFO - 2018-11-27 13:13:08 --> Config Class Initialized
INFO - 2018-11-27 13:13:08 --> Hooks Class Initialized
DEBUG - 2018-11-27 13:13:08 --> UTF-8 Support Enabled
INFO - 2018-11-27 13:13:08 --> Utf8 Class Initialized
INFO - 2018-11-27 13:13:08 --> URI Class Initialized
INFO - 2018-11-27 13:13:08 --> Router Class Initialized
INFO - 2018-11-27 13:13:08 --> Output Class Initialized
INFO - 2018-11-27 13:13:08 --> Security Class Initialized
DEBUG - 2018-11-27 13:13:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-27 13:13:08 --> Input Class Initialized
INFO - 2018-11-27 13:13:08 --> Language Class Initialized
INFO - 2018-11-27 13:13:08 --> Loader Class Initialized
INFO - 2018-11-27 13:13:08 --> Helper loaded: url_helper
INFO - 2018-11-27 13:13:08 --> Helper loaded: file_helper
INFO - 2018-11-27 13:13:08 --> Helper loaded: email_helper
INFO - 2018-11-27 13:13:08 --> Helper loaded: common_helper
INFO - 2018-11-27 13:13:08 --> Database Driver Class Initialized
DEBUG - 2018-11-27 13:13:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-27 13:13:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-27 13:13:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-27 13:13:08 --> Pagination Class Initialized
INFO - 2018-11-27 13:13:08 --> Helper loaded: form_helper
INFO - 2018-11-27 13:13:08 --> Form Validation Class Initialized
INFO - 2018-11-27 13:13:08 --> Controller Class Initialized
INFO - 2018-11-27 13:13:32 --> Config Class Initialized
INFO - 2018-11-27 13:13:32 --> Hooks Class Initialized
DEBUG - 2018-11-27 13:13:32 --> UTF-8 Support Enabled
INFO - 2018-11-27 13:13:32 --> Utf8 Class Initialized
INFO - 2018-11-27 13:13:32 --> URI Class Initialized
INFO - 2018-11-27 13:13:32 --> Router Class Initialized
INFO - 2018-11-27 13:13:32 --> Output Class Initialized
INFO - 2018-11-27 13:13:32 --> Security Class Initialized
DEBUG - 2018-11-27 13:13:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-27 13:13:32 --> Input Class Initialized
INFO - 2018-11-27 13:13:32 --> Language Class Initialized
INFO - 2018-11-27 13:13:32 --> Loader Class Initialized
INFO - 2018-11-27 13:13:32 --> Helper loaded: url_helper
INFO - 2018-11-27 13:13:32 --> Helper loaded: file_helper
INFO - 2018-11-27 13:13:32 --> Helper loaded: email_helper
INFO - 2018-11-27 13:13:32 --> Helper loaded: common_helper
INFO - 2018-11-27 13:13:32 --> Database Driver Class Initialized
DEBUG - 2018-11-27 13:13:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-27 13:13:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-27 13:13:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-27 13:13:32 --> Pagination Class Initialized
INFO - 2018-11-27 13:13:32 --> Helper loaded: form_helper
INFO - 2018-11-27 13:13:32 --> Form Validation Class Initialized
INFO - 2018-11-27 13:13:32 --> Controller Class Initialized
INFO - 2018-11-27 13:17:07 --> Config Class Initialized
INFO - 2018-11-27 13:17:07 --> Hooks Class Initialized
DEBUG - 2018-11-27 13:17:07 --> UTF-8 Support Enabled
INFO - 2018-11-27 13:17:07 --> Utf8 Class Initialized
INFO - 2018-11-27 13:17:07 --> URI Class Initialized
INFO - 2018-11-27 13:17:07 --> Router Class Initialized
INFO - 2018-11-27 13:17:07 --> Output Class Initialized
INFO - 2018-11-27 13:17:07 --> Security Class Initialized
DEBUG - 2018-11-27 13:17:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-27 13:17:07 --> Input Class Initialized
INFO - 2018-11-27 13:17:07 --> Language Class Initialized
INFO - 2018-11-27 13:17:07 --> Loader Class Initialized
INFO - 2018-11-27 13:17:07 --> Helper loaded: url_helper
INFO - 2018-11-27 13:17:07 --> Helper loaded: file_helper
INFO - 2018-11-27 13:17:07 --> Helper loaded: email_helper
INFO - 2018-11-27 13:17:07 --> Helper loaded: common_helper
INFO - 2018-11-27 13:17:07 --> Database Driver Class Initialized
DEBUG - 2018-11-27 13:17:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-27 13:17:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-27 13:17:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-27 13:17:07 --> Pagination Class Initialized
INFO - 2018-11-27 13:17:07 --> Helper loaded: form_helper
INFO - 2018-11-27 13:17:07 --> Form Validation Class Initialized
INFO - 2018-11-27 13:17:07 --> Controller Class Initialized
INFO - 2018-11-27 13:17:07 --> File loaded: C:\xampp\htdocs\payment_example\application\views\payu_payment/confirmation.php
INFO - 2018-11-27 13:17:07 --> Final output sent to browser
DEBUG - 2018-11-27 13:17:07 --> Total execution time: 0.3020
INFO - 2018-11-27 13:17:09 --> Config Class Initialized
INFO - 2018-11-27 13:17:09 --> Hooks Class Initialized
DEBUG - 2018-11-27 13:17:09 --> UTF-8 Support Enabled
INFO - 2018-11-27 13:17:09 --> Utf8 Class Initialized
INFO - 2018-11-27 13:17:09 --> URI Class Initialized
INFO - 2018-11-27 13:17:09 --> Router Class Initialized
INFO - 2018-11-27 13:17:09 --> Output Class Initialized
INFO - 2018-11-27 13:17:09 --> Security Class Initialized
DEBUG - 2018-11-27 13:17:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-27 13:17:09 --> Input Class Initialized
INFO - 2018-11-27 13:17:09 --> Language Class Initialized
ERROR - 2018-11-27 13:17:09 --> 404 Page Not Found: Verify/favicon.png
INFO - 2018-11-27 13:19:08 --> Config Class Initialized
INFO - 2018-11-27 13:19:08 --> Hooks Class Initialized
DEBUG - 2018-11-27 13:19:08 --> UTF-8 Support Enabled
INFO - 2018-11-27 13:19:08 --> Utf8 Class Initialized
INFO - 2018-11-27 13:19:08 --> URI Class Initialized
INFO - 2018-11-27 13:19:08 --> Router Class Initialized
INFO - 2018-11-27 13:19:08 --> Output Class Initialized
INFO - 2018-11-27 13:19:08 --> Security Class Initialized
DEBUG - 2018-11-27 13:19:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-27 13:19:08 --> Input Class Initialized
INFO - 2018-11-27 13:19:08 --> Language Class Initialized
INFO - 2018-11-27 13:19:08 --> Loader Class Initialized
INFO - 2018-11-27 13:19:08 --> Helper loaded: url_helper
INFO - 2018-11-27 13:19:08 --> Helper loaded: file_helper
INFO - 2018-11-27 13:19:08 --> Helper loaded: email_helper
INFO - 2018-11-27 13:19:08 --> Helper loaded: common_helper
INFO - 2018-11-27 13:19:08 --> Database Driver Class Initialized
DEBUG - 2018-11-27 13:19:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-27 13:19:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-27 13:19:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-27 13:19:08 --> Pagination Class Initialized
INFO - 2018-11-27 13:19:08 --> Helper loaded: form_helper
INFO - 2018-11-27 13:19:08 --> Form Validation Class Initialized
INFO - 2018-11-27 13:19:08 --> Controller Class Initialized
INFO - 2018-11-27 13:42:51 --> Config Class Initialized
INFO - 2018-11-27 13:42:51 --> Hooks Class Initialized
DEBUG - 2018-11-27 13:42:51 --> UTF-8 Support Enabled
INFO - 2018-11-27 13:42:51 --> Utf8 Class Initialized
INFO - 2018-11-27 13:42:51 --> URI Class Initialized
INFO - 2018-11-27 13:42:51 --> Router Class Initialized
INFO - 2018-11-27 13:42:51 --> Output Class Initialized
INFO - 2018-11-27 13:42:51 --> Security Class Initialized
DEBUG - 2018-11-27 13:42:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-27 13:42:51 --> Input Class Initialized
INFO - 2018-11-27 13:42:51 --> Language Class Initialized
INFO - 2018-11-27 13:42:51 --> Loader Class Initialized
INFO - 2018-11-27 13:42:51 --> Helper loaded: url_helper
INFO - 2018-11-27 13:42:51 --> Helper loaded: file_helper
INFO - 2018-11-27 13:42:51 --> Helper loaded: email_helper
INFO - 2018-11-27 13:42:51 --> Helper loaded: common_helper
INFO - 2018-11-27 13:42:51 --> Database Driver Class Initialized
DEBUG - 2018-11-27 13:42:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-27 13:42:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-27 13:42:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-27 13:42:51 --> Pagination Class Initialized
INFO - 2018-11-27 13:42:51 --> Helper loaded: form_helper
INFO - 2018-11-27 13:42:51 --> Form Validation Class Initialized
INFO - 2018-11-27 13:42:51 --> Controller Class Initialized
INFO - 2018-11-27 13:42:51 --> File loaded: C:\xampp\htdocs\payment_example\application\views\payu_payment/confirmation.php
INFO - 2018-11-27 13:42:51 --> Final output sent to browser
DEBUG - 2018-11-27 13:42:51 --> Total execution time: 0.0680
INFO - 2018-11-27 13:43:07 --> Config Class Initialized
INFO - 2018-11-27 13:43:07 --> Hooks Class Initialized
DEBUG - 2018-11-27 13:43:07 --> UTF-8 Support Enabled
INFO - 2018-11-27 13:43:07 --> Utf8 Class Initialized
INFO - 2018-11-27 13:43:07 --> URI Class Initialized
INFO - 2018-11-27 13:43:07 --> Router Class Initialized
INFO - 2018-11-27 13:43:07 --> Output Class Initialized
INFO - 2018-11-27 13:43:07 --> Security Class Initialized
DEBUG - 2018-11-27 13:43:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-27 13:43:07 --> Input Class Initialized
INFO - 2018-11-27 13:43:07 --> Language Class Initialized
INFO - 2018-11-27 13:43:07 --> Loader Class Initialized
INFO - 2018-11-27 13:43:07 --> Helper loaded: url_helper
INFO - 2018-11-27 13:43:07 --> Helper loaded: file_helper
INFO - 2018-11-27 13:43:07 --> Helper loaded: email_helper
INFO - 2018-11-27 13:43:07 --> Helper loaded: common_helper
INFO - 2018-11-27 13:43:07 --> Database Driver Class Initialized
DEBUG - 2018-11-27 13:43:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-27 13:43:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-27 13:43:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-27 13:43:07 --> Pagination Class Initialized
INFO - 2018-11-27 13:43:07 --> Helper loaded: form_helper
INFO - 2018-11-27 13:43:07 --> Form Validation Class Initialized
INFO - 2018-11-27 13:43:07 --> Controller Class Initialized
INFO - 2018-11-27 13:43:07 --> File loaded: C:\xampp\htdocs\payment_example\application\views\payu_payment/confirmation.php
INFO - 2018-11-27 13:43:07 --> Final output sent to browser
DEBUG - 2018-11-27 13:43:07 --> Total execution time: 0.0890
INFO - 2018-11-27 13:43:08 --> Config Class Initialized
INFO - 2018-11-27 13:43:08 --> Hooks Class Initialized
DEBUG - 2018-11-27 13:43:08 --> UTF-8 Support Enabled
INFO - 2018-11-27 13:43:08 --> Utf8 Class Initialized
INFO - 2018-11-27 13:43:08 --> URI Class Initialized
INFO - 2018-11-27 13:43:08 --> Router Class Initialized
INFO - 2018-11-27 13:43:08 --> Output Class Initialized
INFO - 2018-11-27 13:43:08 --> Security Class Initialized
DEBUG - 2018-11-27 13:43:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-27 13:43:08 --> Input Class Initialized
INFO - 2018-11-27 13:43:08 --> Language Class Initialized
ERROR - 2018-11-27 13:43:08 --> 404 Page Not Found: Verify/favicon.png
INFO - 2018-11-27 13:43:23 --> Config Class Initialized
INFO - 2018-11-27 13:43:23 --> Hooks Class Initialized
DEBUG - 2018-11-27 13:43:23 --> UTF-8 Support Enabled
INFO - 2018-11-27 13:43:23 --> Utf8 Class Initialized
INFO - 2018-11-27 13:43:23 --> URI Class Initialized
INFO - 2018-11-27 13:43:23 --> Router Class Initialized
INFO - 2018-11-27 13:43:23 --> Output Class Initialized
INFO - 2018-11-27 13:43:23 --> Security Class Initialized
DEBUG - 2018-11-27 13:43:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-27 13:43:23 --> Input Class Initialized
INFO - 2018-11-27 13:43:23 --> Language Class Initialized
INFO - 2018-11-27 13:43:23 --> Loader Class Initialized
INFO - 2018-11-27 13:43:23 --> Helper loaded: url_helper
INFO - 2018-11-27 13:43:23 --> Helper loaded: file_helper
INFO - 2018-11-27 13:43:23 --> Helper loaded: email_helper
INFO - 2018-11-27 13:43:23 --> Helper loaded: common_helper
INFO - 2018-11-27 13:43:23 --> Database Driver Class Initialized
DEBUG - 2018-11-27 13:43:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-27 13:43:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-27 13:43:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-27 13:43:23 --> Pagination Class Initialized
INFO - 2018-11-27 13:43:23 --> Helper loaded: form_helper
INFO - 2018-11-27 13:43:23 --> Form Validation Class Initialized
INFO - 2018-11-27 13:43:23 --> Controller Class Initialized
INFO - 2018-11-27 13:43:23 --> File loaded: C:\xampp\htdocs\payment_example\application\views\payu_payment/confirmation.php
INFO - 2018-11-27 13:43:23 --> Final output sent to browser
DEBUG - 2018-11-27 13:43:23 --> Total execution time: 0.0640
INFO - 2018-11-27 13:44:00 --> Config Class Initialized
INFO - 2018-11-27 13:44:00 --> Hooks Class Initialized
DEBUG - 2018-11-27 13:44:00 --> UTF-8 Support Enabled
INFO - 2018-11-27 13:44:00 --> Utf8 Class Initialized
INFO - 2018-11-27 13:44:00 --> URI Class Initialized
INFO - 2018-11-27 13:44:00 --> Router Class Initialized
INFO - 2018-11-27 13:44:00 --> Output Class Initialized
INFO - 2018-11-27 13:44:00 --> Security Class Initialized
DEBUG - 2018-11-27 13:44:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-27 13:44:00 --> Input Class Initialized
INFO - 2018-11-27 13:44:00 --> Language Class Initialized
INFO - 2018-11-27 13:44:00 --> Loader Class Initialized
INFO - 2018-11-27 13:44:00 --> Helper loaded: url_helper
INFO - 2018-11-27 13:44:00 --> Helper loaded: file_helper
INFO - 2018-11-27 13:44:00 --> Helper loaded: email_helper
INFO - 2018-11-27 13:44:00 --> Helper loaded: common_helper
INFO - 2018-11-27 13:44:00 --> Database Driver Class Initialized
DEBUG - 2018-11-27 13:44:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-27 13:44:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-27 13:44:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-27 13:44:00 --> Pagination Class Initialized
INFO - 2018-11-27 13:44:00 --> Helper loaded: form_helper
INFO - 2018-11-27 13:44:00 --> Form Validation Class Initialized
INFO - 2018-11-27 13:44:00 --> Controller Class Initialized
INFO - 2018-11-27 13:44:00 --> File loaded: C:\xampp\htdocs\payment_example\application\views\payu_payment/confirmation.php
INFO - 2018-11-27 13:44:00 --> Final output sent to browser
DEBUG - 2018-11-27 13:44:00 --> Total execution time: 0.0880
INFO - 2018-11-27 13:44:00 --> Config Class Initialized
INFO - 2018-11-27 13:44:00 --> Hooks Class Initialized
DEBUG - 2018-11-27 13:44:00 --> UTF-8 Support Enabled
INFO - 2018-11-27 13:44:00 --> Utf8 Class Initialized
INFO - 2018-11-27 13:44:00 --> URI Class Initialized
INFO - 2018-11-27 13:44:00 --> Router Class Initialized
INFO - 2018-11-27 13:44:00 --> Output Class Initialized
INFO - 2018-11-27 13:44:00 --> Security Class Initialized
DEBUG - 2018-11-27 13:44:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-27 13:44:00 --> Input Class Initialized
INFO - 2018-11-27 13:44:00 --> Language Class Initialized
ERROR - 2018-11-27 13:44:00 --> 404 Page Not Found: Verify/favicon.png
INFO - 2018-11-27 13:44:05 --> Config Class Initialized
INFO - 2018-11-27 13:44:05 --> Hooks Class Initialized
DEBUG - 2018-11-27 13:44:05 --> UTF-8 Support Enabled
INFO - 2018-11-27 13:44:05 --> Utf8 Class Initialized
INFO - 2018-11-27 13:44:05 --> URI Class Initialized
INFO - 2018-11-27 13:44:05 --> Router Class Initialized
INFO - 2018-11-27 13:44:05 --> Output Class Initialized
INFO - 2018-11-27 13:44:05 --> Security Class Initialized
DEBUG - 2018-11-27 13:44:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-27 13:44:05 --> Input Class Initialized
INFO - 2018-11-27 13:44:05 --> Language Class Initialized
INFO - 2018-11-27 13:44:05 --> Loader Class Initialized
INFO - 2018-11-27 13:44:05 --> Helper loaded: url_helper
INFO - 2018-11-27 13:44:05 --> Helper loaded: file_helper
INFO - 2018-11-27 13:44:05 --> Helper loaded: email_helper
INFO - 2018-11-27 13:44:05 --> Helper loaded: common_helper
INFO - 2018-11-27 13:44:05 --> Database Driver Class Initialized
DEBUG - 2018-11-27 13:44:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-27 13:44:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-27 13:44:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-27 13:44:05 --> Pagination Class Initialized
INFO - 2018-11-27 13:44:05 --> Helper loaded: form_helper
INFO - 2018-11-27 13:44:05 --> Form Validation Class Initialized
INFO - 2018-11-27 13:44:05 --> Controller Class Initialized
INFO - 2018-11-27 13:44:05 --> File loaded: C:\xampp\htdocs\payment_example\application\views\payu_payment/confirmation.php
INFO - 2018-11-27 13:44:05 --> Final output sent to browser
DEBUG - 2018-11-27 13:44:05 --> Total execution time: 0.0730
INFO - 2018-11-27 13:44:10 --> Config Class Initialized
INFO - 2018-11-27 13:44:10 --> Hooks Class Initialized
DEBUG - 2018-11-27 13:44:10 --> UTF-8 Support Enabled
INFO - 2018-11-27 13:44:10 --> Utf8 Class Initialized
INFO - 2018-11-27 13:44:10 --> URI Class Initialized
INFO - 2018-11-27 13:44:10 --> Router Class Initialized
INFO - 2018-11-27 13:44:10 --> Output Class Initialized
INFO - 2018-11-27 13:44:10 --> Security Class Initialized
DEBUG - 2018-11-27 13:44:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-27 13:44:10 --> Input Class Initialized
INFO - 2018-11-27 13:44:10 --> Language Class Initialized
INFO - 2018-11-27 13:44:10 --> Loader Class Initialized
INFO - 2018-11-27 13:44:10 --> Helper loaded: url_helper
INFO - 2018-11-27 13:44:10 --> Helper loaded: file_helper
INFO - 2018-11-27 13:44:10 --> Helper loaded: email_helper
INFO - 2018-11-27 13:44:10 --> Helper loaded: common_helper
INFO - 2018-11-27 13:44:11 --> Database Driver Class Initialized
DEBUG - 2018-11-27 13:44:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-27 13:44:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-27 13:44:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-27 13:44:11 --> Pagination Class Initialized
INFO - 2018-11-27 13:44:11 --> Helper loaded: form_helper
INFO - 2018-11-27 13:44:11 --> Form Validation Class Initialized
INFO - 2018-11-27 13:44:11 --> Controller Class Initialized
INFO - 2018-11-27 13:44:11 --> File loaded: C:\xampp\htdocs\payment_example\application\views\payu_payment/confirmation.php
INFO - 2018-11-27 13:44:11 --> Final output sent to browser
DEBUG - 2018-11-27 13:44:11 --> Total execution time: 0.0530
INFO - 2018-11-27 13:44:11 --> Config Class Initialized
INFO - 2018-11-27 13:44:11 --> Hooks Class Initialized
DEBUG - 2018-11-27 13:44:11 --> UTF-8 Support Enabled
INFO - 2018-11-27 13:44:11 --> Utf8 Class Initialized
INFO - 2018-11-27 13:44:11 --> URI Class Initialized
INFO - 2018-11-27 13:44:11 --> Router Class Initialized
INFO - 2018-11-27 13:44:11 --> Output Class Initialized
INFO - 2018-11-27 13:44:11 --> Security Class Initialized
DEBUG - 2018-11-27 13:44:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-27 13:44:11 --> Input Class Initialized
INFO - 2018-11-27 13:44:11 --> Language Class Initialized
ERROR - 2018-11-27 13:44:11 --> 404 Page Not Found: Verify/favicon.png
INFO - 2018-11-27 13:50:25 --> Config Class Initialized
INFO - 2018-11-27 13:50:25 --> Hooks Class Initialized
DEBUG - 2018-11-27 13:50:25 --> UTF-8 Support Enabled
INFO - 2018-11-27 13:50:25 --> Utf8 Class Initialized
INFO - 2018-11-27 13:50:25 --> URI Class Initialized
INFO - 2018-11-27 13:50:25 --> Router Class Initialized
INFO - 2018-11-27 13:50:25 --> Output Class Initialized
INFO - 2018-11-27 13:50:25 --> Security Class Initialized
DEBUG - 2018-11-27 13:50:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-27 13:50:25 --> Input Class Initialized
INFO - 2018-11-27 13:50:25 --> Language Class Initialized
INFO - 2018-11-27 13:50:25 --> Loader Class Initialized
INFO - 2018-11-27 13:50:25 --> Helper loaded: url_helper
INFO - 2018-11-27 13:50:25 --> Helper loaded: file_helper
INFO - 2018-11-27 13:50:25 --> Helper loaded: email_helper
INFO - 2018-11-27 13:50:25 --> Helper loaded: common_helper
INFO - 2018-11-27 13:50:25 --> Database Driver Class Initialized
DEBUG - 2018-11-27 13:50:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-27 13:50:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-27 13:50:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-27 13:50:25 --> Pagination Class Initialized
INFO - 2018-11-27 13:50:25 --> Helper loaded: form_helper
INFO - 2018-11-27 13:50:25 --> Form Validation Class Initialized
INFO - 2018-11-27 13:50:25 --> Controller Class Initialized
INFO - 2018-11-27 13:50:25 --> File loaded: C:\xampp\htdocs\payment_example\application\views\payu_payment/success.php
INFO - 2018-11-27 13:50:25 --> Final output sent to browser
DEBUG - 2018-11-27 13:50:25 --> Total execution time: 0.1160
INFO - 2018-11-27 13:50:27 --> Config Class Initialized
INFO - 2018-11-27 13:50:27 --> Hooks Class Initialized
DEBUG - 2018-11-27 13:50:27 --> UTF-8 Support Enabled
INFO - 2018-11-27 13:50:27 --> Utf8 Class Initialized
INFO - 2018-11-27 13:50:27 --> URI Class Initialized
INFO - 2018-11-27 13:50:27 --> Router Class Initialized
INFO - 2018-11-27 13:50:27 --> Output Class Initialized
INFO - 2018-11-27 13:50:27 --> Security Class Initialized
DEBUG - 2018-11-27 13:50:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-27 13:50:27 --> Input Class Initialized
INFO - 2018-11-27 13:50:27 --> Language Class Initialized
ERROR - 2018-11-27 13:50:27 --> 404 Page Not Found: Img/favicon.png
INFO - 2018-11-27 13:52:42 --> Config Class Initialized
INFO - 2018-11-27 13:52:42 --> Hooks Class Initialized
DEBUG - 2018-11-27 13:52:42 --> UTF-8 Support Enabled
INFO - 2018-11-27 13:52:42 --> Utf8 Class Initialized
INFO - 2018-11-27 13:52:42 --> URI Class Initialized
INFO - 2018-11-27 13:52:42 --> Router Class Initialized
INFO - 2018-11-27 13:52:42 --> Output Class Initialized
INFO - 2018-11-27 13:52:42 --> Security Class Initialized
DEBUG - 2018-11-27 13:52:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-27 13:52:42 --> Input Class Initialized
INFO - 2018-11-27 13:52:42 --> Language Class Initialized
INFO - 2018-11-27 13:52:42 --> Loader Class Initialized
INFO - 2018-11-27 13:52:42 --> Helper loaded: url_helper
INFO - 2018-11-27 13:52:42 --> Helper loaded: file_helper
INFO - 2018-11-27 13:52:42 --> Helper loaded: email_helper
INFO - 2018-11-27 13:52:42 --> Helper loaded: common_helper
INFO - 2018-11-27 13:52:42 --> Database Driver Class Initialized
DEBUG - 2018-11-27 13:52:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-27 13:52:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-27 13:52:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-27 13:52:42 --> Pagination Class Initialized
INFO - 2018-11-27 13:52:42 --> Helper loaded: form_helper
INFO - 2018-11-27 13:52:42 --> Form Validation Class Initialized
INFO - 2018-11-27 13:52:42 --> Controller Class Initialized
INFO - 2018-11-27 13:52:42 --> File loaded: C:\xampp\htdocs\payment_example\application\views\payu_payment/success.php
INFO - 2018-11-27 13:52:42 --> Final output sent to browser
DEBUG - 2018-11-27 13:52:42 --> Total execution time: 0.0740
INFO - 2018-11-27 13:52:43 --> Config Class Initialized
INFO - 2018-11-27 13:52:43 --> Hooks Class Initialized
DEBUG - 2018-11-27 13:52:43 --> UTF-8 Support Enabled
INFO - 2018-11-27 13:52:43 --> Utf8 Class Initialized
INFO - 2018-11-27 13:52:43 --> URI Class Initialized
INFO - 2018-11-27 13:52:43 --> Router Class Initialized
INFO - 2018-11-27 13:52:43 --> Output Class Initialized
INFO - 2018-11-27 13:52:43 --> Security Class Initialized
DEBUG - 2018-11-27 13:52:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-27 13:52:43 --> Input Class Initialized
INFO - 2018-11-27 13:52:43 --> Language Class Initialized
ERROR - 2018-11-27 13:52:43 --> 404 Page Not Found: Img/favicon.png
INFO - 2018-11-27 13:53:20 --> Config Class Initialized
INFO - 2018-11-27 13:53:20 --> Hooks Class Initialized
DEBUG - 2018-11-27 13:53:20 --> UTF-8 Support Enabled
INFO - 2018-11-27 13:53:20 --> Utf8 Class Initialized
INFO - 2018-11-27 13:53:20 --> URI Class Initialized
DEBUG - 2018-11-27 13:53:20 --> No URI present. Default controller set.
INFO - 2018-11-27 13:53:20 --> Router Class Initialized
INFO - 2018-11-27 13:53:20 --> Output Class Initialized
INFO - 2018-11-27 13:53:20 --> Security Class Initialized
DEBUG - 2018-11-27 13:53:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-27 13:53:20 --> Input Class Initialized
INFO - 2018-11-27 13:53:20 --> Language Class Initialized
INFO - 2018-11-27 13:53:20 --> Loader Class Initialized
INFO - 2018-11-27 13:53:20 --> Helper loaded: url_helper
INFO - 2018-11-27 13:53:20 --> Helper loaded: file_helper
INFO - 2018-11-27 13:53:20 --> Helper loaded: email_helper
INFO - 2018-11-27 13:53:20 --> Helper loaded: common_helper
INFO - 2018-11-27 13:53:20 --> Database Driver Class Initialized
DEBUG - 2018-11-27 13:53:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-27 13:53:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-27 13:53:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-27 13:53:20 --> Pagination Class Initialized
INFO - 2018-11-27 13:53:20 --> Helper loaded: form_helper
INFO - 2018-11-27 13:53:20 --> Form Validation Class Initialized
INFO - 2018-11-27 13:53:20 --> Controller Class Initialized
INFO - 2018-11-27 13:53:20 --> File loaded: C:\xampp\htdocs\payment_example\application\views\payu_payment/index.php
INFO - 2018-11-27 13:53:20 --> Final output sent to browser
DEBUG - 2018-11-27 13:53:20 --> Total execution time: 0.0670
INFO - 2018-11-27 13:59:58 --> Config Class Initialized
INFO - 2018-11-27 13:59:58 --> Hooks Class Initialized
DEBUG - 2018-11-27 13:59:58 --> UTF-8 Support Enabled
INFO - 2018-11-27 13:59:58 --> Utf8 Class Initialized
INFO - 2018-11-27 13:59:58 --> URI Class Initialized
DEBUG - 2018-11-27 13:59:58 --> No URI present. Default controller set.
INFO - 2018-11-27 13:59:58 --> Router Class Initialized
INFO - 2018-11-27 13:59:58 --> Output Class Initialized
INFO - 2018-11-27 13:59:58 --> Security Class Initialized
DEBUG - 2018-11-27 13:59:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-27 13:59:58 --> Input Class Initialized
INFO - 2018-11-27 13:59:58 --> Language Class Initialized
INFO - 2018-11-27 13:59:58 --> Loader Class Initialized
INFO - 2018-11-27 13:59:58 --> Helper loaded: url_helper
INFO - 2018-11-27 13:59:58 --> Helper loaded: file_helper
INFO - 2018-11-27 13:59:58 --> Helper loaded: email_helper
INFO - 2018-11-27 13:59:58 --> Helper loaded: common_helper
INFO - 2018-11-27 13:59:58 --> Database Driver Class Initialized
DEBUG - 2018-11-27 13:59:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-27 13:59:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-27 13:59:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-27 13:59:58 --> Pagination Class Initialized
INFO - 2018-11-27 13:59:58 --> Helper loaded: form_helper
INFO - 2018-11-27 13:59:58 --> Form Validation Class Initialized
INFO - 2018-11-27 13:59:58 --> Controller Class Initialized
ERROR - 2018-11-27 13:59:58 --> Query error: Table 'wetinuneed.employee_details' doesn't exist - Invalid query: SELECT *
FROM `employee_details`
INFO - 2018-11-27 13:59:58 --> Language file loaded: language/english/db_lang.php
INFO - 2018-11-27 14:00:19 --> Config Class Initialized
INFO - 2018-11-27 14:00:19 --> Hooks Class Initialized
DEBUG - 2018-11-27 14:00:19 --> UTF-8 Support Enabled
INFO - 2018-11-27 14:00:19 --> Utf8 Class Initialized
INFO - 2018-11-27 14:00:19 --> URI Class Initialized
DEBUG - 2018-11-27 14:00:19 --> No URI present. Default controller set.
INFO - 2018-11-27 14:00:19 --> Router Class Initialized
INFO - 2018-11-27 14:00:19 --> Output Class Initialized
INFO - 2018-11-27 14:00:19 --> Security Class Initialized
DEBUG - 2018-11-27 14:00:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-27 14:00:19 --> Input Class Initialized
INFO - 2018-11-27 14:00:19 --> Language Class Initialized
INFO - 2018-11-27 14:00:19 --> Loader Class Initialized
INFO - 2018-11-27 14:00:19 --> Helper loaded: url_helper
INFO - 2018-11-27 14:00:19 --> Helper loaded: file_helper
INFO - 2018-11-27 14:00:19 --> Helper loaded: email_helper
INFO - 2018-11-27 14:00:19 --> Helper loaded: common_helper
INFO - 2018-11-27 14:00:19 --> Database Driver Class Initialized
DEBUG - 2018-11-27 14:00:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-27 14:00:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-27 14:00:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-27 14:00:19 --> Pagination Class Initialized
INFO - 2018-11-27 14:00:19 --> Helper loaded: form_helper
INFO - 2018-11-27 14:00:19 --> Form Validation Class Initialized
INFO - 2018-11-27 14:00:19 --> Controller Class Initialized
INFO - 2018-11-27 14:00:19 --> File loaded: C:\xampp\htdocs\payment_example\application\views\payu_payment/index.php
INFO - 2018-11-27 14:00:19 --> Final output sent to browser
DEBUG - 2018-11-27 14:00:19 --> Total execution time: 0.0620
INFO - 2018-11-27 14:00:38 --> Config Class Initialized
INFO - 2018-11-27 14:00:38 --> Hooks Class Initialized
DEBUG - 2018-11-27 14:00:38 --> UTF-8 Support Enabled
INFO - 2018-11-27 14:00:38 --> Utf8 Class Initialized
INFO - 2018-11-27 14:00:38 --> URI Class Initialized
DEBUG - 2018-11-27 14:00:38 --> No URI present. Default controller set.
INFO - 2018-11-27 14:00:38 --> Router Class Initialized
INFO - 2018-11-27 14:00:38 --> Output Class Initialized
INFO - 2018-11-27 14:00:38 --> Security Class Initialized
DEBUG - 2018-11-27 14:00:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-27 14:00:38 --> Input Class Initialized
INFO - 2018-11-27 14:00:38 --> Language Class Initialized
INFO - 2018-11-27 14:00:38 --> Loader Class Initialized
INFO - 2018-11-27 14:00:38 --> Helper loaded: url_helper
INFO - 2018-11-27 14:00:38 --> Helper loaded: file_helper
INFO - 2018-11-27 14:00:38 --> Helper loaded: email_helper
INFO - 2018-11-27 14:00:38 --> Helper loaded: common_helper
INFO - 2018-11-27 14:00:38 --> Database Driver Class Initialized
ERROR - 2018-11-27 14:00:38 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'root'@'admin-PC' (using password: NO) C:\xampp\htdocs\payment_example\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2018-11-27 14:00:38 --> Unable to connect to the database
INFO - 2018-11-27 14:00:38 --> Language file loaded: language/english/db_lang.php
INFO - 2018-11-27 14:00:54 --> Config Class Initialized
INFO - 2018-11-27 14:00:54 --> Hooks Class Initialized
DEBUG - 2018-11-27 14:00:54 --> UTF-8 Support Enabled
INFO - 2018-11-27 14:00:54 --> Utf8 Class Initialized
INFO - 2018-11-27 14:00:54 --> URI Class Initialized
DEBUG - 2018-11-27 14:00:54 --> No URI present. Default controller set.
INFO - 2018-11-27 14:00:54 --> Router Class Initialized
INFO - 2018-11-27 14:00:54 --> Output Class Initialized
INFO - 2018-11-27 14:00:54 --> Security Class Initialized
DEBUG - 2018-11-27 14:00:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-27 14:00:54 --> Input Class Initialized
INFO - 2018-11-27 14:00:54 --> Language Class Initialized
INFO - 2018-11-27 14:00:54 --> Loader Class Initialized
INFO - 2018-11-27 14:00:54 --> Helper loaded: url_helper
INFO - 2018-11-27 14:00:54 --> Helper loaded: file_helper
INFO - 2018-11-27 14:00:54 --> Helper loaded: email_helper
INFO - 2018-11-27 14:00:54 --> Helper loaded: common_helper
INFO - 2018-11-27 14:00:54 --> Database Driver Class Initialized
DEBUG - 2018-11-27 14:00:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-27 14:00:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-27 14:00:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-27 14:00:54 --> Pagination Class Initialized
INFO - 2018-11-27 14:00:54 --> Helper loaded: form_helper
INFO - 2018-11-27 14:00:54 --> Form Validation Class Initialized
INFO - 2018-11-27 14:00:54 --> Controller Class Initialized
INFO - 2018-11-27 14:00:54 --> File loaded: C:\xampp\htdocs\payment_example\application\views\payu_payment/index.php
INFO - 2018-11-27 14:00:54 --> Final output sent to browser
DEBUG - 2018-11-27 14:00:54 --> Total execution time: 0.0770
INFO - 2018-11-27 14:01:39 --> Config Class Initialized
INFO - 2018-11-27 14:01:39 --> Hooks Class Initialized
DEBUG - 2018-11-27 14:01:39 --> UTF-8 Support Enabled
INFO - 2018-11-27 14:01:39 --> Utf8 Class Initialized
INFO - 2018-11-27 14:01:39 --> URI Class Initialized
DEBUG - 2018-11-27 14:01:39 --> No URI present. Default controller set.
INFO - 2018-11-27 14:01:39 --> Router Class Initialized
INFO - 2018-11-27 14:01:39 --> Output Class Initialized
INFO - 2018-11-27 14:01:39 --> Security Class Initialized
DEBUG - 2018-11-27 14:01:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-27 14:01:39 --> Input Class Initialized
INFO - 2018-11-27 14:01:39 --> Language Class Initialized
INFO - 2018-11-27 14:01:39 --> Loader Class Initialized
INFO - 2018-11-27 14:01:39 --> Helper loaded: url_helper
INFO - 2018-11-27 14:01:39 --> Helper loaded: file_helper
INFO - 2018-11-27 14:01:39 --> Helper loaded: email_helper
INFO - 2018-11-27 14:01:39 --> Helper loaded: common_helper
INFO - 2018-11-27 14:01:39 --> Database Driver Class Initialized
DEBUG - 2018-11-27 14:01:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-27 14:01:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-27 14:01:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-27 14:01:39 --> Pagination Class Initialized
INFO - 2018-11-27 14:01:39 --> Helper loaded: form_helper
INFO - 2018-11-27 14:01:39 --> Form Validation Class Initialized
INFO - 2018-11-27 14:01:39 --> Controller Class Initialized
INFO - 2018-11-27 14:01:39 --> File loaded: C:\xampp\htdocs\payment_example\application\views\payu_payment/index.php
INFO - 2018-11-27 14:01:39 --> Final output sent to browser
DEBUG - 2018-11-27 14:01:39 --> Total execution time: 0.0650
INFO - 2018-11-27 14:01:44 --> Config Class Initialized
INFO - 2018-11-27 14:01:44 --> Hooks Class Initialized
DEBUG - 2018-11-27 14:01:44 --> UTF-8 Support Enabled
INFO - 2018-11-27 14:01:44 --> Utf8 Class Initialized
INFO - 2018-11-27 14:01:44 --> URI Class Initialized
INFO - 2018-11-27 14:01:44 --> Router Class Initialized
INFO - 2018-11-27 14:01:44 --> Output Class Initialized
INFO - 2018-11-27 14:01:44 --> Security Class Initialized
DEBUG - 2018-11-27 14:01:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-27 14:01:44 --> Input Class Initialized
INFO - 2018-11-27 14:01:44 --> Language Class Initialized
INFO - 2018-11-27 14:01:44 --> Loader Class Initialized
INFO - 2018-11-27 14:01:44 --> Helper loaded: url_helper
INFO - 2018-11-27 14:01:44 --> Helper loaded: file_helper
INFO - 2018-11-27 14:01:44 --> Helper loaded: email_helper
INFO - 2018-11-27 14:01:44 --> Helper loaded: common_helper
INFO - 2018-11-27 14:01:44 --> Database Driver Class Initialized
DEBUG - 2018-11-27 14:01:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-27 14:01:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-27 14:01:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-27 14:01:44 --> Pagination Class Initialized
INFO - 2018-11-27 14:01:44 --> Helper loaded: form_helper
INFO - 2018-11-27 14:01:44 --> Form Validation Class Initialized
INFO - 2018-11-27 14:01:44 --> Controller Class Initialized
INFO - 2018-11-27 14:01:44 --> File loaded: C:\xampp\htdocs\payment_example\application\views\payu_payment/confirmation.php
INFO - 2018-11-27 14:01:44 --> Final output sent to browser
DEBUG - 2018-11-27 14:01:44 --> Total execution time: 0.0630
INFO - 2018-11-27 14:01:44 --> Config Class Initialized
INFO - 2018-11-27 14:01:44 --> Hooks Class Initialized
DEBUG - 2018-11-27 14:01:44 --> UTF-8 Support Enabled
INFO - 2018-11-27 14:01:44 --> Utf8 Class Initialized
INFO - 2018-11-27 14:01:44 --> URI Class Initialized
INFO - 2018-11-27 14:01:44 --> Router Class Initialized
INFO - 2018-11-27 14:01:44 --> Output Class Initialized
INFO - 2018-11-27 14:01:44 --> Security Class Initialized
DEBUG - 2018-11-27 14:01:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-27 14:01:44 --> Input Class Initialized
INFO - 2018-11-27 14:01:44 --> Language Class Initialized
ERROR - 2018-11-27 14:01:44 --> 404 Page Not Found: Verify/favicon.png
INFO - 2018-11-27 14:02:38 --> Config Class Initialized
INFO - 2018-11-27 14:02:38 --> Hooks Class Initialized
DEBUG - 2018-11-27 14:02:38 --> UTF-8 Support Enabled
INFO - 2018-11-27 14:02:38 --> Utf8 Class Initialized
INFO - 2018-11-27 14:02:38 --> URI Class Initialized
INFO - 2018-11-27 14:02:38 --> Router Class Initialized
INFO - 2018-11-27 14:02:38 --> Output Class Initialized
INFO - 2018-11-27 14:02:38 --> Security Class Initialized
DEBUG - 2018-11-27 14:02:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-27 14:02:38 --> Input Class Initialized
INFO - 2018-11-27 14:02:38 --> Language Class Initialized
INFO - 2018-11-27 14:02:38 --> Loader Class Initialized
INFO - 2018-11-27 14:02:38 --> Helper loaded: url_helper
INFO - 2018-11-27 14:02:38 --> Helper loaded: file_helper
INFO - 2018-11-27 14:02:38 --> Helper loaded: email_helper
INFO - 2018-11-27 14:02:38 --> Helper loaded: common_helper
INFO - 2018-11-27 14:02:38 --> Database Driver Class Initialized
DEBUG - 2018-11-27 14:02:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-27 14:02:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-27 14:02:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-27 14:02:38 --> Pagination Class Initialized
INFO - 2018-11-27 14:02:38 --> Helper loaded: form_helper
INFO - 2018-11-27 14:02:38 --> Form Validation Class Initialized
INFO - 2018-11-27 14:02:38 --> Controller Class Initialized
INFO - 2018-11-27 14:02:38 --> File loaded: C:\xampp\htdocs\payment_example\application\views\payu_payment/success.php
INFO - 2018-11-27 14:02:38 --> Final output sent to browser
DEBUG - 2018-11-27 14:02:38 --> Total execution time: 0.0770
INFO - 2018-11-27 14:02:39 --> Config Class Initialized
INFO - 2018-11-27 14:02:39 --> Hooks Class Initialized
DEBUG - 2018-11-27 14:02:39 --> UTF-8 Support Enabled
INFO - 2018-11-27 14:02:39 --> Utf8 Class Initialized
INFO - 2018-11-27 14:02:39 --> URI Class Initialized
INFO - 2018-11-27 14:02:39 --> Router Class Initialized
INFO - 2018-11-27 14:02:39 --> Output Class Initialized
INFO - 2018-11-27 14:02:39 --> Security Class Initialized
DEBUG - 2018-11-27 14:02:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-27 14:02:39 --> Input Class Initialized
INFO - 2018-11-27 14:02:39 --> Language Class Initialized
ERROR - 2018-11-27 14:02:39 --> 404 Page Not Found: Img/favicon.png
INFO - 2018-11-27 14:04:56 --> Config Class Initialized
INFO - 2018-11-27 14:04:56 --> Hooks Class Initialized
DEBUG - 2018-11-27 14:04:56 --> UTF-8 Support Enabled
INFO - 2018-11-27 14:04:56 --> Utf8 Class Initialized
INFO - 2018-11-27 14:04:56 --> URI Class Initialized
INFO - 2018-11-27 14:04:56 --> Router Class Initialized
INFO - 2018-11-27 14:04:56 --> Output Class Initialized
INFO - 2018-11-27 14:04:56 --> Security Class Initialized
DEBUG - 2018-11-27 14:04:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-27 14:04:56 --> Input Class Initialized
INFO - 2018-11-27 14:04:56 --> Language Class Initialized
INFO - 2018-11-27 14:04:56 --> Loader Class Initialized
INFO - 2018-11-27 14:04:56 --> Helper loaded: url_helper
INFO - 2018-11-27 14:04:56 --> Helper loaded: file_helper
INFO - 2018-11-27 14:04:56 --> Helper loaded: email_helper
INFO - 2018-11-27 14:04:56 --> Helper loaded: common_helper
INFO - 2018-11-27 14:04:56 --> Database Driver Class Initialized
DEBUG - 2018-11-27 14:04:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-27 14:04:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-27 14:04:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-27 14:04:56 --> Pagination Class Initialized
INFO - 2018-11-27 14:04:56 --> Helper loaded: form_helper
INFO - 2018-11-27 14:04:56 --> Form Validation Class Initialized
INFO - 2018-11-27 14:04:56 --> Controller Class Initialized
INFO - 2018-11-27 14:04:56 --> File loaded: C:\xampp\htdocs\payment_example\application\views\payu_payment/success.php
INFO - 2018-11-27 14:04:56 --> Final output sent to browser
DEBUG - 2018-11-27 14:04:56 --> Total execution time: 0.0720
INFO - 2018-11-27 14:04:57 --> Config Class Initialized
INFO - 2018-11-27 14:04:57 --> Hooks Class Initialized
DEBUG - 2018-11-27 14:04:57 --> UTF-8 Support Enabled
INFO - 2018-11-27 14:04:57 --> Utf8 Class Initialized
INFO - 2018-11-27 14:04:57 --> URI Class Initialized
INFO - 2018-11-27 14:04:57 --> Router Class Initialized
INFO - 2018-11-27 14:04:57 --> Output Class Initialized
INFO - 2018-11-27 14:04:57 --> Security Class Initialized
DEBUG - 2018-11-27 14:04:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-27 14:04:57 --> Input Class Initialized
INFO - 2018-11-27 14:04:57 --> Language Class Initialized
ERROR - 2018-11-27 14:04:57 --> 404 Page Not Found: Img/favicon.png
INFO - 2018-11-27 14:05:15 --> Config Class Initialized
INFO - 2018-11-27 14:05:15 --> Hooks Class Initialized
DEBUG - 2018-11-27 14:05:15 --> UTF-8 Support Enabled
INFO - 2018-11-27 14:05:15 --> Utf8 Class Initialized
INFO - 2018-11-27 14:05:15 --> URI Class Initialized
INFO - 2018-11-27 14:05:15 --> Router Class Initialized
INFO - 2018-11-27 14:05:15 --> Output Class Initialized
INFO - 2018-11-27 14:05:15 --> Security Class Initialized
DEBUG - 2018-11-27 14:05:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-27 14:05:15 --> Input Class Initialized
INFO - 2018-11-27 14:05:15 --> Language Class Initialized
INFO - 2018-11-27 14:05:15 --> Loader Class Initialized
INFO - 2018-11-27 14:05:15 --> Helper loaded: url_helper
INFO - 2018-11-27 14:05:15 --> Helper loaded: file_helper
INFO - 2018-11-27 14:05:15 --> Helper loaded: email_helper
INFO - 2018-11-27 14:05:15 --> Helper loaded: common_helper
INFO - 2018-11-27 14:05:15 --> Database Driver Class Initialized
DEBUG - 2018-11-27 14:05:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-27 14:05:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-27 14:05:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-27 14:05:15 --> Pagination Class Initialized
INFO - 2018-11-27 14:05:15 --> Helper loaded: form_helper
INFO - 2018-11-27 14:05:15 --> Form Validation Class Initialized
INFO - 2018-11-27 14:05:15 --> Controller Class Initialized
INFO - 2018-11-27 14:05:15 --> File loaded: C:\xampp\htdocs\payment_example\application\views\payu_payment/success.php
INFO - 2018-11-27 14:05:15 --> Final output sent to browser
DEBUG - 2018-11-27 14:05:15 --> Total execution time: 0.0600
INFO - 2018-11-27 14:05:16 --> Config Class Initialized
INFO - 2018-11-27 14:05:16 --> Hooks Class Initialized
DEBUG - 2018-11-27 14:05:16 --> UTF-8 Support Enabled
INFO - 2018-11-27 14:05:16 --> Utf8 Class Initialized
INFO - 2018-11-27 14:05:16 --> URI Class Initialized
INFO - 2018-11-27 14:05:16 --> Router Class Initialized
INFO - 2018-11-27 14:05:16 --> Output Class Initialized
INFO - 2018-11-27 14:05:16 --> Security Class Initialized
DEBUG - 2018-11-27 14:05:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-27 14:05:16 --> Input Class Initialized
INFO - 2018-11-27 14:05:16 --> Language Class Initialized
ERROR - 2018-11-27 14:05:16 --> 404 Page Not Found: Img/favicon.png
INFO - 2018-11-27 14:06:22 --> Config Class Initialized
INFO - 2018-11-27 14:06:22 --> Hooks Class Initialized
DEBUG - 2018-11-27 14:06:22 --> UTF-8 Support Enabled
INFO - 2018-11-27 14:06:22 --> Utf8 Class Initialized
INFO - 2018-11-27 14:06:22 --> URI Class Initialized
INFO - 2018-11-27 14:06:22 --> Router Class Initialized
INFO - 2018-11-27 14:06:22 --> Output Class Initialized
INFO - 2018-11-27 14:06:22 --> Security Class Initialized
DEBUG - 2018-11-27 14:06:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-27 14:06:22 --> Input Class Initialized
INFO - 2018-11-27 14:06:22 --> Language Class Initialized
INFO - 2018-11-27 14:06:22 --> Loader Class Initialized
INFO - 2018-11-27 14:06:22 --> Helper loaded: url_helper
INFO - 2018-11-27 14:06:22 --> Helper loaded: file_helper
INFO - 2018-11-27 14:06:22 --> Helper loaded: email_helper
INFO - 2018-11-27 14:06:22 --> Helper loaded: common_helper
INFO - 2018-11-27 14:06:22 --> Database Driver Class Initialized
DEBUG - 2018-11-27 14:06:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-27 14:06:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-27 14:06:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-27 14:06:22 --> Pagination Class Initialized
INFO - 2018-11-27 14:06:22 --> Helper loaded: form_helper
INFO - 2018-11-27 14:06:22 --> Form Validation Class Initialized
INFO - 2018-11-27 14:06:22 --> Controller Class Initialized
INFO - 2018-11-27 14:06:22 --> File loaded: C:\xampp\htdocs\payment_example\application\views\payu_payment/success.php
INFO - 2018-11-27 14:06:22 --> Final output sent to browser
DEBUG - 2018-11-27 14:06:22 --> Total execution time: 0.0600
INFO - 2018-11-27 14:06:23 --> Config Class Initialized
INFO - 2018-11-27 14:06:23 --> Hooks Class Initialized
DEBUG - 2018-11-27 14:06:23 --> UTF-8 Support Enabled
INFO - 2018-11-27 14:06:23 --> Utf8 Class Initialized
INFO - 2018-11-27 14:06:23 --> URI Class Initialized
INFO - 2018-11-27 14:06:23 --> Router Class Initialized
INFO - 2018-11-27 14:06:23 --> Output Class Initialized
INFO - 2018-11-27 14:06:23 --> Security Class Initialized
DEBUG - 2018-11-27 14:06:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-27 14:06:23 --> Input Class Initialized
INFO - 2018-11-27 14:06:23 --> Language Class Initialized
ERROR - 2018-11-27 14:06:23 --> 404 Page Not Found: Img/favicon.png
INFO - 2018-11-27 14:06:40 --> Config Class Initialized
INFO - 2018-11-27 14:06:40 --> Hooks Class Initialized
DEBUG - 2018-11-27 14:06:40 --> UTF-8 Support Enabled
INFO - 2018-11-27 14:06:40 --> Utf8 Class Initialized
INFO - 2018-11-27 14:06:40 --> URI Class Initialized
INFO - 2018-11-27 14:06:40 --> Router Class Initialized
INFO - 2018-11-27 14:06:40 --> Output Class Initialized
INFO - 2018-11-27 14:06:40 --> Security Class Initialized
DEBUG - 2018-11-27 14:06:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-27 14:06:40 --> Input Class Initialized
INFO - 2018-11-27 14:06:40 --> Language Class Initialized
INFO - 2018-11-27 14:06:40 --> Loader Class Initialized
INFO - 2018-11-27 14:06:40 --> Helper loaded: url_helper
INFO - 2018-11-27 14:06:40 --> Helper loaded: file_helper
INFO - 2018-11-27 14:06:40 --> Helper loaded: email_helper
INFO - 2018-11-27 14:06:40 --> Helper loaded: common_helper
INFO - 2018-11-27 14:06:40 --> Database Driver Class Initialized
DEBUG - 2018-11-27 14:06:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-27 14:06:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-27 14:06:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-27 14:06:40 --> Pagination Class Initialized
INFO - 2018-11-27 14:06:40 --> Helper loaded: form_helper
INFO - 2018-11-27 14:06:40 --> Form Validation Class Initialized
INFO - 2018-11-27 14:06:40 --> Controller Class Initialized
INFO - 2018-11-27 14:06:40 --> File loaded: C:\xampp\htdocs\payment_example\application\views\payu_payment/success.php
INFO - 2018-11-27 14:06:40 --> Final output sent to browser
DEBUG - 2018-11-27 14:06:40 --> Total execution time: 0.0640
INFO - 2018-11-27 14:06:41 --> Config Class Initialized
INFO - 2018-11-27 14:06:41 --> Hooks Class Initialized
DEBUG - 2018-11-27 14:06:41 --> UTF-8 Support Enabled
INFO - 2018-11-27 14:06:41 --> Utf8 Class Initialized
INFO - 2018-11-27 14:06:41 --> URI Class Initialized
INFO - 2018-11-27 14:06:41 --> Router Class Initialized
INFO - 2018-11-27 14:06:41 --> Output Class Initialized
INFO - 2018-11-27 14:06:41 --> Security Class Initialized
DEBUG - 2018-11-27 14:06:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-27 14:06:41 --> Input Class Initialized
INFO - 2018-11-27 14:06:41 --> Language Class Initialized
ERROR - 2018-11-27 14:06:42 --> 404 Page Not Found: Img/favicon.png
INFO - 2018-11-27 14:08:01 --> Config Class Initialized
INFO - 2018-11-27 14:08:01 --> Hooks Class Initialized
DEBUG - 2018-11-27 14:08:01 --> UTF-8 Support Enabled
INFO - 2018-11-27 14:08:01 --> Utf8 Class Initialized
INFO - 2018-11-27 14:08:01 --> URI Class Initialized
INFO - 2018-11-27 14:08:01 --> Router Class Initialized
INFO - 2018-11-27 14:08:01 --> Output Class Initialized
INFO - 2018-11-27 14:08:01 --> Security Class Initialized
DEBUG - 2018-11-27 14:08:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-27 14:08:01 --> Input Class Initialized
INFO - 2018-11-27 14:08:01 --> Language Class Initialized
INFO - 2018-11-27 14:08:01 --> Loader Class Initialized
INFO - 2018-11-27 14:08:01 --> Helper loaded: url_helper
INFO - 2018-11-27 14:08:01 --> Helper loaded: file_helper
INFO - 2018-11-27 14:08:01 --> Helper loaded: email_helper
INFO - 2018-11-27 14:08:01 --> Helper loaded: common_helper
INFO - 2018-11-27 14:08:01 --> Database Driver Class Initialized
DEBUG - 2018-11-27 14:08:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-27 14:08:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-27 14:08:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-27 14:08:01 --> Pagination Class Initialized
INFO - 2018-11-27 14:08:01 --> Helper loaded: form_helper
INFO - 2018-11-27 14:08:01 --> Form Validation Class Initialized
INFO - 2018-11-27 14:08:01 --> Controller Class Initialized
INFO - 2018-11-27 14:08:01 --> File loaded: C:\xampp\htdocs\payment_example\application\views\payu_payment/success.php
INFO - 2018-11-27 14:08:01 --> Final output sent to browser
DEBUG - 2018-11-27 14:08:01 --> Total execution time: 0.0650
INFO - 2018-11-27 14:10:18 --> Config Class Initialized
INFO - 2018-11-27 14:10:18 --> Hooks Class Initialized
DEBUG - 2018-11-27 14:10:18 --> UTF-8 Support Enabled
INFO - 2018-11-27 14:10:18 --> Utf8 Class Initialized
INFO - 2018-11-27 14:10:18 --> URI Class Initialized
INFO - 2018-11-27 14:10:18 --> Router Class Initialized
INFO - 2018-11-27 14:10:18 --> Output Class Initialized
INFO - 2018-11-27 14:10:18 --> Security Class Initialized
DEBUG - 2018-11-27 14:10:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-27 14:10:18 --> Input Class Initialized
INFO - 2018-11-27 14:10:18 --> Language Class Initialized
INFO - 2018-11-27 14:10:18 --> Loader Class Initialized
INFO - 2018-11-27 14:10:18 --> Helper loaded: url_helper
INFO - 2018-11-27 14:10:18 --> Helper loaded: file_helper
INFO - 2018-11-27 14:10:18 --> Helper loaded: email_helper
INFO - 2018-11-27 14:10:18 --> Helper loaded: common_helper
INFO - 2018-11-27 14:10:18 --> Database Driver Class Initialized
DEBUG - 2018-11-27 14:10:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-27 14:10:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-27 14:10:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-27 14:10:18 --> Pagination Class Initialized
INFO - 2018-11-27 14:10:18 --> Helper loaded: form_helper
INFO - 2018-11-27 14:10:18 --> Form Validation Class Initialized
INFO - 2018-11-27 14:10:18 --> Controller Class Initialized
INFO - 2018-11-27 14:10:18 --> File loaded: C:\xampp\htdocs\payment_example\application\views\payu_payment/success.php
INFO - 2018-11-27 14:10:18 --> Final output sent to browser
DEBUG - 2018-11-27 14:10:18 --> Total execution time: 0.0620
INFO - 2018-11-27 14:10:19 --> Config Class Initialized
INFO - 2018-11-27 14:10:19 --> Hooks Class Initialized
DEBUG - 2018-11-27 14:10:19 --> UTF-8 Support Enabled
INFO - 2018-11-27 14:10:19 --> Utf8 Class Initialized
INFO - 2018-11-27 14:10:19 --> URI Class Initialized
INFO - 2018-11-27 14:10:19 --> Router Class Initialized
INFO - 2018-11-27 14:10:19 --> Output Class Initialized
INFO - 2018-11-27 14:10:19 --> Security Class Initialized
DEBUG - 2018-11-27 14:10:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-27 14:10:19 --> Input Class Initialized
INFO - 2018-11-27 14:10:19 --> Language Class Initialized
ERROR - 2018-11-27 14:10:19 --> 404 Page Not Found: Img/favicon.png
INFO - 2018-11-27 14:14:37 --> Config Class Initialized
INFO - 2018-11-27 14:14:37 --> Hooks Class Initialized
DEBUG - 2018-11-27 14:14:37 --> UTF-8 Support Enabled
INFO - 2018-11-27 14:14:37 --> Utf8 Class Initialized
INFO - 2018-11-27 14:14:37 --> URI Class Initialized
DEBUG - 2018-11-27 14:14:37 --> No URI present. Default controller set.
INFO - 2018-11-27 14:14:37 --> Router Class Initialized
INFO - 2018-11-27 14:14:37 --> Output Class Initialized
INFO - 2018-11-27 14:14:37 --> Security Class Initialized
DEBUG - 2018-11-27 14:14:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-27 14:14:37 --> Input Class Initialized
INFO - 2018-11-27 14:14:37 --> Language Class Initialized
INFO - 2018-11-27 14:14:37 --> Loader Class Initialized
INFO - 2018-11-27 14:14:37 --> Helper loaded: url_helper
INFO - 2018-11-27 14:14:37 --> Helper loaded: file_helper
INFO - 2018-11-27 14:14:37 --> Helper loaded: email_helper
INFO - 2018-11-27 14:14:37 --> Helper loaded: common_helper
INFO - 2018-11-27 14:14:37 --> Database Driver Class Initialized
DEBUG - 2018-11-27 14:14:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-27 14:14:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-27 14:14:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-27 14:14:37 --> Pagination Class Initialized
INFO - 2018-11-27 14:14:37 --> Helper loaded: form_helper
INFO - 2018-11-27 14:14:37 --> Form Validation Class Initialized
INFO - 2018-11-27 14:14:37 --> Controller Class Initialized
INFO - 2018-11-27 14:14:37 --> File loaded: C:\xampp\htdocs\payment_example\application\views\payu_payment/index.php
INFO - 2018-11-27 14:14:37 --> Final output sent to browser
DEBUG - 2018-11-27 14:14:37 --> Total execution time: 0.0760
INFO - 2018-11-27 14:14:40 --> Config Class Initialized
INFO - 2018-11-27 14:14:40 --> Hooks Class Initialized
DEBUG - 2018-11-27 14:14:40 --> UTF-8 Support Enabled
INFO - 2018-11-27 14:14:40 --> Utf8 Class Initialized
INFO - 2018-11-27 14:14:40 --> URI Class Initialized
INFO - 2018-11-27 14:14:40 --> Router Class Initialized
INFO - 2018-11-27 14:14:40 --> Output Class Initialized
INFO - 2018-11-27 14:14:40 --> Security Class Initialized
DEBUG - 2018-11-27 14:14:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-27 14:14:40 --> Input Class Initialized
INFO - 2018-11-27 14:14:40 --> Language Class Initialized
INFO - 2018-11-27 14:14:40 --> Loader Class Initialized
INFO - 2018-11-27 14:14:40 --> Helper loaded: url_helper
INFO - 2018-11-27 14:14:40 --> Helper loaded: file_helper
INFO - 2018-11-27 14:14:40 --> Helper loaded: email_helper
INFO - 2018-11-27 14:14:40 --> Helper loaded: common_helper
INFO - 2018-11-27 14:14:40 --> Database Driver Class Initialized
DEBUG - 2018-11-27 14:14:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-27 14:14:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-27 14:14:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-27 14:14:40 --> Pagination Class Initialized
INFO - 2018-11-27 14:14:40 --> Helper loaded: form_helper
INFO - 2018-11-27 14:14:40 --> Form Validation Class Initialized
INFO - 2018-11-27 14:14:40 --> Controller Class Initialized
INFO - 2018-11-27 14:14:40 --> File loaded: C:\xampp\htdocs\payment_example\application\views\payu_payment/confirmation.php
INFO - 2018-11-27 14:14:40 --> Final output sent to browser
DEBUG - 2018-11-27 14:14:40 --> Total execution time: 0.0600
INFO - 2018-11-27 14:14:41 --> Config Class Initialized
INFO - 2018-11-27 14:14:41 --> Hooks Class Initialized
DEBUG - 2018-11-27 14:14:41 --> UTF-8 Support Enabled
INFO - 2018-11-27 14:14:41 --> Utf8 Class Initialized
INFO - 2018-11-27 14:14:41 --> URI Class Initialized
INFO - 2018-11-27 14:14:41 --> Router Class Initialized
INFO - 2018-11-27 14:14:41 --> Output Class Initialized
INFO - 2018-11-27 14:14:41 --> Security Class Initialized
DEBUG - 2018-11-27 14:14:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-27 14:14:41 --> Input Class Initialized
INFO - 2018-11-27 14:14:41 --> Language Class Initialized
ERROR - 2018-11-27 14:14:41 --> 404 Page Not Found: Verify/favicon.png
INFO - 2018-11-27 14:14:58 --> Config Class Initialized
INFO - 2018-11-27 14:14:58 --> Hooks Class Initialized
DEBUG - 2018-11-27 14:14:58 --> UTF-8 Support Enabled
INFO - 2018-11-27 14:14:58 --> Utf8 Class Initialized
INFO - 2018-11-27 14:14:58 --> URI Class Initialized
INFO - 2018-11-27 14:14:58 --> Router Class Initialized
INFO - 2018-11-27 14:14:58 --> Output Class Initialized
INFO - 2018-11-27 14:14:58 --> Security Class Initialized
DEBUG - 2018-11-27 14:14:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-27 14:14:58 --> Input Class Initialized
INFO - 2018-11-27 14:14:58 --> Language Class Initialized
INFO - 2018-11-27 14:14:58 --> Loader Class Initialized
INFO - 2018-11-27 14:14:58 --> Helper loaded: url_helper
INFO - 2018-11-27 14:14:58 --> Helper loaded: file_helper
INFO - 2018-11-27 14:14:58 --> Helper loaded: email_helper
INFO - 2018-11-27 14:14:58 --> Helper loaded: common_helper
INFO - 2018-11-27 14:14:58 --> Database Driver Class Initialized
DEBUG - 2018-11-27 14:14:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-27 14:14:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-27 14:14:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-27 14:14:58 --> Pagination Class Initialized
INFO - 2018-11-27 14:14:58 --> Helper loaded: form_helper
INFO - 2018-11-27 14:14:58 --> Form Validation Class Initialized
INFO - 2018-11-27 14:14:58 --> Controller Class Initialized
INFO - 2018-11-27 14:14:58 --> File loaded: C:\xampp\htdocs\payment_example\application\views\payu_payment/fail.php
INFO - 2018-11-27 14:14:58 --> Final output sent to browser
DEBUG - 2018-11-27 14:14:58 --> Total execution time: 0.1130
INFO - 2018-11-27 14:15:07 --> Config Class Initialized
INFO - 2018-11-27 14:15:07 --> Hooks Class Initialized
DEBUG - 2018-11-27 14:15:07 --> UTF-8 Support Enabled
INFO - 2018-11-27 14:15:07 --> Utf8 Class Initialized
INFO - 2018-11-27 14:15:07 --> URI Class Initialized
DEBUG - 2018-11-27 14:15:07 --> No URI present. Default controller set.
INFO - 2018-11-27 14:15:07 --> Router Class Initialized
INFO - 2018-11-27 14:15:07 --> Output Class Initialized
INFO - 2018-11-27 14:15:07 --> Security Class Initialized
DEBUG - 2018-11-27 14:15:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-27 14:15:07 --> Input Class Initialized
INFO - 2018-11-27 14:15:07 --> Language Class Initialized
INFO - 2018-11-27 14:15:07 --> Loader Class Initialized
INFO - 2018-11-27 14:15:07 --> Helper loaded: url_helper
INFO - 2018-11-27 14:15:07 --> Helper loaded: file_helper
INFO - 2018-11-27 14:15:07 --> Helper loaded: email_helper
INFO - 2018-11-27 14:15:07 --> Helper loaded: common_helper
INFO - 2018-11-27 14:15:07 --> Database Driver Class Initialized
DEBUG - 2018-11-27 14:15:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-27 14:15:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-27 14:15:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-27 14:15:07 --> Pagination Class Initialized
INFO - 2018-11-27 14:15:07 --> Helper loaded: form_helper
INFO - 2018-11-27 14:15:07 --> Form Validation Class Initialized
INFO - 2018-11-27 14:15:07 --> Controller Class Initialized
INFO - 2018-11-27 14:15:07 --> File loaded: C:\xampp\htdocs\payment_example\application\views\payu_payment/index.php
INFO - 2018-11-27 14:15:07 --> Final output sent to browser
DEBUG - 2018-11-27 14:15:07 --> Total execution time: 0.0670
INFO - 2018-11-27 14:16:23 --> Config Class Initialized
INFO - 2018-11-27 14:16:23 --> Hooks Class Initialized
DEBUG - 2018-11-27 14:16:23 --> UTF-8 Support Enabled
INFO - 2018-11-27 14:16:23 --> Utf8 Class Initialized
INFO - 2018-11-27 14:16:23 --> URI Class Initialized
INFO - 2018-11-27 14:16:23 --> Router Class Initialized
INFO - 2018-11-27 14:16:23 --> Output Class Initialized
INFO - 2018-11-27 14:16:23 --> Security Class Initialized
DEBUG - 2018-11-27 14:16:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-27 14:16:23 --> Input Class Initialized
INFO - 2018-11-27 14:16:23 --> Language Class Initialized
INFO - 2018-11-27 14:16:23 --> Loader Class Initialized
INFO - 2018-11-27 14:16:23 --> Helper loaded: url_helper
INFO - 2018-11-27 14:16:23 --> Helper loaded: file_helper
INFO - 2018-11-27 14:16:23 --> Helper loaded: email_helper
INFO - 2018-11-27 14:16:23 --> Helper loaded: common_helper
INFO - 2018-11-27 14:16:23 --> Database Driver Class Initialized
DEBUG - 2018-11-27 14:16:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-27 14:16:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-27 14:16:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-27 14:16:23 --> Pagination Class Initialized
INFO - 2018-11-27 14:16:23 --> Helper loaded: form_helper
INFO - 2018-11-27 14:16:23 --> Form Validation Class Initialized
INFO - 2018-11-27 14:16:23 --> Controller Class Initialized
INFO - 2018-11-27 14:16:23 --> File loaded: C:\xampp\htdocs\payment_example\application\views\payu_payment/confirmation.php
INFO - 2018-11-27 14:16:23 --> Final output sent to browser
DEBUG - 2018-11-27 14:16:23 --> Total execution time: 0.0650
INFO - 2018-11-27 14:17:00 --> Config Class Initialized
INFO - 2018-11-27 14:17:00 --> Hooks Class Initialized
DEBUG - 2018-11-27 14:17:00 --> UTF-8 Support Enabled
INFO - 2018-11-27 14:17:00 --> Utf8 Class Initialized
INFO - 2018-11-27 14:17:00 --> URI Class Initialized
INFO - 2018-11-27 14:17:00 --> Router Class Initialized
INFO - 2018-11-27 14:17:00 --> Output Class Initialized
INFO - 2018-11-27 14:17:00 --> Security Class Initialized
DEBUG - 2018-11-27 14:17:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-27 14:17:00 --> Input Class Initialized
INFO - 2018-11-27 14:17:00 --> Language Class Initialized
INFO - 2018-11-27 14:17:00 --> Loader Class Initialized
INFO - 2018-11-27 14:17:00 --> Helper loaded: url_helper
INFO - 2018-11-27 14:17:00 --> Helper loaded: file_helper
INFO - 2018-11-27 14:17:00 --> Helper loaded: email_helper
INFO - 2018-11-27 14:17:00 --> Helper loaded: common_helper
INFO - 2018-11-27 14:17:00 --> Database Driver Class Initialized
DEBUG - 2018-11-27 14:17:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-27 14:17:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-27 14:17:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-27 14:17:00 --> Pagination Class Initialized
INFO - 2018-11-27 14:17:00 --> Helper loaded: form_helper
INFO - 2018-11-27 14:17:00 --> Form Validation Class Initialized
INFO - 2018-11-27 14:17:00 --> Controller Class Initialized
INFO - 2018-11-27 14:17:00 --> File loaded: C:\xampp\htdocs\payment_example\application\views\payu_payment/fail.php
INFO - 2018-11-27 14:17:00 --> Final output sent to browser
DEBUG - 2018-11-27 14:17:00 --> Total execution time: 0.1800
INFO - 2018-11-27 14:21:20 --> Config Class Initialized
INFO - 2018-11-27 14:21:20 --> Hooks Class Initialized
DEBUG - 2018-11-27 14:21:20 --> UTF-8 Support Enabled
INFO - 2018-11-27 14:21:20 --> Utf8 Class Initialized
INFO - 2018-11-27 14:21:20 --> URI Class Initialized
DEBUG - 2018-11-27 14:21:20 --> No URI present. Default controller set.
INFO - 2018-11-27 14:21:20 --> Router Class Initialized
INFO - 2018-11-27 14:21:20 --> Output Class Initialized
INFO - 2018-11-27 14:21:20 --> Security Class Initialized
DEBUG - 2018-11-27 14:21:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-27 14:21:20 --> Input Class Initialized
INFO - 2018-11-27 14:21:20 --> Language Class Initialized
INFO - 2018-11-27 14:21:20 --> Loader Class Initialized
INFO - 2018-11-27 14:21:20 --> Helper loaded: url_helper
INFO - 2018-11-27 14:21:20 --> Helper loaded: file_helper
INFO - 2018-11-27 14:21:20 --> Helper loaded: email_helper
INFO - 2018-11-27 14:21:20 --> Helper loaded: common_helper
INFO - 2018-11-27 14:21:20 --> Database Driver Class Initialized
DEBUG - 2018-11-27 14:21:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-27 14:21:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-27 14:21:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-27 14:21:20 --> Pagination Class Initialized
INFO - 2018-11-27 14:21:20 --> Helper loaded: form_helper
INFO - 2018-11-27 14:21:20 --> Form Validation Class Initialized
INFO - 2018-11-27 14:21:20 --> Controller Class Initialized
INFO - 2018-11-27 14:21:20 --> File loaded: C:\xampp\htdocs\payment_example\application\views\payu_payment/index.php
INFO - 2018-11-27 14:21:20 --> Final output sent to browser
DEBUG - 2018-11-27 14:21:20 --> Total execution time: 0.0690

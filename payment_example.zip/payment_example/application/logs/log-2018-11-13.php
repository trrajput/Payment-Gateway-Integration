<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2018-11-13 08:07:32 --> Config Class Initialized
INFO - 2018-11-13 08:07:32 --> Hooks Class Initialized
DEBUG - 2018-11-13 08:07:32 --> UTF-8 Support Enabled
INFO - 2018-11-13 08:07:32 --> Utf8 Class Initialized
INFO - 2018-11-13 08:07:32 --> URI Class Initialized
DEBUG - 2018-11-13 08:07:32 --> No URI present. Default controller set.
INFO - 2018-11-13 08:07:32 --> Router Class Initialized
INFO - 2018-11-13 08:07:32 --> Output Class Initialized
INFO - 2018-11-13 08:07:32 --> Security Class Initialized
DEBUG - 2018-11-13 08:07:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-13 08:07:32 --> Input Class Initialized
INFO - 2018-11-13 08:07:32 --> Language Class Initialized
INFO - 2018-11-13 08:07:32 --> Loader Class Initialized
INFO - 2018-11-13 08:07:32 --> Helper loaded: url_helper
INFO - 2018-11-13 08:07:32 --> Helper loaded: file_helper
INFO - 2018-11-13 08:07:32 --> Helper loaded: email_helper
INFO - 2018-11-13 08:07:32 --> Helper loaded: common_helper
INFO - 2018-11-13 08:07:32 --> Database Driver Class Initialized
DEBUG - 2018-11-13 08:07:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-13 08:07:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-13 08:07:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-13 08:07:32 --> Pagination Class Initialized
INFO - 2018-11-13 08:07:32 --> Helper loaded: form_helper
INFO - 2018-11-13 08:07:32 --> Form Validation Class Initialized
INFO - 2018-11-13 08:07:32 --> Model Class Initialized
INFO - 2018-11-13 08:07:32 --> Controller Class Initialized
INFO - 2018-11-13 08:07:32 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-13 08:07:32 --> Model Class Initialized
INFO - 2018-11-13 08:07:32 --> Model Class Initialized
INFO - 2018-11-13 08:07:32 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\index/index.php
INFO - 2018-11-13 08:07:32 --> Final output sent to browser
DEBUG - 2018-11-13 08:07:32 --> Total execution time: 0.0540
INFO - 2018-11-13 08:08:49 --> Config Class Initialized
INFO - 2018-11-13 08:08:49 --> Hooks Class Initialized
DEBUG - 2018-11-13 08:08:49 --> UTF-8 Support Enabled
INFO - 2018-11-13 08:08:49 --> Utf8 Class Initialized
INFO - 2018-11-13 08:08:49 --> URI Class Initialized
DEBUG - 2018-11-13 08:08:49 --> No URI present. Default controller set.
INFO - 2018-11-13 08:08:49 --> Router Class Initialized
INFO - 2018-11-13 08:08:49 --> Output Class Initialized
INFO - 2018-11-13 08:08:49 --> Security Class Initialized
DEBUG - 2018-11-13 08:08:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-13 08:08:49 --> Input Class Initialized
INFO - 2018-11-13 08:08:49 --> Language Class Initialized
INFO - 2018-11-13 08:08:49 --> Loader Class Initialized
INFO - 2018-11-13 08:08:49 --> Helper loaded: url_helper
INFO - 2018-11-13 08:08:49 --> Helper loaded: file_helper
INFO - 2018-11-13 08:08:49 --> Helper loaded: email_helper
INFO - 2018-11-13 08:08:49 --> Helper loaded: common_helper
INFO - 2018-11-13 08:08:49 --> Database Driver Class Initialized
DEBUG - 2018-11-13 08:08:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-13 08:08:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-13 08:08:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-13 08:08:49 --> Pagination Class Initialized
INFO - 2018-11-13 08:08:49 --> Helper loaded: form_helper
INFO - 2018-11-13 08:08:49 --> Form Validation Class Initialized
INFO - 2018-11-13 08:08:49 --> Model Class Initialized
INFO - 2018-11-13 08:08:49 --> Controller Class Initialized
INFO - 2018-11-13 08:08:49 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-13 08:08:49 --> Model Class Initialized
INFO - 2018-11-13 08:08:49 --> Model Class Initialized
INFO - 2018-11-13 08:08:49 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\index/index.php
INFO - 2018-11-13 08:08:49 --> Final output sent to browser
DEBUG - 2018-11-13 08:08:49 --> Total execution time: 0.0450
INFO - 2018-11-13 08:23:16 --> Config Class Initialized
INFO - 2018-11-13 08:23:16 --> Hooks Class Initialized
DEBUG - 2018-11-13 08:23:16 --> UTF-8 Support Enabled
INFO - 2018-11-13 08:23:16 --> Utf8 Class Initialized
INFO - 2018-11-13 08:23:16 --> URI Class Initialized
DEBUG - 2018-11-13 08:23:16 --> No URI present. Default controller set.
INFO - 2018-11-13 08:23:16 --> Router Class Initialized
INFO - 2018-11-13 08:23:16 --> Output Class Initialized
INFO - 2018-11-13 08:23:16 --> Security Class Initialized
DEBUG - 2018-11-13 08:23:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-13 08:23:16 --> Input Class Initialized
INFO - 2018-11-13 08:23:16 --> Language Class Initialized
INFO - 2018-11-13 08:23:16 --> Loader Class Initialized
INFO - 2018-11-13 08:23:16 --> Helper loaded: url_helper
INFO - 2018-11-13 08:23:16 --> Helper loaded: file_helper
INFO - 2018-11-13 08:23:16 --> Helper loaded: email_helper
INFO - 2018-11-13 08:23:16 --> Helper loaded: common_helper
INFO - 2018-11-13 08:23:16 --> Database Driver Class Initialized
DEBUG - 2018-11-13 08:23:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-13 08:23:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-13 08:23:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-13 08:23:16 --> Pagination Class Initialized
INFO - 2018-11-13 08:23:16 --> Helper loaded: form_helper
INFO - 2018-11-13 08:23:16 --> Form Validation Class Initialized
INFO - 2018-11-13 08:23:16 --> Model Class Initialized
INFO - 2018-11-13 08:23:16 --> Controller Class Initialized
INFO - 2018-11-13 08:23:16 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-13 08:23:16 --> Model Class Initialized
INFO - 2018-11-13 08:23:16 --> Model Class Initialized
INFO - 2018-11-13 08:23:16 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\index.php
INFO - 2018-11-13 08:23:16 --> Final output sent to browser
DEBUG - 2018-11-13 08:23:16 --> Total execution time: 0.0450
INFO - 2018-11-13 08:23:16 --> Config Class Initialized
INFO - 2018-11-13 08:23:16 --> Hooks Class Initialized
DEBUG - 2018-11-13 08:23:16 --> UTF-8 Support Enabled
INFO - 2018-11-13 08:23:16 --> Utf8 Class Initialized
INFO - 2018-11-13 08:23:16 --> URI Class Initialized
INFO - 2018-11-13 08:23:16 --> Router Class Initialized
INFO - 2018-11-13 08:23:16 --> Output Class Initialized
INFO - 2018-11-13 08:23:16 --> Security Class Initialized
DEBUG - 2018-11-13 08:23:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-13 08:23:16 --> Input Class Initialized
INFO - 2018-11-13 08:23:16 --> Language Class Initialized
ERROR - 2018-11-13 08:23:16 --> 404 Page Not Found: Plugins/owl-carousel
INFO - 2018-11-13 08:23:16 --> Config Class Initialized
INFO - 2018-11-13 08:23:16 --> Hooks Class Initialized
DEBUG - 2018-11-13 08:23:16 --> UTF-8 Support Enabled
INFO - 2018-11-13 08:23:16 --> Utf8 Class Initialized
INFO - 2018-11-13 08:23:16 --> URI Class Initialized
INFO - 2018-11-13 08:23:16 --> Router Class Initialized
INFO - 2018-11-13 08:23:16 --> Output Class Initialized
INFO - 2018-11-13 08:23:16 --> Security Class Initialized
DEBUG - 2018-11-13 08:23:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-13 08:23:16 --> Input Class Initialized
INFO - 2018-11-13 08:23:16 --> Language Class Initialized
ERROR - 2018-11-13 08:23:16 --> 404 Page Not Found: Plugins/arcticmodal
INFO - 2018-11-13 08:23:17 --> Config Class Initialized
INFO - 2018-11-13 08:23:17 --> Hooks Class Initialized
DEBUG - 2018-11-13 08:23:17 --> UTF-8 Support Enabled
INFO - 2018-11-13 08:23:17 --> Utf8 Class Initialized
INFO - 2018-11-13 08:23:17 --> URI Class Initialized
INFO - 2018-11-13 08:23:17 --> Router Class Initialized
INFO - 2018-11-13 08:23:17 --> Output Class Initialized
INFO - 2018-11-13 08:23:17 --> Security Class Initialized
DEBUG - 2018-11-13 08:23:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-13 08:23:17 --> Input Class Initialized
INFO - 2018-11-13 08:23:17 --> Language Class Initialized
ERROR - 2018-11-13 08:23:17 --> 404 Page Not Found: Plugins/wt.validator.min.js
INFO - 2018-11-13 08:23:17 --> Config Class Initialized
INFO - 2018-11-13 08:23:17 --> Hooks Class Initialized
DEBUG - 2018-11-13 08:23:17 --> UTF-8 Support Enabled
INFO - 2018-11-13 08:23:17 --> Utf8 Class Initialized
INFO - 2018-11-13 08:23:17 --> URI Class Initialized
INFO - 2018-11-13 08:23:17 --> Router Class Initialized
INFO - 2018-11-13 08:23:17 --> Output Class Initialized
INFO - 2018-11-13 08:23:17 --> Security Class Initialized
DEBUG - 2018-11-13 08:23:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-13 08:23:17 --> Input Class Initialized
INFO - 2018-11-13 08:23:17 --> Language Class Initialized
ERROR - 2018-11-13 08:23:17 --> 404 Page Not Found: Plugins/wt.jquery.nav.1.0.js
INFO - 2018-11-13 08:23:17 --> Config Class Initialized
INFO - 2018-11-13 08:23:17 --> Hooks Class Initialized
DEBUG - 2018-11-13 08:23:17 --> UTF-8 Support Enabled
INFO - 2018-11-13 08:23:17 --> Utf8 Class Initialized
INFO - 2018-11-13 08:23:17 --> URI Class Initialized
INFO - 2018-11-13 08:23:17 --> Router Class Initialized
INFO - 2018-11-13 08:23:17 --> Output Class Initialized
INFO - 2018-11-13 08:23:17 --> Security Class Initialized
DEBUG - 2018-11-13 08:23:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-13 08:23:17 --> Input Class Initialized
INFO - 2018-11-13 08:23:17 --> Language Class Initialized
ERROR - 2018-11-13 08:23:17 --> 404 Page Not Found: Plugins/wt.validator.min.js
INFO - 2018-11-13 08:23:17 --> Config Class Initialized
INFO - 2018-11-13 08:23:17 --> Hooks Class Initialized
DEBUG - 2018-11-13 08:23:17 --> UTF-8 Support Enabled
INFO - 2018-11-13 08:23:17 --> Utf8 Class Initialized
INFO - 2018-11-13 08:23:17 --> URI Class Initialized
INFO - 2018-11-13 08:23:17 --> Router Class Initialized
INFO - 2018-11-13 08:23:17 --> Output Class Initialized
INFO - 2018-11-13 08:23:17 --> Security Class Initialized
DEBUG - 2018-11-13 08:23:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-13 08:23:17 --> Input Class Initialized
INFO - 2018-11-13 08:23:17 --> Language Class Initialized
INFO - 2018-11-13 08:23:17 --> Config Class Initialized
INFO - 2018-11-13 08:23:17 --> Config Class Initialized
ERROR - 2018-11-13 08:23:17 --> 404 Page Not Found: Plugins/mad.customselect.js
INFO - 2018-11-13 08:23:17 --> Hooks Class Initialized
INFO - 2018-11-13 08:23:17 --> Config Class Initialized
INFO - 2018-11-13 08:23:17 --> Hooks Class Initialized
DEBUG - 2018-11-13 08:23:17 --> UTF-8 Support Enabled
INFO - 2018-11-13 08:23:17 --> Hooks Class Initialized
DEBUG - 2018-11-13 08:23:17 --> UTF-8 Support Enabled
INFO - 2018-11-13 08:23:17 --> Utf8 Class Initialized
DEBUG - 2018-11-13 08:23:17 --> UTF-8 Support Enabled
INFO - 2018-11-13 08:23:17 --> Utf8 Class Initialized
INFO - 2018-11-13 08:23:17 --> URI Class Initialized
INFO - 2018-11-13 08:23:17 --> Utf8 Class Initialized
INFO - 2018-11-13 08:23:17 --> URI Class Initialized
INFO - 2018-11-13 08:23:17 --> Router Class Initialized
INFO - 2018-11-13 08:23:17 --> URI Class Initialized
INFO - 2018-11-13 08:23:17 --> Router Class Initialized
INFO - 2018-11-13 08:23:17 --> Router Class Initialized
INFO - 2018-11-13 08:23:17 --> Output Class Initialized
INFO - 2018-11-13 08:23:17 --> Output Class Initialized
INFO - 2018-11-13 08:23:17 --> Output Class Initialized
INFO - 2018-11-13 08:23:17 --> Security Class Initialized
INFO - 2018-11-13 08:23:17 --> Security Class Initialized
INFO - 2018-11-13 08:23:17 --> Security Class Initialized
DEBUG - 2018-11-13 08:23:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-11-13 08:23:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-11-13 08:23:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-13 08:23:17 --> Input Class Initialized
INFO - 2018-11-13 08:23:17 --> Input Class Initialized
INFO - 2018-11-13 08:23:17 --> Input Class Initialized
INFO - 2018-11-13 08:23:17 --> Language Class Initialized
INFO - 2018-11-13 08:23:17 --> Language Class Initialized
INFO - 2018-11-13 08:23:17 --> Language Class Initialized
ERROR - 2018-11-13 08:23:17 --> 404 Page Not Found: Plugins/retina.min.js
ERROR - 2018-11-13 08:23:17 --> 404 Page Not Found: Plugins/arcticmodal
ERROR - 2018-11-13 08:23:17 --> 404 Page Not Found: Plugins/owl-carousel
INFO - 2018-11-13 08:23:17 --> Config Class Initialized
INFO - 2018-11-13 08:23:17 --> Hooks Class Initialized
DEBUG - 2018-11-13 08:23:17 --> UTF-8 Support Enabled
INFO - 2018-11-13 08:23:17 --> Utf8 Class Initialized
INFO - 2018-11-13 08:23:17 --> URI Class Initialized
INFO - 2018-11-13 08:23:17 --> Router Class Initialized
INFO - 2018-11-13 08:23:17 --> Output Class Initialized
INFO - 2018-11-13 08:23:17 --> Security Class Initialized
DEBUG - 2018-11-13 08:23:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-13 08:23:17 --> Input Class Initialized
INFO - 2018-11-13 08:23:17 --> Language Class Initialized
ERROR - 2018-11-13 08:23:17 --> 404 Page Not Found: Plugins/wt.jquery.nav.1.0.js
INFO - 2018-11-13 08:23:17 --> Config Class Initialized
INFO - 2018-11-13 08:23:17 --> Hooks Class Initialized
DEBUG - 2018-11-13 08:23:17 --> UTF-8 Support Enabled
INFO - 2018-11-13 08:23:17 --> Utf8 Class Initialized
INFO - 2018-11-13 08:23:17 --> URI Class Initialized
INFO - 2018-11-13 08:23:17 --> Router Class Initialized
INFO - 2018-11-13 08:23:17 --> Output Class Initialized
INFO - 2018-11-13 08:23:17 --> Security Class Initialized
DEBUG - 2018-11-13 08:23:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-13 08:23:17 --> Input Class Initialized
INFO - 2018-11-13 08:23:17 --> Language Class Initialized
ERROR - 2018-11-13 08:23:17 --> 404 Page Not Found: Plugins/arcticmodal
INFO - 2018-11-13 08:23:17 --> Config Class Initialized
INFO - 2018-11-13 08:23:17 --> Hooks Class Initialized
DEBUG - 2018-11-13 08:23:17 --> UTF-8 Support Enabled
INFO - 2018-11-13 08:23:17 --> Utf8 Class Initialized
INFO - 2018-11-13 08:23:17 --> URI Class Initialized
INFO - 2018-11-13 08:23:17 --> Router Class Initialized
INFO - 2018-11-13 08:23:17 --> Output Class Initialized
INFO - 2018-11-13 08:23:17 --> Security Class Initialized
DEBUG - 2018-11-13 08:23:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-13 08:23:17 --> Input Class Initialized
INFO - 2018-11-13 08:23:17 --> Language Class Initialized
ERROR - 2018-11-13 08:23:17 --> 404 Page Not Found: Plugins/mad.customselect.js
INFO - 2018-11-13 08:23:17 --> Config Class Initialized
INFO - 2018-11-13 08:23:17 --> Hooks Class Initialized
DEBUG - 2018-11-13 08:23:17 --> UTF-8 Support Enabled
INFO - 2018-11-13 08:23:17 --> Utf8 Class Initialized
INFO - 2018-11-13 08:23:17 --> URI Class Initialized
INFO - 2018-11-13 08:23:17 --> Router Class Initialized
INFO - 2018-11-13 08:23:17 --> Output Class Initialized
INFO - 2018-11-13 08:23:17 --> Security Class Initialized
DEBUG - 2018-11-13 08:23:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-13 08:23:17 --> Input Class Initialized
INFO - 2018-11-13 08:23:17 --> Language Class Initialized
ERROR - 2018-11-13 08:23:17 --> 404 Page Not Found: Plugins/owl-carousel
INFO - 2018-11-13 08:23:21 --> Config Class Initialized
INFO - 2018-11-13 08:23:21 --> Hooks Class Initialized
DEBUG - 2018-11-13 08:23:21 --> UTF-8 Support Enabled
INFO - 2018-11-13 08:23:21 --> Utf8 Class Initialized
INFO - 2018-11-13 08:23:21 --> URI Class Initialized
INFO - 2018-11-13 08:23:21 --> Router Class Initialized
INFO - 2018-11-13 08:23:21 --> Output Class Initialized
INFO - 2018-11-13 08:23:21 --> Security Class Initialized
DEBUG - 2018-11-13 08:23:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-13 08:23:21 --> Input Class Initialized
INFO - 2018-11-13 08:23:21 --> Language Class Initialized
ERROR - 2018-11-13 08:23:21 --> 404 Page Not Found: Plugins/owl-carousel
INFO - 2018-11-13 08:23:21 --> Config Class Initialized
INFO - 2018-11-13 08:23:21 --> Hooks Class Initialized
DEBUG - 2018-11-13 08:23:21 --> UTF-8 Support Enabled
INFO - 2018-11-13 08:23:21 --> Utf8 Class Initialized
INFO - 2018-11-13 08:23:21 --> URI Class Initialized
INFO - 2018-11-13 08:23:21 --> Router Class Initialized
INFO - 2018-11-13 08:23:21 --> Output Class Initialized
INFO - 2018-11-13 08:23:21 --> Security Class Initialized
DEBUG - 2018-11-13 08:23:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-13 08:23:21 --> Input Class Initialized
INFO - 2018-11-13 08:23:21 --> Language Class Initialized
ERROR - 2018-11-13 08:23:21 --> 404 Page Not Found: Plugins/arcticmodal
INFO - 2018-11-13 08:26:53 --> Config Class Initialized
INFO - 2018-11-13 08:26:53 --> Hooks Class Initialized
DEBUG - 2018-11-13 08:26:54 --> UTF-8 Support Enabled
INFO - 2018-11-13 08:26:54 --> Utf8 Class Initialized
INFO - 2018-11-13 08:26:54 --> URI Class Initialized
DEBUG - 2018-11-13 08:26:54 --> No URI present. Default controller set.
INFO - 2018-11-13 08:26:54 --> Router Class Initialized
INFO - 2018-11-13 08:26:54 --> Output Class Initialized
INFO - 2018-11-13 08:26:54 --> Security Class Initialized
DEBUG - 2018-11-13 08:26:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-13 08:26:54 --> Input Class Initialized
INFO - 2018-11-13 08:26:54 --> Language Class Initialized
INFO - 2018-11-13 08:26:54 --> Loader Class Initialized
INFO - 2018-11-13 08:26:54 --> Helper loaded: url_helper
INFO - 2018-11-13 08:26:54 --> Helper loaded: file_helper
INFO - 2018-11-13 08:26:54 --> Helper loaded: email_helper
INFO - 2018-11-13 08:26:54 --> Helper loaded: common_helper
INFO - 2018-11-13 08:26:54 --> Database Driver Class Initialized
DEBUG - 2018-11-13 08:26:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-13 08:26:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-13 08:26:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-13 08:26:54 --> Pagination Class Initialized
INFO - 2018-11-13 08:26:54 --> Helper loaded: form_helper
INFO - 2018-11-13 08:26:54 --> Form Validation Class Initialized
INFO - 2018-11-13 08:26:54 --> Model Class Initialized
INFO - 2018-11-13 08:26:54 --> Controller Class Initialized
INFO - 2018-11-13 08:26:54 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-13 08:26:54 --> Model Class Initialized
INFO - 2018-11-13 08:26:54 --> Model Class Initialized
INFO - 2018-11-13 08:26:54 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\index.php
INFO - 2018-11-13 08:26:54 --> Final output sent to browser
DEBUG - 2018-11-13 08:26:54 --> Total execution time: 0.0480
INFO - 2018-11-13 08:29:35 --> Config Class Initialized
INFO - 2018-11-13 08:29:35 --> Hooks Class Initialized
DEBUG - 2018-11-13 08:29:35 --> UTF-8 Support Enabled
INFO - 2018-11-13 08:29:35 --> Utf8 Class Initialized
INFO - 2018-11-13 08:29:35 --> URI Class Initialized
DEBUG - 2018-11-13 08:29:35 --> No URI present. Default controller set.
INFO - 2018-11-13 08:29:35 --> Router Class Initialized
INFO - 2018-11-13 08:29:35 --> Output Class Initialized
INFO - 2018-11-13 08:29:35 --> Security Class Initialized
DEBUG - 2018-11-13 08:29:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-13 08:29:35 --> Input Class Initialized
INFO - 2018-11-13 08:29:35 --> Language Class Initialized
INFO - 2018-11-13 08:29:35 --> Loader Class Initialized
INFO - 2018-11-13 08:29:35 --> Helper loaded: url_helper
INFO - 2018-11-13 08:29:35 --> Helper loaded: file_helper
INFO - 2018-11-13 08:29:35 --> Helper loaded: email_helper
INFO - 2018-11-13 08:29:35 --> Helper loaded: common_helper
INFO - 2018-11-13 08:29:35 --> Database Driver Class Initialized
DEBUG - 2018-11-13 08:29:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-13 08:29:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-13 08:29:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-13 08:29:35 --> Pagination Class Initialized
INFO - 2018-11-13 08:29:35 --> Helper loaded: form_helper
INFO - 2018-11-13 08:29:35 --> Form Validation Class Initialized
INFO - 2018-11-13 08:29:35 --> Model Class Initialized
INFO - 2018-11-13 08:29:35 --> Controller Class Initialized
INFO - 2018-11-13 08:29:35 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-13 08:29:35 --> Model Class Initialized
INFO - 2018-11-13 08:29:35 --> Model Class Initialized
INFO - 2018-11-13 08:29:35 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\index.php
INFO - 2018-11-13 08:29:35 --> Final output sent to browser
DEBUG - 2018-11-13 08:29:35 --> Total execution time: 0.0580
INFO - 2018-11-13 08:33:18 --> Config Class Initialized
INFO - 2018-11-13 08:33:18 --> Hooks Class Initialized
DEBUG - 2018-11-13 08:33:18 --> UTF-8 Support Enabled
INFO - 2018-11-13 08:33:18 --> Utf8 Class Initialized
INFO - 2018-11-13 08:33:18 --> URI Class Initialized
INFO - 2018-11-13 08:33:18 --> Router Class Initialized
INFO - 2018-11-13 08:33:18 --> Output Class Initialized
INFO - 2018-11-13 08:33:18 --> Security Class Initialized
DEBUG - 2018-11-13 08:33:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-13 08:33:18 --> Input Class Initialized
INFO - 2018-11-13 08:33:18 --> Language Class Initialized
ERROR - 2018-11-13 08:33:18 --> 404 Page Not Found: Blog_post_with_sidebarhtml/index
INFO - 2018-11-13 08:33:20 --> Config Class Initialized
INFO - 2018-11-13 08:33:20 --> Hooks Class Initialized
DEBUG - 2018-11-13 08:33:20 --> UTF-8 Support Enabled
INFO - 2018-11-13 08:33:20 --> Utf8 Class Initialized
INFO - 2018-11-13 08:33:20 --> URI Class Initialized
DEBUG - 2018-11-13 08:33:20 --> No URI present. Default controller set.
INFO - 2018-11-13 08:33:20 --> Router Class Initialized
INFO - 2018-11-13 08:33:20 --> Output Class Initialized
INFO - 2018-11-13 08:33:20 --> Security Class Initialized
DEBUG - 2018-11-13 08:33:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-13 08:33:20 --> Input Class Initialized
INFO - 2018-11-13 08:33:20 --> Language Class Initialized
INFO - 2018-11-13 08:33:20 --> Loader Class Initialized
INFO - 2018-11-13 08:33:20 --> Helper loaded: url_helper
INFO - 2018-11-13 08:33:20 --> Helper loaded: file_helper
INFO - 2018-11-13 08:33:20 --> Helper loaded: email_helper
INFO - 2018-11-13 08:33:20 --> Helper loaded: common_helper
INFO - 2018-11-13 08:33:20 --> Database Driver Class Initialized
DEBUG - 2018-11-13 08:33:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-13 08:33:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-13 08:33:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-13 08:33:20 --> Pagination Class Initialized
INFO - 2018-11-13 08:33:20 --> Helper loaded: form_helper
INFO - 2018-11-13 08:33:20 --> Form Validation Class Initialized
INFO - 2018-11-13 08:33:20 --> Model Class Initialized
INFO - 2018-11-13 08:33:20 --> Controller Class Initialized
INFO - 2018-11-13 08:33:20 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-13 08:33:20 --> Model Class Initialized
INFO - 2018-11-13 08:33:20 --> Model Class Initialized
INFO - 2018-11-13 08:33:20 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\index.php
INFO - 2018-11-13 08:33:20 --> Final output sent to browser
DEBUG - 2018-11-13 08:33:20 --> Total execution time: 0.0560
INFO - 2018-11-13 08:33:56 --> Config Class Initialized
INFO - 2018-11-13 08:33:56 --> Hooks Class Initialized
DEBUG - 2018-11-13 08:33:56 --> UTF-8 Support Enabled
INFO - 2018-11-13 08:33:56 --> Utf8 Class Initialized
INFO - 2018-11-13 08:33:56 --> URI Class Initialized
DEBUG - 2018-11-13 08:33:56 --> No URI present. Default controller set.
INFO - 2018-11-13 08:33:56 --> Router Class Initialized
INFO - 2018-11-13 08:33:56 --> Output Class Initialized
INFO - 2018-11-13 08:33:56 --> Security Class Initialized
DEBUG - 2018-11-13 08:33:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-13 08:33:56 --> Input Class Initialized
INFO - 2018-11-13 08:33:56 --> Language Class Initialized
INFO - 2018-11-13 08:33:56 --> Loader Class Initialized
INFO - 2018-11-13 08:33:56 --> Helper loaded: url_helper
INFO - 2018-11-13 08:33:56 --> Helper loaded: file_helper
INFO - 2018-11-13 08:33:56 --> Helper loaded: email_helper
INFO - 2018-11-13 08:33:56 --> Helper loaded: common_helper
INFO - 2018-11-13 08:33:56 --> Database Driver Class Initialized
DEBUG - 2018-11-13 08:33:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-13 08:33:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-13 08:33:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-13 08:33:56 --> Pagination Class Initialized
INFO - 2018-11-13 08:33:56 --> Helper loaded: form_helper
INFO - 2018-11-13 08:33:56 --> Form Validation Class Initialized
INFO - 2018-11-13 08:33:56 --> Model Class Initialized
INFO - 2018-11-13 08:33:56 --> Controller Class Initialized
INFO - 2018-11-13 08:33:56 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-13 08:33:56 --> Model Class Initialized
INFO - 2018-11-13 08:33:56 --> Model Class Initialized
INFO - 2018-11-13 08:33:56 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\index.php
INFO - 2018-11-13 08:33:56 --> Final output sent to browser
DEBUG - 2018-11-13 08:33:56 --> Total execution time: 0.0640
INFO - 2018-11-13 08:37:06 --> Config Class Initialized
INFO - 2018-11-13 08:37:06 --> Hooks Class Initialized
DEBUG - 2018-11-13 08:37:06 --> UTF-8 Support Enabled
INFO - 2018-11-13 08:37:06 --> Utf8 Class Initialized
INFO - 2018-11-13 08:37:06 --> URI Class Initialized
DEBUG - 2018-11-13 08:37:06 --> No URI present. Default controller set.
INFO - 2018-11-13 08:37:06 --> Router Class Initialized
INFO - 2018-11-13 08:37:06 --> Output Class Initialized
INFO - 2018-11-13 08:37:06 --> Security Class Initialized
DEBUG - 2018-11-13 08:37:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-13 08:37:06 --> Input Class Initialized
INFO - 2018-11-13 08:37:06 --> Language Class Initialized
INFO - 2018-11-13 08:37:06 --> Loader Class Initialized
INFO - 2018-11-13 08:37:06 --> Helper loaded: url_helper
INFO - 2018-11-13 08:37:06 --> Helper loaded: file_helper
INFO - 2018-11-13 08:37:06 --> Helper loaded: email_helper
INFO - 2018-11-13 08:37:06 --> Helper loaded: common_helper
INFO - 2018-11-13 08:37:06 --> Database Driver Class Initialized
DEBUG - 2018-11-13 08:37:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-13 08:37:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-13 08:37:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-13 08:37:06 --> Pagination Class Initialized
INFO - 2018-11-13 08:37:06 --> Helper loaded: form_helper
INFO - 2018-11-13 08:37:06 --> Form Validation Class Initialized
INFO - 2018-11-13 08:37:06 --> Model Class Initialized
INFO - 2018-11-13 08:37:06 --> Controller Class Initialized
INFO - 2018-11-13 08:37:06 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-13 08:37:06 --> Model Class Initialized
INFO - 2018-11-13 08:37:06 --> Model Class Initialized
INFO - 2018-11-13 08:37:06 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\index.php
INFO - 2018-11-13 08:37:06 --> Final output sent to browser
DEBUG - 2018-11-13 08:37:06 --> Total execution time: 0.0620
INFO - 2018-11-13 08:37:16 --> Config Class Initialized
INFO - 2018-11-13 08:37:16 --> Hooks Class Initialized
DEBUG - 2018-11-13 08:37:16 --> UTF-8 Support Enabled
INFO - 2018-11-13 08:37:16 --> Utf8 Class Initialized
INFO - 2018-11-13 08:37:16 --> URI Class Initialized
INFO - 2018-11-13 08:37:16 --> Router Class Initialized
INFO - 2018-11-13 08:37:16 --> Output Class Initialized
INFO - 2018-11-13 08:37:16 --> Security Class Initialized
DEBUG - 2018-11-13 08:37:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-13 08:37:16 --> Input Class Initialized
INFO - 2018-11-13 08:37:16 --> Language Class Initialized
ERROR - 2018-11-13 08:37:16 --> 404 Page Not Found: Index-2html/index
INFO - 2018-11-13 08:37:19 --> Config Class Initialized
INFO - 2018-11-13 08:37:19 --> Hooks Class Initialized
DEBUG - 2018-11-13 08:37:19 --> UTF-8 Support Enabled
INFO - 2018-11-13 08:37:19 --> Utf8 Class Initialized
INFO - 2018-11-13 08:37:19 --> URI Class Initialized
DEBUG - 2018-11-13 08:37:19 --> No URI present. Default controller set.
INFO - 2018-11-13 08:37:19 --> Router Class Initialized
INFO - 2018-11-13 08:37:19 --> Output Class Initialized
INFO - 2018-11-13 08:37:19 --> Security Class Initialized
DEBUG - 2018-11-13 08:37:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-13 08:37:19 --> Input Class Initialized
INFO - 2018-11-13 08:37:19 --> Language Class Initialized
INFO - 2018-11-13 08:37:19 --> Loader Class Initialized
INFO - 2018-11-13 08:37:19 --> Helper loaded: url_helper
INFO - 2018-11-13 08:37:19 --> Helper loaded: file_helper
INFO - 2018-11-13 08:37:19 --> Helper loaded: email_helper
INFO - 2018-11-13 08:37:19 --> Helper loaded: common_helper
INFO - 2018-11-13 08:37:19 --> Database Driver Class Initialized
DEBUG - 2018-11-13 08:37:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-13 08:37:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-13 08:37:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-13 08:37:19 --> Pagination Class Initialized
INFO - 2018-11-13 08:37:19 --> Helper loaded: form_helper
INFO - 2018-11-13 08:37:19 --> Form Validation Class Initialized
INFO - 2018-11-13 08:37:19 --> Model Class Initialized
INFO - 2018-11-13 08:37:19 --> Controller Class Initialized
INFO - 2018-11-13 08:37:19 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-13 08:37:19 --> Model Class Initialized
INFO - 2018-11-13 08:37:19 --> Model Class Initialized
INFO - 2018-11-13 08:37:19 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\index.php
INFO - 2018-11-13 08:37:19 --> Final output sent to browser
DEBUG - 2018-11-13 08:37:19 --> Total execution time: 0.0600
INFO - 2018-11-13 08:42:54 --> Config Class Initialized
INFO - 2018-11-13 08:42:54 --> Hooks Class Initialized
DEBUG - 2018-11-13 08:42:54 --> UTF-8 Support Enabled
INFO - 2018-11-13 08:42:54 --> Utf8 Class Initialized
INFO - 2018-11-13 08:42:54 --> URI Class Initialized
DEBUG - 2018-11-13 08:42:54 --> No URI present. Default controller set.
INFO - 2018-11-13 08:42:54 --> Router Class Initialized
INFO - 2018-11-13 08:42:54 --> Output Class Initialized
INFO - 2018-11-13 08:42:54 --> Security Class Initialized
DEBUG - 2018-11-13 08:42:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-13 08:42:54 --> Input Class Initialized
INFO - 2018-11-13 08:42:54 --> Language Class Initialized
INFO - 2018-11-13 08:42:54 --> Loader Class Initialized
INFO - 2018-11-13 08:42:54 --> Helper loaded: url_helper
INFO - 2018-11-13 08:42:54 --> Helper loaded: file_helper
INFO - 2018-11-13 08:42:54 --> Helper loaded: email_helper
INFO - 2018-11-13 08:42:54 --> Helper loaded: common_helper
INFO - 2018-11-13 08:42:54 --> Database Driver Class Initialized
DEBUG - 2018-11-13 08:42:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-13 08:42:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-13 08:42:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-13 08:42:54 --> Pagination Class Initialized
INFO - 2018-11-13 08:42:54 --> Helper loaded: form_helper
INFO - 2018-11-13 08:42:54 --> Form Validation Class Initialized
INFO - 2018-11-13 08:42:54 --> Model Class Initialized
INFO - 2018-11-13 08:42:54 --> Controller Class Initialized
INFO - 2018-11-13 08:42:54 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-13 08:42:54 --> Model Class Initialized
INFO - 2018-11-13 08:42:54 --> Model Class Initialized
INFO - 2018-11-13 08:42:54 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\index.php
INFO - 2018-11-13 08:42:54 --> Final output sent to browser
DEBUG - 2018-11-13 08:42:54 --> Total execution time: 0.0540
INFO - 2018-11-13 08:47:40 --> Config Class Initialized
INFO - 2018-11-13 08:47:40 --> Hooks Class Initialized
DEBUG - 2018-11-13 08:47:40 --> UTF-8 Support Enabled
INFO - 2018-11-13 08:47:40 --> Utf8 Class Initialized
INFO - 2018-11-13 08:47:40 --> URI Class Initialized
DEBUG - 2018-11-13 08:47:40 --> No URI present. Default controller set.
INFO - 2018-11-13 08:47:40 --> Router Class Initialized
INFO - 2018-11-13 08:47:40 --> Output Class Initialized
INFO - 2018-11-13 08:47:40 --> Security Class Initialized
DEBUG - 2018-11-13 08:47:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-13 08:47:40 --> Input Class Initialized
INFO - 2018-11-13 08:47:40 --> Language Class Initialized
INFO - 2018-11-13 08:47:40 --> Loader Class Initialized
INFO - 2018-11-13 08:47:40 --> Helper loaded: url_helper
INFO - 2018-11-13 08:47:40 --> Helper loaded: file_helper
INFO - 2018-11-13 08:47:40 --> Helper loaded: email_helper
INFO - 2018-11-13 08:47:40 --> Helper loaded: common_helper
INFO - 2018-11-13 08:47:40 --> Database Driver Class Initialized
DEBUG - 2018-11-13 08:47:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-13 08:47:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-13 08:47:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-13 08:47:40 --> Pagination Class Initialized
INFO - 2018-11-13 08:47:40 --> Helper loaded: form_helper
INFO - 2018-11-13 08:47:40 --> Form Validation Class Initialized
INFO - 2018-11-13 08:47:40 --> Model Class Initialized
INFO - 2018-11-13 08:47:40 --> Controller Class Initialized
INFO - 2018-11-13 08:47:40 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-13 08:47:40 --> Model Class Initialized
INFO - 2018-11-13 08:47:40 --> Model Class Initialized
INFO - 2018-11-13 08:47:40 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\index.php
INFO - 2018-11-13 08:47:40 --> Final output sent to browser
DEBUG - 2018-11-13 08:47:40 --> Total execution time: 0.0630
INFO - 2018-11-13 08:47:41 --> Config Class Initialized
INFO - 2018-11-13 08:47:41 --> Hooks Class Initialized
INFO - 2018-11-13 08:47:41 --> Config Class Initialized
INFO - 2018-11-13 08:47:41 --> Hooks Class Initialized
DEBUG - 2018-11-13 08:47:41 --> UTF-8 Support Enabled
INFO - 2018-11-13 08:47:41 --> Utf8 Class Initialized
INFO - 2018-11-13 08:47:41 --> URI Class Initialized
DEBUG - 2018-11-13 08:47:41 --> No URI present. Default controller set.
INFO - 2018-11-13 08:47:41 --> Router Class Initialized
INFO - 2018-11-13 08:47:41 --> Output Class Initialized
INFO - 2018-11-13 08:47:41 --> Security Class Initialized
DEBUG - 2018-11-13 08:47:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-13 08:47:41 --> Input Class Initialized
INFO - 2018-11-13 08:47:41 --> Language Class Initialized
INFO - 2018-11-13 08:47:41 --> Loader Class Initialized
INFO - 2018-11-13 08:47:41 --> Helper loaded: url_helper
INFO - 2018-11-13 08:47:41 --> Helper loaded: file_helper
INFO - 2018-11-13 08:47:41 --> Helper loaded: email_helper
INFO - 2018-11-13 08:47:41 --> Helper loaded: common_helper
INFO - 2018-11-13 08:47:41 --> Database Driver Class Initialized
DEBUG - 2018-11-13 08:47:41 --> UTF-8 Support Enabled
INFO - 2018-11-13 08:47:41 --> Utf8 Class Initialized
INFO - 2018-11-13 08:47:41 --> URI Class Initialized
DEBUG - 2018-11-13 08:47:41 --> No URI present. Default controller set.
INFO - 2018-11-13 08:47:41 --> Router Class Initialized
INFO - 2018-11-13 08:47:41 --> Output Class Initialized
INFO - 2018-11-13 08:47:41 --> Security Class Initialized
DEBUG - 2018-11-13 08:47:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-13 08:47:41 --> Input Class Initialized
INFO - 2018-11-13 08:47:41 --> Language Class Initialized
DEBUG - 2018-11-13 08:47:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-13 08:47:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-13 08:47:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-13 08:47:41 --> Pagination Class Initialized
INFO - 2018-11-13 08:47:41 --> Helper loaded: form_helper
INFO - 2018-11-13 08:47:41 --> Form Validation Class Initialized
INFO - 2018-11-13 08:47:41 --> Model Class Initialized
INFO - 2018-11-13 08:47:41 --> Controller Class Initialized
INFO - 2018-11-13 08:47:41 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-13 08:47:41 --> Model Class Initialized
INFO - 2018-11-13 08:47:41 --> Model Class Initialized
INFO - 2018-11-13 08:47:41 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\index.php
INFO - 2018-11-13 08:47:41 --> Final output sent to browser
DEBUG - 2018-11-13 08:47:41 --> Total execution time: 0.1910
INFO - 2018-11-13 08:47:41 --> Loader Class Initialized
INFO - 2018-11-13 08:47:41 --> Helper loaded: url_helper
INFO - 2018-11-13 08:47:41 --> Helper loaded: file_helper
INFO - 2018-11-13 08:47:41 --> Helper loaded: email_helper
INFO - 2018-11-13 08:47:41 --> Helper loaded: common_helper
INFO - 2018-11-13 08:47:41 --> Database Driver Class Initialized
DEBUG - 2018-11-13 08:47:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-13 08:47:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-13 08:47:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-13 08:47:41 --> Pagination Class Initialized
INFO - 2018-11-13 08:47:41 --> Helper loaded: form_helper
INFO - 2018-11-13 08:47:41 --> Form Validation Class Initialized
INFO - 2018-11-13 08:47:41 --> Model Class Initialized
INFO - 2018-11-13 08:47:41 --> Controller Class Initialized
INFO - 2018-11-13 08:47:41 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-13 08:47:41 --> Model Class Initialized
INFO - 2018-11-13 08:47:41 --> Model Class Initialized
INFO - 2018-11-13 08:47:41 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\index.php
INFO - 2018-11-13 08:47:41 --> Final output sent to browser
DEBUG - 2018-11-13 08:47:41 --> Total execution time: 0.5270
INFO - 2018-11-13 08:49:28 --> Config Class Initialized
INFO - 2018-11-13 08:49:28 --> Hooks Class Initialized
DEBUG - 2018-11-13 08:49:28 --> UTF-8 Support Enabled
INFO - 2018-11-13 08:49:28 --> Utf8 Class Initialized
INFO - 2018-11-13 08:49:28 --> URI Class Initialized
DEBUG - 2018-11-13 08:49:28 --> No URI present. Default controller set.
INFO - 2018-11-13 08:49:28 --> Router Class Initialized
INFO - 2018-11-13 08:49:28 --> Output Class Initialized
INFO - 2018-11-13 08:49:28 --> Security Class Initialized
DEBUG - 2018-11-13 08:49:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-13 08:49:28 --> Input Class Initialized
INFO - 2018-11-13 08:49:28 --> Language Class Initialized
INFO - 2018-11-13 08:49:28 --> Loader Class Initialized
INFO - 2018-11-13 08:49:28 --> Helper loaded: url_helper
INFO - 2018-11-13 08:49:28 --> Helper loaded: file_helper
INFO - 2018-11-13 08:49:28 --> Helper loaded: email_helper
INFO - 2018-11-13 08:49:28 --> Helper loaded: common_helper
INFO - 2018-11-13 08:49:28 --> Database Driver Class Initialized
DEBUG - 2018-11-13 08:49:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-13 08:49:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-13 08:49:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-13 08:49:28 --> Pagination Class Initialized
INFO - 2018-11-13 08:49:28 --> Helper loaded: form_helper
INFO - 2018-11-13 08:49:28 --> Form Validation Class Initialized
INFO - 2018-11-13 08:49:28 --> Model Class Initialized
INFO - 2018-11-13 08:49:28 --> Controller Class Initialized
INFO - 2018-11-13 08:49:28 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-13 08:49:28 --> Model Class Initialized
INFO - 2018-11-13 08:49:28 --> Model Class Initialized
INFO - 2018-11-13 08:49:28 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\index.php
INFO - 2018-11-13 08:49:28 --> Final output sent to browser
DEBUG - 2018-11-13 08:49:28 --> Total execution time: 0.0760
INFO - 2018-11-13 08:53:42 --> Config Class Initialized
INFO - 2018-11-13 08:53:42 --> Hooks Class Initialized
DEBUG - 2018-11-13 08:53:42 --> UTF-8 Support Enabled
INFO - 2018-11-13 08:53:42 --> Utf8 Class Initialized
INFO - 2018-11-13 08:53:42 --> URI Class Initialized
DEBUG - 2018-11-13 08:53:42 --> No URI present. Default controller set.
INFO - 2018-11-13 08:53:42 --> Router Class Initialized
INFO - 2018-11-13 08:53:42 --> Output Class Initialized
INFO - 2018-11-13 08:53:42 --> Security Class Initialized
DEBUG - 2018-11-13 08:53:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-13 08:53:42 --> Input Class Initialized
INFO - 2018-11-13 08:53:42 --> Language Class Initialized
INFO - 2018-11-13 08:53:42 --> Loader Class Initialized
INFO - 2018-11-13 08:53:42 --> Helper loaded: url_helper
INFO - 2018-11-13 08:53:42 --> Helper loaded: file_helper
INFO - 2018-11-13 08:53:42 --> Helper loaded: email_helper
INFO - 2018-11-13 08:53:42 --> Helper loaded: common_helper
INFO - 2018-11-13 08:53:42 --> Database Driver Class Initialized
DEBUG - 2018-11-13 08:53:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-13 08:53:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-13 08:53:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-13 08:53:42 --> Pagination Class Initialized
INFO - 2018-11-13 08:53:42 --> Helper loaded: form_helper
INFO - 2018-11-13 08:53:42 --> Form Validation Class Initialized
INFO - 2018-11-13 08:53:42 --> Model Class Initialized
INFO - 2018-11-13 08:53:42 --> Controller Class Initialized
INFO - 2018-11-13 08:53:42 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-13 08:53:42 --> Model Class Initialized
INFO - 2018-11-13 08:53:42 --> Model Class Initialized
INFO - 2018-11-13 08:53:42 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\index.php
INFO - 2018-11-13 08:53:42 --> Final output sent to browser
DEBUG - 2018-11-13 08:53:42 --> Total execution time: 0.0730
INFO - 2018-11-13 08:54:00 --> Config Class Initialized
INFO - 2018-11-13 08:54:00 --> Hooks Class Initialized
DEBUG - 2018-11-13 08:54:00 --> UTF-8 Support Enabled
INFO - 2018-11-13 08:54:00 --> Utf8 Class Initialized
INFO - 2018-11-13 08:54:00 --> URI Class Initialized
DEBUG - 2018-11-13 08:54:00 --> No URI present. Default controller set.
INFO - 2018-11-13 08:54:00 --> Router Class Initialized
INFO - 2018-11-13 08:54:00 --> Output Class Initialized
INFO - 2018-11-13 08:54:00 --> Security Class Initialized
DEBUG - 2018-11-13 08:54:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-13 08:54:00 --> Input Class Initialized
INFO - 2018-11-13 08:54:00 --> Language Class Initialized
INFO - 2018-11-13 08:54:00 --> Loader Class Initialized
INFO - 2018-11-13 08:54:00 --> Helper loaded: url_helper
INFO - 2018-11-13 08:54:00 --> Helper loaded: file_helper
INFO - 2018-11-13 08:54:00 --> Helper loaded: email_helper
INFO - 2018-11-13 08:54:00 --> Helper loaded: common_helper
INFO - 2018-11-13 08:54:00 --> Database Driver Class Initialized
DEBUG - 2018-11-13 08:54:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-13 08:54:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-13 08:54:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-13 08:54:00 --> Pagination Class Initialized
INFO - 2018-11-13 08:54:00 --> Helper loaded: form_helper
INFO - 2018-11-13 08:54:00 --> Form Validation Class Initialized
INFO - 2018-11-13 08:54:00 --> Model Class Initialized
INFO - 2018-11-13 08:54:00 --> Controller Class Initialized
INFO - 2018-11-13 08:54:00 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-13 08:54:00 --> Model Class Initialized
INFO - 2018-11-13 08:54:00 --> Model Class Initialized
INFO - 2018-11-13 08:54:01 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\index.php
INFO - 2018-11-13 08:54:01 --> Final output sent to browser
DEBUG - 2018-11-13 08:54:01 --> Total execution time: 0.0940
INFO - 2018-11-13 08:55:28 --> Config Class Initialized
INFO - 2018-11-13 08:55:28 --> Hooks Class Initialized
DEBUG - 2018-11-13 08:55:28 --> UTF-8 Support Enabled
INFO - 2018-11-13 08:55:28 --> Utf8 Class Initialized
INFO - 2018-11-13 08:55:28 --> URI Class Initialized
INFO - 2018-11-13 08:55:28 --> Router Class Initialized
INFO - 2018-11-13 08:55:28 --> Output Class Initialized
INFO - 2018-11-13 08:55:28 --> Security Class Initialized
DEBUG - 2018-11-13 08:55:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-13 08:55:28 --> Input Class Initialized
INFO - 2018-11-13 08:55:28 --> Language Class Initialized
ERROR - 2018-11-13 08:55:28 --> 404 Page Not Found: Pages_new_listinghtml/index
INFO - 2018-11-13 08:55:31 --> Config Class Initialized
INFO - 2018-11-13 08:55:31 --> Hooks Class Initialized
DEBUG - 2018-11-13 08:55:31 --> UTF-8 Support Enabled
INFO - 2018-11-13 08:55:31 --> Utf8 Class Initialized
INFO - 2018-11-13 08:55:31 --> URI Class Initialized
DEBUG - 2018-11-13 08:55:31 --> No URI present. Default controller set.
INFO - 2018-11-13 08:55:31 --> Router Class Initialized
INFO - 2018-11-13 08:55:31 --> Output Class Initialized
INFO - 2018-11-13 08:55:31 --> Security Class Initialized
DEBUG - 2018-11-13 08:55:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-13 08:55:31 --> Input Class Initialized
INFO - 2018-11-13 08:55:31 --> Language Class Initialized
INFO - 2018-11-13 08:55:31 --> Loader Class Initialized
INFO - 2018-11-13 08:55:31 --> Helper loaded: url_helper
INFO - 2018-11-13 08:55:31 --> Helper loaded: file_helper
INFO - 2018-11-13 08:55:31 --> Helper loaded: email_helper
INFO - 2018-11-13 08:55:31 --> Helper loaded: common_helper
INFO - 2018-11-13 08:55:31 --> Database Driver Class Initialized
DEBUG - 2018-11-13 08:55:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-13 08:55:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-13 08:55:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-13 08:55:31 --> Pagination Class Initialized
INFO - 2018-11-13 08:55:31 --> Helper loaded: form_helper
INFO - 2018-11-13 08:55:31 --> Form Validation Class Initialized
INFO - 2018-11-13 08:55:31 --> Model Class Initialized
INFO - 2018-11-13 08:55:31 --> Controller Class Initialized
INFO - 2018-11-13 08:55:31 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-13 08:55:31 --> Model Class Initialized
INFO - 2018-11-13 08:55:31 --> Model Class Initialized
INFO - 2018-11-13 08:55:31 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\index.php
INFO - 2018-11-13 08:55:31 --> Final output sent to browser
DEBUG - 2018-11-13 08:55:31 --> Total execution time: 0.0480
INFO - 2018-11-13 08:56:55 --> Config Class Initialized
INFO - 2018-11-13 08:56:55 --> Hooks Class Initialized
DEBUG - 2018-11-13 08:56:55 --> UTF-8 Support Enabled
INFO - 2018-11-13 08:56:55 --> Utf8 Class Initialized
INFO - 2018-11-13 08:56:55 --> URI Class Initialized
INFO - 2018-11-13 08:56:55 --> Router Class Initialized
INFO - 2018-11-13 08:56:55 --> Output Class Initialized
INFO - 2018-11-13 08:56:55 --> Security Class Initialized
DEBUG - 2018-11-13 08:56:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-13 08:56:55 --> Input Class Initialized
INFO - 2018-11-13 08:56:55 --> Language Class Initialized
ERROR - 2018-11-13 08:56:55 --> 404 Page Not Found: Pages_new_listinghtml/index
INFO - 2018-11-13 08:56:57 --> Config Class Initialized
INFO - 2018-11-13 08:56:57 --> Hooks Class Initialized
DEBUG - 2018-11-13 08:56:57 --> UTF-8 Support Enabled
INFO - 2018-11-13 08:56:57 --> Utf8 Class Initialized
INFO - 2018-11-13 08:56:57 --> URI Class Initialized
DEBUG - 2018-11-13 08:56:57 --> No URI present. Default controller set.
INFO - 2018-11-13 08:56:57 --> Router Class Initialized
INFO - 2018-11-13 08:56:57 --> Output Class Initialized
INFO - 2018-11-13 08:56:57 --> Security Class Initialized
DEBUG - 2018-11-13 08:56:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-13 08:56:57 --> Input Class Initialized
INFO - 2018-11-13 08:56:57 --> Language Class Initialized
INFO - 2018-11-13 08:56:57 --> Loader Class Initialized
INFO - 2018-11-13 08:56:57 --> Helper loaded: url_helper
INFO - 2018-11-13 08:56:57 --> Helper loaded: file_helper
INFO - 2018-11-13 08:56:57 --> Helper loaded: email_helper
INFO - 2018-11-13 08:56:57 --> Helper loaded: common_helper
INFO - 2018-11-13 08:56:57 --> Database Driver Class Initialized
DEBUG - 2018-11-13 08:56:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-13 08:56:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-13 08:56:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-13 08:56:57 --> Pagination Class Initialized
INFO - 2018-11-13 08:56:57 --> Helper loaded: form_helper
INFO - 2018-11-13 08:56:57 --> Form Validation Class Initialized
INFO - 2018-11-13 08:56:57 --> Model Class Initialized
INFO - 2018-11-13 08:56:57 --> Controller Class Initialized
INFO - 2018-11-13 08:56:57 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-13 08:56:57 --> Model Class Initialized
INFO - 2018-11-13 08:56:57 --> Model Class Initialized
INFO - 2018-11-13 08:56:57 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\index.php
INFO - 2018-11-13 08:56:57 --> Final output sent to browser
DEBUG - 2018-11-13 08:56:57 --> Total execution time: 0.0480
INFO - 2018-11-13 09:05:10 --> Config Class Initialized
INFO - 2018-11-13 09:05:10 --> Hooks Class Initialized
DEBUG - 2018-11-13 09:05:10 --> UTF-8 Support Enabled
INFO - 2018-11-13 09:05:10 --> Utf8 Class Initialized
INFO - 2018-11-13 09:05:10 --> URI Class Initialized
DEBUG - 2018-11-13 09:05:10 --> No URI present. Default controller set.
INFO - 2018-11-13 09:05:10 --> Router Class Initialized
INFO - 2018-11-13 09:05:10 --> Output Class Initialized
INFO - 2018-11-13 09:05:10 --> Security Class Initialized
DEBUG - 2018-11-13 09:05:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-13 09:05:10 --> Input Class Initialized
INFO - 2018-11-13 09:05:10 --> Language Class Initialized
INFO - 2018-11-13 09:05:10 --> Loader Class Initialized
INFO - 2018-11-13 09:05:10 --> Helper loaded: url_helper
INFO - 2018-11-13 09:05:10 --> Helper loaded: file_helper
INFO - 2018-11-13 09:05:10 --> Helper loaded: email_helper
INFO - 2018-11-13 09:05:10 --> Helper loaded: common_helper
INFO - 2018-11-13 09:05:10 --> Database Driver Class Initialized
DEBUG - 2018-11-13 09:05:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-13 09:05:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-13 09:05:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-13 09:05:10 --> Pagination Class Initialized
INFO - 2018-11-13 09:05:10 --> Helper loaded: form_helper
INFO - 2018-11-13 09:05:10 --> Form Validation Class Initialized
INFO - 2018-11-13 09:05:10 --> Model Class Initialized
INFO - 2018-11-13 09:05:10 --> Controller Class Initialized
INFO - 2018-11-13 09:05:10 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-13 09:05:10 --> Model Class Initialized
INFO - 2018-11-13 09:05:10 --> Model Class Initialized
INFO - 2018-11-13 09:05:10 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\template/header-menu.php
INFO - 2018-11-13 09:05:10 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\index.php
INFO - 2018-11-13 09:05:10 --> Final output sent to browser
DEBUG - 2018-11-13 09:05:10 --> Total execution time: 0.0470
INFO - 2018-11-13 09:05:15 --> Config Class Initialized
INFO - 2018-11-13 09:05:15 --> Hooks Class Initialized
DEBUG - 2018-11-13 09:05:15 --> UTF-8 Support Enabled
INFO - 2018-11-13 09:05:15 --> Utf8 Class Initialized
INFO - 2018-11-13 09:05:15 --> URI Class Initialized
INFO - 2018-11-13 09:05:15 --> Router Class Initialized
INFO - 2018-11-13 09:05:15 --> Output Class Initialized
INFO - 2018-11-13 09:05:15 --> Security Class Initialized
DEBUG - 2018-11-13 09:05:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-13 09:05:15 --> Input Class Initialized
INFO - 2018-11-13 09:05:15 --> Language Class Initialized
ERROR - 2018-11-13 09:05:15 --> 404 Page Not Found: Index-2html/index
INFO - 2018-11-13 09:05:17 --> Config Class Initialized
INFO - 2018-11-13 09:05:17 --> Hooks Class Initialized
DEBUG - 2018-11-13 09:05:17 --> UTF-8 Support Enabled
INFO - 2018-11-13 09:05:17 --> Utf8 Class Initialized
INFO - 2018-11-13 09:05:17 --> URI Class Initialized
DEBUG - 2018-11-13 09:05:17 --> No URI present. Default controller set.
INFO - 2018-11-13 09:05:17 --> Router Class Initialized
INFO - 2018-11-13 09:05:17 --> Output Class Initialized
INFO - 2018-11-13 09:05:17 --> Security Class Initialized
DEBUG - 2018-11-13 09:05:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-13 09:05:17 --> Input Class Initialized
INFO - 2018-11-13 09:05:17 --> Language Class Initialized
INFO - 2018-11-13 09:05:17 --> Loader Class Initialized
INFO - 2018-11-13 09:05:17 --> Helper loaded: url_helper
INFO - 2018-11-13 09:05:17 --> Helper loaded: file_helper
INFO - 2018-11-13 09:05:17 --> Helper loaded: email_helper
INFO - 2018-11-13 09:05:17 --> Helper loaded: common_helper
INFO - 2018-11-13 09:05:17 --> Database Driver Class Initialized
DEBUG - 2018-11-13 09:05:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-13 09:05:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-13 09:05:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-13 09:05:17 --> Pagination Class Initialized
INFO - 2018-11-13 09:05:17 --> Helper loaded: form_helper
INFO - 2018-11-13 09:05:17 --> Form Validation Class Initialized
INFO - 2018-11-13 09:05:17 --> Model Class Initialized
INFO - 2018-11-13 09:05:17 --> Controller Class Initialized
INFO - 2018-11-13 09:05:17 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-13 09:05:17 --> Model Class Initialized
INFO - 2018-11-13 09:05:17 --> Model Class Initialized
INFO - 2018-11-13 09:05:17 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\template/header-menu.php
INFO - 2018-11-13 09:05:17 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\index.php
INFO - 2018-11-13 09:05:17 --> Final output sent to browser
DEBUG - 2018-11-13 09:05:17 --> Total execution time: 0.0590
INFO - 2018-11-13 09:05:23 --> Config Class Initialized
INFO - 2018-11-13 09:05:23 --> Hooks Class Initialized
DEBUG - 2018-11-13 09:05:23 --> UTF-8 Support Enabled
INFO - 2018-11-13 09:05:23 --> Utf8 Class Initialized
INFO - 2018-11-13 09:05:23 --> URI Class Initialized
DEBUG - 2018-11-13 09:05:23 --> No URI present. Default controller set.
INFO - 2018-11-13 09:05:23 --> Router Class Initialized
INFO - 2018-11-13 09:05:23 --> Output Class Initialized
INFO - 2018-11-13 09:05:23 --> Security Class Initialized
DEBUG - 2018-11-13 09:05:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-13 09:05:23 --> Input Class Initialized
INFO - 2018-11-13 09:05:23 --> Language Class Initialized
INFO - 2018-11-13 09:05:23 --> Loader Class Initialized
INFO - 2018-11-13 09:05:23 --> Helper loaded: url_helper
INFO - 2018-11-13 09:05:23 --> Helper loaded: file_helper
INFO - 2018-11-13 09:05:23 --> Helper loaded: email_helper
INFO - 2018-11-13 09:05:23 --> Helper loaded: common_helper
INFO - 2018-11-13 09:05:23 --> Database Driver Class Initialized
DEBUG - 2018-11-13 09:05:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-13 09:05:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-13 09:05:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-13 09:05:23 --> Pagination Class Initialized
INFO - 2018-11-13 09:05:23 --> Helper loaded: form_helper
INFO - 2018-11-13 09:05:23 --> Form Validation Class Initialized
INFO - 2018-11-13 09:05:23 --> Model Class Initialized
INFO - 2018-11-13 09:05:23 --> Controller Class Initialized
INFO - 2018-11-13 09:05:23 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-13 09:05:23 --> Model Class Initialized
INFO - 2018-11-13 09:05:23 --> Model Class Initialized
INFO - 2018-11-13 09:05:23 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\template/header-menu.php
INFO - 2018-11-13 09:05:23 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\index.php
INFO - 2018-11-13 09:05:23 --> Final output sent to browser
DEBUG - 2018-11-13 09:05:23 --> Total execution time: 0.0550
INFO - 2018-11-13 09:07:36 --> Config Class Initialized
INFO - 2018-11-13 09:07:36 --> Hooks Class Initialized
DEBUG - 2018-11-13 09:07:36 --> UTF-8 Support Enabled
INFO - 2018-11-13 09:07:36 --> Utf8 Class Initialized
INFO - 2018-11-13 09:07:36 --> URI Class Initialized
DEBUG - 2018-11-13 09:07:36 --> No URI present. Default controller set.
INFO - 2018-11-13 09:07:36 --> Router Class Initialized
INFO - 2018-11-13 09:07:36 --> Output Class Initialized
INFO - 2018-11-13 09:07:36 --> Security Class Initialized
DEBUG - 2018-11-13 09:07:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-13 09:07:36 --> Input Class Initialized
INFO - 2018-11-13 09:07:36 --> Language Class Initialized
INFO - 2018-11-13 09:07:36 --> Loader Class Initialized
INFO - 2018-11-13 09:07:36 --> Helper loaded: url_helper
INFO - 2018-11-13 09:07:36 --> Helper loaded: file_helper
INFO - 2018-11-13 09:07:36 --> Helper loaded: email_helper
INFO - 2018-11-13 09:07:36 --> Helper loaded: common_helper
INFO - 2018-11-13 09:07:36 --> Database Driver Class Initialized
DEBUG - 2018-11-13 09:07:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-13 09:07:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-13 09:07:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-13 09:07:36 --> Pagination Class Initialized
INFO - 2018-11-13 09:07:36 --> Helper loaded: form_helper
INFO - 2018-11-13 09:07:36 --> Form Validation Class Initialized
INFO - 2018-11-13 09:07:36 --> Model Class Initialized
INFO - 2018-11-13 09:07:36 --> Controller Class Initialized
INFO - 2018-11-13 09:07:36 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-13 09:07:36 --> Model Class Initialized
INFO - 2018-11-13 09:07:36 --> Model Class Initialized
INFO - 2018-11-13 09:07:36 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\template/header-menu.php
INFO - 2018-11-13 09:07:36 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\template/footer.php
INFO - 2018-11-13 09:07:36 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\index.php
INFO - 2018-11-13 09:07:36 --> Final output sent to browser
DEBUG - 2018-11-13 09:07:36 --> Total execution time: 0.0650
INFO - 2018-11-13 09:09:13 --> Config Class Initialized
INFO - 2018-11-13 09:09:13 --> Hooks Class Initialized
DEBUG - 2018-11-13 09:09:13 --> UTF-8 Support Enabled
INFO - 2018-11-13 09:09:13 --> Utf8 Class Initialized
INFO - 2018-11-13 09:09:13 --> URI Class Initialized
DEBUG - 2018-11-13 09:09:13 --> No URI present. Default controller set.
INFO - 2018-11-13 09:09:13 --> Router Class Initialized
INFO - 2018-11-13 09:09:13 --> Output Class Initialized
INFO - 2018-11-13 09:09:13 --> Security Class Initialized
DEBUG - 2018-11-13 09:09:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-13 09:09:13 --> Input Class Initialized
INFO - 2018-11-13 09:09:13 --> Language Class Initialized
INFO - 2018-11-13 09:09:13 --> Loader Class Initialized
INFO - 2018-11-13 09:09:13 --> Helper loaded: url_helper
INFO - 2018-11-13 09:09:13 --> Helper loaded: file_helper
INFO - 2018-11-13 09:09:13 --> Helper loaded: email_helper
INFO - 2018-11-13 09:09:13 --> Helper loaded: common_helper
INFO - 2018-11-13 09:09:13 --> Database Driver Class Initialized
DEBUG - 2018-11-13 09:09:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-13 09:09:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-13 09:09:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-13 09:09:13 --> Pagination Class Initialized
INFO - 2018-11-13 09:09:13 --> Helper loaded: form_helper
INFO - 2018-11-13 09:09:13 --> Form Validation Class Initialized
INFO - 2018-11-13 09:09:13 --> Model Class Initialized
INFO - 2018-11-13 09:09:13 --> Controller Class Initialized
INFO - 2018-11-13 09:09:13 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-13 09:09:13 --> Model Class Initialized
INFO - 2018-11-13 09:09:13 --> Model Class Initialized
INFO - 2018-11-13 09:09:13 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\template/header-menu.php
INFO - 2018-11-13 09:09:13 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\template/footer.php
INFO - 2018-11-13 09:09:13 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\index.php
INFO - 2018-11-13 09:09:13 --> Final output sent to browser
DEBUG - 2018-11-13 09:09:13 --> Total execution time: 0.0870
INFO - 2018-11-13 09:15:02 --> Config Class Initialized
INFO - 2018-11-13 09:15:02 --> Hooks Class Initialized
DEBUG - 2018-11-13 09:15:02 --> UTF-8 Support Enabled
INFO - 2018-11-13 09:15:02 --> Utf8 Class Initialized
INFO - 2018-11-13 09:15:02 --> URI Class Initialized
DEBUG - 2018-11-13 09:15:02 --> No URI present. Default controller set.
INFO - 2018-11-13 09:15:02 --> Router Class Initialized
INFO - 2018-11-13 09:15:02 --> Output Class Initialized
INFO - 2018-11-13 09:15:02 --> Security Class Initialized
DEBUG - 2018-11-13 09:15:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-13 09:15:02 --> Input Class Initialized
INFO - 2018-11-13 09:15:02 --> Language Class Initialized
INFO - 2018-11-13 09:15:02 --> Loader Class Initialized
INFO - 2018-11-13 09:15:02 --> Helper loaded: url_helper
INFO - 2018-11-13 09:15:02 --> Helper loaded: file_helper
INFO - 2018-11-13 09:15:02 --> Helper loaded: email_helper
INFO - 2018-11-13 09:15:02 --> Helper loaded: common_helper
INFO - 2018-11-13 09:15:02 --> Database Driver Class Initialized
DEBUG - 2018-11-13 09:15:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-13 09:15:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-13 09:15:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-13 09:15:02 --> Pagination Class Initialized
INFO - 2018-11-13 09:15:02 --> Helper loaded: form_helper
INFO - 2018-11-13 09:15:02 --> Form Validation Class Initialized
INFO - 2018-11-13 09:15:02 --> Model Class Initialized
INFO - 2018-11-13 09:15:02 --> Controller Class Initialized
INFO - 2018-11-13 09:15:02 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-13 09:15:02 --> Model Class Initialized
INFO - 2018-11-13 09:15:02 --> Model Class Initialized
INFO - 2018-11-13 09:15:02 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\template/header-menu.php
INFO - 2018-11-13 09:15:02 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\template/footer.php
INFO - 2018-11-13 09:15:02 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\index.php
INFO - 2018-11-13 09:15:02 --> Final output sent to browser
DEBUG - 2018-11-13 09:15:02 --> Total execution time: 0.0530
INFO - 2018-11-13 09:15:15 --> Config Class Initialized
INFO - 2018-11-13 09:15:15 --> Hooks Class Initialized
DEBUG - 2018-11-13 09:15:15 --> UTF-8 Support Enabled
INFO - 2018-11-13 09:15:15 --> Utf8 Class Initialized
INFO - 2018-11-13 09:15:15 --> URI Class Initialized
DEBUG - 2018-11-13 09:15:15 --> No URI present. Default controller set.
INFO - 2018-11-13 09:15:15 --> Router Class Initialized
INFO - 2018-11-13 09:15:15 --> Output Class Initialized
INFO - 2018-11-13 09:15:15 --> Security Class Initialized
DEBUG - 2018-11-13 09:15:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-13 09:15:15 --> Input Class Initialized
INFO - 2018-11-13 09:15:15 --> Language Class Initialized
INFO - 2018-11-13 09:15:15 --> Loader Class Initialized
INFO - 2018-11-13 09:15:15 --> Helper loaded: url_helper
INFO - 2018-11-13 09:15:15 --> Helper loaded: file_helper
INFO - 2018-11-13 09:15:15 --> Helper loaded: email_helper
INFO - 2018-11-13 09:15:15 --> Helper loaded: common_helper
INFO - 2018-11-13 09:15:15 --> Database Driver Class Initialized
DEBUG - 2018-11-13 09:15:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-13 09:15:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-13 09:15:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-13 09:15:15 --> Pagination Class Initialized
INFO - 2018-11-13 09:15:15 --> Helper loaded: form_helper
INFO - 2018-11-13 09:15:15 --> Form Validation Class Initialized
INFO - 2018-11-13 09:15:15 --> Model Class Initialized
INFO - 2018-11-13 09:15:15 --> Controller Class Initialized
INFO - 2018-11-13 09:15:15 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-13 09:15:15 --> Model Class Initialized
INFO - 2018-11-13 09:15:15 --> Model Class Initialized
INFO - 2018-11-13 09:15:15 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\template/header-menu.php
INFO - 2018-11-13 09:15:15 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\template/header.php
INFO - 2018-11-13 09:15:15 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\template/footer.php
INFO - 2018-11-13 09:15:15 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\index.php
INFO - 2018-11-13 09:15:15 --> Final output sent to browser
DEBUG - 2018-11-13 09:15:15 --> Total execution time: 0.0540
INFO - 2018-11-13 09:19:49 --> Config Class Initialized
INFO - 2018-11-13 09:19:49 --> Hooks Class Initialized
DEBUG - 2018-11-13 09:19:49 --> UTF-8 Support Enabled
INFO - 2018-11-13 09:19:49 --> Utf8 Class Initialized
INFO - 2018-11-13 09:19:49 --> URI Class Initialized
INFO - 2018-11-13 09:19:49 --> Router Class Initialized
INFO - 2018-11-13 09:19:49 --> Output Class Initialized
INFO - 2018-11-13 09:19:49 --> Security Class Initialized
DEBUG - 2018-11-13 09:19:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-13 09:19:49 --> Input Class Initialized
INFO - 2018-11-13 09:19:49 --> Language Class Initialized
ERROR - 2018-11-13 09:19:49 --> 404 Page Not Found: Pages_new_listinghtml/index
INFO - 2018-11-13 09:19:50 --> Config Class Initialized
INFO - 2018-11-13 09:19:50 --> Hooks Class Initialized
DEBUG - 2018-11-13 09:19:50 --> UTF-8 Support Enabled
INFO - 2018-11-13 09:19:50 --> Utf8 Class Initialized
INFO - 2018-11-13 09:19:50 --> URI Class Initialized
DEBUG - 2018-11-13 09:19:50 --> No URI present. Default controller set.
INFO - 2018-11-13 09:19:50 --> Router Class Initialized
INFO - 2018-11-13 09:19:50 --> Output Class Initialized
INFO - 2018-11-13 09:19:50 --> Security Class Initialized
DEBUG - 2018-11-13 09:19:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-13 09:19:50 --> Input Class Initialized
INFO - 2018-11-13 09:19:50 --> Language Class Initialized
INFO - 2018-11-13 09:19:50 --> Loader Class Initialized
INFO - 2018-11-13 09:19:50 --> Helper loaded: url_helper
INFO - 2018-11-13 09:19:50 --> Helper loaded: file_helper
INFO - 2018-11-13 09:19:50 --> Helper loaded: email_helper
INFO - 2018-11-13 09:19:50 --> Helper loaded: common_helper
INFO - 2018-11-13 09:19:50 --> Database Driver Class Initialized
DEBUG - 2018-11-13 09:19:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-13 09:19:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-13 09:19:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-13 09:19:50 --> Pagination Class Initialized
INFO - 2018-11-13 09:19:50 --> Helper loaded: form_helper
INFO - 2018-11-13 09:19:50 --> Form Validation Class Initialized
INFO - 2018-11-13 09:19:50 --> Model Class Initialized
INFO - 2018-11-13 09:19:50 --> Controller Class Initialized
INFO - 2018-11-13 09:19:50 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-13 09:19:50 --> Model Class Initialized
INFO - 2018-11-13 09:19:50 --> Model Class Initialized
INFO - 2018-11-13 09:19:50 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\template/header-menu.php
INFO - 2018-11-13 09:19:50 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\template/header.php
INFO - 2018-11-13 09:19:50 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\template/footer.php
INFO - 2018-11-13 09:19:50 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\index.php
INFO - 2018-11-13 09:19:50 --> Final output sent to browser
DEBUG - 2018-11-13 09:19:50 --> Total execution time: 0.0620
INFO - 2018-11-13 09:21:49 --> Config Class Initialized
INFO - 2018-11-13 09:21:49 --> Hooks Class Initialized
DEBUG - 2018-11-13 09:21:49 --> UTF-8 Support Enabled
INFO - 2018-11-13 09:21:49 --> Utf8 Class Initialized
INFO - 2018-11-13 09:21:49 --> URI Class Initialized
DEBUG - 2018-11-13 09:21:49 --> No URI present. Default controller set.
INFO - 2018-11-13 09:21:49 --> Router Class Initialized
INFO - 2018-11-13 09:21:49 --> Output Class Initialized
INFO - 2018-11-13 09:21:49 --> Security Class Initialized
DEBUG - 2018-11-13 09:21:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-13 09:21:49 --> Input Class Initialized
INFO - 2018-11-13 09:21:49 --> Language Class Initialized
INFO - 2018-11-13 09:21:49 --> Loader Class Initialized
INFO - 2018-11-13 09:21:49 --> Helper loaded: url_helper
INFO - 2018-11-13 09:21:49 --> Helper loaded: file_helper
INFO - 2018-11-13 09:21:49 --> Helper loaded: email_helper
INFO - 2018-11-13 09:21:49 --> Helper loaded: common_helper
INFO - 2018-11-13 09:21:49 --> Database Driver Class Initialized
DEBUG - 2018-11-13 09:21:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-13 09:21:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-13 09:21:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-13 09:21:49 --> Pagination Class Initialized
INFO - 2018-11-13 09:21:49 --> Helper loaded: form_helper
INFO - 2018-11-13 09:21:49 --> Form Validation Class Initialized
INFO - 2018-11-13 09:21:49 --> Model Class Initialized
INFO - 2018-11-13 09:21:49 --> Controller Class Initialized
INFO - 2018-11-13 09:21:49 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-13 09:21:49 --> Model Class Initialized
INFO - 2018-11-13 09:21:49 --> Model Class Initialized
INFO - 2018-11-13 09:21:49 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\template/header-menu.php
INFO - 2018-11-13 09:21:49 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\template/header.php
INFO - 2018-11-13 09:21:49 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\template/footer.php
INFO - 2018-11-13 09:21:49 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\index.php
INFO - 2018-11-13 09:21:49 --> Final output sent to browser
DEBUG - 2018-11-13 09:21:49 --> Total execution time: 0.0600
INFO - 2018-11-13 09:23:13 --> Config Class Initialized
INFO - 2018-11-13 09:23:13 --> Hooks Class Initialized
DEBUG - 2018-11-13 09:23:13 --> UTF-8 Support Enabled
INFO - 2018-11-13 09:23:13 --> Utf8 Class Initialized
INFO - 2018-11-13 09:23:13 --> URI Class Initialized
DEBUG - 2018-11-13 09:23:13 --> No URI present. Default controller set.
INFO - 2018-11-13 09:23:13 --> Router Class Initialized
INFO - 2018-11-13 09:23:13 --> Output Class Initialized
INFO - 2018-11-13 09:23:13 --> Security Class Initialized
DEBUG - 2018-11-13 09:23:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-13 09:23:13 --> Input Class Initialized
INFO - 2018-11-13 09:23:13 --> Language Class Initialized
INFO - 2018-11-13 09:23:13 --> Loader Class Initialized
INFO - 2018-11-13 09:23:13 --> Helper loaded: url_helper
INFO - 2018-11-13 09:23:13 --> Helper loaded: file_helper
INFO - 2018-11-13 09:23:13 --> Helper loaded: email_helper
INFO - 2018-11-13 09:23:13 --> Helper loaded: common_helper
INFO - 2018-11-13 09:23:13 --> Database Driver Class Initialized
DEBUG - 2018-11-13 09:23:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-13 09:23:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-13 09:23:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-13 09:23:13 --> Pagination Class Initialized
INFO - 2018-11-13 09:23:13 --> Helper loaded: form_helper
INFO - 2018-11-13 09:23:13 --> Form Validation Class Initialized
INFO - 2018-11-13 09:23:13 --> Model Class Initialized
INFO - 2018-11-13 09:23:13 --> Controller Class Initialized
INFO - 2018-11-13 09:23:13 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-13 09:23:13 --> Model Class Initialized
INFO - 2018-11-13 09:23:13 --> Model Class Initialized
INFO - 2018-11-13 09:23:13 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\template/header-menu.php
INFO - 2018-11-13 09:23:13 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\template/header.php
INFO - 2018-11-13 09:23:13 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\template/footer.php
INFO - 2018-11-13 09:23:13 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\index.php
INFO - 2018-11-13 09:23:13 --> Final output sent to browser
DEBUG - 2018-11-13 09:23:13 --> Total execution time: 0.0590
INFO - 2018-11-13 09:24:12 --> Config Class Initialized
INFO - 2018-11-13 09:24:12 --> Hooks Class Initialized
DEBUG - 2018-11-13 09:24:12 --> UTF-8 Support Enabled
INFO - 2018-11-13 09:24:12 --> Utf8 Class Initialized
INFO - 2018-11-13 09:24:12 --> URI Class Initialized
DEBUG - 2018-11-13 09:24:12 --> No URI present. Default controller set.
INFO - 2018-11-13 09:24:12 --> Router Class Initialized
INFO - 2018-11-13 09:24:12 --> Output Class Initialized
INFO - 2018-11-13 09:24:12 --> Security Class Initialized
DEBUG - 2018-11-13 09:24:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-13 09:24:12 --> Input Class Initialized
INFO - 2018-11-13 09:24:12 --> Language Class Initialized
INFO - 2018-11-13 09:24:12 --> Loader Class Initialized
INFO - 2018-11-13 09:24:12 --> Helper loaded: url_helper
INFO - 2018-11-13 09:24:12 --> Helper loaded: file_helper
INFO - 2018-11-13 09:24:12 --> Helper loaded: email_helper
INFO - 2018-11-13 09:24:12 --> Helper loaded: common_helper
INFO - 2018-11-13 09:24:12 --> Database Driver Class Initialized
DEBUG - 2018-11-13 09:24:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-13 09:24:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-13 09:24:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-13 09:24:12 --> Pagination Class Initialized
INFO - 2018-11-13 09:24:12 --> Helper loaded: form_helper
INFO - 2018-11-13 09:24:12 --> Form Validation Class Initialized
INFO - 2018-11-13 09:24:12 --> Model Class Initialized
INFO - 2018-11-13 09:24:12 --> Controller Class Initialized
INFO - 2018-11-13 09:24:12 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-13 09:24:12 --> Model Class Initialized
INFO - 2018-11-13 09:24:12 --> Model Class Initialized
INFO - 2018-11-13 09:24:12 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\template/header-menu.php
INFO - 2018-11-13 09:24:12 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\template/header.php
INFO - 2018-11-13 09:24:12 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\template/footer.php
INFO - 2018-11-13 09:24:12 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\index.php
INFO - 2018-11-13 09:24:12 --> Final output sent to browser
DEBUG - 2018-11-13 09:24:12 --> Total execution time: 0.0520
INFO - 2018-11-13 09:25:25 --> Config Class Initialized
INFO - 2018-11-13 09:25:25 --> Hooks Class Initialized
DEBUG - 2018-11-13 09:25:25 --> UTF-8 Support Enabled
INFO - 2018-11-13 09:25:25 --> Utf8 Class Initialized
INFO - 2018-11-13 09:25:25 --> URI Class Initialized
DEBUG - 2018-11-13 09:25:25 --> No URI present. Default controller set.
INFO - 2018-11-13 09:25:25 --> Router Class Initialized
INFO - 2018-11-13 09:25:25 --> Output Class Initialized
INFO - 2018-11-13 09:25:25 --> Security Class Initialized
DEBUG - 2018-11-13 09:25:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-13 09:25:25 --> Input Class Initialized
INFO - 2018-11-13 09:25:25 --> Language Class Initialized
INFO - 2018-11-13 09:25:25 --> Loader Class Initialized
INFO - 2018-11-13 09:25:25 --> Helper loaded: url_helper
INFO - 2018-11-13 09:25:25 --> Helper loaded: file_helper
INFO - 2018-11-13 09:25:25 --> Helper loaded: email_helper
INFO - 2018-11-13 09:25:25 --> Helper loaded: common_helper
INFO - 2018-11-13 09:25:25 --> Database Driver Class Initialized
DEBUG - 2018-11-13 09:25:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-13 09:25:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-13 09:25:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-13 09:25:25 --> Pagination Class Initialized
INFO - 2018-11-13 09:25:25 --> Helper loaded: form_helper
INFO - 2018-11-13 09:25:25 --> Form Validation Class Initialized
INFO - 2018-11-13 09:25:25 --> Model Class Initialized
INFO - 2018-11-13 09:25:25 --> Controller Class Initialized
INFO - 2018-11-13 09:25:25 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-13 09:25:25 --> Model Class Initialized
INFO - 2018-11-13 09:25:25 --> Model Class Initialized
INFO - 2018-11-13 09:25:25 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\template/header-menu.php
INFO - 2018-11-13 09:25:25 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\template/header.php
INFO - 2018-11-13 09:25:25 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\template/footer.php
INFO - 2018-11-13 09:25:25 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\index.php
INFO - 2018-11-13 09:25:25 --> Final output sent to browser
DEBUG - 2018-11-13 09:25:25 --> Total execution time: 0.0490
INFO - 2018-11-13 09:35:56 --> Config Class Initialized
INFO - 2018-11-13 09:35:56 --> Hooks Class Initialized
DEBUG - 2018-11-13 09:35:56 --> UTF-8 Support Enabled
INFO - 2018-11-13 09:35:56 --> Utf8 Class Initialized
INFO - 2018-11-13 09:35:56 --> URI Class Initialized
DEBUG - 2018-11-13 09:35:56 --> No URI present. Default controller set.
INFO - 2018-11-13 09:35:56 --> Router Class Initialized
INFO - 2018-11-13 09:35:56 --> Output Class Initialized
INFO - 2018-11-13 09:35:56 --> Security Class Initialized
DEBUG - 2018-11-13 09:35:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-13 09:35:56 --> Input Class Initialized
INFO - 2018-11-13 09:35:56 --> Language Class Initialized
INFO - 2018-11-13 09:35:56 --> Loader Class Initialized
INFO - 2018-11-13 09:35:56 --> Helper loaded: url_helper
INFO - 2018-11-13 09:35:56 --> Helper loaded: file_helper
INFO - 2018-11-13 09:35:56 --> Helper loaded: email_helper
INFO - 2018-11-13 09:35:56 --> Helper loaded: common_helper
INFO - 2018-11-13 09:35:56 --> Database Driver Class Initialized
ERROR - 2018-11-13 09:35:56 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'admin'@'admin-PC' (using password: YES) C:\xampp\htdocs\wetinuneed\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2018-11-13 09:35:56 --> Unable to connect to the database
INFO - 2018-11-13 09:35:56 --> Language file loaded: language/english/db_lang.php
INFO - 2018-11-13 09:38:36 --> Config Class Initialized
INFO - 2018-11-13 09:38:36 --> Hooks Class Initialized
DEBUG - 2018-11-13 09:38:36 --> UTF-8 Support Enabled
INFO - 2018-11-13 09:38:36 --> Utf8 Class Initialized
INFO - 2018-11-13 09:38:36 --> URI Class Initialized
DEBUG - 2018-11-13 09:38:36 --> No URI present. Default controller set.
INFO - 2018-11-13 09:38:36 --> Router Class Initialized
INFO - 2018-11-13 09:38:36 --> Output Class Initialized
INFO - 2018-11-13 09:38:36 --> Security Class Initialized
DEBUG - 2018-11-13 09:38:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-13 09:38:36 --> Input Class Initialized
INFO - 2018-11-13 09:38:36 --> Language Class Initialized
INFO - 2018-11-13 09:38:36 --> Loader Class Initialized
INFO - 2018-11-13 09:38:36 --> Helper loaded: url_helper
INFO - 2018-11-13 09:38:36 --> Helper loaded: file_helper
INFO - 2018-11-13 09:38:36 --> Helper loaded: email_helper
INFO - 2018-11-13 09:38:36 --> Helper loaded: common_helper
INFO - 2018-11-13 09:38:36 --> Database Driver Class Initialized
ERROR - 2018-11-13 09:38:36 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'admin'@'admin-PC' (using password: YES) C:\xampp\htdocs\wetinuneed\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2018-11-13 09:38:36 --> Unable to connect to the database
INFO - 2018-11-13 09:38:36 --> Language file loaded: language/english/db_lang.php
INFO - 2018-11-13 10:29:56 --> Config Class Initialized
INFO - 2018-11-13 10:29:56 --> Hooks Class Initialized
DEBUG - 2018-11-13 10:29:56 --> UTF-8 Support Enabled
INFO - 2018-11-13 10:29:56 --> Utf8 Class Initialized
INFO - 2018-11-13 10:29:56 --> URI Class Initialized
DEBUG - 2018-11-13 10:29:56 --> No URI present. Default controller set.
INFO - 2018-11-13 10:29:56 --> Router Class Initialized
INFO - 2018-11-13 10:29:56 --> Output Class Initialized
INFO - 2018-11-13 10:29:56 --> Security Class Initialized
DEBUG - 2018-11-13 10:29:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-13 10:29:56 --> Input Class Initialized
INFO - 2018-11-13 10:29:56 --> Language Class Initialized
INFO - 2018-11-13 10:29:56 --> Loader Class Initialized
INFO - 2018-11-13 10:29:56 --> Helper loaded: url_helper
INFO - 2018-11-13 10:29:56 --> Helper loaded: file_helper
INFO - 2018-11-13 10:29:56 --> Helper loaded: email_helper
INFO - 2018-11-13 10:29:56 --> Helper loaded: common_helper
INFO - 2018-11-13 10:29:56 --> Database Driver Class Initialized
DEBUG - 2018-11-13 10:29:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-13 10:29:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-13 10:29:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-13 10:29:56 --> Pagination Class Initialized
INFO - 2018-11-13 10:29:56 --> Helper loaded: form_helper
INFO - 2018-11-13 10:29:56 --> Form Validation Class Initialized
INFO - 2018-11-13 10:29:56 --> Model Class Initialized
INFO - 2018-11-13 10:29:56 --> Controller Class Initialized
INFO - 2018-11-13 10:29:56 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-13 10:29:56 --> Model Class Initialized
INFO - 2018-11-13 10:29:56 --> Model Class Initialized
INFO - 2018-11-13 10:29:56 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\template/header-menu.php
INFO - 2018-11-13 10:29:56 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\template/header.php
INFO - 2018-11-13 10:29:56 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\template/footer.php
INFO - 2018-11-13 10:29:56 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\index.php
INFO - 2018-11-13 10:29:56 --> Final output sent to browser
DEBUG - 2018-11-13 10:29:56 --> Total execution time: 0.0800
INFO - 2018-11-13 10:33:11 --> Config Class Initialized
INFO - 2018-11-13 10:33:11 --> Hooks Class Initialized
DEBUG - 2018-11-13 10:33:11 --> UTF-8 Support Enabled
INFO - 2018-11-13 10:33:11 --> Utf8 Class Initialized
INFO - 2018-11-13 10:33:11 --> URI Class Initialized
DEBUG - 2018-11-13 10:33:11 --> No URI present. Default controller set.
INFO - 2018-11-13 10:33:11 --> Router Class Initialized
INFO - 2018-11-13 10:33:11 --> Output Class Initialized
INFO - 2018-11-13 10:33:11 --> Security Class Initialized
DEBUG - 2018-11-13 10:33:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-13 10:33:11 --> Input Class Initialized
INFO - 2018-11-13 10:33:11 --> Language Class Initialized
INFO - 2018-11-13 10:33:11 --> Loader Class Initialized
INFO - 2018-11-13 10:33:11 --> Helper loaded: url_helper
INFO - 2018-11-13 10:33:11 --> Helper loaded: file_helper
INFO - 2018-11-13 10:33:11 --> Helper loaded: email_helper
INFO - 2018-11-13 10:33:11 --> Helper loaded: common_helper
INFO - 2018-11-13 10:33:11 --> Database Driver Class Initialized
DEBUG - 2018-11-13 10:33:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-13 10:33:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-13 10:33:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-13 10:33:11 --> Pagination Class Initialized
INFO - 2018-11-13 10:33:11 --> Helper loaded: form_helper
INFO - 2018-11-13 10:33:11 --> Form Validation Class Initialized
INFO - 2018-11-13 10:33:11 --> Model Class Initialized
INFO - 2018-11-13 10:33:11 --> Controller Class Initialized
INFO - 2018-11-13 10:33:11 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-13 10:33:11 --> Model Class Initialized
INFO - 2018-11-13 10:33:11 --> Model Class Initialized
INFO - 2018-11-13 10:33:11 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\template/header-menu.php
INFO - 2018-11-13 10:33:11 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\template/header.php
INFO - 2018-11-13 10:33:11 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\template/footer.php
INFO - 2018-11-13 10:33:11 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\index.php
INFO - 2018-11-13 10:33:11 --> Final output sent to browser
DEBUG - 2018-11-13 10:33:11 --> Total execution time: 0.0500
INFO - 2018-11-13 10:39:13 --> Config Class Initialized
INFO - 2018-11-13 10:39:13 --> Hooks Class Initialized
DEBUG - 2018-11-13 10:39:13 --> UTF-8 Support Enabled
INFO - 2018-11-13 10:39:13 --> Utf8 Class Initialized
INFO - 2018-11-13 10:39:13 --> URI Class Initialized
DEBUG - 2018-11-13 10:39:13 --> No URI present. Default controller set.
INFO - 2018-11-13 10:39:13 --> Router Class Initialized
INFO - 2018-11-13 10:39:13 --> Output Class Initialized
INFO - 2018-11-13 10:39:13 --> Security Class Initialized
DEBUG - 2018-11-13 10:39:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-13 10:39:13 --> Input Class Initialized
INFO - 2018-11-13 10:39:13 --> Language Class Initialized
INFO - 2018-11-13 10:39:13 --> Loader Class Initialized
INFO - 2018-11-13 10:39:13 --> Helper loaded: url_helper
INFO - 2018-11-13 10:39:13 --> Helper loaded: file_helper
INFO - 2018-11-13 10:39:13 --> Helper loaded: email_helper
INFO - 2018-11-13 10:39:13 --> Helper loaded: common_helper
INFO - 2018-11-13 10:39:13 --> Database Driver Class Initialized
DEBUG - 2018-11-13 10:39:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-13 10:39:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-13 10:39:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-13 10:39:13 --> Pagination Class Initialized
INFO - 2018-11-13 10:39:13 --> Helper loaded: form_helper
INFO - 2018-11-13 10:39:13 --> Form Validation Class Initialized
INFO - 2018-11-13 10:39:13 --> Model Class Initialized
INFO - 2018-11-13 10:39:13 --> Controller Class Initialized
INFO - 2018-11-13 10:39:13 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-13 10:39:13 --> Model Class Initialized
INFO - 2018-11-13 10:39:13 --> Model Class Initialized
INFO - 2018-11-13 10:39:13 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\template/header-menu.php
INFO - 2018-11-13 10:39:13 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\template/header.php
INFO - 2018-11-13 10:39:13 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\template/footer.php
INFO - 2018-11-13 10:39:13 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\index.php
INFO - 2018-11-13 10:39:13 --> Final output sent to browser
DEBUG - 2018-11-13 10:39:13 --> Total execution time: 0.0660
INFO - 2018-11-13 10:40:06 --> Config Class Initialized
INFO - 2018-11-13 10:40:06 --> Hooks Class Initialized
DEBUG - 2018-11-13 10:40:06 --> UTF-8 Support Enabled
INFO - 2018-11-13 10:40:06 --> Utf8 Class Initialized
INFO - 2018-11-13 10:40:06 --> URI Class Initialized
DEBUG - 2018-11-13 10:40:06 --> No URI present. Default controller set.
INFO - 2018-11-13 10:40:06 --> Router Class Initialized
INFO - 2018-11-13 10:40:06 --> Output Class Initialized
INFO - 2018-11-13 10:40:06 --> Security Class Initialized
DEBUG - 2018-11-13 10:40:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-13 10:40:06 --> Input Class Initialized
INFO - 2018-11-13 10:40:06 --> Language Class Initialized
INFO - 2018-11-13 10:40:06 --> Loader Class Initialized
INFO - 2018-11-13 10:40:06 --> Helper loaded: url_helper
INFO - 2018-11-13 10:40:06 --> Helper loaded: file_helper
INFO - 2018-11-13 10:40:06 --> Helper loaded: email_helper
INFO - 2018-11-13 10:40:06 --> Helper loaded: common_helper
INFO - 2018-11-13 10:40:06 --> Database Driver Class Initialized
DEBUG - 2018-11-13 10:40:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-13 10:40:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-13 10:40:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-13 10:40:06 --> Pagination Class Initialized
INFO - 2018-11-13 10:40:06 --> Helper loaded: form_helper
INFO - 2018-11-13 10:40:06 --> Form Validation Class Initialized
INFO - 2018-11-13 10:40:06 --> Model Class Initialized
INFO - 2018-11-13 10:40:06 --> Controller Class Initialized
INFO - 2018-11-13 10:40:06 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-13 10:40:06 --> Model Class Initialized
INFO - 2018-11-13 10:40:06 --> Model Class Initialized
INFO - 2018-11-13 10:40:06 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\template/header-menu.php
INFO - 2018-11-13 10:40:06 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\template/header.php
INFO - 2018-11-13 10:40:06 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\template/footer.php
INFO - 2018-11-13 10:40:06 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\index.php
INFO - 2018-11-13 10:40:06 --> Final output sent to browser
DEBUG - 2018-11-13 10:40:06 --> Total execution time: 0.0540

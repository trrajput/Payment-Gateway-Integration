<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2018-11-24 05:56:00 --> Config Class Initialized
INFO - 2018-11-24 05:56:00 --> Hooks Class Initialized
DEBUG - 2018-11-24 05:56:00 --> UTF-8 Support Enabled
INFO - 2018-11-24 05:56:00 --> Utf8 Class Initialized
INFO - 2018-11-24 05:56:00 --> URI Class Initialized
INFO - 2018-11-24 05:56:00 --> Router Class Initialized
INFO - 2018-11-24 05:56:00 --> Output Class Initialized
INFO - 2018-11-24 05:56:00 --> Security Class Initialized
DEBUG - 2018-11-24 05:56:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-24 05:56:00 --> Input Class Initialized
INFO - 2018-11-24 05:56:00 --> Language Class Initialized
INFO - 2018-11-24 05:56:00 --> Loader Class Initialized
INFO - 2018-11-24 05:56:00 --> Helper loaded: url_helper
INFO - 2018-11-24 05:56:00 --> Helper loaded: file_helper
INFO - 2018-11-24 05:56:00 --> Helper loaded: email_helper
INFO - 2018-11-24 05:56:00 --> Helper loaded: common_helper
INFO - 2018-11-24 05:56:00 --> Database Driver Class Initialized
DEBUG - 2018-11-24 05:56:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-24 05:56:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-24 05:56:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-24 05:56:00 --> Pagination Class Initialized
INFO - 2018-11-24 05:56:00 --> Helper loaded: form_helper
INFO - 2018-11-24 05:56:00 --> Form Validation Class Initialized
INFO - 2018-11-24 05:56:00 --> Model Class Initialized
INFO - 2018-11-24 05:56:00 --> Controller Class Initialized
INFO - 2018-11-24 05:56:00 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-24 05:56:00 --> Model Class Initialized
INFO - 2018-11-24 05:56:00 --> Model Class Initialized
INFO - 2018-11-24 05:56:00 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/index.php
INFO - 2018-11-24 05:56:00 --> Final output sent to browser
DEBUG - 2018-11-24 05:56:00 --> Total execution time: 0.0910
INFO - 2018-11-24 05:56:14 --> Config Class Initialized
INFO - 2018-11-24 05:56:14 --> Hooks Class Initialized
DEBUG - 2018-11-24 05:56:14 --> UTF-8 Support Enabled
INFO - 2018-11-24 05:56:14 --> Utf8 Class Initialized
INFO - 2018-11-24 05:56:14 --> URI Class Initialized
INFO - 2018-11-24 05:56:14 --> Router Class Initialized
INFO - 2018-11-24 05:56:14 --> Output Class Initialized
INFO - 2018-11-24 05:56:14 --> Security Class Initialized
DEBUG - 2018-11-24 05:56:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-24 05:56:14 --> Input Class Initialized
INFO - 2018-11-24 05:56:14 --> Language Class Initialized
INFO - 2018-11-24 05:56:14 --> Loader Class Initialized
INFO - 2018-11-24 05:56:14 --> Helper loaded: url_helper
INFO - 2018-11-24 05:56:14 --> Helper loaded: file_helper
INFO - 2018-11-24 05:56:14 --> Helper loaded: email_helper
INFO - 2018-11-24 05:56:14 --> Helper loaded: common_helper
INFO - 2018-11-24 05:56:14 --> Database Driver Class Initialized
DEBUG - 2018-11-24 05:56:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-24 05:56:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-24 05:56:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-24 05:56:14 --> Pagination Class Initialized
INFO - 2018-11-24 05:56:14 --> Helper loaded: form_helper
INFO - 2018-11-24 05:56:14 --> Form Validation Class Initialized
INFO - 2018-11-24 05:56:14 --> Model Class Initialized
INFO - 2018-11-24 05:56:14 --> Controller Class Initialized
INFO - 2018-11-24 05:56:14 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-24 05:56:14 --> Model Class Initialized
INFO - 2018-11-24 05:56:14 --> Model Class Initialized
ERROR - 2018-11-24 05:56:14 --> Severity: Notice --> Undefined index: remember_me C:\xampp\htdocs\wetinuneed\application\controllers\admin\Admin.php 77
INFO - 2018-11-24 05:56:14 --> Config Class Initialized
INFO - 2018-11-24 05:56:14 --> Hooks Class Initialized
DEBUG - 2018-11-24 05:56:14 --> UTF-8 Support Enabled
INFO - 2018-11-24 05:56:14 --> Utf8 Class Initialized
INFO - 2018-11-24 05:56:14 --> URI Class Initialized
INFO - 2018-11-24 05:56:14 --> Router Class Initialized
INFO - 2018-11-24 05:56:14 --> Output Class Initialized
INFO - 2018-11-24 05:56:14 --> Security Class Initialized
DEBUG - 2018-11-24 05:56:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-24 05:56:14 --> Input Class Initialized
INFO - 2018-11-24 05:56:14 --> Language Class Initialized
INFO - 2018-11-24 05:56:14 --> Loader Class Initialized
INFO - 2018-11-24 05:56:14 --> Helper loaded: url_helper
INFO - 2018-11-24 05:56:14 --> Helper loaded: file_helper
INFO - 2018-11-24 05:56:14 --> Helper loaded: email_helper
INFO - 2018-11-24 05:56:14 --> Helper loaded: common_helper
INFO - 2018-11-24 05:56:14 --> Database Driver Class Initialized
DEBUG - 2018-11-24 05:56:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-24 05:56:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-24 05:56:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-24 05:56:14 --> Pagination Class Initialized
INFO - 2018-11-24 05:56:14 --> Helper loaded: form_helper
INFO - 2018-11-24 05:56:14 --> Form Validation Class Initialized
INFO - 2018-11-24 05:56:14 --> Model Class Initialized
INFO - 2018-11-24 05:56:14 --> Controller Class Initialized
INFO - 2018-11-24 05:56:14 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-24 05:56:14 --> Model Class Initialized
INFO - 2018-11-24 05:56:14 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-24 05:56:14 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/sidebar.php
INFO - 2018-11-24 05:56:14 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/right-sidebar.php
INFO - 2018-11-24 05:56:14 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/footer.php
INFO - 2018-11-24 05:56:14 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/dashboard.php
INFO - 2018-11-24 05:56:14 --> Final output sent to browser
DEBUG - 2018-11-24 05:56:14 --> Total execution time: 0.0430
INFO - 2018-11-24 06:10:31 --> Config Class Initialized
INFO - 2018-11-24 06:10:31 --> Hooks Class Initialized
DEBUG - 2018-11-24 06:10:31 --> UTF-8 Support Enabled
INFO - 2018-11-24 06:10:31 --> Utf8 Class Initialized
INFO - 2018-11-24 06:10:31 --> URI Class Initialized
INFO - 2018-11-24 06:10:31 --> Router Class Initialized
INFO - 2018-11-24 06:10:31 --> Output Class Initialized
INFO - 2018-11-24 06:10:31 --> Security Class Initialized
DEBUG - 2018-11-24 06:10:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-24 06:10:31 --> Input Class Initialized
INFO - 2018-11-24 06:10:31 --> Language Class Initialized
ERROR - 2018-11-24 06:10:31 --> 404 Page Not Found: PaytmKit/TxnTest.php
INFO - 2018-11-24 06:10:47 --> Config Class Initialized
INFO - 2018-11-24 06:10:47 --> Hooks Class Initialized
DEBUG - 2018-11-24 06:10:47 --> UTF-8 Support Enabled
INFO - 2018-11-24 06:10:47 --> Utf8 Class Initialized
INFO - 2018-11-24 06:10:47 --> URI Class Initialized
INFO - 2018-11-24 06:10:47 --> Router Class Initialized
INFO - 2018-11-24 06:10:47 --> Output Class Initialized
INFO - 2018-11-24 06:10:47 --> Security Class Initialized
DEBUG - 2018-11-24 06:10:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-24 06:10:47 --> Input Class Initialized
INFO - 2018-11-24 06:10:47 --> Language Class Initialized
ERROR - 2018-11-24 06:10:47 --> 404 Page Not Found: PaytmKit/TxnTest.php
INFO - 2018-11-24 06:11:12 --> Config Class Initialized
INFO - 2018-11-24 06:11:12 --> Hooks Class Initialized
DEBUG - 2018-11-24 06:11:12 --> UTF-8 Support Enabled
INFO - 2018-11-24 06:11:12 --> Utf8 Class Initialized
INFO - 2018-11-24 06:11:12 --> URI Class Initialized
INFO - 2018-11-24 06:11:12 --> Router Class Initialized
INFO - 2018-11-24 06:11:12 --> Output Class Initialized
INFO - 2018-11-24 06:11:12 --> Security Class Initialized
DEBUG - 2018-11-24 06:11:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-24 06:11:12 --> Input Class Initialized
INFO - 2018-11-24 06:11:12 --> Language Class Initialized
ERROR - 2018-11-24 06:11:12 --> 404 Page Not Found: PaytmKit/TxnTest.php
INFO - 2018-11-24 07:35:16 --> Config Class Initialized
INFO - 2018-11-24 07:35:16 --> Hooks Class Initialized
DEBUG - 2018-11-24 07:35:16 --> UTF-8 Support Enabled
INFO - 2018-11-24 07:35:16 --> Utf8 Class Initialized
INFO - 2018-11-24 07:35:16 --> URI Class Initialized
INFO - 2018-11-24 07:35:16 --> Router Class Initialized
INFO - 2018-11-24 07:35:16 --> Output Class Initialized
INFO - 2018-11-24 07:35:16 --> Security Class Initialized
DEBUG - 2018-11-24 07:35:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-24 07:35:16 --> Input Class Initialized
INFO - 2018-11-24 07:35:16 --> Language Class Initialized
ERROR - 2018-11-24 07:35:16 --> 404 Page Not Found: Testphp/index
INFO - 2018-11-24 07:35:33 --> Config Class Initialized
INFO - 2018-11-24 07:35:33 --> Hooks Class Initialized
DEBUG - 2018-11-24 07:35:33 --> UTF-8 Support Enabled
INFO - 2018-11-24 07:35:33 --> Utf8 Class Initialized
INFO - 2018-11-24 07:35:33 --> URI Class Initialized
INFO - 2018-11-24 07:35:33 --> Router Class Initialized
INFO - 2018-11-24 07:35:33 --> Output Class Initialized
INFO - 2018-11-24 07:35:33 --> Security Class Initialized
DEBUG - 2018-11-24 07:35:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-24 07:35:33 --> Input Class Initialized
INFO - 2018-11-24 07:35:33 --> Language Class Initialized
ERROR - 2018-11-24 07:35:33 --> 404 Page Not Found: Testphp/index
INFO - 2018-11-24 07:35:51 --> Config Class Initialized
INFO - 2018-11-24 07:35:51 --> Hooks Class Initialized
DEBUG - 2018-11-24 07:35:51 --> UTF-8 Support Enabled
INFO - 2018-11-24 07:35:51 --> Utf8 Class Initialized
INFO - 2018-11-24 07:35:51 --> URI Class Initialized
INFO - 2018-11-24 07:35:51 --> Router Class Initialized
INFO - 2018-11-24 07:35:51 --> Output Class Initialized
INFO - 2018-11-24 07:35:51 --> Security Class Initialized
DEBUG - 2018-11-24 07:35:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-24 07:35:51 --> Input Class Initialized
INFO - 2018-11-24 07:35:51 --> Language Class Initialized
ERROR - 2018-11-24 07:35:51 --> 404 Page Not Found: Testphp/index
INFO - 2018-11-24 07:36:06 --> Config Class Initialized
INFO - 2018-11-24 07:36:06 --> Hooks Class Initialized
DEBUG - 2018-11-24 07:36:06 --> UTF-8 Support Enabled
INFO - 2018-11-24 07:36:06 --> Utf8 Class Initialized
INFO - 2018-11-24 07:36:06 --> URI Class Initialized
INFO - 2018-11-24 07:36:06 --> Router Class Initialized
INFO - 2018-11-24 07:36:06 --> Output Class Initialized
INFO - 2018-11-24 07:36:06 --> Security Class Initialized
DEBUG - 2018-11-24 07:36:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-24 07:36:06 --> Input Class Initialized
INFO - 2018-11-24 07:36:06 --> Language Class Initialized
ERROR - 2018-11-24 07:36:06 --> 404 Page Not Found: Testphp/index
INFO - 2018-11-24 07:36:31 --> Config Class Initialized
INFO - 2018-11-24 07:36:31 --> Hooks Class Initialized
DEBUG - 2018-11-24 07:36:31 --> UTF-8 Support Enabled
INFO - 2018-11-24 07:36:31 --> Utf8 Class Initialized
INFO - 2018-11-24 07:36:31 --> URI Class Initialized
INFO - 2018-11-24 07:36:31 --> Router Class Initialized
INFO - 2018-11-24 07:36:31 --> Output Class Initialized
INFO - 2018-11-24 07:36:31 --> Security Class Initialized
DEBUG - 2018-11-24 07:36:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-24 07:36:31 --> Input Class Initialized
INFO - 2018-11-24 07:36:31 --> Language Class Initialized
ERROR - 2018-11-24 07:36:31 --> 404 Page Not Found: Testphp/index
INFO - 2018-11-24 07:36:53 --> Config Class Initialized
INFO - 2018-11-24 07:36:53 --> Hooks Class Initialized
DEBUG - 2018-11-24 07:36:53 --> UTF-8 Support Enabled
INFO - 2018-11-24 07:36:53 --> Utf8 Class Initialized
INFO - 2018-11-24 07:36:53 --> URI Class Initialized
INFO - 2018-11-24 07:36:53 --> Router Class Initialized
INFO - 2018-11-24 07:36:53 --> Output Class Initialized
INFO - 2018-11-24 07:36:53 --> Security Class Initialized
DEBUG - 2018-11-24 07:36:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-24 07:36:53 --> Input Class Initialized
INFO - 2018-11-24 07:36:53 --> Language Class Initialized
ERROR - 2018-11-24 07:36:53 --> 404 Page Not Found: Testphp/index
INFO - 2018-11-24 10:31:10 --> Config Class Initialized
INFO - 2018-11-24 10:31:10 --> Hooks Class Initialized
DEBUG - 2018-11-24 10:31:10 --> UTF-8 Support Enabled
INFO - 2018-11-24 10:31:10 --> Utf8 Class Initialized
INFO - 2018-11-24 10:31:10 --> URI Class Initialized
DEBUG - 2018-11-24 10:31:10 --> No URI present. Default controller set.
INFO - 2018-11-24 10:31:10 --> Router Class Initialized
INFO - 2018-11-24 10:31:10 --> Output Class Initialized
INFO - 2018-11-24 10:31:10 --> Security Class Initialized
DEBUG - 2018-11-24 10:31:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-24 10:31:10 --> Input Class Initialized
INFO - 2018-11-24 10:31:10 --> Language Class Initialized
INFO - 2018-11-24 10:31:10 --> Loader Class Initialized
INFO - 2018-11-24 10:31:10 --> Helper loaded: url_helper
INFO - 2018-11-24 10:31:10 --> Helper loaded: file_helper
INFO - 2018-11-24 10:31:10 --> Helper loaded: email_helper
INFO - 2018-11-24 10:31:10 --> Helper loaded: common_helper
INFO - 2018-11-24 10:31:10 --> Database Driver Class Initialized
DEBUG - 2018-11-24 10:31:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-24 10:31:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-24 10:31:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-24 10:31:10 --> Pagination Class Initialized
INFO - 2018-11-24 10:31:11 --> Helper loaded: form_helper
INFO - 2018-11-24 10:31:11 --> Form Validation Class Initialized
INFO - 2018-11-24 10:31:11 --> Model Class Initialized
INFO - 2018-11-24 10:31:11 --> Controller Class Initialized
INFO - 2018-11-24 10:31:11 --> Model Class Initialized
INFO - 2018-11-24 10:31:11 --> Model Class Initialized
INFO - 2018-11-24 10:31:11 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\template/header-menu.php
INFO - 2018-11-24 10:31:11 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\template/header.php
INFO - 2018-11-24 10:31:11 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\template/footer.php
INFO - 2018-11-24 10:31:11 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\index.php
INFO - 2018-11-24 10:31:11 --> Final output sent to browser
DEBUG - 2018-11-24 10:31:11 --> Total execution time: 0.8891
INFO - 2018-11-24 10:34:12 --> Config Class Initialized
INFO - 2018-11-24 10:34:12 --> Hooks Class Initialized
DEBUG - 2018-11-24 10:34:12 --> UTF-8 Support Enabled
INFO - 2018-11-24 10:34:12 --> Utf8 Class Initialized
INFO - 2018-11-24 10:34:12 --> URI Class Initialized
DEBUG - 2018-11-24 10:34:12 --> No URI present. Default controller set.
INFO - 2018-11-24 10:34:12 --> Router Class Initialized
INFO - 2018-11-24 10:34:12 --> Output Class Initialized
INFO - 2018-11-24 10:34:12 --> Security Class Initialized
DEBUG - 2018-11-24 10:34:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-24 10:34:12 --> Input Class Initialized
INFO - 2018-11-24 10:34:12 --> Language Class Initialized
INFO - 2018-11-24 10:34:12 --> Loader Class Initialized
INFO - 2018-11-24 10:34:12 --> Helper loaded: url_helper
INFO - 2018-11-24 10:34:12 --> Helper loaded: file_helper
INFO - 2018-11-24 10:34:12 --> Helper loaded: email_helper
INFO - 2018-11-24 10:34:12 --> Helper loaded: common_helper
INFO - 2018-11-24 10:34:12 --> Database Driver Class Initialized
DEBUG - 2018-11-24 10:34:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-24 10:34:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-24 10:34:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-24 10:34:12 --> Pagination Class Initialized
INFO - 2018-11-24 10:34:12 --> Helper loaded: form_helper
INFO - 2018-11-24 10:34:12 --> Form Validation Class Initialized
INFO - 2018-11-24 10:34:12 --> Model Class Initialized
INFO - 2018-11-24 10:34:12 --> Controller Class Initialized
INFO - 2018-11-24 10:34:12 --> Model Class Initialized
INFO - 2018-11-24 10:34:12 --> Model Class Initialized
INFO - 2018-11-24 10:34:12 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\template/header-menu.php
INFO - 2018-11-24 10:34:12 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\template/header.php
INFO - 2018-11-24 10:34:12 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\template/footer.php
INFO - 2018-11-24 10:34:12 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\index.php
INFO - 2018-11-24 10:34:12 --> Final output sent to browser
DEBUG - 2018-11-24 10:34:12 --> Total execution time: 0.1500
INFO - 2018-11-24 10:49:34 --> Config Class Initialized
INFO - 2018-11-24 10:49:34 --> Hooks Class Initialized
DEBUG - 2018-11-24 10:49:34 --> UTF-8 Support Enabled
INFO - 2018-11-24 10:49:34 --> Utf8 Class Initialized
INFO - 2018-11-24 10:49:34 --> URI Class Initialized
DEBUG - 2018-11-24 10:49:34 --> No URI present. Default controller set.
INFO - 2018-11-24 10:49:34 --> Router Class Initialized
INFO - 2018-11-24 10:49:34 --> Output Class Initialized
INFO - 2018-11-24 10:49:34 --> Security Class Initialized
DEBUG - 2018-11-24 10:49:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-24 10:49:34 --> Input Class Initialized
INFO - 2018-11-24 10:49:34 --> Language Class Initialized
INFO - 2018-11-24 10:49:34 --> Loader Class Initialized
INFO - 2018-11-24 10:49:34 --> Helper loaded: url_helper
INFO - 2018-11-24 10:49:34 --> Helper loaded: file_helper
INFO - 2018-11-24 10:49:34 --> Helper loaded: email_helper
INFO - 2018-11-24 10:49:34 --> Helper loaded: common_helper
INFO - 2018-11-24 10:49:34 --> Database Driver Class Initialized
DEBUG - 2018-11-24 10:49:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-24 10:49:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-24 10:49:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-24 10:49:34 --> Pagination Class Initialized
INFO - 2018-11-24 10:49:34 --> Helper loaded: form_helper
INFO - 2018-11-24 10:49:34 --> Form Validation Class Initialized
INFO - 2018-11-24 10:49:34 --> Model Class Initialized
INFO - 2018-11-24 10:49:34 --> Controller Class Initialized
INFO - 2018-11-24 10:49:34 --> Model Class Initialized
INFO - 2018-11-24 10:49:34 --> Model Class Initialized
INFO - 2018-11-24 10:49:34 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\template/header-menu.php
INFO - 2018-11-24 10:49:34 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\template/header.php
INFO - 2018-11-24 10:49:34 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\template/footer.php
INFO - 2018-11-24 10:49:34 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\index.php
INFO - 2018-11-24 10:49:34 --> Final output sent to browser
DEBUG - 2018-11-24 10:49:34 --> Total execution time: 0.3110
INFO - 2018-11-24 12:16:02 --> Config Class Initialized
INFO - 2018-11-24 12:16:02 --> Hooks Class Initialized
DEBUG - 2018-11-24 12:16:02 --> UTF-8 Support Enabled
INFO - 2018-11-24 12:16:02 --> Utf8 Class Initialized
INFO - 2018-11-24 12:16:02 --> URI Class Initialized
DEBUG - 2018-11-24 12:16:02 --> No URI present. Default controller set.
INFO - 2018-11-24 12:16:02 --> Router Class Initialized
INFO - 2018-11-24 12:16:02 --> Output Class Initialized
INFO - 2018-11-24 12:16:02 --> Security Class Initialized
DEBUG - 2018-11-24 12:16:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-24 12:16:02 --> Input Class Initialized
INFO - 2018-11-24 12:16:02 --> Language Class Initialized
INFO - 2018-11-24 12:16:02 --> Loader Class Initialized
INFO - 2018-11-24 12:16:02 --> Helper loaded: url_helper
INFO - 2018-11-24 12:16:02 --> Helper loaded: file_helper
INFO - 2018-11-24 12:16:02 --> Helper loaded: email_helper
INFO - 2018-11-24 12:16:02 --> Helper loaded: common_helper
INFO - 2018-11-24 12:16:02 --> Database Driver Class Initialized
DEBUG - 2018-11-24 12:16:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-24 12:16:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-24 12:16:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-24 12:16:02 --> Pagination Class Initialized
INFO - 2018-11-24 12:16:02 --> Helper loaded: form_helper
INFO - 2018-11-24 12:16:02 --> Form Validation Class Initialized
INFO - 2018-11-24 12:16:02 --> Model Class Initialized
INFO - 2018-11-24 12:16:02 --> Controller Class Initialized
INFO - 2018-11-24 12:16:02 --> Model Class Initialized
INFO - 2018-11-24 12:16:02 --> Model Class Initialized
INFO - 2018-11-24 12:16:02 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\template/header-menu.php
INFO - 2018-11-24 12:16:02 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\template/header.php
INFO - 2018-11-24 12:16:02 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\template/footer.php
INFO - 2018-11-24 12:16:02 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\index.php
INFO - 2018-11-24 12:16:02 --> Final output sent to browser
DEBUG - 2018-11-24 12:16:02 --> Total execution time: 0.1510

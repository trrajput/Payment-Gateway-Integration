<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2018-11-20 07:22:16 --> Config Class Initialized
INFO - 2018-11-20 07:22:16 --> Hooks Class Initialized
DEBUG - 2018-11-20 07:22:16 --> UTF-8 Support Enabled
INFO - 2018-11-20 07:22:16 --> Utf8 Class Initialized
INFO - 2018-11-20 07:22:16 --> URI Class Initialized
INFO - 2018-11-20 07:22:16 --> Router Class Initialized
INFO - 2018-11-20 07:22:16 --> Output Class Initialized
INFO - 2018-11-20 07:22:16 --> Security Class Initialized
DEBUG - 2018-11-20 07:22:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-20 07:22:16 --> Input Class Initialized
INFO - 2018-11-20 07:22:16 --> Language Class Initialized
INFO - 2018-11-20 07:22:16 --> Loader Class Initialized
INFO - 2018-11-20 07:22:16 --> Helper loaded: url_helper
INFO - 2018-11-20 07:22:16 --> Helper loaded: file_helper
INFO - 2018-11-20 07:22:16 --> Helper loaded: email_helper
INFO - 2018-11-20 07:22:16 --> Helper loaded: common_helper
INFO - 2018-11-20 07:22:16 --> Database Driver Class Initialized
DEBUG - 2018-11-20 07:22:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-20 07:22:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-20 07:22:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-20 07:22:16 --> Pagination Class Initialized
INFO - 2018-11-20 07:22:16 --> Helper loaded: form_helper
INFO - 2018-11-20 07:22:16 --> Form Validation Class Initialized
INFO - 2018-11-20 07:22:16 --> Model Class Initialized
INFO - 2018-11-20 07:22:16 --> Controller Class Initialized
INFO - 2018-11-20 07:22:16 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-20 07:22:16 --> Model Class Initialized
INFO - 2018-11-20 07:22:16 --> Model Class Initialized
INFO - 2018-11-20 07:22:16 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/index.php
INFO - 2018-11-20 07:22:16 --> Final output sent to browser
DEBUG - 2018-11-20 07:22:16 --> Total execution time: 0.1210
INFO - 2018-11-20 07:22:21 --> Config Class Initialized
INFO - 2018-11-20 07:22:21 --> Hooks Class Initialized
DEBUG - 2018-11-20 07:22:21 --> UTF-8 Support Enabled
INFO - 2018-11-20 07:22:21 --> Utf8 Class Initialized
INFO - 2018-11-20 07:22:21 --> URI Class Initialized
INFO - 2018-11-20 07:22:21 --> Router Class Initialized
INFO - 2018-11-20 07:22:21 --> Output Class Initialized
INFO - 2018-11-20 07:22:21 --> Security Class Initialized
DEBUG - 2018-11-20 07:22:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-20 07:22:21 --> Input Class Initialized
INFO - 2018-11-20 07:22:21 --> Language Class Initialized
INFO - 2018-11-20 07:22:21 --> Loader Class Initialized
INFO - 2018-11-20 07:22:21 --> Helper loaded: url_helper
INFO - 2018-11-20 07:22:21 --> Helper loaded: file_helper
INFO - 2018-11-20 07:22:21 --> Helper loaded: email_helper
INFO - 2018-11-20 07:22:21 --> Helper loaded: common_helper
INFO - 2018-11-20 07:22:21 --> Database Driver Class Initialized
DEBUG - 2018-11-20 07:22:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-20 07:22:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-20 07:22:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-20 07:22:21 --> Pagination Class Initialized
INFO - 2018-11-20 07:22:21 --> Helper loaded: form_helper
INFO - 2018-11-20 07:22:21 --> Form Validation Class Initialized
INFO - 2018-11-20 07:22:21 --> Model Class Initialized
INFO - 2018-11-20 07:22:21 --> Controller Class Initialized
INFO - 2018-11-20 07:22:21 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-20 07:22:21 --> Model Class Initialized
INFO - 2018-11-20 07:22:21 --> Model Class Initialized
INFO - 2018-11-20 07:22:21 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/index.php
INFO - 2018-11-20 07:22:21 --> Final output sent to browser
DEBUG - 2018-11-20 07:22:21 --> Total execution time: 0.0696
INFO - 2018-11-20 07:32:51 --> Config Class Initialized
INFO - 2018-11-20 07:32:51 --> Hooks Class Initialized
DEBUG - 2018-11-20 07:32:51 --> UTF-8 Support Enabled
INFO - 2018-11-20 07:32:51 --> Utf8 Class Initialized
INFO - 2018-11-20 07:32:51 --> URI Class Initialized
INFO - 2018-11-20 07:32:51 --> Router Class Initialized
INFO - 2018-11-20 07:32:51 --> Output Class Initialized
INFO - 2018-11-20 07:32:51 --> Security Class Initialized
DEBUG - 2018-11-20 07:32:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-20 07:32:51 --> Input Class Initialized
INFO - 2018-11-20 07:32:51 --> Language Class Initialized
INFO - 2018-11-20 07:32:51 --> Loader Class Initialized
INFO - 2018-11-20 07:32:51 --> Helper loaded: url_helper
INFO - 2018-11-20 07:32:51 --> Helper loaded: file_helper
INFO - 2018-11-20 07:32:51 --> Helper loaded: email_helper
INFO - 2018-11-20 07:32:51 --> Helper loaded: common_helper
INFO - 2018-11-20 07:32:51 --> Database Driver Class Initialized
DEBUG - 2018-11-20 07:32:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-20 07:32:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-20 07:32:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-20 07:32:51 --> Pagination Class Initialized
INFO - 2018-11-20 07:32:51 --> Helper loaded: form_helper
INFO - 2018-11-20 07:32:51 --> Form Validation Class Initialized
INFO - 2018-11-20 07:32:51 --> Model Class Initialized
INFO - 2018-11-20 07:32:51 --> Controller Class Initialized
INFO - 2018-11-20 07:32:51 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-20 07:32:51 --> Model Class Initialized
INFO - 2018-11-20 07:32:51 --> Model Class Initialized
INFO - 2018-11-20 07:32:51 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/index.php
INFO - 2018-11-20 07:32:51 --> Final output sent to browser
DEBUG - 2018-11-20 07:32:51 --> Total execution time: 0.0630
INFO - 2018-11-20 07:33:10 --> Config Class Initialized
INFO - 2018-11-20 07:33:10 --> Hooks Class Initialized
DEBUG - 2018-11-20 07:33:10 --> UTF-8 Support Enabled
INFO - 2018-11-20 07:33:10 --> Utf8 Class Initialized
INFO - 2018-11-20 07:33:10 --> URI Class Initialized
INFO - 2018-11-20 07:33:10 --> Router Class Initialized
INFO - 2018-11-20 07:33:10 --> Output Class Initialized
INFO - 2018-11-20 07:33:10 --> Security Class Initialized
DEBUG - 2018-11-20 07:33:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-20 07:33:10 --> Input Class Initialized
INFO - 2018-11-20 07:33:10 --> Language Class Initialized
INFO - 2018-11-20 07:33:10 --> Loader Class Initialized
INFO - 2018-11-20 07:33:10 --> Helper loaded: url_helper
INFO - 2018-11-20 07:33:10 --> Helper loaded: file_helper
INFO - 2018-11-20 07:33:10 --> Helper loaded: email_helper
INFO - 2018-11-20 07:33:10 --> Helper loaded: common_helper
INFO - 2018-11-20 07:33:10 --> Database Driver Class Initialized
DEBUG - 2018-11-20 07:33:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-20 07:33:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-20 07:33:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-20 07:33:10 --> Pagination Class Initialized
INFO - 2018-11-20 07:33:10 --> Helper loaded: form_helper
INFO - 2018-11-20 07:33:10 --> Form Validation Class Initialized
INFO - 2018-11-20 07:33:10 --> Model Class Initialized
INFO - 2018-11-20 07:33:10 --> Controller Class Initialized
INFO - 2018-11-20 07:33:10 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-20 07:33:10 --> Model Class Initialized
INFO - 2018-11-20 07:33:10 --> Model Class Initialized
INFO - 2018-11-20 07:33:10 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/index.php
INFO - 2018-11-20 07:33:10 --> Final output sent to browser
DEBUG - 2018-11-20 07:33:10 --> Total execution time: 0.0726
INFO - 2018-11-20 07:35:13 --> Config Class Initialized
INFO - 2018-11-20 07:35:13 --> Hooks Class Initialized
DEBUG - 2018-11-20 07:35:13 --> UTF-8 Support Enabled
INFO - 2018-11-20 07:35:13 --> Utf8 Class Initialized
INFO - 2018-11-20 07:35:13 --> URI Class Initialized
INFO - 2018-11-20 07:35:13 --> Router Class Initialized
INFO - 2018-11-20 07:35:13 --> Output Class Initialized
INFO - 2018-11-20 07:35:13 --> Security Class Initialized
DEBUG - 2018-11-20 07:35:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-20 07:35:13 --> Input Class Initialized
INFO - 2018-11-20 07:35:13 --> Language Class Initialized
INFO - 2018-11-20 07:35:13 --> Loader Class Initialized
INFO - 2018-11-20 07:35:13 --> Helper loaded: url_helper
INFO - 2018-11-20 07:35:13 --> Helper loaded: file_helper
INFO - 2018-11-20 07:35:13 --> Helper loaded: email_helper
INFO - 2018-11-20 07:35:13 --> Helper loaded: common_helper
INFO - 2018-11-20 07:35:13 --> Database Driver Class Initialized
DEBUG - 2018-11-20 07:35:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-20 07:35:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-20 07:35:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-20 07:35:13 --> Pagination Class Initialized
INFO - 2018-11-20 07:35:13 --> Helper loaded: form_helper
INFO - 2018-11-20 07:35:13 --> Form Validation Class Initialized
INFO - 2018-11-20 07:35:13 --> Model Class Initialized
INFO - 2018-11-20 07:35:13 --> Controller Class Initialized
INFO - 2018-11-20 07:35:13 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-20 07:35:13 --> Model Class Initialized
INFO - 2018-11-20 07:35:13 --> Model Class Initialized
INFO - 2018-11-20 07:35:13 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/index.php
INFO - 2018-11-20 07:35:13 --> Final output sent to browser
DEBUG - 2018-11-20 07:35:13 --> Total execution time: 0.0530
INFO - 2018-11-20 07:35:13 --> Config Class Initialized
INFO - 2018-11-20 07:35:13 --> Hooks Class Initialized
DEBUG - 2018-11-20 07:35:13 --> UTF-8 Support Enabled
INFO - 2018-11-20 07:35:13 --> Utf8 Class Initialized
INFO - 2018-11-20 07:35:13 --> URI Class Initialized
INFO - 2018-11-20 07:35:13 --> Router Class Initialized
INFO - 2018-11-20 07:35:13 --> Output Class Initialized
INFO - 2018-11-20 07:35:13 --> Security Class Initialized
DEBUG - 2018-11-20 07:35:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-20 07:35:13 --> Input Class Initialized
INFO - 2018-11-20 07:35:13 --> Language Class Initialized
ERROR - 2018-11-20 07:35:13 --> 404 Page Not Found: Bootstrap/dist
INFO - 2018-11-20 07:35:14 --> Config Class Initialized
INFO - 2018-11-20 07:35:14 --> Hooks Class Initialized
DEBUG - 2018-11-20 07:35:14 --> UTF-8 Support Enabled
INFO - 2018-11-20 07:35:14 --> Utf8 Class Initialized
INFO - 2018-11-20 07:35:14 --> URI Class Initialized
INFO - 2018-11-20 07:35:14 --> Router Class Initialized
INFO - 2018-11-20 07:35:14 --> Output Class Initialized
INFO - 2018-11-20 07:35:14 --> Security Class Initialized
DEBUG - 2018-11-20 07:35:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-20 07:35:14 --> Input Class Initialized
INFO - 2018-11-20 07:35:14 --> Language Class Initialized
ERROR - 2018-11-20 07:35:14 --> 404 Page Not Found: Bootstrap/dist
INFO - 2018-11-20 07:36:11 --> Config Class Initialized
INFO - 2018-11-20 07:36:11 --> Hooks Class Initialized
DEBUG - 2018-11-20 07:36:11 --> UTF-8 Support Enabled
INFO - 2018-11-20 07:36:11 --> Utf8 Class Initialized
INFO - 2018-11-20 07:36:11 --> URI Class Initialized
INFO - 2018-11-20 07:36:11 --> Router Class Initialized
INFO - 2018-11-20 07:36:11 --> Output Class Initialized
INFO - 2018-11-20 07:36:11 --> Security Class Initialized
DEBUG - 2018-11-20 07:36:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-20 07:36:11 --> Input Class Initialized
INFO - 2018-11-20 07:36:11 --> Language Class Initialized
INFO - 2018-11-20 07:36:11 --> Loader Class Initialized
INFO - 2018-11-20 07:36:11 --> Helper loaded: url_helper
INFO - 2018-11-20 07:36:11 --> Helper loaded: file_helper
INFO - 2018-11-20 07:36:11 --> Helper loaded: email_helper
INFO - 2018-11-20 07:36:11 --> Helper loaded: common_helper
INFO - 2018-11-20 07:36:11 --> Database Driver Class Initialized
DEBUG - 2018-11-20 07:36:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-20 07:36:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-20 07:36:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-20 07:36:11 --> Pagination Class Initialized
INFO - 2018-11-20 07:36:11 --> Helper loaded: form_helper
INFO - 2018-11-20 07:36:11 --> Form Validation Class Initialized
INFO - 2018-11-20 07:36:11 --> Model Class Initialized
INFO - 2018-11-20 07:36:11 --> Controller Class Initialized
INFO - 2018-11-20 07:36:11 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-20 07:36:11 --> Model Class Initialized
INFO - 2018-11-20 07:36:11 --> Model Class Initialized
INFO - 2018-11-20 07:36:11 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/index.php
INFO - 2018-11-20 07:36:11 --> Final output sent to browser
DEBUG - 2018-11-20 07:36:11 --> Total execution time: 0.0580
INFO - 2018-11-20 07:41:57 --> Config Class Initialized
INFO - 2018-11-20 07:41:57 --> Hooks Class Initialized
DEBUG - 2018-11-20 07:41:57 --> UTF-8 Support Enabled
INFO - 2018-11-20 07:41:57 --> Utf8 Class Initialized
INFO - 2018-11-20 07:41:57 --> URI Class Initialized
INFO - 2018-11-20 07:41:57 --> Router Class Initialized
INFO - 2018-11-20 07:41:57 --> Output Class Initialized
INFO - 2018-11-20 07:41:57 --> Security Class Initialized
DEBUG - 2018-11-20 07:41:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-20 07:41:57 --> Input Class Initialized
INFO - 2018-11-20 07:41:57 --> Language Class Initialized
INFO - 2018-11-20 07:41:57 --> Loader Class Initialized
INFO - 2018-11-20 07:41:57 --> Helper loaded: url_helper
INFO - 2018-11-20 07:41:57 --> Helper loaded: file_helper
INFO - 2018-11-20 07:41:57 --> Helper loaded: email_helper
INFO - 2018-11-20 07:41:57 --> Helper loaded: common_helper
INFO - 2018-11-20 07:41:57 --> Database Driver Class Initialized
DEBUG - 2018-11-20 07:41:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-20 07:41:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-20 07:41:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-20 07:41:57 --> Pagination Class Initialized
INFO - 2018-11-20 07:41:57 --> Helper loaded: form_helper
INFO - 2018-11-20 07:41:57 --> Form Validation Class Initialized
INFO - 2018-11-20 07:41:57 --> Model Class Initialized
INFO - 2018-11-20 07:41:57 --> Controller Class Initialized
INFO - 2018-11-20 07:41:57 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-20 07:41:57 --> Model Class Initialized
INFO - 2018-11-20 07:41:57 --> Model Class Initialized
INFO - 2018-11-20 07:41:57 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/index.php
INFO - 2018-11-20 07:41:57 --> Final output sent to browser
DEBUG - 2018-11-20 07:41:57 --> Total execution time: 0.0550
INFO - 2018-11-20 07:41:58 --> Config Class Initialized
INFO - 2018-11-20 07:41:58 --> Hooks Class Initialized
DEBUG - 2018-11-20 07:41:58 --> UTF-8 Support Enabled
INFO - 2018-11-20 07:41:58 --> Utf8 Class Initialized
INFO - 2018-11-20 07:41:58 --> URI Class Initialized
INFO - 2018-11-20 07:41:58 --> Router Class Initialized
INFO - 2018-11-20 07:41:58 --> Output Class Initialized
INFO - 2018-11-20 07:41:58 --> Security Class Initialized
DEBUG - 2018-11-20 07:41:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-20 07:41:58 --> Input Class Initialized
INFO - 2018-11-20 07:41:58 --> Language Class Initialized
ERROR - 2018-11-20 07:41:58 --> 404 Page Not Found: Plugins/images
INFO - 2018-11-20 07:43:07 --> Config Class Initialized
INFO - 2018-11-20 07:43:07 --> Hooks Class Initialized
DEBUG - 2018-11-20 07:43:07 --> UTF-8 Support Enabled
INFO - 2018-11-20 07:43:07 --> Utf8 Class Initialized
INFO - 2018-11-20 07:43:07 --> URI Class Initialized
INFO - 2018-11-20 07:43:07 --> Router Class Initialized
INFO - 2018-11-20 07:43:07 --> Output Class Initialized
INFO - 2018-11-20 07:43:07 --> Security Class Initialized
DEBUG - 2018-11-20 07:43:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-20 07:43:07 --> Input Class Initialized
INFO - 2018-11-20 07:43:07 --> Language Class Initialized
INFO - 2018-11-20 07:43:07 --> Loader Class Initialized
INFO - 2018-11-20 07:43:07 --> Helper loaded: url_helper
INFO - 2018-11-20 07:43:07 --> Helper loaded: file_helper
INFO - 2018-11-20 07:43:07 --> Helper loaded: email_helper
INFO - 2018-11-20 07:43:07 --> Helper loaded: common_helper
INFO - 2018-11-20 07:43:07 --> Database Driver Class Initialized
DEBUG - 2018-11-20 07:43:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-20 07:43:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-20 07:43:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-20 07:43:07 --> Pagination Class Initialized
INFO - 2018-11-20 07:43:07 --> Helper loaded: form_helper
INFO - 2018-11-20 07:43:07 --> Form Validation Class Initialized
INFO - 2018-11-20 07:43:07 --> Model Class Initialized
INFO - 2018-11-20 07:43:07 --> Controller Class Initialized
INFO - 2018-11-20 07:43:07 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-20 07:43:07 --> Model Class Initialized
INFO - 2018-11-20 07:43:07 --> Model Class Initialized
INFO - 2018-11-20 07:43:07 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/index.php
INFO - 2018-11-20 07:43:07 --> Final output sent to browser
DEBUG - 2018-11-20 07:43:07 --> Total execution time: 0.0626
INFO - 2018-11-20 07:43:08 --> Config Class Initialized
INFO - 2018-11-20 07:43:08 --> Hooks Class Initialized
DEBUG - 2018-11-20 07:43:08 --> UTF-8 Support Enabled
INFO - 2018-11-20 07:43:08 --> Utf8 Class Initialized
INFO - 2018-11-20 07:43:08 --> URI Class Initialized
INFO - 2018-11-20 07:43:08 --> Router Class Initialized
INFO - 2018-11-20 07:43:08 --> Output Class Initialized
INFO - 2018-11-20 07:43:08 --> Security Class Initialized
DEBUG - 2018-11-20 07:43:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-20 07:43:08 --> Input Class Initialized
INFO - 2018-11-20 07:43:08 --> Language Class Initialized
ERROR - 2018-11-20 07:43:08 --> 404 Page Not Found: Plugins/images
INFO - 2018-11-20 07:44:03 --> Config Class Initialized
INFO - 2018-11-20 07:44:03 --> Hooks Class Initialized
DEBUG - 2018-11-20 07:44:03 --> UTF-8 Support Enabled
INFO - 2018-11-20 07:44:03 --> Utf8 Class Initialized
INFO - 2018-11-20 07:44:03 --> URI Class Initialized
INFO - 2018-11-20 07:44:03 --> Router Class Initialized
INFO - 2018-11-20 07:44:03 --> Output Class Initialized
INFO - 2018-11-20 07:44:03 --> Security Class Initialized
DEBUG - 2018-11-20 07:44:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-20 07:44:03 --> Input Class Initialized
INFO - 2018-11-20 07:44:03 --> Language Class Initialized
INFO - 2018-11-20 07:44:03 --> Loader Class Initialized
INFO - 2018-11-20 07:44:03 --> Helper loaded: url_helper
INFO - 2018-11-20 07:44:03 --> Helper loaded: file_helper
INFO - 2018-11-20 07:44:03 --> Helper loaded: email_helper
INFO - 2018-11-20 07:44:03 --> Helper loaded: common_helper
INFO - 2018-11-20 07:44:03 --> Database Driver Class Initialized
DEBUG - 2018-11-20 07:44:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-20 07:44:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-20 07:44:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-20 07:44:03 --> Pagination Class Initialized
INFO - 2018-11-20 07:44:03 --> Helper loaded: form_helper
INFO - 2018-11-20 07:44:03 --> Form Validation Class Initialized
INFO - 2018-11-20 07:44:03 --> Model Class Initialized
INFO - 2018-11-20 07:44:03 --> Controller Class Initialized
INFO - 2018-11-20 07:44:03 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-20 07:44:03 --> Model Class Initialized
INFO - 2018-11-20 07:44:03 --> Model Class Initialized
INFO - 2018-11-20 07:44:03 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/index.php
INFO - 2018-11-20 07:44:03 --> Final output sent to browser
DEBUG - 2018-11-20 07:44:03 --> Total execution time: 0.0500
INFO - 2018-11-20 07:44:04 --> Config Class Initialized
INFO - 2018-11-20 07:44:04 --> Hooks Class Initialized
DEBUG - 2018-11-20 07:44:04 --> UTF-8 Support Enabled
INFO - 2018-11-20 07:44:04 --> Utf8 Class Initialized
INFO - 2018-11-20 07:44:04 --> URI Class Initialized
INFO - 2018-11-20 07:44:04 --> Router Class Initialized
INFO - 2018-11-20 07:44:04 --> Output Class Initialized
INFO - 2018-11-20 07:44:04 --> Security Class Initialized
DEBUG - 2018-11-20 07:44:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-20 07:44:04 --> Input Class Initialized
INFO - 2018-11-20 07:44:04 --> Language Class Initialized
ERROR - 2018-11-20 07:44:04 --> 404 Page Not Found: Plugins/images
INFO - 2018-11-20 07:45:45 --> Config Class Initialized
INFO - 2018-11-20 07:45:45 --> Hooks Class Initialized
DEBUG - 2018-11-20 07:45:45 --> UTF-8 Support Enabled
INFO - 2018-11-20 07:45:45 --> Utf8 Class Initialized
INFO - 2018-11-20 07:45:45 --> URI Class Initialized
INFO - 2018-11-20 07:45:45 --> Router Class Initialized
INFO - 2018-11-20 07:45:45 --> Output Class Initialized
INFO - 2018-11-20 07:45:45 --> Security Class Initialized
DEBUG - 2018-11-20 07:45:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-20 07:45:45 --> Input Class Initialized
INFO - 2018-11-20 07:45:45 --> Language Class Initialized
INFO - 2018-11-20 07:45:45 --> Loader Class Initialized
INFO - 2018-11-20 07:45:45 --> Helper loaded: url_helper
INFO - 2018-11-20 07:45:45 --> Helper loaded: file_helper
INFO - 2018-11-20 07:45:45 --> Helper loaded: email_helper
INFO - 2018-11-20 07:45:45 --> Helper loaded: common_helper
INFO - 2018-11-20 07:45:45 --> Database Driver Class Initialized
DEBUG - 2018-11-20 07:45:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-20 07:45:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-20 07:45:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-20 07:45:45 --> Pagination Class Initialized
INFO - 2018-11-20 07:45:45 --> Helper loaded: form_helper
INFO - 2018-11-20 07:45:45 --> Form Validation Class Initialized
INFO - 2018-11-20 07:45:45 --> Model Class Initialized
INFO - 2018-11-20 07:45:45 --> Controller Class Initialized
INFO - 2018-11-20 07:45:45 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-20 07:45:45 --> Model Class Initialized
INFO - 2018-11-20 07:45:45 --> Model Class Initialized
INFO - 2018-11-20 07:45:45 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/index.php
INFO - 2018-11-20 07:45:45 --> Final output sent to browser
DEBUG - 2018-11-20 07:45:45 --> Total execution time: 0.0620
INFO - 2018-11-20 07:45:46 --> Config Class Initialized
INFO - 2018-11-20 07:45:46 --> Hooks Class Initialized
DEBUG - 2018-11-20 07:45:46 --> UTF-8 Support Enabled
INFO - 2018-11-20 07:45:46 --> Utf8 Class Initialized
INFO - 2018-11-20 07:45:46 --> URI Class Initialized
INFO - 2018-11-20 07:45:46 --> Router Class Initialized
INFO - 2018-11-20 07:45:46 --> Output Class Initialized
INFO - 2018-11-20 07:45:46 --> Security Class Initialized
DEBUG - 2018-11-20 07:45:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-20 07:45:46 --> Input Class Initialized
INFO - 2018-11-20 07:45:46 --> Language Class Initialized
ERROR - 2018-11-20 07:45:46 --> 404 Page Not Found: Plugins/images
INFO - 2018-11-20 07:48:02 --> Config Class Initialized
INFO - 2018-11-20 07:48:02 --> Hooks Class Initialized
DEBUG - 2018-11-20 07:48:02 --> UTF-8 Support Enabled
INFO - 2018-11-20 07:48:02 --> Utf8 Class Initialized
INFO - 2018-11-20 07:48:02 --> URI Class Initialized
INFO - 2018-11-20 07:48:02 --> Router Class Initialized
INFO - 2018-11-20 07:48:02 --> Output Class Initialized
INFO - 2018-11-20 07:48:02 --> Security Class Initialized
DEBUG - 2018-11-20 07:48:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-20 07:48:02 --> Input Class Initialized
INFO - 2018-11-20 07:48:02 --> Language Class Initialized
INFO - 2018-11-20 07:48:02 --> Loader Class Initialized
INFO - 2018-11-20 07:48:02 --> Helper loaded: url_helper
INFO - 2018-11-20 07:48:02 --> Helper loaded: file_helper
INFO - 2018-11-20 07:48:02 --> Helper loaded: email_helper
INFO - 2018-11-20 07:48:02 --> Helper loaded: common_helper
INFO - 2018-11-20 07:48:02 --> Database Driver Class Initialized
DEBUG - 2018-11-20 07:48:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-20 07:48:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-20 07:48:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-20 07:48:02 --> Pagination Class Initialized
INFO - 2018-11-20 07:48:02 --> Helper loaded: form_helper
INFO - 2018-11-20 07:48:02 --> Form Validation Class Initialized
INFO - 2018-11-20 07:48:02 --> Model Class Initialized
INFO - 2018-11-20 07:48:02 --> Controller Class Initialized
INFO - 2018-11-20 07:48:02 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-20 07:48:02 --> Model Class Initialized
INFO - 2018-11-20 07:48:02 --> Model Class Initialized
INFO - 2018-11-20 07:48:02 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/index.php
INFO - 2018-11-20 07:48:02 --> Final output sent to browser
DEBUG - 2018-11-20 07:48:02 --> Total execution time: 0.0676
INFO - 2018-11-20 07:48:03 --> Config Class Initialized
INFO - 2018-11-20 07:48:03 --> Hooks Class Initialized
DEBUG - 2018-11-20 07:48:03 --> UTF-8 Support Enabled
INFO - 2018-11-20 07:48:03 --> Utf8 Class Initialized
INFO - 2018-11-20 07:48:03 --> URI Class Initialized
INFO - 2018-11-20 07:48:03 --> Router Class Initialized
INFO - 2018-11-20 07:48:03 --> Output Class Initialized
INFO - 2018-11-20 07:48:03 --> Security Class Initialized
DEBUG - 2018-11-20 07:48:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-20 07:48:03 --> Input Class Initialized
INFO - 2018-11-20 07:48:03 --> Language Class Initialized
ERROR - 2018-11-20 07:48:03 --> 404 Page Not Found: Plugins/images
INFO - 2018-11-20 07:52:02 --> Config Class Initialized
INFO - 2018-11-20 07:52:02 --> Hooks Class Initialized
DEBUG - 2018-11-20 07:52:02 --> UTF-8 Support Enabled
INFO - 2018-11-20 07:52:02 --> Utf8 Class Initialized
INFO - 2018-11-20 07:52:02 --> URI Class Initialized
INFO - 2018-11-20 07:52:02 --> Router Class Initialized
INFO - 2018-11-20 07:52:02 --> Output Class Initialized
INFO - 2018-11-20 07:52:02 --> Security Class Initialized
DEBUG - 2018-11-20 07:52:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-20 07:52:02 --> Input Class Initialized
INFO - 2018-11-20 07:52:02 --> Language Class Initialized
INFO - 2018-11-20 07:52:02 --> Loader Class Initialized
INFO - 2018-11-20 07:52:02 --> Helper loaded: url_helper
INFO - 2018-11-20 07:52:02 --> Helper loaded: file_helper
INFO - 2018-11-20 07:52:02 --> Helper loaded: email_helper
INFO - 2018-11-20 07:52:02 --> Helper loaded: common_helper
INFO - 2018-11-20 07:52:02 --> Database Driver Class Initialized
DEBUG - 2018-11-20 07:52:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-20 07:52:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-20 07:52:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-20 07:52:02 --> Pagination Class Initialized
INFO - 2018-11-20 07:52:02 --> Helper loaded: form_helper
INFO - 2018-11-20 07:52:02 --> Form Validation Class Initialized
INFO - 2018-11-20 07:52:02 --> Model Class Initialized
INFO - 2018-11-20 07:52:02 --> Controller Class Initialized
INFO - 2018-11-20 07:52:02 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-20 07:52:02 --> Model Class Initialized
INFO - 2018-11-20 07:52:02 --> Model Class Initialized
INFO - 2018-11-20 07:52:02 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/index.php
INFO - 2018-11-20 07:52:02 --> Final output sent to browser
DEBUG - 2018-11-20 07:52:02 --> Total execution time: 0.0616
INFO - 2018-11-20 07:52:03 --> Config Class Initialized
INFO - 2018-11-20 07:52:03 --> Hooks Class Initialized
DEBUG - 2018-11-20 07:52:03 --> UTF-8 Support Enabled
INFO - 2018-11-20 07:52:03 --> Utf8 Class Initialized
INFO - 2018-11-20 07:52:03 --> URI Class Initialized
INFO - 2018-11-20 07:52:03 --> Router Class Initialized
INFO - 2018-11-20 07:52:03 --> Output Class Initialized
INFO - 2018-11-20 07:52:03 --> Security Class Initialized
DEBUG - 2018-11-20 07:52:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-20 07:52:03 --> Input Class Initialized
INFO - 2018-11-20 07:52:03 --> Language Class Initialized
ERROR - 2018-11-20 07:52:03 --> 404 Page Not Found: Plugins/images
INFO - 2018-11-20 07:52:42 --> Config Class Initialized
INFO - 2018-11-20 07:52:42 --> Hooks Class Initialized
DEBUG - 2018-11-20 07:52:42 --> UTF-8 Support Enabled
INFO - 2018-11-20 07:52:42 --> Utf8 Class Initialized
INFO - 2018-11-20 07:52:42 --> URI Class Initialized
INFO - 2018-11-20 07:52:42 --> Router Class Initialized
INFO - 2018-11-20 07:52:42 --> Output Class Initialized
INFO - 2018-11-20 07:52:42 --> Security Class Initialized
DEBUG - 2018-11-20 07:52:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-20 07:52:42 --> Input Class Initialized
INFO - 2018-11-20 07:52:42 --> Language Class Initialized
INFO - 2018-11-20 07:52:42 --> Loader Class Initialized
INFO - 2018-11-20 07:52:42 --> Helper loaded: url_helper
INFO - 2018-11-20 07:52:42 --> Helper loaded: file_helper
INFO - 2018-11-20 07:52:42 --> Helper loaded: email_helper
INFO - 2018-11-20 07:52:42 --> Helper loaded: common_helper
INFO - 2018-11-20 07:52:42 --> Database Driver Class Initialized
DEBUG - 2018-11-20 07:52:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-20 07:52:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-20 07:52:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-20 07:52:42 --> Pagination Class Initialized
INFO - 2018-11-20 07:52:42 --> Helper loaded: form_helper
INFO - 2018-11-20 07:52:42 --> Form Validation Class Initialized
INFO - 2018-11-20 07:52:42 --> Model Class Initialized
INFO - 2018-11-20 07:52:42 --> Controller Class Initialized
INFO - 2018-11-20 07:52:42 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-20 07:52:42 --> Model Class Initialized
INFO - 2018-11-20 07:52:42 --> Model Class Initialized
INFO - 2018-11-20 07:52:42 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/index.php
INFO - 2018-11-20 07:52:42 --> Final output sent to browser
DEBUG - 2018-11-20 07:52:42 --> Total execution time: 0.0606
INFO - 2018-11-20 07:52:43 --> Config Class Initialized
INFO - 2018-11-20 07:52:43 --> Hooks Class Initialized
DEBUG - 2018-11-20 07:52:43 --> UTF-8 Support Enabled
INFO - 2018-11-20 07:52:43 --> Utf8 Class Initialized
INFO - 2018-11-20 07:52:43 --> URI Class Initialized
INFO - 2018-11-20 07:52:43 --> Router Class Initialized
INFO - 2018-11-20 07:52:43 --> Output Class Initialized
INFO - 2018-11-20 07:52:43 --> Security Class Initialized
DEBUG - 2018-11-20 07:52:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-20 07:52:43 --> Input Class Initialized
INFO - 2018-11-20 07:52:43 --> Language Class Initialized
ERROR - 2018-11-20 07:52:43 --> 404 Page Not Found: Plugins/images
INFO - 2018-11-20 07:52:47 --> Config Class Initialized
INFO - 2018-11-20 07:52:47 --> Hooks Class Initialized
DEBUG - 2018-11-20 07:52:47 --> UTF-8 Support Enabled
INFO - 2018-11-20 07:52:47 --> Utf8 Class Initialized
INFO - 2018-11-20 07:52:47 --> URI Class Initialized
INFO - 2018-11-20 07:52:47 --> Router Class Initialized
INFO - 2018-11-20 07:52:47 --> Output Class Initialized
INFO - 2018-11-20 07:52:47 --> Security Class Initialized
DEBUG - 2018-11-20 07:52:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-20 07:52:47 --> Input Class Initialized
INFO - 2018-11-20 07:52:47 --> Language Class Initialized
INFO - 2018-11-20 07:52:47 --> Loader Class Initialized
INFO - 2018-11-20 07:52:47 --> Helper loaded: url_helper
INFO - 2018-11-20 07:52:47 --> Helper loaded: file_helper
INFO - 2018-11-20 07:52:47 --> Helper loaded: email_helper
INFO - 2018-11-20 07:52:47 --> Helper loaded: common_helper
INFO - 2018-11-20 07:52:47 --> Database Driver Class Initialized
DEBUG - 2018-11-20 07:52:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-20 07:52:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-20 07:52:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-20 07:52:47 --> Pagination Class Initialized
INFO - 2018-11-20 07:52:47 --> Helper loaded: form_helper
INFO - 2018-11-20 07:52:47 --> Form Validation Class Initialized
INFO - 2018-11-20 07:52:47 --> Model Class Initialized
INFO - 2018-11-20 07:52:47 --> Controller Class Initialized
INFO - 2018-11-20 07:52:47 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-20 07:52:47 --> Model Class Initialized
INFO - 2018-11-20 07:52:47 --> Model Class Initialized
INFO - 2018-11-20 07:52:47 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/index.php
INFO - 2018-11-20 07:52:47 --> Final output sent to browser
DEBUG - 2018-11-20 07:52:47 --> Total execution time: 0.0636
INFO - 2018-11-20 07:53:25 --> Config Class Initialized
INFO - 2018-11-20 07:53:25 --> Hooks Class Initialized
DEBUG - 2018-11-20 07:53:25 --> UTF-8 Support Enabled
INFO - 2018-11-20 07:53:25 --> Utf8 Class Initialized
INFO - 2018-11-20 07:53:25 --> URI Class Initialized
INFO - 2018-11-20 07:53:25 --> Router Class Initialized
INFO - 2018-11-20 07:53:25 --> Output Class Initialized
INFO - 2018-11-20 07:53:25 --> Security Class Initialized
DEBUG - 2018-11-20 07:53:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-20 07:53:25 --> Input Class Initialized
INFO - 2018-11-20 07:53:25 --> Language Class Initialized
INFO - 2018-11-20 07:53:26 --> Loader Class Initialized
INFO - 2018-11-20 07:53:26 --> Helper loaded: url_helper
INFO - 2018-11-20 07:53:26 --> Helper loaded: file_helper
INFO - 2018-11-20 07:53:26 --> Helper loaded: email_helper
INFO - 2018-11-20 07:53:26 --> Helper loaded: common_helper
INFO - 2018-11-20 07:53:26 --> Database Driver Class Initialized
DEBUG - 2018-11-20 07:53:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-20 07:53:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-20 07:53:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-20 07:53:26 --> Pagination Class Initialized
INFO - 2018-11-20 07:53:26 --> Helper loaded: form_helper
INFO - 2018-11-20 07:53:26 --> Form Validation Class Initialized
INFO - 2018-11-20 07:53:26 --> Model Class Initialized
INFO - 2018-11-20 07:53:26 --> Controller Class Initialized
INFO - 2018-11-20 07:53:26 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-20 07:53:26 --> Model Class Initialized
INFO - 2018-11-20 07:53:26 --> Model Class Initialized
INFO - 2018-11-20 07:53:26 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/index.php
INFO - 2018-11-20 07:53:26 --> Final output sent to browser
DEBUG - 2018-11-20 07:53:26 --> Total execution time: 0.0500
INFO - 2018-11-20 07:53:26 --> Config Class Initialized
INFO - 2018-11-20 07:53:26 --> Hooks Class Initialized
DEBUG - 2018-11-20 07:53:26 --> UTF-8 Support Enabled
INFO - 2018-11-20 07:53:26 --> Utf8 Class Initialized
INFO - 2018-11-20 07:53:26 --> URI Class Initialized
INFO - 2018-11-20 07:53:26 --> Router Class Initialized
INFO - 2018-11-20 07:53:26 --> Output Class Initialized
INFO - 2018-11-20 07:53:26 --> Security Class Initialized
DEBUG - 2018-11-20 07:53:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-20 07:53:26 --> Input Class Initialized
INFO - 2018-11-20 07:53:26 --> Language Class Initialized
ERROR - 2018-11-20 07:53:26 --> 404 Page Not Found: Plugins/images
INFO - 2018-11-20 07:53:36 --> Config Class Initialized
INFO - 2018-11-20 07:53:36 --> Hooks Class Initialized
DEBUG - 2018-11-20 07:53:36 --> UTF-8 Support Enabled
INFO - 2018-11-20 07:53:36 --> Utf8 Class Initialized
INFO - 2018-11-20 07:53:36 --> URI Class Initialized
INFO - 2018-11-20 07:53:36 --> Router Class Initialized
INFO - 2018-11-20 07:53:36 --> Output Class Initialized
INFO - 2018-11-20 07:53:36 --> Security Class Initialized
DEBUG - 2018-11-20 07:53:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-20 07:53:36 --> Input Class Initialized
INFO - 2018-11-20 07:53:36 --> Language Class Initialized
INFO - 2018-11-20 07:53:36 --> Loader Class Initialized
INFO - 2018-11-20 07:53:36 --> Helper loaded: url_helper
INFO - 2018-11-20 07:53:36 --> Helper loaded: file_helper
INFO - 2018-11-20 07:53:36 --> Helper loaded: email_helper
INFO - 2018-11-20 07:53:36 --> Helper loaded: common_helper
INFO - 2018-11-20 07:53:36 --> Database Driver Class Initialized
DEBUG - 2018-11-20 07:53:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-20 07:53:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-20 07:53:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-20 07:53:36 --> Pagination Class Initialized
INFO - 2018-11-20 07:53:36 --> Helper loaded: form_helper
INFO - 2018-11-20 07:53:36 --> Form Validation Class Initialized
INFO - 2018-11-20 07:53:36 --> Model Class Initialized
INFO - 2018-11-20 07:53:36 --> Controller Class Initialized
INFO - 2018-11-20 07:53:36 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-20 07:53:36 --> Model Class Initialized
INFO - 2018-11-20 07:53:36 --> Model Class Initialized
INFO - 2018-11-20 07:53:36 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/index.php
INFO - 2018-11-20 07:53:36 --> Final output sent to browser
DEBUG - 2018-11-20 07:53:36 --> Total execution time: 0.0430
INFO - 2018-11-20 07:53:36 --> Config Class Initialized
INFO - 2018-11-20 07:53:36 --> Hooks Class Initialized
DEBUG - 2018-11-20 07:53:36 --> UTF-8 Support Enabled
INFO - 2018-11-20 07:53:36 --> Utf8 Class Initialized
INFO - 2018-11-20 07:53:36 --> URI Class Initialized
INFO - 2018-11-20 07:53:36 --> Router Class Initialized
INFO - 2018-11-20 07:53:36 --> Output Class Initialized
INFO - 2018-11-20 07:53:36 --> Security Class Initialized
DEBUG - 2018-11-20 07:53:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-20 07:53:36 --> Input Class Initialized
INFO - 2018-11-20 07:53:36 --> Language Class Initialized
INFO - 2018-11-20 07:53:36 --> Loader Class Initialized
INFO - 2018-11-20 07:53:36 --> Helper loaded: url_helper
INFO - 2018-11-20 07:53:36 --> Helper loaded: file_helper
INFO - 2018-11-20 07:53:36 --> Helper loaded: email_helper
INFO - 2018-11-20 07:53:36 --> Helper loaded: common_helper
INFO - 2018-11-20 07:53:36 --> Database Driver Class Initialized
DEBUG - 2018-11-20 07:53:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-20 07:53:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-20 07:53:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-20 07:53:36 --> Pagination Class Initialized
INFO - 2018-11-20 07:53:36 --> Helper loaded: form_helper
INFO - 2018-11-20 07:53:36 --> Form Validation Class Initialized
INFO - 2018-11-20 07:53:36 --> Model Class Initialized
INFO - 2018-11-20 07:53:36 --> Controller Class Initialized
INFO - 2018-11-20 07:53:36 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-20 07:53:36 --> Model Class Initialized
INFO - 2018-11-20 07:53:36 --> Model Class Initialized
INFO - 2018-11-20 07:53:36 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/index.php
INFO - 2018-11-20 07:53:36 --> Final output sent to browser
DEBUG - 2018-11-20 07:53:36 --> Total execution time: 0.0530
INFO - 2018-11-20 07:53:37 --> Config Class Initialized
INFO - 2018-11-20 07:53:37 --> Hooks Class Initialized
DEBUG - 2018-11-20 07:53:37 --> UTF-8 Support Enabled
INFO - 2018-11-20 07:53:37 --> Utf8 Class Initialized
INFO - 2018-11-20 07:53:37 --> URI Class Initialized
INFO - 2018-11-20 07:53:37 --> Router Class Initialized
INFO - 2018-11-20 07:53:37 --> Output Class Initialized
INFO - 2018-11-20 07:53:37 --> Security Class Initialized
DEBUG - 2018-11-20 07:53:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-20 07:53:37 --> Input Class Initialized
INFO - 2018-11-20 07:53:37 --> Language Class Initialized
ERROR - 2018-11-20 07:53:37 --> 404 Page Not Found: Plugins/images
INFO - 2018-11-20 07:54:12 --> Config Class Initialized
INFO - 2018-11-20 07:54:12 --> Hooks Class Initialized
DEBUG - 2018-11-20 07:54:12 --> UTF-8 Support Enabled
INFO - 2018-11-20 07:54:12 --> Utf8 Class Initialized
INFO - 2018-11-20 07:54:12 --> URI Class Initialized
INFO - 2018-11-20 07:54:12 --> Router Class Initialized
INFO - 2018-11-20 07:54:12 --> Output Class Initialized
INFO - 2018-11-20 07:54:12 --> Security Class Initialized
DEBUG - 2018-11-20 07:54:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-20 07:54:12 --> Input Class Initialized
INFO - 2018-11-20 07:54:12 --> Language Class Initialized
INFO - 2018-11-20 07:54:12 --> Loader Class Initialized
INFO - 2018-11-20 07:54:12 --> Helper loaded: url_helper
INFO - 2018-11-20 07:54:12 --> Helper loaded: file_helper
INFO - 2018-11-20 07:54:12 --> Helper loaded: email_helper
INFO - 2018-11-20 07:54:12 --> Helper loaded: common_helper
INFO - 2018-11-20 07:54:12 --> Database Driver Class Initialized
DEBUG - 2018-11-20 07:54:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-20 07:54:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-20 07:54:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-20 07:54:12 --> Pagination Class Initialized
INFO - 2018-11-20 07:54:12 --> Helper loaded: form_helper
INFO - 2018-11-20 07:54:12 --> Form Validation Class Initialized
INFO - 2018-11-20 07:54:12 --> Model Class Initialized
INFO - 2018-11-20 07:54:12 --> Controller Class Initialized
INFO - 2018-11-20 07:54:12 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-20 07:54:12 --> Model Class Initialized
INFO - 2018-11-20 07:54:12 --> Model Class Initialized
INFO - 2018-11-20 07:54:12 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/index.php
INFO - 2018-11-20 07:54:12 --> Final output sent to browser
DEBUG - 2018-11-20 07:54:12 --> Total execution time: 0.0636
INFO - 2018-11-20 07:54:13 --> Config Class Initialized
INFO - 2018-11-20 07:54:13 --> Hooks Class Initialized
DEBUG - 2018-11-20 07:54:13 --> UTF-8 Support Enabled
INFO - 2018-11-20 07:54:13 --> Utf8 Class Initialized
INFO - 2018-11-20 07:54:13 --> URI Class Initialized
INFO - 2018-11-20 07:54:13 --> Router Class Initialized
INFO - 2018-11-20 07:54:13 --> Output Class Initialized
INFO - 2018-11-20 07:54:13 --> Security Class Initialized
DEBUG - 2018-11-20 07:54:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-20 07:54:13 --> Input Class Initialized
INFO - 2018-11-20 07:54:13 --> Language Class Initialized
ERROR - 2018-11-20 07:54:13 --> 404 Page Not Found: Plugins/images
INFO - 2018-11-20 07:55:30 --> Config Class Initialized
INFO - 2018-11-20 07:55:30 --> Hooks Class Initialized
DEBUG - 2018-11-20 07:55:30 --> UTF-8 Support Enabled
INFO - 2018-11-20 07:55:30 --> Utf8 Class Initialized
INFO - 2018-11-20 07:55:30 --> URI Class Initialized
INFO - 2018-11-20 07:55:30 --> Router Class Initialized
INFO - 2018-11-20 07:55:30 --> Output Class Initialized
INFO - 2018-11-20 07:55:30 --> Security Class Initialized
DEBUG - 2018-11-20 07:55:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-20 07:55:30 --> Input Class Initialized
INFO - 2018-11-20 07:55:30 --> Language Class Initialized
INFO - 2018-11-20 07:55:30 --> Loader Class Initialized
INFO - 2018-11-20 07:55:30 --> Helper loaded: url_helper
INFO - 2018-11-20 07:55:30 --> Helper loaded: file_helper
INFO - 2018-11-20 07:55:30 --> Helper loaded: email_helper
INFO - 2018-11-20 07:55:30 --> Helper loaded: common_helper
INFO - 2018-11-20 07:55:30 --> Database Driver Class Initialized
DEBUG - 2018-11-20 07:55:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-20 07:55:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-20 07:55:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-20 07:55:30 --> Pagination Class Initialized
INFO - 2018-11-20 07:55:30 --> Helper loaded: form_helper
INFO - 2018-11-20 07:55:30 --> Form Validation Class Initialized
INFO - 2018-11-20 07:55:30 --> Model Class Initialized
INFO - 2018-11-20 07:55:30 --> Controller Class Initialized
INFO - 2018-11-20 07:55:30 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-20 07:55:30 --> Model Class Initialized
INFO - 2018-11-20 07:55:30 --> Model Class Initialized
INFO - 2018-11-20 07:55:30 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/index.php
INFO - 2018-11-20 07:55:30 --> Final output sent to browser
DEBUG - 2018-11-20 07:55:30 --> Total execution time: 0.0480
INFO - 2018-11-20 07:55:31 --> Config Class Initialized
INFO - 2018-11-20 07:55:31 --> Hooks Class Initialized
DEBUG - 2018-11-20 07:55:31 --> UTF-8 Support Enabled
INFO - 2018-11-20 07:55:31 --> Utf8 Class Initialized
INFO - 2018-11-20 07:55:31 --> URI Class Initialized
INFO - 2018-11-20 07:55:31 --> Router Class Initialized
INFO - 2018-11-20 07:55:31 --> Output Class Initialized
INFO - 2018-11-20 07:55:31 --> Security Class Initialized
DEBUG - 2018-11-20 07:55:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-20 07:55:31 --> Input Class Initialized
INFO - 2018-11-20 07:55:31 --> Language Class Initialized
ERROR - 2018-11-20 07:55:31 --> 404 Page Not Found: Plugins/images
INFO - 2018-11-20 07:58:48 --> Config Class Initialized
INFO - 2018-11-20 07:58:48 --> Hooks Class Initialized
DEBUG - 2018-11-20 07:58:48 --> UTF-8 Support Enabled
INFO - 2018-11-20 07:58:48 --> Utf8 Class Initialized
INFO - 2018-11-20 07:58:48 --> URI Class Initialized
INFO - 2018-11-20 07:58:48 --> Router Class Initialized
INFO - 2018-11-20 07:58:48 --> Output Class Initialized
INFO - 2018-11-20 07:58:48 --> Security Class Initialized
DEBUG - 2018-11-20 07:58:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-20 07:58:48 --> Input Class Initialized
INFO - 2018-11-20 07:58:48 --> Language Class Initialized
INFO - 2018-11-20 07:58:48 --> Loader Class Initialized
INFO - 2018-11-20 07:58:48 --> Helper loaded: url_helper
INFO - 2018-11-20 07:58:48 --> Helper loaded: file_helper
INFO - 2018-11-20 07:58:48 --> Helper loaded: email_helper
INFO - 2018-11-20 07:58:48 --> Helper loaded: common_helper
INFO - 2018-11-20 07:58:48 --> Database Driver Class Initialized
DEBUG - 2018-11-20 07:58:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-20 07:58:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-20 07:58:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-20 07:58:48 --> Pagination Class Initialized
INFO - 2018-11-20 07:58:48 --> Helper loaded: form_helper
INFO - 2018-11-20 07:58:48 --> Form Validation Class Initialized
INFO - 2018-11-20 07:58:48 --> Model Class Initialized
INFO - 2018-11-20 07:58:48 --> Controller Class Initialized
INFO - 2018-11-20 07:58:48 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-20 07:58:48 --> Model Class Initialized
INFO - 2018-11-20 07:58:48 --> Model Class Initialized
INFO - 2018-11-20 07:58:48 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/index.php
INFO - 2018-11-20 07:58:48 --> Final output sent to browser
DEBUG - 2018-11-20 07:58:48 --> Total execution time: 0.0920
INFO - 2018-11-20 07:58:48 --> Config Class Initialized
INFO - 2018-11-20 07:58:48 --> Hooks Class Initialized
DEBUG - 2018-11-20 07:58:48 --> UTF-8 Support Enabled
INFO - 2018-11-20 07:58:48 --> Utf8 Class Initialized
INFO - 2018-11-20 07:58:48 --> URI Class Initialized
INFO - 2018-11-20 07:58:48 --> Router Class Initialized
INFO - 2018-11-20 07:58:48 --> Output Class Initialized
INFO - 2018-11-20 07:58:48 --> Security Class Initialized
DEBUG - 2018-11-20 07:58:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-20 07:58:48 --> Input Class Initialized
INFO - 2018-11-20 07:58:48 --> Language Class Initialized
ERROR - 2018-11-20 07:58:48 --> 404 Page Not Found: Plugins/images
INFO - 2018-11-20 08:01:10 --> Config Class Initialized
INFO - 2018-11-20 08:01:10 --> Hooks Class Initialized
DEBUG - 2018-11-20 08:01:10 --> UTF-8 Support Enabled
INFO - 2018-11-20 08:01:10 --> Utf8 Class Initialized
INFO - 2018-11-20 08:01:10 --> URI Class Initialized
INFO - 2018-11-20 08:01:10 --> Router Class Initialized
INFO - 2018-11-20 08:01:10 --> Output Class Initialized
INFO - 2018-11-20 08:01:10 --> Security Class Initialized
DEBUG - 2018-11-20 08:01:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-20 08:01:10 --> Input Class Initialized
INFO - 2018-11-20 08:01:10 --> Language Class Initialized
INFO - 2018-11-20 08:01:10 --> Loader Class Initialized
INFO - 2018-11-20 08:01:10 --> Helper loaded: url_helper
INFO - 2018-11-20 08:01:10 --> Helper loaded: file_helper
INFO - 2018-11-20 08:01:10 --> Helper loaded: email_helper
INFO - 2018-11-20 08:01:10 --> Helper loaded: common_helper
INFO - 2018-11-20 08:01:10 --> Database Driver Class Initialized
DEBUG - 2018-11-20 08:01:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-20 08:01:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-20 08:01:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-20 08:01:10 --> Pagination Class Initialized
INFO - 2018-11-20 08:01:10 --> Helper loaded: form_helper
INFO - 2018-11-20 08:01:10 --> Form Validation Class Initialized
INFO - 2018-11-20 08:01:10 --> Model Class Initialized
INFO - 2018-11-20 08:01:10 --> Controller Class Initialized
INFO - 2018-11-20 08:01:10 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-20 08:01:10 --> Model Class Initialized
INFO - 2018-11-20 08:01:10 --> Model Class Initialized
INFO - 2018-11-20 08:01:10 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/index.php
INFO - 2018-11-20 08:01:10 --> Final output sent to browser
DEBUG - 2018-11-20 08:01:10 --> Total execution time: 0.0576
INFO - 2018-11-20 08:01:10 --> Config Class Initialized
INFO - 2018-11-20 08:01:10 --> Hooks Class Initialized
DEBUG - 2018-11-20 08:01:10 --> UTF-8 Support Enabled
INFO - 2018-11-20 08:01:10 --> Utf8 Class Initialized
INFO - 2018-11-20 08:01:10 --> URI Class Initialized
INFO - 2018-11-20 08:01:10 --> Router Class Initialized
INFO - 2018-11-20 08:01:10 --> Output Class Initialized
INFO - 2018-11-20 08:01:11 --> Security Class Initialized
DEBUG - 2018-11-20 08:01:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-20 08:01:11 --> Input Class Initialized
INFO - 2018-11-20 08:01:11 --> Language Class Initialized
ERROR - 2018-11-20 08:01:11 --> 404 Page Not Found: Plugins/images
INFO - 2018-11-20 08:01:13 --> Config Class Initialized
INFO - 2018-11-20 08:01:13 --> Hooks Class Initialized
DEBUG - 2018-11-20 08:01:13 --> UTF-8 Support Enabled
INFO - 2018-11-20 08:01:13 --> Utf8 Class Initialized
INFO - 2018-11-20 08:01:13 --> URI Class Initialized
INFO - 2018-11-20 08:01:13 --> Router Class Initialized
INFO - 2018-11-20 08:01:13 --> Output Class Initialized
INFO - 2018-11-20 08:01:13 --> Security Class Initialized
DEBUG - 2018-11-20 08:01:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-20 08:01:13 --> Input Class Initialized
INFO - 2018-11-20 08:01:13 --> Language Class Initialized
INFO - 2018-11-20 08:01:13 --> Loader Class Initialized
INFO - 2018-11-20 08:01:13 --> Helper loaded: url_helper
INFO - 2018-11-20 08:01:13 --> Helper loaded: file_helper
INFO - 2018-11-20 08:01:13 --> Helper loaded: email_helper
INFO - 2018-11-20 08:01:13 --> Helper loaded: common_helper
INFO - 2018-11-20 08:01:13 --> Database Driver Class Initialized
DEBUG - 2018-11-20 08:01:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-20 08:01:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-20 08:01:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-20 08:01:13 --> Pagination Class Initialized
INFO - 2018-11-20 08:01:13 --> Helper loaded: form_helper
INFO - 2018-11-20 08:01:13 --> Form Validation Class Initialized
INFO - 2018-11-20 08:01:13 --> Model Class Initialized
INFO - 2018-11-20 08:01:13 --> Controller Class Initialized
INFO - 2018-11-20 08:01:13 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-20 08:01:13 --> Model Class Initialized
INFO - 2018-11-20 08:01:13 --> Model Class Initialized
INFO - 2018-11-20 08:01:13 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/index.php
INFO - 2018-11-20 08:01:13 --> Final output sent to browser
DEBUG - 2018-11-20 08:01:13 --> Total execution time: 0.0500
INFO - 2018-11-20 08:01:13 --> Config Class Initialized
INFO - 2018-11-20 08:01:13 --> Hooks Class Initialized
DEBUG - 2018-11-20 08:01:13 --> UTF-8 Support Enabled
INFO - 2018-11-20 08:01:13 --> Utf8 Class Initialized
INFO - 2018-11-20 08:01:13 --> URI Class Initialized
INFO - 2018-11-20 08:01:13 --> Router Class Initialized
INFO - 2018-11-20 08:01:13 --> Output Class Initialized
INFO - 2018-11-20 08:01:13 --> Security Class Initialized
DEBUG - 2018-11-20 08:01:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-20 08:01:13 --> Input Class Initialized
INFO - 2018-11-20 08:01:13 --> Language Class Initialized
ERROR - 2018-11-20 08:01:13 --> 404 Page Not Found: Plugins/images
INFO - 2018-11-20 08:01:13 --> Config Class Initialized
INFO - 2018-11-20 08:01:13 --> Hooks Class Initialized
DEBUG - 2018-11-20 08:01:13 --> UTF-8 Support Enabled
INFO - 2018-11-20 08:01:13 --> Utf8 Class Initialized
INFO - 2018-11-20 08:01:13 --> URI Class Initialized
INFO - 2018-11-20 08:01:13 --> Router Class Initialized
INFO - 2018-11-20 08:01:13 --> Output Class Initialized
INFO - 2018-11-20 08:01:13 --> Security Class Initialized
DEBUG - 2018-11-20 08:01:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-20 08:01:13 --> Input Class Initialized
INFO - 2018-11-20 08:01:13 --> Language Class Initialized
INFO - 2018-11-20 08:01:13 --> Loader Class Initialized
INFO - 2018-11-20 08:01:13 --> Helper loaded: url_helper
INFO - 2018-11-20 08:01:13 --> Helper loaded: file_helper
INFO - 2018-11-20 08:01:13 --> Helper loaded: email_helper
INFO - 2018-11-20 08:01:13 --> Helper loaded: common_helper
INFO - 2018-11-20 08:01:13 --> Database Driver Class Initialized
DEBUG - 2018-11-20 08:01:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-20 08:01:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-20 08:01:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-20 08:01:13 --> Pagination Class Initialized
INFO - 2018-11-20 08:01:13 --> Helper loaded: form_helper
INFO - 2018-11-20 08:01:13 --> Form Validation Class Initialized
INFO - 2018-11-20 08:01:13 --> Model Class Initialized
INFO - 2018-11-20 08:01:13 --> Controller Class Initialized
INFO - 2018-11-20 08:01:13 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-20 08:01:13 --> Model Class Initialized
INFO - 2018-11-20 08:01:13 --> Model Class Initialized
INFO - 2018-11-20 08:01:13 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/index.php
INFO - 2018-11-20 08:01:13 --> Final output sent to browser
DEBUG - 2018-11-20 08:01:13 --> Total execution time: 0.0660
INFO - 2018-11-20 08:01:14 --> Config Class Initialized
INFO - 2018-11-20 08:01:14 --> Hooks Class Initialized
DEBUG - 2018-11-20 08:01:14 --> UTF-8 Support Enabled
INFO - 2018-11-20 08:01:14 --> Utf8 Class Initialized
INFO - 2018-11-20 08:01:14 --> URI Class Initialized
INFO - 2018-11-20 08:01:14 --> Router Class Initialized
INFO - 2018-11-20 08:01:14 --> Output Class Initialized
INFO - 2018-11-20 08:01:14 --> Security Class Initialized
DEBUG - 2018-11-20 08:01:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-20 08:01:14 --> Input Class Initialized
INFO - 2018-11-20 08:01:14 --> Language Class Initialized
ERROR - 2018-11-20 08:01:14 --> 404 Page Not Found: Plugins/images
INFO - 2018-11-20 08:01:45 --> Config Class Initialized
INFO - 2018-11-20 08:01:45 --> Hooks Class Initialized
DEBUG - 2018-11-20 08:01:45 --> UTF-8 Support Enabled
INFO - 2018-11-20 08:01:45 --> Utf8 Class Initialized
INFO - 2018-11-20 08:01:45 --> URI Class Initialized
INFO - 2018-11-20 08:01:45 --> Router Class Initialized
INFO - 2018-11-20 08:01:45 --> Output Class Initialized
INFO - 2018-11-20 08:01:45 --> Security Class Initialized
DEBUG - 2018-11-20 08:01:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-20 08:01:45 --> Input Class Initialized
INFO - 2018-11-20 08:01:45 --> Language Class Initialized
INFO - 2018-11-20 08:01:45 --> Loader Class Initialized
INFO - 2018-11-20 08:01:45 --> Helper loaded: url_helper
INFO - 2018-11-20 08:01:45 --> Helper loaded: file_helper
INFO - 2018-11-20 08:01:45 --> Helper loaded: email_helper
INFO - 2018-11-20 08:01:45 --> Helper loaded: common_helper
INFO - 2018-11-20 08:01:45 --> Database Driver Class Initialized
DEBUG - 2018-11-20 08:01:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-20 08:01:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-20 08:01:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-20 08:01:45 --> Pagination Class Initialized
INFO - 2018-11-20 08:01:45 --> Helper loaded: form_helper
INFO - 2018-11-20 08:01:45 --> Form Validation Class Initialized
INFO - 2018-11-20 08:01:45 --> Model Class Initialized
INFO - 2018-11-20 08:01:45 --> Controller Class Initialized
INFO - 2018-11-20 08:01:45 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-20 08:01:45 --> Model Class Initialized
INFO - 2018-11-20 08:01:45 --> Model Class Initialized
INFO - 2018-11-20 08:01:45 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/index.php
INFO - 2018-11-20 08:01:45 --> Final output sent to browser
DEBUG - 2018-11-20 08:01:45 --> Total execution time: 0.0510
INFO - 2018-11-20 08:01:45 --> Config Class Initialized
INFO - 2018-11-20 08:01:45 --> Hooks Class Initialized
DEBUG - 2018-11-20 08:01:45 --> UTF-8 Support Enabled
INFO - 2018-11-20 08:01:45 --> Utf8 Class Initialized
INFO - 2018-11-20 08:01:45 --> URI Class Initialized
INFO - 2018-11-20 08:01:45 --> Router Class Initialized
INFO - 2018-11-20 08:01:45 --> Output Class Initialized
INFO - 2018-11-20 08:01:45 --> Security Class Initialized
DEBUG - 2018-11-20 08:01:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-20 08:01:45 --> Input Class Initialized
INFO - 2018-11-20 08:01:45 --> Language Class Initialized
ERROR - 2018-11-20 08:01:45 --> 404 Page Not Found: Plugins/images
INFO - 2018-11-20 08:01:48 --> Config Class Initialized
INFO - 2018-11-20 08:01:48 --> Hooks Class Initialized
DEBUG - 2018-11-20 08:01:48 --> UTF-8 Support Enabled
INFO - 2018-11-20 08:01:48 --> Utf8 Class Initialized
INFO - 2018-11-20 08:01:48 --> URI Class Initialized
INFO - 2018-11-20 08:01:48 --> Router Class Initialized
INFO - 2018-11-20 08:01:48 --> Output Class Initialized
INFO - 2018-11-20 08:01:48 --> Security Class Initialized
DEBUG - 2018-11-20 08:01:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-20 08:01:48 --> Input Class Initialized
INFO - 2018-11-20 08:01:48 --> Language Class Initialized
INFO - 2018-11-20 08:01:48 --> Loader Class Initialized
INFO - 2018-11-20 08:01:48 --> Helper loaded: url_helper
INFO - 2018-11-20 08:01:48 --> Helper loaded: file_helper
INFO - 2018-11-20 08:01:48 --> Helper loaded: email_helper
INFO - 2018-11-20 08:01:48 --> Helper loaded: common_helper
INFO - 2018-11-20 08:01:48 --> Database Driver Class Initialized
DEBUG - 2018-11-20 08:01:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-20 08:01:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-20 08:01:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-20 08:01:48 --> Pagination Class Initialized
INFO - 2018-11-20 08:01:48 --> Helper loaded: form_helper
INFO - 2018-11-20 08:01:48 --> Form Validation Class Initialized
INFO - 2018-11-20 08:01:48 --> Model Class Initialized
INFO - 2018-11-20 08:01:48 --> Controller Class Initialized
INFO - 2018-11-20 08:01:48 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-20 08:01:48 --> Model Class Initialized
INFO - 2018-11-20 08:01:48 --> Model Class Initialized
INFO - 2018-11-20 08:01:48 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/index.php
INFO - 2018-11-20 08:01:48 --> Final output sent to browser
DEBUG - 2018-11-20 08:01:48 --> Total execution time: 0.0586
INFO - 2018-11-20 08:01:48 --> Config Class Initialized
INFO - 2018-11-20 08:01:48 --> Hooks Class Initialized
DEBUG - 2018-11-20 08:01:48 --> UTF-8 Support Enabled
INFO - 2018-11-20 08:01:48 --> Utf8 Class Initialized
INFO - 2018-11-20 08:01:48 --> URI Class Initialized
INFO - 2018-11-20 08:01:48 --> Router Class Initialized
INFO - 2018-11-20 08:01:48 --> Output Class Initialized
INFO - 2018-11-20 08:01:48 --> Security Class Initialized
DEBUG - 2018-11-20 08:01:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-20 08:01:48 --> Input Class Initialized
INFO - 2018-11-20 08:01:48 --> Language Class Initialized
ERROR - 2018-11-20 08:01:48 --> 404 Page Not Found: Plugins/images
INFO - 2018-11-20 08:01:48 --> Config Class Initialized
INFO - 2018-11-20 08:01:48 --> Hooks Class Initialized
DEBUG - 2018-11-20 08:01:48 --> UTF-8 Support Enabled
INFO - 2018-11-20 08:01:48 --> Utf8 Class Initialized
INFO - 2018-11-20 08:01:48 --> URI Class Initialized
INFO - 2018-11-20 08:01:48 --> Router Class Initialized
INFO - 2018-11-20 08:01:48 --> Output Class Initialized
INFO - 2018-11-20 08:01:48 --> Security Class Initialized
DEBUG - 2018-11-20 08:01:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-20 08:01:48 --> Input Class Initialized
INFO - 2018-11-20 08:01:48 --> Language Class Initialized
INFO - 2018-11-20 08:01:48 --> Config Class Initialized
INFO - 2018-11-20 08:01:48 --> Hooks Class Initialized
DEBUG - 2018-11-20 08:01:48 --> UTF-8 Support Enabled
INFO - 2018-11-20 08:01:48 --> Utf8 Class Initialized
INFO - 2018-11-20 08:01:48 --> URI Class Initialized
INFO - 2018-11-20 08:01:48 --> Loader Class Initialized
INFO - 2018-11-20 08:01:48 --> Helper loaded: url_helper
INFO - 2018-11-20 08:01:48 --> Helper loaded: file_helper
INFO - 2018-11-20 08:01:48 --> Helper loaded: email_helper
INFO - 2018-11-20 08:01:48 --> Helper loaded: common_helper
INFO - 2018-11-20 08:01:48 --> Router Class Initialized
INFO - 2018-11-20 08:01:48 --> Database Driver Class Initialized
INFO - 2018-11-20 08:01:48 --> Output Class Initialized
INFO - 2018-11-20 08:01:48 --> Security Class Initialized
DEBUG - 2018-11-20 08:01:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-20 08:01:48 --> Input Class Initialized
INFO - 2018-11-20 08:01:48 --> Language Class Initialized
INFO - 2018-11-20 08:01:48 --> Loader Class Initialized
INFO - 2018-11-20 08:01:48 --> Helper loaded: url_helper
INFO - 2018-11-20 08:01:48 --> Helper loaded: file_helper
INFO - 2018-11-20 08:01:48 --> Helper loaded: email_helper
INFO - 2018-11-20 08:01:48 --> Helper loaded: common_helper
INFO - 2018-11-20 08:01:48 --> Database Driver Class Initialized
DEBUG - 2018-11-20 08:01:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-20 08:01:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-20 08:01:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-20 08:01:48 --> Pagination Class Initialized
INFO - 2018-11-20 08:01:48 --> Helper loaded: form_helper
INFO - 2018-11-20 08:01:48 --> Form Validation Class Initialized
INFO - 2018-11-20 08:01:48 --> Model Class Initialized
INFO - 2018-11-20 08:01:48 --> Controller Class Initialized
INFO - 2018-11-20 08:01:48 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-20 08:01:48 --> Model Class Initialized
INFO - 2018-11-20 08:01:48 --> Model Class Initialized
INFO - 2018-11-20 08:01:48 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/index.php
INFO - 2018-11-20 08:01:48 --> Final output sent to browser
DEBUG - 2018-11-20 08:01:48 --> Total execution time: 0.0760
DEBUG - 2018-11-20 08:01:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-20 08:01:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-20 08:01:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-20 08:01:48 --> Pagination Class Initialized
INFO - 2018-11-20 08:01:48 --> Helper loaded: form_helper
INFO - 2018-11-20 08:01:48 --> Form Validation Class Initialized
INFO - 2018-11-20 08:01:48 --> Model Class Initialized
INFO - 2018-11-20 08:01:48 --> Controller Class Initialized
INFO - 2018-11-20 08:01:48 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-20 08:01:48 --> Model Class Initialized
INFO - 2018-11-20 08:01:48 --> Model Class Initialized
INFO - 2018-11-20 08:01:48 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/index.php
INFO - 2018-11-20 08:01:48 --> Final output sent to browser
DEBUG - 2018-11-20 08:01:48 --> Total execution time: 0.0880
INFO - 2018-11-20 08:01:48 --> Config Class Initialized
INFO - 2018-11-20 08:01:48 --> Hooks Class Initialized
DEBUG - 2018-11-20 08:01:48 --> UTF-8 Support Enabled
INFO - 2018-11-20 08:01:48 --> Utf8 Class Initialized
INFO - 2018-11-20 08:01:48 --> URI Class Initialized
INFO - 2018-11-20 08:01:48 --> Router Class Initialized
INFO - 2018-11-20 08:01:48 --> Output Class Initialized
INFO - 2018-11-20 08:01:48 --> Security Class Initialized
DEBUG - 2018-11-20 08:01:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-20 08:01:48 --> Input Class Initialized
INFO - 2018-11-20 08:01:48 --> Language Class Initialized
INFO - 2018-11-20 08:01:48 --> Loader Class Initialized
INFO - 2018-11-20 08:01:48 --> Helper loaded: url_helper
INFO - 2018-11-20 08:01:48 --> Helper loaded: file_helper
INFO - 2018-11-20 08:01:48 --> Helper loaded: email_helper
INFO - 2018-11-20 08:01:48 --> Helper loaded: common_helper
INFO - 2018-11-20 08:01:48 --> Database Driver Class Initialized
DEBUG - 2018-11-20 08:01:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-20 08:01:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-20 08:01:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-20 08:01:48 --> Pagination Class Initialized
INFO - 2018-11-20 08:01:48 --> Helper loaded: form_helper
INFO - 2018-11-20 08:01:48 --> Form Validation Class Initialized
INFO - 2018-11-20 08:01:48 --> Model Class Initialized
INFO - 2018-11-20 08:01:48 --> Controller Class Initialized
INFO - 2018-11-20 08:01:48 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-20 08:01:48 --> Model Class Initialized
INFO - 2018-11-20 08:01:48 --> Model Class Initialized
INFO - 2018-11-20 08:01:48 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/index.php
INFO - 2018-11-20 08:01:48 --> Final output sent to browser
DEBUG - 2018-11-20 08:01:48 --> Total execution time: 0.0580
INFO - 2018-11-20 08:01:48 --> Config Class Initialized
INFO - 2018-11-20 08:01:48 --> Hooks Class Initialized
DEBUG - 2018-11-20 08:01:48 --> UTF-8 Support Enabled
INFO - 2018-11-20 08:01:48 --> Utf8 Class Initialized
INFO - 2018-11-20 08:01:48 --> URI Class Initialized
INFO - 2018-11-20 08:01:48 --> Router Class Initialized
INFO - 2018-11-20 08:01:48 --> Output Class Initialized
INFO - 2018-11-20 08:01:48 --> Security Class Initialized
DEBUG - 2018-11-20 08:01:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-20 08:01:48 --> Input Class Initialized
INFO - 2018-11-20 08:01:48 --> Language Class Initialized
INFO - 2018-11-20 08:01:48 --> Loader Class Initialized
INFO - 2018-11-20 08:01:48 --> Helper loaded: url_helper
INFO - 2018-11-20 08:01:48 --> Helper loaded: file_helper
INFO - 2018-11-20 08:01:48 --> Helper loaded: email_helper
INFO - 2018-11-20 08:01:48 --> Helper loaded: common_helper
INFO - 2018-11-20 08:01:48 --> Database Driver Class Initialized
DEBUG - 2018-11-20 08:01:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-20 08:01:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-20 08:01:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-20 08:01:48 --> Pagination Class Initialized
INFO - 2018-11-20 08:01:48 --> Helper loaded: form_helper
INFO - 2018-11-20 08:01:48 --> Form Validation Class Initialized
INFO - 2018-11-20 08:01:48 --> Model Class Initialized
INFO - 2018-11-20 08:01:48 --> Controller Class Initialized
INFO - 2018-11-20 08:01:48 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-20 08:01:48 --> Model Class Initialized
INFO - 2018-11-20 08:01:48 --> Model Class Initialized
INFO - 2018-11-20 08:01:48 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/index.php
INFO - 2018-11-20 08:01:48 --> Final output sent to browser
DEBUG - 2018-11-20 08:01:48 --> Total execution time: 0.0480
INFO - 2018-11-20 08:01:49 --> Config Class Initialized
INFO - 2018-11-20 08:01:49 --> Hooks Class Initialized
DEBUG - 2018-11-20 08:01:49 --> UTF-8 Support Enabled
INFO - 2018-11-20 08:01:49 --> Utf8 Class Initialized
INFO - 2018-11-20 08:01:49 --> URI Class Initialized
INFO - 2018-11-20 08:01:49 --> Router Class Initialized
INFO - 2018-11-20 08:01:49 --> Output Class Initialized
INFO - 2018-11-20 08:01:49 --> Security Class Initialized
DEBUG - 2018-11-20 08:01:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-20 08:01:49 --> Input Class Initialized
INFO - 2018-11-20 08:01:49 --> Language Class Initialized
ERROR - 2018-11-20 08:01:49 --> 404 Page Not Found: Plugins/images
INFO - 2018-11-20 08:01:49 --> Config Class Initialized
INFO - 2018-11-20 08:01:49 --> Hooks Class Initialized
DEBUG - 2018-11-20 08:01:49 --> UTF-8 Support Enabled
INFO - 2018-11-20 08:01:49 --> Utf8 Class Initialized
INFO - 2018-11-20 08:01:49 --> URI Class Initialized
INFO - 2018-11-20 08:01:49 --> Router Class Initialized
INFO - 2018-11-20 08:01:49 --> Output Class Initialized
INFO - 2018-11-20 08:01:49 --> Security Class Initialized
DEBUG - 2018-11-20 08:01:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-20 08:01:49 --> Input Class Initialized
INFO - 2018-11-20 08:01:49 --> Language Class Initialized
INFO - 2018-11-20 08:01:49 --> Loader Class Initialized
INFO - 2018-11-20 08:01:49 --> Helper loaded: url_helper
INFO - 2018-11-20 08:01:49 --> Helper loaded: file_helper
INFO - 2018-11-20 08:01:49 --> Helper loaded: email_helper
INFO - 2018-11-20 08:01:49 --> Helper loaded: common_helper
INFO - 2018-11-20 08:01:49 --> Database Driver Class Initialized
DEBUG - 2018-11-20 08:01:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-20 08:01:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-20 08:01:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-20 08:01:49 --> Pagination Class Initialized
INFO - 2018-11-20 08:01:49 --> Helper loaded: form_helper
INFO - 2018-11-20 08:01:49 --> Form Validation Class Initialized
INFO - 2018-11-20 08:01:49 --> Model Class Initialized
INFO - 2018-11-20 08:01:49 --> Controller Class Initialized
INFO - 2018-11-20 08:01:49 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-20 08:01:49 --> Model Class Initialized
INFO - 2018-11-20 08:01:49 --> Model Class Initialized
INFO - 2018-11-20 08:01:49 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/index.php
INFO - 2018-11-20 08:01:49 --> Final output sent to browser
DEBUG - 2018-11-20 08:01:49 --> Total execution time: 0.0690
INFO - 2018-11-20 08:01:49 --> Config Class Initialized
INFO - 2018-11-20 08:01:49 --> Hooks Class Initialized
DEBUG - 2018-11-20 08:01:49 --> UTF-8 Support Enabled
INFO - 2018-11-20 08:01:49 --> Utf8 Class Initialized
INFO - 2018-11-20 08:01:49 --> URI Class Initialized
INFO - 2018-11-20 08:01:49 --> Router Class Initialized
INFO - 2018-11-20 08:01:49 --> Output Class Initialized
INFO - 2018-11-20 08:01:49 --> Security Class Initialized
DEBUG - 2018-11-20 08:01:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-20 08:01:49 --> Input Class Initialized
INFO - 2018-11-20 08:01:49 --> Language Class Initialized
INFO - 2018-11-20 08:01:49 --> Loader Class Initialized
INFO - 2018-11-20 08:01:49 --> Helper loaded: url_helper
INFO - 2018-11-20 08:01:49 --> Helper loaded: file_helper
INFO - 2018-11-20 08:01:49 --> Helper loaded: email_helper
INFO - 2018-11-20 08:01:49 --> Helper loaded: common_helper
INFO - 2018-11-20 08:01:49 --> Database Driver Class Initialized
DEBUG - 2018-11-20 08:01:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-20 08:01:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-20 08:01:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-20 08:01:49 --> Pagination Class Initialized
INFO - 2018-11-20 08:01:49 --> Helper loaded: form_helper
INFO - 2018-11-20 08:01:49 --> Form Validation Class Initialized
INFO - 2018-11-20 08:01:49 --> Model Class Initialized
INFO - 2018-11-20 08:01:49 --> Controller Class Initialized
INFO - 2018-11-20 08:01:49 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-20 08:01:49 --> Model Class Initialized
INFO - 2018-11-20 08:01:49 --> Model Class Initialized
INFO - 2018-11-20 08:01:49 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/index.php
INFO - 2018-11-20 08:01:49 --> Final output sent to browser
DEBUG - 2018-11-20 08:01:49 --> Total execution time: 0.0640
INFO - 2018-11-20 08:01:49 --> Config Class Initialized
INFO - 2018-11-20 08:01:49 --> Hooks Class Initialized
DEBUG - 2018-11-20 08:01:49 --> UTF-8 Support Enabled
INFO - 2018-11-20 08:01:49 --> Utf8 Class Initialized
INFO - 2018-11-20 08:01:49 --> URI Class Initialized
INFO - 2018-11-20 08:01:49 --> Router Class Initialized
INFO - 2018-11-20 08:01:49 --> Output Class Initialized
INFO - 2018-11-20 08:01:49 --> Security Class Initialized
DEBUG - 2018-11-20 08:01:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-20 08:01:49 --> Input Class Initialized
INFO - 2018-11-20 08:01:49 --> Language Class Initialized
ERROR - 2018-11-20 08:01:49 --> 404 Page Not Found: Plugins/images
INFO - 2018-11-20 08:01:49 --> Config Class Initialized
INFO - 2018-11-20 08:01:49 --> Hooks Class Initialized
DEBUG - 2018-11-20 08:01:49 --> UTF-8 Support Enabled
INFO - 2018-11-20 08:01:49 --> Utf8 Class Initialized
INFO - 2018-11-20 08:01:49 --> URI Class Initialized
INFO - 2018-11-20 08:01:49 --> Router Class Initialized
INFO - 2018-11-20 08:01:49 --> Output Class Initialized
INFO - 2018-11-20 08:01:49 --> Security Class Initialized
DEBUG - 2018-11-20 08:01:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-20 08:01:49 --> Input Class Initialized
INFO - 2018-11-20 08:01:49 --> Language Class Initialized
ERROR - 2018-11-20 08:01:49 --> 404 Page Not Found: Plugins/images
INFO - 2018-11-20 08:02:19 --> Config Class Initialized
INFO - 2018-11-20 08:02:19 --> Hooks Class Initialized
DEBUG - 2018-11-20 08:02:19 --> UTF-8 Support Enabled
INFO - 2018-11-20 08:02:19 --> Utf8 Class Initialized
INFO - 2018-11-20 08:02:19 --> URI Class Initialized
INFO - 2018-11-20 08:02:19 --> Router Class Initialized
INFO - 2018-11-20 08:02:19 --> Output Class Initialized
INFO - 2018-11-20 08:02:19 --> Security Class Initialized
DEBUG - 2018-11-20 08:02:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-20 08:02:19 --> Input Class Initialized
INFO - 2018-11-20 08:02:19 --> Language Class Initialized
INFO - 2018-11-20 08:02:19 --> Loader Class Initialized
INFO - 2018-11-20 08:02:19 --> Helper loaded: url_helper
INFO - 2018-11-20 08:02:19 --> Helper loaded: file_helper
INFO - 2018-11-20 08:02:19 --> Helper loaded: email_helper
INFO - 2018-11-20 08:02:19 --> Helper loaded: common_helper
INFO - 2018-11-20 08:02:19 --> Database Driver Class Initialized
DEBUG - 2018-11-20 08:02:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-20 08:02:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-20 08:02:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-20 08:02:19 --> Pagination Class Initialized
INFO - 2018-11-20 08:02:19 --> Helper loaded: form_helper
INFO - 2018-11-20 08:02:19 --> Form Validation Class Initialized
INFO - 2018-11-20 08:02:19 --> Model Class Initialized
INFO - 2018-11-20 08:02:19 --> Controller Class Initialized
INFO - 2018-11-20 08:02:19 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-20 08:02:19 --> Model Class Initialized
INFO - 2018-11-20 08:02:19 --> Model Class Initialized
INFO - 2018-11-20 08:02:19 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/index.php
INFO - 2018-11-20 08:02:19 --> Final output sent to browser
DEBUG - 2018-11-20 08:02:19 --> Total execution time: 0.0602
INFO - 2018-11-20 08:02:19 --> Config Class Initialized
INFO - 2018-11-20 08:02:19 --> Hooks Class Initialized
DEBUG - 2018-11-20 08:02:19 --> UTF-8 Support Enabled
INFO - 2018-11-20 08:02:19 --> Utf8 Class Initialized
INFO - 2018-11-20 08:02:19 --> URI Class Initialized
INFO - 2018-11-20 08:02:19 --> Router Class Initialized
INFO - 2018-11-20 08:02:19 --> Output Class Initialized
INFO - 2018-11-20 08:02:19 --> Security Class Initialized
DEBUG - 2018-11-20 08:02:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-20 08:02:19 --> Input Class Initialized
INFO - 2018-11-20 08:02:19 --> Language Class Initialized
ERROR - 2018-11-20 08:02:19 --> 404 Page Not Found: Plugins/images
INFO - 2018-11-20 08:02:20 --> Config Class Initialized
INFO - 2018-11-20 08:02:20 --> Hooks Class Initialized
DEBUG - 2018-11-20 08:02:20 --> UTF-8 Support Enabled
INFO - 2018-11-20 08:02:20 --> Utf8 Class Initialized
INFO - 2018-11-20 08:02:20 --> URI Class Initialized
INFO - 2018-11-20 08:02:20 --> Router Class Initialized
INFO - 2018-11-20 08:02:20 --> Output Class Initialized
INFO - 2018-11-20 08:02:20 --> Security Class Initialized
DEBUG - 2018-11-20 08:02:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-20 08:02:20 --> Input Class Initialized
INFO - 2018-11-20 08:02:20 --> Language Class Initialized
INFO - 2018-11-20 08:02:20 --> Loader Class Initialized
INFO - 2018-11-20 08:02:20 --> Helper loaded: url_helper
INFO - 2018-11-20 08:02:20 --> Helper loaded: file_helper
INFO - 2018-11-20 08:02:20 --> Helper loaded: email_helper
INFO - 2018-11-20 08:02:20 --> Helper loaded: common_helper
INFO - 2018-11-20 08:02:20 --> Database Driver Class Initialized
DEBUG - 2018-11-20 08:02:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-20 08:02:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-20 08:02:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-20 08:02:20 --> Pagination Class Initialized
INFO - 2018-11-20 08:02:20 --> Helper loaded: form_helper
INFO - 2018-11-20 08:02:20 --> Form Validation Class Initialized
INFO - 2018-11-20 08:02:20 --> Model Class Initialized
INFO - 2018-11-20 08:02:20 --> Controller Class Initialized
INFO - 2018-11-20 08:02:20 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-20 08:02:20 --> Model Class Initialized
INFO - 2018-11-20 08:02:20 --> Model Class Initialized
INFO - 2018-11-20 08:02:20 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/index.php
INFO - 2018-11-20 08:02:20 --> Final output sent to browser
DEBUG - 2018-11-20 08:02:20 --> Total execution time: 0.0536
INFO - 2018-11-20 08:02:20 --> Config Class Initialized
INFO - 2018-11-20 08:02:20 --> Hooks Class Initialized
DEBUG - 2018-11-20 08:02:20 --> UTF-8 Support Enabled
INFO - 2018-11-20 08:02:20 --> Utf8 Class Initialized
INFO - 2018-11-20 08:02:20 --> URI Class Initialized
INFO - 2018-11-20 08:02:20 --> Router Class Initialized
INFO - 2018-11-20 08:02:20 --> Output Class Initialized
INFO - 2018-11-20 08:02:20 --> Security Class Initialized
DEBUG - 2018-11-20 08:02:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-20 08:02:20 --> Input Class Initialized
INFO - 2018-11-20 08:02:20 --> Language Class Initialized
ERROR - 2018-11-20 08:02:20 --> 404 Page Not Found: Plugins/images
INFO - 2018-11-20 08:07:23 --> Config Class Initialized
INFO - 2018-11-20 08:07:23 --> Hooks Class Initialized
DEBUG - 2018-11-20 08:07:23 --> UTF-8 Support Enabled
INFO - 2018-11-20 08:07:23 --> Utf8 Class Initialized
INFO - 2018-11-20 08:07:23 --> URI Class Initialized
INFO - 2018-11-20 08:07:23 --> Router Class Initialized
INFO - 2018-11-20 08:07:23 --> Output Class Initialized
INFO - 2018-11-20 08:07:23 --> Security Class Initialized
DEBUG - 2018-11-20 08:07:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-20 08:07:23 --> Input Class Initialized
INFO - 2018-11-20 08:07:23 --> Language Class Initialized
INFO - 2018-11-20 08:07:23 --> Loader Class Initialized
INFO - 2018-11-20 08:07:23 --> Helper loaded: url_helper
INFO - 2018-11-20 08:07:23 --> Helper loaded: file_helper
INFO - 2018-11-20 08:07:23 --> Helper loaded: email_helper
INFO - 2018-11-20 08:07:23 --> Helper loaded: common_helper
INFO - 2018-11-20 08:07:23 --> Database Driver Class Initialized
DEBUG - 2018-11-20 08:07:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-20 08:07:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-20 08:07:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-20 08:07:23 --> Pagination Class Initialized
INFO - 2018-11-20 08:07:23 --> Helper loaded: form_helper
INFO - 2018-11-20 08:07:23 --> Form Validation Class Initialized
INFO - 2018-11-20 08:07:23 --> Model Class Initialized
INFO - 2018-11-20 08:07:23 --> Controller Class Initialized
INFO - 2018-11-20 08:07:23 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-20 08:07:23 --> Model Class Initialized
INFO - 2018-11-20 08:07:23 --> Model Class Initialized
INFO - 2018-11-20 08:07:23 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/index.php
INFO - 2018-11-20 08:07:23 --> Final output sent to browser
DEBUG - 2018-11-20 08:07:23 --> Total execution time: 0.0550
INFO - 2018-11-20 08:09:14 --> Config Class Initialized
INFO - 2018-11-20 08:09:14 --> Hooks Class Initialized
DEBUG - 2018-11-20 08:09:14 --> UTF-8 Support Enabled
INFO - 2018-11-20 08:09:14 --> Utf8 Class Initialized
INFO - 2018-11-20 08:09:14 --> URI Class Initialized
INFO - 2018-11-20 08:09:14 --> Router Class Initialized
INFO - 2018-11-20 08:09:14 --> Output Class Initialized
INFO - 2018-11-20 08:09:14 --> Security Class Initialized
DEBUG - 2018-11-20 08:09:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-20 08:09:14 --> Input Class Initialized
INFO - 2018-11-20 08:09:14 --> Language Class Initialized
ERROR - 2018-11-20 08:09:14 --> 404 Page Not Found: Plugins/images
INFO - 2018-11-20 08:09:20 --> Config Class Initialized
INFO - 2018-11-20 08:09:20 --> Hooks Class Initialized
DEBUG - 2018-11-20 08:09:20 --> UTF-8 Support Enabled
INFO - 2018-11-20 08:09:20 --> Utf8 Class Initialized
INFO - 2018-11-20 08:09:20 --> URI Class Initialized
INFO - 2018-11-20 08:09:20 --> Router Class Initialized
INFO - 2018-11-20 08:09:20 --> Output Class Initialized
INFO - 2018-11-20 08:09:20 --> Security Class Initialized
DEBUG - 2018-11-20 08:09:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-20 08:09:20 --> Input Class Initialized
INFO - 2018-11-20 08:09:20 --> Language Class Initialized
ERROR - 2018-11-20 08:09:20 --> 404 Page Not Found: Plugins/images
INFO - 2018-11-20 08:12:13 --> Config Class Initialized
INFO - 2018-11-20 08:12:13 --> Hooks Class Initialized
DEBUG - 2018-11-20 08:12:13 --> UTF-8 Support Enabled
INFO - 2018-11-20 08:12:13 --> Utf8 Class Initialized
INFO - 2018-11-20 08:12:13 --> URI Class Initialized
INFO - 2018-11-20 08:12:13 --> Router Class Initialized
INFO - 2018-11-20 08:12:13 --> Output Class Initialized
INFO - 2018-11-20 08:12:13 --> Security Class Initialized
DEBUG - 2018-11-20 08:12:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-20 08:12:13 --> Input Class Initialized
INFO - 2018-11-20 08:12:13 --> Language Class Initialized
INFO - 2018-11-20 08:12:13 --> Loader Class Initialized
INFO - 2018-11-20 08:12:13 --> Helper loaded: url_helper
INFO - 2018-11-20 08:12:13 --> Helper loaded: file_helper
INFO - 2018-11-20 08:12:13 --> Helper loaded: email_helper
INFO - 2018-11-20 08:12:13 --> Helper loaded: common_helper
INFO - 2018-11-20 08:12:13 --> Database Driver Class Initialized
DEBUG - 2018-11-20 08:12:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-20 08:12:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-20 08:12:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-20 08:12:13 --> Pagination Class Initialized
INFO - 2018-11-20 08:12:13 --> Helper loaded: form_helper
INFO - 2018-11-20 08:12:13 --> Form Validation Class Initialized
INFO - 2018-11-20 08:12:13 --> Model Class Initialized
INFO - 2018-11-20 08:12:13 --> Controller Class Initialized
INFO - 2018-11-20 08:12:13 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-20 08:12:13 --> Model Class Initialized
INFO - 2018-11-20 08:12:13 --> Model Class Initialized
INFO - 2018-11-20 08:12:13 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/index.php
INFO - 2018-11-20 08:12:13 --> Final output sent to browser
DEBUG - 2018-11-20 08:12:13 --> Total execution time: 0.0550
INFO - 2018-11-20 08:16:17 --> Config Class Initialized
INFO - 2018-11-20 08:16:17 --> Hooks Class Initialized
DEBUG - 2018-11-20 08:16:17 --> UTF-8 Support Enabled
INFO - 2018-11-20 08:16:17 --> Utf8 Class Initialized
INFO - 2018-11-20 08:16:17 --> URI Class Initialized
INFO - 2018-11-20 08:16:17 --> Router Class Initialized
INFO - 2018-11-20 08:16:17 --> Output Class Initialized
INFO - 2018-11-20 08:16:17 --> Security Class Initialized
DEBUG - 2018-11-20 08:16:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-20 08:16:17 --> Input Class Initialized
INFO - 2018-11-20 08:16:17 --> Language Class Initialized
INFO - 2018-11-20 08:16:17 --> Loader Class Initialized
INFO - 2018-11-20 08:16:17 --> Helper loaded: url_helper
INFO - 2018-11-20 08:16:17 --> Helper loaded: file_helper
INFO - 2018-11-20 08:16:17 --> Helper loaded: email_helper
INFO - 2018-11-20 08:16:17 --> Helper loaded: common_helper
INFO - 2018-11-20 08:16:17 --> Database Driver Class Initialized
DEBUG - 2018-11-20 08:16:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-20 08:16:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-20 08:16:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-20 08:16:17 --> Pagination Class Initialized
INFO - 2018-11-20 08:16:17 --> Helper loaded: form_helper
INFO - 2018-11-20 08:16:17 --> Form Validation Class Initialized
INFO - 2018-11-20 08:16:17 --> Model Class Initialized
INFO - 2018-11-20 08:16:17 --> Controller Class Initialized
INFO - 2018-11-20 08:16:17 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-20 08:16:17 --> Model Class Initialized
INFO - 2018-11-20 08:16:17 --> Model Class Initialized
INFO - 2018-11-20 08:16:17 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/index.php
INFO - 2018-11-20 08:16:17 --> Final output sent to browser
DEBUG - 2018-11-20 08:16:17 --> Total execution time: 0.0580
INFO - 2018-11-20 08:16:21 --> Config Class Initialized
INFO - 2018-11-20 08:16:21 --> Hooks Class Initialized
DEBUG - 2018-11-20 08:16:21 --> UTF-8 Support Enabled
INFO - 2018-11-20 08:16:21 --> Utf8 Class Initialized
INFO - 2018-11-20 08:16:21 --> URI Class Initialized
INFO - 2018-11-20 08:16:21 --> Router Class Initialized
INFO - 2018-11-20 08:16:21 --> Output Class Initialized
INFO - 2018-11-20 08:16:21 --> Security Class Initialized
DEBUG - 2018-11-20 08:16:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-20 08:16:21 --> Input Class Initialized
INFO - 2018-11-20 08:16:21 --> Language Class Initialized
INFO - 2018-11-20 08:16:21 --> Loader Class Initialized
INFO - 2018-11-20 08:16:21 --> Helper loaded: url_helper
INFO - 2018-11-20 08:16:21 --> Helper loaded: file_helper
INFO - 2018-11-20 08:16:21 --> Helper loaded: email_helper
INFO - 2018-11-20 08:16:21 --> Helper loaded: common_helper
INFO - 2018-11-20 08:16:21 --> Database Driver Class Initialized
DEBUG - 2018-11-20 08:16:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-20 08:16:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-20 08:16:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-20 08:16:21 --> Pagination Class Initialized
INFO - 2018-11-20 08:16:21 --> Helper loaded: form_helper
INFO - 2018-11-20 08:16:21 --> Form Validation Class Initialized
INFO - 2018-11-20 08:16:21 --> Model Class Initialized
INFO - 2018-11-20 08:16:21 --> Controller Class Initialized
INFO - 2018-11-20 08:16:21 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-20 08:16:21 --> Model Class Initialized
INFO - 2018-11-20 08:16:21 --> Model Class Initialized
INFO - 2018-11-20 08:16:21 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/index.php
INFO - 2018-11-20 08:16:21 --> Final output sent to browser
DEBUG - 2018-11-20 08:16:21 --> Total execution time: 0.0530
INFO - 2018-11-20 08:16:33 --> Config Class Initialized
INFO - 2018-11-20 08:16:33 --> Hooks Class Initialized
DEBUG - 2018-11-20 08:16:33 --> UTF-8 Support Enabled
INFO - 2018-11-20 08:16:33 --> Utf8 Class Initialized
INFO - 2018-11-20 08:16:33 --> URI Class Initialized
INFO - 2018-11-20 08:16:33 --> Router Class Initialized
INFO - 2018-11-20 08:16:33 --> Output Class Initialized
INFO - 2018-11-20 08:16:33 --> Security Class Initialized
DEBUG - 2018-11-20 08:16:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-20 08:16:33 --> Input Class Initialized
INFO - 2018-11-20 08:16:33 --> Language Class Initialized
INFO - 2018-11-20 08:16:33 --> Loader Class Initialized
INFO - 2018-11-20 08:16:33 --> Helper loaded: url_helper
INFO - 2018-11-20 08:16:33 --> Helper loaded: file_helper
INFO - 2018-11-20 08:16:33 --> Helper loaded: email_helper
INFO - 2018-11-20 08:16:33 --> Helper loaded: common_helper
INFO - 2018-11-20 08:16:33 --> Database Driver Class Initialized
DEBUG - 2018-11-20 08:16:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-20 08:16:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-20 08:16:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-20 08:16:33 --> Pagination Class Initialized
INFO - 2018-11-20 08:16:33 --> Helper loaded: form_helper
INFO - 2018-11-20 08:16:33 --> Form Validation Class Initialized
INFO - 2018-11-20 08:16:33 --> Model Class Initialized
INFO - 2018-11-20 08:16:33 --> Controller Class Initialized
INFO - 2018-11-20 08:16:33 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-20 08:16:33 --> Model Class Initialized
INFO - 2018-11-20 08:16:33 --> Model Class Initialized
INFO - 2018-11-20 08:16:33 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/index.php
INFO - 2018-11-20 08:16:33 --> Final output sent to browser
DEBUG - 2018-11-20 08:16:33 --> Total execution time: 0.0780
INFO - 2018-11-20 08:16:57 --> Config Class Initialized
INFO - 2018-11-20 08:16:57 --> Hooks Class Initialized
DEBUG - 2018-11-20 08:16:57 --> UTF-8 Support Enabled
INFO - 2018-11-20 08:16:57 --> Utf8 Class Initialized
INFO - 2018-11-20 08:16:57 --> URI Class Initialized
INFO - 2018-11-20 08:16:57 --> Router Class Initialized
INFO - 2018-11-20 08:16:57 --> Output Class Initialized
INFO - 2018-11-20 08:16:57 --> Security Class Initialized
DEBUG - 2018-11-20 08:16:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-20 08:16:57 --> Input Class Initialized
INFO - 2018-11-20 08:16:57 --> Language Class Initialized
INFO - 2018-11-20 08:16:57 --> Loader Class Initialized
INFO - 2018-11-20 08:16:57 --> Helper loaded: url_helper
INFO - 2018-11-20 08:16:57 --> Helper loaded: file_helper
INFO - 2018-11-20 08:16:57 --> Helper loaded: email_helper
INFO - 2018-11-20 08:16:57 --> Helper loaded: common_helper
INFO - 2018-11-20 08:16:57 --> Database Driver Class Initialized
DEBUG - 2018-11-20 08:16:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-20 08:16:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-20 08:16:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-20 08:16:57 --> Pagination Class Initialized
INFO - 2018-11-20 08:16:57 --> Helper loaded: form_helper
INFO - 2018-11-20 08:16:57 --> Form Validation Class Initialized
INFO - 2018-11-20 08:16:57 --> Model Class Initialized
INFO - 2018-11-20 08:16:57 --> Controller Class Initialized
INFO - 2018-11-20 08:16:57 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-20 08:16:57 --> Model Class Initialized
INFO - 2018-11-20 08:16:57 --> Model Class Initialized
INFO - 2018-11-20 08:16:57 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/index.php
INFO - 2018-11-20 08:16:57 --> Final output sent to browser
DEBUG - 2018-11-20 08:16:57 --> Total execution time: 0.0560
INFO - 2018-11-20 08:17:17 --> Config Class Initialized
INFO - 2018-11-20 08:17:17 --> Hooks Class Initialized
DEBUG - 2018-11-20 08:17:17 --> UTF-8 Support Enabled
INFO - 2018-11-20 08:17:17 --> Utf8 Class Initialized
INFO - 2018-11-20 08:17:17 --> URI Class Initialized
INFO - 2018-11-20 08:17:17 --> Router Class Initialized
INFO - 2018-11-20 08:17:17 --> Output Class Initialized
INFO - 2018-11-20 08:17:17 --> Security Class Initialized
DEBUG - 2018-11-20 08:17:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-20 08:17:17 --> Input Class Initialized
INFO - 2018-11-20 08:17:17 --> Language Class Initialized
INFO - 2018-11-20 08:17:17 --> Loader Class Initialized
INFO - 2018-11-20 08:17:17 --> Helper loaded: url_helper
INFO - 2018-11-20 08:17:17 --> Helper loaded: file_helper
INFO - 2018-11-20 08:17:17 --> Helper loaded: email_helper
INFO - 2018-11-20 08:17:17 --> Helper loaded: common_helper
INFO - 2018-11-20 08:17:17 --> Database Driver Class Initialized
DEBUG - 2018-11-20 08:17:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-20 08:17:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-20 08:17:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-20 08:17:17 --> Pagination Class Initialized
INFO - 2018-11-20 08:17:17 --> Helper loaded: form_helper
INFO - 2018-11-20 08:17:17 --> Form Validation Class Initialized
INFO - 2018-11-20 08:17:17 --> Model Class Initialized
INFO - 2018-11-20 08:17:17 --> Controller Class Initialized
INFO - 2018-11-20 08:17:17 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-20 08:17:17 --> Model Class Initialized
INFO - 2018-11-20 08:17:17 --> Model Class Initialized
INFO - 2018-11-20 08:17:17 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/index.php
INFO - 2018-11-20 08:17:17 --> Final output sent to browser
DEBUG - 2018-11-20 08:17:17 --> Total execution time: 0.0520
INFO - 2018-11-20 08:18:36 --> Config Class Initialized
INFO - 2018-11-20 08:18:36 --> Hooks Class Initialized
DEBUG - 2018-11-20 08:18:36 --> UTF-8 Support Enabled
INFO - 2018-11-20 08:18:36 --> Utf8 Class Initialized
INFO - 2018-11-20 08:18:36 --> URI Class Initialized
INFO - 2018-11-20 08:18:36 --> Router Class Initialized
INFO - 2018-11-20 08:18:36 --> Output Class Initialized
INFO - 2018-11-20 08:18:36 --> Security Class Initialized
DEBUG - 2018-11-20 08:18:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-20 08:18:36 --> Input Class Initialized
INFO - 2018-11-20 08:18:36 --> Language Class Initialized
INFO - 2018-11-20 08:18:36 --> Loader Class Initialized
INFO - 2018-11-20 08:18:36 --> Helper loaded: url_helper
INFO - 2018-11-20 08:18:36 --> Helper loaded: file_helper
INFO - 2018-11-20 08:18:36 --> Helper loaded: email_helper
INFO - 2018-11-20 08:18:36 --> Helper loaded: common_helper
INFO - 2018-11-20 08:18:36 --> Database Driver Class Initialized
DEBUG - 2018-11-20 08:18:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-20 08:18:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-20 08:18:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-20 08:18:36 --> Pagination Class Initialized
INFO - 2018-11-20 08:18:36 --> Helper loaded: form_helper
INFO - 2018-11-20 08:18:36 --> Form Validation Class Initialized
INFO - 2018-11-20 08:18:36 --> Model Class Initialized
INFO - 2018-11-20 08:18:36 --> Controller Class Initialized
INFO - 2018-11-20 08:18:36 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-20 08:18:36 --> Model Class Initialized
INFO - 2018-11-20 08:18:36 --> Model Class Initialized
INFO - 2018-11-20 08:18:36 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/index.php
INFO - 2018-11-20 08:18:36 --> Final output sent to browser
DEBUG - 2018-11-20 08:18:36 --> Total execution time: 0.0736
INFO - 2018-11-20 08:20:59 --> Config Class Initialized
INFO - 2018-11-20 08:20:59 --> Hooks Class Initialized
DEBUG - 2018-11-20 08:20:59 --> UTF-8 Support Enabled
INFO - 2018-11-20 08:20:59 --> Utf8 Class Initialized
INFO - 2018-11-20 08:20:59 --> URI Class Initialized
INFO - 2018-11-20 08:20:59 --> Router Class Initialized
INFO - 2018-11-20 08:20:59 --> Output Class Initialized
INFO - 2018-11-20 08:20:59 --> Security Class Initialized
DEBUG - 2018-11-20 08:20:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-20 08:20:59 --> Input Class Initialized
INFO - 2018-11-20 08:20:59 --> Language Class Initialized
INFO - 2018-11-20 08:20:59 --> Loader Class Initialized
INFO - 2018-11-20 08:20:59 --> Helper loaded: url_helper
INFO - 2018-11-20 08:20:59 --> Helper loaded: file_helper
INFO - 2018-11-20 08:20:59 --> Helper loaded: email_helper
INFO - 2018-11-20 08:20:59 --> Helper loaded: common_helper
INFO - 2018-11-20 08:20:59 --> Database Driver Class Initialized
DEBUG - 2018-11-20 08:20:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-20 08:20:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-20 08:20:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-20 08:20:59 --> Pagination Class Initialized
INFO - 2018-11-20 08:20:59 --> Helper loaded: form_helper
INFO - 2018-11-20 08:20:59 --> Form Validation Class Initialized
INFO - 2018-11-20 08:20:59 --> Model Class Initialized
INFO - 2018-11-20 08:20:59 --> Controller Class Initialized
INFO - 2018-11-20 08:20:59 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-20 08:20:59 --> Model Class Initialized
INFO - 2018-11-20 08:20:59 --> Model Class Initialized
INFO - 2018-11-20 08:20:59 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/index.php
INFO - 2018-11-20 08:20:59 --> Final output sent to browser
DEBUG - 2018-11-20 08:20:59 --> Total execution time: 0.0860
INFO - 2018-11-20 08:21:09 --> Config Class Initialized
INFO - 2018-11-20 08:21:09 --> Hooks Class Initialized
DEBUG - 2018-11-20 08:21:09 --> UTF-8 Support Enabled
INFO - 2018-11-20 08:21:09 --> Utf8 Class Initialized
INFO - 2018-11-20 08:21:09 --> URI Class Initialized
INFO - 2018-11-20 08:21:09 --> Router Class Initialized
INFO - 2018-11-20 08:21:09 --> Output Class Initialized
INFO - 2018-11-20 08:21:09 --> Security Class Initialized
DEBUG - 2018-11-20 08:21:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-20 08:21:09 --> Input Class Initialized
INFO - 2018-11-20 08:21:09 --> Language Class Initialized
INFO - 2018-11-20 08:21:09 --> Loader Class Initialized
INFO - 2018-11-20 08:21:09 --> Helper loaded: url_helper
INFO - 2018-11-20 08:21:09 --> Helper loaded: file_helper
INFO - 2018-11-20 08:21:09 --> Helper loaded: email_helper
INFO - 2018-11-20 08:21:09 --> Helper loaded: common_helper
INFO - 2018-11-20 08:21:09 --> Database Driver Class Initialized
DEBUG - 2018-11-20 08:21:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-20 08:21:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-20 08:21:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-20 08:21:09 --> Pagination Class Initialized
INFO - 2018-11-20 08:21:09 --> Helper loaded: form_helper
INFO - 2018-11-20 08:21:09 --> Form Validation Class Initialized
INFO - 2018-11-20 08:21:09 --> Model Class Initialized
INFO - 2018-11-20 08:21:09 --> Controller Class Initialized
INFO - 2018-11-20 08:21:09 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-20 08:21:09 --> Model Class Initialized
INFO - 2018-11-20 08:21:09 --> Model Class Initialized
INFO - 2018-11-20 08:21:09 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/index.php
INFO - 2018-11-20 08:21:09 --> Final output sent to browser
DEBUG - 2018-11-20 08:21:09 --> Total execution time: 0.0560
INFO - 2018-11-20 08:25:11 --> Config Class Initialized
INFO - 2018-11-20 08:25:11 --> Hooks Class Initialized
DEBUG - 2018-11-20 08:25:11 --> UTF-8 Support Enabled
INFO - 2018-11-20 08:25:11 --> Utf8 Class Initialized
INFO - 2018-11-20 08:25:11 --> URI Class Initialized
INFO - 2018-11-20 08:25:11 --> Router Class Initialized
INFO - 2018-11-20 08:25:11 --> Output Class Initialized
INFO - 2018-11-20 08:25:11 --> Security Class Initialized
DEBUG - 2018-11-20 08:25:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-20 08:25:11 --> Input Class Initialized
INFO - 2018-11-20 08:25:11 --> Language Class Initialized
INFO - 2018-11-20 08:25:11 --> Loader Class Initialized
INFO - 2018-11-20 08:25:11 --> Helper loaded: url_helper
INFO - 2018-11-20 08:25:11 --> Helper loaded: file_helper
INFO - 2018-11-20 08:25:11 --> Helper loaded: email_helper
INFO - 2018-11-20 08:25:11 --> Helper loaded: common_helper
INFO - 2018-11-20 08:25:11 --> Database Driver Class Initialized
DEBUG - 2018-11-20 08:25:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-20 08:25:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-20 08:25:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-20 08:25:11 --> Pagination Class Initialized
INFO - 2018-11-20 08:25:11 --> Helper loaded: form_helper
INFO - 2018-11-20 08:25:11 --> Form Validation Class Initialized
INFO - 2018-11-20 08:25:11 --> Model Class Initialized
INFO - 2018-11-20 08:25:11 --> Controller Class Initialized
INFO - 2018-11-20 08:25:11 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-20 08:25:11 --> Model Class Initialized
INFO - 2018-11-20 08:25:11 --> Model Class Initialized
INFO - 2018-11-20 08:25:11 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/index.php
INFO - 2018-11-20 08:25:11 --> Final output sent to browser
DEBUG - 2018-11-20 08:25:11 --> Total execution time: 0.0576
INFO - 2018-11-20 08:25:50 --> Config Class Initialized
INFO - 2018-11-20 08:25:50 --> Hooks Class Initialized
DEBUG - 2018-11-20 08:25:50 --> UTF-8 Support Enabled
INFO - 2018-11-20 08:25:50 --> Utf8 Class Initialized
INFO - 2018-11-20 08:25:50 --> URI Class Initialized
INFO - 2018-11-20 08:25:50 --> Router Class Initialized
INFO - 2018-11-20 08:25:50 --> Output Class Initialized
INFO - 2018-11-20 08:25:50 --> Security Class Initialized
DEBUG - 2018-11-20 08:25:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-20 08:25:50 --> Input Class Initialized
INFO - 2018-11-20 08:25:50 --> Language Class Initialized
INFO - 2018-11-20 08:25:50 --> Loader Class Initialized
INFO - 2018-11-20 08:25:50 --> Helper loaded: url_helper
INFO - 2018-11-20 08:25:50 --> Helper loaded: file_helper
INFO - 2018-11-20 08:25:50 --> Helper loaded: email_helper
INFO - 2018-11-20 08:25:50 --> Helper loaded: common_helper
INFO - 2018-11-20 08:25:50 --> Database Driver Class Initialized
DEBUG - 2018-11-20 08:25:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-20 08:25:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-20 08:25:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-20 08:25:50 --> Pagination Class Initialized
INFO - 2018-11-20 08:25:50 --> Helper loaded: form_helper
INFO - 2018-11-20 08:25:50 --> Form Validation Class Initialized
INFO - 2018-11-20 08:25:50 --> Model Class Initialized
INFO - 2018-11-20 08:25:50 --> Controller Class Initialized
INFO - 2018-11-20 08:25:50 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-20 08:25:50 --> Model Class Initialized
INFO - 2018-11-20 08:25:50 --> Model Class Initialized
INFO - 2018-11-20 08:25:50 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/index.php
INFO - 2018-11-20 08:25:50 --> Final output sent to browser
DEBUG - 2018-11-20 08:25:50 --> Total execution time: 0.0736
INFO - 2018-11-20 08:26:11 --> Config Class Initialized
INFO - 2018-11-20 08:26:11 --> Hooks Class Initialized
DEBUG - 2018-11-20 08:26:11 --> UTF-8 Support Enabled
INFO - 2018-11-20 08:26:11 --> Utf8 Class Initialized
INFO - 2018-11-20 08:26:11 --> URI Class Initialized
INFO - 2018-11-20 08:26:11 --> Router Class Initialized
INFO - 2018-11-20 08:26:11 --> Output Class Initialized
INFO - 2018-11-20 08:26:11 --> Security Class Initialized
DEBUG - 2018-11-20 08:26:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-20 08:26:11 --> Input Class Initialized
INFO - 2018-11-20 08:26:11 --> Language Class Initialized
INFO - 2018-11-20 08:26:11 --> Loader Class Initialized
INFO - 2018-11-20 08:26:11 --> Helper loaded: url_helper
INFO - 2018-11-20 08:26:11 --> Helper loaded: file_helper
INFO - 2018-11-20 08:26:11 --> Helper loaded: email_helper
INFO - 2018-11-20 08:26:11 --> Helper loaded: common_helper
INFO - 2018-11-20 08:26:11 --> Database Driver Class Initialized
DEBUG - 2018-11-20 08:26:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-20 08:26:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-20 08:26:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-20 08:26:11 --> Pagination Class Initialized
INFO - 2018-11-20 08:26:11 --> Helper loaded: form_helper
INFO - 2018-11-20 08:26:11 --> Form Validation Class Initialized
INFO - 2018-11-20 08:26:11 --> Model Class Initialized
INFO - 2018-11-20 08:26:11 --> Controller Class Initialized
INFO - 2018-11-20 08:26:11 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-20 08:26:11 --> Model Class Initialized
INFO - 2018-11-20 08:26:11 --> Model Class Initialized
INFO - 2018-11-20 08:26:11 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/index.php
INFO - 2018-11-20 08:26:11 --> Final output sent to browser
DEBUG - 2018-11-20 08:26:11 --> Total execution time: 0.0640
INFO - 2018-11-20 08:27:26 --> Config Class Initialized
INFO - 2018-11-20 08:27:26 --> Hooks Class Initialized
DEBUG - 2018-11-20 08:27:26 --> UTF-8 Support Enabled
INFO - 2018-11-20 08:27:26 --> Utf8 Class Initialized
INFO - 2018-11-20 08:27:26 --> URI Class Initialized
INFO - 2018-11-20 08:27:26 --> Router Class Initialized
INFO - 2018-11-20 08:27:26 --> Output Class Initialized
INFO - 2018-11-20 08:27:26 --> Security Class Initialized
DEBUG - 2018-11-20 08:27:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-20 08:27:26 --> Input Class Initialized
INFO - 2018-11-20 08:27:26 --> Language Class Initialized
INFO - 2018-11-20 08:27:26 --> Loader Class Initialized
INFO - 2018-11-20 08:27:26 --> Helper loaded: url_helper
INFO - 2018-11-20 08:27:26 --> Helper loaded: file_helper
INFO - 2018-11-20 08:27:26 --> Helper loaded: email_helper
INFO - 2018-11-20 08:27:26 --> Helper loaded: common_helper
INFO - 2018-11-20 08:27:26 --> Database Driver Class Initialized
DEBUG - 2018-11-20 08:27:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-20 08:27:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-20 08:27:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-20 08:27:26 --> Pagination Class Initialized
INFO - 2018-11-20 08:27:26 --> Helper loaded: form_helper
INFO - 2018-11-20 08:27:26 --> Form Validation Class Initialized
INFO - 2018-11-20 08:27:26 --> Model Class Initialized
INFO - 2018-11-20 08:27:26 --> Controller Class Initialized
INFO - 2018-11-20 08:27:26 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-20 08:27:26 --> Model Class Initialized
INFO - 2018-11-20 08:27:26 --> Model Class Initialized
INFO - 2018-11-20 08:27:26 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/index.php
INFO - 2018-11-20 08:27:26 --> Final output sent to browser
DEBUG - 2018-11-20 08:27:26 --> Total execution time: 0.0590
INFO - 2018-11-20 08:27:51 --> Config Class Initialized
INFO - 2018-11-20 08:27:51 --> Hooks Class Initialized
DEBUG - 2018-11-20 08:27:51 --> UTF-8 Support Enabled
INFO - 2018-11-20 08:27:51 --> Utf8 Class Initialized
INFO - 2018-11-20 08:27:51 --> URI Class Initialized
INFO - 2018-11-20 08:27:51 --> Router Class Initialized
INFO - 2018-11-20 08:27:51 --> Output Class Initialized
INFO - 2018-11-20 08:27:51 --> Security Class Initialized
DEBUG - 2018-11-20 08:27:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-20 08:27:51 --> Input Class Initialized
INFO - 2018-11-20 08:27:51 --> Language Class Initialized
INFO - 2018-11-20 08:27:51 --> Loader Class Initialized
INFO - 2018-11-20 08:27:51 --> Helper loaded: url_helper
INFO - 2018-11-20 08:27:51 --> Helper loaded: file_helper
INFO - 2018-11-20 08:27:51 --> Helper loaded: email_helper
INFO - 2018-11-20 08:27:51 --> Helper loaded: common_helper
INFO - 2018-11-20 08:27:51 --> Database Driver Class Initialized
DEBUG - 2018-11-20 08:27:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-20 08:27:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-20 08:27:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-20 08:27:51 --> Pagination Class Initialized
INFO - 2018-11-20 08:27:51 --> Helper loaded: form_helper
INFO - 2018-11-20 08:27:51 --> Form Validation Class Initialized
INFO - 2018-11-20 08:27:51 --> Model Class Initialized
INFO - 2018-11-20 08:27:51 --> Controller Class Initialized
INFO - 2018-11-20 08:27:51 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-20 08:27:51 --> Model Class Initialized
INFO - 2018-11-20 08:27:51 --> Model Class Initialized
INFO - 2018-11-20 08:27:51 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/index.php
INFO - 2018-11-20 08:27:51 --> Final output sent to browser
DEBUG - 2018-11-20 08:27:51 --> Total execution time: 0.0650
INFO - 2018-11-20 08:28:50 --> Config Class Initialized
INFO - 2018-11-20 08:28:50 --> Hooks Class Initialized
DEBUG - 2018-11-20 08:28:50 --> UTF-8 Support Enabled
INFO - 2018-11-20 08:28:50 --> Utf8 Class Initialized
INFO - 2018-11-20 08:28:50 --> URI Class Initialized
INFO - 2018-11-20 08:28:50 --> Router Class Initialized
INFO - 2018-11-20 08:28:50 --> Output Class Initialized
INFO - 2018-11-20 08:28:50 --> Security Class Initialized
DEBUG - 2018-11-20 08:28:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-20 08:28:50 --> Input Class Initialized
INFO - 2018-11-20 08:28:50 --> Language Class Initialized
INFO - 2018-11-20 08:28:50 --> Loader Class Initialized
INFO - 2018-11-20 08:28:50 --> Helper loaded: url_helper
INFO - 2018-11-20 08:28:50 --> Helper loaded: file_helper
INFO - 2018-11-20 08:28:50 --> Helper loaded: email_helper
INFO - 2018-11-20 08:28:50 --> Helper loaded: common_helper
INFO - 2018-11-20 08:28:50 --> Database Driver Class Initialized
DEBUG - 2018-11-20 08:28:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-20 08:28:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-20 08:28:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-20 08:28:50 --> Pagination Class Initialized
INFO - 2018-11-20 08:28:50 --> Helper loaded: form_helper
INFO - 2018-11-20 08:28:50 --> Form Validation Class Initialized
INFO - 2018-11-20 08:28:50 --> Model Class Initialized
INFO - 2018-11-20 08:28:50 --> Controller Class Initialized
INFO - 2018-11-20 08:28:50 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-20 08:28:50 --> Model Class Initialized
INFO - 2018-11-20 08:28:50 --> Model Class Initialized
INFO - 2018-11-20 08:28:50 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/index.php
INFO - 2018-11-20 08:28:50 --> Final output sent to browser
DEBUG - 2018-11-20 08:28:50 --> Total execution time: 0.0570
INFO - 2018-11-20 08:32:52 --> Config Class Initialized
INFO - 2018-11-20 08:32:52 --> Hooks Class Initialized
DEBUG - 2018-11-20 08:32:52 --> UTF-8 Support Enabled
INFO - 2018-11-20 08:32:52 --> Utf8 Class Initialized
INFO - 2018-11-20 08:32:52 --> URI Class Initialized
INFO - 2018-11-20 08:32:52 --> Router Class Initialized
INFO - 2018-11-20 08:32:52 --> Output Class Initialized
INFO - 2018-11-20 08:32:52 --> Security Class Initialized
DEBUG - 2018-11-20 08:32:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-20 08:32:52 --> Input Class Initialized
INFO - 2018-11-20 08:32:52 --> Language Class Initialized
INFO - 2018-11-20 08:32:52 --> Loader Class Initialized
INFO - 2018-11-20 08:32:52 --> Helper loaded: url_helper
INFO - 2018-11-20 08:32:52 --> Helper loaded: file_helper
INFO - 2018-11-20 08:32:52 --> Helper loaded: email_helper
INFO - 2018-11-20 08:32:52 --> Helper loaded: common_helper
INFO - 2018-11-20 08:32:52 --> Database Driver Class Initialized
DEBUG - 2018-11-20 08:32:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-20 08:32:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-20 08:32:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-20 08:32:52 --> Pagination Class Initialized
INFO - 2018-11-20 08:32:52 --> Helper loaded: form_helper
INFO - 2018-11-20 08:32:52 --> Form Validation Class Initialized
INFO - 2018-11-20 08:32:52 --> Model Class Initialized
INFO - 2018-11-20 08:32:52 --> Controller Class Initialized
INFO - 2018-11-20 08:32:52 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-20 08:32:52 --> Model Class Initialized
INFO - 2018-11-20 08:32:52 --> Model Class Initialized
INFO - 2018-11-20 08:32:52 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/index.php
INFO - 2018-11-20 08:32:52 --> Final output sent to browser
DEBUG - 2018-11-20 08:32:52 --> Total execution time: 0.0510
INFO - 2018-11-20 08:34:04 --> Config Class Initialized
INFO - 2018-11-20 08:34:04 --> Hooks Class Initialized
DEBUG - 2018-11-20 08:34:04 --> UTF-8 Support Enabled
INFO - 2018-11-20 08:34:04 --> Utf8 Class Initialized
INFO - 2018-11-20 08:34:04 --> URI Class Initialized
INFO - 2018-11-20 08:34:04 --> Router Class Initialized
INFO - 2018-11-20 08:34:04 --> Output Class Initialized
INFO - 2018-11-20 08:34:04 --> Security Class Initialized
DEBUG - 2018-11-20 08:34:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-20 08:34:04 --> Input Class Initialized
INFO - 2018-11-20 08:34:04 --> Language Class Initialized
INFO - 2018-11-20 08:34:04 --> Loader Class Initialized
INFO - 2018-11-20 08:34:04 --> Helper loaded: url_helper
INFO - 2018-11-20 08:34:04 --> Helper loaded: file_helper
INFO - 2018-11-20 08:34:04 --> Helper loaded: email_helper
INFO - 2018-11-20 08:34:04 --> Helper loaded: common_helper
INFO - 2018-11-20 08:34:04 --> Database Driver Class Initialized
DEBUG - 2018-11-20 08:34:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-20 08:34:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-20 08:34:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-20 08:34:04 --> Pagination Class Initialized
INFO - 2018-11-20 08:34:04 --> Helper loaded: form_helper
INFO - 2018-11-20 08:34:04 --> Form Validation Class Initialized
INFO - 2018-11-20 08:34:04 --> Model Class Initialized
INFO - 2018-11-20 08:34:04 --> Controller Class Initialized
INFO - 2018-11-20 08:34:04 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-20 08:34:04 --> Model Class Initialized
INFO - 2018-11-20 08:34:04 --> Model Class Initialized
INFO - 2018-11-20 08:34:04 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/index.php
INFO - 2018-11-20 08:34:04 --> Final output sent to browser
DEBUG - 2018-11-20 08:34:04 --> Total execution time: 0.0470
INFO - 2018-11-20 08:35:18 --> Config Class Initialized
INFO - 2018-11-20 08:35:18 --> Hooks Class Initialized
DEBUG - 2018-11-20 08:35:18 --> UTF-8 Support Enabled
INFO - 2018-11-20 08:35:18 --> Utf8 Class Initialized
INFO - 2018-11-20 08:35:18 --> URI Class Initialized
INFO - 2018-11-20 08:35:18 --> Router Class Initialized
INFO - 2018-11-20 08:35:18 --> Output Class Initialized
INFO - 2018-11-20 08:35:18 --> Security Class Initialized
DEBUG - 2018-11-20 08:35:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-20 08:35:18 --> Input Class Initialized
INFO - 2018-11-20 08:35:18 --> Language Class Initialized
INFO - 2018-11-20 08:35:18 --> Loader Class Initialized
INFO - 2018-11-20 08:35:18 --> Helper loaded: url_helper
INFO - 2018-11-20 08:35:18 --> Helper loaded: file_helper
INFO - 2018-11-20 08:35:18 --> Helper loaded: email_helper
INFO - 2018-11-20 08:35:18 --> Helper loaded: common_helper
INFO - 2018-11-20 08:35:18 --> Database Driver Class Initialized
DEBUG - 2018-11-20 08:35:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-20 08:35:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-20 08:35:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-20 08:35:18 --> Pagination Class Initialized
INFO - 2018-11-20 08:35:18 --> Helper loaded: form_helper
INFO - 2018-11-20 08:35:18 --> Form Validation Class Initialized
INFO - 2018-11-20 08:35:18 --> Model Class Initialized
INFO - 2018-11-20 08:35:18 --> Controller Class Initialized
INFO - 2018-11-20 08:35:18 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-20 08:35:18 --> Model Class Initialized
INFO - 2018-11-20 08:35:18 --> Model Class Initialized
INFO - 2018-11-20 08:35:18 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/index.php
INFO - 2018-11-20 08:35:18 --> Final output sent to browser
DEBUG - 2018-11-20 08:35:18 --> Total execution time: 0.0520
INFO - 2018-11-20 08:35:29 --> Config Class Initialized
INFO - 2018-11-20 08:35:29 --> Hooks Class Initialized
DEBUG - 2018-11-20 08:35:29 --> UTF-8 Support Enabled
INFO - 2018-11-20 08:35:29 --> Utf8 Class Initialized
INFO - 2018-11-20 08:35:29 --> URI Class Initialized
INFO - 2018-11-20 08:35:29 --> Router Class Initialized
INFO - 2018-11-20 08:35:29 --> Output Class Initialized
INFO - 2018-11-20 08:35:29 --> Security Class Initialized
DEBUG - 2018-11-20 08:35:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-20 08:35:29 --> Input Class Initialized
INFO - 2018-11-20 08:35:29 --> Language Class Initialized
INFO - 2018-11-20 08:35:29 --> Loader Class Initialized
INFO - 2018-11-20 08:35:29 --> Helper loaded: url_helper
INFO - 2018-11-20 08:35:29 --> Helper loaded: file_helper
INFO - 2018-11-20 08:35:29 --> Helper loaded: email_helper
INFO - 2018-11-20 08:35:29 --> Helper loaded: common_helper
INFO - 2018-11-20 08:35:29 --> Database Driver Class Initialized
DEBUG - 2018-11-20 08:35:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-20 08:35:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-20 08:35:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-20 08:35:29 --> Pagination Class Initialized
INFO - 2018-11-20 08:35:29 --> Helper loaded: form_helper
INFO - 2018-11-20 08:35:29 --> Form Validation Class Initialized
INFO - 2018-11-20 08:35:29 --> Model Class Initialized
INFO - 2018-11-20 08:35:29 --> Controller Class Initialized
INFO - 2018-11-20 08:35:29 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-20 08:35:29 --> Model Class Initialized
INFO - 2018-11-20 08:35:29 --> Model Class Initialized
INFO - 2018-11-20 08:35:29 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/index.php
INFO - 2018-11-20 08:35:29 --> Final output sent to browser
DEBUG - 2018-11-20 08:35:29 --> Total execution time: 0.0560
INFO - 2018-11-20 08:36:05 --> Config Class Initialized
INFO - 2018-11-20 08:36:05 --> Hooks Class Initialized
DEBUG - 2018-11-20 08:36:05 --> UTF-8 Support Enabled
INFO - 2018-11-20 08:36:05 --> Utf8 Class Initialized
INFO - 2018-11-20 08:36:05 --> URI Class Initialized
INFO - 2018-11-20 08:36:05 --> Router Class Initialized
INFO - 2018-11-20 08:36:05 --> Output Class Initialized
INFO - 2018-11-20 08:36:05 --> Security Class Initialized
DEBUG - 2018-11-20 08:36:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-20 08:36:05 --> Input Class Initialized
INFO - 2018-11-20 08:36:05 --> Language Class Initialized
INFO - 2018-11-20 08:36:05 --> Loader Class Initialized
INFO - 2018-11-20 08:36:05 --> Helper loaded: url_helper
INFO - 2018-11-20 08:36:05 --> Helper loaded: file_helper
INFO - 2018-11-20 08:36:05 --> Helper loaded: email_helper
INFO - 2018-11-20 08:36:05 --> Helper loaded: common_helper
INFO - 2018-11-20 08:36:05 --> Database Driver Class Initialized
DEBUG - 2018-11-20 08:36:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-20 08:36:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-20 08:36:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-20 08:36:05 --> Pagination Class Initialized
INFO - 2018-11-20 08:36:05 --> Helper loaded: form_helper
INFO - 2018-11-20 08:36:05 --> Form Validation Class Initialized
INFO - 2018-11-20 08:36:05 --> Model Class Initialized
INFO - 2018-11-20 08:36:05 --> Controller Class Initialized
INFO - 2018-11-20 08:36:05 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-20 08:36:05 --> Model Class Initialized
INFO - 2018-11-20 08:36:05 --> Model Class Initialized
INFO - 2018-11-20 08:36:05 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/index.php
INFO - 2018-11-20 08:36:05 --> Final output sent to browser
DEBUG - 2018-11-20 08:36:05 --> Total execution time: 0.0596
INFO - 2018-11-20 08:38:12 --> Config Class Initialized
INFO - 2018-11-20 08:38:12 --> Hooks Class Initialized
DEBUG - 2018-11-20 08:38:12 --> UTF-8 Support Enabled
INFO - 2018-11-20 08:38:12 --> Utf8 Class Initialized
INFO - 2018-11-20 08:38:12 --> URI Class Initialized
INFO - 2018-11-20 08:38:12 --> Router Class Initialized
INFO - 2018-11-20 08:38:12 --> Output Class Initialized
INFO - 2018-11-20 08:38:12 --> Security Class Initialized
DEBUG - 2018-11-20 08:38:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-20 08:38:12 --> Input Class Initialized
INFO - 2018-11-20 08:38:12 --> Language Class Initialized
INFO - 2018-11-20 08:38:12 --> Loader Class Initialized
INFO - 2018-11-20 08:38:12 --> Helper loaded: url_helper
INFO - 2018-11-20 08:38:12 --> Helper loaded: file_helper
INFO - 2018-11-20 08:38:12 --> Helper loaded: email_helper
INFO - 2018-11-20 08:38:12 --> Helper loaded: common_helper
INFO - 2018-11-20 08:38:12 --> Database Driver Class Initialized
DEBUG - 2018-11-20 08:38:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-20 08:38:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-20 08:38:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-20 08:38:12 --> Pagination Class Initialized
INFO - 2018-11-20 08:38:12 --> Helper loaded: form_helper
INFO - 2018-11-20 08:38:12 --> Form Validation Class Initialized
INFO - 2018-11-20 08:38:12 --> Model Class Initialized
INFO - 2018-11-20 08:38:12 --> Controller Class Initialized
INFO - 2018-11-20 08:38:12 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-20 08:38:12 --> Model Class Initialized
INFO - 2018-11-20 08:38:12 --> Model Class Initialized
INFO - 2018-11-20 08:38:12 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/index.php
INFO - 2018-11-20 08:38:12 --> Final output sent to browser
DEBUG - 2018-11-20 08:38:12 --> Total execution time: 0.0600
INFO - 2018-11-20 08:38:45 --> Config Class Initialized
INFO - 2018-11-20 08:38:45 --> Hooks Class Initialized
DEBUG - 2018-11-20 08:38:45 --> UTF-8 Support Enabled
INFO - 2018-11-20 08:38:45 --> Utf8 Class Initialized
INFO - 2018-11-20 08:38:45 --> URI Class Initialized
INFO - 2018-11-20 08:38:45 --> Router Class Initialized
INFO - 2018-11-20 08:38:45 --> Output Class Initialized
INFO - 2018-11-20 08:38:45 --> Security Class Initialized
DEBUG - 2018-11-20 08:38:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-20 08:38:45 --> Input Class Initialized
INFO - 2018-11-20 08:38:45 --> Language Class Initialized
INFO - 2018-11-20 08:38:45 --> Loader Class Initialized
INFO - 2018-11-20 08:38:45 --> Helper loaded: url_helper
INFO - 2018-11-20 08:38:45 --> Helper loaded: file_helper
INFO - 2018-11-20 08:38:45 --> Helper loaded: email_helper
INFO - 2018-11-20 08:38:45 --> Helper loaded: common_helper
INFO - 2018-11-20 08:38:45 --> Database Driver Class Initialized
DEBUG - 2018-11-20 08:38:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-20 08:38:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-20 08:38:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-20 08:38:45 --> Pagination Class Initialized
INFO - 2018-11-20 08:38:45 --> Helper loaded: form_helper
INFO - 2018-11-20 08:38:45 --> Form Validation Class Initialized
INFO - 2018-11-20 08:38:45 --> Model Class Initialized
INFO - 2018-11-20 08:38:45 --> Controller Class Initialized
INFO - 2018-11-20 08:38:45 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-20 08:38:45 --> Model Class Initialized
INFO - 2018-11-20 08:38:45 --> Model Class Initialized
INFO - 2018-11-20 08:38:45 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/index.php
INFO - 2018-11-20 08:38:45 --> Final output sent to browser
DEBUG - 2018-11-20 08:38:45 --> Total execution time: 0.0590
INFO - 2018-11-20 08:38:49 --> Config Class Initialized
INFO - 2018-11-20 08:38:49 --> Hooks Class Initialized
DEBUG - 2018-11-20 08:38:49 --> UTF-8 Support Enabled
INFO - 2018-11-20 08:38:49 --> Utf8 Class Initialized
INFO - 2018-11-20 08:38:49 --> URI Class Initialized
INFO - 2018-11-20 08:38:49 --> Router Class Initialized
INFO - 2018-11-20 08:38:49 --> Output Class Initialized
INFO - 2018-11-20 08:38:49 --> Security Class Initialized
DEBUG - 2018-11-20 08:38:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-20 08:38:49 --> Input Class Initialized
INFO - 2018-11-20 08:38:49 --> Language Class Initialized
INFO - 2018-11-20 08:38:49 --> Loader Class Initialized
INFO - 2018-11-20 08:38:49 --> Helper loaded: url_helper
INFO - 2018-11-20 08:38:49 --> Helper loaded: file_helper
INFO - 2018-11-20 08:38:49 --> Helper loaded: email_helper
INFO - 2018-11-20 08:38:49 --> Helper loaded: common_helper
INFO - 2018-11-20 08:38:49 --> Database Driver Class Initialized
DEBUG - 2018-11-20 08:38:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-20 08:38:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-20 08:38:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-20 08:38:49 --> Pagination Class Initialized
INFO - 2018-11-20 08:38:49 --> Helper loaded: form_helper
INFO - 2018-11-20 08:38:49 --> Form Validation Class Initialized
INFO - 2018-11-20 08:38:49 --> Model Class Initialized
INFO - 2018-11-20 08:38:49 --> Controller Class Initialized
INFO - 2018-11-20 08:38:49 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-20 08:38:49 --> Model Class Initialized
INFO - 2018-11-20 08:38:49 --> Model Class Initialized
INFO - 2018-11-20 08:38:49 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/index.php
INFO - 2018-11-20 08:38:49 --> Final output sent to browser
DEBUG - 2018-11-20 08:38:49 --> Total execution time: 0.0570
INFO - 2018-11-20 08:38:50 --> Config Class Initialized
INFO - 2018-11-20 08:38:50 --> Hooks Class Initialized
DEBUG - 2018-11-20 08:38:50 --> UTF-8 Support Enabled
INFO - 2018-11-20 08:38:50 --> Utf8 Class Initialized
INFO - 2018-11-20 08:38:50 --> URI Class Initialized
INFO - 2018-11-20 08:38:50 --> Router Class Initialized
INFO - 2018-11-20 08:38:50 --> Output Class Initialized
INFO - 2018-11-20 08:38:50 --> Security Class Initialized
DEBUG - 2018-11-20 08:38:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-20 08:38:50 --> Input Class Initialized
INFO - 2018-11-20 08:38:50 --> Language Class Initialized
INFO - 2018-11-20 08:38:50 --> Loader Class Initialized
INFO - 2018-11-20 08:38:50 --> Helper loaded: url_helper
INFO - 2018-11-20 08:38:50 --> Helper loaded: file_helper
INFO - 2018-11-20 08:38:50 --> Helper loaded: email_helper
INFO - 2018-11-20 08:38:50 --> Helper loaded: common_helper
INFO - 2018-11-20 08:38:50 --> Database Driver Class Initialized
DEBUG - 2018-11-20 08:38:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-20 08:38:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-20 08:38:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-20 08:38:50 --> Pagination Class Initialized
INFO - 2018-11-20 08:38:50 --> Helper loaded: form_helper
INFO - 2018-11-20 08:38:50 --> Form Validation Class Initialized
INFO - 2018-11-20 08:38:50 --> Model Class Initialized
INFO - 2018-11-20 08:38:50 --> Controller Class Initialized
INFO - 2018-11-20 08:38:50 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-20 08:38:50 --> Model Class Initialized
INFO - 2018-11-20 08:38:50 --> Model Class Initialized
INFO - 2018-11-20 08:38:50 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/index.php
INFO - 2018-11-20 08:38:50 --> Final output sent to browser
DEBUG - 2018-11-20 08:38:50 --> Total execution time: 0.0620
INFO - 2018-11-20 08:38:50 --> Config Class Initialized
INFO - 2018-11-20 08:38:50 --> Hooks Class Initialized
DEBUG - 2018-11-20 08:38:50 --> UTF-8 Support Enabled
INFO - 2018-11-20 08:38:50 --> Utf8 Class Initialized
INFO - 2018-11-20 08:38:50 --> URI Class Initialized
INFO - 2018-11-20 08:38:50 --> Router Class Initialized
INFO - 2018-11-20 08:38:50 --> Output Class Initialized
INFO - 2018-11-20 08:38:50 --> Security Class Initialized
DEBUG - 2018-11-20 08:38:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-20 08:38:50 --> Input Class Initialized
INFO - 2018-11-20 08:38:50 --> Language Class Initialized
INFO - 2018-11-20 08:38:50 --> Loader Class Initialized
INFO - 2018-11-20 08:38:50 --> Helper loaded: url_helper
INFO - 2018-11-20 08:38:50 --> Helper loaded: file_helper
INFO - 2018-11-20 08:38:50 --> Helper loaded: email_helper
INFO - 2018-11-20 08:38:50 --> Helper loaded: common_helper
INFO - 2018-11-20 08:38:50 --> Database Driver Class Initialized
DEBUG - 2018-11-20 08:38:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-20 08:38:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-20 08:38:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-20 08:38:50 --> Pagination Class Initialized
INFO - 2018-11-20 08:38:50 --> Helper loaded: form_helper
INFO - 2018-11-20 08:38:50 --> Form Validation Class Initialized
INFO - 2018-11-20 08:38:50 --> Model Class Initialized
INFO - 2018-11-20 08:38:50 --> Controller Class Initialized
INFO - 2018-11-20 08:38:50 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-20 08:38:50 --> Model Class Initialized
INFO - 2018-11-20 08:38:50 --> Model Class Initialized
INFO - 2018-11-20 08:38:50 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/index.php
INFO - 2018-11-20 08:38:50 --> Final output sent to browser
DEBUG - 2018-11-20 08:38:50 --> Total execution time: 0.0600
INFO - 2018-11-20 08:38:50 --> Config Class Initialized
INFO - 2018-11-20 08:38:50 --> Hooks Class Initialized
DEBUG - 2018-11-20 08:38:50 --> UTF-8 Support Enabled
INFO - 2018-11-20 08:38:50 --> Utf8 Class Initialized
INFO - 2018-11-20 08:38:50 --> URI Class Initialized
INFO - 2018-11-20 08:38:50 --> Router Class Initialized
INFO - 2018-11-20 08:38:50 --> Output Class Initialized
INFO - 2018-11-20 08:38:50 --> Security Class Initialized
DEBUG - 2018-11-20 08:38:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-20 08:38:50 --> Input Class Initialized
INFO - 2018-11-20 08:38:50 --> Language Class Initialized
INFO - 2018-11-20 08:38:50 --> Loader Class Initialized
INFO - 2018-11-20 08:38:50 --> Helper loaded: url_helper
INFO - 2018-11-20 08:38:50 --> Helper loaded: file_helper
INFO - 2018-11-20 08:38:50 --> Helper loaded: email_helper
INFO - 2018-11-20 08:38:50 --> Helper loaded: common_helper
INFO - 2018-11-20 08:38:50 --> Database Driver Class Initialized
DEBUG - 2018-11-20 08:38:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-20 08:38:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-20 08:38:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-20 08:38:50 --> Pagination Class Initialized
INFO - 2018-11-20 08:38:50 --> Helper loaded: form_helper
INFO - 2018-11-20 08:38:50 --> Form Validation Class Initialized
INFO - 2018-11-20 08:38:50 --> Model Class Initialized
INFO - 2018-11-20 08:38:50 --> Controller Class Initialized
INFO - 2018-11-20 08:38:50 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-20 08:38:50 --> Model Class Initialized
INFO - 2018-11-20 08:38:50 --> Model Class Initialized
INFO - 2018-11-20 08:38:50 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/index.php
INFO - 2018-11-20 08:38:50 --> Final output sent to browser
DEBUG - 2018-11-20 08:38:50 --> Total execution time: 0.0660
INFO - 2018-11-20 08:39:48 --> Config Class Initialized
INFO - 2018-11-20 08:39:48 --> Hooks Class Initialized
DEBUG - 2018-11-20 08:39:48 --> UTF-8 Support Enabled
INFO - 2018-11-20 08:39:48 --> Utf8 Class Initialized
INFO - 2018-11-20 08:39:48 --> URI Class Initialized
INFO - 2018-11-20 08:39:48 --> Router Class Initialized
INFO - 2018-11-20 08:39:48 --> Output Class Initialized
INFO - 2018-11-20 08:39:48 --> Security Class Initialized
DEBUG - 2018-11-20 08:39:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-20 08:39:48 --> Input Class Initialized
INFO - 2018-11-20 08:39:48 --> Language Class Initialized
INFO - 2018-11-20 08:39:48 --> Loader Class Initialized
INFO - 2018-11-20 08:39:48 --> Helper loaded: url_helper
INFO - 2018-11-20 08:39:48 --> Helper loaded: file_helper
INFO - 2018-11-20 08:39:48 --> Helper loaded: email_helper
INFO - 2018-11-20 08:39:48 --> Helper loaded: common_helper
INFO - 2018-11-20 08:39:48 --> Database Driver Class Initialized
DEBUG - 2018-11-20 08:39:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-20 08:39:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-20 08:39:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-20 08:39:48 --> Pagination Class Initialized
INFO - 2018-11-20 08:39:48 --> Helper loaded: form_helper
INFO - 2018-11-20 08:39:48 --> Form Validation Class Initialized
INFO - 2018-11-20 08:39:48 --> Model Class Initialized
INFO - 2018-11-20 08:39:48 --> Controller Class Initialized
INFO - 2018-11-20 08:39:48 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-20 08:39:48 --> Model Class Initialized
INFO - 2018-11-20 08:39:48 --> Model Class Initialized
INFO - 2018-11-20 08:39:48 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/index.php
INFO - 2018-11-20 08:39:48 --> Final output sent to browser
DEBUG - 2018-11-20 08:39:48 --> Total execution time: 0.0660
INFO - 2018-11-20 08:40:06 --> Config Class Initialized
INFO - 2018-11-20 08:40:06 --> Hooks Class Initialized
DEBUG - 2018-11-20 08:40:06 --> UTF-8 Support Enabled
INFO - 2018-11-20 08:40:06 --> Utf8 Class Initialized
INFO - 2018-11-20 08:40:06 --> URI Class Initialized
INFO - 2018-11-20 08:40:06 --> Router Class Initialized
INFO - 2018-11-20 08:40:06 --> Output Class Initialized
INFO - 2018-11-20 08:40:06 --> Security Class Initialized
DEBUG - 2018-11-20 08:40:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-20 08:40:06 --> Input Class Initialized
INFO - 2018-11-20 08:40:06 --> Language Class Initialized
INFO - 2018-11-20 08:40:06 --> Loader Class Initialized
INFO - 2018-11-20 08:40:06 --> Helper loaded: url_helper
INFO - 2018-11-20 08:40:06 --> Helper loaded: file_helper
INFO - 2018-11-20 08:40:06 --> Helper loaded: email_helper
INFO - 2018-11-20 08:40:06 --> Helper loaded: common_helper
INFO - 2018-11-20 08:40:06 --> Database Driver Class Initialized
DEBUG - 2018-11-20 08:40:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-20 08:40:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-20 08:40:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-20 08:40:06 --> Pagination Class Initialized
INFO - 2018-11-20 08:40:06 --> Helper loaded: form_helper
INFO - 2018-11-20 08:40:06 --> Form Validation Class Initialized
INFO - 2018-11-20 08:40:06 --> Model Class Initialized
INFO - 2018-11-20 08:40:06 --> Controller Class Initialized
INFO - 2018-11-20 08:40:06 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-20 08:40:06 --> Model Class Initialized
INFO - 2018-11-20 08:40:06 --> Model Class Initialized
INFO - 2018-11-20 08:40:06 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/index.php
INFO - 2018-11-20 08:40:06 --> Final output sent to browser
DEBUG - 2018-11-20 08:40:06 --> Total execution time: 0.0630
INFO - 2018-11-20 08:40:20 --> Config Class Initialized
INFO - 2018-11-20 08:40:20 --> Hooks Class Initialized
DEBUG - 2018-11-20 08:40:20 --> UTF-8 Support Enabled
INFO - 2018-11-20 08:40:20 --> Utf8 Class Initialized
INFO - 2018-11-20 08:40:20 --> URI Class Initialized
INFO - 2018-11-20 08:40:20 --> Router Class Initialized
INFO - 2018-11-20 08:40:20 --> Output Class Initialized
INFO - 2018-11-20 08:40:20 --> Security Class Initialized
DEBUG - 2018-11-20 08:40:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-20 08:40:20 --> Input Class Initialized
INFO - 2018-11-20 08:40:20 --> Language Class Initialized
INFO - 2018-11-20 08:40:20 --> Loader Class Initialized
INFO - 2018-11-20 08:40:20 --> Helper loaded: url_helper
INFO - 2018-11-20 08:40:20 --> Helper loaded: file_helper
INFO - 2018-11-20 08:40:20 --> Helper loaded: email_helper
INFO - 2018-11-20 08:40:20 --> Helper loaded: common_helper
INFO - 2018-11-20 08:40:20 --> Database Driver Class Initialized
DEBUG - 2018-11-20 08:40:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-20 08:40:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-20 08:40:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-20 08:40:20 --> Pagination Class Initialized
INFO - 2018-11-20 08:40:20 --> Helper loaded: form_helper
INFO - 2018-11-20 08:40:20 --> Form Validation Class Initialized
INFO - 2018-11-20 08:40:20 --> Model Class Initialized
INFO - 2018-11-20 08:40:20 --> Controller Class Initialized
INFO - 2018-11-20 08:40:20 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-20 08:40:20 --> Model Class Initialized
INFO - 2018-11-20 08:40:20 --> Model Class Initialized
INFO - 2018-11-20 08:40:20 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/index.php
INFO - 2018-11-20 08:40:20 --> Final output sent to browser
DEBUG - 2018-11-20 08:40:20 --> Total execution time: 0.0900
INFO - 2018-11-20 08:41:59 --> Config Class Initialized
INFO - 2018-11-20 08:41:59 --> Hooks Class Initialized
DEBUG - 2018-11-20 08:41:59 --> UTF-8 Support Enabled
INFO - 2018-11-20 08:41:59 --> Utf8 Class Initialized
INFO - 2018-11-20 08:41:59 --> URI Class Initialized
INFO - 2018-11-20 08:41:59 --> Router Class Initialized
INFO - 2018-11-20 08:41:59 --> Output Class Initialized
INFO - 2018-11-20 08:41:59 --> Security Class Initialized
DEBUG - 2018-11-20 08:41:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-20 08:41:59 --> Input Class Initialized
INFO - 2018-11-20 08:41:59 --> Language Class Initialized
INFO - 2018-11-20 08:41:59 --> Loader Class Initialized
INFO - 2018-11-20 08:41:59 --> Helper loaded: url_helper
INFO - 2018-11-20 08:41:59 --> Helper loaded: file_helper
INFO - 2018-11-20 08:41:59 --> Helper loaded: email_helper
INFO - 2018-11-20 08:41:59 --> Helper loaded: common_helper
INFO - 2018-11-20 08:41:59 --> Database Driver Class Initialized
DEBUG - 2018-11-20 08:41:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-20 08:41:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-20 08:41:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-20 08:41:59 --> Pagination Class Initialized
INFO - 2018-11-20 08:41:59 --> Helper loaded: form_helper
INFO - 2018-11-20 08:41:59 --> Form Validation Class Initialized
INFO - 2018-11-20 08:41:59 --> Model Class Initialized
INFO - 2018-11-20 08:41:59 --> Controller Class Initialized
INFO - 2018-11-20 08:41:59 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-20 08:41:59 --> Model Class Initialized
INFO - 2018-11-20 08:41:59 --> Model Class Initialized
INFO - 2018-11-20 08:41:59 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/index.php
INFO - 2018-11-20 08:41:59 --> Final output sent to browser
DEBUG - 2018-11-20 08:41:59 --> Total execution time: 0.0590
INFO - 2018-11-20 08:43:24 --> Config Class Initialized
INFO - 2018-11-20 08:43:24 --> Hooks Class Initialized
DEBUG - 2018-11-20 08:43:24 --> UTF-8 Support Enabled
INFO - 2018-11-20 08:43:24 --> Utf8 Class Initialized
INFO - 2018-11-20 08:43:24 --> URI Class Initialized
INFO - 2018-11-20 08:43:24 --> Router Class Initialized
INFO - 2018-11-20 08:43:24 --> Output Class Initialized
INFO - 2018-11-20 08:43:24 --> Security Class Initialized
DEBUG - 2018-11-20 08:43:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-20 08:43:24 --> Input Class Initialized
INFO - 2018-11-20 08:43:24 --> Language Class Initialized
INFO - 2018-11-20 08:43:24 --> Loader Class Initialized
INFO - 2018-11-20 08:43:24 --> Helper loaded: url_helper
INFO - 2018-11-20 08:43:24 --> Helper loaded: file_helper
INFO - 2018-11-20 08:43:24 --> Helper loaded: email_helper
INFO - 2018-11-20 08:43:24 --> Helper loaded: common_helper
INFO - 2018-11-20 08:43:24 --> Database Driver Class Initialized
DEBUG - 2018-11-20 08:43:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-20 08:43:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-20 08:43:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-20 08:43:24 --> Pagination Class Initialized
INFO - 2018-11-20 08:43:24 --> Helper loaded: form_helper
INFO - 2018-11-20 08:43:24 --> Form Validation Class Initialized
INFO - 2018-11-20 08:43:24 --> Model Class Initialized
INFO - 2018-11-20 08:43:24 --> Controller Class Initialized
INFO - 2018-11-20 08:43:24 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-20 08:43:24 --> Model Class Initialized
INFO - 2018-11-20 08:43:24 --> Model Class Initialized
INFO - 2018-11-20 08:43:24 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/index.php
INFO - 2018-11-20 08:43:24 --> Final output sent to browser
DEBUG - 2018-11-20 08:43:24 --> Total execution time: 0.0530
INFO - 2018-11-20 08:44:54 --> Config Class Initialized
INFO - 2018-11-20 08:44:54 --> Hooks Class Initialized
DEBUG - 2018-11-20 08:44:54 --> UTF-8 Support Enabled
INFO - 2018-11-20 08:44:54 --> Utf8 Class Initialized
INFO - 2018-11-20 08:44:54 --> URI Class Initialized
INFO - 2018-11-20 08:44:54 --> Router Class Initialized
INFO - 2018-11-20 08:44:54 --> Output Class Initialized
INFO - 2018-11-20 08:44:54 --> Security Class Initialized
DEBUG - 2018-11-20 08:44:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-20 08:44:54 --> Input Class Initialized
INFO - 2018-11-20 08:44:54 --> Language Class Initialized
INFO - 2018-11-20 08:44:54 --> Loader Class Initialized
INFO - 2018-11-20 08:44:54 --> Helper loaded: url_helper
INFO - 2018-11-20 08:44:54 --> Helper loaded: file_helper
INFO - 2018-11-20 08:44:54 --> Helper loaded: email_helper
INFO - 2018-11-20 08:44:54 --> Helper loaded: common_helper
INFO - 2018-11-20 08:44:54 --> Database Driver Class Initialized
DEBUG - 2018-11-20 08:44:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-20 08:44:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-20 08:44:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-20 08:44:54 --> Pagination Class Initialized
INFO - 2018-11-20 08:44:54 --> Helper loaded: form_helper
INFO - 2018-11-20 08:44:54 --> Form Validation Class Initialized
INFO - 2018-11-20 08:44:54 --> Model Class Initialized
INFO - 2018-11-20 08:44:54 --> Controller Class Initialized
INFO - 2018-11-20 08:44:54 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-20 08:44:54 --> Model Class Initialized
INFO - 2018-11-20 08:44:54 --> Model Class Initialized
INFO - 2018-11-20 08:44:54 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/index.php
INFO - 2018-11-20 08:44:54 --> Final output sent to browser
DEBUG - 2018-11-20 08:44:54 --> Total execution time: 0.0600
INFO - 2018-11-20 08:48:58 --> Config Class Initialized
INFO - 2018-11-20 08:48:58 --> Hooks Class Initialized
DEBUG - 2018-11-20 08:48:58 --> UTF-8 Support Enabled
INFO - 2018-11-20 08:48:58 --> Utf8 Class Initialized
INFO - 2018-11-20 08:48:58 --> URI Class Initialized
INFO - 2018-11-20 08:48:58 --> Router Class Initialized
INFO - 2018-11-20 08:48:58 --> Output Class Initialized
INFO - 2018-11-20 08:48:58 --> Security Class Initialized
DEBUG - 2018-11-20 08:48:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-20 08:48:58 --> Input Class Initialized
INFO - 2018-11-20 08:48:58 --> Language Class Initialized
INFO - 2018-11-20 08:48:58 --> Loader Class Initialized
INFO - 2018-11-20 08:48:58 --> Helper loaded: url_helper
INFO - 2018-11-20 08:48:58 --> Helper loaded: file_helper
INFO - 2018-11-20 08:48:58 --> Helper loaded: email_helper
INFO - 2018-11-20 08:48:58 --> Helper loaded: common_helper
INFO - 2018-11-20 08:48:58 --> Database Driver Class Initialized
DEBUG - 2018-11-20 08:48:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-20 08:48:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-20 08:48:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-20 08:48:58 --> Pagination Class Initialized
INFO - 2018-11-20 08:48:58 --> Helper loaded: form_helper
INFO - 2018-11-20 08:48:58 --> Form Validation Class Initialized
INFO - 2018-11-20 08:48:58 --> Model Class Initialized
INFO - 2018-11-20 08:48:58 --> Controller Class Initialized
INFO - 2018-11-20 08:48:58 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-20 08:48:58 --> Model Class Initialized
INFO - 2018-11-20 08:48:58 --> Model Class Initialized
ERROR - 2018-11-20 08:48:58 --> Severity: Notice --> Undefined variable: error_msg C:\xampp\htdocs\wetinuneed\application\views\admin\index.php 63
ERROR - 2018-11-20 08:48:58 --> Severity: Notice --> Undefined variable: error_msg C:\xampp\htdocs\wetinuneed\application\views\admin\index.php 70
INFO - 2018-11-20 08:48:58 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/index.php
INFO - 2018-11-20 08:48:58 --> Final output sent to browser
DEBUG - 2018-11-20 08:48:58 --> Total execution time: 0.0626
INFO - 2018-11-20 08:50:26 --> Config Class Initialized
INFO - 2018-11-20 08:50:26 --> Hooks Class Initialized
DEBUG - 2018-11-20 08:50:26 --> UTF-8 Support Enabled
INFO - 2018-11-20 08:50:26 --> Utf8 Class Initialized
INFO - 2018-11-20 08:50:26 --> URI Class Initialized
INFO - 2018-11-20 08:50:26 --> Router Class Initialized
INFO - 2018-11-20 08:50:26 --> Output Class Initialized
INFO - 2018-11-20 08:50:26 --> Security Class Initialized
DEBUG - 2018-11-20 08:50:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-20 08:50:26 --> Input Class Initialized
INFO - 2018-11-20 08:50:26 --> Language Class Initialized
INFO - 2018-11-20 08:50:26 --> Loader Class Initialized
INFO - 2018-11-20 08:50:26 --> Helper loaded: url_helper
INFO - 2018-11-20 08:50:26 --> Helper loaded: file_helper
INFO - 2018-11-20 08:50:26 --> Helper loaded: email_helper
INFO - 2018-11-20 08:50:26 --> Helper loaded: common_helper
INFO - 2018-11-20 08:50:26 --> Database Driver Class Initialized
DEBUG - 2018-11-20 08:50:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-20 08:50:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-20 08:50:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-20 08:50:26 --> Pagination Class Initialized
INFO - 2018-11-20 08:50:26 --> Helper loaded: form_helper
INFO - 2018-11-20 08:50:26 --> Form Validation Class Initialized
INFO - 2018-11-20 08:50:26 --> Model Class Initialized
INFO - 2018-11-20 08:50:26 --> Controller Class Initialized
INFO - 2018-11-20 08:50:26 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-20 08:50:26 --> Model Class Initialized
INFO - 2018-11-20 08:50:26 --> Model Class Initialized
ERROR - 2018-11-20 08:50:26 --> Severity: Warning --> Illegal string offset 'userid' C:\xampp\htdocs\wetinuneed\application\views\admin\index.php 63
ERROR - 2018-11-20 08:50:26 --> Severity: Notice --> Uninitialized string offset: 0 C:\xampp\htdocs\wetinuneed\application\views\admin\index.php 63
ERROR - 2018-11-20 08:50:26 --> Severity: Warning --> Illegal string offset 'password' C:\xampp\htdocs\wetinuneed\application\views\admin\index.php 70
ERROR - 2018-11-20 08:50:26 --> Severity: Notice --> Uninitialized string offset: 0 C:\xampp\htdocs\wetinuneed\application\views\admin\index.php 70
INFO - 2018-11-20 08:50:26 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/index.php
INFO - 2018-11-20 08:50:26 --> Final output sent to browser
DEBUG - 2018-11-20 08:50:26 --> Total execution time: 0.0630
INFO - 2018-11-20 08:51:34 --> Config Class Initialized
INFO - 2018-11-20 08:51:34 --> Hooks Class Initialized
DEBUG - 2018-11-20 08:51:34 --> UTF-8 Support Enabled
INFO - 2018-11-20 08:51:34 --> Utf8 Class Initialized
INFO - 2018-11-20 08:51:34 --> URI Class Initialized
INFO - 2018-11-20 08:51:34 --> Router Class Initialized
INFO - 2018-11-20 08:51:34 --> Output Class Initialized
INFO - 2018-11-20 08:51:34 --> Security Class Initialized
DEBUG - 2018-11-20 08:51:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-20 08:51:34 --> Input Class Initialized
INFO - 2018-11-20 08:51:34 --> Language Class Initialized
INFO - 2018-11-20 08:51:34 --> Loader Class Initialized
INFO - 2018-11-20 08:51:34 --> Helper loaded: url_helper
INFO - 2018-11-20 08:51:34 --> Helper loaded: file_helper
INFO - 2018-11-20 08:51:34 --> Helper loaded: email_helper
INFO - 2018-11-20 08:51:34 --> Helper loaded: common_helper
INFO - 2018-11-20 08:51:34 --> Database Driver Class Initialized
DEBUG - 2018-11-20 08:51:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-20 08:51:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-20 08:51:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-20 08:51:34 --> Pagination Class Initialized
INFO - 2018-11-20 08:51:34 --> Helper loaded: form_helper
INFO - 2018-11-20 08:51:34 --> Form Validation Class Initialized
INFO - 2018-11-20 08:51:34 --> Model Class Initialized
INFO - 2018-11-20 08:51:34 --> Controller Class Initialized
INFO - 2018-11-20 08:51:34 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-20 08:51:34 --> Model Class Initialized
INFO - 2018-11-20 08:51:34 --> Model Class Initialized
INFO - 2018-11-20 08:51:34 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/index.php
INFO - 2018-11-20 08:51:34 --> Final output sent to browser
DEBUG - 2018-11-20 08:51:34 --> Total execution time: 0.0666
INFO - 2018-11-20 08:55:39 --> Config Class Initialized
INFO - 2018-11-20 08:55:39 --> Hooks Class Initialized
DEBUG - 2018-11-20 08:55:39 --> UTF-8 Support Enabled
INFO - 2018-11-20 08:55:39 --> Utf8 Class Initialized
INFO - 2018-11-20 08:55:39 --> URI Class Initialized
INFO - 2018-11-20 08:55:39 --> Router Class Initialized
INFO - 2018-11-20 08:55:39 --> Output Class Initialized
INFO - 2018-11-20 08:55:39 --> Security Class Initialized
DEBUG - 2018-11-20 08:55:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-20 08:55:39 --> Input Class Initialized
INFO - 2018-11-20 08:55:39 --> Language Class Initialized
INFO - 2018-11-20 08:55:39 --> Loader Class Initialized
INFO - 2018-11-20 08:55:39 --> Helper loaded: url_helper
INFO - 2018-11-20 08:55:39 --> Helper loaded: file_helper
INFO - 2018-11-20 08:55:39 --> Helper loaded: email_helper
INFO - 2018-11-20 08:55:39 --> Helper loaded: common_helper
INFO - 2018-11-20 08:55:39 --> Database Driver Class Initialized
DEBUG - 2018-11-20 08:55:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-20 08:55:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-20 08:55:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-20 08:55:39 --> Pagination Class Initialized
INFO - 2018-11-20 08:55:39 --> Helper loaded: form_helper
INFO - 2018-11-20 08:55:39 --> Form Validation Class Initialized
INFO - 2018-11-20 08:55:39 --> Model Class Initialized
INFO - 2018-11-20 08:55:39 --> Controller Class Initialized
INFO - 2018-11-20 08:55:39 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-20 08:55:39 --> Model Class Initialized
INFO - 2018-11-20 08:55:39 --> Model Class Initialized
INFO - 2018-11-20 08:55:39 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/index.php
INFO - 2018-11-20 08:55:39 --> Final output sent to browser
DEBUG - 2018-11-20 08:55:39 --> Total execution time: 0.0540
INFO - 2018-11-20 08:56:08 --> Config Class Initialized
INFO - 2018-11-20 08:56:08 --> Hooks Class Initialized
DEBUG - 2018-11-20 08:56:08 --> UTF-8 Support Enabled
INFO - 2018-11-20 08:56:08 --> Utf8 Class Initialized
INFO - 2018-11-20 08:56:08 --> URI Class Initialized
INFO - 2018-11-20 08:56:08 --> Router Class Initialized
INFO - 2018-11-20 08:56:08 --> Output Class Initialized
INFO - 2018-11-20 08:56:08 --> Security Class Initialized
DEBUG - 2018-11-20 08:56:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-20 08:56:08 --> Input Class Initialized
INFO - 2018-11-20 08:56:08 --> Language Class Initialized
INFO - 2018-11-20 08:56:08 --> Loader Class Initialized
INFO - 2018-11-20 08:56:08 --> Helper loaded: url_helper
INFO - 2018-11-20 08:56:08 --> Helper loaded: file_helper
INFO - 2018-11-20 08:56:08 --> Helper loaded: email_helper
INFO - 2018-11-20 08:56:08 --> Helper loaded: common_helper
INFO - 2018-11-20 08:56:08 --> Database Driver Class Initialized
DEBUG - 2018-11-20 08:56:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-20 08:56:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-20 08:56:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-20 08:56:08 --> Pagination Class Initialized
INFO - 2018-11-20 08:56:08 --> Helper loaded: form_helper
INFO - 2018-11-20 08:56:08 --> Form Validation Class Initialized
INFO - 2018-11-20 08:56:08 --> Model Class Initialized
INFO - 2018-11-20 08:56:08 --> Controller Class Initialized
INFO - 2018-11-20 08:56:08 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-20 08:56:08 --> Model Class Initialized
INFO - 2018-11-20 08:56:08 --> Model Class Initialized
INFO - 2018-11-20 08:56:08 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/index.php
INFO - 2018-11-20 08:56:08 --> Final output sent to browser
DEBUG - 2018-11-20 08:56:08 --> Total execution time: 0.0610
INFO - 2018-11-20 08:56:48 --> Config Class Initialized
INFO - 2018-11-20 08:56:48 --> Hooks Class Initialized
DEBUG - 2018-11-20 08:56:48 --> UTF-8 Support Enabled
INFO - 2018-11-20 08:56:48 --> Utf8 Class Initialized
INFO - 2018-11-20 08:56:48 --> URI Class Initialized
INFO - 2018-11-20 08:56:48 --> Router Class Initialized
INFO - 2018-11-20 08:56:48 --> Output Class Initialized
INFO - 2018-11-20 08:56:48 --> Security Class Initialized
DEBUG - 2018-11-20 08:56:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-20 08:56:48 --> Input Class Initialized
INFO - 2018-11-20 08:56:48 --> Language Class Initialized
INFO - 2018-11-20 08:56:48 --> Loader Class Initialized
INFO - 2018-11-20 08:56:48 --> Helper loaded: url_helper
INFO - 2018-11-20 08:56:48 --> Helper loaded: file_helper
INFO - 2018-11-20 08:56:48 --> Helper loaded: email_helper
INFO - 2018-11-20 08:56:48 --> Helper loaded: common_helper
INFO - 2018-11-20 08:56:48 --> Database Driver Class Initialized
DEBUG - 2018-11-20 08:56:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-20 08:56:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-20 08:56:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-20 08:56:48 --> Pagination Class Initialized
INFO - 2018-11-20 08:56:48 --> Helper loaded: form_helper
INFO - 2018-11-20 08:56:48 --> Form Validation Class Initialized
INFO - 2018-11-20 08:56:48 --> Model Class Initialized
INFO - 2018-11-20 08:56:48 --> Controller Class Initialized
INFO - 2018-11-20 08:56:48 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-20 08:56:48 --> Model Class Initialized
INFO - 2018-11-20 08:56:48 --> Model Class Initialized
INFO - 2018-11-20 08:56:48 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/index.php
INFO - 2018-11-20 08:56:48 --> Final output sent to browser
DEBUG - 2018-11-20 08:56:48 --> Total execution time: 0.0610
INFO - 2018-11-20 08:56:49 --> Config Class Initialized
INFO - 2018-11-20 08:56:49 --> Hooks Class Initialized
DEBUG - 2018-11-20 08:56:49 --> UTF-8 Support Enabled
INFO - 2018-11-20 08:56:49 --> Utf8 Class Initialized
INFO - 2018-11-20 08:56:49 --> URI Class Initialized
INFO - 2018-11-20 08:56:49 --> Router Class Initialized
INFO - 2018-11-20 08:56:49 --> Output Class Initialized
INFO - 2018-11-20 08:56:49 --> Security Class Initialized
DEBUG - 2018-11-20 08:56:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-20 08:56:49 --> Input Class Initialized
INFO - 2018-11-20 08:56:49 --> Language Class Initialized
INFO - 2018-11-20 08:56:49 --> Loader Class Initialized
INFO - 2018-11-20 08:56:49 --> Helper loaded: url_helper
INFO - 2018-11-20 08:56:49 --> Helper loaded: file_helper
INFO - 2018-11-20 08:56:49 --> Helper loaded: email_helper
INFO - 2018-11-20 08:56:49 --> Helper loaded: common_helper
INFO - 2018-11-20 08:56:49 --> Database Driver Class Initialized
DEBUG - 2018-11-20 08:56:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-20 08:56:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-20 08:56:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-20 08:56:49 --> Pagination Class Initialized
INFO - 2018-11-20 08:56:49 --> Helper loaded: form_helper
INFO - 2018-11-20 08:56:49 --> Form Validation Class Initialized
INFO - 2018-11-20 08:56:49 --> Model Class Initialized
INFO - 2018-11-20 08:56:49 --> Controller Class Initialized
INFO - 2018-11-20 08:56:49 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-20 08:56:49 --> Model Class Initialized
INFO - 2018-11-20 08:56:49 --> Model Class Initialized
INFO - 2018-11-20 08:56:49 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/index.php
INFO - 2018-11-20 08:56:49 --> Final output sent to browser
DEBUG - 2018-11-20 08:56:49 --> Total execution time: 0.0656
INFO - 2018-11-20 08:57:04 --> Config Class Initialized
INFO - 2018-11-20 08:57:04 --> Hooks Class Initialized
DEBUG - 2018-11-20 08:57:04 --> UTF-8 Support Enabled
INFO - 2018-11-20 08:57:04 --> Utf8 Class Initialized
INFO - 2018-11-20 08:57:04 --> URI Class Initialized
INFO - 2018-11-20 08:57:04 --> Router Class Initialized
INFO - 2018-11-20 08:57:04 --> Output Class Initialized
INFO - 2018-11-20 08:57:04 --> Security Class Initialized
DEBUG - 2018-11-20 08:57:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-20 08:57:04 --> Input Class Initialized
INFO - 2018-11-20 08:57:04 --> Language Class Initialized
INFO - 2018-11-20 08:57:04 --> Loader Class Initialized
INFO - 2018-11-20 08:57:04 --> Helper loaded: url_helper
INFO - 2018-11-20 08:57:04 --> Helper loaded: file_helper
INFO - 2018-11-20 08:57:04 --> Helper loaded: email_helper
INFO - 2018-11-20 08:57:04 --> Helper loaded: common_helper
INFO - 2018-11-20 08:57:04 --> Database Driver Class Initialized
DEBUG - 2018-11-20 08:57:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-20 08:57:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-20 08:57:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-20 08:57:04 --> Pagination Class Initialized
INFO - 2018-11-20 08:57:04 --> Helper loaded: form_helper
INFO - 2018-11-20 08:57:04 --> Form Validation Class Initialized
INFO - 2018-11-20 08:57:04 --> Model Class Initialized
INFO - 2018-11-20 08:57:04 --> Controller Class Initialized
INFO - 2018-11-20 08:57:04 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-20 08:57:04 --> Model Class Initialized
INFO - 2018-11-20 08:57:04 --> Model Class Initialized
INFO - 2018-11-20 08:57:04 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/index.php
INFO - 2018-11-20 08:57:04 --> Final output sent to browser
DEBUG - 2018-11-20 08:57:04 --> Total execution time: 0.0570
INFO - 2018-11-20 08:57:47 --> Config Class Initialized
INFO - 2018-11-20 08:57:47 --> Hooks Class Initialized
DEBUG - 2018-11-20 08:57:47 --> UTF-8 Support Enabled
INFO - 2018-11-20 08:57:47 --> Utf8 Class Initialized
INFO - 2018-11-20 08:57:47 --> URI Class Initialized
INFO - 2018-11-20 08:57:47 --> Router Class Initialized
INFO - 2018-11-20 08:57:47 --> Output Class Initialized
INFO - 2018-11-20 08:57:47 --> Security Class Initialized
DEBUG - 2018-11-20 08:57:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-20 08:57:47 --> Input Class Initialized
INFO - 2018-11-20 08:57:47 --> Language Class Initialized
INFO - 2018-11-20 08:57:47 --> Loader Class Initialized
INFO - 2018-11-20 08:57:47 --> Helper loaded: url_helper
INFO - 2018-11-20 08:57:47 --> Helper loaded: file_helper
INFO - 2018-11-20 08:57:47 --> Helper loaded: email_helper
INFO - 2018-11-20 08:57:47 --> Helper loaded: common_helper
INFO - 2018-11-20 08:57:47 --> Database Driver Class Initialized
DEBUG - 2018-11-20 08:57:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-20 08:57:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-20 08:57:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-20 08:57:47 --> Pagination Class Initialized
INFO - 2018-11-20 08:57:47 --> Helper loaded: form_helper
INFO - 2018-11-20 08:57:47 --> Form Validation Class Initialized
INFO - 2018-11-20 08:57:47 --> Model Class Initialized
INFO - 2018-11-20 08:57:47 --> Controller Class Initialized
INFO - 2018-11-20 08:57:47 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-20 08:57:47 --> Model Class Initialized
INFO - 2018-11-20 08:57:47 --> Model Class Initialized
INFO - 2018-11-20 08:57:47 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/index.php
INFO - 2018-11-20 08:57:47 --> Final output sent to browser
DEBUG - 2018-11-20 08:57:47 --> Total execution time: 0.0676
INFO - 2018-11-20 08:57:58 --> Config Class Initialized
INFO - 2018-11-20 08:57:58 --> Hooks Class Initialized
DEBUG - 2018-11-20 08:57:58 --> UTF-8 Support Enabled
INFO - 2018-11-20 08:57:58 --> Utf8 Class Initialized
INFO - 2018-11-20 08:57:58 --> URI Class Initialized
INFO - 2018-11-20 08:57:58 --> Router Class Initialized
INFO - 2018-11-20 08:57:58 --> Output Class Initialized
INFO - 2018-11-20 08:57:58 --> Security Class Initialized
DEBUG - 2018-11-20 08:57:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-20 08:57:58 --> Input Class Initialized
INFO - 2018-11-20 08:57:58 --> Language Class Initialized
INFO - 2018-11-20 08:57:58 --> Loader Class Initialized
INFO - 2018-11-20 08:57:58 --> Helper loaded: url_helper
INFO - 2018-11-20 08:57:58 --> Helper loaded: file_helper
INFO - 2018-11-20 08:57:58 --> Helper loaded: email_helper
INFO - 2018-11-20 08:57:58 --> Helper loaded: common_helper
INFO - 2018-11-20 08:57:58 --> Database Driver Class Initialized
DEBUG - 2018-11-20 08:57:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-20 08:57:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-20 08:57:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-20 08:57:58 --> Pagination Class Initialized
INFO - 2018-11-20 08:57:58 --> Helper loaded: form_helper
INFO - 2018-11-20 08:57:58 --> Form Validation Class Initialized
INFO - 2018-11-20 08:57:58 --> Model Class Initialized
INFO - 2018-11-20 08:57:58 --> Controller Class Initialized
INFO - 2018-11-20 08:57:58 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-20 08:57:58 --> Model Class Initialized
INFO - 2018-11-20 08:57:58 --> Model Class Initialized
INFO - 2018-11-20 08:57:58 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/index.php
INFO - 2018-11-20 08:57:58 --> Final output sent to browser
DEBUG - 2018-11-20 08:57:58 --> Total execution time: 0.0800
INFO - 2018-11-20 08:58:21 --> Config Class Initialized
INFO - 2018-11-20 08:58:21 --> Hooks Class Initialized
DEBUG - 2018-11-20 08:58:21 --> UTF-8 Support Enabled
INFO - 2018-11-20 08:58:21 --> Utf8 Class Initialized
INFO - 2018-11-20 08:58:21 --> URI Class Initialized
INFO - 2018-11-20 08:58:21 --> Router Class Initialized
INFO - 2018-11-20 08:58:21 --> Output Class Initialized
INFO - 2018-11-20 08:58:21 --> Security Class Initialized
DEBUG - 2018-11-20 08:58:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-20 08:58:21 --> Input Class Initialized
INFO - 2018-11-20 08:58:21 --> Language Class Initialized
INFO - 2018-11-20 08:58:21 --> Loader Class Initialized
INFO - 2018-11-20 08:58:21 --> Helper loaded: url_helper
INFO - 2018-11-20 08:58:21 --> Helper loaded: file_helper
INFO - 2018-11-20 08:58:21 --> Helper loaded: email_helper
INFO - 2018-11-20 08:58:21 --> Helper loaded: common_helper
INFO - 2018-11-20 08:58:21 --> Database Driver Class Initialized
DEBUG - 2018-11-20 08:58:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-20 08:58:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-20 08:58:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-20 08:58:21 --> Pagination Class Initialized
INFO - 2018-11-20 08:58:21 --> Helper loaded: form_helper
INFO - 2018-11-20 08:58:21 --> Form Validation Class Initialized
INFO - 2018-11-20 08:58:21 --> Model Class Initialized
INFO - 2018-11-20 08:58:21 --> Controller Class Initialized
INFO - 2018-11-20 08:58:21 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-20 08:58:21 --> Model Class Initialized
INFO - 2018-11-20 08:58:21 --> Model Class Initialized
INFO - 2018-11-20 08:58:36 --> Config Class Initialized
INFO - 2018-11-20 08:58:36 --> Hooks Class Initialized
DEBUG - 2018-11-20 08:58:36 --> UTF-8 Support Enabled
INFO - 2018-11-20 08:58:36 --> Utf8 Class Initialized
INFO - 2018-11-20 08:58:36 --> URI Class Initialized
INFO - 2018-11-20 08:58:36 --> Router Class Initialized
INFO - 2018-11-20 08:58:36 --> Output Class Initialized
INFO - 2018-11-20 08:58:36 --> Security Class Initialized
DEBUG - 2018-11-20 08:58:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-20 08:58:36 --> Input Class Initialized
INFO - 2018-11-20 08:58:36 --> Language Class Initialized
INFO - 2018-11-20 08:58:36 --> Loader Class Initialized
INFO - 2018-11-20 08:58:36 --> Helper loaded: url_helper
INFO - 2018-11-20 08:58:36 --> Helper loaded: file_helper
INFO - 2018-11-20 08:58:36 --> Helper loaded: email_helper
INFO - 2018-11-20 08:58:36 --> Helper loaded: common_helper
INFO - 2018-11-20 08:58:36 --> Database Driver Class Initialized
DEBUG - 2018-11-20 08:58:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-20 08:58:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-20 08:58:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-20 08:58:36 --> Pagination Class Initialized
INFO - 2018-11-20 08:58:36 --> Helper loaded: form_helper
INFO - 2018-11-20 08:58:36 --> Form Validation Class Initialized
INFO - 2018-11-20 08:58:36 --> Model Class Initialized
INFO - 2018-11-20 08:58:36 --> Controller Class Initialized
INFO - 2018-11-20 08:58:36 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-20 08:58:36 --> Model Class Initialized
INFO - 2018-11-20 08:58:36 --> Model Class Initialized
INFO - 2018-11-20 08:59:33 --> Config Class Initialized
INFO - 2018-11-20 08:59:33 --> Hooks Class Initialized
DEBUG - 2018-11-20 08:59:33 --> UTF-8 Support Enabled
INFO - 2018-11-20 08:59:33 --> Utf8 Class Initialized
INFO - 2018-11-20 08:59:33 --> URI Class Initialized
INFO - 2018-11-20 08:59:33 --> Router Class Initialized
INFO - 2018-11-20 08:59:33 --> Output Class Initialized
INFO - 2018-11-20 08:59:33 --> Security Class Initialized
DEBUG - 2018-11-20 08:59:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-20 08:59:33 --> Input Class Initialized
INFO - 2018-11-20 08:59:33 --> Language Class Initialized
INFO - 2018-11-20 08:59:33 --> Loader Class Initialized
INFO - 2018-11-20 08:59:33 --> Helper loaded: url_helper
INFO - 2018-11-20 08:59:33 --> Helper loaded: file_helper
INFO - 2018-11-20 08:59:33 --> Helper loaded: email_helper
INFO - 2018-11-20 08:59:33 --> Helper loaded: common_helper
INFO - 2018-11-20 08:59:33 --> Database Driver Class Initialized
DEBUG - 2018-11-20 08:59:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-20 08:59:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-20 08:59:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-20 08:59:33 --> Pagination Class Initialized
INFO - 2018-11-20 08:59:33 --> Helper loaded: form_helper
INFO - 2018-11-20 08:59:33 --> Form Validation Class Initialized
INFO - 2018-11-20 08:59:33 --> Model Class Initialized
INFO - 2018-11-20 08:59:33 --> Controller Class Initialized
INFO - 2018-11-20 08:59:33 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-20 08:59:33 --> Model Class Initialized
INFO - 2018-11-20 08:59:33 --> Model Class Initialized
INFO - 2018-11-20 08:59:33 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/index.php
INFO - 2018-11-20 08:59:33 --> Final output sent to browser
DEBUG - 2018-11-20 08:59:33 --> Total execution time: 0.0650
INFO - 2018-11-20 08:59:35 --> Config Class Initialized
INFO - 2018-11-20 08:59:35 --> Hooks Class Initialized
DEBUG - 2018-11-20 08:59:35 --> UTF-8 Support Enabled
INFO - 2018-11-20 08:59:35 --> Utf8 Class Initialized
INFO - 2018-11-20 08:59:35 --> URI Class Initialized
INFO - 2018-11-20 08:59:35 --> Router Class Initialized
INFO - 2018-11-20 08:59:35 --> Output Class Initialized
INFO - 2018-11-20 08:59:35 --> Security Class Initialized
DEBUG - 2018-11-20 08:59:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-20 08:59:35 --> Input Class Initialized
INFO - 2018-11-20 08:59:35 --> Language Class Initialized
INFO - 2018-11-20 08:59:35 --> Loader Class Initialized
INFO - 2018-11-20 08:59:35 --> Helper loaded: url_helper
INFO - 2018-11-20 08:59:35 --> Helper loaded: file_helper
INFO - 2018-11-20 08:59:35 --> Helper loaded: email_helper
INFO - 2018-11-20 08:59:35 --> Helper loaded: common_helper
INFO - 2018-11-20 08:59:35 --> Database Driver Class Initialized
DEBUG - 2018-11-20 08:59:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-20 08:59:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-20 08:59:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-20 08:59:35 --> Pagination Class Initialized
INFO - 2018-11-20 08:59:35 --> Helper loaded: form_helper
INFO - 2018-11-20 08:59:35 --> Form Validation Class Initialized
INFO - 2018-11-20 08:59:35 --> Model Class Initialized
INFO - 2018-11-20 08:59:35 --> Controller Class Initialized
INFO - 2018-11-20 08:59:35 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-20 08:59:35 --> Model Class Initialized
INFO - 2018-11-20 08:59:35 --> Model Class Initialized
INFO - 2018-11-20 08:59:35 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/index.php
INFO - 2018-11-20 08:59:35 --> Final output sent to browser
DEBUG - 2018-11-20 08:59:35 --> Total execution time: 0.0680
INFO - 2018-11-20 08:59:54 --> Config Class Initialized
INFO - 2018-11-20 08:59:54 --> Hooks Class Initialized
DEBUG - 2018-11-20 08:59:54 --> UTF-8 Support Enabled
INFO - 2018-11-20 08:59:54 --> Utf8 Class Initialized
INFO - 2018-11-20 08:59:54 --> URI Class Initialized
INFO - 2018-11-20 08:59:54 --> Router Class Initialized
INFO - 2018-11-20 08:59:54 --> Output Class Initialized
INFO - 2018-11-20 08:59:54 --> Security Class Initialized
DEBUG - 2018-11-20 08:59:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-20 08:59:54 --> Input Class Initialized
INFO - 2018-11-20 08:59:54 --> Language Class Initialized
INFO - 2018-11-20 08:59:54 --> Loader Class Initialized
INFO - 2018-11-20 08:59:54 --> Helper loaded: url_helper
INFO - 2018-11-20 08:59:54 --> Helper loaded: file_helper
INFO - 2018-11-20 08:59:54 --> Helper loaded: email_helper
INFO - 2018-11-20 08:59:54 --> Helper loaded: common_helper
INFO - 2018-11-20 08:59:54 --> Database Driver Class Initialized
DEBUG - 2018-11-20 08:59:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-20 08:59:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-20 08:59:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-20 08:59:54 --> Pagination Class Initialized
INFO - 2018-11-20 08:59:54 --> Helper loaded: form_helper
INFO - 2018-11-20 08:59:54 --> Form Validation Class Initialized
INFO - 2018-11-20 08:59:54 --> Model Class Initialized
INFO - 2018-11-20 08:59:54 --> Controller Class Initialized
INFO - 2018-11-20 08:59:54 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-20 08:59:54 --> Model Class Initialized
INFO - 2018-11-20 08:59:54 --> Model Class Initialized
INFO - 2018-11-20 08:59:54 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/index.php
INFO - 2018-11-20 08:59:54 --> Final output sent to browser
DEBUG - 2018-11-20 08:59:54 --> Total execution time: 0.0656
INFO - 2018-11-20 08:59:56 --> Config Class Initialized
INFO - 2018-11-20 08:59:56 --> Hooks Class Initialized
DEBUG - 2018-11-20 08:59:56 --> UTF-8 Support Enabled
INFO - 2018-11-20 08:59:56 --> Utf8 Class Initialized
INFO - 2018-11-20 08:59:56 --> URI Class Initialized
INFO - 2018-11-20 08:59:56 --> Router Class Initialized
INFO - 2018-11-20 08:59:56 --> Output Class Initialized
INFO - 2018-11-20 08:59:56 --> Security Class Initialized
DEBUG - 2018-11-20 08:59:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-20 08:59:56 --> Input Class Initialized
INFO - 2018-11-20 08:59:56 --> Language Class Initialized
INFO - 2018-11-20 08:59:56 --> Loader Class Initialized
INFO - 2018-11-20 08:59:56 --> Helper loaded: url_helper
INFO - 2018-11-20 08:59:56 --> Helper loaded: file_helper
INFO - 2018-11-20 08:59:56 --> Helper loaded: email_helper
INFO - 2018-11-20 08:59:56 --> Helper loaded: common_helper
INFO - 2018-11-20 08:59:56 --> Database Driver Class Initialized
DEBUG - 2018-11-20 08:59:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-20 08:59:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-20 08:59:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-20 08:59:56 --> Pagination Class Initialized
INFO - 2018-11-20 08:59:56 --> Helper loaded: form_helper
INFO - 2018-11-20 08:59:56 --> Form Validation Class Initialized
INFO - 2018-11-20 08:59:56 --> Model Class Initialized
INFO - 2018-11-20 08:59:56 --> Controller Class Initialized
INFO - 2018-11-20 08:59:56 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-20 08:59:56 --> Model Class Initialized
INFO - 2018-11-20 08:59:56 --> Model Class Initialized
INFO - 2018-11-20 08:59:56 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/index.php
INFO - 2018-11-20 08:59:56 --> Final output sent to browser
DEBUG - 2018-11-20 08:59:56 --> Total execution time: 0.0630
INFO - 2018-11-20 09:00:10 --> Config Class Initialized
INFO - 2018-11-20 09:00:10 --> Hooks Class Initialized
DEBUG - 2018-11-20 09:00:10 --> UTF-8 Support Enabled
INFO - 2018-11-20 09:00:10 --> Utf8 Class Initialized
INFO - 2018-11-20 09:00:10 --> URI Class Initialized
INFO - 2018-11-20 09:00:10 --> Router Class Initialized
INFO - 2018-11-20 09:00:10 --> Output Class Initialized
INFO - 2018-11-20 09:00:10 --> Security Class Initialized
DEBUG - 2018-11-20 09:00:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-20 09:00:10 --> Input Class Initialized
INFO - 2018-11-20 09:00:10 --> Language Class Initialized
INFO - 2018-11-20 09:00:10 --> Loader Class Initialized
INFO - 2018-11-20 09:00:10 --> Helper loaded: url_helper
INFO - 2018-11-20 09:00:10 --> Helper loaded: file_helper
INFO - 2018-11-20 09:00:10 --> Helper loaded: email_helper
INFO - 2018-11-20 09:00:10 --> Helper loaded: common_helper
INFO - 2018-11-20 09:00:10 --> Database Driver Class Initialized
DEBUG - 2018-11-20 09:00:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-20 09:00:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-20 09:00:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-20 09:00:10 --> Pagination Class Initialized
INFO - 2018-11-20 09:00:10 --> Helper loaded: form_helper
INFO - 2018-11-20 09:00:10 --> Form Validation Class Initialized
INFO - 2018-11-20 09:00:10 --> Model Class Initialized
INFO - 2018-11-20 09:00:10 --> Controller Class Initialized
INFO - 2018-11-20 09:00:10 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-20 09:00:10 --> Model Class Initialized
INFO - 2018-11-20 09:00:10 --> Model Class Initialized
INFO - 2018-11-20 09:00:10 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/index.php
INFO - 2018-11-20 09:00:10 --> Final output sent to browser
DEBUG - 2018-11-20 09:00:10 --> Total execution time: 0.0630
INFO - 2018-11-20 09:08:26 --> Config Class Initialized
INFO - 2018-11-20 09:08:26 --> Hooks Class Initialized
DEBUG - 2018-11-20 09:08:26 --> UTF-8 Support Enabled
INFO - 2018-11-20 09:08:26 --> Utf8 Class Initialized
INFO - 2018-11-20 09:08:26 --> URI Class Initialized
INFO - 2018-11-20 09:08:26 --> Router Class Initialized
INFO - 2018-11-20 09:08:26 --> Output Class Initialized
INFO - 2018-11-20 09:08:26 --> Security Class Initialized
DEBUG - 2018-11-20 09:08:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-20 09:08:26 --> Input Class Initialized
INFO - 2018-11-20 09:08:26 --> Language Class Initialized
INFO - 2018-11-20 09:08:26 --> Loader Class Initialized
INFO - 2018-11-20 09:08:26 --> Helper loaded: url_helper
INFO - 2018-11-20 09:08:26 --> Helper loaded: file_helper
INFO - 2018-11-20 09:08:26 --> Helper loaded: email_helper
INFO - 2018-11-20 09:08:26 --> Helper loaded: common_helper
INFO - 2018-11-20 09:08:26 --> Database Driver Class Initialized
DEBUG - 2018-11-20 09:08:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-20 09:08:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-20 09:08:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-20 09:08:26 --> Pagination Class Initialized
INFO - 2018-11-20 09:08:26 --> Helper loaded: form_helper
INFO - 2018-11-20 09:08:26 --> Form Validation Class Initialized
INFO - 2018-11-20 09:08:26 --> Model Class Initialized
INFO - 2018-11-20 09:08:26 --> Controller Class Initialized
INFO - 2018-11-20 09:08:26 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-20 09:08:26 --> Model Class Initialized
INFO - 2018-11-20 09:08:26 --> Model Class Initialized
INFO - 2018-11-20 09:08:26 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/index.php
INFO - 2018-11-20 09:08:26 --> Final output sent to browser
DEBUG - 2018-11-20 09:08:26 --> Total execution time: 0.0740
INFO - 2018-11-20 09:08:28 --> Config Class Initialized
INFO - 2018-11-20 09:08:28 --> Hooks Class Initialized
DEBUG - 2018-11-20 09:08:28 --> UTF-8 Support Enabled
INFO - 2018-11-20 09:08:28 --> Utf8 Class Initialized
INFO - 2018-11-20 09:08:28 --> URI Class Initialized
INFO - 2018-11-20 09:08:28 --> Router Class Initialized
INFO - 2018-11-20 09:08:28 --> Output Class Initialized
INFO - 2018-11-20 09:08:28 --> Security Class Initialized
DEBUG - 2018-11-20 09:08:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-20 09:08:28 --> Input Class Initialized
INFO - 2018-11-20 09:08:28 --> Language Class Initialized
INFO - 2018-11-20 09:08:28 --> Loader Class Initialized
INFO - 2018-11-20 09:08:28 --> Helper loaded: url_helper
INFO - 2018-11-20 09:08:28 --> Helper loaded: file_helper
INFO - 2018-11-20 09:08:28 --> Helper loaded: email_helper
INFO - 2018-11-20 09:08:28 --> Helper loaded: common_helper
INFO - 2018-11-20 09:08:28 --> Database Driver Class Initialized
DEBUG - 2018-11-20 09:08:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-20 09:08:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-20 09:08:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-20 09:08:28 --> Pagination Class Initialized
INFO - 2018-11-20 09:08:28 --> Helper loaded: form_helper
INFO - 2018-11-20 09:08:28 --> Form Validation Class Initialized
INFO - 2018-11-20 09:08:28 --> Model Class Initialized
INFO - 2018-11-20 09:08:28 --> Controller Class Initialized
INFO - 2018-11-20 09:08:28 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-20 09:08:28 --> Model Class Initialized
INFO - 2018-11-20 09:08:28 --> Model Class Initialized
INFO - 2018-11-20 09:08:28 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/index.php
INFO - 2018-11-20 09:08:28 --> Final output sent to browser
DEBUG - 2018-11-20 09:08:28 --> Total execution time: 0.0490
INFO - 2018-11-20 09:08:34 --> Config Class Initialized
INFO - 2018-11-20 09:08:34 --> Hooks Class Initialized
DEBUG - 2018-11-20 09:08:34 --> UTF-8 Support Enabled
INFO - 2018-11-20 09:08:34 --> Utf8 Class Initialized
INFO - 2018-11-20 09:08:34 --> URI Class Initialized
INFO - 2018-11-20 09:08:34 --> Router Class Initialized
INFO - 2018-11-20 09:08:34 --> Output Class Initialized
INFO - 2018-11-20 09:08:34 --> Security Class Initialized
DEBUG - 2018-11-20 09:08:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-20 09:08:34 --> Input Class Initialized
INFO - 2018-11-20 09:08:34 --> Language Class Initialized
INFO - 2018-11-20 09:08:34 --> Loader Class Initialized
INFO - 2018-11-20 09:08:34 --> Helper loaded: url_helper
INFO - 2018-11-20 09:08:34 --> Helper loaded: file_helper
INFO - 2018-11-20 09:08:34 --> Helper loaded: email_helper
INFO - 2018-11-20 09:08:34 --> Helper loaded: common_helper
INFO - 2018-11-20 09:08:34 --> Database Driver Class Initialized
DEBUG - 2018-11-20 09:08:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-20 09:08:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-20 09:08:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-20 09:08:34 --> Pagination Class Initialized
INFO - 2018-11-20 09:08:34 --> Helper loaded: form_helper
INFO - 2018-11-20 09:08:34 --> Form Validation Class Initialized
INFO - 2018-11-20 09:08:34 --> Model Class Initialized
INFO - 2018-11-20 09:08:34 --> Controller Class Initialized
INFO - 2018-11-20 09:08:34 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-20 09:08:34 --> Model Class Initialized
INFO - 2018-11-20 09:08:34 --> Model Class Initialized
INFO - 2018-11-20 09:08:34 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/index.php
INFO - 2018-11-20 09:08:34 --> Final output sent to browser
DEBUG - 2018-11-20 09:08:34 --> Total execution time: 0.0670
INFO - 2018-11-20 09:11:14 --> Config Class Initialized
INFO - 2018-11-20 09:11:14 --> Hooks Class Initialized
DEBUG - 2018-11-20 09:11:14 --> UTF-8 Support Enabled
INFO - 2018-11-20 09:11:14 --> Utf8 Class Initialized
INFO - 2018-11-20 09:11:14 --> URI Class Initialized
INFO - 2018-11-20 09:11:14 --> Router Class Initialized
INFO - 2018-11-20 09:11:14 --> Output Class Initialized
INFO - 2018-11-20 09:11:14 --> Security Class Initialized
DEBUG - 2018-11-20 09:11:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-20 09:11:14 --> Input Class Initialized
INFO - 2018-11-20 09:11:14 --> Language Class Initialized
INFO - 2018-11-20 09:11:14 --> Loader Class Initialized
INFO - 2018-11-20 09:11:14 --> Helper loaded: url_helper
INFO - 2018-11-20 09:11:14 --> Helper loaded: file_helper
INFO - 2018-11-20 09:11:14 --> Helper loaded: email_helper
INFO - 2018-11-20 09:11:14 --> Helper loaded: common_helper
INFO - 2018-11-20 09:11:14 --> Database Driver Class Initialized
DEBUG - 2018-11-20 09:11:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-20 09:11:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-20 09:11:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-20 09:11:14 --> Pagination Class Initialized
INFO - 2018-11-20 09:11:14 --> Helper loaded: form_helper
INFO - 2018-11-20 09:11:14 --> Form Validation Class Initialized
INFO - 2018-11-20 09:11:14 --> Model Class Initialized
INFO - 2018-11-20 09:11:14 --> Controller Class Initialized
INFO - 2018-11-20 09:11:14 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-20 09:11:14 --> Model Class Initialized
INFO - 2018-11-20 09:11:14 --> Model Class Initialized
INFO - 2018-11-20 09:11:14 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/index.php
INFO - 2018-11-20 09:11:14 --> Final output sent to browser
DEBUG - 2018-11-20 09:11:14 --> Total execution time: 0.0550
INFO - 2018-11-20 09:12:37 --> Config Class Initialized
INFO - 2018-11-20 09:12:37 --> Hooks Class Initialized
DEBUG - 2018-11-20 09:12:37 --> UTF-8 Support Enabled
INFO - 2018-11-20 09:12:37 --> Utf8 Class Initialized
INFO - 2018-11-20 09:12:37 --> URI Class Initialized
INFO - 2018-11-20 09:12:37 --> Router Class Initialized
INFO - 2018-11-20 09:12:37 --> Output Class Initialized
INFO - 2018-11-20 09:12:37 --> Security Class Initialized
DEBUG - 2018-11-20 09:12:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-20 09:12:37 --> Input Class Initialized
INFO - 2018-11-20 09:12:37 --> Language Class Initialized
INFO - 2018-11-20 09:12:37 --> Loader Class Initialized
INFO - 2018-11-20 09:12:37 --> Helper loaded: url_helper
INFO - 2018-11-20 09:12:37 --> Helper loaded: file_helper
INFO - 2018-11-20 09:12:37 --> Helper loaded: email_helper
INFO - 2018-11-20 09:12:37 --> Helper loaded: common_helper
INFO - 2018-11-20 09:12:37 --> Database Driver Class Initialized
DEBUG - 2018-11-20 09:12:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-20 09:12:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-20 09:12:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-20 09:12:37 --> Pagination Class Initialized
INFO - 2018-11-20 09:12:37 --> Helper loaded: form_helper
INFO - 2018-11-20 09:12:37 --> Form Validation Class Initialized
INFO - 2018-11-20 09:12:37 --> Model Class Initialized
INFO - 2018-11-20 09:12:37 --> Controller Class Initialized
INFO - 2018-11-20 09:12:37 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-20 09:12:37 --> Model Class Initialized
INFO - 2018-11-20 09:12:37 --> Model Class Initialized
INFO - 2018-11-20 09:12:37 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/index.php
INFO - 2018-11-20 09:12:37 --> Final output sent to browser
DEBUG - 2018-11-20 09:12:37 --> Total execution time: 0.0570
INFO - 2018-11-20 09:12:43 --> Config Class Initialized
INFO - 2018-11-20 09:12:43 --> Hooks Class Initialized
DEBUG - 2018-11-20 09:12:43 --> UTF-8 Support Enabled
INFO - 2018-11-20 09:12:43 --> Utf8 Class Initialized
INFO - 2018-11-20 09:12:43 --> URI Class Initialized
INFO - 2018-11-20 09:12:43 --> Router Class Initialized
INFO - 2018-11-20 09:12:43 --> Output Class Initialized
INFO - 2018-11-20 09:12:43 --> Security Class Initialized
DEBUG - 2018-11-20 09:12:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-20 09:12:43 --> Input Class Initialized
INFO - 2018-11-20 09:12:43 --> Language Class Initialized
INFO - 2018-11-20 09:12:43 --> Loader Class Initialized
INFO - 2018-11-20 09:12:43 --> Helper loaded: url_helper
INFO - 2018-11-20 09:12:43 --> Helper loaded: file_helper
INFO - 2018-11-20 09:12:43 --> Helper loaded: email_helper
INFO - 2018-11-20 09:12:43 --> Helper loaded: common_helper
INFO - 2018-11-20 09:12:43 --> Database Driver Class Initialized
DEBUG - 2018-11-20 09:12:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-20 09:12:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-20 09:12:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-20 09:12:43 --> Pagination Class Initialized
INFO - 2018-11-20 09:12:43 --> Helper loaded: form_helper
INFO - 2018-11-20 09:12:43 --> Form Validation Class Initialized
INFO - 2018-11-20 09:12:43 --> Model Class Initialized
INFO - 2018-11-20 09:12:43 --> Controller Class Initialized
INFO - 2018-11-20 09:12:43 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-20 09:12:43 --> Model Class Initialized
INFO - 2018-11-20 09:12:43 --> Model Class Initialized
INFO - 2018-11-20 09:12:43 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/index.php
INFO - 2018-11-20 09:12:43 --> Final output sent to browser
DEBUG - 2018-11-20 09:12:43 --> Total execution time: 0.0570
INFO - 2018-11-20 09:12:49 --> Config Class Initialized
INFO - 2018-11-20 09:12:49 --> Hooks Class Initialized
DEBUG - 2018-11-20 09:12:49 --> UTF-8 Support Enabled
INFO - 2018-11-20 09:12:49 --> Utf8 Class Initialized
INFO - 2018-11-20 09:12:49 --> URI Class Initialized
INFO - 2018-11-20 09:12:49 --> Router Class Initialized
INFO - 2018-11-20 09:12:49 --> Output Class Initialized
INFO - 2018-11-20 09:12:49 --> Security Class Initialized
DEBUG - 2018-11-20 09:12:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-20 09:12:49 --> Input Class Initialized
INFO - 2018-11-20 09:12:49 --> Language Class Initialized
INFO - 2018-11-20 09:12:49 --> Loader Class Initialized
INFO - 2018-11-20 09:12:49 --> Helper loaded: url_helper
INFO - 2018-11-20 09:12:49 --> Helper loaded: file_helper
INFO - 2018-11-20 09:12:49 --> Helper loaded: email_helper
INFO - 2018-11-20 09:12:49 --> Helper loaded: common_helper
INFO - 2018-11-20 09:12:49 --> Database Driver Class Initialized
DEBUG - 2018-11-20 09:12:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-20 09:12:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-20 09:12:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-20 09:12:49 --> Pagination Class Initialized
INFO - 2018-11-20 09:12:49 --> Helper loaded: form_helper
INFO - 2018-11-20 09:12:49 --> Form Validation Class Initialized
INFO - 2018-11-20 09:12:49 --> Model Class Initialized
INFO - 2018-11-20 09:12:49 --> Controller Class Initialized
INFO - 2018-11-20 09:12:49 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-20 09:12:49 --> Model Class Initialized
INFO - 2018-11-20 09:12:49 --> Model Class Initialized
INFO - 2018-11-20 09:12:49 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/index.php
INFO - 2018-11-20 09:12:49 --> Final output sent to browser
DEBUG - 2018-11-20 09:12:49 --> Total execution time: 0.0640
INFO - 2018-11-20 09:12:55 --> Config Class Initialized
INFO - 2018-11-20 09:12:55 --> Hooks Class Initialized
DEBUG - 2018-11-20 09:12:55 --> UTF-8 Support Enabled
INFO - 2018-11-20 09:12:55 --> Utf8 Class Initialized
INFO - 2018-11-20 09:12:55 --> URI Class Initialized
INFO - 2018-11-20 09:12:55 --> Router Class Initialized
INFO - 2018-11-20 09:12:55 --> Output Class Initialized
INFO - 2018-11-20 09:12:55 --> Security Class Initialized
DEBUG - 2018-11-20 09:12:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-20 09:12:55 --> Input Class Initialized
INFO - 2018-11-20 09:12:55 --> Language Class Initialized
INFO - 2018-11-20 09:12:55 --> Loader Class Initialized
INFO - 2018-11-20 09:12:55 --> Helper loaded: url_helper
INFO - 2018-11-20 09:12:55 --> Helper loaded: file_helper
INFO - 2018-11-20 09:12:55 --> Helper loaded: email_helper
INFO - 2018-11-20 09:12:55 --> Helper loaded: common_helper
INFO - 2018-11-20 09:12:55 --> Database Driver Class Initialized
DEBUG - 2018-11-20 09:12:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-20 09:12:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-20 09:12:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-20 09:12:55 --> Pagination Class Initialized
INFO - 2018-11-20 09:12:55 --> Helper loaded: form_helper
INFO - 2018-11-20 09:12:55 --> Form Validation Class Initialized
INFO - 2018-11-20 09:12:55 --> Model Class Initialized
INFO - 2018-11-20 09:12:55 --> Controller Class Initialized
INFO - 2018-11-20 09:12:55 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-20 09:12:55 --> Model Class Initialized
INFO - 2018-11-20 09:12:55 --> Model Class Initialized
INFO - 2018-11-20 09:12:55 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/index.php
INFO - 2018-11-20 09:12:55 --> Final output sent to browser
DEBUG - 2018-11-20 09:12:55 --> Total execution time: 0.0920
INFO - 2018-11-20 09:13:07 --> Config Class Initialized
INFO - 2018-11-20 09:13:07 --> Hooks Class Initialized
DEBUG - 2018-11-20 09:13:07 --> UTF-8 Support Enabled
INFO - 2018-11-20 09:13:07 --> Utf8 Class Initialized
INFO - 2018-11-20 09:13:07 --> URI Class Initialized
INFO - 2018-11-20 09:13:07 --> Router Class Initialized
INFO - 2018-11-20 09:13:07 --> Output Class Initialized
INFO - 2018-11-20 09:13:07 --> Security Class Initialized
DEBUG - 2018-11-20 09:13:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-20 09:13:07 --> Input Class Initialized
INFO - 2018-11-20 09:13:07 --> Language Class Initialized
INFO - 2018-11-20 09:13:07 --> Loader Class Initialized
INFO - 2018-11-20 09:13:07 --> Helper loaded: url_helper
INFO - 2018-11-20 09:13:07 --> Helper loaded: file_helper
INFO - 2018-11-20 09:13:07 --> Helper loaded: email_helper
INFO - 2018-11-20 09:13:07 --> Helper loaded: common_helper
INFO - 2018-11-20 09:13:07 --> Database Driver Class Initialized
DEBUG - 2018-11-20 09:13:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-20 09:13:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-20 09:13:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-20 09:13:07 --> Pagination Class Initialized
INFO - 2018-11-20 09:13:07 --> Helper loaded: form_helper
INFO - 2018-11-20 09:13:07 --> Form Validation Class Initialized
INFO - 2018-11-20 09:13:07 --> Model Class Initialized
INFO - 2018-11-20 09:13:07 --> Controller Class Initialized
INFO - 2018-11-20 09:13:07 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-20 09:13:07 --> Model Class Initialized
INFO - 2018-11-20 09:13:07 --> Model Class Initialized
INFO - 2018-11-20 09:13:07 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/index.php
INFO - 2018-11-20 09:13:07 --> Final output sent to browser
DEBUG - 2018-11-20 09:13:07 --> Total execution time: 0.0550
INFO - 2018-11-20 09:13:35 --> Config Class Initialized
INFO - 2018-11-20 09:13:35 --> Hooks Class Initialized
DEBUG - 2018-11-20 09:13:35 --> UTF-8 Support Enabled
INFO - 2018-11-20 09:13:35 --> Utf8 Class Initialized
INFO - 2018-11-20 09:13:35 --> URI Class Initialized
INFO - 2018-11-20 09:13:35 --> Router Class Initialized
INFO - 2018-11-20 09:13:35 --> Output Class Initialized
INFO - 2018-11-20 09:13:35 --> Security Class Initialized
DEBUG - 2018-11-20 09:13:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-20 09:13:35 --> Input Class Initialized
INFO - 2018-11-20 09:13:35 --> Language Class Initialized
INFO - 2018-11-20 09:13:35 --> Loader Class Initialized
INFO - 2018-11-20 09:13:35 --> Helper loaded: url_helper
INFO - 2018-11-20 09:13:35 --> Helper loaded: file_helper
INFO - 2018-11-20 09:13:35 --> Helper loaded: email_helper
INFO - 2018-11-20 09:13:35 --> Helper loaded: common_helper
INFO - 2018-11-20 09:13:35 --> Database Driver Class Initialized
DEBUG - 2018-11-20 09:13:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-20 09:13:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-20 09:13:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-20 09:13:35 --> Pagination Class Initialized
INFO - 2018-11-20 09:13:35 --> Helper loaded: form_helper
INFO - 2018-11-20 09:13:35 --> Form Validation Class Initialized
INFO - 2018-11-20 09:13:35 --> Model Class Initialized
INFO - 2018-11-20 09:13:35 --> Controller Class Initialized
INFO - 2018-11-20 09:13:35 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-20 09:13:35 --> Model Class Initialized
INFO - 2018-11-20 09:13:35 --> Model Class Initialized
INFO - 2018-11-20 09:13:35 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/index.php
INFO - 2018-11-20 09:13:35 --> Final output sent to browser
DEBUG - 2018-11-20 09:13:35 --> Total execution time: 0.0580
INFO - 2018-11-20 09:13:44 --> Config Class Initialized
INFO - 2018-11-20 09:13:44 --> Hooks Class Initialized
DEBUG - 2018-11-20 09:13:44 --> UTF-8 Support Enabled
INFO - 2018-11-20 09:13:44 --> Utf8 Class Initialized
INFO - 2018-11-20 09:13:44 --> URI Class Initialized
INFO - 2018-11-20 09:13:44 --> Router Class Initialized
INFO - 2018-11-20 09:13:44 --> Output Class Initialized
INFO - 2018-11-20 09:13:44 --> Security Class Initialized
DEBUG - 2018-11-20 09:13:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-20 09:13:44 --> Input Class Initialized
INFO - 2018-11-20 09:13:44 --> Language Class Initialized
INFO - 2018-11-20 09:13:44 --> Loader Class Initialized
INFO - 2018-11-20 09:13:44 --> Helper loaded: url_helper
INFO - 2018-11-20 09:13:44 --> Helper loaded: file_helper
INFO - 2018-11-20 09:13:44 --> Helper loaded: email_helper
INFO - 2018-11-20 09:13:44 --> Helper loaded: common_helper
INFO - 2018-11-20 09:13:44 --> Database Driver Class Initialized
DEBUG - 2018-11-20 09:13:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-20 09:13:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-20 09:13:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-20 09:13:44 --> Pagination Class Initialized
INFO - 2018-11-20 09:13:44 --> Helper loaded: form_helper
INFO - 2018-11-20 09:13:44 --> Form Validation Class Initialized
INFO - 2018-11-20 09:13:44 --> Model Class Initialized
INFO - 2018-11-20 09:13:44 --> Controller Class Initialized
INFO - 2018-11-20 09:13:44 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-20 09:13:44 --> Model Class Initialized
INFO - 2018-11-20 09:13:44 --> Model Class Initialized
INFO - 2018-11-20 09:13:44 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/index.php
INFO - 2018-11-20 09:13:44 --> Final output sent to browser
DEBUG - 2018-11-20 09:13:44 --> Total execution time: 0.0560
INFO - 2018-11-20 09:15:14 --> Config Class Initialized
INFO - 2018-11-20 09:15:14 --> Hooks Class Initialized
DEBUG - 2018-11-20 09:15:14 --> UTF-8 Support Enabled
INFO - 2018-11-20 09:15:14 --> Utf8 Class Initialized
INFO - 2018-11-20 09:15:14 --> URI Class Initialized
INFO - 2018-11-20 09:15:14 --> Router Class Initialized
INFO - 2018-11-20 09:15:14 --> Output Class Initialized
INFO - 2018-11-20 09:15:14 --> Security Class Initialized
DEBUG - 2018-11-20 09:15:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-20 09:15:14 --> Input Class Initialized
INFO - 2018-11-20 09:15:14 --> Language Class Initialized
INFO - 2018-11-20 09:15:14 --> Loader Class Initialized
INFO - 2018-11-20 09:15:14 --> Helper loaded: url_helper
INFO - 2018-11-20 09:15:14 --> Helper loaded: file_helper
INFO - 2018-11-20 09:15:14 --> Helper loaded: email_helper
INFO - 2018-11-20 09:15:14 --> Helper loaded: common_helper
INFO - 2018-11-20 09:15:14 --> Database Driver Class Initialized
DEBUG - 2018-11-20 09:15:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-20 09:15:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-20 09:15:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-20 09:15:14 --> Pagination Class Initialized
INFO - 2018-11-20 09:15:14 --> Helper loaded: form_helper
INFO - 2018-11-20 09:15:14 --> Form Validation Class Initialized
INFO - 2018-11-20 09:15:14 --> Model Class Initialized
INFO - 2018-11-20 09:15:14 --> Controller Class Initialized
INFO - 2018-11-20 09:15:14 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-20 09:15:14 --> Model Class Initialized
INFO - 2018-11-20 09:15:14 --> Model Class Initialized
INFO - 2018-11-20 09:15:14 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/index.php
INFO - 2018-11-20 09:15:14 --> Final output sent to browser
DEBUG - 2018-11-20 09:15:14 --> Total execution time: 0.0680
INFO - 2018-11-20 09:21:49 --> Config Class Initialized
INFO - 2018-11-20 09:21:49 --> Hooks Class Initialized
DEBUG - 2018-11-20 09:21:49 --> UTF-8 Support Enabled
INFO - 2018-11-20 09:21:49 --> Utf8 Class Initialized
INFO - 2018-11-20 09:21:49 --> URI Class Initialized
INFO - 2018-11-20 09:21:49 --> Router Class Initialized
INFO - 2018-11-20 09:21:49 --> Output Class Initialized
INFO - 2018-11-20 09:21:49 --> Security Class Initialized
DEBUG - 2018-11-20 09:21:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-20 09:21:49 --> Input Class Initialized
INFO - 2018-11-20 09:21:49 --> Language Class Initialized
INFO - 2018-11-20 09:21:49 --> Loader Class Initialized
INFO - 2018-11-20 09:21:49 --> Helper loaded: url_helper
INFO - 2018-11-20 09:21:49 --> Helper loaded: file_helper
INFO - 2018-11-20 09:21:49 --> Helper loaded: email_helper
INFO - 2018-11-20 09:21:49 --> Helper loaded: common_helper
INFO - 2018-11-20 09:21:49 --> Database Driver Class Initialized
DEBUG - 2018-11-20 09:21:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-20 09:21:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-20 09:21:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-20 09:21:49 --> Pagination Class Initialized
INFO - 2018-11-20 09:21:49 --> Helper loaded: form_helper
INFO - 2018-11-20 09:21:49 --> Form Validation Class Initialized
INFO - 2018-11-20 09:21:49 --> Model Class Initialized
INFO - 2018-11-20 09:21:49 --> Controller Class Initialized
INFO - 2018-11-20 09:21:49 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-20 09:21:49 --> Model Class Initialized
INFO - 2018-11-20 09:21:49 --> Model Class Initialized
INFO - 2018-11-20 09:21:49 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/index.php
INFO - 2018-11-20 09:21:49 --> Final output sent to browser
DEBUG - 2018-11-20 09:21:49 --> Total execution time: 0.0550
INFO - 2018-11-20 09:23:40 --> Config Class Initialized
INFO - 2018-11-20 09:23:40 --> Hooks Class Initialized
DEBUG - 2018-11-20 09:23:40 --> UTF-8 Support Enabled
INFO - 2018-11-20 09:23:40 --> Utf8 Class Initialized
INFO - 2018-11-20 09:23:40 --> URI Class Initialized
INFO - 2018-11-20 09:23:40 --> Router Class Initialized
INFO - 2018-11-20 09:23:40 --> Output Class Initialized
INFO - 2018-11-20 09:23:40 --> Security Class Initialized
DEBUG - 2018-11-20 09:23:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-20 09:23:40 --> Input Class Initialized
INFO - 2018-11-20 09:23:40 --> Language Class Initialized
INFO - 2018-11-20 09:23:40 --> Loader Class Initialized
INFO - 2018-11-20 09:23:40 --> Helper loaded: url_helper
INFO - 2018-11-20 09:23:40 --> Helper loaded: file_helper
INFO - 2018-11-20 09:23:40 --> Helper loaded: email_helper
INFO - 2018-11-20 09:23:40 --> Helper loaded: common_helper
INFO - 2018-11-20 09:23:40 --> Database Driver Class Initialized
DEBUG - 2018-11-20 09:23:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-20 09:23:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-20 09:23:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-20 09:23:40 --> Pagination Class Initialized
INFO - 2018-11-20 09:23:40 --> Helper loaded: form_helper
INFO - 2018-11-20 09:23:40 --> Form Validation Class Initialized
INFO - 2018-11-20 09:23:40 --> Model Class Initialized
INFO - 2018-11-20 09:23:40 --> Controller Class Initialized
INFO - 2018-11-20 09:23:40 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-20 09:23:40 --> Model Class Initialized
INFO - 2018-11-20 09:23:40 --> Model Class Initialized
INFO - 2018-11-20 09:23:40 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/index.php
INFO - 2018-11-20 09:23:40 --> Final output sent to browser
DEBUG - 2018-11-20 09:23:40 --> Total execution time: 0.0716
INFO - 2018-11-20 09:24:00 --> Config Class Initialized
INFO - 2018-11-20 09:24:00 --> Hooks Class Initialized
DEBUG - 2018-11-20 09:24:00 --> UTF-8 Support Enabled
INFO - 2018-11-20 09:24:00 --> Utf8 Class Initialized
INFO - 2018-11-20 09:24:00 --> URI Class Initialized
INFO - 2018-11-20 09:24:00 --> Router Class Initialized
INFO - 2018-11-20 09:24:00 --> Output Class Initialized
INFO - 2018-11-20 09:24:00 --> Security Class Initialized
DEBUG - 2018-11-20 09:24:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-20 09:24:00 --> Input Class Initialized
INFO - 2018-11-20 09:24:00 --> Language Class Initialized
INFO - 2018-11-20 09:24:00 --> Loader Class Initialized
INFO - 2018-11-20 09:24:00 --> Helper loaded: url_helper
INFO - 2018-11-20 09:24:00 --> Helper loaded: file_helper
INFO - 2018-11-20 09:24:00 --> Helper loaded: email_helper
INFO - 2018-11-20 09:24:00 --> Helper loaded: common_helper
INFO - 2018-11-20 09:24:00 --> Database Driver Class Initialized
DEBUG - 2018-11-20 09:24:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-20 09:24:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-20 09:24:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-20 09:24:00 --> Pagination Class Initialized
INFO - 2018-11-20 09:24:00 --> Helper loaded: form_helper
INFO - 2018-11-20 09:24:00 --> Form Validation Class Initialized
INFO - 2018-11-20 09:24:00 --> Model Class Initialized
INFO - 2018-11-20 09:24:00 --> Controller Class Initialized
INFO - 2018-11-20 09:24:00 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-20 09:24:00 --> Model Class Initialized
INFO - 2018-11-20 09:24:00 --> Model Class Initialized
INFO - 2018-11-20 09:24:00 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/index.php
INFO - 2018-11-20 09:24:00 --> Final output sent to browser
DEBUG - 2018-11-20 09:24:00 --> Total execution time: 0.0680
INFO - 2018-11-20 09:24:12 --> Config Class Initialized
INFO - 2018-11-20 09:24:12 --> Hooks Class Initialized
DEBUG - 2018-11-20 09:24:12 --> UTF-8 Support Enabled
INFO - 2018-11-20 09:24:12 --> Utf8 Class Initialized
INFO - 2018-11-20 09:24:12 --> URI Class Initialized
INFO - 2018-11-20 09:24:12 --> Router Class Initialized
INFO - 2018-11-20 09:24:12 --> Output Class Initialized
INFO - 2018-11-20 09:24:12 --> Security Class Initialized
DEBUG - 2018-11-20 09:24:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-20 09:24:12 --> Input Class Initialized
INFO - 2018-11-20 09:24:12 --> Language Class Initialized
INFO - 2018-11-20 09:24:12 --> Loader Class Initialized
INFO - 2018-11-20 09:24:12 --> Helper loaded: url_helper
INFO - 2018-11-20 09:24:12 --> Helper loaded: file_helper
INFO - 2018-11-20 09:24:12 --> Helper loaded: email_helper
INFO - 2018-11-20 09:24:12 --> Helper loaded: common_helper
INFO - 2018-11-20 09:24:12 --> Database Driver Class Initialized
DEBUG - 2018-11-20 09:24:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-20 09:24:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-20 09:24:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-20 09:24:12 --> Pagination Class Initialized
INFO - 2018-11-20 09:24:12 --> Helper loaded: form_helper
INFO - 2018-11-20 09:24:12 --> Form Validation Class Initialized
INFO - 2018-11-20 09:24:12 --> Model Class Initialized
INFO - 2018-11-20 09:24:12 --> Controller Class Initialized
INFO - 2018-11-20 09:24:12 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-20 09:24:12 --> Model Class Initialized
INFO - 2018-11-20 09:24:12 --> Model Class Initialized
INFO - 2018-11-20 09:24:12 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/index.php
INFO - 2018-11-20 09:24:12 --> Final output sent to browser
DEBUG - 2018-11-20 09:24:12 --> Total execution time: 0.0620
INFO - 2018-11-20 09:28:36 --> Config Class Initialized
INFO - 2018-11-20 09:28:36 --> Hooks Class Initialized
DEBUG - 2018-11-20 09:28:36 --> UTF-8 Support Enabled
INFO - 2018-11-20 09:28:36 --> Utf8 Class Initialized
INFO - 2018-11-20 09:28:36 --> URI Class Initialized
INFO - 2018-11-20 09:28:36 --> Router Class Initialized
INFO - 2018-11-20 09:28:36 --> Output Class Initialized
INFO - 2018-11-20 09:28:36 --> Security Class Initialized
DEBUG - 2018-11-20 09:28:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-20 09:28:36 --> Input Class Initialized
INFO - 2018-11-20 09:28:36 --> Language Class Initialized
INFO - 2018-11-20 09:28:36 --> Loader Class Initialized
INFO - 2018-11-20 09:28:36 --> Helper loaded: url_helper
INFO - 2018-11-20 09:28:36 --> Helper loaded: file_helper
INFO - 2018-11-20 09:28:36 --> Helper loaded: email_helper
INFO - 2018-11-20 09:28:36 --> Helper loaded: common_helper
INFO - 2018-11-20 09:28:36 --> Database Driver Class Initialized
DEBUG - 2018-11-20 09:28:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-20 09:28:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-20 09:28:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-20 09:28:36 --> Pagination Class Initialized
INFO - 2018-11-20 09:28:36 --> Helper loaded: form_helper
INFO - 2018-11-20 09:28:36 --> Form Validation Class Initialized
INFO - 2018-11-20 09:28:36 --> Model Class Initialized
INFO - 2018-11-20 09:28:36 --> Controller Class Initialized
INFO - 2018-11-20 09:28:36 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-20 09:28:36 --> Model Class Initialized
INFO - 2018-11-20 09:28:36 --> Model Class Initialized
INFO - 2018-11-20 09:28:36 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/index.php
INFO - 2018-11-20 09:28:36 --> Final output sent to browser
DEBUG - 2018-11-20 09:28:36 --> Total execution time: 0.0750
INFO - 2018-11-20 09:28:47 --> Config Class Initialized
INFO - 2018-11-20 09:28:47 --> Hooks Class Initialized
DEBUG - 2018-11-20 09:28:47 --> UTF-8 Support Enabled
INFO - 2018-11-20 09:28:47 --> Utf8 Class Initialized
INFO - 2018-11-20 09:28:47 --> URI Class Initialized
INFO - 2018-11-20 09:28:47 --> Router Class Initialized
INFO - 2018-11-20 09:28:47 --> Output Class Initialized
INFO - 2018-11-20 09:28:47 --> Security Class Initialized
DEBUG - 2018-11-20 09:28:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-20 09:28:47 --> Input Class Initialized
INFO - 2018-11-20 09:28:47 --> Language Class Initialized
INFO - 2018-11-20 09:28:47 --> Loader Class Initialized
INFO - 2018-11-20 09:28:47 --> Helper loaded: url_helper
INFO - 2018-11-20 09:28:47 --> Helper loaded: file_helper
INFO - 2018-11-20 09:28:47 --> Helper loaded: email_helper
INFO - 2018-11-20 09:28:47 --> Helper loaded: common_helper
INFO - 2018-11-20 09:28:47 --> Database Driver Class Initialized
DEBUG - 2018-11-20 09:28:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-20 09:28:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-20 09:28:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-20 09:28:47 --> Pagination Class Initialized
INFO - 2018-11-20 09:28:47 --> Helper loaded: form_helper
INFO - 2018-11-20 09:28:47 --> Form Validation Class Initialized
INFO - 2018-11-20 09:28:47 --> Model Class Initialized
INFO - 2018-11-20 09:28:47 --> Controller Class Initialized
INFO - 2018-11-20 09:28:47 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-20 09:28:47 --> Model Class Initialized
INFO - 2018-11-20 09:28:47 --> Model Class Initialized
INFO - 2018-11-20 09:28:47 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/index.php
INFO - 2018-11-20 09:28:47 --> Final output sent to browser
DEBUG - 2018-11-20 09:28:47 --> Total execution time: 0.0510
INFO - 2018-11-20 09:28:56 --> Config Class Initialized
INFO - 2018-11-20 09:28:56 --> Hooks Class Initialized
DEBUG - 2018-11-20 09:28:56 --> UTF-8 Support Enabled
INFO - 2018-11-20 09:28:56 --> Utf8 Class Initialized
INFO - 2018-11-20 09:28:56 --> URI Class Initialized
INFO - 2018-11-20 09:28:56 --> Router Class Initialized
INFO - 2018-11-20 09:28:56 --> Output Class Initialized
INFO - 2018-11-20 09:28:56 --> Security Class Initialized
DEBUG - 2018-11-20 09:28:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-20 09:28:56 --> Input Class Initialized
INFO - 2018-11-20 09:28:56 --> Language Class Initialized
INFO - 2018-11-20 09:28:56 --> Loader Class Initialized
INFO - 2018-11-20 09:28:56 --> Helper loaded: url_helper
INFO - 2018-11-20 09:28:56 --> Helper loaded: file_helper
INFO - 2018-11-20 09:28:56 --> Helper loaded: email_helper
INFO - 2018-11-20 09:28:56 --> Helper loaded: common_helper
INFO - 2018-11-20 09:28:56 --> Database Driver Class Initialized
DEBUG - 2018-11-20 09:28:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-20 09:28:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-20 09:28:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-20 09:28:56 --> Pagination Class Initialized
INFO - 2018-11-20 09:28:56 --> Helper loaded: form_helper
INFO - 2018-11-20 09:28:56 --> Form Validation Class Initialized
INFO - 2018-11-20 09:28:56 --> Model Class Initialized
INFO - 2018-11-20 09:28:56 --> Controller Class Initialized
INFO - 2018-11-20 09:28:56 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-20 09:28:56 --> Model Class Initialized
INFO - 2018-11-20 09:28:56 --> Model Class Initialized
INFO - 2018-11-20 09:28:56 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/index.php
INFO - 2018-11-20 09:28:56 --> Final output sent to browser
DEBUG - 2018-11-20 09:28:56 --> Total execution time: 0.0506
INFO - 2018-11-20 09:29:03 --> Config Class Initialized
INFO - 2018-11-20 09:29:03 --> Hooks Class Initialized
DEBUG - 2018-11-20 09:29:03 --> UTF-8 Support Enabled
INFO - 2018-11-20 09:29:03 --> Utf8 Class Initialized
INFO - 2018-11-20 09:29:03 --> URI Class Initialized
INFO - 2018-11-20 09:29:03 --> Router Class Initialized
INFO - 2018-11-20 09:29:03 --> Output Class Initialized
INFO - 2018-11-20 09:29:03 --> Security Class Initialized
DEBUG - 2018-11-20 09:29:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-20 09:29:03 --> Input Class Initialized
INFO - 2018-11-20 09:29:03 --> Language Class Initialized
INFO - 2018-11-20 09:29:03 --> Loader Class Initialized
INFO - 2018-11-20 09:29:03 --> Helper loaded: url_helper
INFO - 2018-11-20 09:29:03 --> Helper loaded: file_helper
INFO - 2018-11-20 09:29:03 --> Helper loaded: email_helper
INFO - 2018-11-20 09:29:03 --> Helper loaded: common_helper
INFO - 2018-11-20 09:29:03 --> Database Driver Class Initialized
DEBUG - 2018-11-20 09:29:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-20 09:29:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-20 09:29:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-20 09:29:03 --> Pagination Class Initialized
INFO - 2018-11-20 09:29:03 --> Helper loaded: form_helper
INFO - 2018-11-20 09:29:03 --> Form Validation Class Initialized
INFO - 2018-11-20 09:29:03 --> Model Class Initialized
INFO - 2018-11-20 09:29:03 --> Controller Class Initialized
INFO - 2018-11-20 09:29:03 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-20 09:29:03 --> Model Class Initialized
INFO - 2018-11-20 09:29:03 --> Model Class Initialized
INFO - 2018-11-20 09:29:03 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/index.php
INFO - 2018-11-20 09:29:03 --> Final output sent to browser
DEBUG - 2018-11-20 09:29:03 --> Total execution time: 0.0580
INFO - 2018-11-20 09:29:33 --> Config Class Initialized
INFO - 2018-11-20 09:29:33 --> Hooks Class Initialized
DEBUG - 2018-11-20 09:29:33 --> UTF-8 Support Enabled
INFO - 2018-11-20 09:29:33 --> Utf8 Class Initialized
INFO - 2018-11-20 09:29:33 --> URI Class Initialized
INFO - 2018-11-20 09:29:33 --> Router Class Initialized
INFO - 2018-11-20 09:29:33 --> Output Class Initialized
INFO - 2018-11-20 09:29:33 --> Security Class Initialized
DEBUG - 2018-11-20 09:29:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-20 09:29:33 --> Input Class Initialized
INFO - 2018-11-20 09:29:33 --> Language Class Initialized
INFO - 2018-11-20 09:29:33 --> Loader Class Initialized
INFO - 2018-11-20 09:29:33 --> Helper loaded: url_helper
INFO - 2018-11-20 09:29:33 --> Helper loaded: file_helper
INFO - 2018-11-20 09:29:33 --> Helper loaded: email_helper
INFO - 2018-11-20 09:29:33 --> Helper loaded: common_helper
INFO - 2018-11-20 09:29:33 --> Database Driver Class Initialized
DEBUG - 2018-11-20 09:29:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-20 09:29:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-20 09:29:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-20 09:29:33 --> Pagination Class Initialized
INFO - 2018-11-20 09:29:33 --> Helper loaded: form_helper
INFO - 2018-11-20 09:29:33 --> Form Validation Class Initialized
INFO - 2018-11-20 09:29:33 --> Model Class Initialized
INFO - 2018-11-20 09:29:33 --> Controller Class Initialized
INFO - 2018-11-20 09:29:33 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-20 09:29:33 --> Model Class Initialized
INFO - 2018-11-20 09:29:33 --> Model Class Initialized
INFO - 2018-11-20 09:29:33 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/index.php
INFO - 2018-11-20 09:29:33 --> Final output sent to browser
DEBUG - 2018-11-20 09:29:33 --> Total execution time: 0.0640
INFO - 2018-11-20 09:29:41 --> Config Class Initialized
INFO - 2018-11-20 09:29:41 --> Hooks Class Initialized
DEBUG - 2018-11-20 09:29:41 --> UTF-8 Support Enabled
INFO - 2018-11-20 09:29:41 --> Utf8 Class Initialized
INFO - 2018-11-20 09:29:41 --> URI Class Initialized
INFO - 2018-11-20 09:29:41 --> Router Class Initialized
INFO - 2018-11-20 09:29:41 --> Output Class Initialized
INFO - 2018-11-20 09:29:41 --> Security Class Initialized
DEBUG - 2018-11-20 09:29:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-20 09:29:41 --> Input Class Initialized
INFO - 2018-11-20 09:29:41 --> Language Class Initialized
INFO - 2018-11-20 09:29:41 --> Loader Class Initialized
INFO - 2018-11-20 09:29:41 --> Helper loaded: url_helper
INFO - 2018-11-20 09:29:41 --> Helper loaded: file_helper
INFO - 2018-11-20 09:29:41 --> Helper loaded: email_helper
INFO - 2018-11-20 09:29:41 --> Helper loaded: common_helper
INFO - 2018-11-20 09:29:41 --> Database Driver Class Initialized
DEBUG - 2018-11-20 09:29:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-20 09:29:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-20 09:29:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-20 09:29:41 --> Pagination Class Initialized
INFO - 2018-11-20 09:29:41 --> Helper loaded: form_helper
INFO - 2018-11-20 09:29:41 --> Form Validation Class Initialized
INFO - 2018-11-20 09:29:41 --> Model Class Initialized
INFO - 2018-11-20 09:29:41 --> Controller Class Initialized
INFO - 2018-11-20 09:29:41 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-20 09:29:41 --> Model Class Initialized
INFO - 2018-11-20 09:29:41 --> Model Class Initialized
INFO - 2018-11-20 09:29:41 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/index.php
INFO - 2018-11-20 09:29:41 --> Final output sent to browser
DEBUG - 2018-11-20 09:29:41 --> Total execution time: 0.0580
INFO - 2018-11-20 09:29:53 --> Config Class Initialized
INFO - 2018-11-20 09:29:53 --> Hooks Class Initialized
DEBUG - 2018-11-20 09:29:53 --> UTF-8 Support Enabled
INFO - 2018-11-20 09:29:53 --> Utf8 Class Initialized
INFO - 2018-11-20 09:29:53 --> URI Class Initialized
INFO - 2018-11-20 09:29:53 --> Router Class Initialized
INFO - 2018-11-20 09:29:53 --> Output Class Initialized
INFO - 2018-11-20 09:29:53 --> Security Class Initialized
DEBUG - 2018-11-20 09:29:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-20 09:29:53 --> Input Class Initialized
INFO - 2018-11-20 09:29:53 --> Language Class Initialized
INFO - 2018-11-20 09:29:53 --> Loader Class Initialized
INFO - 2018-11-20 09:29:53 --> Helper loaded: url_helper
INFO - 2018-11-20 09:29:53 --> Helper loaded: file_helper
INFO - 2018-11-20 09:29:53 --> Helper loaded: email_helper
INFO - 2018-11-20 09:29:53 --> Helper loaded: common_helper
INFO - 2018-11-20 09:29:53 --> Database Driver Class Initialized
DEBUG - 2018-11-20 09:29:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-20 09:29:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-20 09:29:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-20 09:29:53 --> Pagination Class Initialized
INFO - 2018-11-20 09:29:53 --> Helper loaded: form_helper
INFO - 2018-11-20 09:29:53 --> Form Validation Class Initialized
INFO - 2018-11-20 09:29:53 --> Model Class Initialized
INFO - 2018-11-20 09:29:53 --> Controller Class Initialized
INFO - 2018-11-20 09:29:53 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-20 09:29:53 --> Model Class Initialized
INFO - 2018-11-20 09:29:53 --> Model Class Initialized
INFO - 2018-11-20 09:29:53 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/index.php
INFO - 2018-11-20 09:29:53 --> Final output sent to browser
DEBUG - 2018-11-20 09:29:53 --> Total execution time: 0.0630
INFO - 2018-11-20 09:31:40 --> Config Class Initialized
INFO - 2018-11-20 09:31:40 --> Hooks Class Initialized
DEBUG - 2018-11-20 09:31:40 --> UTF-8 Support Enabled
INFO - 2018-11-20 09:31:40 --> Utf8 Class Initialized
INFO - 2018-11-20 09:31:40 --> URI Class Initialized
INFO - 2018-11-20 09:31:40 --> Router Class Initialized
INFO - 2018-11-20 09:31:40 --> Output Class Initialized
INFO - 2018-11-20 09:31:40 --> Security Class Initialized
DEBUG - 2018-11-20 09:31:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-20 09:31:40 --> Input Class Initialized
INFO - 2018-11-20 09:31:40 --> Language Class Initialized
INFO - 2018-11-20 09:31:40 --> Loader Class Initialized
INFO - 2018-11-20 09:31:40 --> Helper loaded: url_helper
INFO - 2018-11-20 09:31:40 --> Helper loaded: file_helper
INFO - 2018-11-20 09:31:40 --> Helper loaded: email_helper
INFO - 2018-11-20 09:31:40 --> Helper loaded: common_helper
INFO - 2018-11-20 09:31:40 --> Database Driver Class Initialized
DEBUG - 2018-11-20 09:31:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-20 09:31:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-20 09:31:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-20 09:31:40 --> Pagination Class Initialized
INFO - 2018-11-20 09:31:40 --> Helper loaded: form_helper
INFO - 2018-11-20 09:31:40 --> Form Validation Class Initialized
INFO - 2018-11-20 09:31:40 --> Model Class Initialized
INFO - 2018-11-20 09:31:40 --> Controller Class Initialized
INFO - 2018-11-20 09:31:40 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-20 09:31:40 --> Model Class Initialized
INFO - 2018-11-20 09:31:40 --> Model Class Initialized
INFO - 2018-11-20 09:31:40 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/index.php
INFO - 2018-11-20 09:31:40 --> Final output sent to browser
DEBUG - 2018-11-20 09:31:40 --> Total execution time: 0.0676
INFO - 2018-11-20 09:31:54 --> Config Class Initialized
INFO - 2018-11-20 09:31:54 --> Hooks Class Initialized
DEBUG - 2018-11-20 09:31:54 --> UTF-8 Support Enabled
INFO - 2018-11-20 09:31:54 --> Utf8 Class Initialized
INFO - 2018-11-20 09:31:54 --> URI Class Initialized
INFO - 2018-11-20 09:31:54 --> Router Class Initialized
INFO - 2018-11-20 09:31:54 --> Output Class Initialized
INFO - 2018-11-20 09:31:54 --> Security Class Initialized
DEBUG - 2018-11-20 09:31:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-20 09:31:54 --> Input Class Initialized
INFO - 2018-11-20 09:31:54 --> Language Class Initialized
INFO - 2018-11-20 09:31:54 --> Loader Class Initialized
INFO - 2018-11-20 09:31:54 --> Helper loaded: url_helper
INFO - 2018-11-20 09:31:54 --> Helper loaded: file_helper
INFO - 2018-11-20 09:31:54 --> Helper loaded: email_helper
INFO - 2018-11-20 09:31:54 --> Helper loaded: common_helper
INFO - 2018-11-20 09:31:54 --> Database Driver Class Initialized
DEBUG - 2018-11-20 09:31:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-20 09:31:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-20 09:31:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-20 09:31:54 --> Pagination Class Initialized
INFO - 2018-11-20 09:31:54 --> Helper loaded: form_helper
INFO - 2018-11-20 09:31:54 --> Form Validation Class Initialized
INFO - 2018-11-20 09:31:54 --> Model Class Initialized
INFO - 2018-11-20 09:31:54 --> Controller Class Initialized
INFO - 2018-11-20 09:31:54 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-20 09:31:54 --> Model Class Initialized
INFO - 2018-11-20 09:31:54 --> Model Class Initialized
INFO - 2018-11-20 09:31:54 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/index.php
INFO - 2018-11-20 09:31:54 --> Final output sent to browser
DEBUG - 2018-11-20 09:31:54 --> Total execution time: 0.0762
INFO - 2018-11-20 09:32:04 --> Config Class Initialized
INFO - 2018-11-20 09:32:04 --> Hooks Class Initialized
DEBUG - 2018-11-20 09:32:04 --> UTF-8 Support Enabled
INFO - 2018-11-20 09:32:04 --> Utf8 Class Initialized
INFO - 2018-11-20 09:32:04 --> URI Class Initialized
INFO - 2018-11-20 09:32:04 --> Router Class Initialized
INFO - 2018-11-20 09:32:04 --> Output Class Initialized
INFO - 2018-11-20 09:32:04 --> Security Class Initialized
DEBUG - 2018-11-20 09:32:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-20 09:32:04 --> Input Class Initialized
INFO - 2018-11-20 09:32:04 --> Language Class Initialized
INFO - 2018-11-20 09:32:04 --> Loader Class Initialized
INFO - 2018-11-20 09:32:04 --> Helper loaded: url_helper
INFO - 2018-11-20 09:32:04 --> Helper loaded: file_helper
INFO - 2018-11-20 09:32:04 --> Helper loaded: email_helper
INFO - 2018-11-20 09:32:04 --> Helper loaded: common_helper
INFO - 2018-11-20 09:32:04 --> Database Driver Class Initialized
DEBUG - 2018-11-20 09:32:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-20 09:32:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-20 09:32:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-20 09:32:04 --> Pagination Class Initialized
INFO - 2018-11-20 09:32:04 --> Helper loaded: form_helper
INFO - 2018-11-20 09:32:04 --> Form Validation Class Initialized
INFO - 2018-11-20 09:32:04 --> Model Class Initialized
INFO - 2018-11-20 09:32:04 --> Controller Class Initialized
INFO - 2018-11-20 09:32:04 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-20 09:32:04 --> Model Class Initialized
INFO - 2018-11-20 09:32:04 --> Model Class Initialized
INFO - 2018-11-20 09:32:04 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/index.php
INFO - 2018-11-20 09:32:04 --> Final output sent to browser
DEBUG - 2018-11-20 09:32:04 --> Total execution time: 0.0740
INFO - 2018-11-20 09:32:19 --> Config Class Initialized
INFO - 2018-11-20 09:32:19 --> Hooks Class Initialized
DEBUG - 2018-11-20 09:32:19 --> UTF-8 Support Enabled
INFO - 2018-11-20 09:32:19 --> Utf8 Class Initialized
INFO - 2018-11-20 09:32:19 --> URI Class Initialized
INFO - 2018-11-20 09:32:19 --> Router Class Initialized
INFO - 2018-11-20 09:32:19 --> Output Class Initialized
INFO - 2018-11-20 09:32:19 --> Security Class Initialized
DEBUG - 2018-11-20 09:32:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-20 09:32:19 --> Input Class Initialized
INFO - 2018-11-20 09:32:19 --> Language Class Initialized
INFO - 2018-11-20 09:32:19 --> Loader Class Initialized
INFO - 2018-11-20 09:32:19 --> Helper loaded: url_helper
INFO - 2018-11-20 09:32:19 --> Helper loaded: file_helper
INFO - 2018-11-20 09:32:19 --> Helper loaded: email_helper
INFO - 2018-11-20 09:32:19 --> Helper loaded: common_helper
INFO - 2018-11-20 09:32:19 --> Database Driver Class Initialized
DEBUG - 2018-11-20 09:32:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-20 09:32:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-20 09:32:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-20 09:32:19 --> Pagination Class Initialized
INFO - 2018-11-20 09:32:19 --> Helper loaded: form_helper
INFO - 2018-11-20 09:32:19 --> Form Validation Class Initialized
INFO - 2018-11-20 09:32:19 --> Model Class Initialized
INFO - 2018-11-20 09:32:19 --> Controller Class Initialized
INFO - 2018-11-20 09:32:19 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-20 09:32:19 --> Model Class Initialized
INFO - 2018-11-20 09:32:19 --> Model Class Initialized
INFO - 2018-11-20 09:32:19 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/index.php
INFO - 2018-11-20 09:32:19 --> Final output sent to browser
DEBUG - 2018-11-20 09:32:19 --> Total execution time: 0.0570
INFO - 2018-11-20 09:33:07 --> Config Class Initialized
INFO - 2018-11-20 09:33:07 --> Hooks Class Initialized
DEBUG - 2018-11-20 09:33:07 --> UTF-8 Support Enabled
INFO - 2018-11-20 09:33:07 --> Utf8 Class Initialized
INFO - 2018-11-20 09:33:07 --> URI Class Initialized
INFO - 2018-11-20 09:33:07 --> Router Class Initialized
INFO - 2018-11-20 09:33:07 --> Output Class Initialized
INFO - 2018-11-20 09:33:07 --> Security Class Initialized
DEBUG - 2018-11-20 09:33:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-20 09:33:07 --> Input Class Initialized
INFO - 2018-11-20 09:33:07 --> Language Class Initialized
INFO - 2018-11-20 09:33:07 --> Loader Class Initialized
INFO - 2018-11-20 09:33:07 --> Helper loaded: url_helper
INFO - 2018-11-20 09:33:07 --> Helper loaded: file_helper
INFO - 2018-11-20 09:33:07 --> Helper loaded: email_helper
INFO - 2018-11-20 09:33:07 --> Helper loaded: common_helper
INFO - 2018-11-20 09:33:07 --> Database Driver Class Initialized
DEBUG - 2018-11-20 09:33:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-20 09:33:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-20 09:33:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-20 09:33:07 --> Pagination Class Initialized
INFO - 2018-11-20 09:33:07 --> Helper loaded: form_helper
INFO - 2018-11-20 09:33:07 --> Form Validation Class Initialized
INFO - 2018-11-20 09:33:07 --> Model Class Initialized
INFO - 2018-11-20 09:33:07 --> Controller Class Initialized
INFO - 2018-11-20 09:33:07 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-20 09:33:07 --> Model Class Initialized
INFO - 2018-11-20 09:33:07 --> Model Class Initialized
INFO - 2018-11-20 09:33:07 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/index.php
INFO - 2018-11-20 09:33:07 --> Final output sent to browser
DEBUG - 2018-11-20 09:33:07 --> Total execution time: 0.0670
INFO - 2018-11-20 09:33:30 --> Config Class Initialized
INFO - 2018-11-20 09:33:30 --> Hooks Class Initialized
DEBUG - 2018-11-20 09:33:30 --> UTF-8 Support Enabled
INFO - 2018-11-20 09:33:30 --> Utf8 Class Initialized
INFO - 2018-11-20 09:33:30 --> URI Class Initialized
INFO - 2018-11-20 09:33:30 --> Router Class Initialized
INFO - 2018-11-20 09:33:30 --> Output Class Initialized
INFO - 2018-11-20 09:33:30 --> Security Class Initialized
DEBUG - 2018-11-20 09:33:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-20 09:33:30 --> Input Class Initialized
INFO - 2018-11-20 09:33:30 --> Language Class Initialized
INFO - 2018-11-20 09:33:30 --> Loader Class Initialized
INFO - 2018-11-20 09:33:30 --> Helper loaded: url_helper
INFO - 2018-11-20 09:33:30 --> Helper loaded: file_helper
INFO - 2018-11-20 09:33:30 --> Helper loaded: email_helper
INFO - 2018-11-20 09:33:30 --> Helper loaded: common_helper
INFO - 2018-11-20 09:33:30 --> Database Driver Class Initialized
DEBUG - 2018-11-20 09:33:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-20 09:33:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-20 09:33:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-20 09:33:30 --> Pagination Class Initialized
INFO - 2018-11-20 09:33:30 --> Helper loaded: form_helper
INFO - 2018-11-20 09:33:30 --> Form Validation Class Initialized
INFO - 2018-11-20 09:33:30 --> Model Class Initialized
INFO - 2018-11-20 09:33:30 --> Controller Class Initialized
INFO - 2018-11-20 09:33:30 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-20 09:33:30 --> Model Class Initialized
INFO - 2018-11-20 09:33:30 --> Model Class Initialized
INFO - 2018-11-20 09:33:30 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/index.php
INFO - 2018-11-20 09:33:30 --> Final output sent to browser
DEBUG - 2018-11-20 09:33:30 --> Total execution time: 0.0530
INFO - 2018-11-20 09:33:58 --> Config Class Initialized
INFO - 2018-11-20 09:33:58 --> Hooks Class Initialized
DEBUG - 2018-11-20 09:33:58 --> UTF-8 Support Enabled
INFO - 2018-11-20 09:33:58 --> Utf8 Class Initialized
INFO - 2018-11-20 09:33:58 --> URI Class Initialized
INFO - 2018-11-20 09:33:58 --> Router Class Initialized
INFO - 2018-11-20 09:33:58 --> Output Class Initialized
INFO - 2018-11-20 09:33:58 --> Security Class Initialized
DEBUG - 2018-11-20 09:33:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-20 09:33:58 --> Input Class Initialized
INFO - 2018-11-20 09:33:58 --> Language Class Initialized
INFO - 2018-11-20 09:33:58 --> Loader Class Initialized
INFO - 2018-11-20 09:33:58 --> Helper loaded: url_helper
INFO - 2018-11-20 09:33:58 --> Helper loaded: file_helper
INFO - 2018-11-20 09:33:58 --> Helper loaded: email_helper
INFO - 2018-11-20 09:33:58 --> Helper loaded: common_helper
INFO - 2018-11-20 09:33:58 --> Database Driver Class Initialized
DEBUG - 2018-11-20 09:33:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-20 09:33:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-20 09:33:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-20 09:33:58 --> Pagination Class Initialized
INFO - 2018-11-20 09:33:58 --> Helper loaded: form_helper
INFO - 2018-11-20 09:33:58 --> Form Validation Class Initialized
INFO - 2018-11-20 09:33:58 --> Model Class Initialized
INFO - 2018-11-20 09:33:58 --> Controller Class Initialized
INFO - 2018-11-20 09:33:58 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-20 09:33:58 --> Model Class Initialized
INFO - 2018-11-20 09:33:58 --> Model Class Initialized
INFO - 2018-11-20 09:33:58 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/index.php
INFO - 2018-11-20 09:33:58 --> Final output sent to browser
DEBUG - 2018-11-20 09:33:58 --> Total execution time: 0.0570
INFO - 2018-11-20 09:35:18 --> Config Class Initialized
INFO - 2018-11-20 09:35:18 --> Hooks Class Initialized
DEBUG - 2018-11-20 09:35:18 --> UTF-8 Support Enabled
INFO - 2018-11-20 09:35:18 --> Utf8 Class Initialized
INFO - 2018-11-20 09:35:18 --> URI Class Initialized
INFO - 2018-11-20 09:35:18 --> Router Class Initialized
INFO - 2018-11-20 09:35:18 --> Output Class Initialized
INFO - 2018-11-20 09:35:18 --> Security Class Initialized
DEBUG - 2018-11-20 09:35:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-20 09:35:18 --> Input Class Initialized
INFO - 2018-11-20 09:35:18 --> Language Class Initialized
INFO - 2018-11-20 09:35:18 --> Loader Class Initialized
INFO - 2018-11-20 09:35:18 --> Helper loaded: url_helper
INFO - 2018-11-20 09:35:18 --> Helper loaded: file_helper
INFO - 2018-11-20 09:35:18 --> Helper loaded: email_helper
INFO - 2018-11-20 09:35:18 --> Helper loaded: common_helper
INFO - 2018-11-20 09:35:18 --> Database Driver Class Initialized
DEBUG - 2018-11-20 09:35:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-20 09:35:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-20 09:35:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-20 09:35:18 --> Pagination Class Initialized
INFO - 2018-11-20 09:35:18 --> Helper loaded: form_helper
INFO - 2018-11-20 09:35:18 --> Form Validation Class Initialized
INFO - 2018-11-20 09:35:18 --> Model Class Initialized
INFO - 2018-11-20 09:35:18 --> Controller Class Initialized
INFO - 2018-11-20 09:35:18 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-20 09:35:18 --> Model Class Initialized
INFO - 2018-11-20 09:35:18 --> Model Class Initialized
INFO - 2018-11-20 09:35:18 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/index.php
INFO - 2018-11-20 09:35:18 --> Final output sent to browser
DEBUG - 2018-11-20 09:35:18 --> Total execution time: 0.0630
INFO - 2018-11-20 09:35:37 --> Config Class Initialized
INFO - 2018-11-20 09:35:37 --> Hooks Class Initialized
DEBUG - 2018-11-20 09:35:37 --> UTF-8 Support Enabled
INFO - 2018-11-20 09:35:37 --> Utf8 Class Initialized
INFO - 2018-11-20 09:35:37 --> URI Class Initialized
INFO - 2018-11-20 09:35:37 --> Router Class Initialized
INFO - 2018-11-20 09:35:37 --> Output Class Initialized
INFO - 2018-11-20 09:35:37 --> Security Class Initialized
DEBUG - 2018-11-20 09:35:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-20 09:35:37 --> Input Class Initialized
INFO - 2018-11-20 09:35:37 --> Language Class Initialized
INFO - 2018-11-20 09:35:37 --> Loader Class Initialized
INFO - 2018-11-20 09:35:37 --> Helper loaded: url_helper
INFO - 2018-11-20 09:35:37 --> Helper loaded: file_helper
INFO - 2018-11-20 09:35:37 --> Helper loaded: email_helper
INFO - 2018-11-20 09:35:37 --> Helper loaded: common_helper
INFO - 2018-11-20 09:35:37 --> Database Driver Class Initialized
DEBUG - 2018-11-20 09:35:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-20 09:35:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-20 09:35:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-20 09:35:37 --> Pagination Class Initialized
INFO - 2018-11-20 09:35:37 --> Helper loaded: form_helper
INFO - 2018-11-20 09:35:37 --> Form Validation Class Initialized
INFO - 2018-11-20 09:35:37 --> Model Class Initialized
INFO - 2018-11-20 09:35:37 --> Controller Class Initialized
INFO - 2018-11-20 09:35:37 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-20 09:35:37 --> Model Class Initialized
INFO - 2018-11-20 09:35:37 --> Model Class Initialized
INFO - 2018-11-20 09:35:37 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/index.php
INFO - 2018-11-20 09:35:37 --> Final output sent to browser
DEBUG - 2018-11-20 09:35:37 --> Total execution time: 0.0600
INFO - 2018-11-20 09:36:39 --> Config Class Initialized
INFO - 2018-11-20 09:36:39 --> Hooks Class Initialized
DEBUG - 2018-11-20 09:36:39 --> UTF-8 Support Enabled
INFO - 2018-11-20 09:36:39 --> Utf8 Class Initialized
INFO - 2018-11-20 09:36:39 --> URI Class Initialized
INFO - 2018-11-20 09:36:39 --> Router Class Initialized
INFO - 2018-11-20 09:36:39 --> Output Class Initialized
INFO - 2018-11-20 09:36:39 --> Security Class Initialized
DEBUG - 2018-11-20 09:36:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-20 09:36:39 --> Input Class Initialized
INFO - 2018-11-20 09:36:39 --> Language Class Initialized
INFO - 2018-11-20 09:36:39 --> Loader Class Initialized
INFO - 2018-11-20 09:36:39 --> Helper loaded: url_helper
INFO - 2018-11-20 09:36:39 --> Helper loaded: file_helper
INFO - 2018-11-20 09:36:39 --> Helper loaded: email_helper
INFO - 2018-11-20 09:36:39 --> Helper loaded: common_helper
INFO - 2018-11-20 09:36:39 --> Database Driver Class Initialized
DEBUG - 2018-11-20 09:36:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-20 09:36:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-20 09:36:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-20 09:36:39 --> Pagination Class Initialized
INFO - 2018-11-20 09:36:39 --> Helper loaded: form_helper
INFO - 2018-11-20 09:36:39 --> Form Validation Class Initialized
INFO - 2018-11-20 09:36:39 --> Model Class Initialized
INFO - 2018-11-20 09:36:39 --> Controller Class Initialized
INFO - 2018-11-20 09:36:39 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-20 09:36:39 --> Model Class Initialized
INFO - 2018-11-20 09:36:39 --> Model Class Initialized
INFO - 2018-11-20 09:36:39 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/index.php
INFO - 2018-11-20 09:36:39 --> Final output sent to browser
DEBUG - 2018-11-20 09:36:39 --> Total execution time: 0.0520
INFO - 2018-11-20 09:38:01 --> Config Class Initialized
INFO - 2018-11-20 09:38:01 --> Hooks Class Initialized
DEBUG - 2018-11-20 09:38:01 --> UTF-8 Support Enabled
INFO - 2018-11-20 09:38:01 --> Utf8 Class Initialized
INFO - 2018-11-20 09:38:01 --> URI Class Initialized
INFO - 2018-11-20 09:38:01 --> Router Class Initialized
INFO - 2018-11-20 09:38:01 --> Output Class Initialized
INFO - 2018-11-20 09:38:01 --> Security Class Initialized
DEBUG - 2018-11-20 09:38:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-20 09:38:01 --> Input Class Initialized
INFO - 2018-11-20 09:38:01 --> Language Class Initialized
INFO - 2018-11-20 09:38:01 --> Loader Class Initialized
INFO - 2018-11-20 09:38:01 --> Helper loaded: url_helper
INFO - 2018-11-20 09:38:01 --> Helper loaded: file_helper
INFO - 2018-11-20 09:38:01 --> Helper loaded: email_helper
INFO - 2018-11-20 09:38:01 --> Helper loaded: common_helper
INFO - 2018-11-20 09:38:01 --> Database Driver Class Initialized
DEBUG - 2018-11-20 09:38:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-20 09:38:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-20 09:38:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-20 09:38:01 --> Pagination Class Initialized
INFO - 2018-11-20 09:38:01 --> Helper loaded: form_helper
INFO - 2018-11-20 09:38:01 --> Form Validation Class Initialized
INFO - 2018-11-20 09:38:01 --> Model Class Initialized
INFO - 2018-11-20 09:38:01 --> Controller Class Initialized
INFO - 2018-11-20 09:38:01 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-20 09:38:01 --> Model Class Initialized
INFO - 2018-11-20 09:38:01 --> Model Class Initialized
INFO - 2018-11-20 09:38:01 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/index.php
INFO - 2018-11-20 09:38:01 --> Final output sent to browser
DEBUG - 2018-11-20 09:38:01 --> Total execution time: 0.0610
INFO - 2018-11-20 10:41:52 --> Config Class Initialized
INFO - 2018-11-20 10:41:52 --> Hooks Class Initialized
DEBUG - 2018-11-20 10:41:52 --> UTF-8 Support Enabled
INFO - 2018-11-20 10:41:52 --> Utf8 Class Initialized
INFO - 2018-11-20 10:41:52 --> URI Class Initialized
INFO - 2018-11-20 10:41:52 --> Router Class Initialized
INFO - 2018-11-20 10:41:52 --> Output Class Initialized
INFO - 2018-11-20 10:41:52 --> Security Class Initialized
DEBUG - 2018-11-20 10:41:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-20 10:41:52 --> Input Class Initialized
INFO - 2018-11-20 10:41:52 --> Language Class Initialized
INFO - 2018-11-20 10:41:52 --> Loader Class Initialized
INFO - 2018-11-20 10:41:52 --> Helper loaded: url_helper
INFO - 2018-11-20 10:41:52 --> Helper loaded: file_helper
INFO - 2018-11-20 10:41:52 --> Helper loaded: email_helper
INFO - 2018-11-20 10:41:52 --> Helper loaded: common_helper
INFO - 2018-11-20 10:41:52 --> Database Driver Class Initialized
DEBUG - 2018-11-20 10:41:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-20 10:41:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-20 10:41:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-20 10:41:52 --> Pagination Class Initialized
INFO - 2018-11-20 10:41:52 --> Helper loaded: form_helper
INFO - 2018-11-20 10:41:52 --> Form Validation Class Initialized
INFO - 2018-11-20 10:41:52 --> Model Class Initialized
INFO - 2018-11-20 10:41:52 --> Controller Class Initialized
INFO - 2018-11-20 10:41:52 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-20 10:41:52 --> Model Class Initialized
INFO - 2018-11-20 10:41:52 --> Model Class Initialized
INFO - 2018-11-20 10:41:52 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/index.php
INFO - 2018-11-20 10:41:52 --> Final output sent to browser
DEBUG - 2018-11-20 10:41:52 --> Total execution time: 0.0560
INFO - 2018-11-20 10:42:08 --> Config Class Initialized
INFO - 2018-11-20 10:42:08 --> Hooks Class Initialized
DEBUG - 2018-11-20 10:42:08 --> UTF-8 Support Enabled
INFO - 2018-11-20 10:42:08 --> Utf8 Class Initialized
INFO - 2018-11-20 10:42:08 --> URI Class Initialized
INFO - 2018-11-20 10:42:08 --> Router Class Initialized
INFO - 2018-11-20 10:42:08 --> Output Class Initialized
INFO - 2018-11-20 10:42:08 --> Security Class Initialized
DEBUG - 2018-11-20 10:42:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-20 10:42:08 --> Input Class Initialized
INFO - 2018-11-20 10:42:08 --> Language Class Initialized
INFO - 2018-11-20 10:42:08 --> Loader Class Initialized
INFO - 2018-11-20 10:42:08 --> Helper loaded: url_helper
INFO - 2018-11-20 10:42:08 --> Helper loaded: file_helper
INFO - 2018-11-20 10:42:08 --> Helper loaded: email_helper
INFO - 2018-11-20 10:42:08 --> Helper loaded: common_helper
INFO - 2018-11-20 10:42:08 --> Database Driver Class Initialized
DEBUG - 2018-11-20 10:42:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-20 10:42:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-20 10:42:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-20 10:42:08 --> Pagination Class Initialized
INFO - 2018-11-20 10:42:08 --> Helper loaded: form_helper
INFO - 2018-11-20 10:42:08 --> Form Validation Class Initialized
INFO - 2018-11-20 10:42:08 --> Model Class Initialized
INFO - 2018-11-20 10:42:08 --> Controller Class Initialized
INFO - 2018-11-20 10:42:08 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-20 10:42:08 --> Model Class Initialized
INFO - 2018-11-20 10:42:08 --> Model Class Initialized
ERROR - 2018-11-20 10:42:08 --> Severity: Notice --> Undefined index: remember_me C:\xampp\htdocs\wetinuneed\application\controllers\Admin.php 76
INFO - 2018-11-20 10:42:08 --> Config Class Initialized
INFO - 2018-11-20 10:42:08 --> Hooks Class Initialized
DEBUG - 2018-11-20 10:42:08 --> UTF-8 Support Enabled
INFO - 2018-11-20 10:42:08 --> Utf8 Class Initialized
INFO - 2018-11-20 10:42:08 --> URI Class Initialized
INFO - 2018-11-20 10:42:08 --> Router Class Initialized
INFO - 2018-11-20 10:42:08 --> Output Class Initialized
INFO - 2018-11-20 10:42:08 --> Security Class Initialized
DEBUG - 2018-11-20 10:42:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-20 10:42:08 --> Input Class Initialized
INFO - 2018-11-20 10:42:08 --> Language Class Initialized
INFO - 2018-11-20 10:42:08 --> Loader Class Initialized
INFO - 2018-11-20 10:42:08 --> Helper loaded: url_helper
INFO - 2018-11-20 10:42:08 --> Helper loaded: file_helper
INFO - 2018-11-20 10:42:08 --> Helper loaded: email_helper
INFO - 2018-11-20 10:42:08 --> Helper loaded: common_helper
INFO - 2018-11-20 10:42:08 --> Database Driver Class Initialized
DEBUG - 2018-11-20 10:42:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-20 10:42:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-20 10:42:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-20 10:42:08 --> Pagination Class Initialized
INFO - 2018-11-20 10:42:08 --> Helper loaded: form_helper
INFO - 2018-11-20 10:42:08 --> Form Validation Class Initialized
INFO - 2018-11-20 10:42:08 --> Model Class Initialized
INFO - 2018-11-20 10:42:08 --> Controller Class Initialized
INFO - 2018-11-20 10:42:08 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-20 10:42:08 --> Model Class Initialized
INFO - 2018-11-20 10:42:08 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/dashboard.php
INFO - 2018-11-20 10:42:08 --> Final output sent to browser
DEBUG - 2018-11-20 10:42:08 --> Total execution time: 0.0460
INFO - 2018-11-20 10:55:10 --> Config Class Initialized
INFO - 2018-11-20 10:55:10 --> Hooks Class Initialized
DEBUG - 2018-11-20 10:55:10 --> UTF-8 Support Enabled
INFO - 2018-11-20 10:55:10 --> Utf8 Class Initialized
INFO - 2018-11-20 10:55:10 --> URI Class Initialized
INFO - 2018-11-20 10:55:10 --> Router Class Initialized
INFO - 2018-11-20 10:55:10 --> Output Class Initialized
INFO - 2018-11-20 10:55:10 --> Security Class Initialized
DEBUG - 2018-11-20 10:55:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-20 10:55:10 --> Input Class Initialized
INFO - 2018-11-20 10:55:10 --> Language Class Initialized
INFO - 2018-11-20 10:55:10 --> Loader Class Initialized
INFO - 2018-11-20 10:55:10 --> Helper loaded: url_helper
INFO - 2018-11-20 10:55:10 --> Helper loaded: file_helper
INFO - 2018-11-20 10:55:10 --> Helper loaded: email_helper
INFO - 2018-11-20 10:55:10 --> Helper loaded: common_helper
INFO - 2018-11-20 10:55:10 --> Database Driver Class Initialized
DEBUG - 2018-11-20 10:55:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-20 10:55:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-20 10:55:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-20 10:55:10 --> Pagination Class Initialized
INFO - 2018-11-20 10:55:10 --> Helper loaded: form_helper
INFO - 2018-11-20 10:55:10 --> Form Validation Class Initialized
INFO - 2018-11-20 10:55:10 --> Model Class Initialized
INFO - 2018-11-20 10:55:10 --> Controller Class Initialized
INFO - 2018-11-20 10:55:10 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-20 10:55:10 --> Model Class Initialized
INFO - 2018-11-20 10:55:10 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/dashboard.php
INFO - 2018-11-20 10:55:10 --> Final output sent to browser
DEBUG - 2018-11-20 10:55:10 --> Total execution time: 0.0580
INFO - 2018-11-20 10:56:29 --> Config Class Initialized
INFO - 2018-11-20 10:56:29 --> Hooks Class Initialized
DEBUG - 2018-11-20 10:56:29 --> UTF-8 Support Enabled
INFO - 2018-11-20 10:56:29 --> Utf8 Class Initialized
INFO - 2018-11-20 10:56:29 --> URI Class Initialized
INFO - 2018-11-20 10:56:29 --> Router Class Initialized
INFO - 2018-11-20 10:56:29 --> Output Class Initialized
INFO - 2018-11-20 10:56:29 --> Security Class Initialized
DEBUG - 2018-11-20 10:56:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-20 10:56:29 --> Input Class Initialized
INFO - 2018-11-20 10:56:29 --> Language Class Initialized
INFO - 2018-11-20 10:56:29 --> Loader Class Initialized
INFO - 2018-11-20 10:56:29 --> Helper loaded: url_helper
INFO - 2018-11-20 10:56:29 --> Helper loaded: file_helper
INFO - 2018-11-20 10:56:29 --> Helper loaded: email_helper
INFO - 2018-11-20 10:56:29 --> Helper loaded: common_helper
INFO - 2018-11-20 10:56:29 --> Database Driver Class Initialized
DEBUG - 2018-11-20 10:56:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-20 10:56:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-20 10:56:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-20 10:56:29 --> Pagination Class Initialized
INFO - 2018-11-20 10:56:29 --> Helper loaded: form_helper
INFO - 2018-11-20 10:56:29 --> Form Validation Class Initialized
INFO - 2018-11-20 10:56:29 --> Model Class Initialized
INFO - 2018-11-20 10:56:29 --> Controller Class Initialized
INFO - 2018-11-20 10:56:29 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-20 10:56:29 --> Model Class Initialized
INFO - 2018-11-20 10:56:29 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/dashboard.php
INFO - 2018-11-20 10:56:29 --> Final output sent to browser
DEBUG - 2018-11-20 10:56:29 --> Total execution time: 0.0660
INFO - 2018-11-20 10:56:43 --> Config Class Initialized
INFO - 2018-11-20 10:56:43 --> Hooks Class Initialized
DEBUG - 2018-11-20 10:56:43 --> UTF-8 Support Enabled
INFO - 2018-11-20 10:56:43 --> Utf8 Class Initialized
INFO - 2018-11-20 10:56:43 --> URI Class Initialized
INFO - 2018-11-20 10:56:43 --> Router Class Initialized
INFO - 2018-11-20 10:56:43 --> Output Class Initialized
INFO - 2018-11-20 10:56:43 --> Security Class Initialized
DEBUG - 2018-11-20 10:56:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-20 10:56:43 --> Input Class Initialized
INFO - 2018-11-20 10:56:43 --> Language Class Initialized
INFO - 2018-11-20 10:56:43 --> Loader Class Initialized
INFO - 2018-11-20 10:56:43 --> Helper loaded: url_helper
INFO - 2018-11-20 10:56:43 --> Helper loaded: file_helper
INFO - 2018-11-20 10:56:43 --> Helper loaded: email_helper
INFO - 2018-11-20 10:56:43 --> Helper loaded: common_helper
INFO - 2018-11-20 10:56:43 --> Database Driver Class Initialized
DEBUG - 2018-11-20 10:56:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-20 10:56:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-20 10:56:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-20 10:56:43 --> Pagination Class Initialized
INFO - 2018-11-20 10:56:43 --> Helper loaded: form_helper
INFO - 2018-11-20 10:56:43 --> Form Validation Class Initialized
INFO - 2018-11-20 10:56:43 --> Model Class Initialized
INFO - 2018-11-20 10:56:43 --> Controller Class Initialized
INFO - 2018-11-20 10:56:43 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-20 10:56:43 --> Model Class Initialized
INFO - 2018-11-20 10:56:43 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/dashboard.php
INFO - 2018-11-20 10:56:43 --> Final output sent to browser
DEBUG - 2018-11-20 10:56:43 --> Total execution time: 0.0760
INFO - 2018-11-20 10:56:50 --> Config Class Initialized
INFO - 2018-11-20 10:56:50 --> Hooks Class Initialized
DEBUG - 2018-11-20 10:56:50 --> UTF-8 Support Enabled
INFO - 2018-11-20 10:56:50 --> Utf8 Class Initialized
INFO - 2018-11-20 10:56:50 --> URI Class Initialized
INFO - 2018-11-20 10:56:50 --> Router Class Initialized
INFO - 2018-11-20 10:56:50 --> Output Class Initialized
INFO - 2018-11-20 10:56:50 --> Security Class Initialized
DEBUG - 2018-11-20 10:56:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-20 10:56:50 --> Input Class Initialized
INFO - 2018-11-20 10:56:50 --> Language Class Initialized
INFO - 2018-11-20 10:56:50 --> Loader Class Initialized
INFO - 2018-11-20 10:56:50 --> Helper loaded: url_helper
INFO - 2018-11-20 10:56:50 --> Helper loaded: file_helper
INFO - 2018-11-20 10:56:50 --> Helper loaded: email_helper
INFO - 2018-11-20 10:56:50 --> Helper loaded: common_helper
INFO - 2018-11-20 10:56:50 --> Database Driver Class Initialized
DEBUG - 2018-11-20 10:56:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-20 10:56:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-20 10:56:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-20 10:56:50 --> Pagination Class Initialized
INFO - 2018-11-20 10:56:50 --> Helper loaded: form_helper
INFO - 2018-11-20 10:56:50 --> Form Validation Class Initialized
INFO - 2018-11-20 10:56:50 --> Model Class Initialized
INFO - 2018-11-20 10:56:50 --> Controller Class Initialized
INFO - 2018-11-20 10:56:50 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-20 10:56:50 --> Model Class Initialized
INFO - 2018-11-20 10:56:50 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/dashboard.php
INFO - 2018-11-20 10:56:50 --> Final output sent to browser
DEBUG - 2018-11-20 10:56:50 --> Total execution time: 0.0780
INFO - 2018-11-20 11:01:27 --> Config Class Initialized
INFO - 2018-11-20 11:01:27 --> Hooks Class Initialized
DEBUG - 2018-11-20 11:01:27 --> UTF-8 Support Enabled
INFO - 2018-11-20 11:01:27 --> Utf8 Class Initialized
INFO - 2018-11-20 11:01:27 --> URI Class Initialized
INFO - 2018-11-20 11:01:27 --> Router Class Initialized
INFO - 2018-11-20 11:01:27 --> Output Class Initialized
INFO - 2018-11-20 11:01:27 --> Security Class Initialized
DEBUG - 2018-11-20 11:01:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-20 11:01:27 --> Input Class Initialized
INFO - 2018-11-20 11:01:27 --> Language Class Initialized
INFO - 2018-11-20 11:01:27 --> Loader Class Initialized
INFO - 2018-11-20 11:01:27 --> Helper loaded: url_helper
INFO - 2018-11-20 11:01:27 --> Helper loaded: file_helper
INFO - 2018-11-20 11:01:27 --> Helper loaded: email_helper
INFO - 2018-11-20 11:01:27 --> Helper loaded: common_helper
INFO - 2018-11-20 11:01:27 --> Database Driver Class Initialized
DEBUG - 2018-11-20 11:01:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-20 11:01:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-20 11:01:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-20 11:01:27 --> Pagination Class Initialized
INFO - 2018-11-20 11:01:27 --> Helper loaded: form_helper
INFO - 2018-11-20 11:01:27 --> Form Validation Class Initialized
INFO - 2018-11-20 11:01:27 --> Model Class Initialized
INFO - 2018-11-20 11:01:27 --> Controller Class Initialized
INFO - 2018-11-20 11:01:27 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-20 11:01:27 --> Model Class Initialized
INFO - 2018-11-20 11:01:27 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/dashboard.php
INFO - 2018-11-20 11:01:27 --> Final output sent to browser
DEBUG - 2018-11-20 11:01:27 --> Total execution time: 0.0630
INFO - 2018-11-20 11:01:51 --> Config Class Initialized
INFO - 2018-11-20 11:01:51 --> Hooks Class Initialized
DEBUG - 2018-11-20 11:01:51 --> UTF-8 Support Enabled
INFO - 2018-11-20 11:01:51 --> Utf8 Class Initialized
INFO - 2018-11-20 11:01:51 --> URI Class Initialized
INFO - 2018-11-20 11:01:51 --> Router Class Initialized
INFO - 2018-11-20 11:01:51 --> Output Class Initialized
INFO - 2018-11-20 11:01:51 --> Security Class Initialized
DEBUG - 2018-11-20 11:01:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-20 11:01:51 --> Input Class Initialized
INFO - 2018-11-20 11:01:51 --> Language Class Initialized
INFO - 2018-11-20 11:01:51 --> Loader Class Initialized
INFO - 2018-11-20 11:01:51 --> Helper loaded: url_helper
INFO - 2018-11-20 11:01:51 --> Helper loaded: file_helper
INFO - 2018-11-20 11:01:51 --> Helper loaded: email_helper
INFO - 2018-11-20 11:01:51 --> Helper loaded: common_helper
INFO - 2018-11-20 11:01:51 --> Database Driver Class Initialized
DEBUG - 2018-11-20 11:01:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-20 11:01:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-20 11:01:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-20 11:01:51 --> Pagination Class Initialized
INFO - 2018-11-20 11:01:51 --> Helper loaded: form_helper
INFO - 2018-11-20 11:01:51 --> Form Validation Class Initialized
INFO - 2018-11-20 11:01:51 --> Model Class Initialized
INFO - 2018-11-20 11:01:51 --> Controller Class Initialized
INFO - 2018-11-20 11:01:51 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-20 11:01:51 --> Model Class Initialized
INFO - 2018-11-20 11:01:51 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/dashboard.php
INFO - 2018-11-20 11:01:51 --> Final output sent to browser
DEBUG - 2018-11-20 11:01:51 --> Total execution time: 0.0710
INFO - 2018-11-20 11:02:11 --> Config Class Initialized
INFO - 2018-11-20 11:02:11 --> Hooks Class Initialized
DEBUG - 2018-11-20 11:02:11 --> UTF-8 Support Enabled
INFO - 2018-11-20 11:02:11 --> Utf8 Class Initialized
INFO - 2018-11-20 11:02:11 --> URI Class Initialized
INFO - 2018-11-20 11:02:11 --> Router Class Initialized
INFO - 2018-11-20 11:02:11 --> Output Class Initialized
INFO - 2018-11-20 11:02:11 --> Security Class Initialized
DEBUG - 2018-11-20 11:02:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-20 11:02:11 --> Input Class Initialized
INFO - 2018-11-20 11:02:11 --> Language Class Initialized
INFO - 2018-11-20 11:02:11 --> Loader Class Initialized
INFO - 2018-11-20 11:02:11 --> Helper loaded: url_helper
INFO - 2018-11-20 11:02:11 --> Helper loaded: file_helper
INFO - 2018-11-20 11:02:11 --> Helper loaded: email_helper
INFO - 2018-11-20 11:02:11 --> Helper loaded: common_helper
INFO - 2018-11-20 11:02:11 --> Database Driver Class Initialized
DEBUG - 2018-11-20 11:02:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-20 11:02:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-20 11:02:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-20 11:02:11 --> Pagination Class Initialized
INFO - 2018-11-20 11:02:11 --> Helper loaded: form_helper
INFO - 2018-11-20 11:02:11 --> Form Validation Class Initialized
INFO - 2018-11-20 11:02:11 --> Model Class Initialized
INFO - 2018-11-20 11:02:11 --> Controller Class Initialized
INFO - 2018-11-20 11:02:11 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-20 11:02:11 --> Model Class Initialized
INFO - 2018-11-20 11:02:11 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/dashboard.php
INFO - 2018-11-20 11:02:11 --> Final output sent to browser
DEBUG - 2018-11-20 11:02:11 --> Total execution time: 0.0590
INFO - 2018-11-20 11:05:17 --> Config Class Initialized
INFO - 2018-11-20 11:05:17 --> Hooks Class Initialized
DEBUG - 2018-11-20 11:05:17 --> UTF-8 Support Enabled
INFO - 2018-11-20 11:05:17 --> Utf8 Class Initialized
INFO - 2018-11-20 11:05:17 --> URI Class Initialized
INFO - 2018-11-20 11:05:17 --> Router Class Initialized
INFO - 2018-11-20 11:05:17 --> Output Class Initialized
INFO - 2018-11-20 11:05:17 --> Security Class Initialized
DEBUG - 2018-11-20 11:05:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-20 11:05:17 --> Input Class Initialized
INFO - 2018-11-20 11:05:17 --> Language Class Initialized
INFO - 2018-11-20 11:05:17 --> Loader Class Initialized
INFO - 2018-11-20 11:05:17 --> Helper loaded: url_helper
INFO - 2018-11-20 11:05:17 --> Helper loaded: file_helper
INFO - 2018-11-20 11:05:17 --> Helper loaded: email_helper
INFO - 2018-11-20 11:05:17 --> Helper loaded: common_helper
INFO - 2018-11-20 11:05:17 --> Database Driver Class Initialized
DEBUG - 2018-11-20 11:05:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-20 11:05:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-20 11:05:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-20 11:05:17 --> Pagination Class Initialized
INFO - 2018-11-20 11:05:17 --> Helper loaded: form_helper
INFO - 2018-11-20 11:05:17 --> Form Validation Class Initialized
INFO - 2018-11-20 11:05:17 --> Model Class Initialized
INFO - 2018-11-20 11:05:17 --> Controller Class Initialized
INFO - 2018-11-20 11:05:17 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-20 11:05:17 --> Model Class Initialized
INFO - 2018-11-20 11:05:17 --> Model Class Initialized
INFO - 2018-11-20 11:05:17 --> Config Class Initialized
INFO - 2018-11-20 11:05:17 --> Hooks Class Initialized
DEBUG - 2018-11-20 11:05:17 --> UTF-8 Support Enabled
INFO - 2018-11-20 11:05:17 --> Utf8 Class Initialized
INFO - 2018-11-20 11:05:17 --> URI Class Initialized
INFO - 2018-11-20 11:05:17 --> Router Class Initialized
INFO - 2018-11-20 11:05:17 --> Output Class Initialized
INFO - 2018-11-20 11:05:17 --> Security Class Initialized
DEBUG - 2018-11-20 11:05:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-20 11:05:17 --> Input Class Initialized
INFO - 2018-11-20 11:05:17 --> Language Class Initialized
INFO - 2018-11-20 11:05:17 --> Loader Class Initialized
INFO - 2018-11-20 11:05:17 --> Helper loaded: url_helper
INFO - 2018-11-20 11:05:17 --> Helper loaded: file_helper
INFO - 2018-11-20 11:05:17 --> Helper loaded: email_helper
INFO - 2018-11-20 11:05:17 --> Helper loaded: common_helper
INFO - 2018-11-20 11:05:17 --> Database Driver Class Initialized
DEBUG - 2018-11-20 11:05:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-20 11:05:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-20 11:05:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-20 11:05:17 --> Pagination Class Initialized
INFO - 2018-11-20 11:05:17 --> Helper loaded: form_helper
INFO - 2018-11-20 11:05:17 --> Form Validation Class Initialized
INFO - 2018-11-20 11:05:17 --> Model Class Initialized
INFO - 2018-11-20 11:05:17 --> Controller Class Initialized
INFO - 2018-11-20 11:05:17 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-20 11:05:17 --> Model Class Initialized
INFO - 2018-11-20 11:05:17 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/dashboard.php
INFO - 2018-11-20 11:05:17 --> Final output sent to browser
DEBUG - 2018-11-20 11:05:17 --> Total execution time: 0.0600
INFO - 2018-11-20 11:05:19 --> Config Class Initialized
INFO - 2018-11-20 11:05:19 --> Hooks Class Initialized
DEBUG - 2018-11-20 11:05:19 --> UTF-8 Support Enabled
INFO - 2018-11-20 11:05:19 --> Utf8 Class Initialized
INFO - 2018-11-20 11:05:19 --> URI Class Initialized
DEBUG - 2018-11-20 11:05:19 --> No URI present. Default controller set.
INFO - 2018-11-20 11:05:19 --> Router Class Initialized
INFO - 2018-11-20 11:05:19 --> Output Class Initialized
INFO - 2018-11-20 11:05:19 --> Security Class Initialized
DEBUG - 2018-11-20 11:05:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-20 11:05:19 --> Input Class Initialized
INFO - 2018-11-20 11:05:19 --> Language Class Initialized
INFO - 2018-11-20 11:05:19 --> Loader Class Initialized
INFO - 2018-11-20 11:05:19 --> Helper loaded: url_helper
INFO - 2018-11-20 11:05:19 --> Helper loaded: file_helper
INFO - 2018-11-20 11:05:19 --> Helper loaded: email_helper
INFO - 2018-11-20 11:05:19 --> Helper loaded: common_helper
INFO - 2018-11-20 11:05:19 --> Database Driver Class Initialized
DEBUG - 2018-11-20 11:05:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-20 11:05:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-20 11:05:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-20 11:05:19 --> Pagination Class Initialized
INFO - 2018-11-20 11:05:19 --> Helper loaded: form_helper
INFO - 2018-11-20 11:05:19 --> Form Validation Class Initialized
INFO - 2018-11-20 11:05:19 --> Model Class Initialized
INFO - 2018-11-20 11:05:19 --> Controller Class Initialized
INFO - 2018-11-20 11:05:19 --> Model Class Initialized
INFO - 2018-11-20 11:05:19 --> Model Class Initialized
INFO - 2018-11-20 11:05:19 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\template/header-menu.php
INFO - 2018-11-20 11:05:19 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\template/header.php
INFO - 2018-11-20 11:05:19 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\template/footer.php
INFO - 2018-11-20 11:05:19 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\index.php
INFO - 2018-11-20 11:05:19 --> Final output sent to browser
DEBUG - 2018-11-20 11:05:19 --> Total execution time: 0.0810
INFO - 2018-11-20 11:12:40 --> Config Class Initialized
INFO - 2018-11-20 11:12:40 --> Hooks Class Initialized
DEBUG - 2018-11-20 11:12:40 --> UTF-8 Support Enabled
INFO - 2018-11-20 11:12:40 --> Utf8 Class Initialized
INFO - 2018-11-20 11:12:40 --> URI Class Initialized
INFO - 2018-11-20 11:12:40 --> Router Class Initialized
INFO - 2018-11-20 11:12:40 --> Output Class Initialized
INFO - 2018-11-20 11:12:40 --> Security Class Initialized
DEBUG - 2018-11-20 11:12:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-20 11:12:40 --> Input Class Initialized
INFO - 2018-11-20 11:12:40 --> Language Class Initialized
ERROR - 2018-11-20 11:12:40 --> 404 Page Not Found: Lo/index
INFO - 2018-11-20 11:12:46 --> Config Class Initialized
INFO - 2018-11-20 11:12:46 --> Hooks Class Initialized
DEBUG - 2018-11-20 11:12:46 --> UTF-8 Support Enabled
INFO - 2018-11-20 11:12:46 --> Utf8 Class Initialized
INFO - 2018-11-20 11:12:46 --> URI Class Initialized
INFO - 2018-11-20 11:12:46 --> Router Class Initialized
INFO - 2018-11-20 11:12:46 --> Output Class Initialized
INFO - 2018-11-20 11:12:46 --> Security Class Initialized
DEBUG - 2018-11-20 11:12:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-20 11:12:46 --> Input Class Initialized
INFO - 2018-11-20 11:12:46 --> Language Class Initialized
INFO - 2018-11-20 11:12:46 --> Loader Class Initialized
INFO - 2018-11-20 11:12:46 --> Helper loaded: url_helper
INFO - 2018-11-20 11:12:46 --> Helper loaded: file_helper
INFO - 2018-11-20 11:12:46 --> Helper loaded: email_helper
INFO - 2018-11-20 11:12:46 --> Helper loaded: common_helper
INFO - 2018-11-20 11:12:46 --> Database Driver Class Initialized
DEBUG - 2018-11-20 11:12:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-20 11:12:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-20 11:12:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-20 11:12:46 --> Pagination Class Initialized
INFO - 2018-11-20 11:12:46 --> Helper loaded: form_helper
INFO - 2018-11-20 11:12:46 --> Form Validation Class Initialized
INFO - 2018-11-20 11:12:46 --> Model Class Initialized
INFO - 2018-11-20 11:12:46 --> Controller Class Initialized
INFO - 2018-11-20 11:12:46 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-20 11:12:46 --> Model Class Initialized
INFO - 2018-11-20 11:12:46 --> Model Class Initialized
INFO - 2018-11-20 11:12:46 --> Config Class Initialized
INFO - 2018-11-20 11:12:46 --> Hooks Class Initialized
DEBUG - 2018-11-20 11:12:46 --> UTF-8 Support Enabled
INFO - 2018-11-20 11:12:46 --> Utf8 Class Initialized
INFO - 2018-11-20 11:12:46 --> URI Class Initialized
INFO - 2018-11-20 11:12:46 --> Router Class Initialized
INFO - 2018-11-20 11:12:46 --> Output Class Initialized
INFO - 2018-11-20 11:12:46 --> Security Class Initialized
DEBUG - 2018-11-20 11:12:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-20 11:12:46 --> Input Class Initialized
INFO - 2018-11-20 11:12:46 --> Language Class Initialized
INFO - 2018-11-20 11:12:46 --> Loader Class Initialized
INFO - 2018-11-20 11:12:46 --> Helper loaded: url_helper
INFO - 2018-11-20 11:12:46 --> Helper loaded: file_helper
INFO - 2018-11-20 11:12:46 --> Helper loaded: email_helper
INFO - 2018-11-20 11:12:46 --> Helper loaded: common_helper
INFO - 2018-11-20 11:12:46 --> Database Driver Class Initialized
DEBUG - 2018-11-20 11:12:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-20 11:12:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-20 11:12:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-20 11:12:46 --> Pagination Class Initialized
INFO - 2018-11-20 11:12:46 --> Helper loaded: form_helper
INFO - 2018-11-20 11:12:46 --> Form Validation Class Initialized
INFO - 2018-11-20 11:12:46 --> Model Class Initialized
INFO - 2018-11-20 11:12:46 --> Controller Class Initialized
INFO - 2018-11-20 11:12:46 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-20 11:12:46 --> Model Class Initialized
INFO - 2018-11-20 11:12:46 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
ERROR - 2018-11-20 11:12:46 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string C:\xampp\htdocs\wetinuneed\application\views\admin\dashboard.php 12
INFO - 2018-11-20 11:12:46 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/dashboard.php
INFO - 2018-11-20 11:12:46 --> Final output sent to browser
DEBUG - 2018-11-20 11:12:46 --> Total execution time: 0.0450
INFO - 2018-11-20 11:13:03 --> Config Class Initialized
INFO - 2018-11-20 11:13:03 --> Hooks Class Initialized
DEBUG - 2018-11-20 11:13:03 --> UTF-8 Support Enabled
INFO - 2018-11-20 11:13:03 --> Utf8 Class Initialized
INFO - 2018-11-20 11:13:03 --> URI Class Initialized
INFO - 2018-11-20 11:13:03 --> Router Class Initialized
INFO - 2018-11-20 11:13:03 --> Output Class Initialized
INFO - 2018-11-20 11:13:03 --> Security Class Initialized
DEBUG - 2018-11-20 11:13:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-20 11:13:03 --> Input Class Initialized
INFO - 2018-11-20 11:13:03 --> Language Class Initialized
INFO - 2018-11-20 11:13:03 --> Loader Class Initialized
INFO - 2018-11-20 11:13:03 --> Helper loaded: url_helper
INFO - 2018-11-20 11:13:03 --> Helper loaded: file_helper
INFO - 2018-11-20 11:13:03 --> Helper loaded: email_helper
INFO - 2018-11-20 11:13:03 --> Helper loaded: common_helper
INFO - 2018-11-20 11:13:03 --> Database Driver Class Initialized
DEBUG - 2018-11-20 11:13:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-20 11:13:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-20 11:13:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-20 11:13:03 --> Pagination Class Initialized
INFO - 2018-11-20 11:13:03 --> Helper loaded: form_helper
INFO - 2018-11-20 11:13:03 --> Form Validation Class Initialized
INFO - 2018-11-20 11:13:03 --> Model Class Initialized
INFO - 2018-11-20 11:13:03 --> Controller Class Initialized
INFO - 2018-11-20 11:13:03 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-20 11:13:03 --> Model Class Initialized
INFO - 2018-11-20 11:13:03 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
ERROR - 2018-11-20 11:13:03 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string C:\xampp\htdocs\wetinuneed\application\views\admin\dashboard.php 12
INFO - 2018-11-20 11:13:03 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/dashboard.php
INFO - 2018-11-20 11:13:03 --> Final output sent to browser
DEBUG - 2018-11-20 11:13:03 --> Total execution time: 0.0680
INFO - 2018-11-20 11:13:06 --> Config Class Initialized
INFO - 2018-11-20 11:13:06 --> Hooks Class Initialized
DEBUG - 2018-11-20 11:13:06 --> UTF-8 Support Enabled
INFO - 2018-11-20 11:13:06 --> Utf8 Class Initialized
INFO - 2018-11-20 11:13:06 --> URI Class Initialized
INFO - 2018-11-20 11:13:06 --> Router Class Initialized
INFO - 2018-11-20 11:13:06 --> Output Class Initialized
INFO - 2018-11-20 11:13:06 --> Security Class Initialized
DEBUG - 2018-11-20 11:13:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-20 11:13:06 --> Input Class Initialized
INFO - 2018-11-20 11:13:06 --> Language Class Initialized
INFO - 2018-11-20 11:13:06 --> Loader Class Initialized
INFO - 2018-11-20 11:13:06 --> Helper loaded: url_helper
INFO - 2018-11-20 11:13:06 --> Helper loaded: file_helper
INFO - 2018-11-20 11:13:06 --> Helper loaded: email_helper
INFO - 2018-11-20 11:13:06 --> Helper loaded: common_helper
INFO - 2018-11-20 11:13:06 --> Database Driver Class Initialized
DEBUG - 2018-11-20 11:13:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-20 11:13:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-20 11:13:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-20 11:13:06 --> Pagination Class Initialized
INFO - 2018-11-20 11:13:06 --> Helper loaded: form_helper
INFO - 2018-11-20 11:13:06 --> Form Validation Class Initialized
INFO - 2018-11-20 11:13:06 --> Model Class Initialized
INFO - 2018-11-20 11:13:06 --> Controller Class Initialized
INFO - 2018-11-20 11:13:06 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-20 11:13:06 --> Model Class Initialized
INFO - 2018-11-20 11:13:06 --> Model Class Initialized
INFO - 2018-11-20 11:13:06 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/index.php
INFO - 2018-11-20 11:13:06 --> Final output sent to browser
DEBUG - 2018-11-20 11:13:06 --> Total execution time: 0.0600
INFO - 2018-11-20 11:13:08 --> Config Class Initialized
INFO - 2018-11-20 11:13:08 --> Hooks Class Initialized
DEBUG - 2018-11-20 11:13:08 --> UTF-8 Support Enabled
INFO - 2018-11-20 11:13:08 --> Utf8 Class Initialized
INFO - 2018-11-20 11:13:08 --> URI Class Initialized
INFO - 2018-11-20 11:13:08 --> Router Class Initialized
INFO - 2018-11-20 11:13:08 --> Output Class Initialized
INFO - 2018-11-20 11:13:08 --> Security Class Initialized
DEBUG - 2018-11-20 11:13:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-20 11:13:08 --> Input Class Initialized
INFO - 2018-11-20 11:13:08 --> Language Class Initialized
INFO - 2018-11-20 11:13:08 --> Loader Class Initialized
INFO - 2018-11-20 11:13:08 --> Helper loaded: url_helper
INFO - 2018-11-20 11:13:08 --> Helper loaded: file_helper
INFO - 2018-11-20 11:13:08 --> Helper loaded: email_helper
INFO - 2018-11-20 11:13:08 --> Helper loaded: common_helper
INFO - 2018-11-20 11:13:08 --> Database Driver Class Initialized
DEBUG - 2018-11-20 11:13:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-20 11:13:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-20 11:13:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-20 11:13:08 --> Pagination Class Initialized
INFO - 2018-11-20 11:13:08 --> Helper loaded: form_helper
INFO - 2018-11-20 11:13:08 --> Form Validation Class Initialized
INFO - 2018-11-20 11:13:08 --> Model Class Initialized
INFO - 2018-11-20 11:13:08 --> Controller Class Initialized
INFO - 2018-11-20 11:13:08 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-20 11:13:08 --> Model Class Initialized
INFO - 2018-11-20 11:13:08 --> Model Class Initialized
INFO - 2018-11-20 11:13:08 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/index.php
INFO - 2018-11-20 11:13:08 --> Final output sent to browser
DEBUG - 2018-11-20 11:13:08 --> Total execution time: 0.0540
INFO - 2018-11-20 11:13:10 --> Config Class Initialized
INFO - 2018-11-20 11:13:10 --> Hooks Class Initialized
DEBUG - 2018-11-20 11:13:10 --> UTF-8 Support Enabled
INFO - 2018-11-20 11:13:10 --> Utf8 Class Initialized
INFO - 2018-11-20 11:13:10 --> URI Class Initialized
INFO - 2018-11-20 11:13:10 --> Router Class Initialized
INFO - 2018-11-20 11:13:10 --> Output Class Initialized
INFO - 2018-11-20 11:13:10 --> Security Class Initialized
DEBUG - 2018-11-20 11:13:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-20 11:13:10 --> Input Class Initialized
INFO - 2018-11-20 11:13:10 --> Language Class Initialized
INFO - 2018-11-20 11:13:10 --> Loader Class Initialized
INFO - 2018-11-20 11:13:10 --> Helper loaded: url_helper
INFO - 2018-11-20 11:13:10 --> Helper loaded: file_helper
INFO - 2018-11-20 11:13:10 --> Helper loaded: email_helper
INFO - 2018-11-20 11:13:10 --> Helper loaded: common_helper
INFO - 2018-11-20 11:13:10 --> Database Driver Class Initialized
DEBUG - 2018-11-20 11:13:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-20 11:13:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-20 11:13:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-20 11:13:10 --> Pagination Class Initialized
INFO - 2018-11-20 11:13:10 --> Helper loaded: form_helper
INFO - 2018-11-20 11:13:10 --> Form Validation Class Initialized
INFO - 2018-11-20 11:13:10 --> Model Class Initialized
INFO - 2018-11-20 11:13:10 --> Controller Class Initialized
INFO - 2018-11-20 11:13:10 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-20 11:13:10 --> Model Class Initialized
INFO - 2018-11-20 11:13:10 --> Model Class Initialized
INFO - 2018-11-20 11:13:10 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/index.php
INFO - 2018-11-20 11:13:10 --> Final output sent to browser
DEBUG - 2018-11-20 11:13:10 --> Total execution time: 0.0510
INFO - 2018-11-20 11:13:14 --> Config Class Initialized
INFO - 2018-11-20 11:13:14 --> Hooks Class Initialized
DEBUG - 2018-11-20 11:13:14 --> UTF-8 Support Enabled
INFO - 2018-11-20 11:13:14 --> Utf8 Class Initialized
INFO - 2018-11-20 11:13:14 --> URI Class Initialized
INFO - 2018-11-20 11:13:14 --> Router Class Initialized
INFO - 2018-11-20 11:13:14 --> Output Class Initialized
INFO - 2018-11-20 11:13:14 --> Security Class Initialized
DEBUG - 2018-11-20 11:13:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-20 11:13:14 --> Input Class Initialized
INFO - 2018-11-20 11:13:14 --> Language Class Initialized
INFO - 2018-11-20 11:13:14 --> Loader Class Initialized
INFO - 2018-11-20 11:13:14 --> Helper loaded: url_helper
INFO - 2018-11-20 11:13:14 --> Helper loaded: file_helper
INFO - 2018-11-20 11:13:14 --> Helper loaded: email_helper
INFO - 2018-11-20 11:13:14 --> Helper loaded: common_helper
INFO - 2018-11-20 11:13:14 --> Database Driver Class Initialized
DEBUG - 2018-11-20 11:13:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-20 11:13:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-20 11:13:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-20 11:13:14 --> Pagination Class Initialized
INFO - 2018-11-20 11:13:14 --> Helper loaded: form_helper
INFO - 2018-11-20 11:13:14 --> Form Validation Class Initialized
INFO - 2018-11-20 11:13:14 --> Model Class Initialized
INFO - 2018-11-20 11:13:14 --> Controller Class Initialized
INFO - 2018-11-20 11:13:14 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-20 11:13:14 --> Model Class Initialized
INFO - 2018-11-20 11:13:14 --> Model Class Initialized
INFO - 2018-11-20 11:13:14 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/index.php
INFO - 2018-11-20 11:13:14 --> Final output sent to browser
DEBUG - 2018-11-20 11:13:14 --> Total execution time: 0.0650
INFO - 2018-11-20 11:16:43 --> Config Class Initialized
INFO - 2018-11-20 11:16:43 --> Hooks Class Initialized
DEBUG - 2018-11-20 11:16:43 --> UTF-8 Support Enabled
INFO - 2018-11-20 11:16:43 --> Utf8 Class Initialized
INFO - 2018-11-20 11:16:43 --> URI Class Initialized
INFO - 2018-11-20 11:16:43 --> Router Class Initialized
INFO - 2018-11-20 11:16:43 --> Output Class Initialized
INFO - 2018-11-20 11:16:43 --> Security Class Initialized
DEBUG - 2018-11-20 11:16:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-20 11:16:43 --> Input Class Initialized
INFO - 2018-11-20 11:16:43 --> Language Class Initialized
INFO - 2018-11-20 11:16:43 --> Loader Class Initialized
INFO - 2018-11-20 11:16:43 --> Helper loaded: url_helper
INFO - 2018-11-20 11:16:43 --> Helper loaded: file_helper
INFO - 2018-11-20 11:16:43 --> Helper loaded: email_helper
INFO - 2018-11-20 11:16:43 --> Helper loaded: common_helper
INFO - 2018-11-20 11:16:43 --> Database Driver Class Initialized
DEBUG - 2018-11-20 11:16:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-20 11:16:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-20 11:16:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-20 11:16:44 --> Pagination Class Initialized
INFO - 2018-11-20 11:16:44 --> Helper loaded: form_helper
INFO - 2018-11-20 11:16:44 --> Form Validation Class Initialized
INFO - 2018-11-20 11:16:44 --> Model Class Initialized
INFO - 2018-11-20 11:16:44 --> Controller Class Initialized
INFO - 2018-11-20 11:16:44 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-20 11:16:44 --> Model Class Initialized
INFO - 2018-11-20 11:16:44 --> Model Class Initialized
INFO - 2018-11-20 11:16:44 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/index.php
INFO - 2018-11-20 11:16:44 --> Final output sent to browser
DEBUG - 2018-11-20 11:16:44 --> Total execution time: 0.0650
INFO - 2018-11-20 11:18:24 --> Config Class Initialized
INFO - 2018-11-20 11:18:24 --> Hooks Class Initialized
DEBUG - 2018-11-20 11:18:24 --> UTF-8 Support Enabled
INFO - 2018-11-20 11:18:24 --> Utf8 Class Initialized
INFO - 2018-11-20 11:18:24 --> URI Class Initialized
INFO - 2018-11-20 11:18:24 --> Router Class Initialized
INFO - 2018-11-20 11:18:24 --> Output Class Initialized
INFO - 2018-11-20 11:18:24 --> Security Class Initialized
DEBUG - 2018-11-20 11:18:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-20 11:18:24 --> Input Class Initialized
INFO - 2018-11-20 11:18:24 --> Language Class Initialized
INFO - 2018-11-20 11:18:24 --> Loader Class Initialized
INFO - 2018-11-20 11:18:24 --> Helper loaded: url_helper
INFO - 2018-11-20 11:18:24 --> Helper loaded: file_helper
INFO - 2018-11-20 11:18:24 --> Helper loaded: email_helper
INFO - 2018-11-20 11:18:24 --> Helper loaded: common_helper
INFO - 2018-11-20 11:18:24 --> Database Driver Class Initialized
DEBUG - 2018-11-20 11:18:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-20 11:18:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-20 11:18:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-20 11:18:24 --> Pagination Class Initialized
INFO - 2018-11-20 11:18:24 --> Helper loaded: form_helper
INFO - 2018-11-20 11:18:24 --> Form Validation Class Initialized
INFO - 2018-11-20 11:18:24 --> Model Class Initialized
INFO - 2018-11-20 11:18:24 --> Controller Class Initialized
INFO - 2018-11-20 11:18:24 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-20 11:18:24 --> Model Class Initialized
INFO - 2018-11-20 11:18:24 --> Model Class Initialized
INFO - 2018-11-20 11:18:24 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/index.php
INFO - 2018-11-20 11:18:24 --> Final output sent to browser
DEBUG - 2018-11-20 11:18:24 --> Total execution time: 0.0530
INFO - 2018-11-20 11:19:08 --> Config Class Initialized
INFO - 2018-11-20 11:19:08 --> Hooks Class Initialized
DEBUG - 2018-11-20 11:19:08 --> UTF-8 Support Enabled
INFO - 2018-11-20 11:19:08 --> Utf8 Class Initialized
INFO - 2018-11-20 11:19:08 --> URI Class Initialized
INFO - 2018-11-20 11:19:08 --> Router Class Initialized
INFO - 2018-11-20 11:19:08 --> Output Class Initialized
INFO - 2018-11-20 11:19:08 --> Security Class Initialized
DEBUG - 2018-11-20 11:19:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-20 11:19:08 --> Input Class Initialized
INFO - 2018-11-20 11:19:08 --> Language Class Initialized
INFO - 2018-11-20 11:19:08 --> Loader Class Initialized
INFO - 2018-11-20 11:19:08 --> Helper loaded: url_helper
INFO - 2018-11-20 11:19:08 --> Helper loaded: file_helper
INFO - 2018-11-20 11:19:08 --> Helper loaded: email_helper
INFO - 2018-11-20 11:19:08 --> Helper loaded: common_helper
INFO - 2018-11-20 11:19:08 --> Database Driver Class Initialized
DEBUG - 2018-11-20 11:19:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-20 11:19:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-20 11:19:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-20 11:19:08 --> Pagination Class Initialized
INFO - 2018-11-20 11:19:08 --> Helper loaded: form_helper
INFO - 2018-11-20 11:19:08 --> Form Validation Class Initialized
INFO - 2018-11-20 11:19:08 --> Model Class Initialized
INFO - 2018-11-20 11:19:08 --> Controller Class Initialized
INFO - 2018-11-20 11:19:08 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-20 11:19:08 --> Model Class Initialized
INFO - 2018-11-20 11:19:08 --> Model Class Initialized
INFO - 2018-11-20 11:19:08 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/index.php
INFO - 2018-11-20 11:19:08 --> Final output sent to browser
DEBUG - 2018-11-20 11:19:08 --> Total execution time: 0.0560
INFO - 2018-11-20 11:20:51 --> Config Class Initialized
INFO - 2018-11-20 11:20:51 --> Hooks Class Initialized
DEBUG - 2018-11-20 11:20:51 --> UTF-8 Support Enabled
INFO - 2018-11-20 11:20:51 --> Utf8 Class Initialized
INFO - 2018-11-20 11:20:51 --> URI Class Initialized
INFO - 2018-11-20 11:20:51 --> Router Class Initialized
INFO - 2018-11-20 11:20:51 --> Output Class Initialized
INFO - 2018-11-20 11:20:51 --> Security Class Initialized
DEBUG - 2018-11-20 11:20:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-20 11:20:51 --> Input Class Initialized
INFO - 2018-11-20 11:20:51 --> Language Class Initialized
INFO - 2018-11-20 11:20:51 --> Loader Class Initialized
INFO - 2018-11-20 11:20:51 --> Helper loaded: url_helper
INFO - 2018-11-20 11:20:51 --> Helper loaded: file_helper
INFO - 2018-11-20 11:20:51 --> Helper loaded: email_helper
INFO - 2018-11-20 11:20:51 --> Helper loaded: common_helper
INFO - 2018-11-20 11:20:51 --> Database Driver Class Initialized
DEBUG - 2018-11-20 11:20:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-20 11:20:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-20 11:20:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-20 11:20:51 --> Pagination Class Initialized
INFO - 2018-11-20 11:20:51 --> Helper loaded: form_helper
INFO - 2018-11-20 11:20:51 --> Form Validation Class Initialized
INFO - 2018-11-20 11:20:51 --> Model Class Initialized
INFO - 2018-11-20 11:20:51 --> Controller Class Initialized
INFO - 2018-11-20 11:20:51 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-20 11:20:51 --> Model Class Initialized
INFO - 2018-11-20 11:20:51 --> Model Class Initialized
INFO - 2018-11-20 11:20:51 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/index.php
INFO - 2018-11-20 11:20:51 --> Final output sent to browser
DEBUG - 2018-11-20 11:20:52 --> Total execution time: 0.0560
INFO - 2018-11-20 11:24:23 --> Config Class Initialized
INFO - 2018-11-20 11:24:23 --> Hooks Class Initialized
DEBUG - 2018-11-20 11:24:23 --> UTF-8 Support Enabled
INFO - 2018-11-20 11:24:23 --> Utf8 Class Initialized
INFO - 2018-11-20 11:24:23 --> URI Class Initialized
INFO - 2018-11-20 11:24:23 --> Router Class Initialized
INFO - 2018-11-20 11:24:23 --> Output Class Initialized
INFO - 2018-11-20 11:24:23 --> Security Class Initialized
DEBUG - 2018-11-20 11:24:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-20 11:24:23 --> Input Class Initialized
INFO - 2018-11-20 11:24:23 --> Language Class Initialized
INFO - 2018-11-20 11:24:23 --> Loader Class Initialized
INFO - 2018-11-20 11:24:23 --> Helper loaded: url_helper
INFO - 2018-11-20 11:24:23 --> Helper loaded: file_helper
INFO - 2018-11-20 11:24:23 --> Helper loaded: email_helper
INFO - 2018-11-20 11:24:23 --> Helper loaded: common_helper
INFO - 2018-11-20 11:24:23 --> Database Driver Class Initialized
DEBUG - 2018-11-20 11:24:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-20 11:24:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-20 11:24:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-20 11:24:23 --> Pagination Class Initialized
INFO - 2018-11-20 11:24:23 --> Helper loaded: form_helper
INFO - 2018-11-20 11:24:23 --> Form Validation Class Initialized
INFO - 2018-11-20 11:24:23 --> Model Class Initialized
INFO - 2018-11-20 11:24:23 --> Controller Class Initialized
INFO - 2018-11-20 11:24:23 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-20 11:24:23 --> Model Class Initialized
INFO - 2018-11-20 11:24:23 --> Model Class Initialized
INFO - 2018-11-20 11:24:23 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/index.php
INFO - 2018-11-20 11:24:23 --> Final output sent to browser
DEBUG - 2018-11-20 11:24:23 --> Total execution time: 0.0480
INFO - 2018-11-20 11:24:34 --> Config Class Initialized
INFO - 2018-11-20 11:24:34 --> Hooks Class Initialized
DEBUG - 2018-11-20 11:24:34 --> UTF-8 Support Enabled
INFO - 2018-11-20 11:24:34 --> Utf8 Class Initialized
INFO - 2018-11-20 11:24:34 --> URI Class Initialized
INFO - 2018-11-20 11:24:34 --> Router Class Initialized
INFO - 2018-11-20 11:24:34 --> Output Class Initialized
INFO - 2018-11-20 11:24:34 --> Security Class Initialized
DEBUG - 2018-11-20 11:24:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-20 11:24:34 --> Input Class Initialized
INFO - 2018-11-20 11:24:34 --> Language Class Initialized
INFO - 2018-11-20 11:24:34 --> Loader Class Initialized
INFO - 2018-11-20 11:24:34 --> Helper loaded: url_helper
INFO - 2018-11-20 11:24:34 --> Helper loaded: file_helper
INFO - 2018-11-20 11:24:34 --> Helper loaded: email_helper
INFO - 2018-11-20 11:24:34 --> Helper loaded: common_helper
INFO - 2018-11-20 11:24:34 --> Database Driver Class Initialized
DEBUG - 2018-11-20 11:24:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-20 11:24:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-20 11:24:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-20 11:24:34 --> Pagination Class Initialized
INFO - 2018-11-20 11:24:34 --> Helper loaded: form_helper
INFO - 2018-11-20 11:24:34 --> Form Validation Class Initialized
INFO - 2018-11-20 11:24:34 --> Model Class Initialized
INFO - 2018-11-20 11:24:34 --> Controller Class Initialized
INFO - 2018-11-20 11:24:34 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-20 11:24:34 --> Model Class Initialized
INFO - 2018-11-20 11:24:34 --> Model Class Initialized
INFO - 2018-11-20 11:24:34 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/index.php
INFO - 2018-11-20 11:24:34 --> Final output sent to browser
DEBUG - 2018-11-20 11:24:34 --> Total execution time: 0.0990
INFO - 2018-11-20 11:25:36 --> Config Class Initialized
INFO - 2018-11-20 11:25:36 --> Hooks Class Initialized
DEBUG - 2018-11-20 11:25:36 --> UTF-8 Support Enabled
INFO - 2018-11-20 11:25:36 --> Utf8 Class Initialized
INFO - 2018-11-20 11:25:36 --> URI Class Initialized
INFO - 2018-11-20 11:25:36 --> Router Class Initialized
INFO - 2018-11-20 11:25:36 --> Output Class Initialized
INFO - 2018-11-20 11:25:36 --> Security Class Initialized
DEBUG - 2018-11-20 11:25:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-20 11:25:36 --> Input Class Initialized
INFO - 2018-11-20 11:25:36 --> Language Class Initialized
INFO - 2018-11-20 11:25:36 --> Loader Class Initialized
INFO - 2018-11-20 11:25:36 --> Helper loaded: url_helper
INFO - 2018-11-20 11:25:36 --> Helper loaded: file_helper
INFO - 2018-11-20 11:25:36 --> Helper loaded: email_helper
INFO - 2018-11-20 11:25:36 --> Helper loaded: common_helper
INFO - 2018-11-20 11:25:36 --> Database Driver Class Initialized
DEBUG - 2018-11-20 11:25:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-20 11:25:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-20 11:25:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-20 11:25:36 --> Pagination Class Initialized
INFO - 2018-11-20 11:25:36 --> Helper loaded: form_helper
INFO - 2018-11-20 11:25:36 --> Form Validation Class Initialized
INFO - 2018-11-20 11:25:36 --> Model Class Initialized
INFO - 2018-11-20 11:25:36 --> Controller Class Initialized
INFO - 2018-11-20 11:25:36 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-20 11:25:36 --> Model Class Initialized
INFO - 2018-11-20 11:25:36 --> Model Class Initialized
INFO - 2018-11-20 11:25:36 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/index.php
INFO - 2018-11-20 11:25:36 --> Final output sent to browser
DEBUG - 2018-11-20 11:25:36 --> Total execution time: 0.0640
INFO - 2018-11-20 11:27:16 --> Config Class Initialized
INFO - 2018-11-20 11:27:16 --> Hooks Class Initialized
DEBUG - 2018-11-20 11:27:16 --> UTF-8 Support Enabled
INFO - 2018-11-20 11:27:16 --> Utf8 Class Initialized
INFO - 2018-11-20 11:27:16 --> URI Class Initialized
INFO - 2018-11-20 11:27:16 --> Router Class Initialized
INFO - 2018-11-20 11:27:16 --> Output Class Initialized
INFO - 2018-11-20 11:27:16 --> Security Class Initialized
DEBUG - 2018-11-20 11:27:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-20 11:27:16 --> Input Class Initialized
INFO - 2018-11-20 11:27:16 --> Language Class Initialized
INFO - 2018-11-20 11:27:16 --> Loader Class Initialized
INFO - 2018-11-20 11:27:16 --> Helper loaded: url_helper
INFO - 2018-11-20 11:27:16 --> Helper loaded: file_helper
INFO - 2018-11-20 11:27:16 --> Helper loaded: email_helper
INFO - 2018-11-20 11:27:16 --> Helper loaded: common_helper
INFO - 2018-11-20 11:27:16 --> Database Driver Class Initialized
DEBUG - 2018-11-20 11:27:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-20 11:27:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-20 11:27:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-20 11:27:16 --> Pagination Class Initialized
INFO - 2018-11-20 11:27:16 --> Helper loaded: form_helper
INFO - 2018-11-20 11:27:16 --> Form Validation Class Initialized
INFO - 2018-11-20 11:27:16 --> Model Class Initialized
INFO - 2018-11-20 11:27:16 --> Controller Class Initialized
INFO - 2018-11-20 11:27:16 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-20 11:27:16 --> Model Class Initialized
INFO - 2018-11-20 11:27:16 --> Model Class Initialized
INFO - 2018-11-20 11:27:16 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/index.php
INFO - 2018-11-20 11:27:16 --> Final output sent to browser
DEBUG - 2018-11-20 11:27:16 --> Total execution time: 0.0490
INFO - 2018-11-20 11:27:35 --> Config Class Initialized
INFO - 2018-11-20 11:27:35 --> Hooks Class Initialized
DEBUG - 2018-11-20 11:27:35 --> UTF-8 Support Enabled
INFO - 2018-11-20 11:27:35 --> Utf8 Class Initialized
INFO - 2018-11-20 11:27:35 --> URI Class Initialized
INFO - 2018-11-20 11:27:35 --> Router Class Initialized
INFO - 2018-11-20 11:27:35 --> Output Class Initialized
INFO - 2018-11-20 11:27:35 --> Security Class Initialized
DEBUG - 2018-11-20 11:27:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-20 11:27:35 --> Input Class Initialized
INFO - 2018-11-20 11:27:35 --> Language Class Initialized
INFO - 2018-11-20 11:27:35 --> Loader Class Initialized
INFO - 2018-11-20 11:27:35 --> Helper loaded: url_helper
INFO - 2018-11-20 11:27:35 --> Helper loaded: file_helper
INFO - 2018-11-20 11:27:35 --> Helper loaded: email_helper
INFO - 2018-11-20 11:27:35 --> Helper loaded: common_helper
INFO - 2018-11-20 11:27:35 --> Database Driver Class Initialized
DEBUG - 2018-11-20 11:27:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-20 11:27:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-20 11:27:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-20 11:27:35 --> Pagination Class Initialized
INFO - 2018-11-20 11:27:35 --> Helper loaded: form_helper
INFO - 2018-11-20 11:27:35 --> Form Validation Class Initialized
INFO - 2018-11-20 11:27:35 --> Model Class Initialized
INFO - 2018-11-20 11:27:35 --> Controller Class Initialized
INFO - 2018-11-20 11:27:35 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-20 11:27:35 --> Model Class Initialized
INFO - 2018-11-20 11:27:35 --> Model Class Initialized
INFO - 2018-11-20 11:27:35 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/index.php
INFO - 2018-11-20 11:27:35 --> Final output sent to browser
DEBUG - 2018-11-20 11:27:35 --> Total execution time: 0.1000
INFO - 2018-11-20 11:28:06 --> Config Class Initialized
INFO - 2018-11-20 11:28:06 --> Hooks Class Initialized
DEBUG - 2018-11-20 11:28:06 --> UTF-8 Support Enabled
INFO - 2018-11-20 11:28:06 --> Utf8 Class Initialized
INFO - 2018-11-20 11:28:06 --> URI Class Initialized
INFO - 2018-11-20 11:28:06 --> Router Class Initialized
INFO - 2018-11-20 11:28:06 --> Output Class Initialized
INFO - 2018-11-20 11:28:06 --> Security Class Initialized
DEBUG - 2018-11-20 11:28:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-20 11:28:06 --> Input Class Initialized
INFO - 2018-11-20 11:28:06 --> Language Class Initialized
INFO - 2018-11-20 11:28:06 --> Loader Class Initialized
INFO - 2018-11-20 11:28:06 --> Helper loaded: url_helper
INFO - 2018-11-20 11:28:06 --> Helper loaded: file_helper
INFO - 2018-11-20 11:28:06 --> Helper loaded: email_helper
INFO - 2018-11-20 11:28:06 --> Helper loaded: common_helper
INFO - 2018-11-20 11:28:06 --> Database Driver Class Initialized
DEBUG - 2018-11-20 11:28:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-20 11:28:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-20 11:28:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-20 11:28:06 --> Pagination Class Initialized
INFO - 2018-11-20 11:28:06 --> Helper loaded: form_helper
INFO - 2018-11-20 11:28:06 --> Form Validation Class Initialized
INFO - 2018-11-20 11:28:06 --> Model Class Initialized
INFO - 2018-11-20 11:28:06 --> Controller Class Initialized
INFO - 2018-11-20 11:28:06 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-20 11:28:06 --> Model Class Initialized
INFO - 2018-11-20 11:28:06 --> Model Class Initialized
INFO - 2018-11-20 11:28:06 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/index.php
INFO - 2018-11-20 11:28:06 --> Final output sent to browser
DEBUG - 2018-11-20 11:28:06 --> Total execution time: 0.0520
INFO - 2018-11-20 11:28:10 --> Config Class Initialized
INFO - 2018-11-20 11:28:10 --> Hooks Class Initialized
DEBUG - 2018-11-20 11:28:10 --> UTF-8 Support Enabled
INFO - 2018-11-20 11:28:10 --> Utf8 Class Initialized
INFO - 2018-11-20 11:28:10 --> URI Class Initialized
INFO - 2018-11-20 11:28:10 --> Router Class Initialized
INFO - 2018-11-20 11:28:10 --> Output Class Initialized
INFO - 2018-11-20 11:28:10 --> Security Class Initialized
DEBUG - 2018-11-20 11:28:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-20 11:28:10 --> Input Class Initialized
INFO - 2018-11-20 11:28:10 --> Language Class Initialized
INFO - 2018-11-20 11:28:10 --> Loader Class Initialized
INFO - 2018-11-20 11:28:10 --> Helper loaded: url_helper
INFO - 2018-11-20 11:28:10 --> Helper loaded: file_helper
INFO - 2018-11-20 11:28:10 --> Helper loaded: email_helper
INFO - 2018-11-20 11:28:10 --> Helper loaded: common_helper
INFO - 2018-11-20 11:28:10 --> Database Driver Class Initialized
DEBUG - 2018-11-20 11:28:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-20 11:28:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-20 11:28:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-20 11:28:10 --> Pagination Class Initialized
INFO - 2018-11-20 11:28:10 --> Helper loaded: form_helper
INFO - 2018-11-20 11:28:10 --> Form Validation Class Initialized
INFO - 2018-11-20 11:28:10 --> Model Class Initialized
INFO - 2018-11-20 11:28:10 --> Controller Class Initialized
INFO - 2018-11-20 11:28:10 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-20 11:28:10 --> Model Class Initialized
INFO - 2018-11-20 11:28:10 --> Model Class Initialized
INFO - 2018-11-20 11:28:10 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/index.php
INFO - 2018-11-20 11:28:10 --> Final output sent to browser
DEBUG - 2018-11-20 11:28:10 --> Total execution time: 0.0530
INFO - 2018-11-20 11:28:46 --> Config Class Initialized
INFO - 2018-11-20 11:28:46 --> Hooks Class Initialized
DEBUG - 2018-11-20 11:28:46 --> UTF-8 Support Enabled
INFO - 2018-11-20 11:28:46 --> Utf8 Class Initialized
INFO - 2018-11-20 11:28:46 --> URI Class Initialized
INFO - 2018-11-20 11:28:46 --> Router Class Initialized
INFO - 2018-11-20 11:28:46 --> Output Class Initialized
INFO - 2018-11-20 11:28:46 --> Security Class Initialized
DEBUG - 2018-11-20 11:28:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-20 11:28:46 --> Input Class Initialized
INFO - 2018-11-20 11:28:46 --> Language Class Initialized
INFO - 2018-11-20 11:28:46 --> Loader Class Initialized
INFO - 2018-11-20 11:28:46 --> Helper loaded: url_helper
INFO - 2018-11-20 11:28:46 --> Helper loaded: file_helper
INFO - 2018-11-20 11:28:46 --> Helper loaded: email_helper
INFO - 2018-11-20 11:28:46 --> Helper loaded: common_helper
INFO - 2018-11-20 11:28:46 --> Database Driver Class Initialized
DEBUG - 2018-11-20 11:28:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-20 11:28:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-20 11:28:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-20 11:28:46 --> Pagination Class Initialized
INFO - 2018-11-20 11:28:46 --> Helper loaded: form_helper
INFO - 2018-11-20 11:28:46 --> Form Validation Class Initialized
INFO - 2018-11-20 11:28:46 --> Model Class Initialized
INFO - 2018-11-20 11:28:46 --> Controller Class Initialized
INFO - 2018-11-20 11:28:46 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-20 11:28:46 --> Model Class Initialized
INFO - 2018-11-20 11:28:46 --> Model Class Initialized
ERROR - 2018-11-20 11:28:46 --> Severity: Notice --> Undefined index: remember_me C:\xampp\htdocs\wetinuneed\application\controllers\Admin.php 76
INFO - 2018-11-20 11:28:46 --> Config Class Initialized
INFO - 2018-11-20 11:28:46 --> Hooks Class Initialized
DEBUG - 2018-11-20 11:28:46 --> UTF-8 Support Enabled
INFO - 2018-11-20 11:28:46 --> Utf8 Class Initialized
INFO - 2018-11-20 11:28:46 --> URI Class Initialized
INFO - 2018-11-20 11:28:46 --> Router Class Initialized
INFO - 2018-11-20 11:28:46 --> Output Class Initialized
INFO - 2018-11-20 11:28:46 --> Security Class Initialized
DEBUG - 2018-11-20 11:28:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-20 11:28:46 --> Input Class Initialized
INFO - 2018-11-20 11:28:46 --> Language Class Initialized
INFO - 2018-11-20 11:28:46 --> Loader Class Initialized
INFO - 2018-11-20 11:28:46 --> Helper loaded: url_helper
INFO - 2018-11-20 11:28:46 --> Helper loaded: file_helper
INFO - 2018-11-20 11:28:46 --> Helper loaded: email_helper
INFO - 2018-11-20 11:28:46 --> Helper loaded: common_helper
INFO - 2018-11-20 11:28:46 --> Database Driver Class Initialized
DEBUG - 2018-11-20 11:28:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-20 11:28:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-20 11:28:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-20 11:28:46 --> Pagination Class Initialized
INFO - 2018-11-20 11:28:46 --> Helper loaded: form_helper
INFO - 2018-11-20 11:28:46 --> Form Validation Class Initialized
INFO - 2018-11-20 11:28:46 --> Model Class Initialized
INFO - 2018-11-20 11:28:46 --> Controller Class Initialized
INFO - 2018-11-20 11:28:46 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-20 11:28:46 --> Model Class Initialized
INFO - 2018-11-20 11:28:46 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
ERROR - 2018-11-20 11:28:46 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string C:\xampp\htdocs\wetinuneed\application\views\admin\dashboard.php 12
INFO - 2018-11-20 11:28:46 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/dashboard.php
INFO - 2018-11-20 11:28:46 --> Final output sent to browser
DEBUG - 2018-11-20 11:28:46 --> Total execution time: 0.0420
INFO - 2018-11-20 11:28:51 --> Config Class Initialized
INFO - 2018-11-20 11:28:51 --> Hooks Class Initialized
DEBUG - 2018-11-20 11:28:51 --> UTF-8 Support Enabled
INFO - 2018-11-20 11:28:51 --> Utf8 Class Initialized
INFO - 2018-11-20 11:28:51 --> URI Class Initialized
INFO - 2018-11-20 11:28:51 --> Router Class Initialized
INFO - 2018-11-20 11:28:51 --> Output Class Initialized
INFO - 2018-11-20 11:28:51 --> Security Class Initialized
DEBUG - 2018-11-20 11:28:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-20 11:28:51 --> Input Class Initialized
INFO - 2018-11-20 11:28:51 --> Language Class Initialized
INFO - 2018-11-20 11:28:51 --> Loader Class Initialized
INFO - 2018-11-20 11:28:51 --> Helper loaded: url_helper
INFO - 2018-11-20 11:28:51 --> Helper loaded: file_helper
INFO - 2018-11-20 11:28:51 --> Helper loaded: email_helper
INFO - 2018-11-20 11:28:51 --> Helper loaded: common_helper
INFO - 2018-11-20 11:28:51 --> Database Driver Class Initialized
DEBUG - 2018-11-20 11:28:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-20 11:28:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-20 11:28:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-20 11:28:51 --> Pagination Class Initialized
INFO - 2018-11-20 11:28:51 --> Helper loaded: form_helper
INFO - 2018-11-20 11:28:51 --> Form Validation Class Initialized
INFO - 2018-11-20 11:28:51 --> Model Class Initialized
INFO - 2018-11-20 11:28:51 --> Controller Class Initialized
INFO - 2018-11-20 11:28:51 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-20 11:28:51 --> Model Class Initialized
INFO - 2018-11-20 11:28:51 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
ERROR - 2018-11-20 11:28:51 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string C:\xampp\htdocs\wetinuneed\application\views\admin\dashboard.php 12
INFO - 2018-11-20 11:28:51 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/dashboard.php
INFO - 2018-11-20 11:28:51 --> Final output sent to browser
DEBUG - 2018-11-20 11:28:51 --> Total execution time: 0.0500
INFO - 2018-11-20 11:29:20 --> Config Class Initialized
INFO - 2018-11-20 11:29:20 --> Hooks Class Initialized
DEBUG - 2018-11-20 11:29:20 --> UTF-8 Support Enabled
INFO - 2018-11-20 11:29:20 --> Utf8 Class Initialized
INFO - 2018-11-20 11:29:20 --> URI Class Initialized
INFO - 2018-11-20 11:29:20 --> Router Class Initialized
INFO - 2018-11-20 11:29:20 --> Output Class Initialized
INFO - 2018-11-20 11:29:20 --> Security Class Initialized
DEBUG - 2018-11-20 11:29:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-20 11:29:20 --> Input Class Initialized
INFO - 2018-11-20 11:29:20 --> Language Class Initialized
INFO - 2018-11-20 11:29:20 --> Loader Class Initialized
INFO - 2018-11-20 11:29:20 --> Helper loaded: url_helper
INFO - 2018-11-20 11:29:20 --> Helper loaded: file_helper
INFO - 2018-11-20 11:29:20 --> Helper loaded: email_helper
INFO - 2018-11-20 11:29:20 --> Helper loaded: common_helper
INFO - 2018-11-20 11:29:20 --> Database Driver Class Initialized
DEBUG - 2018-11-20 11:29:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-20 11:29:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-20 11:29:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-20 11:29:20 --> Pagination Class Initialized
INFO - 2018-11-20 11:29:20 --> Helper loaded: form_helper
INFO - 2018-11-20 11:29:20 --> Form Validation Class Initialized
INFO - 2018-11-20 11:29:20 --> Model Class Initialized
INFO - 2018-11-20 11:29:20 --> Controller Class Initialized
INFO - 2018-11-20 11:29:20 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-20 11:29:20 --> Model Class Initialized
INFO - 2018-11-20 11:29:20 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-20 11:29:20 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/dashboard.php
INFO - 2018-11-20 11:29:20 --> Final output sent to browser
DEBUG - 2018-11-20 11:29:20 --> Total execution time: 0.0570
INFO - 2018-11-20 11:30:41 --> Config Class Initialized
INFO - 2018-11-20 11:30:41 --> Hooks Class Initialized
DEBUG - 2018-11-20 11:30:41 --> UTF-8 Support Enabled
INFO - 2018-11-20 11:30:41 --> Utf8 Class Initialized
INFO - 2018-11-20 11:30:41 --> URI Class Initialized
INFO - 2018-11-20 11:30:41 --> Router Class Initialized
INFO - 2018-11-20 11:30:41 --> Output Class Initialized
INFO - 2018-11-20 11:30:41 --> Security Class Initialized
DEBUG - 2018-11-20 11:30:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-20 11:30:41 --> Input Class Initialized
INFO - 2018-11-20 11:30:41 --> Language Class Initialized
INFO - 2018-11-20 11:30:41 --> Loader Class Initialized
INFO - 2018-11-20 11:30:41 --> Helper loaded: url_helper
INFO - 2018-11-20 11:30:41 --> Helper loaded: file_helper
INFO - 2018-11-20 11:30:41 --> Helper loaded: email_helper
INFO - 2018-11-20 11:30:41 --> Helper loaded: common_helper
INFO - 2018-11-20 11:30:41 --> Database Driver Class Initialized
DEBUG - 2018-11-20 11:30:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-20 11:30:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-20 11:30:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-20 11:30:41 --> Pagination Class Initialized
INFO - 2018-11-20 11:30:41 --> Helper loaded: form_helper
INFO - 2018-11-20 11:30:41 --> Form Validation Class Initialized
INFO - 2018-11-20 11:30:41 --> Model Class Initialized
INFO - 2018-11-20 11:30:41 --> Controller Class Initialized
INFO - 2018-11-20 11:30:41 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-20 11:30:41 --> Model Class Initialized
INFO - 2018-11-20 11:30:41 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-20 11:30:41 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/sidebar.php
INFO - 2018-11-20 11:30:41 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/dashboard.php
INFO - 2018-11-20 11:30:41 --> Final output sent to browser
DEBUG - 2018-11-20 11:30:41 --> Total execution time: 0.0490
INFO - 2018-11-20 11:30:59 --> Config Class Initialized
INFO - 2018-11-20 11:30:59 --> Hooks Class Initialized
DEBUG - 2018-11-20 11:30:59 --> UTF-8 Support Enabled
INFO - 2018-11-20 11:30:59 --> Utf8 Class Initialized
INFO - 2018-11-20 11:30:59 --> URI Class Initialized
INFO - 2018-11-20 11:30:59 --> Router Class Initialized
INFO - 2018-11-20 11:30:59 --> Output Class Initialized
INFO - 2018-11-20 11:30:59 --> Security Class Initialized
DEBUG - 2018-11-20 11:30:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-20 11:30:59 --> Input Class Initialized
INFO - 2018-11-20 11:30:59 --> Language Class Initialized
INFO - 2018-11-20 11:30:59 --> Loader Class Initialized
INFO - 2018-11-20 11:30:59 --> Helper loaded: url_helper
INFO - 2018-11-20 11:30:59 --> Helper loaded: file_helper
INFO - 2018-11-20 11:30:59 --> Helper loaded: email_helper
INFO - 2018-11-20 11:30:59 --> Helper loaded: common_helper
INFO - 2018-11-20 11:30:59 --> Database Driver Class Initialized
DEBUG - 2018-11-20 11:30:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-20 11:30:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-20 11:30:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-20 11:30:59 --> Pagination Class Initialized
INFO - 2018-11-20 11:30:59 --> Helper loaded: form_helper
INFO - 2018-11-20 11:30:59 --> Form Validation Class Initialized
INFO - 2018-11-20 11:30:59 --> Model Class Initialized
INFO - 2018-11-20 11:30:59 --> Controller Class Initialized
INFO - 2018-11-20 11:30:59 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-20 11:30:59 --> Model Class Initialized
INFO - 2018-11-20 11:30:59 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-20 11:30:59 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/sidebar.php
INFO - 2018-11-20 11:30:59 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/dashboard.php
INFO - 2018-11-20 11:30:59 --> Final output sent to browser
DEBUG - 2018-11-20 11:30:59 --> Total execution time: 0.0580
INFO - 2018-11-20 11:31:26 --> Config Class Initialized
INFO - 2018-11-20 11:31:26 --> Hooks Class Initialized
DEBUG - 2018-11-20 11:31:26 --> UTF-8 Support Enabled
INFO - 2018-11-20 11:31:26 --> Utf8 Class Initialized
INFO - 2018-11-20 11:31:26 --> URI Class Initialized
INFO - 2018-11-20 11:31:26 --> Router Class Initialized
INFO - 2018-11-20 11:31:26 --> Output Class Initialized
INFO - 2018-11-20 11:31:26 --> Security Class Initialized
DEBUG - 2018-11-20 11:31:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-20 11:31:26 --> Input Class Initialized
INFO - 2018-11-20 11:31:26 --> Language Class Initialized
INFO - 2018-11-20 11:31:26 --> Loader Class Initialized
INFO - 2018-11-20 11:31:26 --> Helper loaded: url_helper
INFO - 2018-11-20 11:31:26 --> Helper loaded: file_helper
INFO - 2018-11-20 11:31:26 --> Helper loaded: email_helper
INFO - 2018-11-20 11:31:26 --> Helper loaded: common_helper
INFO - 2018-11-20 11:31:26 --> Database Driver Class Initialized
DEBUG - 2018-11-20 11:31:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-20 11:31:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-20 11:31:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-20 11:31:26 --> Pagination Class Initialized
INFO - 2018-11-20 11:31:26 --> Helper loaded: form_helper
INFO - 2018-11-20 11:31:26 --> Form Validation Class Initialized
INFO - 2018-11-20 11:31:26 --> Model Class Initialized
INFO - 2018-11-20 11:31:26 --> Controller Class Initialized
INFO - 2018-11-20 11:31:26 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-20 11:31:26 --> Model Class Initialized
INFO - 2018-11-20 11:31:26 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-20 11:31:26 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/sidebar.php
INFO - 2018-11-20 11:31:26 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/dashboard.php
INFO - 2018-11-20 11:31:26 --> Final output sent to browser
DEBUG - 2018-11-20 11:31:26 --> Total execution time: 0.0430
INFO - 2018-11-20 11:31:54 --> Config Class Initialized
INFO - 2018-11-20 11:31:54 --> Hooks Class Initialized
DEBUG - 2018-11-20 11:31:54 --> UTF-8 Support Enabled
INFO - 2018-11-20 11:31:54 --> Utf8 Class Initialized
INFO - 2018-11-20 11:31:54 --> URI Class Initialized
INFO - 2018-11-20 11:31:54 --> Router Class Initialized
INFO - 2018-11-20 11:31:54 --> Output Class Initialized
INFO - 2018-11-20 11:31:54 --> Security Class Initialized
DEBUG - 2018-11-20 11:31:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-20 11:31:54 --> Input Class Initialized
INFO - 2018-11-20 11:31:54 --> Language Class Initialized
INFO - 2018-11-20 11:31:54 --> Loader Class Initialized
INFO - 2018-11-20 11:31:54 --> Helper loaded: url_helper
INFO - 2018-11-20 11:31:54 --> Helper loaded: file_helper
INFO - 2018-11-20 11:31:54 --> Helper loaded: email_helper
INFO - 2018-11-20 11:31:54 --> Helper loaded: common_helper
INFO - 2018-11-20 11:31:54 --> Database Driver Class Initialized
DEBUG - 2018-11-20 11:31:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-20 11:31:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-20 11:31:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-20 11:31:54 --> Pagination Class Initialized
INFO - 2018-11-20 11:31:54 --> Helper loaded: form_helper
INFO - 2018-11-20 11:31:54 --> Form Validation Class Initialized
INFO - 2018-11-20 11:31:54 --> Model Class Initialized
INFO - 2018-11-20 11:31:54 --> Controller Class Initialized
INFO - 2018-11-20 11:31:54 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-20 11:31:54 --> Model Class Initialized
INFO - 2018-11-20 11:31:54 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-20 11:31:54 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/sidebar.php
INFO - 2018-11-20 11:31:54 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/dashboard.php
INFO - 2018-11-20 11:31:54 --> Final output sent to browser
DEBUG - 2018-11-20 11:31:54 --> Total execution time: 0.0610
INFO - 2018-11-20 11:35:49 --> Config Class Initialized
INFO - 2018-11-20 11:35:49 --> Hooks Class Initialized
DEBUG - 2018-11-20 11:35:49 --> UTF-8 Support Enabled
INFO - 2018-11-20 11:35:49 --> Utf8 Class Initialized
INFO - 2018-11-20 11:35:49 --> URI Class Initialized
INFO - 2018-11-20 11:35:49 --> Router Class Initialized
INFO - 2018-11-20 11:35:49 --> Output Class Initialized
INFO - 2018-11-20 11:35:49 --> Security Class Initialized
DEBUG - 2018-11-20 11:35:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-20 11:35:49 --> Input Class Initialized
INFO - 2018-11-20 11:35:49 --> Language Class Initialized
INFO - 2018-11-20 11:35:49 --> Loader Class Initialized
INFO - 2018-11-20 11:35:49 --> Helper loaded: url_helper
INFO - 2018-11-20 11:35:49 --> Helper loaded: file_helper
INFO - 2018-11-20 11:35:49 --> Helper loaded: email_helper
INFO - 2018-11-20 11:35:49 --> Helper loaded: common_helper
INFO - 2018-11-20 11:35:49 --> Database Driver Class Initialized
DEBUG - 2018-11-20 11:35:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-20 11:35:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-20 11:35:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-20 11:35:49 --> Pagination Class Initialized
INFO - 2018-11-20 11:35:49 --> Helper loaded: form_helper
INFO - 2018-11-20 11:35:49 --> Form Validation Class Initialized
INFO - 2018-11-20 11:35:49 --> Model Class Initialized
INFO - 2018-11-20 11:35:49 --> Controller Class Initialized
INFO - 2018-11-20 11:35:49 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-20 11:35:49 --> Model Class Initialized
INFO - 2018-11-20 11:35:49 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-20 11:35:49 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/sidebar.php
INFO - 2018-11-20 11:35:49 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/dashboard.php
INFO - 2018-11-20 11:35:49 --> Final output sent to browser
DEBUG - 2018-11-20 11:35:49 --> Total execution time: 0.0600
INFO - 2018-11-20 11:36:30 --> Config Class Initialized
INFO - 2018-11-20 11:36:30 --> Hooks Class Initialized
DEBUG - 2018-11-20 11:36:30 --> UTF-8 Support Enabled
INFO - 2018-11-20 11:36:30 --> Utf8 Class Initialized
INFO - 2018-11-20 11:36:30 --> URI Class Initialized
INFO - 2018-11-20 11:36:30 --> Router Class Initialized
INFO - 2018-11-20 11:36:30 --> Output Class Initialized
INFO - 2018-11-20 11:36:30 --> Security Class Initialized
DEBUG - 2018-11-20 11:36:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-20 11:36:30 --> Input Class Initialized
INFO - 2018-11-20 11:36:30 --> Language Class Initialized
INFO - 2018-11-20 11:36:30 --> Loader Class Initialized
INFO - 2018-11-20 11:36:30 --> Helper loaded: url_helper
INFO - 2018-11-20 11:36:30 --> Helper loaded: file_helper
INFO - 2018-11-20 11:36:30 --> Helper loaded: email_helper
INFO - 2018-11-20 11:36:30 --> Helper loaded: common_helper
INFO - 2018-11-20 11:36:30 --> Database Driver Class Initialized
DEBUG - 2018-11-20 11:36:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-20 11:36:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-20 11:36:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-20 11:36:30 --> Pagination Class Initialized
INFO - 2018-11-20 11:36:30 --> Helper loaded: form_helper
INFO - 2018-11-20 11:36:30 --> Form Validation Class Initialized
INFO - 2018-11-20 11:36:30 --> Model Class Initialized
INFO - 2018-11-20 11:36:30 --> Controller Class Initialized
INFO - 2018-11-20 11:36:30 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-20 11:36:30 --> Model Class Initialized
INFO - 2018-11-20 11:36:30 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-20 11:36:30 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/sidebar.php
INFO - 2018-11-20 11:36:30 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/dashboard.php
INFO - 2018-11-20 11:36:30 --> Final output sent to browser
DEBUG - 2018-11-20 11:36:30 --> Total execution time: 0.0570
INFO - 2018-11-20 11:38:16 --> Config Class Initialized
INFO - 2018-11-20 11:38:16 --> Hooks Class Initialized
DEBUG - 2018-11-20 11:38:16 --> UTF-8 Support Enabled
INFO - 2018-11-20 11:38:16 --> Utf8 Class Initialized
INFO - 2018-11-20 11:38:16 --> URI Class Initialized
INFO - 2018-11-20 11:38:16 --> Router Class Initialized
INFO - 2018-11-20 11:38:16 --> Output Class Initialized
INFO - 2018-11-20 11:38:16 --> Security Class Initialized
DEBUG - 2018-11-20 11:38:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-20 11:38:16 --> Input Class Initialized
INFO - 2018-11-20 11:38:16 --> Language Class Initialized
INFO - 2018-11-20 11:38:16 --> Loader Class Initialized
INFO - 2018-11-20 11:38:16 --> Helper loaded: url_helper
INFO - 2018-11-20 11:38:16 --> Helper loaded: file_helper
INFO - 2018-11-20 11:38:16 --> Helper loaded: email_helper
INFO - 2018-11-20 11:38:16 --> Helper loaded: common_helper
INFO - 2018-11-20 11:38:16 --> Database Driver Class Initialized
DEBUG - 2018-11-20 11:38:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-20 11:38:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-20 11:38:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-20 11:38:16 --> Pagination Class Initialized
INFO - 2018-11-20 11:38:16 --> Helper loaded: form_helper
INFO - 2018-11-20 11:38:16 --> Form Validation Class Initialized
INFO - 2018-11-20 11:38:16 --> Model Class Initialized
INFO - 2018-11-20 11:38:16 --> Controller Class Initialized
INFO - 2018-11-20 11:38:16 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-20 11:38:16 --> Model Class Initialized
INFO - 2018-11-20 11:38:16 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-20 11:38:16 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/sidebar.php
INFO - 2018-11-20 11:38:16 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/dashboard.php
INFO - 2018-11-20 11:38:16 --> Final output sent to browser
DEBUG - 2018-11-20 11:38:16 --> Total execution time: 0.0590
INFO - 2018-11-20 11:40:27 --> Config Class Initialized
INFO - 2018-11-20 11:40:27 --> Hooks Class Initialized
DEBUG - 2018-11-20 11:40:27 --> UTF-8 Support Enabled
INFO - 2018-11-20 11:40:27 --> Utf8 Class Initialized
INFO - 2018-11-20 11:40:27 --> URI Class Initialized
INFO - 2018-11-20 11:40:27 --> Router Class Initialized
INFO - 2018-11-20 11:40:27 --> Output Class Initialized
INFO - 2018-11-20 11:40:27 --> Security Class Initialized
DEBUG - 2018-11-20 11:40:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-20 11:40:27 --> Input Class Initialized
INFO - 2018-11-20 11:40:27 --> Language Class Initialized
ERROR - 2018-11-20 11:40:27 --> 404 Page Not Found: Starter-pagehtml/index
INFO - 2018-11-20 11:40:29 --> Config Class Initialized
INFO - 2018-11-20 11:40:29 --> Hooks Class Initialized
DEBUG - 2018-11-20 11:40:29 --> UTF-8 Support Enabled
INFO - 2018-11-20 11:40:29 --> Utf8 Class Initialized
INFO - 2018-11-20 11:40:29 --> URI Class Initialized
INFO - 2018-11-20 11:40:29 --> Router Class Initialized
INFO - 2018-11-20 11:40:29 --> Output Class Initialized
INFO - 2018-11-20 11:40:29 --> Security Class Initialized
DEBUG - 2018-11-20 11:40:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-20 11:40:29 --> Input Class Initialized
INFO - 2018-11-20 11:40:29 --> Language Class Initialized
INFO - 2018-11-20 11:40:29 --> Loader Class Initialized
INFO - 2018-11-20 11:40:29 --> Helper loaded: url_helper
INFO - 2018-11-20 11:40:29 --> Helper loaded: file_helper
INFO - 2018-11-20 11:40:29 --> Helper loaded: email_helper
INFO - 2018-11-20 11:40:29 --> Helper loaded: common_helper
INFO - 2018-11-20 11:40:29 --> Database Driver Class Initialized
DEBUG - 2018-11-20 11:40:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-20 11:40:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-20 11:40:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-20 11:40:29 --> Pagination Class Initialized
INFO - 2018-11-20 11:40:29 --> Helper loaded: form_helper
INFO - 2018-11-20 11:40:29 --> Form Validation Class Initialized
INFO - 2018-11-20 11:40:29 --> Model Class Initialized
INFO - 2018-11-20 11:40:29 --> Controller Class Initialized
INFO - 2018-11-20 11:40:29 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-20 11:40:29 --> Model Class Initialized
INFO - 2018-11-20 11:40:29 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-20 11:40:29 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/sidebar.php
INFO - 2018-11-20 11:40:29 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/dashboard.php
INFO - 2018-11-20 11:40:29 --> Final output sent to browser
DEBUG - 2018-11-20 11:40:29 --> Total execution time: 0.0590
INFO - 2018-11-20 11:43:36 --> Config Class Initialized
INFO - 2018-11-20 11:43:36 --> Hooks Class Initialized
DEBUG - 2018-11-20 11:43:36 --> UTF-8 Support Enabled
INFO - 2018-11-20 11:43:36 --> Utf8 Class Initialized
INFO - 2018-11-20 11:43:36 --> URI Class Initialized
INFO - 2018-11-20 11:43:36 --> Router Class Initialized
INFO - 2018-11-20 11:43:36 --> Output Class Initialized
INFO - 2018-11-20 11:43:36 --> Security Class Initialized
DEBUG - 2018-11-20 11:43:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-20 11:43:36 --> Input Class Initialized
INFO - 2018-11-20 11:43:36 --> Language Class Initialized
INFO - 2018-11-20 11:43:36 --> Loader Class Initialized
INFO - 2018-11-20 11:43:36 --> Helper loaded: url_helper
INFO - 2018-11-20 11:43:36 --> Helper loaded: file_helper
INFO - 2018-11-20 11:43:36 --> Helper loaded: email_helper
INFO - 2018-11-20 11:43:36 --> Helper loaded: common_helper
INFO - 2018-11-20 11:43:36 --> Database Driver Class Initialized
DEBUG - 2018-11-20 11:43:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-20 11:43:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-20 11:43:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-20 11:43:36 --> Pagination Class Initialized
INFO - 2018-11-20 11:43:36 --> Helper loaded: form_helper
INFO - 2018-11-20 11:43:36 --> Form Validation Class Initialized
INFO - 2018-11-20 11:43:36 --> Model Class Initialized
INFO - 2018-11-20 11:43:36 --> Controller Class Initialized
INFO - 2018-11-20 11:43:36 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-20 11:43:36 --> Model Class Initialized
INFO - 2018-11-20 11:43:36 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-20 11:43:36 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/sidebar.php
INFO - 2018-11-20 11:43:36 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/dashboard.php
INFO - 2018-11-20 11:43:36 --> Final output sent to browser
DEBUG - 2018-11-20 11:43:36 --> Total execution time: 0.0610
INFO - 2018-11-20 11:43:53 --> Config Class Initialized
INFO - 2018-11-20 11:43:53 --> Hooks Class Initialized
DEBUG - 2018-11-20 11:43:53 --> UTF-8 Support Enabled
INFO - 2018-11-20 11:43:53 --> Utf8 Class Initialized
INFO - 2018-11-20 11:43:53 --> URI Class Initialized
INFO - 2018-11-20 11:43:53 --> Router Class Initialized
INFO - 2018-11-20 11:43:53 --> Output Class Initialized
INFO - 2018-11-20 11:43:53 --> Security Class Initialized
DEBUG - 2018-11-20 11:43:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-20 11:43:53 --> Input Class Initialized
INFO - 2018-11-20 11:43:53 --> Language Class Initialized
ERROR - 2018-11-20 11:43:53 --> 404 Page Not Found: Starter-pagehtml/index
INFO - 2018-11-20 11:43:55 --> Config Class Initialized
INFO - 2018-11-20 11:43:55 --> Hooks Class Initialized
DEBUG - 2018-11-20 11:43:55 --> UTF-8 Support Enabled
INFO - 2018-11-20 11:43:55 --> Utf8 Class Initialized
INFO - 2018-11-20 11:43:55 --> URI Class Initialized
INFO - 2018-11-20 11:43:55 --> Router Class Initialized
INFO - 2018-11-20 11:43:55 --> Output Class Initialized
INFO - 2018-11-20 11:43:55 --> Security Class Initialized
DEBUG - 2018-11-20 11:43:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-20 11:43:55 --> Input Class Initialized
INFO - 2018-11-20 11:43:55 --> Language Class Initialized
INFO - 2018-11-20 11:43:55 --> Loader Class Initialized
INFO - 2018-11-20 11:43:55 --> Helper loaded: url_helper
INFO - 2018-11-20 11:43:55 --> Helper loaded: file_helper
INFO - 2018-11-20 11:43:55 --> Helper loaded: email_helper
INFO - 2018-11-20 11:43:55 --> Helper loaded: common_helper
INFO - 2018-11-20 11:43:55 --> Database Driver Class Initialized
DEBUG - 2018-11-20 11:43:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-20 11:43:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-20 11:43:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-20 11:43:55 --> Pagination Class Initialized
INFO - 2018-11-20 11:43:55 --> Helper loaded: form_helper
INFO - 2018-11-20 11:43:55 --> Form Validation Class Initialized
INFO - 2018-11-20 11:43:55 --> Model Class Initialized
INFO - 2018-11-20 11:43:55 --> Controller Class Initialized
INFO - 2018-11-20 11:43:55 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-20 11:43:55 --> Model Class Initialized
INFO - 2018-11-20 11:43:55 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-20 11:43:55 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/sidebar.php
INFO - 2018-11-20 11:43:55 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/dashboard.php
INFO - 2018-11-20 11:43:55 --> Final output sent to browser
DEBUG - 2018-11-20 11:43:55 --> Total execution time: 0.0550
INFO - 2018-11-20 11:45:24 --> Config Class Initialized
INFO - 2018-11-20 11:45:24 --> Hooks Class Initialized
DEBUG - 2018-11-20 11:45:24 --> UTF-8 Support Enabled
INFO - 2018-11-20 11:45:24 --> Utf8 Class Initialized
INFO - 2018-11-20 11:45:24 --> URI Class Initialized
INFO - 2018-11-20 11:45:24 --> Router Class Initialized
INFO - 2018-11-20 11:45:24 --> Output Class Initialized
INFO - 2018-11-20 11:45:24 --> Security Class Initialized
DEBUG - 2018-11-20 11:45:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-20 11:45:24 --> Input Class Initialized
INFO - 2018-11-20 11:45:24 --> Language Class Initialized
INFO - 2018-11-20 11:45:24 --> Loader Class Initialized
INFO - 2018-11-20 11:45:24 --> Helper loaded: url_helper
INFO - 2018-11-20 11:45:24 --> Helper loaded: file_helper
INFO - 2018-11-20 11:45:24 --> Helper loaded: email_helper
INFO - 2018-11-20 11:45:24 --> Helper loaded: common_helper
INFO - 2018-11-20 11:45:24 --> Database Driver Class Initialized
DEBUG - 2018-11-20 11:45:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-20 11:45:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-20 11:45:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-20 11:45:24 --> Pagination Class Initialized
INFO - 2018-11-20 11:45:24 --> Helper loaded: form_helper
INFO - 2018-11-20 11:45:24 --> Form Validation Class Initialized
INFO - 2018-11-20 11:45:24 --> Model Class Initialized
INFO - 2018-11-20 11:45:24 --> Controller Class Initialized
INFO - 2018-11-20 11:45:24 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-20 11:45:24 --> Model Class Initialized
INFO - 2018-11-20 11:45:24 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-20 11:45:24 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/sidebar.php
INFO - 2018-11-20 11:45:24 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/dashboard.php
INFO - 2018-11-20 11:45:24 --> Final output sent to browser
DEBUG - 2018-11-20 11:45:24 --> Total execution time: 0.0680
INFO - 2018-11-20 11:47:16 --> Config Class Initialized
INFO - 2018-11-20 11:47:16 --> Hooks Class Initialized
DEBUG - 2018-11-20 11:47:16 --> UTF-8 Support Enabled
INFO - 2018-11-20 11:47:16 --> Utf8 Class Initialized
INFO - 2018-11-20 11:47:16 --> URI Class Initialized
INFO - 2018-11-20 11:47:16 --> Router Class Initialized
INFO - 2018-11-20 11:47:16 --> Output Class Initialized
INFO - 2018-11-20 11:47:16 --> Security Class Initialized
DEBUG - 2018-11-20 11:47:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-20 11:47:16 --> Input Class Initialized
INFO - 2018-11-20 11:47:16 --> Language Class Initialized
ERROR - 2018-11-20 11:47:16 --> 404 Page Not Found: Indexhtml/index
INFO - 2018-11-20 11:47:18 --> Config Class Initialized
INFO - 2018-11-20 11:47:18 --> Hooks Class Initialized
DEBUG - 2018-11-20 11:47:18 --> UTF-8 Support Enabled
INFO - 2018-11-20 11:47:18 --> Utf8 Class Initialized
INFO - 2018-11-20 11:47:18 --> URI Class Initialized
INFO - 2018-11-20 11:47:18 --> Router Class Initialized
INFO - 2018-11-20 11:47:18 --> Output Class Initialized
INFO - 2018-11-20 11:47:18 --> Security Class Initialized
DEBUG - 2018-11-20 11:47:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-20 11:47:18 --> Input Class Initialized
INFO - 2018-11-20 11:47:18 --> Language Class Initialized
INFO - 2018-11-20 11:47:18 --> Loader Class Initialized
INFO - 2018-11-20 11:47:18 --> Helper loaded: url_helper
INFO - 2018-11-20 11:47:18 --> Helper loaded: file_helper
INFO - 2018-11-20 11:47:18 --> Helper loaded: email_helper
INFO - 2018-11-20 11:47:18 --> Helper loaded: common_helper
INFO - 2018-11-20 11:47:18 --> Database Driver Class Initialized
DEBUG - 2018-11-20 11:47:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-20 11:47:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-20 11:47:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-20 11:47:18 --> Pagination Class Initialized
INFO - 2018-11-20 11:47:18 --> Helper loaded: form_helper
INFO - 2018-11-20 11:47:18 --> Form Validation Class Initialized
INFO - 2018-11-20 11:47:18 --> Model Class Initialized
INFO - 2018-11-20 11:47:18 --> Controller Class Initialized
INFO - 2018-11-20 11:47:18 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-20 11:47:18 --> Model Class Initialized
INFO - 2018-11-20 11:47:18 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-20 11:47:18 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/sidebar.php
INFO - 2018-11-20 11:47:18 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/dashboard.php
INFO - 2018-11-20 11:47:18 --> Final output sent to browser
DEBUG - 2018-11-20 11:47:18 --> Total execution time: 0.0570
INFO - 2018-11-20 11:48:30 --> Config Class Initialized
INFO - 2018-11-20 11:48:30 --> Hooks Class Initialized
DEBUG - 2018-11-20 11:48:30 --> UTF-8 Support Enabled
INFO - 2018-11-20 11:48:30 --> Utf8 Class Initialized
INFO - 2018-11-20 11:48:30 --> URI Class Initialized
INFO - 2018-11-20 11:48:30 --> Router Class Initialized
INFO - 2018-11-20 11:48:30 --> Output Class Initialized
INFO - 2018-11-20 11:48:30 --> Security Class Initialized
DEBUG - 2018-11-20 11:48:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-20 11:48:30 --> Input Class Initialized
INFO - 2018-11-20 11:48:30 --> Language Class Initialized
INFO - 2018-11-20 11:48:30 --> Loader Class Initialized
INFO - 2018-11-20 11:48:30 --> Helper loaded: url_helper
INFO - 2018-11-20 11:48:30 --> Helper loaded: file_helper
INFO - 2018-11-20 11:48:30 --> Helper loaded: email_helper
INFO - 2018-11-20 11:48:30 --> Helper loaded: common_helper
INFO - 2018-11-20 11:48:30 --> Database Driver Class Initialized
DEBUG - 2018-11-20 11:48:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-20 11:48:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-20 11:48:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-20 11:48:30 --> Pagination Class Initialized
INFO - 2018-11-20 11:48:30 --> Helper loaded: form_helper
INFO - 2018-11-20 11:48:30 --> Form Validation Class Initialized
INFO - 2018-11-20 11:48:30 --> Model Class Initialized
INFO - 2018-11-20 11:48:30 --> Controller Class Initialized
INFO - 2018-11-20 11:48:30 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-20 11:48:30 --> Model Class Initialized
INFO - 2018-11-20 11:48:30 --> Model Class Initialized
INFO - 2018-11-20 11:48:30 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/index.php
INFO - 2018-11-20 11:48:30 --> Final output sent to browser
DEBUG - 2018-11-20 11:48:30 --> Total execution time: 0.0560
INFO - 2018-11-20 11:48:36 --> Config Class Initialized
INFO - 2018-11-20 11:48:36 --> Hooks Class Initialized
DEBUG - 2018-11-20 11:48:36 --> UTF-8 Support Enabled
INFO - 2018-11-20 11:48:36 --> Utf8 Class Initialized
INFO - 2018-11-20 11:48:36 --> URI Class Initialized
INFO - 2018-11-20 11:48:36 --> Router Class Initialized
INFO - 2018-11-20 11:48:36 --> Output Class Initialized
INFO - 2018-11-20 11:48:36 --> Security Class Initialized
DEBUG - 2018-11-20 11:48:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-20 11:48:36 --> Input Class Initialized
INFO - 2018-11-20 11:48:36 --> Language Class Initialized
INFO - 2018-11-20 11:48:36 --> Loader Class Initialized
INFO - 2018-11-20 11:48:36 --> Helper loaded: url_helper
INFO - 2018-11-20 11:48:36 --> Helper loaded: file_helper
INFO - 2018-11-20 11:48:36 --> Helper loaded: email_helper
INFO - 2018-11-20 11:48:36 --> Helper loaded: common_helper
INFO - 2018-11-20 11:48:36 --> Database Driver Class Initialized
DEBUG - 2018-11-20 11:48:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-20 11:48:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-20 11:48:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-20 11:48:36 --> Pagination Class Initialized
INFO - 2018-11-20 11:48:36 --> Helper loaded: form_helper
INFO - 2018-11-20 11:48:36 --> Form Validation Class Initialized
INFO - 2018-11-20 11:48:36 --> Model Class Initialized
INFO - 2018-11-20 11:48:36 --> Controller Class Initialized
INFO - 2018-11-20 11:48:36 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-20 11:48:36 --> Model Class Initialized
INFO - 2018-11-20 11:48:36 --> Model Class Initialized
ERROR - 2018-11-20 11:48:36 --> Severity: Notice --> Undefined index: remember_me C:\xampp\htdocs\wetinuneed\application\controllers\Admin.php 76
INFO - 2018-11-20 11:48:36 --> Config Class Initialized
INFO - 2018-11-20 11:48:36 --> Hooks Class Initialized
DEBUG - 2018-11-20 11:48:36 --> UTF-8 Support Enabled
INFO - 2018-11-20 11:48:36 --> Utf8 Class Initialized
INFO - 2018-11-20 11:48:36 --> URI Class Initialized
INFO - 2018-11-20 11:48:36 --> Router Class Initialized
INFO - 2018-11-20 11:48:36 --> Output Class Initialized
INFO - 2018-11-20 11:48:36 --> Security Class Initialized
DEBUG - 2018-11-20 11:48:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-20 11:48:36 --> Input Class Initialized
INFO - 2018-11-20 11:48:36 --> Language Class Initialized
INFO - 2018-11-20 11:48:36 --> Loader Class Initialized
INFO - 2018-11-20 11:48:36 --> Helper loaded: url_helper
INFO - 2018-11-20 11:48:36 --> Helper loaded: file_helper
INFO - 2018-11-20 11:48:36 --> Helper loaded: email_helper
INFO - 2018-11-20 11:48:36 --> Helper loaded: common_helper
INFO - 2018-11-20 11:48:36 --> Database Driver Class Initialized
DEBUG - 2018-11-20 11:48:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-20 11:48:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-20 11:48:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-20 11:48:36 --> Pagination Class Initialized
INFO - 2018-11-20 11:48:36 --> Helper loaded: form_helper
INFO - 2018-11-20 11:48:36 --> Form Validation Class Initialized
INFO - 2018-11-20 11:48:36 --> Model Class Initialized
INFO - 2018-11-20 11:48:36 --> Controller Class Initialized
INFO - 2018-11-20 11:48:36 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-20 11:48:36 --> Model Class Initialized
INFO - 2018-11-20 11:48:36 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-20 11:48:36 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/sidebar.php
INFO - 2018-11-20 11:48:36 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/dashboard.php
INFO - 2018-11-20 11:48:36 --> Final output sent to browser
DEBUG - 2018-11-20 11:48:36 --> Total execution time: 0.0480
INFO - 2018-11-20 11:51:32 --> Config Class Initialized
INFO - 2018-11-20 11:51:32 --> Hooks Class Initialized
DEBUG - 2018-11-20 11:51:32 --> UTF-8 Support Enabled
INFO - 2018-11-20 11:51:32 --> Utf8 Class Initialized
INFO - 2018-11-20 11:51:32 --> URI Class Initialized
INFO - 2018-11-20 11:51:32 --> Router Class Initialized
INFO - 2018-11-20 11:51:32 --> Output Class Initialized
INFO - 2018-11-20 11:51:32 --> Security Class Initialized
DEBUG - 2018-11-20 11:51:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-20 11:51:32 --> Input Class Initialized
INFO - 2018-11-20 11:51:32 --> Language Class Initialized
INFO - 2018-11-20 11:51:32 --> Loader Class Initialized
INFO - 2018-11-20 11:51:32 --> Helper loaded: url_helper
INFO - 2018-11-20 11:51:32 --> Helper loaded: file_helper
INFO - 2018-11-20 11:51:32 --> Helper loaded: email_helper
INFO - 2018-11-20 11:51:32 --> Helper loaded: common_helper
INFO - 2018-11-20 11:51:32 --> Database Driver Class Initialized
DEBUG - 2018-11-20 11:51:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-20 11:51:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-20 11:51:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-20 11:51:32 --> Pagination Class Initialized
INFO - 2018-11-20 11:51:32 --> Helper loaded: form_helper
INFO - 2018-11-20 11:51:32 --> Form Validation Class Initialized
INFO - 2018-11-20 11:51:32 --> Model Class Initialized
INFO - 2018-11-20 11:51:32 --> Controller Class Initialized
INFO - 2018-11-20 11:51:32 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-20 11:51:32 --> Model Class Initialized
INFO - 2018-11-20 11:51:32 --> Model Class Initialized
INFO - 2018-11-20 11:51:32 --> Config Class Initialized
INFO - 2018-11-20 11:51:32 --> Hooks Class Initialized
DEBUG - 2018-11-20 11:51:32 --> UTF-8 Support Enabled
INFO - 2018-11-20 11:51:32 --> Utf8 Class Initialized
INFO - 2018-11-20 11:51:32 --> URI Class Initialized
INFO - 2018-11-20 11:51:32 --> Router Class Initialized
INFO - 2018-11-20 11:51:32 --> Output Class Initialized
INFO - 2018-11-20 11:51:32 --> Security Class Initialized
DEBUG - 2018-11-20 11:51:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-20 11:51:32 --> Input Class Initialized
INFO - 2018-11-20 11:51:32 --> Language Class Initialized
ERROR - 2018-11-20 11:51:32 --> 404 Page Not Found: Admin/dashboard
INFO - 2018-11-20 11:51:35 --> Config Class Initialized
INFO - 2018-11-20 11:51:35 --> Hooks Class Initialized
DEBUG - 2018-11-20 11:51:35 --> UTF-8 Support Enabled
INFO - 2018-11-20 11:51:35 --> Utf8 Class Initialized
INFO - 2018-11-20 11:51:35 --> URI Class Initialized
INFO - 2018-11-20 11:51:35 --> Router Class Initialized
INFO - 2018-11-20 11:51:35 --> Output Class Initialized
INFO - 2018-11-20 11:51:35 --> Security Class Initialized
DEBUG - 2018-11-20 11:51:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-20 11:51:35 --> Input Class Initialized
INFO - 2018-11-20 11:51:35 --> Language Class Initialized
ERROR - 2018-11-20 11:51:35 --> 404 Page Not Found: Admin/dashboard
INFO - 2018-11-20 11:51:45 --> Config Class Initialized
INFO - 2018-11-20 11:51:45 --> Hooks Class Initialized
DEBUG - 2018-11-20 11:51:45 --> UTF-8 Support Enabled
INFO - 2018-11-20 11:51:45 --> Utf8 Class Initialized
INFO - 2018-11-20 11:51:45 --> URI Class Initialized
INFO - 2018-11-20 11:51:45 --> Router Class Initialized
INFO - 2018-11-20 11:51:45 --> Output Class Initialized
INFO - 2018-11-20 11:51:45 --> Security Class Initialized
DEBUG - 2018-11-20 11:51:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-20 11:51:45 --> Input Class Initialized
INFO - 2018-11-20 11:51:45 --> Language Class Initialized
ERROR - 2018-11-20 11:51:45 --> 404 Page Not Found: Admin/dashboard
INFO - 2018-11-20 11:52:12 --> Config Class Initialized
INFO - 2018-11-20 11:52:12 --> Hooks Class Initialized
DEBUG - 2018-11-20 11:52:12 --> UTF-8 Support Enabled
INFO - 2018-11-20 11:52:12 --> Utf8 Class Initialized
INFO - 2018-11-20 11:52:12 --> URI Class Initialized
INFO - 2018-11-20 11:52:12 --> Router Class Initialized
INFO - 2018-11-20 11:52:12 --> Output Class Initialized
INFO - 2018-11-20 11:52:12 --> Security Class Initialized
DEBUG - 2018-11-20 11:52:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-20 11:52:12 --> Input Class Initialized
INFO - 2018-11-20 11:52:12 --> Language Class Initialized
ERROR - 2018-11-20 11:52:12 --> 404 Page Not Found: Admin/dashboard
INFO - 2018-11-20 11:53:46 --> Config Class Initialized
INFO - 2018-11-20 11:53:46 --> Hooks Class Initialized
DEBUG - 2018-11-20 11:53:46 --> UTF-8 Support Enabled
INFO - 2018-11-20 11:53:46 --> Utf8 Class Initialized
INFO - 2018-11-20 11:53:46 --> URI Class Initialized
INFO - 2018-11-20 11:53:46 --> Router Class Initialized
INFO - 2018-11-20 11:53:46 --> Output Class Initialized
INFO - 2018-11-20 11:53:46 --> Security Class Initialized
DEBUG - 2018-11-20 11:53:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-20 11:53:46 --> Input Class Initialized
INFO - 2018-11-20 11:53:46 --> Language Class Initialized
ERROR - 2018-11-20 11:53:46 --> 404 Page Not Found: Admin/dashboard
INFO - 2018-11-20 11:53:57 --> Config Class Initialized
INFO - 2018-11-20 11:53:57 --> Hooks Class Initialized
DEBUG - 2018-11-20 11:53:57 --> UTF-8 Support Enabled
INFO - 2018-11-20 11:53:57 --> Utf8 Class Initialized
INFO - 2018-11-20 11:53:57 --> URI Class Initialized
DEBUG - 2018-11-20 11:53:57 --> No URI present. Default controller set.
INFO - 2018-11-20 11:53:57 --> Router Class Initialized
INFO - 2018-11-20 11:53:57 --> Output Class Initialized
INFO - 2018-11-20 11:53:57 --> Security Class Initialized
DEBUG - 2018-11-20 11:53:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-20 11:53:57 --> Input Class Initialized
INFO - 2018-11-20 11:53:57 --> Language Class Initialized
INFO - 2018-11-20 11:53:57 --> Loader Class Initialized
INFO - 2018-11-20 11:53:57 --> Helper loaded: url_helper
INFO - 2018-11-20 11:53:57 --> Helper loaded: file_helper
INFO - 2018-11-20 11:53:57 --> Helper loaded: email_helper
INFO - 2018-11-20 11:53:57 --> Helper loaded: common_helper
INFO - 2018-11-20 11:53:57 --> Database Driver Class Initialized
DEBUG - 2018-11-20 11:53:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-20 11:53:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-20 11:53:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-20 11:53:57 --> Pagination Class Initialized
INFO - 2018-11-20 11:53:57 --> Helper loaded: form_helper
INFO - 2018-11-20 11:53:57 --> Form Validation Class Initialized
INFO - 2018-11-20 11:53:57 --> Model Class Initialized
INFO - 2018-11-20 11:53:57 --> Controller Class Initialized
INFO - 2018-11-20 11:53:57 --> Model Class Initialized
INFO - 2018-11-20 11:53:57 --> Model Class Initialized
INFO - 2018-11-20 11:53:57 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\template/header-menu.php
INFO - 2018-11-20 11:53:57 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\template/header.php
INFO - 2018-11-20 11:53:57 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\template/footer.php
INFO - 2018-11-20 11:53:57 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\index.php
INFO - 2018-11-20 11:53:57 --> Final output sent to browser
DEBUG - 2018-11-20 11:53:57 --> Total execution time: 0.0640
INFO - 2018-11-20 11:54:02 --> Config Class Initialized
INFO - 2018-11-20 11:54:02 --> Hooks Class Initialized
DEBUG - 2018-11-20 11:54:02 --> UTF-8 Support Enabled
INFO - 2018-11-20 11:54:02 --> Utf8 Class Initialized
INFO - 2018-11-20 11:54:02 --> URI Class Initialized
INFO - 2018-11-20 11:54:02 --> Router Class Initialized
INFO - 2018-11-20 11:54:02 --> Output Class Initialized
INFO - 2018-11-20 11:54:02 --> Security Class Initialized
DEBUG - 2018-11-20 11:54:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-20 11:54:02 --> Input Class Initialized
INFO - 2018-11-20 11:54:02 --> Language Class Initialized
INFO - 2018-11-20 11:54:02 --> Loader Class Initialized
INFO - 2018-11-20 11:54:02 --> Helper loaded: url_helper
INFO - 2018-11-20 11:54:02 --> Helper loaded: file_helper
INFO - 2018-11-20 11:54:02 --> Helper loaded: email_helper
INFO - 2018-11-20 11:54:02 --> Helper loaded: common_helper
INFO - 2018-11-20 11:54:02 --> Database Driver Class Initialized
DEBUG - 2018-11-20 11:54:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-20 11:54:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-20 11:54:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-20 11:54:02 --> Pagination Class Initialized
INFO - 2018-11-20 11:54:02 --> Helper loaded: form_helper
INFO - 2018-11-20 11:54:02 --> Form Validation Class Initialized
INFO - 2018-11-20 11:54:02 --> Model Class Initialized
INFO - 2018-11-20 11:54:02 --> Controller Class Initialized
INFO - 2018-11-20 11:54:02 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-20 11:54:02 --> Model Class Initialized
INFO - 2018-11-20 11:54:02 --> Model Class Initialized
INFO - 2018-11-20 11:54:02 --> Config Class Initialized
INFO - 2018-11-20 11:54:02 --> Hooks Class Initialized
DEBUG - 2018-11-20 11:54:02 --> UTF-8 Support Enabled
INFO - 2018-11-20 11:54:02 --> Utf8 Class Initialized
INFO - 2018-11-20 11:54:02 --> URI Class Initialized
INFO - 2018-11-20 11:54:02 --> Router Class Initialized
INFO - 2018-11-20 11:54:02 --> Output Class Initialized
INFO - 2018-11-20 11:54:02 --> Security Class Initialized
DEBUG - 2018-11-20 11:54:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-20 11:54:02 --> Input Class Initialized
INFO - 2018-11-20 11:54:02 --> Language Class Initialized
ERROR - 2018-11-20 11:54:02 --> Severity: Warning --> require(common/Index_Controller.php): failed to open stream: No such file or directory C:\xampp\htdocs\wetinuneed\application\controllers\wun_admin\Dashboard.php 2
ERROR - 2018-11-20 11:54:02 --> Severity: Compile Error --> require(): Failed opening required 'common/Index_Controller.php' (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\wetinuneed\application\controllers\wun_admin\Dashboard.php 2
INFO - 2018-11-20 11:54:27 --> Config Class Initialized
INFO - 2018-11-20 11:54:27 --> Hooks Class Initialized
DEBUG - 2018-11-20 11:54:27 --> UTF-8 Support Enabled
INFO - 2018-11-20 11:54:27 --> Utf8 Class Initialized
INFO - 2018-11-20 11:54:27 --> URI Class Initialized
INFO - 2018-11-20 11:54:27 --> Router Class Initialized
INFO - 2018-11-20 11:54:27 --> Output Class Initialized
INFO - 2018-11-20 11:54:27 --> Security Class Initialized
DEBUG - 2018-11-20 11:54:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-20 11:54:27 --> Input Class Initialized
INFO - 2018-11-20 11:54:27 --> Language Class Initialized
ERROR - 2018-11-20 11:54:27 --> Severity: Warning --> require(common/Index_Controller.php): failed to open stream: No such file or directory C:\xampp\htdocs\wetinuneed\application\controllers\wun_admin\Dashboard.php 2
ERROR - 2018-11-20 11:54:27 --> Severity: Compile Error --> require(): Failed opening required 'common/Index_Controller.php' (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\wetinuneed\application\controllers\wun_admin\Dashboard.php 2
INFO - 2018-11-20 11:54:27 --> Config Class Initialized
INFO - 2018-11-20 11:54:27 --> Hooks Class Initialized
DEBUG - 2018-11-20 11:54:27 --> UTF-8 Support Enabled
INFO - 2018-11-20 11:54:27 --> Utf8 Class Initialized
INFO - 2018-11-20 11:54:27 --> URI Class Initialized
INFO - 2018-11-20 11:54:27 --> Router Class Initialized
INFO - 2018-11-20 11:54:27 --> Output Class Initialized
INFO - 2018-11-20 11:54:27 --> Security Class Initialized
DEBUG - 2018-11-20 11:54:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-20 11:54:27 --> Input Class Initialized
INFO - 2018-11-20 11:54:27 --> Language Class Initialized
ERROR - 2018-11-20 11:54:27 --> Severity: Warning --> require(common/Index_Controller.php): failed to open stream: No such file or directory C:\xampp\htdocs\wetinuneed\application\controllers\wun_admin\Dashboard.php 2
ERROR - 2018-11-20 11:54:27 --> Severity: Compile Error --> require(): Failed opening required 'common/Index_Controller.php' (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\wetinuneed\application\controllers\wun_admin\Dashboard.php 2
INFO - 2018-11-20 11:54:28 --> Config Class Initialized
INFO - 2018-11-20 11:54:28 --> Hooks Class Initialized
DEBUG - 2018-11-20 11:54:28 --> UTF-8 Support Enabled
INFO - 2018-11-20 11:54:28 --> Utf8 Class Initialized
INFO - 2018-11-20 11:54:28 --> URI Class Initialized
INFO - 2018-11-20 11:54:28 --> Router Class Initialized
INFO - 2018-11-20 11:54:28 --> Output Class Initialized
INFO - 2018-11-20 11:54:28 --> Security Class Initialized
DEBUG - 2018-11-20 11:54:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-20 11:54:28 --> Input Class Initialized
INFO - 2018-11-20 11:54:28 --> Language Class Initialized
ERROR - 2018-11-20 11:54:28 --> Severity: Warning --> require(common/Index_Controller.php): failed to open stream: No such file or directory C:\xampp\htdocs\wetinuneed\application\controllers\wun_admin\Dashboard.php 2
ERROR - 2018-11-20 11:54:28 --> Severity: Compile Error --> require(): Failed opening required 'common/Index_Controller.php' (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\wetinuneed\application\controllers\wun_admin\Dashboard.php 2
INFO - 2018-11-20 11:54:28 --> Config Class Initialized
INFO - 2018-11-20 11:54:28 --> Hooks Class Initialized
DEBUG - 2018-11-20 11:54:28 --> UTF-8 Support Enabled
INFO - 2018-11-20 11:54:28 --> Utf8 Class Initialized
INFO - 2018-11-20 11:54:28 --> URI Class Initialized
INFO - 2018-11-20 11:54:28 --> Router Class Initialized
INFO - 2018-11-20 11:54:28 --> Output Class Initialized
INFO - 2018-11-20 11:54:28 --> Security Class Initialized
DEBUG - 2018-11-20 11:54:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-20 11:54:28 --> Input Class Initialized
INFO - 2018-11-20 11:54:28 --> Language Class Initialized
ERROR - 2018-11-20 11:54:28 --> Severity: Warning --> require(common/Index_Controller.php): failed to open stream: No such file or directory C:\xampp\htdocs\wetinuneed\application\controllers\wun_admin\Dashboard.php 2
ERROR - 2018-11-20 11:54:28 --> Severity: Compile Error --> require(): Failed opening required 'common/Index_Controller.php' (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\wetinuneed\application\controllers\wun_admin\Dashboard.php 2
INFO - 2018-11-20 11:54:28 --> Config Class Initialized
INFO - 2018-11-20 11:54:28 --> Hooks Class Initialized
DEBUG - 2018-11-20 11:54:28 --> UTF-8 Support Enabled
INFO - 2018-11-20 11:54:28 --> Utf8 Class Initialized
INFO - 2018-11-20 11:54:28 --> URI Class Initialized
INFO - 2018-11-20 11:54:28 --> Router Class Initialized
INFO - 2018-11-20 11:54:28 --> Output Class Initialized
INFO - 2018-11-20 11:54:28 --> Security Class Initialized
DEBUG - 2018-11-20 11:54:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-20 11:54:28 --> Input Class Initialized
INFO - 2018-11-20 11:54:28 --> Language Class Initialized
ERROR - 2018-11-20 11:54:28 --> Severity: Warning --> require(common/Index_Controller.php): failed to open stream: No such file or directory C:\xampp\htdocs\wetinuneed\application\controllers\wun_admin\Dashboard.php 2
ERROR - 2018-11-20 11:54:28 --> Severity: Compile Error --> require(): Failed opening required 'common/Index_Controller.php' (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\wetinuneed\application\controllers\wun_admin\Dashboard.php 2
INFO - 2018-11-20 11:54:42 --> Config Class Initialized
INFO - 2018-11-20 11:54:42 --> Hooks Class Initialized
DEBUG - 2018-11-20 11:54:42 --> UTF-8 Support Enabled
INFO - 2018-11-20 11:54:42 --> Utf8 Class Initialized
INFO - 2018-11-20 11:54:42 --> URI Class Initialized
INFO - 2018-11-20 11:54:42 --> Router Class Initialized
INFO - 2018-11-20 11:54:42 --> Output Class Initialized
INFO - 2018-11-20 11:54:42 --> Security Class Initialized
DEBUG - 2018-11-20 11:54:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-20 11:54:42 --> Input Class Initialized
INFO - 2018-11-20 11:54:42 --> Language Class Initialized
ERROR - 2018-11-20 11:54:42 --> Severity: Warning --> require(common/Index_Controller.php): failed to open stream: No such file or directory C:\xampp\htdocs\wetinuneed\application\controllers\wun_admin\Dashboard.php 2
ERROR - 2018-11-20 11:54:42 --> Severity: Compile Error --> require(): Failed opening required 'common/Index_Controller.php' (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\wetinuneed\application\controllers\wun_admin\Dashboard.php 2
INFO - 2018-11-20 11:54:47 --> Config Class Initialized
INFO - 2018-11-20 11:54:47 --> Hooks Class Initialized
DEBUG - 2018-11-20 11:54:47 --> UTF-8 Support Enabled
INFO - 2018-11-20 11:54:47 --> Utf8 Class Initialized
INFO - 2018-11-20 11:54:47 --> URI Class Initialized
INFO - 2018-11-20 11:54:47 --> Router Class Initialized
INFO - 2018-11-20 11:54:47 --> Output Class Initialized
INFO - 2018-11-20 11:54:47 --> Security Class Initialized
DEBUG - 2018-11-20 11:54:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-20 11:54:47 --> Input Class Initialized
INFO - 2018-11-20 11:54:47 --> Language Class Initialized
ERROR - 2018-11-20 11:54:47 --> Severity: Warning --> require(common/Index_Controller.php): failed to open stream: No such file or directory C:\xampp\htdocs\wetinuneed\application\controllers\wun_admin\Dashboard.php 2
ERROR - 2018-11-20 11:54:47 --> Severity: Compile Error --> require(): Failed opening required 'common/Index_Controller.php' (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\wetinuneed\application\controllers\wun_admin\Dashboard.php 2
INFO - 2018-11-20 11:55:37 --> Config Class Initialized
INFO - 2018-11-20 11:55:37 --> Hooks Class Initialized
DEBUG - 2018-11-20 11:55:37 --> UTF-8 Support Enabled
INFO - 2018-11-20 11:55:37 --> Utf8 Class Initialized
INFO - 2018-11-20 11:55:37 --> URI Class Initialized
INFO - 2018-11-20 11:55:37 --> Router Class Initialized
INFO - 2018-11-20 11:55:37 --> Output Class Initialized
INFO - 2018-11-20 11:55:37 --> Security Class Initialized
DEBUG - 2018-11-20 11:55:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-20 11:55:37 --> Input Class Initialized
INFO - 2018-11-20 11:55:37 --> Language Class Initialized
ERROR - 2018-11-20 11:55:37 --> Severity: Warning --> require(common/Index_Controller.php): failed to open stream: No such file or directory C:\xampp\htdocs\wetinuneed\application\controllers\wun_admin\Dashboard.php 2
ERROR - 2018-11-20 11:55:37 --> Severity: Compile Error --> require(): Failed opening required 'common/Index_Controller.php' (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\wetinuneed\application\controllers\wun_admin\Dashboard.php 2
INFO - 2018-11-20 11:55:37 --> Config Class Initialized
INFO - 2018-11-20 11:55:37 --> Hooks Class Initialized
DEBUG - 2018-11-20 11:55:37 --> UTF-8 Support Enabled
INFO - 2018-11-20 11:55:37 --> Utf8 Class Initialized
INFO - 2018-11-20 11:55:37 --> URI Class Initialized
INFO - 2018-11-20 11:55:37 --> Router Class Initialized
INFO - 2018-11-20 11:55:37 --> Output Class Initialized
INFO - 2018-11-20 11:55:37 --> Security Class Initialized
DEBUG - 2018-11-20 11:55:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-20 11:55:37 --> Input Class Initialized
INFO - 2018-11-20 11:55:37 --> Language Class Initialized
ERROR - 2018-11-20 11:55:37 --> Severity: Warning --> require(common/Index_Controller.php): failed to open stream: No such file or directory C:\xampp\htdocs\wetinuneed\application\controllers\wun_admin\Dashboard.php 2
ERROR - 2018-11-20 11:55:37 --> Severity: Compile Error --> require(): Failed opening required 'common/Index_Controller.php' (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\wetinuneed\application\controllers\wun_admin\Dashboard.php 2
INFO - 2018-11-20 11:55:37 --> Config Class Initialized
INFO - 2018-11-20 11:55:37 --> Hooks Class Initialized
DEBUG - 2018-11-20 11:55:37 --> UTF-8 Support Enabled
INFO - 2018-11-20 11:55:37 --> Utf8 Class Initialized
INFO - 2018-11-20 11:55:37 --> URI Class Initialized
INFO - 2018-11-20 11:55:37 --> Router Class Initialized
INFO - 2018-11-20 11:55:37 --> Output Class Initialized
INFO - 2018-11-20 11:55:37 --> Security Class Initialized
DEBUG - 2018-11-20 11:55:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-20 11:55:37 --> Input Class Initialized
INFO - 2018-11-20 11:55:37 --> Language Class Initialized
ERROR - 2018-11-20 11:55:37 --> Severity: Warning --> require(common/Index_Controller.php): failed to open stream: No such file or directory C:\xampp\htdocs\wetinuneed\application\controllers\wun_admin\Dashboard.php 2
ERROR - 2018-11-20 11:55:37 --> Severity: Compile Error --> require(): Failed opening required 'common/Index_Controller.php' (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\wetinuneed\application\controllers\wun_admin\Dashboard.php 2
INFO - 2018-11-20 11:55:38 --> Config Class Initialized
INFO - 2018-11-20 11:55:38 --> Hooks Class Initialized
DEBUG - 2018-11-20 11:55:38 --> UTF-8 Support Enabled
INFO - 2018-11-20 11:55:38 --> Utf8 Class Initialized
INFO - 2018-11-20 11:55:38 --> URI Class Initialized
INFO - 2018-11-20 11:55:38 --> Router Class Initialized
INFO - 2018-11-20 11:55:38 --> Output Class Initialized
INFO - 2018-11-20 11:55:38 --> Security Class Initialized
DEBUG - 2018-11-20 11:55:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-20 11:55:38 --> Input Class Initialized
INFO - 2018-11-20 11:55:38 --> Language Class Initialized
ERROR - 2018-11-20 11:55:38 --> Severity: Warning --> require(common/Index_Controller.php): failed to open stream: No such file or directory C:\xampp\htdocs\wetinuneed\application\controllers\wun_admin\Dashboard.php 2
ERROR - 2018-11-20 11:55:38 --> Severity: Compile Error --> require(): Failed opening required 'common/Index_Controller.php' (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\wetinuneed\application\controllers\wun_admin\Dashboard.php 2
INFO - 2018-11-20 11:55:38 --> Config Class Initialized
INFO - 2018-11-20 11:55:38 --> Hooks Class Initialized
DEBUG - 2018-11-20 11:55:38 --> UTF-8 Support Enabled
INFO - 2018-11-20 11:55:38 --> Utf8 Class Initialized
INFO - 2018-11-20 11:55:38 --> URI Class Initialized
INFO - 2018-11-20 11:55:38 --> Router Class Initialized
INFO - 2018-11-20 11:55:38 --> Output Class Initialized
INFO - 2018-11-20 11:55:38 --> Security Class Initialized
DEBUG - 2018-11-20 11:55:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-20 11:55:38 --> Input Class Initialized
INFO - 2018-11-20 11:55:38 --> Language Class Initialized
ERROR - 2018-11-20 11:55:38 --> Severity: Warning --> require(common/Index_Controller.php): failed to open stream: No such file or directory C:\xampp\htdocs\wetinuneed\application\controllers\wun_admin\Dashboard.php 2
ERROR - 2018-11-20 11:55:38 --> Severity: Compile Error --> require(): Failed opening required 'common/Index_Controller.php' (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\wetinuneed\application\controllers\wun_admin\Dashboard.php 2
INFO - 2018-11-20 11:55:38 --> Config Class Initialized
INFO - 2018-11-20 11:55:38 --> Hooks Class Initialized
DEBUG - 2018-11-20 11:55:38 --> UTF-8 Support Enabled
INFO - 2018-11-20 11:55:38 --> Utf8 Class Initialized
INFO - 2018-11-20 11:55:38 --> URI Class Initialized
INFO - 2018-11-20 11:55:38 --> Router Class Initialized
INFO - 2018-11-20 11:55:38 --> Output Class Initialized
INFO - 2018-11-20 11:55:38 --> Security Class Initialized
DEBUG - 2018-11-20 11:55:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-20 11:55:38 --> Input Class Initialized
INFO - 2018-11-20 11:55:38 --> Language Class Initialized
ERROR - 2018-11-20 11:55:38 --> Severity: Warning --> require(common/Index_Controller.php): failed to open stream: No such file or directory C:\xampp\htdocs\wetinuneed\application\controllers\wun_admin\Dashboard.php 2
ERROR - 2018-11-20 11:55:38 --> Severity: Compile Error --> require(): Failed opening required 'common/Index_Controller.php' (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\wetinuneed\application\controllers\wun_admin\Dashboard.php 2
INFO - 2018-11-20 11:55:38 --> Config Class Initialized
INFO - 2018-11-20 11:55:38 --> Hooks Class Initialized
DEBUG - 2018-11-20 11:55:38 --> UTF-8 Support Enabled
INFO - 2018-11-20 11:55:38 --> Utf8 Class Initialized
INFO - 2018-11-20 11:55:38 --> URI Class Initialized
INFO - 2018-11-20 11:55:38 --> Router Class Initialized
INFO - 2018-11-20 11:55:38 --> Output Class Initialized
INFO - 2018-11-20 11:55:38 --> Security Class Initialized
DEBUG - 2018-11-20 11:55:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-20 11:55:38 --> Input Class Initialized
INFO - 2018-11-20 11:55:38 --> Language Class Initialized
ERROR - 2018-11-20 11:55:38 --> Severity: Warning --> require(common/Index_Controller.php): failed to open stream: No such file or directory C:\xampp\htdocs\wetinuneed\application\controllers\wun_admin\Dashboard.php 2
ERROR - 2018-11-20 11:55:38 --> Severity: Compile Error --> require(): Failed opening required 'common/Index_Controller.php' (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\wetinuneed\application\controllers\wun_admin\Dashboard.php 2
INFO - 2018-11-20 11:55:38 --> Config Class Initialized
INFO - 2018-11-20 11:55:38 --> Hooks Class Initialized
DEBUG - 2018-11-20 11:55:38 --> UTF-8 Support Enabled
INFO - 2018-11-20 11:55:38 --> Utf8 Class Initialized
INFO - 2018-11-20 11:55:38 --> URI Class Initialized
INFO - 2018-11-20 11:55:38 --> Router Class Initialized
INFO - 2018-11-20 11:55:38 --> Output Class Initialized
INFO - 2018-11-20 11:55:38 --> Security Class Initialized
DEBUG - 2018-11-20 11:55:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-20 11:55:38 --> Input Class Initialized
INFO - 2018-11-20 11:55:38 --> Language Class Initialized
ERROR - 2018-11-20 11:55:38 --> Severity: Warning --> require(common/Index_Controller.php): failed to open stream: No such file or directory C:\xampp\htdocs\wetinuneed\application\controllers\wun_admin\Dashboard.php 2
ERROR - 2018-11-20 11:55:38 --> Severity: Compile Error --> require(): Failed opening required 'common/Index_Controller.php' (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\wetinuneed\application\controllers\wun_admin\Dashboard.php 2
INFO - 2018-11-20 11:55:38 --> Config Class Initialized
INFO - 2018-11-20 11:55:38 --> Hooks Class Initialized
DEBUG - 2018-11-20 11:55:38 --> UTF-8 Support Enabled
INFO - 2018-11-20 11:55:38 --> Utf8 Class Initialized
INFO - 2018-11-20 11:55:38 --> URI Class Initialized
INFO - 2018-11-20 11:55:38 --> Router Class Initialized
INFO - 2018-11-20 11:55:38 --> Output Class Initialized
INFO - 2018-11-20 11:55:38 --> Security Class Initialized
DEBUG - 2018-11-20 11:55:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-20 11:55:38 --> Input Class Initialized
INFO - 2018-11-20 11:55:38 --> Language Class Initialized
ERROR - 2018-11-20 11:55:38 --> Severity: Warning --> require(common/Index_Controller.php): failed to open stream: No such file or directory C:\xampp\htdocs\wetinuneed\application\controllers\wun_admin\Dashboard.php 2
ERROR - 2018-11-20 11:55:38 --> Severity: Compile Error --> require(): Failed opening required 'common/Index_Controller.php' (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\wetinuneed\application\controllers\wun_admin\Dashboard.php 2
INFO - 2018-11-20 11:55:39 --> Config Class Initialized
INFO - 2018-11-20 11:55:39 --> Hooks Class Initialized
DEBUG - 2018-11-20 11:55:39 --> UTF-8 Support Enabled
INFO - 2018-11-20 11:55:39 --> Utf8 Class Initialized
INFO - 2018-11-20 11:55:39 --> URI Class Initialized
INFO - 2018-11-20 11:55:39 --> Router Class Initialized
INFO - 2018-11-20 11:55:39 --> Output Class Initialized
INFO - 2018-11-20 11:55:39 --> Security Class Initialized
DEBUG - 2018-11-20 11:55:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-20 11:55:39 --> Input Class Initialized
INFO - 2018-11-20 11:55:39 --> Language Class Initialized
ERROR - 2018-11-20 11:55:39 --> Severity: Warning --> require(common/Index_Controller.php): failed to open stream: No such file or directory C:\xampp\htdocs\wetinuneed\application\controllers\wun_admin\Dashboard.php 2
ERROR - 2018-11-20 11:55:39 --> Severity: Compile Error --> require(): Failed opening required 'common/Index_Controller.php' (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\wetinuneed\application\controllers\wun_admin\Dashboard.php 2
INFO - 2018-11-20 11:55:39 --> Config Class Initialized
INFO - 2018-11-20 11:55:39 --> Hooks Class Initialized
DEBUG - 2018-11-20 11:55:39 --> UTF-8 Support Enabled
INFO - 2018-11-20 11:55:39 --> Utf8 Class Initialized
INFO - 2018-11-20 11:55:39 --> URI Class Initialized
INFO - 2018-11-20 11:55:39 --> Router Class Initialized
INFO - 2018-11-20 11:55:39 --> Output Class Initialized
INFO - 2018-11-20 11:55:39 --> Security Class Initialized
DEBUG - 2018-11-20 11:55:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-20 11:55:39 --> Input Class Initialized
INFO - 2018-11-20 11:55:39 --> Language Class Initialized
ERROR - 2018-11-20 11:55:39 --> Severity: Warning --> require(common/Index_Controller.php): failed to open stream: No such file or directory C:\xampp\htdocs\wetinuneed\application\controllers\wun_admin\Dashboard.php 2
ERROR - 2018-11-20 11:55:39 --> Severity: Compile Error --> require(): Failed opening required 'common/Index_Controller.php' (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\wetinuneed\application\controllers\wun_admin\Dashboard.php 2
INFO - 2018-11-20 11:55:39 --> Config Class Initialized
INFO - 2018-11-20 11:55:39 --> Hooks Class Initialized
DEBUG - 2018-11-20 11:55:39 --> UTF-8 Support Enabled
INFO - 2018-11-20 11:55:39 --> Utf8 Class Initialized
INFO - 2018-11-20 11:55:39 --> URI Class Initialized
INFO - 2018-11-20 11:55:39 --> Router Class Initialized
INFO - 2018-11-20 11:55:39 --> Output Class Initialized
INFO - 2018-11-20 11:55:39 --> Security Class Initialized
DEBUG - 2018-11-20 11:55:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-20 11:55:39 --> Input Class Initialized
INFO - 2018-11-20 11:55:39 --> Language Class Initialized
ERROR - 2018-11-20 11:55:39 --> Severity: Warning --> require(common/Index_Controller.php): failed to open stream: No such file or directory C:\xampp\htdocs\wetinuneed\application\controllers\wun_admin\Dashboard.php 2
ERROR - 2018-11-20 11:55:39 --> Severity: Compile Error --> require(): Failed opening required 'common/Index_Controller.php' (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\wetinuneed\application\controllers\wun_admin\Dashboard.php 2
INFO - 2018-11-20 11:55:39 --> Config Class Initialized
INFO - 2018-11-20 11:55:39 --> Hooks Class Initialized
DEBUG - 2018-11-20 11:55:39 --> UTF-8 Support Enabled
INFO - 2018-11-20 11:55:39 --> Utf8 Class Initialized
INFO - 2018-11-20 11:55:39 --> URI Class Initialized
INFO - 2018-11-20 11:55:39 --> Router Class Initialized
INFO - 2018-11-20 11:55:39 --> Output Class Initialized
INFO - 2018-11-20 11:55:39 --> Security Class Initialized
DEBUG - 2018-11-20 11:55:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-20 11:55:39 --> Input Class Initialized
INFO - 2018-11-20 11:55:39 --> Language Class Initialized
ERROR - 2018-11-20 11:55:39 --> Severity: Warning --> require(common/Index_Controller.php): failed to open stream: No such file or directory C:\xampp\htdocs\wetinuneed\application\controllers\wun_admin\Dashboard.php 2
ERROR - 2018-11-20 11:55:39 --> Severity: Compile Error --> require(): Failed opening required 'common/Index_Controller.php' (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\wetinuneed\application\controllers\wun_admin\Dashboard.php 2
INFO - 2018-11-20 11:55:39 --> Config Class Initialized
INFO - 2018-11-20 11:55:39 --> Hooks Class Initialized
DEBUG - 2018-11-20 11:55:39 --> UTF-8 Support Enabled
INFO - 2018-11-20 11:55:39 --> Utf8 Class Initialized
INFO - 2018-11-20 11:55:39 --> URI Class Initialized
INFO - 2018-11-20 11:55:39 --> Router Class Initialized
INFO - 2018-11-20 11:55:39 --> Output Class Initialized
INFO - 2018-11-20 11:55:39 --> Security Class Initialized
DEBUG - 2018-11-20 11:55:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-20 11:55:39 --> Input Class Initialized
INFO - 2018-11-20 11:55:39 --> Language Class Initialized
ERROR - 2018-11-20 11:55:39 --> Severity: Warning --> require(common/Index_Controller.php): failed to open stream: No such file or directory C:\xampp\htdocs\wetinuneed\application\controllers\wun_admin\Dashboard.php 2
ERROR - 2018-11-20 11:55:39 --> Severity: Compile Error --> require(): Failed opening required 'common/Index_Controller.php' (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\wetinuneed\application\controllers\wun_admin\Dashboard.php 2
INFO - 2018-11-20 11:55:42 --> Config Class Initialized
INFO - 2018-11-20 11:55:42 --> Hooks Class Initialized
DEBUG - 2018-11-20 11:55:42 --> UTF-8 Support Enabled
INFO - 2018-11-20 11:55:42 --> Utf8 Class Initialized
INFO - 2018-11-20 11:55:42 --> URI Class Initialized
INFO - 2018-11-20 11:55:42 --> Router Class Initialized
INFO - 2018-11-20 11:55:42 --> Output Class Initialized
INFO - 2018-11-20 11:55:42 --> Security Class Initialized
DEBUG - 2018-11-20 11:55:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-20 11:55:42 --> Input Class Initialized
INFO - 2018-11-20 11:55:42 --> Language Class Initialized
ERROR - 2018-11-20 11:55:42 --> Severity: Warning --> require(common/Index_Controller.php): failed to open stream: No such file or directory C:\xampp\htdocs\wetinuneed\application\controllers\wun_admin\Dashboard.php 2
ERROR - 2018-11-20 11:55:42 --> Severity: Compile Error --> require(): Failed opening required 'common/Index_Controller.php' (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\wetinuneed\application\controllers\wun_admin\Dashboard.php 2
INFO - 2018-11-20 11:56:16 --> Config Class Initialized
INFO - 2018-11-20 11:56:16 --> Hooks Class Initialized
DEBUG - 2018-11-20 11:56:16 --> UTF-8 Support Enabled
INFO - 2018-11-20 11:56:16 --> Utf8 Class Initialized
INFO - 2018-11-20 11:56:16 --> URI Class Initialized
INFO - 2018-11-20 11:56:16 --> Router Class Initialized
INFO - 2018-11-20 11:56:16 --> Output Class Initialized
INFO - 2018-11-20 11:56:16 --> Security Class Initialized
DEBUG - 2018-11-20 11:56:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-20 11:56:16 --> Input Class Initialized
INFO - 2018-11-20 11:56:16 --> Language Class Initialized
ERROR - 2018-11-20 11:56:16 --> Severity: Warning --> require(common/Index_Controller.php): failed to open stream: No such file or directory C:\xampp\htdocs\wetinuneed\application\controllers\wun_admin\Dashboard.php 2
ERROR - 2018-11-20 11:56:16 --> Severity: Compile Error --> require(): Failed opening required 'common/Index_Controller.php' (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\wetinuneed\application\controllers\wun_admin\Dashboard.php 2
INFO - 2018-11-20 11:58:14 --> Config Class Initialized
INFO - 2018-11-20 11:58:14 --> Hooks Class Initialized
DEBUG - 2018-11-20 11:58:14 --> UTF-8 Support Enabled
INFO - 2018-11-20 11:58:14 --> Utf8 Class Initialized
INFO - 2018-11-20 11:58:14 --> URI Class Initialized
INFO - 2018-11-20 11:58:14 --> Router Class Initialized
INFO - 2018-11-20 11:58:14 --> Output Class Initialized
INFO - 2018-11-20 11:58:14 --> Security Class Initialized
DEBUG - 2018-11-20 11:58:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-20 11:58:14 --> Input Class Initialized
INFO - 2018-11-20 11:58:14 --> Language Class Initialized
ERROR - 2018-11-20 11:58:14 --> Severity: Warning --> require(common/Index_Controller.php): failed to open stream: No such file or directory C:\xampp\htdocs\wetinuneed\application\controllers\wun_admin\Dashboard.php 2
ERROR - 2018-11-20 11:58:14 --> Severity: Compile Error --> require(): Failed opening required 'common/Index_Controller.php' (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\wetinuneed\application\controllers\wun_admin\Dashboard.php 2
INFO - 2018-11-20 11:58:16 --> Config Class Initialized
INFO - 2018-11-20 11:58:16 --> Hooks Class Initialized
DEBUG - 2018-11-20 11:58:16 --> UTF-8 Support Enabled
INFO - 2018-11-20 11:58:16 --> Utf8 Class Initialized
INFO - 2018-11-20 11:58:16 --> URI Class Initialized
INFO - 2018-11-20 11:58:16 --> Router Class Initialized
INFO - 2018-11-20 11:58:16 --> Output Class Initialized
INFO - 2018-11-20 11:58:16 --> Security Class Initialized
DEBUG - 2018-11-20 11:58:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-20 11:58:16 --> Input Class Initialized
INFO - 2018-11-20 11:58:16 --> Language Class Initialized
ERROR - 2018-11-20 11:58:16 --> Severity: Warning --> require(common/Index_Controller.php): failed to open stream: No such file or directory C:\xampp\htdocs\wetinuneed\application\controllers\wun_admin\Dashboard.php 2
ERROR - 2018-11-20 11:58:16 --> Severity: Compile Error --> require(): Failed opening required 'common/Index_Controller.php' (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\wetinuneed\application\controllers\wun_admin\Dashboard.php 2
INFO - 2018-11-20 11:58:16 --> Config Class Initialized
INFO - 2018-11-20 11:58:16 --> Hooks Class Initialized
DEBUG - 2018-11-20 11:58:16 --> UTF-8 Support Enabled
INFO - 2018-11-20 11:58:16 --> Utf8 Class Initialized
INFO - 2018-11-20 11:58:16 --> URI Class Initialized
INFO - 2018-11-20 11:58:16 --> Router Class Initialized
INFO - 2018-11-20 11:58:16 --> Output Class Initialized
INFO - 2018-11-20 11:58:16 --> Security Class Initialized
DEBUG - 2018-11-20 11:58:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-20 11:58:16 --> Input Class Initialized
INFO - 2018-11-20 11:58:16 --> Language Class Initialized
ERROR - 2018-11-20 11:58:16 --> Severity: Warning --> require(common/Index_Controller.php): failed to open stream: No such file or directory C:\xampp\htdocs\wetinuneed\application\controllers\wun_admin\Dashboard.php 2
ERROR - 2018-11-20 11:58:16 --> Severity: Compile Error --> require(): Failed opening required 'common/Index_Controller.php' (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\wetinuneed\application\controllers\wun_admin\Dashboard.php 2
INFO - 2018-11-20 11:58:58 --> Config Class Initialized
INFO - 2018-11-20 11:58:58 --> Hooks Class Initialized
DEBUG - 2018-11-20 11:58:58 --> UTF-8 Support Enabled
INFO - 2018-11-20 11:58:58 --> Utf8 Class Initialized
INFO - 2018-11-20 11:58:58 --> URI Class Initialized
INFO - 2018-11-20 11:58:58 --> Router Class Initialized
INFO - 2018-11-20 11:58:58 --> Output Class Initialized
INFO - 2018-11-20 11:58:58 --> Security Class Initialized
DEBUG - 2018-11-20 11:58:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-20 11:58:58 --> Input Class Initialized
INFO - 2018-11-20 11:58:58 --> Language Class Initialized
ERROR - 2018-11-20 11:58:58 --> Severity: Warning --> require(common/Index_Controller.php): failed to open stream: No such file or directory C:\xampp\htdocs\wetinuneed\application\controllers\wun_admin\Dashboard.php 2
ERROR - 2018-11-20 11:58:58 --> Severity: Compile Error --> require(): Failed opening required 'common/Index_Controller.php' (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\wetinuneed\application\controllers\wun_admin\Dashboard.php 2
INFO - 2018-11-20 11:58:58 --> Config Class Initialized
INFO - 2018-11-20 11:58:58 --> Hooks Class Initialized
DEBUG - 2018-11-20 11:58:58 --> UTF-8 Support Enabled
INFO - 2018-11-20 11:58:58 --> Utf8 Class Initialized
INFO - 2018-11-20 11:58:58 --> URI Class Initialized
INFO - 2018-11-20 11:58:58 --> Router Class Initialized
INFO - 2018-11-20 11:58:58 --> Output Class Initialized
INFO - 2018-11-20 11:58:58 --> Security Class Initialized
DEBUG - 2018-11-20 11:58:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-20 11:58:58 --> Input Class Initialized
INFO - 2018-11-20 11:58:58 --> Language Class Initialized
ERROR - 2018-11-20 11:58:58 --> Severity: Warning --> require(common/Index_Controller.php): failed to open stream: No such file or directory C:\xampp\htdocs\wetinuneed\application\controllers\wun_admin\Dashboard.php 2
ERROR - 2018-11-20 11:58:58 --> Severity: Compile Error --> require(): Failed opening required 'common/Index_Controller.php' (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\wetinuneed\application\controllers\wun_admin\Dashboard.php 2
INFO - 2018-11-20 11:58:59 --> Config Class Initialized
INFO - 2018-11-20 11:58:59 --> Hooks Class Initialized
DEBUG - 2018-11-20 11:58:59 --> UTF-8 Support Enabled
INFO - 2018-11-20 11:58:59 --> Utf8 Class Initialized
INFO - 2018-11-20 11:58:59 --> URI Class Initialized
INFO - 2018-11-20 11:58:59 --> Router Class Initialized
INFO - 2018-11-20 11:58:59 --> Output Class Initialized
INFO - 2018-11-20 11:58:59 --> Security Class Initialized
DEBUG - 2018-11-20 11:58:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-20 11:58:59 --> Input Class Initialized
INFO - 2018-11-20 11:58:59 --> Language Class Initialized
ERROR - 2018-11-20 11:58:59 --> Severity: Warning --> require(common/Index_Controller.php): failed to open stream: No such file or directory C:\xampp\htdocs\wetinuneed\application\controllers\wun_admin\Dashboard.php 2
ERROR - 2018-11-20 11:58:59 --> Severity: Compile Error --> require(): Failed opening required 'common/Index_Controller.php' (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\wetinuneed\application\controllers\wun_admin\Dashboard.php 2
INFO - 2018-11-20 11:58:59 --> Config Class Initialized
INFO - 2018-11-20 11:58:59 --> Hooks Class Initialized
DEBUG - 2018-11-20 11:58:59 --> UTF-8 Support Enabled
INFO - 2018-11-20 11:58:59 --> Utf8 Class Initialized
INFO - 2018-11-20 11:58:59 --> URI Class Initialized
INFO - 2018-11-20 11:58:59 --> Router Class Initialized
INFO - 2018-11-20 11:58:59 --> Output Class Initialized
INFO - 2018-11-20 11:58:59 --> Security Class Initialized
DEBUG - 2018-11-20 11:58:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-20 11:58:59 --> Input Class Initialized
INFO - 2018-11-20 11:58:59 --> Language Class Initialized
ERROR - 2018-11-20 11:58:59 --> Severity: Warning --> require(common/Index_Controller.php): failed to open stream: No such file or directory C:\xampp\htdocs\wetinuneed\application\controllers\wun_admin\Dashboard.php 2
ERROR - 2018-11-20 11:58:59 --> Severity: Compile Error --> require(): Failed opening required 'common/Index_Controller.php' (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\wetinuneed\application\controllers\wun_admin\Dashboard.php 2
INFO - 2018-11-20 11:58:59 --> Config Class Initialized
INFO - 2018-11-20 11:58:59 --> Hooks Class Initialized
DEBUG - 2018-11-20 11:58:59 --> UTF-8 Support Enabled
INFO - 2018-11-20 11:58:59 --> Utf8 Class Initialized
INFO - 2018-11-20 11:58:59 --> URI Class Initialized
INFO - 2018-11-20 11:58:59 --> Router Class Initialized
INFO - 2018-11-20 11:58:59 --> Output Class Initialized
INFO - 2018-11-20 11:58:59 --> Security Class Initialized
DEBUG - 2018-11-20 11:58:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-20 11:58:59 --> Input Class Initialized
INFO - 2018-11-20 11:58:59 --> Language Class Initialized
ERROR - 2018-11-20 11:58:59 --> Severity: Warning --> require(common/Index_Controller.php): failed to open stream: No such file or directory C:\xampp\htdocs\wetinuneed\application\controllers\wun_admin\Dashboard.php 2
ERROR - 2018-11-20 11:58:59 --> Severity: Compile Error --> require(): Failed opening required 'common/Index_Controller.php' (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\wetinuneed\application\controllers\wun_admin\Dashboard.php 2
INFO - 2018-11-20 11:58:59 --> Config Class Initialized
INFO - 2018-11-20 11:58:59 --> Hooks Class Initialized
DEBUG - 2018-11-20 11:58:59 --> UTF-8 Support Enabled
INFO - 2018-11-20 11:58:59 --> Utf8 Class Initialized
INFO - 2018-11-20 11:58:59 --> URI Class Initialized
INFO - 2018-11-20 11:58:59 --> Router Class Initialized
INFO - 2018-11-20 11:58:59 --> Output Class Initialized
INFO - 2018-11-20 11:58:59 --> Security Class Initialized
DEBUG - 2018-11-20 11:58:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-20 11:58:59 --> Input Class Initialized
INFO - 2018-11-20 11:58:59 --> Language Class Initialized
ERROR - 2018-11-20 11:58:59 --> Severity: Warning --> require(common/Index_Controller.php): failed to open stream: No such file or directory C:\xampp\htdocs\wetinuneed\application\controllers\wun_admin\Dashboard.php 2
ERROR - 2018-11-20 11:58:59 --> Severity: Compile Error --> require(): Failed opening required 'common/Index_Controller.php' (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\wetinuneed\application\controllers\wun_admin\Dashboard.php 2
INFO - 2018-11-20 11:58:59 --> Config Class Initialized
INFO - 2018-11-20 11:58:59 --> Hooks Class Initialized
DEBUG - 2018-11-20 11:58:59 --> UTF-8 Support Enabled
INFO - 2018-11-20 11:58:59 --> Utf8 Class Initialized
INFO - 2018-11-20 11:58:59 --> URI Class Initialized
INFO - 2018-11-20 11:58:59 --> Router Class Initialized
INFO - 2018-11-20 11:58:59 --> Output Class Initialized
INFO - 2018-11-20 11:58:59 --> Security Class Initialized
DEBUG - 2018-11-20 11:58:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-20 11:58:59 --> Input Class Initialized
INFO - 2018-11-20 11:58:59 --> Language Class Initialized
ERROR - 2018-11-20 11:58:59 --> Severity: Warning --> require(common/Index_Controller.php): failed to open stream: No such file or directory C:\xampp\htdocs\wetinuneed\application\controllers\wun_admin\Dashboard.php 2
ERROR - 2018-11-20 11:58:59 --> Severity: Compile Error --> require(): Failed opening required 'common/Index_Controller.php' (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\wetinuneed\application\controllers\wun_admin\Dashboard.php 2
INFO - 2018-11-20 12:00:06 --> Config Class Initialized
INFO - 2018-11-20 12:00:06 --> Hooks Class Initialized
DEBUG - 2018-11-20 12:00:06 --> UTF-8 Support Enabled
INFO - 2018-11-20 12:00:06 --> Utf8 Class Initialized
INFO - 2018-11-20 12:00:06 --> URI Class Initialized
INFO - 2018-11-20 12:00:06 --> Router Class Initialized
INFO - 2018-11-20 12:00:06 --> Output Class Initialized
INFO - 2018-11-20 12:00:06 --> Security Class Initialized
DEBUG - 2018-11-20 12:00:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-20 12:00:06 --> Input Class Initialized
INFO - 2018-11-20 12:00:06 --> Language Class Initialized
INFO - 2018-11-20 12:00:06 --> Loader Class Initialized
INFO - 2018-11-20 12:00:06 --> Helper loaded: url_helper
INFO - 2018-11-20 12:00:06 --> Helper loaded: file_helper
INFO - 2018-11-20 12:00:06 --> Helper loaded: email_helper
INFO - 2018-11-20 12:00:06 --> Helper loaded: common_helper
INFO - 2018-11-20 12:00:06 --> Database Driver Class Initialized
DEBUG - 2018-11-20 12:00:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-20 12:00:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-20 12:00:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-20 12:00:06 --> Pagination Class Initialized
INFO - 2018-11-20 12:00:06 --> Helper loaded: form_helper
INFO - 2018-11-20 12:00:06 --> Form Validation Class Initialized
INFO - 2018-11-20 12:00:06 --> Model Class Initialized
INFO - 2018-11-20 12:00:06 --> Controller Class Initialized
INFO - 2018-11-20 12:00:06 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-20 12:00:06 --> Model Class Initialized
INFO - 2018-11-20 12:00:06 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-20 12:00:06 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/sidebar.php
INFO - 2018-11-20 12:00:06 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/dashboard.php
INFO - 2018-11-20 12:00:06 --> Final output sent to browser
DEBUG - 2018-11-20 12:00:06 --> Total execution time: 0.0520
INFO - 2018-11-20 12:00:48 --> Config Class Initialized
INFO - 2018-11-20 12:00:48 --> Hooks Class Initialized
DEBUG - 2018-11-20 12:00:48 --> UTF-8 Support Enabled
INFO - 2018-11-20 12:00:48 --> Utf8 Class Initialized
INFO - 2018-11-20 12:00:48 --> URI Class Initialized
INFO - 2018-11-20 12:00:48 --> Router Class Initialized
INFO - 2018-11-20 12:00:48 --> Output Class Initialized
INFO - 2018-11-20 12:00:48 --> Security Class Initialized
DEBUG - 2018-11-20 12:00:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-20 12:00:48 --> Input Class Initialized
INFO - 2018-11-20 12:00:48 --> Language Class Initialized
ERROR - 2018-11-20 12:00:48 --> Severity: Warning --> require(./common/Index_Controller.php): failed to open stream: No such file or directory C:\xampp\htdocs\wetinuneed\application\controllers\wun_admin\Dashboard.php 2
ERROR - 2018-11-20 12:00:48 --> Severity: Compile Error --> require(): Failed opening required './common/Index_Controller.php' (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\wetinuneed\application\controllers\wun_admin\Dashboard.php 2
INFO - 2018-11-20 12:00:54 --> Config Class Initialized
INFO - 2018-11-20 12:00:54 --> Hooks Class Initialized
DEBUG - 2018-11-20 12:00:54 --> UTF-8 Support Enabled
INFO - 2018-11-20 12:00:54 --> Utf8 Class Initialized
INFO - 2018-11-20 12:00:54 --> URI Class Initialized
INFO - 2018-11-20 12:00:54 --> Router Class Initialized
INFO - 2018-11-20 12:00:54 --> Output Class Initialized
INFO - 2018-11-20 12:00:54 --> Security Class Initialized
DEBUG - 2018-11-20 12:00:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-20 12:00:54 --> Input Class Initialized
INFO - 2018-11-20 12:00:54 --> Language Class Initialized
ERROR - 2018-11-20 12:00:54 --> Severity: Warning --> require(../common/Index_Controller.php): failed to open stream: No such file or directory C:\xampp\htdocs\wetinuneed\application\controllers\wun_admin\Dashboard.php 2
ERROR - 2018-11-20 12:00:54 --> Severity: Compile Error --> require(): Failed opening required '../common/Index_Controller.php' (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\wetinuneed\application\controllers\wun_admin\Dashboard.php 2
INFO - 2018-11-20 12:00:54 --> Config Class Initialized
INFO - 2018-11-20 12:00:54 --> Hooks Class Initialized
DEBUG - 2018-11-20 12:00:54 --> UTF-8 Support Enabled
INFO - 2018-11-20 12:00:54 --> Utf8 Class Initialized
INFO - 2018-11-20 12:00:54 --> URI Class Initialized
INFO - 2018-11-20 12:00:54 --> Router Class Initialized
INFO - 2018-11-20 12:00:54 --> Output Class Initialized
INFO - 2018-11-20 12:00:54 --> Security Class Initialized
DEBUG - 2018-11-20 12:00:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-20 12:00:54 --> Input Class Initialized
INFO - 2018-11-20 12:00:54 --> Language Class Initialized
ERROR - 2018-11-20 12:00:54 --> Severity: Warning --> require(../common/Index_Controller.php): failed to open stream: No such file or directory C:\xampp\htdocs\wetinuneed\application\controllers\wun_admin\Dashboard.php 2
ERROR - 2018-11-20 12:00:54 --> Severity: Compile Error --> require(): Failed opening required '../common/Index_Controller.php' (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\wetinuneed\application\controllers\wun_admin\Dashboard.php 2
INFO - 2018-11-20 12:00:54 --> Config Class Initialized
INFO - 2018-11-20 12:00:54 --> Hooks Class Initialized
DEBUG - 2018-11-20 12:00:54 --> UTF-8 Support Enabled
INFO - 2018-11-20 12:00:54 --> Utf8 Class Initialized
INFO - 2018-11-20 12:00:54 --> URI Class Initialized
INFO - 2018-11-20 12:00:54 --> Router Class Initialized
INFO - 2018-11-20 12:00:54 --> Output Class Initialized
INFO - 2018-11-20 12:00:54 --> Security Class Initialized
DEBUG - 2018-11-20 12:00:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-20 12:00:54 --> Input Class Initialized
INFO - 2018-11-20 12:00:54 --> Language Class Initialized
ERROR - 2018-11-20 12:00:54 --> Severity: Warning --> require(../common/Index_Controller.php): failed to open stream: No such file or directory C:\xampp\htdocs\wetinuneed\application\controllers\wun_admin\Dashboard.php 2
ERROR - 2018-11-20 12:00:54 --> Severity: Compile Error --> require(): Failed opening required '../common/Index_Controller.php' (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\wetinuneed\application\controllers\wun_admin\Dashboard.php 2
INFO - 2018-11-20 12:00:55 --> Config Class Initialized
INFO - 2018-11-20 12:00:55 --> Hooks Class Initialized
DEBUG - 2018-11-20 12:00:55 --> UTF-8 Support Enabled
INFO - 2018-11-20 12:00:55 --> Utf8 Class Initialized
INFO - 2018-11-20 12:00:55 --> URI Class Initialized
INFO - 2018-11-20 12:00:55 --> Router Class Initialized
INFO - 2018-11-20 12:00:55 --> Output Class Initialized
INFO - 2018-11-20 12:00:55 --> Security Class Initialized
DEBUG - 2018-11-20 12:00:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-20 12:00:55 --> Input Class Initialized
INFO - 2018-11-20 12:00:55 --> Language Class Initialized
ERROR - 2018-11-20 12:00:55 --> Severity: Warning --> require(../common/Index_Controller.php): failed to open stream: No such file or directory C:\xampp\htdocs\wetinuneed\application\controllers\wun_admin\Dashboard.php 2
ERROR - 2018-11-20 12:00:55 --> Severity: Compile Error --> require(): Failed opening required '../common/Index_Controller.php' (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\wetinuneed\application\controllers\wun_admin\Dashboard.php 2
INFO - 2018-11-20 12:01:13 --> Config Class Initialized
INFO - 2018-11-20 12:01:13 --> Hooks Class Initialized
DEBUG - 2018-11-20 12:01:13 --> UTF-8 Support Enabled
INFO - 2018-11-20 12:01:13 --> Utf8 Class Initialized
INFO - 2018-11-20 12:01:13 --> URI Class Initialized
INFO - 2018-11-20 12:01:13 --> Router Class Initialized
INFO - 2018-11-20 12:01:13 --> Output Class Initialized
INFO - 2018-11-20 12:01:13 --> Security Class Initialized
DEBUG - 2018-11-20 12:01:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-20 12:01:13 --> Input Class Initialized
INFO - 2018-11-20 12:01:13 --> Language Class Initialized
INFO - 2018-11-20 12:01:13 --> Loader Class Initialized
INFO - 2018-11-20 12:01:13 --> Helper loaded: url_helper
INFO - 2018-11-20 12:01:13 --> Helper loaded: file_helper
INFO - 2018-11-20 12:01:13 --> Helper loaded: email_helper
INFO - 2018-11-20 12:01:13 --> Helper loaded: common_helper
INFO - 2018-11-20 12:01:13 --> Database Driver Class Initialized
DEBUG - 2018-11-20 12:01:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-20 12:01:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-20 12:01:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-20 12:01:13 --> Pagination Class Initialized
INFO - 2018-11-20 12:01:13 --> Helper loaded: form_helper
INFO - 2018-11-20 12:01:13 --> Form Validation Class Initialized
INFO - 2018-11-20 12:01:13 --> Model Class Initialized
INFO - 2018-11-20 12:01:13 --> Controller Class Initialized
INFO - 2018-11-20 12:01:13 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-20 12:01:13 --> Model Class Initialized
INFO - 2018-11-20 12:01:13 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-20 12:01:13 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/sidebar.php
INFO - 2018-11-20 12:01:13 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/dashboard.php
INFO - 2018-11-20 12:01:13 --> Final output sent to browser
DEBUG - 2018-11-20 12:01:13 --> Total execution time: 0.0700
INFO - 2018-11-20 12:01:28 --> Config Class Initialized
INFO - 2018-11-20 12:01:28 --> Hooks Class Initialized
DEBUG - 2018-11-20 12:01:28 --> UTF-8 Support Enabled
INFO - 2018-11-20 12:01:28 --> Utf8 Class Initialized
INFO - 2018-11-20 12:01:28 --> URI Class Initialized
INFO - 2018-11-20 12:01:28 --> Router Class Initialized
INFO - 2018-11-20 12:01:28 --> Output Class Initialized
INFO - 2018-11-20 12:01:28 --> Security Class Initialized
DEBUG - 2018-11-20 12:01:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-20 12:01:28 --> Input Class Initialized
INFO - 2018-11-20 12:01:28 --> Language Class Initialized
INFO - 2018-11-20 12:01:28 --> Loader Class Initialized
INFO - 2018-11-20 12:01:28 --> Helper loaded: url_helper
INFO - 2018-11-20 12:01:28 --> Helper loaded: file_helper
INFO - 2018-11-20 12:01:28 --> Helper loaded: email_helper
INFO - 2018-11-20 12:01:28 --> Helper loaded: common_helper
INFO - 2018-11-20 12:01:28 --> Database Driver Class Initialized
DEBUG - 2018-11-20 12:01:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-20 12:01:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-20 12:01:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-20 12:01:28 --> Pagination Class Initialized
INFO - 2018-11-20 12:01:28 --> Helper loaded: form_helper
INFO - 2018-11-20 12:01:28 --> Form Validation Class Initialized
INFO - 2018-11-20 12:01:28 --> Model Class Initialized
INFO - 2018-11-20 12:01:28 --> Controller Class Initialized
INFO - 2018-11-20 12:01:28 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-20 12:01:28 --> Model Class Initialized
INFO - 2018-11-20 12:01:28 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-20 12:01:28 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/sidebar.php
INFO - 2018-11-20 12:01:28 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/dashboard.php
INFO - 2018-11-20 12:01:28 --> Final output sent to browser
DEBUG - 2018-11-20 12:01:28 --> Total execution time: 0.0620
INFO - 2018-11-20 12:08:18 --> Config Class Initialized
INFO - 2018-11-20 12:08:18 --> Hooks Class Initialized
DEBUG - 2018-11-20 12:08:18 --> UTF-8 Support Enabled
INFO - 2018-11-20 12:08:18 --> Utf8 Class Initialized
INFO - 2018-11-20 12:08:18 --> URI Class Initialized
INFO - 2018-11-20 12:08:18 --> Router Class Initialized
INFO - 2018-11-20 12:08:18 --> Output Class Initialized
INFO - 2018-11-20 12:08:18 --> Security Class Initialized
DEBUG - 2018-11-20 12:08:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-20 12:08:18 --> Input Class Initialized
INFO - 2018-11-20 12:08:18 --> Language Class Initialized
INFO - 2018-11-20 12:08:18 --> Loader Class Initialized
INFO - 2018-11-20 12:08:18 --> Helper loaded: url_helper
INFO - 2018-11-20 12:08:18 --> Helper loaded: file_helper
INFO - 2018-11-20 12:08:18 --> Helper loaded: email_helper
INFO - 2018-11-20 12:08:18 --> Helper loaded: common_helper
INFO - 2018-11-20 12:08:18 --> Database Driver Class Initialized
DEBUG - 2018-11-20 12:08:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-20 12:08:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-20 12:08:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-20 12:08:18 --> Pagination Class Initialized
INFO - 2018-11-20 12:08:18 --> Helper loaded: form_helper
INFO - 2018-11-20 12:08:18 --> Form Validation Class Initialized
INFO - 2018-11-20 12:08:18 --> Model Class Initialized
INFO - 2018-11-20 12:08:18 --> Controller Class Initialized
INFO - 2018-11-20 12:08:18 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-20 12:08:18 --> Model Class Initialized
INFO - 2018-11-20 12:08:18 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-20 12:08:18 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/sidebar.php
INFO - 2018-11-20 12:08:18 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/right-sidebar.php
INFO - 2018-11-20 12:08:18 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/dashboard.php
INFO - 2018-11-20 12:08:18 --> Final output sent to browser
DEBUG - 2018-11-20 12:08:18 --> Total execution time: 0.0550
INFO - 2018-11-20 12:08:19 --> Config Class Initialized
INFO - 2018-11-20 12:08:19 --> Hooks Class Initialized
DEBUG - 2018-11-20 12:08:19 --> UTF-8 Support Enabled
INFO - 2018-11-20 12:08:19 --> Utf8 Class Initialized
INFO - 2018-11-20 12:08:19 --> URI Class Initialized
INFO - 2018-11-20 12:08:19 --> Router Class Initialized
INFO - 2018-11-20 12:08:19 --> Output Class Initialized
INFO - 2018-11-20 12:08:19 --> Security Class Initialized
DEBUG - 2018-11-20 12:08:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-20 12:08:19 --> Input Class Initialized
INFO - 2018-11-20 12:08:19 --> Language Class Initialized
INFO - 2018-11-20 12:08:19 --> Loader Class Initialized
INFO - 2018-11-20 12:08:19 --> Helper loaded: url_helper
INFO - 2018-11-20 12:08:19 --> Helper loaded: file_helper
INFO - 2018-11-20 12:08:19 --> Helper loaded: email_helper
INFO - 2018-11-20 12:08:19 --> Helper loaded: common_helper
INFO - 2018-11-20 12:08:19 --> Database Driver Class Initialized
DEBUG - 2018-11-20 12:08:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-20 12:08:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-20 12:08:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-20 12:08:19 --> Pagination Class Initialized
INFO - 2018-11-20 12:08:19 --> Helper loaded: form_helper
INFO - 2018-11-20 12:08:19 --> Form Validation Class Initialized
INFO - 2018-11-20 12:08:19 --> Model Class Initialized
INFO - 2018-11-20 12:08:19 --> Controller Class Initialized
INFO - 2018-11-20 12:08:19 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-20 12:08:19 --> Model Class Initialized
INFO - 2018-11-20 12:08:19 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-20 12:08:19 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/sidebar.php
INFO - 2018-11-20 12:08:19 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/right-sidebar.php
INFO - 2018-11-20 12:08:19 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/dashboard.php
INFO - 2018-11-20 12:08:19 --> Final output sent to browser
DEBUG - 2018-11-20 12:08:19 --> Total execution time: 0.0530
INFO - 2018-11-20 12:09:26 --> Config Class Initialized
INFO - 2018-11-20 12:09:26 --> Hooks Class Initialized
DEBUG - 2018-11-20 12:09:26 --> UTF-8 Support Enabled
INFO - 2018-11-20 12:09:26 --> Utf8 Class Initialized
INFO - 2018-11-20 12:09:26 --> URI Class Initialized
INFO - 2018-11-20 12:09:26 --> Router Class Initialized
INFO - 2018-11-20 12:09:26 --> Output Class Initialized
INFO - 2018-11-20 12:09:26 --> Security Class Initialized
DEBUG - 2018-11-20 12:09:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-20 12:09:26 --> Input Class Initialized
INFO - 2018-11-20 12:09:26 --> Language Class Initialized
INFO - 2018-11-20 12:09:26 --> Loader Class Initialized
INFO - 2018-11-20 12:09:26 --> Helper loaded: url_helper
INFO - 2018-11-20 12:09:26 --> Helper loaded: file_helper
INFO - 2018-11-20 12:09:26 --> Helper loaded: email_helper
INFO - 2018-11-20 12:09:26 --> Helper loaded: common_helper
INFO - 2018-11-20 12:09:26 --> Database Driver Class Initialized
DEBUG - 2018-11-20 12:09:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-20 12:09:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-20 12:09:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-20 12:09:26 --> Pagination Class Initialized
INFO - 2018-11-20 12:09:26 --> Helper loaded: form_helper
INFO - 2018-11-20 12:09:26 --> Form Validation Class Initialized
INFO - 2018-11-20 12:09:26 --> Model Class Initialized
INFO - 2018-11-20 12:09:26 --> Controller Class Initialized
INFO - 2018-11-20 12:09:26 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-20 12:09:26 --> Model Class Initialized
INFO - 2018-11-20 12:09:26 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-20 12:09:26 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/sidebar.php
INFO - 2018-11-20 12:09:26 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/right-sidebar.php
INFO - 2018-11-20 12:09:26 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/footer.php
INFO - 2018-11-20 12:09:26 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/dashboard.php
INFO - 2018-11-20 12:09:26 --> Final output sent to browser
DEBUG - 2018-11-20 12:09:26 --> Total execution time: 0.0650
INFO - 2018-11-20 12:11:08 --> Config Class Initialized
INFO - 2018-11-20 12:11:08 --> Hooks Class Initialized
DEBUG - 2018-11-20 12:11:08 --> UTF-8 Support Enabled
INFO - 2018-11-20 12:11:08 --> Utf8 Class Initialized
INFO - 2018-11-20 12:11:08 --> URI Class Initialized
INFO - 2018-11-20 12:11:08 --> Router Class Initialized
INFO - 2018-11-20 12:11:08 --> Output Class Initialized
INFO - 2018-11-20 12:11:08 --> Security Class Initialized
DEBUG - 2018-11-20 12:11:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-20 12:11:08 --> Input Class Initialized
INFO - 2018-11-20 12:11:08 --> Language Class Initialized
INFO - 2018-11-20 12:11:08 --> Loader Class Initialized
INFO - 2018-11-20 12:11:08 --> Helper loaded: url_helper
INFO - 2018-11-20 12:11:08 --> Helper loaded: file_helper
INFO - 2018-11-20 12:11:08 --> Helper loaded: email_helper
INFO - 2018-11-20 12:11:08 --> Helper loaded: common_helper
INFO - 2018-11-20 12:11:08 --> Database Driver Class Initialized
DEBUG - 2018-11-20 12:11:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-20 12:11:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-20 12:11:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-20 12:11:08 --> Pagination Class Initialized
INFO - 2018-11-20 12:11:08 --> Helper loaded: form_helper
INFO - 2018-11-20 12:11:08 --> Form Validation Class Initialized
INFO - 2018-11-20 12:11:08 --> Model Class Initialized
INFO - 2018-11-20 12:11:08 --> Controller Class Initialized
INFO - 2018-11-20 12:11:08 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-20 12:11:08 --> Model Class Initialized
INFO - 2018-11-20 12:11:08 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-20 12:11:08 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/sidebar.php
INFO - 2018-11-20 12:11:08 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/right-sidebar.php
INFO - 2018-11-20 12:11:08 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/footer.php
INFO - 2018-11-20 12:11:08 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/dashboard.php
INFO - 2018-11-20 12:11:08 --> Final output sent to browser
DEBUG - 2018-11-20 12:11:08 --> Total execution time: 0.0550
INFO - 2018-11-20 12:12:08 --> Config Class Initialized
INFO - 2018-11-20 12:12:08 --> Hooks Class Initialized
DEBUG - 2018-11-20 12:12:08 --> UTF-8 Support Enabled
INFO - 2018-11-20 12:12:08 --> Utf8 Class Initialized
INFO - 2018-11-20 12:12:08 --> URI Class Initialized
INFO - 2018-11-20 12:12:08 --> Router Class Initialized
INFO - 2018-11-20 12:12:08 --> Output Class Initialized
INFO - 2018-11-20 12:12:08 --> Security Class Initialized
DEBUG - 2018-11-20 12:12:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-20 12:12:08 --> Input Class Initialized
INFO - 2018-11-20 12:12:08 --> Language Class Initialized
INFO - 2018-11-20 12:12:08 --> Loader Class Initialized
INFO - 2018-11-20 12:12:08 --> Helper loaded: url_helper
INFO - 2018-11-20 12:12:08 --> Helper loaded: file_helper
INFO - 2018-11-20 12:12:08 --> Helper loaded: email_helper
INFO - 2018-11-20 12:12:08 --> Helper loaded: common_helper
INFO - 2018-11-20 12:12:08 --> Database Driver Class Initialized
DEBUG - 2018-11-20 12:12:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-20 12:12:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-20 12:12:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-20 12:12:08 --> Pagination Class Initialized
INFO - 2018-11-20 12:12:08 --> Helper loaded: form_helper
INFO - 2018-11-20 12:12:08 --> Form Validation Class Initialized
INFO - 2018-11-20 12:12:08 --> Model Class Initialized
INFO - 2018-11-20 12:12:08 --> Controller Class Initialized
INFO - 2018-11-20 12:12:08 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-20 12:12:08 --> Model Class Initialized
INFO - 2018-11-20 12:12:08 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-20 12:12:08 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/sidebar.php
INFO - 2018-11-20 12:12:08 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/right-sidebar.php
INFO - 2018-11-20 12:12:08 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/footer.php
INFO - 2018-11-20 12:12:08 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/dashboard.php
INFO - 2018-11-20 12:12:08 --> Final output sent to browser
DEBUG - 2018-11-20 12:12:08 --> Total execution time: 0.0560
INFO - 2018-11-20 12:12:35 --> Config Class Initialized
INFO - 2018-11-20 12:12:35 --> Hooks Class Initialized
DEBUG - 2018-11-20 12:12:35 --> UTF-8 Support Enabled
INFO - 2018-11-20 12:12:35 --> Utf8 Class Initialized
INFO - 2018-11-20 12:12:35 --> URI Class Initialized
INFO - 2018-11-20 12:12:35 --> Router Class Initialized
INFO - 2018-11-20 12:12:35 --> Output Class Initialized
INFO - 2018-11-20 12:12:35 --> Security Class Initialized
DEBUG - 2018-11-20 12:12:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-20 12:12:35 --> Input Class Initialized
INFO - 2018-11-20 12:12:35 --> Language Class Initialized
INFO - 2018-11-20 12:12:35 --> Loader Class Initialized
INFO - 2018-11-20 12:12:35 --> Helper loaded: url_helper
INFO - 2018-11-20 12:12:35 --> Helper loaded: file_helper
INFO - 2018-11-20 12:12:35 --> Helper loaded: email_helper
INFO - 2018-11-20 12:12:35 --> Helper loaded: common_helper
INFO - 2018-11-20 12:12:35 --> Database Driver Class Initialized
DEBUG - 2018-11-20 12:12:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-20 12:12:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-20 12:12:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-20 12:12:35 --> Pagination Class Initialized
INFO - 2018-11-20 12:12:35 --> Helper loaded: form_helper
INFO - 2018-11-20 12:12:35 --> Form Validation Class Initialized
INFO - 2018-11-20 12:12:35 --> Model Class Initialized
INFO - 2018-11-20 12:12:35 --> Controller Class Initialized
INFO - 2018-11-20 12:12:35 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-20 12:12:35 --> Model Class Initialized
INFO - 2018-11-20 12:12:35 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-20 12:12:35 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/sidebar.php
INFO - 2018-11-20 12:12:35 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/right-sidebar.php
INFO - 2018-11-20 12:12:35 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/footer.php
INFO - 2018-11-20 12:12:35 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/dashboard.php
INFO - 2018-11-20 12:12:35 --> Final output sent to browser
DEBUG - 2018-11-20 12:12:35 --> Total execution time: 0.0700
INFO - 2018-11-20 12:13:47 --> Config Class Initialized
INFO - 2018-11-20 12:13:47 --> Hooks Class Initialized
DEBUG - 2018-11-20 12:13:47 --> UTF-8 Support Enabled
INFO - 2018-11-20 12:13:47 --> Utf8 Class Initialized
INFO - 2018-11-20 12:13:47 --> URI Class Initialized
INFO - 2018-11-20 12:13:47 --> Router Class Initialized
INFO - 2018-11-20 12:13:47 --> Output Class Initialized
INFO - 2018-11-20 12:13:47 --> Security Class Initialized
DEBUG - 2018-11-20 12:13:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-20 12:13:47 --> Input Class Initialized
INFO - 2018-11-20 12:13:47 --> Language Class Initialized
INFO - 2018-11-20 12:13:47 --> Loader Class Initialized
INFO - 2018-11-20 12:13:47 --> Helper loaded: url_helper
INFO - 2018-11-20 12:13:47 --> Helper loaded: file_helper
INFO - 2018-11-20 12:13:47 --> Helper loaded: email_helper
INFO - 2018-11-20 12:13:47 --> Helper loaded: common_helper
INFO - 2018-11-20 12:13:47 --> Database Driver Class Initialized
DEBUG - 2018-11-20 12:13:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-20 12:13:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-20 12:13:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-20 12:13:47 --> Pagination Class Initialized
INFO - 2018-11-20 12:13:47 --> Helper loaded: form_helper
INFO - 2018-11-20 12:13:47 --> Form Validation Class Initialized
INFO - 2018-11-20 12:13:47 --> Model Class Initialized
INFO - 2018-11-20 12:13:47 --> Controller Class Initialized
INFO - 2018-11-20 12:13:47 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-20 12:13:47 --> Model Class Initialized
INFO - 2018-11-20 12:13:47 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-20 12:13:47 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/sidebar.php
INFO - 2018-11-20 12:13:47 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/right-sidebar.php
INFO - 2018-11-20 12:13:47 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/footer.php
INFO - 2018-11-20 12:13:47 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/dashboard.php
INFO - 2018-11-20 12:13:47 --> Final output sent to browser
DEBUG - 2018-11-20 12:13:47 --> Total execution time: 0.0720
INFO - 2018-11-20 12:13:53 --> Config Class Initialized
INFO - 2018-11-20 12:13:53 --> Hooks Class Initialized
DEBUG - 2018-11-20 12:13:53 --> UTF-8 Support Enabled
INFO - 2018-11-20 12:13:53 --> Utf8 Class Initialized
INFO - 2018-11-20 12:13:53 --> URI Class Initialized
INFO - 2018-11-20 12:13:53 --> Router Class Initialized
INFO - 2018-11-20 12:13:53 --> Output Class Initialized
INFO - 2018-11-20 12:13:53 --> Security Class Initialized
DEBUG - 2018-11-20 12:13:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-20 12:13:53 --> Input Class Initialized
INFO - 2018-11-20 12:13:53 --> Language Class Initialized
ERROR - 2018-11-20 12:13:53 --> 404 Page Not Found: wun_admin/Indexhtml/index
INFO - 2018-11-20 12:13:56 --> Config Class Initialized
INFO - 2018-11-20 12:13:56 --> Hooks Class Initialized
DEBUG - 2018-11-20 12:13:56 --> UTF-8 Support Enabled
INFO - 2018-11-20 12:13:56 --> Utf8 Class Initialized
INFO - 2018-11-20 12:13:56 --> URI Class Initialized
INFO - 2018-11-20 12:13:56 --> Router Class Initialized
INFO - 2018-11-20 12:13:56 --> Output Class Initialized
INFO - 2018-11-20 12:13:56 --> Security Class Initialized
DEBUG - 2018-11-20 12:13:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-20 12:13:56 --> Input Class Initialized
INFO - 2018-11-20 12:13:56 --> Language Class Initialized
INFO - 2018-11-20 12:13:56 --> Loader Class Initialized
INFO - 2018-11-20 12:13:56 --> Helper loaded: url_helper
INFO - 2018-11-20 12:13:56 --> Helper loaded: file_helper
INFO - 2018-11-20 12:13:56 --> Helper loaded: email_helper
INFO - 2018-11-20 12:13:56 --> Helper loaded: common_helper
INFO - 2018-11-20 12:13:56 --> Database Driver Class Initialized
DEBUG - 2018-11-20 12:13:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-20 12:13:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-20 12:13:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-20 12:13:56 --> Pagination Class Initialized
INFO - 2018-11-20 12:13:56 --> Helper loaded: form_helper
INFO - 2018-11-20 12:13:56 --> Form Validation Class Initialized
INFO - 2018-11-20 12:13:56 --> Model Class Initialized
INFO - 2018-11-20 12:13:56 --> Controller Class Initialized
INFO - 2018-11-20 12:13:56 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-20 12:13:56 --> Model Class Initialized
INFO - 2018-11-20 12:13:56 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-20 12:13:56 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/sidebar.php
INFO - 2018-11-20 12:13:56 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/right-sidebar.php
INFO - 2018-11-20 12:13:56 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/footer.php
INFO - 2018-11-20 12:13:56 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/dashboard.php
INFO - 2018-11-20 12:13:56 --> Final output sent to browser
DEBUG - 2018-11-20 12:13:56 --> Total execution time: 0.0540
INFO - 2018-11-20 12:16:04 --> Config Class Initialized
INFO - 2018-11-20 12:16:04 --> Hooks Class Initialized
DEBUG - 2018-11-20 12:16:04 --> UTF-8 Support Enabled
INFO - 2018-11-20 12:16:04 --> Utf8 Class Initialized
INFO - 2018-11-20 12:16:04 --> URI Class Initialized
INFO - 2018-11-20 12:16:04 --> Router Class Initialized
INFO - 2018-11-20 12:16:04 --> Output Class Initialized
INFO - 2018-11-20 12:16:04 --> Security Class Initialized
DEBUG - 2018-11-20 12:16:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-20 12:16:04 --> Input Class Initialized
INFO - 2018-11-20 12:16:04 --> Language Class Initialized
INFO - 2018-11-20 12:16:04 --> Loader Class Initialized
INFO - 2018-11-20 12:16:04 --> Helper loaded: url_helper
INFO - 2018-11-20 12:16:04 --> Helper loaded: file_helper
INFO - 2018-11-20 12:16:04 --> Helper loaded: email_helper
INFO - 2018-11-20 12:16:04 --> Helper loaded: common_helper
INFO - 2018-11-20 12:16:04 --> Database Driver Class Initialized
DEBUG - 2018-11-20 12:16:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-20 12:16:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-20 12:16:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-20 12:16:04 --> Pagination Class Initialized
INFO - 2018-11-20 12:16:04 --> Helper loaded: form_helper
INFO - 2018-11-20 12:16:04 --> Form Validation Class Initialized
INFO - 2018-11-20 12:16:04 --> Model Class Initialized
INFO - 2018-11-20 12:16:04 --> Controller Class Initialized
INFO - 2018-11-20 12:16:04 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-20 12:16:04 --> Model Class Initialized
INFO - 2018-11-20 12:16:04 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-20 12:16:04 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/sidebar.php
INFO - 2018-11-20 12:16:04 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/right-sidebar.php
INFO - 2018-11-20 12:16:04 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/footer.php
INFO - 2018-11-20 12:16:04 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/dashboard.php
INFO - 2018-11-20 12:16:04 --> Final output sent to browser
DEBUG - 2018-11-20 12:16:04 --> Total execution time: 0.0640
INFO - 2018-11-20 12:16:08 --> Config Class Initialized
INFO - 2018-11-20 12:16:08 --> Hooks Class Initialized
DEBUG - 2018-11-20 12:16:08 --> UTF-8 Support Enabled
INFO - 2018-11-20 12:16:08 --> Utf8 Class Initialized
INFO - 2018-11-20 12:16:08 --> URI Class Initialized
INFO - 2018-11-20 12:16:08 --> Router Class Initialized
INFO - 2018-11-20 12:16:08 --> Output Class Initialized
INFO - 2018-11-20 12:16:08 --> Security Class Initialized
DEBUG - 2018-11-20 12:16:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-20 12:16:08 --> Input Class Initialized
INFO - 2018-11-20 12:16:08 --> Language Class Initialized
INFO - 2018-11-20 12:16:08 --> Loader Class Initialized
INFO - 2018-11-20 12:16:08 --> Helper loaded: url_helper
INFO - 2018-11-20 12:16:08 --> Helper loaded: file_helper
INFO - 2018-11-20 12:16:08 --> Helper loaded: email_helper
INFO - 2018-11-20 12:16:08 --> Helper loaded: common_helper
INFO - 2018-11-20 12:16:08 --> Database Driver Class Initialized
DEBUG - 2018-11-20 12:16:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-20 12:16:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-20 12:16:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-20 12:16:08 --> Pagination Class Initialized
INFO - 2018-11-20 12:16:08 --> Helper loaded: form_helper
INFO - 2018-11-20 12:16:08 --> Form Validation Class Initialized
INFO - 2018-11-20 12:16:08 --> Model Class Initialized
INFO - 2018-11-20 12:16:08 --> Controller Class Initialized
INFO - 2018-11-20 12:16:08 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-20 12:16:08 --> Model Class Initialized
INFO - 2018-11-20 12:16:08 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-20 12:16:08 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/sidebar.php
INFO - 2018-11-20 12:16:08 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/right-sidebar.php
INFO - 2018-11-20 12:16:08 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/footer.php
INFO - 2018-11-20 12:16:08 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/dashboard.php
INFO - 2018-11-20 12:16:08 --> Final output sent to browser
DEBUG - 2018-11-20 12:16:08 --> Total execution time: 0.0580
INFO - 2018-11-20 12:16:41 --> Config Class Initialized
INFO - 2018-11-20 12:16:41 --> Hooks Class Initialized
DEBUG - 2018-11-20 12:16:41 --> UTF-8 Support Enabled
INFO - 2018-11-20 12:16:41 --> Utf8 Class Initialized
INFO - 2018-11-20 12:16:41 --> URI Class Initialized
INFO - 2018-11-20 12:16:41 --> Router Class Initialized
INFO - 2018-11-20 12:16:41 --> Output Class Initialized
INFO - 2018-11-20 12:16:41 --> Security Class Initialized
DEBUG - 2018-11-20 12:16:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-20 12:16:41 --> Input Class Initialized
INFO - 2018-11-20 12:16:41 --> Language Class Initialized
INFO - 2018-11-20 12:16:41 --> Loader Class Initialized
INFO - 2018-11-20 12:16:41 --> Helper loaded: url_helper
INFO - 2018-11-20 12:16:41 --> Helper loaded: file_helper
INFO - 2018-11-20 12:16:41 --> Helper loaded: email_helper
INFO - 2018-11-20 12:16:41 --> Helper loaded: common_helper
INFO - 2018-11-20 12:16:41 --> Database Driver Class Initialized
DEBUG - 2018-11-20 12:16:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-20 12:16:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-20 12:16:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-20 12:16:41 --> Pagination Class Initialized
INFO - 2018-11-20 12:16:41 --> Helper loaded: form_helper
INFO - 2018-11-20 12:16:41 --> Form Validation Class Initialized
INFO - 2018-11-20 12:16:41 --> Model Class Initialized
INFO - 2018-11-20 12:16:41 --> Controller Class Initialized
INFO - 2018-11-20 12:16:41 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-20 12:16:41 --> Model Class Initialized
INFO - 2018-11-20 12:16:41 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-20 12:16:41 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/sidebar.php
INFO - 2018-11-20 12:16:41 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/right-sidebar.php
INFO - 2018-11-20 12:16:41 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/footer.php
INFO - 2018-11-20 12:16:41 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/dashboard.php
INFO - 2018-11-20 12:16:41 --> Final output sent to browser
DEBUG - 2018-11-20 12:16:41 --> Total execution time: 0.0520
INFO - 2018-11-20 12:17:31 --> Config Class Initialized
INFO - 2018-11-20 12:17:31 --> Hooks Class Initialized
DEBUG - 2018-11-20 12:17:31 --> UTF-8 Support Enabled
INFO - 2018-11-20 12:17:31 --> Utf8 Class Initialized
INFO - 2018-11-20 12:17:31 --> URI Class Initialized
INFO - 2018-11-20 12:17:31 --> Router Class Initialized
INFO - 2018-11-20 12:17:31 --> Output Class Initialized
INFO - 2018-11-20 12:17:31 --> Security Class Initialized
DEBUG - 2018-11-20 12:17:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-20 12:17:31 --> Input Class Initialized
INFO - 2018-11-20 12:17:31 --> Language Class Initialized
INFO - 2018-11-20 12:17:31 --> Loader Class Initialized
INFO - 2018-11-20 12:17:31 --> Helper loaded: url_helper
INFO - 2018-11-20 12:17:31 --> Helper loaded: file_helper
INFO - 2018-11-20 12:17:31 --> Helper loaded: email_helper
INFO - 2018-11-20 12:17:31 --> Helper loaded: common_helper
INFO - 2018-11-20 12:17:31 --> Database Driver Class Initialized
DEBUG - 2018-11-20 12:17:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-20 12:17:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-20 12:17:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-20 12:17:31 --> Pagination Class Initialized
INFO - 2018-11-20 12:17:31 --> Helper loaded: form_helper
INFO - 2018-11-20 12:17:31 --> Form Validation Class Initialized
INFO - 2018-11-20 12:17:31 --> Model Class Initialized
INFO - 2018-11-20 12:17:31 --> Controller Class Initialized
INFO - 2018-11-20 12:17:31 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-20 12:17:31 --> Model Class Initialized
INFO - 2018-11-20 12:17:31 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-20 12:17:31 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/sidebar.php
INFO - 2018-11-20 12:17:31 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/right-sidebar.php
INFO - 2018-11-20 12:17:31 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/footer.php
INFO - 2018-11-20 12:17:31 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/dashboard.php
INFO - 2018-11-20 12:17:31 --> Final output sent to browser
DEBUG - 2018-11-20 12:17:31 --> Total execution time: 0.0590
INFO - 2018-11-20 12:18:01 --> Config Class Initialized
INFO - 2018-11-20 12:18:01 --> Hooks Class Initialized
DEBUG - 2018-11-20 12:18:01 --> UTF-8 Support Enabled
INFO - 2018-11-20 12:18:01 --> Utf8 Class Initialized
INFO - 2018-11-20 12:18:01 --> URI Class Initialized
INFO - 2018-11-20 12:18:01 --> Router Class Initialized
INFO - 2018-11-20 12:18:01 --> Output Class Initialized
INFO - 2018-11-20 12:18:01 --> Security Class Initialized
DEBUG - 2018-11-20 12:18:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-20 12:18:01 --> Input Class Initialized
INFO - 2018-11-20 12:18:01 --> Language Class Initialized
INFO - 2018-11-20 12:18:01 --> Loader Class Initialized
INFO - 2018-11-20 12:18:01 --> Helper loaded: url_helper
INFO - 2018-11-20 12:18:01 --> Helper loaded: file_helper
INFO - 2018-11-20 12:18:01 --> Helper loaded: email_helper
INFO - 2018-11-20 12:18:01 --> Helper loaded: common_helper
INFO - 2018-11-20 12:18:01 --> Database Driver Class Initialized
DEBUG - 2018-11-20 12:18:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-20 12:18:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-20 12:18:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-20 12:18:01 --> Pagination Class Initialized
INFO - 2018-11-20 12:18:01 --> Helper loaded: form_helper
INFO - 2018-11-20 12:18:01 --> Form Validation Class Initialized
INFO - 2018-11-20 12:18:01 --> Model Class Initialized
INFO - 2018-11-20 12:18:01 --> Controller Class Initialized
INFO - 2018-11-20 12:18:01 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-20 12:18:01 --> Model Class Initialized
INFO - 2018-11-20 12:18:01 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-20 12:18:01 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/sidebar.php
INFO - 2018-11-20 12:18:01 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/right-sidebar.php
INFO - 2018-11-20 12:18:01 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/footer.php
INFO - 2018-11-20 12:18:01 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/dashboard.php
INFO - 2018-11-20 12:18:01 --> Final output sent to browser
DEBUG - 2018-11-20 12:18:01 --> Total execution time: 0.0450
INFO - 2018-11-20 12:19:49 --> Config Class Initialized
INFO - 2018-11-20 12:19:49 --> Hooks Class Initialized
DEBUG - 2018-11-20 12:19:49 --> UTF-8 Support Enabled
INFO - 2018-11-20 12:19:49 --> Utf8 Class Initialized
INFO - 2018-11-20 12:19:49 --> URI Class Initialized
INFO - 2018-11-20 12:19:49 --> Router Class Initialized
INFO - 2018-11-20 12:19:49 --> Output Class Initialized
INFO - 2018-11-20 12:19:49 --> Security Class Initialized
DEBUG - 2018-11-20 12:19:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-20 12:19:49 --> Input Class Initialized
INFO - 2018-11-20 12:19:49 --> Language Class Initialized
INFO - 2018-11-20 12:19:49 --> Loader Class Initialized
INFO - 2018-11-20 12:19:49 --> Helper loaded: url_helper
INFO - 2018-11-20 12:19:49 --> Helper loaded: file_helper
INFO - 2018-11-20 12:19:49 --> Helper loaded: email_helper
INFO - 2018-11-20 12:19:49 --> Helper loaded: common_helper
INFO - 2018-11-20 12:19:49 --> Database Driver Class Initialized
DEBUG - 2018-11-20 12:19:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-20 12:19:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-20 12:19:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-20 12:19:49 --> Pagination Class Initialized
INFO - 2018-11-20 12:19:49 --> Helper loaded: form_helper
INFO - 2018-11-20 12:19:49 --> Form Validation Class Initialized
INFO - 2018-11-20 12:19:49 --> Model Class Initialized
INFO - 2018-11-20 12:19:49 --> Controller Class Initialized
INFO - 2018-11-20 12:19:49 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-20 12:19:49 --> Model Class Initialized
INFO - 2018-11-20 12:19:49 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-20 12:19:49 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/sidebar.php
INFO - 2018-11-20 12:19:49 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/right-sidebar.php
INFO - 2018-11-20 12:19:49 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/footer.php
INFO - 2018-11-20 12:19:49 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/dashboard.php
INFO - 2018-11-20 12:19:49 --> Final output sent to browser
DEBUG - 2018-11-20 12:19:49 --> Total execution time: 0.0500
INFO - 2018-11-20 12:20:55 --> Config Class Initialized
INFO - 2018-11-20 12:20:55 --> Hooks Class Initialized
DEBUG - 2018-11-20 12:20:55 --> UTF-8 Support Enabled
INFO - 2018-11-20 12:20:55 --> Utf8 Class Initialized
INFO - 2018-11-20 12:20:55 --> URI Class Initialized
INFO - 2018-11-20 12:20:55 --> Router Class Initialized
INFO - 2018-11-20 12:20:55 --> Output Class Initialized
INFO - 2018-11-20 12:20:55 --> Security Class Initialized
DEBUG - 2018-11-20 12:20:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-20 12:20:55 --> Input Class Initialized
INFO - 2018-11-20 12:20:55 --> Language Class Initialized
INFO - 2018-11-20 12:20:55 --> Loader Class Initialized
INFO - 2018-11-20 12:20:55 --> Helper loaded: url_helper
INFO - 2018-11-20 12:20:55 --> Helper loaded: file_helper
INFO - 2018-11-20 12:20:55 --> Helper loaded: email_helper
INFO - 2018-11-20 12:20:55 --> Helper loaded: common_helper
INFO - 2018-11-20 12:20:55 --> Database Driver Class Initialized
DEBUG - 2018-11-20 12:20:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-20 12:20:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-20 12:20:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-20 12:20:55 --> Pagination Class Initialized
INFO - 2018-11-20 12:20:55 --> Helper loaded: form_helper
INFO - 2018-11-20 12:20:55 --> Form Validation Class Initialized
INFO - 2018-11-20 12:20:55 --> Model Class Initialized
INFO - 2018-11-20 12:20:55 --> Controller Class Initialized
INFO - 2018-11-20 12:20:55 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-20 12:20:55 --> Model Class Initialized
INFO - 2018-11-20 12:20:55 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-20 12:20:55 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/sidebar.php
INFO - 2018-11-20 12:20:55 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/right-sidebar.php
INFO - 2018-11-20 12:20:55 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/footer.php
INFO - 2018-11-20 12:20:55 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/dashboard.php
INFO - 2018-11-20 12:20:55 --> Final output sent to browser
DEBUG - 2018-11-20 12:20:55 --> Total execution time: 0.0700
INFO - 2018-11-20 12:21:13 --> Config Class Initialized
INFO - 2018-11-20 12:21:13 --> Hooks Class Initialized
DEBUG - 2018-11-20 12:21:13 --> UTF-8 Support Enabled
INFO - 2018-11-20 12:21:13 --> Utf8 Class Initialized
INFO - 2018-11-20 12:21:13 --> URI Class Initialized
INFO - 2018-11-20 12:21:13 --> Router Class Initialized
INFO - 2018-11-20 12:21:13 --> Output Class Initialized
INFO - 2018-11-20 12:21:13 --> Security Class Initialized
DEBUG - 2018-11-20 12:21:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-20 12:21:13 --> Input Class Initialized
INFO - 2018-11-20 12:21:13 --> Language Class Initialized
INFO - 2018-11-20 12:21:13 --> Loader Class Initialized
INFO - 2018-11-20 12:21:13 --> Helper loaded: url_helper
INFO - 2018-11-20 12:21:13 --> Helper loaded: file_helper
INFO - 2018-11-20 12:21:13 --> Helper loaded: email_helper
INFO - 2018-11-20 12:21:13 --> Helper loaded: common_helper
INFO - 2018-11-20 12:21:13 --> Database Driver Class Initialized
DEBUG - 2018-11-20 12:21:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-20 12:21:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-20 12:21:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-20 12:21:13 --> Pagination Class Initialized
INFO - 2018-11-20 12:21:13 --> Helper loaded: form_helper
INFO - 2018-11-20 12:21:13 --> Form Validation Class Initialized
INFO - 2018-11-20 12:21:13 --> Model Class Initialized
INFO - 2018-11-20 12:21:13 --> Controller Class Initialized
INFO - 2018-11-20 12:21:13 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-20 12:21:13 --> Model Class Initialized
INFO - 2018-11-20 12:21:13 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-20 12:21:13 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/sidebar.php
INFO - 2018-11-20 12:21:13 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/right-sidebar.php
INFO - 2018-11-20 12:21:13 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/footer.php
INFO - 2018-11-20 12:21:13 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/dashboard.php
INFO - 2018-11-20 12:21:13 --> Final output sent to browser
DEBUG - 2018-11-20 12:21:13 --> Total execution time: 0.0600
INFO - 2018-11-20 12:21:40 --> Config Class Initialized
INFO - 2018-11-20 12:21:40 --> Hooks Class Initialized
DEBUG - 2018-11-20 12:21:40 --> UTF-8 Support Enabled
INFO - 2018-11-20 12:21:40 --> Utf8 Class Initialized
INFO - 2018-11-20 12:21:40 --> URI Class Initialized
INFO - 2018-11-20 12:21:40 --> Router Class Initialized
INFO - 2018-11-20 12:21:40 --> Output Class Initialized
INFO - 2018-11-20 12:21:40 --> Security Class Initialized
DEBUG - 2018-11-20 12:21:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-20 12:21:40 --> Input Class Initialized
INFO - 2018-11-20 12:21:40 --> Language Class Initialized
INFO - 2018-11-20 12:21:40 --> Loader Class Initialized
INFO - 2018-11-20 12:21:40 --> Helper loaded: url_helper
INFO - 2018-11-20 12:21:40 --> Helper loaded: file_helper
INFO - 2018-11-20 12:21:40 --> Helper loaded: email_helper
INFO - 2018-11-20 12:21:40 --> Helper loaded: common_helper
INFO - 2018-11-20 12:21:40 --> Database Driver Class Initialized
DEBUG - 2018-11-20 12:21:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-20 12:21:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-20 12:21:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-20 12:21:40 --> Pagination Class Initialized
INFO - 2018-11-20 12:21:40 --> Helper loaded: form_helper
INFO - 2018-11-20 12:21:40 --> Form Validation Class Initialized
INFO - 2018-11-20 12:21:40 --> Model Class Initialized
INFO - 2018-11-20 12:21:40 --> Controller Class Initialized
INFO - 2018-11-20 12:21:40 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-20 12:21:40 --> Model Class Initialized
INFO - 2018-11-20 12:21:40 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-20 12:21:40 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/sidebar.php
INFO - 2018-11-20 12:21:40 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/right-sidebar.php
INFO - 2018-11-20 12:21:40 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/footer.php
INFO - 2018-11-20 12:21:40 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/dashboard.php
INFO - 2018-11-20 12:21:40 --> Final output sent to browser
DEBUG - 2018-11-20 12:21:40 --> Total execution time: 0.0610
INFO - 2018-11-20 12:21:52 --> Config Class Initialized
INFO - 2018-11-20 12:21:52 --> Hooks Class Initialized
DEBUG - 2018-11-20 12:21:52 --> UTF-8 Support Enabled
INFO - 2018-11-20 12:21:52 --> Utf8 Class Initialized
INFO - 2018-11-20 12:21:52 --> URI Class Initialized
INFO - 2018-11-20 12:21:52 --> Router Class Initialized
INFO - 2018-11-20 12:21:52 --> Output Class Initialized
INFO - 2018-11-20 12:21:52 --> Security Class Initialized
DEBUG - 2018-11-20 12:21:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-20 12:21:52 --> Input Class Initialized
INFO - 2018-11-20 12:21:52 --> Language Class Initialized
INFO - 2018-11-20 12:21:52 --> Loader Class Initialized
INFO - 2018-11-20 12:21:52 --> Helper loaded: url_helper
INFO - 2018-11-20 12:21:52 --> Helper loaded: file_helper
INFO - 2018-11-20 12:21:52 --> Helper loaded: email_helper
INFO - 2018-11-20 12:21:52 --> Helper loaded: common_helper
INFO - 2018-11-20 12:21:52 --> Database Driver Class Initialized
DEBUG - 2018-11-20 12:21:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-20 12:21:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-20 12:21:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-20 12:21:52 --> Pagination Class Initialized
INFO - 2018-11-20 12:21:52 --> Helper loaded: form_helper
INFO - 2018-11-20 12:21:52 --> Form Validation Class Initialized
INFO - 2018-11-20 12:21:52 --> Model Class Initialized
INFO - 2018-11-20 12:21:52 --> Controller Class Initialized
INFO - 2018-11-20 12:21:52 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-20 12:21:52 --> Model Class Initialized
INFO - 2018-11-20 12:21:52 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-20 12:21:52 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/sidebar.php
INFO - 2018-11-20 12:21:52 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/right-sidebar.php
INFO - 2018-11-20 12:21:52 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/footer.php
INFO - 2018-11-20 12:21:52 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/dashboard.php
INFO - 2018-11-20 12:21:52 --> Final output sent to browser
DEBUG - 2018-11-20 12:21:52 --> Total execution time: 0.0450
INFO - 2018-11-20 12:23:28 --> Config Class Initialized
INFO - 2018-11-20 12:23:28 --> Hooks Class Initialized
DEBUG - 2018-11-20 12:23:28 --> UTF-8 Support Enabled
INFO - 2018-11-20 12:23:28 --> Utf8 Class Initialized
INFO - 2018-11-20 12:23:28 --> URI Class Initialized
INFO - 2018-11-20 12:23:28 --> Router Class Initialized
INFO - 2018-11-20 12:23:28 --> Output Class Initialized
INFO - 2018-11-20 12:23:28 --> Security Class Initialized
DEBUG - 2018-11-20 12:23:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-20 12:23:28 --> Input Class Initialized
INFO - 2018-11-20 12:23:28 --> Language Class Initialized
INFO - 2018-11-20 12:23:28 --> Loader Class Initialized
INFO - 2018-11-20 12:23:28 --> Helper loaded: url_helper
INFO - 2018-11-20 12:23:28 --> Helper loaded: file_helper
INFO - 2018-11-20 12:23:28 --> Helper loaded: email_helper
INFO - 2018-11-20 12:23:28 --> Helper loaded: common_helper
INFO - 2018-11-20 12:23:28 --> Database Driver Class Initialized
DEBUG - 2018-11-20 12:23:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-20 12:23:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-20 12:23:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-20 12:23:28 --> Pagination Class Initialized
INFO - 2018-11-20 12:23:28 --> Helper loaded: form_helper
INFO - 2018-11-20 12:23:28 --> Form Validation Class Initialized
INFO - 2018-11-20 12:23:28 --> Model Class Initialized
INFO - 2018-11-20 12:23:28 --> Controller Class Initialized
INFO - 2018-11-20 12:23:28 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-20 12:23:28 --> Model Class Initialized
INFO - 2018-11-20 12:23:28 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-20 12:23:28 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/sidebar.php
INFO - 2018-11-20 12:23:28 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/right-sidebar.php
INFO - 2018-11-20 12:23:28 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/footer.php
INFO - 2018-11-20 12:23:28 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/dashboard.php
INFO - 2018-11-20 12:23:28 --> Final output sent to browser
DEBUG - 2018-11-20 12:23:28 --> Total execution time: 0.0550
INFO - 2018-11-20 12:24:12 --> Config Class Initialized
INFO - 2018-11-20 12:24:12 --> Hooks Class Initialized
DEBUG - 2018-11-20 12:24:12 --> UTF-8 Support Enabled
INFO - 2018-11-20 12:24:12 --> Utf8 Class Initialized
INFO - 2018-11-20 12:24:12 --> URI Class Initialized
INFO - 2018-11-20 12:24:12 --> Router Class Initialized
INFO - 2018-11-20 12:24:12 --> Output Class Initialized
INFO - 2018-11-20 12:24:12 --> Security Class Initialized
DEBUG - 2018-11-20 12:24:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-20 12:24:12 --> Input Class Initialized
INFO - 2018-11-20 12:24:12 --> Language Class Initialized
INFO - 2018-11-20 12:24:12 --> Loader Class Initialized
INFO - 2018-11-20 12:24:12 --> Helper loaded: url_helper
INFO - 2018-11-20 12:24:12 --> Helper loaded: file_helper
INFO - 2018-11-20 12:24:12 --> Helper loaded: email_helper
INFO - 2018-11-20 12:24:12 --> Helper loaded: common_helper
INFO - 2018-11-20 12:24:12 --> Database Driver Class Initialized
DEBUG - 2018-11-20 12:24:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-20 12:24:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-20 12:24:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-20 12:24:12 --> Pagination Class Initialized
INFO - 2018-11-20 12:24:12 --> Helper loaded: form_helper
INFO - 2018-11-20 12:24:12 --> Form Validation Class Initialized
INFO - 2018-11-20 12:24:12 --> Model Class Initialized
INFO - 2018-11-20 12:24:12 --> Controller Class Initialized
INFO - 2018-11-20 12:24:12 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-20 12:24:12 --> Model Class Initialized
INFO - 2018-11-20 12:24:12 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-20 12:24:12 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/sidebar.php
INFO - 2018-11-20 12:24:12 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/right-sidebar.php
INFO - 2018-11-20 12:24:12 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/footer.php
INFO - 2018-11-20 12:24:12 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/dashboard.php
INFO - 2018-11-20 12:24:12 --> Final output sent to browser
DEBUG - 2018-11-20 12:24:12 --> Total execution time: 0.0610
INFO - 2018-11-20 12:24:29 --> Config Class Initialized
INFO - 2018-11-20 12:24:29 --> Hooks Class Initialized
DEBUG - 2018-11-20 12:24:29 --> UTF-8 Support Enabled
INFO - 2018-11-20 12:24:29 --> Utf8 Class Initialized
INFO - 2018-11-20 12:24:29 --> URI Class Initialized
INFO - 2018-11-20 12:24:29 --> Router Class Initialized
INFO - 2018-11-20 12:24:29 --> Output Class Initialized
INFO - 2018-11-20 12:24:29 --> Security Class Initialized
DEBUG - 2018-11-20 12:24:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-20 12:24:29 --> Input Class Initialized
INFO - 2018-11-20 12:24:29 --> Language Class Initialized
INFO - 2018-11-20 12:24:29 --> Loader Class Initialized
INFO - 2018-11-20 12:24:29 --> Helper loaded: url_helper
INFO - 2018-11-20 12:24:29 --> Helper loaded: file_helper
INFO - 2018-11-20 12:24:29 --> Helper loaded: email_helper
INFO - 2018-11-20 12:24:29 --> Helper loaded: common_helper
INFO - 2018-11-20 12:24:29 --> Database Driver Class Initialized
DEBUG - 2018-11-20 12:24:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-20 12:24:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-20 12:24:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-20 12:24:29 --> Pagination Class Initialized
INFO - 2018-11-20 12:24:29 --> Helper loaded: form_helper
INFO - 2018-11-20 12:24:29 --> Form Validation Class Initialized
INFO - 2018-11-20 12:24:29 --> Model Class Initialized
INFO - 2018-11-20 12:24:29 --> Controller Class Initialized
INFO - 2018-11-20 12:24:29 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-20 12:24:29 --> Model Class Initialized
INFO - 2018-11-20 12:24:29 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-20 12:24:29 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/sidebar.php
INFO - 2018-11-20 12:24:29 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/right-sidebar.php
INFO - 2018-11-20 12:24:29 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/footer.php
INFO - 2018-11-20 12:24:29 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/dashboard.php
INFO - 2018-11-20 12:24:29 --> Final output sent to browser
DEBUG - 2018-11-20 12:24:29 --> Total execution time: 0.0530
INFO - 2018-11-20 12:24:36 --> Config Class Initialized
INFO - 2018-11-20 12:24:36 --> Hooks Class Initialized
DEBUG - 2018-11-20 12:24:36 --> UTF-8 Support Enabled
INFO - 2018-11-20 12:24:36 --> Utf8 Class Initialized
INFO - 2018-11-20 12:24:36 --> URI Class Initialized
INFO - 2018-11-20 12:24:36 --> Router Class Initialized
INFO - 2018-11-20 12:24:36 --> Output Class Initialized
INFO - 2018-11-20 12:24:36 --> Security Class Initialized
DEBUG - 2018-11-20 12:24:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-20 12:24:36 --> Input Class Initialized
INFO - 2018-11-20 12:24:36 --> Language Class Initialized
INFO - 2018-11-20 12:24:36 --> Loader Class Initialized
INFO - 2018-11-20 12:24:36 --> Helper loaded: url_helper
INFO - 2018-11-20 12:24:36 --> Helper loaded: file_helper
INFO - 2018-11-20 12:24:36 --> Helper loaded: email_helper
INFO - 2018-11-20 12:24:36 --> Helper loaded: common_helper
INFO - 2018-11-20 12:24:36 --> Database Driver Class Initialized
DEBUG - 2018-11-20 12:24:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-20 12:24:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-20 12:24:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-20 12:24:36 --> Pagination Class Initialized
INFO - 2018-11-20 12:24:36 --> Helper loaded: form_helper
INFO - 2018-11-20 12:24:36 --> Form Validation Class Initialized
INFO - 2018-11-20 12:24:36 --> Model Class Initialized
INFO - 2018-11-20 12:24:36 --> Controller Class Initialized
INFO - 2018-11-20 12:24:36 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-20 12:24:36 --> Model Class Initialized
INFO - 2018-11-20 12:24:36 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-20 12:24:36 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/sidebar.php
INFO - 2018-11-20 12:24:36 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/right-sidebar.php
INFO - 2018-11-20 12:24:36 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/footer.php
INFO - 2018-11-20 12:24:36 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/dashboard.php
INFO - 2018-11-20 12:24:36 --> Final output sent to browser
DEBUG - 2018-11-20 12:24:36 --> Total execution time: 0.0600
INFO - 2018-11-20 12:25:57 --> Config Class Initialized
INFO - 2018-11-20 12:25:57 --> Hooks Class Initialized
DEBUG - 2018-11-20 12:25:57 --> UTF-8 Support Enabled
INFO - 2018-11-20 12:25:57 --> Utf8 Class Initialized
INFO - 2018-11-20 12:25:57 --> URI Class Initialized
INFO - 2018-11-20 12:25:57 --> Router Class Initialized
INFO - 2018-11-20 12:25:57 --> Output Class Initialized
INFO - 2018-11-20 12:25:57 --> Security Class Initialized
DEBUG - 2018-11-20 12:25:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-20 12:25:57 --> Input Class Initialized
INFO - 2018-11-20 12:25:57 --> Language Class Initialized
INFO - 2018-11-20 12:25:57 --> Loader Class Initialized
INFO - 2018-11-20 12:25:57 --> Helper loaded: url_helper
INFO - 2018-11-20 12:25:57 --> Helper loaded: file_helper
INFO - 2018-11-20 12:25:57 --> Helper loaded: email_helper
INFO - 2018-11-20 12:25:57 --> Helper loaded: common_helper
INFO - 2018-11-20 12:25:57 --> Database Driver Class Initialized
DEBUG - 2018-11-20 12:25:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-20 12:25:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-20 12:25:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-20 12:25:57 --> Pagination Class Initialized
INFO - 2018-11-20 12:25:57 --> Helper loaded: form_helper
INFO - 2018-11-20 12:25:57 --> Form Validation Class Initialized
INFO - 2018-11-20 12:25:57 --> Model Class Initialized
INFO - 2018-11-20 12:25:57 --> Controller Class Initialized
INFO - 2018-11-20 12:25:57 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-20 12:25:57 --> Model Class Initialized
INFO - 2018-11-20 12:25:57 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-20 12:25:57 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/sidebar.php
INFO - 2018-11-20 12:25:57 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/right-sidebar.php
INFO - 2018-11-20 12:25:57 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/footer.php
INFO - 2018-11-20 12:25:57 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/dashboard.php
INFO - 2018-11-20 12:25:57 --> Final output sent to browser
DEBUG - 2018-11-20 12:25:57 --> Total execution time: 0.0630
INFO - 2018-11-20 12:26:03 --> Config Class Initialized
INFO - 2018-11-20 12:26:03 --> Hooks Class Initialized
DEBUG - 2018-11-20 12:26:03 --> UTF-8 Support Enabled
INFO - 2018-11-20 12:26:03 --> Utf8 Class Initialized
INFO - 2018-11-20 12:26:03 --> URI Class Initialized
INFO - 2018-11-20 12:26:03 --> Router Class Initialized
INFO - 2018-11-20 12:26:03 --> Output Class Initialized
INFO - 2018-11-20 12:26:03 --> Security Class Initialized
DEBUG - 2018-11-20 12:26:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-20 12:26:03 --> Input Class Initialized
INFO - 2018-11-20 12:26:03 --> Language Class Initialized
ERROR - 2018-11-20 12:26:03 --> 404 Page Not Found: wun_admin/Sweatalerthtml/index
INFO - 2018-11-20 12:26:05 --> Config Class Initialized
INFO - 2018-11-20 12:26:05 --> Hooks Class Initialized
DEBUG - 2018-11-20 12:26:05 --> UTF-8 Support Enabled
INFO - 2018-11-20 12:26:05 --> Utf8 Class Initialized
INFO - 2018-11-20 12:26:05 --> URI Class Initialized
INFO - 2018-11-20 12:26:05 --> Router Class Initialized
INFO - 2018-11-20 12:26:05 --> Output Class Initialized
INFO - 2018-11-20 12:26:05 --> Security Class Initialized
DEBUG - 2018-11-20 12:26:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-20 12:26:05 --> Input Class Initialized
INFO - 2018-11-20 12:26:05 --> Language Class Initialized
INFO - 2018-11-20 12:26:05 --> Loader Class Initialized
INFO - 2018-11-20 12:26:05 --> Helper loaded: url_helper
INFO - 2018-11-20 12:26:05 --> Helper loaded: file_helper
INFO - 2018-11-20 12:26:05 --> Helper loaded: email_helper
INFO - 2018-11-20 12:26:05 --> Helper loaded: common_helper
INFO - 2018-11-20 12:26:05 --> Database Driver Class Initialized
DEBUG - 2018-11-20 12:26:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-20 12:26:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-20 12:26:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-20 12:26:05 --> Pagination Class Initialized
INFO - 2018-11-20 12:26:05 --> Helper loaded: form_helper
INFO - 2018-11-20 12:26:05 --> Form Validation Class Initialized
INFO - 2018-11-20 12:26:05 --> Model Class Initialized
INFO - 2018-11-20 12:26:05 --> Controller Class Initialized
INFO - 2018-11-20 12:26:05 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-20 12:26:05 --> Model Class Initialized
INFO - 2018-11-20 12:26:05 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-20 12:26:05 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/sidebar.php
INFO - 2018-11-20 12:26:05 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/right-sidebar.php
INFO - 2018-11-20 12:26:05 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/footer.php
INFO - 2018-11-20 12:26:05 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/dashboard.php
INFO - 2018-11-20 12:26:05 --> Final output sent to browser
DEBUG - 2018-11-20 12:26:05 --> Total execution time: 0.0570
INFO - 2018-11-20 12:26:09 --> Config Class Initialized
INFO - 2018-11-20 12:26:09 --> Hooks Class Initialized
DEBUG - 2018-11-20 12:26:09 --> UTF-8 Support Enabled
INFO - 2018-11-20 12:26:09 --> Utf8 Class Initialized
INFO - 2018-11-20 12:26:09 --> URI Class Initialized
INFO - 2018-11-20 12:26:09 --> Router Class Initialized
INFO - 2018-11-20 12:26:09 --> Output Class Initialized
INFO - 2018-11-20 12:26:09 --> Security Class Initialized
DEBUG - 2018-11-20 12:26:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-20 12:26:09 --> Input Class Initialized
INFO - 2018-11-20 12:26:09 --> Language Class Initialized
ERROR - 2018-11-20 12:26:09 --> 404 Page Not Found: wun_admin/Indexhtml/index
INFO - 2018-11-20 12:26:10 --> Config Class Initialized
INFO - 2018-11-20 12:26:10 --> Hooks Class Initialized
DEBUG - 2018-11-20 12:26:10 --> UTF-8 Support Enabled
INFO - 2018-11-20 12:26:10 --> Utf8 Class Initialized
INFO - 2018-11-20 12:26:10 --> URI Class Initialized
INFO - 2018-11-20 12:26:10 --> Router Class Initialized
INFO - 2018-11-20 12:26:10 --> Output Class Initialized
INFO - 2018-11-20 12:26:10 --> Security Class Initialized
DEBUG - 2018-11-20 12:26:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-20 12:26:10 --> Input Class Initialized
INFO - 2018-11-20 12:26:10 --> Language Class Initialized
INFO - 2018-11-20 12:26:10 --> Loader Class Initialized
INFO - 2018-11-20 12:26:10 --> Helper loaded: url_helper
INFO - 2018-11-20 12:26:10 --> Helper loaded: file_helper
INFO - 2018-11-20 12:26:10 --> Helper loaded: email_helper
INFO - 2018-11-20 12:26:10 --> Helper loaded: common_helper
INFO - 2018-11-20 12:26:10 --> Database Driver Class Initialized
DEBUG - 2018-11-20 12:26:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-20 12:26:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-20 12:26:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-20 12:26:10 --> Pagination Class Initialized
INFO - 2018-11-20 12:26:10 --> Helper loaded: form_helper
INFO - 2018-11-20 12:26:10 --> Form Validation Class Initialized
INFO - 2018-11-20 12:26:10 --> Model Class Initialized
INFO - 2018-11-20 12:26:10 --> Controller Class Initialized
INFO - 2018-11-20 12:26:10 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-20 12:26:10 --> Model Class Initialized
INFO - 2018-11-20 12:26:10 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-20 12:26:10 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/sidebar.php
INFO - 2018-11-20 12:26:10 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/right-sidebar.php
INFO - 2018-11-20 12:26:10 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/footer.php
INFO - 2018-11-20 12:26:10 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/dashboard.php
INFO - 2018-11-20 12:26:10 --> Final output sent to browser
DEBUG - 2018-11-20 12:26:10 --> Total execution time: 0.0690
INFO - 2018-11-20 12:26:43 --> Config Class Initialized
INFO - 2018-11-20 12:26:43 --> Hooks Class Initialized
DEBUG - 2018-11-20 12:26:43 --> UTF-8 Support Enabled
INFO - 2018-11-20 12:26:43 --> Utf8 Class Initialized
INFO - 2018-11-20 12:26:43 --> URI Class Initialized
INFO - 2018-11-20 12:26:43 --> Router Class Initialized
INFO - 2018-11-20 12:26:43 --> Output Class Initialized
INFO - 2018-11-20 12:26:43 --> Security Class Initialized
DEBUG - 2018-11-20 12:26:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-20 12:26:43 --> Input Class Initialized
INFO - 2018-11-20 12:26:43 --> Language Class Initialized
INFO - 2018-11-20 12:26:43 --> Loader Class Initialized
INFO - 2018-11-20 12:26:43 --> Helper loaded: url_helper
INFO - 2018-11-20 12:26:43 --> Helper loaded: file_helper
INFO - 2018-11-20 12:26:43 --> Helper loaded: email_helper
INFO - 2018-11-20 12:26:43 --> Helper loaded: common_helper
INFO - 2018-11-20 12:26:43 --> Database Driver Class Initialized
DEBUG - 2018-11-20 12:26:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-20 12:26:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-20 12:26:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-20 12:26:43 --> Pagination Class Initialized
INFO - 2018-11-20 12:26:43 --> Helper loaded: form_helper
INFO - 2018-11-20 12:26:43 --> Form Validation Class Initialized
INFO - 2018-11-20 12:26:43 --> Model Class Initialized
INFO - 2018-11-20 12:26:43 --> Controller Class Initialized
INFO - 2018-11-20 12:26:43 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-20 12:26:43 --> Model Class Initialized
INFO - 2018-11-20 12:26:43 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-20 12:26:43 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/sidebar.php
INFO - 2018-11-20 12:26:43 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/right-sidebar.php
INFO - 2018-11-20 12:26:43 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/footer.php
INFO - 2018-11-20 12:26:43 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/dashboard.php
INFO - 2018-11-20 12:26:43 --> Final output sent to browser
DEBUG - 2018-11-20 12:26:43 --> Total execution time: 0.0500
INFO - 2018-11-20 12:26:47 --> Config Class Initialized
INFO - 2018-11-20 12:26:47 --> Hooks Class Initialized
DEBUG - 2018-11-20 12:26:47 --> UTF-8 Support Enabled
INFO - 2018-11-20 12:26:47 --> Utf8 Class Initialized
INFO - 2018-11-20 12:26:47 --> URI Class Initialized
INFO - 2018-11-20 12:26:47 --> Router Class Initialized
INFO - 2018-11-20 12:26:47 --> Output Class Initialized
INFO - 2018-11-20 12:26:47 --> Security Class Initialized
DEBUG - 2018-11-20 12:26:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-20 12:26:47 --> Input Class Initialized
INFO - 2018-11-20 12:26:47 --> Language Class Initialized
ERROR - 2018-11-20 12:26:47 --> 404 Page Not Found: Admin/dashboard
INFO - 2018-11-20 12:26:54 --> Config Class Initialized
INFO - 2018-11-20 12:26:54 --> Hooks Class Initialized
DEBUG - 2018-11-20 12:26:54 --> UTF-8 Support Enabled
INFO - 2018-11-20 12:26:54 --> Utf8 Class Initialized
INFO - 2018-11-20 12:26:54 --> URI Class Initialized
INFO - 2018-11-20 12:26:54 --> Router Class Initialized
INFO - 2018-11-20 12:26:54 --> Output Class Initialized
INFO - 2018-11-20 12:26:54 --> Security Class Initialized
DEBUG - 2018-11-20 12:26:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-20 12:26:54 --> Input Class Initialized
INFO - 2018-11-20 12:26:54 --> Language Class Initialized
INFO - 2018-11-20 12:26:54 --> Loader Class Initialized
INFO - 2018-11-20 12:26:54 --> Helper loaded: url_helper
INFO - 2018-11-20 12:26:54 --> Helper loaded: file_helper
INFO - 2018-11-20 12:26:54 --> Helper loaded: email_helper
INFO - 2018-11-20 12:26:54 --> Helper loaded: common_helper
INFO - 2018-11-20 12:26:54 --> Database Driver Class Initialized
DEBUG - 2018-11-20 12:26:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-20 12:26:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-20 12:26:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-20 12:26:54 --> Pagination Class Initialized
INFO - 2018-11-20 12:26:54 --> Helper loaded: form_helper
INFO - 2018-11-20 12:26:54 --> Form Validation Class Initialized
INFO - 2018-11-20 12:26:54 --> Model Class Initialized
INFO - 2018-11-20 12:26:54 --> Controller Class Initialized
INFO - 2018-11-20 12:26:54 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-20 12:26:54 --> Model Class Initialized
INFO - 2018-11-20 12:26:54 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-20 12:26:54 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/sidebar.php
INFO - 2018-11-20 12:26:54 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/right-sidebar.php
INFO - 2018-11-20 12:26:54 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/footer.php
INFO - 2018-11-20 12:26:54 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/dashboard.php
INFO - 2018-11-20 12:26:54 --> Final output sent to browser
DEBUG - 2018-11-20 12:26:54 --> Total execution time: 0.0710
INFO - 2018-11-20 12:28:13 --> Config Class Initialized
INFO - 2018-11-20 12:28:13 --> Hooks Class Initialized
DEBUG - 2018-11-20 12:28:13 --> UTF-8 Support Enabled
INFO - 2018-11-20 12:28:13 --> Utf8 Class Initialized
INFO - 2018-11-20 12:28:13 --> URI Class Initialized
INFO - 2018-11-20 12:28:13 --> Router Class Initialized
INFO - 2018-11-20 12:28:13 --> Output Class Initialized
INFO - 2018-11-20 12:28:13 --> Security Class Initialized
DEBUG - 2018-11-20 12:28:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-20 12:28:13 --> Input Class Initialized
INFO - 2018-11-20 12:28:13 --> Language Class Initialized
ERROR - 2018-11-20 12:28:13 --> 404 Page Not Found: Admin/dashboard
INFO - 2018-11-20 12:28:15 --> Config Class Initialized
INFO - 2018-11-20 12:28:15 --> Hooks Class Initialized
DEBUG - 2018-11-20 12:28:15 --> UTF-8 Support Enabled
INFO - 2018-11-20 12:28:15 --> Utf8 Class Initialized
INFO - 2018-11-20 12:28:15 --> URI Class Initialized
INFO - 2018-11-20 12:28:15 --> Router Class Initialized
INFO - 2018-11-20 12:28:15 --> Output Class Initialized
INFO - 2018-11-20 12:28:15 --> Security Class Initialized
DEBUG - 2018-11-20 12:28:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-20 12:28:15 --> Input Class Initialized
INFO - 2018-11-20 12:28:15 --> Language Class Initialized
INFO - 2018-11-20 12:28:15 --> Loader Class Initialized
INFO - 2018-11-20 12:28:15 --> Helper loaded: url_helper
INFO - 2018-11-20 12:28:15 --> Helper loaded: file_helper
INFO - 2018-11-20 12:28:15 --> Helper loaded: email_helper
INFO - 2018-11-20 12:28:15 --> Helper loaded: common_helper
INFO - 2018-11-20 12:28:15 --> Database Driver Class Initialized
DEBUG - 2018-11-20 12:28:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-20 12:28:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-20 12:28:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-20 12:28:15 --> Pagination Class Initialized
INFO - 2018-11-20 12:28:15 --> Helper loaded: form_helper
INFO - 2018-11-20 12:28:15 --> Form Validation Class Initialized
INFO - 2018-11-20 12:28:15 --> Model Class Initialized
INFO - 2018-11-20 12:28:15 --> Controller Class Initialized
INFO - 2018-11-20 12:28:15 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-20 12:28:15 --> Model Class Initialized
INFO - 2018-11-20 12:28:15 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-20 12:28:15 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/sidebar.php
INFO - 2018-11-20 12:28:15 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/right-sidebar.php
INFO - 2018-11-20 12:28:15 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/footer.php
INFO - 2018-11-20 12:28:15 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/dashboard.php
INFO - 2018-11-20 12:28:15 --> Final output sent to browser
DEBUG - 2018-11-20 12:28:15 --> Total execution time: 0.0710
INFO - 2018-11-20 12:28:39 --> Config Class Initialized
INFO - 2018-11-20 12:28:39 --> Hooks Class Initialized
DEBUG - 2018-11-20 12:28:39 --> UTF-8 Support Enabled
INFO - 2018-11-20 12:28:39 --> Utf8 Class Initialized
INFO - 2018-11-20 12:28:39 --> URI Class Initialized
INFO - 2018-11-20 12:28:39 --> Router Class Initialized
INFO - 2018-11-20 12:28:39 --> Output Class Initialized
INFO - 2018-11-20 12:28:39 --> Security Class Initialized
DEBUG - 2018-11-20 12:28:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-20 12:28:39 --> Input Class Initialized
INFO - 2018-11-20 12:28:39 --> Language Class Initialized
ERROR - 2018-11-20 12:28:39 --> 404 Page Not Found: wun_admin/Panels-wellshtml/index
INFO - 2018-11-20 12:28:41 --> Config Class Initialized
INFO - 2018-11-20 12:28:41 --> Hooks Class Initialized
DEBUG - 2018-11-20 12:28:41 --> UTF-8 Support Enabled
INFO - 2018-11-20 12:28:41 --> Utf8 Class Initialized
INFO - 2018-11-20 12:28:41 --> URI Class Initialized
INFO - 2018-11-20 12:28:41 --> Router Class Initialized
INFO - 2018-11-20 12:28:41 --> Output Class Initialized
INFO - 2018-11-20 12:28:41 --> Security Class Initialized
DEBUG - 2018-11-20 12:28:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-20 12:28:41 --> Input Class Initialized
INFO - 2018-11-20 12:28:41 --> Language Class Initialized
INFO - 2018-11-20 12:28:41 --> Loader Class Initialized
INFO - 2018-11-20 12:28:41 --> Helper loaded: url_helper
INFO - 2018-11-20 12:28:41 --> Helper loaded: file_helper
INFO - 2018-11-20 12:28:41 --> Helper loaded: email_helper
INFO - 2018-11-20 12:28:41 --> Helper loaded: common_helper
INFO - 2018-11-20 12:28:41 --> Database Driver Class Initialized
DEBUG - 2018-11-20 12:28:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-20 12:28:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-20 12:28:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-20 12:28:41 --> Pagination Class Initialized
INFO - 2018-11-20 12:28:41 --> Helper loaded: form_helper
INFO - 2018-11-20 12:28:41 --> Form Validation Class Initialized
INFO - 2018-11-20 12:28:41 --> Model Class Initialized
INFO - 2018-11-20 12:28:41 --> Controller Class Initialized
INFO - 2018-11-20 12:28:41 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-20 12:28:41 --> Model Class Initialized
INFO - 2018-11-20 12:28:41 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-20 12:28:41 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/sidebar.php
INFO - 2018-11-20 12:28:41 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/right-sidebar.php
INFO - 2018-11-20 12:28:41 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/footer.php
INFO - 2018-11-20 12:28:41 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/dashboard.php
INFO - 2018-11-20 12:28:41 --> Final output sent to browser
DEBUG - 2018-11-20 12:28:41 --> Total execution time: 0.0540
INFO - 2018-11-20 12:28:49 --> Config Class Initialized
INFO - 2018-11-20 12:28:49 --> Hooks Class Initialized
DEBUG - 2018-11-20 12:28:49 --> UTF-8 Support Enabled
INFO - 2018-11-20 12:28:49 --> Utf8 Class Initialized
INFO - 2018-11-20 12:28:49 --> URI Class Initialized
INFO - 2018-11-20 12:28:49 --> Router Class Initialized
INFO - 2018-11-20 12:28:49 --> Output Class Initialized
INFO - 2018-11-20 12:28:49 --> Security Class Initialized
DEBUG - 2018-11-20 12:28:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-20 12:28:49 --> Input Class Initialized
INFO - 2018-11-20 12:28:49 --> Language Class Initialized
INFO - 2018-11-20 12:28:49 --> Loader Class Initialized
INFO - 2018-11-20 12:28:49 --> Helper loaded: url_helper
INFO - 2018-11-20 12:28:49 --> Helper loaded: file_helper
INFO - 2018-11-20 12:28:49 --> Helper loaded: email_helper
INFO - 2018-11-20 12:28:49 --> Helper loaded: common_helper
INFO - 2018-11-20 12:28:49 --> Database Driver Class Initialized
DEBUG - 2018-11-20 12:28:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-20 12:28:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-20 12:28:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-20 12:28:49 --> Pagination Class Initialized
INFO - 2018-11-20 12:28:49 --> Helper loaded: form_helper
INFO - 2018-11-20 12:28:49 --> Form Validation Class Initialized
INFO - 2018-11-20 12:28:49 --> Model Class Initialized
INFO - 2018-11-20 12:28:49 --> Controller Class Initialized
INFO - 2018-11-20 12:28:49 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-20 12:28:49 --> Model Class Initialized
INFO - 2018-11-20 12:28:49 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-20 12:28:49 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/sidebar.php
INFO - 2018-11-20 12:28:49 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/right-sidebar.php
INFO - 2018-11-20 12:28:49 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/footer.php
INFO - 2018-11-20 12:28:49 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/dashboard.php
INFO - 2018-11-20 12:28:49 --> Final output sent to browser
DEBUG - 2018-11-20 12:28:49 --> Total execution time: 0.0650
INFO - 2018-11-20 12:29:27 --> Config Class Initialized
INFO - 2018-11-20 12:29:27 --> Hooks Class Initialized
DEBUG - 2018-11-20 12:29:27 --> UTF-8 Support Enabled
INFO - 2018-11-20 12:29:27 --> Utf8 Class Initialized
INFO - 2018-11-20 12:29:27 --> URI Class Initialized
INFO - 2018-11-20 12:29:27 --> Router Class Initialized
INFO - 2018-11-20 12:29:27 --> Output Class Initialized
INFO - 2018-11-20 12:29:27 --> Security Class Initialized
DEBUG - 2018-11-20 12:29:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-20 12:29:27 --> Input Class Initialized
INFO - 2018-11-20 12:29:27 --> Language Class Initialized
INFO - 2018-11-20 12:29:27 --> Loader Class Initialized
INFO - 2018-11-20 12:29:27 --> Helper loaded: url_helper
INFO - 2018-11-20 12:29:27 --> Helper loaded: file_helper
INFO - 2018-11-20 12:29:27 --> Helper loaded: email_helper
INFO - 2018-11-20 12:29:27 --> Helper loaded: common_helper
INFO - 2018-11-20 12:29:27 --> Database Driver Class Initialized
DEBUG - 2018-11-20 12:29:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-20 12:29:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-20 12:29:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-20 12:29:27 --> Pagination Class Initialized
INFO - 2018-11-20 12:29:27 --> Helper loaded: form_helper
INFO - 2018-11-20 12:29:27 --> Form Validation Class Initialized
INFO - 2018-11-20 12:29:27 --> Model Class Initialized
INFO - 2018-11-20 12:29:27 --> Controller Class Initialized
INFO - 2018-11-20 12:29:27 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-20 12:29:27 --> Model Class Initialized
INFO - 2018-11-20 12:29:27 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-20 12:29:27 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/sidebar.php
INFO - 2018-11-20 12:29:27 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/right-sidebar.php
INFO - 2018-11-20 12:29:27 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/footer.php
INFO - 2018-11-20 12:29:27 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/dashboard.php
INFO - 2018-11-20 12:29:27 --> Final output sent to browser
DEBUG - 2018-11-20 12:29:27 --> Total execution time: 0.0830
INFO - 2018-11-20 12:32:19 --> Config Class Initialized
INFO - 2018-11-20 12:32:19 --> Hooks Class Initialized
DEBUG - 2018-11-20 12:32:19 --> UTF-8 Support Enabled
INFO - 2018-11-20 12:32:19 --> Utf8 Class Initialized
INFO - 2018-11-20 12:32:19 --> URI Class Initialized
INFO - 2018-11-20 12:32:19 --> Router Class Initialized
INFO - 2018-11-20 12:32:19 --> Output Class Initialized
INFO - 2018-11-20 12:32:19 --> Security Class Initialized
DEBUG - 2018-11-20 12:32:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-20 12:32:19 --> Input Class Initialized
INFO - 2018-11-20 12:32:19 --> Language Class Initialized
INFO - 2018-11-20 12:32:19 --> Loader Class Initialized
INFO - 2018-11-20 12:32:19 --> Helper loaded: url_helper
INFO - 2018-11-20 12:32:19 --> Helper loaded: file_helper
INFO - 2018-11-20 12:32:19 --> Helper loaded: email_helper
INFO - 2018-11-20 12:32:19 --> Helper loaded: common_helper
INFO - 2018-11-20 12:32:19 --> Database Driver Class Initialized
DEBUG - 2018-11-20 12:32:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-20 12:32:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-20 12:32:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-20 12:32:19 --> Pagination Class Initialized
INFO - 2018-11-20 12:32:19 --> Helper loaded: form_helper
INFO - 2018-11-20 12:32:19 --> Form Validation Class Initialized
INFO - 2018-11-20 12:32:19 --> Model Class Initialized
INFO - 2018-11-20 12:32:19 --> Controller Class Initialized
INFO - 2018-11-20 12:32:19 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-20 12:32:19 --> Model Class Initialized
INFO - 2018-11-20 12:32:19 --> Model Class Initialized
INFO - 2018-11-20 12:32:19 --> Config Class Initialized
INFO - 2018-11-20 12:32:19 --> Hooks Class Initialized
DEBUG - 2018-11-20 12:32:19 --> UTF-8 Support Enabled
INFO - 2018-11-20 12:32:19 --> Utf8 Class Initialized
INFO - 2018-11-20 12:32:19 --> URI Class Initialized
INFO - 2018-11-20 12:32:19 --> Router Class Initialized
INFO - 2018-11-20 12:32:19 --> Output Class Initialized
INFO - 2018-11-20 12:32:19 --> Security Class Initialized
DEBUG - 2018-11-20 12:32:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-20 12:32:19 --> Input Class Initialized
INFO - 2018-11-20 12:32:19 --> Language Class Initialized
ERROR - 2018-11-20 12:32:19 --> 404 Page Not Found: Admin/dashboard
INFO - 2018-11-20 12:32:55 --> Config Class Initialized
INFO - 2018-11-20 12:32:55 --> Hooks Class Initialized
DEBUG - 2018-11-20 12:32:55 --> UTF-8 Support Enabled
INFO - 2018-11-20 12:32:55 --> Utf8 Class Initialized
INFO - 2018-11-20 12:32:55 --> URI Class Initialized
INFO - 2018-11-20 12:32:55 --> Router Class Initialized
INFO - 2018-11-20 12:32:55 --> Output Class Initialized
INFO - 2018-11-20 12:32:55 --> Security Class Initialized
DEBUG - 2018-11-20 12:32:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-20 12:32:55 --> Input Class Initialized
INFO - 2018-11-20 12:32:55 --> Language Class Initialized
INFO - 2018-11-20 12:32:55 --> Loader Class Initialized
INFO - 2018-11-20 12:32:55 --> Helper loaded: url_helper
INFO - 2018-11-20 12:32:55 --> Helper loaded: file_helper
INFO - 2018-11-20 12:32:55 --> Helper loaded: email_helper
INFO - 2018-11-20 12:32:55 --> Helper loaded: common_helper
INFO - 2018-11-20 12:32:55 --> Database Driver Class Initialized
DEBUG - 2018-11-20 12:32:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-20 12:32:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-20 12:32:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-20 12:32:55 --> Pagination Class Initialized
INFO - 2018-11-20 12:32:55 --> Helper loaded: form_helper
INFO - 2018-11-20 12:32:55 --> Form Validation Class Initialized
INFO - 2018-11-20 12:32:55 --> Model Class Initialized
INFO - 2018-11-20 12:32:55 --> Controller Class Initialized
INFO - 2018-11-20 12:32:55 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-20 12:32:55 --> Model Class Initialized
INFO - 2018-11-20 12:32:55 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-20 12:32:55 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/sidebar.php
INFO - 2018-11-20 12:32:55 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/right-sidebar.php
INFO - 2018-11-20 12:32:55 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/footer.php
INFO - 2018-11-20 12:32:55 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/dashboard.php
INFO - 2018-11-20 12:32:55 --> Final output sent to browser
DEBUG - 2018-11-20 12:32:55 --> Total execution time: 0.0550
INFO - 2018-11-20 12:33:14 --> Config Class Initialized
INFO - 2018-11-20 12:33:14 --> Hooks Class Initialized
DEBUG - 2018-11-20 12:33:14 --> UTF-8 Support Enabled
INFO - 2018-11-20 12:33:14 --> Utf8 Class Initialized
INFO - 2018-11-20 12:33:14 --> URI Class Initialized
INFO - 2018-11-20 12:33:14 --> Router Class Initialized
INFO - 2018-11-20 12:33:14 --> Output Class Initialized
INFO - 2018-11-20 12:33:14 --> Security Class Initialized
DEBUG - 2018-11-20 12:33:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-20 12:33:14 --> Input Class Initialized
INFO - 2018-11-20 12:33:14 --> Language Class Initialized
INFO - 2018-11-20 12:33:14 --> Loader Class Initialized
INFO - 2018-11-20 12:33:14 --> Helper loaded: url_helper
INFO - 2018-11-20 12:33:14 --> Helper loaded: file_helper
INFO - 2018-11-20 12:33:14 --> Helper loaded: email_helper
INFO - 2018-11-20 12:33:14 --> Helper loaded: common_helper
INFO - 2018-11-20 12:33:14 --> Database Driver Class Initialized
DEBUG - 2018-11-20 12:33:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-20 12:33:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-20 12:33:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-20 12:33:14 --> Pagination Class Initialized
INFO - 2018-11-20 12:33:14 --> Helper loaded: form_helper
INFO - 2018-11-20 12:33:14 --> Form Validation Class Initialized
INFO - 2018-11-20 12:33:14 --> Model Class Initialized
INFO - 2018-11-20 12:33:14 --> Controller Class Initialized
INFO - 2018-11-20 12:33:14 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-20 12:33:14 --> Model Class Initialized
INFO - 2018-11-20 12:33:14 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-20 12:33:14 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/sidebar.php
INFO - 2018-11-20 12:33:14 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/right-sidebar.php
INFO - 2018-11-20 12:33:14 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/footer.php
INFO - 2018-11-20 12:33:14 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/dashboard.php
INFO - 2018-11-20 12:33:14 --> Final output sent to browser
DEBUG - 2018-11-20 12:33:14 --> Total execution time: 0.0590
INFO - 2018-11-20 12:34:02 --> Config Class Initialized
INFO - 2018-11-20 12:34:02 --> Hooks Class Initialized
DEBUG - 2018-11-20 12:34:02 --> UTF-8 Support Enabled
INFO - 2018-11-20 12:34:02 --> Utf8 Class Initialized
INFO - 2018-11-20 12:34:02 --> URI Class Initialized
INFO - 2018-11-20 12:34:02 --> Router Class Initialized
INFO - 2018-11-20 12:34:02 --> Output Class Initialized
INFO - 2018-11-20 12:34:02 --> Security Class Initialized
DEBUG - 2018-11-20 12:34:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-20 12:34:02 --> Input Class Initialized
INFO - 2018-11-20 12:34:02 --> Language Class Initialized
INFO - 2018-11-20 12:34:02 --> Loader Class Initialized
INFO - 2018-11-20 12:34:02 --> Helper loaded: url_helper
INFO - 2018-11-20 12:34:02 --> Helper loaded: file_helper
INFO - 2018-11-20 12:34:02 --> Helper loaded: email_helper
INFO - 2018-11-20 12:34:02 --> Helper loaded: common_helper
INFO - 2018-11-20 12:34:02 --> Database Driver Class Initialized
DEBUG - 2018-11-20 12:34:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-20 12:34:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-20 12:34:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-20 12:34:02 --> Pagination Class Initialized
INFO - 2018-11-20 12:34:02 --> Helper loaded: form_helper
INFO - 2018-11-20 12:34:02 --> Form Validation Class Initialized
INFO - 2018-11-20 12:34:02 --> Model Class Initialized
INFO - 2018-11-20 12:34:02 --> Controller Class Initialized
INFO - 2018-11-20 12:34:02 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-20 12:34:02 --> Model Class Initialized
INFO - 2018-11-20 12:34:02 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-20 12:34:02 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/sidebar.php
INFO - 2018-11-20 12:34:02 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/right-sidebar.php
INFO - 2018-11-20 12:34:02 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/footer.php
INFO - 2018-11-20 12:34:02 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/dashboard.php
INFO - 2018-11-20 12:34:02 --> Final output sent to browser
DEBUG - 2018-11-20 12:34:02 --> Total execution time: 0.0680
INFO - 2018-11-20 13:37:49 --> Config Class Initialized
INFO - 2018-11-20 13:37:49 --> Hooks Class Initialized
DEBUG - 2018-11-20 13:37:49 --> UTF-8 Support Enabled
INFO - 2018-11-20 13:37:49 --> Utf8 Class Initialized
INFO - 2018-11-20 13:37:49 --> URI Class Initialized
INFO - 2018-11-20 13:37:49 --> Router Class Initialized
INFO - 2018-11-20 13:37:49 --> Output Class Initialized
INFO - 2018-11-20 13:37:49 --> Security Class Initialized
DEBUG - 2018-11-20 13:37:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-20 13:37:49 --> Input Class Initialized
INFO - 2018-11-20 13:37:49 --> Language Class Initialized
INFO - 2018-11-20 13:37:49 --> Loader Class Initialized
INFO - 2018-11-20 13:37:49 --> Helper loaded: url_helper
INFO - 2018-11-20 13:37:49 --> Helper loaded: file_helper
INFO - 2018-11-20 13:37:49 --> Helper loaded: email_helper
INFO - 2018-11-20 13:37:49 --> Helper loaded: common_helper
INFO - 2018-11-20 13:37:49 --> Database Driver Class Initialized
DEBUG - 2018-11-20 13:37:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-20 13:37:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-20 13:37:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-20 13:37:49 --> Pagination Class Initialized
INFO - 2018-11-20 13:37:49 --> Helper loaded: form_helper
INFO - 2018-11-20 13:37:49 --> Form Validation Class Initialized
INFO - 2018-11-20 13:37:49 --> Model Class Initialized
INFO - 2018-11-20 13:37:49 --> Controller Class Initialized
INFO - 2018-11-20 13:37:49 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-20 13:37:49 --> Model Class Initialized
INFO - 2018-11-20 13:37:49 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-20 13:37:49 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/sidebar.php
INFO - 2018-11-20 13:37:49 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/right-sidebar.php
INFO - 2018-11-20 13:37:49 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/footer.php
INFO - 2018-11-20 13:37:49 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/dashboard.php
INFO - 2018-11-20 13:37:49 --> Final output sent to browser
DEBUG - 2018-11-20 13:37:49 --> Total execution time: 0.0840
INFO - 2018-11-20 13:46:41 --> Config Class Initialized
INFO - 2018-11-20 13:46:41 --> Hooks Class Initialized
DEBUG - 2018-11-20 13:46:41 --> UTF-8 Support Enabled
INFO - 2018-11-20 13:46:41 --> Utf8 Class Initialized
INFO - 2018-11-20 13:46:41 --> URI Class Initialized
INFO - 2018-11-20 13:46:41 --> Router Class Initialized
INFO - 2018-11-20 13:46:41 --> Output Class Initialized
INFO - 2018-11-20 13:46:41 --> Security Class Initialized
DEBUG - 2018-11-20 13:46:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-20 13:46:41 --> Input Class Initialized
INFO - 2018-11-20 13:46:41 --> Language Class Initialized
INFO - 2018-11-20 13:46:41 --> Loader Class Initialized
INFO - 2018-11-20 13:46:41 --> Helper loaded: url_helper
INFO - 2018-11-20 13:46:41 --> Helper loaded: file_helper
INFO - 2018-11-20 13:46:41 --> Helper loaded: email_helper
INFO - 2018-11-20 13:46:41 --> Helper loaded: common_helper
INFO - 2018-11-20 13:46:41 --> Database Driver Class Initialized
DEBUG - 2018-11-20 13:46:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-20 13:46:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-20 13:46:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-20 13:46:42 --> Pagination Class Initialized
INFO - 2018-11-20 13:46:42 --> Helper loaded: form_helper
INFO - 2018-11-20 13:46:42 --> Form Validation Class Initialized
INFO - 2018-11-20 13:46:42 --> Model Class Initialized
INFO - 2018-11-20 13:46:42 --> Controller Class Initialized
INFO - 2018-11-20 13:46:42 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-20 13:46:42 --> Model Class Initialized
INFO - 2018-11-20 13:46:42 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-20 13:46:42 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/sidebar.php
INFO - 2018-11-20 13:46:42 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/right-sidebar.php
INFO - 2018-11-20 13:46:42 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/footer.php
INFO - 2018-11-20 13:46:42 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/dashboard.php
INFO - 2018-11-20 13:46:42 --> Final output sent to browser
DEBUG - 2018-11-20 13:46:42 --> Total execution time: 0.0620
INFO - 2018-11-20 13:47:23 --> Config Class Initialized
INFO - 2018-11-20 13:47:23 --> Hooks Class Initialized
DEBUG - 2018-11-20 13:47:23 --> UTF-8 Support Enabled
INFO - 2018-11-20 13:47:23 --> Utf8 Class Initialized
INFO - 2018-11-20 13:47:23 --> URI Class Initialized
INFO - 2018-11-20 13:47:23 --> Router Class Initialized
INFO - 2018-11-20 13:47:23 --> Output Class Initialized
INFO - 2018-11-20 13:47:23 --> Security Class Initialized
DEBUG - 2018-11-20 13:47:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-20 13:47:23 --> Input Class Initialized
INFO - 2018-11-20 13:47:23 --> Language Class Initialized
INFO - 2018-11-20 13:47:23 --> Loader Class Initialized
INFO - 2018-11-20 13:47:23 --> Helper loaded: url_helper
INFO - 2018-11-20 13:47:23 --> Helper loaded: file_helper
INFO - 2018-11-20 13:47:23 --> Helper loaded: email_helper
INFO - 2018-11-20 13:47:23 --> Helper loaded: common_helper
INFO - 2018-11-20 13:47:23 --> Database Driver Class Initialized
DEBUG - 2018-11-20 13:47:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-20 13:47:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-20 13:47:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-20 13:47:23 --> Pagination Class Initialized
INFO - 2018-11-20 13:47:23 --> Helper loaded: form_helper
INFO - 2018-11-20 13:47:23 --> Form Validation Class Initialized
INFO - 2018-11-20 13:47:23 --> Model Class Initialized
INFO - 2018-11-20 13:47:23 --> Controller Class Initialized
INFO - 2018-11-20 13:47:23 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-20 13:47:23 --> Model Class Initialized
INFO - 2018-11-20 13:47:23 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-20 13:47:23 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/sidebar.php
INFO - 2018-11-20 13:47:23 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/right-sidebar.php
INFO - 2018-11-20 13:47:23 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/footer.php
INFO - 2018-11-20 13:47:23 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/dashboard.php
INFO - 2018-11-20 13:47:23 --> Final output sent to browser
DEBUG - 2018-11-20 13:47:23 --> Total execution time: 0.0600
INFO - 2018-11-20 13:48:43 --> Config Class Initialized
INFO - 2018-11-20 13:48:43 --> Hooks Class Initialized
DEBUG - 2018-11-20 13:48:43 --> UTF-8 Support Enabled
INFO - 2018-11-20 13:48:43 --> Utf8 Class Initialized
INFO - 2018-11-20 13:48:43 --> URI Class Initialized
INFO - 2018-11-20 13:48:43 --> Router Class Initialized
INFO - 2018-11-20 13:48:43 --> Output Class Initialized
INFO - 2018-11-20 13:48:43 --> Security Class Initialized
DEBUG - 2018-11-20 13:48:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-20 13:48:43 --> Input Class Initialized
INFO - 2018-11-20 13:48:43 --> Language Class Initialized
INFO - 2018-11-20 13:48:43 --> Loader Class Initialized
INFO - 2018-11-20 13:48:43 --> Helper loaded: url_helper
INFO - 2018-11-20 13:48:43 --> Helper loaded: file_helper
INFO - 2018-11-20 13:48:43 --> Helper loaded: email_helper
INFO - 2018-11-20 13:48:43 --> Helper loaded: common_helper
INFO - 2018-11-20 13:48:43 --> Database Driver Class Initialized
DEBUG - 2018-11-20 13:48:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-20 13:48:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-20 13:48:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-20 13:48:43 --> Pagination Class Initialized
INFO - 2018-11-20 13:48:43 --> Helper loaded: form_helper
INFO - 2018-11-20 13:48:43 --> Form Validation Class Initialized
INFO - 2018-11-20 13:48:43 --> Model Class Initialized
INFO - 2018-11-20 13:48:43 --> Controller Class Initialized
INFO - 2018-11-20 13:48:43 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-20 13:48:43 --> Model Class Initialized
INFO - 2018-11-20 13:48:43 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-20 13:48:43 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/sidebar.php
INFO - 2018-11-20 13:48:43 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/right-sidebar.php
INFO - 2018-11-20 13:48:43 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/footer.php
INFO - 2018-11-20 13:48:43 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/dashboard.php
INFO - 2018-11-20 13:48:43 --> Final output sent to browser
DEBUG - 2018-11-20 13:48:43 --> Total execution time: 0.0570
INFO - 2018-11-20 13:49:46 --> Config Class Initialized
INFO - 2018-11-20 13:49:46 --> Hooks Class Initialized
DEBUG - 2018-11-20 13:49:46 --> UTF-8 Support Enabled
INFO - 2018-11-20 13:49:46 --> Utf8 Class Initialized
INFO - 2018-11-20 13:49:46 --> URI Class Initialized
INFO - 2018-11-20 13:49:46 --> Router Class Initialized
INFO - 2018-11-20 13:49:46 --> Output Class Initialized
INFO - 2018-11-20 13:49:46 --> Security Class Initialized
DEBUG - 2018-11-20 13:49:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-20 13:49:46 --> Input Class Initialized
INFO - 2018-11-20 13:49:46 --> Language Class Initialized
INFO - 2018-11-20 13:49:46 --> Loader Class Initialized
INFO - 2018-11-20 13:49:46 --> Helper loaded: url_helper
INFO - 2018-11-20 13:49:46 --> Helper loaded: file_helper
INFO - 2018-11-20 13:49:46 --> Helper loaded: email_helper
INFO - 2018-11-20 13:49:46 --> Helper loaded: common_helper
INFO - 2018-11-20 13:49:46 --> Database Driver Class Initialized
DEBUG - 2018-11-20 13:49:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-20 13:49:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-20 13:49:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-20 13:49:47 --> Pagination Class Initialized
INFO - 2018-11-20 13:49:47 --> Helper loaded: form_helper
INFO - 2018-11-20 13:49:47 --> Form Validation Class Initialized
INFO - 2018-11-20 13:49:47 --> Model Class Initialized
INFO - 2018-11-20 13:49:47 --> Controller Class Initialized
INFO - 2018-11-20 13:49:47 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-20 13:49:47 --> Model Class Initialized
INFO - 2018-11-20 13:49:47 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-20 13:49:47 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/sidebar.php
INFO - 2018-11-20 13:49:47 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/right-sidebar.php
INFO - 2018-11-20 13:49:47 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/footer.php
INFO - 2018-11-20 13:49:47 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/dashboard.php
INFO - 2018-11-20 13:49:47 --> Final output sent to browser
DEBUG - 2018-11-20 13:49:47 --> Total execution time: 0.0870
INFO - 2018-11-20 13:50:09 --> Config Class Initialized
INFO - 2018-11-20 13:50:09 --> Hooks Class Initialized
DEBUG - 2018-11-20 13:50:09 --> UTF-8 Support Enabled
INFO - 2018-11-20 13:50:09 --> Utf8 Class Initialized
INFO - 2018-11-20 13:50:09 --> URI Class Initialized
INFO - 2018-11-20 13:50:09 --> Router Class Initialized
INFO - 2018-11-20 13:50:09 --> Output Class Initialized
INFO - 2018-11-20 13:50:09 --> Security Class Initialized
DEBUG - 2018-11-20 13:50:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-20 13:50:09 --> Input Class Initialized
INFO - 2018-11-20 13:50:09 --> Language Class Initialized
INFO - 2018-11-20 13:50:09 --> Loader Class Initialized
INFO - 2018-11-20 13:50:09 --> Helper loaded: url_helper
INFO - 2018-11-20 13:50:09 --> Helper loaded: file_helper
INFO - 2018-11-20 13:50:09 --> Helper loaded: email_helper
INFO - 2018-11-20 13:50:09 --> Helper loaded: common_helper
INFO - 2018-11-20 13:50:09 --> Database Driver Class Initialized
DEBUG - 2018-11-20 13:50:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-20 13:50:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-20 13:50:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-20 13:50:09 --> Pagination Class Initialized
INFO - 2018-11-20 13:50:09 --> Helper loaded: form_helper
INFO - 2018-11-20 13:50:09 --> Form Validation Class Initialized
INFO - 2018-11-20 13:50:09 --> Model Class Initialized
INFO - 2018-11-20 13:50:09 --> Controller Class Initialized
INFO - 2018-11-20 13:50:09 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-20 13:50:09 --> Model Class Initialized
INFO - 2018-11-20 13:50:09 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-20 13:50:09 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/sidebar.php
INFO - 2018-11-20 13:50:09 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/right-sidebar.php
INFO - 2018-11-20 13:50:09 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/footer.php
INFO - 2018-11-20 13:50:09 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/dashboard.php
INFO - 2018-11-20 13:50:09 --> Final output sent to browser
DEBUG - 2018-11-20 13:50:09 --> Total execution time: 0.0610
INFO - 2018-11-20 13:50:45 --> Config Class Initialized
INFO - 2018-11-20 13:50:45 --> Hooks Class Initialized
DEBUG - 2018-11-20 13:50:45 --> UTF-8 Support Enabled
INFO - 2018-11-20 13:50:45 --> Utf8 Class Initialized
INFO - 2018-11-20 13:50:45 --> URI Class Initialized
INFO - 2018-11-20 13:50:45 --> Router Class Initialized
INFO - 2018-11-20 13:50:45 --> Output Class Initialized
INFO - 2018-11-20 13:50:45 --> Security Class Initialized
DEBUG - 2018-11-20 13:50:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-20 13:50:45 --> Input Class Initialized
INFO - 2018-11-20 13:50:45 --> Language Class Initialized
INFO - 2018-11-20 13:50:45 --> Loader Class Initialized
INFO - 2018-11-20 13:50:45 --> Helper loaded: url_helper
INFO - 2018-11-20 13:50:45 --> Helper loaded: file_helper
INFO - 2018-11-20 13:50:45 --> Helper loaded: email_helper
INFO - 2018-11-20 13:50:45 --> Helper loaded: common_helper
INFO - 2018-11-20 13:50:45 --> Database Driver Class Initialized
DEBUG - 2018-11-20 13:50:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-20 13:50:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-20 13:50:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-20 13:50:45 --> Pagination Class Initialized
INFO - 2018-11-20 13:50:45 --> Helper loaded: form_helper
INFO - 2018-11-20 13:50:45 --> Form Validation Class Initialized
INFO - 2018-11-20 13:50:45 --> Model Class Initialized
INFO - 2018-11-20 13:50:45 --> Controller Class Initialized
INFO - 2018-11-20 13:50:45 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-20 13:50:45 --> Model Class Initialized
INFO - 2018-11-20 13:50:45 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-20 13:50:45 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/sidebar.php
INFO - 2018-11-20 13:50:45 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/right-sidebar.php
INFO - 2018-11-20 13:50:45 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/footer.php
INFO - 2018-11-20 13:50:45 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/dashboard.php
INFO - 2018-11-20 13:50:45 --> Final output sent to browser
DEBUG - 2018-11-20 13:50:45 --> Total execution time: 0.0600
INFO - 2018-11-20 13:51:53 --> Config Class Initialized
INFO - 2018-11-20 13:51:53 --> Hooks Class Initialized
DEBUG - 2018-11-20 13:51:53 --> UTF-8 Support Enabled
INFO - 2018-11-20 13:51:53 --> Utf8 Class Initialized
INFO - 2018-11-20 13:51:53 --> URI Class Initialized
INFO - 2018-11-20 13:51:53 --> Router Class Initialized
INFO - 2018-11-20 13:51:53 --> Output Class Initialized
INFO - 2018-11-20 13:51:53 --> Security Class Initialized
DEBUG - 2018-11-20 13:51:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-20 13:51:53 --> Input Class Initialized
INFO - 2018-11-20 13:51:53 --> Language Class Initialized
ERROR - 2018-11-20 13:51:53 --> 404 Page Not Found: Admin/admin
INFO - 2018-11-20 13:51:56 --> Config Class Initialized
INFO - 2018-11-20 13:51:56 --> Hooks Class Initialized
DEBUG - 2018-11-20 13:51:56 --> UTF-8 Support Enabled
INFO - 2018-11-20 13:51:56 --> Utf8 Class Initialized
INFO - 2018-11-20 13:51:56 --> URI Class Initialized
INFO - 2018-11-20 13:51:56 --> Router Class Initialized
INFO - 2018-11-20 13:51:56 --> Output Class Initialized
INFO - 2018-11-20 13:51:56 --> Security Class Initialized
DEBUG - 2018-11-20 13:51:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-20 13:51:56 --> Input Class Initialized
INFO - 2018-11-20 13:51:56 --> Language Class Initialized
ERROR - 2018-11-20 13:51:56 --> 404 Page Not Found: Admin/admin
INFO - 2018-11-20 13:51:57 --> Config Class Initialized
INFO - 2018-11-20 13:51:57 --> Hooks Class Initialized
DEBUG - 2018-11-20 13:51:58 --> UTF-8 Support Enabled
INFO - 2018-11-20 13:51:58 --> Utf8 Class Initialized
INFO - 2018-11-20 13:51:58 --> URI Class Initialized
INFO - 2018-11-20 13:51:58 --> Router Class Initialized
INFO - 2018-11-20 13:51:58 --> Output Class Initialized
INFO - 2018-11-20 13:51:58 --> Security Class Initialized
DEBUG - 2018-11-20 13:51:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-20 13:51:58 --> Input Class Initialized
INFO - 2018-11-20 13:51:58 --> Language Class Initialized
ERROR - 2018-11-20 13:51:58 --> 404 Page Not Found: Admin/admin
INFO - 2018-11-20 13:52:30 --> Config Class Initialized
INFO - 2018-11-20 13:52:30 --> Hooks Class Initialized
DEBUG - 2018-11-20 13:52:30 --> UTF-8 Support Enabled
INFO - 2018-11-20 13:52:30 --> Utf8 Class Initialized
INFO - 2018-11-20 13:52:30 --> URI Class Initialized
INFO - 2018-11-20 13:52:30 --> Router Class Initialized
INFO - 2018-11-20 13:52:30 --> Output Class Initialized
INFO - 2018-11-20 13:52:30 --> Security Class Initialized
DEBUG - 2018-11-20 13:52:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-20 13:52:30 --> Input Class Initialized
INFO - 2018-11-20 13:52:30 --> Language Class Initialized
INFO - 2018-11-20 13:52:30 --> Loader Class Initialized
INFO - 2018-11-20 13:52:30 --> Helper loaded: url_helper
INFO - 2018-11-20 13:52:30 --> Helper loaded: file_helper
INFO - 2018-11-20 13:52:30 --> Helper loaded: email_helper
INFO - 2018-11-20 13:52:30 --> Helper loaded: common_helper
INFO - 2018-11-20 13:52:30 --> Database Driver Class Initialized
DEBUG - 2018-11-20 13:52:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-20 13:52:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-20 13:52:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-20 13:52:30 --> Pagination Class Initialized
INFO - 2018-11-20 13:52:30 --> Helper loaded: form_helper
INFO - 2018-11-20 13:52:30 --> Form Validation Class Initialized
INFO - 2018-11-20 13:52:30 --> Model Class Initialized
INFO - 2018-11-20 13:52:30 --> Controller Class Initialized
INFO - 2018-11-20 13:52:30 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-20 13:52:30 --> Model Class Initialized
INFO - 2018-11-20 13:52:30 --> Model Class Initialized
INFO - 2018-11-20 13:52:30 --> Config Class Initialized
INFO - 2018-11-20 13:52:30 --> Hooks Class Initialized
DEBUG - 2018-11-20 13:52:30 --> UTF-8 Support Enabled
INFO - 2018-11-20 13:52:30 --> Utf8 Class Initialized
INFO - 2018-11-20 13:52:30 --> URI Class Initialized
INFO - 2018-11-20 13:52:30 --> Router Class Initialized
INFO - 2018-11-20 13:52:30 --> Output Class Initialized
INFO - 2018-11-20 13:52:30 --> Security Class Initialized
DEBUG - 2018-11-20 13:52:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-20 13:52:30 --> Input Class Initialized
INFO - 2018-11-20 13:52:30 --> Language Class Initialized
ERROR - 2018-11-20 13:52:30 --> 404 Page Not Found: Admin/dashboard
INFO - 2018-11-20 13:53:26 --> Config Class Initialized
INFO - 2018-11-20 13:53:26 --> Hooks Class Initialized
DEBUG - 2018-11-20 13:53:26 --> UTF-8 Support Enabled
INFO - 2018-11-20 13:53:26 --> Utf8 Class Initialized
INFO - 2018-11-20 13:53:26 --> URI Class Initialized
INFO - 2018-11-20 13:53:26 --> Router Class Initialized
INFO - 2018-11-20 13:53:26 --> Output Class Initialized
INFO - 2018-11-20 13:53:26 --> Security Class Initialized
DEBUG - 2018-11-20 13:53:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-20 13:53:26 --> Input Class Initialized
INFO - 2018-11-20 13:53:26 --> Language Class Initialized
ERROR - 2018-11-20 13:53:26 --> 404 Page Not Found: Admin/dashboard
INFO - 2018-11-20 13:53:32 --> Config Class Initialized
INFO - 2018-11-20 13:53:32 --> Hooks Class Initialized
DEBUG - 2018-11-20 13:53:32 --> UTF-8 Support Enabled
INFO - 2018-11-20 13:53:32 --> Utf8 Class Initialized
INFO - 2018-11-20 13:53:32 --> URI Class Initialized
INFO - 2018-11-20 13:53:32 --> Router Class Initialized
INFO - 2018-11-20 13:53:32 --> Output Class Initialized
INFO - 2018-11-20 13:53:32 --> Security Class Initialized
DEBUG - 2018-11-20 13:53:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-20 13:53:32 --> Input Class Initialized
INFO - 2018-11-20 13:53:32 --> Language Class Initialized
INFO - 2018-11-20 13:53:33 --> Loader Class Initialized
INFO - 2018-11-20 13:53:33 --> Helper loaded: url_helper
INFO - 2018-11-20 13:53:33 --> Helper loaded: file_helper
INFO - 2018-11-20 13:53:33 --> Helper loaded: email_helper
INFO - 2018-11-20 13:53:33 --> Helper loaded: common_helper
INFO - 2018-11-20 13:53:33 --> Database Driver Class Initialized
DEBUG - 2018-11-20 13:53:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-20 13:53:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-20 13:53:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-20 13:53:33 --> Pagination Class Initialized
INFO - 2018-11-20 13:53:33 --> Helper loaded: form_helper
INFO - 2018-11-20 13:53:33 --> Form Validation Class Initialized
INFO - 2018-11-20 13:53:33 --> Model Class Initialized
INFO - 2018-11-20 13:53:33 --> Controller Class Initialized
INFO - 2018-11-20 13:53:33 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-20 13:53:33 --> Model Class Initialized
INFO - 2018-11-20 13:53:33 --> Model Class Initialized
INFO - 2018-11-20 13:53:33 --> Config Class Initialized
INFO - 2018-11-20 13:53:33 --> Hooks Class Initialized
DEBUG - 2018-11-20 13:53:33 --> UTF-8 Support Enabled
INFO - 2018-11-20 13:53:33 --> Utf8 Class Initialized
INFO - 2018-11-20 13:53:33 --> URI Class Initialized
INFO - 2018-11-20 13:53:33 --> Router Class Initialized
INFO - 2018-11-20 13:53:33 --> Output Class Initialized
INFO - 2018-11-20 13:53:33 --> Security Class Initialized
DEBUG - 2018-11-20 13:53:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-20 13:53:33 --> Input Class Initialized
INFO - 2018-11-20 13:53:33 --> Language Class Initialized
ERROR - 2018-11-20 13:53:33 --> 404 Page Not Found: Admin/dashboard
INFO - 2018-11-20 13:54:11 --> Config Class Initialized
INFO - 2018-11-20 13:54:11 --> Hooks Class Initialized
DEBUG - 2018-11-20 13:54:11 --> UTF-8 Support Enabled
INFO - 2018-11-20 13:54:11 --> Utf8 Class Initialized
INFO - 2018-11-20 13:54:11 --> URI Class Initialized
INFO - 2018-11-20 13:54:11 --> Router Class Initialized
INFO - 2018-11-20 13:54:11 --> Output Class Initialized
INFO - 2018-11-20 13:54:11 --> Security Class Initialized
DEBUG - 2018-11-20 13:54:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-20 13:54:11 --> Input Class Initialized
INFO - 2018-11-20 13:54:11 --> Language Class Initialized
ERROR - 2018-11-20 13:54:11 --> 404 Page Not Found: Admin/dashboard
INFO - 2018-11-20 13:54:15 --> Config Class Initialized
INFO - 2018-11-20 13:54:15 --> Hooks Class Initialized
DEBUG - 2018-11-20 13:54:15 --> UTF-8 Support Enabled
INFO - 2018-11-20 13:54:15 --> Utf8 Class Initialized
INFO - 2018-11-20 13:54:15 --> URI Class Initialized
INFO - 2018-11-20 13:54:15 --> Router Class Initialized
INFO - 2018-11-20 13:54:15 --> Output Class Initialized
INFO - 2018-11-20 13:54:15 --> Security Class Initialized
DEBUG - 2018-11-20 13:54:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-20 13:54:15 --> Input Class Initialized
INFO - 2018-11-20 13:54:15 --> Language Class Initialized
INFO - 2018-11-20 13:54:15 --> Loader Class Initialized
INFO - 2018-11-20 13:54:15 --> Helper loaded: url_helper
INFO - 2018-11-20 13:54:15 --> Helper loaded: file_helper
INFO - 2018-11-20 13:54:15 --> Helper loaded: email_helper
INFO - 2018-11-20 13:54:15 --> Helper loaded: common_helper
INFO - 2018-11-20 13:54:15 --> Database Driver Class Initialized
DEBUG - 2018-11-20 13:54:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-20 13:54:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-20 13:54:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-20 13:54:15 --> Pagination Class Initialized
INFO - 2018-11-20 13:54:15 --> Helper loaded: form_helper
INFO - 2018-11-20 13:54:15 --> Form Validation Class Initialized
INFO - 2018-11-20 13:54:15 --> Model Class Initialized
INFO - 2018-11-20 13:54:15 --> Controller Class Initialized
INFO - 2018-11-20 13:54:15 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-20 13:54:15 --> Model Class Initialized
INFO - 2018-11-20 13:54:15 --> Model Class Initialized
INFO - 2018-11-20 13:54:15 --> Config Class Initialized
INFO - 2018-11-20 13:54:15 --> Hooks Class Initialized
DEBUG - 2018-11-20 13:54:15 --> UTF-8 Support Enabled
INFO - 2018-11-20 13:54:15 --> Utf8 Class Initialized
INFO - 2018-11-20 13:54:15 --> URI Class Initialized
INFO - 2018-11-20 13:54:15 --> Router Class Initialized
INFO - 2018-11-20 13:54:15 --> Output Class Initialized
INFO - 2018-11-20 13:54:15 --> Security Class Initialized
DEBUG - 2018-11-20 13:54:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-20 13:54:15 --> Input Class Initialized
INFO - 2018-11-20 13:54:15 --> Language Class Initialized
ERROR - 2018-11-20 13:54:15 --> 404 Page Not Found: Admin/dashboard
INFO - 2018-11-20 13:54:41 --> Config Class Initialized
INFO - 2018-11-20 13:54:41 --> Hooks Class Initialized
DEBUG - 2018-11-20 13:54:41 --> UTF-8 Support Enabled
INFO - 2018-11-20 13:54:41 --> Utf8 Class Initialized
INFO - 2018-11-20 13:54:41 --> URI Class Initialized
INFO - 2018-11-20 13:54:41 --> Router Class Initialized
INFO - 2018-11-20 13:54:41 --> Output Class Initialized
INFO - 2018-11-20 13:54:41 --> Security Class Initialized
DEBUG - 2018-11-20 13:54:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-20 13:54:41 --> Input Class Initialized
INFO - 2018-11-20 13:54:41 --> Language Class Initialized
INFO - 2018-11-20 13:54:41 --> Loader Class Initialized
INFO - 2018-11-20 13:54:41 --> Helper loaded: url_helper
INFO - 2018-11-20 13:54:41 --> Helper loaded: file_helper
INFO - 2018-11-20 13:54:41 --> Helper loaded: email_helper
INFO - 2018-11-20 13:54:41 --> Helper loaded: common_helper
INFO - 2018-11-20 13:54:41 --> Database Driver Class Initialized
DEBUG - 2018-11-20 13:54:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-20 13:54:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-20 13:54:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-20 13:54:41 --> Pagination Class Initialized
INFO - 2018-11-20 13:54:41 --> Helper loaded: form_helper
INFO - 2018-11-20 13:54:41 --> Form Validation Class Initialized
INFO - 2018-11-20 13:54:41 --> Model Class Initialized
INFO - 2018-11-20 13:54:41 --> Controller Class Initialized
INFO - 2018-11-20 13:54:41 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-20 13:54:41 --> Model Class Initialized
INFO - 2018-11-20 13:54:41 --> Model Class Initialized
INFO - 2018-11-20 13:54:41 --> Config Class Initialized
INFO - 2018-11-20 13:54:41 --> Hooks Class Initialized
DEBUG - 2018-11-20 13:54:41 --> UTF-8 Support Enabled
INFO - 2018-11-20 13:54:41 --> Utf8 Class Initialized
INFO - 2018-11-20 13:54:41 --> URI Class Initialized
INFO - 2018-11-20 13:54:41 --> Router Class Initialized
INFO - 2018-11-20 13:54:41 --> Output Class Initialized
INFO - 2018-11-20 13:54:41 --> Security Class Initialized
DEBUG - 2018-11-20 13:54:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-20 13:54:41 --> Input Class Initialized
INFO - 2018-11-20 13:54:41 --> Language Class Initialized
ERROR - 2018-11-20 13:54:41 --> 404 Page Not Found: Admin/dashboard
INFO - 2018-11-20 13:55:02 --> Config Class Initialized
INFO - 2018-11-20 13:55:02 --> Hooks Class Initialized
DEBUG - 2018-11-20 13:55:02 --> UTF-8 Support Enabled
INFO - 2018-11-20 13:55:02 --> Utf8 Class Initialized
INFO - 2018-11-20 13:55:02 --> URI Class Initialized
INFO - 2018-11-20 13:55:02 --> Router Class Initialized
INFO - 2018-11-20 13:55:02 --> Output Class Initialized
INFO - 2018-11-20 13:55:02 --> Security Class Initialized
DEBUG - 2018-11-20 13:55:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-20 13:55:02 --> Input Class Initialized
INFO - 2018-11-20 13:55:02 --> Language Class Initialized
INFO - 2018-11-20 13:55:02 --> Loader Class Initialized
INFO - 2018-11-20 13:55:02 --> Helper loaded: url_helper
INFO - 2018-11-20 13:55:02 --> Helper loaded: file_helper
INFO - 2018-11-20 13:55:02 --> Helper loaded: email_helper
INFO - 2018-11-20 13:55:02 --> Helper loaded: common_helper
INFO - 2018-11-20 13:55:02 --> Database Driver Class Initialized
DEBUG - 2018-11-20 13:55:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-20 13:55:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-20 13:55:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-20 13:55:02 --> Pagination Class Initialized
INFO - 2018-11-20 13:55:02 --> Helper loaded: form_helper
INFO - 2018-11-20 13:55:02 --> Form Validation Class Initialized
INFO - 2018-11-20 13:55:02 --> Model Class Initialized
INFO - 2018-11-20 13:55:02 --> Controller Class Initialized
INFO - 2018-11-20 13:55:02 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-20 13:55:02 --> Model Class Initialized
INFO - 2018-11-20 13:55:02 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-20 13:55:02 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/sidebar.php
INFO - 2018-11-20 13:55:02 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/right-sidebar.php
INFO - 2018-11-20 13:55:02 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/footer.php
INFO - 2018-11-20 13:55:02 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/dashboard.php
INFO - 2018-11-20 13:55:02 --> Final output sent to browser
DEBUG - 2018-11-20 13:55:02 --> Total execution time: 0.0570
INFO - 2018-11-20 13:55:38 --> Config Class Initialized
INFO - 2018-11-20 13:55:38 --> Hooks Class Initialized
DEBUG - 2018-11-20 13:55:38 --> UTF-8 Support Enabled
INFO - 2018-11-20 13:55:38 --> Utf8 Class Initialized
INFO - 2018-11-20 13:55:38 --> URI Class Initialized
INFO - 2018-11-20 13:55:38 --> Router Class Initialized
INFO - 2018-11-20 13:55:38 --> Output Class Initialized
INFO - 2018-11-20 13:55:38 --> Security Class Initialized
DEBUG - 2018-11-20 13:55:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-20 13:55:38 --> Input Class Initialized
INFO - 2018-11-20 13:55:38 --> Language Class Initialized
ERROR - 2018-11-20 13:55:38 --> 404 Page Not Found: admin//index
INFO - 2018-11-20 13:55:40 --> Config Class Initialized
INFO - 2018-11-20 13:55:40 --> Hooks Class Initialized
DEBUG - 2018-11-20 13:55:40 --> UTF-8 Support Enabled
INFO - 2018-11-20 13:55:40 --> Utf8 Class Initialized
INFO - 2018-11-20 13:55:40 --> URI Class Initialized
INFO - 2018-11-20 13:55:40 --> Router Class Initialized
INFO - 2018-11-20 13:55:40 --> Output Class Initialized
INFO - 2018-11-20 13:55:40 --> Security Class Initialized
DEBUG - 2018-11-20 13:55:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-20 13:55:40 --> Input Class Initialized
INFO - 2018-11-20 13:55:40 --> Language Class Initialized
ERROR - 2018-11-20 13:55:40 --> 404 Page Not Found: admin//index
INFO - 2018-11-20 13:55:49 --> Config Class Initialized
INFO - 2018-11-20 13:55:49 --> Hooks Class Initialized
DEBUG - 2018-11-20 13:55:49 --> UTF-8 Support Enabled
INFO - 2018-11-20 13:55:49 --> Utf8 Class Initialized
INFO - 2018-11-20 13:55:49 --> URI Class Initialized
INFO - 2018-11-20 13:55:49 --> Router Class Initialized
INFO - 2018-11-20 13:55:49 --> Output Class Initialized
INFO - 2018-11-20 13:55:49 --> Security Class Initialized
DEBUG - 2018-11-20 13:55:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-20 13:55:49 --> Input Class Initialized
INFO - 2018-11-20 13:55:49 --> Language Class Initialized
ERROR - 2018-11-20 13:55:49 --> Severity: Warning --> require(common/Index_Controller.php): failed to open stream: No such file or directory C:\xampp\htdocs\wetinuneed\application\controllers\admin\Admin.php 3
ERROR - 2018-11-20 13:55:49 --> Severity: Compile Error --> require(): Failed opening required 'common/Index_Controller.php' (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\wetinuneed\application\controllers\admin\Admin.php 3
INFO - 2018-11-20 13:56:21 --> Config Class Initialized
INFO - 2018-11-20 13:56:21 --> Hooks Class Initialized
DEBUG - 2018-11-20 13:56:21 --> UTF-8 Support Enabled
INFO - 2018-11-20 13:56:21 --> Utf8 Class Initialized
INFO - 2018-11-20 13:56:21 --> URI Class Initialized
INFO - 2018-11-20 13:56:21 --> Router Class Initialized
INFO - 2018-11-20 13:56:21 --> Output Class Initialized
INFO - 2018-11-20 13:56:21 --> Security Class Initialized
DEBUG - 2018-11-20 13:56:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-20 13:56:21 --> Input Class Initialized
INFO - 2018-11-20 13:56:21 --> Language Class Initialized
INFO - 2018-11-20 13:56:21 --> Loader Class Initialized
INFO - 2018-11-20 13:56:21 --> Helper loaded: url_helper
INFO - 2018-11-20 13:56:21 --> Helper loaded: file_helper
INFO - 2018-11-20 13:56:21 --> Helper loaded: email_helper
INFO - 2018-11-20 13:56:21 --> Helper loaded: common_helper
INFO - 2018-11-20 13:56:21 --> Database Driver Class Initialized
DEBUG - 2018-11-20 13:56:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-20 13:56:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-20 13:56:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-20 13:56:21 --> Pagination Class Initialized
INFO - 2018-11-20 13:56:21 --> Helper loaded: form_helper
INFO - 2018-11-20 13:56:21 --> Form Validation Class Initialized
INFO - 2018-11-20 13:56:22 --> Model Class Initialized
INFO - 2018-11-20 13:56:22 --> Controller Class Initialized
INFO - 2018-11-20 13:56:22 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-20 13:56:22 --> Model Class Initialized
INFO - 2018-11-20 13:56:22 --> Model Class Initialized
INFO - 2018-11-20 13:56:22 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/index.php
INFO - 2018-11-20 13:56:22 --> Final output sent to browser
DEBUG - 2018-11-20 13:56:22 --> Total execution time: 0.0730
INFO - 2018-11-20 13:56:40 --> Config Class Initialized
INFO - 2018-11-20 13:56:40 --> Hooks Class Initialized
DEBUG - 2018-11-20 13:56:40 --> UTF-8 Support Enabled
INFO - 2018-11-20 13:56:40 --> Utf8 Class Initialized
INFO - 2018-11-20 13:56:40 --> URI Class Initialized
INFO - 2018-11-20 13:56:40 --> Router Class Initialized
INFO - 2018-11-20 13:56:40 --> Output Class Initialized
INFO - 2018-11-20 13:56:40 --> Security Class Initialized
DEBUG - 2018-11-20 13:56:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-20 13:56:40 --> Input Class Initialized
INFO - 2018-11-20 13:56:40 --> Language Class Initialized
INFO - 2018-11-20 13:56:40 --> Loader Class Initialized
INFO - 2018-11-20 13:56:40 --> Helper loaded: url_helper
INFO - 2018-11-20 13:56:40 --> Helper loaded: file_helper
INFO - 2018-11-20 13:56:40 --> Helper loaded: email_helper
INFO - 2018-11-20 13:56:40 --> Helper loaded: common_helper
INFO - 2018-11-20 13:56:40 --> Database Driver Class Initialized
DEBUG - 2018-11-20 13:56:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-20 13:56:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-20 13:56:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-20 13:56:40 --> Pagination Class Initialized
INFO - 2018-11-20 13:56:40 --> Helper loaded: form_helper
INFO - 2018-11-20 13:56:40 --> Form Validation Class Initialized
INFO - 2018-11-20 13:56:40 --> Model Class Initialized
INFO - 2018-11-20 13:56:40 --> Controller Class Initialized
INFO - 2018-11-20 13:56:40 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-20 13:56:40 --> Model Class Initialized
INFO - 2018-11-20 13:56:40 --> Model Class Initialized
ERROR - 2018-11-20 13:56:40 --> Severity: Notice --> Undefined index: remember_me C:\xampp\htdocs\wetinuneed\application\controllers\admin\Admin.php 76
INFO - 2018-11-20 13:56:40 --> Config Class Initialized
INFO - 2018-11-20 13:56:40 --> Hooks Class Initialized
DEBUG - 2018-11-20 13:56:40 --> UTF-8 Support Enabled
INFO - 2018-11-20 13:56:40 --> Utf8 Class Initialized
INFO - 2018-11-20 13:56:40 --> URI Class Initialized
INFO - 2018-11-20 13:56:40 --> Router Class Initialized
INFO - 2018-11-20 13:56:40 --> Output Class Initialized
INFO - 2018-11-20 13:56:40 --> Security Class Initialized
DEBUG - 2018-11-20 13:56:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-20 13:56:40 --> Input Class Initialized
INFO - 2018-11-20 13:56:40 --> Language Class Initialized
INFO - 2018-11-20 13:56:40 --> Loader Class Initialized
INFO - 2018-11-20 13:56:40 --> Helper loaded: url_helper
INFO - 2018-11-20 13:56:40 --> Helper loaded: file_helper
INFO - 2018-11-20 13:56:40 --> Helper loaded: email_helper
INFO - 2018-11-20 13:56:40 --> Helper loaded: common_helper
INFO - 2018-11-20 13:56:40 --> Database Driver Class Initialized
DEBUG - 2018-11-20 13:56:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-20 13:56:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-20 13:56:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-20 13:56:40 --> Pagination Class Initialized
INFO - 2018-11-20 13:56:40 --> Helper loaded: form_helper
INFO - 2018-11-20 13:56:40 --> Form Validation Class Initialized
INFO - 2018-11-20 13:56:40 --> Model Class Initialized
INFO - 2018-11-20 13:56:40 --> Controller Class Initialized
INFO - 2018-11-20 13:56:40 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-20 13:56:40 --> Model Class Initialized
INFO - 2018-11-20 13:56:40 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-20 13:56:41 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/sidebar.php
INFO - 2018-11-20 13:56:41 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/right-sidebar.php
INFO - 2018-11-20 13:56:41 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/footer.php
INFO - 2018-11-20 13:56:41 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/dashboard.php
INFO - 2018-11-20 13:56:41 --> Final output sent to browser
DEBUG - 2018-11-20 13:56:41 --> Total execution time: 0.0550
INFO - 2018-11-20 13:57:08 --> Config Class Initialized
INFO - 2018-11-20 13:57:08 --> Hooks Class Initialized
DEBUG - 2018-11-20 13:57:08 --> UTF-8 Support Enabled
INFO - 2018-11-20 13:57:08 --> Utf8 Class Initialized
INFO - 2018-11-20 13:57:08 --> URI Class Initialized
INFO - 2018-11-20 13:57:08 --> Router Class Initialized
INFO - 2018-11-20 13:57:08 --> Output Class Initialized
INFO - 2018-11-20 13:57:08 --> Security Class Initialized
DEBUG - 2018-11-20 13:57:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-20 13:57:08 --> Input Class Initialized
INFO - 2018-11-20 13:57:08 --> Language Class Initialized
INFO - 2018-11-20 13:57:08 --> Loader Class Initialized
INFO - 2018-11-20 13:57:08 --> Helper loaded: url_helper
INFO - 2018-11-20 13:57:08 --> Helper loaded: file_helper
INFO - 2018-11-20 13:57:08 --> Helper loaded: email_helper
INFO - 2018-11-20 13:57:08 --> Helper loaded: common_helper
INFO - 2018-11-20 13:57:08 --> Database Driver Class Initialized
DEBUG - 2018-11-20 13:57:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-20 13:57:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-20 13:57:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-20 13:57:08 --> Pagination Class Initialized
INFO - 2018-11-20 13:57:08 --> Helper loaded: form_helper
INFO - 2018-11-20 13:57:08 --> Form Validation Class Initialized
INFO - 2018-11-20 13:57:08 --> Model Class Initialized
INFO - 2018-11-20 13:57:08 --> Controller Class Initialized
INFO - 2018-11-20 13:57:08 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-20 13:57:08 --> Model Class Initialized
INFO - 2018-11-20 13:57:08 --> Model Class Initialized
INFO - 2018-11-20 13:57:08 --> Config Class Initialized
INFO - 2018-11-20 13:57:08 --> Hooks Class Initialized
DEBUG - 2018-11-20 13:57:08 --> UTF-8 Support Enabled
INFO - 2018-11-20 13:57:08 --> Utf8 Class Initialized
INFO - 2018-11-20 13:57:08 --> URI Class Initialized
INFO - 2018-11-20 13:57:08 --> Router Class Initialized
INFO - 2018-11-20 13:57:08 --> Output Class Initialized
INFO - 2018-11-20 13:57:08 --> Security Class Initialized
DEBUG - 2018-11-20 13:57:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-20 13:57:08 --> Input Class Initialized
INFO - 2018-11-20 13:57:08 --> Language Class Initialized
INFO - 2018-11-20 13:57:08 --> Loader Class Initialized
INFO - 2018-11-20 13:57:08 --> Helper loaded: url_helper
INFO - 2018-11-20 13:57:08 --> Helper loaded: file_helper
INFO - 2018-11-20 13:57:08 --> Helper loaded: email_helper
INFO - 2018-11-20 13:57:08 --> Helper loaded: common_helper
INFO - 2018-11-20 13:57:08 --> Database Driver Class Initialized
DEBUG - 2018-11-20 13:57:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-20 13:57:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-20 13:57:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-20 13:57:08 --> Pagination Class Initialized
INFO - 2018-11-20 13:57:08 --> Helper loaded: form_helper
INFO - 2018-11-20 13:57:08 --> Form Validation Class Initialized
INFO - 2018-11-20 13:57:08 --> Model Class Initialized
INFO - 2018-11-20 13:57:08 --> Controller Class Initialized
INFO - 2018-11-20 13:57:08 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-20 13:57:08 --> Model Class Initialized
INFO - 2018-11-20 13:57:08 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-20 13:57:08 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/sidebar.php
INFO - 2018-11-20 13:57:08 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/right-sidebar.php
INFO - 2018-11-20 13:57:08 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/footer.php
INFO - 2018-11-20 13:57:08 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/dashboard.php
INFO - 2018-11-20 13:57:08 --> Final output sent to browser
DEBUG - 2018-11-20 13:57:08 --> Total execution time: 0.0530
INFO - 2018-11-20 13:57:19 --> Config Class Initialized
INFO - 2018-11-20 13:57:19 --> Hooks Class Initialized
DEBUG - 2018-11-20 13:57:19 --> UTF-8 Support Enabled
INFO - 2018-11-20 13:57:19 --> Utf8 Class Initialized
INFO - 2018-11-20 13:57:19 --> URI Class Initialized
INFO - 2018-11-20 13:57:19 --> Router Class Initialized
INFO - 2018-11-20 13:57:19 --> Output Class Initialized
INFO - 2018-11-20 13:57:19 --> Security Class Initialized
DEBUG - 2018-11-20 13:57:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-20 13:57:19 --> Input Class Initialized
INFO - 2018-11-20 13:57:19 --> Language Class Initialized
INFO - 2018-11-20 13:57:19 --> Loader Class Initialized
INFO - 2018-11-20 13:57:19 --> Helper loaded: url_helper
INFO - 2018-11-20 13:57:19 --> Helper loaded: file_helper
INFO - 2018-11-20 13:57:19 --> Helper loaded: email_helper
INFO - 2018-11-20 13:57:19 --> Helper loaded: common_helper
INFO - 2018-11-20 13:57:19 --> Database Driver Class Initialized
DEBUG - 2018-11-20 13:57:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-20 13:57:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-20 13:57:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-20 13:57:19 --> Pagination Class Initialized
INFO - 2018-11-20 13:57:19 --> Helper loaded: form_helper
INFO - 2018-11-20 13:57:19 --> Form Validation Class Initialized
INFO - 2018-11-20 13:57:19 --> Model Class Initialized
INFO - 2018-11-20 13:57:19 --> Controller Class Initialized
INFO - 2018-11-20 13:57:19 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-20 13:57:19 --> Model Class Initialized
INFO - 2018-11-20 13:57:19 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-20 13:57:19 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/sidebar.php
INFO - 2018-11-20 13:57:19 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/right-sidebar.php
INFO - 2018-11-20 13:57:19 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/footer.php
INFO - 2018-11-20 13:57:19 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/dashboard.php
INFO - 2018-11-20 13:57:19 --> Final output sent to browser
DEBUG - 2018-11-20 13:57:19 --> Total execution time: 0.0530
INFO - 2018-11-20 13:58:06 --> Config Class Initialized
INFO - 2018-11-20 13:58:06 --> Hooks Class Initialized
DEBUG - 2018-11-20 13:58:06 --> UTF-8 Support Enabled
INFO - 2018-11-20 13:58:06 --> Utf8 Class Initialized
INFO - 2018-11-20 13:58:06 --> URI Class Initialized
INFO - 2018-11-20 13:58:06 --> Router Class Initialized
INFO - 2018-11-20 13:58:06 --> Output Class Initialized
INFO - 2018-11-20 13:58:06 --> Security Class Initialized
DEBUG - 2018-11-20 13:58:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-20 13:58:06 --> Input Class Initialized
INFO - 2018-11-20 13:58:06 --> Language Class Initialized
INFO - 2018-11-20 13:58:06 --> Loader Class Initialized
INFO - 2018-11-20 13:58:06 --> Helper loaded: url_helper
INFO - 2018-11-20 13:58:06 --> Helper loaded: file_helper
INFO - 2018-11-20 13:58:06 --> Helper loaded: email_helper
INFO - 2018-11-20 13:58:06 --> Helper loaded: common_helper
INFO - 2018-11-20 13:58:06 --> Database Driver Class Initialized
DEBUG - 2018-11-20 13:58:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-20 13:58:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-20 13:58:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-20 13:58:06 --> Pagination Class Initialized
INFO - 2018-11-20 13:58:06 --> Helper loaded: form_helper
INFO - 2018-11-20 13:58:06 --> Form Validation Class Initialized
INFO - 2018-11-20 13:58:06 --> Model Class Initialized
INFO - 2018-11-20 13:58:06 --> Controller Class Initialized
INFO - 2018-11-20 13:58:06 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-20 13:58:06 --> Model Class Initialized
INFO - 2018-11-20 13:58:06 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-20 13:58:06 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/sidebar.php
INFO - 2018-11-20 13:58:06 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/right-sidebar.php
INFO - 2018-11-20 13:58:06 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/footer.php
INFO - 2018-11-20 13:58:06 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/dashboard.php
INFO - 2018-11-20 13:58:06 --> Final output sent to browser
DEBUG - 2018-11-20 13:58:06 --> Total execution time: 0.0790
INFO - 2018-11-20 14:00:06 --> Config Class Initialized
INFO - 2018-11-20 14:00:06 --> Hooks Class Initialized
DEBUG - 2018-11-20 14:00:06 --> UTF-8 Support Enabled
INFO - 2018-11-20 14:00:06 --> Utf8 Class Initialized
INFO - 2018-11-20 14:00:06 --> URI Class Initialized
INFO - 2018-11-20 14:00:06 --> Router Class Initialized
INFO - 2018-11-20 14:00:06 --> Output Class Initialized
INFO - 2018-11-20 14:00:06 --> Security Class Initialized
DEBUG - 2018-11-20 14:00:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-20 14:00:06 --> Input Class Initialized
INFO - 2018-11-20 14:00:06 --> Language Class Initialized
INFO - 2018-11-20 14:00:06 --> Loader Class Initialized
INFO - 2018-11-20 14:00:06 --> Helper loaded: url_helper
INFO - 2018-11-20 14:00:06 --> Helper loaded: file_helper
INFO - 2018-11-20 14:00:06 --> Helper loaded: email_helper
INFO - 2018-11-20 14:00:06 --> Helper loaded: common_helper
INFO - 2018-11-20 14:00:06 --> Database Driver Class Initialized
DEBUG - 2018-11-20 14:00:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-20 14:00:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-20 14:00:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-20 14:00:06 --> Pagination Class Initialized
INFO - 2018-11-20 14:00:06 --> Helper loaded: form_helper
INFO - 2018-11-20 14:00:06 --> Form Validation Class Initialized
INFO - 2018-11-20 14:00:06 --> Model Class Initialized
INFO - 2018-11-20 14:00:06 --> Controller Class Initialized
INFO - 2018-11-20 14:00:06 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-20 14:00:06 --> Model Class Initialized
INFO - 2018-11-20 14:00:06 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-20 14:00:06 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/sidebar.php
INFO - 2018-11-20 14:00:06 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/right-sidebar.php
INFO - 2018-11-20 14:00:06 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/footer.php
INFO - 2018-11-20 14:00:06 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/dashboard.php
INFO - 2018-11-20 14:00:06 --> Final output sent to browser
DEBUG - 2018-11-20 14:00:06 --> Total execution time: 0.0660
INFO - 2018-11-20 14:03:50 --> Config Class Initialized
INFO - 2018-11-20 14:03:50 --> Hooks Class Initialized
DEBUG - 2018-11-20 14:03:50 --> UTF-8 Support Enabled
INFO - 2018-11-20 14:03:50 --> Utf8 Class Initialized
INFO - 2018-11-20 14:03:50 --> URI Class Initialized
INFO - 2018-11-20 14:03:50 --> Router Class Initialized
INFO - 2018-11-20 14:03:50 --> Output Class Initialized
INFO - 2018-11-20 14:03:50 --> Security Class Initialized
DEBUG - 2018-11-20 14:03:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-20 14:03:50 --> Input Class Initialized
INFO - 2018-11-20 14:03:50 --> Language Class Initialized
INFO - 2018-11-20 14:03:50 --> Loader Class Initialized
INFO - 2018-11-20 14:03:50 --> Helper loaded: url_helper
INFO - 2018-11-20 14:03:50 --> Helper loaded: file_helper
INFO - 2018-11-20 14:03:50 --> Helper loaded: email_helper
INFO - 2018-11-20 14:03:50 --> Helper loaded: common_helper
INFO - 2018-11-20 14:03:50 --> Database Driver Class Initialized
DEBUG - 2018-11-20 14:03:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-20 14:03:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-20 14:03:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-20 14:03:50 --> Pagination Class Initialized
INFO - 2018-11-20 14:03:50 --> Helper loaded: form_helper
INFO - 2018-11-20 14:03:50 --> Form Validation Class Initialized
INFO - 2018-11-20 14:03:50 --> Model Class Initialized
INFO - 2018-11-20 14:03:50 --> Controller Class Initialized
INFO - 2018-11-20 14:03:50 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-20 14:03:50 --> Model Class Initialized
INFO - 2018-11-20 14:03:50 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-20 14:03:50 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/sidebar.php
INFO - 2018-11-20 14:03:50 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/right-sidebar.php
INFO - 2018-11-20 14:03:50 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/footer.php
INFO - 2018-11-20 14:03:50 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/dashboard.php
INFO - 2018-11-20 14:03:50 --> Final output sent to browser
DEBUG - 2018-11-20 14:03:50 --> Total execution time: 0.0530
INFO - 2018-11-20 14:03:56 --> Config Class Initialized
INFO - 2018-11-20 14:03:56 --> Hooks Class Initialized
DEBUG - 2018-11-20 14:03:56 --> UTF-8 Support Enabled
INFO - 2018-11-20 14:03:56 --> Utf8 Class Initialized
INFO - 2018-11-20 14:03:56 --> URI Class Initialized
INFO - 2018-11-20 14:03:56 --> Router Class Initialized
INFO - 2018-11-20 14:03:56 --> Output Class Initialized
INFO - 2018-11-20 14:03:56 --> Security Class Initialized
DEBUG - 2018-11-20 14:03:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-20 14:03:56 --> Input Class Initialized
INFO - 2018-11-20 14:03:56 --> Language Class Initialized
ERROR - 2018-11-20 14:03:56 --> 404 Page Not Found: admin/Logout/index
INFO - 2018-11-20 14:04:20 --> Config Class Initialized
INFO - 2018-11-20 14:04:20 --> Hooks Class Initialized
DEBUG - 2018-11-20 14:04:20 --> UTF-8 Support Enabled
INFO - 2018-11-20 14:04:20 --> Utf8 Class Initialized
INFO - 2018-11-20 14:04:20 --> URI Class Initialized
INFO - 2018-11-20 14:04:20 --> Router Class Initialized
INFO - 2018-11-20 14:04:20 --> Output Class Initialized
INFO - 2018-11-20 14:04:20 --> Security Class Initialized
DEBUG - 2018-11-20 14:04:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-20 14:04:20 --> Input Class Initialized
INFO - 2018-11-20 14:04:20 --> Language Class Initialized
ERROR - 2018-11-20 14:04:20 --> 404 Page Not Found: admin/Logout/index
INFO - 2018-11-20 14:04:22 --> Config Class Initialized
INFO - 2018-11-20 14:04:22 --> Hooks Class Initialized
DEBUG - 2018-11-20 14:04:22 --> UTF-8 Support Enabled
INFO - 2018-11-20 14:04:22 --> Utf8 Class Initialized
INFO - 2018-11-20 14:04:22 --> URI Class Initialized
INFO - 2018-11-20 14:04:22 --> Router Class Initialized
INFO - 2018-11-20 14:04:22 --> Output Class Initialized
INFO - 2018-11-20 14:04:22 --> Security Class Initialized
DEBUG - 2018-11-20 14:04:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-20 14:04:22 --> Input Class Initialized
INFO - 2018-11-20 14:04:22 --> Language Class Initialized
INFO - 2018-11-20 14:04:22 --> Loader Class Initialized
INFO - 2018-11-20 14:04:22 --> Helper loaded: url_helper
INFO - 2018-11-20 14:04:22 --> Helper loaded: file_helper
INFO - 2018-11-20 14:04:22 --> Helper loaded: email_helper
INFO - 2018-11-20 14:04:22 --> Helper loaded: common_helper
INFO - 2018-11-20 14:04:22 --> Database Driver Class Initialized
DEBUG - 2018-11-20 14:04:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-20 14:04:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-20 14:04:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-20 14:04:22 --> Pagination Class Initialized
INFO - 2018-11-20 14:04:22 --> Helper loaded: form_helper
INFO - 2018-11-20 14:04:22 --> Form Validation Class Initialized
INFO - 2018-11-20 14:04:22 --> Model Class Initialized
INFO - 2018-11-20 14:04:22 --> Controller Class Initialized
INFO - 2018-11-20 14:04:22 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-20 14:04:22 --> Model Class Initialized
INFO - 2018-11-20 14:04:22 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-20 14:04:22 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/sidebar.php
INFO - 2018-11-20 14:04:22 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/right-sidebar.php
INFO - 2018-11-20 14:04:22 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/footer.php
INFO - 2018-11-20 14:04:22 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/dashboard.php
INFO - 2018-11-20 14:04:22 --> Final output sent to browser
DEBUG - 2018-11-20 14:04:22 --> Total execution time: 0.0510
INFO - 2018-11-20 14:04:24 --> Config Class Initialized
INFO - 2018-11-20 14:04:24 --> Hooks Class Initialized
DEBUG - 2018-11-20 14:04:24 --> UTF-8 Support Enabled
INFO - 2018-11-20 14:04:24 --> Utf8 Class Initialized
INFO - 2018-11-20 14:04:24 --> URI Class Initialized
INFO - 2018-11-20 14:04:24 --> Router Class Initialized
INFO - 2018-11-20 14:04:24 --> Output Class Initialized
INFO - 2018-11-20 14:04:24 --> Security Class Initialized
DEBUG - 2018-11-20 14:04:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-20 14:04:24 --> Input Class Initialized
INFO - 2018-11-20 14:04:24 --> Language Class Initialized
INFO - 2018-11-20 14:04:24 --> Loader Class Initialized
INFO - 2018-11-20 14:04:24 --> Helper loaded: url_helper
INFO - 2018-11-20 14:04:24 --> Helper loaded: file_helper
INFO - 2018-11-20 14:04:24 --> Helper loaded: email_helper
INFO - 2018-11-20 14:04:24 --> Helper loaded: common_helper
INFO - 2018-11-20 14:04:24 --> Database Driver Class Initialized
DEBUG - 2018-11-20 14:04:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-20 14:04:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-20 14:04:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-20 14:04:24 --> Pagination Class Initialized
INFO - 2018-11-20 14:04:24 --> Helper loaded: form_helper
INFO - 2018-11-20 14:04:24 --> Form Validation Class Initialized
INFO - 2018-11-20 14:04:24 --> Model Class Initialized
INFO - 2018-11-20 14:04:24 --> Controller Class Initialized
INFO - 2018-11-20 14:04:24 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-20 14:04:24 --> Model Class Initialized
INFO - 2018-11-20 14:04:24 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-20 14:04:24 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/sidebar.php
INFO - 2018-11-20 14:04:24 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/right-sidebar.php
INFO - 2018-11-20 14:04:24 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/footer.php
INFO - 2018-11-20 14:04:24 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/dashboard.php
INFO - 2018-11-20 14:04:24 --> Final output sent to browser
DEBUG - 2018-11-20 14:04:24 --> Total execution time: 0.0520
INFO - 2018-11-20 14:04:29 --> Config Class Initialized
INFO - 2018-11-20 14:04:29 --> Hooks Class Initialized
DEBUG - 2018-11-20 14:04:29 --> UTF-8 Support Enabled
INFO - 2018-11-20 14:04:29 --> Utf8 Class Initialized
INFO - 2018-11-20 14:04:29 --> URI Class Initialized
INFO - 2018-11-20 14:04:29 --> Router Class Initialized
INFO - 2018-11-20 14:04:29 --> Output Class Initialized
INFO - 2018-11-20 14:04:29 --> Security Class Initialized
DEBUG - 2018-11-20 14:04:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-20 14:04:29 --> Input Class Initialized
INFO - 2018-11-20 14:04:29 --> Language Class Initialized
ERROR - 2018-11-20 14:04:29 --> 404 Page Not Found: admin/Logout/index
INFO - 2018-11-20 14:04:49 --> Config Class Initialized
INFO - 2018-11-20 14:04:49 --> Hooks Class Initialized
DEBUG - 2018-11-20 14:04:49 --> UTF-8 Support Enabled
INFO - 2018-11-20 14:04:49 --> Utf8 Class Initialized
INFO - 2018-11-20 14:04:49 --> URI Class Initialized
INFO - 2018-11-20 14:04:49 --> Router Class Initialized
INFO - 2018-11-20 14:04:49 --> Output Class Initialized
INFO - 2018-11-20 14:04:49 --> Security Class Initialized
DEBUG - 2018-11-20 14:04:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-20 14:04:49 --> Input Class Initialized
INFO - 2018-11-20 14:04:49 --> Language Class Initialized
INFO - 2018-11-20 14:04:49 --> Loader Class Initialized
INFO - 2018-11-20 14:04:49 --> Helper loaded: url_helper
INFO - 2018-11-20 14:04:49 --> Helper loaded: file_helper
INFO - 2018-11-20 14:04:49 --> Helper loaded: email_helper
INFO - 2018-11-20 14:04:49 --> Helper loaded: common_helper
INFO - 2018-11-20 14:04:49 --> Database Driver Class Initialized
DEBUG - 2018-11-20 14:04:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-20 14:04:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-20 14:04:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-20 14:04:49 --> Pagination Class Initialized
INFO - 2018-11-20 14:04:49 --> Helper loaded: form_helper
INFO - 2018-11-20 14:04:49 --> Form Validation Class Initialized
INFO - 2018-11-20 14:04:49 --> Model Class Initialized
INFO - 2018-11-20 14:04:49 --> Controller Class Initialized
INFO - 2018-11-20 14:04:49 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-20 14:04:49 --> Model Class Initialized
INFO - 2018-11-20 14:04:49 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-20 14:04:49 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/sidebar.php
INFO - 2018-11-20 14:04:49 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/right-sidebar.php
INFO - 2018-11-20 14:04:49 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/footer.php
INFO - 2018-11-20 14:04:49 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/dashboard.php
INFO - 2018-11-20 14:04:49 --> Final output sent to browser
DEBUG - 2018-11-20 14:04:49 --> Total execution time: 0.0490
INFO - 2018-11-20 14:05:26 --> Config Class Initialized
INFO - 2018-11-20 14:05:26 --> Hooks Class Initialized
DEBUG - 2018-11-20 14:05:26 --> UTF-8 Support Enabled
INFO - 2018-11-20 14:05:26 --> Utf8 Class Initialized
INFO - 2018-11-20 14:05:26 --> URI Class Initialized
INFO - 2018-11-20 14:05:26 --> Router Class Initialized
INFO - 2018-11-20 14:05:26 --> Output Class Initialized
INFO - 2018-11-20 14:05:26 --> Security Class Initialized
DEBUG - 2018-11-20 14:05:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-20 14:05:26 --> Input Class Initialized
INFO - 2018-11-20 14:05:26 --> Language Class Initialized
INFO - 2018-11-20 14:05:26 --> Loader Class Initialized
INFO - 2018-11-20 14:05:26 --> Helper loaded: url_helper
INFO - 2018-11-20 14:05:26 --> Helper loaded: file_helper
INFO - 2018-11-20 14:05:26 --> Helper loaded: email_helper
INFO - 2018-11-20 14:05:26 --> Helper loaded: common_helper
INFO - 2018-11-20 14:05:26 --> Database Driver Class Initialized
DEBUG - 2018-11-20 14:05:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-20 14:05:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-20 14:05:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-20 14:05:26 --> Pagination Class Initialized
INFO - 2018-11-20 14:05:26 --> Helper loaded: form_helper
INFO - 2018-11-20 14:05:26 --> Form Validation Class Initialized
INFO - 2018-11-20 14:05:26 --> Model Class Initialized
INFO - 2018-11-20 14:05:26 --> Controller Class Initialized
INFO - 2018-11-20 14:05:26 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-20 14:05:26 --> Model Class Initialized
INFO - 2018-11-20 14:05:26 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-20 14:05:26 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/sidebar.php
INFO - 2018-11-20 14:05:26 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/right-sidebar.php
INFO - 2018-11-20 14:05:26 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/footer.php
INFO - 2018-11-20 14:05:26 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/dashboard.php
INFO - 2018-11-20 14:05:26 --> Final output sent to browser
DEBUG - 2018-11-20 14:05:26 --> Total execution time: 0.0590
INFO - 2018-11-20 14:05:31 --> Config Class Initialized
INFO - 2018-11-20 14:05:31 --> Hooks Class Initialized
DEBUG - 2018-11-20 14:05:31 --> UTF-8 Support Enabled
INFO - 2018-11-20 14:05:31 --> Utf8 Class Initialized
INFO - 2018-11-20 14:05:31 --> URI Class Initialized
INFO - 2018-11-20 14:05:31 --> Router Class Initialized
INFO - 2018-11-20 14:05:31 --> Output Class Initialized
INFO - 2018-11-20 14:05:31 --> Security Class Initialized
DEBUG - 2018-11-20 14:05:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-20 14:05:31 --> Input Class Initialized
INFO - 2018-11-20 14:05:31 --> Language Class Initialized
INFO - 2018-11-20 14:05:31 --> Loader Class Initialized
INFO - 2018-11-20 14:05:31 --> Helper loaded: url_helper
INFO - 2018-11-20 14:05:31 --> Helper loaded: file_helper
INFO - 2018-11-20 14:05:31 --> Helper loaded: email_helper
INFO - 2018-11-20 14:05:31 --> Helper loaded: common_helper
INFO - 2018-11-20 14:05:31 --> Database Driver Class Initialized
DEBUG - 2018-11-20 14:05:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-20 14:05:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-20 14:05:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-20 14:05:31 --> Pagination Class Initialized
INFO - 2018-11-20 14:05:31 --> Helper loaded: form_helper
INFO - 2018-11-20 14:05:31 --> Form Validation Class Initialized
INFO - 2018-11-20 14:05:31 --> Model Class Initialized
INFO - 2018-11-20 14:05:31 --> Controller Class Initialized
INFO - 2018-11-20 14:05:31 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-20 14:05:31 --> Model Class Initialized
INFO - 2018-11-20 14:05:31 --> Model Class Initialized
INFO - 2018-11-20 14:05:31 --> Config Class Initialized
INFO - 2018-11-20 14:05:31 --> Hooks Class Initialized
DEBUG - 2018-11-20 14:05:31 --> UTF-8 Support Enabled
INFO - 2018-11-20 14:05:31 --> Utf8 Class Initialized
INFO - 2018-11-20 14:05:31 --> URI Class Initialized
INFO - 2018-11-20 14:05:31 --> Router Class Initialized
INFO - 2018-11-20 14:05:31 --> Output Class Initialized
INFO - 2018-11-20 14:05:31 --> Security Class Initialized
DEBUG - 2018-11-20 14:05:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-20 14:05:31 --> Input Class Initialized
INFO - 2018-11-20 14:05:31 --> Language Class Initialized
INFO - 2018-11-20 14:05:31 --> Loader Class Initialized
INFO - 2018-11-20 14:05:31 --> Helper loaded: url_helper
INFO - 2018-11-20 14:05:31 --> Helper loaded: file_helper
INFO - 2018-11-20 14:05:31 --> Helper loaded: email_helper
INFO - 2018-11-20 14:05:31 --> Helper loaded: common_helper
INFO - 2018-11-20 14:05:31 --> Database Driver Class Initialized
DEBUG - 2018-11-20 14:05:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-20 14:05:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-20 14:05:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-20 14:05:31 --> Pagination Class Initialized
INFO - 2018-11-20 14:05:31 --> Helper loaded: form_helper
INFO - 2018-11-20 14:05:31 --> Form Validation Class Initialized
INFO - 2018-11-20 14:05:31 --> Model Class Initialized
INFO - 2018-11-20 14:05:31 --> Controller Class Initialized
INFO - 2018-11-20 14:05:31 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-20 14:05:31 --> Model Class Initialized
INFO - 2018-11-20 14:05:31 --> Model Class Initialized
INFO - 2018-11-20 14:05:31 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/index.php
INFO - 2018-11-20 14:05:31 --> Final output sent to browser
DEBUG - 2018-11-20 14:05:31 --> Total execution time: 0.0520
INFO - 2018-11-20 14:05:44 --> Config Class Initialized
INFO - 2018-11-20 14:05:44 --> Hooks Class Initialized
DEBUG - 2018-11-20 14:05:44 --> UTF-8 Support Enabled
INFO - 2018-11-20 14:05:44 --> Utf8 Class Initialized
INFO - 2018-11-20 14:05:44 --> URI Class Initialized
INFO - 2018-11-20 14:05:44 --> Router Class Initialized
INFO - 2018-11-20 14:05:44 --> Output Class Initialized
INFO - 2018-11-20 14:05:44 --> Security Class Initialized
DEBUG - 2018-11-20 14:05:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-20 14:05:44 --> Input Class Initialized
INFO - 2018-11-20 14:05:44 --> Language Class Initialized
INFO - 2018-11-20 14:05:44 --> Loader Class Initialized
INFO - 2018-11-20 14:05:44 --> Helper loaded: url_helper
INFO - 2018-11-20 14:05:44 --> Helper loaded: file_helper
INFO - 2018-11-20 14:05:44 --> Helper loaded: email_helper
INFO - 2018-11-20 14:05:44 --> Helper loaded: common_helper
INFO - 2018-11-20 14:05:44 --> Database Driver Class Initialized
DEBUG - 2018-11-20 14:05:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-20 14:05:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-20 14:05:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-20 14:05:44 --> Pagination Class Initialized
INFO - 2018-11-20 14:05:44 --> Helper loaded: form_helper
INFO - 2018-11-20 14:05:44 --> Form Validation Class Initialized
INFO - 2018-11-20 14:05:44 --> Model Class Initialized
INFO - 2018-11-20 14:05:44 --> Controller Class Initialized
INFO - 2018-11-20 14:05:44 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-20 14:05:44 --> Model Class Initialized
INFO - 2018-11-20 14:05:44 --> Model Class Initialized
ERROR - 2018-11-20 14:05:44 --> Severity: Notice --> Undefined index: remember_me C:\xampp\htdocs\wetinuneed\application\controllers\admin\Admin.php 76
INFO - 2018-11-20 14:05:44 --> Config Class Initialized
INFO - 2018-11-20 14:05:44 --> Hooks Class Initialized
DEBUG - 2018-11-20 14:05:44 --> UTF-8 Support Enabled
INFO - 2018-11-20 14:05:44 --> Utf8 Class Initialized
INFO - 2018-11-20 14:05:44 --> URI Class Initialized
INFO - 2018-11-20 14:05:44 --> Router Class Initialized
INFO - 2018-11-20 14:05:44 --> Output Class Initialized
INFO - 2018-11-20 14:05:44 --> Security Class Initialized
DEBUG - 2018-11-20 14:05:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-20 14:05:44 --> Input Class Initialized
INFO - 2018-11-20 14:05:44 --> Language Class Initialized
INFO - 2018-11-20 14:05:44 --> Loader Class Initialized
INFO - 2018-11-20 14:05:44 --> Helper loaded: url_helper
INFO - 2018-11-20 14:05:44 --> Helper loaded: file_helper
INFO - 2018-11-20 14:05:44 --> Helper loaded: email_helper
INFO - 2018-11-20 14:05:44 --> Helper loaded: common_helper
INFO - 2018-11-20 14:05:44 --> Database Driver Class Initialized
DEBUG - 2018-11-20 14:05:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-20 14:05:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-20 14:05:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-20 14:05:44 --> Pagination Class Initialized
INFO - 2018-11-20 14:05:44 --> Helper loaded: form_helper
INFO - 2018-11-20 14:05:44 --> Form Validation Class Initialized
INFO - 2018-11-20 14:05:44 --> Model Class Initialized
INFO - 2018-11-20 14:05:44 --> Controller Class Initialized
INFO - 2018-11-20 14:05:44 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-20 14:05:44 --> Model Class Initialized
INFO - 2018-11-20 14:05:44 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-20 14:05:44 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/sidebar.php
INFO - 2018-11-20 14:05:44 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/right-sidebar.php
INFO - 2018-11-20 14:05:44 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/footer.php
INFO - 2018-11-20 14:05:44 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/dashboard.php
INFO - 2018-11-20 14:05:44 --> Final output sent to browser
DEBUG - 2018-11-20 14:05:44 --> Total execution time: 0.0430
INFO - 2018-11-20 14:06:00 --> Config Class Initialized
INFO - 2018-11-20 14:06:00 --> Hooks Class Initialized
DEBUG - 2018-11-20 14:06:00 --> UTF-8 Support Enabled
INFO - 2018-11-20 14:06:00 --> Utf8 Class Initialized
INFO - 2018-11-20 14:06:00 --> URI Class Initialized
INFO - 2018-11-20 14:06:00 --> Router Class Initialized
INFO - 2018-11-20 14:06:00 --> Output Class Initialized
INFO - 2018-11-20 14:06:00 --> Security Class Initialized
DEBUG - 2018-11-20 14:06:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-20 14:06:00 --> Input Class Initialized
INFO - 2018-11-20 14:06:00 --> Language Class Initialized
INFO - 2018-11-20 14:06:00 --> Loader Class Initialized
INFO - 2018-11-20 14:06:00 --> Helper loaded: url_helper
INFO - 2018-11-20 14:06:00 --> Helper loaded: file_helper
INFO - 2018-11-20 14:06:00 --> Helper loaded: email_helper
INFO - 2018-11-20 14:06:00 --> Helper loaded: common_helper
INFO - 2018-11-20 14:06:00 --> Database Driver Class Initialized
DEBUG - 2018-11-20 14:06:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-20 14:06:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-20 14:06:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-20 14:06:00 --> Pagination Class Initialized
INFO - 2018-11-20 14:06:00 --> Helper loaded: form_helper
INFO - 2018-11-20 14:06:00 --> Form Validation Class Initialized
INFO - 2018-11-20 14:06:00 --> Model Class Initialized
INFO - 2018-11-20 14:06:00 --> Controller Class Initialized
INFO - 2018-11-20 14:06:00 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-20 14:06:00 --> Model Class Initialized
INFO - 2018-11-20 14:06:00 --> Model Class Initialized
INFO - 2018-11-20 14:06:00 --> Config Class Initialized
INFO - 2018-11-20 14:06:00 --> Hooks Class Initialized
DEBUG - 2018-11-20 14:06:00 --> UTF-8 Support Enabled
INFO - 2018-11-20 14:06:00 --> Utf8 Class Initialized
INFO - 2018-11-20 14:06:00 --> URI Class Initialized
INFO - 2018-11-20 14:06:00 --> Router Class Initialized
INFO - 2018-11-20 14:06:00 --> Output Class Initialized
INFO - 2018-11-20 14:06:00 --> Security Class Initialized
DEBUG - 2018-11-20 14:06:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-20 14:06:00 --> Input Class Initialized
INFO - 2018-11-20 14:06:00 --> Language Class Initialized
INFO - 2018-11-20 14:06:00 --> Loader Class Initialized
INFO - 2018-11-20 14:06:00 --> Helper loaded: url_helper
INFO - 2018-11-20 14:06:00 --> Helper loaded: file_helper
INFO - 2018-11-20 14:06:00 --> Helper loaded: email_helper
INFO - 2018-11-20 14:06:00 --> Helper loaded: common_helper
INFO - 2018-11-20 14:06:00 --> Database Driver Class Initialized
DEBUG - 2018-11-20 14:06:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-20 14:06:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-20 14:06:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-20 14:06:00 --> Pagination Class Initialized
INFO - 2018-11-20 14:06:00 --> Helper loaded: form_helper
INFO - 2018-11-20 14:06:00 --> Form Validation Class Initialized
INFO - 2018-11-20 14:06:00 --> Model Class Initialized
INFO - 2018-11-20 14:06:00 --> Controller Class Initialized
INFO - 2018-11-20 14:06:00 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-20 14:06:00 --> Model Class Initialized
INFO - 2018-11-20 14:06:00 --> Model Class Initialized
INFO - 2018-11-20 14:06:00 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/index.php
INFO - 2018-11-20 14:06:00 --> Final output sent to browser
DEBUG - 2018-11-20 14:06:00 --> Total execution time: 0.0430
INFO - 2018-11-20 14:06:04 --> Config Class Initialized
INFO - 2018-11-20 14:06:04 --> Hooks Class Initialized
DEBUG - 2018-11-20 14:06:04 --> UTF-8 Support Enabled
INFO - 2018-11-20 14:06:04 --> Utf8 Class Initialized
INFO - 2018-11-20 14:06:04 --> URI Class Initialized
INFO - 2018-11-20 14:06:04 --> Router Class Initialized
INFO - 2018-11-20 14:06:04 --> Output Class Initialized
INFO - 2018-11-20 14:06:04 --> Security Class Initialized
DEBUG - 2018-11-20 14:06:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-20 14:06:04 --> Input Class Initialized
INFO - 2018-11-20 14:06:04 --> Language Class Initialized
INFO - 2018-11-20 14:06:04 --> Loader Class Initialized
INFO - 2018-11-20 14:06:04 --> Helper loaded: url_helper
INFO - 2018-11-20 14:06:04 --> Helper loaded: file_helper
INFO - 2018-11-20 14:06:04 --> Helper loaded: email_helper
INFO - 2018-11-20 14:06:04 --> Helper loaded: common_helper
INFO - 2018-11-20 14:06:04 --> Database Driver Class Initialized
DEBUG - 2018-11-20 14:06:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-20 14:06:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-20 14:06:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-20 14:06:04 --> Pagination Class Initialized
INFO - 2018-11-20 14:06:04 --> Helper loaded: form_helper
INFO - 2018-11-20 14:06:04 --> Form Validation Class Initialized
INFO - 2018-11-20 14:06:04 --> Model Class Initialized
INFO - 2018-11-20 14:06:04 --> Controller Class Initialized
INFO - 2018-11-20 14:06:04 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-20 14:06:04 --> Model Class Initialized
INFO - 2018-11-20 14:06:04 --> Model Class Initialized
INFO - 2018-11-20 14:06:04 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/index.php
INFO - 2018-11-20 14:06:04 --> Final output sent to browser
DEBUG - 2018-11-20 14:06:04 --> Total execution time: 0.0530
INFO - 2018-11-20 14:06:07 --> Config Class Initialized
INFO - 2018-11-20 14:06:07 --> Hooks Class Initialized
DEBUG - 2018-11-20 14:06:07 --> UTF-8 Support Enabled
INFO - 2018-11-20 14:06:07 --> Utf8 Class Initialized
INFO - 2018-11-20 14:06:07 --> URI Class Initialized
INFO - 2018-11-20 14:06:07 --> Router Class Initialized
INFO - 2018-11-20 14:06:07 --> Output Class Initialized
INFO - 2018-11-20 14:06:07 --> Security Class Initialized
DEBUG - 2018-11-20 14:06:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-20 14:06:07 --> Input Class Initialized
INFO - 2018-11-20 14:06:07 --> Language Class Initialized
INFO - 2018-11-20 14:06:07 --> Loader Class Initialized
INFO - 2018-11-20 14:06:07 --> Helper loaded: url_helper
INFO - 2018-11-20 14:06:07 --> Helper loaded: file_helper
INFO - 2018-11-20 14:06:07 --> Helper loaded: email_helper
INFO - 2018-11-20 14:06:07 --> Helper loaded: common_helper
INFO - 2018-11-20 14:06:07 --> Database Driver Class Initialized
DEBUG - 2018-11-20 14:06:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-20 14:06:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-20 14:06:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-20 14:06:07 --> Pagination Class Initialized
INFO - 2018-11-20 14:06:07 --> Helper loaded: form_helper
INFO - 2018-11-20 14:06:07 --> Form Validation Class Initialized
INFO - 2018-11-20 14:06:07 --> Model Class Initialized
INFO - 2018-11-20 14:06:07 --> Controller Class Initialized
INFO - 2018-11-20 14:06:07 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-20 14:06:07 --> Model Class Initialized
INFO - 2018-11-20 14:06:07 --> Model Class Initialized
INFO - 2018-11-20 14:06:07 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/index.php
INFO - 2018-11-20 14:06:07 --> Final output sent to browser
DEBUG - 2018-11-20 14:06:07 --> Total execution time: 0.0560
INFO - 2018-11-20 14:06:08 --> Config Class Initialized
INFO - 2018-11-20 14:06:08 --> Hooks Class Initialized
DEBUG - 2018-11-20 14:06:08 --> UTF-8 Support Enabled
INFO - 2018-11-20 14:06:08 --> Utf8 Class Initialized
INFO - 2018-11-20 14:06:08 --> URI Class Initialized
INFO - 2018-11-20 14:06:08 --> Router Class Initialized
INFO - 2018-11-20 14:06:08 --> Output Class Initialized
INFO - 2018-11-20 14:06:08 --> Security Class Initialized
DEBUG - 2018-11-20 14:06:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-20 14:06:08 --> Input Class Initialized
INFO - 2018-11-20 14:06:08 --> Language Class Initialized
INFO - 2018-11-20 14:06:08 --> Loader Class Initialized
INFO - 2018-11-20 14:06:08 --> Helper loaded: url_helper
INFO - 2018-11-20 14:06:08 --> Helper loaded: file_helper
INFO - 2018-11-20 14:06:08 --> Helper loaded: email_helper
INFO - 2018-11-20 14:06:08 --> Helper loaded: common_helper
INFO - 2018-11-20 14:06:08 --> Database Driver Class Initialized
DEBUG - 2018-11-20 14:06:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-20 14:06:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-20 14:06:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-20 14:06:08 --> Pagination Class Initialized
INFO - 2018-11-20 14:06:08 --> Helper loaded: form_helper
INFO - 2018-11-20 14:06:08 --> Form Validation Class Initialized
INFO - 2018-11-20 14:06:08 --> Model Class Initialized
INFO - 2018-11-20 14:06:08 --> Controller Class Initialized
INFO - 2018-11-20 14:06:08 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-20 14:06:08 --> Model Class Initialized
INFO - 2018-11-20 14:06:08 --> Model Class Initialized
INFO - 2018-11-20 14:06:08 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/index.php
INFO - 2018-11-20 14:06:08 --> Final output sent to browser
DEBUG - 2018-11-20 14:06:08 --> Total execution time: 0.0570
INFO - 2018-11-20 14:07:49 --> Config Class Initialized
INFO - 2018-11-20 14:07:49 --> Hooks Class Initialized
DEBUG - 2018-11-20 14:07:49 --> UTF-8 Support Enabled
INFO - 2018-11-20 14:07:49 --> Utf8 Class Initialized
INFO - 2018-11-20 14:07:49 --> URI Class Initialized
INFO - 2018-11-20 14:07:49 --> Router Class Initialized
INFO - 2018-11-20 14:07:49 --> Output Class Initialized
INFO - 2018-11-20 14:07:49 --> Security Class Initialized
DEBUG - 2018-11-20 14:07:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-20 14:07:49 --> Input Class Initialized
INFO - 2018-11-20 14:07:49 --> Language Class Initialized
INFO - 2018-11-20 14:07:49 --> Loader Class Initialized
INFO - 2018-11-20 14:07:49 --> Helper loaded: url_helper
INFO - 2018-11-20 14:07:49 --> Helper loaded: file_helper
INFO - 2018-11-20 14:07:49 --> Helper loaded: email_helper
INFO - 2018-11-20 14:07:49 --> Helper loaded: common_helper
INFO - 2018-11-20 14:07:49 --> Database Driver Class Initialized
DEBUG - 2018-11-20 14:07:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-20 14:07:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-20 14:07:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-20 14:07:49 --> Pagination Class Initialized
INFO - 2018-11-20 14:07:49 --> Helper loaded: form_helper
INFO - 2018-11-20 14:07:49 --> Form Validation Class Initialized
INFO - 2018-11-20 14:07:49 --> Model Class Initialized
INFO - 2018-11-20 14:07:49 --> Controller Class Initialized
INFO - 2018-11-20 14:07:49 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-20 14:07:49 --> Model Class Initialized
INFO - 2018-11-20 14:07:49 --> Model Class Initialized
INFO - 2018-11-20 14:07:49 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/index.php
INFO - 2018-11-20 14:07:49 --> Final output sent to browser
DEBUG - 2018-11-20 14:07:49 --> Total execution time: 0.0580
INFO - 2018-11-20 14:07:55 --> Config Class Initialized
INFO - 2018-11-20 14:07:55 --> Hooks Class Initialized
DEBUG - 2018-11-20 14:07:55 --> UTF-8 Support Enabled
INFO - 2018-11-20 14:07:55 --> Utf8 Class Initialized
INFO - 2018-11-20 14:07:55 --> URI Class Initialized
INFO - 2018-11-20 14:07:55 --> Router Class Initialized
INFO - 2018-11-20 14:07:55 --> Output Class Initialized
INFO - 2018-11-20 14:07:55 --> Security Class Initialized
DEBUG - 2018-11-20 14:07:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-20 14:07:55 --> Input Class Initialized
INFO - 2018-11-20 14:07:55 --> Language Class Initialized
INFO - 2018-11-20 14:07:55 --> Loader Class Initialized
INFO - 2018-11-20 14:07:55 --> Helper loaded: url_helper
INFO - 2018-11-20 14:07:55 --> Helper loaded: file_helper
INFO - 2018-11-20 14:07:55 --> Helper loaded: email_helper
INFO - 2018-11-20 14:07:55 --> Helper loaded: common_helper
INFO - 2018-11-20 14:07:55 --> Database Driver Class Initialized
DEBUG - 2018-11-20 14:07:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-20 14:07:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-20 14:07:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-20 14:07:55 --> Pagination Class Initialized
INFO - 2018-11-20 14:07:55 --> Helper loaded: form_helper
INFO - 2018-11-20 14:07:55 --> Form Validation Class Initialized
INFO - 2018-11-20 14:07:55 --> Model Class Initialized
INFO - 2018-11-20 14:07:55 --> Controller Class Initialized
INFO - 2018-11-20 14:07:55 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-20 14:07:55 --> Model Class Initialized
INFO - 2018-11-20 14:07:55 --> Model Class Initialized
ERROR - 2018-11-20 14:07:55 --> Severity: Notice --> Undefined index: remember_me C:\xampp\htdocs\wetinuneed\application\controllers\admin\Admin.php 76
INFO - 2018-11-20 14:07:55 --> Config Class Initialized
INFO - 2018-11-20 14:07:55 --> Hooks Class Initialized
DEBUG - 2018-11-20 14:07:55 --> UTF-8 Support Enabled
INFO - 2018-11-20 14:07:55 --> Utf8 Class Initialized
INFO - 2018-11-20 14:07:55 --> URI Class Initialized
INFO - 2018-11-20 14:07:55 --> Router Class Initialized
INFO - 2018-11-20 14:07:55 --> Output Class Initialized
INFO - 2018-11-20 14:07:55 --> Security Class Initialized
DEBUG - 2018-11-20 14:07:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-20 14:07:55 --> Input Class Initialized
INFO - 2018-11-20 14:07:55 --> Language Class Initialized
INFO - 2018-11-20 14:07:55 --> Loader Class Initialized
INFO - 2018-11-20 14:07:55 --> Helper loaded: url_helper
INFO - 2018-11-20 14:07:55 --> Helper loaded: file_helper
INFO - 2018-11-20 14:07:55 --> Helper loaded: email_helper
INFO - 2018-11-20 14:07:55 --> Helper loaded: common_helper
INFO - 2018-11-20 14:07:55 --> Database Driver Class Initialized
DEBUG - 2018-11-20 14:07:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-20 14:07:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-20 14:07:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-20 14:07:55 --> Pagination Class Initialized
INFO - 2018-11-20 14:07:55 --> Helper loaded: form_helper
INFO - 2018-11-20 14:07:55 --> Form Validation Class Initialized
INFO - 2018-11-20 14:07:55 --> Model Class Initialized
INFO - 2018-11-20 14:07:55 --> Controller Class Initialized
INFO - 2018-11-20 14:07:55 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-20 14:07:55 --> Model Class Initialized
INFO - 2018-11-20 14:07:55 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-20 14:07:55 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/sidebar.php
INFO - 2018-11-20 14:07:55 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/right-sidebar.php
INFO - 2018-11-20 14:07:55 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/footer.php
INFO - 2018-11-20 14:07:55 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/dashboard.php
INFO - 2018-11-20 14:07:55 --> Final output sent to browser
DEBUG - 2018-11-20 14:07:55 --> Total execution time: 0.0550
INFO - 2018-11-20 14:08:05 --> Config Class Initialized
INFO - 2018-11-20 14:08:05 --> Hooks Class Initialized
DEBUG - 2018-11-20 14:08:05 --> UTF-8 Support Enabled
INFO - 2018-11-20 14:08:05 --> Utf8 Class Initialized
INFO - 2018-11-20 14:08:05 --> URI Class Initialized
INFO - 2018-11-20 14:08:05 --> Router Class Initialized
INFO - 2018-11-20 14:08:05 --> Output Class Initialized
INFO - 2018-11-20 14:08:05 --> Security Class Initialized
DEBUG - 2018-11-20 14:08:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-20 14:08:05 --> Input Class Initialized
INFO - 2018-11-20 14:08:05 --> Language Class Initialized
INFO - 2018-11-20 14:08:05 --> Loader Class Initialized
INFO - 2018-11-20 14:08:05 --> Helper loaded: url_helper
INFO - 2018-11-20 14:08:05 --> Helper loaded: file_helper
INFO - 2018-11-20 14:08:05 --> Helper loaded: email_helper
INFO - 2018-11-20 14:08:05 --> Helper loaded: common_helper
INFO - 2018-11-20 14:08:05 --> Database Driver Class Initialized
DEBUG - 2018-11-20 14:08:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-20 14:08:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-20 14:08:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-20 14:08:05 --> Pagination Class Initialized
INFO - 2018-11-20 14:08:05 --> Helper loaded: form_helper
INFO - 2018-11-20 14:08:05 --> Form Validation Class Initialized
INFO - 2018-11-20 14:08:05 --> Model Class Initialized
INFO - 2018-11-20 14:08:05 --> Controller Class Initialized
INFO - 2018-11-20 14:08:05 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-20 14:08:05 --> Model Class Initialized
INFO - 2018-11-20 14:08:05 --> Model Class Initialized
INFO - 2018-11-20 14:08:05 --> Config Class Initialized
INFO - 2018-11-20 14:08:05 --> Hooks Class Initialized
DEBUG - 2018-11-20 14:08:05 --> UTF-8 Support Enabled
INFO - 2018-11-20 14:08:05 --> Utf8 Class Initialized
INFO - 2018-11-20 14:08:05 --> URI Class Initialized
INFO - 2018-11-20 14:08:05 --> Router Class Initialized
INFO - 2018-11-20 14:08:05 --> Output Class Initialized
INFO - 2018-11-20 14:08:05 --> Security Class Initialized
DEBUG - 2018-11-20 14:08:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-20 14:08:05 --> Input Class Initialized
INFO - 2018-11-20 14:08:05 --> Language Class Initialized
INFO - 2018-11-20 14:08:05 --> Loader Class Initialized
INFO - 2018-11-20 14:08:05 --> Helper loaded: url_helper
INFO - 2018-11-20 14:08:05 --> Helper loaded: file_helper
INFO - 2018-11-20 14:08:05 --> Helper loaded: email_helper
INFO - 2018-11-20 14:08:05 --> Helper loaded: common_helper
INFO - 2018-11-20 14:08:05 --> Database Driver Class Initialized
DEBUG - 2018-11-20 14:08:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-20 14:08:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-20 14:08:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-20 14:08:05 --> Pagination Class Initialized
INFO - 2018-11-20 14:08:05 --> Helper loaded: form_helper
INFO - 2018-11-20 14:08:05 --> Form Validation Class Initialized
INFO - 2018-11-20 14:08:05 --> Model Class Initialized
INFO - 2018-11-20 14:08:05 --> Controller Class Initialized
INFO - 2018-11-20 14:08:05 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-20 14:08:05 --> Model Class Initialized
INFO - 2018-11-20 14:08:05 --> Model Class Initialized
INFO - 2018-11-20 14:08:05 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/index.php
INFO - 2018-11-20 14:08:05 --> Final output sent to browser
DEBUG - 2018-11-20 14:08:05 --> Total execution time: 0.0460
INFO - 2018-11-20 14:08:18 --> Config Class Initialized
INFO - 2018-11-20 14:08:18 --> Hooks Class Initialized
DEBUG - 2018-11-20 14:08:18 --> UTF-8 Support Enabled
INFO - 2018-11-20 14:08:18 --> Utf8 Class Initialized
INFO - 2018-11-20 14:08:18 --> URI Class Initialized
INFO - 2018-11-20 14:08:18 --> Router Class Initialized
INFO - 2018-11-20 14:08:18 --> Output Class Initialized
INFO - 2018-11-20 14:08:18 --> Security Class Initialized
DEBUG - 2018-11-20 14:08:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-20 14:08:18 --> Input Class Initialized
INFO - 2018-11-20 14:08:18 --> Language Class Initialized
INFO - 2018-11-20 14:08:18 --> Loader Class Initialized
INFO - 2018-11-20 14:08:18 --> Helper loaded: url_helper
INFO - 2018-11-20 14:08:18 --> Helper loaded: file_helper
INFO - 2018-11-20 14:08:18 --> Helper loaded: email_helper
INFO - 2018-11-20 14:08:18 --> Helper loaded: common_helper
INFO - 2018-11-20 14:08:18 --> Database Driver Class Initialized
DEBUG - 2018-11-20 14:08:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-20 14:08:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-20 14:08:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-20 14:08:18 --> Pagination Class Initialized
INFO - 2018-11-20 14:08:18 --> Helper loaded: form_helper
INFO - 2018-11-20 14:08:18 --> Form Validation Class Initialized
INFO - 2018-11-20 14:08:18 --> Model Class Initialized
INFO - 2018-11-20 14:08:18 --> Controller Class Initialized
INFO - 2018-11-20 14:08:18 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-20 14:08:18 --> Model Class Initialized
INFO - 2018-11-20 14:08:18 --> Model Class Initialized
INFO - 2018-11-20 14:08:18 --> Config Class Initialized
INFO - 2018-11-20 14:08:18 --> Hooks Class Initialized
DEBUG - 2018-11-20 14:08:18 --> UTF-8 Support Enabled
INFO - 2018-11-20 14:08:18 --> Utf8 Class Initialized
INFO - 2018-11-20 14:08:18 --> URI Class Initialized
INFO - 2018-11-20 14:08:18 --> Router Class Initialized
INFO - 2018-11-20 14:08:18 --> Output Class Initialized
INFO - 2018-11-20 14:08:18 --> Security Class Initialized
DEBUG - 2018-11-20 14:08:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-20 14:08:18 --> Input Class Initialized
INFO - 2018-11-20 14:08:18 --> Language Class Initialized
INFO - 2018-11-20 14:08:18 --> Loader Class Initialized
INFO - 2018-11-20 14:08:18 --> Helper loaded: url_helper
INFO - 2018-11-20 14:08:18 --> Helper loaded: file_helper
INFO - 2018-11-20 14:08:18 --> Helper loaded: email_helper
INFO - 2018-11-20 14:08:18 --> Helper loaded: common_helper
INFO - 2018-11-20 14:08:18 --> Database Driver Class Initialized
DEBUG - 2018-11-20 14:08:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-20 14:08:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-20 14:08:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-20 14:08:18 --> Pagination Class Initialized
INFO - 2018-11-20 14:08:18 --> Helper loaded: form_helper
INFO - 2018-11-20 14:08:18 --> Form Validation Class Initialized
INFO - 2018-11-20 14:08:18 --> Model Class Initialized
INFO - 2018-11-20 14:08:18 --> Controller Class Initialized
INFO - 2018-11-20 14:08:18 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-20 14:08:18 --> Model Class Initialized
INFO - 2018-11-20 14:08:18 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-20 14:08:18 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/sidebar.php
INFO - 2018-11-20 14:08:18 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/right-sidebar.php
INFO - 2018-11-20 14:08:18 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/footer.php
INFO - 2018-11-20 14:08:18 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/dashboard.php
INFO - 2018-11-20 14:08:18 --> Final output sent to browser
DEBUG - 2018-11-20 14:08:18 --> Total execution time: 0.0600
INFO - 2018-11-20 14:08:24 --> Config Class Initialized
INFO - 2018-11-20 14:08:24 --> Hooks Class Initialized
DEBUG - 2018-11-20 14:08:24 --> UTF-8 Support Enabled
INFO - 2018-11-20 14:08:24 --> Utf8 Class Initialized
INFO - 2018-11-20 14:08:24 --> URI Class Initialized
INFO - 2018-11-20 14:08:24 --> Router Class Initialized
INFO - 2018-11-20 14:08:24 --> Output Class Initialized
INFO - 2018-11-20 14:08:24 --> Security Class Initialized
DEBUG - 2018-11-20 14:08:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-20 14:08:24 --> Input Class Initialized
INFO - 2018-11-20 14:08:24 --> Language Class Initialized
INFO - 2018-11-20 14:08:24 --> Loader Class Initialized
INFO - 2018-11-20 14:08:24 --> Helper loaded: url_helper
INFO - 2018-11-20 14:08:24 --> Helper loaded: file_helper
INFO - 2018-11-20 14:08:24 --> Helper loaded: email_helper
INFO - 2018-11-20 14:08:24 --> Helper loaded: common_helper
INFO - 2018-11-20 14:08:24 --> Database Driver Class Initialized
DEBUG - 2018-11-20 14:08:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-20 14:08:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-20 14:08:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-20 14:08:24 --> Pagination Class Initialized
INFO - 2018-11-20 14:08:24 --> Helper loaded: form_helper
INFO - 2018-11-20 14:08:24 --> Form Validation Class Initialized
INFO - 2018-11-20 14:08:24 --> Model Class Initialized
INFO - 2018-11-20 14:08:24 --> Controller Class Initialized
INFO - 2018-11-20 14:08:24 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-20 14:08:24 --> Model Class Initialized
INFO - 2018-11-20 14:08:24 --> Model Class Initialized
INFO - 2018-11-20 14:08:24 --> Config Class Initialized
INFO - 2018-11-20 14:08:24 --> Hooks Class Initialized
DEBUG - 2018-11-20 14:08:24 --> UTF-8 Support Enabled
INFO - 2018-11-20 14:08:24 --> Utf8 Class Initialized
INFO - 2018-11-20 14:08:24 --> URI Class Initialized
INFO - 2018-11-20 14:08:24 --> Router Class Initialized
INFO - 2018-11-20 14:08:24 --> Output Class Initialized
INFO - 2018-11-20 14:08:24 --> Security Class Initialized
DEBUG - 2018-11-20 14:08:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-20 14:08:24 --> Input Class Initialized
INFO - 2018-11-20 14:08:24 --> Language Class Initialized
INFO - 2018-11-20 14:08:24 --> Loader Class Initialized
INFO - 2018-11-20 14:08:24 --> Helper loaded: url_helper
INFO - 2018-11-20 14:08:24 --> Helper loaded: file_helper
INFO - 2018-11-20 14:08:24 --> Helper loaded: email_helper
INFO - 2018-11-20 14:08:24 --> Helper loaded: common_helper
INFO - 2018-11-20 14:08:24 --> Database Driver Class Initialized
DEBUG - 2018-11-20 14:08:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-20 14:08:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-20 14:08:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-20 14:08:24 --> Pagination Class Initialized
INFO - 2018-11-20 14:08:24 --> Helper loaded: form_helper
INFO - 2018-11-20 14:08:24 --> Form Validation Class Initialized
INFO - 2018-11-20 14:08:24 --> Model Class Initialized
INFO - 2018-11-20 14:08:24 --> Controller Class Initialized
INFO - 2018-11-20 14:08:24 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-20 14:08:24 --> Model Class Initialized
INFO - 2018-11-20 14:08:24 --> Model Class Initialized
INFO - 2018-11-20 14:08:24 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/index.php
INFO - 2018-11-20 14:08:24 --> Final output sent to browser
DEBUG - 2018-11-20 14:08:24 --> Total execution time: 0.0440
INFO - 2018-11-20 14:08:28 --> Config Class Initialized
INFO - 2018-11-20 14:08:28 --> Hooks Class Initialized
DEBUG - 2018-11-20 14:08:28 --> UTF-8 Support Enabled
INFO - 2018-11-20 14:08:28 --> Utf8 Class Initialized
INFO - 2018-11-20 14:08:28 --> URI Class Initialized
INFO - 2018-11-20 14:08:28 --> Router Class Initialized
INFO - 2018-11-20 14:08:28 --> Output Class Initialized
INFO - 2018-11-20 14:08:28 --> Security Class Initialized
DEBUG - 2018-11-20 14:08:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-20 14:08:28 --> Input Class Initialized
INFO - 2018-11-20 14:08:28 --> Language Class Initialized
INFO - 2018-11-20 14:08:28 --> Loader Class Initialized
INFO - 2018-11-20 14:08:28 --> Helper loaded: url_helper
INFO - 2018-11-20 14:08:28 --> Helper loaded: file_helper
INFO - 2018-11-20 14:08:28 --> Helper loaded: email_helper
INFO - 2018-11-20 14:08:28 --> Helper loaded: common_helper
INFO - 2018-11-20 14:08:28 --> Database Driver Class Initialized
DEBUG - 2018-11-20 14:08:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-20 14:08:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-20 14:08:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-20 14:08:28 --> Pagination Class Initialized
INFO - 2018-11-20 14:08:28 --> Helper loaded: form_helper
INFO - 2018-11-20 14:08:28 --> Form Validation Class Initialized
INFO - 2018-11-20 14:08:28 --> Model Class Initialized
INFO - 2018-11-20 14:08:28 --> Controller Class Initialized
INFO - 2018-11-20 14:08:28 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-20 14:08:28 --> Model Class Initialized
INFO - 2018-11-20 14:08:28 --> Model Class Initialized
ERROR - 2018-11-20 14:08:28 --> Severity: Notice --> Undefined index: remember_me C:\xampp\htdocs\wetinuneed\application\controllers\admin\Admin.php 76
INFO - 2018-11-20 14:08:28 --> Config Class Initialized
INFO - 2018-11-20 14:08:28 --> Hooks Class Initialized
DEBUG - 2018-11-20 14:08:28 --> UTF-8 Support Enabled
INFO - 2018-11-20 14:08:28 --> Utf8 Class Initialized
INFO - 2018-11-20 14:08:28 --> URI Class Initialized
INFO - 2018-11-20 14:08:28 --> Router Class Initialized
INFO - 2018-11-20 14:08:28 --> Output Class Initialized
INFO - 2018-11-20 14:08:28 --> Security Class Initialized
DEBUG - 2018-11-20 14:08:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-20 14:08:28 --> Input Class Initialized
INFO - 2018-11-20 14:08:28 --> Language Class Initialized
INFO - 2018-11-20 14:08:28 --> Loader Class Initialized
INFO - 2018-11-20 14:08:28 --> Helper loaded: url_helper
INFO - 2018-11-20 14:08:28 --> Helper loaded: file_helper
INFO - 2018-11-20 14:08:28 --> Helper loaded: email_helper
INFO - 2018-11-20 14:08:28 --> Helper loaded: common_helper
INFO - 2018-11-20 14:08:28 --> Database Driver Class Initialized
DEBUG - 2018-11-20 14:08:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-20 14:08:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-20 14:08:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-20 14:08:28 --> Pagination Class Initialized
INFO - 2018-11-20 14:08:28 --> Helper loaded: form_helper
INFO - 2018-11-20 14:08:28 --> Form Validation Class Initialized
INFO - 2018-11-20 14:08:28 --> Model Class Initialized
INFO - 2018-11-20 14:08:28 --> Controller Class Initialized
INFO - 2018-11-20 14:08:28 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-20 14:08:28 --> Model Class Initialized
INFO - 2018-11-20 14:08:28 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-20 14:08:28 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/sidebar.php
INFO - 2018-11-20 14:08:28 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/right-sidebar.php
INFO - 2018-11-20 14:08:28 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/footer.php
INFO - 2018-11-20 14:08:28 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/dashboard.php
INFO - 2018-11-20 14:08:28 --> Final output sent to browser
DEBUG - 2018-11-20 14:08:28 --> Total execution time: 0.0500
INFO - 2018-11-20 14:10:34 --> Config Class Initialized
INFO - 2018-11-20 14:10:34 --> Hooks Class Initialized
DEBUG - 2018-11-20 14:10:34 --> UTF-8 Support Enabled
INFO - 2018-11-20 14:10:34 --> Utf8 Class Initialized
INFO - 2018-11-20 14:10:34 --> URI Class Initialized
INFO - 2018-11-20 14:10:34 --> Router Class Initialized
INFO - 2018-11-20 14:10:34 --> Output Class Initialized
INFO - 2018-11-20 14:10:34 --> Security Class Initialized
DEBUG - 2018-11-20 14:10:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-20 14:10:34 --> Input Class Initialized
INFO - 2018-11-20 14:10:34 --> Language Class Initialized
INFO - 2018-11-20 14:10:34 --> Loader Class Initialized
INFO - 2018-11-20 14:10:34 --> Helper loaded: url_helper
INFO - 2018-11-20 14:10:34 --> Helper loaded: file_helper
INFO - 2018-11-20 14:10:34 --> Helper loaded: email_helper
INFO - 2018-11-20 14:10:34 --> Helper loaded: common_helper
INFO - 2018-11-20 14:10:34 --> Database Driver Class Initialized
DEBUG - 2018-11-20 14:10:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-20 14:10:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-20 14:10:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-20 14:10:34 --> Pagination Class Initialized
INFO - 2018-11-20 14:10:34 --> Helper loaded: form_helper
INFO - 2018-11-20 14:10:34 --> Form Validation Class Initialized
INFO - 2018-11-20 14:10:34 --> Model Class Initialized
INFO - 2018-11-20 14:10:34 --> Controller Class Initialized
INFO - 2018-11-20 14:10:34 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-20 14:10:34 --> Model Class Initialized
INFO - 2018-11-20 14:10:34 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-20 14:10:34 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/sidebar.php
INFO - 2018-11-20 14:10:34 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/right-sidebar.php
INFO - 2018-11-20 14:10:34 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/footer.php
INFO - 2018-11-20 14:10:34 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/dashboard.php
INFO - 2018-11-20 14:10:34 --> Final output sent to browser
DEBUG - 2018-11-20 14:10:34 --> Total execution time: 0.0480
INFO - 2018-11-20 14:10:45 --> Config Class Initialized
INFO - 2018-11-20 14:10:45 --> Hooks Class Initialized
DEBUG - 2018-11-20 14:10:45 --> UTF-8 Support Enabled
INFO - 2018-11-20 14:10:45 --> Utf8 Class Initialized
INFO - 2018-11-20 14:10:45 --> URI Class Initialized
INFO - 2018-11-20 14:10:45 --> Router Class Initialized
INFO - 2018-11-20 14:10:45 --> Output Class Initialized
INFO - 2018-11-20 14:10:45 --> Security Class Initialized
DEBUG - 2018-11-20 14:10:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-20 14:10:45 --> Input Class Initialized
INFO - 2018-11-20 14:10:45 --> Language Class Initialized
INFO - 2018-11-20 14:10:45 --> Loader Class Initialized
INFO - 2018-11-20 14:10:45 --> Helper loaded: url_helper
INFO - 2018-11-20 14:10:45 --> Helper loaded: file_helper
INFO - 2018-11-20 14:10:45 --> Helper loaded: email_helper
INFO - 2018-11-20 14:10:45 --> Helper loaded: common_helper
INFO - 2018-11-20 14:10:45 --> Database Driver Class Initialized
DEBUG - 2018-11-20 14:10:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-20 14:10:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-20 14:10:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-20 14:10:45 --> Pagination Class Initialized
INFO - 2018-11-20 14:10:45 --> Helper loaded: form_helper
INFO - 2018-11-20 14:10:45 --> Form Validation Class Initialized
INFO - 2018-11-20 14:10:45 --> Model Class Initialized
INFO - 2018-11-20 14:10:45 --> Controller Class Initialized
INFO - 2018-11-20 14:10:45 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-20 14:10:45 --> Model Class Initialized
INFO - 2018-11-20 14:10:45 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-20 14:10:45 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/sidebar.php
INFO - 2018-11-20 14:10:45 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/right-sidebar.php
INFO - 2018-11-20 14:10:45 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/footer.php
INFO - 2018-11-20 14:10:45 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/dashboard.php
INFO - 2018-11-20 14:10:45 --> Final output sent to browser
DEBUG - 2018-11-20 14:10:45 --> Total execution time: 0.0800
INFO - 2018-11-20 14:10:49 --> Config Class Initialized
INFO - 2018-11-20 14:10:49 --> Hooks Class Initialized
DEBUG - 2018-11-20 14:10:49 --> UTF-8 Support Enabled
INFO - 2018-11-20 14:10:49 --> Utf8 Class Initialized
INFO - 2018-11-20 14:10:49 --> URI Class Initialized
INFO - 2018-11-20 14:10:49 --> Router Class Initialized
INFO - 2018-11-20 14:10:49 --> Output Class Initialized
INFO - 2018-11-20 14:10:49 --> Security Class Initialized
DEBUG - 2018-11-20 14:10:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-20 14:10:49 --> Input Class Initialized
INFO - 2018-11-20 14:10:49 --> Language Class Initialized
ERROR - 2018-11-20 14:10:49 --> 404 Page Not Found: admin/Index2html/index
INFO - 2018-11-20 14:10:52 --> Config Class Initialized
INFO - 2018-11-20 14:10:52 --> Hooks Class Initialized
DEBUG - 2018-11-20 14:10:52 --> UTF-8 Support Enabled
INFO - 2018-11-20 14:10:52 --> Utf8 Class Initialized
INFO - 2018-11-20 14:10:52 --> URI Class Initialized
INFO - 2018-11-20 14:10:52 --> Router Class Initialized
INFO - 2018-11-20 14:10:52 --> Output Class Initialized
INFO - 2018-11-20 14:10:52 --> Security Class Initialized
DEBUG - 2018-11-20 14:10:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-20 14:10:52 --> Input Class Initialized
INFO - 2018-11-20 14:10:52 --> Language Class Initialized
INFO - 2018-11-20 14:10:52 --> Loader Class Initialized
INFO - 2018-11-20 14:10:52 --> Helper loaded: url_helper
INFO - 2018-11-20 14:10:52 --> Helper loaded: file_helper
INFO - 2018-11-20 14:10:52 --> Helper loaded: email_helper
INFO - 2018-11-20 14:10:52 --> Helper loaded: common_helper
INFO - 2018-11-20 14:10:52 --> Database Driver Class Initialized
DEBUG - 2018-11-20 14:10:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-20 14:10:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-20 14:10:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-20 14:10:52 --> Pagination Class Initialized
INFO - 2018-11-20 14:10:52 --> Helper loaded: form_helper
INFO - 2018-11-20 14:10:52 --> Form Validation Class Initialized
INFO - 2018-11-20 14:10:52 --> Model Class Initialized
INFO - 2018-11-20 14:10:52 --> Controller Class Initialized
INFO - 2018-11-20 14:10:52 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-20 14:10:52 --> Model Class Initialized
INFO - 2018-11-20 14:10:52 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-20 14:10:52 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/sidebar.php
INFO - 2018-11-20 14:10:52 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/right-sidebar.php
INFO - 2018-11-20 14:10:52 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/footer.php
INFO - 2018-11-20 14:10:52 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/dashboard.php
INFO - 2018-11-20 14:10:52 --> Final output sent to browser
DEBUG - 2018-11-20 14:10:52 --> Total execution time: 0.0550
INFO - 2018-11-20 14:17:23 --> Config Class Initialized
INFO - 2018-11-20 14:17:23 --> Hooks Class Initialized
DEBUG - 2018-11-20 14:17:23 --> UTF-8 Support Enabled
INFO - 2018-11-20 14:17:23 --> Utf8 Class Initialized
INFO - 2018-11-20 14:17:23 --> URI Class Initialized
INFO - 2018-11-20 14:17:23 --> Router Class Initialized
INFO - 2018-11-20 14:17:23 --> Output Class Initialized
INFO - 2018-11-20 14:17:23 --> Security Class Initialized
DEBUG - 2018-11-20 14:17:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-20 14:17:24 --> Input Class Initialized
INFO - 2018-11-20 14:17:24 --> Language Class Initialized
INFO - 2018-11-20 14:17:24 --> Loader Class Initialized
INFO - 2018-11-20 14:17:24 --> Helper loaded: url_helper
INFO - 2018-11-20 14:17:24 --> Helper loaded: file_helper
INFO - 2018-11-20 14:17:24 --> Helper loaded: email_helper
INFO - 2018-11-20 14:17:24 --> Helper loaded: common_helper
INFO - 2018-11-20 14:17:24 --> Database Driver Class Initialized
DEBUG - 2018-11-20 14:17:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-20 14:17:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-20 14:17:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-20 14:17:24 --> Pagination Class Initialized
INFO - 2018-11-20 14:17:24 --> Helper loaded: form_helper
INFO - 2018-11-20 14:17:24 --> Form Validation Class Initialized
INFO - 2018-11-20 14:17:24 --> Model Class Initialized
INFO - 2018-11-20 14:17:24 --> Controller Class Initialized
INFO - 2018-11-20 14:17:24 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-20 14:17:24 --> Model Class Initialized
INFO - 2018-11-20 14:17:24 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-20 14:17:24 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/sidebar.php
INFO - 2018-11-20 14:17:24 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/right-sidebar.php
INFO - 2018-11-20 14:17:24 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/footer.php
INFO - 2018-11-20 14:17:24 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/dashboard.php
INFO - 2018-11-20 14:17:24 --> Final output sent to browser
DEBUG - 2018-11-20 14:17:24 --> Total execution time: 0.0510
INFO - 2018-11-20 14:17:32 --> Config Class Initialized
INFO - 2018-11-20 14:17:32 --> Hooks Class Initialized
DEBUG - 2018-11-20 14:17:32 --> UTF-8 Support Enabled
INFO - 2018-11-20 14:17:32 --> Utf8 Class Initialized
INFO - 2018-11-20 14:17:32 --> URI Class Initialized
INFO - 2018-11-20 14:17:32 --> Router Class Initialized
INFO - 2018-11-20 14:17:32 --> Output Class Initialized
INFO - 2018-11-20 14:17:32 --> Security Class Initialized
DEBUG - 2018-11-20 14:17:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-20 14:17:32 --> Input Class Initialized
INFO - 2018-11-20 14:17:32 --> Language Class Initialized
ERROR - 2018-11-20 14:17:32 --> 404 Page Not Found: admin/Indexhtml/index
INFO - 2018-11-20 14:17:34 --> Config Class Initialized
INFO - 2018-11-20 14:17:34 --> Hooks Class Initialized
DEBUG - 2018-11-20 14:17:34 --> UTF-8 Support Enabled
INFO - 2018-11-20 14:17:34 --> Utf8 Class Initialized
INFO - 2018-11-20 14:17:34 --> URI Class Initialized
INFO - 2018-11-20 14:17:34 --> Router Class Initialized
INFO - 2018-11-20 14:17:34 --> Output Class Initialized
INFO - 2018-11-20 14:17:34 --> Security Class Initialized
DEBUG - 2018-11-20 14:17:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-20 14:17:34 --> Input Class Initialized
INFO - 2018-11-20 14:17:34 --> Language Class Initialized
INFO - 2018-11-20 14:17:34 --> Loader Class Initialized
INFO - 2018-11-20 14:17:34 --> Helper loaded: url_helper
INFO - 2018-11-20 14:17:34 --> Helper loaded: file_helper
INFO - 2018-11-20 14:17:34 --> Helper loaded: email_helper
INFO - 2018-11-20 14:17:34 --> Helper loaded: common_helper
INFO - 2018-11-20 14:17:34 --> Database Driver Class Initialized
DEBUG - 2018-11-20 14:17:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-20 14:17:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-20 14:17:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-20 14:17:34 --> Pagination Class Initialized
INFO - 2018-11-20 14:17:34 --> Helper loaded: form_helper
INFO - 2018-11-20 14:17:34 --> Form Validation Class Initialized
INFO - 2018-11-20 14:17:34 --> Model Class Initialized
INFO - 2018-11-20 14:17:34 --> Controller Class Initialized
INFO - 2018-11-20 14:17:34 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-20 14:17:34 --> Model Class Initialized
INFO - 2018-11-20 14:17:34 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-20 14:17:34 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/sidebar.php
INFO - 2018-11-20 14:17:34 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/right-sidebar.php
INFO - 2018-11-20 14:17:34 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/footer.php
INFO - 2018-11-20 14:17:34 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/dashboard.php
INFO - 2018-11-20 14:17:34 --> Final output sent to browser
DEBUG - 2018-11-20 14:17:34 --> Total execution time: 0.0590
INFO - 2018-11-20 14:24:23 --> Config Class Initialized
INFO - 2018-11-20 14:24:23 --> Hooks Class Initialized
DEBUG - 2018-11-20 14:24:23 --> UTF-8 Support Enabled
INFO - 2018-11-20 14:24:23 --> Utf8 Class Initialized
INFO - 2018-11-20 14:24:23 --> URI Class Initialized
INFO - 2018-11-20 14:24:23 --> Router Class Initialized
INFO - 2018-11-20 14:24:23 --> Output Class Initialized
INFO - 2018-11-20 14:24:23 --> Security Class Initialized
DEBUG - 2018-11-20 14:24:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-20 14:24:23 --> Input Class Initialized
INFO - 2018-11-20 14:24:23 --> Language Class Initialized
INFO - 2018-11-20 14:24:23 --> Loader Class Initialized
INFO - 2018-11-20 14:24:23 --> Helper loaded: url_helper
INFO - 2018-11-20 14:24:23 --> Helper loaded: file_helper
INFO - 2018-11-20 14:24:23 --> Helper loaded: email_helper
INFO - 2018-11-20 14:24:23 --> Helper loaded: common_helper
INFO - 2018-11-20 14:24:23 --> Database Driver Class Initialized
DEBUG - 2018-11-20 14:24:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-20 14:24:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-20 14:24:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-20 14:24:23 --> Pagination Class Initialized
INFO - 2018-11-20 14:24:23 --> Helper loaded: form_helper
INFO - 2018-11-20 14:24:23 --> Form Validation Class Initialized
INFO - 2018-11-20 14:24:23 --> Model Class Initialized
INFO - 2018-11-20 14:24:23 --> Controller Class Initialized
INFO - 2018-11-20 14:24:23 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-20 14:24:23 --> Model Class Initialized
INFO - 2018-11-20 14:24:23 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-20 14:24:23 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/sidebar.php
INFO - 2018-11-20 14:24:23 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/right-sidebar.php
INFO - 2018-11-20 14:24:23 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/footer.php
INFO - 2018-11-20 14:24:23 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/dashboard.php
INFO - 2018-11-20 14:24:23 --> Final output sent to browser
DEBUG - 2018-11-20 14:24:23 --> Total execution time: 0.0540
INFO - 2018-11-20 14:24:41 --> Config Class Initialized
INFO - 2018-11-20 14:24:41 --> Hooks Class Initialized
DEBUG - 2018-11-20 14:24:41 --> UTF-8 Support Enabled
INFO - 2018-11-20 14:24:41 --> Utf8 Class Initialized
INFO - 2018-11-20 14:24:41 --> URI Class Initialized
INFO - 2018-11-20 14:24:41 --> Router Class Initialized
INFO - 2018-11-20 14:24:41 --> Output Class Initialized
INFO - 2018-11-20 14:24:41 --> Security Class Initialized
DEBUG - 2018-11-20 14:24:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-20 14:24:41 --> Input Class Initialized
INFO - 2018-11-20 14:24:41 --> Language Class Initialized
INFO - 2018-11-20 14:24:41 --> Loader Class Initialized
INFO - 2018-11-20 14:24:41 --> Helper loaded: url_helper
INFO - 2018-11-20 14:24:41 --> Helper loaded: file_helper
INFO - 2018-11-20 14:24:41 --> Helper loaded: email_helper
INFO - 2018-11-20 14:24:41 --> Helper loaded: common_helper
INFO - 2018-11-20 14:24:41 --> Database Driver Class Initialized
DEBUG - 2018-11-20 14:24:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-20 14:24:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-20 14:24:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-20 14:24:42 --> Pagination Class Initialized
INFO - 2018-11-20 14:24:42 --> Helper loaded: form_helper
INFO - 2018-11-20 14:24:42 --> Form Validation Class Initialized
INFO - 2018-11-20 14:24:42 --> Model Class Initialized
INFO - 2018-11-20 14:24:42 --> Controller Class Initialized
INFO - 2018-11-20 14:24:42 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-20 14:24:42 --> Model Class Initialized
INFO - 2018-11-20 14:24:42 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-20 14:24:42 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/sidebar.php
INFO - 2018-11-20 14:24:42 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/right-sidebar.php
INFO - 2018-11-20 14:24:42 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/footer.php
INFO - 2018-11-20 14:24:42 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/dashboard.php
INFO - 2018-11-20 14:24:42 --> Final output sent to browser
DEBUG - 2018-11-20 14:24:42 --> Total execution time: 0.0520
INFO - 2018-11-20 14:24:45 --> Config Class Initialized
INFO - 2018-11-20 14:24:45 --> Hooks Class Initialized
DEBUG - 2018-11-20 14:24:45 --> UTF-8 Support Enabled
INFO - 2018-11-20 14:24:45 --> Utf8 Class Initialized
INFO - 2018-11-20 14:24:45 --> URI Class Initialized
INFO - 2018-11-20 14:24:45 --> Router Class Initialized
INFO - 2018-11-20 14:24:45 --> Output Class Initialized
INFO - 2018-11-20 14:24:45 --> Security Class Initialized
DEBUG - 2018-11-20 14:24:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-20 14:24:45 --> Input Class Initialized
INFO - 2018-11-20 14:24:45 --> Language Class Initialized
ERROR - 2018-11-20 14:24:45 --> 404 Page Not Found: admin/Indexhtml/index
INFO - 2018-11-20 14:24:47 --> Config Class Initialized
INFO - 2018-11-20 14:24:47 --> Hooks Class Initialized
DEBUG - 2018-11-20 14:24:47 --> UTF-8 Support Enabled
INFO - 2018-11-20 14:24:47 --> Utf8 Class Initialized
INFO - 2018-11-20 14:24:47 --> URI Class Initialized
INFO - 2018-11-20 14:24:47 --> Router Class Initialized
INFO - 2018-11-20 14:24:47 --> Output Class Initialized
INFO - 2018-11-20 14:24:47 --> Security Class Initialized
DEBUG - 2018-11-20 14:24:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-20 14:24:47 --> Input Class Initialized
INFO - 2018-11-20 14:24:47 --> Language Class Initialized
INFO - 2018-11-20 14:24:47 --> Loader Class Initialized
INFO - 2018-11-20 14:24:47 --> Helper loaded: url_helper
INFO - 2018-11-20 14:24:47 --> Helper loaded: file_helper
INFO - 2018-11-20 14:24:47 --> Helper loaded: email_helper
INFO - 2018-11-20 14:24:47 --> Helper loaded: common_helper
INFO - 2018-11-20 14:24:47 --> Database Driver Class Initialized
DEBUG - 2018-11-20 14:24:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-20 14:24:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-20 14:24:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-20 14:24:47 --> Pagination Class Initialized
INFO - 2018-11-20 14:24:47 --> Helper loaded: form_helper
INFO - 2018-11-20 14:24:47 --> Form Validation Class Initialized
INFO - 2018-11-20 14:24:47 --> Model Class Initialized
INFO - 2018-11-20 14:24:47 --> Controller Class Initialized
INFO - 2018-11-20 14:24:47 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-20 14:24:47 --> Model Class Initialized
INFO - 2018-11-20 14:24:47 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-20 14:24:47 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/sidebar.php
INFO - 2018-11-20 14:24:47 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/right-sidebar.php
INFO - 2018-11-20 14:24:47 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/footer.php
INFO - 2018-11-20 14:24:47 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/dashboard.php
INFO - 2018-11-20 14:24:47 --> Final output sent to browser
DEBUG - 2018-11-20 14:24:47 --> Total execution time: 0.0520
INFO - 2018-11-20 14:24:59 --> Config Class Initialized
INFO - 2018-11-20 14:24:59 --> Hooks Class Initialized
DEBUG - 2018-11-20 14:24:59 --> UTF-8 Support Enabled
INFO - 2018-11-20 14:24:59 --> Utf8 Class Initialized
INFO - 2018-11-20 14:24:59 --> URI Class Initialized
INFO - 2018-11-20 14:24:59 --> Router Class Initialized
INFO - 2018-11-20 14:24:59 --> Output Class Initialized
INFO - 2018-11-20 14:24:59 --> Security Class Initialized
DEBUG - 2018-11-20 14:24:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-20 14:24:59 --> Input Class Initialized
INFO - 2018-11-20 14:24:59 --> Language Class Initialized
INFO - 2018-11-20 14:24:59 --> Loader Class Initialized
INFO - 2018-11-20 14:24:59 --> Helper loaded: url_helper
INFO - 2018-11-20 14:24:59 --> Helper loaded: file_helper
INFO - 2018-11-20 14:24:59 --> Helper loaded: email_helper
INFO - 2018-11-20 14:24:59 --> Helper loaded: common_helper
INFO - 2018-11-20 14:24:59 --> Database Driver Class Initialized
DEBUG - 2018-11-20 14:24:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-20 14:24:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-20 14:24:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-20 14:24:59 --> Pagination Class Initialized
INFO - 2018-11-20 14:24:59 --> Helper loaded: form_helper
INFO - 2018-11-20 14:24:59 --> Form Validation Class Initialized
INFO - 2018-11-20 14:24:59 --> Model Class Initialized
INFO - 2018-11-20 14:24:59 --> Controller Class Initialized
INFO - 2018-11-20 14:24:59 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-20 14:24:59 --> Model Class Initialized
INFO - 2018-11-20 14:24:59 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-20 14:24:59 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/sidebar.php
INFO - 2018-11-20 14:24:59 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/right-sidebar.php
INFO - 2018-11-20 14:24:59 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/footer.php
INFO - 2018-11-20 14:24:59 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/dashboard.php
INFO - 2018-11-20 14:24:59 --> Final output sent to browser
DEBUG - 2018-11-20 14:24:59 --> Total execution time: 0.0530
INFO - 2018-11-20 14:26:56 --> Config Class Initialized
INFO - 2018-11-20 14:26:56 --> Hooks Class Initialized
DEBUG - 2018-11-20 14:26:56 --> UTF-8 Support Enabled
INFO - 2018-11-20 14:26:56 --> Utf8 Class Initialized
INFO - 2018-11-20 14:26:56 --> URI Class Initialized
INFO - 2018-11-20 14:26:56 --> Router Class Initialized
INFO - 2018-11-20 14:26:56 --> Output Class Initialized
INFO - 2018-11-20 14:26:56 --> Security Class Initialized
DEBUG - 2018-11-20 14:26:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-20 14:26:56 --> Input Class Initialized
INFO - 2018-11-20 14:26:56 --> Language Class Initialized
INFO - 2018-11-20 14:26:56 --> Loader Class Initialized
INFO - 2018-11-20 14:26:56 --> Helper loaded: url_helper
INFO - 2018-11-20 14:26:56 --> Helper loaded: file_helper
INFO - 2018-11-20 14:26:56 --> Helper loaded: email_helper
INFO - 2018-11-20 14:26:56 --> Helper loaded: common_helper
INFO - 2018-11-20 14:26:56 --> Database Driver Class Initialized
DEBUG - 2018-11-20 14:26:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-20 14:26:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-20 14:26:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-20 14:26:56 --> Pagination Class Initialized
INFO - 2018-11-20 14:26:56 --> Helper loaded: form_helper
INFO - 2018-11-20 14:26:56 --> Form Validation Class Initialized
INFO - 2018-11-20 14:26:56 --> Model Class Initialized
INFO - 2018-11-20 14:26:56 --> Controller Class Initialized
INFO - 2018-11-20 14:26:56 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-20 14:26:56 --> Model Class Initialized
INFO - 2018-11-20 14:26:56 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-20 14:26:56 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/sidebar.php
INFO - 2018-11-20 14:26:56 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/right-sidebar.php
INFO - 2018-11-20 14:26:56 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/footer.php
INFO - 2018-11-20 14:26:56 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/dashboard.php
INFO - 2018-11-20 14:26:56 --> Final output sent to browser
DEBUG - 2018-11-20 14:26:56 --> Total execution time: 0.0610
INFO - 2018-11-20 14:27:25 --> Config Class Initialized
INFO - 2018-11-20 14:27:25 --> Hooks Class Initialized
DEBUG - 2018-11-20 14:27:25 --> UTF-8 Support Enabled
INFO - 2018-11-20 14:27:25 --> Utf8 Class Initialized
INFO - 2018-11-20 14:27:25 --> URI Class Initialized
INFO - 2018-11-20 14:27:25 --> Router Class Initialized
INFO - 2018-11-20 14:27:25 --> Output Class Initialized
INFO - 2018-11-20 14:27:25 --> Security Class Initialized
DEBUG - 2018-11-20 14:27:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-20 14:27:25 --> Input Class Initialized
INFO - 2018-11-20 14:27:25 --> Language Class Initialized
INFO - 2018-11-20 14:27:25 --> Loader Class Initialized
INFO - 2018-11-20 14:27:25 --> Helper loaded: url_helper
INFO - 2018-11-20 14:27:25 --> Helper loaded: file_helper
INFO - 2018-11-20 14:27:25 --> Helper loaded: email_helper
INFO - 2018-11-20 14:27:25 --> Helper loaded: common_helper
INFO - 2018-11-20 14:27:25 --> Database Driver Class Initialized
DEBUG - 2018-11-20 14:27:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-20 14:27:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-20 14:27:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-20 14:27:25 --> Pagination Class Initialized
INFO - 2018-11-20 14:27:25 --> Helper loaded: form_helper
INFO - 2018-11-20 14:27:25 --> Form Validation Class Initialized
INFO - 2018-11-20 14:27:25 --> Model Class Initialized
INFO - 2018-11-20 14:27:25 --> Controller Class Initialized
INFO - 2018-11-20 14:27:25 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-20 14:27:25 --> Model Class Initialized
INFO - 2018-11-20 14:27:25 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-20 14:27:25 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/sidebar.php
INFO - 2018-11-20 14:27:25 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/right-sidebar.php
INFO - 2018-11-20 14:27:25 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/footer.php
INFO - 2018-11-20 14:27:25 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/dashboard.php
INFO - 2018-11-20 14:27:25 --> Final output sent to browser
DEBUG - 2018-11-20 14:27:25 --> Total execution time: 0.0490
INFO - 2018-11-20 14:27:41 --> Config Class Initialized
INFO - 2018-11-20 14:27:41 --> Hooks Class Initialized
DEBUG - 2018-11-20 14:27:41 --> UTF-8 Support Enabled
INFO - 2018-11-20 14:27:41 --> Utf8 Class Initialized
INFO - 2018-11-20 14:27:41 --> URI Class Initialized
INFO - 2018-11-20 14:27:41 --> Router Class Initialized
INFO - 2018-11-20 14:27:41 --> Output Class Initialized
INFO - 2018-11-20 14:27:41 --> Security Class Initialized
DEBUG - 2018-11-20 14:27:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-20 14:27:41 --> Input Class Initialized
INFO - 2018-11-20 14:27:41 --> Language Class Initialized
INFO - 2018-11-20 14:27:41 --> Loader Class Initialized
INFO - 2018-11-20 14:27:41 --> Helper loaded: url_helper
INFO - 2018-11-20 14:27:41 --> Helper loaded: file_helper
INFO - 2018-11-20 14:27:41 --> Helper loaded: email_helper
INFO - 2018-11-20 14:27:41 --> Helper loaded: common_helper
INFO - 2018-11-20 14:27:41 --> Database Driver Class Initialized
DEBUG - 2018-11-20 14:27:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-20 14:27:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-20 14:27:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-20 14:27:41 --> Pagination Class Initialized
INFO - 2018-11-20 14:27:41 --> Helper loaded: form_helper
INFO - 2018-11-20 14:27:41 --> Form Validation Class Initialized
INFO - 2018-11-20 14:27:41 --> Model Class Initialized
INFO - 2018-11-20 14:27:41 --> Controller Class Initialized
INFO - 2018-11-20 14:27:41 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-20 14:27:41 --> Model Class Initialized
INFO - 2018-11-20 14:27:41 --> Model Class Initialized
INFO - 2018-11-20 14:27:41 --> Config Class Initialized
INFO - 2018-11-20 14:27:41 --> Hooks Class Initialized
DEBUG - 2018-11-20 14:27:41 --> UTF-8 Support Enabled
INFO - 2018-11-20 14:27:41 --> Utf8 Class Initialized
INFO - 2018-11-20 14:27:41 --> URI Class Initialized
INFO - 2018-11-20 14:27:41 --> Router Class Initialized
INFO - 2018-11-20 14:27:41 --> Output Class Initialized
INFO - 2018-11-20 14:27:41 --> Security Class Initialized
DEBUG - 2018-11-20 14:27:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-20 14:27:41 --> Input Class Initialized
INFO - 2018-11-20 14:27:41 --> Language Class Initialized
INFO - 2018-11-20 14:27:41 --> Loader Class Initialized
INFO - 2018-11-20 14:27:41 --> Helper loaded: url_helper
INFO - 2018-11-20 14:27:41 --> Helper loaded: file_helper
INFO - 2018-11-20 14:27:41 --> Helper loaded: email_helper
INFO - 2018-11-20 14:27:41 --> Helper loaded: common_helper
INFO - 2018-11-20 14:27:41 --> Database Driver Class Initialized
DEBUG - 2018-11-20 14:27:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-20 14:27:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-20 14:27:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-20 14:27:41 --> Pagination Class Initialized
INFO - 2018-11-20 14:27:41 --> Helper loaded: form_helper
INFO - 2018-11-20 14:27:41 --> Form Validation Class Initialized
INFO - 2018-11-20 14:27:41 --> Model Class Initialized
INFO - 2018-11-20 14:27:41 --> Controller Class Initialized
INFO - 2018-11-20 14:27:41 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-20 14:27:41 --> Model Class Initialized
INFO - 2018-11-20 14:27:41 --> Model Class Initialized
INFO - 2018-11-20 14:27:41 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/index.php
INFO - 2018-11-20 14:27:41 --> Final output sent to browser
DEBUG - 2018-11-20 14:27:41 --> Total execution time: 0.0420
INFO - 2018-11-20 14:28:19 --> Config Class Initialized
INFO - 2018-11-20 14:28:19 --> Hooks Class Initialized
DEBUG - 2018-11-20 14:28:19 --> UTF-8 Support Enabled
INFO - 2018-11-20 14:28:19 --> Utf8 Class Initialized
INFO - 2018-11-20 14:28:19 --> URI Class Initialized
INFO - 2018-11-20 14:28:19 --> Router Class Initialized
INFO - 2018-11-20 14:28:19 --> Output Class Initialized
INFO - 2018-11-20 14:28:19 --> Security Class Initialized
DEBUG - 2018-11-20 14:28:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-20 14:28:19 --> Input Class Initialized
INFO - 2018-11-20 14:28:19 --> Language Class Initialized
INFO - 2018-11-20 14:28:19 --> Loader Class Initialized
INFO - 2018-11-20 14:28:19 --> Helper loaded: url_helper
INFO - 2018-11-20 14:28:19 --> Helper loaded: file_helper
INFO - 2018-11-20 14:28:19 --> Helper loaded: email_helper
INFO - 2018-11-20 14:28:19 --> Helper loaded: common_helper
INFO - 2018-11-20 14:28:19 --> Database Driver Class Initialized
DEBUG - 2018-11-20 14:28:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-20 14:28:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-20 14:28:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-20 14:28:19 --> Pagination Class Initialized
INFO - 2018-11-20 14:28:19 --> Helper loaded: form_helper
INFO - 2018-11-20 14:28:19 --> Form Validation Class Initialized
INFO - 2018-11-20 14:28:19 --> Model Class Initialized
INFO - 2018-11-20 14:28:19 --> Controller Class Initialized
INFO - 2018-11-20 14:28:19 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-20 14:28:19 --> Model Class Initialized
INFO - 2018-11-20 14:28:19 --> Model Class Initialized
INFO - 2018-11-20 14:28:19 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/index.php
INFO - 2018-11-20 14:28:19 --> Final output sent to browser
DEBUG - 2018-11-20 14:28:19 --> Total execution time: 0.0640
INFO - 2018-11-20 14:29:06 --> Config Class Initialized
INFO - 2018-11-20 14:29:06 --> Hooks Class Initialized
DEBUG - 2018-11-20 14:29:06 --> UTF-8 Support Enabled
INFO - 2018-11-20 14:29:06 --> Utf8 Class Initialized
INFO - 2018-11-20 14:29:06 --> URI Class Initialized
INFO - 2018-11-20 14:29:06 --> Router Class Initialized
INFO - 2018-11-20 14:29:06 --> Output Class Initialized
INFO - 2018-11-20 14:29:06 --> Security Class Initialized
DEBUG - 2018-11-20 14:29:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-20 14:29:06 --> Input Class Initialized
INFO - 2018-11-20 14:29:06 --> Language Class Initialized
INFO - 2018-11-20 14:29:06 --> Loader Class Initialized
INFO - 2018-11-20 14:29:06 --> Helper loaded: url_helper
INFO - 2018-11-20 14:29:06 --> Helper loaded: file_helper
INFO - 2018-11-20 14:29:06 --> Helper loaded: email_helper
INFO - 2018-11-20 14:29:06 --> Helper loaded: common_helper
INFO - 2018-11-20 14:29:06 --> Database Driver Class Initialized
DEBUG - 2018-11-20 14:29:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-20 14:29:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-20 14:29:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-20 14:29:06 --> Pagination Class Initialized
INFO - 2018-11-20 14:29:06 --> Helper loaded: form_helper
INFO - 2018-11-20 14:29:06 --> Form Validation Class Initialized
INFO - 2018-11-20 14:29:06 --> Model Class Initialized
INFO - 2018-11-20 14:29:06 --> Controller Class Initialized
INFO - 2018-11-20 14:29:06 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-20 14:29:06 --> Model Class Initialized
INFO - 2018-11-20 14:29:06 --> Model Class Initialized
INFO - 2018-11-20 14:29:06 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/index.php
INFO - 2018-11-20 14:29:06 --> Final output sent to browser
DEBUG - 2018-11-20 14:29:06 --> Total execution time: 0.0530
INFO - 2018-11-20 14:29:12 --> Config Class Initialized
INFO - 2018-11-20 14:29:12 --> Hooks Class Initialized
DEBUG - 2018-11-20 14:29:12 --> UTF-8 Support Enabled
INFO - 2018-11-20 14:29:12 --> Utf8 Class Initialized
INFO - 2018-11-20 14:29:12 --> URI Class Initialized
INFO - 2018-11-20 14:29:12 --> Router Class Initialized
INFO - 2018-11-20 14:29:12 --> Output Class Initialized
INFO - 2018-11-20 14:29:12 --> Security Class Initialized
DEBUG - 2018-11-20 14:29:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-20 14:29:12 --> Input Class Initialized
INFO - 2018-11-20 14:29:12 --> Language Class Initialized
INFO - 2018-11-20 14:29:12 --> Loader Class Initialized
INFO - 2018-11-20 14:29:12 --> Helper loaded: url_helper
INFO - 2018-11-20 14:29:12 --> Helper loaded: file_helper
INFO - 2018-11-20 14:29:12 --> Helper loaded: email_helper
INFO - 2018-11-20 14:29:12 --> Helper loaded: common_helper
INFO - 2018-11-20 14:29:12 --> Database Driver Class Initialized
DEBUG - 2018-11-20 14:29:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-20 14:29:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-20 14:29:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-20 14:29:12 --> Pagination Class Initialized
INFO - 2018-11-20 14:29:12 --> Helper loaded: form_helper
INFO - 2018-11-20 14:29:12 --> Form Validation Class Initialized
INFO - 2018-11-20 14:29:12 --> Model Class Initialized
INFO - 2018-11-20 14:29:12 --> Controller Class Initialized
INFO - 2018-11-20 14:29:12 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-20 14:29:12 --> Model Class Initialized
INFO - 2018-11-20 14:29:12 --> Model Class Initialized
ERROR - 2018-11-20 14:29:12 --> Severity: Notice --> Undefined index: remember_me C:\xampp\htdocs\wetinuneed\application\controllers\admin\Admin.php 76
INFO - 2018-11-20 14:29:12 --> Config Class Initialized
INFO - 2018-11-20 14:29:12 --> Hooks Class Initialized
DEBUG - 2018-11-20 14:29:12 --> UTF-8 Support Enabled
INFO - 2018-11-20 14:29:12 --> Utf8 Class Initialized
INFO - 2018-11-20 14:29:12 --> URI Class Initialized
INFO - 2018-11-20 14:29:12 --> Router Class Initialized
INFO - 2018-11-20 14:29:12 --> Output Class Initialized
INFO - 2018-11-20 14:29:12 --> Security Class Initialized
DEBUG - 2018-11-20 14:29:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-20 14:29:12 --> Input Class Initialized
INFO - 2018-11-20 14:29:12 --> Language Class Initialized
INFO - 2018-11-20 14:29:12 --> Loader Class Initialized
INFO - 2018-11-20 14:29:12 --> Helper loaded: url_helper
INFO - 2018-11-20 14:29:12 --> Helper loaded: file_helper
INFO - 2018-11-20 14:29:12 --> Helper loaded: email_helper
INFO - 2018-11-20 14:29:12 --> Helper loaded: common_helper
INFO - 2018-11-20 14:29:12 --> Database Driver Class Initialized
DEBUG - 2018-11-20 14:29:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-20 14:29:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-20 14:29:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-20 14:29:12 --> Pagination Class Initialized
INFO - 2018-11-20 14:29:12 --> Helper loaded: form_helper
INFO - 2018-11-20 14:29:12 --> Form Validation Class Initialized
INFO - 2018-11-20 14:29:12 --> Model Class Initialized
INFO - 2018-11-20 14:29:12 --> Controller Class Initialized
INFO - 2018-11-20 14:29:12 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-20 14:29:12 --> Model Class Initialized
INFO - 2018-11-20 14:29:12 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-20 14:29:12 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/sidebar.php
INFO - 2018-11-20 14:29:12 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/right-sidebar.php
INFO - 2018-11-20 14:29:12 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/footer.php
INFO - 2018-11-20 14:29:12 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/dashboard.php
INFO - 2018-11-20 14:29:12 --> Final output sent to browser
DEBUG - 2018-11-20 14:29:12 --> Total execution time: 0.0610
INFO - 2018-11-20 14:34:31 --> Config Class Initialized
INFO - 2018-11-20 14:34:31 --> Hooks Class Initialized
DEBUG - 2018-11-20 14:34:31 --> UTF-8 Support Enabled
INFO - 2018-11-20 14:34:31 --> Utf8 Class Initialized
INFO - 2018-11-20 14:34:31 --> URI Class Initialized
INFO - 2018-11-20 14:34:31 --> Router Class Initialized
INFO - 2018-11-20 14:34:31 --> Output Class Initialized
INFO - 2018-11-20 14:34:31 --> Security Class Initialized
DEBUG - 2018-11-20 14:34:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-20 14:34:31 --> Input Class Initialized
INFO - 2018-11-20 14:34:31 --> Language Class Initialized
ERROR - 2018-11-20 14:34:31 --> 404 Page Not Found: admin/Profilehtml/index
INFO - 2018-11-20 14:34:32 --> Config Class Initialized
INFO - 2018-11-20 14:34:32 --> Hooks Class Initialized
DEBUG - 2018-11-20 14:34:32 --> UTF-8 Support Enabled
INFO - 2018-11-20 14:34:32 --> Utf8 Class Initialized
INFO - 2018-11-20 14:34:32 --> URI Class Initialized
INFO - 2018-11-20 14:34:32 --> Router Class Initialized
INFO - 2018-11-20 14:34:32 --> Output Class Initialized
INFO - 2018-11-20 14:34:32 --> Security Class Initialized
DEBUG - 2018-11-20 14:34:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-20 14:34:32 --> Input Class Initialized
INFO - 2018-11-20 14:34:32 --> Language Class Initialized
INFO - 2018-11-20 14:34:32 --> Loader Class Initialized
INFO - 2018-11-20 14:34:32 --> Helper loaded: url_helper
INFO - 2018-11-20 14:34:32 --> Helper loaded: file_helper
INFO - 2018-11-20 14:34:32 --> Helper loaded: email_helper
INFO - 2018-11-20 14:34:32 --> Helper loaded: common_helper
INFO - 2018-11-20 14:34:32 --> Database Driver Class Initialized
DEBUG - 2018-11-20 14:34:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-20 14:34:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-20 14:34:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-20 14:34:32 --> Pagination Class Initialized
INFO - 2018-11-20 14:34:32 --> Helper loaded: form_helper
INFO - 2018-11-20 14:34:32 --> Form Validation Class Initialized
INFO - 2018-11-20 14:34:32 --> Model Class Initialized
INFO - 2018-11-20 14:34:32 --> Controller Class Initialized
INFO - 2018-11-20 14:34:32 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-20 14:34:32 --> Model Class Initialized
INFO - 2018-11-20 14:34:32 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-20 14:34:32 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/sidebar.php
INFO - 2018-11-20 14:34:32 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/right-sidebar.php
INFO - 2018-11-20 14:34:32 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/footer.php
INFO - 2018-11-20 14:34:32 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/dashboard.php
INFO - 2018-11-20 14:34:32 --> Final output sent to browser
DEBUG - 2018-11-20 14:34:32 --> Total execution time: 0.0520
INFO - 2018-11-20 14:37:35 --> Config Class Initialized
INFO - 2018-11-20 14:37:35 --> Hooks Class Initialized
DEBUG - 2018-11-20 14:37:35 --> UTF-8 Support Enabled
INFO - 2018-11-20 14:37:35 --> Utf8 Class Initialized
INFO - 2018-11-20 14:37:35 --> URI Class Initialized
INFO - 2018-11-20 14:37:35 --> Router Class Initialized
INFO - 2018-11-20 14:37:35 --> Output Class Initialized
INFO - 2018-11-20 14:37:35 --> Security Class Initialized
DEBUG - 2018-11-20 14:37:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-20 14:37:35 --> Input Class Initialized
INFO - 2018-11-20 14:37:35 --> Language Class Initialized
INFO - 2018-11-20 14:37:36 --> Loader Class Initialized
INFO - 2018-11-20 14:37:36 --> Helper loaded: url_helper
INFO - 2018-11-20 14:37:36 --> Helper loaded: file_helper
INFO - 2018-11-20 14:37:36 --> Helper loaded: email_helper
INFO - 2018-11-20 14:37:36 --> Helper loaded: common_helper
INFO - 2018-11-20 14:37:36 --> Database Driver Class Initialized
DEBUG - 2018-11-20 14:37:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-20 14:37:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-20 14:37:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-20 14:37:36 --> Pagination Class Initialized
INFO - 2018-11-20 14:37:36 --> Helper loaded: form_helper
INFO - 2018-11-20 14:37:36 --> Form Validation Class Initialized
INFO - 2018-11-20 14:37:36 --> Model Class Initialized
INFO - 2018-11-20 14:37:36 --> Controller Class Initialized
INFO - 2018-11-20 14:37:36 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-20 14:37:36 --> Model Class Initialized
INFO - 2018-11-20 14:37:36 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-20 14:37:36 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/sidebar.php
INFO - 2018-11-20 14:37:36 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/right-sidebar.php
INFO - 2018-11-20 14:37:36 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/footer.php
INFO - 2018-11-20 14:37:36 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/dashboard.php
INFO - 2018-11-20 14:37:36 --> Final output sent to browser
DEBUG - 2018-11-20 14:37:36 --> Total execution time: 0.0570
INFO - 2018-11-20 14:37:50 --> Config Class Initialized
INFO - 2018-11-20 14:37:50 --> Hooks Class Initialized
DEBUG - 2018-11-20 14:37:50 --> UTF-8 Support Enabled
INFO - 2018-11-20 14:37:50 --> Utf8 Class Initialized
INFO - 2018-11-20 14:37:50 --> URI Class Initialized
INFO - 2018-11-20 14:37:50 --> Router Class Initialized
INFO - 2018-11-20 14:37:50 --> Output Class Initialized
INFO - 2018-11-20 14:37:50 --> Security Class Initialized
DEBUG - 2018-11-20 14:37:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-20 14:37:50 --> Input Class Initialized
INFO - 2018-11-20 14:37:50 --> Language Class Initialized
INFO - 2018-11-20 14:37:50 --> Loader Class Initialized
INFO - 2018-11-20 14:37:50 --> Helper loaded: url_helper
INFO - 2018-11-20 14:37:50 --> Helper loaded: file_helper
INFO - 2018-11-20 14:37:50 --> Helper loaded: email_helper
INFO - 2018-11-20 14:37:50 --> Helper loaded: common_helper
INFO - 2018-11-20 14:37:50 --> Database Driver Class Initialized
DEBUG - 2018-11-20 14:37:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-20 14:37:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-20 14:37:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-20 14:37:50 --> Pagination Class Initialized
INFO - 2018-11-20 14:37:50 --> Helper loaded: form_helper
INFO - 2018-11-20 14:37:50 --> Form Validation Class Initialized
INFO - 2018-11-20 14:37:50 --> Model Class Initialized
INFO - 2018-11-20 14:37:50 --> Controller Class Initialized
INFO - 2018-11-20 14:37:50 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-20 14:37:50 --> Model Class Initialized
INFO - 2018-11-20 14:37:50 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-20 14:37:50 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/sidebar.php
INFO - 2018-11-20 14:37:50 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/right-sidebar.php
INFO - 2018-11-20 14:37:50 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/footer.php
INFO - 2018-11-20 14:37:50 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/dashboard.php
INFO - 2018-11-20 14:37:50 --> Final output sent to browser
DEBUG - 2018-11-20 14:37:50 --> Total execution time: 0.0580
INFO - 2018-11-20 14:38:24 --> Config Class Initialized
INFO - 2018-11-20 14:38:24 --> Hooks Class Initialized
DEBUG - 2018-11-20 14:38:24 --> UTF-8 Support Enabled
INFO - 2018-11-20 14:38:24 --> Utf8 Class Initialized
INFO - 2018-11-20 14:38:24 --> URI Class Initialized
INFO - 2018-11-20 14:38:24 --> Router Class Initialized
INFO - 2018-11-20 14:38:24 --> Output Class Initialized
INFO - 2018-11-20 14:38:24 --> Security Class Initialized
DEBUG - 2018-11-20 14:38:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-20 14:38:24 --> Input Class Initialized
INFO - 2018-11-20 14:38:24 --> Language Class Initialized
INFO - 2018-11-20 14:38:24 --> Loader Class Initialized
INFO - 2018-11-20 14:38:24 --> Helper loaded: url_helper
INFO - 2018-11-20 14:38:24 --> Helper loaded: file_helper
INFO - 2018-11-20 14:38:24 --> Helper loaded: email_helper
INFO - 2018-11-20 14:38:24 --> Helper loaded: common_helper
INFO - 2018-11-20 14:38:24 --> Database Driver Class Initialized
DEBUG - 2018-11-20 14:38:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-20 14:38:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-20 14:38:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-20 14:38:24 --> Pagination Class Initialized
INFO - 2018-11-20 14:38:24 --> Helper loaded: form_helper
INFO - 2018-11-20 14:38:24 --> Form Validation Class Initialized
INFO - 2018-11-20 14:38:24 --> Model Class Initialized
INFO - 2018-11-20 14:38:24 --> Controller Class Initialized
INFO - 2018-11-20 14:38:24 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-20 14:38:24 --> Model Class Initialized
INFO - 2018-11-20 14:38:24 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-20 14:38:24 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/sidebar.php
INFO - 2018-11-20 14:38:24 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/right-sidebar.php
INFO - 2018-11-20 14:38:24 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/footer.php
INFO - 2018-11-20 14:38:24 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/dashboard.php
INFO - 2018-11-20 14:38:24 --> Final output sent to browser
DEBUG - 2018-11-20 14:38:24 --> Total execution time: 0.0570
INFO - 2018-11-20 14:39:22 --> Config Class Initialized
INFO - 2018-11-20 14:39:22 --> Hooks Class Initialized
DEBUG - 2018-11-20 14:39:22 --> UTF-8 Support Enabled
INFO - 2018-11-20 14:39:22 --> Utf8 Class Initialized
INFO - 2018-11-20 14:39:22 --> URI Class Initialized
INFO - 2018-11-20 14:39:22 --> Router Class Initialized
INFO - 2018-11-20 14:39:22 --> Output Class Initialized
INFO - 2018-11-20 14:39:22 --> Security Class Initialized
DEBUG - 2018-11-20 14:39:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-20 14:39:22 --> Input Class Initialized
INFO - 2018-11-20 14:39:22 --> Language Class Initialized
INFO - 2018-11-20 14:39:22 --> Loader Class Initialized
INFO - 2018-11-20 14:39:22 --> Helper loaded: url_helper
INFO - 2018-11-20 14:39:22 --> Helper loaded: file_helper
INFO - 2018-11-20 14:39:22 --> Helper loaded: email_helper
INFO - 2018-11-20 14:39:22 --> Helper loaded: common_helper
INFO - 2018-11-20 14:39:22 --> Database Driver Class Initialized
DEBUG - 2018-11-20 14:39:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-20 14:39:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-20 14:39:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-20 14:39:22 --> Pagination Class Initialized
INFO - 2018-11-20 14:39:22 --> Helper loaded: form_helper
INFO - 2018-11-20 14:39:22 --> Form Validation Class Initialized
INFO - 2018-11-20 14:39:22 --> Model Class Initialized
INFO - 2018-11-20 14:39:22 --> Controller Class Initialized
INFO - 2018-11-20 14:39:22 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-20 14:39:22 --> Model Class Initialized
INFO - 2018-11-20 14:39:22 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-20 14:39:22 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/sidebar.php
INFO - 2018-11-20 14:39:22 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/right-sidebar.php
INFO - 2018-11-20 14:39:22 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/footer.php
INFO - 2018-11-20 14:39:22 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/dashboard.php
INFO - 2018-11-20 14:39:22 --> Final output sent to browser
DEBUG - 2018-11-20 14:39:22 --> Total execution time: 0.0630
INFO - 2018-11-20 14:39:24 --> Config Class Initialized
INFO - 2018-11-20 14:39:24 --> Hooks Class Initialized
DEBUG - 2018-11-20 14:39:24 --> UTF-8 Support Enabled
INFO - 2018-11-20 14:39:24 --> Utf8 Class Initialized
INFO - 2018-11-20 14:39:24 --> URI Class Initialized
INFO - 2018-11-20 14:39:24 --> Router Class Initialized
INFO - 2018-11-20 14:39:24 --> Output Class Initialized
INFO - 2018-11-20 14:39:24 --> Security Class Initialized
DEBUG - 2018-11-20 14:39:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-20 14:39:24 --> Input Class Initialized
INFO - 2018-11-20 14:39:24 --> Language Class Initialized
INFO - 2018-11-20 14:39:24 --> Loader Class Initialized
INFO - 2018-11-20 14:39:24 --> Helper loaded: url_helper
INFO - 2018-11-20 14:39:24 --> Helper loaded: file_helper
INFO - 2018-11-20 14:39:24 --> Helper loaded: email_helper
INFO - 2018-11-20 14:39:24 --> Helper loaded: common_helper
INFO - 2018-11-20 14:39:24 --> Database Driver Class Initialized
DEBUG - 2018-11-20 14:39:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-20 14:39:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-20 14:39:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-20 14:39:24 --> Pagination Class Initialized
INFO - 2018-11-20 14:39:24 --> Helper loaded: form_helper
INFO - 2018-11-20 14:39:24 --> Form Validation Class Initialized
INFO - 2018-11-20 14:39:24 --> Model Class Initialized
INFO - 2018-11-20 14:39:24 --> Controller Class Initialized
INFO - 2018-11-20 14:39:24 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-20 14:39:24 --> Model Class Initialized
INFO - 2018-11-20 14:39:24 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-20 14:39:24 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/sidebar.php
INFO - 2018-11-20 14:39:24 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/right-sidebar.php
INFO - 2018-11-20 14:39:24 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/footer.php
INFO - 2018-11-20 14:39:24 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/dashboard.php
INFO - 2018-11-20 14:39:24 --> Final output sent to browser
DEBUG - 2018-11-20 14:39:24 --> Total execution time: 0.0640
INFO - 2018-11-20 14:40:27 --> Config Class Initialized
INFO - 2018-11-20 14:40:27 --> Hooks Class Initialized
DEBUG - 2018-11-20 14:40:27 --> UTF-8 Support Enabled
INFO - 2018-11-20 14:40:27 --> Utf8 Class Initialized
INFO - 2018-11-20 14:40:27 --> URI Class Initialized
INFO - 2018-11-20 14:40:27 --> Router Class Initialized
INFO - 2018-11-20 14:40:27 --> Output Class Initialized
INFO - 2018-11-20 14:40:27 --> Security Class Initialized
DEBUG - 2018-11-20 14:40:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-20 14:40:27 --> Input Class Initialized
INFO - 2018-11-20 14:40:27 --> Language Class Initialized
INFO - 2018-11-20 14:40:27 --> Loader Class Initialized
INFO - 2018-11-20 14:40:27 --> Helper loaded: url_helper
INFO - 2018-11-20 14:40:27 --> Helper loaded: file_helper
INFO - 2018-11-20 14:40:27 --> Helper loaded: email_helper
INFO - 2018-11-20 14:40:27 --> Helper loaded: common_helper
INFO - 2018-11-20 14:40:27 --> Database Driver Class Initialized
DEBUG - 2018-11-20 14:40:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-20 14:40:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-20 14:40:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-20 14:40:27 --> Pagination Class Initialized
INFO - 2018-11-20 14:40:27 --> Helper loaded: form_helper
INFO - 2018-11-20 14:40:27 --> Form Validation Class Initialized
INFO - 2018-11-20 14:40:27 --> Model Class Initialized
INFO - 2018-11-20 14:40:27 --> Controller Class Initialized
INFO - 2018-11-20 14:40:27 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-20 14:40:27 --> Model Class Initialized
INFO - 2018-11-20 14:40:27 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-20 14:40:27 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/sidebar.php
INFO - 2018-11-20 14:40:27 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/right-sidebar.php
INFO - 2018-11-20 14:40:27 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/footer.php
INFO - 2018-11-20 14:40:27 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/dashboard.php
INFO - 2018-11-20 14:40:27 --> Final output sent to browser
DEBUG - 2018-11-20 14:40:27 --> Total execution time: 0.0610
INFO - 2018-11-20 14:40:43 --> Config Class Initialized
INFO - 2018-11-20 14:40:43 --> Hooks Class Initialized
DEBUG - 2018-11-20 14:40:43 --> UTF-8 Support Enabled
INFO - 2018-11-20 14:40:43 --> Utf8 Class Initialized
INFO - 2018-11-20 14:40:43 --> URI Class Initialized
INFO - 2018-11-20 14:40:43 --> Router Class Initialized
INFO - 2018-11-20 14:40:43 --> Output Class Initialized
INFO - 2018-11-20 14:40:43 --> Security Class Initialized
DEBUG - 2018-11-20 14:40:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-20 14:40:43 --> Input Class Initialized
INFO - 2018-11-20 14:40:43 --> Language Class Initialized
INFO - 2018-11-20 14:40:43 --> Loader Class Initialized
INFO - 2018-11-20 14:40:43 --> Helper loaded: url_helper
INFO - 2018-11-20 14:40:43 --> Helper loaded: file_helper
INFO - 2018-11-20 14:40:43 --> Helper loaded: email_helper
INFO - 2018-11-20 14:40:43 --> Helper loaded: common_helper
INFO - 2018-11-20 14:40:43 --> Database Driver Class Initialized
DEBUG - 2018-11-20 14:40:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-20 14:40:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-20 14:40:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-20 14:40:43 --> Pagination Class Initialized
INFO - 2018-11-20 14:40:43 --> Helper loaded: form_helper
INFO - 2018-11-20 14:40:43 --> Form Validation Class Initialized
INFO - 2018-11-20 14:40:43 --> Model Class Initialized
INFO - 2018-11-20 14:40:43 --> Controller Class Initialized
INFO - 2018-11-20 14:40:43 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-20 14:40:43 --> Model Class Initialized
INFO - 2018-11-20 14:40:43 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-20 14:40:43 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/sidebar.php
INFO - 2018-11-20 14:40:43 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/right-sidebar.php
INFO - 2018-11-20 14:40:43 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/footer.php
INFO - 2018-11-20 14:40:43 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/dashboard.php
INFO - 2018-11-20 14:40:43 --> Final output sent to browser
DEBUG - 2018-11-20 14:40:43 --> Total execution time: 0.0570

<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2018-11-23 07:07:47 --> Config Class Initialized
INFO - 2018-11-23 07:07:47 --> Hooks Class Initialized
DEBUG - 2018-11-23 07:07:47 --> UTF-8 Support Enabled
INFO - 2018-11-23 07:07:47 --> Utf8 Class Initialized
INFO - 2018-11-23 07:07:47 --> URI Class Initialized
INFO - 2018-11-23 07:07:47 --> Router Class Initialized
INFO - 2018-11-23 07:07:47 --> Output Class Initialized
INFO - 2018-11-23 07:07:47 --> Security Class Initialized
DEBUG - 2018-11-23 07:07:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-23 07:07:47 --> Input Class Initialized
INFO - 2018-11-23 07:07:47 --> Language Class Initialized
INFO - 2018-11-23 07:07:47 --> Loader Class Initialized
INFO - 2018-11-23 07:07:47 --> Helper loaded: url_helper
INFO - 2018-11-23 07:07:47 --> Helper loaded: file_helper
INFO - 2018-11-23 07:07:47 --> Helper loaded: email_helper
INFO - 2018-11-23 07:07:47 --> Helper loaded: common_helper
INFO - 2018-11-23 07:07:47 --> Database Driver Class Initialized
DEBUG - 2018-11-23 07:07:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-23 07:07:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-23 07:07:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-23 07:07:47 --> Pagination Class Initialized
INFO - 2018-11-23 07:07:47 --> Helper loaded: form_helper
INFO - 2018-11-23 07:07:47 --> Form Validation Class Initialized
INFO - 2018-11-23 07:07:47 --> Model Class Initialized
INFO - 2018-11-23 07:07:47 --> Controller Class Initialized
INFO - 2018-11-23 07:07:47 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-23 07:07:47 --> Model Class Initialized
INFO - 2018-11-23 07:07:47 --> Model Class Initialized
INFO - 2018-11-23 07:07:47 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/index.php
INFO - 2018-11-23 07:07:47 --> Final output sent to browser
DEBUG - 2018-11-23 07:07:47 --> Total execution time: 0.0690
INFO - 2018-11-23 07:07:48 --> Config Class Initialized
INFO - 2018-11-23 07:07:48 --> Hooks Class Initialized
DEBUG - 2018-11-23 07:07:48 --> UTF-8 Support Enabled
INFO - 2018-11-23 07:07:48 --> Utf8 Class Initialized
INFO - 2018-11-23 07:07:48 --> URI Class Initialized
INFO - 2018-11-23 07:07:48 --> Router Class Initialized
INFO - 2018-11-23 07:07:48 --> Output Class Initialized
INFO - 2018-11-23 07:07:48 --> Security Class Initialized
DEBUG - 2018-11-23 07:07:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-23 07:07:48 --> Input Class Initialized
INFO - 2018-11-23 07:07:48 --> Language Class Initialized
INFO - 2018-11-23 07:07:48 --> Loader Class Initialized
INFO - 2018-11-23 07:07:48 --> Helper loaded: url_helper
INFO - 2018-11-23 07:07:48 --> Helper loaded: file_helper
INFO - 2018-11-23 07:07:48 --> Helper loaded: email_helper
INFO - 2018-11-23 07:07:48 --> Helper loaded: common_helper
INFO - 2018-11-23 07:07:48 --> Database Driver Class Initialized
DEBUG - 2018-11-23 07:07:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-23 07:07:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-23 07:07:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-23 07:07:48 --> Pagination Class Initialized
INFO - 2018-11-23 07:07:48 --> Helper loaded: form_helper
INFO - 2018-11-23 07:07:48 --> Form Validation Class Initialized
INFO - 2018-11-23 07:07:48 --> Model Class Initialized
INFO - 2018-11-23 07:07:48 --> Controller Class Initialized
INFO - 2018-11-23 07:07:48 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-23 07:07:48 --> Model Class Initialized
INFO - 2018-11-23 07:07:48 --> Model Class Initialized
INFO - 2018-11-23 07:07:48 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/index.php
INFO - 2018-11-23 07:07:48 --> Final output sent to browser
DEBUG - 2018-11-23 07:07:48 --> Total execution time: 0.0750
INFO - 2018-11-23 07:07:51 --> Config Class Initialized
INFO - 2018-11-23 07:07:51 --> Hooks Class Initialized
DEBUG - 2018-11-23 07:07:51 --> UTF-8 Support Enabled
INFO - 2018-11-23 07:07:51 --> Utf8 Class Initialized
INFO - 2018-11-23 07:07:51 --> URI Class Initialized
INFO - 2018-11-23 07:07:51 --> Router Class Initialized
INFO - 2018-11-23 07:07:51 --> Output Class Initialized
INFO - 2018-11-23 07:07:51 --> Security Class Initialized
DEBUG - 2018-11-23 07:07:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-23 07:07:51 --> Input Class Initialized
INFO - 2018-11-23 07:07:51 --> Language Class Initialized
INFO - 2018-11-23 07:07:51 --> Loader Class Initialized
INFO - 2018-11-23 07:07:51 --> Helper loaded: url_helper
INFO - 2018-11-23 07:07:51 --> Helper loaded: file_helper
INFO - 2018-11-23 07:07:51 --> Helper loaded: email_helper
INFO - 2018-11-23 07:07:51 --> Helper loaded: common_helper
INFO - 2018-11-23 07:07:51 --> Database Driver Class Initialized
DEBUG - 2018-11-23 07:07:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-23 07:07:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-23 07:07:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-23 07:07:51 --> Pagination Class Initialized
INFO - 2018-11-23 07:07:51 --> Helper loaded: form_helper
INFO - 2018-11-23 07:07:51 --> Form Validation Class Initialized
INFO - 2018-11-23 07:07:51 --> Model Class Initialized
INFO - 2018-11-23 07:07:51 --> Controller Class Initialized
INFO - 2018-11-23 07:07:51 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-23 07:07:51 --> Model Class Initialized
INFO - 2018-11-23 07:07:51 --> Model Class Initialized
ERROR - 2018-11-23 07:07:51 --> Severity: Notice --> Undefined index: remember_me C:\xampp\htdocs\wetinuneed\application\controllers\admin\Admin.php 77
INFO - 2018-11-23 07:07:51 --> Config Class Initialized
INFO - 2018-11-23 07:07:51 --> Hooks Class Initialized
DEBUG - 2018-11-23 07:07:51 --> UTF-8 Support Enabled
INFO - 2018-11-23 07:07:51 --> Utf8 Class Initialized
INFO - 2018-11-23 07:07:51 --> URI Class Initialized
INFO - 2018-11-23 07:07:51 --> Router Class Initialized
INFO - 2018-11-23 07:07:51 --> Output Class Initialized
INFO - 2018-11-23 07:07:51 --> Security Class Initialized
DEBUG - 2018-11-23 07:07:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-23 07:07:51 --> Input Class Initialized
INFO - 2018-11-23 07:07:51 --> Language Class Initialized
INFO - 2018-11-23 07:07:51 --> Loader Class Initialized
INFO - 2018-11-23 07:07:51 --> Helper loaded: url_helper
INFO - 2018-11-23 07:07:51 --> Helper loaded: file_helper
INFO - 2018-11-23 07:07:51 --> Helper loaded: email_helper
INFO - 2018-11-23 07:07:51 --> Helper loaded: common_helper
INFO - 2018-11-23 07:07:51 --> Database Driver Class Initialized
DEBUG - 2018-11-23 07:07:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-23 07:07:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-23 07:07:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-23 07:07:51 --> Pagination Class Initialized
INFO - 2018-11-23 07:07:51 --> Helper loaded: form_helper
INFO - 2018-11-23 07:07:51 --> Form Validation Class Initialized
INFO - 2018-11-23 07:07:51 --> Model Class Initialized
INFO - 2018-11-23 07:07:51 --> Controller Class Initialized
INFO - 2018-11-23 07:07:51 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-23 07:07:51 --> Model Class Initialized
INFO - 2018-11-23 07:07:51 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-23 07:07:51 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/sidebar.php
INFO - 2018-11-23 07:07:51 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/right-sidebar.php
INFO - 2018-11-23 07:07:51 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/footer.php
INFO - 2018-11-23 07:07:51 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/dashboard.php
INFO - 2018-11-23 07:07:51 --> Final output sent to browser
DEBUG - 2018-11-23 07:07:51 --> Total execution time: 0.0670
INFO - 2018-11-23 07:08:28 --> Config Class Initialized
INFO - 2018-11-23 07:08:28 --> Hooks Class Initialized
DEBUG - 2018-11-23 07:08:28 --> UTF-8 Support Enabled
INFO - 2018-11-23 07:08:28 --> Utf8 Class Initialized
INFO - 2018-11-23 07:08:28 --> URI Class Initialized
INFO - 2018-11-23 07:08:28 --> Router Class Initialized
INFO - 2018-11-23 07:08:28 --> Output Class Initialized
INFO - 2018-11-23 07:08:28 --> Security Class Initialized
DEBUG - 2018-11-23 07:08:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-23 07:08:28 --> Input Class Initialized
INFO - 2018-11-23 07:08:28 --> Language Class Initialized
INFO - 2018-11-23 07:08:28 --> Loader Class Initialized
INFO - 2018-11-23 07:08:28 --> Helper loaded: url_helper
INFO - 2018-11-23 07:08:28 --> Helper loaded: file_helper
INFO - 2018-11-23 07:08:28 --> Helper loaded: email_helper
INFO - 2018-11-23 07:08:28 --> Helper loaded: common_helper
INFO - 2018-11-23 07:08:28 --> Database Driver Class Initialized
DEBUG - 2018-11-23 07:08:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-23 07:08:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-23 07:08:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-23 07:08:28 --> Pagination Class Initialized
INFO - 2018-11-23 07:08:28 --> Helper loaded: form_helper
INFO - 2018-11-23 07:08:28 --> Form Validation Class Initialized
INFO - 2018-11-23 07:08:28 --> Model Class Initialized
INFO - 2018-11-23 07:08:28 --> Controller Class Initialized
INFO - 2018-11-23 07:08:28 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-23 07:08:28 --> Model Class Initialized
INFO - 2018-11-23 07:08:28 --> Model Class Initialized
INFO - 2018-11-23 07:08:28 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-23 07:08:28 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/change-password.php
INFO - 2018-11-23 07:08:28 --> Final output sent to browser
DEBUG - 2018-11-23 07:08:28 --> Total execution time: 0.0510
INFO - 2018-11-23 07:20:00 --> Config Class Initialized
INFO - 2018-11-23 07:20:00 --> Hooks Class Initialized
DEBUG - 2018-11-23 07:20:00 --> UTF-8 Support Enabled
INFO - 2018-11-23 07:20:00 --> Utf8 Class Initialized
INFO - 2018-11-23 07:20:00 --> URI Class Initialized
INFO - 2018-11-23 07:20:00 --> Router Class Initialized
INFO - 2018-11-23 07:20:00 --> Output Class Initialized
INFO - 2018-11-23 07:20:00 --> Security Class Initialized
DEBUG - 2018-11-23 07:20:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-23 07:20:00 --> Input Class Initialized
INFO - 2018-11-23 07:20:00 --> Language Class Initialized
INFO - 2018-11-23 07:20:00 --> Loader Class Initialized
INFO - 2018-11-23 07:20:00 --> Helper loaded: url_helper
INFO - 2018-11-23 07:20:00 --> Helper loaded: file_helper
INFO - 2018-11-23 07:20:00 --> Helper loaded: email_helper
INFO - 2018-11-23 07:20:00 --> Helper loaded: common_helper
INFO - 2018-11-23 07:20:00 --> Database Driver Class Initialized
DEBUG - 2018-11-23 07:20:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-23 07:20:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-23 07:20:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-23 07:20:00 --> Pagination Class Initialized
INFO - 2018-11-23 07:20:00 --> Helper loaded: form_helper
INFO - 2018-11-23 07:20:00 --> Form Validation Class Initialized
INFO - 2018-11-23 07:20:00 --> Model Class Initialized
INFO - 2018-11-23 07:20:00 --> Controller Class Initialized
INFO - 2018-11-23 07:20:00 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-23 07:20:00 --> Model Class Initialized
INFO - 2018-11-23 07:20:00 --> Model Class Initialized
INFO - 2018-11-23 07:20:00 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-23 07:20:00 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/change-password.php
INFO - 2018-11-23 07:20:00 --> Final output sent to browser
DEBUG - 2018-11-23 07:20:00 --> Total execution time: 0.0550
INFO - 2018-11-23 07:46:17 --> Config Class Initialized
INFO - 2018-11-23 07:46:17 --> Hooks Class Initialized
DEBUG - 2018-11-23 07:46:17 --> UTF-8 Support Enabled
INFO - 2018-11-23 07:46:17 --> Utf8 Class Initialized
INFO - 2018-11-23 07:46:17 --> URI Class Initialized
INFO - 2018-11-23 07:46:17 --> Router Class Initialized
INFO - 2018-11-23 07:46:17 --> Output Class Initialized
INFO - 2018-11-23 07:46:17 --> Security Class Initialized
DEBUG - 2018-11-23 07:46:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-23 07:46:17 --> Input Class Initialized
INFO - 2018-11-23 07:46:17 --> Language Class Initialized
INFO - 2018-11-23 07:46:17 --> Loader Class Initialized
INFO - 2018-11-23 07:46:17 --> Helper loaded: url_helper
INFO - 2018-11-23 07:46:17 --> Helper loaded: file_helper
INFO - 2018-11-23 07:46:17 --> Helper loaded: email_helper
INFO - 2018-11-23 07:46:17 --> Helper loaded: common_helper
INFO - 2018-11-23 07:46:17 --> Database Driver Class Initialized
DEBUG - 2018-11-23 07:46:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-23 07:46:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-23 07:46:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-23 07:46:17 --> Pagination Class Initialized
INFO - 2018-11-23 07:46:17 --> Helper loaded: form_helper
INFO - 2018-11-23 07:46:17 --> Form Validation Class Initialized
INFO - 2018-11-23 07:46:17 --> Model Class Initialized
INFO - 2018-11-23 07:46:17 --> Controller Class Initialized
INFO - 2018-11-23 07:46:17 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-23 07:46:17 --> Model Class Initialized
INFO - 2018-11-23 07:46:17 --> Model Class Initialized
INFO - 2018-11-23 07:46:17 --> Config Class Initialized
INFO - 2018-11-23 07:46:17 --> Hooks Class Initialized
DEBUG - 2018-11-23 07:46:17 --> UTF-8 Support Enabled
INFO - 2018-11-23 07:46:17 --> Utf8 Class Initialized
INFO - 2018-11-23 07:46:17 --> URI Class Initialized
INFO - 2018-11-23 07:46:17 --> Router Class Initialized
INFO - 2018-11-23 07:46:17 --> Output Class Initialized
INFO - 2018-11-23 07:46:17 --> Security Class Initialized
DEBUG - 2018-11-23 07:46:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-23 07:46:17 --> Input Class Initialized
INFO - 2018-11-23 07:46:17 --> Language Class Initialized
INFO - 2018-11-23 07:46:17 --> Loader Class Initialized
INFO - 2018-11-23 07:46:17 --> Helper loaded: url_helper
INFO - 2018-11-23 07:46:17 --> Helper loaded: file_helper
INFO - 2018-11-23 07:46:17 --> Helper loaded: email_helper
INFO - 2018-11-23 07:46:17 --> Helper loaded: common_helper
INFO - 2018-11-23 07:46:17 --> Database Driver Class Initialized
DEBUG - 2018-11-23 07:46:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-23 07:46:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-23 07:46:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-23 07:46:17 --> Pagination Class Initialized
INFO - 2018-11-23 07:46:17 --> Helper loaded: form_helper
INFO - 2018-11-23 07:46:17 --> Form Validation Class Initialized
INFO - 2018-11-23 07:46:17 --> Model Class Initialized
INFO - 2018-11-23 07:46:17 --> Controller Class Initialized
INFO - 2018-11-23 07:46:17 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-23 07:46:17 --> Model Class Initialized
INFO - 2018-11-23 07:46:17 --> Model Class Initialized
INFO - 2018-11-23 07:46:57 --> Config Class Initialized
INFO - 2018-11-23 07:46:57 --> Hooks Class Initialized
DEBUG - 2018-11-23 07:46:57 --> UTF-8 Support Enabled
INFO - 2018-11-23 07:46:57 --> Utf8 Class Initialized
INFO - 2018-11-23 07:46:57 --> URI Class Initialized
INFO - 2018-11-23 07:46:57 --> Router Class Initialized
INFO - 2018-11-23 07:46:57 --> Output Class Initialized
INFO - 2018-11-23 07:46:57 --> Security Class Initialized
DEBUG - 2018-11-23 07:46:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-23 07:46:57 --> Input Class Initialized
INFO - 2018-11-23 07:46:57 --> Language Class Initialized
INFO - 2018-11-23 07:46:57 --> Loader Class Initialized
INFO - 2018-11-23 07:46:57 --> Helper loaded: url_helper
INFO - 2018-11-23 07:46:57 --> Helper loaded: file_helper
INFO - 2018-11-23 07:46:57 --> Helper loaded: email_helper
INFO - 2018-11-23 07:46:57 --> Helper loaded: common_helper
INFO - 2018-11-23 07:46:57 --> Database Driver Class Initialized
DEBUG - 2018-11-23 07:46:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-23 07:46:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-23 07:46:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-23 07:46:57 --> Pagination Class Initialized
INFO - 2018-11-23 07:46:57 --> Helper loaded: form_helper
INFO - 2018-11-23 07:46:57 --> Form Validation Class Initialized
INFO - 2018-11-23 07:46:57 --> Model Class Initialized
INFO - 2018-11-23 07:46:57 --> Controller Class Initialized
INFO - 2018-11-23 07:46:57 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-23 07:46:57 --> Model Class Initialized
INFO - 2018-11-23 07:46:57 --> Model Class Initialized
ERROR - 2018-11-23 07:46:57 --> Severity: Warning --> base_convert() expects exactly 3 parameters, 1 given C:\xampp\htdocs\wetinuneed\application\controllers\admin\Admin.php 31
INFO - 2018-11-23 07:47:19 --> Config Class Initialized
INFO - 2018-11-23 07:47:19 --> Hooks Class Initialized
DEBUG - 2018-11-23 07:47:19 --> UTF-8 Support Enabled
INFO - 2018-11-23 07:47:19 --> Utf8 Class Initialized
INFO - 2018-11-23 07:47:19 --> URI Class Initialized
INFO - 2018-11-23 07:47:19 --> Router Class Initialized
INFO - 2018-11-23 07:47:19 --> Output Class Initialized
INFO - 2018-11-23 07:47:19 --> Security Class Initialized
DEBUG - 2018-11-23 07:47:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-23 07:47:19 --> Input Class Initialized
INFO - 2018-11-23 07:47:19 --> Language Class Initialized
INFO - 2018-11-23 07:47:19 --> Loader Class Initialized
INFO - 2018-11-23 07:47:19 --> Helper loaded: url_helper
INFO - 2018-11-23 07:47:19 --> Helper loaded: file_helper
INFO - 2018-11-23 07:47:19 --> Helper loaded: email_helper
INFO - 2018-11-23 07:47:19 --> Helper loaded: common_helper
INFO - 2018-11-23 07:47:19 --> Database Driver Class Initialized
DEBUG - 2018-11-23 07:47:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-23 07:47:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-23 07:47:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-23 07:47:19 --> Pagination Class Initialized
INFO - 2018-11-23 07:47:19 --> Helper loaded: form_helper
INFO - 2018-11-23 07:47:19 --> Form Validation Class Initialized
INFO - 2018-11-23 07:47:19 --> Model Class Initialized
INFO - 2018-11-23 07:47:19 --> Controller Class Initialized
INFO - 2018-11-23 07:47:19 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-23 07:47:19 --> Model Class Initialized
INFO - 2018-11-23 07:47:19 --> Model Class Initialized
ERROR - 2018-11-23 07:47:19 --> Severity: Warning --> base_convert() expects exactly 3 parameters, 1 given C:\xampp\htdocs\wetinuneed\application\controllers\admin\Admin.php 31
INFO - 2018-11-23 07:47:39 --> Config Class Initialized
INFO - 2018-11-23 07:47:39 --> Hooks Class Initialized
DEBUG - 2018-11-23 07:47:39 --> UTF-8 Support Enabled
INFO - 2018-11-23 07:47:39 --> Utf8 Class Initialized
INFO - 2018-11-23 07:47:39 --> URI Class Initialized
INFO - 2018-11-23 07:47:39 --> Router Class Initialized
INFO - 2018-11-23 07:47:39 --> Output Class Initialized
INFO - 2018-11-23 07:47:39 --> Security Class Initialized
DEBUG - 2018-11-23 07:47:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-23 07:47:39 --> Input Class Initialized
INFO - 2018-11-23 07:47:39 --> Language Class Initialized
INFO - 2018-11-23 07:47:39 --> Loader Class Initialized
INFO - 2018-11-23 07:47:39 --> Helper loaded: url_helper
INFO - 2018-11-23 07:47:39 --> Helper loaded: file_helper
INFO - 2018-11-23 07:47:39 --> Helper loaded: email_helper
INFO - 2018-11-23 07:47:39 --> Helper loaded: common_helper
INFO - 2018-11-23 07:47:39 --> Database Driver Class Initialized
DEBUG - 2018-11-23 07:47:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-23 07:47:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-23 07:47:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-23 07:47:39 --> Pagination Class Initialized
INFO - 2018-11-23 07:47:39 --> Helper loaded: form_helper
INFO - 2018-11-23 07:47:39 --> Form Validation Class Initialized
INFO - 2018-11-23 07:47:39 --> Model Class Initialized
INFO - 2018-11-23 07:47:39 --> Controller Class Initialized
INFO - 2018-11-23 07:47:39 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-23 07:47:39 --> Model Class Initialized
INFO - 2018-11-23 07:47:39 --> Model Class Initialized
INFO - 2018-11-23 07:48:21 --> Config Class Initialized
INFO - 2018-11-23 07:48:21 --> Hooks Class Initialized
DEBUG - 2018-11-23 07:48:21 --> UTF-8 Support Enabled
INFO - 2018-11-23 07:48:21 --> Utf8 Class Initialized
INFO - 2018-11-23 07:48:21 --> URI Class Initialized
INFO - 2018-11-23 07:48:21 --> Router Class Initialized
INFO - 2018-11-23 07:48:21 --> Output Class Initialized
INFO - 2018-11-23 07:48:21 --> Security Class Initialized
DEBUG - 2018-11-23 07:48:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-23 07:48:21 --> Input Class Initialized
INFO - 2018-11-23 07:48:21 --> Language Class Initialized
INFO - 2018-11-23 07:48:21 --> Loader Class Initialized
INFO - 2018-11-23 07:48:21 --> Helper loaded: url_helper
INFO - 2018-11-23 07:48:21 --> Helper loaded: file_helper
INFO - 2018-11-23 07:48:21 --> Helper loaded: email_helper
INFO - 2018-11-23 07:48:21 --> Helper loaded: common_helper
INFO - 2018-11-23 07:48:21 --> Database Driver Class Initialized
DEBUG - 2018-11-23 07:48:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-23 07:48:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-23 07:48:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-23 07:48:21 --> Pagination Class Initialized
INFO - 2018-11-23 07:48:21 --> Helper loaded: form_helper
INFO - 2018-11-23 07:48:21 --> Form Validation Class Initialized
INFO - 2018-11-23 07:48:21 --> Model Class Initialized
INFO - 2018-11-23 07:48:21 --> Controller Class Initialized
INFO - 2018-11-23 07:48:21 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-23 07:48:21 --> Model Class Initialized
INFO - 2018-11-23 07:48:21 --> Model Class Initialized
INFO - 2018-11-23 07:48:32 --> Config Class Initialized
INFO - 2018-11-23 07:48:32 --> Hooks Class Initialized
DEBUG - 2018-11-23 07:48:32 --> UTF-8 Support Enabled
INFO - 2018-11-23 07:48:32 --> Utf8 Class Initialized
INFO - 2018-11-23 07:48:32 --> URI Class Initialized
INFO - 2018-11-23 07:48:32 --> Router Class Initialized
INFO - 2018-11-23 07:48:32 --> Output Class Initialized
INFO - 2018-11-23 07:48:32 --> Security Class Initialized
DEBUG - 2018-11-23 07:48:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-23 07:48:32 --> Input Class Initialized
INFO - 2018-11-23 07:48:32 --> Language Class Initialized
INFO - 2018-11-23 07:48:32 --> Loader Class Initialized
INFO - 2018-11-23 07:48:32 --> Helper loaded: url_helper
INFO - 2018-11-23 07:48:32 --> Helper loaded: file_helper
INFO - 2018-11-23 07:48:32 --> Helper loaded: email_helper
INFO - 2018-11-23 07:48:32 --> Helper loaded: common_helper
INFO - 2018-11-23 07:48:32 --> Database Driver Class Initialized
DEBUG - 2018-11-23 07:48:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-23 07:48:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-23 07:48:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-23 07:48:32 --> Pagination Class Initialized
INFO - 2018-11-23 07:48:32 --> Helper loaded: form_helper
INFO - 2018-11-23 07:48:32 --> Form Validation Class Initialized
INFO - 2018-11-23 07:48:32 --> Model Class Initialized
INFO - 2018-11-23 07:48:32 --> Controller Class Initialized
INFO - 2018-11-23 07:48:32 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-23 07:48:32 --> Model Class Initialized
INFO - 2018-11-23 07:48:32 --> Model Class Initialized
INFO - 2018-11-23 07:48:34 --> Config Class Initialized
INFO - 2018-11-23 07:48:34 --> Hooks Class Initialized
DEBUG - 2018-11-23 07:48:34 --> UTF-8 Support Enabled
INFO - 2018-11-23 07:48:34 --> Utf8 Class Initialized
INFO - 2018-11-23 07:48:34 --> URI Class Initialized
INFO - 2018-11-23 07:48:34 --> Router Class Initialized
INFO - 2018-11-23 07:48:34 --> Output Class Initialized
INFO - 2018-11-23 07:48:34 --> Security Class Initialized
DEBUG - 2018-11-23 07:48:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-23 07:48:34 --> Input Class Initialized
INFO - 2018-11-23 07:48:34 --> Language Class Initialized
INFO - 2018-11-23 07:48:34 --> Loader Class Initialized
INFO - 2018-11-23 07:48:34 --> Helper loaded: url_helper
INFO - 2018-11-23 07:48:34 --> Helper loaded: file_helper
INFO - 2018-11-23 07:48:34 --> Helper loaded: email_helper
INFO - 2018-11-23 07:48:34 --> Helper loaded: common_helper
INFO - 2018-11-23 07:48:34 --> Database Driver Class Initialized
DEBUG - 2018-11-23 07:48:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-23 07:48:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-23 07:48:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-23 07:48:34 --> Pagination Class Initialized
INFO - 2018-11-23 07:48:34 --> Helper loaded: form_helper
INFO - 2018-11-23 07:48:34 --> Form Validation Class Initialized
INFO - 2018-11-23 07:48:34 --> Model Class Initialized
INFO - 2018-11-23 07:48:34 --> Controller Class Initialized
INFO - 2018-11-23 07:48:34 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-23 07:48:34 --> Model Class Initialized
INFO - 2018-11-23 07:48:34 --> Model Class Initialized
INFO - 2018-11-23 07:48:35 --> Config Class Initialized
INFO - 2018-11-23 07:48:35 --> Hooks Class Initialized
DEBUG - 2018-11-23 07:48:35 --> UTF-8 Support Enabled
INFO - 2018-11-23 07:48:35 --> Utf8 Class Initialized
INFO - 2018-11-23 07:48:35 --> URI Class Initialized
INFO - 2018-11-23 07:48:35 --> Router Class Initialized
INFO - 2018-11-23 07:48:35 --> Output Class Initialized
INFO - 2018-11-23 07:48:35 --> Security Class Initialized
DEBUG - 2018-11-23 07:48:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-23 07:48:35 --> Input Class Initialized
INFO - 2018-11-23 07:48:35 --> Language Class Initialized
INFO - 2018-11-23 07:48:35 --> Loader Class Initialized
INFO - 2018-11-23 07:48:35 --> Helper loaded: url_helper
INFO - 2018-11-23 07:48:35 --> Helper loaded: file_helper
INFO - 2018-11-23 07:48:35 --> Helper loaded: email_helper
INFO - 2018-11-23 07:48:35 --> Helper loaded: common_helper
INFO - 2018-11-23 07:48:35 --> Database Driver Class Initialized
DEBUG - 2018-11-23 07:48:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-23 07:48:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-23 07:48:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-23 07:48:35 --> Pagination Class Initialized
INFO - 2018-11-23 07:48:35 --> Helper loaded: form_helper
INFO - 2018-11-23 07:48:35 --> Form Validation Class Initialized
INFO - 2018-11-23 07:48:35 --> Model Class Initialized
INFO - 2018-11-23 07:48:35 --> Controller Class Initialized
INFO - 2018-11-23 07:48:35 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-23 07:48:35 --> Model Class Initialized
INFO - 2018-11-23 07:48:35 --> Model Class Initialized
INFO - 2018-11-23 07:48:36 --> Config Class Initialized
INFO - 2018-11-23 07:48:36 --> Hooks Class Initialized
DEBUG - 2018-11-23 07:48:36 --> UTF-8 Support Enabled
INFO - 2018-11-23 07:48:36 --> Utf8 Class Initialized
INFO - 2018-11-23 07:48:36 --> URI Class Initialized
INFO - 2018-11-23 07:48:36 --> Router Class Initialized
INFO - 2018-11-23 07:48:36 --> Output Class Initialized
INFO - 2018-11-23 07:48:36 --> Security Class Initialized
DEBUG - 2018-11-23 07:48:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-23 07:48:36 --> Input Class Initialized
INFO - 2018-11-23 07:48:36 --> Language Class Initialized
INFO - 2018-11-23 07:48:36 --> Loader Class Initialized
INFO - 2018-11-23 07:48:36 --> Helper loaded: url_helper
INFO - 2018-11-23 07:48:36 --> Helper loaded: file_helper
INFO - 2018-11-23 07:48:36 --> Helper loaded: email_helper
INFO - 2018-11-23 07:48:36 --> Helper loaded: common_helper
INFO - 2018-11-23 07:48:36 --> Database Driver Class Initialized
DEBUG - 2018-11-23 07:48:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-23 07:48:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-23 07:48:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-23 07:48:36 --> Pagination Class Initialized
INFO - 2018-11-23 07:48:36 --> Helper loaded: form_helper
INFO - 2018-11-23 07:48:36 --> Form Validation Class Initialized
INFO - 2018-11-23 07:48:36 --> Model Class Initialized
INFO - 2018-11-23 07:48:36 --> Controller Class Initialized
INFO - 2018-11-23 07:48:36 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-23 07:48:36 --> Model Class Initialized
INFO - 2018-11-23 07:48:36 --> Model Class Initialized
INFO - 2018-11-23 07:48:36 --> Config Class Initialized
INFO - 2018-11-23 07:48:36 --> Hooks Class Initialized
DEBUG - 2018-11-23 07:48:36 --> UTF-8 Support Enabled
INFO - 2018-11-23 07:48:36 --> Utf8 Class Initialized
INFO - 2018-11-23 07:48:36 --> URI Class Initialized
INFO - 2018-11-23 07:48:36 --> Router Class Initialized
INFO - 2018-11-23 07:48:36 --> Output Class Initialized
INFO - 2018-11-23 07:48:36 --> Security Class Initialized
DEBUG - 2018-11-23 07:48:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-23 07:48:36 --> Input Class Initialized
INFO - 2018-11-23 07:48:36 --> Language Class Initialized
INFO - 2018-11-23 07:48:36 --> Loader Class Initialized
INFO - 2018-11-23 07:48:36 --> Helper loaded: url_helper
INFO - 2018-11-23 07:48:36 --> Helper loaded: file_helper
INFO - 2018-11-23 07:48:36 --> Helper loaded: email_helper
INFO - 2018-11-23 07:48:36 --> Helper loaded: common_helper
INFO - 2018-11-23 07:48:36 --> Database Driver Class Initialized
DEBUG - 2018-11-23 07:48:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-23 07:48:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-23 07:48:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-23 07:48:36 --> Pagination Class Initialized
INFO - 2018-11-23 07:48:36 --> Helper loaded: form_helper
INFO - 2018-11-23 07:48:36 --> Form Validation Class Initialized
INFO - 2018-11-23 07:48:36 --> Model Class Initialized
INFO - 2018-11-23 07:48:36 --> Controller Class Initialized
INFO - 2018-11-23 07:48:36 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-23 07:48:36 --> Model Class Initialized
INFO - 2018-11-23 07:48:36 --> Model Class Initialized
INFO - 2018-11-23 07:48:37 --> Config Class Initialized
INFO - 2018-11-23 07:48:37 --> Hooks Class Initialized
DEBUG - 2018-11-23 07:48:37 --> UTF-8 Support Enabled
INFO - 2018-11-23 07:48:37 --> Utf8 Class Initialized
INFO - 2018-11-23 07:48:37 --> URI Class Initialized
INFO - 2018-11-23 07:48:37 --> Router Class Initialized
INFO - 2018-11-23 07:48:37 --> Output Class Initialized
INFO - 2018-11-23 07:48:37 --> Security Class Initialized
DEBUG - 2018-11-23 07:48:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-23 07:48:37 --> Input Class Initialized
INFO - 2018-11-23 07:48:37 --> Language Class Initialized
INFO - 2018-11-23 07:48:37 --> Loader Class Initialized
INFO - 2018-11-23 07:48:37 --> Helper loaded: url_helper
INFO - 2018-11-23 07:48:37 --> Helper loaded: file_helper
INFO - 2018-11-23 07:48:37 --> Helper loaded: email_helper
INFO - 2018-11-23 07:48:37 --> Helper loaded: common_helper
INFO - 2018-11-23 07:48:37 --> Database Driver Class Initialized
DEBUG - 2018-11-23 07:48:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-23 07:48:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-23 07:48:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-23 07:48:37 --> Pagination Class Initialized
INFO - 2018-11-23 07:48:37 --> Helper loaded: form_helper
INFO - 2018-11-23 07:48:37 --> Form Validation Class Initialized
INFO - 2018-11-23 07:48:37 --> Model Class Initialized
INFO - 2018-11-23 07:48:37 --> Controller Class Initialized
INFO - 2018-11-23 07:48:37 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-23 07:48:37 --> Model Class Initialized
INFO - 2018-11-23 07:48:37 --> Model Class Initialized
INFO - 2018-11-23 07:48:38 --> Config Class Initialized
INFO - 2018-11-23 07:48:38 --> Hooks Class Initialized
DEBUG - 2018-11-23 07:48:38 --> UTF-8 Support Enabled
INFO - 2018-11-23 07:48:38 --> Utf8 Class Initialized
INFO - 2018-11-23 07:48:38 --> URI Class Initialized
INFO - 2018-11-23 07:48:38 --> Router Class Initialized
INFO - 2018-11-23 07:48:38 --> Output Class Initialized
INFO - 2018-11-23 07:48:38 --> Security Class Initialized
DEBUG - 2018-11-23 07:48:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-23 07:48:38 --> Input Class Initialized
INFO - 2018-11-23 07:48:38 --> Language Class Initialized
INFO - 2018-11-23 07:48:38 --> Loader Class Initialized
INFO - 2018-11-23 07:48:38 --> Helper loaded: url_helper
INFO - 2018-11-23 07:48:38 --> Helper loaded: file_helper
INFO - 2018-11-23 07:48:38 --> Helper loaded: email_helper
INFO - 2018-11-23 07:48:38 --> Helper loaded: common_helper
INFO - 2018-11-23 07:48:38 --> Database Driver Class Initialized
DEBUG - 2018-11-23 07:48:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-23 07:48:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-23 07:48:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-23 07:48:38 --> Pagination Class Initialized
INFO - 2018-11-23 07:48:38 --> Helper loaded: form_helper
INFO - 2018-11-23 07:48:38 --> Form Validation Class Initialized
INFO - 2018-11-23 07:48:38 --> Model Class Initialized
INFO - 2018-11-23 07:48:38 --> Controller Class Initialized
INFO - 2018-11-23 07:48:38 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-23 07:48:38 --> Model Class Initialized
INFO - 2018-11-23 07:48:38 --> Model Class Initialized
INFO - 2018-11-23 07:48:38 --> Config Class Initialized
INFO - 2018-11-23 07:48:38 --> Hooks Class Initialized
DEBUG - 2018-11-23 07:48:38 --> UTF-8 Support Enabled
INFO - 2018-11-23 07:48:38 --> Utf8 Class Initialized
INFO - 2018-11-23 07:48:38 --> URI Class Initialized
INFO - 2018-11-23 07:48:38 --> Router Class Initialized
INFO - 2018-11-23 07:48:38 --> Output Class Initialized
INFO - 2018-11-23 07:48:38 --> Security Class Initialized
DEBUG - 2018-11-23 07:48:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-23 07:48:38 --> Input Class Initialized
INFO - 2018-11-23 07:48:38 --> Language Class Initialized
INFO - 2018-11-23 07:48:38 --> Loader Class Initialized
INFO - 2018-11-23 07:48:38 --> Helper loaded: url_helper
INFO - 2018-11-23 07:48:38 --> Helper loaded: file_helper
INFO - 2018-11-23 07:48:38 --> Helper loaded: email_helper
INFO - 2018-11-23 07:48:38 --> Helper loaded: common_helper
INFO - 2018-11-23 07:48:38 --> Database Driver Class Initialized
DEBUG - 2018-11-23 07:48:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-23 07:48:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-23 07:48:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-23 07:48:38 --> Pagination Class Initialized
INFO - 2018-11-23 07:48:38 --> Helper loaded: form_helper
INFO - 2018-11-23 07:48:38 --> Form Validation Class Initialized
INFO - 2018-11-23 07:48:38 --> Model Class Initialized
INFO - 2018-11-23 07:48:38 --> Controller Class Initialized
INFO - 2018-11-23 07:48:38 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-23 07:48:38 --> Model Class Initialized
INFO - 2018-11-23 07:48:38 --> Model Class Initialized
INFO - 2018-11-23 07:48:39 --> Config Class Initialized
INFO - 2018-11-23 07:48:39 --> Hooks Class Initialized
DEBUG - 2018-11-23 07:48:39 --> UTF-8 Support Enabled
INFO - 2018-11-23 07:48:39 --> Utf8 Class Initialized
INFO - 2018-11-23 07:48:39 --> URI Class Initialized
INFO - 2018-11-23 07:48:39 --> Router Class Initialized
INFO - 2018-11-23 07:48:39 --> Output Class Initialized
INFO - 2018-11-23 07:48:39 --> Security Class Initialized
DEBUG - 2018-11-23 07:48:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-23 07:48:39 --> Input Class Initialized
INFO - 2018-11-23 07:48:39 --> Language Class Initialized
INFO - 2018-11-23 07:48:39 --> Loader Class Initialized
INFO - 2018-11-23 07:48:39 --> Helper loaded: url_helper
INFO - 2018-11-23 07:48:39 --> Helper loaded: file_helper
INFO - 2018-11-23 07:48:39 --> Helper loaded: email_helper
INFO - 2018-11-23 07:48:39 --> Helper loaded: common_helper
INFO - 2018-11-23 07:48:39 --> Database Driver Class Initialized
DEBUG - 2018-11-23 07:48:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-23 07:48:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-23 07:48:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-23 07:48:39 --> Pagination Class Initialized
INFO - 2018-11-23 07:48:39 --> Helper loaded: form_helper
INFO - 2018-11-23 07:48:39 --> Form Validation Class Initialized
INFO - 2018-11-23 07:48:39 --> Model Class Initialized
INFO - 2018-11-23 07:48:39 --> Controller Class Initialized
INFO - 2018-11-23 07:48:39 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-23 07:48:39 --> Model Class Initialized
INFO - 2018-11-23 07:48:39 --> Model Class Initialized
INFO - 2018-11-23 07:48:39 --> Config Class Initialized
INFO - 2018-11-23 07:48:39 --> Hooks Class Initialized
DEBUG - 2018-11-23 07:48:39 --> UTF-8 Support Enabled
INFO - 2018-11-23 07:48:39 --> Utf8 Class Initialized
INFO - 2018-11-23 07:48:39 --> URI Class Initialized
INFO - 2018-11-23 07:48:39 --> Router Class Initialized
INFO - 2018-11-23 07:48:39 --> Output Class Initialized
INFO - 2018-11-23 07:48:39 --> Security Class Initialized
DEBUG - 2018-11-23 07:48:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-23 07:48:39 --> Input Class Initialized
INFO - 2018-11-23 07:48:39 --> Language Class Initialized
INFO - 2018-11-23 07:48:39 --> Loader Class Initialized
INFO - 2018-11-23 07:48:39 --> Helper loaded: url_helper
INFO - 2018-11-23 07:48:39 --> Helper loaded: file_helper
INFO - 2018-11-23 07:48:39 --> Helper loaded: email_helper
INFO - 2018-11-23 07:48:39 --> Helper loaded: common_helper
INFO - 2018-11-23 07:48:39 --> Database Driver Class Initialized
DEBUG - 2018-11-23 07:48:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-23 07:48:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-23 07:48:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-23 07:48:39 --> Pagination Class Initialized
INFO - 2018-11-23 07:48:39 --> Helper loaded: form_helper
INFO - 2018-11-23 07:48:39 --> Form Validation Class Initialized
INFO - 2018-11-23 07:48:39 --> Model Class Initialized
INFO - 2018-11-23 07:48:39 --> Controller Class Initialized
INFO - 2018-11-23 07:48:39 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-23 07:48:39 --> Model Class Initialized
INFO - 2018-11-23 07:48:39 --> Model Class Initialized
INFO - 2018-11-23 07:48:40 --> Config Class Initialized
INFO - 2018-11-23 07:48:40 --> Hooks Class Initialized
DEBUG - 2018-11-23 07:48:40 --> UTF-8 Support Enabled
INFO - 2018-11-23 07:48:40 --> Utf8 Class Initialized
INFO - 2018-11-23 07:48:40 --> URI Class Initialized
INFO - 2018-11-23 07:48:40 --> Router Class Initialized
INFO - 2018-11-23 07:48:40 --> Output Class Initialized
INFO - 2018-11-23 07:48:40 --> Security Class Initialized
DEBUG - 2018-11-23 07:48:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-23 07:48:40 --> Input Class Initialized
INFO - 2018-11-23 07:48:40 --> Language Class Initialized
INFO - 2018-11-23 07:48:40 --> Loader Class Initialized
INFO - 2018-11-23 07:48:40 --> Helper loaded: url_helper
INFO - 2018-11-23 07:48:40 --> Helper loaded: file_helper
INFO - 2018-11-23 07:48:40 --> Helper loaded: email_helper
INFO - 2018-11-23 07:48:40 --> Helper loaded: common_helper
INFO - 2018-11-23 07:48:40 --> Database Driver Class Initialized
DEBUG - 2018-11-23 07:48:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-23 07:48:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-23 07:48:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-23 07:48:40 --> Pagination Class Initialized
INFO - 2018-11-23 07:48:40 --> Helper loaded: form_helper
INFO - 2018-11-23 07:48:40 --> Form Validation Class Initialized
INFO - 2018-11-23 07:48:40 --> Model Class Initialized
INFO - 2018-11-23 07:48:40 --> Controller Class Initialized
INFO - 2018-11-23 07:48:40 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-23 07:48:40 --> Model Class Initialized
INFO - 2018-11-23 07:48:40 --> Model Class Initialized
INFO - 2018-11-23 07:48:41 --> Config Class Initialized
INFO - 2018-11-23 07:48:41 --> Hooks Class Initialized
DEBUG - 2018-11-23 07:48:41 --> UTF-8 Support Enabled
INFO - 2018-11-23 07:48:41 --> Utf8 Class Initialized
INFO - 2018-11-23 07:48:41 --> URI Class Initialized
INFO - 2018-11-23 07:48:41 --> Router Class Initialized
INFO - 2018-11-23 07:48:41 --> Output Class Initialized
INFO - 2018-11-23 07:48:41 --> Security Class Initialized
DEBUG - 2018-11-23 07:48:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-23 07:48:41 --> Input Class Initialized
INFO - 2018-11-23 07:48:41 --> Language Class Initialized
INFO - 2018-11-23 07:48:41 --> Loader Class Initialized
INFO - 2018-11-23 07:48:41 --> Helper loaded: url_helper
INFO - 2018-11-23 07:48:41 --> Helper loaded: file_helper
INFO - 2018-11-23 07:48:41 --> Helper loaded: email_helper
INFO - 2018-11-23 07:48:41 --> Helper loaded: common_helper
INFO - 2018-11-23 07:48:41 --> Database Driver Class Initialized
DEBUG - 2018-11-23 07:48:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-23 07:48:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-23 07:48:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-23 07:48:41 --> Pagination Class Initialized
INFO - 2018-11-23 07:48:41 --> Helper loaded: form_helper
INFO - 2018-11-23 07:48:41 --> Form Validation Class Initialized
INFO - 2018-11-23 07:48:41 --> Model Class Initialized
INFO - 2018-11-23 07:48:41 --> Controller Class Initialized
INFO - 2018-11-23 07:48:41 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-23 07:48:41 --> Model Class Initialized
INFO - 2018-11-23 07:48:41 --> Model Class Initialized
INFO - 2018-11-23 07:48:41 --> Config Class Initialized
INFO - 2018-11-23 07:48:41 --> Hooks Class Initialized
DEBUG - 2018-11-23 07:48:41 --> UTF-8 Support Enabled
INFO - 2018-11-23 07:48:41 --> Utf8 Class Initialized
INFO - 2018-11-23 07:48:41 --> URI Class Initialized
INFO - 2018-11-23 07:48:41 --> Router Class Initialized
INFO - 2018-11-23 07:48:41 --> Output Class Initialized
INFO - 2018-11-23 07:48:41 --> Security Class Initialized
DEBUG - 2018-11-23 07:48:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-23 07:48:41 --> Input Class Initialized
INFO - 2018-11-23 07:48:41 --> Language Class Initialized
INFO - 2018-11-23 07:48:41 --> Loader Class Initialized
INFO - 2018-11-23 07:48:41 --> Helper loaded: url_helper
INFO - 2018-11-23 07:48:41 --> Helper loaded: file_helper
INFO - 2018-11-23 07:48:41 --> Helper loaded: email_helper
INFO - 2018-11-23 07:48:41 --> Helper loaded: common_helper
INFO - 2018-11-23 07:48:41 --> Database Driver Class Initialized
DEBUG - 2018-11-23 07:48:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-23 07:48:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-23 07:48:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-23 07:48:41 --> Pagination Class Initialized
INFO - 2018-11-23 07:48:41 --> Helper loaded: form_helper
INFO - 2018-11-23 07:48:41 --> Form Validation Class Initialized
INFO - 2018-11-23 07:48:41 --> Model Class Initialized
INFO - 2018-11-23 07:48:41 --> Controller Class Initialized
INFO - 2018-11-23 07:48:41 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-23 07:48:41 --> Model Class Initialized
INFO - 2018-11-23 07:48:41 --> Model Class Initialized
INFO - 2018-11-23 07:48:42 --> Config Class Initialized
INFO - 2018-11-23 07:48:42 --> Hooks Class Initialized
DEBUG - 2018-11-23 07:48:42 --> UTF-8 Support Enabled
INFO - 2018-11-23 07:48:42 --> Utf8 Class Initialized
INFO - 2018-11-23 07:48:42 --> URI Class Initialized
INFO - 2018-11-23 07:48:42 --> Router Class Initialized
INFO - 2018-11-23 07:48:42 --> Output Class Initialized
INFO - 2018-11-23 07:48:42 --> Security Class Initialized
DEBUG - 2018-11-23 07:48:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-23 07:48:42 --> Input Class Initialized
INFO - 2018-11-23 07:48:42 --> Language Class Initialized
INFO - 2018-11-23 07:48:42 --> Loader Class Initialized
INFO - 2018-11-23 07:48:42 --> Helper loaded: url_helper
INFO - 2018-11-23 07:48:42 --> Helper loaded: file_helper
INFO - 2018-11-23 07:48:42 --> Helper loaded: email_helper
INFO - 2018-11-23 07:48:42 --> Helper loaded: common_helper
INFO - 2018-11-23 07:48:42 --> Database Driver Class Initialized
DEBUG - 2018-11-23 07:48:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-23 07:48:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-23 07:48:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-23 07:48:42 --> Pagination Class Initialized
INFO - 2018-11-23 07:48:42 --> Helper loaded: form_helper
INFO - 2018-11-23 07:48:42 --> Form Validation Class Initialized
INFO - 2018-11-23 07:48:42 --> Model Class Initialized
INFO - 2018-11-23 07:48:42 --> Controller Class Initialized
INFO - 2018-11-23 07:48:42 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-23 07:48:42 --> Model Class Initialized
INFO - 2018-11-23 07:48:42 --> Model Class Initialized
INFO - 2018-11-23 07:48:42 --> Config Class Initialized
INFO - 2018-11-23 07:48:42 --> Hooks Class Initialized
DEBUG - 2018-11-23 07:48:42 --> UTF-8 Support Enabled
INFO - 2018-11-23 07:48:42 --> Utf8 Class Initialized
INFO - 2018-11-23 07:48:42 --> URI Class Initialized
INFO - 2018-11-23 07:48:42 --> Router Class Initialized
INFO - 2018-11-23 07:48:42 --> Output Class Initialized
INFO - 2018-11-23 07:48:42 --> Security Class Initialized
DEBUG - 2018-11-23 07:48:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-23 07:48:42 --> Input Class Initialized
INFO - 2018-11-23 07:48:42 --> Language Class Initialized
INFO - 2018-11-23 07:48:42 --> Loader Class Initialized
INFO - 2018-11-23 07:48:42 --> Helper loaded: url_helper
INFO - 2018-11-23 07:48:42 --> Helper loaded: file_helper
INFO - 2018-11-23 07:48:42 --> Helper loaded: email_helper
INFO - 2018-11-23 07:48:42 --> Helper loaded: common_helper
INFO - 2018-11-23 07:48:42 --> Database Driver Class Initialized
DEBUG - 2018-11-23 07:48:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-23 07:48:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-23 07:48:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-23 07:48:42 --> Pagination Class Initialized
INFO - 2018-11-23 07:48:42 --> Helper loaded: form_helper
INFO - 2018-11-23 07:48:42 --> Form Validation Class Initialized
INFO - 2018-11-23 07:48:42 --> Model Class Initialized
INFO - 2018-11-23 07:48:42 --> Controller Class Initialized
INFO - 2018-11-23 07:48:42 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-23 07:48:42 --> Model Class Initialized
INFO - 2018-11-23 07:48:42 --> Model Class Initialized
INFO - 2018-11-23 07:48:43 --> Config Class Initialized
INFO - 2018-11-23 07:48:43 --> Hooks Class Initialized
DEBUG - 2018-11-23 07:48:43 --> UTF-8 Support Enabled
INFO - 2018-11-23 07:48:43 --> Utf8 Class Initialized
INFO - 2018-11-23 07:48:43 --> URI Class Initialized
INFO - 2018-11-23 07:48:43 --> Router Class Initialized
INFO - 2018-11-23 07:48:43 --> Output Class Initialized
INFO - 2018-11-23 07:48:43 --> Security Class Initialized
DEBUG - 2018-11-23 07:48:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-23 07:48:43 --> Input Class Initialized
INFO - 2018-11-23 07:48:43 --> Language Class Initialized
INFO - 2018-11-23 07:48:43 --> Loader Class Initialized
INFO - 2018-11-23 07:48:43 --> Helper loaded: url_helper
INFO - 2018-11-23 07:48:43 --> Helper loaded: file_helper
INFO - 2018-11-23 07:48:43 --> Helper loaded: email_helper
INFO - 2018-11-23 07:48:43 --> Helper loaded: common_helper
INFO - 2018-11-23 07:48:43 --> Database Driver Class Initialized
DEBUG - 2018-11-23 07:48:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-23 07:48:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-23 07:48:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-23 07:48:43 --> Pagination Class Initialized
INFO - 2018-11-23 07:48:43 --> Helper loaded: form_helper
INFO - 2018-11-23 07:48:43 --> Form Validation Class Initialized
INFO - 2018-11-23 07:48:43 --> Model Class Initialized
INFO - 2018-11-23 07:48:43 --> Controller Class Initialized
INFO - 2018-11-23 07:48:43 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-23 07:48:43 --> Model Class Initialized
INFO - 2018-11-23 07:48:43 --> Model Class Initialized
INFO - 2018-11-23 07:48:43 --> Config Class Initialized
INFO - 2018-11-23 07:48:43 --> Hooks Class Initialized
DEBUG - 2018-11-23 07:48:43 --> UTF-8 Support Enabled
INFO - 2018-11-23 07:48:43 --> Utf8 Class Initialized
INFO - 2018-11-23 07:48:43 --> URI Class Initialized
INFO - 2018-11-23 07:48:43 --> Router Class Initialized
INFO - 2018-11-23 07:48:43 --> Output Class Initialized
INFO - 2018-11-23 07:48:43 --> Security Class Initialized
DEBUG - 2018-11-23 07:48:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-23 07:48:43 --> Input Class Initialized
INFO - 2018-11-23 07:48:43 --> Language Class Initialized
INFO - 2018-11-23 07:48:43 --> Loader Class Initialized
INFO - 2018-11-23 07:48:43 --> Helper loaded: url_helper
INFO - 2018-11-23 07:48:43 --> Helper loaded: file_helper
INFO - 2018-11-23 07:48:43 --> Helper loaded: email_helper
INFO - 2018-11-23 07:48:43 --> Helper loaded: common_helper
INFO - 2018-11-23 07:48:43 --> Database Driver Class Initialized
DEBUG - 2018-11-23 07:48:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-23 07:48:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-23 07:48:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-23 07:48:43 --> Pagination Class Initialized
INFO - 2018-11-23 07:48:43 --> Helper loaded: form_helper
INFO - 2018-11-23 07:48:43 --> Form Validation Class Initialized
INFO - 2018-11-23 07:48:43 --> Model Class Initialized
INFO - 2018-11-23 07:48:43 --> Controller Class Initialized
INFO - 2018-11-23 07:48:43 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-23 07:48:43 --> Model Class Initialized
INFO - 2018-11-23 07:48:43 --> Model Class Initialized
INFO - 2018-11-23 07:48:44 --> Config Class Initialized
INFO - 2018-11-23 07:48:44 --> Hooks Class Initialized
DEBUG - 2018-11-23 07:48:44 --> UTF-8 Support Enabled
INFO - 2018-11-23 07:48:44 --> Utf8 Class Initialized
INFO - 2018-11-23 07:48:44 --> URI Class Initialized
INFO - 2018-11-23 07:48:44 --> Router Class Initialized
INFO - 2018-11-23 07:48:44 --> Output Class Initialized
INFO - 2018-11-23 07:48:44 --> Security Class Initialized
DEBUG - 2018-11-23 07:48:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-23 07:48:44 --> Input Class Initialized
INFO - 2018-11-23 07:48:44 --> Language Class Initialized
INFO - 2018-11-23 07:48:44 --> Loader Class Initialized
INFO - 2018-11-23 07:48:44 --> Helper loaded: url_helper
INFO - 2018-11-23 07:48:44 --> Helper loaded: file_helper
INFO - 2018-11-23 07:48:44 --> Helper loaded: email_helper
INFO - 2018-11-23 07:48:44 --> Helper loaded: common_helper
INFO - 2018-11-23 07:48:44 --> Database Driver Class Initialized
DEBUG - 2018-11-23 07:48:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-23 07:48:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-23 07:48:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-23 07:48:44 --> Pagination Class Initialized
INFO - 2018-11-23 07:48:44 --> Helper loaded: form_helper
INFO - 2018-11-23 07:48:44 --> Form Validation Class Initialized
INFO - 2018-11-23 07:48:44 --> Model Class Initialized
INFO - 2018-11-23 07:48:44 --> Controller Class Initialized
INFO - 2018-11-23 07:48:44 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-23 07:48:44 --> Model Class Initialized
INFO - 2018-11-23 07:48:44 --> Model Class Initialized
INFO - 2018-11-23 07:48:44 --> Config Class Initialized
INFO - 2018-11-23 07:48:44 --> Hooks Class Initialized
DEBUG - 2018-11-23 07:48:44 --> UTF-8 Support Enabled
INFO - 2018-11-23 07:48:44 --> Utf8 Class Initialized
INFO - 2018-11-23 07:48:44 --> URI Class Initialized
INFO - 2018-11-23 07:48:44 --> Router Class Initialized
INFO - 2018-11-23 07:48:44 --> Output Class Initialized
INFO - 2018-11-23 07:48:44 --> Security Class Initialized
DEBUG - 2018-11-23 07:48:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-23 07:48:44 --> Input Class Initialized
INFO - 2018-11-23 07:48:44 --> Language Class Initialized
INFO - 2018-11-23 07:48:44 --> Loader Class Initialized
INFO - 2018-11-23 07:48:44 --> Helper loaded: url_helper
INFO - 2018-11-23 07:48:44 --> Helper loaded: file_helper
INFO - 2018-11-23 07:48:44 --> Helper loaded: email_helper
INFO - 2018-11-23 07:48:44 --> Helper loaded: common_helper
INFO - 2018-11-23 07:48:44 --> Database Driver Class Initialized
DEBUG - 2018-11-23 07:48:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-23 07:48:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-23 07:48:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-23 07:48:44 --> Pagination Class Initialized
INFO - 2018-11-23 07:48:44 --> Helper loaded: form_helper
INFO - 2018-11-23 07:48:44 --> Form Validation Class Initialized
INFO - 2018-11-23 07:48:44 --> Model Class Initialized
INFO - 2018-11-23 07:48:44 --> Controller Class Initialized
INFO - 2018-11-23 07:48:44 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-23 07:48:44 --> Model Class Initialized
INFO - 2018-11-23 07:48:44 --> Model Class Initialized
INFO - 2018-11-23 07:48:45 --> Config Class Initialized
INFO - 2018-11-23 07:48:45 --> Hooks Class Initialized
DEBUG - 2018-11-23 07:48:45 --> UTF-8 Support Enabled
INFO - 2018-11-23 07:48:45 --> Utf8 Class Initialized
INFO - 2018-11-23 07:48:45 --> URI Class Initialized
INFO - 2018-11-23 07:48:45 --> Router Class Initialized
INFO - 2018-11-23 07:48:45 --> Output Class Initialized
INFO - 2018-11-23 07:48:45 --> Security Class Initialized
DEBUG - 2018-11-23 07:48:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-23 07:48:45 --> Input Class Initialized
INFO - 2018-11-23 07:48:45 --> Language Class Initialized
INFO - 2018-11-23 07:48:45 --> Loader Class Initialized
INFO - 2018-11-23 07:48:45 --> Helper loaded: url_helper
INFO - 2018-11-23 07:48:45 --> Helper loaded: file_helper
INFO - 2018-11-23 07:48:45 --> Helper loaded: email_helper
INFO - 2018-11-23 07:48:45 --> Helper loaded: common_helper
INFO - 2018-11-23 07:48:45 --> Database Driver Class Initialized
DEBUG - 2018-11-23 07:48:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-23 07:48:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-23 07:48:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-23 07:48:45 --> Pagination Class Initialized
INFO - 2018-11-23 07:48:45 --> Helper loaded: form_helper
INFO - 2018-11-23 07:48:45 --> Form Validation Class Initialized
INFO - 2018-11-23 07:48:45 --> Model Class Initialized
INFO - 2018-11-23 07:48:45 --> Controller Class Initialized
INFO - 2018-11-23 07:48:45 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-23 07:48:45 --> Model Class Initialized
INFO - 2018-11-23 07:48:45 --> Model Class Initialized
INFO - 2018-11-23 07:48:45 --> Config Class Initialized
INFO - 2018-11-23 07:48:45 --> Hooks Class Initialized
DEBUG - 2018-11-23 07:48:45 --> UTF-8 Support Enabled
INFO - 2018-11-23 07:48:45 --> Utf8 Class Initialized
INFO - 2018-11-23 07:48:45 --> URI Class Initialized
INFO - 2018-11-23 07:48:45 --> Router Class Initialized
INFO - 2018-11-23 07:48:45 --> Output Class Initialized
INFO - 2018-11-23 07:48:45 --> Security Class Initialized
DEBUG - 2018-11-23 07:48:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-23 07:48:45 --> Input Class Initialized
INFO - 2018-11-23 07:48:45 --> Language Class Initialized
INFO - 2018-11-23 07:48:45 --> Loader Class Initialized
INFO - 2018-11-23 07:48:45 --> Helper loaded: url_helper
INFO - 2018-11-23 07:48:45 --> Helper loaded: file_helper
INFO - 2018-11-23 07:48:45 --> Helper loaded: email_helper
INFO - 2018-11-23 07:48:45 --> Helper loaded: common_helper
INFO - 2018-11-23 07:48:45 --> Database Driver Class Initialized
DEBUG - 2018-11-23 07:48:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-23 07:48:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-23 07:48:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-23 07:48:45 --> Pagination Class Initialized
INFO - 2018-11-23 07:48:45 --> Helper loaded: form_helper
INFO - 2018-11-23 07:48:45 --> Form Validation Class Initialized
INFO - 2018-11-23 07:48:45 --> Model Class Initialized
INFO - 2018-11-23 07:48:45 --> Controller Class Initialized
INFO - 2018-11-23 07:48:45 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-23 07:48:45 --> Model Class Initialized
INFO - 2018-11-23 07:48:45 --> Model Class Initialized
INFO - 2018-11-23 07:48:46 --> Config Class Initialized
INFO - 2018-11-23 07:48:46 --> Hooks Class Initialized
DEBUG - 2018-11-23 07:48:46 --> UTF-8 Support Enabled
INFO - 2018-11-23 07:48:46 --> Utf8 Class Initialized
INFO - 2018-11-23 07:48:46 --> URI Class Initialized
INFO - 2018-11-23 07:48:46 --> Router Class Initialized
INFO - 2018-11-23 07:48:46 --> Output Class Initialized
INFO - 2018-11-23 07:48:46 --> Security Class Initialized
DEBUG - 2018-11-23 07:48:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-23 07:48:46 --> Input Class Initialized
INFO - 2018-11-23 07:48:46 --> Language Class Initialized
INFO - 2018-11-23 07:48:46 --> Loader Class Initialized
INFO - 2018-11-23 07:48:46 --> Helper loaded: url_helper
INFO - 2018-11-23 07:48:46 --> Helper loaded: file_helper
INFO - 2018-11-23 07:48:46 --> Helper loaded: email_helper
INFO - 2018-11-23 07:48:46 --> Helper loaded: common_helper
INFO - 2018-11-23 07:48:46 --> Database Driver Class Initialized
DEBUG - 2018-11-23 07:48:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-23 07:48:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-23 07:48:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-23 07:48:46 --> Pagination Class Initialized
INFO - 2018-11-23 07:48:46 --> Helper loaded: form_helper
INFO - 2018-11-23 07:48:46 --> Form Validation Class Initialized
INFO - 2018-11-23 07:48:46 --> Model Class Initialized
INFO - 2018-11-23 07:48:46 --> Controller Class Initialized
INFO - 2018-11-23 07:48:46 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-23 07:48:46 --> Model Class Initialized
INFO - 2018-11-23 07:48:46 --> Model Class Initialized
INFO - 2018-11-23 07:48:46 --> Config Class Initialized
INFO - 2018-11-23 07:48:46 --> Hooks Class Initialized
DEBUG - 2018-11-23 07:48:46 --> UTF-8 Support Enabled
INFO - 2018-11-23 07:48:46 --> Utf8 Class Initialized
INFO - 2018-11-23 07:48:46 --> URI Class Initialized
INFO - 2018-11-23 07:48:46 --> Router Class Initialized
INFO - 2018-11-23 07:48:46 --> Output Class Initialized
INFO - 2018-11-23 07:48:46 --> Security Class Initialized
DEBUG - 2018-11-23 07:48:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-23 07:48:46 --> Input Class Initialized
INFO - 2018-11-23 07:48:46 --> Language Class Initialized
INFO - 2018-11-23 07:48:46 --> Loader Class Initialized
INFO - 2018-11-23 07:48:46 --> Helper loaded: url_helper
INFO - 2018-11-23 07:48:46 --> Helper loaded: file_helper
INFO - 2018-11-23 07:48:46 --> Helper loaded: email_helper
INFO - 2018-11-23 07:48:46 --> Helper loaded: common_helper
INFO - 2018-11-23 07:48:46 --> Database Driver Class Initialized
DEBUG - 2018-11-23 07:48:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-23 07:48:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-23 07:48:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-23 07:48:46 --> Pagination Class Initialized
INFO - 2018-11-23 07:48:46 --> Helper loaded: form_helper
INFO - 2018-11-23 07:48:46 --> Form Validation Class Initialized
INFO - 2018-11-23 07:48:46 --> Model Class Initialized
INFO - 2018-11-23 07:48:46 --> Controller Class Initialized
INFO - 2018-11-23 07:48:46 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-23 07:48:46 --> Model Class Initialized
INFO - 2018-11-23 07:48:46 --> Model Class Initialized
INFO - 2018-11-23 07:48:47 --> Config Class Initialized
INFO - 2018-11-23 07:48:47 --> Hooks Class Initialized
DEBUG - 2018-11-23 07:48:47 --> UTF-8 Support Enabled
INFO - 2018-11-23 07:48:47 --> Utf8 Class Initialized
INFO - 2018-11-23 07:48:47 --> URI Class Initialized
INFO - 2018-11-23 07:48:47 --> Router Class Initialized
INFO - 2018-11-23 07:48:47 --> Output Class Initialized
INFO - 2018-11-23 07:48:47 --> Security Class Initialized
DEBUG - 2018-11-23 07:48:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-23 07:48:47 --> Input Class Initialized
INFO - 2018-11-23 07:48:47 --> Language Class Initialized
INFO - 2018-11-23 07:48:47 --> Loader Class Initialized
INFO - 2018-11-23 07:48:47 --> Helper loaded: url_helper
INFO - 2018-11-23 07:48:47 --> Helper loaded: file_helper
INFO - 2018-11-23 07:48:47 --> Helper loaded: email_helper
INFO - 2018-11-23 07:48:47 --> Helper loaded: common_helper
INFO - 2018-11-23 07:48:47 --> Database Driver Class Initialized
DEBUG - 2018-11-23 07:48:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-23 07:48:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-23 07:48:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-23 07:48:47 --> Pagination Class Initialized
INFO - 2018-11-23 07:48:47 --> Helper loaded: form_helper
INFO - 2018-11-23 07:48:47 --> Form Validation Class Initialized
INFO - 2018-11-23 07:48:47 --> Model Class Initialized
INFO - 2018-11-23 07:48:47 --> Controller Class Initialized
INFO - 2018-11-23 07:48:47 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-23 07:48:47 --> Model Class Initialized
INFO - 2018-11-23 07:48:47 --> Model Class Initialized
INFO - 2018-11-23 07:48:47 --> Config Class Initialized
INFO - 2018-11-23 07:48:47 --> Hooks Class Initialized
DEBUG - 2018-11-23 07:48:47 --> UTF-8 Support Enabled
INFO - 2018-11-23 07:48:47 --> Utf8 Class Initialized
INFO - 2018-11-23 07:48:47 --> URI Class Initialized
INFO - 2018-11-23 07:48:47 --> Router Class Initialized
INFO - 2018-11-23 07:48:47 --> Output Class Initialized
INFO - 2018-11-23 07:48:47 --> Security Class Initialized
DEBUG - 2018-11-23 07:48:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-23 07:48:47 --> Input Class Initialized
INFO - 2018-11-23 07:48:47 --> Language Class Initialized
INFO - 2018-11-23 07:48:47 --> Loader Class Initialized
INFO - 2018-11-23 07:48:47 --> Helper loaded: url_helper
INFO - 2018-11-23 07:48:47 --> Helper loaded: file_helper
INFO - 2018-11-23 07:48:47 --> Helper loaded: email_helper
INFO - 2018-11-23 07:48:47 --> Helper loaded: common_helper
INFO - 2018-11-23 07:48:47 --> Database Driver Class Initialized
DEBUG - 2018-11-23 07:48:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-23 07:48:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-23 07:48:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-23 07:48:47 --> Pagination Class Initialized
INFO - 2018-11-23 07:48:47 --> Helper loaded: form_helper
INFO - 2018-11-23 07:48:47 --> Form Validation Class Initialized
INFO - 2018-11-23 07:48:47 --> Model Class Initialized
INFO - 2018-11-23 07:48:47 --> Controller Class Initialized
INFO - 2018-11-23 07:48:47 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-23 07:48:47 --> Model Class Initialized
INFO - 2018-11-23 07:48:47 --> Model Class Initialized
INFO - 2018-11-23 07:48:48 --> Config Class Initialized
INFO - 2018-11-23 07:48:48 --> Hooks Class Initialized
DEBUG - 2018-11-23 07:48:48 --> UTF-8 Support Enabled
INFO - 2018-11-23 07:48:48 --> Utf8 Class Initialized
INFO - 2018-11-23 07:48:48 --> URI Class Initialized
INFO - 2018-11-23 07:48:48 --> Router Class Initialized
INFO - 2018-11-23 07:48:48 --> Output Class Initialized
INFO - 2018-11-23 07:48:48 --> Security Class Initialized
DEBUG - 2018-11-23 07:48:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-23 07:48:48 --> Input Class Initialized
INFO - 2018-11-23 07:48:48 --> Language Class Initialized
INFO - 2018-11-23 07:48:48 --> Loader Class Initialized
INFO - 2018-11-23 07:48:48 --> Helper loaded: url_helper
INFO - 2018-11-23 07:48:48 --> Helper loaded: file_helper
INFO - 2018-11-23 07:48:48 --> Helper loaded: email_helper
INFO - 2018-11-23 07:48:48 --> Helper loaded: common_helper
INFO - 2018-11-23 07:48:48 --> Database Driver Class Initialized
DEBUG - 2018-11-23 07:48:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-23 07:48:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-23 07:48:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-23 07:48:48 --> Pagination Class Initialized
INFO - 2018-11-23 07:48:48 --> Helper loaded: form_helper
INFO - 2018-11-23 07:48:48 --> Form Validation Class Initialized
INFO - 2018-11-23 07:48:48 --> Model Class Initialized
INFO - 2018-11-23 07:48:48 --> Controller Class Initialized
INFO - 2018-11-23 07:48:48 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-23 07:48:48 --> Model Class Initialized
INFO - 2018-11-23 07:48:48 --> Model Class Initialized
INFO - 2018-11-23 07:48:48 --> Config Class Initialized
INFO - 2018-11-23 07:48:48 --> Hooks Class Initialized
DEBUG - 2018-11-23 07:48:48 --> UTF-8 Support Enabled
INFO - 2018-11-23 07:48:48 --> Utf8 Class Initialized
INFO - 2018-11-23 07:48:48 --> URI Class Initialized
INFO - 2018-11-23 07:48:48 --> Router Class Initialized
INFO - 2018-11-23 07:48:48 --> Output Class Initialized
INFO - 2018-11-23 07:48:48 --> Security Class Initialized
DEBUG - 2018-11-23 07:48:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-23 07:48:48 --> Input Class Initialized
INFO - 2018-11-23 07:48:48 --> Language Class Initialized
INFO - 2018-11-23 07:48:48 --> Loader Class Initialized
INFO - 2018-11-23 07:48:48 --> Helper loaded: url_helper
INFO - 2018-11-23 07:48:48 --> Helper loaded: file_helper
INFO - 2018-11-23 07:48:48 --> Helper loaded: email_helper
INFO - 2018-11-23 07:48:48 --> Helper loaded: common_helper
INFO - 2018-11-23 07:48:48 --> Database Driver Class Initialized
DEBUG - 2018-11-23 07:48:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-23 07:48:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-23 07:48:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-23 07:48:48 --> Pagination Class Initialized
INFO - 2018-11-23 07:48:48 --> Helper loaded: form_helper
INFO - 2018-11-23 07:48:48 --> Form Validation Class Initialized
INFO - 2018-11-23 07:48:48 --> Model Class Initialized
INFO - 2018-11-23 07:48:48 --> Controller Class Initialized
INFO - 2018-11-23 07:48:48 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-23 07:48:48 --> Model Class Initialized
INFO - 2018-11-23 07:48:48 --> Model Class Initialized
INFO - 2018-11-23 07:48:49 --> Config Class Initialized
INFO - 2018-11-23 07:48:49 --> Hooks Class Initialized
DEBUG - 2018-11-23 07:48:49 --> UTF-8 Support Enabled
INFO - 2018-11-23 07:48:49 --> Utf8 Class Initialized
INFO - 2018-11-23 07:48:49 --> URI Class Initialized
INFO - 2018-11-23 07:48:49 --> Router Class Initialized
INFO - 2018-11-23 07:48:49 --> Output Class Initialized
INFO - 2018-11-23 07:48:49 --> Security Class Initialized
DEBUG - 2018-11-23 07:48:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-23 07:48:49 --> Input Class Initialized
INFO - 2018-11-23 07:48:49 --> Language Class Initialized
INFO - 2018-11-23 07:48:49 --> Loader Class Initialized
INFO - 2018-11-23 07:48:49 --> Helper loaded: url_helper
INFO - 2018-11-23 07:48:49 --> Helper loaded: file_helper
INFO - 2018-11-23 07:48:49 --> Helper loaded: email_helper
INFO - 2018-11-23 07:48:49 --> Helper loaded: common_helper
INFO - 2018-11-23 07:48:49 --> Database Driver Class Initialized
DEBUG - 2018-11-23 07:48:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-23 07:48:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-23 07:48:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-23 07:48:49 --> Pagination Class Initialized
INFO - 2018-11-23 07:48:49 --> Helper loaded: form_helper
INFO - 2018-11-23 07:48:49 --> Form Validation Class Initialized
INFO - 2018-11-23 07:48:49 --> Model Class Initialized
INFO - 2018-11-23 07:48:49 --> Controller Class Initialized
INFO - 2018-11-23 07:48:49 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-23 07:48:49 --> Model Class Initialized
INFO - 2018-11-23 07:48:49 --> Model Class Initialized
INFO - 2018-11-23 07:48:49 --> Config Class Initialized
INFO - 2018-11-23 07:48:49 --> Hooks Class Initialized
DEBUG - 2018-11-23 07:48:49 --> UTF-8 Support Enabled
INFO - 2018-11-23 07:48:49 --> Utf8 Class Initialized
INFO - 2018-11-23 07:48:49 --> URI Class Initialized
INFO - 2018-11-23 07:48:49 --> Router Class Initialized
INFO - 2018-11-23 07:48:49 --> Output Class Initialized
INFO - 2018-11-23 07:48:49 --> Security Class Initialized
DEBUG - 2018-11-23 07:48:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-23 07:48:49 --> Input Class Initialized
INFO - 2018-11-23 07:48:49 --> Language Class Initialized
INFO - 2018-11-23 07:48:49 --> Loader Class Initialized
INFO - 2018-11-23 07:48:49 --> Helper loaded: url_helper
INFO - 2018-11-23 07:48:49 --> Helper loaded: file_helper
INFO - 2018-11-23 07:48:49 --> Helper loaded: email_helper
INFO - 2018-11-23 07:48:49 --> Helper loaded: common_helper
INFO - 2018-11-23 07:48:49 --> Database Driver Class Initialized
DEBUG - 2018-11-23 07:48:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-23 07:48:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-23 07:48:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-23 07:48:49 --> Pagination Class Initialized
INFO - 2018-11-23 07:48:49 --> Helper loaded: form_helper
INFO - 2018-11-23 07:48:49 --> Form Validation Class Initialized
INFO - 2018-11-23 07:48:49 --> Model Class Initialized
INFO - 2018-11-23 07:48:49 --> Controller Class Initialized
INFO - 2018-11-23 07:48:49 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-23 07:48:49 --> Model Class Initialized
INFO - 2018-11-23 07:48:49 --> Model Class Initialized
INFO - 2018-11-23 07:48:58 --> Config Class Initialized
INFO - 2018-11-23 07:48:58 --> Hooks Class Initialized
DEBUG - 2018-11-23 07:48:58 --> UTF-8 Support Enabled
INFO - 2018-11-23 07:48:58 --> Utf8 Class Initialized
INFO - 2018-11-23 07:48:58 --> URI Class Initialized
INFO - 2018-11-23 07:48:58 --> Router Class Initialized
INFO - 2018-11-23 07:48:58 --> Output Class Initialized
INFO - 2018-11-23 07:48:58 --> Security Class Initialized
DEBUG - 2018-11-23 07:48:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-23 07:48:58 --> Input Class Initialized
INFO - 2018-11-23 07:48:58 --> Language Class Initialized
INFO - 2018-11-23 07:48:58 --> Loader Class Initialized
INFO - 2018-11-23 07:48:58 --> Helper loaded: url_helper
INFO - 2018-11-23 07:48:58 --> Helper loaded: file_helper
INFO - 2018-11-23 07:48:58 --> Helper loaded: email_helper
INFO - 2018-11-23 07:48:58 --> Helper loaded: common_helper
INFO - 2018-11-23 07:48:58 --> Database Driver Class Initialized
DEBUG - 2018-11-23 07:48:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-23 07:48:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-23 07:48:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-23 07:48:58 --> Pagination Class Initialized
INFO - 2018-11-23 07:48:58 --> Helper loaded: form_helper
INFO - 2018-11-23 07:48:58 --> Form Validation Class Initialized
INFO - 2018-11-23 07:48:58 --> Model Class Initialized
INFO - 2018-11-23 07:48:58 --> Controller Class Initialized
INFO - 2018-11-23 07:48:58 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-23 07:48:58 --> Model Class Initialized
INFO - 2018-11-23 07:48:58 --> Model Class Initialized
INFO - 2018-11-23 07:48:59 --> Config Class Initialized
INFO - 2018-11-23 07:48:59 --> Hooks Class Initialized
DEBUG - 2018-11-23 07:48:59 --> UTF-8 Support Enabled
INFO - 2018-11-23 07:48:59 --> Utf8 Class Initialized
INFO - 2018-11-23 07:48:59 --> URI Class Initialized
INFO - 2018-11-23 07:48:59 --> Router Class Initialized
INFO - 2018-11-23 07:48:59 --> Output Class Initialized
INFO - 2018-11-23 07:48:59 --> Security Class Initialized
DEBUG - 2018-11-23 07:48:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-23 07:48:59 --> Input Class Initialized
INFO - 2018-11-23 07:48:59 --> Language Class Initialized
INFO - 2018-11-23 07:48:59 --> Loader Class Initialized
INFO - 2018-11-23 07:48:59 --> Helper loaded: url_helper
INFO - 2018-11-23 07:48:59 --> Helper loaded: file_helper
INFO - 2018-11-23 07:48:59 --> Helper loaded: email_helper
INFO - 2018-11-23 07:48:59 --> Helper loaded: common_helper
INFO - 2018-11-23 07:48:59 --> Database Driver Class Initialized
DEBUG - 2018-11-23 07:48:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-23 07:48:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-23 07:48:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-23 07:48:59 --> Pagination Class Initialized
INFO - 2018-11-23 07:48:59 --> Helper loaded: form_helper
INFO - 2018-11-23 07:48:59 --> Form Validation Class Initialized
INFO - 2018-11-23 07:48:59 --> Model Class Initialized
INFO - 2018-11-23 07:48:59 --> Controller Class Initialized
INFO - 2018-11-23 07:48:59 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-23 07:48:59 --> Model Class Initialized
INFO - 2018-11-23 07:48:59 --> Model Class Initialized
INFO - 2018-11-23 07:48:59 --> Config Class Initialized
INFO - 2018-11-23 07:48:59 --> Hooks Class Initialized
DEBUG - 2018-11-23 07:48:59 --> UTF-8 Support Enabled
INFO - 2018-11-23 07:48:59 --> Utf8 Class Initialized
INFO - 2018-11-23 07:48:59 --> URI Class Initialized
INFO - 2018-11-23 07:48:59 --> Router Class Initialized
INFO - 2018-11-23 07:48:59 --> Output Class Initialized
INFO - 2018-11-23 07:48:59 --> Security Class Initialized
DEBUG - 2018-11-23 07:48:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-23 07:48:59 --> Input Class Initialized
INFO - 2018-11-23 07:48:59 --> Language Class Initialized
INFO - 2018-11-23 07:48:59 --> Loader Class Initialized
INFO - 2018-11-23 07:48:59 --> Helper loaded: url_helper
INFO - 2018-11-23 07:48:59 --> Helper loaded: file_helper
INFO - 2018-11-23 07:48:59 --> Helper loaded: email_helper
INFO - 2018-11-23 07:48:59 --> Helper loaded: common_helper
INFO - 2018-11-23 07:48:59 --> Database Driver Class Initialized
DEBUG - 2018-11-23 07:48:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-23 07:48:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-23 07:48:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-23 07:48:59 --> Pagination Class Initialized
INFO - 2018-11-23 07:48:59 --> Helper loaded: form_helper
INFO - 2018-11-23 07:48:59 --> Form Validation Class Initialized
INFO - 2018-11-23 07:48:59 --> Model Class Initialized
INFO - 2018-11-23 07:48:59 --> Controller Class Initialized
INFO - 2018-11-23 07:48:59 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-23 07:48:59 --> Model Class Initialized
INFO - 2018-11-23 07:48:59 --> Model Class Initialized
INFO - 2018-11-23 07:49:00 --> Config Class Initialized
INFO - 2018-11-23 07:49:00 --> Hooks Class Initialized
DEBUG - 2018-11-23 07:49:00 --> UTF-8 Support Enabled
INFO - 2018-11-23 07:49:00 --> Utf8 Class Initialized
INFO - 2018-11-23 07:49:00 --> URI Class Initialized
INFO - 2018-11-23 07:49:00 --> Router Class Initialized
INFO - 2018-11-23 07:49:00 --> Output Class Initialized
INFO - 2018-11-23 07:49:00 --> Security Class Initialized
DEBUG - 2018-11-23 07:49:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-23 07:49:00 --> Input Class Initialized
INFO - 2018-11-23 07:49:00 --> Language Class Initialized
INFO - 2018-11-23 07:49:00 --> Loader Class Initialized
INFO - 2018-11-23 07:49:00 --> Helper loaded: url_helper
INFO - 2018-11-23 07:49:00 --> Helper loaded: file_helper
INFO - 2018-11-23 07:49:00 --> Helper loaded: email_helper
INFO - 2018-11-23 07:49:00 --> Helper loaded: common_helper
INFO - 2018-11-23 07:49:00 --> Database Driver Class Initialized
DEBUG - 2018-11-23 07:49:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-23 07:49:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-23 07:49:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-23 07:49:00 --> Pagination Class Initialized
INFO - 2018-11-23 07:49:00 --> Helper loaded: form_helper
INFO - 2018-11-23 07:49:00 --> Form Validation Class Initialized
INFO - 2018-11-23 07:49:00 --> Model Class Initialized
INFO - 2018-11-23 07:49:00 --> Controller Class Initialized
INFO - 2018-11-23 07:49:00 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-23 07:49:00 --> Model Class Initialized
INFO - 2018-11-23 07:49:00 --> Model Class Initialized
INFO - 2018-11-23 07:49:00 --> Config Class Initialized
INFO - 2018-11-23 07:49:00 --> Hooks Class Initialized
DEBUG - 2018-11-23 07:49:00 --> UTF-8 Support Enabled
INFO - 2018-11-23 07:49:00 --> Utf8 Class Initialized
INFO - 2018-11-23 07:49:00 --> URI Class Initialized
INFO - 2018-11-23 07:49:00 --> Router Class Initialized
INFO - 2018-11-23 07:49:00 --> Output Class Initialized
INFO - 2018-11-23 07:49:00 --> Security Class Initialized
DEBUG - 2018-11-23 07:49:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-23 07:49:00 --> Input Class Initialized
INFO - 2018-11-23 07:49:00 --> Language Class Initialized
INFO - 2018-11-23 07:49:00 --> Loader Class Initialized
INFO - 2018-11-23 07:49:00 --> Helper loaded: url_helper
INFO - 2018-11-23 07:49:00 --> Helper loaded: file_helper
INFO - 2018-11-23 07:49:00 --> Helper loaded: email_helper
INFO - 2018-11-23 07:49:00 --> Helper loaded: common_helper
INFO - 2018-11-23 07:49:00 --> Database Driver Class Initialized
DEBUG - 2018-11-23 07:49:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-23 07:49:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-23 07:49:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-23 07:49:00 --> Pagination Class Initialized
INFO - 2018-11-23 07:49:00 --> Helper loaded: form_helper
INFO - 2018-11-23 07:49:00 --> Form Validation Class Initialized
INFO - 2018-11-23 07:49:00 --> Model Class Initialized
INFO - 2018-11-23 07:49:00 --> Controller Class Initialized
INFO - 2018-11-23 07:49:00 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-23 07:49:00 --> Model Class Initialized
INFO - 2018-11-23 07:49:00 --> Model Class Initialized
INFO - 2018-11-23 07:49:00 --> Config Class Initialized
INFO - 2018-11-23 07:49:00 --> Hooks Class Initialized
DEBUG - 2018-11-23 07:49:00 --> UTF-8 Support Enabled
INFO - 2018-11-23 07:49:00 --> Utf8 Class Initialized
INFO - 2018-11-23 07:49:00 --> URI Class Initialized
INFO - 2018-11-23 07:49:00 --> Router Class Initialized
INFO - 2018-11-23 07:49:00 --> Output Class Initialized
INFO - 2018-11-23 07:49:00 --> Security Class Initialized
DEBUG - 2018-11-23 07:49:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-23 07:49:01 --> Input Class Initialized
INFO - 2018-11-23 07:49:01 --> Language Class Initialized
INFO - 2018-11-23 07:49:01 --> Loader Class Initialized
INFO - 2018-11-23 07:49:01 --> Helper loaded: url_helper
INFO - 2018-11-23 07:49:01 --> Helper loaded: file_helper
INFO - 2018-11-23 07:49:01 --> Helper loaded: email_helper
INFO - 2018-11-23 07:49:01 --> Helper loaded: common_helper
INFO - 2018-11-23 07:49:01 --> Database Driver Class Initialized
DEBUG - 2018-11-23 07:49:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-23 07:49:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-23 07:49:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-23 07:49:01 --> Pagination Class Initialized
INFO - 2018-11-23 07:49:01 --> Helper loaded: form_helper
INFO - 2018-11-23 07:49:01 --> Form Validation Class Initialized
INFO - 2018-11-23 07:49:01 --> Model Class Initialized
INFO - 2018-11-23 07:49:01 --> Controller Class Initialized
INFO - 2018-11-23 07:49:01 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-23 07:49:01 --> Model Class Initialized
INFO - 2018-11-23 07:49:01 --> Model Class Initialized
INFO - 2018-11-23 07:49:01 --> Config Class Initialized
INFO - 2018-11-23 07:49:01 --> Hooks Class Initialized
DEBUG - 2018-11-23 07:49:01 --> UTF-8 Support Enabled
INFO - 2018-11-23 07:49:01 --> Utf8 Class Initialized
INFO - 2018-11-23 07:49:01 --> URI Class Initialized
INFO - 2018-11-23 07:49:01 --> Router Class Initialized
INFO - 2018-11-23 07:49:01 --> Output Class Initialized
INFO - 2018-11-23 07:49:01 --> Security Class Initialized
DEBUG - 2018-11-23 07:49:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-23 07:49:01 --> Input Class Initialized
INFO - 2018-11-23 07:49:01 --> Language Class Initialized
INFO - 2018-11-23 07:49:01 --> Loader Class Initialized
INFO - 2018-11-23 07:49:01 --> Helper loaded: url_helper
INFO - 2018-11-23 07:49:01 --> Helper loaded: file_helper
INFO - 2018-11-23 07:49:01 --> Helper loaded: email_helper
INFO - 2018-11-23 07:49:01 --> Helper loaded: common_helper
INFO - 2018-11-23 07:49:01 --> Database Driver Class Initialized
DEBUG - 2018-11-23 07:49:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-23 07:49:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-23 07:49:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-23 07:49:01 --> Pagination Class Initialized
INFO - 2018-11-23 07:49:01 --> Helper loaded: form_helper
INFO - 2018-11-23 07:49:01 --> Form Validation Class Initialized
INFO - 2018-11-23 07:49:01 --> Model Class Initialized
INFO - 2018-11-23 07:49:01 --> Controller Class Initialized
INFO - 2018-11-23 07:49:01 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-23 07:49:01 --> Model Class Initialized
INFO - 2018-11-23 07:49:01 --> Model Class Initialized
INFO - 2018-11-23 07:49:01 --> Config Class Initialized
INFO - 2018-11-23 07:49:01 --> Hooks Class Initialized
DEBUG - 2018-11-23 07:49:01 --> UTF-8 Support Enabled
INFO - 2018-11-23 07:49:01 --> Utf8 Class Initialized
INFO - 2018-11-23 07:49:01 --> URI Class Initialized
INFO - 2018-11-23 07:49:01 --> Router Class Initialized
INFO - 2018-11-23 07:49:01 --> Output Class Initialized
INFO - 2018-11-23 07:49:01 --> Security Class Initialized
DEBUG - 2018-11-23 07:49:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-23 07:49:01 --> Input Class Initialized
INFO - 2018-11-23 07:49:01 --> Language Class Initialized
INFO - 2018-11-23 07:49:01 --> Loader Class Initialized
INFO - 2018-11-23 07:49:01 --> Helper loaded: url_helper
INFO - 2018-11-23 07:49:01 --> Helper loaded: file_helper
INFO - 2018-11-23 07:49:01 --> Helper loaded: email_helper
INFO - 2018-11-23 07:49:01 --> Helper loaded: common_helper
INFO - 2018-11-23 07:49:01 --> Database Driver Class Initialized
DEBUG - 2018-11-23 07:49:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-23 07:49:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-23 07:49:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-23 07:49:01 --> Pagination Class Initialized
INFO - 2018-11-23 07:49:01 --> Helper loaded: form_helper
INFO - 2018-11-23 07:49:01 --> Form Validation Class Initialized
INFO - 2018-11-23 07:49:01 --> Model Class Initialized
INFO - 2018-11-23 07:49:01 --> Controller Class Initialized
INFO - 2018-11-23 07:49:01 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-23 07:49:01 --> Model Class Initialized
INFO - 2018-11-23 07:49:01 --> Model Class Initialized
INFO - 2018-11-23 07:49:01 --> Config Class Initialized
INFO - 2018-11-23 07:49:01 --> Hooks Class Initialized
DEBUG - 2018-11-23 07:49:01 --> UTF-8 Support Enabled
INFO - 2018-11-23 07:49:01 --> Utf8 Class Initialized
INFO - 2018-11-23 07:49:01 --> URI Class Initialized
INFO - 2018-11-23 07:49:01 --> Router Class Initialized
INFO - 2018-11-23 07:49:01 --> Output Class Initialized
INFO - 2018-11-23 07:49:01 --> Security Class Initialized
DEBUG - 2018-11-23 07:49:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-23 07:49:01 --> Input Class Initialized
INFO - 2018-11-23 07:49:01 --> Language Class Initialized
INFO - 2018-11-23 07:49:01 --> Loader Class Initialized
INFO - 2018-11-23 07:49:01 --> Helper loaded: url_helper
INFO - 2018-11-23 07:49:01 --> Helper loaded: file_helper
INFO - 2018-11-23 07:49:01 --> Helper loaded: email_helper
INFO - 2018-11-23 07:49:01 --> Helper loaded: common_helper
INFO - 2018-11-23 07:49:01 --> Database Driver Class Initialized
DEBUG - 2018-11-23 07:49:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-23 07:49:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-23 07:49:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-23 07:49:01 --> Pagination Class Initialized
INFO - 2018-11-23 07:49:01 --> Helper loaded: form_helper
INFO - 2018-11-23 07:49:01 --> Form Validation Class Initialized
INFO - 2018-11-23 07:49:01 --> Model Class Initialized
INFO - 2018-11-23 07:49:01 --> Controller Class Initialized
INFO - 2018-11-23 07:49:01 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-23 07:49:01 --> Model Class Initialized
INFO - 2018-11-23 07:49:01 --> Model Class Initialized
INFO - 2018-11-23 07:49:01 --> Config Class Initialized
INFO - 2018-11-23 07:49:01 --> Hooks Class Initialized
DEBUG - 2018-11-23 07:49:01 --> UTF-8 Support Enabled
INFO - 2018-11-23 07:49:01 --> Utf8 Class Initialized
INFO - 2018-11-23 07:49:01 --> URI Class Initialized
INFO - 2018-11-23 07:49:01 --> Router Class Initialized
INFO - 2018-11-23 07:49:01 --> Output Class Initialized
INFO - 2018-11-23 07:49:01 --> Security Class Initialized
DEBUG - 2018-11-23 07:49:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-23 07:49:01 --> Input Class Initialized
INFO - 2018-11-23 07:49:01 --> Language Class Initialized
INFO - 2018-11-23 07:49:01 --> Loader Class Initialized
INFO - 2018-11-23 07:49:01 --> Helper loaded: url_helper
INFO - 2018-11-23 07:49:01 --> Helper loaded: file_helper
INFO - 2018-11-23 07:49:01 --> Helper loaded: email_helper
INFO - 2018-11-23 07:49:01 --> Helper loaded: common_helper
INFO - 2018-11-23 07:49:01 --> Database Driver Class Initialized
DEBUG - 2018-11-23 07:49:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-23 07:49:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-23 07:49:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-23 07:49:01 --> Pagination Class Initialized
INFO - 2018-11-23 07:49:01 --> Helper loaded: form_helper
INFO - 2018-11-23 07:49:01 --> Form Validation Class Initialized
INFO - 2018-11-23 07:49:01 --> Model Class Initialized
INFO - 2018-11-23 07:49:01 --> Controller Class Initialized
INFO - 2018-11-23 07:49:01 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-23 07:49:01 --> Model Class Initialized
INFO - 2018-11-23 07:49:01 --> Model Class Initialized
INFO - 2018-11-23 07:49:01 --> Config Class Initialized
INFO - 2018-11-23 07:49:01 --> Hooks Class Initialized
DEBUG - 2018-11-23 07:49:01 --> UTF-8 Support Enabled
INFO - 2018-11-23 07:49:01 --> Utf8 Class Initialized
INFO - 2018-11-23 07:49:01 --> URI Class Initialized
INFO - 2018-11-23 07:49:01 --> Router Class Initialized
INFO - 2018-11-23 07:49:01 --> Output Class Initialized
INFO - 2018-11-23 07:49:01 --> Security Class Initialized
DEBUG - 2018-11-23 07:49:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-23 07:49:01 --> Input Class Initialized
INFO - 2018-11-23 07:49:01 --> Language Class Initialized
INFO - 2018-11-23 07:49:02 --> Loader Class Initialized
INFO - 2018-11-23 07:49:02 --> Helper loaded: url_helper
INFO - 2018-11-23 07:49:02 --> Helper loaded: file_helper
INFO - 2018-11-23 07:49:02 --> Helper loaded: email_helper
INFO - 2018-11-23 07:49:02 --> Helper loaded: common_helper
INFO - 2018-11-23 07:49:02 --> Database Driver Class Initialized
DEBUG - 2018-11-23 07:49:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-23 07:49:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-23 07:49:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-23 07:49:02 --> Pagination Class Initialized
INFO - 2018-11-23 07:49:02 --> Helper loaded: form_helper
INFO - 2018-11-23 07:49:02 --> Form Validation Class Initialized
INFO - 2018-11-23 07:49:02 --> Model Class Initialized
INFO - 2018-11-23 07:49:02 --> Controller Class Initialized
INFO - 2018-11-23 07:49:02 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-23 07:49:02 --> Model Class Initialized
INFO - 2018-11-23 07:49:02 --> Model Class Initialized
INFO - 2018-11-23 07:49:02 --> Config Class Initialized
INFO - 2018-11-23 07:49:02 --> Hooks Class Initialized
DEBUG - 2018-11-23 07:49:02 --> UTF-8 Support Enabled
INFO - 2018-11-23 07:49:02 --> Utf8 Class Initialized
INFO - 2018-11-23 07:49:02 --> URI Class Initialized
INFO - 2018-11-23 07:49:02 --> Router Class Initialized
INFO - 2018-11-23 07:49:02 --> Output Class Initialized
INFO - 2018-11-23 07:49:02 --> Security Class Initialized
DEBUG - 2018-11-23 07:49:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-23 07:49:02 --> Input Class Initialized
INFO - 2018-11-23 07:49:02 --> Language Class Initialized
INFO - 2018-11-23 07:49:02 --> Loader Class Initialized
INFO - 2018-11-23 07:49:02 --> Helper loaded: url_helper
INFO - 2018-11-23 07:49:02 --> Helper loaded: file_helper
INFO - 2018-11-23 07:49:02 --> Helper loaded: email_helper
INFO - 2018-11-23 07:49:02 --> Helper loaded: common_helper
INFO - 2018-11-23 07:49:02 --> Database Driver Class Initialized
DEBUG - 2018-11-23 07:49:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-23 07:49:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-23 07:49:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-23 07:49:02 --> Pagination Class Initialized
INFO - 2018-11-23 07:49:02 --> Helper loaded: form_helper
INFO - 2018-11-23 07:49:02 --> Form Validation Class Initialized
INFO - 2018-11-23 07:49:02 --> Model Class Initialized
INFO - 2018-11-23 07:49:02 --> Controller Class Initialized
INFO - 2018-11-23 07:49:02 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-23 07:49:02 --> Model Class Initialized
INFO - 2018-11-23 07:49:02 --> Model Class Initialized
INFO - 2018-11-23 07:49:02 --> Config Class Initialized
INFO - 2018-11-23 07:49:02 --> Hooks Class Initialized
DEBUG - 2018-11-23 07:49:02 --> UTF-8 Support Enabled
INFO - 2018-11-23 07:49:02 --> Utf8 Class Initialized
INFO - 2018-11-23 07:49:02 --> URI Class Initialized
INFO - 2018-11-23 07:49:02 --> Router Class Initialized
INFO - 2018-11-23 07:49:02 --> Output Class Initialized
INFO - 2018-11-23 07:49:02 --> Security Class Initialized
DEBUG - 2018-11-23 07:49:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-23 07:49:02 --> Input Class Initialized
INFO - 2018-11-23 07:49:02 --> Language Class Initialized
INFO - 2018-11-23 07:49:02 --> Loader Class Initialized
INFO - 2018-11-23 07:49:02 --> Helper loaded: url_helper
INFO - 2018-11-23 07:49:02 --> Helper loaded: file_helper
INFO - 2018-11-23 07:49:02 --> Helper loaded: email_helper
INFO - 2018-11-23 07:49:02 --> Helper loaded: common_helper
INFO - 2018-11-23 07:49:02 --> Database Driver Class Initialized
DEBUG - 2018-11-23 07:49:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-23 07:49:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-23 07:49:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-23 07:49:02 --> Pagination Class Initialized
INFO - 2018-11-23 07:49:02 --> Helper loaded: form_helper
INFO - 2018-11-23 07:49:02 --> Form Validation Class Initialized
INFO - 2018-11-23 07:49:02 --> Model Class Initialized
INFO - 2018-11-23 07:49:02 --> Controller Class Initialized
INFO - 2018-11-23 07:49:02 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-23 07:49:02 --> Model Class Initialized
INFO - 2018-11-23 07:49:02 --> Model Class Initialized
INFO - 2018-11-23 07:59:19 --> Config Class Initialized
INFO - 2018-11-23 07:59:19 --> Hooks Class Initialized
DEBUG - 2018-11-23 07:59:19 --> UTF-8 Support Enabled
INFO - 2018-11-23 07:59:19 --> Utf8 Class Initialized
INFO - 2018-11-23 07:59:19 --> URI Class Initialized
INFO - 2018-11-23 07:59:19 --> Router Class Initialized
INFO - 2018-11-23 07:59:19 --> Output Class Initialized
INFO - 2018-11-23 07:59:19 --> Security Class Initialized
DEBUG - 2018-11-23 07:59:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-23 07:59:19 --> Input Class Initialized
INFO - 2018-11-23 07:59:19 --> Language Class Initialized
INFO - 2018-11-23 07:59:19 --> Loader Class Initialized
INFO - 2018-11-23 07:59:19 --> Helper loaded: url_helper
INFO - 2018-11-23 07:59:19 --> Helper loaded: file_helper
INFO - 2018-11-23 07:59:19 --> Helper loaded: email_helper
INFO - 2018-11-23 07:59:19 --> Helper loaded: common_helper
INFO - 2018-11-23 07:59:19 --> Database Driver Class Initialized
DEBUG - 2018-11-23 07:59:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-23 07:59:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-23 07:59:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-23 07:59:19 --> Pagination Class Initialized
INFO - 2018-11-23 07:59:19 --> Helper loaded: form_helper
INFO - 2018-11-23 07:59:19 --> Form Validation Class Initialized
INFO - 2018-11-23 07:59:19 --> Model Class Initialized
INFO - 2018-11-23 07:59:19 --> Controller Class Initialized
INFO - 2018-11-23 07:59:19 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-23 07:59:19 --> Model Class Initialized
INFO - 2018-11-23 07:59:19 --> Model Class Initialized
INFO - 2018-11-23 07:59:19 --> Config Class Initialized
INFO - 2018-11-23 07:59:19 --> Hooks Class Initialized
DEBUG - 2018-11-23 07:59:19 --> UTF-8 Support Enabled
INFO - 2018-11-23 07:59:19 --> Utf8 Class Initialized
INFO - 2018-11-23 07:59:19 --> URI Class Initialized
INFO - 2018-11-23 07:59:19 --> Router Class Initialized
INFO - 2018-11-23 07:59:19 --> Output Class Initialized
INFO - 2018-11-23 07:59:19 --> Security Class Initialized
DEBUG - 2018-11-23 07:59:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-23 07:59:19 --> Input Class Initialized
INFO - 2018-11-23 07:59:19 --> Language Class Initialized
INFO - 2018-11-23 07:59:19 --> Loader Class Initialized
INFO - 2018-11-23 07:59:19 --> Helper loaded: url_helper
INFO - 2018-11-23 07:59:19 --> Helper loaded: file_helper
INFO - 2018-11-23 07:59:19 --> Helper loaded: email_helper
INFO - 2018-11-23 07:59:19 --> Helper loaded: common_helper
INFO - 2018-11-23 07:59:19 --> Database Driver Class Initialized
DEBUG - 2018-11-23 07:59:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-23 07:59:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-23 07:59:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-23 07:59:19 --> Pagination Class Initialized
INFO - 2018-11-23 07:59:19 --> Helper loaded: form_helper
INFO - 2018-11-23 07:59:19 --> Form Validation Class Initialized
INFO - 2018-11-23 07:59:19 --> Model Class Initialized
INFO - 2018-11-23 07:59:19 --> Controller Class Initialized
INFO - 2018-11-23 07:59:19 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-23 07:59:19 --> Model Class Initialized
INFO - 2018-11-23 07:59:19 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-23 07:59:19 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/sidebar.php
INFO - 2018-11-23 07:59:19 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/right-sidebar.php
INFO - 2018-11-23 07:59:19 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/footer.php
INFO - 2018-11-23 07:59:19 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/dashboard.php
INFO - 2018-11-23 07:59:19 --> Final output sent to browser
DEBUG - 2018-11-23 07:59:19 --> Total execution time: 0.0510
INFO - 2018-11-23 07:59:25 --> Config Class Initialized
INFO - 2018-11-23 07:59:25 --> Hooks Class Initialized
DEBUG - 2018-11-23 07:59:25 --> UTF-8 Support Enabled
INFO - 2018-11-23 07:59:25 --> Utf8 Class Initialized
INFO - 2018-11-23 07:59:25 --> URI Class Initialized
INFO - 2018-11-23 07:59:25 --> Router Class Initialized
INFO - 2018-11-23 07:59:25 --> Output Class Initialized
INFO - 2018-11-23 07:59:25 --> Security Class Initialized
DEBUG - 2018-11-23 07:59:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-23 07:59:25 --> Input Class Initialized
INFO - 2018-11-23 07:59:25 --> Language Class Initialized
INFO - 2018-11-23 07:59:25 --> Loader Class Initialized
INFO - 2018-11-23 07:59:25 --> Helper loaded: url_helper
INFO - 2018-11-23 07:59:25 --> Helper loaded: file_helper
INFO - 2018-11-23 07:59:25 --> Helper loaded: email_helper
INFO - 2018-11-23 07:59:25 --> Helper loaded: common_helper
INFO - 2018-11-23 07:59:25 --> Database Driver Class Initialized
DEBUG - 2018-11-23 07:59:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-23 07:59:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-23 07:59:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-23 07:59:26 --> Pagination Class Initialized
INFO - 2018-11-23 07:59:26 --> Helper loaded: form_helper
INFO - 2018-11-23 07:59:26 --> Form Validation Class Initialized
INFO - 2018-11-23 07:59:26 --> Model Class Initialized
INFO - 2018-11-23 07:59:26 --> Controller Class Initialized
INFO - 2018-11-23 07:59:26 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-23 07:59:26 --> Model Class Initialized
INFO - 2018-11-23 07:59:26 --> Model Class Initialized
INFO - 2018-11-23 08:01:26 --> Config Class Initialized
INFO - 2018-11-23 08:01:26 --> Hooks Class Initialized
DEBUG - 2018-11-23 08:01:26 --> UTF-8 Support Enabled
INFO - 2018-11-23 08:01:26 --> Utf8 Class Initialized
INFO - 2018-11-23 08:01:26 --> URI Class Initialized
INFO - 2018-11-23 08:01:26 --> Router Class Initialized
INFO - 2018-11-23 08:01:26 --> Output Class Initialized
INFO - 2018-11-23 08:01:26 --> Security Class Initialized
DEBUG - 2018-11-23 08:01:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-23 08:01:26 --> Input Class Initialized
INFO - 2018-11-23 08:01:26 --> Language Class Initialized
INFO - 2018-11-23 08:01:26 --> Loader Class Initialized
INFO - 2018-11-23 08:01:26 --> Helper loaded: url_helper
INFO - 2018-11-23 08:01:26 --> Helper loaded: file_helper
INFO - 2018-11-23 08:01:26 --> Helper loaded: email_helper
INFO - 2018-11-23 08:01:26 --> Helper loaded: common_helper
INFO - 2018-11-23 08:01:26 --> Database Driver Class Initialized
DEBUG - 2018-11-23 08:01:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-23 08:01:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-23 08:01:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-23 08:01:26 --> Pagination Class Initialized
INFO - 2018-11-23 08:01:26 --> Helper loaded: form_helper
INFO - 2018-11-23 08:01:26 --> Form Validation Class Initialized
INFO - 2018-11-23 08:01:26 --> Model Class Initialized
INFO - 2018-11-23 08:01:26 --> Controller Class Initialized
INFO - 2018-11-23 08:01:26 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-23 08:01:26 --> Model Class Initialized
INFO - 2018-11-23 08:01:26 --> Model Class Initialized
INFO - 2018-11-23 08:01:26 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-23 08:01:26 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/change-password.php
INFO - 2018-11-23 08:01:26 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-23 08:01:26 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/change-password.php
INFO - 2018-11-23 08:01:26 --> Final output sent to browser
DEBUG - 2018-11-23 08:01:26 --> Total execution time: 0.0660
INFO - 2018-11-23 08:02:13 --> Config Class Initialized
INFO - 2018-11-23 08:02:13 --> Hooks Class Initialized
DEBUG - 2018-11-23 08:02:13 --> UTF-8 Support Enabled
INFO - 2018-11-23 08:02:13 --> Utf8 Class Initialized
INFO - 2018-11-23 08:02:13 --> URI Class Initialized
INFO - 2018-11-23 08:02:13 --> Router Class Initialized
INFO - 2018-11-23 08:02:13 --> Output Class Initialized
INFO - 2018-11-23 08:02:13 --> Security Class Initialized
DEBUG - 2018-11-23 08:02:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-23 08:02:13 --> Input Class Initialized
INFO - 2018-11-23 08:02:13 --> Language Class Initialized
INFO - 2018-11-23 08:02:13 --> Loader Class Initialized
INFO - 2018-11-23 08:02:13 --> Helper loaded: url_helper
INFO - 2018-11-23 08:02:13 --> Helper loaded: file_helper
INFO - 2018-11-23 08:02:13 --> Helper loaded: email_helper
INFO - 2018-11-23 08:02:13 --> Helper loaded: common_helper
INFO - 2018-11-23 08:02:13 --> Database Driver Class Initialized
DEBUG - 2018-11-23 08:02:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-23 08:02:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-23 08:02:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-23 08:02:13 --> Pagination Class Initialized
INFO - 2018-11-23 08:02:13 --> Helper loaded: form_helper
INFO - 2018-11-23 08:02:13 --> Form Validation Class Initialized
INFO - 2018-11-23 08:02:13 --> Model Class Initialized
INFO - 2018-11-23 08:02:13 --> Controller Class Initialized
INFO - 2018-11-23 08:02:13 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-23 08:02:13 --> Model Class Initialized
INFO - 2018-11-23 08:02:13 --> Model Class Initialized
INFO - 2018-11-23 08:02:13 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-23 08:02:13 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/change-password.php
INFO - 2018-11-23 08:02:13 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-23 08:02:13 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/change-password.php
INFO - 2018-11-23 08:02:13 --> Final output sent to browser
DEBUG - 2018-11-23 08:02:13 --> Total execution time: 0.0520
INFO - 2018-11-23 08:02:31 --> Config Class Initialized
INFO - 2018-11-23 08:02:31 --> Hooks Class Initialized
DEBUG - 2018-11-23 08:02:31 --> UTF-8 Support Enabled
INFO - 2018-11-23 08:02:31 --> Utf8 Class Initialized
INFO - 2018-11-23 08:02:31 --> URI Class Initialized
INFO - 2018-11-23 08:02:31 --> Router Class Initialized
INFO - 2018-11-23 08:02:31 --> Output Class Initialized
INFO - 2018-11-23 08:02:31 --> Security Class Initialized
DEBUG - 2018-11-23 08:02:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-23 08:02:31 --> Input Class Initialized
INFO - 2018-11-23 08:02:31 --> Language Class Initialized
INFO - 2018-11-23 08:02:31 --> Loader Class Initialized
INFO - 2018-11-23 08:02:31 --> Helper loaded: url_helper
INFO - 2018-11-23 08:02:31 --> Helper loaded: file_helper
INFO - 2018-11-23 08:02:31 --> Helper loaded: email_helper
INFO - 2018-11-23 08:02:31 --> Helper loaded: common_helper
INFO - 2018-11-23 08:02:31 --> Database Driver Class Initialized
DEBUG - 2018-11-23 08:02:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-23 08:02:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-23 08:02:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-23 08:02:31 --> Pagination Class Initialized
INFO - 2018-11-23 08:02:31 --> Helper loaded: form_helper
INFO - 2018-11-23 08:02:31 --> Form Validation Class Initialized
INFO - 2018-11-23 08:02:31 --> Model Class Initialized
INFO - 2018-11-23 08:02:31 --> Controller Class Initialized
INFO - 2018-11-23 08:02:31 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-23 08:02:31 --> Model Class Initialized
INFO - 2018-11-23 08:02:31 --> Model Class Initialized
INFO - 2018-11-23 08:02:31 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-23 08:02:31 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/change-password.php
INFO - 2018-11-23 08:02:31 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-23 08:02:31 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/change-password.php
INFO - 2018-11-23 08:02:31 --> Final output sent to browser
DEBUG - 2018-11-23 08:02:31 --> Total execution time: 0.0580
INFO - 2018-11-23 08:03:38 --> Config Class Initialized
INFO - 2018-11-23 08:03:38 --> Hooks Class Initialized
DEBUG - 2018-11-23 08:03:38 --> UTF-8 Support Enabled
INFO - 2018-11-23 08:03:38 --> Utf8 Class Initialized
INFO - 2018-11-23 08:03:38 --> URI Class Initialized
INFO - 2018-11-23 08:03:38 --> Router Class Initialized
INFO - 2018-11-23 08:03:38 --> Output Class Initialized
INFO - 2018-11-23 08:03:38 --> Security Class Initialized
DEBUG - 2018-11-23 08:03:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-23 08:03:38 --> Input Class Initialized
INFO - 2018-11-23 08:03:38 --> Language Class Initialized
INFO - 2018-11-23 08:03:38 --> Loader Class Initialized
INFO - 2018-11-23 08:03:38 --> Helper loaded: url_helper
INFO - 2018-11-23 08:03:38 --> Helper loaded: file_helper
INFO - 2018-11-23 08:03:38 --> Helper loaded: email_helper
INFO - 2018-11-23 08:03:38 --> Helper loaded: common_helper
INFO - 2018-11-23 08:03:38 --> Database Driver Class Initialized
DEBUG - 2018-11-23 08:03:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-23 08:03:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-23 08:03:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-23 08:03:38 --> Pagination Class Initialized
INFO - 2018-11-23 08:03:38 --> Helper loaded: form_helper
INFO - 2018-11-23 08:03:38 --> Form Validation Class Initialized
INFO - 2018-11-23 08:03:38 --> Model Class Initialized
INFO - 2018-11-23 08:03:38 --> Controller Class Initialized
INFO - 2018-11-23 08:03:38 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-23 08:03:38 --> Model Class Initialized
INFO - 2018-11-23 08:03:38 --> Model Class Initialized
INFO - 2018-11-23 08:03:38 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-23 08:03:38 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/change-password.php
INFO - 2018-11-23 08:03:38 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-23 08:03:38 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/change-password.php
INFO - 2018-11-23 08:03:38 --> Final output sent to browser
DEBUG - 2018-11-23 08:03:38 --> Total execution time: 0.0440
INFO - 2018-11-23 08:04:21 --> Config Class Initialized
INFO - 2018-11-23 08:04:21 --> Hooks Class Initialized
DEBUG - 2018-11-23 08:04:21 --> UTF-8 Support Enabled
INFO - 2018-11-23 08:04:21 --> Utf8 Class Initialized
INFO - 2018-11-23 08:04:21 --> URI Class Initialized
INFO - 2018-11-23 08:04:21 --> Router Class Initialized
INFO - 2018-11-23 08:04:21 --> Output Class Initialized
INFO - 2018-11-23 08:04:21 --> Security Class Initialized
DEBUG - 2018-11-23 08:04:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-23 08:04:21 --> Input Class Initialized
INFO - 2018-11-23 08:04:21 --> Language Class Initialized
INFO - 2018-11-23 08:04:21 --> Loader Class Initialized
INFO - 2018-11-23 08:04:21 --> Helper loaded: url_helper
INFO - 2018-11-23 08:04:21 --> Helper loaded: file_helper
INFO - 2018-11-23 08:04:21 --> Helper loaded: email_helper
INFO - 2018-11-23 08:04:21 --> Helper loaded: common_helper
INFO - 2018-11-23 08:04:21 --> Database Driver Class Initialized
DEBUG - 2018-11-23 08:04:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-23 08:04:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-23 08:04:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-23 08:04:21 --> Pagination Class Initialized
INFO - 2018-11-23 08:04:21 --> Helper loaded: form_helper
INFO - 2018-11-23 08:04:21 --> Form Validation Class Initialized
INFO - 2018-11-23 08:04:21 --> Model Class Initialized
INFO - 2018-11-23 08:04:21 --> Controller Class Initialized
INFO - 2018-11-23 08:04:21 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-23 08:04:21 --> Model Class Initialized
INFO - 2018-11-23 08:04:21 --> Model Class Initialized
INFO - 2018-11-23 08:04:54 --> Config Class Initialized
INFO - 2018-11-23 08:04:54 --> Hooks Class Initialized
DEBUG - 2018-11-23 08:04:54 --> UTF-8 Support Enabled
INFO - 2018-11-23 08:04:54 --> Utf8 Class Initialized
INFO - 2018-11-23 08:04:54 --> URI Class Initialized
INFO - 2018-11-23 08:04:54 --> Router Class Initialized
INFO - 2018-11-23 08:04:54 --> Output Class Initialized
INFO - 2018-11-23 08:04:54 --> Security Class Initialized
DEBUG - 2018-11-23 08:04:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-23 08:04:54 --> Input Class Initialized
INFO - 2018-11-23 08:04:54 --> Language Class Initialized
INFO - 2018-11-23 08:04:54 --> Loader Class Initialized
INFO - 2018-11-23 08:04:54 --> Helper loaded: url_helper
INFO - 2018-11-23 08:04:54 --> Helper loaded: file_helper
INFO - 2018-11-23 08:04:54 --> Helper loaded: email_helper
INFO - 2018-11-23 08:04:54 --> Helper loaded: common_helper
INFO - 2018-11-23 08:04:54 --> Database Driver Class Initialized
DEBUG - 2018-11-23 08:04:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-23 08:04:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-23 08:04:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-23 08:04:54 --> Pagination Class Initialized
INFO - 2018-11-23 08:04:54 --> Helper loaded: form_helper
INFO - 2018-11-23 08:04:54 --> Form Validation Class Initialized
INFO - 2018-11-23 08:04:54 --> Model Class Initialized
INFO - 2018-11-23 08:04:54 --> Controller Class Initialized
INFO - 2018-11-23 08:04:54 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-23 08:04:54 --> Model Class Initialized
INFO - 2018-11-23 08:04:54 --> Model Class Initialized
INFO - 2018-11-23 08:04:54 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-23 08:04:54 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/change-password.php
INFO - 2018-11-23 08:04:54 --> Final output sent to browser
DEBUG - 2018-11-23 08:04:54 --> Total execution time: 0.0646
INFO - 2018-11-23 08:08:50 --> Config Class Initialized
INFO - 2018-11-23 08:08:50 --> Hooks Class Initialized
DEBUG - 2018-11-23 08:08:50 --> UTF-8 Support Enabled
INFO - 2018-11-23 08:08:50 --> Utf8 Class Initialized
INFO - 2018-11-23 08:08:50 --> URI Class Initialized
INFO - 2018-11-23 08:08:50 --> Router Class Initialized
INFO - 2018-11-23 08:08:50 --> Output Class Initialized
INFO - 2018-11-23 08:08:50 --> Security Class Initialized
DEBUG - 2018-11-23 08:08:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-23 08:08:50 --> Input Class Initialized
INFO - 2018-11-23 08:08:50 --> Language Class Initialized
INFO - 2018-11-23 08:08:50 --> Loader Class Initialized
INFO - 2018-11-23 08:08:50 --> Helper loaded: url_helper
INFO - 2018-11-23 08:08:50 --> Helper loaded: file_helper
INFO - 2018-11-23 08:08:50 --> Helper loaded: email_helper
INFO - 2018-11-23 08:08:50 --> Helper loaded: common_helper
INFO - 2018-11-23 08:08:50 --> Database Driver Class Initialized
DEBUG - 2018-11-23 08:08:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-23 08:08:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-23 08:08:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-23 08:08:51 --> Pagination Class Initialized
INFO - 2018-11-23 08:08:51 --> Helper loaded: form_helper
INFO - 2018-11-23 08:08:51 --> Form Validation Class Initialized
INFO - 2018-11-23 08:08:51 --> Model Class Initialized
INFO - 2018-11-23 08:08:51 --> Controller Class Initialized
INFO - 2018-11-23 08:08:51 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-23 08:08:51 --> Model Class Initialized
INFO - 2018-11-23 08:08:51 --> Model Class Initialized
INFO - 2018-11-23 08:08:51 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-23 08:08:51 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/change-password.php
INFO - 2018-11-23 08:08:51 --> Final output sent to browser
DEBUG - 2018-11-23 08:08:51 --> Total execution time: 0.0636
INFO - 2018-11-23 08:09:08 --> Config Class Initialized
INFO - 2018-11-23 08:09:08 --> Hooks Class Initialized
DEBUG - 2018-11-23 08:09:08 --> UTF-8 Support Enabled
INFO - 2018-11-23 08:09:08 --> Utf8 Class Initialized
INFO - 2018-11-23 08:09:08 --> URI Class Initialized
INFO - 2018-11-23 08:09:08 --> Router Class Initialized
INFO - 2018-11-23 08:09:08 --> Output Class Initialized
INFO - 2018-11-23 08:09:08 --> Security Class Initialized
DEBUG - 2018-11-23 08:09:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-23 08:09:08 --> Input Class Initialized
INFO - 2018-11-23 08:09:08 --> Language Class Initialized
INFO - 2018-11-23 08:09:08 --> Loader Class Initialized
INFO - 2018-11-23 08:09:08 --> Helper loaded: url_helper
INFO - 2018-11-23 08:09:08 --> Helper loaded: file_helper
INFO - 2018-11-23 08:09:08 --> Helper loaded: email_helper
INFO - 2018-11-23 08:09:08 --> Helper loaded: common_helper
INFO - 2018-11-23 08:09:08 --> Database Driver Class Initialized
DEBUG - 2018-11-23 08:09:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-23 08:09:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-23 08:09:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-23 08:09:08 --> Pagination Class Initialized
INFO - 2018-11-23 08:09:08 --> Helper loaded: form_helper
INFO - 2018-11-23 08:09:08 --> Form Validation Class Initialized
INFO - 2018-11-23 08:09:08 --> Model Class Initialized
INFO - 2018-11-23 08:09:08 --> Controller Class Initialized
INFO - 2018-11-23 08:09:08 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-23 08:09:08 --> Model Class Initialized
INFO - 2018-11-23 08:09:08 --> Model Class Initialized
INFO - 2018-11-23 08:09:08 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-23 08:09:08 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/change-password.php
INFO - 2018-11-23 08:09:08 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-23 08:09:08 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/change-password.php
INFO - 2018-11-23 08:09:08 --> Final output sent to browser
DEBUG - 2018-11-23 08:09:08 --> Total execution time: 0.0706
INFO - 2018-11-23 08:30:56 --> Config Class Initialized
INFO - 2018-11-23 08:30:56 --> Hooks Class Initialized
DEBUG - 2018-11-23 08:30:56 --> UTF-8 Support Enabled
INFO - 2018-11-23 08:30:56 --> Utf8 Class Initialized
INFO - 2018-11-23 08:30:56 --> URI Class Initialized
INFO - 2018-11-23 08:30:56 --> Router Class Initialized
INFO - 2018-11-23 08:30:56 --> Output Class Initialized
INFO - 2018-11-23 08:30:56 --> Security Class Initialized
DEBUG - 2018-11-23 08:30:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-23 08:30:56 --> Input Class Initialized
INFO - 2018-11-23 08:30:56 --> Language Class Initialized
INFO - 2018-11-23 08:30:56 --> Loader Class Initialized
INFO - 2018-11-23 08:30:56 --> Helper loaded: url_helper
INFO - 2018-11-23 08:30:56 --> Helper loaded: file_helper
INFO - 2018-11-23 08:30:56 --> Helper loaded: email_helper
INFO - 2018-11-23 08:30:56 --> Helper loaded: common_helper
INFO - 2018-11-23 08:30:56 --> Database Driver Class Initialized
DEBUG - 2018-11-23 08:30:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-23 08:30:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-23 08:30:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-23 08:30:56 --> Pagination Class Initialized
INFO - 2018-11-23 08:30:56 --> Helper loaded: form_helper
INFO - 2018-11-23 08:30:56 --> Form Validation Class Initialized
INFO - 2018-11-23 08:30:56 --> Model Class Initialized
INFO - 2018-11-23 08:30:56 --> Controller Class Initialized
INFO - 2018-11-23 08:30:56 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-23 08:30:56 --> Model Class Initialized
INFO - 2018-11-23 08:30:56 --> Model Class Initialized
INFO - 2018-11-23 08:30:56 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-23 08:30:56 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/change-password.php
INFO - 2018-11-23 08:30:56 --> Final output sent to browser
DEBUG - 2018-11-23 08:30:56 --> Total execution time: 0.0490
INFO - 2018-11-23 08:33:05 --> Config Class Initialized
INFO - 2018-11-23 08:33:05 --> Hooks Class Initialized
DEBUG - 2018-11-23 08:33:05 --> UTF-8 Support Enabled
INFO - 2018-11-23 08:33:05 --> Utf8 Class Initialized
INFO - 2018-11-23 08:33:05 --> URI Class Initialized
INFO - 2018-11-23 08:33:05 --> Router Class Initialized
INFO - 2018-11-23 08:33:05 --> Output Class Initialized
INFO - 2018-11-23 08:33:05 --> Security Class Initialized
DEBUG - 2018-11-23 08:33:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-23 08:33:05 --> Input Class Initialized
INFO - 2018-11-23 08:33:05 --> Language Class Initialized
INFO - 2018-11-23 08:33:05 --> Loader Class Initialized
INFO - 2018-11-23 08:33:05 --> Helper loaded: url_helper
INFO - 2018-11-23 08:33:05 --> Helper loaded: file_helper
INFO - 2018-11-23 08:33:05 --> Helper loaded: email_helper
INFO - 2018-11-23 08:33:05 --> Helper loaded: common_helper
INFO - 2018-11-23 08:33:05 --> Database Driver Class Initialized
DEBUG - 2018-11-23 08:33:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-23 08:33:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-23 08:33:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-23 08:33:05 --> Pagination Class Initialized
INFO - 2018-11-23 08:33:05 --> Helper loaded: form_helper
INFO - 2018-11-23 08:33:05 --> Form Validation Class Initialized
INFO - 2018-11-23 08:33:05 --> Model Class Initialized
INFO - 2018-11-23 08:33:05 --> Controller Class Initialized
INFO - 2018-11-23 08:33:05 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-23 08:33:05 --> Model Class Initialized
INFO - 2018-11-23 08:33:05 --> Model Class Initialized
INFO - 2018-11-23 08:33:05 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-23 08:33:05 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/change-password.php
INFO - 2018-11-23 08:33:05 --> Final output sent to browser
DEBUG - 2018-11-23 08:33:05 --> Total execution time: 0.0590
INFO - 2018-11-23 08:33:41 --> Config Class Initialized
INFO - 2018-11-23 08:33:41 --> Hooks Class Initialized
DEBUG - 2018-11-23 08:33:41 --> UTF-8 Support Enabled
INFO - 2018-11-23 08:33:41 --> Utf8 Class Initialized
INFO - 2018-11-23 08:33:41 --> URI Class Initialized
INFO - 2018-11-23 08:33:41 --> Router Class Initialized
INFO - 2018-11-23 08:33:41 --> Output Class Initialized
INFO - 2018-11-23 08:33:41 --> Security Class Initialized
DEBUG - 2018-11-23 08:33:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-23 08:33:41 --> Input Class Initialized
INFO - 2018-11-23 08:33:41 --> Language Class Initialized
INFO - 2018-11-23 08:33:41 --> Loader Class Initialized
INFO - 2018-11-23 08:33:41 --> Helper loaded: url_helper
INFO - 2018-11-23 08:33:41 --> Helper loaded: file_helper
INFO - 2018-11-23 08:33:41 --> Helper loaded: email_helper
INFO - 2018-11-23 08:33:41 --> Helper loaded: common_helper
INFO - 2018-11-23 08:33:41 --> Database Driver Class Initialized
DEBUG - 2018-11-23 08:33:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-23 08:33:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-23 08:33:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-23 08:33:41 --> Pagination Class Initialized
INFO - 2018-11-23 08:33:41 --> Helper loaded: form_helper
INFO - 2018-11-23 08:33:41 --> Form Validation Class Initialized
INFO - 2018-11-23 08:33:41 --> Model Class Initialized
INFO - 2018-11-23 08:33:41 --> Controller Class Initialized
INFO - 2018-11-23 08:33:41 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-23 08:33:41 --> Model Class Initialized
INFO - 2018-11-23 08:33:41 --> Model Class Initialized
INFO - 2018-11-23 08:33:41 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-23 08:33:41 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/change-password.php
INFO - 2018-11-23 08:33:41 --> Final output sent to browser
DEBUG - 2018-11-23 08:33:41 --> Total execution time: 0.0596
INFO - 2018-11-23 08:34:32 --> Config Class Initialized
INFO - 2018-11-23 08:34:32 --> Hooks Class Initialized
DEBUG - 2018-11-23 08:34:32 --> UTF-8 Support Enabled
INFO - 2018-11-23 08:34:32 --> Utf8 Class Initialized
INFO - 2018-11-23 08:34:32 --> URI Class Initialized
INFO - 2018-11-23 08:34:32 --> Router Class Initialized
INFO - 2018-11-23 08:34:32 --> Output Class Initialized
INFO - 2018-11-23 08:34:32 --> Security Class Initialized
DEBUG - 2018-11-23 08:34:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-23 08:34:32 --> Input Class Initialized
INFO - 2018-11-23 08:34:32 --> Language Class Initialized
INFO - 2018-11-23 08:34:32 --> Loader Class Initialized
INFO - 2018-11-23 08:34:32 --> Helper loaded: url_helper
INFO - 2018-11-23 08:34:32 --> Helper loaded: file_helper
INFO - 2018-11-23 08:34:32 --> Helper loaded: email_helper
INFO - 2018-11-23 08:34:32 --> Helper loaded: common_helper
INFO - 2018-11-23 08:34:32 --> Database Driver Class Initialized
DEBUG - 2018-11-23 08:34:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-23 08:34:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-23 08:34:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-23 08:34:32 --> Pagination Class Initialized
INFO - 2018-11-23 08:34:32 --> Helper loaded: form_helper
INFO - 2018-11-23 08:34:32 --> Form Validation Class Initialized
INFO - 2018-11-23 08:34:32 --> Model Class Initialized
INFO - 2018-11-23 08:34:32 --> Controller Class Initialized
INFO - 2018-11-23 08:34:32 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-23 08:34:32 --> Model Class Initialized
INFO - 2018-11-23 08:34:32 --> Model Class Initialized
INFO - 2018-11-23 08:34:32 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-23 08:34:32 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/change-password.php
INFO - 2018-11-23 08:34:32 --> Final output sent to browser
DEBUG - 2018-11-23 08:34:32 --> Total execution time: 0.0596
INFO - 2018-11-23 08:35:04 --> Config Class Initialized
INFO - 2018-11-23 08:35:04 --> Hooks Class Initialized
DEBUG - 2018-11-23 08:35:04 --> UTF-8 Support Enabled
INFO - 2018-11-23 08:35:04 --> Utf8 Class Initialized
INFO - 2018-11-23 08:35:04 --> URI Class Initialized
INFO - 2018-11-23 08:35:04 --> Router Class Initialized
INFO - 2018-11-23 08:35:04 --> Output Class Initialized
INFO - 2018-11-23 08:35:04 --> Security Class Initialized
DEBUG - 2018-11-23 08:35:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-23 08:35:04 --> Input Class Initialized
INFO - 2018-11-23 08:35:04 --> Language Class Initialized
INFO - 2018-11-23 08:35:04 --> Loader Class Initialized
INFO - 2018-11-23 08:35:04 --> Helper loaded: url_helper
INFO - 2018-11-23 08:35:04 --> Helper loaded: file_helper
INFO - 2018-11-23 08:35:04 --> Helper loaded: email_helper
INFO - 2018-11-23 08:35:04 --> Helper loaded: common_helper
INFO - 2018-11-23 08:35:04 --> Database Driver Class Initialized
DEBUG - 2018-11-23 08:35:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-23 08:35:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-23 08:35:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-23 08:35:04 --> Pagination Class Initialized
INFO - 2018-11-23 08:35:04 --> Helper loaded: form_helper
INFO - 2018-11-23 08:35:04 --> Form Validation Class Initialized
INFO - 2018-11-23 08:35:04 --> Model Class Initialized
INFO - 2018-11-23 08:35:04 --> Controller Class Initialized
INFO - 2018-11-23 08:35:04 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-23 08:35:04 --> Model Class Initialized
INFO - 2018-11-23 08:35:04 --> Model Class Initialized
INFO - 2018-11-23 08:35:04 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-23 08:35:04 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/change-password.php
INFO - 2018-11-23 08:35:04 --> Final output sent to browser
DEBUG - 2018-11-23 08:35:04 --> Total execution time: 0.0550
INFO - 2018-11-23 08:36:54 --> Config Class Initialized
INFO - 2018-11-23 08:36:54 --> Hooks Class Initialized
DEBUG - 2018-11-23 08:36:54 --> UTF-8 Support Enabled
INFO - 2018-11-23 08:36:54 --> Utf8 Class Initialized
INFO - 2018-11-23 08:36:54 --> URI Class Initialized
INFO - 2018-11-23 08:36:54 --> Router Class Initialized
INFO - 2018-11-23 08:36:54 --> Output Class Initialized
INFO - 2018-11-23 08:36:54 --> Security Class Initialized
DEBUG - 2018-11-23 08:36:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-23 08:36:54 --> Input Class Initialized
INFO - 2018-11-23 08:36:54 --> Language Class Initialized
INFO - 2018-11-23 08:36:54 --> Loader Class Initialized
INFO - 2018-11-23 08:36:54 --> Helper loaded: url_helper
INFO - 2018-11-23 08:36:54 --> Helper loaded: file_helper
INFO - 2018-11-23 08:36:54 --> Helper loaded: email_helper
INFO - 2018-11-23 08:36:54 --> Helper loaded: common_helper
INFO - 2018-11-23 08:36:54 --> Database Driver Class Initialized
DEBUG - 2018-11-23 08:36:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-23 08:36:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-23 08:36:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-23 08:36:54 --> Pagination Class Initialized
INFO - 2018-11-23 08:36:54 --> Helper loaded: form_helper
INFO - 2018-11-23 08:36:54 --> Form Validation Class Initialized
INFO - 2018-11-23 08:36:54 --> Model Class Initialized
INFO - 2018-11-23 08:36:54 --> Controller Class Initialized
INFO - 2018-11-23 08:36:54 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-23 08:36:54 --> Model Class Initialized
INFO - 2018-11-23 08:36:54 --> Model Class Initialized
INFO - 2018-11-23 08:36:54 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-23 08:36:54 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/change-password.php
INFO - 2018-11-23 08:36:54 --> Final output sent to browser
DEBUG - 2018-11-23 08:36:54 --> Total execution time: 0.0680
INFO - 2018-11-23 08:37:36 --> Config Class Initialized
INFO - 2018-11-23 08:37:36 --> Hooks Class Initialized
DEBUG - 2018-11-23 08:37:36 --> UTF-8 Support Enabled
INFO - 2018-11-23 08:37:36 --> Utf8 Class Initialized
INFO - 2018-11-23 08:37:36 --> URI Class Initialized
INFO - 2018-11-23 08:37:36 --> Router Class Initialized
INFO - 2018-11-23 08:37:36 --> Output Class Initialized
INFO - 2018-11-23 08:37:36 --> Security Class Initialized
DEBUG - 2018-11-23 08:37:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-23 08:37:36 --> Input Class Initialized
INFO - 2018-11-23 08:37:36 --> Language Class Initialized
INFO - 2018-11-23 08:37:36 --> Loader Class Initialized
INFO - 2018-11-23 08:37:36 --> Helper loaded: url_helper
INFO - 2018-11-23 08:37:36 --> Helper loaded: file_helper
INFO - 2018-11-23 08:37:36 --> Helper loaded: email_helper
INFO - 2018-11-23 08:37:36 --> Helper loaded: common_helper
INFO - 2018-11-23 08:37:36 --> Database Driver Class Initialized
DEBUG - 2018-11-23 08:37:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-23 08:37:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-23 08:37:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-23 08:37:37 --> Pagination Class Initialized
INFO - 2018-11-23 08:37:37 --> Helper loaded: form_helper
INFO - 2018-11-23 08:37:37 --> Form Validation Class Initialized
INFO - 2018-11-23 08:37:37 --> Model Class Initialized
INFO - 2018-11-23 08:37:37 --> Controller Class Initialized
INFO - 2018-11-23 08:37:37 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-23 08:37:37 --> Model Class Initialized
INFO - 2018-11-23 08:37:37 --> Model Class Initialized
INFO - 2018-11-23 08:37:37 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-23 08:37:37 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/change-password.php
INFO - 2018-11-23 08:37:37 --> Final output sent to browser
DEBUG - 2018-11-23 08:37:37 --> Total execution time: 0.0580
INFO - 2018-11-23 08:38:58 --> Config Class Initialized
INFO - 2018-11-23 08:38:58 --> Hooks Class Initialized
DEBUG - 2018-11-23 08:38:58 --> UTF-8 Support Enabled
INFO - 2018-11-23 08:38:58 --> Utf8 Class Initialized
INFO - 2018-11-23 08:38:58 --> URI Class Initialized
INFO - 2018-11-23 08:38:58 --> Router Class Initialized
INFO - 2018-11-23 08:38:58 --> Output Class Initialized
INFO - 2018-11-23 08:38:58 --> Security Class Initialized
DEBUG - 2018-11-23 08:38:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-23 08:38:58 --> Input Class Initialized
INFO - 2018-11-23 08:38:58 --> Language Class Initialized
INFO - 2018-11-23 08:38:58 --> Loader Class Initialized
INFO - 2018-11-23 08:38:58 --> Helper loaded: url_helper
INFO - 2018-11-23 08:38:58 --> Helper loaded: file_helper
INFO - 2018-11-23 08:38:58 --> Helper loaded: email_helper
INFO - 2018-11-23 08:38:58 --> Helper loaded: common_helper
INFO - 2018-11-23 08:38:58 --> Database Driver Class Initialized
DEBUG - 2018-11-23 08:38:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-23 08:38:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-23 08:38:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-23 08:38:58 --> Pagination Class Initialized
INFO - 2018-11-23 08:38:58 --> Helper loaded: form_helper
INFO - 2018-11-23 08:38:58 --> Form Validation Class Initialized
INFO - 2018-11-23 08:38:58 --> Model Class Initialized
INFO - 2018-11-23 08:38:58 --> Controller Class Initialized
INFO - 2018-11-23 08:38:58 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-23 08:38:58 --> Model Class Initialized
INFO - 2018-11-23 08:38:58 --> Model Class Initialized
INFO - 2018-11-23 08:38:58 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-23 08:38:58 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/change-password.php
INFO - 2018-11-23 08:38:58 --> Final output sent to browser
DEBUG - 2018-11-23 08:38:58 --> Total execution time: 0.0586
INFO - 2018-11-23 08:40:04 --> Config Class Initialized
INFO - 2018-11-23 08:40:04 --> Hooks Class Initialized
DEBUG - 2018-11-23 08:40:04 --> UTF-8 Support Enabled
INFO - 2018-11-23 08:40:04 --> Utf8 Class Initialized
INFO - 2018-11-23 08:40:04 --> URI Class Initialized
INFO - 2018-11-23 08:40:04 --> Router Class Initialized
INFO - 2018-11-23 08:40:04 --> Output Class Initialized
INFO - 2018-11-23 08:40:04 --> Security Class Initialized
DEBUG - 2018-11-23 08:40:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-23 08:40:04 --> Input Class Initialized
INFO - 2018-11-23 08:40:04 --> Language Class Initialized
INFO - 2018-11-23 08:40:04 --> Loader Class Initialized
INFO - 2018-11-23 08:40:04 --> Helper loaded: url_helper
INFO - 2018-11-23 08:40:04 --> Helper loaded: file_helper
INFO - 2018-11-23 08:40:04 --> Helper loaded: email_helper
INFO - 2018-11-23 08:40:04 --> Helper loaded: common_helper
INFO - 2018-11-23 08:40:04 --> Database Driver Class Initialized
DEBUG - 2018-11-23 08:40:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-23 08:40:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-23 08:40:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-23 08:40:04 --> Pagination Class Initialized
INFO - 2018-11-23 08:40:04 --> Helper loaded: form_helper
INFO - 2018-11-23 08:40:04 --> Form Validation Class Initialized
INFO - 2018-11-23 08:40:04 --> Model Class Initialized
INFO - 2018-11-23 08:40:04 --> Controller Class Initialized
INFO - 2018-11-23 08:40:04 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-23 08:40:04 --> Model Class Initialized
INFO - 2018-11-23 08:40:04 --> Model Class Initialized
INFO - 2018-11-23 08:40:04 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-23 08:40:04 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/change-password.php
INFO - 2018-11-23 08:40:04 --> Final output sent to browser
DEBUG - 2018-11-23 08:40:04 --> Total execution time: 0.0536
INFO - 2018-11-23 08:40:14 --> Config Class Initialized
INFO - 2018-11-23 08:40:14 --> Hooks Class Initialized
DEBUG - 2018-11-23 08:40:14 --> UTF-8 Support Enabled
INFO - 2018-11-23 08:40:14 --> Utf8 Class Initialized
INFO - 2018-11-23 08:40:14 --> URI Class Initialized
INFO - 2018-11-23 08:40:14 --> Router Class Initialized
INFO - 2018-11-23 08:40:14 --> Output Class Initialized
INFO - 2018-11-23 08:40:14 --> Security Class Initialized
DEBUG - 2018-11-23 08:40:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-23 08:40:14 --> Input Class Initialized
INFO - 2018-11-23 08:40:14 --> Language Class Initialized
INFO - 2018-11-23 08:40:14 --> Loader Class Initialized
INFO - 2018-11-23 08:40:14 --> Helper loaded: url_helper
INFO - 2018-11-23 08:40:14 --> Helper loaded: file_helper
INFO - 2018-11-23 08:40:14 --> Helper loaded: email_helper
INFO - 2018-11-23 08:40:14 --> Helper loaded: common_helper
INFO - 2018-11-23 08:40:14 --> Database Driver Class Initialized
DEBUG - 2018-11-23 08:40:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-23 08:40:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-23 08:40:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-23 08:40:14 --> Pagination Class Initialized
INFO - 2018-11-23 08:40:14 --> Helper loaded: form_helper
INFO - 2018-11-23 08:40:14 --> Form Validation Class Initialized
INFO - 2018-11-23 08:40:14 --> Model Class Initialized
INFO - 2018-11-23 08:40:14 --> Controller Class Initialized
INFO - 2018-11-23 08:40:14 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-23 08:40:14 --> Model Class Initialized
INFO - 2018-11-23 08:40:14 --> Model Class Initialized
INFO - 2018-11-23 08:40:14 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-23 08:40:14 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/change-password.php
INFO - 2018-11-23 08:40:14 --> Final output sent to browser
DEBUG - 2018-11-23 08:40:14 --> Total execution time: 0.0620
INFO - 2018-11-23 08:41:19 --> Config Class Initialized
INFO - 2018-11-23 08:41:19 --> Hooks Class Initialized
DEBUG - 2018-11-23 08:41:19 --> UTF-8 Support Enabled
INFO - 2018-11-23 08:41:19 --> Utf8 Class Initialized
INFO - 2018-11-23 08:41:19 --> URI Class Initialized
INFO - 2018-11-23 08:41:19 --> Router Class Initialized
INFO - 2018-11-23 08:41:19 --> Output Class Initialized
INFO - 2018-11-23 08:41:19 --> Security Class Initialized
DEBUG - 2018-11-23 08:41:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-23 08:41:19 --> Input Class Initialized
INFO - 2018-11-23 08:41:19 --> Language Class Initialized
INFO - 2018-11-23 08:41:19 --> Loader Class Initialized
INFO - 2018-11-23 08:41:19 --> Helper loaded: url_helper
INFO - 2018-11-23 08:41:19 --> Helper loaded: file_helper
INFO - 2018-11-23 08:41:19 --> Helper loaded: email_helper
INFO - 2018-11-23 08:41:19 --> Helper loaded: common_helper
INFO - 2018-11-23 08:41:19 --> Database Driver Class Initialized
DEBUG - 2018-11-23 08:41:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-23 08:41:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-23 08:41:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-23 08:41:19 --> Pagination Class Initialized
INFO - 2018-11-23 08:41:19 --> Helper loaded: form_helper
INFO - 2018-11-23 08:41:19 --> Form Validation Class Initialized
INFO - 2018-11-23 08:41:19 --> Model Class Initialized
INFO - 2018-11-23 08:41:19 --> Controller Class Initialized
INFO - 2018-11-23 08:41:19 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-23 08:41:19 --> Model Class Initialized
INFO - 2018-11-23 08:41:19 --> Model Class Initialized
INFO - 2018-11-23 08:41:19 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-23 08:41:19 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/change-password.php
INFO - 2018-11-23 08:41:19 --> Final output sent to browser
DEBUG - 2018-11-23 08:41:19 --> Total execution time: 0.0696
INFO - 2018-11-23 08:41:25 --> Config Class Initialized
INFO - 2018-11-23 08:41:25 --> Hooks Class Initialized
DEBUG - 2018-11-23 08:41:25 --> UTF-8 Support Enabled
INFO - 2018-11-23 08:41:25 --> Utf8 Class Initialized
INFO - 2018-11-23 08:41:25 --> URI Class Initialized
INFO - 2018-11-23 08:41:25 --> Router Class Initialized
INFO - 2018-11-23 08:41:25 --> Output Class Initialized
INFO - 2018-11-23 08:41:25 --> Security Class Initialized
DEBUG - 2018-11-23 08:41:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-23 08:41:25 --> Input Class Initialized
INFO - 2018-11-23 08:41:25 --> Language Class Initialized
INFO - 2018-11-23 08:41:25 --> Loader Class Initialized
INFO - 2018-11-23 08:41:25 --> Helper loaded: url_helper
INFO - 2018-11-23 08:41:25 --> Helper loaded: file_helper
INFO - 2018-11-23 08:41:25 --> Helper loaded: email_helper
INFO - 2018-11-23 08:41:25 --> Helper loaded: common_helper
INFO - 2018-11-23 08:41:25 --> Database Driver Class Initialized
DEBUG - 2018-11-23 08:41:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-23 08:41:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-23 08:41:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-23 08:41:25 --> Pagination Class Initialized
INFO - 2018-11-23 08:41:25 --> Helper loaded: form_helper
INFO - 2018-11-23 08:41:25 --> Form Validation Class Initialized
INFO - 2018-11-23 08:41:25 --> Model Class Initialized
INFO - 2018-11-23 08:41:25 --> Controller Class Initialized
INFO - 2018-11-23 08:41:25 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-23 08:41:25 --> Model Class Initialized
INFO - 2018-11-23 08:41:25 --> Model Class Initialized
INFO - 2018-11-23 08:41:25 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-23 08:41:25 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/change-password.php
INFO - 2018-11-23 08:41:25 --> Final output sent to browser
DEBUG - 2018-11-23 08:41:25 --> Total execution time: 0.0550
INFO - 2018-11-23 08:41:35 --> Config Class Initialized
INFO - 2018-11-23 08:41:35 --> Hooks Class Initialized
DEBUG - 2018-11-23 08:41:35 --> UTF-8 Support Enabled
INFO - 2018-11-23 08:41:35 --> Utf8 Class Initialized
INFO - 2018-11-23 08:41:35 --> URI Class Initialized
INFO - 2018-11-23 08:41:35 --> Router Class Initialized
INFO - 2018-11-23 08:41:35 --> Output Class Initialized
INFO - 2018-11-23 08:41:35 --> Security Class Initialized
DEBUG - 2018-11-23 08:41:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-23 08:41:35 --> Input Class Initialized
INFO - 2018-11-23 08:41:35 --> Language Class Initialized
INFO - 2018-11-23 08:41:35 --> Loader Class Initialized
INFO - 2018-11-23 08:41:35 --> Helper loaded: url_helper
INFO - 2018-11-23 08:41:35 --> Helper loaded: file_helper
INFO - 2018-11-23 08:41:35 --> Helper loaded: email_helper
INFO - 2018-11-23 08:41:35 --> Helper loaded: common_helper
INFO - 2018-11-23 08:41:35 --> Database Driver Class Initialized
DEBUG - 2018-11-23 08:41:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-23 08:41:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-23 08:41:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-23 08:41:35 --> Pagination Class Initialized
INFO - 2018-11-23 08:41:35 --> Helper loaded: form_helper
INFO - 2018-11-23 08:41:35 --> Form Validation Class Initialized
INFO - 2018-11-23 08:41:35 --> Model Class Initialized
INFO - 2018-11-23 08:41:35 --> Controller Class Initialized
INFO - 2018-11-23 08:41:35 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-23 08:41:35 --> Model Class Initialized
INFO - 2018-11-23 08:41:35 --> Model Class Initialized
INFO - 2018-11-23 08:41:49 --> Config Class Initialized
INFO - 2018-11-23 08:41:49 --> Hooks Class Initialized
DEBUG - 2018-11-23 08:41:49 --> UTF-8 Support Enabled
INFO - 2018-11-23 08:41:49 --> Utf8 Class Initialized
INFO - 2018-11-23 08:41:49 --> URI Class Initialized
INFO - 2018-11-23 08:41:49 --> Router Class Initialized
INFO - 2018-11-23 08:41:49 --> Output Class Initialized
INFO - 2018-11-23 08:41:49 --> Security Class Initialized
DEBUG - 2018-11-23 08:41:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-23 08:41:49 --> Input Class Initialized
INFO - 2018-11-23 08:41:49 --> Language Class Initialized
INFO - 2018-11-23 08:41:49 --> Loader Class Initialized
INFO - 2018-11-23 08:41:49 --> Helper loaded: url_helper
INFO - 2018-11-23 08:41:49 --> Helper loaded: file_helper
INFO - 2018-11-23 08:41:49 --> Helper loaded: email_helper
INFO - 2018-11-23 08:41:49 --> Helper loaded: common_helper
INFO - 2018-11-23 08:41:49 --> Database Driver Class Initialized
DEBUG - 2018-11-23 08:41:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-23 08:41:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-23 08:41:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-23 08:41:49 --> Pagination Class Initialized
INFO - 2018-11-23 08:41:49 --> Helper loaded: form_helper
INFO - 2018-11-23 08:41:49 --> Form Validation Class Initialized
INFO - 2018-11-23 08:41:49 --> Model Class Initialized
INFO - 2018-11-23 08:41:49 --> Controller Class Initialized
INFO - 2018-11-23 08:41:49 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-23 08:41:49 --> Model Class Initialized
INFO - 2018-11-23 08:41:49 --> Model Class Initialized
INFO - 2018-11-23 08:41:49 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-23 08:41:49 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/change-password.php
INFO - 2018-11-23 08:41:49 --> Final output sent to browser
DEBUG - 2018-11-23 08:41:49 --> Total execution time: 0.0550
INFO - 2018-11-23 08:41:52 --> Config Class Initialized
INFO - 2018-11-23 08:41:52 --> Hooks Class Initialized
DEBUG - 2018-11-23 08:41:52 --> UTF-8 Support Enabled
INFO - 2018-11-23 08:41:52 --> Utf8 Class Initialized
INFO - 2018-11-23 08:41:52 --> URI Class Initialized
INFO - 2018-11-23 08:41:52 --> Router Class Initialized
INFO - 2018-11-23 08:41:52 --> Output Class Initialized
INFO - 2018-11-23 08:41:52 --> Security Class Initialized
DEBUG - 2018-11-23 08:41:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-23 08:41:52 --> Input Class Initialized
INFO - 2018-11-23 08:41:52 --> Language Class Initialized
INFO - 2018-11-23 08:41:52 --> Loader Class Initialized
INFO - 2018-11-23 08:41:52 --> Helper loaded: url_helper
INFO - 2018-11-23 08:41:52 --> Helper loaded: file_helper
INFO - 2018-11-23 08:41:52 --> Helper loaded: email_helper
INFO - 2018-11-23 08:41:52 --> Helper loaded: common_helper
INFO - 2018-11-23 08:41:52 --> Database Driver Class Initialized
DEBUG - 2018-11-23 08:41:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-23 08:41:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-23 08:41:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-23 08:41:52 --> Pagination Class Initialized
INFO - 2018-11-23 08:41:52 --> Helper loaded: form_helper
INFO - 2018-11-23 08:41:52 --> Form Validation Class Initialized
INFO - 2018-11-23 08:41:52 --> Model Class Initialized
INFO - 2018-11-23 08:41:52 --> Controller Class Initialized
INFO - 2018-11-23 08:41:52 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-23 08:41:52 --> Model Class Initialized
INFO - 2018-11-23 08:41:52 --> Model Class Initialized
INFO - 2018-11-23 08:41:52 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-23 08:41:52 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/change-password.php
INFO - 2018-11-23 08:41:52 --> Final output sent to browser
DEBUG - 2018-11-23 08:41:52 --> Total execution time: 0.0460
INFO - 2018-11-23 08:43:09 --> Config Class Initialized
INFO - 2018-11-23 08:43:09 --> Hooks Class Initialized
DEBUG - 2018-11-23 08:43:09 --> UTF-8 Support Enabled
INFO - 2018-11-23 08:43:09 --> Utf8 Class Initialized
INFO - 2018-11-23 08:43:09 --> URI Class Initialized
INFO - 2018-11-23 08:43:09 --> Router Class Initialized
INFO - 2018-11-23 08:43:09 --> Output Class Initialized
INFO - 2018-11-23 08:43:09 --> Security Class Initialized
DEBUG - 2018-11-23 08:43:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-23 08:43:09 --> Input Class Initialized
INFO - 2018-11-23 08:43:09 --> Language Class Initialized
INFO - 2018-11-23 08:43:09 --> Loader Class Initialized
INFO - 2018-11-23 08:43:09 --> Helper loaded: url_helper
INFO - 2018-11-23 08:43:09 --> Helper loaded: file_helper
INFO - 2018-11-23 08:43:09 --> Helper loaded: email_helper
INFO - 2018-11-23 08:43:09 --> Helper loaded: common_helper
INFO - 2018-11-23 08:43:09 --> Database Driver Class Initialized
DEBUG - 2018-11-23 08:43:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-23 08:43:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-23 08:43:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-23 08:43:09 --> Pagination Class Initialized
INFO - 2018-11-23 08:43:09 --> Helper loaded: form_helper
INFO - 2018-11-23 08:43:09 --> Form Validation Class Initialized
INFO - 2018-11-23 08:43:09 --> Model Class Initialized
INFO - 2018-11-23 08:43:09 --> Controller Class Initialized
INFO - 2018-11-23 08:43:09 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-23 08:43:09 --> Model Class Initialized
INFO - 2018-11-23 08:43:09 --> Model Class Initialized
INFO - 2018-11-23 08:43:09 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-23 08:43:09 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/change-password.php
INFO - 2018-11-23 08:43:09 --> Final output sent to browser
DEBUG - 2018-11-23 08:43:09 --> Total execution time: 0.0696
INFO - 2018-11-23 08:43:09 --> Config Class Initialized
INFO - 2018-11-23 08:43:09 --> Hooks Class Initialized
DEBUG - 2018-11-23 08:43:09 --> UTF-8 Support Enabled
INFO - 2018-11-23 08:43:09 --> Utf8 Class Initialized
INFO - 2018-11-23 08:43:09 --> URI Class Initialized
INFO - 2018-11-23 08:43:09 --> Router Class Initialized
INFO - 2018-11-23 08:43:09 --> Output Class Initialized
INFO - 2018-11-23 08:43:09 --> Security Class Initialized
DEBUG - 2018-11-23 08:43:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-23 08:43:09 --> Input Class Initialized
INFO - 2018-11-23 08:43:09 --> Language Class Initialized
INFO - 2018-11-23 08:43:09 --> Loader Class Initialized
INFO - 2018-11-23 08:43:09 --> Helper loaded: url_helper
INFO - 2018-11-23 08:43:09 --> Helper loaded: file_helper
INFO - 2018-11-23 08:43:09 --> Helper loaded: email_helper
INFO - 2018-11-23 08:43:09 --> Helper loaded: common_helper
INFO - 2018-11-23 08:43:09 --> Database Driver Class Initialized
DEBUG - 2018-11-23 08:43:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-23 08:43:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-23 08:43:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-23 08:43:09 --> Pagination Class Initialized
INFO - 2018-11-23 08:43:09 --> Helper loaded: form_helper
INFO - 2018-11-23 08:43:09 --> Form Validation Class Initialized
INFO - 2018-11-23 08:43:09 --> Model Class Initialized
INFO - 2018-11-23 08:43:09 --> Controller Class Initialized
INFO - 2018-11-23 08:43:09 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-23 08:43:09 --> Model Class Initialized
INFO - 2018-11-23 08:43:09 --> Model Class Initialized
INFO - 2018-11-23 08:43:09 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-23 08:43:09 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/change-password.php
INFO - 2018-11-23 08:43:09 --> Final output sent to browser
DEBUG - 2018-11-23 08:43:09 --> Total execution time: 0.0630
INFO - 2018-11-23 08:44:36 --> Config Class Initialized
INFO - 2018-11-23 08:44:36 --> Hooks Class Initialized
DEBUG - 2018-11-23 08:44:36 --> UTF-8 Support Enabled
INFO - 2018-11-23 08:44:36 --> Utf8 Class Initialized
INFO - 2018-11-23 08:44:36 --> URI Class Initialized
INFO - 2018-11-23 08:44:36 --> Router Class Initialized
INFO - 2018-11-23 08:44:36 --> Output Class Initialized
INFO - 2018-11-23 08:44:36 --> Security Class Initialized
DEBUG - 2018-11-23 08:44:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-23 08:44:36 --> Input Class Initialized
INFO - 2018-11-23 08:44:36 --> Language Class Initialized
INFO - 2018-11-23 08:44:36 --> Loader Class Initialized
INFO - 2018-11-23 08:44:36 --> Helper loaded: url_helper
INFO - 2018-11-23 08:44:36 --> Helper loaded: file_helper
INFO - 2018-11-23 08:44:36 --> Helper loaded: email_helper
INFO - 2018-11-23 08:44:36 --> Helper loaded: common_helper
INFO - 2018-11-23 08:44:36 --> Database Driver Class Initialized
DEBUG - 2018-11-23 08:44:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-23 08:44:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-23 08:44:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-23 08:44:36 --> Pagination Class Initialized
INFO - 2018-11-23 08:44:36 --> Helper loaded: form_helper
INFO - 2018-11-23 08:44:36 --> Form Validation Class Initialized
INFO - 2018-11-23 08:44:36 --> Model Class Initialized
INFO - 2018-11-23 08:44:36 --> Controller Class Initialized
INFO - 2018-11-23 08:44:36 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-23 08:44:36 --> Model Class Initialized
INFO - 2018-11-23 08:44:36 --> Model Class Initialized
INFO - 2018-11-23 08:44:36 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-23 08:44:36 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/change-password.php
INFO - 2018-11-23 08:44:36 --> Final output sent to browser
DEBUG - 2018-11-23 08:44:36 --> Total execution time: 0.0450
INFO - 2018-11-23 08:45:34 --> Config Class Initialized
INFO - 2018-11-23 08:45:34 --> Hooks Class Initialized
DEBUG - 2018-11-23 08:45:34 --> UTF-8 Support Enabled
INFO - 2018-11-23 08:45:34 --> Utf8 Class Initialized
INFO - 2018-11-23 08:45:34 --> URI Class Initialized
INFO - 2018-11-23 08:45:34 --> Router Class Initialized
INFO - 2018-11-23 08:45:34 --> Output Class Initialized
INFO - 2018-11-23 08:45:34 --> Security Class Initialized
DEBUG - 2018-11-23 08:45:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-23 08:45:34 --> Input Class Initialized
INFO - 2018-11-23 08:45:34 --> Language Class Initialized
INFO - 2018-11-23 08:45:34 --> Loader Class Initialized
INFO - 2018-11-23 08:45:34 --> Helper loaded: url_helper
INFO - 2018-11-23 08:45:34 --> Helper loaded: file_helper
INFO - 2018-11-23 08:45:34 --> Helper loaded: email_helper
INFO - 2018-11-23 08:45:34 --> Helper loaded: common_helper
INFO - 2018-11-23 08:45:34 --> Database Driver Class Initialized
DEBUG - 2018-11-23 08:45:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-23 08:45:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-23 08:45:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-23 08:45:34 --> Pagination Class Initialized
INFO - 2018-11-23 08:45:34 --> Helper loaded: form_helper
INFO - 2018-11-23 08:45:34 --> Form Validation Class Initialized
INFO - 2018-11-23 08:45:34 --> Model Class Initialized
INFO - 2018-11-23 08:45:34 --> Controller Class Initialized
INFO - 2018-11-23 08:45:34 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-23 08:45:34 --> Model Class Initialized
INFO - 2018-11-23 08:45:34 --> Model Class Initialized
INFO - 2018-11-23 08:45:34 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-23 08:45:34 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/change-password.php
INFO - 2018-11-23 08:45:34 --> Final output sent to browser
DEBUG - 2018-11-23 08:45:34 --> Total execution time: 0.0460
INFO - 2018-11-23 08:45:55 --> Config Class Initialized
INFO - 2018-11-23 08:45:55 --> Hooks Class Initialized
DEBUG - 2018-11-23 08:45:55 --> UTF-8 Support Enabled
INFO - 2018-11-23 08:45:55 --> Utf8 Class Initialized
INFO - 2018-11-23 08:45:55 --> URI Class Initialized
INFO - 2018-11-23 08:45:55 --> Router Class Initialized
INFO - 2018-11-23 08:45:55 --> Output Class Initialized
INFO - 2018-11-23 08:45:55 --> Security Class Initialized
DEBUG - 2018-11-23 08:45:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-23 08:45:55 --> Input Class Initialized
INFO - 2018-11-23 08:45:55 --> Language Class Initialized
INFO - 2018-11-23 08:45:55 --> Loader Class Initialized
INFO - 2018-11-23 08:45:55 --> Helper loaded: url_helper
INFO - 2018-11-23 08:45:55 --> Helper loaded: file_helper
INFO - 2018-11-23 08:45:55 --> Helper loaded: email_helper
INFO - 2018-11-23 08:45:55 --> Helper loaded: common_helper
INFO - 2018-11-23 08:45:55 --> Database Driver Class Initialized
DEBUG - 2018-11-23 08:45:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-23 08:45:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-23 08:45:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-23 08:45:55 --> Pagination Class Initialized
INFO - 2018-11-23 08:45:55 --> Helper loaded: form_helper
INFO - 2018-11-23 08:45:55 --> Form Validation Class Initialized
INFO - 2018-11-23 08:45:55 --> Model Class Initialized
INFO - 2018-11-23 08:45:55 --> Controller Class Initialized
INFO - 2018-11-23 08:45:55 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-23 08:45:55 --> Model Class Initialized
INFO - 2018-11-23 08:45:55 --> Model Class Initialized
INFO - 2018-11-23 08:45:55 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-23 08:45:55 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/change-password.php
INFO - 2018-11-23 08:45:55 --> Final output sent to browser
DEBUG - 2018-11-23 08:45:55 --> Total execution time: 0.0430
INFO - 2018-11-23 08:46:37 --> Config Class Initialized
INFO - 2018-11-23 08:46:37 --> Hooks Class Initialized
DEBUG - 2018-11-23 08:46:37 --> UTF-8 Support Enabled
INFO - 2018-11-23 08:46:37 --> Utf8 Class Initialized
INFO - 2018-11-23 08:46:37 --> URI Class Initialized
INFO - 2018-11-23 08:46:37 --> Router Class Initialized
INFO - 2018-11-23 08:46:37 --> Output Class Initialized
INFO - 2018-11-23 08:46:37 --> Security Class Initialized
DEBUG - 2018-11-23 08:46:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-23 08:46:37 --> Input Class Initialized
INFO - 2018-11-23 08:46:37 --> Language Class Initialized
INFO - 2018-11-23 08:46:37 --> Loader Class Initialized
INFO - 2018-11-23 08:46:37 --> Helper loaded: url_helper
INFO - 2018-11-23 08:46:37 --> Helper loaded: file_helper
INFO - 2018-11-23 08:46:37 --> Helper loaded: email_helper
INFO - 2018-11-23 08:46:37 --> Helper loaded: common_helper
INFO - 2018-11-23 08:46:37 --> Database Driver Class Initialized
DEBUG - 2018-11-23 08:46:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-23 08:46:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-23 08:46:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-23 08:46:37 --> Pagination Class Initialized
INFO - 2018-11-23 08:46:37 --> Helper loaded: form_helper
INFO - 2018-11-23 08:46:37 --> Form Validation Class Initialized
INFO - 2018-11-23 08:46:37 --> Model Class Initialized
INFO - 2018-11-23 08:46:37 --> Controller Class Initialized
INFO - 2018-11-23 08:46:37 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-23 08:46:37 --> Model Class Initialized
INFO - 2018-11-23 08:46:37 --> Model Class Initialized
INFO - 2018-11-23 08:46:37 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-23 08:46:37 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/change-password.php
INFO - 2018-11-23 08:46:37 --> Final output sent to browser
DEBUG - 2018-11-23 08:46:37 --> Total execution time: 0.0656
INFO - 2018-11-23 08:50:01 --> Config Class Initialized
INFO - 2018-11-23 08:50:01 --> Hooks Class Initialized
DEBUG - 2018-11-23 08:50:01 --> UTF-8 Support Enabled
INFO - 2018-11-23 08:50:01 --> Utf8 Class Initialized
INFO - 2018-11-23 08:50:01 --> URI Class Initialized
INFO - 2018-11-23 08:50:01 --> Router Class Initialized
INFO - 2018-11-23 08:50:01 --> Output Class Initialized
INFO - 2018-11-23 08:50:01 --> Security Class Initialized
DEBUG - 2018-11-23 08:50:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-23 08:50:01 --> Input Class Initialized
INFO - 2018-11-23 08:50:01 --> Language Class Initialized
INFO - 2018-11-23 08:50:01 --> Loader Class Initialized
INFO - 2018-11-23 08:50:01 --> Helper loaded: url_helper
INFO - 2018-11-23 08:50:01 --> Helper loaded: file_helper
INFO - 2018-11-23 08:50:01 --> Helper loaded: email_helper
INFO - 2018-11-23 08:50:01 --> Helper loaded: common_helper
INFO - 2018-11-23 08:50:01 --> Database Driver Class Initialized
DEBUG - 2018-11-23 08:50:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-23 08:50:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-23 08:50:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-23 08:50:01 --> Pagination Class Initialized
INFO - 2018-11-23 08:50:01 --> Helper loaded: form_helper
INFO - 2018-11-23 08:50:01 --> Form Validation Class Initialized
INFO - 2018-11-23 08:50:01 --> Model Class Initialized
INFO - 2018-11-23 08:50:01 --> Controller Class Initialized
INFO - 2018-11-23 08:50:01 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-23 08:50:01 --> Model Class Initialized
INFO - 2018-11-23 08:50:01 --> Model Class Initialized
INFO - 2018-11-23 08:50:01 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-23 08:50:01 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/change-password.php
INFO - 2018-11-23 08:50:01 --> Final output sent to browser
DEBUG - 2018-11-23 08:50:01 --> Total execution time: 0.1010
INFO - 2018-11-23 08:53:15 --> Config Class Initialized
INFO - 2018-11-23 08:53:15 --> Hooks Class Initialized
DEBUG - 2018-11-23 08:53:15 --> UTF-8 Support Enabled
INFO - 2018-11-23 08:53:15 --> Utf8 Class Initialized
INFO - 2018-11-23 08:53:15 --> URI Class Initialized
INFO - 2018-11-23 08:53:15 --> Router Class Initialized
INFO - 2018-11-23 08:53:15 --> Output Class Initialized
INFO - 2018-11-23 08:53:15 --> Security Class Initialized
DEBUG - 2018-11-23 08:53:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-23 08:53:15 --> Input Class Initialized
INFO - 2018-11-23 08:53:15 --> Language Class Initialized
INFO - 2018-11-23 08:53:15 --> Loader Class Initialized
INFO - 2018-11-23 08:53:15 --> Helper loaded: url_helper
INFO - 2018-11-23 08:53:15 --> Helper loaded: file_helper
INFO - 2018-11-23 08:53:15 --> Helper loaded: email_helper
INFO - 2018-11-23 08:53:15 --> Helper loaded: common_helper
INFO - 2018-11-23 08:53:15 --> Database Driver Class Initialized
DEBUG - 2018-11-23 08:53:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-23 08:53:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-23 08:53:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-23 08:53:15 --> Pagination Class Initialized
INFO - 2018-11-23 08:53:15 --> Helper loaded: form_helper
INFO - 2018-11-23 08:53:15 --> Form Validation Class Initialized
INFO - 2018-11-23 08:53:15 --> Model Class Initialized
INFO - 2018-11-23 08:53:15 --> Controller Class Initialized
INFO - 2018-11-23 08:53:15 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-23 08:53:15 --> Model Class Initialized
INFO - 2018-11-23 08:53:15 --> Model Class Initialized
INFO - 2018-11-23 08:53:15 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-23 08:53:15 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/change-password.php
INFO - 2018-11-23 08:53:15 --> Final output sent to browser
DEBUG - 2018-11-23 08:53:15 --> Total execution time: 0.0580
INFO - 2018-11-23 08:54:29 --> Config Class Initialized
INFO - 2018-11-23 08:54:29 --> Hooks Class Initialized
DEBUG - 2018-11-23 08:54:29 --> UTF-8 Support Enabled
INFO - 2018-11-23 08:54:29 --> Utf8 Class Initialized
INFO - 2018-11-23 08:54:29 --> URI Class Initialized
INFO - 2018-11-23 08:54:29 --> Router Class Initialized
INFO - 2018-11-23 08:54:29 --> Output Class Initialized
INFO - 2018-11-23 08:54:29 --> Security Class Initialized
DEBUG - 2018-11-23 08:54:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-23 08:54:29 --> Input Class Initialized
INFO - 2018-11-23 08:54:29 --> Language Class Initialized
INFO - 2018-11-23 08:54:29 --> Loader Class Initialized
INFO - 2018-11-23 08:54:29 --> Helper loaded: url_helper
INFO - 2018-11-23 08:54:29 --> Helper loaded: file_helper
INFO - 2018-11-23 08:54:29 --> Helper loaded: email_helper
INFO - 2018-11-23 08:54:29 --> Helper loaded: common_helper
INFO - 2018-11-23 08:54:29 --> Database Driver Class Initialized
DEBUG - 2018-11-23 08:54:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-23 08:54:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-23 08:54:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-23 08:54:29 --> Pagination Class Initialized
INFO - 2018-11-23 08:54:29 --> Helper loaded: form_helper
INFO - 2018-11-23 08:54:29 --> Form Validation Class Initialized
INFO - 2018-11-23 08:54:29 --> Model Class Initialized
INFO - 2018-11-23 08:54:29 --> Controller Class Initialized
INFO - 2018-11-23 08:54:29 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-23 08:54:29 --> Model Class Initialized
INFO - 2018-11-23 08:54:29 --> Model Class Initialized
INFO - 2018-11-23 08:54:29 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-23 08:54:29 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/change-password.php
INFO - 2018-11-23 08:54:29 --> Final output sent to browser
DEBUG - 2018-11-23 08:54:29 --> Total execution time: 0.0550
INFO - 2018-11-23 08:55:57 --> Config Class Initialized
INFO - 2018-11-23 08:55:57 --> Hooks Class Initialized
DEBUG - 2018-11-23 08:55:57 --> UTF-8 Support Enabled
INFO - 2018-11-23 08:55:57 --> Utf8 Class Initialized
INFO - 2018-11-23 08:55:57 --> URI Class Initialized
INFO - 2018-11-23 08:55:57 --> Router Class Initialized
INFO - 2018-11-23 08:55:57 --> Output Class Initialized
INFO - 2018-11-23 08:55:57 --> Security Class Initialized
DEBUG - 2018-11-23 08:55:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-23 08:55:57 --> Input Class Initialized
INFO - 2018-11-23 08:55:57 --> Language Class Initialized
INFO - 2018-11-23 08:55:57 --> Loader Class Initialized
INFO - 2018-11-23 08:55:57 --> Helper loaded: url_helper
INFO - 2018-11-23 08:55:57 --> Helper loaded: file_helper
INFO - 2018-11-23 08:55:57 --> Helper loaded: email_helper
INFO - 2018-11-23 08:55:57 --> Helper loaded: common_helper
INFO - 2018-11-23 08:55:57 --> Database Driver Class Initialized
DEBUG - 2018-11-23 08:55:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-23 08:55:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-23 08:55:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-23 08:55:57 --> Pagination Class Initialized
INFO - 2018-11-23 08:55:57 --> Helper loaded: form_helper
INFO - 2018-11-23 08:55:57 --> Form Validation Class Initialized
INFO - 2018-11-23 08:55:57 --> Model Class Initialized
INFO - 2018-11-23 08:55:57 --> Controller Class Initialized
INFO - 2018-11-23 08:55:57 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-23 08:55:57 --> Model Class Initialized
INFO - 2018-11-23 08:55:57 --> Model Class Initialized
INFO - 2018-11-23 08:55:57 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-23 08:55:57 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/change-password.php
INFO - 2018-11-23 08:55:57 --> Final output sent to browser
DEBUG - 2018-11-23 08:55:57 --> Total execution time: 0.0530
INFO - 2018-11-23 08:58:49 --> Config Class Initialized
INFO - 2018-11-23 08:58:49 --> Hooks Class Initialized
DEBUG - 2018-11-23 08:58:49 --> UTF-8 Support Enabled
INFO - 2018-11-23 08:58:49 --> Utf8 Class Initialized
INFO - 2018-11-23 08:58:49 --> URI Class Initialized
INFO - 2018-11-23 08:58:49 --> Router Class Initialized
INFO - 2018-11-23 08:58:49 --> Output Class Initialized
INFO - 2018-11-23 08:58:49 --> Security Class Initialized
DEBUG - 2018-11-23 08:58:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-23 08:58:49 --> Input Class Initialized
INFO - 2018-11-23 08:58:49 --> Language Class Initialized
INFO - 2018-11-23 08:58:49 --> Loader Class Initialized
INFO - 2018-11-23 08:58:49 --> Helper loaded: url_helper
INFO - 2018-11-23 08:58:49 --> Helper loaded: file_helper
INFO - 2018-11-23 08:58:49 --> Helper loaded: email_helper
INFO - 2018-11-23 08:58:49 --> Helper loaded: common_helper
INFO - 2018-11-23 08:58:49 --> Database Driver Class Initialized
DEBUG - 2018-11-23 08:58:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-23 08:58:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-23 08:58:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-23 08:58:49 --> Pagination Class Initialized
INFO - 2018-11-23 08:58:49 --> Helper loaded: form_helper
INFO - 2018-11-23 08:58:49 --> Form Validation Class Initialized
INFO - 2018-11-23 08:58:49 --> Model Class Initialized
INFO - 2018-11-23 08:58:49 --> Controller Class Initialized
INFO - 2018-11-23 08:58:49 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-23 08:58:49 --> Model Class Initialized
INFO - 2018-11-23 08:58:49 --> Model Class Initialized
INFO - 2018-11-23 08:58:49 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-23 08:58:49 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/change-password.php
INFO - 2018-11-23 08:58:49 --> Final output sent to browser
DEBUG - 2018-11-23 08:58:49 --> Total execution time: 0.0610
INFO - 2018-11-23 08:59:46 --> Config Class Initialized
INFO - 2018-11-23 08:59:46 --> Hooks Class Initialized
DEBUG - 2018-11-23 08:59:46 --> UTF-8 Support Enabled
INFO - 2018-11-23 08:59:46 --> Utf8 Class Initialized
INFO - 2018-11-23 08:59:46 --> URI Class Initialized
INFO - 2018-11-23 08:59:46 --> Router Class Initialized
INFO - 2018-11-23 08:59:46 --> Output Class Initialized
INFO - 2018-11-23 08:59:46 --> Security Class Initialized
DEBUG - 2018-11-23 08:59:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-23 08:59:46 --> Input Class Initialized
INFO - 2018-11-23 08:59:46 --> Language Class Initialized
INFO - 2018-11-23 08:59:46 --> Loader Class Initialized
INFO - 2018-11-23 08:59:46 --> Helper loaded: url_helper
INFO - 2018-11-23 08:59:46 --> Helper loaded: file_helper
INFO - 2018-11-23 08:59:46 --> Helper loaded: email_helper
INFO - 2018-11-23 08:59:46 --> Helper loaded: common_helper
INFO - 2018-11-23 08:59:46 --> Database Driver Class Initialized
DEBUG - 2018-11-23 08:59:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-23 08:59:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-23 08:59:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-23 08:59:46 --> Pagination Class Initialized
INFO - 2018-11-23 08:59:46 --> Helper loaded: form_helper
INFO - 2018-11-23 08:59:46 --> Form Validation Class Initialized
INFO - 2018-11-23 08:59:46 --> Model Class Initialized
INFO - 2018-11-23 08:59:46 --> Controller Class Initialized
INFO - 2018-11-23 08:59:46 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-23 08:59:46 --> Model Class Initialized
INFO - 2018-11-23 08:59:46 --> Model Class Initialized
INFO - 2018-11-23 08:59:46 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-23 08:59:46 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/change-password.php
INFO - 2018-11-23 08:59:46 --> Final output sent to browser
DEBUG - 2018-11-23 08:59:46 --> Total execution time: 0.0500
INFO - 2018-11-23 09:00:10 --> Config Class Initialized
INFO - 2018-11-23 09:00:10 --> Hooks Class Initialized
DEBUG - 2018-11-23 09:00:10 --> UTF-8 Support Enabled
INFO - 2018-11-23 09:00:10 --> Utf8 Class Initialized
INFO - 2018-11-23 09:00:10 --> URI Class Initialized
INFO - 2018-11-23 09:00:10 --> Router Class Initialized
INFO - 2018-11-23 09:00:10 --> Output Class Initialized
INFO - 2018-11-23 09:00:10 --> Security Class Initialized
DEBUG - 2018-11-23 09:00:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-23 09:00:10 --> Input Class Initialized
INFO - 2018-11-23 09:00:10 --> Language Class Initialized
INFO - 2018-11-23 09:00:10 --> Loader Class Initialized
INFO - 2018-11-23 09:00:10 --> Helper loaded: url_helper
INFO - 2018-11-23 09:00:10 --> Helper loaded: file_helper
INFO - 2018-11-23 09:00:10 --> Helper loaded: email_helper
INFO - 2018-11-23 09:00:10 --> Helper loaded: common_helper
INFO - 2018-11-23 09:00:10 --> Database Driver Class Initialized
DEBUG - 2018-11-23 09:00:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-23 09:00:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-23 09:00:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-23 09:00:10 --> Pagination Class Initialized
INFO - 2018-11-23 09:00:10 --> Helper loaded: form_helper
INFO - 2018-11-23 09:00:10 --> Form Validation Class Initialized
INFO - 2018-11-23 09:00:10 --> Model Class Initialized
INFO - 2018-11-23 09:00:10 --> Controller Class Initialized
INFO - 2018-11-23 09:00:10 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-23 09:00:10 --> Model Class Initialized
INFO - 2018-11-23 09:00:10 --> Model Class Initialized
INFO - 2018-11-23 09:00:10 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-23 09:00:10 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/change-password.php
INFO - 2018-11-23 09:00:10 --> Final output sent to browser
DEBUG - 2018-11-23 09:00:10 --> Total execution time: 0.0530
INFO - 2018-11-23 09:00:49 --> Config Class Initialized
INFO - 2018-11-23 09:00:49 --> Hooks Class Initialized
DEBUG - 2018-11-23 09:00:49 --> UTF-8 Support Enabled
INFO - 2018-11-23 09:00:49 --> Utf8 Class Initialized
INFO - 2018-11-23 09:00:49 --> URI Class Initialized
INFO - 2018-11-23 09:00:49 --> Router Class Initialized
INFO - 2018-11-23 09:00:49 --> Output Class Initialized
INFO - 2018-11-23 09:00:49 --> Security Class Initialized
DEBUG - 2018-11-23 09:00:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-23 09:00:49 --> Input Class Initialized
INFO - 2018-11-23 09:00:49 --> Language Class Initialized
INFO - 2018-11-23 09:00:49 --> Loader Class Initialized
INFO - 2018-11-23 09:00:49 --> Helper loaded: url_helper
INFO - 2018-11-23 09:00:49 --> Helper loaded: file_helper
INFO - 2018-11-23 09:00:49 --> Helper loaded: email_helper
INFO - 2018-11-23 09:00:49 --> Helper loaded: common_helper
INFO - 2018-11-23 09:00:49 --> Database Driver Class Initialized
DEBUG - 2018-11-23 09:00:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-23 09:00:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-23 09:00:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-23 09:00:49 --> Pagination Class Initialized
INFO - 2018-11-23 09:00:49 --> Helper loaded: form_helper
INFO - 2018-11-23 09:00:49 --> Form Validation Class Initialized
INFO - 2018-11-23 09:00:49 --> Model Class Initialized
INFO - 2018-11-23 09:00:49 --> Controller Class Initialized
INFO - 2018-11-23 09:00:49 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-23 09:00:49 --> Model Class Initialized
INFO - 2018-11-23 09:00:49 --> Model Class Initialized
INFO - 2018-11-23 09:00:49 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-23 09:00:49 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/change-password.php
INFO - 2018-11-23 09:00:49 --> Final output sent to browser
DEBUG - 2018-11-23 09:00:49 --> Total execution time: 0.0570
INFO - 2018-11-23 09:01:23 --> Config Class Initialized
INFO - 2018-11-23 09:01:23 --> Hooks Class Initialized
DEBUG - 2018-11-23 09:01:23 --> UTF-8 Support Enabled
INFO - 2018-11-23 09:01:23 --> Utf8 Class Initialized
INFO - 2018-11-23 09:01:23 --> URI Class Initialized
INFO - 2018-11-23 09:01:23 --> Router Class Initialized
INFO - 2018-11-23 09:01:23 --> Output Class Initialized
INFO - 2018-11-23 09:01:23 --> Security Class Initialized
DEBUG - 2018-11-23 09:01:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-23 09:01:23 --> Input Class Initialized
INFO - 2018-11-23 09:01:23 --> Language Class Initialized
INFO - 2018-11-23 09:01:23 --> Loader Class Initialized
INFO - 2018-11-23 09:01:23 --> Helper loaded: url_helper
INFO - 2018-11-23 09:01:23 --> Helper loaded: file_helper
INFO - 2018-11-23 09:01:23 --> Helper loaded: email_helper
INFO - 2018-11-23 09:01:23 --> Helper loaded: common_helper
INFO - 2018-11-23 09:01:23 --> Database Driver Class Initialized
DEBUG - 2018-11-23 09:01:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-23 09:01:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-23 09:01:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-23 09:01:23 --> Pagination Class Initialized
INFO - 2018-11-23 09:01:23 --> Helper loaded: form_helper
INFO - 2018-11-23 09:01:23 --> Form Validation Class Initialized
INFO - 2018-11-23 09:01:23 --> Model Class Initialized
INFO - 2018-11-23 09:01:23 --> Controller Class Initialized
INFO - 2018-11-23 09:01:23 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-23 09:01:23 --> Model Class Initialized
INFO - 2018-11-23 09:01:23 --> Model Class Initialized
INFO - 2018-11-23 09:01:23 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-23 09:01:23 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/change-password.php
INFO - 2018-11-23 09:01:23 --> Final output sent to browser
DEBUG - 2018-11-23 09:01:23 --> Total execution time: 0.0620
INFO - 2018-11-23 09:01:32 --> Config Class Initialized
INFO - 2018-11-23 09:01:32 --> Hooks Class Initialized
DEBUG - 2018-11-23 09:01:32 --> UTF-8 Support Enabled
INFO - 2018-11-23 09:01:32 --> Utf8 Class Initialized
INFO - 2018-11-23 09:01:32 --> URI Class Initialized
INFO - 2018-11-23 09:01:32 --> Router Class Initialized
INFO - 2018-11-23 09:01:32 --> Output Class Initialized
INFO - 2018-11-23 09:01:32 --> Security Class Initialized
DEBUG - 2018-11-23 09:01:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-23 09:01:32 --> Input Class Initialized
INFO - 2018-11-23 09:01:32 --> Language Class Initialized
INFO - 2018-11-23 09:01:32 --> Loader Class Initialized
INFO - 2018-11-23 09:01:32 --> Helper loaded: url_helper
INFO - 2018-11-23 09:01:32 --> Helper loaded: file_helper
INFO - 2018-11-23 09:01:32 --> Helper loaded: email_helper
INFO - 2018-11-23 09:01:32 --> Helper loaded: common_helper
INFO - 2018-11-23 09:01:32 --> Database Driver Class Initialized
DEBUG - 2018-11-23 09:01:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-23 09:01:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-23 09:01:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-23 09:01:32 --> Pagination Class Initialized
INFO - 2018-11-23 09:01:32 --> Helper loaded: form_helper
INFO - 2018-11-23 09:01:32 --> Form Validation Class Initialized
INFO - 2018-11-23 09:01:32 --> Model Class Initialized
INFO - 2018-11-23 09:01:32 --> Controller Class Initialized
INFO - 2018-11-23 09:01:32 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-23 09:01:32 --> Model Class Initialized
INFO - 2018-11-23 09:01:32 --> Model Class Initialized
INFO - 2018-11-23 09:01:32 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-23 09:01:32 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/change-password.php
INFO - 2018-11-23 09:01:32 --> Final output sent to browser
DEBUG - 2018-11-23 09:01:32 --> Total execution time: 0.0620
INFO - 2018-11-23 09:01:32 --> Config Class Initialized
INFO - 2018-11-23 09:01:32 --> Hooks Class Initialized
DEBUG - 2018-11-23 09:01:32 --> UTF-8 Support Enabled
INFO - 2018-11-23 09:01:32 --> Utf8 Class Initialized
INFO - 2018-11-23 09:01:32 --> URI Class Initialized
INFO - 2018-11-23 09:01:32 --> Router Class Initialized
INFO - 2018-11-23 09:01:32 --> Output Class Initialized
INFO - 2018-11-23 09:01:32 --> Security Class Initialized
DEBUG - 2018-11-23 09:01:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-23 09:01:32 --> Input Class Initialized
INFO - 2018-11-23 09:01:32 --> Language Class Initialized
INFO - 2018-11-23 09:01:33 --> Loader Class Initialized
INFO - 2018-11-23 09:01:33 --> Helper loaded: url_helper
INFO - 2018-11-23 09:01:33 --> Helper loaded: file_helper
INFO - 2018-11-23 09:01:33 --> Helper loaded: email_helper
INFO - 2018-11-23 09:01:33 --> Helper loaded: common_helper
INFO - 2018-11-23 09:01:33 --> Database Driver Class Initialized
DEBUG - 2018-11-23 09:01:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-23 09:01:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-23 09:01:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-23 09:01:33 --> Pagination Class Initialized
INFO - 2018-11-23 09:01:33 --> Helper loaded: form_helper
INFO - 2018-11-23 09:01:33 --> Form Validation Class Initialized
INFO - 2018-11-23 09:01:33 --> Model Class Initialized
INFO - 2018-11-23 09:01:33 --> Controller Class Initialized
INFO - 2018-11-23 09:01:33 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-23 09:01:33 --> Model Class Initialized
INFO - 2018-11-23 09:01:33 --> Model Class Initialized
INFO - 2018-11-23 09:01:33 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-23 09:01:33 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/change-password.php
INFO - 2018-11-23 09:01:33 --> Final output sent to browser
DEBUG - 2018-11-23 09:01:33 --> Total execution time: 0.0610
INFO - 2018-11-23 09:02:48 --> Config Class Initialized
INFO - 2018-11-23 09:02:48 --> Hooks Class Initialized
DEBUG - 2018-11-23 09:02:48 --> UTF-8 Support Enabled
INFO - 2018-11-23 09:02:48 --> Utf8 Class Initialized
INFO - 2018-11-23 09:02:48 --> URI Class Initialized
INFO - 2018-11-23 09:02:48 --> Router Class Initialized
INFO - 2018-11-23 09:02:48 --> Output Class Initialized
INFO - 2018-11-23 09:02:48 --> Security Class Initialized
DEBUG - 2018-11-23 09:02:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-23 09:02:48 --> Input Class Initialized
INFO - 2018-11-23 09:02:48 --> Language Class Initialized
INFO - 2018-11-23 09:02:48 --> Loader Class Initialized
INFO - 2018-11-23 09:02:48 --> Helper loaded: url_helper
INFO - 2018-11-23 09:02:48 --> Helper loaded: file_helper
INFO - 2018-11-23 09:02:48 --> Helper loaded: email_helper
INFO - 2018-11-23 09:02:48 --> Helper loaded: common_helper
INFO - 2018-11-23 09:02:48 --> Database Driver Class Initialized
DEBUG - 2018-11-23 09:02:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-23 09:02:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-23 09:02:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-23 09:02:48 --> Pagination Class Initialized
INFO - 2018-11-23 09:02:48 --> Helper loaded: form_helper
INFO - 2018-11-23 09:02:48 --> Form Validation Class Initialized
INFO - 2018-11-23 09:02:48 --> Model Class Initialized
INFO - 2018-11-23 09:02:48 --> Controller Class Initialized
INFO - 2018-11-23 09:02:48 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-23 09:02:48 --> Model Class Initialized
INFO - 2018-11-23 09:02:48 --> Model Class Initialized
INFO - 2018-11-23 09:02:48 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-23 09:02:48 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/change-password.php
INFO - 2018-11-23 09:02:48 --> Final output sent to browser
DEBUG - 2018-11-23 09:02:48 --> Total execution time: 0.0620
INFO - 2018-11-23 09:05:26 --> Config Class Initialized
INFO - 2018-11-23 09:05:26 --> Hooks Class Initialized
DEBUG - 2018-11-23 09:05:26 --> UTF-8 Support Enabled
INFO - 2018-11-23 09:05:26 --> Utf8 Class Initialized
INFO - 2018-11-23 09:05:26 --> URI Class Initialized
INFO - 2018-11-23 09:05:26 --> Router Class Initialized
INFO - 2018-11-23 09:05:26 --> Output Class Initialized
INFO - 2018-11-23 09:05:26 --> Security Class Initialized
DEBUG - 2018-11-23 09:05:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-23 09:05:26 --> Input Class Initialized
INFO - 2018-11-23 09:05:26 --> Language Class Initialized
INFO - 2018-11-23 09:05:26 --> Loader Class Initialized
INFO - 2018-11-23 09:05:26 --> Helper loaded: url_helper
INFO - 2018-11-23 09:05:26 --> Helper loaded: file_helper
INFO - 2018-11-23 09:05:26 --> Helper loaded: email_helper
INFO - 2018-11-23 09:05:26 --> Helper loaded: common_helper
INFO - 2018-11-23 09:05:26 --> Database Driver Class Initialized
DEBUG - 2018-11-23 09:05:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-23 09:05:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-23 09:05:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-23 09:05:26 --> Pagination Class Initialized
INFO - 2018-11-23 09:05:26 --> Helper loaded: form_helper
INFO - 2018-11-23 09:05:26 --> Form Validation Class Initialized
INFO - 2018-11-23 09:05:26 --> Model Class Initialized
INFO - 2018-11-23 09:05:26 --> Controller Class Initialized
INFO - 2018-11-23 09:05:26 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-23 09:05:26 --> Model Class Initialized
INFO - 2018-11-23 09:05:26 --> Model Class Initialized
INFO - 2018-11-23 09:05:26 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-23 09:05:26 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/change-password.php
INFO - 2018-11-23 09:05:26 --> Final output sent to browser
DEBUG - 2018-11-23 09:05:26 --> Total execution time: 0.0560
INFO - 2018-11-23 09:05:27 --> Config Class Initialized
INFO - 2018-11-23 09:05:27 --> Hooks Class Initialized
DEBUG - 2018-11-23 09:05:27 --> UTF-8 Support Enabled
INFO - 2018-11-23 09:05:27 --> Utf8 Class Initialized
INFO - 2018-11-23 09:05:27 --> URI Class Initialized
INFO - 2018-11-23 09:05:27 --> Router Class Initialized
INFO - 2018-11-23 09:05:27 --> Output Class Initialized
INFO - 2018-11-23 09:05:27 --> Security Class Initialized
DEBUG - 2018-11-23 09:05:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-23 09:05:27 --> Input Class Initialized
INFO - 2018-11-23 09:05:27 --> Language Class Initialized
INFO - 2018-11-23 09:05:27 --> Loader Class Initialized
INFO - 2018-11-23 09:05:27 --> Helper loaded: url_helper
INFO - 2018-11-23 09:05:27 --> Helper loaded: file_helper
INFO - 2018-11-23 09:05:27 --> Helper loaded: email_helper
INFO - 2018-11-23 09:05:27 --> Helper loaded: common_helper
INFO - 2018-11-23 09:05:27 --> Database Driver Class Initialized
DEBUG - 2018-11-23 09:05:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-23 09:05:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-23 09:05:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-23 09:05:27 --> Pagination Class Initialized
INFO - 2018-11-23 09:05:27 --> Helper loaded: form_helper
INFO - 2018-11-23 09:05:27 --> Form Validation Class Initialized
INFO - 2018-11-23 09:05:27 --> Model Class Initialized
INFO - 2018-11-23 09:05:27 --> Controller Class Initialized
INFO - 2018-11-23 09:05:27 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-23 09:05:27 --> Model Class Initialized
INFO - 2018-11-23 09:05:27 --> Model Class Initialized
INFO - 2018-11-23 09:05:27 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-23 09:05:27 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/change-password.php
INFO - 2018-11-23 09:05:27 --> Final output sent to browser
DEBUG - 2018-11-23 09:05:27 --> Total execution time: 0.1690
INFO - 2018-11-23 09:05:52 --> Config Class Initialized
INFO - 2018-11-23 09:05:52 --> Hooks Class Initialized
DEBUG - 2018-11-23 09:05:52 --> UTF-8 Support Enabled
INFO - 2018-11-23 09:05:52 --> Utf8 Class Initialized
INFO - 2018-11-23 09:05:52 --> URI Class Initialized
INFO - 2018-11-23 09:05:52 --> Router Class Initialized
INFO - 2018-11-23 09:05:52 --> Output Class Initialized
INFO - 2018-11-23 09:05:52 --> Security Class Initialized
DEBUG - 2018-11-23 09:05:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-23 09:05:52 --> Input Class Initialized
INFO - 2018-11-23 09:05:52 --> Language Class Initialized
INFO - 2018-11-23 09:05:52 --> Loader Class Initialized
INFO - 2018-11-23 09:05:52 --> Helper loaded: url_helper
INFO - 2018-11-23 09:05:52 --> Helper loaded: file_helper
INFO - 2018-11-23 09:05:52 --> Helper loaded: email_helper
INFO - 2018-11-23 09:05:52 --> Helper loaded: common_helper
INFO - 2018-11-23 09:05:52 --> Database Driver Class Initialized
DEBUG - 2018-11-23 09:05:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-23 09:05:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-23 09:05:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-23 09:05:52 --> Pagination Class Initialized
INFO - 2018-11-23 09:05:52 --> Helper loaded: form_helper
INFO - 2018-11-23 09:05:52 --> Form Validation Class Initialized
INFO - 2018-11-23 09:05:52 --> Model Class Initialized
INFO - 2018-11-23 09:05:52 --> Controller Class Initialized
INFO - 2018-11-23 09:05:52 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-23 09:05:52 --> Model Class Initialized
INFO - 2018-11-23 09:05:52 --> Model Class Initialized
INFO - 2018-11-23 09:05:52 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-23 09:05:52 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/change-password.php
INFO - 2018-11-23 09:05:52 --> Final output sent to browser
DEBUG - 2018-11-23 09:05:52 --> Total execution time: 0.0480
INFO - 2018-11-23 09:06:07 --> Config Class Initialized
INFO - 2018-11-23 09:06:07 --> Hooks Class Initialized
DEBUG - 2018-11-23 09:06:07 --> UTF-8 Support Enabled
INFO - 2018-11-23 09:06:07 --> Utf8 Class Initialized
INFO - 2018-11-23 09:06:07 --> URI Class Initialized
INFO - 2018-11-23 09:06:07 --> Router Class Initialized
INFO - 2018-11-23 09:06:07 --> Output Class Initialized
INFO - 2018-11-23 09:06:07 --> Security Class Initialized
DEBUG - 2018-11-23 09:06:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-23 09:06:07 --> Input Class Initialized
INFO - 2018-11-23 09:06:07 --> Language Class Initialized
INFO - 2018-11-23 09:06:07 --> Loader Class Initialized
INFO - 2018-11-23 09:06:07 --> Helper loaded: url_helper
INFO - 2018-11-23 09:06:07 --> Helper loaded: file_helper
INFO - 2018-11-23 09:06:07 --> Helper loaded: email_helper
INFO - 2018-11-23 09:06:07 --> Helper loaded: common_helper
INFO - 2018-11-23 09:06:07 --> Database Driver Class Initialized
DEBUG - 2018-11-23 09:06:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-23 09:06:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-23 09:06:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-23 09:06:07 --> Pagination Class Initialized
INFO - 2018-11-23 09:06:07 --> Helper loaded: form_helper
INFO - 2018-11-23 09:06:07 --> Form Validation Class Initialized
INFO - 2018-11-23 09:06:07 --> Model Class Initialized
INFO - 2018-11-23 09:06:07 --> Controller Class Initialized
INFO - 2018-11-23 09:06:07 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-23 09:06:07 --> Model Class Initialized
INFO - 2018-11-23 09:06:07 --> Model Class Initialized
INFO - 2018-11-23 09:06:07 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-23 09:06:07 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/change-password.php
INFO - 2018-11-23 09:06:07 --> Final output sent to browser
DEBUG - 2018-11-23 09:06:07 --> Total execution time: 0.0630
INFO - 2018-11-23 09:07:21 --> Config Class Initialized
INFO - 2018-11-23 09:07:21 --> Hooks Class Initialized
DEBUG - 2018-11-23 09:07:21 --> UTF-8 Support Enabled
INFO - 2018-11-23 09:07:21 --> Utf8 Class Initialized
INFO - 2018-11-23 09:07:22 --> URI Class Initialized
INFO - 2018-11-23 09:07:22 --> Router Class Initialized
INFO - 2018-11-23 09:07:22 --> Output Class Initialized
INFO - 2018-11-23 09:07:22 --> Security Class Initialized
DEBUG - 2018-11-23 09:07:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-23 09:07:22 --> Input Class Initialized
INFO - 2018-11-23 09:07:22 --> Language Class Initialized
INFO - 2018-11-23 09:07:22 --> Loader Class Initialized
INFO - 2018-11-23 09:07:22 --> Helper loaded: url_helper
INFO - 2018-11-23 09:07:22 --> Helper loaded: file_helper
INFO - 2018-11-23 09:07:22 --> Helper loaded: email_helper
INFO - 2018-11-23 09:07:22 --> Helper loaded: common_helper
INFO - 2018-11-23 09:07:22 --> Database Driver Class Initialized
DEBUG - 2018-11-23 09:07:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-23 09:07:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-23 09:07:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-23 09:07:22 --> Pagination Class Initialized
INFO - 2018-11-23 09:07:22 --> Helper loaded: form_helper
INFO - 2018-11-23 09:07:22 --> Form Validation Class Initialized
INFO - 2018-11-23 09:07:22 --> Model Class Initialized
INFO - 2018-11-23 09:07:22 --> Controller Class Initialized
INFO - 2018-11-23 09:07:22 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-23 09:07:22 --> Model Class Initialized
INFO - 2018-11-23 09:07:22 --> Model Class Initialized
INFO - 2018-11-23 09:07:22 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-23 09:07:22 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/change-password.php
INFO - 2018-11-23 09:07:22 --> Final output sent to browser
DEBUG - 2018-11-23 09:07:22 --> Total execution time: 0.0450
INFO - 2018-11-23 09:10:48 --> Config Class Initialized
INFO - 2018-11-23 09:10:48 --> Hooks Class Initialized
DEBUG - 2018-11-23 09:10:48 --> UTF-8 Support Enabled
INFO - 2018-11-23 09:10:48 --> Utf8 Class Initialized
INFO - 2018-11-23 09:10:48 --> URI Class Initialized
INFO - 2018-11-23 09:10:48 --> Router Class Initialized
INFO - 2018-11-23 09:10:48 --> Output Class Initialized
INFO - 2018-11-23 09:10:49 --> Security Class Initialized
DEBUG - 2018-11-23 09:10:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-23 09:10:49 --> Input Class Initialized
INFO - 2018-11-23 09:10:49 --> Language Class Initialized
INFO - 2018-11-23 09:10:49 --> Loader Class Initialized
INFO - 2018-11-23 09:10:49 --> Helper loaded: url_helper
INFO - 2018-11-23 09:10:49 --> Helper loaded: file_helper
INFO - 2018-11-23 09:10:49 --> Helper loaded: email_helper
INFO - 2018-11-23 09:10:49 --> Helper loaded: common_helper
INFO - 2018-11-23 09:10:49 --> Database Driver Class Initialized
DEBUG - 2018-11-23 09:10:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-23 09:10:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-23 09:10:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-23 09:10:49 --> Pagination Class Initialized
INFO - 2018-11-23 09:10:49 --> Helper loaded: form_helper
INFO - 2018-11-23 09:10:49 --> Form Validation Class Initialized
INFO - 2018-11-23 09:10:49 --> Model Class Initialized
INFO - 2018-11-23 09:10:49 --> Controller Class Initialized
INFO - 2018-11-23 09:10:49 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-23 09:10:49 --> Model Class Initialized
INFO - 2018-11-23 09:10:49 --> Model Class Initialized
INFO - 2018-11-23 09:10:49 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-23 09:10:49 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/change-password.php
INFO - 2018-11-23 09:10:49 --> Final output sent to browser
DEBUG - 2018-11-23 09:10:49 --> Total execution time: 0.0550
INFO - 2018-11-23 09:11:11 --> Config Class Initialized
INFO - 2018-11-23 09:11:11 --> Hooks Class Initialized
DEBUG - 2018-11-23 09:11:11 --> UTF-8 Support Enabled
INFO - 2018-11-23 09:11:11 --> Utf8 Class Initialized
INFO - 2018-11-23 09:11:11 --> URI Class Initialized
INFO - 2018-11-23 09:11:11 --> Router Class Initialized
INFO - 2018-11-23 09:11:11 --> Output Class Initialized
INFO - 2018-11-23 09:11:11 --> Security Class Initialized
DEBUG - 2018-11-23 09:11:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-23 09:11:11 --> Input Class Initialized
INFO - 2018-11-23 09:11:11 --> Language Class Initialized
INFO - 2018-11-23 09:11:11 --> Loader Class Initialized
INFO - 2018-11-23 09:11:11 --> Helper loaded: url_helper
INFO - 2018-11-23 09:11:11 --> Helper loaded: file_helper
INFO - 2018-11-23 09:11:11 --> Helper loaded: email_helper
INFO - 2018-11-23 09:11:11 --> Helper loaded: common_helper
INFO - 2018-11-23 09:11:11 --> Database Driver Class Initialized
DEBUG - 2018-11-23 09:11:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-23 09:11:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-23 09:11:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-23 09:11:11 --> Pagination Class Initialized
INFO - 2018-11-23 09:11:11 --> Helper loaded: form_helper
INFO - 2018-11-23 09:11:11 --> Form Validation Class Initialized
INFO - 2018-11-23 09:11:11 --> Model Class Initialized
INFO - 2018-11-23 09:11:11 --> Controller Class Initialized
INFO - 2018-11-23 09:11:11 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-23 09:11:11 --> Model Class Initialized
INFO - 2018-11-23 09:11:11 --> Model Class Initialized
INFO - 2018-11-23 09:11:11 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-23 09:11:11 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/change-password.php
INFO - 2018-11-23 09:11:11 --> Final output sent to browser
DEBUG - 2018-11-23 09:11:11 --> Total execution time: 0.0500
INFO - 2018-11-23 09:12:13 --> Config Class Initialized
INFO - 2018-11-23 09:12:13 --> Hooks Class Initialized
DEBUG - 2018-11-23 09:12:13 --> UTF-8 Support Enabled
INFO - 2018-11-23 09:12:13 --> Utf8 Class Initialized
INFO - 2018-11-23 09:12:13 --> URI Class Initialized
INFO - 2018-11-23 09:12:13 --> Router Class Initialized
INFO - 2018-11-23 09:12:13 --> Output Class Initialized
INFO - 2018-11-23 09:12:13 --> Security Class Initialized
DEBUG - 2018-11-23 09:12:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-23 09:12:13 --> Input Class Initialized
INFO - 2018-11-23 09:12:13 --> Language Class Initialized
INFO - 2018-11-23 09:12:13 --> Loader Class Initialized
INFO - 2018-11-23 09:12:13 --> Helper loaded: url_helper
INFO - 2018-11-23 09:12:13 --> Helper loaded: file_helper
INFO - 2018-11-23 09:12:13 --> Helper loaded: email_helper
INFO - 2018-11-23 09:12:13 --> Helper loaded: common_helper
INFO - 2018-11-23 09:12:13 --> Database Driver Class Initialized
DEBUG - 2018-11-23 09:12:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-23 09:12:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-23 09:12:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-23 09:12:13 --> Pagination Class Initialized
INFO - 2018-11-23 09:12:13 --> Helper loaded: form_helper
INFO - 2018-11-23 09:12:13 --> Form Validation Class Initialized
INFO - 2018-11-23 09:12:13 --> Model Class Initialized
INFO - 2018-11-23 09:12:13 --> Controller Class Initialized
INFO - 2018-11-23 09:12:13 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-23 09:12:13 --> Model Class Initialized
INFO - 2018-11-23 09:12:13 --> Model Class Initialized
INFO - 2018-11-23 09:12:13 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-23 09:12:13 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/change-password.php
INFO - 2018-11-23 09:12:13 --> Final output sent to browser
DEBUG - 2018-11-23 09:12:13 --> Total execution time: 0.0520
INFO - 2018-11-23 09:13:15 --> Config Class Initialized
INFO - 2018-11-23 09:13:15 --> Hooks Class Initialized
DEBUG - 2018-11-23 09:13:15 --> UTF-8 Support Enabled
INFO - 2018-11-23 09:13:15 --> Utf8 Class Initialized
INFO - 2018-11-23 09:13:15 --> URI Class Initialized
INFO - 2018-11-23 09:13:15 --> Router Class Initialized
INFO - 2018-11-23 09:13:15 --> Output Class Initialized
INFO - 2018-11-23 09:13:15 --> Security Class Initialized
DEBUG - 2018-11-23 09:13:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-23 09:13:15 --> Input Class Initialized
INFO - 2018-11-23 09:13:15 --> Language Class Initialized
INFO - 2018-11-23 09:13:15 --> Loader Class Initialized
INFO - 2018-11-23 09:13:15 --> Helper loaded: url_helper
INFO - 2018-11-23 09:13:15 --> Helper loaded: file_helper
INFO - 2018-11-23 09:13:15 --> Helper loaded: email_helper
INFO - 2018-11-23 09:13:15 --> Helper loaded: common_helper
INFO - 2018-11-23 09:13:15 --> Database Driver Class Initialized
DEBUG - 2018-11-23 09:13:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-23 09:13:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-23 09:13:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-23 09:13:15 --> Pagination Class Initialized
INFO - 2018-11-23 09:13:15 --> Helper loaded: form_helper
INFO - 2018-11-23 09:13:15 --> Form Validation Class Initialized
INFO - 2018-11-23 09:13:15 --> Model Class Initialized
INFO - 2018-11-23 09:13:15 --> Controller Class Initialized
INFO - 2018-11-23 09:13:15 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-23 09:13:15 --> Model Class Initialized
INFO - 2018-11-23 09:13:15 --> Model Class Initialized
INFO - 2018-11-23 09:13:15 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-23 09:13:15 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/change-password.php
INFO - 2018-11-23 09:13:15 --> Final output sent to browser
DEBUG - 2018-11-23 09:13:15 --> Total execution time: 0.0750
INFO - 2018-11-23 09:15:13 --> Config Class Initialized
INFO - 2018-11-23 09:15:13 --> Hooks Class Initialized
DEBUG - 2018-11-23 09:15:13 --> UTF-8 Support Enabled
INFO - 2018-11-23 09:15:13 --> Utf8 Class Initialized
INFO - 2018-11-23 09:15:13 --> URI Class Initialized
INFO - 2018-11-23 09:15:13 --> Router Class Initialized
INFO - 2018-11-23 09:15:13 --> Output Class Initialized
INFO - 2018-11-23 09:15:13 --> Security Class Initialized
DEBUG - 2018-11-23 09:15:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-23 09:15:13 --> Input Class Initialized
INFO - 2018-11-23 09:15:13 --> Language Class Initialized
INFO - 2018-11-23 09:15:14 --> Loader Class Initialized
INFO - 2018-11-23 09:15:14 --> Helper loaded: url_helper
INFO - 2018-11-23 09:15:14 --> Helper loaded: file_helper
INFO - 2018-11-23 09:15:14 --> Helper loaded: email_helper
INFO - 2018-11-23 09:15:14 --> Helper loaded: common_helper
INFO - 2018-11-23 09:15:14 --> Database Driver Class Initialized
DEBUG - 2018-11-23 09:15:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-23 09:15:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-23 09:15:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-23 09:15:14 --> Pagination Class Initialized
INFO - 2018-11-23 09:15:14 --> Helper loaded: form_helper
INFO - 2018-11-23 09:15:14 --> Form Validation Class Initialized
INFO - 2018-11-23 09:15:14 --> Model Class Initialized
INFO - 2018-11-23 09:15:14 --> Controller Class Initialized
INFO - 2018-11-23 09:15:14 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-23 09:15:14 --> Model Class Initialized
INFO - 2018-11-23 09:15:14 --> Model Class Initialized
INFO - 2018-11-23 09:15:14 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-23 09:15:14 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/change-password.php
INFO - 2018-11-23 09:15:14 --> Final output sent to browser
DEBUG - 2018-11-23 09:15:14 --> Total execution time: 0.0560
INFO - 2018-11-23 09:16:48 --> Config Class Initialized
INFO - 2018-11-23 09:16:48 --> Hooks Class Initialized
DEBUG - 2018-11-23 09:16:48 --> UTF-8 Support Enabled
INFO - 2018-11-23 09:16:48 --> Utf8 Class Initialized
INFO - 2018-11-23 09:16:48 --> URI Class Initialized
INFO - 2018-11-23 09:16:48 --> Router Class Initialized
INFO - 2018-11-23 09:16:48 --> Output Class Initialized
INFO - 2018-11-23 09:16:48 --> Security Class Initialized
DEBUG - 2018-11-23 09:16:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-23 09:16:48 --> Input Class Initialized
INFO - 2018-11-23 09:16:48 --> Language Class Initialized
INFO - 2018-11-23 09:16:48 --> Loader Class Initialized
INFO - 2018-11-23 09:16:48 --> Helper loaded: url_helper
INFO - 2018-11-23 09:16:48 --> Helper loaded: file_helper
INFO - 2018-11-23 09:16:48 --> Helper loaded: email_helper
INFO - 2018-11-23 09:16:48 --> Helper loaded: common_helper
INFO - 2018-11-23 09:16:48 --> Database Driver Class Initialized
DEBUG - 2018-11-23 09:16:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-23 09:16:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-23 09:16:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-23 09:16:48 --> Pagination Class Initialized
INFO - 2018-11-23 09:16:48 --> Helper loaded: form_helper
INFO - 2018-11-23 09:16:48 --> Form Validation Class Initialized
INFO - 2018-11-23 09:16:48 --> Model Class Initialized
INFO - 2018-11-23 09:16:48 --> Controller Class Initialized
INFO - 2018-11-23 09:16:48 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-23 09:16:48 --> Model Class Initialized
INFO - 2018-11-23 09:16:48 --> Model Class Initialized
INFO - 2018-11-23 09:16:48 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-23 09:16:48 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/change-password.php
INFO - 2018-11-23 09:16:48 --> Final output sent to browser
DEBUG - 2018-11-23 09:16:48 --> Total execution time: 0.0500
INFO - 2018-11-23 09:17:26 --> Config Class Initialized
INFO - 2018-11-23 09:17:26 --> Hooks Class Initialized
DEBUG - 2018-11-23 09:17:26 --> UTF-8 Support Enabled
INFO - 2018-11-23 09:17:26 --> Utf8 Class Initialized
INFO - 2018-11-23 09:17:26 --> URI Class Initialized
INFO - 2018-11-23 09:17:26 --> Router Class Initialized
INFO - 2018-11-23 09:17:26 --> Output Class Initialized
INFO - 2018-11-23 09:17:26 --> Security Class Initialized
DEBUG - 2018-11-23 09:17:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-23 09:17:26 --> Input Class Initialized
INFO - 2018-11-23 09:17:26 --> Language Class Initialized
INFO - 2018-11-23 09:17:26 --> Loader Class Initialized
INFO - 2018-11-23 09:17:26 --> Helper loaded: url_helper
INFO - 2018-11-23 09:17:26 --> Helper loaded: file_helper
INFO - 2018-11-23 09:17:26 --> Helper loaded: email_helper
INFO - 2018-11-23 09:17:26 --> Helper loaded: common_helper
INFO - 2018-11-23 09:17:26 --> Database Driver Class Initialized
DEBUG - 2018-11-23 09:17:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-23 09:17:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-23 09:17:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-23 09:17:26 --> Pagination Class Initialized
INFO - 2018-11-23 09:17:26 --> Helper loaded: form_helper
INFO - 2018-11-23 09:17:26 --> Form Validation Class Initialized
INFO - 2018-11-23 09:17:26 --> Model Class Initialized
INFO - 2018-11-23 09:17:26 --> Controller Class Initialized
INFO - 2018-11-23 09:17:26 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-23 09:17:26 --> Model Class Initialized
INFO - 2018-11-23 09:17:26 --> Model Class Initialized
INFO - 2018-11-23 09:17:26 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-23 09:17:26 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/change-password.php
INFO - 2018-11-23 09:17:26 --> Final output sent to browser
DEBUG - 2018-11-23 09:17:26 --> Total execution time: 0.0560
INFO - 2018-11-23 09:17:51 --> Config Class Initialized
INFO - 2018-11-23 09:17:51 --> Hooks Class Initialized
DEBUG - 2018-11-23 09:17:51 --> UTF-8 Support Enabled
INFO - 2018-11-23 09:17:51 --> Utf8 Class Initialized
INFO - 2018-11-23 09:17:51 --> URI Class Initialized
INFO - 2018-11-23 09:17:51 --> Router Class Initialized
INFO - 2018-11-23 09:17:51 --> Output Class Initialized
INFO - 2018-11-23 09:17:51 --> Security Class Initialized
DEBUG - 2018-11-23 09:17:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-23 09:17:51 --> Input Class Initialized
INFO - 2018-11-23 09:17:51 --> Language Class Initialized
INFO - 2018-11-23 09:17:51 --> Loader Class Initialized
INFO - 2018-11-23 09:17:51 --> Helper loaded: url_helper
INFO - 2018-11-23 09:17:51 --> Helper loaded: file_helper
INFO - 2018-11-23 09:17:51 --> Helper loaded: email_helper
INFO - 2018-11-23 09:17:51 --> Helper loaded: common_helper
INFO - 2018-11-23 09:17:51 --> Database Driver Class Initialized
DEBUG - 2018-11-23 09:17:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-23 09:17:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-23 09:17:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-23 09:17:51 --> Pagination Class Initialized
INFO - 2018-11-23 09:17:51 --> Helper loaded: form_helper
INFO - 2018-11-23 09:17:51 --> Form Validation Class Initialized
INFO - 2018-11-23 09:17:51 --> Model Class Initialized
INFO - 2018-11-23 09:17:51 --> Controller Class Initialized
INFO - 2018-11-23 09:17:51 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-23 09:17:51 --> Model Class Initialized
INFO - 2018-11-23 09:17:51 --> Model Class Initialized
INFO - 2018-11-23 09:17:51 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-23 09:17:51 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/change-password.php
INFO - 2018-11-23 09:17:51 --> Final output sent to browser
DEBUG - 2018-11-23 09:17:51 --> Total execution time: 0.0580
INFO - 2018-11-23 09:18:02 --> Config Class Initialized
INFO - 2018-11-23 09:18:02 --> Hooks Class Initialized
DEBUG - 2018-11-23 09:18:02 --> UTF-8 Support Enabled
INFO - 2018-11-23 09:18:02 --> Utf8 Class Initialized
INFO - 2018-11-23 09:18:02 --> URI Class Initialized
INFO - 2018-11-23 09:18:02 --> Router Class Initialized
INFO - 2018-11-23 09:18:02 --> Output Class Initialized
INFO - 2018-11-23 09:18:02 --> Security Class Initialized
DEBUG - 2018-11-23 09:18:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-23 09:18:02 --> Input Class Initialized
INFO - 2018-11-23 09:18:02 --> Language Class Initialized
INFO - 2018-11-23 09:18:02 --> Loader Class Initialized
INFO - 2018-11-23 09:18:02 --> Helper loaded: url_helper
INFO - 2018-11-23 09:18:02 --> Helper loaded: file_helper
INFO - 2018-11-23 09:18:02 --> Helper loaded: email_helper
INFO - 2018-11-23 09:18:02 --> Helper loaded: common_helper
INFO - 2018-11-23 09:18:02 --> Database Driver Class Initialized
DEBUG - 2018-11-23 09:18:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-23 09:18:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-23 09:18:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-23 09:18:02 --> Pagination Class Initialized
INFO - 2018-11-23 09:18:02 --> Helper loaded: form_helper
INFO - 2018-11-23 09:18:02 --> Form Validation Class Initialized
INFO - 2018-11-23 09:18:02 --> Model Class Initialized
INFO - 2018-11-23 09:18:02 --> Controller Class Initialized
INFO - 2018-11-23 09:18:02 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-23 09:18:02 --> Model Class Initialized
INFO - 2018-11-23 09:18:02 --> Model Class Initialized
INFO - 2018-11-23 09:18:02 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-23 09:18:02 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/change-password.php
INFO - 2018-11-23 09:18:02 --> Final output sent to browser
DEBUG - 2018-11-23 09:18:02 --> Total execution time: 0.0520
INFO - 2018-11-23 09:18:37 --> Config Class Initialized
INFO - 2018-11-23 09:18:37 --> Hooks Class Initialized
DEBUG - 2018-11-23 09:18:37 --> UTF-8 Support Enabled
INFO - 2018-11-23 09:18:37 --> Utf8 Class Initialized
INFO - 2018-11-23 09:18:37 --> URI Class Initialized
INFO - 2018-11-23 09:18:37 --> Router Class Initialized
INFO - 2018-11-23 09:18:37 --> Output Class Initialized
INFO - 2018-11-23 09:18:37 --> Security Class Initialized
DEBUG - 2018-11-23 09:18:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-23 09:18:37 --> Input Class Initialized
INFO - 2018-11-23 09:18:37 --> Language Class Initialized
INFO - 2018-11-23 09:18:37 --> Loader Class Initialized
INFO - 2018-11-23 09:18:37 --> Helper loaded: url_helper
INFO - 2018-11-23 09:18:37 --> Helper loaded: file_helper
INFO - 2018-11-23 09:18:37 --> Helper loaded: email_helper
INFO - 2018-11-23 09:18:37 --> Helper loaded: common_helper
INFO - 2018-11-23 09:18:37 --> Database Driver Class Initialized
DEBUG - 2018-11-23 09:18:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-23 09:18:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-23 09:18:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-23 09:18:37 --> Pagination Class Initialized
INFO - 2018-11-23 09:18:37 --> Helper loaded: form_helper
INFO - 2018-11-23 09:18:37 --> Form Validation Class Initialized
INFO - 2018-11-23 09:18:37 --> Model Class Initialized
INFO - 2018-11-23 09:18:37 --> Controller Class Initialized
INFO - 2018-11-23 09:18:37 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-23 09:18:37 --> Model Class Initialized
INFO - 2018-11-23 09:18:37 --> Model Class Initialized
INFO - 2018-11-23 09:18:37 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-23 09:18:37 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/change-password.php
INFO - 2018-11-23 09:18:37 --> Final output sent to browser
DEBUG - 2018-11-23 09:18:37 --> Total execution time: 0.0510
INFO - 2018-11-23 09:19:00 --> Config Class Initialized
INFO - 2018-11-23 09:19:00 --> Hooks Class Initialized
DEBUG - 2018-11-23 09:19:00 --> UTF-8 Support Enabled
INFO - 2018-11-23 09:19:00 --> Utf8 Class Initialized
INFO - 2018-11-23 09:19:00 --> URI Class Initialized
INFO - 2018-11-23 09:19:00 --> Router Class Initialized
INFO - 2018-11-23 09:19:00 --> Output Class Initialized
INFO - 2018-11-23 09:19:00 --> Security Class Initialized
DEBUG - 2018-11-23 09:19:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-23 09:19:00 --> Input Class Initialized
INFO - 2018-11-23 09:19:00 --> Language Class Initialized
INFO - 2018-11-23 09:19:00 --> Loader Class Initialized
INFO - 2018-11-23 09:19:00 --> Helper loaded: url_helper
INFO - 2018-11-23 09:19:00 --> Helper loaded: file_helper
INFO - 2018-11-23 09:19:00 --> Helper loaded: email_helper
INFO - 2018-11-23 09:19:00 --> Helper loaded: common_helper
INFO - 2018-11-23 09:19:00 --> Database Driver Class Initialized
DEBUG - 2018-11-23 09:19:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-23 09:19:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-23 09:19:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-23 09:19:00 --> Pagination Class Initialized
INFO - 2018-11-23 09:19:00 --> Helper loaded: form_helper
INFO - 2018-11-23 09:19:00 --> Form Validation Class Initialized
INFO - 2018-11-23 09:19:00 --> Model Class Initialized
INFO - 2018-11-23 09:19:00 --> Controller Class Initialized
INFO - 2018-11-23 09:19:00 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-23 09:19:00 --> Model Class Initialized
INFO - 2018-11-23 09:19:00 --> Model Class Initialized
INFO - 2018-11-23 09:19:00 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-23 09:19:00 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/change-password.php
INFO - 2018-11-23 09:19:00 --> Final output sent to browser
DEBUG - 2018-11-23 09:19:00 --> Total execution time: 0.0540
INFO - 2018-11-23 09:19:36 --> Config Class Initialized
INFO - 2018-11-23 09:19:36 --> Hooks Class Initialized
DEBUG - 2018-11-23 09:19:36 --> UTF-8 Support Enabled
INFO - 2018-11-23 09:19:36 --> Utf8 Class Initialized
INFO - 2018-11-23 09:19:36 --> URI Class Initialized
INFO - 2018-11-23 09:19:36 --> Router Class Initialized
INFO - 2018-11-23 09:19:36 --> Output Class Initialized
INFO - 2018-11-23 09:19:36 --> Security Class Initialized
DEBUG - 2018-11-23 09:19:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-23 09:19:36 --> Input Class Initialized
INFO - 2018-11-23 09:19:36 --> Language Class Initialized
INFO - 2018-11-23 09:19:36 --> Loader Class Initialized
INFO - 2018-11-23 09:19:36 --> Helper loaded: url_helper
INFO - 2018-11-23 09:19:36 --> Helper loaded: file_helper
INFO - 2018-11-23 09:19:36 --> Helper loaded: email_helper
INFO - 2018-11-23 09:19:36 --> Helper loaded: common_helper
INFO - 2018-11-23 09:19:36 --> Database Driver Class Initialized
DEBUG - 2018-11-23 09:19:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-23 09:19:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-23 09:19:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-23 09:19:36 --> Pagination Class Initialized
INFO - 2018-11-23 09:19:36 --> Helper loaded: form_helper
INFO - 2018-11-23 09:19:36 --> Form Validation Class Initialized
INFO - 2018-11-23 09:19:36 --> Model Class Initialized
INFO - 2018-11-23 09:19:36 --> Controller Class Initialized
INFO - 2018-11-23 09:19:36 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-23 09:19:36 --> Model Class Initialized
INFO - 2018-11-23 09:19:36 --> Model Class Initialized
INFO - 2018-11-23 09:19:36 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-23 09:19:36 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/change-password.php
INFO - 2018-11-23 09:19:36 --> Final output sent to browser
DEBUG - 2018-11-23 09:19:36 --> Total execution time: 0.0600
INFO - 2018-11-23 09:20:01 --> Config Class Initialized
INFO - 2018-11-23 09:20:01 --> Hooks Class Initialized
DEBUG - 2018-11-23 09:20:01 --> UTF-8 Support Enabled
INFO - 2018-11-23 09:20:01 --> Utf8 Class Initialized
INFO - 2018-11-23 09:20:01 --> URI Class Initialized
INFO - 2018-11-23 09:20:01 --> Router Class Initialized
INFO - 2018-11-23 09:20:01 --> Output Class Initialized
INFO - 2018-11-23 09:20:01 --> Security Class Initialized
DEBUG - 2018-11-23 09:20:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-23 09:20:01 --> Input Class Initialized
INFO - 2018-11-23 09:20:01 --> Language Class Initialized
INFO - 2018-11-23 09:20:01 --> Loader Class Initialized
INFO - 2018-11-23 09:20:01 --> Helper loaded: url_helper
INFO - 2018-11-23 09:20:01 --> Helper loaded: file_helper
INFO - 2018-11-23 09:20:01 --> Helper loaded: email_helper
INFO - 2018-11-23 09:20:01 --> Helper loaded: common_helper
INFO - 2018-11-23 09:20:01 --> Database Driver Class Initialized
DEBUG - 2018-11-23 09:20:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-23 09:20:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-23 09:20:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-23 09:20:01 --> Pagination Class Initialized
INFO - 2018-11-23 09:20:01 --> Helper loaded: form_helper
INFO - 2018-11-23 09:20:01 --> Form Validation Class Initialized
INFO - 2018-11-23 09:20:01 --> Model Class Initialized
INFO - 2018-11-23 09:20:01 --> Controller Class Initialized
INFO - 2018-11-23 09:20:01 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-23 09:20:01 --> Model Class Initialized
INFO - 2018-11-23 09:20:01 --> Model Class Initialized
INFO - 2018-11-23 09:20:01 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-23 09:20:01 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/change-password.php
INFO - 2018-11-23 09:20:01 --> Final output sent to browser
DEBUG - 2018-11-23 09:20:01 --> Total execution time: 0.0440
INFO - 2018-11-23 09:25:10 --> Config Class Initialized
INFO - 2018-11-23 09:25:10 --> Hooks Class Initialized
DEBUG - 2018-11-23 09:25:10 --> UTF-8 Support Enabled
INFO - 2018-11-23 09:25:10 --> Utf8 Class Initialized
INFO - 2018-11-23 09:25:10 --> URI Class Initialized
INFO - 2018-11-23 09:25:10 --> Router Class Initialized
INFO - 2018-11-23 09:25:10 --> Output Class Initialized
INFO - 2018-11-23 09:25:10 --> Security Class Initialized
DEBUG - 2018-11-23 09:25:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-23 09:25:10 --> Input Class Initialized
INFO - 2018-11-23 09:25:10 --> Language Class Initialized
INFO - 2018-11-23 09:25:10 --> Loader Class Initialized
INFO - 2018-11-23 09:25:10 --> Helper loaded: url_helper
INFO - 2018-11-23 09:25:10 --> Helper loaded: file_helper
INFO - 2018-11-23 09:25:10 --> Helper loaded: email_helper
INFO - 2018-11-23 09:25:10 --> Helper loaded: common_helper
INFO - 2018-11-23 09:25:10 --> Database Driver Class Initialized
DEBUG - 2018-11-23 09:25:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-23 09:25:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-23 09:25:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-23 09:25:10 --> Pagination Class Initialized
INFO - 2018-11-23 09:25:10 --> Helper loaded: form_helper
INFO - 2018-11-23 09:25:10 --> Form Validation Class Initialized
INFO - 2018-11-23 09:25:10 --> Model Class Initialized
INFO - 2018-11-23 09:25:10 --> Controller Class Initialized
INFO - 2018-11-23 09:25:10 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-23 09:25:10 --> Model Class Initialized
INFO - 2018-11-23 09:25:10 --> Model Class Initialized
INFO - 2018-11-23 09:25:10 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-23 09:25:10 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/change-password.php
INFO - 2018-11-23 09:25:10 --> Final output sent to browser
DEBUG - 2018-11-23 09:25:10 --> Total execution time: 0.0580
INFO - 2018-11-23 10:33:29 --> Config Class Initialized
INFO - 2018-11-23 10:33:29 --> Hooks Class Initialized
DEBUG - 2018-11-23 10:33:29 --> UTF-8 Support Enabled
INFO - 2018-11-23 10:33:29 --> Utf8 Class Initialized
INFO - 2018-11-23 10:33:29 --> URI Class Initialized
INFO - 2018-11-23 10:33:29 --> Router Class Initialized
INFO - 2018-11-23 10:33:29 --> Output Class Initialized
INFO - 2018-11-23 10:33:29 --> Security Class Initialized
DEBUG - 2018-11-23 10:33:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-23 10:33:29 --> Input Class Initialized
INFO - 2018-11-23 10:33:29 --> Language Class Initialized
INFO - 2018-11-23 10:33:29 --> Loader Class Initialized
INFO - 2018-11-23 10:33:29 --> Helper loaded: url_helper
INFO - 2018-11-23 10:33:29 --> Helper loaded: file_helper
INFO - 2018-11-23 10:33:29 --> Helper loaded: email_helper
INFO - 2018-11-23 10:33:29 --> Helper loaded: common_helper
INFO - 2018-11-23 10:33:29 --> Database Driver Class Initialized
DEBUG - 2018-11-23 10:33:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-23 10:33:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-23 10:33:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-23 10:33:29 --> Pagination Class Initialized
INFO - 2018-11-23 10:33:29 --> Helper loaded: form_helper
INFO - 2018-11-23 10:33:29 --> Form Validation Class Initialized
INFO - 2018-11-23 10:33:29 --> Model Class Initialized
INFO - 2018-11-23 10:33:29 --> Controller Class Initialized
INFO - 2018-11-23 10:33:29 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-23 10:33:29 --> Model Class Initialized
INFO - 2018-11-23 10:33:29 --> Model Class Initialized
INFO - 2018-11-23 10:33:29 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-23 10:33:29 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/change-password.php
INFO - 2018-11-23 10:33:29 --> Final output sent to browser
DEBUG - 2018-11-23 10:33:29 --> Total execution time: 0.0720
INFO - 2018-11-23 10:55:47 --> Config Class Initialized
INFO - 2018-11-23 10:55:47 --> Hooks Class Initialized
DEBUG - 2018-11-23 10:55:47 --> UTF-8 Support Enabled
INFO - 2018-11-23 10:55:47 --> Utf8 Class Initialized
INFO - 2018-11-23 10:55:47 --> URI Class Initialized
INFO - 2018-11-23 10:55:47 --> Router Class Initialized
INFO - 2018-11-23 10:55:47 --> Output Class Initialized
INFO - 2018-11-23 10:55:47 --> Security Class Initialized
DEBUG - 2018-11-23 10:55:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-23 10:55:47 --> Input Class Initialized
INFO - 2018-11-23 10:55:47 --> Language Class Initialized
INFO - 2018-11-23 10:55:47 --> Loader Class Initialized
INFO - 2018-11-23 10:55:47 --> Helper loaded: url_helper
INFO - 2018-11-23 10:55:47 --> Helper loaded: file_helper
INFO - 2018-11-23 10:55:47 --> Helper loaded: email_helper
INFO - 2018-11-23 10:55:47 --> Helper loaded: common_helper
INFO - 2018-11-23 10:55:47 --> Database Driver Class Initialized
DEBUG - 2018-11-23 10:55:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-23 10:55:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-23 10:55:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-23 10:55:47 --> Pagination Class Initialized
INFO - 2018-11-23 10:55:47 --> Helper loaded: form_helper
INFO - 2018-11-23 10:55:47 --> Form Validation Class Initialized
INFO - 2018-11-23 10:55:47 --> Model Class Initialized
INFO - 2018-11-23 10:55:47 --> Controller Class Initialized
INFO - 2018-11-23 10:55:47 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-23 10:55:47 --> Model Class Initialized
INFO - 2018-11-23 10:55:47 --> Model Class Initialized
INFO - 2018-11-23 10:55:47 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-23 10:55:47 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/change-password.php
INFO - 2018-11-23 10:55:47 --> Final output sent to browser
DEBUG - 2018-11-23 10:55:47 --> Total execution time: 0.0530
INFO - 2018-11-23 10:57:23 --> Config Class Initialized
INFO - 2018-11-23 10:57:23 --> Hooks Class Initialized
DEBUG - 2018-11-23 10:57:23 --> UTF-8 Support Enabled
INFO - 2018-11-23 10:57:23 --> Utf8 Class Initialized
INFO - 2018-11-23 10:57:23 --> URI Class Initialized
INFO - 2018-11-23 10:57:23 --> Router Class Initialized
INFO - 2018-11-23 10:57:23 --> Output Class Initialized
INFO - 2018-11-23 10:57:23 --> Security Class Initialized
DEBUG - 2018-11-23 10:57:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-23 10:57:23 --> Input Class Initialized
INFO - 2018-11-23 10:57:23 --> Language Class Initialized
INFO - 2018-11-23 10:57:23 --> Loader Class Initialized
INFO - 2018-11-23 10:57:23 --> Helper loaded: url_helper
INFO - 2018-11-23 10:57:23 --> Helper loaded: file_helper
INFO - 2018-11-23 10:57:23 --> Helper loaded: email_helper
INFO - 2018-11-23 10:57:23 --> Helper loaded: common_helper
INFO - 2018-11-23 10:57:23 --> Database Driver Class Initialized
DEBUG - 2018-11-23 10:57:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-23 10:57:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-23 10:57:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-23 10:57:23 --> Pagination Class Initialized
INFO - 2018-11-23 10:57:23 --> Helper loaded: form_helper
INFO - 2018-11-23 10:57:23 --> Form Validation Class Initialized
INFO - 2018-11-23 10:57:23 --> Model Class Initialized
INFO - 2018-11-23 10:57:23 --> Controller Class Initialized
INFO - 2018-11-23 10:57:23 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-23 10:57:23 --> Model Class Initialized
INFO - 2018-11-23 10:57:23 --> Model Class Initialized
INFO - 2018-11-23 10:57:23 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-23 10:57:23 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/change-password.php
INFO - 2018-11-23 10:57:23 --> Final output sent to browser
DEBUG - 2018-11-23 10:57:23 --> Total execution time: 0.0556
INFO - 2018-11-23 11:04:37 --> Config Class Initialized
INFO - 2018-11-23 11:04:37 --> Hooks Class Initialized
DEBUG - 2018-11-23 11:04:37 --> UTF-8 Support Enabled
INFO - 2018-11-23 11:04:37 --> Utf8 Class Initialized
INFO - 2018-11-23 11:04:37 --> URI Class Initialized
INFO - 2018-11-23 11:04:37 --> Router Class Initialized
INFO - 2018-11-23 11:04:37 --> Output Class Initialized
INFO - 2018-11-23 11:04:37 --> Security Class Initialized
DEBUG - 2018-11-23 11:04:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-23 11:04:37 --> Input Class Initialized
INFO - 2018-11-23 11:04:37 --> Language Class Initialized
INFO - 2018-11-23 11:04:37 --> Loader Class Initialized
INFO - 2018-11-23 11:04:37 --> Helper loaded: url_helper
INFO - 2018-11-23 11:04:37 --> Helper loaded: file_helper
INFO - 2018-11-23 11:04:37 --> Helper loaded: email_helper
INFO - 2018-11-23 11:04:37 --> Helper loaded: common_helper
INFO - 2018-11-23 11:04:37 --> Database Driver Class Initialized
DEBUG - 2018-11-23 11:04:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-23 11:04:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-23 11:04:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-23 11:04:37 --> Pagination Class Initialized
INFO - 2018-11-23 11:04:37 --> Helper loaded: form_helper
INFO - 2018-11-23 11:04:37 --> Form Validation Class Initialized
INFO - 2018-11-23 11:04:37 --> Model Class Initialized
INFO - 2018-11-23 11:04:37 --> Controller Class Initialized
INFO - 2018-11-23 11:04:37 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-23 11:04:37 --> Model Class Initialized
INFO - 2018-11-23 11:04:37 --> Model Class Initialized
INFO - 2018-11-23 11:04:37 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-23 11:04:37 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/change-password.php
INFO - 2018-11-23 11:04:37 --> Final output sent to browser
DEBUG - 2018-11-23 11:04:37 --> Total execution time: 0.0650
INFO - 2018-11-23 11:05:46 --> Config Class Initialized
INFO - 2018-11-23 11:05:46 --> Hooks Class Initialized
DEBUG - 2018-11-23 11:05:46 --> UTF-8 Support Enabled
INFO - 2018-11-23 11:05:46 --> Utf8 Class Initialized
INFO - 2018-11-23 11:05:46 --> URI Class Initialized
INFO - 2018-11-23 11:05:46 --> Router Class Initialized
INFO - 2018-11-23 11:05:46 --> Output Class Initialized
INFO - 2018-11-23 11:05:46 --> Security Class Initialized
DEBUG - 2018-11-23 11:05:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-23 11:05:46 --> Input Class Initialized
INFO - 2018-11-23 11:05:46 --> Language Class Initialized
INFO - 2018-11-23 11:05:46 --> Loader Class Initialized
INFO - 2018-11-23 11:05:46 --> Helper loaded: url_helper
INFO - 2018-11-23 11:05:46 --> Helper loaded: file_helper
INFO - 2018-11-23 11:05:46 --> Helper loaded: email_helper
INFO - 2018-11-23 11:05:46 --> Helper loaded: common_helper
INFO - 2018-11-23 11:05:46 --> Database Driver Class Initialized
DEBUG - 2018-11-23 11:05:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-23 11:05:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-23 11:05:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-23 11:05:46 --> Pagination Class Initialized
INFO - 2018-11-23 11:05:46 --> Helper loaded: form_helper
INFO - 2018-11-23 11:05:46 --> Form Validation Class Initialized
INFO - 2018-11-23 11:05:46 --> Model Class Initialized
INFO - 2018-11-23 11:05:46 --> Controller Class Initialized
INFO - 2018-11-23 11:05:46 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-23 11:05:46 --> Model Class Initialized
INFO - 2018-11-23 11:05:46 --> Model Class Initialized
INFO - 2018-11-23 11:05:46 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-23 11:05:46 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/change-password.php
INFO - 2018-11-23 11:05:46 --> Final output sent to browser
DEBUG - 2018-11-23 11:05:46 --> Total execution time: 0.0550
INFO - 2018-11-23 11:06:12 --> Config Class Initialized
INFO - 2018-11-23 11:06:12 --> Hooks Class Initialized
DEBUG - 2018-11-23 11:06:12 --> UTF-8 Support Enabled
INFO - 2018-11-23 11:06:12 --> Utf8 Class Initialized
INFO - 2018-11-23 11:06:12 --> URI Class Initialized
INFO - 2018-11-23 11:06:12 --> Router Class Initialized
INFO - 2018-11-23 11:06:12 --> Output Class Initialized
INFO - 2018-11-23 11:06:12 --> Security Class Initialized
DEBUG - 2018-11-23 11:06:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-23 11:06:12 --> Input Class Initialized
INFO - 2018-11-23 11:06:12 --> Language Class Initialized
INFO - 2018-11-23 11:06:12 --> Loader Class Initialized
INFO - 2018-11-23 11:06:12 --> Helper loaded: url_helper
INFO - 2018-11-23 11:06:12 --> Helper loaded: file_helper
INFO - 2018-11-23 11:06:12 --> Helper loaded: email_helper
INFO - 2018-11-23 11:06:12 --> Helper loaded: common_helper
INFO - 2018-11-23 11:06:12 --> Database Driver Class Initialized
DEBUG - 2018-11-23 11:06:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-23 11:06:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-23 11:06:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-23 11:06:12 --> Pagination Class Initialized
INFO - 2018-11-23 11:06:12 --> Helper loaded: form_helper
INFO - 2018-11-23 11:06:12 --> Form Validation Class Initialized
INFO - 2018-11-23 11:06:12 --> Model Class Initialized
INFO - 2018-11-23 11:06:12 --> Controller Class Initialized
INFO - 2018-11-23 11:06:12 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-23 11:06:12 --> Model Class Initialized
INFO - 2018-11-23 11:06:12 --> Model Class Initialized
INFO - 2018-11-23 11:06:12 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-23 11:06:12 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/change-password.php
INFO - 2018-11-23 11:06:12 --> Final output sent to browser
DEBUG - 2018-11-23 11:06:12 --> Total execution time: 0.0570
INFO - 2018-11-23 11:06:45 --> Config Class Initialized
INFO - 2018-11-23 11:06:45 --> Hooks Class Initialized
DEBUG - 2018-11-23 11:06:45 --> UTF-8 Support Enabled
INFO - 2018-11-23 11:06:45 --> Utf8 Class Initialized
INFO - 2018-11-23 11:06:45 --> URI Class Initialized
INFO - 2018-11-23 11:06:45 --> Router Class Initialized
INFO - 2018-11-23 11:06:45 --> Output Class Initialized
INFO - 2018-11-23 11:06:45 --> Security Class Initialized
DEBUG - 2018-11-23 11:06:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-23 11:06:45 --> Input Class Initialized
INFO - 2018-11-23 11:06:45 --> Language Class Initialized
INFO - 2018-11-23 11:06:45 --> Loader Class Initialized
INFO - 2018-11-23 11:06:45 --> Helper loaded: url_helper
INFO - 2018-11-23 11:06:45 --> Helper loaded: file_helper
INFO - 2018-11-23 11:06:45 --> Helper loaded: email_helper
INFO - 2018-11-23 11:06:45 --> Helper loaded: common_helper
INFO - 2018-11-23 11:06:45 --> Database Driver Class Initialized
DEBUG - 2018-11-23 11:06:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-23 11:06:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-23 11:06:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-23 11:06:45 --> Pagination Class Initialized
INFO - 2018-11-23 11:06:45 --> Helper loaded: form_helper
INFO - 2018-11-23 11:06:45 --> Form Validation Class Initialized
INFO - 2018-11-23 11:06:45 --> Model Class Initialized
INFO - 2018-11-23 11:06:45 --> Controller Class Initialized
INFO - 2018-11-23 11:06:45 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-23 11:06:45 --> Model Class Initialized
INFO - 2018-11-23 11:06:45 --> Model Class Initialized
INFO - 2018-11-23 11:06:45 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-23 11:06:45 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/change-password.php
INFO - 2018-11-23 11:06:45 --> Final output sent to browser
DEBUG - 2018-11-23 11:06:45 --> Total execution time: 0.0600
INFO - 2018-11-23 11:07:08 --> Config Class Initialized
INFO - 2018-11-23 11:07:08 --> Hooks Class Initialized
DEBUG - 2018-11-23 11:07:08 --> UTF-8 Support Enabled
INFO - 2018-11-23 11:07:08 --> Utf8 Class Initialized
INFO - 2018-11-23 11:07:08 --> URI Class Initialized
INFO - 2018-11-23 11:07:08 --> Router Class Initialized
INFO - 2018-11-23 11:07:08 --> Output Class Initialized
INFO - 2018-11-23 11:07:08 --> Security Class Initialized
DEBUG - 2018-11-23 11:07:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-23 11:07:08 --> Input Class Initialized
INFO - 2018-11-23 11:07:08 --> Language Class Initialized
INFO - 2018-11-23 11:07:08 --> Loader Class Initialized
INFO - 2018-11-23 11:07:08 --> Helper loaded: url_helper
INFO - 2018-11-23 11:07:08 --> Helper loaded: file_helper
INFO - 2018-11-23 11:07:08 --> Helper loaded: email_helper
INFO - 2018-11-23 11:07:08 --> Helper loaded: common_helper
INFO - 2018-11-23 11:07:08 --> Database Driver Class Initialized
DEBUG - 2018-11-23 11:07:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-23 11:07:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-23 11:07:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-23 11:07:08 --> Pagination Class Initialized
INFO - 2018-11-23 11:07:08 --> Helper loaded: form_helper
INFO - 2018-11-23 11:07:08 --> Form Validation Class Initialized
INFO - 2018-11-23 11:07:08 --> Model Class Initialized
INFO - 2018-11-23 11:07:08 --> Controller Class Initialized
INFO - 2018-11-23 11:07:08 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-23 11:07:08 --> Model Class Initialized
INFO - 2018-11-23 11:07:08 --> Model Class Initialized
INFO - 2018-11-23 11:07:08 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-23 11:07:08 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/change-password.php
INFO - 2018-11-23 11:07:08 --> Final output sent to browser
DEBUG - 2018-11-23 11:07:08 --> Total execution time: 0.0570
INFO - 2018-11-23 11:07:26 --> Config Class Initialized
INFO - 2018-11-23 11:07:26 --> Hooks Class Initialized
DEBUG - 2018-11-23 11:07:26 --> UTF-8 Support Enabled
INFO - 2018-11-23 11:07:26 --> Utf8 Class Initialized
INFO - 2018-11-23 11:07:26 --> URI Class Initialized
INFO - 2018-11-23 11:07:26 --> Router Class Initialized
INFO - 2018-11-23 11:07:26 --> Output Class Initialized
INFO - 2018-11-23 11:07:26 --> Security Class Initialized
DEBUG - 2018-11-23 11:07:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-23 11:07:26 --> Input Class Initialized
INFO - 2018-11-23 11:07:26 --> Language Class Initialized
INFO - 2018-11-23 11:07:26 --> Loader Class Initialized
INFO - 2018-11-23 11:07:26 --> Helper loaded: url_helper
INFO - 2018-11-23 11:07:26 --> Helper loaded: file_helper
INFO - 2018-11-23 11:07:26 --> Helper loaded: email_helper
INFO - 2018-11-23 11:07:26 --> Helper loaded: common_helper
INFO - 2018-11-23 11:07:26 --> Database Driver Class Initialized
DEBUG - 2018-11-23 11:07:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-23 11:07:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-23 11:07:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-23 11:07:26 --> Pagination Class Initialized
INFO - 2018-11-23 11:07:26 --> Helper loaded: form_helper
INFO - 2018-11-23 11:07:26 --> Form Validation Class Initialized
INFO - 2018-11-23 11:07:26 --> Model Class Initialized
INFO - 2018-11-23 11:07:26 --> Controller Class Initialized
INFO - 2018-11-23 11:07:26 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-23 11:07:26 --> Model Class Initialized
INFO - 2018-11-23 11:07:26 --> Model Class Initialized
INFO - 2018-11-23 11:07:26 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-23 11:07:26 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/change-password.php
INFO - 2018-11-23 11:07:26 --> Final output sent to browser
DEBUG - 2018-11-23 11:07:26 --> Total execution time: 0.0560
INFO - 2018-11-23 11:10:16 --> Config Class Initialized
INFO - 2018-11-23 11:10:16 --> Hooks Class Initialized
DEBUG - 2018-11-23 11:10:16 --> UTF-8 Support Enabled
INFO - 2018-11-23 11:10:16 --> Utf8 Class Initialized
INFO - 2018-11-23 11:10:16 --> URI Class Initialized
INFO - 2018-11-23 11:10:16 --> Router Class Initialized
INFO - 2018-11-23 11:10:16 --> Output Class Initialized
INFO - 2018-11-23 11:10:16 --> Security Class Initialized
DEBUG - 2018-11-23 11:10:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-23 11:10:16 --> Input Class Initialized
INFO - 2018-11-23 11:10:16 --> Language Class Initialized
INFO - 2018-11-23 11:10:16 --> Loader Class Initialized
INFO - 2018-11-23 11:10:16 --> Helper loaded: url_helper
INFO - 2018-11-23 11:10:16 --> Helper loaded: file_helper
INFO - 2018-11-23 11:10:16 --> Helper loaded: email_helper
INFO - 2018-11-23 11:10:16 --> Helper loaded: common_helper
INFO - 2018-11-23 11:10:16 --> Database Driver Class Initialized
DEBUG - 2018-11-23 11:10:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-23 11:10:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-23 11:10:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-23 11:10:16 --> Pagination Class Initialized
INFO - 2018-11-23 11:10:16 --> Helper loaded: form_helper
INFO - 2018-11-23 11:10:16 --> Form Validation Class Initialized
INFO - 2018-11-23 11:10:16 --> Model Class Initialized
INFO - 2018-11-23 11:10:16 --> Controller Class Initialized
INFO - 2018-11-23 11:10:16 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-23 11:10:16 --> Model Class Initialized
INFO - 2018-11-23 11:10:16 --> Model Class Initialized
INFO - 2018-11-23 11:10:16 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-23 11:10:16 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/change-password.php
INFO - 2018-11-23 11:10:16 --> Final output sent to browser
DEBUG - 2018-11-23 11:10:16 --> Total execution time: 0.0910
INFO - 2018-11-23 11:13:13 --> Config Class Initialized
INFO - 2018-11-23 11:13:13 --> Hooks Class Initialized
DEBUG - 2018-11-23 11:13:13 --> UTF-8 Support Enabled
INFO - 2018-11-23 11:13:13 --> Utf8 Class Initialized
INFO - 2018-11-23 11:13:13 --> URI Class Initialized
INFO - 2018-11-23 11:13:13 --> Router Class Initialized
INFO - 2018-11-23 11:13:13 --> Output Class Initialized
INFO - 2018-11-23 11:13:13 --> Security Class Initialized
DEBUG - 2018-11-23 11:13:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-23 11:13:13 --> Input Class Initialized
INFO - 2018-11-23 11:13:13 --> Language Class Initialized
INFO - 2018-11-23 11:13:13 --> Loader Class Initialized
INFO - 2018-11-23 11:13:13 --> Helper loaded: url_helper
INFO - 2018-11-23 11:13:13 --> Helper loaded: file_helper
INFO - 2018-11-23 11:13:13 --> Helper loaded: email_helper
INFO - 2018-11-23 11:13:13 --> Helper loaded: common_helper
INFO - 2018-11-23 11:13:13 --> Database Driver Class Initialized
DEBUG - 2018-11-23 11:13:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-23 11:13:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-23 11:13:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-23 11:13:13 --> Pagination Class Initialized
INFO - 2018-11-23 11:13:13 --> Helper loaded: form_helper
INFO - 2018-11-23 11:13:13 --> Form Validation Class Initialized
INFO - 2018-11-23 11:13:13 --> Model Class Initialized
INFO - 2018-11-23 11:13:13 --> Controller Class Initialized
INFO - 2018-11-23 11:13:13 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-23 11:13:13 --> Model Class Initialized
INFO - 2018-11-23 11:13:13 --> Model Class Initialized
INFO - 2018-11-23 11:13:13 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-23 11:13:13 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/change-password.php
INFO - 2018-11-23 11:13:13 --> Final output sent to browser
DEBUG - 2018-11-23 11:13:13 --> Total execution time: 0.0726
INFO - 2018-11-23 11:14:32 --> Config Class Initialized
INFO - 2018-11-23 11:14:32 --> Hooks Class Initialized
DEBUG - 2018-11-23 11:14:32 --> UTF-8 Support Enabled
INFO - 2018-11-23 11:14:32 --> Utf8 Class Initialized
INFO - 2018-11-23 11:14:32 --> URI Class Initialized
INFO - 2018-11-23 11:14:32 --> Router Class Initialized
INFO - 2018-11-23 11:14:32 --> Output Class Initialized
INFO - 2018-11-23 11:14:32 --> Security Class Initialized
DEBUG - 2018-11-23 11:14:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-23 11:14:32 --> Input Class Initialized
INFO - 2018-11-23 11:14:32 --> Language Class Initialized
INFO - 2018-11-23 11:14:32 --> Loader Class Initialized
INFO - 2018-11-23 11:14:32 --> Helper loaded: url_helper
INFO - 2018-11-23 11:14:32 --> Helper loaded: file_helper
INFO - 2018-11-23 11:14:32 --> Helper loaded: email_helper
INFO - 2018-11-23 11:14:32 --> Helper loaded: common_helper
INFO - 2018-11-23 11:14:32 --> Database Driver Class Initialized
DEBUG - 2018-11-23 11:14:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-23 11:14:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-23 11:14:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-23 11:14:32 --> Pagination Class Initialized
INFO - 2018-11-23 11:14:32 --> Helper loaded: form_helper
INFO - 2018-11-23 11:14:32 --> Form Validation Class Initialized
INFO - 2018-11-23 11:14:32 --> Model Class Initialized
INFO - 2018-11-23 11:14:32 --> Controller Class Initialized
INFO - 2018-11-23 11:14:32 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-23 11:14:32 --> Model Class Initialized
INFO - 2018-11-23 11:14:32 --> Model Class Initialized
INFO - 2018-11-23 11:14:32 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-23 11:14:32 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/change-password.php
INFO - 2018-11-23 11:14:32 --> Final output sent to browser
DEBUG - 2018-11-23 11:14:32 --> Total execution time: 0.0700
INFO - 2018-11-23 11:15:23 --> Config Class Initialized
INFO - 2018-11-23 11:15:23 --> Hooks Class Initialized
DEBUG - 2018-11-23 11:15:23 --> UTF-8 Support Enabled
INFO - 2018-11-23 11:15:23 --> Utf8 Class Initialized
INFO - 2018-11-23 11:15:23 --> URI Class Initialized
INFO - 2018-11-23 11:15:23 --> Router Class Initialized
INFO - 2018-11-23 11:15:23 --> Output Class Initialized
INFO - 2018-11-23 11:15:23 --> Security Class Initialized
DEBUG - 2018-11-23 11:15:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-23 11:15:23 --> Input Class Initialized
INFO - 2018-11-23 11:15:23 --> Language Class Initialized
INFO - 2018-11-23 11:15:23 --> Loader Class Initialized
INFO - 2018-11-23 11:15:23 --> Helper loaded: url_helper
INFO - 2018-11-23 11:15:23 --> Helper loaded: file_helper
INFO - 2018-11-23 11:15:23 --> Helper loaded: email_helper
INFO - 2018-11-23 11:15:23 --> Helper loaded: common_helper
INFO - 2018-11-23 11:15:23 --> Database Driver Class Initialized
DEBUG - 2018-11-23 11:15:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-23 11:15:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-23 11:15:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-23 11:15:23 --> Pagination Class Initialized
INFO - 2018-11-23 11:15:23 --> Helper loaded: form_helper
INFO - 2018-11-23 11:15:23 --> Form Validation Class Initialized
INFO - 2018-11-23 11:15:23 --> Model Class Initialized
INFO - 2018-11-23 11:15:23 --> Controller Class Initialized
INFO - 2018-11-23 11:15:23 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-23 11:15:23 --> Model Class Initialized
INFO - 2018-11-23 11:15:23 --> Model Class Initialized
INFO - 2018-11-23 11:15:23 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-23 11:15:23 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/change-password.php
INFO - 2018-11-23 11:15:23 --> Final output sent to browser
DEBUG - 2018-11-23 11:15:23 --> Total execution time: 0.0700
INFO - 2018-11-23 11:15:41 --> Config Class Initialized
INFO - 2018-11-23 11:15:41 --> Hooks Class Initialized
DEBUG - 2018-11-23 11:15:41 --> UTF-8 Support Enabled
INFO - 2018-11-23 11:15:41 --> Utf8 Class Initialized
INFO - 2018-11-23 11:15:41 --> URI Class Initialized
INFO - 2018-11-23 11:15:41 --> Router Class Initialized
INFO - 2018-11-23 11:15:41 --> Output Class Initialized
INFO - 2018-11-23 11:15:41 --> Security Class Initialized
DEBUG - 2018-11-23 11:15:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-23 11:15:41 --> Input Class Initialized
INFO - 2018-11-23 11:15:41 --> Language Class Initialized
INFO - 2018-11-23 11:15:41 --> Loader Class Initialized
INFO - 2018-11-23 11:15:41 --> Helper loaded: url_helper
INFO - 2018-11-23 11:15:41 --> Helper loaded: file_helper
INFO - 2018-11-23 11:15:41 --> Helper loaded: email_helper
INFO - 2018-11-23 11:15:41 --> Helper loaded: common_helper
INFO - 2018-11-23 11:15:41 --> Database Driver Class Initialized
DEBUG - 2018-11-23 11:15:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-23 11:15:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-23 11:15:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-23 11:15:41 --> Pagination Class Initialized
INFO - 2018-11-23 11:15:41 --> Helper loaded: form_helper
INFO - 2018-11-23 11:15:41 --> Form Validation Class Initialized
INFO - 2018-11-23 11:15:41 --> Model Class Initialized
INFO - 2018-11-23 11:15:41 --> Controller Class Initialized
INFO - 2018-11-23 11:15:41 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-23 11:15:41 --> Model Class Initialized
INFO - 2018-11-23 11:15:41 --> Model Class Initialized
INFO - 2018-11-23 11:15:41 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-23 11:15:41 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/change-password.php
INFO - 2018-11-23 11:15:41 --> Final output sent to browser
DEBUG - 2018-11-23 11:15:41 --> Total execution time: 0.0660
INFO - 2018-11-23 11:16:33 --> Config Class Initialized
INFO - 2018-11-23 11:16:33 --> Hooks Class Initialized
DEBUG - 2018-11-23 11:16:33 --> UTF-8 Support Enabled
INFO - 2018-11-23 11:16:33 --> Utf8 Class Initialized
INFO - 2018-11-23 11:16:33 --> URI Class Initialized
INFO - 2018-11-23 11:16:33 --> Router Class Initialized
INFO - 2018-11-23 11:16:33 --> Output Class Initialized
INFO - 2018-11-23 11:16:33 --> Security Class Initialized
DEBUG - 2018-11-23 11:16:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-23 11:16:33 --> Input Class Initialized
INFO - 2018-11-23 11:16:33 --> Language Class Initialized
INFO - 2018-11-23 11:16:33 --> Loader Class Initialized
INFO - 2018-11-23 11:16:33 --> Helper loaded: url_helper
INFO - 2018-11-23 11:16:33 --> Helper loaded: file_helper
INFO - 2018-11-23 11:16:33 --> Helper loaded: email_helper
INFO - 2018-11-23 11:16:33 --> Helper loaded: common_helper
INFO - 2018-11-23 11:16:33 --> Database Driver Class Initialized
DEBUG - 2018-11-23 11:16:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-23 11:16:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-23 11:16:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-23 11:16:33 --> Pagination Class Initialized
INFO - 2018-11-23 11:16:33 --> Helper loaded: form_helper
INFO - 2018-11-23 11:16:33 --> Form Validation Class Initialized
INFO - 2018-11-23 11:16:33 --> Model Class Initialized
INFO - 2018-11-23 11:16:33 --> Controller Class Initialized
INFO - 2018-11-23 11:16:33 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-23 11:16:33 --> Model Class Initialized
INFO - 2018-11-23 11:16:33 --> Model Class Initialized
INFO - 2018-11-23 11:16:33 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-23 11:16:33 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/change-password.php
INFO - 2018-11-23 11:16:33 --> Final output sent to browser
DEBUG - 2018-11-23 11:16:33 --> Total execution time: 0.0590
INFO - 2018-11-23 11:16:47 --> Config Class Initialized
INFO - 2018-11-23 11:16:47 --> Hooks Class Initialized
DEBUG - 2018-11-23 11:16:47 --> UTF-8 Support Enabled
INFO - 2018-11-23 11:16:47 --> Utf8 Class Initialized
INFO - 2018-11-23 11:16:47 --> URI Class Initialized
INFO - 2018-11-23 11:16:47 --> Router Class Initialized
INFO - 2018-11-23 11:16:47 --> Output Class Initialized
INFO - 2018-11-23 11:16:47 --> Security Class Initialized
DEBUG - 2018-11-23 11:16:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-23 11:16:47 --> Input Class Initialized
INFO - 2018-11-23 11:16:47 --> Language Class Initialized
INFO - 2018-11-23 11:16:47 --> Loader Class Initialized
INFO - 2018-11-23 11:16:47 --> Helper loaded: url_helper
INFO - 2018-11-23 11:16:47 --> Helper loaded: file_helper
INFO - 2018-11-23 11:16:47 --> Helper loaded: email_helper
INFO - 2018-11-23 11:16:47 --> Helper loaded: common_helper
INFO - 2018-11-23 11:16:47 --> Database Driver Class Initialized
DEBUG - 2018-11-23 11:16:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-23 11:16:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-23 11:16:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-23 11:16:47 --> Pagination Class Initialized
INFO - 2018-11-23 11:16:47 --> Helper loaded: form_helper
INFO - 2018-11-23 11:16:47 --> Form Validation Class Initialized
INFO - 2018-11-23 11:16:47 --> Model Class Initialized
INFO - 2018-11-23 11:16:47 --> Controller Class Initialized
INFO - 2018-11-23 11:16:47 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-23 11:16:47 --> Model Class Initialized
INFO - 2018-11-23 11:16:47 --> Model Class Initialized
INFO - 2018-11-23 11:16:47 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-23 11:16:47 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/change-password.php
INFO - 2018-11-23 11:16:47 --> Final output sent to browser
DEBUG - 2018-11-23 11:16:47 --> Total execution time: 0.0580
INFO - 2018-11-23 11:17:20 --> Config Class Initialized
INFO - 2018-11-23 11:17:20 --> Hooks Class Initialized
DEBUG - 2018-11-23 11:17:20 --> UTF-8 Support Enabled
INFO - 2018-11-23 11:17:20 --> Utf8 Class Initialized
INFO - 2018-11-23 11:17:20 --> URI Class Initialized
INFO - 2018-11-23 11:17:20 --> Router Class Initialized
INFO - 2018-11-23 11:17:20 --> Output Class Initialized
INFO - 2018-11-23 11:17:20 --> Security Class Initialized
DEBUG - 2018-11-23 11:17:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-23 11:17:20 --> Input Class Initialized
INFO - 2018-11-23 11:17:20 --> Language Class Initialized
INFO - 2018-11-23 11:17:20 --> Loader Class Initialized
INFO - 2018-11-23 11:17:20 --> Helper loaded: url_helper
INFO - 2018-11-23 11:17:20 --> Helper loaded: file_helper
INFO - 2018-11-23 11:17:20 --> Helper loaded: email_helper
INFO - 2018-11-23 11:17:20 --> Helper loaded: common_helper
INFO - 2018-11-23 11:17:20 --> Database Driver Class Initialized
DEBUG - 2018-11-23 11:17:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-23 11:17:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-23 11:17:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-23 11:17:20 --> Pagination Class Initialized
INFO - 2018-11-23 11:17:20 --> Helper loaded: form_helper
INFO - 2018-11-23 11:17:20 --> Form Validation Class Initialized
INFO - 2018-11-23 11:17:20 --> Model Class Initialized
INFO - 2018-11-23 11:17:20 --> Controller Class Initialized
INFO - 2018-11-23 11:17:20 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-23 11:17:20 --> Model Class Initialized
INFO - 2018-11-23 11:17:20 --> Model Class Initialized
INFO - 2018-11-23 11:17:20 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-23 11:17:20 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/change-password.php
INFO - 2018-11-23 11:17:20 --> Final output sent to browser
DEBUG - 2018-11-23 11:17:20 --> Total execution time: 0.0670
INFO - 2018-11-23 11:17:53 --> Config Class Initialized
INFO - 2018-11-23 11:17:53 --> Hooks Class Initialized
DEBUG - 2018-11-23 11:17:53 --> UTF-8 Support Enabled
INFO - 2018-11-23 11:17:53 --> Utf8 Class Initialized
INFO - 2018-11-23 11:17:53 --> URI Class Initialized
INFO - 2018-11-23 11:17:53 --> Router Class Initialized
INFO - 2018-11-23 11:17:53 --> Output Class Initialized
INFO - 2018-11-23 11:17:53 --> Security Class Initialized
DEBUG - 2018-11-23 11:17:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-23 11:17:53 --> Input Class Initialized
INFO - 2018-11-23 11:17:53 --> Language Class Initialized
INFO - 2018-11-23 11:17:53 --> Loader Class Initialized
INFO - 2018-11-23 11:17:53 --> Helper loaded: url_helper
INFO - 2018-11-23 11:17:53 --> Helper loaded: file_helper
INFO - 2018-11-23 11:17:53 --> Helper loaded: email_helper
INFO - 2018-11-23 11:17:53 --> Helper loaded: common_helper
INFO - 2018-11-23 11:17:53 --> Database Driver Class Initialized
DEBUG - 2018-11-23 11:17:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-23 11:17:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-23 11:17:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-23 11:17:53 --> Pagination Class Initialized
INFO - 2018-11-23 11:17:53 --> Helper loaded: form_helper
INFO - 2018-11-23 11:17:53 --> Form Validation Class Initialized
INFO - 2018-11-23 11:17:53 --> Model Class Initialized
INFO - 2018-11-23 11:17:53 --> Controller Class Initialized
INFO - 2018-11-23 11:17:53 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-23 11:17:53 --> Model Class Initialized
INFO - 2018-11-23 11:17:53 --> Model Class Initialized
INFO - 2018-11-23 11:17:53 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-23 11:17:53 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/change-password.php
INFO - 2018-11-23 11:17:53 --> Final output sent to browser
DEBUG - 2018-11-23 11:17:53 --> Total execution time: 0.0900
INFO - 2018-11-23 11:18:12 --> Config Class Initialized
INFO - 2018-11-23 11:18:12 --> Hooks Class Initialized
DEBUG - 2018-11-23 11:18:12 --> UTF-8 Support Enabled
INFO - 2018-11-23 11:18:12 --> Utf8 Class Initialized
INFO - 2018-11-23 11:18:12 --> URI Class Initialized
INFO - 2018-11-23 11:18:12 --> Router Class Initialized
INFO - 2018-11-23 11:18:12 --> Output Class Initialized
INFO - 2018-11-23 11:18:12 --> Security Class Initialized
DEBUG - 2018-11-23 11:18:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-23 11:18:12 --> Input Class Initialized
INFO - 2018-11-23 11:18:12 --> Language Class Initialized
INFO - 2018-11-23 11:18:12 --> Loader Class Initialized
INFO - 2018-11-23 11:18:12 --> Helper loaded: url_helper
INFO - 2018-11-23 11:18:12 --> Helper loaded: file_helper
INFO - 2018-11-23 11:18:12 --> Helper loaded: email_helper
INFO - 2018-11-23 11:18:12 --> Helper loaded: common_helper
INFO - 2018-11-23 11:18:12 --> Database Driver Class Initialized
DEBUG - 2018-11-23 11:18:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-23 11:18:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-23 11:18:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-23 11:18:12 --> Pagination Class Initialized
INFO - 2018-11-23 11:18:12 --> Helper loaded: form_helper
INFO - 2018-11-23 11:18:12 --> Form Validation Class Initialized
INFO - 2018-11-23 11:18:12 --> Model Class Initialized
INFO - 2018-11-23 11:18:12 --> Controller Class Initialized
INFO - 2018-11-23 11:18:12 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-23 11:18:12 --> Model Class Initialized
INFO - 2018-11-23 11:18:12 --> Model Class Initialized
INFO - 2018-11-23 11:18:12 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-23 11:18:12 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/change-password.php
INFO - 2018-11-23 11:18:12 --> Final output sent to browser
DEBUG - 2018-11-23 11:18:12 --> Total execution time: 0.0600
INFO - 2018-11-23 11:21:42 --> Config Class Initialized
INFO - 2018-11-23 11:21:42 --> Hooks Class Initialized
DEBUG - 2018-11-23 11:21:42 --> UTF-8 Support Enabled
INFO - 2018-11-23 11:21:42 --> Utf8 Class Initialized
INFO - 2018-11-23 11:21:42 --> URI Class Initialized
INFO - 2018-11-23 11:21:42 --> Router Class Initialized
INFO - 2018-11-23 11:21:42 --> Output Class Initialized
INFO - 2018-11-23 11:21:42 --> Security Class Initialized
DEBUG - 2018-11-23 11:21:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-23 11:21:42 --> Input Class Initialized
INFO - 2018-11-23 11:21:42 --> Language Class Initialized
INFO - 2018-11-23 11:21:42 --> Loader Class Initialized
INFO - 2018-11-23 11:21:42 --> Helper loaded: url_helper
INFO - 2018-11-23 11:21:42 --> Helper loaded: file_helper
INFO - 2018-11-23 11:21:42 --> Helper loaded: email_helper
INFO - 2018-11-23 11:21:42 --> Helper loaded: common_helper
INFO - 2018-11-23 11:21:42 --> Database Driver Class Initialized
DEBUG - 2018-11-23 11:21:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-23 11:21:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-23 11:21:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-23 11:21:42 --> Pagination Class Initialized
INFO - 2018-11-23 11:21:42 --> Helper loaded: form_helper
INFO - 2018-11-23 11:21:42 --> Form Validation Class Initialized
INFO - 2018-11-23 11:21:42 --> Model Class Initialized
INFO - 2018-11-23 11:21:42 --> Controller Class Initialized
INFO - 2018-11-23 11:21:42 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-23 11:21:42 --> Model Class Initialized
INFO - 2018-11-23 11:21:42 --> Model Class Initialized
INFO - 2018-11-23 11:21:42 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-23 11:21:42 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/change-password.php
INFO - 2018-11-23 11:21:42 --> Final output sent to browser
DEBUG - 2018-11-23 11:21:42 --> Total execution time: 0.0690
INFO - 2018-11-23 11:22:00 --> Config Class Initialized
INFO - 2018-11-23 11:22:00 --> Hooks Class Initialized
DEBUG - 2018-11-23 11:22:00 --> UTF-8 Support Enabled
INFO - 2018-11-23 11:22:00 --> Utf8 Class Initialized
INFO - 2018-11-23 11:22:00 --> URI Class Initialized
INFO - 2018-11-23 11:22:00 --> Router Class Initialized
INFO - 2018-11-23 11:22:00 --> Output Class Initialized
INFO - 2018-11-23 11:22:00 --> Security Class Initialized
DEBUG - 2018-11-23 11:22:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-23 11:22:00 --> Input Class Initialized
INFO - 2018-11-23 11:22:00 --> Language Class Initialized
INFO - 2018-11-23 11:22:00 --> Loader Class Initialized
INFO - 2018-11-23 11:22:00 --> Helper loaded: url_helper
INFO - 2018-11-23 11:22:00 --> Helper loaded: file_helper
INFO - 2018-11-23 11:22:00 --> Helper loaded: email_helper
INFO - 2018-11-23 11:22:00 --> Helper loaded: common_helper
INFO - 2018-11-23 11:22:00 --> Database Driver Class Initialized
DEBUG - 2018-11-23 11:22:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-23 11:22:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-23 11:22:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-23 11:22:00 --> Pagination Class Initialized
INFO - 2018-11-23 11:22:00 --> Helper loaded: form_helper
INFO - 2018-11-23 11:22:00 --> Form Validation Class Initialized
INFO - 2018-11-23 11:22:00 --> Model Class Initialized
INFO - 2018-11-23 11:22:00 --> Controller Class Initialized
INFO - 2018-11-23 11:22:00 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-23 11:22:00 --> Model Class Initialized
INFO - 2018-11-23 11:22:00 --> Model Class Initialized
INFO - 2018-11-23 11:22:00 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-23 11:22:00 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/change-password.php
INFO - 2018-11-23 11:22:00 --> Final output sent to browser
DEBUG - 2018-11-23 11:22:00 --> Total execution time: 0.0540
INFO - 2018-11-23 11:22:40 --> Config Class Initialized
INFO - 2018-11-23 11:22:40 --> Hooks Class Initialized
DEBUG - 2018-11-23 11:22:40 --> UTF-8 Support Enabled
INFO - 2018-11-23 11:22:40 --> Utf8 Class Initialized
INFO - 2018-11-23 11:22:40 --> URI Class Initialized
INFO - 2018-11-23 11:22:40 --> Router Class Initialized
INFO - 2018-11-23 11:22:40 --> Output Class Initialized
INFO - 2018-11-23 11:22:40 --> Security Class Initialized
DEBUG - 2018-11-23 11:22:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-23 11:22:40 --> Input Class Initialized
INFO - 2018-11-23 11:22:40 --> Language Class Initialized
INFO - 2018-11-23 11:22:40 --> Loader Class Initialized
INFO - 2018-11-23 11:22:40 --> Helper loaded: url_helper
INFO - 2018-11-23 11:22:40 --> Helper loaded: file_helper
INFO - 2018-11-23 11:22:40 --> Helper loaded: email_helper
INFO - 2018-11-23 11:22:40 --> Helper loaded: common_helper
INFO - 2018-11-23 11:22:40 --> Database Driver Class Initialized
DEBUG - 2018-11-23 11:22:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-23 11:22:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-23 11:22:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-23 11:22:40 --> Pagination Class Initialized
INFO - 2018-11-23 11:22:40 --> Helper loaded: form_helper
INFO - 2018-11-23 11:22:40 --> Form Validation Class Initialized
INFO - 2018-11-23 11:22:40 --> Model Class Initialized
INFO - 2018-11-23 11:22:40 --> Controller Class Initialized
INFO - 2018-11-23 11:22:40 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-23 11:22:40 --> Model Class Initialized
INFO - 2018-11-23 11:22:40 --> Model Class Initialized
INFO - 2018-11-23 11:22:40 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-23 11:22:40 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/change-password.php
INFO - 2018-11-23 11:22:40 --> Final output sent to browser
DEBUG - 2018-11-23 11:22:40 --> Total execution time: 0.0786
INFO - 2018-11-23 11:23:36 --> Config Class Initialized
INFO - 2018-11-23 11:23:36 --> Hooks Class Initialized
DEBUG - 2018-11-23 11:23:36 --> UTF-8 Support Enabled
INFO - 2018-11-23 11:23:36 --> Utf8 Class Initialized
INFO - 2018-11-23 11:23:36 --> URI Class Initialized
INFO - 2018-11-23 11:23:36 --> Router Class Initialized
INFO - 2018-11-23 11:23:36 --> Output Class Initialized
INFO - 2018-11-23 11:23:36 --> Security Class Initialized
DEBUG - 2018-11-23 11:23:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-23 11:23:36 --> Input Class Initialized
INFO - 2018-11-23 11:23:36 --> Language Class Initialized
INFO - 2018-11-23 11:23:36 --> Loader Class Initialized
INFO - 2018-11-23 11:23:36 --> Helper loaded: url_helper
INFO - 2018-11-23 11:23:36 --> Helper loaded: file_helper
INFO - 2018-11-23 11:23:36 --> Helper loaded: email_helper
INFO - 2018-11-23 11:23:36 --> Helper loaded: common_helper
INFO - 2018-11-23 11:23:36 --> Database Driver Class Initialized
DEBUG - 2018-11-23 11:23:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-23 11:23:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-23 11:23:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-23 11:23:36 --> Pagination Class Initialized
INFO - 2018-11-23 11:23:36 --> Helper loaded: form_helper
INFO - 2018-11-23 11:23:36 --> Form Validation Class Initialized
INFO - 2018-11-23 11:23:36 --> Model Class Initialized
INFO - 2018-11-23 11:23:36 --> Controller Class Initialized
INFO - 2018-11-23 11:23:36 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-23 11:23:36 --> Model Class Initialized
INFO - 2018-11-23 11:23:36 --> Model Class Initialized
INFO - 2018-11-23 11:23:36 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-23 11:23:36 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/change-password.php
INFO - 2018-11-23 11:23:36 --> Final output sent to browser
DEBUG - 2018-11-23 11:23:36 --> Total execution time: 0.0700
INFO - 2018-11-23 11:24:00 --> Config Class Initialized
INFO - 2018-11-23 11:24:00 --> Hooks Class Initialized
DEBUG - 2018-11-23 11:24:00 --> UTF-8 Support Enabled
INFO - 2018-11-23 11:24:00 --> Utf8 Class Initialized
INFO - 2018-11-23 11:24:00 --> URI Class Initialized
INFO - 2018-11-23 11:24:00 --> Router Class Initialized
INFO - 2018-11-23 11:24:00 --> Output Class Initialized
INFO - 2018-11-23 11:24:00 --> Security Class Initialized
DEBUG - 2018-11-23 11:24:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-23 11:24:00 --> Input Class Initialized
INFO - 2018-11-23 11:24:00 --> Language Class Initialized
INFO - 2018-11-23 11:24:00 --> Loader Class Initialized
INFO - 2018-11-23 11:24:00 --> Helper loaded: url_helper
INFO - 2018-11-23 11:24:00 --> Helper loaded: file_helper
INFO - 2018-11-23 11:24:00 --> Helper loaded: email_helper
INFO - 2018-11-23 11:24:00 --> Helper loaded: common_helper
INFO - 2018-11-23 11:24:00 --> Database Driver Class Initialized
DEBUG - 2018-11-23 11:24:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-23 11:24:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-23 11:24:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-23 11:24:00 --> Pagination Class Initialized
INFO - 2018-11-23 11:24:00 --> Helper loaded: form_helper
INFO - 2018-11-23 11:24:00 --> Form Validation Class Initialized
INFO - 2018-11-23 11:24:00 --> Model Class Initialized
INFO - 2018-11-23 11:24:00 --> Controller Class Initialized
INFO - 2018-11-23 11:24:00 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-23 11:24:00 --> Model Class Initialized
INFO - 2018-11-23 11:24:00 --> Model Class Initialized
INFO - 2018-11-23 11:24:00 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-23 11:24:00 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/change-password.php
INFO - 2018-11-23 11:24:00 --> Final output sent to browser
DEBUG - 2018-11-23 11:24:00 --> Total execution time: 0.0710
INFO - 2018-11-23 11:27:27 --> Config Class Initialized
INFO - 2018-11-23 11:27:27 --> Hooks Class Initialized
DEBUG - 2018-11-23 11:27:27 --> UTF-8 Support Enabled
INFO - 2018-11-23 11:27:27 --> Utf8 Class Initialized
INFO - 2018-11-23 11:27:27 --> URI Class Initialized
INFO - 2018-11-23 11:27:27 --> Router Class Initialized
INFO - 2018-11-23 11:27:27 --> Output Class Initialized
INFO - 2018-11-23 11:27:27 --> Security Class Initialized
DEBUG - 2018-11-23 11:27:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-23 11:27:27 --> Input Class Initialized
INFO - 2018-11-23 11:27:27 --> Language Class Initialized
INFO - 2018-11-23 11:27:27 --> Loader Class Initialized
INFO - 2018-11-23 11:27:27 --> Helper loaded: url_helper
INFO - 2018-11-23 11:27:27 --> Helper loaded: file_helper
INFO - 2018-11-23 11:27:27 --> Helper loaded: email_helper
INFO - 2018-11-23 11:27:27 --> Helper loaded: common_helper
INFO - 2018-11-23 11:27:27 --> Database Driver Class Initialized
DEBUG - 2018-11-23 11:27:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-23 11:27:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-23 11:27:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-23 11:27:27 --> Pagination Class Initialized
INFO - 2018-11-23 11:27:27 --> Helper loaded: form_helper
INFO - 2018-11-23 11:27:27 --> Form Validation Class Initialized
INFO - 2018-11-23 11:27:27 --> Model Class Initialized
INFO - 2018-11-23 11:27:27 --> Controller Class Initialized
INFO - 2018-11-23 11:27:27 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-23 11:27:27 --> Model Class Initialized
INFO - 2018-11-23 11:27:27 --> Model Class Initialized
INFO - 2018-11-23 11:27:27 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-23 11:27:27 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/change-password.php
INFO - 2018-11-23 11:27:27 --> Final output sent to browser
DEBUG - 2018-11-23 11:27:27 --> Total execution time: 0.0570
INFO - 2018-11-23 11:29:18 --> Config Class Initialized
INFO - 2018-11-23 11:29:18 --> Hooks Class Initialized
DEBUG - 2018-11-23 11:29:18 --> UTF-8 Support Enabled
INFO - 2018-11-23 11:29:18 --> Utf8 Class Initialized
INFO - 2018-11-23 11:29:18 --> URI Class Initialized
INFO - 2018-11-23 11:29:18 --> Router Class Initialized
INFO - 2018-11-23 11:29:18 --> Output Class Initialized
INFO - 2018-11-23 11:29:18 --> Security Class Initialized
DEBUG - 2018-11-23 11:29:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-23 11:29:18 --> Input Class Initialized
INFO - 2018-11-23 11:29:18 --> Language Class Initialized
INFO - 2018-11-23 11:29:18 --> Loader Class Initialized
INFO - 2018-11-23 11:29:18 --> Helper loaded: url_helper
INFO - 2018-11-23 11:29:18 --> Helper loaded: file_helper
INFO - 2018-11-23 11:29:18 --> Helper loaded: email_helper
INFO - 2018-11-23 11:29:18 --> Helper loaded: common_helper
INFO - 2018-11-23 11:29:18 --> Database Driver Class Initialized
DEBUG - 2018-11-23 11:29:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-23 11:29:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-23 11:29:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-23 11:29:19 --> Pagination Class Initialized
INFO - 2018-11-23 11:29:19 --> Helper loaded: form_helper
INFO - 2018-11-23 11:29:19 --> Form Validation Class Initialized
INFO - 2018-11-23 11:29:19 --> Model Class Initialized
INFO - 2018-11-23 11:29:19 --> Controller Class Initialized
INFO - 2018-11-23 11:29:19 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-23 11:29:19 --> Model Class Initialized
INFO - 2018-11-23 11:29:19 --> Model Class Initialized
INFO - 2018-11-23 11:29:19 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-23 11:29:19 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/change-password.php
INFO - 2018-11-23 11:29:19 --> Final output sent to browser
DEBUG - 2018-11-23 11:29:19 --> Total execution time: 0.0590
INFO - 2018-11-23 11:30:02 --> Config Class Initialized
INFO - 2018-11-23 11:30:02 --> Hooks Class Initialized
DEBUG - 2018-11-23 11:30:02 --> UTF-8 Support Enabled
INFO - 2018-11-23 11:30:02 --> Utf8 Class Initialized
INFO - 2018-11-23 11:30:02 --> URI Class Initialized
INFO - 2018-11-23 11:30:02 --> Router Class Initialized
INFO - 2018-11-23 11:30:02 --> Output Class Initialized
INFO - 2018-11-23 11:30:02 --> Security Class Initialized
DEBUG - 2018-11-23 11:30:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-23 11:30:02 --> Input Class Initialized
INFO - 2018-11-23 11:30:02 --> Language Class Initialized
INFO - 2018-11-23 11:30:02 --> Loader Class Initialized
INFO - 2018-11-23 11:30:02 --> Helper loaded: url_helper
INFO - 2018-11-23 11:30:02 --> Helper loaded: file_helper
INFO - 2018-11-23 11:30:02 --> Helper loaded: email_helper
INFO - 2018-11-23 11:30:02 --> Helper loaded: common_helper
INFO - 2018-11-23 11:30:02 --> Database Driver Class Initialized
DEBUG - 2018-11-23 11:30:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-23 11:30:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-23 11:30:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-23 11:30:02 --> Pagination Class Initialized
INFO - 2018-11-23 11:30:02 --> Helper loaded: form_helper
INFO - 2018-11-23 11:30:02 --> Form Validation Class Initialized
INFO - 2018-11-23 11:30:02 --> Model Class Initialized
INFO - 2018-11-23 11:30:02 --> Controller Class Initialized
INFO - 2018-11-23 11:30:02 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-23 11:30:02 --> Model Class Initialized
INFO - 2018-11-23 11:30:02 --> Model Class Initialized
INFO - 2018-11-23 11:30:02 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-23 11:30:02 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/change-password.php
INFO - 2018-11-23 11:30:02 --> Final output sent to browser
DEBUG - 2018-11-23 11:30:02 --> Total execution time: 0.0640
INFO - 2018-11-23 11:33:17 --> Config Class Initialized
INFO - 2018-11-23 11:33:17 --> Hooks Class Initialized
DEBUG - 2018-11-23 11:33:17 --> UTF-8 Support Enabled
INFO - 2018-11-23 11:33:17 --> Utf8 Class Initialized
INFO - 2018-11-23 11:33:17 --> URI Class Initialized
INFO - 2018-11-23 11:33:17 --> Router Class Initialized
INFO - 2018-11-23 11:33:17 --> Output Class Initialized
INFO - 2018-11-23 11:33:17 --> Security Class Initialized
DEBUG - 2018-11-23 11:33:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-23 11:33:17 --> Input Class Initialized
INFO - 2018-11-23 11:33:17 --> Language Class Initialized
INFO - 2018-11-23 11:33:17 --> Loader Class Initialized
INFO - 2018-11-23 11:33:17 --> Helper loaded: url_helper
INFO - 2018-11-23 11:33:17 --> Helper loaded: file_helper
INFO - 2018-11-23 11:33:17 --> Helper loaded: email_helper
INFO - 2018-11-23 11:33:17 --> Helper loaded: common_helper
INFO - 2018-11-23 11:33:17 --> Database Driver Class Initialized
DEBUG - 2018-11-23 11:33:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-23 11:33:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-23 11:33:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-23 11:33:17 --> Pagination Class Initialized
INFO - 2018-11-23 11:33:17 --> Helper loaded: form_helper
INFO - 2018-11-23 11:33:17 --> Form Validation Class Initialized
INFO - 2018-11-23 11:33:17 --> Model Class Initialized
INFO - 2018-11-23 11:33:17 --> Controller Class Initialized
INFO - 2018-11-23 11:33:17 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-23 11:33:17 --> Model Class Initialized
INFO - 2018-11-23 11:33:17 --> Model Class Initialized
INFO - 2018-11-23 11:33:17 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-23 11:33:17 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/change-password.php
INFO - 2018-11-23 11:33:17 --> Final output sent to browser
DEBUG - 2018-11-23 11:33:17 --> Total execution time: 0.0460
INFO - 2018-11-23 11:37:14 --> Config Class Initialized
INFO - 2018-11-23 11:37:14 --> Hooks Class Initialized
DEBUG - 2018-11-23 11:37:14 --> UTF-8 Support Enabled
INFO - 2018-11-23 11:37:14 --> Utf8 Class Initialized
INFO - 2018-11-23 11:37:14 --> URI Class Initialized
INFO - 2018-11-23 11:37:14 --> Router Class Initialized
INFO - 2018-11-23 11:37:14 --> Output Class Initialized
INFO - 2018-11-23 11:37:14 --> Security Class Initialized
DEBUG - 2018-11-23 11:37:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-23 11:37:14 --> Input Class Initialized
INFO - 2018-11-23 11:37:14 --> Language Class Initialized
INFO - 2018-11-23 11:37:14 --> Loader Class Initialized
INFO - 2018-11-23 11:37:14 --> Helper loaded: url_helper
INFO - 2018-11-23 11:37:14 --> Helper loaded: file_helper
INFO - 2018-11-23 11:37:14 --> Helper loaded: email_helper
INFO - 2018-11-23 11:37:14 --> Helper loaded: common_helper
INFO - 2018-11-23 11:37:14 --> Database Driver Class Initialized
DEBUG - 2018-11-23 11:37:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-23 11:37:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-23 11:37:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-23 11:37:14 --> Pagination Class Initialized
INFO - 2018-11-23 11:37:14 --> Helper loaded: form_helper
INFO - 2018-11-23 11:37:14 --> Form Validation Class Initialized
INFO - 2018-11-23 11:37:14 --> Model Class Initialized
INFO - 2018-11-23 11:37:14 --> Controller Class Initialized
INFO - 2018-11-23 11:37:14 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-23 11:37:14 --> Model Class Initialized
INFO - 2018-11-23 11:37:14 --> Model Class Initialized
INFO - 2018-11-23 11:37:14 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-23 11:37:14 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/change-password.php
INFO - 2018-11-23 11:37:14 --> Final output sent to browser
DEBUG - 2018-11-23 11:37:14 --> Total execution time: 0.0550
INFO - 2018-11-23 11:37:24 --> Config Class Initialized
INFO - 2018-11-23 11:37:24 --> Hooks Class Initialized
DEBUG - 2018-11-23 11:37:24 --> UTF-8 Support Enabled
INFO - 2018-11-23 11:37:24 --> Utf8 Class Initialized
INFO - 2018-11-23 11:37:25 --> URI Class Initialized
INFO - 2018-11-23 11:37:25 --> Router Class Initialized
INFO - 2018-11-23 11:37:25 --> Output Class Initialized
INFO - 2018-11-23 11:37:25 --> Security Class Initialized
DEBUG - 2018-11-23 11:37:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-23 11:37:25 --> Input Class Initialized
INFO - 2018-11-23 11:37:25 --> Language Class Initialized
INFO - 2018-11-23 11:37:25 --> Loader Class Initialized
INFO - 2018-11-23 11:37:25 --> Helper loaded: url_helper
INFO - 2018-11-23 11:37:25 --> Helper loaded: file_helper
INFO - 2018-11-23 11:37:25 --> Helper loaded: email_helper
INFO - 2018-11-23 11:37:25 --> Helper loaded: common_helper
INFO - 2018-11-23 11:37:25 --> Database Driver Class Initialized
DEBUG - 2018-11-23 11:37:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-23 11:37:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-23 11:37:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-23 11:37:25 --> Pagination Class Initialized
INFO - 2018-11-23 11:37:25 --> Helper loaded: form_helper
INFO - 2018-11-23 11:37:25 --> Form Validation Class Initialized
INFO - 2018-11-23 11:37:25 --> Model Class Initialized
INFO - 2018-11-23 11:37:25 --> Controller Class Initialized
INFO - 2018-11-23 11:37:25 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-23 11:37:25 --> Model Class Initialized
INFO - 2018-11-23 11:37:25 --> Model Class Initialized
INFO - 2018-11-23 11:37:56 --> Config Class Initialized
INFO - 2018-11-23 11:37:56 --> Hooks Class Initialized
DEBUG - 2018-11-23 11:37:56 --> UTF-8 Support Enabled
INFO - 2018-11-23 11:37:56 --> Utf8 Class Initialized
INFO - 2018-11-23 11:37:56 --> URI Class Initialized
INFO - 2018-11-23 11:37:56 --> Router Class Initialized
INFO - 2018-11-23 11:37:56 --> Output Class Initialized
INFO - 2018-11-23 11:37:56 --> Security Class Initialized
DEBUG - 2018-11-23 11:37:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-23 11:37:56 --> Input Class Initialized
INFO - 2018-11-23 11:37:56 --> Language Class Initialized
INFO - 2018-11-23 11:37:56 --> Loader Class Initialized
INFO - 2018-11-23 11:37:56 --> Helper loaded: url_helper
INFO - 2018-11-23 11:37:56 --> Helper loaded: file_helper
INFO - 2018-11-23 11:37:56 --> Helper loaded: email_helper
INFO - 2018-11-23 11:37:56 --> Helper loaded: common_helper
INFO - 2018-11-23 11:37:56 --> Database Driver Class Initialized
DEBUG - 2018-11-23 11:37:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-23 11:37:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-23 11:37:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-23 11:37:56 --> Pagination Class Initialized
INFO - 2018-11-23 11:37:56 --> Helper loaded: form_helper
INFO - 2018-11-23 11:37:56 --> Form Validation Class Initialized
INFO - 2018-11-23 11:37:56 --> Model Class Initialized
INFO - 2018-11-23 11:37:56 --> Controller Class Initialized
INFO - 2018-11-23 11:37:56 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-23 11:37:56 --> Model Class Initialized
INFO - 2018-11-23 11:37:56 --> Model Class Initialized
ERROR - 2018-11-23 11:37:56 --> Query error: Unknown column 'password' in 'where clause' - Invalid query: SELECT `admin_id`
FROM `admin_master`
WHERE `password` = 'e6e061838856bf47e1de730719fb2609'
AND `admin_id` IS NULL
INFO - 2018-11-23 11:37:56 --> Language file loaded: language/english/db_lang.php
INFO - 2018-11-23 11:38:17 --> Config Class Initialized
INFO - 2018-11-23 11:38:17 --> Hooks Class Initialized
DEBUG - 2018-11-23 11:38:17 --> UTF-8 Support Enabled
INFO - 2018-11-23 11:38:17 --> Utf8 Class Initialized
INFO - 2018-11-23 11:38:17 --> URI Class Initialized
INFO - 2018-11-23 11:38:17 --> Router Class Initialized
INFO - 2018-11-23 11:38:17 --> Output Class Initialized
INFO - 2018-11-23 11:38:17 --> Security Class Initialized
DEBUG - 2018-11-23 11:38:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-23 11:38:17 --> Input Class Initialized
INFO - 2018-11-23 11:38:17 --> Language Class Initialized
INFO - 2018-11-23 11:38:17 --> Loader Class Initialized
INFO - 2018-11-23 11:38:17 --> Helper loaded: url_helper
INFO - 2018-11-23 11:38:17 --> Helper loaded: file_helper
INFO - 2018-11-23 11:38:17 --> Helper loaded: email_helper
INFO - 2018-11-23 11:38:17 --> Helper loaded: common_helper
INFO - 2018-11-23 11:38:17 --> Database Driver Class Initialized
DEBUG - 2018-11-23 11:38:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-23 11:38:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-23 11:38:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-23 11:38:17 --> Pagination Class Initialized
INFO - 2018-11-23 11:38:17 --> Helper loaded: form_helper
INFO - 2018-11-23 11:38:17 --> Form Validation Class Initialized
INFO - 2018-11-23 11:38:17 --> Model Class Initialized
INFO - 2018-11-23 11:38:17 --> Controller Class Initialized
INFO - 2018-11-23 11:38:17 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-23 11:38:17 --> Model Class Initialized
INFO - 2018-11-23 11:38:17 --> Model Class Initialized
INFO - 2018-11-23 11:38:17 --> Config Class Initialized
INFO - 2018-11-23 11:38:17 --> Hooks Class Initialized
DEBUG - 2018-11-23 11:38:17 --> UTF-8 Support Enabled
INFO - 2018-11-23 11:38:17 --> Utf8 Class Initialized
INFO - 2018-11-23 11:38:17 --> URI Class Initialized
INFO - 2018-11-23 11:38:17 --> Router Class Initialized
INFO - 2018-11-23 11:38:17 --> Output Class Initialized
INFO - 2018-11-23 11:38:17 --> Security Class Initialized
DEBUG - 2018-11-23 11:38:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-23 11:38:17 --> Input Class Initialized
INFO - 2018-11-23 11:38:17 --> Language Class Initialized
ERROR - 2018-11-23 11:38:17 --> 404 Page Not Found: admin/Change_password/index
INFO - 2018-11-23 11:38:20 --> Config Class Initialized
INFO - 2018-11-23 11:38:20 --> Hooks Class Initialized
DEBUG - 2018-11-23 11:38:20 --> UTF-8 Support Enabled
INFO - 2018-11-23 11:38:20 --> Utf8 Class Initialized
INFO - 2018-11-23 11:38:20 --> URI Class Initialized
INFO - 2018-11-23 11:38:20 --> Router Class Initialized
INFO - 2018-11-23 11:38:20 --> Output Class Initialized
INFO - 2018-11-23 11:38:20 --> Security Class Initialized
DEBUG - 2018-11-23 11:38:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-23 11:38:20 --> Input Class Initialized
INFO - 2018-11-23 11:38:20 --> Language Class Initialized
ERROR - 2018-11-23 11:38:20 --> 404 Page Not Found: admin/Change_password/index
INFO - 2018-11-23 11:38:23 --> Config Class Initialized
INFO - 2018-11-23 11:38:23 --> Hooks Class Initialized
DEBUG - 2018-11-23 11:38:23 --> UTF-8 Support Enabled
INFO - 2018-11-23 11:38:23 --> Utf8 Class Initialized
INFO - 2018-11-23 11:38:23 --> URI Class Initialized
INFO - 2018-11-23 11:38:23 --> Router Class Initialized
INFO - 2018-11-23 11:38:23 --> Output Class Initialized
INFO - 2018-11-23 11:38:23 --> Security Class Initialized
DEBUG - 2018-11-23 11:38:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-23 11:38:23 --> Input Class Initialized
INFO - 2018-11-23 11:38:23 --> Language Class Initialized
ERROR - 2018-11-23 11:38:23 --> 404 Page Not Found: admin/Change_password/index
INFO - 2018-11-23 11:38:28 --> Config Class Initialized
INFO - 2018-11-23 11:38:28 --> Hooks Class Initialized
DEBUG - 2018-11-23 11:38:28 --> UTF-8 Support Enabled
INFO - 2018-11-23 11:38:28 --> Utf8 Class Initialized
INFO - 2018-11-23 11:38:28 --> URI Class Initialized
INFO - 2018-11-23 11:38:28 --> Router Class Initialized
INFO - 2018-11-23 11:38:28 --> Output Class Initialized
INFO - 2018-11-23 11:38:28 --> Security Class Initialized
DEBUG - 2018-11-23 11:38:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-23 11:38:28 --> Input Class Initialized
INFO - 2018-11-23 11:38:28 --> Language Class Initialized
ERROR - 2018-11-23 11:38:28 --> 404 Page Not Found: admin/Change_password/index
INFO - 2018-11-23 11:38:30 --> Config Class Initialized
INFO - 2018-11-23 11:38:30 --> Hooks Class Initialized
DEBUG - 2018-11-23 11:38:30 --> UTF-8 Support Enabled
INFO - 2018-11-23 11:38:30 --> Utf8 Class Initialized
INFO - 2018-11-23 11:38:30 --> URI Class Initialized
INFO - 2018-11-23 11:38:30 --> Router Class Initialized
INFO - 2018-11-23 11:38:30 --> Output Class Initialized
INFO - 2018-11-23 11:38:30 --> Security Class Initialized
DEBUG - 2018-11-23 11:38:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-23 11:38:31 --> Input Class Initialized
INFO - 2018-11-23 11:38:31 --> Language Class Initialized
ERROR - 2018-11-23 11:38:31 --> 404 Page Not Found: admin/Change_password/index
INFO - 2018-11-23 11:39:14 --> Config Class Initialized
INFO - 2018-11-23 11:39:14 --> Hooks Class Initialized
DEBUG - 2018-11-23 11:39:14 --> UTF-8 Support Enabled
INFO - 2018-11-23 11:39:14 --> Utf8 Class Initialized
INFO - 2018-11-23 11:39:14 --> URI Class Initialized
INFO - 2018-11-23 11:39:14 --> Router Class Initialized
INFO - 2018-11-23 11:39:14 --> Output Class Initialized
INFO - 2018-11-23 11:39:14 --> Security Class Initialized
DEBUG - 2018-11-23 11:39:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-23 11:39:14 --> Input Class Initialized
INFO - 2018-11-23 11:39:14 --> Language Class Initialized
ERROR - 2018-11-23 11:39:15 --> 404 Page Not Found: admin/Change_password/index
INFO - 2018-11-23 11:39:19 --> Config Class Initialized
INFO - 2018-11-23 11:39:19 --> Hooks Class Initialized
DEBUG - 2018-11-23 11:39:19 --> UTF-8 Support Enabled
INFO - 2018-11-23 11:39:19 --> Utf8 Class Initialized
INFO - 2018-11-23 11:39:19 --> URI Class Initialized
INFO - 2018-11-23 11:39:19 --> Router Class Initialized
INFO - 2018-11-23 11:39:19 --> Output Class Initialized
INFO - 2018-11-23 11:39:19 --> Security Class Initialized
DEBUG - 2018-11-23 11:39:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-23 11:39:19 --> Input Class Initialized
INFO - 2018-11-23 11:39:19 --> Language Class Initialized
ERROR - 2018-11-23 11:39:19 --> 404 Page Not Found: admin/Change_password/index
INFO - 2018-11-23 11:39:20 --> Config Class Initialized
INFO - 2018-11-23 11:39:20 --> Hooks Class Initialized
DEBUG - 2018-11-23 11:39:20 --> UTF-8 Support Enabled
INFO - 2018-11-23 11:39:20 --> Utf8 Class Initialized
INFO - 2018-11-23 11:39:20 --> URI Class Initialized
INFO - 2018-11-23 11:39:20 --> Router Class Initialized
INFO - 2018-11-23 11:39:20 --> Output Class Initialized
INFO - 2018-11-23 11:39:20 --> Security Class Initialized
DEBUG - 2018-11-23 11:39:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-23 11:39:20 --> Input Class Initialized
INFO - 2018-11-23 11:39:20 --> Language Class Initialized
ERROR - 2018-11-23 11:39:20 --> 404 Page Not Found: admin/Change_password/index
INFO - 2018-11-23 11:39:20 --> Config Class Initialized
INFO - 2018-11-23 11:39:20 --> Hooks Class Initialized
DEBUG - 2018-11-23 11:39:20 --> UTF-8 Support Enabled
INFO - 2018-11-23 11:39:20 --> Utf8 Class Initialized
INFO - 2018-11-23 11:39:20 --> URI Class Initialized
INFO - 2018-11-23 11:39:20 --> Router Class Initialized
INFO - 2018-11-23 11:39:20 --> Output Class Initialized
INFO - 2018-11-23 11:39:20 --> Security Class Initialized
DEBUG - 2018-11-23 11:39:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-23 11:39:20 --> Input Class Initialized
INFO - 2018-11-23 11:39:20 --> Language Class Initialized
ERROR - 2018-11-23 11:39:20 --> 404 Page Not Found: admin/Change_password/index
INFO - 2018-11-23 11:39:21 --> Config Class Initialized
INFO - 2018-11-23 11:39:21 --> Hooks Class Initialized
DEBUG - 2018-11-23 11:39:21 --> UTF-8 Support Enabled
INFO - 2018-11-23 11:39:21 --> Utf8 Class Initialized
INFO - 2018-11-23 11:39:21 --> URI Class Initialized
INFO - 2018-11-23 11:39:21 --> Router Class Initialized
INFO - 2018-11-23 11:39:21 --> Output Class Initialized
INFO - 2018-11-23 11:39:21 --> Security Class Initialized
DEBUG - 2018-11-23 11:39:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-23 11:39:21 --> Input Class Initialized
INFO - 2018-11-23 11:39:21 --> Language Class Initialized
ERROR - 2018-11-23 11:39:21 --> 404 Page Not Found: admin/Change_password/index
INFO - 2018-11-23 11:39:36 --> Config Class Initialized
INFO - 2018-11-23 11:39:36 --> Hooks Class Initialized
DEBUG - 2018-11-23 11:39:36 --> UTF-8 Support Enabled
INFO - 2018-11-23 11:39:36 --> Utf8 Class Initialized
INFO - 2018-11-23 11:39:36 --> URI Class Initialized
INFO - 2018-11-23 11:39:36 --> Router Class Initialized
INFO - 2018-11-23 11:39:36 --> Output Class Initialized
INFO - 2018-11-23 11:39:36 --> Security Class Initialized
DEBUG - 2018-11-23 11:39:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-23 11:39:36 --> Input Class Initialized
INFO - 2018-11-23 11:39:36 --> Language Class Initialized
ERROR - 2018-11-23 11:39:36 --> 404 Page Not Found: admin/Change_password/index
INFO - 2018-11-23 11:40:00 --> Config Class Initialized
INFO - 2018-11-23 11:40:00 --> Hooks Class Initialized
DEBUG - 2018-11-23 11:40:00 --> UTF-8 Support Enabled
INFO - 2018-11-23 11:40:00 --> Utf8 Class Initialized
INFO - 2018-11-23 11:40:00 --> URI Class Initialized
INFO - 2018-11-23 11:40:00 --> Router Class Initialized
INFO - 2018-11-23 11:40:00 --> Output Class Initialized
INFO - 2018-11-23 11:40:00 --> Security Class Initialized
DEBUG - 2018-11-23 11:40:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-23 11:40:00 --> Input Class Initialized
INFO - 2018-11-23 11:40:00 --> Language Class Initialized
ERROR - 2018-11-23 11:40:00 --> 404 Page Not Found: admin/Change_password/index
INFO - 2018-11-23 11:40:01 --> Config Class Initialized
INFO - 2018-11-23 11:40:01 --> Hooks Class Initialized
DEBUG - 2018-11-23 11:40:01 --> UTF-8 Support Enabled
INFO - 2018-11-23 11:40:01 --> Utf8 Class Initialized
INFO - 2018-11-23 11:40:01 --> URI Class Initialized
INFO - 2018-11-23 11:40:01 --> Router Class Initialized
INFO - 2018-11-23 11:40:01 --> Output Class Initialized
INFO - 2018-11-23 11:40:01 --> Security Class Initialized
DEBUG - 2018-11-23 11:40:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-23 11:40:01 --> Input Class Initialized
INFO - 2018-11-23 11:40:01 --> Language Class Initialized
ERROR - 2018-11-23 11:40:01 --> 404 Page Not Found: admin/Change_password/index
INFO - 2018-11-23 11:40:49 --> Config Class Initialized
INFO - 2018-11-23 11:40:49 --> Hooks Class Initialized
DEBUG - 2018-11-23 11:40:49 --> UTF-8 Support Enabled
INFO - 2018-11-23 11:40:49 --> Utf8 Class Initialized
INFO - 2018-11-23 11:40:49 --> URI Class Initialized
INFO - 2018-11-23 11:40:49 --> Router Class Initialized
INFO - 2018-11-23 11:40:49 --> Output Class Initialized
INFO - 2018-11-23 11:40:49 --> Security Class Initialized
DEBUG - 2018-11-23 11:40:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-23 11:40:49 --> Input Class Initialized
INFO - 2018-11-23 11:40:49 --> Language Class Initialized
INFO - 2018-11-23 11:40:49 --> Loader Class Initialized
INFO - 2018-11-23 11:40:49 --> Helper loaded: url_helper
INFO - 2018-11-23 11:40:49 --> Helper loaded: file_helper
INFO - 2018-11-23 11:40:49 --> Helper loaded: email_helper
INFO - 2018-11-23 11:40:49 --> Helper loaded: common_helper
INFO - 2018-11-23 11:40:49 --> Database Driver Class Initialized
DEBUG - 2018-11-23 11:40:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-23 11:40:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-23 11:40:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-23 11:40:49 --> Pagination Class Initialized
INFO - 2018-11-23 11:40:49 --> Helper loaded: form_helper
INFO - 2018-11-23 11:40:49 --> Form Validation Class Initialized
INFO - 2018-11-23 11:40:49 --> Model Class Initialized
INFO - 2018-11-23 11:40:49 --> Controller Class Initialized
INFO - 2018-11-23 11:40:49 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-23 11:40:49 --> Model Class Initialized
INFO - 2018-11-23 11:40:49 --> Model Class Initialized
INFO - 2018-11-23 11:40:49 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-23 11:40:49 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/change-password.php
INFO - 2018-11-23 11:40:49 --> Final output sent to browser
DEBUG - 2018-11-23 11:40:49 --> Total execution time: 0.0666
INFO - 2018-11-23 11:41:21 --> Config Class Initialized
INFO - 2018-11-23 11:41:21 --> Hooks Class Initialized
DEBUG - 2018-11-23 11:41:21 --> UTF-8 Support Enabled
INFO - 2018-11-23 11:41:21 --> Utf8 Class Initialized
INFO - 2018-11-23 11:41:21 --> URI Class Initialized
INFO - 2018-11-23 11:41:21 --> Router Class Initialized
INFO - 2018-11-23 11:41:21 --> Output Class Initialized
INFO - 2018-11-23 11:41:21 --> Security Class Initialized
DEBUG - 2018-11-23 11:41:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-23 11:41:21 --> Input Class Initialized
INFO - 2018-11-23 11:41:21 --> Language Class Initialized
ERROR - 2018-11-23 11:41:21 --> 404 Page Not Found: admin/Change_pasword/index
INFO - 2018-11-23 11:41:26 --> Config Class Initialized
INFO - 2018-11-23 11:41:26 --> Hooks Class Initialized
DEBUG - 2018-11-23 11:41:26 --> UTF-8 Support Enabled
INFO - 2018-11-23 11:41:26 --> Utf8 Class Initialized
INFO - 2018-11-23 11:41:26 --> URI Class Initialized
INFO - 2018-11-23 11:41:26 --> Router Class Initialized
INFO - 2018-11-23 11:41:26 --> Output Class Initialized
INFO - 2018-11-23 11:41:26 --> Security Class Initialized
DEBUG - 2018-11-23 11:41:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-23 11:41:26 --> Input Class Initialized
INFO - 2018-11-23 11:41:26 --> Language Class Initialized
INFO - 2018-11-23 11:41:26 --> Loader Class Initialized
INFO - 2018-11-23 11:41:26 --> Helper loaded: url_helper
INFO - 2018-11-23 11:41:26 --> Helper loaded: file_helper
INFO - 2018-11-23 11:41:26 --> Helper loaded: email_helper
INFO - 2018-11-23 11:41:26 --> Helper loaded: common_helper
INFO - 2018-11-23 11:41:26 --> Database Driver Class Initialized
DEBUG - 2018-11-23 11:41:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-23 11:41:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-23 11:41:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-23 11:41:26 --> Pagination Class Initialized
INFO - 2018-11-23 11:41:26 --> Helper loaded: form_helper
INFO - 2018-11-23 11:41:26 --> Form Validation Class Initialized
INFO - 2018-11-23 11:41:26 --> Model Class Initialized
INFO - 2018-11-23 11:41:26 --> Controller Class Initialized
INFO - 2018-11-23 11:41:26 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-23 11:41:26 --> Model Class Initialized
INFO - 2018-11-23 11:41:26 --> Model Class Initialized
INFO - 2018-11-23 11:41:26 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-23 11:41:26 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/change-password.php
INFO - 2018-11-23 11:41:26 --> Final output sent to browser
DEBUG - 2018-11-23 11:41:26 --> Total execution time: 0.0550
INFO - 2018-11-23 11:41:30 --> Config Class Initialized
INFO - 2018-11-23 11:41:30 --> Hooks Class Initialized
DEBUG - 2018-11-23 11:41:30 --> UTF-8 Support Enabled
INFO - 2018-11-23 11:41:30 --> Utf8 Class Initialized
INFO - 2018-11-23 11:41:30 --> URI Class Initialized
INFO - 2018-11-23 11:41:30 --> Router Class Initialized
INFO - 2018-11-23 11:41:30 --> Output Class Initialized
INFO - 2018-11-23 11:41:30 --> Security Class Initialized
DEBUG - 2018-11-23 11:41:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-23 11:41:30 --> Input Class Initialized
INFO - 2018-11-23 11:41:30 --> Language Class Initialized
ERROR - 2018-11-23 11:41:30 --> 404 Page Not Found: admin/Change_pasword/index
INFO - 2018-11-23 11:41:51 --> Config Class Initialized
INFO - 2018-11-23 11:41:51 --> Hooks Class Initialized
DEBUG - 2018-11-23 11:41:51 --> UTF-8 Support Enabled
INFO - 2018-11-23 11:41:51 --> Utf8 Class Initialized
INFO - 2018-11-23 11:41:51 --> URI Class Initialized
INFO - 2018-11-23 11:41:51 --> Router Class Initialized
INFO - 2018-11-23 11:41:51 --> Output Class Initialized
INFO - 2018-11-23 11:41:51 --> Security Class Initialized
DEBUG - 2018-11-23 11:41:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-23 11:41:51 --> Input Class Initialized
INFO - 2018-11-23 11:41:51 --> Language Class Initialized
INFO - 2018-11-23 11:41:51 --> Loader Class Initialized
INFO - 2018-11-23 11:41:51 --> Helper loaded: url_helper
INFO - 2018-11-23 11:41:51 --> Helper loaded: file_helper
INFO - 2018-11-23 11:41:51 --> Helper loaded: email_helper
INFO - 2018-11-23 11:41:51 --> Helper loaded: common_helper
INFO - 2018-11-23 11:41:51 --> Database Driver Class Initialized
DEBUG - 2018-11-23 11:41:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-23 11:41:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-23 11:41:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-23 11:41:51 --> Pagination Class Initialized
INFO - 2018-11-23 11:41:51 --> Helper loaded: form_helper
INFO - 2018-11-23 11:41:51 --> Form Validation Class Initialized
INFO - 2018-11-23 11:41:51 --> Model Class Initialized
INFO - 2018-11-23 11:41:51 --> Controller Class Initialized
INFO - 2018-11-23 11:41:51 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-23 11:41:51 --> Model Class Initialized
INFO - 2018-11-23 11:41:51 --> Model Class Initialized
INFO - 2018-11-23 11:41:51 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-23 11:41:51 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/change-password.php
INFO - 2018-11-23 11:41:51 --> Final output sent to browser
DEBUG - 2018-11-23 11:41:51 --> Total execution time: 0.0520
INFO - 2018-11-23 11:41:53 --> Config Class Initialized
INFO - 2018-11-23 11:41:53 --> Hooks Class Initialized
DEBUG - 2018-11-23 11:41:53 --> UTF-8 Support Enabled
INFO - 2018-11-23 11:41:53 --> Utf8 Class Initialized
INFO - 2018-11-23 11:41:53 --> URI Class Initialized
INFO - 2018-11-23 11:41:53 --> Router Class Initialized
INFO - 2018-11-23 11:41:53 --> Output Class Initialized
INFO - 2018-11-23 11:41:53 --> Security Class Initialized
DEBUG - 2018-11-23 11:41:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-23 11:41:53 --> Input Class Initialized
INFO - 2018-11-23 11:41:53 --> Language Class Initialized
INFO - 2018-11-23 11:41:53 --> Loader Class Initialized
INFO - 2018-11-23 11:41:53 --> Helper loaded: url_helper
INFO - 2018-11-23 11:41:53 --> Helper loaded: file_helper
INFO - 2018-11-23 11:41:53 --> Helper loaded: email_helper
INFO - 2018-11-23 11:41:53 --> Helper loaded: common_helper
INFO - 2018-11-23 11:41:53 --> Database Driver Class Initialized
DEBUG - 2018-11-23 11:41:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-23 11:41:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-23 11:41:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-23 11:41:53 --> Pagination Class Initialized
INFO - 2018-11-23 11:41:53 --> Helper loaded: form_helper
INFO - 2018-11-23 11:41:53 --> Form Validation Class Initialized
INFO - 2018-11-23 11:41:53 --> Model Class Initialized
INFO - 2018-11-23 11:41:53 --> Controller Class Initialized
INFO - 2018-11-23 11:41:53 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-23 11:41:53 --> Model Class Initialized
INFO - 2018-11-23 11:41:53 --> Model Class Initialized
INFO - 2018-11-23 11:41:53 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-23 11:41:53 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/change-password.php
INFO - 2018-11-23 11:41:53 --> Final output sent to browser
DEBUG - 2018-11-23 11:41:53 --> Total execution time: 0.0470
INFO - 2018-11-23 11:41:57 --> Config Class Initialized
INFO - 2018-11-23 11:41:57 --> Hooks Class Initialized
DEBUG - 2018-11-23 11:41:57 --> UTF-8 Support Enabled
INFO - 2018-11-23 11:41:57 --> Utf8 Class Initialized
INFO - 2018-11-23 11:41:57 --> URI Class Initialized
INFO - 2018-11-23 11:41:57 --> Router Class Initialized
INFO - 2018-11-23 11:41:57 --> Output Class Initialized
INFO - 2018-11-23 11:41:57 --> Security Class Initialized
DEBUG - 2018-11-23 11:41:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-23 11:41:57 --> Input Class Initialized
INFO - 2018-11-23 11:41:57 --> Language Class Initialized
INFO - 2018-11-23 11:41:57 --> Loader Class Initialized
INFO - 2018-11-23 11:41:57 --> Helper loaded: url_helper
INFO - 2018-11-23 11:41:57 --> Helper loaded: file_helper
INFO - 2018-11-23 11:41:57 --> Helper loaded: email_helper
INFO - 2018-11-23 11:41:57 --> Helper loaded: common_helper
INFO - 2018-11-23 11:41:57 --> Database Driver Class Initialized
DEBUG - 2018-11-23 11:41:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-23 11:41:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-23 11:41:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-23 11:41:57 --> Pagination Class Initialized
INFO - 2018-11-23 11:41:57 --> Helper loaded: form_helper
INFO - 2018-11-23 11:41:57 --> Form Validation Class Initialized
INFO - 2018-11-23 11:41:57 --> Model Class Initialized
INFO - 2018-11-23 11:41:57 --> Controller Class Initialized
INFO - 2018-11-23 11:41:57 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-23 11:41:57 --> Model Class Initialized
INFO - 2018-11-23 11:41:57 --> Model Class Initialized
INFO - 2018-11-23 11:41:57 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-23 11:41:57 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/change-password.php
INFO - 2018-11-23 11:41:57 --> Final output sent to browser
DEBUG - 2018-11-23 11:41:57 --> Total execution time: 0.0720
INFO - 2018-11-23 11:42:08 --> Config Class Initialized
INFO - 2018-11-23 11:42:08 --> Hooks Class Initialized
DEBUG - 2018-11-23 11:42:08 --> UTF-8 Support Enabled
INFO - 2018-11-23 11:42:08 --> Utf8 Class Initialized
INFO - 2018-11-23 11:42:08 --> URI Class Initialized
INFO - 2018-11-23 11:42:08 --> Router Class Initialized
INFO - 2018-11-23 11:42:08 --> Output Class Initialized
INFO - 2018-11-23 11:42:08 --> Security Class Initialized
DEBUG - 2018-11-23 11:42:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-23 11:42:08 --> Input Class Initialized
INFO - 2018-11-23 11:42:08 --> Language Class Initialized
INFO - 2018-11-23 11:42:08 --> Loader Class Initialized
INFO - 2018-11-23 11:42:08 --> Helper loaded: url_helper
INFO - 2018-11-23 11:42:08 --> Helper loaded: file_helper
INFO - 2018-11-23 11:42:08 --> Helper loaded: email_helper
INFO - 2018-11-23 11:42:08 --> Helper loaded: common_helper
INFO - 2018-11-23 11:42:08 --> Database Driver Class Initialized
DEBUG - 2018-11-23 11:42:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-23 11:42:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-23 11:42:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-23 11:42:08 --> Pagination Class Initialized
INFO - 2018-11-23 11:42:08 --> Helper loaded: form_helper
INFO - 2018-11-23 11:42:08 --> Form Validation Class Initialized
INFO - 2018-11-23 11:42:08 --> Model Class Initialized
INFO - 2018-11-23 11:42:08 --> Controller Class Initialized
INFO - 2018-11-23 11:42:08 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-23 11:42:08 --> Model Class Initialized
INFO - 2018-11-23 11:42:08 --> Model Class Initialized
INFO - 2018-11-23 11:42:08 --> Config Class Initialized
INFO - 2018-11-23 11:42:08 --> Hooks Class Initialized
DEBUG - 2018-11-23 11:42:08 --> UTF-8 Support Enabled
INFO - 2018-11-23 11:42:08 --> Utf8 Class Initialized
INFO - 2018-11-23 11:42:08 --> URI Class Initialized
INFO - 2018-11-23 11:42:08 --> Router Class Initialized
INFO - 2018-11-23 11:42:08 --> Output Class Initialized
INFO - 2018-11-23 11:42:08 --> Security Class Initialized
DEBUG - 2018-11-23 11:42:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-23 11:42:08 --> Input Class Initialized
INFO - 2018-11-23 11:42:08 --> Language Class Initialized
INFO - 2018-11-23 11:42:08 --> Loader Class Initialized
INFO - 2018-11-23 11:42:08 --> Helper loaded: url_helper
INFO - 2018-11-23 11:42:08 --> Helper loaded: file_helper
INFO - 2018-11-23 11:42:08 --> Helper loaded: email_helper
INFO - 2018-11-23 11:42:08 --> Helper loaded: common_helper
INFO - 2018-11-23 11:42:08 --> Database Driver Class Initialized
DEBUG - 2018-11-23 11:42:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-23 11:42:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-23 11:42:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-23 11:42:08 --> Pagination Class Initialized
INFO - 2018-11-23 11:42:08 --> Helper loaded: form_helper
INFO - 2018-11-23 11:42:08 --> Form Validation Class Initialized
INFO - 2018-11-23 11:42:08 --> Model Class Initialized
INFO - 2018-11-23 11:42:08 --> Controller Class Initialized
INFO - 2018-11-23 11:42:08 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-23 11:42:08 --> Model Class Initialized
INFO - 2018-11-23 11:42:08 --> Model Class Initialized
INFO - 2018-11-23 11:42:08 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-23 11:42:08 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/change-password.php
INFO - 2018-11-23 11:42:08 --> Final output sent to browser
DEBUG - 2018-11-23 11:42:08 --> Total execution time: 0.0680
INFO - 2018-11-23 11:42:57 --> Config Class Initialized
INFO - 2018-11-23 11:42:57 --> Hooks Class Initialized
DEBUG - 2018-11-23 11:42:57 --> UTF-8 Support Enabled
INFO - 2018-11-23 11:42:57 --> Utf8 Class Initialized
INFO - 2018-11-23 11:42:57 --> URI Class Initialized
INFO - 2018-11-23 11:42:57 --> Router Class Initialized
INFO - 2018-11-23 11:42:57 --> Output Class Initialized
INFO - 2018-11-23 11:42:57 --> Security Class Initialized
DEBUG - 2018-11-23 11:42:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-23 11:42:57 --> Input Class Initialized
INFO - 2018-11-23 11:42:57 --> Language Class Initialized
INFO - 2018-11-23 11:42:57 --> Loader Class Initialized
INFO - 2018-11-23 11:42:57 --> Helper loaded: url_helper
INFO - 2018-11-23 11:42:57 --> Helper loaded: file_helper
INFO - 2018-11-23 11:42:57 --> Helper loaded: email_helper
INFO - 2018-11-23 11:42:57 --> Helper loaded: common_helper
INFO - 2018-11-23 11:42:57 --> Database Driver Class Initialized
DEBUG - 2018-11-23 11:42:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-23 11:42:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-23 11:42:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-23 11:42:57 --> Pagination Class Initialized
INFO - 2018-11-23 11:42:57 --> Helper loaded: form_helper
INFO - 2018-11-23 11:42:57 --> Form Validation Class Initialized
INFO - 2018-11-23 11:42:57 --> Model Class Initialized
INFO - 2018-11-23 11:42:57 --> Controller Class Initialized
INFO - 2018-11-23 11:42:57 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-23 11:42:57 --> Model Class Initialized
INFO - 2018-11-23 11:42:57 --> Model Class Initialized
INFO - 2018-11-23 11:42:57 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-23 11:42:57 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/change-password.php
INFO - 2018-11-23 11:42:57 --> Final output sent to browser
DEBUG - 2018-11-23 11:42:57 --> Total execution time: 0.0530
INFO - 2018-11-23 11:43:15 --> Config Class Initialized
INFO - 2018-11-23 11:43:15 --> Hooks Class Initialized
DEBUG - 2018-11-23 11:43:15 --> UTF-8 Support Enabled
INFO - 2018-11-23 11:43:15 --> Utf8 Class Initialized
INFO - 2018-11-23 11:43:15 --> URI Class Initialized
INFO - 2018-11-23 11:43:15 --> Router Class Initialized
INFO - 2018-11-23 11:43:15 --> Output Class Initialized
INFO - 2018-11-23 11:43:15 --> Security Class Initialized
DEBUG - 2018-11-23 11:43:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-23 11:43:15 --> Input Class Initialized
INFO - 2018-11-23 11:43:15 --> Language Class Initialized
INFO - 2018-11-23 11:43:15 --> Loader Class Initialized
INFO - 2018-11-23 11:43:15 --> Helper loaded: url_helper
INFO - 2018-11-23 11:43:15 --> Helper loaded: file_helper
INFO - 2018-11-23 11:43:15 --> Helper loaded: email_helper
INFO - 2018-11-23 11:43:15 --> Helper loaded: common_helper
INFO - 2018-11-23 11:43:15 --> Database Driver Class Initialized
DEBUG - 2018-11-23 11:43:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-23 11:43:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-23 11:43:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-23 11:43:15 --> Pagination Class Initialized
INFO - 2018-11-23 11:43:15 --> Helper loaded: form_helper
INFO - 2018-11-23 11:43:15 --> Form Validation Class Initialized
INFO - 2018-11-23 11:43:15 --> Model Class Initialized
INFO - 2018-11-23 11:43:15 --> Controller Class Initialized
INFO - 2018-11-23 11:43:15 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-23 11:43:15 --> Model Class Initialized
INFO - 2018-11-23 11:43:15 --> Model Class Initialized
INFO - 2018-11-23 11:43:15 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-23 11:43:15 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/change-password.php
INFO - 2018-11-23 11:43:15 --> Final output sent to browser
DEBUG - 2018-11-23 11:43:15 --> Total execution time: 0.0590
INFO - 2018-11-23 11:51:11 --> Config Class Initialized
INFO - 2018-11-23 11:51:11 --> Hooks Class Initialized
DEBUG - 2018-11-23 11:51:11 --> UTF-8 Support Enabled
INFO - 2018-11-23 11:51:11 --> Utf8 Class Initialized
INFO - 2018-11-23 11:51:11 --> URI Class Initialized
INFO - 2018-11-23 11:51:11 --> Router Class Initialized
INFO - 2018-11-23 11:51:11 --> Output Class Initialized
INFO - 2018-11-23 11:51:11 --> Security Class Initialized
DEBUG - 2018-11-23 11:51:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-23 11:51:11 --> Input Class Initialized
INFO - 2018-11-23 11:51:11 --> Language Class Initialized
INFO - 2018-11-23 11:51:11 --> Loader Class Initialized
INFO - 2018-11-23 11:51:11 --> Helper loaded: url_helper
INFO - 2018-11-23 11:51:11 --> Helper loaded: file_helper
INFO - 2018-11-23 11:51:11 --> Helper loaded: email_helper
INFO - 2018-11-23 11:51:11 --> Helper loaded: common_helper
INFO - 2018-11-23 11:51:11 --> Database Driver Class Initialized
DEBUG - 2018-11-23 11:51:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-23 11:51:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-23 11:51:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-23 11:51:11 --> Pagination Class Initialized
INFO - 2018-11-23 11:51:11 --> Helper loaded: form_helper
INFO - 2018-11-23 11:51:11 --> Form Validation Class Initialized
INFO - 2018-11-23 11:51:11 --> Model Class Initialized
INFO - 2018-11-23 11:51:11 --> Controller Class Initialized
INFO - 2018-11-23 11:51:11 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-23 11:51:11 --> Model Class Initialized
INFO - 2018-11-23 11:51:11 --> Model Class Initialized
INFO - 2018-11-23 11:51:11 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-23 11:51:11 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/change-password.php
INFO - 2018-11-23 11:51:11 --> Final output sent to browser
DEBUG - 2018-11-23 11:51:11 --> Total execution time: 0.0600
INFO - 2018-11-23 11:51:21 --> Config Class Initialized
INFO - 2018-11-23 11:51:21 --> Hooks Class Initialized
DEBUG - 2018-11-23 11:51:21 --> UTF-8 Support Enabled
INFO - 2018-11-23 11:51:21 --> Utf8 Class Initialized
INFO - 2018-11-23 11:51:21 --> URI Class Initialized
INFO - 2018-11-23 11:51:21 --> Router Class Initialized
INFO - 2018-11-23 11:51:21 --> Output Class Initialized
INFO - 2018-11-23 11:51:21 --> Security Class Initialized
DEBUG - 2018-11-23 11:51:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-23 11:51:21 --> Input Class Initialized
INFO - 2018-11-23 11:51:21 --> Language Class Initialized
INFO - 2018-11-23 11:51:21 --> Loader Class Initialized
INFO - 2018-11-23 11:51:21 --> Helper loaded: url_helper
INFO - 2018-11-23 11:51:21 --> Helper loaded: file_helper
INFO - 2018-11-23 11:51:21 --> Helper loaded: email_helper
INFO - 2018-11-23 11:51:21 --> Helper loaded: common_helper
INFO - 2018-11-23 11:51:21 --> Database Driver Class Initialized
DEBUG - 2018-11-23 11:51:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-23 11:51:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-23 11:51:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-23 11:51:21 --> Pagination Class Initialized
INFO - 2018-11-23 11:51:21 --> Helper loaded: form_helper
INFO - 2018-11-23 11:51:21 --> Form Validation Class Initialized
INFO - 2018-11-23 11:51:21 --> Model Class Initialized
INFO - 2018-11-23 11:51:21 --> Controller Class Initialized
INFO - 2018-11-23 11:51:21 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-23 11:51:21 --> Model Class Initialized
INFO - 2018-11-23 11:51:21 --> Model Class Initialized
INFO - 2018-11-23 11:51:21 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-23 11:51:21 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/change-password.php
INFO - 2018-11-23 11:51:21 --> Final output sent to browser
DEBUG - 2018-11-23 11:51:21 --> Total execution time: 0.0590
INFO - 2018-11-23 11:51:43 --> Config Class Initialized
INFO - 2018-11-23 11:51:43 --> Hooks Class Initialized
DEBUG - 2018-11-23 11:51:43 --> UTF-8 Support Enabled
INFO - 2018-11-23 11:51:43 --> Utf8 Class Initialized
INFO - 2018-11-23 11:51:43 --> URI Class Initialized
INFO - 2018-11-23 11:51:43 --> Router Class Initialized
INFO - 2018-11-23 11:51:43 --> Output Class Initialized
INFO - 2018-11-23 11:51:43 --> Security Class Initialized
DEBUG - 2018-11-23 11:51:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-23 11:51:43 --> Input Class Initialized
INFO - 2018-11-23 11:51:43 --> Language Class Initialized
INFO - 2018-11-23 11:51:43 --> Loader Class Initialized
INFO - 2018-11-23 11:51:43 --> Helper loaded: url_helper
INFO - 2018-11-23 11:51:43 --> Helper loaded: file_helper
INFO - 2018-11-23 11:51:43 --> Helper loaded: email_helper
INFO - 2018-11-23 11:51:43 --> Helper loaded: common_helper
INFO - 2018-11-23 11:51:43 --> Database Driver Class Initialized
DEBUG - 2018-11-23 11:51:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-23 11:51:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-23 11:51:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-23 11:51:43 --> Pagination Class Initialized
INFO - 2018-11-23 11:51:43 --> Helper loaded: form_helper
INFO - 2018-11-23 11:51:43 --> Form Validation Class Initialized
INFO - 2018-11-23 11:51:43 --> Model Class Initialized
INFO - 2018-11-23 11:51:43 --> Controller Class Initialized
INFO - 2018-11-23 11:51:43 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-23 11:51:43 --> Model Class Initialized
INFO - 2018-11-23 11:51:43 --> Model Class Initialized
INFO - 2018-11-23 11:51:43 --> Config Class Initialized
INFO - 2018-11-23 11:51:43 --> Hooks Class Initialized
DEBUG - 2018-11-23 11:51:43 --> UTF-8 Support Enabled
INFO - 2018-11-23 11:51:43 --> Utf8 Class Initialized
INFO - 2018-11-23 11:51:43 --> URI Class Initialized
INFO - 2018-11-23 11:51:43 --> Router Class Initialized
INFO - 2018-11-23 11:51:43 --> Output Class Initialized
INFO - 2018-11-23 11:51:43 --> Security Class Initialized
DEBUG - 2018-11-23 11:51:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-23 11:51:43 --> Input Class Initialized
INFO - 2018-11-23 11:51:43 --> Language Class Initialized
INFO - 2018-11-23 11:51:43 --> Loader Class Initialized
INFO - 2018-11-23 11:51:43 --> Helper loaded: url_helper
INFO - 2018-11-23 11:51:43 --> Helper loaded: file_helper
INFO - 2018-11-23 11:51:43 --> Helper loaded: email_helper
INFO - 2018-11-23 11:51:43 --> Helper loaded: common_helper
INFO - 2018-11-23 11:51:43 --> Database Driver Class Initialized
DEBUG - 2018-11-23 11:51:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-23 11:51:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-23 11:51:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-23 11:51:43 --> Pagination Class Initialized
INFO - 2018-11-23 11:51:43 --> Helper loaded: form_helper
INFO - 2018-11-23 11:51:43 --> Form Validation Class Initialized
INFO - 2018-11-23 11:51:43 --> Model Class Initialized
INFO - 2018-11-23 11:51:43 --> Controller Class Initialized
INFO - 2018-11-23 11:51:43 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-23 11:51:43 --> Model Class Initialized
INFO - 2018-11-23 11:51:43 --> Model Class Initialized
INFO - 2018-11-23 11:51:43 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-23 11:51:43 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/change-password.php
INFO - 2018-11-23 11:51:43 --> Final output sent to browser
DEBUG - 2018-11-23 11:51:43 --> Total execution time: 0.0650
INFO - 2018-11-23 11:52:23 --> Config Class Initialized
INFO - 2018-11-23 11:52:23 --> Hooks Class Initialized
DEBUG - 2018-11-23 11:52:23 --> UTF-8 Support Enabled
INFO - 2018-11-23 11:52:23 --> Utf8 Class Initialized
INFO - 2018-11-23 11:52:23 --> URI Class Initialized
INFO - 2018-11-23 11:52:23 --> Router Class Initialized
INFO - 2018-11-23 11:52:23 --> Output Class Initialized
INFO - 2018-11-23 11:52:23 --> Security Class Initialized
DEBUG - 2018-11-23 11:52:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-23 11:52:23 --> Input Class Initialized
INFO - 2018-11-23 11:52:23 --> Language Class Initialized
INFO - 2018-11-23 11:52:23 --> Loader Class Initialized
INFO - 2018-11-23 11:52:23 --> Helper loaded: url_helper
INFO - 2018-11-23 11:52:23 --> Helper loaded: file_helper
INFO - 2018-11-23 11:52:23 --> Helper loaded: email_helper
INFO - 2018-11-23 11:52:23 --> Helper loaded: common_helper
INFO - 2018-11-23 11:52:23 --> Database Driver Class Initialized
DEBUG - 2018-11-23 11:52:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-23 11:52:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-23 11:52:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-23 11:52:23 --> Pagination Class Initialized
INFO - 2018-11-23 11:52:23 --> Helper loaded: form_helper
INFO - 2018-11-23 11:52:23 --> Form Validation Class Initialized
INFO - 2018-11-23 11:52:23 --> Model Class Initialized
INFO - 2018-11-23 11:52:23 --> Controller Class Initialized
INFO - 2018-11-23 11:52:23 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-23 11:52:23 --> Model Class Initialized
INFO - 2018-11-23 11:52:23 --> Model Class Initialized
INFO - 2018-11-23 11:52:23 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-23 11:52:23 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/change-password.php
INFO - 2018-11-23 11:52:23 --> Final output sent to browser
DEBUG - 2018-11-23 11:52:23 --> Total execution time: 0.0540
INFO - 2018-11-23 11:53:42 --> Config Class Initialized
INFO - 2018-11-23 11:53:42 --> Hooks Class Initialized
DEBUG - 2018-11-23 11:53:42 --> UTF-8 Support Enabled
INFO - 2018-11-23 11:53:42 --> Utf8 Class Initialized
INFO - 2018-11-23 11:53:42 --> URI Class Initialized
INFO - 2018-11-23 11:53:42 --> Router Class Initialized
INFO - 2018-11-23 11:53:42 --> Output Class Initialized
INFO - 2018-11-23 11:53:42 --> Security Class Initialized
DEBUG - 2018-11-23 11:53:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-23 11:53:42 --> Input Class Initialized
INFO - 2018-11-23 11:53:42 --> Language Class Initialized
INFO - 2018-11-23 11:53:42 --> Loader Class Initialized
INFO - 2018-11-23 11:53:42 --> Helper loaded: url_helper
INFO - 2018-11-23 11:53:42 --> Helper loaded: file_helper
INFO - 2018-11-23 11:53:42 --> Helper loaded: email_helper
INFO - 2018-11-23 11:53:42 --> Helper loaded: common_helper
INFO - 2018-11-23 11:53:42 --> Database Driver Class Initialized
DEBUG - 2018-11-23 11:53:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-23 11:53:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-23 11:53:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-23 11:53:42 --> Pagination Class Initialized
INFO - 2018-11-23 11:53:42 --> Helper loaded: form_helper
INFO - 2018-11-23 11:53:42 --> Form Validation Class Initialized
INFO - 2018-11-23 11:53:42 --> Model Class Initialized
INFO - 2018-11-23 11:53:42 --> Controller Class Initialized
INFO - 2018-11-23 11:53:42 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-23 11:53:42 --> Model Class Initialized
INFO - 2018-11-23 11:53:42 --> Model Class Initialized
INFO - 2018-11-23 11:53:42 --> Config Class Initialized
INFO - 2018-11-23 11:53:42 --> Hooks Class Initialized
DEBUG - 2018-11-23 11:53:42 --> UTF-8 Support Enabled
INFO - 2018-11-23 11:53:42 --> Utf8 Class Initialized
INFO - 2018-11-23 11:53:42 --> URI Class Initialized
INFO - 2018-11-23 11:53:42 --> Router Class Initialized
INFO - 2018-11-23 11:53:42 --> Output Class Initialized
INFO - 2018-11-23 11:53:42 --> Security Class Initialized
DEBUG - 2018-11-23 11:53:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-23 11:53:42 --> Input Class Initialized
INFO - 2018-11-23 11:53:42 --> Language Class Initialized
INFO - 2018-11-23 11:53:42 --> Loader Class Initialized
INFO - 2018-11-23 11:53:42 --> Helper loaded: url_helper
INFO - 2018-11-23 11:53:42 --> Helper loaded: file_helper
INFO - 2018-11-23 11:53:42 --> Helper loaded: email_helper
INFO - 2018-11-23 11:53:42 --> Helper loaded: common_helper
INFO - 2018-11-23 11:53:42 --> Database Driver Class Initialized
DEBUG - 2018-11-23 11:53:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-23 11:53:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-23 11:53:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-23 11:53:42 --> Pagination Class Initialized
INFO - 2018-11-23 11:53:42 --> Helper loaded: form_helper
INFO - 2018-11-23 11:53:42 --> Form Validation Class Initialized
INFO - 2018-11-23 11:53:42 --> Model Class Initialized
INFO - 2018-11-23 11:53:42 --> Controller Class Initialized
INFO - 2018-11-23 11:53:42 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-23 11:53:42 --> Model Class Initialized
INFO - 2018-11-23 11:53:42 --> Model Class Initialized
INFO - 2018-11-23 11:55:15 --> Config Class Initialized
INFO - 2018-11-23 11:55:15 --> Hooks Class Initialized
DEBUG - 2018-11-23 11:55:15 --> UTF-8 Support Enabled
INFO - 2018-11-23 11:55:15 --> Utf8 Class Initialized
INFO - 2018-11-23 11:55:15 --> URI Class Initialized
INFO - 2018-11-23 11:55:15 --> Router Class Initialized
INFO - 2018-11-23 11:55:15 --> Output Class Initialized
INFO - 2018-11-23 11:55:15 --> Security Class Initialized
DEBUG - 2018-11-23 11:55:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-23 11:55:15 --> Input Class Initialized
INFO - 2018-11-23 11:55:15 --> Language Class Initialized
INFO - 2018-11-23 11:55:15 --> Loader Class Initialized
INFO - 2018-11-23 11:55:15 --> Helper loaded: url_helper
INFO - 2018-11-23 11:55:15 --> Helper loaded: file_helper
INFO - 2018-11-23 11:55:15 --> Helper loaded: email_helper
INFO - 2018-11-23 11:55:15 --> Helper loaded: common_helper
INFO - 2018-11-23 11:55:15 --> Database Driver Class Initialized
DEBUG - 2018-11-23 11:55:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-23 11:55:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-23 11:55:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-23 11:55:15 --> Pagination Class Initialized
INFO - 2018-11-23 11:55:15 --> Helper loaded: form_helper
INFO - 2018-11-23 11:55:15 --> Form Validation Class Initialized
INFO - 2018-11-23 11:55:15 --> Model Class Initialized
INFO - 2018-11-23 11:55:15 --> Controller Class Initialized
INFO - 2018-11-23 11:55:15 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-23 11:55:15 --> Model Class Initialized
INFO - 2018-11-23 11:55:15 --> Model Class Initialized
INFO - 2018-11-23 11:55:15 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-23 11:55:15 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/change-password.php
INFO - 2018-11-23 11:55:15 --> Final output sent to browser
DEBUG - 2018-11-23 11:55:15 --> Total execution time: 0.0560
INFO - 2018-11-23 11:55:20 --> Config Class Initialized
INFO - 2018-11-23 11:55:20 --> Hooks Class Initialized
DEBUG - 2018-11-23 11:55:20 --> UTF-8 Support Enabled
INFO - 2018-11-23 11:55:20 --> Utf8 Class Initialized
INFO - 2018-11-23 11:55:20 --> URI Class Initialized
INFO - 2018-11-23 11:55:20 --> Router Class Initialized
INFO - 2018-11-23 11:55:20 --> Output Class Initialized
INFO - 2018-11-23 11:55:20 --> Security Class Initialized
DEBUG - 2018-11-23 11:55:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-23 11:55:20 --> Input Class Initialized
INFO - 2018-11-23 11:55:20 --> Language Class Initialized
INFO - 2018-11-23 11:55:20 --> Loader Class Initialized
INFO - 2018-11-23 11:55:20 --> Helper loaded: url_helper
INFO - 2018-11-23 11:55:20 --> Helper loaded: file_helper
INFO - 2018-11-23 11:55:20 --> Helper loaded: email_helper
INFO - 2018-11-23 11:55:20 --> Helper loaded: common_helper
INFO - 2018-11-23 11:55:20 --> Database Driver Class Initialized
DEBUG - 2018-11-23 11:55:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-23 11:55:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-23 11:55:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-23 11:55:20 --> Pagination Class Initialized
INFO - 2018-11-23 11:55:20 --> Helper loaded: form_helper
INFO - 2018-11-23 11:55:20 --> Form Validation Class Initialized
INFO - 2018-11-23 11:55:20 --> Model Class Initialized
INFO - 2018-11-23 11:55:20 --> Controller Class Initialized
INFO - 2018-11-23 11:55:20 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-23 11:55:20 --> Model Class Initialized
INFO - 2018-11-23 11:55:20 --> Model Class Initialized
INFO - 2018-11-23 11:55:20 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-23 11:55:20 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/change-password.php
INFO - 2018-11-23 11:55:20 --> Final output sent to browser
DEBUG - 2018-11-23 11:55:20 --> Total execution time: 0.0580
INFO - 2018-11-23 11:55:26 --> Config Class Initialized
INFO - 2018-11-23 11:55:26 --> Hooks Class Initialized
DEBUG - 2018-11-23 11:55:26 --> UTF-8 Support Enabled
INFO - 2018-11-23 11:55:26 --> Utf8 Class Initialized
INFO - 2018-11-23 11:55:26 --> URI Class Initialized
INFO - 2018-11-23 11:55:26 --> Router Class Initialized
INFO - 2018-11-23 11:55:26 --> Output Class Initialized
INFO - 2018-11-23 11:55:26 --> Security Class Initialized
DEBUG - 2018-11-23 11:55:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-23 11:55:26 --> Input Class Initialized
INFO - 2018-11-23 11:55:26 --> Language Class Initialized
INFO - 2018-11-23 11:55:26 --> Loader Class Initialized
INFO - 2018-11-23 11:55:26 --> Helper loaded: url_helper
INFO - 2018-11-23 11:55:26 --> Helper loaded: file_helper
INFO - 2018-11-23 11:55:26 --> Helper loaded: email_helper
INFO - 2018-11-23 11:55:26 --> Helper loaded: common_helper
INFO - 2018-11-23 11:55:26 --> Database Driver Class Initialized
DEBUG - 2018-11-23 11:55:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-23 11:55:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-23 11:55:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-23 11:55:26 --> Pagination Class Initialized
INFO - 2018-11-23 11:55:26 --> Helper loaded: form_helper
INFO - 2018-11-23 11:55:26 --> Form Validation Class Initialized
INFO - 2018-11-23 11:55:26 --> Model Class Initialized
INFO - 2018-11-23 11:55:26 --> Controller Class Initialized
INFO - 2018-11-23 11:55:26 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-23 11:55:26 --> Model Class Initialized
INFO - 2018-11-23 11:55:26 --> Model Class Initialized
INFO - 2018-11-23 11:55:26 --> Config Class Initialized
INFO - 2018-11-23 11:55:26 --> Hooks Class Initialized
DEBUG - 2018-11-23 11:55:26 --> UTF-8 Support Enabled
INFO - 2018-11-23 11:55:26 --> Utf8 Class Initialized
INFO - 2018-11-23 11:55:26 --> URI Class Initialized
INFO - 2018-11-23 11:55:26 --> Router Class Initialized
INFO - 2018-11-23 11:55:26 --> Output Class Initialized
INFO - 2018-11-23 11:55:26 --> Security Class Initialized
DEBUG - 2018-11-23 11:55:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-23 11:55:26 --> Input Class Initialized
INFO - 2018-11-23 11:55:26 --> Language Class Initialized
INFO - 2018-11-23 11:55:26 --> Loader Class Initialized
INFO - 2018-11-23 11:55:26 --> Helper loaded: url_helper
INFO - 2018-11-23 11:55:26 --> Helper loaded: file_helper
INFO - 2018-11-23 11:55:26 --> Helper loaded: email_helper
INFO - 2018-11-23 11:55:26 --> Helper loaded: common_helper
INFO - 2018-11-23 11:55:26 --> Database Driver Class Initialized
DEBUG - 2018-11-23 11:55:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-23 11:55:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-23 11:55:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-23 11:55:26 --> Pagination Class Initialized
INFO - 2018-11-23 11:55:26 --> Helper loaded: form_helper
INFO - 2018-11-23 11:55:26 --> Form Validation Class Initialized
INFO - 2018-11-23 11:55:26 --> Model Class Initialized
INFO - 2018-11-23 11:55:26 --> Controller Class Initialized
INFO - 2018-11-23 11:55:26 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-23 11:55:26 --> Model Class Initialized
INFO - 2018-11-23 11:55:26 --> Model Class Initialized
INFO - 2018-11-23 11:55:26 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-23 11:55:26 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/change-password.php
INFO - 2018-11-23 11:55:26 --> Final output sent to browser
DEBUG - 2018-11-23 11:55:26 --> Total execution time: 0.0630
INFO - 2018-11-23 11:58:00 --> Config Class Initialized
INFO - 2018-11-23 11:58:00 --> Hooks Class Initialized
DEBUG - 2018-11-23 11:58:00 --> UTF-8 Support Enabled
INFO - 2018-11-23 11:58:00 --> Utf8 Class Initialized
INFO - 2018-11-23 11:58:00 --> URI Class Initialized
INFO - 2018-11-23 11:58:00 --> Router Class Initialized
INFO - 2018-11-23 11:58:00 --> Output Class Initialized
INFO - 2018-11-23 11:58:00 --> Security Class Initialized
DEBUG - 2018-11-23 11:58:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-23 11:58:00 --> Input Class Initialized
INFO - 2018-11-23 11:58:00 --> Language Class Initialized
INFO - 2018-11-23 11:58:00 --> Loader Class Initialized
INFO - 2018-11-23 11:58:00 --> Helper loaded: url_helper
INFO - 2018-11-23 11:58:00 --> Helper loaded: file_helper
INFO - 2018-11-23 11:58:00 --> Helper loaded: email_helper
INFO - 2018-11-23 11:58:00 --> Helper loaded: common_helper
INFO - 2018-11-23 11:58:00 --> Database Driver Class Initialized
DEBUG - 2018-11-23 11:58:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-23 11:58:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-23 11:58:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-23 11:58:00 --> Pagination Class Initialized
INFO - 2018-11-23 11:58:00 --> Helper loaded: form_helper
INFO - 2018-11-23 11:58:00 --> Form Validation Class Initialized
INFO - 2018-11-23 11:58:00 --> Model Class Initialized
INFO - 2018-11-23 11:58:00 --> Controller Class Initialized
INFO - 2018-11-23 11:58:00 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-23 11:58:00 --> Model Class Initialized
INFO - 2018-11-23 11:58:00 --> Model Class Initialized
INFO - 2018-11-23 11:58:00 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-23 11:58:00 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/change-password.php
INFO - 2018-11-23 11:58:00 --> Final output sent to browser
DEBUG - 2018-11-23 11:58:00 --> Total execution time: 0.0560
INFO - 2018-11-23 11:58:14 --> Config Class Initialized
INFO - 2018-11-23 11:58:14 --> Hooks Class Initialized
DEBUG - 2018-11-23 11:58:14 --> UTF-8 Support Enabled
INFO - 2018-11-23 11:58:14 --> Utf8 Class Initialized
INFO - 2018-11-23 11:58:14 --> URI Class Initialized
INFO - 2018-11-23 11:58:14 --> Router Class Initialized
INFO - 2018-11-23 11:58:14 --> Output Class Initialized
INFO - 2018-11-23 11:58:14 --> Security Class Initialized
DEBUG - 2018-11-23 11:58:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-23 11:58:14 --> Input Class Initialized
INFO - 2018-11-23 11:58:14 --> Language Class Initialized
INFO - 2018-11-23 11:58:14 --> Loader Class Initialized
INFO - 2018-11-23 11:58:14 --> Helper loaded: url_helper
INFO - 2018-11-23 11:58:14 --> Helper loaded: file_helper
INFO - 2018-11-23 11:58:14 --> Helper loaded: email_helper
INFO - 2018-11-23 11:58:14 --> Helper loaded: common_helper
INFO - 2018-11-23 11:58:14 --> Database Driver Class Initialized
DEBUG - 2018-11-23 11:58:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-23 11:58:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-23 11:58:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-23 11:58:14 --> Pagination Class Initialized
INFO - 2018-11-23 11:58:14 --> Helper loaded: form_helper
INFO - 2018-11-23 11:58:14 --> Form Validation Class Initialized
INFO - 2018-11-23 11:58:14 --> Model Class Initialized
INFO - 2018-11-23 11:58:14 --> Controller Class Initialized
INFO - 2018-11-23 11:58:14 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-23 11:58:14 --> Model Class Initialized
INFO - 2018-11-23 11:58:14 --> Model Class Initialized
INFO - 2018-11-23 11:58:14 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-23 11:58:14 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/change-password.php
INFO - 2018-11-23 11:58:14 --> Final output sent to browser
DEBUG - 2018-11-23 11:58:14 --> Total execution time: 0.0750
INFO - 2018-11-23 11:58:42 --> Config Class Initialized
INFO - 2018-11-23 11:58:42 --> Hooks Class Initialized
DEBUG - 2018-11-23 11:58:42 --> UTF-8 Support Enabled
INFO - 2018-11-23 11:58:42 --> Utf8 Class Initialized
INFO - 2018-11-23 11:58:42 --> URI Class Initialized
INFO - 2018-11-23 11:58:42 --> Router Class Initialized
INFO - 2018-11-23 11:58:42 --> Output Class Initialized
INFO - 2018-11-23 11:58:42 --> Security Class Initialized
DEBUG - 2018-11-23 11:58:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-23 11:58:42 --> Input Class Initialized
INFO - 2018-11-23 11:58:42 --> Language Class Initialized
INFO - 2018-11-23 11:58:42 --> Loader Class Initialized
INFO - 2018-11-23 11:58:42 --> Helper loaded: url_helper
INFO - 2018-11-23 11:58:42 --> Helper loaded: file_helper
INFO - 2018-11-23 11:58:42 --> Helper loaded: email_helper
INFO - 2018-11-23 11:58:42 --> Helper loaded: common_helper
INFO - 2018-11-23 11:58:42 --> Database Driver Class Initialized
DEBUG - 2018-11-23 11:58:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-23 11:58:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-23 11:58:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-23 11:58:42 --> Pagination Class Initialized
INFO - 2018-11-23 11:58:42 --> Helper loaded: form_helper
INFO - 2018-11-23 11:58:42 --> Form Validation Class Initialized
INFO - 2018-11-23 11:58:42 --> Model Class Initialized
INFO - 2018-11-23 11:58:42 --> Controller Class Initialized
INFO - 2018-11-23 11:58:42 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-23 11:58:42 --> Model Class Initialized
INFO - 2018-11-23 11:58:42 --> Model Class Initialized
INFO - 2018-11-23 11:58:42 --> Config Class Initialized
INFO - 2018-11-23 11:58:42 --> Hooks Class Initialized
DEBUG - 2018-11-23 11:58:42 --> UTF-8 Support Enabled
INFO - 2018-11-23 11:58:42 --> Utf8 Class Initialized
INFO - 2018-11-23 11:58:42 --> URI Class Initialized
INFO - 2018-11-23 11:58:42 --> Router Class Initialized
INFO - 2018-11-23 11:58:42 --> Output Class Initialized
INFO - 2018-11-23 11:58:42 --> Security Class Initialized
DEBUG - 2018-11-23 11:58:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-23 11:58:42 --> Input Class Initialized
INFO - 2018-11-23 11:58:42 --> Language Class Initialized
INFO - 2018-11-23 11:58:42 --> Loader Class Initialized
INFO - 2018-11-23 11:58:42 --> Helper loaded: url_helper
INFO - 2018-11-23 11:58:42 --> Helper loaded: file_helper
INFO - 2018-11-23 11:58:42 --> Helper loaded: email_helper
INFO - 2018-11-23 11:58:42 --> Helper loaded: common_helper
INFO - 2018-11-23 11:58:42 --> Database Driver Class Initialized
DEBUG - 2018-11-23 11:58:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-23 11:58:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-23 11:58:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-23 11:58:42 --> Pagination Class Initialized
INFO - 2018-11-23 11:58:42 --> Helper loaded: form_helper
INFO - 2018-11-23 11:58:42 --> Form Validation Class Initialized
INFO - 2018-11-23 11:58:42 --> Model Class Initialized
INFO - 2018-11-23 11:58:42 --> Controller Class Initialized
INFO - 2018-11-23 11:58:42 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-23 11:58:42 --> Model Class Initialized
INFO - 2018-11-23 11:58:42 --> Model Class Initialized
INFO - 2018-11-23 11:58:42 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-23 11:58:42 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/change-password.php
INFO - 2018-11-23 11:58:42 --> Final output sent to browser
DEBUG - 2018-11-23 11:58:42 --> Total execution time: 0.0510
INFO - 2018-11-23 12:01:25 --> Config Class Initialized
INFO - 2018-11-23 12:01:25 --> Hooks Class Initialized
DEBUG - 2018-11-23 12:01:25 --> UTF-8 Support Enabled
INFO - 2018-11-23 12:01:25 --> Utf8 Class Initialized
INFO - 2018-11-23 12:01:25 --> URI Class Initialized
INFO - 2018-11-23 12:01:25 --> Router Class Initialized
INFO - 2018-11-23 12:01:25 --> Output Class Initialized
INFO - 2018-11-23 12:01:25 --> Security Class Initialized
DEBUG - 2018-11-23 12:01:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-23 12:01:25 --> Input Class Initialized
INFO - 2018-11-23 12:01:25 --> Language Class Initialized
INFO - 2018-11-23 12:01:25 --> Loader Class Initialized
INFO - 2018-11-23 12:01:25 --> Helper loaded: url_helper
INFO - 2018-11-23 12:01:25 --> Helper loaded: file_helper
INFO - 2018-11-23 12:01:25 --> Helper loaded: email_helper
INFO - 2018-11-23 12:01:25 --> Helper loaded: common_helper
INFO - 2018-11-23 12:01:25 --> Database Driver Class Initialized
DEBUG - 2018-11-23 12:01:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-23 12:01:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-23 12:01:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-23 12:01:25 --> Pagination Class Initialized
INFO - 2018-11-23 12:01:25 --> Helper loaded: form_helper
INFO - 2018-11-23 12:01:25 --> Form Validation Class Initialized
INFO - 2018-11-23 12:01:25 --> Model Class Initialized
INFO - 2018-11-23 12:01:25 --> Controller Class Initialized
INFO - 2018-11-23 12:01:25 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-23 12:01:25 --> Model Class Initialized
INFO - 2018-11-23 12:01:25 --> Model Class Initialized
INFO - 2018-11-23 12:01:25 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-23 12:01:25 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/change-password.php
INFO - 2018-11-23 12:01:25 --> Final output sent to browser
DEBUG - 2018-11-23 12:01:25 --> Total execution time: 0.0816
INFO - 2018-11-23 12:01:42 --> Config Class Initialized
INFO - 2018-11-23 12:01:42 --> Hooks Class Initialized
DEBUG - 2018-11-23 12:01:42 --> UTF-8 Support Enabled
INFO - 2018-11-23 12:01:42 --> Utf8 Class Initialized
INFO - 2018-11-23 12:01:42 --> URI Class Initialized
INFO - 2018-11-23 12:01:42 --> Router Class Initialized
INFO - 2018-11-23 12:01:42 --> Output Class Initialized
INFO - 2018-11-23 12:01:42 --> Security Class Initialized
DEBUG - 2018-11-23 12:01:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-23 12:01:42 --> Input Class Initialized
INFO - 2018-11-23 12:01:42 --> Language Class Initialized
INFO - 2018-11-23 12:01:42 --> Loader Class Initialized
INFO - 2018-11-23 12:01:42 --> Helper loaded: url_helper
INFO - 2018-11-23 12:01:42 --> Helper loaded: file_helper
INFO - 2018-11-23 12:01:42 --> Helper loaded: email_helper
INFO - 2018-11-23 12:01:42 --> Helper loaded: common_helper
INFO - 2018-11-23 12:01:42 --> Database Driver Class Initialized
DEBUG - 2018-11-23 12:01:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-23 12:01:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-23 12:01:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-23 12:01:42 --> Pagination Class Initialized
INFO - 2018-11-23 12:01:42 --> Helper loaded: form_helper
INFO - 2018-11-23 12:01:42 --> Form Validation Class Initialized
INFO - 2018-11-23 12:01:42 --> Model Class Initialized
INFO - 2018-11-23 12:01:42 --> Controller Class Initialized
INFO - 2018-11-23 12:01:42 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-23 12:01:42 --> Model Class Initialized
INFO - 2018-11-23 12:01:42 --> Model Class Initialized
INFO - 2018-11-23 12:01:42 --> Config Class Initialized
INFO - 2018-11-23 12:01:42 --> Hooks Class Initialized
DEBUG - 2018-11-23 12:01:42 --> UTF-8 Support Enabled
INFO - 2018-11-23 12:01:42 --> Utf8 Class Initialized
INFO - 2018-11-23 12:01:42 --> URI Class Initialized
INFO - 2018-11-23 12:01:42 --> Router Class Initialized
INFO - 2018-11-23 12:01:42 --> Output Class Initialized
INFO - 2018-11-23 12:01:42 --> Security Class Initialized
DEBUG - 2018-11-23 12:01:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-23 12:01:42 --> Input Class Initialized
INFO - 2018-11-23 12:01:42 --> Language Class Initialized
INFO - 2018-11-23 12:01:42 --> Loader Class Initialized
INFO - 2018-11-23 12:01:42 --> Helper loaded: url_helper
INFO - 2018-11-23 12:01:42 --> Helper loaded: file_helper
INFO - 2018-11-23 12:01:42 --> Helper loaded: email_helper
INFO - 2018-11-23 12:01:42 --> Helper loaded: common_helper
INFO - 2018-11-23 12:01:42 --> Database Driver Class Initialized
DEBUG - 2018-11-23 12:01:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-23 12:01:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-23 12:01:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-23 12:01:42 --> Pagination Class Initialized
INFO - 2018-11-23 12:01:42 --> Helper loaded: form_helper
INFO - 2018-11-23 12:01:42 --> Form Validation Class Initialized
INFO - 2018-11-23 12:01:42 --> Model Class Initialized
INFO - 2018-11-23 12:01:42 --> Controller Class Initialized
INFO - 2018-11-23 12:01:42 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-23 12:01:42 --> Model Class Initialized
INFO - 2018-11-23 12:01:42 --> Model Class Initialized
INFO - 2018-11-23 12:01:42 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-23 12:01:42 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/change-password.php
INFO - 2018-11-23 12:01:42 --> Final output sent to browser
DEBUG - 2018-11-23 12:01:42 --> Total execution time: 0.0560
INFO - 2018-11-23 12:02:03 --> Config Class Initialized
INFO - 2018-11-23 12:02:03 --> Hooks Class Initialized
DEBUG - 2018-11-23 12:02:03 --> UTF-8 Support Enabled
INFO - 2018-11-23 12:02:03 --> Utf8 Class Initialized
INFO - 2018-11-23 12:02:03 --> URI Class Initialized
INFO - 2018-11-23 12:02:03 --> Router Class Initialized
INFO - 2018-11-23 12:02:03 --> Output Class Initialized
INFO - 2018-11-23 12:02:03 --> Security Class Initialized
DEBUG - 2018-11-23 12:02:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-23 12:02:03 --> Input Class Initialized
INFO - 2018-11-23 12:02:03 --> Language Class Initialized
INFO - 2018-11-23 12:02:03 --> Loader Class Initialized
INFO - 2018-11-23 12:02:03 --> Helper loaded: url_helper
INFO - 2018-11-23 12:02:03 --> Helper loaded: file_helper
INFO - 2018-11-23 12:02:03 --> Helper loaded: email_helper
INFO - 2018-11-23 12:02:03 --> Helper loaded: common_helper
INFO - 2018-11-23 12:02:03 --> Database Driver Class Initialized
DEBUG - 2018-11-23 12:02:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-23 12:02:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-23 12:02:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-23 12:02:03 --> Pagination Class Initialized
INFO - 2018-11-23 12:02:03 --> Helper loaded: form_helper
INFO - 2018-11-23 12:02:03 --> Form Validation Class Initialized
INFO - 2018-11-23 12:02:03 --> Model Class Initialized
INFO - 2018-11-23 12:02:03 --> Controller Class Initialized
INFO - 2018-11-23 12:02:03 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-23 12:02:03 --> Model Class Initialized
INFO - 2018-11-23 12:02:03 --> Model Class Initialized
INFO - 2018-11-23 12:02:03 --> Config Class Initialized
INFO - 2018-11-23 12:02:03 --> Hooks Class Initialized
DEBUG - 2018-11-23 12:02:03 --> UTF-8 Support Enabled
INFO - 2018-11-23 12:02:03 --> Utf8 Class Initialized
INFO - 2018-11-23 12:02:03 --> URI Class Initialized
INFO - 2018-11-23 12:02:03 --> Router Class Initialized
INFO - 2018-11-23 12:02:03 --> Output Class Initialized
INFO - 2018-11-23 12:02:03 --> Security Class Initialized
DEBUG - 2018-11-23 12:02:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-23 12:02:03 --> Input Class Initialized
INFO - 2018-11-23 12:02:03 --> Language Class Initialized
INFO - 2018-11-23 12:02:03 --> Loader Class Initialized
INFO - 2018-11-23 12:02:03 --> Helper loaded: url_helper
INFO - 2018-11-23 12:02:03 --> Helper loaded: file_helper
INFO - 2018-11-23 12:02:03 --> Helper loaded: email_helper
INFO - 2018-11-23 12:02:03 --> Helper loaded: common_helper
INFO - 2018-11-23 12:02:03 --> Database Driver Class Initialized
DEBUG - 2018-11-23 12:02:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-23 12:02:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-23 12:02:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-23 12:02:03 --> Pagination Class Initialized
INFO - 2018-11-23 12:02:03 --> Helper loaded: form_helper
INFO - 2018-11-23 12:02:03 --> Form Validation Class Initialized
INFO - 2018-11-23 12:02:03 --> Model Class Initialized
INFO - 2018-11-23 12:02:03 --> Controller Class Initialized
INFO - 2018-11-23 12:02:03 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-23 12:02:03 --> Model Class Initialized
INFO - 2018-11-23 12:02:04 --> Model Class Initialized
INFO - 2018-11-23 12:02:04 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-23 12:02:04 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/change-password.php
INFO - 2018-11-23 12:02:04 --> Final output sent to browser
DEBUG - 2018-11-23 12:02:04 --> Total execution time: 0.0580
INFO - 2018-11-23 12:05:23 --> Config Class Initialized
INFO - 2018-11-23 12:05:23 --> Hooks Class Initialized
DEBUG - 2018-11-23 12:05:23 --> UTF-8 Support Enabled
INFO - 2018-11-23 12:05:23 --> Utf8 Class Initialized
INFO - 2018-11-23 12:05:23 --> URI Class Initialized
INFO - 2018-11-23 12:05:23 --> Router Class Initialized
INFO - 2018-11-23 12:05:23 --> Output Class Initialized
INFO - 2018-11-23 12:05:23 --> Security Class Initialized
DEBUG - 2018-11-23 12:05:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-23 12:05:23 --> Input Class Initialized
INFO - 2018-11-23 12:05:23 --> Language Class Initialized
INFO - 2018-11-23 12:05:23 --> Loader Class Initialized
INFO - 2018-11-23 12:05:23 --> Helper loaded: url_helper
INFO - 2018-11-23 12:05:23 --> Helper loaded: file_helper
INFO - 2018-11-23 12:05:23 --> Helper loaded: email_helper
INFO - 2018-11-23 12:05:23 --> Helper loaded: common_helper
INFO - 2018-11-23 12:05:23 --> Database Driver Class Initialized
DEBUG - 2018-11-23 12:05:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-23 12:05:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-23 12:05:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-23 12:05:23 --> Pagination Class Initialized
INFO - 2018-11-23 12:05:23 --> Helper loaded: form_helper
INFO - 2018-11-23 12:05:23 --> Form Validation Class Initialized
INFO - 2018-11-23 12:05:23 --> Model Class Initialized
INFO - 2018-11-23 12:05:23 --> Controller Class Initialized
INFO - 2018-11-23 12:05:23 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-23 12:05:23 --> Model Class Initialized
INFO - 2018-11-23 12:05:23 --> Model Class Initialized
INFO - 2018-11-23 12:05:23 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-23 12:05:23 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/change-password.php
INFO - 2018-11-23 12:05:23 --> Final output sent to browser
DEBUG - 2018-11-23 12:05:23 --> Total execution time: 0.0540
INFO - 2018-11-23 12:10:27 --> Config Class Initialized
INFO - 2018-11-23 12:10:27 --> Hooks Class Initialized
DEBUG - 2018-11-23 12:10:27 --> UTF-8 Support Enabled
INFO - 2018-11-23 12:10:27 --> Utf8 Class Initialized
INFO - 2018-11-23 12:10:27 --> URI Class Initialized
INFO - 2018-11-23 12:10:27 --> Router Class Initialized
INFO - 2018-11-23 12:10:27 --> Output Class Initialized
INFO - 2018-11-23 12:10:27 --> Security Class Initialized
DEBUG - 2018-11-23 12:10:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-23 12:10:27 --> Input Class Initialized
INFO - 2018-11-23 12:10:27 --> Language Class Initialized
INFO - 2018-11-23 12:10:27 --> Loader Class Initialized
INFO - 2018-11-23 12:10:27 --> Helper loaded: url_helper
INFO - 2018-11-23 12:10:27 --> Helper loaded: file_helper
INFO - 2018-11-23 12:10:27 --> Helper loaded: email_helper
INFO - 2018-11-23 12:10:27 --> Helper loaded: common_helper
INFO - 2018-11-23 12:10:27 --> Database Driver Class Initialized
DEBUG - 2018-11-23 12:10:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-23 12:10:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-23 12:10:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-23 12:10:27 --> Pagination Class Initialized
INFO - 2018-11-23 12:10:27 --> Helper loaded: form_helper
INFO - 2018-11-23 12:10:27 --> Form Validation Class Initialized
INFO - 2018-11-23 12:10:27 --> Model Class Initialized
INFO - 2018-11-23 12:10:27 --> Controller Class Initialized
INFO - 2018-11-23 12:10:27 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-23 12:10:27 --> Model Class Initialized
INFO - 2018-11-23 12:10:27 --> Model Class Initialized
INFO - 2018-11-23 12:10:27 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-23 12:10:27 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/change-password.php
INFO - 2018-11-23 12:10:27 --> Final output sent to browser
DEBUG - 2018-11-23 12:10:27 --> Total execution time: 0.0530
INFO - 2018-11-23 12:12:44 --> Config Class Initialized
INFO - 2018-11-23 12:12:44 --> Hooks Class Initialized
DEBUG - 2018-11-23 12:12:44 --> UTF-8 Support Enabled
INFO - 2018-11-23 12:12:44 --> Utf8 Class Initialized
INFO - 2018-11-23 12:12:44 --> URI Class Initialized
INFO - 2018-11-23 12:12:44 --> Router Class Initialized
INFO - 2018-11-23 12:12:44 --> Output Class Initialized
INFO - 2018-11-23 12:12:44 --> Security Class Initialized
DEBUG - 2018-11-23 12:12:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-23 12:12:44 --> Input Class Initialized
INFO - 2018-11-23 12:12:44 --> Language Class Initialized
INFO - 2018-11-23 12:12:44 --> Loader Class Initialized
INFO - 2018-11-23 12:12:44 --> Helper loaded: url_helper
INFO - 2018-11-23 12:12:44 --> Helper loaded: file_helper
INFO - 2018-11-23 12:12:44 --> Helper loaded: email_helper
INFO - 2018-11-23 12:12:44 --> Helper loaded: common_helper
INFO - 2018-11-23 12:12:44 --> Database Driver Class Initialized
DEBUG - 2018-11-23 12:12:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-23 12:12:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-23 12:12:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-23 12:12:44 --> Pagination Class Initialized
INFO - 2018-11-23 12:12:44 --> Helper loaded: form_helper
INFO - 2018-11-23 12:12:44 --> Form Validation Class Initialized
INFO - 2018-11-23 12:12:44 --> Model Class Initialized
INFO - 2018-11-23 12:12:44 --> Controller Class Initialized
INFO - 2018-11-23 12:12:44 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-23 12:12:44 --> Model Class Initialized
INFO - 2018-11-23 12:12:44 --> Model Class Initialized
INFO - 2018-11-23 12:12:44 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-23 12:12:44 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/change-password.php
INFO - 2018-11-23 12:12:44 --> Final output sent to browser
DEBUG - 2018-11-23 12:12:44 --> Total execution time: 0.0470
INFO - 2018-11-23 12:13:39 --> Config Class Initialized
INFO - 2018-11-23 12:13:39 --> Hooks Class Initialized
DEBUG - 2018-11-23 12:13:39 --> UTF-8 Support Enabled
INFO - 2018-11-23 12:13:39 --> Utf8 Class Initialized
INFO - 2018-11-23 12:13:39 --> URI Class Initialized
INFO - 2018-11-23 12:13:39 --> Router Class Initialized
INFO - 2018-11-23 12:13:39 --> Output Class Initialized
INFO - 2018-11-23 12:13:39 --> Security Class Initialized
DEBUG - 2018-11-23 12:13:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-23 12:13:39 --> Input Class Initialized
INFO - 2018-11-23 12:13:39 --> Language Class Initialized
INFO - 2018-11-23 12:13:39 --> Loader Class Initialized
INFO - 2018-11-23 12:13:39 --> Helper loaded: url_helper
INFO - 2018-11-23 12:13:39 --> Helper loaded: file_helper
INFO - 2018-11-23 12:13:39 --> Helper loaded: email_helper
INFO - 2018-11-23 12:13:39 --> Helper loaded: common_helper
INFO - 2018-11-23 12:13:39 --> Database Driver Class Initialized
DEBUG - 2018-11-23 12:13:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-23 12:13:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-23 12:13:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-23 12:13:39 --> Pagination Class Initialized
INFO - 2018-11-23 12:13:39 --> Helper loaded: form_helper
INFO - 2018-11-23 12:13:39 --> Form Validation Class Initialized
INFO - 2018-11-23 12:13:39 --> Model Class Initialized
INFO - 2018-11-23 12:13:39 --> Controller Class Initialized
INFO - 2018-11-23 12:13:39 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-23 12:13:39 --> Model Class Initialized
INFO - 2018-11-23 12:13:39 --> Model Class Initialized
INFO - 2018-11-23 12:13:39 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-23 12:13:39 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/change-password.php
INFO - 2018-11-23 12:13:39 --> Final output sent to browser
DEBUG - 2018-11-23 12:13:39 --> Total execution time: 0.0590
INFO - 2018-11-23 12:14:07 --> Config Class Initialized
INFO - 2018-11-23 12:14:07 --> Hooks Class Initialized
DEBUG - 2018-11-23 12:14:08 --> UTF-8 Support Enabled
INFO - 2018-11-23 12:14:08 --> Utf8 Class Initialized
INFO - 2018-11-23 12:14:08 --> URI Class Initialized
INFO - 2018-11-23 12:14:08 --> Router Class Initialized
INFO - 2018-11-23 12:14:08 --> Output Class Initialized
INFO - 2018-11-23 12:14:08 --> Security Class Initialized
DEBUG - 2018-11-23 12:14:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-23 12:14:08 --> Input Class Initialized
INFO - 2018-11-23 12:14:08 --> Language Class Initialized
INFO - 2018-11-23 12:14:08 --> Loader Class Initialized
INFO - 2018-11-23 12:14:08 --> Helper loaded: url_helper
INFO - 2018-11-23 12:14:08 --> Helper loaded: file_helper
INFO - 2018-11-23 12:14:08 --> Helper loaded: email_helper
INFO - 2018-11-23 12:14:08 --> Helper loaded: common_helper
INFO - 2018-11-23 12:14:08 --> Database Driver Class Initialized
DEBUG - 2018-11-23 12:14:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-23 12:14:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-23 12:14:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-23 12:14:08 --> Pagination Class Initialized
INFO - 2018-11-23 12:14:08 --> Helper loaded: form_helper
INFO - 2018-11-23 12:14:08 --> Form Validation Class Initialized
INFO - 2018-11-23 12:14:08 --> Model Class Initialized
INFO - 2018-11-23 12:14:08 --> Controller Class Initialized
INFO - 2018-11-23 12:14:08 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-23 12:14:08 --> Model Class Initialized
INFO - 2018-11-23 12:14:08 --> Model Class Initialized
INFO - 2018-11-23 12:14:08 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-23 12:14:08 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/change-password.php
INFO - 2018-11-23 12:14:08 --> Final output sent to browser
DEBUG - 2018-11-23 12:14:08 --> Total execution time: 0.0610
INFO - 2018-11-23 12:14:24 --> Config Class Initialized
INFO - 2018-11-23 12:14:24 --> Hooks Class Initialized
DEBUG - 2018-11-23 12:14:24 --> UTF-8 Support Enabled
INFO - 2018-11-23 12:14:24 --> Utf8 Class Initialized
INFO - 2018-11-23 12:14:24 --> URI Class Initialized
INFO - 2018-11-23 12:14:24 --> Router Class Initialized
INFO - 2018-11-23 12:14:24 --> Output Class Initialized
INFO - 2018-11-23 12:14:24 --> Security Class Initialized
DEBUG - 2018-11-23 12:14:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-23 12:14:24 --> Input Class Initialized
INFO - 2018-11-23 12:14:24 --> Language Class Initialized
INFO - 2018-11-23 12:14:24 --> Loader Class Initialized
INFO - 2018-11-23 12:14:24 --> Helper loaded: url_helper
INFO - 2018-11-23 12:14:24 --> Helper loaded: file_helper
INFO - 2018-11-23 12:14:24 --> Helper loaded: email_helper
INFO - 2018-11-23 12:14:24 --> Helper loaded: common_helper
INFO - 2018-11-23 12:14:24 --> Database Driver Class Initialized
DEBUG - 2018-11-23 12:14:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-23 12:14:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-23 12:14:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-23 12:14:24 --> Pagination Class Initialized
INFO - 2018-11-23 12:14:24 --> Helper loaded: form_helper
INFO - 2018-11-23 12:14:24 --> Form Validation Class Initialized
INFO - 2018-11-23 12:14:24 --> Model Class Initialized
INFO - 2018-11-23 12:14:24 --> Controller Class Initialized
INFO - 2018-11-23 12:14:24 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-23 12:14:24 --> Model Class Initialized
INFO - 2018-11-23 12:14:24 --> Model Class Initialized
INFO - 2018-11-23 12:14:24 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-23 12:14:24 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/change-password.php
INFO - 2018-11-23 12:14:24 --> Final output sent to browser
DEBUG - 2018-11-23 12:14:24 --> Total execution time: 0.0610
INFO - 2018-11-23 12:15:11 --> Config Class Initialized
INFO - 2018-11-23 12:15:11 --> Hooks Class Initialized
DEBUG - 2018-11-23 12:15:11 --> UTF-8 Support Enabled
INFO - 2018-11-23 12:15:11 --> Utf8 Class Initialized
INFO - 2018-11-23 12:15:11 --> URI Class Initialized
INFO - 2018-11-23 12:15:11 --> Router Class Initialized
INFO - 2018-11-23 12:15:11 --> Output Class Initialized
INFO - 2018-11-23 12:15:11 --> Security Class Initialized
DEBUG - 2018-11-23 12:15:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-23 12:15:11 --> Input Class Initialized
INFO - 2018-11-23 12:15:11 --> Language Class Initialized
INFO - 2018-11-23 12:15:12 --> Loader Class Initialized
INFO - 2018-11-23 12:15:12 --> Helper loaded: url_helper
INFO - 2018-11-23 12:15:12 --> Helper loaded: file_helper
INFO - 2018-11-23 12:15:12 --> Helper loaded: email_helper
INFO - 2018-11-23 12:15:12 --> Helper loaded: common_helper
INFO - 2018-11-23 12:15:12 --> Database Driver Class Initialized
DEBUG - 2018-11-23 12:15:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-23 12:15:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-23 12:15:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-23 12:15:12 --> Pagination Class Initialized
INFO - 2018-11-23 12:15:12 --> Helper loaded: form_helper
INFO - 2018-11-23 12:15:12 --> Form Validation Class Initialized
INFO - 2018-11-23 12:15:12 --> Model Class Initialized
INFO - 2018-11-23 12:15:12 --> Controller Class Initialized
INFO - 2018-11-23 12:15:12 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-23 12:15:12 --> Model Class Initialized
INFO - 2018-11-23 12:15:12 --> Model Class Initialized
INFO - 2018-11-23 12:15:12 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-23 12:15:12 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/change-password.php
INFO - 2018-11-23 12:15:12 --> Final output sent to browser
DEBUG - 2018-11-23 12:15:12 --> Total execution time: 0.0540
INFO - 2018-11-23 12:15:25 --> Config Class Initialized
INFO - 2018-11-23 12:15:25 --> Hooks Class Initialized
DEBUG - 2018-11-23 12:15:25 --> UTF-8 Support Enabled
INFO - 2018-11-23 12:15:25 --> Utf8 Class Initialized
INFO - 2018-11-23 12:15:25 --> URI Class Initialized
INFO - 2018-11-23 12:15:25 --> Router Class Initialized
INFO - 2018-11-23 12:15:25 --> Output Class Initialized
INFO - 2018-11-23 12:15:25 --> Security Class Initialized
DEBUG - 2018-11-23 12:15:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-23 12:15:25 --> Input Class Initialized
INFO - 2018-11-23 12:15:25 --> Language Class Initialized
INFO - 2018-11-23 12:15:25 --> Loader Class Initialized
INFO - 2018-11-23 12:15:25 --> Helper loaded: url_helper
INFO - 2018-11-23 12:15:25 --> Helper loaded: file_helper
INFO - 2018-11-23 12:15:25 --> Helper loaded: email_helper
INFO - 2018-11-23 12:15:25 --> Helper loaded: common_helper
INFO - 2018-11-23 12:15:25 --> Database Driver Class Initialized
DEBUG - 2018-11-23 12:15:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-23 12:15:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-23 12:15:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-23 12:15:25 --> Pagination Class Initialized
INFO - 2018-11-23 12:15:25 --> Helper loaded: form_helper
INFO - 2018-11-23 12:15:25 --> Form Validation Class Initialized
INFO - 2018-11-23 12:15:26 --> Model Class Initialized
INFO - 2018-11-23 12:15:26 --> Controller Class Initialized
INFO - 2018-11-23 12:15:26 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-23 12:15:26 --> Model Class Initialized
INFO - 2018-11-23 12:15:26 --> Model Class Initialized
INFO - 2018-11-23 12:15:26 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-23 12:15:26 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/change-password.php
INFO - 2018-11-23 12:15:26 --> Final output sent to browser
DEBUG - 2018-11-23 12:15:26 --> Total execution time: 0.0590
INFO - 2018-11-23 12:15:49 --> Config Class Initialized
INFO - 2018-11-23 12:15:49 --> Hooks Class Initialized
DEBUG - 2018-11-23 12:15:49 --> UTF-8 Support Enabled
INFO - 2018-11-23 12:15:49 --> Utf8 Class Initialized
INFO - 2018-11-23 12:15:49 --> URI Class Initialized
INFO - 2018-11-23 12:15:49 --> Router Class Initialized
INFO - 2018-11-23 12:15:49 --> Output Class Initialized
INFO - 2018-11-23 12:15:49 --> Security Class Initialized
DEBUG - 2018-11-23 12:15:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-23 12:15:49 --> Input Class Initialized
INFO - 2018-11-23 12:15:49 --> Language Class Initialized
INFO - 2018-11-23 12:15:49 --> Loader Class Initialized
INFO - 2018-11-23 12:15:49 --> Helper loaded: url_helper
INFO - 2018-11-23 12:15:49 --> Helper loaded: file_helper
INFO - 2018-11-23 12:15:49 --> Helper loaded: email_helper
INFO - 2018-11-23 12:15:49 --> Helper loaded: common_helper
INFO - 2018-11-23 12:15:49 --> Database Driver Class Initialized
DEBUG - 2018-11-23 12:15:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-23 12:15:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-23 12:15:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-23 12:15:49 --> Pagination Class Initialized
INFO - 2018-11-23 12:15:49 --> Helper loaded: form_helper
INFO - 2018-11-23 12:15:49 --> Form Validation Class Initialized
INFO - 2018-11-23 12:15:49 --> Model Class Initialized
INFO - 2018-11-23 12:15:49 --> Controller Class Initialized
INFO - 2018-11-23 12:15:49 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-23 12:15:49 --> Model Class Initialized
INFO - 2018-11-23 12:15:49 --> Model Class Initialized
INFO - 2018-11-23 12:15:49 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-23 12:15:49 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/change-password.php
INFO - 2018-11-23 12:15:49 --> Final output sent to browser
DEBUG - 2018-11-23 12:15:49 --> Total execution time: 0.0620
INFO - 2018-11-23 12:16:41 --> Config Class Initialized
INFO - 2018-11-23 12:16:41 --> Hooks Class Initialized
DEBUG - 2018-11-23 12:16:41 --> UTF-8 Support Enabled
INFO - 2018-11-23 12:16:41 --> Utf8 Class Initialized
INFO - 2018-11-23 12:16:41 --> URI Class Initialized
INFO - 2018-11-23 12:16:41 --> Router Class Initialized
INFO - 2018-11-23 12:16:41 --> Output Class Initialized
INFO - 2018-11-23 12:16:41 --> Security Class Initialized
DEBUG - 2018-11-23 12:16:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-23 12:16:41 --> Input Class Initialized
INFO - 2018-11-23 12:16:41 --> Language Class Initialized
INFO - 2018-11-23 12:16:41 --> Loader Class Initialized
INFO - 2018-11-23 12:16:41 --> Helper loaded: url_helper
INFO - 2018-11-23 12:16:41 --> Helper loaded: file_helper
INFO - 2018-11-23 12:16:41 --> Helper loaded: email_helper
INFO - 2018-11-23 12:16:41 --> Helper loaded: common_helper
INFO - 2018-11-23 12:16:41 --> Database Driver Class Initialized
DEBUG - 2018-11-23 12:16:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-23 12:16:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-23 12:16:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-23 12:16:41 --> Pagination Class Initialized
INFO - 2018-11-23 12:16:41 --> Helper loaded: form_helper
INFO - 2018-11-23 12:16:41 --> Form Validation Class Initialized
INFO - 2018-11-23 12:16:41 --> Model Class Initialized
INFO - 2018-11-23 12:16:41 --> Controller Class Initialized
INFO - 2018-11-23 12:16:41 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-23 12:16:41 --> Model Class Initialized
INFO - 2018-11-23 12:16:41 --> Model Class Initialized
INFO - 2018-11-23 12:16:41 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-23 12:16:41 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/change-password.php
INFO - 2018-11-23 12:16:41 --> Final output sent to browser
DEBUG - 2018-11-23 12:16:41 --> Total execution time: 0.0510
INFO - 2018-11-23 12:17:30 --> Config Class Initialized
INFO - 2018-11-23 12:17:30 --> Hooks Class Initialized
DEBUG - 2018-11-23 12:17:30 --> UTF-8 Support Enabled
INFO - 2018-11-23 12:17:30 --> Utf8 Class Initialized
INFO - 2018-11-23 12:17:30 --> URI Class Initialized
INFO - 2018-11-23 12:17:30 --> Router Class Initialized
INFO - 2018-11-23 12:17:30 --> Output Class Initialized
INFO - 2018-11-23 12:17:30 --> Security Class Initialized
DEBUG - 2018-11-23 12:17:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-23 12:17:30 --> Input Class Initialized
INFO - 2018-11-23 12:17:30 --> Language Class Initialized
INFO - 2018-11-23 12:17:30 --> Loader Class Initialized
INFO - 2018-11-23 12:17:30 --> Helper loaded: url_helper
INFO - 2018-11-23 12:17:30 --> Helper loaded: file_helper
INFO - 2018-11-23 12:17:30 --> Helper loaded: email_helper
INFO - 2018-11-23 12:17:30 --> Helper loaded: common_helper
INFO - 2018-11-23 12:17:30 --> Database Driver Class Initialized
DEBUG - 2018-11-23 12:17:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-23 12:17:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-23 12:17:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-23 12:17:30 --> Pagination Class Initialized
INFO - 2018-11-23 12:17:30 --> Helper loaded: form_helper
INFO - 2018-11-23 12:17:30 --> Form Validation Class Initialized
INFO - 2018-11-23 12:17:30 --> Model Class Initialized
INFO - 2018-11-23 12:17:30 --> Controller Class Initialized
INFO - 2018-11-23 12:17:30 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-23 12:17:30 --> Model Class Initialized
INFO - 2018-11-23 12:17:30 --> Model Class Initialized
INFO - 2018-11-23 12:17:30 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-23 12:17:30 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/change-password.php
INFO - 2018-11-23 12:17:30 --> Final output sent to browser
DEBUG - 2018-11-23 12:17:30 --> Total execution time: 0.0640
INFO - 2018-11-23 12:18:44 --> Config Class Initialized
INFO - 2018-11-23 12:18:44 --> Hooks Class Initialized
DEBUG - 2018-11-23 12:18:44 --> UTF-8 Support Enabled
INFO - 2018-11-23 12:18:44 --> Utf8 Class Initialized
INFO - 2018-11-23 12:18:44 --> URI Class Initialized
INFO - 2018-11-23 12:18:44 --> Router Class Initialized
INFO - 2018-11-23 12:18:44 --> Output Class Initialized
INFO - 2018-11-23 12:18:44 --> Security Class Initialized
DEBUG - 2018-11-23 12:18:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-23 12:18:44 --> Input Class Initialized
INFO - 2018-11-23 12:18:44 --> Language Class Initialized
INFO - 2018-11-23 12:18:44 --> Loader Class Initialized
INFO - 2018-11-23 12:18:44 --> Helper loaded: url_helper
INFO - 2018-11-23 12:18:44 --> Helper loaded: file_helper
INFO - 2018-11-23 12:18:44 --> Helper loaded: email_helper
INFO - 2018-11-23 12:18:44 --> Helper loaded: common_helper
INFO - 2018-11-23 12:18:44 --> Database Driver Class Initialized
DEBUG - 2018-11-23 12:18:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-23 12:18:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-23 12:18:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-23 12:18:44 --> Pagination Class Initialized
INFO - 2018-11-23 12:18:44 --> Helper loaded: form_helper
INFO - 2018-11-23 12:18:44 --> Form Validation Class Initialized
INFO - 2018-11-23 12:18:44 --> Model Class Initialized
INFO - 2018-11-23 12:18:44 --> Controller Class Initialized
INFO - 2018-11-23 12:18:44 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-23 12:18:44 --> Model Class Initialized
INFO - 2018-11-23 12:18:44 --> Model Class Initialized
INFO - 2018-11-23 12:18:44 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-23 12:18:44 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/change-password.php
INFO - 2018-11-23 12:18:44 --> Final output sent to browser
DEBUG - 2018-11-23 12:18:44 --> Total execution time: 0.0720
INFO - 2018-11-23 12:18:51 --> Config Class Initialized
INFO - 2018-11-23 12:18:51 --> Hooks Class Initialized
DEBUG - 2018-11-23 12:18:51 --> UTF-8 Support Enabled
INFO - 2018-11-23 12:18:51 --> Utf8 Class Initialized
INFO - 2018-11-23 12:18:51 --> URI Class Initialized
INFO - 2018-11-23 12:18:51 --> Router Class Initialized
INFO - 2018-11-23 12:18:51 --> Output Class Initialized
INFO - 2018-11-23 12:18:51 --> Security Class Initialized
DEBUG - 2018-11-23 12:18:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-23 12:18:51 --> Input Class Initialized
INFO - 2018-11-23 12:18:51 --> Language Class Initialized
INFO - 2018-11-23 12:18:51 --> Loader Class Initialized
INFO - 2018-11-23 12:18:51 --> Helper loaded: url_helper
INFO - 2018-11-23 12:18:51 --> Helper loaded: file_helper
INFO - 2018-11-23 12:18:51 --> Helper loaded: email_helper
INFO - 2018-11-23 12:18:51 --> Helper loaded: common_helper
INFO - 2018-11-23 12:18:51 --> Database Driver Class Initialized
DEBUG - 2018-11-23 12:18:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-23 12:18:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-23 12:18:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-23 12:18:51 --> Pagination Class Initialized
INFO - 2018-11-23 12:18:51 --> Helper loaded: form_helper
INFO - 2018-11-23 12:18:51 --> Form Validation Class Initialized
INFO - 2018-11-23 12:18:51 --> Model Class Initialized
INFO - 2018-11-23 12:18:51 --> Controller Class Initialized
INFO - 2018-11-23 12:18:51 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-23 12:18:51 --> Model Class Initialized
INFO - 2018-11-23 12:18:51 --> Model Class Initialized
INFO - 2018-11-23 12:18:51 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-23 12:18:51 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/change-password.php
INFO - 2018-11-23 12:18:51 --> Final output sent to browser
DEBUG - 2018-11-23 12:18:51 --> Total execution time: 0.0570
INFO - 2018-11-23 12:20:33 --> Config Class Initialized
INFO - 2018-11-23 12:20:33 --> Hooks Class Initialized
DEBUG - 2018-11-23 12:20:33 --> UTF-8 Support Enabled
INFO - 2018-11-23 12:20:33 --> Utf8 Class Initialized
INFO - 2018-11-23 12:20:33 --> URI Class Initialized
INFO - 2018-11-23 12:20:33 --> Router Class Initialized
INFO - 2018-11-23 12:20:33 --> Output Class Initialized
INFO - 2018-11-23 12:20:33 --> Security Class Initialized
DEBUG - 2018-11-23 12:20:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-23 12:20:33 --> Input Class Initialized
INFO - 2018-11-23 12:20:33 --> Language Class Initialized
INFO - 2018-11-23 12:20:33 --> Loader Class Initialized
INFO - 2018-11-23 12:20:33 --> Helper loaded: url_helper
INFO - 2018-11-23 12:20:33 --> Helper loaded: file_helper
INFO - 2018-11-23 12:20:33 --> Helper loaded: email_helper
INFO - 2018-11-23 12:20:33 --> Helper loaded: common_helper
INFO - 2018-11-23 12:20:33 --> Database Driver Class Initialized
DEBUG - 2018-11-23 12:20:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-23 12:20:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-23 12:20:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-23 12:20:33 --> Pagination Class Initialized
INFO - 2018-11-23 12:20:33 --> Helper loaded: form_helper
INFO - 2018-11-23 12:20:33 --> Form Validation Class Initialized
INFO - 2018-11-23 12:20:33 --> Model Class Initialized
INFO - 2018-11-23 12:20:33 --> Controller Class Initialized
INFO - 2018-11-23 12:20:33 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-23 12:20:33 --> Model Class Initialized
INFO - 2018-11-23 12:20:33 --> Model Class Initialized
INFO - 2018-11-23 12:20:33 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-23 12:20:33 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/change-password.php
INFO - 2018-11-23 12:20:33 --> Final output sent to browser
DEBUG - 2018-11-23 12:20:33 --> Total execution time: 0.0470
INFO - 2018-11-23 12:20:59 --> Config Class Initialized
INFO - 2018-11-23 12:20:59 --> Hooks Class Initialized
DEBUG - 2018-11-23 12:20:59 --> UTF-8 Support Enabled
INFO - 2018-11-23 12:20:59 --> Utf8 Class Initialized
INFO - 2018-11-23 12:20:59 --> URI Class Initialized
INFO - 2018-11-23 12:20:59 --> Router Class Initialized
INFO - 2018-11-23 12:20:59 --> Output Class Initialized
INFO - 2018-11-23 12:20:59 --> Security Class Initialized
DEBUG - 2018-11-23 12:20:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-23 12:20:59 --> Input Class Initialized
INFO - 2018-11-23 12:20:59 --> Language Class Initialized
INFO - 2018-11-23 12:20:59 --> Loader Class Initialized
INFO - 2018-11-23 12:20:59 --> Helper loaded: url_helper
INFO - 2018-11-23 12:20:59 --> Helper loaded: file_helper
INFO - 2018-11-23 12:20:59 --> Helper loaded: email_helper
INFO - 2018-11-23 12:20:59 --> Helper loaded: common_helper
INFO - 2018-11-23 12:20:59 --> Database Driver Class Initialized
DEBUG - 2018-11-23 12:20:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-23 12:20:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-23 12:20:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-23 12:20:59 --> Pagination Class Initialized
INFO - 2018-11-23 12:20:59 --> Helper loaded: form_helper
INFO - 2018-11-23 12:20:59 --> Form Validation Class Initialized
INFO - 2018-11-23 12:20:59 --> Model Class Initialized
INFO - 2018-11-23 12:20:59 --> Controller Class Initialized
INFO - 2018-11-23 12:20:59 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-23 12:20:59 --> Model Class Initialized
INFO - 2018-11-23 12:20:59 --> Model Class Initialized
INFO - 2018-11-23 12:20:59 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-23 12:20:59 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/change-password.php
INFO - 2018-11-23 12:20:59 --> Final output sent to browser
DEBUG - 2018-11-23 12:20:59 --> Total execution time: 0.0560
INFO - 2018-11-23 12:22:58 --> Config Class Initialized
INFO - 2018-11-23 12:22:58 --> Hooks Class Initialized
DEBUG - 2018-11-23 12:22:58 --> UTF-8 Support Enabled
INFO - 2018-11-23 12:22:58 --> Utf8 Class Initialized
INFO - 2018-11-23 12:22:58 --> URI Class Initialized
INFO - 2018-11-23 12:22:58 --> Router Class Initialized
INFO - 2018-11-23 12:22:58 --> Output Class Initialized
INFO - 2018-11-23 12:22:58 --> Security Class Initialized
DEBUG - 2018-11-23 12:22:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-23 12:22:58 --> Input Class Initialized
INFO - 2018-11-23 12:22:58 --> Language Class Initialized
INFO - 2018-11-23 12:22:58 --> Loader Class Initialized
INFO - 2018-11-23 12:22:58 --> Helper loaded: url_helper
INFO - 2018-11-23 12:22:58 --> Helper loaded: file_helper
INFO - 2018-11-23 12:22:58 --> Helper loaded: email_helper
INFO - 2018-11-23 12:22:58 --> Helper loaded: common_helper
INFO - 2018-11-23 12:22:58 --> Database Driver Class Initialized
DEBUG - 2018-11-23 12:22:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-23 12:22:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-23 12:22:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-23 12:22:58 --> Pagination Class Initialized
INFO - 2018-11-23 12:22:58 --> Helper loaded: form_helper
INFO - 2018-11-23 12:22:58 --> Form Validation Class Initialized
INFO - 2018-11-23 12:22:58 --> Model Class Initialized
INFO - 2018-11-23 12:22:58 --> Controller Class Initialized
INFO - 2018-11-23 12:22:58 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-23 12:22:58 --> Model Class Initialized
INFO - 2018-11-23 12:22:58 --> Model Class Initialized
INFO - 2018-11-23 12:22:58 --> Config Class Initialized
INFO - 2018-11-23 12:22:58 --> Hooks Class Initialized
DEBUG - 2018-11-23 12:22:58 --> UTF-8 Support Enabled
INFO - 2018-11-23 12:22:58 --> Utf8 Class Initialized
INFO - 2018-11-23 12:22:58 --> URI Class Initialized
INFO - 2018-11-23 12:22:58 --> Router Class Initialized
INFO - 2018-11-23 12:22:58 --> Output Class Initialized
INFO - 2018-11-23 12:22:58 --> Security Class Initialized
DEBUG - 2018-11-23 12:22:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-23 12:22:58 --> Input Class Initialized
INFO - 2018-11-23 12:22:58 --> Language Class Initialized
INFO - 2018-11-23 12:22:58 --> Loader Class Initialized
INFO - 2018-11-23 12:22:58 --> Helper loaded: url_helper
INFO - 2018-11-23 12:22:58 --> Helper loaded: file_helper
INFO - 2018-11-23 12:22:58 --> Helper loaded: email_helper
INFO - 2018-11-23 12:22:58 --> Helper loaded: common_helper
INFO - 2018-11-23 12:22:58 --> Database Driver Class Initialized
DEBUG - 2018-11-23 12:22:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-23 12:22:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-23 12:22:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-23 12:22:58 --> Pagination Class Initialized
INFO - 2018-11-23 12:22:58 --> Helper loaded: form_helper
INFO - 2018-11-23 12:22:58 --> Form Validation Class Initialized
INFO - 2018-11-23 12:22:58 --> Model Class Initialized
INFO - 2018-11-23 12:22:58 --> Controller Class Initialized
INFO - 2018-11-23 12:22:58 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-23 12:22:58 --> Model Class Initialized
INFO - 2018-11-23 12:22:58 --> Model Class Initialized
INFO - 2018-11-23 12:22:58 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-23 12:22:58 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/change-password.php
INFO - 2018-11-23 12:22:58 --> Final output sent to browser
DEBUG - 2018-11-23 12:22:58 --> Total execution time: 0.0600
INFO - 2018-11-23 12:24:51 --> Config Class Initialized
INFO - 2018-11-23 12:24:51 --> Hooks Class Initialized
DEBUG - 2018-11-23 12:24:51 --> UTF-8 Support Enabled
INFO - 2018-11-23 12:24:51 --> Utf8 Class Initialized
INFO - 2018-11-23 12:24:51 --> URI Class Initialized
INFO - 2018-11-23 12:24:51 --> Router Class Initialized
INFO - 2018-11-23 12:24:51 --> Output Class Initialized
INFO - 2018-11-23 12:24:51 --> Security Class Initialized
DEBUG - 2018-11-23 12:24:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-23 12:24:51 --> Input Class Initialized
INFO - 2018-11-23 12:24:51 --> Language Class Initialized
INFO - 2018-11-23 12:24:51 --> Loader Class Initialized
INFO - 2018-11-23 12:24:51 --> Helper loaded: url_helper
INFO - 2018-11-23 12:24:51 --> Helper loaded: file_helper
INFO - 2018-11-23 12:24:51 --> Helper loaded: email_helper
INFO - 2018-11-23 12:24:51 --> Helper loaded: common_helper
INFO - 2018-11-23 12:24:51 --> Database Driver Class Initialized
DEBUG - 2018-11-23 12:24:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-23 12:24:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-23 12:24:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-23 12:24:51 --> Pagination Class Initialized
INFO - 2018-11-23 12:24:51 --> Helper loaded: form_helper
INFO - 2018-11-23 12:24:51 --> Form Validation Class Initialized
INFO - 2018-11-23 12:24:51 --> Model Class Initialized
INFO - 2018-11-23 12:24:51 --> Controller Class Initialized
INFO - 2018-11-23 12:24:51 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-23 12:24:51 --> Model Class Initialized
INFO - 2018-11-23 12:24:51 --> Model Class Initialized
INFO - 2018-11-23 12:24:51 --> Config Class Initialized
INFO - 2018-11-23 12:24:51 --> Hooks Class Initialized
DEBUG - 2018-11-23 12:24:51 --> UTF-8 Support Enabled
INFO - 2018-11-23 12:24:51 --> Utf8 Class Initialized
INFO - 2018-11-23 12:24:51 --> URI Class Initialized
INFO - 2018-11-23 12:24:51 --> Router Class Initialized
INFO - 2018-11-23 12:24:51 --> Output Class Initialized
INFO - 2018-11-23 12:24:51 --> Security Class Initialized
DEBUG - 2018-11-23 12:24:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-23 12:24:51 --> Input Class Initialized
INFO - 2018-11-23 12:24:51 --> Language Class Initialized
INFO - 2018-11-23 12:24:51 --> Loader Class Initialized
INFO - 2018-11-23 12:24:51 --> Helper loaded: url_helper
INFO - 2018-11-23 12:24:51 --> Helper loaded: file_helper
INFO - 2018-11-23 12:24:51 --> Helper loaded: email_helper
INFO - 2018-11-23 12:24:51 --> Helper loaded: common_helper
INFO - 2018-11-23 12:24:51 --> Database Driver Class Initialized
DEBUG - 2018-11-23 12:24:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-23 12:24:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-23 12:24:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-23 12:24:51 --> Pagination Class Initialized
INFO - 2018-11-23 12:24:51 --> Helper loaded: form_helper
INFO - 2018-11-23 12:24:51 --> Form Validation Class Initialized
INFO - 2018-11-23 12:24:51 --> Model Class Initialized
INFO - 2018-11-23 12:24:51 --> Controller Class Initialized
INFO - 2018-11-23 12:24:51 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-23 12:24:51 --> Model Class Initialized
INFO - 2018-11-23 12:24:51 --> Model Class Initialized
INFO - 2018-11-23 12:24:51 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/index.php
INFO - 2018-11-23 12:24:51 --> Final output sent to browser
DEBUG - 2018-11-23 12:24:51 --> Total execution time: 0.0490
INFO - 2018-11-23 12:25:12 --> Config Class Initialized
INFO - 2018-11-23 12:25:12 --> Hooks Class Initialized
DEBUG - 2018-11-23 12:25:12 --> UTF-8 Support Enabled
INFO - 2018-11-23 12:25:12 --> Utf8 Class Initialized
INFO - 2018-11-23 12:25:12 --> URI Class Initialized
INFO - 2018-11-23 12:25:12 --> Router Class Initialized
INFO - 2018-11-23 12:25:12 --> Output Class Initialized
INFO - 2018-11-23 12:25:12 --> Security Class Initialized
DEBUG - 2018-11-23 12:25:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-23 12:25:12 --> Input Class Initialized
INFO - 2018-11-23 12:25:12 --> Language Class Initialized
INFO - 2018-11-23 12:25:12 --> Loader Class Initialized
INFO - 2018-11-23 12:25:12 --> Helper loaded: url_helper
INFO - 2018-11-23 12:25:12 --> Helper loaded: file_helper
INFO - 2018-11-23 12:25:12 --> Helper loaded: email_helper
INFO - 2018-11-23 12:25:12 --> Helper loaded: common_helper
INFO - 2018-11-23 12:25:12 --> Database Driver Class Initialized
DEBUG - 2018-11-23 12:25:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-23 12:25:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-23 12:25:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-23 12:25:12 --> Pagination Class Initialized
INFO - 2018-11-23 12:25:12 --> Helper loaded: form_helper
INFO - 2018-11-23 12:25:12 --> Form Validation Class Initialized
INFO - 2018-11-23 12:25:12 --> Model Class Initialized
INFO - 2018-11-23 12:25:12 --> Controller Class Initialized
INFO - 2018-11-23 12:25:12 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-23 12:25:12 --> Model Class Initialized
INFO - 2018-11-23 12:25:12 --> Model Class Initialized
ERROR - 2018-11-23 12:25:12 --> Severity: Notice --> Undefined index: remember_me C:\xampp\htdocs\wetinuneed\application\controllers\admin\Admin.php 77
INFO - 2018-11-23 12:25:12 --> Config Class Initialized
INFO - 2018-11-23 12:25:12 --> Hooks Class Initialized
DEBUG - 2018-11-23 12:25:12 --> UTF-8 Support Enabled
INFO - 2018-11-23 12:25:12 --> Utf8 Class Initialized
INFO - 2018-11-23 12:25:12 --> URI Class Initialized
INFO - 2018-11-23 12:25:12 --> Router Class Initialized
INFO - 2018-11-23 12:25:12 --> Output Class Initialized
INFO - 2018-11-23 12:25:12 --> Security Class Initialized
DEBUG - 2018-11-23 12:25:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-23 12:25:12 --> Input Class Initialized
INFO - 2018-11-23 12:25:12 --> Language Class Initialized
INFO - 2018-11-23 12:25:12 --> Loader Class Initialized
INFO - 2018-11-23 12:25:12 --> Helper loaded: url_helper
INFO - 2018-11-23 12:25:12 --> Helper loaded: file_helper
INFO - 2018-11-23 12:25:12 --> Helper loaded: email_helper
INFO - 2018-11-23 12:25:12 --> Helper loaded: common_helper
INFO - 2018-11-23 12:25:12 --> Database Driver Class Initialized
DEBUG - 2018-11-23 12:25:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-23 12:25:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-23 12:25:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-23 12:25:12 --> Pagination Class Initialized
INFO - 2018-11-23 12:25:12 --> Helper loaded: form_helper
INFO - 2018-11-23 12:25:12 --> Form Validation Class Initialized
INFO - 2018-11-23 12:25:12 --> Model Class Initialized
INFO - 2018-11-23 12:25:12 --> Controller Class Initialized
INFO - 2018-11-23 12:25:12 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-23 12:25:12 --> Model Class Initialized
INFO - 2018-11-23 12:25:12 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-23 12:25:12 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/sidebar.php
INFO - 2018-11-23 12:25:12 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/right-sidebar.php
INFO - 2018-11-23 12:25:12 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/footer.php
INFO - 2018-11-23 12:25:12 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/dashboard.php
INFO - 2018-11-23 12:25:12 --> Final output sent to browser
DEBUG - 2018-11-23 12:25:12 --> Total execution time: 0.0630
INFO - 2018-11-23 12:25:18 --> Config Class Initialized
INFO - 2018-11-23 12:25:18 --> Hooks Class Initialized
DEBUG - 2018-11-23 12:25:18 --> UTF-8 Support Enabled
INFO - 2018-11-23 12:25:18 --> Utf8 Class Initialized
INFO - 2018-11-23 12:25:18 --> URI Class Initialized
INFO - 2018-11-23 12:25:18 --> Router Class Initialized
INFO - 2018-11-23 12:25:18 --> Output Class Initialized
INFO - 2018-11-23 12:25:18 --> Security Class Initialized
DEBUG - 2018-11-23 12:25:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-23 12:25:18 --> Input Class Initialized
INFO - 2018-11-23 12:25:18 --> Language Class Initialized
INFO - 2018-11-23 12:25:18 --> Loader Class Initialized
INFO - 2018-11-23 12:25:18 --> Helper loaded: url_helper
INFO - 2018-11-23 12:25:18 --> Helper loaded: file_helper
INFO - 2018-11-23 12:25:18 --> Helper loaded: email_helper
INFO - 2018-11-23 12:25:18 --> Helper loaded: common_helper
INFO - 2018-11-23 12:25:18 --> Database Driver Class Initialized
DEBUG - 2018-11-23 12:25:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-23 12:25:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-23 12:25:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-23 12:25:18 --> Pagination Class Initialized
INFO - 2018-11-23 12:25:18 --> Helper loaded: form_helper
INFO - 2018-11-23 12:25:18 --> Form Validation Class Initialized
INFO - 2018-11-23 12:25:18 --> Model Class Initialized
INFO - 2018-11-23 12:25:18 --> Controller Class Initialized
INFO - 2018-11-23 12:25:18 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-23 12:25:18 --> Model Class Initialized
INFO - 2018-11-23 12:25:18 --> Model Class Initialized
INFO - 2018-11-23 12:25:18 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-23 12:25:18 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/change-password.php
INFO - 2018-11-23 12:25:18 --> Final output sent to browser
DEBUG - 2018-11-23 12:25:18 --> Total execution time: 0.0610
INFO - 2018-11-23 12:25:29 --> Config Class Initialized
INFO - 2018-11-23 12:25:29 --> Hooks Class Initialized
DEBUG - 2018-11-23 12:25:29 --> UTF-8 Support Enabled
INFO - 2018-11-23 12:25:29 --> Utf8 Class Initialized
INFO - 2018-11-23 12:25:29 --> URI Class Initialized
INFO - 2018-11-23 12:25:29 --> Router Class Initialized
INFO - 2018-11-23 12:25:29 --> Output Class Initialized
INFO - 2018-11-23 12:25:29 --> Security Class Initialized
DEBUG - 2018-11-23 12:25:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-23 12:25:29 --> Input Class Initialized
INFO - 2018-11-23 12:25:29 --> Language Class Initialized
INFO - 2018-11-23 12:25:29 --> Loader Class Initialized
INFO - 2018-11-23 12:25:29 --> Helper loaded: url_helper
INFO - 2018-11-23 12:25:29 --> Helper loaded: file_helper
INFO - 2018-11-23 12:25:29 --> Helper loaded: email_helper
INFO - 2018-11-23 12:25:29 --> Helper loaded: common_helper
INFO - 2018-11-23 12:25:29 --> Database Driver Class Initialized
DEBUG - 2018-11-23 12:25:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-23 12:25:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-23 12:25:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-23 12:25:29 --> Pagination Class Initialized
INFO - 2018-11-23 12:25:29 --> Helper loaded: form_helper
INFO - 2018-11-23 12:25:29 --> Form Validation Class Initialized
INFO - 2018-11-23 12:25:29 --> Model Class Initialized
INFO - 2018-11-23 12:25:29 --> Controller Class Initialized
INFO - 2018-11-23 12:25:29 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-23 12:25:29 --> Model Class Initialized
INFO - 2018-11-23 12:25:29 --> Model Class Initialized
INFO - 2018-11-23 12:25:29 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-23 12:25:29 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/change-password.php
INFO - 2018-11-23 12:25:29 --> Final output sent to browser
DEBUG - 2018-11-23 12:25:29 --> Total execution time: 0.0570
INFO - 2018-11-23 12:25:57 --> Config Class Initialized
INFO - 2018-11-23 12:25:57 --> Hooks Class Initialized
DEBUG - 2018-11-23 12:25:57 --> UTF-8 Support Enabled
INFO - 2018-11-23 12:25:57 --> Utf8 Class Initialized
INFO - 2018-11-23 12:25:57 --> URI Class Initialized
INFO - 2018-11-23 12:25:57 --> Router Class Initialized
INFO - 2018-11-23 12:25:57 --> Output Class Initialized
INFO - 2018-11-23 12:25:57 --> Security Class Initialized
DEBUG - 2018-11-23 12:25:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-23 12:25:57 --> Input Class Initialized
INFO - 2018-11-23 12:25:57 --> Language Class Initialized
INFO - 2018-11-23 12:25:57 --> Loader Class Initialized
INFO - 2018-11-23 12:25:57 --> Helper loaded: url_helper
INFO - 2018-11-23 12:25:57 --> Helper loaded: file_helper
INFO - 2018-11-23 12:25:57 --> Helper loaded: email_helper
INFO - 2018-11-23 12:25:57 --> Helper loaded: common_helper
INFO - 2018-11-23 12:25:57 --> Database Driver Class Initialized
DEBUG - 2018-11-23 12:25:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-23 12:25:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-23 12:25:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-23 12:25:57 --> Pagination Class Initialized
INFO - 2018-11-23 12:25:57 --> Helper loaded: form_helper
INFO - 2018-11-23 12:25:57 --> Form Validation Class Initialized
INFO - 2018-11-23 12:25:57 --> Model Class Initialized
INFO - 2018-11-23 12:25:57 --> Controller Class Initialized
INFO - 2018-11-23 12:25:57 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-23 12:25:57 --> Model Class Initialized
INFO - 2018-11-23 12:25:57 --> Model Class Initialized
ERROR - 2018-11-23 12:25:57 --> Severity: Warning --> Missing argument 3 for Adminmaster_model::updateData(), called in C:\xampp\htdocs\wetinuneed\application\controllers\admin\Admin.php on line 122 and defined C:\xampp\htdocs\wetinuneed\application\models\Adminmaster_model.php 63
ERROR - 2018-11-23 12:25:57 --> Severity: Notice --> Undefined variable: where C:\xampp\htdocs\wetinuneed\application\models\Adminmaster_model.php 65
ERROR - 2018-11-23 12:25:57 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\wetinuneed\system\database\DB_driver.php 1528
ERROR - 2018-11-23 12:25:57 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'IS NULL' at line 2 - Invalid query: UPDATE Array SET `admin_id` = '1'
WHERE  IS NULL
INFO - 2018-11-23 12:25:57 --> Language file loaded: language/english/db_lang.php
INFO - 2018-11-23 12:26:45 --> Config Class Initialized
INFO - 2018-11-23 12:26:45 --> Hooks Class Initialized
DEBUG - 2018-11-23 12:26:45 --> UTF-8 Support Enabled
INFO - 2018-11-23 12:26:45 --> Utf8 Class Initialized
INFO - 2018-11-23 12:26:45 --> URI Class Initialized
INFO - 2018-11-23 12:26:45 --> Router Class Initialized
INFO - 2018-11-23 12:26:45 --> Output Class Initialized
INFO - 2018-11-23 12:26:45 --> Security Class Initialized
DEBUG - 2018-11-23 12:26:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-23 12:26:45 --> Input Class Initialized
INFO - 2018-11-23 12:26:45 --> Language Class Initialized
INFO - 2018-11-23 12:26:45 --> Loader Class Initialized
INFO - 2018-11-23 12:26:45 --> Helper loaded: url_helper
INFO - 2018-11-23 12:26:45 --> Helper loaded: file_helper
INFO - 2018-11-23 12:26:45 --> Helper loaded: email_helper
INFO - 2018-11-23 12:26:45 --> Helper loaded: common_helper
INFO - 2018-11-23 12:26:45 --> Database Driver Class Initialized
DEBUG - 2018-11-23 12:26:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-23 12:26:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-23 12:26:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-23 12:26:45 --> Pagination Class Initialized
INFO - 2018-11-23 12:26:45 --> Helper loaded: form_helper
INFO - 2018-11-23 12:26:45 --> Form Validation Class Initialized
INFO - 2018-11-23 12:26:45 --> Model Class Initialized
INFO - 2018-11-23 12:26:45 --> Controller Class Initialized
INFO - 2018-11-23 12:26:45 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-23 12:26:45 --> Model Class Initialized
INFO - 2018-11-23 12:26:45 --> Model Class Initialized
ERROR - 2018-11-23 12:26:45 --> Severity: Warning --> Missing argument 3 for Adminmaster_model::updateData(), called in C:\xampp\htdocs\wetinuneed\application\controllers\admin\Admin.php on line 122 and defined C:\xampp\htdocs\wetinuneed\application\models\Adminmaster_model.php 63
ERROR - 2018-11-23 12:26:45 --> Severity: Notice --> Undefined variable: where C:\xampp\htdocs\wetinuneed\application\models\Adminmaster_model.php 65
ERROR - 2018-11-23 12:26:45 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\wetinuneed\system\database\DB_driver.php 1528
ERROR - 2018-11-23 12:26:45 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'IS NULL' at line 2 - Invalid query: UPDATE Array SET `admin_id` = '1'
WHERE  IS NULL
INFO - 2018-11-23 12:26:45 --> Language file loaded: language/english/db_lang.php
INFO - 2018-11-23 12:27:10 --> Config Class Initialized
INFO - 2018-11-23 12:27:10 --> Hooks Class Initialized
DEBUG - 2018-11-23 12:27:10 --> UTF-8 Support Enabled
INFO - 2018-11-23 12:27:10 --> Utf8 Class Initialized
INFO - 2018-11-23 12:27:10 --> URI Class Initialized
INFO - 2018-11-23 12:27:10 --> Router Class Initialized
INFO - 2018-11-23 12:27:10 --> Output Class Initialized
INFO - 2018-11-23 12:27:10 --> Security Class Initialized
DEBUG - 2018-11-23 12:27:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-23 12:27:10 --> Input Class Initialized
INFO - 2018-11-23 12:27:10 --> Language Class Initialized
INFO - 2018-11-23 12:27:10 --> Loader Class Initialized
INFO - 2018-11-23 12:27:10 --> Helper loaded: url_helper
INFO - 2018-11-23 12:27:10 --> Helper loaded: file_helper
INFO - 2018-11-23 12:27:10 --> Helper loaded: email_helper
INFO - 2018-11-23 12:27:10 --> Helper loaded: common_helper
INFO - 2018-11-23 12:27:10 --> Database Driver Class Initialized
DEBUG - 2018-11-23 12:27:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-23 12:27:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-23 12:27:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-23 12:27:10 --> Pagination Class Initialized
INFO - 2018-11-23 12:27:10 --> Helper loaded: form_helper
INFO - 2018-11-23 12:27:10 --> Form Validation Class Initialized
INFO - 2018-11-23 12:27:10 --> Model Class Initialized
INFO - 2018-11-23 12:27:10 --> Controller Class Initialized
INFO - 2018-11-23 12:27:10 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-23 12:27:10 --> Model Class Initialized
INFO - 2018-11-23 12:27:10 --> Model Class Initialized
INFO - 2018-11-23 12:27:10 --> Config Class Initialized
INFO - 2018-11-23 12:27:10 --> Hooks Class Initialized
DEBUG - 2018-11-23 12:27:10 --> UTF-8 Support Enabled
INFO - 2018-11-23 12:27:10 --> Utf8 Class Initialized
INFO - 2018-11-23 12:27:10 --> URI Class Initialized
INFO - 2018-11-23 12:27:10 --> Router Class Initialized
INFO - 2018-11-23 12:27:10 --> Output Class Initialized
INFO - 2018-11-23 12:27:10 --> Security Class Initialized
DEBUG - 2018-11-23 12:27:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-23 12:27:10 --> Input Class Initialized
INFO - 2018-11-23 12:27:10 --> Language Class Initialized
INFO - 2018-11-23 12:27:10 --> Loader Class Initialized
INFO - 2018-11-23 12:27:10 --> Helper loaded: url_helper
INFO - 2018-11-23 12:27:10 --> Helper loaded: file_helper
INFO - 2018-11-23 12:27:10 --> Helper loaded: email_helper
INFO - 2018-11-23 12:27:10 --> Helper loaded: common_helper
INFO - 2018-11-23 12:27:10 --> Database Driver Class Initialized
DEBUG - 2018-11-23 12:27:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-23 12:27:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-23 12:27:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-23 12:27:10 --> Pagination Class Initialized
INFO - 2018-11-23 12:27:10 --> Helper loaded: form_helper
INFO - 2018-11-23 12:27:10 --> Form Validation Class Initialized
INFO - 2018-11-23 12:27:10 --> Model Class Initialized
INFO - 2018-11-23 12:27:10 --> Controller Class Initialized
INFO - 2018-11-23 12:27:10 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-23 12:27:10 --> Model Class Initialized
INFO - 2018-11-23 12:27:10 --> Model Class Initialized
INFO - 2018-11-23 12:27:10 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-23 12:27:10 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/change-password.php
INFO - 2018-11-23 12:27:10 --> Final output sent to browser
DEBUG - 2018-11-23 12:27:10 --> Total execution time: 0.0560
INFO - 2018-11-23 12:27:27 --> Config Class Initialized
INFO - 2018-11-23 12:27:27 --> Hooks Class Initialized
DEBUG - 2018-11-23 12:27:27 --> UTF-8 Support Enabled
INFO - 2018-11-23 12:27:27 --> Utf8 Class Initialized
INFO - 2018-11-23 12:27:27 --> URI Class Initialized
INFO - 2018-11-23 12:27:27 --> Router Class Initialized
INFO - 2018-11-23 12:27:27 --> Output Class Initialized
INFO - 2018-11-23 12:27:27 --> Security Class Initialized
DEBUG - 2018-11-23 12:27:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-23 12:27:27 --> Input Class Initialized
INFO - 2018-11-23 12:27:27 --> Language Class Initialized
INFO - 2018-11-23 12:27:27 --> Loader Class Initialized
INFO - 2018-11-23 12:27:27 --> Helper loaded: url_helper
INFO - 2018-11-23 12:27:27 --> Helper loaded: file_helper
INFO - 2018-11-23 12:27:27 --> Helper loaded: email_helper
INFO - 2018-11-23 12:27:27 --> Helper loaded: common_helper
INFO - 2018-11-23 12:27:27 --> Database Driver Class Initialized
DEBUG - 2018-11-23 12:27:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-23 12:27:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-23 12:27:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-23 12:27:27 --> Pagination Class Initialized
INFO - 2018-11-23 12:27:27 --> Helper loaded: form_helper
INFO - 2018-11-23 12:27:27 --> Form Validation Class Initialized
INFO - 2018-11-23 12:27:27 --> Model Class Initialized
INFO - 2018-11-23 12:27:27 --> Controller Class Initialized
INFO - 2018-11-23 12:27:27 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-23 12:27:27 --> Model Class Initialized
INFO - 2018-11-23 12:27:27 --> Model Class Initialized
INFO - 2018-11-23 12:27:27 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-23 12:27:27 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/change-password.php
INFO - 2018-11-23 12:27:27 --> Final output sent to browser
DEBUG - 2018-11-23 12:27:27 --> Total execution time: 0.0676
INFO - 2018-11-23 12:27:32 --> Config Class Initialized
INFO - 2018-11-23 12:27:32 --> Hooks Class Initialized
DEBUG - 2018-11-23 12:27:32 --> UTF-8 Support Enabled
INFO - 2018-11-23 12:27:32 --> Utf8 Class Initialized
INFO - 2018-11-23 12:27:32 --> URI Class Initialized
INFO - 2018-11-23 12:27:32 --> Router Class Initialized
INFO - 2018-11-23 12:27:32 --> Output Class Initialized
INFO - 2018-11-23 12:27:32 --> Security Class Initialized
DEBUG - 2018-11-23 12:27:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-23 12:27:32 --> Input Class Initialized
INFO - 2018-11-23 12:27:32 --> Language Class Initialized
INFO - 2018-11-23 12:27:32 --> Loader Class Initialized
INFO - 2018-11-23 12:27:32 --> Helper loaded: url_helper
INFO - 2018-11-23 12:27:32 --> Helper loaded: file_helper
INFO - 2018-11-23 12:27:32 --> Helper loaded: email_helper
INFO - 2018-11-23 12:27:32 --> Helper loaded: common_helper
INFO - 2018-11-23 12:27:32 --> Database Driver Class Initialized
DEBUG - 2018-11-23 12:27:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-23 12:27:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-23 12:27:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-23 12:27:32 --> Pagination Class Initialized
INFO - 2018-11-23 12:27:32 --> Helper loaded: form_helper
INFO - 2018-11-23 12:27:32 --> Form Validation Class Initialized
INFO - 2018-11-23 12:27:32 --> Model Class Initialized
INFO - 2018-11-23 12:27:32 --> Controller Class Initialized
INFO - 2018-11-23 12:27:32 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-23 12:27:32 --> Model Class Initialized
INFO - 2018-11-23 12:27:32 --> Model Class Initialized
INFO - 2018-11-23 12:27:32 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-23 12:27:32 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/change-password.php
INFO - 2018-11-23 12:27:32 --> Final output sent to browser
DEBUG - 2018-11-23 12:27:32 --> Total execution time: 0.0640
INFO - 2018-11-23 12:27:36 --> Config Class Initialized
INFO - 2018-11-23 12:27:36 --> Hooks Class Initialized
DEBUG - 2018-11-23 12:27:36 --> UTF-8 Support Enabled
INFO - 2018-11-23 12:27:36 --> Utf8 Class Initialized
INFO - 2018-11-23 12:27:36 --> URI Class Initialized
INFO - 2018-11-23 12:27:36 --> Router Class Initialized
INFO - 2018-11-23 12:27:36 --> Output Class Initialized
INFO - 2018-11-23 12:27:36 --> Security Class Initialized
DEBUG - 2018-11-23 12:27:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-23 12:27:36 --> Input Class Initialized
INFO - 2018-11-23 12:27:36 --> Language Class Initialized
INFO - 2018-11-23 12:27:36 --> Loader Class Initialized
INFO - 2018-11-23 12:27:36 --> Helper loaded: url_helper
INFO - 2018-11-23 12:27:36 --> Helper loaded: file_helper
INFO - 2018-11-23 12:27:36 --> Helper loaded: email_helper
INFO - 2018-11-23 12:27:36 --> Helper loaded: common_helper
INFO - 2018-11-23 12:27:36 --> Database Driver Class Initialized
DEBUG - 2018-11-23 12:27:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-23 12:27:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-23 12:27:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-23 12:27:36 --> Pagination Class Initialized
INFO - 2018-11-23 12:27:36 --> Helper loaded: form_helper
INFO - 2018-11-23 12:27:36 --> Form Validation Class Initialized
INFO - 2018-11-23 12:27:36 --> Model Class Initialized
INFO - 2018-11-23 12:27:36 --> Controller Class Initialized
INFO - 2018-11-23 12:27:36 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-23 12:27:36 --> Model Class Initialized
INFO - 2018-11-23 12:27:36 --> Model Class Initialized
INFO - 2018-11-23 12:27:36 --> Config Class Initialized
INFO - 2018-11-23 12:27:36 --> Hooks Class Initialized
DEBUG - 2018-11-23 12:27:36 --> UTF-8 Support Enabled
INFO - 2018-11-23 12:27:36 --> Utf8 Class Initialized
INFO - 2018-11-23 12:27:36 --> URI Class Initialized
INFO - 2018-11-23 12:27:36 --> Router Class Initialized
INFO - 2018-11-23 12:27:36 --> Output Class Initialized
INFO - 2018-11-23 12:27:36 --> Security Class Initialized
DEBUG - 2018-11-23 12:27:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-23 12:27:36 --> Input Class Initialized
INFO - 2018-11-23 12:27:36 --> Language Class Initialized
INFO - 2018-11-23 12:27:36 --> Loader Class Initialized
INFO - 2018-11-23 12:27:36 --> Helper loaded: url_helper
INFO - 2018-11-23 12:27:36 --> Helper loaded: file_helper
INFO - 2018-11-23 12:27:36 --> Helper loaded: email_helper
INFO - 2018-11-23 12:27:36 --> Helper loaded: common_helper
INFO - 2018-11-23 12:27:36 --> Database Driver Class Initialized
DEBUG - 2018-11-23 12:27:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-23 12:27:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-23 12:27:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-23 12:27:36 --> Pagination Class Initialized
INFO - 2018-11-23 12:27:36 --> Helper loaded: form_helper
INFO - 2018-11-23 12:27:36 --> Form Validation Class Initialized
INFO - 2018-11-23 12:27:36 --> Model Class Initialized
INFO - 2018-11-23 12:27:36 --> Controller Class Initialized
INFO - 2018-11-23 12:27:36 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-23 12:27:36 --> Model Class Initialized
INFO - 2018-11-23 12:27:36 --> Model Class Initialized
INFO - 2018-11-23 12:27:36 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/index.php
INFO - 2018-11-23 12:27:36 --> Final output sent to browser
DEBUG - 2018-11-23 12:27:36 --> Total execution time: 0.0510
INFO - 2018-11-23 12:27:38 --> Config Class Initialized
INFO - 2018-11-23 12:27:38 --> Hooks Class Initialized
DEBUG - 2018-11-23 12:27:38 --> UTF-8 Support Enabled
INFO - 2018-11-23 12:27:38 --> Utf8 Class Initialized
INFO - 2018-11-23 12:27:38 --> URI Class Initialized
INFO - 2018-11-23 12:27:38 --> Router Class Initialized
INFO - 2018-11-23 12:27:38 --> Output Class Initialized
INFO - 2018-11-23 12:27:38 --> Security Class Initialized
DEBUG - 2018-11-23 12:27:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-23 12:27:38 --> Input Class Initialized
INFO - 2018-11-23 12:27:38 --> Language Class Initialized
INFO - 2018-11-23 12:27:38 --> Loader Class Initialized
INFO - 2018-11-23 12:27:38 --> Helper loaded: url_helper
INFO - 2018-11-23 12:27:38 --> Helper loaded: file_helper
INFO - 2018-11-23 12:27:38 --> Helper loaded: email_helper
INFO - 2018-11-23 12:27:38 --> Helper loaded: common_helper
INFO - 2018-11-23 12:27:38 --> Database Driver Class Initialized
DEBUG - 2018-11-23 12:27:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-23 12:27:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-23 12:27:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-23 12:27:38 --> Pagination Class Initialized
INFO - 2018-11-23 12:27:38 --> Helper loaded: form_helper
INFO - 2018-11-23 12:27:38 --> Form Validation Class Initialized
INFO - 2018-11-23 12:27:38 --> Model Class Initialized
INFO - 2018-11-23 12:27:38 --> Controller Class Initialized
INFO - 2018-11-23 12:27:38 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-23 12:27:38 --> Model Class Initialized
INFO - 2018-11-23 12:27:38 --> Model Class Initialized
INFO - 2018-11-23 12:27:38 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/index.php
INFO - 2018-11-23 12:27:38 --> Final output sent to browser
DEBUG - 2018-11-23 12:27:38 --> Total execution time: 0.0630
INFO - 2018-11-23 12:27:49 --> Config Class Initialized
INFO - 2018-11-23 12:27:49 --> Hooks Class Initialized
DEBUG - 2018-11-23 12:27:49 --> UTF-8 Support Enabled
INFO - 2018-11-23 12:27:49 --> Utf8 Class Initialized
INFO - 2018-11-23 12:27:49 --> URI Class Initialized
INFO - 2018-11-23 12:27:49 --> Router Class Initialized
INFO - 2018-11-23 12:27:49 --> Output Class Initialized
INFO - 2018-11-23 12:27:49 --> Security Class Initialized
DEBUG - 2018-11-23 12:27:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-23 12:27:49 --> Input Class Initialized
INFO - 2018-11-23 12:27:49 --> Language Class Initialized
INFO - 2018-11-23 12:27:49 --> Loader Class Initialized
INFO - 2018-11-23 12:27:49 --> Helper loaded: url_helper
INFO - 2018-11-23 12:27:49 --> Helper loaded: file_helper
INFO - 2018-11-23 12:27:49 --> Helper loaded: email_helper
INFO - 2018-11-23 12:27:49 --> Helper loaded: common_helper
INFO - 2018-11-23 12:27:49 --> Database Driver Class Initialized
DEBUG - 2018-11-23 12:27:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-23 12:27:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-23 12:27:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-23 12:27:49 --> Pagination Class Initialized
INFO - 2018-11-23 12:27:49 --> Helper loaded: form_helper
INFO - 2018-11-23 12:27:49 --> Form Validation Class Initialized
INFO - 2018-11-23 12:27:49 --> Model Class Initialized
INFO - 2018-11-23 12:27:49 --> Controller Class Initialized
INFO - 2018-11-23 12:27:49 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-23 12:27:49 --> Model Class Initialized
INFO - 2018-11-23 12:27:49 --> Model Class Initialized
INFO - 2018-11-23 12:27:49 --> Config Class Initialized
INFO - 2018-11-23 12:27:49 --> Hooks Class Initialized
DEBUG - 2018-11-23 12:27:49 --> UTF-8 Support Enabled
INFO - 2018-11-23 12:27:49 --> Utf8 Class Initialized
INFO - 2018-11-23 12:27:49 --> URI Class Initialized
INFO - 2018-11-23 12:27:49 --> Router Class Initialized
INFO - 2018-11-23 12:27:49 --> Output Class Initialized
INFO - 2018-11-23 12:27:49 --> Security Class Initialized
DEBUG - 2018-11-23 12:27:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-23 12:27:49 --> Input Class Initialized
INFO - 2018-11-23 12:27:49 --> Language Class Initialized
INFO - 2018-11-23 12:27:49 --> Loader Class Initialized
INFO - 2018-11-23 12:27:49 --> Helper loaded: url_helper
INFO - 2018-11-23 12:27:49 --> Helper loaded: file_helper
INFO - 2018-11-23 12:27:49 --> Helper loaded: email_helper
INFO - 2018-11-23 12:27:49 --> Helper loaded: common_helper
INFO - 2018-11-23 12:27:49 --> Database Driver Class Initialized
DEBUG - 2018-11-23 12:27:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-23 12:27:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-23 12:27:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-23 12:27:49 --> Pagination Class Initialized
INFO - 2018-11-23 12:27:49 --> Helper loaded: form_helper
INFO - 2018-11-23 12:27:49 --> Form Validation Class Initialized
INFO - 2018-11-23 12:27:49 --> Model Class Initialized
INFO - 2018-11-23 12:27:49 --> Controller Class Initialized
INFO - 2018-11-23 12:27:49 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-23 12:27:49 --> Model Class Initialized
INFO - 2018-11-23 12:27:49 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-23 12:27:49 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/sidebar.php
INFO - 2018-11-23 12:27:49 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/right-sidebar.php
INFO - 2018-11-23 12:27:49 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/footer.php
INFO - 2018-11-23 12:27:49 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/dashboard.php
INFO - 2018-11-23 12:27:49 --> Final output sent to browser
DEBUG - 2018-11-23 12:27:49 --> Total execution time: 0.0560
INFO - 2018-11-23 12:27:54 --> Config Class Initialized
INFO - 2018-11-23 12:27:54 --> Hooks Class Initialized
DEBUG - 2018-11-23 12:27:54 --> UTF-8 Support Enabled
INFO - 2018-11-23 12:27:54 --> Utf8 Class Initialized
INFO - 2018-11-23 12:27:54 --> URI Class Initialized
INFO - 2018-11-23 12:27:54 --> Router Class Initialized
INFO - 2018-11-23 12:27:54 --> Output Class Initialized
INFO - 2018-11-23 12:27:54 --> Security Class Initialized
DEBUG - 2018-11-23 12:27:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-23 12:27:54 --> Input Class Initialized
INFO - 2018-11-23 12:27:54 --> Language Class Initialized
INFO - 2018-11-23 12:27:54 --> Loader Class Initialized
INFO - 2018-11-23 12:27:54 --> Helper loaded: url_helper
INFO - 2018-11-23 12:27:54 --> Helper loaded: file_helper
INFO - 2018-11-23 12:27:54 --> Helper loaded: email_helper
INFO - 2018-11-23 12:27:54 --> Helper loaded: common_helper
INFO - 2018-11-23 12:27:54 --> Database Driver Class Initialized
DEBUG - 2018-11-23 12:27:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-23 12:27:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-23 12:27:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-23 12:27:54 --> Pagination Class Initialized
INFO - 2018-11-23 12:27:54 --> Helper loaded: form_helper
INFO - 2018-11-23 12:27:54 --> Form Validation Class Initialized
INFO - 2018-11-23 12:27:54 --> Model Class Initialized
INFO - 2018-11-23 12:27:54 --> Controller Class Initialized
INFO - 2018-11-23 12:27:54 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-23 12:27:54 --> Model Class Initialized
INFO - 2018-11-23 12:27:54 --> Model Class Initialized
INFO - 2018-11-23 12:27:54 --> Config Class Initialized
INFO - 2018-11-23 12:27:54 --> Hooks Class Initialized
DEBUG - 2018-11-23 12:27:54 --> UTF-8 Support Enabled
INFO - 2018-11-23 12:27:54 --> Utf8 Class Initialized
INFO - 2018-11-23 12:27:54 --> URI Class Initialized
INFO - 2018-11-23 12:27:54 --> Router Class Initialized
INFO - 2018-11-23 12:27:54 --> Output Class Initialized
INFO - 2018-11-23 12:27:54 --> Security Class Initialized
DEBUG - 2018-11-23 12:27:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-23 12:27:54 --> Input Class Initialized
INFO - 2018-11-23 12:27:54 --> Language Class Initialized
INFO - 2018-11-23 12:27:54 --> Loader Class Initialized
INFO - 2018-11-23 12:27:54 --> Helper loaded: url_helper
INFO - 2018-11-23 12:27:54 --> Helper loaded: file_helper
INFO - 2018-11-23 12:27:54 --> Helper loaded: email_helper
INFO - 2018-11-23 12:27:54 --> Helper loaded: common_helper
INFO - 2018-11-23 12:27:54 --> Database Driver Class Initialized
DEBUG - 2018-11-23 12:27:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-23 12:27:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-23 12:27:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-23 12:27:54 --> Pagination Class Initialized
INFO - 2018-11-23 12:27:54 --> Helper loaded: form_helper
INFO - 2018-11-23 12:27:54 --> Form Validation Class Initialized
INFO - 2018-11-23 12:27:54 --> Model Class Initialized
INFO - 2018-11-23 12:27:54 --> Controller Class Initialized
INFO - 2018-11-23 12:27:54 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-23 12:27:54 --> Model Class Initialized
INFO - 2018-11-23 12:27:54 --> Model Class Initialized
INFO - 2018-11-23 12:27:54 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/index.php
INFO - 2018-11-23 12:27:54 --> Final output sent to browser
DEBUG - 2018-11-23 12:27:54 --> Total execution time: 0.0520
INFO - 2018-11-23 12:27:59 --> Config Class Initialized
INFO - 2018-11-23 12:27:59 --> Hooks Class Initialized
DEBUG - 2018-11-23 12:27:59 --> UTF-8 Support Enabled
INFO - 2018-11-23 12:27:59 --> Utf8 Class Initialized
INFO - 2018-11-23 12:27:59 --> URI Class Initialized
INFO - 2018-11-23 12:27:59 --> Router Class Initialized
INFO - 2018-11-23 12:27:59 --> Output Class Initialized
INFO - 2018-11-23 12:27:59 --> Security Class Initialized
DEBUG - 2018-11-23 12:27:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-23 12:27:59 --> Input Class Initialized
INFO - 2018-11-23 12:27:59 --> Language Class Initialized
INFO - 2018-11-23 12:27:59 --> Loader Class Initialized
INFO - 2018-11-23 12:27:59 --> Helper loaded: url_helper
INFO - 2018-11-23 12:27:59 --> Helper loaded: file_helper
INFO - 2018-11-23 12:27:59 --> Helper loaded: email_helper
INFO - 2018-11-23 12:27:59 --> Helper loaded: common_helper
INFO - 2018-11-23 12:27:59 --> Database Driver Class Initialized
DEBUG - 2018-11-23 12:27:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-23 12:27:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-23 12:27:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-23 12:27:59 --> Pagination Class Initialized
INFO - 2018-11-23 12:27:59 --> Helper loaded: form_helper
INFO - 2018-11-23 12:27:59 --> Form Validation Class Initialized
INFO - 2018-11-23 12:27:59 --> Model Class Initialized
INFO - 2018-11-23 12:27:59 --> Controller Class Initialized
INFO - 2018-11-23 12:27:59 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-23 12:27:59 --> Model Class Initialized
INFO - 2018-11-23 12:27:59 --> Model Class Initialized
ERROR - 2018-11-23 12:27:59 --> Severity: Notice --> Undefined index: remember_me C:\xampp\htdocs\wetinuneed\application\controllers\admin\Admin.php 77
INFO - 2018-11-23 12:27:59 --> Config Class Initialized
INFO - 2018-11-23 12:27:59 --> Hooks Class Initialized
DEBUG - 2018-11-23 12:27:59 --> UTF-8 Support Enabled
INFO - 2018-11-23 12:27:59 --> Utf8 Class Initialized
INFO - 2018-11-23 12:27:59 --> URI Class Initialized
INFO - 2018-11-23 12:27:59 --> Router Class Initialized
INFO - 2018-11-23 12:27:59 --> Output Class Initialized
INFO - 2018-11-23 12:27:59 --> Security Class Initialized
DEBUG - 2018-11-23 12:27:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-23 12:27:59 --> Input Class Initialized
INFO - 2018-11-23 12:27:59 --> Language Class Initialized
INFO - 2018-11-23 12:27:59 --> Loader Class Initialized
INFO - 2018-11-23 12:27:59 --> Helper loaded: url_helper
INFO - 2018-11-23 12:27:59 --> Helper loaded: file_helper
INFO - 2018-11-23 12:27:59 --> Helper loaded: email_helper
INFO - 2018-11-23 12:27:59 --> Helper loaded: common_helper
INFO - 2018-11-23 12:27:59 --> Database Driver Class Initialized
DEBUG - 2018-11-23 12:27:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-23 12:27:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-23 12:27:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-23 12:27:59 --> Pagination Class Initialized
INFO - 2018-11-23 12:27:59 --> Helper loaded: form_helper
INFO - 2018-11-23 12:27:59 --> Form Validation Class Initialized
INFO - 2018-11-23 12:27:59 --> Model Class Initialized
INFO - 2018-11-23 12:27:59 --> Controller Class Initialized
INFO - 2018-11-23 12:27:59 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-23 12:27:59 --> Model Class Initialized
INFO - 2018-11-23 12:27:59 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-23 12:27:59 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/sidebar.php
INFO - 2018-11-23 12:27:59 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/right-sidebar.php
INFO - 2018-11-23 12:27:59 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/footer.php
INFO - 2018-11-23 12:27:59 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/dashboard.php
INFO - 2018-11-23 12:27:59 --> Final output sent to browser
DEBUG - 2018-11-23 12:27:59 --> Total execution time: 0.0520
INFO - 2018-11-23 12:28:05 --> Config Class Initialized
INFO - 2018-11-23 12:28:05 --> Hooks Class Initialized
DEBUG - 2018-11-23 12:28:05 --> UTF-8 Support Enabled
INFO - 2018-11-23 12:28:05 --> Utf8 Class Initialized
INFO - 2018-11-23 12:28:05 --> URI Class Initialized
INFO - 2018-11-23 12:28:05 --> Router Class Initialized
INFO - 2018-11-23 12:28:05 --> Output Class Initialized
INFO - 2018-11-23 12:28:05 --> Security Class Initialized
DEBUG - 2018-11-23 12:28:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-23 12:28:05 --> Input Class Initialized
INFO - 2018-11-23 12:28:05 --> Language Class Initialized
INFO - 2018-11-23 12:28:05 --> Loader Class Initialized
INFO - 2018-11-23 12:28:05 --> Helper loaded: url_helper
INFO - 2018-11-23 12:28:05 --> Helper loaded: file_helper
INFO - 2018-11-23 12:28:05 --> Helper loaded: email_helper
INFO - 2018-11-23 12:28:05 --> Helper loaded: common_helper
INFO - 2018-11-23 12:28:05 --> Database Driver Class Initialized
DEBUG - 2018-11-23 12:28:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-23 12:28:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-23 12:28:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-23 12:28:05 --> Pagination Class Initialized
INFO - 2018-11-23 12:28:05 --> Helper loaded: form_helper
INFO - 2018-11-23 12:28:05 --> Form Validation Class Initialized
INFO - 2018-11-23 12:28:05 --> Model Class Initialized
INFO - 2018-11-23 12:28:05 --> Controller Class Initialized
INFO - 2018-11-23 12:28:05 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-23 12:28:05 --> Model Class Initialized
INFO - 2018-11-23 12:28:05 --> Model Class Initialized
INFO - 2018-11-23 12:28:05 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-23 12:28:05 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/change-password.php
INFO - 2018-11-23 12:28:05 --> Final output sent to browser
DEBUG - 2018-11-23 12:28:05 --> Total execution time: 0.0590
INFO - 2018-11-23 12:28:52 --> Config Class Initialized
INFO - 2018-11-23 12:28:52 --> Hooks Class Initialized
DEBUG - 2018-11-23 12:28:52 --> UTF-8 Support Enabled
INFO - 2018-11-23 12:28:52 --> Utf8 Class Initialized
INFO - 2018-11-23 12:28:52 --> URI Class Initialized
INFO - 2018-11-23 12:28:52 --> Router Class Initialized
INFO - 2018-11-23 12:28:52 --> Output Class Initialized
INFO - 2018-11-23 12:28:52 --> Security Class Initialized
DEBUG - 2018-11-23 12:28:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-23 12:28:52 --> Input Class Initialized
INFO - 2018-11-23 12:28:52 --> Language Class Initialized
INFO - 2018-11-23 12:28:52 --> Loader Class Initialized
INFO - 2018-11-23 12:28:52 --> Helper loaded: url_helper
INFO - 2018-11-23 12:28:52 --> Helper loaded: file_helper
INFO - 2018-11-23 12:28:52 --> Helper loaded: email_helper
INFO - 2018-11-23 12:28:52 --> Helper loaded: common_helper
INFO - 2018-11-23 12:28:52 --> Database Driver Class Initialized
DEBUG - 2018-11-23 12:28:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-23 12:28:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-23 12:28:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-23 12:28:52 --> Pagination Class Initialized
INFO - 2018-11-23 12:28:52 --> Helper loaded: form_helper
INFO - 2018-11-23 12:28:52 --> Form Validation Class Initialized
INFO - 2018-11-23 12:28:52 --> Model Class Initialized
INFO - 2018-11-23 12:28:52 --> Controller Class Initialized
INFO - 2018-11-23 12:28:52 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-23 12:28:52 --> Model Class Initialized
INFO - 2018-11-23 12:28:52 --> Model Class Initialized
INFO - 2018-11-23 12:28:52 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-23 12:28:52 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/change-password.php
INFO - 2018-11-23 12:28:52 --> Final output sent to browser
DEBUG - 2018-11-23 12:28:52 --> Total execution time: 0.0570
INFO - 2018-11-23 12:30:13 --> Config Class Initialized
INFO - 2018-11-23 12:30:13 --> Hooks Class Initialized
DEBUG - 2018-11-23 12:30:13 --> UTF-8 Support Enabled
INFO - 2018-11-23 12:30:13 --> Utf8 Class Initialized
INFO - 2018-11-23 12:30:13 --> URI Class Initialized
INFO - 2018-11-23 12:30:13 --> Router Class Initialized
INFO - 2018-11-23 12:30:13 --> Output Class Initialized
INFO - 2018-11-23 12:30:13 --> Security Class Initialized
DEBUG - 2018-11-23 12:30:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-23 12:30:13 --> Input Class Initialized
INFO - 2018-11-23 12:30:13 --> Language Class Initialized
INFO - 2018-11-23 12:30:13 --> Loader Class Initialized
INFO - 2018-11-23 12:30:13 --> Helper loaded: url_helper
INFO - 2018-11-23 12:30:13 --> Helper loaded: file_helper
INFO - 2018-11-23 12:30:13 --> Helper loaded: email_helper
INFO - 2018-11-23 12:30:13 --> Helper loaded: common_helper
INFO - 2018-11-23 12:30:13 --> Database Driver Class Initialized
DEBUG - 2018-11-23 12:30:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-23 12:30:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-23 12:30:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-23 12:30:13 --> Pagination Class Initialized
INFO - 2018-11-23 12:30:13 --> Helper loaded: form_helper
INFO - 2018-11-23 12:30:13 --> Form Validation Class Initialized
INFO - 2018-11-23 12:30:13 --> Model Class Initialized
INFO - 2018-11-23 12:30:13 --> Controller Class Initialized
INFO - 2018-11-23 12:30:13 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-23 12:30:13 --> Model Class Initialized
INFO - 2018-11-23 12:30:13 --> Model Class Initialized
INFO - 2018-11-23 12:30:13 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-23 12:30:13 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/change-password.php
INFO - 2018-11-23 12:30:13 --> Final output sent to browser
DEBUG - 2018-11-23 12:30:13 --> Total execution time: 0.0626
INFO - 2018-11-23 12:30:55 --> Config Class Initialized
INFO - 2018-11-23 12:30:55 --> Hooks Class Initialized
DEBUG - 2018-11-23 12:30:55 --> UTF-8 Support Enabled
INFO - 2018-11-23 12:30:55 --> Utf8 Class Initialized
INFO - 2018-11-23 12:30:55 --> URI Class Initialized
INFO - 2018-11-23 12:30:55 --> Router Class Initialized
INFO - 2018-11-23 12:30:55 --> Output Class Initialized
INFO - 2018-11-23 12:30:55 --> Security Class Initialized
DEBUG - 2018-11-23 12:30:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-23 12:30:55 --> Input Class Initialized
INFO - 2018-11-23 12:30:55 --> Language Class Initialized
INFO - 2018-11-23 12:30:55 --> Loader Class Initialized
INFO - 2018-11-23 12:30:55 --> Helper loaded: url_helper
INFO - 2018-11-23 12:30:55 --> Helper loaded: file_helper
INFO - 2018-11-23 12:30:55 --> Helper loaded: email_helper
INFO - 2018-11-23 12:30:55 --> Helper loaded: common_helper
INFO - 2018-11-23 12:30:55 --> Database Driver Class Initialized
DEBUG - 2018-11-23 12:30:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-23 12:30:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-23 12:30:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-23 12:30:55 --> Pagination Class Initialized
INFO - 2018-11-23 12:30:55 --> Helper loaded: form_helper
INFO - 2018-11-23 12:30:55 --> Form Validation Class Initialized
INFO - 2018-11-23 12:30:55 --> Model Class Initialized
INFO - 2018-11-23 12:30:55 --> Controller Class Initialized
INFO - 2018-11-23 12:30:55 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-23 12:30:55 --> Model Class Initialized
INFO - 2018-11-23 12:30:55 --> Model Class Initialized
INFO - 2018-11-23 12:30:55 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-23 12:30:55 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/change-password.php
INFO - 2018-11-23 12:30:55 --> Final output sent to browser
DEBUG - 2018-11-23 12:30:55 --> Total execution time: 0.0510
INFO - 2018-11-23 12:31:37 --> Config Class Initialized
INFO - 2018-11-23 12:31:37 --> Hooks Class Initialized
DEBUG - 2018-11-23 12:31:37 --> UTF-8 Support Enabled
INFO - 2018-11-23 12:31:37 --> Utf8 Class Initialized
INFO - 2018-11-23 12:31:37 --> URI Class Initialized
INFO - 2018-11-23 12:31:37 --> Router Class Initialized
INFO - 2018-11-23 12:31:37 --> Output Class Initialized
INFO - 2018-11-23 12:31:37 --> Security Class Initialized
DEBUG - 2018-11-23 12:31:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-23 12:31:37 --> Input Class Initialized
INFO - 2018-11-23 12:31:37 --> Language Class Initialized
INFO - 2018-11-23 12:31:37 --> Loader Class Initialized
INFO - 2018-11-23 12:31:37 --> Helper loaded: url_helper
INFO - 2018-11-23 12:31:37 --> Helper loaded: file_helper
INFO - 2018-11-23 12:31:37 --> Helper loaded: email_helper
INFO - 2018-11-23 12:31:37 --> Helper loaded: common_helper
INFO - 2018-11-23 12:31:37 --> Database Driver Class Initialized
DEBUG - 2018-11-23 12:31:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-23 12:31:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-23 12:31:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-23 12:31:37 --> Pagination Class Initialized
INFO - 2018-11-23 12:31:37 --> Helper loaded: form_helper
INFO - 2018-11-23 12:31:37 --> Form Validation Class Initialized
INFO - 2018-11-23 12:31:37 --> Model Class Initialized
INFO - 2018-11-23 12:31:37 --> Controller Class Initialized
INFO - 2018-11-23 12:31:37 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-23 12:31:37 --> Model Class Initialized
INFO - 2018-11-23 12:31:37 --> Model Class Initialized
INFO - 2018-11-23 12:31:37 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-23 12:31:37 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/change-password.php
INFO - 2018-11-23 12:31:37 --> Final output sent to browser
DEBUG - 2018-11-23 12:31:37 --> Total execution time: 0.0580
INFO - 2018-11-23 12:34:23 --> Config Class Initialized
INFO - 2018-11-23 12:34:23 --> Hooks Class Initialized
DEBUG - 2018-11-23 12:34:23 --> UTF-8 Support Enabled
INFO - 2018-11-23 12:34:23 --> Utf8 Class Initialized
INFO - 2018-11-23 12:34:23 --> URI Class Initialized
INFO - 2018-11-23 12:34:23 --> Router Class Initialized
INFO - 2018-11-23 12:34:23 --> Output Class Initialized
INFO - 2018-11-23 12:34:23 --> Security Class Initialized
DEBUG - 2018-11-23 12:34:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-23 12:34:23 --> Input Class Initialized
INFO - 2018-11-23 12:34:23 --> Language Class Initialized
INFO - 2018-11-23 12:34:23 --> Loader Class Initialized
INFO - 2018-11-23 12:34:23 --> Helper loaded: url_helper
INFO - 2018-11-23 12:34:23 --> Helper loaded: file_helper
INFO - 2018-11-23 12:34:23 --> Helper loaded: email_helper
INFO - 2018-11-23 12:34:23 --> Helper loaded: common_helper
INFO - 2018-11-23 12:34:23 --> Database Driver Class Initialized
DEBUG - 2018-11-23 12:34:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-23 12:34:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-23 12:34:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-23 12:34:23 --> Pagination Class Initialized
INFO - 2018-11-23 12:34:23 --> Helper loaded: form_helper
INFO - 2018-11-23 12:34:23 --> Form Validation Class Initialized
INFO - 2018-11-23 12:34:23 --> Model Class Initialized
INFO - 2018-11-23 12:34:23 --> Controller Class Initialized
INFO - 2018-11-23 12:34:23 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-23 12:34:23 --> Model Class Initialized
INFO - 2018-11-23 12:34:23 --> Model Class Initialized
INFO - 2018-11-23 12:34:23 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-23 12:34:23 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/change-password.php
INFO - 2018-11-23 12:34:23 --> Final output sent to browser
DEBUG - 2018-11-23 12:34:23 --> Total execution time: 0.0550
INFO - 2018-11-23 12:35:26 --> Config Class Initialized
INFO - 2018-11-23 12:35:26 --> Hooks Class Initialized
DEBUG - 2018-11-23 12:35:26 --> UTF-8 Support Enabled
INFO - 2018-11-23 12:35:26 --> Utf8 Class Initialized
INFO - 2018-11-23 12:35:26 --> URI Class Initialized
INFO - 2018-11-23 12:35:26 --> Router Class Initialized
INFO - 2018-11-23 12:35:26 --> Output Class Initialized
INFO - 2018-11-23 12:35:26 --> Security Class Initialized
DEBUG - 2018-11-23 12:35:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-23 12:35:26 --> Input Class Initialized
INFO - 2018-11-23 12:35:26 --> Language Class Initialized
INFO - 2018-11-23 12:35:26 --> Loader Class Initialized
INFO - 2018-11-23 12:35:26 --> Helper loaded: url_helper
INFO - 2018-11-23 12:35:26 --> Helper loaded: file_helper
INFO - 2018-11-23 12:35:26 --> Helper loaded: email_helper
INFO - 2018-11-23 12:35:26 --> Helper loaded: common_helper
INFO - 2018-11-23 12:35:26 --> Database Driver Class Initialized
DEBUG - 2018-11-23 12:35:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-23 12:35:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-23 12:35:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-23 12:35:26 --> Pagination Class Initialized
INFO - 2018-11-23 12:35:26 --> Helper loaded: form_helper
INFO - 2018-11-23 12:35:26 --> Form Validation Class Initialized
INFO - 2018-11-23 12:35:26 --> Model Class Initialized
INFO - 2018-11-23 12:35:26 --> Controller Class Initialized
INFO - 2018-11-23 12:35:26 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-23 12:35:26 --> Model Class Initialized
INFO - 2018-11-23 12:35:26 --> Model Class Initialized
INFO - 2018-11-23 12:35:26 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-23 12:35:26 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/change-password.php
INFO - 2018-11-23 12:35:26 --> Final output sent to browser
DEBUG - 2018-11-23 12:35:26 --> Total execution time: 0.0910
INFO - 2018-11-23 12:38:20 --> Config Class Initialized
INFO - 2018-11-23 12:38:20 --> Hooks Class Initialized
DEBUG - 2018-11-23 12:38:20 --> UTF-8 Support Enabled
INFO - 2018-11-23 12:38:20 --> Utf8 Class Initialized
INFO - 2018-11-23 12:38:20 --> URI Class Initialized
INFO - 2018-11-23 12:38:20 --> Router Class Initialized
INFO - 2018-11-23 12:38:20 --> Output Class Initialized
INFO - 2018-11-23 12:38:20 --> Security Class Initialized
DEBUG - 2018-11-23 12:38:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-23 12:38:20 --> Input Class Initialized
INFO - 2018-11-23 12:38:20 --> Language Class Initialized
INFO - 2018-11-23 12:38:20 --> Loader Class Initialized
INFO - 2018-11-23 12:38:20 --> Helper loaded: url_helper
INFO - 2018-11-23 12:38:20 --> Helper loaded: file_helper
INFO - 2018-11-23 12:38:20 --> Helper loaded: email_helper
INFO - 2018-11-23 12:38:20 --> Helper loaded: common_helper
INFO - 2018-11-23 12:38:20 --> Database Driver Class Initialized
DEBUG - 2018-11-23 12:38:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-23 12:38:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-23 12:38:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-23 12:38:20 --> Pagination Class Initialized
INFO - 2018-11-23 12:38:20 --> Helper loaded: form_helper
INFO - 2018-11-23 12:38:20 --> Form Validation Class Initialized
INFO - 2018-11-23 12:38:20 --> Model Class Initialized
INFO - 2018-11-23 12:38:20 --> Controller Class Initialized
INFO - 2018-11-23 12:38:20 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-23 12:38:20 --> Model Class Initialized
INFO - 2018-11-23 12:38:20 --> Model Class Initialized
INFO - 2018-11-23 12:38:20 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-23 12:38:20 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/change-password.php
INFO - 2018-11-23 12:38:20 --> Final output sent to browser
DEBUG - 2018-11-23 12:38:20 --> Total execution time: 0.0550
INFO - 2018-11-23 12:38:24 --> Config Class Initialized
INFO - 2018-11-23 12:38:24 --> Hooks Class Initialized
DEBUG - 2018-11-23 12:38:24 --> UTF-8 Support Enabled
INFO - 2018-11-23 12:38:24 --> Utf8 Class Initialized
INFO - 2018-11-23 12:38:24 --> URI Class Initialized
INFO - 2018-11-23 12:38:24 --> Router Class Initialized
INFO - 2018-11-23 12:38:24 --> Output Class Initialized
INFO - 2018-11-23 12:38:24 --> Security Class Initialized
DEBUG - 2018-11-23 12:38:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-23 12:38:24 --> Input Class Initialized
INFO - 2018-11-23 12:38:24 --> Language Class Initialized
INFO - 2018-11-23 12:38:24 --> Loader Class Initialized
INFO - 2018-11-23 12:38:24 --> Helper loaded: url_helper
INFO - 2018-11-23 12:38:24 --> Helper loaded: file_helper
INFO - 2018-11-23 12:38:24 --> Helper loaded: email_helper
INFO - 2018-11-23 12:38:24 --> Helper loaded: common_helper
INFO - 2018-11-23 12:38:24 --> Database Driver Class Initialized
DEBUG - 2018-11-23 12:38:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-23 12:38:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-23 12:38:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-23 12:38:24 --> Pagination Class Initialized
INFO - 2018-11-23 12:38:24 --> Helper loaded: form_helper
INFO - 2018-11-23 12:38:24 --> Form Validation Class Initialized
INFO - 2018-11-23 12:38:24 --> Model Class Initialized
INFO - 2018-11-23 12:38:24 --> Controller Class Initialized
INFO - 2018-11-23 12:38:24 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-23 12:38:24 --> Model Class Initialized
INFO - 2018-11-23 12:38:24 --> Model Class Initialized
INFO - 2018-11-23 12:38:24 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-23 12:38:24 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/change-password.php
INFO - 2018-11-23 12:38:24 --> Final output sent to browser
DEBUG - 2018-11-23 12:38:24 --> Total execution time: 0.0520
INFO - 2018-11-23 12:38:25 --> Config Class Initialized
INFO - 2018-11-23 12:38:25 --> Hooks Class Initialized
DEBUG - 2018-11-23 12:38:25 --> UTF-8 Support Enabled
INFO - 2018-11-23 12:38:25 --> Utf8 Class Initialized
INFO - 2018-11-23 12:38:25 --> URI Class Initialized
INFO - 2018-11-23 12:38:25 --> Router Class Initialized
INFO - 2018-11-23 12:38:25 --> Output Class Initialized
INFO - 2018-11-23 12:38:25 --> Security Class Initialized
DEBUG - 2018-11-23 12:38:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-23 12:38:25 --> Input Class Initialized
INFO - 2018-11-23 12:38:25 --> Language Class Initialized
INFO - 2018-11-23 12:38:25 --> Loader Class Initialized
INFO - 2018-11-23 12:38:25 --> Helper loaded: url_helper
INFO - 2018-11-23 12:38:25 --> Helper loaded: file_helper
INFO - 2018-11-23 12:38:25 --> Helper loaded: email_helper
INFO - 2018-11-23 12:38:25 --> Helper loaded: common_helper
INFO - 2018-11-23 12:38:25 --> Database Driver Class Initialized
DEBUG - 2018-11-23 12:38:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-23 12:38:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-23 12:38:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-23 12:38:25 --> Pagination Class Initialized
INFO - 2018-11-23 12:38:25 --> Helper loaded: form_helper
INFO - 2018-11-23 12:38:25 --> Form Validation Class Initialized
INFO - 2018-11-23 12:38:25 --> Model Class Initialized
INFO - 2018-11-23 12:38:25 --> Controller Class Initialized
INFO - 2018-11-23 12:38:25 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-23 12:38:25 --> Model Class Initialized
INFO - 2018-11-23 12:38:25 --> Model Class Initialized
INFO - 2018-11-23 12:38:25 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-23 12:38:25 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/change-password.php
INFO - 2018-11-23 12:38:25 --> Final output sent to browser
DEBUG - 2018-11-23 12:38:25 --> Total execution time: 0.0520
INFO - 2018-11-23 12:38:44 --> Config Class Initialized
INFO - 2018-11-23 12:38:44 --> Hooks Class Initialized
DEBUG - 2018-11-23 12:38:44 --> UTF-8 Support Enabled
INFO - 2018-11-23 12:38:44 --> Utf8 Class Initialized
INFO - 2018-11-23 12:38:44 --> URI Class Initialized
INFO - 2018-11-23 12:38:44 --> Router Class Initialized
INFO - 2018-11-23 12:38:44 --> Output Class Initialized
INFO - 2018-11-23 12:38:44 --> Security Class Initialized
DEBUG - 2018-11-23 12:38:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-23 12:38:44 --> Input Class Initialized
INFO - 2018-11-23 12:38:44 --> Language Class Initialized
INFO - 2018-11-23 12:38:44 --> Loader Class Initialized
INFO - 2018-11-23 12:38:44 --> Helper loaded: url_helper
INFO - 2018-11-23 12:38:44 --> Helper loaded: file_helper
INFO - 2018-11-23 12:38:44 --> Helper loaded: email_helper
INFO - 2018-11-23 12:38:44 --> Helper loaded: common_helper
INFO - 2018-11-23 12:38:44 --> Database Driver Class Initialized
DEBUG - 2018-11-23 12:38:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-23 12:38:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-23 12:38:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-23 12:38:44 --> Pagination Class Initialized
INFO - 2018-11-23 12:38:44 --> Helper loaded: form_helper
INFO - 2018-11-23 12:38:44 --> Form Validation Class Initialized
INFO - 2018-11-23 12:38:44 --> Model Class Initialized
INFO - 2018-11-23 12:38:44 --> Controller Class Initialized
INFO - 2018-11-23 12:38:44 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-23 12:38:44 --> Model Class Initialized
INFO - 2018-11-23 12:38:44 --> Model Class Initialized
INFO - 2018-11-23 12:38:44 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-23 12:38:44 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/change-password.php
INFO - 2018-11-23 12:38:44 --> Final output sent to browser
DEBUG - 2018-11-23 12:38:44 --> Total execution time: 0.0590
INFO - 2018-11-23 12:40:58 --> Config Class Initialized
INFO - 2018-11-23 12:40:58 --> Hooks Class Initialized
DEBUG - 2018-11-23 12:40:58 --> UTF-8 Support Enabled
INFO - 2018-11-23 12:40:58 --> Utf8 Class Initialized
INFO - 2018-11-23 12:40:58 --> URI Class Initialized
INFO - 2018-11-23 12:40:58 --> Router Class Initialized
INFO - 2018-11-23 12:40:58 --> Output Class Initialized
INFO - 2018-11-23 12:40:58 --> Security Class Initialized
DEBUG - 2018-11-23 12:40:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-23 12:40:58 --> Input Class Initialized
INFO - 2018-11-23 12:40:58 --> Language Class Initialized
INFO - 2018-11-23 12:40:58 --> Loader Class Initialized
INFO - 2018-11-23 12:40:58 --> Helper loaded: url_helper
INFO - 2018-11-23 12:40:58 --> Helper loaded: file_helper
INFO - 2018-11-23 12:40:58 --> Helper loaded: email_helper
INFO - 2018-11-23 12:40:58 --> Helper loaded: common_helper
INFO - 2018-11-23 12:40:58 --> Database Driver Class Initialized
DEBUG - 2018-11-23 12:40:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-23 12:40:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-23 12:40:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-23 12:40:58 --> Pagination Class Initialized
INFO - 2018-11-23 12:40:58 --> Helper loaded: form_helper
INFO - 2018-11-23 12:40:58 --> Form Validation Class Initialized
INFO - 2018-11-23 12:40:58 --> Model Class Initialized
INFO - 2018-11-23 12:40:58 --> Controller Class Initialized
INFO - 2018-11-23 12:40:58 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-23 12:40:58 --> Model Class Initialized
INFO - 2018-11-23 12:40:58 --> Model Class Initialized
INFO - 2018-11-23 12:40:58 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-23 12:40:58 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/change-password.php
INFO - 2018-11-23 12:40:58 --> Final output sent to browser
DEBUG - 2018-11-23 12:40:58 --> Total execution time: 0.0520
INFO - 2018-11-23 12:42:05 --> Config Class Initialized
INFO - 2018-11-23 12:42:05 --> Hooks Class Initialized
DEBUG - 2018-11-23 12:42:05 --> UTF-8 Support Enabled
INFO - 2018-11-23 12:42:05 --> Utf8 Class Initialized
INFO - 2018-11-23 12:42:05 --> URI Class Initialized
INFO - 2018-11-23 12:42:05 --> Router Class Initialized
INFO - 2018-11-23 12:42:05 --> Output Class Initialized
INFO - 2018-11-23 12:42:05 --> Security Class Initialized
DEBUG - 2018-11-23 12:42:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-23 12:42:05 --> Input Class Initialized
INFO - 2018-11-23 12:42:05 --> Language Class Initialized
INFO - 2018-11-23 12:42:05 --> Loader Class Initialized
INFO - 2018-11-23 12:42:05 --> Helper loaded: url_helper
INFO - 2018-11-23 12:42:05 --> Helper loaded: file_helper
INFO - 2018-11-23 12:42:05 --> Helper loaded: email_helper
INFO - 2018-11-23 12:42:05 --> Helper loaded: common_helper
INFO - 2018-11-23 12:42:05 --> Database Driver Class Initialized
DEBUG - 2018-11-23 12:42:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-23 12:42:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-23 12:42:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-23 12:42:05 --> Pagination Class Initialized
INFO - 2018-11-23 12:42:05 --> Helper loaded: form_helper
INFO - 2018-11-23 12:42:05 --> Form Validation Class Initialized
INFO - 2018-11-23 12:42:05 --> Model Class Initialized
INFO - 2018-11-23 12:42:05 --> Controller Class Initialized
INFO - 2018-11-23 12:42:05 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-23 12:42:05 --> Model Class Initialized
INFO - 2018-11-23 12:42:05 --> Model Class Initialized
INFO - 2018-11-23 12:42:05 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-23 12:42:05 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/change-password.php
INFO - 2018-11-23 12:42:05 --> Final output sent to browser
DEBUG - 2018-11-23 12:42:05 --> Total execution time: 0.0580
INFO - 2018-11-23 12:42:22 --> Config Class Initialized
INFO - 2018-11-23 12:42:22 --> Hooks Class Initialized
DEBUG - 2018-11-23 12:42:22 --> UTF-8 Support Enabled
INFO - 2018-11-23 12:42:22 --> Utf8 Class Initialized
INFO - 2018-11-23 12:42:22 --> URI Class Initialized
INFO - 2018-11-23 12:42:22 --> Router Class Initialized
INFO - 2018-11-23 12:42:22 --> Output Class Initialized
INFO - 2018-11-23 12:42:22 --> Security Class Initialized
DEBUG - 2018-11-23 12:42:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-23 12:42:22 --> Input Class Initialized
INFO - 2018-11-23 12:42:22 --> Language Class Initialized
INFO - 2018-11-23 12:42:22 --> Loader Class Initialized
INFO - 2018-11-23 12:42:22 --> Helper loaded: url_helper
INFO - 2018-11-23 12:42:22 --> Helper loaded: file_helper
INFO - 2018-11-23 12:42:22 --> Helper loaded: email_helper
INFO - 2018-11-23 12:42:22 --> Helper loaded: common_helper
INFO - 2018-11-23 12:42:22 --> Database Driver Class Initialized
DEBUG - 2018-11-23 12:42:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-23 12:42:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-23 12:42:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-23 12:42:22 --> Pagination Class Initialized
INFO - 2018-11-23 12:42:22 --> Helper loaded: form_helper
INFO - 2018-11-23 12:42:22 --> Form Validation Class Initialized
INFO - 2018-11-23 12:42:22 --> Model Class Initialized
INFO - 2018-11-23 12:42:22 --> Controller Class Initialized
INFO - 2018-11-23 12:42:22 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-23 12:42:22 --> Model Class Initialized
INFO - 2018-11-23 12:42:22 --> Model Class Initialized
INFO - 2018-11-23 12:42:22 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-23 12:42:22 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/change-password.php
INFO - 2018-11-23 12:42:22 --> Final output sent to browser
DEBUG - 2018-11-23 12:42:22 --> Total execution time: 0.0610
INFO - 2018-11-23 12:43:12 --> Config Class Initialized
INFO - 2018-11-23 12:43:12 --> Hooks Class Initialized
DEBUG - 2018-11-23 12:43:12 --> UTF-8 Support Enabled
INFO - 2018-11-23 12:43:12 --> Utf8 Class Initialized
INFO - 2018-11-23 12:43:12 --> URI Class Initialized
INFO - 2018-11-23 12:43:12 --> Router Class Initialized
INFO - 2018-11-23 12:43:12 --> Output Class Initialized
INFO - 2018-11-23 12:43:12 --> Security Class Initialized
DEBUG - 2018-11-23 12:43:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-23 12:43:12 --> Input Class Initialized
INFO - 2018-11-23 12:43:12 --> Language Class Initialized
INFO - 2018-11-23 12:43:12 --> Loader Class Initialized
INFO - 2018-11-23 12:43:12 --> Helper loaded: url_helper
INFO - 2018-11-23 12:43:12 --> Helper loaded: file_helper
INFO - 2018-11-23 12:43:12 --> Helper loaded: email_helper
INFO - 2018-11-23 12:43:12 --> Helper loaded: common_helper
INFO - 2018-11-23 12:43:12 --> Database Driver Class Initialized
DEBUG - 2018-11-23 12:43:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-23 12:43:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-23 12:43:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-23 12:43:12 --> Pagination Class Initialized
INFO - 2018-11-23 12:43:12 --> Helper loaded: form_helper
INFO - 2018-11-23 12:43:12 --> Form Validation Class Initialized
INFO - 2018-11-23 12:43:12 --> Model Class Initialized
INFO - 2018-11-23 12:43:12 --> Controller Class Initialized
INFO - 2018-11-23 12:43:12 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-23 12:43:12 --> Model Class Initialized
INFO - 2018-11-23 12:43:12 --> Model Class Initialized
INFO - 2018-11-23 12:43:12 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-23 12:43:12 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/change-password.php
INFO - 2018-11-23 12:43:12 --> Final output sent to browser
DEBUG - 2018-11-23 12:43:12 --> Total execution time: 0.0630
INFO - 2018-11-23 12:43:24 --> Config Class Initialized
INFO - 2018-11-23 12:43:24 --> Hooks Class Initialized
DEBUG - 2018-11-23 12:43:24 --> UTF-8 Support Enabled
INFO - 2018-11-23 12:43:24 --> Utf8 Class Initialized
INFO - 2018-11-23 12:43:24 --> URI Class Initialized
INFO - 2018-11-23 12:43:24 --> Router Class Initialized
INFO - 2018-11-23 12:43:24 --> Output Class Initialized
INFO - 2018-11-23 12:43:24 --> Security Class Initialized
DEBUG - 2018-11-23 12:43:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-23 12:43:24 --> Input Class Initialized
INFO - 2018-11-23 12:43:24 --> Language Class Initialized
INFO - 2018-11-23 12:43:24 --> Loader Class Initialized
INFO - 2018-11-23 12:43:24 --> Helper loaded: url_helper
INFO - 2018-11-23 12:43:24 --> Helper loaded: file_helper
INFO - 2018-11-23 12:43:24 --> Helper loaded: email_helper
INFO - 2018-11-23 12:43:24 --> Helper loaded: common_helper
INFO - 2018-11-23 12:43:24 --> Database Driver Class Initialized
DEBUG - 2018-11-23 12:43:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-23 12:43:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-23 12:43:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-23 12:43:24 --> Pagination Class Initialized
INFO - 2018-11-23 12:43:24 --> Helper loaded: form_helper
INFO - 2018-11-23 12:43:24 --> Form Validation Class Initialized
INFO - 2018-11-23 12:43:24 --> Model Class Initialized
INFO - 2018-11-23 12:43:24 --> Controller Class Initialized
INFO - 2018-11-23 12:43:24 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-23 12:43:24 --> Model Class Initialized
INFO - 2018-11-23 12:43:24 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-23 12:43:24 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/sidebar.php
INFO - 2018-11-23 12:43:24 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/right-sidebar.php
INFO - 2018-11-23 12:43:24 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/footer.php
INFO - 2018-11-23 12:43:24 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/dashboard.php
INFO - 2018-11-23 12:43:24 --> Final output sent to browser
DEBUG - 2018-11-23 12:43:24 --> Total execution time: 0.0540
INFO - 2018-11-23 12:44:07 --> Config Class Initialized
INFO - 2018-11-23 12:44:07 --> Hooks Class Initialized
DEBUG - 2018-11-23 12:44:07 --> UTF-8 Support Enabled
INFO - 2018-11-23 12:44:07 --> Utf8 Class Initialized
INFO - 2018-11-23 12:44:07 --> URI Class Initialized
INFO - 2018-11-23 12:44:07 --> Router Class Initialized
INFO - 2018-11-23 12:44:07 --> Output Class Initialized
INFO - 2018-11-23 12:44:07 --> Security Class Initialized
DEBUG - 2018-11-23 12:44:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-23 12:44:07 --> Input Class Initialized
INFO - 2018-11-23 12:44:07 --> Language Class Initialized
INFO - 2018-11-23 12:44:07 --> Loader Class Initialized
INFO - 2018-11-23 12:44:07 --> Helper loaded: url_helper
INFO - 2018-11-23 12:44:07 --> Helper loaded: file_helper
INFO - 2018-11-23 12:44:07 --> Helper loaded: email_helper
INFO - 2018-11-23 12:44:07 --> Helper loaded: common_helper
INFO - 2018-11-23 12:44:07 --> Database Driver Class Initialized
DEBUG - 2018-11-23 12:44:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-23 12:44:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-23 12:44:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-23 12:44:07 --> Pagination Class Initialized
INFO - 2018-11-23 12:44:07 --> Helper loaded: form_helper
INFO - 2018-11-23 12:44:07 --> Form Validation Class Initialized
INFO - 2018-11-23 12:44:07 --> Model Class Initialized
INFO - 2018-11-23 12:44:07 --> Controller Class Initialized
INFO - 2018-11-23 12:44:07 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-23 12:44:07 --> Model Class Initialized
INFO - 2018-11-23 12:44:07 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-23 12:44:07 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/sidebar.php
INFO - 2018-11-23 12:44:07 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/right-sidebar.php
INFO - 2018-11-23 12:44:07 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/footer.php
INFO - 2018-11-23 12:44:07 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/dashboard.php
INFO - 2018-11-23 12:44:07 --> Final output sent to browser
DEBUG - 2018-11-23 12:44:07 --> Total execution time: 0.0620
INFO - 2018-11-23 12:44:14 --> Config Class Initialized
INFO - 2018-11-23 12:44:14 --> Hooks Class Initialized
DEBUG - 2018-11-23 12:44:14 --> UTF-8 Support Enabled
INFO - 2018-11-23 12:44:14 --> Utf8 Class Initialized
INFO - 2018-11-23 12:44:14 --> URI Class Initialized
INFO - 2018-11-23 12:44:14 --> Router Class Initialized
INFO - 2018-11-23 12:44:14 --> Output Class Initialized
INFO - 2018-11-23 12:44:14 --> Security Class Initialized
DEBUG - 2018-11-23 12:44:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-23 12:44:14 --> Input Class Initialized
INFO - 2018-11-23 12:44:14 --> Language Class Initialized
INFO - 2018-11-23 12:44:14 --> Loader Class Initialized
INFO - 2018-11-23 12:44:14 --> Helper loaded: url_helper
INFO - 2018-11-23 12:44:14 --> Helper loaded: file_helper
INFO - 2018-11-23 12:44:14 --> Helper loaded: email_helper
INFO - 2018-11-23 12:44:14 --> Helper loaded: common_helper
INFO - 2018-11-23 12:44:14 --> Database Driver Class Initialized
DEBUG - 2018-11-23 12:44:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-23 12:44:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-23 12:44:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-23 12:44:14 --> Pagination Class Initialized
INFO - 2018-11-23 12:44:14 --> Helper loaded: form_helper
INFO - 2018-11-23 12:44:14 --> Form Validation Class Initialized
INFO - 2018-11-23 12:44:14 --> Model Class Initialized
INFO - 2018-11-23 12:44:14 --> Controller Class Initialized
INFO - 2018-11-23 12:44:14 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-23 12:44:14 --> Model Class Initialized
INFO - 2018-11-23 12:44:14 --> Model Class Initialized
INFO - 2018-11-23 12:44:14 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-23 12:44:14 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/change-password.php
INFO - 2018-11-23 12:44:14 --> Final output sent to browser
DEBUG - 2018-11-23 12:44:14 --> Total execution time: 0.0630
INFO - 2018-11-23 12:46:04 --> Config Class Initialized
INFO - 2018-11-23 12:46:04 --> Hooks Class Initialized
DEBUG - 2018-11-23 12:46:04 --> UTF-8 Support Enabled
INFO - 2018-11-23 12:46:04 --> Utf8 Class Initialized
INFO - 2018-11-23 12:46:04 --> URI Class Initialized
INFO - 2018-11-23 12:46:04 --> Router Class Initialized
INFO - 2018-11-23 12:46:04 --> Output Class Initialized
INFO - 2018-11-23 12:46:04 --> Security Class Initialized
DEBUG - 2018-11-23 12:46:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-23 12:46:04 --> Input Class Initialized
INFO - 2018-11-23 12:46:04 --> Language Class Initialized
INFO - 2018-11-23 12:46:04 --> Loader Class Initialized
INFO - 2018-11-23 12:46:04 --> Helper loaded: url_helper
INFO - 2018-11-23 12:46:04 --> Helper loaded: file_helper
INFO - 2018-11-23 12:46:04 --> Helper loaded: email_helper
INFO - 2018-11-23 12:46:04 --> Helper loaded: common_helper
INFO - 2018-11-23 12:46:04 --> Database Driver Class Initialized
DEBUG - 2018-11-23 12:46:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-23 12:46:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-23 12:46:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-23 12:46:04 --> Pagination Class Initialized
INFO - 2018-11-23 12:46:04 --> Helper loaded: form_helper
INFO - 2018-11-23 12:46:04 --> Form Validation Class Initialized
INFO - 2018-11-23 12:46:04 --> Model Class Initialized
INFO - 2018-11-23 12:46:04 --> Controller Class Initialized
INFO - 2018-11-23 12:46:04 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-23 12:46:04 --> Model Class Initialized
INFO - 2018-11-23 12:46:04 --> Model Class Initialized
INFO - 2018-11-23 12:46:04 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-23 12:46:04 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/change-password.php
INFO - 2018-11-23 12:46:04 --> Final output sent to browser
DEBUG - 2018-11-23 12:46:04 --> Total execution time: 0.0610
INFO - 2018-11-23 12:46:23 --> Config Class Initialized
INFO - 2018-11-23 12:46:23 --> Hooks Class Initialized
DEBUG - 2018-11-23 12:46:23 --> UTF-8 Support Enabled
INFO - 2018-11-23 12:46:23 --> Utf8 Class Initialized
INFO - 2018-11-23 12:46:23 --> URI Class Initialized
INFO - 2018-11-23 12:46:23 --> Router Class Initialized
INFO - 2018-11-23 12:46:23 --> Output Class Initialized
INFO - 2018-11-23 12:46:23 --> Security Class Initialized
DEBUG - 2018-11-23 12:46:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-23 12:46:23 --> Input Class Initialized
INFO - 2018-11-23 12:46:23 --> Language Class Initialized
INFO - 2018-11-23 12:46:23 --> Loader Class Initialized
INFO - 2018-11-23 12:46:23 --> Helper loaded: url_helper
INFO - 2018-11-23 12:46:23 --> Helper loaded: file_helper
INFO - 2018-11-23 12:46:23 --> Helper loaded: email_helper
INFO - 2018-11-23 12:46:23 --> Helper loaded: common_helper
INFO - 2018-11-23 12:46:23 --> Database Driver Class Initialized
DEBUG - 2018-11-23 12:46:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-23 12:46:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-23 12:46:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-23 12:46:23 --> Pagination Class Initialized
INFO - 2018-11-23 12:46:23 --> Helper loaded: form_helper
INFO - 2018-11-23 12:46:23 --> Form Validation Class Initialized
INFO - 2018-11-23 12:46:23 --> Model Class Initialized
INFO - 2018-11-23 12:46:23 --> Controller Class Initialized
INFO - 2018-11-23 12:46:23 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-23 12:46:23 --> Model Class Initialized
INFO - 2018-11-23 12:46:23 --> Model Class Initialized
INFO - 2018-11-23 12:46:23 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-23 12:46:23 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/change-password.php
INFO - 2018-11-23 12:46:23 --> Final output sent to browser
DEBUG - 2018-11-23 12:46:23 --> Total execution time: 0.0530
INFO - 2018-11-23 12:46:50 --> Config Class Initialized
INFO - 2018-11-23 12:46:50 --> Hooks Class Initialized
DEBUG - 2018-11-23 12:46:50 --> UTF-8 Support Enabled
INFO - 2018-11-23 12:46:50 --> Utf8 Class Initialized
INFO - 2018-11-23 12:46:50 --> URI Class Initialized
INFO - 2018-11-23 12:46:50 --> Router Class Initialized
INFO - 2018-11-23 12:46:50 --> Output Class Initialized
INFO - 2018-11-23 12:46:50 --> Security Class Initialized
DEBUG - 2018-11-23 12:46:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-23 12:46:50 --> Input Class Initialized
INFO - 2018-11-23 12:46:50 --> Language Class Initialized
INFO - 2018-11-23 12:46:50 --> Loader Class Initialized
INFO - 2018-11-23 12:46:50 --> Helper loaded: url_helper
INFO - 2018-11-23 12:46:50 --> Helper loaded: file_helper
INFO - 2018-11-23 12:46:50 --> Helper loaded: email_helper
INFO - 2018-11-23 12:46:50 --> Helper loaded: common_helper
INFO - 2018-11-23 12:46:50 --> Database Driver Class Initialized
DEBUG - 2018-11-23 12:46:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-23 12:46:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-23 12:46:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-23 12:46:50 --> Pagination Class Initialized
INFO - 2018-11-23 12:46:50 --> Helper loaded: form_helper
INFO - 2018-11-23 12:46:50 --> Form Validation Class Initialized
INFO - 2018-11-23 12:46:50 --> Model Class Initialized
INFO - 2018-11-23 12:46:50 --> Controller Class Initialized
INFO - 2018-11-23 12:46:50 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-23 12:46:50 --> Model Class Initialized
INFO - 2018-11-23 12:46:50 --> Model Class Initialized
INFO - 2018-11-23 12:46:50 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-23 12:46:50 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/change-password.php
INFO - 2018-11-23 12:46:50 --> Final output sent to browser
DEBUG - 2018-11-23 12:46:50 --> Total execution time: 0.0610
INFO - 2018-11-23 12:49:45 --> Config Class Initialized
INFO - 2018-11-23 12:49:45 --> Hooks Class Initialized
DEBUG - 2018-11-23 12:49:45 --> UTF-8 Support Enabled
INFO - 2018-11-23 12:49:45 --> Utf8 Class Initialized
INFO - 2018-11-23 12:49:45 --> URI Class Initialized
INFO - 2018-11-23 12:49:45 --> Router Class Initialized
INFO - 2018-11-23 12:49:45 --> Output Class Initialized
INFO - 2018-11-23 12:49:45 --> Security Class Initialized
DEBUG - 2018-11-23 12:49:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-23 12:49:45 --> Input Class Initialized
INFO - 2018-11-23 12:49:45 --> Language Class Initialized
INFO - 2018-11-23 12:49:45 --> Loader Class Initialized
INFO - 2018-11-23 12:49:45 --> Helper loaded: url_helper
INFO - 2018-11-23 12:49:45 --> Helper loaded: file_helper
INFO - 2018-11-23 12:49:45 --> Helper loaded: email_helper
INFO - 2018-11-23 12:49:45 --> Helper loaded: common_helper
INFO - 2018-11-23 12:49:45 --> Database Driver Class Initialized
DEBUG - 2018-11-23 12:49:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-23 12:49:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-23 12:49:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-23 12:49:45 --> Pagination Class Initialized
INFO - 2018-11-23 12:49:45 --> Helper loaded: form_helper
INFO - 2018-11-23 12:49:45 --> Form Validation Class Initialized
INFO - 2018-11-23 12:49:45 --> Model Class Initialized
INFO - 2018-11-23 12:49:45 --> Controller Class Initialized
INFO - 2018-11-23 12:49:45 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-23 12:49:45 --> Model Class Initialized
INFO - 2018-11-23 12:49:45 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-23 12:49:45 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/sidebar.php
INFO - 2018-11-23 12:49:45 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/right-sidebar.php
INFO - 2018-11-23 12:49:45 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/footer.php
INFO - 2018-11-23 12:49:45 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/dashboard.php
INFO - 2018-11-23 12:49:45 --> Final output sent to browser
DEBUG - 2018-11-23 12:49:45 --> Total execution time: 0.0490
INFO - 2018-11-23 12:50:10 --> Config Class Initialized
INFO - 2018-11-23 12:50:10 --> Hooks Class Initialized
DEBUG - 2018-11-23 12:50:10 --> UTF-8 Support Enabled
INFO - 2018-11-23 12:50:10 --> Utf8 Class Initialized
INFO - 2018-11-23 12:50:10 --> URI Class Initialized
INFO - 2018-11-23 12:50:10 --> Router Class Initialized
INFO - 2018-11-23 12:50:10 --> Output Class Initialized
INFO - 2018-11-23 12:50:10 --> Security Class Initialized
DEBUG - 2018-11-23 12:50:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-23 12:50:10 --> Input Class Initialized
INFO - 2018-11-23 12:50:10 --> Language Class Initialized
INFO - 2018-11-23 12:50:10 --> Loader Class Initialized
INFO - 2018-11-23 12:50:10 --> Helper loaded: url_helper
INFO - 2018-11-23 12:50:10 --> Helper loaded: file_helper
INFO - 2018-11-23 12:50:10 --> Helper loaded: email_helper
INFO - 2018-11-23 12:50:10 --> Helper loaded: common_helper
INFO - 2018-11-23 12:50:10 --> Database Driver Class Initialized
DEBUG - 2018-11-23 12:50:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-23 12:50:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-23 12:50:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-23 12:50:10 --> Pagination Class Initialized
INFO - 2018-11-23 12:50:10 --> Helper loaded: form_helper
INFO - 2018-11-23 12:50:10 --> Form Validation Class Initialized
INFO - 2018-11-23 12:50:10 --> Model Class Initialized
INFO - 2018-11-23 12:50:10 --> Controller Class Initialized
INFO - 2018-11-23 12:50:10 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-23 12:50:10 --> Model Class Initialized
INFO - 2018-11-23 12:50:10 --> Model Class Initialized
INFO - 2018-11-23 12:50:10 --> Config Class Initialized
INFO - 2018-11-23 12:50:10 --> Hooks Class Initialized
DEBUG - 2018-11-23 12:50:10 --> UTF-8 Support Enabled
INFO - 2018-11-23 12:50:10 --> Utf8 Class Initialized
INFO - 2018-11-23 12:50:10 --> URI Class Initialized
INFO - 2018-11-23 12:50:10 --> Router Class Initialized
INFO - 2018-11-23 12:50:10 --> Output Class Initialized
INFO - 2018-11-23 12:50:10 --> Security Class Initialized
DEBUG - 2018-11-23 12:50:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-23 12:50:10 --> Input Class Initialized
INFO - 2018-11-23 12:50:10 --> Language Class Initialized
INFO - 2018-11-23 12:50:10 --> Loader Class Initialized
INFO - 2018-11-23 12:50:10 --> Helper loaded: url_helper
INFO - 2018-11-23 12:50:10 --> Helper loaded: file_helper
INFO - 2018-11-23 12:50:10 --> Helper loaded: email_helper
INFO - 2018-11-23 12:50:10 --> Helper loaded: common_helper
INFO - 2018-11-23 12:50:10 --> Database Driver Class Initialized
DEBUG - 2018-11-23 12:50:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-23 12:50:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-23 12:50:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-23 12:50:10 --> Pagination Class Initialized
INFO - 2018-11-23 12:50:10 --> Helper loaded: form_helper
INFO - 2018-11-23 12:50:10 --> Form Validation Class Initialized
INFO - 2018-11-23 12:50:10 --> Model Class Initialized
INFO - 2018-11-23 12:50:10 --> Controller Class Initialized
INFO - 2018-11-23 12:50:10 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-23 12:50:10 --> Model Class Initialized
INFO - 2018-11-23 12:50:10 --> Model Class Initialized
INFO - 2018-11-23 12:50:10 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/index.php
INFO - 2018-11-23 12:50:10 --> Final output sent to browser
DEBUG - 2018-11-23 12:50:10 --> Total execution time: 0.0530
INFO - 2018-11-23 12:52:09 --> Config Class Initialized
INFO - 2018-11-23 12:52:09 --> Hooks Class Initialized
DEBUG - 2018-11-23 12:52:09 --> UTF-8 Support Enabled
INFO - 2018-11-23 12:52:09 --> Utf8 Class Initialized
INFO - 2018-11-23 12:52:09 --> URI Class Initialized
INFO - 2018-11-23 12:52:09 --> Router Class Initialized
INFO - 2018-11-23 12:52:09 --> Output Class Initialized
INFO - 2018-11-23 12:52:09 --> Security Class Initialized
DEBUG - 2018-11-23 12:52:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-23 12:52:09 --> Input Class Initialized
INFO - 2018-11-23 12:52:09 --> Language Class Initialized
INFO - 2018-11-23 12:52:09 --> Loader Class Initialized
INFO - 2018-11-23 12:52:09 --> Helper loaded: url_helper
INFO - 2018-11-23 12:52:09 --> Helper loaded: file_helper
INFO - 2018-11-23 12:52:09 --> Helper loaded: email_helper
INFO - 2018-11-23 12:52:09 --> Helper loaded: common_helper
INFO - 2018-11-23 12:52:09 --> Database Driver Class Initialized
DEBUG - 2018-11-23 12:52:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-23 12:52:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-23 12:52:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-23 12:52:09 --> Pagination Class Initialized
INFO - 2018-11-23 12:52:09 --> Helper loaded: form_helper
INFO - 2018-11-23 12:52:09 --> Form Validation Class Initialized
INFO - 2018-11-23 12:52:09 --> Model Class Initialized
INFO - 2018-11-23 12:52:09 --> Controller Class Initialized
INFO - 2018-11-23 12:52:09 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-23 12:52:09 --> Model Class Initialized
INFO - 2018-11-23 12:52:09 --> Model Class Initialized
INFO - 2018-11-23 12:52:09 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/index.php
INFO - 2018-11-23 12:52:09 --> Final output sent to browser
DEBUG - 2018-11-23 12:52:09 --> Total execution time: 0.0520
INFO - 2018-11-23 12:52:57 --> Config Class Initialized
INFO - 2018-11-23 12:52:57 --> Hooks Class Initialized
DEBUG - 2018-11-23 12:52:57 --> UTF-8 Support Enabled
INFO - 2018-11-23 12:52:57 --> Utf8 Class Initialized
INFO - 2018-11-23 12:52:57 --> URI Class Initialized
INFO - 2018-11-23 12:52:57 --> Router Class Initialized
INFO - 2018-11-23 12:52:57 --> Output Class Initialized
INFO - 2018-11-23 12:52:57 --> Security Class Initialized
DEBUG - 2018-11-23 12:52:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-23 12:52:57 --> Input Class Initialized
INFO - 2018-11-23 12:52:57 --> Language Class Initialized
INFO - 2018-11-23 12:52:57 --> Loader Class Initialized
INFO - 2018-11-23 12:52:57 --> Helper loaded: url_helper
INFO - 2018-11-23 12:52:57 --> Helper loaded: file_helper
INFO - 2018-11-23 12:52:57 --> Helper loaded: email_helper
INFO - 2018-11-23 12:52:57 --> Helper loaded: common_helper
INFO - 2018-11-23 12:52:57 --> Database Driver Class Initialized
DEBUG - 2018-11-23 12:52:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-23 12:52:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-23 12:52:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-23 12:52:57 --> Pagination Class Initialized
INFO - 2018-11-23 12:52:57 --> Helper loaded: form_helper
INFO - 2018-11-23 12:52:57 --> Form Validation Class Initialized
INFO - 2018-11-23 12:52:57 --> Model Class Initialized
INFO - 2018-11-23 12:52:57 --> Controller Class Initialized
INFO - 2018-11-23 12:52:57 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-23 12:52:57 --> Model Class Initialized
INFO - 2018-11-23 12:52:57 --> Model Class Initialized
INFO - 2018-11-23 12:52:57 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/index.php
INFO - 2018-11-23 12:52:57 --> Final output sent to browser
DEBUG - 2018-11-23 12:52:57 --> Total execution time: 0.0490
INFO - 2018-11-23 12:53:08 --> Config Class Initialized
INFO - 2018-11-23 12:53:08 --> Hooks Class Initialized
DEBUG - 2018-11-23 12:53:08 --> UTF-8 Support Enabled
INFO - 2018-11-23 12:53:08 --> Utf8 Class Initialized
INFO - 2018-11-23 12:53:08 --> URI Class Initialized
INFO - 2018-11-23 12:53:08 --> Router Class Initialized
INFO - 2018-11-23 12:53:08 --> Output Class Initialized
INFO - 2018-11-23 12:53:08 --> Security Class Initialized
DEBUG - 2018-11-23 12:53:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-23 12:53:08 --> Input Class Initialized
INFO - 2018-11-23 12:53:08 --> Language Class Initialized
INFO - 2018-11-23 12:53:08 --> Loader Class Initialized
INFO - 2018-11-23 12:53:08 --> Helper loaded: url_helper
INFO - 2018-11-23 12:53:08 --> Helper loaded: file_helper
INFO - 2018-11-23 12:53:08 --> Helper loaded: email_helper
INFO - 2018-11-23 12:53:08 --> Helper loaded: common_helper
INFO - 2018-11-23 12:53:08 --> Database Driver Class Initialized
DEBUG - 2018-11-23 12:53:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-23 12:53:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-23 12:53:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-23 12:53:08 --> Pagination Class Initialized
INFO - 2018-11-23 12:53:08 --> Helper loaded: form_helper
INFO - 2018-11-23 12:53:08 --> Form Validation Class Initialized
INFO - 2018-11-23 12:53:08 --> Model Class Initialized
INFO - 2018-11-23 12:53:08 --> Controller Class Initialized
INFO - 2018-11-23 12:53:08 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-23 12:53:08 --> Model Class Initialized
INFO - 2018-11-23 12:53:08 --> Model Class Initialized
INFO - 2018-11-23 12:53:08 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/index.php
INFO - 2018-11-23 12:53:08 --> Final output sent to browser
DEBUG - 2018-11-23 12:53:08 --> Total execution time: 0.0610
INFO - 2018-11-23 12:53:43 --> Config Class Initialized
INFO - 2018-11-23 12:53:43 --> Hooks Class Initialized
DEBUG - 2018-11-23 12:53:43 --> UTF-8 Support Enabled
INFO - 2018-11-23 12:53:43 --> Utf8 Class Initialized
INFO - 2018-11-23 12:53:43 --> URI Class Initialized
INFO - 2018-11-23 12:53:43 --> Router Class Initialized
INFO - 2018-11-23 12:53:43 --> Output Class Initialized
INFO - 2018-11-23 12:53:43 --> Security Class Initialized
DEBUG - 2018-11-23 12:53:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-23 12:53:43 --> Input Class Initialized
INFO - 2018-11-23 12:53:43 --> Language Class Initialized
ERROR - 2018-11-23 12:53:43 --> 404 Page Not Found: admin/Forgot_password/index
INFO - 2018-11-23 12:53:59 --> Config Class Initialized
INFO - 2018-11-23 12:53:59 --> Hooks Class Initialized
DEBUG - 2018-11-23 12:53:59 --> UTF-8 Support Enabled
INFO - 2018-11-23 12:53:59 --> Utf8 Class Initialized
INFO - 2018-11-23 12:53:59 --> URI Class Initialized
INFO - 2018-11-23 12:53:59 --> Router Class Initialized
INFO - 2018-11-23 12:53:59 --> Output Class Initialized
INFO - 2018-11-23 12:53:59 --> Security Class Initialized
DEBUG - 2018-11-23 12:53:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-23 12:53:59 --> Input Class Initialized
INFO - 2018-11-23 12:53:59 --> Language Class Initialized
INFO - 2018-11-23 12:53:59 --> Loader Class Initialized
INFO - 2018-11-23 12:53:59 --> Helper loaded: url_helper
INFO - 2018-11-23 12:53:59 --> Helper loaded: file_helper
INFO - 2018-11-23 12:53:59 --> Helper loaded: email_helper
INFO - 2018-11-23 12:53:59 --> Helper loaded: common_helper
INFO - 2018-11-23 12:53:59 --> Database Driver Class Initialized
DEBUG - 2018-11-23 12:53:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-23 12:53:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-23 12:53:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-23 12:53:59 --> Pagination Class Initialized
INFO - 2018-11-23 12:53:59 --> Helper loaded: form_helper
INFO - 2018-11-23 12:53:59 --> Form Validation Class Initialized
INFO - 2018-11-23 12:53:59 --> Model Class Initialized
INFO - 2018-11-23 12:53:59 --> Controller Class Initialized
INFO - 2018-11-23 12:53:59 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-23 12:53:59 --> Model Class Initialized
INFO - 2018-11-23 12:53:59 --> Model Class Initialized
INFO - 2018-11-23 12:53:59 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/index.php
INFO - 2018-11-23 12:53:59 --> Final output sent to browser
DEBUG - 2018-11-23 12:53:59 --> Total execution time: 0.0450
INFO - 2018-11-23 12:54:06 --> Config Class Initialized
INFO - 2018-11-23 12:54:06 --> Hooks Class Initialized
DEBUG - 2018-11-23 12:54:06 --> UTF-8 Support Enabled
INFO - 2018-11-23 12:54:06 --> Utf8 Class Initialized
INFO - 2018-11-23 12:54:06 --> URI Class Initialized
INFO - 2018-11-23 12:54:06 --> Router Class Initialized
INFO - 2018-11-23 12:54:06 --> Output Class Initialized
INFO - 2018-11-23 12:54:06 --> Security Class Initialized
DEBUG - 2018-11-23 12:54:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-23 12:54:06 --> Input Class Initialized
INFO - 2018-11-23 12:54:06 --> Language Class Initialized
ERROR - 2018-11-23 12:54:06 --> 404 Page Not Found: admin/Forgot_password/index
INFO - 2018-11-23 12:54:10 --> Config Class Initialized
INFO - 2018-11-23 12:54:10 --> Hooks Class Initialized
DEBUG - 2018-11-23 12:54:10 --> UTF-8 Support Enabled
INFO - 2018-11-23 12:54:10 --> Utf8 Class Initialized
INFO - 2018-11-23 12:54:10 --> URI Class Initialized
INFO - 2018-11-23 12:54:10 --> Router Class Initialized
INFO - 2018-11-23 12:54:10 --> Output Class Initialized
INFO - 2018-11-23 12:54:10 --> Security Class Initialized
DEBUG - 2018-11-23 12:54:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-23 12:54:10 --> Input Class Initialized
INFO - 2018-11-23 12:54:10 --> Language Class Initialized
INFO - 2018-11-23 12:54:10 --> Loader Class Initialized
INFO - 2018-11-23 12:54:10 --> Helper loaded: url_helper
INFO - 2018-11-23 12:54:10 --> Helper loaded: file_helper
INFO - 2018-11-23 12:54:10 --> Helper loaded: email_helper
INFO - 2018-11-23 12:54:10 --> Helper loaded: common_helper
INFO - 2018-11-23 12:54:10 --> Database Driver Class Initialized
DEBUG - 2018-11-23 12:54:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-23 12:54:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-23 12:54:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-23 12:54:10 --> Pagination Class Initialized
INFO - 2018-11-23 12:54:10 --> Helper loaded: form_helper
INFO - 2018-11-23 12:54:10 --> Form Validation Class Initialized
INFO - 2018-11-23 12:54:10 --> Model Class Initialized
INFO - 2018-11-23 12:54:10 --> Controller Class Initialized
INFO - 2018-11-23 12:54:10 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-23 12:54:10 --> Model Class Initialized
INFO - 2018-11-23 12:54:10 --> Model Class Initialized
INFO - 2018-11-23 12:54:10 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/index.php
INFO - 2018-11-23 12:54:10 --> Final output sent to browser
DEBUG - 2018-11-23 12:54:10 --> Total execution time: 0.0630
INFO - 2018-11-23 12:54:19 --> Config Class Initialized
INFO - 2018-11-23 12:54:19 --> Hooks Class Initialized
DEBUG - 2018-11-23 12:54:19 --> UTF-8 Support Enabled
INFO - 2018-11-23 12:54:19 --> Utf8 Class Initialized
INFO - 2018-11-23 12:54:19 --> URI Class Initialized
INFO - 2018-11-23 12:54:19 --> Router Class Initialized
INFO - 2018-11-23 12:54:19 --> Output Class Initialized
INFO - 2018-11-23 12:54:19 --> Security Class Initialized
DEBUG - 2018-11-23 12:54:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-23 12:54:19 --> Input Class Initialized
INFO - 2018-11-23 12:54:19 --> Language Class Initialized
INFO - 2018-11-23 12:54:19 --> Loader Class Initialized
INFO - 2018-11-23 12:54:19 --> Helper loaded: url_helper
INFO - 2018-11-23 12:54:19 --> Helper loaded: file_helper
INFO - 2018-11-23 12:54:19 --> Helper loaded: email_helper
INFO - 2018-11-23 12:54:19 --> Helper loaded: common_helper
INFO - 2018-11-23 12:54:19 --> Database Driver Class Initialized
DEBUG - 2018-11-23 12:54:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-23 12:54:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-23 12:54:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-23 12:54:19 --> Pagination Class Initialized
INFO - 2018-11-23 12:54:19 --> Helper loaded: form_helper
INFO - 2018-11-23 12:54:19 --> Form Validation Class Initialized
INFO - 2018-11-23 12:54:19 --> Model Class Initialized
INFO - 2018-11-23 12:54:19 --> Controller Class Initialized
INFO - 2018-11-23 12:54:19 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-23 12:54:19 --> Model Class Initialized
INFO - 2018-11-23 12:54:19 --> Model Class Initialized
INFO - 2018-11-23 12:54:19 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/index.php
INFO - 2018-11-23 12:54:19 --> Final output sent to browser
DEBUG - 2018-11-23 12:54:19 --> Total execution time: 0.0580
INFO - 2018-11-23 12:54:56 --> Config Class Initialized
INFO - 2018-11-23 12:54:56 --> Hooks Class Initialized
DEBUG - 2018-11-23 12:54:56 --> UTF-8 Support Enabled
INFO - 2018-11-23 12:54:56 --> Utf8 Class Initialized
INFO - 2018-11-23 12:54:56 --> URI Class Initialized
INFO - 2018-11-23 12:54:56 --> Router Class Initialized
INFO - 2018-11-23 12:54:56 --> Output Class Initialized
INFO - 2018-11-23 12:54:56 --> Security Class Initialized
DEBUG - 2018-11-23 12:54:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-23 12:54:56 --> Input Class Initialized
INFO - 2018-11-23 12:54:56 --> Language Class Initialized
INFO - 2018-11-23 12:54:56 --> Loader Class Initialized
INFO - 2018-11-23 12:54:56 --> Helper loaded: url_helper
INFO - 2018-11-23 12:54:56 --> Helper loaded: file_helper
INFO - 2018-11-23 12:54:56 --> Helper loaded: email_helper
INFO - 2018-11-23 12:54:56 --> Helper loaded: common_helper
INFO - 2018-11-23 12:54:56 --> Database Driver Class Initialized
DEBUG - 2018-11-23 12:54:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-23 12:54:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-23 12:54:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-23 12:54:56 --> Pagination Class Initialized
INFO - 2018-11-23 12:54:56 --> Helper loaded: form_helper
INFO - 2018-11-23 12:54:56 --> Form Validation Class Initialized
INFO - 2018-11-23 12:54:56 --> Model Class Initialized
INFO - 2018-11-23 12:54:56 --> Controller Class Initialized
INFO - 2018-11-23 12:54:56 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-23 12:54:56 --> Model Class Initialized
INFO - 2018-11-23 12:54:56 --> Model Class Initialized
INFO - 2018-11-23 12:54:56 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/index.php
INFO - 2018-11-23 12:54:56 --> Final output sent to browser
DEBUG - 2018-11-23 12:54:56 --> Total execution time: 0.0540
INFO - 2018-11-23 12:55:07 --> Config Class Initialized
INFO - 2018-11-23 12:55:07 --> Hooks Class Initialized
DEBUG - 2018-11-23 12:55:07 --> UTF-8 Support Enabled
INFO - 2018-11-23 12:55:07 --> Utf8 Class Initialized
INFO - 2018-11-23 12:55:07 --> URI Class Initialized
INFO - 2018-11-23 12:55:07 --> Router Class Initialized
INFO - 2018-11-23 12:55:07 --> Output Class Initialized
INFO - 2018-11-23 12:55:07 --> Security Class Initialized
DEBUG - 2018-11-23 12:55:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-23 12:55:07 --> Input Class Initialized
INFO - 2018-11-23 12:55:07 --> Language Class Initialized
ERROR - 2018-11-23 12:55:07 --> 404 Page Not Found: admin/Admin/forgot_password
INFO - 2018-11-23 12:57:18 --> Config Class Initialized
INFO - 2018-11-23 12:57:18 --> Hooks Class Initialized
DEBUG - 2018-11-23 12:57:18 --> UTF-8 Support Enabled
INFO - 2018-11-23 12:57:18 --> Utf8 Class Initialized
INFO - 2018-11-23 12:57:18 --> URI Class Initialized
INFO - 2018-11-23 12:57:18 --> Router Class Initialized
INFO - 2018-11-23 12:57:18 --> Output Class Initialized
INFO - 2018-11-23 12:57:18 --> Security Class Initialized
DEBUG - 2018-11-23 12:57:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-23 12:57:18 --> Input Class Initialized
INFO - 2018-11-23 12:57:18 --> Language Class Initialized
INFO - 2018-11-23 12:57:18 --> Loader Class Initialized
INFO - 2018-11-23 12:57:18 --> Helper loaded: url_helper
INFO - 2018-11-23 12:57:18 --> Helper loaded: file_helper
INFO - 2018-11-23 12:57:18 --> Helper loaded: email_helper
INFO - 2018-11-23 12:57:18 --> Helper loaded: common_helper
INFO - 2018-11-23 12:57:18 --> Database Driver Class Initialized
DEBUG - 2018-11-23 12:57:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-23 12:57:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-23 12:57:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-23 12:57:18 --> Pagination Class Initialized
INFO - 2018-11-23 12:57:18 --> Helper loaded: form_helper
INFO - 2018-11-23 12:57:18 --> Form Validation Class Initialized
INFO - 2018-11-23 12:57:18 --> Model Class Initialized
INFO - 2018-11-23 12:57:18 --> Controller Class Initialized
INFO - 2018-11-23 12:57:18 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-23 12:57:18 --> Model Class Initialized
INFO - 2018-11-23 12:57:18 --> Model Class Initialized
INFO - 2018-11-23 12:57:18 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/index.php
INFO - 2018-11-23 12:57:18 --> Final output sent to browser
DEBUG - 2018-11-23 12:57:18 --> Total execution time: 0.0700
INFO - 2018-11-23 12:57:20 --> Config Class Initialized
INFO - 2018-11-23 12:57:20 --> Hooks Class Initialized
DEBUG - 2018-11-23 12:57:20 --> UTF-8 Support Enabled
INFO - 2018-11-23 12:57:20 --> Utf8 Class Initialized
INFO - 2018-11-23 12:57:20 --> URI Class Initialized
INFO - 2018-11-23 12:57:20 --> Router Class Initialized
INFO - 2018-11-23 12:57:20 --> Output Class Initialized
INFO - 2018-11-23 12:57:20 --> Security Class Initialized
DEBUG - 2018-11-23 12:57:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-23 12:57:20 --> Input Class Initialized
INFO - 2018-11-23 12:57:20 --> Language Class Initialized
INFO - 2018-11-23 12:57:20 --> Loader Class Initialized
INFO - 2018-11-23 12:57:20 --> Helper loaded: url_helper
INFO - 2018-11-23 12:57:20 --> Helper loaded: file_helper
INFO - 2018-11-23 12:57:20 --> Helper loaded: email_helper
INFO - 2018-11-23 12:57:20 --> Helper loaded: common_helper
INFO - 2018-11-23 12:57:20 --> Database Driver Class Initialized
DEBUG - 2018-11-23 12:57:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-23 12:57:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-23 12:57:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-23 12:57:20 --> Pagination Class Initialized
INFO - 2018-11-23 12:57:20 --> Helper loaded: form_helper
INFO - 2018-11-23 12:57:20 --> Form Validation Class Initialized
INFO - 2018-11-23 12:57:20 --> Model Class Initialized
INFO - 2018-11-23 12:57:20 --> Controller Class Initialized
INFO - 2018-11-23 12:57:20 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-23 12:57:20 --> Model Class Initialized
INFO - 2018-11-23 12:57:20 --> Model Class Initialized
INFO - 2018-11-23 12:57:20 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/index.php
INFO - 2018-11-23 12:57:20 --> Final output sent to browser
DEBUG - 2018-11-23 12:57:20 --> Total execution time: 0.0596
INFO - 2018-11-23 13:00:05 --> Config Class Initialized
INFO - 2018-11-23 13:00:05 --> Hooks Class Initialized
DEBUG - 2018-11-23 13:00:05 --> UTF-8 Support Enabled
INFO - 2018-11-23 13:00:05 --> Utf8 Class Initialized
INFO - 2018-11-23 13:00:05 --> URI Class Initialized
INFO - 2018-11-23 13:00:05 --> Router Class Initialized
INFO - 2018-11-23 13:00:05 --> Output Class Initialized
INFO - 2018-11-23 13:00:05 --> Security Class Initialized
DEBUG - 2018-11-23 13:00:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-23 13:00:05 --> Input Class Initialized
INFO - 2018-11-23 13:00:05 --> Language Class Initialized
INFO - 2018-11-23 13:00:05 --> Loader Class Initialized
INFO - 2018-11-23 13:00:05 --> Helper loaded: url_helper
INFO - 2018-11-23 13:00:05 --> Helper loaded: file_helper
INFO - 2018-11-23 13:00:05 --> Helper loaded: email_helper
INFO - 2018-11-23 13:00:05 --> Helper loaded: common_helper
INFO - 2018-11-23 13:00:05 --> Database Driver Class Initialized
DEBUG - 2018-11-23 13:00:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-23 13:00:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-23 13:00:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-23 13:00:05 --> Pagination Class Initialized
INFO - 2018-11-23 13:00:05 --> Helper loaded: form_helper
INFO - 2018-11-23 13:00:05 --> Form Validation Class Initialized
INFO - 2018-11-23 13:00:05 --> Model Class Initialized
INFO - 2018-11-23 13:00:05 --> Controller Class Initialized
INFO - 2018-11-23 13:00:05 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-23 13:00:05 --> Model Class Initialized
INFO - 2018-11-23 13:00:05 --> Model Class Initialized
INFO - 2018-11-23 13:00:05 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/index.php
INFO - 2018-11-23 13:00:05 --> Final output sent to browser
DEBUG - 2018-11-23 13:00:05 --> Total execution time: 0.0640
INFO - 2018-11-23 13:00:37 --> Config Class Initialized
INFO - 2018-11-23 13:00:37 --> Hooks Class Initialized
DEBUG - 2018-11-23 13:00:37 --> UTF-8 Support Enabled
INFO - 2018-11-23 13:00:37 --> Utf8 Class Initialized
INFO - 2018-11-23 13:00:37 --> URI Class Initialized
INFO - 2018-11-23 13:00:37 --> Router Class Initialized
INFO - 2018-11-23 13:00:37 --> Output Class Initialized
INFO - 2018-11-23 13:00:37 --> Security Class Initialized
DEBUG - 2018-11-23 13:00:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-23 13:00:37 --> Input Class Initialized
INFO - 2018-11-23 13:00:37 --> Language Class Initialized
INFO - 2018-11-23 13:00:37 --> Loader Class Initialized
INFO - 2018-11-23 13:00:37 --> Helper loaded: url_helper
INFO - 2018-11-23 13:00:37 --> Helper loaded: file_helper
INFO - 2018-11-23 13:00:37 --> Helper loaded: email_helper
INFO - 2018-11-23 13:00:37 --> Helper loaded: common_helper
INFO - 2018-11-23 13:00:37 --> Database Driver Class Initialized
DEBUG - 2018-11-23 13:00:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-23 13:00:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-23 13:00:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-23 13:00:37 --> Pagination Class Initialized
INFO - 2018-11-23 13:00:37 --> Helper loaded: form_helper
INFO - 2018-11-23 13:00:37 --> Form Validation Class Initialized
INFO - 2018-11-23 13:00:37 --> Model Class Initialized
INFO - 2018-11-23 13:00:37 --> Controller Class Initialized
INFO - 2018-11-23 13:00:37 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-23 13:00:37 --> Model Class Initialized
INFO - 2018-11-23 13:00:37 --> Model Class Initialized
INFO - 2018-11-23 13:00:37 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/index.php
INFO - 2018-11-23 13:00:37 --> Final output sent to browser
DEBUG - 2018-11-23 13:00:37 --> Total execution time: 0.0510
INFO - 2018-11-23 13:00:40 --> Config Class Initialized
INFO - 2018-11-23 13:00:40 --> Hooks Class Initialized
DEBUG - 2018-11-23 13:00:40 --> UTF-8 Support Enabled
INFO - 2018-11-23 13:00:40 --> Utf8 Class Initialized
INFO - 2018-11-23 13:00:40 --> URI Class Initialized
INFO - 2018-11-23 13:00:40 --> Router Class Initialized
INFO - 2018-11-23 13:00:40 --> Output Class Initialized
INFO - 2018-11-23 13:00:40 --> Security Class Initialized
DEBUG - 2018-11-23 13:00:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-23 13:00:40 --> Input Class Initialized
INFO - 2018-11-23 13:00:40 --> Language Class Initialized
INFO - 2018-11-23 13:00:40 --> Loader Class Initialized
INFO - 2018-11-23 13:00:40 --> Helper loaded: url_helper
INFO - 2018-11-23 13:00:40 --> Helper loaded: file_helper
INFO - 2018-11-23 13:00:40 --> Helper loaded: email_helper
INFO - 2018-11-23 13:00:40 --> Helper loaded: common_helper
INFO - 2018-11-23 13:00:40 --> Database Driver Class Initialized
DEBUG - 2018-11-23 13:00:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-23 13:00:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-23 13:00:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-23 13:00:40 --> Pagination Class Initialized
INFO - 2018-11-23 13:00:40 --> Helper loaded: form_helper
INFO - 2018-11-23 13:00:40 --> Form Validation Class Initialized
INFO - 2018-11-23 13:00:40 --> Model Class Initialized
INFO - 2018-11-23 13:00:40 --> Controller Class Initialized
INFO - 2018-11-23 13:00:40 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-23 13:00:40 --> Model Class Initialized
INFO - 2018-11-23 13:00:40 --> Model Class Initialized
ERROR - 2018-11-23 13:00:40 --> Severity: Notice --> Undefined index: remember_me C:\xampp\htdocs\wetinuneed\application\controllers\admin\Admin.php 77
INFO - 2018-11-23 13:00:40 --> Config Class Initialized
INFO - 2018-11-23 13:00:40 --> Hooks Class Initialized
DEBUG - 2018-11-23 13:00:40 --> UTF-8 Support Enabled
INFO - 2018-11-23 13:00:40 --> Utf8 Class Initialized
INFO - 2018-11-23 13:00:40 --> URI Class Initialized
INFO - 2018-11-23 13:00:40 --> Router Class Initialized
INFO - 2018-11-23 13:00:40 --> Output Class Initialized
INFO - 2018-11-23 13:00:40 --> Security Class Initialized
DEBUG - 2018-11-23 13:00:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-23 13:00:40 --> Input Class Initialized
INFO - 2018-11-23 13:00:40 --> Language Class Initialized
INFO - 2018-11-23 13:00:40 --> Loader Class Initialized
INFO - 2018-11-23 13:00:40 --> Helper loaded: url_helper
INFO - 2018-11-23 13:00:40 --> Helper loaded: file_helper
INFO - 2018-11-23 13:00:40 --> Helper loaded: email_helper
INFO - 2018-11-23 13:00:40 --> Helper loaded: common_helper
INFO - 2018-11-23 13:00:40 --> Database Driver Class Initialized
DEBUG - 2018-11-23 13:00:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-23 13:00:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-23 13:00:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-23 13:00:40 --> Pagination Class Initialized
INFO - 2018-11-23 13:00:40 --> Helper loaded: form_helper
INFO - 2018-11-23 13:00:40 --> Form Validation Class Initialized
INFO - 2018-11-23 13:00:40 --> Model Class Initialized
INFO - 2018-11-23 13:00:40 --> Controller Class Initialized
INFO - 2018-11-23 13:00:40 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-23 13:00:40 --> Model Class Initialized
INFO - 2018-11-23 13:00:40 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-23 13:00:40 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/sidebar.php
INFO - 2018-11-23 13:00:40 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/right-sidebar.php
INFO - 2018-11-23 13:00:40 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/footer.php
INFO - 2018-11-23 13:00:40 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/dashboard.php
INFO - 2018-11-23 13:00:40 --> Final output sent to browser
DEBUG - 2018-11-23 13:00:40 --> Total execution time: 0.0540
INFO - 2018-11-23 13:02:07 --> Config Class Initialized
INFO - 2018-11-23 13:02:07 --> Hooks Class Initialized
DEBUG - 2018-11-23 13:02:07 --> UTF-8 Support Enabled
INFO - 2018-11-23 13:02:07 --> Utf8 Class Initialized
INFO - 2018-11-23 13:02:07 --> URI Class Initialized
INFO - 2018-11-23 13:02:07 --> Router Class Initialized
INFO - 2018-11-23 13:02:07 --> Output Class Initialized
INFO - 2018-11-23 13:02:07 --> Security Class Initialized
DEBUG - 2018-11-23 13:02:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-23 13:02:07 --> Input Class Initialized
INFO - 2018-11-23 13:02:07 --> Language Class Initialized
INFO - 2018-11-23 13:02:07 --> Loader Class Initialized
INFO - 2018-11-23 13:02:07 --> Helper loaded: url_helper
INFO - 2018-11-23 13:02:07 --> Helper loaded: file_helper
INFO - 2018-11-23 13:02:07 --> Helper loaded: email_helper
INFO - 2018-11-23 13:02:07 --> Helper loaded: common_helper
INFO - 2018-11-23 13:02:07 --> Database Driver Class Initialized
DEBUG - 2018-11-23 13:02:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-23 13:02:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-23 13:02:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-23 13:02:07 --> Pagination Class Initialized
INFO - 2018-11-23 13:02:07 --> Helper loaded: form_helper
INFO - 2018-11-23 13:02:07 --> Form Validation Class Initialized
INFO - 2018-11-23 13:02:07 --> Model Class Initialized
INFO - 2018-11-23 13:02:07 --> Controller Class Initialized
INFO - 2018-11-23 13:02:07 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-23 13:02:07 --> Model Class Initialized
INFO - 2018-11-23 13:02:07 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-23 13:02:07 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/sidebar.php
INFO - 2018-11-23 13:02:07 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/right-sidebar.php
INFO - 2018-11-23 13:02:07 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/footer.php
INFO - 2018-11-23 13:02:07 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/dashboard.php
INFO - 2018-11-23 13:02:07 --> Final output sent to browser
DEBUG - 2018-11-23 13:02:07 --> Total execution time: 0.0596
INFO - 2018-11-23 13:03:27 --> Config Class Initialized
INFO - 2018-11-23 13:03:27 --> Hooks Class Initialized
DEBUG - 2018-11-23 13:03:27 --> UTF-8 Support Enabled
INFO - 2018-11-23 13:03:27 --> Utf8 Class Initialized
INFO - 2018-11-23 13:03:27 --> URI Class Initialized
INFO - 2018-11-23 13:03:27 --> Router Class Initialized
INFO - 2018-11-23 13:03:27 --> Output Class Initialized
INFO - 2018-11-23 13:03:27 --> Security Class Initialized
DEBUG - 2018-11-23 13:03:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-23 13:03:27 --> Input Class Initialized
INFO - 2018-11-23 13:03:27 --> Language Class Initialized
INFO - 2018-11-23 13:03:27 --> Loader Class Initialized
INFO - 2018-11-23 13:03:27 --> Helper loaded: url_helper
INFO - 2018-11-23 13:03:27 --> Helper loaded: file_helper
INFO - 2018-11-23 13:03:27 --> Helper loaded: email_helper
INFO - 2018-11-23 13:03:27 --> Helper loaded: common_helper
INFO - 2018-11-23 13:03:27 --> Database Driver Class Initialized
DEBUG - 2018-11-23 13:03:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-23 13:03:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-23 13:03:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-23 13:03:27 --> Pagination Class Initialized
INFO - 2018-11-23 13:03:27 --> Helper loaded: form_helper
INFO - 2018-11-23 13:03:27 --> Form Validation Class Initialized
INFO - 2018-11-23 13:03:27 --> Model Class Initialized
INFO - 2018-11-23 13:03:27 --> Controller Class Initialized
INFO - 2018-11-23 13:03:27 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-23 13:03:27 --> Model Class Initialized
INFO - 2018-11-23 13:03:27 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-23 13:03:27 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/sidebar.php
INFO - 2018-11-23 13:03:27 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/right-sidebar.php
INFO - 2018-11-23 13:03:27 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/footer.php
INFO - 2018-11-23 13:03:27 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/dashboard.php
INFO - 2018-11-23 13:03:27 --> Final output sent to browser
DEBUG - 2018-11-23 13:03:27 --> Total execution time: 0.0540
INFO - 2018-11-23 13:03:49 --> Config Class Initialized
INFO - 2018-11-23 13:03:49 --> Hooks Class Initialized
DEBUG - 2018-11-23 13:03:49 --> UTF-8 Support Enabled
INFO - 2018-11-23 13:03:49 --> Utf8 Class Initialized
INFO - 2018-11-23 13:03:49 --> URI Class Initialized
INFO - 2018-11-23 13:03:49 --> Router Class Initialized
INFO - 2018-11-23 13:03:49 --> Output Class Initialized
INFO - 2018-11-23 13:03:49 --> Security Class Initialized
DEBUG - 2018-11-23 13:03:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-23 13:03:49 --> Input Class Initialized
INFO - 2018-11-23 13:03:49 --> Language Class Initialized
INFO - 2018-11-23 13:03:49 --> Loader Class Initialized
INFO - 2018-11-23 13:03:49 --> Helper loaded: url_helper
INFO - 2018-11-23 13:03:49 --> Helper loaded: file_helper
INFO - 2018-11-23 13:03:49 --> Helper loaded: email_helper
INFO - 2018-11-23 13:03:49 --> Helper loaded: common_helper
INFO - 2018-11-23 13:03:49 --> Database Driver Class Initialized
DEBUG - 2018-11-23 13:03:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-23 13:03:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-23 13:03:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-23 13:03:49 --> Pagination Class Initialized
INFO - 2018-11-23 13:03:49 --> Helper loaded: form_helper
INFO - 2018-11-23 13:03:49 --> Form Validation Class Initialized
INFO - 2018-11-23 13:03:49 --> Model Class Initialized
INFO - 2018-11-23 13:03:49 --> Controller Class Initialized
INFO - 2018-11-23 13:03:49 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-23 13:03:49 --> Model Class Initialized
INFO - 2018-11-23 13:03:49 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-23 13:03:49 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/sidebar.php
INFO - 2018-11-23 13:03:49 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/right-sidebar.php
INFO - 2018-11-23 13:03:49 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/footer.php
INFO - 2018-11-23 13:03:49 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/dashboard.php
INFO - 2018-11-23 13:03:49 --> Final output sent to browser
DEBUG - 2018-11-23 13:03:49 --> Total execution time: 0.0600
INFO - 2018-11-23 13:03:58 --> Config Class Initialized
INFO - 2018-11-23 13:03:58 --> Hooks Class Initialized
DEBUG - 2018-11-23 13:03:58 --> UTF-8 Support Enabled
INFO - 2018-11-23 13:03:58 --> Utf8 Class Initialized
INFO - 2018-11-23 13:03:58 --> URI Class Initialized
INFO - 2018-11-23 13:03:58 --> Router Class Initialized
INFO - 2018-11-23 13:03:58 --> Output Class Initialized
INFO - 2018-11-23 13:03:58 --> Security Class Initialized
DEBUG - 2018-11-23 13:03:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-23 13:03:58 --> Input Class Initialized
INFO - 2018-11-23 13:03:58 --> Language Class Initialized
INFO - 2018-11-23 13:03:58 --> Loader Class Initialized
INFO - 2018-11-23 13:03:58 --> Helper loaded: url_helper
INFO - 2018-11-23 13:03:58 --> Helper loaded: file_helper
INFO - 2018-11-23 13:03:58 --> Helper loaded: email_helper
INFO - 2018-11-23 13:03:58 --> Helper loaded: common_helper
INFO - 2018-11-23 13:03:58 --> Database Driver Class Initialized
DEBUG - 2018-11-23 13:03:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-23 13:03:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-23 13:03:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-23 13:03:58 --> Pagination Class Initialized
INFO - 2018-11-23 13:03:58 --> Helper loaded: form_helper
INFO - 2018-11-23 13:03:58 --> Form Validation Class Initialized
INFO - 2018-11-23 13:03:58 --> Model Class Initialized
INFO - 2018-11-23 13:03:58 --> Controller Class Initialized
INFO - 2018-11-23 13:03:58 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-23 13:03:58 --> Model Class Initialized
INFO - 2018-11-23 13:03:58 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-23 13:03:58 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/sidebar.php
INFO - 2018-11-23 13:03:58 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/right-sidebar.php
INFO - 2018-11-23 13:03:58 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/footer.php
INFO - 2018-11-23 13:03:58 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/dashboard.php
INFO - 2018-11-23 13:03:58 --> Final output sent to browser
DEBUG - 2018-11-23 13:03:58 --> Total execution time: 0.0620
INFO - 2018-11-23 13:04:04 --> Config Class Initialized
INFO - 2018-11-23 13:04:04 --> Hooks Class Initialized
DEBUG - 2018-11-23 13:04:04 --> UTF-8 Support Enabled
INFO - 2018-11-23 13:04:04 --> Utf8 Class Initialized
INFO - 2018-11-23 13:04:04 --> URI Class Initialized
INFO - 2018-11-23 13:04:04 --> Router Class Initialized
INFO - 2018-11-23 13:04:04 --> Output Class Initialized
INFO - 2018-11-23 13:04:04 --> Security Class Initialized
DEBUG - 2018-11-23 13:04:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-23 13:04:04 --> Input Class Initialized
INFO - 2018-11-23 13:04:04 --> Language Class Initialized
INFO - 2018-11-23 13:04:04 --> Loader Class Initialized
INFO - 2018-11-23 13:04:04 --> Helper loaded: url_helper
INFO - 2018-11-23 13:04:04 --> Helper loaded: file_helper
INFO - 2018-11-23 13:04:04 --> Helper loaded: email_helper
INFO - 2018-11-23 13:04:04 --> Helper loaded: common_helper
INFO - 2018-11-23 13:04:04 --> Database Driver Class Initialized
DEBUG - 2018-11-23 13:04:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-23 13:04:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-23 13:04:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-23 13:04:04 --> Pagination Class Initialized
INFO - 2018-11-23 13:04:04 --> Helper loaded: form_helper
INFO - 2018-11-23 13:04:04 --> Form Validation Class Initialized
INFO - 2018-11-23 13:04:04 --> Model Class Initialized
INFO - 2018-11-23 13:04:04 --> Controller Class Initialized
INFO - 2018-11-23 13:04:04 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-23 13:04:04 --> Model Class Initialized
INFO - 2018-11-23 13:04:04 --> Model Class Initialized
INFO - 2018-11-23 13:04:04 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-23 13:04:04 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/change-password.php
INFO - 2018-11-23 13:04:04 --> Final output sent to browser
DEBUG - 2018-11-23 13:04:04 --> Total execution time: 0.0560
INFO - 2018-11-23 13:10:16 --> Config Class Initialized
INFO - 2018-11-23 13:10:16 --> Hooks Class Initialized
DEBUG - 2018-11-23 13:10:16 --> UTF-8 Support Enabled
INFO - 2018-11-23 13:10:16 --> Utf8 Class Initialized
INFO - 2018-11-23 13:10:16 --> URI Class Initialized
INFO - 2018-11-23 13:10:16 --> Router Class Initialized
INFO - 2018-11-23 13:10:16 --> Output Class Initialized
INFO - 2018-11-23 13:10:16 --> Security Class Initialized
DEBUG - 2018-11-23 13:10:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-23 13:10:16 --> Input Class Initialized
INFO - 2018-11-23 13:10:16 --> Language Class Initialized
INFO - 2018-11-23 13:10:16 --> Loader Class Initialized
INFO - 2018-11-23 13:10:16 --> Helper loaded: url_helper
INFO - 2018-11-23 13:10:16 --> Helper loaded: file_helper
INFO - 2018-11-23 13:10:16 --> Helper loaded: email_helper
INFO - 2018-11-23 13:10:16 --> Helper loaded: common_helper
INFO - 2018-11-23 13:10:16 --> Database Driver Class Initialized
DEBUG - 2018-11-23 13:10:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-23 13:10:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-23 13:10:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-23 13:10:16 --> Pagination Class Initialized
INFO - 2018-11-23 13:10:16 --> Helper loaded: form_helper
INFO - 2018-11-23 13:10:16 --> Form Validation Class Initialized
INFO - 2018-11-23 13:10:16 --> Model Class Initialized
INFO - 2018-11-23 13:10:16 --> Controller Class Initialized
INFO - 2018-11-23 13:10:16 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-23 13:10:16 --> Model Class Initialized
INFO - 2018-11-23 13:10:16 --> Model Class Initialized
INFO - 2018-11-23 13:10:16 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-23 13:10:16 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/change-password.php
INFO - 2018-11-23 13:10:16 --> Final output sent to browser
DEBUG - 2018-11-23 13:10:16 --> Total execution time: 0.1620
INFO - 2018-11-23 13:27:12 --> Config Class Initialized
INFO - 2018-11-23 13:27:12 --> Hooks Class Initialized
DEBUG - 2018-11-23 13:27:12 --> UTF-8 Support Enabled
INFO - 2018-11-23 13:27:12 --> Utf8 Class Initialized
INFO - 2018-11-23 13:27:12 --> URI Class Initialized
INFO - 2018-11-23 13:27:12 --> Router Class Initialized
INFO - 2018-11-23 13:27:12 --> Output Class Initialized
INFO - 2018-11-23 13:27:12 --> Security Class Initialized
DEBUG - 2018-11-23 13:27:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-23 13:27:12 --> Input Class Initialized
INFO - 2018-11-23 13:27:12 --> Language Class Initialized
INFO - 2018-11-23 13:27:12 --> Loader Class Initialized
INFO - 2018-11-23 13:27:12 --> Helper loaded: url_helper
INFO - 2018-11-23 13:27:12 --> Helper loaded: file_helper
INFO - 2018-11-23 13:27:12 --> Helper loaded: email_helper
INFO - 2018-11-23 13:27:12 --> Helper loaded: common_helper
INFO - 2018-11-23 13:27:12 --> Database Driver Class Initialized
DEBUG - 2018-11-23 13:27:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-23 13:27:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-23 13:27:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-23 13:27:12 --> Pagination Class Initialized
INFO - 2018-11-23 13:27:12 --> Helper loaded: form_helper
INFO - 2018-11-23 13:27:12 --> Form Validation Class Initialized
INFO - 2018-11-23 13:27:12 --> Model Class Initialized
INFO - 2018-11-23 13:27:12 --> Controller Class Initialized
INFO - 2018-11-23 13:27:12 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-23 13:27:12 --> Model Class Initialized
INFO - 2018-11-23 13:27:12 --> Model Class Initialized
INFO - 2018-11-23 13:27:12 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-23 13:27:12 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/change-password.php
INFO - 2018-11-23 13:27:12 --> Final output sent to browser
DEBUG - 2018-11-23 13:27:12 --> Total execution time: 0.0630
INFO - 2018-11-23 13:41:30 --> Config Class Initialized
INFO - 2018-11-23 13:41:30 --> Hooks Class Initialized
DEBUG - 2018-11-23 13:41:30 --> UTF-8 Support Enabled
INFO - 2018-11-23 13:41:30 --> Utf8 Class Initialized
INFO - 2018-11-23 13:41:30 --> URI Class Initialized
INFO - 2018-11-23 13:41:30 --> Router Class Initialized
INFO - 2018-11-23 13:41:30 --> Output Class Initialized
INFO - 2018-11-23 13:41:30 --> Security Class Initialized
DEBUG - 2018-11-23 13:41:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-23 13:41:30 --> Input Class Initialized
INFO - 2018-11-23 13:41:30 --> Language Class Initialized
INFO - 2018-11-23 13:41:30 --> Loader Class Initialized
INFO - 2018-11-23 13:41:30 --> Helper loaded: url_helper
INFO - 2018-11-23 13:41:30 --> Helper loaded: file_helper
INFO - 2018-11-23 13:41:30 --> Helper loaded: email_helper
INFO - 2018-11-23 13:41:30 --> Helper loaded: common_helper
INFO - 2018-11-23 13:41:30 --> Database Driver Class Initialized
DEBUG - 2018-11-23 13:41:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-23 13:41:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-23 13:41:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-23 13:41:30 --> Pagination Class Initialized
INFO - 2018-11-23 13:41:30 --> Helper loaded: form_helper
INFO - 2018-11-23 13:41:30 --> Form Validation Class Initialized
INFO - 2018-11-23 13:41:30 --> Model Class Initialized
INFO - 2018-11-23 13:41:30 --> Controller Class Initialized
INFO - 2018-11-23 13:41:30 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-23 13:41:30 --> Model Class Initialized
INFO - 2018-11-23 13:41:30 --> Model Class Initialized
INFO - 2018-11-23 13:41:30 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-23 13:41:30 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/change-password.php
INFO - 2018-11-23 13:41:30 --> Final output sent to browser
DEBUG - 2018-11-23 13:41:30 --> Total execution time: 0.0530
INFO - 2018-11-23 13:44:59 --> Config Class Initialized
INFO - 2018-11-23 13:44:59 --> Hooks Class Initialized
DEBUG - 2018-11-23 13:44:59 --> UTF-8 Support Enabled
INFO - 2018-11-23 13:44:59 --> Utf8 Class Initialized
INFO - 2018-11-23 13:44:59 --> URI Class Initialized
INFO - 2018-11-23 13:44:59 --> Router Class Initialized
INFO - 2018-11-23 13:44:59 --> Output Class Initialized
INFO - 2018-11-23 13:44:59 --> Security Class Initialized
DEBUG - 2018-11-23 13:44:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-23 13:44:59 --> Input Class Initialized
INFO - 2018-11-23 13:44:59 --> Language Class Initialized
INFO - 2018-11-23 13:44:59 --> Loader Class Initialized
INFO - 2018-11-23 13:44:59 --> Helper loaded: url_helper
INFO - 2018-11-23 13:44:59 --> Helper loaded: file_helper
INFO - 2018-11-23 13:44:59 --> Helper loaded: email_helper
INFO - 2018-11-23 13:44:59 --> Helper loaded: common_helper
INFO - 2018-11-23 13:44:59 --> Database Driver Class Initialized
DEBUG - 2018-11-23 13:44:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-23 13:44:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-23 13:44:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-23 13:44:59 --> Pagination Class Initialized
INFO - 2018-11-23 13:44:59 --> Helper loaded: form_helper
INFO - 2018-11-23 13:44:59 --> Form Validation Class Initialized
INFO - 2018-11-23 13:44:59 --> Model Class Initialized
INFO - 2018-11-23 13:44:59 --> Controller Class Initialized
INFO - 2018-11-23 13:44:59 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-23 13:44:59 --> Model Class Initialized
INFO - 2018-11-23 13:44:59 --> Model Class Initialized
INFO - 2018-11-23 13:44:59 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-23 13:44:59 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/change-password.php
INFO - 2018-11-23 13:44:59 --> Final output sent to browser
DEBUG - 2018-11-23 13:44:59 --> Total execution time: 0.0470
INFO - 2018-11-23 13:45:14 --> Config Class Initialized
INFO - 2018-11-23 13:45:14 --> Hooks Class Initialized
DEBUG - 2018-11-23 13:45:14 --> UTF-8 Support Enabled
INFO - 2018-11-23 13:45:14 --> Utf8 Class Initialized
INFO - 2018-11-23 13:45:14 --> URI Class Initialized
INFO - 2018-11-23 13:45:14 --> Router Class Initialized
INFO - 2018-11-23 13:45:14 --> Output Class Initialized
INFO - 2018-11-23 13:45:14 --> Security Class Initialized
DEBUG - 2018-11-23 13:45:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-23 13:45:14 --> Input Class Initialized
INFO - 2018-11-23 13:45:14 --> Language Class Initialized
INFO - 2018-11-23 13:45:14 --> Loader Class Initialized
INFO - 2018-11-23 13:45:14 --> Helper loaded: url_helper
INFO - 2018-11-23 13:45:14 --> Helper loaded: file_helper
INFO - 2018-11-23 13:45:14 --> Helper loaded: email_helper
INFO - 2018-11-23 13:45:14 --> Helper loaded: common_helper
INFO - 2018-11-23 13:45:14 --> Database Driver Class Initialized
DEBUG - 2018-11-23 13:45:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-23 13:45:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-23 13:45:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-23 13:45:14 --> Pagination Class Initialized
INFO - 2018-11-23 13:45:14 --> Helper loaded: form_helper
INFO - 2018-11-23 13:45:14 --> Form Validation Class Initialized
INFO - 2018-11-23 13:45:14 --> Model Class Initialized
INFO - 2018-11-23 13:45:14 --> Controller Class Initialized
INFO - 2018-11-23 13:45:14 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-23 13:45:14 --> Model Class Initialized
INFO - 2018-11-23 13:45:14 --> Model Class Initialized
INFO - 2018-11-23 13:45:14 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-23 13:45:14 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/change-password.php
INFO - 2018-11-23 13:45:14 --> Final output sent to browser
DEBUG - 2018-11-23 13:45:14 --> Total execution time: 0.0560
INFO - 2018-11-23 13:45:43 --> Config Class Initialized
INFO - 2018-11-23 13:45:43 --> Hooks Class Initialized
DEBUG - 2018-11-23 13:45:43 --> UTF-8 Support Enabled
INFO - 2018-11-23 13:45:43 --> Utf8 Class Initialized
INFO - 2018-11-23 13:45:43 --> URI Class Initialized
INFO - 2018-11-23 13:45:43 --> Router Class Initialized
INFO - 2018-11-23 13:45:43 --> Output Class Initialized
INFO - 2018-11-23 13:45:43 --> Security Class Initialized
DEBUG - 2018-11-23 13:45:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-23 13:45:43 --> Input Class Initialized
INFO - 2018-11-23 13:45:43 --> Language Class Initialized
INFO - 2018-11-23 13:45:43 --> Loader Class Initialized
INFO - 2018-11-23 13:45:43 --> Helper loaded: url_helper
INFO - 2018-11-23 13:45:43 --> Helper loaded: file_helper
INFO - 2018-11-23 13:45:43 --> Helper loaded: email_helper
INFO - 2018-11-23 13:45:43 --> Helper loaded: common_helper
INFO - 2018-11-23 13:45:43 --> Database Driver Class Initialized
DEBUG - 2018-11-23 13:45:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-23 13:45:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-23 13:45:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-23 13:45:43 --> Pagination Class Initialized
INFO - 2018-11-23 13:45:43 --> Helper loaded: form_helper
INFO - 2018-11-23 13:45:43 --> Form Validation Class Initialized
INFO - 2018-11-23 13:45:43 --> Model Class Initialized
INFO - 2018-11-23 13:45:43 --> Controller Class Initialized
INFO - 2018-11-23 13:45:43 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-23 13:45:43 --> Model Class Initialized
INFO - 2018-11-23 13:45:43 --> Model Class Initialized
INFO - 2018-11-23 13:45:43 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-23 13:45:43 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/change-password.php
INFO - 2018-11-23 13:45:43 --> Final output sent to browser
DEBUG - 2018-11-23 13:45:43 --> Total execution time: 0.0616
INFO - 2018-11-23 13:46:30 --> Config Class Initialized
INFO - 2018-11-23 13:46:30 --> Hooks Class Initialized
DEBUG - 2018-11-23 13:46:30 --> UTF-8 Support Enabled
INFO - 2018-11-23 13:46:30 --> Utf8 Class Initialized
INFO - 2018-11-23 13:46:30 --> URI Class Initialized
INFO - 2018-11-23 13:46:30 --> Router Class Initialized
INFO - 2018-11-23 13:46:30 --> Output Class Initialized
INFO - 2018-11-23 13:46:30 --> Security Class Initialized
DEBUG - 2018-11-23 13:46:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-23 13:46:30 --> Input Class Initialized
INFO - 2018-11-23 13:46:30 --> Language Class Initialized
INFO - 2018-11-23 13:46:30 --> Loader Class Initialized
INFO - 2018-11-23 13:46:30 --> Helper loaded: url_helper
INFO - 2018-11-23 13:46:30 --> Helper loaded: file_helper
INFO - 2018-11-23 13:46:30 --> Helper loaded: email_helper
INFO - 2018-11-23 13:46:30 --> Helper loaded: common_helper
INFO - 2018-11-23 13:46:30 --> Database Driver Class Initialized
DEBUG - 2018-11-23 13:46:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-23 13:46:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-23 13:46:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-23 13:46:30 --> Pagination Class Initialized
INFO - 2018-11-23 13:46:30 --> Helper loaded: form_helper
INFO - 2018-11-23 13:46:30 --> Form Validation Class Initialized
INFO - 2018-11-23 13:46:30 --> Model Class Initialized
INFO - 2018-11-23 13:46:30 --> Controller Class Initialized
INFO - 2018-11-23 13:46:30 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-23 13:46:30 --> Model Class Initialized
INFO - 2018-11-23 13:46:30 --> Model Class Initialized
INFO - 2018-11-23 13:46:30 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-23 13:46:30 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/change-password.php
INFO - 2018-11-23 13:46:30 --> Final output sent to browser
DEBUG - 2018-11-23 13:46:30 --> Total execution time: 0.0786
INFO - 2018-11-23 13:46:40 --> Config Class Initialized
INFO - 2018-11-23 13:46:40 --> Hooks Class Initialized
DEBUG - 2018-11-23 13:46:40 --> UTF-8 Support Enabled
INFO - 2018-11-23 13:46:40 --> Utf8 Class Initialized
INFO - 2018-11-23 13:46:40 --> URI Class Initialized
INFO - 2018-11-23 13:46:40 --> Router Class Initialized
INFO - 2018-11-23 13:46:40 --> Output Class Initialized
INFO - 2018-11-23 13:46:40 --> Security Class Initialized
DEBUG - 2018-11-23 13:46:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-23 13:46:40 --> Input Class Initialized
INFO - 2018-11-23 13:46:40 --> Language Class Initialized
INFO - 2018-11-23 13:46:40 --> Loader Class Initialized
INFO - 2018-11-23 13:46:40 --> Helper loaded: url_helper
INFO - 2018-11-23 13:46:40 --> Helper loaded: file_helper
INFO - 2018-11-23 13:46:40 --> Helper loaded: email_helper
INFO - 2018-11-23 13:46:40 --> Helper loaded: common_helper
INFO - 2018-11-23 13:46:40 --> Database Driver Class Initialized
DEBUG - 2018-11-23 13:46:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-23 13:46:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-23 13:46:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-23 13:46:40 --> Pagination Class Initialized
INFO - 2018-11-23 13:46:40 --> Helper loaded: form_helper
INFO - 2018-11-23 13:46:40 --> Form Validation Class Initialized
INFO - 2018-11-23 13:46:40 --> Model Class Initialized
INFO - 2018-11-23 13:46:40 --> Controller Class Initialized
INFO - 2018-11-23 13:46:40 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-23 13:46:40 --> Model Class Initialized
INFO - 2018-11-23 13:46:40 --> Model Class Initialized
INFO - 2018-11-23 13:46:40 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-23 13:46:40 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/change-password.php
INFO - 2018-11-23 13:46:40 --> Final output sent to browser
DEBUG - 2018-11-23 13:46:40 --> Total execution time: 0.0510
INFO - 2018-11-23 13:46:52 --> Config Class Initialized
INFO - 2018-11-23 13:46:52 --> Hooks Class Initialized
DEBUG - 2018-11-23 13:46:52 --> UTF-8 Support Enabled
INFO - 2018-11-23 13:46:52 --> Utf8 Class Initialized
INFO - 2018-11-23 13:46:52 --> URI Class Initialized
INFO - 2018-11-23 13:46:52 --> Router Class Initialized
INFO - 2018-11-23 13:46:52 --> Output Class Initialized
INFO - 2018-11-23 13:46:52 --> Security Class Initialized
DEBUG - 2018-11-23 13:46:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-23 13:46:52 --> Input Class Initialized
INFO - 2018-11-23 13:46:52 --> Language Class Initialized
INFO - 2018-11-23 13:46:52 --> Loader Class Initialized
INFO - 2018-11-23 13:46:52 --> Helper loaded: url_helper
INFO - 2018-11-23 13:46:52 --> Helper loaded: file_helper
INFO - 2018-11-23 13:46:52 --> Helper loaded: email_helper
INFO - 2018-11-23 13:46:52 --> Helper loaded: common_helper
INFO - 2018-11-23 13:46:52 --> Database Driver Class Initialized
DEBUG - 2018-11-23 13:46:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-23 13:46:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-23 13:46:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-23 13:46:52 --> Pagination Class Initialized
INFO - 2018-11-23 13:46:52 --> Helper loaded: form_helper
INFO - 2018-11-23 13:46:52 --> Form Validation Class Initialized
INFO - 2018-11-23 13:46:52 --> Model Class Initialized
INFO - 2018-11-23 13:46:52 --> Controller Class Initialized
INFO - 2018-11-23 13:46:52 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-23 13:46:52 --> Model Class Initialized
INFO - 2018-11-23 13:46:52 --> Model Class Initialized
INFO - 2018-11-23 13:46:52 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-23 13:46:52 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/change-password.php
INFO - 2018-11-23 13:46:52 --> Final output sent to browser
DEBUG - 2018-11-23 13:46:52 --> Total execution time: 0.0586
INFO - 2018-11-23 13:47:05 --> Config Class Initialized
INFO - 2018-11-23 13:47:05 --> Hooks Class Initialized
DEBUG - 2018-11-23 13:47:05 --> UTF-8 Support Enabled
INFO - 2018-11-23 13:47:05 --> Utf8 Class Initialized
INFO - 2018-11-23 13:47:05 --> URI Class Initialized
INFO - 2018-11-23 13:47:05 --> Router Class Initialized
INFO - 2018-11-23 13:47:05 --> Output Class Initialized
INFO - 2018-11-23 13:47:05 --> Security Class Initialized
DEBUG - 2018-11-23 13:47:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-23 13:47:05 --> Input Class Initialized
INFO - 2018-11-23 13:47:05 --> Language Class Initialized
INFO - 2018-11-23 13:47:05 --> Loader Class Initialized
INFO - 2018-11-23 13:47:05 --> Helper loaded: url_helper
INFO - 2018-11-23 13:47:05 --> Helper loaded: file_helper
INFO - 2018-11-23 13:47:05 --> Helper loaded: email_helper
INFO - 2018-11-23 13:47:05 --> Helper loaded: common_helper
INFO - 2018-11-23 13:47:05 --> Database Driver Class Initialized
DEBUG - 2018-11-23 13:47:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-23 13:47:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-23 13:47:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-23 13:47:05 --> Pagination Class Initialized
INFO - 2018-11-23 13:47:05 --> Helper loaded: form_helper
INFO - 2018-11-23 13:47:05 --> Form Validation Class Initialized
INFO - 2018-11-23 13:47:05 --> Model Class Initialized
INFO - 2018-11-23 13:47:05 --> Controller Class Initialized
INFO - 2018-11-23 13:47:05 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-23 13:47:05 --> Model Class Initialized
INFO - 2018-11-23 13:47:05 --> Model Class Initialized
INFO - 2018-11-23 13:47:05 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-23 13:47:05 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/change-password.php
INFO - 2018-11-23 13:47:05 --> Final output sent to browser
DEBUG - 2018-11-23 13:47:05 --> Total execution time: 0.0570
INFO - 2018-11-23 13:51:52 --> Config Class Initialized
INFO - 2018-11-23 13:51:52 --> Hooks Class Initialized
DEBUG - 2018-11-23 13:51:52 --> UTF-8 Support Enabled
INFO - 2018-11-23 13:51:52 --> Utf8 Class Initialized
INFO - 2018-11-23 13:51:52 --> URI Class Initialized
INFO - 2018-11-23 13:51:52 --> Router Class Initialized
INFO - 2018-11-23 13:51:52 --> Output Class Initialized
INFO - 2018-11-23 13:51:52 --> Security Class Initialized
DEBUG - 2018-11-23 13:51:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-23 13:51:52 --> Input Class Initialized
INFO - 2018-11-23 13:51:52 --> Language Class Initialized
INFO - 2018-11-23 13:51:52 --> Loader Class Initialized
INFO - 2018-11-23 13:51:52 --> Helper loaded: url_helper
INFO - 2018-11-23 13:51:52 --> Helper loaded: file_helper
INFO - 2018-11-23 13:51:52 --> Helper loaded: email_helper
INFO - 2018-11-23 13:51:52 --> Helper loaded: common_helper
INFO - 2018-11-23 13:51:52 --> Database Driver Class Initialized
DEBUG - 2018-11-23 13:51:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-23 13:51:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-23 13:51:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-23 13:51:52 --> Pagination Class Initialized
INFO - 2018-11-23 13:51:52 --> Helper loaded: form_helper
INFO - 2018-11-23 13:51:52 --> Form Validation Class Initialized
INFO - 2018-11-23 13:51:52 --> Model Class Initialized
INFO - 2018-11-23 13:51:52 --> Controller Class Initialized
INFO - 2018-11-23 13:51:52 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-23 13:51:52 --> Model Class Initialized
INFO - 2018-11-23 13:51:52 --> Model Class Initialized
INFO - 2018-11-23 13:51:52 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-23 13:51:52 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/change-password.php
INFO - 2018-11-23 13:51:52 --> Final output sent to browser
DEBUG - 2018-11-23 13:51:52 --> Total execution time: 0.0520
INFO - 2018-11-23 13:52:54 --> Config Class Initialized
INFO - 2018-11-23 13:52:54 --> Hooks Class Initialized
DEBUG - 2018-11-23 13:52:54 --> UTF-8 Support Enabled
INFO - 2018-11-23 13:52:54 --> Utf8 Class Initialized
INFO - 2018-11-23 13:52:54 --> URI Class Initialized
INFO - 2018-11-23 13:52:54 --> Router Class Initialized
INFO - 2018-11-23 13:52:54 --> Output Class Initialized
INFO - 2018-11-23 13:52:54 --> Security Class Initialized
DEBUG - 2018-11-23 13:52:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-23 13:52:54 --> Input Class Initialized
INFO - 2018-11-23 13:52:54 --> Language Class Initialized
INFO - 2018-11-23 13:52:54 --> Loader Class Initialized
INFO - 2018-11-23 13:52:54 --> Helper loaded: url_helper
INFO - 2018-11-23 13:52:54 --> Helper loaded: file_helper
INFO - 2018-11-23 13:52:54 --> Helper loaded: email_helper
INFO - 2018-11-23 13:52:54 --> Helper loaded: common_helper
INFO - 2018-11-23 13:52:54 --> Database Driver Class Initialized
DEBUG - 2018-11-23 13:52:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-23 13:52:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-23 13:52:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-23 13:52:54 --> Pagination Class Initialized
INFO - 2018-11-23 13:52:54 --> Helper loaded: form_helper
INFO - 2018-11-23 13:52:54 --> Form Validation Class Initialized
INFO - 2018-11-23 13:52:54 --> Model Class Initialized
INFO - 2018-11-23 13:52:54 --> Controller Class Initialized
INFO - 2018-11-23 13:52:54 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-23 13:52:54 --> Model Class Initialized
INFO - 2018-11-23 13:52:54 --> Model Class Initialized
INFO - 2018-11-23 13:52:54 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-23 13:52:54 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/change-password.php
INFO - 2018-11-23 13:52:54 --> Final output sent to browser
DEBUG - 2018-11-23 13:52:54 --> Total execution time: 0.0440
INFO - 2018-11-23 13:53:15 --> Config Class Initialized
INFO - 2018-11-23 13:53:15 --> Hooks Class Initialized
DEBUG - 2018-11-23 13:53:15 --> UTF-8 Support Enabled
INFO - 2018-11-23 13:53:15 --> Utf8 Class Initialized
INFO - 2018-11-23 13:53:15 --> URI Class Initialized
INFO - 2018-11-23 13:53:15 --> Router Class Initialized
INFO - 2018-11-23 13:53:15 --> Output Class Initialized
INFO - 2018-11-23 13:53:15 --> Security Class Initialized
DEBUG - 2018-11-23 13:53:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-23 13:53:15 --> Input Class Initialized
INFO - 2018-11-23 13:53:15 --> Language Class Initialized
INFO - 2018-11-23 13:53:15 --> Loader Class Initialized
INFO - 2018-11-23 13:53:15 --> Helper loaded: url_helper
INFO - 2018-11-23 13:53:15 --> Helper loaded: file_helper
INFO - 2018-11-23 13:53:15 --> Helper loaded: email_helper
INFO - 2018-11-23 13:53:15 --> Helper loaded: common_helper
INFO - 2018-11-23 13:53:15 --> Database Driver Class Initialized
DEBUG - 2018-11-23 13:53:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-23 13:53:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-23 13:53:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-23 13:53:15 --> Pagination Class Initialized
INFO - 2018-11-23 13:53:15 --> Helper loaded: form_helper
INFO - 2018-11-23 13:53:15 --> Form Validation Class Initialized
INFO - 2018-11-23 13:53:15 --> Model Class Initialized
INFO - 2018-11-23 13:53:15 --> Controller Class Initialized
INFO - 2018-11-23 13:53:15 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-23 13:53:15 --> Model Class Initialized
INFO - 2018-11-23 13:53:15 --> Model Class Initialized
INFO - 2018-11-23 13:53:15 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-23 13:53:15 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/change-password.php
INFO - 2018-11-23 13:53:15 --> Final output sent to browser
DEBUG - 2018-11-23 13:53:15 --> Total execution time: 0.0620
INFO - 2018-11-23 13:54:36 --> Config Class Initialized
INFO - 2018-11-23 13:54:36 --> Hooks Class Initialized
DEBUG - 2018-11-23 13:54:36 --> UTF-8 Support Enabled
INFO - 2018-11-23 13:54:36 --> Utf8 Class Initialized
INFO - 2018-11-23 13:54:36 --> URI Class Initialized
INFO - 2018-11-23 13:54:36 --> Router Class Initialized
INFO - 2018-11-23 13:54:36 --> Output Class Initialized
INFO - 2018-11-23 13:54:36 --> Security Class Initialized
DEBUG - 2018-11-23 13:54:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-23 13:54:36 --> Input Class Initialized
INFO - 2018-11-23 13:54:36 --> Language Class Initialized
INFO - 2018-11-23 13:54:36 --> Loader Class Initialized
INFO - 2018-11-23 13:54:36 --> Helper loaded: url_helper
INFO - 2018-11-23 13:54:36 --> Helper loaded: file_helper
INFO - 2018-11-23 13:54:36 --> Helper loaded: email_helper
INFO - 2018-11-23 13:54:36 --> Helper loaded: common_helper
INFO - 2018-11-23 13:54:36 --> Database Driver Class Initialized
DEBUG - 2018-11-23 13:54:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-23 13:54:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-23 13:54:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-23 13:54:36 --> Pagination Class Initialized
INFO - 2018-11-23 13:54:36 --> Helper loaded: form_helper
INFO - 2018-11-23 13:54:36 --> Form Validation Class Initialized
INFO - 2018-11-23 13:54:36 --> Model Class Initialized
INFO - 2018-11-23 13:54:36 --> Controller Class Initialized
INFO - 2018-11-23 13:54:36 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-23 13:54:36 --> Model Class Initialized
INFO - 2018-11-23 13:54:36 --> Model Class Initialized
INFO - 2018-11-23 13:54:36 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-23 13:54:36 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/change-password.php
INFO - 2018-11-23 13:54:36 --> Final output sent to browser
DEBUG - 2018-11-23 13:54:36 --> Total execution time: 0.0600
INFO - 2018-11-23 13:56:00 --> Config Class Initialized
INFO - 2018-11-23 13:56:00 --> Hooks Class Initialized
DEBUG - 2018-11-23 13:56:00 --> UTF-8 Support Enabled
INFO - 2018-11-23 13:56:00 --> Utf8 Class Initialized
INFO - 2018-11-23 13:56:00 --> URI Class Initialized
INFO - 2018-11-23 13:56:00 --> Router Class Initialized
INFO - 2018-11-23 13:56:00 --> Output Class Initialized
INFO - 2018-11-23 13:56:00 --> Security Class Initialized
DEBUG - 2018-11-23 13:56:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-23 13:56:00 --> Input Class Initialized
INFO - 2018-11-23 13:56:00 --> Language Class Initialized
INFO - 2018-11-23 13:56:00 --> Loader Class Initialized
INFO - 2018-11-23 13:56:00 --> Helper loaded: url_helper
INFO - 2018-11-23 13:56:00 --> Helper loaded: file_helper
INFO - 2018-11-23 13:56:00 --> Helper loaded: email_helper
INFO - 2018-11-23 13:56:00 --> Helper loaded: common_helper
INFO - 2018-11-23 13:56:00 --> Database Driver Class Initialized
DEBUG - 2018-11-23 13:56:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-23 13:56:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-23 13:56:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-23 13:56:00 --> Pagination Class Initialized
INFO - 2018-11-23 13:56:00 --> Helper loaded: form_helper
INFO - 2018-11-23 13:56:00 --> Form Validation Class Initialized
INFO - 2018-11-23 13:56:00 --> Model Class Initialized
INFO - 2018-11-23 13:56:00 --> Controller Class Initialized
INFO - 2018-11-23 13:56:00 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-23 13:56:00 --> Model Class Initialized
INFO - 2018-11-23 13:56:00 --> Model Class Initialized
INFO - 2018-11-23 13:56:00 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-23 13:56:00 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/change-password.php
INFO - 2018-11-23 13:56:00 --> Final output sent to browser
DEBUG - 2018-11-23 13:56:00 --> Total execution time: 0.0470
INFO - 2018-11-23 14:01:23 --> Config Class Initialized
INFO - 2018-11-23 14:01:23 --> Hooks Class Initialized
DEBUG - 2018-11-23 14:01:23 --> UTF-8 Support Enabled
INFO - 2018-11-23 14:01:23 --> Utf8 Class Initialized
INFO - 2018-11-23 14:01:23 --> URI Class Initialized
INFO - 2018-11-23 14:01:23 --> Router Class Initialized
INFO - 2018-11-23 14:01:23 --> Output Class Initialized
INFO - 2018-11-23 14:01:23 --> Security Class Initialized
DEBUG - 2018-11-23 14:01:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-23 14:01:23 --> Input Class Initialized
INFO - 2018-11-23 14:01:23 --> Language Class Initialized
INFO - 2018-11-23 14:01:23 --> Loader Class Initialized
INFO - 2018-11-23 14:01:23 --> Helper loaded: url_helper
INFO - 2018-11-23 14:01:23 --> Helper loaded: file_helper
INFO - 2018-11-23 14:01:23 --> Helper loaded: email_helper
INFO - 2018-11-23 14:01:23 --> Helper loaded: common_helper
INFO - 2018-11-23 14:01:23 --> Database Driver Class Initialized
DEBUG - 2018-11-23 14:01:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-23 14:01:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-23 14:01:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-23 14:01:23 --> Pagination Class Initialized
INFO - 2018-11-23 14:01:23 --> Helper loaded: form_helper
INFO - 2018-11-23 14:01:23 --> Form Validation Class Initialized
INFO - 2018-11-23 14:01:23 --> Model Class Initialized
INFO - 2018-11-23 14:01:23 --> Controller Class Initialized
INFO - 2018-11-23 14:01:23 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-23 14:01:23 --> Model Class Initialized
INFO - 2018-11-23 14:01:23 --> Model Class Initialized
INFO - 2018-11-23 14:01:23 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-23 14:01:23 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/change-password.php
INFO - 2018-11-23 14:01:23 --> Final output sent to browser
DEBUG - 2018-11-23 14:01:23 --> Total execution time: 0.0490
INFO - 2018-11-23 14:01:24 --> Config Class Initialized
INFO - 2018-11-23 14:01:24 --> Hooks Class Initialized
DEBUG - 2018-11-23 14:01:24 --> UTF-8 Support Enabled
INFO - 2018-11-23 14:01:24 --> Utf8 Class Initialized
INFO - 2018-11-23 14:01:24 --> URI Class Initialized
INFO - 2018-11-23 14:01:24 --> Router Class Initialized
INFO - 2018-11-23 14:01:24 --> Output Class Initialized
INFO - 2018-11-23 14:01:24 --> Security Class Initialized
DEBUG - 2018-11-23 14:01:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-23 14:01:24 --> Input Class Initialized
INFO - 2018-11-23 14:01:24 --> Language Class Initialized
ERROR - 2018-11-23 14:01:24 --> 404 Page Not Found: Plugins/images
INFO - 2018-11-23 14:02:27 --> Config Class Initialized
INFO - 2018-11-23 14:02:27 --> Hooks Class Initialized
DEBUG - 2018-11-23 14:02:27 --> UTF-8 Support Enabled
INFO - 2018-11-23 14:02:27 --> Utf8 Class Initialized
INFO - 2018-11-23 14:02:27 --> URI Class Initialized
INFO - 2018-11-23 14:02:27 --> Router Class Initialized
INFO - 2018-11-23 14:02:27 --> Output Class Initialized
INFO - 2018-11-23 14:02:27 --> Security Class Initialized
DEBUG - 2018-11-23 14:02:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-23 14:02:27 --> Input Class Initialized
INFO - 2018-11-23 14:02:27 --> Language Class Initialized
INFO - 2018-11-23 14:02:27 --> Loader Class Initialized
INFO - 2018-11-23 14:02:27 --> Helper loaded: url_helper
INFO - 2018-11-23 14:02:27 --> Helper loaded: file_helper
INFO - 2018-11-23 14:02:27 --> Helper loaded: email_helper
INFO - 2018-11-23 14:02:27 --> Helper loaded: common_helper
INFO - 2018-11-23 14:02:27 --> Database Driver Class Initialized
DEBUG - 2018-11-23 14:02:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-23 14:02:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-23 14:02:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-23 14:02:27 --> Pagination Class Initialized
INFO - 2018-11-23 14:02:27 --> Helper loaded: form_helper
INFO - 2018-11-23 14:02:27 --> Form Validation Class Initialized
INFO - 2018-11-23 14:02:27 --> Model Class Initialized
INFO - 2018-11-23 14:02:27 --> Controller Class Initialized
INFO - 2018-11-23 14:02:27 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-23 14:02:27 --> Model Class Initialized
INFO - 2018-11-23 14:02:27 --> Model Class Initialized
INFO - 2018-11-23 14:02:27 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-23 14:02:27 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/change-password.php
INFO - 2018-11-23 14:02:27 --> Final output sent to browser
DEBUG - 2018-11-23 14:02:27 --> Total execution time: 0.0590
INFO - 2018-11-23 14:02:28 --> Config Class Initialized
INFO - 2018-11-23 14:02:28 --> Hooks Class Initialized
DEBUG - 2018-11-23 14:02:28 --> UTF-8 Support Enabled
INFO - 2018-11-23 14:02:28 --> Utf8 Class Initialized
INFO - 2018-11-23 14:02:28 --> URI Class Initialized
INFO - 2018-11-23 14:02:28 --> Router Class Initialized
INFO - 2018-11-23 14:02:28 --> Output Class Initialized
INFO - 2018-11-23 14:02:28 --> Security Class Initialized
DEBUG - 2018-11-23 14:02:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-23 14:02:28 --> Input Class Initialized
INFO - 2018-11-23 14:02:28 --> Language Class Initialized
ERROR - 2018-11-23 14:02:28 --> 404 Page Not Found: Plugins/images
INFO - 2018-11-23 14:04:23 --> Config Class Initialized
INFO - 2018-11-23 14:04:23 --> Hooks Class Initialized
DEBUG - 2018-11-23 14:04:23 --> UTF-8 Support Enabled
INFO - 2018-11-23 14:04:23 --> Utf8 Class Initialized
INFO - 2018-11-23 14:04:23 --> URI Class Initialized
INFO - 2018-11-23 14:04:23 --> Router Class Initialized
INFO - 2018-11-23 14:04:23 --> Output Class Initialized
INFO - 2018-11-23 14:04:23 --> Security Class Initialized
DEBUG - 2018-11-23 14:04:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-23 14:04:23 --> Input Class Initialized
INFO - 2018-11-23 14:04:23 --> Language Class Initialized
INFO - 2018-11-23 14:04:23 --> Loader Class Initialized
INFO - 2018-11-23 14:04:23 --> Helper loaded: url_helper
INFO - 2018-11-23 14:04:23 --> Helper loaded: file_helper
INFO - 2018-11-23 14:04:23 --> Helper loaded: email_helper
INFO - 2018-11-23 14:04:23 --> Helper loaded: common_helper
INFO - 2018-11-23 14:04:23 --> Database Driver Class Initialized
DEBUG - 2018-11-23 14:04:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-23 14:04:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-23 14:04:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-23 14:04:23 --> Pagination Class Initialized
INFO - 2018-11-23 14:04:23 --> Helper loaded: form_helper
INFO - 2018-11-23 14:04:23 --> Form Validation Class Initialized
INFO - 2018-11-23 14:04:23 --> Model Class Initialized
INFO - 2018-11-23 14:04:23 --> Controller Class Initialized
INFO - 2018-11-23 14:04:23 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-23 14:04:23 --> Model Class Initialized
INFO - 2018-11-23 14:04:23 --> Model Class Initialized
INFO - 2018-11-23 14:04:23 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-23 14:04:23 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/change-password.php
INFO - 2018-11-23 14:04:23 --> Final output sent to browser
DEBUG - 2018-11-23 14:04:23 --> Total execution time: 0.0510
INFO - 2018-11-23 14:04:24 --> Config Class Initialized
INFO - 2018-11-23 14:04:24 --> Hooks Class Initialized
DEBUG - 2018-11-23 14:04:24 --> UTF-8 Support Enabled
INFO - 2018-11-23 14:04:24 --> Utf8 Class Initialized
INFO - 2018-11-23 14:04:24 --> URI Class Initialized
INFO - 2018-11-23 14:04:24 --> Router Class Initialized
INFO - 2018-11-23 14:04:24 --> Output Class Initialized
INFO - 2018-11-23 14:04:24 --> Security Class Initialized
DEBUG - 2018-11-23 14:04:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-23 14:04:24 --> Input Class Initialized
INFO - 2018-11-23 14:04:24 --> Language Class Initialized
ERROR - 2018-11-23 14:04:24 --> 404 Page Not Found: Plugins/images
INFO - 2018-11-23 14:05:13 --> Config Class Initialized
INFO - 2018-11-23 14:05:13 --> Hooks Class Initialized
DEBUG - 2018-11-23 14:05:13 --> UTF-8 Support Enabled
INFO - 2018-11-23 14:05:13 --> Utf8 Class Initialized
INFO - 2018-11-23 14:05:13 --> URI Class Initialized
INFO - 2018-11-23 14:05:13 --> Router Class Initialized
INFO - 2018-11-23 14:05:13 --> Output Class Initialized
INFO - 2018-11-23 14:05:13 --> Security Class Initialized
DEBUG - 2018-11-23 14:05:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-23 14:05:13 --> Input Class Initialized
INFO - 2018-11-23 14:05:13 --> Language Class Initialized
INFO - 2018-11-23 14:05:13 --> Loader Class Initialized
INFO - 2018-11-23 14:05:13 --> Helper loaded: url_helper
INFO - 2018-11-23 14:05:13 --> Helper loaded: file_helper
INFO - 2018-11-23 14:05:13 --> Helper loaded: email_helper
INFO - 2018-11-23 14:05:13 --> Helper loaded: common_helper
INFO - 2018-11-23 14:05:13 --> Database Driver Class Initialized
DEBUG - 2018-11-23 14:05:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-23 14:05:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-23 14:05:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-23 14:05:13 --> Pagination Class Initialized
INFO - 2018-11-23 14:05:13 --> Helper loaded: form_helper
INFO - 2018-11-23 14:05:13 --> Form Validation Class Initialized
INFO - 2018-11-23 14:05:13 --> Model Class Initialized
INFO - 2018-11-23 14:05:13 --> Controller Class Initialized
INFO - 2018-11-23 14:05:13 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-23 14:05:13 --> Model Class Initialized
INFO - 2018-11-23 14:05:13 --> Model Class Initialized
INFO - 2018-11-23 14:05:13 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-23 14:05:13 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/change-password.php
INFO - 2018-11-23 14:05:13 --> Final output sent to browser
DEBUG - 2018-11-23 14:05:13 --> Total execution time: 0.0776
INFO - 2018-11-23 14:05:14 --> Config Class Initialized
INFO - 2018-11-23 14:05:14 --> Hooks Class Initialized
DEBUG - 2018-11-23 14:05:14 --> UTF-8 Support Enabled
INFO - 2018-11-23 14:05:14 --> Utf8 Class Initialized
INFO - 2018-11-23 14:05:14 --> URI Class Initialized
INFO - 2018-11-23 14:05:14 --> Router Class Initialized
INFO - 2018-11-23 14:05:14 --> Output Class Initialized
INFO - 2018-11-23 14:05:14 --> Security Class Initialized
DEBUG - 2018-11-23 14:05:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-23 14:05:14 --> Input Class Initialized
INFO - 2018-11-23 14:05:14 --> Language Class Initialized
ERROR - 2018-11-23 14:05:14 --> 404 Page Not Found: Plugins/images
INFO - 2018-11-23 14:06:33 --> Config Class Initialized
INFO - 2018-11-23 14:06:33 --> Hooks Class Initialized
DEBUG - 2018-11-23 14:06:33 --> UTF-8 Support Enabled
INFO - 2018-11-23 14:06:33 --> Utf8 Class Initialized
INFO - 2018-11-23 14:06:33 --> URI Class Initialized
INFO - 2018-11-23 14:06:33 --> Router Class Initialized
INFO - 2018-11-23 14:06:33 --> Output Class Initialized
INFO - 2018-11-23 14:06:33 --> Security Class Initialized
DEBUG - 2018-11-23 14:06:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-23 14:06:33 --> Input Class Initialized
INFO - 2018-11-23 14:06:33 --> Language Class Initialized
INFO - 2018-11-23 14:06:33 --> Loader Class Initialized
INFO - 2018-11-23 14:06:33 --> Helper loaded: url_helper
INFO - 2018-11-23 14:06:33 --> Helper loaded: file_helper
INFO - 2018-11-23 14:06:33 --> Helper loaded: email_helper
INFO - 2018-11-23 14:06:33 --> Helper loaded: common_helper
INFO - 2018-11-23 14:06:33 --> Database Driver Class Initialized
DEBUG - 2018-11-23 14:06:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-23 14:06:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-23 14:06:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-23 14:06:33 --> Pagination Class Initialized
INFO - 2018-11-23 14:06:33 --> Helper loaded: form_helper
INFO - 2018-11-23 14:06:33 --> Form Validation Class Initialized
INFO - 2018-11-23 14:06:33 --> Model Class Initialized
INFO - 2018-11-23 14:06:33 --> Controller Class Initialized
INFO - 2018-11-23 14:06:33 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-23 14:06:33 --> Model Class Initialized
INFO - 2018-11-23 14:06:33 --> Model Class Initialized
INFO - 2018-11-23 14:06:33 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-23 14:06:33 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/change-password.php
INFO - 2018-11-23 14:06:33 --> Final output sent to browser
DEBUG - 2018-11-23 14:06:33 --> Total execution time: 0.0746
INFO - 2018-11-23 14:06:34 --> Config Class Initialized
INFO - 2018-11-23 14:06:34 --> Hooks Class Initialized
DEBUG - 2018-11-23 14:06:34 --> UTF-8 Support Enabled
INFO - 2018-11-23 14:06:34 --> Utf8 Class Initialized
INFO - 2018-11-23 14:06:34 --> URI Class Initialized
INFO - 2018-11-23 14:06:34 --> Router Class Initialized
INFO - 2018-11-23 14:06:34 --> Output Class Initialized
INFO - 2018-11-23 14:06:34 --> Security Class Initialized
DEBUG - 2018-11-23 14:06:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-23 14:06:34 --> Input Class Initialized
INFO - 2018-11-23 14:06:34 --> Language Class Initialized
ERROR - 2018-11-23 14:06:34 --> 404 Page Not Found: Plugins/images
INFO - 2018-11-23 14:07:45 --> Config Class Initialized
INFO - 2018-11-23 14:07:45 --> Hooks Class Initialized
DEBUG - 2018-11-23 14:07:45 --> UTF-8 Support Enabled
INFO - 2018-11-23 14:07:45 --> Utf8 Class Initialized
INFO - 2018-11-23 14:07:45 --> URI Class Initialized
INFO - 2018-11-23 14:07:45 --> Router Class Initialized
INFO - 2018-11-23 14:07:45 --> Output Class Initialized
INFO - 2018-11-23 14:07:45 --> Security Class Initialized
DEBUG - 2018-11-23 14:07:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-23 14:07:45 --> Input Class Initialized
INFO - 2018-11-23 14:07:45 --> Language Class Initialized
INFO - 2018-11-23 14:07:45 --> Loader Class Initialized
INFO - 2018-11-23 14:07:45 --> Helper loaded: url_helper
INFO - 2018-11-23 14:07:45 --> Helper loaded: file_helper
INFO - 2018-11-23 14:07:45 --> Helper loaded: email_helper
INFO - 2018-11-23 14:07:45 --> Helper loaded: common_helper
INFO - 2018-11-23 14:07:45 --> Database Driver Class Initialized
DEBUG - 2018-11-23 14:07:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-23 14:07:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-23 14:07:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-23 14:07:46 --> Pagination Class Initialized
INFO - 2018-11-23 14:07:46 --> Helper loaded: form_helper
INFO - 2018-11-23 14:07:46 --> Form Validation Class Initialized
INFO - 2018-11-23 14:07:46 --> Model Class Initialized
INFO - 2018-11-23 14:07:46 --> Controller Class Initialized
INFO - 2018-11-23 14:07:46 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-23 14:07:46 --> Model Class Initialized
INFO - 2018-11-23 14:07:46 --> Model Class Initialized
INFO - 2018-11-23 14:07:46 --> Config Class Initialized
INFO - 2018-11-23 14:07:46 --> Hooks Class Initialized
DEBUG - 2018-11-23 14:07:46 --> UTF-8 Support Enabled
INFO - 2018-11-23 14:07:46 --> Utf8 Class Initialized
INFO - 2018-11-23 14:07:46 --> URI Class Initialized
INFO - 2018-11-23 14:07:46 --> Router Class Initialized
INFO - 2018-11-23 14:07:46 --> Output Class Initialized
INFO - 2018-11-23 14:07:46 --> Security Class Initialized
DEBUG - 2018-11-23 14:07:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-23 14:07:46 --> Input Class Initialized
INFO - 2018-11-23 14:07:46 --> Language Class Initialized
INFO - 2018-11-23 14:07:46 --> Loader Class Initialized
INFO - 2018-11-23 14:07:46 --> Helper loaded: url_helper
INFO - 2018-11-23 14:07:46 --> Helper loaded: file_helper
INFO - 2018-11-23 14:07:46 --> Helper loaded: email_helper
INFO - 2018-11-23 14:07:46 --> Helper loaded: common_helper
INFO - 2018-11-23 14:07:46 --> Database Driver Class Initialized
DEBUG - 2018-11-23 14:07:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-23 14:07:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-23 14:07:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-23 14:07:46 --> Pagination Class Initialized
INFO - 2018-11-23 14:07:46 --> Helper loaded: form_helper
INFO - 2018-11-23 14:07:46 --> Form Validation Class Initialized
INFO - 2018-11-23 14:07:46 --> Model Class Initialized
INFO - 2018-11-23 14:07:46 --> Controller Class Initialized
INFO - 2018-11-23 14:07:46 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-23 14:07:46 --> Model Class Initialized
INFO - 2018-11-23 14:07:46 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-23 14:07:46 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/sidebar.php
INFO - 2018-11-23 14:07:46 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/right-sidebar.php
INFO - 2018-11-23 14:07:46 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/footer.php
INFO - 2018-11-23 14:07:46 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/dashboard.php
INFO - 2018-11-23 14:07:46 --> Final output sent to browser
DEBUG - 2018-11-23 14:07:46 --> Total execution time: 0.0500
INFO - 2018-11-23 14:07:53 --> Config Class Initialized
INFO - 2018-11-23 14:07:53 --> Hooks Class Initialized
DEBUG - 2018-11-23 14:07:53 --> UTF-8 Support Enabled
INFO - 2018-11-23 14:07:53 --> Utf8 Class Initialized
INFO - 2018-11-23 14:07:53 --> URI Class Initialized
INFO - 2018-11-23 14:07:53 --> Router Class Initialized
INFO - 2018-11-23 14:07:53 --> Output Class Initialized
INFO - 2018-11-23 14:07:53 --> Security Class Initialized
DEBUG - 2018-11-23 14:07:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-23 14:07:53 --> Input Class Initialized
INFO - 2018-11-23 14:07:53 --> Language Class Initialized
INFO - 2018-11-23 14:07:53 --> Loader Class Initialized
INFO - 2018-11-23 14:07:53 --> Helper loaded: url_helper
INFO - 2018-11-23 14:07:53 --> Helper loaded: file_helper
INFO - 2018-11-23 14:07:53 --> Helper loaded: email_helper
INFO - 2018-11-23 14:07:53 --> Helper loaded: common_helper
INFO - 2018-11-23 14:07:53 --> Database Driver Class Initialized
DEBUG - 2018-11-23 14:07:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-23 14:07:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-23 14:07:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-23 14:07:53 --> Pagination Class Initialized
INFO - 2018-11-23 14:07:53 --> Helper loaded: form_helper
INFO - 2018-11-23 14:07:53 --> Form Validation Class Initialized
INFO - 2018-11-23 14:07:53 --> Model Class Initialized
INFO - 2018-11-23 14:07:53 --> Controller Class Initialized
INFO - 2018-11-23 14:07:53 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-23 14:07:53 --> Model Class Initialized
INFO - 2018-11-23 14:07:53 --> Model Class Initialized
INFO - 2018-11-23 14:07:53 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-23 14:07:53 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/change-password.php
INFO - 2018-11-23 14:07:53 --> Final output sent to browser
DEBUG - 2018-11-23 14:07:53 --> Total execution time: 0.0570
INFO - 2018-11-23 14:07:54 --> Config Class Initialized
INFO - 2018-11-23 14:07:54 --> Hooks Class Initialized
DEBUG - 2018-11-23 14:07:54 --> UTF-8 Support Enabled
INFO - 2018-11-23 14:07:54 --> Utf8 Class Initialized
INFO - 2018-11-23 14:07:54 --> URI Class Initialized
INFO - 2018-11-23 14:07:54 --> Router Class Initialized
INFO - 2018-11-23 14:07:54 --> Output Class Initialized
INFO - 2018-11-23 14:07:54 --> Security Class Initialized
DEBUG - 2018-11-23 14:07:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-23 14:07:54 --> Input Class Initialized
INFO - 2018-11-23 14:07:54 --> Language Class Initialized
ERROR - 2018-11-23 14:07:54 --> 404 Page Not Found: Plugins/images
INFO - 2018-11-23 14:08:23 --> Config Class Initialized
INFO - 2018-11-23 14:08:23 --> Hooks Class Initialized
DEBUG - 2018-11-23 14:08:23 --> UTF-8 Support Enabled
INFO - 2018-11-23 14:08:23 --> Utf8 Class Initialized
INFO - 2018-11-23 14:08:23 --> URI Class Initialized
INFO - 2018-11-23 14:08:23 --> Router Class Initialized
INFO - 2018-11-23 14:08:23 --> Output Class Initialized
INFO - 2018-11-23 14:08:23 --> Security Class Initialized
DEBUG - 2018-11-23 14:08:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-23 14:08:23 --> Input Class Initialized
INFO - 2018-11-23 14:08:23 --> Language Class Initialized
INFO - 2018-11-23 14:08:23 --> Loader Class Initialized
INFO - 2018-11-23 14:08:23 --> Helper loaded: url_helper
INFO - 2018-11-23 14:08:23 --> Helper loaded: file_helper
INFO - 2018-11-23 14:08:23 --> Helper loaded: email_helper
INFO - 2018-11-23 14:08:23 --> Helper loaded: common_helper
INFO - 2018-11-23 14:08:23 --> Database Driver Class Initialized
DEBUG - 2018-11-23 14:08:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-23 14:08:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-23 14:08:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-23 14:08:23 --> Pagination Class Initialized
INFO - 2018-11-23 14:08:23 --> Helper loaded: form_helper
INFO - 2018-11-23 14:08:23 --> Form Validation Class Initialized
INFO - 2018-11-23 14:08:23 --> Model Class Initialized
INFO - 2018-11-23 14:08:23 --> Controller Class Initialized
INFO - 2018-11-23 14:08:23 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-23 14:08:23 --> Model Class Initialized
INFO - 2018-11-23 14:08:23 --> Model Class Initialized
INFO - 2018-11-23 14:08:23 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-23 14:08:23 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/change-password.php
INFO - 2018-11-23 14:08:23 --> Final output sent to browser
DEBUG - 2018-11-23 14:08:23 --> Total execution time: 0.0570
INFO - 2018-11-23 14:08:24 --> Config Class Initialized
INFO - 2018-11-23 14:08:24 --> Hooks Class Initialized
DEBUG - 2018-11-23 14:08:24 --> UTF-8 Support Enabled
INFO - 2018-11-23 14:08:24 --> Utf8 Class Initialized
INFO - 2018-11-23 14:08:24 --> URI Class Initialized
INFO - 2018-11-23 14:08:24 --> Router Class Initialized
INFO - 2018-11-23 14:08:24 --> Output Class Initialized
INFO - 2018-11-23 14:08:24 --> Security Class Initialized
DEBUG - 2018-11-23 14:08:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-23 14:08:24 --> Input Class Initialized
INFO - 2018-11-23 14:08:24 --> Language Class Initialized
ERROR - 2018-11-23 14:08:24 --> 404 Page Not Found: Plugins/images
INFO - 2018-11-23 14:10:29 --> Config Class Initialized
INFO - 2018-11-23 14:10:29 --> Hooks Class Initialized
DEBUG - 2018-11-23 14:10:29 --> UTF-8 Support Enabled
INFO - 2018-11-23 14:10:29 --> Utf8 Class Initialized
INFO - 2018-11-23 14:10:29 --> URI Class Initialized
INFO - 2018-11-23 14:10:29 --> Router Class Initialized
INFO - 2018-11-23 14:10:29 --> Output Class Initialized
INFO - 2018-11-23 14:10:29 --> Security Class Initialized
DEBUG - 2018-11-23 14:10:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-23 14:10:29 --> Input Class Initialized
INFO - 2018-11-23 14:10:29 --> Language Class Initialized
INFO - 2018-11-23 14:10:29 --> Loader Class Initialized
INFO - 2018-11-23 14:10:29 --> Helper loaded: url_helper
INFO - 2018-11-23 14:10:29 --> Helper loaded: file_helper
INFO - 2018-11-23 14:10:29 --> Helper loaded: email_helper
INFO - 2018-11-23 14:10:29 --> Helper loaded: common_helper
INFO - 2018-11-23 14:10:29 --> Database Driver Class Initialized
DEBUG - 2018-11-23 14:10:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-23 14:10:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-23 14:10:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-23 14:10:29 --> Pagination Class Initialized
INFO - 2018-11-23 14:10:29 --> Helper loaded: form_helper
INFO - 2018-11-23 14:10:29 --> Form Validation Class Initialized
INFO - 2018-11-23 14:10:29 --> Model Class Initialized
INFO - 2018-11-23 14:10:29 --> Controller Class Initialized
INFO - 2018-11-23 14:10:29 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-23 14:10:29 --> Model Class Initialized
INFO - 2018-11-23 14:10:29 --> Model Class Initialized
INFO - 2018-11-23 14:10:29 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-23 14:10:29 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/change-password.php
INFO - 2018-11-23 14:10:29 --> Final output sent to browser
DEBUG - 2018-11-23 14:10:29 --> Total execution time: 0.0530
INFO - 2018-11-23 14:10:31 --> Config Class Initialized
INFO - 2018-11-23 14:10:31 --> Hooks Class Initialized
DEBUG - 2018-11-23 14:10:31 --> UTF-8 Support Enabled
INFO - 2018-11-23 14:10:31 --> Utf8 Class Initialized
INFO - 2018-11-23 14:10:31 --> URI Class Initialized
INFO - 2018-11-23 14:10:31 --> Router Class Initialized
INFO - 2018-11-23 14:10:31 --> Output Class Initialized
INFO - 2018-11-23 14:10:31 --> Security Class Initialized
DEBUG - 2018-11-23 14:10:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-23 14:10:31 --> Input Class Initialized
INFO - 2018-11-23 14:10:31 --> Language Class Initialized
ERROR - 2018-11-23 14:10:31 --> 404 Page Not Found: Plugins/images
INFO - 2018-11-23 14:10:48 --> Config Class Initialized
INFO - 2018-11-23 14:10:48 --> Hooks Class Initialized
DEBUG - 2018-11-23 14:10:48 --> UTF-8 Support Enabled
INFO - 2018-11-23 14:10:48 --> Utf8 Class Initialized
INFO - 2018-11-23 14:10:48 --> URI Class Initialized
INFO - 2018-11-23 14:10:48 --> Router Class Initialized
INFO - 2018-11-23 14:10:48 --> Output Class Initialized
INFO - 2018-11-23 14:10:48 --> Security Class Initialized
DEBUG - 2018-11-23 14:10:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-23 14:10:48 --> Input Class Initialized
INFO - 2018-11-23 14:10:48 --> Language Class Initialized
INFO - 2018-11-23 14:10:48 --> Loader Class Initialized
INFO - 2018-11-23 14:10:48 --> Helper loaded: url_helper
INFO - 2018-11-23 14:10:48 --> Helper loaded: file_helper
INFO - 2018-11-23 14:10:48 --> Helper loaded: email_helper
INFO - 2018-11-23 14:10:48 --> Helper loaded: common_helper
INFO - 2018-11-23 14:10:48 --> Database Driver Class Initialized
DEBUG - 2018-11-23 14:10:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-23 14:10:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-23 14:10:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-23 14:10:48 --> Pagination Class Initialized
INFO - 2018-11-23 14:10:48 --> Helper loaded: form_helper
INFO - 2018-11-23 14:10:48 --> Form Validation Class Initialized
INFO - 2018-11-23 14:10:48 --> Model Class Initialized
INFO - 2018-11-23 14:10:48 --> Controller Class Initialized
INFO - 2018-11-23 14:10:48 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-23 14:10:48 --> Model Class Initialized
INFO - 2018-11-23 14:10:48 --> Model Class Initialized
INFO - 2018-11-23 14:10:48 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-23 14:10:48 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/change-password.php
INFO - 2018-11-23 14:10:48 --> Final output sent to browser
DEBUG - 2018-11-23 14:10:48 --> Total execution time: 0.0550
INFO - 2018-11-23 14:10:49 --> Config Class Initialized
INFO - 2018-11-23 14:10:49 --> Hooks Class Initialized
DEBUG - 2018-11-23 14:10:49 --> UTF-8 Support Enabled
INFO - 2018-11-23 14:10:49 --> Utf8 Class Initialized
INFO - 2018-11-23 14:10:49 --> URI Class Initialized
INFO - 2018-11-23 14:10:49 --> Router Class Initialized
INFO - 2018-11-23 14:10:49 --> Output Class Initialized
INFO - 2018-11-23 14:10:49 --> Security Class Initialized
DEBUG - 2018-11-23 14:10:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-23 14:10:49 --> Input Class Initialized
INFO - 2018-11-23 14:10:49 --> Language Class Initialized
ERROR - 2018-11-23 14:10:49 --> 404 Page Not Found: Plugins/images
INFO - 2018-11-23 14:10:58 --> Config Class Initialized
INFO - 2018-11-23 14:10:58 --> Hooks Class Initialized
DEBUG - 2018-11-23 14:10:58 --> UTF-8 Support Enabled
INFO - 2018-11-23 14:10:58 --> Utf8 Class Initialized
INFO - 2018-11-23 14:10:58 --> URI Class Initialized
INFO - 2018-11-23 14:10:58 --> Router Class Initialized
INFO - 2018-11-23 14:10:58 --> Output Class Initialized
INFO - 2018-11-23 14:10:58 --> Security Class Initialized
DEBUG - 2018-11-23 14:10:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-23 14:10:58 --> Input Class Initialized
INFO - 2018-11-23 14:10:58 --> Language Class Initialized
INFO - 2018-11-23 14:10:58 --> Loader Class Initialized
INFO - 2018-11-23 14:10:58 --> Helper loaded: url_helper
INFO - 2018-11-23 14:10:58 --> Helper loaded: file_helper
INFO - 2018-11-23 14:10:58 --> Helper loaded: email_helper
INFO - 2018-11-23 14:10:58 --> Helper loaded: common_helper
INFO - 2018-11-23 14:10:58 --> Database Driver Class Initialized
DEBUG - 2018-11-23 14:10:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-23 14:10:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-23 14:10:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-23 14:10:58 --> Pagination Class Initialized
INFO - 2018-11-23 14:10:58 --> Helper loaded: form_helper
INFO - 2018-11-23 14:10:58 --> Form Validation Class Initialized
INFO - 2018-11-23 14:10:58 --> Model Class Initialized
INFO - 2018-11-23 14:10:58 --> Controller Class Initialized
INFO - 2018-11-23 14:10:58 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-23 14:10:58 --> Model Class Initialized
INFO - 2018-11-23 14:10:58 --> Model Class Initialized
INFO - 2018-11-23 14:10:58 --> Config Class Initialized
INFO - 2018-11-23 14:10:58 --> Hooks Class Initialized
DEBUG - 2018-11-23 14:10:58 --> UTF-8 Support Enabled
INFO - 2018-11-23 14:10:58 --> Utf8 Class Initialized
INFO - 2018-11-23 14:10:58 --> URI Class Initialized
INFO - 2018-11-23 14:10:58 --> Router Class Initialized
INFO - 2018-11-23 14:10:58 --> Output Class Initialized
INFO - 2018-11-23 14:10:58 --> Security Class Initialized
DEBUG - 2018-11-23 14:10:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-23 14:10:58 --> Input Class Initialized
INFO - 2018-11-23 14:10:58 --> Language Class Initialized
INFO - 2018-11-23 14:10:58 --> Loader Class Initialized
INFO - 2018-11-23 14:10:58 --> Helper loaded: url_helper
INFO - 2018-11-23 14:10:58 --> Helper loaded: file_helper
INFO - 2018-11-23 14:10:58 --> Helper loaded: email_helper
INFO - 2018-11-23 14:10:58 --> Helper loaded: common_helper
INFO - 2018-11-23 14:10:58 --> Database Driver Class Initialized
DEBUG - 2018-11-23 14:10:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-23 14:10:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-23 14:10:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-23 14:10:58 --> Pagination Class Initialized
INFO - 2018-11-23 14:10:58 --> Helper loaded: form_helper
INFO - 2018-11-23 14:10:58 --> Form Validation Class Initialized
INFO - 2018-11-23 14:10:58 --> Model Class Initialized
INFO - 2018-11-23 14:10:58 --> Controller Class Initialized
INFO - 2018-11-23 14:10:58 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-23 14:10:58 --> Model Class Initialized
INFO - 2018-11-23 14:10:58 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-23 14:10:58 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/sidebar.php
INFO - 2018-11-23 14:10:58 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/right-sidebar.php
INFO - 2018-11-23 14:10:58 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/footer.php
INFO - 2018-11-23 14:10:58 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/dashboard.php
INFO - 2018-11-23 14:10:58 --> Final output sent to browser
DEBUG - 2018-11-23 14:10:58 --> Total execution time: 0.0420
INFO - 2018-11-23 14:11:14 --> Config Class Initialized
INFO - 2018-11-23 14:11:14 --> Hooks Class Initialized
DEBUG - 2018-11-23 14:11:14 --> UTF-8 Support Enabled
INFO - 2018-11-23 14:11:14 --> Utf8 Class Initialized
INFO - 2018-11-23 14:11:14 --> URI Class Initialized
INFO - 2018-11-23 14:11:14 --> Router Class Initialized
INFO - 2018-11-23 14:11:14 --> Output Class Initialized
INFO - 2018-11-23 14:11:14 --> Security Class Initialized
DEBUG - 2018-11-23 14:11:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-23 14:11:14 --> Input Class Initialized
INFO - 2018-11-23 14:11:14 --> Language Class Initialized
INFO - 2018-11-23 14:11:14 --> Loader Class Initialized
INFO - 2018-11-23 14:11:14 --> Helper loaded: url_helper
INFO - 2018-11-23 14:11:14 --> Helper loaded: file_helper
INFO - 2018-11-23 14:11:14 --> Helper loaded: email_helper
INFO - 2018-11-23 14:11:14 --> Helper loaded: common_helper
INFO - 2018-11-23 14:11:14 --> Database Driver Class Initialized
DEBUG - 2018-11-23 14:11:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-23 14:11:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-23 14:11:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-23 14:11:14 --> Pagination Class Initialized
INFO - 2018-11-23 14:11:14 --> Helper loaded: form_helper
INFO - 2018-11-23 14:11:14 --> Form Validation Class Initialized
INFO - 2018-11-23 14:11:14 --> Model Class Initialized
INFO - 2018-11-23 14:11:14 --> Controller Class Initialized
INFO - 2018-11-23 14:11:14 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-23 14:11:14 --> Model Class Initialized
INFO - 2018-11-23 14:11:14 --> Model Class Initialized
INFO - 2018-11-23 14:11:14 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-23 14:11:14 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/change-password.php
INFO - 2018-11-23 14:11:14 --> Final output sent to browser
DEBUG - 2018-11-23 14:11:14 --> Total execution time: 0.0460
INFO - 2018-11-23 14:11:15 --> Config Class Initialized
INFO - 2018-11-23 14:11:15 --> Hooks Class Initialized
DEBUG - 2018-11-23 14:11:15 --> UTF-8 Support Enabled
INFO - 2018-11-23 14:11:15 --> Utf8 Class Initialized
INFO - 2018-11-23 14:11:15 --> URI Class Initialized
INFO - 2018-11-23 14:11:15 --> Router Class Initialized
INFO - 2018-11-23 14:11:15 --> Output Class Initialized
INFO - 2018-11-23 14:11:15 --> Security Class Initialized
DEBUG - 2018-11-23 14:11:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-23 14:11:15 --> Input Class Initialized
INFO - 2018-11-23 14:11:15 --> Language Class Initialized
ERROR - 2018-11-23 14:11:15 --> 404 Page Not Found: Plugins/images
INFO - 2018-11-23 14:11:32 --> Config Class Initialized
INFO - 2018-11-23 14:11:32 --> Hooks Class Initialized
DEBUG - 2018-11-23 14:11:32 --> UTF-8 Support Enabled
INFO - 2018-11-23 14:11:32 --> Utf8 Class Initialized
INFO - 2018-11-23 14:11:32 --> URI Class Initialized
INFO - 2018-11-23 14:11:32 --> Router Class Initialized
INFO - 2018-11-23 14:11:32 --> Output Class Initialized
INFO - 2018-11-23 14:11:32 --> Security Class Initialized
DEBUG - 2018-11-23 14:11:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-23 14:11:32 --> Input Class Initialized
INFO - 2018-11-23 14:11:32 --> Language Class Initialized
INFO - 2018-11-23 14:11:32 --> Loader Class Initialized
INFO - 2018-11-23 14:11:32 --> Helper loaded: url_helper
INFO - 2018-11-23 14:11:32 --> Helper loaded: file_helper
INFO - 2018-11-23 14:11:32 --> Helper loaded: email_helper
INFO - 2018-11-23 14:11:32 --> Helper loaded: common_helper
INFO - 2018-11-23 14:11:32 --> Database Driver Class Initialized
DEBUG - 2018-11-23 14:11:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-23 14:11:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-23 14:11:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-23 14:11:32 --> Pagination Class Initialized
INFO - 2018-11-23 14:11:32 --> Helper loaded: form_helper
INFO - 2018-11-23 14:11:32 --> Form Validation Class Initialized
INFO - 2018-11-23 14:11:32 --> Model Class Initialized
INFO - 2018-11-23 14:11:32 --> Controller Class Initialized
INFO - 2018-11-23 14:11:32 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-23 14:11:32 --> Model Class Initialized
INFO - 2018-11-23 14:11:32 --> Model Class Initialized
INFO - 2018-11-23 14:11:32 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-23 14:11:32 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/change-password.php
INFO - 2018-11-23 14:11:32 --> Final output sent to browser
DEBUG - 2018-11-23 14:11:32 --> Total execution time: 0.0600
INFO - 2018-11-23 14:11:33 --> Config Class Initialized
INFO - 2018-11-23 14:11:33 --> Hooks Class Initialized
DEBUG - 2018-11-23 14:11:33 --> UTF-8 Support Enabled
INFO - 2018-11-23 14:11:33 --> Utf8 Class Initialized
INFO - 2018-11-23 14:11:33 --> URI Class Initialized
INFO - 2018-11-23 14:11:33 --> Router Class Initialized
INFO - 2018-11-23 14:11:33 --> Output Class Initialized
INFO - 2018-11-23 14:11:33 --> Security Class Initialized
DEBUG - 2018-11-23 14:11:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-23 14:11:33 --> Input Class Initialized
INFO - 2018-11-23 14:11:33 --> Language Class Initialized
ERROR - 2018-11-23 14:11:33 --> 404 Page Not Found: Plugins/images
INFO - 2018-11-23 14:11:36 --> Config Class Initialized
INFO - 2018-11-23 14:11:36 --> Hooks Class Initialized
DEBUG - 2018-11-23 14:11:36 --> UTF-8 Support Enabled
INFO - 2018-11-23 14:11:36 --> Utf8 Class Initialized
INFO - 2018-11-23 14:11:36 --> URI Class Initialized
INFO - 2018-11-23 14:11:36 --> Router Class Initialized
INFO - 2018-11-23 14:11:36 --> Output Class Initialized
INFO - 2018-11-23 14:11:36 --> Security Class Initialized
DEBUG - 2018-11-23 14:11:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-23 14:11:36 --> Input Class Initialized
INFO - 2018-11-23 14:11:36 --> Language Class Initialized
INFO - 2018-11-23 14:11:36 --> Loader Class Initialized
INFO - 2018-11-23 14:11:36 --> Helper loaded: url_helper
INFO - 2018-11-23 14:11:36 --> Helper loaded: file_helper
INFO - 2018-11-23 14:11:36 --> Helper loaded: email_helper
INFO - 2018-11-23 14:11:36 --> Helper loaded: common_helper
INFO - 2018-11-23 14:11:36 --> Database Driver Class Initialized
DEBUG - 2018-11-23 14:11:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-23 14:11:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-23 14:11:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-23 14:11:37 --> Pagination Class Initialized
INFO - 2018-11-23 14:11:37 --> Helper loaded: form_helper
INFO - 2018-11-23 14:11:37 --> Form Validation Class Initialized
INFO - 2018-11-23 14:11:37 --> Model Class Initialized
INFO - 2018-11-23 14:11:37 --> Controller Class Initialized
INFO - 2018-11-23 14:11:37 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-23 14:11:37 --> Model Class Initialized
INFO - 2018-11-23 14:11:37 --> Model Class Initialized
INFO - 2018-11-23 14:11:37 --> Config Class Initialized
INFO - 2018-11-23 14:11:37 --> Hooks Class Initialized
DEBUG - 2018-11-23 14:11:37 --> UTF-8 Support Enabled
INFO - 2018-11-23 14:11:37 --> Utf8 Class Initialized
INFO - 2018-11-23 14:11:37 --> URI Class Initialized
INFO - 2018-11-23 14:11:37 --> Router Class Initialized
INFO - 2018-11-23 14:11:37 --> Output Class Initialized
INFO - 2018-11-23 14:11:37 --> Security Class Initialized
DEBUG - 2018-11-23 14:11:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-23 14:11:37 --> Input Class Initialized
INFO - 2018-11-23 14:11:37 --> Language Class Initialized
INFO - 2018-11-23 14:11:37 --> Loader Class Initialized
INFO - 2018-11-23 14:11:37 --> Helper loaded: url_helper
INFO - 2018-11-23 14:11:37 --> Helper loaded: file_helper
INFO - 2018-11-23 14:11:37 --> Helper loaded: email_helper
INFO - 2018-11-23 14:11:37 --> Helper loaded: common_helper
INFO - 2018-11-23 14:11:37 --> Database Driver Class Initialized
DEBUG - 2018-11-23 14:11:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-23 14:11:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-23 14:11:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-23 14:11:37 --> Pagination Class Initialized
INFO - 2018-11-23 14:11:37 --> Helper loaded: form_helper
INFO - 2018-11-23 14:11:37 --> Form Validation Class Initialized
INFO - 2018-11-23 14:11:37 --> Model Class Initialized
INFO - 2018-11-23 14:11:37 --> Controller Class Initialized
INFO - 2018-11-23 14:11:37 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-23 14:11:37 --> Model Class Initialized
INFO - 2018-11-23 14:11:37 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-23 14:11:37 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/sidebar.php
INFO - 2018-11-23 14:11:37 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/right-sidebar.php
INFO - 2018-11-23 14:11:37 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/footer.php
INFO - 2018-11-23 14:11:37 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/dashboard.php
INFO - 2018-11-23 14:11:37 --> Final output sent to browser
DEBUG - 2018-11-23 14:11:37 --> Total execution time: 0.0430
INFO - 2018-11-23 14:11:52 --> Config Class Initialized
INFO - 2018-11-23 14:11:52 --> Hooks Class Initialized
DEBUG - 2018-11-23 14:11:52 --> UTF-8 Support Enabled
INFO - 2018-11-23 14:11:52 --> Utf8 Class Initialized
INFO - 2018-11-23 14:11:52 --> URI Class Initialized
INFO - 2018-11-23 14:11:52 --> Router Class Initialized
INFO - 2018-11-23 14:11:52 --> Output Class Initialized
INFO - 2018-11-23 14:11:52 --> Security Class Initialized
DEBUG - 2018-11-23 14:11:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-23 14:11:52 --> Input Class Initialized
INFO - 2018-11-23 14:11:52 --> Language Class Initialized
INFO - 2018-11-23 14:11:52 --> Loader Class Initialized
INFO - 2018-11-23 14:11:52 --> Helper loaded: url_helper
INFO - 2018-11-23 14:11:52 --> Helper loaded: file_helper
INFO - 2018-11-23 14:11:52 --> Helper loaded: email_helper
INFO - 2018-11-23 14:11:52 --> Helper loaded: common_helper
INFO - 2018-11-23 14:11:52 --> Database Driver Class Initialized
DEBUG - 2018-11-23 14:11:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-23 14:11:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-23 14:11:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-23 14:11:52 --> Pagination Class Initialized
INFO - 2018-11-23 14:11:52 --> Helper loaded: form_helper
INFO - 2018-11-23 14:11:52 --> Form Validation Class Initialized
INFO - 2018-11-23 14:11:52 --> Model Class Initialized
INFO - 2018-11-23 14:11:52 --> Controller Class Initialized
INFO - 2018-11-23 14:11:52 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-23 14:11:52 --> Model Class Initialized
INFO - 2018-11-23 14:11:52 --> Model Class Initialized
INFO - 2018-11-23 14:11:52 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-23 14:11:52 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/change-password.php
INFO - 2018-11-23 14:11:52 --> Final output sent to browser
DEBUG - 2018-11-23 14:11:52 --> Total execution time: 0.0630
INFO - 2018-11-23 14:11:52 --> Config Class Initialized
INFO - 2018-11-23 14:11:52 --> Hooks Class Initialized
DEBUG - 2018-11-23 14:11:52 --> UTF-8 Support Enabled
INFO - 2018-11-23 14:11:52 --> Utf8 Class Initialized
INFO - 2018-11-23 14:11:52 --> URI Class Initialized
INFO - 2018-11-23 14:11:52 --> Router Class Initialized
INFO - 2018-11-23 14:11:52 --> Output Class Initialized
INFO - 2018-11-23 14:11:52 --> Security Class Initialized
DEBUG - 2018-11-23 14:11:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-23 14:11:52 --> Input Class Initialized
INFO - 2018-11-23 14:11:52 --> Language Class Initialized
ERROR - 2018-11-23 14:11:52 --> 404 Page Not Found: Plugins/images
INFO - 2018-11-23 14:11:55 --> Config Class Initialized
INFO - 2018-11-23 14:11:55 --> Hooks Class Initialized
DEBUG - 2018-11-23 14:11:55 --> UTF-8 Support Enabled
INFO - 2018-11-23 14:11:55 --> Utf8 Class Initialized
INFO - 2018-11-23 14:11:55 --> URI Class Initialized
INFO - 2018-11-23 14:11:55 --> Router Class Initialized
INFO - 2018-11-23 14:11:55 --> Output Class Initialized
INFO - 2018-11-23 14:11:55 --> Security Class Initialized
DEBUG - 2018-11-23 14:11:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-23 14:11:55 --> Input Class Initialized
INFO - 2018-11-23 14:11:55 --> Language Class Initialized
INFO - 2018-11-23 14:11:55 --> Loader Class Initialized
INFO - 2018-11-23 14:11:55 --> Helper loaded: url_helper
INFO - 2018-11-23 14:11:55 --> Helper loaded: file_helper
INFO - 2018-11-23 14:11:55 --> Helper loaded: email_helper
INFO - 2018-11-23 14:11:55 --> Helper loaded: common_helper
INFO - 2018-11-23 14:11:55 --> Database Driver Class Initialized
DEBUG - 2018-11-23 14:11:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-23 14:11:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-23 14:11:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-23 14:11:55 --> Pagination Class Initialized
INFO - 2018-11-23 14:11:55 --> Helper loaded: form_helper
INFO - 2018-11-23 14:11:55 --> Form Validation Class Initialized
INFO - 2018-11-23 14:11:55 --> Model Class Initialized
INFO - 2018-11-23 14:11:55 --> Controller Class Initialized
INFO - 2018-11-23 14:11:55 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-23 14:11:55 --> Model Class Initialized
INFO - 2018-11-23 14:11:55 --> Model Class Initialized
INFO - 2018-11-23 14:11:55 --> Config Class Initialized
INFO - 2018-11-23 14:11:55 --> Hooks Class Initialized
DEBUG - 2018-11-23 14:11:55 --> UTF-8 Support Enabled
INFO - 2018-11-23 14:11:55 --> Utf8 Class Initialized
INFO - 2018-11-23 14:11:55 --> URI Class Initialized
INFO - 2018-11-23 14:11:55 --> Router Class Initialized
INFO - 2018-11-23 14:11:55 --> Output Class Initialized
INFO - 2018-11-23 14:11:55 --> Security Class Initialized
DEBUG - 2018-11-23 14:11:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-23 14:11:55 --> Input Class Initialized
INFO - 2018-11-23 14:11:55 --> Language Class Initialized
INFO - 2018-11-23 14:11:55 --> Loader Class Initialized
INFO - 2018-11-23 14:11:55 --> Helper loaded: url_helper
INFO - 2018-11-23 14:11:55 --> Helper loaded: file_helper
INFO - 2018-11-23 14:11:55 --> Helper loaded: email_helper
INFO - 2018-11-23 14:11:55 --> Helper loaded: common_helper
INFO - 2018-11-23 14:11:55 --> Database Driver Class Initialized
DEBUG - 2018-11-23 14:11:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-23 14:11:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-23 14:11:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-23 14:11:55 --> Pagination Class Initialized
INFO - 2018-11-23 14:11:55 --> Helper loaded: form_helper
INFO - 2018-11-23 14:11:55 --> Form Validation Class Initialized
INFO - 2018-11-23 14:11:55 --> Model Class Initialized
INFO - 2018-11-23 14:11:55 --> Controller Class Initialized
INFO - 2018-11-23 14:11:55 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-23 14:11:55 --> Model Class Initialized
INFO - 2018-11-23 14:11:55 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-23 14:11:55 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/sidebar.php
INFO - 2018-11-23 14:11:55 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/right-sidebar.php
INFO - 2018-11-23 14:11:55 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/footer.php
INFO - 2018-11-23 14:11:55 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/dashboard.php
INFO - 2018-11-23 14:11:55 --> Final output sent to browser
DEBUG - 2018-11-23 14:11:55 --> Total execution time: 0.0430
INFO - 2018-11-23 14:12:01 --> Config Class Initialized
INFO - 2018-11-23 14:12:01 --> Hooks Class Initialized
DEBUG - 2018-11-23 14:12:01 --> UTF-8 Support Enabled
INFO - 2018-11-23 14:12:01 --> Utf8 Class Initialized
INFO - 2018-11-23 14:12:01 --> URI Class Initialized
INFO - 2018-11-23 14:12:01 --> Router Class Initialized
INFO - 2018-11-23 14:12:01 --> Output Class Initialized
INFO - 2018-11-23 14:12:01 --> Security Class Initialized
DEBUG - 2018-11-23 14:12:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-23 14:12:01 --> Input Class Initialized
INFO - 2018-11-23 14:12:01 --> Language Class Initialized
INFO - 2018-11-23 14:12:01 --> Loader Class Initialized
INFO - 2018-11-23 14:12:01 --> Helper loaded: url_helper
INFO - 2018-11-23 14:12:01 --> Helper loaded: file_helper
INFO - 2018-11-23 14:12:01 --> Helper loaded: email_helper
INFO - 2018-11-23 14:12:01 --> Helper loaded: common_helper
INFO - 2018-11-23 14:12:01 --> Database Driver Class Initialized
DEBUG - 2018-11-23 14:12:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-23 14:12:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-23 14:12:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-23 14:12:01 --> Pagination Class Initialized
INFO - 2018-11-23 14:12:01 --> Helper loaded: form_helper
INFO - 2018-11-23 14:12:01 --> Form Validation Class Initialized
INFO - 2018-11-23 14:12:01 --> Model Class Initialized
INFO - 2018-11-23 14:12:01 --> Controller Class Initialized
INFO - 2018-11-23 14:12:01 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-23 14:12:01 --> Model Class Initialized
INFO - 2018-11-23 14:12:01 --> Model Class Initialized
INFO - 2018-11-23 14:12:01 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-23 14:12:01 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/change-password.php
INFO - 2018-11-23 14:12:01 --> Final output sent to browser
DEBUG - 2018-11-23 14:12:01 --> Total execution time: 0.0660
INFO - 2018-11-23 14:12:02 --> Config Class Initialized
INFO - 2018-11-23 14:12:02 --> Hooks Class Initialized
DEBUG - 2018-11-23 14:12:02 --> UTF-8 Support Enabled
INFO - 2018-11-23 14:12:02 --> Utf8 Class Initialized
INFO - 2018-11-23 14:12:02 --> URI Class Initialized
INFO - 2018-11-23 14:12:02 --> Router Class Initialized
INFO - 2018-11-23 14:12:02 --> Output Class Initialized
INFO - 2018-11-23 14:12:02 --> Security Class Initialized
DEBUG - 2018-11-23 14:12:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-23 14:12:02 --> Input Class Initialized
INFO - 2018-11-23 14:12:02 --> Language Class Initialized
ERROR - 2018-11-23 14:12:02 --> 404 Page Not Found: Plugins/images
INFO - 2018-11-23 14:12:12 --> Config Class Initialized
INFO - 2018-11-23 14:12:12 --> Hooks Class Initialized
DEBUG - 2018-11-23 14:12:12 --> UTF-8 Support Enabled
INFO - 2018-11-23 14:12:12 --> Utf8 Class Initialized
INFO - 2018-11-23 14:12:12 --> URI Class Initialized
INFO - 2018-11-23 14:12:12 --> Router Class Initialized
INFO - 2018-11-23 14:12:12 --> Output Class Initialized
INFO - 2018-11-23 14:12:12 --> Security Class Initialized
DEBUG - 2018-11-23 14:12:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-23 14:12:12 --> Input Class Initialized
INFO - 2018-11-23 14:12:12 --> Language Class Initialized
INFO - 2018-11-23 14:12:12 --> Loader Class Initialized
INFO - 2018-11-23 14:12:12 --> Helper loaded: url_helper
INFO - 2018-11-23 14:12:12 --> Helper loaded: file_helper
INFO - 2018-11-23 14:12:12 --> Helper loaded: email_helper
INFO - 2018-11-23 14:12:12 --> Helper loaded: common_helper
INFO - 2018-11-23 14:12:12 --> Database Driver Class Initialized
DEBUG - 2018-11-23 14:12:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-23 14:12:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-23 14:12:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-23 14:12:12 --> Pagination Class Initialized
INFO - 2018-11-23 14:12:12 --> Helper loaded: form_helper
INFO - 2018-11-23 14:12:12 --> Form Validation Class Initialized
INFO - 2018-11-23 14:12:12 --> Model Class Initialized
INFO - 2018-11-23 14:12:12 --> Controller Class Initialized
INFO - 2018-11-23 14:12:12 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-23 14:12:12 --> Model Class Initialized
INFO - 2018-11-23 14:12:12 --> Model Class Initialized
INFO - 2018-11-23 14:12:12 --> Config Class Initialized
INFO - 2018-11-23 14:12:12 --> Hooks Class Initialized
DEBUG - 2018-11-23 14:12:12 --> UTF-8 Support Enabled
INFO - 2018-11-23 14:12:12 --> Utf8 Class Initialized
INFO - 2018-11-23 14:12:12 --> URI Class Initialized
INFO - 2018-11-23 14:12:12 --> Router Class Initialized
INFO - 2018-11-23 14:12:12 --> Output Class Initialized
INFO - 2018-11-23 14:12:12 --> Security Class Initialized
DEBUG - 2018-11-23 14:12:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-23 14:12:12 --> Input Class Initialized
INFO - 2018-11-23 14:12:12 --> Language Class Initialized
INFO - 2018-11-23 14:12:12 --> Loader Class Initialized
INFO - 2018-11-23 14:12:12 --> Helper loaded: url_helper
INFO - 2018-11-23 14:12:12 --> Helper loaded: file_helper
INFO - 2018-11-23 14:12:12 --> Helper loaded: email_helper
INFO - 2018-11-23 14:12:12 --> Helper loaded: common_helper
INFO - 2018-11-23 14:12:12 --> Database Driver Class Initialized
DEBUG - 2018-11-23 14:12:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-23 14:12:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-23 14:12:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-23 14:12:12 --> Pagination Class Initialized
INFO - 2018-11-23 14:12:12 --> Helper loaded: form_helper
INFO - 2018-11-23 14:12:12 --> Form Validation Class Initialized
INFO - 2018-11-23 14:12:12 --> Model Class Initialized
INFO - 2018-11-23 14:12:12 --> Controller Class Initialized
INFO - 2018-11-23 14:12:12 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-23 14:12:12 --> Model Class Initialized
INFO - 2018-11-23 14:12:12 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-23 14:12:12 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/sidebar.php
INFO - 2018-11-23 14:12:12 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/right-sidebar.php
INFO - 2018-11-23 14:12:12 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/footer.php
INFO - 2018-11-23 14:12:12 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/dashboard.php
INFO - 2018-11-23 14:12:12 --> Final output sent to browser
DEBUG - 2018-11-23 14:12:12 --> Total execution time: 0.0600
INFO - 2018-11-23 14:12:29 --> Config Class Initialized
INFO - 2018-11-23 14:12:29 --> Hooks Class Initialized
DEBUG - 2018-11-23 14:12:29 --> UTF-8 Support Enabled
INFO - 2018-11-23 14:12:29 --> Utf8 Class Initialized
INFO - 2018-11-23 14:12:29 --> URI Class Initialized
INFO - 2018-11-23 14:12:29 --> Router Class Initialized
INFO - 2018-11-23 14:12:29 --> Output Class Initialized
INFO - 2018-11-23 14:12:29 --> Security Class Initialized
DEBUG - 2018-11-23 14:12:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-23 14:12:29 --> Input Class Initialized
INFO - 2018-11-23 14:12:29 --> Language Class Initialized
INFO - 2018-11-23 14:12:29 --> Loader Class Initialized
INFO - 2018-11-23 14:12:29 --> Helper loaded: url_helper
INFO - 2018-11-23 14:12:29 --> Helper loaded: file_helper
INFO - 2018-11-23 14:12:29 --> Helper loaded: email_helper
INFO - 2018-11-23 14:12:29 --> Helper loaded: common_helper
INFO - 2018-11-23 14:12:29 --> Database Driver Class Initialized
DEBUG - 2018-11-23 14:12:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-23 14:12:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-23 14:12:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-23 14:12:29 --> Pagination Class Initialized
INFO - 2018-11-23 14:12:29 --> Helper loaded: form_helper
INFO - 2018-11-23 14:12:29 --> Form Validation Class Initialized
INFO - 2018-11-23 14:12:29 --> Model Class Initialized
INFO - 2018-11-23 14:12:29 --> Controller Class Initialized
INFO - 2018-11-23 14:12:29 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-23 14:12:29 --> Model Class Initialized
INFO - 2018-11-23 14:12:29 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-23 14:12:29 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/sidebar.php
INFO - 2018-11-23 14:12:29 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/right-sidebar.php
INFO - 2018-11-23 14:12:29 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/footer.php
INFO - 2018-11-23 14:12:29 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/dashboard.php
INFO - 2018-11-23 14:12:29 --> Final output sent to browser
DEBUG - 2018-11-23 14:12:29 --> Total execution time: 0.0570
INFO - 2018-11-23 14:12:48 --> Config Class Initialized
INFO - 2018-11-23 14:12:48 --> Hooks Class Initialized
DEBUG - 2018-11-23 14:12:48 --> UTF-8 Support Enabled
INFO - 2018-11-23 14:12:48 --> Utf8 Class Initialized
INFO - 2018-11-23 14:12:48 --> URI Class Initialized
INFO - 2018-11-23 14:12:48 --> Router Class Initialized
INFO - 2018-11-23 14:12:48 --> Output Class Initialized
INFO - 2018-11-23 14:12:48 --> Security Class Initialized
DEBUG - 2018-11-23 14:12:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-23 14:12:48 --> Input Class Initialized
INFO - 2018-11-23 14:12:48 --> Language Class Initialized
INFO - 2018-11-23 14:12:48 --> Loader Class Initialized
INFO - 2018-11-23 14:12:48 --> Helper loaded: url_helper
INFO - 2018-11-23 14:12:48 --> Helper loaded: file_helper
INFO - 2018-11-23 14:12:48 --> Helper loaded: email_helper
INFO - 2018-11-23 14:12:48 --> Helper loaded: common_helper
INFO - 2018-11-23 14:12:48 --> Database Driver Class Initialized
DEBUG - 2018-11-23 14:12:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-23 14:12:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-23 14:12:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-23 14:12:48 --> Pagination Class Initialized
INFO - 2018-11-23 14:12:48 --> Helper loaded: form_helper
INFO - 2018-11-23 14:12:48 --> Form Validation Class Initialized
INFO - 2018-11-23 14:12:48 --> Model Class Initialized
INFO - 2018-11-23 14:12:48 --> Controller Class Initialized
INFO - 2018-11-23 14:12:48 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-23 14:12:48 --> Model Class Initialized
INFO - 2018-11-23 14:12:48 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-23 14:12:48 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/sidebar.php
INFO - 2018-11-23 14:12:48 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/right-sidebar.php
INFO - 2018-11-23 14:12:48 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/footer.php
INFO - 2018-11-23 14:12:48 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/dashboard.php
INFO - 2018-11-23 14:12:48 --> Final output sent to browser
DEBUG - 2018-11-23 14:12:48 --> Total execution time: 0.0620
INFO - 2018-11-23 14:13:56 --> Config Class Initialized
INFO - 2018-11-23 14:13:56 --> Hooks Class Initialized
DEBUG - 2018-11-23 14:13:56 --> UTF-8 Support Enabled
INFO - 2018-11-23 14:13:56 --> Utf8 Class Initialized
INFO - 2018-11-23 14:13:56 --> URI Class Initialized
INFO - 2018-11-23 14:13:56 --> Router Class Initialized
INFO - 2018-11-23 14:13:56 --> Output Class Initialized
INFO - 2018-11-23 14:13:56 --> Security Class Initialized
DEBUG - 2018-11-23 14:13:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-23 14:13:56 --> Input Class Initialized
INFO - 2018-11-23 14:13:56 --> Language Class Initialized
INFO - 2018-11-23 14:13:56 --> Loader Class Initialized
INFO - 2018-11-23 14:13:56 --> Helper loaded: url_helper
INFO - 2018-11-23 14:13:56 --> Helper loaded: file_helper
INFO - 2018-11-23 14:13:56 --> Helper loaded: email_helper
INFO - 2018-11-23 14:13:56 --> Helper loaded: common_helper
INFO - 2018-11-23 14:13:56 --> Database Driver Class Initialized
DEBUG - 2018-11-23 14:13:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-23 14:13:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-23 14:13:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-23 14:13:56 --> Pagination Class Initialized
INFO - 2018-11-23 14:13:56 --> Helper loaded: form_helper
INFO - 2018-11-23 14:13:56 --> Form Validation Class Initialized
INFO - 2018-11-23 14:13:56 --> Model Class Initialized
INFO - 2018-11-23 14:13:56 --> Controller Class Initialized
INFO - 2018-11-23 14:13:56 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-23 14:13:56 --> Model Class Initialized
INFO - 2018-11-23 14:13:56 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-23 14:13:56 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/sidebar.php
INFO - 2018-11-23 14:13:56 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/right-sidebar.php
INFO - 2018-11-23 14:13:56 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/footer.php
INFO - 2018-11-23 14:13:56 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/dashboard.php
INFO - 2018-11-23 14:13:56 --> Final output sent to browser
DEBUG - 2018-11-23 14:13:56 --> Total execution time: 0.0620
INFO - 2018-11-23 14:14:35 --> Config Class Initialized
INFO - 2018-11-23 14:14:35 --> Hooks Class Initialized
DEBUG - 2018-11-23 14:14:35 --> UTF-8 Support Enabled
INFO - 2018-11-23 14:14:35 --> Utf8 Class Initialized
INFO - 2018-11-23 14:14:35 --> URI Class Initialized
INFO - 2018-11-23 14:14:35 --> Router Class Initialized
INFO - 2018-11-23 14:14:35 --> Output Class Initialized
INFO - 2018-11-23 14:14:35 --> Security Class Initialized
DEBUG - 2018-11-23 14:14:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-23 14:14:35 --> Input Class Initialized
INFO - 2018-11-23 14:14:35 --> Language Class Initialized
INFO - 2018-11-23 14:14:35 --> Loader Class Initialized
INFO - 2018-11-23 14:14:35 --> Helper loaded: url_helper
INFO - 2018-11-23 14:14:35 --> Helper loaded: file_helper
INFO - 2018-11-23 14:14:35 --> Helper loaded: email_helper
INFO - 2018-11-23 14:14:35 --> Helper loaded: common_helper
INFO - 2018-11-23 14:14:35 --> Database Driver Class Initialized
DEBUG - 2018-11-23 14:14:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-23 14:14:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-23 14:14:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-23 14:14:35 --> Pagination Class Initialized
INFO - 2018-11-23 14:14:35 --> Helper loaded: form_helper
INFO - 2018-11-23 14:14:35 --> Form Validation Class Initialized
INFO - 2018-11-23 14:14:35 --> Model Class Initialized
INFO - 2018-11-23 14:14:35 --> Controller Class Initialized
INFO - 2018-11-23 14:14:35 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-23 14:14:35 --> Model Class Initialized
INFO - 2018-11-23 14:14:35 --> Model Class Initialized
INFO - 2018-11-23 14:14:35 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-23 14:14:35 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/change-password.php
INFO - 2018-11-23 14:14:35 --> Final output sent to browser
DEBUG - 2018-11-23 14:14:35 --> Total execution time: 0.0570
INFO - 2018-11-23 14:14:36 --> Config Class Initialized
INFO - 2018-11-23 14:14:36 --> Hooks Class Initialized
DEBUG - 2018-11-23 14:14:36 --> UTF-8 Support Enabled
INFO - 2018-11-23 14:14:36 --> Utf8 Class Initialized
INFO - 2018-11-23 14:14:36 --> URI Class Initialized
INFO - 2018-11-23 14:14:36 --> Router Class Initialized
INFO - 2018-11-23 14:14:36 --> Output Class Initialized
INFO - 2018-11-23 14:14:36 --> Security Class Initialized
DEBUG - 2018-11-23 14:14:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-23 14:14:36 --> Input Class Initialized
INFO - 2018-11-23 14:14:36 --> Language Class Initialized
ERROR - 2018-11-23 14:14:36 --> 404 Page Not Found: Plugins/images
INFO - 2018-11-23 14:15:47 --> Config Class Initialized
INFO - 2018-11-23 14:15:47 --> Hooks Class Initialized
DEBUG - 2018-11-23 14:15:47 --> UTF-8 Support Enabled
INFO - 2018-11-23 14:15:47 --> Utf8 Class Initialized
INFO - 2018-11-23 14:15:47 --> URI Class Initialized
INFO - 2018-11-23 14:15:47 --> Router Class Initialized
INFO - 2018-11-23 14:15:47 --> Output Class Initialized
INFO - 2018-11-23 14:15:47 --> Security Class Initialized
DEBUG - 2018-11-23 14:15:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-23 14:15:47 --> Input Class Initialized
INFO - 2018-11-23 14:15:47 --> Language Class Initialized
INFO - 2018-11-23 14:15:47 --> Loader Class Initialized
INFO - 2018-11-23 14:15:47 --> Helper loaded: url_helper
INFO - 2018-11-23 14:15:47 --> Helper loaded: file_helper
INFO - 2018-11-23 14:15:47 --> Helper loaded: email_helper
INFO - 2018-11-23 14:15:47 --> Helper loaded: common_helper
INFO - 2018-11-23 14:15:47 --> Database Driver Class Initialized
DEBUG - 2018-11-23 14:15:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-23 14:15:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-23 14:15:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-23 14:15:47 --> Pagination Class Initialized
INFO - 2018-11-23 14:15:47 --> Helper loaded: form_helper
INFO - 2018-11-23 14:15:47 --> Form Validation Class Initialized
INFO - 2018-11-23 14:15:47 --> Model Class Initialized
INFO - 2018-11-23 14:15:47 --> Controller Class Initialized
INFO - 2018-11-23 14:15:47 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-23 14:15:47 --> Model Class Initialized
INFO - 2018-11-23 14:15:47 --> Model Class Initialized
INFO - 2018-11-23 14:15:47 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-23 14:15:47 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/change-password.php
INFO - 2018-11-23 14:15:47 --> Final output sent to browser
DEBUG - 2018-11-23 14:15:47 --> Total execution time: 0.0670
INFO - 2018-11-23 14:15:48 --> Config Class Initialized
INFO - 2018-11-23 14:15:48 --> Hooks Class Initialized
DEBUG - 2018-11-23 14:15:48 --> UTF-8 Support Enabled
INFO - 2018-11-23 14:15:48 --> Utf8 Class Initialized
INFO - 2018-11-23 14:15:48 --> URI Class Initialized
INFO - 2018-11-23 14:15:48 --> Router Class Initialized
INFO - 2018-11-23 14:15:48 --> Output Class Initialized
INFO - 2018-11-23 14:15:48 --> Security Class Initialized
DEBUG - 2018-11-23 14:15:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-23 14:15:48 --> Input Class Initialized
INFO - 2018-11-23 14:15:48 --> Language Class Initialized
ERROR - 2018-11-23 14:15:48 --> 404 Page Not Found: Plugins/images
INFO - 2018-11-23 14:17:44 --> Config Class Initialized
INFO - 2018-11-23 14:17:44 --> Hooks Class Initialized
DEBUG - 2018-11-23 14:17:44 --> UTF-8 Support Enabled
INFO - 2018-11-23 14:17:44 --> Utf8 Class Initialized
INFO - 2018-11-23 14:17:44 --> URI Class Initialized
INFO - 2018-11-23 14:17:44 --> Router Class Initialized
INFO - 2018-11-23 14:17:44 --> Output Class Initialized
INFO - 2018-11-23 14:17:44 --> Security Class Initialized
DEBUG - 2018-11-23 14:17:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-23 14:17:44 --> Input Class Initialized
INFO - 2018-11-23 14:17:44 --> Language Class Initialized
INFO - 2018-11-23 14:17:44 --> Loader Class Initialized
INFO - 2018-11-23 14:17:44 --> Helper loaded: url_helper
INFO - 2018-11-23 14:17:44 --> Helper loaded: file_helper
INFO - 2018-11-23 14:17:44 --> Helper loaded: email_helper
INFO - 2018-11-23 14:17:44 --> Helper loaded: common_helper
INFO - 2018-11-23 14:17:44 --> Database Driver Class Initialized
DEBUG - 2018-11-23 14:17:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-23 14:17:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-23 14:17:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-23 14:17:44 --> Pagination Class Initialized
INFO - 2018-11-23 14:17:44 --> Helper loaded: form_helper
INFO - 2018-11-23 14:17:44 --> Form Validation Class Initialized
INFO - 2018-11-23 14:17:44 --> Model Class Initialized
INFO - 2018-11-23 14:17:44 --> Controller Class Initialized
INFO - 2018-11-23 14:17:44 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-23 14:17:44 --> Model Class Initialized
INFO - 2018-11-23 14:17:44 --> Model Class Initialized
INFO - 2018-11-23 14:17:44 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-23 14:17:44 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/change-password.php
INFO - 2018-11-23 14:17:44 --> Final output sent to browser
DEBUG - 2018-11-23 14:17:44 --> Total execution time: 0.0530
INFO - 2018-11-23 14:17:45 --> Config Class Initialized
INFO - 2018-11-23 14:17:45 --> Hooks Class Initialized
DEBUG - 2018-11-23 14:17:45 --> UTF-8 Support Enabled
INFO - 2018-11-23 14:17:45 --> Utf8 Class Initialized
INFO - 2018-11-23 14:17:45 --> URI Class Initialized
INFO - 2018-11-23 14:17:45 --> Router Class Initialized
INFO - 2018-11-23 14:17:45 --> Output Class Initialized
INFO - 2018-11-23 14:17:45 --> Security Class Initialized
DEBUG - 2018-11-23 14:17:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-23 14:17:45 --> Input Class Initialized
INFO - 2018-11-23 14:17:45 --> Language Class Initialized
ERROR - 2018-11-23 14:17:45 --> 404 Page Not Found: Plugins/images
INFO - 2018-11-23 14:18:09 --> Config Class Initialized
INFO - 2018-11-23 14:18:09 --> Hooks Class Initialized
DEBUG - 2018-11-23 14:18:09 --> UTF-8 Support Enabled
INFO - 2018-11-23 14:18:09 --> Utf8 Class Initialized
INFO - 2018-11-23 14:18:09 --> URI Class Initialized
INFO - 2018-11-23 14:18:09 --> Router Class Initialized
INFO - 2018-11-23 14:18:09 --> Output Class Initialized
INFO - 2018-11-23 14:18:09 --> Security Class Initialized
DEBUG - 2018-11-23 14:18:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-23 14:18:09 --> Input Class Initialized
INFO - 2018-11-23 14:18:09 --> Language Class Initialized
INFO - 2018-11-23 14:18:09 --> Loader Class Initialized
INFO - 2018-11-23 14:18:09 --> Helper loaded: url_helper
INFO - 2018-11-23 14:18:09 --> Helper loaded: file_helper
INFO - 2018-11-23 14:18:09 --> Helper loaded: email_helper
INFO - 2018-11-23 14:18:09 --> Helper loaded: common_helper
INFO - 2018-11-23 14:18:09 --> Database Driver Class Initialized
DEBUG - 2018-11-23 14:18:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-23 14:18:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-23 14:18:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-23 14:18:09 --> Pagination Class Initialized
INFO - 2018-11-23 14:18:09 --> Helper loaded: form_helper
INFO - 2018-11-23 14:18:09 --> Form Validation Class Initialized
INFO - 2018-11-23 14:18:09 --> Model Class Initialized
INFO - 2018-11-23 14:18:09 --> Controller Class Initialized
INFO - 2018-11-23 14:18:09 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-23 14:18:09 --> Model Class Initialized
INFO - 2018-11-23 14:18:09 --> Model Class Initialized
INFO - 2018-11-23 14:18:09 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-23 14:18:09 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/change-password.php
INFO - 2018-11-23 14:18:09 --> Final output sent to browser
DEBUG - 2018-11-23 14:18:09 --> Total execution time: 0.0966
INFO - 2018-11-23 14:18:10 --> Config Class Initialized
INFO - 2018-11-23 14:18:10 --> Hooks Class Initialized
DEBUG - 2018-11-23 14:18:10 --> UTF-8 Support Enabled
INFO - 2018-11-23 14:18:10 --> Utf8 Class Initialized
INFO - 2018-11-23 14:18:10 --> URI Class Initialized
INFO - 2018-11-23 14:18:10 --> Router Class Initialized
INFO - 2018-11-23 14:18:10 --> Output Class Initialized
INFO - 2018-11-23 14:18:10 --> Security Class Initialized
DEBUG - 2018-11-23 14:18:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-23 14:18:10 --> Input Class Initialized
INFO - 2018-11-23 14:18:10 --> Language Class Initialized
ERROR - 2018-11-23 14:18:10 --> 404 Page Not Found: Plugins/images
INFO - 2018-11-23 14:18:42 --> Config Class Initialized
INFO - 2018-11-23 14:18:42 --> Hooks Class Initialized
DEBUG - 2018-11-23 14:18:42 --> UTF-8 Support Enabled
INFO - 2018-11-23 14:18:42 --> Utf8 Class Initialized
INFO - 2018-11-23 14:18:42 --> URI Class Initialized
INFO - 2018-11-23 14:18:42 --> Router Class Initialized
INFO - 2018-11-23 14:18:42 --> Output Class Initialized
INFO - 2018-11-23 14:18:42 --> Security Class Initialized
DEBUG - 2018-11-23 14:18:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-23 14:18:42 --> Input Class Initialized
INFO - 2018-11-23 14:18:42 --> Language Class Initialized
INFO - 2018-11-23 14:18:42 --> Loader Class Initialized
INFO - 2018-11-23 14:18:42 --> Helper loaded: url_helper
INFO - 2018-11-23 14:18:42 --> Helper loaded: file_helper
INFO - 2018-11-23 14:18:42 --> Helper loaded: email_helper
INFO - 2018-11-23 14:18:42 --> Helper loaded: common_helper
INFO - 2018-11-23 14:18:42 --> Database Driver Class Initialized
DEBUG - 2018-11-23 14:18:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-23 14:18:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-23 14:18:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-23 14:18:42 --> Pagination Class Initialized
INFO - 2018-11-23 14:18:42 --> Helper loaded: form_helper
INFO - 2018-11-23 14:18:42 --> Form Validation Class Initialized
INFO - 2018-11-23 14:18:42 --> Model Class Initialized
INFO - 2018-11-23 14:18:42 --> Controller Class Initialized
INFO - 2018-11-23 14:18:42 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-23 14:18:42 --> Model Class Initialized
INFO - 2018-11-23 14:18:42 --> Model Class Initialized
INFO - 2018-11-23 14:18:42 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-23 14:18:42 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/change-password.php
INFO - 2018-11-23 14:18:42 --> Final output sent to browser
DEBUG - 2018-11-23 14:18:42 --> Total execution time: 0.0676
INFO - 2018-11-23 14:18:43 --> Config Class Initialized
INFO - 2018-11-23 14:18:43 --> Hooks Class Initialized
DEBUG - 2018-11-23 14:18:43 --> UTF-8 Support Enabled
INFO - 2018-11-23 14:18:43 --> Utf8 Class Initialized
INFO - 2018-11-23 14:18:43 --> URI Class Initialized
INFO - 2018-11-23 14:18:43 --> Router Class Initialized
INFO - 2018-11-23 14:18:43 --> Output Class Initialized
INFO - 2018-11-23 14:18:43 --> Security Class Initialized
DEBUG - 2018-11-23 14:18:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-23 14:18:43 --> Input Class Initialized
INFO - 2018-11-23 14:18:43 --> Language Class Initialized
ERROR - 2018-11-23 14:18:43 --> 404 Page Not Found: Plugins/images
INFO - 2018-11-23 14:20:00 --> Config Class Initialized
INFO - 2018-11-23 14:20:00 --> Hooks Class Initialized
DEBUG - 2018-11-23 14:20:00 --> UTF-8 Support Enabled
INFO - 2018-11-23 14:20:00 --> Utf8 Class Initialized
INFO - 2018-11-23 14:20:00 --> URI Class Initialized
INFO - 2018-11-23 14:20:00 --> Router Class Initialized
INFO - 2018-11-23 14:20:00 --> Output Class Initialized
INFO - 2018-11-23 14:20:00 --> Security Class Initialized
DEBUG - 2018-11-23 14:20:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-23 14:20:00 --> Input Class Initialized
INFO - 2018-11-23 14:20:00 --> Language Class Initialized
INFO - 2018-11-23 14:20:00 --> Loader Class Initialized
INFO - 2018-11-23 14:20:00 --> Helper loaded: url_helper
INFO - 2018-11-23 14:20:00 --> Helper loaded: file_helper
INFO - 2018-11-23 14:20:00 --> Helper loaded: email_helper
INFO - 2018-11-23 14:20:00 --> Helper loaded: common_helper
INFO - 2018-11-23 14:20:00 --> Database Driver Class Initialized
DEBUG - 2018-11-23 14:20:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-23 14:20:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-23 14:20:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-23 14:20:00 --> Pagination Class Initialized
INFO - 2018-11-23 14:20:00 --> Helper loaded: form_helper
INFO - 2018-11-23 14:20:00 --> Form Validation Class Initialized
INFO - 2018-11-23 14:20:00 --> Model Class Initialized
INFO - 2018-11-23 14:20:00 --> Controller Class Initialized
INFO - 2018-11-23 14:20:00 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-23 14:20:00 --> Model Class Initialized
INFO - 2018-11-23 14:20:00 --> Model Class Initialized
INFO - 2018-11-23 14:20:00 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-23 14:20:00 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/change-password.php
INFO - 2018-11-23 14:20:00 --> Final output sent to browser
DEBUG - 2018-11-23 14:20:00 --> Total execution time: 0.0876
INFO - 2018-11-23 14:20:01 --> Config Class Initialized
INFO - 2018-11-23 14:20:01 --> Hooks Class Initialized
DEBUG - 2018-11-23 14:20:01 --> UTF-8 Support Enabled
INFO - 2018-11-23 14:20:01 --> Utf8 Class Initialized
INFO - 2018-11-23 14:20:01 --> URI Class Initialized
INFO - 2018-11-23 14:20:01 --> Router Class Initialized
INFO - 2018-11-23 14:20:01 --> Output Class Initialized
INFO - 2018-11-23 14:20:01 --> Security Class Initialized
DEBUG - 2018-11-23 14:20:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-23 14:20:01 --> Input Class Initialized
INFO - 2018-11-23 14:20:01 --> Language Class Initialized
ERROR - 2018-11-23 14:20:01 --> 404 Page Not Found: Plugins/images
INFO - 2018-11-23 14:21:59 --> Config Class Initialized
INFO - 2018-11-23 14:21:59 --> Hooks Class Initialized
DEBUG - 2018-11-23 14:21:59 --> UTF-8 Support Enabled
INFO - 2018-11-23 14:21:59 --> Utf8 Class Initialized
INFO - 2018-11-23 14:21:59 --> URI Class Initialized
INFO - 2018-11-23 14:21:59 --> Router Class Initialized
INFO - 2018-11-23 14:21:59 --> Output Class Initialized
INFO - 2018-11-23 14:21:59 --> Security Class Initialized
DEBUG - 2018-11-23 14:21:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-23 14:21:59 --> Input Class Initialized
INFO - 2018-11-23 14:21:59 --> Language Class Initialized
INFO - 2018-11-23 14:21:59 --> Loader Class Initialized
INFO - 2018-11-23 14:21:59 --> Helper loaded: url_helper
INFO - 2018-11-23 14:21:59 --> Helper loaded: file_helper
INFO - 2018-11-23 14:21:59 --> Helper loaded: email_helper
INFO - 2018-11-23 14:21:59 --> Helper loaded: common_helper
INFO - 2018-11-23 14:21:59 --> Database Driver Class Initialized
DEBUG - 2018-11-23 14:21:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-23 14:21:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-23 14:21:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-23 14:21:59 --> Pagination Class Initialized
INFO - 2018-11-23 14:21:59 --> Helper loaded: form_helper
INFO - 2018-11-23 14:21:59 --> Form Validation Class Initialized
INFO - 2018-11-23 14:21:59 --> Model Class Initialized
INFO - 2018-11-23 14:21:59 --> Controller Class Initialized
INFO - 2018-11-23 14:21:59 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-23 14:21:59 --> Model Class Initialized
INFO - 2018-11-23 14:21:59 --> Model Class Initialized
INFO - 2018-11-23 14:21:59 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-23 14:21:59 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/change-password.php
INFO - 2018-11-23 14:21:59 --> Final output sent to browser
DEBUG - 2018-11-23 14:21:59 --> Total execution time: 0.0430
INFO - 2018-11-23 14:22:00 --> Config Class Initialized
INFO - 2018-11-23 14:22:00 --> Hooks Class Initialized
DEBUG - 2018-11-23 14:22:00 --> UTF-8 Support Enabled
INFO - 2018-11-23 14:22:00 --> Utf8 Class Initialized
INFO - 2018-11-23 14:22:00 --> URI Class Initialized
INFO - 2018-11-23 14:22:00 --> Router Class Initialized
INFO - 2018-11-23 14:22:00 --> Output Class Initialized
INFO - 2018-11-23 14:22:00 --> Security Class Initialized
DEBUG - 2018-11-23 14:22:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-23 14:22:00 --> Input Class Initialized
INFO - 2018-11-23 14:22:00 --> Language Class Initialized
INFO - 2018-11-23 14:22:00 --> Loader Class Initialized
INFO - 2018-11-23 14:22:00 --> Helper loaded: url_helper
INFO - 2018-11-23 14:22:00 --> Helper loaded: file_helper
INFO - 2018-11-23 14:22:00 --> Helper loaded: email_helper
INFO - 2018-11-23 14:22:00 --> Helper loaded: common_helper
INFO - 2018-11-23 14:22:00 --> Database Driver Class Initialized
DEBUG - 2018-11-23 14:22:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-23 14:22:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-23 14:22:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-23 14:22:00 --> Pagination Class Initialized
INFO - 2018-11-23 14:22:00 --> Helper loaded: form_helper
INFO - 2018-11-23 14:22:00 --> Form Validation Class Initialized
INFO - 2018-11-23 14:22:00 --> Model Class Initialized
INFO - 2018-11-23 14:22:00 --> Controller Class Initialized
INFO - 2018-11-23 14:22:00 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-23 14:22:00 --> Model Class Initialized
INFO - 2018-11-23 14:22:00 --> Model Class Initialized
INFO - 2018-11-23 14:22:00 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-23 14:22:00 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/change-password.php
INFO - 2018-11-23 14:22:00 --> Final output sent to browser
DEBUG - 2018-11-23 14:22:00 --> Total execution time: 0.0620
INFO - 2018-11-23 14:22:00 --> Config Class Initialized
INFO - 2018-11-23 14:22:00 --> Hooks Class Initialized
DEBUG - 2018-11-23 14:22:00 --> UTF-8 Support Enabled
INFO - 2018-11-23 14:22:00 --> Utf8 Class Initialized
INFO - 2018-11-23 14:22:00 --> URI Class Initialized
INFO - 2018-11-23 14:22:00 --> Router Class Initialized
INFO - 2018-11-23 14:22:00 --> Output Class Initialized
INFO - 2018-11-23 14:22:00 --> Security Class Initialized
DEBUG - 2018-11-23 14:22:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-23 14:22:00 --> Input Class Initialized
INFO - 2018-11-23 14:22:00 --> Language Class Initialized
INFO - 2018-11-23 14:22:00 --> Loader Class Initialized
INFO - 2018-11-23 14:22:00 --> Helper loaded: url_helper
INFO - 2018-11-23 14:22:00 --> Helper loaded: file_helper
INFO - 2018-11-23 14:22:00 --> Helper loaded: email_helper
INFO - 2018-11-23 14:22:00 --> Helper loaded: common_helper
INFO - 2018-11-23 14:22:00 --> Database Driver Class Initialized
DEBUG - 2018-11-23 14:22:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-23 14:22:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-23 14:22:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-23 14:22:00 --> Pagination Class Initialized
INFO - 2018-11-23 14:22:00 --> Helper loaded: form_helper
INFO - 2018-11-23 14:22:00 --> Form Validation Class Initialized
INFO - 2018-11-23 14:22:00 --> Model Class Initialized
INFO - 2018-11-23 14:22:00 --> Controller Class Initialized
INFO - 2018-11-23 14:22:00 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-23 14:22:00 --> Model Class Initialized
INFO - 2018-11-23 14:22:00 --> Model Class Initialized
INFO - 2018-11-23 14:22:00 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-23 14:22:00 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/change-password.php
INFO - 2018-11-23 14:22:00 --> Final output sent to browser
DEBUG - 2018-11-23 14:22:00 --> Total execution time: 0.0490
INFO - 2018-11-23 14:22:00 --> Config Class Initialized
INFO - 2018-11-23 14:22:00 --> Hooks Class Initialized
DEBUG - 2018-11-23 14:22:00 --> UTF-8 Support Enabled
INFO - 2018-11-23 14:22:00 --> Utf8 Class Initialized
INFO - 2018-11-23 14:22:00 --> URI Class Initialized
INFO - 2018-11-23 14:22:00 --> Router Class Initialized
INFO - 2018-11-23 14:22:00 --> Output Class Initialized
INFO - 2018-11-23 14:22:00 --> Security Class Initialized
DEBUG - 2018-11-23 14:22:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-23 14:22:00 --> Input Class Initialized
INFO - 2018-11-23 14:22:00 --> Language Class Initialized
INFO - 2018-11-23 14:22:00 --> Loader Class Initialized
INFO - 2018-11-23 14:22:00 --> Helper loaded: url_helper
INFO - 2018-11-23 14:22:00 --> Helper loaded: file_helper
INFO - 2018-11-23 14:22:00 --> Helper loaded: email_helper
INFO - 2018-11-23 14:22:00 --> Helper loaded: common_helper
INFO - 2018-11-23 14:22:00 --> Database Driver Class Initialized
DEBUG - 2018-11-23 14:22:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-23 14:22:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-23 14:22:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-23 14:22:00 --> Pagination Class Initialized
INFO - 2018-11-23 14:22:00 --> Helper loaded: form_helper
INFO - 2018-11-23 14:22:00 --> Form Validation Class Initialized
INFO - 2018-11-23 14:22:00 --> Model Class Initialized
INFO - 2018-11-23 14:22:00 --> Controller Class Initialized
INFO - 2018-11-23 14:22:00 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-23 14:22:00 --> Model Class Initialized
INFO - 2018-11-23 14:22:00 --> Model Class Initialized
INFO - 2018-11-23 14:22:00 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-23 14:22:00 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/change-password.php
INFO - 2018-11-23 14:22:00 --> Final output sent to browser
DEBUG - 2018-11-23 14:22:00 --> Total execution time: 0.0810
INFO - 2018-11-23 14:22:01 --> Config Class Initialized
INFO - 2018-11-23 14:22:01 --> Hooks Class Initialized
DEBUG - 2018-11-23 14:22:01 --> UTF-8 Support Enabled
INFO - 2018-11-23 14:22:01 --> Utf8 Class Initialized
INFO - 2018-11-23 14:22:01 --> URI Class Initialized
INFO - 2018-11-23 14:22:01 --> Router Class Initialized
INFO - 2018-11-23 14:22:01 --> Output Class Initialized
INFO - 2018-11-23 14:22:01 --> Security Class Initialized
DEBUG - 2018-11-23 14:22:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-23 14:22:01 --> Input Class Initialized
INFO - 2018-11-23 14:22:01 --> Language Class Initialized
ERROR - 2018-11-23 14:22:01 --> 404 Page Not Found: Plugins/images
INFO - 2018-11-23 14:22:48 --> Config Class Initialized
INFO - 2018-11-23 14:22:48 --> Hooks Class Initialized
DEBUG - 2018-11-23 14:22:48 --> UTF-8 Support Enabled
INFO - 2018-11-23 14:22:48 --> Utf8 Class Initialized
INFO - 2018-11-23 14:22:48 --> URI Class Initialized
INFO - 2018-11-23 14:22:48 --> Router Class Initialized
INFO - 2018-11-23 14:22:48 --> Output Class Initialized
INFO - 2018-11-23 14:22:48 --> Security Class Initialized
DEBUG - 2018-11-23 14:22:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-23 14:22:48 --> Input Class Initialized
INFO - 2018-11-23 14:22:48 --> Language Class Initialized
INFO - 2018-11-23 14:22:48 --> Loader Class Initialized
INFO - 2018-11-23 14:22:48 --> Helper loaded: url_helper
INFO - 2018-11-23 14:22:48 --> Helper loaded: file_helper
INFO - 2018-11-23 14:22:48 --> Helper loaded: email_helper
INFO - 2018-11-23 14:22:48 --> Helper loaded: common_helper
INFO - 2018-11-23 14:22:48 --> Database Driver Class Initialized
DEBUG - 2018-11-23 14:22:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-23 14:22:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-23 14:22:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-23 14:22:48 --> Pagination Class Initialized
INFO - 2018-11-23 14:22:48 --> Helper loaded: form_helper
INFO - 2018-11-23 14:22:48 --> Form Validation Class Initialized
INFO - 2018-11-23 14:22:48 --> Model Class Initialized
INFO - 2018-11-23 14:22:48 --> Controller Class Initialized
INFO - 2018-11-23 14:22:48 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-23 14:22:48 --> Model Class Initialized
INFO - 2018-11-23 14:22:48 --> Model Class Initialized
INFO - 2018-11-23 14:22:48 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-23 14:22:48 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/change-password.php
INFO - 2018-11-23 14:22:48 --> Final output sent to browser
DEBUG - 2018-11-23 14:22:48 --> Total execution time: 0.2100
INFO - 2018-11-23 14:22:49 --> Config Class Initialized
INFO - 2018-11-23 14:22:49 --> Hooks Class Initialized
DEBUG - 2018-11-23 14:22:49 --> UTF-8 Support Enabled
INFO - 2018-11-23 14:22:49 --> Utf8 Class Initialized
INFO - 2018-11-23 14:22:49 --> URI Class Initialized
INFO - 2018-11-23 14:22:49 --> Router Class Initialized
INFO - 2018-11-23 14:22:49 --> Output Class Initialized
INFO - 2018-11-23 14:22:49 --> Security Class Initialized
DEBUG - 2018-11-23 14:22:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-23 14:22:49 --> Input Class Initialized
INFO - 2018-11-23 14:22:49 --> Language Class Initialized
ERROR - 2018-11-23 14:22:49 --> 404 Page Not Found: Plugins/images
INFO - 2018-11-23 14:23:12 --> Config Class Initialized
INFO - 2018-11-23 14:23:12 --> Hooks Class Initialized
DEBUG - 2018-11-23 14:23:12 --> UTF-8 Support Enabled
INFO - 2018-11-23 14:23:12 --> Utf8 Class Initialized
INFO - 2018-11-23 14:23:12 --> URI Class Initialized
INFO - 2018-11-23 14:23:12 --> Router Class Initialized
INFO - 2018-11-23 14:23:12 --> Output Class Initialized
INFO - 2018-11-23 14:23:12 --> Security Class Initialized
DEBUG - 2018-11-23 14:23:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-23 14:23:12 --> Input Class Initialized
INFO - 2018-11-23 14:23:12 --> Language Class Initialized
INFO - 2018-11-23 14:23:12 --> Loader Class Initialized
INFO - 2018-11-23 14:23:12 --> Helper loaded: url_helper
INFO - 2018-11-23 14:23:12 --> Helper loaded: file_helper
INFO - 2018-11-23 14:23:12 --> Helper loaded: email_helper
INFO - 2018-11-23 14:23:12 --> Helper loaded: common_helper
INFO - 2018-11-23 14:23:12 --> Database Driver Class Initialized
DEBUG - 2018-11-23 14:23:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-23 14:23:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-23 14:23:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-23 14:23:12 --> Pagination Class Initialized
INFO - 2018-11-23 14:23:12 --> Helper loaded: form_helper
INFO - 2018-11-23 14:23:12 --> Form Validation Class Initialized
INFO - 2018-11-23 14:23:12 --> Model Class Initialized
INFO - 2018-11-23 14:23:12 --> Controller Class Initialized
INFO - 2018-11-23 14:23:12 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-23 14:23:12 --> Model Class Initialized
INFO - 2018-11-23 14:23:12 --> Model Class Initialized
INFO - 2018-11-23 14:23:12 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-23 14:23:12 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/change-password.php
INFO - 2018-11-23 14:23:12 --> Final output sent to browser
DEBUG - 2018-11-23 14:23:12 --> Total execution time: 0.0830
INFO - 2018-11-23 14:24:07 --> Config Class Initialized
INFO - 2018-11-23 14:24:07 --> Hooks Class Initialized
DEBUG - 2018-11-23 14:24:07 --> UTF-8 Support Enabled
INFO - 2018-11-23 14:24:07 --> Utf8 Class Initialized
INFO - 2018-11-23 14:24:07 --> URI Class Initialized
INFO - 2018-11-23 14:24:07 --> Router Class Initialized
INFO - 2018-11-23 14:24:07 --> Output Class Initialized
INFO - 2018-11-23 14:24:07 --> Security Class Initialized
DEBUG - 2018-11-23 14:24:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-23 14:24:07 --> Input Class Initialized
INFO - 2018-11-23 14:24:07 --> Language Class Initialized
INFO - 2018-11-23 14:24:07 --> Loader Class Initialized
INFO - 2018-11-23 14:24:07 --> Helper loaded: url_helper
INFO - 2018-11-23 14:24:07 --> Helper loaded: file_helper
INFO - 2018-11-23 14:24:07 --> Helper loaded: email_helper
INFO - 2018-11-23 14:24:07 --> Helper loaded: common_helper
INFO - 2018-11-23 14:24:07 --> Database Driver Class Initialized
DEBUG - 2018-11-23 14:24:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-23 14:24:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-23 14:24:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-23 14:24:07 --> Pagination Class Initialized
INFO - 2018-11-23 14:24:07 --> Helper loaded: form_helper
INFO - 2018-11-23 14:24:07 --> Form Validation Class Initialized
INFO - 2018-11-23 14:24:07 --> Model Class Initialized
INFO - 2018-11-23 14:24:07 --> Controller Class Initialized
INFO - 2018-11-23 14:24:07 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-23 14:24:07 --> Model Class Initialized
INFO - 2018-11-23 14:24:07 --> Model Class Initialized
INFO - 2018-11-23 14:24:07 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-23 14:24:07 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/change-password.php
INFO - 2018-11-23 14:24:07 --> Final output sent to browser
DEBUG - 2018-11-23 14:24:07 --> Total execution time: 0.0600
INFO - 2018-11-23 14:24:08 --> Config Class Initialized
INFO - 2018-11-23 14:24:08 --> Hooks Class Initialized
DEBUG - 2018-11-23 14:24:08 --> UTF-8 Support Enabled
INFO - 2018-11-23 14:24:08 --> Utf8 Class Initialized
INFO - 2018-11-23 14:24:08 --> URI Class Initialized
INFO - 2018-11-23 14:24:08 --> Router Class Initialized
INFO - 2018-11-23 14:24:08 --> Output Class Initialized
INFO - 2018-11-23 14:24:08 --> Security Class Initialized
DEBUG - 2018-11-23 14:24:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-23 14:24:08 --> Input Class Initialized
INFO - 2018-11-23 14:24:08 --> Language Class Initialized
ERROR - 2018-11-23 14:24:08 --> 404 Page Not Found: Plugins/images
INFO - 2018-11-23 14:26:07 --> Config Class Initialized
INFO - 2018-11-23 14:26:07 --> Hooks Class Initialized
DEBUG - 2018-11-23 14:26:07 --> UTF-8 Support Enabled
INFO - 2018-11-23 14:26:07 --> Utf8 Class Initialized
INFO - 2018-11-23 14:26:07 --> URI Class Initialized
INFO - 2018-11-23 14:26:07 --> Router Class Initialized
INFO - 2018-11-23 14:26:07 --> Output Class Initialized
INFO - 2018-11-23 14:26:07 --> Security Class Initialized
DEBUG - 2018-11-23 14:26:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-23 14:26:07 --> Input Class Initialized
INFO - 2018-11-23 14:26:07 --> Language Class Initialized
INFO - 2018-11-23 14:26:07 --> Loader Class Initialized
INFO - 2018-11-23 14:26:07 --> Helper loaded: url_helper
INFO - 2018-11-23 14:26:07 --> Helper loaded: file_helper
INFO - 2018-11-23 14:26:07 --> Helper loaded: email_helper
INFO - 2018-11-23 14:26:07 --> Helper loaded: common_helper
INFO - 2018-11-23 14:26:07 --> Database Driver Class Initialized
DEBUG - 2018-11-23 14:26:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-23 14:26:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-23 14:26:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-23 14:26:07 --> Pagination Class Initialized
INFO - 2018-11-23 14:26:07 --> Helper loaded: form_helper
INFO - 2018-11-23 14:26:07 --> Form Validation Class Initialized
INFO - 2018-11-23 14:26:07 --> Model Class Initialized
INFO - 2018-11-23 14:26:07 --> Controller Class Initialized
INFO - 2018-11-23 14:26:07 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-23 14:26:07 --> Model Class Initialized
INFO - 2018-11-23 14:26:07 --> Model Class Initialized
INFO - 2018-11-23 14:26:07 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-23 14:26:07 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/change-password.php
INFO - 2018-11-23 14:26:07 --> Final output sent to browser
DEBUG - 2018-11-23 14:26:07 --> Total execution time: 0.0620
INFO - 2018-11-23 14:26:08 --> Config Class Initialized
INFO - 2018-11-23 14:26:08 --> Hooks Class Initialized
DEBUG - 2018-11-23 14:26:08 --> UTF-8 Support Enabled
INFO - 2018-11-23 14:26:08 --> Utf8 Class Initialized
INFO - 2018-11-23 14:26:08 --> URI Class Initialized
INFO - 2018-11-23 14:26:08 --> Router Class Initialized
INFO - 2018-11-23 14:26:08 --> Output Class Initialized
INFO - 2018-11-23 14:26:08 --> Security Class Initialized
DEBUG - 2018-11-23 14:26:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-23 14:26:08 --> Input Class Initialized
INFO - 2018-11-23 14:26:08 --> Language Class Initialized
ERROR - 2018-11-23 14:26:08 --> 404 Page Not Found: Plugins/images
INFO - 2018-11-23 14:28:32 --> Config Class Initialized
INFO - 2018-11-23 14:28:32 --> Hooks Class Initialized
DEBUG - 2018-11-23 14:28:32 --> UTF-8 Support Enabled
INFO - 2018-11-23 14:28:32 --> Utf8 Class Initialized
INFO - 2018-11-23 14:28:32 --> URI Class Initialized
INFO - 2018-11-23 14:28:32 --> Router Class Initialized
INFO - 2018-11-23 14:28:32 --> Output Class Initialized
INFO - 2018-11-23 14:28:32 --> Security Class Initialized
DEBUG - 2018-11-23 14:28:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-23 14:28:32 --> Input Class Initialized
INFO - 2018-11-23 14:28:32 --> Language Class Initialized
INFO - 2018-11-23 14:28:32 --> Loader Class Initialized
INFO - 2018-11-23 14:28:32 --> Helper loaded: url_helper
INFO - 2018-11-23 14:28:32 --> Helper loaded: file_helper
INFO - 2018-11-23 14:28:32 --> Helper loaded: email_helper
INFO - 2018-11-23 14:28:32 --> Helper loaded: common_helper
INFO - 2018-11-23 14:28:32 --> Database Driver Class Initialized
DEBUG - 2018-11-23 14:28:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-23 14:28:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-23 14:28:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-23 14:28:32 --> Pagination Class Initialized
INFO - 2018-11-23 14:28:32 --> Helper loaded: form_helper
INFO - 2018-11-23 14:28:32 --> Form Validation Class Initialized
INFO - 2018-11-23 14:28:32 --> Model Class Initialized
INFO - 2018-11-23 14:28:32 --> Controller Class Initialized
INFO - 2018-11-23 14:28:32 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-23 14:28:32 --> Model Class Initialized
INFO - 2018-11-23 14:28:32 --> Model Class Initialized
INFO - 2018-11-23 14:28:32 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-23 14:28:32 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/change-password.php
INFO - 2018-11-23 14:28:32 --> Final output sent to browser
DEBUG - 2018-11-23 14:28:32 --> Total execution time: 0.0596
INFO - 2018-11-23 14:28:41 --> Config Class Initialized
INFO - 2018-11-23 14:28:41 --> Hooks Class Initialized
DEBUG - 2018-11-23 14:28:41 --> UTF-8 Support Enabled
INFO - 2018-11-23 14:28:41 --> Utf8 Class Initialized
INFO - 2018-11-23 14:28:41 --> URI Class Initialized
INFO - 2018-11-23 14:28:41 --> Router Class Initialized
INFO - 2018-11-23 14:28:41 --> Output Class Initialized
INFO - 2018-11-23 14:28:41 --> Security Class Initialized
DEBUG - 2018-11-23 14:28:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-23 14:28:41 --> Input Class Initialized
INFO - 2018-11-23 14:28:41 --> Language Class Initialized
INFO - 2018-11-23 14:28:41 --> Loader Class Initialized
INFO - 2018-11-23 14:28:41 --> Helper loaded: url_helper
INFO - 2018-11-23 14:28:41 --> Helper loaded: file_helper
INFO - 2018-11-23 14:28:41 --> Helper loaded: email_helper
INFO - 2018-11-23 14:28:41 --> Helper loaded: common_helper
INFO - 2018-11-23 14:28:41 --> Database Driver Class Initialized
DEBUG - 2018-11-23 14:28:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-23 14:28:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-23 14:28:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-23 14:28:41 --> Pagination Class Initialized
INFO - 2018-11-23 14:28:41 --> Helper loaded: form_helper
INFO - 2018-11-23 14:28:41 --> Form Validation Class Initialized
INFO - 2018-11-23 14:28:41 --> Model Class Initialized
INFO - 2018-11-23 14:28:41 --> Controller Class Initialized
INFO - 2018-11-23 14:28:41 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-23 14:28:41 --> Model Class Initialized
INFO - 2018-11-23 14:28:41 --> Model Class Initialized
INFO - 2018-11-23 14:28:41 --> Config Class Initialized
INFO - 2018-11-23 14:28:41 --> Hooks Class Initialized
DEBUG - 2018-11-23 14:28:41 --> UTF-8 Support Enabled
INFO - 2018-11-23 14:28:41 --> Utf8 Class Initialized
INFO - 2018-11-23 14:28:41 --> URI Class Initialized
INFO - 2018-11-23 14:28:41 --> Router Class Initialized
INFO - 2018-11-23 14:28:41 --> Output Class Initialized
INFO - 2018-11-23 14:28:41 --> Security Class Initialized
DEBUG - 2018-11-23 14:28:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-23 14:28:41 --> Input Class Initialized
INFO - 2018-11-23 14:28:41 --> Language Class Initialized
INFO - 2018-11-23 14:28:41 --> Loader Class Initialized
INFO - 2018-11-23 14:28:41 --> Helper loaded: url_helper
INFO - 2018-11-23 14:28:41 --> Helper loaded: file_helper
INFO - 2018-11-23 14:28:41 --> Helper loaded: email_helper
INFO - 2018-11-23 14:28:41 --> Helper loaded: common_helper
INFO - 2018-11-23 14:28:41 --> Database Driver Class Initialized
DEBUG - 2018-11-23 14:28:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-23 14:28:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-23 14:28:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-23 14:28:41 --> Pagination Class Initialized
INFO - 2018-11-23 14:28:41 --> Helper loaded: form_helper
INFO - 2018-11-23 14:28:41 --> Form Validation Class Initialized
INFO - 2018-11-23 14:28:41 --> Model Class Initialized
INFO - 2018-11-23 14:28:41 --> Controller Class Initialized
INFO - 2018-11-23 14:28:41 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-23 14:28:41 --> Model Class Initialized
INFO - 2018-11-23 14:28:41 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-23 14:28:41 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/sidebar.php
INFO - 2018-11-23 14:28:41 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/right-sidebar.php
INFO - 2018-11-23 14:28:41 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/footer.php
INFO - 2018-11-23 14:28:41 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/dashboard.php
INFO - 2018-11-23 14:28:41 --> Final output sent to browser
DEBUG - 2018-11-23 14:28:41 --> Total execution time: 0.0450
INFO - 2018-11-23 14:28:45 --> Config Class Initialized
INFO - 2018-11-23 14:28:45 --> Hooks Class Initialized
DEBUG - 2018-11-23 14:28:45 --> UTF-8 Support Enabled
INFO - 2018-11-23 14:28:45 --> Utf8 Class Initialized
INFO - 2018-11-23 14:28:45 --> URI Class Initialized
INFO - 2018-11-23 14:28:45 --> Router Class Initialized
INFO - 2018-11-23 14:28:45 --> Output Class Initialized
INFO - 2018-11-23 14:28:45 --> Security Class Initialized
DEBUG - 2018-11-23 14:28:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-23 14:28:45 --> Input Class Initialized
INFO - 2018-11-23 14:28:45 --> Language Class Initialized
INFO - 2018-11-23 14:28:45 --> Loader Class Initialized
INFO - 2018-11-23 14:28:45 --> Helper loaded: url_helper
INFO - 2018-11-23 14:28:45 --> Helper loaded: file_helper
INFO - 2018-11-23 14:28:45 --> Helper loaded: email_helper
INFO - 2018-11-23 14:28:45 --> Helper loaded: common_helper
INFO - 2018-11-23 14:28:45 --> Database Driver Class Initialized
DEBUG - 2018-11-23 14:28:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-23 14:28:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-23 14:28:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-23 14:28:45 --> Pagination Class Initialized
INFO - 2018-11-23 14:28:45 --> Helper loaded: form_helper
INFO - 2018-11-23 14:28:45 --> Form Validation Class Initialized
INFO - 2018-11-23 14:28:45 --> Model Class Initialized
INFO - 2018-11-23 14:28:45 --> Controller Class Initialized
INFO - 2018-11-23 14:28:45 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-23 14:28:45 --> Model Class Initialized
INFO - 2018-11-23 14:28:45 --> Model Class Initialized
INFO - 2018-11-23 14:28:45 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-23 14:28:45 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/change-password.php
INFO - 2018-11-23 14:28:45 --> Final output sent to browser
DEBUG - 2018-11-23 14:28:45 --> Total execution time: 0.0640
INFO - 2018-11-23 14:29:17 --> Config Class Initialized
INFO - 2018-11-23 14:29:17 --> Hooks Class Initialized
DEBUG - 2018-11-23 14:29:17 --> UTF-8 Support Enabled
INFO - 2018-11-23 14:29:17 --> Utf8 Class Initialized
INFO - 2018-11-23 14:29:17 --> URI Class Initialized
INFO - 2018-11-23 14:29:17 --> Router Class Initialized
INFO - 2018-11-23 14:29:17 --> Output Class Initialized
INFO - 2018-11-23 14:29:17 --> Security Class Initialized
DEBUG - 2018-11-23 14:29:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-23 14:29:17 --> Input Class Initialized
INFO - 2018-11-23 14:29:17 --> Language Class Initialized
INFO - 2018-11-23 14:29:17 --> Loader Class Initialized
INFO - 2018-11-23 14:29:17 --> Helper loaded: url_helper
INFO - 2018-11-23 14:29:17 --> Helper loaded: file_helper
INFO - 2018-11-23 14:29:17 --> Helper loaded: email_helper
INFO - 2018-11-23 14:29:17 --> Helper loaded: common_helper
INFO - 2018-11-23 14:29:17 --> Database Driver Class Initialized
DEBUG - 2018-11-23 14:29:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-23 14:29:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-23 14:29:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-23 14:29:17 --> Pagination Class Initialized
INFO - 2018-11-23 14:29:17 --> Helper loaded: form_helper
INFO - 2018-11-23 14:29:17 --> Form Validation Class Initialized
INFO - 2018-11-23 14:29:17 --> Model Class Initialized
INFO - 2018-11-23 14:29:17 --> Controller Class Initialized
INFO - 2018-11-23 14:29:17 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-23 14:29:17 --> Model Class Initialized
INFO - 2018-11-23 14:29:17 --> Model Class Initialized
INFO - 2018-11-23 14:29:17 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-23 14:29:17 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/change-password.php
INFO - 2018-11-23 14:29:17 --> Final output sent to browser
DEBUG - 2018-11-23 14:29:17 --> Total execution time: 0.0560
INFO - 2018-11-23 14:29:26 --> Config Class Initialized
INFO - 2018-11-23 14:29:26 --> Hooks Class Initialized
DEBUG - 2018-11-23 14:29:26 --> UTF-8 Support Enabled
INFO - 2018-11-23 14:29:26 --> Utf8 Class Initialized
INFO - 2018-11-23 14:29:26 --> URI Class Initialized
INFO - 2018-11-23 14:29:26 --> Router Class Initialized
INFO - 2018-11-23 14:29:26 --> Output Class Initialized
INFO - 2018-11-23 14:29:26 --> Security Class Initialized
DEBUG - 2018-11-23 14:29:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-23 14:29:26 --> Input Class Initialized
INFO - 2018-11-23 14:29:26 --> Language Class Initialized
INFO - 2018-11-23 14:29:26 --> Loader Class Initialized
INFO - 2018-11-23 14:29:26 --> Helper loaded: url_helper
INFO - 2018-11-23 14:29:26 --> Helper loaded: file_helper
INFO - 2018-11-23 14:29:26 --> Helper loaded: email_helper
INFO - 2018-11-23 14:29:26 --> Helper loaded: common_helper
INFO - 2018-11-23 14:29:26 --> Database Driver Class Initialized
DEBUG - 2018-11-23 14:29:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-23 14:29:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-23 14:29:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-23 14:29:26 --> Pagination Class Initialized
INFO - 2018-11-23 14:29:26 --> Helper loaded: form_helper
INFO - 2018-11-23 14:29:26 --> Form Validation Class Initialized
INFO - 2018-11-23 14:29:26 --> Model Class Initialized
INFO - 2018-11-23 14:29:26 --> Controller Class Initialized
INFO - 2018-11-23 14:29:26 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-23 14:29:26 --> Model Class Initialized
INFO - 2018-11-23 14:29:26 --> Model Class Initialized
INFO - 2018-11-23 14:29:26 --> Config Class Initialized
INFO - 2018-11-23 14:29:26 --> Hooks Class Initialized
DEBUG - 2018-11-23 14:29:26 --> UTF-8 Support Enabled
INFO - 2018-11-23 14:29:26 --> Utf8 Class Initialized
INFO - 2018-11-23 14:29:26 --> URI Class Initialized
INFO - 2018-11-23 14:29:26 --> Router Class Initialized
INFO - 2018-11-23 14:29:26 --> Output Class Initialized
INFO - 2018-11-23 14:29:26 --> Security Class Initialized
DEBUG - 2018-11-23 14:29:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-23 14:29:26 --> Input Class Initialized
INFO - 2018-11-23 14:29:26 --> Language Class Initialized
INFO - 2018-11-23 14:29:26 --> Loader Class Initialized
INFO - 2018-11-23 14:29:26 --> Helper loaded: url_helper
INFO - 2018-11-23 14:29:26 --> Helper loaded: file_helper
INFO - 2018-11-23 14:29:26 --> Helper loaded: email_helper
INFO - 2018-11-23 14:29:26 --> Helper loaded: common_helper
INFO - 2018-11-23 14:29:26 --> Database Driver Class Initialized
DEBUG - 2018-11-23 14:29:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-23 14:29:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-23 14:29:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-23 14:29:26 --> Pagination Class Initialized
INFO - 2018-11-23 14:29:26 --> Helper loaded: form_helper
INFO - 2018-11-23 14:29:26 --> Form Validation Class Initialized
INFO - 2018-11-23 14:29:26 --> Model Class Initialized
INFO - 2018-11-23 14:29:26 --> Controller Class Initialized
INFO - 2018-11-23 14:29:26 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-23 14:29:26 --> Model Class Initialized
INFO - 2018-11-23 14:29:26 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-23 14:29:26 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/sidebar.php
INFO - 2018-11-23 14:29:26 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/right-sidebar.php
INFO - 2018-11-23 14:29:26 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/footer.php
INFO - 2018-11-23 14:29:26 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/dashboard.php
INFO - 2018-11-23 14:29:26 --> Final output sent to browser
DEBUG - 2018-11-23 14:29:26 --> Total execution time: 0.1040
INFO - 2018-11-23 14:29:56 --> Config Class Initialized
INFO - 2018-11-23 14:29:56 --> Hooks Class Initialized
DEBUG - 2018-11-23 14:29:56 --> UTF-8 Support Enabled
INFO - 2018-11-23 14:29:56 --> Utf8 Class Initialized
INFO - 2018-11-23 14:29:56 --> URI Class Initialized
INFO - 2018-11-23 14:29:56 --> Router Class Initialized
INFO - 2018-11-23 14:29:56 --> Output Class Initialized
INFO - 2018-11-23 14:29:56 --> Security Class Initialized
DEBUG - 2018-11-23 14:29:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-23 14:29:56 --> Input Class Initialized
INFO - 2018-11-23 14:29:56 --> Language Class Initialized
INFO - 2018-11-23 14:29:56 --> Loader Class Initialized
INFO - 2018-11-23 14:29:56 --> Helper loaded: url_helper
INFO - 2018-11-23 14:29:56 --> Helper loaded: file_helper
INFO - 2018-11-23 14:29:56 --> Helper loaded: email_helper
INFO - 2018-11-23 14:29:56 --> Helper loaded: common_helper
INFO - 2018-11-23 14:29:56 --> Database Driver Class Initialized
DEBUG - 2018-11-23 14:29:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-23 14:29:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-23 14:29:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-23 14:29:56 --> Pagination Class Initialized
INFO - 2018-11-23 14:29:56 --> Helper loaded: form_helper
INFO - 2018-11-23 14:29:56 --> Form Validation Class Initialized
INFO - 2018-11-23 14:29:56 --> Model Class Initialized
INFO - 2018-11-23 14:29:56 --> Controller Class Initialized
INFO - 2018-11-23 14:29:56 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-23 14:29:56 --> Model Class Initialized
INFO - 2018-11-23 14:29:56 --> Model Class Initialized
INFO - 2018-11-23 14:29:56 --> Config Class Initialized
INFO - 2018-11-23 14:29:56 --> Hooks Class Initialized
DEBUG - 2018-11-23 14:29:56 --> UTF-8 Support Enabled
INFO - 2018-11-23 14:29:56 --> Utf8 Class Initialized
INFO - 2018-11-23 14:29:56 --> URI Class Initialized
INFO - 2018-11-23 14:29:56 --> Router Class Initialized
INFO - 2018-11-23 14:29:56 --> Output Class Initialized
INFO - 2018-11-23 14:29:56 --> Security Class Initialized
DEBUG - 2018-11-23 14:29:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-23 14:29:56 --> Input Class Initialized
INFO - 2018-11-23 14:29:56 --> Language Class Initialized
INFO - 2018-11-23 14:29:56 --> Loader Class Initialized
INFO - 2018-11-23 14:29:56 --> Helper loaded: url_helper
INFO - 2018-11-23 14:29:56 --> Helper loaded: file_helper
INFO - 2018-11-23 14:29:56 --> Helper loaded: email_helper
INFO - 2018-11-23 14:29:56 --> Helper loaded: common_helper
INFO - 2018-11-23 14:29:56 --> Database Driver Class Initialized
DEBUG - 2018-11-23 14:29:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-23 14:29:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-23 14:29:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-23 14:29:56 --> Pagination Class Initialized
INFO - 2018-11-23 14:29:56 --> Helper loaded: form_helper
INFO - 2018-11-23 14:29:56 --> Form Validation Class Initialized
INFO - 2018-11-23 14:29:56 --> Model Class Initialized
INFO - 2018-11-23 14:29:56 --> Controller Class Initialized
INFO - 2018-11-23 14:29:56 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-23 14:29:56 --> Model Class Initialized
INFO - 2018-11-23 14:29:56 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-23 14:29:56 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/sidebar.php
INFO - 2018-11-23 14:29:56 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/right-sidebar.php
INFO - 2018-11-23 14:29:56 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/footer.php
INFO - 2018-11-23 14:29:56 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/dashboard.php
INFO - 2018-11-23 14:29:56 --> Final output sent to browser
DEBUG - 2018-11-23 14:29:56 --> Total execution time: 0.1110
INFO - 2018-11-23 14:30:23 --> Config Class Initialized
INFO - 2018-11-23 14:30:23 --> Hooks Class Initialized
DEBUG - 2018-11-23 14:30:23 --> UTF-8 Support Enabled
INFO - 2018-11-23 14:30:23 --> Utf8 Class Initialized
INFO - 2018-11-23 14:30:23 --> URI Class Initialized
INFO - 2018-11-23 14:30:23 --> Router Class Initialized
INFO - 2018-11-23 14:30:23 --> Output Class Initialized
INFO - 2018-11-23 14:30:23 --> Security Class Initialized
DEBUG - 2018-11-23 14:30:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-23 14:30:23 --> Input Class Initialized
INFO - 2018-11-23 14:30:23 --> Language Class Initialized
ERROR - 2018-11-23 14:30:23 --> 404 Page Not Found: C/index
INFO - 2018-11-23 14:30:23 --> Config Class Initialized
INFO - 2018-11-23 14:30:23 --> Hooks Class Initialized
DEBUG - 2018-11-23 14:30:23 --> UTF-8 Support Enabled
INFO - 2018-11-23 14:30:23 --> Utf8 Class Initialized
INFO - 2018-11-23 14:30:23 --> URI Class Initialized
INFO - 2018-11-23 14:30:23 --> Router Class Initialized
INFO - 2018-11-23 14:30:23 --> Output Class Initialized
INFO - 2018-11-23 14:30:23 --> Security Class Initialized
DEBUG - 2018-11-23 14:30:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-23 14:30:23 --> Input Class Initialized
INFO - 2018-11-23 14:30:23 --> Language Class Initialized
ERROR - 2018-11-23 14:30:23 --> 404 Page Not Found: Cc/index
INFO - 2018-11-23 14:30:24 --> Config Class Initialized
INFO - 2018-11-23 14:30:24 --> Hooks Class Initialized
DEBUG - 2018-11-23 14:30:24 --> UTF-8 Support Enabled
INFO - 2018-11-23 14:30:24 --> Utf8 Class Initialized
INFO - 2018-11-23 14:30:24 --> URI Class Initialized
INFO - 2018-11-23 14:30:24 --> Router Class Initialized
INFO - 2018-11-23 14:30:24 --> Output Class Initialized
INFO - 2018-11-23 14:30:24 --> Security Class Initialized
DEBUG - 2018-11-23 14:30:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-23 14:30:24 --> Input Class Initialized
INFO - 2018-11-23 14:30:24 --> Language Class Initialized
ERROR - 2018-11-23 14:30:24 --> 404 Page Not Found: Ccc/index
INFO - 2018-11-23 14:30:34 --> Config Class Initialized
INFO - 2018-11-23 14:30:34 --> Hooks Class Initialized
DEBUG - 2018-11-23 14:30:34 --> UTF-8 Support Enabled
INFO - 2018-11-23 14:30:34 --> Utf8 Class Initialized
INFO - 2018-11-23 14:30:34 --> URI Class Initialized
INFO - 2018-11-23 14:30:34 --> Router Class Initialized
INFO - 2018-11-23 14:30:34 --> Output Class Initialized
INFO - 2018-11-23 14:30:34 --> Security Class Initialized
DEBUG - 2018-11-23 14:30:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-23 14:30:34 --> Input Class Initialized
INFO - 2018-11-23 14:30:34 --> Language Class Initialized
INFO - 2018-11-23 14:30:34 --> Loader Class Initialized
INFO - 2018-11-23 14:30:34 --> Helper loaded: url_helper
INFO - 2018-11-23 14:30:34 --> Helper loaded: file_helper
INFO - 2018-11-23 14:30:34 --> Helper loaded: email_helper
INFO - 2018-11-23 14:30:34 --> Helper loaded: common_helper
INFO - 2018-11-23 14:30:34 --> Database Driver Class Initialized
DEBUG - 2018-11-23 14:30:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-23 14:30:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-23 14:30:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-23 14:30:34 --> Pagination Class Initialized
INFO - 2018-11-23 14:30:34 --> Helper loaded: form_helper
INFO - 2018-11-23 14:30:34 --> Form Validation Class Initialized
INFO - 2018-11-23 14:30:34 --> Model Class Initialized
INFO - 2018-11-23 14:30:34 --> Controller Class Initialized
INFO - 2018-11-23 14:30:34 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-23 14:30:34 --> Model Class Initialized
INFO - 2018-11-23 14:30:34 --> Model Class Initialized
INFO - 2018-11-23 14:30:34 --> Config Class Initialized
INFO - 2018-11-23 14:30:34 --> Hooks Class Initialized
DEBUG - 2018-11-23 14:30:34 --> UTF-8 Support Enabled
INFO - 2018-11-23 14:30:34 --> Utf8 Class Initialized
INFO - 2018-11-23 14:30:34 --> URI Class Initialized
INFO - 2018-11-23 14:30:34 --> Router Class Initialized
INFO - 2018-11-23 14:30:34 --> Output Class Initialized
INFO - 2018-11-23 14:30:34 --> Security Class Initialized
DEBUG - 2018-11-23 14:30:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-23 14:30:34 --> Input Class Initialized
INFO - 2018-11-23 14:30:34 --> Language Class Initialized
INFO - 2018-11-23 14:30:34 --> Loader Class Initialized
INFO - 2018-11-23 14:30:34 --> Helper loaded: url_helper
INFO - 2018-11-23 14:30:34 --> Helper loaded: file_helper
INFO - 2018-11-23 14:30:34 --> Helper loaded: email_helper
INFO - 2018-11-23 14:30:34 --> Helper loaded: common_helper
INFO - 2018-11-23 14:30:34 --> Database Driver Class Initialized
DEBUG - 2018-11-23 14:30:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-23 14:30:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-23 14:30:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-23 14:30:34 --> Pagination Class Initialized
INFO - 2018-11-23 14:30:34 --> Helper loaded: form_helper
INFO - 2018-11-23 14:30:34 --> Form Validation Class Initialized
INFO - 2018-11-23 14:30:34 --> Model Class Initialized
INFO - 2018-11-23 14:30:34 --> Controller Class Initialized
INFO - 2018-11-23 14:30:34 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-23 14:30:34 --> Model Class Initialized
INFO - 2018-11-23 14:30:34 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-23 14:30:34 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/sidebar.php
INFO - 2018-11-23 14:30:34 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/right-sidebar.php
INFO - 2018-11-23 14:30:34 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/footer.php
INFO - 2018-11-23 14:30:34 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/dashboard.php
INFO - 2018-11-23 14:30:34 --> Final output sent to browser
DEBUG - 2018-11-23 14:30:34 --> Total execution time: 0.0924
INFO - 2018-11-23 14:35:13 --> Config Class Initialized
INFO - 2018-11-23 14:35:13 --> Hooks Class Initialized
DEBUG - 2018-11-23 14:35:13 --> UTF-8 Support Enabled
INFO - 2018-11-23 14:35:13 --> Utf8 Class Initialized
INFO - 2018-11-23 14:35:13 --> URI Class Initialized
INFO - 2018-11-23 14:35:13 --> Router Class Initialized
INFO - 2018-11-23 14:35:13 --> Output Class Initialized
INFO - 2018-11-23 14:35:13 --> Security Class Initialized
DEBUG - 2018-11-23 14:35:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-23 14:35:13 --> Input Class Initialized
INFO - 2018-11-23 14:35:13 --> Language Class Initialized
INFO - 2018-11-23 14:35:13 --> Loader Class Initialized
INFO - 2018-11-23 14:35:13 --> Helper loaded: url_helper
INFO - 2018-11-23 14:35:13 --> Helper loaded: file_helper
INFO - 2018-11-23 14:35:13 --> Helper loaded: email_helper
INFO - 2018-11-23 14:35:13 --> Helper loaded: common_helper
INFO - 2018-11-23 14:35:13 --> Database Driver Class Initialized
DEBUG - 2018-11-23 14:35:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-23 14:35:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-23 14:35:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-23 14:35:14 --> Pagination Class Initialized
INFO - 2018-11-23 14:35:14 --> Helper loaded: form_helper
INFO - 2018-11-23 14:35:14 --> Form Validation Class Initialized
INFO - 2018-11-23 14:35:14 --> Model Class Initialized
INFO - 2018-11-23 14:35:14 --> Controller Class Initialized
INFO - 2018-11-23 14:35:14 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-23 14:35:14 --> Model Class Initialized
INFO - 2018-11-23 14:35:14 --> Model Class Initialized
INFO - 2018-11-23 14:35:14 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-23 14:35:14 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/change-password.php
INFO - 2018-11-23 14:35:14 --> Final output sent to browser
DEBUG - 2018-11-23 14:35:14 --> Total execution time: 0.0600

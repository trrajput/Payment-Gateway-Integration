<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2018-11-17 08:08:26 --> Config Class Initialized
INFO - 2018-11-17 08:08:26 --> Hooks Class Initialized
DEBUG - 2018-11-17 08:08:26 --> UTF-8 Support Enabled
INFO - 2018-11-17 08:08:26 --> Utf8 Class Initialized
INFO - 2018-11-17 08:08:26 --> URI Class Initialized
DEBUG - 2018-11-17 08:08:26 --> No URI present. Default controller set.
INFO - 2018-11-17 08:08:26 --> Router Class Initialized
INFO - 2018-11-17 08:08:26 --> Output Class Initialized
INFO - 2018-11-17 08:08:26 --> Security Class Initialized
DEBUG - 2018-11-17 08:08:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-17 08:08:26 --> Input Class Initialized
INFO - 2018-11-17 08:08:26 --> Language Class Initialized
INFO - 2018-11-17 08:08:26 --> Loader Class Initialized
INFO - 2018-11-17 08:08:26 --> Helper loaded: url_helper
INFO - 2018-11-17 08:08:26 --> Helper loaded: file_helper
INFO - 2018-11-17 08:08:26 --> Helper loaded: email_helper
INFO - 2018-11-17 08:08:26 --> Helper loaded: common_helper
INFO - 2018-11-17 08:08:26 --> Database Driver Class Initialized
DEBUG - 2018-11-17 08:08:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-17 08:08:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-17 08:08:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-17 08:08:26 --> Pagination Class Initialized
INFO - 2018-11-17 08:08:26 --> Helper loaded: form_helper
INFO - 2018-11-17 08:08:26 --> Form Validation Class Initialized
INFO - 2018-11-17 08:08:26 --> Model Class Initialized
INFO - 2018-11-17 08:08:26 --> Controller Class Initialized
INFO - 2018-11-17 08:08:26 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-17 08:08:26 --> Model Class Initialized
INFO - 2018-11-17 08:08:26 --> Model Class Initialized
INFO - 2018-11-17 08:08:26 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\template/header-menu.php
INFO - 2018-11-17 08:08:26 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\template/header.php
INFO - 2018-11-17 08:08:26 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\template/footer.php
INFO - 2018-11-17 08:08:26 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\index.php
INFO - 2018-11-17 08:08:26 --> Final output sent to browser
DEBUG - 2018-11-17 08:08:26 --> Total execution time: 0.0960
INFO - 2018-11-17 08:08:55 --> Config Class Initialized
INFO - 2018-11-17 08:08:55 --> Hooks Class Initialized
DEBUG - 2018-11-17 08:08:55 --> UTF-8 Support Enabled
INFO - 2018-11-17 08:08:55 --> Utf8 Class Initialized
INFO - 2018-11-17 08:08:55 --> URI Class Initialized
DEBUG - 2018-11-17 08:08:55 --> No URI present. Default controller set.
INFO - 2018-11-17 08:08:55 --> Router Class Initialized
INFO - 2018-11-17 08:08:55 --> Output Class Initialized
INFO - 2018-11-17 08:08:55 --> Security Class Initialized
DEBUG - 2018-11-17 08:08:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-17 08:08:55 --> Input Class Initialized
INFO - 2018-11-17 08:08:55 --> Language Class Initialized
INFO - 2018-11-17 08:08:55 --> Loader Class Initialized
INFO - 2018-11-17 08:08:55 --> Helper loaded: url_helper
INFO - 2018-11-17 08:08:55 --> Helper loaded: file_helper
INFO - 2018-11-17 08:08:55 --> Helper loaded: email_helper
INFO - 2018-11-17 08:08:55 --> Helper loaded: common_helper
INFO - 2018-11-17 08:08:55 --> Database Driver Class Initialized
DEBUG - 2018-11-17 08:08:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-17 08:08:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-17 08:08:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-17 08:08:55 --> Pagination Class Initialized
INFO - 2018-11-17 08:08:55 --> Helper loaded: form_helper
INFO - 2018-11-17 08:08:55 --> Form Validation Class Initialized
INFO - 2018-11-17 08:08:55 --> Model Class Initialized
INFO - 2018-11-17 08:08:55 --> Controller Class Initialized
INFO - 2018-11-17 08:08:55 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-17 08:08:55 --> Model Class Initialized
INFO - 2018-11-17 08:08:55 --> Model Class Initialized
INFO - 2018-11-17 08:08:55 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\template/header-menu.php
INFO - 2018-11-17 08:08:55 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\template/header.php
INFO - 2018-11-17 08:08:55 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\template/footer.php
INFO - 2018-11-17 08:08:55 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\index.php
INFO - 2018-11-17 08:08:55 --> Final output sent to browser
DEBUG - 2018-11-17 08:08:55 --> Total execution time: 0.0460
INFO - 2018-11-17 08:09:05 --> Config Class Initialized
INFO - 2018-11-17 08:09:05 --> Hooks Class Initialized
DEBUG - 2018-11-17 08:09:05 --> UTF-8 Support Enabled
INFO - 2018-11-17 08:09:05 --> Utf8 Class Initialized
INFO - 2018-11-17 08:09:05 --> URI Class Initialized
DEBUG - 2018-11-17 08:09:05 --> No URI present. Default controller set.
INFO - 2018-11-17 08:09:05 --> Router Class Initialized
INFO - 2018-11-17 08:09:05 --> Output Class Initialized
INFO - 2018-11-17 08:09:05 --> Security Class Initialized
DEBUG - 2018-11-17 08:09:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-17 08:09:05 --> Input Class Initialized
INFO - 2018-11-17 08:09:05 --> Language Class Initialized
INFO - 2018-11-17 08:09:05 --> Loader Class Initialized
INFO - 2018-11-17 08:09:05 --> Helper loaded: url_helper
INFO - 2018-11-17 08:09:05 --> Helper loaded: file_helper
INFO - 2018-11-17 08:09:05 --> Helper loaded: email_helper
INFO - 2018-11-17 08:09:05 --> Helper loaded: common_helper
INFO - 2018-11-17 08:09:05 --> Database Driver Class Initialized
DEBUG - 2018-11-17 08:09:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-17 08:09:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-17 08:09:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-17 08:09:05 --> Pagination Class Initialized
INFO - 2018-11-17 08:09:05 --> Helper loaded: form_helper
INFO - 2018-11-17 08:09:05 --> Form Validation Class Initialized
INFO - 2018-11-17 08:09:05 --> Model Class Initialized
INFO - 2018-11-17 08:09:05 --> Controller Class Initialized
INFO - 2018-11-17 08:09:05 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-17 08:09:05 --> Model Class Initialized
INFO - 2018-11-17 08:09:05 --> Model Class Initialized
INFO - 2018-11-17 08:09:05 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\template/header-menu.php
INFO - 2018-11-17 08:09:05 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\template/header.php
INFO - 2018-11-17 08:09:05 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\template/footer.php
INFO - 2018-11-17 08:09:05 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\index.php
INFO - 2018-11-17 08:09:05 --> Final output sent to browser
DEBUG - 2018-11-17 08:09:05 --> Total execution time: 0.0530
INFO - 2018-11-17 08:13:14 --> Config Class Initialized
INFO - 2018-11-17 08:13:14 --> Hooks Class Initialized
DEBUG - 2018-11-17 08:13:14 --> UTF-8 Support Enabled
INFO - 2018-11-17 08:13:14 --> Utf8 Class Initialized
INFO - 2018-11-17 08:13:14 --> URI Class Initialized
DEBUG - 2018-11-17 08:13:14 --> No URI present. Default controller set.
INFO - 2018-11-17 08:13:14 --> Router Class Initialized
INFO - 2018-11-17 08:13:14 --> Output Class Initialized
INFO - 2018-11-17 08:13:14 --> Security Class Initialized
DEBUG - 2018-11-17 08:13:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-17 08:13:14 --> Input Class Initialized
INFO - 2018-11-17 08:13:14 --> Language Class Initialized
INFO - 2018-11-17 08:13:14 --> Loader Class Initialized
INFO - 2018-11-17 08:13:14 --> Helper loaded: url_helper
INFO - 2018-11-17 08:13:14 --> Helper loaded: file_helper
INFO - 2018-11-17 08:13:14 --> Helper loaded: email_helper
INFO - 2018-11-17 08:13:14 --> Helper loaded: common_helper
INFO - 2018-11-17 08:13:14 --> Database Driver Class Initialized
DEBUG - 2018-11-17 08:13:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-17 08:13:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-17 08:13:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-17 08:13:14 --> Pagination Class Initialized
INFO - 2018-11-17 08:13:14 --> Helper loaded: form_helper
INFO - 2018-11-17 08:13:14 --> Form Validation Class Initialized
INFO - 2018-11-17 08:13:14 --> Model Class Initialized
INFO - 2018-11-17 08:13:14 --> Controller Class Initialized
INFO - 2018-11-17 08:13:14 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-17 08:13:14 --> Model Class Initialized
INFO - 2018-11-17 08:13:14 --> Model Class Initialized
INFO - 2018-11-17 08:13:14 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\template/header-menu.php
INFO - 2018-11-17 08:13:14 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\template/header.php
INFO - 2018-11-17 08:13:14 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\template/footer.php
INFO - 2018-11-17 08:13:14 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\index.php
INFO - 2018-11-17 08:13:14 --> Final output sent to browser
DEBUG - 2018-11-17 08:13:14 --> Total execution time: 0.0550
INFO - 2018-11-17 08:14:00 --> Config Class Initialized
INFO - 2018-11-17 08:14:00 --> Hooks Class Initialized
DEBUG - 2018-11-17 08:14:00 --> UTF-8 Support Enabled
INFO - 2018-11-17 08:14:00 --> Utf8 Class Initialized
INFO - 2018-11-17 08:14:00 --> URI Class Initialized
DEBUG - 2018-11-17 08:14:00 --> No URI present. Default controller set.
INFO - 2018-11-17 08:14:00 --> Router Class Initialized
INFO - 2018-11-17 08:14:00 --> Output Class Initialized
INFO - 2018-11-17 08:14:00 --> Security Class Initialized
DEBUG - 2018-11-17 08:14:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-17 08:14:00 --> Input Class Initialized
INFO - 2018-11-17 08:14:00 --> Language Class Initialized
INFO - 2018-11-17 08:14:00 --> Loader Class Initialized
INFO - 2018-11-17 08:14:00 --> Helper loaded: url_helper
INFO - 2018-11-17 08:14:00 --> Helper loaded: file_helper
INFO - 2018-11-17 08:14:00 --> Helper loaded: email_helper
INFO - 2018-11-17 08:14:00 --> Helper loaded: common_helper
INFO - 2018-11-17 08:14:00 --> Database Driver Class Initialized
DEBUG - 2018-11-17 08:14:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-17 08:14:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-17 08:14:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-17 08:14:00 --> Pagination Class Initialized
INFO - 2018-11-17 08:14:00 --> Helper loaded: form_helper
INFO - 2018-11-17 08:14:00 --> Form Validation Class Initialized
INFO - 2018-11-17 08:14:00 --> Model Class Initialized
INFO - 2018-11-17 08:14:00 --> Controller Class Initialized
INFO - 2018-11-17 08:14:00 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-17 08:14:00 --> Model Class Initialized
INFO - 2018-11-17 08:14:00 --> Model Class Initialized
INFO - 2018-11-17 08:14:00 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\template/header-menu.php
INFO - 2018-11-17 08:14:00 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\template/header.php
INFO - 2018-11-17 08:14:00 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\template/footer.php
INFO - 2018-11-17 08:14:00 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\index.php
INFO - 2018-11-17 08:14:00 --> Final output sent to browser
DEBUG - 2018-11-17 08:14:00 --> Total execution time: 0.0468
INFO - 2018-11-17 08:14:07 --> Config Class Initialized
INFO - 2018-11-17 08:14:07 --> Hooks Class Initialized
DEBUG - 2018-11-17 08:14:07 --> UTF-8 Support Enabled
INFO - 2018-11-17 08:14:07 --> Utf8 Class Initialized
INFO - 2018-11-17 08:14:07 --> URI Class Initialized
DEBUG - 2018-11-17 08:14:07 --> No URI present. Default controller set.
INFO - 2018-11-17 08:14:07 --> Router Class Initialized
INFO - 2018-11-17 08:14:07 --> Output Class Initialized
INFO - 2018-11-17 08:14:07 --> Security Class Initialized
DEBUG - 2018-11-17 08:14:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-17 08:14:07 --> Input Class Initialized
INFO - 2018-11-17 08:14:07 --> Language Class Initialized
INFO - 2018-11-17 08:14:07 --> Loader Class Initialized
INFO - 2018-11-17 08:14:07 --> Helper loaded: url_helper
INFO - 2018-11-17 08:14:07 --> Helper loaded: file_helper
INFO - 2018-11-17 08:14:07 --> Helper loaded: email_helper
INFO - 2018-11-17 08:14:07 --> Helper loaded: common_helper
INFO - 2018-11-17 08:14:07 --> Database Driver Class Initialized
DEBUG - 2018-11-17 08:14:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-17 08:14:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-17 08:14:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-17 08:14:07 --> Pagination Class Initialized
INFO - 2018-11-17 08:14:07 --> Helper loaded: form_helper
INFO - 2018-11-17 08:14:07 --> Form Validation Class Initialized
INFO - 2018-11-17 08:14:07 --> Model Class Initialized
INFO - 2018-11-17 08:14:07 --> Controller Class Initialized
INFO - 2018-11-17 08:14:07 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-17 08:14:07 --> Model Class Initialized
INFO - 2018-11-17 08:14:07 --> Model Class Initialized
INFO - 2018-11-17 08:14:07 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\template/header-menu.php
INFO - 2018-11-17 08:14:07 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\template/header.php
INFO - 2018-11-17 08:14:07 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\template/footer.php
INFO - 2018-11-17 08:14:07 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\index.php
INFO - 2018-11-17 08:14:08 --> Final output sent to browser
DEBUG - 2018-11-17 08:14:08 --> Total execution time: 0.0468
INFO - 2018-11-17 08:14:09 --> Config Class Initialized
INFO - 2018-11-17 08:14:09 --> Hooks Class Initialized
DEBUG - 2018-11-17 08:14:09 --> UTF-8 Support Enabled
INFO - 2018-11-17 08:14:09 --> Utf8 Class Initialized
INFO - 2018-11-17 08:14:09 --> URI Class Initialized
DEBUG - 2018-11-17 08:14:09 --> No URI present. Default controller set.
INFO - 2018-11-17 08:14:09 --> Router Class Initialized
INFO - 2018-11-17 08:14:09 --> Output Class Initialized
INFO - 2018-11-17 08:14:09 --> Security Class Initialized
DEBUG - 2018-11-17 08:14:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-17 08:14:09 --> Input Class Initialized
INFO - 2018-11-17 08:14:09 --> Language Class Initialized
INFO - 2018-11-17 08:14:09 --> Loader Class Initialized
INFO - 2018-11-17 08:14:09 --> Helper loaded: url_helper
INFO - 2018-11-17 08:14:09 --> Helper loaded: file_helper
INFO - 2018-11-17 08:14:09 --> Helper loaded: email_helper
INFO - 2018-11-17 08:14:09 --> Helper loaded: common_helper
INFO - 2018-11-17 08:14:09 --> Database Driver Class Initialized
DEBUG - 2018-11-17 08:14:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-17 08:14:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-17 08:14:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-17 08:14:09 --> Pagination Class Initialized
INFO - 2018-11-17 08:14:09 --> Helper loaded: form_helper
INFO - 2018-11-17 08:14:09 --> Form Validation Class Initialized
INFO - 2018-11-17 08:14:09 --> Model Class Initialized
INFO - 2018-11-17 08:14:09 --> Controller Class Initialized
INFO - 2018-11-17 08:14:09 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-17 08:14:09 --> Model Class Initialized
INFO - 2018-11-17 08:14:09 --> Model Class Initialized
INFO - 2018-11-17 08:14:09 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\template/header-menu.php
INFO - 2018-11-17 08:14:09 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\template/header.php
INFO - 2018-11-17 08:14:09 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\template/footer.php
INFO - 2018-11-17 08:14:09 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\index.php
INFO - 2018-11-17 08:14:09 --> Final output sent to browser
DEBUG - 2018-11-17 08:14:09 --> Total execution time: 0.0486
INFO - 2018-11-17 08:14:13 --> Config Class Initialized
INFO - 2018-11-17 08:14:13 --> Hooks Class Initialized
DEBUG - 2018-11-17 08:14:13 --> UTF-8 Support Enabled
INFO - 2018-11-17 08:14:13 --> Utf8 Class Initialized
INFO - 2018-11-17 08:14:13 --> URI Class Initialized
DEBUG - 2018-11-17 08:14:13 --> No URI present. Default controller set.
INFO - 2018-11-17 08:14:13 --> Router Class Initialized
INFO - 2018-11-17 08:14:13 --> Output Class Initialized
INFO - 2018-11-17 08:14:13 --> Security Class Initialized
DEBUG - 2018-11-17 08:14:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-17 08:14:13 --> Input Class Initialized
INFO - 2018-11-17 08:14:13 --> Language Class Initialized
INFO - 2018-11-17 08:14:13 --> Loader Class Initialized
INFO - 2018-11-17 08:14:13 --> Helper loaded: url_helper
INFO - 2018-11-17 08:14:13 --> Helper loaded: file_helper
INFO - 2018-11-17 08:14:13 --> Helper loaded: email_helper
INFO - 2018-11-17 08:14:13 --> Helper loaded: common_helper
INFO - 2018-11-17 08:14:13 --> Database Driver Class Initialized
DEBUG - 2018-11-17 08:14:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-17 08:14:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-17 08:14:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-17 08:14:13 --> Pagination Class Initialized
INFO - 2018-11-17 08:14:13 --> Helper loaded: form_helper
INFO - 2018-11-17 08:14:13 --> Form Validation Class Initialized
INFO - 2018-11-17 08:14:13 --> Model Class Initialized
INFO - 2018-11-17 08:14:13 --> Controller Class Initialized
INFO - 2018-11-17 08:14:13 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-17 08:14:13 --> Model Class Initialized
INFO - 2018-11-17 08:14:13 --> Model Class Initialized
INFO - 2018-11-17 08:14:13 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\template/header-menu.php
INFO - 2018-11-17 08:14:13 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\template/header.php
INFO - 2018-11-17 08:14:13 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\template/footer.php
INFO - 2018-11-17 08:14:13 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\index.php
INFO - 2018-11-17 08:14:13 --> Final output sent to browser
DEBUG - 2018-11-17 08:14:13 --> Total execution time: 0.0550
INFO - 2018-11-17 08:14:20 --> Config Class Initialized
INFO - 2018-11-17 08:14:20 --> Hooks Class Initialized
DEBUG - 2018-11-17 08:14:20 --> UTF-8 Support Enabled
INFO - 2018-11-17 08:14:20 --> Utf8 Class Initialized
INFO - 2018-11-17 08:14:20 --> URI Class Initialized
DEBUG - 2018-11-17 08:14:20 --> No URI present. Default controller set.
INFO - 2018-11-17 08:14:20 --> Router Class Initialized
INFO - 2018-11-17 08:14:20 --> Output Class Initialized
INFO - 2018-11-17 08:14:20 --> Security Class Initialized
DEBUG - 2018-11-17 08:14:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-17 08:14:20 --> Input Class Initialized
INFO - 2018-11-17 08:14:20 --> Language Class Initialized
INFO - 2018-11-17 08:14:20 --> Loader Class Initialized
INFO - 2018-11-17 08:14:20 --> Helper loaded: url_helper
INFO - 2018-11-17 08:14:20 --> Helper loaded: file_helper
INFO - 2018-11-17 08:14:20 --> Helper loaded: email_helper
INFO - 2018-11-17 08:14:20 --> Helper loaded: common_helper
INFO - 2018-11-17 08:14:20 --> Database Driver Class Initialized
DEBUG - 2018-11-17 08:14:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-17 08:14:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-17 08:14:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-17 08:14:20 --> Pagination Class Initialized
INFO - 2018-11-17 08:14:20 --> Helper loaded: form_helper
INFO - 2018-11-17 08:14:20 --> Form Validation Class Initialized
INFO - 2018-11-17 08:14:20 --> Model Class Initialized
INFO - 2018-11-17 08:14:20 --> Controller Class Initialized
INFO - 2018-11-17 08:14:20 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-17 08:14:20 --> Model Class Initialized
INFO - 2018-11-17 08:14:20 --> Model Class Initialized
INFO - 2018-11-17 08:14:20 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\template/header-menu.php
INFO - 2018-11-17 08:14:20 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\template/header.php
INFO - 2018-11-17 08:14:20 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\template/footer.php
INFO - 2018-11-17 08:14:20 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\index.php
INFO - 2018-11-17 08:14:20 --> Final output sent to browser
DEBUG - 2018-11-17 08:14:20 --> Total execution time: 0.0468
INFO - 2018-11-17 08:53:38 --> Config Class Initialized
INFO - 2018-11-17 08:53:38 --> Hooks Class Initialized
DEBUG - 2018-11-17 08:53:38 --> UTF-8 Support Enabled
INFO - 2018-11-17 08:53:38 --> Utf8 Class Initialized
INFO - 2018-11-17 08:53:38 --> URI Class Initialized
INFO - 2018-11-17 08:53:38 --> Router Class Initialized
INFO - 2018-11-17 08:53:38 --> Output Class Initialized
INFO - 2018-11-17 08:53:38 --> Security Class Initialized
DEBUG - 2018-11-17 08:53:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-17 08:53:38 --> Input Class Initialized
INFO - 2018-11-17 08:53:38 --> Language Class Initialized
INFO - 2018-11-17 08:53:38 --> Loader Class Initialized
INFO - 2018-11-17 08:53:38 --> Helper loaded: url_helper
INFO - 2018-11-17 08:53:38 --> Helper loaded: file_helper
INFO - 2018-11-17 08:53:38 --> Helper loaded: email_helper
INFO - 2018-11-17 08:53:38 --> Helper loaded: common_helper
INFO - 2018-11-17 08:53:38 --> Database Driver Class Initialized
DEBUG - 2018-11-17 08:53:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-17 08:53:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-17 08:53:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-17 08:53:38 --> Pagination Class Initialized
INFO - 2018-11-17 08:53:38 --> Helper loaded: form_helper
INFO - 2018-11-17 08:53:38 --> Form Validation Class Initialized
INFO - 2018-11-17 08:53:38 --> Model Class Initialized
INFO - 2018-11-17 08:53:38 --> Controller Class Initialized
INFO - 2018-11-17 08:53:38 --> Model Class Initialized
INFO - 2018-11-17 08:53:38 --> Model Class Initialized
INFO - 2018-11-17 08:54:10 --> Config Class Initialized
INFO - 2018-11-17 08:54:10 --> Hooks Class Initialized
DEBUG - 2018-11-17 08:54:10 --> UTF-8 Support Enabled
INFO - 2018-11-17 08:54:10 --> Utf8 Class Initialized
INFO - 2018-11-17 08:54:10 --> URI Class Initialized
INFO - 2018-11-17 08:54:10 --> Router Class Initialized
INFO - 2018-11-17 08:54:10 --> Output Class Initialized
INFO - 2018-11-17 08:54:10 --> Security Class Initialized
DEBUG - 2018-11-17 08:54:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-17 08:54:10 --> Input Class Initialized
INFO - 2018-11-17 08:54:10 --> Language Class Initialized
INFO - 2018-11-17 08:54:10 --> Loader Class Initialized
INFO - 2018-11-17 08:54:10 --> Helper loaded: url_helper
INFO - 2018-11-17 08:54:10 --> Helper loaded: file_helper
INFO - 2018-11-17 08:54:10 --> Helper loaded: email_helper
INFO - 2018-11-17 08:54:10 --> Helper loaded: common_helper
INFO - 2018-11-17 08:54:10 --> Database Driver Class Initialized
DEBUG - 2018-11-17 08:54:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-17 08:54:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-17 08:54:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-17 08:54:10 --> Pagination Class Initialized
INFO - 2018-11-17 08:54:10 --> Helper loaded: form_helper
INFO - 2018-11-17 08:54:10 --> Form Validation Class Initialized
INFO - 2018-11-17 08:54:10 --> Model Class Initialized
INFO - 2018-11-17 08:54:10 --> Controller Class Initialized
INFO - 2018-11-17 08:54:10 --> Model Class Initialized
INFO - 2018-11-17 08:54:10 --> Model Class Initialized
ERROR - 2018-11-17 08:54:10 --> Could not find the language line "ADMIN_LOGIN_PAGE_TITLE"
ERROR - 2018-11-17 08:54:10 --> Could not find the language line "ADMIN_LOGIN_REMEMBER_ME"
ERROR - 2018-11-17 08:54:10 --> Could not find the language line "ADMIN_LOGIN_SUBMIT_SIGNIN"
ERROR - 2018-11-17 08:54:10 --> Could not find the language line "ADMIN_LOGIN_FORGOT_PASSWORD"
INFO - 2018-11-17 08:54:10 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/index.php
INFO - 2018-11-17 08:54:10 --> Final output sent to browser
DEBUG - 2018-11-17 08:54:10 --> Total execution time: 0.0580
INFO - 2018-11-17 08:55:18 --> Config Class Initialized
INFO - 2018-11-17 08:55:18 --> Hooks Class Initialized
DEBUG - 2018-11-17 08:55:18 --> UTF-8 Support Enabled
INFO - 2018-11-17 08:55:18 --> Utf8 Class Initialized
INFO - 2018-11-17 08:55:18 --> URI Class Initialized
INFO - 2018-11-17 08:55:18 --> Router Class Initialized
INFO - 2018-11-17 08:55:18 --> Output Class Initialized
INFO - 2018-11-17 08:55:18 --> Security Class Initialized
DEBUG - 2018-11-17 08:55:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-17 08:55:18 --> Input Class Initialized
INFO - 2018-11-17 08:55:18 --> Language Class Initialized
INFO - 2018-11-17 08:55:18 --> Loader Class Initialized
INFO - 2018-11-17 08:55:18 --> Helper loaded: url_helper
INFO - 2018-11-17 08:55:18 --> Helper loaded: file_helper
INFO - 2018-11-17 08:55:18 --> Helper loaded: email_helper
INFO - 2018-11-17 08:55:18 --> Helper loaded: common_helper
INFO - 2018-11-17 08:55:19 --> Database Driver Class Initialized
DEBUG - 2018-11-17 08:55:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-17 08:55:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-17 08:55:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-17 08:55:19 --> Pagination Class Initialized
INFO - 2018-11-17 08:55:19 --> Helper loaded: form_helper
INFO - 2018-11-17 08:55:19 --> Form Validation Class Initialized
INFO - 2018-11-17 08:55:19 --> Model Class Initialized
INFO - 2018-11-17 08:55:19 --> Controller Class Initialized
INFO - 2018-11-17 08:55:19 --> Model Class Initialized
INFO - 2018-11-17 08:55:19 --> Model Class Initialized
ERROR - 2018-11-17 08:55:19 --> Could not find the language line "ADMIN_LOGIN_PAGE_TITLE"
ERROR - 2018-11-17 08:55:19 --> Could not find the language line "ADMIN_LOGIN_REMEMBER_ME"
ERROR - 2018-11-17 08:55:19 --> Could not find the language line "ADMIN_LOGIN_SUBMIT_SIGNIN"
ERROR - 2018-11-17 08:55:19 --> Could not find the language line "ADMIN_LOGIN_FORGOT_PASSWORD"
INFO - 2018-11-17 08:55:19 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/index.php
INFO - 2018-11-17 08:55:19 --> Final output sent to browser
DEBUG - 2018-11-17 08:55:19 --> Total execution time: 0.0550
INFO - 2018-11-17 08:57:56 --> Config Class Initialized
INFO - 2018-11-17 08:57:56 --> Hooks Class Initialized
DEBUG - 2018-11-17 08:57:56 --> UTF-8 Support Enabled
INFO - 2018-11-17 08:57:56 --> Utf8 Class Initialized
INFO - 2018-11-17 08:57:56 --> URI Class Initialized
INFO - 2018-11-17 08:57:56 --> Router Class Initialized
INFO - 2018-11-17 08:57:56 --> Output Class Initialized
INFO - 2018-11-17 08:57:56 --> Security Class Initialized
DEBUG - 2018-11-17 08:57:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-17 08:57:56 --> Input Class Initialized
INFO - 2018-11-17 08:57:56 --> Language Class Initialized
INFO - 2018-11-17 08:57:56 --> Loader Class Initialized
INFO - 2018-11-17 08:57:56 --> Helper loaded: url_helper
INFO - 2018-11-17 08:57:56 --> Helper loaded: file_helper
INFO - 2018-11-17 08:57:56 --> Helper loaded: email_helper
INFO - 2018-11-17 08:57:56 --> Helper loaded: common_helper
INFO - 2018-11-17 08:57:56 --> Database Driver Class Initialized
DEBUG - 2018-11-17 08:57:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-17 08:57:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-17 08:57:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-17 08:57:56 --> Pagination Class Initialized
INFO - 2018-11-17 08:57:56 --> Helper loaded: form_helper
INFO - 2018-11-17 08:57:56 --> Form Validation Class Initialized
INFO - 2018-11-17 08:57:56 --> Model Class Initialized
INFO - 2018-11-17 08:57:56 --> Controller Class Initialized
INFO - 2018-11-17 08:57:56 --> Model Class Initialized
INFO - 2018-11-17 08:57:56 --> Model Class Initialized
ERROR - 2018-11-17 08:57:56 --> Could not find the language line "ADMIN_LOGIN_PAGE_TITLE"
ERROR - 2018-11-17 08:57:56 --> Could not find the language line "ADMIN_LOGIN_REMEMBER_ME"
ERROR - 2018-11-17 08:57:56 --> Could not find the language line "ADMIN_LOGIN_SUBMIT_SIGNIN"
ERROR - 2018-11-17 08:57:56 --> Could not find the language line "ADMIN_LOGIN_FORGOT_PASSWORD"
INFO - 2018-11-17 08:57:56 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/index.php
INFO - 2018-11-17 08:57:56 --> Final output sent to browser
DEBUG - 2018-11-17 08:57:56 --> Total execution time: 0.0550
INFO - 2018-11-17 08:58:33 --> Config Class Initialized
INFO - 2018-11-17 08:58:33 --> Hooks Class Initialized
DEBUG - 2018-11-17 08:58:33 --> UTF-8 Support Enabled
INFO - 2018-11-17 08:58:33 --> Utf8 Class Initialized
INFO - 2018-11-17 08:58:33 --> URI Class Initialized
INFO - 2018-11-17 08:58:33 --> Router Class Initialized
INFO - 2018-11-17 08:58:33 --> Output Class Initialized
INFO - 2018-11-17 08:58:33 --> Security Class Initialized
DEBUG - 2018-11-17 08:58:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-17 08:58:33 --> Input Class Initialized
INFO - 2018-11-17 08:58:33 --> Language Class Initialized
INFO - 2018-11-17 08:58:33 --> Loader Class Initialized
INFO - 2018-11-17 08:58:33 --> Helper loaded: url_helper
INFO - 2018-11-17 08:58:33 --> Helper loaded: file_helper
INFO - 2018-11-17 08:58:33 --> Helper loaded: email_helper
INFO - 2018-11-17 08:58:33 --> Helper loaded: common_helper
INFO - 2018-11-17 08:58:33 --> Database Driver Class Initialized
DEBUG - 2018-11-17 08:58:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-17 08:58:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-17 08:58:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-17 08:58:33 --> Pagination Class Initialized
INFO - 2018-11-17 08:58:33 --> Helper loaded: form_helper
INFO - 2018-11-17 08:58:33 --> Form Validation Class Initialized
INFO - 2018-11-17 08:58:33 --> Model Class Initialized
INFO - 2018-11-17 08:58:33 --> Controller Class Initialized
INFO - 2018-11-17 08:58:33 --> Model Class Initialized
INFO - 2018-11-17 08:58:33 --> Model Class Initialized
ERROR - 2018-11-17 08:58:33 --> Could not find the language line "ADMIN_LOGIN_PAGE_TITLE"
ERROR - 2018-11-17 08:58:33 --> Could not find the language line "ADMIN_LOGIN_REMEMBER_ME"
ERROR - 2018-11-17 08:58:33 --> Could not find the language line "ADMIN_LOGIN_SUBMIT_SIGNIN"
ERROR - 2018-11-17 08:58:33 --> Could not find the language line "ADMIN_LOGIN_FORGOT_PASSWORD"
INFO - 2018-11-17 08:58:33 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/index.php
INFO - 2018-11-17 08:58:33 --> Final output sent to browser
DEBUG - 2018-11-17 08:58:33 --> Total execution time: 0.0650
INFO - 2018-11-17 09:00:00 --> Config Class Initialized
INFO - 2018-11-17 09:00:00 --> Hooks Class Initialized
DEBUG - 2018-11-17 09:00:00 --> UTF-8 Support Enabled
INFO - 2018-11-17 09:00:00 --> Utf8 Class Initialized
INFO - 2018-11-17 09:00:00 --> URI Class Initialized
INFO - 2018-11-17 09:00:00 --> Router Class Initialized
INFO - 2018-11-17 09:00:00 --> Output Class Initialized
INFO - 2018-11-17 09:00:00 --> Security Class Initialized
DEBUG - 2018-11-17 09:00:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-17 09:00:00 --> Input Class Initialized
INFO - 2018-11-17 09:00:00 --> Language Class Initialized
INFO - 2018-11-17 09:00:00 --> Loader Class Initialized
INFO - 2018-11-17 09:00:00 --> Helper loaded: url_helper
INFO - 2018-11-17 09:00:00 --> Helper loaded: file_helper
INFO - 2018-11-17 09:00:00 --> Helper loaded: email_helper
INFO - 2018-11-17 09:00:00 --> Helper loaded: common_helper
INFO - 2018-11-17 09:00:00 --> Database Driver Class Initialized
DEBUG - 2018-11-17 09:00:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-17 09:00:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-17 09:00:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-17 09:00:00 --> Pagination Class Initialized
INFO - 2018-11-17 09:00:00 --> Helper loaded: form_helper
INFO - 2018-11-17 09:00:00 --> Form Validation Class Initialized
INFO - 2018-11-17 09:00:00 --> Model Class Initialized
INFO - 2018-11-17 09:00:00 --> Controller Class Initialized
INFO - 2018-11-17 09:00:00 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-17 09:00:00 --> Model Class Initialized
INFO - 2018-11-17 09:00:00 --> Model Class Initialized
INFO - 2018-11-17 09:01:05 --> Config Class Initialized
INFO - 2018-11-17 09:01:05 --> Hooks Class Initialized
DEBUG - 2018-11-17 09:01:05 --> UTF-8 Support Enabled
INFO - 2018-11-17 09:01:05 --> Utf8 Class Initialized
INFO - 2018-11-17 09:01:05 --> URI Class Initialized
INFO - 2018-11-17 09:01:05 --> Router Class Initialized
INFO - 2018-11-17 09:01:05 --> Output Class Initialized
INFO - 2018-11-17 09:01:05 --> Security Class Initialized
DEBUG - 2018-11-17 09:01:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-17 09:01:05 --> Input Class Initialized
INFO - 2018-11-17 09:01:05 --> Language Class Initialized
INFO - 2018-11-17 09:01:05 --> Loader Class Initialized
INFO - 2018-11-17 09:01:05 --> Helper loaded: url_helper
INFO - 2018-11-17 09:01:05 --> Helper loaded: file_helper
INFO - 2018-11-17 09:01:05 --> Helper loaded: email_helper
INFO - 2018-11-17 09:01:05 --> Helper loaded: common_helper
INFO - 2018-11-17 09:01:05 --> Database Driver Class Initialized
DEBUG - 2018-11-17 09:01:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-17 09:01:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-17 09:01:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-17 09:01:05 --> Pagination Class Initialized
INFO - 2018-11-17 09:01:05 --> Helper loaded: form_helper
INFO - 2018-11-17 09:01:05 --> Form Validation Class Initialized
INFO - 2018-11-17 09:01:05 --> Model Class Initialized
INFO - 2018-11-17 09:01:05 --> Controller Class Initialized
INFO - 2018-11-17 09:01:05 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-17 09:01:05 --> Model Class Initialized
INFO - 2018-11-17 09:01:05 --> Model Class Initialized
INFO - 2018-11-17 09:01:05 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/index.php
INFO - 2018-11-17 09:01:05 --> Final output sent to browser
DEBUG - 2018-11-17 09:01:05 --> Total execution time: 0.0636
INFO - 2018-11-17 09:01:52 --> Config Class Initialized
INFO - 2018-11-17 09:01:52 --> Hooks Class Initialized
DEBUG - 2018-11-17 09:01:52 --> UTF-8 Support Enabled
INFO - 2018-11-17 09:01:52 --> Utf8 Class Initialized
INFO - 2018-11-17 09:01:52 --> URI Class Initialized
INFO - 2018-11-17 09:01:52 --> Router Class Initialized
INFO - 2018-11-17 09:01:52 --> Output Class Initialized
INFO - 2018-11-17 09:01:52 --> Security Class Initialized
DEBUG - 2018-11-17 09:01:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-17 09:01:52 --> Input Class Initialized
INFO - 2018-11-17 09:01:52 --> Language Class Initialized
INFO - 2018-11-17 09:01:52 --> Loader Class Initialized
INFO - 2018-11-17 09:01:52 --> Helper loaded: url_helper
INFO - 2018-11-17 09:01:52 --> Helper loaded: file_helper
INFO - 2018-11-17 09:01:52 --> Helper loaded: email_helper
INFO - 2018-11-17 09:01:52 --> Helper loaded: common_helper
INFO - 2018-11-17 09:01:52 --> Database Driver Class Initialized
DEBUG - 2018-11-17 09:01:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-17 09:01:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-17 09:01:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-17 09:01:52 --> Pagination Class Initialized
INFO - 2018-11-17 09:01:52 --> Helper loaded: form_helper
INFO - 2018-11-17 09:01:52 --> Form Validation Class Initialized
INFO - 2018-11-17 09:01:52 --> Model Class Initialized
INFO - 2018-11-17 09:01:52 --> Controller Class Initialized
INFO - 2018-11-17 09:01:52 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-17 09:01:52 --> Model Class Initialized
INFO - 2018-11-17 09:01:52 --> Model Class Initialized
INFO - 2018-11-17 09:01:52 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/index.php
INFO - 2018-11-17 09:01:52 --> Final output sent to browser
DEBUG - 2018-11-17 09:01:52 --> Total execution time: 0.0590
INFO - 2018-11-17 09:02:18 --> Config Class Initialized
INFO - 2018-11-17 09:02:18 --> Hooks Class Initialized
DEBUG - 2018-11-17 09:02:18 --> UTF-8 Support Enabled
INFO - 2018-11-17 09:02:18 --> Utf8 Class Initialized
INFO - 2018-11-17 09:02:18 --> URI Class Initialized
INFO - 2018-11-17 09:02:18 --> Router Class Initialized
INFO - 2018-11-17 09:02:18 --> Output Class Initialized
INFO - 2018-11-17 09:02:18 --> Security Class Initialized
DEBUG - 2018-11-17 09:02:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-17 09:02:18 --> Input Class Initialized
INFO - 2018-11-17 09:02:18 --> Language Class Initialized
INFO - 2018-11-17 09:02:18 --> Loader Class Initialized
INFO - 2018-11-17 09:02:18 --> Helper loaded: url_helper
INFO - 2018-11-17 09:02:18 --> Helper loaded: file_helper
INFO - 2018-11-17 09:02:18 --> Helper loaded: email_helper
INFO - 2018-11-17 09:02:18 --> Helper loaded: common_helper
INFO - 2018-11-17 09:02:18 --> Database Driver Class Initialized
DEBUG - 2018-11-17 09:02:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-17 09:02:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-17 09:02:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-17 09:02:18 --> Pagination Class Initialized
INFO - 2018-11-17 09:02:18 --> Helper loaded: form_helper
INFO - 2018-11-17 09:02:18 --> Form Validation Class Initialized
INFO - 2018-11-17 09:02:18 --> Model Class Initialized
INFO - 2018-11-17 09:02:18 --> Controller Class Initialized
INFO - 2018-11-17 09:02:18 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-17 09:02:18 --> Model Class Initialized
INFO - 2018-11-17 09:02:18 --> Model Class Initialized
INFO - 2018-11-17 09:02:18 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/index.php
INFO - 2018-11-17 09:02:18 --> Final output sent to browser
DEBUG - 2018-11-17 09:02:18 --> Total execution time: 0.0706
INFO - 2018-11-17 09:03:34 --> Config Class Initialized
INFO - 2018-11-17 09:03:34 --> Hooks Class Initialized
DEBUG - 2018-11-17 09:03:34 --> UTF-8 Support Enabled
INFO - 2018-11-17 09:03:34 --> Utf8 Class Initialized
INFO - 2018-11-17 09:03:34 --> URI Class Initialized
INFO - 2018-11-17 09:03:34 --> Router Class Initialized
INFO - 2018-11-17 09:03:34 --> Output Class Initialized
INFO - 2018-11-17 09:03:34 --> Security Class Initialized
DEBUG - 2018-11-17 09:03:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-17 09:03:34 --> Input Class Initialized
INFO - 2018-11-17 09:03:34 --> Language Class Initialized
INFO - 2018-11-17 09:03:34 --> Loader Class Initialized
INFO - 2018-11-17 09:03:34 --> Helper loaded: url_helper
INFO - 2018-11-17 09:03:34 --> Helper loaded: file_helper
INFO - 2018-11-17 09:03:34 --> Helper loaded: email_helper
INFO - 2018-11-17 09:03:34 --> Helper loaded: common_helper
INFO - 2018-11-17 09:03:34 --> Database Driver Class Initialized
DEBUG - 2018-11-17 09:03:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-17 09:03:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-17 09:03:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-17 09:03:34 --> Pagination Class Initialized
INFO - 2018-11-17 09:03:34 --> Helper loaded: form_helper
INFO - 2018-11-17 09:03:34 --> Form Validation Class Initialized
INFO - 2018-11-17 09:03:34 --> Model Class Initialized
INFO - 2018-11-17 09:03:34 --> Controller Class Initialized
INFO - 2018-11-17 09:03:34 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-17 09:03:34 --> Model Class Initialized
INFO - 2018-11-17 09:03:34 --> Model Class Initialized
INFO - 2018-11-17 09:03:34 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/index.php
INFO - 2018-11-17 09:03:34 --> Final output sent to browser
DEBUG - 2018-11-17 09:03:34 --> Total execution time: 0.0480
INFO - 2018-11-17 09:03:50 --> Config Class Initialized
INFO - 2018-11-17 09:03:50 --> Hooks Class Initialized
DEBUG - 2018-11-17 09:03:50 --> UTF-8 Support Enabled
INFO - 2018-11-17 09:03:50 --> Utf8 Class Initialized
INFO - 2018-11-17 09:03:50 --> URI Class Initialized
INFO - 2018-11-17 09:03:50 --> Router Class Initialized
INFO - 2018-11-17 09:03:50 --> Output Class Initialized
INFO - 2018-11-17 09:03:50 --> Security Class Initialized
DEBUG - 2018-11-17 09:03:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-17 09:03:50 --> Input Class Initialized
INFO - 2018-11-17 09:03:50 --> Language Class Initialized
INFO - 2018-11-17 09:03:50 --> Loader Class Initialized
INFO - 2018-11-17 09:03:50 --> Helper loaded: url_helper
INFO - 2018-11-17 09:03:50 --> Helper loaded: file_helper
INFO - 2018-11-17 09:03:50 --> Helper loaded: email_helper
INFO - 2018-11-17 09:03:50 --> Helper loaded: common_helper
INFO - 2018-11-17 09:03:50 --> Database Driver Class Initialized
DEBUG - 2018-11-17 09:03:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-17 09:03:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-17 09:03:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-17 09:03:50 --> Pagination Class Initialized
INFO - 2018-11-17 09:03:50 --> Helper loaded: form_helper
INFO - 2018-11-17 09:03:50 --> Form Validation Class Initialized
INFO - 2018-11-17 09:03:50 --> Model Class Initialized
INFO - 2018-11-17 09:03:50 --> Controller Class Initialized
INFO - 2018-11-17 09:03:50 --> Model Class Initialized
INFO - 2018-11-17 09:03:50 --> Model Class Initialized
INFO - 2018-11-17 09:03:50 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\template/header-menu.php
INFO - 2018-11-17 09:03:50 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\template/header.php
INFO - 2018-11-17 09:03:50 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\template/footer.php
INFO - 2018-11-17 09:03:50 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\index.php
INFO - 2018-11-17 09:03:50 --> Final output sent to browser
DEBUG - 2018-11-17 09:03:50 --> Total execution time: 0.0686
INFO - 2018-11-17 09:03:53 --> Config Class Initialized
INFO - 2018-11-17 09:03:53 --> Hooks Class Initialized
DEBUG - 2018-11-17 09:03:53 --> UTF-8 Support Enabled
INFO - 2018-11-17 09:03:53 --> Utf8 Class Initialized
INFO - 2018-11-17 09:03:53 --> URI Class Initialized
INFO - 2018-11-17 09:03:53 --> Router Class Initialized
INFO - 2018-11-17 09:03:53 --> Output Class Initialized
INFO - 2018-11-17 09:03:53 --> Security Class Initialized
DEBUG - 2018-11-17 09:03:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-17 09:03:53 --> Input Class Initialized
INFO - 2018-11-17 09:03:53 --> Language Class Initialized
INFO - 2018-11-17 09:03:53 --> Loader Class Initialized
INFO - 2018-11-17 09:03:53 --> Helper loaded: url_helper
INFO - 2018-11-17 09:03:53 --> Helper loaded: file_helper
INFO - 2018-11-17 09:03:53 --> Helper loaded: email_helper
INFO - 2018-11-17 09:03:53 --> Helper loaded: common_helper
INFO - 2018-11-17 09:03:53 --> Database Driver Class Initialized
DEBUG - 2018-11-17 09:03:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-17 09:03:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-17 09:03:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-17 09:03:53 --> Pagination Class Initialized
INFO - 2018-11-17 09:03:53 --> Helper loaded: form_helper
INFO - 2018-11-17 09:03:53 --> Form Validation Class Initialized
INFO - 2018-11-17 09:03:53 --> Model Class Initialized
INFO - 2018-11-17 09:03:53 --> Controller Class Initialized
INFO - 2018-11-17 09:03:53 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-17 09:03:53 --> Model Class Initialized
INFO - 2018-11-17 09:03:53 --> Model Class Initialized
INFO - 2018-11-17 09:03:53 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/index.php
INFO - 2018-11-17 09:03:53 --> Final output sent to browser
DEBUG - 2018-11-17 09:03:53 --> Total execution time: 0.0600
INFO - 2018-11-17 09:04:02 --> Config Class Initialized
INFO - 2018-11-17 09:04:02 --> Hooks Class Initialized
DEBUG - 2018-11-17 09:04:02 --> UTF-8 Support Enabled
INFO - 2018-11-17 09:04:02 --> Utf8 Class Initialized
INFO - 2018-11-17 09:04:02 --> URI Class Initialized
INFO - 2018-11-17 09:04:02 --> Router Class Initialized
INFO - 2018-11-17 09:04:02 --> Output Class Initialized
INFO - 2018-11-17 09:04:02 --> Security Class Initialized
DEBUG - 2018-11-17 09:04:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-17 09:04:02 --> Input Class Initialized
INFO - 2018-11-17 09:04:02 --> Language Class Initialized
INFO - 2018-11-17 09:04:02 --> Loader Class Initialized
INFO - 2018-11-17 09:04:02 --> Helper loaded: url_helper
INFO - 2018-11-17 09:04:02 --> Helper loaded: file_helper
INFO - 2018-11-17 09:04:02 --> Helper loaded: email_helper
INFO - 2018-11-17 09:04:02 --> Helper loaded: common_helper
INFO - 2018-11-17 09:04:02 --> Database Driver Class Initialized
DEBUG - 2018-11-17 09:04:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-17 09:04:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-17 09:04:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-17 09:04:02 --> Pagination Class Initialized
INFO - 2018-11-17 09:04:02 --> Helper loaded: form_helper
INFO - 2018-11-17 09:04:02 --> Form Validation Class Initialized
INFO - 2018-11-17 09:04:02 --> Model Class Initialized
INFO - 2018-11-17 09:04:02 --> Controller Class Initialized
INFO - 2018-11-17 09:04:02 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-17 09:04:02 --> Model Class Initialized
INFO - 2018-11-17 09:04:02 --> Model Class Initialized
INFO - 2018-11-17 09:04:02 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/index.php
INFO - 2018-11-17 09:04:02 --> Final output sent to browser
DEBUG - 2018-11-17 09:04:02 --> Total execution time: 0.0460
INFO - 2018-11-17 09:04:07 --> Config Class Initialized
INFO - 2018-11-17 09:04:07 --> Hooks Class Initialized
DEBUG - 2018-11-17 09:04:07 --> UTF-8 Support Enabled
INFO - 2018-11-17 09:04:07 --> Utf8 Class Initialized
INFO - 2018-11-17 09:04:07 --> URI Class Initialized
INFO - 2018-11-17 09:04:07 --> Router Class Initialized
INFO - 2018-11-17 09:04:07 --> Output Class Initialized
INFO - 2018-11-17 09:04:07 --> Security Class Initialized
DEBUG - 2018-11-17 09:04:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-17 09:04:07 --> Input Class Initialized
INFO - 2018-11-17 09:04:07 --> Language Class Initialized
INFO - 2018-11-17 09:04:07 --> Loader Class Initialized
INFO - 2018-11-17 09:04:07 --> Helper loaded: url_helper
INFO - 2018-11-17 09:04:07 --> Helper loaded: file_helper
INFO - 2018-11-17 09:04:07 --> Helper loaded: email_helper
INFO - 2018-11-17 09:04:07 --> Helper loaded: common_helper
INFO - 2018-11-17 09:04:07 --> Database Driver Class Initialized
DEBUG - 2018-11-17 09:04:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-17 09:04:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-17 09:04:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-17 09:04:07 --> Pagination Class Initialized
INFO - 2018-11-17 09:04:07 --> Helper loaded: form_helper
INFO - 2018-11-17 09:04:07 --> Form Validation Class Initialized
INFO - 2018-11-17 09:04:07 --> Model Class Initialized
INFO - 2018-11-17 09:04:07 --> Controller Class Initialized
INFO - 2018-11-17 09:04:07 --> Model Class Initialized
INFO - 2018-11-17 09:04:07 --> Model Class Initialized
INFO - 2018-11-17 09:04:07 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\template/header-menu.php
INFO - 2018-11-17 09:04:07 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\template/header.php
INFO - 2018-11-17 09:04:07 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\template/footer.php
INFO - 2018-11-17 09:04:07 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\index.php
INFO - 2018-11-17 09:04:07 --> Final output sent to browser
DEBUG - 2018-11-17 09:04:07 --> Total execution time: 0.0590
INFO - 2018-11-17 09:04:37 --> Config Class Initialized
INFO - 2018-11-17 09:04:37 --> Hooks Class Initialized
DEBUG - 2018-11-17 09:04:37 --> UTF-8 Support Enabled
INFO - 2018-11-17 09:04:37 --> Utf8 Class Initialized
INFO - 2018-11-17 09:04:37 --> URI Class Initialized
INFO - 2018-11-17 09:04:37 --> Router Class Initialized
INFO - 2018-11-17 09:04:37 --> Output Class Initialized
INFO - 2018-11-17 09:04:37 --> Security Class Initialized
DEBUG - 2018-11-17 09:04:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-17 09:04:37 --> Input Class Initialized
INFO - 2018-11-17 09:04:37 --> Language Class Initialized
INFO - 2018-11-17 09:04:37 --> Loader Class Initialized
INFO - 2018-11-17 09:04:37 --> Helper loaded: url_helper
INFO - 2018-11-17 09:04:37 --> Helper loaded: file_helper
INFO - 2018-11-17 09:04:37 --> Helper loaded: email_helper
INFO - 2018-11-17 09:04:37 --> Helper loaded: common_helper
INFO - 2018-11-17 09:04:37 --> Database Driver Class Initialized
DEBUG - 2018-11-17 09:04:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-17 09:04:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-17 09:04:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-17 09:04:37 --> Pagination Class Initialized
INFO - 2018-11-17 09:04:37 --> Helper loaded: form_helper
INFO - 2018-11-17 09:04:37 --> Form Validation Class Initialized
INFO - 2018-11-17 09:04:37 --> Model Class Initialized
INFO - 2018-11-17 09:04:37 --> Controller Class Initialized
INFO - 2018-11-17 09:04:37 --> Model Class Initialized
INFO - 2018-11-17 09:04:37 --> Model Class Initialized
INFO - 2018-11-17 09:04:37 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\template/header-menu.php
INFO - 2018-11-17 09:04:37 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\template/header.php
INFO - 2018-11-17 09:04:37 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\template/footer.php
INFO - 2018-11-17 09:04:37 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\index.php
INFO - 2018-11-17 09:04:37 --> Final output sent to browser
DEBUG - 2018-11-17 09:04:37 --> Total execution time: 0.0580
INFO - 2018-11-17 09:04:39 --> Config Class Initialized
INFO - 2018-11-17 09:04:39 --> Hooks Class Initialized
DEBUG - 2018-11-17 09:04:39 --> UTF-8 Support Enabled
INFO - 2018-11-17 09:04:39 --> Utf8 Class Initialized
INFO - 2018-11-17 09:04:39 --> URI Class Initialized
INFO - 2018-11-17 09:04:39 --> Router Class Initialized
INFO - 2018-11-17 09:04:39 --> Output Class Initialized
INFO - 2018-11-17 09:04:39 --> Security Class Initialized
DEBUG - 2018-11-17 09:04:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-17 09:04:39 --> Input Class Initialized
INFO - 2018-11-17 09:04:39 --> Language Class Initialized
INFO - 2018-11-17 09:04:39 --> Loader Class Initialized
INFO - 2018-11-17 09:04:39 --> Helper loaded: url_helper
INFO - 2018-11-17 09:04:39 --> Helper loaded: file_helper
INFO - 2018-11-17 09:04:39 --> Helper loaded: email_helper
INFO - 2018-11-17 09:04:39 --> Helper loaded: common_helper
INFO - 2018-11-17 09:04:39 --> Database Driver Class Initialized
DEBUG - 2018-11-17 09:04:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-17 09:04:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-17 09:04:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-17 09:04:40 --> Pagination Class Initialized
INFO - 2018-11-17 09:04:40 --> Helper loaded: form_helper
INFO - 2018-11-17 09:04:40 --> Form Validation Class Initialized
INFO - 2018-11-17 09:04:40 --> Model Class Initialized
INFO - 2018-11-17 09:04:40 --> Controller Class Initialized
INFO - 2018-11-17 09:04:40 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-17 09:04:40 --> Model Class Initialized
INFO - 2018-11-17 09:04:40 --> Model Class Initialized
INFO - 2018-11-17 09:04:40 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/index.php
INFO - 2018-11-17 09:04:40 --> Final output sent to browser
DEBUG - 2018-11-17 09:04:40 --> Total execution time: 0.1380
INFO - 2018-11-17 09:04:42 --> Config Class Initialized
INFO - 2018-11-17 09:04:42 --> Hooks Class Initialized
DEBUG - 2018-11-17 09:04:42 --> UTF-8 Support Enabled
INFO - 2018-11-17 09:04:42 --> Utf8 Class Initialized
INFO - 2018-11-17 09:04:42 --> URI Class Initialized
INFO - 2018-11-17 09:04:42 --> Router Class Initialized
INFO - 2018-11-17 09:04:42 --> Output Class Initialized
INFO - 2018-11-17 09:04:42 --> Security Class Initialized
DEBUG - 2018-11-17 09:04:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-17 09:04:42 --> Input Class Initialized
INFO - 2018-11-17 09:04:42 --> Language Class Initialized
INFO - 2018-11-17 09:04:42 --> Loader Class Initialized
INFO - 2018-11-17 09:04:42 --> Helper loaded: url_helper
INFO - 2018-11-17 09:04:42 --> Helper loaded: file_helper
INFO - 2018-11-17 09:04:42 --> Helper loaded: email_helper
INFO - 2018-11-17 09:04:42 --> Helper loaded: common_helper
INFO - 2018-11-17 09:04:42 --> Database Driver Class Initialized
DEBUG - 2018-11-17 09:04:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-17 09:04:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-17 09:04:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-17 09:04:42 --> Pagination Class Initialized
INFO - 2018-11-17 09:04:42 --> Helper loaded: form_helper
INFO - 2018-11-17 09:04:42 --> Form Validation Class Initialized
INFO - 2018-11-17 09:04:42 --> Model Class Initialized
INFO - 2018-11-17 09:04:42 --> Controller Class Initialized
INFO - 2018-11-17 09:04:42 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-17 09:04:42 --> Model Class Initialized
INFO - 2018-11-17 09:04:42 --> Model Class Initialized
INFO - 2018-11-17 09:04:42 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/index.php
INFO - 2018-11-17 09:04:42 --> Final output sent to browser
DEBUG - 2018-11-17 09:04:42 --> Total execution time: 0.0600
INFO - 2018-11-17 09:05:50 --> Config Class Initialized
INFO - 2018-11-17 09:05:50 --> Hooks Class Initialized
DEBUG - 2018-11-17 09:05:50 --> UTF-8 Support Enabled
INFO - 2018-11-17 09:05:50 --> Utf8 Class Initialized
INFO - 2018-11-17 09:05:50 --> URI Class Initialized
INFO - 2018-11-17 09:05:50 --> Router Class Initialized
INFO - 2018-11-17 09:05:50 --> Output Class Initialized
INFO - 2018-11-17 09:05:50 --> Security Class Initialized
DEBUG - 2018-11-17 09:05:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-17 09:05:50 --> Input Class Initialized
INFO - 2018-11-17 09:05:50 --> Language Class Initialized
INFO - 2018-11-17 09:05:50 --> Loader Class Initialized
INFO - 2018-11-17 09:05:50 --> Helper loaded: url_helper
INFO - 2018-11-17 09:05:50 --> Helper loaded: file_helper
INFO - 2018-11-17 09:05:50 --> Helper loaded: email_helper
INFO - 2018-11-17 09:05:50 --> Helper loaded: common_helper
INFO - 2018-11-17 09:05:50 --> Database Driver Class Initialized
DEBUG - 2018-11-17 09:05:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-17 09:05:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-17 09:05:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-17 09:05:50 --> Pagination Class Initialized
INFO - 2018-11-17 09:05:50 --> Helper loaded: form_helper
INFO - 2018-11-17 09:05:50 --> Form Validation Class Initialized
INFO - 2018-11-17 09:05:50 --> Model Class Initialized
INFO - 2018-11-17 09:05:50 --> Controller Class Initialized
INFO - 2018-11-17 09:05:50 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-17 09:05:50 --> Model Class Initialized
INFO - 2018-11-17 09:05:50 --> Model Class Initialized
INFO - 2018-11-17 09:05:50 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/index.php
INFO - 2018-11-17 09:05:50 --> Final output sent to browser
DEBUG - 2018-11-17 09:05:50 --> Total execution time: 0.0480
INFO - 2018-11-17 09:05:54 --> Config Class Initialized
INFO - 2018-11-17 09:05:54 --> Hooks Class Initialized
DEBUG - 2018-11-17 09:05:54 --> UTF-8 Support Enabled
INFO - 2018-11-17 09:05:54 --> Utf8 Class Initialized
INFO - 2018-11-17 09:05:54 --> URI Class Initialized
INFO - 2018-11-17 09:05:54 --> Router Class Initialized
INFO - 2018-11-17 09:05:54 --> Output Class Initialized
INFO - 2018-11-17 09:05:54 --> Security Class Initialized
DEBUG - 2018-11-17 09:05:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-17 09:05:54 --> Input Class Initialized
INFO - 2018-11-17 09:05:54 --> Language Class Initialized
INFO - 2018-11-17 09:05:54 --> Loader Class Initialized
INFO - 2018-11-17 09:05:54 --> Helper loaded: url_helper
INFO - 2018-11-17 09:05:54 --> Helper loaded: file_helper
INFO - 2018-11-17 09:05:54 --> Helper loaded: email_helper
INFO - 2018-11-17 09:05:54 --> Helper loaded: common_helper
INFO - 2018-11-17 09:05:54 --> Database Driver Class Initialized
DEBUG - 2018-11-17 09:05:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-17 09:05:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-17 09:05:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-17 09:05:54 --> Pagination Class Initialized
INFO - 2018-11-17 09:05:54 --> Helper loaded: form_helper
INFO - 2018-11-17 09:05:54 --> Form Validation Class Initialized
INFO - 2018-11-17 09:05:54 --> Model Class Initialized
INFO - 2018-11-17 09:05:54 --> Controller Class Initialized
INFO - 2018-11-17 09:05:54 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-17 09:05:54 --> Model Class Initialized
INFO - 2018-11-17 09:05:54 --> Model Class Initialized
INFO - 2018-11-17 09:05:54 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/index.php
INFO - 2018-11-17 09:05:54 --> Final output sent to browser
DEBUG - 2018-11-17 09:05:54 --> Total execution time: 0.0600
INFO - 2018-11-17 09:05:58 --> Config Class Initialized
INFO - 2018-11-17 09:05:58 --> Hooks Class Initialized
DEBUG - 2018-11-17 09:05:58 --> UTF-8 Support Enabled
INFO - 2018-11-17 09:05:58 --> Utf8 Class Initialized
INFO - 2018-11-17 09:05:58 --> URI Class Initialized
INFO - 2018-11-17 09:05:58 --> Router Class Initialized
INFO - 2018-11-17 09:05:58 --> Output Class Initialized
INFO - 2018-11-17 09:05:58 --> Security Class Initialized
DEBUG - 2018-11-17 09:05:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-17 09:05:58 --> Input Class Initialized
INFO - 2018-11-17 09:05:58 --> Language Class Initialized
INFO - 2018-11-17 09:05:58 --> Loader Class Initialized
INFO - 2018-11-17 09:05:58 --> Helper loaded: url_helper
INFO - 2018-11-17 09:05:58 --> Helper loaded: file_helper
INFO - 2018-11-17 09:05:58 --> Helper loaded: email_helper
INFO - 2018-11-17 09:05:58 --> Helper loaded: common_helper
INFO - 2018-11-17 09:05:58 --> Database Driver Class Initialized
DEBUG - 2018-11-17 09:05:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-17 09:05:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-17 09:05:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-17 09:05:58 --> Pagination Class Initialized
INFO - 2018-11-17 09:05:58 --> Helper loaded: form_helper
INFO - 2018-11-17 09:05:58 --> Form Validation Class Initialized
INFO - 2018-11-17 09:05:58 --> Model Class Initialized
INFO - 2018-11-17 09:05:58 --> Controller Class Initialized
INFO - 2018-11-17 09:05:58 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-17 09:05:58 --> Model Class Initialized
INFO - 2018-11-17 09:05:58 --> Model Class Initialized
INFO - 2018-11-17 09:05:58 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/index.php
INFO - 2018-11-17 09:05:58 --> Final output sent to browser
DEBUG - 2018-11-17 09:05:58 --> Total execution time: 0.0550
INFO - 2018-11-17 09:06:01 --> Config Class Initialized
INFO - 2018-11-17 09:06:01 --> Hooks Class Initialized
DEBUG - 2018-11-17 09:06:01 --> UTF-8 Support Enabled
INFO - 2018-11-17 09:06:01 --> Utf8 Class Initialized
INFO - 2018-11-17 09:06:01 --> URI Class Initialized
INFO - 2018-11-17 09:06:01 --> Router Class Initialized
INFO - 2018-11-17 09:06:01 --> Output Class Initialized
INFO - 2018-11-17 09:06:01 --> Security Class Initialized
DEBUG - 2018-11-17 09:06:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-17 09:06:01 --> Input Class Initialized
INFO - 2018-11-17 09:06:01 --> Language Class Initialized
INFO - 2018-11-17 09:06:01 --> Loader Class Initialized
INFO - 2018-11-17 09:06:01 --> Helper loaded: url_helper
INFO - 2018-11-17 09:06:01 --> Helper loaded: file_helper
INFO - 2018-11-17 09:06:01 --> Helper loaded: email_helper
INFO - 2018-11-17 09:06:01 --> Helper loaded: common_helper
INFO - 2018-11-17 09:06:01 --> Database Driver Class Initialized
DEBUG - 2018-11-17 09:06:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-17 09:06:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-17 09:06:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-17 09:06:01 --> Pagination Class Initialized
INFO - 2018-11-17 09:06:01 --> Helper loaded: form_helper
INFO - 2018-11-17 09:06:01 --> Form Validation Class Initialized
INFO - 2018-11-17 09:06:01 --> Model Class Initialized
INFO - 2018-11-17 09:06:01 --> Controller Class Initialized
INFO - 2018-11-17 09:06:01 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-17 09:06:01 --> Model Class Initialized
INFO - 2018-11-17 09:06:01 --> Model Class Initialized
INFO - 2018-11-17 09:06:01 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/index.php
INFO - 2018-11-17 09:06:01 --> Final output sent to browser
DEBUG - 2018-11-17 09:06:01 --> Total execution time: 0.0560
INFO - 2018-11-17 10:26:12 --> Config Class Initialized
INFO - 2018-11-17 10:26:12 --> Hooks Class Initialized
DEBUG - 2018-11-17 10:26:12 --> UTF-8 Support Enabled
INFO - 2018-11-17 10:26:12 --> Utf8 Class Initialized
INFO - 2018-11-17 10:26:12 --> URI Class Initialized
INFO - 2018-11-17 10:26:12 --> Router Class Initialized
INFO - 2018-11-17 10:26:12 --> Output Class Initialized
INFO - 2018-11-17 10:26:12 --> Security Class Initialized
DEBUG - 2018-11-17 10:26:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-17 10:26:12 --> Input Class Initialized
INFO - 2018-11-17 10:26:12 --> Language Class Initialized
INFO - 2018-11-17 10:26:12 --> Loader Class Initialized
INFO - 2018-11-17 10:26:12 --> Helper loaded: url_helper
INFO - 2018-11-17 10:26:12 --> Helper loaded: file_helper
INFO - 2018-11-17 10:26:12 --> Helper loaded: email_helper
INFO - 2018-11-17 10:26:12 --> Helper loaded: common_helper
INFO - 2018-11-17 10:26:12 --> Database Driver Class Initialized
DEBUG - 2018-11-17 10:26:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-17 10:26:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-17 10:26:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-17 10:26:12 --> Pagination Class Initialized
INFO - 2018-11-17 10:26:12 --> Helper loaded: form_helper
INFO - 2018-11-17 10:26:12 --> Form Validation Class Initialized
INFO - 2018-11-17 10:26:12 --> Model Class Initialized
INFO - 2018-11-17 10:26:12 --> Controller Class Initialized
INFO - 2018-11-17 10:26:12 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-17 10:26:12 --> Model Class Initialized
INFO - 2018-11-17 10:26:12 --> Model Class Initialized
INFO - 2018-11-17 10:26:12 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/index.php
INFO - 2018-11-17 10:26:12 --> Final output sent to browser
DEBUG - 2018-11-17 10:26:12 --> Total execution time: 0.1470
INFO - 2018-11-17 10:29:21 --> Config Class Initialized
INFO - 2018-11-17 10:29:21 --> Hooks Class Initialized
DEBUG - 2018-11-17 10:29:21 --> UTF-8 Support Enabled
INFO - 2018-11-17 10:29:21 --> Utf8 Class Initialized
INFO - 2018-11-17 10:29:21 --> URI Class Initialized
INFO - 2018-11-17 10:29:21 --> Router Class Initialized
INFO - 2018-11-17 10:29:21 --> Output Class Initialized
INFO - 2018-11-17 10:29:21 --> Security Class Initialized
DEBUG - 2018-11-17 10:29:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-17 10:29:21 --> Input Class Initialized
INFO - 2018-11-17 10:29:21 --> Language Class Initialized
INFO - 2018-11-17 10:29:21 --> Loader Class Initialized
INFO - 2018-11-17 10:29:21 --> Helper loaded: url_helper
INFO - 2018-11-17 10:29:21 --> Helper loaded: file_helper
INFO - 2018-11-17 10:29:21 --> Helper loaded: email_helper
INFO - 2018-11-17 10:29:21 --> Helper loaded: common_helper
INFO - 2018-11-17 10:29:21 --> Database Driver Class Initialized
DEBUG - 2018-11-17 10:29:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-17 10:29:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-17 10:29:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-17 10:29:21 --> Pagination Class Initialized
INFO - 2018-11-17 10:29:21 --> Helper loaded: form_helper
INFO - 2018-11-17 10:29:21 --> Form Validation Class Initialized
INFO - 2018-11-17 10:29:21 --> Model Class Initialized
INFO - 2018-11-17 10:29:21 --> Controller Class Initialized
INFO - 2018-11-17 10:29:21 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-17 10:29:21 --> Model Class Initialized
INFO - 2018-11-17 10:29:21 --> Model Class Initialized
INFO - 2018-11-17 10:29:21 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/index.php
INFO - 2018-11-17 10:29:21 --> Final output sent to browser
DEBUG - 2018-11-17 10:29:21 --> Total execution time: 0.0686
INFO - 2018-11-17 10:31:52 --> Config Class Initialized
INFO - 2018-11-17 10:31:52 --> Hooks Class Initialized
DEBUG - 2018-11-17 10:31:52 --> UTF-8 Support Enabled
INFO - 2018-11-17 10:31:52 --> Utf8 Class Initialized
INFO - 2018-11-17 10:31:52 --> URI Class Initialized
INFO - 2018-11-17 10:31:52 --> Router Class Initialized
INFO - 2018-11-17 10:31:52 --> Output Class Initialized
INFO - 2018-11-17 10:31:52 --> Security Class Initialized
DEBUG - 2018-11-17 10:31:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-17 10:31:52 --> Input Class Initialized
INFO - 2018-11-17 10:31:52 --> Language Class Initialized
INFO - 2018-11-17 10:31:52 --> Loader Class Initialized
INFO - 2018-11-17 10:31:52 --> Helper loaded: url_helper
INFO - 2018-11-17 10:31:52 --> Helper loaded: file_helper
INFO - 2018-11-17 10:31:52 --> Helper loaded: email_helper
INFO - 2018-11-17 10:31:52 --> Helper loaded: common_helper
INFO - 2018-11-17 10:31:52 --> Database Driver Class Initialized
DEBUG - 2018-11-17 10:31:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-17 10:31:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-17 10:31:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-17 10:31:52 --> Pagination Class Initialized
INFO - 2018-11-17 10:31:52 --> Helper loaded: form_helper
INFO - 2018-11-17 10:31:52 --> Form Validation Class Initialized
INFO - 2018-11-17 10:31:52 --> Model Class Initialized
INFO - 2018-11-17 10:31:52 --> Controller Class Initialized
INFO - 2018-11-17 10:31:52 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-17 10:31:52 --> Model Class Initialized
INFO - 2018-11-17 10:31:52 --> Model Class Initialized
INFO - 2018-11-17 10:31:52 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/index.php
INFO - 2018-11-17 10:31:52 --> Final output sent to browser
DEBUG - 2018-11-17 10:31:52 --> Total execution time: 0.0540
INFO - 2018-11-17 10:31:55 --> Config Class Initialized
INFO - 2018-11-17 10:31:55 --> Hooks Class Initialized
DEBUG - 2018-11-17 10:31:55 --> UTF-8 Support Enabled
INFO - 2018-11-17 10:31:55 --> Utf8 Class Initialized
INFO - 2018-11-17 10:31:55 --> URI Class Initialized
INFO - 2018-11-17 10:31:55 --> Router Class Initialized
INFO - 2018-11-17 10:31:55 --> Output Class Initialized
INFO - 2018-11-17 10:31:55 --> Security Class Initialized
DEBUG - 2018-11-17 10:31:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-17 10:31:55 --> Input Class Initialized
INFO - 2018-11-17 10:31:55 --> Language Class Initialized
INFO - 2018-11-17 10:31:55 --> Loader Class Initialized
INFO - 2018-11-17 10:31:55 --> Helper loaded: url_helper
INFO - 2018-11-17 10:31:55 --> Helper loaded: file_helper
INFO - 2018-11-17 10:31:55 --> Helper loaded: email_helper
INFO - 2018-11-17 10:31:55 --> Helper loaded: common_helper
INFO - 2018-11-17 10:31:55 --> Database Driver Class Initialized
DEBUG - 2018-11-17 10:31:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-17 10:31:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-17 10:31:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-17 10:31:55 --> Pagination Class Initialized
INFO - 2018-11-17 10:31:55 --> Helper loaded: form_helper
INFO - 2018-11-17 10:31:55 --> Form Validation Class Initialized
INFO - 2018-11-17 10:31:55 --> Model Class Initialized
INFO - 2018-11-17 10:31:55 --> Controller Class Initialized
INFO - 2018-11-17 10:31:55 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-17 10:31:55 --> Model Class Initialized
INFO - 2018-11-17 10:31:55 --> Model Class Initialized
INFO - 2018-11-17 10:31:55 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/index.php
INFO - 2018-11-17 10:31:55 --> Final output sent to browser
DEBUG - 2018-11-17 10:31:55 --> Total execution time: 0.0530
INFO - 2018-11-17 10:31:57 --> Config Class Initialized
INFO - 2018-11-17 10:31:57 --> Hooks Class Initialized
DEBUG - 2018-11-17 10:31:57 --> UTF-8 Support Enabled
INFO - 2018-11-17 10:31:57 --> Utf8 Class Initialized
INFO - 2018-11-17 10:31:57 --> URI Class Initialized
INFO - 2018-11-17 10:31:57 --> Router Class Initialized
INFO - 2018-11-17 10:31:57 --> Output Class Initialized
INFO - 2018-11-17 10:31:57 --> Security Class Initialized
DEBUG - 2018-11-17 10:31:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-17 10:31:57 --> Input Class Initialized
INFO - 2018-11-17 10:31:57 --> Language Class Initialized
INFO - 2018-11-17 10:31:57 --> Loader Class Initialized
INFO - 2018-11-17 10:31:57 --> Helper loaded: url_helper
INFO - 2018-11-17 10:31:57 --> Helper loaded: file_helper
INFO - 2018-11-17 10:31:57 --> Helper loaded: email_helper
INFO - 2018-11-17 10:31:57 --> Helper loaded: common_helper
INFO - 2018-11-17 10:31:57 --> Database Driver Class Initialized
DEBUG - 2018-11-17 10:31:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-17 10:31:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-17 10:31:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-17 10:31:57 --> Pagination Class Initialized
INFO - 2018-11-17 10:31:57 --> Helper loaded: form_helper
INFO - 2018-11-17 10:31:57 --> Form Validation Class Initialized
INFO - 2018-11-17 10:31:57 --> Model Class Initialized
INFO - 2018-11-17 10:31:57 --> Controller Class Initialized
INFO - 2018-11-17 10:31:57 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-17 10:31:57 --> Model Class Initialized
INFO - 2018-11-17 10:31:57 --> Model Class Initialized
INFO - 2018-11-17 10:31:57 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/index.php
INFO - 2018-11-17 10:31:57 --> Final output sent to browser
DEBUG - 2018-11-17 10:31:57 --> Total execution time: 0.0680
INFO - 2018-11-17 10:31:59 --> Config Class Initialized
INFO - 2018-11-17 10:31:59 --> Hooks Class Initialized
DEBUG - 2018-11-17 10:31:59 --> UTF-8 Support Enabled
INFO - 2018-11-17 10:31:59 --> Utf8 Class Initialized
INFO - 2018-11-17 10:31:59 --> URI Class Initialized
INFO - 2018-11-17 10:31:59 --> Router Class Initialized
INFO - 2018-11-17 10:31:59 --> Output Class Initialized
INFO - 2018-11-17 10:31:59 --> Security Class Initialized
DEBUG - 2018-11-17 10:31:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-17 10:31:59 --> Input Class Initialized
INFO - 2018-11-17 10:31:59 --> Language Class Initialized
INFO - 2018-11-17 10:31:59 --> Loader Class Initialized
INFO - 2018-11-17 10:31:59 --> Helper loaded: url_helper
INFO - 2018-11-17 10:31:59 --> Helper loaded: file_helper
INFO - 2018-11-17 10:31:59 --> Helper loaded: email_helper
INFO - 2018-11-17 10:31:59 --> Helper loaded: common_helper
INFO - 2018-11-17 10:31:59 --> Database Driver Class Initialized
DEBUG - 2018-11-17 10:31:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-17 10:31:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-17 10:31:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-17 10:31:59 --> Pagination Class Initialized
INFO - 2018-11-17 10:31:59 --> Helper loaded: form_helper
INFO - 2018-11-17 10:31:59 --> Form Validation Class Initialized
INFO - 2018-11-17 10:31:59 --> Model Class Initialized
INFO - 2018-11-17 10:31:59 --> Controller Class Initialized
INFO - 2018-11-17 10:31:59 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-17 10:31:59 --> Model Class Initialized
INFO - 2018-11-17 10:31:59 --> Model Class Initialized
INFO - 2018-11-17 10:31:59 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/index.php
INFO - 2018-11-17 10:31:59 --> Final output sent to browser
DEBUG - 2018-11-17 10:31:59 --> Total execution time: 0.0480
INFO - 2018-11-17 10:32:01 --> Config Class Initialized
INFO - 2018-11-17 10:32:01 --> Hooks Class Initialized
DEBUG - 2018-11-17 10:32:01 --> UTF-8 Support Enabled
INFO - 2018-11-17 10:32:01 --> Utf8 Class Initialized
INFO - 2018-11-17 10:32:01 --> URI Class Initialized
INFO - 2018-11-17 10:32:01 --> Router Class Initialized
INFO - 2018-11-17 10:32:01 --> Output Class Initialized
INFO - 2018-11-17 10:32:01 --> Security Class Initialized
DEBUG - 2018-11-17 10:32:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-17 10:32:01 --> Input Class Initialized
INFO - 2018-11-17 10:32:01 --> Language Class Initialized
INFO - 2018-11-17 10:32:01 --> Loader Class Initialized
INFO - 2018-11-17 10:32:01 --> Helper loaded: url_helper
INFO - 2018-11-17 10:32:01 --> Helper loaded: file_helper
INFO - 2018-11-17 10:32:01 --> Helper loaded: email_helper
INFO - 2018-11-17 10:32:01 --> Helper loaded: common_helper
INFO - 2018-11-17 10:32:01 --> Database Driver Class Initialized
DEBUG - 2018-11-17 10:32:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-17 10:32:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-17 10:32:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-17 10:32:01 --> Pagination Class Initialized
INFO - 2018-11-17 10:32:01 --> Helper loaded: form_helper
INFO - 2018-11-17 10:32:01 --> Form Validation Class Initialized
INFO - 2018-11-17 10:32:01 --> Model Class Initialized
INFO - 2018-11-17 10:32:01 --> Controller Class Initialized
INFO - 2018-11-17 10:32:01 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-17 10:32:01 --> Model Class Initialized
INFO - 2018-11-17 10:32:01 --> Model Class Initialized
INFO - 2018-11-17 10:32:01 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/index.php
INFO - 2018-11-17 10:32:01 --> Final output sent to browser
DEBUG - 2018-11-17 10:32:01 --> Total execution time: 0.0450
INFO - 2018-11-17 10:32:07 --> Config Class Initialized
INFO - 2018-11-17 10:32:07 --> Hooks Class Initialized
DEBUG - 2018-11-17 10:32:07 --> UTF-8 Support Enabled
INFO - 2018-11-17 10:32:07 --> Utf8 Class Initialized
INFO - 2018-11-17 10:32:07 --> URI Class Initialized
INFO - 2018-11-17 10:32:07 --> Router Class Initialized
INFO - 2018-11-17 10:32:07 --> Output Class Initialized
INFO - 2018-11-17 10:32:07 --> Security Class Initialized
DEBUG - 2018-11-17 10:32:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-17 10:32:07 --> Input Class Initialized
INFO - 2018-11-17 10:32:07 --> Language Class Initialized
INFO - 2018-11-17 10:32:07 --> Loader Class Initialized
INFO - 2018-11-17 10:32:07 --> Helper loaded: url_helper
INFO - 2018-11-17 10:32:07 --> Helper loaded: file_helper
INFO - 2018-11-17 10:32:07 --> Helper loaded: email_helper
INFO - 2018-11-17 10:32:07 --> Helper loaded: common_helper
INFO - 2018-11-17 10:32:07 --> Database Driver Class Initialized
DEBUG - 2018-11-17 10:32:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-17 10:32:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-17 10:32:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-17 10:32:07 --> Pagination Class Initialized
INFO - 2018-11-17 10:32:07 --> Helper loaded: form_helper
INFO - 2018-11-17 10:32:07 --> Form Validation Class Initialized
INFO - 2018-11-17 10:32:07 --> Model Class Initialized
INFO - 2018-11-17 10:32:07 --> Controller Class Initialized
INFO - 2018-11-17 10:32:07 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-17 10:32:07 --> Model Class Initialized
INFO - 2018-11-17 10:32:07 --> Model Class Initialized
INFO - 2018-11-17 10:32:07 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/index.php
INFO - 2018-11-17 10:32:07 --> Final output sent to browser
DEBUG - 2018-11-17 10:32:07 --> Total execution time: 0.0560
INFO - 2018-11-17 10:34:48 --> Config Class Initialized
INFO - 2018-11-17 10:34:48 --> Hooks Class Initialized
DEBUG - 2018-11-17 10:34:48 --> UTF-8 Support Enabled
INFO - 2018-11-17 10:34:48 --> Utf8 Class Initialized
INFO - 2018-11-17 10:34:48 --> URI Class Initialized
INFO - 2018-11-17 10:34:48 --> Router Class Initialized
INFO - 2018-11-17 10:34:48 --> Output Class Initialized
INFO - 2018-11-17 10:34:48 --> Security Class Initialized
DEBUG - 2018-11-17 10:34:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-17 10:34:48 --> Input Class Initialized
INFO - 2018-11-17 10:34:48 --> Language Class Initialized
INFO - 2018-11-17 10:34:48 --> Loader Class Initialized
INFO - 2018-11-17 10:34:48 --> Helper loaded: url_helper
INFO - 2018-11-17 10:34:48 --> Helper loaded: file_helper
INFO - 2018-11-17 10:34:48 --> Helper loaded: email_helper
INFO - 2018-11-17 10:34:48 --> Helper loaded: common_helper
INFO - 2018-11-17 10:34:48 --> Database Driver Class Initialized
DEBUG - 2018-11-17 10:34:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-17 10:34:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-17 10:34:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-17 10:34:48 --> Pagination Class Initialized
INFO - 2018-11-17 10:34:48 --> Helper loaded: form_helper
INFO - 2018-11-17 10:34:49 --> Form Validation Class Initialized
INFO - 2018-11-17 10:34:49 --> Model Class Initialized
INFO - 2018-11-17 10:34:49 --> Controller Class Initialized
INFO - 2018-11-17 10:34:49 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-17 10:34:49 --> Model Class Initialized
INFO - 2018-11-17 10:34:49 --> Model Class Initialized
INFO - 2018-11-17 10:34:49 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/index.php
INFO - 2018-11-17 10:34:49 --> Final output sent to browser
DEBUG - 2018-11-17 10:34:49 --> Total execution time: 0.0480
INFO - 2018-11-17 10:34:53 --> Config Class Initialized
INFO - 2018-11-17 10:34:53 --> Hooks Class Initialized
DEBUG - 2018-11-17 10:34:53 --> UTF-8 Support Enabled
INFO - 2018-11-17 10:34:53 --> Utf8 Class Initialized
INFO - 2018-11-17 10:34:53 --> URI Class Initialized
INFO - 2018-11-17 10:34:53 --> Router Class Initialized
INFO - 2018-11-17 10:34:53 --> Output Class Initialized
INFO - 2018-11-17 10:34:53 --> Security Class Initialized
DEBUG - 2018-11-17 10:34:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-17 10:34:53 --> Input Class Initialized
INFO - 2018-11-17 10:34:53 --> Language Class Initialized
INFO - 2018-11-17 10:34:53 --> Loader Class Initialized
INFO - 2018-11-17 10:34:53 --> Helper loaded: url_helper
INFO - 2018-11-17 10:34:53 --> Helper loaded: file_helper
INFO - 2018-11-17 10:34:53 --> Helper loaded: email_helper
INFO - 2018-11-17 10:34:53 --> Helper loaded: common_helper
INFO - 2018-11-17 10:34:53 --> Database Driver Class Initialized
DEBUG - 2018-11-17 10:34:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-17 10:34:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-17 10:34:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-17 10:34:53 --> Pagination Class Initialized
INFO - 2018-11-17 10:34:53 --> Helper loaded: form_helper
INFO - 2018-11-17 10:34:53 --> Form Validation Class Initialized
INFO - 2018-11-17 10:34:53 --> Model Class Initialized
INFO - 2018-11-17 10:34:53 --> Controller Class Initialized
INFO - 2018-11-17 10:34:53 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-17 10:34:53 --> Model Class Initialized
INFO - 2018-11-17 10:34:53 --> Model Class Initialized
INFO - 2018-11-17 10:34:53 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/index.php
INFO - 2018-11-17 10:34:53 --> Final output sent to browser
DEBUG - 2018-11-17 10:34:53 --> Total execution time: 0.0590
INFO - 2018-11-17 10:35:06 --> Config Class Initialized
INFO - 2018-11-17 10:35:06 --> Hooks Class Initialized
DEBUG - 2018-11-17 10:35:06 --> UTF-8 Support Enabled
INFO - 2018-11-17 10:35:06 --> Utf8 Class Initialized
INFO - 2018-11-17 10:35:06 --> URI Class Initialized
INFO - 2018-11-17 10:35:06 --> Router Class Initialized
INFO - 2018-11-17 10:35:06 --> Output Class Initialized
INFO - 2018-11-17 10:35:06 --> Security Class Initialized
DEBUG - 2018-11-17 10:35:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-17 10:35:06 --> Input Class Initialized
INFO - 2018-11-17 10:35:06 --> Language Class Initialized
INFO - 2018-11-17 10:35:06 --> Loader Class Initialized
INFO - 2018-11-17 10:35:06 --> Helper loaded: url_helper
INFO - 2018-11-17 10:35:06 --> Helper loaded: file_helper
INFO - 2018-11-17 10:35:06 --> Helper loaded: email_helper
INFO - 2018-11-17 10:35:06 --> Helper loaded: common_helper
INFO - 2018-11-17 10:35:06 --> Database Driver Class Initialized
DEBUG - 2018-11-17 10:35:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-17 10:35:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-17 10:35:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-17 10:35:06 --> Pagination Class Initialized
INFO - 2018-11-17 10:35:06 --> Helper loaded: form_helper
INFO - 2018-11-17 10:35:06 --> Form Validation Class Initialized
INFO - 2018-11-17 10:35:06 --> Model Class Initialized
INFO - 2018-11-17 10:35:06 --> Controller Class Initialized
INFO - 2018-11-17 10:35:06 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-17 10:35:06 --> Model Class Initialized
INFO - 2018-11-17 10:35:06 --> Model Class Initialized
INFO - 2018-11-17 10:35:06 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/index.php
INFO - 2018-11-17 10:35:06 --> Final output sent to browser
DEBUG - 2018-11-17 10:35:06 --> Total execution time: 0.0600
INFO - 2018-11-17 10:35:56 --> Config Class Initialized
INFO - 2018-11-17 10:35:56 --> Hooks Class Initialized
DEBUG - 2018-11-17 10:35:56 --> UTF-8 Support Enabled
INFO - 2018-11-17 10:35:56 --> Utf8 Class Initialized
INFO - 2018-11-17 10:35:56 --> URI Class Initialized
INFO - 2018-11-17 10:35:56 --> Router Class Initialized
INFO - 2018-11-17 10:35:56 --> Output Class Initialized
INFO - 2018-11-17 10:35:56 --> Security Class Initialized
DEBUG - 2018-11-17 10:35:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-17 10:35:56 --> Input Class Initialized
INFO - 2018-11-17 10:35:56 --> Language Class Initialized
INFO - 2018-11-17 10:35:56 --> Loader Class Initialized
INFO - 2018-11-17 10:35:56 --> Helper loaded: url_helper
INFO - 2018-11-17 10:35:56 --> Helper loaded: file_helper
INFO - 2018-11-17 10:35:56 --> Helper loaded: email_helper
INFO - 2018-11-17 10:35:56 --> Helper loaded: common_helper
INFO - 2018-11-17 10:35:56 --> Database Driver Class Initialized
DEBUG - 2018-11-17 10:35:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-17 10:35:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-17 10:35:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-17 10:35:56 --> Pagination Class Initialized
INFO - 2018-11-17 10:35:56 --> Helper loaded: form_helper
INFO - 2018-11-17 10:35:56 --> Form Validation Class Initialized
INFO - 2018-11-17 10:35:56 --> Model Class Initialized
INFO - 2018-11-17 10:35:56 --> Controller Class Initialized
INFO - 2018-11-17 10:35:56 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-17 10:35:56 --> Model Class Initialized
INFO - 2018-11-17 10:35:56 --> Model Class Initialized
INFO - 2018-11-17 10:35:56 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/index.php
INFO - 2018-11-17 10:35:56 --> Final output sent to browser
DEBUG - 2018-11-17 10:35:56 --> Total execution time: 0.0690
INFO - 2018-11-17 10:36:22 --> Config Class Initialized
INFO - 2018-11-17 10:36:22 --> Hooks Class Initialized
DEBUG - 2018-11-17 10:36:22 --> UTF-8 Support Enabled
INFO - 2018-11-17 10:36:22 --> Utf8 Class Initialized
INFO - 2018-11-17 10:36:22 --> URI Class Initialized
INFO - 2018-11-17 10:36:22 --> Router Class Initialized
INFO - 2018-11-17 10:36:22 --> Output Class Initialized
INFO - 2018-11-17 10:36:22 --> Security Class Initialized
DEBUG - 2018-11-17 10:36:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-17 10:36:22 --> Input Class Initialized
INFO - 2018-11-17 10:36:22 --> Language Class Initialized
INFO - 2018-11-17 10:36:22 --> Loader Class Initialized
INFO - 2018-11-17 10:36:22 --> Helper loaded: url_helper
INFO - 2018-11-17 10:36:22 --> Helper loaded: file_helper
INFO - 2018-11-17 10:36:22 --> Helper loaded: email_helper
INFO - 2018-11-17 10:36:22 --> Helper loaded: common_helper
INFO - 2018-11-17 10:36:22 --> Database Driver Class Initialized
DEBUG - 2018-11-17 10:36:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-17 10:36:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-17 10:36:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-17 10:36:22 --> Pagination Class Initialized
INFO - 2018-11-17 10:36:22 --> Helper loaded: form_helper
INFO - 2018-11-17 10:36:22 --> Form Validation Class Initialized
INFO - 2018-11-17 10:36:22 --> Model Class Initialized
INFO - 2018-11-17 10:36:22 --> Controller Class Initialized
INFO - 2018-11-17 10:36:22 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-17 10:36:22 --> Model Class Initialized
INFO - 2018-11-17 10:36:22 --> Model Class Initialized
ERROR - 2018-11-17 10:36:22 --> Severity: Notice --> Undefined index: remember_me C:\xampp\htdocs\wetinuneed\application\controllers\Admin.php 74
INFO - 2018-11-17 10:36:22 --> Config Class Initialized
INFO - 2018-11-17 10:36:22 --> Hooks Class Initialized
DEBUG - 2018-11-17 10:36:22 --> UTF-8 Support Enabled
INFO - 2018-11-17 10:36:22 --> Utf8 Class Initialized
INFO - 2018-11-17 10:36:22 --> URI Class Initialized
INFO - 2018-11-17 10:36:22 --> Router Class Initialized
INFO - 2018-11-17 10:36:22 --> Output Class Initialized
INFO - 2018-11-17 10:36:22 --> Security Class Initialized
DEBUG - 2018-11-17 10:36:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-17 10:36:22 --> Input Class Initialized
INFO - 2018-11-17 10:36:22 --> Language Class Initialized
INFO - 2018-11-17 10:36:22 --> Loader Class Initialized
INFO - 2018-11-17 10:36:22 --> Helper loaded: url_helper
INFO - 2018-11-17 10:36:22 --> Helper loaded: file_helper
INFO - 2018-11-17 10:36:22 --> Helper loaded: email_helper
INFO - 2018-11-17 10:36:22 --> Helper loaded: common_helper
INFO - 2018-11-17 10:36:22 --> Database Driver Class Initialized
DEBUG - 2018-11-17 10:36:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-17 10:36:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-17 10:36:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-17 10:36:22 --> Pagination Class Initialized
INFO - 2018-11-17 10:36:22 --> Helper loaded: form_helper
INFO - 2018-11-17 10:36:22 --> Form Validation Class Initialized
INFO - 2018-11-17 10:36:22 --> Model Class Initialized
INFO - 2018-11-17 10:36:22 --> Controller Class Initialized
INFO - 2018-11-17 10:36:22 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-17 10:36:22 --> Model Class Initialized
INFO - 2018-11-17 10:36:22 --> Config Class Initialized
INFO - 2018-11-17 10:36:22 --> Hooks Class Initialized
DEBUG - 2018-11-17 10:36:22 --> UTF-8 Support Enabled
INFO - 2018-11-17 10:36:22 --> Utf8 Class Initialized
INFO - 2018-11-17 10:36:22 --> URI Class Initialized
DEBUG - 2018-11-17 10:36:22 --> No URI present. Default controller set.
INFO - 2018-11-17 10:36:22 --> Router Class Initialized
INFO - 2018-11-17 10:36:22 --> Output Class Initialized
INFO - 2018-11-17 10:36:22 --> Security Class Initialized
DEBUG - 2018-11-17 10:36:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-17 10:36:22 --> Input Class Initialized
INFO - 2018-11-17 10:36:22 --> Language Class Initialized
INFO - 2018-11-17 10:36:22 --> Loader Class Initialized
INFO - 2018-11-17 10:36:22 --> Helper loaded: url_helper
INFO - 2018-11-17 10:36:22 --> Helper loaded: file_helper
INFO - 2018-11-17 10:36:22 --> Helper loaded: email_helper
INFO - 2018-11-17 10:36:22 --> Helper loaded: common_helper
INFO - 2018-11-17 10:36:22 --> Database Driver Class Initialized
DEBUG - 2018-11-17 10:36:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-17 10:36:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-17 10:36:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-17 10:36:22 --> Pagination Class Initialized
INFO - 2018-11-17 10:36:22 --> Helper loaded: form_helper
INFO - 2018-11-17 10:36:22 --> Form Validation Class Initialized
INFO - 2018-11-17 10:36:22 --> Model Class Initialized
INFO - 2018-11-17 10:36:22 --> Controller Class Initialized
INFO - 2018-11-17 10:36:22 --> Model Class Initialized
INFO - 2018-11-17 10:36:22 --> Model Class Initialized
INFO - 2018-11-17 10:36:22 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\template/header-menu.php
INFO - 2018-11-17 10:36:22 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\template/header.php
INFO - 2018-11-17 10:36:22 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\template/footer.php
INFO - 2018-11-17 10:36:22 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\index.php
INFO - 2018-11-17 10:36:22 --> Final output sent to browser
DEBUG - 2018-11-17 10:36:22 --> Total execution time: 0.0460
INFO - 2018-11-17 10:37:38 --> Config Class Initialized
INFO - 2018-11-17 10:37:38 --> Hooks Class Initialized
DEBUG - 2018-11-17 10:37:38 --> UTF-8 Support Enabled
INFO - 2018-11-17 10:37:38 --> Utf8 Class Initialized
INFO - 2018-11-17 10:37:38 --> URI Class Initialized
INFO - 2018-11-17 10:37:38 --> Router Class Initialized
INFO - 2018-11-17 10:37:38 --> Output Class Initialized
INFO - 2018-11-17 10:37:38 --> Security Class Initialized
DEBUG - 2018-11-17 10:37:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-17 10:37:38 --> Input Class Initialized
INFO - 2018-11-17 10:37:38 --> Language Class Initialized
INFO - 2018-11-17 10:37:38 --> Loader Class Initialized
INFO - 2018-11-17 10:37:38 --> Helper loaded: url_helper
INFO - 2018-11-17 10:37:38 --> Helper loaded: file_helper
INFO - 2018-11-17 10:37:38 --> Helper loaded: email_helper
INFO - 2018-11-17 10:37:38 --> Helper loaded: common_helper
INFO - 2018-11-17 10:37:38 --> Database Driver Class Initialized
DEBUG - 2018-11-17 10:37:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-17 10:37:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-17 10:37:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-17 10:37:38 --> Pagination Class Initialized
INFO - 2018-11-17 10:37:38 --> Helper loaded: form_helper
INFO - 2018-11-17 10:37:38 --> Form Validation Class Initialized
INFO - 2018-11-17 10:37:38 --> Model Class Initialized
INFO - 2018-11-17 10:37:38 --> Controller Class Initialized
INFO - 2018-11-17 10:37:38 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-17 10:37:38 --> Model Class Initialized
INFO - 2018-11-17 10:37:38 --> Model Class Initialized
INFO - 2018-11-17 10:37:38 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/index.php
INFO - 2018-11-17 10:37:38 --> Final output sent to browser
DEBUG - 2018-11-17 10:37:38 --> Total execution time: 0.0570
INFO - 2018-11-17 10:37:45 --> Config Class Initialized
INFO - 2018-11-17 10:37:45 --> Hooks Class Initialized
DEBUG - 2018-11-17 10:37:45 --> UTF-8 Support Enabled
INFO - 2018-11-17 10:37:45 --> Utf8 Class Initialized
INFO - 2018-11-17 10:37:45 --> URI Class Initialized
INFO - 2018-11-17 10:37:45 --> Router Class Initialized
INFO - 2018-11-17 10:37:45 --> Output Class Initialized
INFO - 2018-11-17 10:37:45 --> Security Class Initialized
DEBUG - 2018-11-17 10:37:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-17 10:37:45 --> Input Class Initialized
INFO - 2018-11-17 10:37:45 --> Language Class Initialized
INFO - 2018-11-17 10:37:45 --> Loader Class Initialized
INFO - 2018-11-17 10:37:45 --> Helper loaded: url_helper
INFO - 2018-11-17 10:37:45 --> Helper loaded: file_helper
INFO - 2018-11-17 10:37:45 --> Helper loaded: email_helper
INFO - 2018-11-17 10:37:45 --> Helper loaded: common_helper
INFO - 2018-11-17 10:37:45 --> Database Driver Class Initialized
DEBUG - 2018-11-17 10:37:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-17 10:37:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-17 10:37:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-17 10:37:45 --> Pagination Class Initialized
INFO - 2018-11-17 10:37:45 --> Helper loaded: form_helper
INFO - 2018-11-17 10:37:45 --> Form Validation Class Initialized
INFO - 2018-11-17 10:37:45 --> Model Class Initialized
INFO - 2018-11-17 10:37:45 --> Controller Class Initialized
INFO - 2018-11-17 10:37:45 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-17 10:37:45 --> Model Class Initialized
INFO - 2018-11-17 10:37:45 --> Model Class Initialized
ERROR - 2018-11-17 10:37:45 --> Severity: Notice --> Undefined index: remember_me C:\xampp\htdocs\wetinuneed\application\controllers\Admin.php 74
INFO - 2018-11-17 10:37:45 --> Config Class Initialized
INFO - 2018-11-17 10:37:45 --> Hooks Class Initialized
DEBUG - 2018-11-17 10:37:45 --> UTF-8 Support Enabled
INFO - 2018-11-17 10:37:45 --> Utf8 Class Initialized
INFO - 2018-11-17 10:37:45 --> URI Class Initialized
INFO - 2018-11-17 10:37:45 --> Router Class Initialized
INFO - 2018-11-17 10:37:45 --> Output Class Initialized
INFO - 2018-11-17 10:37:45 --> Security Class Initialized
DEBUG - 2018-11-17 10:37:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-17 10:37:45 --> Input Class Initialized
INFO - 2018-11-17 10:37:45 --> Language Class Initialized
INFO - 2018-11-17 10:37:45 --> Loader Class Initialized
INFO - 2018-11-17 10:37:45 --> Helper loaded: url_helper
INFO - 2018-11-17 10:37:45 --> Helper loaded: file_helper
INFO - 2018-11-17 10:37:45 --> Helper loaded: email_helper
INFO - 2018-11-17 10:37:45 --> Helper loaded: common_helper
INFO - 2018-11-17 10:37:45 --> Database Driver Class Initialized
DEBUG - 2018-11-17 10:37:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-17 10:37:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-17 10:37:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-17 10:37:45 --> Pagination Class Initialized
INFO - 2018-11-17 10:37:45 --> Helper loaded: form_helper
INFO - 2018-11-17 10:37:45 --> Form Validation Class Initialized
INFO - 2018-11-17 10:37:45 --> Model Class Initialized
INFO - 2018-11-17 10:37:45 --> Controller Class Initialized
INFO - 2018-11-17 10:37:45 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-17 10:37:45 --> Model Class Initialized
INFO - 2018-11-17 10:37:45 --> Config Class Initialized
INFO - 2018-11-17 10:37:45 --> Hooks Class Initialized
DEBUG - 2018-11-17 10:37:45 --> UTF-8 Support Enabled
INFO - 2018-11-17 10:37:45 --> Utf8 Class Initialized
INFO - 2018-11-17 10:37:45 --> URI Class Initialized
DEBUG - 2018-11-17 10:37:45 --> No URI present. Default controller set.
INFO - 2018-11-17 10:37:45 --> Router Class Initialized
INFO - 2018-11-17 10:37:45 --> Output Class Initialized
INFO - 2018-11-17 10:37:45 --> Security Class Initialized
DEBUG - 2018-11-17 10:37:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-17 10:37:45 --> Input Class Initialized
INFO - 2018-11-17 10:37:45 --> Language Class Initialized
INFO - 2018-11-17 10:37:45 --> Loader Class Initialized
INFO - 2018-11-17 10:37:45 --> Helper loaded: url_helper
INFO - 2018-11-17 10:37:45 --> Helper loaded: file_helper
INFO - 2018-11-17 10:37:45 --> Helper loaded: email_helper
INFO - 2018-11-17 10:37:45 --> Helper loaded: common_helper
INFO - 2018-11-17 10:37:45 --> Database Driver Class Initialized
DEBUG - 2018-11-17 10:37:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-17 10:37:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-17 10:37:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-17 10:37:45 --> Pagination Class Initialized
INFO - 2018-11-17 10:37:45 --> Helper loaded: form_helper
INFO - 2018-11-17 10:37:45 --> Form Validation Class Initialized
INFO - 2018-11-17 10:37:45 --> Model Class Initialized
INFO - 2018-11-17 10:37:45 --> Controller Class Initialized
INFO - 2018-11-17 10:37:45 --> Model Class Initialized
INFO - 2018-11-17 10:37:45 --> Model Class Initialized
INFO - 2018-11-17 10:37:45 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\template/header-menu.php
INFO - 2018-11-17 10:37:45 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\template/header.php
INFO - 2018-11-17 10:37:45 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\template/footer.php
INFO - 2018-11-17 10:37:45 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\index.php
INFO - 2018-11-17 10:37:45 --> Final output sent to browser
DEBUG - 2018-11-17 10:37:45 --> Total execution time: 0.0550
INFO - 2018-11-17 10:38:29 --> Config Class Initialized
INFO - 2018-11-17 10:38:29 --> Hooks Class Initialized
DEBUG - 2018-11-17 10:38:29 --> UTF-8 Support Enabled
INFO - 2018-11-17 10:38:29 --> Utf8 Class Initialized
INFO - 2018-11-17 10:38:29 --> URI Class Initialized
INFO - 2018-11-17 10:38:29 --> Router Class Initialized
INFO - 2018-11-17 10:38:29 --> Output Class Initialized
INFO - 2018-11-17 10:38:29 --> Security Class Initialized
DEBUG - 2018-11-17 10:38:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-17 10:38:29 --> Input Class Initialized
INFO - 2018-11-17 10:38:29 --> Language Class Initialized
INFO - 2018-11-17 10:38:29 --> Loader Class Initialized
INFO - 2018-11-17 10:38:29 --> Helper loaded: url_helper
INFO - 2018-11-17 10:38:29 --> Helper loaded: file_helper
INFO - 2018-11-17 10:38:29 --> Helper loaded: email_helper
INFO - 2018-11-17 10:38:29 --> Helper loaded: common_helper
INFO - 2018-11-17 10:38:29 --> Database Driver Class Initialized
DEBUG - 2018-11-17 10:38:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-17 10:38:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-17 10:38:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-17 10:38:29 --> Pagination Class Initialized
INFO - 2018-11-17 10:38:29 --> Helper loaded: form_helper
INFO - 2018-11-17 10:38:29 --> Form Validation Class Initialized
INFO - 2018-11-17 10:38:29 --> Model Class Initialized
INFO - 2018-11-17 10:38:29 --> Controller Class Initialized
INFO - 2018-11-17 10:38:29 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-17 10:38:29 --> Model Class Initialized
INFO - 2018-11-17 10:38:29 --> Model Class Initialized
INFO - 2018-11-17 10:38:29 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/index.php
INFO - 2018-11-17 10:38:29 --> Final output sent to browser
DEBUG - 2018-11-17 10:38:29 --> Total execution time: 0.0590
INFO - 2018-11-17 10:38:34 --> Config Class Initialized
INFO - 2018-11-17 10:38:34 --> Hooks Class Initialized
DEBUG - 2018-11-17 10:38:34 --> UTF-8 Support Enabled
INFO - 2018-11-17 10:38:34 --> Utf8 Class Initialized
INFO - 2018-11-17 10:38:34 --> URI Class Initialized
INFO - 2018-11-17 10:38:34 --> Router Class Initialized
INFO - 2018-11-17 10:38:34 --> Output Class Initialized
INFO - 2018-11-17 10:38:34 --> Security Class Initialized
DEBUG - 2018-11-17 10:38:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-17 10:38:34 --> Input Class Initialized
INFO - 2018-11-17 10:38:34 --> Language Class Initialized
INFO - 2018-11-17 10:38:34 --> Loader Class Initialized
INFO - 2018-11-17 10:38:34 --> Helper loaded: url_helper
INFO - 2018-11-17 10:38:34 --> Helper loaded: file_helper
INFO - 2018-11-17 10:38:34 --> Helper loaded: email_helper
INFO - 2018-11-17 10:38:34 --> Helper loaded: common_helper
INFO - 2018-11-17 10:38:34 --> Database Driver Class Initialized
DEBUG - 2018-11-17 10:38:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-17 10:38:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-17 10:38:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-17 10:38:34 --> Pagination Class Initialized
INFO - 2018-11-17 10:38:34 --> Helper loaded: form_helper
INFO - 2018-11-17 10:38:34 --> Form Validation Class Initialized
INFO - 2018-11-17 10:38:34 --> Model Class Initialized
INFO - 2018-11-17 10:38:34 --> Controller Class Initialized
INFO - 2018-11-17 10:38:34 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-17 10:38:34 --> Model Class Initialized
INFO - 2018-11-17 10:38:34 --> Model Class Initialized
ERROR - 2018-11-17 10:38:34 --> Severity: Notice --> Undefined index: remember_me C:\xampp\htdocs\wetinuneed\application\controllers\Admin.php 74
INFO - 2018-11-17 10:38:34 --> Config Class Initialized
INFO - 2018-11-17 10:38:34 --> Hooks Class Initialized
DEBUG - 2018-11-17 10:38:34 --> UTF-8 Support Enabled
INFO - 2018-11-17 10:38:34 --> Utf8 Class Initialized
INFO - 2018-11-17 10:38:34 --> URI Class Initialized
INFO - 2018-11-17 10:38:34 --> Router Class Initialized
INFO - 2018-11-17 10:38:34 --> Output Class Initialized
INFO - 2018-11-17 10:38:34 --> Security Class Initialized
DEBUG - 2018-11-17 10:38:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-17 10:38:34 --> Input Class Initialized
INFO - 2018-11-17 10:38:34 --> Language Class Initialized
INFO - 2018-11-17 10:38:34 --> Loader Class Initialized
INFO - 2018-11-17 10:38:34 --> Helper loaded: url_helper
INFO - 2018-11-17 10:38:34 --> Helper loaded: file_helper
INFO - 2018-11-17 10:38:34 --> Helper loaded: email_helper
INFO - 2018-11-17 10:38:34 --> Helper loaded: common_helper
INFO - 2018-11-17 10:38:34 --> Database Driver Class Initialized
DEBUG - 2018-11-17 10:38:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-17 10:38:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-17 10:38:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-17 10:38:34 --> Pagination Class Initialized
INFO - 2018-11-17 10:38:34 --> Helper loaded: form_helper
INFO - 2018-11-17 10:38:34 --> Form Validation Class Initialized
INFO - 2018-11-17 10:38:34 --> Model Class Initialized
INFO - 2018-11-17 10:38:34 --> Controller Class Initialized
INFO - 2018-11-17 10:38:34 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-17 10:38:34 --> Model Class Initialized
INFO - 2018-11-17 10:38:34 --> Config Class Initialized
INFO - 2018-11-17 10:38:34 --> Hooks Class Initialized
DEBUG - 2018-11-17 10:38:34 --> UTF-8 Support Enabled
INFO - 2018-11-17 10:38:34 --> Utf8 Class Initialized
INFO - 2018-11-17 10:38:34 --> URI Class Initialized
DEBUG - 2018-11-17 10:38:34 --> No URI present. Default controller set.
INFO - 2018-11-17 10:38:34 --> Router Class Initialized
INFO - 2018-11-17 10:38:34 --> Output Class Initialized
INFO - 2018-11-17 10:38:34 --> Security Class Initialized
DEBUG - 2018-11-17 10:38:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-17 10:38:34 --> Input Class Initialized
INFO - 2018-11-17 10:38:34 --> Language Class Initialized
INFO - 2018-11-17 10:38:34 --> Loader Class Initialized
INFO - 2018-11-17 10:38:34 --> Helper loaded: url_helper
INFO - 2018-11-17 10:38:34 --> Helper loaded: file_helper
INFO - 2018-11-17 10:38:34 --> Helper loaded: email_helper
INFO - 2018-11-17 10:38:34 --> Helper loaded: common_helper
INFO - 2018-11-17 10:38:34 --> Database Driver Class Initialized
DEBUG - 2018-11-17 10:38:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-17 10:38:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-17 10:38:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-17 10:38:34 --> Pagination Class Initialized
INFO - 2018-11-17 10:38:34 --> Helper loaded: form_helper
INFO - 2018-11-17 10:38:34 --> Form Validation Class Initialized
INFO - 2018-11-17 10:38:34 --> Model Class Initialized
INFO - 2018-11-17 10:38:34 --> Controller Class Initialized
INFO - 2018-11-17 10:38:34 --> Model Class Initialized
INFO - 2018-11-17 10:38:34 --> Model Class Initialized
INFO - 2018-11-17 10:38:34 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\template/header-menu.php
INFO - 2018-11-17 10:38:34 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\template/header.php
INFO - 2018-11-17 10:38:34 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\template/footer.php
INFO - 2018-11-17 10:38:34 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\index.php
INFO - 2018-11-17 10:38:34 --> Final output sent to browser
DEBUG - 2018-11-17 10:38:34 --> Total execution time: 0.0540
INFO - 2018-11-17 10:45:58 --> Config Class Initialized
INFO - 2018-11-17 10:45:58 --> Hooks Class Initialized
DEBUG - 2018-11-17 10:45:58 --> UTF-8 Support Enabled
INFO - 2018-11-17 10:45:58 --> Utf8 Class Initialized
INFO - 2018-11-17 10:45:58 --> URI Class Initialized
INFO - 2018-11-17 10:45:58 --> Router Class Initialized
INFO - 2018-11-17 10:45:58 --> Output Class Initialized
INFO - 2018-11-17 10:45:58 --> Security Class Initialized
DEBUG - 2018-11-17 10:45:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-17 10:45:58 --> Input Class Initialized
INFO - 2018-11-17 10:45:58 --> Language Class Initialized
INFO - 2018-11-17 10:45:58 --> Loader Class Initialized
INFO - 2018-11-17 10:45:58 --> Helper loaded: url_helper
INFO - 2018-11-17 10:45:58 --> Helper loaded: file_helper
INFO - 2018-11-17 10:45:58 --> Helper loaded: email_helper
INFO - 2018-11-17 10:45:58 --> Helper loaded: common_helper
INFO - 2018-11-17 10:45:58 --> Database Driver Class Initialized
DEBUG - 2018-11-17 10:45:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-17 10:45:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-17 10:45:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-17 10:45:58 --> Pagination Class Initialized
INFO - 2018-11-17 10:45:58 --> Helper loaded: form_helper
INFO - 2018-11-17 10:45:58 --> Form Validation Class Initialized
INFO - 2018-11-17 10:45:58 --> Model Class Initialized
INFO - 2018-11-17 10:45:58 --> Controller Class Initialized
INFO - 2018-11-17 10:45:58 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-17 10:45:58 --> Model Class Initialized
INFO - 2018-11-17 10:45:58 --> Model Class Initialized
INFO - 2018-11-17 10:45:58 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/index.php
INFO - 2018-11-17 10:45:58 --> Final output sent to browser
DEBUG - 2018-11-17 10:45:58 --> Total execution time: 0.0530
INFO - 2018-11-17 10:46:03 --> Config Class Initialized
INFO - 2018-11-17 10:46:03 --> Hooks Class Initialized
DEBUG - 2018-11-17 10:46:03 --> UTF-8 Support Enabled
INFO - 2018-11-17 10:46:03 --> Utf8 Class Initialized
INFO - 2018-11-17 10:46:03 --> URI Class Initialized
INFO - 2018-11-17 10:46:03 --> Router Class Initialized
INFO - 2018-11-17 10:46:03 --> Output Class Initialized
INFO - 2018-11-17 10:46:03 --> Security Class Initialized
DEBUG - 2018-11-17 10:46:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-17 10:46:03 --> Input Class Initialized
INFO - 2018-11-17 10:46:03 --> Language Class Initialized
INFO - 2018-11-17 10:46:03 --> Loader Class Initialized
INFO - 2018-11-17 10:46:03 --> Helper loaded: url_helper
INFO - 2018-11-17 10:46:03 --> Helper loaded: file_helper
INFO - 2018-11-17 10:46:03 --> Helper loaded: email_helper
INFO - 2018-11-17 10:46:03 --> Helper loaded: common_helper
INFO - 2018-11-17 10:46:03 --> Database Driver Class Initialized
DEBUG - 2018-11-17 10:46:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-17 10:46:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-17 10:46:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-17 10:46:03 --> Pagination Class Initialized
INFO - 2018-11-17 10:46:03 --> Helper loaded: form_helper
INFO - 2018-11-17 10:46:03 --> Form Validation Class Initialized
INFO - 2018-11-17 10:46:03 --> Model Class Initialized
INFO - 2018-11-17 10:46:03 --> Controller Class Initialized
INFO - 2018-11-17 10:46:03 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-17 10:46:03 --> Model Class Initialized
INFO - 2018-11-17 10:46:03 --> Model Class Initialized
ERROR - 2018-11-17 10:46:03 --> Severity: Notice --> Undefined index: remember_me C:\xampp\htdocs\wetinuneed\application\controllers\Admin.php 74
INFO - 2018-11-17 10:46:03 --> Config Class Initialized
INFO - 2018-11-17 10:46:03 --> Hooks Class Initialized
DEBUG - 2018-11-17 10:46:03 --> UTF-8 Support Enabled
INFO - 2018-11-17 10:46:03 --> Utf8 Class Initialized
INFO - 2018-11-17 10:46:03 --> URI Class Initialized
INFO - 2018-11-17 10:46:03 --> Router Class Initialized
INFO - 2018-11-17 10:46:03 --> Output Class Initialized
INFO - 2018-11-17 10:46:03 --> Security Class Initialized
DEBUG - 2018-11-17 10:46:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-17 10:46:03 --> Input Class Initialized
INFO - 2018-11-17 10:46:03 --> Language Class Initialized
INFO - 2018-11-17 10:46:03 --> Loader Class Initialized
INFO - 2018-11-17 10:46:03 --> Helper loaded: url_helper
INFO - 2018-11-17 10:46:03 --> Helper loaded: file_helper
INFO - 2018-11-17 10:46:03 --> Helper loaded: email_helper
INFO - 2018-11-17 10:46:03 --> Helper loaded: common_helper
INFO - 2018-11-17 10:46:03 --> Database Driver Class Initialized
DEBUG - 2018-11-17 10:46:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-17 10:46:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-17 10:46:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-17 10:46:03 --> Pagination Class Initialized
INFO - 2018-11-17 10:46:03 --> Helper loaded: form_helper
INFO - 2018-11-17 10:46:03 --> Form Validation Class Initialized
INFO - 2018-11-17 10:46:03 --> Model Class Initialized
INFO - 2018-11-17 10:46:03 --> Controller Class Initialized
INFO - 2018-11-17 10:46:03 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-17 10:46:03 --> Model Class Initialized
INFO - 2018-11-17 10:46:03 --> Config Class Initialized
INFO - 2018-11-17 10:46:03 --> Hooks Class Initialized
DEBUG - 2018-11-17 10:46:03 --> UTF-8 Support Enabled
INFO - 2018-11-17 10:46:03 --> Utf8 Class Initialized
INFO - 2018-11-17 10:46:03 --> URI Class Initialized
DEBUG - 2018-11-17 10:46:03 --> No URI present. Default controller set.
INFO - 2018-11-17 10:46:03 --> Router Class Initialized
INFO - 2018-11-17 10:46:03 --> Output Class Initialized
INFO - 2018-11-17 10:46:03 --> Security Class Initialized
DEBUG - 2018-11-17 10:46:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-17 10:46:03 --> Input Class Initialized
INFO - 2018-11-17 10:46:03 --> Language Class Initialized
INFO - 2018-11-17 10:46:03 --> Loader Class Initialized
INFO - 2018-11-17 10:46:03 --> Helper loaded: url_helper
INFO - 2018-11-17 10:46:03 --> Helper loaded: file_helper
INFO - 2018-11-17 10:46:03 --> Helper loaded: email_helper
INFO - 2018-11-17 10:46:03 --> Helper loaded: common_helper
INFO - 2018-11-17 10:46:03 --> Database Driver Class Initialized
DEBUG - 2018-11-17 10:46:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-17 10:46:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-17 10:46:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-17 10:46:03 --> Pagination Class Initialized
INFO - 2018-11-17 10:46:03 --> Helper loaded: form_helper
INFO - 2018-11-17 10:46:03 --> Form Validation Class Initialized
INFO - 2018-11-17 10:46:03 --> Model Class Initialized
INFO - 2018-11-17 10:46:03 --> Controller Class Initialized
INFO - 2018-11-17 10:46:03 --> Model Class Initialized
INFO - 2018-11-17 10:46:03 --> Model Class Initialized
INFO - 2018-11-17 10:46:03 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\template/header-menu.php
INFO - 2018-11-17 10:46:03 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\template/header.php
INFO - 2018-11-17 10:46:03 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\template/footer.php
INFO - 2018-11-17 10:46:03 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\index.php
INFO - 2018-11-17 10:46:03 --> Final output sent to browser
DEBUG - 2018-11-17 10:46:03 --> Total execution time: 0.0530
INFO - 2018-11-17 10:47:08 --> Config Class Initialized
INFO - 2018-11-17 10:47:08 --> Hooks Class Initialized
DEBUG - 2018-11-17 10:47:08 --> UTF-8 Support Enabled
INFO - 2018-11-17 10:47:08 --> Utf8 Class Initialized
INFO - 2018-11-17 10:47:08 --> URI Class Initialized
INFO - 2018-11-17 10:47:08 --> Router Class Initialized
INFO - 2018-11-17 10:47:08 --> Output Class Initialized
INFO - 2018-11-17 10:47:08 --> Security Class Initialized
DEBUG - 2018-11-17 10:47:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-17 10:47:08 --> Input Class Initialized
INFO - 2018-11-17 10:47:08 --> Language Class Initialized
INFO - 2018-11-17 10:47:08 --> Loader Class Initialized
INFO - 2018-11-17 10:47:08 --> Helper loaded: url_helper
INFO - 2018-11-17 10:47:08 --> Helper loaded: file_helper
INFO - 2018-11-17 10:47:08 --> Helper loaded: email_helper
INFO - 2018-11-17 10:47:08 --> Helper loaded: common_helper
INFO - 2018-11-17 10:47:09 --> Database Driver Class Initialized
DEBUG - 2018-11-17 10:47:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-17 10:47:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-17 10:47:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-17 10:47:09 --> Pagination Class Initialized
INFO - 2018-11-17 10:47:09 --> Helper loaded: form_helper
INFO - 2018-11-17 10:47:09 --> Form Validation Class Initialized
INFO - 2018-11-17 10:47:09 --> Model Class Initialized
INFO - 2018-11-17 10:47:09 --> Controller Class Initialized
INFO - 2018-11-17 10:47:09 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-17 10:47:09 --> Model Class Initialized
INFO - 2018-11-17 10:47:09 --> Model Class Initialized
INFO - 2018-11-17 10:47:09 --> Config Class Initialized
INFO - 2018-11-17 10:47:09 --> Hooks Class Initialized
DEBUG - 2018-11-17 10:47:09 --> UTF-8 Support Enabled
INFO - 2018-11-17 10:47:09 --> Utf8 Class Initialized
INFO - 2018-11-17 10:47:09 --> URI Class Initialized
INFO - 2018-11-17 10:47:09 --> Router Class Initialized
INFO - 2018-11-17 10:47:09 --> Output Class Initialized
INFO - 2018-11-17 10:47:09 --> Security Class Initialized
DEBUG - 2018-11-17 10:47:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-17 10:47:09 --> Input Class Initialized
INFO - 2018-11-17 10:47:09 --> Language Class Initialized
INFO - 2018-11-17 10:47:09 --> Loader Class Initialized
INFO - 2018-11-17 10:47:09 --> Helper loaded: url_helper
INFO - 2018-11-17 10:47:09 --> Helper loaded: file_helper
INFO - 2018-11-17 10:47:09 --> Helper loaded: email_helper
INFO - 2018-11-17 10:47:09 --> Helper loaded: common_helper
INFO - 2018-11-17 10:47:09 --> Database Driver Class Initialized
DEBUG - 2018-11-17 10:47:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-17 10:47:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-17 10:47:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-17 10:47:09 --> Pagination Class Initialized
INFO - 2018-11-17 10:47:09 --> Helper loaded: form_helper
INFO - 2018-11-17 10:47:09 --> Form Validation Class Initialized
INFO - 2018-11-17 10:47:09 --> Model Class Initialized
INFO - 2018-11-17 10:47:09 --> Controller Class Initialized
INFO - 2018-11-17 10:47:09 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-17 10:47:09 --> Model Class Initialized
INFO - 2018-11-17 10:47:09 --> Config Class Initialized
INFO - 2018-11-17 10:47:09 --> Hooks Class Initialized
DEBUG - 2018-11-17 10:47:09 --> UTF-8 Support Enabled
INFO - 2018-11-17 10:47:09 --> Utf8 Class Initialized
INFO - 2018-11-17 10:47:09 --> URI Class Initialized
DEBUG - 2018-11-17 10:47:09 --> No URI present. Default controller set.
INFO - 2018-11-17 10:47:09 --> Router Class Initialized
INFO - 2018-11-17 10:47:09 --> Output Class Initialized
INFO - 2018-11-17 10:47:09 --> Security Class Initialized
DEBUG - 2018-11-17 10:47:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-17 10:47:09 --> Input Class Initialized
INFO - 2018-11-17 10:47:09 --> Language Class Initialized
INFO - 2018-11-17 10:47:09 --> Loader Class Initialized
INFO - 2018-11-17 10:47:09 --> Helper loaded: url_helper
INFO - 2018-11-17 10:47:09 --> Helper loaded: file_helper
INFO - 2018-11-17 10:47:09 --> Helper loaded: email_helper
INFO - 2018-11-17 10:47:09 --> Helper loaded: common_helper
INFO - 2018-11-17 10:47:09 --> Database Driver Class Initialized
DEBUG - 2018-11-17 10:47:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-17 10:47:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-17 10:47:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-17 10:47:09 --> Pagination Class Initialized
INFO - 2018-11-17 10:47:09 --> Helper loaded: form_helper
INFO - 2018-11-17 10:47:09 --> Form Validation Class Initialized
INFO - 2018-11-17 10:47:09 --> Model Class Initialized
INFO - 2018-11-17 10:47:09 --> Controller Class Initialized
INFO - 2018-11-17 10:47:09 --> Model Class Initialized
INFO - 2018-11-17 10:47:09 --> Model Class Initialized
INFO - 2018-11-17 10:47:09 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\template/header-menu.php
INFO - 2018-11-17 10:47:09 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\template/header.php
INFO - 2018-11-17 10:47:09 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\template/footer.php
INFO - 2018-11-17 10:47:09 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\index.php
INFO - 2018-11-17 10:47:09 --> Final output sent to browser
DEBUG - 2018-11-17 10:47:09 --> Total execution time: 0.0570
INFO - 2018-11-17 10:47:17 --> Config Class Initialized
INFO - 2018-11-17 10:47:17 --> Hooks Class Initialized
DEBUG - 2018-11-17 10:47:17 --> UTF-8 Support Enabled
INFO - 2018-11-17 10:47:17 --> Utf8 Class Initialized
INFO - 2018-11-17 10:47:17 --> URI Class Initialized
INFO - 2018-11-17 10:47:17 --> Router Class Initialized
INFO - 2018-11-17 10:47:17 --> Output Class Initialized
INFO - 2018-11-17 10:47:17 --> Security Class Initialized
DEBUG - 2018-11-17 10:47:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-17 10:47:17 --> Input Class Initialized
INFO - 2018-11-17 10:47:17 --> Language Class Initialized
INFO - 2018-11-17 10:47:17 --> Loader Class Initialized
INFO - 2018-11-17 10:47:17 --> Helper loaded: url_helper
INFO - 2018-11-17 10:47:17 --> Helper loaded: file_helper
INFO - 2018-11-17 10:47:17 --> Helper loaded: email_helper
INFO - 2018-11-17 10:47:17 --> Helper loaded: common_helper
INFO - 2018-11-17 10:47:17 --> Database Driver Class Initialized
DEBUG - 2018-11-17 10:47:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-17 10:47:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-17 10:47:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-17 10:47:17 --> Pagination Class Initialized
INFO - 2018-11-17 10:47:17 --> Helper loaded: form_helper
INFO - 2018-11-17 10:47:17 --> Form Validation Class Initialized
INFO - 2018-11-17 10:47:17 --> Model Class Initialized
INFO - 2018-11-17 10:47:17 --> Controller Class Initialized
INFO - 2018-11-17 10:47:17 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-17 10:47:17 --> Model Class Initialized
INFO - 2018-11-17 10:47:17 --> Model Class Initialized
INFO - 2018-11-17 10:47:17 --> Config Class Initialized
INFO - 2018-11-17 10:47:17 --> Hooks Class Initialized
DEBUG - 2018-11-17 10:47:17 --> UTF-8 Support Enabled
INFO - 2018-11-17 10:47:17 --> Utf8 Class Initialized
INFO - 2018-11-17 10:47:17 --> URI Class Initialized
INFO - 2018-11-17 10:47:17 --> Router Class Initialized
INFO - 2018-11-17 10:47:17 --> Output Class Initialized
INFO - 2018-11-17 10:47:17 --> Security Class Initialized
DEBUG - 2018-11-17 10:47:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-17 10:47:17 --> Input Class Initialized
INFO - 2018-11-17 10:47:17 --> Language Class Initialized
INFO - 2018-11-17 10:47:17 --> Loader Class Initialized
INFO - 2018-11-17 10:47:17 --> Helper loaded: url_helper
INFO - 2018-11-17 10:47:17 --> Helper loaded: file_helper
INFO - 2018-11-17 10:47:17 --> Helper loaded: email_helper
INFO - 2018-11-17 10:47:17 --> Helper loaded: common_helper
INFO - 2018-11-17 10:47:17 --> Database Driver Class Initialized
DEBUG - 2018-11-17 10:47:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-17 10:47:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-17 10:47:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-17 10:47:17 --> Pagination Class Initialized
INFO - 2018-11-17 10:47:17 --> Helper loaded: form_helper
INFO - 2018-11-17 10:47:17 --> Form Validation Class Initialized
INFO - 2018-11-17 10:47:17 --> Model Class Initialized
INFO - 2018-11-17 10:47:17 --> Controller Class Initialized
INFO - 2018-11-17 10:47:17 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-17 10:47:17 --> Model Class Initialized
INFO - 2018-11-17 10:47:17 --> Config Class Initialized
INFO - 2018-11-17 10:47:17 --> Hooks Class Initialized
DEBUG - 2018-11-17 10:47:17 --> UTF-8 Support Enabled
INFO - 2018-11-17 10:47:17 --> Utf8 Class Initialized
INFO - 2018-11-17 10:47:17 --> URI Class Initialized
DEBUG - 2018-11-17 10:47:17 --> No URI present. Default controller set.
INFO - 2018-11-17 10:47:17 --> Router Class Initialized
INFO - 2018-11-17 10:47:17 --> Output Class Initialized
INFO - 2018-11-17 10:47:17 --> Security Class Initialized
DEBUG - 2018-11-17 10:47:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-17 10:47:17 --> Input Class Initialized
INFO - 2018-11-17 10:47:17 --> Language Class Initialized
INFO - 2018-11-17 10:47:17 --> Loader Class Initialized
INFO - 2018-11-17 10:47:17 --> Helper loaded: url_helper
INFO - 2018-11-17 10:47:17 --> Helper loaded: file_helper
INFO - 2018-11-17 10:47:17 --> Helper loaded: email_helper
INFO - 2018-11-17 10:47:17 --> Helper loaded: common_helper
INFO - 2018-11-17 10:47:17 --> Database Driver Class Initialized
DEBUG - 2018-11-17 10:47:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-17 10:47:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-17 10:47:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-17 10:47:17 --> Pagination Class Initialized
INFO - 2018-11-17 10:47:17 --> Helper loaded: form_helper
INFO - 2018-11-17 10:47:17 --> Form Validation Class Initialized
INFO - 2018-11-17 10:47:17 --> Model Class Initialized
INFO - 2018-11-17 10:47:17 --> Controller Class Initialized
INFO - 2018-11-17 10:47:17 --> Model Class Initialized
INFO - 2018-11-17 10:47:17 --> Model Class Initialized
INFO - 2018-11-17 10:47:17 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\template/header-menu.php
INFO - 2018-11-17 10:47:17 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\template/header.php
INFO - 2018-11-17 10:47:17 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\template/footer.php
INFO - 2018-11-17 10:47:17 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\index.php
INFO - 2018-11-17 10:47:17 --> Final output sent to browser
DEBUG - 2018-11-17 10:47:17 --> Total execution time: 0.0530
INFO - 2018-11-17 10:47:24 --> Config Class Initialized
INFO - 2018-11-17 10:47:24 --> Hooks Class Initialized
DEBUG - 2018-11-17 10:47:24 --> UTF-8 Support Enabled
INFO - 2018-11-17 10:47:24 --> Utf8 Class Initialized
INFO - 2018-11-17 10:47:24 --> URI Class Initialized
INFO - 2018-11-17 10:47:24 --> Router Class Initialized
INFO - 2018-11-17 10:47:24 --> Output Class Initialized
INFO - 2018-11-17 10:47:24 --> Security Class Initialized
DEBUG - 2018-11-17 10:47:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-17 10:47:24 --> Input Class Initialized
INFO - 2018-11-17 10:47:24 --> Language Class Initialized
INFO - 2018-11-17 10:47:24 --> Loader Class Initialized
INFO - 2018-11-17 10:47:24 --> Helper loaded: url_helper
INFO - 2018-11-17 10:47:24 --> Helper loaded: file_helper
INFO - 2018-11-17 10:47:24 --> Helper loaded: email_helper
INFO - 2018-11-17 10:47:24 --> Helper loaded: common_helper
INFO - 2018-11-17 10:47:24 --> Database Driver Class Initialized
DEBUG - 2018-11-17 10:47:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-17 10:47:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-17 10:47:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-17 10:47:24 --> Pagination Class Initialized
INFO - 2018-11-17 10:47:24 --> Helper loaded: form_helper
INFO - 2018-11-17 10:47:24 --> Form Validation Class Initialized
INFO - 2018-11-17 10:47:24 --> Model Class Initialized
INFO - 2018-11-17 10:47:24 --> Controller Class Initialized
INFO - 2018-11-17 10:47:24 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-17 10:47:24 --> Model Class Initialized
INFO - 2018-11-17 10:47:24 --> Model Class Initialized
INFO - 2018-11-17 10:47:24 --> Config Class Initialized
INFO - 2018-11-17 10:47:24 --> Hooks Class Initialized
DEBUG - 2018-11-17 10:47:24 --> UTF-8 Support Enabled
INFO - 2018-11-17 10:47:24 --> Utf8 Class Initialized
INFO - 2018-11-17 10:47:24 --> URI Class Initialized
INFO - 2018-11-17 10:47:24 --> Router Class Initialized
INFO - 2018-11-17 10:47:24 --> Output Class Initialized
INFO - 2018-11-17 10:47:24 --> Security Class Initialized
DEBUG - 2018-11-17 10:47:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-17 10:47:24 --> Input Class Initialized
INFO - 2018-11-17 10:47:24 --> Language Class Initialized
INFO - 2018-11-17 10:47:24 --> Loader Class Initialized
INFO - 2018-11-17 10:47:24 --> Helper loaded: url_helper
INFO - 2018-11-17 10:47:24 --> Helper loaded: file_helper
INFO - 2018-11-17 10:47:24 --> Helper loaded: email_helper
INFO - 2018-11-17 10:47:24 --> Helper loaded: common_helper
INFO - 2018-11-17 10:47:24 --> Database Driver Class Initialized
DEBUG - 2018-11-17 10:47:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-17 10:47:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-17 10:47:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-17 10:47:24 --> Pagination Class Initialized
INFO - 2018-11-17 10:47:24 --> Helper loaded: form_helper
INFO - 2018-11-17 10:47:24 --> Form Validation Class Initialized
INFO - 2018-11-17 10:47:24 --> Model Class Initialized
INFO - 2018-11-17 10:47:24 --> Controller Class Initialized
INFO - 2018-11-17 10:47:24 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-17 10:47:24 --> Model Class Initialized
INFO - 2018-11-17 10:47:24 --> Config Class Initialized
INFO - 2018-11-17 10:47:24 --> Hooks Class Initialized
DEBUG - 2018-11-17 10:47:24 --> UTF-8 Support Enabled
INFO - 2018-11-17 10:47:24 --> Utf8 Class Initialized
INFO - 2018-11-17 10:47:24 --> URI Class Initialized
DEBUG - 2018-11-17 10:47:24 --> No URI present. Default controller set.
INFO - 2018-11-17 10:47:24 --> Router Class Initialized
INFO - 2018-11-17 10:47:24 --> Output Class Initialized
INFO - 2018-11-17 10:47:24 --> Security Class Initialized
DEBUG - 2018-11-17 10:47:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-17 10:47:24 --> Input Class Initialized
INFO - 2018-11-17 10:47:24 --> Language Class Initialized
INFO - 2018-11-17 10:47:24 --> Loader Class Initialized
INFO - 2018-11-17 10:47:24 --> Helper loaded: url_helper
INFO - 2018-11-17 10:47:24 --> Helper loaded: file_helper
INFO - 2018-11-17 10:47:24 --> Helper loaded: email_helper
INFO - 2018-11-17 10:47:24 --> Helper loaded: common_helper
INFO - 2018-11-17 10:47:24 --> Database Driver Class Initialized
DEBUG - 2018-11-17 10:47:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-17 10:47:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-17 10:47:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-17 10:47:24 --> Pagination Class Initialized
INFO - 2018-11-17 10:47:24 --> Helper loaded: form_helper
INFO - 2018-11-17 10:47:24 --> Form Validation Class Initialized
INFO - 2018-11-17 10:47:24 --> Model Class Initialized
INFO - 2018-11-17 10:47:24 --> Controller Class Initialized
INFO - 2018-11-17 10:47:24 --> Model Class Initialized
INFO - 2018-11-17 10:47:24 --> Model Class Initialized
INFO - 2018-11-17 10:47:24 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\template/header-menu.php
INFO - 2018-11-17 10:47:24 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\template/header.php
INFO - 2018-11-17 10:47:24 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\template/footer.php
INFO - 2018-11-17 10:47:24 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\index.php
INFO - 2018-11-17 10:47:24 --> Final output sent to browser
DEBUG - 2018-11-17 10:47:24 --> Total execution time: 0.0520
INFO - 2018-11-17 10:48:14 --> Config Class Initialized
INFO - 2018-11-17 10:48:14 --> Hooks Class Initialized
DEBUG - 2018-11-17 10:48:14 --> UTF-8 Support Enabled
INFO - 2018-11-17 10:48:14 --> Utf8 Class Initialized
INFO - 2018-11-17 10:48:14 --> URI Class Initialized
DEBUG - 2018-11-17 10:48:14 --> No URI present. Default controller set.
INFO - 2018-11-17 10:48:14 --> Router Class Initialized
INFO - 2018-11-17 10:48:14 --> Output Class Initialized
INFO - 2018-11-17 10:48:14 --> Security Class Initialized
DEBUG - 2018-11-17 10:48:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-17 10:48:14 --> Input Class Initialized
INFO - 2018-11-17 10:48:14 --> Language Class Initialized
INFO - 2018-11-17 10:48:14 --> Loader Class Initialized
INFO - 2018-11-17 10:48:14 --> Helper loaded: url_helper
INFO - 2018-11-17 10:48:14 --> Helper loaded: file_helper
INFO - 2018-11-17 10:48:14 --> Helper loaded: email_helper
INFO - 2018-11-17 10:48:14 --> Helper loaded: common_helper
INFO - 2018-11-17 10:48:14 --> Database Driver Class Initialized
DEBUG - 2018-11-17 10:48:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-17 10:48:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-17 10:48:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-17 10:48:14 --> Pagination Class Initialized
INFO - 2018-11-17 10:48:14 --> Helper loaded: form_helper
INFO - 2018-11-17 10:48:14 --> Form Validation Class Initialized
INFO - 2018-11-17 10:48:14 --> Model Class Initialized
INFO - 2018-11-17 10:48:14 --> Controller Class Initialized
INFO - 2018-11-17 10:48:14 --> Model Class Initialized
INFO - 2018-11-17 10:48:14 --> Model Class Initialized
INFO - 2018-11-17 10:48:14 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\template/header-menu.php
INFO - 2018-11-17 10:48:14 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\template/header.php
INFO - 2018-11-17 10:48:14 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\template/footer.php
INFO - 2018-11-17 10:48:14 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\index.php
INFO - 2018-11-17 10:48:14 --> Final output sent to browser
DEBUG - 2018-11-17 10:48:14 --> Total execution time: 0.0540
INFO - 2018-11-17 10:48:18 --> Config Class Initialized
INFO - 2018-11-17 10:48:18 --> Hooks Class Initialized
DEBUG - 2018-11-17 10:48:18 --> UTF-8 Support Enabled
INFO - 2018-11-17 10:48:18 --> Utf8 Class Initialized
INFO - 2018-11-17 10:48:18 --> URI Class Initialized
INFO - 2018-11-17 10:48:18 --> Router Class Initialized
INFO - 2018-11-17 10:48:18 --> Output Class Initialized
INFO - 2018-11-17 10:48:18 --> Security Class Initialized
DEBUG - 2018-11-17 10:48:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-17 10:48:18 --> Input Class Initialized
INFO - 2018-11-17 10:48:18 --> Language Class Initialized
INFO - 2018-11-17 10:48:18 --> Loader Class Initialized
INFO - 2018-11-17 10:48:18 --> Helper loaded: url_helper
INFO - 2018-11-17 10:48:18 --> Helper loaded: file_helper
INFO - 2018-11-17 10:48:18 --> Helper loaded: email_helper
INFO - 2018-11-17 10:48:18 --> Helper loaded: common_helper
INFO - 2018-11-17 10:48:18 --> Database Driver Class Initialized
DEBUG - 2018-11-17 10:48:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-17 10:48:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-17 10:48:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-17 10:48:18 --> Pagination Class Initialized
INFO - 2018-11-17 10:48:18 --> Helper loaded: form_helper
INFO - 2018-11-17 10:48:18 --> Form Validation Class Initialized
INFO - 2018-11-17 10:48:18 --> Model Class Initialized
INFO - 2018-11-17 10:48:18 --> Controller Class Initialized
INFO - 2018-11-17 10:48:18 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-17 10:48:18 --> Model Class Initialized
INFO - 2018-11-17 10:48:18 --> Model Class Initialized
INFO - 2018-11-17 10:48:18 --> Config Class Initialized
INFO - 2018-11-17 10:48:18 --> Hooks Class Initialized
DEBUG - 2018-11-17 10:48:18 --> UTF-8 Support Enabled
INFO - 2018-11-17 10:48:18 --> Utf8 Class Initialized
INFO - 2018-11-17 10:48:18 --> URI Class Initialized
INFO - 2018-11-17 10:48:18 --> Router Class Initialized
INFO - 2018-11-17 10:48:18 --> Output Class Initialized
INFO - 2018-11-17 10:48:18 --> Security Class Initialized
DEBUG - 2018-11-17 10:48:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-17 10:48:18 --> Input Class Initialized
INFO - 2018-11-17 10:48:18 --> Language Class Initialized
INFO - 2018-11-17 10:48:18 --> Loader Class Initialized
INFO - 2018-11-17 10:48:18 --> Helper loaded: url_helper
INFO - 2018-11-17 10:48:18 --> Helper loaded: file_helper
INFO - 2018-11-17 10:48:18 --> Helper loaded: email_helper
INFO - 2018-11-17 10:48:18 --> Helper loaded: common_helper
INFO - 2018-11-17 10:48:18 --> Database Driver Class Initialized
DEBUG - 2018-11-17 10:48:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-17 10:48:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-17 10:48:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-17 10:48:18 --> Pagination Class Initialized
INFO - 2018-11-17 10:48:18 --> Helper loaded: form_helper
INFO - 2018-11-17 10:48:18 --> Form Validation Class Initialized
INFO - 2018-11-17 10:48:18 --> Model Class Initialized
INFO - 2018-11-17 10:48:18 --> Controller Class Initialized
INFO - 2018-11-17 10:48:18 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-17 10:48:18 --> Model Class Initialized
ERROR - 2018-11-17 10:48:18 --> Severity: Parsing Error --> syntax error, unexpected '?>' C:\xampp\htdocs\wetinuneed\application\views\admin\dashboard.php 25
INFO - 2018-11-17 10:48:41 --> Config Class Initialized
INFO - 2018-11-17 10:48:41 --> Hooks Class Initialized
DEBUG - 2018-11-17 10:48:41 --> UTF-8 Support Enabled
INFO - 2018-11-17 10:48:41 --> Utf8 Class Initialized
INFO - 2018-11-17 10:48:41 --> URI Class Initialized
INFO - 2018-11-17 10:48:41 --> Router Class Initialized
INFO - 2018-11-17 10:48:41 --> Output Class Initialized
INFO - 2018-11-17 10:48:41 --> Security Class Initialized
DEBUG - 2018-11-17 10:48:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-17 10:48:41 --> Input Class Initialized
INFO - 2018-11-17 10:48:41 --> Language Class Initialized
INFO - 2018-11-17 10:48:41 --> Loader Class Initialized
INFO - 2018-11-17 10:48:41 --> Helper loaded: url_helper
INFO - 2018-11-17 10:48:41 --> Helper loaded: file_helper
INFO - 2018-11-17 10:48:41 --> Helper loaded: email_helper
INFO - 2018-11-17 10:48:41 --> Helper loaded: common_helper
INFO - 2018-11-17 10:48:41 --> Database Driver Class Initialized
DEBUG - 2018-11-17 10:48:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-17 10:48:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-17 10:48:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-17 10:48:41 --> Pagination Class Initialized
INFO - 2018-11-17 10:48:41 --> Helper loaded: form_helper
INFO - 2018-11-17 10:48:41 --> Form Validation Class Initialized
INFO - 2018-11-17 10:48:41 --> Model Class Initialized
INFO - 2018-11-17 10:48:41 --> Controller Class Initialized
INFO - 2018-11-17 10:48:41 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-17 10:48:41 --> Model Class Initialized
ERROR - 2018-11-17 10:48:41 --> Severity: Warning --> include(C:\xampp\htdocs\wetinuneed\application\views/admin/lte/header): failed to open stream: No such file or directory C:\xampp\htdocs\wetinuneed\application\views\admin\dashboard.php 2
ERROR - 2018-11-17 10:48:41 --> Severity: Warning --> include(): Failed opening 'C:\xampp\htdocs\wetinuneed\application\views/admin/lte/header' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\wetinuneed\application\views\admin\dashboard.php 2
ERROR - 2018-11-17 10:48:41 --> Severity: Warning --> include(C:\xampp\htdocs\wetinuneed\application\views/admin/lte/bread_crumb): failed to open stream: No such file or directory C:\xampp\htdocs\wetinuneed\application\views\admin\dashboard.php 9
ERROR - 2018-11-17 10:48:41 --> Severity: Warning --> include(): Failed opening 'C:\xampp\htdocs\wetinuneed\application\views/admin/lte/bread_crumb' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\wetinuneed\application\views\admin\dashboard.php 9
ERROR - 2018-11-17 10:48:41 --> Severity: Warning --> include(C:\xampp\htdocs\wetinuneed\application\views/admin/lte/footer): failed to open stream: No such file or directory C:\xampp\htdocs\wetinuneed\application\views\admin\dashboard.php 46
ERROR - 2018-11-17 10:48:41 --> Severity: Warning --> include(): Failed opening 'C:\xampp\htdocs\wetinuneed\application\views/admin/lte/footer' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\wetinuneed\application\views\admin\dashboard.php 46
INFO - 2018-11-17 10:48:41 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/dashboard.php
INFO - 2018-11-17 10:48:41 --> Final output sent to browser
DEBUG - 2018-11-17 10:48:41 --> Total execution time: 0.0836
INFO - 2018-11-17 10:52:49 --> Config Class Initialized
INFO - 2018-11-17 10:52:49 --> Hooks Class Initialized
DEBUG - 2018-11-17 10:52:49 --> UTF-8 Support Enabled
INFO - 2018-11-17 10:52:49 --> Utf8 Class Initialized
INFO - 2018-11-17 10:52:49 --> URI Class Initialized
INFO - 2018-11-17 10:52:49 --> Router Class Initialized
INFO - 2018-11-17 10:52:49 --> Output Class Initialized
INFO - 2018-11-17 10:52:49 --> Security Class Initialized
DEBUG - 2018-11-17 10:52:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-17 10:52:49 --> Input Class Initialized
INFO - 2018-11-17 10:52:49 --> Language Class Initialized
INFO - 2018-11-17 10:52:49 --> Loader Class Initialized
INFO - 2018-11-17 10:52:49 --> Helper loaded: url_helper
INFO - 2018-11-17 10:52:49 --> Helper loaded: file_helper
INFO - 2018-11-17 10:52:49 --> Helper loaded: email_helper
INFO - 2018-11-17 10:52:49 --> Helper loaded: common_helper
INFO - 2018-11-17 10:52:49 --> Database Driver Class Initialized
DEBUG - 2018-11-17 10:52:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-17 10:52:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-17 10:52:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-17 10:52:49 --> Pagination Class Initialized
INFO - 2018-11-17 10:52:49 --> Helper loaded: form_helper
INFO - 2018-11-17 10:52:49 --> Form Validation Class Initialized
INFO - 2018-11-17 10:52:49 --> Model Class Initialized
INFO - 2018-11-17 10:52:49 --> Controller Class Initialized
INFO - 2018-11-17 10:52:49 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-17 10:52:49 --> Model Class Initialized
ERROR - 2018-11-17 10:52:49 --> Severity: Notice --> Undefined property: CI_Loader::$user_session C:\xampp\htdocs\wetinuneed\application\views\admin\lte\header.php 51
ERROR - 2018-11-17 10:52:49 --> Severity: Notice --> Undefined property: CI_Loader::$user_session C:\xampp\htdocs\wetinuneed\application\views\admin\lte\header.php 58
ERROR - 2018-11-17 10:52:49 --> Severity: Notice --> Undefined property: CI_Loader::$user_session C:\xampp\htdocs\wetinuneed\application\views\admin\lte\header.php 59
INFO - 2018-11-17 10:54:19 --> Config Class Initialized
INFO - 2018-11-17 10:54:19 --> Hooks Class Initialized
DEBUG - 2018-11-17 10:54:19 --> UTF-8 Support Enabled
INFO - 2018-11-17 10:54:19 --> Utf8 Class Initialized
INFO - 2018-11-17 10:54:19 --> URI Class Initialized
INFO - 2018-11-17 10:54:19 --> Router Class Initialized
INFO - 2018-11-17 10:54:19 --> Output Class Initialized
INFO - 2018-11-17 10:54:19 --> Security Class Initialized
DEBUG - 2018-11-17 10:54:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-17 10:54:19 --> Input Class Initialized
INFO - 2018-11-17 10:54:19 --> Language Class Initialized
INFO - 2018-11-17 10:54:19 --> Loader Class Initialized
INFO - 2018-11-17 10:54:19 --> Helper loaded: url_helper
INFO - 2018-11-17 10:54:19 --> Helper loaded: file_helper
INFO - 2018-11-17 10:54:19 --> Helper loaded: email_helper
INFO - 2018-11-17 10:54:19 --> Helper loaded: common_helper
INFO - 2018-11-17 10:54:19 --> Database Driver Class Initialized
DEBUG - 2018-11-17 10:54:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-17 10:54:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-17 10:54:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-17 10:54:19 --> Pagination Class Initialized
INFO - 2018-11-17 10:54:19 --> Helper loaded: form_helper
INFO - 2018-11-17 10:54:19 --> Form Validation Class Initialized
INFO - 2018-11-17 10:54:19 --> Model Class Initialized
INFO - 2018-11-17 10:54:19 --> Controller Class Initialized
INFO - 2018-11-17 10:54:19 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-17 10:54:19 --> Model Class Initialized
ERROR - 2018-11-17 10:54:19 --> Severity: Notice --> Undefined property: CI_Loader::$user_session C:\xampp\htdocs\wetinuneed\application\views\admin\lte\header.php 58
ERROR - 2018-11-17 10:54:19 --> Severity: Notice --> Undefined index: email C:\xampp\htdocs\wetinuneed\application\views\admin\lte\header.php 59
INFO - 2018-11-17 10:55:25 --> Config Class Initialized
INFO - 2018-11-17 10:55:25 --> Hooks Class Initialized
DEBUG - 2018-11-17 10:55:25 --> UTF-8 Support Enabled
INFO - 2018-11-17 10:55:25 --> Utf8 Class Initialized
INFO - 2018-11-17 10:55:25 --> URI Class Initialized
INFO - 2018-11-17 10:55:25 --> Router Class Initialized
INFO - 2018-11-17 10:55:25 --> Output Class Initialized
INFO - 2018-11-17 10:55:25 --> Security Class Initialized
DEBUG - 2018-11-17 10:55:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-17 10:55:25 --> Input Class Initialized
INFO - 2018-11-17 10:55:25 --> Language Class Initialized
INFO - 2018-11-17 10:55:25 --> Loader Class Initialized
INFO - 2018-11-17 10:55:25 --> Helper loaded: url_helper
INFO - 2018-11-17 10:55:25 --> Helper loaded: file_helper
INFO - 2018-11-17 10:55:25 --> Helper loaded: email_helper
INFO - 2018-11-17 10:55:25 --> Helper loaded: common_helper
INFO - 2018-11-17 10:55:25 --> Database Driver Class Initialized
DEBUG - 2018-11-17 10:55:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-17 10:55:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-17 10:55:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-17 10:55:25 --> Pagination Class Initialized
INFO - 2018-11-17 10:55:25 --> Helper loaded: form_helper
INFO - 2018-11-17 10:55:25 --> Form Validation Class Initialized
INFO - 2018-11-17 10:55:25 --> Model Class Initialized
INFO - 2018-11-17 10:55:25 --> Controller Class Initialized
INFO - 2018-11-17 10:55:25 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-17 10:55:25 --> Model Class Initialized
ERROR - 2018-11-17 10:55:25 --> Severity: Notice --> Undefined property: CI_Loader::$user_session C:\xampp\htdocs\wetinuneed\application\views\admin\lte\header.php 58
ERROR - 2018-11-17 10:55:25 --> Severity: Notice --> Undefined index: email C:\xampp\htdocs\wetinuneed\application\views\admin\lte\header.php 59
ERROR - 2018-11-17 10:55:25 --> Severity: Warning --> include(C:\xampp\htdocs\wetinuneed\application\views/admin/lte/footer): failed to open stream: No such file or directory C:\xampp\htdocs\wetinuneed\application\views\admin\dashboard.php 46
ERROR - 2018-11-17 10:55:25 --> Severity: Warning --> include(): Failed opening 'C:\xampp\htdocs\wetinuneed\application\views/admin/lte/footer' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\wetinuneed\application\views\admin\dashboard.php 46
INFO - 2018-11-17 10:55:25 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/dashboard.php
INFO - 2018-11-17 10:55:25 --> Final output sent to browser
DEBUG - 2018-11-17 10:55:25 --> Total execution time: 0.0536
INFO - 2018-11-17 10:55:42 --> Config Class Initialized
INFO - 2018-11-17 10:55:42 --> Hooks Class Initialized
DEBUG - 2018-11-17 10:55:42 --> UTF-8 Support Enabled
INFO - 2018-11-17 10:55:42 --> Utf8 Class Initialized
INFO - 2018-11-17 10:55:42 --> URI Class Initialized
INFO - 2018-11-17 10:55:42 --> Router Class Initialized
INFO - 2018-11-17 10:55:42 --> Output Class Initialized
INFO - 2018-11-17 10:55:42 --> Security Class Initialized
DEBUG - 2018-11-17 10:55:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-17 10:55:42 --> Input Class Initialized
INFO - 2018-11-17 10:55:42 --> Language Class Initialized
INFO - 2018-11-17 10:55:42 --> Loader Class Initialized
INFO - 2018-11-17 10:55:42 --> Helper loaded: url_helper
INFO - 2018-11-17 10:55:42 --> Helper loaded: file_helper
INFO - 2018-11-17 10:55:42 --> Helper loaded: email_helper
INFO - 2018-11-17 10:55:42 --> Helper loaded: common_helper
INFO - 2018-11-17 10:55:42 --> Database Driver Class Initialized
DEBUG - 2018-11-17 10:55:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-17 10:55:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-17 10:55:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-17 10:55:42 --> Pagination Class Initialized
INFO - 2018-11-17 10:55:42 --> Helper loaded: form_helper
INFO - 2018-11-17 10:55:42 --> Form Validation Class Initialized
INFO - 2018-11-17 10:55:42 --> Model Class Initialized
INFO - 2018-11-17 10:55:42 --> Controller Class Initialized
INFO - 2018-11-17 10:55:42 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-17 10:55:42 --> Model Class Initialized
ERROR - 2018-11-17 10:55:42 --> Severity: Notice --> Undefined property: CI_Loader::$user_session C:\xampp\htdocs\wetinuneed\application\views\admin\lte\header.php 58
ERROR - 2018-11-17 10:55:42 --> Severity: Notice --> Undefined index: email C:\xampp\htdocs\wetinuneed\application\views\admin\lte\header.php 59
INFO - 2018-11-17 10:55:42 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/dashboard.php
INFO - 2018-11-17 10:55:42 --> Final output sent to browser
DEBUG - 2018-11-17 10:55:42 --> Total execution time: 0.0600
INFO - 2018-11-17 11:19:32 --> Config Class Initialized
INFO - 2018-11-17 11:19:32 --> Hooks Class Initialized
DEBUG - 2018-11-17 11:19:32 --> UTF-8 Support Enabled
INFO - 2018-11-17 11:19:32 --> Utf8 Class Initialized
INFO - 2018-11-17 11:19:32 --> URI Class Initialized
INFO - 2018-11-17 11:19:32 --> Router Class Initialized
INFO - 2018-11-17 11:19:32 --> Output Class Initialized
INFO - 2018-11-17 11:19:32 --> Security Class Initialized
DEBUG - 2018-11-17 11:19:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-17 11:19:32 --> Input Class Initialized
INFO - 2018-11-17 11:19:32 --> Language Class Initialized
INFO - 2018-11-17 11:19:32 --> Loader Class Initialized
INFO - 2018-11-17 11:19:32 --> Helper loaded: url_helper
INFO - 2018-11-17 11:19:32 --> Helper loaded: file_helper
INFO - 2018-11-17 11:19:32 --> Helper loaded: email_helper
INFO - 2018-11-17 11:19:32 --> Helper loaded: common_helper
INFO - 2018-11-17 11:19:32 --> Database Driver Class Initialized
DEBUG - 2018-11-17 11:19:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-17 11:19:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-17 11:19:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-17 11:19:32 --> Pagination Class Initialized
INFO - 2018-11-17 11:19:32 --> Helper loaded: form_helper
INFO - 2018-11-17 11:19:32 --> Form Validation Class Initialized
INFO - 2018-11-17 11:19:32 --> Model Class Initialized
INFO - 2018-11-17 11:19:32 --> Controller Class Initialized
INFO - 2018-11-17 11:19:32 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-17 11:19:32 --> Model Class Initialized
ERROR - 2018-11-17 11:19:32 --> Severity: Notice --> Undefined property: CI_Loader::$user_session C:\xampp\htdocs\wetinuneed\application\views\admin\lte\header.php 58
ERROR - 2018-11-17 11:19:32 --> Severity: Notice --> Undefined index: email C:\xampp\htdocs\wetinuneed\application\views\admin\lte\header.php 59
INFO - 2018-11-17 11:19:32 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/dashboard.php
INFO - 2018-11-17 11:19:32 --> Final output sent to browser
DEBUG - 2018-11-17 11:19:32 --> Total execution time: 0.0590

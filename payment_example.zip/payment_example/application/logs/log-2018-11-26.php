<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2018-11-26 06:03:01 --> Config Class Initialized
INFO - 2018-11-26 06:03:01 --> Hooks Class Initialized
DEBUG - 2018-11-26 06:03:01 --> UTF-8 Support Enabled
INFO - 2018-11-26 06:03:01 --> Utf8 Class Initialized
INFO - 2018-11-26 06:03:01 --> URI Class Initialized
DEBUG - 2018-11-26 06:03:01 --> No URI present. Default controller set.
INFO - 2018-11-26 06:03:01 --> Router Class Initialized
INFO - 2018-11-26 06:03:01 --> Output Class Initialized
INFO - 2018-11-26 06:03:01 --> Security Class Initialized
DEBUG - 2018-11-26 06:03:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-26 06:03:01 --> Input Class Initialized
INFO - 2018-11-26 06:03:01 --> Language Class Initialized
INFO - 2018-11-26 06:03:01 --> Loader Class Initialized
INFO - 2018-11-26 06:03:01 --> Helper loaded: url_helper
INFO - 2018-11-26 06:03:01 --> Helper loaded: file_helper
INFO - 2018-11-26 06:03:01 --> Helper loaded: email_helper
INFO - 2018-11-26 06:03:01 --> Helper loaded: common_helper
INFO - 2018-11-26 06:03:01 --> Database Driver Class Initialized
ERROR - 2018-11-26 06:03:11 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): A connection attempt failed because the connected party did not properly respond after a period of time, or established connection failed because connected host has failed to respond.
 C:\xampp\htdocs\wetinuneed\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2018-11-26 06:03:11 --> Unable to connect to the database
INFO - 2018-11-26 06:03:11 --> Language file loaded: language/english/db_lang.php
INFO - 2018-11-26 06:03:16 --> Config Class Initialized
INFO - 2018-11-26 06:03:16 --> Hooks Class Initialized
DEBUG - 2018-11-26 06:03:16 --> UTF-8 Support Enabled
INFO - 2018-11-26 06:03:16 --> Utf8 Class Initialized
INFO - 2018-11-26 06:03:16 --> URI Class Initialized
DEBUG - 2018-11-26 06:03:16 --> No URI present. Default controller set.
INFO - 2018-11-26 06:03:16 --> Router Class Initialized
INFO - 2018-11-26 06:03:16 --> Output Class Initialized
INFO - 2018-11-26 06:03:16 --> Security Class Initialized
DEBUG - 2018-11-26 06:03:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-26 06:03:16 --> Input Class Initialized
INFO - 2018-11-26 06:03:16 --> Language Class Initialized
INFO - 2018-11-26 06:03:16 --> Loader Class Initialized
INFO - 2018-11-26 06:03:16 --> Helper loaded: url_helper
INFO - 2018-11-26 06:03:16 --> Helper loaded: file_helper
INFO - 2018-11-26 06:03:16 --> Helper loaded: email_helper
INFO - 2018-11-26 06:03:16 --> Helper loaded: common_helper
INFO - 2018-11-26 06:03:16 --> Database Driver Class Initialized
ERROR - 2018-11-26 06:03:26 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): A connection attempt failed because the connected party did not properly respond after a period of time, or established connection failed because connected host has failed to respond.
 C:\xampp\htdocs\wetinuneed\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2018-11-26 06:03:26 --> Unable to connect to the database
INFO - 2018-11-26 06:03:26 --> Language file loaded: language/english/db_lang.php
INFO - 2018-11-26 06:04:27 --> Config Class Initialized
INFO - 2018-11-26 06:04:27 --> Hooks Class Initialized
DEBUG - 2018-11-26 06:04:27 --> UTF-8 Support Enabled
INFO - 2018-11-26 06:04:27 --> Utf8 Class Initialized
INFO - 2018-11-26 06:04:27 --> URI Class Initialized
DEBUG - 2018-11-26 06:04:27 --> No URI present. Default controller set.
INFO - 2018-11-26 06:04:27 --> Router Class Initialized
INFO - 2018-11-26 06:04:27 --> Output Class Initialized
INFO - 2018-11-26 06:04:27 --> Security Class Initialized
DEBUG - 2018-11-26 06:04:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-26 06:04:27 --> Input Class Initialized
INFO - 2018-11-26 06:04:27 --> Language Class Initialized
INFO - 2018-11-26 06:04:27 --> Loader Class Initialized
INFO - 2018-11-26 06:04:27 --> Helper loaded: url_helper
INFO - 2018-11-26 06:04:27 --> Helper loaded: file_helper
INFO - 2018-11-26 06:04:27 --> Helper loaded: email_helper
INFO - 2018-11-26 06:04:27 --> Helper loaded: common_helper
INFO - 2018-11-26 06:04:27 --> Database Driver Class Initialized
DEBUG - 2018-11-26 06:04:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-26 06:04:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-26 06:04:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-26 06:04:27 --> Pagination Class Initialized
INFO - 2018-11-26 06:04:27 --> Helper loaded: form_helper
INFO - 2018-11-26 06:04:27 --> Form Validation Class Initialized
INFO - 2018-11-26 06:04:27 --> Model Class Initialized
INFO - 2018-11-26 06:04:27 --> Controller Class Initialized
INFO - 2018-11-26 06:04:27 --> Model Class Initialized
INFO - 2018-11-26 06:04:27 --> Model Class Initialized
INFO - 2018-11-26 06:04:27 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\template/header-menu.php
INFO - 2018-11-26 06:04:27 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\template/header.php
INFO - 2018-11-26 06:04:27 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\template/footer.php
INFO - 2018-11-26 06:04:27 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\index.php
INFO - 2018-11-26 06:04:27 --> Final output sent to browser
DEBUG - 2018-11-26 06:04:27 --> Total execution time: 0.1560
INFO - 2018-11-26 06:04:40 --> Config Class Initialized
INFO - 2018-11-26 06:04:40 --> Hooks Class Initialized
DEBUG - 2018-11-26 06:04:40 --> UTF-8 Support Enabled
INFO - 2018-11-26 06:04:40 --> Utf8 Class Initialized
INFO - 2018-11-26 06:04:40 --> URI Class Initialized
INFO - 2018-11-26 06:04:40 --> Router Class Initialized
INFO - 2018-11-26 06:04:40 --> Output Class Initialized
INFO - 2018-11-26 06:04:40 --> Security Class Initialized
DEBUG - 2018-11-26 06:04:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-26 06:04:40 --> Input Class Initialized
INFO - 2018-11-26 06:04:40 --> Language Class Initialized
INFO - 2018-11-26 06:04:41 --> Loader Class Initialized
INFO - 2018-11-26 06:04:41 --> Helper loaded: url_helper
INFO - 2018-11-26 06:04:41 --> Helper loaded: file_helper
INFO - 2018-11-26 06:04:41 --> Helper loaded: email_helper
INFO - 2018-11-26 06:04:41 --> Helper loaded: common_helper
INFO - 2018-11-26 06:04:41 --> Database Driver Class Initialized
DEBUG - 2018-11-26 06:04:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-26 06:04:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-26 06:04:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-26 06:04:41 --> Pagination Class Initialized
INFO - 2018-11-26 06:04:41 --> Helper loaded: form_helper
INFO - 2018-11-26 06:04:41 --> Form Validation Class Initialized
INFO - 2018-11-26 06:04:41 --> Model Class Initialized
INFO - 2018-11-26 06:04:41 --> Controller Class Initialized
INFO - 2018-11-26 06:04:41 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-26 06:04:41 --> Model Class Initialized
INFO - 2018-11-26 06:04:41 --> Model Class Initialized
INFO - 2018-11-26 06:04:41 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/index.php
INFO - 2018-11-26 06:04:41 --> Final output sent to browser
DEBUG - 2018-11-26 06:04:41 --> Total execution time: 0.1120
INFO - 2018-11-26 06:05:02 --> Config Class Initialized
INFO - 2018-11-26 06:05:02 --> Hooks Class Initialized
DEBUG - 2018-11-26 06:05:02 --> UTF-8 Support Enabled
INFO - 2018-11-26 06:05:02 --> Utf8 Class Initialized
INFO - 2018-11-26 06:05:02 --> URI Class Initialized
INFO - 2018-11-26 06:05:02 --> Router Class Initialized
INFO - 2018-11-26 06:05:02 --> Output Class Initialized
INFO - 2018-11-26 06:05:02 --> Security Class Initialized
DEBUG - 2018-11-26 06:05:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-26 06:05:02 --> Input Class Initialized
INFO - 2018-11-26 06:05:02 --> Language Class Initialized
INFO - 2018-11-26 06:05:02 --> Loader Class Initialized
INFO - 2018-11-26 06:05:02 --> Helper loaded: url_helper
INFO - 2018-11-26 06:05:02 --> Helper loaded: file_helper
INFO - 2018-11-26 06:05:02 --> Helper loaded: email_helper
INFO - 2018-11-26 06:05:02 --> Helper loaded: common_helper
INFO - 2018-11-26 06:05:02 --> Database Driver Class Initialized
DEBUG - 2018-11-26 06:05:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-26 06:05:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-26 06:05:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-26 06:05:02 --> Pagination Class Initialized
INFO - 2018-11-26 06:05:02 --> Helper loaded: form_helper
INFO - 2018-11-26 06:05:02 --> Form Validation Class Initialized
INFO - 2018-11-26 06:05:02 --> Model Class Initialized
INFO - 2018-11-26 06:05:02 --> Controller Class Initialized
INFO - 2018-11-26 06:05:02 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-26 06:05:02 --> Model Class Initialized
INFO - 2018-11-26 06:05:02 --> Model Class Initialized
ERROR - 2018-11-26 06:05:02 --> Severity: Notice --> Undefined index: remember_me C:\xampp\htdocs\wetinuneed\application\controllers\admin\Admin.php 77
INFO - 2018-11-26 06:05:02 --> Config Class Initialized
INFO - 2018-11-26 06:05:02 --> Hooks Class Initialized
DEBUG - 2018-11-26 06:05:02 --> UTF-8 Support Enabled
INFO - 2018-11-26 06:05:02 --> Utf8 Class Initialized
INFO - 2018-11-26 06:05:02 --> URI Class Initialized
INFO - 2018-11-26 06:05:02 --> Router Class Initialized
INFO - 2018-11-26 06:05:02 --> Output Class Initialized
INFO - 2018-11-26 06:05:02 --> Security Class Initialized
DEBUG - 2018-11-26 06:05:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-26 06:05:02 --> Input Class Initialized
INFO - 2018-11-26 06:05:02 --> Language Class Initialized
INFO - 2018-11-26 06:05:02 --> Loader Class Initialized
INFO - 2018-11-26 06:05:02 --> Helper loaded: url_helper
INFO - 2018-11-26 06:05:02 --> Helper loaded: file_helper
INFO - 2018-11-26 06:05:02 --> Helper loaded: email_helper
INFO - 2018-11-26 06:05:02 --> Helper loaded: common_helper
INFO - 2018-11-26 06:05:02 --> Database Driver Class Initialized
DEBUG - 2018-11-26 06:05:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-26 06:05:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-26 06:05:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-26 06:05:02 --> Pagination Class Initialized
INFO - 2018-11-26 06:05:02 --> Helper loaded: form_helper
INFO - 2018-11-26 06:05:02 --> Form Validation Class Initialized
INFO - 2018-11-26 06:05:02 --> Model Class Initialized
INFO - 2018-11-26 06:05:02 --> Controller Class Initialized
INFO - 2018-11-26 06:05:02 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-26 06:05:02 --> Model Class Initialized
INFO - 2018-11-26 06:05:02 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-26 06:05:02 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/sidebar.php
INFO - 2018-11-26 06:05:02 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/right-sidebar.php
INFO - 2018-11-26 06:05:02 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/footer.php
INFO - 2018-11-26 06:05:02 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/dashboard.php
INFO - 2018-11-26 06:05:02 --> Final output sent to browser
DEBUG - 2018-11-26 06:05:02 --> Total execution time: 0.1100
INFO - 2018-11-26 06:09:50 --> Config Class Initialized
INFO - 2018-11-26 06:09:50 --> Hooks Class Initialized
DEBUG - 2018-11-26 06:09:50 --> UTF-8 Support Enabled
INFO - 2018-11-26 06:09:50 --> Utf8 Class Initialized
INFO - 2018-11-26 06:09:50 --> URI Class Initialized
INFO - 2018-11-26 06:09:50 --> Router Class Initialized
INFO - 2018-11-26 06:09:50 --> Output Class Initialized
INFO - 2018-11-26 06:09:50 --> Security Class Initialized
DEBUG - 2018-11-26 06:09:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-26 06:09:50 --> Input Class Initialized
INFO - 2018-11-26 06:09:50 --> Language Class Initialized
INFO - 2018-11-26 06:09:50 --> Loader Class Initialized
INFO - 2018-11-26 06:09:50 --> Helper loaded: url_helper
INFO - 2018-11-26 06:09:50 --> Helper loaded: file_helper
INFO - 2018-11-26 06:09:50 --> Helper loaded: email_helper
INFO - 2018-11-26 06:09:50 --> Helper loaded: common_helper
INFO - 2018-11-26 06:09:50 --> Database Driver Class Initialized
DEBUG - 2018-11-26 06:09:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-26 06:09:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-26 06:09:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-26 06:09:50 --> Pagination Class Initialized
INFO - 2018-11-26 06:09:50 --> Helper loaded: form_helper
INFO - 2018-11-26 06:09:50 --> Form Validation Class Initialized
INFO - 2018-11-26 06:09:50 --> Model Class Initialized
INFO - 2018-11-26 06:09:50 --> Controller Class Initialized
INFO - 2018-11-26 06:09:50 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-26 06:09:50 --> Model Class Initialized
INFO - 2018-11-26 06:09:50 --> Model Class Initialized
INFO - 2018-11-26 06:09:50 --> Config Class Initialized
INFO - 2018-11-26 06:09:50 --> Hooks Class Initialized
DEBUG - 2018-11-26 06:09:50 --> UTF-8 Support Enabled
INFO - 2018-11-26 06:09:50 --> Utf8 Class Initialized
INFO - 2018-11-26 06:09:50 --> URI Class Initialized
INFO - 2018-11-26 06:09:50 --> Router Class Initialized
INFO - 2018-11-26 06:09:50 --> Output Class Initialized
INFO - 2018-11-26 06:09:50 --> Security Class Initialized
DEBUG - 2018-11-26 06:09:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-26 06:09:50 --> Input Class Initialized
INFO - 2018-11-26 06:09:50 --> Language Class Initialized
INFO - 2018-11-26 06:09:50 --> Loader Class Initialized
INFO - 2018-11-26 06:09:50 --> Helper loaded: url_helper
INFO - 2018-11-26 06:09:50 --> Helper loaded: file_helper
INFO - 2018-11-26 06:09:50 --> Helper loaded: email_helper
INFO - 2018-11-26 06:09:50 --> Helper loaded: common_helper
INFO - 2018-11-26 06:09:50 --> Database Driver Class Initialized
DEBUG - 2018-11-26 06:09:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-26 06:09:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-26 06:09:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-26 06:09:50 --> Pagination Class Initialized
INFO - 2018-11-26 06:09:50 --> Helper loaded: form_helper
INFO - 2018-11-26 06:09:50 --> Form Validation Class Initialized
INFO - 2018-11-26 06:09:50 --> Model Class Initialized
INFO - 2018-11-26 06:09:50 --> Controller Class Initialized
INFO - 2018-11-26 06:09:50 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-26 06:09:50 --> Model Class Initialized
INFO - 2018-11-26 06:09:50 --> Model Class Initialized
INFO - 2018-11-26 06:09:50 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/index.php
INFO - 2018-11-26 06:09:50 --> Final output sent to browser
DEBUG - 2018-11-26 06:09:50 --> Total execution time: 0.0550
INFO - 2018-11-26 06:19:57 --> Config Class Initialized
INFO - 2018-11-26 06:19:57 --> Hooks Class Initialized
DEBUG - 2018-11-26 06:19:57 --> UTF-8 Support Enabled
INFO - 2018-11-26 06:19:57 --> Utf8 Class Initialized
INFO - 2018-11-26 06:19:57 --> URI Class Initialized
DEBUG - 2018-11-26 06:19:57 --> No URI present. Default controller set.
INFO - 2018-11-26 06:19:57 --> Router Class Initialized
INFO - 2018-11-26 06:19:57 --> Output Class Initialized
INFO - 2018-11-26 06:19:57 --> Security Class Initialized
DEBUG - 2018-11-26 06:19:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-26 06:19:57 --> Input Class Initialized
INFO - 2018-11-26 06:19:57 --> Language Class Initialized
INFO - 2018-11-26 06:19:57 --> Loader Class Initialized
INFO - 2018-11-26 06:19:57 --> Helper loaded: url_helper
INFO - 2018-11-26 06:19:57 --> Helper loaded: file_helper
INFO - 2018-11-26 06:19:57 --> Helper loaded: email_helper
INFO - 2018-11-26 06:19:57 --> Helper loaded: common_helper
INFO - 2018-11-26 06:19:57 --> Database Driver Class Initialized
DEBUG - 2018-11-26 06:19:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-26 06:19:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-26 06:19:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-26 06:19:57 --> Pagination Class Initialized
INFO - 2018-11-26 06:19:57 --> Helper loaded: form_helper
INFO - 2018-11-26 06:19:57 --> Form Validation Class Initialized
INFO - 2018-11-26 06:19:57 --> Model Class Initialized
INFO - 2018-11-26 06:19:57 --> Controller Class Initialized
INFO - 2018-11-26 06:19:57 --> Model Class Initialized
INFO - 2018-11-26 06:19:57 --> Model Class Initialized
INFO - 2018-11-26 06:19:57 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\template/header-menu.php
INFO - 2018-11-26 06:19:57 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\template/header.php
INFO - 2018-11-26 06:19:57 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\template/footer.php
INFO - 2018-11-26 06:19:57 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\index.php
INFO - 2018-11-26 06:19:57 --> Final output sent to browser
DEBUG - 2018-11-26 06:19:57 --> Total execution time: 0.0710
INFO - 2018-11-26 06:20:05 --> Config Class Initialized
INFO - 2018-11-26 06:20:05 --> Hooks Class Initialized
DEBUG - 2018-11-26 06:20:05 --> UTF-8 Support Enabled
INFO - 2018-11-26 06:20:05 --> Utf8 Class Initialized
INFO - 2018-11-26 06:20:05 --> URI Class Initialized
INFO - 2018-11-26 06:20:05 --> Router Class Initialized
INFO - 2018-11-26 06:20:05 --> Output Class Initialized
INFO - 2018-11-26 06:20:05 --> Security Class Initialized
DEBUG - 2018-11-26 06:20:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-26 06:20:05 --> Input Class Initialized
INFO - 2018-11-26 06:20:05 --> Language Class Initialized
INFO - 2018-11-26 06:20:05 --> Loader Class Initialized
INFO - 2018-11-26 06:20:05 --> Helper loaded: url_helper
INFO - 2018-11-26 06:20:05 --> Helper loaded: file_helper
INFO - 2018-11-26 06:20:05 --> Helper loaded: email_helper
INFO - 2018-11-26 06:20:05 --> Helper loaded: common_helper
INFO - 2018-11-26 06:20:05 --> Database Driver Class Initialized
DEBUG - 2018-11-26 06:20:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-26 06:20:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-26 06:20:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-26 06:20:05 --> Pagination Class Initialized
INFO - 2018-11-26 06:20:05 --> Helper loaded: form_helper
INFO - 2018-11-26 06:20:05 --> Form Validation Class Initialized
INFO - 2018-11-26 06:20:05 --> Model Class Initialized
INFO - 2018-11-26 06:20:05 --> Controller Class Initialized
INFO - 2018-11-26 06:20:05 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-26 06:20:05 --> Model Class Initialized
INFO - 2018-11-26 06:20:05 --> Model Class Initialized
INFO - 2018-11-26 06:20:05 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/index.php
INFO - 2018-11-26 06:20:05 --> Final output sent to browser
DEBUG - 2018-11-26 06:20:05 --> Total execution time: 0.0740
INFO - 2018-11-26 06:57:53 --> Config Class Initialized
INFO - 2018-11-26 06:57:53 --> Hooks Class Initialized
DEBUG - 2018-11-26 06:57:53 --> UTF-8 Support Enabled
INFO - 2018-11-26 06:57:53 --> Utf8 Class Initialized
INFO - 2018-11-26 06:57:53 --> URI Class Initialized
INFO - 2018-11-26 06:57:53 --> Router Class Initialized
INFO - 2018-11-26 06:57:53 --> Output Class Initialized
INFO - 2018-11-26 06:57:53 --> Security Class Initialized
DEBUG - 2018-11-26 06:57:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-26 06:57:53 --> Input Class Initialized
INFO - 2018-11-26 06:57:53 --> Language Class Initialized
INFO - 2018-11-26 06:57:53 --> Loader Class Initialized
INFO - 2018-11-26 06:57:53 --> Helper loaded: url_helper
INFO - 2018-11-26 06:57:53 --> Helper loaded: file_helper
INFO - 2018-11-26 06:57:53 --> Helper loaded: email_helper
INFO - 2018-11-26 06:57:53 --> Helper loaded: common_helper
INFO - 2018-11-26 06:57:53 --> Database Driver Class Initialized
DEBUG - 2018-11-26 06:57:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-26 06:57:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-26 06:57:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-26 06:57:53 --> Pagination Class Initialized
INFO - 2018-11-26 06:57:53 --> Helper loaded: form_helper
INFO - 2018-11-26 06:57:53 --> Form Validation Class Initialized
INFO - 2018-11-26 06:57:53 --> Model Class Initialized
INFO - 2018-11-26 06:57:53 --> Controller Class Initialized
INFO - 2018-11-26 06:57:53 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-26 06:57:53 --> Model Class Initialized
INFO - 2018-11-26 06:57:53 --> Model Class Initialized
INFO - 2018-11-26 06:57:53 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/index.php
INFO - 2018-11-26 06:57:53 --> Final output sent to browser
DEBUG - 2018-11-26 06:57:53 --> Total execution time: 0.0910
INFO - 2018-11-26 06:58:55 --> Config Class Initialized
INFO - 2018-11-26 06:58:55 --> Hooks Class Initialized
DEBUG - 2018-11-26 06:58:55 --> UTF-8 Support Enabled
INFO - 2018-11-26 06:58:55 --> Utf8 Class Initialized
INFO - 2018-11-26 06:58:55 --> URI Class Initialized
INFO - 2018-11-26 06:58:55 --> Router Class Initialized
INFO - 2018-11-26 06:58:55 --> Output Class Initialized
INFO - 2018-11-26 06:58:55 --> Security Class Initialized
DEBUG - 2018-11-26 06:58:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-26 06:58:55 --> Input Class Initialized
INFO - 2018-11-26 06:58:55 --> Language Class Initialized
INFO - 2018-11-26 06:58:55 --> Loader Class Initialized
INFO - 2018-11-26 06:58:55 --> Helper loaded: url_helper
INFO - 2018-11-26 06:58:55 --> Helper loaded: file_helper
INFO - 2018-11-26 06:58:55 --> Helper loaded: email_helper
INFO - 2018-11-26 06:58:55 --> Helper loaded: common_helper
INFO - 2018-11-26 06:58:55 --> Database Driver Class Initialized
DEBUG - 2018-11-26 06:58:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-26 06:58:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-26 06:58:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-26 06:58:55 --> Pagination Class Initialized
INFO - 2018-11-26 06:58:55 --> Helper loaded: form_helper
INFO - 2018-11-26 06:58:55 --> Form Validation Class Initialized
INFO - 2018-11-26 06:58:55 --> Model Class Initialized
INFO - 2018-11-26 06:58:55 --> Controller Class Initialized
INFO - 2018-11-26 06:58:55 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-26 06:58:55 --> Model Class Initialized
INFO - 2018-11-26 06:58:55 --> Model Class Initialized
INFO - 2018-11-26 06:58:55 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/index.php
INFO - 2018-11-26 06:58:55 --> Final output sent to browser
DEBUG - 2018-11-26 06:58:55 --> Total execution time: 0.0710
INFO - 2018-11-26 07:00:19 --> Config Class Initialized
INFO - 2018-11-26 07:00:19 --> Hooks Class Initialized
DEBUG - 2018-11-26 07:00:19 --> UTF-8 Support Enabled
INFO - 2018-11-26 07:00:19 --> Utf8 Class Initialized
INFO - 2018-11-26 07:00:19 --> URI Class Initialized
INFO - 2018-11-26 07:00:19 --> Router Class Initialized
INFO - 2018-11-26 07:00:19 --> Output Class Initialized
INFO - 2018-11-26 07:00:19 --> Security Class Initialized
DEBUG - 2018-11-26 07:00:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-26 07:00:19 --> Input Class Initialized
INFO - 2018-11-26 07:00:19 --> Language Class Initialized
INFO - 2018-11-26 07:00:19 --> Loader Class Initialized
INFO - 2018-11-26 07:00:19 --> Helper loaded: url_helper
INFO - 2018-11-26 07:00:19 --> Helper loaded: file_helper
INFO - 2018-11-26 07:00:19 --> Helper loaded: email_helper
INFO - 2018-11-26 07:00:19 --> Helper loaded: common_helper
INFO - 2018-11-26 07:00:19 --> Database Driver Class Initialized
DEBUG - 2018-11-26 07:00:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-26 07:00:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-26 07:00:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-26 07:00:19 --> Pagination Class Initialized
INFO - 2018-11-26 07:00:20 --> Helper loaded: form_helper
INFO - 2018-11-26 07:00:20 --> Form Validation Class Initialized
INFO - 2018-11-26 07:00:20 --> Model Class Initialized
INFO - 2018-11-26 07:00:20 --> Controller Class Initialized
INFO - 2018-11-26 07:00:20 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-26 07:00:20 --> Model Class Initialized
INFO - 2018-11-26 07:00:20 --> Model Class Initialized
INFO - 2018-11-26 07:00:20 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/index.php
INFO - 2018-11-26 07:00:20 --> Final output sent to browser
DEBUG - 2018-11-26 07:00:20 --> Total execution time: 0.1120
INFO - 2018-11-26 07:00:24 --> Config Class Initialized
INFO - 2018-11-26 07:00:24 --> Hooks Class Initialized
DEBUG - 2018-11-26 07:00:24 --> UTF-8 Support Enabled
INFO - 2018-11-26 07:00:24 --> Utf8 Class Initialized
INFO - 2018-11-26 07:00:25 --> URI Class Initialized
INFO - 2018-11-26 07:00:25 --> Router Class Initialized
INFO - 2018-11-26 07:00:25 --> Output Class Initialized
INFO - 2018-11-26 07:00:25 --> Security Class Initialized
DEBUG - 2018-11-26 07:00:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-26 07:00:25 --> Input Class Initialized
INFO - 2018-11-26 07:00:25 --> Language Class Initialized
INFO - 2018-11-26 07:00:25 --> Loader Class Initialized
INFO - 2018-11-26 07:00:25 --> Helper loaded: url_helper
INFO - 2018-11-26 07:00:25 --> Helper loaded: file_helper
INFO - 2018-11-26 07:00:25 --> Helper loaded: email_helper
INFO - 2018-11-26 07:00:25 --> Helper loaded: common_helper
INFO - 2018-11-26 07:00:25 --> Database Driver Class Initialized
DEBUG - 2018-11-26 07:00:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-26 07:00:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-26 07:00:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-26 07:00:25 --> Pagination Class Initialized
INFO - 2018-11-26 07:00:25 --> Helper loaded: form_helper
INFO - 2018-11-26 07:00:25 --> Form Validation Class Initialized
INFO - 2018-11-26 07:00:25 --> Model Class Initialized
INFO - 2018-11-26 07:00:25 --> Controller Class Initialized
INFO - 2018-11-26 07:00:25 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-26 07:00:25 --> Model Class Initialized
INFO - 2018-11-26 07:00:25 --> Model Class Initialized
INFO - 2018-11-26 07:00:25 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/index.php
INFO - 2018-11-26 07:00:25 --> Final output sent to browser
DEBUG - 2018-11-26 07:00:25 --> Total execution time: 0.0780
INFO - 2018-11-26 07:01:00 --> Config Class Initialized
INFO - 2018-11-26 07:01:00 --> Hooks Class Initialized
DEBUG - 2018-11-26 07:01:00 --> UTF-8 Support Enabled
INFO - 2018-11-26 07:01:00 --> Utf8 Class Initialized
INFO - 2018-11-26 07:01:00 --> URI Class Initialized
INFO - 2018-11-26 07:01:00 --> Router Class Initialized
INFO - 2018-11-26 07:01:00 --> Output Class Initialized
INFO - 2018-11-26 07:01:00 --> Security Class Initialized
DEBUG - 2018-11-26 07:01:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-26 07:01:00 --> Input Class Initialized
INFO - 2018-11-26 07:01:00 --> Language Class Initialized
INFO - 2018-11-26 07:01:00 --> Loader Class Initialized
INFO - 2018-11-26 07:01:00 --> Helper loaded: url_helper
INFO - 2018-11-26 07:01:00 --> Helper loaded: file_helper
INFO - 2018-11-26 07:01:00 --> Helper loaded: email_helper
INFO - 2018-11-26 07:01:00 --> Helper loaded: common_helper
INFO - 2018-11-26 07:01:00 --> Database Driver Class Initialized
DEBUG - 2018-11-26 07:01:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-26 07:01:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-26 07:01:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-26 07:01:00 --> Pagination Class Initialized
INFO - 2018-11-26 07:01:00 --> Helper loaded: form_helper
INFO - 2018-11-26 07:01:00 --> Form Validation Class Initialized
INFO - 2018-11-26 07:01:00 --> Model Class Initialized
INFO - 2018-11-26 07:01:00 --> Controller Class Initialized
INFO - 2018-11-26 07:01:00 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-26 07:01:00 --> Model Class Initialized
INFO - 2018-11-26 07:01:00 --> Model Class Initialized
INFO - 2018-11-26 07:01:00 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/index.php
INFO - 2018-11-26 07:01:00 --> Final output sent to browser
DEBUG - 2018-11-26 07:01:00 --> Total execution time: 0.0650
INFO - 2018-11-26 07:01:15 --> Config Class Initialized
INFO - 2018-11-26 07:01:15 --> Hooks Class Initialized
DEBUG - 2018-11-26 07:01:15 --> UTF-8 Support Enabled
INFO - 2018-11-26 07:01:15 --> Utf8 Class Initialized
INFO - 2018-11-26 07:01:15 --> URI Class Initialized
INFO - 2018-11-26 07:01:15 --> Router Class Initialized
INFO - 2018-11-26 07:01:15 --> Output Class Initialized
INFO - 2018-11-26 07:01:15 --> Security Class Initialized
DEBUG - 2018-11-26 07:01:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-26 07:01:15 --> Input Class Initialized
INFO - 2018-11-26 07:01:15 --> Language Class Initialized
INFO - 2018-11-26 07:01:15 --> Loader Class Initialized
INFO - 2018-11-26 07:01:15 --> Helper loaded: url_helper
INFO - 2018-11-26 07:01:15 --> Helper loaded: file_helper
INFO - 2018-11-26 07:01:15 --> Helper loaded: email_helper
INFO - 2018-11-26 07:01:15 --> Helper loaded: common_helper
INFO - 2018-11-26 07:01:15 --> Database Driver Class Initialized
DEBUG - 2018-11-26 07:01:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-26 07:01:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-26 07:01:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-26 07:01:15 --> Pagination Class Initialized
INFO - 2018-11-26 07:01:15 --> Helper loaded: form_helper
INFO - 2018-11-26 07:01:15 --> Form Validation Class Initialized
INFO - 2018-11-26 07:01:15 --> Model Class Initialized
INFO - 2018-11-26 07:01:15 --> Controller Class Initialized
INFO - 2018-11-26 07:01:15 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-26 07:01:15 --> Model Class Initialized
INFO - 2018-11-26 07:01:15 --> Model Class Initialized
INFO - 2018-11-26 07:01:15 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/index.php
INFO - 2018-11-26 07:01:15 --> Final output sent to browser
DEBUG - 2018-11-26 07:01:15 --> Total execution time: 0.0670
INFO - 2018-11-26 07:01:38 --> Config Class Initialized
INFO - 2018-11-26 07:01:38 --> Hooks Class Initialized
DEBUG - 2018-11-26 07:01:38 --> UTF-8 Support Enabled
INFO - 2018-11-26 07:01:38 --> Utf8 Class Initialized
INFO - 2018-11-26 07:01:38 --> URI Class Initialized
INFO - 2018-11-26 07:01:38 --> Router Class Initialized
INFO - 2018-11-26 07:01:38 --> Output Class Initialized
INFO - 2018-11-26 07:01:38 --> Security Class Initialized
DEBUG - 2018-11-26 07:01:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-26 07:01:38 --> Input Class Initialized
INFO - 2018-11-26 07:01:38 --> Language Class Initialized
INFO - 2018-11-26 07:01:38 --> Loader Class Initialized
INFO - 2018-11-26 07:01:38 --> Helper loaded: url_helper
INFO - 2018-11-26 07:01:38 --> Helper loaded: file_helper
INFO - 2018-11-26 07:01:38 --> Helper loaded: email_helper
INFO - 2018-11-26 07:01:38 --> Helper loaded: common_helper
INFO - 2018-11-26 07:01:38 --> Database Driver Class Initialized
DEBUG - 2018-11-26 07:01:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-26 07:01:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-26 07:01:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-26 07:01:38 --> Pagination Class Initialized
INFO - 2018-11-26 07:01:39 --> Helper loaded: form_helper
INFO - 2018-11-26 07:01:39 --> Form Validation Class Initialized
INFO - 2018-11-26 07:01:39 --> Model Class Initialized
INFO - 2018-11-26 07:01:39 --> Controller Class Initialized
INFO - 2018-11-26 07:01:39 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-26 07:01:39 --> Model Class Initialized
INFO - 2018-11-26 07:01:39 --> Model Class Initialized
INFO - 2018-11-26 07:01:39 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/index.php
INFO - 2018-11-26 07:01:39 --> Final output sent to browser
DEBUG - 2018-11-26 07:01:39 --> Total execution time: 0.0770
INFO - 2018-11-26 07:14:20 --> Config Class Initialized
INFO - 2018-11-26 07:14:20 --> Hooks Class Initialized
DEBUG - 2018-11-26 07:14:20 --> UTF-8 Support Enabled
INFO - 2018-11-26 07:14:20 --> Utf8 Class Initialized
INFO - 2018-11-26 07:14:20 --> URI Class Initialized
INFO - 2018-11-26 07:14:20 --> Router Class Initialized
INFO - 2018-11-26 07:14:20 --> Output Class Initialized
INFO - 2018-11-26 07:14:20 --> Security Class Initialized
DEBUG - 2018-11-26 07:14:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-26 07:14:20 --> Input Class Initialized
INFO - 2018-11-26 07:14:20 --> Language Class Initialized
ERROR - 2018-11-26 07:14:20 --> 404 Page Not Found: admin/VerifyEmail/index
INFO - 2018-11-26 07:14:20 --> Config Class Initialized
INFO - 2018-11-26 07:14:20 --> Hooks Class Initialized
DEBUG - 2018-11-26 07:14:20 --> UTF-8 Support Enabled
INFO - 2018-11-26 07:14:20 --> Utf8 Class Initialized
INFO - 2018-11-26 07:14:20 --> URI Class Initialized
INFO - 2018-11-26 07:14:20 --> Router Class Initialized
INFO - 2018-11-26 07:14:20 --> Output Class Initialized
INFO - 2018-11-26 07:14:20 --> Security Class Initialized
DEBUG - 2018-11-26 07:14:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-26 07:14:20 --> Input Class Initialized
INFO - 2018-11-26 07:14:20 --> Language Class Initialized
ERROR - 2018-11-26 07:14:20 --> 404 Page Not Found: admin/VerifyEmail/index
INFO - 2018-11-26 07:14:21 --> Config Class Initialized
INFO - 2018-11-26 07:14:21 --> Hooks Class Initialized
DEBUG - 2018-11-26 07:14:21 --> UTF-8 Support Enabled
INFO - 2018-11-26 07:14:21 --> Utf8 Class Initialized
INFO - 2018-11-26 07:14:21 --> URI Class Initialized
INFO - 2018-11-26 07:14:21 --> Router Class Initialized
INFO - 2018-11-26 07:14:21 --> Output Class Initialized
INFO - 2018-11-26 07:14:21 --> Security Class Initialized
DEBUG - 2018-11-26 07:14:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-26 07:14:21 --> Input Class Initialized
INFO - 2018-11-26 07:14:21 --> Language Class Initialized
ERROR - 2018-11-26 07:14:21 --> 404 Page Not Found: admin/VerifyEmail/index
INFO - 2018-11-26 07:14:22 --> Config Class Initialized
INFO - 2018-11-26 07:14:22 --> Hooks Class Initialized
DEBUG - 2018-11-26 07:14:22 --> UTF-8 Support Enabled
INFO - 2018-11-26 07:14:22 --> Utf8 Class Initialized
INFO - 2018-11-26 07:14:22 --> URI Class Initialized
INFO - 2018-11-26 07:14:22 --> Router Class Initialized
INFO - 2018-11-26 07:14:22 --> Output Class Initialized
INFO - 2018-11-26 07:14:22 --> Security Class Initialized
DEBUG - 2018-11-26 07:14:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-26 07:14:22 --> Input Class Initialized
INFO - 2018-11-26 07:14:22 --> Language Class Initialized
ERROR - 2018-11-26 07:14:22 --> 404 Page Not Found: admin/VerifyEmail/index
INFO - 2018-11-26 07:14:22 --> Config Class Initialized
INFO - 2018-11-26 07:14:22 --> Hooks Class Initialized
DEBUG - 2018-11-26 07:14:22 --> UTF-8 Support Enabled
INFO - 2018-11-26 07:14:22 --> Utf8 Class Initialized
INFO - 2018-11-26 07:14:22 --> URI Class Initialized
INFO - 2018-11-26 07:14:22 --> Router Class Initialized
INFO - 2018-11-26 07:14:22 --> Output Class Initialized
INFO - 2018-11-26 07:14:22 --> Security Class Initialized
DEBUG - 2018-11-26 07:14:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-26 07:14:22 --> Input Class Initialized
INFO - 2018-11-26 07:14:22 --> Language Class Initialized
ERROR - 2018-11-26 07:14:22 --> 404 Page Not Found: admin/VerifyEmail/index
INFO - 2018-11-26 07:14:22 --> Config Class Initialized
INFO - 2018-11-26 07:14:22 --> Hooks Class Initialized
DEBUG - 2018-11-26 07:14:22 --> UTF-8 Support Enabled
INFO - 2018-11-26 07:14:22 --> Utf8 Class Initialized
INFO - 2018-11-26 07:14:22 --> URI Class Initialized
INFO - 2018-11-26 07:14:22 --> Router Class Initialized
INFO - 2018-11-26 07:14:22 --> Output Class Initialized
INFO - 2018-11-26 07:14:22 --> Security Class Initialized
DEBUG - 2018-11-26 07:14:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-26 07:14:22 --> Input Class Initialized
INFO - 2018-11-26 07:14:22 --> Language Class Initialized
ERROR - 2018-11-26 07:14:22 --> 404 Page Not Found: admin/VerifyEmail/index
INFO - 2018-11-26 07:14:22 --> Config Class Initialized
INFO - 2018-11-26 07:14:22 --> Hooks Class Initialized
DEBUG - 2018-11-26 07:14:22 --> UTF-8 Support Enabled
INFO - 2018-11-26 07:14:22 --> Utf8 Class Initialized
INFO - 2018-11-26 07:14:22 --> URI Class Initialized
INFO - 2018-11-26 07:14:22 --> Router Class Initialized
INFO - 2018-11-26 07:14:22 --> Output Class Initialized
INFO - 2018-11-26 07:14:22 --> Security Class Initialized
DEBUG - 2018-11-26 07:14:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-26 07:14:22 --> Input Class Initialized
INFO - 2018-11-26 07:14:22 --> Language Class Initialized
ERROR - 2018-11-26 07:14:22 --> 404 Page Not Found: admin/VerifyEmail/index
INFO - 2018-11-26 07:14:23 --> Config Class Initialized
INFO - 2018-11-26 07:14:23 --> Hooks Class Initialized
DEBUG - 2018-11-26 07:14:23 --> UTF-8 Support Enabled
INFO - 2018-11-26 07:14:23 --> Utf8 Class Initialized
INFO - 2018-11-26 07:14:23 --> URI Class Initialized
INFO - 2018-11-26 07:14:23 --> Router Class Initialized
INFO - 2018-11-26 07:14:23 --> Output Class Initialized
INFO - 2018-11-26 07:14:23 --> Security Class Initialized
DEBUG - 2018-11-26 07:14:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-26 07:14:23 --> Input Class Initialized
INFO - 2018-11-26 07:14:23 --> Language Class Initialized
ERROR - 2018-11-26 07:14:23 --> 404 Page Not Found: admin/VerifyEmail/index
INFO - 2018-11-26 07:14:23 --> Config Class Initialized
INFO - 2018-11-26 07:14:23 --> Hooks Class Initialized
DEBUG - 2018-11-26 07:14:23 --> UTF-8 Support Enabled
INFO - 2018-11-26 07:14:23 --> Utf8 Class Initialized
INFO - 2018-11-26 07:14:23 --> URI Class Initialized
INFO - 2018-11-26 07:14:23 --> Router Class Initialized
INFO - 2018-11-26 07:14:23 --> Output Class Initialized
INFO - 2018-11-26 07:14:23 --> Security Class Initialized
DEBUG - 2018-11-26 07:14:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-26 07:14:23 --> Input Class Initialized
INFO - 2018-11-26 07:14:23 --> Language Class Initialized
ERROR - 2018-11-26 07:14:23 --> 404 Page Not Found: admin/VerifyEmail/index
INFO - 2018-11-26 07:14:24 --> Config Class Initialized
INFO - 2018-11-26 07:14:24 --> Hooks Class Initialized
DEBUG - 2018-11-26 07:14:24 --> UTF-8 Support Enabled
INFO - 2018-11-26 07:14:24 --> Utf8 Class Initialized
INFO - 2018-11-26 07:14:24 --> URI Class Initialized
INFO - 2018-11-26 07:14:24 --> Router Class Initialized
INFO - 2018-11-26 07:14:24 --> Output Class Initialized
INFO - 2018-11-26 07:14:24 --> Security Class Initialized
DEBUG - 2018-11-26 07:14:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-26 07:14:24 --> Input Class Initialized
INFO - 2018-11-26 07:14:24 --> Language Class Initialized
ERROR - 2018-11-26 07:14:24 --> 404 Page Not Found: admin/VerifyEmail/index
INFO - 2018-11-26 07:14:25 --> Config Class Initialized
INFO - 2018-11-26 07:14:25 --> Hooks Class Initialized
DEBUG - 2018-11-26 07:14:25 --> UTF-8 Support Enabled
INFO - 2018-11-26 07:14:25 --> Utf8 Class Initialized
INFO - 2018-11-26 07:14:25 --> URI Class Initialized
INFO - 2018-11-26 07:14:25 --> Router Class Initialized
INFO - 2018-11-26 07:14:25 --> Output Class Initialized
INFO - 2018-11-26 07:14:25 --> Security Class Initialized
DEBUG - 2018-11-26 07:14:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-26 07:14:25 --> Input Class Initialized
INFO - 2018-11-26 07:14:25 --> Language Class Initialized
ERROR - 2018-11-26 07:14:25 --> 404 Page Not Found: admin/VerifyEmail/index
INFO - 2018-11-26 07:14:25 --> Config Class Initialized
INFO - 2018-11-26 07:14:25 --> Hooks Class Initialized
DEBUG - 2018-11-26 07:14:25 --> UTF-8 Support Enabled
INFO - 2018-11-26 07:14:25 --> Utf8 Class Initialized
INFO - 2018-11-26 07:14:25 --> URI Class Initialized
INFO - 2018-11-26 07:14:25 --> Router Class Initialized
INFO - 2018-11-26 07:14:25 --> Output Class Initialized
INFO - 2018-11-26 07:14:25 --> Security Class Initialized
DEBUG - 2018-11-26 07:14:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-26 07:14:25 --> Input Class Initialized
INFO - 2018-11-26 07:14:25 --> Language Class Initialized
ERROR - 2018-11-26 07:14:25 --> 404 Page Not Found: admin/VerifyEmail/index
INFO - 2018-11-26 07:14:25 --> Config Class Initialized
INFO - 2018-11-26 07:14:25 --> Hooks Class Initialized
DEBUG - 2018-11-26 07:14:25 --> UTF-8 Support Enabled
INFO - 2018-11-26 07:14:25 --> Utf8 Class Initialized
INFO - 2018-11-26 07:14:25 --> URI Class Initialized
INFO - 2018-11-26 07:14:25 --> Router Class Initialized
INFO - 2018-11-26 07:14:25 --> Output Class Initialized
INFO - 2018-11-26 07:14:25 --> Security Class Initialized
DEBUG - 2018-11-26 07:14:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-26 07:14:25 --> Input Class Initialized
INFO - 2018-11-26 07:14:25 --> Language Class Initialized
ERROR - 2018-11-26 07:14:25 --> 404 Page Not Found: admin/VerifyEmail/index
INFO - 2018-11-26 07:14:27 --> Config Class Initialized
INFO - 2018-11-26 07:14:27 --> Hooks Class Initialized
DEBUG - 2018-11-26 07:14:27 --> UTF-8 Support Enabled
INFO - 2018-11-26 07:14:27 --> Utf8 Class Initialized
INFO - 2018-11-26 07:14:27 --> URI Class Initialized
INFO - 2018-11-26 07:14:27 --> Router Class Initialized
INFO - 2018-11-26 07:14:27 --> Output Class Initialized
INFO - 2018-11-26 07:14:27 --> Security Class Initialized
DEBUG - 2018-11-26 07:14:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-26 07:14:27 --> Input Class Initialized
INFO - 2018-11-26 07:14:27 --> Language Class Initialized
ERROR - 2018-11-26 07:14:27 --> 404 Page Not Found: admin/VerifyEmail/index
INFO - 2018-11-26 07:14:28 --> Config Class Initialized
INFO - 2018-11-26 07:14:28 --> Hooks Class Initialized
DEBUG - 2018-11-26 07:14:28 --> UTF-8 Support Enabled
INFO - 2018-11-26 07:14:28 --> Utf8 Class Initialized
INFO - 2018-11-26 07:14:28 --> URI Class Initialized
INFO - 2018-11-26 07:14:28 --> Router Class Initialized
INFO - 2018-11-26 07:14:28 --> Output Class Initialized
INFO - 2018-11-26 07:14:28 --> Security Class Initialized
DEBUG - 2018-11-26 07:14:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-26 07:14:28 --> Input Class Initialized
INFO - 2018-11-26 07:14:28 --> Language Class Initialized
ERROR - 2018-11-26 07:14:28 --> 404 Page Not Found: admin/VerifyEmail/index
INFO - 2018-11-26 07:15:21 --> Config Class Initialized
INFO - 2018-11-26 07:15:21 --> Hooks Class Initialized
DEBUG - 2018-11-26 07:15:21 --> UTF-8 Support Enabled
INFO - 2018-11-26 07:15:21 --> Utf8 Class Initialized
INFO - 2018-11-26 07:15:21 --> URI Class Initialized
INFO - 2018-11-26 07:15:21 --> Router Class Initialized
INFO - 2018-11-26 07:15:21 --> Output Class Initialized
INFO - 2018-11-26 07:15:21 --> Security Class Initialized
DEBUG - 2018-11-26 07:15:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-26 07:15:21 --> Input Class Initialized
INFO - 2018-11-26 07:15:21 --> Language Class Initialized
INFO - 2018-11-26 07:15:21 --> Loader Class Initialized
INFO - 2018-11-26 07:15:21 --> Helper loaded: url_helper
INFO - 2018-11-26 07:15:21 --> Helper loaded: file_helper
INFO - 2018-11-26 07:15:21 --> Helper loaded: email_helper
INFO - 2018-11-26 07:15:21 --> Helper loaded: common_helper
INFO - 2018-11-26 07:15:21 --> Database Driver Class Initialized
DEBUG - 2018-11-26 07:15:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-26 07:15:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-26 07:15:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-26 07:15:21 --> Pagination Class Initialized
INFO - 2018-11-26 07:15:21 --> Helper loaded: form_helper
INFO - 2018-11-26 07:15:21 --> Form Validation Class Initialized
INFO - 2018-11-26 07:15:21 --> Model Class Initialized
INFO - 2018-11-26 07:15:21 --> Controller Class Initialized
INFO - 2018-11-26 07:15:21 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-26 07:15:21 --> Model Class Initialized
INFO - 2018-11-26 07:15:21 --> Model Class Initialized
INFO - 2018-11-26 07:15:21 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/index.php
INFO - 2018-11-26 07:15:21 --> Final output sent to browser
DEBUG - 2018-11-26 07:15:21 --> Total execution time: 0.0930
INFO - 2018-11-26 07:15:27 --> Config Class Initialized
INFO - 2018-11-26 07:15:27 --> Hooks Class Initialized
DEBUG - 2018-11-26 07:15:27 --> UTF-8 Support Enabled
INFO - 2018-11-26 07:15:27 --> Utf8 Class Initialized
INFO - 2018-11-26 07:15:27 --> URI Class Initialized
INFO - 2018-11-26 07:15:27 --> Router Class Initialized
INFO - 2018-11-26 07:15:27 --> Output Class Initialized
INFO - 2018-11-26 07:15:27 --> Security Class Initialized
DEBUG - 2018-11-26 07:15:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-26 07:15:27 --> Input Class Initialized
INFO - 2018-11-26 07:15:27 --> Language Class Initialized
ERROR - 2018-11-26 07:15:27 --> 404 Page Not Found: admin/VerifyEmail/index
INFO - 2018-11-26 07:15:28 --> Config Class Initialized
INFO - 2018-11-26 07:15:28 --> Hooks Class Initialized
DEBUG - 2018-11-26 07:15:28 --> UTF-8 Support Enabled
INFO - 2018-11-26 07:15:28 --> Utf8 Class Initialized
INFO - 2018-11-26 07:15:28 --> URI Class Initialized
INFO - 2018-11-26 07:15:28 --> Router Class Initialized
INFO - 2018-11-26 07:15:28 --> Output Class Initialized
INFO - 2018-11-26 07:15:28 --> Security Class Initialized
DEBUG - 2018-11-26 07:15:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-26 07:15:28 --> Input Class Initialized
INFO - 2018-11-26 07:15:28 --> Language Class Initialized
ERROR - 2018-11-26 07:15:28 --> 404 Page Not Found: admin/VerifyEmail/index
INFO - 2018-11-26 07:15:29 --> Config Class Initialized
INFO - 2018-11-26 07:15:29 --> Hooks Class Initialized
DEBUG - 2018-11-26 07:15:29 --> UTF-8 Support Enabled
INFO - 2018-11-26 07:15:29 --> Utf8 Class Initialized
INFO - 2018-11-26 07:15:29 --> URI Class Initialized
INFO - 2018-11-26 07:15:29 --> Router Class Initialized
INFO - 2018-11-26 07:15:29 --> Output Class Initialized
INFO - 2018-11-26 07:15:29 --> Security Class Initialized
DEBUG - 2018-11-26 07:15:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-26 07:15:29 --> Input Class Initialized
INFO - 2018-11-26 07:15:29 --> Language Class Initialized
ERROR - 2018-11-26 07:15:29 --> 404 Page Not Found: admin/VerifyEmail/index
INFO - 2018-11-26 07:15:30 --> Config Class Initialized
INFO - 2018-11-26 07:15:30 --> Hooks Class Initialized
DEBUG - 2018-11-26 07:15:30 --> UTF-8 Support Enabled
INFO - 2018-11-26 07:15:30 --> Utf8 Class Initialized
INFO - 2018-11-26 07:15:30 --> URI Class Initialized
INFO - 2018-11-26 07:15:30 --> Router Class Initialized
INFO - 2018-11-26 07:15:30 --> Output Class Initialized
INFO - 2018-11-26 07:15:30 --> Security Class Initialized
DEBUG - 2018-11-26 07:15:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-26 07:15:30 --> Input Class Initialized
INFO - 2018-11-26 07:15:30 --> Language Class Initialized
ERROR - 2018-11-26 07:15:30 --> 404 Page Not Found: admin/VerifyEmail/index
INFO - 2018-11-26 07:15:30 --> Config Class Initialized
INFO - 2018-11-26 07:15:30 --> Hooks Class Initialized
DEBUG - 2018-11-26 07:15:30 --> UTF-8 Support Enabled
INFO - 2018-11-26 07:15:30 --> Utf8 Class Initialized
INFO - 2018-11-26 07:15:30 --> URI Class Initialized
INFO - 2018-11-26 07:15:30 --> Router Class Initialized
INFO - 2018-11-26 07:15:30 --> Output Class Initialized
INFO - 2018-11-26 07:15:30 --> Security Class Initialized
DEBUG - 2018-11-26 07:15:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-26 07:15:30 --> Input Class Initialized
INFO - 2018-11-26 07:15:30 --> Language Class Initialized
ERROR - 2018-11-26 07:15:30 --> 404 Page Not Found: admin/VerifyEmail/index
INFO - 2018-11-26 07:15:31 --> Config Class Initialized
INFO - 2018-11-26 07:15:31 --> Hooks Class Initialized
DEBUG - 2018-11-26 07:15:31 --> UTF-8 Support Enabled
INFO - 2018-11-26 07:15:31 --> Utf8 Class Initialized
INFO - 2018-11-26 07:15:31 --> URI Class Initialized
INFO - 2018-11-26 07:15:31 --> Router Class Initialized
INFO - 2018-11-26 07:15:31 --> Output Class Initialized
INFO - 2018-11-26 07:15:31 --> Security Class Initialized
DEBUG - 2018-11-26 07:15:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-26 07:15:31 --> Input Class Initialized
INFO - 2018-11-26 07:15:31 --> Language Class Initialized
ERROR - 2018-11-26 07:15:31 --> 404 Page Not Found: admin/VerifyEmail/index
INFO - 2018-11-26 07:15:31 --> Config Class Initialized
INFO - 2018-11-26 07:15:31 --> Hooks Class Initialized
DEBUG - 2018-11-26 07:15:31 --> UTF-8 Support Enabled
INFO - 2018-11-26 07:15:31 --> Utf8 Class Initialized
INFO - 2018-11-26 07:15:31 --> URI Class Initialized
INFO - 2018-11-26 07:15:31 --> Router Class Initialized
INFO - 2018-11-26 07:15:31 --> Output Class Initialized
INFO - 2018-11-26 07:15:31 --> Security Class Initialized
DEBUG - 2018-11-26 07:15:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-26 07:15:31 --> Input Class Initialized
INFO - 2018-11-26 07:15:31 --> Language Class Initialized
ERROR - 2018-11-26 07:15:31 --> 404 Page Not Found: admin/VerifyEmail/index
INFO - 2018-11-26 07:15:43 --> Config Class Initialized
INFO - 2018-11-26 07:15:43 --> Hooks Class Initialized
DEBUG - 2018-11-26 07:15:43 --> UTF-8 Support Enabled
INFO - 2018-11-26 07:15:43 --> Utf8 Class Initialized
INFO - 2018-11-26 07:15:43 --> URI Class Initialized
INFO - 2018-11-26 07:15:43 --> Router Class Initialized
INFO - 2018-11-26 07:15:43 --> Output Class Initialized
INFO - 2018-11-26 07:15:43 --> Security Class Initialized
DEBUG - 2018-11-26 07:15:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-26 07:15:43 --> Input Class Initialized
INFO - 2018-11-26 07:15:43 --> Language Class Initialized
ERROR - 2018-11-26 07:15:43 --> 404 Page Not Found: admin/VerifyEmail/index
INFO - 2018-11-26 07:15:44 --> Config Class Initialized
INFO - 2018-11-26 07:15:44 --> Hooks Class Initialized
DEBUG - 2018-11-26 07:15:44 --> UTF-8 Support Enabled
INFO - 2018-11-26 07:15:44 --> Utf8 Class Initialized
INFO - 2018-11-26 07:15:44 --> URI Class Initialized
INFO - 2018-11-26 07:15:44 --> Router Class Initialized
INFO - 2018-11-26 07:15:44 --> Output Class Initialized
INFO - 2018-11-26 07:15:44 --> Security Class Initialized
DEBUG - 2018-11-26 07:15:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-26 07:15:44 --> Input Class Initialized
INFO - 2018-11-26 07:15:44 --> Language Class Initialized
ERROR - 2018-11-26 07:15:44 --> 404 Page Not Found: admin/VerifyEmail/index
INFO - 2018-11-26 07:16:43 --> Config Class Initialized
INFO - 2018-11-26 07:16:43 --> Hooks Class Initialized
DEBUG - 2018-11-26 07:16:43 --> UTF-8 Support Enabled
INFO - 2018-11-26 07:16:43 --> Utf8 Class Initialized
INFO - 2018-11-26 07:16:43 --> URI Class Initialized
INFO - 2018-11-26 07:16:43 --> Router Class Initialized
INFO - 2018-11-26 07:16:43 --> Output Class Initialized
INFO - 2018-11-26 07:16:43 --> Security Class Initialized
DEBUG - 2018-11-26 07:16:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-26 07:16:43 --> Input Class Initialized
INFO - 2018-11-26 07:16:43 --> Language Class Initialized
INFO - 2018-11-26 07:16:43 --> Loader Class Initialized
INFO - 2018-11-26 07:16:43 --> Helper loaded: url_helper
INFO - 2018-11-26 07:16:43 --> Helper loaded: file_helper
INFO - 2018-11-26 07:16:43 --> Helper loaded: email_helper
INFO - 2018-11-26 07:16:43 --> Helper loaded: common_helper
INFO - 2018-11-26 07:16:44 --> Database Driver Class Initialized
DEBUG - 2018-11-26 07:16:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-26 07:16:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-26 07:16:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-26 07:16:44 --> Pagination Class Initialized
INFO - 2018-11-26 07:16:44 --> Helper loaded: form_helper
INFO - 2018-11-26 07:16:44 --> Form Validation Class Initialized
INFO - 2018-11-26 07:16:44 --> Model Class Initialized
INFO - 2018-11-26 07:16:44 --> Controller Class Initialized
INFO - 2018-11-26 07:16:44 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-26 07:16:44 --> Model Class Initialized
INFO - 2018-11-26 07:16:44 --> Model Class Initialized
INFO - 2018-11-26 07:16:44 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/index.php
INFO - 2018-11-26 07:16:44 --> Final output sent to browser
DEBUG - 2018-11-26 07:16:44 --> Total execution time: 0.0650
INFO - 2018-11-26 07:16:50 --> Config Class Initialized
INFO - 2018-11-26 07:16:50 --> Hooks Class Initialized
DEBUG - 2018-11-26 07:16:50 --> UTF-8 Support Enabled
INFO - 2018-11-26 07:16:50 --> Utf8 Class Initialized
INFO - 2018-11-26 07:16:50 --> URI Class Initialized
INFO - 2018-11-26 07:16:50 --> Router Class Initialized
INFO - 2018-11-26 07:16:50 --> Output Class Initialized
INFO - 2018-11-26 07:16:50 --> Security Class Initialized
DEBUG - 2018-11-26 07:16:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-26 07:16:50 --> Input Class Initialized
INFO - 2018-11-26 07:16:50 --> Language Class Initialized
INFO - 2018-11-26 07:16:50 --> Loader Class Initialized
INFO - 2018-11-26 07:16:50 --> Helper loaded: url_helper
INFO - 2018-11-26 07:16:50 --> Helper loaded: file_helper
INFO - 2018-11-26 07:16:50 --> Helper loaded: email_helper
INFO - 2018-11-26 07:16:50 --> Helper loaded: common_helper
INFO - 2018-11-26 07:16:50 --> Database Driver Class Initialized
DEBUG - 2018-11-26 07:16:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-26 07:16:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-26 07:16:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-26 07:16:50 --> Pagination Class Initialized
INFO - 2018-11-26 07:16:50 --> Helper loaded: form_helper
INFO - 2018-11-26 07:16:50 --> Form Validation Class Initialized
INFO - 2018-11-26 07:16:50 --> Model Class Initialized
INFO - 2018-11-26 07:16:50 --> Controller Class Initialized
INFO - 2018-11-26 07:16:50 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-26 07:16:50 --> Model Class Initialized
INFO - 2018-11-26 07:16:50 --> Model Class Initialized
ERROR - 2018-11-26 07:16:50 --> Severity: Notice --> Undefined index: forgots_email C:\xampp\htdocs\wetinuneed\application\controllers\admin\Admin.php 163
INFO - 2018-11-26 07:16:50 --> Final output sent to browser
DEBUG - 2018-11-26 07:16:50 --> Total execution time: 0.0820
INFO - 2018-11-26 07:16:51 --> Config Class Initialized
INFO - 2018-11-26 07:16:51 --> Hooks Class Initialized
DEBUG - 2018-11-26 07:16:51 --> UTF-8 Support Enabled
INFO - 2018-11-26 07:16:51 --> Utf8 Class Initialized
INFO - 2018-11-26 07:16:51 --> URI Class Initialized
INFO - 2018-11-26 07:16:51 --> Router Class Initialized
INFO - 2018-11-26 07:16:51 --> Output Class Initialized
INFO - 2018-11-26 07:16:51 --> Security Class Initialized
DEBUG - 2018-11-26 07:16:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-26 07:16:51 --> Input Class Initialized
INFO - 2018-11-26 07:16:51 --> Language Class Initialized
INFO - 2018-11-26 07:16:51 --> Loader Class Initialized
INFO - 2018-11-26 07:16:51 --> Helper loaded: url_helper
INFO - 2018-11-26 07:16:51 --> Helper loaded: file_helper
INFO - 2018-11-26 07:16:51 --> Helper loaded: email_helper
INFO - 2018-11-26 07:16:51 --> Helper loaded: common_helper
INFO - 2018-11-26 07:16:51 --> Database Driver Class Initialized
DEBUG - 2018-11-26 07:16:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-26 07:16:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-26 07:16:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-26 07:16:51 --> Pagination Class Initialized
INFO - 2018-11-26 07:16:51 --> Helper loaded: form_helper
INFO - 2018-11-26 07:16:51 --> Form Validation Class Initialized
INFO - 2018-11-26 07:16:51 --> Model Class Initialized
INFO - 2018-11-26 07:16:51 --> Controller Class Initialized
INFO - 2018-11-26 07:16:51 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-26 07:16:51 --> Model Class Initialized
INFO - 2018-11-26 07:16:51 --> Model Class Initialized
ERROR - 2018-11-26 07:16:51 --> Severity: Notice --> Undefined index: forgots_email C:\xampp\htdocs\wetinuneed\application\controllers\admin\Admin.php 163
INFO - 2018-11-26 07:16:51 --> Final output sent to browser
DEBUG - 2018-11-26 07:16:51 --> Total execution time: 0.0650
INFO - 2018-11-26 07:16:51 --> Config Class Initialized
INFO - 2018-11-26 07:16:51 --> Hooks Class Initialized
DEBUG - 2018-11-26 07:16:51 --> UTF-8 Support Enabled
INFO - 2018-11-26 07:16:51 --> Utf8 Class Initialized
INFO - 2018-11-26 07:16:51 --> URI Class Initialized
INFO - 2018-11-26 07:16:51 --> Router Class Initialized
INFO - 2018-11-26 07:16:51 --> Output Class Initialized
INFO - 2018-11-26 07:16:51 --> Security Class Initialized
DEBUG - 2018-11-26 07:16:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-26 07:16:51 --> Input Class Initialized
INFO - 2018-11-26 07:16:51 --> Language Class Initialized
INFO - 2018-11-26 07:16:51 --> Loader Class Initialized
INFO - 2018-11-26 07:16:51 --> Helper loaded: url_helper
INFO - 2018-11-26 07:16:51 --> Helper loaded: file_helper
INFO - 2018-11-26 07:16:51 --> Helper loaded: email_helper
INFO - 2018-11-26 07:16:51 --> Helper loaded: common_helper
INFO - 2018-11-26 07:16:51 --> Database Driver Class Initialized
DEBUG - 2018-11-26 07:16:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-26 07:16:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-26 07:16:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-26 07:16:51 --> Pagination Class Initialized
INFO - 2018-11-26 07:16:51 --> Helper loaded: form_helper
INFO - 2018-11-26 07:16:51 --> Form Validation Class Initialized
INFO - 2018-11-26 07:16:51 --> Model Class Initialized
INFO - 2018-11-26 07:16:51 --> Controller Class Initialized
INFO - 2018-11-26 07:16:51 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-26 07:16:51 --> Model Class Initialized
INFO - 2018-11-26 07:16:51 --> Model Class Initialized
ERROR - 2018-11-26 07:16:51 --> Severity: Notice --> Undefined index: forgots_email C:\xampp\htdocs\wetinuneed\application\controllers\admin\Admin.php 163
INFO - 2018-11-26 07:16:51 --> Final output sent to browser
DEBUG - 2018-11-26 07:16:51 --> Total execution time: 0.0640
INFO - 2018-11-26 07:16:52 --> Config Class Initialized
INFO - 2018-11-26 07:16:52 --> Hooks Class Initialized
DEBUG - 2018-11-26 07:16:52 --> UTF-8 Support Enabled
INFO - 2018-11-26 07:16:52 --> Utf8 Class Initialized
INFO - 2018-11-26 07:16:52 --> URI Class Initialized
INFO - 2018-11-26 07:16:52 --> Router Class Initialized
INFO - 2018-11-26 07:16:52 --> Output Class Initialized
INFO - 2018-11-26 07:16:52 --> Security Class Initialized
DEBUG - 2018-11-26 07:16:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-26 07:16:52 --> Input Class Initialized
INFO - 2018-11-26 07:16:52 --> Language Class Initialized
INFO - 2018-11-26 07:16:52 --> Loader Class Initialized
INFO - 2018-11-26 07:16:52 --> Helper loaded: url_helper
INFO - 2018-11-26 07:16:52 --> Helper loaded: file_helper
INFO - 2018-11-26 07:16:52 --> Helper loaded: email_helper
INFO - 2018-11-26 07:16:52 --> Helper loaded: common_helper
INFO - 2018-11-26 07:16:52 --> Database Driver Class Initialized
DEBUG - 2018-11-26 07:16:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-26 07:16:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-26 07:16:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-26 07:16:52 --> Pagination Class Initialized
INFO - 2018-11-26 07:16:52 --> Helper loaded: form_helper
INFO - 2018-11-26 07:16:52 --> Form Validation Class Initialized
INFO - 2018-11-26 07:16:52 --> Model Class Initialized
INFO - 2018-11-26 07:16:52 --> Controller Class Initialized
INFO - 2018-11-26 07:16:52 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-26 07:16:52 --> Model Class Initialized
INFO - 2018-11-26 07:16:52 --> Model Class Initialized
ERROR - 2018-11-26 07:16:52 --> Severity: Notice --> Undefined index: forgots_email C:\xampp\htdocs\wetinuneed\application\controllers\admin\Admin.php 163
INFO - 2018-11-26 07:16:52 --> Final output sent to browser
DEBUG - 2018-11-26 07:16:52 --> Total execution time: 0.0650
INFO - 2018-11-26 07:16:52 --> Config Class Initialized
INFO - 2018-11-26 07:16:52 --> Hooks Class Initialized
DEBUG - 2018-11-26 07:16:52 --> UTF-8 Support Enabled
INFO - 2018-11-26 07:16:52 --> Utf8 Class Initialized
INFO - 2018-11-26 07:16:52 --> URI Class Initialized
INFO - 2018-11-26 07:16:52 --> Router Class Initialized
INFO - 2018-11-26 07:16:52 --> Output Class Initialized
INFO - 2018-11-26 07:16:52 --> Security Class Initialized
DEBUG - 2018-11-26 07:16:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-26 07:16:52 --> Input Class Initialized
INFO - 2018-11-26 07:16:52 --> Language Class Initialized
INFO - 2018-11-26 07:16:52 --> Loader Class Initialized
INFO - 2018-11-26 07:16:52 --> Helper loaded: url_helper
INFO - 2018-11-26 07:16:52 --> Helper loaded: file_helper
INFO - 2018-11-26 07:16:52 --> Helper loaded: email_helper
INFO - 2018-11-26 07:16:52 --> Helper loaded: common_helper
INFO - 2018-11-26 07:16:52 --> Database Driver Class Initialized
DEBUG - 2018-11-26 07:16:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-26 07:16:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-26 07:16:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-26 07:16:52 --> Pagination Class Initialized
INFO - 2018-11-26 07:16:52 --> Helper loaded: form_helper
INFO - 2018-11-26 07:16:52 --> Form Validation Class Initialized
INFO - 2018-11-26 07:16:52 --> Model Class Initialized
INFO - 2018-11-26 07:16:52 --> Controller Class Initialized
INFO - 2018-11-26 07:16:52 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-26 07:16:52 --> Model Class Initialized
INFO - 2018-11-26 07:16:52 --> Model Class Initialized
ERROR - 2018-11-26 07:16:52 --> Severity: Notice --> Undefined index: forgots_email C:\xampp\htdocs\wetinuneed\application\controllers\admin\Admin.php 163
INFO - 2018-11-26 07:16:52 --> Final output sent to browser
DEBUG - 2018-11-26 07:16:52 --> Total execution time: 0.0640
INFO - 2018-11-26 07:16:52 --> Config Class Initialized
INFO - 2018-11-26 07:16:52 --> Hooks Class Initialized
DEBUG - 2018-11-26 07:16:52 --> UTF-8 Support Enabled
INFO - 2018-11-26 07:16:52 --> Utf8 Class Initialized
INFO - 2018-11-26 07:16:52 --> URI Class Initialized
INFO - 2018-11-26 07:16:52 --> Router Class Initialized
INFO - 2018-11-26 07:16:53 --> Output Class Initialized
INFO - 2018-11-26 07:16:53 --> Security Class Initialized
DEBUG - 2018-11-26 07:16:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-26 07:16:53 --> Input Class Initialized
INFO - 2018-11-26 07:16:53 --> Language Class Initialized
INFO - 2018-11-26 07:16:53 --> Loader Class Initialized
INFO - 2018-11-26 07:16:53 --> Helper loaded: url_helper
INFO - 2018-11-26 07:16:53 --> Helper loaded: file_helper
INFO - 2018-11-26 07:16:53 --> Helper loaded: email_helper
INFO - 2018-11-26 07:16:53 --> Helper loaded: common_helper
INFO - 2018-11-26 07:16:53 --> Database Driver Class Initialized
DEBUG - 2018-11-26 07:16:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-26 07:16:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-26 07:16:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-26 07:16:53 --> Pagination Class Initialized
INFO - 2018-11-26 07:16:53 --> Helper loaded: form_helper
INFO - 2018-11-26 07:16:53 --> Form Validation Class Initialized
INFO - 2018-11-26 07:16:53 --> Model Class Initialized
INFO - 2018-11-26 07:16:53 --> Controller Class Initialized
INFO - 2018-11-26 07:16:53 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-26 07:16:53 --> Model Class Initialized
INFO - 2018-11-26 07:16:53 --> Model Class Initialized
ERROR - 2018-11-26 07:16:53 --> Severity: Notice --> Undefined index: forgots_email C:\xampp\htdocs\wetinuneed\application\controllers\admin\Admin.php 163
INFO - 2018-11-26 07:16:53 --> Final output sent to browser
DEBUG - 2018-11-26 07:16:53 --> Total execution time: 0.0690
INFO - 2018-11-26 07:16:53 --> Config Class Initialized
INFO - 2018-11-26 07:16:53 --> Hooks Class Initialized
DEBUG - 2018-11-26 07:16:53 --> UTF-8 Support Enabled
INFO - 2018-11-26 07:16:53 --> Utf8 Class Initialized
INFO - 2018-11-26 07:16:53 --> URI Class Initialized
INFO - 2018-11-26 07:16:53 --> Router Class Initialized
INFO - 2018-11-26 07:16:53 --> Output Class Initialized
INFO - 2018-11-26 07:16:53 --> Security Class Initialized
DEBUG - 2018-11-26 07:16:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-26 07:16:53 --> Input Class Initialized
INFO - 2018-11-26 07:16:53 --> Language Class Initialized
INFO - 2018-11-26 07:16:53 --> Loader Class Initialized
INFO - 2018-11-26 07:16:53 --> Helper loaded: url_helper
INFO - 2018-11-26 07:16:53 --> Helper loaded: file_helper
INFO - 2018-11-26 07:16:53 --> Helper loaded: email_helper
INFO - 2018-11-26 07:16:53 --> Helper loaded: common_helper
INFO - 2018-11-26 07:16:53 --> Database Driver Class Initialized
DEBUG - 2018-11-26 07:16:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-26 07:16:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-26 07:16:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-26 07:16:53 --> Pagination Class Initialized
INFO - 2018-11-26 07:16:53 --> Helper loaded: form_helper
INFO - 2018-11-26 07:16:53 --> Form Validation Class Initialized
INFO - 2018-11-26 07:16:53 --> Model Class Initialized
INFO - 2018-11-26 07:16:53 --> Controller Class Initialized
INFO - 2018-11-26 07:16:53 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-26 07:16:53 --> Model Class Initialized
INFO - 2018-11-26 07:16:53 --> Model Class Initialized
ERROR - 2018-11-26 07:16:53 --> Severity: Notice --> Undefined index: forgots_email C:\xampp\htdocs\wetinuneed\application\controllers\admin\Admin.php 163
INFO - 2018-11-26 07:16:53 --> Final output sent to browser
DEBUG - 2018-11-26 07:16:53 --> Total execution time: 0.0700
INFO - 2018-11-26 07:17:19 --> Config Class Initialized
INFO - 2018-11-26 07:17:19 --> Hooks Class Initialized
DEBUG - 2018-11-26 07:17:19 --> UTF-8 Support Enabled
INFO - 2018-11-26 07:17:19 --> Utf8 Class Initialized
INFO - 2018-11-26 07:17:19 --> URI Class Initialized
INFO - 2018-11-26 07:17:19 --> Router Class Initialized
INFO - 2018-11-26 07:17:19 --> Output Class Initialized
INFO - 2018-11-26 07:17:19 --> Security Class Initialized
DEBUG - 2018-11-26 07:17:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-26 07:17:19 --> Input Class Initialized
INFO - 2018-11-26 07:17:19 --> Language Class Initialized
INFO - 2018-11-26 07:17:19 --> Loader Class Initialized
INFO - 2018-11-26 07:17:19 --> Helper loaded: url_helper
INFO - 2018-11-26 07:17:19 --> Helper loaded: file_helper
INFO - 2018-11-26 07:17:19 --> Helper loaded: email_helper
INFO - 2018-11-26 07:17:19 --> Helper loaded: common_helper
INFO - 2018-11-26 07:17:19 --> Database Driver Class Initialized
DEBUG - 2018-11-26 07:17:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-26 07:17:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-26 07:17:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-26 07:17:19 --> Pagination Class Initialized
INFO - 2018-11-26 07:17:19 --> Helper loaded: form_helper
INFO - 2018-11-26 07:17:19 --> Form Validation Class Initialized
INFO - 2018-11-26 07:17:19 --> Model Class Initialized
INFO - 2018-11-26 07:17:19 --> Controller Class Initialized
INFO - 2018-11-26 07:17:19 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-26 07:17:19 --> Model Class Initialized
INFO - 2018-11-26 07:17:19 --> Model Class Initialized
INFO - 2018-11-26 07:17:19 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/index.php
INFO - 2018-11-26 07:17:19 --> Final output sent to browser
DEBUG - 2018-11-26 07:17:19 --> Total execution time: 0.1090
INFO - 2018-11-26 07:17:27 --> Config Class Initialized
INFO - 2018-11-26 07:17:27 --> Hooks Class Initialized
DEBUG - 2018-11-26 07:17:27 --> UTF-8 Support Enabled
INFO - 2018-11-26 07:17:27 --> Utf8 Class Initialized
INFO - 2018-11-26 07:17:27 --> URI Class Initialized
INFO - 2018-11-26 07:17:27 --> Router Class Initialized
INFO - 2018-11-26 07:17:27 --> Output Class Initialized
INFO - 2018-11-26 07:17:27 --> Security Class Initialized
DEBUG - 2018-11-26 07:17:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-26 07:17:27 --> Input Class Initialized
INFO - 2018-11-26 07:17:27 --> Language Class Initialized
INFO - 2018-11-26 07:17:27 --> Loader Class Initialized
INFO - 2018-11-26 07:17:27 --> Helper loaded: url_helper
INFO - 2018-11-26 07:17:27 --> Helper loaded: file_helper
INFO - 2018-11-26 07:17:27 --> Helper loaded: email_helper
INFO - 2018-11-26 07:17:27 --> Helper loaded: common_helper
INFO - 2018-11-26 07:17:27 --> Database Driver Class Initialized
DEBUG - 2018-11-26 07:17:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-26 07:17:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-26 07:17:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-26 07:17:27 --> Pagination Class Initialized
INFO - 2018-11-26 07:17:27 --> Helper loaded: form_helper
INFO - 2018-11-26 07:17:27 --> Form Validation Class Initialized
INFO - 2018-11-26 07:17:27 --> Model Class Initialized
INFO - 2018-11-26 07:17:27 --> Controller Class Initialized
INFO - 2018-11-26 07:17:27 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-26 07:17:27 --> Model Class Initialized
INFO - 2018-11-26 07:17:27 --> Model Class Initialized
INFO - 2018-11-26 07:17:27 --> Final output sent to browser
DEBUG - 2018-11-26 07:17:27 --> Total execution time: 0.0660
INFO - 2018-11-26 07:17:28 --> Config Class Initialized
INFO - 2018-11-26 07:17:28 --> Hooks Class Initialized
DEBUG - 2018-11-26 07:17:28 --> UTF-8 Support Enabled
INFO - 2018-11-26 07:17:28 --> Utf8 Class Initialized
INFO - 2018-11-26 07:17:28 --> URI Class Initialized
INFO - 2018-11-26 07:17:28 --> Router Class Initialized
INFO - 2018-11-26 07:17:28 --> Output Class Initialized
INFO - 2018-11-26 07:17:28 --> Security Class Initialized
DEBUG - 2018-11-26 07:17:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-26 07:17:28 --> Input Class Initialized
INFO - 2018-11-26 07:17:28 --> Language Class Initialized
INFO - 2018-11-26 07:17:28 --> Loader Class Initialized
INFO - 2018-11-26 07:17:28 --> Helper loaded: url_helper
INFO - 2018-11-26 07:17:28 --> Helper loaded: file_helper
INFO - 2018-11-26 07:17:28 --> Helper loaded: email_helper
INFO - 2018-11-26 07:17:28 --> Helper loaded: common_helper
INFO - 2018-11-26 07:17:28 --> Database Driver Class Initialized
DEBUG - 2018-11-26 07:17:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-26 07:17:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-26 07:17:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-26 07:17:28 --> Pagination Class Initialized
INFO - 2018-11-26 07:17:28 --> Helper loaded: form_helper
INFO - 2018-11-26 07:17:28 --> Form Validation Class Initialized
INFO - 2018-11-26 07:17:28 --> Model Class Initialized
INFO - 2018-11-26 07:17:28 --> Controller Class Initialized
INFO - 2018-11-26 07:17:28 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-26 07:17:28 --> Model Class Initialized
INFO - 2018-11-26 07:17:28 --> Model Class Initialized
INFO - 2018-11-26 07:17:28 --> Final output sent to browser
DEBUG - 2018-11-26 07:17:28 --> Total execution time: 0.0750
INFO - 2018-11-26 07:17:29 --> Config Class Initialized
INFO - 2018-11-26 07:17:29 --> Hooks Class Initialized
DEBUG - 2018-11-26 07:17:29 --> UTF-8 Support Enabled
INFO - 2018-11-26 07:17:29 --> Utf8 Class Initialized
INFO - 2018-11-26 07:17:29 --> URI Class Initialized
INFO - 2018-11-26 07:17:29 --> Router Class Initialized
INFO - 2018-11-26 07:17:29 --> Output Class Initialized
INFO - 2018-11-26 07:17:29 --> Security Class Initialized
DEBUG - 2018-11-26 07:17:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-26 07:17:29 --> Input Class Initialized
INFO - 2018-11-26 07:17:29 --> Language Class Initialized
INFO - 2018-11-26 07:17:29 --> Loader Class Initialized
INFO - 2018-11-26 07:17:29 --> Helper loaded: url_helper
INFO - 2018-11-26 07:17:29 --> Helper loaded: file_helper
INFO - 2018-11-26 07:17:29 --> Helper loaded: email_helper
INFO - 2018-11-26 07:17:29 --> Helper loaded: common_helper
INFO - 2018-11-26 07:17:29 --> Database Driver Class Initialized
DEBUG - 2018-11-26 07:17:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-26 07:17:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-26 07:17:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-26 07:17:29 --> Pagination Class Initialized
INFO - 2018-11-26 07:17:29 --> Helper loaded: form_helper
INFO - 2018-11-26 07:17:29 --> Form Validation Class Initialized
INFO - 2018-11-26 07:17:29 --> Model Class Initialized
INFO - 2018-11-26 07:17:29 --> Controller Class Initialized
INFO - 2018-11-26 07:17:29 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-26 07:17:29 --> Model Class Initialized
INFO - 2018-11-26 07:17:29 --> Model Class Initialized
INFO - 2018-11-26 07:17:29 --> Final output sent to browser
DEBUG - 2018-11-26 07:17:29 --> Total execution time: 0.0750
INFO - 2018-11-26 07:17:30 --> Config Class Initialized
INFO - 2018-11-26 07:17:30 --> Hooks Class Initialized
DEBUG - 2018-11-26 07:17:30 --> UTF-8 Support Enabled
INFO - 2018-11-26 07:17:30 --> Utf8 Class Initialized
INFO - 2018-11-26 07:17:30 --> URI Class Initialized
INFO - 2018-11-26 07:17:30 --> Router Class Initialized
INFO - 2018-11-26 07:17:30 --> Output Class Initialized
INFO - 2018-11-26 07:17:30 --> Security Class Initialized
DEBUG - 2018-11-26 07:17:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-26 07:17:30 --> Input Class Initialized
INFO - 2018-11-26 07:17:30 --> Language Class Initialized
INFO - 2018-11-26 07:17:30 --> Loader Class Initialized
INFO - 2018-11-26 07:17:30 --> Helper loaded: url_helper
INFO - 2018-11-26 07:17:30 --> Helper loaded: file_helper
INFO - 2018-11-26 07:17:30 --> Helper loaded: email_helper
INFO - 2018-11-26 07:17:30 --> Helper loaded: common_helper
INFO - 2018-11-26 07:17:30 --> Database Driver Class Initialized
DEBUG - 2018-11-26 07:17:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-26 07:17:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-26 07:17:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-26 07:17:30 --> Pagination Class Initialized
INFO - 2018-11-26 07:17:30 --> Helper loaded: form_helper
INFO - 2018-11-26 07:17:30 --> Form Validation Class Initialized
INFO - 2018-11-26 07:17:30 --> Model Class Initialized
INFO - 2018-11-26 07:17:30 --> Controller Class Initialized
INFO - 2018-11-26 07:17:30 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-26 07:17:30 --> Model Class Initialized
INFO - 2018-11-26 07:17:30 --> Model Class Initialized
INFO - 2018-11-26 07:17:30 --> Final output sent to browser
DEBUG - 2018-11-26 07:17:30 --> Total execution time: 0.0770
INFO - 2018-11-26 07:17:31 --> Config Class Initialized
INFO - 2018-11-26 07:17:31 --> Hooks Class Initialized
DEBUG - 2018-11-26 07:17:31 --> UTF-8 Support Enabled
INFO - 2018-11-26 07:17:31 --> Utf8 Class Initialized
INFO - 2018-11-26 07:17:31 --> URI Class Initialized
INFO - 2018-11-26 07:17:31 --> Router Class Initialized
INFO - 2018-11-26 07:17:31 --> Output Class Initialized
INFO - 2018-11-26 07:17:31 --> Security Class Initialized
DEBUG - 2018-11-26 07:17:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-26 07:17:31 --> Input Class Initialized
INFO - 2018-11-26 07:17:31 --> Language Class Initialized
INFO - 2018-11-26 07:17:31 --> Loader Class Initialized
INFO - 2018-11-26 07:17:31 --> Helper loaded: url_helper
INFO - 2018-11-26 07:17:31 --> Helper loaded: file_helper
INFO - 2018-11-26 07:17:31 --> Helper loaded: email_helper
INFO - 2018-11-26 07:17:31 --> Helper loaded: common_helper
INFO - 2018-11-26 07:17:31 --> Database Driver Class Initialized
DEBUG - 2018-11-26 07:17:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-26 07:17:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-26 07:17:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-26 07:17:31 --> Pagination Class Initialized
INFO - 2018-11-26 07:17:31 --> Helper loaded: form_helper
INFO - 2018-11-26 07:17:31 --> Form Validation Class Initialized
INFO - 2018-11-26 07:17:31 --> Model Class Initialized
INFO - 2018-11-26 07:17:31 --> Controller Class Initialized
INFO - 2018-11-26 07:17:31 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-26 07:17:31 --> Model Class Initialized
INFO - 2018-11-26 07:17:31 --> Model Class Initialized
INFO - 2018-11-26 07:17:31 --> Final output sent to browser
DEBUG - 2018-11-26 07:17:31 --> Total execution time: 0.0750
INFO - 2018-11-26 07:17:31 --> Config Class Initialized
INFO - 2018-11-26 07:17:31 --> Hooks Class Initialized
DEBUG - 2018-11-26 07:17:31 --> UTF-8 Support Enabled
INFO - 2018-11-26 07:17:31 --> Utf8 Class Initialized
INFO - 2018-11-26 07:17:31 --> URI Class Initialized
INFO - 2018-11-26 07:17:31 --> Router Class Initialized
INFO - 2018-11-26 07:17:31 --> Output Class Initialized
INFO - 2018-11-26 07:17:31 --> Security Class Initialized
DEBUG - 2018-11-26 07:17:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-26 07:17:31 --> Input Class Initialized
INFO - 2018-11-26 07:17:31 --> Language Class Initialized
INFO - 2018-11-26 07:17:31 --> Loader Class Initialized
INFO - 2018-11-26 07:17:31 --> Helper loaded: url_helper
INFO - 2018-11-26 07:17:31 --> Helper loaded: file_helper
INFO - 2018-11-26 07:17:31 --> Helper loaded: email_helper
INFO - 2018-11-26 07:17:31 --> Helper loaded: common_helper
INFO - 2018-11-26 07:17:31 --> Database Driver Class Initialized
DEBUG - 2018-11-26 07:17:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-26 07:17:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-26 07:17:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-26 07:17:31 --> Pagination Class Initialized
INFO - 2018-11-26 07:17:31 --> Helper loaded: form_helper
INFO - 2018-11-26 07:17:31 --> Form Validation Class Initialized
INFO - 2018-11-26 07:17:31 --> Model Class Initialized
INFO - 2018-11-26 07:17:31 --> Controller Class Initialized
INFO - 2018-11-26 07:17:31 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-26 07:17:31 --> Model Class Initialized
INFO - 2018-11-26 07:17:31 --> Model Class Initialized
INFO - 2018-11-26 07:17:31 --> Final output sent to browser
DEBUG - 2018-11-26 07:17:31 --> Total execution time: 0.0840
INFO - 2018-11-26 07:17:32 --> Config Class Initialized
INFO - 2018-11-26 07:17:32 --> Hooks Class Initialized
DEBUG - 2018-11-26 07:17:32 --> UTF-8 Support Enabled
INFO - 2018-11-26 07:17:32 --> Utf8 Class Initialized
INFO - 2018-11-26 07:17:32 --> URI Class Initialized
INFO - 2018-11-26 07:17:32 --> Router Class Initialized
INFO - 2018-11-26 07:17:32 --> Output Class Initialized
INFO - 2018-11-26 07:17:32 --> Security Class Initialized
DEBUG - 2018-11-26 07:17:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-26 07:17:32 --> Input Class Initialized
INFO - 2018-11-26 07:17:32 --> Language Class Initialized
INFO - 2018-11-26 07:17:32 --> Loader Class Initialized
INFO - 2018-11-26 07:17:32 --> Helper loaded: url_helper
INFO - 2018-11-26 07:17:32 --> Helper loaded: file_helper
INFO - 2018-11-26 07:17:32 --> Helper loaded: email_helper
INFO - 2018-11-26 07:17:32 --> Helper loaded: common_helper
INFO - 2018-11-26 07:17:32 --> Database Driver Class Initialized
DEBUG - 2018-11-26 07:17:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-26 07:17:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-26 07:17:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-26 07:17:32 --> Pagination Class Initialized
INFO - 2018-11-26 07:17:32 --> Helper loaded: form_helper
INFO - 2018-11-26 07:17:32 --> Form Validation Class Initialized
INFO - 2018-11-26 07:17:32 --> Model Class Initialized
INFO - 2018-11-26 07:17:32 --> Controller Class Initialized
INFO - 2018-11-26 07:17:32 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-26 07:17:32 --> Model Class Initialized
INFO - 2018-11-26 07:17:32 --> Model Class Initialized
INFO - 2018-11-26 07:17:32 --> Final output sent to browser
DEBUG - 2018-11-26 07:17:32 --> Total execution time: 0.0700
INFO - 2018-11-26 07:19:53 --> Config Class Initialized
INFO - 2018-11-26 07:19:53 --> Hooks Class Initialized
DEBUG - 2018-11-26 07:19:53 --> UTF-8 Support Enabled
INFO - 2018-11-26 07:19:53 --> Utf8 Class Initialized
INFO - 2018-11-26 07:19:53 --> URI Class Initialized
INFO - 2018-11-26 07:19:53 --> Router Class Initialized
INFO - 2018-11-26 07:19:53 --> Output Class Initialized
INFO - 2018-11-26 07:19:53 --> Security Class Initialized
DEBUG - 2018-11-26 07:19:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-26 07:19:53 --> Input Class Initialized
INFO - 2018-11-26 07:19:53 --> Language Class Initialized
INFO - 2018-11-26 07:19:53 --> Loader Class Initialized
INFO - 2018-11-26 07:19:53 --> Helper loaded: url_helper
INFO - 2018-11-26 07:19:53 --> Helper loaded: file_helper
INFO - 2018-11-26 07:19:53 --> Helper loaded: email_helper
INFO - 2018-11-26 07:19:53 --> Helper loaded: common_helper
INFO - 2018-11-26 07:19:53 --> Database Driver Class Initialized
DEBUG - 2018-11-26 07:19:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-26 07:19:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-26 07:19:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-26 07:19:53 --> Pagination Class Initialized
INFO - 2018-11-26 07:19:53 --> Helper loaded: form_helper
INFO - 2018-11-26 07:19:53 --> Form Validation Class Initialized
INFO - 2018-11-26 07:19:53 --> Model Class Initialized
INFO - 2018-11-26 07:19:53 --> Controller Class Initialized
INFO - 2018-11-26 07:19:53 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-26 07:19:53 --> Model Class Initialized
INFO - 2018-11-26 07:19:53 --> Model Class Initialized
INFO - 2018-11-26 07:19:53 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/index.php
INFO - 2018-11-26 07:19:53 --> Final output sent to browser
DEBUG - 2018-11-26 07:19:53 --> Total execution time: 0.0740
INFO - 2018-11-26 07:20:01 --> Config Class Initialized
INFO - 2018-11-26 07:20:01 --> Hooks Class Initialized
DEBUG - 2018-11-26 07:20:01 --> UTF-8 Support Enabled
INFO - 2018-11-26 07:20:01 --> Utf8 Class Initialized
INFO - 2018-11-26 07:20:01 --> URI Class Initialized
INFO - 2018-11-26 07:20:01 --> Router Class Initialized
INFO - 2018-11-26 07:20:01 --> Output Class Initialized
INFO - 2018-11-26 07:20:01 --> Security Class Initialized
DEBUG - 2018-11-26 07:20:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-26 07:20:01 --> Input Class Initialized
INFO - 2018-11-26 07:20:01 --> Language Class Initialized
INFO - 2018-11-26 07:20:01 --> Loader Class Initialized
INFO - 2018-11-26 07:20:01 --> Helper loaded: url_helper
INFO - 2018-11-26 07:20:01 --> Helper loaded: file_helper
INFO - 2018-11-26 07:20:01 --> Helper loaded: email_helper
INFO - 2018-11-26 07:20:01 --> Helper loaded: common_helper
INFO - 2018-11-26 07:20:01 --> Database Driver Class Initialized
DEBUG - 2018-11-26 07:20:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-26 07:20:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-26 07:20:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-26 07:20:01 --> Pagination Class Initialized
INFO - 2018-11-26 07:20:01 --> Helper loaded: form_helper
INFO - 2018-11-26 07:20:01 --> Form Validation Class Initialized
INFO - 2018-11-26 07:20:01 --> Model Class Initialized
INFO - 2018-11-26 07:20:01 --> Controller Class Initialized
INFO - 2018-11-26 07:20:01 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-26 07:20:01 --> Model Class Initialized
INFO - 2018-11-26 07:20:01 --> Model Class Initialized
INFO - 2018-11-26 07:20:01 --> Final output sent to browser
DEBUG - 2018-11-26 07:20:01 --> Total execution time: 0.0730
INFO - 2018-11-26 07:20:02 --> Config Class Initialized
INFO - 2018-11-26 07:20:02 --> Hooks Class Initialized
DEBUG - 2018-11-26 07:20:02 --> UTF-8 Support Enabled
INFO - 2018-11-26 07:20:02 --> Utf8 Class Initialized
INFO - 2018-11-26 07:20:02 --> URI Class Initialized
INFO - 2018-11-26 07:20:02 --> Router Class Initialized
INFO - 2018-11-26 07:20:02 --> Output Class Initialized
INFO - 2018-11-26 07:20:02 --> Security Class Initialized
DEBUG - 2018-11-26 07:20:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-26 07:20:02 --> Input Class Initialized
INFO - 2018-11-26 07:20:02 --> Language Class Initialized
INFO - 2018-11-26 07:20:02 --> Loader Class Initialized
INFO - 2018-11-26 07:20:02 --> Helper loaded: url_helper
INFO - 2018-11-26 07:20:02 --> Helper loaded: file_helper
INFO - 2018-11-26 07:20:02 --> Helper loaded: email_helper
INFO - 2018-11-26 07:20:02 --> Helper loaded: common_helper
INFO - 2018-11-26 07:20:02 --> Database Driver Class Initialized
DEBUG - 2018-11-26 07:20:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-26 07:20:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-26 07:20:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-26 07:20:02 --> Pagination Class Initialized
INFO - 2018-11-26 07:20:02 --> Helper loaded: form_helper
INFO - 2018-11-26 07:20:02 --> Form Validation Class Initialized
INFO - 2018-11-26 07:20:02 --> Model Class Initialized
INFO - 2018-11-26 07:20:02 --> Controller Class Initialized
INFO - 2018-11-26 07:20:02 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-26 07:20:02 --> Model Class Initialized
INFO - 2018-11-26 07:20:02 --> Model Class Initialized
INFO - 2018-11-26 07:20:02 --> Final output sent to browser
DEBUG - 2018-11-26 07:20:02 --> Total execution time: 0.0740
INFO - 2018-11-26 07:20:03 --> Config Class Initialized
INFO - 2018-11-26 07:20:03 --> Hooks Class Initialized
DEBUG - 2018-11-26 07:20:03 --> UTF-8 Support Enabled
INFO - 2018-11-26 07:20:03 --> Utf8 Class Initialized
INFO - 2018-11-26 07:20:03 --> URI Class Initialized
INFO - 2018-11-26 07:20:03 --> Router Class Initialized
INFO - 2018-11-26 07:20:03 --> Output Class Initialized
INFO - 2018-11-26 07:20:03 --> Security Class Initialized
DEBUG - 2018-11-26 07:20:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-26 07:20:03 --> Input Class Initialized
INFO - 2018-11-26 07:20:03 --> Language Class Initialized
INFO - 2018-11-26 07:20:03 --> Loader Class Initialized
INFO - 2018-11-26 07:20:03 --> Helper loaded: url_helper
INFO - 2018-11-26 07:20:03 --> Helper loaded: file_helper
INFO - 2018-11-26 07:20:03 --> Helper loaded: email_helper
INFO - 2018-11-26 07:20:03 --> Helper loaded: common_helper
INFO - 2018-11-26 07:20:03 --> Database Driver Class Initialized
DEBUG - 2018-11-26 07:20:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-26 07:20:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-26 07:20:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-26 07:20:03 --> Pagination Class Initialized
INFO - 2018-11-26 07:20:03 --> Helper loaded: form_helper
INFO - 2018-11-26 07:20:03 --> Form Validation Class Initialized
INFO - 2018-11-26 07:20:03 --> Model Class Initialized
INFO - 2018-11-26 07:20:03 --> Controller Class Initialized
INFO - 2018-11-26 07:20:03 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-26 07:20:03 --> Model Class Initialized
INFO - 2018-11-26 07:20:03 --> Model Class Initialized
INFO - 2018-11-26 07:20:03 --> Final output sent to browser
DEBUG - 2018-11-26 07:20:03 --> Total execution time: 0.0680
INFO - 2018-11-26 07:20:04 --> Config Class Initialized
INFO - 2018-11-26 07:20:04 --> Hooks Class Initialized
DEBUG - 2018-11-26 07:20:04 --> UTF-8 Support Enabled
INFO - 2018-11-26 07:20:04 --> Utf8 Class Initialized
INFO - 2018-11-26 07:20:04 --> URI Class Initialized
INFO - 2018-11-26 07:20:04 --> Router Class Initialized
INFO - 2018-11-26 07:20:04 --> Output Class Initialized
INFO - 2018-11-26 07:20:04 --> Security Class Initialized
DEBUG - 2018-11-26 07:20:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-26 07:20:04 --> Input Class Initialized
INFO - 2018-11-26 07:20:04 --> Language Class Initialized
INFO - 2018-11-26 07:20:04 --> Loader Class Initialized
INFO - 2018-11-26 07:20:04 --> Helper loaded: url_helper
INFO - 2018-11-26 07:20:04 --> Helper loaded: file_helper
INFO - 2018-11-26 07:20:04 --> Helper loaded: email_helper
INFO - 2018-11-26 07:20:04 --> Helper loaded: common_helper
INFO - 2018-11-26 07:20:04 --> Database Driver Class Initialized
DEBUG - 2018-11-26 07:20:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-26 07:20:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-26 07:20:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-26 07:20:04 --> Pagination Class Initialized
INFO - 2018-11-26 07:20:04 --> Helper loaded: form_helper
INFO - 2018-11-26 07:20:04 --> Form Validation Class Initialized
INFO - 2018-11-26 07:20:04 --> Model Class Initialized
INFO - 2018-11-26 07:20:04 --> Controller Class Initialized
INFO - 2018-11-26 07:20:04 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-26 07:20:04 --> Model Class Initialized
INFO - 2018-11-26 07:20:04 --> Model Class Initialized
INFO - 2018-11-26 07:20:04 --> Final output sent to browser
DEBUG - 2018-11-26 07:20:04 --> Total execution time: 0.0690
INFO - 2018-11-26 07:20:05 --> Config Class Initialized
INFO - 2018-11-26 07:20:05 --> Hooks Class Initialized
DEBUG - 2018-11-26 07:20:05 --> UTF-8 Support Enabled
INFO - 2018-11-26 07:20:05 --> Utf8 Class Initialized
INFO - 2018-11-26 07:20:05 --> URI Class Initialized
INFO - 2018-11-26 07:20:05 --> Router Class Initialized
INFO - 2018-11-26 07:20:05 --> Output Class Initialized
INFO - 2018-11-26 07:20:05 --> Security Class Initialized
DEBUG - 2018-11-26 07:20:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-26 07:20:05 --> Input Class Initialized
INFO - 2018-11-26 07:20:05 --> Language Class Initialized
INFO - 2018-11-26 07:20:05 --> Loader Class Initialized
INFO - 2018-11-26 07:20:05 --> Helper loaded: url_helper
INFO - 2018-11-26 07:20:05 --> Helper loaded: file_helper
INFO - 2018-11-26 07:20:05 --> Helper loaded: email_helper
INFO - 2018-11-26 07:20:05 --> Helper loaded: common_helper
INFO - 2018-11-26 07:20:05 --> Database Driver Class Initialized
DEBUG - 2018-11-26 07:20:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-26 07:20:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-26 07:20:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-26 07:20:05 --> Pagination Class Initialized
INFO - 2018-11-26 07:20:05 --> Helper loaded: form_helper
INFO - 2018-11-26 07:20:05 --> Form Validation Class Initialized
INFO - 2018-11-26 07:20:05 --> Model Class Initialized
INFO - 2018-11-26 07:20:05 --> Controller Class Initialized
INFO - 2018-11-26 07:20:05 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-26 07:20:05 --> Model Class Initialized
INFO - 2018-11-26 07:20:05 --> Model Class Initialized
INFO - 2018-11-26 07:20:05 --> Final output sent to browser
DEBUG - 2018-11-26 07:20:05 --> Total execution time: 0.0790
INFO - 2018-11-26 07:20:05 --> Config Class Initialized
INFO - 2018-11-26 07:20:05 --> Hooks Class Initialized
DEBUG - 2018-11-26 07:20:05 --> UTF-8 Support Enabled
INFO - 2018-11-26 07:20:05 --> Utf8 Class Initialized
INFO - 2018-11-26 07:20:05 --> URI Class Initialized
INFO - 2018-11-26 07:20:05 --> Router Class Initialized
INFO - 2018-11-26 07:20:05 --> Output Class Initialized
INFO - 2018-11-26 07:20:05 --> Security Class Initialized
DEBUG - 2018-11-26 07:20:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-26 07:20:05 --> Input Class Initialized
INFO - 2018-11-26 07:20:05 --> Language Class Initialized
INFO - 2018-11-26 07:20:05 --> Loader Class Initialized
INFO - 2018-11-26 07:20:05 --> Helper loaded: url_helper
INFO - 2018-11-26 07:20:05 --> Helper loaded: file_helper
INFO - 2018-11-26 07:20:05 --> Helper loaded: email_helper
INFO - 2018-11-26 07:20:05 --> Helper loaded: common_helper
INFO - 2018-11-26 07:20:05 --> Database Driver Class Initialized
DEBUG - 2018-11-26 07:20:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-26 07:20:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-26 07:20:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-26 07:20:05 --> Pagination Class Initialized
INFO - 2018-11-26 07:20:05 --> Helper loaded: form_helper
INFO - 2018-11-26 07:20:05 --> Form Validation Class Initialized
INFO - 2018-11-26 07:20:05 --> Model Class Initialized
INFO - 2018-11-26 07:20:05 --> Controller Class Initialized
INFO - 2018-11-26 07:20:05 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-26 07:20:05 --> Model Class Initialized
INFO - 2018-11-26 07:20:05 --> Model Class Initialized
INFO - 2018-11-26 07:20:05 --> Final output sent to browser
DEBUG - 2018-11-26 07:20:05 --> Total execution time: 0.0740
INFO - 2018-11-26 07:20:06 --> Config Class Initialized
INFO - 2018-11-26 07:20:06 --> Hooks Class Initialized
DEBUG - 2018-11-26 07:20:06 --> UTF-8 Support Enabled
INFO - 2018-11-26 07:20:06 --> Utf8 Class Initialized
INFO - 2018-11-26 07:20:06 --> URI Class Initialized
INFO - 2018-11-26 07:20:06 --> Router Class Initialized
INFO - 2018-11-26 07:20:06 --> Output Class Initialized
INFO - 2018-11-26 07:20:06 --> Security Class Initialized
DEBUG - 2018-11-26 07:20:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-26 07:20:06 --> Input Class Initialized
INFO - 2018-11-26 07:20:06 --> Language Class Initialized
INFO - 2018-11-26 07:20:06 --> Loader Class Initialized
INFO - 2018-11-26 07:20:06 --> Helper loaded: url_helper
INFO - 2018-11-26 07:20:06 --> Helper loaded: file_helper
INFO - 2018-11-26 07:20:06 --> Helper loaded: email_helper
INFO - 2018-11-26 07:20:06 --> Helper loaded: common_helper
INFO - 2018-11-26 07:20:06 --> Database Driver Class Initialized
DEBUG - 2018-11-26 07:20:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-26 07:20:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-26 07:20:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-26 07:20:06 --> Pagination Class Initialized
INFO - 2018-11-26 07:20:06 --> Helper loaded: form_helper
INFO - 2018-11-26 07:20:06 --> Form Validation Class Initialized
INFO - 2018-11-26 07:20:06 --> Model Class Initialized
INFO - 2018-11-26 07:20:06 --> Controller Class Initialized
INFO - 2018-11-26 07:20:06 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-26 07:20:06 --> Model Class Initialized
INFO - 2018-11-26 07:20:06 --> Model Class Initialized
INFO - 2018-11-26 07:20:06 --> Final output sent to browser
DEBUG - 2018-11-26 07:20:06 --> Total execution time: 0.0630
INFO - 2018-11-26 07:20:06 --> Config Class Initialized
INFO - 2018-11-26 07:20:06 --> Hooks Class Initialized
DEBUG - 2018-11-26 07:20:06 --> UTF-8 Support Enabled
INFO - 2018-11-26 07:20:06 --> Utf8 Class Initialized
INFO - 2018-11-26 07:20:06 --> URI Class Initialized
INFO - 2018-11-26 07:20:06 --> Router Class Initialized
INFO - 2018-11-26 07:20:06 --> Output Class Initialized
INFO - 2018-11-26 07:20:06 --> Security Class Initialized
DEBUG - 2018-11-26 07:20:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-26 07:20:06 --> Input Class Initialized
INFO - 2018-11-26 07:20:06 --> Language Class Initialized
INFO - 2018-11-26 07:20:06 --> Loader Class Initialized
INFO - 2018-11-26 07:20:06 --> Helper loaded: url_helper
INFO - 2018-11-26 07:20:06 --> Helper loaded: file_helper
INFO - 2018-11-26 07:20:06 --> Helper loaded: email_helper
INFO - 2018-11-26 07:20:06 --> Helper loaded: common_helper
INFO - 2018-11-26 07:20:06 --> Database Driver Class Initialized
DEBUG - 2018-11-26 07:20:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-26 07:20:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-26 07:20:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-26 07:20:06 --> Pagination Class Initialized
INFO - 2018-11-26 07:20:06 --> Helper loaded: form_helper
INFO - 2018-11-26 07:20:06 --> Form Validation Class Initialized
INFO - 2018-11-26 07:20:06 --> Model Class Initialized
INFO - 2018-11-26 07:20:06 --> Controller Class Initialized
INFO - 2018-11-26 07:20:06 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-26 07:20:06 --> Model Class Initialized
INFO - 2018-11-26 07:20:06 --> Model Class Initialized
INFO - 2018-11-26 07:20:06 --> Final output sent to browser
DEBUG - 2018-11-26 07:20:06 --> Total execution time: 0.0720
INFO - 2018-11-26 07:20:07 --> Config Class Initialized
INFO - 2018-11-26 07:20:07 --> Hooks Class Initialized
DEBUG - 2018-11-26 07:20:07 --> UTF-8 Support Enabled
INFO - 2018-11-26 07:20:07 --> Utf8 Class Initialized
INFO - 2018-11-26 07:20:07 --> URI Class Initialized
INFO - 2018-11-26 07:20:07 --> Router Class Initialized
INFO - 2018-11-26 07:20:07 --> Output Class Initialized
INFO - 2018-11-26 07:20:07 --> Security Class Initialized
DEBUG - 2018-11-26 07:20:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-26 07:20:07 --> Input Class Initialized
INFO - 2018-11-26 07:20:07 --> Language Class Initialized
INFO - 2018-11-26 07:20:07 --> Loader Class Initialized
INFO - 2018-11-26 07:20:07 --> Helper loaded: url_helper
INFO - 2018-11-26 07:20:07 --> Helper loaded: file_helper
INFO - 2018-11-26 07:20:07 --> Helper loaded: email_helper
INFO - 2018-11-26 07:20:07 --> Helper loaded: common_helper
INFO - 2018-11-26 07:20:07 --> Database Driver Class Initialized
DEBUG - 2018-11-26 07:20:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-26 07:20:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-26 07:20:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-26 07:20:07 --> Pagination Class Initialized
INFO - 2018-11-26 07:20:07 --> Helper loaded: form_helper
INFO - 2018-11-26 07:20:07 --> Form Validation Class Initialized
INFO - 2018-11-26 07:20:07 --> Model Class Initialized
INFO - 2018-11-26 07:20:07 --> Controller Class Initialized
INFO - 2018-11-26 07:20:07 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-26 07:20:07 --> Model Class Initialized
INFO - 2018-11-26 07:20:07 --> Model Class Initialized
INFO - 2018-11-26 07:20:07 --> Final output sent to browser
DEBUG - 2018-11-26 07:20:07 --> Total execution time: 0.0660
INFO - 2018-11-26 07:20:45 --> Config Class Initialized
INFO - 2018-11-26 07:20:45 --> Hooks Class Initialized
DEBUG - 2018-11-26 07:20:45 --> UTF-8 Support Enabled
INFO - 2018-11-26 07:20:45 --> Utf8 Class Initialized
INFO - 2018-11-26 07:20:45 --> URI Class Initialized
INFO - 2018-11-26 07:20:45 --> Router Class Initialized
INFO - 2018-11-26 07:20:45 --> Output Class Initialized
INFO - 2018-11-26 07:20:45 --> Security Class Initialized
DEBUG - 2018-11-26 07:20:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-26 07:20:45 --> Input Class Initialized
INFO - 2018-11-26 07:20:45 --> Language Class Initialized
INFO - 2018-11-26 07:20:45 --> Loader Class Initialized
INFO - 2018-11-26 07:20:45 --> Helper loaded: url_helper
INFO - 2018-11-26 07:20:45 --> Helper loaded: file_helper
INFO - 2018-11-26 07:20:45 --> Helper loaded: email_helper
INFO - 2018-11-26 07:20:45 --> Helper loaded: common_helper
INFO - 2018-11-26 07:20:45 --> Database Driver Class Initialized
DEBUG - 2018-11-26 07:20:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-26 07:20:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-26 07:20:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-26 07:20:45 --> Pagination Class Initialized
INFO - 2018-11-26 07:20:45 --> Helper loaded: form_helper
INFO - 2018-11-26 07:20:45 --> Form Validation Class Initialized
INFO - 2018-11-26 07:20:45 --> Model Class Initialized
INFO - 2018-11-26 07:20:45 --> Controller Class Initialized
INFO - 2018-11-26 07:20:45 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-26 07:20:45 --> Model Class Initialized
INFO - 2018-11-26 07:20:45 --> Model Class Initialized
INFO - 2018-11-26 07:20:45 --> Final output sent to browser
DEBUG - 2018-11-26 07:20:45 --> Total execution time: 0.0700
INFO - 2018-11-26 07:20:45 --> Config Class Initialized
INFO - 2018-11-26 07:20:45 --> Hooks Class Initialized
DEBUG - 2018-11-26 07:20:45 --> UTF-8 Support Enabled
INFO - 2018-11-26 07:20:45 --> Utf8 Class Initialized
INFO - 2018-11-26 07:20:45 --> URI Class Initialized
INFO - 2018-11-26 07:20:45 --> Router Class Initialized
INFO - 2018-11-26 07:20:45 --> Output Class Initialized
INFO - 2018-11-26 07:20:45 --> Security Class Initialized
DEBUG - 2018-11-26 07:20:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-26 07:20:45 --> Input Class Initialized
INFO - 2018-11-26 07:20:45 --> Language Class Initialized
INFO - 2018-11-26 07:20:45 --> Loader Class Initialized
INFO - 2018-11-26 07:20:45 --> Helper loaded: url_helper
INFO - 2018-11-26 07:20:45 --> Helper loaded: file_helper
INFO - 2018-11-26 07:20:45 --> Helper loaded: email_helper
INFO - 2018-11-26 07:20:45 --> Helper loaded: common_helper
INFO - 2018-11-26 07:20:45 --> Database Driver Class Initialized
DEBUG - 2018-11-26 07:20:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-26 07:20:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-26 07:20:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-26 07:20:45 --> Pagination Class Initialized
INFO - 2018-11-26 07:20:45 --> Helper loaded: form_helper
INFO - 2018-11-26 07:20:45 --> Form Validation Class Initialized
INFO - 2018-11-26 07:20:45 --> Model Class Initialized
INFO - 2018-11-26 07:20:45 --> Controller Class Initialized
INFO - 2018-11-26 07:20:45 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-26 07:20:45 --> Model Class Initialized
INFO - 2018-11-26 07:20:45 --> Model Class Initialized
INFO - 2018-11-26 07:20:45 --> Final output sent to browser
DEBUG - 2018-11-26 07:20:45 --> Total execution time: 0.0730
INFO - 2018-11-26 07:20:47 --> Config Class Initialized
INFO - 2018-11-26 07:20:47 --> Hooks Class Initialized
DEBUG - 2018-11-26 07:20:47 --> UTF-8 Support Enabled
INFO - 2018-11-26 07:20:47 --> Utf8 Class Initialized
INFO - 2018-11-26 07:20:47 --> URI Class Initialized
INFO - 2018-11-26 07:20:47 --> Router Class Initialized
INFO - 2018-11-26 07:20:47 --> Output Class Initialized
INFO - 2018-11-26 07:20:47 --> Security Class Initialized
DEBUG - 2018-11-26 07:20:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-26 07:20:47 --> Input Class Initialized
INFO - 2018-11-26 07:20:47 --> Language Class Initialized
INFO - 2018-11-26 07:20:47 --> Loader Class Initialized
INFO - 2018-11-26 07:20:47 --> Helper loaded: url_helper
INFO - 2018-11-26 07:20:47 --> Helper loaded: file_helper
INFO - 2018-11-26 07:20:47 --> Helper loaded: email_helper
INFO - 2018-11-26 07:20:47 --> Helper loaded: common_helper
INFO - 2018-11-26 07:20:47 --> Database Driver Class Initialized
DEBUG - 2018-11-26 07:20:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-26 07:20:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-26 07:20:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-26 07:20:47 --> Pagination Class Initialized
INFO - 2018-11-26 07:20:47 --> Helper loaded: form_helper
INFO - 2018-11-26 07:20:47 --> Form Validation Class Initialized
INFO - 2018-11-26 07:20:47 --> Model Class Initialized
INFO - 2018-11-26 07:20:47 --> Controller Class Initialized
INFO - 2018-11-26 07:20:47 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-26 07:20:47 --> Model Class Initialized
INFO - 2018-11-26 07:20:47 --> Model Class Initialized
INFO - 2018-11-26 07:20:47 --> Final output sent to browser
DEBUG - 2018-11-26 07:20:47 --> Total execution time: 0.0770
INFO - 2018-11-26 07:20:48 --> Config Class Initialized
INFO - 2018-11-26 07:20:48 --> Hooks Class Initialized
DEBUG - 2018-11-26 07:20:48 --> UTF-8 Support Enabled
INFO - 2018-11-26 07:20:48 --> Utf8 Class Initialized
INFO - 2018-11-26 07:20:48 --> URI Class Initialized
INFO - 2018-11-26 07:20:48 --> Router Class Initialized
INFO - 2018-11-26 07:20:48 --> Output Class Initialized
INFO - 2018-11-26 07:20:48 --> Security Class Initialized
DEBUG - 2018-11-26 07:20:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-26 07:20:48 --> Input Class Initialized
INFO - 2018-11-26 07:20:48 --> Language Class Initialized
INFO - 2018-11-26 07:20:48 --> Loader Class Initialized
INFO - 2018-11-26 07:20:48 --> Helper loaded: url_helper
INFO - 2018-11-26 07:20:48 --> Helper loaded: file_helper
INFO - 2018-11-26 07:20:48 --> Helper loaded: email_helper
INFO - 2018-11-26 07:20:48 --> Helper loaded: common_helper
INFO - 2018-11-26 07:20:48 --> Database Driver Class Initialized
DEBUG - 2018-11-26 07:20:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-26 07:20:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-26 07:20:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-26 07:20:48 --> Pagination Class Initialized
INFO - 2018-11-26 07:20:48 --> Helper loaded: form_helper
INFO - 2018-11-26 07:20:48 --> Form Validation Class Initialized
INFO - 2018-11-26 07:20:48 --> Model Class Initialized
INFO - 2018-11-26 07:20:48 --> Controller Class Initialized
INFO - 2018-11-26 07:20:48 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-26 07:20:48 --> Model Class Initialized
INFO - 2018-11-26 07:20:48 --> Model Class Initialized
INFO - 2018-11-26 07:20:48 --> Final output sent to browser
DEBUG - 2018-11-26 07:20:48 --> Total execution time: 0.0640
INFO - 2018-11-26 07:20:49 --> Config Class Initialized
INFO - 2018-11-26 07:20:49 --> Hooks Class Initialized
DEBUG - 2018-11-26 07:20:49 --> UTF-8 Support Enabled
INFO - 2018-11-26 07:20:49 --> Utf8 Class Initialized
INFO - 2018-11-26 07:20:49 --> URI Class Initialized
INFO - 2018-11-26 07:20:49 --> Router Class Initialized
INFO - 2018-11-26 07:20:49 --> Output Class Initialized
INFO - 2018-11-26 07:20:49 --> Security Class Initialized
DEBUG - 2018-11-26 07:20:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-26 07:20:49 --> Input Class Initialized
INFO - 2018-11-26 07:20:49 --> Language Class Initialized
INFO - 2018-11-26 07:20:49 --> Loader Class Initialized
INFO - 2018-11-26 07:20:49 --> Helper loaded: url_helper
INFO - 2018-11-26 07:20:49 --> Helper loaded: file_helper
INFO - 2018-11-26 07:20:49 --> Helper loaded: email_helper
INFO - 2018-11-26 07:20:49 --> Helper loaded: common_helper
INFO - 2018-11-26 07:20:49 --> Database Driver Class Initialized
DEBUG - 2018-11-26 07:20:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-26 07:20:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-26 07:20:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-26 07:20:49 --> Pagination Class Initialized
INFO - 2018-11-26 07:20:49 --> Helper loaded: form_helper
INFO - 2018-11-26 07:20:49 --> Form Validation Class Initialized
INFO - 2018-11-26 07:20:49 --> Model Class Initialized
INFO - 2018-11-26 07:20:49 --> Controller Class Initialized
INFO - 2018-11-26 07:20:49 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-26 07:20:49 --> Model Class Initialized
INFO - 2018-11-26 07:20:49 --> Model Class Initialized
INFO - 2018-11-26 07:20:49 --> Final output sent to browser
DEBUG - 2018-11-26 07:20:49 --> Total execution time: 0.0730
INFO - 2018-11-26 07:20:49 --> Config Class Initialized
INFO - 2018-11-26 07:20:49 --> Hooks Class Initialized
DEBUG - 2018-11-26 07:20:49 --> UTF-8 Support Enabled
INFO - 2018-11-26 07:20:49 --> Utf8 Class Initialized
INFO - 2018-11-26 07:20:49 --> URI Class Initialized
INFO - 2018-11-26 07:20:49 --> Router Class Initialized
INFO - 2018-11-26 07:20:49 --> Output Class Initialized
INFO - 2018-11-26 07:20:49 --> Security Class Initialized
DEBUG - 2018-11-26 07:20:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-26 07:20:49 --> Input Class Initialized
INFO - 2018-11-26 07:20:49 --> Language Class Initialized
INFO - 2018-11-26 07:20:49 --> Loader Class Initialized
INFO - 2018-11-26 07:20:49 --> Helper loaded: url_helper
INFO - 2018-11-26 07:20:49 --> Helper loaded: file_helper
INFO - 2018-11-26 07:20:49 --> Helper loaded: email_helper
INFO - 2018-11-26 07:20:49 --> Helper loaded: common_helper
INFO - 2018-11-26 07:20:49 --> Database Driver Class Initialized
DEBUG - 2018-11-26 07:20:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-26 07:20:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-26 07:20:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-26 07:20:49 --> Pagination Class Initialized
INFO - 2018-11-26 07:20:49 --> Helper loaded: form_helper
INFO - 2018-11-26 07:20:49 --> Form Validation Class Initialized
INFO - 2018-11-26 07:20:49 --> Model Class Initialized
INFO - 2018-11-26 07:20:49 --> Controller Class Initialized
INFO - 2018-11-26 07:20:49 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-26 07:20:49 --> Model Class Initialized
INFO - 2018-11-26 07:20:49 --> Model Class Initialized
INFO - 2018-11-26 07:20:49 --> Final output sent to browser
DEBUG - 2018-11-26 07:20:49 --> Total execution time: 0.0710
INFO - 2018-11-26 07:20:50 --> Config Class Initialized
INFO - 2018-11-26 07:20:50 --> Hooks Class Initialized
DEBUG - 2018-11-26 07:20:50 --> UTF-8 Support Enabled
INFO - 2018-11-26 07:20:50 --> Utf8 Class Initialized
INFO - 2018-11-26 07:20:50 --> URI Class Initialized
INFO - 2018-11-26 07:20:50 --> Router Class Initialized
INFO - 2018-11-26 07:20:50 --> Output Class Initialized
INFO - 2018-11-26 07:20:50 --> Security Class Initialized
DEBUG - 2018-11-26 07:20:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-26 07:20:50 --> Input Class Initialized
INFO - 2018-11-26 07:20:50 --> Language Class Initialized
INFO - 2018-11-26 07:20:50 --> Loader Class Initialized
INFO - 2018-11-26 07:20:50 --> Helper loaded: url_helper
INFO - 2018-11-26 07:20:50 --> Helper loaded: file_helper
INFO - 2018-11-26 07:20:50 --> Helper loaded: email_helper
INFO - 2018-11-26 07:20:50 --> Helper loaded: common_helper
INFO - 2018-11-26 07:20:50 --> Database Driver Class Initialized
DEBUG - 2018-11-26 07:20:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-26 07:20:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-26 07:20:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-26 07:20:50 --> Pagination Class Initialized
INFO - 2018-11-26 07:20:50 --> Helper loaded: form_helper
INFO - 2018-11-26 07:20:50 --> Form Validation Class Initialized
INFO - 2018-11-26 07:20:50 --> Model Class Initialized
INFO - 2018-11-26 07:20:50 --> Controller Class Initialized
INFO - 2018-11-26 07:20:50 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-26 07:20:50 --> Model Class Initialized
INFO - 2018-11-26 07:20:50 --> Model Class Initialized
INFO - 2018-11-26 07:20:50 --> Final output sent to browser
DEBUG - 2018-11-26 07:20:50 --> Total execution time: 0.0720
INFO - 2018-11-26 07:20:50 --> Config Class Initialized
INFO - 2018-11-26 07:20:50 --> Hooks Class Initialized
DEBUG - 2018-11-26 07:20:50 --> UTF-8 Support Enabled
INFO - 2018-11-26 07:20:50 --> Utf8 Class Initialized
INFO - 2018-11-26 07:20:50 --> URI Class Initialized
INFO - 2018-11-26 07:20:50 --> Router Class Initialized
INFO - 2018-11-26 07:20:50 --> Output Class Initialized
INFO - 2018-11-26 07:20:50 --> Security Class Initialized
DEBUG - 2018-11-26 07:20:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-26 07:20:50 --> Input Class Initialized
INFO - 2018-11-26 07:20:50 --> Language Class Initialized
INFO - 2018-11-26 07:20:50 --> Loader Class Initialized
INFO - 2018-11-26 07:20:50 --> Helper loaded: url_helper
INFO - 2018-11-26 07:20:50 --> Helper loaded: file_helper
INFO - 2018-11-26 07:20:50 --> Helper loaded: email_helper
INFO - 2018-11-26 07:20:50 --> Helper loaded: common_helper
INFO - 2018-11-26 07:20:50 --> Database Driver Class Initialized
DEBUG - 2018-11-26 07:20:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-26 07:20:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-26 07:20:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-26 07:20:50 --> Pagination Class Initialized
INFO - 2018-11-26 07:20:50 --> Helper loaded: form_helper
INFO - 2018-11-26 07:20:50 --> Form Validation Class Initialized
INFO - 2018-11-26 07:20:50 --> Model Class Initialized
INFO - 2018-11-26 07:20:50 --> Controller Class Initialized
INFO - 2018-11-26 07:20:50 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-26 07:20:50 --> Model Class Initialized
INFO - 2018-11-26 07:20:50 --> Model Class Initialized
INFO - 2018-11-26 07:20:50 --> Final output sent to browser
DEBUG - 2018-11-26 07:20:50 --> Total execution time: 0.0650
INFO - 2018-11-26 07:20:51 --> Config Class Initialized
INFO - 2018-11-26 07:20:51 --> Hooks Class Initialized
DEBUG - 2018-11-26 07:20:51 --> UTF-8 Support Enabled
INFO - 2018-11-26 07:20:51 --> Utf8 Class Initialized
INFO - 2018-11-26 07:20:51 --> URI Class Initialized
INFO - 2018-11-26 07:20:51 --> Router Class Initialized
INFO - 2018-11-26 07:20:51 --> Output Class Initialized
INFO - 2018-11-26 07:20:51 --> Security Class Initialized
DEBUG - 2018-11-26 07:20:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-26 07:20:51 --> Input Class Initialized
INFO - 2018-11-26 07:20:51 --> Language Class Initialized
INFO - 2018-11-26 07:20:51 --> Loader Class Initialized
INFO - 2018-11-26 07:20:51 --> Helper loaded: url_helper
INFO - 2018-11-26 07:20:51 --> Helper loaded: file_helper
INFO - 2018-11-26 07:20:51 --> Helper loaded: email_helper
INFO - 2018-11-26 07:20:51 --> Helper loaded: common_helper
INFO - 2018-11-26 07:20:51 --> Database Driver Class Initialized
DEBUG - 2018-11-26 07:20:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-26 07:20:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-26 07:20:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-26 07:20:51 --> Pagination Class Initialized
INFO - 2018-11-26 07:20:51 --> Helper loaded: form_helper
INFO - 2018-11-26 07:20:51 --> Form Validation Class Initialized
INFO - 2018-11-26 07:20:51 --> Model Class Initialized
INFO - 2018-11-26 07:20:51 --> Controller Class Initialized
INFO - 2018-11-26 07:20:51 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-26 07:20:51 --> Model Class Initialized
INFO - 2018-11-26 07:20:51 --> Model Class Initialized
INFO - 2018-11-26 07:20:51 --> Final output sent to browser
DEBUG - 2018-11-26 07:20:51 --> Total execution time: 0.0610
INFO - 2018-11-26 07:20:51 --> Config Class Initialized
INFO - 2018-11-26 07:20:51 --> Hooks Class Initialized
DEBUG - 2018-11-26 07:20:51 --> UTF-8 Support Enabled
INFO - 2018-11-26 07:20:51 --> Utf8 Class Initialized
INFO - 2018-11-26 07:20:51 --> URI Class Initialized
INFO - 2018-11-26 07:20:51 --> Router Class Initialized
INFO - 2018-11-26 07:20:51 --> Output Class Initialized
INFO - 2018-11-26 07:20:51 --> Security Class Initialized
DEBUG - 2018-11-26 07:20:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-26 07:20:51 --> Input Class Initialized
INFO - 2018-11-26 07:20:51 --> Language Class Initialized
INFO - 2018-11-26 07:20:51 --> Loader Class Initialized
INFO - 2018-11-26 07:20:51 --> Helper loaded: url_helper
INFO - 2018-11-26 07:20:51 --> Helper loaded: file_helper
INFO - 2018-11-26 07:20:51 --> Helper loaded: email_helper
INFO - 2018-11-26 07:20:51 --> Helper loaded: common_helper
INFO - 2018-11-26 07:20:51 --> Database Driver Class Initialized
DEBUG - 2018-11-26 07:20:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-26 07:20:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-26 07:20:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-26 07:20:51 --> Pagination Class Initialized
INFO - 2018-11-26 07:20:51 --> Helper loaded: form_helper
INFO - 2018-11-26 07:20:51 --> Form Validation Class Initialized
INFO - 2018-11-26 07:20:51 --> Model Class Initialized
INFO - 2018-11-26 07:20:51 --> Controller Class Initialized
INFO - 2018-11-26 07:20:51 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-26 07:20:51 --> Model Class Initialized
INFO - 2018-11-26 07:20:51 --> Model Class Initialized
INFO - 2018-11-26 07:20:51 --> Final output sent to browser
DEBUG - 2018-11-26 07:20:51 --> Total execution time: 0.1710
INFO - 2018-11-26 07:20:52 --> Config Class Initialized
INFO - 2018-11-26 07:20:52 --> Hooks Class Initialized
DEBUG - 2018-11-26 07:20:52 --> UTF-8 Support Enabled
INFO - 2018-11-26 07:20:52 --> Utf8 Class Initialized
INFO - 2018-11-26 07:20:52 --> URI Class Initialized
INFO - 2018-11-26 07:20:52 --> Router Class Initialized
INFO - 2018-11-26 07:20:52 --> Output Class Initialized
INFO - 2018-11-26 07:20:52 --> Security Class Initialized
DEBUG - 2018-11-26 07:20:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-26 07:20:52 --> Input Class Initialized
INFO - 2018-11-26 07:20:52 --> Language Class Initialized
INFO - 2018-11-26 07:20:52 --> Loader Class Initialized
INFO - 2018-11-26 07:20:52 --> Helper loaded: url_helper
INFO - 2018-11-26 07:20:52 --> Helper loaded: file_helper
INFO - 2018-11-26 07:20:52 --> Helper loaded: email_helper
INFO - 2018-11-26 07:20:52 --> Helper loaded: common_helper
INFO - 2018-11-26 07:20:52 --> Database Driver Class Initialized
DEBUG - 2018-11-26 07:20:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-26 07:20:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-26 07:20:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-26 07:20:52 --> Pagination Class Initialized
INFO - 2018-11-26 07:20:52 --> Helper loaded: form_helper
INFO - 2018-11-26 07:20:52 --> Form Validation Class Initialized
INFO - 2018-11-26 07:20:52 --> Model Class Initialized
INFO - 2018-11-26 07:20:52 --> Controller Class Initialized
INFO - 2018-11-26 07:20:52 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-26 07:20:52 --> Model Class Initialized
INFO - 2018-11-26 07:20:52 --> Model Class Initialized
INFO - 2018-11-26 07:20:52 --> Final output sent to browser
DEBUG - 2018-11-26 07:20:52 --> Total execution time: 0.0650
INFO - 2018-11-26 07:20:52 --> Config Class Initialized
INFO - 2018-11-26 07:20:52 --> Hooks Class Initialized
DEBUG - 2018-11-26 07:20:52 --> UTF-8 Support Enabled
INFO - 2018-11-26 07:20:52 --> Utf8 Class Initialized
INFO - 2018-11-26 07:20:52 --> URI Class Initialized
INFO - 2018-11-26 07:20:52 --> Router Class Initialized
INFO - 2018-11-26 07:20:52 --> Output Class Initialized
INFO - 2018-11-26 07:20:52 --> Security Class Initialized
DEBUG - 2018-11-26 07:20:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-26 07:20:52 --> Input Class Initialized
INFO - 2018-11-26 07:20:52 --> Language Class Initialized
INFO - 2018-11-26 07:20:52 --> Loader Class Initialized
INFO - 2018-11-26 07:20:52 --> Helper loaded: url_helper
INFO - 2018-11-26 07:20:52 --> Helper loaded: file_helper
INFO - 2018-11-26 07:20:52 --> Helper loaded: email_helper
INFO - 2018-11-26 07:20:52 --> Helper loaded: common_helper
INFO - 2018-11-26 07:20:52 --> Database Driver Class Initialized
DEBUG - 2018-11-26 07:20:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-26 07:20:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-26 07:20:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-26 07:20:52 --> Pagination Class Initialized
INFO - 2018-11-26 07:20:52 --> Helper loaded: form_helper
INFO - 2018-11-26 07:20:52 --> Form Validation Class Initialized
INFO - 2018-11-26 07:20:52 --> Model Class Initialized
INFO - 2018-11-26 07:20:52 --> Controller Class Initialized
INFO - 2018-11-26 07:20:52 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-26 07:20:52 --> Model Class Initialized
INFO - 2018-11-26 07:20:52 --> Model Class Initialized
INFO - 2018-11-26 07:20:52 --> Final output sent to browser
DEBUG - 2018-11-26 07:20:52 --> Total execution time: 0.0720
INFO - 2018-11-26 07:20:52 --> Config Class Initialized
INFO - 2018-11-26 07:20:52 --> Hooks Class Initialized
DEBUG - 2018-11-26 07:20:52 --> UTF-8 Support Enabled
INFO - 2018-11-26 07:20:52 --> Utf8 Class Initialized
INFO - 2018-11-26 07:20:52 --> URI Class Initialized
INFO - 2018-11-26 07:20:52 --> Router Class Initialized
INFO - 2018-11-26 07:20:52 --> Output Class Initialized
INFO - 2018-11-26 07:20:52 --> Security Class Initialized
DEBUG - 2018-11-26 07:20:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-26 07:20:52 --> Input Class Initialized
INFO - 2018-11-26 07:20:52 --> Language Class Initialized
INFO - 2018-11-26 07:20:52 --> Loader Class Initialized
INFO - 2018-11-26 07:20:52 --> Helper loaded: url_helper
INFO - 2018-11-26 07:20:52 --> Helper loaded: file_helper
INFO - 2018-11-26 07:20:52 --> Helper loaded: email_helper
INFO - 2018-11-26 07:20:52 --> Helper loaded: common_helper
INFO - 2018-11-26 07:20:52 --> Database Driver Class Initialized
DEBUG - 2018-11-26 07:20:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-26 07:20:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-26 07:20:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-26 07:20:52 --> Pagination Class Initialized
INFO - 2018-11-26 07:20:52 --> Helper loaded: form_helper
INFO - 2018-11-26 07:20:52 --> Form Validation Class Initialized
INFO - 2018-11-26 07:20:52 --> Model Class Initialized
INFO - 2018-11-26 07:20:52 --> Controller Class Initialized
INFO - 2018-11-26 07:20:52 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-26 07:20:52 --> Model Class Initialized
INFO - 2018-11-26 07:20:52 --> Model Class Initialized
INFO - 2018-11-26 07:20:52 --> Final output sent to browser
DEBUG - 2018-11-26 07:20:52 --> Total execution time: 0.0650
INFO - 2018-11-26 07:20:53 --> Config Class Initialized
INFO - 2018-11-26 07:20:53 --> Hooks Class Initialized
DEBUG - 2018-11-26 07:20:53 --> UTF-8 Support Enabled
INFO - 2018-11-26 07:20:53 --> Utf8 Class Initialized
INFO - 2018-11-26 07:20:53 --> URI Class Initialized
INFO - 2018-11-26 07:20:53 --> Router Class Initialized
INFO - 2018-11-26 07:20:53 --> Output Class Initialized
INFO - 2018-11-26 07:20:53 --> Security Class Initialized
DEBUG - 2018-11-26 07:20:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-26 07:20:53 --> Input Class Initialized
INFO - 2018-11-26 07:20:53 --> Language Class Initialized
INFO - 2018-11-26 07:20:53 --> Loader Class Initialized
INFO - 2018-11-26 07:20:53 --> Helper loaded: url_helper
INFO - 2018-11-26 07:20:53 --> Helper loaded: file_helper
INFO - 2018-11-26 07:20:53 --> Helper loaded: email_helper
INFO - 2018-11-26 07:20:53 --> Helper loaded: common_helper
INFO - 2018-11-26 07:20:53 --> Database Driver Class Initialized
DEBUG - 2018-11-26 07:20:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-26 07:20:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-26 07:20:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-26 07:20:53 --> Pagination Class Initialized
INFO - 2018-11-26 07:20:53 --> Helper loaded: form_helper
INFO - 2018-11-26 07:20:53 --> Form Validation Class Initialized
INFO - 2018-11-26 07:20:53 --> Model Class Initialized
INFO - 2018-11-26 07:20:53 --> Controller Class Initialized
INFO - 2018-11-26 07:20:53 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-26 07:20:53 --> Model Class Initialized
INFO - 2018-11-26 07:20:53 --> Model Class Initialized
INFO - 2018-11-26 07:20:53 --> Final output sent to browser
DEBUG - 2018-11-26 07:20:53 --> Total execution time: 0.0630
INFO - 2018-11-26 07:20:53 --> Config Class Initialized
INFO - 2018-11-26 07:20:53 --> Hooks Class Initialized
DEBUG - 2018-11-26 07:20:53 --> UTF-8 Support Enabled
INFO - 2018-11-26 07:20:53 --> Utf8 Class Initialized
INFO - 2018-11-26 07:20:53 --> URI Class Initialized
INFO - 2018-11-26 07:20:53 --> Router Class Initialized
INFO - 2018-11-26 07:20:53 --> Output Class Initialized
INFO - 2018-11-26 07:20:53 --> Security Class Initialized
DEBUG - 2018-11-26 07:20:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-26 07:20:53 --> Input Class Initialized
INFO - 2018-11-26 07:20:53 --> Language Class Initialized
INFO - 2018-11-26 07:20:53 --> Loader Class Initialized
INFO - 2018-11-26 07:20:53 --> Helper loaded: url_helper
INFO - 2018-11-26 07:20:53 --> Helper loaded: file_helper
INFO - 2018-11-26 07:20:53 --> Helper loaded: email_helper
INFO - 2018-11-26 07:20:53 --> Helper loaded: common_helper
INFO - 2018-11-26 07:20:53 --> Database Driver Class Initialized
DEBUG - 2018-11-26 07:20:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-26 07:20:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-26 07:20:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-26 07:20:53 --> Pagination Class Initialized
INFO - 2018-11-26 07:20:53 --> Helper loaded: form_helper
INFO - 2018-11-26 07:20:53 --> Form Validation Class Initialized
INFO - 2018-11-26 07:20:53 --> Model Class Initialized
INFO - 2018-11-26 07:20:53 --> Controller Class Initialized
INFO - 2018-11-26 07:20:53 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-26 07:20:53 --> Model Class Initialized
INFO - 2018-11-26 07:20:53 --> Model Class Initialized
INFO - 2018-11-26 07:20:53 --> Final output sent to browser
DEBUG - 2018-11-26 07:20:53 --> Total execution time: 0.0780
INFO - 2018-11-26 07:20:53 --> Config Class Initialized
INFO - 2018-11-26 07:20:53 --> Hooks Class Initialized
DEBUG - 2018-11-26 07:20:53 --> UTF-8 Support Enabled
INFO - 2018-11-26 07:20:53 --> Utf8 Class Initialized
INFO - 2018-11-26 07:20:53 --> URI Class Initialized
INFO - 2018-11-26 07:20:53 --> Router Class Initialized
INFO - 2018-11-26 07:20:53 --> Output Class Initialized
INFO - 2018-11-26 07:20:53 --> Security Class Initialized
DEBUG - 2018-11-26 07:20:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-26 07:20:53 --> Input Class Initialized
INFO - 2018-11-26 07:20:53 --> Language Class Initialized
INFO - 2018-11-26 07:20:53 --> Loader Class Initialized
INFO - 2018-11-26 07:20:53 --> Helper loaded: url_helper
INFO - 2018-11-26 07:20:53 --> Helper loaded: file_helper
INFO - 2018-11-26 07:20:53 --> Helper loaded: email_helper
INFO - 2018-11-26 07:20:53 --> Helper loaded: common_helper
INFO - 2018-11-26 07:20:53 --> Database Driver Class Initialized
DEBUG - 2018-11-26 07:20:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-26 07:20:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-26 07:20:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-26 07:20:53 --> Pagination Class Initialized
INFO - 2018-11-26 07:20:53 --> Helper loaded: form_helper
INFO - 2018-11-26 07:20:53 --> Form Validation Class Initialized
INFO - 2018-11-26 07:20:53 --> Model Class Initialized
INFO - 2018-11-26 07:20:53 --> Controller Class Initialized
INFO - 2018-11-26 07:20:53 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-26 07:20:53 --> Model Class Initialized
INFO - 2018-11-26 07:20:53 --> Model Class Initialized
INFO - 2018-11-26 07:20:53 --> Final output sent to browser
DEBUG - 2018-11-26 07:20:53 --> Total execution time: 0.0700
INFO - 2018-11-26 07:20:54 --> Config Class Initialized
INFO - 2018-11-26 07:20:54 --> Hooks Class Initialized
DEBUG - 2018-11-26 07:20:54 --> UTF-8 Support Enabled
INFO - 2018-11-26 07:20:54 --> Utf8 Class Initialized
INFO - 2018-11-26 07:20:54 --> URI Class Initialized
INFO - 2018-11-26 07:20:54 --> Router Class Initialized
INFO - 2018-11-26 07:20:54 --> Output Class Initialized
INFO - 2018-11-26 07:20:54 --> Security Class Initialized
DEBUG - 2018-11-26 07:20:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-26 07:20:54 --> Input Class Initialized
INFO - 2018-11-26 07:20:54 --> Language Class Initialized
INFO - 2018-11-26 07:20:54 --> Loader Class Initialized
INFO - 2018-11-26 07:20:54 --> Helper loaded: url_helper
INFO - 2018-11-26 07:20:54 --> Helper loaded: file_helper
INFO - 2018-11-26 07:20:54 --> Helper loaded: email_helper
INFO - 2018-11-26 07:20:54 --> Helper loaded: common_helper
INFO - 2018-11-26 07:20:54 --> Database Driver Class Initialized
DEBUG - 2018-11-26 07:20:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-26 07:20:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-26 07:20:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-26 07:20:54 --> Pagination Class Initialized
INFO - 2018-11-26 07:20:54 --> Helper loaded: form_helper
INFO - 2018-11-26 07:20:54 --> Form Validation Class Initialized
INFO - 2018-11-26 07:20:54 --> Model Class Initialized
INFO - 2018-11-26 07:20:54 --> Controller Class Initialized
INFO - 2018-11-26 07:20:54 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-26 07:20:54 --> Model Class Initialized
INFO - 2018-11-26 07:20:54 --> Model Class Initialized
INFO - 2018-11-26 07:20:54 --> Final output sent to browser
DEBUG - 2018-11-26 07:20:54 --> Total execution time: 0.0740
INFO - 2018-11-26 07:20:54 --> Config Class Initialized
INFO - 2018-11-26 07:20:54 --> Hooks Class Initialized
DEBUG - 2018-11-26 07:20:54 --> UTF-8 Support Enabled
INFO - 2018-11-26 07:20:54 --> Utf8 Class Initialized
INFO - 2018-11-26 07:20:54 --> URI Class Initialized
INFO - 2018-11-26 07:20:54 --> Router Class Initialized
INFO - 2018-11-26 07:20:54 --> Output Class Initialized
INFO - 2018-11-26 07:20:54 --> Security Class Initialized
DEBUG - 2018-11-26 07:20:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-26 07:20:54 --> Input Class Initialized
INFO - 2018-11-26 07:20:54 --> Language Class Initialized
INFO - 2018-11-26 07:20:54 --> Loader Class Initialized
INFO - 2018-11-26 07:20:54 --> Helper loaded: url_helper
INFO - 2018-11-26 07:20:54 --> Helper loaded: file_helper
INFO - 2018-11-26 07:20:54 --> Helper loaded: email_helper
INFO - 2018-11-26 07:20:54 --> Helper loaded: common_helper
INFO - 2018-11-26 07:20:54 --> Database Driver Class Initialized
DEBUG - 2018-11-26 07:20:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-26 07:20:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-26 07:20:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-26 07:20:54 --> Pagination Class Initialized
INFO - 2018-11-26 07:20:54 --> Helper loaded: form_helper
INFO - 2018-11-26 07:20:54 --> Form Validation Class Initialized
INFO - 2018-11-26 07:20:54 --> Model Class Initialized
INFO - 2018-11-26 07:20:54 --> Controller Class Initialized
INFO - 2018-11-26 07:20:54 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-26 07:20:54 --> Model Class Initialized
INFO - 2018-11-26 07:20:54 --> Model Class Initialized
INFO - 2018-11-26 07:20:54 --> Final output sent to browser
DEBUG - 2018-11-26 07:20:54 --> Total execution time: 0.0730
INFO - 2018-11-26 07:20:54 --> Config Class Initialized
INFO - 2018-11-26 07:20:54 --> Hooks Class Initialized
DEBUG - 2018-11-26 07:20:54 --> UTF-8 Support Enabled
INFO - 2018-11-26 07:20:54 --> Utf8 Class Initialized
INFO - 2018-11-26 07:20:54 --> URI Class Initialized
INFO - 2018-11-26 07:20:54 --> Router Class Initialized
INFO - 2018-11-26 07:20:54 --> Output Class Initialized
INFO - 2018-11-26 07:20:54 --> Security Class Initialized
DEBUG - 2018-11-26 07:20:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-26 07:20:54 --> Input Class Initialized
INFO - 2018-11-26 07:20:54 --> Language Class Initialized
INFO - 2018-11-26 07:20:54 --> Loader Class Initialized
INFO - 2018-11-26 07:20:54 --> Helper loaded: url_helper
INFO - 2018-11-26 07:20:54 --> Helper loaded: file_helper
INFO - 2018-11-26 07:20:54 --> Helper loaded: email_helper
INFO - 2018-11-26 07:20:54 --> Helper loaded: common_helper
INFO - 2018-11-26 07:20:54 --> Database Driver Class Initialized
DEBUG - 2018-11-26 07:20:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-26 07:20:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-26 07:20:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-26 07:20:54 --> Pagination Class Initialized
INFO - 2018-11-26 07:20:54 --> Helper loaded: form_helper
INFO - 2018-11-26 07:20:54 --> Form Validation Class Initialized
INFO - 2018-11-26 07:20:54 --> Model Class Initialized
INFO - 2018-11-26 07:20:54 --> Controller Class Initialized
INFO - 2018-11-26 07:20:54 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-26 07:20:54 --> Model Class Initialized
INFO - 2018-11-26 07:20:54 --> Model Class Initialized
INFO - 2018-11-26 07:20:54 --> Final output sent to browser
DEBUG - 2018-11-26 07:20:54 --> Total execution time: 0.0780
INFO - 2018-11-26 07:20:54 --> Config Class Initialized
INFO - 2018-11-26 07:20:54 --> Hooks Class Initialized
DEBUG - 2018-11-26 07:20:54 --> UTF-8 Support Enabled
INFO - 2018-11-26 07:20:54 --> Utf8 Class Initialized
INFO - 2018-11-26 07:20:54 --> URI Class Initialized
INFO - 2018-11-26 07:20:54 --> Router Class Initialized
INFO - 2018-11-26 07:20:54 --> Output Class Initialized
INFO - 2018-11-26 07:20:54 --> Security Class Initialized
DEBUG - 2018-11-26 07:20:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-26 07:20:54 --> Input Class Initialized
INFO - 2018-11-26 07:20:54 --> Language Class Initialized
INFO - 2018-11-26 07:20:54 --> Loader Class Initialized
INFO - 2018-11-26 07:20:54 --> Helper loaded: url_helper
INFO - 2018-11-26 07:20:54 --> Helper loaded: file_helper
INFO - 2018-11-26 07:20:54 --> Helper loaded: email_helper
INFO - 2018-11-26 07:20:54 --> Helper loaded: common_helper
INFO - 2018-11-26 07:20:55 --> Database Driver Class Initialized
DEBUG - 2018-11-26 07:20:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-26 07:20:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-26 07:20:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-26 07:20:55 --> Pagination Class Initialized
INFO - 2018-11-26 07:20:55 --> Helper loaded: form_helper
INFO - 2018-11-26 07:20:55 --> Form Validation Class Initialized
INFO - 2018-11-26 07:20:55 --> Model Class Initialized
INFO - 2018-11-26 07:20:55 --> Controller Class Initialized
INFO - 2018-11-26 07:20:55 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-26 07:20:55 --> Model Class Initialized
INFO - 2018-11-26 07:20:55 --> Model Class Initialized
INFO - 2018-11-26 07:20:55 --> Final output sent to browser
DEBUG - 2018-11-26 07:20:55 --> Total execution time: 0.0680
INFO - 2018-11-26 07:20:55 --> Config Class Initialized
INFO - 2018-11-26 07:20:55 --> Hooks Class Initialized
DEBUG - 2018-11-26 07:20:55 --> UTF-8 Support Enabled
INFO - 2018-11-26 07:20:55 --> Utf8 Class Initialized
INFO - 2018-11-26 07:20:55 --> URI Class Initialized
INFO - 2018-11-26 07:20:55 --> Router Class Initialized
INFO - 2018-11-26 07:20:55 --> Output Class Initialized
INFO - 2018-11-26 07:20:55 --> Security Class Initialized
DEBUG - 2018-11-26 07:20:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-26 07:20:55 --> Input Class Initialized
INFO - 2018-11-26 07:20:55 --> Language Class Initialized
ERROR - 2018-11-26 07:20:55 --> 404 Page Not Found: admin/Reset_password/index
INFO - 2018-11-26 07:21:43 --> Config Class Initialized
INFO - 2018-11-26 07:21:43 --> Hooks Class Initialized
DEBUG - 2018-11-26 07:21:43 --> UTF-8 Support Enabled
INFO - 2018-11-26 07:21:43 --> Utf8 Class Initialized
INFO - 2018-11-26 07:21:43 --> URI Class Initialized
INFO - 2018-11-26 07:21:43 --> Router Class Initialized
INFO - 2018-11-26 07:21:43 --> Output Class Initialized
INFO - 2018-11-26 07:21:43 --> Security Class Initialized
DEBUG - 2018-11-26 07:21:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-26 07:21:43 --> Input Class Initialized
INFO - 2018-11-26 07:21:43 --> Language Class Initialized
INFO - 2018-11-26 07:21:43 --> Loader Class Initialized
INFO - 2018-11-26 07:21:43 --> Helper loaded: url_helper
INFO - 2018-11-26 07:21:43 --> Helper loaded: file_helper
INFO - 2018-11-26 07:21:43 --> Helper loaded: email_helper
INFO - 2018-11-26 07:21:43 --> Helper loaded: common_helper
INFO - 2018-11-26 07:21:43 --> Database Driver Class Initialized
DEBUG - 2018-11-26 07:21:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-26 07:21:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-26 07:21:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-26 07:21:43 --> Pagination Class Initialized
INFO - 2018-11-26 07:21:43 --> Helper loaded: form_helper
INFO - 2018-11-26 07:21:43 --> Form Validation Class Initialized
INFO - 2018-11-26 07:21:43 --> Model Class Initialized
INFO - 2018-11-26 07:21:43 --> Controller Class Initialized
INFO - 2018-11-26 07:21:43 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-26 07:21:43 --> Model Class Initialized
INFO - 2018-11-26 07:21:43 --> Model Class Initialized
INFO - 2018-11-26 07:21:43 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/index.php
INFO - 2018-11-26 07:21:43 --> Final output sent to browser
DEBUG - 2018-11-26 07:21:43 --> Total execution time: 0.0920
INFO - 2018-11-26 07:21:55 --> Config Class Initialized
INFO - 2018-11-26 07:21:55 --> Hooks Class Initialized
DEBUG - 2018-11-26 07:21:55 --> UTF-8 Support Enabled
INFO - 2018-11-26 07:21:55 --> Utf8 Class Initialized
INFO - 2018-11-26 07:21:55 --> URI Class Initialized
INFO - 2018-11-26 07:21:55 --> Router Class Initialized
INFO - 2018-11-26 07:21:55 --> Output Class Initialized
INFO - 2018-11-26 07:21:55 --> Security Class Initialized
DEBUG - 2018-11-26 07:21:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-26 07:21:55 --> Input Class Initialized
INFO - 2018-11-26 07:21:55 --> Language Class Initialized
INFO - 2018-11-26 07:21:55 --> Loader Class Initialized
INFO - 2018-11-26 07:21:55 --> Helper loaded: url_helper
INFO - 2018-11-26 07:21:55 --> Helper loaded: file_helper
INFO - 2018-11-26 07:21:55 --> Helper loaded: email_helper
INFO - 2018-11-26 07:21:55 --> Helper loaded: common_helper
INFO - 2018-11-26 07:21:55 --> Database Driver Class Initialized
DEBUG - 2018-11-26 07:21:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-26 07:21:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-26 07:21:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-26 07:21:55 --> Pagination Class Initialized
INFO - 2018-11-26 07:21:55 --> Helper loaded: form_helper
INFO - 2018-11-26 07:21:55 --> Form Validation Class Initialized
INFO - 2018-11-26 07:21:55 --> Model Class Initialized
INFO - 2018-11-26 07:21:55 --> Controller Class Initialized
INFO - 2018-11-26 07:21:55 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-26 07:21:55 --> Model Class Initialized
INFO - 2018-11-26 07:21:55 --> Model Class Initialized
INFO - 2018-11-26 07:21:55 --> Final output sent to browser
DEBUG - 2018-11-26 07:21:55 --> Total execution time: 0.0780
INFO - 2018-11-26 07:22:05 --> Config Class Initialized
INFO - 2018-11-26 07:22:05 --> Hooks Class Initialized
DEBUG - 2018-11-26 07:22:05 --> UTF-8 Support Enabled
INFO - 2018-11-26 07:22:05 --> Utf8 Class Initialized
INFO - 2018-11-26 07:22:05 --> URI Class Initialized
INFO - 2018-11-26 07:22:05 --> Router Class Initialized
INFO - 2018-11-26 07:22:05 --> Output Class Initialized
INFO - 2018-11-26 07:22:05 --> Security Class Initialized
DEBUG - 2018-11-26 07:22:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-26 07:22:05 --> Input Class Initialized
INFO - 2018-11-26 07:22:05 --> Language Class Initialized
INFO - 2018-11-26 07:22:05 --> Loader Class Initialized
INFO - 2018-11-26 07:22:05 --> Helper loaded: url_helper
INFO - 2018-11-26 07:22:05 --> Helper loaded: file_helper
INFO - 2018-11-26 07:22:05 --> Helper loaded: email_helper
INFO - 2018-11-26 07:22:05 --> Helper loaded: common_helper
INFO - 2018-11-26 07:22:05 --> Database Driver Class Initialized
DEBUG - 2018-11-26 07:22:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-26 07:22:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-26 07:22:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-26 07:22:05 --> Pagination Class Initialized
INFO - 2018-11-26 07:22:05 --> Helper loaded: form_helper
INFO - 2018-11-26 07:22:05 --> Form Validation Class Initialized
INFO - 2018-11-26 07:22:05 --> Model Class Initialized
INFO - 2018-11-26 07:22:05 --> Controller Class Initialized
INFO - 2018-11-26 07:22:05 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-26 07:22:05 --> Model Class Initialized
INFO - 2018-11-26 07:22:05 --> Model Class Initialized
INFO - 2018-11-26 07:22:05 --> Final output sent to browser
DEBUG - 2018-11-26 07:22:05 --> Total execution time: 0.0690
INFO - 2018-11-26 07:22:05 --> Config Class Initialized
INFO - 2018-11-26 07:22:05 --> Hooks Class Initialized
DEBUG - 2018-11-26 07:22:05 --> UTF-8 Support Enabled
INFO - 2018-11-26 07:22:05 --> Utf8 Class Initialized
INFO - 2018-11-26 07:22:05 --> URI Class Initialized
INFO - 2018-11-26 07:22:05 --> Router Class Initialized
INFO - 2018-11-26 07:22:05 --> Output Class Initialized
INFO - 2018-11-26 07:22:05 --> Security Class Initialized
DEBUG - 2018-11-26 07:22:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-26 07:22:05 --> Input Class Initialized
INFO - 2018-11-26 07:22:05 --> Language Class Initialized
INFO - 2018-11-26 07:22:05 --> Loader Class Initialized
INFO - 2018-11-26 07:22:05 --> Helper loaded: url_helper
INFO - 2018-11-26 07:22:05 --> Helper loaded: file_helper
INFO - 2018-11-26 07:22:05 --> Helper loaded: email_helper
INFO - 2018-11-26 07:22:05 --> Helper loaded: common_helper
INFO - 2018-11-26 07:22:05 --> Database Driver Class Initialized
DEBUG - 2018-11-26 07:22:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-26 07:22:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-26 07:22:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-26 07:22:05 --> Pagination Class Initialized
INFO - 2018-11-26 07:22:05 --> Helper loaded: form_helper
INFO - 2018-11-26 07:22:05 --> Form Validation Class Initialized
INFO - 2018-11-26 07:22:05 --> Model Class Initialized
INFO - 2018-11-26 07:22:05 --> Controller Class Initialized
INFO - 2018-11-26 07:22:05 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-26 07:22:05 --> Model Class Initialized
INFO - 2018-11-26 07:22:05 --> Model Class Initialized
INFO - 2018-11-26 07:22:05 --> Final output sent to browser
DEBUG - 2018-11-26 07:22:05 --> Total execution time: 0.0680
INFO - 2018-11-26 07:22:05 --> Config Class Initialized
INFO - 2018-11-26 07:22:05 --> Hooks Class Initialized
DEBUG - 2018-11-26 07:22:05 --> UTF-8 Support Enabled
INFO - 2018-11-26 07:22:05 --> Utf8 Class Initialized
INFO - 2018-11-26 07:22:05 --> URI Class Initialized
INFO - 2018-11-26 07:22:05 --> Router Class Initialized
INFO - 2018-11-26 07:22:05 --> Output Class Initialized
INFO - 2018-11-26 07:22:05 --> Security Class Initialized
DEBUG - 2018-11-26 07:22:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-26 07:22:05 --> Input Class Initialized
INFO - 2018-11-26 07:22:05 --> Language Class Initialized
INFO - 2018-11-26 07:22:05 --> Loader Class Initialized
INFO - 2018-11-26 07:22:05 --> Helper loaded: url_helper
INFO - 2018-11-26 07:22:05 --> Helper loaded: file_helper
INFO - 2018-11-26 07:22:05 --> Helper loaded: email_helper
INFO - 2018-11-26 07:22:05 --> Helper loaded: common_helper
INFO - 2018-11-26 07:22:05 --> Database Driver Class Initialized
DEBUG - 2018-11-26 07:22:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-26 07:22:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-26 07:22:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-26 07:22:05 --> Pagination Class Initialized
INFO - 2018-11-26 07:22:06 --> Helper loaded: form_helper
INFO - 2018-11-26 07:22:06 --> Form Validation Class Initialized
INFO - 2018-11-26 07:22:06 --> Model Class Initialized
INFO - 2018-11-26 07:22:06 --> Controller Class Initialized
INFO - 2018-11-26 07:22:06 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-26 07:22:06 --> Model Class Initialized
INFO - 2018-11-26 07:22:06 --> Model Class Initialized
INFO - 2018-11-26 07:22:06 --> Final output sent to browser
DEBUG - 2018-11-26 07:22:06 --> Total execution time: 0.0610
INFO - 2018-11-26 07:22:06 --> Config Class Initialized
INFO - 2018-11-26 07:22:06 --> Hooks Class Initialized
DEBUG - 2018-11-26 07:22:06 --> UTF-8 Support Enabled
INFO - 2018-11-26 07:22:06 --> Utf8 Class Initialized
INFO - 2018-11-26 07:22:06 --> URI Class Initialized
INFO - 2018-11-26 07:22:06 --> Router Class Initialized
INFO - 2018-11-26 07:22:06 --> Output Class Initialized
INFO - 2018-11-26 07:22:06 --> Security Class Initialized
DEBUG - 2018-11-26 07:22:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-26 07:22:06 --> Input Class Initialized
INFO - 2018-11-26 07:22:06 --> Language Class Initialized
INFO - 2018-11-26 07:22:06 --> Loader Class Initialized
INFO - 2018-11-26 07:22:06 --> Helper loaded: url_helper
INFO - 2018-11-26 07:22:06 --> Helper loaded: file_helper
INFO - 2018-11-26 07:22:06 --> Helper loaded: email_helper
INFO - 2018-11-26 07:22:06 --> Helper loaded: common_helper
INFO - 2018-11-26 07:22:06 --> Database Driver Class Initialized
DEBUG - 2018-11-26 07:22:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-26 07:22:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-26 07:22:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-26 07:22:06 --> Pagination Class Initialized
INFO - 2018-11-26 07:22:06 --> Helper loaded: form_helper
INFO - 2018-11-26 07:22:06 --> Form Validation Class Initialized
INFO - 2018-11-26 07:22:06 --> Model Class Initialized
INFO - 2018-11-26 07:22:06 --> Controller Class Initialized
INFO - 2018-11-26 07:22:06 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-26 07:22:06 --> Model Class Initialized
INFO - 2018-11-26 07:22:06 --> Model Class Initialized
INFO - 2018-11-26 07:22:06 --> Final output sent to browser
DEBUG - 2018-11-26 07:22:06 --> Total execution time: 0.0650
INFO - 2018-11-26 07:22:06 --> Config Class Initialized
INFO - 2018-11-26 07:22:06 --> Hooks Class Initialized
DEBUG - 2018-11-26 07:22:06 --> UTF-8 Support Enabled
INFO - 2018-11-26 07:22:06 --> Utf8 Class Initialized
INFO - 2018-11-26 07:22:06 --> URI Class Initialized
INFO - 2018-11-26 07:22:06 --> Router Class Initialized
INFO - 2018-11-26 07:22:06 --> Output Class Initialized
INFO - 2018-11-26 07:22:06 --> Security Class Initialized
DEBUG - 2018-11-26 07:22:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-26 07:22:06 --> Input Class Initialized
INFO - 2018-11-26 07:22:06 --> Language Class Initialized
INFO - 2018-11-26 07:22:06 --> Loader Class Initialized
INFO - 2018-11-26 07:22:06 --> Helper loaded: url_helper
INFO - 2018-11-26 07:22:06 --> Helper loaded: file_helper
INFO - 2018-11-26 07:22:06 --> Helper loaded: email_helper
INFO - 2018-11-26 07:22:06 --> Helper loaded: common_helper
INFO - 2018-11-26 07:22:06 --> Database Driver Class Initialized
DEBUG - 2018-11-26 07:22:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-26 07:22:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-26 07:22:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-26 07:22:06 --> Pagination Class Initialized
INFO - 2018-11-26 07:22:06 --> Helper loaded: form_helper
INFO - 2018-11-26 07:22:06 --> Form Validation Class Initialized
INFO - 2018-11-26 07:22:06 --> Model Class Initialized
INFO - 2018-11-26 07:22:06 --> Controller Class Initialized
INFO - 2018-11-26 07:22:06 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-26 07:22:06 --> Model Class Initialized
INFO - 2018-11-26 07:22:06 --> Model Class Initialized
INFO - 2018-11-26 07:22:06 --> Final output sent to browser
DEBUG - 2018-11-26 07:22:06 --> Total execution time: 0.0750
INFO - 2018-11-26 07:22:07 --> Config Class Initialized
INFO - 2018-11-26 07:22:07 --> Hooks Class Initialized
DEBUG - 2018-11-26 07:22:07 --> UTF-8 Support Enabled
INFO - 2018-11-26 07:22:07 --> Utf8 Class Initialized
INFO - 2018-11-26 07:22:07 --> URI Class Initialized
INFO - 2018-11-26 07:22:07 --> Router Class Initialized
INFO - 2018-11-26 07:22:07 --> Output Class Initialized
INFO - 2018-11-26 07:22:07 --> Security Class Initialized
DEBUG - 2018-11-26 07:22:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-26 07:22:07 --> Input Class Initialized
INFO - 2018-11-26 07:22:07 --> Language Class Initialized
INFO - 2018-11-26 07:22:07 --> Loader Class Initialized
INFO - 2018-11-26 07:22:07 --> Helper loaded: url_helper
INFO - 2018-11-26 07:22:07 --> Helper loaded: file_helper
INFO - 2018-11-26 07:22:07 --> Helper loaded: email_helper
INFO - 2018-11-26 07:22:07 --> Helper loaded: common_helper
INFO - 2018-11-26 07:22:07 --> Database Driver Class Initialized
DEBUG - 2018-11-26 07:22:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-26 07:22:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-26 07:22:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-26 07:22:07 --> Pagination Class Initialized
INFO - 2018-11-26 07:22:07 --> Helper loaded: form_helper
INFO - 2018-11-26 07:22:07 --> Form Validation Class Initialized
INFO - 2018-11-26 07:22:07 --> Model Class Initialized
INFO - 2018-11-26 07:22:07 --> Controller Class Initialized
INFO - 2018-11-26 07:22:07 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-26 07:22:07 --> Model Class Initialized
INFO - 2018-11-26 07:22:07 --> Model Class Initialized
ERROR - 2018-11-26 07:22:07 --> Severity: Warning --> Missing argument 1 for Admin::reset_password() C:\xampp\htdocs\wetinuneed\application\controllers\admin\Admin.php 174
INFO - 2018-11-26 08:01:41 --> Config Class Initialized
INFO - 2018-11-26 08:01:41 --> Hooks Class Initialized
DEBUG - 2018-11-26 08:01:41 --> UTF-8 Support Enabled
INFO - 2018-11-26 08:01:41 --> Utf8 Class Initialized
INFO - 2018-11-26 08:01:41 --> URI Class Initialized
INFO - 2018-11-26 08:01:41 --> Router Class Initialized
INFO - 2018-11-26 08:01:41 --> Output Class Initialized
INFO - 2018-11-26 08:01:41 --> Security Class Initialized
DEBUG - 2018-11-26 08:01:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-26 08:01:41 --> Input Class Initialized
INFO - 2018-11-26 08:01:41 --> Language Class Initialized
INFO - 2018-11-26 08:01:41 --> Loader Class Initialized
INFO - 2018-11-26 08:01:41 --> Helper loaded: url_helper
INFO - 2018-11-26 08:01:41 --> Helper loaded: file_helper
INFO - 2018-11-26 08:01:41 --> Helper loaded: email_helper
INFO - 2018-11-26 08:01:41 --> Helper loaded: common_helper
INFO - 2018-11-26 08:01:41 --> Database Driver Class Initialized
DEBUG - 2018-11-26 08:01:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-26 08:01:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-26 08:01:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-26 08:01:41 --> Pagination Class Initialized
INFO - 2018-11-26 08:01:41 --> Helper loaded: form_helper
INFO - 2018-11-26 08:01:41 --> Form Validation Class Initialized
INFO - 2018-11-26 08:01:41 --> Model Class Initialized
INFO - 2018-11-26 08:01:41 --> Controller Class Initialized
INFO - 2018-11-26 08:01:41 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-26 08:01:41 --> Model Class Initialized
INFO - 2018-11-26 08:01:41 --> Model Class Initialized
INFO - 2018-11-26 08:01:41 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/index.php
INFO - 2018-11-26 08:01:41 --> Final output sent to browser
DEBUG - 2018-11-26 08:01:41 --> Total execution time: 0.0950
INFO - 2018-11-26 08:02:16 --> Config Class Initialized
INFO - 2018-11-26 08:02:16 --> Hooks Class Initialized
DEBUG - 2018-11-26 08:02:16 --> UTF-8 Support Enabled
INFO - 2018-11-26 08:02:16 --> Utf8 Class Initialized
INFO - 2018-11-26 08:02:16 --> URI Class Initialized
INFO - 2018-11-26 08:02:16 --> Router Class Initialized
INFO - 2018-11-26 08:02:16 --> Output Class Initialized
INFO - 2018-11-26 08:02:16 --> Security Class Initialized
DEBUG - 2018-11-26 08:02:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-26 08:02:16 --> Input Class Initialized
INFO - 2018-11-26 08:02:16 --> Language Class Initialized
INFO - 2018-11-26 08:02:16 --> Loader Class Initialized
INFO - 2018-11-26 08:02:16 --> Helper loaded: url_helper
INFO - 2018-11-26 08:02:16 --> Helper loaded: file_helper
INFO - 2018-11-26 08:02:16 --> Helper loaded: email_helper
INFO - 2018-11-26 08:02:16 --> Helper loaded: common_helper
INFO - 2018-11-26 08:02:16 --> Database Driver Class Initialized
DEBUG - 2018-11-26 08:02:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-26 08:02:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-26 08:02:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-26 08:02:16 --> Pagination Class Initialized
INFO - 2018-11-26 08:02:16 --> Helper loaded: form_helper
INFO - 2018-11-26 08:02:16 --> Form Validation Class Initialized
INFO - 2018-11-26 08:02:16 --> Model Class Initialized
INFO - 2018-11-26 08:02:16 --> Controller Class Initialized
INFO - 2018-11-26 08:02:16 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-26 08:02:16 --> Model Class Initialized
INFO - 2018-11-26 08:02:16 --> Model Class Initialized
INFO - 2018-11-26 08:02:16 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/index.php
INFO - 2018-11-26 08:02:16 --> Final output sent to browser
DEBUG - 2018-11-26 08:02:16 --> Total execution time: 0.0860
INFO - 2018-11-26 08:06:22 --> Config Class Initialized
INFO - 2018-11-26 08:06:22 --> Hooks Class Initialized
DEBUG - 2018-11-26 08:06:22 --> UTF-8 Support Enabled
INFO - 2018-11-26 08:06:22 --> Utf8 Class Initialized
INFO - 2018-11-26 08:06:22 --> URI Class Initialized
INFO - 2018-11-26 08:06:22 --> Router Class Initialized
INFO - 2018-11-26 08:06:22 --> Output Class Initialized
INFO - 2018-11-26 08:06:22 --> Security Class Initialized
DEBUG - 2018-11-26 08:06:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-26 08:06:22 --> Input Class Initialized
INFO - 2018-11-26 08:06:22 --> Language Class Initialized
INFO - 2018-11-26 08:06:22 --> Loader Class Initialized
INFO - 2018-11-26 08:06:22 --> Helper loaded: url_helper
INFO - 2018-11-26 08:06:22 --> Helper loaded: file_helper
INFO - 2018-11-26 08:06:22 --> Helper loaded: email_helper
INFO - 2018-11-26 08:06:22 --> Helper loaded: common_helper
INFO - 2018-11-26 08:06:22 --> Database Driver Class Initialized
DEBUG - 2018-11-26 08:06:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-26 08:06:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-26 08:06:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-26 08:06:22 --> Pagination Class Initialized
INFO - 2018-11-26 08:06:22 --> Helper loaded: form_helper
INFO - 2018-11-26 08:06:22 --> Form Validation Class Initialized
INFO - 2018-11-26 08:06:22 --> Model Class Initialized
INFO - 2018-11-26 08:06:22 --> Controller Class Initialized
INFO - 2018-11-26 08:06:22 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-26 08:06:22 --> Model Class Initialized
INFO - 2018-11-26 08:06:22 --> Model Class Initialized
INFO - 2018-11-26 08:06:22 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/index.php
INFO - 2018-11-26 08:06:22 --> Final output sent to browser
DEBUG - 2018-11-26 08:06:22 --> Total execution time: 0.0730
INFO - 2018-11-26 08:13:36 --> Config Class Initialized
INFO - 2018-11-26 08:13:36 --> Hooks Class Initialized
DEBUG - 2018-11-26 08:13:36 --> UTF-8 Support Enabled
INFO - 2018-11-26 08:13:36 --> Utf8 Class Initialized
INFO - 2018-11-26 08:13:36 --> URI Class Initialized
INFO - 2018-11-26 08:13:36 --> Router Class Initialized
INFO - 2018-11-26 08:13:36 --> Output Class Initialized
INFO - 2018-11-26 08:13:36 --> Security Class Initialized
DEBUG - 2018-11-26 08:13:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-26 08:13:36 --> Input Class Initialized
INFO - 2018-11-26 08:13:36 --> Language Class Initialized
INFO - 2018-11-26 08:13:36 --> Loader Class Initialized
INFO - 2018-11-26 08:13:36 --> Helper loaded: url_helper
INFO - 2018-11-26 08:13:36 --> Helper loaded: file_helper
INFO - 2018-11-26 08:13:36 --> Helper loaded: email_helper
INFO - 2018-11-26 08:13:36 --> Helper loaded: common_helper
INFO - 2018-11-26 08:13:36 --> Database Driver Class Initialized
DEBUG - 2018-11-26 08:13:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-26 08:13:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-26 08:13:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-26 08:13:36 --> Pagination Class Initialized
INFO - 2018-11-26 08:13:36 --> Helper loaded: form_helper
INFO - 2018-11-26 08:13:36 --> Form Validation Class Initialized
INFO - 2018-11-26 08:13:36 --> Model Class Initialized
INFO - 2018-11-26 08:13:36 --> Controller Class Initialized
INFO - 2018-11-26 08:13:36 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-26 08:13:36 --> Model Class Initialized
INFO - 2018-11-26 08:13:36 --> Model Class Initialized
INFO - 2018-11-26 08:13:36 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/index.php
INFO - 2018-11-26 08:13:36 --> Final output sent to browser
DEBUG - 2018-11-26 08:13:36 --> Total execution time: 0.0650
INFO - 2018-11-26 08:14:05 --> Config Class Initialized
INFO - 2018-11-26 08:14:05 --> Hooks Class Initialized
DEBUG - 2018-11-26 08:14:05 --> UTF-8 Support Enabled
INFO - 2018-11-26 08:14:05 --> Utf8 Class Initialized
INFO - 2018-11-26 08:14:05 --> URI Class Initialized
INFO - 2018-11-26 08:14:05 --> Router Class Initialized
INFO - 2018-11-26 08:14:05 --> Output Class Initialized
INFO - 2018-11-26 08:14:05 --> Security Class Initialized
DEBUG - 2018-11-26 08:14:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-26 08:14:05 --> Input Class Initialized
INFO - 2018-11-26 08:14:05 --> Language Class Initialized
INFO - 2018-11-26 08:14:05 --> Loader Class Initialized
INFO - 2018-11-26 08:14:05 --> Helper loaded: url_helper
INFO - 2018-11-26 08:14:05 --> Helper loaded: file_helper
INFO - 2018-11-26 08:14:05 --> Helper loaded: email_helper
INFO - 2018-11-26 08:14:05 --> Helper loaded: common_helper
INFO - 2018-11-26 08:14:05 --> Database Driver Class Initialized
DEBUG - 2018-11-26 08:14:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-26 08:14:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-26 08:14:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-26 08:14:05 --> Pagination Class Initialized
INFO - 2018-11-26 08:14:05 --> Helper loaded: form_helper
INFO - 2018-11-26 08:14:05 --> Form Validation Class Initialized
INFO - 2018-11-26 08:14:05 --> Model Class Initialized
INFO - 2018-11-26 08:14:05 --> Controller Class Initialized
INFO - 2018-11-26 08:14:05 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-26 08:14:05 --> Model Class Initialized
INFO - 2018-11-26 08:14:05 --> Model Class Initialized
INFO - 2018-11-26 08:14:05 --> Final output sent to browser
DEBUG - 2018-11-26 08:14:05 --> Total execution time: 0.0780
INFO - 2018-11-26 08:14:05 --> Config Class Initialized
INFO - 2018-11-26 08:14:05 --> Hooks Class Initialized
DEBUG - 2018-11-26 08:14:05 --> UTF-8 Support Enabled
INFO - 2018-11-26 08:14:05 --> Utf8 Class Initialized
INFO - 2018-11-26 08:14:05 --> URI Class Initialized
INFO - 2018-11-26 08:14:05 --> Router Class Initialized
INFO - 2018-11-26 08:14:05 --> Output Class Initialized
INFO - 2018-11-26 08:14:05 --> Security Class Initialized
DEBUG - 2018-11-26 08:14:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-26 08:14:05 --> Input Class Initialized
INFO - 2018-11-26 08:14:05 --> Language Class Initialized
INFO - 2018-11-26 08:14:05 --> Loader Class Initialized
INFO - 2018-11-26 08:14:05 --> Helper loaded: url_helper
INFO - 2018-11-26 08:14:05 --> Helper loaded: file_helper
INFO - 2018-11-26 08:14:05 --> Helper loaded: email_helper
INFO - 2018-11-26 08:14:05 --> Helper loaded: common_helper
INFO - 2018-11-26 08:14:05 --> Database Driver Class Initialized
DEBUG - 2018-11-26 08:14:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-26 08:14:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-26 08:14:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-26 08:14:05 --> Pagination Class Initialized
INFO - 2018-11-26 08:14:05 --> Helper loaded: form_helper
INFO - 2018-11-26 08:14:05 --> Form Validation Class Initialized
INFO - 2018-11-26 08:14:05 --> Model Class Initialized
INFO - 2018-11-26 08:14:05 --> Controller Class Initialized
INFO - 2018-11-26 08:14:05 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-26 08:14:05 --> Model Class Initialized
INFO - 2018-11-26 08:14:05 --> Model Class Initialized
ERROR - 2018-11-26 08:14:05 --> Severity: Notice --> Undefined index: email C:\xampp\htdocs\wetinuneed\application\controllers\admin\Admin.php 179
ERROR - 2018-11-26 08:14:05 --> Severity: Error --> Call to undefined method Admin::randomString() C:\xampp\htdocs\wetinuneed\application\controllers\admin\Admin.php 180
INFO - 2018-11-26 08:15:34 --> Config Class Initialized
INFO - 2018-11-26 08:15:34 --> Hooks Class Initialized
DEBUG - 2018-11-26 08:15:34 --> UTF-8 Support Enabled
INFO - 2018-11-26 08:15:34 --> Utf8 Class Initialized
INFO - 2018-11-26 08:15:34 --> URI Class Initialized
INFO - 2018-11-26 08:15:34 --> Router Class Initialized
INFO - 2018-11-26 08:15:34 --> Output Class Initialized
INFO - 2018-11-26 08:15:34 --> Security Class Initialized
DEBUG - 2018-11-26 08:15:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-26 08:15:34 --> Input Class Initialized
INFO - 2018-11-26 08:15:34 --> Language Class Initialized
INFO - 2018-11-26 08:15:34 --> Loader Class Initialized
INFO - 2018-11-26 08:15:34 --> Helper loaded: url_helper
INFO - 2018-11-26 08:15:34 --> Helper loaded: file_helper
INFO - 2018-11-26 08:15:34 --> Helper loaded: email_helper
INFO - 2018-11-26 08:15:34 --> Helper loaded: common_helper
INFO - 2018-11-26 08:15:34 --> Database Driver Class Initialized
DEBUG - 2018-11-26 08:15:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-26 08:15:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-26 08:15:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-26 08:15:34 --> Pagination Class Initialized
INFO - 2018-11-26 08:15:34 --> Helper loaded: form_helper
INFO - 2018-11-26 08:15:34 --> Form Validation Class Initialized
INFO - 2018-11-26 08:15:34 --> Model Class Initialized
INFO - 2018-11-26 08:15:34 --> Controller Class Initialized
INFO - 2018-11-26 08:15:34 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-26 08:15:34 --> Model Class Initialized
INFO - 2018-11-26 08:15:34 --> Model Class Initialized
ERROR - 2018-11-26 08:15:34 --> Severity: Error --> Call to undefined method Admin::randomString() C:\xampp\htdocs\wetinuneed\application\controllers\admin\Admin.php 180
INFO - 2018-11-26 08:15:48 --> Config Class Initialized
INFO - 2018-11-26 08:15:48 --> Hooks Class Initialized
DEBUG - 2018-11-26 08:15:48 --> UTF-8 Support Enabled
INFO - 2018-11-26 08:15:48 --> Utf8 Class Initialized
INFO - 2018-11-26 08:15:48 --> URI Class Initialized
INFO - 2018-11-26 08:15:48 --> Router Class Initialized
INFO - 2018-11-26 08:15:48 --> Output Class Initialized
INFO - 2018-11-26 08:15:48 --> Security Class Initialized
DEBUG - 2018-11-26 08:15:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-26 08:15:48 --> Input Class Initialized
INFO - 2018-11-26 08:15:48 --> Language Class Initialized
INFO - 2018-11-26 08:15:48 --> Loader Class Initialized
INFO - 2018-11-26 08:15:48 --> Helper loaded: url_helper
INFO - 2018-11-26 08:15:48 --> Helper loaded: file_helper
INFO - 2018-11-26 08:15:48 --> Helper loaded: email_helper
INFO - 2018-11-26 08:15:48 --> Helper loaded: common_helper
INFO - 2018-11-26 08:15:48 --> Database Driver Class Initialized
DEBUG - 2018-11-26 08:15:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-26 08:15:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-26 08:15:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-26 08:15:48 --> Pagination Class Initialized
INFO - 2018-11-26 08:15:48 --> Helper loaded: form_helper
INFO - 2018-11-26 08:15:48 --> Form Validation Class Initialized
INFO - 2018-11-26 08:15:48 --> Model Class Initialized
INFO - 2018-11-26 08:15:48 --> Controller Class Initialized
INFO - 2018-11-26 08:15:48 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-26 08:15:48 --> Model Class Initialized
INFO - 2018-11-26 08:15:48 --> Model Class Initialized
ERROR - 2018-11-26 08:15:48 --> Query error: Unknown column 'email' in 'where clause' - Invalid query: UPDATE `admin_master` SET `token` = '6gfdCDaPaTOz0T8'
WHERE `email` = 'admin@gmail.com'
INFO - 2018-11-26 08:15:48 --> Language file loaded: language/english/db_lang.php
INFO - 2018-11-26 08:16:04 --> Config Class Initialized
INFO - 2018-11-26 08:16:04 --> Hooks Class Initialized
DEBUG - 2018-11-26 08:16:04 --> UTF-8 Support Enabled
INFO - 2018-11-26 08:16:04 --> Utf8 Class Initialized
INFO - 2018-11-26 08:16:04 --> URI Class Initialized
INFO - 2018-11-26 08:16:04 --> Router Class Initialized
INFO - 2018-11-26 08:16:04 --> Output Class Initialized
INFO - 2018-11-26 08:16:04 --> Security Class Initialized
DEBUG - 2018-11-26 08:16:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-26 08:16:04 --> Input Class Initialized
INFO - 2018-11-26 08:16:04 --> Language Class Initialized
INFO - 2018-11-26 08:16:04 --> Loader Class Initialized
INFO - 2018-11-26 08:16:04 --> Helper loaded: url_helper
INFO - 2018-11-26 08:16:04 --> Helper loaded: file_helper
INFO - 2018-11-26 08:16:04 --> Helper loaded: email_helper
INFO - 2018-11-26 08:16:04 --> Helper loaded: common_helper
INFO - 2018-11-26 08:16:04 --> Database Driver Class Initialized
DEBUG - 2018-11-26 08:16:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-26 08:16:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-26 08:16:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-26 08:16:04 --> Pagination Class Initialized
INFO - 2018-11-26 08:16:04 --> Helper loaded: form_helper
INFO - 2018-11-26 08:16:04 --> Form Validation Class Initialized
INFO - 2018-11-26 08:16:04 --> Model Class Initialized
INFO - 2018-11-26 08:16:04 --> Controller Class Initialized
INFO - 2018-11-26 08:16:04 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-26 08:16:04 --> Model Class Initialized
INFO - 2018-11-26 08:16:04 --> Model Class Initialized
ERROR - 2018-11-26 08:16:04 --> Severity: Notice --> Undefined variable: toke C:\xampp\htdocs\wetinuneed\application\controllers\admin\Admin.php 185
ERROR - 2018-11-26 08:16:04 --> Query error: Unknown column 'email' in 'where clause' - Invalid query: SELECT *
FROM `admin_master`
WHERE `email` = 'admin@gmail.com'
INFO - 2018-11-26 08:16:04 --> Language file loaded: language/english/db_lang.php
INFO - 2018-11-26 08:16:26 --> Config Class Initialized
INFO - 2018-11-26 08:16:26 --> Hooks Class Initialized
DEBUG - 2018-11-26 08:16:26 --> UTF-8 Support Enabled
INFO - 2018-11-26 08:16:26 --> Utf8 Class Initialized
INFO - 2018-11-26 08:16:26 --> URI Class Initialized
INFO - 2018-11-26 08:16:26 --> Router Class Initialized
INFO - 2018-11-26 08:16:26 --> Output Class Initialized
INFO - 2018-11-26 08:16:26 --> Security Class Initialized
DEBUG - 2018-11-26 08:16:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-26 08:16:26 --> Input Class Initialized
INFO - 2018-11-26 08:16:26 --> Language Class Initialized
INFO - 2018-11-26 08:16:26 --> Loader Class Initialized
INFO - 2018-11-26 08:16:26 --> Helper loaded: url_helper
INFO - 2018-11-26 08:16:26 --> Helper loaded: file_helper
INFO - 2018-11-26 08:16:26 --> Helper loaded: email_helper
INFO - 2018-11-26 08:16:26 --> Helper loaded: common_helper
INFO - 2018-11-26 08:16:26 --> Database Driver Class Initialized
DEBUG - 2018-11-26 08:16:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-26 08:16:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-26 08:16:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-26 08:16:26 --> Pagination Class Initialized
INFO - 2018-11-26 08:16:26 --> Helper loaded: form_helper
INFO - 2018-11-26 08:16:26 --> Form Validation Class Initialized
INFO - 2018-11-26 08:16:26 --> Model Class Initialized
INFO - 2018-11-26 08:16:26 --> Controller Class Initialized
INFO - 2018-11-26 08:16:26 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-26 08:16:26 --> Model Class Initialized
INFO - 2018-11-26 08:16:26 --> Model Class Initialized
INFO - 2018-11-26 08:16:26 --> Config Class Initialized
INFO - 2018-11-26 08:16:26 --> Hooks Class Initialized
DEBUG - 2018-11-26 08:16:26 --> UTF-8 Support Enabled
INFO - 2018-11-26 08:16:26 --> Utf8 Class Initialized
INFO - 2018-11-26 08:16:26 --> URI Class Initialized
INFO - 2018-11-26 08:16:26 --> Router Class Initialized
INFO - 2018-11-26 08:16:26 --> Output Class Initialized
INFO - 2018-11-26 08:16:26 --> Security Class Initialized
DEBUG - 2018-11-26 08:16:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-26 08:16:26 --> Input Class Initialized
INFO - 2018-11-26 08:16:26 --> Language Class Initialized
INFO - 2018-11-26 08:16:26 --> Loader Class Initialized
INFO - 2018-11-26 08:16:26 --> Helper loaded: url_helper
INFO - 2018-11-26 08:16:26 --> Helper loaded: file_helper
INFO - 2018-11-26 08:16:26 --> Helper loaded: email_helper
INFO - 2018-11-26 08:16:26 --> Helper loaded: common_helper
INFO - 2018-11-26 08:16:26 --> Database Driver Class Initialized
DEBUG - 2018-11-26 08:16:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-26 08:16:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-26 08:16:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-26 08:16:26 --> Pagination Class Initialized
INFO - 2018-11-26 08:16:26 --> Helper loaded: form_helper
INFO - 2018-11-26 08:16:26 --> Form Validation Class Initialized
INFO - 2018-11-26 08:16:26 --> Model Class Initialized
INFO - 2018-11-26 08:16:26 --> Controller Class Initialized
INFO - 2018-11-26 08:16:26 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-26 08:16:26 --> Model Class Initialized
INFO - 2018-11-26 08:16:26 --> Model Class Initialized
INFO - 2018-11-26 08:16:26 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/index.php
INFO - 2018-11-26 08:16:26 --> Final output sent to browser
DEBUG - 2018-11-26 08:16:26 --> Total execution time: 0.0510
INFO - 2018-11-26 08:23:03 --> Config Class Initialized
INFO - 2018-11-26 08:23:03 --> Hooks Class Initialized
DEBUG - 2018-11-26 08:23:03 --> UTF-8 Support Enabled
INFO - 2018-11-26 08:23:03 --> Utf8 Class Initialized
INFO - 2018-11-26 08:23:03 --> URI Class Initialized
INFO - 2018-11-26 08:23:03 --> Router Class Initialized
INFO - 2018-11-26 08:23:03 --> Output Class Initialized
INFO - 2018-11-26 08:23:03 --> Security Class Initialized
DEBUG - 2018-11-26 08:23:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-26 08:23:03 --> Input Class Initialized
INFO - 2018-11-26 08:23:03 --> Language Class Initialized
INFO - 2018-11-26 08:23:03 --> Loader Class Initialized
INFO - 2018-11-26 08:23:03 --> Helper loaded: url_helper
INFO - 2018-11-26 08:23:03 --> Helper loaded: file_helper
INFO - 2018-11-26 08:23:03 --> Helper loaded: email_helper
INFO - 2018-11-26 08:23:03 --> Helper loaded: common_helper
INFO - 2018-11-26 08:23:03 --> Database Driver Class Initialized
DEBUG - 2018-11-26 08:23:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-26 08:23:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-26 08:23:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-26 08:23:03 --> Pagination Class Initialized
INFO - 2018-11-26 08:23:03 --> Helper loaded: form_helper
INFO - 2018-11-26 08:23:03 --> Form Validation Class Initialized
INFO - 2018-11-26 08:23:03 --> Model Class Initialized
INFO - 2018-11-26 08:23:03 --> Controller Class Initialized
INFO - 2018-11-26 08:23:03 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-26 08:23:03 --> Model Class Initialized
INFO - 2018-11-26 08:23:03 --> Model Class Initialized
INFO - 2018-11-26 08:23:03 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/index.php
INFO - 2018-11-26 08:23:03 --> Final output sent to browser
DEBUG - 2018-11-26 08:23:03 --> Total execution time: 0.0790
INFO - 2018-11-26 10:33:43 --> Config Class Initialized
INFO - 2018-11-26 10:33:43 --> Hooks Class Initialized
DEBUG - 2018-11-26 10:33:43 --> UTF-8 Support Enabled
INFO - 2018-11-26 10:33:43 --> Utf8 Class Initialized
INFO - 2018-11-26 10:33:43 --> URI Class Initialized
INFO - 2018-11-26 10:33:43 --> Router Class Initialized
INFO - 2018-11-26 10:33:43 --> Output Class Initialized
INFO - 2018-11-26 10:33:43 --> Security Class Initialized
DEBUG - 2018-11-26 10:33:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-26 10:33:43 --> Input Class Initialized
INFO - 2018-11-26 10:33:43 --> Language Class Initialized
INFO - 2018-11-26 10:33:43 --> Loader Class Initialized
INFO - 2018-11-26 10:33:43 --> Helper loaded: url_helper
INFO - 2018-11-26 10:33:43 --> Helper loaded: file_helper
INFO - 2018-11-26 10:33:43 --> Helper loaded: email_helper
INFO - 2018-11-26 10:33:43 --> Helper loaded: common_helper
INFO - 2018-11-26 10:33:43 --> Database Driver Class Initialized
DEBUG - 2018-11-26 10:33:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-26 10:33:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-26 10:33:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-26 10:33:43 --> Pagination Class Initialized
INFO - 2018-11-26 10:33:43 --> Helper loaded: form_helper
INFO - 2018-11-26 10:33:43 --> Form Validation Class Initialized
INFO - 2018-11-26 10:33:43 --> Model Class Initialized
INFO - 2018-11-26 10:33:43 --> Controller Class Initialized
INFO - 2018-11-26 10:33:43 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-26 10:33:43 --> Model Class Initialized
INFO - 2018-11-26 10:33:43 --> Model Class Initialized
INFO - 2018-11-26 10:33:43 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/index.php
INFO - 2018-11-26 10:33:43 --> Final output sent to browser
DEBUG - 2018-11-26 10:33:43 --> Total execution time: 0.1220
INFO - 2018-11-26 10:34:22 --> Config Class Initialized
INFO - 2018-11-26 10:34:22 --> Hooks Class Initialized
DEBUG - 2018-11-26 10:34:22 --> UTF-8 Support Enabled
INFO - 2018-11-26 10:34:22 --> Utf8 Class Initialized
INFO - 2018-11-26 10:34:22 --> URI Class Initialized
INFO - 2018-11-26 10:34:22 --> Router Class Initialized
INFO - 2018-11-26 10:34:22 --> Output Class Initialized
INFO - 2018-11-26 10:34:22 --> Security Class Initialized
DEBUG - 2018-11-26 10:34:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-26 10:34:22 --> Input Class Initialized
INFO - 2018-11-26 10:34:22 --> Language Class Initialized
INFO - 2018-11-26 10:34:22 --> Loader Class Initialized
INFO - 2018-11-26 10:34:22 --> Helper loaded: url_helper
INFO - 2018-11-26 10:34:22 --> Helper loaded: file_helper
INFO - 2018-11-26 10:34:22 --> Helper loaded: email_helper
INFO - 2018-11-26 10:34:22 --> Helper loaded: common_helper
INFO - 2018-11-26 10:34:22 --> Database Driver Class Initialized
DEBUG - 2018-11-26 10:34:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-26 10:34:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-26 10:34:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-26 10:34:22 --> Pagination Class Initialized
INFO - 2018-11-26 10:34:22 --> Helper loaded: form_helper
INFO - 2018-11-26 10:34:22 --> Form Validation Class Initialized
INFO - 2018-11-26 10:34:22 --> Model Class Initialized
INFO - 2018-11-26 10:34:22 --> Controller Class Initialized
INFO - 2018-11-26 10:34:22 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-26 10:34:22 --> Model Class Initialized
INFO - 2018-11-26 10:34:22 --> Model Class Initialized
INFO - 2018-11-26 10:34:22 --> Config Class Initialized
INFO - 2018-11-26 10:34:22 --> Hooks Class Initialized
DEBUG - 2018-11-26 10:34:22 --> UTF-8 Support Enabled
INFO - 2018-11-26 10:34:22 --> Utf8 Class Initialized
INFO - 2018-11-26 10:34:22 --> URI Class Initialized
INFO - 2018-11-26 10:34:22 --> Router Class Initialized
INFO - 2018-11-26 10:34:22 --> Output Class Initialized
INFO - 2018-11-26 10:34:22 --> Security Class Initialized
DEBUG - 2018-11-26 10:34:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-26 10:34:22 --> Input Class Initialized
INFO - 2018-11-26 10:34:22 --> Language Class Initialized
INFO - 2018-11-26 10:34:22 --> Loader Class Initialized
INFO - 2018-11-26 10:34:22 --> Helper loaded: url_helper
INFO - 2018-11-26 10:34:22 --> Helper loaded: file_helper
INFO - 2018-11-26 10:34:22 --> Helper loaded: email_helper
INFO - 2018-11-26 10:34:22 --> Helper loaded: common_helper
INFO - 2018-11-26 10:34:22 --> Database Driver Class Initialized
DEBUG - 2018-11-26 10:34:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-26 10:34:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-26 10:34:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-26 10:34:22 --> Pagination Class Initialized
INFO - 2018-11-26 10:34:22 --> Helper loaded: form_helper
INFO - 2018-11-26 10:34:22 --> Form Validation Class Initialized
INFO - 2018-11-26 10:34:22 --> Model Class Initialized
INFO - 2018-11-26 10:34:22 --> Controller Class Initialized
INFO - 2018-11-26 10:34:22 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-26 10:34:22 --> Model Class Initialized
INFO - 2018-11-26 10:34:22 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-26 10:34:22 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/sidebar.php
INFO - 2018-11-26 10:34:22 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/right-sidebar.php
INFO - 2018-11-26 10:34:22 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/footer.php
INFO - 2018-11-26 10:34:22 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/dashboard.php
INFO - 2018-11-26 10:34:22 --> Final output sent to browser
DEBUG - 2018-11-26 10:34:22 --> Total execution time: 0.0630
INFO - 2018-11-26 10:37:21 --> Config Class Initialized
INFO - 2018-11-26 10:37:21 --> Hooks Class Initialized
DEBUG - 2018-11-26 10:37:21 --> UTF-8 Support Enabled
INFO - 2018-11-26 10:37:21 --> Utf8 Class Initialized
INFO - 2018-11-26 10:37:21 --> URI Class Initialized
INFO - 2018-11-26 10:37:21 --> Router Class Initialized
INFO - 2018-11-26 10:37:21 --> Output Class Initialized
INFO - 2018-11-26 10:37:21 --> Security Class Initialized
DEBUG - 2018-11-26 10:37:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-26 10:37:21 --> Input Class Initialized
INFO - 2018-11-26 10:37:21 --> Language Class Initialized
INFO - 2018-11-26 10:37:21 --> Loader Class Initialized
INFO - 2018-11-26 10:37:21 --> Helper loaded: url_helper
INFO - 2018-11-26 10:37:21 --> Helper loaded: file_helper
INFO - 2018-11-26 10:37:21 --> Helper loaded: email_helper
INFO - 2018-11-26 10:37:21 --> Helper loaded: common_helper
INFO - 2018-11-26 10:37:21 --> Database Driver Class Initialized
DEBUG - 2018-11-26 10:37:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-26 10:37:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-26 10:37:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-26 10:37:21 --> Pagination Class Initialized
INFO - 2018-11-26 10:37:21 --> Helper loaded: form_helper
INFO - 2018-11-26 10:37:21 --> Form Validation Class Initialized
INFO - 2018-11-26 10:37:21 --> Model Class Initialized
INFO - 2018-11-26 10:37:21 --> Controller Class Initialized
INFO - 2018-11-26 10:37:21 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-26 10:37:21 --> Model Class Initialized
INFO - 2018-11-26 10:37:21 --> Model Class Initialized
INFO - 2018-11-26 10:37:21 --> Config Class Initialized
INFO - 2018-11-26 10:37:21 --> Hooks Class Initialized
DEBUG - 2018-11-26 10:37:21 --> UTF-8 Support Enabled
INFO - 2018-11-26 10:37:21 --> Utf8 Class Initialized
INFO - 2018-11-26 10:37:21 --> URI Class Initialized
INFO - 2018-11-26 10:37:21 --> Router Class Initialized
INFO - 2018-11-26 10:37:21 --> Output Class Initialized
INFO - 2018-11-26 10:37:21 --> Security Class Initialized
DEBUG - 2018-11-26 10:37:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-26 10:37:21 --> Input Class Initialized
INFO - 2018-11-26 10:37:21 --> Language Class Initialized
INFO - 2018-11-26 10:37:21 --> Loader Class Initialized
INFO - 2018-11-26 10:37:21 --> Helper loaded: url_helper
INFO - 2018-11-26 10:37:21 --> Helper loaded: file_helper
INFO - 2018-11-26 10:37:21 --> Helper loaded: email_helper
INFO - 2018-11-26 10:37:21 --> Helper loaded: common_helper
INFO - 2018-11-26 10:37:21 --> Database Driver Class Initialized
DEBUG - 2018-11-26 10:37:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-26 10:37:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-26 10:37:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-26 10:37:21 --> Pagination Class Initialized
INFO - 2018-11-26 10:37:21 --> Helper loaded: form_helper
INFO - 2018-11-26 10:37:21 --> Form Validation Class Initialized
INFO - 2018-11-26 10:37:21 --> Model Class Initialized
INFO - 2018-11-26 10:37:21 --> Controller Class Initialized
INFO - 2018-11-26 10:37:21 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-26 10:37:21 --> Model Class Initialized
INFO - 2018-11-26 10:37:21 --> Model Class Initialized
INFO - 2018-11-26 10:37:21 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/index.php
INFO - 2018-11-26 10:37:21 --> Final output sent to browser
DEBUG - 2018-11-26 10:37:21 --> Total execution time: 0.0510
INFO - 2018-11-26 10:37:37 --> Config Class Initialized
INFO - 2018-11-26 10:37:37 --> Hooks Class Initialized
DEBUG - 2018-11-26 10:37:37 --> UTF-8 Support Enabled
INFO - 2018-11-26 10:37:37 --> Utf8 Class Initialized
INFO - 2018-11-26 10:37:37 --> URI Class Initialized
INFO - 2018-11-26 10:37:37 --> Router Class Initialized
INFO - 2018-11-26 10:37:37 --> Output Class Initialized
INFO - 2018-11-26 10:37:37 --> Security Class Initialized
DEBUG - 2018-11-26 10:37:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-26 10:37:37 --> Input Class Initialized
INFO - 2018-11-26 10:37:37 --> Language Class Initialized
INFO - 2018-11-26 10:37:37 --> Loader Class Initialized
INFO - 2018-11-26 10:37:37 --> Helper loaded: url_helper
INFO - 2018-11-26 10:37:37 --> Helper loaded: file_helper
INFO - 2018-11-26 10:37:37 --> Helper loaded: email_helper
INFO - 2018-11-26 10:37:37 --> Helper loaded: common_helper
INFO - 2018-11-26 10:37:37 --> Database Driver Class Initialized
DEBUG - 2018-11-26 10:37:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-26 10:37:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-26 10:37:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-26 10:37:37 --> Pagination Class Initialized
INFO - 2018-11-26 10:37:37 --> Helper loaded: form_helper
INFO - 2018-11-26 10:37:37 --> Form Validation Class Initialized
INFO - 2018-11-26 10:37:37 --> Model Class Initialized
INFO - 2018-11-26 10:37:37 --> Controller Class Initialized
INFO - 2018-11-26 10:37:37 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-26 10:37:37 --> Model Class Initialized
INFO - 2018-11-26 10:37:37 --> Model Class Initialized
INFO - 2018-11-26 10:37:37 --> Final output sent to browser
DEBUG - 2018-11-26 10:37:37 --> Total execution time: 0.0650
INFO - 2018-11-26 10:43:32 --> Config Class Initialized
INFO - 2018-11-26 10:43:32 --> Hooks Class Initialized
DEBUG - 2018-11-26 10:43:32 --> UTF-8 Support Enabled
INFO - 2018-11-26 10:43:32 --> Utf8 Class Initialized
INFO - 2018-11-26 10:43:32 --> URI Class Initialized
INFO - 2018-11-26 10:43:32 --> Router Class Initialized
INFO - 2018-11-26 10:43:32 --> Output Class Initialized
INFO - 2018-11-26 10:43:32 --> Security Class Initialized
DEBUG - 2018-11-26 10:43:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-26 10:43:32 --> Input Class Initialized
INFO - 2018-11-26 10:43:32 --> Language Class Initialized
INFO - 2018-11-26 10:43:32 --> Loader Class Initialized
INFO - 2018-11-26 10:43:32 --> Helper loaded: url_helper
INFO - 2018-11-26 10:43:32 --> Helper loaded: file_helper
INFO - 2018-11-26 10:43:32 --> Helper loaded: email_helper
INFO - 2018-11-26 10:43:32 --> Helper loaded: common_helper
INFO - 2018-11-26 10:43:32 --> Database Driver Class Initialized
DEBUG - 2018-11-26 10:43:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-26 10:43:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-26 10:43:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-26 10:43:32 --> Pagination Class Initialized
INFO - 2018-11-26 10:43:32 --> Helper loaded: form_helper
INFO - 2018-11-26 10:43:32 --> Form Validation Class Initialized
INFO - 2018-11-26 10:43:32 --> Model Class Initialized
INFO - 2018-11-26 10:43:32 --> Controller Class Initialized
INFO - 2018-11-26 10:43:32 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-26 10:43:32 --> Model Class Initialized
INFO - 2018-11-26 10:43:32 --> Model Class Initialized
INFO - 2018-11-26 10:43:32 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/index.php
INFO - 2018-11-26 10:43:32 --> Final output sent to browser
DEBUG - 2018-11-26 10:43:32 --> Total execution time: 0.0730
INFO - 2018-11-26 10:44:25 --> Config Class Initialized
INFO - 2018-11-26 10:44:25 --> Hooks Class Initialized
DEBUG - 2018-11-26 10:44:25 --> UTF-8 Support Enabled
INFO - 2018-11-26 10:44:25 --> Utf8 Class Initialized
INFO - 2018-11-26 10:44:25 --> URI Class Initialized
INFO - 2018-11-26 10:44:25 --> Router Class Initialized
INFO - 2018-11-26 10:44:25 --> Output Class Initialized
INFO - 2018-11-26 10:44:25 --> Security Class Initialized
DEBUG - 2018-11-26 10:44:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-26 10:44:25 --> Input Class Initialized
INFO - 2018-11-26 10:44:25 --> Language Class Initialized
INFO - 2018-11-26 10:44:25 --> Loader Class Initialized
INFO - 2018-11-26 10:44:25 --> Helper loaded: url_helper
INFO - 2018-11-26 10:44:25 --> Helper loaded: file_helper
INFO - 2018-11-26 10:44:25 --> Helper loaded: email_helper
INFO - 2018-11-26 10:44:25 --> Helper loaded: common_helper
INFO - 2018-11-26 10:44:25 --> Database Driver Class Initialized
DEBUG - 2018-11-26 10:44:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-26 10:44:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-26 10:44:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-26 10:44:25 --> Pagination Class Initialized
INFO - 2018-11-26 10:44:25 --> Helper loaded: form_helper
INFO - 2018-11-26 10:44:25 --> Form Validation Class Initialized
INFO - 2018-11-26 10:44:25 --> Model Class Initialized
INFO - 2018-11-26 10:44:25 --> Controller Class Initialized
INFO - 2018-11-26 10:44:25 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-26 10:44:25 --> Model Class Initialized
INFO - 2018-11-26 10:44:25 --> Model Class Initialized
ERROR - 2018-11-26 10:44:25 --> Severity: Notice --> Undefined index: remember_me C:\xampp\htdocs\wetinuneed\application\controllers\admin\Admin.php 77
INFO - 2018-11-26 10:44:25 --> Config Class Initialized
INFO - 2018-11-26 10:44:25 --> Hooks Class Initialized
DEBUG - 2018-11-26 10:44:25 --> UTF-8 Support Enabled
INFO - 2018-11-26 10:44:25 --> Utf8 Class Initialized
INFO - 2018-11-26 10:44:25 --> URI Class Initialized
INFO - 2018-11-26 10:44:25 --> Router Class Initialized
INFO - 2018-11-26 10:44:25 --> Output Class Initialized
INFO - 2018-11-26 10:44:25 --> Security Class Initialized
DEBUG - 2018-11-26 10:44:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-26 10:44:25 --> Input Class Initialized
INFO - 2018-11-26 10:44:25 --> Language Class Initialized
INFO - 2018-11-26 10:44:25 --> Loader Class Initialized
INFO - 2018-11-26 10:44:25 --> Helper loaded: url_helper
INFO - 2018-11-26 10:44:25 --> Helper loaded: file_helper
INFO - 2018-11-26 10:44:25 --> Helper loaded: email_helper
INFO - 2018-11-26 10:44:25 --> Helper loaded: common_helper
INFO - 2018-11-26 10:44:25 --> Database Driver Class Initialized
DEBUG - 2018-11-26 10:44:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-26 10:44:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-26 10:44:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-26 10:44:25 --> Pagination Class Initialized
INFO - 2018-11-26 10:44:25 --> Helper loaded: form_helper
INFO - 2018-11-26 10:44:25 --> Form Validation Class Initialized
INFO - 2018-11-26 10:44:25 --> Model Class Initialized
INFO - 2018-11-26 10:44:25 --> Controller Class Initialized
INFO - 2018-11-26 10:44:25 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-26 10:44:25 --> Model Class Initialized
INFO - 2018-11-26 10:44:25 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-26 10:44:25 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/sidebar.php
INFO - 2018-11-26 10:44:25 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/right-sidebar.php
INFO - 2018-11-26 10:44:25 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/footer.php
INFO - 2018-11-26 10:44:25 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/dashboard.php
INFO - 2018-11-26 10:44:25 --> Final output sent to browser
DEBUG - 2018-11-26 10:44:25 --> Total execution time: 0.0530
INFO - 2018-11-26 10:44:46 --> Config Class Initialized
INFO - 2018-11-26 10:44:46 --> Hooks Class Initialized
DEBUG - 2018-11-26 10:44:46 --> UTF-8 Support Enabled
INFO - 2018-11-26 10:44:46 --> Utf8 Class Initialized
INFO - 2018-11-26 10:44:46 --> URI Class Initialized
INFO - 2018-11-26 10:44:46 --> Router Class Initialized
INFO - 2018-11-26 10:44:46 --> Output Class Initialized
INFO - 2018-11-26 10:44:46 --> Security Class Initialized
DEBUG - 2018-11-26 10:44:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-26 10:44:46 --> Input Class Initialized
INFO - 2018-11-26 10:44:46 --> Language Class Initialized
INFO - 2018-11-26 10:44:46 --> Loader Class Initialized
INFO - 2018-11-26 10:44:46 --> Helper loaded: url_helper
INFO - 2018-11-26 10:44:46 --> Helper loaded: file_helper
INFO - 2018-11-26 10:44:46 --> Helper loaded: email_helper
INFO - 2018-11-26 10:44:46 --> Helper loaded: common_helper
INFO - 2018-11-26 10:44:46 --> Database Driver Class Initialized
DEBUG - 2018-11-26 10:44:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-26 10:44:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-26 10:44:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-26 10:44:46 --> Pagination Class Initialized
INFO - 2018-11-26 10:44:46 --> Helper loaded: form_helper
INFO - 2018-11-26 10:44:46 --> Form Validation Class Initialized
INFO - 2018-11-26 10:44:46 --> Model Class Initialized
INFO - 2018-11-26 10:44:46 --> Controller Class Initialized
INFO - 2018-11-26 10:44:46 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-26 10:44:46 --> Model Class Initialized
INFO - 2018-11-26 10:44:46 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-26 10:44:46 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/sidebar.php
INFO - 2018-11-26 10:44:46 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/right-sidebar.php
INFO - 2018-11-26 10:44:46 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/footer.php
INFO - 2018-11-26 10:44:46 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/dashboard.php
INFO - 2018-11-26 10:44:46 --> Final output sent to browser
DEBUG - 2018-11-26 10:44:46 --> Total execution time: 0.0790
INFO - 2018-11-26 10:52:33 --> Config Class Initialized
INFO - 2018-11-26 10:52:33 --> Hooks Class Initialized
DEBUG - 2018-11-26 10:52:33 --> UTF-8 Support Enabled
INFO - 2018-11-26 10:52:33 --> Utf8 Class Initialized
INFO - 2018-11-26 10:52:33 --> URI Class Initialized
INFO - 2018-11-26 10:52:33 --> Router Class Initialized
INFO - 2018-11-26 10:52:33 --> Output Class Initialized
INFO - 2018-11-26 10:52:33 --> Security Class Initialized
DEBUG - 2018-11-26 10:52:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-26 10:52:33 --> Input Class Initialized
INFO - 2018-11-26 10:52:33 --> Language Class Initialized
INFO - 2018-11-26 10:52:33 --> Loader Class Initialized
INFO - 2018-11-26 10:52:33 --> Helper loaded: url_helper
INFO - 2018-11-26 10:52:33 --> Helper loaded: file_helper
INFO - 2018-11-26 10:52:33 --> Helper loaded: email_helper
INFO - 2018-11-26 10:52:33 --> Helper loaded: common_helper
INFO - 2018-11-26 10:52:33 --> Database Driver Class Initialized
DEBUG - 2018-11-26 10:52:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-26 10:52:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-26 10:52:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-26 10:52:33 --> Pagination Class Initialized
INFO - 2018-11-26 10:52:33 --> Helper loaded: form_helper
INFO - 2018-11-26 10:52:33 --> Form Validation Class Initialized
INFO - 2018-11-26 10:52:33 --> Model Class Initialized
INFO - 2018-11-26 10:52:33 --> Controller Class Initialized
INFO - 2018-11-26 10:52:33 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-26 10:52:33 --> Model Class Initialized
INFO - 2018-11-26 10:52:33 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-26 10:52:33 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/sidebar.php
INFO - 2018-11-26 10:52:33 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/right-sidebar.php
INFO - 2018-11-26 10:52:33 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/footer.php
INFO - 2018-11-26 10:52:33 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/dashboard.php
INFO - 2018-11-26 10:52:33 --> Final output sent to browser
DEBUG - 2018-11-26 10:52:33 --> Total execution time: 0.0680
INFO - 2018-11-26 10:52:38 --> Config Class Initialized
INFO - 2018-11-26 10:52:38 --> Hooks Class Initialized
DEBUG - 2018-11-26 10:52:38 --> UTF-8 Support Enabled
INFO - 2018-11-26 10:52:38 --> Utf8 Class Initialized
INFO - 2018-11-26 10:52:38 --> URI Class Initialized
INFO - 2018-11-26 10:52:38 --> Router Class Initialized
INFO - 2018-11-26 10:52:38 --> Output Class Initialized
INFO - 2018-11-26 10:52:38 --> Security Class Initialized
DEBUG - 2018-11-26 10:52:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-26 10:52:38 --> Input Class Initialized
INFO - 2018-11-26 10:52:38 --> Language Class Initialized
ERROR - 2018-11-26 10:52:38 --> 404 Page Not Found: admin/Reset_password/index
INFO - 2018-11-26 10:52:44 --> Config Class Initialized
INFO - 2018-11-26 10:52:44 --> Hooks Class Initialized
DEBUG - 2018-11-26 10:52:44 --> UTF-8 Support Enabled
INFO - 2018-11-26 10:52:44 --> Utf8 Class Initialized
INFO - 2018-11-26 10:52:44 --> URI Class Initialized
INFO - 2018-11-26 10:52:44 --> Router Class Initialized
INFO - 2018-11-26 10:52:44 --> Output Class Initialized
INFO - 2018-11-26 10:52:44 --> Security Class Initialized
DEBUG - 2018-11-26 10:52:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-26 10:52:44 --> Input Class Initialized
INFO - 2018-11-26 10:52:44 --> Language Class Initialized
INFO - 2018-11-26 10:52:44 --> Loader Class Initialized
INFO - 2018-11-26 10:52:44 --> Helper loaded: url_helper
INFO - 2018-11-26 10:52:44 --> Helper loaded: file_helper
INFO - 2018-11-26 10:52:44 --> Helper loaded: email_helper
INFO - 2018-11-26 10:52:44 --> Helper loaded: common_helper
INFO - 2018-11-26 10:52:44 --> Database Driver Class Initialized
DEBUG - 2018-11-26 10:52:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-26 10:52:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-26 10:52:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-26 10:52:44 --> Pagination Class Initialized
INFO - 2018-11-26 10:52:44 --> Helper loaded: form_helper
INFO - 2018-11-26 10:52:44 --> Form Validation Class Initialized
INFO - 2018-11-26 10:52:44 --> Model Class Initialized
INFO - 2018-11-26 10:52:44 --> Controller Class Initialized
INFO - 2018-11-26 10:52:44 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-26 10:52:44 --> Model Class Initialized
INFO - 2018-11-26 10:52:44 --> Model Class Initialized
INFO - 2018-11-26 10:52:44 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/reset-password.php
INFO - 2018-11-26 10:52:44 --> Config Class Initialized
INFO - 2018-11-26 10:52:44 --> Hooks Class Initialized
DEBUG - 2018-11-26 10:52:44 --> UTF-8 Support Enabled
INFO - 2018-11-26 10:52:44 --> Utf8 Class Initialized
INFO - 2018-11-26 10:52:44 --> URI Class Initialized
INFO - 2018-11-26 10:52:44 --> Router Class Initialized
INFO - 2018-11-26 10:52:44 --> Output Class Initialized
INFO - 2018-11-26 10:52:44 --> Security Class Initialized
DEBUG - 2018-11-26 10:52:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-26 10:52:44 --> Input Class Initialized
INFO - 2018-11-26 10:52:44 --> Language Class Initialized
INFO - 2018-11-26 10:52:44 --> Loader Class Initialized
INFO - 2018-11-26 10:52:44 --> Helper loaded: url_helper
INFO - 2018-11-26 10:52:45 --> Helper loaded: file_helper
INFO - 2018-11-26 10:52:45 --> Helper loaded: email_helper
INFO - 2018-11-26 10:52:45 --> Helper loaded: common_helper
INFO - 2018-11-26 10:52:45 --> Database Driver Class Initialized
DEBUG - 2018-11-26 10:52:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-26 10:52:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-26 10:52:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-26 10:52:45 --> Pagination Class Initialized
INFO - 2018-11-26 10:52:45 --> Helper loaded: form_helper
INFO - 2018-11-26 10:52:45 --> Form Validation Class Initialized
INFO - 2018-11-26 10:52:45 --> Model Class Initialized
INFO - 2018-11-26 10:52:45 --> Controller Class Initialized
INFO - 2018-11-26 10:52:45 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-26 10:52:45 --> Model Class Initialized
INFO - 2018-11-26 10:52:45 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-26 10:52:45 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/sidebar.php
INFO - 2018-11-26 10:52:45 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/right-sidebar.php
INFO - 2018-11-26 10:52:45 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/footer.php
INFO - 2018-11-26 10:52:45 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/dashboard.php
INFO - 2018-11-26 10:52:45 --> Final output sent to browser
DEBUG - 2018-11-26 10:52:45 --> Total execution time: 0.0760
INFO - 2018-11-26 10:52:45 --> Config Class Initialized
INFO - 2018-11-26 10:52:45 --> Hooks Class Initialized
DEBUG - 2018-11-26 10:52:45 --> UTF-8 Support Enabled
INFO - 2018-11-26 10:52:45 --> Utf8 Class Initialized
INFO - 2018-11-26 10:52:45 --> URI Class Initialized
INFO - 2018-11-26 10:52:45 --> Router Class Initialized
INFO - 2018-11-26 10:52:45 --> Output Class Initialized
INFO - 2018-11-26 10:52:45 --> Security Class Initialized
DEBUG - 2018-11-26 10:52:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-26 10:52:45 --> Input Class Initialized
INFO - 2018-11-26 10:52:45 --> Language Class Initialized
INFO - 2018-11-26 10:52:45 --> Loader Class Initialized
INFO - 2018-11-26 10:52:45 --> Helper loaded: url_helper
INFO - 2018-11-26 10:52:45 --> Helper loaded: file_helper
INFO - 2018-11-26 10:52:45 --> Helper loaded: email_helper
INFO - 2018-11-26 10:52:45 --> Helper loaded: common_helper
INFO - 2018-11-26 10:52:45 --> Database Driver Class Initialized
DEBUG - 2018-11-26 10:52:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-26 10:52:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-26 10:52:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-26 10:52:45 --> Pagination Class Initialized
INFO - 2018-11-26 10:52:45 --> Helper loaded: form_helper
INFO - 2018-11-26 10:52:45 --> Form Validation Class Initialized
INFO - 2018-11-26 10:52:45 --> Model Class Initialized
INFO - 2018-11-26 10:52:45 --> Controller Class Initialized
INFO - 2018-11-26 10:52:45 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-26 10:52:45 --> Model Class Initialized
INFO - 2018-11-26 10:52:45 --> Model Class Initialized
INFO - 2018-11-26 10:52:45 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/reset-password.php
INFO - 2018-11-26 10:52:45 --> Config Class Initialized
INFO - 2018-11-26 10:52:45 --> Hooks Class Initialized
DEBUG - 2018-11-26 10:52:45 --> UTF-8 Support Enabled
INFO - 2018-11-26 10:52:45 --> Utf8 Class Initialized
INFO - 2018-11-26 10:52:45 --> URI Class Initialized
INFO - 2018-11-26 10:52:45 --> Router Class Initialized
INFO - 2018-11-26 10:52:45 --> Output Class Initialized
INFO - 2018-11-26 10:52:45 --> Security Class Initialized
DEBUG - 2018-11-26 10:52:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-26 10:52:45 --> Input Class Initialized
INFO - 2018-11-26 10:52:45 --> Language Class Initialized
INFO - 2018-11-26 10:52:45 --> Loader Class Initialized
INFO - 2018-11-26 10:52:45 --> Helper loaded: url_helper
INFO - 2018-11-26 10:52:45 --> Helper loaded: file_helper
INFO - 2018-11-26 10:52:45 --> Helper loaded: email_helper
INFO - 2018-11-26 10:52:45 --> Helper loaded: common_helper
INFO - 2018-11-26 10:52:45 --> Database Driver Class Initialized
DEBUG - 2018-11-26 10:52:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-26 10:52:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-26 10:52:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-26 10:52:45 --> Pagination Class Initialized
INFO - 2018-11-26 10:52:45 --> Helper loaded: form_helper
INFO - 2018-11-26 10:52:45 --> Form Validation Class Initialized
INFO - 2018-11-26 10:52:45 --> Model Class Initialized
INFO - 2018-11-26 10:52:45 --> Controller Class Initialized
INFO - 2018-11-26 10:52:45 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-26 10:52:45 --> Model Class Initialized
INFO - 2018-11-26 10:52:45 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-26 10:52:45 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/sidebar.php
INFO - 2018-11-26 10:52:45 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/right-sidebar.php
INFO - 2018-11-26 10:52:45 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/footer.php
INFO - 2018-11-26 10:52:45 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/dashboard.php
INFO - 2018-11-26 10:52:45 --> Final output sent to browser
DEBUG - 2018-11-26 10:52:45 --> Total execution time: 0.0650
INFO - 2018-11-26 10:53:27 --> Config Class Initialized
INFO - 2018-11-26 10:53:27 --> Hooks Class Initialized
DEBUG - 2018-11-26 10:53:27 --> UTF-8 Support Enabled
INFO - 2018-11-26 10:53:27 --> Utf8 Class Initialized
INFO - 2018-11-26 10:53:27 --> URI Class Initialized
INFO - 2018-11-26 10:53:27 --> Router Class Initialized
INFO - 2018-11-26 10:53:27 --> Output Class Initialized
INFO - 2018-11-26 10:53:27 --> Security Class Initialized
DEBUG - 2018-11-26 10:53:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-26 10:53:27 --> Input Class Initialized
INFO - 2018-11-26 10:53:27 --> Language Class Initialized
INFO - 2018-11-26 10:53:27 --> Loader Class Initialized
INFO - 2018-11-26 10:53:27 --> Helper loaded: url_helper
INFO - 2018-11-26 10:53:27 --> Helper loaded: file_helper
INFO - 2018-11-26 10:53:27 --> Helper loaded: email_helper
INFO - 2018-11-26 10:53:27 --> Helper loaded: common_helper
INFO - 2018-11-26 10:53:27 --> Database Driver Class Initialized
DEBUG - 2018-11-26 10:53:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-26 10:53:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-26 10:53:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-26 10:53:27 --> Pagination Class Initialized
INFO - 2018-11-26 10:53:27 --> Helper loaded: form_helper
INFO - 2018-11-26 10:53:27 --> Form Validation Class Initialized
INFO - 2018-11-26 10:53:27 --> Model Class Initialized
INFO - 2018-11-26 10:53:27 --> Controller Class Initialized
INFO - 2018-11-26 10:53:27 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-26 10:53:27 --> Model Class Initialized
INFO - 2018-11-26 10:53:27 --> Model Class Initialized
INFO - 2018-11-26 10:53:27 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/reset-password.php
INFO - 2018-11-26 10:53:27 --> Final output sent to browser
DEBUG - 2018-11-26 10:53:27 --> Total execution time: 0.0770
INFO - 2018-11-26 11:01:51 --> Config Class Initialized
INFO - 2018-11-26 11:01:51 --> Hooks Class Initialized
DEBUG - 2018-11-26 11:01:51 --> UTF-8 Support Enabled
INFO - 2018-11-26 11:01:51 --> Utf8 Class Initialized
INFO - 2018-11-26 11:01:51 --> URI Class Initialized
INFO - 2018-11-26 11:01:51 --> Router Class Initialized
INFO - 2018-11-26 11:01:51 --> Output Class Initialized
INFO - 2018-11-26 11:01:51 --> Security Class Initialized
DEBUG - 2018-11-26 11:01:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-26 11:01:51 --> Input Class Initialized
INFO - 2018-11-26 11:01:51 --> Language Class Initialized
INFO - 2018-11-26 11:01:51 --> Loader Class Initialized
INFO - 2018-11-26 11:01:51 --> Helper loaded: url_helper
INFO - 2018-11-26 11:01:51 --> Helper loaded: file_helper
INFO - 2018-11-26 11:01:51 --> Helper loaded: email_helper
INFO - 2018-11-26 11:01:51 --> Helper loaded: common_helper
INFO - 2018-11-26 11:01:51 --> Database Driver Class Initialized
DEBUG - 2018-11-26 11:01:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-26 11:01:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-26 11:01:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-26 11:01:51 --> Pagination Class Initialized
INFO - 2018-11-26 11:01:51 --> Helper loaded: form_helper
INFO - 2018-11-26 11:01:51 --> Form Validation Class Initialized
INFO - 2018-11-26 11:01:51 --> Model Class Initialized
INFO - 2018-11-26 11:01:51 --> Controller Class Initialized
INFO - 2018-11-26 11:01:51 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-26 11:01:51 --> Model Class Initialized
INFO - 2018-11-26 11:01:51 --> Model Class Initialized
INFO - 2018-11-26 11:01:51 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/reset-password.php
INFO - 2018-11-26 11:01:51 --> Final output sent to browser
DEBUG - 2018-11-26 11:01:51 --> Total execution time: 0.0690
INFO - 2018-11-26 11:25:37 --> Config Class Initialized
INFO - 2018-11-26 11:25:37 --> Hooks Class Initialized
DEBUG - 2018-11-26 11:25:37 --> UTF-8 Support Enabled
INFO - 2018-11-26 11:25:37 --> Utf8 Class Initialized
INFO - 2018-11-26 11:25:37 --> URI Class Initialized
INFO - 2018-11-26 11:25:37 --> Router Class Initialized
INFO - 2018-11-26 11:25:37 --> Output Class Initialized
INFO - 2018-11-26 11:25:37 --> Security Class Initialized
DEBUG - 2018-11-26 11:25:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-26 11:25:37 --> Input Class Initialized
INFO - 2018-11-26 11:25:37 --> Language Class Initialized
INFO - 2018-11-26 11:25:37 --> Loader Class Initialized
INFO - 2018-11-26 11:25:37 --> Helper loaded: url_helper
INFO - 2018-11-26 11:25:37 --> Helper loaded: file_helper
INFO - 2018-11-26 11:25:37 --> Helper loaded: email_helper
INFO - 2018-11-26 11:25:37 --> Helper loaded: common_helper
INFO - 2018-11-26 11:25:37 --> Database Driver Class Initialized
DEBUG - 2018-11-26 11:25:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-26 11:25:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-26 11:25:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-26 11:25:37 --> Pagination Class Initialized
INFO - 2018-11-26 11:25:37 --> Helper loaded: form_helper
INFO - 2018-11-26 11:25:37 --> Form Validation Class Initialized
INFO - 2018-11-26 11:25:37 --> Model Class Initialized
INFO - 2018-11-26 11:25:37 --> Controller Class Initialized
INFO - 2018-11-26 11:25:37 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-26 11:25:37 --> Model Class Initialized
INFO - 2018-11-26 11:25:37 --> Model Class Initialized
INFO - 2018-11-26 11:25:37 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/reset-password.php
INFO - 2018-11-26 11:25:37 --> Final output sent to browser
DEBUG - 2018-11-26 11:25:37 --> Total execution time: 0.0750
INFO - 2018-11-26 11:25:41 --> Config Class Initialized
INFO - 2018-11-26 11:25:41 --> Hooks Class Initialized
DEBUG - 2018-11-26 11:25:41 --> UTF-8 Support Enabled
INFO - 2018-11-26 11:25:41 --> Utf8 Class Initialized
INFO - 2018-11-26 11:25:41 --> URI Class Initialized
INFO - 2018-11-26 11:25:41 --> Router Class Initialized
INFO - 2018-11-26 11:25:41 --> Output Class Initialized
INFO - 2018-11-26 11:25:41 --> Security Class Initialized
DEBUG - 2018-11-26 11:25:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-26 11:25:41 --> Input Class Initialized
INFO - 2018-11-26 11:25:41 --> Language Class Initialized
INFO - 2018-11-26 11:25:41 --> Loader Class Initialized
INFO - 2018-11-26 11:25:41 --> Helper loaded: url_helper
INFO - 2018-11-26 11:25:41 --> Helper loaded: file_helper
INFO - 2018-11-26 11:25:41 --> Helper loaded: email_helper
INFO - 2018-11-26 11:25:41 --> Helper loaded: common_helper
INFO - 2018-11-26 11:25:41 --> Database Driver Class Initialized
DEBUG - 2018-11-26 11:25:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-26 11:25:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-26 11:25:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-26 11:25:41 --> Pagination Class Initialized
INFO - 2018-11-26 11:25:41 --> Helper loaded: form_helper
INFO - 2018-11-26 11:25:41 --> Form Validation Class Initialized
INFO - 2018-11-26 11:25:41 --> Model Class Initialized
INFO - 2018-11-26 11:25:41 --> Controller Class Initialized
INFO - 2018-11-26 11:25:41 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-26 11:25:41 --> Model Class Initialized
INFO - 2018-11-26 11:25:41 --> Model Class Initialized
INFO - 2018-11-26 11:25:41 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/reset-password.php
INFO - 2018-11-26 11:25:41 --> Final output sent to browser
DEBUG - 2018-11-26 11:25:41 --> Total execution time: 0.0810
INFO - 2018-11-26 11:51:52 --> Config Class Initialized
INFO - 2018-11-26 11:51:52 --> Hooks Class Initialized
DEBUG - 2018-11-26 11:51:52 --> UTF-8 Support Enabled
INFO - 2018-11-26 11:51:52 --> Utf8 Class Initialized
INFO - 2018-11-26 11:51:52 --> URI Class Initialized
INFO - 2018-11-26 11:51:52 --> Router Class Initialized
INFO - 2018-11-26 11:51:52 --> Output Class Initialized
INFO - 2018-11-26 11:51:52 --> Security Class Initialized
DEBUG - 2018-11-26 11:51:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-26 11:51:52 --> Input Class Initialized
INFO - 2018-11-26 11:51:52 --> Language Class Initialized
ERROR - 2018-11-26 11:51:52 --> Severity: Parsing Error --> syntax error, unexpected ';' C:\xampp\htdocs\wetinuneed\application\controllers\admin\Admin.php 228
INFO - 2018-11-26 11:53:00 --> Config Class Initialized
INFO - 2018-11-26 11:53:00 --> Hooks Class Initialized
DEBUG - 2018-11-26 11:53:00 --> UTF-8 Support Enabled
INFO - 2018-11-26 11:53:00 --> Utf8 Class Initialized
INFO - 2018-11-26 11:53:00 --> URI Class Initialized
INFO - 2018-11-26 11:53:00 --> Router Class Initialized
INFO - 2018-11-26 11:53:00 --> Output Class Initialized
INFO - 2018-11-26 11:53:00 --> Security Class Initialized
DEBUG - 2018-11-26 11:53:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-26 11:53:00 --> Input Class Initialized
INFO - 2018-11-26 11:53:00 --> Language Class Initialized
ERROR - 2018-11-26 11:53:00 --> Severity: Parsing Error --> syntax error, unexpected ';' C:\xampp\htdocs\wetinuneed\application\controllers\admin\Admin.php 228
INFO - 2018-11-26 11:54:30 --> Config Class Initialized
INFO - 2018-11-26 11:54:30 --> Hooks Class Initialized
DEBUG - 2018-11-26 11:54:30 --> UTF-8 Support Enabled
INFO - 2018-11-26 11:54:30 --> Utf8 Class Initialized
INFO - 2018-11-26 11:54:30 --> URI Class Initialized
INFO - 2018-11-26 11:54:30 --> Router Class Initialized
INFO - 2018-11-26 11:54:30 --> Output Class Initialized
INFO - 2018-11-26 11:54:30 --> Security Class Initialized
DEBUG - 2018-11-26 11:54:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-26 11:54:30 --> Input Class Initialized
INFO - 2018-11-26 11:54:30 --> Language Class Initialized
ERROR - 2018-11-26 11:54:30 --> Severity: Parsing Error --> syntax error, unexpected ';' C:\xampp\htdocs\wetinuneed\application\controllers\admin\Admin.php 228
INFO - 2018-11-26 11:54:41 --> Config Class Initialized
INFO - 2018-11-26 11:54:41 --> Hooks Class Initialized
DEBUG - 2018-11-26 11:54:41 --> UTF-8 Support Enabled
INFO - 2018-11-26 11:54:41 --> Utf8 Class Initialized
INFO - 2018-11-26 11:54:41 --> URI Class Initialized
INFO - 2018-11-26 11:54:41 --> Router Class Initialized
INFO - 2018-11-26 11:54:41 --> Output Class Initialized
INFO - 2018-11-26 11:54:41 --> Security Class Initialized
DEBUG - 2018-11-26 11:54:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-26 11:54:41 --> Input Class Initialized
INFO - 2018-11-26 11:54:41 --> Language Class Initialized
INFO - 2018-11-26 11:54:41 --> Loader Class Initialized
INFO - 2018-11-26 11:54:41 --> Helper loaded: url_helper
INFO - 2018-11-26 11:54:41 --> Helper loaded: file_helper
INFO - 2018-11-26 11:54:41 --> Helper loaded: email_helper
INFO - 2018-11-26 11:54:41 --> Helper loaded: common_helper
INFO - 2018-11-26 11:54:41 --> Database Driver Class Initialized
DEBUG - 2018-11-26 11:54:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-26 11:54:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-26 11:54:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-26 11:54:41 --> Pagination Class Initialized
INFO - 2018-11-26 11:54:41 --> Helper loaded: form_helper
INFO - 2018-11-26 11:54:41 --> Form Validation Class Initialized
INFO - 2018-11-26 11:54:41 --> Model Class Initialized
INFO - 2018-11-26 11:54:41 --> Controller Class Initialized
INFO - 2018-11-26 11:54:41 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-26 11:54:41 --> Model Class Initialized
INFO - 2018-11-26 11:54:41 --> Model Class Initialized
INFO - 2018-11-26 11:54:41 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/reset-password.php
INFO - 2018-11-26 11:54:41 --> Final output sent to browser
DEBUG - 2018-11-26 11:54:41 --> Total execution time: 0.1980
INFO - 2018-11-26 12:20:31 --> Config Class Initialized
INFO - 2018-11-26 12:20:31 --> Hooks Class Initialized
DEBUG - 2018-11-26 12:20:31 --> UTF-8 Support Enabled
INFO - 2018-11-26 12:20:31 --> Utf8 Class Initialized
INFO - 2018-11-26 12:20:31 --> URI Class Initialized
INFO - 2018-11-26 12:20:31 --> Router Class Initialized
INFO - 2018-11-26 12:20:31 --> Output Class Initialized
INFO - 2018-11-26 12:20:31 --> Security Class Initialized
DEBUG - 2018-11-26 12:20:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-26 12:20:31 --> Input Class Initialized
INFO - 2018-11-26 12:20:31 --> Language Class Initialized
INFO - 2018-11-26 12:20:31 --> Loader Class Initialized
INFO - 2018-11-26 12:20:31 --> Helper loaded: url_helper
INFO - 2018-11-26 12:20:31 --> Helper loaded: file_helper
INFO - 2018-11-26 12:20:31 --> Helper loaded: email_helper
INFO - 2018-11-26 12:20:31 --> Helper loaded: common_helper
INFO - 2018-11-26 12:20:31 --> Database Driver Class Initialized
DEBUG - 2018-11-26 12:20:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-26 12:20:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-26 12:20:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-26 12:20:31 --> Pagination Class Initialized
INFO - 2018-11-26 12:20:31 --> Helper loaded: form_helper
INFO - 2018-11-26 12:20:31 --> Form Validation Class Initialized
INFO - 2018-11-26 12:20:31 --> Model Class Initialized
INFO - 2018-11-26 12:20:31 --> Controller Class Initialized
INFO - 2018-11-26 12:20:31 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-26 12:20:31 --> Model Class Initialized
INFO - 2018-11-26 12:20:31 --> Model Class Initialized
INFO - 2018-11-26 12:20:31 --> Config Class Initialized
INFO - 2018-11-26 12:20:31 --> Hooks Class Initialized
DEBUG - 2018-11-26 12:20:31 --> UTF-8 Support Enabled
INFO - 2018-11-26 12:20:31 --> Utf8 Class Initialized
INFO - 2018-11-26 12:20:31 --> URI Class Initialized
INFO - 2018-11-26 12:20:31 --> Router Class Initialized
INFO - 2018-11-26 12:20:31 --> Output Class Initialized
INFO - 2018-11-26 12:20:31 --> Security Class Initialized
DEBUG - 2018-11-26 12:20:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-26 12:20:31 --> Input Class Initialized
INFO - 2018-11-26 12:20:31 --> Language Class Initialized
INFO - 2018-11-26 12:20:31 --> Loader Class Initialized
INFO - 2018-11-26 12:20:31 --> Helper loaded: url_helper
INFO - 2018-11-26 12:20:31 --> Helper loaded: file_helper
INFO - 2018-11-26 12:20:31 --> Helper loaded: email_helper
INFO - 2018-11-26 12:20:31 --> Helper loaded: common_helper
INFO - 2018-11-26 12:20:31 --> Database Driver Class Initialized
DEBUG - 2018-11-26 12:20:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-26 12:20:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-26 12:20:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-26 12:20:31 --> Pagination Class Initialized
INFO - 2018-11-26 12:20:31 --> Helper loaded: form_helper
INFO - 2018-11-26 12:20:31 --> Form Validation Class Initialized
INFO - 2018-11-26 12:20:31 --> Model Class Initialized
INFO - 2018-11-26 12:20:31 --> Controller Class Initialized
INFO - 2018-11-26 12:20:31 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-26 12:20:31 --> Model Class Initialized
INFO - 2018-11-26 12:20:31 --> Model Class Initialized
INFO - 2018-11-26 12:20:31 --> Config Class Initialized
INFO - 2018-11-26 12:20:31 --> Hooks Class Initialized
DEBUG - 2018-11-26 12:20:31 --> UTF-8 Support Enabled
INFO - 2018-11-26 12:20:31 --> Utf8 Class Initialized
INFO - 2018-11-26 12:20:31 --> URI Class Initialized
INFO - 2018-11-26 12:20:31 --> Router Class Initialized
INFO - 2018-11-26 12:20:31 --> Output Class Initialized
INFO - 2018-11-26 12:20:31 --> Security Class Initialized
DEBUG - 2018-11-26 12:20:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-26 12:20:31 --> Input Class Initialized
INFO - 2018-11-26 12:20:31 --> Language Class Initialized
INFO - 2018-11-26 12:20:31 --> Loader Class Initialized
INFO - 2018-11-26 12:20:31 --> Helper loaded: url_helper
INFO - 2018-11-26 12:20:31 --> Helper loaded: file_helper
INFO - 2018-11-26 12:20:31 --> Helper loaded: email_helper
INFO - 2018-11-26 12:20:31 --> Helper loaded: common_helper
INFO - 2018-11-26 12:20:31 --> Database Driver Class Initialized
DEBUG - 2018-11-26 12:20:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-26 12:20:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-26 12:20:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-26 12:20:31 --> Pagination Class Initialized
INFO - 2018-11-26 12:20:31 --> Helper loaded: form_helper
INFO - 2018-11-26 12:20:31 --> Form Validation Class Initialized
INFO - 2018-11-26 12:20:31 --> Model Class Initialized
INFO - 2018-11-26 12:20:31 --> Controller Class Initialized
INFO - 2018-11-26 12:20:31 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-26 12:20:31 --> Model Class Initialized
INFO - 2018-11-26 12:20:31 --> Model Class Initialized
INFO - 2018-11-26 12:20:31 --> Config Class Initialized
INFO - 2018-11-26 12:20:31 --> Hooks Class Initialized
DEBUG - 2018-11-26 12:20:31 --> UTF-8 Support Enabled
INFO - 2018-11-26 12:20:31 --> Utf8 Class Initialized
INFO - 2018-11-26 12:20:31 --> URI Class Initialized
INFO - 2018-11-26 12:20:31 --> Router Class Initialized
INFO - 2018-11-26 12:20:31 --> Output Class Initialized
INFO - 2018-11-26 12:20:31 --> Security Class Initialized
DEBUG - 2018-11-26 12:20:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-26 12:20:31 --> Input Class Initialized
INFO - 2018-11-26 12:20:31 --> Language Class Initialized
INFO - 2018-11-26 12:20:31 --> Loader Class Initialized
INFO - 2018-11-26 12:20:31 --> Helper loaded: url_helper
INFO - 2018-11-26 12:20:31 --> Helper loaded: file_helper
INFO - 2018-11-26 12:20:31 --> Helper loaded: email_helper
INFO - 2018-11-26 12:20:31 --> Helper loaded: common_helper
INFO - 2018-11-26 12:20:31 --> Database Driver Class Initialized
DEBUG - 2018-11-26 12:20:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-26 12:20:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-26 12:20:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-26 12:20:31 --> Pagination Class Initialized
INFO - 2018-11-26 12:20:31 --> Helper loaded: form_helper
INFO - 2018-11-26 12:20:31 --> Form Validation Class Initialized
INFO - 2018-11-26 12:20:31 --> Model Class Initialized
INFO - 2018-11-26 12:20:31 --> Controller Class Initialized
INFO - 2018-11-26 12:20:31 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-26 12:20:31 --> Model Class Initialized
INFO - 2018-11-26 12:20:31 --> Model Class Initialized
INFO - 2018-11-26 12:20:31 --> Config Class Initialized
INFO - 2018-11-26 12:20:31 --> Hooks Class Initialized
DEBUG - 2018-11-26 12:20:31 --> UTF-8 Support Enabled
INFO - 2018-11-26 12:20:31 --> Utf8 Class Initialized
INFO - 2018-11-26 12:20:31 --> URI Class Initialized
INFO - 2018-11-26 12:20:31 --> Router Class Initialized
INFO - 2018-11-26 12:20:31 --> Output Class Initialized
INFO - 2018-11-26 12:20:31 --> Security Class Initialized
DEBUG - 2018-11-26 12:20:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-26 12:20:31 --> Input Class Initialized
INFO - 2018-11-26 12:20:31 --> Language Class Initialized
INFO - 2018-11-26 12:20:31 --> Loader Class Initialized
INFO - 2018-11-26 12:20:31 --> Helper loaded: url_helper
INFO - 2018-11-26 12:20:31 --> Helper loaded: file_helper
INFO - 2018-11-26 12:20:31 --> Helper loaded: email_helper
INFO - 2018-11-26 12:20:31 --> Helper loaded: common_helper
INFO - 2018-11-26 12:20:31 --> Database Driver Class Initialized
DEBUG - 2018-11-26 12:20:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-26 12:20:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-26 12:20:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-26 12:20:31 --> Pagination Class Initialized
INFO - 2018-11-26 12:20:31 --> Helper loaded: form_helper
INFO - 2018-11-26 12:20:31 --> Form Validation Class Initialized
INFO - 2018-11-26 12:20:31 --> Model Class Initialized
INFO - 2018-11-26 12:20:31 --> Controller Class Initialized
INFO - 2018-11-26 12:20:31 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-26 12:20:31 --> Model Class Initialized
INFO - 2018-11-26 12:20:31 --> Model Class Initialized
INFO - 2018-11-26 12:20:31 --> Config Class Initialized
INFO - 2018-11-26 12:20:31 --> Hooks Class Initialized
DEBUG - 2018-11-26 12:20:31 --> UTF-8 Support Enabled
INFO - 2018-11-26 12:20:31 --> Utf8 Class Initialized
INFO - 2018-11-26 12:20:31 --> URI Class Initialized
INFO - 2018-11-26 12:20:31 --> Router Class Initialized
INFO - 2018-11-26 12:20:31 --> Output Class Initialized
INFO - 2018-11-26 12:20:31 --> Security Class Initialized
DEBUG - 2018-11-26 12:20:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-26 12:20:31 --> Input Class Initialized
INFO - 2018-11-26 12:20:31 --> Language Class Initialized
INFO - 2018-11-26 12:20:31 --> Loader Class Initialized
INFO - 2018-11-26 12:20:31 --> Helper loaded: url_helper
INFO - 2018-11-26 12:20:31 --> Helper loaded: file_helper
INFO - 2018-11-26 12:20:31 --> Helper loaded: email_helper
INFO - 2018-11-26 12:20:31 --> Helper loaded: common_helper
INFO - 2018-11-26 12:20:31 --> Database Driver Class Initialized
DEBUG - 2018-11-26 12:20:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-26 12:20:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-26 12:20:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-26 12:20:31 --> Pagination Class Initialized
INFO - 2018-11-26 12:20:31 --> Helper loaded: form_helper
INFO - 2018-11-26 12:20:31 --> Form Validation Class Initialized
INFO - 2018-11-26 12:20:31 --> Model Class Initialized
INFO - 2018-11-26 12:20:31 --> Controller Class Initialized
INFO - 2018-11-26 12:20:31 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-26 12:20:31 --> Model Class Initialized
INFO - 2018-11-26 12:20:31 --> Model Class Initialized
INFO - 2018-11-26 12:20:31 --> Config Class Initialized
INFO - 2018-11-26 12:20:31 --> Hooks Class Initialized
DEBUG - 2018-11-26 12:20:31 --> UTF-8 Support Enabled
INFO - 2018-11-26 12:20:31 --> Utf8 Class Initialized
INFO - 2018-11-26 12:20:31 --> URI Class Initialized
INFO - 2018-11-26 12:20:31 --> Router Class Initialized
INFO - 2018-11-26 12:20:31 --> Output Class Initialized
INFO - 2018-11-26 12:20:31 --> Security Class Initialized
DEBUG - 2018-11-26 12:20:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-26 12:20:31 --> Input Class Initialized
INFO - 2018-11-26 12:20:31 --> Language Class Initialized
INFO - 2018-11-26 12:20:31 --> Loader Class Initialized
INFO - 2018-11-26 12:20:31 --> Helper loaded: url_helper
INFO - 2018-11-26 12:20:31 --> Helper loaded: file_helper
INFO - 2018-11-26 12:20:31 --> Helper loaded: email_helper
INFO - 2018-11-26 12:20:31 --> Helper loaded: common_helper
INFO - 2018-11-26 12:20:31 --> Database Driver Class Initialized
DEBUG - 2018-11-26 12:20:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-26 12:20:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-26 12:20:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-26 12:20:31 --> Pagination Class Initialized
INFO - 2018-11-26 12:20:31 --> Helper loaded: form_helper
INFO - 2018-11-26 12:20:31 --> Form Validation Class Initialized
INFO - 2018-11-26 12:20:31 --> Model Class Initialized
INFO - 2018-11-26 12:20:31 --> Controller Class Initialized
INFO - 2018-11-26 12:20:31 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-26 12:20:31 --> Model Class Initialized
INFO - 2018-11-26 12:20:31 --> Model Class Initialized
INFO - 2018-11-26 12:20:31 --> Config Class Initialized
INFO - 2018-11-26 12:20:31 --> Hooks Class Initialized
DEBUG - 2018-11-26 12:20:31 --> UTF-8 Support Enabled
INFO - 2018-11-26 12:20:31 --> Utf8 Class Initialized
INFO - 2018-11-26 12:20:31 --> URI Class Initialized
INFO - 2018-11-26 12:20:31 --> Router Class Initialized
INFO - 2018-11-26 12:20:31 --> Output Class Initialized
INFO - 2018-11-26 12:20:31 --> Security Class Initialized
DEBUG - 2018-11-26 12:20:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-26 12:20:31 --> Input Class Initialized
INFO - 2018-11-26 12:20:31 --> Language Class Initialized
INFO - 2018-11-26 12:20:31 --> Loader Class Initialized
INFO - 2018-11-26 12:20:31 --> Helper loaded: url_helper
INFO - 2018-11-26 12:20:31 --> Helper loaded: file_helper
INFO - 2018-11-26 12:20:31 --> Helper loaded: email_helper
INFO - 2018-11-26 12:20:31 --> Helper loaded: common_helper
INFO - 2018-11-26 12:20:31 --> Database Driver Class Initialized
DEBUG - 2018-11-26 12:20:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-26 12:20:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-26 12:20:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-26 12:20:31 --> Pagination Class Initialized
INFO - 2018-11-26 12:20:31 --> Helper loaded: form_helper
INFO - 2018-11-26 12:20:31 --> Form Validation Class Initialized
INFO - 2018-11-26 12:20:31 --> Model Class Initialized
INFO - 2018-11-26 12:20:31 --> Controller Class Initialized
INFO - 2018-11-26 12:20:31 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-26 12:20:31 --> Model Class Initialized
INFO - 2018-11-26 12:20:31 --> Model Class Initialized
INFO - 2018-11-26 12:20:31 --> Config Class Initialized
INFO - 2018-11-26 12:20:31 --> Hooks Class Initialized
DEBUG - 2018-11-26 12:20:31 --> UTF-8 Support Enabled
INFO - 2018-11-26 12:20:31 --> Utf8 Class Initialized
INFO - 2018-11-26 12:20:31 --> URI Class Initialized
INFO - 2018-11-26 12:20:31 --> Router Class Initialized
INFO - 2018-11-26 12:20:31 --> Output Class Initialized
INFO - 2018-11-26 12:20:31 --> Security Class Initialized
DEBUG - 2018-11-26 12:20:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-26 12:20:31 --> Input Class Initialized
INFO - 2018-11-26 12:20:31 --> Language Class Initialized
INFO - 2018-11-26 12:20:31 --> Loader Class Initialized
INFO - 2018-11-26 12:20:31 --> Helper loaded: url_helper
INFO - 2018-11-26 12:20:31 --> Helper loaded: file_helper
INFO - 2018-11-26 12:20:31 --> Helper loaded: email_helper
INFO - 2018-11-26 12:20:31 --> Helper loaded: common_helper
INFO - 2018-11-26 12:20:31 --> Database Driver Class Initialized
DEBUG - 2018-11-26 12:20:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-26 12:20:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-26 12:20:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-26 12:20:31 --> Pagination Class Initialized
INFO - 2018-11-26 12:20:31 --> Helper loaded: form_helper
INFO - 2018-11-26 12:20:31 --> Form Validation Class Initialized
INFO - 2018-11-26 12:20:31 --> Model Class Initialized
INFO - 2018-11-26 12:20:31 --> Controller Class Initialized
INFO - 2018-11-26 12:20:31 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-26 12:20:31 --> Model Class Initialized
INFO - 2018-11-26 12:20:31 --> Model Class Initialized
INFO - 2018-11-26 12:20:31 --> Config Class Initialized
INFO - 2018-11-26 12:20:31 --> Hooks Class Initialized
DEBUG - 2018-11-26 12:20:31 --> UTF-8 Support Enabled
INFO - 2018-11-26 12:20:31 --> Utf8 Class Initialized
INFO - 2018-11-26 12:20:31 --> URI Class Initialized
INFO - 2018-11-26 12:20:31 --> Router Class Initialized
INFO - 2018-11-26 12:20:31 --> Output Class Initialized
INFO - 2018-11-26 12:20:31 --> Security Class Initialized
DEBUG - 2018-11-26 12:20:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-26 12:20:31 --> Input Class Initialized
INFO - 2018-11-26 12:20:31 --> Language Class Initialized
INFO - 2018-11-26 12:20:31 --> Loader Class Initialized
INFO - 2018-11-26 12:20:31 --> Helper loaded: url_helper
INFO - 2018-11-26 12:20:31 --> Helper loaded: file_helper
INFO - 2018-11-26 12:20:31 --> Helper loaded: email_helper
INFO - 2018-11-26 12:20:31 --> Helper loaded: common_helper
INFO - 2018-11-26 12:20:31 --> Database Driver Class Initialized
DEBUG - 2018-11-26 12:20:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-26 12:20:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-26 12:20:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-26 12:20:32 --> Pagination Class Initialized
INFO - 2018-11-26 12:20:32 --> Helper loaded: form_helper
INFO - 2018-11-26 12:20:32 --> Form Validation Class Initialized
INFO - 2018-11-26 12:20:32 --> Model Class Initialized
INFO - 2018-11-26 12:20:32 --> Controller Class Initialized
INFO - 2018-11-26 12:20:32 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-26 12:20:32 --> Model Class Initialized
INFO - 2018-11-26 12:20:32 --> Model Class Initialized
INFO - 2018-11-26 12:20:32 --> Config Class Initialized
INFO - 2018-11-26 12:20:32 --> Hooks Class Initialized
DEBUG - 2018-11-26 12:20:32 --> UTF-8 Support Enabled
INFO - 2018-11-26 12:20:32 --> Utf8 Class Initialized
INFO - 2018-11-26 12:20:32 --> URI Class Initialized
INFO - 2018-11-26 12:20:32 --> Router Class Initialized
INFO - 2018-11-26 12:20:32 --> Output Class Initialized
INFO - 2018-11-26 12:20:32 --> Security Class Initialized
DEBUG - 2018-11-26 12:20:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-26 12:20:32 --> Input Class Initialized
INFO - 2018-11-26 12:20:32 --> Language Class Initialized
INFO - 2018-11-26 12:20:32 --> Loader Class Initialized
INFO - 2018-11-26 12:20:32 --> Helper loaded: url_helper
INFO - 2018-11-26 12:20:32 --> Helper loaded: file_helper
INFO - 2018-11-26 12:20:32 --> Helper loaded: email_helper
INFO - 2018-11-26 12:20:32 --> Helper loaded: common_helper
INFO - 2018-11-26 12:20:32 --> Database Driver Class Initialized
DEBUG - 2018-11-26 12:20:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-26 12:20:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-26 12:20:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-26 12:20:32 --> Pagination Class Initialized
INFO - 2018-11-26 12:20:32 --> Helper loaded: form_helper
INFO - 2018-11-26 12:20:32 --> Form Validation Class Initialized
INFO - 2018-11-26 12:20:32 --> Model Class Initialized
INFO - 2018-11-26 12:20:32 --> Controller Class Initialized
INFO - 2018-11-26 12:20:32 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-26 12:20:32 --> Model Class Initialized
INFO - 2018-11-26 12:20:32 --> Model Class Initialized
INFO - 2018-11-26 12:20:32 --> Config Class Initialized
INFO - 2018-11-26 12:20:32 --> Hooks Class Initialized
DEBUG - 2018-11-26 12:20:32 --> UTF-8 Support Enabled
INFO - 2018-11-26 12:20:32 --> Utf8 Class Initialized
INFO - 2018-11-26 12:20:32 --> URI Class Initialized
INFO - 2018-11-26 12:20:32 --> Router Class Initialized
INFO - 2018-11-26 12:20:32 --> Output Class Initialized
INFO - 2018-11-26 12:20:32 --> Security Class Initialized
DEBUG - 2018-11-26 12:20:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-26 12:20:32 --> Input Class Initialized
INFO - 2018-11-26 12:20:32 --> Language Class Initialized
INFO - 2018-11-26 12:20:32 --> Loader Class Initialized
INFO - 2018-11-26 12:20:32 --> Helper loaded: url_helper
INFO - 2018-11-26 12:20:32 --> Helper loaded: file_helper
INFO - 2018-11-26 12:20:32 --> Helper loaded: email_helper
INFO - 2018-11-26 12:20:32 --> Helper loaded: common_helper
INFO - 2018-11-26 12:20:32 --> Database Driver Class Initialized
DEBUG - 2018-11-26 12:20:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-26 12:20:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-26 12:20:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-26 12:20:32 --> Pagination Class Initialized
INFO - 2018-11-26 12:20:32 --> Helper loaded: form_helper
INFO - 2018-11-26 12:20:32 --> Form Validation Class Initialized
INFO - 2018-11-26 12:20:32 --> Model Class Initialized
INFO - 2018-11-26 12:20:32 --> Controller Class Initialized
INFO - 2018-11-26 12:20:32 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-26 12:20:32 --> Model Class Initialized
INFO - 2018-11-26 12:20:32 --> Model Class Initialized
INFO - 2018-11-26 12:20:32 --> Config Class Initialized
INFO - 2018-11-26 12:20:32 --> Hooks Class Initialized
DEBUG - 2018-11-26 12:20:32 --> UTF-8 Support Enabled
INFO - 2018-11-26 12:20:32 --> Utf8 Class Initialized
INFO - 2018-11-26 12:20:32 --> URI Class Initialized
INFO - 2018-11-26 12:20:32 --> Router Class Initialized
INFO - 2018-11-26 12:20:32 --> Output Class Initialized
INFO - 2018-11-26 12:20:32 --> Security Class Initialized
DEBUG - 2018-11-26 12:20:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-26 12:20:32 --> Input Class Initialized
INFO - 2018-11-26 12:20:32 --> Language Class Initialized
INFO - 2018-11-26 12:20:32 --> Loader Class Initialized
INFO - 2018-11-26 12:20:32 --> Helper loaded: url_helper
INFO - 2018-11-26 12:20:32 --> Helper loaded: file_helper
INFO - 2018-11-26 12:20:32 --> Helper loaded: email_helper
INFO - 2018-11-26 12:20:32 --> Helper loaded: common_helper
INFO - 2018-11-26 12:20:32 --> Database Driver Class Initialized
DEBUG - 2018-11-26 12:20:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-26 12:20:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-26 12:20:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-26 12:20:32 --> Pagination Class Initialized
INFO - 2018-11-26 12:20:32 --> Helper loaded: form_helper
INFO - 2018-11-26 12:20:32 --> Form Validation Class Initialized
INFO - 2018-11-26 12:20:32 --> Model Class Initialized
INFO - 2018-11-26 12:20:32 --> Controller Class Initialized
INFO - 2018-11-26 12:20:32 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-26 12:20:32 --> Model Class Initialized
INFO - 2018-11-26 12:20:32 --> Model Class Initialized
INFO - 2018-11-26 12:20:32 --> Config Class Initialized
INFO - 2018-11-26 12:20:32 --> Hooks Class Initialized
DEBUG - 2018-11-26 12:20:32 --> UTF-8 Support Enabled
INFO - 2018-11-26 12:20:32 --> Utf8 Class Initialized
INFO - 2018-11-26 12:20:32 --> URI Class Initialized
INFO - 2018-11-26 12:20:32 --> Router Class Initialized
INFO - 2018-11-26 12:20:32 --> Output Class Initialized
INFO - 2018-11-26 12:20:32 --> Security Class Initialized
DEBUG - 2018-11-26 12:20:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-26 12:20:32 --> Input Class Initialized
INFO - 2018-11-26 12:20:32 --> Language Class Initialized
INFO - 2018-11-26 12:20:32 --> Loader Class Initialized
INFO - 2018-11-26 12:20:32 --> Helper loaded: url_helper
INFO - 2018-11-26 12:20:32 --> Helper loaded: file_helper
INFO - 2018-11-26 12:20:32 --> Helper loaded: email_helper
INFO - 2018-11-26 12:20:32 --> Helper loaded: common_helper
INFO - 2018-11-26 12:20:32 --> Database Driver Class Initialized
DEBUG - 2018-11-26 12:20:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-26 12:20:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-26 12:20:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-26 12:20:32 --> Pagination Class Initialized
INFO - 2018-11-26 12:20:32 --> Helper loaded: form_helper
INFO - 2018-11-26 12:20:32 --> Form Validation Class Initialized
INFO - 2018-11-26 12:20:32 --> Model Class Initialized
INFO - 2018-11-26 12:20:32 --> Controller Class Initialized
INFO - 2018-11-26 12:20:32 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-26 12:20:32 --> Model Class Initialized
INFO - 2018-11-26 12:20:32 --> Model Class Initialized
INFO - 2018-11-26 12:20:32 --> Config Class Initialized
INFO - 2018-11-26 12:20:32 --> Hooks Class Initialized
DEBUG - 2018-11-26 12:20:32 --> UTF-8 Support Enabled
INFO - 2018-11-26 12:20:32 --> Utf8 Class Initialized
INFO - 2018-11-26 12:20:32 --> URI Class Initialized
INFO - 2018-11-26 12:20:32 --> Router Class Initialized
INFO - 2018-11-26 12:20:32 --> Output Class Initialized
INFO - 2018-11-26 12:20:32 --> Security Class Initialized
DEBUG - 2018-11-26 12:20:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-26 12:20:32 --> Input Class Initialized
INFO - 2018-11-26 12:20:32 --> Language Class Initialized
INFO - 2018-11-26 12:20:32 --> Loader Class Initialized
INFO - 2018-11-26 12:20:32 --> Helper loaded: url_helper
INFO - 2018-11-26 12:20:32 --> Helper loaded: file_helper
INFO - 2018-11-26 12:20:32 --> Helper loaded: email_helper
INFO - 2018-11-26 12:20:32 --> Helper loaded: common_helper
INFO - 2018-11-26 12:20:32 --> Database Driver Class Initialized
DEBUG - 2018-11-26 12:20:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-26 12:20:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-26 12:20:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-26 12:20:32 --> Pagination Class Initialized
INFO - 2018-11-26 12:20:32 --> Helper loaded: form_helper
INFO - 2018-11-26 12:20:32 --> Form Validation Class Initialized
INFO - 2018-11-26 12:20:32 --> Model Class Initialized
INFO - 2018-11-26 12:20:32 --> Controller Class Initialized
INFO - 2018-11-26 12:20:32 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-26 12:20:32 --> Model Class Initialized
INFO - 2018-11-26 12:20:32 --> Model Class Initialized
INFO - 2018-11-26 12:20:32 --> Config Class Initialized
INFO - 2018-11-26 12:20:32 --> Hooks Class Initialized
DEBUG - 2018-11-26 12:20:32 --> UTF-8 Support Enabled
INFO - 2018-11-26 12:20:32 --> Utf8 Class Initialized
INFO - 2018-11-26 12:20:32 --> URI Class Initialized
INFO - 2018-11-26 12:20:32 --> Router Class Initialized
INFO - 2018-11-26 12:20:32 --> Output Class Initialized
INFO - 2018-11-26 12:20:32 --> Security Class Initialized
DEBUG - 2018-11-26 12:20:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-26 12:20:32 --> Input Class Initialized
INFO - 2018-11-26 12:20:32 --> Language Class Initialized
INFO - 2018-11-26 12:20:32 --> Loader Class Initialized
INFO - 2018-11-26 12:20:32 --> Helper loaded: url_helper
INFO - 2018-11-26 12:20:32 --> Helper loaded: file_helper
INFO - 2018-11-26 12:20:32 --> Helper loaded: email_helper
INFO - 2018-11-26 12:20:32 --> Helper loaded: common_helper
INFO - 2018-11-26 12:20:32 --> Database Driver Class Initialized
DEBUG - 2018-11-26 12:20:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-26 12:20:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-26 12:20:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-26 12:20:32 --> Pagination Class Initialized
INFO - 2018-11-26 12:20:32 --> Helper loaded: form_helper
INFO - 2018-11-26 12:20:32 --> Form Validation Class Initialized
INFO - 2018-11-26 12:20:32 --> Model Class Initialized
INFO - 2018-11-26 12:20:32 --> Controller Class Initialized
INFO - 2018-11-26 12:20:32 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-26 12:20:32 --> Model Class Initialized
INFO - 2018-11-26 12:20:32 --> Model Class Initialized
INFO - 2018-11-26 12:20:32 --> Config Class Initialized
INFO - 2018-11-26 12:20:32 --> Hooks Class Initialized
DEBUG - 2018-11-26 12:20:32 --> UTF-8 Support Enabled
INFO - 2018-11-26 12:20:32 --> Utf8 Class Initialized
INFO - 2018-11-26 12:20:32 --> URI Class Initialized
INFO - 2018-11-26 12:20:32 --> Router Class Initialized
INFO - 2018-11-26 12:20:32 --> Output Class Initialized
INFO - 2018-11-26 12:20:32 --> Security Class Initialized
DEBUG - 2018-11-26 12:20:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-26 12:20:32 --> Input Class Initialized
INFO - 2018-11-26 12:20:32 --> Language Class Initialized
INFO - 2018-11-26 12:20:32 --> Loader Class Initialized
INFO - 2018-11-26 12:20:32 --> Helper loaded: url_helper
INFO - 2018-11-26 12:20:32 --> Helper loaded: file_helper
INFO - 2018-11-26 12:20:32 --> Helper loaded: email_helper
INFO - 2018-11-26 12:20:32 --> Helper loaded: common_helper
INFO - 2018-11-26 12:20:32 --> Database Driver Class Initialized
DEBUG - 2018-11-26 12:20:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-26 12:20:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-26 12:20:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-26 12:20:32 --> Pagination Class Initialized
INFO - 2018-11-26 12:20:32 --> Helper loaded: form_helper
INFO - 2018-11-26 12:20:32 --> Form Validation Class Initialized
INFO - 2018-11-26 12:20:32 --> Model Class Initialized
INFO - 2018-11-26 12:20:32 --> Controller Class Initialized
INFO - 2018-11-26 12:20:32 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-26 12:20:32 --> Model Class Initialized
INFO - 2018-11-26 12:20:32 --> Model Class Initialized
INFO - 2018-11-26 12:20:32 --> Config Class Initialized
INFO - 2018-11-26 12:20:32 --> Hooks Class Initialized
DEBUG - 2018-11-26 12:20:32 --> UTF-8 Support Enabled
INFO - 2018-11-26 12:20:32 --> Utf8 Class Initialized
INFO - 2018-11-26 12:20:32 --> URI Class Initialized
INFO - 2018-11-26 12:20:32 --> Router Class Initialized
INFO - 2018-11-26 12:20:32 --> Output Class Initialized
INFO - 2018-11-26 12:20:32 --> Security Class Initialized
DEBUG - 2018-11-26 12:20:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-26 12:20:32 --> Input Class Initialized
INFO - 2018-11-26 12:20:32 --> Language Class Initialized
INFO - 2018-11-26 12:20:32 --> Loader Class Initialized
INFO - 2018-11-26 12:20:32 --> Helper loaded: url_helper
INFO - 2018-11-26 12:20:32 --> Helper loaded: file_helper
INFO - 2018-11-26 12:20:32 --> Helper loaded: email_helper
INFO - 2018-11-26 12:20:32 --> Helper loaded: common_helper
INFO - 2018-11-26 12:20:32 --> Database Driver Class Initialized
DEBUG - 2018-11-26 12:20:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-26 12:20:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-26 12:20:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-26 12:20:32 --> Pagination Class Initialized
INFO - 2018-11-26 12:20:32 --> Helper loaded: form_helper
INFO - 2018-11-26 12:20:32 --> Form Validation Class Initialized
INFO - 2018-11-26 12:20:32 --> Model Class Initialized
INFO - 2018-11-26 12:20:32 --> Controller Class Initialized
INFO - 2018-11-26 12:20:32 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-26 12:20:32 --> Model Class Initialized
INFO - 2018-11-26 12:20:32 --> Model Class Initialized
INFO - 2018-11-26 12:20:32 --> Config Class Initialized
INFO - 2018-11-26 12:20:32 --> Hooks Class Initialized
DEBUG - 2018-11-26 12:20:32 --> UTF-8 Support Enabled
INFO - 2018-11-26 12:20:32 --> Utf8 Class Initialized
INFO - 2018-11-26 12:20:32 --> URI Class Initialized
INFO - 2018-11-26 12:20:32 --> Router Class Initialized
INFO - 2018-11-26 12:20:32 --> Output Class Initialized
INFO - 2018-11-26 12:20:32 --> Security Class Initialized
DEBUG - 2018-11-26 12:20:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-26 12:20:32 --> Input Class Initialized
INFO - 2018-11-26 12:20:32 --> Language Class Initialized
INFO - 2018-11-26 12:20:32 --> Loader Class Initialized
INFO - 2018-11-26 12:20:32 --> Helper loaded: url_helper
INFO - 2018-11-26 12:20:32 --> Helper loaded: file_helper
INFO - 2018-11-26 12:20:32 --> Helper loaded: email_helper
INFO - 2018-11-26 12:20:32 --> Helper loaded: common_helper
INFO - 2018-11-26 12:20:32 --> Database Driver Class Initialized
DEBUG - 2018-11-26 12:20:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-26 12:20:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-26 12:20:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-26 12:20:32 --> Pagination Class Initialized
INFO - 2018-11-26 12:20:32 --> Helper loaded: form_helper
INFO - 2018-11-26 12:20:32 --> Form Validation Class Initialized
INFO - 2018-11-26 12:20:32 --> Model Class Initialized
INFO - 2018-11-26 12:20:32 --> Controller Class Initialized
INFO - 2018-11-26 12:20:32 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-26 12:20:32 --> Model Class Initialized
INFO - 2018-11-26 12:20:32 --> Model Class Initialized
INFO - 2018-11-26 12:20:32 --> Config Class Initialized
INFO - 2018-11-26 12:20:32 --> Hooks Class Initialized
DEBUG - 2018-11-26 12:20:32 --> UTF-8 Support Enabled
INFO - 2018-11-26 12:20:32 --> Utf8 Class Initialized
INFO - 2018-11-26 12:20:32 --> URI Class Initialized
INFO - 2018-11-26 12:20:32 --> Router Class Initialized
INFO - 2018-11-26 12:20:32 --> Output Class Initialized
INFO - 2018-11-26 12:20:32 --> Security Class Initialized
DEBUG - 2018-11-26 12:20:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-26 12:20:32 --> Input Class Initialized
INFO - 2018-11-26 12:20:32 --> Language Class Initialized
INFO - 2018-11-26 12:20:32 --> Loader Class Initialized
INFO - 2018-11-26 12:20:32 --> Helper loaded: url_helper
INFO - 2018-11-26 12:20:32 --> Helper loaded: file_helper
INFO - 2018-11-26 12:20:32 --> Helper loaded: email_helper
INFO - 2018-11-26 12:20:32 --> Helper loaded: common_helper
INFO - 2018-11-26 12:20:32 --> Database Driver Class Initialized
DEBUG - 2018-11-26 12:20:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-26 12:20:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-26 12:20:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-26 12:20:32 --> Pagination Class Initialized
INFO - 2018-11-26 12:20:32 --> Helper loaded: form_helper
INFO - 2018-11-26 12:20:32 --> Form Validation Class Initialized
INFO - 2018-11-26 12:20:32 --> Model Class Initialized
INFO - 2018-11-26 12:20:32 --> Controller Class Initialized
INFO - 2018-11-26 12:20:32 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-26 12:20:32 --> Model Class Initialized
INFO - 2018-11-26 12:20:32 --> Model Class Initialized
INFO - 2018-11-26 12:20:33 --> Config Class Initialized
INFO - 2018-11-26 12:20:33 --> Hooks Class Initialized
DEBUG - 2018-11-26 12:20:33 --> UTF-8 Support Enabled
INFO - 2018-11-26 12:20:33 --> Utf8 Class Initialized
INFO - 2018-11-26 12:20:33 --> URI Class Initialized
INFO - 2018-11-26 12:20:33 --> Router Class Initialized
INFO - 2018-11-26 12:20:33 --> Output Class Initialized
INFO - 2018-11-26 12:20:33 --> Security Class Initialized
DEBUG - 2018-11-26 12:20:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-26 12:20:33 --> Input Class Initialized
INFO - 2018-11-26 12:20:33 --> Language Class Initialized
INFO - 2018-11-26 12:20:33 --> Loader Class Initialized
INFO - 2018-11-26 12:20:33 --> Helper loaded: url_helper
INFO - 2018-11-26 12:20:33 --> Helper loaded: file_helper
INFO - 2018-11-26 12:20:33 --> Helper loaded: email_helper
INFO - 2018-11-26 12:20:33 --> Helper loaded: common_helper
INFO - 2018-11-26 12:20:33 --> Database Driver Class Initialized
DEBUG - 2018-11-26 12:20:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-26 12:20:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-26 12:20:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-26 12:20:33 --> Pagination Class Initialized
INFO - 2018-11-26 12:20:33 --> Helper loaded: form_helper
INFO - 2018-11-26 12:20:33 --> Form Validation Class Initialized
INFO - 2018-11-26 12:20:33 --> Model Class Initialized
INFO - 2018-11-26 12:20:33 --> Controller Class Initialized
INFO - 2018-11-26 12:20:33 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-26 12:20:33 --> Model Class Initialized
INFO - 2018-11-26 12:20:33 --> Model Class Initialized
INFO - 2018-11-26 12:20:33 --> Config Class Initialized
INFO - 2018-11-26 12:20:33 --> Hooks Class Initialized
DEBUG - 2018-11-26 12:20:33 --> UTF-8 Support Enabled
INFO - 2018-11-26 12:20:33 --> Utf8 Class Initialized
INFO - 2018-11-26 12:20:33 --> URI Class Initialized
INFO - 2018-11-26 12:20:33 --> Router Class Initialized
INFO - 2018-11-26 12:20:33 --> Output Class Initialized
INFO - 2018-11-26 12:20:33 --> Security Class Initialized
DEBUG - 2018-11-26 12:20:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-26 12:20:33 --> Input Class Initialized
INFO - 2018-11-26 12:20:33 --> Language Class Initialized
INFO - 2018-11-26 12:20:33 --> Loader Class Initialized
INFO - 2018-11-26 12:20:33 --> Helper loaded: url_helper
INFO - 2018-11-26 12:20:33 --> Helper loaded: file_helper
INFO - 2018-11-26 12:20:33 --> Helper loaded: email_helper
INFO - 2018-11-26 12:20:33 --> Helper loaded: common_helper
INFO - 2018-11-26 12:20:33 --> Database Driver Class Initialized
DEBUG - 2018-11-26 12:20:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-26 12:20:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-26 12:20:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-26 12:20:33 --> Pagination Class Initialized
INFO - 2018-11-26 12:20:33 --> Helper loaded: form_helper
INFO - 2018-11-26 12:20:33 --> Form Validation Class Initialized
INFO - 2018-11-26 12:20:33 --> Model Class Initialized
INFO - 2018-11-26 12:20:33 --> Controller Class Initialized
INFO - 2018-11-26 12:20:33 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-26 12:20:33 --> Model Class Initialized
INFO - 2018-11-26 12:20:33 --> Model Class Initialized
INFO - 2018-11-26 12:20:33 --> Config Class Initialized
INFO - 2018-11-26 12:20:33 --> Hooks Class Initialized
DEBUG - 2018-11-26 12:20:33 --> UTF-8 Support Enabled
INFO - 2018-11-26 12:20:33 --> Utf8 Class Initialized
INFO - 2018-11-26 12:20:33 --> URI Class Initialized
INFO - 2018-11-26 12:20:33 --> Router Class Initialized
INFO - 2018-11-26 12:20:33 --> Output Class Initialized
INFO - 2018-11-26 12:20:33 --> Security Class Initialized
DEBUG - 2018-11-26 12:20:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-26 12:20:33 --> Input Class Initialized
INFO - 2018-11-26 12:20:33 --> Language Class Initialized
INFO - 2018-11-26 12:20:33 --> Loader Class Initialized
INFO - 2018-11-26 12:20:33 --> Helper loaded: url_helper
INFO - 2018-11-26 12:20:33 --> Helper loaded: file_helper
INFO - 2018-11-26 12:20:33 --> Helper loaded: email_helper
INFO - 2018-11-26 12:20:33 --> Helper loaded: common_helper
INFO - 2018-11-26 12:20:33 --> Database Driver Class Initialized
DEBUG - 2018-11-26 12:20:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-26 12:20:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-26 12:20:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-26 12:20:33 --> Pagination Class Initialized
INFO - 2018-11-26 12:20:33 --> Helper loaded: form_helper
INFO - 2018-11-26 12:20:33 --> Form Validation Class Initialized
INFO - 2018-11-26 12:20:33 --> Model Class Initialized
INFO - 2018-11-26 12:20:33 --> Controller Class Initialized
INFO - 2018-11-26 12:20:33 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-26 12:20:33 --> Model Class Initialized
INFO - 2018-11-26 12:20:33 --> Model Class Initialized
INFO - 2018-11-26 12:20:33 --> Config Class Initialized
INFO - 2018-11-26 12:20:33 --> Hooks Class Initialized
DEBUG - 2018-11-26 12:20:33 --> UTF-8 Support Enabled
INFO - 2018-11-26 12:20:33 --> Utf8 Class Initialized
INFO - 2018-11-26 12:20:33 --> URI Class Initialized
INFO - 2018-11-26 12:20:33 --> Router Class Initialized
INFO - 2018-11-26 12:20:33 --> Output Class Initialized
INFO - 2018-11-26 12:20:33 --> Security Class Initialized
DEBUG - 2018-11-26 12:20:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-26 12:20:33 --> Input Class Initialized
INFO - 2018-11-26 12:20:33 --> Language Class Initialized
INFO - 2018-11-26 12:20:33 --> Loader Class Initialized
INFO - 2018-11-26 12:20:33 --> Helper loaded: url_helper
INFO - 2018-11-26 12:20:33 --> Helper loaded: file_helper
INFO - 2018-11-26 12:20:33 --> Helper loaded: email_helper
INFO - 2018-11-26 12:20:33 --> Helper loaded: common_helper
INFO - 2018-11-26 12:20:33 --> Database Driver Class Initialized
DEBUG - 2018-11-26 12:20:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-26 12:20:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-26 12:20:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-26 12:20:33 --> Pagination Class Initialized
INFO - 2018-11-26 12:20:33 --> Helper loaded: form_helper
INFO - 2018-11-26 12:20:33 --> Form Validation Class Initialized
INFO - 2018-11-26 12:20:33 --> Model Class Initialized
INFO - 2018-11-26 12:20:33 --> Controller Class Initialized
INFO - 2018-11-26 12:20:33 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-26 12:20:33 --> Model Class Initialized
INFO - 2018-11-26 12:20:33 --> Model Class Initialized
INFO - 2018-11-26 12:20:33 --> Config Class Initialized
INFO - 2018-11-26 12:20:33 --> Hooks Class Initialized
DEBUG - 2018-11-26 12:20:33 --> UTF-8 Support Enabled
INFO - 2018-11-26 12:20:33 --> Utf8 Class Initialized
INFO - 2018-11-26 12:20:33 --> URI Class Initialized
INFO - 2018-11-26 12:20:33 --> Router Class Initialized
INFO - 2018-11-26 12:20:33 --> Output Class Initialized
INFO - 2018-11-26 12:20:33 --> Security Class Initialized
DEBUG - 2018-11-26 12:20:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-26 12:20:33 --> Input Class Initialized
INFO - 2018-11-26 12:20:33 --> Language Class Initialized
INFO - 2018-11-26 12:20:33 --> Loader Class Initialized
INFO - 2018-11-26 12:20:33 --> Helper loaded: url_helper
INFO - 2018-11-26 12:20:33 --> Helper loaded: file_helper
INFO - 2018-11-26 12:20:33 --> Helper loaded: email_helper
INFO - 2018-11-26 12:20:33 --> Helper loaded: common_helper
INFO - 2018-11-26 12:20:33 --> Database Driver Class Initialized
DEBUG - 2018-11-26 12:20:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-26 12:20:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-26 12:20:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-26 12:20:33 --> Pagination Class Initialized
INFO - 2018-11-26 12:20:33 --> Helper loaded: form_helper
INFO - 2018-11-26 12:20:33 --> Form Validation Class Initialized
INFO - 2018-11-26 12:20:33 --> Model Class Initialized
INFO - 2018-11-26 12:20:33 --> Controller Class Initialized
INFO - 2018-11-26 12:20:33 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-26 12:20:33 --> Model Class Initialized
INFO - 2018-11-26 12:20:33 --> Model Class Initialized
INFO - 2018-11-26 12:20:33 --> Config Class Initialized
INFO - 2018-11-26 12:20:33 --> Hooks Class Initialized
DEBUG - 2018-11-26 12:20:33 --> UTF-8 Support Enabled
INFO - 2018-11-26 12:20:33 --> Utf8 Class Initialized
INFO - 2018-11-26 12:20:33 --> URI Class Initialized
INFO - 2018-11-26 12:20:33 --> Router Class Initialized
INFO - 2018-11-26 12:20:33 --> Output Class Initialized
INFO - 2018-11-26 12:20:33 --> Security Class Initialized
DEBUG - 2018-11-26 12:20:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-26 12:20:33 --> Input Class Initialized
INFO - 2018-11-26 12:20:33 --> Language Class Initialized
INFO - 2018-11-26 12:20:33 --> Loader Class Initialized
INFO - 2018-11-26 12:20:33 --> Helper loaded: url_helper
INFO - 2018-11-26 12:20:33 --> Helper loaded: file_helper
INFO - 2018-11-26 12:20:33 --> Helper loaded: email_helper
INFO - 2018-11-26 12:20:33 --> Helper loaded: common_helper
INFO - 2018-11-26 12:20:33 --> Database Driver Class Initialized
DEBUG - 2018-11-26 12:20:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-26 12:20:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-26 12:20:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-26 12:20:33 --> Pagination Class Initialized
INFO - 2018-11-26 12:20:33 --> Helper loaded: form_helper
INFO - 2018-11-26 12:20:33 --> Form Validation Class Initialized
INFO - 2018-11-26 12:20:33 --> Model Class Initialized
INFO - 2018-11-26 12:20:33 --> Controller Class Initialized
INFO - 2018-11-26 12:20:33 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-26 12:20:33 --> Model Class Initialized
INFO - 2018-11-26 12:20:33 --> Model Class Initialized
INFO - 2018-11-26 12:20:33 --> Config Class Initialized
INFO - 2018-11-26 12:20:33 --> Hooks Class Initialized
DEBUG - 2018-11-26 12:20:33 --> UTF-8 Support Enabled
INFO - 2018-11-26 12:20:33 --> Utf8 Class Initialized
INFO - 2018-11-26 12:20:33 --> URI Class Initialized
INFO - 2018-11-26 12:20:33 --> Router Class Initialized
INFO - 2018-11-26 12:20:33 --> Output Class Initialized
INFO - 2018-11-26 12:20:33 --> Security Class Initialized
DEBUG - 2018-11-26 12:20:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-26 12:20:33 --> Input Class Initialized
INFO - 2018-11-26 12:20:33 --> Language Class Initialized
INFO - 2018-11-26 12:20:33 --> Loader Class Initialized
INFO - 2018-11-26 12:20:33 --> Helper loaded: url_helper
INFO - 2018-11-26 12:20:33 --> Helper loaded: file_helper
INFO - 2018-11-26 12:20:33 --> Helper loaded: email_helper
INFO - 2018-11-26 12:20:33 --> Helper loaded: common_helper
INFO - 2018-11-26 12:20:33 --> Database Driver Class Initialized
DEBUG - 2018-11-26 12:20:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-26 12:20:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-26 12:20:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-26 12:20:33 --> Pagination Class Initialized
INFO - 2018-11-26 12:20:33 --> Helper loaded: form_helper
INFO - 2018-11-26 12:20:33 --> Form Validation Class Initialized
INFO - 2018-11-26 12:20:33 --> Model Class Initialized
INFO - 2018-11-26 12:20:33 --> Controller Class Initialized
INFO - 2018-11-26 12:20:33 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-26 12:20:33 --> Model Class Initialized
INFO - 2018-11-26 12:20:33 --> Model Class Initialized
INFO - 2018-11-26 12:20:33 --> Config Class Initialized
INFO - 2018-11-26 12:20:33 --> Hooks Class Initialized
DEBUG - 2018-11-26 12:20:33 --> UTF-8 Support Enabled
INFO - 2018-11-26 12:20:33 --> Utf8 Class Initialized
INFO - 2018-11-26 12:20:33 --> URI Class Initialized
INFO - 2018-11-26 12:20:33 --> Router Class Initialized
INFO - 2018-11-26 12:20:33 --> Output Class Initialized
INFO - 2018-11-26 12:20:33 --> Security Class Initialized
DEBUG - 2018-11-26 12:20:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-26 12:20:33 --> Input Class Initialized
INFO - 2018-11-26 12:20:33 --> Language Class Initialized
INFO - 2018-11-26 12:20:33 --> Loader Class Initialized
INFO - 2018-11-26 12:20:33 --> Helper loaded: url_helper
INFO - 2018-11-26 12:20:33 --> Helper loaded: file_helper
INFO - 2018-11-26 12:20:33 --> Helper loaded: email_helper
INFO - 2018-11-26 12:20:33 --> Helper loaded: common_helper
INFO - 2018-11-26 12:20:33 --> Database Driver Class Initialized
DEBUG - 2018-11-26 12:20:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-26 12:20:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-26 12:20:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-26 12:20:33 --> Pagination Class Initialized
INFO - 2018-11-26 12:20:33 --> Helper loaded: form_helper
INFO - 2018-11-26 12:20:33 --> Form Validation Class Initialized
INFO - 2018-11-26 12:20:33 --> Model Class Initialized
INFO - 2018-11-26 12:20:33 --> Controller Class Initialized
INFO - 2018-11-26 12:20:33 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-26 12:20:33 --> Model Class Initialized
INFO - 2018-11-26 12:20:33 --> Model Class Initialized
INFO - 2018-11-26 12:20:33 --> Config Class Initialized
INFO - 2018-11-26 12:20:33 --> Hooks Class Initialized
DEBUG - 2018-11-26 12:20:33 --> UTF-8 Support Enabled
INFO - 2018-11-26 12:20:33 --> Utf8 Class Initialized
INFO - 2018-11-26 12:20:33 --> URI Class Initialized
INFO - 2018-11-26 12:20:33 --> Router Class Initialized
INFO - 2018-11-26 12:20:33 --> Output Class Initialized
INFO - 2018-11-26 12:20:33 --> Security Class Initialized
DEBUG - 2018-11-26 12:20:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-26 12:20:33 --> Input Class Initialized
INFO - 2018-11-26 12:20:33 --> Language Class Initialized
INFO - 2018-11-26 12:20:33 --> Loader Class Initialized
INFO - 2018-11-26 12:20:33 --> Helper loaded: url_helper
INFO - 2018-11-26 12:20:33 --> Helper loaded: file_helper
INFO - 2018-11-26 12:20:33 --> Helper loaded: email_helper
INFO - 2018-11-26 12:20:33 --> Helper loaded: common_helper
INFO - 2018-11-26 12:20:33 --> Database Driver Class Initialized
DEBUG - 2018-11-26 12:20:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-26 12:20:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-26 12:20:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-26 12:20:33 --> Pagination Class Initialized
INFO - 2018-11-26 12:20:33 --> Helper loaded: form_helper
INFO - 2018-11-26 12:20:33 --> Form Validation Class Initialized
INFO - 2018-11-26 12:20:33 --> Model Class Initialized
INFO - 2018-11-26 12:20:33 --> Controller Class Initialized
INFO - 2018-11-26 12:20:33 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-26 12:20:33 --> Model Class Initialized
INFO - 2018-11-26 12:20:33 --> Model Class Initialized
INFO - 2018-11-26 12:20:33 --> Config Class Initialized
INFO - 2018-11-26 12:20:33 --> Hooks Class Initialized
DEBUG - 2018-11-26 12:20:33 --> UTF-8 Support Enabled
INFO - 2018-11-26 12:20:33 --> Utf8 Class Initialized
INFO - 2018-11-26 12:20:33 --> URI Class Initialized
INFO - 2018-11-26 12:20:33 --> Router Class Initialized
INFO - 2018-11-26 12:20:33 --> Output Class Initialized
INFO - 2018-11-26 12:20:33 --> Security Class Initialized
DEBUG - 2018-11-26 12:20:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-26 12:20:33 --> Input Class Initialized
INFO - 2018-11-26 12:20:33 --> Language Class Initialized
INFO - 2018-11-26 12:20:33 --> Loader Class Initialized
INFO - 2018-11-26 12:20:33 --> Helper loaded: url_helper
INFO - 2018-11-26 12:20:33 --> Helper loaded: file_helper
INFO - 2018-11-26 12:20:33 --> Helper loaded: email_helper
INFO - 2018-11-26 12:20:33 --> Helper loaded: common_helper
INFO - 2018-11-26 12:20:33 --> Database Driver Class Initialized
DEBUG - 2018-11-26 12:20:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-26 12:20:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-26 12:20:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-26 12:20:33 --> Pagination Class Initialized
INFO - 2018-11-26 12:20:33 --> Helper loaded: form_helper
INFO - 2018-11-26 12:20:33 --> Form Validation Class Initialized
INFO - 2018-11-26 12:20:33 --> Model Class Initialized
INFO - 2018-11-26 12:20:33 --> Controller Class Initialized
INFO - 2018-11-26 12:20:33 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-26 12:20:33 --> Model Class Initialized
INFO - 2018-11-26 12:20:33 --> Model Class Initialized
INFO - 2018-11-26 12:20:33 --> Config Class Initialized
INFO - 2018-11-26 12:20:33 --> Hooks Class Initialized
DEBUG - 2018-11-26 12:20:33 --> UTF-8 Support Enabled
INFO - 2018-11-26 12:20:33 --> Utf8 Class Initialized
INFO - 2018-11-26 12:20:33 --> URI Class Initialized
INFO - 2018-11-26 12:20:33 --> Router Class Initialized
INFO - 2018-11-26 12:20:33 --> Output Class Initialized
INFO - 2018-11-26 12:20:33 --> Security Class Initialized
DEBUG - 2018-11-26 12:20:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-26 12:20:33 --> Input Class Initialized
INFO - 2018-11-26 12:20:33 --> Language Class Initialized
INFO - 2018-11-26 12:20:34 --> Loader Class Initialized
INFO - 2018-11-26 12:20:34 --> Helper loaded: url_helper
INFO - 2018-11-26 12:20:34 --> Helper loaded: file_helper
INFO - 2018-11-26 12:20:34 --> Helper loaded: email_helper
INFO - 2018-11-26 12:20:34 --> Helper loaded: common_helper
INFO - 2018-11-26 12:20:34 --> Database Driver Class Initialized
DEBUG - 2018-11-26 12:20:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-26 12:20:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-26 12:20:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-26 12:20:34 --> Pagination Class Initialized
INFO - 2018-11-26 12:20:34 --> Helper loaded: form_helper
INFO - 2018-11-26 12:20:34 --> Form Validation Class Initialized
INFO - 2018-11-26 12:20:34 --> Model Class Initialized
INFO - 2018-11-26 12:20:34 --> Controller Class Initialized
INFO - 2018-11-26 12:20:34 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-26 12:20:34 --> Model Class Initialized
INFO - 2018-11-26 12:20:34 --> Model Class Initialized
INFO - 2018-11-26 12:20:34 --> Config Class Initialized
INFO - 2018-11-26 12:20:34 --> Hooks Class Initialized
DEBUG - 2018-11-26 12:20:34 --> UTF-8 Support Enabled
INFO - 2018-11-26 12:20:34 --> Utf8 Class Initialized
INFO - 2018-11-26 12:20:34 --> URI Class Initialized
INFO - 2018-11-26 12:20:34 --> Router Class Initialized
INFO - 2018-11-26 12:20:34 --> Output Class Initialized
INFO - 2018-11-26 12:20:34 --> Security Class Initialized
DEBUG - 2018-11-26 12:20:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-26 12:20:34 --> Input Class Initialized
INFO - 2018-11-26 12:20:34 --> Language Class Initialized
INFO - 2018-11-26 12:20:34 --> Loader Class Initialized
INFO - 2018-11-26 12:20:34 --> Helper loaded: url_helper
INFO - 2018-11-26 12:20:34 --> Helper loaded: file_helper
INFO - 2018-11-26 12:20:34 --> Helper loaded: email_helper
INFO - 2018-11-26 12:20:34 --> Helper loaded: common_helper
INFO - 2018-11-26 12:20:34 --> Database Driver Class Initialized
DEBUG - 2018-11-26 12:20:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-26 12:20:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-26 12:20:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-26 12:20:34 --> Pagination Class Initialized
INFO - 2018-11-26 12:20:34 --> Helper loaded: form_helper
INFO - 2018-11-26 12:20:34 --> Form Validation Class Initialized
INFO - 2018-11-26 12:20:34 --> Model Class Initialized
INFO - 2018-11-26 12:20:34 --> Controller Class Initialized
INFO - 2018-11-26 12:20:34 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-26 12:20:34 --> Model Class Initialized
INFO - 2018-11-26 12:20:34 --> Model Class Initialized
INFO - 2018-11-26 12:20:34 --> Config Class Initialized
INFO - 2018-11-26 12:20:34 --> Hooks Class Initialized
DEBUG - 2018-11-26 12:20:34 --> UTF-8 Support Enabled
INFO - 2018-11-26 12:20:34 --> Utf8 Class Initialized
INFO - 2018-11-26 12:20:34 --> URI Class Initialized
INFO - 2018-11-26 12:20:34 --> Router Class Initialized
INFO - 2018-11-26 12:20:34 --> Output Class Initialized
INFO - 2018-11-26 12:20:34 --> Security Class Initialized
DEBUG - 2018-11-26 12:20:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-26 12:20:34 --> Input Class Initialized
INFO - 2018-11-26 12:20:34 --> Language Class Initialized
INFO - 2018-11-26 12:20:34 --> Loader Class Initialized
INFO - 2018-11-26 12:20:34 --> Helper loaded: url_helper
INFO - 2018-11-26 12:20:34 --> Helper loaded: file_helper
INFO - 2018-11-26 12:20:34 --> Helper loaded: email_helper
INFO - 2018-11-26 12:20:34 --> Helper loaded: common_helper
INFO - 2018-11-26 12:20:34 --> Database Driver Class Initialized
DEBUG - 2018-11-26 12:20:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-26 12:20:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-26 12:20:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-26 12:20:34 --> Pagination Class Initialized
INFO - 2018-11-26 12:20:34 --> Helper loaded: form_helper
INFO - 2018-11-26 12:20:34 --> Form Validation Class Initialized
INFO - 2018-11-26 12:20:34 --> Model Class Initialized
INFO - 2018-11-26 12:20:34 --> Controller Class Initialized
INFO - 2018-11-26 12:20:34 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-26 12:20:34 --> Model Class Initialized
INFO - 2018-11-26 12:20:34 --> Model Class Initialized
INFO - 2018-11-26 12:20:34 --> Config Class Initialized
INFO - 2018-11-26 12:20:34 --> Hooks Class Initialized
DEBUG - 2018-11-26 12:20:34 --> UTF-8 Support Enabled
INFO - 2018-11-26 12:20:34 --> Utf8 Class Initialized
INFO - 2018-11-26 12:20:34 --> URI Class Initialized
INFO - 2018-11-26 12:20:34 --> Router Class Initialized
INFO - 2018-11-26 12:20:34 --> Output Class Initialized
INFO - 2018-11-26 12:20:34 --> Security Class Initialized
DEBUG - 2018-11-26 12:20:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-26 12:20:34 --> Input Class Initialized
INFO - 2018-11-26 12:20:34 --> Language Class Initialized
INFO - 2018-11-26 12:20:34 --> Loader Class Initialized
INFO - 2018-11-26 12:20:34 --> Helper loaded: url_helper
INFO - 2018-11-26 12:20:34 --> Helper loaded: file_helper
INFO - 2018-11-26 12:20:34 --> Helper loaded: email_helper
INFO - 2018-11-26 12:20:34 --> Helper loaded: common_helper
INFO - 2018-11-26 12:20:34 --> Database Driver Class Initialized
DEBUG - 2018-11-26 12:20:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-26 12:20:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-26 12:20:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-26 12:20:34 --> Pagination Class Initialized
INFO - 2018-11-26 12:20:34 --> Helper loaded: form_helper
INFO - 2018-11-26 12:20:34 --> Form Validation Class Initialized
INFO - 2018-11-26 12:20:34 --> Model Class Initialized
INFO - 2018-11-26 12:20:34 --> Controller Class Initialized
INFO - 2018-11-26 12:20:34 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-26 12:20:34 --> Model Class Initialized
INFO - 2018-11-26 12:20:34 --> Model Class Initialized
INFO - 2018-11-26 12:20:34 --> Config Class Initialized
INFO - 2018-11-26 12:20:34 --> Hooks Class Initialized
DEBUG - 2018-11-26 12:20:34 --> UTF-8 Support Enabled
INFO - 2018-11-26 12:20:34 --> Utf8 Class Initialized
INFO - 2018-11-26 12:20:34 --> URI Class Initialized
INFO - 2018-11-26 12:20:34 --> Router Class Initialized
INFO - 2018-11-26 12:20:34 --> Output Class Initialized
INFO - 2018-11-26 12:20:34 --> Security Class Initialized
DEBUG - 2018-11-26 12:20:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-26 12:20:34 --> Input Class Initialized
INFO - 2018-11-26 12:20:34 --> Language Class Initialized
INFO - 2018-11-26 12:20:34 --> Loader Class Initialized
INFO - 2018-11-26 12:20:34 --> Helper loaded: url_helper
INFO - 2018-11-26 12:20:34 --> Helper loaded: file_helper
INFO - 2018-11-26 12:20:34 --> Helper loaded: email_helper
INFO - 2018-11-26 12:20:34 --> Helper loaded: common_helper
INFO - 2018-11-26 12:20:34 --> Database Driver Class Initialized
DEBUG - 2018-11-26 12:20:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-26 12:20:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-26 12:20:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-26 12:20:34 --> Pagination Class Initialized
INFO - 2018-11-26 12:20:34 --> Helper loaded: form_helper
INFO - 2018-11-26 12:20:34 --> Form Validation Class Initialized
INFO - 2018-11-26 12:20:34 --> Model Class Initialized
INFO - 2018-11-26 12:20:34 --> Controller Class Initialized
INFO - 2018-11-26 12:20:34 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-26 12:20:34 --> Model Class Initialized
INFO - 2018-11-26 12:20:34 --> Model Class Initialized
INFO - 2018-11-26 12:20:34 --> Config Class Initialized
INFO - 2018-11-26 12:20:34 --> Hooks Class Initialized
DEBUG - 2018-11-26 12:20:34 --> UTF-8 Support Enabled
INFO - 2018-11-26 12:20:34 --> Utf8 Class Initialized
INFO - 2018-11-26 12:20:34 --> URI Class Initialized
INFO - 2018-11-26 12:20:34 --> Router Class Initialized
INFO - 2018-11-26 12:20:34 --> Output Class Initialized
INFO - 2018-11-26 12:20:34 --> Security Class Initialized
DEBUG - 2018-11-26 12:20:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-26 12:20:34 --> Input Class Initialized
INFO - 2018-11-26 12:20:34 --> Language Class Initialized
INFO - 2018-11-26 12:20:34 --> Loader Class Initialized
INFO - 2018-11-26 12:20:34 --> Helper loaded: url_helper
INFO - 2018-11-26 12:20:34 --> Helper loaded: file_helper
INFO - 2018-11-26 12:20:34 --> Helper loaded: email_helper
INFO - 2018-11-26 12:20:34 --> Helper loaded: common_helper
INFO - 2018-11-26 12:20:34 --> Database Driver Class Initialized
DEBUG - 2018-11-26 12:20:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-26 12:20:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-26 12:20:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-26 12:20:34 --> Pagination Class Initialized
INFO - 2018-11-26 12:20:34 --> Helper loaded: form_helper
INFO - 2018-11-26 12:20:34 --> Form Validation Class Initialized
INFO - 2018-11-26 12:20:34 --> Model Class Initialized
INFO - 2018-11-26 12:20:34 --> Controller Class Initialized
INFO - 2018-11-26 12:20:34 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-26 12:20:34 --> Model Class Initialized
INFO - 2018-11-26 12:20:34 --> Model Class Initialized
INFO - 2018-11-26 12:20:34 --> Config Class Initialized
INFO - 2018-11-26 12:20:34 --> Hooks Class Initialized
DEBUG - 2018-11-26 12:20:34 --> UTF-8 Support Enabled
INFO - 2018-11-26 12:20:34 --> Utf8 Class Initialized
INFO - 2018-11-26 12:20:34 --> URI Class Initialized
INFO - 2018-11-26 12:20:34 --> Router Class Initialized
INFO - 2018-11-26 12:20:34 --> Output Class Initialized
INFO - 2018-11-26 12:20:34 --> Security Class Initialized
DEBUG - 2018-11-26 12:20:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-26 12:20:34 --> Input Class Initialized
INFO - 2018-11-26 12:20:34 --> Language Class Initialized
INFO - 2018-11-26 12:20:34 --> Loader Class Initialized
INFO - 2018-11-26 12:20:34 --> Helper loaded: url_helper
INFO - 2018-11-26 12:20:34 --> Helper loaded: file_helper
INFO - 2018-11-26 12:20:34 --> Helper loaded: email_helper
INFO - 2018-11-26 12:20:34 --> Helper loaded: common_helper
INFO - 2018-11-26 12:20:34 --> Database Driver Class Initialized
DEBUG - 2018-11-26 12:20:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-26 12:20:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-26 12:20:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-26 12:20:34 --> Pagination Class Initialized
INFO - 2018-11-26 12:20:34 --> Helper loaded: form_helper
INFO - 2018-11-26 12:20:34 --> Form Validation Class Initialized
INFO - 2018-11-26 12:20:34 --> Model Class Initialized
INFO - 2018-11-26 12:20:34 --> Controller Class Initialized
INFO - 2018-11-26 12:20:34 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-26 12:20:34 --> Model Class Initialized
INFO - 2018-11-26 12:20:34 --> Model Class Initialized
INFO - 2018-11-26 12:20:34 --> Config Class Initialized
INFO - 2018-11-26 12:20:34 --> Hooks Class Initialized
DEBUG - 2018-11-26 12:20:34 --> UTF-8 Support Enabled
INFO - 2018-11-26 12:20:34 --> Utf8 Class Initialized
INFO - 2018-11-26 12:20:34 --> URI Class Initialized
INFO - 2018-11-26 12:20:34 --> Router Class Initialized
INFO - 2018-11-26 12:20:34 --> Output Class Initialized
INFO - 2018-11-26 12:20:34 --> Security Class Initialized
DEBUG - 2018-11-26 12:20:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-26 12:20:34 --> Input Class Initialized
INFO - 2018-11-26 12:20:34 --> Language Class Initialized
INFO - 2018-11-26 12:20:34 --> Loader Class Initialized
INFO - 2018-11-26 12:20:34 --> Helper loaded: url_helper
INFO - 2018-11-26 12:20:34 --> Helper loaded: file_helper
INFO - 2018-11-26 12:20:34 --> Helper loaded: email_helper
INFO - 2018-11-26 12:20:34 --> Helper loaded: common_helper
INFO - 2018-11-26 12:20:34 --> Database Driver Class Initialized
DEBUG - 2018-11-26 12:20:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-26 12:20:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-26 12:20:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-26 12:20:34 --> Pagination Class Initialized
INFO - 2018-11-26 12:20:34 --> Helper loaded: form_helper
INFO - 2018-11-26 12:20:34 --> Form Validation Class Initialized
INFO - 2018-11-26 12:20:34 --> Model Class Initialized
INFO - 2018-11-26 12:20:34 --> Controller Class Initialized
INFO - 2018-11-26 12:20:34 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-26 12:20:34 --> Model Class Initialized
INFO - 2018-11-26 12:20:34 --> Model Class Initialized
INFO - 2018-11-26 12:20:34 --> Config Class Initialized
INFO - 2018-11-26 12:20:34 --> Hooks Class Initialized
DEBUG - 2018-11-26 12:20:34 --> UTF-8 Support Enabled
INFO - 2018-11-26 12:20:34 --> Utf8 Class Initialized
INFO - 2018-11-26 12:20:34 --> URI Class Initialized
INFO - 2018-11-26 12:20:34 --> Router Class Initialized
INFO - 2018-11-26 12:20:34 --> Output Class Initialized
INFO - 2018-11-26 12:20:34 --> Security Class Initialized
DEBUG - 2018-11-26 12:20:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-26 12:20:34 --> Input Class Initialized
INFO - 2018-11-26 12:20:34 --> Language Class Initialized
INFO - 2018-11-26 12:20:34 --> Loader Class Initialized
INFO - 2018-11-26 12:20:34 --> Helper loaded: url_helper
INFO - 2018-11-26 12:20:34 --> Helper loaded: file_helper
INFO - 2018-11-26 12:20:34 --> Helper loaded: email_helper
INFO - 2018-11-26 12:20:34 --> Helper loaded: common_helper
INFO - 2018-11-26 12:20:34 --> Database Driver Class Initialized
DEBUG - 2018-11-26 12:20:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-26 12:20:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-26 12:20:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-26 12:20:34 --> Pagination Class Initialized
INFO - 2018-11-26 12:20:34 --> Helper loaded: form_helper
INFO - 2018-11-26 12:20:34 --> Form Validation Class Initialized
INFO - 2018-11-26 12:20:34 --> Model Class Initialized
INFO - 2018-11-26 12:20:34 --> Controller Class Initialized
INFO - 2018-11-26 12:20:34 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-26 12:20:34 --> Model Class Initialized
INFO - 2018-11-26 12:20:34 --> Model Class Initialized
INFO - 2018-11-26 12:20:34 --> Config Class Initialized
INFO - 2018-11-26 12:20:34 --> Hooks Class Initialized
DEBUG - 2018-11-26 12:20:34 --> UTF-8 Support Enabled
INFO - 2018-11-26 12:20:34 --> Utf8 Class Initialized
INFO - 2018-11-26 12:20:34 --> URI Class Initialized
INFO - 2018-11-26 12:20:34 --> Router Class Initialized
INFO - 2018-11-26 12:20:34 --> Output Class Initialized
INFO - 2018-11-26 12:20:34 --> Security Class Initialized
DEBUG - 2018-11-26 12:20:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-26 12:20:34 --> Input Class Initialized
INFO - 2018-11-26 12:20:34 --> Language Class Initialized
INFO - 2018-11-26 12:20:34 --> Loader Class Initialized
INFO - 2018-11-26 12:20:34 --> Helper loaded: url_helper
INFO - 2018-11-26 12:20:34 --> Helper loaded: file_helper
INFO - 2018-11-26 12:20:34 --> Helper loaded: email_helper
INFO - 2018-11-26 12:20:34 --> Helper loaded: common_helper
INFO - 2018-11-26 12:20:34 --> Database Driver Class Initialized
DEBUG - 2018-11-26 12:20:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-26 12:20:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-26 12:20:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-26 12:20:34 --> Pagination Class Initialized
INFO - 2018-11-26 12:20:34 --> Helper loaded: form_helper
INFO - 2018-11-26 12:20:34 --> Form Validation Class Initialized
INFO - 2018-11-26 12:20:34 --> Model Class Initialized
INFO - 2018-11-26 12:20:34 --> Controller Class Initialized
INFO - 2018-11-26 12:20:34 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-26 12:20:34 --> Model Class Initialized
INFO - 2018-11-26 12:20:34 --> Model Class Initialized
INFO - 2018-11-26 12:20:39 --> Config Class Initialized
INFO - 2018-11-26 12:20:39 --> Hooks Class Initialized
DEBUG - 2018-11-26 12:20:39 --> UTF-8 Support Enabled
INFO - 2018-11-26 12:20:39 --> Utf8 Class Initialized
INFO - 2018-11-26 12:20:39 --> URI Class Initialized
INFO - 2018-11-26 12:20:39 --> Router Class Initialized
INFO - 2018-11-26 12:20:39 --> Output Class Initialized
INFO - 2018-11-26 12:20:39 --> Security Class Initialized
DEBUG - 2018-11-26 12:20:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-26 12:20:39 --> Input Class Initialized
INFO - 2018-11-26 12:20:39 --> Language Class Initialized
INFO - 2018-11-26 12:20:39 --> Loader Class Initialized
INFO - 2018-11-26 12:20:39 --> Helper loaded: url_helper
INFO - 2018-11-26 12:20:39 --> Helper loaded: file_helper
INFO - 2018-11-26 12:20:39 --> Helper loaded: email_helper
INFO - 2018-11-26 12:20:39 --> Helper loaded: common_helper
INFO - 2018-11-26 12:20:39 --> Database Driver Class Initialized
DEBUG - 2018-11-26 12:20:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-26 12:20:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-26 12:20:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-26 12:20:39 --> Pagination Class Initialized
INFO - 2018-11-26 12:20:39 --> Helper loaded: form_helper
INFO - 2018-11-26 12:20:39 --> Form Validation Class Initialized
INFO - 2018-11-26 12:20:39 --> Model Class Initialized
INFO - 2018-11-26 12:20:39 --> Controller Class Initialized
INFO - 2018-11-26 12:20:39 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-26 12:20:39 --> Model Class Initialized
INFO - 2018-11-26 12:20:39 --> Model Class Initialized
INFO - 2018-11-26 12:20:39 --> Config Class Initialized
INFO - 2018-11-26 12:20:39 --> Hooks Class Initialized
DEBUG - 2018-11-26 12:20:39 --> UTF-8 Support Enabled
INFO - 2018-11-26 12:20:39 --> Utf8 Class Initialized
INFO - 2018-11-26 12:20:39 --> URI Class Initialized
INFO - 2018-11-26 12:20:39 --> Router Class Initialized
INFO - 2018-11-26 12:20:39 --> Output Class Initialized
INFO - 2018-11-26 12:20:39 --> Security Class Initialized
DEBUG - 2018-11-26 12:20:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-26 12:20:39 --> Input Class Initialized
INFO - 2018-11-26 12:20:39 --> Language Class Initialized
INFO - 2018-11-26 12:20:39 --> Loader Class Initialized
INFO - 2018-11-26 12:20:39 --> Helper loaded: url_helper
INFO - 2018-11-26 12:20:39 --> Helper loaded: file_helper
INFO - 2018-11-26 12:20:39 --> Helper loaded: email_helper
INFO - 2018-11-26 12:20:39 --> Helper loaded: common_helper
INFO - 2018-11-26 12:20:39 --> Database Driver Class Initialized
DEBUG - 2018-11-26 12:20:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-26 12:20:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-26 12:20:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-26 12:20:39 --> Pagination Class Initialized
INFO - 2018-11-26 12:20:39 --> Helper loaded: form_helper
INFO - 2018-11-26 12:20:39 --> Form Validation Class Initialized
INFO - 2018-11-26 12:20:39 --> Model Class Initialized
INFO - 2018-11-26 12:20:39 --> Controller Class Initialized
INFO - 2018-11-26 12:20:39 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-26 12:20:39 --> Model Class Initialized
INFO - 2018-11-26 12:20:39 --> Model Class Initialized
INFO - 2018-11-26 12:20:39 --> Config Class Initialized
INFO - 2018-11-26 12:20:39 --> Hooks Class Initialized
DEBUG - 2018-11-26 12:20:39 --> UTF-8 Support Enabled
INFO - 2018-11-26 12:20:39 --> Utf8 Class Initialized
INFO - 2018-11-26 12:20:39 --> URI Class Initialized
INFO - 2018-11-26 12:20:39 --> Router Class Initialized
INFO - 2018-11-26 12:20:39 --> Output Class Initialized
INFO - 2018-11-26 12:20:39 --> Security Class Initialized
DEBUG - 2018-11-26 12:20:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-26 12:20:39 --> Input Class Initialized
INFO - 2018-11-26 12:20:39 --> Language Class Initialized
INFO - 2018-11-26 12:20:39 --> Loader Class Initialized
INFO - 2018-11-26 12:20:39 --> Helper loaded: url_helper
INFO - 2018-11-26 12:20:39 --> Helper loaded: file_helper
INFO - 2018-11-26 12:20:39 --> Helper loaded: email_helper
INFO - 2018-11-26 12:20:39 --> Helper loaded: common_helper
INFO - 2018-11-26 12:20:39 --> Database Driver Class Initialized
DEBUG - 2018-11-26 12:20:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-26 12:20:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-26 12:20:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-26 12:20:39 --> Pagination Class Initialized
INFO - 2018-11-26 12:20:39 --> Helper loaded: form_helper
INFO - 2018-11-26 12:20:39 --> Form Validation Class Initialized
INFO - 2018-11-26 12:20:39 --> Model Class Initialized
INFO - 2018-11-26 12:20:39 --> Controller Class Initialized
INFO - 2018-11-26 12:20:40 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-26 12:20:40 --> Model Class Initialized
INFO - 2018-11-26 12:20:40 --> Model Class Initialized
INFO - 2018-11-26 12:20:40 --> Config Class Initialized
INFO - 2018-11-26 12:20:40 --> Hooks Class Initialized
DEBUG - 2018-11-26 12:20:40 --> UTF-8 Support Enabled
INFO - 2018-11-26 12:20:40 --> Utf8 Class Initialized
INFO - 2018-11-26 12:20:40 --> URI Class Initialized
INFO - 2018-11-26 12:20:40 --> Router Class Initialized
INFO - 2018-11-26 12:20:40 --> Output Class Initialized
INFO - 2018-11-26 12:20:40 --> Security Class Initialized
DEBUG - 2018-11-26 12:20:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-26 12:20:40 --> Input Class Initialized
INFO - 2018-11-26 12:20:40 --> Language Class Initialized
INFO - 2018-11-26 12:20:40 --> Loader Class Initialized
INFO - 2018-11-26 12:20:40 --> Helper loaded: url_helper
INFO - 2018-11-26 12:20:40 --> Helper loaded: file_helper
INFO - 2018-11-26 12:20:40 --> Helper loaded: email_helper
INFO - 2018-11-26 12:20:40 --> Helper loaded: common_helper
INFO - 2018-11-26 12:20:40 --> Database Driver Class Initialized
DEBUG - 2018-11-26 12:20:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-26 12:20:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-26 12:20:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-26 12:20:40 --> Pagination Class Initialized
INFO - 2018-11-26 12:20:40 --> Helper loaded: form_helper
INFO - 2018-11-26 12:20:40 --> Form Validation Class Initialized
INFO - 2018-11-26 12:20:40 --> Model Class Initialized
INFO - 2018-11-26 12:20:40 --> Controller Class Initialized
INFO - 2018-11-26 12:20:40 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-26 12:20:40 --> Model Class Initialized
INFO - 2018-11-26 12:20:40 --> Model Class Initialized
INFO - 2018-11-26 12:20:40 --> Config Class Initialized
INFO - 2018-11-26 12:20:40 --> Hooks Class Initialized
DEBUG - 2018-11-26 12:20:40 --> UTF-8 Support Enabled
INFO - 2018-11-26 12:20:40 --> Utf8 Class Initialized
INFO - 2018-11-26 12:20:40 --> URI Class Initialized
INFO - 2018-11-26 12:20:40 --> Router Class Initialized
INFO - 2018-11-26 12:20:40 --> Output Class Initialized
INFO - 2018-11-26 12:20:40 --> Security Class Initialized
DEBUG - 2018-11-26 12:20:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-26 12:20:40 --> Input Class Initialized
INFO - 2018-11-26 12:20:40 --> Language Class Initialized
INFO - 2018-11-26 12:20:40 --> Loader Class Initialized
INFO - 2018-11-26 12:20:40 --> Helper loaded: url_helper
INFO - 2018-11-26 12:20:40 --> Helper loaded: file_helper
INFO - 2018-11-26 12:20:40 --> Helper loaded: email_helper
INFO - 2018-11-26 12:20:40 --> Helper loaded: common_helper
INFO - 2018-11-26 12:20:40 --> Database Driver Class Initialized
DEBUG - 2018-11-26 12:20:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-26 12:20:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-26 12:20:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-26 12:20:40 --> Pagination Class Initialized
INFO - 2018-11-26 12:20:40 --> Helper loaded: form_helper
INFO - 2018-11-26 12:20:40 --> Form Validation Class Initialized
INFO - 2018-11-26 12:20:40 --> Model Class Initialized
INFO - 2018-11-26 12:20:40 --> Controller Class Initialized
INFO - 2018-11-26 12:20:40 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-26 12:20:40 --> Model Class Initialized
INFO - 2018-11-26 12:20:40 --> Model Class Initialized
INFO - 2018-11-26 12:20:40 --> Config Class Initialized
INFO - 2018-11-26 12:20:40 --> Hooks Class Initialized
DEBUG - 2018-11-26 12:20:40 --> UTF-8 Support Enabled
INFO - 2018-11-26 12:20:40 --> Utf8 Class Initialized
INFO - 2018-11-26 12:20:40 --> URI Class Initialized
INFO - 2018-11-26 12:20:40 --> Router Class Initialized
INFO - 2018-11-26 12:20:40 --> Output Class Initialized
INFO - 2018-11-26 12:20:40 --> Security Class Initialized
DEBUG - 2018-11-26 12:20:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-26 12:20:40 --> Input Class Initialized
INFO - 2018-11-26 12:20:40 --> Language Class Initialized
INFO - 2018-11-26 12:20:40 --> Loader Class Initialized
INFO - 2018-11-26 12:20:40 --> Helper loaded: url_helper
INFO - 2018-11-26 12:20:40 --> Helper loaded: file_helper
INFO - 2018-11-26 12:20:40 --> Helper loaded: email_helper
INFO - 2018-11-26 12:20:40 --> Helper loaded: common_helper
INFO - 2018-11-26 12:20:40 --> Database Driver Class Initialized
DEBUG - 2018-11-26 12:20:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-26 12:20:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-26 12:20:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-26 12:20:40 --> Pagination Class Initialized
INFO - 2018-11-26 12:20:40 --> Helper loaded: form_helper
INFO - 2018-11-26 12:20:40 --> Form Validation Class Initialized
INFO - 2018-11-26 12:20:40 --> Model Class Initialized
INFO - 2018-11-26 12:20:40 --> Controller Class Initialized
INFO - 2018-11-26 12:20:40 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-26 12:20:40 --> Model Class Initialized
INFO - 2018-11-26 12:20:40 --> Model Class Initialized
INFO - 2018-11-26 12:20:40 --> Config Class Initialized
INFO - 2018-11-26 12:20:40 --> Hooks Class Initialized
DEBUG - 2018-11-26 12:20:40 --> UTF-8 Support Enabled
INFO - 2018-11-26 12:20:40 --> Utf8 Class Initialized
INFO - 2018-11-26 12:20:40 --> URI Class Initialized
INFO - 2018-11-26 12:20:40 --> Router Class Initialized
INFO - 2018-11-26 12:20:40 --> Output Class Initialized
INFO - 2018-11-26 12:20:40 --> Security Class Initialized
DEBUG - 2018-11-26 12:20:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-26 12:20:40 --> Input Class Initialized
INFO - 2018-11-26 12:20:40 --> Language Class Initialized
INFO - 2018-11-26 12:20:40 --> Loader Class Initialized
INFO - 2018-11-26 12:20:40 --> Helper loaded: url_helper
INFO - 2018-11-26 12:20:40 --> Helper loaded: file_helper
INFO - 2018-11-26 12:20:40 --> Helper loaded: email_helper
INFO - 2018-11-26 12:20:40 --> Helper loaded: common_helper
INFO - 2018-11-26 12:20:40 --> Database Driver Class Initialized
DEBUG - 2018-11-26 12:20:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-26 12:20:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-26 12:20:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-26 12:20:40 --> Pagination Class Initialized
INFO - 2018-11-26 12:20:40 --> Helper loaded: form_helper
INFO - 2018-11-26 12:20:40 --> Form Validation Class Initialized
INFO - 2018-11-26 12:20:40 --> Model Class Initialized
INFO - 2018-11-26 12:20:40 --> Controller Class Initialized
INFO - 2018-11-26 12:20:40 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-26 12:20:40 --> Model Class Initialized
INFO - 2018-11-26 12:20:40 --> Model Class Initialized
INFO - 2018-11-26 12:20:40 --> Config Class Initialized
INFO - 2018-11-26 12:20:40 --> Hooks Class Initialized
DEBUG - 2018-11-26 12:20:40 --> UTF-8 Support Enabled
INFO - 2018-11-26 12:20:40 --> Utf8 Class Initialized
INFO - 2018-11-26 12:20:40 --> URI Class Initialized
INFO - 2018-11-26 12:20:40 --> Router Class Initialized
INFO - 2018-11-26 12:20:40 --> Output Class Initialized
INFO - 2018-11-26 12:20:40 --> Security Class Initialized
DEBUG - 2018-11-26 12:20:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-26 12:20:40 --> Input Class Initialized
INFO - 2018-11-26 12:20:40 --> Language Class Initialized
INFO - 2018-11-26 12:20:40 --> Loader Class Initialized
INFO - 2018-11-26 12:20:40 --> Helper loaded: url_helper
INFO - 2018-11-26 12:20:40 --> Helper loaded: file_helper
INFO - 2018-11-26 12:20:40 --> Helper loaded: email_helper
INFO - 2018-11-26 12:20:40 --> Helper loaded: common_helper
INFO - 2018-11-26 12:20:40 --> Database Driver Class Initialized
DEBUG - 2018-11-26 12:20:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-26 12:20:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-26 12:20:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-26 12:20:40 --> Pagination Class Initialized
INFO - 2018-11-26 12:20:40 --> Helper loaded: form_helper
INFO - 2018-11-26 12:20:40 --> Form Validation Class Initialized
INFO - 2018-11-26 12:20:40 --> Model Class Initialized
INFO - 2018-11-26 12:20:40 --> Controller Class Initialized
INFO - 2018-11-26 12:20:40 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-26 12:20:40 --> Model Class Initialized
INFO - 2018-11-26 12:20:40 --> Model Class Initialized
INFO - 2018-11-26 12:20:40 --> Config Class Initialized
INFO - 2018-11-26 12:20:40 --> Hooks Class Initialized
DEBUG - 2018-11-26 12:20:40 --> UTF-8 Support Enabled
INFO - 2018-11-26 12:20:40 --> Utf8 Class Initialized
INFO - 2018-11-26 12:20:40 --> URI Class Initialized
INFO - 2018-11-26 12:20:40 --> Router Class Initialized
INFO - 2018-11-26 12:20:40 --> Output Class Initialized
INFO - 2018-11-26 12:20:40 --> Security Class Initialized
DEBUG - 2018-11-26 12:20:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-26 12:20:40 --> Input Class Initialized
INFO - 2018-11-26 12:20:40 --> Language Class Initialized
INFO - 2018-11-26 12:20:40 --> Loader Class Initialized
INFO - 2018-11-26 12:20:40 --> Helper loaded: url_helper
INFO - 2018-11-26 12:20:40 --> Helper loaded: file_helper
INFO - 2018-11-26 12:20:40 --> Helper loaded: email_helper
INFO - 2018-11-26 12:20:40 --> Helper loaded: common_helper
INFO - 2018-11-26 12:20:40 --> Database Driver Class Initialized
DEBUG - 2018-11-26 12:20:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-26 12:20:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-26 12:20:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-26 12:20:40 --> Pagination Class Initialized
INFO - 2018-11-26 12:20:40 --> Helper loaded: form_helper
INFO - 2018-11-26 12:20:40 --> Form Validation Class Initialized
INFO - 2018-11-26 12:20:40 --> Model Class Initialized
INFO - 2018-11-26 12:20:40 --> Controller Class Initialized
INFO - 2018-11-26 12:20:40 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-26 12:20:40 --> Model Class Initialized
INFO - 2018-11-26 12:20:40 --> Model Class Initialized
INFO - 2018-11-26 12:20:40 --> Config Class Initialized
INFO - 2018-11-26 12:20:40 --> Hooks Class Initialized
DEBUG - 2018-11-26 12:20:40 --> UTF-8 Support Enabled
INFO - 2018-11-26 12:20:40 --> Utf8 Class Initialized
INFO - 2018-11-26 12:20:40 --> URI Class Initialized
INFO - 2018-11-26 12:20:40 --> Router Class Initialized
INFO - 2018-11-26 12:20:40 --> Output Class Initialized
INFO - 2018-11-26 12:20:40 --> Security Class Initialized
DEBUG - 2018-11-26 12:20:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-26 12:20:40 --> Input Class Initialized
INFO - 2018-11-26 12:20:40 --> Language Class Initialized
INFO - 2018-11-26 12:20:40 --> Loader Class Initialized
INFO - 2018-11-26 12:20:40 --> Helper loaded: url_helper
INFO - 2018-11-26 12:20:40 --> Helper loaded: file_helper
INFO - 2018-11-26 12:20:40 --> Helper loaded: email_helper
INFO - 2018-11-26 12:20:40 --> Helper loaded: common_helper
INFO - 2018-11-26 12:20:40 --> Database Driver Class Initialized
DEBUG - 2018-11-26 12:20:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-26 12:20:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-26 12:20:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-26 12:20:40 --> Pagination Class Initialized
INFO - 2018-11-26 12:20:40 --> Helper loaded: form_helper
INFO - 2018-11-26 12:20:40 --> Form Validation Class Initialized
INFO - 2018-11-26 12:20:40 --> Model Class Initialized
INFO - 2018-11-26 12:20:40 --> Controller Class Initialized
INFO - 2018-11-26 12:20:40 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-26 12:20:40 --> Model Class Initialized
INFO - 2018-11-26 12:20:40 --> Model Class Initialized
INFO - 2018-11-26 12:20:40 --> Config Class Initialized
INFO - 2018-11-26 12:20:40 --> Hooks Class Initialized
DEBUG - 2018-11-26 12:20:40 --> UTF-8 Support Enabled
INFO - 2018-11-26 12:20:40 --> Utf8 Class Initialized
INFO - 2018-11-26 12:20:40 --> URI Class Initialized
INFO - 2018-11-26 12:20:40 --> Router Class Initialized
INFO - 2018-11-26 12:20:40 --> Output Class Initialized
INFO - 2018-11-26 12:20:40 --> Security Class Initialized
DEBUG - 2018-11-26 12:20:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-26 12:20:40 --> Input Class Initialized
INFO - 2018-11-26 12:20:40 --> Language Class Initialized
INFO - 2018-11-26 12:20:40 --> Loader Class Initialized
INFO - 2018-11-26 12:20:40 --> Helper loaded: url_helper
INFO - 2018-11-26 12:20:40 --> Helper loaded: file_helper
INFO - 2018-11-26 12:20:40 --> Helper loaded: email_helper
INFO - 2018-11-26 12:20:40 --> Helper loaded: common_helper
INFO - 2018-11-26 12:20:40 --> Database Driver Class Initialized
DEBUG - 2018-11-26 12:20:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-26 12:20:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-26 12:20:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-26 12:20:40 --> Pagination Class Initialized
INFO - 2018-11-26 12:20:40 --> Helper loaded: form_helper
INFO - 2018-11-26 12:20:40 --> Form Validation Class Initialized
INFO - 2018-11-26 12:20:40 --> Model Class Initialized
INFO - 2018-11-26 12:20:40 --> Controller Class Initialized
INFO - 2018-11-26 12:20:40 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-26 12:20:40 --> Model Class Initialized
INFO - 2018-11-26 12:20:40 --> Model Class Initialized
INFO - 2018-11-26 12:20:40 --> Config Class Initialized
INFO - 2018-11-26 12:20:40 --> Hooks Class Initialized
DEBUG - 2018-11-26 12:20:40 --> UTF-8 Support Enabled
INFO - 2018-11-26 12:20:40 --> Utf8 Class Initialized
INFO - 2018-11-26 12:20:40 --> URI Class Initialized
INFO - 2018-11-26 12:20:40 --> Router Class Initialized
INFO - 2018-11-26 12:20:40 --> Output Class Initialized
INFO - 2018-11-26 12:20:40 --> Security Class Initialized
DEBUG - 2018-11-26 12:20:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-26 12:20:40 --> Input Class Initialized
INFO - 2018-11-26 12:20:40 --> Language Class Initialized
INFO - 2018-11-26 12:20:40 --> Loader Class Initialized
INFO - 2018-11-26 12:20:40 --> Helper loaded: url_helper
INFO - 2018-11-26 12:20:40 --> Helper loaded: file_helper
INFO - 2018-11-26 12:20:40 --> Helper loaded: email_helper
INFO - 2018-11-26 12:20:40 --> Helper loaded: common_helper
INFO - 2018-11-26 12:20:40 --> Database Driver Class Initialized
DEBUG - 2018-11-26 12:20:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-26 12:20:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-26 12:20:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-26 12:20:40 --> Pagination Class Initialized
INFO - 2018-11-26 12:20:40 --> Helper loaded: form_helper
INFO - 2018-11-26 12:20:40 --> Form Validation Class Initialized
INFO - 2018-11-26 12:20:40 --> Model Class Initialized
INFO - 2018-11-26 12:20:40 --> Controller Class Initialized
INFO - 2018-11-26 12:20:40 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-26 12:20:40 --> Model Class Initialized
INFO - 2018-11-26 12:20:40 --> Model Class Initialized
INFO - 2018-11-26 12:20:40 --> Config Class Initialized
INFO - 2018-11-26 12:20:40 --> Hooks Class Initialized
DEBUG - 2018-11-26 12:20:40 --> UTF-8 Support Enabled
INFO - 2018-11-26 12:20:40 --> Utf8 Class Initialized
INFO - 2018-11-26 12:20:40 --> URI Class Initialized
INFO - 2018-11-26 12:20:40 --> Router Class Initialized
INFO - 2018-11-26 12:20:40 --> Output Class Initialized
INFO - 2018-11-26 12:20:40 --> Security Class Initialized
DEBUG - 2018-11-26 12:20:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-26 12:20:40 --> Input Class Initialized
INFO - 2018-11-26 12:20:40 --> Language Class Initialized
INFO - 2018-11-26 12:20:40 --> Loader Class Initialized
INFO - 2018-11-26 12:20:40 --> Helper loaded: url_helper
INFO - 2018-11-26 12:20:40 --> Helper loaded: file_helper
INFO - 2018-11-26 12:20:40 --> Helper loaded: email_helper
INFO - 2018-11-26 12:20:40 --> Helper loaded: common_helper
INFO - 2018-11-26 12:20:40 --> Database Driver Class Initialized
DEBUG - 2018-11-26 12:20:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-26 12:20:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-26 12:20:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-26 12:20:40 --> Pagination Class Initialized
INFO - 2018-11-26 12:20:40 --> Helper loaded: form_helper
INFO - 2018-11-26 12:20:40 --> Form Validation Class Initialized
INFO - 2018-11-26 12:20:40 --> Model Class Initialized
INFO - 2018-11-26 12:20:40 --> Controller Class Initialized
INFO - 2018-11-26 12:20:40 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-26 12:20:40 --> Model Class Initialized
INFO - 2018-11-26 12:20:40 --> Model Class Initialized
INFO - 2018-11-26 12:20:40 --> Config Class Initialized
INFO - 2018-11-26 12:20:40 --> Hooks Class Initialized
DEBUG - 2018-11-26 12:20:40 --> UTF-8 Support Enabled
INFO - 2018-11-26 12:20:40 --> Utf8 Class Initialized
INFO - 2018-11-26 12:20:40 --> URI Class Initialized
INFO - 2018-11-26 12:20:40 --> Router Class Initialized
INFO - 2018-11-26 12:20:40 --> Output Class Initialized
INFO - 2018-11-26 12:20:40 --> Security Class Initialized
DEBUG - 2018-11-26 12:20:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-26 12:20:40 --> Input Class Initialized
INFO - 2018-11-26 12:20:40 --> Language Class Initialized
INFO - 2018-11-26 12:20:40 --> Loader Class Initialized
INFO - 2018-11-26 12:20:40 --> Helper loaded: url_helper
INFO - 2018-11-26 12:20:40 --> Helper loaded: file_helper
INFO - 2018-11-26 12:20:40 --> Helper loaded: email_helper
INFO - 2018-11-26 12:20:40 --> Helper loaded: common_helper
INFO - 2018-11-26 12:20:40 --> Database Driver Class Initialized
DEBUG - 2018-11-26 12:20:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-26 12:20:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-26 12:20:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-26 12:20:40 --> Pagination Class Initialized
INFO - 2018-11-26 12:20:41 --> Helper loaded: form_helper
INFO - 2018-11-26 12:20:41 --> Form Validation Class Initialized
INFO - 2018-11-26 12:20:41 --> Model Class Initialized
INFO - 2018-11-26 12:20:41 --> Controller Class Initialized
INFO - 2018-11-26 12:20:41 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-26 12:20:41 --> Model Class Initialized
INFO - 2018-11-26 12:20:41 --> Model Class Initialized
INFO - 2018-11-26 12:20:41 --> Config Class Initialized
INFO - 2018-11-26 12:20:41 --> Hooks Class Initialized
DEBUG - 2018-11-26 12:20:41 --> UTF-8 Support Enabled
INFO - 2018-11-26 12:20:41 --> Utf8 Class Initialized
INFO - 2018-11-26 12:20:41 --> URI Class Initialized
INFO - 2018-11-26 12:20:41 --> Router Class Initialized
INFO - 2018-11-26 12:20:41 --> Output Class Initialized
INFO - 2018-11-26 12:20:41 --> Security Class Initialized
DEBUG - 2018-11-26 12:20:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-26 12:20:41 --> Input Class Initialized
INFO - 2018-11-26 12:20:41 --> Language Class Initialized
INFO - 2018-11-26 12:20:41 --> Loader Class Initialized
INFO - 2018-11-26 12:20:41 --> Helper loaded: url_helper
INFO - 2018-11-26 12:20:41 --> Helper loaded: file_helper
INFO - 2018-11-26 12:20:41 --> Helper loaded: email_helper
INFO - 2018-11-26 12:20:41 --> Helper loaded: common_helper
INFO - 2018-11-26 12:20:41 --> Database Driver Class Initialized
DEBUG - 2018-11-26 12:20:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-26 12:20:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-26 12:20:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-26 12:20:41 --> Pagination Class Initialized
INFO - 2018-11-26 12:20:41 --> Helper loaded: form_helper
INFO - 2018-11-26 12:20:41 --> Form Validation Class Initialized
INFO - 2018-11-26 12:20:41 --> Model Class Initialized
INFO - 2018-11-26 12:20:41 --> Controller Class Initialized
INFO - 2018-11-26 12:20:41 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-26 12:20:41 --> Model Class Initialized
INFO - 2018-11-26 12:20:41 --> Model Class Initialized
INFO - 2018-11-26 12:20:41 --> Config Class Initialized
INFO - 2018-11-26 12:20:41 --> Hooks Class Initialized
DEBUG - 2018-11-26 12:20:41 --> UTF-8 Support Enabled
INFO - 2018-11-26 12:20:41 --> Utf8 Class Initialized
INFO - 2018-11-26 12:20:41 --> URI Class Initialized
INFO - 2018-11-26 12:20:41 --> Router Class Initialized
INFO - 2018-11-26 12:20:41 --> Output Class Initialized
INFO - 2018-11-26 12:20:41 --> Security Class Initialized
DEBUG - 2018-11-26 12:20:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-26 12:20:41 --> Input Class Initialized
INFO - 2018-11-26 12:20:41 --> Language Class Initialized
INFO - 2018-11-26 12:20:41 --> Loader Class Initialized
INFO - 2018-11-26 12:20:41 --> Helper loaded: url_helper
INFO - 2018-11-26 12:20:41 --> Helper loaded: file_helper
INFO - 2018-11-26 12:20:41 --> Helper loaded: email_helper
INFO - 2018-11-26 12:20:41 --> Helper loaded: common_helper
INFO - 2018-11-26 12:20:41 --> Database Driver Class Initialized
DEBUG - 2018-11-26 12:20:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-26 12:20:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-26 12:20:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-26 12:20:41 --> Pagination Class Initialized
INFO - 2018-11-26 12:20:41 --> Helper loaded: form_helper
INFO - 2018-11-26 12:20:41 --> Form Validation Class Initialized
INFO - 2018-11-26 12:20:41 --> Model Class Initialized
INFO - 2018-11-26 12:20:41 --> Controller Class Initialized
INFO - 2018-11-26 12:20:41 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-26 12:20:41 --> Model Class Initialized
INFO - 2018-11-26 12:20:41 --> Model Class Initialized
INFO - 2018-11-26 12:20:41 --> Config Class Initialized
INFO - 2018-11-26 12:20:41 --> Hooks Class Initialized
DEBUG - 2018-11-26 12:20:41 --> UTF-8 Support Enabled
INFO - 2018-11-26 12:20:41 --> Utf8 Class Initialized
INFO - 2018-11-26 12:20:41 --> URI Class Initialized
INFO - 2018-11-26 12:20:41 --> Router Class Initialized
INFO - 2018-11-26 12:20:41 --> Output Class Initialized
INFO - 2018-11-26 12:20:41 --> Security Class Initialized
DEBUG - 2018-11-26 12:20:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-26 12:20:41 --> Input Class Initialized
INFO - 2018-11-26 12:20:41 --> Language Class Initialized
INFO - 2018-11-26 12:20:41 --> Loader Class Initialized
INFO - 2018-11-26 12:20:41 --> Helper loaded: url_helper
INFO - 2018-11-26 12:20:41 --> Helper loaded: file_helper
INFO - 2018-11-26 12:20:41 --> Helper loaded: email_helper
INFO - 2018-11-26 12:20:41 --> Helper loaded: common_helper
INFO - 2018-11-26 12:20:41 --> Database Driver Class Initialized
DEBUG - 2018-11-26 12:20:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-26 12:20:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-26 12:20:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-26 12:20:41 --> Pagination Class Initialized
INFO - 2018-11-26 12:20:41 --> Helper loaded: form_helper
INFO - 2018-11-26 12:20:41 --> Form Validation Class Initialized
INFO - 2018-11-26 12:20:41 --> Model Class Initialized
INFO - 2018-11-26 12:20:41 --> Controller Class Initialized
INFO - 2018-11-26 12:20:41 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-26 12:20:41 --> Model Class Initialized
INFO - 2018-11-26 12:20:41 --> Model Class Initialized
INFO - 2018-11-26 12:20:41 --> Config Class Initialized
INFO - 2018-11-26 12:20:41 --> Hooks Class Initialized
DEBUG - 2018-11-26 12:20:41 --> UTF-8 Support Enabled
INFO - 2018-11-26 12:20:41 --> Utf8 Class Initialized
INFO - 2018-11-26 12:20:41 --> URI Class Initialized
INFO - 2018-11-26 12:20:41 --> Router Class Initialized
INFO - 2018-11-26 12:20:41 --> Output Class Initialized
INFO - 2018-11-26 12:20:41 --> Security Class Initialized
DEBUG - 2018-11-26 12:20:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-26 12:20:41 --> Input Class Initialized
INFO - 2018-11-26 12:20:41 --> Language Class Initialized
INFO - 2018-11-26 12:20:41 --> Loader Class Initialized
INFO - 2018-11-26 12:20:41 --> Helper loaded: url_helper
INFO - 2018-11-26 12:20:41 --> Helper loaded: file_helper
INFO - 2018-11-26 12:20:41 --> Helper loaded: email_helper
INFO - 2018-11-26 12:20:41 --> Helper loaded: common_helper
INFO - 2018-11-26 12:20:41 --> Database Driver Class Initialized
DEBUG - 2018-11-26 12:20:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-26 12:20:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-26 12:20:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-26 12:20:41 --> Pagination Class Initialized
INFO - 2018-11-26 12:20:41 --> Helper loaded: form_helper
INFO - 2018-11-26 12:20:41 --> Form Validation Class Initialized
INFO - 2018-11-26 12:20:41 --> Model Class Initialized
INFO - 2018-11-26 12:20:41 --> Controller Class Initialized
INFO - 2018-11-26 12:20:41 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-26 12:20:41 --> Model Class Initialized
INFO - 2018-11-26 12:20:41 --> Model Class Initialized
INFO - 2018-11-26 12:20:41 --> Config Class Initialized
INFO - 2018-11-26 12:20:41 --> Hooks Class Initialized
DEBUG - 2018-11-26 12:20:41 --> UTF-8 Support Enabled
INFO - 2018-11-26 12:20:41 --> Utf8 Class Initialized
INFO - 2018-11-26 12:20:41 --> URI Class Initialized
INFO - 2018-11-26 12:20:41 --> Router Class Initialized
INFO - 2018-11-26 12:20:41 --> Output Class Initialized
INFO - 2018-11-26 12:20:41 --> Security Class Initialized
DEBUG - 2018-11-26 12:20:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-26 12:20:41 --> Input Class Initialized
INFO - 2018-11-26 12:20:41 --> Language Class Initialized
INFO - 2018-11-26 12:20:41 --> Loader Class Initialized
INFO - 2018-11-26 12:20:41 --> Helper loaded: url_helper
INFO - 2018-11-26 12:20:41 --> Helper loaded: file_helper
INFO - 2018-11-26 12:20:41 --> Helper loaded: email_helper
INFO - 2018-11-26 12:20:41 --> Helper loaded: common_helper
INFO - 2018-11-26 12:20:41 --> Database Driver Class Initialized
DEBUG - 2018-11-26 12:20:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-26 12:20:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-26 12:20:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-26 12:20:41 --> Pagination Class Initialized
INFO - 2018-11-26 12:20:41 --> Helper loaded: form_helper
INFO - 2018-11-26 12:20:41 --> Form Validation Class Initialized
INFO - 2018-11-26 12:20:41 --> Model Class Initialized
INFO - 2018-11-26 12:20:41 --> Controller Class Initialized
INFO - 2018-11-26 12:20:41 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-26 12:20:41 --> Model Class Initialized
INFO - 2018-11-26 12:20:41 --> Model Class Initialized
INFO - 2018-11-26 12:20:41 --> Config Class Initialized
INFO - 2018-11-26 12:20:41 --> Hooks Class Initialized
DEBUG - 2018-11-26 12:20:41 --> UTF-8 Support Enabled
INFO - 2018-11-26 12:20:41 --> Utf8 Class Initialized
INFO - 2018-11-26 12:20:41 --> URI Class Initialized
INFO - 2018-11-26 12:20:41 --> Router Class Initialized
INFO - 2018-11-26 12:20:41 --> Output Class Initialized
INFO - 2018-11-26 12:20:41 --> Security Class Initialized
DEBUG - 2018-11-26 12:20:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-26 12:20:41 --> Input Class Initialized
INFO - 2018-11-26 12:20:41 --> Language Class Initialized
INFO - 2018-11-26 12:20:41 --> Loader Class Initialized
INFO - 2018-11-26 12:20:41 --> Helper loaded: url_helper
INFO - 2018-11-26 12:20:41 --> Helper loaded: file_helper
INFO - 2018-11-26 12:20:41 --> Helper loaded: email_helper
INFO - 2018-11-26 12:20:41 --> Helper loaded: common_helper
INFO - 2018-11-26 12:20:41 --> Database Driver Class Initialized
DEBUG - 2018-11-26 12:20:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-26 12:20:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-26 12:20:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-26 12:20:41 --> Pagination Class Initialized
INFO - 2018-11-26 12:20:41 --> Helper loaded: form_helper
INFO - 2018-11-26 12:20:41 --> Form Validation Class Initialized
INFO - 2018-11-26 12:20:41 --> Model Class Initialized
INFO - 2018-11-26 12:20:41 --> Controller Class Initialized
INFO - 2018-11-26 12:20:41 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-26 12:20:41 --> Model Class Initialized
INFO - 2018-11-26 12:20:41 --> Model Class Initialized
INFO - 2018-11-26 12:20:46 --> Config Class Initialized
INFO - 2018-11-26 12:20:46 --> Hooks Class Initialized
DEBUG - 2018-11-26 12:20:46 --> UTF-8 Support Enabled
INFO - 2018-11-26 12:20:46 --> Utf8 Class Initialized
INFO - 2018-11-26 12:20:46 --> URI Class Initialized
INFO - 2018-11-26 12:20:46 --> Router Class Initialized
INFO - 2018-11-26 12:20:46 --> Output Class Initialized
INFO - 2018-11-26 12:20:46 --> Security Class Initialized
DEBUG - 2018-11-26 12:20:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-26 12:20:46 --> Input Class Initialized
INFO - 2018-11-26 12:20:46 --> Language Class Initialized
INFO - 2018-11-26 12:20:46 --> Loader Class Initialized
INFO - 2018-11-26 12:20:46 --> Helper loaded: url_helper
INFO - 2018-11-26 12:20:46 --> Helper loaded: file_helper
INFO - 2018-11-26 12:20:46 --> Helper loaded: email_helper
INFO - 2018-11-26 12:20:46 --> Helper loaded: common_helper
INFO - 2018-11-26 12:20:46 --> Database Driver Class Initialized
DEBUG - 2018-11-26 12:20:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-26 12:20:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-26 12:20:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-26 12:20:46 --> Pagination Class Initialized
INFO - 2018-11-26 12:20:46 --> Helper loaded: form_helper
INFO - 2018-11-26 12:20:46 --> Form Validation Class Initialized
INFO - 2018-11-26 12:20:46 --> Model Class Initialized
INFO - 2018-11-26 12:20:46 --> Controller Class Initialized
INFO - 2018-11-26 12:20:46 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-26 12:20:46 --> Model Class Initialized
INFO - 2018-11-26 12:20:46 --> Model Class Initialized
INFO - 2018-11-26 12:20:46 --> Config Class Initialized
INFO - 2018-11-26 12:20:46 --> Hooks Class Initialized
DEBUG - 2018-11-26 12:20:46 --> UTF-8 Support Enabled
INFO - 2018-11-26 12:20:46 --> Utf8 Class Initialized
INFO - 2018-11-26 12:20:46 --> URI Class Initialized
INFO - 2018-11-26 12:20:46 --> Router Class Initialized
INFO - 2018-11-26 12:20:46 --> Output Class Initialized
INFO - 2018-11-26 12:20:46 --> Security Class Initialized
DEBUG - 2018-11-26 12:20:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-26 12:20:46 --> Input Class Initialized
INFO - 2018-11-26 12:20:46 --> Language Class Initialized
INFO - 2018-11-26 12:20:46 --> Loader Class Initialized
INFO - 2018-11-26 12:20:46 --> Helper loaded: url_helper
INFO - 2018-11-26 12:20:46 --> Helper loaded: file_helper
INFO - 2018-11-26 12:20:46 --> Helper loaded: email_helper
INFO - 2018-11-26 12:20:46 --> Helper loaded: common_helper
INFO - 2018-11-26 12:20:46 --> Database Driver Class Initialized
DEBUG - 2018-11-26 12:20:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-26 12:20:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-26 12:20:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-26 12:20:46 --> Pagination Class Initialized
INFO - 2018-11-26 12:20:46 --> Helper loaded: form_helper
INFO - 2018-11-26 12:20:46 --> Form Validation Class Initialized
INFO - 2018-11-26 12:20:46 --> Model Class Initialized
INFO - 2018-11-26 12:20:46 --> Controller Class Initialized
INFO - 2018-11-26 12:20:46 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-26 12:20:46 --> Model Class Initialized
INFO - 2018-11-26 12:20:46 --> Model Class Initialized
INFO - 2018-11-26 12:20:46 --> Config Class Initialized
INFO - 2018-11-26 12:20:46 --> Hooks Class Initialized
DEBUG - 2018-11-26 12:20:46 --> UTF-8 Support Enabled
INFO - 2018-11-26 12:20:46 --> Utf8 Class Initialized
INFO - 2018-11-26 12:20:46 --> URI Class Initialized
INFO - 2018-11-26 12:20:46 --> Router Class Initialized
INFO - 2018-11-26 12:20:46 --> Output Class Initialized
INFO - 2018-11-26 12:20:46 --> Security Class Initialized
DEBUG - 2018-11-26 12:20:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-26 12:20:46 --> Input Class Initialized
INFO - 2018-11-26 12:20:46 --> Language Class Initialized
INFO - 2018-11-26 12:20:46 --> Loader Class Initialized
INFO - 2018-11-26 12:20:46 --> Helper loaded: url_helper
INFO - 2018-11-26 12:20:46 --> Helper loaded: file_helper
INFO - 2018-11-26 12:20:46 --> Helper loaded: email_helper
INFO - 2018-11-26 12:20:46 --> Helper loaded: common_helper
INFO - 2018-11-26 12:20:46 --> Database Driver Class Initialized
DEBUG - 2018-11-26 12:20:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-26 12:20:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-26 12:20:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-26 12:20:46 --> Pagination Class Initialized
INFO - 2018-11-26 12:20:46 --> Helper loaded: form_helper
INFO - 2018-11-26 12:20:46 --> Form Validation Class Initialized
INFO - 2018-11-26 12:20:46 --> Model Class Initialized
INFO - 2018-11-26 12:20:46 --> Controller Class Initialized
INFO - 2018-11-26 12:20:46 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-26 12:20:46 --> Model Class Initialized
INFO - 2018-11-26 12:20:46 --> Model Class Initialized
INFO - 2018-11-26 12:20:46 --> Config Class Initialized
INFO - 2018-11-26 12:20:46 --> Hooks Class Initialized
DEBUG - 2018-11-26 12:20:46 --> UTF-8 Support Enabled
INFO - 2018-11-26 12:20:46 --> Utf8 Class Initialized
INFO - 2018-11-26 12:20:46 --> URI Class Initialized
INFO - 2018-11-26 12:20:46 --> Router Class Initialized
INFO - 2018-11-26 12:20:46 --> Output Class Initialized
INFO - 2018-11-26 12:20:46 --> Security Class Initialized
DEBUG - 2018-11-26 12:20:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-26 12:20:46 --> Input Class Initialized
INFO - 2018-11-26 12:20:46 --> Language Class Initialized
INFO - 2018-11-26 12:20:46 --> Loader Class Initialized
INFO - 2018-11-26 12:20:46 --> Helper loaded: url_helper
INFO - 2018-11-26 12:20:46 --> Helper loaded: file_helper
INFO - 2018-11-26 12:20:46 --> Helper loaded: email_helper
INFO - 2018-11-26 12:20:46 --> Helper loaded: common_helper
INFO - 2018-11-26 12:20:46 --> Database Driver Class Initialized
DEBUG - 2018-11-26 12:20:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-26 12:20:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-26 12:20:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-26 12:20:46 --> Pagination Class Initialized
INFO - 2018-11-26 12:20:46 --> Helper loaded: form_helper
INFO - 2018-11-26 12:20:46 --> Form Validation Class Initialized
INFO - 2018-11-26 12:20:46 --> Model Class Initialized
INFO - 2018-11-26 12:20:46 --> Controller Class Initialized
INFO - 2018-11-26 12:20:46 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-26 12:20:46 --> Model Class Initialized
INFO - 2018-11-26 12:20:46 --> Model Class Initialized
INFO - 2018-11-26 12:20:46 --> Config Class Initialized
INFO - 2018-11-26 12:20:46 --> Hooks Class Initialized
DEBUG - 2018-11-26 12:20:46 --> UTF-8 Support Enabled
INFO - 2018-11-26 12:20:46 --> Utf8 Class Initialized
INFO - 2018-11-26 12:20:46 --> URI Class Initialized
INFO - 2018-11-26 12:20:46 --> Router Class Initialized
INFO - 2018-11-26 12:20:46 --> Output Class Initialized
INFO - 2018-11-26 12:20:46 --> Security Class Initialized
DEBUG - 2018-11-26 12:20:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-26 12:20:46 --> Input Class Initialized
INFO - 2018-11-26 12:20:46 --> Language Class Initialized
INFO - 2018-11-26 12:20:46 --> Loader Class Initialized
INFO - 2018-11-26 12:20:46 --> Helper loaded: url_helper
INFO - 2018-11-26 12:20:46 --> Helper loaded: file_helper
INFO - 2018-11-26 12:20:46 --> Helper loaded: email_helper
INFO - 2018-11-26 12:20:46 --> Helper loaded: common_helper
INFO - 2018-11-26 12:20:46 --> Database Driver Class Initialized
DEBUG - 2018-11-26 12:20:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-26 12:20:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-26 12:20:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-26 12:20:46 --> Pagination Class Initialized
INFO - 2018-11-26 12:20:46 --> Helper loaded: form_helper
INFO - 2018-11-26 12:20:46 --> Form Validation Class Initialized
INFO - 2018-11-26 12:20:46 --> Model Class Initialized
INFO - 2018-11-26 12:20:46 --> Controller Class Initialized
INFO - 2018-11-26 12:20:46 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-26 12:20:46 --> Model Class Initialized
INFO - 2018-11-26 12:20:46 --> Model Class Initialized
INFO - 2018-11-26 12:20:46 --> Config Class Initialized
INFO - 2018-11-26 12:20:46 --> Hooks Class Initialized
DEBUG - 2018-11-26 12:20:46 --> UTF-8 Support Enabled
INFO - 2018-11-26 12:20:46 --> Utf8 Class Initialized
INFO - 2018-11-26 12:20:46 --> URI Class Initialized
INFO - 2018-11-26 12:20:46 --> Router Class Initialized
INFO - 2018-11-26 12:20:46 --> Output Class Initialized
INFO - 2018-11-26 12:20:46 --> Security Class Initialized
DEBUG - 2018-11-26 12:20:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-26 12:20:46 --> Input Class Initialized
INFO - 2018-11-26 12:20:46 --> Language Class Initialized
INFO - 2018-11-26 12:20:46 --> Loader Class Initialized
INFO - 2018-11-26 12:20:46 --> Helper loaded: url_helper
INFO - 2018-11-26 12:20:46 --> Helper loaded: file_helper
INFO - 2018-11-26 12:20:46 --> Helper loaded: email_helper
INFO - 2018-11-26 12:20:46 --> Helper loaded: common_helper
INFO - 2018-11-26 12:20:46 --> Database Driver Class Initialized
DEBUG - 2018-11-26 12:20:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-26 12:20:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-26 12:20:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-26 12:20:46 --> Pagination Class Initialized
INFO - 2018-11-26 12:20:46 --> Helper loaded: form_helper
INFO - 2018-11-26 12:20:46 --> Form Validation Class Initialized
INFO - 2018-11-26 12:20:46 --> Model Class Initialized
INFO - 2018-11-26 12:20:46 --> Controller Class Initialized
INFO - 2018-11-26 12:20:46 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-26 12:20:46 --> Model Class Initialized
INFO - 2018-11-26 12:20:46 --> Model Class Initialized
INFO - 2018-11-26 12:20:46 --> Config Class Initialized
INFO - 2018-11-26 12:20:46 --> Hooks Class Initialized
DEBUG - 2018-11-26 12:20:46 --> UTF-8 Support Enabled
INFO - 2018-11-26 12:20:46 --> Utf8 Class Initialized
INFO - 2018-11-26 12:20:46 --> URI Class Initialized
INFO - 2018-11-26 12:20:46 --> Router Class Initialized
INFO - 2018-11-26 12:20:46 --> Output Class Initialized
INFO - 2018-11-26 12:20:46 --> Security Class Initialized
DEBUG - 2018-11-26 12:20:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-26 12:20:46 --> Input Class Initialized
INFO - 2018-11-26 12:20:46 --> Language Class Initialized
INFO - 2018-11-26 12:20:46 --> Loader Class Initialized
INFO - 2018-11-26 12:20:46 --> Helper loaded: url_helper
INFO - 2018-11-26 12:20:46 --> Helper loaded: file_helper
INFO - 2018-11-26 12:20:46 --> Helper loaded: email_helper
INFO - 2018-11-26 12:20:46 --> Helper loaded: common_helper
INFO - 2018-11-26 12:20:46 --> Database Driver Class Initialized
DEBUG - 2018-11-26 12:20:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-26 12:20:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-26 12:20:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-26 12:20:46 --> Pagination Class Initialized
INFO - 2018-11-26 12:20:46 --> Helper loaded: form_helper
INFO - 2018-11-26 12:20:46 --> Form Validation Class Initialized
INFO - 2018-11-26 12:20:46 --> Model Class Initialized
INFO - 2018-11-26 12:20:46 --> Controller Class Initialized
INFO - 2018-11-26 12:20:46 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-26 12:20:46 --> Model Class Initialized
INFO - 2018-11-26 12:20:46 --> Model Class Initialized
INFO - 2018-11-26 12:20:46 --> Config Class Initialized
INFO - 2018-11-26 12:20:46 --> Hooks Class Initialized
DEBUG - 2018-11-26 12:20:46 --> UTF-8 Support Enabled
INFO - 2018-11-26 12:20:46 --> Utf8 Class Initialized
INFO - 2018-11-26 12:20:46 --> URI Class Initialized
INFO - 2018-11-26 12:20:46 --> Router Class Initialized
INFO - 2018-11-26 12:20:46 --> Output Class Initialized
INFO - 2018-11-26 12:20:46 --> Security Class Initialized
DEBUG - 2018-11-26 12:20:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-26 12:20:46 --> Input Class Initialized
INFO - 2018-11-26 12:20:46 --> Language Class Initialized
INFO - 2018-11-26 12:20:46 --> Loader Class Initialized
INFO - 2018-11-26 12:20:46 --> Helper loaded: url_helper
INFO - 2018-11-26 12:20:46 --> Helper loaded: file_helper
INFO - 2018-11-26 12:20:46 --> Helper loaded: email_helper
INFO - 2018-11-26 12:20:46 --> Helper loaded: common_helper
INFO - 2018-11-26 12:20:46 --> Database Driver Class Initialized
DEBUG - 2018-11-26 12:20:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-26 12:20:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-26 12:20:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-26 12:20:46 --> Pagination Class Initialized
INFO - 2018-11-26 12:20:46 --> Helper loaded: form_helper
INFO - 2018-11-26 12:20:46 --> Form Validation Class Initialized
INFO - 2018-11-26 12:20:46 --> Model Class Initialized
INFO - 2018-11-26 12:20:46 --> Controller Class Initialized
INFO - 2018-11-26 12:20:46 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-26 12:20:46 --> Model Class Initialized
INFO - 2018-11-26 12:20:46 --> Model Class Initialized
INFO - 2018-11-26 12:20:46 --> Config Class Initialized
INFO - 2018-11-26 12:20:46 --> Hooks Class Initialized
DEBUG - 2018-11-26 12:20:46 --> UTF-8 Support Enabled
INFO - 2018-11-26 12:20:46 --> Utf8 Class Initialized
INFO - 2018-11-26 12:20:46 --> URI Class Initialized
INFO - 2018-11-26 12:20:46 --> Router Class Initialized
INFO - 2018-11-26 12:20:46 --> Output Class Initialized
INFO - 2018-11-26 12:20:46 --> Security Class Initialized
DEBUG - 2018-11-26 12:20:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-26 12:20:46 --> Input Class Initialized
INFO - 2018-11-26 12:20:46 --> Language Class Initialized
INFO - 2018-11-26 12:20:46 --> Loader Class Initialized
INFO - 2018-11-26 12:20:46 --> Helper loaded: url_helper
INFO - 2018-11-26 12:20:46 --> Helper loaded: file_helper
INFO - 2018-11-26 12:20:46 --> Helper loaded: email_helper
INFO - 2018-11-26 12:20:46 --> Helper loaded: common_helper
INFO - 2018-11-26 12:20:46 --> Database Driver Class Initialized
DEBUG - 2018-11-26 12:20:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-26 12:20:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-26 12:20:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-26 12:20:46 --> Pagination Class Initialized
INFO - 2018-11-26 12:20:46 --> Helper loaded: form_helper
INFO - 2018-11-26 12:20:46 --> Form Validation Class Initialized
INFO - 2018-11-26 12:20:46 --> Model Class Initialized
INFO - 2018-11-26 12:20:46 --> Controller Class Initialized
INFO - 2018-11-26 12:20:46 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-26 12:20:46 --> Model Class Initialized
INFO - 2018-11-26 12:20:46 --> Model Class Initialized
INFO - 2018-11-26 12:20:46 --> Config Class Initialized
INFO - 2018-11-26 12:20:46 --> Hooks Class Initialized
DEBUG - 2018-11-26 12:20:46 --> UTF-8 Support Enabled
INFO - 2018-11-26 12:20:46 --> Utf8 Class Initialized
INFO - 2018-11-26 12:20:46 --> URI Class Initialized
INFO - 2018-11-26 12:20:46 --> Router Class Initialized
INFO - 2018-11-26 12:20:46 --> Output Class Initialized
INFO - 2018-11-26 12:20:46 --> Security Class Initialized
DEBUG - 2018-11-26 12:20:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-26 12:20:46 --> Input Class Initialized
INFO - 2018-11-26 12:20:46 --> Language Class Initialized
INFO - 2018-11-26 12:20:46 --> Loader Class Initialized
INFO - 2018-11-26 12:20:46 --> Helper loaded: url_helper
INFO - 2018-11-26 12:20:46 --> Helper loaded: file_helper
INFO - 2018-11-26 12:20:46 --> Helper loaded: email_helper
INFO - 2018-11-26 12:20:46 --> Helper loaded: common_helper
INFO - 2018-11-26 12:20:46 --> Database Driver Class Initialized
DEBUG - 2018-11-26 12:20:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-26 12:20:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-26 12:20:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-26 12:20:46 --> Pagination Class Initialized
INFO - 2018-11-26 12:20:46 --> Helper loaded: form_helper
INFO - 2018-11-26 12:20:46 --> Form Validation Class Initialized
INFO - 2018-11-26 12:20:46 --> Model Class Initialized
INFO - 2018-11-26 12:20:46 --> Controller Class Initialized
INFO - 2018-11-26 12:20:46 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-26 12:20:46 --> Model Class Initialized
INFO - 2018-11-26 12:20:46 --> Model Class Initialized
INFO - 2018-11-26 12:20:46 --> Config Class Initialized
INFO - 2018-11-26 12:20:46 --> Hooks Class Initialized
DEBUG - 2018-11-26 12:20:46 --> UTF-8 Support Enabled
INFO - 2018-11-26 12:20:46 --> Utf8 Class Initialized
INFO - 2018-11-26 12:20:46 --> URI Class Initialized
INFO - 2018-11-26 12:20:46 --> Router Class Initialized
INFO - 2018-11-26 12:20:46 --> Output Class Initialized
INFO - 2018-11-26 12:20:46 --> Security Class Initialized
DEBUG - 2018-11-26 12:20:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-26 12:20:46 --> Input Class Initialized
INFO - 2018-11-26 12:20:46 --> Language Class Initialized
INFO - 2018-11-26 12:20:46 --> Loader Class Initialized
INFO - 2018-11-26 12:20:46 --> Helper loaded: url_helper
INFO - 2018-11-26 12:20:46 --> Helper loaded: file_helper
INFO - 2018-11-26 12:20:46 --> Helper loaded: email_helper
INFO - 2018-11-26 12:20:46 --> Helper loaded: common_helper
INFO - 2018-11-26 12:20:46 --> Database Driver Class Initialized
DEBUG - 2018-11-26 12:20:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-26 12:20:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-26 12:20:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-26 12:20:46 --> Pagination Class Initialized
INFO - 2018-11-26 12:20:46 --> Helper loaded: form_helper
INFO - 2018-11-26 12:20:46 --> Form Validation Class Initialized
INFO - 2018-11-26 12:20:46 --> Model Class Initialized
INFO - 2018-11-26 12:20:46 --> Controller Class Initialized
INFO - 2018-11-26 12:20:46 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-26 12:20:46 --> Model Class Initialized
INFO - 2018-11-26 12:20:46 --> Model Class Initialized
INFO - 2018-11-26 12:20:46 --> Config Class Initialized
INFO - 2018-11-26 12:20:46 --> Hooks Class Initialized
DEBUG - 2018-11-26 12:20:46 --> UTF-8 Support Enabled
INFO - 2018-11-26 12:20:46 --> Utf8 Class Initialized
INFO - 2018-11-26 12:20:46 --> URI Class Initialized
INFO - 2018-11-26 12:20:46 --> Router Class Initialized
INFO - 2018-11-26 12:20:46 --> Output Class Initialized
INFO - 2018-11-26 12:20:46 --> Security Class Initialized
DEBUG - 2018-11-26 12:20:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-26 12:20:46 --> Input Class Initialized
INFO - 2018-11-26 12:20:46 --> Language Class Initialized
INFO - 2018-11-26 12:20:46 --> Loader Class Initialized
INFO - 2018-11-26 12:20:46 --> Helper loaded: url_helper
INFO - 2018-11-26 12:20:46 --> Helper loaded: file_helper
INFO - 2018-11-26 12:20:46 --> Helper loaded: email_helper
INFO - 2018-11-26 12:20:46 --> Helper loaded: common_helper
INFO - 2018-11-26 12:20:46 --> Database Driver Class Initialized
DEBUG - 2018-11-26 12:20:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-26 12:20:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-26 12:20:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-26 12:20:46 --> Pagination Class Initialized
INFO - 2018-11-26 12:20:46 --> Helper loaded: form_helper
INFO - 2018-11-26 12:20:46 --> Form Validation Class Initialized
INFO - 2018-11-26 12:20:46 --> Model Class Initialized
INFO - 2018-11-26 12:20:46 --> Controller Class Initialized
INFO - 2018-11-26 12:20:46 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-26 12:20:46 --> Model Class Initialized
INFO - 2018-11-26 12:20:46 --> Model Class Initialized
INFO - 2018-11-26 12:20:47 --> Config Class Initialized
INFO - 2018-11-26 12:20:47 --> Hooks Class Initialized
DEBUG - 2018-11-26 12:20:47 --> UTF-8 Support Enabled
INFO - 2018-11-26 12:20:47 --> Utf8 Class Initialized
INFO - 2018-11-26 12:20:47 --> URI Class Initialized
INFO - 2018-11-26 12:20:47 --> Router Class Initialized
INFO - 2018-11-26 12:20:47 --> Output Class Initialized
INFO - 2018-11-26 12:20:47 --> Security Class Initialized
DEBUG - 2018-11-26 12:20:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-26 12:20:47 --> Input Class Initialized
INFO - 2018-11-26 12:20:47 --> Language Class Initialized
INFO - 2018-11-26 12:20:47 --> Loader Class Initialized
INFO - 2018-11-26 12:20:47 --> Helper loaded: url_helper
INFO - 2018-11-26 12:20:47 --> Helper loaded: file_helper
INFO - 2018-11-26 12:20:47 --> Helper loaded: email_helper
INFO - 2018-11-26 12:20:47 --> Helper loaded: common_helper
INFO - 2018-11-26 12:20:47 --> Database Driver Class Initialized
DEBUG - 2018-11-26 12:20:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-26 12:20:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-26 12:20:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-26 12:20:47 --> Pagination Class Initialized
INFO - 2018-11-26 12:20:47 --> Helper loaded: form_helper
INFO - 2018-11-26 12:20:47 --> Form Validation Class Initialized
INFO - 2018-11-26 12:20:47 --> Model Class Initialized
INFO - 2018-11-26 12:20:47 --> Controller Class Initialized
INFO - 2018-11-26 12:20:47 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-26 12:20:47 --> Model Class Initialized
INFO - 2018-11-26 12:20:47 --> Model Class Initialized
INFO - 2018-11-26 12:20:47 --> Config Class Initialized
INFO - 2018-11-26 12:20:47 --> Hooks Class Initialized
DEBUG - 2018-11-26 12:20:47 --> UTF-8 Support Enabled
INFO - 2018-11-26 12:20:47 --> Utf8 Class Initialized
INFO - 2018-11-26 12:20:47 --> URI Class Initialized
INFO - 2018-11-26 12:20:47 --> Router Class Initialized
INFO - 2018-11-26 12:20:47 --> Output Class Initialized
INFO - 2018-11-26 12:20:47 --> Security Class Initialized
DEBUG - 2018-11-26 12:20:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-26 12:20:47 --> Input Class Initialized
INFO - 2018-11-26 12:20:47 --> Language Class Initialized
INFO - 2018-11-26 12:20:47 --> Loader Class Initialized
INFO - 2018-11-26 12:20:47 --> Helper loaded: url_helper
INFO - 2018-11-26 12:20:47 --> Helper loaded: file_helper
INFO - 2018-11-26 12:20:47 --> Helper loaded: email_helper
INFO - 2018-11-26 12:20:47 --> Helper loaded: common_helper
INFO - 2018-11-26 12:20:47 --> Database Driver Class Initialized
DEBUG - 2018-11-26 12:20:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-26 12:20:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-26 12:20:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-26 12:20:47 --> Pagination Class Initialized
INFO - 2018-11-26 12:20:47 --> Helper loaded: form_helper
INFO - 2018-11-26 12:20:47 --> Form Validation Class Initialized
INFO - 2018-11-26 12:20:47 --> Model Class Initialized
INFO - 2018-11-26 12:20:47 --> Controller Class Initialized
INFO - 2018-11-26 12:20:47 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-26 12:20:47 --> Model Class Initialized
INFO - 2018-11-26 12:20:47 --> Model Class Initialized
INFO - 2018-11-26 12:20:47 --> Config Class Initialized
INFO - 2018-11-26 12:20:47 --> Hooks Class Initialized
DEBUG - 2018-11-26 12:20:47 --> UTF-8 Support Enabled
INFO - 2018-11-26 12:20:47 --> Utf8 Class Initialized
INFO - 2018-11-26 12:20:47 --> URI Class Initialized
INFO - 2018-11-26 12:20:47 --> Router Class Initialized
INFO - 2018-11-26 12:20:47 --> Output Class Initialized
INFO - 2018-11-26 12:20:47 --> Security Class Initialized
DEBUG - 2018-11-26 12:20:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-26 12:20:47 --> Input Class Initialized
INFO - 2018-11-26 12:20:47 --> Language Class Initialized
INFO - 2018-11-26 12:20:47 --> Loader Class Initialized
INFO - 2018-11-26 12:20:47 --> Helper loaded: url_helper
INFO - 2018-11-26 12:20:47 --> Helper loaded: file_helper
INFO - 2018-11-26 12:20:47 --> Helper loaded: email_helper
INFO - 2018-11-26 12:20:47 --> Helper loaded: common_helper
INFO - 2018-11-26 12:20:47 --> Database Driver Class Initialized
DEBUG - 2018-11-26 12:20:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-26 12:20:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-26 12:20:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-26 12:20:47 --> Pagination Class Initialized
INFO - 2018-11-26 12:20:47 --> Helper loaded: form_helper
INFO - 2018-11-26 12:20:47 --> Form Validation Class Initialized
INFO - 2018-11-26 12:20:47 --> Model Class Initialized
INFO - 2018-11-26 12:20:47 --> Controller Class Initialized
INFO - 2018-11-26 12:20:47 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-26 12:20:47 --> Model Class Initialized
INFO - 2018-11-26 12:20:47 --> Model Class Initialized
INFO - 2018-11-26 12:20:47 --> Config Class Initialized
INFO - 2018-11-26 12:20:47 --> Hooks Class Initialized
DEBUG - 2018-11-26 12:20:47 --> UTF-8 Support Enabled
INFO - 2018-11-26 12:20:47 --> Utf8 Class Initialized
INFO - 2018-11-26 12:20:47 --> URI Class Initialized
INFO - 2018-11-26 12:20:47 --> Router Class Initialized
INFO - 2018-11-26 12:20:47 --> Output Class Initialized
INFO - 2018-11-26 12:20:47 --> Security Class Initialized
DEBUG - 2018-11-26 12:20:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-26 12:20:47 --> Input Class Initialized
INFO - 2018-11-26 12:20:47 --> Language Class Initialized
INFO - 2018-11-26 12:20:47 --> Loader Class Initialized
INFO - 2018-11-26 12:20:47 --> Helper loaded: url_helper
INFO - 2018-11-26 12:20:47 --> Helper loaded: file_helper
INFO - 2018-11-26 12:20:47 --> Helper loaded: email_helper
INFO - 2018-11-26 12:20:47 --> Helper loaded: common_helper
INFO - 2018-11-26 12:20:47 --> Database Driver Class Initialized
DEBUG - 2018-11-26 12:20:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-26 12:20:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-26 12:20:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-26 12:20:47 --> Pagination Class Initialized
INFO - 2018-11-26 12:20:47 --> Helper loaded: form_helper
INFO - 2018-11-26 12:20:47 --> Form Validation Class Initialized
INFO - 2018-11-26 12:20:47 --> Model Class Initialized
INFO - 2018-11-26 12:20:47 --> Controller Class Initialized
INFO - 2018-11-26 12:20:47 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-26 12:20:47 --> Model Class Initialized
INFO - 2018-11-26 12:20:47 --> Model Class Initialized
INFO - 2018-11-26 12:20:47 --> Config Class Initialized
INFO - 2018-11-26 12:20:47 --> Hooks Class Initialized
DEBUG - 2018-11-26 12:20:47 --> UTF-8 Support Enabled
INFO - 2018-11-26 12:20:47 --> Utf8 Class Initialized
INFO - 2018-11-26 12:20:47 --> URI Class Initialized
INFO - 2018-11-26 12:20:47 --> Router Class Initialized
INFO - 2018-11-26 12:20:47 --> Output Class Initialized
INFO - 2018-11-26 12:20:47 --> Security Class Initialized
DEBUG - 2018-11-26 12:20:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-26 12:20:47 --> Input Class Initialized
INFO - 2018-11-26 12:20:47 --> Language Class Initialized
INFO - 2018-11-26 12:20:47 --> Loader Class Initialized
INFO - 2018-11-26 12:20:47 --> Helper loaded: url_helper
INFO - 2018-11-26 12:20:47 --> Helper loaded: file_helper
INFO - 2018-11-26 12:20:47 --> Helper loaded: email_helper
INFO - 2018-11-26 12:20:47 --> Helper loaded: common_helper
INFO - 2018-11-26 12:20:47 --> Database Driver Class Initialized
DEBUG - 2018-11-26 12:20:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-26 12:20:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-26 12:20:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-26 12:20:47 --> Pagination Class Initialized
INFO - 2018-11-26 12:20:47 --> Helper loaded: form_helper
INFO - 2018-11-26 12:20:47 --> Form Validation Class Initialized
INFO - 2018-11-26 12:20:47 --> Model Class Initialized
INFO - 2018-11-26 12:20:47 --> Controller Class Initialized
INFO - 2018-11-26 12:20:47 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-26 12:20:47 --> Model Class Initialized
INFO - 2018-11-26 12:20:47 --> Model Class Initialized
INFO - 2018-11-26 12:20:47 --> Config Class Initialized
INFO - 2018-11-26 12:20:47 --> Hooks Class Initialized
DEBUG - 2018-11-26 12:20:47 --> UTF-8 Support Enabled
INFO - 2018-11-26 12:20:47 --> Utf8 Class Initialized
INFO - 2018-11-26 12:20:47 --> URI Class Initialized
INFO - 2018-11-26 12:20:47 --> Router Class Initialized
INFO - 2018-11-26 12:20:47 --> Output Class Initialized
INFO - 2018-11-26 12:20:47 --> Security Class Initialized
DEBUG - 2018-11-26 12:20:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-26 12:20:47 --> Input Class Initialized
INFO - 2018-11-26 12:20:47 --> Language Class Initialized
INFO - 2018-11-26 12:20:47 --> Loader Class Initialized
INFO - 2018-11-26 12:20:47 --> Helper loaded: url_helper
INFO - 2018-11-26 12:20:47 --> Helper loaded: file_helper
INFO - 2018-11-26 12:20:47 --> Helper loaded: email_helper
INFO - 2018-11-26 12:20:47 --> Helper loaded: common_helper
INFO - 2018-11-26 12:20:47 --> Database Driver Class Initialized
DEBUG - 2018-11-26 12:20:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-26 12:20:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-26 12:20:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-26 12:20:47 --> Pagination Class Initialized
INFO - 2018-11-26 12:20:47 --> Helper loaded: form_helper
INFO - 2018-11-26 12:20:47 --> Form Validation Class Initialized
INFO - 2018-11-26 12:20:47 --> Model Class Initialized
INFO - 2018-11-26 12:20:47 --> Controller Class Initialized
INFO - 2018-11-26 12:20:47 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-26 12:20:47 --> Model Class Initialized
INFO - 2018-11-26 12:20:47 --> Model Class Initialized
INFO - 2018-11-26 12:20:47 --> Config Class Initialized
INFO - 2018-11-26 12:20:47 --> Hooks Class Initialized
DEBUG - 2018-11-26 12:20:47 --> UTF-8 Support Enabled
INFO - 2018-11-26 12:20:47 --> Utf8 Class Initialized
INFO - 2018-11-26 12:20:47 --> URI Class Initialized
INFO - 2018-11-26 12:20:47 --> Router Class Initialized
INFO - 2018-11-26 12:20:47 --> Output Class Initialized
INFO - 2018-11-26 12:20:47 --> Security Class Initialized
DEBUG - 2018-11-26 12:20:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-26 12:20:47 --> Input Class Initialized
INFO - 2018-11-26 12:20:47 --> Language Class Initialized
INFO - 2018-11-26 12:20:47 --> Loader Class Initialized
INFO - 2018-11-26 12:20:47 --> Helper loaded: url_helper
INFO - 2018-11-26 12:20:47 --> Helper loaded: file_helper
INFO - 2018-11-26 12:20:47 --> Helper loaded: email_helper
INFO - 2018-11-26 12:20:47 --> Helper loaded: common_helper
INFO - 2018-11-26 12:20:47 --> Database Driver Class Initialized
DEBUG - 2018-11-26 12:20:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-26 12:20:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-26 12:20:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-26 12:20:47 --> Pagination Class Initialized
INFO - 2018-11-26 12:20:47 --> Helper loaded: form_helper
INFO - 2018-11-26 12:20:47 --> Form Validation Class Initialized
INFO - 2018-11-26 12:20:47 --> Model Class Initialized
INFO - 2018-11-26 12:20:47 --> Controller Class Initialized
INFO - 2018-11-26 12:20:47 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-26 12:20:47 --> Model Class Initialized
INFO - 2018-11-26 12:20:47 --> Model Class Initialized
INFO - 2018-11-26 12:20:47 --> Config Class Initialized
INFO - 2018-11-26 12:20:47 --> Hooks Class Initialized
DEBUG - 2018-11-26 12:20:47 --> UTF-8 Support Enabled
INFO - 2018-11-26 12:20:47 --> Utf8 Class Initialized
INFO - 2018-11-26 12:20:47 --> URI Class Initialized
INFO - 2018-11-26 12:20:47 --> Router Class Initialized
INFO - 2018-11-26 12:20:47 --> Output Class Initialized
INFO - 2018-11-26 12:20:47 --> Security Class Initialized
DEBUG - 2018-11-26 12:20:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-26 12:20:47 --> Input Class Initialized
INFO - 2018-11-26 12:20:47 --> Language Class Initialized
INFO - 2018-11-26 12:20:47 --> Loader Class Initialized
INFO - 2018-11-26 12:20:47 --> Helper loaded: url_helper
INFO - 2018-11-26 12:20:47 --> Helper loaded: file_helper
INFO - 2018-11-26 12:20:47 --> Helper loaded: email_helper
INFO - 2018-11-26 12:20:47 --> Helper loaded: common_helper
INFO - 2018-11-26 12:20:47 --> Database Driver Class Initialized
DEBUG - 2018-11-26 12:20:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-26 12:20:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-26 12:20:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-26 12:20:47 --> Pagination Class Initialized
INFO - 2018-11-26 12:20:47 --> Helper loaded: form_helper
INFO - 2018-11-26 12:20:47 --> Form Validation Class Initialized
INFO - 2018-11-26 12:20:47 --> Model Class Initialized
INFO - 2018-11-26 12:20:47 --> Controller Class Initialized
INFO - 2018-11-26 12:20:47 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-26 12:20:47 --> Model Class Initialized
INFO - 2018-11-26 12:20:47 --> Model Class Initialized
INFO - 2018-11-26 12:21:15 --> Config Class Initialized
INFO - 2018-11-26 12:21:15 --> Hooks Class Initialized
DEBUG - 2018-11-26 12:21:15 --> UTF-8 Support Enabled
INFO - 2018-11-26 12:21:15 --> Utf8 Class Initialized
INFO - 2018-11-26 12:21:15 --> URI Class Initialized
INFO - 2018-11-26 12:21:15 --> Router Class Initialized
INFO - 2018-11-26 12:21:15 --> Output Class Initialized
INFO - 2018-11-26 12:21:15 --> Security Class Initialized
DEBUG - 2018-11-26 12:21:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-26 12:21:15 --> Input Class Initialized
INFO - 2018-11-26 12:21:15 --> Language Class Initialized
INFO - 2018-11-26 12:21:15 --> Loader Class Initialized
INFO - 2018-11-26 12:21:15 --> Helper loaded: url_helper
INFO - 2018-11-26 12:21:15 --> Helper loaded: file_helper
INFO - 2018-11-26 12:21:15 --> Helper loaded: email_helper
INFO - 2018-11-26 12:21:15 --> Helper loaded: common_helper
INFO - 2018-11-26 12:21:15 --> Database Driver Class Initialized
DEBUG - 2018-11-26 12:21:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-26 12:21:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-26 12:21:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-26 12:21:15 --> Pagination Class Initialized
INFO - 2018-11-26 12:21:15 --> Helper loaded: form_helper
INFO - 2018-11-26 12:21:15 --> Form Validation Class Initialized
INFO - 2018-11-26 12:21:15 --> Model Class Initialized
INFO - 2018-11-26 12:21:15 --> Controller Class Initialized
INFO - 2018-11-26 12:21:15 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-26 12:21:15 --> Model Class Initialized
INFO - 2018-11-26 12:21:15 --> Model Class Initialized
INFO - 2018-11-26 12:21:15 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/index.php
INFO - 2018-11-26 12:21:15 --> Final output sent to browser
DEBUG - 2018-11-26 12:21:15 --> Total execution time: 0.0980
INFO - 2018-11-26 12:21:20 --> Config Class Initialized
INFO - 2018-11-26 12:21:20 --> Hooks Class Initialized
DEBUG - 2018-11-26 12:21:20 --> UTF-8 Support Enabled
INFO - 2018-11-26 12:21:20 --> Utf8 Class Initialized
INFO - 2018-11-26 12:21:20 --> URI Class Initialized
INFO - 2018-11-26 12:21:20 --> Router Class Initialized
INFO - 2018-11-26 12:21:20 --> Output Class Initialized
INFO - 2018-11-26 12:21:20 --> Security Class Initialized
DEBUG - 2018-11-26 12:21:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-26 12:21:20 --> Input Class Initialized
INFO - 2018-11-26 12:21:20 --> Language Class Initialized
INFO - 2018-11-26 12:21:20 --> Loader Class Initialized
INFO - 2018-11-26 12:21:20 --> Helper loaded: url_helper
INFO - 2018-11-26 12:21:20 --> Helper loaded: file_helper
INFO - 2018-11-26 12:21:20 --> Helper loaded: email_helper
INFO - 2018-11-26 12:21:20 --> Helper loaded: common_helper
INFO - 2018-11-26 12:21:20 --> Database Driver Class Initialized
DEBUG - 2018-11-26 12:21:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-26 12:21:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-26 12:21:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-26 12:21:20 --> Pagination Class Initialized
INFO - 2018-11-26 12:21:20 --> Helper loaded: form_helper
INFO - 2018-11-26 12:21:20 --> Form Validation Class Initialized
INFO - 2018-11-26 12:21:20 --> Model Class Initialized
INFO - 2018-11-26 12:21:20 --> Controller Class Initialized
INFO - 2018-11-26 12:21:20 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-26 12:21:20 --> Model Class Initialized
INFO - 2018-11-26 12:21:20 --> Model Class Initialized
ERROR - 2018-11-26 12:21:20 --> Severity: Notice --> Undefined index: remember_me C:\xampp\htdocs\wetinuneed\application\controllers\admin\Admin.php 78
INFO - 2018-11-26 12:21:20 --> Config Class Initialized
INFO - 2018-11-26 12:21:20 --> Hooks Class Initialized
DEBUG - 2018-11-26 12:21:20 --> UTF-8 Support Enabled
INFO - 2018-11-26 12:21:20 --> Utf8 Class Initialized
INFO - 2018-11-26 12:21:20 --> URI Class Initialized
INFO - 2018-11-26 12:21:20 --> Router Class Initialized
INFO - 2018-11-26 12:21:20 --> Output Class Initialized
INFO - 2018-11-26 12:21:20 --> Security Class Initialized
DEBUG - 2018-11-26 12:21:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-26 12:21:20 --> Input Class Initialized
INFO - 2018-11-26 12:21:20 --> Language Class Initialized
INFO - 2018-11-26 12:21:20 --> Loader Class Initialized
INFO - 2018-11-26 12:21:20 --> Helper loaded: url_helper
INFO - 2018-11-26 12:21:20 --> Helper loaded: file_helper
INFO - 2018-11-26 12:21:20 --> Helper loaded: email_helper
INFO - 2018-11-26 12:21:20 --> Helper loaded: common_helper
INFO - 2018-11-26 12:21:20 --> Database Driver Class Initialized
DEBUG - 2018-11-26 12:21:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-26 12:21:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-26 12:21:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-26 12:21:20 --> Pagination Class Initialized
INFO - 2018-11-26 12:21:20 --> Helper loaded: form_helper
INFO - 2018-11-26 12:21:20 --> Form Validation Class Initialized
INFO - 2018-11-26 12:21:20 --> Model Class Initialized
INFO - 2018-11-26 12:21:20 --> Controller Class Initialized
INFO - 2018-11-26 12:21:20 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-26 12:21:20 --> Model Class Initialized
INFO - 2018-11-26 12:21:20 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-26 12:21:20 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/sidebar.php
INFO - 2018-11-26 12:21:20 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/right-sidebar.php
INFO - 2018-11-26 12:21:20 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/footer.php
INFO - 2018-11-26 12:21:20 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/dashboard.php
INFO - 2018-11-26 12:21:20 --> Final output sent to browser
DEBUG - 2018-11-26 12:21:20 --> Total execution time: 0.0690
INFO - 2018-11-26 12:21:28 --> Config Class Initialized
INFO - 2018-11-26 12:21:28 --> Hooks Class Initialized
DEBUG - 2018-11-26 12:21:29 --> UTF-8 Support Enabled
INFO - 2018-11-26 12:21:29 --> Utf8 Class Initialized
INFO - 2018-11-26 12:21:29 --> URI Class Initialized
INFO - 2018-11-26 12:21:29 --> Router Class Initialized
INFO - 2018-11-26 12:21:29 --> Output Class Initialized
INFO - 2018-11-26 12:21:29 --> Security Class Initialized
DEBUG - 2018-11-26 12:21:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-26 12:21:29 --> Input Class Initialized
INFO - 2018-11-26 12:21:29 --> Language Class Initialized
INFO - 2018-11-26 12:21:29 --> Loader Class Initialized
INFO - 2018-11-26 12:21:29 --> Helper loaded: url_helper
INFO - 2018-11-26 12:21:29 --> Helper loaded: file_helper
INFO - 2018-11-26 12:21:29 --> Helper loaded: email_helper
INFO - 2018-11-26 12:21:29 --> Helper loaded: common_helper
INFO - 2018-11-26 12:21:29 --> Database Driver Class Initialized
DEBUG - 2018-11-26 12:21:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-26 12:21:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-26 12:21:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-26 12:21:29 --> Pagination Class Initialized
INFO - 2018-11-26 12:21:29 --> Helper loaded: form_helper
INFO - 2018-11-26 12:21:29 --> Form Validation Class Initialized
INFO - 2018-11-26 12:21:29 --> Model Class Initialized
INFO - 2018-11-26 12:21:29 --> Controller Class Initialized
INFO - 2018-11-26 12:21:29 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-26 12:21:29 --> Model Class Initialized
INFO - 2018-11-26 12:21:29 --> Model Class Initialized
INFO - 2018-11-26 12:21:29 --> Config Class Initialized
INFO - 2018-11-26 12:21:29 --> Hooks Class Initialized
DEBUG - 2018-11-26 12:21:29 --> UTF-8 Support Enabled
INFO - 2018-11-26 12:21:29 --> Utf8 Class Initialized
INFO - 2018-11-26 12:21:29 --> URI Class Initialized
INFO - 2018-11-26 12:21:29 --> Router Class Initialized
INFO - 2018-11-26 12:21:29 --> Output Class Initialized
INFO - 2018-11-26 12:21:29 --> Security Class Initialized
DEBUG - 2018-11-26 12:21:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-26 12:21:29 --> Input Class Initialized
INFO - 2018-11-26 12:21:29 --> Language Class Initialized
INFO - 2018-11-26 12:21:29 --> Loader Class Initialized
INFO - 2018-11-26 12:21:29 --> Helper loaded: url_helper
INFO - 2018-11-26 12:21:29 --> Helper loaded: file_helper
INFO - 2018-11-26 12:21:29 --> Helper loaded: email_helper
INFO - 2018-11-26 12:21:29 --> Helper loaded: common_helper
INFO - 2018-11-26 12:21:29 --> Database Driver Class Initialized
DEBUG - 2018-11-26 12:21:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-26 12:21:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-26 12:21:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-26 12:21:29 --> Pagination Class Initialized
INFO - 2018-11-26 12:21:29 --> Helper loaded: form_helper
INFO - 2018-11-26 12:21:29 --> Form Validation Class Initialized
INFO - 2018-11-26 12:21:29 --> Model Class Initialized
INFO - 2018-11-26 12:21:29 --> Controller Class Initialized
INFO - 2018-11-26 12:21:29 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-26 12:21:29 --> Model Class Initialized
INFO - 2018-11-26 12:21:29 --> Model Class Initialized
INFO - 2018-11-26 12:21:29 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/index.php
INFO - 2018-11-26 12:21:29 --> Final output sent to browser
DEBUG - 2018-11-26 12:21:29 --> Total execution time: 0.0650
INFO - 2018-11-26 12:21:34 --> Config Class Initialized
INFO - 2018-11-26 12:21:34 --> Hooks Class Initialized
DEBUG - 2018-11-26 12:21:34 --> UTF-8 Support Enabled
INFO - 2018-11-26 12:21:34 --> Utf8 Class Initialized
INFO - 2018-11-26 12:21:34 --> URI Class Initialized
INFO - 2018-11-26 12:21:34 --> Router Class Initialized
INFO - 2018-11-26 12:21:34 --> Output Class Initialized
INFO - 2018-11-26 12:21:34 --> Security Class Initialized
DEBUG - 2018-11-26 12:21:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-26 12:21:34 --> Input Class Initialized
INFO - 2018-11-26 12:21:34 --> Language Class Initialized
INFO - 2018-11-26 12:21:34 --> Loader Class Initialized
INFO - 2018-11-26 12:21:34 --> Helper loaded: url_helper
INFO - 2018-11-26 12:21:34 --> Helper loaded: file_helper
INFO - 2018-11-26 12:21:34 --> Helper loaded: email_helper
INFO - 2018-11-26 12:21:34 --> Helper loaded: common_helper
INFO - 2018-11-26 12:21:34 --> Database Driver Class Initialized
DEBUG - 2018-11-26 12:21:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-26 12:21:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-26 12:21:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-26 12:21:34 --> Pagination Class Initialized
INFO - 2018-11-26 12:21:34 --> Helper loaded: form_helper
INFO - 2018-11-26 12:21:34 --> Form Validation Class Initialized
INFO - 2018-11-26 12:21:34 --> Model Class Initialized
INFO - 2018-11-26 12:21:34 --> Controller Class Initialized
INFO - 2018-11-26 12:21:34 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-26 12:21:34 --> Model Class Initialized
INFO - 2018-11-26 12:21:34 --> Model Class Initialized
INFO - 2018-11-26 12:21:34 --> Final output sent to browser
DEBUG - 2018-11-26 12:21:34 --> Total execution time: 0.0820
INFO - 2018-11-26 12:21:34 --> Config Class Initialized
INFO - 2018-11-26 12:21:34 --> Hooks Class Initialized
DEBUG - 2018-11-26 12:21:34 --> UTF-8 Support Enabled
INFO - 2018-11-26 12:21:34 --> Utf8 Class Initialized
INFO - 2018-11-26 12:21:34 --> URI Class Initialized
INFO - 2018-11-26 12:21:34 --> Router Class Initialized
INFO - 2018-11-26 12:21:34 --> Output Class Initialized
INFO - 2018-11-26 12:21:34 --> Security Class Initialized
DEBUG - 2018-11-26 12:21:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-26 12:21:34 --> Input Class Initialized
INFO - 2018-11-26 12:21:34 --> Language Class Initialized
INFO - 2018-11-26 12:21:34 --> Loader Class Initialized
INFO - 2018-11-26 12:21:34 --> Helper loaded: url_helper
INFO - 2018-11-26 12:21:34 --> Helper loaded: file_helper
INFO - 2018-11-26 12:21:34 --> Helper loaded: email_helper
INFO - 2018-11-26 12:21:34 --> Helper loaded: common_helper
INFO - 2018-11-26 12:21:34 --> Database Driver Class Initialized
DEBUG - 2018-11-26 12:21:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-26 12:21:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-26 12:21:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-26 12:21:34 --> Pagination Class Initialized
INFO - 2018-11-26 12:21:34 --> Helper loaded: form_helper
INFO - 2018-11-26 12:21:34 --> Form Validation Class Initialized
INFO - 2018-11-26 12:21:34 --> Model Class Initialized
INFO - 2018-11-26 12:21:34 --> Controller Class Initialized
INFO - 2018-11-26 12:21:34 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-26 12:21:34 --> Model Class Initialized
INFO - 2018-11-26 12:21:34 --> Model Class Initialized
INFO - 2018-11-26 12:21:34 --> Config Class Initialized
INFO - 2018-11-26 12:21:34 --> Hooks Class Initialized
DEBUG - 2018-11-26 12:21:34 --> UTF-8 Support Enabled
INFO - 2018-11-26 12:21:34 --> Utf8 Class Initialized
INFO - 2018-11-26 12:21:34 --> URI Class Initialized
INFO - 2018-11-26 12:21:34 --> Router Class Initialized
INFO - 2018-11-26 12:21:34 --> Output Class Initialized
INFO - 2018-11-26 12:21:34 --> Security Class Initialized
DEBUG - 2018-11-26 12:21:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-26 12:21:34 --> Input Class Initialized
INFO - 2018-11-26 12:21:34 --> Language Class Initialized
INFO - 2018-11-26 12:21:34 --> Loader Class Initialized
INFO - 2018-11-26 12:21:34 --> Helper loaded: url_helper
INFO - 2018-11-26 12:21:34 --> Helper loaded: file_helper
INFO - 2018-11-26 12:21:34 --> Helper loaded: email_helper
INFO - 2018-11-26 12:21:34 --> Helper loaded: common_helper
INFO - 2018-11-26 12:21:34 --> Database Driver Class Initialized
DEBUG - 2018-11-26 12:21:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-26 12:21:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-26 12:21:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-26 12:21:34 --> Pagination Class Initialized
INFO - 2018-11-26 12:21:34 --> Helper loaded: form_helper
INFO - 2018-11-26 12:21:34 --> Form Validation Class Initialized
INFO - 2018-11-26 12:21:34 --> Model Class Initialized
INFO - 2018-11-26 12:21:34 --> Controller Class Initialized
INFO - 2018-11-26 12:21:34 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-26 12:21:34 --> Model Class Initialized
INFO - 2018-11-26 12:21:34 --> Model Class Initialized
INFO - 2018-11-26 12:21:34 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/index.php
INFO - 2018-11-26 12:21:34 --> Final output sent to browser
DEBUG - 2018-11-26 12:21:34 --> Total execution time: 0.0730
INFO - 2018-11-26 12:23:10 --> Config Class Initialized
INFO - 2018-11-26 12:23:10 --> Hooks Class Initialized
DEBUG - 2018-11-26 12:23:10 --> UTF-8 Support Enabled
INFO - 2018-11-26 12:23:10 --> Utf8 Class Initialized
INFO - 2018-11-26 12:23:10 --> URI Class Initialized
INFO - 2018-11-26 12:23:10 --> Router Class Initialized
INFO - 2018-11-26 12:23:10 --> Output Class Initialized
INFO - 2018-11-26 12:23:10 --> Security Class Initialized
DEBUG - 2018-11-26 12:23:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-26 12:23:10 --> Input Class Initialized
INFO - 2018-11-26 12:23:10 --> Language Class Initialized
INFO - 2018-11-26 12:23:10 --> Loader Class Initialized
INFO - 2018-11-26 12:23:10 --> Helper loaded: url_helper
INFO - 2018-11-26 12:23:10 --> Helper loaded: file_helper
INFO - 2018-11-26 12:23:10 --> Helper loaded: email_helper
INFO - 2018-11-26 12:23:10 --> Helper loaded: common_helper
INFO - 2018-11-26 12:23:10 --> Database Driver Class Initialized
DEBUG - 2018-11-26 12:23:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-26 12:23:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-26 12:23:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-26 12:23:10 --> Pagination Class Initialized
INFO - 2018-11-26 12:23:10 --> Helper loaded: form_helper
INFO - 2018-11-26 12:23:10 --> Form Validation Class Initialized
INFO - 2018-11-26 12:23:10 --> Model Class Initialized
INFO - 2018-11-26 12:23:10 --> Controller Class Initialized
INFO - 2018-11-26 12:23:10 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-26 12:23:10 --> Model Class Initialized
INFO - 2018-11-26 12:23:10 --> Model Class Initialized
INFO - 2018-11-26 12:23:10 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/index.php
INFO - 2018-11-26 12:23:10 --> Final output sent to browser
DEBUG - 2018-11-26 12:23:10 --> Total execution time: 0.0610
INFO - 2018-11-26 12:23:23 --> Config Class Initialized
INFO - 2018-11-26 12:23:23 --> Hooks Class Initialized
DEBUG - 2018-11-26 12:23:23 --> UTF-8 Support Enabled
INFO - 2018-11-26 12:23:23 --> Utf8 Class Initialized
INFO - 2018-11-26 12:23:23 --> URI Class Initialized
INFO - 2018-11-26 12:23:23 --> Router Class Initialized
INFO - 2018-11-26 12:23:23 --> Output Class Initialized
INFO - 2018-11-26 12:23:23 --> Security Class Initialized
DEBUG - 2018-11-26 12:23:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-26 12:23:23 --> Input Class Initialized
INFO - 2018-11-26 12:23:23 --> Language Class Initialized
INFO - 2018-11-26 12:23:23 --> Loader Class Initialized
INFO - 2018-11-26 12:23:23 --> Helper loaded: url_helper
INFO - 2018-11-26 12:23:23 --> Helper loaded: file_helper
INFO - 2018-11-26 12:23:23 --> Helper loaded: email_helper
INFO - 2018-11-26 12:23:23 --> Helper loaded: common_helper
INFO - 2018-11-26 12:23:23 --> Database Driver Class Initialized
DEBUG - 2018-11-26 12:23:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-26 12:23:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-26 12:23:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-26 12:23:23 --> Pagination Class Initialized
INFO - 2018-11-26 12:23:23 --> Helper loaded: form_helper
INFO - 2018-11-26 12:23:23 --> Form Validation Class Initialized
INFO - 2018-11-26 12:23:23 --> Model Class Initialized
INFO - 2018-11-26 12:23:23 --> Controller Class Initialized
INFO - 2018-11-26 12:23:23 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-26 12:23:23 --> Model Class Initialized
INFO - 2018-11-26 12:23:23 --> Model Class Initialized
INFO - 2018-11-26 12:23:23 --> Final output sent to browser
DEBUG - 2018-11-26 12:23:23 --> Total execution time: 0.0620
INFO - 2018-11-26 12:23:25 --> Config Class Initialized
INFO - 2018-11-26 12:23:25 --> Hooks Class Initialized
DEBUG - 2018-11-26 12:23:25 --> UTF-8 Support Enabled
INFO - 2018-11-26 12:23:25 --> Utf8 Class Initialized
INFO - 2018-11-26 12:23:25 --> URI Class Initialized
INFO - 2018-11-26 12:23:25 --> Router Class Initialized
INFO - 2018-11-26 12:23:25 --> Output Class Initialized
INFO - 2018-11-26 12:23:25 --> Security Class Initialized
DEBUG - 2018-11-26 12:23:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-26 12:23:25 --> Input Class Initialized
INFO - 2018-11-26 12:23:25 --> Language Class Initialized
INFO - 2018-11-26 12:23:25 --> Loader Class Initialized
INFO - 2018-11-26 12:23:25 --> Helper loaded: url_helper
INFO - 2018-11-26 12:23:25 --> Helper loaded: file_helper
INFO - 2018-11-26 12:23:25 --> Helper loaded: email_helper
INFO - 2018-11-26 12:23:25 --> Helper loaded: common_helper
INFO - 2018-11-26 12:23:25 --> Database Driver Class Initialized
DEBUG - 2018-11-26 12:23:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-26 12:23:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-26 12:23:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-26 12:23:25 --> Pagination Class Initialized
INFO - 2018-11-26 12:23:25 --> Helper loaded: form_helper
INFO - 2018-11-26 12:23:25 --> Form Validation Class Initialized
INFO - 2018-11-26 12:23:25 --> Model Class Initialized
INFO - 2018-11-26 12:23:25 --> Controller Class Initialized
INFO - 2018-11-26 12:23:25 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-26 12:23:25 --> Model Class Initialized
INFO - 2018-11-26 12:23:25 --> Model Class Initialized
INFO - 2018-11-26 12:23:25 --> Config Class Initialized
INFO - 2018-11-26 12:23:25 --> Hooks Class Initialized
DEBUG - 2018-11-26 12:23:25 --> UTF-8 Support Enabled
INFO - 2018-11-26 12:23:25 --> Utf8 Class Initialized
INFO - 2018-11-26 12:23:25 --> URI Class Initialized
INFO - 2018-11-26 12:23:25 --> Router Class Initialized
INFO - 2018-11-26 12:23:25 --> Output Class Initialized
INFO - 2018-11-26 12:23:25 --> Security Class Initialized
DEBUG - 2018-11-26 12:23:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-26 12:23:25 --> Input Class Initialized
INFO - 2018-11-26 12:23:25 --> Language Class Initialized
INFO - 2018-11-26 12:23:25 --> Loader Class Initialized
INFO - 2018-11-26 12:23:25 --> Helper loaded: url_helper
INFO - 2018-11-26 12:23:25 --> Helper loaded: file_helper
INFO - 2018-11-26 12:23:25 --> Helper loaded: email_helper
INFO - 2018-11-26 12:23:25 --> Helper loaded: common_helper
INFO - 2018-11-26 12:23:25 --> Database Driver Class Initialized
DEBUG - 2018-11-26 12:23:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-26 12:23:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-26 12:23:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-26 12:23:25 --> Pagination Class Initialized
INFO - 2018-11-26 12:23:25 --> Helper loaded: form_helper
INFO - 2018-11-26 12:23:25 --> Form Validation Class Initialized
INFO - 2018-11-26 12:23:25 --> Model Class Initialized
INFO - 2018-11-26 12:23:25 --> Controller Class Initialized
INFO - 2018-11-26 12:23:25 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-26 12:23:25 --> Model Class Initialized
INFO - 2018-11-26 12:23:25 --> Model Class Initialized
INFO - 2018-11-26 12:23:25 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/index.php
INFO - 2018-11-26 12:23:25 --> Final output sent to browser
DEBUG - 2018-11-26 12:23:25 --> Total execution time: 0.0640
INFO - 2018-11-26 12:25:12 --> Config Class Initialized
INFO - 2018-11-26 12:25:12 --> Hooks Class Initialized
DEBUG - 2018-11-26 12:25:12 --> UTF-8 Support Enabled
INFO - 2018-11-26 12:25:12 --> Utf8 Class Initialized
INFO - 2018-11-26 12:25:12 --> URI Class Initialized
INFO - 2018-11-26 12:25:12 --> Router Class Initialized
INFO - 2018-11-26 12:25:12 --> Output Class Initialized
INFO - 2018-11-26 12:25:12 --> Security Class Initialized
DEBUG - 2018-11-26 12:25:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-26 12:25:12 --> Input Class Initialized
INFO - 2018-11-26 12:25:12 --> Language Class Initialized
INFO - 2018-11-26 12:25:12 --> Loader Class Initialized
INFO - 2018-11-26 12:25:12 --> Helper loaded: url_helper
INFO - 2018-11-26 12:25:12 --> Helper loaded: file_helper
INFO - 2018-11-26 12:25:12 --> Helper loaded: email_helper
INFO - 2018-11-26 12:25:12 --> Helper loaded: common_helper
INFO - 2018-11-26 12:25:12 --> Database Driver Class Initialized
DEBUG - 2018-11-26 12:25:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-26 12:25:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-26 12:25:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-26 12:25:12 --> Pagination Class Initialized
INFO - 2018-11-26 12:25:12 --> Helper loaded: form_helper
INFO - 2018-11-26 12:25:12 --> Form Validation Class Initialized
INFO - 2018-11-26 12:25:12 --> Model Class Initialized
INFO - 2018-11-26 12:25:12 --> Controller Class Initialized
INFO - 2018-11-26 12:25:12 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-26 12:25:12 --> Model Class Initialized
INFO - 2018-11-26 12:25:12 --> Model Class Initialized
INFO - 2018-11-26 12:25:12 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/index.php
INFO - 2018-11-26 12:25:12 --> Final output sent to browser
DEBUG - 2018-11-26 12:25:12 --> Total execution time: 0.0940
INFO - 2018-11-26 12:25:19 --> Config Class Initialized
INFO - 2018-11-26 12:25:19 --> Hooks Class Initialized
DEBUG - 2018-11-26 12:25:19 --> UTF-8 Support Enabled
INFO - 2018-11-26 12:25:19 --> Utf8 Class Initialized
INFO - 2018-11-26 12:25:19 --> URI Class Initialized
INFO - 2018-11-26 12:25:19 --> Router Class Initialized
INFO - 2018-11-26 12:25:19 --> Output Class Initialized
INFO - 2018-11-26 12:25:19 --> Security Class Initialized
DEBUG - 2018-11-26 12:25:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-26 12:25:19 --> Input Class Initialized
INFO - 2018-11-26 12:25:19 --> Language Class Initialized
INFO - 2018-11-26 12:25:19 --> Loader Class Initialized
INFO - 2018-11-26 12:25:19 --> Helper loaded: url_helper
INFO - 2018-11-26 12:25:19 --> Helper loaded: file_helper
INFO - 2018-11-26 12:25:19 --> Helper loaded: email_helper
INFO - 2018-11-26 12:25:19 --> Helper loaded: common_helper
INFO - 2018-11-26 12:25:19 --> Database Driver Class Initialized
DEBUG - 2018-11-26 12:25:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-26 12:25:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-26 12:25:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-26 12:25:19 --> Pagination Class Initialized
INFO - 2018-11-26 12:25:19 --> Helper loaded: form_helper
INFO - 2018-11-26 12:25:19 --> Form Validation Class Initialized
INFO - 2018-11-26 12:25:19 --> Model Class Initialized
INFO - 2018-11-26 12:25:19 --> Controller Class Initialized
INFO - 2018-11-26 12:25:19 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-26 12:25:19 --> Model Class Initialized
INFO - 2018-11-26 12:25:19 --> Model Class Initialized
INFO - 2018-11-26 12:25:19 --> Final output sent to browser
DEBUG - 2018-11-26 12:25:19 --> Total execution time: 0.0740
INFO - 2018-11-26 12:25:19 --> Config Class Initialized
INFO - 2018-11-26 12:25:19 --> Hooks Class Initialized
DEBUG - 2018-11-26 12:25:19 --> UTF-8 Support Enabled
INFO - 2018-11-26 12:25:19 --> Utf8 Class Initialized
INFO - 2018-11-26 12:25:19 --> URI Class Initialized
INFO - 2018-11-26 12:25:19 --> Router Class Initialized
INFO - 2018-11-26 12:25:19 --> Output Class Initialized
INFO - 2018-11-26 12:25:19 --> Security Class Initialized
DEBUG - 2018-11-26 12:25:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-26 12:25:19 --> Input Class Initialized
INFO - 2018-11-26 12:25:19 --> Language Class Initialized
INFO - 2018-11-26 12:25:19 --> Loader Class Initialized
INFO - 2018-11-26 12:25:19 --> Helper loaded: url_helper
INFO - 2018-11-26 12:25:19 --> Helper loaded: file_helper
INFO - 2018-11-26 12:25:19 --> Helper loaded: email_helper
INFO - 2018-11-26 12:25:19 --> Helper loaded: common_helper
INFO - 2018-11-26 12:25:19 --> Database Driver Class Initialized
DEBUG - 2018-11-26 12:25:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-26 12:25:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-26 12:25:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-26 12:25:19 --> Pagination Class Initialized
INFO - 2018-11-26 12:25:19 --> Helper loaded: form_helper
INFO - 2018-11-26 12:25:19 --> Form Validation Class Initialized
INFO - 2018-11-26 12:25:19 --> Model Class Initialized
INFO - 2018-11-26 12:25:19 --> Controller Class Initialized
INFO - 2018-11-26 12:25:19 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-26 12:25:19 --> Model Class Initialized
INFO - 2018-11-26 12:25:19 --> Model Class Initialized
ERROR - 2018-11-26 12:25:19 --> Severity: Warning --> Missing argument 1 for CI_Session::set_flashdata(), called in C:\xampp\htdocs\wetinuneed\application\controllers\admin\Admin.php on line 210 and defined C:\xampp\htdocs\wetinuneed\system\libraries\Session\Session.php 899
ERROR - 2018-11-26 12:25:19 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\wetinuneed\system\libraries\Session\Session.php 901
ERROR - 2018-11-26 12:25:19 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\wetinuneed\system\libraries\Session\Session.php 902
ERROR - 2018-11-26 12:25:19 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\wetinuneed\system\libraries\Session\Session.php 902
INFO - 2018-11-26 12:26:02 --> Config Class Initialized
INFO - 2018-11-26 12:26:02 --> Hooks Class Initialized
DEBUG - 2018-11-26 12:26:02 --> UTF-8 Support Enabled
INFO - 2018-11-26 12:26:02 --> Utf8 Class Initialized
INFO - 2018-11-26 12:26:02 --> URI Class Initialized
INFO - 2018-11-26 12:26:02 --> Router Class Initialized
INFO - 2018-11-26 12:26:02 --> Output Class Initialized
INFO - 2018-11-26 12:26:02 --> Security Class Initialized
DEBUG - 2018-11-26 12:26:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-26 12:26:02 --> Input Class Initialized
INFO - 2018-11-26 12:26:02 --> Language Class Initialized
INFO - 2018-11-26 12:26:02 --> Loader Class Initialized
INFO - 2018-11-26 12:26:02 --> Helper loaded: url_helper
INFO - 2018-11-26 12:26:02 --> Helper loaded: file_helper
INFO - 2018-11-26 12:26:02 --> Helper loaded: email_helper
INFO - 2018-11-26 12:26:02 --> Helper loaded: common_helper
INFO - 2018-11-26 12:26:02 --> Database Driver Class Initialized
DEBUG - 2018-11-26 12:26:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-26 12:26:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-26 12:26:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-26 12:26:02 --> Pagination Class Initialized
INFO - 2018-11-26 12:26:02 --> Helper loaded: form_helper
INFO - 2018-11-26 12:26:02 --> Form Validation Class Initialized
INFO - 2018-11-26 12:26:02 --> Model Class Initialized
INFO - 2018-11-26 12:26:02 --> Controller Class Initialized
INFO - 2018-11-26 12:26:02 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-26 12:26:02 --> Model Class Initialized
INFO - 2018-11-26 12:26:02 --> Model Class Initialized
INFO - 2018-11-26 12:28:35 --> Config Class Initialized
INFO - 2018-11-26 12:28:35 --> Hooks Class Initialized
DEBUG - 2018-11-26 12:28:35 --> UTF-8 Support Enabled
INFO - 2018-11-26 12:28:35 --> Utf8 Class Initialized
INFO - 2018-11-26 12:28:35 --> URI Class Initialized
INFO - 2018-11-26 12:28:35 --> Router Class Initialized
INFO - 2018-11-26 12:28:35 --> Output Class Initialized
INFO - 2018-11-26 12:28:35 --> Security Class Initialized
DEBUG - 2018-11-26 12:28:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-26 12:28:35 --> Input Class Initialized
INFO - 2018-11-26 12:28:35 --> Language Class Initialized
INFO - 2018-11-26 12:28:35 --> Loader Class Initialized
INFO - 2018-11-26 12:28:35 --> Helper loaded: url_helper
INFO - 2018-11-26 12:28:35 --> Helper loaded: file_helper
INFO - 2018-11-26 12:28:35 --> Helper loaded: email_helper
INFO - 2018-11-26 12:28:35 --> Helper loaded: common_helper
INFO - 2018-11-26 12:28:35 --> Database Driver Class Initialized
DEBUG - 2018-11-26 12:28:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-26 12:28:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-26 12:28:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-26 12:28:35 --> Pagination Class Initialized
INFO - 2018-11-26 12:28:35 --> Helper loaded: form_helper
INFO - 2018-11-26 12:28:35 --> Form Validation Class Initialized
INFO - 2018-11-26 12:28:35 --> Model Class Initialized
INFO - 2018-11-26 12:28:35 --> Controller Class Initialized
INFO - 2018-11-26 12:28:35 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-26 12:28:35 --> Model Class Initialized
INFO - 2018-11-26 12:28:35 --> Model Class Initialized
INFO - 2018-11-26 12:28:35 --> Config Class Initialized
INFO - 2018-11-26 12:28:35 --> Hooks Class Initialized
DEBUG - 2018-11-26 12:28:35 --> UTF-8 Support Enabled
INFO - 2018-11-26 12:28:35 --> Utf8 Class Initialized
INFO - 2018-11-26 12:28:35 --> URI Class Initialized
INFO - 2018-11-26 12:28:35 --> Router Class Initialized
INFO - 2018-11-26 12:28:35 --> Output Class Initialized
INFO - 2018-11-26 12:28:35 --> Security Class Initialized
DEBUG - 2018-11-26 12:28:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-26 12:28:35 --> Input Class Initialized
INFO - 2018-11-26 12:28:35 --> Language Class Initialized
INFO - 2018-11-26 12:28:35 --> Loader Class Initialized
INFO - 2018-11-26 12:28:35 --> Helper loaded: url_helper
INFO - 2018-11-26 12:28:35 --> Helper loaded: file_helper
INFO - 2018-11-26 12:28:35 --> Helper loaded: email_helper
INFO - 2018-11-26 12:28:35 --> Helper loaded: common_helper
INFO - 2018-11-26 12:28:35 --> Database Driver Class Initialized
DEBUG - 2018-11-26 12:28:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-26 12:28:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-26 12:28:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-26 12:28:35 --> Pagination Class Initialized
INFO - 2018-11-26 12:28:35 --> Helper loaded: form_helper
INFO - 2018-11-26 12:28:35 --> Form Validation Class Initialized
INFO - 2018-11-26 12:28:35 --> Model Class Initialized
INFO - 2018-11-26 12:28:35 --> Controller Class Initialized
INFO - 2018-11-26 12:28:35 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-26 12:28:35 --> Model Class Initialized
INFO - 2018-11-26 12:28:35 --> Model Class Initialized
INFO - 2018-11-26 12:28:35 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/index.php
INFO - 2018-11-26 12:28:35 --> Final output sent to browser
DEBUG - 2018-11-26 12:28:35 --> Total execution time: 0.0800
INFO - 2018-11-26 12:40:44 --> Config Class Initialized
INFO - 2018-11-26 12:40:44 --> Hooks Class Initialized
DEBUG - 2018-11-26 12:40:44 --> UTF-8 Support Enabled
INFO - 2018-11-26 12:40:44 --> Utf8 Class Initialized
INFO - 2018-11-26 12:40:44 --> URI Class Initialized
INFO - 2018-11-26 12:40:44 --> Router Class Initialized
INFO - 2018-11-26 12:40:44 --> Output Class Initialized
INFO - 2018-11-26 12:40:44 --> Security Class Initialized
DEBUG - 2018-11-26 12:40:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-26 12:40:44 --> Input Class Initialized
INFO - 2018-11-26 12:40:44 --> Language Class Initialized
INFO - 2018-11-26 12:40:44 --> Loader Class Initialized
INFO - 2018-11-26 12:40:44 --> Helper loaded: url_helper
INFO - 2018-11-26 12:40:44 --> Helper loaded: file_helper
INFO - 2018-11-26 12:40:44 --> Helper loaded: email_helper
INFO - 2018-11-26 12:40:44 --> Helper loaded: common_helper
INFO - 2018-11-26 12:40:44 --> Database Driver Class Initialized
DEBUG - 2018-11-26 12:40:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-26 12:40:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-26 12:40:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-26 12:40:44 --> Pagination Class Initialized
INFO - 2018-11-26 12:40:44 --> Helper loaded: form_helper
INFO - 2018-11-26 12:40:44 --> Form Validation Class Initialized
INFO - 2018-11-26 12:40:44 --> Model Class Initialized
INFO - 2018-11-26 12:40:44 --> Controller Class Initialized
INFO - 2018-11-26 12:40:44 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-26 12:40:44 --> Model Class Initialized
INFO - 2018-11-26 12:40:44 --> Model Class Initialized
INFO - 2018-11-26 12:40:44 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/index.php
INFO - 2018-11-26 12:40:44 --> Final output sent to browser
DEBUG - 2018-11-26 12:40:44 --> Total execution time: 0.0600
INFO - 2018-11-26 12:40:51 --> Config Class Initialized
INFO - 2018-11-26 12:40:51 --> Hooks Class Initialized
DEBUG - 2018-11-26 12:40:51 --> UTF-8 Support Enabled
INFO - 2018-11-26 12:40:51 --> Utf8 Class Initialized
INFO - 2018-11-26 12:40:51 --> URI Class Initialized
INFO - 2018-11-26 12:40:51 --> Router Class Initialized
INFO - 2018-11-26 12:40:51 --> Output Class Initialized
INFO - 2018-11-26 12:40:51 --> Security Class Initialized
DEBUG - 2018-11-26 12:40:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-26 12:40:51 --> Input Class Initialized
INFO - 2018-11-26 12:40:51 --> Language Class Initialized
INFO - 2018-11-26 12:40:51 --> Loader Class Initialized
INFO - 2018-11-26 12:40:51 --> Helper loaded: url_helper
INFO - 2018-11-26 12:40:51 --> Helper loaded: file_helper
INFO - 2018-11-26 12:40:51 --> Helper loaded: email_helper
INFO - 2018-11-26 12:40:51 --> Helper loaded: common_helper
INFO - 2018-11-26 12:40:51 --> Database Driver Class Initialized
DEBUG - 2018-11-26 12:40:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-26 12:40:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-26 12:40:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-26 12:40:51 --> Pagination Class Initialized
INFO - 2018-11-26 12:40:51 --> Helper loaded: form_helper
INFO - 2018-11-26 12:40:51 --> Form Validation Class Initialized
INFO - 2018-11-26 12:40:51 --> Model Class Initialized
INFO - 2018-11-26 12:40:51 --> Controller Class Initialized
INFO - 2018-11-26 12:40:51 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-26 12:40:51 --> Model Class Initialized
INFO - 2018-11-26 12:40:51 --> Model Class Initialized
INFO - 2018-11-26 12:40:51 --> Final output sent to browser
DEBUG - 2018-11-26 12:40:51 --> Total execution time: 0.0870
INFO - 2018-11-26 12:40:51 --> Config Class Initialized
INFO - 2018-11-26 12:40:51 --> Hooks Class Initialized
DEBUG - 2018-11-26 12:40:51 --> UTF-8 Support Enabled
INFO - 2018-11-26 12:40:51 --> Utf8 Class Initialized
INFO - 2018-11-26 12:40:51 --> URI Class Initialized
INFO - 2018-11-26 12:40:51 --> Router Class Initialized
INFO - 2018-11-26 12:40:51 --> Output Class Initialized
INFO - 2018-11-26 12:40:51 --> Security Class Initialized
DEBUG - 2018-11-26 12:40:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-26 12:40:51 --> Input Class Initialized
INFO - 2018-11-26 12:40:51 --> Language Class Initialized
INFO - 2018-11-26 12:40:51 --> Loader Class Initialized
INFO - 2018-11-26 12:40:51 --> Helper loaded: url_helper
INFO - 2018-11-26 12:40:51 --> Helper loaded: file_helper
INFO - 2018-11-26 12:40:51 --> Helper loaded: email_helper
INFO - 2018-11-26 12:40:51 --> Helper loaded: common_helper
INFO - 2018-11-26 12:40:51 --> Database Driver Class Initialized
DEBUG - 2018-11-26 12:40:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-26 12:40:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-26 12:40:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-26 12:40:51 --> Pagination Class Initialized
INFO - 2018-11-26 12:40:51 --> Helper loaded: form_helper
INFO - 2018-11-26 12:40:51 --> Form Validation Class Initialized
INFO - 2018-11-26 12:40:51 --> Model Class Initialized
INFO - 2018-11-26 12:40:51 --> Controller Class Initialized
INFO - 2018-11-26 12:40:51 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-26 12:40:51 --> Model Class Initialized
INFO - 2018-11-26 12:40:51 --> Model Class Initialized
INFO - 2018-11-26 12:40:51 --> Config Class Initialized
INFO - 2018-11-26 12:40:51 --> Hooks Class Initialized
DEBUG - 2018-11-26 12:40:51 --> UTF-8 Support Enabled
INFO - 2018-11-26 12:40:51 --> Utf8 Class Initialized
INFO - 2018-11-26 12:40:51 --> URI Class Initialized
INFO - 2018-11-26 12:40:51 --> Router Class Initialized
INFO - 2018-11-26 12:40:51 --> Output Class Initialized
INFO - 2018-11-26 12:40:51 --> Security Class Initialized
DEBUG - 2018-11-26 12:40:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-26 12:40:51 --> Input Class Initialized
INFO - 2018-11-26 12:40:51 --> Language Class Initialized
INFO - 2018-11-26 12:40:51 --> Loader Class Initialized
INFO - 2018-11-26 12:40:51 --> Helper loaded: url_helper
INFO - 2018-11-26 12:40:51 --> Helper loaded: file_helper
INFO - 2018-11-26 12:40:51 --> Helper loaded: email_helper
INFO - 2018-11-26 12:40:51 --> Helper loaded: common_helper
INFO - 2018-11-26 12:40:51 --> Database Driver Class Initialized
DEBUG - 2018-11-26 12:40:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-26 12:40:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-26 12:40:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-26 12:40:51 --> Pagination Class Initialized
INFO - 2018-11-26 12:40:51 --> Helper loaded: form_helper
INFO - 2018-11-26 12:40:51 --> Form Validation Class Initialized
INFO - 2018-11-26 12:40:51 --> Model Class Initialized
INFO - 2018-11-26 12:40:51 --> Controller Class Initialized
INFO - 2018-11-26 12:40:51 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-26 12:40:51 --> Model Class Initialized
INFO - 2018-11-26 12:40:51 --> Model Class Initialized
INFO - 2018-11-26 12:40:51 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/index.php
INFO - 2018-11-26 12:40:51 --> Final output sent to browser
DEBUG - 2018-11-26 12:40:51 --> Total execution time: 0.0750
INFO - 2018-11-26 12:44:32 --> Config Class Initialized
INFO - 2018-11-26 12:44:32 --> Hooks Class Initialized
DEBUG - 2018-11-26 12:44:32 --> UTF-8 Support Enabled
INFO - 2018-11-26 12:44:32 --> Utf8 Class Initialized
INFO - 2018-11-26 12:44:32 --> URI Class Initialized
INFO - 2018-11-26 12:44:32 --> Router Class Initialized
INFO - 2018-11-26 12:44:32 --> Output Class Initialized
INFO - 2018-11-26 12:44:32 --> Security Class Initialized
DEBUG - 2018-11-26 12:44:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-26 12:44:32 --> Input Class Initialized
INFO - 2018-11-26 12:44:32 --> Language Class Initialized
INFO - 2018-11-26 12:44:32 --> Loader Class Initialized
INFO - 2018-11-26 12:44:32 --> Helper loaded: url_helper
INFO - 2018-11-26 12:44:32 --> Helper loaded: file_helper
INFO - 2018-11-26 12:44:32 --> Helper loaded: email_helper
INFO - 2018-11-26 12:44:32 --> Helper loaded: common_helper
INFO - 2018-11-26 12:44:32 --> Database Driver Class Initialized
DEBUG - 2018-11-26 12:44:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-26 12:44:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-26 12:44:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-26 12:44:32 --> Pagination Class Initialized
INFO - 2018-11-26 12:44:32 --> Helper loaded: form_helper
INFO - 2018-11-26 12:44:32 --> Form Validation Class Initialized
INFO - 2018-11-26 12:44:32 --> Model Class Initialized
INFO - 2018-11-26 12:44:32 --> Controller Class Initialized
INFO - 2018-11-26 12:44:32 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-26 12:44:32 --> Model Class Initialized
INFO - 2018-11-26 12:44:32 --> Model Class Initialized
INFO - 2018-11-26 12:44:32 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/index.php
INFO - 2018-11-26 12:44:32 --> Final output sent to browser
DEBUG - 2018-11-26 12:44:32 --> Total execution time: 0.0990
INFO - 2018-11-26 12:44:33 --> Config Class Initialized
INFO - 2018-11-26 12:44:33 --> Hooks Class Initialized
DEBUG - 2018-11-26 12:44:33 --> UTF-8 Support Enabled
INFO - 2018-11-26 12:44:33 --> Utf8 Class Initialized
INFO - 2018-11-26 12:44:33 --> URI Class Initialized
INFO - 2018-11-26 12:44:33 --> Router Class Initialized
INFO - 2018-11-26 12:44:33 --> Output Class Initialized
INFO - 2018-11-26 12:44:33 --> Security Class Initialized
DEBUG - 2018-11-26 12:44:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-26 12:44:33 --> Input Class Initialized
INFO - 2018-11-26 12:44:33 --> Language Class Initialized
INFO - 2018-11-26 12:44:33 --> Loader Class Initialized
INFO - 2018-11-26 12:44:33 --> Helper loaded: url_helper
INFO - 2018-11-26 12:44:33 --> Helper loaded: file_helper
INFO - 2018-11-26 12:44:33 --> Helper loaded: email_helper
INFO - 2018-11-26 12:44:33 --> Helper loaded: common_helper
INFO - 2018-11-26 12:44:33 --> Database Driver Class Initialized
DEBUG - 2018-11-26 12:44:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-26 12:44:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-26 12:44:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-26 12:44:33 --> Pagination Class Initialized
INFO - 2018-11-26 12:44:33 --> Helper loaded: form_helper
INFO - 2018-11-26 12:44:33 --> Form Validation Class Initialized
INFO - 2018-11-26 12:44:33 --> Model Class Initialized
INFO - 2018-11-26 12:44:33 --> Controller Class Initialized
INFO - 2018-11-26 12:44:33 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-26 12:44:33 --> Model Class Initialized
INFO - 2018-11-26 12:44:33 --> Model Class Initialized
INFO - 2018-11-26 12:44:33 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/index.php
INFO - 2018-11-26 12:44:33 --> Final output sent to browser
DEBUG - 2018-11-26 12:44:33 --> Total execution time: 0.1310
INFO - 2018-11-26 12:44:36 --> Config Class Initialized
INFO - 2018-11-26 12:44:36 --> Hooks Class Initialized
DEBUG - 2018-11-26 12:44:36 --> UTF-8 Support Enabled
INFO - 2018-11-26 12:44:36 --> Utf8 Class Initialized
INFO - 2018-11-26 12:44:36 --> URI Class Initialized
INFO - 2018-11-26 12:44:36 --> Router Class Initialized
INFO - 2018-11-26 12:44:36 --> Output Class Initialized
INFO - 2018-11-26 12:44:36 --> Security Class Initialized
DEBUG - 2018-11-26 12:44:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-26 12:44:36 --> Input Class Initialized
INFO - 2018-11-26 12:44:36 --> Language Class Initialized
INFO - 2018-11-26 12:44:36 --> Loader Class Initialized
INFO - 2018-11-26 12:44:36 --> Helper loaded: url_helper
INFO - 2018-11-26 12:44:36 --> Helper loaded: file_helper
INFO - 2018-11-26 12:44:36 --> Helper loaded: email_helper
INFO - 2018-11-26 12:44:36 --> Helper loaded: common_helper
INFO - 2018-11-26 12:44:36 --> Database Driver Class Initialized
DEBUG - 2018-11-26 12:44:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-26 12:44:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-26 12:44:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-26 12:44:36 --> Pagination Class Initialized
INFO - 2018-11-26 12:44:36 --> Helper loaded: form_helper
INFO - 2018-11-26 12:44:36 --> Form Validation Class Initialized
INFO - 2018-11-26 12:44:36 --> Model Class Initialized
INFO - 2018-11-26 12:44:36 --> Controller Class Initialized
INFO - 2018-11-26 12:44:36 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-26 12:44:36 --> Model Class Initialized
INFO - 2018-11-26 12:44:36 --> Model Class Initialized
INFO - 2018-11-26 12:44:36 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/index.php
INFO - 2018-11-26 12:44:36 --> Final output sent to browser
DEBUG - 2018-11-26 12:44:36 --> Total execution time: 0.1170
INFO - 2018-11-26 12:44:50 --> Config Class Initialized
INFO - 2018-11-26 12:44:50 --> Hooks Class Initialized
DEBUG - 2018-11-26 12:44:50 --> UTF-8 Support Enabled
INFO - 2018-11-26 12:44:50 --> Utf8 Class Initialized
INFO - 2018-11-26 12:44:50 --> URI Class Initialized
INFO - 2018-11-26 12:44:50 --> Router Class Initialized
INFO - 2018-11-26 12:44:50 --> Output Class Initialized
INFO - 2018-11-26 12:44:50 --> Security Class Initialized
DEBUG - 2018-11-26 12:44:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-26 12:44:50 --> Input Class Initialized
INFO - 2018-11-26 12:44:50 --> Language Class Initialized
INFO - 2018-11-26 12:44:50 --> Loader Class Initialized
INFO - 2018-11-26 12:44:50 --> Helper loaded: url_helper
INFO - 2018-11-26 12:44:50 --> Helper loaded: file_helper
INFO - 2018-11-26 12:44:50 --> Helper loaded: email_helper
INFO - 2018-11-26 12:44:50 --> Helper loaded: common_helper
INFO - 2018-11-26 12:44:50 --> Database Driver Class Initialized
DEBUG - 2018-11-26 12:44:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-26 12:44:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-26 12:44:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-26 12:44:50 --> Pagination Class Initialized
INFO - 2018-11-26 12:44:50 --> Helper loaded: form_helper
INFO - 2018-11-26 12:44:50 --> Form Validation Class Initialized
INFO - 2018-11-26 12:44:50 --> Model Class Initialized
INFO - 2018-11-26 12:44:50 --> Controller Class Initialized
INFO - 2018-11-26 12:44:50 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-26 12:44:50 --> Model Class Initialized
INFO - 2018-11-26 12:44:50 --> Model Class Initialized
INFO - 2018-11-26 12:44:50 --> Final output sent to browser
DEBUG - 2018-11-26 12:44:50 --> Total execution time: 0.0780
INFO - 2018-11-26 12:44:50 --> Config Class Initialized
INFO - 2018-11-26 12:44:50 --> Hooks Class Initialized
DEBUG - 2018-11-26 12:44:50 --> UTF-8 Support Enabled
INFO - 2018-11-26 12:44:50 --> Utf8 Class Initialized
INFO - 2018-11-26 12:44:50 --> URI Class Initialized
INFO - 2018-11-26 12:44:50 --> Router Class Initialized
INFO - 2018-11-26 12:44:50 --> Output Class Initialized
INFO - 2018-11-26 12:44:50 --> Security Class Initialized
DEBUG - 2018-11-26 12:44:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-26 12:44:50 --> Input Class Initialized
INFO - 2018-11-26 12:44:50 --> Language Class Initialized
INFO - 2018-11-26 12:44:50 --> Loader Class Initialized
INFO - 2018-11-26 12:44:50 --> Helper loaded: url_helper
INFO - 2018-11-26 12:44:51 --> Helper loaded: file_helper
INFO - 2018-11-26 12:44:51 --> Helper loaded: email_helper
INFO - 2018-11-26 12:44:51 --> Helper loaded: common_helper
INFO - 2018-11-26 12:44:51 --> Database Driver Class Initialized
DEBUG - 2018-11-26 12:44:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-26 12:44:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-26 12:44:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-26 12:44:51 --> Pagination Class Initialized
INFO - 2018-11-26 12:44:51 --> Helper loaded: form_helper
INFO - 2018-11-26 12:44:51 --> Form Validation Class Initialized
INFO - 2018-11-26 12:44:51 --> Model Class Initialized
INFO - 2018-11-26 12:44:51 --> Controller Class Initialized
INFO - 2018-11-26 12:44:51 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-26 12:44:51 --> Model Class Initialized
INFO - 2018-11-26 12:44:51 --> Model Class Initialized
INFO - 2018-11-26 12:44:51 --> Config Class Initialized
INFO - 2018-11-26 12:44:51 --> Hooks Class Initialized
DEBUG - 2018-11-26 12:44:51 --> UTF-8 Support Enabled
INFO - 2018-11-26 12:44:51 --> Utf8 Class Initialized
INFO - 2018-11-26 12:44:51 --> URI Class Initialized
INFO - 2018-11-26 12:44:51 --> Router Class Initialized
INFO - 2018-11-26 12:44:51 --> Output Class Initialized
INFO - 2018-11-26 12:44:51 --> Security Class Initialized
DEBUG - 2018-11-26 12:44:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-26 12:44:51 --> Input Class Initialized
INFO - 2018-11-26 12:44:51 --> Language Class Initialized
INFO - 2018-11-26 12:44:51 --> Loader Class Initialized
INFO - 2018-11-26 12:44:51 --> Helper loaded: url_helper
INFO - 2018-11-26 12:44:51 --> Helper loaded: file_helper
INFO - 2018-11-26 12:44:51 --> Helper loaded: email_helper
INFO - 2018-11-26 12:44:51 --> Helper loaded: common_helper
INFO - 2018-11-26 12:44:51 --> Database Driver Class Initialized
DEBUG - 2018-11-26 12:44:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-26 12:44:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-26 12:44:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-26 12:44:51 --> Pagination Class Initialized
INFO - 2018-11-26 12:44:51 --> Helper loaded: form_helper
INFO - 2018-11-26 12:44:51 --> Form Validation Class Initialized
INFO - 2018-11-26 12:44:51 --> Model Class Initialized
INFO - 2018-11-26 12:44:51 --> Controller Class Initialized
INFO - 2018-11-26 12:44:51 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-26 12:44:51 --> Model Class Initialized
INFO - 2018-11-26 12:44:51 --> Model Class Initialized
INFO - 2018-11-26 12:44:51 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/index.php
INFO - 2018-11-26 12:44:51 --> Final output sent to browser
DEBUG - 2018-11-26 12:44:51 --> Total execution time: 0.0610
INFO - 2018-11-26 12:45:49 --> Config Class Initialized
INFO - 2018-11-26 12:45:49 --> Hooks Class Initialized
DEBUG - 2018-11-26 12:45:49 --> UTF-8 Support Enabled
INFO - 2018-11-26 12:45:49 --> Utf8 Class Initialized
INFO - 2018-11-26 12:45:49 --> URI Class Initialized
INFO - 2018-11-26 12:45:49 --> Router Class Initialized
INFO - 2018-11-26 12:45:49 --> Output Class Initialized
INFO - 2018-11-26 12:45:49 --> Security Class Initialized
DEBUG - 2018-11-26 12:45:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-26 12:45:49 --> Input Class Initialized
INFO - 2018-11-26 12:45:49 --> Language Class Initialized
INFO - 2018-11-26 12:45:49 --> Loader Class Initialized
INFO - 2018-11-26 12:45:49 --> Helper loaded: url_helper
INFO - 2018-11-26 12:45:49 --> Helper loaded: file_helper
INFO - 2018-11-26 12:45:49 --> Helper loaded: email_helper
INFO - 2018-11-26 12:45:49 --> Helper loaded: common_helper
INFO - 2018-11-26 12:45:49 --> Database Driver Class Initialized
DEBUG - 2018-11-26 12:45:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-26 12:45:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-26 12:45:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-26 12:45:49 --> Pagination Class Initialized
INFO - 2018-11-26 12:45:49 --> Helper loaded: form_helper
INFO - 2018-11-26 12:45:49 --> Form Validation Class Initialized
INFO - 2018-11-26 12:45:49 --> Model Class Initialized
INFO - 2018-11-26 12:45:49 --> Controller Class Initialized
INFO - 2018-11-26 12:45:49 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-26 12:45:49 --> Model Class Initialized
INFO - 2018-11-26 12:45:49 --> Model Class Initialized
INFO - 2018-11-26 12:45:49 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/index.php
INFO - 2018-11-26 12:45:49 --> Final output sent to browser
DEBUG - 2018-11-26 12:45:49 --> Total execution time: 0.1050
INFO - 2018-11-26 12:45:56 --> Config Class Initialized
INFO - 2018-11-26 12:45:56 --> Hooks Class Initialized
DEBUG - 2018-11-26 12:45:56 --> UTF-8 Support Enabled
INFO - 2018-11-26 12:45:56 --> Utf8 Class Initialized
INFO - 2018-11-26 12:45:56 --> URI Class Initialized
INFO - 2018-11-26 12:45:56 --> Router Class Initialized
INFO - 2018-11-26 12:45:56 --> Output Class Initialized
INFO - 2018-11-26 12:45:56 --> Security Class Initialized
DEBUG - 2018-11-26 12:45:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-26 12:45:56 --> Input Class Initialized
INFO - 2018-11-26 12:45:56 --> Language Class Initialized
INFO - 2018-11-26 12:45:56 --> Loader Class Initialized
INFO - 2018-11-26 12:45:56 --> Helper loaded: url_helper
INFO - 2018-11-26 12:45:56 --> Helper loaded: file_helper
INFO - 2018-11-26 12:45:56 --> Helper loaded: email_helper
INFO - 2018-11-26 12:45:56 --> Helper loaded: common_helper
INFO - 2018-11-26 12:45:56 --> Database Driver Class Initialized
DEBUG - 2018-11-26 12:45:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-26 12:45:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-26 12:45:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-26 12:45:56 --> Pagination Class Initialized
INFO - 2018-11-26 12:45:56 --> Helper loaded: form_helper
INFO - 2018-11-26 12:45:56 --> Form Validation Class Initialized
INFO - 2018-11-26 12:45:56 --> Model Class Initialized
INFO - 2018-11-26 12:45:56 --> Controller Class Initialized
INFO - 2018-11-26 12:45:56 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-26 12:45:56 --> Model Class Initialized
INFO - 2018-11-26 12:45:56 --> Model Class Initialized
INFO - 2018-11-26 12:45:56 --> Final output sent to browser
DEBUG - 2018-11-26 12:45:56 --> Total execution time: 0.0760
INFO - 2018-11-26 12:45:56 --> Config Class Initialized
INFO - 2018-11-26 12:45:56 --> Hooks Class Initialized
DEBUG - 2018-11-26 12:45:56 --> UTF-8 Support Enabled
INFO - 2018-11-26 12:45:56 --> Utf8 Class Initialized
INFO - 2018-11-26 12:45:56 --> URI Class Initialized
INFO - 2018-11-26 12:45:56 --> Router Class Initialized
INFO - 2018-11-26 12:45:56 --> Output Class Initialized
INFO - 2018-11-26 12:45:56 --> Security Class Initialized
DEBUG - 2018-11-26 12:45:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-26 12:45:56 --> Input Class Initialized
INFO - 2018-11-26 12:45:56 --> Language Class Initialized
INFO - 2018-11-26 12:45:56 --> Loader Class Initialized
INFO - 2018-11-26 12:45:56 --> Helper loaded: url_helper
INFO - 2018-11-26 12:45:56 --> Helper loaded: file_helper
INFO - 2018-11-26 12:45:56 --> Helper loaded: email_helper
INFO - 2018-11-26 12:45:56 --> Helper loaded: common_helper
INFO - 2018-11-26 12:45:56 --> Database Driver Class Initialized
DEBUG - 2018-11-26 12:45:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-26 12:45:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-26 12:45:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-26 12:45:56 --> Pagination Class Initialized
INFO - 2018-11-26 12:45:56 --> Helper loaded: form_helper
INFO - 2018-11-26 12:45:56 --> Form Validation Class Initialized
INFO - 2018-11-26 12:45:56 --> Model Class Initialized
INFO - 2018-11-26 12:45:56 --> Controller Class Initialized
INFO - 2018-11-26 12:45:56 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-26 12:45:56 --> Model Class Initialized
INFO - 2018-11-26 12:45:56 --> Model Class Initialized
INFO - 2018-11-26 12:45:56 --> Config Class Initialized
INFO - 2018-11-26 12:45:56 --> Hooks Class Initialized
DEBUG - 2018-11-26 12:45:56 --> UTF-8 Support Enabled
INFO - 2018-11-26 12:45:56 --> Utf8 Class Initialized
INFO - 2018-11-26 12:45:56 --> URI Class Initialized
INFO - 2018-11-26 12:45:56 --> Router Class Initialized
INFO - 2018-11-26 12:45:56 --> Output Class Initialized
INFO - 2018-11-26 12:45:56 --> Security Class Initialized
DEBUG - 2018-11-26 12:45:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-26 12:45:56 --> Input Class Initialized
INFO - 2018-11-26 12:45:56 --> Language Class Initialized
INFO - 2018-11-26 12:45:56 --> Loader Class Initialized
INFO - 2018-11-26 12:45:56 --> Helper loaded: url_helper
INFO - 2018-11-26 12:45:56 --> Helper loaded: file_helper
INFO - 2018-11-26 12:45:56 --> Helper loaded: email_helper
INFO - 2018-11-26 12:45:56 --> Helper loaded: common_helper
INFO - 2018-11-26 12:45:56 --> Database Driver Class Initialized
DEBUG - 2018-11-26 12:45:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-26 12:45:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-26 12:45:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-26 12:45:56 --> Pagination Class Initialized
INFO - 2018-11-26 12:45:56 --> Helper loaded: form_helper
INFO - 2018-11-26 12:45:56 --> Form Validation Class Initialized
INFO - 2018-11-26 12:45:56 --> Model Class Initialized
INFO - 2018-11-26 12:45:56 --> Controller Class Initialized
INFO - 2018-11-26 12:45:56 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-26 12:45:56 --> Model Class Initialized
INFO - 2018-11-26 12:45:56 --> Model Class Initialized
INFO - 2018-11-26 12:45:56 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/index.php
INFO - 2018-11-26 12:45:56 --> Final output sent to browser
DEBUG - 2018-11-26 12:45:56 --> Total execution time: 0.0930
INFO - 2018-11-26 12:46:26 --> Config Class Initialized
INFO - 2018-11-26 12:46:26 --> Hooks Class Initialized
DEBUG - 2018-11-26 12:46:26 --> UTF-8 Support Enabled
INFO - 2018-11-26 12:46:26 --> Utf8 Class Initialized
INFO - 2018-11-26 12:46:26 --> URI Class Initialized
INFO - 2018-11-26 12:46:26 --> Router Class Initialized
INFO - 2018-11-26 12:46:26 --> Output Class Initialized
INFO - 2018-11-26 12:46:26 --> Security Class Initialized
DEBUG - 2018-11-26 12:46:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-26 12:46:26 --> Input Class Initialized
INFO - 2018-11-26 12:46:26 --> Language Class Initialized
INFO - 2018-11-26 12:46:26 --> Loader Class Initialized
INFO - 2018-11-26 12:46:26 --> Helper loaded: url_helper
INFO - 2018-11-26 12:46:26 --> Helper loaded: file_helper
INFO - 2018-11-26 12:46:26 --> Helper loaded: email_helper
INFO - 2018-11-26 12:46:26 --> Helper loaded: common_helper
INFO - 2018-11-26 12:46:26 --> Database Driver Class Initialized
DEBUG - 2018-11-26 12:46:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-26 12:46:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-26 12:46:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-26 12:46:26 --> Pagination Class Initialized
INFO - 2018-11-26 12:46:26 --> Helper loaded: form_helper
INFO - 2018-11-26 12:46:26 --> Form Validation Class Initialized
INFO - 2018-11-26 12:46:26 --> Model Class Initialized
INFO - 2018-11-26 12:46:26 --> Controller Class Initialized
INFO - 2018-11-26 12:46:26 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-26 12:46:26 --> Model Class Initialized
INFO - 2018-11-26 12:46:26 --> Model Class Initialized
INFO - 2018-11-26 12:46:26 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/index.php
INFO - 2018-11-26 12:46:26 --> Final output sent to browser
DEBUG - 2018-11-26 12:46:26 --> Total execution time: 0.1170
INFO - 2018-11-26 12:46:55 --> Config Class Initialized
INFO - 2018-11-26 12:46:55 --> Hooks Class Initialized
DEBUG - 2018-11-26 12:46:55 --> UTF-8 Support Enabled
INFO - 2018-11-26 12:46:55 --> Utf8 Class Initialized
INFO - 2018-11-26 12:46:55 --> URI Class Initialized
INFO - 2018-11-26 12:46:55 --> Router Class Initialized
INFO - 2018-11-26 12:46:55 --> Output Class Initialized
INFO - 2018-11-26 12:46:55 --> Security Class Initialized
DEBUG - 2018-11-26 12:46:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-26 12:46:55 --> Input Class Initialized
INFO - 2018-11-26 12:46:55 --> Language Class Initialized
INFO - 2018-11-26 12:46:55 --> Loader Class Initialized
INFO - 2018-11-26 12:46:55 --> Helper loaded: url_helper
INFO - 2018-11-26 12:46:55 --> Helper loaded: file_helper
INFO - 2018-11-26 12:46:55 --> Helper loaded: email_helper
INFO - 2018-11-26 12:46:55 --> Helper loaded: common_helper
INFO - 2018-11-26 12:46:55 --> Database Driver Class Initialized
DEBUG - 2018-11-26 12:46:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-26 12:46:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-26 12:46:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-26 12:46:55 --> Pagination Class Initialized
INFO - 2018-11-26 12:46:55 --> Helper loaded: form_helper
INFO - 2018-11-26 12:46:55 --> Form Validation Class Initialized
INFO - 2018-11-26 12:46:55 --> Model Class Initialized
INFO - 2018-11-26 12:46:55 --> Controller Class Initialized
INFO - 2018-11-26 12:46:55 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-26 12:46:55 --> Model Class Initialized
INFO - 2018-11-26 12:46:55 --> Model Class Initialized
INFO - 2018-11-26 12:46:55 --> Final output sent to browser
DEBUG - 2018-11-26 12:46:55 --> Total execution time: 0.1090
INFO - 2018-11-26 12:46:56 --> Config Class Initialized
INFO - 2018-11-26 12:46:56 --> Hooks Class Initialized
DEBUG - 2018-11-26 12:46:56 --> UTF-8 Support Enabled
INFO - 2018-11-26 12:46:56 --> Utf8 Class Initialized
INFO - 2018-11-26 12:46:56 --> URI Class Initialized
INFO - 2018-11-26 12:46:56 --> Router Class Initialized
INFO - 2018-11-26 12:46:56 --> Output Class Initialized
INFO - 2018-11-26 12:46:56 --> Security Class Initialized
DEBUG - 2018-11-26 12:46:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-26 12:46:56 --> Input Class Initialized
INFO - 2018-11-26 12:46:56 --> Language Class Initialized
INFO - 2018-11-26 12:46:56 --> Loader Class Initialized
INFO - 2018-11-26 12:46:56 --> Helper loaded: url_helper
INFO - 2018-11-26 12:46:56 --> Helper loaded: file_helper
INFO - 2018-11-26 12:46:56 --> Helper loaded: email_helper
INFO - 2018-11-26 12:46:56 --> Helper loaded: common_helper
INFO - 2018-11-26 12:46:56 --> Database Driver Class Initialized
DEBUG - 2018-11-26 12:46:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-26 12:46:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-26 12:46:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-26 12:46:56 --> Pagination Class Initialized
INFO - 2018-11-26 12:46:56 --> Helper loaded: form_helper
INFO - 2018-11-26 12:46:56 --> Form Validation Class Initialized
INFO - 2018-11-26 12:46:56 --> Model Class Initialized
INFO - 2018-11-26 12:46:56 --> Controller Class Initialized
INFO - 2018-11-26 12:46:56 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-26 12:46:56 --> Model Class Initialized
INFO - 2018-11-26 12:46:56 --> Model Class Initialized
INFO - 2018-11-26 12:46:56 --> Config Class Initialized
INFO - 2018-11-26 12:46:56 --> Hooks Class Initialized
DEBUG - 2018-11-26 12:46:56 --> UTF-8 Support Enabled
INFO - 2018-11-26 12:46:56 --> Utf8 Class Initialized
INFO - 2018-11-26 12:46:56 --> URI Class Initialized
INFO - 2018-11-26 12:46:56 --> Router Class Initialized
INFO - 2018-11-26 12:46:56 --> Output Class Initialized
INFO - 2018-11-26 12:46:56 --> Security Class Initialized
DEBUG - 2018-11-26 12:46:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-26 12:46:56 --> Input Class Initialized
INFO - 2018-11-26 12:46:56 --> Language Class Initialized
INFO - 2018-11-26 12:46:56 --> Loader Class Initialized
INFO - 2018-11-26 12:46:56 --> Helper loaded: url_helper
INFO - 2018-11-26 12:46:56 --> Helper loaded: file_helper
INFO - 2018-11-26 12:46:56 --> Helper loaded: email_helper
INFO - 2018-11-26 12:46:56 --> Helper loaded: common_helper
INFO - 2018-11-26 12:46:56 --> Database Driver Class Initialized
DEBUG - 2018-11-26 12:46:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-26 12:46:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-26 12:46:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-26 12:46:56 --> Pagination Class Initialized
INFO - 2018-11-26 12:46:56 --> Helper loaded: form_helper
INFO - 2018-11-26 12:46:56 --> Form Validation Class Initialized
INFO - 2018-11-26 12:46:56 --> Model Class Initialized
INFO - 2018-11-26 12:46:56 --> Controller Class Initialized
INFO - 2018-11-26 12:46:56 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-26 12:46:56 --> Model Class Initialized
INFO - 2018-11-26 12:46:56 --> Model Class Initialized
INFO - 2018-11-26 12:46:56 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/index.php
INFO - 2018-11-26 12:46:56 --> Final output sent to browser
DEBUG - 2018-11-26 12:46:56 --> Total execution time: 0.0730
INFO - 2018-11-26 12:47:41 --> Config Class Initialized
INFO - 2018-11-26 12:47:41 --> Hooks Class Initialized
DEBUG - 2018-11-26 12:47:41 --> UTF-8 Support Enabled
INFO - 2018-11-26 12:47:41 --> Utf8 Class Initialized
INFO - 2018-11-26 12:47:41 --> URI Class Initialized
INFO - 2018-11-26 12:47:41 --> Router Class Initialized
INFO - 2018-11-26 12:47:41 --> Output Class Initialized
INFO - 2018-11-26 12:47:41 --> Security Class Initialized
DEBUG - 2018-11-26 12:47:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-26 12:47:41 --> Input Class Initialized
INFO - 2018-11-26 12:47:41 --> Language Class Initialized
INFO - 2018-11-26 12:47:41 --> Loader Class Initialized
INFO - 2018-11-26 12:47:41 --> Helper loaded: url_helper
INFO - 2018-11-26 12:47:41 --> Helper loaded: file_helper
INFO - 2018-11-26 12:47:41 --> Helper loaded: email_helper
INFO - 2018-11-26 12:47:41 --> Helper loaded: common_helper
INFO - 2018-11-26 12:47:41 --> Database Driver Class Initialized
DEBUG - 2018-11-26 12:47:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-26 12:47:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-26 12:47:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-26 12:47:41 --> Pagination Class Initialized
INFO - 2018-11-26 12:47:41 --> Helper loaded: form_helper
INFO - 2018-11-26 12:47:41 --> Form Validation Class Initialized
INFO - 2018-11-26 12:47:41 --> Model Class Initialized
INFO - 2018-11-26 12:47:41 --> Controller Class Initialized
INFO - 2018-11-26 12:47:41 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-26 12:47:41 --> Model Class Initialized
INFO - 2018-11-26 12:47:41 --> Model Class Initialized
INFO - 2018-11-26 12:47:41 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/index.php
INFO - 2018-11-26 12:47:41 --> Final output sent to browser
DEBUG - 2018-11-26 12:47:41 --> Total execution time: 0.1280
INFO - 2018-11-26 12:48:31 --> Config Class Initialized
INFO - 2018-11-26 12:48:31 --> Hooks Class Initialized
DEBUG - 2018-11-26 12:48:31 --> UTF-8 Support Enabled
INFO - 2018-11-26 12:48:31 --> Utf8 Class Initialized
INFO - 2018-11-26 12:48:31 --> URI Class Initialized
INFO - 2018-11-26 12:48:31 --> Router Class Initialized
INFO - 2018-11-26 12:48:31 --> Output Class Initialized
INFO - 2018-11-26 12:48:31 --> Security Class Initialized
DEBUG - 2018-11-26 12:48:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-26 12:48:31 --> Input Class Initialized
INFO - 2018-11-26 12:48:31 --> Language Class Initialized
ERROR - 2018-11-26 12:48:31 --> 404 Page Not Found: admin/Reset_password/index
INFO - 2018-11-26 12:49:38 --> Config Class Initialized
INFO - 2018-11-26 12:49:38 --> Hooks Class Initialized
DEBUG - 2018-11-26 12:49:38 --> UTF-8 Support Enabled
INFO - 2018-11-26 12:49:38 --> Utf8 Class Initialized
INFO - 2018-11-26 12:49:38 --> URI Class Initialized
INFO - 2018-11-26 12:49:38 --> Router Class Initialized
INFO - 2018-11-26 12:49:38 --> Output Class Initialized
INFO - 2018-11-26 12:49:38 --> Security Class Initialized
DEBUG - 2018-11-26 12:49:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-26 12:49:38 --> Input Class Initialized
INFO - 2018-11-26 12:49:38 --> Language Class Initialized
INFO - 2018-11-26 12:49:38 --> Loader Class Initialized
INFO - 2018-11-26 12:49:38 --> Helper loaded: url_helper
INFO - 2018-11-26 12:49:38 --> Helper loaded: file_helper
INFO - 2018-11-26 12:49:38 --> Helper loaded: email_helper
INFO - 2018-11-26 12:49:38 --> Helper loaded: common_helper
INFO - 2018-11-26 12:49:38 --> Database Driver Class Initialized
DEBUG - 2018-11-26 12:49:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-26 12:49:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-26 12:49:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-26 12:49:38 --> Pagination Class Initialized
INFO - 2018-11-26 12:49:38 --> Helper loaded: form_helper
INFO - 2018-11-26 12:49:38 --> Form Validation Class Initialized
INFO - 2018-11-26 12:49:38 --> Model Class Initialized
INFO - 2018-11-26 12:49:38 --> Controller Class Initialized
INFO - 2018-11-26 12:49:38 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-26 12:49:38 --> Model Class Initialized
INFO - 2018-11-26 12:49:38 --> Model Class Initialized
INFO - 2018-11-26 12:49:54 --> Config Class Initialized
INFO - 2018-11-26 12:49:54 --> Hooks Class Initialized
DEBUG - 2018-11-26 12:49:54 --> UTF-8 Support Enabled
INFO - 2018-11-26 12:49:54 --> Utf8 Class Initialized
INFO - 2018-11-26 12:49:54 --> URI Class Initialized
INFO - 2018-11-26 12:49:54 --> Router Class Initialized
INFO - 2018-11-26 12:49:54 --> Output Class Initialized
INFO - 2018-11-26 12:49:54 --> Security Class Initialized
DEBUG - 2018-11-26 12:49:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-26 12:49:54 --> Input Class Initialized
INFO - 2018-11-26 12:49:54 --> Language Class Initialized
INFO - 2018-11-26 12:49:54 --> Loader Class Initialized
INFO - 2018-11-26 12:49:54 --> Helper loaded: url_helper
INFO - 2018-11-26 12:49:54 --> Helper loaded: file_helper
INFO - 2018-11-26 12:49:54 --> Helper loaded: email_helper
INFO - 2018-11-26 12:49:54 --> Helper loaded: common_helper
INFO - 2018-11-26 12:49:54 --> Database Driver Class Initialized
DEBUG - 2018-11-26 12:49:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-26 12:49:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-26 12:49:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-26 12:49:54 --> Pagination Class Initialized
INFO - 2018-11-26 12:49:54 --> Helper loaded: form_helper
INFO - 2018-11-26 12:49:54 --> Form Validation Class Initialized
INFO - 2018-11-26 12:49:54 --> Model Class Initialized
INFO - 2018-11-26 12:49:54 --> Controller Class Initialized
INFO - 2018-11-26 12:49:54 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-26 12:49:54 --> Model Class Initialized
INFO - 2018-11-26 12:49:54 --> Model Class Initialized
INFO - 2018-11-26 12:49:54 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/reset-password.php
INFO - 2018-11-26 12:49:54 --> Final output sent to browser
DEBUG - 2018-11-26 12:49:54 --> Total execution time: 0.0820
INFO - 2018-11-26 12:50:29 --> Config Class Initialized
INFO - 2018-11-26 12:50:29 --> Hooks Class Initialized
DEBUG - 2018-11-26 12:50:29 --> UTF-8 Support Enabled
INFO - 2018-11-26 12:50:29 --> Utf8 Class Initialized
INFO - 2018-11-26 12:50:29 --> URI Class Initialized
INFO - 2018-11-26 12:50:29 --> Router Class Initialized
INFO - 2018-11-26 12:50:29 --> Output Class Initialized
INFO - 2018-11-26 12:50:29 --> Security Class Initialized
DEBUG - 2018-11-26 12:50:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-26 12:50:29 --> Input Class Initialized
INFO - 2018-11-26 12:50:29 --> Language Class Initialized
INFO - 2018-11-26 12:50:29 --> Loader Class Initialized
INFO - 2018-11-26 12:50:29 --> Helper loaded: url_helper
INFO - 2018-11-26 12:50:29 --> Helper loaded: file_helper
INFO - 2018-11-26 12:50:29 --> Helper loaded: email_helper
INFO - 2018-11-26 12:50:29 --> Helper loaded: common_helper
INFO - 2018-11-26 12:50:29 --> Database Driver Class Initialized
DEBUG - 2018-11-26 12:50:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-26 12:50:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-26 12:50:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-26 12:50:29 --> Pagination Class Initialized
INFO - 2018-11-26 12:50:29 --> Helper loaded: form_helper
INFO - 2018-11-26 12:50:29 --> Form Validation Class Initialized
INFO - 2018-11-26 12:50:29 --> Model Class Initialized
INFO - 2018-11-26 12:50:29 --> Controller Class Initialized
INFO - 2018-11-26 12:50:29 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-26 12:50:29 --> Model Class Initialized
INFO - 2018-11-26 12:50:29 --> Model Class Initialized
INFO - 2018-11-26 12:50:29 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/reset-password.php
INFO - 2018-11-26 12:50:29 --> Final output sent to browser
DEBUG - 2018-11-26 12:50:29 --> Total execution time: 0.0850
INFO - 2018-11-26 12:51:29 --> Config Class Initialized
INFO - 2018-11-26 12:51:29 --> Hooks Class Initialized
DEBUG - 2018-11-26 12:51:29 --> UTF-8 Support Enabled
INFO - 2018-11-26 12:51:29 --> Utf8 Class Initialized
INFO - 2018-11-26 12:51:29 --> URI Class Initialized
INFO - 2018-11-26 12:51:29 --> Router Class Initialized
INFO - 2018-11-26 12:51:29 --> Output Class Initialized
INFO - 2018-11-26 12:51:29 --> Security Class Initialized
DEBUG - 2018-11-26 12:51:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-26 12:51:29 --> Input Class Initialized
INFO - 2018-11-26 12:51:29 --> Language Class Initialized
INFO - 2018-11-26 12:51:29 --> Loader Class Initialized
INFO - 2018-11-26 12:51:29 --> Helper loaded: url_helper
INFO - 2018-11-26 12:51:29 --> Helper loaded: file_helper
INFO - 2018-11-26 12:51:29 --> Helper loaded: email_helper
INFO - 2018-11-26 12:51:29 --> Helper loaded: common_helper
INFO - 2018-11-26 12:51:29 --> Database Driver Class Initialized
DEBUG - 2018-11-26 12:51:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-26 12:51:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-26 12:51:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-26 12:51:29 --> Pagination Class Initialized
INFO - 2018-11-26 12:51:29 --> Helper loaded: form_helper
INFO - 2018-11-26 12:51:29 --> Form Validation Class Initialized
INFO - 2018-11-26 12:51:29 --> Model Class Initialized
INFO - 2018-11-26 12:51:29 --> Controller Class Initialized
INFO - 2018-11-26 12:51:29 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-26 12:51:29 --> Model Class Initialized
INFO - 2018-11-26 12:51:29 --> Model Class Initialized
INFO - 2018-11-26 12:51:29 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/reset-password.php
INFO - 2018-11-26 12:51:29 --> Final output sent to browser
DEBUG - 2018-11-26 12:51:29 --> Total execution time: 0.0810
INFO - 2018-11-26 12:51:49 --> Config Class Initialized
INFO - 2018-11-26 12:51:49 --> Hooks Class Initialized
DEBUG - 2018-11-26 12:51:49 --> UTF-8 Support Enabled
INFO - 2018-11-26 12:51:49 --> Utf8 Class Initialized
INFO - 2018-11-26 12:51:49 --> URI Class Initialized
INFO - 2018-11-26 12:51:49 --> Router Class Initialized
INFO - 2018-11-26 12:51:49 --> Output Class Initialized
INFO - 2018-11-26 12:51:49 --> Security Class Initialized
DEBUG - 2018-11-26 12:51:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-26 12:51:49 --> Input Class Initialized
INFO - 2018-11-26 12:51:49 --> Language Class Initialized
INFO - 2018-11-26 12:51:49 --> Loader Class Initialized
INFO - 2018-11-26 12:51:49 --> Helper loaded: url_helper
INFO - 2018-11-26 12:51:49 --> Helper loaded: file_helper
INFO - 2018-11-26 12:51:49 --> Helper loaded: email_helper
INFO - 2018-11-26 12:51:49 --> Helper loaded: common_helper
INFO - 2018-11-26 12:51:49 --> Database Driver Class Initialized
DEBUG - 2018-11-26 12:51:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-26 12:51:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-26 12:51:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-26 12:51:49 --> Pagination Class Initialized
INFO - 2018-11-26 12:51:49 --> Helper loaded: form_helper
INFO - 2018-11-26 12:51:49 --> Form Validation Class Initialized
INFO - 2018-11-26 12:51:49 --> Model Class Initialized
INFO - 2018-11-26 12:51:49 --> Controller Class Initialized
INFO - 2018-11-26 12:51:49 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-26 12:51:49 --> Model Class Initialized
INFO - 2018-11-26 12:51:49 --> Model Class Initialized
INFO - 2018-11-26 12:51:49 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/reset-password.php
INFO - 2018-11-26 12:51:49 --> Final output sent to browser
DEBUG - 2018-11-26 12:51:49 --> Total execution time: 0.0880
INFO - 2018-11-26 12:52:54 --> Config Class Initialized
INFO - 2018-11-26 12:52:54 --> Hooks Class Initialized
DEBUG - 2018-11-26 12:52:54 --> UTF-8 Support Enabled
INFO - 2018-11-26 12:52:54 --> Utf8 Class Initialized
INFO - 2018-11-26 12:52:54 --> URI Class Initialized
INFO - 2018-11-26 12:52:54 --> Router Class Initialized
INFO - 2018-11-26 12:52:54 --> Output Class Initialized
INFO - 2018-11-26 12:52:54 --> Security Class Initialized
DEBUG - 2018-11-26 12:52:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-26 12:52:54 --> Input Class Initialized
INFO - 2018-11-26 12:52:54 --> Language Class Initialized
INFO - 2018-11-26 12:52:54 --> Loader Class Initialized
INFO - 2018-11-26 12:52:54 --> Helper loaded: url_helper
INFO - 2018-11-26 12:52:54 --> Helper loaded: file_helper
INFO - 2018-11-26 12:52:54 --> Helper loaded: email_helper
INFO - 2018-11-26 12:52:54 --> Helper loaded: common_helper
INFO - 2018-11-26 12:52:54 --> Database Driver Class Initialized
DEBUG - 2018-11-26 12:52:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-26 12:52:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-26 12:52:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-26 12:52:54 --> Pagination Class Initialized
INFO - 2018-11-26 12:52:54 --> Helper loaded: form_helper
INFO - 2018-11-26 12:52:54 --> Form Validation Class Initialized
INFO - 2018-11-26 12:52:54 --> Model Class Initialized
INFO - 2018-11-26 12:52:54 --> Controller Class Initialized
INFO - 2018-11-26 12:52:54 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-26 12:52:54 --> Model Class Initialized
INFO - 2018-11-26 12:52:54 --> Model Class Initialized
INFO - 2018-11-26 12:52:54 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/index.php
INFO - 2018-11-26 12:52:54 --> Final output sent to browser
DEBUG - 2018-11-26 12:52:54 --> Total execution time: 0.0860
INFO - 2018-11-26 14:26:21 --> Config Class Initialized
INFO - 2018-11-26 14:26:21 --> Hooks Class Initialized
DEBUG - 2018-11-26 14:26:21 --> UTF-8 Support Enabled
INFO - 2018-11-26 14:26:21 --> Utf8 Class Initialized
INFO - 2018-11-26 14:26:21 --> URI Class Initialized
INFO - 2018-11-26 14:26:21 --> Router Class Initialized
INFO - 2018-11-26 14:26:21 --> Output Class Initialized
INFO - 2018-11-26 14:26:21 --> Security Class Initialized
DEBUG - 2018-11-26 14:26:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-26 14:26:21 --> Input Class Initialized
INFO - 2018-11-26 14:26:21 --> Language Class Initialized
INFO - 2018-11-26 14:26:21 --> Loader Class Initialized
INFO - 2018-11-26 14:26:21 --> Helper loaded: url_helper
INFO - 2018-11-26 14:26:21 --> Helper loaded: file_helper
INFO - 2018-11-26 14:26:21 --> Helper loaded: email_helper
INFO - 2018-11-26 14:26:21 --> Helper loaded: common_helper
INFO - 2018-11-26 14:26:21 --> Database Driver Class Initialized
DEBUG - 2018-11-26 14:26:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-26 14:26:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-26 14:26:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-26 14:26:21 --> Pagination Class Initialized
INFO - 2018-11-26 14:26:21 --> Helper loaded: form_helper
INFO - 2018-11-26 14:26:21 --> Form Validation Class Initialized
INFO - 2018-11-26 14:26:21 --> Model Class Initialized
INFO - 2018-11-26 14:26:21 --> Controller Class Initialized
INFO - 2018-11-26 14:26:21 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-26 14:26:21 --> Model Class Initialized
INFO - 2018-11-26 14:26:21 --> Model Class Initialized
INFO - 2018-11-26 14:26:21 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/reset-password.php
INFO - 2018-11-26 14:26:21 --> Final output sent to browser
DEBUG - 2018-11-26 14:26:21 --> Total execution time: 0.1210
INFO - 2018-11-26 14:26:56 --> Config Class Initialized
INFO - 2018-11-26 14:26:56 --> Hooks Class Initialized
DEBUG - 2018-11-26 14:26:56 --> UTF-8 Support Enabled
INFO - 2018-11-26 14:26:56 --> Utf8 Class Initialized
INFO - 2018-11-26 14:26:56 --> URI Class Initialized
INFO - 2018-11-26 14:26:56 --> Router Class Initialized
INFO - 2018-11-26 14:26:56 --> Output Class Initialized
INFO - 2018-11-26 14:26:56 --> Security Class Initialized
DEBUG - 2018-11-26 14:26:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-26 14:26:56 --> Input Class Initialized
INFO - 2018-11-26 14:26:56 --> Language Class Initialized
INFO - 2018-11-26 14:26:56 --> Loader Class Initialized
INFO - 2018-11-26 14:26:56 --> Helper loaded: url_helper
INFO - 2018-11-26 14:26:56 --> Helper loaded: file_helper
INFO - 2018-11-26 14:26:56 --> Helper loaded: email_helper
INFO - 2018-11-26 14:26:56 --> Helper loaded: common_helper
INFO - 2018-11-26 14:26:56 --> Database Driver Class Initialized
DEBUG - 2018-11-26 14:26:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-26 14:26:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-26 14:26:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-26 14:26:56 --> Pagination Class Initialized
INFO - 2018-11-26 14:26:56 --> Helper loaded: form_helper
INFO - 2018-11-26 14:26:56 --> Form Validation Class Initialized
INFO - 2018-11-26 14:26:56 --> Model Class Initialized
INFO - 2018-11-26 14:26:56 --> Controller Class Initialized
INFO - 2018-11-26 14:26:56 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-26 14:26:56 --> Model Class Initialized
INFO - 2018-11-26 14:26:56 --> Model Class Initialized
INFO - 2018-11-26 14:26:56 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/reset-password.php
INFO - 2018-11-26 14:26:56 --> Final output sent to browser
DEBUG - 2018-11-26 14:26:56 --> Total execution time: 0.0800

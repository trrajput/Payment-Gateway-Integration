<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2018-11-22 05:46:54 --> Config Class Initialized
INFO - 2018-11-22 05:46:54 --> Hooks Class Initialized
DEBUG - 2018-11-22 05:46:54 --> UTF-8 Support Enabled
INFO - 2018-11-22 05:46:54 --> Utf8 Class Initialized
INFO - 2018-11-22 05:46:54 --> URI Class Initialized
INFO - 2018-11-22 05:46:54 --> Router Class Initialized
INFO - 2018-11-22 05:46:54 --> Output Class Initialized
INFO - 2018-11-22 05:46:54 --> Security Class Initialized
DEBUG - 2018-11-22 05:46:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-22 05:46:54 --> Input Class Initialized
INFO - 2018-11-22 05:46:54 --> Language Class Initialized
INFO - 2018-11-22 05:46:54 --> Loader Class Initialized
INFO - 2018-11-22 05:46:54 --> Helper loaded: url_helper
INFO - 2018-11-22 05:46:54 --> Helper loaded: file_helper
INFO - 2018-11-22 05:46:54 --> Helper loaded: email_helper
INFO - 2018-11-22 05:46:54 --> Helper loaded: common_helper
INFO - 2018-11-22 05:46:54 --> Database Driver Class Initialized
DEBUG - 2018-11-22 05:46:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-22 05:46:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-22 05:46:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-22 05:46:54 --> Pagination Class Initialized
INFO - 2018-11-22 05:46:54 --> Helper loaded: form_helper
INFO - 2018-11-22 05:46:54 --> Form Validation Class Initialized
INFO - 2018-11-22 05:46:54 --> Model Class Initialized
INFO - 2018-11-22 05:46:54 --> Controller Class Initialized
INFO - 2018-11-22 05:46:54 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-22 05:46:54 --> Model Class Initialized
INFO - 2018-11-22 05:46:54 --> Model Class Initialized
INFO - 2018-11-22 05:46:54 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/index.php
INFO - 2018-11-22 05:46:54 --> Final output sent to browser
DEBUG - 2018-11-22 05:46:54 --> Total execution time: 0.1200
INFO - 2018-11-22 05:46:57 --> Config Class Initialized
INFO - 2018-11-22 05:46:57 --> Hooks Class Initialized
DEBUG - 2018-11-22 05:46:57 --> UTF-8 Support Enabled
INFO - 2018-11-22 05:46:57 --> Utf8 Class Initialized
INFO - 2018-11-22 05:46:57 --> URI Class Initialized
INFO - 2018-11-22 05:46:57 --> Router Class Initialized
INFO - 2018-11-22 05:46:57 --> Output Class Initialized
INFO - 2018-11-22 05:46:57 --> Security Class Initialized
DEBUG - 2018-11-22 05:46:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-22 05:46:57 --> Input Class Initialized
INFO - 2018-11-22 05:46:57 --> Language Class Initialized
INFO - 2018-11-22 05:46:57 --> Loader Class Initialized
INFO - 2018-11-22 05:46:57 --> Helper loaded: url_helper
INFO - 2018-11-22 05:46:57 --> Helper loaded: file_helper
INFO - 2018-11-22 05:46:57 --> Helper loaded: email_helper
INFO - 2018-11-22 05:46:57 --> Helper loaded: common_helper
INFO - 2018-11-22 05:46:57 --> Database Driver Class Initialized
DEBUG - 2018-11-22 05:46:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-22 05:46:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-22 05:46:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-22 05:46:57 --> Pagination Class Initialized
INFO - 2018-11-22 05:46:57 --> Helper loaded: form_helper
INFO - 2018-11-22 05:46:57 --> Form Validation Class Initialized
INFO - 2018-11-22 05:46:57 --> Model Class Initialized
INFO - 2018-11-22 05:46:57 --> Controller Class Initialized
INFO - 2018-11-22 05:46:57 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-22 05:46:57 --> Model Class Initialized
INFO - 2018-11-22 05:46:57 --> Model Class Initialized
ERROR - 2018-11-22 05:46:57 --> Severity: Notice --> Undefined index: remember_me C:\xampp\htdocs\wetinuneed\application\controllers\admin\Admin.php 77
INFO - 2018-11-22 05:46:57 --> Config Class Initialized
INFO - 2018-11-22 05:46:57 --> Hooks Class Initialized
DEBUG - 2018-11-22 05:46:57 --> UTF-8 Support Enabled
INFO - 2018-11-22 05:46:57 --> Utf8 Class Initialized
INFO - 2018-11-22 05:46:57 --> URI Class Initialized
INFO - 2018-11-22 05:46:57 --> Router Class Initialized
INFO - 2018-11-22 05:46:57 --> Output Class Initialized
INFO - 2018-11-22 05:46:57 --> Security Class Initialized
DEBUG - 2018-11-22 05:46:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-22 05:46:57 --> Input Class Initialized
INFO - 2018-11-22 05:46:57 --> Language Class Initialized
INFO - 2018-11-22 05:46:57 --> Loader Class Initialized
INFO - 2018-11-22 05:46:57 --> Helper loaded: url_helper
INFO - 2018-11-22 05:46:57 --> Helper loaded: file_helper
INFO - 2018-11-22 05:46:57 --> Helper loaded: email_helper
INFO - 2018-11-22 05:46:57 --> Helper loaded: common_helper
INFO - 2018-11-22 05:46:57 --> Database Driver Class Initialized
DEBUG - 2018-11-22 05:46:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-22 05:46:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-22 05:46:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-22 05:46:57 --> Pagination Class Initialized
INFO - 2018-11-22 05:46:57 --> Helper loaded: form_helper
INFO - 2018-11-22 05:46:57 --> Form Validation Class Initialized
INFO - 2018-11-22 05:46:57 --> Model Class Initialized
INFO - 2018-11-22 05:46:57 --> Controller Class Initialized
INFO - 2018-11-22 05:46:57 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-22 05:46:57 --> Model Class Initialized
INFO - 2018-11-22 05:46:57 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-22 05:46:57 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/sidebar.php
INFO - 2018-11-22 05:46:57 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/right-sidebar.php
INFO - 2018-11-22 05:46:57 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/footer.php
INFO - 2018-11-22 05:46:57 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/dashboard.php
INFO - 2018-11-22 05:46:57 --> Final output sent to browser
DEBUG - 2018-11-22 05:46:57 --> Total execution time: 0.0470
INFO - 2018-11-22 05:49:15 --> Config Class Initialized
INFO - 2018-11-22 05:49:15 --> Hooks Class Initialized
DEBUG - 2018-11-22 05:49:15 --> UTF-8 Support Enabled
INFO - 2018-11-22 05:49:15 --> Utf8 Class Initialized
INFO - 2018-11-22 05:49:15 --> URI Class Initialized
INFO - 2018-11-22 05:49:15 --> Router Class Initialized
INFO - 2018-11-22 05:49:15 --> Output Class Initialized
INFO - 2018-11-22 05:49:15 --> Security Class Initialized
DEBUG - 2018-11-22 05:49:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-22 05:49:15 --> Input Class Initialized
INFO - 2018-11-22 05:49:15 --> Language Class Initialized
INFO - 2018-11-22 05:49:15 --> Loader Class Initialized
INFO - 2018-11-22 05:49:15 --> Helper loaded: url_helper
INFO - 2018-11-22 05:49:15 --> Helper loaded: file_helper
INFO - 2018-11-22 05:49:15 --> Helper loaded: email_helper
INFO - 2018-11-22 05:49:15 --> Helper loaded: common_helper
INFO - 2018-11-22 05:49:15 --> Database Driver Class Initialized
DEBUG - 2018-11-22 05:49:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-22 05:49:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-22 05:49:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-22 05:49:15 --> Pagination Class Initialized
INFO - 2018-11-22 05:49:16 --> Helper loaded: form_helper
INFO - 2018-11-22 05:49:16 --> Form Validation Class Initialized
INFO - 2018-11-22 05:49:16 --> Model Class Initialized
INFO - 2018-11-22 05:49:16 --> Controller Class Initialized
INFO - 2018-11-22 05:49:16 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-22 05:49:16 --> Model Class Initialized
INFO - 2018-11-22 05:49:16 --> Config Class Initialized
INFO - 2018-11-22 05:49:16 --> Hooks Class Initialized
DEBUG - 2018-11-22 05:49:16 --> UTF-8 Support Enabled
INFO - 2018-11-22 05:49:16 --> Utf8 Class Initialized
INFO - 2018-11-22 05:49:16 --> URI Class Initialized
DEBUG - 2018-11-22 05:49:16 --> No URI present. Default controller set.
INFO - 2018-11-22 05:49:16 --> Router Class Initialized
INFO - 2018-11-22 05:49:16 --> Output Class Initialized
INFO - 2018-11-22 05:49:16 --> Security Class Initialized
DEBUG - 2018-11-22 05:49:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-22 05:49:16 --> Input Class Initialized
INFO - 2018-11-22 05:49:16 --> Language Class Initialized
INFO - 2018-11-22 05:49:16 --> Loader Class Initialized
INFO - 2018-11-22 05:49:16 --> Helper loaded: url_helper
INFO - 2018-11-22 05:49:16 --> Helper loaded: file_helper
INFO - 2018-11-22 05:49:16 --> Helper loaded: email_helper
INFO - 2018-11-22 05:49:16 --> Helper loaded: common_helper
INFO - 2018-11-22 05:49:16 --> Database Driver Class Initialized
DEBUG - 2018-11-22 05:49:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-22 05:49:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-22 05:49:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-22 05:49:16 --> Pagination Class Initialized
INFO - 2018-11-22 05:49:16 --> Helper loaded: form_helper
INFO - 2018-11-22 05:49:16 --> Form Validation Class Initialized
INFO - 2018-11-22 05:49:16 --> Model Class Initialized
INFO - 2018-11-22 05:49:16 --> Controller Class Initialized
INFO - 2018-11-22 05:49:16 --> Model Class Initialized
INFO - 2018-11-22 05:49:16 --> Model Class Initialized
INFO - 2018-11-22 05:49:16 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\template/header-menu.php
INFO - 2018-11-22 05:49:16 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\template/header.php
INFO - 2018-11-22 05:49:16 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\template/footer.php
INFO - 2018-11-22 05:49:16 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\index.php
INFO - 2018-11-22 05:49:16 --> Final output sent to browser
DEBUG - 2018-11-22 05:49:16 --> Total execution time: 0.0490
INFO - 2018-11-22 05:49:20 --> Config Class Initialized
INFO - 2018-11-22 05:49:20 --> Hooks Class Initialized
DEBUG - 2018-11-22 05:49:20 --> UTF-8 Support Enabled
INFO - 2018-11-22 05:49:20 --> Utf8 Class Initialized
INFO - 2018-11-22 05:49:20 --> URI Class Initialized
INFO - 2018-11-22 05:49:20 --> Router Class Initialized
INFO - 2018-11-22 05:49:20 --> Output Class Initialized
INFO - 2018-11-22 05:49:20 --> Security Class Initialized
DEBUG - 2018-11-22 05:49:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-22 05:49:20 --> Input Class Initialized
INFO - 2018-11-22 05:49:20 --> Language Class Initialized
INFO - 2018-11-22 05:49:20 --> Loader Class Initialized
INFO - 2018-11-22 05:49:20 --> Helper loaded: url_helper
INFO - 2018-11-22 05:49:20 --> Helper loaded: file_helper
INFO - 2018-11-22 05:49:20 --> Helper loaded: email_helper
INFO - 2018-11-22 05:49:20 --> Helper loaded: common_helper
INFO - 2018-11-22 05:49:20 --> Database Driver Class Initialized
DEBUG - 2018-11-22 05:49:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-22 05:49:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-22 05:49:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-22 05:49:20 --> Pagination Class Initialized
INFO - 2018-11-22 05:49:20 --> Helper loaded: form_helper
INFO - 2018-11-22 05:49:20 --> Form Validation Class Initialized
INFO - 2018-11-22 05:49:20 --> Model Class Initialized
INFO - 2018-11-22 05:49:20 --> Controller Class Initialized
INFO - 2018-11-22 05:49:20 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-22 05:49:20 --> Model Class Initialized
INFO - 2018-11-22 05:49:20 --> Model Class Initialized
INFO - 2018-11-22 05:49:20 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/index.php
INFO - 2018-11-22 05:49:20 --> Final output sent to browser
DEBUG - 2018-11-22 05:49:20 --> Total execution time: 0.0510
INFO - 2018-11-22 05:49:29 --> Config Class Initialized
INFO - 2018-11-22 05:49:29 --> Hooks Class Initialized
DEBUG - 2018-11-22 05:49:29 --> UTF-8 Support Enabled
INFO - 2018-11-22 05:49:29 --> Utf8 Class Initialized
INFO - 2018-11-22 05:49:29 --> URI Class Initialized
INFO - 2018-11-22 05:49:29 --> Router Class Initialized
INFO - 2018-11-22 05:49:29 --> Output Class Initialized
INFO - 2018-11-22 05:49:29 --> Security Class Initialized
DEBUG - 2018-11-22 05:49:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-22 05:49:29 --> Input Class Initialized
INFO - 2018-11-22 05:49:29 --> Language Class Initialized
INFO - 2018-11-22 05:49:29 --> Loader Class Initialized
INFO - 2018-11-22 05:49:29 --> Helper loaded: url_helper
INFO - 2018-11-22 05:49:29 --> Helper loaded: file_helper
INFO - 2018-11-22 05:49:29 --> Helper loaded: email_helper
INFO - 2018-11-22 05:49:29 --> Helper loaded: common_helper
INFO - 2018-11-22 05:49:30 --> Database Driver Class Initialized
DEBUG - 2018-11-22 05:49:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-22 05:49:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-22 05:49:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-22 05:49:30 --> Pagination Class Initialized
INFO - 2018-11-22 05:49:30 --> Helper loaded: form_helper
INFO - 2018-11-22 05:49:30 --> Form Validation Class Initialized
INFO - 2018-11-22 05:49:30 --> Model Class Initialized
INFO - 2018-11-22 05:49:30 --> Controller Class Initialized
INFO - 2018-11-22 05:49:30 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-22 05:49:30 --> Model Class Initialized
INFO - 2018-11-22 05:49:30 --> Model Class Initialized
ERROR - 2018-11-22 05:49:30 --> Severity: Notice --> Undefined index: remember_me C:\xampp\htdocs\wetinuneed\application\controllers\admin\Admin.php 77
INFO - 2018-11-22 05:49:30 --> Config Class Initialized
INFO - 2018-11-22 05:49:30 --> Hooks Class Initialized
DEBUG - 2018-11-22 05:49:30 --> UTF-8 Support Enabled
INFO - 2018-11-22 05:49:30 --> Utf8 Class Initialized
INFO - 2018-11-22 05:49:30 --> URI Class Initialized
INFO - 2018-11-22 05:49:30 --> Router Class Initialized
INFO - 2018-11-22 05:49:30 --> Output Class Initialized
INFO - 2018-11-22 05:49:30 --> Security Class Initialized
DEBUG - 2018-11-22 05:49:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-22 05:49:30 --> Input Class Initialized
INFO - 2018-11-22 05:49:30 --> Language Class Initialized
INFO - 2018-11-22 05:49:30 --> Loader Class Initialized
INFO - 2018-11-22 05:49:30 --> Helper loaded: url_helper
INFO - 2018-11-22 05:49:30 --> Helper loaded: file_helper
INFO - 2018-11-22 05:49:30 --> Helper loaded: email_helper
INFO - 2018-11-22 05:49:30 --> Helper loaded: common_helper
INFO - 2018-11-22 05:49:30 --> Database Driver Class Initialized
DEBUG - 2018-11-22 05:49:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-22 05:49:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-22 05:49:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-22 05:49:30 --> Pagination Class Initialized
INFO - 2018-11-22 05:49:30 --> Helper loaded: form_helper
INFO - 2018-11-22 05:49:30 --> Form Validation Class Initialized
INFO - 2018-11-22 05:49:30 --> Model Class Initialized
INFO - 2018-11-22 05:49:30 --> Controller Class Initialized
INFO - 2018-11-22 05:49:30 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-22 05:49:30 --> Model Class Initialized
INFO - 2018-11-22 05:49:30 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-22 05:49:30 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/sidebar.php
INFO - 2018-11-22 05:49:30 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/right-sidebar.php
INFO - 2018-11-22 05:49:30 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/footer.php
INFO - 2018-11-22 05:49:30 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/dashboard.php
INFO - 2018-11-22 05:49:30 --> Final output sent to browser
DEBUG - 2018-11-22 05:49:30 --> Total execution time: 0.0530
INFO - 2018-11-22 05:49:43 --> Config Class Initialized
INFO - 2018-11-22 05:49:43 --> Hooks Class Initialized
DEBUG - 2018-11-22 05:49:43 --> UTF-8 Support Enabled
INFO - 2018-11-22 05:49:43 --> Utf8 Class Initialized
INFO - 2018-11-22 05:49:43 --> URI Class Initialized
INFO - 2018-11-22 05:49:43 --> Router Class Initialized
INFO - 2018-11-22 05:49:43 --> Output Class Initialized
INFO - 2018-11-22 05:49:43 --> Security Class Initialized
DEBUG - 2018-11-22 05:49:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-22 05:49:43 --> Input Class Initialized
INFO - 2018-11-22 05:49:43 --> Language Class Initialized
INFO - 2018-11-22 05:49:43 --> Loader Class Initialized
INFO - 2018-11-22 05:49:43 --> Helper loaded: url_helper
INFO - 2018-11-22 05:49:43 --> Helper loaded: file_helper
INFO - 2018-11-22 05:49:43 --> Helper loaded: email_helper
INFO - 2018-11-22 05:49:43 --> Helper loaded: common_helper
INFO - 2018-11-22 05:49:43 --> Database Driver Class Initialized
DEBUG - 2018-11-22 05:49:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-22 05:49:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-22 05:49:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-22 05:49:43 --> Pagination Class Initialized
INFO - 2018-11-22 05:49:43 --> Helper loaded: form_helper
INFO - 2018-11-22 05:49:43 --> Form Validation Class Initialized
INFO - 2018-11-22 05:49:43 --> Model Class Initialized
INFO - 2018-11-22 05:49:43 --> Controller Class Initialized
INFO - 2018-11-22 05:49:43 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-22 05:49:43 --> Model Class Initialized
INFO - 2018-11-22 05:49:43 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-22 05:49:43 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/sidebar.php
INFO - 2018-11-22 05:49:43 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/right-sidebar.php
INFO - 2018-11-22 05:49:43 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/footer.php
INFO - 2018-11-22 05:49:43 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/dashboard.php
INFO - 2018-11-22 05:49:43 --> Final output sent to browser
DEBUG - 2018-11-22 05:49:43 --> Total execution time: 0.0500
INFO - 2018-11-22 05:49:46 --> Config Class Initialized
INFO - 2018-11-22 05:49:46 --> Hooks Class Initialized
DEBUG - 2018-11-22 05:49:46 --> UTF-8 Support Enabled
INFO - 2018-11-22 05:49:46 --> Utf8 Class Initialized
INFO - 2018-11-22 05:49:46 --> URI Class Initialized
INFO - 2018-11-22 05:49:46 --> Router Class Initialized
INFO - 2018-11-22 05:49:46 --> Output Class Initialized
INFO - 2018-11-22 05:49:46 --> Security Class Initialized
DEBUG - 2018-11-22 05:49:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-22 05:49:46 --> Input Class Initialized
INFO - 2018-11-22 05:49:46 --> Language Class Initialized
INFO - 2018-11-22 05:49:46 --> Loader Class Initialized
INFO - 2018-11-22 05:49:46 --> Helper loaded: url_helper
INFO - 2018-11-22 05:49:46 --> Helper loaded: file_helper
INFO - 2018-11-22 05:49:46 --> Helper loaded: email_helper
INFO - 2018-11-22 05:49:46 --> Helper loaded: common_helper
INFO - 2018-11-22 05:49:46 --> Database Driver Class Initialized
DEBUG - 2018-11-22 05:49:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-22 05:49:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-22 05:49:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-22 05:49:46 --> Pagination Class Initialized
INFO - 2018-11-22 05:49:46 --> Helper loaded: form_helper
INFO - 2018-11-22 05:49:46 --> Form Validation Class Initialized
INFO - 2018-11-22 05:49:46 --> Model Class Initialized
INFO - 2018-11-22 05:49:46 --> Controller Class Initialized
INFO - 2018-11-22 05:49:46 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-22 05:49:46 --> Model Class Initialized
INFO - 2018-11-22 05:49:46 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-22 05:49:46 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/sidebar.php
INFO - 2018-11-22 05:49:46 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/right-sidebar.php
INFO - 2018-11-22 05:49:46 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/footer.php
INFO - 2018-11-22 05:49:46 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/dashboard.php
INFO - 2018-11-22 05:49:46 --> Final output sent to browser
DEBUG - 2018-11-22 05:49:46 --> Total execution time: 0.0680
INFO - 2018-11-22 05:49:48 --> Config Class Initialized
INFO - 2018-11-22 05:49:48 --> Hooks Class Initialized
DEBUG - 2018-11-22 05:49:48 --> UTF-8 Support Enabled
INFO - 2018-11-22 05:49:48 --> Utf8 Class Initialized
INFO - 2018-11-22 05:49:48 --> URI Class Initialized
INFO - 2018-11-22 05:49:48 --> Router Class Initialized
INFO - 2018-11-22 05:49:48 --> Output Class Initialized
INFO - 2018-11-22 05:49:48 --> Security Class Initialized
DEBUG - 2018-11-22 05:49:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-22 05:49:48 --> Input Class Initialized
INFO - 2018-11-22 05:49:48 --> Language Class Initialized
INFO - 2018-11-22 05:49:48 --> Loader Class Initialized
INFO - 2018-11-22 05:49:48 --> Helper loaded: url_helper
INFO - 2018-11-22 05:49:48 --> Helper loaded: file_helper
INFO - 2018-11-22 05:49:48 --> Helper loaded: email_helper
INFO - 2018-11-22 05:49:48 --> Helper loaded: common_helper
INFO - 2018-11-22 05:49:48 --> Database Driver Class Initialized
DEBUG - 2018-11-22 05:49:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-22 05:49:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-22 05:49:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-22 05:49:48 --> Pagination Class Initialized
INFO - 2018-11-22 05:49:48 --> Helper loaded: form_helper
INFO - 2018-11-22 05:49:48 --> Form Validation Class Initialized
INFO - 2018-11-22 05:49:48 --> Model Class Initialized
INFO - 2018-11-22 05:49:48 --> Controller Class Initialized
INFO - 2018-11-22 05:49:48 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-22 05:49:48 --> Model Class Initialized
INFO - 2018-11-22 05:49:48 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-22 05:49:48 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/sidebar.php
INFO - 2018-11-22 05:49:48 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/right-sidebar.php
INFO - 2018-11-22 05:49:48 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/footer.php
INFO - 2018-11-22 05:49:48 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/dashboard.php
INFO - 2018-11-22 05:49:48 --> Final output sent to browser
DEBUG - 2018-11-22 05:49:48 --> Total execution time: 0.0580
INFO - 2018-11-22 05:49:52 --> Config Class Initialized
INFO - 2018-11-22 05:49:52 --> Hooks Class Initialized
DEBUG - 2018-11-22 05:49:52 --> UTF-8 Support Enabled
INFO - 2018-11-22 05:49:52 --> Utf8 Class Initialized
INFO - 2018-11-22 05:49:52 --> URI Class Initialized
INFO - 2018-11-22 05:49:52 --> Router Class Initialized
INFO - 2018-11-22 05:49:52 --> Output Class Initialized
INFO - 2018-11-22 05:49:52 --> Security Class Initialized
DEBUG - 2018-11-22 05:49:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-22 05:49:52 --> Input Class Initialized
INFO - 2018-11-22 05:49:52 --> Language Class Initialized
INFO - 2018-11-22 05:49:52 --> Loader Class Initialized
INFO - 2018-11-22 05:49:52 --> Helper loaded: url_helper
INFO - 2018-11-22 05:49:52 --> Helper loaded: file_helper
INFO - 2018-11-22 05:49:52 --> Helper loaded: email_helper
INFO - 2018-11-22 05:49:52 --> Helper loaded: common_helper
INFO - 2018-11-22 05:49:52 --> Database Driver Class Initialized
DEBUG - 2018-11-22 05:49:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-22 05:49:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-22 05:49:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-22 05:49:52 --> Pagination Class Initialized
INFO - 2018-11-22 05:49:52 --> Helper loaded: form_helper
INFO - 2018-11-22 05:49:52 --> Form Validation Class Initialized
INFO - 2018-11-22 05:49:52 --> Model Class Initialized
INFO - 2018-11-22 05:49:52 --> Controller Class Initialized
INFO - 2018-11-22 05:49:52 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-22 05:49:52 --> Model Class Initialized
INFO - 2018-11-22 05:49:52 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-22 05:49:52 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/sidebar.php
INFO - 2018-11-22 05:49:52 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/right-sidebar.php
INFO - 2018-11-22 05:49:52 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/footer.php
INFO - 2018-11-22 05:49:52 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/dashboard.php
INFO - 2018-11-22 05:49:52 --> Final output sent to browser
DEBUG - 2018-11-22 05:49:52 --> Total execution time: 0.0530
INFO - 2018-11-22 05:49:55 --> Config Class Initialized
INFO - 2018-11-22 05:49:55 --> Hooks Class Initialized
DEBUG - 2018-11-22 05:49:55 --> UTF-8 Support Enabled
INFO - 2018-11-22 05:49:55 --> Utf8 Class Initialized
INFO - 2018-11-22 05:49:55 --> URI Class Initialized
INFO - 2018-11-22 05:49:55 --> Router Class Initialized
INFO - 2018-11-22 05:49:55 --> Output Class Initialized
INFO - 2018-11-22 05:49:55 --> Security Class Initialized
DEBUG - 2018-11-22 05:49:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-22 05:49:55 --> Input Class Initialized
INFO - 2018-11-22 05:49:55 --> Language Class Initialized
INFO - 2018-11-22 05:49:55 --> Loader Class Initialized
INFO - 2018-11-22 05:49:55 --> Helper loaded: url_helper
INFO - 2018-11-22 05:49:55 --> Helper loaded: file_helper
INFO - 2018-11-22 05:49:55 --> Helper loaded: email_helper
INFO - 2018-11-22 05:49:55 --> Helper loaded: common_helper
INFO - 2018-11-22 05:49:55 --> Database Driver Class Initialized
DEBUG - 2018-11-22 05:49:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-22 05:49:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-22 05:49:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-22 05:49:55 --> Pagination Class Initialized
INFO - 2018-11-22 05:49:55 --> Helper loaded: form_helper
INFO - 2018-11-22 05:49:55 --> Form Validation Class Initialized
INFO - 2018-11-22 05:49:55 --> Model Class Initialized
INFO - 2018-11-22 05:49:55 --> Controller Class Initialized
INFO - 2018-11-22 05:49:55 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-22 05:49:55 --> Model Class Initialized
INFO - 2018-11-22 05:49:55 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-22 05:49:55 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/sidebar.php
INFO - 2018-11-22 05:49:55 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/right-sidebar.php
INFO - 2018-11-22 05:49:55 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/footer.php
INFO - 2018-11-22 05:49:55 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/dashboard.php
INFO - 2018-11-22 05:49:55 --> Final output sent to browser
DEBUG - 2018-11-22 05:49:55 --> Total execution time: 0.0690
INFO - 2018-11-22 05:50:01 --> Config Class Initialized
INFO - 2018-11-22 05:50:01 --> Hooks Class Initialized
DEBUG - 2018-11-22 05:50:01 --> UTF-8 Support Enabled
INFO - 2018-11-22 05:50:01 --> Utf8 Class Initialized
INFO - 2018-11-22 05:50:01 --> URI Class Initialized
INFO - 2018-11-22 05:50:01 --> Router Class Initialized
INFO - 2018-11-22 05:50:01 --> Output Class Initialized
INFO - 2018-11-22 05:50:01 --> Security Class Initialized
DEBUG - 2018-11-22 05:50:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-22 05:50:01 --> Input Class Initialized
INFO - 2018-11-22 05:50:01 --> Language Class Initialized
INFO - 2018-11-22 05:50:01 --> Loader Class Initialized
INFO - 2018-11-22 05:50:01 --> Helper loaded: url_helper
INFO - 2018-11-22 05:50:01 --> Helper loaded: file_helper
INFO - 2018-11-22 05:50:01 --> Helper loaded: email_helper
INFO - 2018-11-22 05:50:01 --> Helper loaded: common_helper
INFO - 2018-11-22 05:50:01 --> Database Driver Class Initialized
DEBUG - 2018-11-22 05:50:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-22 05:50:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-22 05:50:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-22 05:50:01 --> Pagination Class Initialized
INFO - 2018-11-22 05:50:01 --> Helper loaded: form_helper
INFO - 2018-11-22 05:50:01 --> Form Validation Class Initialized
INFO - 2018-11-22 05:50:01 --> Model Class Initialized
INFO - 2018-11-22 05:50:01 --> Controller Class Initialized
INFO - 2018-11-22 05:50:01 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-22 05:50:01 --> Model Class Initialized
INFO - 2018-11-22 05:50:01 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-22 05:50:01 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/sidebar.php
INFO - 2018-11-22 05:50:01 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/right-sidebar.php
INFO - 2018-11-22 05:50:01 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/footer.php
INFO - 2018-11-22 05:50:01 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/dashboard.php
INFO - 2018-11-22 05:50:01 --> Final output sent to browser
DEBUG - 2018-11-22 05:50:01 --> Total execution time: 0.0550
INFO - 2018-11-22 13:04:44 --> Config Class Initialized
INFO - 2018-11-22 13:04:44 --> Hooks Class Initialized
DEBUG - 2018-11-22 13:04:44 --> UTF-8 Support Enabled
INFO - 2018-11-22 13:04:44 --> Utf8 Class Initialized
INFO - 2018-11-22 13:04:44 --> URI Class Initialized
INFO - 2018-11-22 13:04:44 --> Router Class Initialized
INFO - 2018-11-22 13:04:44 --> Output Class Initialized
INFO - 2018-11-22 13:04:44 --> Security Class Initialized
DEBUG - 2018-11-22 13:04:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-22 13:04:44 --> Input Class Initialized
INFO - 2018-11-22 13:04:44 --> Language Class Initialized
INFO - 2018-11-22 13:04:44 --> Loader Class Initialized
INFO - 2018-11-22 13:04:44 --> Helper loaded: url_helper
INFO - 2018-11-22 13:04:44 --> Helper loaded: file_helper
INFO - 2018-11-22 13:04:44 --> Helper loaded: email_helper
INFO - 2018-11-22 13:04:44 --> Helper loaded: common_helper
INFO - 2018-11-22 13:04:44 --> Database Driver Class Initialized
DEBUG - 2018-11-22 13:04:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-22 13:04:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-22 13:04:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-22 13:04:44 --> Pagination Class Initialized
INFO - 2018-11-22 13:04:44 --> Helper loaded: form_helper
INFO - 2018-11-22 13:04:44 --> Form Validation Class Initialized
INFO - 2018-11-22 13:04:44 --> Model Class Initialized
INFO - 2018-11-22 13:04:44 --> Controller Class Initialized
INFO - 2018-11-22 13:04:44 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-22 13:04:44 --> Model Class Initialized
INFO - 2018-11-22 13:04:44 --> Config Class Initialized
INFO - 2018-11-22 13:04:44 --> Hooks Class Initialized
DEBUG - 2018-11-22 13:04:44 --> UTF-8 Support Enabled
INFO - 2018-11-22 13:04:44 --> Utf8 Class Initialized
INFO - 2018-11-22 13:04:44 --> URI Class Initialized
DEBUG - 2018-11-22 13:04:44 --> No URI present. Default controller set.
INFO - 2018-11-22 13:04:44 --> Router Class Initialized
INFO - 2018-11-22 13:04:44 --> Output Class Initialized
INFO - 2018-11-22 13:04:44 --> Security Class Initialized
DEBUG - 2018-11-22 13:04:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-22 13:04:44 --> Input Class Initialized
INFO - 2018-11-22 13:04:44 --> Language Class Initialized
INFO - 2018-11-22 13:04:44 --> Loader Class Initialized
INFO - 2018-11-22 13:04:44 --> Helper loaded: url_helper
INFO - 2018-11-22 13:04:44 --> Helper loaded: file_helper
INFO - 2018-11-22 13:04:44 --> Helper loaded: email_helper
INFO - 2018-11-22 13:04:44 --> Helper loaded: common_helper
INFO - 2018-11-22 13:04:44 --> Database Driver Class Initialized
DEBUG - 2018-11-22 13:04:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-22 13:04:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-22 13:04:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-22 13:04:44 --> Pagination Class Initialized
INFO - 2018-11-22 13:04:44 --> Helper loaded: form_helper
INFO - 2018-11-22 13:04:44 --> Form Validation Class Initialized
INFO - 2018-11-22 13:04:44 --> Model Class Initialized
INFO - 2018-11-22 13:04:44 --> Controller Class Initialized
INFO - 2018-11-22 13:04:44 --> Model Class Initialized
INFO - 2018-11-22 13:04:44 --> Model Class Initialized
INFO - 2018-11-22 13:04:44 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\template/header-menu.php
INFO - 2018-11-22 13:04:44 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\template/header.php
INFO - 2018-11-22 13:04:44 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\template/footer.php
INFO - 2018-11-22 13:04:44 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\index.php
INFO - 2018-11-22 13:04:44 --> Final output sent to browser
DEBUG - 2018-11-22 13:04:44 --> Total execution time: 0.0580
INFO - 2018-11-22 13:04:53 --> Config Class Initialized
INFO - 2018-11-22 13:04:53 --> Hooks Class Initialized
DEBUG - 2018-11-22 13:04:53 --> UTF-8 Support Enabled
INFO - 2018-11-22 13:04:53 --> Utf8 Class Initialized
INFO - 2018-11-22 13:04:53 --> URI Class Initialized
INFO - 2018-11-22 13:04:53 --> Router Class Initialized
INFO - 2018-11-22 13:04:53 --> Output Class Initialized
INFO - 2018-11-22 13:04:53 --> Security Class Initialized
DEBUG - 2018-11-22 13:04:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-22 13:04:53 --> Input Class Initialized
INFO - 2018-11-22 13:04:53 --> Language Class Initialized
INFO - 2018-11-22 13:04:53 --> Loader Class Initialized
INFO - 2018-11-22 13:04:53 --> Helper loaded: url_helper
INFO - 2018-11-22 13:04:53 --> Helper loaded: file_helper
INFO - 2018-11-22 13:04:53 --> Helper loaded: email_helper
INFO - 2018-11-22 13:04:53 --> Helper loaded: common_helper
INFO - 2018-11-22 13:04:53 --> Database Driver Class Initialized
DEBUG - 2018-11-22 13:04:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-22 13:04:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-22 13:04:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-22 13:04:53 --> Pagination Class Initialized
INFO - 2018-11-22 13:04:53 --> Helper loaded: form_helper
INFO - 2018-11-22 13:04:53 --> Form Validation Class Initialized
INFO - 2018-11-22 13:04:53 --> Model Class Initialized
INFO - 2018-11-22 13:04:53 --> Controller Class Initialized
INFO - 2018-11-22 13:04:53 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-22 13:04:53 --> Model Class Initialized
INFO - 2018-11-22 13:04:53 --> Model Class Initialized
INFO - 2018-11-22 13:04:53 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/index.php
INFO - 2018-11-22 13:04:53 --> Final output sent to browser
DEBUG - 2018-11-22 13:04:53 --> Total execution time: 0.0920
INFO - 2018-11-22 13:04:55 --> Config Class Initialized
INFO - 2018-11-22 13:04:55 --> Hooks Class Initialized
DEBUG - 2018-11-22 13:04:55 --> UTF-8 Support Enabled
INFO - 2018-11-22 13:04:55 --> Utf8 Class Initialized
INFO - 2018-11-22 13:04:55 --> URI Class Initialized
INFO - 2018-11-22 13:04:55 --> Router Class Initialized
INFO - 2018-11-22 13:04:55 --> Output Class Initialized
INFO - 2018-11-22 13:04:55 --> Security Class Initialized
DEBUG - 2018-11-22 13:04:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-22 13:04:55 --> Input Class Initialized
INFO - 2018-11-22 13:04:55 --> Language Class Initialized
INFO - 2018-11-22 13:04:55 --> Loader Class Initialized
INFO - 2018-11-22 13:04:55 --> Helper loaded: url_helper
INFO - 2018-11-22 13:04:55 --> Helper loaded: file_helper
INFO - 2018-11-22 13:04:55 --> Helper loaded: email_helper
INFO - 2018-11-22 13:04:55 --> Helper loaded: common_helper
INFO - 2018-11-22 13:04:55 --> Database Driver Class Initialized
DEBUG - 2018-11-22 13:04:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-22 13:04:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-22 13:04:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-22 13:04:55 --> Pagination Class Initialized
INFO - 2018-11-22 13:04:55 --> Helper loaded: form_helper
INFO - 2018-11-22 13:04:55 --> Form Validation Class Initialized
INFO - 2018-11-22 13:04:55 --> Model Class Initialized
INFO - 2018-11-22 13:04:55 --> Controller Class Initialized
INFO - 2018-11-22 13:04:55 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-22 13:04:55 --> Model Class Initialized
INFO - 2018-11-22 13:04:55 --> Model Class Initialized
INFO - 2018-11-22 13:04:55 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/index.php
INFO - 2018-11-22 13:04:55 --> Final output sent to browser
DEBUG - 2018-11-22 13:04:55 --> Total execution time: 0.0790
INFO - 2018-11-22 13:04:58 --> Config Class Initialized
INFO - 2018-11-22 13:04:58 --> Hooks Class Initialized
DEBUG - 2018-11-22 13:04:58 --> UTF-8 Support Enabled
INFO - 2018-11-22 13:04:58 --> Utf8 Class Initialized
INFO - 2018-11-22 13:04:58 --> URI Class Initialized
INFO - 2018-11-22 13:04:58 --> Router Class Initialized
INFO - 2018-11-22 13:04:58 --> Output Class Initialized
INFO - 2018-11-22 13:04:58 --> Security Class Initialized
DEBUG - 2018-11-22 13:04:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-22 13:04:58 --> Input Class Initialized
INFO - 2018-11-22 13:04:58 --> Language Class Initialized
INFO - 2018-11-22 13:04:58 --> Loader Class Initialized
INFO - 2018-11-22 13:04:58 --> Helper loaded: url_helper
INFO - 2018-11-22 13:04:58 --> Helper loaded: file_helper
INFO - 2018-11-22 13:04:58 --> Helper loaded: email_helper
INFO - 2018-11-22 13:04:58 --> Helper loaded: common_helper
INFO - 2018-11-22 13:04:58 --> Database Driver Class Initialized
DEBUG - 2018-11-22 13:04:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-22 13:04:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-22 13:04:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-22 13:04:58 --> Pagination Class Initialized
INFO - 2018-11-22 13:04:58 --> Helper loaded: form_helper
INFO - 2018-11-22 13:04:58 --> Form Validation Class Initialized
INFO - 2018-11-22 13:04:58 --> Model Class Initialized
INFO - 2018-11-22 13:04:58 --> Controller Class Initialized
INFO - 2018-11-22 13:04:58 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-22 13:04:58 --> Model Class Initialized
INFO - 2018-11-22 13:04:58 --> Model Class Initialized
ERROR - 2018-11-22 13:04:58 --> Severity: Notice --> Undefined index: remember_me C:\xampp\htdocs\wetinuneed\application\controllers\admin\Admin.php 77
INFO - 2018-11-22 13:04:58 --> Config Class Initialized
INFO - 2018-11-22 13:04:58 --> Hooks Class Initialized
DEBUG - 2018-11-22 13:04:58 --> UTF-8 Support Enabled
INFO - 2018-11-22 13:04:58 --> Utf8 Class Initialized
INFO - 2018-11-22 13:04:58 --> URI Class Initialized
INFO - 2018-11-22 13:04:58 --> Router Class Initialized
INFO - 2018-11-22 13:04:58 --> Output Class Initialized
INFO - 2018-11-22 13:04:58 --> Security Class Initialized
DEBUG - 2018-11-22 13:04:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-22 13:04:58 --> Input Class Initialized
INFO - 2018-11-22 13:04:58 --> Language Class Initialized
INFO - 2018-11-22 13:04:58 --> Loader Class Initialized
INFO - 2018-11-22 13:04:58 --> Helper loaded: url_helper
INFO - 2018-11-22 13:04:58 --> Helper loaded: file_helper
INFO - 2018-11-22 13:04:58 --> Helper loaded: email_helper
INFO - 2018-11-22 13:04:58 --> Helper loaded: common_helper
INFO - 2018-11-22 13:04:58 --> Database Driver Class Initialized
DEBUG - 2018-11-22 13:04:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-22 13:04:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-22 13:04:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-22 13:04:58 --> Pagination Class Initialized
INFO - 2018-11-22 13:04:58 --> Helper loaded: form_helper
INFO - 2018-11-22 13:04:58 --> Form Validation Class Initialized
INFO - 2018-11-22 13:04:58 --> Model Class Initialized
INFO - 2018-11-22 13:04:58 --> Controller Class Initialized
INFO - 2018-11-22 13:04:58 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-22 13:04:58 --> Model Class Initialized
INFO - 2018-11-22 13:04:58 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-22 13:04:58 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/sidebar.php
INFO - 2018-11-22 13:04:58 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/right-sidebar.php
INFO - 2018-11-22 13:04:58 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/footer.php
INFO - 2018-11-22 13:04:58 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/dashboard.php
INFO - 2018-11-22 13:04:58 --> Final output sent to browser
DEBUG - 2018-11-22 13:04:58 --> Total execution time: 0.0610
INFO - 2018-11-22 13:06:01 --> Config Class Initialized
INFO - 2018-11-22 13:06:01 --> Hooks Class Initialized
DEBUG - 2018-11-22 13:06:01 --> UTF-8 Support Enabled
INFO - 2018-11-22 13:06:01 --> Utf8 Class Initialized
INFO - 2018-11-22 13:06:01 --> URI Class Initialized
INFO - 2018-11-22 13:06:01 --> Router Class Initialized
INFO - 2018-11-22 13:06:01 --> Output Class Initialized
INFO - 2018-11-22 13:06:01 --> Security Class Initialized
DEBUG - 2018-11-22 13:06:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-22 13:06:01 --> Input Class Initialized
INFO - 2018-11-22 13:06:01 --> Language Class Initialized
INFO - 2018-11-22 13:06:01 --> Loader Class Initialized
INFO - 2018-11-22 13:06:01 --> Helper loaded: url_helper
INFO - 2018-11-22 13:06:01 --> Helper loaded: file_helper
INFO - 2018-11-22 13:06:01 --> Helper loaded: email_helper
INFO - 2018-11-22 13:06:01 --> Helper loaded: common_helper
INFO - 2018-11-22 13:06:01 --> Database Driver Class Initialized
DEBUG - 2018-11-22 13:06:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-22 13:06:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-22 13:06:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-22 13:06:01 --> Pagination Class Initialized
INFO - 2018-11-22 13:06:01 --> Helper loaded: form_helper
INFO - 2018-11-22 13:06:01 --> Form Validation Class Initialized
INFO - 2018-11-22 13:06:01 --> Model Class Initialized
INFO - 2018-11-22 13:06:01 --> Controller Class Initialized
INFO - 2018-11-22 13:06:01 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-22 13:06:01 --> Model Class Initialized
INFO - 2018-11-22 13:06:01 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-22 13:06:01 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/sidebar.php
INFO - 2018-11-22 13:06:01 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/right-sidebar.php
INFO - 2018-11-22 13:06:01 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/footer.php
INFO - 2018-11-22 13:06:01 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/dashboard.php
INFO - 2018-11-22 13:06:01 --> Final output sent to browser
DEBUG - 2018-11-22 13:06:01 --> Total execution time: 0.0490
INFO - 2018-11-22 13:06:21 --> Config Class Initialized
INFO - 2018-11-22 13:06:21 --> Hooks Class Initialized
DEBUG - 2018-11-22 13:06:21 --> UTF-8 Support Enabled
INFO - 2018-11-22 13:06:21 --> Utf8 Class Initialized
INFO - 2018-11-22 13:06:21 --> URI Class Initialized
INFO - 2018-11-22 13:06:21 --> Router Class Initialized
INFO - 2018-11-22 13:06:21 --> Output Class Initialized
INFO - 2018-11-22 13:06:21 --> Security Class Initialized
DEBUG - 2018-11-22 13:06:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-22 13:06:21 --> Input Class Initialized
INFO - 2018-11-22 13:06:21 --> Language Class Initialized
INFO - 2018-11-22 13:06:21 --> Loader Class Initialized
INFO - 2018-11-22 13:06:21 --> Helper loaded: url_helper
INFO - 2018-11-22 13:06:21 --> Helper loaded: file_helper
INFO - 2018-11-22 13:06:21 --> Helper loaded: email_helper
INFO - 2018-11-22 13:06:21 --> Helper loaded: common_helper
INFO - 2018-11-22 13:06:21 --> Database Driver Class Initialized
DEBUG - 2018-11-22 13:06:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-22 13:06:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-22 13:06:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-22 13:06:21 --> Pagination Class Initialized
INFO - 2018-11-22 13:06:21 --> Helper loaded: form_helper
INFO - 2018-11-22 13:06:21 --> Form Validation Class Initialized
INFO - 2018-11-22 13:06:21 --> Model Class Initialized
INFO - 2018-11-22 13:06:21 --> Controller Class Initialized
INFO - 2018-11-22 13:06:21 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-22 13:06:21 --> Model Class Initialized
INFO - 2018-11-22 13:06:21 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-22 13:06:21 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/sidebar.php
INFO - 2018-11-22 13:06:21 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/right-sidebar.php
INFO - 2018-11-22 13:06:21 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/footer.php
INFO - 2018-11-22 13:06:21 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/dashboard.php
INFO - 2018-11-22 13:06:21 --> Final output sent to browser
DEBUG - 2018-11-22 13:06:21 --> Total execution time: 0.0490
INFO - 2018-11-22 13:06:30 --> Config Class Initialized
INFO - 2018-11-22 13:06:30 --> Hooks Class Initialized
DEBUG - 2018-11-22 13:06:30 --> UTF-8 Support Enabled
INFO - 2018-11-22 13:06:30 --> Utf8 Class Initialized
INFO - 2018-11-22 13:06:30 --> URI Class Initialized
INFO - 2018-11-22 13:06:30 --> Router Class Initialized
INFO - 2018-11-22 13:06:30 --> Output Class Initialized
INFO - 2018-11-22 13:06:30 --> Security Class Initialized
DEBUG - 2018-11-22 13:06:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-22 13:06:30 --> Input Class Initialized
INFO - 2018-11-22 13:06:30 --> Language Class Initialized
INFO - 2018-11-22 13:06:30 --> Loader Class Initialized
INFO - 2018-11-22 13:06:30 --> Helper loaded: url_helper
INFO - 2018-11-22 13:06:30 --> Helper loaded: file_helper
INFO - 2018-11-22 13:06:30 --> Helper loaded: email_helper
INFO - 2018-11-22 13:06:30 --> Helper loaded: common_helper
INFO - 2018-11-22 13:06:30 --> Database Driver Class Initialized
DEBUG - 2018-11-22 13:06:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-22 13:06:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-22 13:06:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-22 13:06:30 --> Pagination Class Initialized
INFO - 2018-11-22 13:06:30 --> Helper loaded: form_helper
INFO - 2018-11-22 13:06:30 --> Form Validation Class Initialized
INFO - 2018-11-22 13:06:30 --> Model Class Initialized
INFO - 2018-11-22 13:06:30 --> Controller Class Initialized
INFO - 2018-11-22 13:06:30 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-22 13:06:30 --> Model Class Initialized
INFO - 2018-11-22 13:06:30 --> Model Class Initialized
INFO - 2018-11-22 13:06:30 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-22 13:06:30 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/change-password.php
INFO - 2018-11-22 13:06:30 --> Final output sent to browser
DEBUG - 2018-11-22 13:06:30 --> Total execution time: 0.0530
INFO - 2018-11-22 13:06:41 --> Config Class Initialized
INFO - 2018-11-22 13:06:41 --> Hooks Class Initialized
DEBUG - 2018-11-22 13:06:41 --> UTF-8 Support Enabled
INFO - 2018-11-22 13:06:41 --> Utf8 Class Initialized
INFO - 2018-11-22 13:06:41 --> URI Class Initialized
INFO - 2018-11-22 13:06:41 --> Router Class Initialized
INFO - 2018-11-22 13:06:41 --> Output Class Initialized
INFO - 2018-11-22 13:06:41 --> Security Class Initialized
DEBUG - 2018-11-22 13:06:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-22 13:06:41 --> Input Class Initialized
INFO - 2018-11-22 13:06:41 --> Language Class Initialized
INFO - 2018-11-22 13:06:41 --> Loader Class Initialized
INFO - 2018-11-22 13:06:41 --> Helper loaded: url_helper
INFO - 2018-11-22 13:06:41 --> Helper loaded: file_helper
INFO - 2018-11-22 13:06:41 --> Helper loaded: email_helper
INFO - 2018-11-22 13:06:41 --> Helper loaded: common_helper
INFO - 2018-11-22 13:06:41 --> Database Driver Class Initialized
DEBUG - 2018-11-22 13:06:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-22 13:06:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-22 13:06:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-22 13:06:41 --> Pagination Class Initialized
INFO - 2018-11-22 13:06:41 --> Helper loaded: form_helper
INFO - 2018-11-22 13:06:41 --> Form Validation Class Initialized
INFO - 2018-11-22 13:06:41 --> Model Class Initialized
INFO - 2018-11-22 13:06:41 --> Controller Class Initialized
INFO - 2018-11-22 13:06:41 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-22 13:06:41 --> Model Class Initialized
INFO - 2018-11-22 13:06:41 --> Model Class Initialized
INFO - 2018-11-22 13:06:41 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-22 13:06:41 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/change-password.php
INFO - 2018-11-22 13:06:41 --> Final output sent to browser
DEBUG - 2018-11-22 13:06:41 --> Total execution time: 0.0570
INFO - 2018-11-22 13:50:35 --> Config Class Initialized
INFO - 2018-11-22 13:50:35 --> Hooks Class Initialized
DEBUG - 2018-11-22 13:50:35 --> UTF-8 Support Enabled
INFO - 2018-11-22 13:50:35 --> Utf8 Class Initialized
INFO - 2018-11-22 13:50:35 --> URI Class Initialized
INFO - 2018-11-22 13:50:35 --> Router Class Initialized
INFO - 2018-11-22 13:50:35 --> Output Class Initialized
INFO - 2018-11-22 13:50:35 --> Security Class Initialized
DEBUG - 2018-11-22 13:50:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-22 13:50:35 --> Input Class Initialized
INFO - 2018-11-22 13:50:35 --> Language Class Initialized
INFO - 2018-11-22 13:50:35 --> Loader Class Initialized
INFO - 2018-11-22 13:50:35 --> Helper loaded: url_helper
INFO - 2018-11-22 13:50:35 --> Helper loaded: file_helper
INFO - 2018-11-22 13:50:35 --> Helper loaded: email_helper
INFO - 2018-11-22 13:50:35 --> Helper loaded: common_helper
INFO - 2018-11-22 13:50:35 --> Database Driver Class Initialized
DEBUG - 2018-11-22 13:50:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-22 13:50:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-22 13:50:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-22 13:50:35 --> Pagination Class Initialized
INFO - 2018-11-22 13:50:35 --> Helper loaded: form_helper
INFO - 2018-11-22 13:50:35 --> Form Validation Class Initialized
INFO - 2018-11-22 13:50:35 --> Model Class Initialized
INFO - 2018-11-22 13:50:35 --> Controller Class Initialized
INFO - 2018-11-22 13:50:35 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-22 13:50:35 --> Model Class Initialized
INFO - 2018-11-22 13:50:35 --> Model Class Initialized
INFO - 2018-11-22 13:50:35 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-22 13:50:35 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/change-password.php
INFO - 2018-11-22 13:50:35 --> Final output sent to browser
DEBUG - 2018-11-22 13:50:35 --> Total execution time: 0.0590
INFO - 2018-11-22 14:00:03 --> Config Class Initialized
INFO - 2018-11-22 14:00:03 --> Hooks Class Initialized
DEBUG - 2018-11-22 14:00:03 --> UTF-8 Support Enabled
INFO - 2018-11-22 14:00:03 --> Utf8 Class Initialized
INFO - 2018-11-22 14:00:03 --> URI Class Initialized
INFO - 2018-11-22 14:00:03 --> Router Class Initialized
INFO - 2018-11-22 14:00:03 --> Output Class Initialized
INFO - 2018-11-22 14:00:03 --> Security Class Initialized
DEBUG - 2018-11-22 14:00:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-22 14:00:03 --> Input Class Initialized
INFO - 2018-11-22 14:00:03 --> Language Class Initialized
INFO - 2018-11-22 14:00:03 --> Loader Class Initialized
INFO - 2018-11-22 14:00:03 --> Helper loaded: url_helper
INFO - 2018-11-22 14:00:03 --> Helper loaded: file_helper
INFO - 2018-11-22 14:00:03 --> Helper loaded: email_helper
INFO - 2018-11-22 14:00:03 --> Helper loaded: common_helper
INFO - 2018-11-22 14:00:03 --> Database Driver Class Initialized
DEBUG - 2018-11-22 14:00:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-22 14:00:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-22 14:00:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-22 14:00:03 --> Pagination Class Initialized
INFO - 2018-11-22 14:00:03 --> Helper loaded: form_helper
INFO - 2018-11-22 14:00:03 --> Form Validation Class Initialized
INFO - 2018-11-22 14:00:03 --> Model Class Initialized
INFO - 2018-11-22 14:00:03 --> Controller Class Initialized
INFO - 2018-11-22 14:00:03 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-22 14:00:03 --> Model Class Initialized
INFO - 2018-11-22 14:00:03 --> Model Class Initialized
INFO - 2018-11-22 14:00:03 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-22 14:00:03 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/change-password.php
INFO - 2018-11-22 14:00:03 --> Final output sent to browser
DEBUG - 2018-11-22 14:00:03 --> Total execution time: 0.1510
INFO - 2018-11-22 14:21:26 --> Config Class Initialized
INFO - 2018-11-22 14:21:26 --> Hooks Class Initialized
DEBUG - 2018-11-22 14:21:26 --> UTF-8 Support Enabled
INFO - 2018-11-22 14:21:26 --> Utf8 Class Initialized
INFO - 2018-11-22 14:21:26 --> URI Class Initialized
INFO - 2018-11-22 14:21:26 --> Router Class Initialized
INFO - 2018-11-22 14:21:26 --> Output Class Initialized
INFO - 2018-11-22 14:21:26 --> Security Class Initialized
DEBUG - 2018-11-22 14:21:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-22 14:21:26 --> Input Class Initialized
INFO - 2018-11-22 14:21:26 --> Language Class Initialized
INFO - 2018-11-22 14:21:26 --> Loader Class Initialized
INFO - 2018-11-22 14:21:26 --> Helper loaded: url_helper
INFO - 2018-11-22 14:21:26 --> Helper loaded: file_helper
INFO - 2018-11-22 14:21:26 --> Helper loaded: email_helper
INFO - 2018-11-22 14:21:26 --> Helper loaded: common_helper
INFO - 2018-11-22 14:21:26 --> Database Driver Class Initialized
DEBUG - 2018-11-22 14:21:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-22 14:21:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-22 14:21:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-22 14:21:26 --> Pagination Class Initialized
INFO - 2018-11-22 14:21:26 --> Helper loaded: form_helper
INFO - 2018-11-22 14:21:26 --> Form Validation Class Initialized
INFO - 2018-11-22 14:21:26 --> Model Class Initialized
INFO - 2018-11-22 14:21:26 --> Controller Class Initialized
INFO - 2018-11-22 14:21:26 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-22 14:21:26 --> Model Class Initialized
INFO - 2018-11-22 14:21:26 --> Model Class Initialized
INFO - 2018-11-22 14:21:26 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-22 14:21:26 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/change-password.php
INFO - 2018-11-22 14:21:26 --> Final output sent to browser
DEBUG - 2018-11-22 14:21:26 --> Total execution time: 0.0570

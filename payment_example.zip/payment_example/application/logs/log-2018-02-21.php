<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2018-02-21 10:17:18 --> Config Class Initialized
INFO - 2018-02-21 10:17:18 --> Hooks Class Initialized
DEBUG - 2018-02-21 10:17:18 --> UTF-8 Support Enabled
INFO - 2018-02-21 10:17:18 --> Utf8 Class Initialized
INFO - 2018-02-21 10:17:18 --> URI Class Initialized
INFO - 2018-02-21 10:17:18 --> Router Class Initialized
INFO - 2018-02-21 10:17:18 --> Output Class Initialized
INFO - 2018-02-21 10:17:18 --> Security Class Initialized
DEBUG - 2018-02-21 10:17:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-21 10:17:18 --> Input Class Initialized
INFO - 2018-02-21 10:17:18 --> Language Class Initialized
INFO - 2018-02-21 10:17:18 --> Loader Class Initialized
INFO - 2018-02-21 10:17:18 --> Helper loaded: url_helper
INFO - 2018-02-21 10:17:18 --> Helper loaded: file_helper
INFO - 2018-02-21 10:17:18 --> Helper loaded: email_helper
INFO - 2018-02-21 10:17:18 --> Helper loaded: common_helper
INFO - 2018-02-21 10:17:18 --> Database Driver Class Initialized
DEBUG - 2018-02-21 10:17:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-21 10:17:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-21 10:17:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-21 10:17:18 --> Pagination Class Initialized
INFO - 2018-02-21 10:17:18 --> Helper loaded: form_helper
INFO - 2018-02-21 10:17:18 --> Form Validation Class Initialized
INFO - 2018-02-21 10:17:18 --> Model Class Initialized
INFO - 2018-02-21 10:17:18 --> Controller Class Initialized
DEBUG - 2018-02-21 10:17:18 --> Config file loaded: /var/www/html/project/radio/application/config/rest.php
INFO - 2018-02-21 10:17:18 --> Helper loaded: inflector_helper
INFO - 2018-02-21 10:17:18 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-21 10:17:18 --> Model Class Initialized
INFO - 2018-02-21 10:17:18 --> Model Class Initialized
INFO - 2018-02-21 10:17:18 --> Model Class Initialized
INFO - 2018-02-21 10:17:18 --> Final output sent to browser
DEBUG - 2018-02-21 10:17:18 --> Total execution time: 0.2511
INFO - 2018-02-21 10:17:36 --> Config Class Initialized
INFO - 2018-02-21 10:17:36 --> Hooks Class Initialized
DEBUG - 2018-02-21 10:17:36 --> UTF-8 Support Enabled
INFO - 2018-02-21 10:17:36 --> Utf8 Class Initialized
INFO - 2018-02-21 10:17:36 --> URI Class Initialized
INFO - 2018-02-21 10:17:36 --> Router Class Initialized
INFO - 2018-02-21 10:17:36 --> Output Class Initialized
INFO - 2018-02-21 10:17:36 --> Security Class Initialized
DEBUG - 2018-02-21 10:17:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-21 10:17:36 --> Input Class Initialized
INFO - 2018-02-21 10:17:36 --> Language Class Initialized
INFO - 2018-02-21 10:17:36 --> Loader Class Initialized
INFO - 2018-02-21 10:17:36 --> Helper loaded: url_helper
INFO - 2018-02-21 10:17:36 --> Helper loaded: file_helper
INFO - 2018-02-21 10:17:36 --> Helper loaded: email_helper
INFO - 2018-02-21 10:17:36 --> Helper loaded: common_helper
INFO - 2018-02-21 10:17:36 --> Database Driver Class Initialized
DEBUG - 2018-02-21 10:17:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-21 10:17:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-21 10:17:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-21 10:17:36 --> Pagination Class Initialized
INFO - 2018-02-21 10:17:36 --> Helper loaded: form_helper
INFO - 2018-02-21 10:17:36 --> Form Validation Class Initialized
INFO - 2018-02-21 10:17:36 --> Model Class Initialized
INFO - 2018-02-21 10:17:36 --> Controller Class Initialized
DEBUG - 2018-02-21 10:17:36 --> Config file loaded: /var/www/html/project/radio/application/config/rest.php
INFO - 2018-02-21 10:17:36 --> Helper loaded: inflector_helper
INFO - 2018-02-21 10:17:36 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-21 10:17:36 --> Model Class Initialized
INFO - 2018-02-21 10:17:36 --> Model Class Initialized
INFO - 2018-02-21 10:17:36 --> Model Class Initialized
INFO - 2018-02-21 10:17:36 --> Final output sent to browser
DEBUG - 2018-02-21 10:17:36 --> Total execution time: 0.0113
INFO - 2018-02-21 10:21:03 --> Config Class Initialized
INFO - 2018-02-21 10:21:03 --> Hooks Class Initialized
DEBUG - 2018-02-21 10:21:03 --> UTF-8 Support Enabled
INFO - 2018-02-21 10:21:03 --> Utf8 Class Initialized
INFO - 2018-02-21 10:21:03 --> URI Class Initialized
INFO - 2018-02-21 10:21:03 --> Router Class Initialized
INFO - 2018-02-21 10:21:03 --> Output Class Initialized
INFO - 2018-02-21 10:21:03 --> Security Class Initialized
DEBUG - 2018-02-21 10:21:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-21 10:21:03 --> Input Class Initialized
INFO - 2018-02-21 10:21:03 --> Language Class Initialized
INFO - 2018-02-21 10:21:03 --> Loader Class Initialized
INFO - 2018-02-21 10:21:03 --> Helper loaded: url_helper
INFO - 2018-02-21 10:21:03 --> Helper loaded: file_helper
INFO - 2018-02-21 10:21:03 --> Helper loaded: email_helper
INFO - 2018-02-21 10:21:03 --> Helper loaded: common_helper
INFO - 2018-02-21 10:21:03 --> Database Driver Class Initialized
DEBUG - 2018-02-21 10:21:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-21 10:21:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-21 10:21:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-21 10:21:03 --> Pagination Class Initialized
INFO - 2018-02-21 10:21:03 --> Helper loaded: form_helper
INFO - 2018-02-21 10:21:03 --> Form Validation Class Initialized
INFO - 2018-02-21 10:21:03 --> Model Class Initialized
INFO - 2018-02-21 10:21:03 --> Controller Class Initialized
INFO - 2018-02-21 10:21:03 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-21 10:21:03 --> Config Class Initialized
INFO - 2018-02-21 10:21:03 --> Hooks Class Initialized
DEBUG - 2018-02-21 10:21:03 --> UTF-8 Support Enabled
INFO - 2018-02-21 10:21:03 --> Utf8 Class Initialized
INFO - 2018-02-21 10:21:03 --> URI Class Initialized
DEBUG - 2018-02-21 10:21:03 --> No URI present. Default controller set.
INFO - 2018-02-21 10:21:03 --> Router Class Initialized
INFO - 2018-02-21 10:21:03 --> Output Class Initialized
INFO - 2018-02-21 10:21:03 --> Security Class Initialized
DEBUG - 2018-02-21 10:21:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-21 10:21:03 --> Input Class Initialized
INFO - 2018-02-21 10:21:03 --> Language Class Initialized
INFO - 2018-02-21 10:21:03 --> Loader Class Initialized
INFO - 2018-02-21 10:21:03 --> Helper loaded: url_helper
INFO - 2018-02-21 10:21:03 --> Helper loaded: file_helper
INFO - 2018-02-21 10:21:03 --> Helper loaded: email_helper
INFO - 2018-02-21 10:21:03 --> Helper loaded: common_helper
INFO - 2018-02-21 10:21:03 --> Database Driver Class Initialized
DEBUG - 2018-02-21 10:21:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-21 10:21:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-21 10:21:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-21 10:21:03 --> Pagination Class Initialized
INFO - 2018-02-21 10:21:03 --> Helper loaded: form_helper
INFO - 2018-02-21 10:21:03 --> Form Validation Class Initialized
INFO - 2018-02-21 10:21:03 --> Model Class Initialized
INFO - 2018-02-21 10:21:03 --> Controller Class Initialized
INFO - 2018-02-21 10:21:03 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-21 10:21:03 --> Model Class Initialized
INFO - 2018-02-21 10:21:03 --> Model Class Initialized
INFO - 2018-02-21 10:21:03 --> File loaded: /var/www/html/project/radio/application/views/index/index.php
INFO - 2018-02-21 10:21:03 --> Final output sent to browser
DEBUG - 2018-02-21 10:21:03 --> Total execution time: 0.0461
INFO - 2018-02-21 10:21:05 --> Config Class Initialized
INFO - 2018-02-21 10:21:05 --> Hooks Class Initialized
DEBUG - 2018-02-21 10:21:05 --> UTF-8 Support Enabled
INFO - 2018-02-21 10:21:05 --> Utf8 Class Initialized
INFO - 2018-02-21 10:21:05 --> URI Class Initialized
INFO - 2018-02-21 10:21:05 --> Router Class Initialized
INFO - 2018-02-21 10:21:05 --> Output Class Initialized
INFO - 2018-02-21 10:21:05 --> Security Class Initialized
DEBUG - 2018-02-21 10:21:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-21 10:21:05 --> Input Class Initialized
INFO - 2018-02-21 10:21:05 --> Language Class Initialized
INFO - 2018-02-21 10:21:05 --> Loader Class Initialized
INFO - 2018-02-21 10:21:05 --> Helper loaded: url_helper
INFO - 2018-02-21 10:21:05 --> Helper loaded: file_helper
INFO - 2018-02-21 10:21:05 --> Helper loaded: email_helper
INFO - 2018-02-21 10:21:05 --> Helper loaded: common_helper
INFO - 2018-02-21 10:21:05 --> Database Driver Class Initialized
DEBUG - 2018-02-21 10:21:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-21 10:21:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-21 10:21:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-21 10:21:05 --> Pagination Class Initialized
INFO - 2018-02-21 10:21:05 --> Helper loaded: form_helper
INFO - 2018-02-21 10:21:05 --> Form Validation Class Initialized
INFO - 2018-02-21 10:21:05 --> Model Class Initialized
INFO - 2018-02-21 10:21:05 --> Controller Class Initialized
INFO - 2018-02-21 10:21:05 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-21 10:21:05 --> Model Class Initialized
INFO - 2018-02-21 10:21:05 --> Model Class Initialized
ERROR - 2018-02-21 10:21:05 --> Severity: Notice --> Undefined index: remember_me /var/www/html/project/radio/application/controllers/Index.php 74
INFO - 2018-02-21 10:21:05 --> Config Class Initialized
INFO - 2018-02-21 10:21:05 --> Hooks Class Initialized
DEBUG - 2018-02-21 10:21:05 --> UTF-8 Support Enabled
INFO - 2018-02-21 10:21:05 --> Utf8 Class Initialized
INFO - 2018-02-21 10:21:05 --> URI Class Initialized
INFO - 2018-02-21 10:21:05 --> Router Class Initialized
INFO - 2018-02-21 10:21:05 --> Output Class Initialized
INFO - 2018-02-21 10:21:05 --> Security Class Initialized
DEBUG - 2018-02-21 10:21:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-21 10:21:05 --> Input Class Initialized
INFO - 2018-02-21 10:21:05 --> Language Class Initialized
INFO - 2018-02-21 10:21:05 --> Loader Class Initialized
INFO - 2018-02-21 10:21:05 --> Helper loaded: url_helper
INFO - 2018-02-21 10:21:05 --> Helper loaded: file_helper
INFO - 2018-02-21 10:21:05 --> Helper loaded: email_helper
INFO - 2018-02-21 10:21:05 --> Helper loaded: common_helper
INFO - 2018-02-21 10:21:05 --> Database Driver Class Initialized
DEBUG - 2018-02-21 10:21:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-21 10:21:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-21 10:21:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-21 10:21:05 --> Pagination Class Initialized
INFO - 2018-02-21 10:21:05 --> Helper loaded: form_helper
INFO - 2018-02-21 10:21:05 --> Form Validation Class Initialized
INFO - 2018-02-21 10:21:05 --> Model Class Initialized
INFO - 2018-02-21 10:21:05 --> Controller Class Initialized
INFO - 2018-02-21 10:21:05 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-21 10:21:05 --> Model Class Initialized
INFO - 2018-02-21 10:21:05 --> Model Class Initialized
INFO - 2018-02-21 10:21:05 --> Model Class Initialized
INFO - 2018-02-21 10:21:05 --> Model Class Initialized
INFO - 2018-02-21 10:21:05 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-21 10:21:05 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-21 10:21:05 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-21 10:21:05 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-21 10:21:05 --> File loaded: /var/www/html/project/radio/application/views/dashboard/index.php
INFO - 2018-02-21 10:21:05 --> Final output sent to browser
DEBUG - 2018-02-21 10:21:05 --> Total execution time: 0.1332
INFO - 2018-02-21 10:21:07 --> Config Class Initialized
INFO - 2018-02-21 10:21:07 --> Hooks Class Initialized
DEBUG - 2018-02-21 10:21:07 --> UTF-8 Support Enabled
INFO - 2018-02-21 10:21:07 --> Utf8 Class Initialized
INFO - 2018-02-21 10:21:07 --> URI Class Initialized
INFO - 2018-02-21 10:21:07 --> Router Class Initialized
INFO - 2018-02-21 10:21:07 --> Output Class Initialized
INFO - 2018-02-21 10:21:07 --> Security Class Initialized
DEBUG - 2018-02-21 10:21:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-21 10:21:07 --> Input Class Initialized
INFO - 2018-02-21 10:21:07 --> Language Class Initialized
INFO - 2018-02-21 10:21:07 --> Loader Class Initialized
INFO - 2018-02-21 10:21:07 --> Helper loaded: url_helper
INFO - 2018-02-21 10:21:07 --> Helper loaded: file_helper
INFO - 2018-02-21 10:21:07 --> Helper loaded: email_helper
INFO - 2018-02-21 10:21:07 --> Helper loaded: common_helper
INFO - 2018-02-21 10:21:07 --> Database Driver Class Initialized
DEBUG - 2018-02-21 10:21:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-21 10:21:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-21 10:21:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-21 10:21:07 --> Pagination Class Initialized
INFO - 2018-02-21 10:21:07 --> Helper loaded: form_helper
INFO - 2018-02-21 10:21:07 --> Form Validation Class Initialized
INFO - 2018-02-21 10:21:07 --> Model Class Initialized
INFO - 2018-02-21 10:21:07 --> Controller Class Initialized
INFO - 2018-02-21 10:21:07 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-21 10:21:07 --> Model Class Initialized
INFO - 2018-02-21 10:21:07 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-21 10:21:07 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-21 10:21:07 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-21 10:21:07 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-21 10:21:07 --> File loaded: /var/www/html/project/radio/application/views/category/index.php
INFO - 2018-02-21 10:21:07 --> Final output sent to browser
DEBUG - 2018-02-21 10:21:07 --> Total execution time: 0.0432
INFO - 2018-02-21 10:21:10 --> Config Class Initialized
INFO - 2018-02-21 10:21:10 --> Hooks Class Initialized
DEBUG - 2018-02-21 10:21:10 --> UTF-8 Support Enabled
INFO - 2018-02-21 10:21:10 --> Utf8 Class Initialized
INFO - 2018-02-21 10:21:10 --> URI Class Initialized
INFO - 2018-02-21 10:21:10 --> Router Class Initialized
INFO - 2018-02-21 10:21:10 --> Output Class Initialized
INFO - 2018-02-21 10:21:10 --> Security Class Initialized
DEBUG - 2018-02-21 10:21:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-21 10:21:10 --> Input Class Initialized
INFO - 2018-02-21 10:21:10 --> Language Class Initialized
INFO - 2018-02-21 10:21:10 --> Loader Class Initialized
INFO - 2018-02-21 10:21:10 --> Helper loaded: url_helper
INFO - 2018-02-21 10:21:10 --> Helper loaded: file_helper
INFO - 2018-02-21 10:21:10 --> Helper loaded: email_helper
INFO - 2018-02-21 10:21:10 --> Helper loaded: common_helper
INFO - 2018-02-21 10:21:10 --> Database Driver Class Initialized
DEBUG - 2018-02-21 10:21:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-21 10:21:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-21 10:21:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-21 10:21:10 --> Pagination Class Initialized
INFO - 2018-02-21 10:21:10 --> Helper loaded: form_helper
INFO - 2018-02-21 10:21:10 --> Form Validation Class Initialized
INFO - 2018-02-21 10:21:10 --> Model Class Initialized
INFO - 2018-02-21 10:21:10 --> Controller Class Initialized
INFO - 2018-02-21 10:21:10 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-21 10:21:10 --> Model Class Initialized
INFO - 2018-02-21 10:21:10 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-21 10:21:10 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-21 10:21:10 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-21 10:21:10 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-21 10:21:10 --> File loaded: /var/www/html/project/radio/application/views/category/add_edit.php
INFO - 2018-02-21 10:21:10 --> Final output sent to browser
DEBUG - 2018-02-21 10:21:10 --> Total execution time: 0.0213
INFO - 2018-02-21 10:21:29 --> Config Class Initialized
INFO - 2018-02-21 10:21:29 --> Hooks Class Initialized
DEBUG - 2018-02-21 10:21:29 --> UTF-8 Support Enabled
INFO - 2018-02-21 10:21:29 --> Utf8 Class Initialized
INFO - 2018-02-21 10:21:29 --> URI Class Initialized
INFO - 2018-02-21 10:21:29 --> Router Class Initialized
INFO - 2018-02-21 10:21:29 --> Output Class Initialized
INFO - 2018-02-21 10:21:29 --> Security Class Initialized
DEBUG - 2018-02-21 10:21:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-21 10:21:29 --> Input Class Initialized
INFO - 2018-02-21 10:21:29 --> Language Class Initialized
INFO - 2018-02-21 10:21:29 --> Loader Class Initialized
INFO - 2018-02-21 10:21:29 --> Helper loaded: url_helper
INFO - 2018-02-21 10:21:29 --> Helper loaded: file_helper
INFO - 2018-02-21 10:21:29 --> Helper loaded: email_helper
INFO - 2018-02-21 10:21:29 --> Helper loaded: common_helper
INFO - 2018-02-21 10:21:29 --> Database Driver Class Initialized
DEBUG - 2018-02-21 10:21:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-21 10:21:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-21 10:21:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-21 10:21:29 --> Pagination Class Initialized
INFO - 2018-02-21 10:21:29 --> Helper loaded: form_helper
INFO - 2018-02-21 10:21:29 --> Form Validation Class Initialized
INFO - 2018-02-21 10:21:29 --> Model Class Initialized
INFO - 2018-02-21 10:21:29 --> Controller Class Initialized
INFO - 2018-02-21 10:21:29 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-21 10:21:29 --> Model Class Initialized
INFO - 2018-02-21 10:21:29 --> Config Class Initialized
INFO - 2018-02-21 10:21:29 --> Hooks Class Initialized
DEBUG - 2018-02-21 10:21:29 --> UTF-8 Support Enabled
INFO - 2018-02-21 10:21:29 --> Utf8 Class Initialized
INFO - 2018-02-21 10:21:29 --> URI Class Initialized
INFO - 2018-02-21 10:21:29 --> Router Class Initialized
INFO - 2018-02-21 10:21:29 --> Output Class Initialized
INFO - 2018-02-21 10:21:29 --> Security Class Initialized
DEBUG - 2018-02-21 10:21:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-21 10:21:29 --> Input Class Initialized
INFO - 2018-02-21 10:21:29 --> Language Class Initialized
INFO - 2018-02-21 10:21:29 --> Loader Class Initialized
INFO - 2018-02-21 10:21:29 --> Helper loaded: url_helper
INFO - 2018-02-21 10:21:29 --> Helper loaded: file_helper
INFO - 2018-02-21 10:21:29 --> Helper loaded: email_helper
INFO - 2018-02-21 10:21:29 --> Helper loaded: common_helper
INFO - 2018-02-21 10:21:29 --> Database Driver Class Initialized
DEBUG - 2018-02-21 10:21:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-21 10:21:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-21 10:21:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-21 10:21:29 --> Pagination Class Initialized
INFO - 2018-02-21 10:21:29 --> Helper loaded: form_helper
INFO - 2018-02-21 10:21:29 --> Form Validation Class Initialized
INFO - 2018-02-21 10:21:29 --> Model Class Initialized
INFO - 2018-02-21 10:21:29 --> Controller Class Initialized
INFO - 2018-02-21 10:21:29 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-21 10:21:29 --> Model Class Initialized
DEBUG - 2018-02-21 10:21:29 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-21 10:21:29 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-02-21 10:21:29 --> Config Class Initialized
INFO - 2018-02-21 10:21:29 --> Hooks Class Initialized
DEBUG - 2018-02-21 10:21:29 --> UTF-8 Support Enabled
INFO - 2018-02-21 10:21:29 --> Utf8 Class Initialized
INFO - 2018-02-21 10:21:29 --> URI Class Initialized
INFO - 2018-02-21 10:21:29 --> Router Class Initialized
INFO - 2018-02-21 10:21:29 --> Output Class Initialized
INFO - 2018-02-21 10:21:29 --> Security Class Initialized
DEBUG - 2018-02-21 10:21:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-21 10:21:29 --> Input Class Initialized
INFO - 2018-02-21 10:21:29 --> Language Class Initialized
INFO - 2018-02-21 10:21:29 --> Loader Class Initialized
INFO - 2018-02-21 10:21:29 --> Helper loaded: url_helper
INFO - 2018-02-21 10:21:29 --> Helper loaded: file_helper
INFO - 2018-02-21 10:21:29 --> Helper loaded: email_helper
INFO - 2018-02-21 10:21:29 --> Helper loaded: common_helper
INFO - 2018-02-21 10:21:29 --> Database Driver Class Initialized
DEBUG - 2018-02-21 10:21:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-21 10:21:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-21 10:21:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-21 10:21:29 --> Pagination Class Initialized
INFO - 2018-02-21 10:21:29 --> Helper loaded: form_helper
INFO - 2018-02-21 10:21:29 --> Form Validation Class Initialized
INFO - 2018-02-21 10:21:29 --> Model Class Initialized
INFO - 2018-02-21 10:21:29 --> Controller Class Initialized
INFO - 2018-02-21 10:21:29 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-21 10:21:29 --> Model Class Initialized
INFO - 2018-02-21 10:21:29 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-21 10:21:29 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-21 10:21:29 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-21 10:21:29 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-21 10:21:29 --> File loaded: /var/www/html/project/radio/application/views/category/index.php
INFO - 2018-02-21 10:21:29 --> Final output sent to browser
DEBUG - 2018-02-21 10:21:29 --> Total execution time: 0.0043
INFO - 2018-02-21 10:21:33 --> Config Class Initialized
INFO - 2018-02-21 10:21:33 --> Hooks Class Initialized
DEBUG - 2018-02-21 10:21:33 --> UTF-8 Support Enabled
INFO - 2018-02-21 10:21:33 --> Utf8 Class Initialized
INFO - 2018-02-21 10:21:33 --> URI Class Initialized
INFO - 2018-02-21 10:21:33 --> Router Class Initialized
INFO - 2018-02-21 10:21:33 --> Output Class Initialized
INFO - 2018-02-21 10:21:33 --> Security Class Initialized
DEBUG - 2018-02-21 10:21:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-21 10:21:33 --> Input Class Initialized
INFO - 2018-02-21 10:21:33 --> Language Class Initialized
INFO - 2018-02-21 10:21:33 --> Loader Class Initialized
INFO - 2018-02-21 10:21:33 --> Helper loaded: url_helper
INFO - 2018-02-21 10:21:33 --> Helper loaded: file_helper
INFO - 2018-02-21 10:21:33 --> Helper loaded: email_helper
INFO - 2018-02-21 10:21:33 --> Helper loaded: common_helper
INFO - 2018-02-21 10:21:33 --> Database Driver Class Initialized
DEBUG - 2018-02-21 10:21:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-21 10:21:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-21 10:21:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-21 10:21:33 --> Pagination Class Initialized
INFO - 2018-02-21 10:21:33 --> Helper loaded: form_helper
INFO - 2018-02-21 10:21:33 --> Form Validation Class Initialized
INFO - 2018-02-21 10:21:33 --> Model Class Initialized
INFO - 2018-02-21 10:21:33 --> Controller Class Initialized
INFO - 2018-02-21 10:21:33 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-21 10:21:33 --> Model Class Initialized
INFO - 2018-02-21 10:21:33 --> Model Class Initialized
INFO - 2018-02-21 10:21:33 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-21 10:21:33 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-21 10:21:33 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-21 10:21:33 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-21 10:21:33 --> File loaded: /var/www/html/project/radio/application/views/subcategory/index.php
INFO - 2018-02-21 10:21:33 --> Final output sent to browser
DEBUG - 2018-02-21 10:21:33 --> Total execution time: 0.0255
INFO - 2018-02-21 10:21:35 --> Config Class Initialized
INFO - 2018-02-21 10:21:35 --> Hooks Class Initialized
DEBUG - 2018-02-21 10:21:35 --> UTF-8 Support Enabled
INFO - 2018-02-21 10:21:35 --> Utf8 Class Initialized
INFO - 2018-02-21 10:21:35 --> URI Class Initialized
INFO - 2018-02-21 10:21:35 --> Router Class Initialized
INFO - 2018-02-21 10:21:35 --> Output Class Initialized
INFO - 2018-02-21 10:21:35 --> Security Class Initialized
DEBUG - 2018-02-21 10:21:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-21 10:21:35 --> Input Class Initialized
INFO - 2018-02-21 10:21:35 --> Language Class Initialized
INFO - 2018-02-21 10:21:35 --> Loader Class Initialized
INFO - 2018-02-21 10:21:35 --> Helper loaded: url_helper
INFO - 2018-02-21 10:21:35 --> Helper loaded: file_helper
INFO - 2018-02-21 10:21:35 --> Helper loaded: email_helper
INFO - 2018-02-21 10:21:35 --> Helper loaded: common_helper
INFO - 2018-02-21 10:21:35 --> Database Driver Class Initialized
DEBUG - 2018-02-21 10:21:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-21 10:21:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-21 10:21:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-21 10:21:35 --> Pagination Class Initialized
INFO - 2018-02-21 10:21:35 --> Helper loaded: form_helper
INFO - 2018-02-21 10:21:35 --> Form Validation Class Initialized
INFO - 2018-02-21 10:21:35 --> Model Class Initialized
INFO - 2018-02-21 10:21:35 --> Controller Class Initialized
INFO - 2018-02-21 10:21:35 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-21 10:21:35 --> Model Class Initialized
INFO - 2018-02-21 10:21:35 --> Model Class Initialized
INFO - 2018-02-21 10:21:35 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-21 10:21:35 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-21 10:21:35 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-21 10:21:35 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-21 10:21:35 --> File loaded: /var/www/html/project/radio/application/views/subcategory/add_edit.php
INFO - 2018-02-21 10:21:35 --> Final output sent to browser
DEBUG - 2018-02-21 10:21:35 --> Total execution time: 0.0051
INFO - 2018-02-21 10:21:49 --> Config Class Initialized
INFO - 2018-02-21 10:21:49 --> Hooks Class Initialized
DEBUG - 2018-02-21 10:21:49 --> UTF-8 Support Enabled
INFO - 2018-02-21 10:21:49 --> Utf8 Class Initialized
INFO - 2018-02-21 10:21:49 --> URI Class Initialized
INFO - 2018-02-21 10:21:49 --> Router Class Initialized
INFO - 2018-02-21 10:21:49 --> Output Class Initialized
INFO - 2018-02-21 10:21:49 --> Security Class Initialized
DEBUG - 2018-02-21 10:21:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-21 10:21:49 --> Input Class Initialized
INFO - 2018-02-21 10:21:49 --> Language Class Initialized
INFO - 2018-02-21 10:21:49 --> Loader Class Initialized
INFO - 2018-02-21 10:21:49 --> Helper loaded: url_helper
INFO - 2018-02-21 10:21:49 --> Helper loaded: file_helper
INFO - 2018-02-21 10:21:49 --> Helper loaded: email_helper
INFO - 2018-02-21 10:21:49 --> Helper loaded: common_helper
INFO - 2018-02-21 10:21:49 --> Database Driver Class Initialized
DEBUG - 2018-02-21 10:21:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-21 10:21:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-21 10:21:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-21 10:21:49 --> Pagination Class Initialized
INFO - 2018-02-21 10:21:49 --> Helper loaded: form_helper
INFO - 2018-02-21 10:21:49 --> Form Validation Class Initialized
INFO - 2018-02-21 10:21:49 --> Model Class Initialized
INFO - 2018-02-21 10:21:49 --> Controller Class Initialized
INFO - 2018-02-21 10:21:49 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-21 10:21:49 --> Model Class Initialized
INFO - 2018-02-21 10:21:49 --> Model Class Initialized
INFO - 2018-02-21 10:21:49 --> Config Class Initialized
INFO - 2018-02-21 10:21:49 --> Hooks Class Initialized
DEBUG - 2018-02-21 10:21:49 --> UTF-8 Support Enabled
INFO - 2018-02-21 10:21:49 --> Utf8 Class Initialized
INFO - 2018-02-21 10:21:49 --> URI Class Initialized
INFO - 2018-02-21 10:21:49 --> Router Class Initialized
INFO - 2018-02-21 10:21:49 --> Output Class Initialized
INFO - 2018-02-21 10:21:49 --> Security Class Initialized
DEBUG - 2018-02-21 10:21:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-21 10:21:49 --> Input Class Initialized
INFO - 2018-02-21 10:21:49 --> Language Class Initialized
INFO - 2018-02-21 10:21:49 --> Loader Class Initialized
INFO - 2018-02-21 10:21:49 --> Helper loaded: url_helper
INFO - 2018-02-21 10:21:49 --> Helper loaded: file_helper
INFO - 2018-02-21 10:21:49 --> Helper loaded: email_helper
INFO - 2018-02-21 10:21:49 --> Helper loaded: common_helper
INFO - 2018-02-21 10:21:49 --> Database Driver Class Initialized
DEBUG - 2018-02-21 10:21:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-21 10:21:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-21 10:21:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-21 10:21:49 --> Pagination Class Initialized
INFO - 2018-02-21 10:21:49 --> Helper loaded: form_helper
INFO - 2018-02-21 10:21:49 --> Form Validation Class Initialized
INFO - 2018-02-21 10:21:49 --> Model Class Initialized
INFO - 2018-02-21 10:21:49 --> Controller Class Initialized
INFO - 2018-02-21 10:21:49 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-21 10:21:49 --> Model Class Initialized
INFO - 2018-02-21 10:21:49 --> Model Class Initialized
DEBUG - 2018-02-21 10:21:49 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-21 10:21:49 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-02-21 10:21:49 --> Config Class Initialized
INFO - 2018-02-21 10:21:49 --> Hooks Class Initialized
DEBUG - 2018-02-21 10:21:49 --> UTF-8 Support Enabled
INFO - 2018-02-21 10:21:49 --> Utf8 Class Initialized
INFO - 2018-02-21 10:21:49 --> URI Class Initialized
INFO - 2018-02-21 10:21:49 --> Router Class Initialized
INFO - 2018-02-21 10:21:49 --> Output Class Initialized
INFO - 2018-02-21 10:21:49 --> Security Class Initialized
DEBUG - 2018-02-21 10:21:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-21 10:21:49 --> Input Class Initialized
INFO - 2018-02-21 10:21:49 --> Language Class Initialized
INFO - 2018-02-21 10:21:49 --> Loader Class Initialized
INFO - 2018-02-21 10:21:49 --> Helper loaded: url_helper
INFO - 2018-02-21 10:21:49 --> Helper loaded: file_helper
INFO - 2018-02-21 10:21:49 --> Helper loaded: email_helper
INFO - 2018-02-21 10:21:49 --> Helper loaded: common_helper
INFO - 2018-02-21 10:21:49 --> Database Driver Class Initialized
DEBUG - 2018-02-21 10:21:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-21 10:21:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-21 10:21:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-21 10:21:49 --> Pagination Class Initialized
INFO - 2018-02-21 10:21:49 --> Helper loaded: form_helper
INFO - 2018-02-21 10:21:49 --> Form Validation Class Initialized
INFO - 2018-02-21 10:21:49 --> Model Class Initialized
INFO - 2018-02-21 10:21:49 --> Controller Class Initialized
INFO - 2018-02-21 10:21:49 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-21 10:21:49 --> Model Class Initialized
INFO - 2018-02-21 10:21:49 --> Model Class Initialized
INFO - 2018-02-21 10:21:49 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-21 10:21:49 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-21 10:21:49 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-21 10:21:49 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-21 10:21:49 --> File loaded: /var/www/html/project/radio/application/views/subcategory/index.php
INFO - 2018-02-21 10:21:49 --> Final output sent to browser
DEBUG - 2018-02-21 10:21:49 --> Total execution time: 0.0050
INFO - 2018-02-21 10:21:52 --> Config Class Initialized
INFO - 2018-02-21 10:21:52 --> Hooks Class Initialized
DEBUG - 2018-02-21 10:21:52 --> UTF-8 Support Enabled
INFO - 2018-02-21 10:21:52 --> Utf8 Class Initialized
INFO - 2018-02-21 10:21:52 --> URI Class Initialized
INFO - 2018-02-21 10:21:52 --> Router Class Initialized
INFO - 2018-02-21 10:21:52 --> Output Class Initialized
INFO - 2018-02-21 10:21:52 --> Security Class Initialized
DEBUG - 2018-02-21 10:21:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-21 10:21:52 --> Input Class Initialized
INFO - 2018-02-21 10:21:52 --> Language Class Initialized
INFO - 2018-02-21 10:21:52 --> Loader Class Initialized
INFO - 2018-02-21 10:21:52 --> Helper loaded: url_helper
INFO - 2018-02-21 10:21:52 --> Helper loaded: file_helper
INFO - 2018-02-21 10:21:52 --> Helper loaded: email_helper
INFO - 2018-02-21 10:21:52 --> Helper loaded: common_helper
INFO - 2018-02-21 10:21:52 --> Database Driver Class Initialized
DEBUG - 2018-02-21 10:21:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-21 10:21:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-21 10:21:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-21 10:21:52 --> Pagination Class Initialized
INFO - 2018-02-21 10:21:52 --> Helper loaded: form_helper
INFO - 2018-02-21 10:21:52 --> Form Validation Class Initialized
INFO - 2018-02-21 10:21:52 --> Model Class Initialized
INFO - 2018-02-21 10:21:52 --> Controller Class Initialized
INFO - 2018-02-21 10:21:52 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-21 10:21:52 --> Model Class Initialized
INFO - 2018-02-21 10:21:52 --> Model Class Initialized
INFO - 2018-02-21 10:21:52 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-21 10:21:52 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-21 10:21:52 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-21 10:21:52 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-21 10:21:52 --> File loaded: /var/www/html/project/radio/application/views/subcategory/add_edit.php
INFO - 2018-02-21 10:21:52 --> Final output sent to browser
DEBUG - 2018-02-21 10:21:52 --> Total execution time: 0.0068
INFO - 2018-02-21 10:22:06 --> Config Class Initialized
INFO - 2018-02-21 10:22:06 --> Hooks Class Initialized
DEBUG - 2018-02-21 10:22:06 --> UTF-8 Support Enabled
INFO - 2018-02-21 10:22:06 --> Utf8 Class Initialized
INFO - 2018-02-21 10:22:06 --> URI Class Initialized
INFO - 2018-02-21 10:22:06 --> Router Class Initialized
INFO - 2018-02-21 10:22:06 --> Output Class Initialized
INFO - 2018-02-21 10:22:06 --> Security Class Initialized
DEBUG - 2018-02-21 10:22:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-21 10:22:06 --> Input Class Initialized
INFO - 2018-02-21 10:22:06 --> Language Class Initialized
INFO - 2018-02-21 10:22:06 --> Loader Class Initialized
INFO - 2018-02-21 10:22:06 --> Helper loaded: url_helper
INFO - 2018-02-21 10:22:06 --> Helper loaded: file_helper
INFO - 2018-02-21 10:22:06 --> Helper loaded: email_helper
INFO - 2018-02-21 10:22:06 --> Helper loaded: common_helper
INFO - 2018-02-21 10:22:06 --> Database Driver Class Initialized
DEBUG - 2018-02-21 10:22:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-21 10:22:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-21 10:22:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-21 10:22:06 --> Pagination Class Initialized
INFO - 2018-02-21 10:22:06 --> Helper loaded: form_helper
INFO - 2018-02-21 10:22:06 --> Form Validation Class Initialized
INFO - 2018-02-21 10:22:06 --> Model Class Initialized
INFO - 2018-02-21 10:22:06 --> Controller Class Initialized
INFO - 2018-02-21 10:22:06 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-21 10:22:06 --> Model Class Initialized
INFO - 2018-02-21 10:22:06 --> Model Class Initialized
INFO - 2018-02-21 10:22:06 --> Config Class Initialized
INFO - 2018-02-21 10:22:06 --> Hooks Class Initialized
DEBUG - 2018-02-21 10:22:06 --> UTF-8 Support Enabled
INFO - 2018-02-21 10:22:06 --> Utf8 Class Initialized
INFO - 2018-02-21 10:22:06 --> URI Class Initialized
INFO - 2018-02-21 10:22:06 --> Router Class Initialized
INFO - 2018-02-21 10:22:06 --> Output Class Initialized
INFO - 2018-02-21 10:22:06 --> Security Class Initialized
DEBUG - 2018-02-21 10:22:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-21 10:22:06 --> Input Class Initialized
INFO - 2018-02-21 10:22:06 --> Language Class Initialized
INFO - 2018-02-21 10:22:06 --> Loader Class Initialized
INFO - 2018-02-21 10:22:06 --> Helper loaded: url_helper
INFO - 2018-02-21 10:22:06 --> Helper loaded: file_helper
INFO - 2018-02-21 10:22:06 --> Helper loaded: email_helper
INFO - 2018-02-21 10:22:06 --> Helper loaded: common_helper
INFO - 2018-02-21 10:22:06 --> Database Driver Class Initialized
DEBUG - 2018-02-21 10:22:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-21 10:22:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-21 10:22:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-21 10:22:06 --> Pagination Class Initialized
INFO - 2018-02-21 10:22:06 --> Helper loaded: form_helper
INFO - 2018-02-21 10:22:06 --> Form Validation Class Initialized
INFO - 2018-02-21 10:22:06 --> Model Class Initialized
INFO - 2018-02-21 10:22:06 --> Controller Class Initialized
INFO - 2018-02-21 10:22:06 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-21 10:22:06 --> Model Class Initialized
INFO - 2018-02-21 10:22:06 --> Model Class Initialized
DEBUG - 2018-02-21 10:22:06 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-21 10:22:06 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-02-21 10:22:06 --> Config Class Initialized
INFO - 2018-02-21 10:22:06 --> Hooks Class Initialized
DEBUG - 2018-02-21 10:22:06 --> UTF-8 Support Enabled
INFO - 2018-02-21 10:22:06 --> Utf8 Class Initialized
INFO - 2018-02-21 10:22:06 --> URI Class Initialized
INFO - 2018-02-21 10:22:06 --> Router Class Initialized
INFO - 2018-02-21 10:22:06 --> Output Class Initialized
INFO - 2018-02-21 10:22:06 --> Security Class Initialized
DEBUG - 2018-02-21 10:22:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-21 10:22:06 --> Input Class Initialized
INFO - 2018-02-21 10:22:06 --> Language Class Initialized
INFO - 2018-02-21 10:22:06 --> Loader Class Initialized
INFO - 2018-02-21 10:22:06 --> Helper loaded: url_helper
INFO - 2018-02-21 10:22:06 --> Helper loaded: file_helper
INFO - 2018-02-21 10:22:06 --> Helper loaded: email_helper
INFO - 2018-02-21 10:22:06 --> Helper loaded: common_helper
INFO - 2018-02-21 10:22:06 --> Database Driver Class Initialized
DEBUG - 2018-02-21 10:22:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-21 10:22:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-21 10:22:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-21 10:22:06 --> Pagination Class Initialized
INFO - 2018-02-21 10:22:06 --> Helper loaded: form_helper
INFO - 2018-02-21 10:22:06 --> Form Validation Class Initialized
INFO - 2018-02-21 10:22:06 --> Model Class Initialized
INFO - 2018-02-21 10:22:06 --> Controller Class Initialized
INFO - 2018-02-21 10:22:06 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-21 10:22:06 --> Model Class Initialized
INFO - 2018-02-21 10:22:06 --> Model Class Initialized
INFO - 2018-02-21 10:22:06 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-21 10:22:06 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-21 10:22:06 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-21 10:22:06 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-21 10:22:06 --> File loaded: /var/www/html/project/radio/application/views/subcategory/index.php
INFO - 2018-02-21 10:22:06 --> Final output sent to browser
DEBUG - 2018-02-21 10:22:06 --> Total execution time: 0.0906
INFO - 2018-02-21 10:22:20 --> Config Class Initialized
INFO - 2018-02-21 10:22:20 --> Hooks Class Initialized
DEBUG - 2018-02-21 10:22:20 --> UTF-8 Support Enabled
INFO - 2018-02-21 10:22:20 --> Utf8 Class Initialized
INFO - 2018-02-21 10:22:20 --> URI Class Initialized
INFO - 2018-02-21 10:22:20 --> Router Class Initialized
INFO - 2018-02-21 10:22:20 --> Output Class Initialized
INFO - 2018-02-21 10:22:20 --> Security Class Initialized
DEBUG - 2018-02-21 10:22:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-21 10:22:20 --> Input Class Initialized
INFO - 2018-02-21 10:22:20 --> Language Class Initialized
INFO - 2018-02-21 10:22:20 --> Loader Class Initialized
INFO - 2018-02-21 10:22:20 --> Helper loaded: url_helper
INFO - 2018-02-21 10:22:20 --> Helper loaded: file_helper
INFO - 2018-02-21 10:22:20 --> Helper loaded: email_helper
INFO - 2018-02-21 10:22:20 --> Helper loaded: common_helper
INFO - 2018-02-21 10:22:20 --> Database Driver Class Initialized
DEBUG - 2018-02-21 10:22:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-21 10:22:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-21 10:22:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-21 10:22:20 --> Pagination Class Initialized
INFO - 2018-02-21 10:22:20 --> Helper loaded: form_helper
INFO - 2018-02-21 10:22:20 --> Form Validation Class Initialized
INFO - 2018-02-21 10:22:20 --> Model Class Initialized
INFO - 2018-02-21 10:22:20 --> Controller Class Initialized
INFO - 2018-02-21 10:22:20 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-21 10:22:20 --> Model Class Initialized
INFO - 2018-02-21 10:22:20 --> Model Class Initialized
INFO - 2018-02-21 10:22:20 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-21 10:22:20 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-21 10:22:20 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-21 10:22:20 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-21 10:22:20 --> File loaded: /var/www/html/project/radio/application/views/subcategory/add_edit.php
INFO - 2018-02-21 10:22:20 --> Final output sent to browser
DEBUG - 2018-02-21 10:22:20 --> Total execution time: 0.0071
INFO - 2018-02-21 10:22:33 --> Config Class Initialized
INFO - 2018-02-21 10:22:33 --> Hooks Class Initialized
DEBUG - 2018-02-21 10:22:33 --> UTF-8 Support Enabled
INFO - 2018-02-21 10:22:33 --> Utf8 Class Initialized
INFO - 2018-02-21 10:22:33 --> URI Class Initialized
INFO - 2018-02-21 10:22:33 --> Router Class Initialized
INFO - 2018-02-21 10:22:33 --> Output Class Initialized
INFO - 2018-02-21 10:22:33 --> Security Class Initialized
DEBUG - 2018-02-21 10:22:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-21 10:22:33 --> Input Class Initialized
INFO - 2018-02-21 10:22:33 --> Language Class Initialized
INFO - 2018-02-21 10:22:33 --> Loader Class Initialized
INFO - 2018-02-21 10:22:33 --> Helper loaded: url_helper
INFO - 2018-02-21 10:22:33 --> Helper loaded: file_helper
INFO - 2018-02-21 10:22:33 --> Helper loaded: email_helper
INFO - 2018-02-21 10:22:33 --> Helper loaded: common_helper
INFO - 2018-02-21 10:22:33 --> Database Driver Class Initialized
DEBUG - 2018-02-21 10:22:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-21 10:22:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-21 10:22:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-21 10:22:33 --> Pagination Class Initialized
INFO - 2018-02-21 10:22:33 --> Helper loaded: form_helper
INFO - 2018-02-21 10:22:33 --> Form Validation Class Initialized
INFO - 2018-02-21 10:22:33 --> Model Class Initialized
INFO - 2018-02-21 10:22:33 --> Controller Class Initialized
INFO - 2018-02-21 10:22:33 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-21 10:22:33 --> Model Class Initialized
INFO - 2018-02-21 10:22:33 --> Model Class Initialized
INFO - 2018-02-21 10:22:33 --> Config Class Initialized
INFO - 2018-02-21 10:22:33 --> Hooks Class Initialized
DEBUG - 2018-02-21 10:22:33 --> UTF-8 Support Enabled
INFO - 2018-02-21 10:22:33 --> Utf8 Class Initialized
INFO - 2018-02-21 10:22:33 --> URI Class Initialized
INFO - 2018-02-21 10:22:33 --> Router Class Initialized
INFO - 2018-02-21 10:22:33 --> Output Class Initialized
INFO - 2018-02-21 10:22:33 --> Security Class Initialized
DEBUG - 2018-02-21 10:22:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-21 10:22:33 --> Input Class Initialized
INFO - 2018-02-21 10:22:33 --> Language Class Initialized
INFO - 2018-02-21 10:22:33 --> Loader Class Initialized
INFO - 2018-02-21 10:22:33 --> Helper loaded: url_helper
INFO - 2018-02-21 10:22:33 --> Helper loaded: file_helper
INFO - 2018-02-21 10:22:33 --> Helper loaded: email_helper
INFO - 2018-02-21 10:22:33 --> Helper loaded: common_helper
INFO - 2018-02-21 10:22:33 --> Database Driver Class Initialized
DEBUG - 2018-02-21 10:22:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-21 10:22:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-21 10:22:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-21 10:22:33 --> Pagination Class Initialized
INFO - 2018-02-21 10:22:33 --> Helper loaded: form_helper
INFO - 2018-02-21 10:22:33 --> Form Validation Class Initialized
INFO - 2018-02-21 10:22:33 --> Model Class Initialized
INFO - 2018-02-21 10:22:33 --> Controller Class Initialized
INFO - 2018-02-21 10:22:33 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-21 10:22:33 --> Model Class Initialized
INFO - 2018-02-21 10:22:33 --> Model Class Initialized
DEBUG - 2018-02-21 10:22:33 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-21 10:22:33 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-02-21 10:22:33 --> Config Class Initialized
INFO - 2018-02-21 10:22:33 --> Hooks Class Initialized
DEBUG - 2018-02-21 10:22:33 --> UTF-8 Support Enabled
INFO - 2018-02-21 10:22:33 --> Utf8 Class Initialized
INFO - 2018-02-21 10:22:33 --> URI Class Initialized
INFO - 2018-02-21 10:22:33 --> Router Class Initialized
INFO - 2018-02-21 10:22:33 --> Output Class Initialized
INFO - 2018-02-21 10:22:33 --> Security Class Initialized
DEBUG - 2018-02-21 10:22:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-21 10:22:33 --> Input Class Initialized
INFO - 2018-02-21 10:22:33 --> Language Class Initialized
INFO - 2018-02-21 10:22:33 --> Loader Class Initialized
INFO - 2018-02-21 10:22:33 --> Helper loaded: url_helper
INFO - 2018-02-21 10:22:33 --> Helper loaded: file_helper
INFO - 2018-02-21 10:22:33 --> Helper loaded: email_helper
INFO - 2018-02-21 10:22:33 --> Helper loaded: common_helper
INFO - 2018-02-21 10:22:33 --> Database Driver Class Initialized
DEBUG - 2018-02-21 10:22:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-21 10:22:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-21 10:22:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-21 10:22:33 --> Pagination Class Initialized
INFO - 2018-02-21 10:22:33 --> Helper loaded: form_helper
INFO - 2018-02-21 10:22:33 --> Form Validation Class Initialized
INFO - 2018-02-21 10:22:33 --> Model Class Initialized
INFO - 2018-02-21 10:22:33 --> Controller Class Initialized
INFO - 2018-02-21 10:22:33 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-21 10:22:33 --> Model Class Initialized
INFO - 2018-02-21 10:22:33 --> Model Class Initialized
INFO - 2018-02-21 10:22:33 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-21 10:22:33 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-21 10:22:33 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-21 10:22:33 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-21 10:22:33 --> File loaded: /var/www/html/project/radio/application/views/subcategory/index.php
INFO - 2018-02-21 10:22:33 --> Final output sent to browser
DEBUG - 2018-02-21 10:22:33 --> Total execution time: 0.0074
INFO - 2018-02-21 10:22:35 --> Config Class Initialized
INFO - 2018-02-21 10:22:35 --> Hooks Class Initialized
DEBUG - 2018-02-21 10:22:35 --> UTF-8 Support Enabled
INFO - 2018-02-21 10:22:35 --> Utf8 Class Initialized
INFO - 2018-02-21 10:22:35 --> URI Class Initialized
INFO - 2018-02-21 10:22:35 --> Router Class Initialized
INFO - 2018-02-21 10:22:35 --> Output Class Initialized
INFO - 2018-02-21 10:22:35 --> Security Class Initialized
DEBUG - 2018-02-21 10:22:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-21 10:22:35 --> Input Class Initialized
INFO - 2018-02-21 10:22:35 --> Language Class Initialized
INFO - 2018-02-21 10:22:35 --> Loader Class Initialized
INFO - 2018-02-21 10:22:35 --> Helper loaded: url_helper
INFO - 2018-02-21 10:22:35 --> Helper loaded: file_helper
INFO - 2018-02-21 10:22:35 --> Helper loaded: email_helper
INFO - 2018-02-21 10:22:35 --> Helper loaded: common_helper
INFO - 2018-02-21 10:22:35 --> Database Driver Class Initialized
DEBUG - 2018-02-21 10:22:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-21 10:22:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-21 10:22:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-21 10:22:35 --> Pagination Class Initialized
INFO - 2018-02-21 10:22:35 --> Helper loaded: form_helper
INFO - 2018-02-21 10:22:35 --> Form Validation Class Initialized
INFO - 2018-02-21 10:22:35 --> Model Class Initialized
INFO - 2018-02-21 10:22:35 --> Controller Class Initialized
INFO - 2018-02-21 10:22:35 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-21 10:22:35 --> Model Class Initialized
INFO - 2018-02-21 10:22:35 --> Model Class Initialized
INFO - 2018-02-21 10:22:35 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-21 10:22:35 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-21 10:22:35 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-21 10:22:35 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-21 10:22:35 --> File loaded: /var/www/html/project/radio/application/views/subcategory/add_edit.php
INFO - 2018-02-21 10:22:35 --> Final output sent to browser
DEBUG - 2018-02-21 10:22:35 --> Total execution time: 0.0070
INFO - 2018-02-21 10:23:02 --> Config Class Initialized
INFO - 2018-02-21 10:23:02 --> Hooks Class Initialized
DEBUG - 2018-02-21 10:23:02 --> UTF-8 Support Enabled
INFO - 2018-02-21 10:23:02 --> Utf8 Class Initialized
INFO - 2018-02-21 10:23:02 --> URI Class Initialized
INFO - 2018-02-21 10:23:02 --> Router Class Initialized
INFO - 2018-02-21 10:23:02 --> Output Class Initialized
INFO - 2018-02-21 10:23:02 --> Security Class Initialized
DEBUG - 2018-02-21 10:23:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-21 10:23:02 --> Input Class Initialized
INFO - 2018-02-21 10:23:02 --> Language Class Initialized
INFO - 2018-02-21 10:23:02 --> Loader Class Initialized
INFO - 2018-02-21 10:23:02 --> Helper loaded: url_helper
INFO - 2018-02-21 10:23:02 --> Helper loaded: file_helper
INFO - 2018-02-21 10:23:02 --> Helper loaded: email_helper
INFO - 2018-02-21 10:23:02 --> Helper loaded: common_helper
INFO - 2018-02-21 10:23:02 --> Database Driver Class Initialized
DEBUG - 2018-02-21 10:23:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-21 10:23:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-21 10:23:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-21 10:23:02 --> Pagination Class Initialized
INFO - 2018-02-21 10:23:02 --> Helper loaded: form_helper
INFO - 2018-02-21 10:23:02 --> Form Validation Class Initialized
INFO - 2018-02-21 10:23:02 --> Model Class Initialized
INFO - 2018-02-21 10:23:02 --> Controller Class Initialized
INFO - 2018-02-21 10:23:02 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-21 10:23:02 --> Model Class Initialized
INFO - 2018-02-21 10:23:02 --> Model Class Initialized
INFO - 2018-02-21 10:23:02 --> Config Class Initialized
INFO - 2018-02-21 10:23:02 --> Hooks Class Initialized
DEBUG - 2018-02-21 10:23:02 --> UTF-8 Support Enabled
INFO - 2018-02-21 10:23:02 --> Utf8 Class Initialized
INFO - 2018-02-21 10:23:02 --> URI Class Initialized
INFO - 2018-02-21 10:23:02 --> Router Class Initialized
INFO - 2018-02-21 10:23:02 --> Output Class Initialized
INFO - 2018-02-21 10:23:02 --> Security Class Initialized
DEBUG - 2018-02-21 10:23:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-21 10:23:02 --> Input Class Initialized
INFO - 2018-02-21 10:23:02 --> Language Class Initialized
INFO - 2018-02-21 10:23:02 --> Loader Class Initialized
INFO - 2018-02-21 10:23:02 --> Helper loaded: url_helper
INFO - 2018-02-21 10:23:02 --> Helper loaded: file_helper
INFO - 2018-02-21 10:23:02 --> Helper loaded: email_helper
INFO - 2018-02-21 10:23:02 --> Helper loaded: common_helper
INFO - 2018-02-21 10:23:02 --> Database Driver Class Initialized
DEBUG - 2018-02-21 10:23:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-21 10:23:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-21 10:23:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-21 10:23:02 --> Pagination Class Initialized
INFO - 2018-02-21 10:23:02 --> Helper loaded: form_helper
INFO - 2018-02-21 10:23:02 --> Form Validation Class Initialized
INFO - 2018-02-21 10:23:02 --> Model Class Initialized
INFO - 2018-02-21 10:23:02 --> Controller Class Initialized
INFO - 2018-02-21 10:23:02 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-21 10:23:02 --> Model Class Initialized
INFO - 2018-02-21 10:23:02 --> Model Class Initialized
DEBUG - 2018-02-21 10:23:02 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-21 10:23:02 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-02-21 10:23:02 --> Config Class Initialized
INFO - 2018-02-21 10:23:02 --> Hooks Class Initialized
DEBUG - 2018-02-21 10:23:02 --> UTF-8 Support Enabled
INFO - 2018-02-21 10:23:02 --> Utf8 Class Initialized
INFO - 2018-02-21 10:23:02 --> URI Class Initialized
INFO - 2018-02-21 10:23:02 --> Router Class Initialized
INFO - 2018-02-21 10:23:02 --> Output Class Initialized
INFO - 2018-02-21 10:23:02 --> Security Class Initialized
DEBUG - 2018-02-21 10:23:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-21 10:23:02 --> Input Class Initialized
INFO - 2018-02-21 10:23:02 --> Language Class Initialized
INFO - 2018-02-21 10:23:02 --> Loader Class Initialized
INFO - 2018-02-21 10:23:02 --> Helper loaded: url_helper
INFO - 2018-02-21 10:23:02 --> Helper loaded: file_helper
INFO - 2018-02-21 10:23:02 --> Helper loaded: email_helper
INFO - 2018-02-21 10:23:02 --> Helper loaded: common_helper
INFO - 2018-02-21 10:23:02 --> Database Driver Class Initialized
DEBUG - 2018-02-21 10:23:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-21 10:23:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-21 10:23:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-21 10:23:02 --> Pagination Class Initialized
INFO - 2018-02-21 10:23:02 --> Helper loaded: form_helper
INFO - 2018-02-21 10:23:02 --> Form Validation Class Initialized
INFO - 2018-02-21 10:23:02 --> Model Class Initialized
INFO - 2018-02-21 10:23:02 --> Controller Class Initialized
INFO - 2018-02-21 10:23:02 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-21 10:23:02 --> Model Class Initialized
INFO - 2018-02-21 10:23:02 --> Model Class Initialized
INFO - 2018-02-21 10:23:02 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-21 10:23:02 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-21 10:23:02 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-21 10:23:02 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-21 10:23:02 --> File loaded: /var/www/html/project/radio/application/views/subcategory/index.php
INFO - 2018-02-21 10:23:02 --> Final output sent to browser
DEBUG - 2018-02-21 10:23:02 --> Total execution time: 0.0046
INFO - 2018-02-21 10:23:05 --> Config Class Initialized
INFO - 2018-02-21 10:23:05 --> Hooks Class Initialized
DEBUG - 2018-02-21 10:23:05 --> UTF-8 Support Enabled
INFO - 2018-02-21 10:23:05 --> Utf8 Class Initialized
INFO - 2018-02-21 10:23:05 --> URI Class Initialized
INFO - 2018-02-21 10:23:05 --> Router Class Initialized
INFO - 2018-02-21 10:23:05 --> Output Class Initialized
INFO - 2018-02-21 10:23:05 --> Security Class Initialized
DEBUG - 2018-02-21 10:23:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-21 10:23:05 --> Input Class Initialized
INFO - 2018-02-21 10:23:05 --> Language Class Initialized
INFO - 2018-02-21 10:23:05 --> Loader Class Initialized
INFO - 2018-02-21 10:23:05 --> Helper loaded: url_helper
INFO - 2018-02-21 10:23:05 --> Helper loaded: file_helper
INFO - 2018-02-21 10:23:05 --> Helper loaded: email_helper
INFO - 2018-02-21 10:23:05 --> Helper loaded: common_helper
INFO - 2018-02-21 10:23:05 --> Database Driver Class Initialized
DEBUG - 2018-02-21 10:23:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-21 10:23:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-21 10:23:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-21 10:23:05 --> Pagination Class Initialized
INFO - 2018-02-21 10:23:05 --> Helper loaded: form_helper
INFO - 2018-02-21 10:23:05 --> Form Validation Class Initialized
INFO - 2018-02-21 10:23:05 --> Model Class Initialized
INFO - 2018-02-21 10:23:05 --> Controller Class Initialized
INFO - 2018-02-21 10:23:05 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-21 10:23:05 --> Model Class Initialized
INFO - 2018-02-21 10:23:05 --> Model Class Initialized
INFO - 2018-02-21 10:23:05 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-21 10:23:05 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-21 10:23:05 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-21 10:23:05 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-21 10:23:05 --> File loaded: /var/www/html/project/radio/application/views/subcategory/add_edit.php
INFO - 2018-02-21 10:23:05 --> Final output sent to browser
DEBUG - 2018-02-21 10:23:05 --> Total execution time: 0.0052
INFO - 2018-02-21 10:23:08 --> Config Class Initialized
INFO - 2018-02-21 10:23:08 --> Hooks Class Initialized
DEBUG - 2018-02-21 10:23:08 --> UTF-8 Support Enabled
INFO - 2018-02-21 10:23:08 --> Utf8 Class Initialized
INFO - 2018-02-21 10:23:08 --> URI Class Initialized
INFO - 2018-02-21 10:23:08 --> Router Class Initialized
INFO - 2018-02-21 10:23:08 --> Output Class Initialized
INFO - 2018-02-21 10:23:08 --> Security Class Initialized
DEBUG - 2018-02-21 10:23:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-21 10:23:08 --> Input Class Initialized
INFO - 2018-02-21 10:23:08 --> Language Class Initialized
INFO - 2018-02-21 10:23:08 --> Loader Class Initialized
INFO - 2018-02-21 10:23:08 --> Helper loaded: url_helper
INFO - 2018-02-21 10:23:08 --> Helper loaded: file_helper
INFO - 2018-02-21 10:23:08 --> Helper loaded: email_helper
INFO - 2018-02-21 10:23:08 --> Helper loaded: common_helper
INFO - 2018-02-21 10:23:08 --> Database Driver Class Initialized
DEBUG - 2018-02-21 10:23:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-21 10:23:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-21 10:23:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-21 10:23:08 --> Pagination Class Initialized
INFO - 2018-02-21 10:23:08 --> Helper loaded: form_helper
INFO - 2018-02-21 10:23:08 --> Form Validation Class Initialized
INFO - 2018-02-21 10:23:08 --> Model Class Initialized
INFO - 2018-02-21 10:23:08 --> Controller Class Initialized
INFO - 2018-02-21 10:23:08 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-21 10:23:08 --> Model Class Initialized
INFO - 2018-02-21 10:23:08 --> Model Class Initialized
INFO - 2018-02-21 10:23:08 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-21 10:23:08 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-21 10:23:08 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-21 10:23:08 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-21 10:23:08 --> File loaded: /var/www/html/project/radio/application/views/subcategory/index.php
INFO - 2018-02-21 10:23:08 --> Final output sent to browser
DEBUG - 2018-02-21 10:23:08 --> Total execution time: 0.0074
INFO - 2018-02-21 10:23:10 --> Config Class Initialized
INFO - 2018-02-21 10:23:10 --> Hooks Class Initialized
DEBUG - 2018-02-21 10:23:10 --> UTF-8 Support Enabled
INFO - 2018-02-21 10:23:10 --> Utf8 Class Initialized
INFO - 2018-02-21 10:23:10 --> URI Class Initialized
INFO - 2018-02-21 10:23:10 --> Router Class Initialized
INFO - 2018-02-21 10:23:10 --> Output Class Initialized
INFO - 2018-02-21 10:23:10 --> Security Class Initialized
DEBUG - 2018-02-21 10:23:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-21 10:23:10 --> Input Class Initialized
INFO - 2018-02-21 10:23:10 --> Language Class Initialized
INFO - 2018-02-21 10:23:10 --> Loader Class Initialized
INFO - 2018-02-21 10:23:10 --> Helper loaded: url_helper
INFO - 2018-02-21 10:23:10 --> Helper loaded: file_helper
INFO - 2018-02-21 10:23:10 --> Helper loaded: email_helper
INFO - 2018-02-21 10:23:10 --> Helper loaded: common_helper
INFO - 2018-02-21 10:23:10 --> Database Driver Class Initialized
DEBUG - 2018-02-21 10:23:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-21 10:23:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-21 10:23:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-21 10:23:10 --> Pagination Class Initialized
INFO - 2018-02-21 10:23:10 --> Helper loaded: form_helper
INFO - 2018-02-21 10:23:10 --> Form Validation Class Initialized
INFO - 2018-02-21 10:23:10 --> Model Class Initialized
INFO - 2018-02-21 10:23:10 --> Controller Class Initialized
INFO - 2018-02-21 10:23:10 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-21 10:23:10 --> Model Class Initialized
INFO - 2018-02-21 10:23:10 --> Model Class Initialized
INFO - 2018-02-21 10:23:10 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-21 10:23:10 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-21 10:23:10 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-21 10:23:10 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-21 10:23:10 --> File loaded: /var/www/html/project/radio/application/views/subcategory/add_edit.php
INFO - 2018-02-21 10:23:10 --> Final output sent to browser
DEBUG - 2018-02-21 10:23:10 --> Total execution time: 0.0070
INFO - 2018-02-21 10:23:14 --> Config Class Initialized
INFO - 2018-02-21 10:23:14 --> Hooks Class Initialized
DEBUG - 2018-02-21 10:23:14 --> UTF-8 Support Enabled
INFO - 2018-02-21 10:23:14 --> Utf8 Class Initialized
INFO - 2018-02-21 10:23:14 --> URI Class Initialized
INFO - 2018-02-21 10:23:14 --> Router Class Initialized
INFO - 2018-02-21 10:23:14 --> Output Class Initialized
INFO - 2018-02-21 10:23:14 --> Security Class Initialized
DEBUG - 2018-02-21 10:23:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-21 10:23:14 --> Input Class Initialized
INFO - 2018-02-21 10:23:14 --> Language Class Initialized
INFO - 2018-02-21 10:23:14 --> Loader Class Initialized
INFO - 2018-02-21 10:23:14 --> Helper loaded: url_helper
INFO - 2018-02-21 10:23:14 --> Helper loaded: file_helper
INFO - 2018-02-21 10:23:14 --> Helper loaded: email_helper
INFO - 2018-02-21 10:23:14 --> Helper loaded: common_helper
INFO - 2018-02-21 10:23:14 --> Database Driver Class Initialized
DEBUG - 2018-02-21 10:23:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-21 10:23:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-21 10:23:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-21 10:23:14 --> Pagination Class Initialized
INFO - 2018-02-21 10:23:14 --> Helper loaded: form_helper
INFO - 2018-02-21 10:23:14 --> Form Validation Class Initialized
INFO - 2018-02-21 10:23:14 --> Model Class Initialized
INFO - 2018-02-21 10:23:14 --> Controller Class Initialized
INFO - 2018-02-21 10:23:14 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-21 10:23:14 --> Model Class Initialized
INFO - 2018-02-21 10:23:14 --> Model Class Initialized
INFO - 2018-02-21 10:23:14 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-21 10:23:14 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-21 10:23:14 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-21 10:23:14 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-21 10:23:14 --> File loaded: /var/www/html/project/radio/application/views/subcategory/index.php
INFO - 2018-02-21 10:23:14 --> Final output sent to browser
DEBUG - 2018-02-21 10:23:14 --> Total execution time: 0.0082
INFO - 2018-02-21 10:23:17 --> Config Class Initialized
INFO - 2018-02-21 10:23:17 --> Hooks Class Initialized
DEBUG - 2018-02-21 10:23:17 --> UTF-8 Support Enabled
INFO - 2018-02-21 10:23:17 --> Utf8 Class Initialized
INFO - 2018-02-21 10:23:17 --> URI Class Initialized
INFO - 2018-02-21 10:23:17 --> Router Class Initialized
INFO - 2018-02-21 10:23:17 --> Output Class Initialized
INFO - 2018-02-21 10:23:17 --> Security Class Initialized
DEBUG - 2018-02-21 10:23:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-21 10:23:17 --> Input Class Initialized
INFO - 2018-02-21 10:23:17 --> Language Class Initialized
INFO - 2018-02-21 10:23:17 --> Loader Class Initialized
INFO - 2018-02-21 10:23:17 --> Helper loaded: url_helper
INFO - 2018-02-21 10:23:17 --> Helper loaded: file_helper
INFO - 2018-02-21 10:23:17 --> Helper loaded: email_helper
INFO - 2018-02-21 10:23:17 --> Helper loaded: common_helper
INFO - 2018-02-21 10:23:17 --> Database Driver Class Initialized
DEBUG - 2018-02-21 10:23:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-21 10:23:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-21 10:23:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-21 10:23:17 --> Pagination Class Initialized
INFO - 2018-02-21 10:23:17 --> Helper loaded: form_helper
INFO - 2018-02-21 10:23:17 --> Form Validation Class Initialized
INFO - 2018-02-21 10:23:17 --> Model Class Initialized
INFO - 2018-02-21 10:23:17 --> Controller Class Initialized
INFO - 2018-02-21 10:23:17 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-21 10:23:17 --> Model Class Initialized
INFO - 2018-02-21 10:23:17 --> Model Class Initialized
INFO - 2018-02-21 10:23:17 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-21 10:23:17 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-21 10:23:17 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-21 10:23:17 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-21 10:23:17 --> File loaded: /var/www/html/project/radio/application/views/subcategory/add_edit.php
INFO - 2018-02-21 10:23:17 --> Final output sent to browser
DEBUG - 2018-02-21 10:23:17 --> Total execution time: 0.0058
INFO - 2018-02-21 10:23:20 --> Config Class Initialized
INFO - 2018-02-21 10:23:20 --> Hooks Class Initialized
DEBUG - 2018-02-21 10:23:20 --> UTF-8 Support Enabled
INFO - 2018-02-21 10:23:20 --> Utf8 Class Initialized
INFO - 2018-02-21 10:23:20 --> URI Class Initialized
INFO - 2018-02-21 10:23:20 --> Router Class Initialized
INFO - 2018-02-21 10:23:20 --> Output Class Initialized
INFO - 2018-02-21 10:23:20 --> Security Class Initialized
DEBUG - 2018-02-21 10:23:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-21 10:23:20 --> Input Class Initialized
INFO - 2018-02-21 10:23:20 --> Language Class Initialized
INFO - 2018-02-21 10:23:20 --> Loader Class Initialized
INFO - 2018-02-21 10:23:20 --> Helper loaded: url_helper
INFO - 2018-02-21 10:23:20 --> Helper loaded: file_helper
INFO - 2018-02-21 10:23:20 --> Helper loaded: email_helper
INFO - 2018-02-21 10:23:20 --> Helper loaded: common_helper
INFO - 2018-02-21 10:23:20 --> Database Driver Class Initialized
DEBUG - 2018-02-21 10:23:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-21 10:23:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-21 10:23:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-21 10:23:20 --> Pagination Class Initialized
INFO - 2018-02-21 10:23:20 --> Helper loaded: form_helper
INFO - 2018-02-21 10:23:20 --> Form Validation Class Initialized
INFO - 2018-02-21 10:23:20 --> Model Class Initialized
INFO - 2018-02-21 10:23:20 --> Controller Class Initialized
INFO - 2018-02-21 10:23:20 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-21 10:23:20 --> Model Class Initialized
INFO - 2018-02-21 10:23:20 --> Model Class Initialized
INFO - 2018-02-21 10:23:20 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-21 10:23:20 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-21 10:23:20 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-21 10:23:20 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-21 10:23:20 --> File loaded: /var/www/html/project/radio/application/views/subcategory/index.php
INFO - 2018-02-21 10:23:20 --> Final output sent to browser
DEBUG - 2018-02-21 10:23:20 --> Total execution time: 0.0061
INFO - 2018-02-21 10:23:24 --> Config Class Initialized
INFO - 2018-02-21 10:23:24 --> Hooks Class Initialized
DEBUG - 2018-02-21 10:23:24 --> UTF-8 Support Enabled
INFO - 2018-02-21 10:23:24 --> Utf8 Class Initialized
INFO - 2018-02-21 10:23:24 --> URI Class Initialized
INFO - 2018-02-21 10:23:24 --> Router Class Initialized
INFO - 2018-02-21 10:23:24 --> Output Class Initialized
INFO - 2018-02-21 10:23:24 --> Security Class Initialized
DEBUG - 2018-02-21 10:23:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-21 10:23:24 --> Input Class Initialized
INFO - 2018-02-21 10:23:24 --> Language Class Initialized
INFO - 2018-02-21 10:23:24 --> Loader Class Initialized
INFO - 2018-02-21 10:23:24 --> Helper loaded: url_helper
INFO - 2018-02-21 10:23:24 --> Helper loaded: file_helper
INFO - 2018-02-21 10:23:24 --> Helper loaded: email_helper
INFO - 2018-02-21 10:23:24 --> Helper loaded: common_helper
INFO - 2018-02-21 10:23:24 --> Database Driver Class Initialized
DEBUG - 2018-02-21 10:23:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-21 10:23:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-21 10:23:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-21 10:23:24 --> Pagination Class Initialized
INFO - 2018-02-21 10:23:24 --> Helper loaded: form_helper
INFO - 2018-02-21 10:23:24 --> Form Validation Class Initialized
INFO - 2018-02-21 10:23:24 --> Model Class Initialized
INFO - 2018-02-21 10:23:24 --> Controller Class Initialized
INFO - 2018-02-21 10:23:24 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-21 10:23:24 --> Model Class Initialized
INFO - 2018-02-21 10:23:24 --> Model Class Initialized
INFO - 2018-02-21 10:23:24 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-21 10:23:24 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-21 10:23:24 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-21 10:23:24 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-21 10:23:24 --> File loaded: /var/www/html/project/radio/application/views/subcategory/add_edit.php
INFO - 2018-02-21 10:23:24 --> Final output sent to browser
DEBUG - 2018-02-21 10:23:24 --> Total execution time: 0.0052
INFO - 2018-02-21 10:23:52 --> Config Class Initialized
INFO - 2018-02-21 10:23:52 --> Hooks Class Initialized
DEBUG - 2018-02-21 10:23:52 --> UTF-8 Support Enabled
INFO - 2018-02-21 10:23:52 --> Utf8 Class Initialized
INFO - 2018-02-21 10:23:52 --> URI Class Initialized
INFO - 2018-02-21 10:23:52 --> Router Class Initialized
INFO - 2018-02-21 10:23:52 --> Output Class Initialized
INFO - 2018-02-21 10:23:52 --> Security Class Initialized
DEBUG - 2018-02-21 10:23:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-21 10:23:52 --> Input Class Initialized
INFO - 2018-02-21 10:23:52 --> Language Class Initialized
INFO - 2018-02-21 10:23:52 --> Loader Class Initialized
INFO - 2018-02-21 10:23:52 --> Helper loaded: url_helper
INFO - 2018-02-21 10:23:52 --> Helper loaded: file_helper
INFO - 2018-02-21 10:23:52 --> Helper loaded: email_helper
INFO - 2018-02-21 10:23:52 --> Helper loaded: common_helper
INFO - 2018-02-21 10:23:52 --> Database Driver Class Initialized
DEBUG - 2018-02-21 10:23:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-21 10:23:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-21 10:23:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-21 10:23:52 --> Pagination Class Initialized
INFO - 2018-02-21 10:23:52 --> Helper loaded: form_helper
INFO - 2018-02-21 10:23:52 --> Form Validation Class Initialized
INFO - 2018-02-21 10:23:52 --> Model Class Initialized
INFO - 2018-02-21 10:23:52 --> Controller Class Initialized
INFO - 2018-02-21 10:23:52 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-21 10:23:52 --> Model Class Initialized
INFO - 2018-02-21 10:23:52 --> Model Class Initialized
INFO - 2018-02-21 10:23:52 --> Config Class Initialized
INFO - 2018-02-21 10:23:52 --> Hooks Class Initialized
DEBUG - 2018-02-21 10:23:52 --> UTF-8 Support Enabled
INFO - 2018-02-21 10:23:52 --> Utf8 Class Initialized
INFO - 2018-02-21 10:23:52 --> URI Class Initialized
INFO - 2018-02-21 10:23:52 --> Router Class Initialized
INFO - 2018-02-21 10:23:52 --> Output Class Initialized
INFO - 2018-02-21 10:23:52 --> Security Class Initialized
DEBUG - 2018-02-21 10:23:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-21 10:23:52 --> Input Class Initialized
INFO - 2018-02-21 10:23:52 --> Language Class Initialized
INFO - 2018-02-21 10:23:52 --> Loader Class Initialized
INFO - 2018-02-21 10:23:52 --> Helper loaded: url_helper
INFO - 2018-02-21 10:23:52 --> Helper loaded: file_helper
INFO - 2018-02-21 10:23:52 --> Helper loaded: email_helper
INFO - 2018-02-21 10:23:52 --> Helper loaded: common_helper
INFO - 2018-02-21 10:23:52 --> Database Driver Class Initialized
DEBUG - 2018-02-21 10:23:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-21 10:23:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-21 10:23:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-21 10:23:52 --> Pagination Class Initialized
INFO - 2018-02-21 10:23:52 --> Helper loaded: form_helper
INFO - 2018-02-21 10:23:52 --> Form Validation Class Initialized
INFO - 2018-02-21 10:23:52 --> Model Class Initialized
INFO - 2018-02-21 10:23:52 --> Controller Class Initialized
INFO - 2018-02-21 10:23:52 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-21 10:23:52 --> Model Class Initialized
INFO - 2018-02-21 10:23:52 --> Model Class Initialized
DEBUG - 2018-02-21 10:23:52 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-21 10:23:52 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-02-21 10:23:52 --> Config Class Initialized
INFO - 2018-02-21 10:23:52 --> Hooks Class Initialized
DEBUG - 2018-02-21 10:23:52 --> UTF-8 Support Enabled
INFO - 2018-02-21 10:23:52 --> Utf8 Class Initialized
INFO - 2018-02-21 10:23:52 --> URI Class Initialized
INFO - 2018-02-21 10:23:52 --> Router Class Initialized
INFO - 2018-02-21 10:23:52 --> Output Class Initialized
INFO - 2018-02-21 10:23:52 --> Security Class Initialized
DEBUG - 2018-02-21 10:23:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-21 10:23:52 --> Input Class Initialized
INFO - 2018-02-21 10:23:52 --> Language Class Initialized
INFO - 2018-02-21 10:23:52 --> Loader Class Initialized
INFO - 2018-02-21 10:23:52 --> Helper loaded: url_helper
INFO - 2018-02-21 10:23:52 --> Helper loaded: file_helper
INFO - 2018-02-21 10:23:52 --> Helper loaded: email_helper
INFO - 2018-02-21 10:23:52 --> Helper loaded: common_helper
INFO - 2018-02-21 10:23:52 --> Database Driver Class Initialized
DEBUG - 2018-02-21 10:23:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-21 10:23:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-21 10:23:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-21 10:23:52 --> Pagination Class Initialized
INFO - 2018-02-21 10:23:52 --> Helper loaded: form_helper
INFO - 2018-02-21 10:23:52 --> Form Validation Class Initialized
INFO - 2018-02-21 10:23:52 --> Model Class Initialized
INFO - 2018-02-21 10:23:52 --> Controller Class Initialized
INFO - 2018-02-21 10:23:52 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-21 10:23:52 --> Model Class Initialized
INFO - 2018-02-21 10:23:52 --> Model Class Initialized
INFO - 2018-02-21 10:23:52 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-21 10:23:52 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-21 10:23:52 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-21 10:23:52 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-21 10:23:52 --> File loaded: /var/www/html/project/radio/application/views/subcategory/index.php
INFO - 2018-02-21 10:23:52 --> Final output sent to browser
DEBUG - 2018-02-21 10:23:52 --> Total execution time: 0.0063
INFO - 2018-02-21 10:24:02 --> Config Class Initialized
INFO - 2018-02-21 10:24:02 --> Hooks Class Initialized
DEBUG - 2018-02-21 10:24:02 --> UTF-8 Support Enabled
INFO - 2018-02-21 10:24:02 --> Utf8 Class Initialized
INFO - 2018-02-21 10:24:02 --> URI Class Initialized
INFO - 2018-02-21 10:24:02 --> Router Class Initialized
INFO - 2018-02-21 10:24:02 --> Output Class Initialized
INFO - 2018-02-21 10:24:02 --> Security Class Initialized
DEBUG - 2018-02-21 10:24:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-21 10:24:02 --> Input Class Initialized
INFO - 2018-02-21 10:24:02 --> Language Class Initialized
INFO - 2018-02-21 10:24:02 --> Loader Class Initialized
INFO - 2018-02-21 10:24:02 --> Helper loaded: url_helper
INFO - 2018-02-21 10:24:02 --> Helper loaded: file_helper
INFO - 2018-02-21 10:24:02 --> Helper loaded: email_helper
INFO - 2018-02-21 10:24:02 --> Helper loaded: common_helper
INFO - 2018-02-21 10:24:02 --> Database Driver Class Initialized
DEBUG - 2018-02-21 10:24:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-21 10:24:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-21 10:24:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-21 10:24:02 --> Pagination Class Initialized
INFO - 2018-02-21 10:24:02 --> Helper loaded: form_helper
INFO - 2018-02-21 10:24:02 --> Form Validation Class Initialized
INFO - 2018-02-21 10:24:02 --> Model Class Initialized
INFO - 2018-02-21 10:24:02 --> Controller Class Initialized
INFO - 2018-02-21 10:24:02 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-21 10:24:02 --> Model Class Initialized
INFO - 2018-02-21 10:24:02 --> Model Class Initialized
INFO - 2018-02-21 10:24:02 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-21 10:24:02 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-21 10:24:02 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-21 10:24:02 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-21 10:24:02 --> File loaded: /var/www/html/project/radio/application/views/subcategory/add_edit.php
INFO - 2018-02-21 10:24:02 --> Final output sent to browser
DEBUG - 2018-02-21 10:24:02 --> Total execution time: 0.0095
INFO - 2018-02-21 10:24:10 --> Config Class Initialized
INFO - 2018-02-21 10:24:10 --> Hooks Class Initialized
DEBUG - 2018-02-21 10:24:10 --> UTF-8 Support Enabled
INFO - 2018-02-21 10:24:10 --> Utf8 Class Initialized
INFO - 2018-02-21 10:24:10 --> URI Class Initialized
INFO - 2018-02-21 10:24:10 --> Router Class Initialized
INFO - 2018-02-21 10:24:10 --> Output Class Initialized
INFO - 2018-02-21 10:24:10 --> Security Class Initialized
DEBUG - 2018-02-21 10:24:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-21 10:24:10 --> Input Class Initialized
INFO - 2018-02-21 10:24:10 --> Language Class Initialized
INFO - 2018-02-21 10:24:10 --> Loader Class Initialized
INFO - 2018-02-21 10:24:10 --> Helper loaded: url_helper
INFO - 2018-02-21 10:24:10 --> Helper loaded: file_helper
INFO - 2018-02-21 10:24:10 --> Helper loaded: email_helper
INFO - 2018-02-21 10:24:10 --> Helper loaded: common_helper
INFO - 2018-02-21 10:24:10 --> Database Driver Class Initialized
DEBUG - 2018-02-21 10:24:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-21 10:24:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-21 10:24:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-21 10:24:10 --> Pagination Class Initialized
INFO - 2018-02-21 10:24:10 --> Helper loaded: form_helper
INFO - 2018-02-21 10:24:10 --> Form Validation Class Initialized
INFO - 2018-02-21 10:24:10 --> Model Class Initialized
INFO - 2018-02-21 10:24:10 --> Controller Class Initialized
INFO - 2018-02-21 10:24:10 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-21 10:24:10 --> Model Class Initialized
INFO - 2018-02-21 10:24:10 --> Model Class Initialized
INFO - 2018-02-21 10:24:10 --> Config Class Initialized
INFO - 2018-02-21 10:24:10 --> Hooks Class Initialized
DEBUG - 2018-02-21 10:24:10 --> UTF-8 Support Enabled
INFO - 2018-02-21 10:24:10 --> Utf8 Class Initialized
INFO - 2018-02-21 10:24:10 --> URI Class Initialized
INFO - 2018-02-21 10:24:10 --> Router Class Initialized
INFO - 2018-02-21 10:24:10 --> Output Class Initialized
INFO - 2018-02-21 10:24:10 --> Security Class Initialized
DEBUG - 2018-02-21 10:24:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-21 10:24:10 --> Input Class Initialized
INFO - 2018-02-21 10:24:10 --> Language Class Initialized
INFO - 2018-02-21 10:24:10 --> Loader Class Initialized
INFO - 2018-02-21 10:24:10 --> Helper loaded: url_helper
INFO - 2018-02-21 10:24:10 --> Helper loaded: file_helper
INFO - 2018-02-21 10:24:10 --> Helper loaded: email_helper
INFO - 2018-02-21 10:24:10 --> Helper loaded: common_helper
INFO - 2018-02-21 10:24:10 --> Database Driver Class Initialized
DEBUG - 2018-02-21 10:24:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-21 10:24:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-21 10:24:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-21 10:24:10 --> Pagination Class Initialized
INFO - 2018-02-21 10:24:10 --> Helper loaded: form_helper
INFO - 2018-02-21 10:24:10 --> Form Validation Class Initialized
INFO - 2018-02-21 10:24:10 --> Model Class Initialized
INFO - 2018-02-21 10:24:10 --> Controller Class Initialized
INFO - 2018-02-21 10:24:10 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-21 10:24:10 --> Model Class Initialized
INFO - 2018-02-21 10:24:10 --> Model Class Initialized
DEBUG - 2018-02-21 10:24:10 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-21 10:24:10 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-02-21 10:24:10 --> Config Class Initialized
INFO - 2018-02-21 10:24:10 --> Hooks Class Initialized
DEBUG - 2018-02-21 10:24:10 --> UTF-8 Support Enabled
INFO - 2018-02-21 10:24:10 --> Utf8 Class Initialized
INFO - 2018-02-21 10:24:10 --> URI Class Initialized
INFO - 2018-02-21 10:24:10 --> Router Class Initialized
INFO - 2018-02-21 10:24:10 --> Output Class Initialized
INFO - 2018-02-21 10:24:10 --> Security Class Initialized
DEBUG - 2018-02-21 10:24:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-21 10:24:10 --> Input Class Initialized
INFO - 2018-02-21 10:24:10 --> Language Class Initialized
INFO - 2018-02-21 10:24:10 --> Loader Class Initialized
INFO - 2018-02-21 10:24:10 --> Helper loaded: url_helper
INFO - 2018-02-21 10:24:10 --> Helper loaded: file_helper
INFO - 2018-02-21 10:24:10 --> Helper loaded: email_helper
INFO - 2018-02-21 10:24:10 --> Helper loaded: common_helper
INFO - 2018-02-21 10:24:10 --> Database Driver Class Initialized
DEBUG - 2018-02-21 10:24:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-21 10:24:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-21 10:24:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-21 10:24:10 --> Pagination Class Initialized
INFO - 2018-02-21 10:24:10 --> Helper loaded: form_helper
INFO - 2018-02-21 10:24:10 --> Form Validation Class Initialized
INFO - 2018-02-21 10:24:10 --> Model Class Initialized
INFO - 2018-02-21 10:24:10 --> Controller Class Initialized
INFO - 2018-02-21 10:24:10 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-21 10:24:10 --> Model Class Initialized
INFO - 2018-02-21 10:24:10 --> Model Class Initialized
INFO - 2018-02-21 10:24:10 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-21 10:24:10 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-21 10:24:10 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-21 10:24:10 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-21 10:24:10 --> File loaded: /var/www/html/project/radio/application/views/subcategory/index.php
INFO - 2018-02-21 10:24:10 --> Final output sent to browser
DEBUG - 2018-02-21 10:24:10 --> Total execution time: 0.0066
INFO - 2018-02-21 10:24:18 --> Config Class Initialized
INFO - 2018-02-21 10:24:18 --> Hooks Class Initialized
DEBUG - 2018-02-21 10:24:18 --> UTF-8 Support Enabled
INFO - 2018-02-21 10:24:18 --> Utf8 Class Initialized
INFO - 2018-02-21 10:24:18 --> URI Class Initialized
INFO - 2018-02-21 10:24:18 --> Router Class Initialized
INFO - 2018-02-21 10:24:18 --> Output Class Initialized
INFO - 2018-02-21 10:24:18 --> Security Class Initialized
DEBUG - 2018-02-21 10:24:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-21 10:24:18 --> Input Class Initialized
INFO - 2018-02-21 10:24:18 --> Language Class Initialized
INFO - 2018-02-21 10:24:18 --> Loader Class Initialized
INFO - 2018-02-21 10:24:18 --> Helper loaded: url_helper
INFO - 2018-02-21 10:24:18 --> Helper loaded: file_helper
INFO - 2018-02-21 10:24:18 --> Helper loaded: email_helper
INFO - 2018-02-21 10:24:18 --> Helper loaded: common_helper
INFO - 2018-02-21 10:24:18 --> Database Driver Class Initialized
DEBUG - 2018-02-21 10:24:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-21 10:24:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-21 10:24:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-21 10:24:18 --> Pagination Class Initialized
INFO - 2018-02-21 10:24:18 --> Helper loaded: form_helper
INFO - 2018-02-21 10:24:18 --> Form Validation Class Initialized
INFO - 2018-02-21 10:24:18 --> Model Class Initialized
INFO - 2018-02-21 10:24:18 --> Controller Class Initialized
INFO - 2018-02-21 10:24:18 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-21 10:24:18 --> Model Class Initialized
INFO - 2018-02-21 10:24:18 --> Model Class Initialized
INFO - 2018-02-21 10:24:18 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-21 10:24:18 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-21 10:24:18 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-21 10:24:18 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-21 10:24:18 --> File loaded: /var/www/html/project/radio/application/views/subcategory/add_edit.php
INFO - 2018-02-21 10:24:18 --> Final output sent to browser
DEBUG - 2018-02-21 10:24:18 --> Total execution time: 0.0059
INFO - 2018-02-21 10:24:34 --> Config Class Initialized
INFO - 2018-02-21 10:24:34 --> Hooks Class Initialized
DEBUG - 2018-02-21 10:24:34 --> UTF-8 Support Enabled
INFO - 2018-02-21 10:24:34 --> Utf8 Class Initialized
INFO - 2018-02-21 10:24:34 --> URI Class Initialized
INFO - 2018-02-21 10:24:34 --> Router Class Initialized
INFO - 2018-02-21 10:24:34 --> Output Class Initialized
INFO - 2018-02-21 10:24:34 --> Security Class Initialized
DEBUG - 2018-02-21 10:24:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-21 10:24:34 --> Input Class Initialized
INFO - 2018-02-21 10:24:34 --> Language Class Initialized
INFO - 2018-02-21 10:24:34 --> Loader Class Initialized
INFO - 2018-02-21 10:24:34 --> Helper loaded: url_helper
INFO - 2018-02-21 10:24:34 --> Helper loaded: file_helper
INFO - 2018-02-21 10:24:34 --> Helper loaded: email_helper
INFO - 2018-02-21 10:24:34 --> Helper loaded: common_helper
INFO - 2018-02-21 10:24:34 --> Database Driver Class Initialized
DEBUG - 2018-02-21 10:24:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-21 10:24:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-21 10:24:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-21 10:24:34 --> Pagination Class Initialized
INFO - 2018-02-21 10:24:35 --> Helper loaded: form_helper
INFO - 2018-02-21 10:24:35 --> Form Validation Class Initialized
INFO - 2018-02-21 10:24:35 --> Model Class Initialized
INFO - 2018-02-21 10:24:35 --> Controller Class Initialized
INFO - 2018-02-21 10:24:35 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-21 10:24:35 --> Model Class Initialized
INFO - 2018-02-21 10:24:35 --> Model Class Initialized
INFO - 2018-02-21 10:24:35 --> Config Class Initialized
INFO - 2018-02-21 10:24:35 --> Hooks Class Initialized
DEBUG - 2018-02-21 10:24:35 --> UTF-8 Support Enabled
INFO - 2018-02-21 10:24:35 --> Utf8 Class Initialized
INFO - 2018-02-21 10:24:35 --> URI Class Initialized
INFO - 2018-02-21 10:24:35 --> Router Class Initialized
INFO - 2018-02-21 10:24:35 --> Output Class Initialized
INFO - 2018-02-21 10:24:35 --> Security Class Initialized
DEBUG - 2018-02-21 10:24:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-21 10:24:35 --> Input Class Initialized
INFO - 2018-02-21 10:24:35 --> Language Class Initialized
INFO - 2018-02-21 10:24:35 --> Loader Class Initialized
INFO - 2018-02-21 10:24:35 --> Helper loaded: url_helper
INFO - 2018-02-21 10:24:35 --> Helper loaded: file_helper
INFO - 2018-02-21 10:24:35 --> Helper loaded: email_helper
INFO - 2018-02-21 10:24:35 --> Helper loaded: common_helper
INFO - 2018-02-21 10:24:35 --> Database Driver Class Initialized
DEBUG - 2018-02-21 10:24:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-21 10:24:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-21 10:24:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-21 10:24:35 --> Pagination Class Initialized
INFO - 2018-02-21 10:24:35 --> Helper loaded: form_helper
INFO - 2018-02-21 10:24:35 --> Form Validation Class Initialized
INFO - 2018-02-21 10:24:35 --> Model Class Initialized
INFO - 2018-02-21 10:24:35 --> Controller Class Initialized
INFO - 2018-02-21 10:24:35 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-21 10:24:35 --> Model Class Initialized
INFO - 2018-02-21 10:24:35 --> Model Class Initialized
DEBUG - 2018-02-21 10:24:35 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-21 10:24:35 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-02-21 10:24:35 --> Config Class Initialized
INFO - 2018-02-21 10:24:35 --> Hooks Class Initialized
DEBUG - 2018-02-21 10:24:35 --> UTF-8 Support Enabled
INFO - 2018-02-21 10:24:35 --> Utf8 Class Initialized
INFO - 2018-02-21 10:24:35 --> URI Class Initialized
INFO - 2018-02-21 10:24:35 --> Router Class Initialized
INFO - 2018-02-21 10:24:35 --> Output Class Initialized
INFO - 2018-02-21 10:24:35 --> Security Class Initialized
DEBUG - 2018-02-21 10:24:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-21 10:24:35 --> Input Class Initialized
INFO - 2018-02-21 10:24:35 --> Language Class Initialized
INFO - 2018-02-21 10:24:35 --> Loader Class Initialized
INFO - 2018-02-21 10:24:35 --> Helper loaded: url_helper
INFO - 2018-02-21 10:24:35 --> Helper loaded: file_helper
INFO - 2018-02-21 10:24:35 --> Helper loaded: email_helper
INFO - 2018-02-21 10:24:35 --> Helper loaded: common_helper
INFO - 2018-02-21 10:24:35 --> Database Driver Class Initialized
DEBUG - 2018-02-21 10:24:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-21 10:24:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-21 10:24:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-21 10:24:35 --> Pagination Class Initialized
INFO - 2018-02-21 10:24:35 --> Helper loaded: form_helper
INFO - 2018-02-21 10:24:35 --> Form Validation Class Initialized
INFO - 2018-02-21 10:24:35 --> Model Class Initialized
INFO - 2018-02-21 10:24:35 --> Controller Class Initialized
INFO - 2018-02-21 10:24:35 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-21 10:24:35 --> Model Class Initialized
INFO - 2018-02-21 10:24:35 --> Model Class Initialized
INFO - 2018-02-21 10:24:35 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-21 10:24:35 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-21 10:24:35 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-21 10:24:35 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-21 10:24:35 --> File loaded: /var/www/html/project/radio/application/views/subcategory/index.php
INFO - 2018-02-21 10:24:35 --> Final output sent to browser
DEBUG - 2018-02-21 10:24:35 --> Total execution time: 0.0043
INFO - 2018-02-21 10:24:43 --> Config Class Initialized
INFO - 2018-02-21 10:24:43 --> Hooks Class Initialized
DEBUG - 2018-02-21 10:24:43 --> UTF-8 Support Enabled
INFO - 2018-02-21 10:24:43 --> Utf8 Class Initialized
INFO - 2018-02-21 10:24:43 --> URI Class Initialized
INFO - 2018-02-21 10:24:43 --> Router Class Initialized
INFO - 2018-02-21 10:24:43 --> Output Class Initialized
INFO - 2018-02-21 10:24:43 --> Security Class Initialized
DEBUG - 2018-02-21 10:24:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-21 10:24:43 --> Input Class Initialized
INFO - 2018-02-21 10:24:43 --> Language Class Initialized
INFO - 2018-02-21 10:24:43 --> Loader Class Initialized
INFO - 2018-02-21 10:24:43 --> Helper loaded: url_helper
INFO - 2018-02-21 10:24:43 --> Helper loaded: file_helper
INFO - 2018-02-21 10:24:43 --> Helper loaded: email_helper
INFO - 2018-02-21 10:24:43 --> Helper loaded: common_helper
INFO - 2018-02-21 10:24:43 --> Database Driver Class Initialized
DEBUG - 2018-02-21 10:24:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-21 10:24:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-21 10:24:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-21 10:24:43 --> Pagination Class Initialized
INFO - 2018-02-21 10:24:43 --> Helper loaded: form_helper
INFO - 2018-02-21 10:24:43 --> Form Validation Class Initialized
INFO - 2018-02-21 10:24:43 --> Model Class Initialized
INFO - 2018-02-21 10:24:43 --> Controller Class Initialized
INFO - 2018-02-21 10:24:43 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-21 10:24:43 --> Model Class Initialized
INFO - 2018-02-21 10:24:43 --> Model Class Initialized
INFO - 2018-02-21 10:24:43 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-21 10:24:43 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-21 10:24:43 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-21 10:24:43 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-21 10:24:43 --> File loaded: /var/www/html/project/radio/application/views/subcategory/add_edit.php
INFO - 2018-02-21 10:24:43 --> Final output sent to browser
DEBUG - 2018-02-21 10:24:43 --> Total execution time: 0.0060
INFO - 2018-02-21 10:24:56 --> Config Class Initialized
INFO - 2018-02-21 10:24:56 --> Hooks Class Initialized
DEBUG - 2018-02-21 10:24:56 --> UTF-8 Support Enabled
INFO - 2018-02-21 10:24:56 --> Utf8 Class Initialized
INFO - 2018-02-21 10:24:56 --> URI Class Initialized
INFO - 2018-02-21 10:24:56 --> Router Class Initialized
INFO - 2018-02-21 10:24:56 --> Output Class Initialized
INFO - 2018-02-21 10:24:56 --> Security Class Initialized
DEBUG - 2018-02-21 10:24:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-21 10:24:56 --> Input Class Initialized
INFO - 2018-02-21 10:24:56 --> Language Class Initialized
INFO - 2018-02-21 10:24:56 --> Loader Class Initialized
INFO - 2018-02-21 10:24:56 --> Helper loaded: url_helper
INFO - 2018-02-21 10:24:56 --> Helper loaded: file_helper
INFO - 2018-02-21 10:24:56 --> Helper loaded: email_helper
INFO - 2018-02-21 10:24:56 --> Helper loaded: common_helper
INFO - 2018-02-21 10:24:56 --> Database Driver Class Initialized
DEBUG - 2018-02-21 10:24:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-21 10:24:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-21 10:24:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-21 10:24:56 --> Pagination Class Initialized
INFO - 2018-02-21 10:24:56 --> Helper loaded: form_helper
INFO - 2018-02-21 10:24:56 --> Form Validation Class Initialized
INFO - 2018-02-21 10:24:56 --> Model Class Initialized
INFO - 2018-02-21 10:24:56 --> Controller Class Initialized
INFO - 2018-02-21 10:24:56 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-21 10:24:56 --> Model Class Initialized
INFO - 2018-02-21 10:24:56 --> Model Class Initialized
INFO - 2018-02-21 10:24:56 --> Config Class Initialized
INFO - 2018-02-21 10:24:56 --> Hooks Class Initialized
DEBUG - 2018-02-21 10:24:56 --> UTF-8 Support Enabled
INFO - 2018-02-21 10:24:56 --> Utf8 Class Initialized
INFO - 2018-02-21 10:24:56 --> URI Class Initialized
INFO - 2018-02-21 10:24:56 --> Router Class Initialized
INFO - 2018-02-21 10:24:56 --> Output Class Initialized
INFO - 2018-02-21 10:24:56 --> Security Class Initialized
DEBUG - 2018-02-21 10:24:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-21 10:24:56 --> Input Class Initialized
INFO - 2018-02-21 10:24:56 --> Language Class Initialized
INFO - 2018-02-21 10:24:56 --> Loader Class Initialized
INFO - 2018-02-21 10:24:56 --> Helper loaded: url_helper
INFO - 2018-02-21 10:24:56 --> Helper loaded: file_helper
INFO - 2018-02-21 10:24:56 --> Helper loaded: email_helper
INFO - 2018-02-21 10:24:56 --> Helper loaded: common_helper
INFO - 2018-02-21 10:24:56 --> Database Driver Class Initialized
DEBUG - 2018-02-21 10:24:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-21 10:24:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-21 10:24:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-21 10:24:56 --> Pagination Class Initialized
INFO - 2018-02-21 10:24:56 --> Helper loaded: form_helper
INFO - 2018-02-21 10:24:56 --> Form Validation Class Initialized
INFO - 2018-02-21 10:24:56 --> Model Class Initialized
INFO - 2018-02-21 10:24:56 --> Controller Class Initialized
INFO - 2018-02-21 10:24:56 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-21 10:24:56 --> Model Class Initialized
INFO - 2018-02-21 10:24:56 --> Model Class Initialized
DEBUG - 2018-02-21 10:24:56 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-21 10:24:56 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-02-21 10:24:56 --> Config Class Initialized
INFO - 2018-02-21 10:24:56 --> Hooks Class Initialized
DEBUG - 2018-02-21 10:24:56 --> UTF-8 Support Enabled
INFO - 2018-02-21 10:24:56 --> Utf8 Class Initialized
INFO - 2018-02-21 10:24:56 --> URI Class Initialized
INFO - 2018-02-21 10:24:56 --> Router Class Initialized
INFO - 2018-02-21 10:24:56 --> Output Class Initialized
INFO - 2018-02-21 10:24:56 --> Security Class Initialized
DEBUG - 2018-02-21 10:24:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-21 10:24:56 --> Input Class Initialized
INFO - 2018-02-21 10:24:56 --> Language Class Initialized
INFO - 2018-02-21 10:24:56 --> Loader Class Initialized
INFO - 2018-02-21 10:24:56 --> Helper loaded: url_helper
INFO - 2018-02-21 10:24:56 --> Helper loaded: file_helper
INFO - 2018-02-21 10:24:56 --> Helper loaded: email_helper
INFO - 2018-02-21 10:24:56 --> Helper loaded: common_helper
INFO - 2018-02-21 10:24:56 --> Database Driver Class Initialized
DEBUG - 2018-02-21 10:24:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-21 10:24:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-21 10:24:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-21 10:24:56 --> Pagination Class Initialized
INFO - 2018-02-21 10:24:56 --> Helper loaded: form_helper
INFO - 2018-02-21 10:24:56 --> Form Validation Class Initialized
INFO - 2018-02-21 10:24:56 --> Model Class Initialized
INFO - 2018-02-21 10:24:56 --> Controller Class Initialized
INFO - 2018-02-21 10:24:56 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-21 10:24:56 --> Model Class Initialized
INFO - 2018-02-21 10:24:56 --> Model Class Initialized
INFO - 2018-02-21 10:24:56 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-21 10:24:56 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-21 10:24:56 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-21 10:24:56 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-21 10:24:56 --> File loaded: /var/www/html/project/radio/application/views/subcategory/index.php
INFO - 2018-02-21 10:24:56 --> Final output sent to browser
DEBUG - 2018-02-21 10:24:56 --> Total execution time: 0.0048
INFO - 2018-02-21 10:25:05 --> Config Class Initialized
INFO - 2018-02-21 10:25:05 --> Hooks Class Initialized
DEBUG - 2018-02-21 10:25:05 --> UTF-8 Support Enabled
INFO - 2018-02-21 10:25:05 --> Utf8 Class Initialized
INFO - 2018-02-21 10:25:05 --> URI Class Initialized
INFO - 2018-02-21 10:25:05 --> Router Class Initialized
INFO - 2018-02-21 10:25:05 --> Output Class Initialized
INFO - 2018-02-21 10:25:05 --> Security Class Initialized
DEBUG - 2018-02-21 10:25:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-21 10:25:05 --> Input Class Initialized
INFO - 2018-02-21 10:25:05 --> Language Class Initialized
INFO - 2018-02-21 10:25:05 --> Loader Class Initialized
INFO - 2018-02-21 10:25:05 --> Helper loaded: url_helper
INFO - 2018-02-21 10:25:05 --> Helper loaded: file_helper
INFO - 2018-02-21 10:25:05 --> Helper loaded: email_helper
INFO - 2018-02-21 10:25:05 --> Helper loaded: common_helper
INFO - 2018-02-21 10:25:05 --> Database Driver Class Initialized
DEBUG - 2018-02-21 10:25:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-21 10:25:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-21 10:25:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-21 10:25:05 --> Pagination Class Initialized
INFO - 2018-02-21 10:25:05 --> Helper loaded: form_helper
INFO - 2018-02-21 10:25:05 --> Form Validation Class Initialized
INFO - 2018-02-21 10:25:05 --> Model Class Initialized
INFO - 2018-02-21 10:25:05 --> Controller Class Initialized
DEBUG - 2018-02-21 10:25:05 --> Config file loaded: /var/www/html/project/radio/application/config/rest.php
INFO - 2018-02-21 10:25:05 --> Helper loaded: inflector_helper
INFO - 2018-02-21 10:25:05 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-21 10:25:05 --> Model Class Initialized
INFO - 2018-02-21 10:25:05 --> Model Class Initialized
INFO - 2018-02-21 10:25:05 --> Model Class Initialized
INFO - 2018-02-21 10:25:05 --> Final output sent to browser
DEBUG - 2018-02-21 10:25:05 --> Total execution time: 0.0068
INFO - 2018-02-21 10:25:17 --> Config Class Initialized
INFO - 2018-02-21 10:25:17 --> Hooks Class Initialized
DEBUG - 2018-02-21 10:25:17 --> UTF-8 Support Enabled
INFO - 2018-02-21 10:25:17 --> Utf8 Class Initialized
INFO - 2018-02-21 10:25:17 --> URI Class Initialized
INFO - 2018-02-21 10:25:17 --> Router Class Initialized
INFO - 2018-02-21 10:25:17 --> Output Class Initialized
INFO - 2018-02-21 10:25:17 --> Security Class Initialized
DEBUG - 2018-02-21 10:25:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-21 10:25:17 --> Input Class Initialized
INFO - 2018-02-21 10:25:17 --> Language Class Initialized
INFO - 2018-02-21 10:25:17 --> Loader Class Initialized
INFO - 2018-02-21 10:25:17 --> Helper loaded: url_helper
INFO - 2018-02-21 10:25:17 --> Helper loaded: file_helper
INFO - 2018-02-21 10:25:17 --> Helper loaded: email_helper
INFO - 2018-02-21 10:25:17 --> Helper loaded: common_helper
INFO - 2018-02-21 10:25:17 --> Database Driver Class Initialized
DEBUG - 2018-02-21 10:25:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-21 10:25:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-21 10:25:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-21 10:25:17 --> Pagination Class Initialized
INFO - 2018-02-21 10:25:17 --> Helper loaded: form_helper
INFO - 2018-02-21 10:25:17 --> Form Validation Class Initialized
INFO - 2018-02-21 10:25:17 --> Model Class Initialized
INFO - 2018-02-21 10:25:17 --> Controller Class Initialized
DEBUG - 2018-02-21 10:25:17 --> Config file loaded: /var/www/html/project/radio/application/config/rest.php
INFO - 2018-02-21 10:25:17 --> Helper loaded: inflector_helper
INFO - 2018-02-21 10:25:17 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-21 10:25:17 --> Model Class Initialized
INFO - 2018-02-21 10:25:17 --> Model Class Initialized
INFO - 2018-02-21 10:25:17 --> Model Class Initialized
INFO - 2018-02-21 10:25:17 --> Final output sent to browser
DEBUG - 2018-02-21 10:25:17 --> Total execution time: 0.0055
INFO - 2018-02-21 10:25:35 --> Config Class Initialized
INFO - 2018-02-21 10:25:35 --> Hooks Class Initialized
DEBUG - 2018-02-21 10:25:35 --> UTF-8 Support Enabled
INFO - 2018-02-21 10:25:35 --> Utf8 Class Initialized
INFO - 2018-02-21 10:25:35 --> URI Class Initialized
INFO - 2018-02-21 10:25:35 --> Router Class Initialized
INFO - 2018-02-21 10:25:35 --> Output Class Initialized
INFO - 2018-02-21 10:25:35 --> Security Class Initialized
DEBUG - 2018-02-21 10:25:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-21 10:25:35 --> Input Class Initialized
INFO - 2018-02-21 10:25:35 --> Language Class Initialized
INFO - 2018-02-21 10:25:35 --> Loader Class Initialized
INFO - 2018-02-21 10:25:35 --> Helper loaded: url_helper
INFO - 2018-02-21 10:25:35 --> Helper loaded: file_helper
INFO - 2018-02-21 10:25:35 --> Helper loaded: email_helper
INFO - 2018-02-21 10:25:35 --> Helper loaded: common_helper
INFO - 2018-02-21 10:25:35 --> Database Driver Class Initialized
DEBUG - 2018-02-21 10:25:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-21 10:25:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-21 10:25:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-21 10:25:35 --> Pagination Class Initialized
INFO - 2018-02-21 10:25:35 --> Helper loaded: form_helper
INFO - 2018-02-21 10:25:35 --> Form Validation Class Initialized
INFO - 2018-02-21 10:25:35 --> Model Class Initialized
INFO - 2018-02-21 10:25:35 --> Controller Class Initialized
DEBUG - 2018-02-21 10:25:35 --> Config file loaded: /var/www/html/project/radio/application/config/rest.php
INFO - 2018-02-21 10:25:35 --> Helper loaded: inflector_helper
INFO - 2018-02-21 10:25:35 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-21 10:25:35 --> Model Class Initialized
INFO - 2018-02-21 10:25:35 --> Model Class Initialized
INFO - 2018-02-21 10:25:35 --> Model Class Initialized
INFO - 2018-02-21 10:25:35 --> Final output sent to browser
DEBUG - 2018-02-21 10:25:35 --> Total execution time: 0.0074
INFO - 2018-02-21 10:29:57 --> Config Class Initialized
INFO - 2018-02-21 10:29:57 --> Hooks Class Initialized
DEBUG - 2018-02-21 10:29:57 --> UTF-8 Support Enabled
INFO - 2018-02-21 10:29:57 --> Utf8 Class Initialized
INFO - 2018-02-21 10:29:57 --> URI Class Initialized
INFO - 2018-02-21 10:29:57 --> Router Class Initialized
INFO - 2018-02-21 10:29:57 --> Output Class Initialized
INFO - 2018-02-21 10:29:57 --> Security Class Initialized
DEBUG - 2018-02-21 10:29:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-21 10:29:57 --> Input Class Initialized
INFO - 2018-02-21 10:29:57 --> Language Class Initialized
INFO - 2018-02-21 10:29:57 --> Loader Class Initialized
INFO - 2018-02-21 10:29:57 --> Helper loaded: url_helper
INFO - 2018-02-21 10:29:57 --> Helper loaded: file_helper
INFO - 2018-02-21 10:29:57 --> Helper loaded: email_helper
INFO - 2018-02-21 10:29:57 --> Helper loaded: common_helper
INFO - 2018-02-21 10:29:57 --> Database Driver Class Initialized
DEBUG - 2018-02-21 10:29:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-21 10:29:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-21 10:29:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-21 10:29:57 --> Pagination Class Initialized
INFO - 2018-02-21 10:29:57 --> Helper loaded: form_helper
INFO - 2018-02-21 10:29:57 --> Form Validation Class Initialized
INFO - 2018-02-21 10:29:57 --> Model Class Initialized
INFO - 2018-02-21 10:29:57 --> Controller Class Initialized
DEBUG - 2018-02-21 10:29:57 --> Config file loaded: /var/www/html/project/radio/application/config/rest.php
INFO - 2018-02-21 10:29:57 --> Helper loaded: inflector_helper
INFO - 2018-02-21 10:29:57 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-21 10:29:57 --> Model Class Initialized
INFO - 2018-02-21 10:29:57 --> Model Class Initialized
INFO - 2018-02-21 10:29:57 --> Model Class Initialized
INFO - 2018-02-21 10:29:57 --> Final output sent to browser
DEBUG - 2018-02-21 10:29:57 --> Total execution time: 0.0063
INFO - 2018-02-21 10:30:14 --> Config Class Initialized
INFO - 2018-02-21 10:30:14 --> Hooks Class Initialized
DEBUG - 2018-02-21 10:30:14 --> UTF-8 Support Enabled
INFO - 2018-02-21 10:30:14 --> Utf8 Class Initialized
INFO - 2018-02-21 10:30:14 --> URI Class Initialized
INFO - 2018-02-21 10:30:14 --> Router Class Initialized
INFO - 2018-02-21 10:30:14 --> Output Class Initialized
INFO - 2018-02-21 10:30:14 --> Security Class Initialized
DEBUG - 2018-02-21 10:30:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-21 10:30:14 --> Input Class Initialized
INFO - 2018-02-21 10:30:14 --> Language Class Initialized
INFO - 2018-02-21 10:30:14 --> Loader Class Initialized
INFO - 2018-02-21 10:30:14 --> Helper loaded: url_helper
INFO - 2018-02-21 10:30:14 --> Helper loaded: file_helper
INFO - 2018-02-21 10:30:14 --> Helper loaded: email_helper
INFO - 2018-02-21 10:30:14 --> Helper loaded: common_helper
INFO - 2018-02-21 10:30:14 --> Database Driver Class Initialized
DEBUG - 2018-02-21 10:30:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-21 10:30:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-21 10:30:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-21 10:30:14 --> Pagination Class Initialized
INFO - 2018-02-21 10:30:14 --> Helper loaded: form_helper
INFO - 2018-02-21 10:30:14 --> Form Validation Class Initialized
INFO - 2018-02-21 10:30:14 --> Model Class Initialized
INFO - 2018-02-21 10:30:14 --> Controller Class Initialized
DEBUG - 2018-02-21 10:30:14 --> Config file loaded: /var/www/html/project/radio/application/config/rest.php
INFO - 2018-02-21 10:30:14 --> Helper loaded: inflector_helper
INFO - 2018-02-21 10:30:14 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-21 10:30:14 --> Model Class Initialized
INFO - 2018-02-21 10:30:14 --> Model Class Initialized
INFO - 2018-02-21 10:30:14 --> Model Class Initialized
INFO - 2018-02-21 10:30:14 --> Final output sent to browser
DEBUG - 2018-02-21 10:30:14 --> Total execution time: 0.0073
INFO - 2018-02-21 10:34:46 --> Config Class Initialized
INFO - 2018-02-21 10:34:46 --> Hooks Class Initialized
DEBUG - 2018-02-21 10:34:46 --> UTF-8 Support Enabled
INFO - 2018-02-21 10:34:46 --> Utf8 Class Initialized
INFO - 2018-02-21 10:34:46 --> URI Class Initialized
INFO - 2018-02-21 10:34:46 --> Router Class Initialized
INFO - 2018-02-21 10:34:46 --> Output Class Initialized
INFO - 2018-02-21 10:34:46 --> Security Class Initialized
DEBUG - 2018-02-21 10:34:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-21 10:34:46 --> Input Class Initialized
INFO - 2018-02-21 10:34:46 --> Language Class Initialized
INFO - 2018-02-21 10:34:46 --> Loader Class Initialized
INFO - 2018-02-21 10:34:46 --> Helper loaded: url_helper
INFO - 2018-02-21 10:34:46 --> Helper loaded: file_helper
INFO - 2018-02-21 10:34:46 --> Helper loaded: email_helper
INFO - 2018-02-21 10:34:46 --> Helper loaded: common_helper
INFO - 2018-02-21 10:34:46 --> Database Driver Class Initialized
DEBUG - 2018-02-21 10:34:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-21 10:34:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-21 10:34:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-21 10:34:46 --> Pagination Class Initialized
INFO - 2018-02-21 10:34:46 --> Helper loaded: form_helper
INFO - 2018-02-21 10:34:46 --> Form Validation Class Initialized
INFO - 2018-02-21 10:34:46 --> Model Class Initialized
INFO - 2018-02-21 10:34:46 --> Controller Class Initialized
DEBUG - 2018-02-21 10:34:46 --> Config file loaded: /var/www/html/project/radio/application/config/rest.php
INFO - 2018-02-21 10:34:46 --> Helper loaded: inflector_helper
INFO - 2018-02-21 10:34:46 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-21 10:34:46 --> Model Class Initialized
INFO - 2018-02-21 10:34:46 --> Model Class Initialized
INFO - 2018-02-21 10:34:46 --> Model Class Initialized
INFO - 2018-02-21 10:34:46 --> Final output sent to browser
DEBUG - 2018-02-21 10:34:46 --> Total execution time: 0.0068
INFO - 2018-02-21 10:35:39 --> Config Class Initialized
INFO - 2018-02-21 10:35:39 --> Hooks Class Initialized
DEBUG - 2018-02-21 10:35:39 --> UTF-8 Support Enabled
INFO - 2018-02-21 10:35:39 --> Utf8 Class Initialized
INFO - 2018-02-21 10:35:39 --> URI Class Initialized
INFO - 2018-02-21 10:35:39 --> Router Class Initialized
INFO - 2018-02-21 10:35:39 --> Output Class Initialized
INFO - 2018-02-21 10:35:39 --> Security Class Initialized
DEBUG - 2018-02-21 10:35:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-21 10:35:39 --> Input Class Initialized
INFO - 2018-02-21 10:35:39 --> Language Class Initialized
INFO - 2018-02-21 10:35:39 --> Loader Class Initialized
INFO - 2018-02-21 10:35:39 --> Helper loaded: url_helper
INFO - 2018-02-21 10:35:39 --> Helper loaded: file_helper
INFO - 2018-02-21 10:35:39 --> Helper loaded: email_helper
INFO - 2018-02-21 10:35:39 --> Helper loaded: common_helper
INFO - 2018-02-21 10:35:39 --> Database Driver Class Initialized
DEBUG - 2018-02-21 10:35:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-21 10:35:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-21 10:35:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-21 10:35:39 --> Pagination Class Initialized
INFO - 2018-02-21 10:35:39 --> Helper loaded: form_helper
INFO - 2018-02-21 10:35:39 --> Form Validation Class Initialized
INFO - 2018-02-21 10:35:39 --> Model Class Initialized
INFO - 2018-02-21 10:35:39 --> Controller Class Initialized
DEBUG - 2018-02-21 10:35:39 --> Config file loaded: /var/www/html/project/radio/application/config/rest.php
INFO - 2018-02-21 10:35:39 --> Helper loaded: inflector_helper
INFO - 2018-02-21 10:35:39 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-21 10:35:39 --> Model Class Initialized
INFO - 2018-02-21 10:35:39 --> Model Class Initialized
INFO - 2018-02-21 10:35:39 --> Model Class Initialized
INFO - 2018-02-21 10:35:39 --> Final output sent to browser
DEBUG - 2018-02-21 10:35:39 --> Total execution time: 0.0070
INFO - 2018-02-21 10:36:53 --> Config Class Initialized
INFO - 2018-02-21 10:36:53 --> Hooks Class Initialized
DEBUG - 2018-02-21 10:36:53 --> UTF-8 Support Enabled
INFO - 2018-02-21 10:36:53 --> Utf8 Class Initialized
INFO - 2018-02-21 10:36:53 --> URI Class Initialized
INFO - 2018-02-21 10:36:53 --> Router Class Initialized
INFO - 2018-02-21 10:36:53 --> Output Class Initialized
INFO - 2018-02-21 10:36:53 --> Security Class Initialized
DEBUG - 2018-02-21 10:36:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-21 10:36:53 --> Input Class Initialized
INFO - 2018-02-21 10:36:53 --> Language Class Initialized
INFO - 2018-02-21 10:36:53 --> Loader Class Initialized
INFO - 2018-02-21 10:36:53 --> Helper loaded: url_helper
INFO - 2018-02-21 10:36:53 --> Helper loaded: file_helper
INFO - 2018-02-21 10:36:53 --> Helper loaded: email_helper
INFO - 2018-02-21 10:36:53 --> Helper loaded: common_helper
INFO - 2018-02-21 10:36:53 --> Database Driver Class Initialized
DEBUG - 2018-02-21 10:36:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-21 10:36:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-21 10:36:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-21 10:36:53 --> Pagination Class Initialized
INFO - 2018-02-21 10:36:53 --> Helper loaded: form_helper
INFO - 2018-02-21 10:36:53 --> Form Validation Class Initialized
INFO - 2018-02-21 10:36:53 --> Model Class Initialized
INFO - 2018-02-21 10:36:53 --> Controller Class Initialized
INFO - 2018-02-21 10:36:53 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-21 10:36:53 --> Model Class Initialized
INFO - 2018-02-21 10:36:53 --> Model Class Initialized
INFO - 2018-02-21 10:36:53 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-21 10:36:53 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-21 10:36:53 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-21 10:36:53 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-21 10:36:53 --> File loaded: /var/www/html/project/radio/application/views/subcategory/add_edit.php
INFO - 2018-02-21 10:36:53 --> Final output sent to browser
DEBUG - 2018-02-21 10:36:53 --> Total execution time: 0.0070
INFO - 2018-02-21 10:37:00 --> Config Class Initialized
INFO - 2018-02-21 10:37:00 --> Hooks Class Initialized
DEBUG - 2018-02-21 10:37:00 --> UTF-8 Support Enabled
INFO - 2018-02-21 10:37:00 --> Utf8 Class Initialized
INFO - 2018-02-21 10:37:00 --> URI Class Initialized
INFO - 2018-02-21 10:37:00 --> Router Class Initialized
INFO - 2018-02-21 10:37:00 --> Output Class Initialized
INFO - 2018-02-21 10:37:00 --> Security Class Initialized
DEBUG - 2018-02-21 10:37:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-21 10:37:00 --> Input Class Initialized
INFO - 2018-02-21 10:37:00 --> Language Class Initialized
INFO - 2018-02-21 10:37:00 --> Loader Class Initialized
INFO - 2018-02-21 10:37:00 --> Helper loaded: url_helper
INFO - 2018-02-21 10:37:00 --> Helper loaded: file_helper
INFO - 2018-02-21 10:37:00 --> Helper loaded: email_helper
INFO - 2018-02-21 10:37:00 --> Helper loaded: common_helper
INFO - 2018-02-21 10:37:00 --> Database Driver Class Initialized
DEBUG - 2018-02-21 10:37:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-21 10:37:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-21 10:37:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-21 10:37:00 --> Pagination Class Initialized
INFO - 2018-02-21 10:37:00 --> Helper loaded: form_helper
INFO - 2018-02-21 10:37:00 --> Form Validation Class Initialized
INFO - 2018-02-21 10:37:00 --> Model Class Initialized
INFO - 2018-02-21 10:37:00 --> Controller Class Initialized
INFO - 2018-02-21 10:37:00 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-21 10:37:00 --> Model Class Initialized
INFO - 2018-02-21 10:37:00 --> Model Class Initialized
INFO - 2018-02-21 10:37:00 --> Config Class Initialized
INFO - 2018-02-21 10:37:00 --> Hooks Class Initialized
DEBUG - 2018-02-21 10:37:00 --> UTF-8 Support Enabled
INFO - 2018-02-21 10:37:00 --> Utf8 Class Initialized
INFO - 2018-02-21 10:37:00 --> URI Class Initialized
INFO - 2018-02-21 10:37:00 --> Router Class Initialized
INFO - 2018-02-21 10:37:00 --> Output Class Initialized
INFO - 2018-02-21 10:37:00 --> Security Class Initialized
DEBUG - 2018-02-21 10:37:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-21 10:37:00 --> Input Class Initialized
INFO - 2018-02-21 10:37:00 --> Language Class Initialized
INFO - 2018-02-21 10:37:00 --> Loader Class Initialized
INFO - 2018-02-21 10:37:00 --> Helper loaded: url_helper
INFO - 2018-02-21 10:37:00 --> Helper loaded: file_helper
INFO - 2018-02-21 10:37:00 --> Helper loaded: email_helper
INFO - 2018-02-21 10:37:00 --> Helper loaded: common_helper
INFO - 2018-02-21 10:37:00 --> Database Driver Class Initialized
DEBUG - 2018-02-21 10:37:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-21 10:37:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-21 10:37:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-21 10:37:00 --> Pagination Class Initialized
INFO - 2018-02-21 10:37:00 --> Helper loaded: form_helper
INFO - 2018-02-21 10:37:00 --> Form Validation Class Initialized
INFO - 2018-02-21 10:37:00 --> Model Class Initialized
INFO - 2018-02-21 10:37:00 --> Controller Class Initialized
INFO - 2018-02-21 10:37:00 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-21 10:37:00 --> Model Class Initialized
INFO - 2018-02-21 10:37:00 --> Model Class Initialized
DEBUG - 2018-02-21 10:37:00 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-21 10:37:00 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-02-21 10:37:00 --> Upload Class Initialized
INFO - 2018-02-21 10:37:00 --> Config Class Initialized
INFO - 2018-02-21 10:37:00 --> Hooks Class Initialized
DEBUG - 2018-02-21 10:37:00 --> UTF-8 Support Enabled
INFO - 2018-02-21 10:37:00 --> Utf8 Class Initialized
INFO - 2018-02-21 10:37:00 --> URI Class Initialized
INFO - 2018-02-21 10:37:00 --> Router Class Initialized
INFO - 2018-02-21 10:37:00 --> Output Class Initialized
INFO - 2018-02-21 10:37:00 --> Security Class Initialized
DEBUG - 2018-02-21 10:37:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-21 10:37:00 --> Input Class Initialized
INFO - 2018-02-21 10:37:00 --> Language Class Initialized
INFO - 2018-02-21 10:37:00 --> Loader Class Initialized
INFO - 2018-02-21 10:37:00 --> Helper loaded: url_helper
INFO - 2018-02-21 10:37:00 --> Helper loaded: file_helper
INFO - 2018-02-21 10:37:00 --> Helper loaded: email_helper
INFO - 2018-02-21 10:37:00 --> Helper loaded: common_helper
INFO - 2018-02-21 10:37:00 --> Database Driver Class Initialized
DEBUG - 2018-02-21 10:37:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-21 10:37:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-21 10:37:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-21 10:37:00 --> Pagination Class Initialized
INFO - 2018-02-21 10:37:00 --> Helper loaded: form_helper
INFO - 2018-02-21 10:37:00 --> Form Validation Class Initialized
INFO - 2018-02-21 10:37:00 --> Model Class Initialized
INFO - 2018-02-21 10:37:00 --> Controller Class Initialized
INFO - 2018-02-21 10:37:00 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-21 10:37:00 --> Model Class Initialized
INFO - 2018-02-21 10:37:00 --> Model Class Initialized
INFO - 2018-02-21 10:37:00 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-21 10:37:00 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-21 10:37:00 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-21 10:37:00 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-21 10:37:00 --> File loaded: /var/www/html/project/radio/application/views/subcategory/index.php
INFO - 2018-02-21 10:37:00 --> Final output sent to browser
DEBUG - 2018-02-21 10:37:00 --> Total execution time: 0.0074
INFO - 2018-02-21 10:37:03 --> Config Class Initialized
INFO - 2018-02-21 10:37:03 --> Hooks Class Initialized
DEBUG - 2018-02-21 10:37:03 --> UTF-8 Support Enabled
INFO - 2018-02-21 10:37:03 --> Utf8 Class Initialized
INFO - 2018-02-21 10:37:03 --> URI Class Initialized
INFO - 2018-02-21 10:37:03 --> Router Class Initialized
INFO - 2018-02-21 10:37:03 --> Output Class Initialized
INFO - 2018-02-21 10:37:03 --> Security Class Initialized
DEBUG - 2018-02-21 10:37:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-21 10:37:03 --> Input Class Initialized
INFO - 2018-02-21 10:37:03 --> Language Class Initialized
INFO - 2018-02-21 10:37:03 --> Loader Class Initialized
INFO - 2018-02-21 10:37:03 --> Helper loaded: url_helper
INFO - 2018-02-21 10:37:03 --> Helper loaded: file_helper
INFO - 2018-02-21 10:37:03 --> Helper loaded: email_helper
INFO - 2018-02-21 10:37:03 --> Helper loaded: common_helper
INFO - 2018-02-21 10:37:03 --> Database Driver Class Initialized
DEBUG - 2018-02-21 10:37:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-21 10:37:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-21 10:37:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-21 10:37:03 --> Pagination Class Initialized
INFO - 2018-02-21 10:37:03 --> Helper loaded: form_helper
INFO - 2018-02-21 10:37:03 --> Form Validation Class Initialized
INFO - 2018-02-21 10:37:03 --> Model Class Initialized
INFO - 2018-02-21 10:37:03 --> Controller Class Initialized
DEBUG - 2018-02-21 10:37:03 --> Config file loaded: /var/www/html/project/radio/application/config/rest.php
INFO - 2018-02-21 10:37:03 --> Helper loaded: inflector_helper
INFO - 2018-02-21 10:37:03 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-21 10:37:03 --> Model Class Initialized
INFO - 2018-02-21 10:37:03 --> Model Class Initialized
INFO - 2018-02-21 10:37:03 --> Model Class Initialized
INFO - 2018-02-21 10:37:03 --> Final output sent to browser
DEBUG - 2018-02-21 10:37:03 --> Total execution time: 0.0082
INFO - 2018-02-21 10:41:39 --> Config Class Initialized
INFO - 2018-02-21 10:41:39 --> Hooks Class Initialized
DEBUG - 2018-02-21 10:41:39 --> UTF-8 Support Enabled
INFO - 2018-02-21 10:41:39 --> Utf8 Class Initialized
INFO - 2018-02-21 10:41:39 --> URI Class Initialized
INFO - 2018-02-21 10:41:39 --> Router Class Initialized
INFO - 2018-02-21 10:41:39 --> Output Class Initialized
INFO - 2018-02-21 10:41:39 --> Security Class Initialized
DEBUG - 2018-02-21 10:41:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-21 10:41:39 --> Input Class Initialized
INFO - 2018-02-21 10:41:39 --> Language Class Initialized
INFO - 2018-02-21 10:41:39 --> Loader Class Initialized
INFO - 2018-02-21 10:41:39 --> Helper loaded: url_helper
INFO - 2018-02-21 10:41:39 --> Helper loaded: file_helper
INFO - 2018-02-21 10:41:39 --> Helper loaded: email_helper
INFO - 2018-02-21 10:41:39 --> Helper loaded: common_helper
INFO - 2018-02-21 10:41:39 --> Database Driver Class Initialized
DEBUG - 2018-02-21 10:41:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-21 10:41:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-21 10:41:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-21 10:41:39 --> Pagination Class Initialized
INFO - 2018-02-21 10:41:39 --> Helper loaded: form_helper
INFO - 2018-02-21 10:41:39 --> Form Validation Class Initialized
INFO - 2018-02-21 10:41:39 --> Model Class Initialized
INFO - 2018-02-21 10:41:39 --> Controller Class Initialized
DEBUG - 2018-02-21 10:41:39 --> Config file loaded: /var/www/html/project/radio/application/config/rest.php
INFO - 2018-02-21 10:41:39 --> Helper loaded: inflector_helper
INFO - 2018-02-21 10:41:39 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-21 10:41:39 --> Model Class Initialized
INFO - 2018-02-21 10:41:39 --> Model Class Initialized
INFO - 2018-02-21 10:41:39 --> Model Class Initialized
INFO - 2018-02-21 10:41:39 --> Final output sent to browser
DEBUG - 2018-02-21 10:41:39 --> Total execution time: 0.0076
INFO - 2018-02-21 10:42:10 --> Config Class Initialized
INFO - 2018-02-21 10:42:10 --> Hooks Class Initialized
DEBUG - 2018-02-21 10:42:10 --> UTF-8 Support Enabled
INFO - 2018-02-21 10:42:10 --> Utf8 Class Initialized
INFO - 2018-02-21 10:42:10 --> URI Class Initialized
INFO - 2018-02-21 10:42:10 --> Router Class Initialized
INFO - 2018-02-21 10:42:10 --> Output Class Initialized
INFO - 2018-02-21 10:42:10 --> Security Class Initialized
DEBUG - 2018-02-21 10:42:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-21 10:42:10 --> Input Class Initialized
INFO - 2018-02-21 10:42:10 --> Language Class Initialized
INFO - 2018-02-21 10:42:10 --> Loader Class Initialized
INFO - 2018-02-21 10:42:10 --> Helper loaded: url_helper
INFO - 2018-02-21 10:42:10 --> Helper loaded: file_helper
INFO - 2018-02-21 10:42:10 --> Helper loaded: email_helper
INFO - 2018-02-21 10:42:10 --> Helper loaded: common_helper
INFO - 2018-02-21 10:42:10 --> Database Driver Class Initialized
DEBUG - 2018-02-21 10:42:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-21 10:42:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-21 10:42:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-21 10:42:10 --> Pagination Class Initialized
INFO - 2018-02-21 10:42:10 --> Helper loaded: form_helper
INFO - 2018-02-21 10:42:10 --> Form Validation Class Initialized
INFO - 2018-02-21 10:42:10 --> Model Class Initialized
INFO - 2018-02-21 10:42:10 --> Controller Class Initialized
DEBUG - 2018-02-21 10:42:10 --> Config file loaded: /var/www/html/project/radio/application/config/rest.php
INFO - 2018-02-21 10:42:10 --> Helper loaded: inflector_helper
INFO - 2018-02-21 10:42:10 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-21 10:42:10 --> Model Class Initialized
INFO - 2018-02-21 10:42:10 --> Model Class Initialized
INFO - 2018-02-21 10:42:10 --> Model Class Initialized
INFO - 2018-02-21 10:42:10 --> Final output sent to browser
DEBUG - 2018-02-21 10:42:10 --> Total execution time: 0.0098
INFO - 2018-02-21 10:42:55 --> Config Class Initialized
INFO - 2018-02-21 10:42:55 --> Hooks Class Initialized
DEBUG - 2018-02-21 10:42:55 --> UTF-8 Support Enabled
INFO - 2018-02-21 10:42:55 --> Utf8 Class Initialized
INFO - 2018-02-21 10:42:55 --> URI Class Initialized
INFO - 2018-02-21 10:42:55 --> Router Class Initialized
INFO - 2018-02-21 10:42:55 --> Output Class Initialized
INFO - 2018-02-21 10:42:55 --> Security Class Initialized
DEBUG - 2018-02-21 10:42:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-21 10:42:55 --> Input Class Initialized
INFO - 2018-02-21 10:42:55 --> Language Class Initialized
INFO - 2018-02-21 10:42:55 --> Loader Class Initialized
INFO - 2018-02-21 10:42:55 --> Helper loaded: url_helper
INFO - 2018-02-21 10:42:55 --> Helper loaded: file_helper
INFO - 2018-02-21 10:42:55 --> Helper loaded: email_helper
INFO - 2018-02-21 10:42:55 --> Helper loaded: common_helper
INFO - 2018-02-21 10:42:55 --> Database Driver Class Initialized
DEBUG - 2018-02-21 10:42:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-21 10:42:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-21 10:42:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-21 10:42:55 --> Pagination Class Initialized
INFO - 2018-02-21 10:42:55 --> Helper loaded: form_helper
INFO - 2018-02-21 10:42:55 --> Form Validation Class Initialized
INFO - 2018-02-21 10:42:55 --> Model Class Initialized
INFO - 2018-02-21 10:42:55 --> Controller Class Initialized
DEBUG - 2018-02-21 10:42:55 --> Config file loaded: /var/www/html/project/radio/application/config/rest.php
INFO - 2018-02-21 10:42:55 --> Helper loaded: inflector_helper
INFO - 2018-02-21 10:42:55 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-21 10:42:55 --> Model Class Initialized
INFO - 2018-02-21 10:42:55 --> Model Class Initialized
INFO - 2018-02-21 10:42:55 --> Model Class Initialized
INFO - 2018-02-21 10:42:55 --> Final output sent to browser
DEBUG - 2018-02-21 10:42:55 --> Total execution time: 0.0075
INFO - 2018-02-21 10:43:23 --> Config Class Initialized
INFO - 2018-02-21 10:43:23 --> Hooks Class Initialized
DEBUG - 2018-02-21 10:43:23 --> UTF-8 Support Enabled
INFO - 2018-02-21 10:43:23 --> Utf8 Class Initialized
INFO - 2018-02-21 10:43:23 --> URI Class Initialized
INFO - 2018-02-21 10:43:23 --> Router Class Initialized
INFO - 2018-02-21 10:43:23 --> Output Class Initialized
INFO - 2018-02-21 10:43:23 --> Security Class Initialized
DEBUG - 2018-02-21 10:43:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-21 10:43:23 --> Input Class Initialized
INFO - 2018-02-21 10:43:23 --> Language Class Initialized
INFO - 2018-02-21 10:43:23 --> Loader Class Initialized
INFO - 2018-02-21 10:43:23 --> Helper loaded: url_helper
INFO - 2018-02-21 10:43:23 --> Helper loaded: file_helper
INFO - 2018-02-21 10:43:23 --> Helper loaded: email_helper
INFO - 2018-02-21 10:43:23 --> Helper loaded: common_helper
INFO - 2018-02-21 10:43:23 --> Database Driver Class Initialized
DEBUG - 2018-02-21 10:43:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-21 10:43:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-21 10:43:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-21 10:43:23 --> Pagination Class Initialized
INFO - 2018-02-21 10:43:23 --> Helper loaded: form_helper
INFO - 2018-02-21 10:43:23 --> Form Validation Class Initialized
INFO - 2018-02-21 10:43:23 --> Model Class Initialized
INFO - 2018-02-21 10:43:23 --> Controller Class Initialized
DEBUG - 2018-02-21 10:43:23 --> Config file loaded: /var/www/html/project/radio/application/config/rest.php
INFO - 2018-02-21 10:43:23 --> Helper loaded: inflector_helper
INFO - 2018-02-21 10:43:23 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-21 10:43:23 --> Model Class Initialized
INFO - 2018-02-21 10:43:23 --> Model Class Initialized
INFO - 2018-02-21 10:43:23 --> Model Class Initialized
INFO - 2018-02-21 10:43:23 --> Final output sent to browser
DEBUG - 2018-02-21 10:43:23 --> Total execution time: 0.0059
INFO - 2018-02-21 10:43:38 --> Config Class Initialized
INFO - 2018-02-21 10:43:38 --> Hooks Class Initialized
DEBUG - 2018-02-21 10:43:38 --> UTF-8 Support Enabled
INFO - 2018-02-21 10:43:38 --> Utf8 Class Initialized
INFO - 2018-02-21 10:43:38 --> URI Class Initialized
INFO - 2018-02-21 10:43:38 --> Router Class Initialized
INFO - 2018-02-21 10:43:38 --> Output Class Initialized
INFO - 2018-02-21 10:43:38 --> Security Class Initialized
DEBUG - 2018-02-21 10:43:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-21 10:43:38 --> Input Class Initialized
INFO - 2018-02-21 10:43:38 --> Language Class Initialized
INFO - 2018-02-21 10:43:38 --> Loader Class Initialized
INFO - 2018-02-21 10:43:38 --> Helper loaded: url_helper
INFO - 2018-02-21 10:43:38 --> Helper loaded: file_helper
INFO - 2018-02-21 10:43:38 --> Helper loaded: email_helper
INFO - 2018-02-21 10:43:38 --> Helper loaded: common_helper
INFO - 2018-02-21 10:43:38 --> Database Driver Class Initialized
DEBUG - 2018-02-21 10:43:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-21 10:43:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-21 10:43:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-21 10:43:38 --> Pagination Class Initialized
INFO - 2018-02-21 10:43:38 --> Helper loaded: form_helper
INFO - 2018-02-21 10:43:38 --> Form Validation Class Initialized
INFO - 2018-02-21 10:43:38 --> Model Class Initialized
INFO - 2018-02-21 10:43:38 --> Controller Class Initialized
DEBUG - 2018-02-21 10:43:38 --> Config file loaded: /var/www/html/project/radio/application/config/rest.php
INFO - 2018-02-21 10:43:38 --> Helper loaded: inflector_helper
INFO - 2018-02-21 10:43:38 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-21 10:43:38 --> Model Class Initialized
INFO - 2018-02-21 10:43:38 --> Model Class Initialized
INFO - 2018-02-21 10:43:38 --> Model Class Initialized
INFO - 2018-02-21 10:43:38 --> Final output sent to browser
DEBUG - 2018-02-21 10:43:38 --> Total execution time: 0.0092
INFO - 2018-02-21 10:44:07 --> Config Class Initialized
INFO - 2018-02-21 10:44:07 --> Hooks Class Initialized
DEBUG - 2018-02-21 10:44:07 --> UTF-8 Support Enabled
INFO - 2018-02-21 10:44:07 --> Utf8 Class Initialized
INFO - 2018-02-21 10:44:07 --> URI Class Initialized
INFO - 2018-02-21 10:44:07 --> Router Class Initialized
INFO - 2018-02-21 10:44:07 --> Output Class Initialized
INFO - 2018-02-21 10:44:07 --> Security Class Initialized
DEBUG - 2018-02-21 10:44:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-21 10:44:07 --> Input Class Initialized
INFO - 2018-02-21 10:44:07 --> Language Class Initialized
INFO - 2018-02-21 10:44:07 --> Loader Class Initialized
INFO - 2018-02-21 10:44:07 --> Helper loaded: url_helper
INFO - 2018-02-21 10:44:07 --> Helper loaded: file_helper
INFO - 2018-02-21 10:44:07 --> Helper loaded: email_helper
INFO - 2018-02-21 10:44:07 --> Helper loaded: common_helper
INFO - 2018-02-21 10:44:07 --> Database Driver Class Initialized
DEBUG - 2018-02-21 10:44:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-21 10:44:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-21 10:44:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-21 10:44:07 --> Pagination Class Initialized
INFO - 2018-02-21 10:44:07 --> Helper loaded: form_helper
INFO - 2018-02-21 10:44:07 --> Form Validation Class Initialized
INFO - 2018-02-21 10:44:07 --> Model Class Initialized
INFO - 2018-02-21 10:44:07 --> Controller Class Initialized
DEBUG - 2018-02-21 10:44:07 --> Config file loaded: /var/www/html/project/radio/application/config/rest.php
INFO - 2018-02-21 10:44:07 --> Helper loaded: inflector_helper
INFO - 2018-02-21 10:44:07 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-21 10:44:07 --> Model Class Initialized
INFO - 2018-02-21 10:44:07 --> Model Class Initialized
INFO - 2018-02-21 10:44:07 --> Model Class Initialized
INFO - 2018-02-21 10:44:07 --> Final output sent to browser
DEBUG - 2018-02-21 10:44:07 --> Total execution time: 0.0063
INFO - 2018-02-21 10:45:29 --> Config Class Initialized
INFO - 2018-02-21 10:45:29 --> Hooks Class Initialized
DEBUG - 2018-02-21 10:45:29 --> UTF-8 Support Enabled
INFO - 2018-02-21 10:45:29 --> Utf8 Class Initialized
INFO - 2018-02-21 10:45:29 --> URI Class Initialized
INFO - 2018-02-21 10:45:29 --> Router Class Initialized
INFO - 2018-02-21 10:45:29 --> Output Class Initialized
INFO - 2018-02-21 10:45:29 --> Security Class Initialized
DEBUG - 2018-02-21 10:45:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-21 10:45:29 --> Input Class Initialized
INFO - 2018-02-21 10:45:29 --> Language Class Initialized
INFO - 2018-02-21 10:45:29 --> Loader Class Initialized
INFO - 2018-02-21 10:45:29 --> Helper loaded: url_helper
INFO - 2018-02-21 10:45:29 --> Helper loaded: file_helper
INFO - 2018-02-21 10:45:29 --> Helper loaded: email_helper
INFO - 2018-02-21 10:45:29 --> Helper loaded: common_helper
INFO - 2018-02-21 10:45:29 --> Database Driver Class Initialized
DEBUG - 2018-02-21 10:45:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-21 10:45:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-21 10:45:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-21 10:45:29 --> Pagination Class Initialized
INFO - 2018-02-21 10:45:29 --> Helper loaded: form_helper
INFO - 2018-02-21 10:45:29 --> Form Validation Class Initialized
INFO - 2018-02-21 10:45:29 --> Model Class Initialized
INFO - 2018-02-21 10:45:29 --> Controller Class Initialized
DEBUG - 2018-02-21 10:45:29 --> Config file loaded: /var/www/html/project/radio/application/config/rest.php
INFO - 2018-02-21 10:45:29 --> Helper loaded: inflector_helper
INFO - 2018-02-21 10:45:29 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-21 10:45:29 --> Model Class Initialized
INFO - 2018-02-21 10:45:29 --> Model Class Initialized
INFO - 2018-02-21 10:45:29 --> Model Class Initialized
INFO - 2018-02-21 10:45:29 --> Final output sent to browser
DEBUG - 2018-02-21 10:45:29 --> Total execution time: 0.0060
INFO - 2018-02-21 10:50:51 --> Config Class Initialized
INFO - 2018-02-21 10:50:51 --> Hooks Class Initialized
DEBUG - 2018-02-21 10:50:51 --> UTF-8 Support Enabled
INFO - 2018-02-21 10:50:51 --> Utf8 Class Initialized
INFO - 2018-02-21 10:50:51 --> URI Class Initialized
INFO - 2018-02-21 10:50:51 --> Router Class Initialized
INFO - 2018-02-21 10:50:51 --> Output Class Initialized
INFO - 2018-02-21 10:50:51 --> Security Class Initialized
DEBUG - 2018-02-21 10:50:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-21 10:50:51 --> Input Class Initialized
INFO - 2018-02-21 10:50:51 --> Language Class Initialized
INFO - 2018-02-21 10:50:51 --> Loader Class Initialized
INFO - 2018-02-21 10:50:51 --> Helper loaded: url_helper
INFO - 2018-02-21 10:50:51 --> Helper loaded: file_helper
INFO - 2018-02-21 10:50:51 --> Helper loaded: email_helper
INFO - 2018-02-21 10:50:51 --> Helper loaded: common_helper
INFO - 2018-02-21 10:50:51 --> Database Driver Class Initialized
DEBUG - 2018-02-21 10:50:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-21 10:50:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-21 10:50:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-21 10:50:51 --> Pagination Class Initialized
INFO - 2018-02-21 10:50:51 --> Helper loaded: form_helper
INFO - 2018-02-21 10:50:51 --> Form Validation Class Initialized
INFO - 2018-02-21 10:50:51 --> Model Class Initialized
INFO - 2018-02-21 10:50:51 --> Controller Class Initialized
DEBUG - 2018-02-21 10:50:51 --> Config file loaded: /var/www/html/project/radio/application/config/rest.php
INFO - 2018-02-21 10:50:51 --> Helper loaded: inflector_helper
INFO - 2018-02-21 10:50:51 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-21 10:50:51 --> Model Class Initialized
INFO - 2018-02-21 10:50:51 --> Model Class Initialized
INFO - 2018-02-21 10:50:51 --> Model Class Initialized
INFO - 2018-02-21 10:54:52 --> Config Class Initialized
INFO - 2018-02-21 10:54:52 --> Hooks Class Initialized
DEBUG - 2018-02-21 10:54:52 --> UTF-8 Support Enabled
INFO - 2018-02-21 10:54:52 --> Utf8 Class Initialized
INFO - 2018-02-21 10:54:52 --> URI Class Initialized
INFO - 2018-02-21 10:54:52 --> Router Class Initialized
INFO - 2018-02-21 10:54:52 --> Output Class Initialized
INFO - 2018-02-21 10:54:52 --> Security Class Initialized
DEBUG - 2018-02-21 10:54:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-21 10:54:52 --> Input Class Initialized
INFO - 2018-02-21 10:54:52 --> Language Class Initialized
INFO - 2018-02-21 10:54:52 --> Loader Class Initialized
INFO - 2018-02-21 10:54:52 --> Helper loaded: url_helper
INFO - 2018-02-21 10:54:52 --> Helper loaded: file_helper
INFO - 2018-02-21 10:54:52 --> Helper loaded: email_helper
INFO - 2018-02-21 10:54:52 --> Helper loaded: common_helper
INFO - 2018-02-21 10:54:52 --> Database Driver Class Initialized
DEBUG - 2018-02-21 10:54:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-21 10:54:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-21 10:54:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-21 10:54:52 --> Pagination Class Initialized
INFO - 2018-02-21 10:54:52 --> Helper loaded: form_helper
INFO - 2018-02-21 10:54:52 --> Form Validation Class Initialized
INFO - 2018-02-21 10:54:52 --> Model Class Initialized
INFO - 2018-02-21 10:54:52 --> Controller Class Initialized
DEBUG - 2018-02-21 10:54:52 --> Config file loaded: /var/www/html/project/radio/application/config/rest.php
INFO - 2018-02-21 10:54:52 --> Helper loaded: inflector_helper
INFO - 2018-02-21 10:54:52 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-21 10:54:52 --> Model Class Initialized
INFO - 2018-02-21 10:54:52 --> Model Class Initialized
INFO - 2018-02-21 10:54:52 --> Model Class Initialized
INFO - 2018-02-21 10:55:30 --> Config Class Initialized
INFO - 2018-02-21 10:55:30 --> Hooks Class Initialized
DEBUG - 2018-02-21 10:55:30 --> UTF-8 Support Enabled
INFO - 2018-02-21 10:55:30 --> Utf8 Class Initialized
INFO - 2018-02-21 10:55:30 --> URI Class Initialized
INFO - 2018-02-21 10:55:30 --> Router Class Initialized
INFO - 2018-02-21 10:55:30 --> Output Class Initialized
INFO - 2018-02-21 10:55:30 --> Security Class Initialized
DEBUG - 2018-02-21 10:55:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-21 10:55:30 --> Input Class Initialized
INFO - 2018-02-21 10:55:30 --> Language Class Initialized
INFO - 2018-02-21 10:55:30 --> Loader Class Initialized
INFO - 2018-02-21 10:55:30 --> Helper loaded: url_helper
INFO - 2018-02-21 10:55:30 --> Helper loaded: file_helper
INFO - 2018-02-21 10:55:30 --> Helper loaded: email_helper
INFO - 2018-02-21 10:55:30 --> Helper loaded: common_helper
INFO - 2018-02-21 10:55:30 --> Database Driver Class Initialized
DEBUG - 2018-02-21 10:55:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-21 10:55:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-21 10:55:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-21 10:55:30 --> Pagination Class Initialized
INFO - 2018-02-21 10:55:30 --> Helper loaded: form_helper
INFO - 2018-02-21 10:55:30 --> Form Validation Class Initialized
INFO - 2018-02-21 10:55:30 --> Model Class Initialized
INFO - 2018-02-21 10:55:30 --> Controller Class Initialized
DEBUG - 2018-02-21 10:55:30 --> Config file loaded: /var/www/html/project/radio/application/config/rest.php
INFO - 2018-02-21 10:55:30 --> Helper loaded: inflector_helper
INFO - 2018-02-21 10:55:30 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-21 10:55:30 --> Model Class Initialized
INFO - 2018-02-21 10:55:30 --> Model Class Initialized
INFO - 2018-02-21 10:55:30 --> Model Class Initialized
INFO - 2018-02-21 10:58:50 --> Config Class Initialized
INFO - 2018-02-21 10:58:50 --> Hooks Class Initialized
DEBUG - 2018-02-21 10:58:50 --> UTF-8 Support Enabled
INFO - 2018-02-21 10:58:50 --> Utf8 Class Initialized
INFO - 2018-02-21 10:58:50 --> URI Class Initialized
INFO - 2018-02-21 10:58:50 --> Router Class Initialized
INFO - 2018-02-21 10:58:50 --> Output Class Initialized
INFO - 2018-02-21 10:58:50 --> Security Class Initialized
DEBUG - 2018-02-21 10:58:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-21 10:58:50 --> Input Class Initialized
INFO - 2018-02-21 10:58:50 --> Language Class Initialized
INFO - 2018-02-21 10:58:50 --> Loader Class Initialized
INFO - 2018-02-21 10:58:50 --> Helper loaded: url_helper
INFO - 2018-02-21 10:58:50 --> Helper loaded: file_helper
INFO - 2018-02-21 10:58:50 --> Helper loaded: email_helper
INFO - 2018-02-21 10:58:50 --> Helper loaded: common_helper
INFO - 2018-02-21 10:58:50 --> Database Driver Class Initialized
DEBUG - 2018-02-21 10:58:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-21 10:58:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-21 10:58:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-21 10:58:50 --> Pagination Class Initialized
INFO - 2018-02-21 10:58:50 --> Helper loaded: form_helper
INFO - 2018-02-21 10:58:50 --> Form Validation Class Initialized
INFO - 2018-02-21 10:58:50 --> Model Class Initialized
INFO - 2018-02-21 10:58:50 --> Controller Class Initialized
DEBUG - 2018-02-21 10:58:50 --> Config file loaded: /var/www/html/project/radio/application/config/rest.php
INFO - 2018-02-21 10:58:50 --> Helper loaded: inflector_helper
INFO - 2018-02-21 10:58:50 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-21 10:58:50 --> Model Class Initialized
INFO - 2018-02-21 10:58:50 --> Model Class Initialized
INFO - 2018-02-21 10:58:50 --> Model Class Initialized
INFO - 2018-02-21 10:59:59 --> Config Class Initialized
INFO - 2018-02-21 10:59:59 --> Hooks Class Initialized
DEBUG - 2018-02-21 10:59:59 --> UTF-8 Support Enabled
INFO - 2018-02-21 10:59:59 --> Utf8 Class Initialized
INFO - 2018-02-21 10:59:59 --> URI Class Initialized
INFO - 2018-02-21 10:59:59 --> Router Class Initialized
INFO - 2018-02-21 10:59:59 --> Output Class Initialized
INFO - 2018-02-21 10:59:59 --> Security Class Initialized
DEBUG - 2018-02-21 10:59:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-21 10:59:59 --> Input Class Initialized
INFO - 2018-02-21 10:59:59 --> Language Class Initialized
INFO - 2018-02-21 10:59:59 --> Loader Class Initialized
INFO - 2018-02-21 10:59:59 --> Helper loaded: url_helper
INFO - 2018-02-21 10:59:59 --> Helper loaded: file_helper
INFO - 2018-02-21 10:59:59 --> Helper loaded: email_helper
INFO - 2018-02-21 10:59:59 --> Helper loaded: common_helper
INFO - 2018-02-21 10:59:59 --> Database Driver Class Initialized
DEBUG - 2018-02-21 10:59:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-21 10:59:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-21 10:59:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-21 10:59:59 --> Pagination Class Initialized
INFO - 2018-02-21 10:59:59 --> Helper loaded: form_helper
INFO - 2018-02-21 10:59:59 --> Form Validation Class Initialized
INFO - 2018-02-21 10:59:59 --> Model Class Initialized
INFO - 2018-02-21 10:59:59 --> Controller Class Initialized
DEBUG - 2018-02-21 10:59:59 --> Config file loaded: /var/www/html/project/radio/application/config/rest.php
INFO - 2018-02-21 10:59:59 --> Helper loaded: inflector_helper
INFO - 2018-02-21 10:59:59 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-21 10:59:59 --> Model Class Initialized
INFO - 2018-02-21 10:59:59 --> Model Class Initialized
INFO - 2018-02-21 10:59:59 --> Model Class Initialized
INFO - 2018-02-21 11:00:12 --> Config Class Initialized
INFO - 2018-02-21 11:00:12 --> Hooks Class Initialized
DEBUG - 2018-02-21 11:00:12 --> UTF-8 Support Enabled
INFO - 2018-02-21 11:00:12 --> Utf8 Class Initialized
INFO - 2018-02-21 11:00:12 --> URI Class Initialized
INFO - 2018-02-21 11:00:12 --> Router Class Initialized
INFO - 2018-02-21 11:00:12 --> Output Class Initialized
INFO - 2018-02-21 11:00:12 --> Security Class Initialized
DEBUG - 2018-02-21 11:00:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-21 11:00:12 --> Input Class Initialized
INFO - 2018-02-21 11:00:12 --> Language Class Initialized
INFO - 2018-02-21 11:00:12 --> Loader Class Initialized
INFO - 2018-02-21 11:00:12 --> Helper loaded: url_helper
INFO - 2018-02-21 11:00:12 --> Helper loaded: file_helper
INFO - 2018-02-21 11:00:12 --> Helper loaded: email_helper
INFO - 2018-02-21 11:00:12 --> Helper loaded: common_helper
INFO - 2018-02-21 11:00:12 --> Database Driver Class Initialized
DEBUG - 2018-02-21 11:00:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-21 11:00:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-21 11:00:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-21 11:00:12 --> Pagination Class Initialized
INFO - 2018-02-21 11:00:12 --> Helper loaded: form_helper
INFO - 2018-02-21 11:00:12 --> Form Validation Class Initialized
INFO - 2018-02-21 11:00:12 --> Model Class Initialized
INFO - 2018-02-21 11:00:12 --> Controller Class Initialized
DEBUG - 2018-02-21 11:00:12 --> Config file loaded: /var/www/html/project/radio/application/config/rest.php
INFO - 2018-02-21 11:00:12 --> Helper loaded: inflector_helper
INFO - 2018-02-21 11:00:12 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-21 11:00:12 --> Model Class Initialized
INFO - 2018-02-21 11:00:12 --> Model Class Initialized
INFO - 2018-02-21 11:00:12 --> Model Class Initialized
INFO - 2018-02-21 11:00:15 --> Config Class Initialized
INFO - 2018-02-21 11:00:15 --> Hooks Class Initialized
DEBUG - 2018-02-21 11:00:15 --> UTF-8 Support Enabled
INFO - 2018-02-21 11:00:15 --> Utf8 Class Initialized
INFO - 2018-02-21 11:00:15 --> URI Class Initialized
INFO - 2018-02-21 11:00:15 --> Router Class Initialized
INFO - 2018-02-21 11:00:15 --> Output Class Initialized
INFO - 2018-02-21 11:00:15 --> Security Class Initialized
DEBUG - 2018-02-21 11:00:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-21 11:00:15 --> Input Class Initialized
INFO - 2018-02-21 11:00:15 --> Language Class Initialized
INFO - 2018-02-21 11:00:15 --> Loader Class Initialized
INFO - 2018-02-21 11:00:15 --> Helper loaded: url_helper
INFO - 2018-02-21 11:00:15 --> Helper loaded: file_helper
INFO - 2018-02-21 11:00:15 --> Helper loaded: email_helper
INFO - 2018-02-21 11:00:15 --> Helper loaded: common_helper
INFO - 2018-02-21 11:00:15 --> Database Driver Class Initialized
DEBUG - 2018-02-21 11:00:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-21 11:00:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-21 11:00:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-21 11:00:15 --> Pagination Class Initialized
INFO - 2018-02-21 11:00:15 --> Helper loaded: form_helper
INFO - 2018-02-21 11:00:15 --> Form Validation Class Initialized
INFO - 2018-02-21 11:00:15 --> Model Class Initialized
INFO - 2018-02-21 11:00:15 --> Controller Class Initialized
DEBUG - 2018-02-21 11:00:15 --> Config file loaded: /var/www/html/project/radio/application/config/rest.php
INFO - 2018-02-21 11:00:15 --> Helper loaded: inflector_helper
INFO - 2018-02-21 11:00:15 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-21 11:00:15 --> Model Class Initialized
INFO - 2018-02-21 11:00:15 --> Model Class Initialized
INFO - 2018-02-21 11:00:15 --> Model Class Initialized
INFO - 2018-02-21 11:00:23 --> Config Class Initialized
INFO - 2018-02-21 11:00:23 --> Hooks Class Initialized
DEBUG - 2018-02-21 11:00:23 --> UTF-8 Support Enabled
INFO - 2018-02-21 11:00:23 --> Utf8 Class Initialized
INFO - 2018-02-21 11:00:23 --> URI Class Initialized
INFO - 2018-02-21 11:00:23 --> Router Class Initialized
INFO - 2018-02-21 11:00:23 --> Output Class Initialized
INFO - 2018-02-21 11:00:23 --> Security Class Initialized
DEBUG - 2018-02-21 11:00:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-21 11:00:23 --> Input Class Initialized
INFO - 2018-02-21 11:00:23 --> Language Class Initialized
INFO - 2018-02-21 11:00:23 --> Loader Class Initialized
INFO - 2018-02-21 11:00:23 --> Helper loaded: url_helper
INFO - 2018-02-21 11:00:23 --> Helper loaded: file_helper
INFO - 2018-02-21 11:00:23 --> Helper loaded: email_helper
INFO - 2018-02-21 11:00:23 --> Helper loaded: common_helper
INFO - 2018-02-21 11:00:23 --> Database Driver Class Initialized
DEBUG - 2018-02-21 11:00:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-21 11:00:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-21 11:00:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-21 11:00:23 --> Pagination Class Initialized
INFO - 2018-02-21 11:00:23 --> Helper loaded: form_helper
INFO - 2018-02-21 11:00:23 --> Form Validation Class Initialized
INFO - 2018-02-21 11:00:23 --> Model Class Initialized
INFO - 2018-02-21 11:00:23 --> Controller Class Initialized
DEBUG - 2018-02-21 11:00:23 --> Config file loaded: /var/www/html/project/radio/application/config/rest.php
INFO - 2018-02-21 11:00:23 --> Helper loaded: inflector_helper
INFO - 2018-02-21 11:00:23 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-21 11:00:23 --> Model Class Initialized
INFO - 2018-02-21 11:00:23 --> Model Class Initialized
INFO - 2018-02-21 11:00:23 --> Model Class Initialized
INFO - 2018-02-21 11:01:09 --> Config Class Initialized
INFO - 2018-02-21 11:01:09 --> Hooks Class Initialized
DEBUG - 2018-02-21 11:01:09 --> UTF-8 Support Enabled
INFO - 2018-02-21 11:01:09 --> Utf8 Class Initialized
INFO - 2018-02-21 11:01:09 --> URI Class Initialized
INFO - 2018-02-21 11:01:09 --> Router Class Initialized
INFO - 2018-02-21 11:01:09 --> Output Class Initialized
INFO - 2018-02-21 11:01:09 --> Security Class Initialized
DEBUG - 2018-02-21 11:01:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-21 11:01:09 --> Input Class Initialized
INFO - 2018-02-21 11:01:09 --> Language Class Initialized
INFO - 2018-02-21 11:01:09 --> Loader Class Initialized
INFO - 2018-02-21 11:01:09 --> Helper loaded: url_helper
INFO - 2018-02-21 11:01:09 --> Helper loaded: file_helper
INFO - 2018-02-21 11:01:09 --> Helper loaded: email_helper
INFO - 2018-02-21 11:01:09 --> Helper loaded: common_helper
INFO - 2018-02-21 11:01:09 --> Database Driver Class Initialized
DEBUG - 2018-02-21 11:01:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-21 11:01:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-21 11:01:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-21 11:01:09 --> Pagination Class Initialized
INFO - 2018-02-21 11:01:09 --> Helper loaded: form_helper
INFO - 2018-02-21 11:01:09 --> Form Validation Class Initialized
INFO - 2018-02-21 11:01:09 --> Model Class Initialized
INFO - 2018-02-21 11:01:09 --> Controller Class Initialized
DEBUG - 2018-02-21 11:01:09 --> Config file loaded: /var/www/html/project/radio/application/config/rest.php
INFO - 2018-02-21 11:01:09 --> Helper loaded: inflector_helper
INFO - 2018-02-21 11:01:09 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-21 11:01:09 --> Model Class Initialized
INFO - 2018-02-21 11:01:09 --> Model Class Initialized
INFO - 2018-02-21 11:01:09 --> Model Class Initialized
INFO - 2018-02-21 11:01:19 --> Config Class Initialized
INFO - 2018-02-21 11:01:19 --> Hooks Class Initialized
DEBUG - 2018-02-21 11:01:19 --> UTF-8 Support Enabled
INFO - 2018-02-21 11:01:19 --> Utf8 Class Initialized
INFO - 2018-02-21 11:01:19 --> URI Class Initialized
INFO - 2018-02-21 11:01:19 --> Router Class Initialized
INFO - 2018-02-21 11:01:19 --> Output Class Initialized
INFO - 2018-02-21 11:01:19 --> Security Class Initialized
DEBUG - 2018-02-21 11:01:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-21 11:01:19 --> Input Class Initialized
INFO - 2018-02-21 11:01:19 --> Language Class Initialized
INFO - 2018-02-21 11:01:19 --> Loader Class Initialized
INFO - 2018-02-21 11:01:19 --> Helper loaded: url_helper
INFO - 2018-02-21 11:01:19 --> Helper loaded: file_helper
INFO - 2018-02-21 11:01:19 --> Helper loaded: email_helper
INFO - 2018-02-21 11:01:19 --> Helper loaded: common_helper
INFO - 2018-02-21 11:01:19 --> Database Driver Class Initialized
DEBUG - 2018-02-21 11:01:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-21 11:01:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-21 11:01:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-21 11:01:19 --> Pagination Class Initialized
INFO - 2018-02-21 11:01:19 --> Helper loaded: form_helper
INFO - 2018-02-21 11:01:19 --> Form Validation Class Initialized
INFO - 2018-02-21 11:01:19 --> Model Class Initialized
INFO - 2018-02-21 11:01:19 --> Controller Class Initialized
DEBUG - 2018-02-21 11:01:19 --> Config file loaded: /var/www/html/project/radio/application/config/rest.php
INFO - 2018-02-21 11:01:19 --> Helper loaded: inflector_helper
INFO - 2018-02-21 11:01:19 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-21 11:01:19 --> Model Class Initialized
INFO - 2018-02-21 11:01:19 --> Model Class Initialized
INFO - 2018-02-21 11:01:19 --> Model Class Initialized
INFO - 2018-02-21 11:01:19 --> Final output sent to browser
DEBUG - 2018-02-21 11:01:19 --> Total execution time: 0.0109
INFO - 2018-02-21 11:01:47 --> Config Class Initialized
INFO - 2018-02-21 11:01:47 --> Hooks Class Initialized
DEBUG - 2018-02-21 11:01:47 --> UTF-8 Support Enabled
INFO - 2018-02-21 11:01:47 --> Utf8 Class Initialized
INFO - 2018-02-21 11:01:47 --> URI Class Initialized
INFO - 2018-02-21 11:01:47 --> Router Class Initialized
INFO - 2018-02-21 11:01:47 --> Output Class Initialized
INFO - 2018-02-21 11:01:47 --> Security Class Initialized
DEBUG - 2018-02-21 11:01:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-21 11:01:47 --> Input Class Initialized
INFO - 2018-02-21 11:01:47 --> Language Class Initialized
INFO - 2018-02-21 11:01:47 --> Loader Class Initialized
INFO - 2018-02-21 11:01:47 --> Helper loaded: url_helper
INFO - 2018-02-21 11:01:47 --> Helper loaded: file_helper
INFO - 2018-02-21 11:01:47 --> Helper loaded: email_helper
INFO - 2018-02-21 11:01:47 --> Helper loaded: common_helper
INFO - 2018-02-21 11:01:47 --> Database Driver Class Initialized
DEBUG - 2018-02-21 11:01:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-21 11:01:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-21 11:01:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-21 11:01:47 --> Pagination Class Initialized
INFO - 2018-02-21 11:01:47 --> Helper loaded: form_helper
INFO - 2018-02-21 11:01:47 --> Form Validation Class Initialized
INFO - 2018-02-21 11:01:47 --> Model Class Initialized
INFO - 2018-02-21 11:01:47 --> Controller Class Initialized
DEBUG - 2018-02-21 11:01:47 --> Config file loaded: /var/www/html/project/radio/application/config/rest.php
INFO - 2018-02-21 11:01:47 --> Helper loaded: inflector_helper
INFO - 2018-02-21 11:01:47 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-21 11:01:47 --> Model Class Initialized
INFO - 2018-02-21 11:01:47 --> Model Class Initialized
INFO - 2018-02-21 11:01:47 --> Model Class Initialized
INFO - 2018-02-21 11:01:47 --> Final output sent to browser
DEBUG - 2018-02-21 11:01:47 --> Total execution time: 0.0065
INFO - 2018-02-21 11:02:06 --> Config Class Initialized
INFO - 2018-02-21 11:02:06 --> Hooks Class Initialized
DEBUG - 2018-02-21 11:02:06 --> UTF-8 Support Enabled
INFO - 2018-02-21 11:02:06 --> Utf8 Class Initialized
INFO - 2018-02-21 11:02:06 --> URI Class Initialized
INFO - 2018-02-21 11:02:06 --> Router Class Initialized
INFO - 2018-02-21 11:02:06 --> Output Class Initialized
INFO - 2018-02-21 11:02:06 --> Security Class Initialized
DEBUG - 2018-02-21 11:02:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-21 11:02:06 --> Input Class Initialized
INFO - 2018-02-21 11:02:06 --> Language Class Initialized
INFO - 2018-02-21 11:02:06 --> Loader Class Initialized
INFO - 2018-02-21 11:02:06 --> Helper loaded: url_helper
INFO - 2018-02-21 11:02:06 --> Helper loaded: file_helper
INFO - 2018-02-21 11:02:06 --> Helper loaded: email_helper
INFO - 2018-02-21 11:02:06 --> Helper loaded: common_helper
INFO - 2018-02-21 11:02:06 --> Database Driver Class Initialized
DEBUG - 2018-02-21 11:02:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-21 11:02:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-21 11:02:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-21 11:02:06 --> Pagination Class Initialized
INFO - 2018-02-21 11:02:06 --> Helper loaded: form_helper
INFO - 2018-02-21 11:02:06 --> Form Validation Class Initialized
INFO - 2018-02-21 11:02:06 --> Model Class Initialized
INFO - 2018-02-21 11:02:06 --> Controller Class Initialized
DEBUG - 2018-02-21 11:02:06 --> Config file loaded: /var/www/html/project/radio/application/config/rest.php
INFO - 2018-02-21 11:02:06 --> Helper loaded: inflector_helper
INFO - 2018-02-21 11:02:06 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-21 11:02:06 --> Model Class Initialized
INFO - 2018-02-21 11:02:06 --> Model Class Initialized
INFO - 2018-02-21 11:02:06 --> Model Class Initialized
INFO - 2018-02-21 11:02:06 --> Final output sent to browser
DEBUG - 2018-02-21 11:02:06 --> Total execution time: 0.0066
INFO - 2018-02-21 11:05:04 --> Config Class Initialized
INFO - 2018-02-21 11:05:04 --> Hooks Class Initialized
DEBUG - 2018-02-21 11:05:04 --> UTF-8 Support Enabled
INFO - 2018-02-21 11:05:04 --> Utf8 Class Initialized
INFO - 2018-02-21 11:05:04 --> URI Class Initialized
INFO - 2018-02-21 11:05:04 --> Router Class Initialized
INFO - 2018-02-21 11:05:04 --> Output Class Initialized
INFO - 2018-02-21 11:05:04 --> Security Class Initialized
DEBUG - 2018-02-21 11:05:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-21 11:05:04 --> Input Class Initialized
INFO - 2018-02-21 11:05:04 --> Language Class Initialized
INFO - 2018-02-21 11:05:04 --> Loader Class Initialized
INFO - 2018-02-21 11:05:04 --> Helper loaded: url_helper
INFO - 2018-02-21 11:05:04 --> Helper loaded: file_helper
INFO - 2018-02-21 11:05:04 --> Helper loaded: email_helper
INFO - 2018-02-21 11:05:04 --> Helper loaded: common_helper
INFO - 2018-02-21 11:05:04 --> Database Driver Class Initialized
DEBUG - 2018-02-21 11:05:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-21 11:05:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-21 11:05:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-21 11:05:04 --> Pagination Class Initialized
INFO - 2018-02-21 11:05:04 --> Helper loaded: form_helper
INFO - 2018-02-21 11:05:04 --> Form Validation Class Initialized
INFO - 2018-02-21 11:05:04 --> Model Class Initialized
INFO - 2018-02-21 11:05:04 --> Controller Class Initialized
DEBUG - 2018-02-21 11:05:04 --> Config file loaded: /var/www/html/project/radio/application/config/rest.php
INFO - 2018-02-21 11:05:04 --> Helper loaded: inflector_helper
INFO - 2018-02-21 11:05:04 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-21 11:05:04 --> Model Class Initialized
INFO - 2018-02-21 11:05:04 --> Model Class Initialized
INFO - 2018-02-21 11:05:04 --> Model Class Initialized
INFO - 2018-02-21 11:05:14 --> Config Class Initialized
INFO - 2018-02-21 11:05:14 --> Hooks Class Initialized
DEBUG - 2018-02-21 11:05:14 --> UTF-8 Support Enabled
INFO - 2018-02-21 11:05:14 --> Utf8 Class Initialized
INFO - 2018-02-21 11:05:14 --> URI Class Initialized
INFO - 2018-02-21 11:05:14 --> Router Class Initialized
INFO - 2018-02-21 11:05:14 --> Output Class Initialized
INFO - 2018-02-21 11:05:14 --> Security Class Initialized
DEBUG - 2018-02-21 11:05:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-21 11:05:14 --> Input Class Initialized
INFO - 2018-02-21 11:05:14 --> Language Class Initialized
INFO - 2018-02-21 11:05:14 --> Loader Class Initialized
INFO - 2018-02-21 11:05:14 --> Helper loaded: url_helper
INFO - 2018-02-21 11:05:14 --> Helper loaded: file_helper
INFO - 2018-02-21 11:05:14 --> Helper loaded: email_helper
INFO - 2018-02-21 11:05:14 --> Helper loaded: common_helper
INFO - 2018-02-21 11:05:14 --> Database Driver Class Initialized
DEBUG - 2018-02-21 11:05:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-21 11:05:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-21 11:05:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-21 11:05:14 --> Pagination Class Initialized
INFO - 2018-02-21 11:05:14 --> Helper loaded: form_helper
INFO - 2018-02-21 11:05:14 --> Form Validation Class Initialized
INFO - 2018-02-21 11:05:14 --> Model Class Initialized
INFO - 2018-02-21 11:05:14 --> Controller Class Initialized
DEBUG - 2018-02-21 11:05:14 --> Config file loaded: /var/www/html/project/radio/application/config/rest.php
INFO - 2018-02-21 11:05:14 --> Helper loaded: inflector_helper
INFO - 2018-02-21 11:05:14 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-21 11:05:14 --> Model Class Initialized
INFO - 2018-02-21 11:05:14 --> Model Class Initialized
INFO - 2018-02-21 11:05:14 --> Model Class Initialized
INFO - 2018-02-21 11:05:14 --> Final output sent to browser
DEBUG - 2018-02-21 11:05:14 --> Total execution time: 0.0083
INFO - 2018-02-21 12:09:03 --> Config Class Initialized
INFO - 2018-02-21 12:09:03 --> Hooks Class Initialized
DEBUG - 2018-02-21 12:09:03 --> UTF-8 Support Enabled
INFO - 2018-02-21 12:09:03 --> Utf8 Class Initialized
INFO - 2018-02-21 12:09:03 --> URI Class Initialized
INFO - 2018-02-21 12:09:03 --> Router Class Initialized
INFO - 2018-02-21 12:09:03 --> Output Class Initialized
INFO - 2018-02-21 12:09:03 --> Security Class Initialized
DEBUG - 2018-02-21 12:09:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-21 12:09:03 --> Input Class Initialized
INFO - 2018-02-21 12:09:03 --> Language Class Initialized
INFO - 2018-02-21 12:09:03 --> Loader Class Initialized
INFO - 2018-02-21 12:09:03 --> Helper loaded: url_helper
INFO - 2018-02-21 12:09:03 --> Helper loaded: file_helper
INFO - 2018-02-21 12:09:03 --> Helper loaded: email_helper
INFO - 2018-02-21 12:09:03 --> Helper loaded: common_helper
INFO - 2018-02-21 12:09:03 --> Database Driver Class Initialized
DEBUG - 2018-02-21 12:09:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-21 12:09:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-21 12:09:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-21 12:09:03 --> Pagination Class Initialized
INFO - 2018-02-21 12:09:03 --> Helper loaded: form_helper
INFO - 2018-02-21 12:09:03 --> Form Validation Class Initialized
INFO - 2018-02-21 12:09:03 --> Model Class Initialized
INFO - 2018-02-21 12:09:03 --> Controller Class Initialized
DEBUG - 2018-02-21 12:09:03 --> Config file loaded: /var/www/html/project/radio/application/config/rest.php
INFO - 2018-02-21 12:09:03 --> Helper loaded: inflector_helper
INFO - 2018-02-21 12:09:03 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-21 12:09:03 --> Model Class Initialized
INFO - 2018-02-21 12:09:03 --> Model Class Initialized
INFO - 2018-02-21 12:09:03 --> Model Class Initialized
INFO - 2018-02-21 12:09:03 --> Final output sent to browser
DEBUG - 2018-02-21 12:09:03 --> Total execution time: 0.0065
INFO - 2018-02-21 12:10:39 --> Config Class Initialized
INFO - 2018-02-21 12:10:39 --> Hooks Class Initialized
DEBUG - 2018-02-21 12:10:39 --> UTF-8 Support Enabled
INFO - 2018-02-21 12:10:39 --> Utf8 Class Initialized
INFO - 2018-02-21 12:10:39 --> URI Class Initialized
INFO - 2018-02-21 12:10:39 --> Router Class Initialized
INFO - 2018-02-21 12:10:39 --> Output Class Initialized
INFO - 2018-02-21 12:10:39 --> Security Class Initialized
DEBUG - 2018-02-21 12:10:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-21 12:10:39 --> Input Class Initialized
INFO - 2018-02-21 12:10:39 --> Language Class Initialized
INFO - 2018-02-21 12:10:39 --> Loader Class Initialized
INFO - 2018-02-21 12:10:39 --> Helper loaded: url_helper
INFO - 2018-02-21 12:10:39 --> Helper loaded: file_helper
INFO - 2018-02-21 12:10:39 --> Helper loaded: email_helper
INFO - 2018-02-21 12:10:39 --> Helper loaded: common_helper
INFO - 2018-02-21 12:10:39 --> Database Driver Class Initialized
DEBUG - 2018-02-21 12:10:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-21 12:10:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-21 12:10:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-21 12:10:39 --> Pagination Class Initialized
INFO - 2018-02-21 12:10:39 --> Helper loaded: form_helper
INFO - 2018-02-21 12:10:39 --> Form Validation Class Initialized
INFO - 2018-02-21 12:10:39 --> Model Class Initialized
INFO - 2018-02-21 12:10:39 --> Controller Class Initialized
DEBUG - 2018-02-21 12:10:39 --> Config file loaded: /var/www/html/project/radio/application/config/rest.php
INFO - 2018-02-21 12:10:39 --> Helper loaded: inflector_helper
INFO - 2018-02-21 12:10:39 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-21 12:10:39 --> Model Class Initialized
INFO - 2018-02-21 12:10:39 --> Model Class Initialized
INFO - 2018-02-21 12:10:39 --> Model Class Initialized
INFO - 2018-02-21 12:10:39 --> Final output sent to browser
DEBUG - 2018-02-21 12:10:39 --> Total execution time: 0.0065
INFO - 2018-02-21 12:12:00 --> Config Class Initialized
INFO - 2018-02-21 12:12:00 --> Hooks Class Initialized
DEBUG - 2018-02-21 12:12:00 --> UTF-8 Support Enabled
INFO - 2018-02-21 12:12:00 --> Utf8 Class Initialized
INFO - 2018-02-21 12:12:00 --> URI Class Initialized
INFO - 2018-02-21 12:12:00 --> Router Class Initialized
INFO - 2018-02-21 12:12:00 --> Output Class Initialized
INFO - 2018-02-21 12:12:00 --> Security Class Initialized
DEBUG - 2018-02-21 12:12:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-21 12:12:00 --> Input Class Initialized
INFO - 2018-02-21 12:12:00 --> Language Class Initialized
INFO - 2018-02-21 12:12:00 --> Loader Class Initialized
INFO - 2018-02-21 12:12:00 --> Helper loaded: url_helper
INFO - 2018-02-21 12:12:00 --> Helper loaded: file_helper
INFO - 2018-02-21 12:12:00 --> Helper loaded: email_helper
INFO - 2018-02-21 12:12:00 --> Helper loaded: common_helper
INFO - 2018-02-21 12:12:00 --> Database Driver Class Initialized
DEBUG - 2018-02-21 12:12:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-21 12:12:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-21 12:12:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-21 12:12:00 --> Pagination Class Initialized
INFO - 2018-02-21 12:12:00 --> Helper loaded: form_helper
INFO - 2018-02-21 12:12:00 --> Form Validation Class Initialized
INFO - 2018-02-21 12:12:00 --> Model Class Initialized
INFO - 2018-02-21 12:12:00 --> Controller Class Initialized
DEBUG - 2018-02-21 12:12:00 --> Config file loaded: /var/www/html/project/radio/application/config/rest.php
INFO - 2018-02-21 12:12:00 --> Helper loaded: inflector_helper
INFO - 2018-02-21 12:12:00 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-21 12:12:00 --> Model Class Initialized
INFO - 2018-02-21 12:12:00 --> Model Class Initialized
INFO - 2018-02-21 12:12:00 --> Model Class Initialized
INFO - 2018-02-21 12:12:35 --> Config Class Initialized
INFO - 2018-02-21 12:12:35 --> Hooks Class Initialized
DEBUG - 2018-02-21 12:12:35 --> UTF-8 Support Enabled
INFO - 2018-02-21 12:12:35 --> Utf8 Class Initialized
INFO - 2018-02-21 12:12:35 --> URI Class Initialized
INFO - 2018-02-21 12:12:35 --> Router Class Initialized
INFO - 2018-02-21 12:12:35 --> Output Class Initialized
INFO - 2018-02-21 12:12:35 --> Security Class Initialized
DEBUG - 2018-02-21 12:12:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-21 12:12:35 --> Input Class Initialized
INFO - 2018-02-21 12:12:35 --> Language Class Initialized
INFO - 2018-02-21 12:12:35 --> Loader Class Initialized
INFO - 2018-02-21 12:12:35 --> Helper loaded: url_helper
INFO - 2018-02-21 12:12:35 --> Helper loaded: file_helper
INFO - 2018-02-21 12:12:35 --> Helper loaded: email_helper
INFO - 2018-02-21 12:12:35 --> Helper loaded: common_helper
INFO - 2018-02-21 12:12:35 --> Database Driver Class Initialized
DEBUG - 2018-02-21 12:12:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-21 12:12:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-21 12:12:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-21 12:12:35 --> Pagination Class Initialized
INFO - 2018-02-21 12:12:35 --> Helper loaded: form_helper
INFO - 2018-02-21 12:12:35 --> Form Validation Class Initialized
INFO - 2018-02-21 12:12:35 --> Model Class Initialized
INFO - 2018-02-21 12:12:35 --> Controller Class Initialized
DEBUG - 2018-02-21 12:12:35 --> Config file loaded: /var/www/html/project/radio/application/config/rest.php
INFO - 2018-02-21 12:12:35 --> Helper loaded: inflector_helper
INFO - 2018-02-21 12:12:35 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-21 12:12:35 --> Model Class Initialized
INFO - 2018-02-21 12:12:35 --> Model Class Initialized
INFO - 2018-02-21 12:12:35 --> Model Class Initialized
INFO - 2018-02-21 12:12:35 --> Final output sent to browser
DEBUG - 2018-02-21 12:12:35 --> Total execution time: 0.0078
INFO - 2018-02-21 12:14:57 --> Config Class Initialized
INFO - 2018-02-21 12:14:57 --> Hooks Class Initialized
DEBUG - 2018-02-21 12:14:57 --> UTF-8 Support Enabled
INFO - 2018-02-21 12:14:57 --> Utf8 Class Initialized
INFO - 2018-02-21 12:14:57 --> URI Class Initialized
INFO - 2018-02-21 12:14:57 --> Router Class Initialized
INFO - 2018-02-21 12:14:57 --> Output Class Initialized
INFO - 2018-02-21 12:14:57 --> Security Class Initialized
DEBUG - 2018-02-21 12:14:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-21 12:14:57 --> Input Class Initialized
INFO - 2018-02-21 12:14:57 --> Language Class Initialized
INFO - 2018-02-21 12:14:57 --> Loader Class Initialized
INFO - 2018-02-21 12:14:57 --> Helper loaded: url_helper
INFO - 2018-02-21 12:14:57 --> Helper loaded: file_helper
INFO - 2018-02-21 12:14:57 --> Helper loaded: email_helper
INFO - 2018-02-21 12:14:57 --> Helper loaded: common_helper
INFO - 2018-02-21 12:14:57 --> Database Driver Class Initialized
DEBUG - 2018-02-21 12:14:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-21 12:14:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-21 12:14:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-21 12:14:57 --> Pagination Class Initialized
INFO - 2018-02-21 12:14:57 --> Helper loaded: form_helper
INFO - 2018-02-21 12:14:57 --> Form Validation Class Initialized
INFO - 2018-02-21 12:14:57 --> Model Class Initialized
INFO - 2018-02-21 12:14:57 --> Controller Class Initialized
DEBUG - 2018-02-21 12:14:57 --> Config file loaded: /var/www/html/project/radio/application/config/rest.php
INFO - 2018-02-21 12:14:57 --> Helper loaded: inflector_helper
INFO - 2018-02-21 12:14:57 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-21 12:14:57 --> Model Class Initialized
INFO - 2018-02-21 12:14:57 --> Model Class Initialized
INFO - 2018-02-21 12:14:57 --> Model Class Initialized
INFO - 2018-02-21 12:15:49 --> Config Class Initialized
INFO - 2018-02-21 12:15:49 --> Hooks Class Initialized
DEBUG - 2018-02-21 12:15:49 --> UTF-8 Support Enabled
INFO - 2018-02-21 12:15:49 --> Utf8 Class Initialized
INFO - 2018-02-21 12:15:49 --> URI Class Initialized
INFO - 2018-02-21 12:15:49 --> Router Class Initialized
INFO - 2018-02-21 12:15:49 --> Output Class Initialized
INFO - 2018-02-21 12:15:49 --> Security Class Initialized
DEBUG - 2018-02-21 12:15:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-21 12:15:49 --> Input Class Initialized
INFO - 2018-02-21 12:15:49 --> Language Class Initialized
INFO - 2018-02-21 12:15:49 --> Loader Class Initialized
INFO - 2018-02-21 12:15:49 --> Helper loaded: url_helper
INFO - 2018-02-21 12:15:49 --> Helper loaded: file_helper
INFO - 2018-02-21 12:15:49 --> Helper loaded: email_helper
INFO - 2018-02-21 12:15:49 --> Helper loaded: common_helper
INFO - 2018-02-21 12:15:49 --> Database Driver Class Initialized
DEBUG - 2018-02-21 12:15:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-21 12:15:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-21 12:15:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-21 12:15:49 --> Pagination Class Initialized
INFO - 2018-02-21 12:15:49 --> Helper loaded: form_helper
INFO - 2018-02-21 12:15:49 --> Form Validation Class Initialized
INFO - 2018-02-21 12:15:49 --> Model Class Initialized
INFO - 2018-02-21 12:15:49 --> Controller Class Initialized
DEBUG - 2018-02-21 12:15:49 --> Config file loaded: /var/www/html/project/radio/application/config/rest.php
INFO - 2018-02-21 12:15:49 --> Helper loaded: inflector_helper
INFO - 2018-02-21 12:15:49 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-21 12:15:49 --> Model Class Initialized
INFO - 2018-02-21 12:15:49 --> Model Class Initialized
INFO - 2018-02-21 12:15:49 --> Model Class Initialized
INFO - 2018-02-21 12:15:49 --> Final output sent to browser
DEBUG - 2018-02-21 12:15:49 --> Total execution time: 0.0109
INFO - 2018-02-21 12:16:15 --> Config Class Initialized
INFO - 2018-02-21 12:16:15 --> Hooks Class Initialized
DEBUG - 2018-02-21 12:16:15 --> UTF-8 Support Enabled
INFO - 2018-02-21 12:16:15 --> Utf8 Class Initialized
INFO - 2018-02-21 12:16:15 --> URI Class Initialized
INFO - 2018-02-21 12:16:15 --> Router Class Initialized
INFO - 2018-02-21 12:16:15 --> Output Class Initialized
INFO - 2018-02-21 12:16:15 --> Security Class Initialized
DEBUG - 2018-02-21 12:16:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-21 12:16:15 --> Input Class Initialized
INFO - 2018-02-21 12:16:15 --> Language Class Initialized
INFO - 2018-02-21 12:16:15 --> Loader Class Initialized
INFO - 2018-02-21 12:16:15 --> Helper loaded: url_helper
INFO - 2018-02-21 12:16:15 --> Helper loaded: file_helper
INFO - 2018-02-21 12:16:15 --> Helper loaded: email_helper
INFO - 2018-02-21 12:16:15 --> Helper loaded: common_helper
INFO - 2018-02-21 12:16:15 --> Database Driver Class Initialized
DEBUG - 2018-02-21 12:16:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-21 12:16:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-21 12:16:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-21 12:16:15 --> Pagination Class Initialized
INFO - 2018-02-21 12:16:15 --> Helper loaded: form_helper
INFO - 2018-02-21 12:16:15 --> Form Validation Class Initialized
INFO - 2018-02-21 12:16:15 --> Model Class Initialized
INFO - 2018-02-21 12:16:15 --> Controller Class Initialized
DEBUG - 2018-02-21 12:16:15 --> Config file loaded: /var/www/html/project/radio/application/config/rest.php
INFO - 2018-02-21 12:16:15 --> Helper loaded: inflector_helper
INFO - 2018-02-21 12:16:15 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-21 12:16:15 --> Model Class Initialized
INFO - 2018-02-21 12:16:15 --> Model Class Initialized
INFO - 2018-02-21 12:16:15 --> Model Class Initialized
INFO - 2018-02-21 12:16:15 --> Final output sent to browser
DEBUG - 2018-02-21 12:16:15 --> Total execution time: 0.0065
INFO - 2018-02-21 12:16:24 --> Config Class Initialized
INFO - 2018-02-21 12:16:24 --> Hooks Class Initialized
DEBUG - 2018-02-21 12:16:24 --> UTF-8 Support Enabled
INFO - 2018-02-21 12:16:24 --> Utf8 Class Initialized
INFO - 2018-02-21 12:16:24 --> URI Class Initialized
INFO - 2018-02-21 12:16:24 --> Router Class Initialized
INFO - 2018-02-21 12:16:24 --> Output Class Initialized
INFO - 2018-02-21 12:16:24 --> Security Class Initialized
DEBUG - 2018-02-21 12:16:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-21 12:16:24 --> Input Class Initialized
INFO - 2018-02-21 12:16:24 --> Language Class Initialized
INFO - 2018-02-21 12:16:24 --> Loader Class Initialized
INFO - 2018-02-21 12:16:24 --> Helper loaded: url_helper
INFO - 2018-02-21 12:16:24 --> Helper loaded: file_helper
INFO - 2018-02-21 12:16:24 --> Helper loaded: email_helper
INFO - 2018-02-21 12:16:24 --> Helper loaded: common_helper
INFO - 2018-02-21 12:16:24 --> Database Driver Class Initialized
DEBUG - 2018-02-21 12:16:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-21 12:16:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-21 12:16:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-21 12:16:24 --> Pagination Class Initialized
INFO - 2018-02-21 12:16:24 --> Helper loaded: form_helper
INFO - 2018-02-21 12:16:24 --> Form Validation Class Initialized
INFO - 2018-02-21 12:16:24 --> Model Class Initialized
INFO - 2018-02-21 12:16:24 --> Controller Class Initialized
DEBUG - 2018-02-21 12:16:24 --> Config file loaded: /var/www/html/project/radio/application/config/rest.php
INFO - 2018-02-21 12:16:24 --> Helper loaded: inflector_helper
INFO - 2018-02-21 12:16:24 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-21 12:16:24 --> Model Class Initialized
INFO - 2018-02-21 12:16:24 --> Model Class Initialized
INFO - 2018-02-21 12:16:24 --> Model Class Initialized
INFO - 2018-02-21 12:16:24 --> Final output sent to browser
DEBUG - 2018-02-21 12:16:24 --> Total execution time: 0.0095
INFO - 2018-02-21 14:10:05 --> Config Class Initialized
INFO - 2018-02-21 14:10:05 --> Hooks Class Initialized
DEBUG - 2018-02-21 14:10:05 --> UTF-8 Support Enabled
INFO - 2018-02-21 14:10:05 --> Utf8 Class Initialized
INFO - 2018-02-21 14:10:05 --> URI Class Initialized
INFO - 2018-02-21 14:10:05 --> Router Class Initialized
INFO - 2018-02-21 14:10:05 --> Output Class Initialized
INFO - 2018-02-21 14:10:05 --> Security Class Initialized
DEBUG - 2018-02-21 14:10:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-21 14:10:05 --> Input Class Initialized
INFO - 2018-02-21 14:10:05 --> Language Class Initialized
INFO - 2018-02-21 14:10:05 --> Loader Class Initialized
INFO - 2018-02-21 14:10:05 --> Helper loaded: url_helper
INFO - 2018-02-21 14:10:05 --> Helper loaded: file_helper
INFO - 2018-02-21 14:10:05 --> Helper loaded: email_helper
INFO - 2018-02-21 14:10:05 --> Helper loaded: common_helper
INFO - 2018-02-21 14:10:05 --> Database Driver Class Initialized
DEBUG - 2018-02-21 14:10:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-21 14:10:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-21 14:10:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-21 14:10:05 --> Pagination Class Initialized
INFO - 2018-02-21 14:10:05 --> Helper loaded: form_helper
INFO - 2018-02-21 14:10:05 --> Form Validation Class Initialized
INFO - 2018-02-21 14:10:05 --> Model Class Initialized
INFO - 2018-02-21 14:10:05 --> Controller Class Initialized
INFO - 2018-02-21 14:10:05 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-21 14:10:05 --> Config Class Initialized
INFO - 2018-02-21 14:10:05 --> Hooks Class Initialized
DEBUG - 2018-02-21 14:10:05 --> UTF-8 Support Enabled
INFO - 2018-02-21 14:10:05 --> Utf8 Class Initialized
INFO - 2018-02-21 14:10:05 --> URI Class Initialized
DEBUG - 2018-02-21 14:10:05 --> No URI present. Default controller set.
INFO - 2018-02-21 14:10:05 --> Router Class Initialized
INFO - 2018-02-21 14:10:05 --> Output Class Initialized
INFO - 2018-02-21 14:10:05 --> Security Class Initialized
DEBUG - 2018-02-21 14:10:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-21 14:10:05 --> Input Class Initialized
INFO - 2018-02-21 14:10:05 --> Language Class Initialized
INFO - 2018-02-21 14:10:05 --> Loader Class Initialized
INFO - 2018-02-21 14:10:05 --> Helper loaded: url_helper
INFO - 2018-02-21 14:10:05 --> Helper loaded: file_helper
INFO - 2018-02-21 14:10:05 --> Helper loaded: email_helper
INFO - 2018-02-21 14:10:05 --> Helper loaded: common_helper
INFO - 2018-02-21 14:10:05 --> Database Driver Class Initialized
DEBUG - 2018-02-21 14:10:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-21 14:10:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-21 14:10:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-21 14:10:05 --> Pagination Class Initialized
INFO - 2018-02-21 14:10:05 --> Helper loaded: form_helper
INFO - 2018-02-21 14:10:05 --> Form Validation Class Initialized
INFO - 2018-02-21 14:10:05 --> Model Class Initialized
INFO - 2018-02-21 14:10:05 --> Controller Class Initialized
INFO - 2018-02-21 14:10:05 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-21 14:10:05 --> Model Class Initialized
INFO - 2018-02-21 14:10:05 --> Model Class Initialized
INFO - 2018-02-21 14:10:05 --> File loaded: /var/www/html/project/radio/application/views/index/index.php
INFO - 2018-02-21 14:10:05 --> Final output sent to browser
DEBUG - 2018-02-21 14:10:05 --> Total execution time: 0.0558
INFO - 2018-02-21 15:14:57 --> Config Class Initialized
INFO - 2018-02-21 15:14:57 --> Hooks Class Initialized
DEBUG - 2018-02-21 15:14:57 --> UTF-8 Support Enabled
INFO - 2018-02-21 15:14:57 --> Utf8 Class Initialized
INFO - 2018-02-21 15:14:57 --> URI Class Initialized
INFO - 2018-02-21 15:14:57 --> Router Class Initialized
INFO - 2018-02-21 15:14:57 --> Output Class Initialized
INFO - 2018-02-21 15:14:57 --> Security Class Initialized
DEBUG - 2018-02-21 15:14:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-21 15:14:57 --> Input Class Initialized
INFO - 2018-02-21 15:14:57 --> Language Class Initialized
ERROR - 2018-02-21 15:14:57 --> Severity: error --> Exception: syntax error, unexpected ']' /var/www/html/project/radio/application/controllers/api/Fetchappdata.php 164
INFO - 2018-02-21 15:15:21 --> Config Class Initialized
INFO - 2018-02-21 15:15:21 --> Hooks Class Initialized
DEBUG - 2018-02-21 15:15:21 --> UTF-8 Support Enabled
INFO - 2018-02-21 15:15:21 --> Utf8 Class Initialized
INFO - 2018-02-21 15:15:21 --> URI Class Initialized
INFO - 2018-02-21 15:15:21 --> Router Class Initialized
INFO - 2018-02-21 15:15:21 --> Output Class Initialized
INFO - 2018-02-21 15:15:21 --> Security Class Initialized
DEBUG - 2018-02-21 15:15:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-21 15:15:21 --> Input Class Initialized
INFO - 2018-02-21 15:15:21 --> Language Class Initialized
INFO - 2018-02-21 15:15:21 --> Loader Class Initialized
INFO - 2018-02-21 15:15:21 --> Helper loaded: url_helper
INFO - 2018-02-21 15:15:21 --> Helper loaded: file_helper
INFO - 2018-02-21 15:15:21 --> Helper loaded: email_helper
INFO - 2018-02-21 15:15:21 --> Helper loaded: common_helper
INFO - 2018-02-21 15:15:21 --> Database Driver Class Initialized
DEBUG - 2018-02-21 15:15:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-21 15:15:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-21 15:15:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-21 15:15:21 --> Pagination Class Initialized
INFO - 2018-02-21 15:15:21 --> Helper loaded: form_helper
INFO - 2018-02-21 15:15:21 --> Form Validation Class Initialized
INFO - 2018-02-21 15:15:21 --> Model Class Initialized
INFO - 2018-02-21 15:15:21 --> Controller Class Initialized
DEBUG - 2018-02-21 15:15:21 --> Config file loaded: /var/www/html/project/radio/application/config/rest.php
INFO - 2018-02-21 15:15:21 --> Helper loaded: inflector_helper
INFO - 2018-02-21 15:15:21 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-21 15:15:21 --> Model Class Initialized
INFO - 2018-02-21 15:15:21 --> Model Class Initialized
INFO - 2018-02-21 15:15:21 --> Model Class Initialized
INFO - 2018-02-21 15:15:21 --> Model Class Initialized
INFO - 2018-02-21 15:15:21 --> Model Class Initialized
ERROR - 2018-02-21 15:15:21 --> Severity: Notice --> Undefined index: pageNo /var/www/html/project/radio/application/controllers/api/Fetchappdata.php 155
ERROR - 2018-02-21 15:15:21 --> Severity: Notice --> Undefined index: iSubCategoryId /var/www/html/project/radio/application/controllers/api/Fetchappdata.php 158
ERROR - 2018-02-21 15:15:21 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '-20, 20' at line 5 - Invalid query: SELECT `t`.*
FROM `tracks ad` `t`
WHERE `t`.`is_deleted` =0
AND `t`.`iSubCategoryId` IS NULL
 LIMIT -20, 20
INFO - 2018-02-21 15:15:21 --> Language file loaded: language/english/db_lang.php
INFO - 2018-02-21 15:15:59 --> Config Class Initialized
INFO - 2018-02-21 15:15:59 --> Hooks Class Initialized
DEBUG - 2018-02-21 15:15:59 --> UTF-8 Support Enabled
INFO - 2018-02-21 15:15:59 --> Utf8 Class Initialized
INFO - 2018-02-21 15:15:59 --> URI Class Initialized
INFO - 2018-02-21 15:15:59 --> Router Class Initialized
INFO - 2018-02-21 15:15:59 --> Output Class Initialized
INFO - 2018-02-21 15:15:59 --> Security Class Initialized
DEBUG - 2018-02-21 15:15:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-21 15:15:59 --> Input Class Initialized
INFO - 2018-02-21 15:15:59 --> Language Class Initialized
INFO - 2018-02-21 15:15:59 --> Loader Class Initialized
INFO - 2018-02-21 15:15:59 --> Helper loaded: url_helper
INFO - 2018-02-21 15:15:59 --> Helper loaded: file_helper
INFO - 2018-02-21 15:15:59 --> Helper loaded: email_helper
INFO - 2018-02-21 15:15:59 --> Helper loaded: common_helper
INFO - 2018-02-21 15:15:59 --> Database Driver Class Initialized
DEBUG - 2018-02-21 15:15:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-21 15:15:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-21 15:15:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-21 15:15:59 --> Pagination Class Initialized
INFO - 2018-02-21 15:15:59 --> Helper loaded: form_helper
INFO - 2018-02-21 15:15:59 --> Form Validation Class Initialized
INFO - 2018-02-21 15:15:59 --> Model Class Initialized
INFO - 2018-02-21 15:15:59 --> Controller Class Initialized
DEBUG - 2018-02-21 15:15:59 --> Config file loaded: /var/www/html/project/radio/application/config/rest.php
INFO - 2018-02-21 15:15:59 --> Helper loaded: inflector_helper
INFO - 2018-02-21 15:15:59 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-21 15:15:59 --> Model Class Initialized
INFO - 2018-02-21 15:15:59 --> Model Class Initialized
INFO - 2018-02-21 15:15:59 --> Model Class Initialized
INFO - 2018-02-21 15:15:59 --> Model Class Initialized
INFO - 2018-02-21 15:15:59 --> Model Class Initialized
INFO - 2018-02-21 15:15:59 --> Final output sent to browser
DEBUG - 2018-02-21 15:15:59 --> Total execution time: 0.0057
INFO - 2018-02-21 15:16:06 --> Config Class Initialized
INFO - 2018-02-21 15:16:06 --> Hooks Class Initialized
DEBUG - 2018-02-21 15:16:06 --> UTF-8 Support Enabled
INFO - 2018-02-21 15:16:06 --> Utf8 Class Initialized
INFO - 2018-02-21 15:16:06 --> URI Class Initialized
INFO - 2018-02-21 15:16:06 --> Router Class Initialized
INFO - 2018-02-21 15:16:06 --> Output Class Initialized
INFO - 2018-02-21 15:16:06 --> Security Class Initialized
DEBUG - 2018-02-21 15:16:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-21 15:16:06 --> Input Class Initialized
INFO - 2018-02-21 15:16:06 --> Language Class Initialized
INFO - 2018-02-21 15:16:06 --> Loader Class Initialized
INFO - 2018-02-21 15:16:06 --> Helper loaded: url_helper
INFO - 2018-02-21 15:16:06 --> Helper loaded: file_helper
INFO - 2018-02-21 15:16:06 --> Helper loaded: email_helper
INFO - 2018-02-21 15:16:06 --> Helper loaded: common_helper
INFO - 2018-02-21 15:16:06 --> Database Driver Class Initialized
DEBUG - 2018-02-21 15:16:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-21 15:16:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-21 15:16:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-21 15:16:06 --> Pagination Class Initialized
INFO - 2018-02-21 15:16:06 --> Helper loaded: form_helper
INFO - 2018-02-21 15:16:06 --> Form Validation Class Initialized
INFO - 2018-02-21 15:16:06 --> Model Class Initialized
INFO - 2018-02-21 15:16:06 --> Controller Class Initialized
DEBUG - 2018-02-21 15:16:06 --> Config file loaded: /var/www/html/project/radio/application/config/rest.php
INFO - 2018-02-21 15:16:06 --> Helper loaded: inflector_helper
INFO - 2018-02-21 15:16:06 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-21 15:16:06 --> Model Class Initialized
INFO - 2018-02-21 15:16:06 --> Model Class Initialized
INFO - 2018-02-21 15:16:06 --> Model Class Initialized
INFO - 2018-02-21 15:16:06 --> Model Class Initialized
INFO - 2018-02-21 15:16:06 --> Model Class Initialized
INFO - 2018-02-21 15:16:06 --> Final output sent to browser
DEBUG - 2018-02-21 15:16:06 --> Total execution time: 0.0065
INFO - 2018-02-21 15:16:10 --> Config Class Initialized
INFO - 2018-02-21 15:16:10 --> Hooks Class Initialized
DEBUG - 2018-02-21 15:16:10 --> UTF-8 Support Enabled
INFO - 2018-02-21 15:16:10 --> Utf8 Class Initialized
INFO - 2018-02-21 15:16:10 --> URI Class Initialized
INFO - 2018-02-21 15:16:10 --> Router Class Initialized
INFO - 2018-02-21 15:16:10 --> Output Class Initialized
INFO - 2018-02-21 15:16:10 --> Security Class Initialized
DEBUG - 2018-02-21 15:16:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-21 15:16:10 --> Input Class Initialized
INFO - 2018-02-21 15:16:10 --> Language Class Initialized
INFO - 2018-02-21 15:16:10 --> Loader Class Initialized
INFO - 2018-02-21 15:16:10 --> Helper loaded: url_helper
INFO - 2018-02-21 15:16:10 --> Helper loaded: file_helper
INFO - 2018-02-21 15:16:10 --> Helper loaded: email_helper
INFO - 2018-02-21 15:16:10 --> Helper loaded: common_helper
INFO - 2018-02-21 15:16:10 --> Database Driver Class Initialized
DEBUG - 2018-02-21 15:16:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-21 15:16:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-21 15:16:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-21 15:16:10 --> Pagination Class Initialized
INFO - 2018-02-21 15:16:10 --> Helper loaded: form_helper
INFO - 2018-02-21 15:16:10 --> Form Validation Class Initialized
INFO - 2018-02-21 15:16:10 --> Model Class Initialized
INFO - 2018-02-21 15:16:10 --> Controller Class Initialized
DEBUG - 2018-02-21 15:16:10 --> Config file loaded: /var/www/html/project/radio/application/config/rest.php
INFO - 2018-02-21 15:16:10 --> Helper loaded: inflector_helper
INFO - 2018-02-21 15:16:10 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-21 15:16:10 --> Model Class Initialized
INFO - 2018-02-21 15:16:10 --> Model Class Initialized
INFO - 2018-02-21 15:16:10 --> Model Class Initialized
INFO - 2018-02-21 15:16:10 --> Model Class Initialized
INFO - 2018-02-21 15:16:10 --> Model Class Initialized
ERROR - 2018-02-21 15:16:10 --> Query error: Table 'radio.tracks ad' doesn't exist - Invalid query: SELECT `t`.*
FROM `tracks ad` `t`
WHERE `t`.`is_deleted` =0
AND `t`.`iSubCategoryId` = '1'
 LIMIT 20
INFO - 2018-02-21 15:16:10 --> Language file loaded: language/english/db_lang.php
INFO - 2018-02-21 15:16:37 --> Config Class Initialized
INFO - 2018-02-21 15:16:37 --> Hooks Class Initialized
DEBUG - 2018-02-21 15:16:37 --> UTF-8 Support Enabled
INFO - 2018-02-21 15:16:37 --> Utf8 Class Initialized
INFO - 2018-02-21 15:16:37 --> URI Class Initialized
INFO - 2018-02-21 15:16:37 --> Router Class Initialized
INFO - 2018-02-21 15:16:37 --> Output Class Initialized
INFO - 2018-02-21 15:16:37 --> Security Class Initialized
DEBUG - 2018-02-21 15:16:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-21 15:16:37 --> Input Class Initialized
INFO - 2018-02-21 15:16:37 --> Language Class Initialized
INFO - 2018-02-21 15:16:37 --> Loader Class Initialized
INFO - 2018-02-21 15:16:37 --> Helper loaded: url_helper
INFO - 2018-02-21 15:16:37 --> Helper loaded: file_helper
INFO - 2018-02-21 15:16:37 --> Helper loaded: email_helper
INFO - 2018-02-21 15:16:37 --> Helper loaded: common_helper
INFO - 2018-02-21 15:16:37 --> Database Driver Class Initialized
DEBUG - 2018-02-21 15:16:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-21 15:16:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-21 15:16:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-21 15:16:37 --> Pagination Class Initialized
INFO - 2018-02-21 15:16:37 --> Helper loaded: form_helper
INFO - 2018-02-21 15:16:37 --> Form Validation Class Initialized
INFO - 2018-02-21 15:16:37 --> Model Class Initialized
INFO - 2018-02-21 15:16:37 --> Controller Class Initialized
DEBUG - 2018-02-21 15:16:37 --> Config file loaded: /var/www/html/project/radio/application/config/rest.php
INFO - 2018-02-21 15:16:37 --> Helper loaded: inflector_helper
INFO - 2018-02-21 15:16:37 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-21 15:16:37 --> Model Class Initialized
INFO - 2018-02-21 15:16:37 --> Model Class Initialized
INFO - 2018-02-21 15:16:37 --> Model Class Initialized
INFO - 2018-02-21 15:16:37 --> Model Class Initialized
INFO - 2018-02-21 15:16:37 --> Model Class Initialized
ERROR - 2018-02-21 15:16:37 --> Query error: Unknown column 'tr.iTracksId' in 'on clause' - Invalid query: SELECT `te`.*, `t`.`iCategoryId`
FROM `tracks_extrafields` as `te`
JOIN `tracks` as `t` ON `t`.`iTracksId` = `tr`.`iTracksId`
WHERE `te`.`iTracksId` IN('3', '5', '7', '10')
INFO - 2018-02-21 15:16:37 --> Language file loaded: language/english/db_lang.php
INFO - 2018-02-21 15:17:07 --> Config Class Initialized
INFO - 2018-02-21 15:17:07 --> Hooks Class Initialized
DEBUG - 2018-02-21 15:17:07 --> UTF-8 Support Enabled
INFO - 2018-02-21 15:17:07 --> Utf8 Class Initialized
INFO - 2018-02-21 15:17:07 --> URI Class Initialized
INFO - 2018-02-21 15:17:07 --> Router Class Initialized
INFO - 2018-02-21 15:17:07 --> Output Class Initialized
INFO - 2018-02-21 15:17:07 --> Security Class Initialized
DEBUG - 2018-02-21 15:17:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-21 15:17:07 --> Input Class Initialized
INFO - 2018-02-21 15:17:07 --> Language Class Initialized
INFO - 2018-02-21 15:17:07 --> Loader Class Initialized
INFO - 2018-02-21 15:17:07 --> Helper loaded: url_helper
INFO - 2018-02-21 15:17:07 --> Helper loaded: file_helper
INFO - 2018-02-21 15:17:07 --> Helper loaded: email_helper
INFO - 2018-02-21 15:17:07 --> Helper loaded: common_helper
INFO - 2018-02-21 15:17:07 --> Database Driver Class Initialized
DEBUG - 2018-02-21 15:17:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-21 15:17:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-21 15:17:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-21 15:17:07 --> Pagination Class Initialized
INFO - 2018-02-21 15:17:07 --> Helper loaded: form_helper
INFO - 2018-02-21 15:17:07 --> Form Validation Class Initialized
INFO - 2018-02-21 15:17:07 --> Model Class Initialized
INFO - 2018-02-21 15:17:07 --> Controller Class Initialized
DEBUG - 2018-02-21 15:17:07 --> Config file loaded: /var/www/html/project/radio/application/config/rest.php
INFO - 2018-02-21 15:17:07 --> Helper loaded: inflector_helper
INFO - 2018-02-21 15:17:07 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-21 15:17:07 --> Model Class Initialized
INFO - 2018-02-21 15:17:07 --> Model Class Initialized
INFO - 2018-02-21 15:17:07 --> Model Class Initialized
INFO - 2018-02-21 15:17:07 --> Model Class Initialized
INFO - 2018-02-21 15:17:07 --> Model Class Initialized
ERROR - 2018-02-21 15:17:07 --> Query error: Table 'radio.userFavourite' doesn't exist - Invalid query: SELECT `uf`.*
FROM `userFavourite` as `uf`
WHERE `uf`.`iTracksId` IN('3', '5', '7', '10')
AND `uf`.`iUserId` = '1'
INFO - 2018-02-21 15:17:07 --> Language file loaded: language/english/db_lang.php
INFO - 2018-02-21 15:18:22 --> Config Class Initialized
INFO - 2018-02-21 15:18:22 --> Hooks Class Initialized
DEBUG - 2018-02-21 15:18:22 --> UTF-8 Support Enabled
INFO - 2018-02-21 15:18:22 --> Utf8 Class Initialized
INFO - 2018-02-21 15:18:22 --> URI Class Initialized
INFO - 2018-02-21 15:18:22 --> Router Class Initialized
INFO - 2018-02-21 15:18:22 --> Output Class Initialized
INFO - 2018-02-21 15:18:22 --> Security Class Initialized
DEBUG - 2018-02-21 15:18:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-21 15:18:22 --> Input Class Initialized
INFO - 2018-02-21 15:18:22 --> Language Class Initialized
INFO - 2018-02-21 15:18:22 --> Loader Class Initialized
INFO - 2018-02-21 15:18:22 --> Helper loaded: url_helper
INFO - 2018-02-21 15:18:22 --> Helper loaded: file_helper
INFO - 2018-02-21 15:18:22 --> Helper loaded: email_helper
INFO - 2018-02-21 15:18:22 --> Helper loaded: common_helper
INFO - 2018-02-21 15:18:22 --> Database Driver Class Initialized
DEBUG - 2018-02-21 15:18:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-21 15:18:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-21 15:18:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-21 15:18:22 --> Pagination Class Initialized
INFO - 2018-02-21 15:18:22 --> Helper loaded: form_helper
INFO - 2018-02-21 15:18:22 --> Form Validation Class Initialized
INFO - 2018-02-21 15:18:22 --> Model Class Initialized
INFO - 2018-02-21 15:18:22 --> Controller Class Initialized
DEBUG - 2018-02-21 15:18:22 --> Config file loaded: /var/www/html/project/radio/application/config/rest.php
INFO - 2018-02-21 15:18:22 --> Helper loaded: inflector_helper
INFO - 2018-02-21 15:18:22 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-21 15:18:22 --> Model Class Initialized
INFO - 2018-02-21 15:18:22 --> Model Class Initialized
INFO - 2018-02-21 15:18:22 --> Model Class Initialized
INFO - 2018-02-21 15:18:22 --> Model Class Initialized
INFO - 2018-02-21 15:18:22 --> Model Class Initialized
INFO - 2018-02-21 15:19:05 --> Config Class Initialized
INFO - 2018-02-21 15:19:05 --> Hooks Class Initialized
DEBUG - 2018-02-21 15:19:05 --> UTF-8 Support Enabled
INFO - 2018-02-21 15:19:05 --> Utf8 Class Initialized
INFO - 2018-02-21 15:19:05 --> URI Class Initialized
INFO - 2018-02-21 15:19:05 --> Router Class Initialized
INFO - 2018-02-21 15:19:05 --> Output Class Initialized
INFO - 2018-02-21 15:19:05 --> Security Class Initialized
DEBUG - 2018-02-21 15:19:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-21 15:19:05 --> Input Class Initialized
INFO - 2018-02-21 15:19:05 --> Language Class Initialized
INFO - 2018-02-21 15:19:05 --> Loader Class Initialized
INFO - 2018-02-21 15:19:05 --> Helper loaded: url_helper
INFO - 2018-02-21 15:19:05 --> Helper loaded: file_helper
INFO - 2018-02-21 15:19:05 --> Helper loaded: email_helper
INFO - 2018-02-21 15:19:05 --> Helper loaded: common_helper
INFO - 2018-02-21 15:19:05 --> Database Driver Class Initialized
DEBUG - 2018-02-21 15:19:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-21 15:19:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-21 15:19:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-21 15:19:05 --> Pagination Class Initialized
INFO - 2018-02-21 15:19:05 --> Helper loaded: form_helper
INFO - 2018-02-21 15:19:05 --> Form Validation Class Initialized
INFO - 2018-02-21 15:19:05 --> Model Class Initialized
INFO - 2018-02-21 15:19:05 --> Controller Class Initialized
DEBUG - 2018-02-21 15:19:05 --> Config file loaded: /var/www/html/project/radio/application/config/rest.php
INFO - 2018-02-21 15:19:05 --> Helper loaded: inflector_helper
INFO - 2018-02-21 15:19:05 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-21 15:19:05 --> Model Class Initialized
INFO - 2018-02-21 15:19:05 --> Model Class Initialized
INFO - 2018-02-21 15:19:05 --> Model Class Initialized
INFO - 2018-02-21 15:19:05 --> Model Class Initialized
INFO - 2018-02-21 15:19:05 --> Model Class Initialized
INFO - 2018-02-21 15:19:56 --> Config Class Initialized
INFO - 2018-02-21 15:19:56 --> Hooks Class Initialized
DEBUG - 2018-02-21 15:19:56 --> UTF-8 Support Enabled
INFO - 2018-02-21 15:19:56 --> Utf8 Class Initialized
INFO - 2018-02-21 15:19:56 --> URI Class Initialized
INFO - 2018-02-21 15:19:56 --> Router Class Initialized
INFO - 2018-02-21 15:19:56 --> Output Class Initialized
INFO - 2018-02-21 15:19:56 --> Security Class Initialized
DEBUG - 2018-02-21 15:19:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-21 15:19:56 --> Input Class Initialized
INFO - 2018-02-21 15:19:56 --> Language Class Initialized
INFO - 2018-02-21 15:19:56 --> Loader Class Initialized
INFO - 2018-02-21 15:19:56 --> Helper loaded: url_helper
INFO - 2018-02-21 15:19:56 --> Helper loaded: file_helper
INFO - 2018-02-21 15:19:56 --> Helper loaded: email_helper
INFO - 2018-02-21 15:19:56 --> Helper loaded: common_helper
INFO - 2018-02-21 15:19:56 --> Database Driver Class Initialized
DEBUG - 2018-02-21 15:19:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-21 15:19:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-21 15:19:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-21 15:19:56 --> Pagination Class Initialized
INFO - 2018-02-21 15:19:56 --> Helper loaded: form_helper
INFO - 2018-02-21 15:19:56 --> Form Validation Class Initialized
INFO - 2018-02-21 15:19:56 --> Model Class Initialized
INFO - 2018-02-21 15:19:56 --> Controller Class Initialized
DEBUG - 2018-02-21 15:19:56 --> Config file loaded: /var/www/html/project/radio/application/config/rest.php
INFO - 2018-02-21 15:19:56 --> Helper loaded: inflector_helper
INFO - 2018-02-21 15:19:56 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-21 15:19:56 --> Model Class Initialized
INFO - 2018-02-21 15:19:56 --> Model Class Initialized
INFO - 2018-02-21 15:19:56 --> Model Class Initialized
INFO - 2018-02-21 15:19:56 --> Model Class Initialized
INFO - 2018-02-21 15:19:56 --> Model Class Initialized
INFO - 2018-02-21 15:20:01 --> Config Class Initialized
INFO - 2018-02-21 15:20:01 --> Hooks Class Initialized
DEBUG - 2018-02-21 15:20:01 --> UTF-8 Support Enabled
INFO - 2018-02-21 15:20:01 --> Utf8 Class Initialized
INFO - 2018-02-21 15:20:01 --> URI Class Initialized
INFO - 2018-02-21 15:20:01 --> Router Class Initialized
INFO - 2018-02-21 15:20:01 --> Output Class Initialized
INFO - 2018-02-21 15:20:01 --> Security Class Initialized
DEBUG - 2018-02-21 15:20:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-21 15:20:01 --> Input Class Initialized
INFO - 2018-02-21 15:20:01 --> Language Class Initialized
INFO - 2018-02-21 15:20:01 --> Loader Class Initialized
INFO - 2018-02-21 15:20:01 --> Helper loaded: url_helper
INFO - 2018-02-21 15:20:01 --> Helper loaded: file_helper
INFO - 2018-02-21 15:20:01 --> Helper loaded: email_helper
INFO - 2018-02-21 15:20:01 --> Helper loaded: common_helper
INFO - 2018-02-21 15:20:01 --> Database Driver Class Initialized
DEBUG - 2018-02-21 15:20:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-21 15:20:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-21 15:20:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-21 15:20:01 --> Pagination Class Initialized
INFO - 2018-02-21 15:20:01 --> Helper loaded: form_helper
INFO - 2018-02-21 15:20:01 --> Form Validation Class Initialized
INFO - 2018-02-21 15:20:01 --> Model Class Initialized
INFO - 2018-02-21 15:20:01 --> Controller Class Initialized
DEBUG - 2018-02-21 15:20:01 --> Config file loaded: /var/www/html/project/radio/application/config/rest.php
INFO - 2018-02-21 15:20:01 --> Helper loaded: inflector_helper
INFO - 2018-02-21 15:20:01 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-21 15:20:01 --> Model Class Initialized
INFO - 2018-02-21 15:20:01 --> Model Class Initialized
INFO - 2018-02-21 15:20:01 --> Model Class Initialized
INFO - 2018-02-21 15:20:01 --> Model Class Initialized
INFO - 2018-02-21 15:20:01 --> Model Class Initialized
INFO - 2018-02-21 15:20:17 --> Config Class Initialized
INFO - 2018-02-21 15:20:17 --> Hooks Class Initialized
DEBUG - 2018-02-21 15:20:17 --> UTF-8 Support Enabled
INFO - 2018-02-21 15:20:17 --> Utf8 Class Initialized
INFO - 2018-02-21 15:20:17 --> URI Class Initialized
INFO - 2018-02-21 15:20:17 --> Router Class Initialized
INFO - 2018-02-21 15:20:17 --> Output Class Initialized
INFO - 2018-02-21 15:20:17 --> Security Class Initialized
DEBUG - 2018-02-21 15:20:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-21 15:20:17 --> Input Class Initialized
INFO - 2018-02-21 15:20:17 --> Language Class Initialized
INFO - 2018-02-21 15:20:17 --> Loader Class Initialized
INFO - 2018-02-21 15:20:17 --> Helper loaded: url_helper
INFO - 2018-02-21 15:20:17 --> Helper loaded: file_helper
INFO - 2018-02-21 15:20:17 --> Helper loaded: email_helper
INFO - 2018-02-21 15:20:17 --> Helper loaded: common_helper
INFO - 2018-02-21 15:20:17 --> Database Driver Class Initialized
DEBUG - 2018-02-21 15:20:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-21 15:20:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-21 15:20:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-21 15:20:17 --> Pagination Class Initialized
INFO - 2018-02-21 15:20:17 --> Helper loaded: form_helper
INFO - 2018-02-21 15:20:17 --> Form Validation Class Initialized
INFO - 2018-02-21 15:20:17 --> Model Class Initialized
INFO - 2018-02-21 15:20:17 --> Controller Class Initialized
DEBUG - 2018-02-21 15:20:17 --> Config file loaded: /var/www/html/project/radio/application/config/rest.php
INFO - 2018-02-21 15:20:17 --> Helper loaded: inflector_helper
INFO - 2018-02-21 15:20:17 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-21 15:20:17 --> Model Class Initialized
INFO - 2018-02-21 15:20:17 --> Model Class Initialized
INFO - 2018-02-21 15:20:17 --> Model Class Initialized
INFO - 2018-02-21 15:20:17 --> Model Class Initialized
INFO - 2018-02-21 15:20:17 --> Model Class Initialized
INFO - 2018-02-21 15:20:44 --> Config Class Initialized
INFO - 2018-02-21 15:20:44 --> Hooks Class Initialized
DEBUG - 2018-02-21 15:20:44 --> UTF-8 Support Enabled
INFO - 2018-02-21 15:20:44 --> Utf8 Class Initialized
INFO - 2018-02-21 15:20:44 --> URI Class Initialized
INFO - 2018-02-21 15:20:44 --> Router Class Initialized
INFO - 2018-02-21 15:20:44 --> Output Class Initialized
INFO - 2018-02-21 15:20:44 --> Security Class Initialized
DEBUG - 2018-02-21 15:20:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-21 15:20:44 --> Input Class Initialized
INFO - 2018-02-21 15:20:44 --> Language Class Initialized
INFO - 2018-02-21 15:20:44 --> Loader Class Initialized
INFO - 2018-02-21 15:20:44 --> Helper loaded: url_helper
INFO - 2018-02-21 15:20:44 --> Helper loaded: file_helper
INFO - 2018-02-21 15:20:44 --> Helper loaded: email_helper
INFO - 2018-02-21 15:20:44 --> Helper loaded: common_helper
INFO - 2018-02-21 15:20:44 --> Database Driver Class Initialized
DEBUG - 2018-02-21 15:20:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-21 15:20:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-21 15:20:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-21 15:20:44 --> Pagination Class Initialized
INFO - 2018-02-21 15:20:44 --> Helper loaded: form_helper
INFO - 2018-02-21 15:20:44 --> Form Validation Class Initialized
INFO - 2018-02-21 15:20:44 --> Model Class Initialized
INFO - 2018-02-21 15:20:44 --> Controller Class Initialized
DEBUG - 2018-02-21 15:20:44 --> Config file loaded: /var/www/html/project/radio/application/config/rest.php
INFO - 2018-02-21 15:20:44 --> Helper loaded: inflector_helper
INFO - 2018-02-21 15:20:44 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-21 15:20:44 --> Model Class Initialized
INFO - 2018-02-21 15:20:44 --> Model Class Initialized
INFO - 2018-02-21 15:20:44 --> Model Class Initialized
INFO - 2018-02-21 15:20:44 --> Model Class Initialized
INFO - 2018-02-21 15:20:44 --> Model Class Initialized
INFO - 2018-02-21 15:21:05 --> Config Class Initialized
INFO - 2018-02-21 15:21:05 --> Hooks Class Initialized
DEBUG - 2018-02-21 15:21:05 --> UTF-8 Support Enabled
INFO - 2018-02-21 15:21:05 --> Utf8 Class Initialized
INFO - 2018-02-21 15:21:05 --> URI Class Initialized
INFO - 2018-02-21 15:21:05 --> Router Class Initialized
INFO - 2018-02-21 15:21:05 --> Output Class Initialized
INFO - 2018-02-21 15:21:05 --> Security Class Initialized
DEBUG - 2018-02-21 15:21:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-21 15:21:05 --> Input Class Initialized
INFO - 2018-02-21 15:21:05 --> Language Class Initialized
INFO - 2018-02-21 15:21:05 --> Loader Class Initialized
INFO - 2018-02-21 15:21:05 --> Helper loaded: url_helper
INFO - 2018-02-21 15:21:05 --> Helper loaded: file_helper
INFO - 2018-02-21 15:21:05 --> Helper loaded: email_helper
INFO - 2018-02-21 15:21:05 --> Helper loaded: common_helper
INFO - 2018-02-21 15:21:05 --> Database Driver Class Initialized
DEBUG - 2018-02-21 15:21:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-21 15:21:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-21 15:21:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-21 15:21:05 --> Pagination Class Initialized
INFO - 2018-02-21 15:21:05 --> Helper loaded: form_helper
INFO - 2018-02-21 15:21:05 --> Form Validation Class Initialized
INFO - 2018-02-21 15:21:05 --> Model Class Initialized
INFO - 2018-02-21 15:21:05 --> Controller Class Initialized
DEBUG - 2018-02-21 15:21:05 --> Config file loaded: /var/www/html/project/radio/application/config/rest.php
INFO - 2018-02-21 15:21:05 --> Helper loaded: inflector_helper
INFO - 2018-02-21 15:21:05 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-21 15:21:05 --> Model Class Initialized
INFO - 2018-02-21 15:21:05 --> Model Class Initialized
INFO - 2018-02-21 15:21:05 --> Model Class Initialized
INFO - 2018-02-21 15:21:05 --> Model Class Initialized
INFO - 2018-02-21 15:21:05 --> Model Class Initialized
INFO - 2018-02-21 15:22:37 --> Config Class Initialized
INFO - 2018-02-21 15:22:37 --> Hooks Class Initialized
DEBUG - 2018-02-21 15:22:37 --> UTF-8 Support Enabled
INFO - 2018-02-21 15:22:37 --> Utf8 Class Initialized
INFO - 2018-02-21 15:22:37 --> URI Class Initialized
INFO - 2018-02-21 15:22:37 --> Router Class Initialized
INFO - 2018-02-21 15:22:37 --> Output Class Initialized
INFO - 2018-02-21 15:22:37 --> Security Class Initialized
DEBUG - 2018-02-21 15:22:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-21 15:22:37 --> Input Class Initialized
INFO - 2018-02-21 15:22:37 --> Language Class Initialized
INFO - 2018-02-21 15:22:37 --> Loader Class Initialized
INFO - 2018-02-21 15:22:37 --> Helper loaded: url_helper
INFO - 2018-02-21 15:22:37 --> Helper loaded: file_helper
INFO - 2018-02-21 15:22:37 --> Helper loaded: email_helper
INFO - 2018-02-21 15:22:37 --> Helper loaded: common_helper
INFO - 2018-02-21 15:22:37 --> Database Driver Class Initialized
DEBUG - 2018-02-21 15:22:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-21 15:22:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-21 15:22:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-21 15:22:37 --> Pagination Class Initialized
INFO - 2018-02-21 15:22:37 --> Helper loaded: form_helper
INFO - 2018-02-21 15:22:37 --> Form Validation Class Initialized
INFO - 2018-02-21 15:22:37 --> Model Class Initialized
INFO - 2018-02-21 15:22:37 --> Controller Class Initialized
DEBUG - 2018-02-21 15:22:37 --> Config file loaded: /var/www/html/project/radio/application/config/rest.php
INFO - 2018-02-21 15:22:37 --> Helper loaded: inflector_helper
INFO - 2018-02-21 15:22:37 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-21 15:22:37 --> Model Class Initialized
INFO - 2018-02-21 15:22:37 --> Model Class Initialized
INFO - 2018-02-21 15:22:37 --> Model Class Initialized
INFO - 2018-02-21 15:22:37 --> Model Class Initialized
INFO - 2018-02-21 15:22:37 --> Model Class Initialized
INFO - 2018-02-21 15:23:56 --> Config Class Initialized
INFO - 2018-02-21 15:23:56 --> Hooks Class Initialized
DEBUG - 2018-02-21 15:23:56 --> UTF-8 Support Enabled
INFO - 2018-02-21 15:23:56 --> Utf8 Class Initialized
INFO - 2018-02-21 15:23:56 --> URI Class Initialized
INFO - 2018-02-21 15:23:56 --> Router Class Initialized
INFO - 2018-02-21 15:23:56 --> Output Class Initialized
INFO - 2018-02-21 15:23:56 --> Security Class Initialized
DEBUG - 2018-02-21 15:23:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-21 15:23:56 --> Input Class Initialized
INFO - 2018-02-21 15:23:56 --> Language Class Initialized
INFO - 2018-02-21 15:23:56 --> Loader Class Initialized
INFO - 2018-02-21 15:23:56 --> Helper loaded: url_helper
INFO - 2018-02-21 15:23:56 --> Helper loaded: file_helper
INFO - 2018-02-21 15:23:56 --> Helper loaded: email_helper
INFO - 2018-02-21 15:23:56 --> Helper loaded: common_helper
INFO - 2018-02-21 15:23:56 --> Database Driver Class Initialized
DEBUG - 2018-02-21 15:23:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-21 15:23:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-21 15:23:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-21 15:23:56 --> Pagination Class Initialized
INFO - 2018-02-21 15:23:56 --> Helper loaded: form_helper
INFO - 2018-02-21 15:23:56 --> Form Validation Class Initialized
INFO - 2018-02-21 15:23:56 --> Model Class Initialized
INFO - 2018-02-21 15:23:56 --> Controller Class Initialized
DEBUG - 2018-02-21 15:23:56 --> Config file loaded: /var/www/html/project/radio/application/config/rest.php
INFO - 2018-02-21 15:23:56 --> Helper loaded: inflector_helper
INFO - 2018-02-21 15:23:56 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-21 15:23:56 --> Model Class Initialized
INFO - 2018-02-21 15:23:56 --> Model Class Initialized
INFO - 2018-02-21 15:23:56 --> Model Class Initialized
INFO - 2018-02-21 15:23:56 --> Model Class Initialized
INFO - 2018-02-21 15:23:56 --> Model Class Initialized
INFO - 2018-02-21 15:23:56 --> Final output sent to browser
DEBUG - 2018-02-21 15:23:56 --> Total execution time: 0.0095
INFO - 2018-02-21 15:24:19 --> Config Class Initialized
INFO - 2018-02-21 15:24:19 --> Hooks Class Initialized
DEBUG - 2018-02-21 15:24:19 --> UTF-8 Support Enabled
INFO - 2018-02-21 15:24:19 --> Utf8 Class Initialized
INFO - 2018-02-21 15:24:19 --> URI Class Initialized
INFO - 2018-02-21 15:24:19 --> Router Class Initialized
INFO - 2018-02-21 15:24:19 --> Output Class Initialized
INFO - 2018-02-21 15:24:19 --> Security Class Initialized
DEBUG - 2018-02-21 15:24:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-21 15:24:19 --> Input Class Initialized
INFO - 2018-02-21 15:24:19 --> Language Class Initialized
INFO - 2018-02-21 15:24:19 --> Loader Class Initialized
INFO - 2018-02-21 15:24:19 --> Helper loaded: url_helper
INFO - 2018-02-21 15:24:19 --> Helper loaded: file_helper
INFO - 2018-02-21 15:24:19 --> Helper loaded: email_helper
INFO - 2018-02-21 15:24:19 --> Helper loaded: common_helper
INFO - 2018-02-21 15:24:19 --> Database Driver Class Initialized
DEBUG - 2018-02-21 15:24:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-21 15:24:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-21 15:24:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-21 15:24:19 --> Pagination Class Initialized
INFO - 2018-02-21 15:24:19 --> Helper loaded: form_helper
INFO - 2018-02-21 15:24:19 --> Form Validation Class Initialized
INFO - 2018-02-21 15:24:19 --> Model Class Initialized
INFO - 2018-02-21 15:24:19 --> Controller Class Initialized
DEBUG - 2018-02-21 15:24:19 --> Config file loaded: /var/www/html/project/radio/application/config/rest.php
INFO - 2018-02-21 15:24:19 --> Helper loaded: inflector_helper
INFO - 2018-02-21 15:24:19 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-21 15:24:19 --> Model Class Initialized
INFO - 2018-02-21 15:24:19 --> Model Class Initialized
INFO - 2018-02-21 15:24:19 --> Model Class Initialized
INFO - 2018-02-21 15:24:19 --> Model Class Initialized
INFO - 2018-02-21 15:24:19 --> Model Class Initialized
INFO - 2018-02-21 15:24:19 --> Final output sent to browser
DEBUG - 2018-02-21 15:24:19 --> Total execution time: 0.0056
INFO - 2018-02-21 15:24:23 --> Config Class Initialized
INFO - 2018-02-21 15:24:23 --> Hooks Class Initialized
DEBUG - 2018-02-21 15:24:23 --> UTF-8 Support Enabled
INFO - 2018-02-21 15:24:23 --> Utf8 Class Initialized
INFO - 2018-02-21 15:24:23 --> URI Class Initialized
INFO - 2018-02-21 15:24:23 --> Router Class Initialized
INFO - 2018-02-21 15:24:23 --> Output Class Initialized
INFO - 2018-02-21 15:24:23 --> Security Class Initialized
DEBUG - 2018-02-21 15:24:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-21 15:24:23 --> Input Class Initialized
INFO - 2018-02-21 15:24:23 --> Language Class Initialized
INFO - 2018-02-21 15:24:23 --> Loader Class Initialized
INFO - 2018-02-21 15:24:23 --> Helper loaded: url_helper
INFO - 2018-02-21 15:24:23 --> Helper loaded: file_helper
INFO - 2018-02-21 15:24:23 --> Helper loaded: email_helper
INFO - 2018-02-21 15:24:23 --> Helper loaded: common_helper
INFO - 2018-02-21 15:24:23 --> Database Driver Class Initialized
DEBUG - 2018-02-21 15:24:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-21 15:24:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-21 15:24:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-21 15:24:23 --> Pagination Class Initialized
INFO - 2018-02-21 15:24:23 --> Helper loaded: form_helper
INFO - 2018-02-21 15:24:23 --> Form Validation Class Initialized
INFO - 2018-02-21 15:24:23 --> Model Class Initialized
INFO - 2018-02-21 15:24:23 --> Controller Class Initialized
DEBUG - 2018-02-21 15:24:23 --> Config file loaded: /var/www/html/project/radio/application/config/rest.php
INFO - 2018-02-21 15:24:23 --> Helper loaded: inflector_helper
INFO - 2018-02-21 15:24:23 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-21 15:24:23 --> Model Class Initialized
INFO - 2018-02-21 15:24:23 --> Model Class Initialized
INFO - 2018-02-21 15:24:23 --> Model Class Initialized
INFO - 2018-02-21 15:24:23 --> Model Class Initialized
INFO - 2018-02-21 15:24:23 --> Model Class Initialized
INFO - 2018-02-21 15:24:23 --> Final output sent to browser
DEBUG - 2018-02-21 15:24:23 --> Total execution time: 0.0079
INFO - 2018-02-21 15:28:38 --> Config Class Initialized
INFO - 2018-02-21 15:28:38 --> Hooks Class Initialized
DEBUG - 2018-02-21 15:28:38 --> UTF-8 Support Enabled
INFO - 2018-02-21 15:28:38 --> Utf8 Class Initialized
INFO - 2018-02-21 15:28:38 --> URI Class Initialized
INFO - 2018-02-21 15:28:38 --> Router Class Initialized
INFO - 2018-02-21 15:28:38 --> Output Class Initialized
INFO - 2018-02-21 15:28:38 --> Security Class Initialized
DEBUG - 2018-02-21 15:28:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-21 15:28:38 --> Input Class Initialized
INFO - 2018-02-21 15:28:38 --> Language Class Initialized
INFO - 2018-02-21 15:28:38 --> Loader Class Initialized
INFO - 2018-02-21 15:28:38 --> Helper loaded: url_helper
INFO - 2018-02-21 15:28:38 --> Helper loaded: file_helper
INFO - 2018-02-21 15:28:38 --> Helper loaded: email_helper
INFO - 2018-02-21 15:28:38 --> Helper loaded: common_helper
INFO - 2018-02-21 15:28:38 --> Database Driver Class Initialized
DEBUG - 2018-02-21 15:28:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-21 15:28:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-21 15:28:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-21 15:28:38 --> Pagination Class Initialized
INFO - 2018-02-21 15:28:38 --> Helper loaded: form_helper
INFO - 2018-02-21 15:28:38 --> Form Validation Class Initialized
INFO - 2018-02-21 15:28:38 --> Model Class Initialized
INFO - 2018-02-21 15:28:38 --> Controller Class Initialized
DEBUG - 2018-02-21 15:28:38 --> Config file loaded: /var/www/html/project/radio/application/config/rest.php
INFO - 2018-02-21 15:28:38 --> Helper loaded: inflector_helper
INFO - 2018-02-21 15:28:38 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-21 15:28:38 --> Model Class Initialized
INFO - 2018-02-21 15:28:38 --> Model Class Initialized
INFO - 2018-02-21 15:28:38 --> Model Class Initialized
INFO - 2018-02-21 15:28:38 --> Model Class Initialized
INFO - 2018-02-21 15:28:38 --> Model Class Initialized
INFO - 2018-02-21 15:28:38 --> Final output sent to browser
DEBUG - 2018-02-21 15:28:38 --> Total execution time: 0.0092
INFO - 2018-02-21 15:29:59 --> Config Class Initialized
INFO - 2018-02-21 15:29:59 --> Hooks Class Initialized
DEBUG - 2018-02-21 15:29:59 --> UTF-8 Support Enabled
INFO - 2018-02-21 15:29:59 --> Utf8 Class Initialized
INFO - 2018-02-21 15:29:59 --> URI Class Initialized
INFO - 2018-02-21 15:29:59 --> Router Class Initialized
INFO - 2018-02-21 15:29:59 --> Output Class Initialized
INFO - 2018-02-21 15:29:59 --> Security Class Initialized
DEBUG - 2018-02-21 15:29:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-21 15:29:59 --> Input Class Initialized
INFO - 2018-02-21 15:29:59 --> Language Class Initialized
INFO - 2018-02-21 15:29:59 --> Loader Class Initialized
INFO - 2018-02-21 15:29:59 --> Helper loaded: url_helper
INFO - 2018-02-21 15:29:59 --> Helper loaded: file_helper
INFO - 2018-02-21 15:29:59 --> Helper loaded: email_helper
INFO - 2018-02-21 15:29:59 --> Helper loaded: common_helper
INFO - 2018-02-21 15:29:59 --> Database Driver Class Initialized
DEBUG - 2018-02-21 15:29:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-21 15:29:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-21 15:29:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-21 15:29:59 --> Pagination Class Initialized
INFO - 2018-02-21 15:29:59 --> Helper loaded: form_helper
INFO - 2018-02-21 15:29:59 --> Form Validation Class Initialized
INFO - 2018-02-21 15:29:59 --> Model Class Initialized
INFO - 2018-02-21 15:29:59 --> Controller Class Initialized
DEBUG - 2018-02-21 15:29:59 --> Config file loaded: /var/www/html/project/radio/application/config/rest.php
INFO - 2018-02-21 15:29:59 --> Helper loaded: inflector_helper
INFO - 2018-02-21 15:29:59 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-21 15:29:59 --> Model Class Initialized
INFO - 2018-02-21 15:29:59 --> Model Class Initialized
INFO - 2018-02-21 15:29:59 --> Model Class Initialized
ERROR - 2018-02-21 15:29:59 --> Severity: error --> Exception: syntax error, unexpected '") as vTrackImage "' (T_CONSTANT_ENCAPSED_STRING), expecting ',' or ')' /var/www/html/project/radio/application/models/Tracks_model.php 171
INFO - 2018-02-21 15:30:30 --> Config Class Initialized
INFO - 2018-02-21 15:30:30 --> Hooks Class Initialized
DEBUG - 2018-02-21 15:30:30 --> UTF-8 Support Enabled
INFO - 2018-02-21 15:30:30 --> Utf8 Class Initialized
INFO - 2018-02-21 15:30:30 --> URI Class Initialized
INFO - 2018-02-21 15:30:30 --> Router Class Initialized
INFO - 2018-02-21 15:30:30 --> Output Class Initialized
INFO - 2018-02-21 15:30:30 --> Security Class Initialized
DEBUG - 2018-02-21 15:30:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-21 15:30:30 --> Input Class Initialized
INFO - 2018-02-21 15:30:30 --> Language Class Initialized
INFO - 2018-02-21 15:30:30 --> Loader Class Initialized
INFO - 2018-02-21 15:30:30 --> Helper loaded: url_helper
INFO - 2018-02-21 15:30:30 --> Helper loaded: file_helper
INFO - 2018-02-21 15:30:30 --> Helper loaded: email_helper
INFO - 2018-02-21 15:30:30 --> Helper loaded: common_helper
INFO - 2018-02-21 15:30:30 --> Database Driver Class Initialized
DEBUG - 2018-02-21 15:30:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-21 15:30:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-21 15:30:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-21 15:30:30 --> Pagination Class Initialized
INFO - 2018-02-21 15:30:30 --> Helper loaded: form_helper
INFO - 2018-02-21 15:30:30 --> Form Validation Class Initialized
INFO - 2018-02-21 15:30:30 --> Model Class Initialized
INFO - 2018-02-21 15:30:30 --> Controller Class Initialized
DEBUG - 2018-02-21 15:30:30 --> Config file loaded: /var/www/html/project/radio/application/config/rest.php
INFO - 2018-02-21 15:30:30 --> Helper loaded: inflector_helper
INFO - 2018-02-21 15:30:30 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-21 15:30:30 --> Model Class Initialized
INFO - 2018-02-21 15:30:30 --> Model Class Initialized
INFO - 2018-02-21 15:30:30 --> Model Class Initialized
INFO - 2018-02-21 15:30:30 --> Model Class Initialized
INFO - 2018-02-21 15:30:30 --> Model Class Initialized
INFO - 2018-02-21 15:30:30 --> Final output sent to browser
DEBUG - 2018-02-21 15:30:30 --> Total execution time: 0.0081
INFO - 2018-02-21 15:32:24 --> Config Class Initialized
INFO - 2018-02-21 15:32:24 --> Hooks Class Initialized
DEBUG - 2018-02-21 15:32:24 --> UTF-8 Support Enabled
INFO - 2018-02-21 15:32:24 --> Utf8 Class Initialized
INFO - 2018-02-21 15:32:24 --> URI Class Initialized
INFO - 2018-02-21 15:32:24 --> Router Class Initialized
INFO - 2018-02-21 15:32:24 --> Output Class Initialized
INFO - 2018-02-21 15:32:24 --> Security Class Initialized
DEBUG - 2018-02-21 15:32:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-21 15:32:24 --> Input Class Initialized
INFO - 2018-02-21 15:32:24 --> Language Class Initialized
INFO - 2018-02-21 15:32:24 --> Loader Class Initialized
INFO - 2018-02-21 15:32:24 --> Helper loaded: url_helper
INFO - 2018-02-21 15:32:24 --> Helper loaded: file_helper
INFO - 2018-02-21 15:32:24 --> Helper loaded: email_helper
INFO - 2018-02-21 15:32:24 --> Helper loaded: common_helper
INFO - 2018-02-21 15:32:24 --> Database Driver Class Initialized
DEBUG - 2018-02-21 15:32:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-21 15:32:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-21 15:32:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-21 15:32:24 --> Pagination Class Initialized
INFO - 2018-02-21 15:32:24 --> Helper loaded: form_helper
INFO - 2018-02-21 15:32:24 --> Form Validation Class Initialized
INFO - 2018-02-21 15:32:24 --> Model Class Initialized
INFO - 2018-02-21 15:32:24 --> Controller Class Initialized
DEBUG - 2018-02-21 15:32:24 --> Config file loaded: /var/www/html/project/radio/application/config/rest.php
INFO - 2018-02-21 15:32:24 --> Helper loaded: inflector_helper
INFO - 2018-02-21 15:32:24 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-21 15:32:24 --> Model Class Initialized
INFO - 2018-02-21 15:32:24 --> Model Class Initialized
INFO - 2018-02-21 15:32:24 --> Model Class Initialized
INFO - 2018-02-21 15:32:24 --> Model Class Initialized
INFO - 2018-02-21 15:32:24 --> Model Class Initialized
INFO - 2018-02-21 15:32:24 --> Final output sent to browser
DEBUG - 2018-02-21 15:32:24 --> Total execution time: 0.0062
INFO - 2018-02-21 15:34:42 --> Config Class Initialized
INFO - 2018-02-21 15:34:42 --> Hooks Class Initialized
DEBUG - 2018-02-21 15:34:42 --> UTF-8 Support Enabled
INFO - 2018-02-21 15:34:42 --> Utf8 Class Initialized
INFO - 2018-02-21 15:34:42 --> URI Class Initialized
INFO - 2018-02-21 15:34:42 --> Router Class Initialized
INFO - 2018-02-21 15:34:42 --> Output Class Initialized
INFO - 2018-02-21 15:34:42 --> Security Class Initialized
DEBUG - 2018-02-21 15:34:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-21 15:34:42 --> Input Class Initialized
INFO - 2018-02-21 15:34:42 --> Language Class Initialized
INFO - 2018-02-21 15:34:42 --> Loader Class Initialized
INFO - 2018-02-21 15:34:42 --> Helper loaded: url_helper
INFO - 2018-02-21 15:34:42 --> Helper loaded: file_helper
INFO - 2018-02-21 15:34:42 --> Helper loaded: email_helper
INFO - 2018-02-21 15:34:42 --> Helper loaded: common_helper
INFO - 2018-02-21 15:34:42 --> Database Driver Class Initialized
DEBUG - 2018-02-21 15:34:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-21 15:34:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-21 15:34:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-21 15:34:42 --> Pagination Class Initialized
INFO - 2018-02-21 15:34:42 --> Helper loaded: form_helper
INFO - 2018-02-21 15:34:42 --> Form Validation Class Initialized
INFO - 2018-02-21 15:34:42 --> Model Class Initialized
INFO - 2018-02-21 15:34:42 --> Controller Class Initialized
DEBUG - 2018-02-21 15:34:42 --> Config file loaded: /var/www/html/project/radio/application/config/rest.php
INFO - 2018-02-21 15:34:42 --> Helper loaded: inflector_helper
INFO - 2018-02-21 15:34:42 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-21 15:34:42 --> Model Class Initialized
INFO - 2018-02-21 15:34:42 --> Model Class Initialized
INFO - 2018-02-21 15:34:42 --> Model Class Initialized
INFO - 2018-02-21 15:34:42 --> Model Class Initialized
INFO - 2018-02-21 15:34:42 --> Model Class Initialized
INFO - 2018-02-21 15:34:42 --> Final output sent to browser
DEBUG - 2018-02-21 15:34:42 --> Total execution time: 0.0071
INFO - 2018-02-21 15:35:11 --> Config Class Initialized
INFO - 2018-02-21 15:35:11 --> Hooks Class Initialized
DEBUG - 2018-02-21 15:35:11 --> UTF-8 Support Enabled
INFO - 2018-02-21 15:35:11 --> Utf8 Class Initialized
INFO - 2018-02-21 15:35:11 --> URI Class Initialized
INFO - 2018-02-21 15:35:11 --> Router Class Initialized
INFO - 2018-02-21 15:35:11 --> Output Class Initialized
INFO - 2018-02-21 15:35:11 --> Security Class Initialized
DEBUG - 2018-02-21 15:35:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-21 15:35:11 --> Input Class Initialized
INFO - 2018-02-21 15:35:11 --> Language Class Initialized
INFO - 2018-02-21 15:35:11 --> Loader Class Initialized
INFO - 2018-02-21 15:35:11 --> Helper loaded: url_helper
INFO - 2018-02-21 15:35:11 --> Helper loaded: file_helper
INFO - 2018-02-21 15:35:11 --> Helper loaded: email_helper
INFO - 2018-02-21 15:35:11 --> Helper loaded: common_helper
INFO - 2018-02-21 15:35:11 --> Database Driver Class Initialized
DEBUG - 2018-02-21 15:35:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-21 15:35:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-21 15:35:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-21 15:35:11 --> Pagination Class Initialized
INFO - 2018-02-21 15:35:11 --> Helper loaded: form_helper
INFO - 2018-02-21 15:35:11 --> Form Validation Class Initialized
INFO - 2018-02-21 15:35:11 --> Model Class Initialized
INFO - 2018-02-21 15:35:11 --> Controller Class Initialized
DEBUG - 2018-02-21 15:35:11 --> Config file loaded: /var/www/html/project/radio/application/config/rest.php
INFO - 2018-02-21 15:35:11 --> Helper loaded: inflector_helper
INFO - 2018-02-21 15:35:11 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-21 15:35:11 --> Model Class Initialized
INFO - 2018-02-21 15:35:11 --> Model Class Initialized
INFO - 2018-02-21 15:35:11 --> Model Class Initialized
INFO - 2018-02-21 15:35:11 --> Model Class Initialized
INFO - 2018-02-21 15:35:11 --> Model Class Initialized
INFO - 2018-02-21 15:35:11 --> Final output sent to browser
DEBUG - 2018-02-21 15:35:11 --> Total execution time: 0.0071
INFO - 2018-02-21 15:35:44 --> Config Class Initialized
INFO - 2018-02-21 15:35:44 --> Hooks Class Initialized
DEBUG - 2018-02-21 15:35:44 --> UTF-8 Support Enabled
INFO - 2018-02-21 15:35:44 --> Utf8 Class Initialized
INFO - 2018-02-21 15:35:44 --> URI Class Initialized
INFO - 2018-02-21 15:35:44 --> Router Class Initialized
INFO - 2018-02-21 15:35:44 --> Output Class Initialized
INFO - 2018-02-21 15:35:44 --> Security Class Initialized
DEBUG - 2018-02-21 15:35:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-21 15:35:44 --> Input Class Initialized
INFO - 2018-02-21 15:35:44 --> Language Class Initialized
INFO - 2018-02-21 15:35:44 --> Loader Class Initialized
INFO - 2018-02-21 15:35:44 --> Helper loaded: url_helper
INFO - 2018-02-21 15:35:44 --> Helper loaded: file_helper
INFO - 2018-02-21 15:35:44 --> Helper loaded: email_helper
INFO - 2018-02-21 15:35:44 --> Helper loaded: common_helper
INFO - 2018-02-21 15:35:44 --> Database Driver Class Initialized
DEBUG - 2018-02-21 15:35:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-21 15:35:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-21 15:35:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-21 15:35:44 --> Pagination Class Initialized
INFO - 2018-02-21 15:35:44 --> Helper loaded: form_helper
INFO - 2018-02-21 15:35:44 --> Form Validation Class Initialized
INFO - 2018-02-21 15:35:44 --> Model Class Initialized
INFO - 2018-02-21 15:35:44 --> Controller Class Initialized
DEBUG - 2018-02-21 15:35:44 --> Config file loaded: /var/www/html/project/radio/application/config/rest.php
INFO - 2018-02-21 15:35:44 --> Helper loaded: inflector_helper
INFO - 2018-02-21 15:35:44 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-21 15:35:44 --> Model Class Initialized
INFO - 2018-02-21 15:35:44 --> Model Class Initialized
INFO - 2018-02-21 15:35:44 --> Model Class Initialized
INFO - 2018-02-21 15:35:44 --> Model Class Initialized
INFO - 2018-02-21 15:35:44 --> Model Class Initialized
INFO - 2018-02-21 15:35:44 --> Final output sent to browser
DEBUG - 2018-02-21 15:35:44 --> Total execution time: 0.0067
INFO - 2018-02-21 15:35:49 --> Config Class Initialized
INFO - 2018-02-21 15:35:49 --> Hooks Class Initialized
DEBUG - 2018-02-21 15:35:49 --> UTF-8 Support Enabled
INFO - 2018-02-21 15:35:49 --> Utf8 Class Initialized
INFO - 2018-02-21 15:35:49 --> URI Class Initialized
INFO - 2018-02-21 15:35:49 --> Router Class Initialized
INFO - 2018-02-21 15:35:49 --> Output Class Initialized
INFO - 2018-02-21 15:35:49 --> Security Class Initialized
DEBUG - 2018-02-21 15:35:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-21 15:35:49 --> Input Class Initialized
INFO - 2018-02-21 15:35:49 --> Language Class Initialized
INFO - 2018-02-21 15:35:49 --> Loader Class Initialized
INFO - 2018-02-21 15:35:49 --> Helper loaded: url_helper
INFO - 2018-02-21 15:35:49 --> Helper loaded: file_helper
INFO - 2018-02-21 15:35:49 --> Helper loaded: email_helper
INFO - 2018-02-21 15:35:49 --> Helper loaded: common_helper
INFO - 2018-02-21 15:35:49 --> Database Driver Class Initialized
DEBUG - 2018-02-21 15:35:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-21 15:35:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-21 15:35:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-21 15:35:49 --> Pagination Class Initialized
INFO - 2018-02-21 15:35:49 --> Helper loaded: form_helper
INFO - 2018-02-21 15:35:49 --> Form Validation Class Initialized
INFO - 2018-02-21 15:35:49 --> Model Class Initialized
INFO - 2018-02-21 15:35:49 --> Controller Class Initialized
DEBUG - 2018-02-21 15:35:49 --> Config file loaded: /var/www/html/project/radio/application/config/rest.php
INFO - 2018-02-21 15:35:49 --> Helper loaded: inflector_helper
INFO - 2018-02-21 15:35:49 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-21 15:35:49 --> Model Class Initialized
INFO - 2018-02-21 15:35:49 --> Model Class Initialized
INFO - 2018-02-21 15:35:49 --> Model Class Initialized
INFO - 2018-02-21 15:35:49 --> Model Class Initialized
INFO - 2018-02-21 15:35:49 --> Model Class Initialized
INFO - 2018-02-21 15:35:49 --> Final output sent to browser
DEBUG - 2018-02-21 15:35:49 --> Total execution time: 0.0096
INFO - 2018-02-21 15:36:37 --> Config Class Initialized
INFO - 2018-02-21 15:36:37 --> Hooks Class Initialized
DEBUG - 2018-02-21 15:36:37 --> UTF-8 Support Enabled
INFO - 2018-02-21 15:36:37 --> Utf8 Class Initialized
INFO - 2018-02-21 15:36:37 --> URI Class Initialized
INFO - 2018-02-21 15:36:37 --> Router Class Initialized
INFO - 2018-02-21 15:36:37 --> Output Class Initialized
INFO - 2018-02-21 15:36:37 --> Security Class Initialized
DEBUG - 2018-02-21 15:36:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-21 15:36:37 --> Input Class Initialized
INFO - 2018-02-21 15:36:37 --> Language Class Initialized
INFO - 2018-02-21 15:36:37 --> Loader Class Initialized
INFO - 2018-02-21 15:36:37 --> Helper loaded: url_helper
INFO - 2018-02-21 15:36:37 --> Helper loaded: file_helper
INFO - 2018-02-21 15:36:37 --> Helper loaded: email_helper
INFO - 2018-02-21 15:36:37 --> Helper loaded: common_helper
INFO - 2018-02-21 15:36:37 --> Database Driver Class Initialized
DEBUG - 2018-02-21 15:36:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-21 15:36:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-21 15:36:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-21 15:36:37 --> Pagination Class Initialized
INFO - 2018-02-21 15:36:37 --> Helper loaded: form_helper
INFO - 2018-02-21 15:36:37 --> Form Validation Class Initialized
INFO - 2018-02-21 15:36:37 --> Model Class Initialized
INFO - 2018-02-21 15:36:37 --> Controller Class Initialized
DEBUG - 2018-02-21 15:36:37 --> Config file loaded: /var/www/html/project/radio/application/config/rest.php
INFO - 2018-02-21 15:36:37 --> Helper loaded: inflector_helper
INFO - 2018-02-21 15:36:37 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-21 15:36:37 --> Model Class Initialized
INFO - 2018-02-21 15:36:37 --> Model Class Initialized
INFO - 2018-02-21 15:36:37 --> Model Class Initialized
INFO - 2018-02-21 15:36:37 --> Model Class Initialized
INFO - 2018-02-21 15:36:37 --> Model Class Initialized
INFO - 2018-02-21 15:36:37 --> Final output sent to browser
DEBUG - 2018-02-21 15:36:37 --> Total execution time: 0.0070
INFO - 2018-02-21 15:47:52 --> Config Class Initialized
INFO - 2018-02-21 15:47:52 --> Hooks Class Initialized
DEBUG - 2018-02-21 15:47:52 --> UTF-8 Support Enabled
INFO - 2018-02-21 15:47:52 --> Utf8 Class Initialized
INFO - 2018-02-21 15:47:52 --> URI Class Initialized
INFO - 2018-02-21 15:47:52 --> Router Class Initialized
INFO - 2018-02-21 15:47:52 --> Output Class Initialized
INFO - 2018-02-21 15:47:52 --> Security Class Initialized
DEBUG - 2018-02-21 15:47:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-21 15:47:52 --> Input Class Initialized
INFO - 2018-02-21 15:47:52 --> Language Class Initialized
INFO - 2018-02-21 15:47:52 --> Loader Class Initialized
INFO - 2018-02-21 15:47:52 --> Helper loaded: url_helper
INFO - 2018-02-21 15:47:52 --> Helper loaded: file_helper
INFO - 2018-02-21 15:47:52 --> Helper loaded: email_helper
INFO - 2018-02-21 15:47:52 --> Helper loaded: common_helper
INFO - 2018-02-21 15:47:52 --> Database Driver Class Initialized
DEBUG - 2018-02-21 15:47:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-21 15:47:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-21 15:47:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-21 15:47:52 --> Pagination Class Initialized
INFO - 2018-02-21 15:47:52 --> Helper loaded: form_helper
INFO - 2018-02-21 15:47:52 --> Form Validation Class Initialized
INFO - 2018-02-21 15:47:52 --> Model Class Initialized
INFO - 2018-02-21 15:47:52 --> Controller Class Initialized
DEBUG - 2018-02-21 15:47:52 --> Config file loaded: /var/www/html/project/radio/application/config/rest.php
INFO - 2018-02-21 15:47:52 --> Helper loaded: inflector_helper
INFO - 2018-02-21 15:47:52 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-21 15:47:52 --> Model Class Initialized
INFO - 2018-02-21 15:47:52 --> Model Class Initialized
INFO - 2018-02-21 15:47:52 --> Model Class Initialized
INFO - 2018-02-21 15:47:52 --> Model Class Initialized
INFO - 2018-02-21 15:47:52 --> Model Class Initialized
ERROR - 2018-02-21 15:47:52 --> Query error: Expression #3 of SELECT list is not in GROUP BY clause and contains nonaggregated column 'radio.uf.iUserId' which is not functionally dependent on columns in GROUP BY clause; this is incompatible with sql_mode=only_full_group_by - Invalid query: SELECT `uf`.`iTracksId`, count(uf.iUserId) as totalFavorite, IF(uf.iUserId = 1, 'Yes', 'No') as isFav
FROM `userfavorites` as `uf`
WHERE `uf`.`iTracksId` IN('3', '5', '7', '10')
GROUP BY `uf`.`iTracksId`
INFO - 2018-02-21 15:47:52 --> Language file loaded: language/english/db_lang.php
INFO - 2018-02-21 16:08:22 --> Config Class Initialized
INFO - 2018-02-21 16:08:22 --> Hooks Class Initialized
DEBUG - 2018-02-21 16:08:22 --> UTF-8 Support Enabled
INFO - 2018-02-21 16:08:22 --> Utf8 Class Initialized
INFO - 2018-02-21 16:08:22 --> URI Class Initialized
INFO - 2018-02-21 16:08:22 --> Router Class Initialized
INFO - 2018-02-21 16:08:22 --> Output Class Initialized
INFO - 2018-02-21 16:08:22 --> Security Class Initialized
DEBUG - 2018-02-21 16:08:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-21 16:08:22 --> Input Class Initialized
INFO - 2018-02-21 16:08:22 --> Language Class Initialized
INFO - 2018-02-21 16:08:22 --> Loader Class Initialized
INFO - 2018-02-21 16:08:22 --> Helper loaded: url_helper
INFO - 2018-02-21 16:08:22 --> Helper loaded: file_helper
INFO - 2018-02-21 16:08:22 --> Helper loaded: email_helper
INFO - 2018-02-21 16:08:22 --> Helper loaded: common_helper
INFO - 2018-02-21 16:08:22 --> Database Driver Class Initialized
DEBUG - 2018-02-21 16:08:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-21 16:08:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-21 16:08:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-21 16:08:22 --> Pagination Class Initialized
INFO - 2018-02-21 16:08:22 --> Helper loaded: form_helper
INFO - 2018-02-21 16:08:22 --> Form Validation Class Initialized
INFO - 2018-02-21 16:08:22 --> Model Class Initialized
INFO - 2018-02-21 16:08:22 --> Controller Class Initialized
DEBUG - 2018-02-21 16:08:22 --> Config file loaded: /var/www/html/project/radio/application/config/rest.php
INFO - 2018-02-21 16:08:22 --> Helper loaded: inflector_helper
INFO - 2018-02-21 16:08:22 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-21 16:08:22 --> Model Class Initialized
INFO - 2018-02-21 16:08:22 --> Model Class Initialized
INFO - 2018-02-21 16:08:22 --> Model Class Initialized
INFO - 2018-02-21 16:08:22 --> Model Class Initialized
INFO - 2018-02-21 16:08:22 --> Model Class Initialized
ERROR - 2018-02-21 16:08:22 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ')) as aaa
FROM `userfavorites` as `uf`
WHERE `uf`.`iTracksId` IN('3', '5', '7', ' at line 1 - Invalid query: SELECT `uf`.`iTracksId`, count(uf.iUserId) as totalFavorite, count(IF(uf.iUserId = 1)) as aaa
FROM `userfavorites` as `uf`
WHERE `uf`.`iTracksId` IN('3', '5', '7', '10')
GROUP BY `uf`.`iTracksId`
INFO - 2018-02-21 16:08:22 --> Language file loaded: language/english/db_lang.php
INFO - 2018-02-21 16:08:32 --> Config Class Initialized
INFO - 2018-02-21 16:08:32 --> Hooks Class Initialized
DEBUG - 2018-02-21 16:08:32 --> UTF-8 Support Enabled
INFO - 2018-02-21 16:08:32 --> Utf8 Class Initialized
INFO - 2018-02-21 16:08:32 --> URI Class Initialized
INFO - 2018-02-21 16:08:32 --> Router Class Initialized
INFO - 2018-02-21 16:08:32 --> Output Class Initialized
INFO - 2018-02-21 16:08:32 --> Security Class Initialized
DEBUG - 2018-02-21 16:08:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-21 16:08:32 --> Input Class Initialized
INFO - 2018-02-21 16:08:32 --> Language Class Initialized
INFO - 2018-02-21 16:08:32 --> Loader Class Initialized
INFO - 2018-02-21 16:08:32 --> Helper loaded: url_helper
INFO - 2018-02-21 16:08:32 --> Helper loaded: file_helper
INFO - 2018-02-21 16:08:32 --> Helper loaded: email_helper
INFO - 2018-02-21 16:08:32 --> Helper loaded: common_helper
INFO - 2018-02-21 16:08:32 --> Database Driver Class Initialized
DEBUG - 2018-02-21 16:08:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-21 16:08:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-21 16:08:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-21 16:08:32 --> Pagination Class Initialized
INFO - 2018-02-21 16:08:32 --> Helper loaded: form_helper
INFO - 2018-02-21 16:08:32 --> Form Validation Class Initialized
INFO - 2018-02-21 16:08:32 --> Model Class Initialized
INFO - 2018-02-21 16:08:32 --> Controller Class Initialized
DEBUG - 2018-02-21 16:08:32 --> Config file loaded: /var/www/html/project/radio/application/config/rest.php
INFO - 2018-02-21 16:08:32 --> Helper loaded: inflector_helper
INFO - 2018-02-21 16:08:32 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-21 16:08:32 --> Model Class Initialized
INFO - 2018-02-21 16:08:32 --> Model Class Initialized
INFO - 2018-02-21 16:08:32 --> Model Class Initialized
INFO - 2018-02-21 16:08:32 --> Model Class Initialized
INFO - 2018-02-21 16:08:32 --> Model Class Initialized
INFO - 2018-02-21 16:09:44 --> Config Class Initialized
INFO - 2018-02-21 16:09:44 --> Hooks Class Initialized
DEBUG - 2018-02-21 16:09:44 --> UTF-8 Support Enabled
INFO - 2018-02-21 16:09:44 --> Utf8 Class Initialized
INFO - 2018-02-21 16:09:44 --> URI Class Initialized
INFO - 2018-02-21 16:09:44 --> Router Class Initialized
INFO - 2018-02-21 16:09:44 --> Output Class Initialized
INFO - 2018-02-21 16:09:44 --> Security Class Initialized
DEBUG - 2018-02-21 16:09:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-21 16:09:44 --> Input Class Initialized
INFO - 2018-02-21 16:09:44 --> Language Class Initialized
INFO - 2018-02-21 16:09:44 --> Loader Class Initialized
INFO - 2018-02-21 16:09:44 --> Helper loaded: url_helper
INFO - 2018-02-21 16:09:44 --> Helper loaded: file_helper
INFO - 2018-02-21 16:09:44 --> Helper loaded: email_helper
INFO - 2018-02-21 16:09:44 --> Helper loaded: common_helper
INFO - 2018-02-21 16:09:44 --> Database Driver Class Initialized
DEBUG - 2018-02-21 16:09:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-21 16:09:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-21 16:09:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-21 16:09:44 --> Pagination Class Initialized
INFO - 2018-02-21 16:09:44 --> Helper loaded: form_helper
INFO - 2018-02-21 16:09:44 --> Form Validation Class Initialized
INFO - 2018-02-21 16:09:44 --> Model Class Initialized
INFO - 2018-02-21 16:09:44 --> Controller Class Initialized
DEBUG - 2018-02-21 16:09:44 --> Config file loaded: /var/www/html/project/radio/application/config/rest.php
INFO - 2018-02-21 16:09:44 --> Helper loaded: inflector_helper
INFO - 2018-02-21 16:09:44 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-21 16:09:44 --> Model Class Initialized
INFO - 2018-02-21 16:09:44 --> Model Class Initialized
INFO - 2018-02-21 16:09:44 --> Model Class Initialized
INFO - 2018-02-21 16:09:44 --> Model Class Initialized
INFO - 2018-02-21 16:09:44 --> Model Class Initialized
INFO - 2018-02-21 16:09:51 --> Config Class Initialized
INFO - 2018-02-21 16:09:51 --> Hooks Class Initialized
DEBUG - 2018-02-21 16:09:51 --> UTF-8 Support Enabled
INFO - 2018-02-21 16:09:51 --> Utf8 Class Initialized
INFO - 2018-02-21 16:09:51 --> URI Class Initialized
INFO - 2018-02-21 16:09:51 --> Router Class Initialized
INFO - 2018-02-21 16:09:51 --> Output Class Initialized
INFO - 2018-02-21 16:09:51 --> Security Class Initialized
DEBUG - 2018-02-21 16:09:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-21 16:09:51 --> Input Class Initialized
INFO - 2018-02-21 16:09:51 --> Language Class Initialized
INFO - 2018-02-21 16:09:51 --> Loader Class Initialized
INFO - 2018-02-21 16:09:51 --> Helper loaded: url_helper
INFO - 2018-02-21 16:09:51 --> Helper loaded: file_helper
INFO - 2018-02-21 16:09:51 --> Helper loaded: email_helper
INFO - 2018-02-21 16:09:51 --> Helper loaded: common_helper
INFO - 2018-02-21 16:09:51 --> Database Driver Class Initialized
DEBUG - 2018-02-21 16:09:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-21 16:09:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-21 16:09:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-21 16:09:51 --> Pagination Class Initialized
INFO - 2018-02-21 16:09:51 --> Helper loaded: form_helper
INFO - 2018-02-21 16:09:51 --> Form Validation Class Initialized
INFO - 2018-02-21 16:09:51 --> Model Class Initialized
INFO - 2018-02-21 16:09:51 --> Controller Class Initialized
DEBUG - 2018-02-21 16:09:51 --> Config file loaded: /var/www/html/project/radio/application/config/rest.php
INFO - 2018-02-21 16:09:51 --> Helper loaded: inflector_helper
INFO - 2018-02-21 16:09:51 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-21 16:09:51 --> Model Class Initialized
INFO - 2018-02-21 16:09:51 --> Model Class Initialized
INFO - 2018-02-21 16:09:51 --> Model Class Initialized
INFO - 2018-02-21 16:09:51 --> Model Class Initialized
INFO - 2018-02-21 16:09:51 --> Model Class Initialized
INFO - 2018-02-21 16:10:17 --> Config Class Initialized
INFO - 2018-02-21 16:10:17 --> Hooks Class Initialized
DEBUG - 2018-02-21 16:10:17 --> UTF-8 Support Enabled
INFO - 2018-02-21 16:10:17 --> Utf8 Class Initialized
INFO - 2018-02-21 16:10:17 --> URI Class Initialized
INFO - 2018-02-21 16:10:17 --> Router Class Initialized
INFO - 2018-02-21 16:10:17 --> Output Class Initialized
INFO - 2018-02-21 16:10:17 --> Security Class Initialized
DEBUG - 2018-02-21 16:10:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-21 16:10:17 --> Input Class Initialized
INFO - 2018-02-21 16:10:17 --> Language Class Initialized
INFO - 2018-02-21 16:10:17 --> Loader Class Initialized
INFO - 2018-02-21 16:10:17 --> Helper loaded: url_helper
INFO - 2018-02-21 16:10:17 --> Helper loaded: file_helper
INFO - 2018-02-21 16:10:17 --> Helper loaded: email_helper
INFO - 2018-02-21 16:10:17 --> Helper loaded: common_helper
INFO - 2018-02-21 16:10:17 --> Database Driver Class Initialized
DEBUG - 2018-02-21 16:10:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-21 16:10:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-21 16:10:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-21 16:10:17 --> Pagination Class Initialized
INFO - 2018-02-21 16:10:17 --> Helper loaded: form_helper
INFO - 2018-02-21 16:10:17 --> Form Validation Class Initialized
INFO - 2018-02-21 16:10:17 --> Model Class Initialized
INFO - 2018-02-21 16:10:17 --> Controller Class Initialized
DEBUG - 2018-02-21 16:10:17 --> Config file loaded: /var/www/html/project/radio/application/config/rest.php
INFO - 2018-02-21 16:10:17 --> Helper loaded: inflector_helper
INFO - 2018-02-21 16:10:17 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-21 16:10:17 --> Model Class Initialized
INFO - 2018-02-21 16:10:17 --> Model Class Initialized
INFO - 2018-02-21 16:10:17 --> Model Class Initialized
INFO - 2018-02-21 16:10:17 --> Model Class Initialized
INFO - 2018-02-21 16:10:17 --> Model Class Initialized
INFO - 2018-02-21 16:11:46 --> Config Class Initialized
INFO - 2018-02-21 16:11:46 --> Hooks Class Initialized
DEBUG - 2018-02-21 16:11:46 --> UTF-8 Support Enabled
INFO - 2018-02-21 16:11:46 --> Utf8 Class Initialized
INFO - 2018-02-21 16:11:46 --> URI Class Initialized
INFO - 2018-02-21 16:11:46 --> Router Class Initialized
INFO - 2018-02-21 16:11:46 --> Output Class Initialized
INFO - 2018-02-21 16:11:46 --> Security Class Initialized
DEBUG - 2018-02-21 16:11:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-21 16:11:46 --> Input Class Initialized
INFO - 2018-02-21 16:11:46 --> Language Class Initialized
INFO - 2018-02-21 16:11:46 --> Loader Class Initialized
INFO - 2018-02-21 16:11:46 --> Helper loaded: url_helper
INFO - 2018-02-21 16:11:46 --> Helper loaded: file_helper
INFO - 2018-02-21 16:11:46 --> Helper loaded: email_helper
INFO - 2018-02-21 16:11:46 --> Helper loaded: common_helper
INFO - 2018-02-21 16:11:46 --> Database Driver Class Initialized
DEBUG - 2018-02-21 16:11:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-21 16:11:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-21 16:11:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-21 16:11:46 --> Pagination Class Initialized
INFO - 2018-02-21 16:11:46 --> Helper loaded: form_helper
INFO - 2018-02-21 16:11:46 --> Form Validation Class Initialized
INFO - 2018-02-21 16:11:46 --> Model Class Initialized
INFO - 2018-02-21 16:11:46 --> Controller Class Initialized
DEBUG - 2018-02-21 16:11:46 --> Config file loaded: /var/www/html/project/radio/application/config/rest.php
INFO - 2018-02-21 16:11:46 --> Helper loaded: inflector_helper
INFO - 2018-02-21 16:11:46 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-21 16:11:46 --> Model Class Initialized
INFO - 2018-02-21 16:11:46 --> Model Class Initialized
INFO - 2018-02-21 16:11:46 --> Model Class Initialized
INFO - 2018-02-21 16:11:46 --> Model Class Initialized
INFO - 2018-02-21 16:11:46 --> Model Class Initialized
INFO - 2018-02-21 16:11:56 --> Config Class Initialized
INFO - 2018-02-21 16:11:56 --> Hooks Class Initialized
DEBUG - 2018-02-21 16:11:56 --> UTF-8 Support Enabled
INFO - 2018-02-21 16:11:56 --> Utf8 Class Initialized
INFO - 2018-02-21 16:11:56 --> URI Class Initialized
INFO - 2018-02-21 16:11:56 --> Router Class Initialized
INFO - 2018-02-21 16:11:56 --> Output Class Initialized
INFO - 2018-02-21 16:11:56 --> Security Class Initialized
DEBUG - 2018-02-21 16:11:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-21 16:11:56 --> Input Class Initialized
INFO - 2018-02-21 16:11:56 --> Language Class Initialized
INFO - 2018-02-21 16:11:56 --> Loader Class Initialized
INFO - 2018-02-21 16:11:56 --> Helper loaded: url_helper
INFO - 2018-02-21 16:11:56 --> Helper loaded: file_helper
INFO - 2018-02-21 16:11:56 --> Helper loaded: email_helper
INFO - 2018-02-21 16:11:56 --> Helper loaded: common_helper
INFO - 2018-02-21 16:11:56 --> Database Driver Class Initialized
DEBUG - 2018-02-21 16:11:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-21 16:11:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-21 16:11:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-21 16:11:56 --> Pagination Class Initialized
INFO - 2018-02-21 16:11:56 --> Helper loaded: form_helper
INFO - 2018-02-21 16:11:56 --> Form Validation Class Initialized
INFO - 2018-02-21 16:11:56 --> Model Class Initialized
INFO - 2018-02-21 16:11:56 --> Controller Class Initialized
DEBUG - 2018-02-21 16:11:56 --> Config file loaded: /var/www/html/project/radio/application/config/rest.php
INFO - 2018-02-21 16:11:56 --> Helper loaded: inflector_helper
INFO - 2018-02-21 16:11:56 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-21 16:11:56 --> Model Class Initialized
INFO - 2018-02-21 16:11:56 --> Model Class Initialized
INFO - 2018-02-21 16:11:56 --> Model Class Initialized
INFO - 2018-02-21 16:11:56 --> Model Class Initialized
INFO - 2018-02-21 16:11:56 --> Model Class Initialized
INFO - 2018-02-21 16:12:16 --> Config Class Initialized
INFO - 2018-02-21 16:12:16 --> Hooks Class Initialized
DEBUG - 2018-02-21 16:12:16 --> UTF-8 Support Enabled
INFO - 2018-02-21 16:12:16 --> Utf8 Class Initialized
INFO - 2018-02-21 16:12:16 --> URI Class Initialized
INFO - 2018-02-21 16:12:16 --> Router Class Initialized
INFO - 2018-02-21 16:12:16 --> Output Class Initialized
INFO - 2018-02-21 16:12:16 --> Security Class Initialized
DEBUG - 2018-02-21 16:12:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-21 16:12:16 --> Input Class Initialized
INFO - 2018-02-21 16:12:16 --> Language Class Initialized
INFO - 2018-02-21 16:12:16 --> Loader Class Initialized
INFO - 2018-02-21 16:12:16 --> Helper loaded: url_helper
INFO - 2018-02-21 16:12:16 --> Helper loaded: file_helper
INFO - 2018-02-21 16:12:16 --> Helper loaded: email_helper
INFO - 2018-02-21 16:12:16 --> Helper loaded: common_helper
INFO - 2018-02-21 16:12:16 --> Database Driver Class Initialized
DEBUG - 2018-02-21 16:12:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-21 16:12:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-21 16:12:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-21 16:12:16 --> Pagination Class Initialized
INFO - 2018-02-21 16:12:16 --> Helper loaded: form_helper
INFO - 2018-02-21 16:12:16 --> Form Validation Class Initialized
INFO - 2018-02-21 16:12:16 --> Model Class Initialized
INFO - 2018-02-21 16:12:16 --> Controller Class Initialized
DEBUG - 2018-02-21 16:12:16 --> Config file loaded: /var/www/html/project/radio/application/config/rest.php
INFO - 2018-02-21 16:12:16 --> Helper loaded: inflector_helper
INFO - 2018-02-21 16:12:16 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-21 16:12:16 --> Model Class Initialized
INFO - 2018-02-21 16:12:16 --> Model Class Initialized
INFO - 2018-02-21 16:12:16 --> Model Class Initialized
INFO - 2018-02-21 16:12:16 --> Model Class Initialized
INFO - 2018-02-21 16:12:16 --> Model Class Initialized
INFO - 2018-02-21 16:12:25 --> Config Class Initialized
INFO - 2018-02-21 16:12:25 --> Hooks Class Initialized
DEBUG - 2018-02-21 16:12:25 --> UTF-8 Support Enabled
INFO - 2018-02-21 16:12:25 --> Utf8 Class Initialized
INFO - 2018-02-21 16:12:25 --> URI Class Initialized
INFO - 2018-02-21 16:12:25 --> Router Class Initialized
INFO - 2018-02-21 16:12:25 --> Output Class Initialized
INFO - 2018-02-21 16:12:25 --> Security Class Initialized
DEBUG - 2018-02-21 16:12:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-21 16:12:25 --> Input Class Initialized
INFO - 2018-02-21 16:12:25 --> Language Class Initialized
INFO - 2018-02-21 16:12:25 --> Loader Class Initialized
INFO - 2018-02-21 16:12:25 --> Helper loaded: url_helper
INFO - 2018-02-21 16:12:25 --> Helper loaded: file_helper
INFO - 2018-02-21 16:12:25 --> Helper loaded: email_helper
INFO - 2018-02-21 16:12:25 --> Helper loaded: common_helper
INFO - 2018-02-21 16:12:25 --> Database Driver Class Initialized
DEBUG - 2018-02-21 16:12:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-21 16:12:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-21 16:12:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-21 16:12:25 --> Pagination Class Initialized
INFO - 2018-02-21 16:12:25 --> Helper loaded: form_helper
INFO - 2018-02-21 16:12:25 --> Form Validation Class Initialized
INFO - 2018-02-21 16:12:25 --> Model Class Initialized
INFO - 2018-02-21 16:12:25 --> Controller Class Initialized
DEBUG - 2018-02-21 16:12:25 --> Config file loaded: /var/www/html/project/radio/application/config/rest.php
INFO - 2018-02-21 16:12:25 --> Helper loaded: inflector_helper
INFO - 2018-02-21 16:12:25 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-21 16:12:25 --> Model Class Initialized
INFO - 2018-02-21 16:12:25 --> Model Class Initialized
INFO - 2018-02-21 16:12:25 --> Model Class Initialized
INFO - 2018-02-21 16:12:25 --> Model Class Initialized
INFO - 2018-02-21 16:12:25 --> Model Class Initialized
INFO - 2018-02-21 16:12:38 --> Config Class Initialized
INFO - 2018-02-21 16:12:38 --> Hooks Class Initialized
DEBUG - 2018-02-21 16:12:38 --> UTF-8 Support Enabled
INFO - 2018-02-21 16:12:38 --> Utf8 Class Initialized
INFO - 2018-02-21 16:12:38 --> URI Class Initialized
INFO - 2018-02-21 16:12:38 --> Router Class Initialized
INFO - 2018-02-21 16:12:38 --> Output Class Initialized
INFO - 2018-02-21 16:12:38 --> Security Class Initialized
DEBUG - 2018-02-21 16:12:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-21 16:12:38 --> Input Class Initialized
INFO - 2018-02-21 16:12:38 --> Language Class Initialized
INFO - 2018-02-21 16:12:38 --> Loader Class Initialized
INFO - 2018-02-21 16:12:38 --> Helper loaded: url_helper
INFO - 2018-02-21 16:12:38 --> Helper loaded: file_helper
INFO - 2018-02-21 16:12:38 --> Helper loaded: email_helper
INFO - 2018-02-21 16:12:38 --> Helper loaded: common_helper
INFO - 2018-02-21 16:12:38 --> Database Driver Class Initialized
DEBUG - 2018-02-21 16:12:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-21 16:12:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-21 16:12:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-21 16:12:38 --> Pagination Class Initialized
INFO - 2018-02-21 16:12:38 --> Helper loaded: form_helper
INFO - 2018-02-21 16:12:38 --> Form Validation Class Initialized
INFO - 2018-02-21 16:12:38 --> Model Class Initialized
INFO - 2018-02-21 16:12:38 --> Controller Class Initialized
DEBUG - 2018-02-21 16:12:38 --> Config file loaded: /var/www/html/project/radio/application/config/rest.php
INFO - 2018-02-21 16:12:38 --> Helper loaded: inflector_helper
INFO - 2018-02-21 16:12:38 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-21 16:12:38 --> Model Class Initialized
INFO - 2018-02-21 16:12:38 --> Model Class Initialized
INFO - 2018-02-21 16:12:38 --> Model Class Initialized
INFO - 2018-02-21 16:12:38 --> Model Class Initialized
INFO - 2018-02-21 16:12:38 --> Model Class Initialized
INFO - 2018-02-21 16:12:45 --> Config Class Initialized
INFO - 2018-02-21 16:12:45 --> Hooks Class Initialized
DEBUG - 2018-02-21 16:12:45 --> UTF-8 Support Enabled
INFO - 2018-02-21 16:12:45 --> Utf8 Class Initialized
INFO - 2018-02-21 16:12:45 --> URI Class Initialized
INFO - 2018-02-21 16:12:45 --> Router Class Initialized
INFO - 2018-02-21 16:12:45 --> Output Class Initialized
INFO - 2018-02-21 16:12:45 --> Security Class Initialized
DEBUG - 2018-02-21 16:12:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-21 16:12:45 --> Input Class Initialized
INFO - 2018-02-21 16:12:45 --> Language Class Initialized
INFO - 2018-02-21 16:12:45 --> Loader Class Initialized
INFO - 2018-02-21 16:12:45 --> Helper loaded: url_helper
INFO - 2018-02-21 16:12:45 --> Helper loaded: file_helper
INFO - 2018-02-21 16:12:45 --> Helper loaded: email_helper
INFO - 2018-02-21 16:12:45 --> Helper loaded: common_helper
INFO - 2018-02-21 16:12:45 --> Database Driver Class Initialized
DEBUG - 2018-02-21 16:12:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-21 16:12:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-21 16:12:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-21 16:12:45 --> Pagination Class Initialized
INFO - 2018-02-21 16:12:45 --> Helper loaded: form_helper
INFO - 2018-02-21 16:12:45 --> Form Validation Class Initialized
INFO - 2018-02-21 16:12:45 --> Model Class Initialized
INFO - 2018-02-21 16:12:45 --> Controller Class Initialized
DEBUG - 2018-02-21 16:12:45 --> Config file loaded: /var/www/html/project/radio/application/config/rest.php
INFO - 2018-02-21 16:12:45 --> Helper loaded: inflector_helper
INFO - 2018-02-21 16:12:45 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-21 16:12:45 --> Model Class Initialized
INFO - 2018-02-21 16:12:45 --> Model Class Initialized
INFO - 2018-02-21 16:12:45 --> Model Class Initialized
INFO - 2018-02-21 16:12:45 --> Model Class Initialized
INFO - 2018-02-21 16:12:45 --> Model Class Initialized
INFO - 2018-02-21 16:12:50 --> Config Class Initialized
INFO - 2018-02-21 16:12:50 --> Hooks Class Initialized
DEBUG - 2018-02-21 16:12:50 --> UTF-8 Support Enabled
INFO - 2018-02-21 16:12:50 --> Utf8 Class Initialized
INFO - 2018-02-21 16:12:50 --> URI Class Initialized
INFO - 2018-02-21 16:12:50 --> Router Class Initialized
INFO - 2018-02-21 16:12:50 --> Output Class Initialized
INFO - 2018-02-21 16:12:50 --> Security Class Initialized
DEBUG - 2018-02-21 16:12:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-21 16:12:50 --> Input Class Initialized
INFO - 2018-02-21 16:12:50 --> Language Class Initialized
INFO - 2018-02-21 16:12:50 --> Loader Class Initialized
INFO - 2018-02-21 16:12:50 --> Helper loaded: url_helper
INFO - 2018-02-21 16:12:50 --> Helper loaded: file_helper
INFO - 2018-02-21 16:12:50 --> Helper loaded: email_helper
INFO - 2018-02-21 16:12:50 --> Helper loaded: common_helper
INFO - 2018-02-21 16:12:50 --> Database Driver Class Initialized
DEBUG - 2018-02-21 16:12:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-21 16:12:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-21 16:12:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-21 16:12:50 --> Pagination Class Initialized
INFO - 2018-02-21 16:12:50 --> Helper loaded: form_helper
INFO - 2018-02-21 16:12:50 --> Form Validation Class Initialized
INFO - 2018-02-21 16:12:50 --> Model Class Initialized
INFO - 2018-02-21 16:12:50 --> Controller Class Initialized
DEBUG - 2018-02-21 16:12:50 --> Config file loaded: /var/www/html/project/radio/application/config/rest.php
INFO - 2018-02-21 16:12:50 --> Helper loaded: inflector_helper
INFO - 2018-02-21 16:12:50 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-21 16:12:50 --> Model Class Initialized
INFO - 2018-02-21 16:12:50 --> Model Class Initialized
INFO - 2018-02-21 16:12:50 --> Model Class Initialized
INFO - 2018-02-21 16:12:50 --> Model Class Initialized
INFO - 2018-02-21 16:12:50 --> Model Class Initialized
INFO - 2018-02-21 16:12:55 --> Config Class Initialized
INFO - 2018-02-21 16:12:55 --> Hooks Class Initialized
DEBUG - 2018-02-21 16:12:55 --> UTF-8 Support Enabled
INFO - 2018-02-21 16:12:55 --> Utf8 Class Initialized
INFO - 2018-02-21 16:12:55 --> URI Class Initialized
INFO - 2018-02-21 16:12:55 --> Router Class Initialized
INFO - 2018-02-21 16:12:55 --> Output Class Initialized
INFO - 2018-02-21 16:12:55 --> Security Class Initialized
DEBUG - 2018-02-21 16:12:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-21 16:12:55 --> Input Class Initialized
INFO - 2018-02-21 16:12:55 --> Language Class Initialized
INFO - 2018-02-21 16:12:55 --> Loader Class Initialized
INFO - 2018-02-21 16:12:55 --> Helper loaded: url_helper
INFO - 2018-02-21 16:12:55 --> Helper loaded: file_helper
INFO - 2018-02-21 16:12:55 --> Helper loaded: email_helper
INFO - 2018-02-21 16:12:55 --> Helper loaded: common_helper
INFO - 2018-02-21 16:12:55 --> Database Driver Class Initialized
DEBUG - 2018-02-21 16:12:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-21 16:12:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-21 16:12:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-21 16:12:55 --> Pagination Class Initialized
INFO - 2018-02-21 16:12:55 --> Helper loaded: form_helper
INFO - 2018-02-21 16:12:55 --> Form Validation Class Initialized
INFO - 2018-02-21 16:12:55 --> Model Class Initialized
INFO - 2018-02-21 16:12:55 --> Controller Class Initialized
DEBUG - 2018-02-21 16:12:55 --> Config file loaded: /var/www/html/project/radio/application/config/rest.php
INFO - 2018-02-21 16:12:55 --> Helper loaded: inflector_helper
INFO - 2018-02-21 16:12:55 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-21 16:12:55 --> Model Class Initialized
INFO - 2018-02-21 16:12:55 --> Model Class Initialized
INFO - 2018-02-21 16:12:55 --> Model Class Initialized
INFO - 2018-02-21 16:12:55 --> Model Class Initialized
INFO - 2018-02-21 16:12:55 --> Model Class Initialized
INFO - 2018-02-21 16:12:59 --> Config Class Initialized
INFO - 2018-02-21 16:12:59 --> Hooks Class Initialized
DEBUG - 2018-02-21 16:12:59 --> UTF-8 Support Enabled
INFO - 2018-02-21 16:12:59 --> Utf8 Class Initialized
INFO - 2018-02-21 16:12:59 --> URI Class Initialized
INFO - 2018-02-21 16:12:59 --> Router Class Initialized
INFO - 2018-02-21 16:12:59 --> Output Class Initialized
INFO - 2018-02-21 16:12:59 --> Security Class Initialized
DEBUG - 2018-02-21 16:12:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-21 16:12:59 --> Input Class Initialized
INFO - 2018-02-21 16:12:59 --> Language Class Initialized
INFO - 2018-02-21 16:12:59 --> Loader Class Initialized
INFO - 2018-02-21 16:12:59 --> Helper loaded: url_helper
INFO - 2018-02-21 16:12:59 --> Helper loaded: file_helper
INFO - 2018-02-21 16:12:59 --> Helper loaded: email_helper
INFO - 2018-02-21 16:12:59 --> Helper loaded: common_helper
INFO - 2018-02-21 16:12:59 --> Database Driver Class Initialized
DEBUG - 2018-02-21 16:12:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-21 16:12:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-21 16:12:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-21 16:12:59 --> Pagination Class Initialized
INFO - 2018-02-21 16:12:59 --> Helper loaded: form_helper
INFO - 2018-02-21 16:12:59 --> Form Validation Class Initialized
INFO - 2018-02-21 16:12:59 --> Model Class Initialized
INFO - 2018-02-21 16:12:59 --> Controller Class Initialized
DEBUG - 2018-02-21 16:12:59 --> Config file loaded: /var/www/html/project/radio/application/config/rest.php
INFO - 2018-02-21 16:12:59 --> Helper loaded: inflector_helper
INFO - 2018-02-21 16:12:59 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-21 16:12:59 --> Model Class Initialized
INFO - 2018-02-21 16:12:59 --> Model Class Initialized
INFO - 2018-02-21 16:12:59 --> Model Class Initialized
INFO - 2018-02-21 16:12:59 --> Model Class Initialized
INFO - 2018-02-21 16:12:59 --> Model Class Initialized
INFO - 2018-02-21 16:13:17 --> Config Class Initialized
INFO - 2018-02-21 16:13:17 --> Hooks Class Initialized
DEBUG - 2018-02-21 16:13:17 --> UTF-8 Support Enabled
INFO - 2018-02-21 16:13:17 --> Utf8 Class Initialized
INFO - 2018-02-21 16:13:17 --> URI Class Initialized
INFO - 2018-02-21 16:13:17 --> Router Class Initialized
INFO - 2018-02-21 16:13:17 --> Output Class Initialized
INFO - 2018-02-21 16:13:17 --> Security Class Initialized
DEBUG - 2018-02-21 16:13:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-21 16:13:17 --> Input Class Initialized
INFO - 2018-02-21 16:13:17 --> Language Class Initialized
INFO - 2018-02-21 16:13:17 --> Loader Class Initialized
INFO - 2018-02-21 16:13:17 --> Helper loaded: url_helper
INFO - 2018-02-21 16:13:17 --> Helper loaded: file_helper
INFO - 2018-02-21 16:13:17 --> Helper loaded: email_helper
INFO - 2018-02-21 16:13:17 --> Helper loaded: common_helper
INFO - 2018-02-21 16:13:17 --> Database Driver Class Initialized
DEBUG - 2018-02-21 16:13:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-21 16:13:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-21 16:13:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-21 16:13:17 --> Pagination Class Initialized
INFO - 2018-02-21 16:13:17 --> Helper loaded: form_helper
INFO - 2018-02-21 16:13:17 --> Form Validation Class Initialized
INFO - 2018-02-21 16:13:17 --> Model Class Initialized
INFO - 2018-02-21 16:13:17 --> Controller Class Initialized
DEBUG - 2018-02-21 16:13:17 --> Config file loaded: /var/www/html/project/radio/application/config/rest.php
INFO - 2018-02-21 16:13:17 --> Helper loaded: inflector_helper
INFO - 2018-02-21 16:13:17 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-21 16:13:17 --> Model Class Initialized
INFO - 2018-02-21 16:13:17 --> Model Class Initialized
INFO - 2018-02-21 16:13:17 --> Model Class Initialized
INFO - 2018-02-21 16:13:17 --> Model Class Initialized
INFO - 2018-02-21 16:13:17 --> Model Class Initialized
INFO - 2018-02-21 16:14:15 --> Config Class Initialized
INFO - 2018-02-21 16:14:15 --> Hooks Class Initialized
DEBUG - 2018-02-21 16:14:15 --> UTF-8 Support Enabled
INFO - 2018-02-21 16:14:15 --> Utf8 Class Initialized
INFO - 2018-02-21 16:14:15 --> URI Class Initialized
INFO - 2018-02-21 16:14:15 --> Router Class Initialized
INFO - 2018-02-21 16:14:15 --> Output Class Initialized
INFO - 2018-02-21 16:14:15 --> Security Class Initialized
DEBUG - 2018-02-21 16:14:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-21 16:14:15 --> Input Class Initialized
INFO - 2018-02-21 16:14:15 --> Language Class Initialized
INFO - 2018-02-21 16:14:15 --> Loader Class Initialized
INFO - 2018-02-21 16:14:15 --> Helper loaded: url_helper
INFO - 2018-02-21 16:14:15 --> Helper loaded: file_helper
INFO - 2018-02-21 16:14:15 --> Helper loaded: email_helper
INFO - 2018-02-21 16:14:15 --> Helper loaded: common_helper
INFO - 2018-02-21 16:14:15 --> Database Driver Class Initialized
DEBUG - 2018-02-21 16:14:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-21 16:14:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-21 16:14:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-21 16:14:15 --> Pagination Class Initialized
INFO - 2018-02-21 16:14:15 --> Helper loaded: form_helper
INFO - 2018-02-21 16:14:15 --> Form Validation Class Initialized
INFO - 2018-02-21 16:14:15 --> Model Class Initialized
INFO - 2018-02-21 16:14:15 --> Controller Class Initialized
DEBUG - 2018-02-21 16:14:15 --> Config file loaded: /var/www/html/project/radio/application/config/rest.php
INFO - 2018-02-21 16:14:15 --> Helper loaded: inflector_helper
INFO - 2018-02-21 16:14:15 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-21 16:14:15 --> Model Class Initialized
INFO - 2018-02-21 16:14:15 --> Model Class Initialized
INFO - 2018-02-21 16:14:15 --> Model Class Initialized
INFO - 2018-02-21 16:14:15 --> Model Class Initialized
INFO - 2018-02-21 16:14:15 --> Model Class Initialized
INFO - 2018-02-21 16:14:15 --> Final output sent to browser
DEBUG - 2018-02-21 16:14:15 --> Total execution time: 0.0086
INFO - 2018-02-21 16:15:10 --> Config Class Initialized
INFO - 2018-02-21 16:15:10 --> Hooks Class Initialized
DEBUG - 2018-02-21 16:15:10 --> UTF-8 Support Enabled
INFO - 2018-02-21 16:15:10 --> Utf8 Class Initialized
INFO - 2018-02-21 16:15:10 --> URI Class Initialized
INFO - 2018-02-21 16:15:10 --> Router Class Initialized
INFO - 2018-02-21 16:15:10 --> Output Class Initialized
INFO - 2018-02-21 16:15:10 --> Security Class Initialized
DEBUG - 2018-02-21 16:15:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-21 16:15:10 --> Input Class Initialized
INFO - 2018-02-21 16:15:10 --> Language Class Initialized
INFO - 2018-02-21 16:15:10 --> Loader Class Initialized
INFO - 2018-02-21 16:15:10 --> Helper loaded: url_helper
INFO - 2018-02-21 16:15:10 --> Helper loaded: file_helper
INFO - 2018-02-21 16:15:10 --> Helper loaded: email_helper
INFO - 2018-02-21 16:15:10 --> Helper loaded: common_helper
INFO - 2018-02-21 16:15:10 --> Database Driver Class Initialized
DEBUG - 2018-02-21 16:15:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-21 16:15:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-21 16:15:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-21 16:15:10 --> Pagination Class Initialized
INFO - 2018-02-21 16:15:10 --> Helper loaded: form_helper
INFO - 2018-02-21 16:15:10 --> Form Validation Class Initialized
INFO - 2018-02-21 16:15:10 --> Model Class Initialized
INFO - 2018-02-21 16:15:10 --> Controller Class Initialized
DEBUG - 2018-02-21 16:15:10 --> Config file loaded: /var/www/html/project/radio/application/config/rest.php
INFO - 2018-02-21 16:15:10 --> Helper loaded: inflector_helper
INFO - 2018-02-21 16:15:10 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-21 16:15:10 --> Model Class Initialized
INFO - 2018-02-21 16:15:10 --> Model Class Initialized
INFO - 2018-02-21 16:15:10 --> Model Class Initialized
INFO - 2018-02-21 16:15:10 --> Model Class Initialized
INFO - 2018-02-21 16:15:10 --> Model Class Initialized
INFO - 2018-02-21 16:15:26 --> Config Class Initialized
INFO - 2018-02-21 16:15:26 --> Hooks Class Initialized
DEBUG - 2018-02-21 16:15:26 --> UTF-8 Support Enabled
INFO - 2018-02-21 16:15:26 --> Utf8 Class Initialized
INFO - 2018-02-21 16:15:26 --> URI Class Initialized
INFO - 2018-02-21 16:15:26 --> Router Class Initialized
INFO - 2018-02-21 16:15:26 --> Output Class Initialized
INFO - 2018-02-21 16:15:26 --> Security Class Initialized
DEBUG - 2018-02-21 16:15:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-21 16:15:26 --> Input Class Initialized
INFO - 2018-02-21 16:15:26 --> Language Class Initialized
INFO - 2018-02-21 16:15:26 --> Loader Class Initialized
INFO - 2018-02-21 16:15:26 --> Helper loaded: url_helper
INFO - 2018-02-21 16:15:26 --> Helper loaded: file_helper
INFO - 2018-02-21 16:15:26 --> Helper loaded: email_helper
INFO - 2018-02-21 16:15:26 --> Helper loaded: common_helper
INFO - 2018-02-21 16:15:26 --> Database Driver Class Initialized
DEBUG - 2018-02-21 16:15:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-21 16:15:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-21 16:15:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-21 16:15:26 --> Pagination Class Initialized
INFO - 2018-02-21 16:15:26 --> Helper loaded: form_helper
INFO - 2018-02-21 16:15:26 --> Form Validation Class Initialized
INFO - 2018-02-21 16:15:26 --> Model Class Initialized
INFO - 2018-02-21 16:15:26 --> Controller Class Initialized
DEBUG - 2018-02-21 16:15:26 --> Config file loaded: /var/www/html/project/radio/application/config/rest.php
INFO - 2018-02-21 16:15:26 --> Helper loaded: inflector_helper
INFO - 2018-02-21 16:15:26 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-21 16:15:26 --> Model Class Initialized
INFO - 2018-02-21 16:15:26 --> Model Class Initialized
INFO - 2018-02-21 16:15:26 --> Model Class Initialized
INFO - 2018-02-21 16:15:26 --> Model Class Initialized
INFO - 2018-02-21 16:15:26 --> Model Class Initialized
INFO - 2018-02-21 16:15:26 --> Final output sent to browser
DEBUG - 2018-02-21 16:15:26 --> Total execution time: 0.0069
INFO - 2018-02-21 16:26:54 --> Config Class Initialized
INFO - 2018-02-21 16:26:54 --> Hooks Class Initialized
DEBUG - 2018-02-21 16:26:54 --> UTF-8 Support Enabled
INFO - 2018-02-21 16:26:54 --> Utf8 Class Initialized
INFO - 2018-02-21 16:26:54 --> URI Class Initialized
INFO - 2018-02-21 16:26:54 --> Router Class Initialized
INFO - 2018-02-21 16:26:54 --> Output Class Initialized
INFO - 2018-02-21 16:26:54 --> Security Class Initialized
DEBUG - 2018-02-21 16:26:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-21 16:26:54 --> Input Class Initialized
INFO - 2018-02-21 16:26:54 --> Language Class Initialized
INFO - 2018-02-21 16:26:54 --> Loader Class Initialized
INFO - 2018-02-21 16:26:54 --> Helper loaded: url_helper
INFO - 2018-02-21 16:26:54 --> Helper loaded: file_helper
INFO - 2018-02-21 16:26:54 --> Helper loaded: email_helper
INFO - 2018-02-21 16:26:54 --> Helper loaded: common_helper
INFO - 2018-02-21 16:26:54 --> Database Driver Class Initialized
DEBUG - 2018-02-21 16:26:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-21 16:26:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-21 16:26:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-21 16:26:54 --> Pagination Class Initialized
INFO - 2018-02-21 16:26:54 --> Helper loaded: form_helper
INFO - 2018-02-21 16:26:54 --> Form Validation Class Initialized
INFO - 2018-02-21 16:26:54 --> Model Class Initialized
INFO - 2018-02-21 16:26:54 --> Controller Class Initialized
DEBUG - 2018-02-21 16:26:54 --> Config file loaded: /var/www/html/project/radio/application/config/rest.php
INFO - 2018-02-21 16:26:54 --> Helper loaded: inflector_helper
INFO - 2018-02-21 16:26:54 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-21 16:26:54 --> Model Class Initialized
INFO - 2018-02-21 16:26:54 --> Model Class Initialized
INFO - 2018-02-21 16:26:54 --> Model Class Initialized
INFO - 2018-02-21 16:26:54 --> Model Class Initialized
INFO - 2018-02-21 16:26:54 --> Model Class Initialized
INFO - 2018-02-21 16:26:54 --> Final output sent to browser
DEBUG - 2018-02-21 16:26:54 --> Total execution time: 0.0071
INFO - 2018-02-21 16:27:03 --> Config Class Initialized
INFO - 2018-02-21 16:27:03 --> Hooks Class Initialized
DEBUG - 2018-02-21 16:27:03 --> UTF-8 Support Enabled
INFO - 2018-02-21 16:27:03 --> Utf8 Class Initialized
INFO - 2018-02-21 16:27:03 --> URI Class Initialized
INFO - 2018-02-21 16:27:03 --> Router Class Initialized
INFO - 2018-02-21 16:27:03 --> Output Class Initialized
INFO - 2018-02-21 16:27:03 --> Security Class Initialized
DEBUG - 2018-02-21 16:27:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-21 16:27:03 --> Input Class Initialized
INFO - 2018-02-21 16:27:03 --> Language Class Initialized
INFO - 2018-02-21 16:27:03 --> Loader Class Initialized
INFO - 2018-02-21 16:27:03 --> Helper loaded: url_helper
INFO - 2018-02-21 16:27:03 --> Helper loaded: file_helper
INFO - 2018-02-21 16:27:03 --> Helper loaded: email_helper
INFO - 2018-02-21 16:27:03 --> Helper loaded: common_helper
INFO - 2018-02-21 16:27:03 --> Database Driver Class Initialized
DEBUG - 2018-02-21 16:27:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-21 16:27:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-21 16:27:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-21 16:27:03 --> Pagination Class Initialized
INFO - 2018-02-21 16:27:03 --> Helper loaded: form_helper
INFO - 2018-02-21 16:27:03 --> Form Validation Class Initialized
INFO - 2018-02-21 16:27:03 --> Model Class Initialized
INFO - 2018-02-21 16:27:03 --> Controller Class Initialized
DEBUG - 2018-02-21 16:27:03 --> Config file loaded: /var/www/html/project/radio/application/config/rest.php
INFO - 2018-02-21 16:27:03 --> Helper loaded: inflector_helper
INFO - 2018-02-21 16:27:03 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-21 16:27:03 --> Model Class Initialized
INFO - 2018-02-21 16:27:03 --> Model Class Initialized
INFO - 2018-02-21 16:27:03 --> Model Class Initialized
INFO - 2018-02-21 16:27:03 --> Model Class Initialized
INFO - 2018-02-21 16:27:03 --> Model Class Initialized
INFO - 2018-02-21 16:27:03 --> Final output sent to browser
DEBUG - 2018-02-21 16:27:03 --> Total execution time: 0.0073
INFO - 2018-02-21 16:34:26 --> Config Class Initialized
INFO - 2018-02-21 16:34:26 --> Hooks Class Initialized
DEBUG - 2018-02-21 16:34:26 --> UTF-8 Support Enabled
INFO - 2018-02-21 16:34:26 --> Utf8 Class Initialized
INFO - 2018-02-21 16:34:26 --> URI Class Initialized
INFO - 2018-02-21 16:34:26 --> Router Class Initialized
INFO - 2018-02-21 16:34:26 --> Output Class Initialized
INFO - 2018-02-21 16:34:26 --> Security Class Initialized
DEBUG - 2018-02-21 16:34:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-21 16:34:26 --> Input Class Initialized
INFO - 2018-02-21 16:34:26 --> Language Class Initialized
INFO - 2018-02-21 16:34:26 --> Loader Class Initialized
INFO - 2018-02-21 16:34:26 --> Helper loaded: url_helper
INFO - 2018-02-21 16:34:26 --> Helper loaded: file_helper
INFO - 2018-02-21 16:34:26 --> Helper loaded: email_helper
INFO - 2018-02-21 16:34:26 --> Helper loaded: common_helper
INFO - 2018-02-21 16:34:26 --> Database Driver Class Initialized
DEBUG - 2018-02-21 16:34:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-21 16:34:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-21 16:34:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-21 16:34:26 --> Pagination Class Initialized
INFO - 2018-02-21 16:34:26 --> Helper loaded: form_helper
INFO - 2018-02-21 16:34:26 --> Form Validation Class Initialized
INFO - 2018-02-21 16:34:26 --> Model Class Initialized
INFO - 2018-02-21 16:34:26 --> Controller Class Initialized
DEBUG - 2018-02-21 16:34:26 --> Config file loaded: /var/www/html/project/radio/application/config/rest.php
INFO - 2018-02-21 16:34:26 --> Helper loaded: inflector_helper
INFO - 2018-02-21 16:34:26 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-21 16:34:26 --> Model Class Initialized
INFO - 2018-02-21 16:34:26 --> Model Class Initialized
INFO - 2018-02-21 16:34:26 --> Model Class Initialized
INFO - 2018-02-21 16:34:26 --> Model Class Initialized
INFO - 2018-02-21 16:34:26 --> Model Class Initialized
INFO - 2018-02-21 16:34:26 --> Final output sent to browser
DEBUG - 2018-02-21 16:34:26 --> Total execution time: 0.0065
INFO - 2018-02-21 16:34:30 --> Config Class Initialized
INFO - 2018-02-21 16:34:30 --> Hooks Class Initialized
DEBUG - 2018-02-21 16:34:30 --> UTF-8 Support Enabled
INFO - 2018-02-21 16:34:30 --> Utf8 Class Initialized
INFO - 2018-02-21 16:34:30 --> URI Class Initialized
INFO - 2018-02-21 16:34:30 --> Router Class Initialized
INFO - 2018-02-21 16:34:30 --> Output Class Initialized
INFO - 2018-02-21 16:34:30 --> Security Class Initialized
DEBUG - 2018-02-21 16:34:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-21 16:34:30 --> Input Class Initialized
INFO - 2018-02-21 16:34:30 --> Language Class Initialized
INFO - 2018-02-21 16:34:30 --> Loader Class Initialized
INFO - 2018-02-21 16:34:30 --> Helper loaded: url_helper
INFO - 2018-02-21 16:34:30 --> Helper loaded: file_helper
INFO - 2018-02-21 16:34:30 --> Helper loaded: email_helper
INFO - 2018-02-21 16:34:30 --> Helper loaded: common_helper
INFO - 2018-02-21 16:34:30 --> Database Driver Class Initialized
DEBUG - 2018-02-21 16:34:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-21 16:34:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-21 16:34:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-21 16:34:30 --> Pagination Class Initialized
INFO - 2018-02-21 16:34:30 --> Helper loaded: form_helper
INFO - 2018-02-21 16:34:30 --> Form Validation Class Initialized
INFO - 2018-02-21 16:34:30 --> Model Class Initialized
INFO - 2018-02-21 16:34:30 --> Controller Class Initialized
DEBUG - 2018-02-21 16:34:30 --> Config file loaded: /var/www/html/project/radio/application/config/rest.php
INFO - 2018-02-21 16:34:30 --> Helper loaded: inflector_helper
INFO - 2018-02-21 16:34:30 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-21 16:34:30 --> Model Class Initialized
INFO - 2018-02-21 16:34:30 --> Model Class Initialized
INFO - 2018-02-21 16:34:30 --> Model Class Initialized
INFO - 2018-02-21 16:34:30 --> Model Class Initialized
INFO - 2018-02-21 16:34:30 --> Model Class Initialized
INFO - 2018-02-21 16:34:30 --> Final output sent to browser
DEBUG - 2018-02-21 16:34:30 --> Total execution time: 0.0076
INFO - 2018-02-21 16:36:22 --> Config Class Initialized
INFO - 2018-02-21 16:36:22 --> Hooks Class Initialized
DEBUG - 2018-02-21 16:36:22 --> UTF-8 Support Enabled
INFO - 2018-02-21 16:36:22 --> Utf8 Class Initialized
INFO - 2018-02-21 16:36:22 --> URI Class Initialized
INFO - 2018-02-21 16:36:22 --> Router Class Initialized
INFO - 2018-02-21 16:36:22 --> Output Class Initialized
INFO - 2018-02-21 16:36:22 --> Security Class Initialized
DEBUG - 2018-02-21 16:36:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-21 16:36:22 --> Input Class Initialized
INFO - 2018-02-21 16:36:22 --> Language Class Initialized
INFO - 2018-02-21 16:36:22 --> Loader Class Initialized
INFO - 2018-02-21 16:36:22 --> Helper loaded: url_helper
INFO - 2018-02-21 16:36:22 --> Helper loaded: file_helper
INFO - 2018-02-21 16:36:22 --> Helper loaded: email_helper
INFO - 2018-02-21 16:36:22 --> Helper loaded: common_helper
INFO - 2018-02-21 16:36:22 --> Database Driver Class Initialized
DEBUG - 2018-02-21 16:36:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-21 16:36:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-21 16:36:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-21 16:36:22 --> Pagination Class Initialized
INFO - 2018-02-21 16:36:22 --> Helper loaded: form_helper
INFO - 2018-02-21 16:36:22 --> Form Validation Class Initialized
INFO - 2018-02-21 16:36:22 --> Model Class Initialized
INFO - 2018-02-21 16:36:22 --> Controller Class Initialized
INFO - 2018-02-21 16:36:22 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-21 16:36:22 --> Model Class Initialized
INFO - 2018-02-21 16:36:22 --> Model Class Initialized
ERROR - 2018-02-21 16:36:22 --> Severity: Notice --> Undefined index: remember_me /var/www/html/project/radio/application/controllers/Index.php 74
INFO - 2018-02-21 16:36:22 --> Config Class Initialized
INFO - 2018-02-21 16:36:22 --> Hooks Class Initialized
DEBUG - 2018-02-21 16:36:22 --> UTF-8 Support Enabled
INFO - 2018-02-21 16:36:22 --> Utf8 Class Initialized
INFO - 2018-02-21 16:36:22 --> URI Class Initialized
INFO - 2018-02-21 16:36:22 --> Router Class Initialized
INFO - 2018-02-21 16:36:22 --> Output Class Initialized
INFO - 2018-02-21 16:36:22 --> Security Class Initialized
DEBUG - 2018-02-21 16:36:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-21 16:36:22 --> Input Class Initialized
INFO - 2018-02-21 16:36:22 --> Language Class Initialized
INFO - 2018-02-21 16:36:22 --> Loader Class Initialized
INFO - 2018-02-21 16:36:22 --> Helper loaded: url_helper
INFO - 2018-02-21 16:36:22 --> Helper loaded: file_helper
INFO - 2018-02-21 16:36:22 --> Helper loaded: email_helper
INFO - 2018-02-21 16:36:22 --> Helper loaded: common_helper
INFO - 2018-02-21 16:36:22 --> Database Driver Class Initialized
DEBUG - 2018-02-21 16:36:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-21 16:36:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-21 16:36:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-21 16:36:22 --> Pagination Class Initialized
INFO - 2018-02-21 16:36:22 --> Helper loaded: form_helper
INFO - 2018-02-21 16:36:22 --> Form Validation Class Initialized
INFO - 2018-02-21 16:36:22 --> Model Class Initialized
INFO - 2018-02-21 16:36:22 --> Controller Class Initialized
INFO - 2018-02-21 16:36:22 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-21 16:36:22 --> Model Class Initialized
INFO - 2018-02-21 16:36:22 --> Model Class Initialized
INFO - 2018-02-21 16:36:22 --> Model Class Initialized
INFO - 2018-02-21 16:36:22 --> Model Class Initialized
INFO - 2018-02-21 16:36:22 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-21 16:36:22 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-21 16:36:22 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-21 16:36:22 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-21 16:36:22 --> File loaded: /var/www/html/project/radio/application/views/dashboard/index.php
INFO - 2018-02-21 16:36:22 --> Final output sent to browser
DEBUG - 2018-02-21 16:36:22 --> Total execution time: 0.2236
INFO - 2018-02-21 16:36:23 --> Config Class Initialized
INFO - 2018-02-21 16:36:23 --> Hooks Class Initialized
DEBUG - 2018-02-21 16:36:23 --> UTF-8 Support Enabled
INFO - 2018-02-21 16:36:23 --> Utf8 Class Initialized
INFO - 2018-02-21 16:36:23 --> URI Class Initialized
INFO - 2018-02-21 16:36:23 --> Router Class Initialized
INFO - 2018-02-21 16:36:23 --> Output Class Initialized
INFO - 2018-02-21 16:36:23 --> Security Class Initialized
DEBUG - 2018-02-21 16:36:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-21 16:36:23 --> Input Class Initialized
INFO - 2018-02-21 16:36:23 --> Language Class Initialized
INFO - 2018-02-21 16:36:23 --> Loader Class Initialized
INFO - 2018-02-21 16:36:23 --> Helper loaded: url_helper
INFO - 2018-02-21 16:36:23 --> Helper loaded: file_helper
INFO - 2018-02-21 16:36:23 --> Helper loaded: email_helper
INFO - 2018-02-21 16:36:23 --> Helper loaded: common_helper
INFO - 2018-02-21 16:36:23 --> Database Driver Class Initialized
DEBUG - 2018-02-21 16:36:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-21 16:36:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-21 16:36:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-21 16:36:23 --> Pagination Class Initialized
INFO - 2018-02-21 16:36:23 --> Helper loaded: form_helper
INFO - 2018-02-21 16:36:23 --> Form Validation Class Initialized
INFO - 2018-02-21 16:36:23 --> Model Class Initialized
INFO - 2018-02-21 16:36:23 --> Controller Class Initialized
INFO - 2018-02-21 16:36:23 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-21 16:36:23 --> Model Class Initialized
INFO - 2018-02-21 16:36:23 --> Model Class Initialized
INFO - 2018-02-21 16:36:23 --> Model Class Initialized
INFO - 2018-02-21 16:36:23 --> Model Class Initialized
INFO - 2018-02-21 16:36:23 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-21 16:36:23 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-21 16:36:23 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-21 16:36:23 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-21 16:36:23 --> File loaded: /var/www/html/project/radio/application/views/tracks/index.php
INFO - 2018-02-21 16:36:23 --> Final output sent to browser
DEBUG - 2018-02-21 16:36:23 --> Total execution time: 0.0093
INFO - 2018-02-21 16:36:24 --> Config Class Initialized
INFO - 2018-02-21 16:36:24 --> Hooks Class Initialized
DEBUG - 2018-02-21 16:36:24 --> UTF-8 Support Enabled
INFO - 2018-02-21 16:36:24 --> Utf8 Class Initialized
INFO - 2018-02-21 16:36:24 --> URI Class Initialized
INFO - 2018-02-21 16:36:24 --> Router Class Initialized
INFO - 2018-02-21 16:36:24 --> Output Class Initialized
INFO - 2018-02-21 16:36:24 --> Security Class Initialized
DEBUG - 2018-02-21 16:36:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-21 16:36:24 --> Input Class Initialized
INFO - 2018-02-21 16:36:24 --> Language Class Initialized
INFO - 2018-02-21 16:36:24 --> Loader Class Initialized
INFO - 2018-02-21 16:36:24 --> Helper loaded: url_helper
INFO - 2018-02-21 16:36:24 --> Helper loaded: file_helper
INFO - 2018-02-21 16:36:24 --> Helper loaded: email_helper
INFO - 2018-02-21 16:36:24 --> Helper loaded: common_helper
INFO - 2018-02-21 16:36:24 --> Database Driver Class Initialized
DEBUG - 2018-02-21 16:36:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-21 16:36:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-21 16:36:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-21 16:36:24 --> Pagination Class Initialized
INFO - 2018-02-21 16:36:24 --> Helper loaded: form_helper
INFO - 2018-02-21 16:36:24 --> Form Validation Class Initialized
INFO - 2018-02-21 16:36:24 --> Model Class Initialized
INFO - 2018-02-21 16:36:24 --> Controller Class Initialized
INFO - 2018-02-21 16:36:24 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-21 16:36:24 --> Model Class Initialized
INFO - 2018-02-21 16:36:24 --> Model Class Initialized
INFO - 2018-02-21 16:36:24 --> Model Class Initialized
INFO - 2018-02-21 16:36:24 --> Model Class Initialized
INFO - 2018-02-21 16:36:25 --> Config Class Initialized
INFO - 2018-02-21 16:36:25 --> Hooks Class Initialized
DEBUG - 2018-02-21 16:36:25 --> UTF-8 Support Enabled
INFO - 2018-02-21 16:36:25 --> Utf8 Class Initialized
INFO - 2018-02-21 16:36:25 --> URI Class Initialized
INFO - 2018-02-21 16:36:25 --> Router Class Initialized
INFO - 2018-02-21 16:36:25 --> Output Class Initialized
INFO - 2018-02-21 16:36:25 --> Security Class Initialized
DEBUG - 2018-02-21 16:36:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-21 16:36:25 --> Input Class Initialized
INFO - 2018-02-21 16:36:25 --> Language Class Initialized
INFO - 2018-02-21 16:36:25 --> Loader Class Initialized
INFO - 2018-02-21 16:36:25 --> Helper loaded: url_helper
INFO - 2018-02-21 16:36:25 --> Helper loaded: file_helper
INFO - 2018-02-21 16:36:25 --> Helper loaded: email_helper
INFO - 2018-02-21 16:36:25 --> Helper loaded: common_helper
INFO - 2018-02-21 16:36:25 --> Database Driver Class Initialized
DEBUG - 2018-02-21 16:36:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-21 16:36:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-21 16:36:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-21 16:36:25 --> Pagination Class Initialized
INFO - 2018-02-21 16:36:25 --> Helper loaded: form_helper
INFO - 2018-02-21 16:36:25 --> Form Validation Class Initialized
INFO - 2018-02-21 16:36:25 --> Model Class Initialized
INFO - 2018-02-21 16:36:25 --> Controller Class Initialized
INFO - 2018-02-21 16:36:25 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-21 16:36:25 --> Model Class Initialized
INFO - 2018-02-21 16:36:25 --> Model Class Initialized
INFO - 2018-02-21 16:36:25 --> Model Class Initialized
INFO - 2018-02-21 16:36:25 --> Model Class Initialized
INFO - 2018-02-21 16:36:25 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-21 16:36:25 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-21 16:36:25 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-21 16:36:25 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-21 16:36:25 --> File loaded: /var/www/html/project/radio/application/views/tracks/add_edit.php
INFO - 2018-02-21 16:36:25 --> Final output sent to browser
DEBUG - 2018-02-21 16:36:25 --> Total execution time: 0.0113
INFO - 2018-02-21 16:36:27 --> Config Class Initialized
INFO - 2018-02-21 16:36:27 --> Hooks Class Initialized
DEBUG - 2018-02-21 16:36:27 --> UTF-8 Support Enabled
INFO - 2018-02-21 16:36:27 --> Utf8 Class Initialized
INFO - 2018-02-21 16:36:27 --> URI Class Initialized
INFO - 2018-02-21 16:36:27 --> Router Class Initialized
INFO - 2018-02-21 16:36:27 --> Output Class Initialized
INFO - 2018-02-21 16:36:27 --> Security Class Initialized
DEBUG - 2018-02-21 16:36:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-21 16:36:27 --> Input Class Initialized
INFO - 2018-02-21 16:36:27 --> Language Class Initialized
INFO - 2018-02-21 16:36:27 --> Loader Class Initialized
INFO - 2018-02-21 16:36:27 --> Helper loaded: url_helper
INFO - 2018-02-21 16:36:27 --> Helper loaded: file_helper
INFO - 2018-02-21 16:36:27 --> Helper loaded: email_helper
INFO - 2018-02-21 16:36:27 --> Helper loaded: common_helper
INFO - 2018-02-21 16:36:27 --> Database Driver Class Initialized
DEBUG - 2018-02-21 16:36:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-21 16:36:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-21 16:36:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-21 16:36:27 --> Pagination Class Initialized
INFO - 2018-02-21 16:36:27 --> Helper loaded: form_helper
INFO - 2018-02-21 16:36:27 --> Form Validation Class Initialized
INFO - 2018-02-21 16:36:27 --> Model Class Initialized
INFO - 2018-02-21 16:36:27 --> Controller Class Initialized
INFO - 2018-02-21 16:36:27 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-21 16:36:27 --> Model Class Initialized
INFO - 2018-02-21 16:36:27 --> Model Class Initialized
INFO - 2018-02-21 16:36:27 --> Model Class Initialized
INFO - 2018-02-21 16:36:27 --> Model Class Initialized
INFO - 2018-02-21 16:37:26 --> Config Class Initialized
INFO - 2018-02-21 16:37:26 --> Hooks Class Initialized
DEBUG - 2018-02-21 16:37:26 --> UTF-8 Support Enabled
INFO - 2018-02-21 16:37:26 --> Utf8 Class Initialized
INFO - 2018-02-21 16:37:26 --> URI Class Initialized
INFO - 2018-02-21 16:37:26 --> Router Class Initialized
INFO - 2018-02-21 16:37:26 --> Output Class Initialized
INFO - 2018-02-21 16:37:26 --> Security Class Initialized
DEBUG - 2018-02-21 16:37:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-21 16:37:26 --> Input Class Initialized
INFO - 2018-02-21 16:37:26 --> Language Class Initialized
INFO - 2018-02-21 16:37:26 --> Loader Class Initialized
INFO - 2018-02-21 16:37:26 --> Helper loaded: url_helper
INFO - 2018-02-21 16:37:26 --> Helper loaded: file_helper
INFO - 2018-02-21 16:37:26 --> Helper loaded: email_helper
INFO - 2018-02-21 16:37:26 --> Helper loaded: common_helper
INFO - 2018-02-21 16:37:26 --> Database Driver Class Initialized
DEBUG - 2018-02-21 16:37:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-21 16:37:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-21 16:37:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-21 16:37:26 --> Pagination Class Initialized
INFO - 2018-02-21 16:37:26 --> Helper loaded: form_helper
INFO - 2018-02-21 16:37:26 --> Form Validation Class Initialized
INFO - 2018-02-21 16:37:26 --> Model Class Initialized
INFO - 2018-02-21 16:37:26 --> Controller Class Initialized
INFO - 2018-02-21 16:37:26 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-21 16:37:26 --> Model Class Initialized
INFO - 2018-02-21 16:37:26 --> Model Class Initialized
INFO - 2018-02-21 16:37:26 --> Model Class Initialized
INFO - 2018-02-21 16:37:26 --> Model Class Initialized
DEBUG - 2018-02-21 16:37:26 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-21 16:37:26 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-02-21 16:37:26 --> Config Class Initialized
INFO - 2018-02-21 16:37:26 --> Hooks Class Initialized
DEBUG - 2018-02-21 16:37:26 --> UTF-8 Support Enabled
INFO - 2018-02-21 16:37:26 --> Utf8 Class Initialized
INFO - 2018-02-21 16:37:26 --> URI Class Initialized
INFO - 2018-02-21 16:37:26 --> Router Class Initialized
INFO - 2018-02-21 16:37:26 --> Output Class Initialized
INFO - 2018-02-21 16:37:26 --> Security Class Initialized
DEBUG - 2018-02-21 16:37:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-21 16:37:26 --> Input Class Initialized
INFO - 2018-02-21 16:37:26 --> Language Class Initialized
INFO - 2018-02-21 16:37:26 --> Loader Class Initialized
INFO - 2018-02-21 16:37:26 --> Helper loaded: url_helper
INFO - 2018-02-21 16:37:26 --> Helper loaded: file_helper
INFO - 2018-02-21 16:37:26 --> Helper loaded: email_helper
INFO - 2018-02-21 16:37:26 --> Helper loaded: common_helper
INFO - 2018-02-21 16:37:26 --> Database Driver Class Initialized
DEBUG - 2018-02-21 16:37:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-21 16:37:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-21 16:37:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-21 16:37:26 --> Pagination Class Initialized
INFO - 2018-02-21 16:37:26 --> Helper loaded: form_helper
INFO - 2018-02-21 16:37:26 --> Form Validation Class Initialized
INFO - 2018-02-21 16:37:26 --> Model Class Initialized
INFO - 2018-02-21 16:37:26 --> Controller Class Initialized
INFO - 2018-02-21 16:37:26 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-21 16:37:26 --> Model Class Initialized
INFO - 2018-02-21 16:37:26 --> Model Class Initialized
INFO - 2018-02-21 16:37:26 --> Model Class Initialized
INFO - 2018-02-21 16:37:26 --> Model Class Initialized
INFO - 2018-02-21 16:37:26 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-21 16:37:26 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-21 16:37:26 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-21 16:37:26 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-21 16:37:26 --> File loaded: /var/www/html/project/radio/application/views/tracks/index.php
INFO - 2018-02-21 16:37:26 --> Final output sent to browser
DEBUG - 2018-02-21 16:37:26 --> Total execution time: 0.0035
INFO - 2018-02-21 16:37:26 --> Config Class Initialized
INFO - 2018-02-21 16:37:26 --> Hooks Class Initialized
DEBUG - 2018-02-21 16:37:26 --> UTF-8 Support Enabled
INFO - 2018-02-21 16:37:26 --> Utf8 Class Initialized
INFO - 2018-02-21 16:37:26 --> URI Class Initialized
INFO - 2018-02-21 16:37:26 --> Router Class Initialized
INFO - 2018-02-21 16:37:26 --> Output Class Initialized
INFO - 2018-02-21 16:37:26 --> Security Class Initialized
DEBUG - 2018-02-21 16:37:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-21 16:37:26 --> Input Class Initialized
INFO - 2018-02-21 16:37:26 --> Language Class Initialized
INFO - 2018-02-21 16:37:26 --> Loader Class Initialized
INFO - 2018-02-21 16:37:26 --> Helper loaded: url_helper
INFO - 2018-02-21 16:37:26 --> Helper loaded: file_helper
INFO - 2018-02-21 16:37:26 --> Helper loaded: email_helper
INFO - 2018-02-21 16:37:26 --> Helper loaded: common_helper
INFO - 2018-02-21 16:37:26 --> Database Driver Class Initialized
DEBUG - 2018-02-21 16:37:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-21 16:37:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-21 16:37:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-21 16:37:26 --> Pagination Class Initialized
INFO - 2018-02-21 16:37:26 --> Helper loaded: form_helper
INFO - 2018-02-21 16:37:26 --> Form Validation Class Initialized
INFO - 2018-02-21 16:37:26 --> Model Class Initialized
INFO - 2018-02-21 16:37:26 --> Controller Class Initialized
INFO - 2018-02-21 16:37:26 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-21 16:37:26 --> Model Class Initialized
INFO - 2018-02-21 16:37:26 --> Model Class Initialized
INFO - 2018-02-21 16:37:26 --> Model Class Initialized
INFO - 2018-02-21 16:37:26 --> Model Class Initialized
INFO - 2018-02-21 16:37:28 --> Config Class Initialized
INFO - 2018-02-21 16:37:28 --> Hooks Class Initialized
DEBUG - 2018-02-21 16:37:28 --> UTF-8 Support Enabled
INFO - 2018-02-21 16:37:28 --> Utf8 Class Initialized
INFO - 2018-02-21 16:37:28 --> URI Class Initialized
INFO - 2018-02-21 16:37:28 --> Router Class Initialized
INFO - 2018-02-21 16:37:28 --> Output Class Initialized
INFO - 2018-02-21 16:37:28 --> Security Class Initialized
DEBUG - 2018-02-21 16:37:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-21 16:37:28 --> Input Class Initialized
INFO - 2018-02-21 16:37:28 --> Language Class Initialized
INFO - 2018-02-21 16:37:28 --> Loader Class Initialized
INFO - 2018-02-21 16:37:28 --> Helper loaded: url_helper
INFO - 2018-02-21 16:37:28 --> Helper loaded: file_helper
INFO - 2018-02-21 16:37:28 --> Helper loaded: email_helper
INFO - 2018-02-21 16:37:28 --> Helper loaded: common_helper
INFO - 2018-02-21 16:37:28 --> Database Driver Class Initialized
DEBUG - 2018-02-21 16:37:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-21 16:37:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-21 16:37:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-21 16:37:28 --> Pagination Class Initialized
INFO - 2018-02-21 16:37:28 --> Helper loaded: form_helper
INFO - 2018-02-21 16:37:28 --> Form Validation Class Initialized
INFO - 2018-02-21 16:37:28 --> Model Class Initialized
INFO - 2018-02-21 16:37:28 --> Controller Class Initialized
INFO - 2018-02-21 16:37:28 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-21 16:37:28 --> Model Class Initialized
INFO - 2018-02-21 16:37:28 --> Model Class Initialized
INFO - 2018-02-21 16:37:28 --> Model Class Initialized
INFO - 2018-02-21 16:37:28 --> Model Class Initialized
INFO - 2018-02-21 16:37:28 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-21 16:37:28 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-21 16:37:28 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-21 16:37:28 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-21 16:37:28 --> File loaded: /var/www/html/project/radio/application/views/tracks/add_edit.php
INFO - 2018-02-21 16:37:28 --> Final output sent to browser
DEBUG - 2018-02-21 16:37:28 --> Total execution time: 0.0108
INFO - 2018-02-21 16:37:30 --> Config Class Initialized
INFO - 2018-02-21 16:37:30 --> Hooks Class Initialized
DEBUG - 2018-02-21 16:37:30 --> UTF-8 Support Enabled
INFO - 2018-02-21 16:37:30 --> Utf8 Class Initialized
INFO - 2018-02-21 16:37:30 --> URI Class Initialized
INFO - 2018-02-21 16:37:30 --> Router Class Initialized
INFO - 2018-02-21 16:37:30 --> Output Class Initialized
INFO - 2018-02-21 16:37:30 --> Security Class Initialized
DEBUG - 2018-02-21 16:37:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-21 16:37:30 --> Input Class Initialized
INFO - 2018-02-21 16:37:30 --> Language Class Initialized
INFO - 2018-02-21 16:37:30 --> Loader Class Initialized
INFO - 2018-02-21 16:37:30 --> Helper loaded: url_helper
INFO - 2018-02-21 16:37:30 --> Helper loaded: file_helper
INFO - 2018-02-21 16:37:30 --> Helper loaded: email_helper
INFO - 2018-02-21 16:37:30 --> Helper loaded: common_helper
INFO - 2018-02-21 16:37:30 --> Database Driver Class Initialized
DEBUG - 2018-02-21 16:37:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-21 16:37:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-21 16:37:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-21 16:37:30 --> Pagination Class Initialized
INFO - 2018-02-21 16:37:30 --> Helper loaded: form_helper
INFO - 2018-02-21 16:37:30 --> Form Validation Class Initialized
INFO - 2018-02-21 16:37:30 --> Model Class Initialized
INFO - 2018-02-21 16:37:30 --> Controller Class Initialized
INFO - 2018-02-21 16:37:30 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-21 16:37:30 --> Model Class Initialized
INFO - 2018-02-21 16:37:30 --> Model Class Initialized
INFO - 2018-02-21 16:37:30 --> Model Class Initialized
INFO - 2018-02-21 16:37:30 --> Model Class Initialized
INFO - 2018-02-21 16:38:15 --> Config Class Initialized
INFO - 2018-02-21 16:38:15 --> Hooks Class Initialized
DEBUG - 2018-02-21 16:38:15 --> UTF-8 Support Enabled
INFO - 2018-02-21 16:38:15 --> Utf8 Class Initialized
INFO - 2018-02-21 16:38:15 --> URI Class Initialized
INFO - 2018-02-21 16:38:15 --> Router Class Initialized
INFO - 2018-02-21 16:38:15 --> Output Class Initialized
INFO - 2018-02-21 16:38:15 --> Security Class Initialized
DEBUG - 2018-02-21 16:38:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-21 16:38:15 --> Input Class Initialized
INFO - 2018-02-21 16:38:15 --> Language Class Initialized
INFO - 2018-02-21 16:38:15 --> Loader Class Initialized
INFO - 2018-02-21 16:38:15 --> Helper loaded: url_helper
INFO - 2018-02-21 16:38:15 --> Helper loaded: file_helper
INFO - 2018-02-21 16:38:15 --> Helper loaded: email_helper
INFO - 2018-02-21 16:38:15 --> Helper loaded: common_helper
INFO - 2018-02-21 16:38:15 --> Database Driver Class Initialized
DEBUG - 2018-02-21 16:38:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-21 16:38:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-21 16:38:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-21 16:38:15 --> Pagination Class Initialized
INFO - 2018-02-21 16:38:15 --> Helper loaded: form_helper
INFO - 2018-02-21 16:38:15 --> Form Validation Class Initialized
INFO - 2018-02-21 16:38:15 --> Model Class Initialized
INFO - 2018-02-21 16:38:15 --> Controller Class Initialized
INFO - 2018-02-21 16:38:15 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-21 16:38:15 --> Model Class Initialized
INFO - 2018-02-21 16:38:15 --> Model Class Initialized
INFO - 2018-02-21 16:38:15 --> Model Class Initialized
INFO - 2018-02-21 16:38:15 --> Model Class Initialized
DEBUG - 2018-02-21 16:38:15 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-21 16:38:15 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-02-21 16:38:15 --> Config Class Initialized
INFO - 2018-02-21 16:38:15 --> Hooks Class Initialized
DEBUG - 2018-02-21 16:38:15 --> UTF-8 Support Enabled
INFO - 2018-02-21 16:38:15 --> Utf8 Class Initialized
INFO - 2018-02-21 16:38:15 --> URI Class Initialized
INFO - 2018-02-21 16:38:15 --> Router Class Initialized
INFO - 2018-02-21 16:38:15 --> Output Class Initialized
INFO - 2018-02-21 16:38:15 --> Security Class Initialized
DEBUG - 2018-02-21 16:38:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-21 16:38:15 --> Input Class Initialized
INFO - 2018-02-21 16:38:15 --> Language Class Initialized
INFO - 2018-02-21 16:38:15 --> Loader Class Initialized
INFO - 2018-02-21 16:38:15 --> Helper loaded: url_helper
INFO - 2018-02-21 16:38:15 --> Helper loaded: file_helper
INFO - 2018-02-21 16:38:15 --> Helper loaded: email_helper
INFO - 2018-02-21 16:38:15 --> Helper loaded: common_helper
INFO - 2018-02-21 16:38:15 --> Database Driver Class Initialized
DEBUG - 2018-02-21 16:38:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-21 16:38:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-21 16:38:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-21 16:38:15 --> Pagination Class Initialized
INFO - 2018-02-21 16:38:15 --> Helper loaded: form_helper
INFO - 2018-02-21 16:38:15 --> Form Validation Class Initialized
INFO - 2018-02-21 16:38:15 --> Model Class Initialized
INFO - 2018-02-21 16:38:15 --> Controller Class Initialized
INFO - 2018-02-21 16:38:15 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-21 16:38:15 --> Model Class Initialized
INFO - 2018-02-21 16:38:15 --> Model Class Initialized
INFO - 2018-02-21 16:38:15 --> Model Class Initialized
INFO - 2018-02-21 16:38:15 --> Model Class Initialized
INFO - 2018-02-21 16:38:15 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-21 16:38:15 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-21 16:38:15 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-21 16:38:15 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-21 16:38:15 --> File loaded: /var/www/html/project/radio/application/views/tracks/index.php
INFO - 2018-02-21 16:38:15 --> Final output sent to browser
DEBUG - 2018-02-21 16:38:15 --> Total execution time: 0.0039
INFO - 2018-02-21 16:38:16 --> Config Class Initialized
INFO - 2018-02-21 16:38:16 --> Hooks Class Initialized
DEBUG - 2018-02-21 16:38:16 --> UTF-8 Support Enabled
INFO - 2018-02-21 16:38:16 --> Utf8 Class Initialized
INFO - 2018-02-21 16:38:16 --> URI Class Initialized
INFO - 2018-02-21 16:38:16 --> Router Class Initialized
INFO - 2018-02-21 16:38:16 --> Output Class Initialized
INFO - 2018-02-21 16:38:16 --> Security Class Initialized
DEBUG - 2018-02-21 16:38:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-21 16:38:16 --> Input Class Initialized
INFO - 2018-02-21 16:38:16 --> Language Class Initialized
INFO - 2018-02-21 16:38:16 --> Loader Class Initialized
INFO - 2018-02-21 16:38:16 --> Helper loaded: url_helper
INFO - 2018-02-21 16:38:16 --> Helper loaded: file_helper
INFO - 2018-02-21 16:38:16 --> Helper loaded: email_helper
INFO - 2018-02-21 16:38:16 --> Helper loaded: common_helper
INFO - 2018-02-21 16:38:16 --> Database Driver Class Initialized
DEBUG - 2018-02-21 16:38:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-21 16:38:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-21 16:38:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-21 16:38:16 --> Pagination Class Initialized
INFO - 2018-02-21 16:38:16 --> Helper loaded: form_helper
INFO - 2018-02-21 16:38:16 --> Form Validation Class Initialized
INFO - 2018-02-21 16:38:16 --> Model Class Initialized
INFO - 2018-02-21 16:38:16 --> Controller Class Initialized
INFO - 2018-02-21 16:38:16 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-21 16:38:16 --> Model Class Initialized
INFO - 2018-02-21 16:38:16 --> Model Class Initialized
INFO - 2018-02-21 16:38:16 --> Model Class Initialized
INFO - 2018-02-21 16:38:16 --> Model Class Initialized
INFO - 2018-02-21 16:38:23 --> Config Class Initialized
INFO - 2018-02-21 16:38:23 --> Hooks Class Initialized
DEBUG - 2018-02-21 16:38:23 --> UTF-8 Support Enabled
INFO - 2018-02-21 16:38:23 --> Utf8 Class Initialized
INFO - 2018-02-21 16:38:23 --> URI Class Initialized
INFO - 2018-02-21 16:38:23 --> Router Class Initialized
INFO - 2018-02-21 16:38:23 --> Output Class Initialized
INFO - 2018-02-21 16:38:23 --> Security Class Initialized
DEBUG - 2018-02-21 16:38:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-21 16:38:23 --> Input Class Initialized
INFO - 2018-02-21 16:38:23 --> Language Class Initialized
INFO - 2018-02-21 16:38:23 --> Loader Class Initialized
INFO - 2018-02-21 16:38:23 --> Helper loaded: url_helper
INFO - 2018-02-21 16:38:23 --> Helper loaded: file_helper
INFO - 2018-02-21 16:38:23 --> Helper loaded: email_helper
INFO - 2018-02-21 16:38:23 --> Helper loaded: common_helper
INFO - 2018-02-21 16:38:23 --> Database Driver Class Initialized
DEBUG - 2018-02-21 16:38:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-21 16:38:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-21 16:38:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-21 16:38:23 --> Pagination Class Initialized
INFO - 2018-02-21 16:38:23 --> Helper loaded: form_helper
INFO - 2018-02-21 16:38:23 --> Form Validation Class Initialized
INFO - 2018-02-21 16:38:23 --> Model Class Initialized
INFO - 2018-02-21 16:38:23 --> Controller Class Initialized
INFO - 2018-02-21 16:38:23 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-21 16:38:23 --> Model Class Initialized
INFO - 2018-02-21 16:38:23 --> Model Class Initialized
INFO - 2018-02-21 16:38:23 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-21 16:38:23 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-21 16:38:23 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-21 16:38:23 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-21 16:38:23 --> File loaded: /var/www/html/project/radio/application/views/subcategory/index.php
INFO - 2018-02-21 16:38:23 --> Final output sent to browser
DEBUG - 2018-02-21 16:38:23 --> Total execution time: 0.0290
INFO - 2018-02-21 16:38:41 --> Config Class Initialized
INFO - 2018-02-21 16:38:41 --> Hooks Class Initialized
DEBUG - 2018-02-21 16:38:41 --> UTF-8 Support Enabled
INFO - 2018-02-21 16:38:41 --> Utf8 Class Initialized
INFO - 2018-02-21 16:38:41 --> URI Class Initialized
INFO - 2018-02-21 16:38:41 --> Router Class Initialized
INFO - 2018-02-21 16:38:41 --> Output Class Initialized
INFO - 2018-02-21 16:38:41 --> Security Class Initialized
DEBUG - 2018-02-21 16:38:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-21 16:38:41 --> Input Class Initialized
INFO - 2018-02-21 16:38:41 --> Language Class Initialized
INFO - 2018-02-21 16:38:41 --> Loader Class Initialized
INFO - 2018-02-21 16:38:41 --> Helper loaded: url_helper
INFO - 2018-02-21 16:38:41 --> Helper loaded: file_helper
INFO - 2018-02-21 16:38:41 --> Helper loaded: email_helper
INFO - 2018-02-21 16:38:41 --> Helper loaded: common_helper
INFO - 2018-02-21 16:38:41 --> Database Driver Class Initialized
DEBUG - 2018-02-21 16:38:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-21 16:38:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-21 16:38:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-21 16:38:41 --> Pagination Class Initialized
INFO - 2018-02-21 16:38:41 --> Helper loaded: form_helper
INFO - 2018-02-21 16:38:41 --> Form Validation Class Initialized
INFO - 2018-02-21 16:38:41 --> Model Class Initialized
INFO - 2018-02-21 16:38:41 --> Controller Class Initialized
DEBUG - 2018-02-21 16:38:41 --> Config file loaded: /var/www/html/project/radio/application/config/rest.php
INFO - 2018-02-21 16:38:41 --> Helper loaded: inflector_helper
INFO - 2018-02-21 16:38:41 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-21 16:38:41 --> Model Class Initialized
INFO - 2018-02-21 16:38:41 --> Model Class Initialized
INFO - 2018-02-21 16:38:41 --> Model Class Initialized
INFO - 2018-02-21 16:38:41 --> Model Class Initialized
INFO - 2018-02-21 16:38:41 --> Model Class Initialized
INFO - 2018-02-21 16:38:41 --> Final output sent to browser
DEBUG - 2018-02-21 16:38:41 --> Total execution time: 0.0064
INFO - 2018-02-21 16:39:03 --> Config Class Initialized
INFO - 2018-02-21 16:39:03 --> Hooks Class Initialized
DEBUG - 2018-02-21 16:39:03 --> UTF-8 Support Enabled
INFO - 2018-02-21 16:39:03 --> Utf8 Class Initialized
INFO - 2018-02-21 16:39:03 --> URI Class Initialized
INFO - 2018-02-21 16:39:03 --> Router Class Initialized
INFO - 2018-02-21 16:39:03 --> Output Class Initialized
INFO - 2018-02-21 16:39:03 --> Security Class Initialized
DEBUG - 2018-02-21 16:39:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-21 16:39:03 --> Input Class Initialized
INFO - 2018-02-21 16:39:03 --> Language Class Initialized
INFO - 2018-02-21 16:39:03 --> Loader Class Initialized
INFO - 2018-02-21 16:39:03 --> Helper loaded: url_helper
INFO - 2018-02-21 16:39:03 --> Helper loaded: file_helper
INFO - 2018-02-21 16:39:03 --> Helper loaded: email_helper
INFO - 2018-02-21 16:39:03 --> Helper loaded: common_helper
INFO - 2018-02-21 16:39:03 --> Database Driver Class Initialized
DEBUG - 2018-02-21 16:39:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-21 16:39:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-21 16:39:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-21 16:39:03 --> Pagination Class Initialized
INFO - 2018-02-21 16:39:03 --> Helper loaded: form_helper
INFO - 2018-02-21 16:39:03 --> Form Validation Class Initialized
INFO - 2018-02-21 16:39:03 --> Model Class Initialized
INFO - 2018-02-21 16:39:03 --> Controller Class Initialized
DEBUG - 2018-02-21 16:39:03 --> Config file loaded: /var/www/html/project/radio/application/config/rest.php
INFO - 2018-02-21 16:39:03 --> Helper loaded: inflector_helper
INFO - 2018-02-21 16:39:03 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-21 16:39:03 --> Model Class Initialized
INFO - 2018-02-21 16:39:03 --> Model Class Initialized
INFO - 2018-02-21 16:39:03 --> Model Class Initialized
INFO - 2018-02-21 16:39:03 --> Model Class Initialized
INFO - 2018-02-21 16:39:03 --> Model Class Initialized
INFO - 2018-02-21 16:39:03 --> Final output sent to browser
DEBUG - 2018-02-21 16:39:03 --> Total execution time: 0.0054
INFO - 2018-02-21 16:41:37 --> Config Class Initialized
INFO - 2018-02-21 16:41:37 --> Hooks Class Initialized
DEBUG - 2018-02-21 16:41:37 --> UTF-8 Support Enabled
INFO - 2018-02-21 16:41:37 --> Utf8 Class Initialized
INFO - 2018-02-21 16:41:37 --> URI Class Initialized
INFO - 2018-02-21 16:41:37 --> Router Class Initialized
INFO - 2018-02-21 16:41:37 --> Output Class Initialized
INFO - 2018-02-21 16:41:37 --> Security Class Initialized
DEBUG - 2018-02-21 16:41:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-21 16:41:37 --> Input Class Initialized
INFO - 2018-02-21 16:41:37 --> Language Class Initialized
INFO - 2018-02-21 16:41:37 --> Loader Class Initialized
INFO - 2018-02-21 16:41:37 --> Helper loaded: url_helper
INFO - 2018-02-21 16:41:37 --> Helper loaded: file_helper
INFO - 2018-02-21 16:41:37 --> Helper loaded: email_helper
INFO - 2018-02-21 16:41:37 --> Helper loaded: common_helper
INFO - 2018-02-21 16:41:37 --> Database Driver Class Initialized
DEBUG - 2018-02-21 16:41:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-21 16:41:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-21 16:41:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-21 16:41:37 --> Pagination Class Initialized
INFO - 2018-02-21 16:41:37 --> Helper loaded: form_helper
INFO - 2018-02-21 16:41:37 --> Form Validation Class Initialized
INFO - 2018-02-21 16:41:37 --> Model Class Initialized
INFO - 2018-02-21 16:41:37 --> Controller Class Initialized
INFO - 2018-02-21 16:41:37 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-21 16:41:37 --> Model Class Initialized
INFO - 2018-02-21 16:41:37 --> Model Class Initialized
INFO - 2018-02-21 16:41:37 --> Model Class Initialized
INFO - 2018-02-21 16:41:37 --> Model Class Initialized
INFO - 2018-02-21 16:41:37 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-21 16:41:37 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-21 16:41:37 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-21 16:41:37 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-21 16:41:37 --> File loaded: /var/www/html/project/radio/application/views/tracks/index.php
INFO - 2018-02-21 16:41:37 --> Final output sent to browser
DEBUG - 2018-02-21 16:41:37 --> Total execution time: 0.0050
INFO - 2018-02-21 16:41:37 --> Config Class Initialized
INFO - 2018-02-21 16:41:37 --> Hooks Class Initialized
DEBUG - 2018-02-21 16:41:37 --> UTF-8 Support Enabled
INFO - 2018-02-21 16:41:37 --> Utf8 Class Initialized
INFO - 2018-02-21 16:41:37 --> URI Class Initialized
INFO - 2018-02-21 16:41:37 --> Router Class Initialized
INFO - 2018-02-21 16:41:37 --> Output Class Initialized
INFO - 2018-02-21 16:41:37 --> Security Class Initialized
DEBUG - 2018-02-21 16:41:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-21 16:41:37 --> Input Class Initialized
INFO - 2018-02-21 16:41:37 --> Language Class Initialized
INFO - 2018-02-21 16:41:37 --> Loader Class Initialized
INFO - 2018-02-21 16:41:37 --> Helper loaded: url_helper
INFO - 2018-02-21 16:41:37 --> Helper loaded: file_helper
INFO - 2018-02-21 16:41:37 --> Helper loaded: email_helper
INFO - 2018-02-21 16:41:37 --> Helper loaded: common_helper
INFO - 2018-02-21 16:41:37 --> Database Driver Class Initialized
DEBUG - 2018-02-21 16:41:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-21 16:41:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-21 16:41:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-21 16:41:37 --> Pagination Class Initialized
INFO - 2018-02-21 16:41:37 --> Helper loaded: form_helper
INFO - 2018-02-21 16:41:37 --> Form Validation Class Initialized
INFO - 2018-02-21 16:41:37 --> Model Class Initialized
INFO - 2018-02-21 16:41:37 --> Controller Class Initialized
INFO - 2018-02-21 16:41:37 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-21 16:41:37 --> Model Class Initialized
INFO - 2018-02-21 16:41:37 --> Model Class Initialized
INFO - 2018-02-21 16:41:37 --> Model Class Initialized
INFO - 2018-02-21 16:41:37 --> Model Class Initialized
INFO - 2018-02-21 17:20:35 --> Config Class Initialized
INFO - 2018-02-21 17:20:35 --> Hooks Class Initialized
DEBUG - 2018-02-21 17:20:35 --> UTF-8 Support Enabled
INFO - 2018-02-21 17:20:35 --> Utf8 Class Initialized
INFO - 2018-02-21 17:20:35 --> URI Class Initialized
INFO - 2018-02-21 17:20:35 --> Router Class Initialized
INFO - 2018-02-21 17:20:35 --> Output Class Initialized
INFO - 2018-02-21 17:20:35 --> Security Class Initialized
DEBUG - 2018-02-21 17:20:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-21 17:20:35 --> Input Class Initialized
INFO - 2018-02-21 17:20:35 --> Language Class Initialized
INFO - 2018-02-21 17:20:35 --> Loader Class Initialized
INFO - 2018-02-21 17:20:35 --> Helper loaded: url_helper
INFO - 2018-02-21 17:20:35 --> Helper loaded: file_helper
INFO - 2018-02-21 17:20:35 --> Helper loaded: email_helper
INFO - 2018-02-21 17:20:35 --> Helper loaded: common_helper
INFO - 2018-02-21 17:20:35 --> Database Driver Class Initialized
DEBUG - 2018-02-21 17:20:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-21 17:20:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-21 17:20:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-21 17:20:35 --> Pagination Class Initialized
INFO - 2018-02-21 17:20:35 --> Helper loaded: form_helper
INFO - 2018-02-21 17:20:35 --> Form Validation Class Initialized
INFO - 2018-02-21 17:20:35 --> Model Class Initialized
INFO - 2018-02-21 17:20:35 --> Controller Class Initialized
DEBUG - 2018-02-21 17:20:35 --> Config file loaded: /var/www/html/project/radio/application/config/rest.php
INFO - 2018-02-21 17:20:35 --> Helper loaded: inflector_helper
INFO - 2018-02-21 17:20:35 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-21 17:20:35 --> Model Class Initialized
INFO - 2018-02-21 17:20:35 --> Model Class Initialized
INFO - 2018-02-21 17:20:35 --> Model Class Initialized
INFO - 2018-02-21 17:20:35 --> Model Class Initialized
INFO - 2018-02-21 17:20:35 --> Model Class Initialized
INFO - 2018-02-21 17:20:35 --> Final output sent to browser
DEBUG - 2018-02-21 17:20:35 --> Total execution time: 0.0069
INFO - 2018-02-21 17:20:48 --> Config Class Initialized
INFO - 2018-02-21 17:20:48 --> Hooks Class Initialized
DEBUG - 2018-02-21 17:20:48 --> UTF-8 Support Enabled
INFO - 2018-02-21 17:20:48 --> Utf8 Class Initialized
INFO - 2018-02-21 17:20:48 --> URI Class Initialized
INFO - 2018-02-21 17:20:48 --> Router Class Initialized
INFO - 2018-02-21 17:20:48 --> Output Class Initialized
INFO - 2018-02-21 17:20:48 --> Security Class Initialized
DEBUG - 2018-02-21 17:20:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-21 17:20:48 --> Input Class Initialized
INFO - 2018-02-21 17:20:48 --> Language Class Initialized
INFO - 2018-02-21 17:20:48 --> Loader Class Initialized
INFO - 2018-02-21 17:20:48 --> Helper loaded: url_helper
INFO - 2018-02-21 17:20:48 --> Helper loaded: file_helper
INFO - 2018-02-21 17:20:48 --> Helper loaded: email_helper
INFO - 2018-02-21 17:20:48 --> Helper loaded: common_helper
INFO - 2018-02-21 17:20:48 --> Database Driver Class Initialized
DEBUG - 2018-02-21 17:20:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-21 17:20:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-21 17:20:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-21 17:20:48 --> Pagination Class Initialized
INFO - 2018-02-21 17:20:48 --> Helper loaded: form_helper
INFO - 2018-02-21 17:20:48 --> Form Validation Class Initialized
INFO - 2018-02-21 17:20:48 --> Model Class Initialized
INFO - 2018-02-21 17:20:48 --> Controller Class Initialized
DEBUG - 2018-02-21 17:20:48 --> Config file loaded: /var/www/html/project/radio/application/config/rest.php
INFO - 2018-02-21 17:20:48 --> Helper loaded: inflector_helper
INFO - 2018-02-21 17:20:48 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-21 17:20:48 --> Model Class Initialized
INFO - 2018-02-21 17:20:48 --> Model Class Initialized
INFO - 2018-02-21 17:20:48 --> Model Class Initialized
INFO - 2018-02-21 17:20:48 --> Model Class Initialized
INFO - 2018-02-21 17:20:48 --> Model Class Initialized
INFO - 2018-02-21 17:20:48 --> Final output sent to browser
DEBUG - 2018-02-21 17:20:48 --> Total execution time: 0.0062
INFO - 2018-02-21 17:20:58 --> Config Class Initialized
INFO - 2018-02-21 17:20:58 --> Hooks Class Initialized
DEBUG - 2018-02-21 17:20:58 --> UTF-8 Support Enabled
INFO - 2018-02-21 17:20:58 --> Utf8 Class Initialized
INFO - 2018-02-21 17:20:58 --> URI Class Initialized
INFO - 2018-02-21 17:20:58 --> Router Class Initialized
INFO - 2018-02-21 17:20:58 --> Output Class Initialized
INFO - 2018-02-21 17:20:58 --> Security Class Initialized
DEBUG - 2018-02-21 17:20:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-21 17:20:58 --> Input Class Initialized
INFO - 2018-02-21 17:20:58 --> Language Class Initialized
INFO - 2018-02-21 17:20:58 --> Loader Class Initialized
INFO - 2018-02-21 17:20:58 --> Helper loaded: url_helper
INFO - 2018-02-21 17:20:58 --> Helper loaded: file_helper
INFO - 2018-02-21 17:20:58 --> Helper loaded: email_helper
INFO - 2018-02-21 17:20:58 --> Helper loaded: common_helper
INFO - 2018-02-21 17:20:58 --> Database Driver Class Initialized
DEBUG - 2018-02-21 17:20:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-21 17:20:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-21 17:20:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-21 17:20:58 --> Pagination Class Initialized
INFO - 2018-02-21 17:20:58 --> Helper loaded: form_helper
INFO - 2018-02-21 17:20:58 --> Form Validation Class Initialized
INFO - 2018-02-21 17:20:58 --> Model Class Initialized
INFO - 2018-02-21 17:20:58 --> Controller Class Initialized
DEBUG - 2018-02-21 17:20:58 --> Config file loaded: /var/www/html/project/radio/application/config/rest.php
INFO - 2018-02-21 17:20:58 --> Helper loaded: inflector_helper
INFO - 2018-02-21 17:20:58 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-21 17:20:58 --> Model Class Initialized
INFO - 2018-02-21 17:20:58 --> Model Class Initialized
INFO - 2018-02-21 17:20:58 --> Model Class Initialized
INFO - 2018-02-21 17:20:58 --> Model Class Initialized
INFO - 2018-02-21 17:20:58 --> Model Class Initialized
INFO - 2018-02-21 17:20:58 --> Final output sent to browser
DEBUG - 2018-02-21 17:20:58 --> Total execution time: 0.0065
INFO - 2018-02-21 17:32:08 --> Config Class Initialized
INFO - 2018-02-21 17:32:08 --> Hooks Class Initialized
DEBUG - 2018-02-21 17:32:08 --> UTF-8 Support Enabled
INFO - 2018-02-21 17:32:08 --> Utf8 Class Initialized
INFO - 2018-02-21 17:32:08 --> URI Class Initialized
INFO - 2018-02-21 17:32:08 --> Router Class Initialized
INFO - 2018-02-21 17:32:08 --> Output Class Initialized
INFO - 2018-02-21 17:32:08 --> Security Class Initialized
DEBUG - 2018-02-21 17:32:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-21 17:32:08 --> Input Class Initialized
INFO - 2018-02-21 17:32:08 --> Language Class Initialized
INFO - 2018-02-21 17:32:08 --> Loader Class Initialized
INFO - 2018-02-21 17:32:08 --> Helper loaded: url_helper
INFO - 2018-02-21 17:32:08 --> Helper loaded: file_helper
INFO - 2018-02-21 17:32:08 --> Helper loaded: email_helper
INFO - 2018-02-21 17:32:08 --> Helper loaded: common_helper
INFO - 2018-02-21 17:32:08 --> Database Driver Class Initialized
DEBUG - 2018-02-21 17:32:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-21 17:32:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-21 17:32:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-21 17:32:08 --> Pagination Class Initialized
INFO - 2018-02-21 17:32:08 --> Helper loaded: form_helper
INFO - 2018-02-21 17:32:08 --> Form Validation Class Initialized
INFO - 2018-02-21 17:32:08 --> Model Class Initialized
INFO - 2018-02-21 17:32:08 --> Controller Class Initialized
DEBUG - 2018-02-21 17:32:08 --> Config file loaded: /var/www/html/project/radio/application/config/rest.php
INFO - 2018-02-21 17:32:08 --> Helper loaded: inflector_helper
INFO - 2018-02-21 17:32:08 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-21 17:32:08 --> Model Class Initialized
INFO - 2018-02-21 17:32:08 --> Model Class Initialized
INFO - 2018-02-21 17:32:08 --> Model Class Initialized
INFO - 2018-02-21 17:32:08 --> Model Class Initialized
INFO - 2018-02-21 17:32:08 --> Model Class Initialized
INFO - 2018-02-21 17:32:08 --> Final output sent to browser
DEBUG - 2018-02-21 17:32:08 --> Total execution time: 0.0082
INFO - 2018-02-21 17:32:30 --> Config Class Initialized
INFO - 2018-02-21 17:32:30 --> Hooks Class Initialized
DEBUG - 2018-02-21 17:32:30 --> UTF-8 Support Enabled
INFO - 2018-02-21 17:32:30 --> Utf8 Class Initialized
INFO - 2018-02-21 17:32:30 --> URI Class Initialized
INFO - 2018-02-21 17:32:30 --> Router Class Initialized
INFO - 2018-02-21 17:32:30 --> Output Class Initialized
INFO - 2018-02-21 17:32:30 --> Security Class Initialized
DEBUG - 2018-02-21 17:32:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-21 17:32:30 --> Input Class Initialized
INFO - 2018-02-21 17:32:30 --> Language Class Initialized
INFO - 2018-02-21 17:32:30 --> Loader Class Initialized
INFO - 2018-02-21 17:32:30 --> Helper loaded: url_helper
INFO - 2018-02-21 17:32:30 --> Helper loaded: file_helper
INFO - 2018-02-21 17:32:30 --> Helper loaded: email_helper
INFO - 2018-02-21 17:32:30 --> Helper loaded: common_helper
INFO - 2018-02-21 17:32:30 --> Database Driver Class Initialized
DEBUG - 2018-02-21 17:32:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-21 17:32:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-21 17:32:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-21 17:32:30 --> Pagination Class Initialized
INFO - 2018-02-21 17:32:30 --> Helper loaded: form_helper
INFO - 2018-02-21 17:32:30 --> Form Validation Class Initialized
INFO - 2018-02-21 17:32:30 --> Model Class Initialized
INFO - 2018-02-21 17:32:30 --> Controller Class Initialized
DEBUG - 2018-02-21 17:32:30 --> Config file loaded: /var/www/html/project/radio/application/config/rest.php
INFO - 2018-02-21 17:32:30 --> Helper loaded: inflector_helper
INFO - 2018-02-21 17:32:30 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-21 17:32:30 --> Model Class Initialized
INFO - 2018-02-21 17:32:30 --> Model Class Initialized
INFO - 2018-02-21 17:32:30 --> Model Class Initialized
INFO - 2018-02-21 17:32:30 --> Model Class Initialized
INFO - 2018-02-21 17:32:30 --> Model Class Initialized
INFO - 2018-02-21 17:32:30 --> Final output sent to browser
DEBUG - 2018-02-21 17:32:30 --> Total execution time: 0.0069
INFO - 2018-02-21 17:32:36 --> Config Class Initialized
INFO - 2018-02-21 17:32:36 --> Hooks Class Initialized
DEBUG - 2018-02-21 17:32:36 --> UTF-8 Support Enabled
INFO - 2018-02-21 17:32:36 --> Utf8 Class Initialized
INFO - 2018-02-21 17:32:36 --> URI Class Initialized
INFO - 2018-02-21 17:32:36 --> Router Class Initialized
INFO - 2018-02-21 17:32:36 --> Output Class Initialized
INFO - 2018-02-21 17:32:36 --> Security Class Initialized
DEBUG - 2018-02-21 17:32:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-21 17:32:36 --> Input Class Initialized
INFO - 2018-02-21 17:32:36 --> Language Class Initialized
INFO - 2018-02-21 17:32:36 --> Loader Class Initialized
INFO - 2018-02-21 17:32:36 --> Helper loaded: url_helper
INFO - 2018-02-21 17:32:36 --> Helper loaded: file_helper
INFO - 2018-02-21 17:32:36 --> Helper loaded: email_helper
INFO - 2018-02-21 17:32:36 --> Helper loaded: common_helper
INFO - 2018-02-21 17:32:36 --> Database Driver Class Initialized
DEBUG - 2018-02-21 17:32:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-21 17:32:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-21 17:32:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-21 17:32:36 --> Pagination Class Initialized
INFO - 2018-02-21 17:32:36 --> Helper loaded: form_helper
INFO - 2018-02-21 17:32:36 --> Form Validation Class Initialized
INFO - 2018-02-21 17:32:36 --> Model Class Initialized
INFO - 2018-02-21 17:32:36 --> Controller Class Initialized
DEBUG - 2018-02-21 17:32:36 --> Config file loaded: /var/www/html/project/radio/application/config/rest.php
INFO - 2018-02-21 17:32:36 --> Helper loaded: inflector_helper
INFO - 2018-02-21 17:32:36 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-21 17:32:36 --> Model Class Initialized
INFO - 2018-02-21 17:32:36 --> Model Class Initialized
INFO - 2018-02-21 17:32:36 --> Model Class Initialized
INFO - 2018-02-21 17:32:36 --> Model Class Initialized
INFO - 2018-02-21 17:32:36 --> Model Class Initialized
INFO - 2018-02-21 17:32:36 --> Final output sent to browser
DEBUG - 2018-02-21 17:32:36 --> Total execution time: 0.0054
INFO - 2018-02-21 17:32:44 --> Config Class Initialized
INFO - 2018-02-21 17:32:44 --> Hooks Class Initialized
DEBUG - 2018-02-21 17:32:44 --> UTF-8 Support Enabled
INFO - 2018-02-21 17:32:44 --> Utf8 Class Initialized
INFO - 2018-02-21 17:32:44 --> URI Class Initialized
INFO - 2018-02-21 17:32:44 --> Router Class Initialized
INFO - 2018-02-21 17:32:44 --> Output Class Initialized
INFO - 2018-02-21 17:32:44 --> Security Class Initialized
DEBUG - 2018-02-21 17:32:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-21 17:32:44 --> Input Class Initialized
INFO - 2018-02-21 17:32:44 --> Language Class Initialized
INFO - 2018-02-21 17:32:44 --> Loader Class Initialized
INFO - 2018-02-21 17:32:44 --> Helper loaded: url_helper
INFO - 2018-02-21 17:32:44 --> Helper loaded: file_helper
INFO - 2018-02-21 17:32:44 --> Helper loaded: email_helper
INFO - 2018-02-21 17:32:44 --> Helper loaded: common_helper
INFO - 2018-02-21 17:32:44 --> Database Driver Class Initialized
DEBUG - 2018-02-21 17:32:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-21 17:32:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-21 17:32:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-21 17:32:44 --> Pagination Class Initialized
INFO - 2018-02-21 17:32:44 --> Helper loaded: form_helper
INFO - 2018-02-21 17:32:44 --> Form Validation Class Initialized
INFO - 2018-02-21 17:32:44 --> Model Class Initialized
INFO - 2018-02-21 17:32:44 --> Controller Class Initialized
DEBUG - 2018-02-21 17:32:44 --> Config file loaded: /var/www/html/project/radio/application/config/rest.php
INFO - 2018-02-21 17:32:44 --> Helper loaded: inflector_helper
INFO - 2018-02-21 17:32:44 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-21 17:32:44 --> Model Class Initialized
INFO - 2018-02-21 17:32:44 --> Model Class Initialized
INFO - 2018-02-21 17:32:44 --> Model Class Initialized
INFO - 2018-02-21 17:32:44 --> Model Class Initialized
INFO - 2018-02-21 17:32:44 --> Model Class Initialized
INFO - 2018-02-21 17:32:44 --> Final output sent to browser
DEBUG - 2018-02-21 17:32:44 --> Total execution time: 0.0075
INFO - 2018-02-21 17:33:00 --> Config Class Initialized
INFO - 2018-02-21 17:33:00 --> Hooks Class Initialized
DEBUG - 2018-02-21 17:33:00 --> UTF-8 Support Enabled
INFO - 2018-02-21 17:33:00 --> Utf8 Class Initialized
INFO - 2018-02-21 17:33:00 --> URI Class Initialized
INFO - 2018-02-21 17:33:00 --> Router Class Initialized
INFO - 2018-02-21 17:33:00 --> Output Class Initialized
INFO - 2018-02-21 17:33:00 --> Security Class Initialized
DEBUG - 2018-02-21 17:33:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-21 17:33:00 --> Input Class Initialized
INFO - 2018-02-21 17:33:00 --> Language Class Initialized
INFO - 2018-02-21 17:33:00 --> Loader Class Initialized
INFO - 2018-02-21 17:33:00 --> Helper loaded: url_helper
INFO - 2018-02-21 17:33:00 --> Helper loaded: file_helper
INFO - 2018-02-21 17:33:00 --> Helper loaded: email_helper
INFO - 2018-02-21 17:33:00 --> Helper loaded: common_helper
INFO - 2018-02-21 17:33:00 --> Database Driver Class Initialized
DEBUG - 2018-02-21 17:33:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-21 17:33:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-21 17:33:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-21 17:33:00 --> Pagination Class Initialized
INFO - 2018-02-21 17:33:00 --> Helper loaded: form_helper
INFO - 2018-02-21 17:33:00 --> Form Validation Class Initialized
INFO - 2018-02-21 17:33:00 --> Model Class Initialized
INFO - 2018-02-21 17:33:00 --> Controller Class Initialized
DEBUG - 2018-02-21 17:33:00 --> Config file loaded: /var/www/html/project/radio/application/config/rest.php
INFO - 2018-02-21 17:33:00 --> Helper loaded: inflector_helper
INFO - 2018-02-21 17:33:00 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-21 17:33:00 --> Model Class Initialized
INFO - 2018-02-21 17:33:00 --> Model Class Initialized
INFO - 2018-02-21 17:33:00 --> Model Class Initialized
INFO - 2018-02-21 17:33:00 --> Model Class Initialized
INFO - 2018-02-21 17:33:00 --> Model Class Initialized
INFO - 2018-02-21 17:33:00 --> Final output sent to browser
DEBUG - 2018-02-21 17:33:00 --> Total execution time: 0.0076
INFO - 2018-02-21 17:33:06 --> Config Class Initialized
INFO - 2018-02-21 17:33:06 --> Hooks Class Initialized
DEBUG - 2018-02-21 17:33:06 --> UTF-8 Support Enabled
INFO - 2018-02-21 17:33:06 --> Utf8 Class Initialized
INFO - 2018-02-21 17:33:06 --> URI Class Initialized
INFO - 2018-02-21 17:33:06 --> Router Class Initialized
INFO - 2018-02-21 17:33:06 --> Output Class Initialized
INFO - 2018-02-21 17:33:06 --> Security Class Initialized
DEBUG - 2018-02-21 17:33:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-21 17:33:06 --> Input Class Initialized
INFO - 2018-02-21 17:33:06 --> Language Class Initialized
INFO - 2018-02-21 17:33:06 --> Loader Class Initialized
INFO - 2018-02-21 17:33:06 --> Helper loaded: url_helper
INFO - 2018-02-21 17:33:06 --> Helper loaded: file_helper
INFO - 2018-02-21 17:33:06 --> Helper loaded: email_helper
INFO - 2018-02-21 17:33:06 --> Helper loaded: common_helper
INFO - 2018-02-21 17:33:06 --> Database Driver Class Initialized
DEBUG - 2018-02-21 17:33:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-21 17:33:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-21 17:33:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-21 17:33:06 --> Pagination Class Initialized
INFO - 2018-02-21 17:33:06 --> Helper loaded: form_helper
INFO - 2018-02-21 17:33:06 --> Form Validation Class Initialized
INFO - 2018-02-21 17:33:06 --> Model Class Initialized
INFO - 2018-02-21 17:33:06 --> Controller Class Initialized
DEBUG - 2018-02-21 17:33:06 --> Config file loaded: /var/www/html/project/radio/application/config/rest.php
INFO - 2018-02-21 17:33:06 --> Helper loaded: inflector_helper
INFO - 2018-02-21 17:33:06 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-21 17:33:06 --> Model Class Initialized
INFO - 2018-02-21 17:33:06 --> Model Class Initialized
INFO - 2018-02-21 17:33:06 --> Model Class Initialized
INFO - 2018-02-21 17:33:06 --> Model Class Initialized
INFO - 2018-02-21 17:33:06 --> Model Class Initialized
INFO - 2018-02-21 17:33:06 --> Final output sent to browser
DEBUG - 2018-02-21 17:33:06 --> Total execution time: 0.0059
INFO - 2018-02-21 17:33:09 --> Config Class Initialized
INFO - 2018-02-21 17:33:09 --> Hooks Class Initialized
DEBUG - 2018-02-21 17:33:09 --> UTF-8 Support Enabled
INFO - 2018-02-21 17:33:09 --> Utf8 Class Initialized
INFO - 2018-02-21 17:33:09 --> URI Class Initialized
INFO - 2018-02-21 17:33:09 --> Router Class Initialized
INFO - 2018-02-21 17:33:09 --> Output Class Initialized
INFO - 2018-02-21 17:33:09 --> Security Class Initialized
DEBUG - 2018-02-21 17:33:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-21 17:33:09 --> Input Class Initialized
INFO - 2018-02-21 17:33:09 --> Language Class Initialized
INFO - 2018-02-21 17:33:09 --> Loader Class Initialized
INFO - 2018-02-21 17:33:09 --> Helper loaded: url_helper
INFO - 2018-02-21 17:33:09 --> Helper loaded: file_helper
INFO - 2018-02-21 17:33:09 --> Helper loaded: email_helper
INFO - 2018-02-21 17:33:09 --> Helper loaded: common_helper
INFO - 2018-02-21 17:33:09 --> Database Driver Class Initialized
DEBUG - 2018-02-21 17:33:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-21 17:33:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-21 17:33:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-21 17:33:09 --> Pagination Class Initialized
INFO - 2018-02-21 17:33:09 --> Helper loaded: form_helper
INFO - 2018-02-21 17:33:09 --> Form Validation Class Initialized
INFO - 2018-02-21 17:33:09 --> Model Class Initialized
INFO - 2018-02-21 17:33:09 --> Controller Class Initialized
DEBUG - 2018-02-21 17:33:09 --> Config file loaded: /var/www/html/project/radio/application/config/rest.php
INFO - 2018-02-21 17:33:09 --> Helper loaded: inflector_helper
INFO - 2018-02-21 17:33:09 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-21 17:33:09 --> Model Class Initialized
INFO - 2018-02-21 17:33:09 --> Model Class Initialized
INFO - 2018-02-21 17:33:09 --> Model Class Initialized
INFO - 2018-02-21 17:33:09 --> Model Class Initialized
INFO - 2018-02-21 17:33:09 --> Model Class Initialized
INFO - 2018-02-21 17:33:09 --> Final output sent to browser
DEBUG - 2018-02-21 17:33:09 --> Total execution time: 0.0063
INFO - 2018-02-21 17:33:11 --> Config Class Initialized
INFO - 2018-02-21 17:33:11 --> Hooks Class Initialized
DEBUG - 2018-02-21 17:33:11 --> UTF-8 Support Enabled
INFO - 2018-02-21 17:33:11 --> Utf8 Class Initialized
INFO - 2018-02-21 17:33:11 --> URI Class Initialized
INFO - 2018-02-21 17:33:11 --> Router Class Initialized
INFO - 2018-02-21 17:33:11 --> Output Class Initialized
INFO - 2018-02-21 17:33:11 --> Security Class Initialized
DEBUG - 2018-02-21 17:33:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-21 17:33:11 --> Input Class Initialized
INFO - 2018-02-21 17:33:11 --> Language Class Initialized
INFO - 2018-02-21 17:33:11 --> Loader Class Initialized
INFO - 2018-02-21 17:33:11 --> Helper loaded: url_helper
INFO - 2018-02-21 17:33:11 --> Helper loaded: file_helper
INFO - 2018-02-21 17:33:11 --> Helper loaded: email_helper
INFO - 2018-02-21 17:33:11 --> Helper loaded: common_helper
INFO - 2018-02-21 17:33:11 --> Database Driver Class Initialized
DEBUG - 2018-02-21 17:33:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-21 17:33:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-21 17:33:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-21 17:33:11 --> Pagination Class Initialized
INFO - 2018-02-21 17:33:11 --> Helper loaded: form_helper
INFO - 2018-02-21 17:33:11 --> Form Validation Class Initialized
INFO - 2018-02-21 17:33:11 --> Model Class Initialized
INFO - 2018-02-21 17:33:11 --> Controller Class Initialized
DEBUG - 2018-02-21 17:33:11 --> Config file loaded: /var/www/html/project/radio/application/config/rest.php
INFO - 2018-02-21 17:33:11 --> Helper loaded: inflector_helper
INFO - 2018-02-21 17:33:11 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-21 17:33:11 --> Model Class Initialized
INFO - 2018-02-21 17:33:11 --> Model Class Initialized
INFO - 2018-02-21 17:33:11 --> Model Class Initialized
INFO - 2018-02-21 17:33:11 --> Model Class Initialized
INFO - 2018-02-21 17:33:11 --> Model Class Initialized
INFO - 2018-02-21 17:33:11 --> Final output sent to browser
DEBUG - 2018-02-21 17:33:11 --> Total execution time: 0.0077
INFO - 2018-02-21 17:33:21 --> Config Class Initialized
INFO - 2018-02-21 17:33:21 --> Hooks Class Initialized
DEBUG - 2018-02-21 17:33:21 --> UTF-8 Support Enabled
INFO - 2018-02-21 17:33:21 --> Utf8 Class Initialized
INFO - 2018-02-21 17:33:21 --> URI Class Initialized
INFO - 2018-02-21 17:33:21 --> Router Class Initialized
INFO - 2018-02-21 17:33:21 --> Output Class Initialized
INFO - 2018-02-21 17:33:21 --> Security Class Initialized
DEBUG - 2018-02-21 17:33:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-21 17:33:21 --> Input Class Initialized
INFO - 2018-02-21 17:33:21 --> Language Class Initialized
INFO - 2018-02-21 17:33:21 --> Loader Class Initialized
INFO - 2018-02-21 17:33:21 --> Helper loaded: url_helper
INFO - 2018-02-21 17:33:21 --> Helper loaded: file_helper
INFO - 2018-02-21 17:33:21 --> Helper loaded: email_helper
INFO - 2018-02-21 17:33:21 --> Helper loaded: common_helper
INFO - 2018-02-21 17:33:21 --> Database Driver Class Initialized
DEBUG - 2018-02-21 17:33:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-21 17:33:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-21 17:33:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-21 17:33:21 --> Pagination Class Initialized
INFO - 2018-02-21 17:33:21 --> Helper loaded: form_helper
INFO - 2018-02-21 17:33:21 --> Form Validation Class Initialized
INFO - 2018-02-21 17:33:21 --> Model Class Initialized
INFO - 2018-02-21 17:33:21 --> Controller Class Initialized
DEBUG - 2018-02-21 17:33:21 --> Config file loaded: /var/www/html/project/radio/application/config/rest.php
INFO - 2018-02-21 17:33:21 --> Helper loaded: inflector_helper
INFO - 2018-02-21 17:33:21 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-21 17:33:21 --> Model Class Initialized
INFO - 2018-02-21 17:33:21 --> Model Class Initialized
INFO - 2018-02-21 17:33:21 --> Model Class Initialized
INFO - 2018-02-21 17:33:21 --> Model Class Initialized
INFO - 2018-02-21 17:33:21 --> Model Class Initialized
INFO - 2018-02-21 17:33:21 --> Final output sent to browser
DEBUG - 2018-02-21 17:33:21 --> Total execution time: 0.0071
INFO - 2018-02-21 17:49:19 --> Config Class Initialized
INFO - 2018-02-21 17:49:19 --> Hooks Class Initialized
DEBUG - 2018-02-21 17:49:19 --> UTF-8 Support Enabled
INFO - 2018-02-21 17:49:19 --> Utf8 Class Initialized
INFO - 2018-02-21 17:49:19 --> URI Class Initialized
INFO - 2018-02-21 17:49:19 --> Router Class Initialized
INFO - 2018-02-21 17:49:19 --> Output Class Initialized
INFO - 2018-02-21 17:49:19 --> Security Class Initialized
DEBUG - 2018-02-21 17:49:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-21 17:49:19 --> Input Class Initialized
INFO - 2018-02-21 17:49:19 --> Language Class Initialized
INFO - 2018-02-21 17:49:19 --> Loader Class Initialized
INFO - 2018-02-21 17:49:19 --> Helper loaded: url_helper
INFO - 2018-02-21 17:49:19 --> Helper loaded: file_helper
INFO - 2018-02-21 17:49:19 --> Helper loaded: email_helper
INFO - 2018-02-21 17:49:19 --> Helper loaded: common_helper
INFO - 2018-02-21 17:49:19 --> Database Driver Class Initialized
DEBUG - 2018-02-21 17:49:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-21 17:49:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-21 17:49:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-21 17:49:19 --> Pagination Class Initialized
INFO - 2018-02-21 17:49:19 --> Helper loaded: form_helper
INFO - 2018-02-21 17:49:19 --> Form Validation Class Initialized
INFO - 2018-02-21 17:49:19 --> Model Class Initialized
INFO - 2018-02-21 17:49:19 --> Controller Class Initialized
DEBUG - 2018-02-21 17:49:19 --> Config file loaded: /var/www/html/project/radio/application/config/rest.php
INFO - 2018-02-21 17:49:19 --> Helper loaded: inflector_helper
INFO - 2018-02-21 17:49:19 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-21 17:49:19 --> Model Class Initialized
INFO - 2018-02-21 17:49:19 --> Model Class Initialized
INFO - 2018-02-21 17:49:19 --> Model Class Initialized
INFO - 2018-02-21 17:49:19 --> Model Class Initialized
INFO - 2018-02-21 17:49:19 --> Model Class Initialized
INFO - 2018-02-21 17:49:19 --> Final output sent to browser
DEBUG - 2018-02-21 17:49:19 --> Total execution time: 0.0066
INFO - 2018-02-21 17:49:30 --> Config Class Initialized
INFO - 2018-02-21 17:49:30 --> Hooks Class Initialized
DEBUG - 2018-02-21 17:49:30 --> UTF-8 Support Enabled
INFO - 2018-02-21 17:49:30 --> Utf8 Class Initialized
INFO - 2018-02-21 17:49:30 --> URI Class Initialized
INFO - 2018-02-21 17:49:30 --> Router Class Initialized
INFO - 2018-02-21 17:49:30 --> Output Class Initialized
INFO - 2018-02-21 17:49:30 --> Security Class Initialized
DEBUG - 2018-02-21 17:49:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-21 17:49:30 --> Input Class Initialized
INFO - 2018-02-21 17:49:30 --> Language Class Initialized
INFO - 2018-02-21 17:49:30 --> Loader Class Initialized
INFO - 2018-02-21 17:49:30 --> Helper loaded: url_helper
INFO - 2018-02-21 17:49:30 --> Helper loaded: file_helper
INFO - 2018-02-21 17:49:30 --> Helper loaded: email_helper
INFO - 2018-02-21 17:49:30 --> Helper loaded: common_helper
INFO - 2018-02-21 17:49:30 --> Database Driver Class Initialized
DEBUG - 2018-02-21 17:49:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-21 17:49:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-21 17:49:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-21 17:49:30 --> Pagination Class Initialized
INFO - 2018-02-21 17:49:30 --> Helper loaded: form_helper
INFO - 2018-02-21 17:49:30 --> Form Validation Class Initialized
INFO - 2018-02-21 17:49:30 --> Model Class Initialized
INFO - 2018-02-21 17:49:30 --> Controller Class Initialized
DEBUG - 2018-02-21 17:49:30 --> Config file loaded: /var/www/html/project/radio/application/config/rest.php
INFO - 2018-02-21 17:49:30 --> Helper loaded: inflector_helper
INFO - 2018-02-21 17:49:30 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-21 17:49:30 --> Model Class Initialized
INFO - 2018-02-21 17:49:30 --> Model Class Initialized
INFO - 2018-02-21 17:49:30 --> Model Class Initialized
INFO - 2018-02-21 17:49:30 --> Model Class Initialized
INFO - 2018-02-21 17:49:30 --> Model Class Initialized
INFO - 2018-02-21 17:49:30 --> Final output sent to browser
DEBUG - 2018-02-21 17:49:30 --> Total execution time: 0.0065
INFO - 2018-02-21 17:49:48 --> Config Class Initialized
INFO - 2018-02-21 17:49:48 --> Hooks Class Initialized
DEBUG - 2018-02-21 17:49:48 --> UTF-8 Support Enabled
INFO - 2018-02-21 17:49:48 --> Utf8 Class Initialized
INFO - 2018-02-21 17:49:48 --> URI Class Initialized
INFO - 2018-02-21 17:49:48 --> Router Class Initialized
INFO - 2018-02-21 17:49:48 --> Output Class Initialized
INFO - 2018-02-21 17:49:48 --> Security Class Initialized
DEBUG - 2018-02-21 17:49:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-21 17:49:48 --> Input Class Initialized
INFO - 2018-02-21 17:49:48 --> Language Class Initialized
INFO - 2018-02-21 17:49:48 --> Loader Class Initialized
INFO - 2018-02-21 17:49:48 --> Helper loaded: url_helper
INFO - 2018-02-21 17:49:48 --> Helper loaded: file_helper
INFO - 2018-02-21 17:49:48 --> Helper loaded: email_helper
INFO - 2018-02-21 17:49:48 --> Helper loaded: common_helper
INFO - 2018-02-21 17:49:48 --> Database Driver Class Initialized
DEBUG - 2018-02-21 17:49:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-21 17:49:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-21 17:49:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-21 17:49:48 --> Pagination Class Initialized
INFO - 2018-02-21 17:49:48 --> Helper loaded: form_helper
INFO - 2018-02-21 17:49:48 --> Form Validation Class Initialized
INFO - 2018-02-21 17:49:48 --> Model Class Initialized
INFO - 2018-02-21 17:49:48 --> Controller Class Initialized
DEBUG - 2018-02-21 17:49:48 --> Config file loaded: /var/www/html/project/radio/application/config/rest.php
INFO - 2018-02-21 17:49:48 --> Helper loaded: inflector_helper
INFO - 2018-02-21 17:49:48 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-21 17:49:48 --> Model Class Initialized
INFO - 2018-02-21 17:49:48 --> Model Class Initialized
INFO - 2018-02-21 17:49:48 --> Model Class Initialized
INFO - 2018-02-21 17:49:48 --> Model Class Initialized
INFO - 2018-02-21 17:49:48 --> Model Class Initialized
INFO - 2018-02-21 17:50:30 --> Config Class Initialized
INFO - 2018-02-21 17:50:30 --> Hooks Class Initialized
DEBUG - 2018-02-21 17:50:30 --> UTF-8 Support Enabled
INFO - 2018-02-21 17:50:30 --> Utf8 Class Initialized
INFO - 2018-02-21 17:50:30 --> URI Class Initialized
INFO - 2018-02-21 17:50:30 --> Router Class Initialized
INFO - 2018-02-21 17:50:30 --> Output Class Initialized
INFO - 2018-02-21 17:50:30 --> Security Class Initialized
DEBUG - 2018-02-21 17:50:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-21 17:50:30 --> Input Class Initialized
INFO - 2018-02-21 17:50:30 --> Language Class Initialized
INFO - 2018-02-21 17:50:30 --> Loader Class Initialized
INFO - 2018-02-21 17:50:30 --> Helper loaded: url_helper
INFO - 2018-02-21 17:50:30 --> Helper loaded: file_helper
INFO - 2018-02-21 17:50:30 --> Helper loaded: email_helper
INFO - 2018-02-21 17:50:30 --> Helper loaded: common_helper
INFO - 2018-02-21 17:50:30 --> Database Driver Class Initialized
DEBUG - 2018-02-21 17:50:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-21 17:50:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-21 17:50:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-21 17:50:30 --> Pagination Class Initialized
INFO - 2018-02-21 17:50:30 --> Helper loaded: form_helper
INFO - 2018-02-21 17:50:30 --> Form Validation Class Initialized
INFO - 2018-02-21 17:50:30 --> Model Class Initialized
INFO - 2018-02-21 17:50:30 --> Controller Class Initialized
DEBUG - 2018-02-21 17:50:30 --> Config file loaded: /var/www/html/project/radio/application/config/rest.php
INFO - 2018-02-21 17:50:30 --> Helper loaded: inflector_helper
INFO - 2018-02-21 17:50:30 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-21 17:50:30 --> Model Class Initialized
INFO - 2018-02-21 17:50:30 --> Model Class Initialized
INFO - 2018-02-21 17:50:30 --> Model Class Initialized
INFO - 2018-02-21 17:50:30 --> Model Class Initialized
INFO - 2018-02-21 17:50:30 --> Model Class Initialized
INFO - 2018-02-21 17:50:30 --> Final output sent to browser
DEBUG - 2018-02-21 17:50:30 --> Total execution time: 0.0070
INFO - 2018-02-21 17:51:17 --> Config Class Initialized
INFO - 2018-02-21 17:51:17 --> Hooks Class Initialized
DEBUG - 2018-02-21 17:51:17 --> UTF-8 Support Enabled
INFO - 2018-02-21 17:51:17 --> Utf8 Class Initialized
INFO - 2018-02-21 17:51:17 --> URI Class Initialized
INFO - 2018-02-21 17:51:17 --> Router Class Initialized
INFO - 2018-02-21 17:51:17 --> Output Class Initialized
INFO - 2018-02-21 17:51:17 --> Security Class Initialized
DEBUG - 2018-02-21 17:51:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-21 17:51:17 --> Input Class Initialized
INFO - 2018-02-21 17:51:17 --> Language Class Initialized
INFO - 2018-02-21 17:51:17 --> Loader Class Initialized
INFO - 2018-02-21 17:51:17 --> Helper loaded: url_helper
INFO - 2018-02-21 17:51:17 --> Helper loaded: file_helper
INFO - 2018-02-21 17:51:17 --> Helper loaded: email_helper
INFO - 2018-02-21 17:51:17 --> Helper loaded: common_helper
INFO - 2018-02-21 17:51:17 --> Database Driver Class Initialized
DEBUG - 2018-02-21 17:51:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-21 17:51:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-21 17:51:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-21 17:51:17 --> Pagination Class Initialized
INFO - 2018-02-21 17:51:17 --> Helper loaded: form_helper
INFO - 2018-02-21 17:51:17 --> Form Validation Class Initialized
INFO - 2018-02-21 17:51:17 --> Model Class Initialized
INFO - 2018-02-21 17:51:17 --> Controller Class Initialized
DEBUG - 2018-02-21 17:51:17 --> Config file loaded: /var/www/html/project/radio/application/config/rest.php
INFO - 2018-02-21 17:51:17 --> Helper loaded: inflector_helper
INFO - 2018-02-21 17:51:17 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-21 17:51:17 --> Model Class Initialized
INFO - 2018-02-21 17:51:17 --> Model Class Initialized
INFO - 2018-02-21 17:51:17 --> Model Class Initialized
INFO - 2018-02-21 17:51:17 --> Model Class Initialized
INFO - 2018-02-21 17:51:17 --> Model Class Initialized
INFO - 2018-02-21 17:51:17 --> Final output sent to browser
DEBUG - 2018-02-21 17:51:17 --> Total execution time: 0.0051
INFO - 2018-02-21 17:51:41 --> Config Class Initialized
INFO - 2018-02-21 17:51:41 --> Hooks Class Initialized
DEBUG - 2018-02-21 17:51:41 --> UTF-8 Support Enabled
INFO - 2018-02-21 17:51:41 --> Utf8 Class Initialized
INFO - 2018-02-21 17:51:41 --> URI Class Initialized
INFO - 2018-02-21 17:51:41 --> Router Class Initialized
INFO - 2018-02-21 17:51:41 --> Output Class Initialized
INFO - 2018-02-21 17:51:41 --> Security Class Initialized
DEBUG - 2018-02-21 17:51:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-21 17:51:41 --> Input Class Initialized
INFO - 2018-02-21 17:51:41 --> Language Class Initialized
INFO - 2018-02-21 17:51:41 --> Loader Class Initialized
INFO - 2018-02-21 17:51:41 --> Helper loaded: url_helper
INFO - 2018-02-21 17:51:41 --> Helper loaded: file_helper
INFO - 2018-02-21 17:51:41 --> Helper loaded: email_helper
INFO - 2018-02-21 17:51:41 --> Helper loaded: common_helper
INFO - 2018-02-21 17:51:41 --> Database Driver Class Initialized
DEBUG - 2018-02-21 17:51:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-21 17:51:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-21 17:51:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-21 17:51:41 --> Pagination Class Initialized
INFO - 2018-02-21 17:51:41 --> Helper loaded: form_helper
INFO - 2018-02-21 17:51:41 --> Form Validation Class Initialized
INFO - 2018-02-21 17:51:41 --> Model Class Initialized
INFO - 2018-02-21 17:51:41 --> Controller Class Initialized
DEBUG - 2018-02-21 17:51:41 --> Config file loaded: /var/www/html/project/radio/application/config/rest.php
INFO - 2018-02-21 17:51:41 --> Helper loaded: inflector_helper
INFO - 2018-02-21 17:51:41 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-21 17:51:41 --> Model Class Initialized
INFO - 2018-02-21 17:51:41 --> Model Class Initialized
INFO - 2018-02-21 17:51:41 --> Model Class Initialized
INFO - 2018-02-21 17:51:41 --> Model Class Initialized
INFO - 2018-02-21 17:51:41 --> Model Class Initialized
INFO - 2018-02-21 17:51:41 --> Final output sent to browser
DEBUG - 2018-02-21 17:51:41 --> Total execution time: 0.0060

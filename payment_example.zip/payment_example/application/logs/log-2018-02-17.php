<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2018-02-17 10:01:39 --> Config Class Initialized
INFO - 2018-02-17 10:01:39 --> Hooks Class Initialized
DEBUG - 2018-02-17 10:01:39 --> UTF-8 Support Enabled
INFO - 2018-02-17 10:01:39 --> Utf8 Class Initialized
INFO - 2018-02-17 10:01:39 --> URI Class Initialized
DEBUG - 2018-02-17 10:01:39 --> No URI present. Default controller set.
INFO - 2018-02-17 10:01:39 --> Router Class Initialized
INFO - 2018-02-17 10:01:39 --> Output Class Initialized
INFO - 2018-02-17 10:01:39 --> Security Class Initialized
DEBUG - 2018-02-17 10:01:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-17 10:01:39 --> Input Class Initialized
INFO - 2018-02-17 10:01:39 --> Language Class Initialized
INFO - 2018-02-17 10:01:39 --> Loader Class Initialized
INFO - 2018-02-17 10:01:39 --> Helper loaded: url_helper
INFO - 2018-02-17 10:01:39 --> Helper loaded: file_helper
INFO - 2018-02-17 10:01:39 --> Helper loaded: email_helper
INFO - 2018-02-17 10:01:39 --> Helper loaded: common_helper
INFO - 2018-02-17 10:01:39 --> Database Driver Class Initialized
DEBUG - 2018-02-17 10:01:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-17 10:01:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-17 10:01:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-17 10:01:39 --> Pagination Class Initialized
INFO - 2018-02-17 10:01:39 --> Helper loaded: form_helper
INFO - 2018-02-17 10:01:39 --> Form Validation Class Initialized
INFO - 2018-02-17 10:01:39 --> Model Class Initialized
INFO - 2018-02-17 10:01:39 --> Controller Class Initialized
INFO - 2018-02-17 10:01:39 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-17 10:01:39 --> Model Class Initialized
INFO - 2018-02-17 10:01:39 --> File loaded: /var/www/html/project/radio/application/views/index/index.php
INFO - 2018-02-17 10:01:39 --> Final output sent to browser
DEBUG - 2018-02-17 10:01:39 --> Total execution time: 0.4235
INFO - 2018-02-17 10:01:45 --> Config Class Initialized
INFO - 2018-02-17 10:01:45 --> Hooks Class Initialized
DEBUG - 2018-02-17 10:01:45 --> UTF-8 Support Enabled
INFO - 2018-02-17 10:01:45 --> Utf8 Class Initialized
INFO - 2018-02-17 10:01:45 --> URI Class Initialized
INFO - 2018-02-17 10:01:45 --> Router Class Initialized
INFO - 2018-02-17 10:01:45 --> Output Class Initialized
INFO - 2018-02-17 10:01:45 --> Security Class Initialized
DEBUG - 2018-02-17 10:01:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-17 10:01:45 --> Input Class Initialized
INFO - 2018-02-17 10:01:45 --> Language Class Initialized
INFO - 2018-02-17 10:01:45 --> Loader Class Initialized
INFO - 2018-02-17 10:01:45 --> Helper loaded: url_helper
INFO - 2018-02-17 10:01:45 --> Helper loaded: file_helper
INFO - 2018-02-17 10:01:45 --> Helper loaded: email_helper
INFO - 2018-02-17 10:01:45 --> Helper loaded: common_helper
INFO - 2018-02-17 10:01:45 --> Database Driver Class Initialized
DEBUG - 2018-02-17 10:01:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-17 10:01:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-17 10:01:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-17 10:01:45 --> Pagination Class Initialized
INFO - 2018-02-17 10:01:45 --> Helper loaded: form_helper
INFO - 2018-02-17 10:01:45 --> Form Validation Class Initialized
INFO - 2018-02-17 10:01:45 --> Model Class Initialized
INFO - 2018-02-17 10:01:45 --> Controller Class Initialized
INFO - 2018-02-17 10:01:45 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-17 10:01:45 --> Model Class Initialized
ERROR - 2018-02-17 10:01:46 --> Severity: Notice --> Undefined index: remember_me /var/www/html/project/radio/application/controllers/Index.php 73
INFO - 2018-02-17 10:01:46 --> Config Class Initialized
INFO - 2018-02-17 10:01:46 --> Hooks Class Initialized
DEBUG - 2018-02-17 10:01:46 --> UTF-8 Support Enabled
INFO - 2018-02-17 10:01:46 --> Utf8 Class Initialized
INFO - 2018-02-17 10:01:46 --> URI Class Initialized
INFO - 2018-02-17 10:01:46 --> Router Class Initialized
INFO - 2018-02-17 10:01:46 --> Output Class Initialized
INFO - 2018-02-17 10:01:46 --> Security Class Initialized
DEBUG - 2018-02-17 10:01:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-17 10:01:46 --> Input Class Initialized
INFO - 2018-02-17 10:01:46 --> Language Class Initialized
INFO - 2018-02-17 10:01:46 --> Loader Class Initialized
INFO - 2018-02-17 10:01:46 --> Helper loaded: url_helper
INFO - 2018-02-17 10:01:46 --> Helper loaded: file_helper
INFO - 2018-02-17 10:01:46 --> Helper loaded: email_helper
INFO - 2018-02-17 10:01:46 --> Helper loaded: common_helper
INFO - 2018-02-17 10:01:46 --> Database Driver Class Initialized
DEBUG - 2018-02-17 10:01:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-17 10:01:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-17 10:01:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-17 10:01:46 --> Pagination Class Initialized
INFO - 2018-02-17 10:01:46 --> Helper loaded: form_helper
INFO - 2018-02-17 10:01:46 --> Form Validation Class Initialized
INFO - 2018-02-17 10:01:46 --> Model Class Initialized
INFO - 2018-02-17 10:01:46 --> Controller Class Initialized
INFO - 2018-02-17 10:01:46 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-17 10:01:46 --> Model Class Initialized
INFO - 2018-02-17 10:01:46 --> Model Class Initialized
INFO - 2018-02-17 10:01:46 --> Model Class Initialized
INFO - 2018-02-17 10:01:46 --> Model Class Initialized
INFO - 2018-02-17 10:01:46 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-17 10:01:46 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-17 10:01:46 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-17 10:01:46 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-17 10:01:46 --> File loaded: /var/www/html/project/radio/application/views/dashboard/index.php
INFO - 2018-02-17 10:01:46 --> Final output sent to browser
DEBUG - 2018-02-17 10:01:46 --> Total execution time: 0.3004
INFO - 2018-02-17 10:01:51 --> Config Class Initialized
INFO - 2018-02-17 10:01:51 --> Hooks Class Initialized
DEBUG - 2018-02-17 10:01:51 --> UTF-8 Support Enabled
INFO - 2018-02-17 10:01:51 --> Utf8 Class Initialized
INFO - 2018-02-17 10:01:51 --> URI Class Initialized
INFO - 2018-02-17 10:01:51 --> Router Class Initialized
INFO - 2018-02-17 10:01:51 --> Output Class Initialized
INFO - 2018-02-17 10:01:51 --> Security Class Initialized
DEBUG - 2018-02-17 10:01:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-17 10:01:51 --> Input Class Initialized
INFO - 2018-02-17 10:01:51 --> Language Class Initialized
INFO - 2018-02-17 10:01:51 --> Loader Class Initialized
INFO - 2018-02-17 10:01:51 --> Helper loaded: url_helper
INFO - 2018-02-17 10:01:51 --> Helper loaded: file_helper
INFO - 2018-02-17 10:01:51 --> Helper loaded: email_helper
INFO - 2018-02-17 10:01:51 --> Helper loaded: common_helper
INFO - 2018-02-17 10:01:51 --> Database Driver Class Initialized
DEBUG - 2018-02-17 10:01:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-17 10:01:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-17 10:01:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-17 10:01:51 --> Pagination Class Initialized
INFO - 2018-02-17 10:01:51 --> Helper loaded: form_helper
INFO - 2018-02-17 10:01:51 --> Form Validation Class Initialized
INFO - 2018-02-17 10:01:51 --> Model Class Initialized
INFO - 2018-02-17 10:01:51 --> Controller Class Initialized
INFO - 2018-02-17 10:01:51 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-17 10:01:51 --> Model Class Initialized
INFO - 2018-02-17 10:01:51 --> Model Class Initialized
INFO - 2018-02-17 10:01:51 --> Model Class Initialized
INFO - 2018-02-17 10:01:51 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-17 10:01:51 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-17 10:01:51 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-17 10:01:51 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-17 10:01:51 --> File loaded: /var/www/html/project/radio/application/views/tracks/index.php
INFO - 2018-02-17 10:01:51 --> Final output sent to browser
DEBUG - 2018-02-17 10:01:51 --> Total execution time: 0.0149
INFO - 2018-02-17 10:01:51 --> Config Class Initialized
INFO - 2018-02-17 10:01:51 --> Hooks Class Initialized
DEBUG - 2018-02-17 10:01:51 --> UTF-8 Support Enabled
INFO - 2018-02-17 10:01:51 --> Utf8 Class Initialized
INFO - 2018-02-17 10:01:51 --> URI Class Initialized
INFO - 2018-02-17 10:01:51 --> Router Class Initialized
INFO - 2018-02-17 10:01:51 --> Output Class Initialized
INFO - 2018-02-17 10:01:51 --> Security Class Initialized
DEBUG - 2018-02-17 10:01:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-17 10:01:51 --> Input Class Initialized
INFO - 2018-02-17 10:01:51 --> Language Class Initialized
INFO - 2018-02-17 10:01:51 --> Loader Class Initialized
INFO - 2018-02-17 10:01:51 --> Helper loaded: url_helper
INFO - 2018-02-17 10:01:51 --> Helper loaded: file_helper
INFO - 2018-02-17 10:01:51 --> Helper loaded: email_helper
INFO - 2018-02-17 10:01:51 --> Helper loaded: common_helper
INFO - 2018-02-17 10:01:51 --> Database Driver Class Initialized
DEBUG - 2018-02-17 10:01:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-17 10:01:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-17 10:01:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-17 10:01:51 --> Pagination Class Initialized
INFO - 2018-02-17 10:01:51 --> Helper loaded: form_helper
INFO - 2018-02-17 10:01:51 --> Form Validation Class Initialized
INFO - 2018-02-17 10:01:51 --> Model Class Initialized
INFO - 2018-02-17 10:01:51 --> Controller Class Initialized
INFO - 2018-02-17 10:01:51 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-17 10:01:51 --> Model Class Initialized
INFO - 2018-02-17 10:01:51 --> Model Class Initialized
INFO - 2018-02-17 10:01:51 --> Model Class Initialized
INFO - 2018-02-17 10:01:52 --> Config Class Initialized
INFO - 2018-02-17 10:01:52 --> Hooks Class Initialized
DEBUG - 2018-02-17 10:01:52 --> UTF-8 Support Enabled
INFO - 2018-02-17 10:01:52 --> Utf8 Class Initialized
INFO - 2018-02-17 10:01:52 --> URI Class Initialized
INFO - 2018-02-17 10:01:52 --> Router Class Initialized
INFO - 2018-02-17 10:01:52 --> Output Class Initialized
INFO - 2018-02-17 10:01:52 --> Security Class Initialized
DEBUG - 2018-02-17 10:01:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-17 10:01:52 --> Input Class Initialized
INFO - 2018-02-17 10:01:52 --> Language Class Initialized
INFO - 2018-02-17 10:01:52 --> Loader Class Initialized
INFO - 2018-02-17 10:01:52 --> Helper loaded: url_helper
INFO - 2018-02-17 10:01:52 --> Helper loaded: file_helper
INFO - 2018-02-17 10:01:52 --> Helper loaded: email_helper
INFO - 2018-02-17 10:01:52 --> Helper loaded: common_helper
INFO - 2018-02-17 10:01:52 --> Database Driver Class Initialized
DEBUG - 2018-02-17 10:01:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-17 10:01:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-17 10:01:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-17 10:01:52 --> Pagination Class Initialized
INFO - 2018-02-17 10:01:52 --> Helper loaded: form_helper
INFO - 2018-02-17 10:01:52 --> Form Validation Class Initialized
INFO - 2018-02-17 10:01:52 --> Model Class Initialized
INFO - 2018-02-17 10:01:52 --> Controller Class Initialized
INFO - 2018-02-17 10:01:52 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-17 10:01:52 --> Model Class Initialized
INFO - 2018-02-17 10:01:52 --> Model Class Initialized
INFO - 2018-02-17 10:01:52 --> Model Class Initialized
INFO - 2018-02-17 10:01:52 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-17 10:01:52 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-17 10:01:52 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-17 10:01:52 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-17 10:01:52 --> File loaded: /var/www/html/project/radio/application/views/tracks/add_edit.php
INFO - 2018-02-17 10:01:52 --> Final output sent to browser
DEBUG - 2018-02-17 10:01:52 --> Total execution time: 0.0172
INFO - 2018-02-17 10:38:47 --> Config Class Initialized
INFO - 2018-02-17 10:38:47 --> Hooks Class Initialized
DEBUG - 2018-02-17 10:38:47 --> UTF-8 Support Enabled
INFO - 2018-02-17 10:38:47 --> Utf8 Class Initialized
INFO - 2018-02-17 10:38:47 --> URI Class Initialized
INFO - 2018-02-17 10:38:47 --> Router Class Initialized
INFO - 2018-02-17 10:38:47 --> Output Class Initialized
INFO - 2018-02-17 10:38:47 --> Security Class Initialized
DEBUG - 2018-02-17 10:38:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-17 10:38:47 --> Input Class Initialized
INFO - 2018-02-17 10:38:47 --> Language Class Initialized
INFO - 2018-02-17 10:38:47 --> Loader Class Initialized
INFO - 2018-02-17 10:38:47 --> Helper loaded: url_helper
INFO - 2018-02-17 10:38:47 --> Helper loaded: file_helper
INFO - 2018-02-17 10:38:47 --> Helper loaded: email_helper
INFO - 2018-02-17 10:38:47 --> Helper loaded: common_helper
INFO - 2018-02-17 10:38:47 --> Database Driver Class Initialized
DEBUG - 2018-02-17 10:38:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-17 10:38:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-17 10:38:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-17 10:38:47 --> Pagination Class Initialized
INFO - 2018-02-17 10:38:47 --> Helper loaded: form_helper
INFO - 2018-02-17 10:38:47 --> Form Validation Class Initialized
INFO - 2018-02-17 10:38:47 --> Model Class Initialized
INFO - 2018-02-17 10:38:47 --> Controller Class Initialized
INFO - 2018-02-17 10:38:47 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-17 10:38:47 --> Model Class Initialized
INFO - 2018-02-17 10:38:47 --> Model Class Initialized
INFO - 2018-02-17 10:38:47 --> Model Class Initialized
INFO - 2018-02-17 10:38:47 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-17 10:38:47 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-17 10:38:47 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-17 10:38:47 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-17 10:38:47 --> File loaded: /var/www/html/project/radio/application/views/tracks/add_edit.php
INFO - 2018-02-17 10:38:47 --> Final output sent to browser
DEBUG - 2018-02-17 10:38:47 --> Total execution time: 0.0358
INFO - 2018-02-17 10:43:19 --> Config Class Initialized
INFO - 2018-02-17 10:43:19 --> Hooks Class Initialized
DEBUG - 2018-02-17 10:43:19 --> UTF-8 Support Enabled
INFO - 2018-02-17 10:43:19 --> Utf8 Class Initialized
INFO - 2018-02-17 10:43:19 --> URI Class Initialized
INFO - 2018-02-17 10:43:19 --> Router Class Initialized
INFO - 2018-02-17 10:43:19 --> Output Class Initialized
INFO - 2018-02-17 10:43:19 --> Security Class Initialized
DEBUG - 2018-02-17 10:43:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-17 10:43:19 --> Input Class Initialized
INFO - 2018-02-17 10:43:19 --> Language Class Initialized
INFO - 2018-02-17 10:43:19 --> Loader Class Initialized
INFO - 2018-02-17 10:43:19 --> Helper loaded: url_helper
INFO - 2018-02-17 10:43:19 --> Helper loaded: file_helper
INFO - 2018-02-17 10:43:19 --> Helper loaded: email_helper
INFO - 2018-02-17 10:43:19 --> Helper loaded: common_helper
INFO - 2018-02-17 10:43:19 --> Database Driver Class Initialized
DEBUG - 2018-02-17 10:43:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-17 10:43:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-17 10:43:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-17 10:43:19 --> Pagination Class Initialized
INFO - 2018-02-17 10:43:19 --> Helper loaded: form_helper
INFO - 2018-02-17 10:43:19 --> Form Validation Class Initialized
INFO - 2018-02-17 10:43:19 --> Model Class Initialized
INFO - 2018-02-17 10:43:19 --> Controller Class Initialized
INFO - 2018-02-17 10:43:19 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-17 10:43:19 --> Model Class Initialized
INFO - 2018-02-17 10:43:19 --> Model Class Initialized
INFO - 2018-02-17 10:43:19 --> Model Class Initialized
INFO - 2018-02-17 10:43:19 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-17 10:43:19 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-17 10:43:19 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-17 10:43:19 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-17 10:43:19 --> File loaded: /var/www/html/project/radio/application/views/tracks/add_edit.php
INFO - 2018-02-17 10:43:19 --> Final output sent to browser
DEBUG - 2018-02-17 10:43:19 --> Total execution time: 0.0105
INFO - 2018-02-17 10:43:47 --> Config Class Initialized
INFO - 2018-02-17 10:43:47 --> Hooks Class Initialized
DEBUG - 2018-02-17 10:43:47 --> UTF-8 Support Enabled
INFO - 2018-02-17 10:43:47 --> Utf8 Class Initialized
INFO - 2018-02-17 10:43:47 --> URI Class Initialized
INFO - 2018-02-17 10:43:47 --> Router Class Initialized
INFO - 2018-02-17 10:43:47 --> Output Class Initialized
INFO - 2018-02-17 10:43:47 --> Security Class Initialized
DEBUG - 2018-02-17 10:43:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-17 10:43:47 --> Input Class Initialized
INFO - 2018-02-17 10:43:47 --> Language Class Initialized
INFO - 2018-02-17 10:43:47 --> Loader Class Initialized
INFO - 2018-02-17 10:43:47 --> Helper loaded: url_helper
INFO - 2018-02-17 10:43:47 --> Helper loaded: file_helper
INFO - 2018-02-17 10:43:47 --> Helper loaded: email_helper
INFO - 2018-02-17 10:43:47 --> Helper loaded: common_helper
INFO - 2018-02-17 10:43:47 --> Database Driver Class Initialized
DEBUG - 2018-02-17 10:43:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-17 10:43:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-17 10:43:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-17 10:43:47 --> Pagination Class Initialized
INFO - 2018-02-17 10:43:47 --> Helper loaded: form_helper
INFO - 2018-02-17 10:43:47 --> Form Validation Class Initialized
INFO - 2018-02-17 10:43:47 --> Model Class Initialized
INFO - 2018-02-17 10:43:47 --> Controller Class Initialized
INFO - 2018-02-17 10:43:47 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-17 10:43:47 --> Model Class Initialized
INFO - 2018-02-17 10:43:47 --> Model Class Initialized
INFO - 2018-02-17 10:43:47 --> Model Class Initialized
INFO - 2018-02-17 10:43:47 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-17 10:43:47 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-17 10:43:47 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-17 10:43:47 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-17 10:43:47 --> File loaded: /var/www/html/project/radio/application/views/tracks/add_edit.php
INFO - 2018-02-17 10:43:47 --> Final output sent to browser
DEBUG - 2018-02-17 10:43:47 --> Total execution time: 0.0114
INFO - 2018-02-17 10:44:08 --> Config Class Initialized
INFO - 2018-02-17 10:44:08 --> Hooks Class Initialized
DEBUG - 2018-02-17 10:44:08 --> UTF-8 Support Enabled
INFO - 2018-02-17 10:44:08 --> Utf8 Class Initialized
INFO - 2018-02-17 10:44:08 --> URI Class Initialized
INFO - 2018-02-17 10:44:08 --> Router Class Initialized
INFO - 2018-02-17 10:44:08 --> Output Class Initialized
INFO - 2018-02-17 10:44:08 --> Security Class Initialized
DEBUG - 2018-02-17 10:44:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-17 10:44:08 --> Input Class Initialized
INFO - 2018-02-17 10:44:08 --> Language Class Initialized
INFO - 2018-02-17 10:44:08 --> Loader Class Initialized
INFO - 2018-02-17 10:44:08 --> Helper loaded: url_helper
INFO - 2018-02-17 10:44:08 --> Helper loaded: file_helper
INFO - 2018-02-17 10:44:08 --> Helper loaded: email_helper
INFO - 2018-02-17 10:44:08 --> Helper loaded: common_helper
INFO - 2018-02-17 10:44:08 --> Database Driver Class Initialized
DEBUG - 2018-02-17 10:44:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-17 10:44:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-17 10:44:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-17 10:44:08 --> Pagination Class Initialized
INFO - 2018-02-17 10:44:08 --> Helper loaded: form_helper
INFO - 2018-02-17 10:44:08 --> Form Validation Class Initialized
INFO - 2018-02-17 10:44:08 --> Model Class Initialized
INFO - 2018-02-17 10:44:08 --> Controller Class Initialized
INFO - 2018-02-17 10:44:08 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-17 10:44:08 --> Model Class Initialized
INFO - 2018-02-17 10:44:08 --> Model Class Initialized
INFO - 2018-02-17 10:44:08 --> Model Class Initialized
INFO - 2018-02-17 10:44:08 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-17 10:44:08 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-17 10:44:08 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-17 10:44:08 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-17 10:44:08 --> File loaded: /var/www/html/project/radio/application/views/tracks/index.php
INFO - 2018-02-17 10:44:08 --> Final output sent to browser
DEBUG - 2018-02-17 10:44:08 --> Total execution time: 0.0105
INFO - 2018-02-17 10:44:09 --> Config Class Initialized
INFO - 2018-02-17 10:44:09 --> Hooks Class Initialized
DEBUG - 2018-02-17 10:44:09 --> UTF-8 Support Enabled
INFO - 2018-02-17 10:44:09 --> Utf8 Class Initialized
INFO - 2018-02-17 10:44:09 --> URI Class Initialized
INFO - 2018-02-17 10:44:09 --> Router Class Initialized
INFO - 2018-02-17 10:44:09 --> Output Class Initialized
INFO - 2018-02-17 10:44:09 --> Security Class Initialized
DEBUG - 2018-02-17 10:44:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-17 10:44:09 --> Input Class Initialized
INFO - 2018-02-17 10:44:09 --> Language Class Initialized
INFO - 2018-02-17 10:44:09 --> Loader Class Initialized
INFO - 2018-02-17 10:44:09 --> Helper loaded: url_helper
INFO - 2018-02-17 10:44:09 --> Helper loaded: file_helper
INFO - 2018-02-17 10:44:09 --> Helper loaded: email_helper
INFO - 2018-02-17 10:44:09 --> Helper loaded: common_helper
INFO - 2018-02-17 10:44:09 --> Database Driver Class Initialized
DEBUG - 2018-02-17 10:44:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-17 10:44:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-17 10:44:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-17 10:44:09 --> Pagination Class Initialized
INFO - 2018-02-17 10:44:09 --> Helper loaded: form_helper
INFO - 2018-02-17 10:44:09 --> Form Validation Class Initialized
INFO - 2018-02-17 10:44:09 --> Model Class Initialized
INFO - 2018-02-17 10:44:09 --> Controller Class Initialized
INFO - 2018-02-17 10:44:09 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-17 10:44:09 --> Model Class Initialized
INFO - 2018-02-17 10:44:09 --> Model Class Initialized
INFO - 2018-02-17 10:44:09 --> Model Class Initialized
INFO - 2018-02-17 10:44:15 --> Config Class Initialized
INFO - 2018-02-17 10:44:15 --> Hooks Class Initialized
DEBUG - 2018-02-17 10:44:15 --> UTF-8 Support Enabled
INFO - 2018-02-17 10:44:15 --> Utf8 Class Initialized
INFO - 2018-02-17 10:44:15 --> URI Class Initialized
INFO - 2018-02-17 10:44:15 --> Router Class Initialized
INFO - 2018-02-17 10:44:15 --> Output Class Initialized
INFO - 2018-02-17 10:44:15 --> Security Class Initialized
DEBUG - 2018-02-17 10:44:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-17 10:44:15 --> Input Class Initialized
INFO - 2018-02-17 10:44:15 --> Language Class Initialized
INFO - 2018-02-17 10:44:15 --> Loader Class Initialized
INFO - 2018-02-17 10:44:15 --> Helper loaded: url_helper
INFO - 2018-02-17 10:44:15 --> Helper loaded: file_helper
INFO - 2018-02-17 10:44:15 --> Helper loaded: email_helper
INFO - 2018-02-17 10:44:15 --> Helper loaded: common_helper
INFO - 2018-02-17 10:44:15 --> Database Driver Class Initialized
DEBUG - 2018-02-17 10:44:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-17 10:44:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-17 10:44:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-17 10:44:15 --> Pagination Class Initialized
INFO - 2018-02-17 10:44:15 --> Helper loaded: form_helper
INFO - 2018-02-17 10:44:15 --> Form Validation Class Initialized
INFO - 2018-02-17 10:44:15 --> Model Class Initialized
INFO - 2018-02-17 10:44:15 --> Controller Class Initialized
INFO - 2018-02-17 10:44:15 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-17 10:44:15 --> Model Class Initialized
INFO - 2018-02-17 10:44:15 --> Model Class Initialized
INFO - 2018-02-17 10:44:15 --> Model Class Initialized
INFO - 2018-02-17 10:44:15 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-17 10:44:15 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-17 10:44:15 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-17 10:44:15 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-17 10:44:15 --> File loaded: /var/www/html/project/radio/application/views/tracks/add_edit.php
INFO - 2018-02-17 10:44:15 --> Final output sent to browser
DEBUG - 2018-02-17 10:44:15 --> Total execution time: 0.0105
INFO - 2018-02-17 10:45:07 --> Config Class Initialized
INFO - 2018-02-17 10:45:07 --> Hooks Class Initialized
DEBUG - 2018-02-17 10:45:07 --> UTF-8 Support Enabled
INFO - 2018-02-17 10:45:07 --> Utf8 Class Initialized
INFO - 2018-02-17 10:45:07 --> URI Class Initialized
INFO - 2018-02-17 10:45:07 --> Router Class Initialized
INFO - 2018-02-17 10:45:07 --> Output Class Initialized
INFO - 2018-02-17 10:45:07 --> Security Class Initialized
DEBUG - 2018-02-17 10:45:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-17 10:45:07 --> Input Class Initialized
INFO - 2018-02-17 10:45:07 --> Language Class Initialized
INFO - 2018-02-17 10:45:07 --> Loader Class Initialized
INFO - 2018-02-17 10:45:07 --> Helper loaded: url_helper
INFO - 2018-02-17 10:45:07 --> Helper loaded: file_helper
INFO - 2018-02-17 10:45:07 --> Helper loaded: email_helper
INFO - 2018-02-17 10:45:07 --> Helper loaded: common_helper
INFO - 2018-02-17 10:45:07 --> Database Driver Class Initialized
DEBUG - 2018-02-17 10:45:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-17 10:45:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-17 10:45:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-17 10:45:07 --> Pagination Class Initialized
INFO - 2018-02-17 10:45:07 --> Helper loaded: form_helper
INFO - 2018-02-17 10:45:07 --> Form Validation Class Initialized
INFO - 2018-02-17 10:45:07 --> Model Class Initialized
INFO - 2018-02-17 10:45:07 --> Controller Class Initialized
INFO - 2018-02-17 10:45:07 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-17 10:45:07 --> Model Class Initialized
INFO - 2018-02-17 10:45:07 --> Model Class Initialized
INFO - 2018-02-17 10:45:07 --> Model Class Initialized
INFO - 2018-02-17 10:45:07 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-17 10:45:07 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-17 10:45:07 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-17 10:45:07 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-17 10:45:07 --> File loaded: /var/www/html/project/radio/application/views/tracks/add_edit.php
INFO - 2018-02-17 10:45:07 --> Final output sent to browser
DEBUG - 2018-02-17 10:45:07 --> Total execution time: 0.0126
INFO - 2018-02-17 10:45:14 --> Config Class Initialized
INFO - 2018-02-17 10:45:14 --> Hooks Class Initialized
DEBUG - 2018-02-17 10:45:14 --> UTF-8 Support Enabled
INFO - 2018-02-17 10:45:14 --> Utf8 Class Initialized
INFO - 2018-02-17 10:45:14 --> URI Class Initialized
INFO - 2018-02-17 10:45:14 --> Router Class Initialized
INFO - 2018-02-17 10:45:14 --> Output Class Initialized
INFO - 2018-02-17 10:45:14 --> Security Class Initialized
DEBUG - 2018-02-17 10:45:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-17 10:45:14 --> Input Class Initialized
INFO - 2018-02-17 10:45:14 --> Language Class Initialized
INFO - 2018-02-17 10:45:14 --> Loader Class Initialized
INFO - 2018-02-17 10:45:14 --> Helper loaded: url_helper
INFO - 2018-02-17 10:45:14 --> Helper loaded: file_helper
INFO - 2018-02-17 10:45:14 --> Helper loaded: email_helper
INFO - 2018-02-17 10:45:14 --> Helper loaded: common_helper
INFO - 2018-02-17 10:45:14 --> Database Driver Class Initialized
DEBUG - 2018-02-17 10:45:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-17 10:45:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-17 10:45:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-17 10:45:14 --> Pagination Class Initialized
INFO - 2018-02-17 10:45:14 --> Helper loaded: form_helper
INFO - 2018-02-17 10:45:14 --> Form Validation Class Initialized
INFO - 2018-02-17 10:45:14 --> Model Class Initialized
INFO - 2018-02-17 10:45:14 --> Controller Class Initialized
INFO - 2018-02-17 10:45:14 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-17 10:45:14 --> Model Class Initialized
INFO - 2018-02-17 10:45:14 --> Model Class Initialized
INFO - 2018-02-17 10:45:14 --> Model Class Initialized
DEBUG - 2018-02-17 10:45:14 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-17 10:45:14 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-02-17 10:45:14 --> Config Class Initialized
INFO - 2018-02-17 10:45:14 --> Hooks Class Initialized
DEBUG - 2018-02-17 10:45:14 --> UTF-8 Support Enabled
INFO - 2018-02-17 10:45:14 --> Utf8 Class Initialized
INFO - 2018-02-17 10:45:14 --> URI Class Initialized
INFO - 2018-02-17 10:45:14 --> Router Class Initialized
INFO - 2018-02-17 10:45:14 --> Output Class Initialized
INFO - 2018-02-17 10:45:14 --> Security Class Initialized
DEBUG - 2018-02-17 10:45:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-17 10:45:14 --> Input Class Initialized
INFO - 2018-02-17 10:45:14 --> Language Class Initialized
INFO - 2018-02-17 10:45:14 --> Loader Class Initialized
INFO - 2018-02-17 10:45:14 --> Helper loaded: url_helper
INFO - 2018-02-17 10:45:14 --> Helper loaded: file_helper
INFO - 2018-02-17 10:45:14 --> Helper loaded: email_helper
INFO - 2018-02-17 10:45:14 --> Helper loaded: common_helper
INFO - 2018-02-17 10:45:14 --> Database Driver Class Initialized
DEBUG - 2018-02-17 10:45:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-17 10:45:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-17 10:45:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-17 10:45:14 --> Pagination Class Initialized
INFO - 2018-02-17 10:45:14 --> Helper loaded: form_helper
INFO - 2018-02-17 10:45:14 --> Form Validation Class Initialized
INFO - 2018-02-17 10:45:14 --> Model Class Initialized
INFO - 2018-02-17 10:45:14 --> Controller Class Initialized
INFO - 2018-02-17 10:45:14 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-17 10:45:14 --> Model Class Initialized
INFO - 2018-02-17 10:45:14 --> Model Class Initialized
INFO - 2018-02-17 10:45:14 --> Model Class Initialized
INFO - 2018-02-17 10:45:14 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-17 10:45:14 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-17 10:45:14 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-17 10:45:14 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-17 10:45:14 --> File loaded: /var/www/html/project/radio/application/views/tracks/index.php
INFO - 2018-02-17 10:45:14 --> Final output sent to browser
DEBUG - 2018-02-17 10:45:14 --> Total execution time: 0.0043
INFO - 2018-02-17 10:45:14 --> Config Class Initialized
INFO - 2018-02-17 10:45:14 --> Hooks Class Initialized
DEBUG - 2018-02-17 10:45:14 --> UTF-8 Support Enabled
INFO - 2018-02-17 10:45:14 --> Utf8 Class Initialized
INFO - 2018-02-17 10:45:14 --> URI Class Initialized
INFO - 2018-02-17 10:45:14 --> Router Class Initialized
INFO - 2018-02-17 10:45:14 --> Output Class Initialized
INFO - 2018-02-17 10:45:14 --> Security Class Initialized
DEBUG - 2018-02-17 10:45:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-17 10:45:14 --> Input Class Initialized
INFO - 2018-02-17 10:45:14 --> Language Class Initialized
INFO - 2018-02-17 10:45:14 --> Loader Class Initialized
INFO - 2018-02-17 10:45:14 --> Helper loaded: url_helper
INFO - 2018-02-17 10:45:14 --> Helper loaded: file_helper
INFO - 2018-02-17 10:45:14 --> Helper loaded: email_helper
INFO - 2018-02-17 10:45:14 --> Helper loaded: common_helper
INFO - 2018-02-17 10:45:14 --> Database Driver Class Initialized
DEBUG - 2018-02-17 10:45:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-17 10:45:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-17 10:45:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-17 10:45:14 --> Pagination Class Initialized
INFO - 2018-02-17 10:45:14 --> Helper loaded: form_helper
INFO - 2018-02-17 10:45:14 --> Form Validation Class Initialized
INFO - 2018-02-17 10:45:14 --> Model Class Initialized
INFO - 2018-02-17 10:45:14 --> Controller Class Initialized
INFO - 2018-02-17 10:45:14 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-17 10:45:14 --> Model Class Initialized
INFO - 2018-02-17 10:45:14 --> Model Class Initialized
INFO - 2018-02-17 10:45:14 --> Model Class Initialized
INFO - 2018-02-17 10:45:18 --> Config Class Initialized
INFO - 2018-02-17 10:45:18 --> Hooks Class Initialized
DEBUG - 2018-02-17 10:45:18 --> UTF-8 Support Enabled
INFO - 2018-02-17 10:45:18 --> Utf8 Class Initialized
INFO - 2018-02-17 10:45:18 --> URI Class Initialized
INFO - 2018-02-17 10:45:18 --> Router Class Initialized
INFO - 2018-02-17 10:45:18 --> Output Class Initialized
INFO - 2018-02-17 10:45:18 --> Security Class Initialized
DEBUG - 2018-02-17 10:45:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-17 10:45:18 --> Input Class Initialized
INFO - 2018-02-17 10:45:18 --> Language Class Initialized
INFO - 2018-02-17 10:45:18 --> Loader Class Initialized
INFO - 2018-02-17 10:45:18 --> Helper loaded: url_helper
INFO - 2018-02-17 10:45:18 --> Helper loaded: file_helper
INFO - 2018-02-17 10:45:18 --> Helper loaded: email_helper
INFO - 2018-02-17 10:45:18 --> Helper loaded: common_helper
INFO - 2018-02-17 10:45:18 --> Database Driver Class Initialized
DEBUG - 2018-02-17 10:45:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-17 10:45:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-17 10:45:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-17 10:45:18 --> Pagination Class Initialized
INFO - 2018-02-17 10:45:18 --> Helper loaded: form_helper
INFO - 2018-02-17 10:45:18 --> Form Validation Class Initialized
INFO - 2018-02-17 10:45:18 --> Model Class Initialized
INFO - 2018-02-17 10:45:18 --> Controller Class Initialized
INFO - 2018-02-17 10:45:18 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-17 10:45:18 --> Model Class Initialized
INFO - 2018-02-17 10:45:18 --> Model Class Initialized
INFO - 2018-02-17 10:45:18 --> Model Class Initialized
INFO - 2018-02-17 10:45:18 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-17 10:45:18 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-17 10:45:18 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-17 10:45:18 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-17 10:45:18 --> File loaded: /var/www/html/project/radio/application/views/tracks/add_edit.php
INFO - 2018-02-17 10:45:18 --> Final output sent to browser
DEBUG - 2018-02-17 10:45:18 --> Total execution time: 0.0096
INFO - 2018-02-17 10:45:26 --> Config Class Initialized
INFO - 2018-02-17 10:45:26 --> Hooks Class Initialized
DEBUG - 2018-02-17 10:45:26 --> UTF-8 Support Enabled
INFO - 2018-02-17 10:45:26 --> Utf8 Class Initialized
INFO - 2018-02-17 10:45:26 --> URI Class Initialized
INFO - 2018-02-17 10:45:26 --> Router Class Initialized
INFO - 2018-02-17 10:45:26 --> Output Class Initialized
INFO - 2018-02-17 10:45:26 --> Security Class Initialized
DEBUG - 2018-02-17 10:45:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-17 10:45:26 --> Input Class Initialized
INFO - 2018-02-17 10:45:26 --> Language Class Initialized
INFO - 2018-02-17 10:45:26 --> Loader Class Initialized
INFO - 2018-02-17 10:45:26 --> Helper loaded: url_helper
INFO - 2018-02-17 10:45:26 --> Helper loaded: file_helper
INFO - 2018-02-17 10:45:26 --> Helper loaded: email_helper
INFO - 2018-02-17 10:45:26 --> Helper loaded: common_helper
INFO - 2018-02-17 10:45:26 --> Database Driver Class Initialized
DEBUG - 2018-02-17 10:45:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-17 10:45:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-17 10:45:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-17 10:45:26 --> Pagination Class Initialized
INFO - 2018-02-17 10:45:26 --> Helper loaded: form_helper
INFO - 2018-02-17 10:45:26 --> Form Validation Class Initialized
INFO - 2018-02-17 10:45:26 --> Model Class Initialized
INFO - 2018-02-17 10:45:26 --> Controller Class Initialized
INFO - 2018-02-17 10:45:26 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-17 10:45:26 --> Model Class Initialized
INFO - 2018-02-17 10:45:26 --> Model Class Initialized
INFO - 2018-02-17 10:45:26 --> Model Class Initialized
DEBUG - 2018-02-17 10:45:26 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-17 10:45:26 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-02-17 10:45:26 --> Config Class Initialized
INFO - 2018-02-17 10:45:26 --> Hooks Class Initialized
DEBUG - 2018-02-17 10:45:26 --> UTF-8 Support Enabled
INFO - 2018-02-17 10:45:26 --> Utf8 Class Initialized
INFO - 2018-02-17 10:45:26 --> URI Class Initialized
INFO - 2018-02-17 10:45:26 --> Router Class Initialized
INFO - 2018-02-17 10:45:26 --> Output Class Initialized
INFO - 2018-02-17 10:45:26 --> Security Class Initialized
DEBUG - 2018-02-17 10:45:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-17 10:45:26 --> Input Class Initialized
INFO - 2018-02-17 10:45:26 --> Language Class Initialized
INFO - 2018-02-17 10:45:26 --> Loader Class Initialized
INFO - 2018-02-17 10:45:26 --> Helper loaded: url_helper
INFO - 2018-02-17 10:45:26 --> Helper loaded: file_helper
INFO - 2018-02-17 10:45:26 --> Helper loaded: email_helper
INFO - 2018-02-17 10:45:26 --> Helper loaded: common_helper
INFO - 2018-02-17 10:45:26 --> Database Driver Class Initialized
DEBUG - 2018-02-17 10:45:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-17 10:45:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-17 10:45:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-17 10:45:26 --> Pagination Class Initialized
INFO - 2018-02-17 10:45:26 --> Helper loaded: form_helper
INFO - 2018-02-17 10:45:26 --> Form Validation Class Initialized
INFO - 2018-02-17 10:45:26 --> Model Class Initialized
INFO - 2018-02-17 10:45:26 --> Controller Class Initialized
INFO - 2018-02-17 10:45:26 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-17 10:45:26 --> Model Class Initialized
INFO - 2018-02-17 10:45:26 --> Model Class Initialized
INFO - 2018-02-17 10:45:26 --> Model Class Initialized
INFO - 2018-02-17 10:45:26 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-17 10:45:26 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-17 10:45:26 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-17 10:45:26 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-17 10:45:26 --> File loaded: /var/www/html/project/radio/application/views/tracks/index.php
INFO - 2018-02-17 10:45:26 --> Final output sent to browser
DEBUG - 2018-02-17 10:45:26 --> Total execution time: 0.0054
INFO - 2018-02-17 10:45:26 --> Config Class Initialized
INFO - 2018-02-17 10:45:26 --> Hooks Class Initialized
DEBUG - 2018-02-17 10:45:26 --> UTF-8 Support Enabled
INFO - 2018-02-17 10:45:26 --> Utf8 Class Initialized
INFO - 2018-02-17 10:45:26 --> URI Class Initialized
INFO - 2018-02-17 10:45:26 --> Router Class Initialized
INFO - 2018-02-17 10:45:26 --> Output Class Initialized
INFO - 2018-02-17 10:45:26 --> Security Class Initialized
DEBUG - 2018-02-17 10:45:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-17 10:45:26 --> Input Class Initialized
INFO - 2018-02-17 10:45:26 --> Language Class Initialized
INFO - 2018-02-17 10:45:26 --> Loader Class Initialized
INFO - 2018-02-17 10:45:26 --> Helper loaded: url_helper
INFO - 2018-02-17 10:45:26 --> Helper loaded: file_helper
INFO - 2018-02-17 10:45:26 --> Helper loaded: email_helper
INFO - 2018-02-17 10:45:26 --> Helper loaded: common_helper
INFO - 2018-02-17 10:45:26 --> Database Driver Class Initialized
DEBUG - 2018-02-17 10:45:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-17 10:45:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-17 10:45:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-17 10:45:26 --> Pagination Class Initialized
INFO - 2018-02-17 10:45:26 --> Helper loaded: form_helper
INFO - 2018-02-17 10:45:26 --> Form Validation Class Initialized
INFO - 2018-02-17 10:45:26 --> Model Class Initialized
INFO - 2018-02-17 10:45:26 --> Controller Class Initialized
INFO - 2018-02-17 10:45:26 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-17 10:45:26 --> Model Class Initialized
INFO - 2018-02-17 10:45:26 --> Model Class Initialized
INFO - 2018-02-17 10:45:26 --> Model Class Initialized
INFO - 2018-02-17 10:45:29 --> Config Class Initialized
INFO - 2018-02-17 10:45:29 --> Hooks Class Initialized
DEBUG - 2018-02-17 10:45:29 --> UTF-8 Support Enabled
INFO - 2018-02-17 10:45:29 --> Utf8 Class Initialized
INFO - 2018-02-17 10:45:29 --> URI Class Initialized
INFO - 2018-02-17 10:45:29 --> Router Class Initialized
INFO - 2018-02-17 10:45:29 --> Output Class Initialized
INFO - 2018-02-17 10:45:29 --> Security Class Initialized
DEBUG - 2018-02-17 10:45:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-17 10:45:29 --> Input Class Initialized
INFO - 2018-02-17 10:45:29 --> Language Class Initialized
INFO - 2018-02-17 10:45:29 --> Loader Class Initialized
INFO - 2018-02-17 10:45:29 --> Helper loaded: url_helper
INFO - 2018-02-17 10:45:29 --> Helper loaded: file_helper
INFO - 2018-02-17 10:45:29 --> Helper loaded: email_helper
INFO - 2018-02-17 10:45:29 --> Helper loaded: common_helper
INFO - 2018-02-17 10:45:29 --> Database Driver Class Initialized
DEBUG - 2018-02-17 10:45:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-17 10:45:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-17 10:45:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-17 10:45:29 --> Pagination Class Initialized
INFO - 2018-02-17 10:45:29 --> Helper loaded: form_helper
INFO - 2018-02-17 10:45:29 --> Form Validation Class Initialized
INFO - 2018-02-17 10:45:29 --> Model Class Initialized
INFO - 2018-02-17 10:45:29 --> Controller Class Initialized
INFO - 2018-02-17 10:45:29 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-17 10:45:29 --> Model Class Initialized
INFO - 2018-02-17 10:45:29 --> Model Class Initialized
INFO - 2018-02-17 10:45:29 --> Model Class Initialized
INFO - 2018-02-17 10:45:29 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-17 10:45:29 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-17 10:45:29 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-17 10:45:29 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-17 10:45:29 --> File loaded: /var/www/html/project/radio/application/views/tracks/add_edit.php
INFO - 2018-02-17 10:45:29 --> Final output sent to browser
DEBUG - 2018-02-17 10:45:29 --> Total execution time: 0.0093
INFO - 2018-02-17 10:45:37 --> Config Class Initialized
INFO - 2018-02-17 10:45:37 --> Hooks Class Initialized
DEBUG - 2018-02-17 10:45:37 --> UTF-8 Support Enabled
INFO - 2018-02-17 10:45:37 --> Utf8 Class Initialized
INFO - 2018-02-17 10:45:37 --> URI Class Initialized
INFO - 2018-02-17 10:45:37 --> Router Class Initialized
INFO - 2018-02-17 10:45:37 --> Output Class Initialized
INFO - 2018-02-17 10:45:37 --> Security Class Initialized
DEBUG - 2018-02-17 10:45:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-17 10:45:37 --> Input Class Initialized
INFO - 2018-02-17 10:45:37 --> Language Class Initialized
INFO - 2018-02-17 10:45:37 --> Loader Class Initialized
INFO - 2018-02-17 10:45:37 --> Helper loaded: url_helper
INFO - 2018-02-17 10:45:37 --> Helper loaded: file_helper
INFO - 2018-02-17 10:45:37 --> Helper loaded: email_helper
INFO - 2018-02-17 10:45:37 --> Helper loaded: common_helper
INFO - 2018-02-17 10:45:37 --> Database Driver Class Initialized
DEBUG - 2018-02-17 10:45:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-17 10:45:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-17 10:45:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-17 10:45:37 --> Pagination Class Initialized
INFO - 2018-02-17 10:45:37 --> Helper loaded: form_helper
INFO - 2018-02-17 10:45:37 --> Form Validation Class Initialized
INFO - 2018-02-17 10:45:37 --> Model Class Initialized
INFO - 2018-02-17 10:45:37 --> Controller Class Initialized
INFO - 2018-02-17 10:45:37 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-17 10:45:37 --> Model Class Initialized
INFO - 2018-02-17 10:45:37 --> Model Class Initialized
INFO - 2018-02-17 10:45:37 --> Model Class Initialized
DEBUG - 2018-02-17 10:45:37 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-17 10:45:37 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-02-17 10:45:37 --> Config Class Initialized
INFO - 2018-02-17 10:45:37 --> Hooks Class Initialized
DEBUG - 2018-02-17 10:45:37 --> UTF-8 Support Enabled
INFO - 2018-02-17 10:45:37 --> Utf8 Class Initialized
INFO - 2018-02-17 10:45:37 --> URI Class Initialized
INFO - 2018-02-17 10:45:37 --> Router Class Initialized
INFO - 2018-02-17 10:45:37 --> Output Class Initialized
INFO - 2018-02-17 10:45:37 --> Security Class Initialized
DEBUG - 2018-02-17 10:45:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-17 10:45:37 --> Input Class Initialized
INFO - 2018-02-17 10:45:37 --> Language Class Initialized
INFO - 2018-02-17 10:45:37 --> Loader Class Initialized
INFO - 2018-02-17 10:45:37 --> Helper loaded: url_helper
INFO - 2018-02-17 10:45:37 --> Helper loaded: file_helper
INFO - 2018-02-17 10:45:37 --> Helper loaded: email_helper
INFO - 2018-02-17 10:45:37 --> Helper loaded: common_helper
INFO - 2018-02-17 10:45:37 --> Database Driver Class Initialized
DEBUG - 2018-02-17 10:45:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-17 10:45:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-17 10:45:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-17 10:45:37 --> Pagination Class Initialized
INFO - 2018-02-17 10:45:37 --> Helper loaded: form_helper
INFO - 2018-02-17 10:45:37 --> Form Validation Class Initialized
INFO - 2018-02-17 10:45:37 --> Model Class Initialized
INFO - 2018-02-17 10:45:37 --> Controller Class Initialized
INFO - 2018-02-17 10:45:37 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-17 10:45:37 --> Model Class Initialized
INFO - 2018-02-17 10:45:37 --> Model Class Initialized
INFO - 2018-02-17 10:45:37 --> Model Class Initialized
INFO - 2018-02-17 10:45:37 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-17 10:45:37 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-17 10:45:37 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-17 10:45:37 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-17 10:45:37 --> File loaded: /var/www/html/project/radio/application/views/tracks/index.php
INFO - 2018-02-17 10:45:37 --> Final output sent to browser
DEBUG - 2018-02-17 10:45:37 --> Total execution time: 0.0054
INFO - 2018-02-17 10:45:37 --> Config Class Initialized
INFO - 2018-02-17 10:45:37 --> Hooks Class Initialized
DEBUG - 2018-02-17 10:45:37 --> UTF-8 Support Enabled
INFO - 2018-02-17 10:45:37 --> Utf8 Class Initialized
INFO - 2018-02-17 10:45:37 --> URI Class Initialized
INFO - 2018-02-17 10:45:37 --> Router Class Initialized
INFO - 2018-02-17 10:45:37 --> Output Class Initialized
INFO - 2018-02-17 10:45:37 --> Security Class Initialized
DEBUG - 2018-02-17 10:45:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-17 10:45:37 --> Input Class Initialized
INFO - 2018-02-17 10:45:37 --> Language Class Initialized
INFO - 2018-02-17 10:45:37 --> Loader Class Initialized
INFO - 2018-02-17 10:45:37 --> Helper loaded: url_helper
INFO - 2018-02-17 10:45:37 --> Helper loaded: file_helper
INFO - 2018-02-17 10:45:37 --> Helper loaded: email_helper
INFO - 2018-02-17 10:45:37 --> Helper loaded: common_helper
INFO - 2018-02-17 10:45:37 --> Database Driver Class Initialized
DEBUG - 2018-02-17 10:45:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-17 10:45:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-17 10:45:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-17 10:45:37 --> Pagination Class Initialized
INFO - 2018-02-17 10:45:37 --> Helper loaded: form_helper
INFO - 2018-02-17 10:45:37 --> Form Validation Class Initialized
INFO - 2018-02-17 10:45:37 --> Model Class Initialized
INFO - 2018-02-17 10:45:37 --> Controller Class Initialized
INFO - 2018-02-17 10:45:37 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-17 10:45:37 --> Model Class Initialized
INFO - 2018-02-17 10:45:37 --> Model Class Initialized
INFO - 2018-02-17 10:45:37 --> Model Class Initialized
INFO - 2018-02-17 10:45:54 --> Config Class Initialized
INFO - 2018-02-17 10:45:54 --> Hooks Class Initialized
DEBUG - 2018-02-17 10:45:54 --> UTF-8 Support Enabled
INFO - 2018-02-17 10:45:54 --> Utf8 Class Initialized
INFO - 2018-02-17 10:45:54 --> URI Class Initialized
INFO - 2018-02-17 10:45:54 --> Router Class Initialized
INFO - 2018-02-17 10:45:54 --> Output Class Initialized
INFO - 2018-02-17 10:45:54 --> Security Class Initialized
DEBUG - 2018-02-17 10:45:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-17 10:45:54 --> Input Class Initialized
INFO - 2018-02-17 10:45:54 --> Language Class Initialized
INFO - 2018-02-17 10:45:54 --> Loader Class Initialized
INFO - 2018-02-17 10:45:54 --> Helper loaded: url_helper
INFO - 2018-02-17 10:45:54 --> Helper loaded: file_helper
INFO - 2018-02-17 10:45:54 --> Helper loaded: email_helper
INFO - 2018-02-17 10:45:54 --> Helper loaded: common_helper
INFO - 2018-02-17 10:45:54 --> Database Driver Class Initialized
DEBUG - 2018-02-17 10:45:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-17 10:45:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-17 10:45:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-17 10:45:54 --> Pagination Class Initialized
INFO - 2018-02-17 10:45:54 --> Helper loaded: form_helper
INFO - 2018-02-17 10:45:54 --> Form Validation Class Initialized
INFO - 2018-02-17 10:45:54 --> Model Class Initialized
INFO - 2018-02-17 10:45:54 --> Controller Class Initialized
INFO - 2018-02-17 10:45:54 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-17 10:45:54 --> Model Class Initialized
INFO - 2018-02-17 10:45:54 --> Model Class Initialized
INFO - 2018-02-17 10:45:54 --> Model Class Initialized
INFO - 2018-02-17 10:45:54 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-17 10:45:54 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-17 10:45:54 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-17 10:45:54 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-17 10:45:54 --> File loaded: /var/www/html/project/radio/application/views/tracks/add_edit.php
INFO - 2018-02-17 10:45:54 --> Final output sent to browser
DEBUG - 2018-02-17 10:45:54 --> Total execution time: 0.0139
INFO - 2018-02-17 11:06:01 --> Config Class Initialized
INFO - 2018-02-17 11:06:01 --> Hooks Class Initialized
DEBUG - 2018-02-17 11:06:01 --> UTF-8 Support Enabled
INFO - 2018-02-17 11:06:01 --> Utf8 Class Initialized
INFO - 2018-02-17 11:06:01 --> URI Class Initialized
INFO - 2018-02-17 11:06:01 --> Router Class Initialized
INFO - 2018-02-17 11:06:01 --> Output Class Initialized
INFO - 2018-02-17 11:06:01 --> Security Class Initialized
DEBUG - 2018-02-17 11:06:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-17 11:06:01 --> Input Class Initialized
INFO - 2018-02-17 11:06:01 --> Language Class Initialized
INFO - 2018-02-17 11:06:01 --> Loader Class Initialized
INFO - 2018-02-17 11:06:01 --> Helper loaded: url_helper
INFO - 2018-02-17 11:06:01 --> Helper loaded: file_helper
INFO - 2018-02-17 11:06:01 --> Helper loaded: email_helper
INFO - 2018-02-17 11:06:01 --> Helper loaded: common_helper
INFO - 2018-02-17 11:06:01 --> Database Driver Class Initialized
DEBUG - 2018-02-17 11:06:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-17 11:06:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-17 11:06:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-17 11:06:01 --> Pagination Class Initialized
INFO - 2018-02-17 11:06:01 --> Helper loaded: form_helper
INFO - 2018-02-17 11:06:01 --> Form Validation Class Initialized
INFO - 2018-02-17 11:06:01 --> Model Class Initialized
INFO - 2018-02-17 11:06:01 --> Controller Class Initialized
INFO - 2018-02-17 11:06:01 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-17 11:06:01 --> Model Class Initialized
INFO - 2018-02-17 11:06:01 --> Model Class Initialized
INFO - 2018-02-17 11:06:01 --> Model Class Initialized
INFO - 2018-02-17 11:06:01 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-17 11:06:01 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-17 11:06:01 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-17 11:06:01 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-17 11:06:01 --> File loaded: /var/www/html/project/radio/application/views/tracks/index.php
INFO - 2018-02-17 11:06:01 --> Final output sent to browser
DEBUG - 2018-02-17 11:06:01 --> Total execution time: 0.0094
INFO - 2018-02-17 11:06:01 --> Config Class Initialized
INFO - 2018-02-17 11:06:01 --> Hooks Class Initialized
DEBUG - 2018-02-17 11:06:01 --> UTF-8 Support Enabled
INFO - 2018-02-17 11:06:01 --> Utf8 Class Initialized
INFO - 2018-02-17 11:06:01 --> URI Class Initialized
INFO - 2018-02-17 11:06:01 --> Router Class Initialized
INFO - 2018-02-17 11:06:01 --> Output Class Initialized
INFO - 2018-02-17 11:06:01 --> Security Class Initialized
DEBUG - 2018-02-17 11:06:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-17 11:06:01 --> Input Class Initialized
INFO - 2018-02-17 11:06:01 --> Language Class Initialized
INFO - 2018-02-17 11:06:01 --> Loader Class Initialized
INFO - 2018-02-17 11:06:01 --> Helper loaded: url_helper
INFO - 2018-02-17 11:06:01 --> Helper loaded: file_helper
INFO - 2018-02-17 11:06:01 --> Helper loaded: email_helper
INFO - 2018-02-17 11:06:01 --> Helper loaded: common_helper
INFO - 2018-02-17 11:06:01 --> Database Driver Class Initialized
DEBUG - 2018-02-17 11:06:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-17 11:06:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-17 11:06:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-17 11:06:01 --> Pagination Class Initialized
INFO - 2018-02-17 11:06:01 --> Helper loaded: form_helper
INFO - 2018-02-17 11:06:01 --> Form Validation Class Initialized
INFO - 2018-02-17 11:06:01 --> Model Class Initialized
INFO - 2018-02-17 11:06:01 --> Controller Class Initialized
INFO - 2018-02-17 11:06:01 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-17 11:06:01 --> Model Class Initialized
INFO - 2018-02-17 11:06:01 --> Model Class Initialized
INFO - 2018-02-17 11:06:01 --> Model Class Initialized
INFO - 2018-02-17 11:06:09 --> Config Class Initialized
INFO - 2018-02-17 11:06:09 --> Hooks Class Initialized
DEBUG - 2018-02-17 11:06:09 --> UTF-8 Support Enabled
INFO - 2018-02-17 11:06:09 --> Utf8 Class Initialized
INFO - 2018-02-17 11:06:09 --> URI Class Initialized
INFO - 2018-02-17 11:06:09 --> Router Class Initialized
INFO - 2018-02-17 11:06:09 --> Output Class Initialized
INFO - 2018-02-17 11:06:09 --> Security Class Initialized
DEBUG - 2018-02-17 11:06:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-17 11:06:09 --> Input Class Initialized
INFO - 2018-02-17 11:06:09 --> Language Class Initialized
INFO - 2018-02-17 11:06:09 --> Loader Class Initialized
INFO - 2018-02-17 11:06:09 --> Helper loaded: url_helper
INFO - 2018-02-17 11:06:09 --> Helper loaded: file_helper
INFO - 2018-02-17 11:06:09 --> Helper loaded: email_helper
INFO - 2018-02-17 11:06:09 --> Helper loaded: common_helper
INFO - 2018-02-17 11:06:09 --> Database Driver Class Initialized
DEBUG - 2018-02-17 11:06:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-17 11:06:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-17 11:06:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-17 11:06:09 --> Pagination Class Initialized
INFO - 2018-02-17 11:06:09 --> Helper loaded: form_helper
INFO - 2018-02-17 11:06:09 --> Form Validation Class Initialized
INFO - 2018-02-17 11:06:09 --> Model Class Initialized
INFO - 2018-02-17 11:06:09 --> Controller Class Initialized
INFO - 2018-02-17 11:06:09 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-17 11:06:09 --> Model Class Initialized
INFO - 2018-02-17 11:06:09 --> Model Class Initialized
INFO - 2018-02-17 11:06:09 --> Model Class Initialized
INFO - 2018-02-17 11:06:09 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-17 11:06:09 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-17 11:06:09 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-17 11:06:09 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-17 11:06:09 --> File loaded: /var/www/html/project/radio/application/views/tracks/index.php
INFO - 2018-02-17 11:06:09 --> Final output sent to browser
DEBUG - 2018-02-17 11:06:09 --> Total execution time: 0.0068
INFO - 2018-02-17 11:06:09 --> Config Class Initialized
INFO - 2018-02-17 11:06:09 --> Hooks Class Initialized
DEBUG - 2018-02-17 11:06:09 --> UTF-8 Support Enabled
INFO - 2018-02-17 11:06:09 --> Utf8 Class Initialized
INFO - 2018-02-17 11:06:09 --> URI Class Initialized
INFO - 2018-02-17 11:06:09 --> Router Class Initialized
INFO - 2018-02-17 11:06:09 --> Output Class Initialized
INFO - 2018-02-17 11:06:09 --> Security Class Initialized
DEBUG - 2018-02-17 11:06:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-17 11:06:09 --> Input Class Initialized
INFO - 2018-02-17 11:06:09 --> Language Class Initialized
INFO - 2018-02-17 11:06:09 --> Loader Class Initialized
INFO - 2018-02-17 11:06:09 --> Helper loaded: url_helper
INFO - 2018-02-17 11:06:09 --> Helper loaded: file_helper
INFO - 2018-02-17 11:06:09 --> Helper loaded: email_helper
INFO - 2018-02-17 11:06:09 --> Helper loaded: common_helper
INFO - 2018-02-17 11:06:09 --> Database Driver Class Initialized
DEBUG - 2018-02-17 11:06:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-17 11:06:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-17 11:06:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-17 11:06:09 --> Pagination Class Initialized
INFO - 2018-02-17 11:06:09 --> Helper loaded: form_helper
INFO - 2018-02-17 11:06:09 --> Form Validation Class Initialized
INFO - 2018-02-17 11:06:09 --> Model Class Initialized
INFO - 2018-02-17 11:06:09 --> Controller Class Initialized
INFO - 2018-02-17 11:06:09 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-17 11:06:09 --> Model Class Initialized
INFO - 2018-02-17 11:06:09 --> Model Class Initialized
INFO - 2018-02-17 11:06:09 --> Model Class Initialized
INFO - 2018-02-17 11:50:59 --> Config Class Initialized
INFO - 2018-02-17 11:50:59 --> Hooks Class Initialized
DEBUG - 2018-02-17 11:50:59 --> UTF-8 Support Enabled
INFO - 2018-02-17 11:50:59 --> Utf8 Class Initialized
INFO - 2018-02-17 11:50:59 --> URI Class Initialized
INFO - 2018-02-17 11:50:59 --> Router Class Initialized
INFO - 2018-02-17 11:50:59 --> Output Class Initialized
INFO - 2018-02-17 11:50:59 --> Security Class Initialized
DEBUG - 2018-02-17 11:50:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-17 11:50:59 --> Input Class Initialized
INFO - 2018-02-17 11:50:59 --> Language Class Initialized
INFO - 2018-02-17 11:50:59 --> Loader Class Initialized
INFO - 2018-02-17 11:50:59 --> Helper loaded: url_helper
INFO - 2018-02-17 11:50:59 --> Helper loaded: file_helper
INFO - 2018-02-17 11:50:59 --> Helper loaded: email_helper
INFO - 2018-02-17 11:50:59 --> Helper loaded: common_helper
INFO - 2018-02-17 11:50:59 --> Database Driver Class Initialized
DEBUG - 2018-02-17 11:50:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-17 11:50:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-17 11:50:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-17 11:50:59 --> Pagination Class Initialized
INFO - 2018-02-17 11:50:59 --> Helper loaded: form_helper
INFO - 2018-02-17 11:50:59 --> Form Validation Class Initialized
INFO - 2018-02-17 11:50:59 --> Model Class Initialized
INFO - 2018-02-17 11:50:59 --> Controller Class Initialized
INFO - 2018-02-17 11:50:59 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-17 11:50:59 --> Model Class Initialized
INFO - 2018-02-17 11:50:59 --> Model Class Initialized
INFO - 2018-02-17 11:50:59 --> Model Class Initialized
INFO - 2018-02-17 11:50:59 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-17 11:50:59 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-17 11:50:59 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
ERROR - 2018-02-17 11:50:59 --> Severity: Notice --> Undefined variable: extraFieldData /var/www/html/project/radio/application/views/tracks/add_edit.php 126
ERROR - 2018-02-17 11:50:59 --> Severity: Notice --> Undefined variable: extraFieldData /var/www/html/project/radio/application/views/tracks/add_edit.php 127
ERROR - 2018-02-17 11:50:59 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/project/radio/application/views/tracks/add_edit.php 127
ERROR - 2018-02-17 11:50:59 --> Severity: Notice --> Undefined variable: extraFieldData /var/www/html/project/radio/application/views/tracks/add_edit.php 162
INFO - 2018-02-17 11:50:59 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-17 11:50:59 --> File loaded: /var/www/html/project/radio/application/views/tracks/add_edit.php
INFO - 2018-02-17 11:50:59 --> Final output sent to browser
DEBUG - 2018-02-17 11:50:59 --> Total execution time: 0.0115
INFO - 2018-02-17 11:51:55 --> Config Class Initialized
INFO - 2018-02-17 11:51:55 --> Hooks Class Initialized
DEBUG - 2018-02-17 11:51:55 --> UTF-8 Support Enabled
INFO - 2018-02-17 11:51:55 --> Utf8 Class Initialized
INFO - 2018-02-17 11:51:55 --> URI Class Initialized
INFO - 2018-02-17 11:51:55 --> Router Class Initialized
INFO - 2018-02-17 11:51:55 --> Output Class Initialized
INFO - 2018-02-17 11:51:55 --> Security Class Initialized
DEBUG - 2018-02-17 11:51:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-17 11:51:55 --> Input Class Initialized
INFO - 2018-02-17 11:51:55 --> Language Class Initialized
INFO - 2018-02-17 11:51:55 --> Loader Class Initialized
INFO - 2018-02-17 11:51:55 --> Helper loaded: url_helper
INFO - 2018-02-17 11:51:55 --> Helper loaded: file_helper
INFO - 2018-02-17 11:51:55 --> Helper loaded: email_helper
INFO - 2018-02-17 11:51:55 --> Helper loaded: common_helper
INFO - 2018-02-17 11:51:55 --> Database Driver Class Initialized
DEBUG - 2018-02-17 11:51:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-17 11:51:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-17 11:51:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-17 11:51:55 --> Pagination Class Initialized
INFO - 2018-02-17 11:51:55 --> Helper loaded: form_helper
INFO - 2018-02-17 11:51:55 --> Form Validation Class Initialized
INFO - 2018-02-17 11:51:55 --> Model Class Initialized
INFO - 2018-02-17 11:51:55 --> Controller Class Initialized
INFO - 2018-02-17 11:51:55 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-17 11:51:55 --> Model Class Initialized
INFO - 2018-02-17 11:51:55 --> Model Class Initialized
INFO - 2018-02-17 11:51:55 --> Model Class Initialized
INFO - 2018-02-17 11:51:55 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-17 11:51:55 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-17 11:51:55 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
ERROR - 2018-02-17 11:51:55 --> Severity: Notice --> Undefined variable: extraFieldData /var/www/html/project/radio/application/views/tracks/add_edit.php 127
ERROR - 2018-02-17 11:51:55 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/project/radio/application/views/tracks/add_edit.php 127
INFO - 2018-02-17 11:51:55 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-17 11:51:55 --> File loaded: /var/www/html/project/radio/application/views/tracks/add_edit.php
INFO - 2018-02-17 11:51:55 --> Final output sent to browser
DEBUG - 2018-02-17 11:51:55 --> Total execution time: 0.0115
INFO - 2018-02-17 11:52:24 --> Config Class Initialized
INFO - 2018-02-17 11:52:24 --> Hooks Class Initialized
DEBUG - 2018-02-17 11:52:24 --> UTF-8 Support Enabled
INFO - 2018-02-17 11:52:24 --> Utf8 Class Initialized
INFO - 2018-02-17 11:52:24 --> URI Class Initialized
INFO - 2018-02-17 11:52:24 --> Router Class Initialized
INFO - 2018-02-17 11:52:24 --> Output Class Initialized
INFO - 2018-02-17 11:52:24 --> Security Class Initialized
DEBUG - 2018-02-17 11:52:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-17 11:52:24 --> Input Class Initialized
INFO - 2018-02-17 11:52:24 --> Language Class Initialized
INFO - 2018-02-17 11:52:24 --> Loader Class Initialized
INFO - 2018-02-17 11:52:24 --> Helper loaded: url_helper
INFO - 2018-02-17 11:52:24 --> Helper loaded: file_helper
INFO - 2018-02-17 11:52:24 --> Helper loaded: email_helper
INFO - 2018-02-17 11:52:24 --> Helper loaded: common_helper
INFO - 2018-02-17 11:52:24 --> Database Driver Class Initialized
DEBUG - 2018-02-17 11:52:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-17 11:52:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-17 11:52:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-17 11:52:24 --> Pagination Class Initialized
INFO - 2018-02-17 11:52:24 --> Helper loaded: form_helper
INFO - 2018-02-17 11:52:24 --> Form Validation Class Initialized
INFO - 2018-02-17 11:52:24 --> Model Class Initialized
INFO - 2018-02-17 11:52:24 --> Controller Class Initialized
INFO - 2018-02-17 11:52:24 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-17 11:52:24 --> Model Class Initialized
INFO - 2018-02-17 11:52:24 --> Model Class Initialized
INFO - 2018-02-17 11:52:24 --> Model Class Initialized
INFO - 2018-02-17 11:52:24 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-17 11:52:24 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-17 11:52:24 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
ERROR - 2018-02-17 11:52:24 --> Severity: Notice --> Undefined variable: extraFieldData /var/www/html/project/radio/application/views/tracks/add_edit.php 127
ERROR - 2018-02-17 11:52:24 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/project/radio/application/views/tracks/add_edit.php 127
INFO - 2018-02-17 11:52:24 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-17 11:52:24 --> File loaded: /var/www/html/project/radio/application/views/tracks/add_edit.php
INFO - 2018-02-17 11:52:24 --> Final output sent to browser
DEBUG - 2018-02-17 11:52:24 --> Total execution time: 0.0104
INFO - 2018-02-17 11:52:44 --> Config Class Initialized
INFO - 2018-02-17 11:52:44 --> Hooks Class Initialized
DEBUG - 2018-02-17 11:52:44 --> UTF-8 Support Enabled
INFO - 2018-02-17 11:52:44 --> Utf8 Class Initialized
INFO - 2018-02-17 11:52:44 --> URI Class Initialized
INFO - 2018-02-17 11:52:44 --> Router Class Initialized
INFO - 2018-02-17 11:52:44 --> Output Class Initialized
INFO - 2018-02-17 11:52:44 --> Security Class Initialized
DEBUG - 2018-02-17 11:52:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-17 11:52:44 --> Input Class Initialized
INFO - 2018-02-17 11:52:44 --> Language Class Initialized
INFO - 2018-02-17 11:52:44 --> Loader Class Initialized
INFO - 2018-02-17 11:52:44 --> Helper loaded: url_helper
INFO - 2018-02-17 11:52:44 --> Helper loaded: file_helper
INFO - 2018-02-17 11:52:44 --> Helper loaded: email_helper
INFO - 2018-02-17 11:52:44 --> Helper loaded: common_helper
INFO - 2018-02-17 11:52:44 --> Database Driver Class Initialized
DEBUG - 2018-02-17 11:52:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-17 11:52:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-17 11:52:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-17 11:52:44 --> Pagination Class Initialized
INFO - 2018-02-17 11:52:44 --> Helper loaded: form_helper
INFO - 2018-02-17 11:52:44 --> Form Validation Class Initialized
INFO - 2018-02-17 11:52:44 --> Model Class Initialized
INFO - 2018-02-17 11:52:44 --> Controller Class Initialized
INFO - 2018-02-17 11:52:44 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-17 11:52:44 --> Model Class Initialized
INFO - 2018-02-17 11:52:44 --> Model Class Initialized
INFO - 2018-02-17 11:52:44 --> Model Class Initialized
INFO - 2018-02-17 11:52:44 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-17 11:52:44 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-17 11:52:44 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-17 11:52:44 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-17 11:52:44 --> File loaded: /var/www/html/project/radio/application/views/tracks/add_edit.php
INFO - 2018-02-17 11:52:44 --> Final output sent to browser
DEBUG - 2018-02-17 11:52:44 --> Total execution time: 0.0114
INFO - 2018-02-17 11:53:29 --> Config Class Initialized
INFO - 2018-02-17 11:53:29 --> Hooks Class Initialized
DEBUG - 2018-02-17 11:53:29 --> UTF-8 Support Enabled
INFO - 2018-02-17 11:53:29 --> Utf8 Class Initialized
INFO - 2018-02-17 11:53:29 --> URI Class Initialized
INFO - 2018-02-17 11:53:29 --> Router Class Initialized
INFO - 2018-02-17 11:53:29 --> Output Class Initialized
INFO - 2018-02-17 11:53:29 --> Security Class Initialized
DEBUG - 2018-02-17 11:53:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-17 11:53:29 --> Input Class Initialized
INFO - 2018-02-17 11:53:29 --> Language Class Initialized
INFO - 2018-02-17 11:53:29 --> Loader Class Initialized
INFO - 2018-02-17 11:53:29 --> Helper loaded: url_helper
INFO - 2018-02-17 11:53:29 --> Helper loaded: file_helper
INFO - 2018-02-17 11:53:29 --> Helper loaded: email_helper
INFO - 2018-02-17 11:53:29 --> Helper loaded: common_helper
INFO - 2018-02-17 11:53:29 --> Database Driver Class Initialized
DEBUG - 2018-02-17 11:53:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-17 11:53:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-17 11:53:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-17 11:53:29 --> Pagination Class Initialized
INFO - 2018-02-17 11:53:29 --> Helper loaded: form_helper
INFO - 2018-02-17 11:53:29 --> Form Validation Class Initialized
INFO - 2018-02-17 11:53:29 --> Model Class Initialized
INFO - 2018-02-17 11:53:29 --> Controller Class Initialized
INFO - 2018-02-17 11:53:29 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-17 11:53:29 --> Model Class Initialized
INFO - 2018-02-17 11:53:29 --> Model Class Initialized
INFO - 2018-02-17 11:53:29 --> Model Class Initialized
INFO - 2018-02-17 11:53:29 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-17 11:53:29 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-17 11:53:29 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-17 11:53:29 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-17 11:53:29 --> File loaded: /var/www/html/project/radio/application/views/tracks/add_edit.php
INFO - 2018-02-17 11:53:29 --> Final output sent to browser
DEBUG - 2018-02-17 11:53:29 --> Total execution time: 0.0108
INFO - 2018-02-17 11:53:34 --> Config Class Initialized
INFO - 2018-02-17 11:53:34 --> Hooks Class Initialized
DEBUG - 2018-02-17 11:53:34 --> UTF-8 Support Enabled
INFO - 2018-02-17 11:53:34 --> Utf8 Class Initialized
INFO - 2018-02-17 11:53:34 --> URI Class Initialized
INFO - 2018-02-17 11:53:34 --> Router Class Initialized
INFO - 2018-02-17 11:53:34 --> Output Class Initialized
INFO - 2018-02-17 11:53:34 --> Security Class Initialized
DEBUG - 2018-02-17 11:53:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-17 11:53:34 --> Input Class Initialized
INFO - 2018-02-17 11:53:34 --> Language Class Initialized
INFO - 2018-02-17 11:53:34 --> Loader Class Initialized
INFO - 2018-02-17 11:53:34 --> Helper loaded: url_helper
INFO - 2018-02-17 11:53:34 --> Helper loaded: file_helper
INFO - 2018-02-17 11:53:34 --> Helper loaded: email_helper
INFO - 2018-02-17 11:53:34 --> Helper loaded: common_helper
INFO - 2018-02-17 11:53:34 --> Database Driver Class Initialized
DEBUG - 2018-02-17 11:53:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-17 11:53:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-17 11:53:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-17 11:53:34 --> Pagination Class Initialized
INFO - 2018-02-17 11:53:34 --> Helper loaded: form_helper
INFO - 2018-02-17 11:53:34 --> Form Validation Class Initialized
INFO - 2018-02-17 11:53:34 --> Model Class Initialized
INFO - 2018-02-17 11:53:34 --> Controller Class Initialized
INFO - 2018-02-17 11:53:34 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-17 11:53:34 --> Model Class Initialized
INFO - 2018-02-17 11:53:34 --> Model Class Initialized
INFO - 2018-02-17 11:53:34 --> Model Class Initialized
INFO - 2018-02-17 11:53:34 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-17 11:53:34 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-17 11:53:34 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-17 11:53:34 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-17 11:53:34 --> File loaded: /var/www/html/project/radio/application/views/tracks/add_edit.php
INFO - 2018-02-17 11:53:34 --> Final output sent to browser
DEBUG - 2018-02-17 11:53:34 --> Total execution time: 0.0116
INFO - 2018-02-17 11:54:24 --> Config Class Initialized
INFO - 2018-02-17 11:54:24 --> Hooks Class Initialized
DEBUG - 2018-02-17 11:54:24 --> UTF-8 Support Enabled
INFO - 2018-02-17 11:54:24 --> Utf8 Class Initialized
INFO - 2018-02-17 11:54:24 --> URI Class Initialized
INFO - 2018-02-17 11:54:24 --> Router Class Initialized
INFO - 2018-02-17 11:54:24 --> Output Class Initialized
INFO - 2018-02-17 11:54:24 --> Security Class Initialized
DEBUG - 2018-02-17 11:54:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-17 11:54:24 --> Input Class Initialized
INFO - 2018-02-17 11:54:24 --> Language Class Initialized
INFO - 2018-02-17 11:54:24 --> Loader Class Initialized
INFO - 2018-02-17 11:54:24 --> Helper loaded: url_helper
INFO - 2018-02-17 11:54:24 --> Helper loaded: file_helper
INFO - 2018-02-17 11:54:24 --> Helper loaded: email_helper
INFO - 2018-02-17 11:54:24 --> Helper loaded: common_helper
INFO - 2018-02-17 11:54:24 --> Database Driver Class Initialized
DEBUG - 2018-02-17 11:54:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-17 11:54:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-17 11:54:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-17 11:54:24 --> Pagination Class Initialized
INFO - 2018-02-17 11:54:24 --> Helper loaded: form_helper
INFO - 2018-02-17 11:54:24 --> Form Validation Class Initialized
INFO - 2018-02-17 11:54:24 --> Model Class Initialized
INFO - 2018-02-17 11:54:24 --> Controller Class Initialized
INFO - 2018-02-17 11:54:24 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-17 11:54:24 --> Model Class Initialized
INFO - 2018-02-17 11:54:24 --> Model Class Initialized
INFO - 2018-02-17 11:54:24 --> Model Class Initialized
INFO - 2018-02-17 11:54:24 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-17 11:54:24 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-17 11:54:24 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-17 11:54:24 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-17 11:54:24 --> File loaded: /var/www/html/project/radio/application/views/tracks/add_edit.php
INFO - 2018-02-17 11:54:24 --> Final output sent to browser
DEBUG - 2018-02-17 11:54:24 --> Total execution time: 0.0114
INFO - 2018-02-17 12:27:35 --> Config Class Initialized
INFO - 2018-02-17 12:27:35 --> Hooks Class Initialized
DEBUG - 2018-02-17 12:27:35 --> UTF-8 Support Enabled
INFO - 2018-02-17 12:27:35 --> Utf8 Class Initialized
INFO - 2018-02-17 12:27:35 --> URI Class Initialized
INFO - 2018-02-17 12:27:35 --> Router Class Initialized
INFO - 2018-02-17 12:27:35 --> Output Class Initialized
INFO - 2018-02-17 12:27:35 --> Security Class Initialized
DEBUG - 2018-02-17 12:27:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-17 12:27:35 --> Input Class Initialized
INFO - 2018-02-17 12:27:35 --> Language Class Initialized
INFO - 2018-02-17 12:27:35 --> Loader Class Initialized
INFO - 2018-02-17 12:27:35 --> Helper loaded: url_helper
INFO - 2018-02-17 12:27:35 --> Helper loaded: file_helper
INFO - 2018-02-17 12:27:35 --> Helper loaded: email_helper
INFO - 2018-02-17 12:27:35 --> Helper loaded: common_helper
INFO - 2018-02-17 12:27:35 --> Database Driver Class Initialized
DEBUG - 2018-02-17 12:27:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-17 12:27:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-17 12:27:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-17 12:27:35 --> Pagination Class Initialized
INFO - 2018-02-17 12:27:35 --> Helper loaded: form_helper
INFO - 2018-02-17 12:27:35 --> Form Validation Class Initialized
INFO - 2018-02-17 12:27:35 --> Model Class Initialized
INFO - 2018-02-17 12:27:35 --> Controller Class Initialized
INFO - 2018-02-17 12:27:35 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-17 12:27:35 --> Model Class Initialized
INFO - 2018-02-17 12:27:35 --> Model Class Initialized
INFO - 2018-02-17 12:27:35 --> Model Class Initialized
INFO - 2018-02-17 12:27:35 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-17 12:27:35 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-17 12:27:35 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-17 12:27:35 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-17 12:27:35 --> File loaded: /var/www/html/project/radio/application/views/tracks/add_edit.php
INFO - 2018-02-17 12:27:35 --> Final output sent to browser
DEBUG - 2018-02-17 12:27:35 --> Total execution time: 0.0351
INFO - 2018-02-17 12:27:47 --> Config Class Initialized
INFO - 2018-02-17 12:27:47 --> Hooks Class Initialized
DEBUG - 2018-02-17 12:27:47 --> UTF-8 Support Enabled
INFO - 2018-02-17 12:27:47 --> Utf8 Class Initialized
INFO - 2018-02-17 12:27:47 --> URI Class Initialized
INFO - 2018-02-17 12:27:47 --> Router Class Initialized
INFO - 2018-02-17 12:27:47 --> Output Class Initialized
INFO - 2018-02-17 12:27:47 --> Security Class Initialized
DEBUG - 2018-02-17 12:27:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-17 12:27:47 --> Input Class Initialized
INFO - 2018-02-17 12:27:47 --> Language Class Initialized
INFO - 2018-02-17 12:27:47 --> Loader Class Initialized
INFO - 2018-02-17 12:27:47 --> Helper loaded: url_helper
INFO - 2018-02-17 12:27:47 --> Helper loaded: file_helper
INFO - 2018-02-17 12:27:47 --> Helper loaded: email_helper
INFO - 2018-02-17 12:27:47 --> Helper loaded: common_helper
INFO - 2018-02-17 12:27:47 --> Database Driver Class Initialized
DEBUG - 2018-02-17 12:27:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-17 12:27:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-17 12:27:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-17 12:27:47 --> Pagination Class Initialized
INFO - 2018-02-17 12:27:47 --> Helper loaded: form_helper
INFO - 2018-02-17 12:27:47 --> Form Validation Class Initialized
INFO - 2018-02-17 12:27:47 --> Model Class Initialized
INFO - 2018-02-17 12:27:47 --> Controller Class Initialized
INFO - 2018-02-17 12:27:47 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-17 12:27:47 --> Model Class Initialized
INFO - 2018-02-17 12:27:47 --> Model Class Initialized
INFO - 2018-02-17 12:27:47 --> Model Class Initialized
INFO - 2018-02-17 12:28:12 --> Config Class Initialized
INFO - 2018-02-17 12:28:12 --> Hooks Class Initialized
DEBUG - 2018-02-17 12:28:12 --> UTF-8 Support Enabled
INFO - 2018-02-17 12:28:12 --> Utf8 Class Initialized
INFO - 2018-02-17 12:28:12 --> URI Class Initialized
INFO - 2018-02-17 12:28:12 --> Router Class Initialized
INFO - 2018-02-17 12:28:12 --> Output Class Initialized
INFO - 2018-02-17 12:28:12 --> Security Class Initialized
DEBUG - 2018-02-17 12:28:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-17 12:28:12 --> Input Class Initialized
INFO - 2018-02-17 12:28:12 --> Language Class Initialized
INFO - 2018-02-17 12:28:12 --> Loader Class Initialized
INFO - 2018-02-17 12:28:12 --> Helper loaded: url_helper
INFO - 2018-02-17 12:28:12 --> Helper loaded: file_helper
INFO - 2018-02-17 12:28:12 --> Helper loaded: email_helper
INFO - 2018-02-17 12:28:12 --> Helper loaded: common_helper
INFO - 2018-02-17 12:28:12 --> Database Driver Class Initialized
DEBUG - 2018-02-17 12:28:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-17 12:28:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-17 12:28:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-17 12:28:12 --> Pagination Class Initialized
INFO - 2018-02-17 12:28:12 --> Helper loaded: form_helper
INFO - 2018-02-17 12:28:12 --> Form Validation Class Initialized
INFO - 2018-02-17 12:28:12 --> Model Class Initialized
INFO - 2018-02-17 12:28:12 --> Controller Class Initialized
INFO - 2018-02-17 12:28:12 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-17 12:28:12 --> Model Class Initialized
INFO - 2018-02-17 12:28:12 --> Model Class Initialized
INFO - 2018-02-17 12:28:12 --> Model Class Initialized
INFO - 2018-02-17 12:28:12 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-17 12:28:12 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-17 12:28:12 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-17 12:28:12 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-17 12:28:12 --> File loaded: /var/www/html/project/radio/application/views/tracks/add_edit.php
INFO - 2018-02-17 12:28:12 --> Final output sent to browser
DEBUG - 2018-02-17 12:28:12 --> Total execution time: 0.0103
INFO - 2018-02-17 12:28:18 --> Config Class Initialized
INFO - 2018-02-17 12:28:18 --> Hooks Class Initialized
DEBUG - 2018-02-17 12:28:18 --> UTF-8 Support Enabled
INFO - 2018-02-17 12:28:18 --> Utf8 Class Initialized
INFO - 2018-02-17 12:28:18 --> URI Class Initialized
INFO - 2018-02-17 12:28:18 --> Router Class Initialized
INFO - 2018-02-17 12:28:18 --> Output Class Initialized
INFO - 2018-02-17 12:28:18 --> Security Class Initialized
DEBUG - 2018-02-17 12:28:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-17 12:28:18 --> Input Class Initialized
INFO - 2018-02-17 12:28:18 --> Language Class Initialized
INFO - 2018-02-17 12:28:18 --> Loader Class Initialized
INFO - 2018-02-17 12:28:18 --> Helper loaded: url_helper
INFO - 2018-02-17 12:28:18 --> Helper loaded: file_helper
INFO - 2018-02-17 12:28:18 --> Helper loaded: email_helper
INFO - 2018-02-17 12:28:18 --> Helper loaded: common_helper
INFO - 2018-02-17 12:28:18 --> Database Driver Class Initialized
DEBUG - 2018-02-17 12:28:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-17 12:28:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-17 12:28:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-17 12:28:18 --> Pagination Class Initialized
INFO - 2018-02-17 12:28:18 --> Helper loaded: form_helper
INFO - 2018-02-17 12:28:18 --> Form Validation Class Initialized
INFO - 2018-02-17 12:28:18 --> Model Class Initialized
INFO - 2018-02-17 12:28:18 --> Controller Class Initialized
INFO - 2018-02-17 12:28:18 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-17 12:28:18 --> Model Class Initialized
INFO - 2018-02-17 12:28:18 --> Model Class Initialized
INFO - 2018-02-17 12:28:18 --> Model Class Initialized
INFO - 2018-02-17 12:28:26 --> Config Class Initialized
INFO - 2018-02-17 12:28:26 --> Hooks Class Initialized
DEBUG - 2018-02-17 12:28:26 --> UTF-8 Support Enabled
INFO - 2018-02-17 12:28:26 --> Utf8 Class Initialized
INFO - 2018-02-17 12:28:26 --> URI Class Initialized
INFO - 2018-02-17 12:28:26 --> Router Class Initialized
INFO - 2018-02-17 12:28:26 --> Output Class Initialized
INFO - 2018-02-17 12:28:26 --> Security Class Initialized
DEBUG - 2018-02-17 12:28:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-17 12:28:26 --> Input Class Initialized
INFO - 2018-02-17 12:28:26 --> Language Class Initialized
INFO - 2018-02-17 12:28:26 --> Loader Class Initialized
INFO - 2018-02-17 12:28:26 --> Helper loaded: url_helper
INFO - 2018-02-17 12:28:26 --> Helper loaded: file_helper
INFO - 2018-02-17 12:28:26 --> Helper loaded: email_helper
INFO - 2018-02-17 12:28:26 --> Helper loaded: common_helper
INFO - 2018-02-17 12:28:26 --> Database Driver Class Initialized
DEBUG - 2018-02-17 12:28:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-17 12:28:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-17 12:28:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-17 12:28:26 --> Pagination Class Initialized
INFO - 2018-02-17 12:28:26 --> Helper loaded: form_helper
INFO - 2018-02-17 12:28:26 --> Form Validation Class Initialized
INFO - 2018-02-17 12:28:26 --> Model Class Initialized
INFO - 2018-02-17 12:28:26 --> Controller Class Initialized
INFO - 2018-02-17 12:28:26 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-17 12:28:26 --> Model Class Initialized
INFO - 2018-02-17 12:28:26 --> Model Class Initialized
INFO - 2018-02-17 12:28:26 --> Model Class Initialized
INFO - 2018-02-17 12:28:31 --> Config Class Initialized
INFO - 2018-02-17 12:28:31 --> Hooks Class Initialized
DEBUG - 2018-02-17 12:28:31 --> UTF-8 Support Enabled
INFO - 2018-02-17 12:28:31 --> Utf8 Class Initialized
INFO - 2018-02-17 12:28:31 --> URI Class Initialized
INFO - 2018-02-17 12:28:31 --> Router Class Initialized
INFO - 2018-02-17 12:28:31 --> Output Class Initialized
INFO - 2018-02-17 12:28:31 --> Security Class Initialized
DEBUG - 2018-02-17 12:28:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-17 12:28:31 --> Input Class Initialized
INFO - 2018-02-17 12:28:31 --> Language Class Initialized
INFO - 2018-02-17 12:28:31 --> Loader Class Initialized
INFO - 2018-02-17 12:28:31 --> Helper loaded: url_helper
INFO - 2018-02-17 12:28:31 --> Helper loaded: file_helper
INFO - 2018-02-17 12:28:31 --> Helper loaded: email_helper
INFO - 2018-02-17 12:28:31 --> Helper loaded: common_helper
INFO - 2018-02-17 12:28:31 --> Database Driver Class Initialized
DEBUG - 2018-02-17 12:28:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-17 12:28:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-17 12:28:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-17 12:28:31 --> Pagination Class Initialized
INFO - 2018-02-17 12:28:31 --> Helper loaded: form_helper
INFO - 2018-02-17 12:28:31 --> Form Validation Class Initialized
INFO - 2018-02-17 12:28:31 --> Model Class Initialized
INFO - 2018-02-17 12:28:31 --> Controller Class Initialized
INFO - 2018-02-17 12:28:31 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-17 12:28:31 --> Model Class Initialized
INFO - 2018-02-17 12:28:31 --> Model Class Initialized
INFO - 2018-02-17 12:28:31 --> Model Class Initialized
INFO - 2018-02-17 12:28:33 --> Config Class Initialized
INFO - 2018-02-17 12:28:33 --> Hooks Class Initialized
DEBUG - 2018-02-17 12:28:33 --> UTF-8 Support Enabled
INFO - 2018-02-17 12:28:33 --> Utf8 Class Initialized
INFO - 2018-02-17 12:28:33 --> URI Class Initialized
INFO - 2018-02-17 12:28:33 --> Router Class Initialized
INFO - 2018-02-17 12:28:33 --> Output Class Initialized
INFO - 2018-02-17 12:28:33 --> Security Class Initialized
DEBUG - 2018-02-17 12:28:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-17 12:28:33 --> Input Class Initialized
INFO - 2018-02-17 12:28:33 --> Language Class Initialized
INFO - 2018-02-17 12:28:33 --> Loader Class Initialized
INFO - 2018-02-17 12:28:33 --> Helper loaded: url_helper
INFO - 2018-02-17 12:28:33 --> Helper loaded: file_helper
INFO - 2018-02-17 12:28:33 --> Helper loaded: email_helper
INFO - 2018-02-17 12:28:33 --> Helper loaded: common_helper
INFO - 2018-02-17 12:28:33 --> Database Driver Class Initialized
DEBUG - 2018-02-17 12:28:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-17 12:28:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-17 12:28:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-17 12:28:33 --> Pagination Class Initialized
INFO - 2018-02-17 12:28:33 --> Helper loaded: form_helper
INFO - 2018-02-17 12:28:33 --> Form Validation Class Initialized
INFO - 2018-02-17 12:28:33 --> Model Class Initialized
INFO - 2018-02-17 12:28:33 --> Controller Class Initialized
INFO - 2018-02-17 12:28:33 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-17 12:28:33 --> Model Class Initialized
INFO - 2018-02-17 12:28:33 --> Model Class Initialized
INFO - 2018-02-17 12:28:33 --> Model Class Initialized
INFO - 2018-02-17 12:28:35 --> Config Class Initialized
INFO - 2018-02-17 12:28:35 --> Hooks Class Initialized
DEBUG - 2018-02-17 12:28:35 --> UTF-8 Support Enabled
INFO - 2018-02-17 12:28:35 --> Utf8 Class Initialized
INFO - 2018-02-17 12:28:35 --> URI Class Initialized
INFO - 2018-02-17 12:28:35 --> Router Class Initialized
INFO - 2018-02-17 12:28:35 --> Output Class Initialized
INFO - 2018-02-17 12:28:35 --> Security Class Initialized
DEBUG - 2018-02-17 12:28:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-17 12:28:35 --> Input Class Initialized
INFO - 2018-02-17 12:28:35 --> Language Class Initialized
INFO - 2018-02-17 12:28:35 --> Loader Class Initialized
INFO - 2018-02-17 12:28:35 --> Helper loaded: url_helper
INFO - 2018-02-17 12:28:35 --> Helper loaded: file_helper
INFO - 2018-02-17 12:28:35 --> Helper loaded: email_helper
INFO - 2018-02-17 12:28:35 --> Helper loaded: common_helper
INFO - 2018-02-17 12:28:35 --> Database Driver Class Initialized
DEBUG - 2018-02-17 12:28:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-17 12:28:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-17 12:28:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-17 12:28:35 --> Pagination Class Initialized
INFO - 2018-02-17 12:28:35 --> Helper loaded: form_helper
INFO - 2018-02-17 12:28:35 --> Form Validation Class Initialized
INFO - 2018-02-17 12:28:35 --> Model Class Initialized
INFO - 2018-02-17 12:28:35 --> Controller Class Initialized
INFO - 2018-02-17 12:28:35 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-17 12:28:35 --> Model Class Initialized
INFO - 2018-02-17 12:28:35 --> Model Class Initialized
INFO - 2018-02-17 12:28:35 --> Model Class Initialized
INFO - 2018-02-17 12:28:37 --> Config Class Initialized
INFO - 2018-02-17 12:28:37 --> Hooks Class Initialized
DEBUG - 2018-02-17 12:28:37 --> UTF-8 Support Enabled
INFO - 2018-02-17 12:28:37 --> Utf8 Class Initialized
INFO - 2018-02-17 12:28:37 --> URI Class Initialized
INFO - 2018-02-17 12:28:37 --> Router Class Initialized
INFO - 2018-02-17 12:28:37 --> Output Class Initialized
INFO - 2018-02-17 12:28:37 --> Security Class Initialized
DEBUG - 2018-02-17 12:28:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-17 12:28:37 --> Input Class Initialized
INFO - 2018-02-17 12:28:37 --> Language Class Initialized
INFO - 2018-02-17 12:28:37 --> Loader Class Initialized
INFO - 2018-02-17 12:28:37 --> Helper loaded: url_helper
INFO - 2018-02-17 12:28:37 --> Helper loaded: file_helper
INFO - 2018-02-17 12:28:37 --> Helper loaded: email_helper
INFO - 2018-02-17 12:28:37 --> Helper loaded: common_helper
INFO - 2018-02-17 12:28:37 --> Database Driver Class Initialized
DEBUG - 2018-02-17 12:28:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-17 12:28:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-17 12:28:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-17 12:28:37 --> Pagination Class Initialized
INFO - 2018-02-17 12:28:37 --> Helper loaded: form_helper
INFO - 2018-02-17 12:28:37 --> Form Validation Class Initialized
INFO - 2018-02-17 12:28:37 --> Model Class Initialized
INFO - 2018-02-17 12:28:37 --> Controller Class Initialized
INFO - 2018-02-17 12:28:37 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-17 12:28:37 --> Model Class Initialized
INFO - 2018-02-17 12:28:37 --> Model Class Initialized
INFO - 2018-02-17 12:28:37 --> Model Class Initialized
INFO - 2018-02-17 12:28:48 --> Config Class Initialized
INFO - 2018-02-17 12:28:48 --> Hooks Class Initialized
DEBUG - 2018-02-17 12:28:48 --> UTF-8 Support Enabled
INFO - 2018-02-17 12:28:48 --> Utf8 Class Initialized
INFO - 2018-02-17 12:28:48 --> URI Class Initialized
INFO - 2018-02-17 12:28:48 --> Router Class Initialized
INFO - 2018-02-17 12:28:48 --> Output Class Initialized
INFO - 2018-02-17 12:28:48 --> Security Class Initialized
DEBUG - 2018-02-17 12:28:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-17 12:28:48 --> Input Class Initialized
INFO - 2018-02-17 12:28:48 --> Language Class Initialized
INFO - 2018-02-17 12:28:48 --> Loader Class Initialized
INFO - 2018-02-17 12:28:48 --> Helper loaded: url_helper
INFO - 2018-02-17 12:28:48 --> Helper loaded: file_helper
INFO - 2018-02-17 12:28:48 --> Helper loaded: email_helper
INFO - 2018-02-17 12:28:48 --> Helper loaded: common_helper
INFO - 2018-02-17 12:28:48 --> Database Driver Class Initialized
DEBUG - 2018-02-17 12:28:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-17 12:28:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-17 12:28:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-17 12:28:48 --> Pagination Class Initialized
INFO - 2018-02-17 12:28:48 --> Helper loaded: form_helper
INFO - 2018-02-17 12:28:48 --> Form Validation Class Initialized
INFO - 2018-02-17 12:28:48 --> Model Class Initialized
INFO - 2018-02-17 12:28:48 --> Controller Class Initialized
INFO - 2018-02-17 12:28:48 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-17 12:28:48 --> Model Class Initialized
INFO - 2018-02-17 12:28:48 --> Model Class Initialized
INFO - 2018-02-17 12:28:48 --> Model Class Initialized
INFO - 2018-02-17 12:28:48 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-17 12:28:48 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-17 12:28:48 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-17 12:28:48 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-17 12:28:48 --> File loaded: /var/www/html/project/radio/application/views/tracks/add_edit.php
INFO - 2018-02-17 12:28:48 --> Final output sent to browser
DEBUG - 2018-02-17 12:28:48 --> Total execution time: 0.0127
INFO - 2018-02-17 12:28:52 --> Config Class Initialized
INFO - 2018-02-17 12:28:52 --> Hooks Class Initialized
DEBUG - 2018-02-17 12:28:52 --> UTF-8 Support Enabled
INFO - 2018-02-17 12:28:52 --> Utf8 Class Initialized
INFO - 2018-02-17 12:28:52 --> URI Class Initialized
INFO - 2018-02-17 12:28:52 --> Router Class Initialized
INFO - 2018-02-17 12:28:52 --> Output Class Initialized
INFO - 2018-02-17 12:28:52 --> Security Class Initialized
DEBUG - 2018-02-17 12:28:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-17 12:28:52 --> Input Class Initialized
INFO - 2018-02-17 12:28:52 --> Language Class Initialized
INFO - 2018-02-17 12:28:52 --> Loader Class Initialized
INFO - 2018-02-17 12:28:52 --> Helper loaded: url_helper
INFO - 2018-02-17 12:28:52 --> Helper loaded: file_helper
INFO - 2018-02-17 12:28:52 --> Helper loaded: email_helper
INFO - 2018-02-17 12:28:52 --> Helper loaded: common_helper
INFO - 2018-02-17 12:28:52 --> Database Driver Class Initialized
DEBUG - 2018-02-17 12:28:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-17 12:28:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-17 12:28:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-17 12:28:52 --> Pagination Class Initialized
INFO - 2018-02-17 12:28:52 --> Helper loaded: form_helper
INFO - 2018-02-17 12:28:52 --> Form Validation Class Initialized
INFO - 2018-02-17 12:28:52 --> Model Class Initialized
INFO - 2018-02-17 12:28:52 --> Controller Class Initialized
INFO - 2018-02-17 12:28:52 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-17 12:28:52 --> Model Class Initialized
INFO - 2018-02-17 12:28:52 --> Model Class Initialized
INFO - 2018-02-17 12:28:52 --> Model Class Initialized
INFO - 2018-02-17 12:28:55 --> Config Class Initialized
INFO - 2018-02-17 12:28:55 --> Hooks Class Initialized
DEBUG - 2018-02-17 12:28:55 --> UTF-8 Support Enabled
INFO - 2018-02-17 12:28:55 --> Utf8 Class Initialized
INFO - 2018-02-17 12:28:55 --> URI Class Initialized
INFO - 2018-02-17 12:28:55 --> Router Class Initialized
INFO - 2018-02-17 12:28:55 --> Output Class Initialized
INFO - 2018-02-17 12:28:55 --> Security Class Initialized
DEBUG - 2018-02-17 12:28:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-17 12:28:55 --> Input Class Initialized
INFO - 2018-02-17 12:28:55 --> Language Class Initialized
INFO - 2018-02-17 12:28:55 --> Loader Class Initialized
INFO - 2018-02-17 12:28:55 --> Helper loaded: url_helper
INFO - 2018-02-17 12:28:55 --> Helper loaded: file_helper
INFO - 2018-02-17 12:28:55 --> Helper loaded: email_helper
INFO - 2018-02-17 12:28:55 --> Helper loaded: common_helper
INFO - 2018-02-17 12:28:55 --> Database Driver Class Initialized
DEBUG - 2018-02-17 12:28:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-17 12:28:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-17 12:28:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-17 12:28:55 --> Pagination Class Initialized
INFO - 2018-02-17 12:28:55 --> Helper loaded: form_helper
INFO - 2018-02-17 12:28:55 --> Form Validation Class Initialized
INFO - 2018-02-17 12:28:55 --> Model Class Initialized
INFO - 2018-02-17 12:28:55 --> Controller Class Initialized
INFO - 2018-02-17 12:28:55 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-17 12:28:55 --> Model Class Initialized
INFO - 2018-02-17 12:28:55 --> Model Class Initialized
INFO - 2018-02-17 12:28:55 --> Model Class Initialized
INFO - 2018-02-17 12:28:59 --> Config Class Initialized
INFO - 2018-02-17 12:28:59 --> Hooks Class Initialized
DEBUG - 2018-02-17 12:28:59 --> UTF-8 Support Enabled
INFO - 2018-02-17 12:28:59 --> Utf8 Class Initialized
INFO - 2018-02-17 12:28:59 --> URI Class Initialized
INFO - 2018-02-17 12:28:59 --> Router Class Initialized
INFO - 2018-02-17 12:28:59 --> Output Class Initialized
INFO - 2018-02-17 12:28:59 --> Security Class Initialized
DEBUG - 2018-02-17 12:28:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-17 12:28:59 --> Input Class Initialized
INFO - 2018-02-17 12:28:59 --> Language Class Initialized
INFO - 2018-02-17 12:28:59 --> Loader Class Initialized
INFO - 2018-02-17 12:28:59 --> Helper loaded: url_helper
INFO - 2018-02-17 12:28:59 --> Helper loaded: file_helper
INFO - 2018-02-17 12:28:59 --> Helper loaded: email_helper
INFO - 2018-02-17 12:28:59 --> Helper loaded: common_helper
INFO - 2018-02-17 12:28:59 --> Database Driver Class Initialized
DEBUG - 2018-02-17 12:28:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-17 12:28:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-17 12:28:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-17 12:28:59 --> Pagination Class Initialized
INFO - 2018-02-17 12:28:59 --> Helper loaded: form_helper
INFO - 2018-02-17 12:28:59 --> Form Validation Class Initialized
INFO - 2018-02-17 12:28:59 --> Model Class Initialized
INFO - 2018-02-17 12:28:59 --> Controller Class Initialized
INFO - 2018-02-17 12:28:59 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-17 12:28:59 --> Model Class Initialized
INFO - 2018-02-17 12:28:59 --> Model Class Initialized
INFO - 2018-02-17 12:28:59 --> Model Class Initialized
INFO - 2018-02-17 12:29:02 --> Config Class Initialized
INFO - 2018-02-17 12:29:02 --> Hooks Class Initialized
DEBUG - 2018-02-17 12:29:02 --> UTF-8 Support Enabled
INFO - 2018-02-17 12:29:02 --> Utf8 Class Initialized
INFO - 2018-02-17 12:29:02 --> URI Class Initialized
INFO - 2018-02-17 12:29:02 --> Router Class Initialized
INFO - 2018-02-17 12:29:02 --> Output Class Initialized
INFO - 2018-02-17 12:29:02 --> Security Class Initialized
DEBUG - 2018-02-17 12:29:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-17 12:29:02 --> Input Class Initialized
INFO - 2018-02-17 12:29:02 --> Language Class Initialized
INFO - 2018-02-17 12:29:02 --> Loader Class Initialized
INFO - 2018-02-17 12:29:02 --> Helper loaded: url_helper
INFO - 2018-02-17 12:29:02 --> Helper loaded: file_helper
INFO - 2018-02-17 12:29:02 --> Helper loaded: email_helper
INFO - 2018-02-17 12:29:02 --> Helper loaded: common_helper
INFO - 2018-02-17 12:29:02 --> Database Driver Class Initialized
DEBUG - 2018-02-17 12:29:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-17 12:29:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-17 12:29:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-17 12:29:02 --> Pagination Class Initialized
INFO - 2018-02-17 12:29:02 --> Helper loaded: form_helper
INFO - 2018-02-17 12:29:02 --> Form Validation Class Initialized
INFO - 2018-02-17 12:29:02 --> Model Class Initialized
INFO - 2018-02-17 12:29:02 --> Controller Class Initialized
INFO - 2018-02-17 12:29:02 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-17 12:29:02 --> Model Class Initialized
INFO - 2018-02-17 12:29:02 --> Model Class Initialized
INFO - 2018-02-17 12:29:02 --> Model Class Initialized
INFO - 2018-02-17 12:29:05 --> Config Class Initialized
INFO - 2018-02-17 12:29:05 --> Hooks Class Initialized
DEBUG - 2018-02-17 12:29:05 --> UTF-8 Support Enabled
INFO - 2018-02-17 12:29:05 --> Utf8 Class Initialized
INFO - 2018-02-17 12:29:05 --> URI Class Initialized
INFO - 2018-02-17 12:29:05 --> Router Class Initialized
INFO - 2018-02-17 12:29:05 --> Output Class Initialized
INFO - 2018-02-17 12:29:05 --> Security Class Initialized
DEBUG - 2018-02-17 12:29:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-17 12:29:05 --> Input Class Initialized
INFO - 2018-02-17 12:29:05 --> Language Class Initialized
INFO - 2018-02-17 12:29:05 --> Loader Class Initialized
INFO - 2018-02-17 12:29:05 --> Helper loaded: url_helper
INFO - 2018-02-17 12:29:05 --> Helper loaded: file_helper
INFO - 2018-02-17 12:29:05 --> Helper loaded: email_helper
INFO - 2018-02-17 12:29:05 --> Helper loaded: common_helper
INFO - 2018-02-17 12:29:05 --> Database Driver Class Initialized
DEBUG - 2018-02-17 12:29:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-17 12:29:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-17 12:29:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-17 12:29:05 --> Pagination Class Initialized
INFO - 2018-02-17 12:29:05 --> Helper loaded: form_helper
INFO - 2018-02-17 12:29:05 --> Form Validation Class Initialized
INFO - 2018-02-17 12:29:05 --> Model Class Initialized
INFO - 2018-02-17 12:29:05 --> Controller Class Initialized
INFO - 2018-02-17 12:29:05 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-17 12:29:05 --> Model Class Initialized
INFO - 2018-02-17 12:29:05 --> Model Class Initialized
INFO - 2018-02-17 12:29:05 --> Model Class Initialized
INFO - 2018-02-17 12:32:45 --> Config Class Initialized
INFO - 2018-02-17 12:32:45 --> Hooks Class Initialized
DEBUG - 2018-02-17 12:32:45 --> UTF-8 Support Enabled
INFO - 2018-02-17 12:32:45 --> Utf8 Class Initialized
INFO - 2018-02-17 12:32:45 --> URI Class Initialized
INFO - 2018-02-17 12:32:45 --> Router Class Initialized
INFO - 2018-02-17 12:32:45 --> Output Class Initialized
INFO - 2018-02-17 12:32:45 --> Security Class Initialized
DEBUG - 2018-02-17 12:32:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-17 12:32:45 --> Input Class Initialized
INFO - 2018-02-17 12:32:45 --> Language Class Initialized
INFO - 2018-02-17 12:32:45 --> Loader Class Initialized
INFO - 2018-02-17 12:32:45 --> Helper loaded: url_helper
INFO - 2018-02-17 12:32:45 --> Helper loaded: file_helper
INFO - 2018-02-17 12:32:45 --> Helper loaded: email_helper
INFO - 2018-02-17 12:32:45 --> Helper loaded: common_helper
INFO - 2018-02-17 12:32:45 --> Database Driver Class Initialized
DEBUG - 2018-02-17 12:32:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-17 12:32:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-17 12:32:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-17 12:32:45 --> Pagination Class Initialized
INFO - 2018-02-17 12:32:45 --> Helper loaded: form_helper
INFO - 2018-02-17 12:32:45 --> Form Validation Class Initialized
INFO - 2018-02-17 12:32:45 --> Model Class Initialized
INFO - 2018-02-17 12:32:45 --> Controller Class Initialized
INFO - 2018-02-17 12:32:45 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-17 12:32:45 --> Model Class Initialized
INFO - 2018-02-17 12:32:45 --> Model Class Initialized
INFO - 2018-02-17 12:32:45 --> Model Class Initialized
INFO - 2018-02-17 12:32:45 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-17 12:32:45 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-17 12:32:45 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-17 12:32:45 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-17 12:32:45 --> File loaded: /var/www/html/project/radio/application/views/tracks/add_edit.php
INFO - 2018-02-17 12:32:45 --> Final output sent to browser
DEBUG - 2018-02-17 12:32:45 --> Total execution time: 0.0106
INFO - 2018-02-17 12:32:54 --> Config Class Initialized
INFO - 2018-02-17 12:32:54 --> Hooks Class Initialized
DEBUG - 2018-02-17 12:32:54 --> UTF-8 Support Enabled
INFO - 2018-02-17 12:32:54 --> Utf8 Class Initialized
INFO - 2018-02-17 12:32:54 --> URI Class Initialized
INFO - 2018-02-17 12:32:54 --> Router Class Initialized
INFO - 2018-02-17 12:32:54 --> Output Class Initialized
INFO - 2018-02-17 12:32:54 --> Security Class Initialized
DEBUG - 2018-02-17 12:32:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-17 12:32:54 --> Input Class Initialized
INFO - 2018-02-17 12:32:54 --> Language Class Initialized
INFO - 2018-02-17 12:32:54 --> Loader Class Initialized
INFO - 2018-02-17 12:32:54 --> Helper loaded: url_helper
INFO - 2018-02-17 12:32:54 --> Helper loaded: file_helper
INFO - 2018-02-17 12:32:54 --> Helper loaded: email_helper
INFO - 2018-02-17 12:32:54 --> Helper loaded: common_helper
INFO - 2018-02-17 12:32:54 --> Database Driver Class Initialized
DEBUG - 2018-02-17 12:32:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-17 12:32:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-17 12:32:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-17 12:32:54 --> Pagination Class Initialized
INFO - 2018-02-17 12:32:54 --> Helper loaded: form_helper
INFO - 2018-02-17 12:32:54 --> Form Validation Class Initialized
INFO - 2018-02-17 12:32:54 --> Model Class Initialized
INFO - 2018-02-17 12:32:54 --> Controller Class Initialized
INFO - 2018-02-17 12:32:54 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-17 12:32:54 --> Model Class Initialized
INFO - 2018-02-17 12:32:54 --> Model Class Initialized
INFO - 2018-02-17 12:32:54 --> Model Class Initialized
INFO - 2018-02-17 12:35:26 --> Config Class Initialized
INFO - 2018-02-17 12:35:26 --> Hooks Class Initialized
DEBUG - 2018-02-17 12:35:26 --> UTF-8 Support Enabled
INFO - 2018-02-17 12:35:26 --> Utf8 Class Initialized
INFO - 2018-02-17 12:35:26 --> URI Class Initialized
INFO - 2018-02-17 12:35:26 --> Router Class Initialized
INFO - 2018-02-17 12:35:26 --> Output Class Initialized
INFO - 2018-02-17 12:35:26 --> Security Class Initialized
DEBUG - 2018-02-17 12:35:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-17 12:35:26 --> Input Class Initialized
INFO - 2018-02-17 12:35:26 --> Language Class Initialized
INFO - 2018-02-17 12:35:26 --> Loader Class Initialized
INFO - 2018-02-17 12:35:26 --> Helper loaded: url_helper
INFO - 2018-02-17 12:35:26 --> Helper loaded: file_helper
INFO - 2018-02-17 12:35:26 --> Helper loaded: email_helper
INFO - 2018-02-17 12:35:26 --> Helper loaded: common_helper
INFO - 2018-02-17 12:35:26 --> Database Driver Class Initialized
DEBUG - 2018-02-17 12:35:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-17 12:35:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-17 12:35:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-17 12:35:26 --> Pagination Class Initialized
INFO - 2018-02-17 12:35:26 --> Helper loaded: form_helper
INFO - 2018-02-17 12:35:26 --> Form Validation Class Initialized
INFO - 2018-02-17 12:35:26 --> Model Class Initialized
INFO - 2018-02-17 12:35:26 --> Controller Class Initialized
INFO - 2018-02-17 12:35:26 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-17 12:35:26 --> Model Class Initialized
INFO - 2018-02-17 12:35:26 --> Model Class Initialized
INFO - 2018-02-17 12:35:26 --> Model Class Initialized
INFO - 2018-02-17 12:35:26 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-17 12:35:26 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-17 12:35:26 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-17 12:35:26 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-17 12:35:26 --> File loaded: /var/www/html/project/radio/application/views/tracks/add_edit.php
INFO - 2018-02-17 12:35:26 --> Final output sent to browser
DEBUG - 2018-02-17 12:35:26 --> Total execution time: 0.0111
INFO - 2018-02-17 12:35:45 --> Config Class Initialized
INFO - 2018-02-17 12:35:45 --> Hooks Class Initialized
DEBUG - 2018-02-17 12:35:45 --> UTF-8 Support Enabled
INFO - 2018-02-17 12:35:45 --> Utf8 Class Initialized
INFO - 2018-02-17 12:35:45 --> URI Class Initialized
INFO - 2018-02-17 12:35:45 --> Router Class Initialized
INFO - 2018-02-17 12:35:45 --> Output Class Initialized
INFO - 2018-02-17 12:35:45 --> Security Class Initialized
DEBUG - 2018-02-17 12:35:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-17 12:35:45 --> Input Class Initialized
INFO - 2018-02-17 12:35:45 --> Language Class Initialized
INFO - 2018-02-17 12:35:45 --> Loader Class Initialized
INFO - 2018-02-17 12:35:45 --> Helper loaded: url_helper
INFO - 2018-02-17 12:35:45 --> Helper loaded: file_helper
INFO - 2018-02-17 12:35:45 --> Helper loaded: email_helper
INFO - 2018-02-17 12:35:45 --> Helper loaded: common_helper
INFO - 2018-02-17 12:35:45 --> Database Driver Class Initialized
DEBUG - 2018-02-17 12:35:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-17 12:35:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-17 12:35:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-17 12:35:45 --> Pagination Class Initialized
INFO - 2018-02-17 12:35:45 --> Helper loaded: form_helper
INFO - 2018-02-17 12:35:45 --> Form Validation Class Initialized
INFO - 2018-02-17 12:35:45 --> Model Class Initialized
INFO - 2018-02-17 12:35:45 --> Controller Class Initialized
INFO - 2018-02-17 12:35:45 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-17 12:35:45 --> Model Class Initialized
INFO - 2018-02-17 12:35:45 --> Model Class Initialized
INFO - 2018-02-17 12:35:45 --> Model Class Initialized
INFO - 2018-02-17 12:35:45 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-17 12:35:45 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-17 12:35:45 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-17 12:35:45 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-17 12:35:45 --> File loaded: /var/www/html/project/radio/application/views/tracks/add_edit.php
INFO - 2018-02-17 12:35:45 --> Final output sent to browser
DEBUG - 2018-02-17 12:35:45 --> Total execution time: 0.0112
INFO - 2018-02-17 12:35:51 --> Config Class Initialized
INFO - 2018-02-17 12:35:51 --> Hooks Class Initialized
DEBUG - 2018-02-17 12:35:51 --> UTF-8 Support Enabled
INFO - 2018-02-17 12:35:51 --> Utf8 Class Initialized
INFO - 2018-02-17 12:35:51 --> URI Class Initialized
INFO - 2018-02-17 12:35:51 --> Router Class Initialized
INFO - 2018-02-17 12:35:51 --> Output Class Initialized
INFO - 2018-02-17 12:35:51 --> Security Class Initialized
DEBUG - 2018-02-17 12:35:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-17 12:35:51 --> Input Class Initialized
INFO - 2018-02-17 12:35:51 --> Language Class Initialized
INFO - 2018-02-17 12:35:51 --> Loader Class Initialized
INFO - 2018-02-17 12:35:51 --> Helper loaded: url_helper
INFO - 2018-02-17 12:35:51 --> Helper loaded: file_helper
INFO - 2018-02-17 12:35:51 --> Helper loaded: email_helper
INFO - 2018-02-17 12:35:51 --> Helper loaded: common_helper
INFO - 2018-02-17 12:35:51 --> Database Driver Class Initialized
DEBUG - 2018-02-17 12:35:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-17 12:35:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-17 12:35:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-17 12:35:51 --> Pagination Class Initialized
INFO - 2018-02-17 12:35:51 --> Helper loaded: form_helper
INFO - 2018-02-17 12:35:51 --> Form Validation Class Initialized
INFO - 2018-02-17 12:35:51 --> Model Class Initialized
INFO - 2018-02-17 12:35:51 --> Controller Class Initialized
INFO - 2018-02-17 12:35:51 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-17 12:35:51 --> Model Class Initialized
INFO - 2018-02-17 12:35:51 --> Model Class Initialized
INFO - 2018-02-17 12:35:51 --> Model Class Initialized
INFO - 2018-02-17 12:35:55 --> Config Class Initialized
INFO - 2018-02-17 12:35:55 --> Hooks Class Initialized
DEBUG - 2018-02-17 12:35:55 --> UTF-8 Support Enabled
INFO - 2018-02-17 12:35:55 --> Utf8 Class Initialized
INFO - 2018-02-17 12:35:55 --> URI Class Initialized
INFO - 2018-02-17 12:35:55 --> Router Class Initialized
INFO - 2018-02-17 12:35:55 --> Output Class Initialized
INFO - 2018-02-17 12:35:55 --> Security Class Initialized
DEBUG - 2018-02-17 12:35:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-17 12:35:55 --> Input Class Initialized
INFO - 2018-02-17 12:35:55 --> Language Class Initialized
INFO - 2018-02-17 12:35:55 --> Loader Class Initialized
INFO - 2018-02-17 12:35:55 --> Helper loaded: url_helper
INFO - 2018-02-17 12:35:55 --> Helper loaded: file_helper
INFO - 2018-02-17 12:35:55 --> Helper loaded: email_helper
INFO - 2018-02-17 12:35:55 --> Helper loaded: common_helper
INFO - 2018-02-17 12:35:55 --> Database Driver Class Initialized
DEBUG - 2018-02-17 12:35:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-17 12:35:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-17 12:35:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-17 12:35:55 --> Pagination Class Initialized
INFO - 2018-02-17 12:35:55 --> Helper loaded: form_helper
INFO - 2018-02-17 12:35:55 --> Form Validation Class Initialized
INFO - 2018-02-17 12:35:55 --> Model Class Initialized
INFO - 2018-02-17 12:35:55 --> Controller Class Initialized
INFO - 2018-02-17 12:35:55 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-17 12:35:55 --> Model Class Initialized
INFO - 2018-02-17 12:35:55 --> Model Class Initialized
INFO - 2018-02-17 12:35:55 --> Model Class Initialized
INFO - 2018-02-17 12:35:59 --> Config Class Initialized
INFO - 2018-02-17 12:35:59 --> Hooks Class Initialized
DEBUG - 2018-02-17 12:35:59 --> UTF-8 Support Enabled
INFO - 2018-02-17 12:35:59 --> Utf8 Class Initialized
INFO - 2018-02-17 12:35:59 --> URI Class Initialized
INFO - 2018-02-17 12:35:59 --> Router Class Initialized
INFO - 2018-02-17 12:35:59 --> Output Class Initialized
INFO - 2018-02-17 12:35:59 --> Security Class Initialized
DEBUG - 2018-02-17 12:35:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-17 12:35:59 --> Input Class Initialized
INFO - 2018-02-17 12:35:59 --> Language Class Initialized
INFO - 2018-02-17 12:35:59 --> Loader Class Initialized
INFO - 2018-02-17 12:35:59 --> Helper loaded: url_helper
INFO - 2018-02-17 12:35:59 --> Helper loaded: file_helper
INFO - 2018-02-17 12:35:59 --> Helper loaded: email_helper
INFO - 2018-02-17 12:35:59 --> Helper loaded: common_helper
INFO - 2018-02-17 12:35:59 --> Database Driver Class Initialized
DEBUG - 2018-02-17 12:35:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-17 12:35:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-17 12:35:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-17 12:35:59 --> Pagination Class Initialized
INFO - 2018-02-17 12:35:59 --> Helper loaded: form_helper
INFO - 2018-02-17 12:35:59 --> Form Validation Class Initialized
INFO - 2018-02-17 12:35:59 --> Model Class Initialized
INFO - 2018-02-17 12:35:59 --> Controller Class Initialized
INFO - 2018-02-17 12:35:59 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-17 12:35:59 --> Model Class Initialized
INFO - 2018-02-17 12:35:59 --> Model Class Initialized
INFO - 2018-02-17 12:35:59 --> Model Class Initialized
INFO - 2018-02-17 12:39:25 --> Config Class Initialized
INFO - 2018-02-17 12:39:25 --> Hooks Class Initialized
DEBUG - 2018-02-17 12:39:25 --> UTF-8 Support Enabled
INFO - 2018-02-17 12:39:25 --> Utf8 Class Initialized
INFO - 2018-02-17 12:39:25 --> URI Class Initialized
INFO - 2018-02-17 12:39:25 --> Router Class Initialized
INFO - 2018-02-17 12:39:25 --> Output Class Initialized
INFO - 2018-02-17 12:39:25 --> Security Class Initialized
DEBUG - 2018-02-17 12:39:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-17 12:39:25 --> Input Class Initialized
INFO - 2018-02-17 12:39:25 --> Language Class Initialized
INFO - 2018-02-17 12:39:25 --> Loader Class Initialized
INFO - 2018-02-17 12:39:25 --> Helper loaded: url_helper
INFO - 2018-02-17 12:39:25 --> Helper loaded: file_helper
INFO - 2018-02-17 12:39:25 --> Helper loaded: email_helper
INFO - 2018-02-17 12:39:25 --> Helper loaded: common_helper
INFO - 2018-02-17 12:39:25 --> Database Driver Class Initialized
DEBUG - 2018-02-17 12:39:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-17 12:39:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-17 12:39:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-17 12:39:25 --> Pagination Class Initialized
INFO - 2018-02-17 12:39:25 --> Helper loaded: form_helper
INFO - 2018-02-17 12:39:25 --> Form Validation Class Initialized
INFO - 2018-02-17 12:39:25 --> Model Class Initialized
INFO - 2018-02-17 12:39:25 --> Controller Class Initialized
INFO - 2018-02-17 12:39:25 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-17 12:39:25 --> Model Class Initialized
INFO - 2018-02-17 12:39:25 --> Model Class Initialized
INFO - 2018-02-17 12:39:25 --> Model Class Initialized
INFO - 2018-02-17 12:39:36 --> Config Class Initialized
INFO - 2018-02-17 12:39:36 --> Hooks Class Initialized
DEBUG - 2018-02-17 12:39:36 --> UTF-8 Support Enabled
INFO - 2018-02-17 12:39:36 --> Utf8 Class Initialized
INFO - 2018-02-17 12:39:36 --> URI Class Initialized
INFO - 2018-02-17 12:39:36 --> Router Class Initialized
INFO - 2018-02-17 12:39:36 --> Output Class Initialized
INFO - 2018-02-17 12:39:36 --> Security Class Initialized
DEBUG - 2018-02-17 12:39:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-17 12:39:36 --> Input Class Initialized
INFO - 2018-02-17 12:39:36 --> Language Class Initialized
INFO - 2018-02-17 12:39:36 --> Loader Class Initialized
INFO - 2018-02-17 12:39:36 --> Helper loaded: url_helper
INFO - 2018-02-17 12:39:36 --> Helper loaded: file_helper
INFO - 2018-02-17 12:39:36 --> Helper loaded: email_helper
INFO - 2018-02-17 12:39:36 --> Helper loaded: common_helper
INFO - 2018-02-17 12:39:36 --> Database Driver Class Initialized
DEBUG - 2018-02-17 12:39:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-17 12:39:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-17 12:39:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-17 12:39:36 --> Pagination Class Initialized
INFO - 2018-02-17 12:39:36 --> Helper loaded: form_helper
INFO - 2018-02-17 12:39:36 --> Form Validation Class Initialized
INFO - 2018-02-17 12:39:36 --> Model Class Initialized
INFO - 2018-02-17 12:39:36 --> Controller Class Initialized
INFO - 2018-02-17 12:39:36 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-17 12:39:36 --> Model Class Initialized
INFO - 2018-02-17 12:39:36 --> Model Class Initialized
INFO - 2018-02-17 12:39:36 --> Model Class Initialized
INFO - 2018-02-17 12:41:04 --> Config Class Initialized
INFO - 2018-02-17 12:41:04 --> Hooks Class Initialized
DEBUG - 2018-02-17 12:41:04 --> UTF-8 Support Enabled
INFO - 2018-02-17 12:41:04 --> Utf8 Class Initialized
INFO - 2018-02-17 12:41:04 --> URI Class Initialized
INFO - 2018-02-17 12:41:04 --> Router Class Initialized
INFO - 2018-02-17 12:41:04 --> Output Class Initialized
INFO - 2018-02-17 12:41:04 --> Security Class Initialized
DEBUG - 2018-02-17 12:41:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-17 12:41:04 --> Input Class Initialized
INFO - 2018-02-17 12:41:04 --> Language Class Initialized
INFO - 2018-02-17 12:41:04 --> Loader Class Initialized
INFO - 2018-02-17 12:41:04 --> Helper loaded: url_helper
INFO - 2018-02-17 12:41:04 --> Helper loaded: file_helper
INFO - 2018-02-17 12:41:04 --> Helper loaded: email_helper
INFO - 2018-02-17 12:41:04 --> Helper loaded: common_helper
INFO - 2018-02-17 12:41:04 --> Database Driver Class Initialized
DEBUG - 2018-02-17 12:41:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-17 12:41:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-17 12:41:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-17 12:41:04 --> Pagination Class Initialized
INFO - 2018-02-17 12:41:04 --> Helper loaded: form_helper
INFO - 2018-02-17 12:41:04 --> Form Validation Class Initialized
INFO - 2018-02-17 12:41:04 --> Model Class Initialized
INFO - 2018-02-17 12:41:04 --> Controller Class Initialized
INFO - 2018-02-17 12:41:04 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-17 12:41:04 --> Model Class Initialized
INFO - 2018-02-17 12:41:04 --> Model Class Initialized
INFO - 2018-02-17 12:41:04 --> Model Class Initialized
INFO - 2018-02-17 12:41:04 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-17 12:41:04 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-17 12:41:04 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-17 12:41:04 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-17 12:41:04 --> File loaded: /var/www/html/project/radio/application/views/tracks/add_edit.php
INFO - 2018-02-17 12:41:04 --> Final output sent to browser
DEBUG - 2018-02-17 12:41:04 --> Total execution time: 0.0154
INFO - 2018-02-17 12:41:20 --> Config Class Initialized
INFO - 2018-02-17 12:41:20 --> Hooks Class Initialized
DEBUG - 2018-02-17 12:41:20 --> UTF-8 Support Enabled
INFO - 2018-02-17 12:41:20 --> Utf8 Class Initialized
INFO - 2018-02-17 12:41:20 --> URI Class Initialized
INFO - 2018-02-17 12:41:20 --> Router Class Initialized
INFO - 2018-02-17 12:41:20 --> Output Class Initialized
INFO - 2018-02-17 12:41:20 --> Security Class Initialized
DEBUG - 2018-02-17 12:41:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-17 12:41:20 --> Input Class Initialized
INFO - 2018-02-17 12:41:20 --> Language Class Initialized
INFO - 2018-02-17 12:41:20 --> Loader Class Initialized
INFO - 2018-02-17 12:41:20 --> Helper loaded: url_helper
INFO - 2018-02-17 12:41:20 --> Helper loaded: file_helper
INFO - 2018-02-17 12:41:20 --> Helper loaded: email_helper
INFO - 2018-02-17 12:41:20 --> Helper loaded: common_helper
INFO - 2018-02-17 12:41:20 --> Database Driver Class Initialized
DEBUG - 2018-02-17 12:41:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-17 12:41:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-17 12:41:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-17 12:41:20 --> Pagination Class Initialized
INFO - 2018-02-17 12:41:20 --> Helper loaded: form_helper
INFO - 2018-02-17 12:41:20 --> Form Validation Class Initialized
INFO - 2018-02-17 12:41:20 --> Model Class Initialized
INFO - 2018-02-17 12:41:20 --> Controller Class Initialized
INFO - 2018-02-17 12:41:20 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-17 12:41:20 --> Model Class Initialized
INFO - 2018-02-17 12:41:20 --> Model Class Initialized
INFO - 2018-02-17 12:41:20 --> Model Class Initialized
INFO - 2018-02-17 12:41:26 --> Config Class Initialized
INFO - 2018-02-17 12:41:26 --> Hooks Class Initialized
DEBUG - 2018-02-17 12:41:26 --> UTF-8 Support Enabled
INFO - 2018-02-17 12:41:26 --> Utf8 Class Initialized
INFO - 2018-02-17 12:41:26 --> URI Class Initialized
INFO - 2018-02-17 12:41:26 --> Router Class Initialized
INFO - 2018-02-17 12:41:26 --> Output Class Initialized
INFO - 2018-02-17 12:41:26 --> Security Class Initialized
DEBUG - 2018-02-17 12:41:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-17 12:41:26 --> Input Class Initialized
INFO - 2018-02-17 12:41:26 --> Language Class Initialized
INFO - 2018-02-17 12:41:26 --> Loader Class Initialized
INFO - 2018-02-17 12:41:26 --> Helper loaded: url_helper
INFO - 2018-02-17 12:41:26 --> Helper loaded: file_helper
INFO - 2018-02-17 12:41:26 --> Helper loaded: email_helper
INFO - 2018-02-17 12:41:26 --> Helper loaded: common_helper
INFO - 2018-02-17 12:41:26 --> Database Driver Class Initialized
DEBUG - 2018-02-17 12:41:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-17 12:41:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-17 12:41:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-17 12:41:26 --> Pagination Class Initialized
INFO - 2018-02-17 12:41:26 --> Helper loaded: form_helper
INFO - 2018-02-17 12:41:26 --> Form Validation Class Initialized
INFO - 2018-02-17 12:41:26 --> Model Class Initialized
INFO - 2018-02-17 12:41:26 --> Controller Class Initialized
INFO - 2018-02-17 12:41:26 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-17 12:41:26 --> Model Class Initialized
INFO - 2018-02-17 12:41:26 --> Model Class Initialized
INFO - 2018-02-17 12:41:26 --> Model Class Initialized
INFO - 2018-02-17 12:41:33 --> Config Class Initialized
INFO - 2018-02-17 12:41:33 --> Hooks Class Initialized
DEBUG - 2018-02-17 12:41:33 --> UTF-8 Support Enabled
INFO - 2018-02-17 12:41:33 --> Utf8 Class Initialized
INFO - 2018-02-17 12:41:33 --> URI Class Initialized
INFO - 2018-02-17 12:41:33 --> Router Class Initialized
INFO - 2018-02-17 12:41:33 --> Output Class Initialized
INFO - 2018-02-17 12:41:33 --> Security Class Initialized
DEBUG - 2018-02-17 12:41:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-17 12:41:33 --> Input Class Initialized
INFO - 2018-02-17 12:41:33 --> Language Class Initialized
INFO - 2018-02-17 12:41:33 --> Loader Class Initialized
INFO - 2018-02-17 12:41:33 --> Helper loaded: url_helper
INFO - 2018-02-17 12:41:33 --> Helper loaded: file_helper
INFO - 2018-02-17 12:41:33 --> Helper loaded: email_helper
INFO - 2018-02-17 12:41:33 --> Helper loaded: common_helper
INFO - 2018-02-17 12:41:33 --> Database Driver Class Initialized
DEBUG - 2018-02-17 12:41:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-17 12:41:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-17 12:41:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-17 12:41:33 --> Pagination Class Initialized
INFO - 2018-02-17 12:41:33 --> Helper loaded: form_helper
INFO - 2018-02-17 12:41:33 --> Form Validation Class Initialized
INFO - 2018-02-17 12:41:33 --> Model Class Initialized
INFO - 2018-02-17 12:41:33 --> Controller Class Initialized
INFO - 2018-02-17 12:41:33 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-17 12:41:33 --> Model Class Initialized
INFO - 2018-02-17 12:41:33 --> Model Class Initialized
INFO - 2018-02-17 12:41:33 --> Model Class Initialized
INFO - 2018-02-17 12:42:04 --> Config Class Initialized
INFO - 2018-02-17 12:42:04 --> Hooks Class Initialized
DEBUG - 2018-02-17 12:42:04 --> UTF-8 Support Enabled
INFO - 2018-02-17 12:42:04 --> Utf8 Class Initialized
INFO - 2018-02-17 12:42:04 --> URI Class Initialized
INFO - 2018-02-17 12:42:04 --> Router Class Initialized
INFO - 2018-02-17 12:42:04 --> Output Class Initialized
INFO - 2018-02-17 12:42:04 --> Security Class Initialized
DEBUG - 2018-02-17 12:42:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-17 12:42:04 --> Input Class Initialized
INFO - 2018-02-17 12:42:04 --> Language Class Initialized
INFO - 2018-02-17 12:42:04 --> Loader Class Initialized
INFO - 2018-02-17 12:42:04 --> Helper loaded: url_helper
INFO - 2018-02-17 12:42:04 --> Helper loaded: file_helper
INFO - 2018-02-17 12:42:04 --> Helper loaded: email_helper
INFO - 2018-02-17 12:42:04 --> Helper loaded: common_helper
INFO - 2018-02-17 12:42:04 --> Database Driver Class Initialized
DEBUG - 2018-02-17 12:42:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-17 12:42:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-17 12:42:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-17 12:42:04 --> Pagination Class Initialized
INFO - 2018-02-17 12:42:04 --> Helper loaded: form_helper
INFO - 2018-02-17 12:42:04 --> Form Validation Class Initialized
INFO - 2018-02-17 12:42:04 --> Model Class Initialized
INFO - 2018-02-17 12:42:04 --> Controller Class Initialized
INFO - 2018-02-17 12:42:04 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-17 12:42:04 --> Model Class Initialized
INFO - 2018-02-17 12:42:04 --> Model Class Initialized
INFO - 2018-02-17 12:42:04 --> Model Class Initialized
INFO - 2018-02-17 12:42:10 --> Config Class Initialized
INFO - 2018-02-17 12:42:10 --> Hooks Class Initialized
DEBUG - 2018-02-17 12:42:10 --> UTF-8 Support Enabled
INFO - 2018-02-17 12:42:10 --> Utf8 Class Initialized
INFO - 2018-02-17 12:42:10 --> URI Class Initialized
INFO - 2018-02-17 12:42:10 --> Router Class Initialized
INFO - 2018-02-17 12:42:10 --> Output Class Initialized
INFO - 2018-02-17 12:42:10 --> Security Class Initialized
DEBUG - 2018-02-17 12:42:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-17 12:42:10 --> Input Class Initialized
INFO - 2018-02-17 12:42:10 --> Language Class Initialized
INFO - 2018-02-17 12:42:10 --> Loader Class Initialized
INFO - 2018-02-17 12:42:10 --> Helper loaded: url_helper
INFO - 2018-02-17 12:42:10 --> Helper loaded: file_helper
INFO - 2018-02-17 12:42:10 --> Helper loaded: email_helper
INFO - 2018-02-17 12:42:10 --> Helper loaded: common_helper
INFO - 2018-02-17 12:42:10 --> Database Driver Class Initialized
DEBUG - 2018-02-17 12:42:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-17 12:42:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-17 12:42:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-17 12:42:10 --> Pagination Class Initialized
INFO - 2018-02-17 12:42:10 --> Helper loaded: form_helper
INFO - 2018-02-17 12:42:10 --> Form Validation Class Initialized
INFO - 2018-02-17 12:42:10 --> Model Class Initialized
INFO - 2018-02-17 12:42:10 --> Controller Class Initialized
INFO - 2018-02-17 12:42:10 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-17 12:42:10 --> Model Class Initialized
INFO - 2018-02-17 12:42:10 --> Model Class Initialized
INFO - 2018-02-17 12:42:10 --> Model Class Initialized
INFO - 2018-02-17 12:42:14 --> Config Class Initialized
INFO - 2018-02-17 12:42:14 --> Hooks Class Initialized
DEBUG - 2018-02-17 12:42:14 --> UTF-8 Support Enabled
INFO - 2018-02-17 12:42:14 --> Utf8 Class Initialized
INFO - 2018-02-17 12:42:14 --> URI Class Initialized
INFO - 2018-02-17 12:42:14 --> Router Class Initialized
INFO - 2018-02-17 12:42:14 --> Output Class Initialized
INFO - 2018-02-17 12:42:14 --> Security Class Initialized
DEBUG - 2018-02-17 12:42:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-17 12:42:14 --> Input Class Initialized
INFO - 2018-02-17 12:42:14 --> Language Class Initialized
INFO - 2018-02-17 12:42:14 --> Loader Class Initialized
INFO - 2018-02-17 12:42:14 --> Helper loaded: url_helper
INFO - 2018-02-17 12:42:14 --> Helper loaded: file_helper
INFO - 2018-02-17 12:42:14 --> Helper loaded: email_helper
INFO - 2018-02-17 12:42:14 --> Helper loaded: common_helper
INFO - 2018-02-17 12:42:14 --> Database Driver Class Initialized
DEBUG - 2018-02-17 12:42:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-17 12:42:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-17 12:42:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-17 12:42:14 --> Pagination Class Initialized
INFO - 2018-02-17 12:42:14 --> Helper loaded: form_helper
INFO - 2018-02-17 12:42:14 --> Form Validation Class Initialized
INFO - 2018-02-17 12:42:14 --> Model Class Initialized
INFO - 2018-02-17 12:42:14 --> Controller Class Initialized
INFO - 2018-02-17 12:42:14 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-17 12:42:14 --> Model Class Initialized
INFO - 2018-02-17 12:42:14 --> Model Class Initialized
INFO - 2018-02-17 12:42:14 --> Model Class Initialized
INFO - 2018-02-17 12:43:40 --> Config Class Initialized
INFO - 2018-02-17 12:43:40 --> Hooks Class Initialized
DEBUG - 2018-02-17 12:43:40 --> UTF-8 Support Enabled
INFO - 2018-02-17 12:43:40 --> Utf8 Class Initialized
INFO - 2018-02-17 12:43:40 --> URI Class Initialized
INFO - 2018-02-17 12:43:40 --> Router Class Initialized
INFO - 2018-02-17 12:43:40 --> Output Class Initialized
INFO - 2018-02-17 12:43:40 --> Security Class Initialized
DEBUG - 2018-02-17 12:43:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-17 12:43:40 --> Input Class Initialized
INFO - 2018-02-17 12:43:40 --> Language Class Initialized
INFO - 2018-02-17 12:43:40 --> Loader Class Initialized
INFO - 2018-02-17 12:43:40 --> Helper loaded: url_helper
INFO - 2018-02-17 12:43:40 --> Helper loaded: file_helper
INFO - 2018-02-17 12:43:40 --> Helper loaded: email_helper
INFO - 2018-02-17 12:43:40 --> Helper loaded: common_helper
INFO - 2018-02-17 12:43:40 --> Database Driver Class Initialized
DEBUG - 2018-02-17 12:43:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-17 12:43:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-17 12:43:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-17 12:43:40 --> Pagination Class Initialized
INFO - 2018-02-17 12:43:40 --> Helper loaded: form_helper
INFO - 2018-02-17 12:43:40 --> Form Validation Class Initialized
INFO - 2018-02-17 12:43:40 --> Model Class Initialized
INFO - 2018-02-17 12:43:40 --> Controller Class Initialized
INFO - 2018-02-17 12:43:40 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-17 12:43:40 --> Model Class Initialized
INFO - 2018-02-17 12:43:40 --> Model Class Initialized
INFO - 2018-02-17 12:43:40 --> Model Class Initialized
INFO - 2018-02-17 12:43:40 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-17 12:43:40 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-17 12:43:40 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-17 12:43:40 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-17 12:43:40 --> File loaded: /var/www/html/project/radio/application/views/tracks/add_edit.php
INFO - 2018-02-17 12:43:40 --> Final output sent to browser
DEBUG - 2018-02-17 12:43:40 --> Total execution time: 0.0094
INFO - 2018-02-17 12:47:04 --> Config Class Initialized
INFO - 2018-02-17 12:47:04 --> Hooks Class Initialized
DEBUG - 2018-02-17 12:47:04 --> UTF-8 Support Enabled
INFO - 2018-02-17 12:47:04 --> Utf8 Class Initialized
INFO - 2018-02-17 12:47:04 --> URI Class Initialized
INFO - 2018-02-17 12:47:04 --> Router Class Initialized
INFO - 2018-02-17 12:47:04 --> Output Class Initialized
INFO - 2018-02-17 12:47:04 --> Security Class Initialized
DEBUG - 2018-02-17 12:47:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-17 12:47:04 --> Input Class Initialized
INFO - 2018-02-17 12:47:04 --> Language Class Initialized
INFO - 2018-02-17 12:47:04 --> Loader Class Initialized
INFO - 2018-02-17 12:47:04 --> Helper loaded: url_helper
INFO - 2018-02-17 12:47:04 --> Helper loaded: file_helper
INFO - 2018-02-17 12:47:04 --> Helper loaded: email_helper
INFO - 2018-02-17 12:47:04 --> Helper loaded: common_helper
INFO - 2018-02-17 12:47:04 --> Database Driver Class Initialized
DEBUG - 2018-02-17 12:47:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-17 12:47:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-17 12:47:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-17 12:47:04 --> Pagination Class Initialized
INFO - 2018-02-17 12:47:04 --> Helper loaded: form_helper
INFO - 2018-02-17 12:47:04 --> Form Validation Class Initialized
INFO - 2018-02-17 12:47:04 --> Model Class Initialized
INFO - 2018-02-17 12:47:04 --> Controller Class Initialized
INFO - 2018-02-17 12:47:04 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-17 12:47:04 --> Model Class Initialized
INFO - 2018-02-17 12:47:04 --> Model Class Initialized
INFO - 2018-02-17 12:47:04 --> Model Class Initialized
INFO - 2018-02-17 12:47:04 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-17 12:47:04 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-17 12:47:04 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-17 12:47:04 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-17 12:47:04 --> File loaded: /var/www/html/project/radio/application/views/tracks/add_edit.php
INFO - 2018-02-17 12:47:04 --> Final output sent to browser
DEBUG - 2018-02-17 12:47:04 --> Total execution time: 0.0120
INFO - 2018-02-17 12:47:11 --> Config Class Initialized
INFO - 2018-02-17 12:47:11 --> Hooks Class Initialized
DEBUG - 2018-02-17 12:47:11 --> UTF-8 Support Enabled
INFO - 2018-02-17 12:47:11 --> Utf8 Class Initialized
INFO - 2018-02-17 12:47:11 --> URI Class Initialized
INFO - 2018-02-17 12:47:11 --> Router Class Initialized
INFO - 2018-02-17 12:47:11 --> Output Class Initialized
INFO - 2018-02-17 12:47:11 --> Security Class Initialized
DEBUG - 2018-02-17 12:47:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-17 12:47:11 --> Input Class Initialized
INFO - 2018-02-17 12:47:11 --> Language Class Initialized
INFO - 2018-02-17 12:47:11 --> Loader Class Initialized
INFO - 2018-02-17 12:47:11 --> Helper loaded: url_helper
INFO - 2018-02-17 12:47:11 --> Helper loaded: file_helper
INFO - 2018-02-17 12:47:11 --> Helper loaded: email_helper
INFO - 2018-02-17 12:47:11 --> Helper loaded: common_helper
INFO - 2018-02-17 12:47:11 --> Database Driver Class Initialized
DEBUG - 2018-02-17 12:47:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-17 12:47:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-17 12:47:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-17 12:47:11 --> Pagination Class Initialized
INFO - 2018-02-17 12:47:11 --> Helper loaded: form_helper
INFO - 2018-02-17 12:47:11 --> Form Validation Class Initialized
INFO - 2018-02-17 12:47:11 --> Model Class Initialized
INFO - 2018-02-17 12:47:11 --> Controller Class Initialized
INFO - 2018-02-17 12:47:11 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-17 12:47:11 --> Model Class Initialized
INFO - 2018-02-17 12:47:11 --> Model Class Initialized
INFO - 2018-02-17 12:47:11 --> Model Class Initialized
INFO - 2018-02-17 12:47:56 --> Config Class Initialized
INFO - 2018-02-17 12:47:56 --> Hooks Class Initialized
DEBUG - 2018-02-17 12:47:56 --> UTF-8 Support Enabled
INFO - 2018-02-17 12:47:56 --> Utf8 Class Initialized
INFO - 2018-02-17 12:47:56 --> URI Class Initialized
INFO - 2018-02-17 12:47:56 --> Router Class Initialized
INFO - 2018-02-17 12:47:56 --> Output Class Initialized
INFO - 2018-02-17 12:47:56 --> Security Class Initialized
DEBUG - 2018-02-17 12:47:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-17 12:47:56 --> Input Class Initialized
INFO - 2018-02-17 12:47:56 --> Language Class Initialized
INFO - 2018-02-17 12:47:56 --> Loader Class Initialized
INFO - 2018-02-17 12:47:56 --> Helper loaded: url_helper
INFO - 2018-02-17 12:47:56 --> Helper loaded: file_helper
INFO - 2018-02-17 12:47:56 --> Helper loaded: email_helper
INFO - 2018-02-17 12:47:56 --> Helper loaded: common_helper
INFO - 2018-02-17 12:47:56 --> Database Driver Class Initialized
DEBUG - 2018-02-17 12:47:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-17 12:47:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-17 12:47:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-17 12:47:56 --> Pagination Class Initialized
INFO - 2018-02-17 12:47:56 --> Helper loaded: form_helper
INFO - 2018-02-17 12:47:56 --> Form Validation Class Initialized
INFO - 2018-02-17 12:47:56 --> Model Class Initialized
INFO - 2018-02-17 12:47:56 --> Controller Class Initialized
INFO - 2018-02-17 12:47:56 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-17 12:47:56 --> Model Class Initialized
INFO - 2018-02-17 12:47:56 --> Model Class Initialized
INFO - 2018-02-17 12:47:56 --> Model Class Initialized
INFO - 2018-02-17 12:48:06 --> Config Class Initialized
INFO - 2018-02-17 12:48:06 --> Hooks Class Initialized
DEBUG - 2018-02-17 12:48:06 --> UTF-8 Support Enabled
INFO - 2018-02-17 12:48:06 --> Utf8 Class Initialized
INFO - 2018-02-17 12:48:06 --> URI Class Initialized
INFO - 2018-02-17 12:48:06 --> Router Class Initialized
INFO - 2018-02-17 12:48:06 --> Output Class Initialized
INFO - 2018-02-17 12:48:06 --> Security Class Initialized
DEBUG - 2018-02-17 12:48:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-17 12:48:06 --> Input Class Initialized
INFO - 2018-02-17 12:48:06 --> Language Class Initialized
INFO - 2018-02-17 12:48:06 --> Loader Class Initialized
INFO - 2018-02-17 12:48:06 --> Helper loaded: url_helper
INFO - 2018-02-17 12:48:06 --> Helper loaded: file_helper
INFO - 2018-02-17 12:48:06 --> Helper loaded: email_helper
INFO - 2018-02-17 12:48:06 --> Helper loaded: common_helper
INFO - 2018-02-17 12:48:06 --> Database Driver Class Initialized
DEBUG - 2018-02-17 12:48:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-17 12:48:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-17 12:48:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-17 12:48:06 --> Pagination Class Initialized
INFO - 2018-02-17 12:48:06 --> Helper loaded: form_helper
INFO - 2018-02-17 12:48:06 --> Form Validation Class Initialized
INFO - 2018-02-17 12:48:06 --> Model Class Initialized
INFO - 2018-02-17 12:48:06 --> Controller Class Initialized
INFO - 2018-02-17 12:48:06 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-17 12:48:06 --> Model Class Initialized
INFO - 2018-02-17 12:48:06 --> Model Class Initialized
INFO - 2018-02-17 12:48:06 --> Model Class Initialized
INFO - 2018-02-17 12:48:26 --> Config Class Initialized
INFO - 2018-02-17 12:48:26 --> Hooks Class Initialized
DEBUG - 2018-02-17 12:48:26 --> UTF-8 Support Enabled
INFO - 2018-02-17 12:48:26 --> Utf8 Class Initialized
INFO - 2018-02-17 12:48:26 --> URI Class Initialized
INFO - 2018-02-17 12:48:26 --> Router Class Initialized
INFO - 2018-02-17 12:48:26 --> Output Class Initialized
INFO - 2018-02-17 12:48:26 --> Security Class Initialized
DEBUG - 2018-02-17 12:48:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-17 12:48:26 --> Input Class Initialized
INFO - 2018-02-17 12:48:26 --> Language Class Initialized
INFO - 2018-02-17 12:48:26 --> Loader Class Initialized
INFO - 2018-02-17 12:48:26 --> Helper loaded: url_helper
INFO - 2018-02-17 12:48:26 --> Helper loaded: file_helper
INFO - 2018-02-17 12:48:26 --> Helper loaded: email_helper
INFO - 2018-02-17 12:48:26 --> Helper loaded: common_helper
INFO - 2018-02-17 12:48:26 --> Database Driver Class Initialized
DEBUG - 2018-02-17 12:48:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-17 12:48:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-17 12:48:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-17 12:48:26 --> Pagination Class Initialized
INFO - 2018-02-17 12:48:26 --> Helper loaded: form_helper
INFO - 2018-02-17 12:48:26 --> Form Validation Class Initialized
INFO - 2018-02-17 12:48:26 --> Model Class Initialized
INFO - 2018-02-17 12:48:26 --> Controller Class Initialized
INFO - 2018-02-17 12:48:26 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-17 12:48:26 --> Model Class Initialized
INFO - 2018-02-17 12:48:26 --> Model Class Initialized
INFO - 2018-02-17 12:48:26 --> Model Class Initialized
INFO - 2018-02-17 12:48:26 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-17 12:48:26 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-17 12:48:26 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-17 12:48:26 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-17 12:48:26 --> File loaded: /var/www/html/project/radio/application/views/tracks/add_edit.php
INFO - 2018-02-17 12:48:26 --> Final output sent to browser
DEBUG - 2018-02-17 12:48:26 --> Total execution time: 0.0139
INFO - 2018-02-17 12:48:29 --> Config Class Initialized
INFO - 2018-02-17 12:48:29 --> Hooks Class Initialized
DEBUG - 2018-02-17 12:48:29 --> UTF-8 Support Enabled
INFO - 2018-02-17 12:48:29 --> Utf8 Class Initialized
INFO - 2018-02-17 12:48:29 --> URI Class Initialized
INFO - 2018-02-17 12:48:29 --> Router Class Initialized
INFO - 2018-02-17 12:48:29 --> Output Class Initialized
INFO - 2018-02-17 12:48:29 --> Security Class Initialized
DEBUG - 2018-02-17 12:48:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-17 12:48:29 --> Input Class Initialized
INFO - 2018-02-17 12:48:29 --> Language Class Initialized
INFO - 2018-02-17 12:48:29 --> Loader Class Initialized
INFO - 2018-02-17 12:48:29 --> Helper loaded: url_helper
INFO - 2018-02-17 12:48:29 --> Helper loaded: file_helper
INFO - 2018-02-17 12:48:29 --> Helper loaded: email_helper
INFO - 2018-02-17 12:48:29 --> Helper loaded: common_helper
INFO - 2018-02-17 12:48:29 --> Database Driver Class Initialized
DEBUG - 2018-02-17 12:48:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-17 12:48:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-17 12:48:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-17 12:48:29 --> Pagination Class Initialized
INFO - 2018-02-17 12:48:29 --> Helper loaded: form_helper
INFO - 2018-02-17 12:48:29 --> Form Validation Class Initialized
INFO - 2018-02-17 12:48:29 --> Model Class Initialized
INFO - 2018-02-17 12:48:29 --> Controller Class Initialized
INFO - 2018-02-17 12:48:29 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-17 12:48:29 --> Model Class Initialized
INFO - 2018-02-17 12:48:29 --> Model Class Initialized
INFO - 2018-02-17 12:48:29 --> Model Class Initialized
INFO - 2018-02-17 12:48:34 --> Config Class Initialized
INFO - 2018-02-17 12:48:34 --> Hooks Class Initialized
DEBUG - 2018-02-17 12:48:34 --> UTF-8 Support Enabled
INFO - 2018-02-17 12:48:34 --> Utf8 Class Initialized
INFO - 2018-02-17 12:48:34 --> URI Class Initialized
INFO - 2018-02-17 12:48:34 --> Router Class Initialized
INFO - 2018-02-17 12:48:34 --> Output Class Initialized
INFO - 2018-02-17 12:48:34 --> Security Class Initialized
DEBUG - 2018-02-17 12:48:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-17 12:48:34 --> Input Class Initialized
INFO - 2018-02-17 12:48:34 --> Language Class Initialized
INFO - 2018-02-17 12:48:34 --> Loader Class Initialized
INFO - 2018-02-17 12:48:34 --> Helper loaded: url_helper
INFO - 2018-02-17 12:48:34 --> Helper loaded: file_helper
INFO - 2018-02-17 12:48:34 --> Helper loaded: email_helper
INFO - 2018-02-17 12:48:34 --> Helper loaded: common_helper
INFO - 2018-02-17 12:48:34 --> Database Driver Class Initialized
DEBUG - 2018-02-17 12:48:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-17 12:48:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-17 12:48:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-17 12:48:34 --> Pagination Class Initialized
INFO - 2018-02-17 12:48:34 --> Helper loaded: form_helper
INFO - 2018-02-17 12:48:34 --> Form Validation Class Initialized
INFO - 2018-02-17 12:48:34 --> Model Class Initialized
INFO - 2018-02-17 12:48:34 --> Controller Class Initialized
INFO - 2018-02-17 12:48:34 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-17 12:48:34 --> Model Class Initialized
INFO - 2018-02-17 12:48:34 --> Model Class Initialized
INFO - 2018-02-17 12:48:34 --> Model Class Initialized
INFO - 2018-02-17 12:48:51 --> Config Class Initialized
INFO - 2018-02-17 12:48:51 --> Hooks Class Initialized
DEBUG - 2018-02-17 12:48:51 --> UTF-8 Support Enabled
INFO - 2018-02-17 12:48:51 --> Utf8 Class Initialized
INFO - 2018-02-17 12:48:51 --> URI Class Initialized
INFO - 2018-02-17 12:48:51 --> Router Class Initialized
INFO - 2018-02-17 12:48:51 --> Output Class Initialized
INFO - 2018-02-17 12:48:51 --> Security Class Initialized
DEBUG - 2018-02-17 12:48:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-17 12:48:51 --> Input Class Initialized
INFO - 2018-02-17 12:48:51 --> Language Class Initialized
INFO - 2018-02-17 12:48:51 --> Loader Class Initialized
INFO - 2018-02-17 12:48:51 --> Helper loaded: url_helper
INFO - 2018-02-17 12:48:51 --> Helper loaded: file_helper
INFO - 2018-02-17 12:48:51 --> Helper loaded: email_helper
INFO - 2018-02-17 12:48:51 --> Helper loaded: common_helper
INFO - 2018-02-17 12:48:51 --> Database Driver Class Initialized
DEBUG - 2018-02-17 12:48:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-17 12:48:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-17 12:48:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-17 12:48:51 --> Pagination Class Initialized
INFO - 2018-02-17 12:48:51 --> Helper loaded: form_helper
INFO - 2018-02-17 12:48:51 --> Form Validation Class Initialized
INFO - 2018-02-17 12:48:51 --> Model Class Initialized
INFO - 2018-02-17 12:48:51 --> Controller Class Initialized
INFO - 2018-02-17 12:48:51 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-17 12:48:51 --> Model Class Initialized
INFO - 2018-02-17 12:48:51 --> Model Class Initialized
INFO - 2018-02-17 12:48:51 --> Model Class Initialized
INFO - 2018-02-17 12:48:51 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-17 12:48:51 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-17 12:48:51 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-17 12:48:51 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-17 12:48:51 --> File loaded: /var/www/html/project/radio/application/views/tracks/index.php
INFO - 2018-02-17 12:48:51 --> Final output sent to browser
DEBUG - 2018-02-17 12:48:51 --> Total execution time: 0.0042
INFO - 2018-02-17 12:48:52 --> Config Class Initialized
INFO - 2018-02-17 12:48:52 --> Hooks Class Initialized
DEBUG - 2018-02-17 12:48:52 --> UTF-8 Support Enabled
INFO - 2018-02-17 12:48:52 --> Utf8 Class Initialized
INFO - 2018-02-17 12:48:52 --> URI Class Initialized
INFO - 2018-02-17 12:48:52 --> Router Class Initialized
INFO - 2018-02-17 12:48:52 --> Output Class Initialized
INFO - 2018-02-17 12:48:52 --> Security Class Initialized
DEBUG - 2018-02-17 12:48:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-17 12:48:52 --> Input Class Initialized
INFO - 2018-02-17 12:48:52 --> Language Class Initialized
INFO - 2018-02-17 12:48:52 --> Loader Class Initialized
INFO - 2018-02-17 12:48:52 --> Helper loaded: url_helper
INFO - 2018-02-17 12:48:52 --> Helper loaded: file_helper
INFO - 2018-02-17 12:48:52 --> Helper loaded: email_helper
INFO - 2018-02-17 12:48:52 --> Helper loaded: common_helper
INFO - 2018-02-17 12:48:52 --> Database Driver Class Initialized
DEBUG - 2018-02-17 12:48:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-17 12:48:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-17 12:48:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-17 12:48:52 --> Pagination Class Initialized
INFO - 2018-02-17 12:48:52 --> Helper loaded: form_helper
INFO - 2018-02-17 12:48:52 --> Form Validation Class Initialized
INFO - 2018-02-17 12:48:52 --> Model Class Initialized
INFO - 2018-02-17 12:48:52 --> Controller Class Initialized
INFO - 2018-02-17 12:48:52 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-17 12:48:52 --> Model Class Initialized
INFO - 2018-02-17 12:48:52 --> Model Class Initialized
INFO - 2018-02-17 12:48:52 --> Model Class Initialized
INFO - 2018-02-17 12:48:56 --> Config Class Initialized
INFO - 2018-02-17 12:48:56 --> Hooks Class Initialized
DEBUG - 2018-02-17 12:48:56 --> UTF-8 Support Enabled
INFO - 2018-02-17 12:48:56 --> Utf8 Class Initialized
INFO - 2018-02-17 12:48:56 --> URI Class Initialized
INFO - 2018-02-17 12:48:56 --> Router Class Initialized
INFO - 2018-02-17 12:48:56 --> Output Class Initialized
INFO - 2018-02-17 12:48:56 --> Security Class Initialized
DEBUG - 2018-02-17 12:48:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-17 12:48:56 --> Input Class Initialized
INFO - 2018-02-17 12:48:56 --> Language Class Initialized
INFO - 2018-02-17 12:48:56 --> Loader Class Initialized
INFO - 2018-02-17 12:48:56 --> Helper loaded: url_helper
INFO - 2018-02-17 12:48:56 --> Helper loaded: file_helper
INFO - 2018-02-17 12:48:56 --> Helper loaded: email_helper
INFO - 2018-02-17 12:48:56 --> Helper loaded: common_helper
INFO - 2018-02-17 12:48:56 --> Database Driver Class Initialized
DEBUG - 2018-02-17 12:48:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-17 12:48:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-17 12:48:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-17 12:48:56 --> Pagination Class Initialized
INFO - 2018-02-17 12:48:56 --> Helper loaded: form_helper
INFO - 2018-02-17 12:48:56 --> Form Validation Class Initialized
INFO - 2018-02-17 12:48:56 --> Model Class Initialized
INFO - 2018-02-17 12:48:56 --> Controller Class Initialized
INFO - 2018-02-17 12:48:56 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-17 12:48:56 --> Model Class Initialized
INFO - 2018-02-17 12:48:56 --> Model Class Initialized
INFO - 2018-02-17 12:48:56 --> Model Class Initialized
INFO - 2018-02-17 12:48:56 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-17 12:48:56 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-17 12:48:56 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-17 12:48:56 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-17 12:48:56 --> File loaded: /var/www/html/project/radio/application/views/tracks/add_edit.php
INFO - 2018-02-17 12:48:56 --> Final output sent to browser
DEBUG - 2018-02-17 12:48:56 --> Total execution time: 0.0125
INFO - 2018-02-17 12:49:14 --> Config Class Initialized
INFO - 2018-02-17 12:49:14 --> Hooks Class Initialized
DEBUG - 2018-02-17 12:49:14 --> UTF-8 Support Enabled
INFO - 2018-02-17 12:49:14 --> Utf8 Class Initialized
INFO - 2018-02-17 12:49:14 --> URI Class Initialized
INFO - 2018-02-17 12:49:14 --> Router Class Initialized
INFO - 2018-02-17 12:49:14 --> Output Class Initialized
INFO - 2018-02-17 12:49:14 --> Security Class Initialized
DEBUG - 2018-02-17 12:49:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-17 12:49:14 --> Input Class Initialized
INFO - 2018-02-17 12:49:14 --> Language Class Initialized
INFO - 2018-02-17 12:49:14 --> Loader Class Initialized
INFO - 2018-02-17 12:49:14 --> Helper loaded: url_helper
INFO - 2018-02-17 12:49:14 --> Helper loaded: file_helper
INFO - 2018-02-17 12:49:14 --> Helper loaded: email_helper
INFO - 2018-02-17 12:49:14 --> Helper loaded: common_helper
INFO - 2018-02-17 12:49:14 --> Database Driver Class Initialized
DEBUG - 2018-02-17 12:49:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-17 12:49:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-17 12:49:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-17 12:49:14 --> Pagination Class Initialized
INFO - 2018-02-17 12:49:14 --> Helper loaded: form_helper
INFO - 2018-02-17 12:49:14 --> Form Validation Class Initialized
INFO - 2018-02-17 12:49:14 --> Model Class Initialized
INFO - 2018-02-17 12:49:14 --> Controller Class Initialized
INFO - 2018-02-17 12:49:14 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-17 12:49:14 --> Model Class Initialized
INFO - 2018-02-17 12:49:14 --> Model Class Initialized
INFO - 2018-02-17 12:49:14 --> Model Class Initialized
INFO - 2018-02-17 12:49:14 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-17 12:49:14 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-17 12:49:14 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-17 12:49:14 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-17 12:49:14 --> File loaded: /var/www/html/project/radio/application/views/tracks/index.php
INFO - 2018-02-17 12:49:14 --> Final output sent to browser
DEBUG - 2018-02-17 12:49:14 --> Total execution time: 0.0059
INFO - 2018-02-17 12:49:14 --> Config Class Initialized
INFO - 2018-02-17 12:49:14 --> Hooks Class Initialized
DEBUG - 2018-02-17 12:49:14 --> UTF-8 Support Enabled
INFO - 2018-02-17 12:49:14 --> Utf8 Class Initialized
INFO - 2018-02-17 12:49:14 --> URI Class Initialized
INFO - 2018-02-17 12:49:14 --> Router Class Initialized
INFO - 2018-02-17 12:49:14 --> Output Class Initialized
INFO - 2018-02-17 12:49:14 --> Security Class Initialized
DEBUG - 2018-02-17 12:49:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-17 12:49:14 --> Input Class Initialized
INFO - 2018-02-17 12:49:14 --> Language Class Initialized
INFO - 2018-02-17 12:49:14 --> Loader Class Initialized
INFO - 2018-02-17 12:49:14 --> Helper loaded: url_helper
INFO - 2018-02-17 12:49:14 --> Helper loaded: file_helper
INFO - 2018-02-17 12:49:14 --> Helper loaded: email_helper
INFO - 2018-02-17 12:49:14 --> Helper loaded: common_helper
INFO - 2018-02-17 12:49:14 --> Database Driver Class Initialized
DEBUG - 2018-02-17 12:49:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-17 12:49:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-17 12:49:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-17 12:49:14 --> Pagination Class Initialized
INFO - 2018-02-17 12:49:14 --> Helper loaded: form_helper
INFO - 2018-02-17 12:49:14 --> Form Validation Class Initialized
INFO - 2018-02-17 12:49:14 --> Model Class Initialized
INFO - 2018-02-17 12:49:14 --> Controller Class Initialized
INFO - 2018-02-17 12:49:14 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-17 12:49:14 --> Model Class Initialized
INFO - 2018-02-17 12:49:14 --> Model Class Initialized
INFO - 2018-02-17 12:49:14 --> Model Class Initialized
INFO - 2018-02-17 12:50:58 --> Config Class Initialized
INFO - 2018-02-17 12:50:58 --> Hooks Class Initialized
DEBUG - 2018-02-17 12:50:58 --> UTF-8 Support Enabled
INFO - 2018-02-17 12:50:58 --> Utf8 Class Initialized
INFO - 2018-02-17 12:50:58 --> URI Class Initialized
INFO - 2018-02-17 12:50:58 --> Router Class Initialized
INFO - 2018-02-17 12:50:58 --> Output Class Initialized
INFO - 2018-02-17 12:50:58 --> Security Class Initialized
DEBUG - 2018-02-17 12:50:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-17 12:50:58 --> Input Class Initialized
INFO - 2018-02-17 12:50:58 --> Language Class Initialized
INFO - 2018-02-17 12:50:58 --> Loader Class Initialized
INFO - 2018-02-17 12:50:58 --> Helper loaded: url_helper
INFO - 2018-02-17 12:50:58 --> Helper loaded: file_helper
INFO - 2018-02-17 12:50:58 --> Helper loaded: email_helper
INFO - 2018-02-17 12:50:58 --> Helper loaded: common_helper
INFO - 2018-02-17 12:50:58 --> Database Driver Class Initialized
DEBUG - 2018-02-17 12:50:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-17 12:50:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-17 12:50:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-17 12:50:58 --> Pagination Class Initialized
INFO - 2018-02-17 12:50:58 --> Helper loaded: form_helper
INFO - 2018-02-17 12:50:58 --> Form Validation Class Initialized
INFO - 2018-02-17 12:50:58 --> Model Class Initialized
INFO - 2018-02-17 12:50:58 --> Controller Class Initialized
INFO - 2018-02-17 12:50:58 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-17 12:50:58 --> Model Class Initialized
INFO - 2018-02-17 12:50:58 --> Model Class Initialized
INFO - 2018-02-17 12:50:58 --> Model Class Initialized
INFO - 2018-02-17 12:50:58 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-17 12:50:58 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-17 12:50:58 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-17 12:50:58 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-17 12:50:58 --> File loaded: /var/www/html/project/radio/application/views/tracks/add_edit.php
INFO - 2018-02-17 12:50:58 --> Final output sent to browser
DEBUG - 2018-02-17 12:50:58 --> Total execution time: 0.0141
INFO - 2018-02-17 12:51:02 --> Config Class Initialized
INFO - 2018-02-17 12:51:02 --> Hooks Class Initialized
DEBUG - 2018-02-17 12:51:02 --> UTF-8 Support Enabled
INFO - 2018-02-17 12:51:02 --> Utf8 Class Initialized
INFO - 2018-02-17 12:51:02 --> URI Class Initialized
INFO - 2018-02-17 12:51:02 --> Router Class Initialized
INFO - 2018-02-17 12:51:02 --> Output Class Initialized
INFO - 2018-02-17 12:51:02 --> Security Class Initialized
DEBUG - 2018-02-17 12:51:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-17 12:51:02 --> Input Class Initialized
INFO - 2018-02-17 12:51:02 --> Language Class Initialized
INFO - 2018-02-17 12:51:02 --> Loader Class Initialized
INFO - 2018-02-17 12:51:02 --> Helper loaded: url_helper
INFO - 2018-02-17 12:51:02 --> Helper loaded: file_helper
INFO - 2018-02-17 12:51:02 --> Helper loaded: email_helper
INFO - 2018-02-17 12:51:02 --> Helper loaded: common_helper
INFO - 2018-02-17 12:51:02 --> Database Driver Class Initialized
DEBUG - 2018-02-17 12:51:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-17 12:51:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-17 12:51:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-17 12:51:02 --> Pagination Class Initialized
INFO - 2018-02-17 12:51:02 --> Helper loaded: form_helper
INFO - 2018-02-17 12:51:02 --> Form Validation Class Initialized
INFO - 2018-02-17 12:51:02 --> Model Class Initialized
INFO - 2018-02-17 12:51:02 --> Controller Class Initialized
INFO - 2018-02-17 12:51:02 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-17 12:51:02 --> Model Class Initialized
INFO - 2018-02-17 12:51:02 --> Model Class Initialized
INFO - 2018-02-17 12:51:02 --> Model Class Initialized
INFO - 2018-02-17 12:51:02 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-17 12:51:02 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-17 12:51:02 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-17 12:51:02 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-17 12:51:02 --> File loaded: /var/www/html/project/radio/application/views/tracks/index.php
INFO - 2018-02-17 12:51:02 --> Final output sent to browser
DEBUG - 2018-02-17 12:51:02 --> Total execution time: 0.0078
INFO - 2018-02-17 12:51:03 --> Config Class Initialized
INFO - 2018-02-17 12:51:03 --> Hooks Class Initialized
DEBUG - 2018-02-17 12:51:03 --> UTF-8 Support Enabled
INFO - 2018-02-17 12:51:03 --> Utf8 Class Initialized
INFO - 2018-02-17 12:51:03 --> URI Class Initialized
INFO - 2018-02-17 12:51:03 --> Router Class Initialized
INFO - 2018-02-17 12:51:03 --> Output Class Initialized
INFO - 2018-02-17 12:51:03 --> Security Class Initialized
DEBUG - 2018-02-17 12:51:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-17 12:51:03 --> Input Class Initialized
INFO - 2018-02-17 12:51:03 --> Language Class Initialized
INFO - 2018-02-17 12:51:03 --> Loader Class Initialized
INFO - 2018-02-17 12:51:03 --> Helper loaded: url_helper
INFO - 2018-02-17 12:51:03 --> Helper loaded: file_helper
INFO - 2018-02-17 12:51:03 --> Helper loaded: email_helper
INFO - 2018-02-17 12:51:03 --> Helper loaded: common_helper
INFO - 2018-02-17 12:51:03 --> Database Driver Class Initialized
DEBUG - 2018-02-17 12:51:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-17 12:51:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-17 12:51:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-17 12:51:03 --> Pagination Class Initialized
INFO - 2018-02-17 12:51:03 --> Helper loaded: form_helper
INFO - 2018-02-17 12:51:03 --> Form Validation Class Initialized
INFO - 2018-02-17 12:51:03 --> Model Class Initialized
INFO - 2018-02-17 12:51:03 --> Controller Class Initialized
INFO - 2018-02-17 12:51:03 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-17 12:51:03 --> Model Class Initialized
INFO - 2018-02-17 12:51:03 --> Model Class Initialized
INFO - 2018-02-17 12:51:03 --> Model Class Initialized
INFO - 2018-02-17 12:51:08 --> Config Class Initialized
INFO - 2018-02-17 12:51:08 --> Hooks Class Initialized
DEBUG - 2018-02-17 12:51:08 --> UTF-8 Support Enabled
INFO - 2018-02-17 12:51:08 --> Utf8 Class Initialized
INFO - 2018-02-17 12:51:08 --> URI Class Initialized
INFO - 2018-02-17 12:51:08 --> Router Class Initialized
INFO - 2018-02-17 12:51:08 --> Output Class Initialized
INFO - 2018-02-17 12:51:08 --> Security Class Initialized
DEBUG - 2018-02-17 12:51:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-17 12:51:08 --> Input Class Initialized
INFO - 2018-02-17 12:51:08 --> Language Class Initialized
INFO - 2018-02-17 12:51:08 --> Loader Class Initialized
INFO - 2018-02-17 12:51:08 --> Helper loaded: url_helper
INFO - 2018-02-17 12:51:08 --> Helper loaded: file_helper
INFO - 2018-02-17 12:51:08 --> Helper loaded: email_helper
INFO - 2018-02-17 12:51:08 --> Helper loaded: common_helper
INFO - 2018-02-17 12:51:08 --> Database Driver Class Initialized
DEBUG - 2018-02-17 12:51:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-17 12:51:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-17 12:51:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-17 12:51:08 --> Pagination Class Initialized
INFO - 2018-02-17 12:51:08 --> Helper loaded: form_helper
INFO - 2018-02-17 12:51:08 --> Form Validation Class Initialized
INFO - 2018-02-17 12:51:08 --> Model Class Initialized
INFO - 2018-02-17 12:51:08 --> Controller Class Initialized
INFO - 2018-02-17 12:51:08 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-17 12:51:08 --> Model Class Initialized
INFO - 2018-02-17 12:51:08 --> Model Class Initialized
INFO - 2018-02-17 12:51:08 --> Model Class Initialized
INFO - 2018-02-17 12:51:08 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-17 12:51:08 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-17 12:51:08 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-17 12:51:08 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-17 12:51:08 --> File loaded: /var/www/html/project/radio/application/views/tracks/add_edit.php
INFO - 2018-02-17 12:51:08 --> Final output sent to browser
DEBUG - 2018-02-17 12:51:08 --> Total execution time: 0.0109
INFO - 2018-02-17 12:51:23 --> Config Class Initialized
INFO - 2018-02-17 12:51:23 --> Hooks Class Initialized
DEBUG - 2018-02-17 12:51:23 --> UTF-8 Support Enabled
INFO - 2018-02-17 12:51:23 --> Utf8 Class Initialized
INFO - 2018-02-17 12:51:23 --> URI Class Initialized
INFO - 2018-02-17 12:51:23 --> Router Class Initialized
INFO - 2018-02-17 12:51:23 --> Output Class Initialized
INFO - 2018-02-17 12:51:23 --> Security Class Initialized
DEBUG - 2018-02-17 12:51:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-17 12:51:23 --> Input Class Initialized
INFO - 2018-02-17 12:51:23 --> Language Class Initialized
INFO - 2018-02-17 12:51:23 --> Loader Class Initialized
INFO - 2018-02-17 12:51:23 --> Helper loaded: url_helper
INFO - 2018-02-17 12:51:23 --> Helper loaded: file_helper
INFO - 2018-02-17 12:51:23 --> Helper loaded: email_helper
INFO - 2018-02-17 12:51:23 --> Helper loaded: common_helper
INFO - 2018-02-17 12:51:23 --> Database Driver Class Initialized
DEBUG - 2018-02-17 12:51:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-17 12:51:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-17 12:51:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-17 12:51:23 --> Pagination Class Initialized
INFO - 2018-02-17 12:51:23 --> Helper loaded: form_helper
INFO - 2018-02-17 12:51:23 --> Form Validation Class Initialized
INFO - 2018-02-17 12:51:23 --> Model Class Initialized
INFO - 2018-02-17 12:51:23 --> Controller Class Initialized
INFO - 2018-02-17 12:51:23 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-17 12:51:23 --> Model Class Initialized
INFO - 2018-02-17 12:51:23 --> Model Class Initialized
INFO - 2018-02-17 12:51:23 --> Model Class Initialized
INFO - 2018-02-17 12:51:23 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-17 12:51:23 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-17 12:51:23 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-17 12:51:23 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-17 12:51:23 --> File loaded: /var/www/html/project/radio/application/views/tracks/add_edit.php
INFO - 2018-02-17 12:51:23 --> Final output sent to browser
DEBUG - 2018-02-17 12:51:23 --> Total execution time: 0.0112
INFO - 2018-02-17 12:51:40 --> Config Class Initialized
INFO - 2018-02-17 12:51:40 --> Hooks Class Initialized
DEBUG - 2018-02-17 12:51:40 --> UTF-8 Support Enabled
INFO - 2018-02-17 12:51:40 --> Utf8 Class Initialized
INFO - 2018-02-17 12:51:40 --> URI Class Initialized
INFO - 2018-02-17 12:51:40 --> Router Class Initialized
INFO - 2018-02-17 12:51:40 --> Output Class Initialized
INFO - 2018-02-17 12:51:40 --> Security Class Initialized
DEBUG - 2018-02-17 12:51:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-17 12:51:40 --> Input Class Initialized
INFO - 2018-02-17 12:51:40 --> Language Class Initialized
INFO - 2018-02-17 12:51:40 --> Loader Class Initialized
INFO - 2018-02-17 12:51:40 --> Helper loaded: url_helper
INFO - 2018-02-17 12:51:40 --> Helper loaded: file_helper
INFO - 2018-02-17 12:51:40 --> Helper loaded: email_helper
INFO - 2018-02-17 12:51:40 --> Helper loaded: common_helper
INFO - 2018-02-17 12:51:40 --> Database Driver Class Initialized
DEBUG - 2018-02-17 12:51:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-17 12:51:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-17 12:51:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-17 12:51:40 --> Pagination Class Initialized
INFO - 2018-02-17 12:51:40 --> Helper loaded: form_helper
INFO - 2018-02-17 12:51:40 --> Form Validation Class Initialized
INFO - 2018-02-17 12:51:40 --> Model Class Initialized
INFO - 2018-02-17 12:51:40 --> Controller Class Initialized
INFO - 2018-02-17 12:51:40 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-17 12:51:40 --> Model Class Initialized
INFO - 2018-02-17 12:51:40 --> Model Class Initialized
INFO - 2018-02-17 12:51:40 --> Model Class Initialized
INFO - 2018-02-17 12:51:40 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-17 12:51:40 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-17 12:51:40 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-17 12:51:40 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-17 12:51:40 --> File loaded: /var/www/html/project/radio/application/views/tracks/add_edit.php
INFO - 2018-02-17 12:51:40 --> Final output sent to browser
DEBUG - 2018-02-17 12:51:40 --> Total execution time: 0.0160
INFO - 2018-02-17 12:52:09 --> Config Class Initialized
INFO - 2018-02-17 12:52:09 --> Hooks Class Initialized
DEBUG - 2018-02-17 12:52:09 --> UTF-8 Support Enabled
INFO - 2018-02-17 12:52:09 --> Utf8 Class Initialized
INFO - 2018-02-17 12:52:09 --> URI Class Initialized
INFO - 2018-02-17 12:52:09 --> Router Class Initialized
INFO - 2018-02-17 12:52:09 --> Output Class Initialized
INFO - 2018-02-17 12:52:09 --> Security Class Initialized
DEBUG - 2018-02-17 12:52:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-17 12:52:09 --> Input Class Initialized
INFO - 2018-02-17 12:52:09 --> Language Class Initialized
INFO - 2018-02-17 12:52:09 --> Loader Class Initialized
INFO - 2018-02-17 12:52:09 --> Helper loaded: url_helper
INFO - 2018-02-17 12:52:09 --> Helper loaded: file_helper
INFO - 2018-02-17 12:52:09 --> Helper loaded: email_helper
INFO - 2018-02-17 12:52:09 --> Helper loaded: common_helper
INFO - 2018-02-17 12:52:09 --> Database Driver Class Initialized
DEBUG - 2018-02-17 12:52:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-17 12:52:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-17 12:52:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-17 12:52:09 --> Pagination Class Initialized
INFO - 2018-02-17 12:52:09 --> Helper loaded: form_helper
INFO - 2018-02-17 12:52:09 --> Form Validation Class Initialized
INFO - 2018-02-17 12:52:09 --> Model Class Initialized
INFO - 2018-02-17 12:52:09 --> Controller Class Initialized
INFO - 2018-02-17 12:52:09 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-17 12:52:09 --> Model Class Initialized
INFO - 2018-02-17 12:52:09 --> Model Class Initialized
INFO - 2018-02-17 12:52:09 --> Model Class Initialized
INFO - 2018-02-17 12:52:09 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-17 12:52:09 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-17 12:52:09 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-17 12:52:09 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-17 12:52:09 --> File loaded: /var/www/html/project/radio/application/views/tracks/add_edit.php
INFO - 2018-02-17 12:52:09 --> Final output sent to browser
DEBUG - 2018-02-17 12:52:09 --> Total execution time: 0.0152
INFO - 2018-02-17 12:52:23 --> Config Class Initialized
INFO - 2018-02-17 12:52:23 --> Hooks Class Initialized
DEBUG - 2018-02-17 12:52:23 --> UTF-8 Support Enabled
INFO - 2018-02-17 12:52:23 --> Utf8 Class Initialized
INFO - 2018-02-17 12:52:23 --> URI Class Initialized
INFO - 2018-02-17 12:52:23 --> Router Class Initialized
INFO - 2018-02-17 12:52:23 --> Output Class Initialized
INFO - 2018-02-17 12:52:23 --> Security Class Initialized
DEBUG - 2018-02-17 12:52:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-17 12:52:23 --> Input Class Initialized
INFO - 2018-02-17 12:52:23 --> Language Class Initialized
INFO - 2018-02-17 12:52:23 --> Loader Class Initialized
INFO - 2018-02-17 12:52:23 --> Helper loaded: url_helper
INFO - 2018-02-17 12:52:23 --> Helper loaded: file_helper
INFO - 2018-02-17 12:52:23 --> Helper loaded: email_helper
INFO - 2018-02-17 12:52:23 --> Helper loaded: common_helper
INFO - 2018-02-17 12:52:23 --> Database Driver Class Initialized
DEBUG - 2018-02-17 12:52:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-17 12:52:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-17 12:52:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-17 12:52:23 --> Pagination Class Initialized
INFO - 2018-02-17 12:52:23 --> Helper loaded: form_helper
INFO - 2018-02-17 12:52:23 --> Form Validation Class Initialized
INFO - 2018-02-17 12:52:23 --> Model Class Initialized
INFO - 2018-02-17 12:52:23 --> Controller Class Initialized
INFO - 2018-02-17 12:52:23 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-17 12:52:23 --> Model Class Initialized
INFO - 2018-02-17 12:52:23 --> Model Class Initialized
INFO - 2018-02-17 12:52:23 --> Model Class Initialized
INFO - 2018-02-17 12:52:23 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-17 12:52:23 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-17 12:52:23 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-17 12:52:23 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-17 12:52:23 --> File loaded: /var/www/html/project/radio/application/views/tracks/add_edit.php
INFO - 2018-02-17 12:52:23 --> Final output sent to browser
DEBUG - 2018-02-17 12:52:23 --> Total execution time: 0.0135
INFO - 2018-02-17 12:52:31 --> Config Class Initialized
INFO - 2018-02-17 12:52:31 --> Hooks Class Initialized
DEBUG - 2018-02-17 12:52:31 --> UTF-8 Support Enabled
INFO - 2018-02-17 12:52:31 --> Utf8 Class Initialized
INFO - 2018-02-17 12:52:31 --> URI Class Initialized
INFO - 2018-02-17 12:52:31 --> Router Class Initialized
INFO - 2018-02-17 12:52:31 --> Output Class Initialized
INFO - 2018-02-17 12:52:31 --> Security Class Initialized
DEBUG - 2018-02-17 12:52:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-17 12:52:31 --> Input Class Initialized
INFO - 2018-02-17 12:52:31 --> Language Class Initialized
INFO - 2018-02-17 12:52:31 --> Loader Class Initialized
INFO - 2018-02-17 12:52:31 --> Helper loaded: url_helper
INFO - 2018-02-17 12:52:31 --> Helper loaded: file_helper
INFO - 2018-02-17 12:52:31 --> Helper loaded: email_helper
INFO - 2018-02-17 12:52:31 --> Helper loaded: common_helper
INFO - 2018-02-17 12:52:31 --> Database Driver Class Initialized
DEBUG - 2018-02-17 12:52:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-17 12:52:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-17 12:52:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-17 12:52:31 --> Pagination Class Initialized
INFO - 2018-02-17 12:52:31 --> Helper loaded: form_helper
INFO - 2018-02-17 12:52:31 --> Form Validation Class Initialized
INFO - 2018-02-17 12:52:31 --> Model Class Initialized
INFO - 2018-02-17 12:52:31 --> Controller Class Initialized
INFO - 2018-02-17 12:52:31 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-17 12:52:31 --> Model Class Initialized
INFO - 2018-02-17 12:52:31 --> Model Class Initialized
INFO - 2018-02-17 12:52:31 --> Model Class Initialized
INFO - 2018-02-17 12:52:31 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-17 12:52:31 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-17 12:52:31 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-17 12:52:31 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-17 12:52:31 --> File loaded: /var/www/html/project/radio/application/views/tracks/add_edit.php
INFO - 2018-02-17 12:52:31 --> Final output sent to browser
DEBUG - 2018-02-17 12:52:31 --> Total execution time: 0.0119
INFO - 2018-02-17 12:53:44 --> Config Class Initialized
INFO - 2018-02-17 12:53:44 --> Hooks Class Initialized
DEBUG - 2018-02-17 12:53:44 --> UTF-8 Support Enabled
INFO - 2018-02-17 12:53:44 --> Utf8 Class Initialized
INFO - 2018-02-17 12:53:44 --> URI Class Initialized
INFO - 2018-02-17 12:53:44 --> Router Class Initialized
INFO - 2018-02-17 12:53:44 --> Output Class Initialized
INFO - 2018-02-17 12:53:44 --> Security Class Initialized
DEBUG - 2018-02-17 12:53:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-17 12:53:44 --> Input Class Initialized
INFO - 2018-02-17 12:53:44 --> Language Class Initialized
INFO - 2018-02-17 12:53:44 --> Loader Class Initialized
INFO - 2018-02-17 12:53:44 --> Helper loaded: url_helper
INFO - 2018-02-17 12:53:44 --> Helper loaded: file_helper
INFO - 2018-02-17 12:53:44 --> Helper loaded: email_helper
INFO - 2018-02-17 12:53:44 --> Helper loaded: common_helper
INFO - 2018-02-17 12:53:44 --> Database Driver Class Initialized
DEBUG - 2018-02-17 12:53:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-17 12:53:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-17 12:53:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-17 12:53:44 --> Pagination Class Initialized
INFO - 2018-02-17 12:53:44 --> Helper loaded: form_helper
INFO - 2018-02-17 12:53:44 --> Form Validation Class Initialized
INFO - 2018-02-17 12:53:44 --> Model Class Initialized
INFO - 2018-02-17 12:53:44 --> Controller Class Initialized
INFO - 2018-02-17 12:53:44 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-17 12:53:44 --> Model Class Initialized
INFO - 2018-02-17 12:53:44 --> Model Class Initialized
INFO - 2018-02-17 12:53:44 --> Model Class Initialized
INFO - 2018-02-17 12:53:44 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-17 12:53:44 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-17 12:53:44 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-17 12:53:44 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-17 12:53:44 --> File loaded: /var/www/html/project/radio/application/views/tracks/add_edit.php
INFO - 2018-02-17 12:53:44 --> Final output sent to browser
DEBUG - 2018-02-17 12:53:44 --> Total execution time: 0.0106
INFO - 2018-02-17 12:54:09 --> Config Class Initialized
INFO - 2018-02-17 12:54:09 --> Hooks Class Initialized
DEBUG - 2018-02-17 12:54:09 --> UTF-8 Support Enabled
INFO - 2018-02-17 12:54:09 --> Utf8 Class Initialized
INFO - 2018-02-17 12:54:09 --> URI Class Initialized
INFO - 2018-02-17 12:54:09 --> Router Class Initialized
INFO - 2018-02-17 12:54:09 --> Output Class Initialized
INFO - 2018-02-17 12:54:09 --> Security Class Initialized
DEBUG - 2018-02-17 12:54:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-17 12:54:09 --> Input Class Initialized
INFO - 2018-02-17 12:54:09 --> Language Class Initialized
INFO - 2018-02-17 12:54:09 --> Loader Class Initialized
INFO - 2018-02-17 12:54:09 --> Helper loaded: url_helper
INFO - 2018-02-17 12:54:09 --> Helper loaded: file_helper
INFO - 2018-02-17 12:54:09 --> Helper loaded: email_helper
INFO - 2018-02-17 12:54:09 --> Helper loaded: common_helper
INFO - 2018-02-17 12:54:09 --> Database Driver Class Initialized
DEBUG - 2018-02-17 12:54:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-17 12:54:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-17 12:54:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-17 12:54:09 --> Pagination Class Initialized
INFO - 2018-02-17 12:54:09 --> Helper loaded: form_helper
INFO - 2018-02-17 12:54:09 --> Form Validation Class Initialized
INFO - 2018-02-17 12:54:09 --> Model Class Initialized
INFO - 2018-02-17 12:54:09 --> Controller Class Initialized
INFO - 2018-02-17 12:54:09 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-17 12:54:09 --> Model Class Initialized
INFO - 2018-02-17 12:54:09 --> Model Class Initialized
INFO - 2018-02-17 12:54:09 --> Model Class Initialized
INFO - 2018-02-17 12:54:09 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-17 12:54:09 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-17 12:54:09 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-17 12:54:09 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-17 12:54:09 --> File loaded: /var/www/html/project/radio/application/views/tracks/add_edit.php
INFO - 2018-02-17 12:54:09 --> Final output sent to browser
DEBUG - 2018-02-17 12:54:09 --> Total execution time: 0.0102
INFO - 2018-02-17 12:54:20 --> Config Class Initialized
INFO - 2018-02-17 12:54:20 --> Hooks Class Initialized
DEBUG - 2018-02-17 12:54:20 --> UTF-8 Support Enabled
INFO - 2018-02-17 12:54:20 --> Utf8 Class Initialized
INFO - 2018-02-17 12:54:20 --> URI Class Initialized
INFO - 2018-02-17 12:54:20 --> Router Class Initialized
INFO - 2018-02-17 12:54:20 --> Output Class Initialized
INFO - 2018-02-17 12:54:20 --> Security Class Initialized
DEBUG - 2018-02-17 12:54:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-17 12:54:20 --> Input Class Initialized
INFO - 2018-02-17 12:54:20 --> Language Class Initialized
INFO - 2018-02-17 12:54:20 --> Loader Class Initialized
INFO - 2018-02-17 12:54:20 --> Helper loaded: url_helper
INFO - 2018-02-17 12:54:20 --> Helper loaded: file_helper
INFO - 2018-02-17 12:54:20 --> Helper loaded: email_helper
INFO - 2018-02-17 12:54:20 --> Helper loaded: common_helper
INFO - 2018-02-17 12:54:20 --> Database Driver Class Initialized
DEBUG - 2018-02-17 12:54:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-17 12:54:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-17 12:54:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-17 12:54:20 --> Pagination Class Initialized
INFO - 2018-02-17 12:54:20 --> Helper loaded: form_helper
INFO - 2018-02-17 12:54:20 --> Form Validation Class Initialized
INFO - 2018-02-17 12:54:20 --> Model Class Initialized
INFO - 2018-02-17 12:54:20 --> Controller Class Initialized
INFO - 2018-02-17 12:54:20 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-17 12:54:20 --> Model Class Initialized
INFO - 2018-02-17 12:54:20 --> Model Class Initialized
INFO - 2018-02-17 12:54:20 --> Model Class Initialized
INFO - 2018-02-17 12:54:20 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-17 12:54:20 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-17 12:54:20 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-17 12:54:20 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-17 12:54:20 --> File loaded: /var/www/html/project/radio/application/views/tracks/add_edit.php
INFO - 2018-02-17 12:54:20 --> Final output sent to browser
DEBUG - 2018-02-17 12:54:20 --> Total execution time: 0.0152
INFO - 2018-02-17 12:54:34 --> Config Class Initialized
INFO - 2018-02-17 12:54:34 --> Hooks Class Initialized
DEBUG - 2018-02-17 12:54:34 --> UTF-8 Support Enabled
INFO - 2018-02-17 12:54:34 --> Utf8 Class Initialized
INFO - 2018-02-17 12:54:34 --> URI Class Initialized
INFO - 2018-02-17 12:54:34 --> Router Class Initialized
INFO - 2018-02-17 12:54:34 --> Output Class Initialized
INFO - 2018-02-17 12:54:34 --> Security Class Initialized
DEBUG - 2018-02-17 12:54:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-17 12:54:34 --> Input Class Initialized
INFO - 2018-02-17 12:54:34 --> Language Class Initialized
INFO - 2018-02-17 12:54:34 --> Loader Class Initialized
INFO - 2018-02-17 12:54:34 --> Helper loaded: url_helper
INFO - 2018-02-17 12:54:34 --> Helper loaded: file_helper
INFO - 2018-02-17 12:54:34 --> Helper loaded: email_helper
INFO - 2018-02-17 12:54:34 --> Helper loaded: common_helper
INFO - 2018-02-17 12:54:34 --> Database Driver Class Initialized
DEBUG - 2018-02-17 12:54:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-17 12:54:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-17 12:54:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-17 12:54:34 --> Pagination Class Initialized
INFO - 2018-02-17 12:54:34 --> Helper loaded: form_helper
INFO - 2018-02-17 12:54:34 --> Form Validation Class Initialized
INFO - 2018-02-17 12:54:34 --> Model Class Initialized
INFO - 2018-02-17 12:54:34 --> Controller Class Initialized
INFO - 2018-02-17 12:54:34 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-17 12:54:34 --> Model Class Initialized
INFO - 2018-02-17 12:54:34 --> Model Class Initialized
INFO - 2018-02-17 12:54:34 --> Model Class Initialized
INFO - 2018-02-17 12:54:34 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-17 12:54:34 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-17 12:54:34 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-17 12:54:34 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-17 12:54:34 --> File loaded: /var/www/html/project/radio/application/views/tracks/add_edit.php
INFO - 2018-02-17 12:54:34 --> Final output sent to browser
DEBUG - 2018-02-17 12:54:34 --> Total execution time: 0.0105
INFO - 2018-02-17 12:54:37 --> Config Class Initialized
INFO - 2018-02-17 12:54:37 --> Hooks Class Initialized
DEBUG - 2018-02-17 12:54:37 --> UTF-8 Support Enabled
INFO - 2018-02-17 12:54:37 --> Utf8 Class Initialized
INFO - 2018-02-17 12:54:37 --> URI Class Initialized
INFO - 2018-02-17 12:54:37 --> Router Class Initialized
INFO - 2018-02-17 12:54:37 --> Output Class Initialized
INFO - 2018-02-17 12:54:37 --> Security Class Initialized
DEBUG - 2018-02-17 12:54:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-17 12:54:37 --> Input Class Initialized
INFO - 2018-02-17 12:54:37 --> Language Class Initialized
INFO - 2018-02-17 12:54:37 --> Loader Class Initialized
INFO - 2018-02-17 12:54:37 --> Helper loaded: url_helper
INFO - 2018-02-17 12:54:37 --> Helper loaded: file_helper
INFO - 2018-02-17 12:54:37 --> Helper loaded: email_helper
INFO - 2018-02-17 12:54:37 --> Helper loaded: common_helper
INFO - 2018-02-17 12:54:37 --> Database Driver Class Initialized
DEBUG - 2018-02-17 12:54:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-17 12:54:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-17 12:54:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-17 12:54:37 --> Pagination Class Initialized
INFO - 2018-02-17 12:54:37 --> Helper loaded: form_helper
INFO - 2018-02-17 12:54:37 --> Form Validation Class Initialized
INFO - 2018-02-17 12:54:37 --> Model Class Initialized
INFO - 2018-02-17 12:54:37 --> Controller Class Initialized
INFO - 2018-02-17 12:54:37 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-17 12:54:37 --> Model Class Initialized
INFO - 2018-02-17 12:54:37 --> Model Class Initialized
INFO - 2018-02-17 12:54:37 --> Model Class Initialized
INFO - 2018-02-17 12:54:37 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-17 12:54:37 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-17 12:54:37 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-17 12:54:37 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-17 12:54:37 --> File loaded: /var/www/html/project/radio/application/views/tracks/add_edit.php
INFO - 2018-02-17 12:54:37 --> Final output sent to browser
DEBUG - 2018-02-17 12:54:37 --> Total execution time: 0.0139
INFO - 2018-02-17 12:54:50 --> Config Class Initialized
INFO - 2018-02-17 12:54:50 --> Hooks Class Initialized
DEBUG - 2018-02-17 12:54:50 --> UTF-8 Support Enabled
INFO - 2018-02-17 12:54:50 --> Utf8 Class Initialized
INFO - 2018-02-17 12:54:50 --> URI Class Initialized
INFO - 2018-02-17 12:54:50 --> Router Class Initialized
INFO - 2018-02-17 12:54:50 --> Output Class Initialized
INFO - 2018-02-17 12:54:50 --> Security Class Initialized
DEBUG - 2018-02-17 12:54:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-17 12:54:50 --> Input Class Initialized
INFO - 2018-02-17 12:54:50 --> Language Class Initialized
INFO - 2018-02-17 12:54:50 --> Loader Class Initialized
INFO - 2018-02-17 12:54:50 --> Helper loaded: url_helper
INFO - 2018-02-17 12:54:50 --> Helper loaded: file_helper
INFO - 2018-02-17 12:54:50 --> Helper loaded: email_helper
INFO - 2018-02-17 12:54:50 --> Helper loaded: common_helper
INFO - 2018-02-17 12:54:50 --> Database Driver Class Initialized
DEBUG - 2018-02-17 12:54:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-17 12:54:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-17 12:54:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-17 12:54:50 --> Pagination Class Initialized
INFO - 2018-02-17 12:54:50 --> Helper loaded: form_helper
INFO - 2018-02-17 12:54:50 --> Form Validation Class Initialized
INFO - 2018-02-17 12:54:50 --> Model Class Initialized
INFO - 2018-02-17 12:54:50 --> Controller Class Initialized
INFO - 2018-02-17 12:54:50 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-17 12:54:50 --> Model Class Initialized
INFO - 2018-02-17 12:54:50 --> Model Class Initialized
INFO - 2018-02-17 12:54:50 --> Model Class Initialized
INFO - 2018-02-17 12:54:50 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-17 12:54:50 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-17 12:54:50 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-17 12:54:50 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-17 12:54:50 --> File loaded: /var/www/html/project/radio/application/views/tracks/add_edit.php
INFO - 2018-02-17 12:54:50 --> Final output sent to browser
DEBUG - 2018-02-17 12:54:50 --> Total execution time: 0.0123
INFO - 2018-02-17 12:54:56 --> Config Class Initialized
INFO - 2018-02-17 12:54:56 --> Hooks Class Initialized
DEBUG - 2018-02-17 12:54:56 --> UTF-8 Support Enabled
INFO - 2018-02-17 12:54:56 --> Utf8 Class Initialized
INFO - 2018-02-17 12:54:56 --> URI Class Initialized
INFO - 2018-02-17 12:54:56 --> Router Class Initialized
INFO - 2018-02-17 12:54:56 --> Output Class Initialized
INFO - 2018-02-17 12:54:56 --> Security Class Initialized
DEBUG - 2018-02-17 12:54:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-17 12:54:56 --> Input Class Initialized
INFO - 2018-02-17 12:54:56 --> Language Class Initialized
INFO - 2018-02-17 12:54:56 --> Loader Class Initialized
INFO - 2018-02-17 12:54:56 --> Helper loaded: url_helper
INFO - 2018-02-17 12:54:56 --> Helper loaded: file_helper
INFO - 2018-02-17 12:54:56 --> Helper loaded: email_helper
INFO - 2018-02-17 12:54:56 --> Helper loaded: common_helper
INFO - 2018-02-17 12:54:56 --> Database Driver Class Initialized
DEBUG - 2018-02-17 12:54:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-17 12:54:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-17 12:54:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-17 12:54:56 --> Pagination Class Initialized
INFO - 2018-02-17 12:54:56 --> Helper loaded: form_helper
INFO - 2018-02-17 12:54:56 --> Form Validation Class Initialized
INFO - 2018-02-17 12:54:56 --> Model Class Initialized
INFO - 2018-02-17 12:54:56 --> Controller Class Initialized
INFO - 2018-02-17 12:54:56 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-17 12:54:56 --> Model Class Initialized
INFO - 2018-02-17 12:54:56 --> Model Class Initialized
INFO - 2018-02-17 12:54:56 --> Model Class Initialized
INFO - 2018-02-17 12:55:26 --> Config Class Initialized
INFO - 2018-02-17 12:55:26 --> Hooks Class Initialized
DEBUG - 2018-02-17 12:55:26 --> UTF-8 Support Enabled
INFO - 2018-02-17 12:55:26 --> Utf8 Class Initialized
INFO - 2018-02-17 12:55:26 --> URI Class Initialized
INFO - 2018-02-17 12:55:26 --> Router Class Initialized
INFO - 2018-02-17 12:55:26 --> Output Class Initialized
INFO - 2018-02-17 12:55:26 --> Security Class Initialized
DEBUG - 2018-02-17 12:55:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-17 12:55:26 --> Input Class Initialized
INFO - 2018-02-17 12:55:26 --> Language Class Initialized
INFO - 2018-02-17 12:55:26 --> Loader Class Initialized
INFO - 2018-02-17 12:55:26 --> Helper loaded: url_helper
INFO - 2018-02-17 12:55:26 --> Helper loaded: file_helper
INFO - 2018-02-17 12:55:26 --> Helper loaded: email_helper
INFO - 2018-02-17 12:55:26 --> Helper loaded: common_helper
INFO - 2018-02-17 12:55:26 --> Database Driver Class Initialized
DEBUG - 2018-02-17 12:55:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-17 12:55:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-17 12:55:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-17 12:55:26 --> Pagination Class Initialized
INFO - 2018-02-17 12:55:26 --> Helper loaded: form_helper
INFO - 2018-02-17 12:55:26 --> Form Validation Class Initialized
INFO - 2018-02-17 12:55:26 --> Model Class Initialized
INFO - 2018-02-17 12:55:26 --> Controller Class Initialized
INFO - 2018-02-17 12:55:26 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-17 12:55:26 --> Model Class Initialized
INFO - 2018-02-17 12:55:26 --> Model Class Initialized
INFO - 2018-02-17 12:55:26 --> Model Class Initialized
INFO - 2018-02-17 12:55:26 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-17 12:55:26 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-17 12:55:26 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-17 12:55:26 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-17 12:55:26 --> File loaded: /var/www/html/project/radio/application/views/tracks/add_edit.php
INFO - 2018-02-17 12:55:26 --> Final output sent to browser
DEBUG - 2018-02-17 12:55:26 --> Total execution time: 0.0111
INFO - 2018-02-17 12:55:30 --> Config Class Initialized
INFO - 2018-02-17 12:55:30 --> Hooks Class Initialized
DEBUG - 2018-02-17 12:55:30 --> UTF-8 Support Enabled
INFO - 2018-02-17 12:55:30 --> Utf8 Class Initialized
INFO - 2018-02-17 12:55:30 --> URI Class Initialized
INFO - 2018-02-17 12:55:30 --> Router Class Initialized
INFO - 2018-02-17 12:55:30 --> Output Class Initialized
INFO - 2018-02-17 12:55:30 --> Security Class Initialized
DEBUG - 2018-02-17 12:55:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-17 12:55:30 --> Input Class Initialized
INFO - 2018-02-17 12:55:30 --> Language Class Initialized
INFO - 2018-02-17 12:55:30 --> Loader Class Initialized
INFO - 2018-02-17 12:55:30 --> Helper loaded: url_helper
INFO - 2018-02-17 12:55:30 --> Helper loaded: file_helper
INFO - 2018-02-17 12:55:30 --> Helper loaded: email_helper
INFO - 2018-02-17 12:55:30 --> Helper loaded: common_helper
INFO - 2018-02-17 12:55:30 --> Database Driver Class Initialized
DEBUG - 2018-02-17 12:55:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-17 12:55:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-17 12:55:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-17 12:55:30 --> Pagination Class Initialized
INFO - 2018-02-17 12:55:30 --> Helper loaded: form_helper
INFO - 2018-02-17 12:55:30 --> Form Validation Class Initialized
INFO - 2018-02-17 12:55:30 --> Model Class Initialized
INFO - 2018-02-17 12:55:30 --> Controller Class Initialized
INFO - 2018-02-17 12:55:30 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-17 12:55:30 --> Model Class Initialized
INFO - 2018-02-17 12:55:30 --> Model Class Initialized
INFO - 2018-02-17 12:55:30 --> Model Class Initialized
INFO - 2018-02-17 12:55:30 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-17 12:55:30 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-17 12:55:30 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-17 12:55:30 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-17 12:55:30 --> File loaded: /var/www/html/project/radio/application/views/tracks/add_edit.php
INFO - 2018-02-17 12:55:30 --> Final output sent to browser
DEBUG - 2018-02-17 12:55:30 --> Total execution time: 0.0113
INFO - 2018-02-17 12:55:44 --> Config Class Initialized
INFO - 2018-02-17 12:55:44 --> Hooks Class Initialized
DEBUG - 2018-02-17 12:55:44 --> UTF-8 Support Enabled
INFO - 2018-02-17 12:55:44 --> Utf8 Class Initialized
INFO - 2018-02-17 12:55:44 --> URI Class Initialized
INFO - 2018-02-17 12:55:44 --> Router Class Initialized
INFO - 2018-02-17 12:55:44 --> Output Class Initialized
INFO - 2018-02-17 12:55:44 --> Security Class Initialized
DEBUG - 2018-02-17 12:55:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-17 12:55:44 --> Input Class Initialized
INFO - 2018-02-17 12:55:44 --> Language Class Initialized
INFO - 2018-02-17 12:55:45 --> Loader Class Initialized
INFO - 2018-02-17 12:55:45 --> Helper loaded: url_helper
INFO - 2018-02-17 12:55:45 --> Helper loaded: file_helper
INFO - 2018-02-17 12:55:45 --> Helper loaded: email_helper
INFO - 2018-02-17 12:55:45 --> Helper loaded: common_helper
INFO - 2018-02-17 12:55:45 --> Database Driver Class Initialized
DEBUG - 2018-02-17 12:55:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-17 12:55:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-17 12:55:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-17 12:55:45 --> Pagination Class Initialized
INFO - 2018-02-17 12:55:45 --> Helper loaded: form_helper
INFO - 2018-02-17 12:55:45 --> Form Validation Class Initialized
INFO - 2018-02-17 12:55:45 --> Model Class Initialized
INFO - 2018-02-17 12:55:45 --> Controller Class Initialized
INFO - 2018-02-17 12:55:45 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-17 12:55:45 --> Model Class Initialized
INFO - 2018-02-17 12:55:45 --> Model Class Initialized
INFO - 2018-02-17 12:55:45 --> Model Class Initialized
INFO - 2018-02-17 12:59:36 --> Config Class Initialized
INFO - 2018-02-17 12:59:36 --> Hooks Class Initialized
DEBUG - 2018-02-17 12:59:36 --> UTF-8 Support Enabled
INFO - 2018-02-17 12:59:36 --> Utf8 Class Initialized
INFO - 2018-02-17 12:59:36 --> URI Class Initialized
INFO - 2018-02-17 12:59:36 --> Router Class Initialized
INFO - 2018-02-17 12:59:36 --> Output Class Initialized
INFO - 2018-02-17 12:59:36 --> Security Class Initialized
DEBUG - 2018-02-17 12:59:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-17 12:59:36 --> Input Class Initialized
INFO - 2018-02-17 12:59:36 --> Language Class Initialized
INFO - 2018-02-17 12:59:36 --> Loader Class Initialized
INFO - 2018-02-17 12:59:36 --> Helper loaded: url_helper
INFO - 2018-02-17 12:59:36 --> Helper loaded: file_helper
INFO - 2018-02-17 12:59:36 --> Helper loaded: email_helper
INFO - 2018-02-17 12:59:36 --> Helper loaded: common_helper
INFO - 2018-02-17 12:59:36 --> Database Driver Class Initialized
DEBUG - 2018-02-17 12:59:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-17 12:59:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-17 12:59:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-17 12:59:36 --> Pagination Class Initialized
INFO - 2018-02-17 12:59:36 --> Helper loaded: form_helper
INFO - 2018-02-17 12:59:36 --> Form Validation Class Initialized
INFO - 2018-02-17 12:59:36 --> Model Class Initialized
INFO - 2018-02-17 12:59:36 --> Controller Class Initialized
INFO - 2018-02-17 12:59:36 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-17 12:59:36 --> Model Class Initialized
INFO - 2018-02-17 12:59:36 --> Model Class Initialized
INFO - 2018-02-17 12:59:36 --> Model Class Initialized
INFO - 2018-02-17 12:59:36 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-17 12:59:36 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-17 12:59:36 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-17 12:59:36 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-17 12:59:36 --> File loaded: /var/www/html/project/radio/application/views/tracks/add_edit.php
INFO - 2018-02-17 12:59:36 --> Final output sent to browser
DEBUG - 2018-02-17 12:59:36 --> Total execution time: 0.0140
INFO - 2018-02-17 12:59:57 --> Config Class Initialized
INFO - 2018-02-17 12:59:57 --> Hooks Class Initialized
DEBUG - 2018-02-17 12:59:57 --> UTF-8 Support Enabled
INFO - 2018-02-17 12:59:57 --> Utf8 Class Initialized
INFO - 2018-02-17 12:59:57 --> URI Class Initialized
INFO - 2018-02-17 12:59:57 --> Router Class Initialized
INFO - 2018-02-17 12:59:57 --> Output Class Initialized
INFO - 2018-02-17 12:59:57 --> Security Class Initialized
DEBUG - 2018-02-17 12:59:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-17 12:59:57 --> Input Class Initialized
INFO - 2018-02-17 12:59:57 --> Language Class Initialized
INFO - 2018-02-17 12:59:57 --> Loader Class Initialized
INFO - 2018-02-17 12:59:57 --> Helper loaded: url_helper
INFO - 2018-02-17 12:59:57 --> Helper loaded: file_helper
INFO - 2018-02-17 12:59:57 --> Helper loaded: email_helper
INFO - 2018-02-17 12:59:57 --> Helper loaded: common_helper
INFO - 2018-02-17 12:59:57 --> Database Driver Class Initialized
DEBUG - 2018-02-17 12:59:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-17 12:59:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-17 12:59:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-17 12:59:57 --> Pagination Class Initialized
INFO - 2018-02-17 12:59:57 --> Helper loaded: form_helper
INFO - 2018-02-17 12:59:57 --> Form Validation Class Initialized
INFO - 2018-02-17 12:59:57 --> Model Class Initialized
INFO - 2018-02-17 12:59:57 --> Controller Class Initialized
INFO - 2018-02-17 12:59:57 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-17 12:59:57 --> Model Class Initialized
INFO - 2018-02-17 12:59:57 --> Model Class Initialized
INFO - 2018-02-17 12:59:57 --> Model Class Initialized
INFO - 2018-02-17 13:04:19 --> Config Class Initialized
INFO - 2018-02-17 13:04:19 --> Hooks Class Initialized
DEBUG - 2018-02-17 13:04:19 --> UTF-8 Support Enabled
INFO - 2018-02-17 13:04:19 --> Utf8 Class Initialized
INFO - 2018-02-17 13:04:19 --> URI Class Initialized
INFO - 2018-02-17 13:04:19 --> Router Class Initialized
INFO - 2018-02-17 13:04:19 --> Output Class Initialized
INFO - 2018-02-17 13:04:19 --> Security Class Initialized
DEBUG - 2018-02-17 13:04:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-17 13:04:19 --> Input Class Initialized
INFO - 2018-02-17 13:04:19 --> Language Class Initialized
INFO - 2018-02-17 13:04:19 --> Loader Class Initialized
INFO - 2018-02-17 13:04:19 --> Helper loaded: url_helper
INFO - 2018-02-17 13:04:19 --> Helper loaded: file_helper
INFO - 2018-02-17 13:04:19 --> Helper loaded: email_helper
INFO - 2018-02-17 13:04:19 --> Helper loaded: common_helper
INFO - 2018-02-17 13:04:19 --> Database Driver Class Initialized
DEBUG - 2018-02-17 13:04:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-17 13:04:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-17 13:04:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-17 13:04:19 --> Pagination Class Initialized
INFO - 2018-02-17 13:04:19 --> Helper loaded: form_helper
INFO - 2018-02-17 13:04:19 --> Form Validation Class Initialized
INFO - 2018-02-17 13:04:19 --> Model Class Initialized
INFO - 2018-02-17 13:04:19 --> Controller Class Initialized
INFO - 2018-02-17 13:04:19 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-17 13:04:19 --> Model Class Initialized
INFO - 2018-02-17 13:04:19 --> Model Class Initialized
INFO - 2018-02-17 13:04:19 --> Model Class Initialized
INFO - 2018-02-17 13:04:19 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-17 13:04:19 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-17 13:04:19 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-17 13:04:19 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-17 13:04:19 --> File loaded: /var/www/html/project/radio/application/views/tracks/add_edit.php
INFO - 2018-02-17 13:04:19 --> Final output sent to browser
DEBUG - 2018-02-17 13:04:19 --> Total execution time: 0.0075
INFO - 2018-02-17 13:04:22 --> Config Class Initialized
INFO - 2018-02-17 13:04:22 --> Hooks Class Initialized
DEBUG - 2018-02-17 13:04:22 --> UTF-8 Support Enabled
INFO - 2018-02-17 13:04:22 --> Utf8 Class Initialized
INFO - 2018-02-17 13:04:22 --> URI Class Initialized
INFO - 2018-02-17 13:04:22 --> Router Class Initialized
INFO - 2018-02-17 13:04:22 --> Output Class Initialized
INFO - 2018-02-17 13:04:22 --> Security Class Initialized
DEBUG - 2018-02-17 13:04:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-17 13:04:22 --> Input Class Initialized
INFO - 2018-02-17 13:04:22 --> Language Class Initialized
INFO - 2018-02-17 13:04:22 --> Loader Class Initialized
INFO - 2018-02-17 13:04:22 --> Helper loaded: url_helper
INFO - 2018-02-17 13:04:22 --> Helper loaded: file_helper
INFO - 2018-02-17 13:04:22 --> Helper loaded: email_helper
INFO - 2018-02-17 13:04:22 --> Helper loaded: common_helper
INFO - 2018-02-17 13:04:22 --> Database Driver Class Initialized
DEBUG - 2018-02-17 13:04:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-17 13:04:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-17 13:04:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-17 13:04:22 --> Pagination Class Initialized
INFO - 2018-02-17 13:04:22 --> Helper loaded: form_helper
INFO - 2018-02-17 13:04:22 --> Form Validation Class Initialized
INFO - 2018-02-17 13:04:22 --> Model Class Initialized
INFO - 2018-02-17 13:04:22 --> Controller Class Initialized
INFO - 2018-02-17 13:04:22 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-17 13:04:22 --> Model Class Initialized
INFO - 2018-02-17 13:04:22 --> Model Class Initialized
INFO - 2018-02-17 13:04:22 --> Model Class Initialized
INFO - 2018-02-17 13:07:26 --> Config Class Initialized
INFO - 2018-02-17 13:07:26 --> Hooks Class Initialized
DEBUG - 2018-02-17 13:07:26 --> UTF-8 Support Enabled
INFO - 2018-02-17 13:07:26 --> Utf8 Class Initialized
INFO - 2018-02-17 13:07:26 --> URI Class Initialized
INFO - 2018-02-17 13:07:26 --> Router Class Initialized
INFO - 2018-02-17 13:07:26 --> Output Class Initialized
INFO - 2018-02-17 13:07:26 --> Security Class Initialized
DEBUG - 2018-02-17 13:07:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-17 13:07:26 --> Input Class Initialized
INFO - 2018-02-17 13:07:26 --> Language Class Initialized
INFO - 2018-02-17 13:07:26 --> Loader Class Initialized
INFO - 2018-02-17 13:07:26 --> Helper loaded: url_helper
INFO - 2018-02-17 13:07:26 --> Helper loaded: file_helper
INFO - 2018-02-17 13:07:26 --> Helper loaded: email_helper
INFO - 2018-02-17 13:07:26 --> Helper loaded: common_helper
INFO - 2018-02-17 13:07:26 --> Database Driver Class Initialized
DEBUG - 2018-02-17 13:07:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-17 13:07:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-17 13:07:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-17 13:07:26 --> Pagination Class Initialized
INFO - 2018-02-17 13:07:26 --> Helper loaded: form_helper
INFO - 2018-02-17 13:07:26 --> Form Validation Class Initialized
INFO - 2018-02-17 13:07:26 --> Model Class Initialized
INFO - 2018-02-17 13:07:26 --> Controller Class Initialized
INFO - 2018-02-17 13:07:26 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-17 13:07:26 --> Model Class Initialized
INFO - 2018-02-17 13:07:26 --> Model Class Initialized
INFO - 2018-02-17 13:07:26 --> Model Class Initialized
INFO - 2018-02-17 13:07:26 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-17 13:07:26 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-17 13:07:26 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-17 13:07:26 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-17 13:07:26 --> File loaded: /var/www/html/project/radio/application/views/tracks/add_edit.php
INFO - 2018-02-17 13:07:26 --> Final output sent to browser
DEBUG - 2018-02-17 13:07:26 --> Total execution time: 0.0097
INFO - 2018-02-17 13:07:29 --> Config Class Initialized
INFO - 2018-02-17 13:07:29 --> Hooks Class Initialized
DEBUG - 2018-02-17 13:07:29 --> UTF-8 Support Enabled
INFO - 2018-02-17 13:07:29 --> Utf8 Class Initialized
INFO - 2018-02-17 13:07:29 --> URI Class Initialized
INFO - 2018-02-17 13:07:29 --> Router Class Initialized
INFO - 2018-02-17 13:07:29 --> Output Class Initialized
INFO - 2018-02-17 13:07:29 --> Security Class Initialized
DEBUG - 2018-02-17 13:07:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-17 13:07:29 --> Input Class Initialized
INFO - 2018-02-17 13:07:29 --> Language Class Initialized
INFO - 2018-02-17 13:07:29 --> Loader Class Initialized
INFO - 2018-02-17 13:07:29 --> Helper loaded: url_helper
INFO - 2018-02-17 13:07:29 --> Helper loaded: file_helper
INFO - 2018-02-17 13:07:29 --> Helper loaded: email_helper
INFO - 2018-02-17 13:07:29 --> Helper loaded: common_helper
INFO - 2018-02-17 13:07:29 --> Database Driver Class Initialized
DEBUG - 2018-02-17 13:07:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-17 13:07:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-17 13:07:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-17 13:07:29 --> Pagination Class Initialized
INFO - 2018-02-17 13:07:29 --> Helper loaded: form_helper
INFO - 2018-02-17 13:07:29 --> Form Validation Class Initialized
INFO - 2018-02-17 13:07:29 --> Model Class Initialized
INFO - 2018-02-17 13:07:29 --> Controller Class Initialized
INFO - 2018-02-17 13:07:29 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-17 13:07:29 --> Model Class Initialized
INFO - 2018-02-17 13:07:29 --> Model Class Initialized
INFO - 2018-02-17 13:07:29 --> Model Class Initialized
INFO - 2018-02-17 13:08:01 --> Config Class Initialized
INFO - 2018-02-17 13:08:01 --> Hooks Class Initialized
DEBUG - 2018-02-17 13:08:01 --> UTF-8 Support Enabled
INFO - 2018-02-17 13:08:01 --> Utf8 Class Initialized
INFO - 2018-02-17 13:08:01 --> URI Class Initialized
INFO - 2018-02-17 13:08:01 --> Router Class Initialized
INFO - 2018-02-17 13:08:01 --> Output Class Initialized
INFO - 2018-02-17 13:08:01 --> Security Class Initialized
DEBUG - 2018-02-17 13:08:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-17 13:08:01 --> Input Class Initialized
INFO - 2018-02-17 13:08:01 --> Language Class Initialized
INFO - 2018-02-17 13:08:01 --> Loader Class Initialized
INFO - 2018-02-17 13:08:01 --> Helper loaded: url_helper
INFO - 2018-02-17 13:08:01 --> Helper loaded: file_helper
INFO - 2018-02-17 13:08:01 --> Helper loaded: email_helper
INFO - 2018-02-17 13:08:01 --> Helper loaded: common_helper
INFO - 2018-02-17 13:08:01 --> Database Driver Class Initialized
DEBUG - 2018-02-17 13:08:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-17 13:08:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-17 13:08:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-17 13:08:01 --> Pagination Class Initialized
INFO - 2018-02-17 13:08:01 --> Helper loaded: form_helper
INFO - 2018-02-17 13:08:01 --> Form Validation Class Initialized
INFO - 2018-02-17 13:08:01 --> Model Class Initialized
INFO - 2018-02-17 13:08:01 --> Controller Class Initialized
INFO - 2018-02-17 13:08:01 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-17 13:08:01 --> Model Class Initialized
INFO - 2018-02-17 13:08:01 --> Model Class Initialized
INFO - 2018-02-17 13:08:01 --> Model Class Initialized
DEBUG - 2018-02-17 13:08:01 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-17 13:08:01 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-02-17 13:08:11 --> Config Class Initialized
INFO - 2018-02-17 13:08:11 --> Hooks Class Initialized
DEBUG - 2018-02-17 13:08:11 --> UTF-8 Support Enabled
INFO - 2018-02-17 13:08:11 --> Utf8 Class Initialized
INFO - 2018-02-17 13:08:11 --> URI Class Initialized
INFO - 2018-02-17 13:08:11 --> Router Class Initialized
INFO - 2018-02-17 13:08:11 --> Output Class Initialized
INFO - 2018-02-17 13:08:11 --> Security Class Initialized
DEBUG - 2018-02-17 13:08:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-17 13:08:11 --> Input Class Initialized
INFO - 2018-02-17 13:08:11 --> Language Class Initialized
INFO - 2018-02-17 13:08:11 --> Loader Class Initialized
INFO - 2018-02-17 13:08:11 --> Helper loaded: url_helper
INFO - 2018-02-17 13:08:11 --> Helper loaded: file_helper
INFO - 2018-02-17 13:08:11 --> Helper loaded: email_helper
INFO - 2018-02-17 13:08:11 --> Helper loaded: common_helper
INFO - 2018-02-17 13:08:11 --> Database Driver Class Initialized
DEBUG - 2018-02-17 13:08:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-17 13:08:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-17 13:08:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-17 13:08:11 --> Pagination Class Initialized
INFO - 2018-02-17 13:08:11 --> Helper loaded: form_helper
INFO - 2018-02-17 13:08:11 --> Form Validation Class Initialized
INFO - 2018-02-17 13:08:11 --> Model Class Initialized
INFO - 2018-02-17 13:08:11 --> Controller Class Initialized
INFO - 2018-02-17 13:08:11 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-17 13:08:11 --> Model Class Initialized
INFO - 2018-02-17 13:08:11 --> Model Class Initialized
INFO - 2018-02-17 13:08:11 --> Model Class Initialized
INFO - 2018-02-17 13:08:11 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-17 13:08:11 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-17 13:08:11 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-17 13:08:11 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-17 13:08:11 --> File loaded: /var/www/html/project/radio/application/views/tracks/add_edit.php
INFO - 2018-02-17 13:08:11 --> Final output sent to browser
DEBUG - 2018-02-17 13:08:11 --> Total execution time: 0.0105
INFO - 2018-02-17 13:08:42 --> Config Class Initialized
INFO - 2018-02-17 13:08:42 --> Hooks Class Initialized
DEBUG - 2018-02-17 13:08:42 --> UTF-8 Support Enabled
INFO - 2018-02-17 13:08:42 --> Utf8 Class Initialized
INFO - 2018-02-17 13:08:42 --> URI Class Initialized
INFO - 2018-02-17 13:08:42 --> Router Class Initialized
INFO - 2018-02-17 13:08:42 --> Output Class Initialized
INFO - 2018-02-17 13:08:42 --> Security Class Initialized
DEBUG - 2018-02-17 13:08:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-17 13:08:42 --> Input Class Initialized
INFO - 2018-02-17 13:08:42 --> Language Class Initialized
INFO - 2018-02-17 13:08:42 --> Loader Class Initialized
INFO - 2018-02-17 13:08:42 --> Helper loaded: url_helper
INFO - 2018-02-17 13:08:42 --> Helper loaded: file_helper
INFO - 2018-02-17 13:08:42 --> Helper loaded: email_helper
INFO - 2018-02-17 13:08:42 --> Helper loaded: common_helper
INFO - 2018-02-17 13:08:42 --> Database Driver Class Initialized
DEBUG - 2018-02-17 13:08:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-17 13:08:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-17 13:08:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-17 13:08:42 --> Pagination Class Initialized
INFO - 2018-02-17 13:08:42 --> Helper loaded: form_helper
INFO - 2018-02-17 13:08:42 --> Form Validation Class Initialized
INFO - 2018-02-17 13:08:42 --> Model Class Initialized
INFO - 2018-02-17 13:08:42 --> Controller Class Initialized
INFO - 2018-02-17 13:08:42 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-17 13:08:42 --> Model Class Initialized
INFO - 2018-02-17 13:08:42 --> Model Class Initialized
INFO - 2018-02-17 13:08:42 --> Model Class Initialized
INFO - 2018-02-17 13:08:56 --> Config Class Initialized
INFO - 2018-02-17 13:08:56 --> Hooks Class Initialized
DEBUG - 2018-02-17 13:08:56 --> UTF-8 Support Enabled
INFO - 2018-02-17 13:08:56 --> Utf8 Class Initialized
INFO - 2018-02-17 13:08:56 --> URI Class Initialized
INFO - 2018-02-17 13:08:56 --> Router Class Initialized
INFO - 2018-02-17 13:08:56 --> Output Class Initialized
INFO - 2018-02-17 13:08:56 --> Security Class Initialized
DEBUG - 2018-02-17 13:08:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-17 13:08:56 --> Input Class Initialized
INFO - 2018-02-17 13:08:56 --> Language Class Initialized
INFO - 2018-02-17 13:08:56 --> Loader Class Initialized
INFO - 2018-02-17 13:08:56 --> Helper loaded: url_helper
INFO - 2018-02-17 13:08:56 --> Helper loaded: file_helper
INFO - 2018-02-17 13:08:56 --> Helper loaded: email_helper
INFO - 2018-02-17 13:08:56 --> Helper loaded: common_helper
INFO - 2018-02-17 13:08:56 --> Database Driver Class Initialized
DEBUG - 2018-02-17 13:08:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-17 13:08:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-17 13:08:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-17 13:08:56 --> Pagination Class Initialized
INFO - 2018-02-17 13:08:56 --> Helper loaded: form_helper
INFO - 2018-02-17 13:08:56 --> Form Validation Class Initialized
INFO - 2018-02-17 13:08:56 --> Model Class Initialized
INFO - 2018-02-17 13:08:56 --> Controller Class Initialized
INFO - 2018-02-17 13:08:56 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-17 13:08:56 --> Model Class Initialized
INFO - 2018-02-17 13:08:56 --> Model Class Initialized
INFO - 2018-02-17 13:08:56 --> Model Class Initialized
INFO - 2018-02-17 13:09:17 --> Config Class Initialized
INFO - 2018-02-17 13:09:17 --> Hooks Class Initialized
DEBUG - 2018-02-17 13:09:17 --> UTF-8 Support Enabled
INFO - 2018-02-17 13:09:17 --> Utf8 Class Initialized
INFO - 2018-02-17 13:09:17 --> URI Class Initialized
INFO - 2018-02-17 13:09:17 --> Router Class Initialized
INFO - 2018-02-17 13:09:17 --> Output Class Initialized
INFO - 2018-02-17 13:09:17 --> Security Class Initialized
DEBUG - 2018-02-17 13:09:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-17 13:09:17 --> Input Class Initialized
INFO - 2018-02-17 13:09:17 --> Language Class Initialized
INFO - 2018-02-17 13:09:17 --> Loader Class Initialized
INFO - 2018-02-17 13:09:17 --> Helper loaded: url_helper
INFO - 2018-02-17 13:09:17 --> Helper loaded: file_helper
INFO - 2018-02-17 13:09:17 --> Helper loaded: email_helper
INFO - 2018-02-17 13:09:17 --> Helper loaded: common_helper
INFO - 2018-02-17 13:09:17 --> Database Driver Class Initialized
DEBUG - 2018-02-17 13:09:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-17 13:09:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-17 13:09:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-17 13:09:17 --> Pagination Class Initialized
INFO - 2018-02-17 13:09:17 --> Helper loaded: form_helper
INFO - 2018-02-17 13:09:17 --> Form Validation Class Initialized
INFO - 2018-02-17 13:09:17 --> Model Class Initialized
INFO - 2018-02-17 13:09:17 --> Controller Class Initialized
INFO - 2018-02-17 13:09:17 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-17 13:09:17 --> Model Class Initialized
INFO - 2018-02-17 13:09:17 --> Model Class Initialized
INFO - 2018-02-17 13:09:17 --> Model Class Initialized
DEBUG - 2018-02-17 13:09:17 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-17 13:09:17 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-02-17 13:21:38 --> Config Class Initialized
INFO - 2018-02-17 13:21:38 --> Hooks Class Initialized
DEBUG - 2018-02-17 13:21:38 --> UTF-8 Support Enabled
INFO - 2018-02-17 13:21:38 --> Utf8 Class Initialized
INFO - 2018-02-17 13:21:38 --> URI Class Initialized
INFO - 2018-02-17 13:21:38 --> Router Class Initialized
INFO - 2018-02-17 13:21:38 --> Output Class Initialized
INFO - 2018-02-17 13:21:38 --> Security Class Initialized
DEBUG - 2018-02-17 13:21:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-17 13:21:38 --> Input Class Initialized
INFO - 2018-02-17 13:21:38 --> Language Class Initialized
INFO - 2018-02-17 13:21:38 --> Loader Class Initialized
INFO - 2018-02-17 13:21:38 --> Helper loaded: url_helper
INFO - 2018-02-17 13:21:38 --> Helper loaded: file_helper
INFO - 2018-02-17 13:21:38 --> Helper loaded: email_helper
INFO - 2018-02-17 13:21:38 --> Helper loaded: common_helper
INFO - 2018-02-17 13:21:38 --> Database Driver Class Initialized
DEBUG - 2018-02-17 13:21:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-17 13:21:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-17 13:21:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-17 13:21:38 --> Pagination Class Initialized
INFO - 2018-02-17 13:21:38 --> Helper loaded: form_helper
INFO - 2018-02-17 13:21:38 --> Form Validation Class Initialized
INFO - 2018-02-17 13:21:38 --> Model Class Initialized
INFO - 2018-02-17 13:21:38 --> Controller Class Initialized
INFO - 2018-02-17 13:21:38 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-17 13:21:38 --> Model Class Initialized
INFO - 2018-02-17 13:21:38 --> Model Class Initialized
INFO - 2018-02-17 13:21:38 --> Model Class Initialized
INFO - 2018-02-17 13:21:38 --> Model Class Initialized
INFO - 2018-02-17 13:21:38 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-17 13:21:38 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-17 13:21:38 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-17 13:21:38 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-17 13:21:38 --> File loaded: /var/www/html/project/radio/application/views/tracks/add_edit.php
INFO - 2018-02-17 13:21:38 --> Final output sent to browser
DEBUG - 2018-02-17 13:21:38 --> Total execution time: 0.0121
INFO - 2018-02-17 13:21:40 --> Config Class Initialized
INFO - 2018-02-17 13:21:40 --> Hooks Class Initialized
DEBUG - 2018-02-17 13:21:40 --> UTF-8 Support Enabled
INFO - 2018-02-17 13:21:40 --> Utf8 Class Initialized
INFO - 2018-02-17 13:21:40 --> URI Class Initialized
INFO - 2018-02-17 13:21:40 --> Router Class Initialized
INFO - 2018-02-17 13:21:40 --> Output Class Initialized
INFO - 2018-02-17 13:21:40 --> Security Class Initialized
DEBUG - 2018-02-17 13:21:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-17 13:21:40 --> Input Class Initialized
INFO - 2018-02-17 13:21:40 --> Language Class Initialized
INFO - 2018-02-17 13:21:40 --> Loader Class Initialized
INFO - 2018-02-17 13:21:40 --> Helper loaded: url_helper
INFO - 2018-02-17 13:21:40 --> Helper loaded: file_helper
INFO - 2018-02-17 13:21:40 --> Helper loaded: email_helper
INFO - 2018-02-17 13:21:40 --> Helper loaded: common_helper
INFO - 2018-02-17 13:21:40 --> Database Driver Class Initialized
DEBUG - 2018-02-17 13:21:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-17 13:21:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-17 13:21:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-17 13:21:40 --> Pagination Class Initialized
INFO - 2018-02-17 13:21:40 --> Helper loaded: form_helper
INFO - 2018-02-17 13:21:40 --> Form Validation Class Initialized
INFO - 2018-02-17 13:21:40 --> Model Class Initialized
INFO - 2018-02-17 13:21:40 --> Controller Class Initialized
INFO - 2018-02-17 13:21:40 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-17 13:21:40 --> Model Class Initialized
INFO - 2018-02-17 13:21:40 --> Model Class Initialized
INFO - 2018-02-17 13:21:40 --> Model Class Initialized
INFO - 2018-02-17 13:21:40 --> Model Class Initialized
INFO - 2018-02-17 13:22:15 --> Config Class Initialized
INFO - 2018-02-17 13:22:15 --> Hooks Class Initialized
DEBUG - 2018-02-17 13:22:15 --> UTF-8 Support Enabled
INFO - 2018-02-17 13:22:15 --> Utf8 Class Initialized
INFO - 2018-02-17 13:22:15 --> URI Class Initialized
INFO - 2018-02-17 13:22:15 --> Router Class Initialized
INFO - 2018-02-17 13:22:15 --> Output Class Initialized
INFO - 2018-02-17 13:22:15 --> Security Class Initialized
DEBUG - 2018-02-17 13:22:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-17 13:22:15 --> Input Class Initialized
INFO - 2018-02-17 13:22:15 --> Language Class Initialized
INFO - 2018-02-17 13:22:15 --> Loader Class Initialized
INFO - 2018-02-17 13:22:15 --> Helper loaded: url_helper
INFO - 2018-02-17 13:22:15 --> Helper loaded: file_helper
INFO - 2018-02-17 13:22:15 --> Helper loaded: email_helper
INFO - 2018-02-17 13:22:15 --> Helper loaded: common_helper
INFO - 2018-02-17 13:22:15 --> Database Driver Class Initialized
DEBUG - 2018-02-17 13:22:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-17 13:22:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-17 13:22:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-17 13:22:15 --> Pagination Class Initialized
INFO - 2018-02-17 13:22:15 --> Helper loaded: form_helper
INFO - 2018-02-17 13:22:15 --> Form Validation Class Initialized
INFO - 2018-02-17 13:22:15 --> Model Class Initialized
INFO - 2018-02-17 13:22:15 --> Controller Class Initialized
INFO - 2018-02-17 13:22:15 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-17 13:22:15 --> Model Class Initialized
INFO - 2018-02-17 13:22:15 --> Model Class Initialized
INFO - 2018-02-17 13:22:15 --> Model Class Initialized
INFO - 2018-02-17 13:22:15 --> Model Class Initialized
DEBUG - 2018-02-17 13:22:15 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-17 13:22:15 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-02-17 13:22:23 --> Config Class Initialized
INFO - 2018-02-17 13:22:23 --> Hooks Class Initialized
DEBUG - 2018-02-17 13:22:23 --> UTF-8 Support Enabled
INFO - 2018-02-17 13:22:23 --> Utf8 Class Initialized
INFO - 2018-02-17 13:22:23 --> URI Class Initialized
INFO - 2018-02-17 13:22:23 --> Router Class Initialized
INFO - 2018-02-17 13:22:23 --> Output Class Initialized
INFO - 2018-02-17 13:22:23 --> Security Class Initialized
DEBUG - 2018-02-17 13:22:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-17 13:22:23 --> Input Class Initialized
INFO - 2018-02-17 13:22:23 --> Language Class Initialized
INFO - 2018-02-17 13:22:23 --> Loader Class Initialized
INFO - 2018-02-17 13:22:23 --> Helper loaded: url_helper
INFO - 2018-02-17 13:22:23 --> Helper loaded: file_helper
INFO - 2018-02-17 13:22:23 --> Helper loaded: email_helper
INFO - 2018-02-17 13:22:23 --> Helper loaded: common_helper
INFO - 2018-02-17 13:22:23 --> Database Driver Class Initialized
DEBUG - 2018-02-17 13:22:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-17 13:22:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-17 13:22:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-17 13:22:23 --> Pagination Class Initialized
INFO - 2018-02-17 13:22:23 --> Helper loaded: form_helper
INFO - 2018-02-17 13:22:23 --> Form Validation Class Initialized
INFO - 2018-02-17 13:22:23 --> Model Class Initialized
INFO - 2018-02-17 13:22:23 --> Controller Class Initialized
INFO - 2018-02-17 13:22:23 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-17 13:22:23 --> Model Class Initialized
INFO - 2018-02-17 13:22:23 --> Model Class Initialized
INFO - 2018-02-17 13:22:23 --> Model Class Initialized
INFO - 2018-02-17 13:22:23 --> Model Class Initialized
DEBUG - 2018-02-17 13:22:23 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-17 13:22:23 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2018-02-17 13:22:23 --> Severity: Warning --> explode() expects parameter 2 to be string, array given /var/www/html/project/radio/application/controllers/Tracks.php 145
ERROR - 2018-02-17 13:22:23 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/html/project/radio/application/controllers/Tracks.php 147
INFO - 2018-02-17 13:22:23 --> Config Class Initialized
INFO - 2018-02-17 13:22:23 --> Hooks Class Initialized
DEBUG - 2018-02-17 13:22:23 --> UTF-8 Support Enabled
INFO - 2018-02-17 13:22:23 --> Utf8 Class Initialized
INFO - 2018-02-17 13:22:23 --> URI Class Initialized
INFO - 2018-02-17 13:22:23 --> Router Class Initialized
INFO - 2018-02-17 13:22:23 --> Output Class Initialized
INFO - 2018-02-17 13:22:23 --> Security Class Initialized
DEBUG - 2018-02-17 13:22:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-17 13:22:23 --> Input Class Initialized
INFO - 2018-02-17 13:22:23 --> Language Class Initialized
INFO - 2018-02-17 13:22:23 --> Loader Class Initialized
INFO - 2018-02-17 13:22:23 --> Helper loaded: url_helper
INFO - 2018-02-17 13:22:23 --> Helper loaded: file_helper
INFO - 2018-02-17 13:22:23 --> Helper loaded: email_helper
INFO - 2018-02-17 13:22:23 --> Helper loaded: common_helper
INFO - 2018-02-17 13:22:23 --> Database Driver Class Initialized
DEBUG - 2018-02-17 13:22:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-17 13:22:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-17 13:22:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-17 13:22:23 --> Pagination Class Initialized
INFO - 2018-02-17 13:22:23 --> Helper loaded: form_helper
INFO - 2018-02-17 13:22:23 --> Form Validation Class Initialized
INFO - 2018-02-17 13:22:23 --> Model Class Initialized
INFO - 2018-02-17 13:22:23 --> Controller Class Initialized
INFO - 2018-02-17 13:22:23 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-17 13:22:23 --> Model Class Initialized
INFO - 2018-02-17 13:22:23 --> Model Class Initialized
INFO - 2018-02-17 13:22:23 --> Model Class Initialized
INFO - 2018-02-17 13:22:23 --> Model Class Initialized
INFO - 2018-02-17 13:22:23 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-17 13:22:23 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-17 13:22:23 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-17 13:22:23 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-17 13:22:23 --> File loaded: /var/www/html/project/radio/application/views/tracks/index.php
INFO - 2018-02-17 13:22:23 --> Final output sent to browser
DEBUG - 2018-02-17 13:22:23 --> Total execution time: 0.0045
INFO - 2018-02-17 13:22:23 --> Config Class Initialized
INFO - 2018-02-17 13:22:23 --> Hooks Class Initialized
DEBUG - 2018-02-17 13:22:23 --> UTF-8 Support Enabled
INFO - 2018-02-17 13:22:23 --> Utf8 Class Initialized
INFO - 2018-02-17 13:22:23 --> URI Class Initialized
INFO - 2018-02-17 13:22:23 --> Router Class Initialized
INFO - 2018-02-17 13:22:23 --> Output Class Initialized
INFO - 2018-02-17 13:22:23 --> Security Class Initialized
DEBUG - 2018-02-17 13:22:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-17 13:22:23 --> Input Class Initialized
INFO - 2018-02-17 13:22:23 --> Language Class Initialized
INFO - 2018-02-17 13:22:23 --> Loader Class Initialized
INFO - 2018-02-17 13:22:23 --> Helper loaded: url_helper
INFO - 2018-02-17 13:22:23 --> Helper loaded: file_helper
INFO - 2018-02-17 13:22:23 --> Helper loaded: email_helper
INFO - 2018-02-17 13:22:23 --> Helper loaded: common_helper
INFO - 2018-02-17 13:22:23 --> Database Driver Class Initialized
DEBUG - 2018-02-17 13:22:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-17 13:22:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-17 13:22:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-17 13:22:23 --> Pagination Class Initialized
INFO - 2018-02-17 13:22:23 --> Helper loaded: form_helper
INFO - 2018-02-17 13:22:23 --> Form Validation Class Initialized
INFO - 2018-02-17 13:22:23 --> Model Class Initialized
INFO - 2018-02-17 13:22:23 --> Controller Class Initialized
INFO - 2018-02-17 13:22:23 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-17 13:22:23 --> Model Class Initialized
INFO - 2018-02-17 13:22:23 --> Model Class Initialized
INFO - 2018-02-17 13:22:23 --> Model Class Initialized
INFO - 2018-02-17 13:22:23 --> Model Class Initialized
INFO - 2018-02-17 13:23:10 --> Config Class Initialized
INFO - 2018-02-17 13:23:10 --> Hooks Class Initialized
DEBUG - 2018-02-17 13:23:10 --> UTF-8 Support Enabled
INFO - 2018-02-17 13:23:10 --> Utf8 Class Initialized
INFO - 2018-02-17 13:23:10 --> URI Class Initialized
INFO - 2018-02-17 13:23:10 --> Router Class Initialized
INFO - 2018-02-17 13:23:10 --> Output Class Initialized
INFO - 2018-02-17 13:23:10 --> Security Class Initialized
DEBUG - 2018-02-17 13:23:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-17 13:23:10 --> Input Class Initialized
INFO - 2018-02-17 13:23:10 --> Language Class Initialized
INFO - 2018-02-17 13:23:10 --> Loader Class Initialized
INFO - 2018-02-17 13:23:10 --> Helper loaded: url_helper
INFO - 2018-02-17 13:23:10 --> Helper loaded: file_helper
INFO - 2018-02-17 13:23:10 --> Helper loaded: email_helper
INFO - 2018-02-17 13:23:10 --> Helper loaded: common_helper
INFO - 2018-02-17 13:23:10 --> Database Driver Class Initialized
DEBUG - 2018-02-17 13:23:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-17 13:23:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-17 13:23:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-17 13:23:10 --> Pagination Class Initialized
INFO - 2018-02-17 13:23:10 --> Helper loaded: form_helper
INFO - 2018-02-17 13:23:10 --> Form Validation Class Initialized
INFO - 2018-02-17 13:23:10 --> Model Class Initialized
INFO - 2018-02-17 13:23:10 --> Controller Class Initialized
INFO - 2018-02-17 13:23:10 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-17 13:23:10 --> Model Class Initialized
INFO - 2018-02-17 13:23:10 --> Model Class Initialized
INFO - 2018-02-17 13:23:10 --> Model Class Initialized
INFO - 2018-02-17 13:23:10 --> Model Class Initialized
INFO - 2018-02-17 13:23:10 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-17 13:23:10 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-17 13:23:10 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-17 13:23:10 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-17 13:23:10 --> File loaded: /var/www/html/project/radio/application/views/tracks/add_edit.php
INFO - 2018-02-17 13:23:10 --> Final output sent to browser
DEBUG - 2018-02-17 13:23:10 --> Total execution time: 0.0106
INFO - 2018-02-17 13:23:12 --> Config Class Initialized
INFO - 2018-02-17 13:23:12 --> Hooks Class Initialized
DEBUG - 2018-02-17 13:23:12 --> UTF-8 Support Enabled
INFO - 2018-02-17 13:23:12 --> Utf8 Class Initialized
INFO - 2018-02-17 13:23:12 --> URI Class Initialized
INFO - 2018-02-17 13:23:12 --> Router Class Initialized
INFO - 2018-02-17 13:23:12 --> Output Class Initialized
INFO - 2018-02-17 13:23:12 --> Security Class Initialized
DEBUG - 2018-02-17 13:23:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-17 13:23:12 --> Input Class Initialized
INFO - 2018-02-17 13:23:12 --> Language Class Initialized
INFO - 2018-02-17 13:23:12 --> Loader Class Initialized
INFO - 2018-02-17 13:23:12 --> Helper loaded: url_helper
INFO - 2018-02-17 13:23:12 --> Helper loaded: file_helper
INFO - 2018-02-17 13:23:12 --> Helper loaded: email_helper
INFO - 2018-02-17 13:23:12 --> Helper loaded: common_helper
INFO - 2018-02-17 13:23:12 --> Database Driver Class Initialized
DEBUG - 2018-02-17 13:23:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-17 13:23:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-17 13:23:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-17 13:23:12 --> Pagination Class Initialized
INFO - 2018-02-17 13:23:12 --> Helper loaded: form_helper
INFO - 2018-02-17 13:23:12 --> Form Validation Class Initialized
INFO - 2018-02-17 13:23:12 --> Model Class Initialized
INFO - 2018-02-17 13:23:12 --> Controller Class Initialized
INFO - 2018-02-17 13:23:12 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-17 13:23:12 --> Model Class Initialized
INFO - 2018-02-17 13:23:12 --> Model Class Initialized
INFO - 2018-02-17 13:23:12 --> Model Class Initialized
INFO - 2018-02-17 13:23:12 --> Model Class Initialized
INFO - 2018-02-17 13:23:42 --> Config Class Initialized
INFO - 2018-02-17 13:23:42 --> Hooks Class Initialized
DEBUG - 2018-02-17 13:23:42 --> UTF-8 Support Enabled
INFO - 2018-02-17 13:23:42 --> Utf8 Class Initialized
INFO - 2018-02-17 13:23:42 --> URI Class Initialized
INFO - 2018-02-17 13:23:42 --> Router Class Initialized
INFO - 2018-02-17 13:23:42 --> Output Class Initialized
INFO - 2018-02-17 13:23:42 --> Security Class Initialized
DEBUG - 2018-02-17 13:23:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-17 13:23:42 --> Input Class Initialized
INFO - 2018-02-17 13:23:42 --> Language Class Initialized
INFO - 2018-02-17 13:23:42 --> Loader Class Initialized
INFO - 2018-02-17 13:23:42 --> Helper loaded: url_helper
INFO - 2018-02-17 13:23:42 --> Helper loaded: file_helper
INFO - 2018-02-17 13:23:42 --> Helper loaded: email_helper
INFO - 2018-02-17 13:23:42 --> Helper loaded: common_helper
INFO - 2018-02-17 13:23:42 --> Database Driver Class Initialized
DEBUG - 2018-02-17 13:23:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-17 13:23:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-17 13:23:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-17 13:23:42 --> Pagination Class Initialized
INFO - 2018-02-17 13:23:42 --> Helper loaded: form_helper
INFO - 2018-02-17 13:23:42 --> Form Validation Class Initialized
INFO - 2018-02-17 13:23:42 --> Model Class Initialized
INFO - 2018-02-17 13:23:42 --> Controller Class Initialized
INFO - 2018-02-17 13:23:42 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-17 13:23:42 --> Model Class Initialized
INFO - 2018-02-17 13:23:42 --> Model Class Initialized
INFO - 2018-02-17 13:23:42 --> Model Class Initialized
INFO - 2018-02-17 13:23:42 --> Model Class Initialized
DEBUG - 2018-02-17 13:23:42 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-17 13:23:42 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2018-02-17 13:23:42 --> Severity: Warning --> explode() expects parameter 2 to be string, array given /var/www/html/project/radio/application/controllers/Tracks.php 145
ERROR - 2018-02-17 13:23:42 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/html/project/radio/application/controllers/Tracks.php 147
INFO - 2018-02-17 13:24:35 --> Config Class Initialized
INFO - 2018-02-17 13:24:35 --> Hooks Class Initialized
DEBUG - 2018-02-17 13:24:35 --> UTF-8 Support Enabled
INFO - 2018-02-17 13:24:35 --> Utf8 Class Initialized
INFO - 2018-02-17 13:24:35 --> URI Class Initialized
INFO - 2018-02-17 13:24:35 --> Router Class Initialized
INFO - 2018-02-17 13:24:35 --> Output Class Initialized
INFO - 2018-02-17 13:24:35 --> Security Class Initialized
DEBUG - 2018-02-17 13:24:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-17 13:24:35 --> Input Class Initialized
INFO - 2018-02-17 13:24:35 --> Language Class Initialized
INFO - 2018-02-17 13:24:35 --> Loader Class Initialized
INFO - 2018-02-17 13:24:35 --> Helper loaded: url_helper
INFO - 2018-02-17 13:24:35 --> Helper loaded: file_helper
INFO - 2018-02-17 13:24:35 --> Helper loaded: email_helper
INFO - 2018-02-17 13:24:35 --> Helper loaded: common_helper
INFO - 2018-02-17 13:24:35 --> Database Driver Class Initialized
DEBUG - 2018-02-17 13:24:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-17 13:24:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-17 13:24:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-17 13:24:35 --> Pagination Class Initialized
INFO - 2018-02-17 13:24:35 --> Helper loaded: form_helper
INFO - 2018-02-17 13:24:35 --> Form Validation Class Initialized
INFO - 2018-02-17 13:24:35 --> Model Class Initialized
INFO - 2018-02-17 13:24:35 --> Controller Class Initialized
INFO - 2018-02-17 13:24:35 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-17 13:24:35 --> Model Class Initialized
INFO - 2018-02-17 13:24:35 --> Model Class Initialized
INFO - 2018-02-17 13:24:35 --> Model Class Initialized
INFO - 2018-02-17 13:24:35 --> Model Class Initialized
DEBUG - 2018-02-17 13:24:35 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-17 13:24:35 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-02-17 13:24:44 --> Config Class Initialized
INFO - 2018-02-17 13:24:44 --> Hooks Class Initialized
DEBUG - 2018-02-17 13:24:44 --> UTF-8 Support Enabled
INFO - 2018-02-17 13:24:44 --> Utf8 Class Initialized
INFO - 2018-02-17 13:24:44 --> URI Class Initialized
INFO - 2018-02-17 13:24:44 --> Router Class Initialized
INFO - 2018-02-17 13:24:44 --> Output Class Initialized
INFO - 2018-02-17 13:24:44 --> Security Class Initialized
DEBUG - 2018-02-17 13:24:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-17 13:24:44 --> Input Class Initialized
INFO - 2018-02-17 13:24:44 --> Language Class Initialized
INFO - 2018-02-17 13:24:44 --> Loader Class Initialized
INFO - 2018-02-17 13:24:44 --> Helper loaded: url_helper
INFO - 2018-02-17 13:24:44 --> Helper loaded: file_helper
INFO - 2018-02-17 13:24:44 --> Helper loaded: email_helper
INFO - 2018-02-17 13:24:44 --> Helper loaded: common_helper
INFO - 2018-02-17 13:24:44 --> Database Driver Class Initialized
DEBUG - 2018-02-17 13:24:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-17 13:24:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-17 13:24:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-17 13:24:44 --> Pagination Class Initialized
INFO - 2018-02-17 13:24:44 --> Helper loaded: form_helper
INFO - 2018-02-17 13:24:44 --> Form Validation Class Initialized
INFO - 2018-02-17 13:24:44 --> Model Class Initialized
INFO - 2018-02-17 13:24:44 --> Controller Class Initialized
INFO - 2018-02-17 13:24:44 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-17 13:24:44 --> Model Class Initialized
INFO - 2018-02-17 13:24:44 --> Model Class Initialized
INFO - 2018-02-17 13:24:44 --> Model Class Initialized
INFO - 2018-02-17 13:24:44 --> Model Class Initialized
INFO - 2018-02-17 13:24:44 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-17 13:24:44 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-17 13:24:44 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-17 13:24:44 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-17 13:24:44 --> File loaded: /var/www/html/project/radio/application/views/tracks/add_edit.php
INFO - 2018-02-17 13:24:44 --> Final output sent to browser
DEBUG - 2018-02-17 13:24:44 --> Total execution time: 0.0150
INFO - 2018-02-17 13:29:23 --> Config Class Initialized
INFO - 2018-02-17 13:29:23 --> Hooks Class Initialized
DEBUG - 2018-02-17 13:29:23 --> UTF-8 Support Enabled
INFO - 2018-02-17 13:29:23 --> Utf8 Class Initialized
INFO - 2018-02-17 13:29:23 --> URI Class Initialized
INFO - 2018-02-17 13:29:23 --> Router Class Initialized
INFO - 2018-02-17 13:29:23 --> Output Class Initialized
INFO - 2018-02-17 13:29:23 --> Security Class Initialized
DEBUG - 2018-02-17 13:29:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-17 13:29:23 --> Input Class Initialized
INFO - 2018-02-17 13:29:23 --> Language Class Initialized
INFO - 2018-02-17 13:29:23 --> Loader Class Initialized
INFO - 2018-02-17 13:29:23 --> Helper loaded: url_helper
INFO - 2018-02-17 13:29:23 --> Helper loaded: file_helper
INFO - 2018-02-17 13:29:23 --> Helper loaded: email_helper
INFO - 2018-02-17 13:29:23 --> Helper loaded: common_helper
INFO - 2018-02-17 13:29:23 --> Database Driver Class Initialized
DEBUG - 2018-02-17 13:29:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-17 13:29:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-17 13:29:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-17 13:29:23 --> Pagination Class Initialized
INFO - 2018-02-17 13:29:23 --> Helper loaded: form_helper
INFO - 2018-02-17 13:29:23 --> Form Validation Class Initialized
INFO - 2018-02-17 13:29:23 --> Model Class Initialized
INFO - 2018-02-17 13:29:23 --> Controller Class Initialized
INFO - 2018-02-17 13:29:23 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-17 13:29:23 --> Model Class Initialized
INFO - 2018-02-17 13:29:23 --> Model Class Initialized
INFO - 2018-02-17 13:29:23 --> Model Class Initialized
INFO - 2018-02-17 13:29:23 --> Model Class Initialized
INFO - 2018-02-17 13:29:23 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-17 13:29:23 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-17 13:29:23 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-17 13:29:23 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-17 13:29:23 --> File loaded: /var/www/html/project/radio/application/views/tracks/index.php
INFO - 2018-02-17 13:29:23 --> Final output sent to browser
DEBUG - 2018-02-17 13:29:23 --> Total execution time: 0.0088
INFO - 2018-02-17 13:29:24 --> Config Class Initialized
INFO - 2018-02-17 13:29:24 --> Hooks Class Initialized
DEBUG - 2018-02-17 13:29:24 --> UTF-8 Support Enabled
INFO - 2018-02-17 13:29:24 --> Utf8 Class Initialized
INFO - 2018-02-17 13:29:24 --> URI Class Initialized
INFO - 2018-02-17 13:29:24 --> Router Class Initialized
INFO - 2018-02-17 13:29:24 --> Output Class Initialized
INFO - 2018-02-17 13:29:24 --> Security Class Initialized
DEBUG - 2018-02-17 13:29:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-17 13:29:24 --> Input Class Initialized
INFO - 2018-02-17 13:29:24 --> Language Class Initialized
INFO - 2018-02-17 13:29:24 --> Loader Class Initialized
INFO - 2018-02-17 13:29:24 --> Helper loaded: url_helper
INFO - 2018-02-17 13:29:24 --> Helper loaded: file_helper
INFO - 2018-02-17 13:29:24 --> Helper loaded: email_helper
INFO - 2018-02-17 13:29:24 --> Helper loaded: common_helper
INFO - 2018-02-17 13:29:24 --> Database Driver Class Initialized
DEBUG - 2018-02-17 13:29:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-17 13:29:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-17 13:29:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-17 13:29:24 --> Pagination Class Initialized
INFO - 2018-02-17 13:29:24 --> Helper loaded: form_helper
INFO - 2018-02-17 13:29:24 --> Form Validation Class Initialized
INFO - 2018-02-17 13:29:24 --> Model Class Initialized
INFO - 2018-02-17 13:29:24 --> Controller Class Initialized
INFO - 2018-02-17 13:29:24 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-17 13:29:24 --> Model Class Initialized
INFO - 2018-02-17 13:29:24 --> Model Class Initialized
INFO - 2018-02-17 13:29:24 --> Model Class Initialized
INFO - 2018-02-17 13:29:24 --> Model Class Initialized
INFO - 2018-02-17 13:29:28 --> Config Class Initialized
INFO - 2018-02-17 13:29:28 --> Hooks Class Initialized
DEBUG - 2018-02-17 13:29:28 --> UTF-8 Support Enabled
INFO - 2018-02-17 13:29:28 --> Utf8 Class Initialized
INFO - 2018-02-17 13:29:28 --> URI Class Initialized
INFO - 2018-02-17 13:29:28 --> Router Class Initialized
INFO - 2018-02-17 13:29:28 --> Output Class Initialized
INFO - 2018-02-17 13:29:28 --> Security Class Initialized
DEBUG - 2018-02-17 13:29:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-17 13:29:28 --> Input Class Initialized
INFO - 2018-02-17 13:29:28 --> Language Class Initialized
INFO - 2018-02-17 13:29:28 --> Loader Class Initialized
INFO - 2018-02-17 13:29:28 --> Helper loaded: url_helper
INFO - 2018-02-17 13:29:28 --> Helper loaded: file_helper
INFO - 2018-02-17 13:29:28 --> Helper loaded: email_helper
INFO - 2018-02-17 13:29:28 --> Helper loaded: common_helper
INFO - 2018-02-17 13:29:28 --> Database Driver Class Initialized
DEBUG - 2018-02-17 13:29:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-17 13:29:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-17 13:29:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-17 13:29:28 --> Pagination Class Initialized
INFO - 2018-02-17 13:29:28 --> Helper loaded: form_helper
INFO - 2018-02-17 13:29:28 --> Form Validation Class Initialized
INFO - 2018-02-17 13:29:28 --> Model Class Initialized
INFO - 2018-02-17 13:29:28 --> Controller Class Initialized
INFO - 2018-02-17 13:29:28 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-17 13:29:28 --> Model Class Initialized
INFO - 2018-02-17 13:29:28 --> Model Class Initialized
INFO - 2018-02-17 13:29:28 --> Model Class Initialized
INFO - 2018-02-17 13:29:28 --> Model Class Initialized
INFO - 2018-02-17 13:29:28 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-17 13:29:28 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-17 13:29:28 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-17 13:29:28 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-17 13:29:28 --> File loaded: /var/www/html/project/radio/application/views/tracks/add_edit.php
INFO - 2018-02-17 13:29:28 --> Final output sent to browser
DEBUG - 2018-02-17 13:29:28 --> Total execution time: 0.0103
INFO - 2018-02-17 13:29:44 --> Config Class Initialized
INFO - 2018-02-17 13:29:44 --> Hooks Class Initialized
DEBUG - 2018-02-17 13:29:44 --> UTF-8 Support Enabled
INFO - 2018-02-17 13:29:44 --> Utf8 Class Initialized
INFO - 2018-02-17 13:29:44 --> URI Class Initialized
INFO - 2018-02-17 13:29:44 --> Router Class Initialized
INFO - 2018-02-17 13:29:44 --> Output Class Initialized
INFO - 2018-02-17 13:29:44 --> Security Class Initialized
DEBUG - 2018-02-17 13:29:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-17 13:29:44 --> Input Class Initialized
INFO - 2018-02-17 13:29:44 --> Language Class Initialized
INFO - 2018-02-17 13:29:44 --> Loader Class Initialized
INFO - 2018-02-17 13:29:44 --> Helper loaded: url_helper
INFO - 2018-02-17 13:29:44 --> Helper loaded: file_helper
INFO - 2018-02-17 13:29:44 --> Helper loaded: email_helper
INFO - 2018-02-17 13:29:44 --> Helper loaded: common_helper
INFO - 2018-02-17 13:29:44 --> Database Driver Class Initialized
DEBUG - 2018-02-17 13:29:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-17 13:29:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-17 13:29:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-17 13:29:44 --> Pagination Class Initialized
INFO - 2018-02-17 13:29:44 --> Helper loaded: form_helper
INFO - 2018-02-17 13:29:44 --> Form Validation Class Initialized
INFO - 2018-02-17 13:29:44 --> Model Class Initialized
INFO - 2018-02-17 13:29:44 --> Controller Class Initialized
INFO - 2018-02-17 13:29:44 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-17 13:29:44 --> Model Class Initialized
INFO - 2018-02-17 13:29:44 --> Model Class Initialized
INFO - 2018-02-17 13:29:44 --> Model Class Initialized
INFO - 2018-02-17 13:29:44 --> Model Class Initialized
INFO - 2018-02-17 13:29:44 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-17 13:29:44 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-17 13:29:44 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-17 13:29:44 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-17 13:29:44 --> File loaded: /var/www/html/project/radio/application/views/tracks/index.php
INFO - 2018-02-17 13:29:44 --> Final output sent to browser
DEBUG - 2018-02-17 13:29:44 --> Total execution time: 0.0056
INFO - 2018-02-17 13:29:44 --> Config Class Initialized
INFO - 2018-02-17 13:29:44 --> Hooks Class Initialized
DEBUG - 2018-02-17 13:29:44 --> UTF-8 Support Enabled
INFO - 2018-02-17 13:29:44 --> Utf8 Class Initialized
INFO - 2018-02-17 13:29:44 --> URI Class Initialized
INFO - 2018-02-17 13:29:44 --> Router Class Initialized
INFO - 2018-02-17 13:29:44 --> Output Class Initialized
INFO - 2018-02-17 13:29:44 --> Security Class Initialized
DEBUG - 2018-02-17 13:29:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-17 13:29:44 --> Input Class Initialized
INFO - 2018-02-17 13:29:44 --> Language Class Initialized
INFO - 2018-02-17 13:29:44 --> Loader Class Initialized
INFO - 2018-02-17 13:29:44 --> Helper loaded: url_helper
INFO - 2018-02-17 13:29:44 --> Helper loaded: file_helper
INFO - 2018-02-17 13:29:44 --> Helper loaded: email_helper
INFO - 2018-02-17 13:29:44 --> Helper loaded: common_helper
INFO - 2018-02-17 13:29:44 --> Database Driver Class Initialized
DEBUG - 2018-02-17 13:29:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-17 13:29:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-17 13:29:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-17 13:29:44 --> Pagination Class Initialized
INFO - 2018-02-17 13:29:44 --> Helper loaded: form_helper
INFO - 2018-02-17 13:29:44 --> Form Validation Class Initialized
INFO - 2018-02-17 13:29:44 --> Model Class Initialized
INFO - 2018-02-17 13:29:44 --> Controller Class Initialized
INFO - 2018-02-17 13:29:44 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-17 13:29:44 --> Model Class Initialized
INFO - 2018-02-17 13:29:44 --> Model Class Initialized
INFO - 2018-02-17 13:29:44 --> Model Class Initialized
INFO - 2018-02-17 13:29:44 --> Model Class Initialized
INFO - 2018-02-17 13:29:52 --> Config Class Initialized
INFO - 2018-02-17 13:29:52 --> Hooks Class Initialized
DEBUG - 2018-02-17 13:29:52 --> UTF-8 Support Enabled
INFO - 2018-02-17 13:29:52 --> Utf8 Class Initialized
INFO - 2018-02-17 13:29:52 --> URI Class Initialized
INFO - 2018-02-17 13:29:52 --> Router Class Initialized
INFO - 2018-02-17 13:29:52 --> Output Class Initialized
INFO - 2018-02-17 13:29:52 --> Security Class Initialized
DEBUG - 2018-02-17 13:29:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-17 13:29:52 --> Input Class Initialized
INFO - 2018-02-17 13:29:52 --> Language Class Initialized
INFO - 2018-02-17 13:29:52 --> Loader Class Initialized
INFO - 2018-02-17 13:29:52 --> Helper loaded: url_helper
INFO - 2018-02-17 13:29:52 --> Helper loaded: file_helper
INFO - 2018-02-17 13:29:52 --> Helper loaded: email_helper
INFO - 2018-02-17 13:29:52 --> Helper loaded: common_helper
INFO - 2018-02-17 13:29:52 --> Database Driver Class Initialized
DEBUG - 2018-02-17 13:29:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-17 13:29:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-17 13:29:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-17 13:29:52 --> Pagination Class Initialized
INFO - 2018-02-17 13:29:52 --> Helper loaded: form_helper
INFO - 2018-02-17 13:29:52 --> Form Validation Class Initialized
INFO - 2018-02-17 13:29:52 --> Model Class Initialized
INFO - 2018-02-17 13:29:52 --> Controller Class Initialized
INFO - 2018-02-17 13:29:52 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-17 13:29:52 --> Model Class Initialized
INFO - 2018-02-17 13:29:52 --> Model Class Initialized
INFO - 2018-02-17 13:29:52 --> Model Class Initialized
INFO - 2018-02-17 13:29:52 --> Model Class Initialized
INFO - 2018-02-17 13:29:52 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-17 13:29:52 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-17 13:29:52 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-17 13:29:52 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-17 13:29:52 --> File loaded: /var/www/html/project/radio/application/views/tracks/add_edit.php
INFO - 2018-02-17 13:29:52 --> Final output sent to browser
DEBUG - 2018-02-17 13:29:52 --> Total execution time: 0.0127
INFO - 2018-02-17 13:30:19 --> Config Class Initialized
INFO - 2018-02-17 13:30:19 --> Hooks Class Initialized
DEBUG - 2018-02-17 13:30:19 --> UTF-8 Support Enabled
INFO - 2018-02-17 13:30:19 --> Utf8 Class Initialized
INFO - 2018-02-17 13:30:19 --> URI Class Initialized
INFO - 2018-02-17 13:30:19 --> Router Class Initialized
INFO - 2018-02-17 13:30:19 --> Output Class Initialized
INFO - 2018-02-17 13:30:19 --> Security Class Initialized
DEBUG - 2018-02-17 13:30:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-17 13:30:19 --> Input Class Initialized
INFO - 2018-02-17 13:30:19 --> Language Class Initialized
INFO - 2018-02-17 13:30:19 --> Loader Class Initialized
INFO - 2018-02-17 13:30:19 --> Helper loaded: url_helper
INFO - 2018-02-17 13:30:19 --> Helper loaded: file_helper
INFO - 2018-02-17 13:30:19 --> Helper loaded: email_helper
INFO - 2018-02-17 13:30:19 --> Helper loaded: common_helper
INFO - 2018-02-17 13:30:19 --> Database Driver Class Initialized
DEBUG - 2018-02-17 13:30:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-17 13:30:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-17 13:30:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-17 13:30:19 --> Pagination Class Initialized
INFO - 2018-02-17 13:30:19 --> Helper loaded: form_helper
INFO - 2018-02-17 13:30:19 --> Form Validation Class Initialized
INFO - 2018-02-17 13:30:19 --> Model Class Initialized
INFO - 2018-02-17 13:30:19 --> Controller Class Initialized
INFO - 2018-02-17 13:30:19 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-17 13:30:19 --> Model Class Initialized
INFO - 2018-02-17 13:30:19 --> Model Class Initialized
INFO - 2018-02-17 13:30:19 --> Model Class Initialized
INFO - 2018-02-17 13:30:19 --> Model Class Initialized
INFO - 2018-02-17 13:30:19 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-17 13:30:19 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-17 13:30:19 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-17 13:30:19 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-17 13:30:19 --> File loaded: /var/www/html/project/radio/application/views/tracks/add_edit.php
INFO - 2018-02-17 13:30:19 --> Final output sent to browser
DEBUG - 2018-02-17 13:30:19 --> Total execution time: 0.0147
INFO - 2018-02-17 14:20:26 --> Config Class Initialized
INFO - 2018-02-17 14:20:26 --> Hooks Class Initialized
DEBUG - 2018-02-17 14:20:26 --> UTF-8 Support Enabled
INFO - 2018-02-17 14:20:26 --> Utf8 Class Initialized
INFO - 2018-02-17 14:20:26 --> URI Class Initialized
INFO - 2018-02-17 14:20:26 --> Router Class Initialized
INFO - 2018-02-17 14:20:26 --> Output Class Initialized
INFO - 2018-02-17 14:20:26 --> Security Class Initialized
DEBUG - 2018-02-17 14:20:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-17 14:20:26 --> Input Class Initialized
INFO - 2018-02-17 14:20:26 --> Language Class Initialized
INFO - 2018-02-17 14:20:26 --> Loader Class Initialized
INFO - 2018-02-17 14:20:26 --> Helper loaded: url_helper
INFO - 2018-02-17 14:20:26 --> Helper loaded: file_helper
INFO - 2018-02-17 14:20:26 --> Helper loaded: email_helper
INFO - 2018-02-17 14:20:26 --> Helper loaded: common_helper
INFO - 2018-02-17 14:20:26 --> Database Driver Class Initialized
DEBUG - 2018-02-17 14:20:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-17 14:20:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-17 14:20:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-17 14:20:26 --> Pagination Class Initialized
INFO - 2018-02-17 14:20:26 --> Helper loaded: form_helper
INFO - 2018-02-17 14:20:26 --> Form Validation Class Initialized
INFO - 2018-02-17 14:20:26 --> Model Class Initialized
INFO - 2018-02-17 14:20:26 --> Controller Class Initialized
INFO - 2018-02-17 14:20:26 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-17 14:20:26 --> Model Class Initialized
INFO - 2018-02-17 14:20:26 --> Model Class Initialized
INFO - 2018-02-17 14:20:26 --> Model Class Initialized
INFO - 2018-02-17 14:20:26 --> Model Class Initialized
INFO - 2018-02-17 14:20:26 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-17 14:20:26 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-17 14:20:26 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-17 14:20:26 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-17 14:20:26 --> File loaded: /var/www/html/project/radio/application/views/tracks/add_edit.php
INFO - 2018-02-17 14:20:26 --> Final output sent to browser
DEBUG - 2018-02-17 14:20:26 --> Total execution time: 0.0121
INFO - 2018-02-17 14:20:32 --> Config Class Initialized
INFO - 2018-02-17 14:20:32 --> Hooks Class Initialized
DEBUG - 2018-02-17 14:20:32 --> UTF-8 Support Enabled
INFO - 2018-02-17 14:20:32 --> Utf8 Class Initialized
INFO - 2018-02-17 14:20:32 --> URI Class Initialized
INFO - 2018-02-17 14:20:32 --> Router Class Initialized
INFO - 2018-02-17 14:20:32 --> Output Class Initialized
INFO - 2018-02-17 14:20:32 --> Security Class Initialized
DEBUG - 2018-02-17 14:20:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-17 14:20:32 --> Input Class Initialized
INFO - 2018-02-17 14:20:32 --> Language Class Initialized
INFO - 2018-02-17 14:20:32 --> Loader Class Initialized
INFO - 2018-02-17 14:20:32 --> Helper loaded: url_helper
INFO - 2018-02-17 14:20:32 --> Helper loaded: file_helper
INFO - 2018-02-17 14:20:32 --> Helper loaded: email_helper
INFO - 2018-02-17 14:20:32 --> Helper loaded: common_helper
INFO - 2018-02-17 14:20:32 --> Database Driver Class Initialized
DEBUG - 2018-02-17 14:20:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-17 14:20:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-17 14:20:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-17 14:20:32 --> Pagination Class Initialized
INFO - 2018-02-17 14:20:32 --> Helper loaded: form_helper
INFO - 2018-02-17 14:20:32 --> Form Validation Class Initialized
INFO - 2018-02-17 14:20:32 --> Model Class Initialized
INFO - 2018-02-17 14:20:32 --> Controller Class Initialized
INFO - 2018-02-17 14:20:32 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-17 14:20:32 --> Model Class Initialized
INFO - 2018-02-17 14:20:32 --> Model Class Initialized
INFO - 2018-02-17 14:20:32 --> Model Class Initialized
INFO - 2018-02-17 14:20:32 --> Model Class Initialized
DEBUG - 2018-02-17 14:20:32 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-17 14:20:32 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-02-17 14:24:08 --> Config Class Initialized
INFO - 2018-02-17 14:24:08 --> Hooks Class Initialized
DEBUG - 2018-02-17 14:24:08 --> UTF-8 Support Enabled
INFO - 2018-02-17 14:24:08 --> Utf8 Class Initialized
INFO - 2018-02-17 14:24:08 --> URI Class Initialized
INFO - 2018-02-17 14:24:08 --> Router Class Initialized
INFO - 2018-02-17 14:24:08 --> Output Class Initialized
INFO - 2018-02-17 14:24:08 --> Security Class Initialized
DEBUG - 2018-02-17 14:24:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-17 14:24:08 --> Input Class Initialized
INFO - 2018-02-17 14:24:08 --> Language Class Initialized
INFO - 2018-02-17 14:24:08 --> Loader Class Initialized
INFO - 2018-02-17 14:24:08 --> Helper loaded: url_helper
INFO - 2018-02-17 14:24:08 --> Helper loaded: file_helper
INFO - 2018-02-17 14:24:08 --> Helper loaded: email_helper
INFO - 2018-02-17 14:24:08 --> Helper loaded: common_helper
INFO - 2018-02-17 14:24:08 --> Database Driver Class Initialized
DEBUG - 2018-02-17 14:24:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-17 14:24:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-17 14:24:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-17 14:24:08 --> Pagination Class Initialized
INFO - 2018-02-17 14:24:08 --> Helper loaded: form_helper
INFO - 2018-02-17 14:24:08 --> Form Validation Class Initialized
INFO - 2018-02-17 14:24:08 --> Model Class Initialized
INFO - 2018-02-17 14:24:08 --> Controller Class Initialized
INFO - 2018-02-17 14:24:08 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-17 14:24:08 --> Model Class Initialized
INFO - 2018-02-17 14:24:08 --> Model Class Initialized
INFO - 2018-02-17 14:24:08 --> Model Class Initialized
INFO - 2018-02-17 14:24:08 --> Model Class Initialized
DEBUG - 2018-02-17 14:24:08 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-17 14:24:08 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-02-17 14:25:17 --> Config Class Initialized
INFO - 2018-02-17 14:25:17 --> Hooks Class Initialized
DEBUG - 2018-02-17 14:25:17 --> UTF-8 Support Enabled
INFO - 2018-02-17 14:25:17 --> Utf8 Class Initialized
INFO - 2018-02-17 14:25:17 --> URI Class Initialized
INFO - 2018-02-17 14:25:17 --> Router Class Initialized
INFO - 2018-02-17 14:25:17 --> Output Class Initialized
INFO - 2018-02-17 14:25:17 --> Security Class Initialized
DEBUG - 2018-02-17 14:25:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-17 14:25:17 --> Input Class Initialized
INFO - 2018-02-17 14:25:17 --> Language Class Initialized
INFO - 2018-02-17 14:25:17 --> Loader Class Initialized
INFO - 2018-02-17 14:25:17 --> Helper loaded: url_helper
INFO - 2018-02-17 14:25:17 --> Helper loaded: file_helper
INFO - 2018-02-17 14:25:17 --> Helper loaded: email_helper
INFO - 2018-02-17 14:25:17 --> Helper loaded: common_helper
INFO - 2018-02-17 14:25:17 --> Database Driver Class Initialized
DEBUG - 2018-02-17 14:25:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-17 14:25:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-17 14:25:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-17 14:25:17 --> Pagination Class Initialized
INFO - 2018-02-17 14:25:17 --> Helper loaded: form_helper
INFO - 2018-02-17 14:25:17 --> Form Validation Class Initialized
INFO - 2018-02-17 14:25:17 --> Model Class Initialized
INFO - 2018-02-17 14:25:17 --> Controller Class Initialized
INFO - 2018-02-17 14:25:17 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-17 14:25:17 --> Model Class Initialized
INFO - 2018-02-17 14:25:17 --> Model Class Initialized
INFO - 2018-02-17 14:25:17 --> Model Class Initialized
INFO - 2018-02-17 14:25:17 --> Model Class Initialized
DEBUG - 2018-02-17 14:25:17 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-17 14:25:17 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2018-02-17 14:25:17 --> Severity: Notice --> Only variables should be passed by reference /var/www/html/project/radio/application/models/Trackextrafield_model.php 81
INFO - 2018-02-17 14:25:37 --> Config Class Initialized
INFO - 2018-02-17 14:25:37 --> Hooks Class Initialized
DEBUG - 2018-02-17 14:25:37 --> UTF-8 Support Enabled
INFO - 2018-02-17 14:25:37 --> Utf8 Class Initialized
INFO - 2018-02-17 14:25:37 --> URI Class Initialized
INFO - 2018-02-17 14:25:37 --> Router Class Initialized
INFO - 2018-02-17 14:25:37 --> Output Class Initialized
INFO - 2018-02-17 14:25:37 --> Security Class Initialized
DEBUG - 2018-02-17 14:25:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-17 14:25:37 --> Input Class Initialized
INFO - 2018-02-17 14:25:37 --> Language Class Initialized
INFO - 2018-02-17 14:25:37 --> Loader Class Initialized
INFO - 2018-02-17 14:25:37 --> Helper loaded: url_helper
INFO - 2018-02-17 14:25:37 --> Helper loaded: file_helper
INFO - 2018-02-17 14:25:37 --> Helper loaded: email_helper
INFO - 2018-02-17 14:25:37 --> Helper loaded: common_helper
INFO - 2018-02-17 14:25:37 --> Database Driver Class Initialized
DEBUG - 2018-02-17 14:25:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-17 14:25:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-17 14:25:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-17 14:25:37 --> Pagination Class Initialized
INFO - 2018-02-17 14:25:37 --> Helper loaded: form_helper
INFO - 2018-02-17 14:25:37 --> Form Validation Class Initialized
INFO - 2018-02-17 14:25:37 --> Model Class Initialized
INFO - 2018-02-17 14:25:37 --> Controller Class Initialized
INFO - 2018-02-17 14:25:37 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-17 14:25:37 --> Model Class Initialized
INFO - 2018-02-17 14:25:37 --> Model Class Initialized
INFO - 2018-02-17 14:25:37 --> Model Class Initialized
INFO - 2018-02-17 14:25:37 --> Model Class Initialized
DEBUG - 2018-02-17 14:25:37 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-17 14:25:37 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-02-17 14:27:46 --> Config Class Initialized
INFO - 2018-02-17 14:27:46 --> Hooks Class Initialized
DEBUG - 2018-02-17 14:27:46 --> UTF-8 Support Enabled
INFO - 2018-02-17 14:27:46 --> Utf8 Class Initialized
INFO - 2018-02-17 14:27:46 --> URI Class Initialized
INFO - 2018-02-17 14:27:46 --> Router Class Initialized
INFO - 2018-02-17 14:27:46 --> Output Class Initialized
INFO - 2018-02-17 14:27:46 --> Security Class Initialized
DEBUG - 2018-02-17 14:27:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-17 14:27:46 --> Input Class Initialized
INFO - 2018-02-17 14:27:46 --> Language Class Initialized
INFO - 2018-02-17 14:27:46 --> Loader Class Initialized
INFO - 2018-02-17 14:27:46 --> Helper loaded: url_helper
INFO - 2018-02-17 14:27:46 --> Helper loaded: file_helper
INFO - 2018-02-17 14:27:46 --> Helper loaded: email_helper
INFO - 2018-02-17 14:27:46 --> Helper loaded: common_helper
INFO - 2018-02-17 14:27:46 --> Database Driver Class Initialized
DEBUG - 2018-02-17 14:27:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-17 14:27:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-17 14:27:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-17 14:27:46 --> Pagination Class Initialized
INFO - 2018-02-17 14:27:46 --> Helper loaded: form_helper
INFO - 2018-02-17 14:27:46 --> Form Validation Class Initialized
INFO - 2018-02-17 14:27:46 --> Model Class Initialized
INFO - 2018-02-17 14:27:46 --> Controller Class Initialized
INFO - 2018-02-17 14:27:46 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-17 14:27:46 --> Model Class Initialized
INFO - 2018-02-17 14:27:46 --> Model Class Initialized
INFO - 2018-02-17 14:27:46 --> Model Class Initialized
INFO - 2018-02-17 14:27:46 --> Model Class Initialized
DEBUG - 2018-02-17 14:27:46 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-17 14:27:46 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-02-17 14:28:20 --> Config Class Initialized
INFO - 2018-02-17 14:28:20 --> Hooks Class Initialized
DEBUG - 2018-02-17 14:28:20 --> UTF-8 Support Enabled
INFO - 2018-02-17 14:28:20 --> Utf8 Class Initialized
INFO - 2018-02-17 14:28:20 --> URI Class Initialized
INFO - 2018-02-17 14:28:20 --> Router Class Initialized
INFO - 2018-02-17 14:28:20 --> Output Class Initialized
INFO - 2018-02-17 14:28:20 --> Security Class Initialized
DEBUG - 2018-02-17 14:28:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-17 14:28:20 --> Input Class Initialized
INFO - 2018-02-17 14:28:20 --> Language Class Initialized
INFO - 2018-02-17 14:28:20 --> Loader Class Initialized
INFO - 2018-02-17 14:28:20 --> Helper loaded: url_helper
INFO - 2018-02-17 14:28:20 --> Helper loaded: file_helper
INFO - 2018-02-17 14:28:20 --> Helper loaded: email_helper
INFO - 2018-02-17 14:28:20 --> Helper loaded: common_helper
INFO - 2018-02-17 14:28:20 --> Database Driver Class Initialized
DEBUG - 2018-02-17 14:28:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-17 14:28:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-17 14:28:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-17 14:28:20 --> Pagination Class Initialized
INFO - 2018-02-17 14:28:20 --> Helper loaded: form_helper
INFO - 2018-02-17 14:28:20 --> Form Validation Class Initialized
INFO - 2018-02-17 14:28:20 --> Model Class Initialized
INFO - 2018-02-17 14:28:20 --> Controller Class Initialized
INFO - 2018-02-17 14:28:20 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-17 14:28:20 --> Model Class Initialized
INFO - 2018-02-17 14:28:20 --> Model Class Initialized
INFO - 2018-02-17 14:28:20 --> Model Class Initialized
INFO - 2018-02-17 14:28:20 --> Model Class Initialized
DEBUG - 2018-02-17 14:28:20 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-17 14:28:20 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-02-17 14:29:03 --> Config Class Initialized
INFO - 2018-02-17 14:29:03 --> Hooks Class Initialized
DEBUG - 2018-02-17 14:29:03 --> UTF-8 Support Enabled
INFO - 2018-02-17 14:29:03 --> Utf8 Class Initialized
INFO - 2018-02-17 14:29:03 --> URI Class Initialized
INFO - 2018-02-17 14:29:03 --> Router Class Initialized
INFO - 2018-02-17 14:29:03 --> Output Class Initialized
INFO - 2018-02-17 14:29:03 --> Security Class Initialized
DEBUG - 2018-02-17 14:29:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-17 14:29:03 --> Input Class Initialized
INFO - 2018-02-17 14:29:03 --> Language Class Initialized
INFO - 2018-02-17 14:29:03 --> Loader Class Initialized
INFO - 2018-02-17 14:29:03 --> Helper loaded: url_helper
INFO - 2018-02-17 14:29:03 --> Helper loaded: file_helper
INFO - 2018-02-17 14:29:03 --> Helper loaded: email_helper
INFO - 2018-02-17 14:29:03 --> Helper loaded: common_helper
INFO - 2018-02-17 14:29:03 --> Database Driver Class Initialized
DEBUG - 2018-02-17 14:29:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-17 14:29:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-17 14:29:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-17 14:29:03 --> Pagination Class Initialized
INFO - 2018-02-17 14:29:03 --> Helper loaded: form_helper
INFO - 2018-02-17 14:29:03 --> Form Validation Class Initialized
INFO - 2018-02-17 14:29:03 --> Model Class Initialized
INFO - 2018-02-17 14:29:03 --> Controller Class Initialized
INFO - 2018-02-17 14:29:03 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-17 14:29:03 --> Model Class Initialized
INFO - 2018-02-17 14:29:03 --> Model Class Initialized
INFO - 2018-02-17 14:29:03 --> Model Class Initialized
INFO - 2018-02-17 14:29:03 --> Model Class Initialized
DEBUG - 2018-02-17 14:29:03 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-17 14:29:03 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-02-17 14:58:01 --> Config Class Initialized
INFO - 2018-02-17 14:58:01 --> Hooks Class Initialized
DEBUG - 2018-02-17 14:58:01 --> UTF-8 Support Enabled
INFO - 2018-02-17 14:58:01 --> Utf8 Class Initialized
INFO - 2018-02-17 14:58:01 --> URI Class Initialized
INFO - 2018-02-17 14:58:01 --> Router Class Initialized
INFO - 2018-02-17 14:58:01 --> Output Class Initialized
INFO - 2018-02-17 14:58:01 --> Security Class Initialized
DEBUG - 2018-02-17 14:58:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-17 14:58:01 --> Input Class Initialized
INFO - 2018-02-17 14:58:01 --> Language Class Initialized
INFO - 2018-02-17 14:58:01 --> Loader Class Initialized
INFO - 2018-02-17 14:58:01 --> Helper loaded: url_helper
INFO - 2018-02-17 14:58:01 --> Helper loaded: file_helper
INFO - 2018-02-17 14:58:01 --> Helper loaded: email_helper
INFO - 2018-02-17 14:58:01 --> Helper loaded: common_helper
INFO - 2018-02-17 14:58:01 --> Database Driver Class Initialized
DEBUG - 2018-02-17 14:58:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-17 14:58:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-17 14:58:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-17 14:58:01 --> Pagination Class Initialized
INFO - 2018-02-17 14:58:01 --> Helper loaded: form_helper
INFO - 2018-02-17 14:58:01 --> Form Validation Class Initialized
INFO - 2018-02-17 14:58:01 --> Model Class Initialized
INFO - 2018-02-17 14:58:01 --> Controller Class Initialized
INFO - 2018-02-17 14:58:01 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-17 14:58:01 --> Model Class Initialized
INFO - 2018-02-17 14:58:01 --> Model Class Initialized
INFO - 2018-02-17 14:58:01 --> Model Class Initialized
INFO - 2018-02-17 14:58:01 --> Model Class Initialized
INFO - 2018-02-17 14:58:01 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-17 14:58:01 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-17 14:58:01 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-17 14:58:01 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-17 14:58:01 --> File loaded: /var/www/html/project/radio/application/views/tracks/add_edit.php
INFO - 2018-02-17 14:58:01 --> Final output sent to browser
DEBUG - 2018-02-17 14:58:01 --> Total execution time: 0.0123
INFO - 2018-02-17 14:58:13 --> Config Class Initialized
INFO - 2018-02-17 14:58:13 --> Hooks Class Initialized
DEBUG - 2018-02-17 14:58:13 --> UTF-8 Support Enabled
INFO - 2018-02-17 14:58:13 --> Utf8 Class Initialized
INFO - 2018-02-17 14:58:13 --> URI Class Initialized
INFO - 2018-02-17 14:58:13 --> Router Class Initialized
INFO - 2018-02-17 14:58:13 --> Output Class Initialized
INFO - 2018-02-17 14:58:13 --> Security Class Initialized
DEBUG - 2018-02-17 14:58:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-17 14:58:13 --> Input Class Initialized
INFO - 2018-02-17 14:58:13 --> Language Class Initialized
INFO - 2018-02-17 14:58:13 --> Loader Class Initialized
INFO - 2018-02-17 14:58:13 --> Helper loaded: url_helper
INFO - 2018-02-17 14:58:13 --> Helper loaded: file_helper
INFO - 2018-02-17 14:58:13 --> Helper loaded: email_helper
INFO - 2018-02-17 14:58:13 --> Helper loaded: common_helper
INFO - 2018-02-17 14:58:13 --> Database Driver Class Initialized
DEBUG - 2018-02-17 14:58:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-17 14:58:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-17 14:58:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-17 14:58:13 --> Pagination Class Initialized
INFO - 2018-02-17 14:58:13 --> Helper loaded: form_helper
INFO - 2018-02-17 14:58:13 --> Form Validation Class Initialized
INFO - 2018-02-17 14:58:13 --> Model Class Initialized
INFO - 2018-02-17 14:58:13 --> Controller Class Initialized
INFO - 2018-02-17 14:58:13 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-17 14:58:13 --> Model Class Initialized
INFO - 2018-02-17 14:58:13 --> Model Class Initialized
INFO - 2018-02-17 14:58:13 --> Model Class Initialized
INFO - 2018-02-17 14:58:13 --> Model Class Initialized
DEBUG - 2018-02-17 14:58:13 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-17 14:58:13 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-02-17 14:58:13 --> Config Class Initialized
INFO - 2018-02-17 14:58:13 --> Hooks Class Initialized
DEBUG - 2018-02-17 14:58:13 --> UTF-8 Support Enabled
INFO - 2018-02-17 14:58:13 --> Utf8 Class Initialized
INFO - 2018-02-17 14:58:13 --> URI Class Initialized
INFO - 2018-02-17 14:58:13 --> Router Class Initialized
INFO - 2018-02-17 14:58:13 --> Output Class Initialized
INFO - 2018-02-17 14:58:13 --> Security Class Initialized
DEBUG - 2018-02-17 14:58:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-17 14:58:13 --> Input Class Initialized
INFO - 2018-02-17 14:58:13 --> Language Class Initialized
INFO - 2018-02-17 14:58:13 --> Loader Class Initialized
INFO - 2018-02-17 14:58:13 --> Helper loaded: url_helper
INFO - 2018-02-17 14:58:13 --> Helper loaded: file_helper
INFO - 2018-02-17 14:58:13 --> Helper loaded: email_helper
INFO - 2018-02-17 14:58:13 --> Helper loaded: common_helper
INFO - 2018-02-17 14:58:13 --> Database Driver Class Initialized
DEBUG - 2018-02-17 14:58:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-17 14:58:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-17 14:58:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-17 14:58:13 --> Pagination Class Initialized
INFO - 2018-02-17 14:58:13 --> Helper loaded: form_helper
INFO - 2018-02-17 14:58:13 --> Form Validation Class Initialized
INFO - 2018-02-17 14:58:13 --> Model Class Initialized
INFO - 2018-02-17 14:58:13 --> Controller Class Initialized
INFO - 2018-02-17 14:58:13 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-17 14:58:13 --> Model Class Initialized
INFO - 2018-02-17 14:58:13 --> Model Class Initialized
INFO - 2018-02-17 14:58:13 --> Model Class Initialized
INFO - 2018-02-17 14:58:13 --> Model Class Initialized
INFO - 2018-02-17 14:58:13 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-17 14:58:13 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-17 14:58:13 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-17 14:58:13 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-17 14:58:13 --> File loaded: /var/www/html/project/radio/application/views/tracks/index.php
INFO - 2018-02-17 14:58:13 --> Final output sent to browser
DEBUG - 2018-02-17 14:58:13 --> Total execution time: 0.0068
INFO - 2018-02-17 14:58:13 --> Config Class Initialized
INFO - 2018-02-17 14:58:13 --> Hooks Class Initialized
DEBUG - 2018-02-17 14:58:13 --> UTF-8 Support Enabled
INFO - 2018-02-17 14:58:13 --> Utf8 Class Initialized
INFO - 2018-02-17 14:58:13 --> URI Class Initialized
INFO - 2018-02-17 14:58:13 --> Router Class Initialized
INFO - 2018-02-17 14:58:13 --> Output Class Initialized
INFO - 2018-02-17 14:58:13 --> Security Class Initialized
DEBUG - 2018-02-17 14:58:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-17 14:58:13 --> Input Class Initialized
INFO - 2018-02-17 14:58:13 --> Language Class Initialized
INFO - 2018-02-17 14:58:13 --> Loader Class Initialized
INFO - 2018-02-17 14:58:13 --> Helper loaded: url_helper
INFO - 2018-02-17 14:58:13 --> Helper loaded: file_helper
INFO - 2018-02-17 14:58:13 --> Helper loaded: email_helper
INFO - 2018-02-17 14:58:13 --> Helper loaded: common_helper
INFO - 2018-02-17 14:58:13 --> Database Driver Class Initialized
DEBUG - 2018-02-17 14:58:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-17 14:58:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-17 14:58:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-17 14:58:13 --> Pagination Class Initialized
INFO - 2018-02-17 14:58:13 --> Helper loaded: form_helper
INFO - 2018-02-17 14:58:13 --> Form Validation Class Initialized
INFO - 2018-02-17 14:58:13 --> Model Class Initialized
INFO - 2018-02-17 14:58:13 --> Controller Class Initialized
INFO - 2018-02-17 14:58:13 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-17 14:58:13 --> Model Class Initialized
INFO - 2018-02-17 14:58:13 --> Model Class Initialized
INFO - 2018-02-17 14:58:13 --> Model Class Initialized
INFO - 2018-02-17 14:58:13 --> Model Class Initialized
INFO - 2018-02-17 14:58:21 --> Config Class Initialized
INFO - 2018-02-17 14:58:21 --> Hooks Class Initialized
DEBUG - 2018-02-17 14:58:21 --> UTF-8 Support Enabled
INFO - 2018-02-17 14:58:21 --> Utf8 Class Initialized
INFO - 2018-02-17 14:58:21 --> URI Class Initialized
INFO - 2018-02-17 14:58:21 --> Router Class Initialized
INFO - 2018-02-17 14:58:21 --> Output Class Initialized
INFO - 2018-02-17 14:58:21 --> Security Class Initialized
DEBUG - 2018-02-17 14:58:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-17 14:58:21 --> Input Class Initialized
INFO - 2018-02-17 14:58:21 --> Language Class Initialized
INFO - 2018-02-17 14:58:21 --> Loader Class Initialized
INFO - 2018-02-17 14:58:21 --> Helper loaded: url_helper
INFO - 2018-02-17 14:58:21 --> Helper loaded: file_helper
INFO - 2018-02-17 14:58:21 --> Helper loaded: email_helper
INFO - 2018-02-17 14:58:21 --> Helper loaded: common_helper
INFO - 2018-02-17 14:58:21 --> Database Driver Class Initialized
DEBUG - 2018-02-17 14:58:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-17 14:58:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-17 14:58:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-17 14:58:21 --> Pagination Class Initialized
INFO - 2018-02-17 14:58:21 --> Helper loaded: form_helper
INFO - 2018-02-17 14:58:21 --> Form Validation Class Initialized
INFO - 2018-02-17 14:58:21 --> Model Class Initialized
INFO - 2018-02-17 14:58:21 --> Controller Class Initialized
INFO - 2018-02-17 14:58:21 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-17 14:58:21 --> Model Class Initialized
INFO - 2018-02-17 14:58:21 --> Model Class Initialized
INFO - 2018-02-17 14:58:21 --> Model Class Initialized
INFO - 2018-02-17 14:58:21 --> Model Class Initialized
INFO - 2018-02-17 14:58:21 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-17 14:58:21 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-17 14:58:21 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-17 14:58:21 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-17 14:58:21 --> File loaded: /var/www/html/project/radio/application/views/tracks/add_edit.php
INFO - 2018-02-17 14:58:21 --> Final output sent to browser
DEBUG - 2018-02-17 14:58:21 --> Total execution time: 0.0095
INFO - 2018-02-17 14:58:24 --> Config Class Initialized
INFO - 2018-02-17 14:58:24 --> Hooks Class Initialized
DEBUG - 2018-02-17 14:58:24 --> UTF-8 Support Enabled
INFO - 2018-02-17 14:58:24 --> Utf8 Class Initialized
INFO - 2018-02-17 14:58:24 --> URI Class Initialized
INFO - 2018-02-17 14:58:24 --> Router Class Initialized
INFO - 2018-02-17 14:58:24 --> Output Class Initialized
INFO - 2018-02-17 14:58:24 --> Security Class Initialized
DEBUG - 2018-02-17 14:58:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-17 14:58:24 --> Input Class Initialized
INFO - 2018-02-17 14:58:24 --> Language Class Initialized
INFO - 2018-02-17 14:58:24 --> Loader Class Initialized
INFO - 2018-02-17 14:58:24 --> Helper loaded: url_helper
INFO - 2018-02-17 14:58:24 --> Helper loaded: file_helper
INFO - 2018-02-17 14:58:24 --> Helper loaded: email_helper
INFO - 2018-02-17 14:58:24 --> Helper loaded: common_helper
INFO - 2018-02-17 14:58:24 --> Database Driver Class Initialized
DEBUG - 2018-02-17 14:58:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-17 14:58:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-17 14:58:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-17 14:58:24 --> Pagination Class Initialized
INFO - 2018-02-17 14:58:24 --> Helper loaded: form_helper
INFO - 2018-02-17 14:58:24 --> Form Validation Class Initialized
INFO - 2018-02-17 14:58:24 --> Model Class Initialized
INFO - 2018-02-17 14:58:24 --> Controller Class Initialized
INFO - 2018-02-17 14:58:24 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-17 14:58:24 --> Model Class Initialized
INFO - 2018-02-17 14:58:24 --> Model Class Initialized
INFO - 2018-02-17 14:58:24 --> Model Class Initialized
INFO - 2018-02-17 14:58:24 --> Model Class Initialized
INFO - 2018-02-17 14:58:24 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-17 14:58:24 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-17 14:58:24 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-17 14:58:24 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-17 14:58:24 --> File loaded: /var/www/html/project/radio/application/views/tracks/index.php
INFO - 2018-02-17 14:58:24 --> Final output sent to browser
DEBUG - 2018-02-17 14:58:24 --> Total execution time: 0.0068
INFO - 2018-02-17 14:58:25 --> Config Class Initialized
INFO - 2018-02-17 14:58:25 --> Hooks Class Initialized
DEBUG - 2018-02-17 14:58:25 --> UTF-8 Support Enabled
INFO - 2018-02-17 14:58:25 --> Utf8 Class Initialized
INFO - 2018-02-17 14:58:25 --> URI Class Initialized
INFO - 2018-02-17 14:58:25 --> Router Class Initialized
INFO - 2018-02-17 14:58:25 --> Output Class Initialized
INFO - 2018-02-17 14:58:25 --> Security Class Initialized
DEBUG - 2018-02-17 14:58:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-17 14:58:25 --> Input Class Initialized
INFO - 2018-02-17 14:58:25 --> Language Class Initialized
INFO - 2018-02-17 14:58:25 --> Loader Class Initialized
INFO - 2018-02-17 14:58:25 --> Helper loaded: url_helper
INFO - 2018-02-17 14:58:25 --> Helper loaded: file_helper
INFO - 2018-02-17 14:58:25 --> Helper loaded: email_helper
INFO - 2018-02-17 14:58:25 --> Helper loaded: common_helper
INFO - 2018-02-17 14:58:25 --> Database Driver Class Initialized
DEBUG - 2018-02-17 14:58:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-17 14:58:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-17 14:58:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-17 14:58:25 --> Pagination Class Initialized
INFO - 2018-02-17 14:58:25 --> Helper loaded: form_helper
INFO - 2018-02-17 14:58:25 --> Form Validation Class Initialized
INFO - 2018-02-17 14:58:25 --> Model Class Initialized
INFO - 2018-02-17 14:58:25 --> Controller Class Initialized
INFO - 2018-02-17 14:58:25 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-17 14:58:25 --> Model Class Initialized
INFO - 2018-02-17 14:58:25 --> Model Class Initialized
INFO - 2018-02-17 14:58:25 --> Model Class Initialized
INFO - 2018-02-17 14:58:25 --> Model Class Initialized
INFO - 2018-02-17 14:58:30 --> Config Class Initialized
INFO - 2018-02-17 14:58:30 --> Hooks Class Initialized
DEBUG - 2018-02-17 14:58:30 --> UTF-8 Support Enabled
INFO - 2018-02-17 14:58:30 --> Utf8 Class Initialized
INFO - 2018-02-17 14:58:30 --> URI Class Initialized
INFO - 2018-02-17 14:58:30 --> Router Class Initialized
INFO - 2018-02-17 14:58:30 --> Output Class Initialized
INFO - 2018-02-17 14:58:30 --> Security Class Initialized
DEBUG - 2018-02-17 14:58:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-17 14:58:30 --> Input Class Initialized
INFO - 2018-02-17 14:58:30 --> Language Class Initialized
INFO - 2018-02-17 14:58:30 --> Loader Class Initialized
INFO - 2018-02-17 14:58:30 --> Helper loaded: url_helper
INFO - 2018-02-17 14:58:30 --> Helper loaded: file_helper
INFO - 2018-02-17 14:58:30 --> Helper loaded: email_helper
INFO - 2018-02-17 14:58:30 --> Helper loaded: common_helper
INFO - 2018-02-17 14:58:30 --> Database Driver Class Initialized
DEBUG - 2018-02-17 14:58:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-17 14:58:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-17 14:58:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-17 14:58:30 --> Pagination Class Initialized
INFO - 2018-02-17 14:58:30 --> Helper loaded: form_helper
INFO - 2018-02-17 14:58:30 --> Form Validation Class Initialized
INFO - 2018-02-17 14:58:30 --> Model Class Initialized
INFO - 2018-02-17 14:58:30 --> Controller Class Initialized
INFO - 2018-02-17 14:58:30 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-17 14:58:30 --> Model Class Initialized
INFO - 2018-02-17 14:58:30 --> Model Class Initialized
INFO - 2018-02-17 14:58:30 --> Model Class Initialized
INFO - 2018-02-17 14:58:30 --> Model Class Initialized
INFO - 2018-02-17 14:58:30 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-17 14:58:30 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-17 14:58:30 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-17 14:58:30 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-17 14:58:30 --> File loaded: /var/www/html/project/radio/application/views/tracks/add_edit.php
INFO - 2018-02-17 14:58:30 --> Final output sent to browser
DEBUG - 2018-02-17 14:58:30 --> Total execution time: 0.0083
INFO - 2018-02-17 14:59:18 --> Config Class Initialized
INFO - 2018-02-17 14:59:18 --> Hooks Class Initialized
DEBUG - 2018-02-17 14:59:18 --> UTF-8 Support Enabled
INFO - 2018-02-17 14:59:18 --> Utf8 Class Initialized
INFO - 2018-02-17 14:59:18 --> URI Class Initialized
INFO - 2018-02-17 14:59:18 --> Router Class Initialized
INFO - 2018-02-17 14:59:18 --> Output Class Initialized
INFO - 2018-02-17 14:59:18 --> Security Class Initialized
DEBUG - 2018-02-17 14:59:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-17 14:59:18 --> Input Class Initialized
INFO - 2018-02-17 14:59:18 --> Language Class Initialized
INFO - 2018-02-17 14:59:18 --> Loader Class Initialized
INFO - 2018-02-17 14:59:18 --> Helper loaded: url_helper
INFO - 2018-02-17 14:59:18 --> Helper loaded: file_helper
INFO - 2018-02-17 14:59:18 --> Helper loaded: email_helper
INFO - 2018-02-17 14:59:18 --> Helper loaded: common_helper
INFO - 2018-02-17 14:59:18 --> Database Driver Class Initialized
DEBUG - 2018-02-17 14:59:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-17 14:59:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-17 14:59:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-17 14:59:18 --> Pagination Class Initialized
INFO - 2018-02-17 14:59:18 --> Helper loaded: form_helper
INFO - 2018-02-17 14:59:18 --> Form Validation Class Initialized
INFO - 2018-02-17 14:59:18 --> Model Class Initialized
INFO - 2018-02-17 14:59:18 --> Controller Class Initialized
INFO - 2018-02-17 14:59:18 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-17 14:59:18 --> Model Class Initialized
INFO - 2018-02-17 14:59:18 --> Model Class Initialized
INFO - 2018-02-17 14:59:18 --> Model Class Initialized
INFO - 2018-02-17 14:59:18 --> Model Class Initialized
INFO - 2018-02-17 14:59:18 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-17 14:59:18 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-17 14:59:18 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-17 14:59:18 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-17 14:59:18 --> File loaded: /var/www/html/project/radio/application/views/tracks/index.php
INFO - 2018-02-17 14:59:18 --> Final output sent to browser
DEBUG - 2018-02-17 14:59:18 --> Total execution time: 0.0064
INFO - 2018-02-17 14:59:18 --> Config Class Initialized
INFO - 2018-02-17 14:59:18 --> Hooks Class Initialized
DEBUG - 2018-02-17 14:59:18 --> UTF-8 Support Enabled
INFO - 2018-02-17 14:59:18 --> Utf8 Class Initialized
INFO - 2018-02-17 14:59:18 --> URI Class Initialized
INFO - 2018-02-17 14:59:18 --> Router Class Initialized
INFO - 2018-02-17 14:59:18 --> Output Class Initialized
INFO - 2018-02-17 14:59:18 --> Security Class Initialized
DEBUG - 2018-02-17 14:59:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-17 14:59:18 --> Input Class Initialized
INFO - 2018-02-17 14:59:18 --> Language Class Initialized
INFO - 2018-02-17 14:59:18 --> Loader Class Initialized
INFO - 2018-02-17 14:59:18 --> Helper loaded: url_helper
INFO - 2018-02-17 14:59:18 --> Helper loaded: file_helper
INFO - 2018-02-17 14:59:18 --> Helper loaded: email_helper
INFO - 2018-02-17 14:59:18 --> Helper loaded: common_helper
INFO - 2018-02-17 14:59:18 --> Database Driver Class Initialized
DEBUG - 2018-02-17 14:59:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-17 14:59:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-17 14:59:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-17 14:59:18 --> Pagination Class Initialized
INFO - 2018-02-17 14:59:18 --> Helper loaded: form_helper
INFO - 2018-02-17 14:59:18 --> Form Validation Class Initialized
INFO - 2018-02-17 14:59:18 --> Model Class Initialized
INFO - 2018-02-17 14:59:18 --> Controller Class Initialized
INFO - 2018-02-17 14:59:18 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-17 14:59:18 --> Model Class Initialized
INFO - 2018-02-17 14:59:18 --> Model Class Initialized
INFO - 2018-02-17 14:59:18 --> Model Class Initialized
INFO - 2018-02-17 14:59:18 --> Model Class Initialized
INFO - 2018-02-17 14:59:26 --> Config Class Initialized
INFO - 2018-02-17 14:59:26 --> Hooks Class Initialized
DEBUG - 2018-02-17 14:59:26 --> UTF-8 Support Enabled
INFO - 2018-02-17 14:59:26 --> Utf8 Class Initialized
INFO - 2018-02-17 14:59:26 --> URI Class Initialized
INFO - 2018-02-17 14:59:26 --> Router Class Initialized
INFO - 2018-02-17 14:59:26 --> Output Class Initialized
INFO - 2018-02-17 14:59:26 --> Security Class Initialized
DEBUG - 2018-02-17 14:59:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-17 14:59:26 --> Input Class Initialized
INFO - 2018-02-17 14:59:26 --> Language Class Initialized
INFO - 2018-02-17 14:59:26 --> Loader Class Initialized
INFO - 2018-02-17 14:59:26 --> Helper loaded: url_helper
INFO - 2018-02-17 14:59:26 --> Helper loaded: file_helper
INFO - 2018-02-17 14:59:26 --> Helper loaded: email_helper
INFO - 2018-02-17 14:59:26 --> Helper loaded: common_helper
INFO - 2018-02-17 14:59:26 --> Database Driver Class Initialized
DEBUG - 2018-02-17 14:59:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-17 14:59:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-17 14:59:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-17 14:59:26 --> Pagination Class Initialized
INFO - 2018-02-17 14:59:26 --> Helper loaded: form_helper
INFO - 2018-02-17 14:59:26 --> Form Validation Class Initialized
INFO - 2018-02-17 14:59:26 --> Model Class Initialized
INFO - 2018-02-17 14:59:26 --> Controller Class Initialized
INFO - 2018-02-17 14:59:26 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-17 14:59:26 --> Model Class Initialized
INFO - 2018-02-17 14:59:26 --> Model Class Initialized
INFO - 2018-02-17 14:59:26 --> Model Class Initialized
INFO - 2018-02-17 14:59:26 --> Model Class Initialized
INFO - 2018-02-17 14:59:26 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-17 14:59:26 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-17 14:59:26 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-17 14:59:26 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-17 14:59:26 --> File loaded: /var/www/html/project/radio/application/views/tracks/add_edit.php
INFO - 2018-02-17 14:59:26 --> Final output sent to browser
DEBUG - 2018-02-17 14:59:26 --> Total execution time: 0.0142
INFO - 2018-02-17 15:00:11 --> Config Class Initialized
INFO - 2018-02-17 15:00:11 --> Hooks Class Initialized
DEBUG - 2018-02-17 15:00:11 --> UTF-8 Support Enabled
INFO - 2018-02-17 15:00:11 --> Utf8 Class Initialized
INFO - 2018-02-17 15:00:11 --> URI Class Initialized
INFO - 2018-02-17 15:00:11 --> Router Class Initialized
INFO - 2018-02-17 15:00:11 --> Output Class Initialized
INFO - 2018-02-17 15:00:11 --> Security Class Initialized
DEBUG - 2018-02-17 15:00:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-17 15:00:11 --> Input Class Initialized
INFO - 2018-02-17 15:00:11 --> Language Class Initialized
INFO - 2018-02-17 15:00:11 --> Loader Class Initialized
INFO - 2018-02-17 15:00:11 --> Helper loaded: url_helper
INFO - 2018-02-17 15:00:11 --> Helper loaded: file_helper
INFO - 2018-02-17 15:00:11 --> Helper loaded: email_helper
INFO - 2018-02-17 15:00:11 --> Helper loaded: common_helper
INFO - 2018-02-17 15:00:11 --> Database Driver Class Initialized
DEBUG - 2018-02-17 15:00:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-17 15:00:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-17 15:00:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-17 15:00:11 --> Pagination Class Initialized
INFO - 2018-02-17 15:00:11 --> Helper loaded: form_helper
INFO - 2018-02-17 15:00:11 --> Form Validation Class Initialized
INFO - 2018-02-17 15:00:11 --> Model Class Initialized
INFO - 2018-02-17 15:00:11 --> Controller Class Initialized
INFO - 2018-02-17 15:00:11 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-17 15:00:11 --> Model Class Initialized
INFO - 2018-02-17 15:00:11 --> Model Class Initialized
INFO - 2018-02-17 15:00:11 --> Model Class Initialized
INFO - 2018-02-17 15:00:11 --> Model Class Initialized
INFO - 2018-02-17 15:00:11 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-17 15:00:11 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-17 15:00:11 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-17 15:00:11 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-17 15:00:11 --> File loaded: /var/www/html/project/radio/application/views/tracks/add_edit.php
INFO - 2018-02-17 15:00:11 --> Final output sent to browser
DEBUG - 2018-02-17 15:00:11 --> Total execution time: 0.0113
INFO - 2018-02-17 15:00:28 --> Config Class Initialized
INFO - 2018-02-17 15:00:28 --> Hooks Class Initialized
DEBUG - 2018-02-17 15:00:28 --> UTF-8 Support Enabled
INFO - 2018-02-17 15:00:28 --> Utf8 Class Initialized
INFO - 2018-02-17 15:00:28 --> URI Class Initialized
INFO - 2018-02-17 15:00:28 --> Router Class Initialized
INFO - 2018-02-17 15:00:28 --> Output Class Initialized
INFO - 2018-02-17 15:00:28 --> Security Class Initialized
DEBUG - 2018-02-17 15:00:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-17 15:00:28 --> Input Class Initialized
INFO - 2018-02-17 15:00:28 --> Language Class Initialized
INFO - 2018-02-17 15:00:28 --> Loader Class Initialized
INFO - 2018-02-17 15:00:28 --> Helper loaded: url_helper
INFO - 2018-02-17 15:00:28 --> Helper loaded: file_helper
INFO - 2018-02-17 15:00:28 --> Helper loaded: email_helper
INFO - 2018-02-17 15:00:28 --> Helper loaded: common_helper
INFO - 2018-02-17 15:00:28 --> Database Driver Class Initialized
DEBUG - 2018-02-17 15:00:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-17 15:00:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-17 15:00:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-17 15:00:28 --> Pagination Class Initialized
INFO - 2018-02-17 15:00:28 --> Helper loaded: form_helper
INFO - 2018-02-17 15:00:28 --> Form Validation Class Initialized
INFO - 2018-02-17 15:00:28 --> Model Class Initialized
INFO - 2018-02-17 15:00:28 --> Controller Class Initialized
INFO - 2018-02-17 15:00:28 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-17 15:00:28 --> Model Class Initialized
INFO - 2018-02-17 15:00:28 --> Model Class Initialized
INFO - 2018-02-17 15:00:28 --> Model Class Initialized
INFO - 2018-02-17 15:00:28 --> Model Class Initialized
DEBUG - 2018-02-17 15:00:28 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-17 15:00:28 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-02-17 15:00:28 --> Config Class Initialized
INFO - 2018-02-17 15:00:28 --> Hooks Class Initialized
DEBUG - 2018-02-17 15:00:28 --> UTF-8 Support Enabled
INFO - 2018-02-17 15:00:28 --> Utf8 Class Initialized
INFO - 2018-02-17 15:00:28 --> URI Class Initialized
INFO - 2018-02-17 15:00:28 --> Router Class Initialized
INFO - 2018-02-17 15:00:28 --> Output Class Initialized
INFO - 2018-02-17 15:00:28 --> Security Class Initialized
DEBUG - 2018-02-17 15:00:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-17 15:00:28 --> Input Class Initialized
INFO - 2018-02-17 15:00:28 --> Language Class Initialized
INFO - 2018-02-17 15:00:28 --> Loader Class Initialized
INFO - 2018-02-17 15:00:28 --> Helper loaded: url_helper
INFO - 2018-02-17 15:00:28 --> Helper loaded: file_helper
INFO - 2018-02-17 15:00:28 --> Helper loaded: email_helper
INFO - 2018-02-17 15:00:28 --> Helper loaded: common_helper
INFO - 2018-02-17 15:00:28 --> Database Driver Class Initialized
DEBUG - 2018-02-17 15:00:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-17 15:00:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-17 15:00:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-17 15:00:28 --> Pagination Class Initialized
INFO - 2018-02-17 15:00:28 --> Helper loaded: form_helper
INFO - 2018-02-17 15:00:28 --> Form Validation Class Initialized
INFO - 2018-02-17 15:00:28 --> Model Class Initialized
INFO - 2018-02-17 15:00:28 --> Controller Class Initialized
INFO - 2018-02-17 15:00:28 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-17 15:00:28 --> Model Class Initialized
INFO - 2018-02-17 15:00:28 --> Model Class Initialized
INFO - 2018-02-17 15:00:28 --> Model Class Initialized
INFO - 2018-02-17 15:00:28 --> Model Class Initialized
INFO - 2018-02-17 15:00:28 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-17 15:00:28 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-17 15:00:28 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-17 15:00:28 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-17 15:00:28 --> File loaded: /var/www/html/project/radio/application/views/tracks/index.php
INFO - 2018-02-17 15:00:28 --> Final output sent to browser
DEBUG - 2018-02-17 15:00:28 --> Total execution time: 0.0031
INFO - 2018-02-17 15:00:28 --> Config Class Initialized
INFO - 2018-02-17 15:00:28 --> Hooks Class Initialized
DEBUG - 2018-02-17 15:00:28 --> UTF-8 Support Enabled
INFO - 2018-02-17 15:00:28 --> Utf8 Class Initialized
INFO - 2018-02-17 15:00:28 --> URI Class Initialized
INFO - 2018-02-17 15:00:28 --> Router Class Initialized
INFO - 2018-02-17 15:00:28 --> Output Class Initialized
INFO - 2018-02-17 15:00:28 --> Security Class Initialized
DEBUG - 2018-02-17 15:00:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-17 15:00:28 --> Input Class Initialized
INFO - 2018-02-17 15:00:28 --> Language Class Initialized
INFO - 2018-02-17 15:00:28 --> Loader Class Initialized
INFO - 2018-02-17 15:00:28 --> Helper loaded: url_helper
INFO - 2018-02-17 15:00:28 --> Helper loaded: file_helper
INFO - 2018-02-17 15:00:28 --> Helper loaded: email_helper
INFO - 2018-02-17 15:00:28 --> Helper loaded: common_helper
INFO - 2018-02-17 15:00:28 --> Database Driver Class Initialized
DEBUG - 2018-02-17 15:00:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-17 15:00:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-17 15:00:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-17 15:00:28 --> Pagination Class Initialized
INFO - 2018-02-17 15:00:28 --> Helper loaded: form_helper
INFO - 2018-02-17 15:00:28 --> Form Validation Class Initialized
INFO - 2018-02-17 15:00:28 --> Model Class Initialized
INFO - 2018-02-17 15:00:28 --> Controller Class Initialized
INFO - 2018-02-17 15:00:28 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-17 15:00:28 --> Model Class Initialized
INFO - 2018-02-17 15:00:28 --> Model Class Initialized
INFO - 2018-02-17 15:00:28 --> Model Class Initialized
INFO - 2018-02-17 15:00:28 --> Model Class Initialized
INFO - 2018-02-17 15:00:41 --> Config Class Initialized
INFO - 2018-02-17 15:00:41 --> Hooks Class Initialized
DEBUG - 2018-02-17 15:00:41 --> UTF-8 Support Enabled
INFO - 2018-02-17 15:00:41 --> Utf8 Class Initialized
INFO - 2018-02-17 15:00:41 --> URI Class Initialized
INFO - 2018-02-17 15:00:41 --> Router Class Initialized
INFO - 2018-02-17 15:00:41 --> Output Class Initialized
INFO - 2018-02-17 15:00:41 --> Security Class Initialized
DEBUG - 2018-02-17 15:00:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-17 15:00:41 --> Input Class Initialized
INFO - 2018-02-17 15:00:41 --> Language Class Initialized
INFO - 2018-02-17 15:00:41 --> Loader Class Initialized
INFO - 2018-02-17 15:00:41 --> Helper loaded: url_helper
INFO - 2018-02-17 15:00:41 --> Helper loaded: file_helper
INFO - 2018-02-17 15:00:41 --> Helper loaded: email_helper
INFO - 2018-02-17 15:00:41 --> Helper loaded: common_helper
INFO - 2018-02-17 15:00:41 --> Database Driver Class Initialized
DEBUG - 2018-02-17 15:00:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-17 15:00:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-17 15:00:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-17 15:00:41 --> Pagination Class Initialized
INFO - 2018-02-17 15:00:41 --> Helper loaded: form_helper
INFO - 2018-02-17 15:00:41 --> Form Validation Class Initialized
INFO - 2018-02-17 15:00:41 --> Model Class Initialized
INFO - 2018-02-17 15:00:41 --> Controller Class Initialized
INFO - 2018-02-17 15:00:41 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-17 15:00:41 --> Model Class Initialized
INFO - 2018-02-17 15:00:41 --> Model Class Initialized
INFO - 2018-02-17 15:00:41 --> Model Class Initialized
INFO - 2018-02-17 15:00:41 --> Model Class Initialized
INFO - 2018-02-17 15:00:41 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-17 15:00:41 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-17 15:00:41 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-17 15:00:41 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-17 15:00:41 --> File loaded: /var/www/html/project/radio/application/views/tracks/add_edit.php
INFO - 2018-02-17 15:00:41 --> Final output sent to browser
DEBUG - 2018-02-17 15:00:41 --> Total execution time: 0.0106
INFO - 2018-02-17 15:00:56 --> Config Class Initialized
INFO - 2018-02-17 15:00:56 --> Hooks Class Initialized
DEBUG - 2018-02-17 15:00:56 --> UTF-8 Support Enabled
INFO - 2018-02-17 15:00:56 --> Utf8 Class Initialized
INFO - 2018-02-17 15:00:56 --> URI Class Initialized
INFO - 2018-02-17 15:00:56 --> Router Class Initialized
INFO - 2018-02-17 15:00:56 --> Output Class Initialized
INFO - 2018-02-17 15:00:56 --> Security Class Initialized
DEBUG - 2018-02-17 15:00:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-17 15:00:56 --> Input Class Initialized
INFO - 2018-02-17 15:00:56 --> Language Class Initialized
INFO - 2018-02-17 15:00:56 --> Loader Class Initialized
INFO - 2018-02-17 15:00:56 --> Helper loaded: url_helper
INFO - 2018-02-17 15:00:56 --> Helper loaded: file_helper
INFO - 2018-02-17 15:00:56 --> Helper loaded: email_helper
INFO - 2018-02-17 15:00:56 --> Helper loaded: common_helper
INFO - 2018-02-17 15:00:56 --> Database Driver Class Initialized
DEBUG - 2018-02-17 15:00:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-17 15:00:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-17 15:00:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-17 15:00:56 --> Pagination Class Initialized
INFO - 2018-02-17 15:00:56 --> Helper loaded: form_helper
INFO - 2018-02-17 15:00:56 --> Form Validation Class Initialized
INFO - 2018-02-17 15:00:56 --> Model Class Initialized
INFO - 2018-02-17 15:00:56 --> Controller Class Initialized
INFO - 2018-02-17 15:00:56 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-17 15:00:56 --> Model Class Initialized
INFO - 2018-02-17 15:00:56 --> Model Class Initialized
INFO - 2018-02-17 15:00:56 --> Model Class Initialized
INFO - 2018-02-17 15:00:56 --> Model Class Initialized
INFO - 2018-02-17 15:01:24 --> Config Class Initialized
INFO - 2018-02-17 15:01:24 --> Hooks Class Initialized
DEBUG - 2018-02-17 15:01:24 --> UTF-8 Support Enabled
INFO - 2018-02-17 15:01:24 --> Utf8 Class Initialized
INFO - 2018-02-17 15:01:24 --> URI Class Initialized
INFO - 2018-02-17 15:01:24 --> Router Class Initialized
INFO - 2018-02-17 15:01:24 --> Output Class Initialized
INFO - 2018-02-17 15:01:24 --> Security Class Initialized
DEBUG - 2018-02-17 15:01:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-17 15:01:24 --> Input Class Initialized
INFO - 2018-02-17 15:01:24 --> Language Class Initialized
INFO - 2018-02-17 15:01:24 --> Loader Class Initialized
INFO - 2018-02-17 15:01:24 --> Helper loaded: url_helper
INFO - 2018-02-17 15:01:24 --> Helper loaded: file_helper
INFO - 2018-02-17 15:01:24 --> Helper loaded: email_helper
INFO - 2018-02-17 15:01:24 --> Helper loaded: common_helper
INFO - 2018-02-17 15:01:24 --> Database Driver Class Initialized
DEBUG - 2018-02-17 15:01:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-17 15:01:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-17 15:01:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-17 15:01:24 --> Pagination Class Initialized
INFO - 2018-02-17 15:01:24 --> Helper loaded: form_helper
INFO - 2018-02-17 15:01:24 --> Form Validation Class Initialized
INFO - 2018-02-17 15:01:24 --> Model Class Initialized
INFO - 2018-02-17 15:01:24 --> Controller Class Initialized
INFO - 2018-02-17 15:01:24 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-17 15:01:24 --> Model Class Initialized
INFO - 2018-02-17 15:01:24 --> Model Class Initialized
INFO - 2018-02-17 15:01:24 --> Model Class Initialized
INFO - 2018-02-17 15:01:24 --> Model Class Initialized
DEBUG - 2018-02-17 15:01:24 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-17 15:01:24 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-02-17 15:01:24 --> Config Class Initialized
INFO - 2018-02-17 15:01:24 --> Hooks Class Initialized
DEBUG - 2018-02-17 15:01:24 --> UTF-8 Support Enabled
INFO - 2018-02-17 15:01:24 --> Utf8 Class Initialized
INFO - 2018-02-17 15:01:24 --> URI Class Initialized
INFO - 2018-02-17 15:01:24 --> Router Class Initialized
INFO - 2018-02-17 15:01:24 --> Output Class Initialized
INFO - 2018-02-17 15:01:24 --> Security Class Initialized
DEBUG - 2018-02-17 15:01:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-17 15:01:24 --> Input Class Initialized
INFO - 2018-02-17 15:01:24 --> Language Class Initialized
INFO - 2018-02-17 15:01:24 --> Loader Class Initialized
INFO - 2018-02-17 15:01:24 --> Helper loaded: url_helper
INFO - 2018-02-17 15:01:24 --> Helper loaded: file_helper
INFO - 2018-02-17 15:01:24 --> Helper loaded: email_helper
INFO - 2018-02-17 15:01:24 --> Helper loaded: common_helper
INFO - 2018-02-17 15:01:24 --> Database Driver Class Initialized
DEBUG - 2018-02-17 15:01:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-17 15:01:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-17 15:01:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-17 15:01:24 --> Pagination Class Initialized
INFO - 2018-02-17 15:01:24 --> Helper loaded: form_helper
INFO - 2018-02-17 15:01:24 --> Form Validation Class Initialized
INFO - 2018-02-17 15:01:24 --> Model Class Initialized
INFO - 2018-02-17 15:01:24 --> Controller Class Initialized
INFO - 2018-02-17 15:01:24 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-17 15:01:24 --> Model Class Initialized
INFO - 2018-02-17 15:01:24 --> Model Class Initialized
INFO - 2018-02-17 15:01:24 --> Model Class Initialized
INFO - 2018-02-17 15:01:24 --> Model Class Initialized
INFO - 2018-02-17 15:01:24 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-17 15:01:24 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-17 15:01:24 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-17 15:01:24 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-17 15:01:24 --> File loaded: /var/www/html/project/radio/application/views/tracks/index.php
INFO - 2018-02-17 15:01:24 --> Final output sent to browser
DEBUG - 2018-02-17 15:01:24 --> Total execution time: 0.0060
INFO - 2018-02-17 15:01:24 --> Config Class Initialized
INFO - 2018-02-17 15:01:24 --> Hooks Class Initialized
DEBUG - 2018-02-17 15:01:24 --> UTF-8 Support Enabled
INFO - 2018-02-17 15:01:24 --> Utf8 Class Initialized
INFO - 2018-02-17 15:01:24 --> URI Class Initialized
INFO - 2018-02-17 15:01:24 --> Router Class Initialized
INFO - 2018-02-17 15:01:24 --> Output Class Initialized
INFO - 2018-02-17 15:01:24 --> Security Class Initialized
DEBUG - 2018-02-17 15:01:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-17 15:01:24 --> Input Class Initialized
INFO - 2018-02-17 15:01:24 --> Language Class Initialized
INFO - 2018-02-17 15:01:24 --> Loader Class Initialized
INFO - 2018-02-17 15:01:24 --> Helper loaded: url_helper
INFO - 2018-02-17 15:01:24 --> Helper loaded: file_helper
INFO - 2018-02-17 15:01:24 --> Helper loaded: email_helper
INFO - 2018-02-17 15:01:24 --> Helper loaded: common_helper
INFO - 2018-02-17 15:01:24 --> Database Driver Class Initialized
DEBUG - 2018-02-17 15:01:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-17 15:01:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-17 15:01:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-17 15:01:24 --> Pagination Class Initialized
INFO - 2018-02-17 15:01:24 --> Helper loaded: form_helper
INFO - 2018-02-17 15:01:24 --> Form Validation Class Initialized
INFO - 2018-02-17 15:01:24 --> Model Class Initialized
INFO - 2018-02-17 15:01:24 --> Controller Class Initialized
INFO - 2018-02-17 15:01:24 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-17 15:01:24 --> Model Class Initialized
INFO - 2018-02-17 15:01:24 --> Model Class Initialized
INFO - 2018-02-17 15:01:24 --> Model Class Initialized
INFO - 2018-02-17 15:01:24 --> Model Class Initialized
INFO - 2018-02-17 15:01:36 --> Config Class Initialized
INFO - 2018-02-17 15:01:36 --> Hooks Class Initialized
DEBUG - 2018-02-17 15:01:36 --> UTF-8 Support Enabled
INFO - 2018-02-17 15:01:36 --> Utf8 Class Initialized
INFO - 2018-02-17 15:01:36 --> URI Class Initialized
INFO - 2018-02-17 15:01:36 --> Router Class Initialized
INFO - 2018-02-17 15:01:36 --> Output Class Initialized
INFO - 2018-02-17 15:01:36 --> Security Class Initialized
DEBUG - 2018-02-17 15:01:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-17 15:01:36 --> Input Class Initialized
INFO - 2018-02-17 15:01:36 --> Language Class Initialized
INFO - 2018-02-17 15:01:36 --> Loader Class Initialized
INFO - 2018-02-17 15:01:36 --> Helper loaded: url_helper
INFO - 2018-02-17 15:01:36 --> Helper loaded: file_helper
INFO - 2018-02-17 15:01:36 --> Helper loaded: email_helper
INFO - 2018-02-17 15:01:36 --> Helper loaded: common_helper
INFO - 2018-02-17 15:01:36 --> Database Driver Class Initialized
DEBUG - 2018-02-17 15:01:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-17 15:01:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-17 15:01:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-17 15:01:36 --> Pagination Class Initialized
INFO - 2018-02-17 15:01:36 --> Helper loaded: form_helper
INFO - 2018-02-17 15:01:36 --> Form Validation Class Initialized
INFO - 2018-02-17 15:01:36 --> Model Class Initialized
INFO - 2018-02-17 15:01:36 --> Controller Class Initialized
INFO - 2018-02-17 15:01:36 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-17 15:01:36 --> Model Class Initialized
INFO - 2018-02-17 15:01:36 --> Model Class Initialized
INFO - 2018-02-17 15:01:36 --> Model Class Initialized
INFO - 2018-02-17 15:01:36 --> Model Class Initialized
INFO - 2018-02-17 15:01:36 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-17 15:01:36 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-17 15:01:36 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-17 15:01:36 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-17 15:01:36 --> File loaded: /var/www/html/project/radio/application/views/tracks/add_edit.php
INFO - 2018-02-17 15:01:36 --> Final output sent to browser
DEBUG - 2018-02-17 15:01:36 --> Total execution time: 0.0084
INFO - 2018-02-17 15:01:40 --> Config Class Initialized
INFO - 2018-02-17 15:01:40 --> Hooks Class Initialized
DEBUG - 2018-02-17 15:01:40 --> UTF-8 Support Enabled
INFO - 2018-02-17 15:01:40 --> Utf8 Class Initialized
INFO - 2018-02-17 15:01:40 --> URI Class Initialized
INFO - 2018-02-17 15:01:40 --> Router Class Initialized
INFO - 2018-02-17 15:01:40 --> Output Class Initialized
INFO - 2018-02-17 15:01:40 --> Security Class Initialized
DEBUG - 2018-02-17 15:01:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-17 15:01:40 --> Input Class Initialized
INFO - 2018-02-17 15:01:40 --> Language Class Initialized
INFO - 2018-02-17 15:01:40 --> Loader Class Initialized
INFO - 2018-02-17 15:01:40 --> Helper loaded: url_helper
INFO - 2018-02-17 15:01:40 --> Helper loaded: file_helper
INFO - 2018-02-17 15:01:40 --> Helper loaded: email_helper
INFO - 2018-02-17 15:01:40 --> Helper loaded: common_helper
INFO - 2018-02-17 15:01:40 --> Database Driver Class Initialized
DEBUG - 2018-02-17 15:01:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-17 15:01:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-17 15:01:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-17 15:01:40 --> Pagination Class Initialized
INFO - 2018-02-17 15:01:40 --> Helper loaded: form_helper
INFO - 2018-02-17 15:01:40 --> Form Validation Class Initialized
INFO - 2018-02-17 15:01:40 --> Model Class Initialized
INFO - 2018-02-17 15:01:40 --> Controller Class Initialized
INFO - 2018-02-17 15:01:40 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-17 15:01:40 --> Model Class Initialized
INFO - 2018-02-17 15:01:40 --> Model Class Initialized
INFO - 2018-02-17 15:01:40 --> Model Class Initialized
INFO - 2018-02-17 15:01:40 --> Model Class Initialized
INFO - 2018-02-17 15:01:48 --> Config Class Initialized
INFO - 2018-02-17 15:01:48 --> Hooks Class Initialized
DEBUG - 2018-02-17 15:01:48 --> UTF-8 Support Enabled
INFO - 2018-02-17 15:01:48 --> Utf8 Class Initialized
INFO - 2018-02-17 15:01:48 --> URI Class Initialized
INFO - 2018-02-17 15:01:48 --> Router Class Initialized
INFO - 2018-02-17 15:01:48 --> Output Class Initialized
INFO - 2018-02-17 15:01:48 --> Security Class Initialized
DEBUG - 2018-02-17 15:01:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-17 15:01:48 --> Input Class Initialized
INFO - 2018-02-17 15:01:48 --> Language Class Initialized
INFO - 2018-02-17 15:01:48 --> Loader Class Initialized
INFO - 2018-02-17 15:01:48 --> Helper loaded: url_helper
INFO - 2018-02-17 15:01:48 --> Helper loaded: file_helper
INFO - 2018-02-17 15:01:48 --> Helper loaded: email_helper
INFO - 2018-02-17 15:01:48 --> Helper loaded: common_helper
INFO - 2018-02-17 15:01:48 --> Database Driver Class Initialized
DEBUG - 2018-02-17 15:01:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-17 15:01:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-17 15:01:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-17 15:01:48 --> Pagination Class Initialized
INFO - 2018-02-17 15:01:48 --> Helper loaded: form_helper
INFO - 2018-02-17 15:01:48 --> Form Validation Class Initialized
INFO - 2018-02-17 15:01:48 --> Model Class Initialized
INFO - 2018-02-17 15:01:48 --> Controller Class Initialized
INFO - 2018-02-17 15:01:48 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-17 15:01:48 --> Model Class Initialized
INFO - 2018-02-17 15:01:48 --> Model Class Initialized
INFO - 2018-02-17 15:01:48 --> Model Class Initialized
INFO - 2018-02-17 15:01:48 --> Model Class Initialized
INFO - 2018-02-17 15:01:52 --> Config Class Initialized
INFO - 2018-02-17 15:01:52 --> Hooks Class Initialized
DEBUG - 2018-02-17 15:01:52 --> UTF-8 Support Enabled
INFO - 2018-02-17 15:01:52 --> Utf8 Class Initialized
INFO - 2018-02-17 15:01:52 --> URI Class Initialized
INFO - 2018-02-17 15:01:52 --> Router Class Initialized
INFO - 2018-02-17 15:01:52 --> Output Class Initialized
INFO - 2018-02-17 15:01:52 --> Security Class Initialized
DEBUG - 2018-02-17 15:01:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-17 15:01:52 --> Input Class Initialized
INFO - 2018-02-17 15:01:52 --> Language Class Initialized
INFO - 2018-02-17 15:01:52 --> Loader Class Initialized
INFO - 2018-02-17 15:01:52 --> Helper loaded: url_helper
INFO - 2018-02-17 15:01:52 --> Helper loaded: file_helper
INFO - 2018-02-17 15:01:52 --> Helper loaded: email_helper
INFO - 2018-02-17 15:01:52 --> Helper loaded: common_helper
INFO - 2018-02-17 15:01:52 --> Database Driver Class Initialized
DEBUG - 2018-02-17 15:01:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-17 15:01:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-17 15:01:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-17 15:01:52 --> Pagination Class Initialized
INFO - 2018-02-17 15:01:52 --> Helper loaded: form_helper
INFO - 2018-02-17 15:01:52 --> Form Validation Class Initialized
INFO - 2018-02-17 15:01:52 --> Model Class Initialized
INFO - 2018-02-17 15:01:52 --> Controller Class Initialized
INFO - 2018-02-17 15:01:52 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-17 15:01:52 --> Model Class Initialized
INFO - 2018-02-17 15:01:52 --> Model Class Initialized
INFO - 2018-02-17 15:01:52 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-17 15:01:52 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-17 15:01:52 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-17 15:01:52 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-17 15:01:52 --> File loaded: /var/www/html/project/radio/application/views/subcategory/index.php
INFO - 2018-02-17 15:01:52 --> Final output sent to browser
DEBUG - 2018-02-17 15:01:52 --> Total execution time: 0.0525
INFO - 2018-02-17 15:01:54 --> Config Class Initialized
INFO - 2018-02-17 15:01:54 --> Hooks Class Initialized
DEBUG - 2018-02-17 15:01:54 --> UTF-8 Support Enabled
INFO - 2018-02-17 15:01:54 --> Utf8 Class Initialized
INFO - 2018-02-17 15:01:54 --> URI Class Initialized
INFO - 2018-02-17 15:01:54 --> Router Class Initialized
INFO - 2018-02-17 15:01:54 --> Output Class Initialized
INFO - 2018-02-17 15:01:54 --> Security Class Initialized
DEBUG - 2018-02-17 15:01:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-17 15:01:54 --> Input Class Initialized
INFO - 2018-02-17 15:01:54 --> Language Class Initialized
INFO - 2018-02-17 15:01:54 --> Loader Class Initialized
INFO - 2018-02-17 15:01:54 --> Helper loaded: url_helper
INFO - 2018-02-17 15:01:54 --> Helper loaded: file_helper
INFO - 2018-02-17 15:01:54 --> Helper loaded: email_helper
INFO - 2018-02-17 15:01:54 --> Helper loaded: common_helper
INFO - 2018-02-17 15:01:54 --> Database Driver Class Initialized
DEBUG - 2018-02-17 15:01:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-17 15:01:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-17 15:01:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-17 15:01:54 --> Pagination Class Initialized
INFO - 2018-02-17 15:01:54 --> Helper loaded: form_helper
INFO - 2018-02-17 15:01:54 --> Form Validation Class Initialized
INFO - 2018-02-17 15:01:54 --> Model Class Initialized
INFO - 2018-02-17 15:01:54 --> Controller Class Initialized
INFO - 2018-02-17 15:01:54 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-17 15:01:54 --> Model Class Initialized
INFO - 2018-02-17 15:01:54 --> Model Class Initialized
INFO - 2018-02-17 15:01:54 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-17 15:01:54 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-17 15:01:54 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-17 15:01:54 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-17 15:01:54 --> File loaded: /var/www/html/project/radio/application/views/subcategory/add_edit.php
INFO - 2018-02-17 15:01:54 --> Final output sent to browser
DEBUG - 2018-02-17 15:01:54 --> Total execution time: 0.0054
INFO - 2018-02-17 15:02:03 --> Config Class Initialized
INFO - 2018-02-17 15:02:03 --> Hooks Class Initialized
DEBUG - 2018-02-17 15:02:03 --> UTF-8 Support Enabled
INFO - 2018-02-17 15:02:03 --> Utf8 Class Initialized
INFO - 2018-02-17 15:02:03 --> URI Class Initialized
INFO - 2018-02-17 15:02:03 --> Router Class Initialized
INFO - 2018-02-17 15:02:03 --> Output Class Initialized
INFO - 2018-02-17 15:02:03 --> Security Class Initialized
DEBUG - 2018-02-17 15:02:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-17 15:02:03 --> Input Class Initialized
INFO - 2018-02-17 15:02:03 --> Language Class Initialized
INFO - 2018-02-17 15:02:03 --> Loader Class Initialized
INFO - 2018-02-17 15:02:03 --> Helper loaded: url_helper
INFO - 2018-02-17 15:02:03 --> Helper loaded: file_helper
INFO - 2018-02-17 15:02:03 --> Helper loaded: email_helper
INFO - 2018-02-17 15:02:03 --> Helper loaded: common_helper
INFO - 2018-02-17 15:02:03 --> Database Driver Class Initialized
DEBUG - 2018-02-17 15:02:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-17 15:02:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-17 15:02:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-17 15:02:03 --> Pagination Class Initialized
INFO - 2018-02-17 15:02:03 --> Helper loaded: form_helper
INFO - 2018-02-17 15:02:03 --> Form Validation Class Initialized
INFO - 2018-02-17 15:02:03 --> Model Class Initialized
INFO - 2018-02-17 15:02:03 --> Controller Class Initialized
INFO - 2018-02-17 15:02:03 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-17 15:02:03 --> Model Class Initialized
INFO - 2018-02-17 15:02:03 --> Model Class Initialized
INFO - 2018-02-17 15:02:03 --> Config Class Initialized
INFO - 2018-02-17 15:02:03 --> Hooks Class Initialized
DEBUG - 2018-02-17 15:02:03 --> UTF-8 Support Enabled
INFO - 2018-02-17 15:02:03 --> Utf8 Class Initialized
INFO - 2018-02-17 15:02:03 --> URI Class Initialized
INFO - 2018-02-17 15:02:03 --> Router Class Initialized
INFO - 2018-02-17 15:02:03 --> Output Class Initialized
INFO - 2018-02-17 15:02:03 --> Security Class Initialized
DEBUG - 2018-02-17 15:02:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-17 15:02:03 --> Input Class Initialized
INFO - 2018-02-17 15:02:03 --> Language Class Initialized
INFO - 2018-02-17 15:02:03 --> Loader Class Initialized
INFO - 2018-02-17 15:02:03 --> Helper loaded: url_helper
INFO - 2018-02-17 15:02:03 --> Helper loaded: file_helper
INFO - 2018-02-17 15:02:03 --> Helper loaded: email_helper
INFO - 2018-02-17 15:02:03 --> Helper loaded: common_helper
INFO - 2018-02-17 15:02:03 --> Database Driver Class Initialized
DEBUG - 2018-02-17 15:02:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-17 15:02:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-17 15:02:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-17 15:02:03 --> Pagination Class Initialized
INFO - 2018-02-17 15:02:03 --> Helper loaded: form_helper
INFO - 2018-02-17 15:02:03 --> Form Validation Class Initialized
INFO - 2018-02-17 15:02:03 --> Model Class Initialized
INFO - 2018-02-17 15:02:03 --> Controller Class Initialized
INFO - 2018-02-17 15:02:03 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-17 15:02:03 --> Model Class Initialized
INFO - 2018-02-17 15:02:03 --> Model Class Initialized
DEBUG - 2018-02-17 15:02:03 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-17 15:02:03 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-02-17 15:02:03 --> Config Class Initialized
INFO - 2018-02-17 15:02:03 --> Hooks Class Initialized
DEBUG - 2018-02-17 15:02:03 --> UTF-8 Support Enabled
INFO - 2018-02-17 15:02:03 --> Utf8 Class Initialized
INFO - 2018-02-17 15:02:03 --> URI Class Initialized
INFO - 2018-02-17 15:02:03 --> Router Class Initialized
INFO - 2018-02-17 15:02:03 --> Output Class Initialized
INFO - 2018-02-17 15:02:03 --> Security Class Initialized
DEBUG - 2018-02-17 15:02:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-17 15:02:03 --> Input Class Initialized
INFO - 2018-02-17 15:02:03 --> Language Class Initialized
INFO - 2018-02-17 15:02:03 --> Loader Class Initialized
INFO - 2018-02-17 15:02:03 --> Helper loaded: url_helper
INFO - 2018-02-17 15:02:03 --> Helper loaded: file_helper
INFO - 2018-02-17 15:02:03 --> Helper loaded: email_helper
INFO - 2018-02-17 15:02:03 --> Helper loaded: common_helper
INFO - 2018-02-17 15:02:03 --> Database Driver Class Initialized
DEBUG - 2018-02-17 15:02:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-17 15:02:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-17 15:02:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-17 15:02:03 --> Pagination Class Initialized
INFO - 2018-02-17 15:02:03 --> Helper loaded: form_helper
INFO - 2018-02-17 15:02:03 --> Form Validation Class Initialized
INFO - 2018-02-17 15:02:03 --> Model Class Initialized
INFO - 2018-02-17 15:02:03 --> Controller Class Initialized
INFO - 2018-02-17 15:02:03 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-17 15:02:03 --> Model Class Initialized
INFO - 2018-02-17 15:02:03 --> Model Class Initialized
INFO - 2018-02-17 15:02:03 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-17 15:02:03 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-17 15:02:03 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-17 15:02:03 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-17 15:02:03 --> File loaded: /var/www/html/project/radio/application/views/subcategory/index.php
INFO - 2018-02-17 15:02:03 --> Final output sent to browser
DEBUG - 2018-02-17 15:02:03 --> Total execution time: 0.0062
INFO - 2018-02-17 15:02:04 --> Config Class Initialized
INFO - 2018-02-17 15:02:04 --> Hooks Class Initialized
DEBUG - 2018-02-17 15:02:04 --> UTF-8 Support Enabled
INFO - 2018-02-17 15:02:04 --> Utf8 Class Initialized
INFO - 2018-02-17 15:02:04 --> URI Class Initialized
INFO - 2018-02-17 15:02:04 --> Router Class Initialized
INFO - 2018-02-17 15:02:04 --> Output Class Initialized
INFO - 2018-02-17 15:02:04 --> Security Class Initialized
DEBUG - 2018-02-17 15:02:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-17 15:02:04 --> Input Class Initialized
INFO - 2018-02-17 15:02:04 --> Language Class Initialized
INFO - 2018-02-17 15:02:04 --> Loader Class Initialized
INFO - 2018-02-17 15:02:04 --> Helper loaded: url_helper
INFO - 2018-02-17 15:02:04 --> Helper loaded: file_helper
INFO - 2018-02-17 15:02:04 --> Helper loaded: email_helper
INFO - 2018-02-17 15:02:04 --> Helper loaded: common_helper
INFO - 2018-02-17 15:02:04 --> Database Driver Class Initialized
DEBUG - 2018-02-17 15:02:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-17 15:02:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-17 15:02:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-17 15:02:04 --> Pagination Class Initialized
INFO - 2018-02-17 15:02:04 --> Helper loaded: form_helper
INFO - 2018-02-17 15:02:04 --> Form Validation Class Initialized
INFO - 2018-02-17 15:02:04 --> Model Class Initialized
INFO - 2018-02-17 15:02:04 --> Controller Class Initialized
INFO - 2018-02-17 15:02:04 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-17 15:02:04 --> Model Class Initialized
INFO - 2018-02-17 15:02:04 --> Model Class Initialized
INFO - 2018-02-17 15:02:04 --> Model Class Initialized
INFO - 2018-02-17 15:02:04 --> Model Class Initialized
INFO - 2018-02-17 15:02:04 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-17 15:02:04 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-17 15:02:04 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-17 15:02:04 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-17 15:02:04 --> File loaded: /var/www/html/project/radio/application/views/tracks/index.php
INFO - 2018-02-17 15:02:04 --> Final output sent to browser
DEBUG - 2018-02-17 15:02:04 --> Total execution time: 0.0054
INFO - 2018-02-17 15:02:05 --> Config Class Initialized
INFO - 2018-02-17 15:02:05 --> Hooks Class Initialized
DEBUG - 2018-02-17 15:02:05 --> UTF-8 Support Enabled
INFO - 2018-02-17 15:02:05 --> Utf8 Class Initialized
INFO - 2018-02-17 15:02:05 --> URI Class Initialized
INFO - 2018-02-17 15:02:05 --> Router Class Initialized
INFO - 2018-02-17 15:02:05 --> Output Class Initialized
INFO - 2018-02-17 15:02:05 --> Security Class Initialized
DEBUG - 2018-02-17 15:02:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-17 15:02:05 --> Input Class Initialized
INFO - 2018-02-17 15:02:05 --> Language Class Initialized
INFO - 2018-02-17 15:02:05 --> Loader Class Initialized
INFO - 2018-02-17 15:02:05 --> Helper loaded: url_helper
INFO - 2018-02-17 15:02:05 --> Helper loaded: file_helper
INFO - 2018-02-17 15:02:05 --> Helper loaded: email_helper
INFO - 2018-02-17 15:02:05 --> Helper loaded: common_helper
INFO - 2018-02-17 15:02:05 --> Database Driver Class Initialized
DEBUG - 2018-02-17 15:02:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-17 15:02:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-17 15:02:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-17 15:02:05 --> Pagination Class Initialized
INFO - 2018-02-17 15:02:05 --> Helper loaded: form_helper
INFO - 2018-02-17 15:02:05 --> Form Validation Class Initialized
INFO - 2018-02-17 15:02:05 --> Model Class Initialized
INFO - 2018-02-17 15:02:05 --> Controller Class Initialized
INFO - 2018-02-17 15:02:05 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-17 15:02:05 --> Model Class Initialized
INFO - 2018-02-17 15:02:05 --> Model Class Initialized
INFO - 2018-02-17 15:02:05 --> Model Class Initialized
INFO - 2018-02-17 15:02:05 --> Model Class Initialized
INFO - 2018-02-17 15:02:08 --> Config Class Initialized
INFO - 2018-02-17 15:02:08 --> Hooks Class Initialized
DEBUG - 2018-02-17 15:02:08 --> UTF-8 Support Enabled
INFO - 2018-02-17 15:02:08 --> Utf8 Class Initialized
INFO - 2018-02-17 15:02:08 --> URI Class Initialized
INFO - 2018-02-17 15:02:08 --> Router Class Initialized
INFO - 2018-02-17 15:02:08 --> Output Class Initialized
INFO - 2018-02-17 15:02:08 --> Security Class Initialized
DEBUG - 2018-02-17 15:02:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-17 15:02:08 --> Input Class Initialized
INFO - 2018-02-17 15:02:08 --> Language Class Initialized
INFO - 2018-02-17 15:02:08 --> Loader Class Initialized
INFO - 2018-02-17 15:02:08 --> Helper loaded: url_helper
INFO - 2018-02-17 15:02:08 --> Helper loaded: file_helper
INFO - 2018-02-17 15:02:08 --> Helper loaded: email_helper
INFO - 2018-02-17 15:02:08 --> Helper loaded: common_helper
INFO - 2018-02-17 15:02:08 --> Database Driver Class Initialized
DEBUG - 2018-02-17 15:02:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-17 15:02:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-17 15:02:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-17 15:02:08 --> Pagination Class Initialized
INFO - 2018-02-17 15:02:08 --> Helper loaded: form_helper
INFO - 2018-02-17 15:02:08 --> Form Validation Class Initialized
INFO - 2018-02-17 15:02:08 --> Model Class Initialized
INFO - 2018-02-17 15:02:08 --> Controller Class Initialized
INFO - 2018-02-17 15:02:08 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-17 15:02:08 --> Model Class Initialized
INFO - 2018-02-17 15:02:08 --> Model Class Initialized
INFO - 2018-02-17 15:02:08 --> Model Class Initialized
INFO - 2018-02-17 15:02:08 --> Model Class Initialized
INFO - 2018-02-17 15:02:08 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-17 15:02:08 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-17 15:02:08 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-17 15:02:08 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-17 15:02:08 --> File loaded: /var/www/html/project/radio/application/views/tracks/add_edit.php
INFO - 2018-02-17 15:02:08 --> Final output sent to browser
DEBUG - 2018-02-17 15:02:08 --> Total execution time: 0.0126
INFO - 2018-02-17 15:02:13 --> Config Class Initialized
INFO - 2018-02-17 15:02:13 --> Hooks Class Initialized
DEBUG - 2018-02-17 15:02:13 --> UTF-8 Support Enabled
INFO - 2018-02-17 15:02:13 --> Utf8 Class Initialized
INFO - 2018-02-17 15:02:13 --> URI Class Initialized
INFO - 2018-02-17 15:02:13 --> Router Class Initialized
INFO - 2018-02-17 15:02:13 --> Output Class Initialized
INFO - 2018-02-17 15:02:13 --> Security Class Initialized
DEBUG - 2018-02-17 15:02:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-17 15:02:13 --> Input Class Initialized
INFO - 2018-02-17 15:02:13 --> Language Class Initialized
INFO - 2018-02-17 15:02:13 --> Loader Class Initialized
INFO - 2018-02-17 15:02:13 --> Helper loaded: url_helper
INFO - 2018-02-17 15:02:13 --> Helper loaded: file_helper
INFO - 2018-02-17 15:02:13 --> Helper loaded: email_helper
INFO - 2018-02-17 15:02:13 --> Helper loaded: common_helper
INFO - 2018-02-17 15:02:13 --> Database Driver Class Initialized
DEBUG - 2018-02-17 15:02:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-17 15:02:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-17 15:02:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-17 15:02:13 --> Pagination Class Initialized
INFO - 2018-02-17 15:02:13 --> Helper loaded: form_helper
INFO - 2018-02-17 15:02:13 --> Form Validation Class Initialized
INFO - 2018-02-17 15:02:13 --> Model Class Initialized
INFO - 2018-02-17 15:02:13 --> Controller Class Initialized
INFO - 2018-02-17 15:02:13 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-17 15:02:13 --> Model Class Initialized
INFO - 2018-02-17 15:02:13 --> Model Class Initialized
INFO - 2018-02-17 15:02:13 --> Model Class Initialized
INFO - 2018-02-17 15:02:13 --> Model Class Initialized
INFO - 2018-02-17 15:02:35 --> Config Class Initialized
INFO - 2018-02-17 15:02:35 --> Hooks Class Initialized
DEBUG - 2018-02-17 15:02:35 --> UTF-8 Support Enabled
INFO - 2018-02-17 15:02:35 --> Utf8 Class Initialized
INFO - 2018-02-17 15:02:35 --> URI Class Initialized
INFO - 2018-02-17 15:02:35 --> Router Class Initialized
INFO - 2018-02-17 15:02:35 --> Output Class Initialized
INFO - 2018-02-17 15:02:35 --> Security Class Initialized
DEBUG - 2018-02-17 15:02:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-17 15:02:35 --> Input Class Initialized
INFO - 2018-02-17 15:02:35 --> Language Class Initialized
INFO - 2018-02-17 15:02:35 --> Loader Class Initialized
INFO - 2018-02-17 15:02:35 --> Helper loaded: url_helper
INFO - 2018-02-17 15:02:35 --> Helper loaded: file_helper
INFO - 2018-02-17 15:02:35 --> Helper loaded: email_helper
INFO - 2018-02-17 15:02:35 --> Helper loaded: common_helper
INFO - 2018-02-17 15:02:35 --> Database Driver Class Initialized
DEBUG - 2018-02-17 15:02:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-17 15:02:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-17 15:02:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-17 15:02:35 --> Pagination Class Initialized
INFO - 2018-02-17 15:02:35 --> Helper loaded: form_helper
INFO - 2018-02-17 15:02:35 --> Form Validation Class Initialized
INFO - 2018-02-17 15:02:35 --> Model Class Initialized
INFO - 2018-02-17 15:02:35 --> Controller Class Initialized
INFO - 2018-02-17 15:02:35 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-17 15:02:35 --> Model Class Initialized
INFO - 2018-02-17 15:02:35 --> Model Class Initialized
INFO - 2018-02-17 15:02:35 --> Model Class Initialized
INFO - 2018-02-17 15:02:35 --> Model Class Initialized
DEBUG - 2018-02-17 15:02:35 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-17 15:02:35 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-02-17 15:02:35 --> Config Class Initialized
INFO - 2018-02-17 15:02:35 --> Hooks Class Initialized
DEBUG - 2018-02-17 15:02:35 --> UTF-8 Support Enabled
INFO - 2018-02-17 15:02:35 --> Utf8 Class Initialized
INFO - 2018-02-17 15:02:35 --> URI Class Initialized
INFO - 2018-02-17 15:02:35 --> Router Class Initialized
INFO - 2018-02-17 15:02:35 --> Output Class Initialized
INFO - 2018-02-17 15:02:35 --> Security Class Initialized
DEBUG - 2018-02-17 15:02:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-17 15:02:35 --> Input Class Initialized
INFO - 2018-02-17 15:02:35 --> Language Class Initialized
INFO - 2018-02-17 15:02:35 --> Loader Class Initialized
INFO - 2018-02-17 15:02:35 --> Helper loaded: url_helper
INFO - 2018-02-17 15:02:35 --> Helper loaded: file_helper
INFO - 2018-02-17 15:02:35 --> Helper loaded: email_helper
INFO - 2018-02-17 15:02:35 --> Helper loaded: common_helper
INFO - 2018-02-17 15:02:35 --> Database Driver Class Initialized
DEBUG - 2018-02-17 15:02:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-17 15:02:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-17 15:02:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-17 15:02:35 --> Pagination Class Initialized
INFO - 2018-02-17 15:02:35 --> Helper loaded: form_helper
INFO - 2018-02-17 15:02:35 --> Form Validation Class Initialized
INFO - 2018-02-17 15:02:35 --> Model Class Initialized
INFO - 2018-02-17 15:02:35 --> Controller Class Initialized
INFO - 2018-02-17 15:02:35 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-17 15:02:35 --> Model Class Initialized
INFO - 2018-02-17 15:02:35 --> Model Class Initialized
INFO - 2018-02-17 15:02:35 --> Model Class Initialized
INFO - 2018-02-17 15:02:35 --> Model Class Initialized
INFO - 2018-02-17 15:02:35 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-17 15:02:35 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-17 15:02:35 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-17 15:02:35 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-17 15:02:35 --> File loaded: /var/www/html/project/radio/application/views/tracks/index.php
INFO - 2018-02-17 15:02:35 --> Final output sent to browser
DEBUG - 2018-02-17 15:02:35 --> Total execution time: 0.0037
INFO - 2018-02-17 15:02:36 --> Config Class Initialized
INFO - 2018-02-17 15:02:36 --> Hooks Class Initialized
DEBUG - 2018-02-17 15:02:36 --> UTF-8 Support Enabled
INFO - 2018-02-17 15:02:36 --> Utf8 Class Initialized
INFO - 2018-02-17 15:02:36 --> URI Class Initialized
INFO - 2018-02-17 15:02:36 --> Router Class Initialized
INFO - 2018-02-17 15:02:36 --> Output Class Initialized
INFO - 2018-02-17 15:02:36 --> Security Class Initialized
DEBUG - 2018-02-17 15:02:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-17 15:02:36 --> Input Class Initialized
INFO - 2018-02-17 15:02:36 --> Language Class Initialized
INFO - 2018-02-17 15:02:36 --> Loader Class Initialized
INFO - 2018-02-17 15:02:36 --> Helper loaded: url_helper
INFO - 2018-02-17 15:02:36 --> Helper loaded: file_helper
INFO - 2018-02-17 15:02:36 --> Helper loaded: email_helper
INFO - 2018-02-17 15:02:36 --> Helper loaded: common_helper
INFO - 2018-02-17 15:02:36 --> Database Driver Class Initialized
DEBUG - 2018-02-17 15:02:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-17 15:02:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-17 15:02:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-17 15:02:36 --> Pagination Class Initialized
INFO - 2018-02-17 15:02:36 --> Helper loaded: form_helper
INFO - 2018-02-17 15:02:36 --> Form Validation Class Initialized
INFO - 2018-02-17 15:02:36 --> Model Class Initialized
INFO - 2018-02-17 15:02:36 --> Controller Class Initialized
INFO - 2018-02-17 15:02:36 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-17 15:02:36 --> Model Class Initialized
INFO - 2018-02-17 15:02:36 --> Model Class Initialized
INFO - 2018-02-17 15:02:36 --> Model Class Initialized
INFO - 2018-02-17 15:02:36 --> Model Class Initialized
INFO - 2018-02-17 15:04:34 --> Config Class Initialized
INFO - 2018-02-17 15:04:34 --> Hooks Class Initialized
DEBUG - 2018-02-17 15:04:34 --> UTF-8 Support Enabled
INFO - 2018-02-17 15:04:34 --> Utf8 Class Initialized
INFO - 2018-02-17 15:04:34 --> URI Class Initialized
INFO - 2018-02-17 15:04:34 --> Router Class Initialized
INFO - 2018-02-17 15:04:34 --> Output Class Initialized
INFO - 2018-02-17 15:04:34 --> Security Class Initialized
DEBUG - 2018-02-17 15:04:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-17 15:04:34 --> Input Class Initialized
INFO - 2018-02-17 15:04:34 --> Language Class Initialized
INFO - 2018-02-17 15:04:34 --> Loader Class Initialized
INFO - 2018-02-17 15:04:34 --> Helper loaded: url_helper
INFO - 2018-02-17 15:04:34 --> Helper loaded: file_helper
INFO - 2018-02-17 15:04:34 --> Helper loaded: email_helper
INFO - 2018-02-17 15:04:34 --> Helper loaded: common_helper
INFO - 2018-02-17 15:04:34 --> Database Driver Class Initialized
DEBUG - 2018-02-17 15:04:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-17 15:04:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-17 15:04:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-17 15:04:34 --> Pagination Class Initialized
INFO - 2018-02-17 15:04:34 --> Helper loaded: form_helper
INFO - 2018-02-17 15:04:34 --> Form Validation Class Initialized
INFO - 2018-02-17 15:04:34 --> Model Class Initialized
INFO - 2018-02-17 15:04:34 --> Controller Class Initialized
INFO - 2018-02-17 15:04:34 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-17 15:04:34 --> Model Class Initialized
INFO - 2018-02-17 15:04:34 --> Model Class Initialized
INFO - 2018-02-17 15:04:34 --> Model Class Initialized
INFO - 2018-02-17 15:04:34 --> Model Class Initialized
INFO - 2018-02-17 15:04:34 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-17 15:04:34 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-17 15:04:34 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-17 15:04:34 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-17 15:04:34 --> File loaded: /var/www/html/project/radio/application/views/tracks/add_edit.php
INFO - 2018-02-17 15:04:34 --> Final output sent to browser
DEBUG - 2018-02-17 15:04:34 --> Total execution time: 0.0082
INFO - 2018-02-17 15:04:41 --> Config Class Initialized
INFO - 2018-02-17 15:04:41 --> Hooks Class Initialized
DEBUG - 2018-02-17 15:04:41 --> UTF-8 Support Enabled
INFO - 2018-02-17 15:04:41 --> Utf8 Class Initialized
INFO - 2018-02-17 15:04:41 --> URI Class Initialized
INFO - 2018-02-17 15:04:41 --> Router Class Initialized
INFO - 2018-02-17 15:04:41 --> Output Class Initialized
INFO - 2018-02-17 15:04:41 --> Security Class Initialized
DEBUG - 2018-02-17 15:04:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-17 15:04:41 --> Input Class Initialized
INFO - 2018-02-17 15:04:41 --> Language Class Initialized
INFO - 2018-02-17 15:04:41 --> Loader Class Initialized
INFO - 2018-02-17 15:04:41 --> Helper loaded: url_helper
INFO - 2018-02-17 15:04:41 --> Helper loaded: file_helper
INFO - 2018-02-17 15:04:41 --> Helper loaded: email_helper
INFO - 2018-02-17 15:04:41 --> Helper loaded: common_helper
INFO - 2018-02-17 15:04:41 --> Database Driver Class Initialized
DEBUG - 2018-02-17 15:04:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-17 15:04:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-17 15:04:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-17 15:04:41 --> Pagination Class Initialized
INFO - 2018-02-17 15:04:41 --> Helper loaded: form_helper
INFO - 2018-02-17 15:04:41 --> Form Validation Class Initialized
INFO - 2018-02-17 15:04:41 --> Model Class Initialized
INFO - 2018-02-17 15:04:41 --> Controller Class Initialized
INFO - 2018-02-17 15:04:41 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-17 15:04:41 --> Model Class Initialized
INFO - 2018-02-17 15:04:41 --> Model Class Initialized
INFO - 2018-02-17 15:04:41 --> Model Class Initialized
INFO - 2018-02-17 15:04:41 --> Model Class Initialized
INFO - 2018-02-17 15:04:41 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-17 15:04:41 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-17 15:04:41 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-17 15:04:41 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-17 15:04:41 --> File loaded: /var/www/html/project/radio/application/views/tracks/index.php
INFO - 2018-02-17 15:04:41 --> Final output sent to browser
DEBUG - 2018-02-17 15:04:41 --> Total execution time: 0.0067
INFO - 2018-02-17 15:04:42 --> Config Class Initialized
INFO - 2018-02-17 15:04:42 --> Hooks Class Initialized
DEBUG - 2018-02-17 15:04:42 --> UTF-8 Support Enabled
INFO - 2018-02-17 15:04:42 --> Utf8 Class Initialized
INFO - 2018-02-17 15:04:42 --> URI Class Initialized
INFO - 2018-02-17 15:04:42 --> Router Class Initialized
INFO - 2018-02-17 15:04:42 --> Output Class Initialized
INFO - 2018-02-17 15:04:42 --> Security Class Initialized
DEBUG - 2018-02-17 15:04:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-17 15:04:42 --> Input Class Initialized
INFO - 2018-02-17 15:04:42 --> Language Class Initialized
INFO - 2018-02-17 15:04:42 --> Loader Class Initialized
INFO - 2018-02-17 15:04:42 --> Helper loaded: url_helper
INFO - 2018-02-17 15:04:42 --> Helper loaded: file_helper
INFO - 2018-02-17 15:04:42 --> Helper loaded: email_helper
INFO - 2018-02-17 15:04:42 --> Helper loaded: common_helper
INFO - 2018-02-17 15:04:42 --> Database Driver Class Initialized
DEBUG - 2018-02-17 15:04:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-17 15:04:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-17 15:04:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-17 15:04:42 --> Pagination Class Initialized
INFO - 2018-02-17 15:04:42 --> Helper loaded: form_helper
INFO - 2018-02-17 15:04:42 --> Form Validation Class Initialized
INFO - 2018-02-17 15:04:42 --> Model Class Initialized
INFO - 2018-02-17 15:04:42 --> Controller Class Initialized
INFO - 2018-02-17 15:04:42 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-17 15:04:42 --> Model Class Initialized
INFO - 2018-02-17 15:04:42 --> Model Class Initialized
INFO - 2018-02-17 15:04:42 --> Model Class Initialized
INFO - 2018-02-17 15:04:42 --> Model Class Initialized
INFO - 2018-02-17 15:04:45 --> Config Class Initialized
INFO - 2018-02-17 15:04:45 --> Hooks Class Initialized
DEBUG - 2018-02-17 15:04:45 --> UTF-8 Support Enabled
INFO - 2018-02-17 15:04:45 --> Utf8 Class Initialized
INFO - 2018-02-17 15:04:45 --> URI Class Initialized
INFO - 2018-02-17 15:04:45 --> Router Class Initialized
INFO - 2018-02-17 15:04:45 --> Output Class Initialized
INFO - 2018-02-17 15:04:45 --> Security Class Initialized
DEBUG - 2018-02-17 15:04:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-17 15:04:45 --> Input Class Initialized
INFO - 2018-02-17 15:04:45 --> Language Class Initialized
INFO - 2018-02-17 15:04:45 --> Loader Class Initialized
INFO - 2018-02-17 15:04:45 --> Helper loaded: url_helper
INFO - 2018-02-17 15:04:45 --> Helper loaded: file_helper
INFO - 2018-02-17 15:04:45 --> Helper loaded: email_helper
INFO - 2018-02-17 15:04:45 --> Helper loaded: common_helper
INFO - 2018-02-17 15:04:45 --> Database Driver Class Initialized
DEBUG - 2018-02-17 15:04:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-17 15:04:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-17 15:04:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-17 15:04:45 --> Pagination Class Initialized
INFO - 2018-02-17 15:04:45 --> Helper loaded: form_helper
INFO - 2018-02-17 15:04:45 --> Form Validation Class Initialized
INFO - 2018-02-17 15:04:45 --> Model Class Initialized
INFO - 2018-02-17 15:04:45 --> Controller Class Initialized
INFO - 2018-02-17 15:04:45 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-17 15:04:45 --> Model Class Initialized
INFO - 2018-02-17 15:04:45 --> Model Class Initialized
INFO - 2018-02-17 15:04:45 --> Model Class Initialized
INFO - 2018-02-17 15:04:45 --> Model Class Initialized
INFO - 2018-02-17 15:04:45 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-17 15:04:45 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-17 15:04:45 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-17 15:04:45 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-17 15:04:45 --> File loaded: /var/www/html/project/radio/application/views/tracks/add_edit.php
INFO - 2018-02-17 15:04:45 --> Final output sent to browser
DEBUG - 2018-02-17 15:04:45 --> Total execution time: 0.0096
INFO - 2018-02-17 15:04:48 --> Config Class Initialized
INFO - 2018-02-17 15:04:48 --> Hooks Class Initialized
DEBUG - 2018-02-17 15:04:48 --> UTF-8 Support Enabled
INFO - 2018-02-17 15:04:48 --> Utf8 Class Initialized
INFO - 2018-02-17 15:04:48 --> URI Class Initialized
INFO - 2018-02-17 15:04:48 --> Router Class Initialized
INFO - 2018-02-17 15:04:48 --> Output Class Initialized
INFO - 2018-02-17 15:04:48 --> Security Class Initialized
DEBUG - 2018-02-17 15:04:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-17 15:04:48 --> Input Class Initialized
INFO - 2018-02-17 15:04:48 --> Language Class Initialized
INFO - 2018-02-17 15:04:48 --> Loader Class Initialized
INFO - 2018-02-17 15:04:48 --> Helper loaded: url_helper
INFO - 2018-02-17 15:04:48 --> Helper loaded: file_helper
INFO - 2018-02-17 15:04:48 --> Helper loaded: email_helper
INFO - 2018-02-17 15:04:48 --> Helper loaded: common_helper
INFO - 2018-02-17 15:04:48 --> Database Driver Class Initialized
DEBUG - 2018-02-17 15:04:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-17 15:04:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-17 15:04:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-17 15:04:48 --> Pagination Class Initialized
INFO - 2018-02-17 15:04:48 --> Helper loaded: form_helper
INFO - 2018-02-17 15:04:48 --> Form Validation Class Initialized
INFO - 2018-02-17 15:04:48 --> Model Class Initialized
INFO - 2018-02-17 15:04:48 --> Controller Class Initialized
INFO - 2018-02-17 15:04:48 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-17 15:04:48 --> Model Class Initialized
INFO - 2018-02-17 15:04:48 --> Model Class Initialized
INFO - 2018-02-17 15:04:48 --> Model Class Initialized
INFO - 2018-02-17 15:04:48 --> Model Class Initialized
INFO - 2018-02-17 15:04:52 --> Config Class Initialized
INFO - 2018-02-17 15:04:52 --> Hooks Class Initialized
DEBUG - 2018-02-17 15:04:52 --> UTF-8 Support Enabled
INFO - 2018-02-17 15:04:52 --> Utf8 Class Initialized
INFO - 2018-02-17 15:04:52 --> URI Class Initialized
INFO - 2018-02-17 15:04:52 --> Router Class Initialized
INFO - 2018-02-17 15:04:52 --> Output Class Initialized
INFO - 2018-02-17 15:04:52 --> Security Class Initialized
DEBUG - 2018-02-17 15:04:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-17 15:04:52 --> Input Class Initialized
INFO - 2018-02-17 15:04:52 --> Language Class Initialized
INFO - 2018-02-17 15:04:52 --> Loader Class Initialized
INFO - 2018-02-17 15:04:52 --> Helper loaded: url_helper
INFO - 2018-02-17 15:04:52 --> Helper loaded: file_helper
INFO - 2018-02-17 15:04:52 --> Helper loaded: email_helper
INFO - 2018-02-17 15:04:52 --> Helper loaded: common_helper
INFO - 2018-02-17 15:04:52 --> Database Driver Class Initialized
DEBUG - 2018-02-17 15:04:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-17 15:04:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-17 15:04:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-17 15:04:52 --> Pagination Class Initialized
INFO - 2018-02-17 15:04:52 --> Helper loaded: form_helper
INFO - 2018-02-17 15:04:52 --> Form Validation Class Initialized
INFO - 2018-02-17 15:04:52 --> Model Class Initialized
INFO - 2018-02-17 15:04:52 --> Controller Class Initialized
INFO - 2018-02-17 15:04:52 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-17 15:04:52 --> Model Class Initialized
INFO - 2018-02-17 15:04:52 --> Model Class Initialized
INFO - 2018-02-17 15:04:52 --> Model Class Initialized
INFO - 2018-02-17 15:04:52 --> Model Class Initialized
INFO - 2018-02-17 15:08:40 --> Config Class Initialized
INFO - 2018-02-17 15:08:40 --> Hooks Class Initialized
DEBUG - 2018-02-17 15:08:40 --> UTF-8 Support Enabled
INFO - 2018-02-17 15:08:40 --> Utf8 Class Initialized
INFO - 2018-02-17 15:08:40 --> URI Class Initialized
INFO - 2018-02-17 15:08:40 --> Router Class Initialized
INFO - 2018-02-17 15:08:40 --> Output Class Initialized
INFO - 2018-02-17 15:08:40 --> Security Class Initialized
DEBUG - 2018-02-17 15:08:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-17 15:08:40 --> Input Class Initialized
INFO - 2018-02-17 15:08:40 --> Language Class Initialized
INFO - 2018-02-17 15:08:40 --> Loader Class Initialized
INFO - 2018-02-17 15:08:40 --> Helper loaded: url_helper
INFO - 2018-02-17 15:08:40 --> Helper loaded: file_helper
INFO - 2018-02-17 15:08:40 --> Helper loaded: email_helper
INFO - 2018-02-17 15:08:40 --> Helper loaded: common_helper
INFO - 2018-02-17 15:08:40 --> Database Driver Class Initialized
DEBUG - 2018-02-17 15:08:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-17 15:08:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-17 15:08:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-17 15:08:40 --> Pagination Class Initialized
INFO - 2018-02-17 15:08:40 --> Helper loaded: form_helper
INFO - 2018-02-17 15:08:40 --> Form Validation Class Initialized
INFO - 2018-02-17 15:08:40 --> Model Class Initialized
INFO - 2018-02-17 15:08:40 --> Controller Class Initialized
INFO - 2018-02-17 15:08:40 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-17 15:08:40 --> Model Class Initialized
INFO - 2018-02-17 15:08:40 --> Model Class Initialized
INFO - 2018-02-17 15:08:40 --> Model Class Initialized
INFO - 2018-02-17 15:08:40 --> Model Class Initialized
INFO - 2018-02-17 15:08:40 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-17 15:08:40 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-17 15:08:40 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-17 15:08:40 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-17 15:08:40 --> File loaded: /var/www/html/project/radio/application/views/tracks/add_edit.php
INFO - 2018-02-17 15:08:40 --> Final output sent to browser
DEBUG - 2018-02-17 15:08:40 --> Total execution time: 0.0112
INFO - 2018-02-17 15:08:49 --> Config Class Initialized
INFO - 2018-02-17 15:08:49 --> Hooks Class Initialized
DEBUG - 2018-02-17 15:08:49 --> UTF-8 Support Enabled
INFO - 2018-02-17 15:08:49 --> Utf8 Class Initialized
INFO - 2018-02-17 15:08:49 --> URI Class Initialized
INFO - 2018-02-17 15:08:49 --> Router Class Initialized
INFO - 2018-02-17 15:08:49 --> Output Class Initialized
INFO - 2018-02-17 15:08:49 --> Security Class Initialized
DEBUG - 2018-02-17 15:08:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-17 15:08:49 --> Input Class Initialized
INFO - 2018-02-17 15:08:49 --> Language Class Initialized
INFO - 2018-02-17 15:08:49 --> Loader Class Initialized
INFO - 2018-02-17 15:08:49 --> Helper loaded: url_helper
INFO - 2018-02-17 15:08:49 --> Helper loaded: file_helper
INFO - 2018-02-17 15:08:49 --> Helper loaded: email_helper
INFO - 2018-02-17 15:08:49 --> Helper loaded: common_helper
INFO - 2018-02-17 15:08:49 --> Database Driver Class Initialized
DEBUG - 2018-02-17 15:08:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-17 15:08:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-17 15:08:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-17 15:08:49 --> Pagination Class Initialized
INFO - 2018-02-17 15:08:49 --> Helper loaded: form_helper
INFO - 2018-02-17 15:08:49 --> Form Validation Class Initialized
INFO - 2018-02-17 15:08:49 --> Model Class Initialized
INFO - 2018-02-17 15:08:49 --> Controller Class Initialized
INFO - 2018-02-17 15:08:49 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-17 15:08:49 --> Model Class Initialized
INFO - 2018-02-17 15:08:49 --> Model Class Initialized
INFO - 2018-02-17 15:08:49 --> Model Class Initialized
INFO - 2018-02-17 15:08:49 --> Model Class Initialized
INFO - 2018-02-17 15:08:53 --> Config Class Initialized
INFO - 2018-02-17 15:08:53 --> Hooks Class Initialized
DEBUG - 2018-02-17 15:08:53 --> UTF-8 Support Enabled
INFO - 2018-02-17 15:08:53 --> Utf8 Class Initialized
INFO - 2018-02-17 15:08:53 --> URI Class Initialized
INFO - 2018-02-17 15:08:53 --> Router Class Initialized
INFO - 2018-02-17 15:08:53 --> Output Class Initialized
INFO - 2018-02-17 15:08:53 --> Security Class Initialized
DEBUG - 2018-02-17 15:08:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-17 15:08:53 --> Input Class Initialized
INFO - 2018-02-17 15:08:53 --> Language Class Initialized
INFO - 2018-02-17 15:08:53 --> Loader Class Initialized
INFO - 2018-02-17 15:08:53 --> Helper loaded: url_helper
INFO - 2018-02-17 15:08:53 --> Helper loaded: file_helper
INFO - 2018-02-17 15:08:53 --> Helper loaded: email_helper
INFO - 2018-02-17 15:08:53 --> Helper loaded: common_helper
INFO - 2018-02-17 15:08:53 --> Database Driver Class Initialized
DEBUG - 2018-02-17 15:08:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-17 15:08:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-17 15:08:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-17 15:08:53 --> Pagination Class Initialized
INFO - 2018-02-17 15:08:53 --> Helper loaded: form_helper
INFO - 2018-02-17 15:08:53 --> Form Validation Class Initialized
INFO - 2018-02-17 15:08:53 --> Model Class Initialized
INFO - 2018-02-17 15:08:53 --> Controller Class Initialized
INFO - 2018-02-17 15:08:53 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-17 15:08:53 --> Model Class Initialized
INFO - 2018-02-17 15:08:53 --> Model Class Initialized
INFO - 2018-02-17 15:08:53 --> Model Class Initialized
INFO - 2018-02-17 15:08:53 --> Model Class Initialized
INFO - 2018-02-17 15:09:00 --> Config Class Initialized
INFO - 2018-02-17 15:09:00 --> Hooks Class Initialized
DEBUG - 2018-02-17 15:09:00 --> UTF-8 Support Enabled
INFO - 2018-02-17 15:09:00 --> Utf8 Class Initialized
INFO - 2018-02-17 15:09:00 --> URI Class Initialized
INFO - 2018-02-17 15:09:00 --> Router Class Initialized
INFO - 2018-02-17 15:09:00 --> Output Class Initialized
INFO - 2018-02-17 15:09:00 --> Security Class Initialized
DEBUG - 2018-02-17 15:09:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-17 15:09:00 --> Input Class Initialized
INFO - 2018-02-17 15:09:00 --> Language Class Initialized
INFO - 2018-02-17 15:09:00 --> Loader Class Initialized
INFO - 2018-02-17 15:09:00 --> Helper loaded: url_helper
INFO - 2018-02-17 15:09:00 --> Helper loaded: file_helper
INFO - 2018-02-17 15:09:00 --> Helper loaded: email_helper
INFO - 2018-02-17 15:09:00 --> Helper loaded: common_helper
INFO - 2018-02-17 15:09:00 --> Database Driver Class Initialized
DEBUG - 2018-02-17 15:09:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-17 15:09:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-17 15:09:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-17 15:09:00 --> Pagination Class Initialized
INFO - 2018-02-17 15:09:00 --> Helper loaded: form_helper
INFO - 2018-02-17 15:09:00 --> Form Validation Class Initialized
INFO - 2018-02-17 15:09:00 --> Model Class Initialized
INFO - 2018-02-17 15:09:00 --> Controller Class Initialized
INFO - 2018-02-17 15:09:00 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-17 15:09:00 --> Model Class Initialized
INFO - 2018-02-17 15:09:00 --> Model Class Initialized
INFO - 2018-02-17 15:09:00 --> Model Class Initialized
INFO - 2018-02-17 15:09:00 --> Model Class Initialized
INFO - 2018-02-17 15:09:05 --> Config Class Initialized
INFO - 2018-02-17 15:09:05 --> Hooks Class Initialized
DEBUG - 2018-02-17 15:09:05 --> UTF-8 Support Enabled
INFO - 2018-02-17 15:09:05 --> Utf8 Class Initialized
INFO - 2018-02-17 15:09:05 --> URI Class Initialized
INFO - 2018-02-17 15:09:05 --> Router Class Initialized
INFO - 2018-02-17 15:09:05 --> Output Class Initialized
INFO - 2018-02-17 15:09:05 --> Security Class Initialized
DEBUG - 2018-02-17 15:09:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-17 15:09:05 --> Input Class Initialized
INFO - 2018-02-17 15:09:05 --> Language Class Initialized
INFO - 2018-02-17 15:09:05 --> Loader Class Initialized
INFO - 2018-02-17 15:09:05 --> Helper loaded: url_helper
INFO - 2018-02-17 15:09:05 --> Helper loaded: file_helper
INFO - 2018-02-17 15:09:05 --> Helper loaded: email_helper
INFO - 2018-02-17 15:09:05 --> Helper loaded: common_helper
INFO - 2018-02-17 15:09:05 --> Database Driver Class Initialized
DEBUG - 2018-02-17 15:09:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-17 15:09:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-17 15:09:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-17 15:09:05 --> Pagination Class Initialized
INFO - 2018-02-17 15:09:05 --> Helper loaded: form_helper
INFO - 2018-02-17 15:09:05 --> Form Validation Class Initialized
INFO - 2018-02-17 15:09:05 --> Model Class Initialized
INFO - 2018-02-17 15:09:05 --> Controller Class Initialized
INFO - 2018-02-17 15:09:05 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-17 15:09:05 --> Model Class Initialized
INFO - 2018-02-17 15:09:05 --> Model Class Initialized
INFO - 2018-02-17 15:09:05 --> Model Class Initialized
INFO - 2018-02-17 15:09:05 --> Model Class Initialized
INFO - 2018-02-17 15:09:13 --> Config Class Initialized
INFO - 2018-02-17 15:09:13 --> Hooks Class Initialized
DEBUG - 2018-02-17 15:09:13 --> UTF-8 Support Enabled
INFO - 2018-02-17 15:09:13 --> Utf8 Class Initialized
INFO - 2018-02-17 15:09:13 --> URI Class Initialized
INFO - 2018-02-17 15:09:13 --> Router Class Initialized
INFO - 2018-02-17 15:09:13 --> Output Class Initialized
INFO - 2018-02-17 15:09:13 --> Security Class Initialized
DEBUG - 2018-02-17 15:09:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-17 15:09:13 --> Input Class Initialized
INFO - 2018-02-17 15:09:13 --> Language Class Initialized
INFO - 2018-02-17 15:09:13 --> Loader Class Initialized
INFO - 2018-02-17 15:09:13 --> Helper loaded: url_helper
INFO - 2018-02-17 15:09:13 --> Helper loaded: file_helper
INFO - 2018-02-17 15:09:13 --> Helper loaded: email_helper
INFO - 2018-02-17 15:09:13 --> Helper loaded: common_helper
INFO - 2018-02-17 15:09:13 --> Database Driver Class Initialized
DEBUG - 2018-02-17 15:09:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-17 15:09:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-17 15:09:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-17 15:09:13 --> Pagination Class Initialized
INFO - 2018-02-17 15:09:13 --> Helper loaded: form_helper
INFO - 2018-02-17 15:09:13 --> Form Validation Class Initialized
INFO - 2018-02-17 15:09:13 --> Model Class Initialized
INFO - 2018-02-17 15:09:13 --> Controller Class Initialized
INFO - 2018-02-17 15:09:13 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-17 15:09:13 --> Model Class Initialized
INFO - 2018-02-17 15:09:13 --> Model Class Initialized
INFO - 2018-02-17 15:09:13 --> Model Class Initialized
INFO - 2018-02-17 15:09:13 --> Model Class Initialized
INFO - 2018-02-17 15:09:21 --> Config Class Initialized
INFO - 2018-02-17 15:09:21 --> Hooks Class Initialized
DEBUG - 2018-02-17 15:09:21 --> UTF-8 Support Enabled
INFO - 2018-02-17 15:09:21 --> Utf8 Class Initialized
INFO - 2018-02-17 15:09:21 --> URI Class Initialized
INFO - 2018-02-17 15:09:21 --> Router Class Initialized
INFO - 2018-02-17 15:09:21 --> Output Class Initialized
INFO - 2018-02-17 15:09:21 --> Security Class Initialized
DEBUG - 2018-02-17 15:09:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-17 15:09:21 --> Input Class Initialized
INFO - 2018-02-17 15:09:21 --> Language Class Initialized
INFO - 2018-02-17 15:09:21 --> Loader Class Initialized
INFO - 2018-02-17 15:09:21 --> Helper loaded: url_helper
INFO - 2018-02-17 15:09:21 --> Helper loaded: file_helper
INFO - 2018-02-17 15:09:21 --> Helper loaded: email_helper
INFO - 2018-02-17 15:09:21 --> Helper loaded: common_helper
INFO - 2018-02-17 15:09:21 --> Database Driver Class Initialized
DEBUG - 2018-02-17 15:09:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-17 15:09:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-17 15:09:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-17 15:09:21 --> Pagination Class Initialized
INFO - 2018-02-17 15:09:21 --> Helper loaded: form_helper
INFO - 2018-02-17 15:09:21 --> Form Validation Class Initialized
INFO - 2018-02-17 15:09:21 --> Model Class Initialized
INFO - 2018-02-17 15:09:21 --> Controller Class Initialized
INFO - 2018-02-17 15:09:21 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-17 15:09:21 --> Model Class Initialized
INFO - 2018-02-17 15:09:21 --> Model Class Initialized
INFO - 2018-02-17 15:09:21 --> Model Class Initialized
INFO - 2018-02-17 15:09:21 --> Model Class Initialized
INFO - 2018-02-17 15:09:22 --> Config Class Initialized
INFO - 2018-02-17 15:09:22 --> Hooks Class Initialized
DEBUG - 2018-02-17 15:09:22 --> UTF-8 Support Enabled
INFO - 2018-02-17 15:09:22 --> Utf8 Class Initialized
INFO - 2018-02-17 15:09:22 --> URI Class Initialized
INFO - 2018-02-17 15:09:22 --> Router Class Initialized
INFO - 2018-02-17 15:09:22 --> Output Class Initialized
INFO - 2018-02-17 15:09:22 --> Security Class Initialized
DEBUG - 2018-02-17 15:09:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-17 15:09:22 --> Input Class Initialized
INFO - 2018-02-17 15:09:22 --> Language Class Initialized
INFO - 2018-02-17 15:09:22 --> Loader Class Initialized
INFO - 2018-02-17 15:09:22 --> Helper loaded: url_helper
INFO - 2018-02-17 15:09:22 --> Helper loaded: file_helper
INFO - 2018-02-17 15:09:22 --> Helper loaded: email_helper
INFO - 2018-02-17 15:09:22 --> Helper loaded: common_helper
INFO - 2018-02-17 15:09:22 --> Database Driver Class Initialized
DEBUG - 2018-02-17 15:09:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-17 15:09:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-17 15:09:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-17 15:09:22 --> Pagination Class Initialized
INFO - 2018-02-17 15:09:22 --> Helper loaded: form_helper
INFO - 2018-02-17 15:09:22 --> Form Validation Class Initialized
INFO - 2018-02-17 15:09:22 --> Model Class Initialized
INFO - 2018-02-17 15:09:22 --> Controller Class Initialized
INFO - 2018-02-17 15:09:22 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-17 15:09:22 --> Model Class Initialized
INFO - 2018-02-17 15:09:22 --> Model Class Initialized
INFO - 2018-02-17 15:09:22 --> Model Class Initialized
INFO - 2018-02-17 15:09:22 --> Model Class Initialized
INFO - 2018-02-17 15:09:34 --> Config Class Initialized
INFO - 2018-02-17 15:09:34 --> Hooks Class Initialized
DEBUG - 2018-02-17 15:09:34 --> UTF-8 Support Enabled
INFO - 2018-02-17 15:09:34 --> Utf8 Class Initialized
INFO - 2018-02-17 15:09:34 --> URI Class Initialized
INFO - 2018-02-17 15:09:34 --> Router Class Initialized
INFO - 2018-02-17 15:09:34 --> Output Class Initialized
INFO - 2018-02-17 15:09:34 --> Security Class Initialized
DEBUG - 2018-02-17 15:09:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-17 15:09:34 --> Input Class Initialized
INFO - 2018-02-17 15:09:34 --> Language Class Initialized
INFO - 2018-02-17 15:09:34 --> Loader Class Initialized
INFO - 2018-02-17 15:09:34 --> Helper loaded: url_helper
INFO - 2018-02-17 15:09:34 --> Helper loaded: file_helper
INFO - 2018-02-17 15:09:34 --> Helper loaded: email_helper
INFO - 2018-02-17 15:09:34 --> Helper loaded: common_helper
INFO - 2018-02-17 15:09:34 --> Database Driver Class Initialized
DEBUG - 2018-02-17 15:09:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-17 15:09:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-17 15:09:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-17 15:09:34 --> Pagination Class Initialized
INFO - 2018-02-17 15:09:34 --> Helper loaded: form_helper
INFO - 2018-02-17 15:09:34 --> Form Validation Class Initialized
INFO - 2018-02-17 15:09:34 --> Model Class Initialized
INFO - 2018-02-17 15:09:34 --> Controller Class Initialized
INFO - 2018-02-17 15:09:34 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-17 15:09:34 --> Model Class Initialized
INFO - 2018-02-17 15:09:34 --> Model Class Initialized
INFO - 2018-02-17 15:09:34 --> Model Class Initialized
INFO - 2018-02-17 15:09:34 --> Model Class Initialized
INFO - 2018-02-17 15:09:36 --> Config Class Initialized
INFO - 2018-02-17 15:09:36 --> Hooks Class Initialized
DEBUG - 2018-02-17 15:09:36 --> UTF-8 Support Enabled
INFO - 2018-02-17 15:09:36 --> Utf8 Class Initialized
INFO - 2018-02-17 15:09:36 --> URI Class Initialized
INFO - 2018-02-17 15:09:36 --> Router Class Initialized
INFO - 2018-02-17 15:09:36 --> Output Class Initialized
INFO - 2018-02-17 15:09:36 --> Security Class Initialized
DEBUG - 2018-02-17 15:09:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-17 15:09:36 --> Input Class Initialized
INFO - 2018-02-17 15:09:36 --> Language Class Initialized
INFO - 2018-02-17 15:09:36 --> Loader Class Initialized
INFO - 2018-02-17 15:09:36 --> Helper loaded: url_helper
INFO - 2018-02-17 15:09:36 --> Helper loaded: file_helper
INFO - 2018-02-17 15:09:36 --> Helper loaded: email_helper
INFO - 2018-02-17 15:09:36 --> Helper loaded: common_helper
INFO - 2018-02-17 15:09:36 --> Database Driver Class Initialized
DEBUG - 2018-02-17 15:09:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-17 15:09:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-17 15:09:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-17 15:09:36 --> Pagination Class Initialized
INFO - 2018-02-17 15:09:36 --> Helper loaded: form_helper
INFO - 2018-02-17 15:09:36 --> Form Validation Class Initialized
INFO - 2018-02-17 15:09:36 --> Model Class Initialized
INFO - 2018-02-17 15:09:36 --> Controller Class Initialized
INFO - 2018-02-17 15:09:36 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-17 15:09:36 --> Model Class Initialized
INFO - 2018-02-17 15:09:36 --> Model Class Initialized
INFO - 2018-02-17 15:09:36 --> Model Class Initialized
INFO - 2018-02-17 15:09:36 --> Model Class Initialized
INFO - 2018-02-17 15:09:36 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-17 15:09:36 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-17 15:09:36 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-17 15:09:36 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-17 15:09:36 --> File loaded: /var/www/html/project/radio/application/views/tracks/add_edit.php
INFO - 2018-02-17 15:09:36 --> Final output sent to browser
DEBUG - 2018-02-17 15:09:36 --> Total execution time: 0.0120
INFO - 2018-02-17 15:09:45 --> Config Class Initialized
INFO - 2018-02-17 15:09:45 --> Hooks Class Initialized
DEBUG - 2018-02-17 15:09:45 --> UTF-8 Support Enabled
INFO - 2018-02-17 15:09:45 --> Utf8 Class Initialized
INFO - 2018-02-17 15:09:45 --> URI Class Initialized
INFO - 2018-02-17 15:09:45 --> Router Class Initialized
INFO - 2018-02-17 15:09:45 --> Output Class Initialized
INFO - 2018-02-17 15:09:45 --> Security Class Initialized
DEBUG - 2018-02-17 15:09:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-17 15:09:45 --> Input Class Initialized
INFO - 2018-02-17 15:09:45 --> Language Class Initialized
INFO - 2018-02-17 15:09:45 --> Loader Class Initialized
INFO - 2018-02-17 15:09:45 --> Helper loaded: url_helper
INFO - 2018-02-17 15:09:45 --> Helper loaded: file_helper
INFO - 2018-02-17 15:09:45 --> Helper loaded: email_helper
INFO - 2018-02-17 15:09:45 --> Helper loaded: common_helper
INFO - 2018-02-17 15:09:45 --> Database Driver Class Initialized
DEBUG - 2018-02-17 15:09:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-17 15:09:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-17 15:09:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-17 15:09:45 --> Pagination Class Initialized
INFO - 2018-02-17 15:09:45 --> Helper loaded: form_helper
INFO - 2018-02-17 15:09:45 --> Form Validation Class Initialized
INFO - 2018-02-17 15:09:45 --> Model Class Initialized
INFO - 2018-02-17 15:09:45 --> Controller Class Initialized
INFO - 2018-02-17 15:09:45 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-17 15:09:45 --> Model Class Initialized
INFO - 2018-02-17 15:09:45 --> Model Class Initialized
INFO - 2018-02-17 15:09:45 --> Model Class Initialized
INFO - 2018-02-17 15:09:45 --> Model Class Initialized
INFO - 2018-02-17 15:10:01 --> Config Class Initialized
INFO - 2018-02-17 15:10:01 --> Hooks Class Initialized
DEBUG - 2018-02-17 15:10:01 --> UTF-8 Support Enabled
INFO - 2018-02-17 15:10:01 --> Utf8 Class Initialized
INFO - 2018-02-17 15:10:01 --> URI Class Initialized
INFO - 2018-02-17 15:10:01 --> Router Class Initialized
INFO - 2018-02-17 15:10:01 --> Output Class Initialized
INFO - 2018-02-17 15:10:01 --> Security Class Initialized
DEBUG - 2018-02-17 15:10:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-17 15:10:01 --> Input Class Initialized
INFO - 2018-02-17 15:10:01 --> Language Class Initialized
INFO - 2018-02-17 15:10:01 --> Loader Class Initialized
INFO - 2018-02-17 15:10:01 --> Helper loaded: url_helper
INFO - 2018-02-17 15:10:01 --> Helper loaded: file_helper
INFO - 2018-02-17 15:10:01 --> Helper loaded: email_helper
INFO - 2018-02-17 15:10:01 --> Helper loaded: common_helper
INFO - 2018-02-17 15:10:01 --> Database Driver Class Initialized
DEBUG - 2018-02-17 15:10:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-17 15:10:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-17 15:10:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-17 15:10:01 --> Pagination Class Initialized
INFO - 2018-02-17 15:10:01 --> Helper loaded: form_helper
INFO - 2018-02-17 15:10:01 --> Form Validation Class Initialized
INFO - 2018-02-17 15:10:01 --> Model Class Initialized
INFO - 2018-02-17 15:10:01 --> Controller Class Initialized
INFO - 2018-02-17 15:10:01 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-17 15:10:01 --> Model Class Initialized
INFO - 2018-02-17 15:10:01 --> Model Class Initialized
INFO - 2018-02-17 15:10:01 --> Model Class Initialized
INFO - 2018-02-17 15:10:01 --> Model Class Initialized
DEBUG - 2018-02-17 15:10:01 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-17 15:10:01 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2018-02-17 15:10:01 --> Severity: Notice --> Undefined variable: dataArray /var/www/html/project/radio/application/models/Trackextrafield_model.php 102
INFO - 2018-02-17 15:10:01 --> Config Class Initialized
INFO - 2018-02-17 15:10:01 --> Hooks Class Initialized
DEBUG - 2018-02-17 15:10:01 --> UTF-8 Support Enabled
INFO - 2018-02-17 15:10:01 --> Utf8 Class Initialized
INFO - 2018-02-17 15:10:01 --> URI Class Initialized
INFO - 2018-02-17 15:10:01 --> Router Class Initialized
INFO - 2018-02-17 15:10:01 --> Output Class Initialized
INFO - 2018-02-17 15:10:01 --> Security Class Initialized
DEBUG - 2018-02-17 15:10:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-17 15:10:01 --> Input Class Initialized
INFO - 2018-02-17 15:10:01 --> Language Class Initialized
INFO - 2018-02-17 15:10:01 --> Loader Class Initialized
INFO - 2018-02-17 15:10:01 --> Helper loaded: url_helper
INFO - 2018-02-17 15:10:01 --> Helper loaded: file_helper
INFO - 2018-02-17 15:10:01 --> Helper loaded: email_helper
INFO - 2018-02-17 15:10:01 --> Helper loaded: common_helper
INFO - 2018-02-17 15:10:01 --> Database Driver Class Initialized
DEBUG - 2018-02-17 15:10:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-17 15:10:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-17 15:10:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-17 15:10:01 --> Pagination Class Initialized
INFO - 2018-02-17 15:10:01 --> Helper loaded: form_helper
INFO - 2018-02-17 15:10:01 --> Form Validation Class Initialized
INFO - 2018-02-17 15:10:01 --> Model Class Initialized
INFO - 2018-02-17 15:10:01 --> Controller Class Initialized
INFO - 2018-02-17 15:10:01 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-17 15:10:01 --> Model Class Initialized
INFO - 2018-02-17 15:10:01 --> Model Class Initialized
INFO - 2018-02-17 15:10:01 --> Model Class Initialized
INFO - 2018-02-17 15:10:01 --> Model Class Initialized
INFO - 2018-02-17 15:10:01 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-17 15:10:01 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-17 15:10:01 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-17 15:10:01 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-17 15:10:01 --> File loaded: /var/www/html/project/radio/application/views/tracks/index.php
INFO - 2018-02-17 15:10:01 --> Final output sent to browser
DEBUG - 2018-02-17 15:10:01 --> Total execution time: 0.0034
INFO - 2018-02-17 15:10:02 --> Config Class Initialized
INFO - 2018-02-17 15:10:02 --> Hooks Class Initialized
DEBUG - 2018-02-17 15:10:02 --> UTF-8 Support Enabled
INFO - 2018-02-17 15:10:02 --> Utf8 Class Initialized
INFO - 2018-02-17 15:10:02 --> URI Class Initialized
INFO - 2018-02-17 15:10:02 --> Router Class Initialized
INFO - 2018-02-17 15:10:02 --> Output Class Initialized
INFO - 2018-02-17 15:10:02 --> Security Class Initialized
DEBUG - 2018-02-17 15:10:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-17 15:10:02 --> Input Class Initialized
INFO - 2018-02-17 15:10:02 --> Language Class Initialized
INFO - 2018-02-17 15:10:02 --> Loader Class Initialized
INFO - 2018-02-17 15:10:02 --> Helper loaded: url_helper
INFO - 2018-02-17 15:10:02 --> Helper loaded: file_helper
INFO - 2018-02-17 15:10:02 --> Helper loaded: email_helper
INFO - 2018-02-17 15:10:02 --> Helper loaded: common_helper
INFO - 2018-02-17 15:10:02 --> Database Driver Class Initialized
DEBUG - 2018-02-17 15:10:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-17 15:10:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-17 15:10:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-17 15:10:02 --> Pagination Class Initialized
INFO - 2018-02-17 15:10:02 --> Helper loaded: form_helper
INFO - 2018-02-17 15:10:02 --> Form Validation Class Initialized
INFO - 2018-02-17 15:10:02 --> Model Class Initialized
INFO - 2018-02-17 15:10:02 --> Controller Class Initialized
INFO - 2018-02-17 15:10:02 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-17 15:10:02 --> Model Class Initialized
INFO - 2018-02-17 15:10:02 --> Model Class Initialized
INFO - 2018-02-17 15:10:02 --> Model Class Initialized
INFO - 2018-02-17 15:10:02 --> Model Class Initialized
INFO - 2018-02-17 15:10:04 --> Config Class Initialized
INFO - 2018-02-17 15:10:04 --> Hooks Class Initialized
DEBUG - 2018-02-17 15:10:04 --> UTF-8 Support Enabled
INFO - 2018-02-17 15:10:04 --> Utf8 Class Initialized
INFO - 2018-02-17 15:10:04 --> URI Class Initialized
INFO - 2018-02-17 15:10:04 --> Router Class Initialized
INFO - 2018-02-17 15:10:04 --> Output Class Initialized
INFO - 2018-02-17 15:10:04 --> Security Class Initialized
DEBUG - 2018-02-17 15:10:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-17 15:10:04 --> Input Class Initialized
INFO - 2018-02-17 15:10:04 --> Language Class Initialized
INFO - 2018-02-17 15:10:04 --> Loader Class Initialized
INFO - 2018-02-17 15:10:04 --> Helper loaded: url_helper
INFO - 2018-02-17 15:10:04 --> Helper loaded: file_helper
INFO - 2018-02-17 15:10:04 --> Helper loaded: email_helper
INFO - 2018-02-17 15:10:04 --> Helper loaded: common_helper
INFO - 2018-02-17 15:10:04 --> Database Driver Class Initialized
DEBUG - 2018-02-17 15:10:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-17 15:10:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-17 15:10:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-17 15:10:04 --> Pagination Class Initialized
INFO - 2018-02-17 15:10:04 --> Helper loaded: form_helper
INFO - 2018-02-17 15:10:04 --> Form Validation Class Initialized
INFO - 2018-02-17 15:10:04 --> Model Class Initialized
INFO - 2018-02-17 15:10:04 --> Controller Class Initialized
INFO - 2018-02-17 15:10:04 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-17 15:10:04 --> Model Class Initialized
INFO - 2018-02-17 15:10:04 --> Model Class Initialized
INFO - 2018-02-17 15:10:04 --> Model Class Initialized
INFO - 2018-02-17 15:10:04 --> Model Class Initialized
INFO - 2018-02-17 15:10:04 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-17 15:10:04 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-17 15:10:04 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-17 15:10:04 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-17 15:10:04 --> File loaded: /var/www/html/project/radio/application/views/tracks/add_edit.php
INFO - 2018-02-17 15:10:04 --> Final output sent to browser
DEBUG - 2018-02-17 15:10:04 --> Total execution time: 0.0107
INFO - 2018-02-17 15:10:10 --> Config Class Initialized
INFO - 2018-02-17 15:10:10 --> Hooks Class Initialized
DEBUG - 2018-02-17 15:10:10 --> UTF-8 Support Enabled
INFO - 2018-02-17 15:10:10 --> Utf8 Class Initialized
INFO - 2018-02-17 15:10:10 --> URI Class Initialized
INFO - 2018-02-17 15:10:10 --> Router Class Initialized
INFO - 2018-02-17 15:10:10 --> Output Class Initialized
INFO - 2018-02-17 15:10:10 --> Security Class Initialized
DEBUG - 2018-02-17 15:10:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-17 15:10:10 --> Input Class Initialized
INFO - 2018-02-17 15:10:10 --> Language Class Initialized
INFO - 2018-02-17 15:10:10 --> Loader Class Initialized
INFO - 2018-02-17 15:10:10 --> Helper loaded: url_helper
INFO - 2018-02-17 15:10:10 --> Helper loaded: file_helper
INFO - 2018-02-17 15:10:10 --> Helper loaded: email_helper
INFO - 2018-02-17 15:10:10 --> Helper loaded: common_helper
INFO - 2018-02-17 15:10:10 --> Database Driver Class Initialized
DEBUG - 2018-02-17 15:10:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-17 15:10:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-17 15:10:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-17 15:10:10 --> Pagination Class Initialized
INFO - 2018-02-17 15:10:10 --> Helper loaded: form_helper
INFO - 2018-02-17 15:10:10 --> Form Validation Class Initialized
INFO - 2018-02-17 15:10:10 --> Model Class Initialized
INFO - 2018-02-17 15:10:10 --> Controller Class Initialized
INFO - 2018-02-17 15:10:10 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-17 15:10:10 --> Model Class Initialized
INFO - 2018-02-17 15:10:10 --> Model Class Initialized
INFO - 2018-02-17 15:10:10 --> Model Class Initialized
INFO - 2018-02-17 15:10:10 --> Model Class Initialized
INFO - 2018-02-17 15:10:10 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-17 15:10:10 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-17 15:10:10 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-17 15:10:10 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-17 15:10:10 --> File loaded: /var/www/html/project/radio/application/views/tracks/add_edit.php
INFO - 2018-02-17 15:10:10 --> Final output sent to browser
DEBUG - 2018-02-17 15:10:10 --> Total execution time: 0.0111
INFO - 2018-02-17 15:10:14 --> Config Class Initialized
INFO - 2018-02-17 15:10:14 --> Hooks Class Initialized
DEBUG - 2018-02-17 15:10:14 --> UTF-8 Support Enabled
INFO - 2018-02-17 15:10:14 --> Utf8 Class Initialized
INFO - 2018-02-17 15:10:14 --> URI Class Initialized
INFO - 2018-02-17 15:10:14 --> Router Class Initialized
INFO - 2018-02-17 15:10:14 --> Output Class Initialized
INFO - 2018-02-17 15:10:14 --> Security Class Initialized
DEBUG - 2018-02-17 15:10:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-17 15:10:14 --> Input Class Initialized
INFO - 2018-02-17 15:10:14 --> Language Class Initialized
INFO - 2018-02-17 15:10:14 --> Loader Class Initialized
INFO - 2018-02-17 15:10:14 --> Helper loaded: url_helper
INFO - 2018-02-17 15:10:14 --> Helper loaded: file_helper
INFO - 2018-02-17 15:10:14 --> Helper loaded: email_helper
INFO - 2018-02-17 15:10:14 --> Helper loaded: common_helper
INFO - 2018-02-17 15:10:14 --> Database Driver Class Initialized
DEBUG - 2018-02-17 15:10:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-17 15:10:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-17 15:10:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-17 15:10:14 --> Pagination Class Initialized
INFO - 2018-02-17 15:10:14 --> Helper loaded: form_helper
INFO - 2018-02-17 15:10:14 --> Form Validation Class Initialized
INFO - 2018-02-17 15:10:14 --> Model Class Initialized
INFO - 2018-02-17 15:10:14 --> Controller Class Initialized
INFO - 2018-02-17 15:10:14 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-17 15:10:14 --> Model Class Initialized
INFO - 2018-02-17 15:10:14 --> Model Class Initialized
INFO - 2018-02-17 15:10:14 --> Model Class Initialized
INFO - 2018-02-17 15:10:14 --> Model Class Initialized
INFO - 2018-02-17 15:10:18 --> Config Class Initialized
INFO - 2018-02-17 15:10:18 --> Hooks Class Initialized
DEBUG - 2018-02-17 15:10:18 --> UTF-8 Support Enabled
INFO - 2018-02-17 15:10:18 --> Utf8 Class Initialized
INFO - 2018-02-17 15:10:18 --> URI Class Initialized
INFO - 2018-02-17 15:10:18 --> Router Class Initialized
INFO - 2018-02-17 15:10:18 --> Output Class Initialized
INFO - 2018-02-17 15:10:18 --> Security Class Initialized
DEBUG - 2018-02-17 15:10:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-17 15:10:18 --> Input Class Initialized
INFO - 2018-02-17 15:10:18 --> Language Class Initialized
INFO - 2018-02-17 15:10:18 --> Loader Class Initialized
INFO - 2018-02-17 15:10:18 --> Helper loaded: url_helper
INFO - 2018-02-17 15:10:18 --> Helper loaded: file_helper
INFO - 2018-02-17 15:10:18 --> Helper loaded: email_helper
INFO - 2018-02-17 15:10:18 --> Helper loaded: common_helper
INFO - 2018-02-17 15:10:18 --> Database Driver Class Initialized
DEBUG - 2018-02-17 15:10:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-17 15:10:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-17 15:10:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-17 15:10:18 --> Pagination Class Initialized
INFO - 2018-02-17 15:10:18 --> Helper loaded: form_helper
INFO - 2018-02-17 15:10:18 --> Form Validation Class Initialized
INFO - 2018-02-17 15:10:18 --> Model Class Initialized
INFO - 2018-02-17 15:10:18 --> Controller Class Initialized
INFO - 2018-02-17 15:10:18 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-17 15:10:18 --> Model Class Initialized
INFO - 2018-02-17 15:10:18 --> Model Class Initialized
INFO - 2018-02-17 15:10:18 --> Model Class Initialized
INFO - 2018-02-17 15:10:18 --> Model Class Initialized
INFO - 2018-02-17 15:10:23 --> Config Class Initialized
INFO - 2018-02-17 15:10:23 --> Hooks Class Initialized
DEBUG - 2018-02-17 15:10:23 --> UTF-8 Support Enabled
INFO - 2018-02-17 15:10:23 --> Utf8 Class Initialized
INFO - 2018-02-17 15:10:23 --> URI Class Initialized
INFO - 2018-02-17 15:10:23 --> Router Class Initialized
INFO - 2018-02-17 15:10:23 --> Output Class Initialized
INFO - 2018-02-17 15:10:23 --> Security Class Initialized
DEBUG - 2018-02-17 15:10:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-17 15:10:23 --> Input Class Initialized
INFO - 2018-02-17 15:10:23 --> Language Class Initialized
INFO - 2018-02-17 15:10:23 --> Loader Class Initialized
INFO - 2018-02-17 15:10:23 --> Helper loaded: url_helper
INFO - 2018-02-17 15:10:23 --> Helper loaded: file_helper
INFO - 2018-02-17 15:10:23 --> Helper loaded: email_helper
INFO - 2018-02-17 15:10:23 --> Helper loaded: common_helper
INFO - 2018-02-17 15:10:23 --> Database Driver Class Initialized
DEBUG - 2018-02-17 15:10:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-17 15:10:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-17 15:10:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-17 15:10:23 --> Pagination Class Initialized
INFO - 2018-02-17 15:10:23 --> Helper loaded: form_helper
INFO - 2018-02-17 15:10:23 --> Form Validation Class Initialized
INFO - 2018-02-17 15:10:23 --> Model Class Initialized
INFO - 2018-02-17 15:10:23 --> Controller Class Initialized
INFO - 2018-02-17 15:10:23 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-17 15:10:23 --> Model Class Initialized
INFO - 2018-02-17 15:10:23 --> Model Class Initialized
INFO - 2018-02-17 15:10:23 --> Model Class Initialized
INFO - 2018-02-17 15:10:23 --> Model Class Initialized
INFO - 2018-02-17 15:10:26 --> Config Class Initialized
INFO - 2018-02-17 15:10:26 --> Hooks Class Initialized
DEBUG - 2018-02-17 15:10:26 --> UTF-8 Support Enabled
INFO - 2018-02-17 15:10:26 --> Utf8 Class Initialized
INFO - 2018-02-17 15:10:26 --> URI Class Initialized
INFO - 2018-02-17 15:10:26 --> Router Class Initialized
INFO - 2018-02-17 15:10:26 --> Output Class Initialized
INFO - 2018-02-17 15:10:26 --> Security Class Initialized
DEBUG - 2018-02-17 15:10:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-17 15:10:26 --> Input Class Initialized
INFO - 2018-02-17 15:10:26 --> Language Class Initialized
INFO - 2018-02-17 15:10:26 --> Loader Class Initialized
INFO - 2018-02-17 15:10:26 --> Helper loaded: url_helper
INFO - 2018-02-17 15:10:26 --> Helper loaded: file_helper
INFO - 2018-02-17 15:10:26 --> Helper loaded: email_helper
INFO - 2018-02-17 15:10:26 --> Helper loaded: common_helper
INFO - 2018-02-17 15:10:26 --> Database Driver Class Initialized
DEBUG - 2018-02-17 15:10:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-17 15:10:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-17 15:10:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-17 15:10:26 --> Pagination Class Initialized
INFO - 2018-02-17 15:10:26 --> Helper loaded: form_helper
INFO - 2018-02-17 15:10:26 --> Form Validation Class Initialized
INFO - 2018-02-17 15:10:26 --> Model Class Initialized
INFO - 2018-02-17 15:10:26 --> Controller Class Initialized
INFO - 2018-02-17 15:10:26 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-17 15:10:26 --> Model Class Initialized
INFO - 2018-02-17 15:10:26 --> Model Class Initialized
INFO - 2018-02-17 15:10:26 --> Model Class Initialized
INFO - 2018-02-17 15:10:26 --> Model Class Initialized
INFO - 2018-02-17 15:10:26 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-17 15:10:26 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-17 15:10:26 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-17 15:10:26 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-17 15:10:26 --> File loaded: /var/www/html/project/radio/application/views/tracks/add_edit.php
INFO - 2018-02-17 15:10:26 --> Final output sent to browser
DEBUG - 2018-02-17 15:10:26 --> Total execution time: 0.0120
INFO - 2018-02-17 15:10:31 --> Config Class Initialized
INFO - 2018-02-17 15:10:31 --> Hooks Class Initialized
DEBUG - 2018-02-17 15:10:31 --> UTF-8 Support Enabled
INFO - 2018-02-17 15:10:31 --> Utf8 Class Initialized
INFO - 2018-02-17 15:10:31 --> URI Class Initialized
INFO - 2018-02-17 15:10:31 --> Router Class Initialized
INFO - 2018-02-17 15:10:31 --> Output Class Initialized
INFO - 2018-02-17 15:10:31 --> Security Class Initialized
DEBUG - 2018-02-17 15:10:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-17 15:10:31 --> Input Class Initialized
INFO - 2018-02-17 15:10:31 --> Language Class Initialized
INFO - 2018-02-17 15:10:31 --> Loader Class Initialized
INFO - 2018-02-17 15:10:31 --> Helper loaded: url_helper
INFO - 2018-02-17 15:10:31 --> Helper loaded: file_helper
INFO - 2018-02-17 15:10:31 --> Helper loaded: email_helper
INFO - 2018-02-17 15:10:31 --> Helper loaded: common_helper
INFO - 2018-02-17 15:10:31 --> Database Driver Class Initialized
DEBUG - 2018-02-17 15:10:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-17 15:10:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-17 15:10:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-17 15:10:31 --> Pagination Class Initialized
INFO - 2018-02-17 15:10:31 --> Helper loaded: form_helper
INFO - 2018-02-17 15:10:31 --> Form Validation Class Initialized
INFO - 2018-02-17 15:10:31 --> Model Class Initialized
INFO - 2018-02-17 15:10:31 --> Controller Class Initialized
INFO - 2018-02-17 15:10:31 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-17 15:10:31 --> Model Class Initialized
INFO - 2018-02-17 15:10:31 --> Model Class Initialized
INFO - 2018-02-17 15:10:31 --> Model Class Initialized
INFO - 2018-02-17 15:10:31 --> Model Class Initialized
INFO - 2018-02-17 15:10:31 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-17 15:10:31 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-17 15:10:31 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-17 15:10:31 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-17 15:10:31 --> File loaded: /var/www/html/project/radio/application/views/tracks/index.php
INFO - 2018-02-17 15:10:31 --> Final output sent to browser
DEBUG - 2018-02-17 15:10:31 --> Total execution time: 0.0063
INFO - 2018-02-17 15:10:31 --> Config Class Initialized
INFO - 2018-02-17 15:10:31 --> Hooks Class Initialized
DEBUG - 2018-02-17 15:10:31 --> UTF-8 Support Enabled
INFO - 2018-02-17 15:10:31 --> Utf8 Class Initialized
INFO - 2018-02-17 15:10:31 --> URI Class Initialized
INFO - 2018-02-17 15:10:31 --> Router Class Initialized
INFO - 2018-02-17 15:10:31 --> Output Class Initialized
INFO - 2018-02-17 15:10:31 --> Security Class Initialized
DEBUG - 2018-02-17 15:10:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-17 15:10:31 --> Input Class Initialized
INFO - 2018-02-17 15:10:31 --> Language Class Initialized
INFO - 2018-02-17 15:10:31 --> Loader Class Initialized
INFO - 2018-02-17 15:10:31 --> Helper loaded: url_helper
INFO - 2018-02-17 15:10:31 --> Helper loaded: file_helper
INFO - 2018-02-17 15:10:31 --> Helper loaded: email_helper
INFO - 2018-02-17 15:10:31 --> Helper loaded: common_helper
INFO - 2018-02-17 15:10:31 --> Database Driver Class Initialized
DEBUG - 2018-02-17 15:10:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-17 15:10:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-17 15:10:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-17 15:10:31 --> Pagination Class Initialized
INFO - 2018-02-17 15:10:31 --> Helper loaded: form_helper
INFO - 2018-02-17 15:10:31 --> Form Validation Class Initialized
INFO - 2018-02-17 15:10:31 --> Model Class Initialized
INFO - 2018-02-17 15:10:31 --> Controller Class Initialized
INFO - 2018-02-17 15:10:31 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-17 15:10:31 --> Model Class Initialized
INFO - 2018-02-17 15:10:31 --> Model Class Initialized
INFO - 2018-02-17 15:10:31 --> Model Class Initialized
INFO - 2018-02-17 15:10:31 --> Model Class Initialized
INFO - 2018-02-17 15:17:05 --> Config Class Initialized
INFO - 2018-02-17 15:17:05 --> Hooks Class Initialized
DEBUG - 2018-02-17 15:17:05 --> UTF-8 Support Enabled
INFO - 2018-02-17 15:17:05 --> Utf8 Class Initialized
INFO - 2018-02-17 15:17:05 --> URI Class Initialized
INFO - 2018-02-17 15:17:05 --> Router Class Initialized
INFO - 2018-02-17 15:17:05 --> Output Class Initialized
INFO - 2018-02-17 15:17:05 --> Security Class Initialized
DEBUG - 2018-02-17 15:17:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-17 15:17:05 --> Input Class Initialized
INFO - 2018-02-17 15:17:05 --> Language Class Initialized
INFO - 2018-02-17 15:17:05 --> Loader Class Initialized
INFO - 2018-02-17 15:17:05 --> Helper loaded: url_helper
INFO - 2018-02-17 15:17:05 --> Helper loaded: file_helper
INFO - 2018-02-17 15:17:05 --> Helper loaded: email_helper
INFO - 2018-02-17 15:17:05 --> Helper loaded: common_helper
INFO - 2018-02-17 15:17:05 --> Database Driver Class Initialized
DEBUG - 2018-02-17 15:17:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-17 15:17:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-17 15:17:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-17 15:17:05 --> Pagination Class Initialized
INFO - 2018-02-17 15:17:05 --> Helper loaded: form_helper
INFO - 2018-02-17 15:17:05 --> Form Validation Class Initialized
INFO - 2018-02-17 15:17:05 --> Model Class Initialized
INFO - 2018-02-17 15:17:05 --> Controller Class Initialized
INFO - 2018-02-17 15:17:05 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-17 15:17:05 --> Model Class Initialized
INFO - 2018-02-17 15:17:05 --> Model Class Initialized
INFO - 2018-02-17 15:17:05 --> Model Class Initialized
INFO - 2018-02-17 15:17:05 --> Model Class Initialized
INFO - 2018-02-17 15:17:05 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-17 15:17:05 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-17 15:17:05 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-17 15:17:05 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-17 15:17:05 --> File loaded: /var/www/html/project/radio/application/views/tracks/add_edit.php
INFO - 2018-02-17 15:17:05 --> Final output sent to browser
DEBUG - 2018-02-17 15:17:05 --> Total execution time: 0.0108
INFO - 2018-02-17 15:17:09 --> Config Class Initialized
INFO - 2018-02-17 15:17:09 --> Hooks Class Initialized
DEBUG - 2018-02-17 15:17:09 --> UTF-8 Support Enabled
INFO - 2018-02-17 15:17:09 --> Utf8 Class Initialized
INFO - 2018-02-17 15:17:09 --> URI Class Initialized
INFO - 2018-02-17 15:17:09 --> Router Class Initialized
INFO - 2018-02-17 15:17:09 --> Output Class Initialized
INFO - 2018-02-17 15:17:09 --> Security Class Initialized
DEBUG - 2018-02-17 15:17:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-17 15:17:09 --> Input Class Initialized
INFO - 2018-02-17 15:17:09 --> Language Class Initialized
INFO - 2018-02-17 15:17:09 --> Loader Class Initialized
INFO - 2018-02-17 15:17:09 --> Helper loaded: url_helper
INFO - 2018-02-17 15:17:09 --> Helper loaded: file_helper
INFO - 2018-02-17 15:17:09 --> Helper loaded: email_helper
INFO - 2018-02-17 15:17:09 --> Helper loaded: common_helper
INFO - 2018-02-17 15:17:09 --> Database Driver Class Initialized
DEBUG - 2018-02-17 15:17:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-17 15:17:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-17 15:17:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-17 15:17:09 --> Pagination Class Initialized
INFO - 2018-02-17 15:17:09 --> Helper loaded: form_helper
INFO - 2018-02-17 15:17:09 --> Form Validation Class Initialized
INFO - 2018-02-17 15:17:09 --> Model Class Initialized
INFO - 2018-02-17 15:17:09 --> Controller Class Initialized
INFO - 2018-02-17 15:17:09 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-17 15:17:09 --> Model Class Initialized
INFO - 2018-02-17 15:17:09 --> Model Class Initialized
INFO - 2018-02-17 15:17:09 --> Model Class Initialized
INFO - 2018-02-17 15:17:09 --> Model Class Initialized
INFO - 2018-02-17 15:17:16 --> Config Class Initialized
INFO - 2018-02-17 15:17:16 --> Hooks Class Initialized
DEBUG - 2018-02-17 15:17:16 --> UTF-8 Support Enabled
INFO - 2018-02-17 15:17:16 --> Utf8 Class Initialized
INFO - 2018-02-17 15:17:16 --> URI Class Initialized
INFO - 2018-02-17 15:17:16 --> Router Class Initialized
INFO - 2018-02-17 15:17:16 --> Output Class Initialized
INFO - 2018-02-17 15:17:16 --> Security Class Initialized
DEBUG - 2018-02-17 15:17:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-17 15:17:16 --> Input Class Initialized
INFO - 2018-02-17 15:17:16 --> Language Class Initialized
INFO - 2018-02-17 15:17:16 --> Loader Class Initialized
INFO - 2018-02-17 15:17:16 --> Helper loaded: url_helper
INFO - 2018-02-17 15:17:16 --> Helper loaded: file_helper
INFO - 2018-02-17 15:17:16 --> Helper loaded: email_helper
INFO - 2018-02-17 15:17:16 --> Helper loaded: common_helper
INFO - 2018-02-17 15:17:16 --> Database Driver Class Initialized
DEBUG - 2018-02-17 15:17:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-17 15:17:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-17 15:17:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-17 15:17:16 --> Pagination Class Initialized
INFO - 2018-02-17 15:17:16 --> Helper loaded: form_helper
INFO - 2018-02-17 15:17:16 --> Form Validation Class Initialized
INFO - 2018-02-17 15:17:16 --> Model Class Initialized
INFO - 2018-02-17 15:17:16 --> Controller Class Initialized
INFO - 2018-02-17 15:17:16 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-17 15:17:16 --> Model Class Initialized
INFO - 2018-02-17 15:17:16 --> Model Class Initialized
INFO - 2018-02-17 15:17:16 --> Model Class Initialized
INFO - 2018-02-17 15:17:16 --> Model Class Initialized
INFO - 2018-02-17 15:17:16 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-17 15:17:16 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-17 15:17:16 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-17 15:17:16 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-17 15:17:16 --> File loaded: /var/www/html/project/radio/application/views/tracks/index.php
INFO - 2018-02-17 15:17:16 --> Final output sent to browser
DEBUG - 2018-02-17 15:17:16 --> Total execution time: 0.0055
INFO - 2018-02-17 15:17:16 --> Config Class Initialized
INFO - 2018-02-17 15:17:16 --> Hooks Class Initialized
DEBUG - 2018-02-17 15:17:16 --> UTF-8 Support Enabled
INFO - 2018-02-17 15:17:16 --> Utf8 Class Initialized
INFO - 2018-02-17 15:17:16 --> URI Class Initialized
INFO - 2018-02-17 15:17:16 --> Router Class Initialized
INFO - 2018-02-17 15:17:16 --> Output Class Initialized
INFO - 2018-02-17 15:17:16 --> Security Class Initialized
DEBUG - 2018-02-17 15:17:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-17 15:17:16 --> Input Class Initialized
INFO - 2018-02-17 15:17:16 --> Language Class Initialized
INFO - 2018-02-17 15:17:16 --> Loader Class Initialized
INFO - 2018-02-17 15:17:16 --> Helper loaded: url_helper
INFO - 2018-02-17 15:17:16 --> Helper loaded: file_helper
INFO - 2018-02-17 15:17:16 --> Helper loaded: email_helper
INFO - 2018-02-17 15:17:16 --> Helper loaded: common_helper
INFO - 2018-02-17 15:17:16 --> Database Driver Class Initialized
DEBUG - 2018-02-17 15:17:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-17 15:17:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-17 15:17:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-17 15:17:16 --> Pagination Class Initialized
INFO - 2018-02-17 15:17:16 --> Helper loaded: form_helper
INFO - 2018-02-17 15:17:16 --> Form Validation Class Initialized
INFO - 2018-02-17 15:17:16 --> Model Class Initialized
INFO - 2018-02-17 15:17:16 --> Controller Class Initialized
INFO - 2018-02-17 15:17:16 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-17 15:17:16 --> Model Class Initialized
INFO - 2018-02-17 15:17:16 --> Model Class Initialized
INFO - 2018-02-17 15:17:16 --> Model Class Initialized
INFO - 2018-02-17 15:17:16 --> Model Class Initialized
INFO - 2018-02-17 15:18:57 --> Config Class Initialized
INFO - 2018-02-17 15:18:57 --> Hooks Class Initialized
DEBUG - 2018-02-17 15:18:57 --> UTF-8 Support Enabled
INFO - 2018-02-17 15:18:57 --> Utf8 Class Initialized
INFO - 2018-02-17 15:18:57 --> URI Class Initialized
INFO - 2018-02-17 15:18:57 --> Router Class Initialized
INFO - 2018-02-17 15:18:57 --> Output Class Initialized
INFO - 2018-02-17 15:18:57 --> Security Class Initialized
DEBUG - 2018-02-17 15:18:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-17 15:18:57 --> Input Class Initialized
INFO - 2018-02-17 15:18:57 --> Language Class Initialized
INFO - 2018-02-17 15:18:57 --> Loader Class Initialized
INFO - 2018-02-17 15:18:57 --> Helper loaded: url_helper
INFO - 2018-02-17 15:18:57 --> Helper loaded: file_helper
INFO - 2018-02-17 15:18:57 --> Helper loaded: email_helper
INFO - 2018-02-17 15:18:57 --> Helper loaded: common_helper
INFO - 2018-02-17 15:18:57 --> Database Driver Class Initialized
DEBUG - 2018-02-17 15:18:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-17 15:18:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-17 15:18:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-17 15:18:57 --> Pagination Class Initialized
INFO - 2018-02-17 15:18:57 --> Helper loaded: form_helper
INFO - 2018-02-17 15:18:57 --> Form Validation Class Initialized
INFO - 2018-02-17 15:18:57 --> Model Class Initialized
INFO - 2018-02-17 15:18:57 --> Controller Class Initialized
INFO - 2018-02-17 15:18:57 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-17 15:18:57 --> Model Class Initialized
INFO - 2018-02-17 15:18:57 --> Model Class Initialized
INFO - 2018-02-17 15:18:57 --> Model Class Initialized
INFO - 2018-02-17 15:18:57 --> Model Class Initialized
INFO - 2018-02-17 15:18:57 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-17 15:18:57 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-17 15:18:57 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-17 15:18:57 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-17 15:18:57 --> File loaded: /var/www/html/project/radio/application/views/tracks/index.php
INFO - 2018-02-17 15:18:57 --> Final output sent to browser
DEBUG - 2018-02-17 15:18:57 --> Total execution time: 0.0058
INFO - 2018-02-17 15:18:57 --> Config Class Initialized
INFO - 2018-02-17 15:18:57 --> Hooks Class Initialized
DEBUG - 2018-02-17 15:18:57 --> UTF-8 Support Enabled
INFO - 2018-02-17 15:18:57 --> Utf8 Class Initialized
INFO - 2018-02-17 15:18:57 --> URI Class Initialized
INFO - 2018-02-17 15:18:57 --> Router Class Initialized
INFO - 2018-02-17 15:18:57 --> Output Class Initialized
INFO - 2018-02-17 15:18:57 --> Security Class Initialized
DEBUG - 2018-02-17 15:18:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-17 15:18:57 --> Input Class Initialized
INFO - 2018-02-17 15:18:57 --> Language Class Initialized
INFO - 2018-02-17 15:18:57 --> Loader Class Initialized
INFO - 2018-02-17 15:18:57 --> Helper loaded: url_helper
INFO - 2018-02-17 15:18:57 --> Helper loaded: file_helper
INFO - 2018-02-17 15:18:57 --> Helper loaded: email_helper
INFO - 2018-02-17 15:18:57 --> Helper loaded: common_helper
INFO - 2018-02-17 15:18:57 --> Database Driver Class Initialized
DEBUG - 2018-02-17 15:18:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-17 15:18:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-17 15:18:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-17 15:18:57 --> Pagination Class Initialized
INFO - 2018-02-17 15:18:57 --> Helper loaded: form_helper
INFO - 2018-02-17 15:18:57 --> Form Validation Class Initialized
INFO - 2018-02-17 15:18:57 --> Model Class Initialized
INFO - 2018-02-17 15:18:57 --> Controller Class Initialized
INFO - 2018-02-17 15:18:57 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-17 15:18:57 --> Model Class Initialized
INFO - 2018-02-17 15:18:57 --> Model Class Initialized
INFO - 2018-02-17 15:18:57 --> Model Class Initialized
INFO - 2018-02-17 15:18:57 --> Model Class Initialized
INFO - 2018-02-17 15:18:58 --> Config Class Initialized
INFO - 2018-02-17 15:18:58 --> Hooks Class Initialized
DEBUG - 2018-02-17 15:18:58 --> UTF-8 Support Enabled
INFO - 2018-02-17 15:18:58 --> Utf8 Class Initialized
INFO - 2018-02-17 15:18:58 --> URI Class Initialized
INFO - 2018-02-17 15:18:58 --> Router Class Initialized
INFO - 2018-02-17 15:18:58 --> Output Class Initialized
INFO - 2018-02-17 15:18:58 --> Security Class Initialized
DEBUG - 2018-02-17 15:18:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-17 15:18:58 --> Input Class Initialized
INFO - 2018-02-17 15:18:58 --> Language Class Initialized
INFO - 2018-02-17 15:18:58 --> Loader Class Initialized
INFO - 2018-02-17 15:18:58 --> Helper loaded: url_helper
INFO - 2018-02-17 15:18:58 --> Helper loaded: file_helper
INFO - 2018-02-17 15:18:58 --> Helper loaded: email_helper
INFO - 2018-02-17 15:18:58 --> Helper loaded: common_helper
INFO - 2018-02-17 15:18:58 --> Database Driver Class Initialized
DEBUG - 2018-02-17 15:18:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-17 15:18:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-17 15:18:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-17 15:18:58 --> Pagination Class Initialized
INFO - 2018-02-17 15:18:58 --> Helper loaded: form_helper
INFO - 2018-02-17 15:18:58 --> Form Validation Class Initialized
INFO - 2018-02-17 15:18:58 --> Model Class Initialized
INFO - 2018-02-17 15:18:58 --> Controller Class Initialized
INFO - 2018-02-17 15:18:58 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-17 15:18:58 --> Model Class Initialized
INFO - 2018-02-17 15:18:58 --> Model Class Initialized
INFO - 2018-02-17 15:18:58 --> Model Class Initialized
INFO - 2018-02-17 15:18:58 --> Model Class Initialized
INFO - 2018-02-17 15:18:58 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-17 15:18:58 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-17 15:18:58 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-17 15:18:58 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-17 15:18:58 --> File loaded: /var/www/html/project/radio/application/views/tracks/add_edit.php
INFO - 2018-02-17 15:18:58 --> Final output sent to browser
DEBUG - 2018-02-17 15:18:58 --> Total execution time: 0.0103
INFO - 2018-02-17 15:19:02 --> Config Class Initialized
INFO - 2018-02-17 15:19:02 --> Hooks Class Initialized
DEBUG - 2018-02-17 15:19:02 --> UTF-8 Support Enabled
INFO - 2018-02-17 15:19:02 --> Utf8 Class Initialized
INFO - 2018-02-17 15:19:02 --> URI Class Initialized
INFO - 2018-02-17 15:19:02 --> Router Class Initialized
INFO - 2018-02-17 15:19:02 --> Output Class Initialized
INFO - 2018-02-17 15:19:02 --> Security Class Initialized
DEBUG - 2018-02-17 15:19:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-17 15:19:02 --> Input Class Initialized
INFO - 2018-02-17 15:19:02 --> Language Class Initialized
INFO - 2018-02-17 15:19:02 --> Loader Class Initialized
INFO - 2018-02-17 15:19:02 --> Helper loaded: url_helper
INFO - 2018-02-17 15:19:02 --> Helper loaded: file_helper
INFO - 2018-02-17 15:19:02 --> Helper loaded: email_helper
INFO - 2018-02-17 15:19:02 --> Helper loaded: common_helper
INFO - 2018-02-17 15:19:02 --> Database Driver Class Initialized
DEBUG - 2018-02-17 15:19:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-17 15:19:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-17 15:19:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-17 15:19:02 --> Pagination Class Initialized
INFO - 2018-02-17 15:19:02 --> Helper loaded: form_helper
INFO - 2018-02-17 15:19:02 --> Form Validation Class Initialized
INFO - 2018-02-17 15:19:02 --> Model Class Initialized
INFO - 2018-02-17 15:19:02 --> Controller Class Initialized
INFO - 2018-02-17 15:19:02 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-17 15:19:02 --> Model Class Initialized
INFO - 2018-02-17 15:19:02 --> Model Class Initialized
INFO - 2018-02-17 15:19:02 --> Model Class Initialized
INFO - 2018-02-17 15:19:02 --> Model Class Initialized
INFO - 2018-02-17 15:19:05 --> Config Class Initialized
INFO - 2018-02-17 15:19:05 --> Hooks Class Initialized
DEBUG - 2018-02-17 15:19:05 --> UTF-8 Support Enabled
INFO - 2018-02-17 15:19:05 --> Utf8 Class Initialized
INFO - 2018-02-17 15:19:05 --> URI Class Initialized
INFO - 2018-02-17 15:19:05 --> Router Class Initialized
INFO - 2018-02-17 15:19:05 --> Output Class Initialized
INFO - 2018-02-17 15:19:05 --> Security Class Initialized
DEBUG - 2018-02-17 15:19:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-17 15:19:05 --> Input Class Initialized
INFO - 2018-02-17 15:19:05 --> Language Class Initialized
INFO - 2018-02-17 15:19:05 --> Loader Class Initialized
INFO - 2018-02-17 15:19:05 --> Helper loaded: url_helper
INFO - 2018-02-17 15:19:05 --> Helper loaded: file_helper
INFO - 2018-02-17 15:19:05 --> Helper loaded: email_helper
INFO - 2018-02-17 15:19:05 --> Helper loaded: common_helper
INFO - 2018-02-17 15:19:05 --> Database Driver Class Initialized
DEBUG - 2018-02-17 15:19:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-17 15:19:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-17 15:19:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-17 15:19:05 --> Pagination Class Initialized
INFO - 2018-02-17 15:19:05 --> Helper loaded: form_helper
INFO - 2018-02-17 15:19:05 --> Form Validation Class Initialized
INFO - 2018-02-17 15:19:05 --> Model Class Initialized
INFO - 2018-02-17 15:19:05 --> Controller Class Initialized
INFO - 2018-02-17 15:19:05 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-17 15:19:05 --> Model Class Initialized
INFO - 2018-02-17 15:19:05 --> Model Class Initialized
INFO - 2018-02-17 15:19:05 --> Model Class Initialized
INFO - 2018-02-17 15:19:05 --> Model Class Initialized
INFO - 2018-02-17 15:19:15 --> Config Class Initialized
INFO - 2018-02-17 15:19:15 --> Hooks Class Initialized
DEBUG - 2018-02-17 15:19:15 --> UTF-8 Support Enabled
INFO - 2018-02-17 15:19:15 --> Utf8 Class Initialized
INFO - 2018-02-17 15:19:15 --> URI Class Initialized
INFO - 2018-02-17 15:19:15 --> Router Class Initialized
INFO - 2018-02-17 15:19:15 --> Output Class Initialized
INFO - 2018-02-17 15:19:15 --> Security Class Initialized
DEBUG - 2018-02-17 15:19:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-17 15:19:15 --> Input Class Initialized
INFO - 2018-02-17 15:19:15 --> Language Class Initialized
INFO - 2018-02-17 15:19:15 --> Loader Class Initialized
INFO - 2018-02-17 15:19:15 --> Helper loaded: url_helper
INFO - 2018-02-17 15:19:15 --> Helper loaded: file_helper
INFO - 2018-02-17 15:19:15 --> Helper loaded: email_helper
INFO - 2018-02-17 15:19:15 --> Helper loaded: common_helper
INFO - 2018-02-17 15:19:15 --> Database Driver Class Initialized
DEBUG - 2018-02-17 15:19:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-17 15:19:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-17 15:19:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-17 15:19:15 --> Pagination Class Initialized
INFO - 2018-02-17 15:19:15 --> Helper loaded: form_helper
INFO - 2018-02-17 15:19:15 --> Form Validation Class Initialized
INFO - 2018-02-17 15:19:15 --> Model Class Initialized
INFO - 2018-02-17 15:19:15 --> Controller Class Initialized
INFO - 2018-02-17 15:19:15 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-17 15:19:15 --> Model Class Initialized
INFO - 2018-02-17 15:19:15 --> Model Class Initialized
INFO - 2018-02-17 15:19:15 --> Model Class Initialized
INFO - 2018-02-17 15:19:15 --> Model Class Initialized
INFO - 2018-02-17 15:19:15 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-17 15:19:15 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-17 15:19:15 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-17 15:19:15 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-17 15:19:15 --> File loaded: /var/www/html/project/radio/application/views/tracks/add_edit.php
INFO - 2018-02-17 15:19:15 --> Final output sent to browser
DEBUG - 2018-02-17 15:19:15 --> Total execution time: 0.0114
INFO - 2018-02-17 15:25:13 --> Config Class Initialized
INFO - 2018-02-17 15:25:13 --> Hooks Class Initialized
DEBUG - 2018-02-17 15:25:13 --> UTF-8 Support Enabled
INFO - 2018-02-17 15:25:13 --> Utf8 Class Initialized
INFO - 2018-02-17 15:25:13 --> URI Class Initialized
INFO - 2018-02-17 15:25:13 --> Router Class Initialized
INFO - 2018-02-17 15:25:13 --> Output Class Initialized
INFO - 2018-02-17 15:25:13 --> Security Class Initialized
DEBUG - 2018-02-17 15:25:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-17 15:25:13 --> Input Class Initialized
INFO - 2018-02-17 15:25:13 --> Language Class Initialized
INFO - 2018-02-17 15:25:13 --> Loader Class Initialized
INFO - 2018-02-17 15:25:13 --> Helper loaded: url_helper
INFO - 2018-02-17 15:25:13 --> Helper loaded: file_helper
INFO - 2018-02-17 15:25:13 --> Helper loaded: email_helper
INFO - 2018-02-17 15:25:13 --> Helper loaded: common_helper
INFO - 2018-02-17 15:25:13 --> Database Driver Class Initialized
DEBUG - 2018-02-17 15:25:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-17 15:25:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-17 15:25:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-17 15:25:13 --> Pagination Class Initialized
INFO - 2018-02-17 15:25:13 --> Helper loaded: form_helper
INFO - 2018-02-17 15:25:13 --> Form Validation Class Initialized
INFO - 2018-02-17 15:25:13 --> Model Class Initialized
INFO - 2018-02-17 15:25:13 --> Controller Class Initialized
INFO - 2018-02-17 15:25:13 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-17 15:25:13 --> Model Class Initialized
INFO - 2018-02-17 15:25:13 --> Model Class Initialized
INFO - 2018-02-17 15:25:13 --> Model Class Initialized
INFO - 2018-02-17 15:25:13 --> Model Class Initialized
INFO - 2018-02-17 15:26:00 --> Config Class Initialized
INFO - 2018-02-17 15:26:00 --> Hooks Class Initialized
DEBUG - 2018-02-17 15:26:00 --> UTF-8 Support Enabled
INFO - 2018-02-17 15:26:00 --> Utf8 Class Initialized
INFO - 2018-02-17 15:26:00 --> URI Class Initialized
INFO - 2018-02-17 15:26:00 --> Router Class Initialized
INFO - 2018-02-17 15:26:00 --> Output Class Initialized
INFO - 2018-02-17 15:26:00 --> Security Class Initialized
DEBUG - 2018-02-17 15:26:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-17 15:26:00 --> Input Class Initialized
INFO - 2018-02-17 15:26:00 --> Language Class Initialized
INFO - 2018-02-17 15:26:00 --> Loader Class Initialized
INFO - 2018-02-17 15:26:00 --> Helper loaded: url_helper
INFO - 2018-02-17 15:26:00 --> Helper loaded: file_helper
INFO - 2018-02-17 15:26:00 --> Helper loaded: email_helper
INFO - 2018-02-17 15:26:00 --> Helper loaded: common_helper
INFO - 2018-02-17 15:26:00 --> Database Driver Class Initialized
DEBUG - 2018-02-17 15:26:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-17 15:26:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-17 15:26:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-17 15:26:00 --> Pagination Class Initialized
INFO - 2018-02-17 15:26:00 --> Helper loaded: form_helper
INFO - 2018-02-17 15:26:00 --> Form Validation Class Initialized
INFO - 2018-02-17 15:26:00 --> Model Class Initialized
INFO - 2018-02-17 15:26:00 --> Controller Class Initialized
INFO - 2018-02-17 15:26:00 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-17 15:26:00 --> Model Class Initialized
INFO - 2018-02-17 15:26:00 --> Model Class Initialized
INFO - 2018-02-17 15:26:00 --> Model Class Initialized
INFO - 2018-02-17 15:26:00 --> Model Class Initialized
INFO - 2018-02-17 15:37:13 --> Config Class Initialized
INFO - 2018-02-17 15:37:13 --> Hooks Class Initialized
DEBUG - 2018-02-17 15:37:13 --> UTF-8 Support Enabled
INFO - 2018-02-17 15:37:13 --> Utf8 Class Initialized
INFO - 2018-02-17 15:37:13 --> URI Class Initialized
INFO - 2018-02-17 15:37:13 --> Router Class Initialized
INFO - 2018-02-17 15:37:13 --> Output Class Initialized
INFO - 2018-02-17 15:37:13 --> Security Class Initialized
DEBUG - 2018-02-17 15:37:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-17 15:37:13 --> Input Class Initialized
INFO - 2018-02-17 15:37:13 --> Language Class Initialized
INFO - 2018-02-17 15:37:13 --> Loader Class Initialized
INFO - 2018-02-17 15:37:13 --> Helper loaded: url_helper
INFO - 2018-02-17 15:37:13 --> Helper loaded: file_helper
INFO - 2018-02-17 15:37:13 --> Helper loaded: email_helper
INFO - 2018-02-17 15:37:13 --> Helper loaded: common_helper
INFO - 2018-02-17 15:37:13 --> Database Driver Class Initialized
DEBUG - 2018-02-17 15:37:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-17 15:37:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-17 15:37:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-17 15:37:13 --> Pagination Class Initialized
INFO - 2018-02-17 15:37:13 --> Helper loaded: form_helper
INFO - 2018-02-17 15:37:13 --> Form Validation Class Initialized
INFO - 2018-02-17 15:37:13 --> Model Class Initialized
INFO - 2018-02-17 15:37:13 --> Controller Class Initialized
INFO - 2018-02-17 15:37:13 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-17 15:37:13 --> Model Class Initialized
INFO - 2018-02-17 15:37:13 --> Model Class Initialized
INFO - 2018-02-17 15:37:13 --> Model Class Initialized
INFO - 2018-02-17 15:37:13 --> Model Class Initialized
INFO - 2018-02-17 15:37:13 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-17 15:37:13 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-17 15:37:13 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-17 15:37:13 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-17 15:37:13 --> File loaded: /var/www/html/project/radio/application/views/tracks/index.php
INFO - 2018-02-17 15:37:13 --> Final output sent to browser
DEBUG - 2018-02-17 15:37:13 --> Total execution time: 0.0067
INFO - 2018-02-17 15:37:13 --> Config Class Initialized
INFO - 2018-02-17 15:37:13 --> Hooks Class Initialized
DEBUG - 2018-02-17 15:37:13 --> UTF-8 Support Enabled
INFO - 2018-02-17 15:37:13 --> Utf8 Class Initialized
INFO - 2018-02-17 15:37:13 --> URI Class Initialized
INFO - 2018-02-17 15:37:13 --> Router Class Initialized
INFO - 2018-02-17 15:37:13 --> Output Class Initialized
INFO - 2018-02-17 15:37:13 --> Security Class Initialized
DEBUG - 2018-02-17 15:37:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-17 15:37:13 --> Input Class Initialized
INFO - 2018-02-17 15:37:13 --> Language Class Initialized
INFO - 2018-02-17 15:37:13 --> Loader Class Initialized
INFO - 2018-02-17 15:37:13 --> Helper loaded: url_helper
INFO - 2018-02-17 15:37:13 --> Helper loaded: file_helper
INFO - 2018-02-17 15:37:13 --> Helper loaded: email_helper
INFO - 2018-02-17 15:37:13 --> Helper loaded: common_helper
INFO - 2018-02-17 15:37:13 --> Database Driver Class Initialized
DEBUG - 2018-02-17 15:37:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-17 15:37:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-17 15:37:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-17 15:37:13 --> Pagination Class Initialized
INFO - 2018-02-17 15:37:13 --> Helper loaded: form_helper
INFO - 2018-02-17 15:37:13 --> Form Validation Class Initialized
INFO - 2018-02-17 15:37:13 --> Model Class Initialized
INFO - 2018-02-17 15:37:13 --> Controller Class Initialized
INFO - 2018-02-17 15:37:13 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-17 15:37:13 --> Model Class Initialized
INFO - 2018-02-17 15:37:13 --> Model Class Initialized
INFO - 2018-02-17 15:37:13 --> Model Class Initialized
INFO - 2018-02-17 15:37:13 --> Model Class Initialized
INFO - 2018-02-17 15:37:19 --> Config Class Initialized
INFO - 2018-02-17 15:37:19 --> Hooks Class Initialized
DEBUG - 2018-02-17 15:37:19 --> UTF-8 Support Enabled
INFO - 2018-02-17 15:37:19 --> Utf8 Class Initialized
INFO - 2018-02-17 15:37:19 --> URI Class Initialized
INFO - 2018-02-17 15:37:19 --> Router Class Initialized
INFO - 2018-02-17 15:37:19 --> Output Class Initialized
INFO - 2018-02-17 15:37:19 --> Security Class Initialized
DEBUG - 2018-02-17 15:37:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-17 15:37:19 --> Input Class Initialized
INFO - 2018-02-17 15:37:19 --> Language Class Initialized
INFO - 2018-02-17 15:37:19 --> Loader Class Initialized
INFO - 2018-02-17 15:37:19 --> Helper loaded: url_helper
INFO - 2018-02-17 15:37:19 --> Helper loaded: file_helper
INFO - 2018-02-17 15:37:19 --> Helper loaded: email_helper
INFO - 2018-02-17 15:37:19 --> Helper loaded: common_helper
INFO - 2018-02-17 15:37:19 --> Database Driver Class Initialized
DEBUG - 2018-02-17 15:37:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-17 15:37:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-17 15:37:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-17 15:37:19 --> Pagination Class Initialized
INFO - 2018-02-17 15:37:19 --> Helper loaded: form_helper
INFO - 2018-02-17 15:37:19 --> Form Validation Class Initialized
INFO - 2018-02-17 15:37:19 --> Model Class Initialized
INFO - 2018-02-17 15:37:19 --> Controller Class Initialized
INFO - 2018-02-17 15:37:19 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-17 15:37:19 --> Model Class Initialized
INFO - 2018-02-17 15:37:19 --> Model Class Initialized
INFO - 2018-02-17 15:37:19 --> Model Class Initialized
INFO - 2018-02-17 15:37:19 --> Model Class Initialized
INFO - 2018-02-17 15:37:19 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-17 15:37:19 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-17 15:37:19 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-17 15:37:19 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-17 15:37:19 --> File loaded: /var/www/html/project/radio/application/views/tracks/add_edit.php
INFO - 2018-02-17 15:37:19 --> Final output sent to browser
DEBUG - 2018-02-17 15:37:19 --> Total execution time: 0.0106
INFO - 2018-02-17 15:37:25 --> Config Class Initialized
INFO - 2018-02-17 15:37:25 --> Hooks Class Initialized
DEBUG - 2018-02-17 15:37:25 --> UTF-8 Support Enabled
INFO - 2018-02-17 15:37:25 --> Utf8 Class Initialized
INFO - 2018-02-17 15:37:25 --> URI Class Initialized
INFO - 2018-02-17 15:37:25 --> Router Class Initialized
INFO - 2018-02-17 15:37:25 --> Output Class Initialized
INFO - 2018-02-17 15:37:25 --> Security Class Initialized
DEBUG - 2018-02-17 15:37:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-17 15:37:25 --> Input Class Initialized
INFO - 2018-02-17 15:37:25 --> Language Class Initialized
INFO - 2018-02-17 15:37:25 --> Loader Class Initialized
INFO - 2018-02-17 15:37:25 --> Helper loaded: url_helper
INFO - 2018-02-17 15:37:25 --> Helper loaded: file_helper
INFO - 2018-02-17 15:37:25 --> Helper loaded: email_helper
INFO - 2018-02-17 15:37:25 --> Helper loaded: common_helper
INFO - 2018-02-17 15:37:25 --> Database Driver Class Initialized
DEBUG - 2018-02-17 15:37:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-17 15:37:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-17 15:37:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-17 15:37:25 --> Pagination Class Initialized
INFO - 2018-02-17 15:37:25 --> Helper loaded: form_helper
INFO - 2018-02-17 15:37:25 --> Form Validation Class Initialized
INFO - 2018-02-17 15:37:25 --> Model Class Initialized
INFO - 2018-02-17 15:37:25 --> Controller Class Initialized
INFO - 2018-02-17 15:37:25 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-17 15:37:25 --> Model Class Initialized
INFO - 2018-02-17 15:37:25 --> Model Class Initialized
INFO - 2018-02-17 15:37:25 --> Model Class Initialized
INFO - 2018-02-17 15:37:25 --> Model Class Initialized
DEBUG - 2018-02-17 15:37:25 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-17 15:37:25 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-02-17 15:37:25 --> Config Class Initialized
INFO - 2018-02-17 15:37:25 --> Hooks Class Initialized
DEBUG - 2018-02-17 15:37:25 --> UTF-8 Support Enabled
INFO - 2018-02-17 15:37:25 --> Utf8 Class Initialized
INFO - 2018-02-17 15:37:25 --> URI Class Initialized
INFO - 2018-02-17 15:37:25 --> Router Class Initialized
INFO - 2018-02-17 15:37:25 --> Output Class Initialized
INFO - 2018-02-17 15:37:25 --> Security Class Initialized
DEBUG - 2018-02-17 15:37:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-17 15:37:25 --> Input Class Initialized
INFO - 2018-02-17 15:37:25 --> Language Class Initialized
INFO - 2018-02-17 15:37:25 --> Loader Class Initialized
INFO - 2018-02-17 15:37:25 --> Helper loaded: url_helper
INFO - 2018-02-17 15:37:25 --> Helper loaded: file_helper
INFO - 2018-02-17 15:37:25 --> Helper loaded: email_helper
INFO - 2018-02-17 15:37:25 --> Helper loaded: common_helper
INFO - 2018-02-17 15:37:25 --> Database Driver Class Initialized
DEBUG - 2018-02-17 15:37:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-17 15:37:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-17 15:37:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-17 15:37:25 --> Pagination Class Initialized
INFO - 2018-02-17 15:37:25 --> Helper loaded: form_helper
INFO - 2018-02-17 15:37:25 --> Form Validation Class Initialized
INFO - 2018-02-17 15:37:25 --> Model Class Initialized
INFO - 2018-02-17 15:37:25 --> Controller Class Initialized
INFO - 2018-02-17 15:37:25 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-17 15:37:25 --> Model Class Initialized
INFO - 2018-02-17 15:37:25 --> Model Class Initialized
INFO - 2018-02-17 15:37:25 --> Model Class Initialized
INFO - 2018-02-17 15:37:25 --> Model Class Initialized
INFO - 2018-02-17 15:37:25 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-17 15:37:25 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-17 15:37:25 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-17 15:37:25 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-17 15:37:25 --> File loaded: /var/www/html/project/radio/application/views/tracks/index.php
INFO - 2018-02-17 15:37:25 --> Final output sent to browser
DEBUG - 2018-02-17 15:37:25 --> Total execution time: 0.0085
INFO - 2018-02-17 15:37:25 --> Config Class Initialized
INFO - 2018-02-17 15:37:25 --> Hooks Class Initialized
DEBUG - 2018-02-17 15:37:25 --> UTF-8 Support Enabled
INFO - 2018-02-17 15:37:25 --> Utf8 Class Initialized
INFO - 2018-02-17 15:37:25 --> URI Class Initialized
INFO - 2018-02-17 15:37:25 --> Router Class Initialized
INFO - 2018-02-17 15:37:25 --> Output Class Initialized
INFO - 2018-02-17 15:37:25 --> Security Class Initialized
DEBUG - 2018-02-17 15:37:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-17 15:37:25 --> Input Class Initialized
INFO - 2018-02-17 15:37:25 --> Language Class Initialized
INFO - 2018-02-17 15:37:25 --> Loader Class Initialized
INFO - 2018-02-17 15:37:25 --> Helper loaded: url_helper
INFO - 2018-02-17 15:37:25 --> Helper loaded: file_helper
INFO - 2018-02-17 15:37:25 --> Helper loaded: email_helper
INFO - 2018-02-17 15:37:25 --> Helper loaded: common_helper
INFO - 2018-02-17 15:37:25 --> Database Driver Class Initialized
DEBUG - 2018-02-17 15:37:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-17 15:37:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-17 15:37:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-17 15:37:25 --> Pagination Class Initialized
INFO - 2018-02-17 15:37:25 --> Helper loaded: form_helper
INFO - 2018-02-17 15:37:25 --> Form Validation Class Initialized
INFO - 2018-02-17 15:37:25 --> Model Class Initialized
INFO - 2018-02-17 15:37:25 --> Controller Class Initialized
INFO - 2018-02-17 15:37:25 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-17 15:37:25 --> Model Class Initialized
INFO - 2018-02-17 15:37:25 --> Model Class Initialized
INFO - 2018-02-17 15:37:25 --> Model Class Initialized
INFO - 2018-02-17 15:37:25 --> Model Class Initialized
INFO - 2018-02-17 15:37:30 --> Config Class Initialized
INFO - 2018-02-17 15:37:30 --> Hooks Class Initialized
DEBUG - 2018-02-17 15:37:30 --> UTF-8 Support Enabled
INFO - 2018-02-17 15:37:30 --> Utf8 Class Initialized
INFO - 2018-02-17 15:37:30 --> URI Class Initialized
INFO - 2018-02-17 15:37:30 --> Router Class Initialized
INFO - 2018-02-17 15:37:30 --> Output Class Initialized
INFO - 2018-02-17 15:37:30 --> Security Class Initialized
DEBUG - 2018-02-17 15:37:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-17 15:37:30 --> Input Class Initialized
INFO - 2018-02-17 15:37:30 --> Language Class Initialized
INFO - 2018-02-17 15:37:30 --> Loader Class Initialized
INFO - 2018-02-17 15:37:30 --> Helper loaded: url_helper
INFO - 2018-02-17 15:37:30 --> Helper loaded: file_helper
INFO - 2018-02-17 15:37:30 --> Helper loaded: email_helper
INFO - 2018-02-17 15:37:30 --> Helper loaded: common_helper
INFO - 2018-02-17 15:37:30 --> Database Driver Class Initialized
DEBUG - 2018-02-17 15:37:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-17 15:37:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-17 15:37:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-17 15:37:30 --> Pagination Class Initialized
INFO - 2018-02-17 15:37:30 --> Helper loaded: form_helper
INFO - 2018-02-17 15:37:30 --> Form Validation Class Initialized
INFO - 2018-02-17 15:37:30 --> Model Class Initialized
INFO - 2018-02-17 15:37:30 --> Controller Class Initialized
INFO - 2018-02-17 15:37:30 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-17 15:37:30 --> Model Class Initialized
INFO - 2018-02-17 15:37:30 --> Model Class Initialized
INFO - 2018-02-17 15:37:30 --> Model Class Initialized
INFO - 2018-02-17 15:37:30 --> Model Class Initialized
INFO - 2018-02-17 15:37:30 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-17 15:37:30 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-17 15:37:30 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-17 15:37:30 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-17 15:37:30 --> File loaded: /var/www/html/project/radio/application/views/tracks/add_edit.php
INFO - 2018-02-17 15:37:30 --> Final output sent to browser
DEBUG - 2018-02-17 15:37:30 --> Total execution time: 0.0115
INFO - 2018-02-17 15:38:41 --> Config Class Initialized
INFO - 2018-02-17 15:38:41 --> Hooks Class Initialized
DEBUG - 2018-02-17 15:38:41 --> UTF-8 Support Enabled
INFO - 2018-02-17 15:38:41 --> Utf8 Class Initialized
INFO - 2018-02-17 15:38:41 --> URI Class Initialized
INFO - 2018-02-17 15:38:41 --> Router Class Initialized
INFO - 2018-02-17 15:38:41 --> Output Class Initialized
INFO - 2018-02-17 15:38:41 --> Security Class Initialized
DEBUG - 2018-02-17 15:38:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-17 15:38:41 --> Input Class Initialized
INFO - 2018-02-17 15:38:41 --> Language Class Initialized
INFO - 2018-02-17 15:38:41 --> Loader Class Initialized
INFO - 2018-02-17 15:38:41 --> Helper loaded: url_helper
INFO - 2018-02-17 15:38:41 --> Helper loaded: file_helper
INFO - 2018-02-17 15:38:41 --> Helper loaded: email_helper
INFO - 2018-02-17 15:38:41 --> Helper loaded: common_helper
INFO - 2018-02-17 15:38:41 --> Database Driver Class Initialized
DEBUG - 2018-02-17 15:38:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-17 15:38:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-17 15:38:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-17 15:38:41 --> Pagination Class Initialized
INFO - 2018-02-17 15:38:41 --> Helper loaded: form_helper
INFO - 2018-02-17 15:38:41 --> Form Validation Class Initialized
INFO - 2018-02-17 15:38:41 --> Model Class Initialized
INFO - 2018-02-17 15:38:41 --> Controller Class Initialized
INFO - 2018-02-17 15:38:41 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-17 15:38:41 --> Model Class Initialized
INFO - 2018-02-17 15:38:41 --> Model Class Initialized
INFO - 2018-02-17 15:38:41 --> Model Class Initialized
INFO - 2018-02-17 15:38:41 --> Model Class Initialized
INFO - 2018-02-17 15:38:41 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-17 15:38:41 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-17 15:38:41 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-17 15:38:41 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-17 15:38:41 --> File loaded: /var/www/html/project/radio/application/views/tracks/add_edit.php
INFO - 2018-02-17 15:38:41 --> Final output sent to browser
DEBUG - 2018-02-17 15:38:41 --> Total execution time: 0.0120
INFO - 2018-02-17 15:38:45 --> Config Class Initialized
INFO - 2018-02-17 15:38:45 --> Hooks Class Initialized
DEBUG - 2018-02-17 15:38:45 --> UTF-8 Support Enabled
INFO - 2018-02-17 15:38:45 --> Utf8 Class Initialized
INFO - 2018-02-17 15:38:45 --> URI Class Initialized
INFO - 2018-02-17 15:38:45 --> Router Class Initialized
INFO - 2018-02-17 15:38:45 --> Output Class Initialized
INFO - 2018-02-17 15:38:45 --> Security Class Initialized
DEBUG - 2018-02-17 15:38:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-17 15:38:45 --> Input Class Initialized
INFO - 2018-02-17 15:38:45 --> Language Class Initialized
INFO - 2018-02-17 15:38:45 --> Loader Class Initialized
INFO - 2018-02-17 15:38:45 --> Helper loaded: url_helper
INFO - 2018-02-17 15:38:45 --> Helper loaded: file_helper
INFO - 2018-02-17 15:38:45 --> Helper loaded: email_helper
INFO - 2018-02-17 15:38:45 --> Helper loaded: common_helper
INFO - 2018-02-17 15:38:45 --> Database Driver Class Initialized
DEBUG - 2018-02-17 15:38:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-17 15:38:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-17 15:38:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-17 15:38:45 --> Pagination Class Initialized
INFO - 2018-02-17 15:38:45 --> Helper loaded: form_helper
INFO - 2018-02-17 15:38:45 --> Form Validation Class Initialized
INFO - 2018-02-17 15:38:45 --> Model Class Initialized
INFO - 2018-02-17 15:38:45 --> Controller Class Initialized
INFO - 2018-02-17 15:38:45 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-17 15:38:45 --> Model Class Initialized
INFO - 2018-02-17 15:38:45 --> Model Class Initialized
INFO - 2018-02-17 15:38:45 --> Model Class Initialized
INFO - 2018-02-17 15:38:45 --> Model Class Initialized
DEBUG - 2018-02-17 15:38:45 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-17 15:38:45 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-02-17 15:38:46 --> Config Class Initialized
INFO - 2018-02-17 15:38:46 --> Hooks Class Initialized
DEBUG - 2018-02-17 15:38:46 --> UTF-8 Support Enabled
INFO - 2018-02-17 15:38:46 --> Utf8 Class Initialized
INFO - 2018-02-17 15:38:46 --> URI Class Initialized
INFO - 2018-02-17 15:38:46 --> Router Class Initialized
INFO - 2018-02-17 15:38:46 --> Output Class Initialized
INFO - 2018-02-17 15:38:46 --> Security Class Initialized
DEBUG - 2018-02-17 15:38:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-17 15:38:46 --> Input Class Initialized
INFO - 2018-02-17 15:38:46 --> Language Class Initialized
INFO - 2018-02-17 15:38:46 --> Loader Class Initialized
INFO - 2018-02-17 15:38:46 --> Helper loaded: url_helper
INFO - 2018-02-17 15:38:46 --> Helper loaded: file_helper
INFO - 2018-02-17 15:38:46 --> Helper loaded: email_helper
INFO - 2018-02-17 15:38:46 --> Helper loaded: common_helper
INFO - 2018-02-17 15:38:46 --> Database Driver Class Initialized
DEBUG - 2018-02-17 15:38:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-17 15:38:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-17 15:38:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-17 15:38:46 --> Pagination Class Initialized
INFO - 2018-02-17 15:38:46 --> Helper loaded: form_helper
INFO - 2018-02-17 15:38:46 --> Form Validation Class Initialized
INFO - 2018-02-17 15:38:46 --> Model Class Initialized
INFO - 2018-02-17 15:38:46 --> Controller Class Initialized
INFO - 2018-02-17 15:38:46 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-17 15:38:46 --> Model Class Initialized
INFO - 2018-02-17 15:38:46 --> Model Class Initialized
INFO - 2018-02-17 15:38:46 --> Model Class Initialized
INFO - 2018-02-17 15:38:46 --> Model Class Initialized
INFO - 2018-02-17 15:38:46 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-17 15:38:46 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-17 15:38:46 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-17 15:38:46 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-17 15:38:46 --> File loaded: /var/www/html/project/radio/application/views/tracks/index.php
INFO - 2018-02-17 15:38:46 --> Final output sent to browser
DEBUG - 2018-02-17 15:38:46 --> Total execution time: 0.0056
INFO - 2018-02-17 15:38:46 --> Config Class Initialized
INFO - 2018-02-17 15:38:46 --> Hooks Class Initialized
DEBUG - 2018-02-17 15:38:46 --> UTF-8 Support Enabled
INFO - 2018-02-17 15:38:46 --> Utf8 Class Initialized
INFO - 2018-02-17 15:38:46 --> URI Class Initialized
INFO - 2018-02-17 15:38:46 --> Router Class Initialized
INFO - 2018-02-17 15:38:46 --> Output Class Initialized
INFO - 2018-02-17 15:38:46 --> Security Class Initialized
DEBUG - 2018-02-17 15:38:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-17 15:38:46 --> Input Class Initialized
INFO - 2018-02-17 15:38:46 --> Language Class Initialized
INFO - 2018-02-17 15:38:46 --> Loader Class Initialized
INFO - 2018-02-17 15:38:46 --> Helper loaded: url_helper
INFO - 2018-02-17 15:38:46 --> Helper loaded: file_helper
INFO - 2018-02-17 15:38:46 --> Helper loaded: email_helper
INFO - 2018-02-17 15:38:46 --> Helper loaded: common_helper
INFO - 2018-02-17 15:38:46 --> Database Driver Class Initialized
DEBUG - 2018-02-17 15:38:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-17 15:38:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-17 15:38:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-17 15:38:46 --> Pagination Class Initialized
INFO - 2018-02-17 15:38:46 --> Helper loaded: form_helper
INFO - 2018-02-17 15:38:46 --> Form Validation Class Initialized
INFO - 2018-02-17 15:38:46 --> Model Class Initialized
INFO - 2018-02-17 15:38:46 --> Controller Class Initialized
INFO - 2018-02-17 15:38:46 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-17 15:38:46 --> Model Class Initialized
INFO - 2018-02-17 15:38:46 --> Model Class Initialized
INFO - 2018-02-17 15:38:46 --> Model Class Initialized
INFO - 2018-02-17 15:38:46 --> Model Class Initialized
INFO - 2018-02-17 15:41:21 --> Config Class Initialized
INFO - 2018-02-17 15:41:21 --> Hooks Class Initialized
DEBUG - 2018-02-17 15:41:21 --> UTF-8 Support Enabled
INFO - 2018-02-17 15:41:21 --> Utf8 Class Initialized
INFO - 2018-02-17 15:41:21 --> URI Class Initialized
INFO - 2018-02-17 15:41:21 --> Router Class Initialized
INFO - 2018-02-17 15:41:21 --> Output Class Initialized
INFO - 2018-02-17 15:41:21 --> Security Class Initialized
DEBUG - 2018-02-17 15:41:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-17 15:41:21 --> Input Class Initialized
INFO - 2018-02-17 15:41:21 --> Language Class Initialized
INFO - 2018-02-17 15:41:21 --> Loader Class Initialized
INFO - 2018-02-17 15:41:21 --> Helper loaded: url_helper
INFO - 2018-02-17 15:41:21 --> Helper loaded: file_helper
INFO - 2018-02-17 15:41:21 --> Helper loaded: email_helper
INFO - 2018-02-17 15:41:21 --> Helper loaded: common_helper
INFO - 2018-02-17 15:41:21 --> Database Driver Class Initialized
DEBUG - 2018-02-17 15:41:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-17 15:41:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-17 15:41:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-17 15:41:21 --> Pagination Class Initialized
INFO - 2018-02-17 15:41:21 --> Helper loaded: form_helper
INFO - 2018-02-17 15:41:21 --> Form Validation Class Initialized
INFO - 2018-02-17 15:41:21 --> Model Class Initialized
INFO - 2018-02-17 15:41:21 --> Controller Class Initialized
INFO - 2018-02-17 15:41:21 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-17 15:41:21 --> Model Class Initialized
INFO - 2018-02-17 15:41:21 --> Model Class Initialized
INFO - 2018-02-17 15:41:21 --> Model Class Initialized
INFO - 2018-02-17 15:41:21 --> Model Class Initialized
INFO - 2018-02-17 15:41:21 --> Config Class Initialized
INFO - 2018-02-17 15:41:21 --> Hooks Class Initialized
DEBUG - 2018-02-17 15:41:21 --> UTF-8 Support Enabled
INFO - 2018-02-17 15:41:21 --> Utf8 Class Initialized
INFO - 2018-02-17 15:41:21 --> URI Class Initialized
INFO - 2018-02-17 15:41:21 --> Router Class Initialized
INFO - 2018-02-17 15:41:21 --> Output Class Initialized
INFO - 2018-02-17 15:41:21 --> Security Class Initialized
DEBUG - 2018-02-17 15:41:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-17 15:41:21 --> Input Class Initialized
INFO - 2018-02-17 15:41:21 --> Language Class Initialized
INFO - 2018-02-17 15:41:21 --> Loader Class Initialized
INFO - 2018-02-17 15:41:21 --> Helper loaded: url_helper
INFO - 2018-02-17 15:41:21 --> Helper loaded: file_helper
INFO - 2018-02-17 15:41:21 --> Helper loaded: email_helper
INFO - 2018-02-17 15:41:21 --> Helper loaded: common_helper
INFO - 2018-02-17 15:41:21 --> Database Driver Class Initialized
DEBUG - 2018-02-17 15:41:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-17 15:41:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-17 15:41:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-17 15:41:21 --> Pagination Class Initialized
INFO - 2018-02-17 15:41:21 --> Helper loaded: form_helper
INFO - 2018-02-17 15:41:21 --> Form Validation Class Initialized
INFO - 2018-02-17 15:41:21 --> Model Class Initialized
INFO - 2018-02-17 15:41:21 --> Controller Class Initialized
INFO - 2018-02-17 15:41:21 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-17 15:41:21 --> Model Class Initialized
INFO - 2018-02-17 15:41:21 --> Model Class Initialized
INFO - 2018-02-17 15:41:21 --> Model Class Initialized
INFO - 2018-02-17 15:41:21 --> Model Class Initialized
INFO - 2018-02-17 15:41:22 --> Config Class Initialized
INFO - 2018-02-17 15:41:22 --> Hooks Class Initialized
DEBUG - 2018-02-17 15:41:22 --> UTF-8 Support Enabled
INFO - 2018-02-17 15:41:22 --> Utf8 Class Initialized
INFO - 2018-02-17 15:41:22 --> URI Class Initialized
INFO - 2018-02-17 15:41:22 --> Router Class Initialized
INFO - 2018-02-17 15:41:22 --> Output Class Initialized
INFO - 2018-02-17 15:41:22 --> Security Class Initialized
DEBUG - 2018-02-17 15:41:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-17 15:41:22 --> Input Class Initialized
INFO - 2018-02-17 15:41:22 --> Language Class Initialized
INFO - 2018-02-17 15:41:22 --> Loader Class Initialized
INFO - 2018-02-17 15:41:22 --> Helper loaded: url_helper
INFO - 2018-02-17 15:41:22 --> Helper loaded: file_helper
INFO - 2018-02-17 15:41:22 --> Helper loaded: email_helper
INFO - 2018-02-17 15:41:22 --> Helper loaded: common_helper
INFO - 2018-02-17 15:41:22 --> Database Driver Class Initialized
DEBUG - 2018-02-17 15:41:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-17 15:41:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-17 15:41:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-17 15:41:22 --> Pagination Class Initialized
INFO - 2018-02-17 15:41:22 --> Helper loaded: form_helper
INFO - 2018-02-17 15:41:22 --> Form Validation Class Initialized
INFO - 2018-02-17 15:41:22 --> Model Class Initialized
INFO - 2018-02-17 15:41:22 --> Controller Class Initialized
INFO - 2018-02-17 15:41:22 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-17 15:41:22 --> Model Class Initialized
INFO - 2018-02-17 15:41:22 --> Model Class Initialized
INFO - 2018-02-17 15:41:22 --> Model Class Initialized
INFO - 2018-02-17 15:41:22 --> Model Class Initialized
INFO - 2018-02-17 15:41:22 --> Config Class Initialized
INFO - 2018-02-17 15:41:22 --> Hooks Class Initialized
DEBUG - 2018-02-17 15:41:22 --> UTF-8 Support Enabled
INFO - 2018-02-17 15:41:22 --> Utf8 Class Initialized
INFO - 2018-02-17 15:41:22 --> URI Class Initialized
INFO - 2018-02-17 15:41:22 --> Router Class Initialized
INFO - 2018-02-17 15:41:22 --> Output Class Initialized
INFO - 2018-02-17 15:41:22 --> Security Class Initialized
DEBUG - 2018-02-17 15:41:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-17 15:41:22 --> Input Class Initialized
INFO - 2018-02-17 15:41:22 --> Language Class Initialized
INFO - 2018-02-17 15:41:22 --> Loader Class Initialized
INFO - 2018-02-17 15:41:22 --> Helper loaded: url_helper
INFO - 2018-02-17 15:41:22 --> Helper loaded: file_helper
INFO - 2018-02-17 15:41:22 --> Helper loaded: email_helper
INFO - 2018-02-17 15:41:22 --> Helper loaded: common_helper
INFO - 2018-02-17 15:41:22 --> Database Driver Class Initialized
DEBUG - 2018-02-17 15:41:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-17 15:41:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-17 15:41:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-17 15:41:22 --> Pagination Class Initialized
INFO - 2018-02-17 15:41:22 --> Helper loaded: form_helper
INFO - 2018-02-17 15:41:22 --> Form Validation Class Initialized
INFO - 2018-02-17 15:41:22 --> Model Class Initialized
INFO - 2018-02-17 15:41:22 --> Controller Class Initialized
INFO - 2018-02-17 15:41:22 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-17 15:41:22 --> Model Class Initialized
INFO - 2018-02-17 15:41:22 --> Model Class Initialized
INFO - 2018-02-17 15:41:22 --> Model Class Initialized
INFO - 2018-02-17 15:41:22 --> Model Class Initialized
INFO - 2018-02-17 15:41:24 --> Config Class Initialized
INFO - 2018-02-17 15:41:24 --> Hooks Class Initialized
DEBUG - 2018-02-17 15:41:24 --> UTF-8 Support Enabled
INFO - 2018-02-17 15:41:24 --> Utf8 Class Initialized
INFO - 2018-02-17 15:41:24 --> URI Class Initialized
INFO - 2018-02-17 15:41:24 --> Router Class Initialized
INFO - 2018-02-17 15:41:24 --> Output Class Initialized
INFO - 2018-02-17 15:41:24 --> Security Class Initialized
DEBUG - 2018-02-17 15:41:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-17 15:41:24 --> Input Class Initialized
INFO - 2018-02-17 15:41:24 --> Language Class Initialized
INFO - 2018-02-17 15:41:24 --> Loader Class Initialized
INFO - 2018-02-17 15:41:24 --> Helper loaded: url_helper
INFO - 2018-02-17 15:41:24 --> Helper loaded: file_helper
INFO - 2018-02-17 15:41:24 --> Helper loaded: email_helper
INFO - 2018-02-17 15:41:24 --> Helper loaded: common_helper
INFO - 2018-02-17 15:41:24 --> Database Driver Class Initialized
DEBUG - 2018-02-17 15:41:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-17 15:41:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-17 15:41:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-17 15:41:24 --> Pagination Class Initialized
INFO - 2018-02-17 15:41:24 --> Helper loaded: form_helper
INFO - 2018-02-17 15:41:24 --> Form Validation Class Initialized
INFO - 2018-02-17 15:41:24 --> Model Class Initialized
INFO - 2018-02-17 15:41:24 --> Controller Class Initialized
INFO - 2018-02-17 15:41:24 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-17 15:41:24 --> Model Class Initialized
INFO - 2018-02-17 15:41:24 --> Model Class Initialized
INFO - 2018-02-17 15:41:24 --> Model Class Initialized
INFO - 2018-02-17 15:41:24 --> Model Class Initialized
INFO - 2018-02-17 15:41:24 --> Config Class Initialized
INFO - 2018-02-17 15:41:24 --> Hooks Class Initialized
DEBUG - 2018-02-17 15:41:24 --> UTF-8 Support Enabled
INFO - 2018-02-17 15:41:24 --> Utf8 Class Initialized
INFO - 2018-02-17 15:41:24 --> URI Class Initialized
INFO - 2018-02-17 15:41:24 --> Router Class Initialized
INFO - 2018-02-17 15:41:24 --> Output Class Initialized
INFO - 2018-02-17 15:41:24 --> Security Class Initialized
DEBUG - 2018-02-17 15:41:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-17 15:41:24 --> Input Class Initialized
INFO - 2018-02-17 15:41:24 --> Language Class Initialized
INFO - 2018-02-17 15:41:24 --> Loader Class Initialized
INFO - 2018-02-17 15:41:24 --> Helper loaded: url_helper
INFO - 2018-02-17 15:41:24 --> Helper loaded: file_helper
INFO - 2018-02-17 15:41:24 --> Helper loaded: email_helper
INFO - 2018-02-17 15:41:24 --> Helper loaded: common_helper
INFO - 2018-02-17 15:41:24 --> Database Driver Class Initialized
DEBUG - 2018-02-17 15:41:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-17 15:41:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-17 15:41:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-17 15:41:24 --> Pagination Class Initialized
INFO - 2018-02-17 15:41:24 --> Helper loaded: form_helper
INFO - 2018-02-17 15:41:24 --> Form Validation Class Initialized
INFO - 2018-02-17 15:41:24 --> Model Class Initialized
INFO - 2018-02-17 15:41:24 --> Controller Class Initialized
INFO - 2018-02-17 15:41:24 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-17 15:41:24 --> Model Class Initialized
INFO - 2018-02-17 15:41:24 --> Model Class Initialized
INFO - 2018-02-17 15:41:24 --> Model Class Initialized
INFO - 2018-02-17 15:41:24 --> Model Class Initialized
INFO - 2018-02-17 15:41:38 --> Config Class Initialized
INFO - 2018-02-17 15:41:38 --> Hooks Class Initialized
DEBUG - 2018-02-17 15:41:38 --> UTF-8 Support Enabled
INFO - 2018-02-17 15:41:38 --> Utf8 Class Initialized
INFO - 2018-02-17 15:41:38 --> URI Class Initialized
INFO - 2018-02-17 15:41:38 --> Router Class Initialized
INFO - 2018-02-17 15:41:38 --> Output Class Initialized
INFO - 2018-02-17 15:41:38 --> Security Class Initialized
DEBUG - 2018-02-17 15:41:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-17 15:41:38 --> Input Class Initialized
INFO - 2018-02-17 15:41:38 --> Language Class Initialized
INFO - 2018-02-17 15:41:38 --> Loader Class Initialized
INFO - 2018-02-17 15:41:38 --> Helper loaded: url_helper
INFO - 2018-02-17 15:41:38 --> Helper loaded: file_helper
INFO - 2018-02-17 15:41:38 --> Helper loaded: email_helper
INFO - 2018-02-17 15:41:38 --> Helper loaded: common_helper
INFO - 2018-02-17 15:41:38 --> Database Driver Class Initialized
DEBUG - 2018-02-17 15:41:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-17 15:41:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-17 15:41:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-17 15:41:38 --> Pagination Class Initialized
INFO - 2018-02-17 15:41:38 --> Helper loaded: form_helper
INFO - 2018-02-17 15:41:38 --> Form Validation Class Initialized
INFO - 2018-02-17 15:41:38 --> Model Class Initialized
INFO - 2018-02-17 15:41:38 --> Controller Class Initialized
INFO - 2018-02-17 15:41:38 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-17 15:41:38 --> Model Class Initialized
INFO - 2018-02-17 15:41:38 --> Model Class Initialized
INFO - 2018-02-17 15:41:38 --> Model Class Initialized
INFO - 2018-02-17 15:41:38 --> Model Class Initialized
INFO - 2018-02-17 15:41:38 --> Config Class Initialized
INFO - 2018-02-17 15:41:38 --> Hooks Class Initialized
DEBUG - 2018-02-17 15:41:38 --> UTF-8 Support Enabled
INFO - 2018-02-17 15:41:38 --> Utf8 Class Initialized
INFO - 2018-02-17 15:41:38 --> URI Class Initialized
INFO - 2018-02-17 15:41:38 --> Router Class Initialized
INFO - 2018-02-17 15:41:38 --> Output Class Initialized
INFO - 2018-02-17 15:41:38 --> Security Class Initialized
DEBUG - 2018-02-17 15:41:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-17 15:41:38 --> Input Class Initialized
INFO - 2018-02-17 15:41:38 --> Language Class Initialized
INFO - 2018-02-17 15:41:38 --> Loader Class Initialized
INFO - 2018-02-17 15:41:38 --> Helper loaded: url_helper
INFO - 2018-02-17 15:41:38 --> Helper loaded: file_helper
INFO - 2018-02-17 15:41:38 --> Helper loaded: email_helper
INFO - 2018-02-17 15:41:38 --> Helper loaded: common_helper
INFO - 2018-02-17 15:41:38 --> Database Driver Class Initialized
DEBUG - 2018-02-17 15:41:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-17 15:41:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-17 15:41:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-17 15:41:38 --> Pagination Class Initialized
INFO - 2018-02-17 15:41:38 --> Helper loaded: form_helper
INFO - 2018-02-17 15:41:38 --> Form Validation Class Initialized
INFO - 2018-02-17 15:41:38 --> Model Class Initialized
INFO - 2018-02-17 15:41:38 --> Controller Class Initialized
INFO - 2018-02-17 15:41:38 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-17 15:41:38 --> Model Class Initialized
INFO - 2018-02-17 15:41:38 --> Model Class Initialized
INFO - 2018-02-17 15:41:38 --> Model Class Initialized
INFO - 2018-02-17 15:41:38 --> Model Class Initialized
INFO - 2018-02-17 15:45:34 --> Config Class Initialized
INFO - 2018-02-17 15:45:34 --> Hooks Class Initialized
DEBUG - 2018-02-17 15:45:34 --> UTF-8 Support Enabled
INFO - 2018-02-17 15:45:34 --> Utf8 Class Initialized
INFO - 2018-02-17 15:45:34 --> URI Class Initialized
INFO - 2018-02-17 15:45:34 --> Router Class Initialized
INFO - 2018-02-17 15:45:34 --> Output Class Initialized
INFO - 2018-02-17 15:45:34 --> Security Class Initialized
DEBUG - 2018-02-17 15:45:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-17 15:45:34 --> Input Class Initialized
INFO - 2018-02-17 15:45:34 --> Language Class Initialized
INFO - 2018-02-17 15:45:34 --> Loader Class Initialized
INFO - 2018-02-17 15:45:34 --> Helper loaded: url_helper
INFO - 2018-02-17 15:45:34 --> Helper loaded: file_helper
INFO - 2018-02-17 15:45:34 --> Helper loaded: email_helper
INFO - 2018-02-17 15:45:34 --> Helper loaded: common_helper
INFO - 2018-02-17 15:45:34 --> Database Driver Class Initialized
DEBUG - 2018-02-17 15:45:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-17 15:45:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-17 15:45:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-17 15:45:34 --> Pagination Class Initialized
INFO - 2018-02-17 15:45:34 --> Helper loaded: form_helper
INFO - 2018-02-17 15:45:34 --> Form Validation Class Initialized
INFO - 2018-02-17 15:45:34 --> Model Class Initialized
INFO - 2018-02-17 15:45:34 --> Controller Class Initialized
INFO - 2018-02-17 15:45:34 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-17 15:45:34 --> Model Class Initialized
INFO - 2018-02-17 15:45:34 --> Model Class Initialized
INFO - 2018-02-17 15:45:34 --> Model Class Initialized
INFO - 2018-02-17 15:45:34 --> Model Class Initialized
INFO - 2018-02-17 15:45:34 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-17 15:45:34 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-17 15:45:34 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-17 15:45:34 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-17 15:45:34 --> File loaded: /var/www/html/project/radio/application/views/tracks/add_edit.php
INFO - 2018-02-17 15:45:34 --> Final output sent to browser
DEBUG - 2018-02-17 15:45:34 --> Total execution time: 0.0108
INFO - 2018-02-17 15:45:37 --> Config Class Initialized
INFO - 2018-02-17 15:45:37 --> Hooks Class Initialized
DEBUG - 2018-02-17 15:45:37 --> UTF-8 Support Enabled
INFO - 2018-02-17 15:45:37 --> Utf8 Class Initialized
INFO - 2018-02-17 15:45:37 --> URI Class Initialized
INFO - 2018-02-17 15:45:37 --> Router Class Initialized
INFO - 2018-02-17 15:45:37 --> Output Class Initialized
INFO - 2018-02-17 15:45:37 --> Security Class Initialized
DEBUG - 2018-02-17 15:45:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-17 15:45:37 --> Input Class Initialized
INFO - 2018-02-17 15:45:37 --> Language Class Initialized
INFO - 2018-02-17 15:45:37 --> Loader Class Initialized
INFO - 2018-02-17 15:45:37 --> Helper loaded: url_helper
INFO - 2018-02-17 15:45:37 --> Helper loaded: file_helper
INFO - 2018-02-17 15:45:37 --> Helper loaded: email_helper
INFO - 2018-02-17 15:45:37 --> Helper loaded: common_helper
INFO - 2018-02-17 15:45:37 --> Database Driver Class Initialized
DEBUG - 2018-02-17 15:45:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-17 15:45:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-17 15:45:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-17 15:45:37 --> Pagination Class Initialized
INFO - 2018-02-17 15:45:37 --> Helper loaded: form_helper
INFO - 2018-02-17 15:45:37 --> Form Validation Class Initialized
INFO - 2018-02-17 15:45:37 --> Model Class Initialized
INFO - 2018-02-17 15:45:37 --> Controller Class Initialized
INFO - 2018-02-17 15:45:37 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-17 15:45:37 --> Model Class Initialized
INFO - 2018-02-17 15:45:37 --> Model Class Initialized
INFO - 2018-02-17 15:45:37 --> Model Class Initialized
INFO - 2018-02-17 15:45:37 --> Model Class Initialized
INFO - 2018-02-17 15:45:37 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-17 15:45:37 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-17 15:45:37 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-17 15:45:37 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-17 15:45:37 --> File loaded: /var/www/html/project/radio/application/views/tracks/add_edit.php
INFO - 2018-02-17 15:45:37 --> Final output sent to browser
DEBUG - 2018-02-17 15:45:37 --> Total execution time: 0.0085
INFO - 2018-02-17 15:50:56 --> Config Class Initialized
INFO - 2018-02-17 15:50:56 --> Hooks Class Initialized
DEBUG - 2018-02-17 15:50:56 --> UTF-8 Support Enabled
INFO - 2018-02-17 15:50:56 --> Utf8 Class Initialized
INFO - 2018-02-17 15:50:56 --> URI Class Initialized
INFO - 2018-02-17 15:50:56 --> Router Class Initialized
INFO - 2018-02-17 15:50:56 --> Output Class Initialized
INFO - 2018-02-17 15:50:56 --> Security Class Initialized
DEBUG - 2018-02-17 15:50:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-17 15:50:56 --> Input Class Initialized
INFO - 2018-02-17 15:50:56 --> Language Class Initialized
INFO - 2018-02-17 15:50:56 --> Loader Class Initialized
INFO - 2018-02-17 15:50:56 --> Helper loaded: url_helper
INFO - 2018-02-17 15:50:56 --> Helper loaded: file_helper
INFO - 2018-02-17 15:50:56 --> Helper loaded: email_helper
INFO - 2018-02-17 15:50:56 --> Helper loaded: common_helper
INFO - 2018-02-17 15:50:56 --> Database Driver Class Initialized
DEBUG - 2018-02-17 15:50:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-17 15:50:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-17 15:50:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-17 15:50:56 --> Pagination Class Initialized
INFO - 2018-02-17 15:50:56 --> Helper loaded: form_helper
INFO - 2018-02-17 15:50:56 --> Form Validation Class Initialized
INFO - 2018-02-17 15:50:56 --> Model Class Initialized
INFO - 2018-02-17 15:50:56 --> Controller Class Initialized
INFO - 2018-02-17 15:50:56 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-17 15:50:56 --> Model Class Initialized
INFO - 2018-02-17 15:50:56 --> Model Class Initialized
INFO - 2018-02-17 15:50:56 --> Model Class Initialized
INFO - 2018-02-17 15:50:56 --> Model Class Initialized
INFO - 2018-02-17 15:51:35 --> Config Class Initialized
INFO - 2018-02-17 15:51:35 --> Hooks Class Initialized
DEBUG - 2018-02-17 15:51:35 --> UTF-8 Support Enabled
INFO - 2018-02-17 15:51:35 --> Utf8 Class Initialized
INFO - 2018-02-17 15:51:35 --> URI Class Initialized
INFO - 2018-02-17 15:51:35 --> Router Class Initialized
INFO - 2018-02-17 15:51:35 --> Output Class Initialized
INFO - 2018-02-17 15:51:35 --> Security Class Initialized
DEBUG - 2018-02-17 15:51:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-17 15:51:35 --> Input Class Initialized
INFO - 2018-02-17 15:51:35 --> Language Class Initialized
INFO - 2018-02-17 15:51:35 --> Loader Class Initialized
INFO - 2018-02-17 15:51:35 --> Helper loaded: url_helper
INFO - 2018-02-17 15:51:35 --> Helper loaded: file_helper
INFO - 2018-02-17 15:51:35 --> Helper loaded: email_helper
INFO - 2018-02-17 15:51:35 --> Helper loaded: common_helper
INFO - 2018-02-17 15:51:35 --> Database Driver Class Initialized
DEBUG - 2018-02-17 15:51:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-17 15:51:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-17 15:51:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-17 15:51:35 --> Pagination Class Initialized
INFO - 2018-02-17 15:51:35 --> Helper loaded: form_helper
INFO - 2018-02-17 15:51:35 --> Form Validation Class Initialized
INFO - 2018-02-17 15:51:35 --> Model Class Initialized
INFO - 2018-02-17 15:51:35 --> Controller Class Initialized
INFO - 2018-02-17 15:51:35 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-17 15:51:35 --> Model Class Initialized
INFO - 2018-02-17 15:51:35 --> Model Class Initialized
INFO - 2018-02-17 15:51:35 --> Model Class Initialized
INFO - 2018-02-17 15:51:35 --> Model Class Initialized
INFO - 2018-02-17 15:51:35 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-17 15:51:35 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-17 15:51:35 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-17 15:51:35 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-17 15:51:35 --> File loaded: /var/www/html/project/radio/application/views/tracks/add_edit.php
INFO - 2018-02-17 15:51:35 --> Final output sent to browser
DEBUG - 2018-02-17 15:51:35 --> Total execution time: 0.0104
INFO - 2018-02-17 15:56:29 --> Config Class Initialized
INFO - 2018-02-17 15:56:29 --> Hooks Class Initialized
DEBUG - 2018-02-17 15:56:29 --> UTF-8 Support Enabled
INFO - 2018-02-17 15:56:29 --> Utf8 Class Initialized
INFO - 2018-02-17 15:56:29 --> URI Class Initialized
INFO - 2018-02-17 15:56:29 --> Router Class Initialized
INFO - 2018-02-17 15:56:29 --> Output Class Initialized
INFO - 2018-02-17 15:56:29 --> Security Class Initialized
DEBUG - 2018-02-17 15:56:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-17 15:56:29 --> Input Class Initialized
INFO - 2018-02-17 15:56:29 --> Language Class Initialized
INFO - 2018-02-17 15:56:29 --> Loader Class Initialized
INFO - 2018-02-17 15:56:29 --> Helper loaded: url_helper
INFO - 2018-02-17 15:56:29 --> Helper loaded: file_helper
INFO - 2018-02-17 15:56:29 --> Helper loaded: email_helper
INFO - 2018-02-17 15:56:29 --> Helper loaded: common_helper
INFO - 2018-02-17 15:56:29 --> Database Driver Class Initialized
DEBUG - 2018-02-17 15:56:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-17 15:56:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-17 15:56:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-17 15:56:29 --> Pagination Class Initialized
INFO - 2018-02-17 15:56:29 --> Helper loaded: form_helper
INFO - 2018-02-17 15:56:29 --> Form Validation Class Initialized
INFO - 2018-02-17 15:56:29 --> Model Class Initialized
INFO - 2018-02-17 15:56:29 --> Controller Class Initialized
INFO - 2018-02-17 15:56:29 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-17 15:56:29 --> Model Class Initialized
INFO - 2018-02-17 15:56:29 --> Model Class Initialized
INFO - 2018-02-17 15:56:29 --> Model Class Initialized
INFO - 2018-02-17 15:56:29 --> Model Class Initialized
INFO - 2018-02-17 15:56:29 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-17 15:56:29 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-17 15:56:29 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-17 15:56:29 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-17 15:56:29 --> File loaded: /var/www/html/project/radio/application/views/tracks/index.php
INFO - 2018-02-17 15:56:29 --> Final output sent to browser
DEBUG - 2018-02-17 15:56:29 --> Total execution time: 0.0076
INFO - 2018-02-17 15:56:29 --> Config Class Initialized
INFO - 2018-02-17 15:56:29 --> Hooks Class Initialized
DEBUG - 2018-02-17 15:56:29 --> UTF-8 Support Enabled
INFO - 2018-02-17 15:56:29 --> Utf8 Class Initialized
INFO - 2018-02-17 15:56:29 --> URI Class Initialized
INFO - 2018-02-17 15:56:29 --> Router Class Initialized
INFO - 2018-02-17 15:56:29 --> Output Class Initialized
INFO - 2018-02-17 15:56:29 --> Security Class Initialized
DEBUG - 2018-02-17 15:56:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-17 15:56:29 --> Input Class Initialized
INFO - 2018-02-17 15:56:29 --> Language Class Initialized
INFO - 2018-02-17 15:56:29 --> Loader Class Initialized
INFO - 2018-02-17 15:56:29 --> Helper loaded: url_helper
INFO - 2018-02-17 15:56:29 --> Helper loaded: file_helper
INFO - 2018-02-17 15:56:29 --> Helper loaded: email_helper
INFO - 2018-02-17 15:56:29 --> Helper loaded: common_helper
INFO - 2018-02-17 15:56:29 --> Database Driver Class Initialized
DEBUG - 2018-02-17 15:56:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-17 15:56:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-17 15:56:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-17 15:56:29 --> Pagination Class Initialized
INFO - 2018-02-17 15:56:29 --> Helper loaded: form_helper
INFO - 2018-02-17 15:56:29 --> Form Validation Class Initialized
INFO - 2018-02-17 15:56:29 --> Model Class Initialized
INFO - 2018-02-17 15:56:29 --> Controller Class Initialized
INFO - 2018-02-17 15:56:29 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-17 15:56:29 --> Model Class Initialized
INFO - 2018-02-17 15:56:29 --> Model Class Initialized
INFO - 2018-02-17 15:56:29 --> Model Class Initialized
INFO - 2018-02-17 15:56:29 --> Model Class Initialized
INFO - 2018-02-17 15:56:31 --> Config Class Initialized
INFO - 2018-02-17 15:56:31 --> Hooks Class Initialized
DEBUG - 2018-02-17 15:56:31 --> UTF-8 Support Enabled
INFO - 2018-02-17 15:56:31 --> Utf8 Class Initialized
INFO - 2018-02-17 15:56:31 --> URI Class Initialized
INFO - 2018-02-17 15:56:31 --> Router Class Initialized
INFO - 2018-02-17 15:56:31 --> Output Class Initialized
INFO - 2018-02-17 15:56:31 --> Security Class Initialized
DEBUG - 2018-02-17 15:56:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-17 15:56:31 --> Input Class Initialized
INFO - 2018-02-17 15:56:31 --> Language Class Initialized
INFO - 2018-02-17 15:56:31 --> Loader Class Initialized
INFO - 2018-02-17 15:56:31 --> Helper loaded: url_helper
INFO - 2018-02-17 15:56:31 --> Helper loaded: file_helper
INFO - 2018-02-17 15:56:31 --> Helper loaded: email_helper
INFO - 2018-02-17 15:56:31 --> Helper loaded: common_helper
INFO - 2018-02-17 15:56:31 --> Database Driver Class Initialized
DEBUG - 2018-02-17 15:56:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-17 15:56:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-17 15:56:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-17 15:56:31 --> Pagination Class Initialized
INFO - 2018-02-17 15:56:31 --> Helper loaded: form_helper
INFO - 2018-02-17 15:56:31 --> Form Validation Class Initialized
INFO - 2018-02-17 15:56:31 --> Model Class Initialized
INFO - 2018-02-17 15:56:31 --> Controller Class Initialized
INFO - 2018-02-17 15:56:31 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-17 15:56:31 --> Model Class Initialized
INFO - 2018-02-17 15:56:31 --> Model Class Initialized
INFO - 2018-02-17 15:56:31 --> Model Class Initialized
INFO - 2018-02-17 15:56:31 --> Model Class Initialized
INFO - 2018-02-17 15:56:31 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-17 15:56:31 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-17 15:56:31 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-17 15:56:31 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-17 15:56:31 --> File loaded: /var/www/html/project/radio/application/views/tracks/add_edit.php
INFO - 2018-02-17 15:56:31 --> Final output sent to browser
DEBUG - 2018-02-17 15:56:31 --> Total execution time: 0.0100
INFO - 2018-02-17 15:56:39 --> Config Class Initialized
INFO - 2018-02-17 15:56:39 --> Hooks Class Initialized
DEBUG - 2018-02-17 15:56:39 --> UTF-8 Support Enabled
INFO - 2018-02-17 15:56:39 --> Utf8 Class Initialized
INFO - 2018-02-17 15:56:39 --> URI Class Initialized
INFO - 2018-02-17 15:56:39 --> Router Class Initialized
INFO - 2018-02-17 15:56:39 --> Output Class Initialized
INFO - 2018-02-17 15:56:39 --> Security Class Initialized
DEBUG - 2018-02-17 15:56:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-17 15:56:39 --> Input Class Initialized
INFO - 2018-02-17 15:56:39 --> Language Class Initialized
INFO - 2018-02-17 15:56:39 --> Loader Class Initialized
INFO - 2018-02-17 15:56:39 --> Helper loaded: url_helper
INFO - 2018-02-17 15:56:39 --> Helper loaded: file_helper
INFO - 2018-02-17 15:56:39 --> Helper loaded: email_helper
INFO - 2018-02-17 15:56:39 --> Helper loaded: common_helper
INFO - 2018-02-17 15:56:39 --> Database Driver Class Initialized
DEBUG - 2018-02-17 15:56:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-17 15:56:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-17 15:56:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-17 15:56:39 --> Pagination Class Initialized
INFO - 2018-02-17 15:56:39 --> Helper loaded: form_helper
INFO - 2018-02-17 15:56:39 --> Form Validation Class Initialized
INFO - 2018-02-17 15:56:39 --> Model Class Initialized
INFO - 2018-02-17 15:56:39 --> Controller Class Initialized
INFO - 2018-02-17 15:56:39 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-17 15:56:39 --> Model Class Initialized
INFO - 2018-02-17 15:56:39 --> Model Class Initialized
INFO - 2018-02-17 15:56:39 --> Model Class Initialized
INFO - 2018-02-17 15:56:39 --> Model Class Initialized
INFO - 2018-02-17 15:57:14 --> Config Class Initialized
INFO - 2018-02-17 15:57:14 --> Hooks Class Initialized
DEBUG - 2018-02-17 15:57:14 --> UTF-8 Support Enabled
INFO - 2018-02-17 15:57:14 --> Utf8 Class Initialized
INFO - 2018-02-17 15:57:14 --> URI Class Initialized
INFO - 2018-02-17 15:57:14 --> Router Class Initialized
INFO - 2018-02-17 15:57:14 --> Output Class Initialized
INFO - 2018-02-17 15:57:14 --> Security Class Initialized
DEBUG - 2018-02-17 15:57:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-17 15:57:14 --> Input Class Initialized
INFO - 2018-02-17 15:57:14 --> Language Class Initialized
INFO - 2018-02-17 15:57:14 --> Loader Class Initialized
INFO - 2018-02-17 15:57:14 --> Helper loaded: url_helper
INFO - 2018-02-17 15:57:14 --> Helper loaded: file_helper
INFO - 2018-02-17 15:57:14 --> Helper loaded: email_helper
INFO - 2018-02-17 15:57:14 --> Helper loaded: common_helper
INFO - 2018-02-17 15:57:14 --> Database Driver Class Initialized
DEBUG - 2018-02-17 15:57:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-17 15:57:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-17 15:57:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-17 15:57:14 --> Pagination Class Initialized
INFO - 2018-02-17 15:57:14 --> Helper loaded: form_helper
INFO - 2018-02-17 15:57:14 --> Form Validation Class Initialized
INFO - 2018-02-17 15:57:14 --> Model Class Initialized
INFO - 2018-02-17 15:57:14 --> Controller Class Initialized
INFO - 2018-02-17 15:57:14 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-17 15:57:14 --> Model Class Initialized
INFO - 2018-02-17 15:57:14 --> Model Class Initialized
INFO - 2018-02-17 15:57:14 --> Model Class Initialized
INFO - 2018-02-17 15:57:14 --> Model Class Initialized
INFO - 2018-02-17 15:57:16 --> Config Class Initialized
INFO - 2018-02-17 15:57:16 --> Hooks Class Initialized
DEBUG - 2018-02-17 15:57:16 --> UTF-8 Support Enabled
INFO - 2018-02-17 15:57:16 --> Utf8 Class Initialized
INFO - 2018-02-17 15:57:16 --> URI Class Initialized
INFO - 2018-02-17 15:57:16 --> Router Class Initialized
INFO - 2018-02-17 15:57:16 --> Output Class Initialized
INFO - 2018-02-17 15:57:16 --> Security Class Initialized
DEBUG - 2018-02-17 15:57:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-17 15:57:16 --> Input Class Initialized
INFO - 2018-02-17 15:57:16 --> Language Class Initialized
INFO - 2018-02-17 15:57:16 --> Loader Class Initialized
INFO - 2018-02-17 15:57:16 --> Helper loaded: url_helper
INFO - 2018-02-17 15:57:16 --> Helper loaded: file_helper
INFO - 2018-02-17 15:57:16 --> Helper loaded: email_helper
INFO - 2018-02-17 15:57:16 --> Helper loaded: common_helper
INFO - 2018-02-17 15:57:16 --> Database Driver Class Initialized
DEBUG - 2018-02-17 15:57:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-17 15:57:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-17 15:57:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-17 15:57:16 --> Pagination Class Initialized
INFO - 2018-02-17 15:57:16 --> Helper loaded: form_helper
INFO - 2018-02-17 15:57:16 --> Form Validation Class Initialized
INFO - 2018-02-17 15:57:16 --> Model Class Initialized
INFO - 2018-02-17 15:57:16 --> Controller Class Initialized
INFO - 2018-02-17 15:57:16 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-17 15:57:16 --> Model Class Initialized
INFO - 2018-02-17 15:57:16 --> Model Class Initialized
INFO - 2018-02-17 15:57:16 --> Model Class Initialized
INFO - 2018-02-17 15:57:16 --> Model Class Initialized
INFO - 2018-02-17 15:57:16 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-17 15:57:16 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-17 15:57:16 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-17 15:57:16 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-17 15:57:16 --> File loaded: /var/www/html/project/radio/application/views/tracks/add_edit.php
INFO - 2018-02-17 15:57:16 --> Final output sent to browser
DEBUG - 2018-02-17 15:57:16 --> Total execution time: 0.0095
INFO - 2018-02-17 15:57:18 --> Config Class Initialized
INFO - 2018-02-17 15:57:18 --> Hooks Class Initialized
DEBUG - 2018-02-17 15:57:18 --> UTF-8 Support Enabled
INFO - 2018-02-17 15:57:18 --> Utf8 Class Initialized
INFO - 2018-02-17 15:57:18 --> URI Class Initialized
INFO - 2018-02-17 15:57:18 --> Router Class Initialized
INFO - 2018-02-17 15:57:18 --> Output Class Initialized
INFO - 2018-02-17 15:57:18 --> Security Class Initialized
DEBUG - 2018-02-17 15:57:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-17 15:57:18 --> Input Class Initialized
INFO - 2018-02-17 15:57:18 --> Language Class Initialized
INFO - 2018-02-17 15:57:18 --> Loader Class Initialized
INFO - 2018-02-17 15:57:18 --> Helper loaded: url_helper
INFO - 2018-02-17 15:57:18 --> Helper loaded: file_helper
INFO - 2018-02-17 15:57:18 --> Helper loaded: email_helper
INFO - 2018-02-17 15:57:18 --> Helper loaded: common_helper
INFO - 2018-02-17 15:57:18 --> Database Driver Class Initialized
DEBUG - 2018-02-17 15:57:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-17 15:57:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-17 15:57:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-17 15:57:18 --> Pagination Class Initialized
INFO - 2018-02-17 15:57:18 --> Helper loaded: form_helper
INFO - 2018-02-17 15:57:18 --> Form Validation Class Initialized
INFO - 2018-02-17 15:57:18 --> Model Class Initialized
INFO - 2018-02-17 15:57:18 --> Controller Class Initialized
INFO - 2018-02-17 15:57:18 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-17 15:57:18 --> Model Class Initialized
INFO - 2018-02-17 15:57:18 --> Model Class Initialized
INFO - 2018-02-17 15:57:18 --> Model Class Initialized
INFO - 2018-02-17 15:57:18 --> Model Class Initialized
INFO - 2018-02-17 15:57:18 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-17 15:57:18 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-17 15:57:18 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-17 15:57:18 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-17 15:57:18 --> File loaded: /var/www/html/project/radio/application/views/tracks/add_edit.php
INFO - 2018-02-17 15:57:18 --> Final output sent to browser
DEBUG - 2018-02-17 15:57:18 --> Total execution time: 0.0086
INFO - 2018-02-17 15:57:43 --> Config Class Initialized
INFO - 2018-02-17 15:57:43 --> Hooks Class Initialized
DEBUG - 2018-02-17 15:57:43 --> UTF-8 Support Enabled
INFO - 2018-02-17 15:57:43 --> Utf8 Class Initialized
INFO - 2018-02-17 15:57:43 --> URI Class Initialized
INFO - 2018-02-17 15:57:43 --> Router Class Initialized
INFO - 2018-02-17 15:57:43 --> Output Class Initialized
INFO - 2018-02-17 15:57:43 --> Security Class Initialized
DEBUG - 2018-02-17 15:57:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-17 15:57:43 --> Input Class Initialized
INFO - 2018-02-17 15:57:43 --> Language Class Initialized
INFO - 2018-02-17 15:57:43 --> Loader Class Initialized
INFO - 2018-02-17 15:57:43 --> Helper loaded: url_helper
INFO - 2018-02-17 15:57:43 --> Helper loaded: file_helper
INFO - 2018-02-17 15:57:43 --> Helper loaded: email_helper
INFO - 2018-02-17 15:57:43 --> Helper loaded: common_helper
INFO - 2018-02-17 15:57:43 --> Database Driver Class Initialized
DEBUG - 2018-02-17 15:57:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-17 15:57:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-17 15:57:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-17 15:57:43 --> Pagination Class Initialized
INFO - 2018-02-17 15:57:43 --> Helper loaded: form_helper
INFO - 2018-02-17 15:57:43 --> Form Validation Class Initialized
INFO - 2018-02-17 15:57:43 --> Model Class Initialized
INFO - 2018-02-17 15:57:43 --> Controller Class Initialized
INFO - 2018-02-17 15:57:43 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-17 15:57:43 --> Model Class Initialized
INFO - 2018-02-17 15:57:43 --> Model Class Initialized
INFO - 2018-02-17 15:57:43 --> Model Class Initialized
INFO - 2018-02-17 15:57:43 --> Model Class Initialized
INFO - 2018-02-17 15:57:43 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-17 15:57:43 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-17 15:57:43 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-17 15:57:43 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-17 15:57:43 --> File loaded: /var/www/html/project/radio/application/views/tracks/add_edit.php
INFO - 2018-02-17 15:57:43 --> Final output sent to browser
DEBUG - 2018-02-17 15:57:43 --> Total execution time: 0.0120
INFO - 2018-02-17 15:57:50 --> Config Class Initialized
INFO - 2018-02-17 15:57:50 --> Hooks Class Initialized
DEBUG - 2018-02-17 15:57:50 --> UTF-8 Support Enabled
INFO - 2018-02-17 15:57:50 --> Utf8 Class Initialized
INFO - 2018-02-17 15:57:50 --> URI Class Initialized
INFO - 2018-02-17 15:57:50 --> Router Class Initialized
INFO - 2018-02-17 15:57:50 --> Output Class Initialized
INFO - 2018-02-17 15:57:50 --> Security Class Initialized
DEBUG - 2018-02-17 15:57:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-17 15:57:50 --> Input Class Initialized
INFO - 2018-02-17 15:57:50 --> Language Class Initialized
INFO - 2018-02-17 15:57:50 --> Loader Class Initialized
INFO - 2018-02-17 15:57:50 --> Helper loaded: url_helper
INFO - 2018-02-17 15:57:50 --> Helper loaded: file_helper
INFO - 2018-02-17 15:57:50 --> Helper loaded: email_helper
INFO - 2018-02-17 15:57:50 --> Helper loaded: common_helper
INFO - 2018-02-17 15:57:50 --> Database Driver Class Initialized
DEBUG - 2018-02-17 15:57:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-17 15:57:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-17 15:57:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-17 15:57:50 --> Pagination Class Initialized
INFO - 2018-02-17 15:57:50 --> Helper loaded: form_helper
INFO - 2018-02-17 15:57:50 --> Form Validation Class Initialized
INFO - 2018-02-17 15:57:50 --> Model Class Initialized
INFO - 2018-02-17 15:57:50 --> Controller Class Initialized
INFO - 2018-02-17 15:57:50 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-17 15:57:50 --> Model Class Initialized
INFO - 2018-02-17 15:57:50 --> Model Class Initialized
INFO - 2018-02-17 15:57:50 --> Model Class Initialized
INFO - 2018-02-17 15:57:50 --> Model Class Initialized
INFO - 2018-02-17 15:57:55 --> Config Class Initialized
INFO - 2018-02-17 15:57:55 --> Hooks Class Initialized
DEBUG - 2018-02-17 15:57:55 --> UTF-8 Support Enabled
INFO - 2018-02-17 15:57:55 --> Utf8 Class Initialized
INFO - 2018-02-17 15:57:55 --> URI Class Initialized
INFO - 2018-02-17 15:57:55 --> Router Class Initialized
INFO - 2018-02-17 15:57:55 --> Output Class Initialized
INFO - 2018-02-17 15:57:55 --> Security Class Initialized
DEBUG - 2018-02-17 15:57:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-17 15:57:55 --> Input Class Initialized
INFO - 2018-02-17 15:57:55 --> Language Class Initialized
INFO - 2018-02-17 15:57:55 --> Loader Class Initialized
INFO - 2018-02-17 15:57:55 --> Helper loaded: url_helper
INFO - 2018-02-17 15:57:55 --> Helper loaded: file_helper
INFO - 2018-02-17 15:57:55 --> Helper loaded: email_helper
INFO - 2018-02-17 15:57:55 --> Helper loaded: common_helper
INFO - 2018-02-17 15:57:55 --> Database Driver Class Initialized
DEBUG - 2018-02-17 15:57:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-17 15:57:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-17 15:57:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-17 15:57:55 --> Pagination Class Initialized
INFO - 2018-02-17 15:57:55 --> Helper loaded: form_helper
INFO - 2018-02-17 15:57:55 --> Form Validation Class Initialized
INFO - 2018-02-17 15:57:55 --> Model Class Initialized
INFO - 2018-02-17 15:57:55 --> Controller Class Initialized
INFO - 2018-02-17 15:57:55 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-17 15:57:55 --> Model Class Initialized
INFO - 2018-02-17 15:57:55 --> Model Class Initialized
INFO - 2018-02-17 15:57:55 --> Model Class Initialized
INFO - 2018-02-17 15:57:55 --> Model Class Initialized
INFO - 2018-02-17 15:57:57 --> Config Class Initialized
INFO - 2018-02-17 15:57:57 --> Hooks Class Initialized
DEBUG - 2018-02-17 15:57:57 --> UTF-8 Support Enabled
INFO - 2018-02-17 15:57:57 --> Utf8 Class Initialized
INFO - 2018-02-17 15:57:57 --> URI Class Initialized
INFO - 2018-02-17 15:57:57 --> Router Class Initialized
INFO - 2018-02-17 15:57:57 --> Output Class Initialized
INFO - 2018-02-17 15:57:57 --> Security Class Initialized
DEBUG - 2018-02-17 15:57:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-17 15:57:57 --> Input Class Initialized
INFO - 2018-02-17 15:57:57 --> Language Class Initialized
INFO - 2018-02-17 15:57:57 --> Loader Class Initialized
INFO - 2018-02-17 15:57:57 --> Helper loaded: url_helper
INFO - 2018-02-17 15:57:57 --> Helper loaded: file_helper
INFO - 2018-02-17 15:57:57 --> Helper loaded: email_helper
INFO - 2018-02-17 15:57:57 --> Helper loaded: common_helper
INFO - 2018-02-17 15:57:57 --> Database Driver Class Initialized
DEBUG - 2018-02-17 15:57:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-17 15:57:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-17 15:57:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-17 15:57:57 --> Pagination Class Initialized
INFO - 2018-02-17 15:57:57 --> Helper loaded: form_helper
INFO - 2018-02-17 15:57:57 --> Form Validation Class Initialized
INFO - 2018-02-17 15:57:57 --> Model Class Initialized
INFO - 2018-02-17 15:57:57 --> Controller Class Initialized
INFO - 2018-02-17 15:57:57 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-17 15:57:57 --> Model Class Initialized
INFO - 2018-02-17 15:57:57 --> Model Class Initialized
INFO - 2018-02-17 15:57:57 --> Model Class Initialized
INFO - 2018-02-17 15:57:57 --> Model Class Initialized
INFO - 2018-02-17 15:57:57 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-17 15:57:57 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-17 15:57:57 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-17 15:57:57 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-17 15:57:57 --> File loaded: /var/www/html/project/radio/application/views/tracks/add_edit.php
INFO - 2018-02-17 15:57:57 --> Final output sent to browser
DEBUG - 2018-02-17 15:57:57 --> Total execution time: 0.0093
INFO - 2018-02-17 15:57:59 --> Config Class Initialized
INFO - 2018-02-17 15:57:59 --> Hooks Class Initialized
DEBUG - 2018-02-17 15:57:59 --> UTF-8 Support Enabled
INFO - 2018-02-17 15:57:59 --> Utf8 Class Initialized
INFO - 2018-02-17 15:57:59 --> URI Class Initialized
INFO - 2018-02-17 15:57:59 --> Router Class Initialized
INFO - 2018-02-17 15:57:59 --> Output Class Initialized
INFO - 2018-02-17 15:57:59 --> Security Class Initialized
DEBUG - 2018-02-17 15:57:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-17 15:57:59 --> Input Class Initialized
INFO - 2018-02-17 15:57:59 --> Language Class Initialized
INFO - 2018-02-17 15:57:59 --> Loader Class Initialized
INFO - 2018-02-17 15:57:59 --> Helper loaded: url_helper
INFO - 2018-02-17 15:57:59 --> Helper loaded: file_helper
INFO - 2018-02-17 15:57:59 --> Helper loaded: email_helper
INFO - 2018-02-17 15:57:59 --> Helper loaded: common_helper
INFO - 2018-02-17 15:57:59 --> Database Driver Class Initialized
DEBUG - 2018-02-17 15:57:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-17 15:57:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-17 15:57:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-17 15:57:59 --> Pagination Class Initialized
INFO - 2018-02-17 15:57:59 --> Helper loaded: form_helper
INFO - 2018-02-17 15:57:59 --> Form Validation Class Initialized
INFO - 2018-02-17 15:57:59 --> Model Class Initialized
INFO - 2018-02-17 15:57:59 --> Controller Class Initialized
INFO - 2018-02-17 15:57:59 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-17 15:57:59 --> Model Class Initialized
INFO - 2018-02-17 15:57:59 --> Model Class Initialized
INFO - 2018-02-17 15:57:59 --> Model Class Initialized
INFO - 2018-02-17 15:57:59 --> Model Class Initialized
INFO - 2018-02-17 15:58:14 --> Config Class Initialized
INFO - 2018-02-17 15:58:14 --> Hooks Class Initialized
DEBUG - 2018-02-17 15:58:14 --> UTF-8 Support Enabled
INFO - 2018-02-17 15:58:14 --> Utf8 Class Initialized
INFO - 2018-02-17 15:58:14 --> URI Class Initialized
INFO - 2018-02-17 15:58:14 --> Router Class Initialized
INFO - 2018-02-17 15:58:14 --> Output Class Initialized
INFO - 2018-02-17 15:58:14 --> Security Class Initialized
DEBUG - 2018-02-17 15:58:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-17 15:58:14 --> Input Class Initialized
INFO - 2018-02-17 15:58:14 --> Language Class Initialized
INFO - 2018-02-17 15:58:14 --> Loader Class Initialized
INFO - 2018-02-17 15:58:14 --> Helper loaded: url_helper
INFO - 2018-02-17 15:58:14 --> Helper loaded: file_helper
INFO - 2018-02-17 15:58:14 --> Helper loaded: email_helper
INFO - 2018-02-17 15:58:14 --> Helper loaded: common_helper
INFO - 2018-02-17 15:58:14 --> Database Driver Class Initialized
DEBUG - 2018-02-17 15:58:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-17 15:58:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-17 15:58:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-17 15:58:14 --> Pagination Class Initialized
INFO - 2018-02-17 15:58:14 --> Helper loaded: form_helper
INFO - 2018-02-17 15:58:14 --> Form Validation Class Initialized
INFO - 2018-02-17 15:58:14 --> Model Class Initialized
INFO - 2018-02-17 15:58:14 --> Controller Class Initialized
INFO - 2018-02-17 15:58:14 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-17 15:58:14 --> Model Class Initialized
INFO - 2018-02-17 15:58:14 --> Model Class Initialized
INFO - 2018-02-17 15:58:14 --> Model Class Initialized
INFO - 2018-02-17 15:58:14 --> Model Class Initialized
INFO - 2018-02-17 15:58:36 --> Config Class Initialized
INFO - 2018-02-17 15:58:36 --> Hooks Class Initialized
DEBUG - 2018-02-17 15:58:36 --> UTF-8 Support Enabled
INFO - 2018-02-17 15:58:36 --> Utf8 Class Initialized
INFO - 2018-02-17 15:58:36 --> URI Class Initialized
INFO - 2018-02-17 15:58:36 --> Router Class Initialized
INFO - 2018-02-17 15:58:36 --> Output Class Initialized
INFO - 2018-02-17 15:58:36 --> Security Class Initialized
DEBUG - 2018-02-17 15:58:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-17 15:58:36 --> Input Class Initialized
INFO - 2018-02-17 15:58:36 --> Language Class Initialized
INFO - 2018-02-17 15:58:36 --> Loader Class Initialized
INFO - 2018-02-17 15:58:36 --> Helper loaded: url_helper
INFO - 2018-02-17 15:58:36 --> Helper loaded: file_helper
INFO - 2018-02-17 15:58:36 --> Helper loaded: email_helper
INFO - 2018-02-17 15:58:36 --> Helper loaded: common_helper
INFO - 2018-02-17 15:58:36 --> Database Driver Class Initialized
DEBUG - 2018-02-17 15:58:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-17 15:58:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-17 15:58:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-17 15:58:36 --> Pagination Class Initialized
INFO - 2018-02-17 15:58:36 --> Helper loaded: form_helper
INFO - 2018-02-17 15:58:36 --> Form Validation Class Initialized
INFO - 2018-02-17 15:58:36 --> Model Class Initialized
INFO - 2018-02-17 15:58:36 --> Controller Class Initialized
INFO - 2018-02-17 15:58:36 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-17 15:58:36 --> Model Class Initialized
INFO - 2018-02-17 15:58:36 --> Model Class Initialized
INFO - 2018-02-17 15:58:36 --> Model Class Initialized
INFO - 2018-02-17 15:58:36 --> Model Class Initialized
INFO - 2018-02-17 15:58:36 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-17 15:58:36 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-17 15:58:36 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-17 15:58:36 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-17 15:58:36 --> File loaded: /var/www/html/project/radio/application/views/tracks/add_edit.php
INFO - 2018-02-17 15:58:36 --> Final output sent to browser
DEBUG - 2018-02-17 15:58:36 --> Total execution time: 0.0126
INFO - 2018-02-17 15:58:38 --> Config Class Initialized
INFO - 2018-02-17 15:58:38 --> Hooks Class Initialized
DEBUG - 2018-02-17 15:58:38 --> UTF-8 Support Enabled
INFO - 2018-02-17 15:58:38 --> Utf8 Class Initialized
INFO - 2018-02-17 15:58:38 --> URI Class Initialized
INFO - 2018-02-17 15:58:38 --> Router Class Initialized
INFO - 2018-02-17 15:58:38 --> Output Class Initialized
INFO - 2018-02-17 15:58:38 --> Security Class Initialized
DEBUG - 2018-02-17 15:58:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-17 15:58:38 --> Input Class Initialized
INFO - 2018-02-17 15:58:38 --> Language Class Initialized
INFO - 2018-02-17 15:58:38 --> Loader Class Initialized
INFO - 2018-02-17 15:58:38 --> Helper loaded: url_helper
INFO - 2018-02-17 15:58:38 --> Helper loaded: file_helper
INFO - 2018-02-17 15:58:38 --> Helper loaded: email_helper
INFO - 2018-02-17 15:58:38 --> Helper loaded: common_helper
INFO - 2018-02-17 15:58:38 --> Database Driver Class Initialized
DEBUG - 2018-02-17 15:58:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-17 15:58:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-17 15:58:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-17 15:58:38 --> Pagination Class Initialized
INFO - 2018-02-17 15:58:38 --> Helper loaded: form_helper
INFO - 2018-02-17 15:58:38 --> Form Validation Class Initialized
INFO - 2018-02-17 15:58:38 --> Model Class Initialized
INFO - 2018-02-17 15:58:38 --> Controller Class Initialized
INFO - 2018-02-17 15:58:38 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-17 15:58:38 --> Model Class Initialized
INFO - 2018-02-17 15:58:38 --> Model Class Initialized
INFO - 2018-02-17 15:58:38 --> Model Class Initialized
INFO - 2018-02-17 15:58:38 --> Model Class Initialized
INFO - 2018-02-17 15:58:44 --> Config Class Initialized
INFO - 2018-02-17 15:58:44 --> Hooks Class Initialized
DEBUG - 2018-02-17 15:58:44 --> UTF-8 Support Enabled
INFO - 2018-02-17 15:58:44 --> Utf8 Class Initialized
INFO - 2018-02-17 15:58:44 --> URI Class Initialized
INFO - 2018-02-17 15:58:44 --> Router Class Initialized
INFO - 2018-02-17 15:58:44 --> Output Class Initialized
INFO - 2018-02-17 15:58:44 --> Security Class Initialized
DEBUG - 2018-02-17 15:58:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-17 15:58:44 --> Input Class Initialized
INFO - 2018-02-17 15:58:44 --> Language Class Initialized
INFO - 2018-02-17 15:58:44 --> Loader Class Initialized
INFO - 2018-02-17 15:58:44 --> Helper loaded: url_helper
INFO - 2018-02-17 15:58:44 --> Helper loaded: file_helper
INFO - 2018-02-17 15:58:44 --> Helper loaded: email_helper
INFO - 2018-02-17 15:58:44 --> Helper loaded: common_helper
INFO - 2018-02-17 15:58:44 --> Database Driver Class Initialized
DEBUG - 2018-02-17 15:58:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-17 15:58:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-17 15:58:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-17 15:58:44 --> Pagination Class Initialized
INFO - 2018-02-17 15:58:44 --> Helper loaded: form_helper
INFO - 2018-02-17 15:58:44 --> Form Validation Class Initialized
INFO - 2018-02-17 15:58:44 --> Model Class Initialized
INFO - 2018-02-17 15:58:44 --> Controller Class Initialized
INFO - 2018-02-17 15:58:44 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-17 15:58:44 --> Model Class Initialized
INFO - 2018-02-17 15:58:44 --> Model Class Initialized
INFO - 2018-02-17 15:58:44 --> Model Class Initialized
INFO - 2018-02-17 15:58:44 --> Model Class Initialized
INFO - 2018-02-17 15:58:46 --> Config Class Initialized
INFO - 2018-02-17 15:58:46 --> Hooks Class Initialized
DEBUG - 2018-02-17 15:58:46 --> UTF-8 Support Enabled
INFO - 2018-02-17 15:58:46 --> Utf8 Class Initialized
INFO - 2018-02-17 15:58:46 --> URI Class Initialized
INFO - 2018-02-17 15:58:46 --> Router Class Initialized
INFO - 2018-02-17 15:58:46 --> Output Class Initialized
INFO - 2018-02-17 15:58:46 --> Security Class Initialized
DEBUG - 2018-02-17 15:58:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-17 15:58:46 --> Input Class Initialized
INFO - 2018-02-17 15:58:46 --> Language Class Initialized
INFO - 2018-02-17 15:58:46 --> Loader Class Initialized
INFO - 2018-02-17 15:58:46 --> Helper loaded: url_helper
INFO - 2018-02-17 15:58:46 --> Helper loaded: file_helper
INFO - 2018-02-17 15:58:46 --> Helper loaded: email_helper
INFO - 2018-02-17 15:58:46 --> Helper loaded: common_helper
INFO - 2018-02-17 15:58:46 --> Database Driver Class Initialized
DEBUG - 2018-02-17 15:58:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-17 15:58:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-17 15:58:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-17 15:58:46 --> Pagination Class Initialized
INFO - 2018-02-17 15:58:46 --> Helper loaded: form_helper
INFO - 2018-02-17 15:58:46 --> Form Validation Class Initialized
INFO - 2018-02-17 15:58:46 --> Model Class Initialized
INFO - 2018-02-17 15:58:46 --> Controller Class Initialized
INFO - 2018-02-17 15:58:46 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-17 15:58:46 --> Model Class Initialized
INFO - 2018-02-17 15:58:46 --> Model Class Initialized
INFO - 2018-02-17 15:58:46 --> Model Class Initialized
INFO - 2018-02-17 15:58:46 --> Model Class Initialized
INFO - 2018-02-17 15:58:46 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-17 15:58:46 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-17 15:58:46 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-17 15:58:46 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-17 15:58:46 --> File loaded: /var/www/html/project/radio/application/views/tracks/add_edit.php
INFO - 2018-02-17 15:58:46 --> Final output sent to browser
DEBUG - 2018-02-17 15:58:46 --> Total execution time: 0.0115
INFO - 2018-02-17 15:59:47 --> Config Class Initialized
INFO - 2018-02-17 15:59:47 --> Hooks Class Initialized
DEBUG - 2018-02-17 15:59:47 --> UTF-8 Support Enabled
INFO - 2018-02-17 15:59:47 --> Utf8 Class Initialized
INFO - 2018-02-17 15:59:47 --> URI Class Initialized
INFO - 2018-02-17 15:59:47 --> Router Class Initialized
INFO - 2018-02-17 15:59:47 --> Output Class Initialized
INFO - 2018-02-17 15:59:47 --> Security Class Initialized
DEBUG - 2018-02-17 15:59:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-17 15:59:47 --> Input Class Initialized
INFO - 2018-02-17 15:59:47 --> Language Class Initialized
INFO - 2018-02-17 15:59:47 --> Loader Class Initialized
INFO - 2018-02-17 15:59:47 --> Helper loaded: url_helper
INFO - 2018-02-17 15:59:47 --> Helper loaded: file_helper
INFO - 2018-02-17 15:59:47 --> Helper loaded: email_helper
INFO - 2018-02-17 15:59:47 --> Helper loaded: common_helper
INFO - 2018-02-17 15:59:47 --> Database Driver Class Initialized
DEBUG - 2018-02-17 15:59:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-17 15:59:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-17 15:59:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-17 15:59:47 --> Pagination Class Initialized
INFO - 2018-02-17 15:59:47 --> Helper loaded: form_helper
INFO - 2018-02-17 15:59:47 --> Form Validation Class Initialized
INFO - 2018-02-17 15:59:47 --> Model Class Initialized
INFO - 2018-02-17 15:59:47 --> Controller Class Initialized
INFO - 2018-02-17 15:59:47 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-17 15:59:47 --> Model Class Initialized
INFO - 2018-02-17 15:59:47 --> Model Class Initialized
INFO - 2018-02-17 15:59:47 --> Model Class Initialized
INFO - 2018-02-17 15:59:47 --> Model Class Initialized
INFO - 2018-02-17 15:59:47 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-17 15:59:47 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-17 15:59:47 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-17 15:59:47 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-17 15:59:47 --> File loaded: /var/www/html/project/radio/application/views/tracks/add_edit.php
INFO - 2018-02-17 15:59:47 --> Final output sent to browser
DEBUG - 2018-02-17 15:59:47 --> Total execution time: 0.0101
INFO - 2018-02-17 16:01:58 --> Config Class Initialized
INFO - 2018-02-17 16:01:58 --> Hooks Class Initialized
DEBUG - 2018-02-17 16:01:58 --> UTF-8 Support Enabled
INFO - 2018-02-17 16:01:58 --> Utf8 Class Initialized
INFO - 2018-02-17 16:01:58 --> URI Class Initialized
INFO - 2018-02-17 16:01:58 --> Router Class Initialized
INFO - 2018-02-17 16:01:58 --> Output Class Initialized
INFO - 2018-02-17 16:01:58 --> Security Class Initialized
DEBUG - 2018-02-17 16:01:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-17 16:01:58 --> Input Class Initialized
INFO - 2018-02-17 16:01:58 --> Language Class Initialized
INFO - 2018-02-17 16:01:58 --> Loader Class Initialized
INFO - 2018-02-17 16:01:58 --> Helper loaded: url_helper
INFO - 2018-02-17 16:01:58 --> Helper loaded: file_helper
INFO - 2018-02-17 16:01:58 --> Helper loaded: email_helper
INFO - 2018-02-17 16:01:58 --> Helper loaded: common_helper
INFO - 2018-02-17 16:01:58 --> Database Driver Class Initialized
DEBUG - 2018-02-17 16:01:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-17 16:01:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-17 16:01:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-17 16:01:58 --> Pagination Class Initialized
INFO - 2018-02-17 16:01:58 --> Helper loaded: form_helper
INFO - 2018-02-17 16:01:58 --> Form Validation Class Initialized
INFO - 2018-02-17 16:01:58 --> Model Class Initialized
INFO - 2018-02-17 16:01:58 --> Controller Class Initialized
INFO - 2018-02-17 16:01:58 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-17 16:01:58 --> Model Class Initialized
INFO - 2018-02-17 16:01:58 --> Model Class Initialized
INFO - 2018-02-17 16:01:58 --> Model Class Initialized
INFO - 2018-02-17 16:01:58 --> Model Class Initialized
INFO - 2018-02-17 16:01:58 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-17 16:01:58 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-17 16:01:58 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-17 16:01:58 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-17 16:01:58 --> File loaded: /var/www/html/project/radio/application/views/tracks/add_edit.php
INFO - 2018-02-17 16:01:58 --> Final output sent to browser
DEBUG - 2018-02-17 16:01:58 --> Total execution time: 0.0096
INFO - 2018-02-17 16:02:02 --> Config Class Initialized
INFO - 2018-02-17 16:02:02 --> Hooks Class Initialized
DEBUG - 2018-02-17 16:02:02 --> UTF-8 Support Enabled
INFO - 2018-02-17 16:02:02 --> Utf8 Class Initialized
INFO - 2018-02-17 16:02:02 --> URI Class Initialized
INFO - 2018-02-17 16:02:02 --> Router Class Initialized
INFO - 2018-02-17 16:02:02 --> Output Class Initialized
INFO - 2018-02-17 16:02:02 --> Security Class Initialized
DEBUG - 2018-02-17 16:02:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-17 16:02:02 --> Input Class Initialized
INFO - 2018-02-17 16:02:02 --> Language Class Initialized
INFO - 2018-02-17 16:02:02 --> Loader Class Initialized
INFO - 2018-02-17 16:02:02 --> Helper loaded: url_helper
INFO - 2018-02-17 16:02:02 --> Helper loaded: file_helper
INFO - 2018-02-17 16:02:02 --> Helper loaded: email_helper
INFO - 2018-02-17 16:02:02 --> Helper loaded: common_helper
INFO - 2018-02-17 16:02:02 --> Database Driver Class Initialized
DEBUG - 2018-02-17 16:02:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-17 16:02:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-17 16:02:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-17 16:02:02 --> Pagination Class Initialized
INFO - 2018-02-17 16:02:02 --> Helper loaded: form_helper
INFO - 2018-02-17 16:02:02 --> Form Validation Class Initialized
INFO - 2018-02-17 16:02:02 --> Model Class Initialized
INFO - 2018-02-17 16:02:02 --> Controller Class Initialized
INFO - 2018-02-17 16:02:02 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-17 16:02:02 --> Model Class Initialized
INFO - 2018-02-17 16:02:02 --> Model Class Initialized
INFO - 2018-02-17 16:02:02 --> Model Class Initialized
INFO - 2018-02-17 16:02:02 --> Model Class Initialized
INFO - 2018-02-17 16:02:06 --> Config Class Initialized
INFO - 2018-02-17 16:02:06 --> Hooks Class Initialized
DEBUG - 2018-02-17 16:02:06 --> UTF-8 Support Enabled
INFO - 2018-02-17 16:02:06 --> Utf8 Class Initialized
INFO - 2018-02-17 16:02:06 --> URI Class Initialized
INFO - 2018-02-17 16:02:06 --> Router Class Initialized
INFO - 2018-02-17 16:02:06 --> Output Class Initialized
INFO - 2018-02-17 16:02:06 --> Security Class Initialized
DEBUG - 2018-02-17 16:02:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-17 16:02:06 --> Input Class Initialized
INFO - 2018-02-17 16:02:06 --> Language Class Initialized
INFO - 2018-02-17 16:02:06 --> Loader Class Initialized
INFO - 2018-02-17 16:02:06 --> Helper loaded: url_helper
INFO - 2018-02-17 16:02:06 --> Helper loaded: file_helper
INFO - 2018-02-17 16:02:06 --> Helper loaded: email_helper
INFO - 2018-02-17 16:02:06 --> Helper loaded: common_helper
INFO - 2018-02-17 16:02:06 --> Database Driver Class Initialized
DEBUG - 2018-02-17 16:02:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-17 16:02:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-17 16:02:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-17 16:02:06 --> Pagination Class Initialized
INFO - 2018-02-17 16:02:06 --> Helper loaded: form_helper
INFO - 2018-02-17 16:02:06 --> Form Validation Class Initialized
INFO - 2018-02-17 16:02:06 --> Model Class Initialized
INFO - 2018-02-17 16:02:06 --> Controller Class Initialized
INFO - 2018-02-17 16:02:06 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-17 16:02:06 --> Model Class Initialized
INFO - 2018-02-17 16:02:06 --> Model Class Initialized
INFO - 2018-02-17 16:02:06 --> Model Class Initialized
INFO - 2018-02-17 16:02:06 --> Model Class Initialized
INFO - 2018-02-17 16:02:08 --> Config Class Initialized
INFO - 2018-02-17 16:02:08 --> Hooks Class Initialized
DEBUG - 2018-02-17 16:02:08 --> UTF-8 Support Enabled
INFO - 2018-02-17 16:02:08 --> Utf8 Class Initialized
INFO - 2018-02-17 16:02:08 --> URI Class Initialized
INFO - 2018-02-17 16:02:08 --> Router Class Initialized
INFO - 2018-02-17 16:02:08 --> Output Class Initialized
INFO - 2018-02-17 16:02:08 --> Security Class Initialized
DEBUG - 2018-02-17 16:02:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-17 16:02:08 --> Input Class Initialized
INFO - 2018-02-17 16:02:08 --> Language Class Initialized
INFO - 2018-02-17 16:02:08 --> Loader Class Initialized
INFO - 2018-02-17 16:02:08 --> Helper loaded: url_helper
INFO - 2018-02-17 16:02:08 --> Helper loaded: file_helper
INFO - 2018-02-17 16:02:08 --> Helper loaded: email_helper
INFO - 2018-02-17 16:02:08 --> Helper loaded: common_helper
INFO - 2018-02-17 16:02:08 --> Database Driver Class Initialized
DEBUG - 2018-02-17 16:02:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-17 16:02:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-17 16:02:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-17 16:02:08 --> Pagination Class Initialized
INFO - 2018-02-17 16:02:08 --> Helper loaded: form_helper
INFO - 2018-02-17 16:02:08 --> Form Validation Class Initialized
INFO - 2018-02-17 16:02:08 --> Model Class Initialized
INFO - 2018-02-17 16:02:08 --> Controller Class Initialized
INFO - 2018-02-17 16:02:08 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-17 16:02:08 --> Model Class Initialized
INFO - 2018-02-17 16:02:08 --> Model Class Initialized
INFO - 2018-02-17 16:02:08 --> Model Class Initialized
INFO - 2018-02-17 16:02:08 --> Model Class Initialized
INFO - 2018-02-17 16:02:08 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-17 16:02:08 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-17 16:02:08 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-17 16:02:08 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-17 16:02:08 --> File loaded: /var/www/html/project/radio/application/views/tracks/add_edit.php
INFO - 2018-02-17 16:02:08 --> Final output sent to browser
DEBUG - 2018-02-17 16:02:08 --> Total execution time: 0.0098
INFO - 2018-02-17 16:02:13 --> Config Class Initialized
INFO - 2018-02-17 16:02:13 --> Hooks Class Initialized
DEBUG - 2018-02-17 16:02:13 --> UTF-8 Support Enabled
INFO - 2018-02-17 16:02:13 --> Utf8 Class Initialized
INFO - 2018-02-17 16:02:13 --> URI Class Initialized
INFO - 2018-02-17 16:02:13 --> Router Class Initialized
INFO - 2018-02-17 16:02:13 --> Output Class Initialized
INFO - 2018-02-17 16:02:13 --> Security Class Initialized
DEBUG - 2018-02-17 16:02:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-17 16:02:13 --> Input Class Initialized
INFO - 2018-02-17 16:02:13 --> Language Class Initialized
INFO - 2018-02-17 16:02:13 --> Loader Class Initialized
INFO - 2018-02-17 16:02:13 --> Helper loaded: url_helper
INFO - 2018-02-17 16:02:13 --> Helper loaded: file_helper
INFO - 2018-02-17 16:02:13 --> Helper loaded: email_helper
INFO - 2018-02-17 16:02:13 --> Helper loaded: common_helper
INFO - 2018-02-17 16:02:13 --> Database Driver Class Initialized
DEBUG - 2018-02-17 16:02:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-17 16:02:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-17 16:02:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-17 16:02:13 --> Pagination Class Initialized
INFO - 2018-02-17 16:02:13 --> Helper loaded: form_helper
INFO - 2018-02-17 16:02:13 --> Form Validation Class Initialized
INFO - 2018-02-17 16:02:13 --> Model Class Initialized
INFO - 2018-02-17 16:02:13 --> Controller Class Initialized
INFO - 2018-02-17 16:02:13 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-17 16:02:13 --> Model Class Initialized
INFO - 2018-02-17 16:02:13 --> Model Class Initialized
INFO - 2018-02-17 16:02:13 --> Model Class Initialized
INFO - 2018-02-17 16:02:13 --> Model Class Initialized
INFO - 2018-02-17 16:02:29 --> Config Class Initialized
INFO - 2018-02-17 16:02:29 --> Hooks Class Initialized
DEBUG - 2018-02-17 16:02:29 --> UTF-8 Support Enabled
INFO - 2018-02-17 16:02:29 --> Utf8 Class Initialized
INFO - 2018-02-17 16:02:29 --> URI Class Initialized
INFO - 2018-02-17 16:02:29 --> Router Class Initialized
INFO - 2018-02-17 16:02:29 --> Output Class Initialized
INFO - 2018-02-17 16:02:29 --> Security Class Initialized
DEBUG - 2018-02-17 16:02:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-17 16:02:29 --> Input Class Initialized
INFO - 2018-02-17 16:02:29 --> Language Class Initialized
INFO - 2018-02-17 16:02:29 --> Loader Class Initialized
INFO - 2018-02-17 16:02:29 --> Helper loaded: url_helper
INFO - 2018-02-17 16:02:29 --> Helper loaded: file_helper
INFO - 2018-02-17 16:02:29 --> Helper loaded: email_helper
INFO - 2018-02-17 16:02:29 --> Helper loaded: common_helper
INFO - 2018-02-17 16:02:29 --> Database Driver Class Initialized
DEBUG - 2018-02-17 16:02:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-17 16:02:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-17 16:02:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-17 16:02:29 --> Pagination Class Initialized
INFO - 2018-02-17 16:02:29 --> Helper loaded: form_helper
INFO - 2018-02-17 16:02:29 --> Form Validation Class Initialized
INFO - 2018-02-17 16:02:29 --> Model Class Initialized
INFO - 2018-02-17 16:02:29 --> Controller Class Initialized
INFO - 2018-02-17 16:02:29 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-17 16:02:29 --> Model Class Initialized
INFO - 2018-02-17 16:02:29 --> Model Class Initialized
INFO - 2018-02-17 16:02:29 --> Model Class Initialized
INFO - 2018-02-17 16:02:29 --> Model Class Initialized
INFO - 2018-02-17 16:02:31 --> Config Class Initialized
INFO - 2018-02-17 16:02:31 --> Hooks Class Initialized
DEBUG - 2018-02-17 16:02:31 --> UTF-8 Support Enabled
INFO - 2018-02-17 16:02:31 --> Utf8 Class Initialized
INFO - 2018-02-17 16:02:31 --> URI Class Initialized
INFO - 2018-02-17 16:02:31 --> Router Class Initialized
INFO - 2018-02-17 16:02:31 --> Output Class Initialized
INFO - 2018-02-17 16:02:31 --> Security Class Initialized
DEBUG - 2018-02-17 16:02:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-17 16:02:31 --> Input Class Initialized
INFO - 2018-02-17 16:02:31 --> Language Class Initialized
INFO - 2018-02-17 16:02:31 --> Loader Class Initialized
INFO - 2018-02-17 16:02:31 --> Helper loaded: url_helper
INFO - 2018-02-17 16:02:31 --> Helper loaded: file_helper
INFO - 2018-02-17 16:02:31 --> Helper loaded: email_helper
INFO - 2018-02-17 16:02:31 --> Helper loaded: common_helper
INFO - 2018-02-17 16:02:31 --> Database Driver Class Initialized
DEBUG - 2018-02-17 16:02:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-17 16:02:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-17 16:02:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-17 16:02:31 --> Pagination Class Initialized
INFO - 2018-02-17 16:02:31 --> Helper loaded: form_helper
INFO - 2018-02-17 16:02:31 --> Form Validation Class Initialized
INFO - 2018-02-17 16:02:31 --> Model Class Initialized
INFO - 2018-02-17 16:02:31 --> Controller Class Initialized
INFO - 2018-02-17 16:02:31 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-17 16:02:31 --> Model Class Initialized
INFO - 2018-02-17 16:02:31 --> Model Class Initialized
INFO - 2018-02-17 16:02:31 --> Model Class Initialized
INFO - 2018-02-17 16:02:31 --> Model Class Initialized
INFO - 2018-02-17 16:02:31 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-17 16:02:31 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-17 16:02:31 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-17 16:02:31 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-17 16:02:31 --> File loaded: /var/www/html/project/radio/application/views/tracks/add_edit.php
INFO - 2018-02-17 16:02:31 --> Final output sent to browser
DEBUG - 2018-02-17 16:02:31 --> Total execution time: 0.0098
INFO - 2018-02-17 16:02:34 --> Config Class Initialized
INFO - 2018-02-17 16:02:34 --> Hooks Class Initialized
DEBUG - 2018-02-17 16:02:34 --> UTF-8 Support Enabled
INFO - 2018-02-17 16:02:34 --> Utf8 Class Initialized
INFO - 2018-02-17 16:02:34 --> URI Class Initialized
INFO - 2018-02-17 16:02:34 --> Router Class Initialized
INFO - 2018-02-17 16:02:34 --> Output Class Initialized
INFO - 2018-02-17 16:02:34 --> Security Class Initialized
DEBUG - 2018-02-17 16:02:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-17 16:02:34 --> Input Class Initialized
INFO - 2018-02-17 16:02:34 --> Language Class Initialized
INFO - 2018-02-17 16:02:34 --> Loader Class Initialized
INFO - 2018-02-17 16:02:34 --> Helper loaded: url_helper
INFO - 2018-02-17 16:02:34 --> Helper loaded: file_helper
INFO - 2018-02-17 16:02:34 --> Helper loaded: email_helper
INFO - 2018-02-17 16:02:34 --> Helper loaded: common_helper
INFO - 2018-02-17 16:02:34 --> Database Driver Class Initialized
DEBUG - 2018-02-17 16:02:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-17 16:02:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-17 16:02:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-17 16:02:34 --> Pagination Class Initialized
INFO - 2018-02-17 16:02:34 --> Helper loaded: form_helper
INFO - 2018-02-17 16:02:34 --> Form Validation Class Initialized
INFO - 2018-02-17 16:02:34 --> Model Class Initialized
INFO - 2018-02-17 16:02:34 --> Controller Class Initialized
INFO - 2018-02-17 16:02:34 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-17 16:02:34 --> Model Class Initialized
INFO - 2018-02-17 16:02:34 --> Model Class Initialized
INFO - 2018-02-17 16:02:34 --> Model Class Initialized
INFO - 2018-02-17 16:02:34 --> Model Class Initialized
INFO - 2018-02-17 16:02:43 --> Config Class Initialized
INFO - 2018-02-17 16:02:43 --> Hooks Class Initialized
DEBUG - 2018-02-17 16:02:43 --> UTF-8 Support Enabled
INFO - 2018-02-17 16:02:43 --> Utf8 Class Initialized
INFO - 2018-02-17 16:02:43 --> URI Class Initialized
INFO - 2018-02-17 16:02:43 --> Router Class Initialized
INFO - 2018-02-17 16:02:43 --> Output Class Initialized
INFO - 2018-02-17 16:02:43 --> Security Class Initialized
DEBUG - 2018-02-17 16:02:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-17 16:02:43 --> Input Class Initialized
INFO - 2018-02-17 16:02:43 --> Language Class Initialized
INFO - 2018-02-17 16:02:43 --> Loader Class Initialized
INFO - 2018-02-17 16:02:43 --> Helper loaded: url_helper
INFO - 2018-02-17 16:02:43 --> Helper loaded: file_helper
INFO - 2018-02-17 16:02:43 --> Helper loaded: email_helper
INFO - 2018-02-17 16:02:43 --> Helper loaded: common_helper
INFO - 2018-02-17 16:02:43 --> Database Driver Class Initialized
DEBUG - 2018-02-17 16:02:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-17 16:02:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-17 16:02:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-17 16:02:43 --> Pagination Class Initialized
INFO - 2018-02-17 16:02:43 --> Helper loaded: form_helper
INFO - 2018-02-17 16:02:43 --> Form Validation Class Initialized
INFO - 2018-02-17 16:02:43 --> Model Class Initialized
INFO - 2018-02-17 16:02:43 --> Controller Class Initialized
INFO - 2018-02-17 16:02:43 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-17 16:02:43 --> Model Class Initialized
INFO - 2018-02-17 16:02:43 --> Model Class Initialized
INFO - 2018-02-17 16:02:43 --> Model Class Initialized
INFO - 2018-02-17 16:02:43 --> Model Class Initialized
INFO - 2018-02-17 16:02:46 --> Config Class Initialized
INFO - 2018-02-17 16:02:46 --> Hooks Class Initialized
DEBUG - 2018-02-17 16:02:46 --> UTF-8 Support Enabled
INFO - 2018-02-17 16:02:46 --> Utf8 Class Initialized
INFO - 2018-02-17 16:02:46 --> URI Class Initialized
INFO - 2018-02-17 16:02:46 --> Router Class Initialized
INFO - 2018-02-17 16:02:46 --> Output Class Initialized
INFO - 2018-02-17 16:02:46 --> Security Class Initialized
DEBUG - 2018-02-17 16:02:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-17 16:02:46 --> Input Class Initialized
INFO - 2018-02-17 16:02:46 --> Language Class Initialized
INFO - 2018-02-17 16:02:46 --> Loader Class Initialized
INFO - 2018-02-17 16:02:46 --> Helper loaded: url_helper
INFO - 2018-02-17 16:02:46 --> Helper loaded: file_helper
INFO - 2018-02-17 16:02:46 --> Helper loaded: email_helper
INFO - 2018-02-17 16:02:46 --> Helper loaded: common_helper
INFO - 2018-02-17 16:02:46 --> Database Driver Class Initialized
DEBUG - 2018-02-17 16:02:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-17 16:02:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-17 16:02:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-17 16:02:46 --> Pagination Class Initialized
INFO - 2018-02-17 16:02:46 --> Helper loaded: form_helper
INFO - 2018-02-17 16:02:46 --> Form Validation Class Initialized
INFO - 2018-02-17 16:02:46 --> Model Class Initialized
INFO - 2018-02-17 16:02:46 --> Controller Class Initialized
INFO - 2018-02-17 16:02:46 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-17 16:02:46 --> Model Class Initialized
INFO - 2018-02-17 16:02:46 --> Model Class Initialized
INFO - 2018-02-17 16:02:46 --> Model Class Initialized
INFO - 2018-02-17 16:02:46 --> Model Class Initialized
INFO - 2018-02-17 16:02:46 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-17 16:02:46 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-17 16:02:46 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-17 16:02:46 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-17 16:02:46 --> File loaded: /var/www/html/project/radio/application/views/tracks/add_edit.php
INFO - 2018-02-17 16:02:46 --> Final output sent to browser
DEBUG - 2018-02-17 16:02:46 --> Total execution time: 0.0106
INFO - 2018-02-17 16:04:03 --> Config Class Initialized
INFO - 2018-02-17 16:04:03 --> Hooks Class Initialized
DEBUG - 2018-02-17 16:04:03 --> UTF-8 Support Enabled
INFO - 2018-02-17 16:04:03 --> Utf8 Class Initialized
INFO - 2018-02-17 16:04:03 --> URI Class Initialized
INFO - 2018-02-17 16:04:03 --> Router Class Initialized
INFO - 2018-02-17 16:04:03 --> Output Class Initialized
INFO - 2018-02-17 16:04:03 --> Security Class Initialized
DEBUG - 2018-02-17 16:04:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-17 16:04:03 --> Input Class Initialized
INFO - 2018-02-17 16:04:03 --> Language Class Initialized
INFO - 2018-02-17 16:04:03 --> Loader Class Initialized
INFO - 2018-02-17 16:04:03 --> Helper loaded: url_helper
INFO - 2018-02-17 16:04:03 --> Helper loaded: file_helper
INFO - 2018-02-17 16:04:03 --> Helper loaded: email_helper
INFO - 2018-02-17 16:04:03 --> Helper loaded: common_helper
INFO - 2018-02-17 16:04:03 --> Database Driver Class Initialized
DEBUG - 2018-02-17 16:04:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-17 16:04:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-17 16:04:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-17 16:04:03 --> Pagination Class Initialized
INFO - 2018-02-17 16:04:03 --> Helper loaded: form_helper
INFO - 2018-02-17 16:04:03 --> Form Validation Class Initialized
INFO - 2018-02-17 16:04:03 --> Model Class Initialized
INFO - 2018-02-17 16:04:03 --> Controller Class Initialized
INFO - 2018-02-17 16:04:03 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-17 16:04:03 --> Model Class Initialized
INFO - 2018-02-17 16:04:03 --> Model Class Initialized
INFO - 2018-02-17 16:04:03 --> Model Class Initialized
INFO - 2018-02-17 16:04:03 --> Model Class Initialized
INFO - 2018-02-17 16:04:03 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-17 16:04:03 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-17 16:04:03 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-17 16:04:03 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-17 16:04:03 --> File loaded: /var/www/html/project/radio/application/views/tracks/add_edit.php
INFO - 2018-02-17 16:04:03 --> Final output sent to browser
DEBUG - 2018-02-17 16:04:03 --> Total execution time: 0.0095
INFO - 2018-02-17 16:04:08 --> Config Class Initialized
INFO - 2018-02-17 16:04:08 --> Hooks Class Initialized
DEBUG - 2018-02-17 16:04:08 --> UTF-8 Support Enabled
INFO - 2018-02-17 16:04:08 --> Utf8 Class Initialized
INFO - 2018-02-17 16:04:08 --> URI Class Initialized
INFO - 2018-02-17 16:04:08 --> Router Class Initialized
INFO - 2018-02-17 16:04:08 --> Output Class Initialized
INFO - 2018-02-17 16:04:08 --> Security Class Initialized
DEBUG - 2018-02-17 16:04:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-17 16:04:08 --> Input Class Initialized
INFO - 2018-02-17 16:04:08 --> Language Class Initialized
INFO - 2018-02-17 16:04:08 --> Loader Class Initialized
INFO - 2018-02-17 16:04:08 --> Helper loaded: url_helper
INFO - 2018-02-17 16:04:08 --> Helper loaded: file_helper
INFO - 2018-02-17 16:04:08 --> Helper loaded: email_helper
INFO - 2018-02-17 16:04:08 --> Helper loaded: common_helper
INFO - 2018-02-17 16:04:08 --> Database Driver Class Initialized
DEBUG - 2018-02-17 16:04:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-17 16:04:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-17 16:04:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-17 16:04:08 --> Pagination Class Initialized
INFO - 2018-02-17 16:04:08 --> Helper loaded: form_helper
INFO - 2018-02-17 16:04:08 --> Form Validation Class Initialized
INFO - 2018-02-17 16:04:08 --> Model Class Initialized
INFO - 2018-02-17 16:04:08 --> Controller Class Initialized
INFO - 2018-02-17 16:04:08 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-17 16:04:08 --> Model Class Initialized
INFO - 2018-02-17 16:04:08 --> Model Class Initialized
INFO - 2018-02-17 16:04:08 --> Model Class Initialized
INFO - 2018-02-17 16:04:08 --> Model Class Initialized
INFO - 2018-02-17 16:04:31 --> Config Class Initialized
INFO - 2018-02-17 16:04:31 --> Hooks Class Initialized
DEBUG - 2018-02-17 16:04:31 --> UTF-8 Support Enabled
INFO - 2018-02-17 16:04:31 --> Utf8 Class Initialized
INFO - 2018-02-17 16:04:31 --> URI Class Initialized
INFO - 2018-02-17 16:04:31 --> Router Class Initialized
INFO - 2018-02-17 16:04:31 --> Output Class Initialized
INFO - 2018-02-17 16:04:31 --> Security Class Initialized
DEBUG - 2018-02-17 16:04:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-17 16:04:31 --> Input Class Initialized
INFO - 2018-02-17 16:04:31 --> Language Class Initialized
INFO - 2018-02-17 16:04:31 --> Loader Class Initialized
INFO - 2018-02-17 16:04:31 --> Helper loaded: url_helper
INFO - 2018-02-17 16:04:31 --> Helper loaded: file_helper
INFO - 2018-02-17 16:04:31 --> Helper loaded: email_helper
INFO - 2018-02-17 16:04:31 --> Helper loaded: common_helper
INFO - 2018-02-17 16:04:31 --> Database Driver Class Initialized
DEBUG - 2018-02-17 16:04:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-17 16:04:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-17 16:04:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-17 16:04:31 --> Pagination Class Initialized
INFO - 2018-02-17 16:04:31 --> Helper loaded: form_helper
INFO - 2018-02-17 16:04:31 --> Form Validation Class Initialized
INFO - 2018-02-17 16:04:31 --> Model Class Initialized
INFO - 2018-02-17 16:04:31 --> Controller Class Initialized
INFO - 2018-02-17 16:04:31 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-17 16:04:31 --> Model Class Initialized
INFO - 2018-02-17 16:04:31 --> Model Class Initialized
INFO - 2018-02-17 16:04:31 --> Model Class Initialized
INFO - 2018-02-17 16:04:31 --> Model Class Initialized
INFO - 2018-02-17 16:04:31 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-17 16:04:31 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-17 16:04:31 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-17 16:04:31 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-17 16:04:31 --> File loaded: /var/www/html/project/radio/application/views/tracks/add_edit.php
INFO - 2018-02-17 16:04:31 --> Final output sent to browser
DEBUG - 2018-02-17 16:04:31 --> Total execution time: 0.0107
INFO - 2018-02-17 16:13:32 --> Config Class Initialized
INFO - 2018-02-17 16:13:32 --> Hooks Class Initialized
DEBUG - 2018-02-17 16:13:32 --> UTF-8 Support Enabled
INFO - 2018-02-17 16:13:32 --> Utf8 Class Initialized
INFO - 2018-02-17 16:13:32 --> URI Class Initialized
INFO - 2018-02-17 16:13:32 --> Router Class Initialized
INFO - 2018-02-17 16:13:32 --> Output Class Initialized
INFO - 2018-02-17 16:13:32 --> Security Class Initialized
DEBUG - 2018-02-17 16:13:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-17 16:13:32 --> Input Class Initialized
INFO - 2018-02-17 16:13:32 --> Language Class Initialized
INFO - 2018-02-17 16:13:32 --> Loader Class Initialized
INFO - 2018-02-17 16:13:32 --> Helper loaded: url_helper
INFO - 2018-02-17 16:13:32 --> Helper loaded: file_helper
INFO - 2018-02-17 16:13:32 --> Helper loaded: email_helper
INFO - 2018-02-17 16:13:32 --> Helper loaded: common_helper
INFO - 2018-02-17 16:13:32 --> Database Driver Class Initialized
DEBUG - 2018-02-17 16:13:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-17 16:13:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-17 16:13:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-17 16:13:32 --> Pagination Class Initialized
INFO - 2018-02-17 16:13:32 --> Helper loaded: form_helper
INFO - 2018-02-17 16:13:32 --> Form Validation Class Initialized
INFO - 2018-02-17 16:13:32 --> Model Class Initialized
INFO - 2018-02-17 16:13:32 --> Controller Class Initialized
INFO - 2018-02-17 16:13:32 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-17 16:13:32 --> Model Class Initialized
INFO - 2018-02-17 16:13:32 --> Model Class Initialized
INFO - 2018-02-17 16:13:32 --> Model Class Initialized
INFO - 2018-02-17 16:13:32 --> Model Class Initialized
INFO - 2018-02-17 16:13:32 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-17 16:13:32 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-17 16:13:32 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-17 16:13:32 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-17 16:13:32 --> File loaded: /var/www/html/project/radio/application/views/tracks/add_edit.php
INFO - 2018-02-17 16:13:32 --> Final output sent to browser
DEBUG - 2018-02-17 16:13:32 --> Total execution time: 0.0107
INFO - 2018-02-17 16:13:37 --> Config Class Initialized
INFO - 2018-02-17 16:13:37 --> Hooks Class Initialized
DEBUG - 2018-02-17 16:13:37 --> UTF-8 Support Enabled
INFO - 2018-02-17 16:13:37 --> Utf8 Class Initialized
INFO - 2018-02-17 16:13:37 --> URI Class Initialized
INFO - 2018-02-17 16:13:37 --> Router Class Initialized
INFO - 2018-02-17 16:13:37 --> Output Class Initialized
INFO - 2018-02-17 16:13:37 --> Security Class Initialized
DEBUG - 2018-02-17 16:13:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-17 16:13:37 --> Input Class Initialized
INFO - 2018-02-17 16:13:37 --> Language Class Initialized
INFO - 2018-02-17 16:13:37 --> Loader Class Initialized
INFO - 2018-02-17 16:13:37 --> Helper loaded: url_helper
INFO - 2018-02-17 16:13:37 --> Helper loaded: file_helper
INFO - 2018-02-17 16:13:37 --> Helper loaded: email_helper
INFO - 2018-02-17 16:13:37 --> Helper loaded: common_helper
INFO - 2018-02-17 16:13:37 --> Database Driver Class Initialized
DEBUG - 2018-02-17 16:13:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-17 16:13:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-17 16:13:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-17 16:13:37 --> Pagination Class Initialized
INFO - 2018-02-17 16:13:37 --> Helper loaded: form_helper
INFO - 2018-02-17 16:13:37 --> Form Validation Class Initialized
INFO - 2018-02-17 16:13:37 --> Model Class Initialized
INFO - 2018-02-17 16:13:37 --> Controller Class Initialized
INFO - 2018-02-17 16:13:37 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-17 16:13:37 --> Model Class Initialized
INFO - 2018-02-17 16:13:37 --> Model Class Initialized
INFO - 2018-02-17 16:13:37 --> Model Class Initialized
INFO - 2018-02-17 16:13:37 --> Model Class Initialized
INFO - 2018-02-17 16:13:37 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-17 16:13:37 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-17 16:13:37 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-17 16:13:37 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-17 16:13:37 --> File loaded: /var/www/html/project/radio/application/views/tracks/add_edit.php
INFO - 2018-02-17 16:13:37 --> Final output sent to browser
DEBUG - 2018-02-17 16:13:37 --> Total execution time: 0.0116
INFO - 2018-02-17 16:13:42 --> Config Class Initialized
INFO - 2018-02-17 16:13:42 --> Hooks Class Initialized
DEBUG - 2018-02-17 16:13:42 --> UTF-8 Support Enabled
INFO - 2018-02-17 16:13:42 --> Utf8 Class Initialized
INFO - 2018-02-17 16:13:42 --> URI Class Initialized
INFO - 2018-02-17 16:13:42 --> Router Class Initialized
INFO - 2018-02-17 16:13:42 --> Output Class Initialized
INFO - 2018-02-17 16:13:42 --> Security Class Initialized
DEBUG - 2018-02-17 16:13:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-17 16:13:42 --> Input Class Initialized
INFO - 2018-02-17 16:13:42 --> Language Class Initialized
INFO - 2018-02-17 16:13:42 --> Loader Class Initialized
INFO - 2018-02-17 16:13:42 --> Helper loaded: url_helper
INFO - 2018-02-17 16:13:42 --> Helper loaded: file_helper
INFO - 2018-02-17 16:13:42 --> Helper loaded: email_helper
INFO - 2018-02-17 16:13:42 --> Helper loaded: common_helper
INFO - 2018-02-17 16:13:42 --> Database Driver Class Initialized
DEBUG - 2018-02-17 16:13:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-17 16:13:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-17 16:13:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-17 16:13:42 --> Pagination Class Initialized
INFO - 2018-02-17 16:13:42 --> Helper loaded: form_helper
INFO - 2018-02-17 16:13:42 --> Form Validation Class Initialized
INFO - 2018-02-17 16:13:42 --> Model Class Initialized
INFO - 2018-02-17 16:13:42 --> Controller Class Initialized
INFO - 2018-02-17 16:13:42 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-17 16:13:42 --> Model Class Initialized
INFO - 2018-02-17 16:13:42 --> Model Class Initialized
INFO - 2018-02-17 16:13:42 --> Model Class Initialized
INFO - 2018-02-17 16:13:42 --> Model Class Initialized
INFO - 2018-02-17 16:14:25 --> Config Class Initialized
INFO - 2018-02-17 16:14:25 --> Hooks Class Initialized
DEBUG - 2018-02-17 16:14:25 --> UTF-8 Support Enabled
INFO - 2018-02-17 16:14:25 --> Utf8 Class Initialized
INFO - 2018-02-17 16:14:25 --> URI Class Initialized
INFO - 2018-02-17 16:14:25 --> Router Class Initialized
INFO - 2018-02-17 16:14:25 --> Output Class Initialized
INFO - 2018-02-17 16:14:25 --> Security Class Initialized
DEBUG - 2018-02-17 16:14:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-17 16:14:25 --> Input Class Initialized
INFO - 2018-02-17 16:14:25 --> Language Class Initialized
INFO - 2018-02-17 16:14:25 --> Loader Class Initialized
INFO - 2018-02-17 16:14:25 --> Helper loaded: url_helper
INFO - 2018-02-17 16:14:25 --> Helper loaded: file_helper
INFO - 2018-02-17 16:14:25 --> Helper loaded: email_helper
INFO - 2018-02-17 16:14:25 --> Helper loaded: common_helper
INFO - 2018-02-17 16:14:25 --> Database Driver Class Initialized
DEBUG - 2018-02-17 16:14:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-17 16:14:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-17 16:14:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-17 16:14:25 --> Pagination Class Initialized
INFO - 2018-02-17 16:14:25 --> Helper loaded: form_helper
INFO - 2018-02-17 16:14:25 --> Form Validation Class Initialized
INFO - 2018-02-17 16:14:25 --> Model Class Initialized
INFO - 2018-02-17 16:14:25 --> Controller Class Initialized
INFO - 2018-02-17 16:14:25 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-17 16:14:25 --> Model Class Initialized
INFO - 2018-02-17 16:14:25 --> Model Class Initialized
INFO - 2018-02-17 16:14:25 --> Model Class Initialized
INFO - 2018-02-17 16:14:25 --> Model Class Initialized
INFO - 2018-02-17 16:14:25 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-17 16:14:25 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-17 16:14:25 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-17 16:14:25 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-17 16:14:25 --> File loaded: /var/www/html/project/radio/application/views/tracks/add_edit.php
INFO - 2018-02-17 16:14:25 --> Final output sent to browser
DEBUG - 2018-02-17 16:14:25 --> Total execution time: 0.0100
INFO - 2018-02-17 16:14:56 --> Config Class Initialized
INFO - 2018-02-17 16:14:56 --> Hooks Class Initialized
DEBUG - 2018-02-17 16:14:56 --> UTF-8 Support Enabled
INFO - 2018-02-17 16:14:56 --> Utf8 Class Initialized
INFO - 2018-02-17 16:14:56 --> URI Class Initialized
INFO - 2018-02-17 16:14:56 --> Router Class Initialized
INFO - 2018-02-17 16:14:56 --> Output Class Initialized
INFO - 2018-02-17 16:14:56 --> Security Class Initialized
DEBUG - 2018-02-17 16:14:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-17 16:14:56 --> Input Class Initialized
INFO - 2018-02-17 16:14:56 --> Language Class Initialized
INFO - 2018-02-17 16:14:56 --> Loader Class Initialized
INFO - 2018-02-17 16:14:56 --> Helper loaded: url_helper
INFO - 2018-02-17 16:14:56 --> Helper loaded: file_helper
INFO - 2018-02-17 16:14:56 --> Helper loaded: email_helper
INFO - 2018-02-17 16:14:56 --> Helper loaded: common_helper
INFO - 2018-02-17 16:14:56 --> Database Driver Class Initialized
DEBUG - 2018-02-17 16:14:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-17 16:14:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-17 16:14:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-17 16:14:56 --> Pagination Class Initialized
INFO - 2018-02-17 16:14:56 --> Helper loaded: form_helper
INFO - 2018-02-17 16:14:56 --> Form Validation Class Initialized
INFO - 2018-02-17 16:14:56 --> Model Class Initialized
INFO - 2018-02-17 16:14:56 --> Controller Class Initialized
INFO - 2018-02-17 16:14:56 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-17 16:14:56 --> Model Class Initialized
INFO - 2018-02-17 16:14:56 --> Model Class Initialized
INFO - 2018-02-17 16:14:56 --> Model Class Initialized
INFO - 2018-02-17 16:14:56 --> Model Class Initialized
INFO - 2018-02-17 16:14:56 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-17 16:14:56 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-17 16:14:56 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-17 16:14:56 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-17 16:14:56 --> File loaded: /var/www/html/project/radio/application/views/tracks/add_edit.php
INFO - 2018-02-17 16:14:56 --> Final output sent to browser
DEBUG - 2018-02-17 16:14:56 --> Total execution time: 0.0094
INFO - 2018-02-17 16:15:01 --> Config Class Initialized
INFO - 2018-02-17 16:15:01 --> Hooks Class Initialized
DEBUG - 2018-02-17 16:15:01 --> UTF-8 Support Enabled
INFO - 2018-02-17 16:15:01 --> Utf8 Class Initialized
INFO - 2018-02-17 16:15:01 --> URI Class Initialized
INFO - 2018-02-17 16:15:01 --> Router Class Initialized
INFO - 2018-02-17 16:15:01 --> Output Class Initialized
INFO - 2018-02-17 16:15:01 --> Security Class Initialized
DEBUG - 2018-02-17 16:15:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-17 16:15:01 --> Input Class Initialized
INFO - 2018-02-17 16:15:01 --> Language Class Initialized
INFO - 2018-02-17 16:15:01 --> Loader Class Initialized
INFO - 2018-02-17 16:15:01 --> Helper loaded: url_helper
INFO - 2018-02-17 16:15:01 --> Helper loaded: file_helper
INFO - 2018-02-17 16:15:01 --> Helper loaded: email_helper
INFO - 2018-02-17 16:15:01 --> Helper loaded: common_helper
INFO - 2018-02-17 16:15:01 --> Database Driver Class Initialized
DEBUG - 2018-02-17 16:15:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-17 16:15:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-17 16:15:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-17 16:15:01 --> Pagination Class Initialized
INFO - 2018-02-17 16:15:01 --> Helper loaded: form_helper
INFO - 2018-02-17 16:15:01 --> Form Validation Class Initialized
INFO - 2018-02-17 16:15:01 --> Model Class Initialized
INFO - 2018-02-17 16:15:01 --> Controller Class Initialized
INFO - 2018-02-17 16:15:01 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-17 16:15:01 --> Model Class Initialized
INFO - 2018-02-17 16:15:01 --> Model Class Initialized
INFO - 2018-02-17 16:15:01 --> Model Class Initialized
INFO - 2018-02-17 16:15:01 --> Model Class Initialized
INFO - 2018-02-17 16:15:12 --> Config Class Initialized
INFO - 2018-02-17 16:15:12 --> Hooks Class Initialized
DEBUG - 2018-02-17 16:15:12 --> UTF-8 Support Enabled
INFO - 2018-02-17 16:15:12 --> Utf8 Class Initialized
INFO - 2018-02-17 16:15:12 --> URI Class Initialized
INFO - 2018-02-17 16:15:12 --> Router Class Initialized
INFO - 2018-02-17 16:15:12 --> Output Class Initialized
INFO - 2018-02-17 16:15:12 --> Security Class Initialized
DEBUG - 2018-02-17 16:15:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-17 16:15:12 --> Input Class Initialized
INFO - 2018-02-17 16:15:12 --> Language Class Initialized
INFO - 2018-02-17 16:15:12 --> Loader Class Initialized
INFO - 2018-02-17 16:15:12 --> Helper loaded: url_helper
INFO - 2018-02-17 16:15:12 --> Helper loaded: file_helper
INFO - 2018-02-17 16:15:12 --> Helper loaded: email_helper
INFO - 2018-02-17 16:15:12 --> Helper loaded: common_helper
INFO - 2018-02-17 16:15:12 --> Database Driver Class Initialized
DEBUG - 2018-02-17 16:15:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-17 16:15:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-17 16:15:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-17 16:15:12 --> Pagination Class Initialized
INFO - 2018-02-17 16:15:12 --> Helper loaded: form_helper
INFO - 2018-02-17 16:15:12 --> Form Validation Class Initialized
INFO - 2018-02-17 16:15:12 --> Model Class Initialized
INFO - 2018-02-17 16:15:12 --> Controller Class Initialized
INFO - 2018-02-17 16:15:12 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-17 16:15:12 --> Model Class Initialized
INFO - 2018-02-17 16:15:12 --> Model Class Initialized
INFO - 2018-02-17 16:15:12 --> Model Class Initialized
INFO - 2018-02-17 16:15:12 --> Model Class Initialized
INFO - 2018-02-17 16:15:14 --> Config Class Initialized
INFO - 2018-02-17 16:15:14 --> Hooks Class Initialized
DEBUG - 2018-02-17 16:15:14 --> UTF-8 Support Enabled
INFO - 2018-02-17 16:15:14 --> Utf8 Class Initialized
INFO - 2018-02-17 16:15:14 --> URI Class Initialized
INFO - 2018-02-17 16:15:14 --> Router Class Initialized
INFO - 2018-02-17 16:15:14 --> Output Class Initialized
INFO - 2018-02-17 16:15:14 --> Security Class Initialized
DEBUG - 2018-02-17 16:15:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-17 16:15:14 --> Input Class Initialized
INFO - 2018-02-17 16:15:14 --> Language Class Initialized
INFO - 2018-02-17 16:15:14 --> Loader Class Initialized
INFO - 2018-02-17 16:15:14 --> Helper loaded: url_helper
INFO - 2018-02-17 16:15:14 --> Helper loaded: file_helper
INFO - 2018-02-17 16:15:14 --> Helper loaded: email_helper
INFO - 2018-02-17 16:15:14 --> Helper loaded: common_helper
INFO - 2018-02-17 16:15:14 --> Database Driver Class Initialized
DEBUG - 2018-02-17 16:15:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-17 16:15:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-17 16:15:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-17 16:15:14 --> Pagination Class Initialized
INFO - 2018-02-17 16:15:14 --> Helper loaded: form_helper
INFO - 2018-02-17 16:15:14 --> Form Validation Class Initialized
INFO - 2018-02-17 16:15:14 --> Model Class Initialized
INFO - 2018-02-17 16:15:14 --> Controller Class Initialized
INFO - 2018-02-17 16:15:14 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-17 16:15:14 --> Model Class Initialized
INFO - 2018-02-17 16:15:14 --> Model Class Initialized
INFO - 2018-02-17 16:15:14 --> Model Class Initialized
INFO - 2018-02-17 16:15:14 --> Model Class Initialized
INFO - 2018-02-17 16:15:14 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-17 16:15:14 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-17 16:15:14 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-17 16:15:14 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-17 16:15:14 --> File loaded: /var/www/html/project/radio/application/views/tracks/add_edit.php
INFO - 2018-02-17 16:15:14 --> Final output sent to browser
DEBUG - 2018-02-17 16:15:14 --> Total execution time: 0.0099
INFO - 2018-02-17 16:56:33 --> Config Class Initialized
INFO - 2018-02-17 16:56:33 --> Hooks Class Initialized
DEBUG - 2018-02-17 16:56:33 --> UTF-8 Support Enabled
INFO - 2018-02-17 16:56:33 --> Utf8 Class Initialized
INFO - 2018-02-17 16:56:33 --> URI Class Initialized
INFO - 2018-02-17 16:56:33 --> Router Class Initialized
INFO - 2018-02-17 16:56:33 --> Output Class Initialized
INFO - 2018-02-17 16:56:33 --> Security Class Initialized
DEBUG - 2018-02-17 16:56:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-17 16:56:33 --> Input Class Initialized
INFO - 2018-02-17 16:56:33 --> Language Class Initialized
INFO - 2018-02-17 16:56:33 --> Loader Class Initialized
INFO - 2018-02-17 16:56:33 --> Helper loaded: url_helper
INFO - 2018-02-17 16:56:33 --> Helper loaded: file_helper
INFO - 2018-02-17 16:56:33 --> Helper loaded: email_helper
INFO - 2018-02-17 16:56:33 --> Helper loaded: common_helper
INFO - 2018-02-17 16:56:33 --> Database Driver Class Initialized
DEBUG - 2018-02-17 16:56:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-17 16:56:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-17 16:56:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-17 16:56:33 --> Pagination Class Initialized
INFO - 2018-02-17 16:56:33 --> Helper loaded: form_helper
INFO - 2018-02-17 16:56:33 --> Form Validation Class Initialized
INFO - 2018-02-17 16:56:33 --> Model Class Initialized
INFO - 2018-02-17 16:56:33 --> Controller Class Initialized
INFO - 2018-02-17 16:56:33 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-17 16:56:33 --> Config Class Initialized
INFO - 2018-02-17 16:56:33 --> Hooks Class Initialized
DEBUG - 2018-02-17 16:56:33 --> UTF-8 Support Enabled
INFO - 2018-02-17 16:56:33 --> Utf8 Class Initialized
INFO - 2018-02-17 16:56:33 --> URI Class Initialized
DEBUG - 2018-02-17 16:56:33 --> No URI present. Default controller set.
INFO - 2018-02-17 16:56:33 --> Router Class Initialized
INFO - 2018-02-17 16:56:33 --> Output Class Initialized
INFO - 2018-02-17 16:56:33 --> Security Class Initialized
DEBUG - 2018-02-17 16:56:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-17 16:56:33 --> Input Class Initialized
INFO - 2018-02-17 16:56:33 --> Language Class Initialized
INFO - 2018-02-17 16:56:33 --> Loader Class Initialized
INFO - 2018-02-17 16:56:33 --> Helper loaded: url_helper
INFO - 2018-02-17 16:56:33 --> Helper loaded: file_helper
INFO - 2018-02-17 16:56:33 --> Helper loaded: email_helper
INFO - 2018-02-17 16:56:33 --> Helper loaded: common_helper
INFO - 2018-02-17 16:56:33 --> Database Driver Class Initialized
DEBUG - 2018-02-17 16:56:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-17 16:56:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-17 16:56:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-17 16:56:33 --> Pagination Class Initialized
INFO - 2018-02-17 16:56:33 --> Helper loaded: form_helper
INFO - 2018-02-17 16:56:33 --> Form Validation Class Initialized
INFO - 2018-02-17 16:56:33 --> Model Class Initialized
INFO - 2018-02-17 16:56:33 --> Controller Class Initialized
INFO - 2018-02-17 16:56:33 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-17 16:56:33 --> Model Class Initialized
INFO - 2018-02-17 16:56:33 --> File loaded: /var/www/html/project/radio/application/views/index/index.php
INFO - 2018-02-17 16:56:33 --> Final output sent to browser
DEBUG - 2018-02-17 16:56:33 --> Total execution time: 0.0061
INFO - 2018-02-17 16:56:38 --> Config Class Initialized
INFO - 2018-02-17 16:56:38 --> Hooks Class Initialized
DEBUG - 2018-02-17 16:56:38 --> UTF-8 Support Enabled
INFO - 2018-02-17 16:56:38 --> Utf8 Class Initialized
INFO - 2018-02-17 16:56:38 --> URI Class Initialized
INFO - 2018-02-17 16:56:38 --> Router Class Initialized
INFO - 2018-02-17 16:56:38 --> Output Class Initialized
INFO - 2018-02-17 16:56:38 --> Security Class Initialized
DEBUG - 2018-02-17 16:56:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-17 16:56:38 --> Input Class Initialized
INFO - 2018-02-17 16:56:38 --> Language Class Initialized
INFO - 2018-02-17 16:56:38 --> Loader Class Initialized
INFO - 2018-02-17 16:56:38 --> Helper loaded: url_helper
INFO - 2018-02-17 16:56:38 --> Helper loaded: file_helper
INFO - 2018-02-17 16:56:38 --> Helper loaded: email_helper
INFO - 2018-02-17 16:56:38 --> Helper loaded: common_helper
INFO - 2018-02-17 16:56:38 --> Database Driver Class Initialized
DEBUG - 2018-02-17 16:56:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-17 16:56:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-17 16:56:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-17 16:56:38 --> Pagination Class Initialized
INFO - 2018-02-17 16:56:38 --> Helper loaded: form_helper
INFO - 2018-02-17 16:56:38 --> Form Validation Class Initialized
INFO - 2018-02-17 16:56:38 --> Model Class Initialized
INFO - 2018-02-17 16:56:38 --> Controller Class Initialized
INFO - 2018-02-17 16:56:38 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-17 16:56:38 --> Model Class Initialized
ERROR - 2018-02-17 16:56:38 --> Severity: Notice --> Undefined index: remember_me /var/www/html/project/radio/application/controllers/Index.php 73
INFO - 2018-02-17 16:56:38 --> Config Class Initialized
INFO - 2018-02-17 16:56:38 --> Hooks Class Initialized
DEBUG - 2018-02-17 16:56:38 --> UTF-8 Support Enabled
INFO - 2018-02-17 16:56:38 --> Utf8 Class Initialized
INFO - 2018-02-17 16:56:38 --> URI Class Initialized
INFO - 2018-02-17 16:56:38 --> Router Class Initialized
INFO - 2018-02-17 16:56:38 --> Output Class Initialized
INFO - 2018-02-17 16:56:38 --> Security Class Initialized
DEBUG - 2018-02-17 16:56:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-17 16:56:38 --> Input Class Initialized
INFO - 2018-02-17 16:56:38 --> Language Class Initialized
INFO - 2018-02-17 16:56:38 --> Loader Class Initialized
INFO - 2018-02-17 16:56:38 --> Helper loaded: url_helper
INFO - 2018-02-17 16:56:38 --> Helper loaded: file_helper
INFO - 2018-02-17 16:56:38 --> Helper loaded: email_helper
INFO - 2018-02-17 16:56:38 --> Helper loaded: common_helper
INFO - 2018-02-17 16:56:38 --> Database Driver Class Initialized
DEBUG - 2018-02-17 16:56:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-17 16:56:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-17 16:56:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-17 16:56:38 --> Pagination Class Initialized
INFO - 2018-02-17 16:56:38 --> Helper loaded: form_helper
INFO - 2018-02-17 16:56:38 --> Form Validation Class Initialized
INFO - 2018-02-17 16:56:38 --> Model Class Initialized
INFO - 2018-02-17 16:56:38 --> Controller Class Initialized
INFO - 2018-02-17 16:56:38 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-17 16:56:38 --> Model Class Initialized
INFO - 2018-02-17 16:56:38 --> Model Class Initialized
INFO - 2018-02-17 16:56:38 --> Model Class Initialized
INFO - 2018-02-17 16:56:38 --> Model Class Initialized
INFO - 2018-02-17 16:56:38 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-17 16:56:38 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-17 16:56:38 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-17 16:56:38 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-17 16:56:38 --> File loaded: /var/www/html/project/radio/application/views/dashboard/index.php
INFO - 2018-02-17 16:56:38 --> Final output sent to browser
DEBUG - 2018-02-17 16:56:38 --> Total execution time: 0.0090
INFO - 2018-02-17 16:56:41 --> Config Class Initialized
INFO - 2018-02-17 16:56:41 --> Hooks Class Initialized
DEBUG - 2018-02-17 16:56:41 --> UTF-8 Support Enabled
INFO - 2018-02-17 16:56:41 --> Utf8 Class Initialized
INFO - 2018-02-17 16:56:41 --> URI Class Initialized
INFO - 2018-02-17 16:56:41 --> Router Class Initialized
INFO - 2018-02-17 16:56:41 --> Output Class Initialized
INFO - 2018-02-17 16:56:41 --> Security Class Initialized
DEBUG - 2018-02-17 16:56:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-17 16:56:41 --> Input Class Initialized
INFO - 2018-02-17 16:56:41 --> Language Class Initialized
INFO - 2018-02-17 16:56:41 --> Loader Class Initialized
INFO - 2018-02-17 16:56:41 --> Helper loaded: url_helper
INFO - 2018-02-17 16:56:41 --> Helper loaded: file_helper
INFO - 2018-02-17 16:56:41 --> Helper loaded: email_helper
INFO - 2018-02-17 16:56:41 --> Helper loaded: common_helper
INFO - 2018-02-17 16:56:41 --> Database Driver Class Initialized
DEBUG - 2018-02-17 16:56:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-17 16:56:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-17 16:56:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-17 16:56:41 --> Pagination Class Initialized
INFO - 2018-02-17 16:56:41 --> Helper loaded: form_helper
INFO - 2018-02-17 16:56:41 --> Form Validation Class Initialized
INFO - 2018-02-17 16:56:41 --> Model Class Initialized
INFO - 2018-02-17 16:56:41 --> Controller Class Initialized
INFO - 2018-02-17 16:56:41 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-17 16:56:41 --> Model Class Initialized
INFO - 2018-02-17 16:56:41 --> Model Class Initialized
INFO - 2018-02-17 16:56:41 --> Model Class Initialized
INFO - 2018-02-17 16:56:41 --> Model Class Initialized
INFO - 2018-02-17 16:56:41 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-17 16:56:41 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-17 16:56:41 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-17 16:56:41 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-17 16:56:41 --> File loaded: /var/www/html/project/radio/application/views/tracks/index.php
INFO - 2018-02-17 16:56:41 --> Final output sent to browser
DEBUG - 2018-02-17 16:56:41 --> Total execution time: 0.0082
INFO - 2018-02-17 16:56:41 --> Config Class Initialized
INFO - 2018-02-17 16:56:41 --> Hooks Class Initialized
DEBUG - 2018-02-17 16:56:41 --> UTF-8 Support Enabled
INFO - 2018-02-17 16:56:41 --> Utf8 Class Initialized
INFO - 2018-02-17 16:56:41 --> URI Class Initialized
INFO - 2018-02-17 16:56:41 --> Router Class Initialized
INFO - 2018-02-17 16:56:41 --> Output Class Initialized
INFO - 2018-02-17 16:56:41 --> Security Class Initialized
DEBUG - 2018-02-17 16:56:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-17 16:56:41 --> Input Class Initialized
INFO - 2018-02-17 16:56:41 --> Language Class Initialized
INFO - 2018-02-17 16:56:41 --> Loader Class Initialized
INFO - 2018-02-17 16:56:41 --> Helper loaded: url_helper
INFO - 2018-02-17 16:56:41 --> Helper loaded: file_helper
INFO - 2018-02-17 16:56:41 --> Helper loaded: email_helper
INFO - 2018-02-17 16:56:41 --> Helper loaded: common_helper
INFO - 2018-02-17 16:56:41 --> Database Driver Class Initialized
DEBUG - 2018-02-17 16:56:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-17 16:56:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-17 16:56:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-17 16:56:41 --> Pagination Class Initialized
INFO - 2018-02-17 16:56:41 --> Helper loaded: form_helper
INFO - 2018-02-17 16:56:41 --> Form Validation Class Initialized
INFO - 2018-02-17 16:56:41 --> Model Class Initialized
INFO - 2018-02-17 16:56:41 --> Controller Class Initialized
INFO - 2018-02-17 16:56:41 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-17 16:56:41 --> Model Class Initialized
INFO - 2018-02-17 16:56:41 --> Model Class Initialized
INFO - 2018-02-17 16:56:41 --> Model Class Initialized
INFO - 2018-02-17 16:56:41 --> Model Class Initialized
INFO - 2018-02-17 16:56:45 --> Config Class Initialized
INFO - 2018-02-17 16:56:45 --> Hooks Class Initialized
DEBUG - 2018-02-17 16:56:45 --> UTF-8 Support Enabled
INFO - 2018-02-17 16:56:45 --> Utf8 Class Initialized
INFO - 2018-02-17 16:56:45 --> URI Class Initialized
INFO - 2018-02-17 16:56:45 --> Router Class Initialized
INFO - 2018-02-17 16:56:45 --> Output Class Initialized
INFO - 2018-02-17 16:56:45 --> Security Class Initialized
DEBUG - 2018-02-17 16:56:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-17 16:56:45 --> Input Class Initialized
INFO - 2018-02-17 16:56:45 --> Language Class Initialized
INFO - 2018-02-17 16:56:45 --> Loader Class Initialized
INFO - 2018-02-17 16:56:45 --> Helper loaded: url_helper
INFO - 2018-02-17 16:56:45 --> Helper loaded: file_helper
INFO - 2018-02-17 16:56:45 --> Helper loaded: email_helper
INFO - 2018-02-17 16:56:45 --> Helper loaded: common_helper
INFO - 2018-02-17 16:56:45 --> Database Driver Class Initialized
DEBUG - 2018-02-17 16:56:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-17 16:56:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-17 16:56:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-17 16:56:45 --> Pagination Class Initialized
INFO - 2018-02-17 16:56:45 --> Helper loaded: form_helper
INFO - 2018-02-17 16:56:45 --> Form Validation Class Initialized
INFO - 2018-02-17 16:56:45 --> Model Class Initialized
INFO - 2018-02-17 16:56:45 --> Controller Class Initialized
INFO - 2018-02-17 16:56:45 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-17 16:56:45 --> Model Class Initialized
INFO - 2018-02-17 16:56:45 --> Model Class Initialized
INFO - 2018-02-17 16:56:45 --> Model Class Initialized
INFO - 2018-02-17 16:56:45 --> Model Class Initialized
INFO - 2018-02-17 16:56:45 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-17 16:56:45 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-17 16:56:45 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-17 16:56:45 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-17 16:56:45 --> File loaded: /var/www/html/project/radio/application/views/tracks/add_edit.php
INFO - 2018-02-17 16:56:45 --> Final output sent to browser
DEBUG - 2018-02-17 16:56:45 --> Total execution time: 0.0116
INFO - 2018-02-17 16:56:50 --> Config Class Initialized
INFO - 2018-02-17 16:56:50 --> Hooks Class Initialized
DEBUG - 2018-02-17 16:56:50 --> UTF-8 Support Enabled
INFO - 2018-02-17 16:56:50 --> Utf8 Class Initialized
INFO - 2018-02-17 16:56:50 --> URI Class Initialized
INFO - 2018-02-17 16:56:50 --> Router Class Initialized
INFO - 2018-02-17 16:56:50 --> Output Class Initialized
INFO - 2018-02-17 16:56:50 --> Security Class Initialized
DEBUG - 2018-02-17 16:56:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-17 16:56:50 --> Input Class Initialized
INFO - 2018-02-17 16:56:50 --> Language Class Initialized
INFO - 2018-02-17 16:56:50 --> Loader Class Initialized
INFO - 2018-02-17 16:56:50 --> Helper loaded: url_helper
INFO - 2018-02-17 16:56:50 --> Helper loaded: file_helper
INFO - 2018-02-17 16:56:50 --> Helper loaded: email_helper
INFO - 2018-02-17 16:56:50 --> Helper loaded: common_helper
INFO - 2018-02-17 16:56:50 --> Database Driver Class Initialized
DEBUG - 2018-02-17 16:56:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-17 16:56:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-17 16:56:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-17 16:56:50 --> Pagination Class Initialized
INFO - 2018-02-17 16:56:50 --> Helper loaded: form_helper
INFO - 2018-02-17 16:56:50 --> Form Validation Class Initialized
INFO - 2018-02-17 16:56:50 --> Model Class Initialized
INFO - 2018-02-17 16:56:50 --> Controller Class Initialized
INFO - 2018-02-17 16:56:50 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-17 16:56:50 --> Model Class Initialized
INFO - 2018-02-17 16:56:50 --> Model Class Initialized
INFO - 2018-02-17 16:56:50 --> Model Class Initialized
INFO - 2018-02-17 16:56:50 --> Model Class Initialized
INFO - 2018-02-17 16:58:54 --> Config Class Initialized
INFO - 2018-02-17 16:58:54 --> Hooks Class Initialized
DEBUG - 2018-02-17 16:58:54 --> UTF-8 Support Enabled
INFO - 2018-02-17 16:58:54 --> Utf8 Class Initialized
INFO - 2018-02-17 16:58:54 --> URI Class Initialized
INFO - 2018-02-17 16:58:54 --> Router Class Initialized
INFO - 2018-02-17 16:58:54 --> Output Class Initialized
INFO - 2018-02-17 16:58:54 --> Security Class Initialized
DEBUG - 2018-02-17 16:58:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-17 16:58:54 --> Input Class Initialized
INFO - 2018-02-17 16:58:54 --> Language Class Initialized
INFO - 2018-02-17 16:58:54 --> Loader Class Initialized
INFO - 2018-02-17 16:58:54 --> Helper loaded: url_helper
INFO - 2018-02-17 16:58:54 --> Helper loaded: file_helper
INFO - 2018-02-17 16:58:54 --> Helper loaded: email_helper
INFO - 2018-02-17 16:58:54 --> Helper loaded: common_helper
INFO - 2018-02-17 16:58:54 --> Database Driver Class Initialized
DEBUG - 2018-02-17 16:58:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-17 16:58:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-17 16:58:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-17 16:58:54 --> Pagination Class Initialized
INFO - 2018-02-17 16:58:54 --> Helper loaded: form_helper
INFO - 2018-02-17 16:58:54 --> Form Validation Class Initialized
INFO - 2018-02-17 16:58:54 --> Model Class Initialized
INFO - 2018-02-17 16:58:54 --> Controller Class Initialized
INFO - 2018-02-17 16:58:54 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-17 16:58:54 --> Model Class Initialized
INFO - 2018-02-17 16:58:54 --> Model Class Initialized
INFO - 2018-02-17 16:58:54 --> Model Class Initialized
INFO - 2018-02-17 16:58:54 --> Model Class Initialized
INFO - 2018-02-17 16:58:54 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-17 16:58:54 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-17 16:58:54 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-17 16:58:54 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-17 16:58:54 --> File loaded: /var/www/html/project/radio/application/views/tracks/index.php
INFO - 2018-02-17 16:58:54 --> Final output sent to browser
DEBUG - 2018-02-17 16:58:54 --> Total execution time: 0.0097
INFO - 2018-02-17 16:58:54 --> Config Class Initialized
INFO - 2018-02-17 16:58:54 --> Hooks Class Initialized
DEBUG - 2018-02-17 16:58:54 --> UTF-8 Support Enabled
INFO - 2018-02-17 16:58:54 --> Utf8 Class Initialized
INFO - 2018-02-17 16:58:54 --> URI Class Initialized
INFO - 2018-02-17 16:58:54 --> Router Class Initialized
INFO - 2018-02-17 16:58:54 --> Output Class Initialized
INFO - 2018-02-17 16:58:54 --> Security Class Initialized
DEBUG - 2018-02-17 16:58:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-17 16:58:54 --> Input Class Initialized
INFO - 2018-02-17 16:58:54 --> Language Class Initialized
INFO - 2018-02-17 16:58:54 --> Loader Class Initialized
INFO - 2018-02-17 16:58:54 --> Helper loaded: url_helper
INFO - 2018-02-17 16:58:54 --> Helper loaded: file_helper
INFO - 2018-02-17 16:58:54 --> Helper loaded: email_helper
INFO - 2018-02-17 16:58:54 --> Helper loaded: common_helper
INFO - 2018-02-17 16:58:54 --> Database Driver Class Initialized
DEBUG - 2018-02-17 16:58:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-17 16:58:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-17 16:58:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-17 16:58:54 --> Pagination Class Initialized
INFO - 2018-02-17 16:58:54 --> Helper loaded: form_helper
INFO - 2018-02-17 16:58:54 --> Form Validation Class Initialized
INFO - 2018-02-17 16:58:54 --> Model Class Initialized
INFO - 2018-02-17 16:58:54 --> Controller Class Initialized
INFO - 2018-02-17 16:58:54 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-17 16:58:54 --> Model Class Initialized
INFO - 2018-02-17 16:58:54 --> Model Class Initialized
INFO - 2018-02-17 16:58:54 --> Model Class Initialized
INFO - 2018-02-17 16:58:54 --> Model Class Initialized
INFO - 2018-02-17 16:59:23 --> Config Class Initialized
INFO - 2018-02-17 16:59:23 --> Hooks Class Initialized
DEBUG - 2018-02-17 16:59:23 --> UTF-8 Support Enabled
INFO - 2018-02-17 16:59:23 --> Utf8 Class Initialized
INFO - 2018-02-17 16:59:23 --> URI Class Initialized
INFO - 2018-02-17 16:59:23 --> Router Class Initialized
INFO - 2018-02-17 16:59:23 --> Output Class Initialized
INFO - 2018-02-17 16:59:23 --> Security Class Initialized
DEBUG - 2018-02-17 16:59:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-17 16:59:23 --> Input Class Initialized
INFO - 2018-02-17 16:59:23 --> Language Class Initialized
INFO - 2018-02-17 16:59:23 --> Loader Class Initialized
INFO - 2018-02-17 16:59:23 --> Helper loaded: url_helper
INFO - 2018-02-17 16:59:23 --> Helper loaded: file_helper
INFO - 2018-02-17 16:59:23 --> Helper loaded: email_helper
INFO - 2018-02-17 16:59:23 --> Helper loaded: common_helper
INFO - 2018-02-17 16:59:23 --> Database Driver Class Initialized
DEBUG - 2018-02-17 16:59:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-17 16:59:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-17 16:59:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-17 16:59:23 --> Pagination Class Initialized
INFO - 2018-02-17 16:59:23 --> Helper loaded: form_helper
INFO - 2018-02-17 16:59:23 --> Form Validation Class Initialized
INFO - 2018-02-17 16:59:23 --> Model Class Initialized
INFO - 2018-02-17 16:59:23 --> Controller Class Initialized
INFO - 2018-02-17 16:59:23 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-17 16:59:23 --> Model Class Initialized
INFO - 2018-02-17 16:59:23 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-17 16:59:23 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-17 16:59:23 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-17 16:59:23 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-17 16:59:23 --> File loaded: /var/www/html/project/radio/application/views/category/index.php
INFO - 2018-02-17 16:59:23 --> Final output sent to browser
DEBUG - 2018-02-17 16:59:23 --> Total execution time: 0.0259
INFO - 2018-02-17 17:51:05 --> Config Class Initialized
INFO - 2018-02-17 17:51:05 --> Hooks Class Initialized
DEBUG - 2018-02-17 17:51:05 --> UTF-8 Support Enabled
INFO - 2018-02-17 17:51:05 --> Utf8 Class Initialized
INFO - 2018-02-17 17:51:05 --> URI Class Initialized
INFO - 2018-02-17 17:51:05 --> Router Class Initialized
INFO - 2018-02-17 17:51:05 --> Output Class Initialized
INFO - 2018-02-17 17:51:05 --> Security Class Initialized
DEBUG - 2018-02-17 17:51:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-17 17:51:05 --> Input Class Initialized
INFO - 2018-02-17 17:51:05 --> Language Class Initialized
INFO - 2018-02-17 17:51:05 --> Loader Class Initialized
INFO - 2018-02-17 17:51:05 --> Helper loaded: url_helper
INFO - 2018-02-17 17:51:05 --> Helper loaded: file_helper
INFO - 2018-02-17 17:51:05 --> Helper loaded: email_helper
INFO - 2018-02-17 17:51:05 --> Helper loaded: common_helper
INFO - 2018-02-17 17:51:05 --> Database Driver Class Initialized
DEBUG - 2018-02-17 17:51:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-17 17:51:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-17 17:51:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-17 17:51:05 --> Pagination Class Initialized
INFO - 2018-02-17 17:51:05 --> Helper loaded: form_helper
INFO - 2018-02-17 17:51:05 --> Form Validation Class Initialized
INFO - 2018-02-17 17:51:05 --> Model Class Initialized
INFO - 2018-02-17 17:51:05 --> Controller Class Initialized
INFO - 2018-02-17 17:51:05 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-17 17:51:05 --> Model Class Initialized
INFO - 2018-02-17 17:52:13 --> Config Class Initialized
INFO - 2018-02-17 17:52:13 --> Hooks Class Initialized
DEBUG - 2018-02-17 17:52:13 --> UTF-8 Support Enabled
INFO - 2018-02-17 17:52:13 --> Utf8 Class Initialized
INFO - 2018-02-17 17:52:13 --> URI Class Initialized
INFO - 2018-02-17 17:52:13 --> Router Class Initialized
INFO - 2018-02-17 17:52:13 --> Output Class Initialized
INFO - 2018-02-17 17:52:13 --> Security Class Initialized
DEBUG - 2018-02-17 17:52:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-17 17:52:13 --> Input Class Initialized
INFO - 2018-02-17 17:52:13 --> Language Class Initialized
INFO - 2018-02-17 17:52:13 --> Loader Class Initialized
INFO - 2018-02-17 17:52:13 --> Helper loaded: url_helper
INFO - 2018-02-17 17:52:13 --> Helper loaded: file_helper
INFO - 2018-02-17 17:52:13 --> Helper loaded: email_helper
INFO - 2018-02-17 17:52:13 --> Helper loaded: common_helper
INFO - 2018-02-17 17:52:13 --> Database Driver Class Initialized
DEBUG - 2018-02-17 17:52:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-17 17:52:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-17 17:52:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-17 17:52:13 --> Pagination Class Initialized
INFO - 2018-02-17 17:52:13 --> Helper loaded: form_helper
INFO - 2018-02-17 17:52:13 --> Form Validation Class Initialized
INFO - 2018-02-17 17:52:13 --> Model Class Initialized
INFO - 2018-02-17 17:52:13 --> Controller Class Initialized
INFO - 2018-02-17 17:52:13 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-17 17:52:13 --> Model Class Initialized

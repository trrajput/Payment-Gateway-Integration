<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2018-02-22 10:03:31 --> Config Class Initialized
INFO - 2018-02-22 10:03:31 --> Hooks Class Initialized
DEBUG - 2018-02-22 10:03:31 --> UTF-8 Support Enabled
INFO - 2018-02-22 10:03:31 --> Utf8 Class Initialized
INFO - 2018-02-22 10:03:31 --> URI Class Initialized
DEBUG - 2018-02-22 10:03:31 --> No URI present. Default controller set.
INFO - 2018-02-22 10:03:31 --> Router Class Initialized
INFO - 2018-02-22 10:03:31 --> Output Class Initialized
INFO - 2018-02-22 10:03:31 --> Security Class Initialized
DEBUG - 2018-02-22 10:03:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-22 10:03:31 --> Input Class Initialized
INFO - 2018-02-22 10:03:31 --> Language Class Initialized
INFO - 2018-02-22 10:03:31 --> Loader Class Initialized
INFO - 2018-02-22 10:03:31 --> Helper loaded: url_helper
INFO - 2018-02-22 10:03:31 --> Helper loaded: file_helper
INFO - 2018-02-22 10:03:31 --> Helper loaded: email_helper
INFO - 2018-02-22 10:03:31 --> Helper loaded: common_helper
INFO - 2018-02-22 10:03:31 --> Database Driver Class Initialized
DEBUG - 2018-02-22 10:03:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-22 10:03:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-22 10:03:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-22 10:03:31 --> Pagination Class Initialized
INFO - 2018-02-22 10:03:31 --> Helper loaded: form_helper
INFO - 2018-02-22 10:03:31 --> Form Validation Class Initialized
INFO - 2018-02-22 10:03:31 --> Model Class Initialized
INFO - 2018-02-22 10:03:31 --> Controller Class Initialized
INFO - 2018-02-22 10:03:31 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-22 10:03:31 --> Model Class Initialized
INFO - 2018-02-22 10:03:31 --> Model Class Initialized
INFO - 2018-02-22 10:03:31 --> File loaded: /var/www/html/project/radio/application/views/index/index.php
INFO - 2018-02-22 10:03:31 --> Final output sent to browser
DEBUG - 2018-02-22 10:03:31 --> Total execution time: 0.3653
INFO - 2018-02-22 10:04:53 --> Config Class Initialized
INFO - 2018-02-22 10:04:53 --> Hooks Class Initialized
DEBUG - 2018-02-22 10:04:53 --> UTF-8 Support Enabled
INFO - 2018-02-22 10:04:53 --> Utf8 Class Initialized
INFO - 2018-02-22 10:04:53 --> URI Class Initialized
INFO - 2018-02-22 10:04:53 --> Router Class Initialized
INFO - 2018-02-22 10:04:53 --> Output Class Initialized
INFO - 2018-02-22 10:04:53 --> Security Class Initialized
DEBUG - 2018-02-22 10:04:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-22 10:04:53 --> Input Class Initialized
INFO - 2018-02-22 10:04:53 --> Language Class Initialized
INFO - 2018-02-22 10:04:53 --> Loader Class Initialized
INFO - 2018-02-22 10:04:53 --> Helper loaded: url_helper
INFO - 2018-02-22 10:04:53 --> Helper loaded: file_helper
INFO - 2018-02-22 10:04:53 --> Helper loaded: email_helper
INFO - 2018-02-22 10:04:53 --> Helper loaded: common_helper
INFO - 2018-02-22 10:04:53 --> Database Driver Class Initialized
DEBUG - 2018-02-22 10:04:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-22 10:04:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-22 10:04:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-22 10:04:53 --> Pagination Class Initialized
INFO - 2018-02-22 10:04:53 --> Helper loaded: form_helper
INFO - 2018-02-22 10:04:53 --> Form Validation Class Initialized
INFO - 2018-02-22 10:04:53 --> Model Class Initialized
INFO - 2018-02-22 10:04:53 --> Controller Class Initialized
INFO - 2018-02-22 10:04:53 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-22 10:04:53 --> Model Class Initialized
INFO - 2018-02-22 10:04:53 --> Model Class Initialized
ERROR - 2018-02-22 10:04:53 --> Severity: Notice --> Undefined index: remember_me /var/www/html/project/radio/application/controllers/Index.php 74
INFO - 2018-02-22 10:04:53 --> Config Class Initialized
INFO - 2018-02-22 10:04:53 --> Hooks Class Initialized
DEBUG - 2018-02-22 10:04:53 --> UTF-8 Support Enabled
INFO - 2018-02-22 10:04:53 --> Utf8 Class Initialized
INFO - 2018-02-22 10:04:53 --> URI Class Initialized
INFO - 2018-02-22 10:04:53 --> Router Class Initialized
INFO - 2018-02-22 10:04:53 --> Output Class Initialized
INFO - 2018-02-22 10:04:53 --> Security Class Initialized
DEBUG - 2018-02-22 10:04:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-22 10:04:53 --> Input Class Initialized
INFO - 2018-02-22 10:04:53 --> Language Class Initialized
INFO - 2018-02-22 10:04:53 --> Loader Class Initialized
INFO - 2018-02-22 10:04:53 --> Helper loaded: url_helper
INFO - 2018-02-22 10:04:53 --> Helper loaded: file_helper
INFO - 2018-02-22 10:04:53 --> Helper loaded: email_helper
INFO - 2018-02-22 10:04:53 --> Helper loaded: common_helper
INFO - 2018-02-22 10:04:53 --> Database Driver Class Initialized
DEBUG - 2018-02-22 10:04:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-22 10:04:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-22 10:04:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-22 10:04:53 --> Pagination Class Initialized
INFO - 2018-02-22 10:04:53 --> Helper loaded: form_helper
INFO - 2018-02-22 10:04:53 --> Form Validation Class Initialized
INFO - 2018-02-22 10:04:53 --> Model Class Initialized
INFO - 2018-02-22 10:04:53 --> Controller Class Initialized
INFO - 2018-02-22 10:04:53 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-22 10:04:53 --> Model Class Initialized
INFO - 2018-02-22 10:04:53 --> Model Class Initialized
INFO - 2018-02-22 10:04:53 --> Model Class Initialized
INFO - 2018-02-22 10:04:53 --> Model Class Initialized
INFO - 2018-02-22 10:04:54 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-22 10:04:54 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-22 10:04:54 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-22 10:04:54 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-22 10:04:54 --> File loaded: /var/www/html/project/radio/application/views/dashboard/index.php
INFO - 2018-02-22 10:04:54 --> Final output sent to browser
DEBUG - 2018-02-22 10:04:54 --> Total execution time: 0.1915
INFO - 2018-02-22 10:04:56 --> Config Class Initialized
INFO - 2018-02-22 10:04:56 --> Hooks Class Initialized
DEBUG - 2018-02-22 10:04:56 --> UTF-8 Support Enabled
INFO - 2018-02-22 10:04:56 --> Utf8 Class Initialized
INFO - 2018-02-22 10:04:56 --> URI Class Initialized
INFO - 2018-02-22 10:04:56 --> Router Class Initialized
INFO - 2018-02-22 10:04:56 --> Output Class Initialized
INFO - 2018-02-22 10:04:56 --> Security Class Initialized
DEBUG - 2018-02-22 10:04:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-22 10:04:56 --> Input Class Initialized
INFO - 2018-02-22 10:04:56 --> Language Class Initialized
INFO - 2018-02-22 10:04:56 --> Loader Class Initialized
INFO - 2018-02-22 10:04:56 --> Helper loaded: url_helper
INFO - 2018-02-22 10:04:56 --> Helper loaded: file_helper
INFO - 2018-02-22 10:04:56 --> Helper loaded: email_helper
INFO - 2018-02-22 10:04:56 --> Helper loaded: common_helper
INFO - 2018-02-22 10:04:56 --> Database Driver Class Initialized
DEBUG - 2018-02-22 10:04:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-22 10:04:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-22 10:04:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-22 10:04:56 --> Pagination Class Initialized
INFO - 2018-02-22 10:04:56 --> Helper loaded: form_helper
INFO - 2018-02-22 10:04:56 --> Form Validation Class Initialized
INFO - 2018-02-22 10:04:56 --> Model Class Initialized
INFO - 2018-02-22 10:04:56 --> Controller Class Initialized
INFO - 2018-02-22 10:04:56 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-22 10:04:56 --> Model Class Initialized
INFO - 2018-02-22 10:04:56 --> Model Class Initialized
INFO - 2018-02-22 10:04:56 --> Model Class Initialized
INFO - 2018-02-22 10:04:56 --> Model Class Initialized
INFO - 2018-02-22 10:04:56 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-22 10:04:56 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-22 10:04:56 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-22 10:04:56 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-22 10:04:56 --> File loaded: /var/www/html/project/radio/application/views/tracks/index.php
INFO - 2018-02-22 10:04:56 --> Final output sent to browser
DEBUG - 2018-02-22 10:04:56 --> Total execution time: 0.0223
INFO - 2018-02-22 10:04:56 --> Config Class Initialized
INFO - 2018-02-22 10:04:56 --> Hooks Class Initialized
DEBUG - 2018-02-22 10:04:56 --> UTF-8 Support Enabled
INFO - 2018-02-22 10:04:56 --> Utf8 Class Initialized
INFO - 2018-02-22 10:04:56 --> URI Class Initialized
INFO - 2018-02-22 10:04:56 --> Router Class Initialized
INFO - 2018-02-22 10:04:56 --> Output Class Initialized
INFO - 2018-02-22 10:04:56 --> Security Class Initialized
DEBUG - 2018-02-22 10:04:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-22 10:04:56 --> Input Class Initialized
INFO - 2018-02-22 10:04:56 --> Language Class Initialized
INFO - 2018-02-22 10:04:56 --> Loader Class Initialized
INFO - 2018-02-22 10:04:56 --> Helper loaded: url_helper
INFO - 2018-02-22 10:04:56 --> Helper loaded: file_helper
INFO - 2018-02-22 10:04:56 --> Helper loaded: email_helper
INFO - 2018-02-22 10:04:56 --> Helper loaded: common_helper
INFO - 2018-02-22 10:04:56 --> Database Driver Class Initialized
DEBUG - 2018-02-22 10:04:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-22 10:04:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-22 10:04:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-22 10:04:56 --> Pagination Class Initialized
INFO - 2018-02-22 10:04:56 --> Helper loaded: form_helper
INFO - 2018-02-22 10:04:56 --> Form Validation Class Initialized
INFO - 2018-02-22 10:04:56 --> Model Class Initialized
INFO - 2018-02-22 10:04:56 --> Controller Class Initialized
INFO - 2018-02-22 10:04:56 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-22 10:04:56 --> Model Class Initialized
INFO - 2018-02-22 10:04:56 --> Model Class Initialized
INFO - 2018-02-22 10:04:56 --> Model Class Initialized
INFO - 2018-02-22 10:04:56 --> Model Class Initialized
INFO - 2018-02-22 10:07:20 --> Config Class Initialized
INFO - 2018-02-22 10:07:20 --> Hooks Class Initialized
DEBUG - 2018-02-22 10:07:20 --> UTF-8 Support Enabled
INFO - 2018-02-22 10:07:20 --> Utf8 Class Initialized
INFO - 2018-02-22 10:07:20 --> URI Class Initialized
INFO - 2018-02-22 10:07:20 --> Router Class Initialized
INFO - 2018-02-22 10:07:20 --> Output Class Initialized
INFO - 2018-02-22 10:07:20 --> Security Class Initialized
DEBUG - 2018-02-22 10:07:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-22 10:07:20 --> Input Class Initialized
INFO - 2018-02-22 10:07:20 --> Language Class Initialized
INFO - 2018-02-22 10:07:20 --> Loader Class Initialized
INFO - 2018-02-22 10:07:20 --> Helper loaded: url_helper
INFO - 2018-02-22 10:07:20 --> Helper loaded: file_helper
INFO - 2018-02-22 10:07:20 --> Helper loaded: email_helper
INFO - 2018-02-22 10:07:20 --> Helper loaded: common_helper
INFO - 2018-02-22 10:07:20 --> Database Driver Class Initialized
DEBUG - 2018-02-22 10:07:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-22 10:07:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-22 10:07:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-22 10:07:20 --> Pagination Class Initialized
INFO - 2018-02-22 10:07:20 --> Helper loaded: form_helper
INFO - 2018-02-22 10:07:20 --> Form Validation Class Initialized
INFO - 2018-02-22 10:07:20 --> Model Class Initialized
INFO - 2018-02-22 10:07:20 --> Controller Class Initialized
DEBUG - 2018-02-22 10:07:20 --> Config file loaded: /var/www/html/project/radio/application/config/rest.php
INFO - 2018-02-22 10:07:20 --> Helper loaded: inflector_helper
INFO - 2018-02-22 10:07:20 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-22 10:07:20 --> Model Class Initialized
INFO - 2018-02-22 10:07:20 --> Model Class Initialized
INFO - 2018-02-22 10:07:20 --> Model Class Initialized
INFO - 2018-02-22 10:07:20 --> Model Class Initialized
INFO - 2018-02-22 10:07:20 --> Model Class Initialized
INFO - 2018-02-22 10:07:20 --> Final output sent to browser
DEBUG - 2018-02-22 10:07:20 --> Total execution time: 0.0806
INFO - 2018-02-22 10:10:20 --> Config Class Initialized
INFO - 2018-02-22 10:10:20 --> Hooks Class Initialized
DEBUG - 2018-02-22 10:10:20 --> UTF-8 Support Enabled
INFO - 2018-02-22 10:10:20 --> Utf8 Class Initialized
INFO - 2018-02-22 10:10:20 --> URI Class Initialized
INFO - 2018-02-22 10:10:20 --> Router Class Initialized
INFO - 2018-02-22 10:10:20 --> Output Class Initialized
INFO - 2018-02-22 10:10:20 --> Security Class Initialized
DEBUG - 2018-02-22 10:10:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-22 10:10:20 --> Input Class Initialized
INFO - 2018-02-22 10:10:20 --> Language Class Initialized
INFO - 2018-02-22 10:10:20 --> Loader Class Initialized
INFO - 2018-02-22 10:10:20 --> Helper loaded: url_helper
INFO - 2018-02-22 10:10:20 --> Helper loaded: file_helper
INFO - 2018-02-22 10:10:20 --> Helper loaded: email_helper
INFO - 2018-02-22 10:10:20 --> Helper loaded: common_helper
INFO - 2018-02-22 10:10:20 --> Database Driver Class Initialized
DEBUG - 2018-02-22 10:10:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-22 10:10:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-22 10:10:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-22 10:10:20 --> Pagination Class Initialized
INFO - 2018-02-22 10:10:20 --> Helper loaded: form_helper
INFO - 2018-02-22 10:10:20 --> Form Validation Class Initialized
INFO - 2018-02-22 10:10:20 --> Model Class Initialized
INFO - 2018-02-22 10:10:20 --> Controller Class Initialized
DEBUG - 2018-02-22 10:10:20 --> Config file loaded: /var/www/html/project/radio/application/config/rest.php
INFO - 2018-02-22 10:10:20 --> Helper loaded: inflector_helper
INFO - 2018-02-22 10:10:20 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-22 10:10:20 --> Model Class Initialized
INFO - 2018-02-22 10:10:20 --> Model Class Initialized
INFO - 2018-02-22 10:10:20 --> Model Class Initialized
INFO - 2018-02-22 10:10:20 --> Model Class Initialized
INFO - 2018-02-22 10:10:20 --> Model Class Initialized
INFO - 2018-02-22 10:10:20 --> Final output sent to browser
DEBUG - 2018-02-22 10:10:20 --> Total execution time: 0.0123
INFO - 2018-02-22 10:10:27 --> Config Class Initialized
INFO - 2018-02-22 10:10:27 --> Hooks Class Initialized
DEBUG - 2018-02-22 10:10:27 --> UTF-8 Support Enabled
INFO - 2018-02-22 10:10:27 --> Utf8 Class Initialized
INFO - 2018-02-22 10:10:27 --> URI Class Initialized
INFO - 2018-02-22 10:10:27 --> Router Class Initialized
INFO - 2018-02-22 10:10:27 --> Output Class Initialized
INFO - 2018-02-22 10:10:27 --> Security Class Initialized
DEBUG - 2018-02-22 10:10:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-22 10:10:27 --> Input Class Initialized
INFO - 2018-02-22 10:10:27 --> Language Class Initialized
INFO - 2018-02-22 10:10:27 --> Loader Class Initialized
INFO - 2018-02-22 10:10:27 --> Helper loaded: url_helper
INFO - 2018-02-22 10:10:27 --> Helper loaded: file_helper
INFO - 2018-02-22 10:10:27 --> Helper loaded: email_helper
INFO - 2018-02-22 10:10:27 --> Helper loaded: common_helper
INFO - 2018-02-22 10:10:27 --> Database Driver Class Initialized
DEBUG - 2018-02-22 10:10:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-22 10:10:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-22 10:10:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-22 10:10:27 --> Pagination Class Initialized
INFO - 2018-02-22 10:10:27 --> Helper loaded: form_helper
INFO - 2018-02-22 10:10:27 --> Form Validation Class Initialized
INFO - 2018-02-22 10:10:27 --> Model Class Initialized
INFO - 2018-02-22 10:10:27 --> Controller Class Initialized
DEBUG - 2018-02-22 10:10:27 --> Config file loaded: /var/www/html/project/radio/application/config/rest.php
INFO - 2018-02-22 10:10:27 --> Helper loaded: inflector_helper
INFO - 2018-02-22 10:10:27 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-22 10:10:27 --> Model Class Initialized
INFO - 2018-02-22 10:10:27 --> Model Class Initialized
INFO - 2018-02-22 10:10:27 --> Model Class Initialized
INFO - 2018-02-22 10:10:27 --> Model Class Initialized
INFO - 2018-02-22 10:10:27 --> Model Class Initialized
INFO - 2018-02-22 10:10:27 --> Final output sent to browser
DEBUG - 2018-02-22 10:10:27 --> Total execution time: 0.0100
INFO - 2018-02-22 10:11:19 --> Config Class Initialized
INFO - 2018-02-22 10:11:19 --> Hooks Class Initialized
DEBUG - 2018-02-22 10:11:19 --> UTF-8 Support Enabled
INFO - 2018-02-22 10:11:19 --> Utf8 Class Initialized
INFO - 2018-02-22 10:11:19 --> URI Class Initialized
INFO - 2018-02-22 10:11:19 --> Router Class Initialized
INFO - 2018-02-22 10:11:19 --> Output Class Initialized
INFO - 2018-02-22 10:11:19 --> Security Class Initialized
DEBUG - 2018-02-22 10:11:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-22 10:11:19 --> Input Class Initialized
INFO - 2018-02-22 10:11:19 --> Language Class Initialized
INFO - 2018-02-22 10:11:19 --> Loader Class Initialized
INFO - 2018-02-22 10:11:19 --> Helper loaded: url_helper
INFO - 2018-02-22 10:11:19 --> Helper loaded: file_helper
INFO - 2018-02-22 10:11:19 --> Helper loaded: email_helper
INFO - 2018-02-22 10:11:19 --> Helper loaded: common_helper
INFO - 2018-02-22 10:11:19 --> Database Driver Class Initialized
DEBUG - 2018-02-22 10:11:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-22 10:11:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-22 10:11:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-22 10:11:19 --> Pagination Class Initialized
INFO - 2018-02-22 10:11:19 --> Helper loaded: form_helper
INFO - 2018-02-22 10:11:19 --> Form Validation Class Initialized
INFO - 2018-02-22 10:11:19 --> Model Class Initialized
INFO - 2018-02-22 10:11:19 --> Controller Class Initialized
DEBUG - 2018-02-22 10:11:19 --> Config file loaded: /var/www/html/project/radio/application/config/rest.php
INFO - 2018-02-22 10:11:19 --> Helper loaded: inflector_helper
INFO - 2018-02-22 10:11:19 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-22 10:11:19 --> Model Class Initialized
INFO - 2018-02-22 10:11:19 --> Model Class Initialized
INFO - 2018-02-22 10:11:19 --> Model Class Initialized
INFO - 2018-02-22 10:11:19 --> Model Class Initialized
INFO - 2018-02-22 10:11:19 --> Model Class Initialized
INFO - 2018-02-22 10:11:19 --> Final output sent to browser
DEBUG - 2018-02-22 10:11:19 --> Total execution time: 0.0118
INFO - 2018-02-22 10:12:17 --> Config Class Initialized
INFO - 2018-02-22 10:12:17 --> Hooks Class Initialized
DEBUG - 2018-02-22 10:12:17 --> UTF-8 Support Enabled
INFO - 2018-02-22 10:12:17 --> Utf8 Class Initialized
INFO - 2018-02-22 10:12:17 --> URI Class Initialized
INFO - 2018-02-22 10:12:17 --> Router Class Initialized
INFO - 2018-02-22 10:12:17 --> Output Class Initialized
INFO - 2018-02-22 10:12:17 --> Security Class Initialized
DEBUG - 2018-02-22 10:12:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-22 10:12:17 --> Input Class Initialized
INFO - 2018-02-22 10:12:17 --> Language Class Initialized
INFO - 2018-02-22 10:12:17 --> Loader Class Initialized
INFO - 2018-02-22 10:12:17 --> Helper loaded: url_helper
INFO - 2018-02-22 10:12:17 --> Helper loaded: file_helper
INFO - 2018-02-22 10:12:17 --> Helper loaded: email_helper
INFO - 2018-02-22 10:12:17 --> Helper loaded: common_helper
INFO - 2018-02-22 10:12:17 --> Database Driver Class Initialized
DEBUG - 2018-02-22 10:12:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-22 10:12:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-22 10:12:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-22 10:12:17 --> Pagination Class Initialized
INFO - 2018-02-22 10:12:17 --> Helper loaded: form_helper
INFO - 2018-02-22 10:12:17 --> Form Validation Class Initialized
INFO - 2018-02-22 10:12:17 --> Model Class Initialized
INFO - 2018-02-22 10:12:17 --> Controller Class Initialized
DEBUG - 2018-02-22 10:12:17 --> Config file loaded: /var/www/html/project/radio/application/config/rest.php
INFO - 2018-02-22 10:12:17 --> Helper loaded: inflector_helper
INFO - 2018-02-22 10:12:17 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-22 10:12:17 --> Model Class Initialized
INFO - 2018-02-22 10:12:17 --> Model Class Initialized
INFO - 2018-02-22 10:12:17 --> Model Class Initialized
INFO - 2018-02-22 10:12:17 --> Model Class Initialized
INFO - 2018-02-22 10:12:17 --> Model Class Initialized
INFO - 2018-02-22 10:12:17 --> Final output sent to browser
DEBUG - 2018-02-22 10:12:17 --> Total execution time: 0.0095
INFO - 2018-02-22 10:12:39 --> Config Class Initialized
INFO - 2018-02-22 10:12:39 --> Hooks Class Initialized
DEBUG - 2018-02-22 10:12:39 --> UTF-8 Support Enabled
INFO - 2018-02-22 10:12:39 --> Utf8 Class Initialized
INFO - 2018-02-22 10:12:39 --> URI Class Initialized
INFO - 2018-02-22 10:12:39 --> Router Class Initialized
INFO - 2018-02-22 10:12:39 --> Output Class Initialized
INFO - 2018-02-22 10:12:39 --> Security Class Initialized
DEBUG - 2018-02-22 10:12:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-22 10:12:39 --> Input Class Initialized
INFO - 2018-02-22 10:12:39 --> Language Class Initialized
INFO - 2018-02-22 10:12:39 --> Loader Class Initialized
INFO - 2018-02-22 10:12:39 --> Helper loaded: url_helper
INFO - 2018-02-22 10:12:39 --> Helper loaded: file_helper
INFO - 2018-02-22 10:12:39 --> Helper loaded: email_helper
INFO - 2018-02-22 10:12:39 --> Helper loaded: common_helper
INFO - 2018-02-22 10:12:39 --> Database Driver Class Initialized
DEBUG - 2018-02-22 10:12:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-22 10:12:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-22 10:12:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-22 10:12:39 --> Pagination Class Initialized
INFO - 2018-02-22 10:12:39 --> Helper loaded: form_helper
INFO - 2018-02-22 10:12:39 --> Form Validation Class Initialized
INFO - 2018-02-22 10:12:39 --> Model Class Initialized
INFO - 2018-02-22 10:12:39 --> Controller Class Initialized
DEBUG - 2018-02-22 10:12:39 --> Config file loaded: /var/www/html/project/radio/application/config/rest.php
INFO - 2018-02-22 10:12:39 --> Helper loaded: inflector_helper
INFO - 2018-02-22 10:12:39 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-22 10:12:39 --> Model Class Initialized
INFO - 2018-02-22 10:12:39 --> Model Class Initialized
INFO - 2018-02-22 10:12:39 --> Model Class Initialized
INFO - 2018-02-22 10:12:39 --> Model Class Initialized
INFO - 2018-02-22 10:12:39 --> Model Class Initialized
INFO - 2018-02-22 10:12:39 --> Final output sent to browser
DEBUG - 2018-02-22 10:12:39 --> Total execution time: 0.0123
INFO - 2018-02-22 11:07:27 --> Config Class Initialized
INFO - 2018-02-22 11:07:27 --> Hooks Class Initialized
DEBUG - 2018-02-22 11:07:27 --> UTF-8 Support Enabled
INFO - 2018-02-22 11:07:27 --> Utf8 Class Initialized
INFO - 2018-02-22 11:07:27 --> URI Class Initialized
INFO - 2018-02-22 11:07:27 --> Router Class Initialized
INFO - 2018-02-22 11:07:27 --> Output Class Initialized
INFO - 2018-02-22 11:07:27 --> Security Class Initialized
DEBUG - 2018-02-22 11:07:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-22 11:07:27 --> Input Class Initialized
INFO - 2018-02-22 11:07:27 --> Language Class Initialized
INFO - 2018-02-22 11:07:27 --> Loader Class Initialized
INFO - 2018-02-22 11:07:27 --> Helper loaded: url_helper
INFO - 2018-02-22 11:07:27 --> Helper loaded: file_helper
INFO - 2018-02-22 11:07:27 --> Helper loaded: email_helper
INFO - 2018-02-22 11:07:27 --> Helper loaded: common_helper
INFO - 2018-02-22 11:07:27 --> Database Driver Class Initialized
DEBUG - 2018-02-22 11:07:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-22 11:07:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-22 11:07:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-22 11:07:27 --> Pagination Class Initialized
INFO - 2018-02-22 11:07:27 --> Helper loaded: form_helper
INFO - 2018-02-22 11:07:27 --> Form Validation Class Initialized
INFO - 2018-02-22 11:07:27 --> Model Class Initialized
INFO - 2018-02-22 11:07:27 --> Controller Class Initialized
DEBUG - 2018-02-22 11:07:27 --> Config file loaded: /var/www/html/project/radio/application/config/rest.php
INFO - 2018-02-22 11:07:27 --> Helper loaded: inflector_helper
INFO - 2018-02-22 11:07:27 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-22 11:07:27 --> Model Class Initialized
INFO - 2018-02-22 11:07:27 --> Model Class Initialized
INFO - 2018-02-22 11:07:27 --> Model Class Initialized
INFO - 2018-02-22 11:07:27 --> Model Class Initialized
INFO - 2018-02-22 11:07:27 --> Model Class Initialized
INFO - 2018-02-22 11:07:27 --> Final output sent to browser
DEBUG - 2018-02-22 11:07:27 --> Total execution time: 0.0080
INFO - 2018-02-22 11:26:09 --> Config Class Initialized
INFO - 2018-02-22 11:26:09 --> Hooks Class Initialized
DEBUG - 2018-02-22 11:26:09 --> UTF-8 Support Enabled
INFO - 2018-02-22 11:26:09 --> Utf8 Class Initialized
INFO - 2018-02-22 11:26:09 --> URI Class Initialized
INFO - 2018-02-22 11:26:09 --> Router Class Initialized
INFO - 2018-02-22 11:26:09 --> Output Class Initialized
INFO - 2018-02-22 11:26:09 --> Security Class Initialized
DEBUG - 2018-02-22 11:26:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-22 11:26:09 --> Input Class Initialized
INFO - 2018-02-22 11:26:09 --> Language Class Initialized
INFO - 2018-02-22 11:26:09 --> Loader Class Initialized
INFO - 2018-02-22 11:26:09 --> Helper loaded: url_helper
INFO - 2018-02-22 11:26:09 --> Helper loaded: file_helper
INFO - 2018-02-22 11:26:09 --> Helper loaded: email_helper
INFO - 2018-02-22 11:26:09 --> Helper loaded: common_helper
INFO - 2018-02-22 11:26:09 --> Database Driver Class Initialized
DEBUG - 2018-02-22 11:26:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-22 11:26:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-22 11:26:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-22 11:26:09 --> Pagination Class Initialized
INFO - 2018-02-22 11:26:09 --> Helper loaded: form_helper
INFO - 2018-02-22 11:26:09 --> Form Validation Class Initialized
INFO - 2018-02-22 11:26:09 --> Model Class Initialized
INFO - 2018-02-22 11:26:09 --> Controller Class Initialized
DEBUG - 2018-02-22 11:26:09 --> Config file loaded: /var/www/html/project/radio/application/config/rest.php
INFO - 2018-02-22 11:26:09 --> Helper loaded: inflector_helper
INFO - 2018-02-22 11:26:09 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-22 11:26:09 --> Model Class Initialized
INFO - 2018-02-22 11:26:09 --> Model Class Initialized
INFO - 2018-02-22 11:26:09 --> Model Class Initialized
INFO - 2018-02-22 11:26:09 --> Model Class Initialized
INFO - 2018-02-22 11:26:09 --> Model Class Initialized
INFO - 2018-02-22 11:26:09 --> Model Class Initialized
INFO - 2018-02-22 11:26:09 --> Final output sent to browser
DEBUG - 2018-02-22 11:26:09 --> Total execution time: 0.0060
INFO - 2018-02-22 11:26:44 --> Config Class Initialized
INFO - 2018-02-22 11:26:44 --> Hooks Class Initialized
DEBUG - 2018-02-22 11:26:44 --> UTF-8 Support Enabled
INFO - 2018-02-22 11:26:44 --> Utf8 Class Initialized
INFO - 2018-02-22 11:26:44 --> URI Class Initialized
INFO - 2018-02-22 11:26:44 --> Router Class Initialized
INFO - 2018-02-22 11:26:44 --> Output Class Initialized
INFO - 2018-02-22 11:26:44 --> Security Class Initialized
DEBUG - 2018-02-22 11:26:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-22 11:26:44 --> Input Class Initialized
INFO - 2018-02-22 11:26:44 --> Language Class Initialized
INFO - 2018-02-22 11:26:44 --> Loader Class Initialized
INFO - 2018-02-22 11:26:44 --> Helper loaded: url_helper
INFO - 2018-02-22 11:26:44 --> Helper loaded: file_helper
INFO - 2018-02-22 11:26:44 --> Helper loaded: email_helper
INFO - 2018-02-22 11:26:44 --> Helper loaded: common_helper
INFO - 2018-02-22 11:26:44 --> Database Driver Class Initialized
DEBUG - 2018-02-22 11:26:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-22 11:26:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-22 11:26:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-22 11:26:44 --> Pagination Class Initialized
INFO - 2018-02-22 11:26:44 --> Helper loaded: form_helper
INFO - 2018-02-22 11:26:44 --> Form Validation Class Initialized
INFO - 2018-02-22 11:26:44 --> Model Class Initialized
INFO - 2018-02-22 11:26:44 --> Controller Class Initialized
DEBUG - 2018-02-22 11:26:44 --> Config file loaded: /var/www/html/project/radio/application/config/rest.php
INFO - 2018-02-22 11:26:44 --> Helper loaded: inflector_helper
INFO - 2018-02-22 11:26:44 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-22 11:26:44 --> Model Class Initialized
INFO - 2018-02-22 11:26:44 --> Model Class Initialized
INFO - 2018-02-22 11:26:44 --> Model Class Initialized
INFO - 2018-02-22 11:26:44 --> Model Class Initialized
INFO - 2018-02-22 11:26:44 --> Model Class Initialized
INFO - 2018-02-22 11:26:44 --> Model Class Initialized
INFO - 2018-02-22 11:26:44 --> Final output sent to browser
DEBUG - 2018-02-22 11:26:44 --> Total execution time: 0.0401
INFO - 2018-02-22 11:26:46 --> Config Class Initialized
INFO - 2018-02-22 11:26:46 --> Hooks Class Initialized
DEBUG - 2018-02-22 11:26:46 --> UTF-8 Support Enabled
INFO - 2018-02-22 11:26:46 --> Utf8 Class Initialized
INFO - 2018-02-22 11:26:46 --> URI Class Initialized
INFO - 2018-02-22 11:26:46 --> Router Class Initialized
INFO - 2018-02-22 11:26:46 --> Output Class Initialized
INFO - 2018-02-22 11:26:46 --> Security Class Initialized
DEBUG - 2018-02-22 11:26:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-22 11:26:46 --> Input Class Initialized
INFO - 2018-02-22 11:26:46 --> Language Class Initialized
INFO - 2018-02-22 11:26:46 --> Loader Class Initialized
INFO - 2018-02-22 11:26:46 --> Helper loaded: url_helper
INFO - 2018-02-22 11:26:46 --> Helper loaded: file_helper
INFO - 2018-02-22 11:26:46 --> Helper loaded: email_helper
INFO - 2018-02-22 11:26:46 --> Helper loaded: common_helper
INFO - 2018-02-22 11:26:46 --> Database Driver Class Initialized
DEBUG - 2018-02-22 11:26:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-22 11:26:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-22 11:26:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-22 11:26:46 --> Pagination Class Initialized
INFO - 2018-02-22 11:26:46 --> Helper loaded: form_helper
INFO - 2018-02-22 11:26:46 --> Form Validation Class Initialized
INFO - 2018-02-22 11:26:46 --> Model Class Initialized
INFO - 2018-02-22 11:26:46 --> Controller Class Initialized
DEBUG - 2018-02-22 11:26:46 --> Config file loaded: /var/www/html/project/radio/application/config/rest.php
INFO - 2018-02-22 11:26:46 --> Helper loaded: inflector_helper
INFO - 2018-02-22 11:26:46 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-22 11:26:46 --> Model Class Initialized
INFO - 2018-02-22 11:26:46 --> Model Class Initialized
INFO - 2018-02-22 11:26:46 --> Model Class Initialized
INFO - 2018-02-22 11:26:46 --> Model Class Initialized
INFO - 2018-02-22 11:26:46 --> Model Class Initialized
INFO - 2018-02-22 11:26:46 --> Model Class Initialized
INFO - 2018-02-22 11:26:46 --> Final output sent to browser
DEBUG - 2018-02-22 11:26:46 --> Total execution time: 0.0055
INFO - 2018-02-22 11:26:51 --> Config Class Initialized
INFO - 2018-02-22 11:26:51 --> Hooks Class Initialized
DEBUG - 2018-02-22 11:26:51 --> UTF-8 Support Enabled
INFO - 2018-02-22 11:26:51 --> Utf8 Class Initialized
INFO - 2018-02-22 11:26:51 --> URI Class Initialized
INFO - 2018-02-22 11:26:51 --> Router Class Initialized
INFO - 2018-02-22 11:26:51 --> Output Class Initialized
INFO - 2018-02-22 11:26:51 --> Security Class Initialized
DEBUG - 2018-02-22 11:26:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-22 11:26:51 --> Input Class Initialized
INFO - 2018-02-22 11:26:51 --> Language Class Initialized
INFO - 2018-02-22 11:26:51 --> Loader Class Initialized
INFO - 2018-02-22 11:26:51 --> Helper loaded: url_helper
INFO - 2018-02-22 11:26:51 --> Helper loaded: file_helper
INFO - 2018-02-22 11:26:51 --> Helper loaded: email_helper
INFO - 2018-02-22 11:26:51 --> Helper loaded: common_helper
INFO - 2018-02-22 11:26:51 --> Database Driver Class Initialized
DEBUG - 2018-02-22 11:26:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-22 11:26:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-22 11:26:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-22 11:26:51 --> Pagination Class Initialized
INFO - 2018-02-22 11:26:51 --> Helper loaded: form_helper
INFO - 2018-02-22 11:26:51 --> Form Validation Class Initialized
INFO - 2018-02-22 11:26:51 --> Model Class Initialized
INFO - 2018-02-22 11:26:51 --> Controller Class Initialized
DEBUG - 2018-02-22 11:26:51 --> Config file loaded: /var/www/html/project/radio/application/config/rest.php
INFO - 2018-02-22 11:26:51 --> Helper loaded: inflector_helper
INFO - 2018-02-22 11:26:51 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-22 11:26:51 --> Model Class Initialized
INFO - 2018-02-22 11:26:51 --> Model Class Initialized
INFO - 2018-02-22 11:26:51 --> Model Class Initialized
INFO - 2018-02-22 11:26:51 --> Model Class Initialized
INFO - 2018-02-22 11:26:51 --> Model Class Initialized
INFO - 2018-02-22 11:26:51 --> Model Class Initialized
INFO - 2018-02-22 11:26:51 --> Final output sent to browser
DEBUG - 2018-02-22 11:26:51 --> Total execution time: 0.0475
INFO - 2018-02-22 11:27:16 --> Config Class Initialized
INFO - 2018-02-22 11:27:16 --> Hooks Class Initialized
DEBUG - 2018-02-22 11:27:16 --> UTF-8 Support Enabled
INFO - 2018-02-22 11:27:16 --> Utf8 Class Initialized
INFO - 2018-02-22 11:27:16 --> URI Class Initialized
INFO - 2018-02-22 11:27:16 --> Router Class Initialized
INFO - 2018-02-22 11:27:16 --> Output Class Initialized
INFO - 2018-02-22 11:27:16 --> Security Class Initialized
DEBUG - 2018-02-22 11:27:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-22 11:27:16 --> Input Class Initialized
INFO - 2018-02-22 11:27:16 --> Language Class Initialized
INFO - 2018-02-22 11:27:16 --> Loader Class Initialized
INFO - 2018-02-22 11:27:16 --> Helper loaded: url_helper
INFO - 2018-02-22 11:27:16 --> Helper loaded: file_helper
INFO - 2018-02-22 11:27:16 --> Helper loaded: email_helper
INFO - 2018-02-22 11:27:16 --> Helper loaded: common_helper
INFO - 2018-02-22 11:27:16 --> Database Driver Class Initialized
DEBUG - 2018-02-22 11:27:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-22 11:27:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-22 11:27:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-22 11:27:16 --> Pagination Class Initialized
INFO - 2018-02-22 11:27:16 --> Helper loaded: form_helper
INFO - 2018-02-22 11:27:16 --> Form Validation Class Initialized
INFO - 2018-02-22 11:27:16 --> Model Class Initialized
INFO - 2018-02-22 11:27:16 --> Controller Class Initialized
DEBUG - 2018-02-22 11:27:16 --> Config file loaded: /var/www/html/project/radio/application/config/rest.php
INFO - 2018-02-22 11:27:16 --> Helper loaded: inflector_helper
INFO - 2018-02-22 11:27:16 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-22 11:27:16 --> Model Class Initialized
INFO - 2018-02-22 11:27:16 --> Model Class Initialized
INFO - 2018-02-22 11:27:16 --> Model Class Initialized
INFO - 2018-02-22 11:27:16 --> Model Class Initialized
INFO - 2018-02-22 11:27:16 --> Model Class Initialized
INFO - 2018-02-22 11:27:16 --> Model Class Initialized
INFO - 2018-02-22 11:27:16 --> Final output sent to browser
DEBUG - 2018-02-22 11:27:16 --> Total execution time: 0.0063
INFO - 2018-02-22 11:27:57 --> Config Class Initialized
INFO - 2018-02-22 11:27:57 --> Hooks Class Initialized
DEBUG - 2018-02-22 11:27:57 --> UTF-8 Support Enabled
INFO - 2018-02-22 11:27:57 --> Utf8 Class Initialized
INFO - 2018-02-22 11:27:57 --> URI Class Initialized
INFO - 2018-02-22 11:27:57 --> Router Class Initialized
INFO - 2018-02-22 11:27:57 --> Output Class Initialized
INFO - 2018-02-22 11:27:57 --> Security Class Initialized
DEBUG - 2018-02-22 11:27:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-22 11:27:57 --> Input Class Initialized
INFO - 2018-02-22 11:27:57 --> Language Class Initialized
INFO - 2018-02-22 11:27:57 --> Loader Class Initialized
INFO - 2018-02-22 11:27:57 --> Helper loaded: url_helper
INFO - 2018-02-22 11:27:57 --> Helper loaded: file_helper
INFO - 2018-02-22 11:27:57 --> Helper loaded: email_helper
INFO - 2018-02-22 11:27:57 --> Helper loaded: common_helper
INFO - 2018-02-22 11:27:57 --> Database Driver Class Initialized
DEBUG - 2018-02-22 11:27:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-22 11:27:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-22 11:27:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-22 11:27:57 --> Pagination Class Initialized
INFO - 2018-02-22 11:27:57 --> Helper loaded: form_helper
INFO - 2018-02-22 11:27:57 --> Form Validation Class Initialized
INFO - 2018-02-22 11:27:57 --> Model Class Initialized
INFO - 2018-02-22 11:27:57 --> Controller Class Initialized
DEBUG - 2018-02-22 11:27:57 --> Config file loaded: /var/www/html/project/radio/application/config/rest.php
INFO - 2018-02-22 11:27:57 --> Helper loaded: inflector_helper
INFO - 2018-02-22 11:27:57 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-22 11:27:57 --> Model Class Initialized
INFO - 2018-02-22 11:27:57 --> Model Class Initialized
INFO - 2018-02-22 11:27:57 --> Model Class Initialized
INFO - 2018-02-22 11:27:57 --> Model Class Initialized
INFO - 2018-02-22 11:27:57 --> Model Class Initialized
INFO - 2018-02-22 11:27:57 --> Model Class Initialized
INFO - 2018-02-22 11:27:57 --> Final output sent to browser
DEBUG - 2018-02-22 11:27:57 --> Total execution time: 0.0057
INFO - 2018-02-22 11:28:10 --> Config Class Initialized
INFO - 2018-02-22 11:28:10 --> Hooks Class Initialized
DEBUG - 2018-02-22 11:28:10 --> UTF-8 Support Enabled
INFO - 2018-02-22 11:28:10 --> Utf8 Class Initialized
INFO - 2018-02-22 11:28:10 --> URI Class Initialized
INFO - 2018-02-22 11:28:10 --> Router Class Initialized
INFO - 2018-02-22 11:28:10 --> Output Class Initialized
INFO - 2018-02-22 11:28:10 --> Security Class Initialized
DEBUG - 2018-02-22 11:28:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-22 11:28:10 --> Input Class Initialized
INFO - 2018-02-22 11:28:10 --> Language Class Initialized
INFO - 2018-02-22 11:28:10 --> Loader Class Initialized
INFO - 2018-02-22 11:28:10 --> Helper loaded: url_helper
INFO - 2018-02-22 11:28:10 --> Helper loaded: file_helper
INFO - 2018-02-22 11:28:10 --> Helper loaded: email_helper
INFO - 2018-02-22 11:28:10 --> Helper loaded: common_helper
INFO - 2018-02-22 11:28:10 --> Database Driver Class Initialized
DEBUG - 2018-02-22 11:28:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-22 11:28:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-22 11:28:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-22 11:28:10 --> Pagination Class Initialized
INFO - 2018-02-22 11:28:10 --> Helper loaded: form_helper
INFO - 2018-02-22 11:28:10 --> Form Validation Class Initialized
INFO - 2018-02-22 11:28:10 --> Model Class Initialized
INFO - 2018-02-22 11:28:10 --> Controller Class Initialized
DEBUG - 2018-02-22 11:28:10 --> Config file loaded: /var/www/html/project/radio/application/config/rest.php
INFO - 2018-02-22 11:28:10 --> Helper loaded: inflector_helper
INFO - 2018-02-22 11:28:10 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-22 11:28:10 --> Model Class Initialized
INFO - 2018-02-22 11:28:10 --> Model Class Initialized
INFO - 2018-02-22 11:28:10 --> Model Class Initialized
INFO - 2018-02-22 11:28:10 --> Model Class Initialized
INFO - 2018-02-22 11:28:10 --> Model Class Initialized
INFO - 2018-02-22 11:28:10 --> Model Class Initialized
INFO - 2018-02-22 11:28:11 --> Final output sent to browser
DEBUG - 2018-02-22 11:28:11 --> Total execution time: 0.0544
INFO - 2018-02-22 11:28:22 --> Config Class Initialized
INFO - 2018-02-22 11:28:22 --> Hooks Class Initialized
DEBUG - 2018-02-22 11:28:22 --> UTF-8 Support Enabled
INFO - 2018-02-22 11:28:22 --> Utf8 Class Initialized
INFO - 2018-02-22 11:28:22 --> URI Class Initialized
INFO - 2018-02-22 11:28:22 --> Router Class Initialized
INFO - 2018-02-22 11:28:22 --> Output Class Initialized
INFO - 2018-02-22 11:28:22 --> Security Class Initialized
DEBUG - 2018-02-22 11:28:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-22 11:28:22 --> Input Class Initialized
INFO - 2018-02-22 11:28:22 --> Language Class Initialized
INFO - 2018-02-22 11:28:22 --> Loader Class Initialized
INFO - 2018-02-22 11:28:22 --> Helper loaded: url_helper
INFO - 2018-02-22 11:28:22 --> Helper loaded: file_helper
INFO - 2018-02-22 11:28:22 --> Helper loaded: email_helper
INFO - 2018-02-22 11:28:22 --> Helper loaded: common_helper
INFO - 2018-02-22 11:28:22 --> Database Driver Class Initialized
DEBUG - 2018-02-22 11:28:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-22 11:28:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-22 11:28:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-22 11:28:22 --> Pagination Class Initialized
INFO - 2018-02-22 11:28:22 --> Helper loaded: form_helper
INFO - 2018-02-22 11:28:22 --> Form Validation Class Initialized
INFO - 2018-02-22 11:28:22 --> Model Class Initialized
INFO - 2018-02-22 11:28:22 --> Controller Class Initialized
DEBUG - 2018-02-22 11:28:22 --> Config file loaded: /var/www/html/project/radio/application/config/rest.php
INFO - 2018-02-22 11:28:22 --> Helper loaded: inflector_helper
INFO - 2018-02-22 11:28:22 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-22 11:28:22 --> Model Class Initialized
INFO - 2018-02-22 11:28:22 --> Model Class Initialized
INFO - 2018-02-22 11:28:22 --> Model Class Initialized
INFO - 2018-02-22 11:28:22 --> Model Class Initialized
INFO - 2018-02-22 11:28:22 --> Model Class Initialized
INFO - 2018-02-22 11:28:22 --> Model Class Initialized
INFO - 2018-02-22 11:28:22 --> Final output sent to browser
DEBUG - 2018-02-22 11:28:22 --> Total execution time: 0.0069
INFO - 2018-02-22 11:39:10 --> Config Class Initialized
INFO - 2018-02-22 11:39:10 --> Hooks Class Initialized
DEBUG - 2018-02-22 11:39:10 --> UTF-8 Support Enabled
INFO - 2018-02-22 11:39:10 --> Utf8 Class Initialized
INFO - 2018-02-22 11:39:10 --> URI Class Initialized
INFO - 2018-02-22 11:39:10 --> Router Class Initialized
INFO - 2018-02-22 11:39:10 --> Output Class Initialized
INFO - 2018-02-22 11:39:10 --> Security Class Initialized
DEBUG - 2018-02-22 11:39:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-22 11:39:10 --> Input Class Initialized
INFO - 2018-02-22 11:39:10 --> Language Class Initialized
INFO - 2018-02-22 11:39:10 --> Loader Class Initialized
INFO - 2018-02-22 11:39:10 --> Helper loaded: url_helper
INFO - 2018-02-22 11:39:10 --> Helper loaded: file_helper
INFO - 2018-02-22 11:39:10 --> Helper loaded: email_helper
INFO - 2018-02-22 11:39:10 --> Helper loaded: common_helper
INFO - 2018-02-22 11:39:10 --> Database Driver Class Initialized
DEBUG - 2018-02-22 11:39:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-22 11:39:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-22 11:39:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-22 11:39:10 --> Pagination Class Initialized
INFO - 2018-02-22 11:39:10 --> Helper loaded: form_helper
INFO - 2018-02-22 11:39:10 --> Form Validation Class Initialized
INFO - 2018-02-22 11:39:10 --> Model Class Initialized
INFO - 2018-02-22 11:39:10 --> Controller Class Initialized
DEBUG - 2018-02-22 11:39:10 --> Config file loaded: /var/www/html/project/radio/application/config/rest.php
INFO - 2018-02-22 11:39:10 --> Helper loaded: inflector_helper
INFO - 2018-02-22 11:39:10 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-22 11:39:10 --> Model Class Initialized
INFO - 2018-02-22 11:39:10 --> Model Class Initialized
INFO - 2018-02-22 11:39:10 --> Model Class Initialized
INFO - 2018-02-22 11:39:10 --> Model Class Initialized
INFO - 2018-02-22 11:39:10 --> Model Class Initialized
INFO - 2018-02-22 11:39:10 --> Final output sent to browser
DEBUG - 2018-02-22 11:39:10 --> Total execution time: 0.0062
INFO - 2018-02-22 11:41:14 --> Config Class Initialized
INFO - 2018-02-22 11:41:14 --> Hooks Class Initialized
DEBUG - 2018-02-22 11:41:14 --> UTF-8 Support Enabled
INFO - 2018-02-22 11:41:14 --> Utf8 Class Initialized
INFO - 2018-02-22 11:41:14 --> URI Class Initialized
INFO - 2018-02-22 11:41:14 --> Router Class Initialized
INFO - 2018-02-22 11:41:14 --> Output Class Initialized
INFO - 2018-02-22 11:41:14 --> Security Class Initialized
DEBUG - 2018-02-22 11:41:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-22 11:41:14 --> Input Class Initialized
INFO - 2018-02-22 11:41:14 --> Language Class Initialized
INFO - 2018-02-22 11:41:14 --> Loader Class Initialized
INFO - 2018-02-22 11:41:14 --> Helper loaded: url_helper
INFO - 2018-02-22 11:41:14 --> Helper loaded: file_helper
INFO - 2018-02-22 11:41:14 --> Helper loaded: email_helper
INFO - 2018-02-22 11:41:14 --> Helper loaded: common_helper
INFO - 2018-02-22 11:41:14 --> Database Driver Class Initialized
DEBUG - 2018-02-22 11:41:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-22 11:41:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-22 11:41:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-22 11:41:14 --> Pagination Class Initialized
INFO - 2018-02-22 11:41:14 --> Helper loaded: form_helper
INFO - 2018-02-22 11:41:14 --> Form Validation Class Initialized
INFO - 2018-02-22 11:41:14 --> Model Class Initialized
INFO - 2018-02-22 11:41:14 --> Controller Class Initialized
DEBUG - 2018-02-22 11:41:14 --> Config file loaded: /var/www/html/project/radio/application/config/rest.php
INFO - 2018-02-22 11:41:14 --> Helper loaded: inflector_helper
INFO - 2018-02-22 11:41:14 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-22 11:41:14 --> Model Class Initialized
INFO - 2018-02-22 11:41:14 --> Model Class Initialized
INFO - 2018-02-22 11:41:14 --> Model Class Initialized
INFO - 2018-02-22 11:41:14 --> Model Class Initialized
INFO - 2018-02-22 11:41:14 --> Model Class Initialized
INFO - 2018-02-22 11:41:14 --> Final output sent to browser
DEBUG - 2018-02-22 11:41:14 --> Total execution time: 0.0059
INFO - 2018-02-22 11:42:04 --> Config Class Initialized
INFO - 2018-02-22 11:42:04 --> Hooks Class Initialized
DEBUG - 2018-02-22 11:42:04 --> UTF-8 Support Enabled
INFO - 2018-02-22 11:42:04 --> Utf8 Class Initialized
INFO - 2018-02-22 11:42:04 --> URI Class Initialized
INFO - 2018-02-22 11:42:04 --> Router Class Initialized
INFO - 2018-02-22 11:42:04 --> Output Class Initialized
INFO - 2018-02-22 11:42:04 --> Security Class Initialized
DEBUG - 2018-02-22 11:42:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-22 11:42:04 --> Input Class Initialized
INFO - 2018-02-22 11:42:04 --> Language Class Initialized
INFO - 2018-02-22 11:42:04 --> Loader Class Initialized
INFO - 2018-02-22 11:42:04 --> Helper loaded: url_helper
INFO - 2018-02-22 11:42:04 --> Helper loaded: file_helper
INFO - 2018-02-22 11:42:04 --> Helper loaded: email_helper
INFO - 2018-02-22 11:42:04 --> Helper loaded: common_helper
INFO - 2018-02-22 11:42:04 --> Database Driver Class Initialized
DEBUG - 2018-02-22 11:42:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-22 11:42:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-22 11:42:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-22 11:42:04 --> Pagination Class Initialized
INFO - 2018-02-22 11:42:04 --> Helper loaded: form_helper
INFO - 2018-02-22 11:42:04 --> Form Validation Class Initialized
INFO - 2018-02-22 11:42:04 --> Model Class Initialized
INFO - 2018-02-22 11:42:04 --> Controller Class Initialized
DEBUG - 2018-02-22 11:42:04 --> Config file loaded: /var/www/html/project/radio/application/config/rest.php
INFO - 2018-02-22 11:42:04 --> Helper loaded: inflector_helper
INFO - 2018-02-22 11:42:04 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-22 11:42:04 --> Model Class Initialized
INFO - 2018-02-22 11:42:04 --> Model Class Initialized
INFO - 2018-02-22 11:42:04 --> Model Class Initialized
INFO - 2018-02-22 11:42:04 --> Model Class Initialized
INFO - 2018-02-22 11:42:04 --> Model Class Initialized
INFO - 2018-02-22 11:42:05 --> Final output sent to browser
DEBUG - 2018-02-22 11:42:05 --> Total execution time: 0.0068
INFO - 2018-02-22 13:00:57 --> Config Class Initialized
INFO - 2018-02-22 13:00:57 --> Hooks Class Initialized
DEBUG - 2018-02-22 13:00:57 --> UTF-8 Support Enabled
INFO - 2018-02-22 13:00:57 --> Utf8 Class Initialized
INFO - 2018-02-22 13:00:57 --> URI Class Initialized
INFO - 2018-02-22 13:00:57 --> Router Class Initialized
INFO - 2018-02-22 13:00:57 --> Output Class Initialized
INFO - 2018-02-22 13:00:57 --> Security Class Initialized
DEBUG - 2018-02-22 13:00:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-22 13:00:57 --> Input Class Initialized
INFO - 2018-02-22 13:00:57 --> Language Class Initialized
ERROR - 2018-02-22 13:00:57 --> Severity: error --> Exception: syntax error, unexpected '}' /var/www/html/project/radio/application/controllers/api/Fetchappdata.php 239
INFO - 2018-02-22 13:02:13 --> Config Class Initialized
INFO - 2018-02-22 13:02:13 --> Hooks Class Initialized
DEBUG - 2018-02-22 13:02:13 --> UTF-8 Support Enabled
INFO - 2018-02-22 13:02:13 --> Utf8 Class Initialized
INFO - 2018-02-22 13:02:13 --> URI Class Initialized
INFO - 2018-02-22 13:02:13 --> Router Class Initialized
INFO - 2018-02-22 13:02:13 --> Output Class Initialized
INFO - 2018-02-22 13:02:13 --> Security Class Initialized
DEBUG - 2018-02-22 13:02:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-22 13:02:13 --> Input Class Initialized
INFO - 2018-02-22 13:02:13 --> Language Class Initialized
INFO - 2018-02-22 13:02:13 --> Loader Class Initialized
INFO - 2018-02-22 13:02:13 --> Helper loaded: url_helper
INFO - 2018-02-22 13:02:13 --> Helper loaded: file_helper
INFO - 2018-02-22 13:02:13 --> Helper loaded: email_helper
INFO - 2018-02-22 13:02:13 --> Helper loaded: common_helper
INFO - 2018-02-22 13:02:13 --> Database Driver Class Initialized
DEBUG - 2018-02-22 13:02:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-22 13:02:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-22 13:02:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-22 13:02:13 --> Pagination Class Initialized
INFO - 2018-02-22 13:02:13 --> Helper loaded: form_helper
INFO - 2018-02-22 13:02:13 --> Form Validation Class Initialized
INFO - 2018-02-22 13:02:13 --> Model Class Initialized
INFO - 2018-02-22 13:02:13 --> Controller Class Initialized
DEBUG - 2018-02-22 13:02:13 --> Config file loaded: /var/www/html/project/radio/application/config/rest.php
INFO - 2018-02-22 13:02:13 --> Helper loaded: inflector_helper
INFO - 2018-02-22 13:02:13 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-22 13:02:13 --> Model Class Initialized
INFO - 2018-02-22 13:02:13 --> Model Class Initialized
INFO - 2018-02-22 13:02:13 --> Model Class Initialized
INFO - 2018-02-22 13:02:13 --> Model Class Initialized
INFO - 2018-02-22 13:02:13 --> Model Class Initialized
INFO - 2018-02-22 13:02:13 --> Model Class Initialized
INFO - 2018-02-22 13:02:13 --> Final output sent to browser
DEBUG - 2018-02-22 13:02:13 --> Total execution time: 0.0122
INFO - 2018-02-22 13:03:56 --> Config Class Initialized
INFO - 2018-02-22 13:03:56 --> Hooks Class Initialized
DEBUG - 2018-02-22 13:03:56 --> UTF-8 Support Enabled
INFO - 2018-02-22 13:03:56 --> Utf8 Class Initialized
INFO - 2018-02-22 13:03:56 --> URI Class Initialized
INFO - 2018-02-22 13:03:56 --> Router Class Initialized
INFO - 2018-02-22 13:03:56 --> Output Class Initialized
INFO - 2018-02-22 13:03:56 --> Security Class Initialized
DEBUG - 2018-02-22 13:03:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-22 13:03:56 --> Input Class Initialized
INFO - 2018-02-22 13:03:56 --> Language Class Initialized
INFO - 2018-02-22 13:03:56 --> Loader Class Initialized
INFO - 2018-02-22 13:03:56 --> Helper loaded: url_helper
INFO - 2018-02-22 13:03:56 --> Helper loaded: file_helper
INFO - 2018-02-22 13:03:56 --> Helper loaded: email_helper
INFO - 2018-02-22 13:03:56 --> Helper loaded: common_helper
INFO - 2018-02-22 13:03:56 --> Database Driver Class Initialized
DEBUG - 2018-02-22 13:03:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-22 13:03:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-22 13:03:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-22 13:03:56 --> Pagination Class Initialized
INFO - 2018-02-22 13:03:56 --> Helper loaded: form_helper
INFO - 2018-02-22 13:03:56 --> Form Validation Class Initialized
INFO - 2018-02-22 13:03:56 --> Model Class Initialized
INFO - 2018-02-22 13:03:56 --> Controller Class Initialized
DEBUG - 2018-02-22 13:03:56 --> Config file loaded: /var/www/html/project/radio/application/config/rest.php
INFO - 2018-02-22 13:03:56 --> Helper loaded: inflector_helper
INFO - 2018-02-22 13:03:56 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-22 13:03:56 --> Model Class Initialized
INFO - 2018-02-22 13:03:56 --> Model Class Initialized
INFO - 2018-02-22 13:03:56 --> Model Class Initialized
INFO - 2018-02-22 13:03:56 --> Model Class Initialized
INFO - 2018-02-22 13:03:56 --> Model Class Initialized
INFO - 2018-02-22 13:03:56 --> Model Class Initialized
INFO - 2018-02-22 13:03:56 --> Final output sent to browser
DEBUG - 2018-02-22 13:03:56 --> Total execution time: 0.0063
INFO - 2018-02-22 13:04:23 --> Config Class Initialized
INFO - 2018-02-22 13:04:23 --> Hooks Class Initialized
DEBUG - 2018-02-22 13:04:23 --> UTF-8 Support Enabled
INFO - 2018-02-22 13:04:23 --> Utf8 Class Initialized
INFO - 2018-02-22 13:04:23 --> URI Class Initialized
INFO - 2018-02-22 13:04:23 --> Router Class Initialized
INFO - 2018-02-22 13:04:23 --> Output Class Initialized
INFO - 2018-02-22 13:04:23 --> Security Class Initialized
DEBUG - 2018-02-22 13:04:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-22 13:04:23 --> Input Class Initialized
INFO - 2018-02-22 13:04:23 --> Language Class Initialized
INFO - 2018-02-22 13:04:23 --> Loader Class Initialized
INFO - 2018-02-22 13:04:23 --> Helper loaded: url_helper
INFO - 2018-02-22 13:04:23 --> Helper loaded: file_helper
INFO - 2018-02-22 13:04:23 --> Helper loaded: email_helper
INFO - 2018-02-22 13:04:23 --> Helper loaded: common_helper
INFO - 2018-02-22 13:04:23 --> Database Driver Class Initialized
DEBUG - 2018-02-22 13:04:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-22 13:04:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-22 13:04:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-22 13:04:23 --> Pagination Class Initialized
INFO - 2018-02-22 13:04:23 --> Helper loaded: form_helper
INFO - 2018-02-22 13:04:23 --> Form Validation Class Initialized
INFO - 2018-02-22 13:04:23 --> Model Class Initialized
INFO - 2018-02-22 13:04:23 --> Controller Class Initialized
DEBUG - 2018-02-22 13:04:23 --> Config file loaded: /var/www/html/project/radio/application/config/rest.php
INFO - 2018-02-22 13:04:23 --> Helper loaded: inflector_helper
INFO - 2018-02-22 13:04:23 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-22 13:04:23 --> Model Class Initialized
INFO - 2018-02-22 13:04:23 --> Model Class Initialized
INFO - 2018-02-22 13:04:23 --> Model Class Initialized
INFO - 2018-02-22 13:04:23 --> Model Class Initialized
INFO - 2018-02-22 13:04:23 --> Model Class Initialized
INFO - 2018-02-22 13:04:23 --> Model Class Initialized
INFO - 2018-02-22 13:04:23 --> Final output sent to browser
DEBUG - 2018-02-22 13:04:23 --> Total execution time: 0.0061
INFO - 2018-02-22 13:04:28 --> Config Class Initialized
INFO - 2018-02-22 13:04:28 --> Hooks Class Initialized
DEBUG - 2018-02-22 13:04:28 --> UTF-8 Support Enabled
INFO - 2018-02-22 13:04:28 --> Utf8 Class Initialized
INFO - 2018-02-22 13:04:28 --> URI Class Initialized
INFO - 2018-02-22 13:04:28 --> Router Class Initialized
INFO - 2018-02-22 13:04:28 --> Output Class Initialized
INFO - 2018-02-22 13:04:28 --> Security Class Initialized
DEBUG - 2018-02-22 13:04:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-22 13:04:28 --> Input Class Initialized
INFO - 2018-02-22 13:04:28 --> Language Class Initialized
INFO - 2018-02-22 13:04:28 --> Loader Class Initialized
INFO - 2018-02-22 13:04:28 --> Helper loaded: url_helper
INFO - 2018-02-22 13:04:28 --> Helper loaded: file_helper
INFO - 2018-02-22 13:04:28 --> Helper loaded: email_helper
INFO - 2018-02-22 13:04:28 --> Helper loaded: common_helper
INFO - 2018-02-22 13:04:28 --> Database Driver Class Initialized
DEBUG - 2018-02-22 13:04:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-22 13:04:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-22 13:04:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-22 13:04:28 --> Pagination Class Initialized
INFO - 2018-02-22 13:04:28 --> Helper loaded: form_helper
INFO - 2018-02-22 13:04:28 --> Form Validation Class Initialized
INFO - 2018-02-22 13:04:28 --> Model Class Initialized
INFO - 2018-02-22 13:04:28 --> Controller Class Initialized
DEBUG - 2018-02-22 13:04:28 --> Config file loaded: /var/www/html/project/radio/application/config/rest.php
INFO - 2018-02-22 13:04:28 --> Helper loaded: inflector_helper
INFO - 2018-02-22 13:04:28 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-22 13:04:28 --> Model Class Initialized
INFO - 2018-02-22 13:04:28 --> Model Class Initialized
INFO - 2018-02-22 13:04:28 --> Model Class Initialized
INFO - 2018-02-22 13:04:28 --> Model Class Initialized
INFO - 2018-02-22 13:04:28 --> Model Class Initialized
INFO - 2018-02-22 13:04:28 --> Model Class Initialized
INFO - 2018-02-22 13:04:28 --> Final output sent to browser
DEBUG - 2018-02-22 13:04:28 --> Total execution time: 0.0076
INFO - 2018-02-22 13:04:35 --> Config Class Initialized
INFO - 2018-02-22 13:04:35 --> Hooks Class Initialized
DEBUG - 2018-02-22 13:04:35 --> UTF-8 Support Enabled
INFO - 2018-02-22 13:04:35 --> Utf8 Class Initialized
INFO - 2018-02-22 13:04:35 --> URI Class Initialized
INFO - 2018-02-22 13:04:35 --> Router Class Initialized
INFO - 2018-02-22 13:04:35 --> Output Class Initialized
INFO - 2018-02-22 13:04:35 --> Security Class Initialized
DEBUG - 2018-02-22 13:04:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-22 13:04:35 --> Input Class Initialized
INFO - 2018-02-22 13:04:35 --> Language Class Initialized
INFO - 2018-02-22 13:04:35 --> Loader Class Initialized
INFO - 2018-02-22 13:04:35 --> Helper loaded: url_helper
INFO - 2018-02-22 13:04:35 --> Helper loaded: file_helper
INFO - 2018-02-22 13:04:35 --> Helper loaded: email_helper
INFO - 2018-02-22 13:04:35 --> Helper loaded: common_helper
INFO - 2018-02-22 13:04:35 --> Database Driver Class Initialized
DEBUG - 2018-02-22 13:04:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-22 13:04:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-22 13:04:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-22 13:04:35 --> Pagination Class Initialized
INFO - 2018-02-22 13:04:35 --> Helper loaded: form_helper
INFO - 2018-02-22 13:04:35 --> Form Validation Class Initialized
INFO - 2018-02-22 13:04:35 --> Model Class Initialized
INFO - 2018-02-22 13:04:35 --> Controller Class Initialized
DEBUG - 2018-02-22 13:04:35 --> Config file loaded: /var/www/html/project/radio/application/config/rest.php
INFO - 2018-02-22 13:04:35 --> Helper loaded: inflector_helper
INFO - 2018-02-22 13:04:35 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-22 13:04:35 --> Model Class Initialized
INFO - 2018-02-22 13:04:35 --> Model Class Initialized
INFO - 2018-02-22 13:04:35 --> Model Class Initialized
INFO - 2018-02-22 13:04:35 --> Model Class Initialized
INFO - 2018-02-22 13:04:35 --> Model Class Initialized
INFO - 2018-02-22 13:04:35 --> Model Class Initialized
INFO - 2018-02-22 13:04:35 --> Final output sent to browser
DEBUG - 2018-02-22 13:04:35 --> Total execution time: 0.0077
INFO - 2018-02-22 13:04:42 --> Config Class Initialized
INFO - 2018-02-22 13:04:42 --> Hooks Class Initialized
DEBUG - 2018-02-22 13:04:42 --> UTF-8 Support Enabled
INFO - 2018-02-22 13:04:42 --> Utf8 Class Initialized
INFO - 2018-02-22 13:04:42 --> URI Class Initialized
INFO - 2018-02-22 13:04:42 --> Router Class Initialized
INFO - 2018-02-22 13:04:42 --> Output Class Initialized
INFO - 2018-02-22 13:04:42 --> Security Class Initialized
DEBUG - 2018-02-22 13:04:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-22 13:04:42 --> Input Class Initialized
INFO - 2018-02-22 13:04:42 --> Language Class Initialized
INFO - 2018-02-22 13:04:42 --> Loader Class Initialized
INFO - 2018-02-22 13:04:42 --> Helper loaded: url_helper
INFO - 2018-02-22 13:04:42 --> Helper loaded: file_helper
INFO - 2018-02-22 13:04:42 --> Helper loaded: email_helper
INFO - 2018-02-22 13:04:42 --> Helper loaded: common_helper
INFO - 2018-02-22 13:04:42 --> Database Driver Class Initialized
DEBUG - 2018-02-22 13:04:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-22 13:04:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-22 13:04:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-22 13:04:42 --> Pagination Class Initialized
INFO - 2018-02-22 13:04:42 --> Helper loaded: form_helper
INFO - 2018-02-22 13:04:42 --> Form Validation Class Initialized
INFO - 2018-02-22 13:04:42 --> Model Class Initialized
INFO - 2018-02-22 13:04:42 --> Controller Class Initialized
DEBUG - 2018-02-22 13:04:42 --> Config file loaded: /var/www/html/project/radio/application/config/rest.php
INFO - 2018-02-22 13:04:42 --> Helper loaded: inflector_helper
INFO - 2018-02-22 13:04:42 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-22 13:04:42 --> Model Class Initialized
INFO - 2018-02-22 13:04:42 --> Model Class Initialized
INFO - 2018-02-22 13:04:42 --> Model Class Initialized
INFO - 2018-02-22 13:04:42 --> Model Class Initialized
INFO - 2018-02-22 13:04:42 --> Model Class Initialized
INFO - 2018-02-22 13:04:42 --> Model Class Initialized
INFO - 2018-02-22 13:04:42 --> Final output sent to browser
DEBUG - 2018-02-22 13:04:42 --> Total execution time: 0.0081
INFO - 2018-02-22 13:58:24 --> Config Class Initialized
INFO - 2018-02-22 13:58:24 --> Hooks Class Initialized
DEBUG - 2018-02-22 13:58:24 --> UTF-8 Support Enabled
INFO - 2018-02-22 13:58:24 --> Utf8 Class Initialized
INFO - 2018-02-22 13:58:24 --> URI Class Initialized
INFO - 2018-02-22 13:58:24 --> Router Class Initialized
INFO - 2018-02-22 13:58:24 --> Output Class Initialized
INFO - 2018-02-22 13:58:24 --> Security Class Initialized
DEBUG - 2018-02-22 13:58:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-22 13:58:24 --> Input Class Initialized
INFO - 2018-02-22 13:58:24 --> Language Class Initialized
INFO - 2018-02-22 13:58:24 --> Loader Class Initialized
INFO - 2018-02-22 13:58:24 --> Helper loaded: url_helper
INFO - 2018-02-22 13:58:24 --> Helper loaded: file_helper
INFO - 2018-02-22 13:58:24 --> Helper loaded: email_helper
INFO - 2018-02-22 13:58:24 --> Helper loaded: common_helper
INFO - 2018-02-22 13:58:24 --> Database Driver Class Initialized
DEBUG - 2018-02-22 13:58:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-22 13:58:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-22 13:58:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-22 13:58:24 --> Pagination Class Initialized
INFO - 2018-02-22 13:58:24 --> Helper loaded: form_helper
INFO - 2018-02-22 13:58:24 --> Form Validation Class Initialized
INFO - 2018-02-22 13:58:24 --> Model Class Initialized
INFO - 2018-02-22 13:58:24 --> Controller Class Initialized
DEBUG - 2018-02-22 13:58:24 --> Config file loaded: /var/www/html/project/radio/application/config/rest.php
INFO - 2018-02-22 13:58:24 --> Helper loaded: inflector_helper
INFO - 2018-02-22 13:58:24 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-22 13:58:24 --> Model Class Initialized
INFO - 2018-02-22 13:58:24 --> Model Class Initialized
INFO - 2018-02-22 13:58:24 --> Model Class Initialized
INFO - 2018-02-22 13:58:24 --> Model Class Initialized
INFO - 2018-02-22 13:58:24 --> Model Class Initialized
INFO - 2018-02-22 13:58:24 --> Model Class Initialized
INFO - 2018-02-22 13:58:24 --> Final output sent to browser
DEBUG - 2018-02-22 13:58:24 --> Total execution time: 0.0081
INFO - 2018-02-22 13:59:41 --> Config Class Initialized
INFO - 2018-02-22 13:59:41 --> Hooks Class Initialized
DEBUG - 2018-02-22 13:59:41 --> UTF-8 Support Enabled
INFO - 2018-02-22 13:59:41 --> Utf8 Class Initialized
INFO - 2018-02-22 13:59:41 --> URI Class Initialized
INFO - 2018-02-22 13:59:41 --> Router Class Initialized
INFO - 2018-02-22 13:59:41 --> Output Class Initialized
INFO - 2018-02-22 13:59:41 --> Security Class Initialized
DEBUG - 2018-02-22 13:59:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-22 13:59:41 --> Input Class Initialized
INFO - 2018-02-22 13:59:41 --> Language Class Initialized
INFO - 2018-02-22 13:59:41 --> Loader Class Initialized
INFO - 2018-02-22 13:59:41 --> Helper loaded: url_helper
INFO - 2018-02-22 13:59:41 --> Helper loaded: file_helper
INFO - 2018-02-22 13:59:41 --> Helper loaded: email_helper
INFO - 2018-02-22 13:59:41 --> Helper loaded: common_helper
INFO - 2018-02-22 13:59:41 --> Database Driver Class Initialized
DEBUG - 2018-02-22 13:59:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-22 13:59:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-22 13:59:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-22 13:59:41 --> Pagination Class Initialized
INFO - 2018-02-22 13:59:41 --> Helper loaded: form_helper
INFO - 2018-02-22 13:59:41 --> Form Validation Class Initialized
INFO - 2018-02-22 13:59:41 --> Model Class Initialized
INFO - 2018-02-22 13:59:41 --> Controller Class Initialized
DEBUG - 2018-02-22 13:59:41 --> Config file loaded: /var/www/html/project/radio/application/config/rest.php
INFO - 2018-02-22 13:59:41 --> Helper loaded: inflector_helper
INFO - 2018-02-22 13:59:41 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-22 13:59:41 --> Model Class Initialized
INFO - 2018-02-22 13:59:41 --> Model Class Initialized
INFO - 2018-02-22 13:59:41 --> Model Class Initialized
INFO - 2018-02-22 13:59:41 --> Model Class Initialized
INFO - 2018-02-22 13:59:41 --> Model Class Initialized
INFO - 2018-02-22 13:59:41 --> Model Class Initialized
INFO - 2018-02-22 13:59:41 --> Final output sent to browser
DEBUG - 2018-02-22 13:59:41 --> Total execution time: 0.0099
INFO - 2018-02-22 13:59:45 --> Config Class Initialized
INFO - 2018-02-22 13:59:45 --> Hooks Class Initialized
DEBUG - 2018-02-22 13:59:45 --> UTF-8 Support Enabled
INFO - 2018-02-22 13:59:45 --> Utf8 Class Initialized
INFO - 2018-02-22 13:59:45 --> URI Class Initialized
INFO - 2018-02-22 13:59:45 --> Router Class Initialized
INFO - 2018-02-22 13:59:45 --> Output Class Initialized
INFO - 2018-02-22 13:59:45 --> Security Class Initialized
DEBUG - 2018-02-22 13:59:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-22 13:59:45 --> Input Class Initialized
INFO - 2018-02-22 13:59:45 --> Language Class Initialized
INFO - 2018-02-22 13:59:45 --> Loader Class Initialized
INFO - 2018-02-22 13:59:45 --> Helper loaded: url_helper
INFO - 2018-02-22 13:59:45 --> Helper loaded: file_helper
INFO - 2018-02-22 13:59:45 --> Helper loaded: email_helper
INFO - 2018-02-22 13:59:45 --> Helper loaded: common_helper
INFO - 2018-02-22 13:59:45 --> Database Driver Class Initialized
DEBUG - 2018-02-22 13:59:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-22 13:59:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-22 13:59:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-22 13:59:45 --> Pagination Class Initialized
INFO - 2018-02-22 13:59:45 --> Helper loaded: form_helper
INFO - 2018-02-22 13:59:45 --> Form Validation Class Initialized
INFO - 2018-02-22 13:59:45 --> Model Class Initialized
INFO - 2018-02-22 13:59:45 --> Controller Class Initialized
DEBUG - 2018-02-22 13:59:45 --> Config file loaded: /var/www/html/project/radio/application/config/rest.php
INFO - 2018-02-22 13:59:45 --> Helper loaded: inflector_helper
INFO - 2018-02-22 13:59:45 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-22 13:59:45 --> Model Class Initialized
INFO - 2018-02-22 13:59:45 --> Model Class Initialized
INFO - 2018-02-22 13:59:45 --> Model Class Initialized
INFO - 2018-02-22 13:59:45 --> Model Class Initialized
INFO - 2018-02-22 13:59:45 --> Model Class Initialized
INFO - 2018-02-22 13:59:45 --> Model Class Initialized
INFO - 2018-02-22 13:59:45 --> Final output sent to browser
DEBUG - 2018-02-22 13:59:45 --> Total execution time: 0.0079
INFO - 2018-02-22 13:59:54 --> Config Class Initialized
INFO - 2018-02-22 13:59:54 --> Hooks Class Initialized
DEBUG - 2018-02-22 13:59:54 --> UTF-8 Support Enabled
INFO - 2018-02-22 13:59:54 --> Utf8 Class Initialized
INFO - 2018-02-22 13:59:54 --> URI Class Initialized
INFO - 2018-02-22 13:59:54 --> Router Class Initialized
INFO - 2018-02-22 13:59:54 --> Output Class Initialized
INFO - 2018-02-22 13:59:54 --> Security Class Initialized
DEBUG - 2018-02-22 13:59:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-22 13:59:54 --> Input Class Initialized
INFO - 2018-02-22 13:59:54 --> Language Class Initialized
INFO - 2018-02-22 13:59:54 --> Loader Class Initialized
INFO - 2018-02-22 13:59:54 --> Helper loaded: url_helper
INFO - 2018-02-22 13:59:54 --> Helper loaded: file_helper
INFO - 2018-02-22 13:59:54 --> Helper loaded: email_helper
INFO - 2018-02-22 13:59:54 --> Helper loaded: common_helper
INFO - 2018-02-22 13:59:54 --> Database Driver Class Initialized
DEBUG - 2018-02-22 13:59:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-22 13:59:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-22 13:59:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-22 13:59:54 --> Pagination Class Initialized
INFO - 2018-02-22 13:59:54 --> Helper loaded: form_helper
INFO - 2018-02-22 13:59:54 --> Form Validation Class Initialized
INFO - 2018-02-22 13:59:54 --> Model Class Initialized
INFO - 2018-02-22 13:59:54 --> Controller Class Initialized
DEBUG - 2018-02-22 13:59:54 --> Config file loaded: /var/www/html/project/radio/application/config/rest.php
INFO - 2018-02-22 13:59:54 --> Helper loaded: inflector_helper
INFO - 2018-02-22 13:59:54 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-22 13:59:54 --> Model Class Initialized
INFO - 2018-02-22 13:59:54 --> Model Class Initialized
INFO - 2018-02-22 13:59:54 --> Model Class Initialized
INFO - 2018-02-22 13:59:54 --> Model Class Initialized
INFO - 2018-02-22 13:59:54 --> Model Class Initialized
INFO - 2018-02-22 13:59:54 --> Model Class Initialized
INFO - 2018-02-22 13:59:54 --> Final output sent to browser
DEBUG - 2018-02-22 13:59:54 --> Total execution time: 0.0063
INFO - 2018-02-22 14:00:50 --> Config Class Initialized
INFO - 2018-02-22 14:00:50 --> Hooks Class Initialized
DEBUG - 2018-02-22 14:00:50 --> UTF-8 Support Enabled
INFO - 2018-02-22 14:00:50 --> Utf8 Class Initialized
INFO - 2018-02-22 14:00:50 --> URI Class Initialized
INFO - 2018-02-22 14:00:50 --> Router Class Initialized
INFO - 2018-02-22 14:00:50 --> Output Class Initialized
INFO - 2018-02-22 14:00:50 --> Security Class Initialized
DEBUG - 2018-02-22 14:00:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-22 14:00:50 --> Input Class Initialized
INFO - 2018-02-22 14:00:50 --> Language Class Initialized
INFO - 2018-02-22 14:00:50 --> Loader Class Initialized
INFO - 2018-02-22 14:00:50 --> Helper loaded: url_helper
INFO - 2018-02-22 14:00:50 --> Helper loaded: file_helper
INFO - 2018-02-22 14:00:50 --> Helper loaded: email_helper
INFO - 2018-02-22 14:00:50 --> Helper loaded: common_helper
INFO - 2018-02-22 14:00:50 --> Database Driver Class Initialized
DEBUG - 2018-02-22 14:00:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-22 14:00:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-22 14:00:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-22 14:00:50 --> Pagination Class Initialized
INFO - 2018-02-22 14:00:50 --> Helper loaded: form_helper
INFO - 2018-02-22 14:00:50 --> Form Validation Class Initialized
INFO - 2018-02-22 14:00:50 --> Model Class Initialized
INFO - 2018-02-22 14:00:50 --> Controller Class Initialized
DEBUG - 2018-02-22 14:00:50 --> Config file loaded: /var/www/html/project/radio/application/config/rest.php
INFO - 2018-02-22 14:00:50 --> Helper loaded: inflector_helper
INFO - 2018-02-22 14:00:50 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-22 14:00:50 --> Model Class Initialized
INFO - 2018-02-22 14:00:50 --> Model Class Initialized
INFO - 2018-02-22 14:00:50 --> Model Class Initialized
INFO - 2018-02-22 14:00:50 --> Model Class Initialized
INFO - 2018-02-22 14:00:50 --> Model Class Initialized
INFO - 2018-02-22 14:00:50 --> Model Class Initialized
INFO - 2018-02-22 14:00:50 --> Final output sent to browser
DEBUG - 2018-02-22 14:00:50 --> Total execution time: 0.0083
INFO - 2018-02-22 14:02:07 --> Config Class Initialized
INFO - 2018-02-22 14:02:07 --> Hooks Class Initialized
DEBUG - 2018-02-22 14:02:07 --> UTF-8 Support Enabled
INFO - 2018-02-22 14:02:07 --> Utf8 Class Initialized
INFO - 2018-02-22 14:02:07 --> URI Class Initialized
INFO - 2018-02-22 14:02:07 --> Router Class Initialized
INFO - 2018-02-22 14:02:07 --> Output Class Initialized
INFO - 2018-02-22 14:02:07 --> Security Class Initialized
DEBUG - 2018-02-22 14:02:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-22 14:02:07 --> Input Class Initialized
INFO - 2018-02-22 14:02:07 --> Language Class Initialized
INFO - 2018-02-22 14:02:07 --> Loader Class Initialized
INFO - 2018-02-22 14:02:07 --> Helper loaded: url_helper
INFO - 2018-02-22 14:02:07 --> Helper loaded: file_helper
INFO - 2018-02-22 14:02:07 --> Helper loaded: email_helper
INFO - 2018-02-22 14:02:07 --> Helper loaded: common_helper
INFO - 2018-02-22 14:02:07 --> Database Driver Class Initialized
DEBUG - 2018-02-22 14:02:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-22 14:02:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-22 14:02:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-22 14:02:07 --> Pagination Class Initialized
INFO - 2018-02-22 14:02:07 --> Helper loaded: form_helper
INFO - 2018-02-22 14:02:07 --> Form Validation Class Initialized
INFO - 2018-02-22 14:02:07 --> Model Class Initialized
INFO - 2018-02-22 14:02:07 --> Controller Class Initialized
DEBUG - 2018-02-22 14:02:07 --> Config file loaded: /var/www/html/project/radio/application/config/rest.php
INFO - 2018-02-22 14:02:07 --> Helper loaded: inflector_helper
INFO - 2018-02-22 14:02:07 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-22 14:02:07 --> Model Class Initialized
INFO - 2018-02-22 14:02:07 --> Model Class Initialized
INFO - 2018-02-22 14:02:07 --> Model Class Initialized
INFO - 2018-02-22 14:02:07 --> Model Class Initialized
INFO - 2018-02-22 14:02:07 --> Model Class Initialized
INFO - 2018-02-22 14:02:07 --> Model Class Initialized
INFO - 2018-02-22 14:02:07 --> Final output sent to browser
DEBUG - 2018-02-22 14:02:07 --> Total execution time: 0.0083
INFO - 2018-02-22 14:26:51 --> Config Class Initialized
INFO - 2018-02-22 14:26:51 --> Hooks Class Initialized
DEBUG - 2018-02-22 14:26:51 --> UTF-8 Support Enabled
INFO - 2018-02-22 14:26:51 --> Utf8 Class Initialized
INFO - 2018-02-22 14:26:51 --> URI Class Initialized
INFO - 2018-02-22 14:26:51 --> Router Class Initialized
INFO - 2018-02-22 14:26:51 --> Output Class Initialized
INFO - 2018-02-22 14:26:51 --> Security Class Initialized
DEBUG - 2018-02-22 14:26:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-22 14:26:51 --> Input Class Initialized
INFO - 2018-02-22 14:26:51 --> Language Class Initialized
INFO - 2018-02-22 14:26:51 --> Loader Class Initialized
INFO - 2018-02-22 14:26:51 --> Helper loaded: url_helper
INFO - 2018-02-22 14:26:51 --> Helper loaded: file_helper
INFO - 2018-02-22 14:26:51 --> Helper loaded: email_helper
INFO - 2018-02-22 14:26:51 --> Helper loaded: common_helper
INFO - 2018-02-22 14:26:51 --> Database Driver Class Initialized
DEBUG - 2018-02-22 14:26:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-22 14:26:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-22 14:26:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-22 14:26:51 --> Pagination Class Initialized
INFO - 2018-02-22 14:26:51 --> Helper loaded: form_helper
INFO - 2018-02-22 14:26:51 --> Form Validation Class Initialized
INFO - 2018-02-22 14:26:51 --> Model Class Initialized
INFO - 2018-02-22 14:26:51 --> Controller Class Initialized
DEBUG - 2018-02-22 14:26:51 --> Config file loaded: /var/www/html/project/radio/application/config/rest.php
INFO - 2018-02-22 14:26:51 --> Helper loaded: inflector_helper
INFO - 2018-02-22 14:26:51 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-22 14:26:51 --> Model Class Initialized
INFO - 2018-02-22 14:26:51 --> Model Class Initialized
INFO - 2018-02-22 14:26:51 --> Model Class Initialized
INFO - 2018-02-22 14:26:51 --> Model Class Initialized
INFO - 2018-02-22 14:26:51 --> Model Class Initialized
INFO - 2018-02-22 14:26:51 --> Model Class Initialized
INFO - 2018-02-22 14:26:51 --> Final output sent to browser
DEBUG - 2018-02-22 14:26:51 --> Total execution time: 0.0114
INFO - 2018-02-22 14:36:51 --> Config Class Initialized
INFO - 2018-02-22 14:36:51 --> Hooks Class Initialized
DEBUG - 2018-02-22 14:36:51 --> UTF-8 Support Enabled
INFO - 2018-02-22 14:36:51 --> Utf8 Class Initialized
INFO - 2018-02-22 14:36:51 --> URI Class Initialized
INFO - 2018-02-22 14:36:51 --> Router Class Initialized
INFO - 2018-02-22 14:36:51 --> Output Class Initialized
INFO - 2018-02-22 14:36:51 --> Security Class Initialized
DEBUG - 2018-02-22 14:36:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-22 14:36:51 --> Input Class Initialized
INFO - 2018-02-22 14:36:51 --> Language Class Initialized
INFO - 2018-02-22 14:36:51 --> Loader Class Initialized
INFO - 2018-02-22 14:36:51 --> Helper loaded: url_helper
INFO - 2018-02-22 14:36:51 --> Helper loaded: file_helper
INFO - 2018-02-22 14:36:51 --> Helper loaded: email_helper
INFO - 2018-02-22 14:36:51 --> Helper loaded: common_helper
INFO - 2018-02-22 14:36:51 --> Database Driver Class Initialized
DEBUG - 2018-02-22 14:36:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-22 14:36:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-22 14:36:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-22 14:36:51 --> Pagination Class Initialized
INFO - 2018-02-22 14:36:51 --> Helper loaded: form_helper
INFO - 2018-02-22 14:36:51 --> Form Validation Class Initialized
INFO - 2018-02-22 14:36:51 --> Model Class Initialized
INFO - 2018-02-22 14:36:51 --> Controller Class Initialized
DEBUG - 2018-02-22 14:36:51 --> Config file loaded: /var/www/html/project/radio/application/config/rest.php
INFO - 2018-02-22 14:36:51 --> Helper loaded: inflector_helper
INFO - 2018-02-22 14:36:51 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-22 14:36:51 --> Model Class Initialized
INFO - 2018-02-22 14:36:51 --> Model Class Initialized
INFO - 2018-02-22 14:36:51 --> Model Class Initialized
INFO - 2018-02-22 14:36:51 --> Model Class Initialized
INFO - 2018-02-22 14:36:51 --> Model Class Initialized
INFO - 2018-02-22 14:36:51 --> Model Class Initialized
INFO - 2018-02-22 14:36:51 --> Final output sent to browser
DEBUG - 2018-02-22 14:36:51 --> Total execution time: 0.0130
INFO - 2018-02-22 14:36:59 --> Config Class Initialized
INFO - 2018-02-22 14:36:59 --> Hooks Class Initialized
DEBUG - 2018-02-22 14:36:59 --> UTF-8 Support Enabled
INFO - 2018-02-22 14:36:59 --> Utf8 Class Initialized
INFO - 2018-02-22 14:36:59 --> URI Class Initialized
INFO - 2018-02-22 14:36:59 --> Router Class Initialized
INFO - 2018-02-22 14:36:59 --> Output Class Initialized
INFO - 2018-02-22 14:36:59 --> Security Class Initialized
DEBUG - 2018-02-22 14:36:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-22 14:36:59 --> Input Class Initialized
INFO - 2018-02-22 14:36:59 --> Language Class Initialized
INFO - 2018-02-22 14:36:59 --> Loader Class Initialized
INFO - 2018-02-22 14:36:59 --> Helper loaded: url_helper
INFO - 2018-02-22 14:36:59 --> Helper loaded: file_helper
INFO - 2018-02-22 14:36:59 --> Helper loaded: email_helper
INFO - 2018-02-22 14:36:59 --> Helper loaded: common_helper
INFO - 2018-02-22 14:36:59 --> Database Driver Class Initialized
DEBUG - 2018-02-22 14:36:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-22 14:36:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-22 14:36:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-22 14:36:59 --> Pagination Class Initialized
INFO - 2018-02-22 14:36:59 --> Helper loaded: form_helper
INFO - 2018-02-22 14:36:59 --> Form Validation Class Initialized
INFO - 2018-02-22 14:36:59 --> Model Class Initialized
INFO - 2018-02-22 14:36:59 --> Controller Class Initialized
DEBUG - 2018-02-22 14:36:59 --> Config file loaded: /var/www/html/project/radio/application/config/rest.php
INFO - 2018-02-22 14:36:59 --> Helper loaded: inflector_helper
INFO - 2018-02-22 14:36:59 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-22 14:36:59 --> Model Class Initialized
INFO - 2018-02-22 14:36:59 --> Model Class Initialized
INFO - 2018-02-22 14:36:59 --> Model Class Initialized
INFO - 2018-02-22 14:36:59 --> Model Class Initialized
INFO - 2018-02-22 14:36:59 --> Model Class Initialized
INFO - 2018-02-22 14:36:59 --> Model Class Initialized
INFO - 2018-02-22 14:36:59 --> Final output sent to browser
DEBUG - 2018-02-22 14:36:59 --> Total execution time: 0.0133
INFO - 2018-02-22 14:37:05 --> Config Class Initialized
INFO - 2018-02-22 14:37:05 --> Hooks Class Initialized
DEBUG - 2018-02-22 14:37:05 --> UTF-8 Support Enabled
INFO - 2018-02-22 14:37:05 --> Utf8 Class Initialized
INFO - 2018-02-22 14:37:05 --> URI Class Initialized
INFO - 2018-02-22 14:37:05 --> Router Class Initialized
INFO - 2018-02-22 14:37:05 --> Output Class Initialized
INFO - 2018-02-22 14:37:05 --> Security Class Initialized
DEBUG - 2018-02-22 14:37:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-22 14:37:05 --> Input Class Initialized
INFO - 2018-02-22 14:37:05 --> Language Class Initialized
INFO - 2018-02-22 14:37:05 --> Loader Class Initialized
INFO - 2018-02-22 14:37:05 --> Helper loaded: url_helper
INFO - 2018-02-22 14:37:05 --> Helper loaded: file_helper
INFO - 2018-02-22 14:37:05 --> Helper loaded: email_helper
INFO - 2018-02-22 14:37:05 --> Helper loaded: common_helper
INFO - 2018-02-22 14:37:05 --> Database Driver Class Initialized
DEBUG - 2018-02-22 14:37:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-22 14:37:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-22 14:37:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-22 14:37:05 --> Pagination Class Initialized
INFO - 2018-02-22 14:37:05 --> Helper loaded: form_helper
INFO - 2018-02-22 14:37:05 --> Form Validation Class Initialized
INFO - 2018-02-22 14:37:05 --> Model Class Initialized
INFO - 2018-02-22 14:37:05 --> Controller Class Initialized
DEBUG - 2018-02-22 14:37:05 --> Config file loaded: /var/www/html/project/radio/application/config/rest.php
INFO - 2018-02-22 14:37:05 --> Helper loaded: inflector_helper
INFO - 2018-02-22 14:37:05 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-22 14:37:05 --> Model Class Initialized
INFO - 2018-02-22 14:37:05 --> Model Class Initialized
INFO - 2018-02-22 14:37:05 --> Model Class Initialized
INFO - 2018-02-22 14:37:05 --> Model Class Initialized
INFO - 2018-02-22 14:37:05 --> Model Class Initialized
INFO - 2018-02-22 14:37:05 --> Model Class Initialized
INFO - 2018-02-22 14:37:05 --> Final output sent to browser
DEBUG - 2018-02-22 14:37:05 --> Total execution time: 0.0138
INFO - 2018-02-22 14:37:10 --> Config Class Initialized
INFO - 2018-02-22 14:37:10 --> Hooks Class Initialized
DEBUG - 2018-02-22 14:37:10 --> UTF-8 Support Enabled
INFO - 2018-02-22 14:37:10 --> Utf8 Class Initialized
INFO - 2018-02-22 14:37:10 --> URI Class Initialized
INFO - 2018-02-22 14:37:10 --> Router Class Initialized
INFO - 2018-02-22 14:37:10 --> Output Class Initialized
INFO - 2018-02-22 14:37:10 --> Security Class Initialized
DEBUG - 2018-02-22 14:37:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-22 14:37:10 --> Input Class Initialized
INFO - 2018-02-22 14:37:10 --> Language Class Initialized
INFO - 2018-02-22 14:37:10 --> Loader Class Initialized
INFO - 2018-02-22 14:37:10 --> Helper loaded: url_helper
INFO - 2018-02-22 14:37:10 --> Helper loaded: file_helper
INFO - 2018-02-22 14:37:10 --> Helper loaded: email_helper
INFO - 2018-02-22 14:37:10 --> Helper loaded: common_helper
INFO - 2018-02-22 14:37:10 --> Database Driver Class Initialized
DEBUG - 2018-02-22 14:37:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-22 14:37:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-22 14:37:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-22 14:37:10 --> Pagination Class Initialized
INFO - 2018-02-22 14:37:10 --> Helper loaded: form_helper
INFO - 2018-02-22 14:37:10 --> Form Validation Class Initialized
INFO - 2018-02-22 14:37:10 --> Model Class Initialized
INFO - 2018-02-22 14:37:10 --> Controller Class Initialized
DEBUG - 2018-02-22 14:37:10 --> Config file loaded: /var/www/html/project/radio/application/config/rest.php
INFO - 2018-02-22 14:37:10 --> Helper loaded: inflector_helper
INFO - 2018-02-22 14:37:10 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-22 14:37:10 --> Model Class Initialized
INFO - 2018-02-22 14:37:10 --> Model Class Initialized
INFO - 2018-02-22 14:37:10 --> Model Class Initialized
INFO - 2018-02-22 14:37:10 --> Model Class Initialized
INFO - 2018-02-22 14:37:10 --> Model Class Initialized
INFO - 2018-02-22 14:37:10 --> Model Class Initialized
INFO - 2018-02-22 14:37:10 --> Final output sent to browser
DEBUG - 2018-02-22 14:37:10 --> Total execution time: 0.0122
INFO - 2018-02-22 14:37:34 --> Config Class Initialized
INFO - 2018-02-22 14:37:34 --> Hooks Class Initialized
DEBUG - 2018-02-22 14:37:34 --> UTF-8 Support Enabled
INFO - 2018-02-22 14:37:34 --> Utf8 Class Initialized
INFO - 2018-02-22 14:37:34 --> URI Class Initialized
INFO - 2018-02-22 14:37:34 --> Router Class Initialized
INFO - 2018-02-22 14:37:34 --> Output Class Initialized
INFO - 2018-02-22 14:37:34 --> Security Class Initialized
DEBUG - 2018-02-22 14:37:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-22 14:37:34 --> Input Class Initialized
INFO - 2018-02-22 14:37:34 --> Language Class Initialized
INFO - 2018-02-22 14:37:34 --> Loader Class Initialized
INFO - 2018-02-22 14:37:34 --> Helper loaded: url_helper
INFO - 2018-02-22 14:37:34 --> Helper loaded: file_helper
INFO - 2018-02-22 14:37:34 --> Helper loaded: email_helper
INFO - 2018-02-22 14:37:34 --> Helper loaded: common_helper
INFO - 2018-02-22 14:37:34 --> Database Driver Class Initialized
DEBUG - 2018-02-22 14:37:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-22 14:37:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-22 14:37:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-22 14:37:34 --> Pagination Class Initialized
INFO - 2018-02-22 14:37:34 --> Helper loaded: form_helper
INFO - 2018-02-22 14:37:34 --> Form Validation Class Initialized
INFO - 2018-02-22 14:37:34 --> Model Class Initialized
INFO - 2018-02-22 14:37:34 --> Controller Class Initialized
DEBUG - 2018-02-22 14:37:34 --> Config file loaded: /var/www/html/project/radio/application/config/rest.php
INFO - 2018-02-22 14:37:34 --> Helper loaded: inflector_helper
INFO - 2018-02-22 14:37:34 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-22 14:37:34 --> Model Class Initialized
INFO - 2018-02-22 14:37:34 --> Model Class Initialized
INFO - 2018-02-22 14:37:34 --> Model Class Initialized
INFO - 2018-02-22 14:37:34 --> Model Class Initialized
INFO - 2018-02-22 14:37:34 --> Model Class Initialized
INFO - 2018-02-22 14:37:34 --> Model Class Initialized
INFO - 2018-02-22 14:37:34 --> Final output sent to browser
DEBUG - 2018-02-22 14:37:34 --> Total execution time: 0.0110
INFO - 2018-02-22 14:46:14 --> Config Class Initialized
INFO - 2018-02-22 14:46:14 --> Hooks Class Initialized
DEBUG - 2018-02-22 14:46:14 --> UTF-8 Support Enabled
INFO - 2018-02-22 14:46:14 --> Utf8 Class Initialized
INFO - 2018-02-22 14:46:14 --> URI Class Initialized
INFO - 2018-02-22 14:46:14 --> Router Class Initialized
INFO - 2018-02-22 14:46:14 --> Output Class Initialized
INFO - 2018-02-22 14:46:14 --> Security Class Initialized
DEBUG - 2018-02-22 14:46:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-22 14:46:14 --> Input Class Initialized
INFO - 2018-02-22 14:46:14 --> Language Class Initialized
INFO - 2018-02-22 14:46:14 --> Loader Class Initialized
INFO - 2018-02-22 14:46:14 --> Helper loaded: url_helper
INFO - 2018-02-22 14:46:14 --> Helper loaded: file_helper
INFO - 2018-02-22 14:46:14 --> Helper loaded: email_helper
INFO - 2018-02-22 14:46:14 --> Helper loaded: common_helper
INFO - 2018-02-22 14:46:14 --> Database Driver Class Initialized
DEBUG - 2018-02-22 14:46:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-22 14:46:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-22 14:46:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-22 14:46:14 --> Pagination Class Initialized
INFO - 2018-02-22 14:46:14 --> Helper loaded: form_helper
INFO - 2018-02-22 14:46:14 --> Form Validation Class Initialized
INFO - 2018-02-22 14:46:14 --> Model Class Initialized
INFO - 2018-02-22 14:46:14 --> Controller Class Initialized
DEBUG - 2018-02-22 14:46:14 --> Config file loaded: /var/www/html/project/radio/application/config/rest.php
INFO - 2018-02-22 14:46:14 --> Helper loaded: inflector_helper
INFO - 2018-02-22 14:46:14 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-22 14:46:14 --> Model Class Initialized
INFO - 2018-02-22 14:46:14 --> Model Class Initialized
INFO - 2018-02-22 14:46:14 --> Model Class Initialized
INFO - 2018-02-22 14:46:14 --> Model Class Initialized
INFO - 2018-02-22 14:46:14 --> Model Class Initialized
INFO - 2018-02-22 14:46:14 --> Model Class Initialized
INFO - 2018-02-22 14:46:14 --> Final output sent to browser
DEBUG - 2018-02-22 14:46:14 --> Total execution time: 0.0093
INFO - 2018-02-22 14:50:17 --> Config Class Initialized
INFO - 2018-02-22 14:50:17 --> Hooks Class Initialized
DEBUG - 2018-02-22 14:50:17 --> UTF-8 Support Enabled
INFO - 2018-02-22 14:50:17 --> Utf8 Class Initialized
INFO - 2018-02-22 14:50:17 --> URI Class Initialized
INFO - 2018-02-22 14:50:17 --> Router Class Initialized
INFO - 2018-02-22 14:50:17 --> Output Class Initialized
INFO - 2018-02-22 14:50:17 --> Security Class Initialized
DEBUG - 2018-02-22 14:50:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-22 14:50:17 --> Input Class Initialized
INFO - 2018-02-22 14:50:17 --> Language Class Initialized
INFO - 2018-02-22 14:50:17 --> Loader Class Initialized
INFO - 2018-02-22 14:50:17 --> Helper loaded: url_helper
INFO - 2018-02-22 14:50:17 --> Helper loaded: file_helper
INFO - 2018-02-22 14:50:17 --> Helper loaded: email_helper
INFO - 2018-02-22 14:50:17 --> Helper loaded: common_helper
INFO - 2018-02-22 14:50:17 --> Database Driver Class Initialized
DEBUG - 2018-02-22 14:50:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-22 14:50:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-22 14:50:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-22 14:50:17 --> Pagination Class Initialized
INFO - 2018-02-22 14:50:17 --> Helper loaded: form_helper
INFO - 2018-02-22 14:50:17 --> Form Validation Class Initialized
INFO - 2018-02-22 14:50:17 --> Model Class Initialized
INFO - 2018-02-22 14:50:17 --> Controller Class Initialized
DEBUG - 2018-02-22 14:50:17 --> Config file loaded: /var/www/html/project/radio/application/config/rest.php
INFO - 2018-02-22 14:50:17 --> Helper loaded: inflector_helper
INFO - 2018-02-22 14:50:17 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-22 14:50:17 --> Model Class Initialized
INFO - 2018-02-22 14:50:17 --> Model Class Initialized
INFO - 2018-02-22 14:50:17 --> Model Class Initialized
INFO - 2018-02-22 14:50:17 --> Model Class Initialized
INFO - 2018-02-22 14:50:17 --> Model Class Initialized
INFO - 2018-02-22 14:50:17 --> Model Class Initialized
ERROR - 2018-02-22 14:50:17 --> Severity: Notice --> Undefined variable: authValidation /var/www/html/project/radio/application/controllers/api/Fetchappdata.php 229
INFO - 2018-02-22 14:50:17 --> Final output sent to browser
DEBUG - 2018-02-22 14:50:17 --> Total execution time: 0.0056
INFO - 2018-02-22 14:50:35 --> Config Class Initialized
INFO - 2018-02-22 14:50:35 --> Hooks Class Initialized
DEBUG - 2018-02-22 14:50:35 --> UTF-8 Support Enabled
INFO - 2018-02-22 14:50:35 --> Utf8 Class Initialized
INFO - 2018-02-22 14:50:35 --> URI Class Initialized
INFO - 2018-02-22 14:50:35 --> Router Class Initialized
INFO - 2018-02-22 14:50:35 --> Output Class Initialized
INFO - 2018-02-22 14:50:35 --> Security Class Initialized
DEBUG - 2018-02-22 14:50:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-22 14:50:35 --> Input Class Initialized
INFO - 2018-02-22 14:50:35 --> Language Class Initialized
INFO - 2018-02-22 14:50:35 --> Loader Class Initialized
INFO - 2018-02-22 14:50:35 --> Helper loaded: url_helper
INFO - 2018-02-22 14:50:35 --> Helper loaded: file_helper
INFO - 2018-02-22 14:50:35 --> Helper loaded: email_helper
INFO - 2018-02-22 14:50:35 --> Helper loaded: common_helper
INFO - 2018-02-22 14:50:35 --> Database Driver Class Initialized
DEBUG - 2018-02-22 14:50:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-22 14:50:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-22 14:50:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-22 14:50:35 --> Pagination Class Initialized
INFO - 2018-02-22 14:50:35 --> Helper loaded: form_helper
INFO - 2018-02-22 14:50:35 --> Form Validation Class Initialized
INFO - 2018-02-22 14:50:35 --> Model Class Initialized
INFO - 2018-02-22 14:50:35 --> Controller Class Initialized
DEBUG - 2018-02-22 14:50:35 --> Config file loaded: /var/www/html/project/radio/application/config/rest.php
INFO - 2018-02-22 14:50:35 --> Helper loaded: inflector_helper
INFO - 2018-02-22 14:50:35 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-22 14:50:35 --> Model Class Initialized
INFO - 2018-02-22 14:50:35 --> Model Class Initialized
INFO - 2018-02-22 14:50:35 --> Model Class Initialized
INFO - 2018-02-22 14:50:35 --> Model Class Initialized
INFO - 2018-02-22 14:50:35 --> Model Class Initialized
INFO - 2018-02-22 14:50:35 --> Model Class Initialized
ERROR - 2018-02-22 14:50:35 --> Severity: Notice --> Undefined variable: authValidation /var/www/html/project/radio/application/controllers/api/Fetchappdata.php 229
INFO - 2018-02-22 14:50:35 --> Final output sent to browser
DEBUG - 2018-02-22 14:50:35 --> Total execution time: 0.0067
INFO - 2018-02-22 14:51:13 --> Config Class Initialized
INFO - 2018-02-22 14:51:13 --> Hooks Class Initialized
DEBUG - 2018-02-22 14:51:13 --> UTF-8 Support Enabled
INFO - 2018-02-22 14:51:13 --> Utf8 Class Initialized
INFO - 2018-02-22 14:51:13 --> URI Class Initialized
INFO - 2018-02-22 14:51:13 --> Router Class Initialized
INFO - 2018-02-22 14:51:13 --> Output Class Initialized
INFO - 2018-02-22 14:51:13 --> Security Class Initialized
DEBUG - 2018-02-22 14:51:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-22 14:51:13 --> Input Class Initialized
INFO - 2018-02-22 14:51:13 --> Language Class Initialized
INFO - 2018-02-22 14:51:13 --> Loader Class Initialized
INFO - 2018-02-22 14:51:13 --> Helper loaded: url_helper
INFO - 2018-02-22 14:51:13 --> Helper loaded: file_helper
INFO - 2018-02-22 14:51:13 --> Helper loaded: email_helper
INFO - 2018-02-22 14:51:13 --> Helper loaded: common_helper
INFO - 2018-02-22 14:51:13 --> Database Driver Class Initialized
DEBUG - 2018-02-22 14:51:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-22 14:51:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-22 14:51:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-22 14:51:13 --> Pagination Class Initialized
INFO - 2018-02-22 14:51:13 --> Helper loaded: form_helper
INFO - 2018-02-22 14:51:13 --> Form Validation Class Initialized
INFO - 2018-02-22 14:51:13 --> Model Class Initialized
INFO - 2018-02-22 14:51:13 --> Controller Class Initialized
DEBUG - 2018-02-22 14:51:13 --> Config file loaded: /var/www/html/project/radio/application/config/rest.php
INFO - 2018-02-22 14:51:13 --> Helper loaded: inflector_helper
INFO - 2018-02-22 14:51:13 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-22 14:51:13 --> Model Class Initialized
INFO - 2018-02-22 14:51:13 --> Model Class Initialized
INFO - 2018-02-22 14:51:13 --> Model Class Initialized
INFO - 2018-02-22 14:51:13 --> Model Class Initialized
INFO - 2018-02-22 14:51:13 --> Model Class Initialized
INFO - 2018-02-22 14:51:13 --> Model Class Initialized
ERROR - 2018-02-22 14:51:13 --> Severity: Notice --> Undefined variable: authValidation /var/www/html/project/radio/application/controllers/api/Fetchappdata.php 229
INFO - 2018-02-22 14:51:13 --> Final output sent to browser
DEBUG - 2018-02-22 14:51:13 --> Total execution time: 0.0064
INFO - 2018-02-22 14:51:39 --> Config Class Initialized
INFO - 2018-02-22 14:51:39 --> Hooks Class Initialized
DEBUG - 2018-02-22 14:51:39 --> UTF-8 Support Enabled
INFO - 2018-02-22 14:51:39 --> Utf8 Class Initialized
INFO - 2018-02-22 14:51:39 --> URI Class Initialized
INFO - 2018-02-22 14:51:39 --> Router Class Initialized
INFO - 2018-02-22 14:51:39 --> Output Class Initialized
INFO - 2018-02-22 14:51:39 --> Security Class Initialized
DEBUG - 2018-02-22 14:51:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-22 14:51:39 --> Input Class Initialized
INFO - 2018-02-22 14:51:39 --> Language Class Initialized
INFO - 2018-02-22 14:51:39 --> Loader Class Initialized
INFO - 2018-02-22 14:51:39 --> Helper loaded: url_helper
INFO - 2018-02-22 14:51:39 --> Helper loaded: file_helper
INFO - 2018-02-22 14:51:39 --> Helper loaded: email_helper
INFO - 2018-02-22 14:51:39 --> Helper loaded: common_helper
INFO - 2018-02-22 14:51:39 --> Database Driver Class Initialized
DEBUG - 2018-02-22 14:51:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-22 14:51:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-22 14:51:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-22 14:51:39 --> Pagination Class Initialized
INFO - 2018-02-22 14:51:39 --> Helper loaded: form_helper
INFO - 2018-02-22 14:51:39 --> Form Validation Class Initialized
INFO - 2018-02-22 14:51:39 --> Model Class Initialized
INFO - 2018-02-22 14:51:39 --> Controller Class Initialized
DEBUG - 2018-02-22 14:51:39 --> Config file loaded: /var/www/html/project/radio/application/config/rest.php
INFO - 2018-02-22 14:51:39 --> Helper loaded: inflector_helper
INFO - 2018-02-22 14:51:39 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-22 14:51:39 --> Model Class Initialized
INFO - 2018-02-22 14:51:39 --> Model Class Initialized
INFO - 2018-02-22 14:51:39 --> Model Class Initialized
INFO - 2018-02-22 14:51:39 --> Model Class Initialized
INFO - 2018-02-22 14:51:39 --> Model Class Initialized
INFO - 2018-02-22 14:51:39 --> Model Class Initialized
INFO - 2018-02-22 14:51:49 --> Config Class Initialized
INFO - 2018-02-22 14:51:49 --> Hooks Class Initialized
DEBUG - 2018-02-22 14:51:49 --> UTF-8 Support Enabled
INFO - 2018-02-22 14:51:49 --> Utf8 Class Initialized
INFO - 2018-02-22 14:51:49 --> URI Class Initialized
INFO - 2018-02-22 14:51:49 --> Router Class Initialized
INFO - 2018-02-22 14:51:49 --> Output Class Initialized
INFO - 2018-02-22 14:51:49 --> Security Class Initialized
DEBUG - 2018-02-22 14:51:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-22 14:51:49 --> Input Class Initialized
INFO - 2018-02-22 14:51:49 --> Language Class Initialized
INFO - 2018-02-22 14:51:49 --> Loader Class Initialized
INFO - 2018-02-22 14:51:49 --> Helper loaded: url_helper
INFO - 2018-02-22 14:51:49 --> Helper loaded: file_helper
INFO - 2018-02-22 14:51:49 --> Helper loaded: email_helper
INFO - 2018-02-22 14:51:49 --> Helper loaded: common_helper
INFO - 2018-02-22 14:51:49 --> Database Driver Class Initialized
DEBUG - 2018-02-22 14:51:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-22 14:51:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-22 14:51:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-22 14:51:49 --> Pagination Class Initialized
INFO - 2018-02-22 14:51:49 --> Helper loaded: form_helper
INFO - 2018-02-22 14:51:49 --> Form Validation Class Initialized
INFO - 2018-02-22 14:51:49 --> Model Class Initialized
INFO - 2018-02-22 14:51:49 --> Controller Class Initialized
DEBUG - 2018-02-22 14:51:49 --> Config file loaded: /var/www/html/project/radio/application/config/rest.php
INFO - 2018-02-22 14:51:49 --> Helper loaded: inflector_helper
INFO - 2018-02-22 14:51:49 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-22 14:51:49 --> Model Class Initialized
INFO - 2018-02-22 14:51:49 --> Model Class Initialized
INFO - 2018-02-22 14:51:49 --> Model Class Initialized
INFO - 2018-02-22 14:51:49 --> Model Class Initialized
INFO - 2018-02-22 14:51:49 --> Model Class Initialized
INFO - 2018-02-22 14:51:49 --> Model Class Initialized
ERROR - 2018-02-22 14:51:49 --> Severity: Notice --> Undefined variable: authValidation /var/www/html/project/radio/application/controllers/api/Fetchappdata.php 229
INFO - 2018-02-22 14:51:49 --> Final output sent to browser
DEBUG - 2018-02-22 14:51:49 --> Total execution time: 0.0050
INFO - 2018-02-22 14:52:10 --> Config Class Initialized
INFO - 2018-02-22 14:52:10 --> Hooks Class Initialized
DEBUG - 2018-02-22 14:52:10 --> UTF-8 Support Enabled
INFO - 2018-02-22 14:52:10 --> Utf8 Class Initialized
INFO - 2018-02-22 14:52:10 --> URI Class Initialized
INFO - 2018-02-22 14:52:10 --> Router Class Initialized
INFO - 2018-02-22 14:52:10 --> Output Class Initialized
INFO - 2018-02-22 14:52:10 --> Security Class Initialized
DEBUG - 2018-02-22 14:52:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-22 14:52:10 --> Input Class Initialized
INFO - 2018-02-22 14:52:10 --> Language Class Initialized
INFO - 2018-02-22 14:52:10 --> Loader Class Initialized
INFO - 2018-02-22 14:52:10 --> Helper loaded: url_helper
INFO - 2018-02-22 14:52:10 --> Helper loaded: file_helper
INFO - 2018-02-22 14:52:10 --> Helper loaded: email_helper
INFO - 2018-02-22 14:52:10 --> Helper loaded: common_helper
INFO - 2018-02-22 14:52:10 --> Database Driver Class Initialized
DEBUG - 2018-02-22 14:52:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-22 14:52:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-22 14:52:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-22 14:52:10 --> Pagination Class Initialized
INFO - 2018-02-22 14:52:10 --> Helper loaded: form_helper
INFO - 2018-02-22 14:52:10 --> Form Validation Class Initialized
INFO - 2018-02-22 14:52:10 --> Model Class Initialized
INFO - 2018-02-22 14:52:10 --> Controller Class Initialized
DEBUG - 2018-02-22 14:52:10 --> Config file loaded: /var/www/html/project/radio/application/config/rest.php
INFO - 2018-02-22 14:52:10 --> Helper loaded: inflector_helper
INFO - 2018-02-22 14:52:10 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-22 14:52:10 --> Model Class Initialized
INFO - 2018-02-22 14:52:10 --> Model Class Initialized
INFO - 2018-02-22 14:52:10 --> Model Class Initialized
INFO - 2018-02-22 14:52:10 --> Model Class Initialized
INFO - 2018-02-22 14:52:10 --> Model Class Initialized
INFO - 2018-02-22 14:52:10 --> Model Class Initialized
ERROR - 2018-02-22 14:52:10 --> Severity: Notice --> Undefined variable: authValidation /var/www/html/project/radio/application/controllers/api/Fetchappdata.php 229
INFO - 2018-02-22 14:52:10 --> Final output sent to browser
DEBUG - 2018-02-22 14:52:10 --> Total execution time: 0.0088
INFO - 2018-02-22 14:52:31 --> Config Class Initialized
INFO - 2018-02-22 14:52:31 --> Hooks Class Initialized
DEBUG - 2018-02-22 14:52:31 --> UTF-8 Support Enabled
INFO - 2018-02-22 14:52:31 --> Utf8 Class Initialized
INFO - 2018-02-22 14:52:31 --> URI Class Initialized
INFO - 2018-02-22 14:52:31 --> Router Class Initialized
INFO - 2018-02-22 14:52:31 --> Output Class Initialized
INFO - 2018-02-22 14:52:31 --> Security Class Initialized
DEBUG - 2018-02-22 14:52:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-22 14:52:31 --> Input Class Initialized
INFO - 2018-02-22 14:52:31 --> Language Class Initialized
INFO - 2018-02-22 14:52:31 --> Loader Class Initialized
INFO - 2018-02-22 14:52:31 --> Helper loaded: url_helper
INFO - 2018-02-22 14:52:31 --> Helper loaded: file_helper
INFO - 2018-02-22 14:52:31 --> Helper loaded: email_helper
INFO - 2018-02-22 14:52:31 --> Helper loaded: common_helper
INFO - 2018-02-22 14:52:31 --> Database Driver Class Initialized
DEBUG - 2018-02-22 14:52:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-22 14:52:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-22 14:52:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-22 14:52:31 --> Pagination Class Initialized
INFO - 2018-02-22 14:52:31 --> Helper loaded: form_helper
INFO - 2018-02-22 14:52:31 --> Form Validation Class Initialized
INFO - 2018-02-22 14:52:31 --> Model Class Initialized
INFO - 2018-02-22 14:52:31 --> Controller Class Initialized
DEBUG - 2018-02-22 14:52:31 --> Config file loaded: /var/www/html/project/radio/application/config/rest.php
INFO - 2018-02-22 14:52:31 --> Helper loaded: inflector_helper
INFO - 2018-02-22 14:52:31 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-22 14:52:31 --> Model Class Initialized
INFO - 2018-02-22 14:52:31 --> Model Class Initialized
INFO - 2018-02-22 14:52:31 --> Model Class Initialized
INFO - 2018-02-22 14:52:31 --> Model Class Initialized
INFO - 2018-02-22 14:52:31 --> Model Class Initialized
INFO - 2018-02-22 14:52:31 --> Model Class Initialized
ERROR - 2018-02-22 14:52:31 --> Severity: Notice --> Undefined variable: authValidation /var/www/html/project/radio/application/controllers/api/Fetchappdata.php 229
INFO - 2018-02-22 14:52:31 --> Final output sent to browser
DEBUG - 2018-02-22 14:52:31 --> Total execution time: 0.0073
INFO - 2018-02-22 14:53:25 --> Config Class Initialized
INFO - 2018-02-22 14:53:25 --> Hooks Class Initialized
DEBUG - 2018-02-22 14:53:25 --> UTF-8 Support Enabled
INFO - 2018-02-22 14:53:25 --> Utf8 Class Initialized
INFO - 2018-02-22 14:53:25 --> URI Class Initialized
INFO - 2018-02-22 14:53:25 --> Router Class Initialized
INFO - 2018-02-22 14:53:25 --> Output Class Initialized
INFO - 2018-02-22 14:53:25 --> Security Class Initialized
DEBUG - 2018-02-22 14:53:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-22 14:53:25 --> Input Class Initialized
INFO - 2018-02-22 14:53:25 --> Language Class Initialized
INFO - 2018-02-22 14:53:25 --> Loader Class Initialized
INFO - 2018-02-22 14:53:25 --> Helper loaded: url_helper
INFO - 2018-02-22 14:53:25 --> Helper loaded: file_helper
INFO - 2018-02-22 14:53:25 --> Helper loaded: email_helper
INFO - 2018-02-22 14:53:25 --> Helper loaded: common_helper
INFO - 2018-02-22 14:53:25 --> Database Driver Class Initialized
DEBUG - 2018-02-22 14:53:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-22 14:53:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-22 14:53:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-22 14:53:25 --> Pagination Class Initialized
INFO - 2018-02-22 14:53:25 --> Helper loaded: form_helper
INFO - 2018-02-22 14:53:25 --> Form Validation Class Initialized
INFO - 2018-02-22 14:53:25 --> Model Class Initialized
INFO - 2018-02-22 14:53:25 --> Controller Class Initialized
DEBUG - 2018-02-22 14:53:25 --> Config file loaded: /var/www/html/project/radio/application/config/rest.php
INFO - 2018-02-22 14:53:25 --> Helper loaded: inflector_helper
INFO - 2018-02-22 14:53:25 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-22 14:53:25 --> Model Class Initialized
INFO - 2018-02-22 14:53:25 --> Model Class Initialized
INFO - 2018-02-22 14:53:25 --> Model Class Initialized
INFO - 2018-02-22 14:53:25 --> Model Class Initialized
INFO - 2018-02-22 14:53:25 --> Model Class Initialized
INFO - 2018-02-22 14:53:25 --> Model Class Initialized
INFO - 2018-02-22 14:53:25 --> Final output sent to browser
DEBUG - 2018-02-22 14:53:25 --> Total execution time: 0.0057
INFO - 2018-02-22 14:53:36 --> Config Class Initialized
INFO - 2018-02-22 14:53:36 --> Hooks Class Initialized
DEBUG - 2018-02-22 14:53:36 --> UTF-8 Support Enabled
INFO - 2018-02-22 14:53:36 --> Utf8 Class Initialized
INFO - 2018-02-22 14:53:36 --> URI Class Initialized
INFO - 2018-02-22 14:53:36 --> Router Class Initialized
INFO - 2018-02-22 14:53:36 --> Output Class Initialized
INFO - 2018-02-22 14:53:36 --> Security Class Initialized
DEBUG - 2018-02-22 14:53:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-22 14:53:36 --> Input Class Initialized
INFO - 2018-02-22 14:53:36 --> Language Class Initialized
INFO - 2018-02-22 14:53:36 --> Loader Class Initialized
INFO - 2018-02-22 14:53:36 --> Helper loaded: url_helper
INFO - 2018-02-22 14:53:36 --> Helper loaded: file_helper
INFO - 2018-02-22 14:53:36 --> Helper loaded: email_helper
INFO - 2018-02-22 14:53:36 --> Helper loaded: common_helper
INFO - 2018-02-22 14:53:36 --> Database Driver Class Initialized
DEBUG - 2018-02-22 14:53:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-22 14:53:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-22 14:53:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-22 14:53:36 --> Pagination Class Initialized
INFO - 2018-02-22 14:53:36 --> Helper loaded: form_helper
INFO - 2018-02-22 14:53:36 --> Form Validation Class Initialized
INFO - 2018-02-22 14:53:36 --> Model Class Initialized
INFO - 2018-02-22 14:53:36 --> Controller Class Initialized
DEBUG - 2018-02-22 14:53:36 --> Config file loaded: /var/www/html/project/radio/application/config/rest.php
INFO - 2018-02-22 14:53:36 --> Helper loaded: inflector_helper
INFO - 2018-02-22 14:53:36 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-22 14:53:36 --> Model Class Initialized
INFO - 2018-02-22 14:53:36 --> Model Class Initialized
INFO - 2018-02-22 14:53:36 --> Model Class Initialized
INFO - 2018-02-22 14:53:36 --> Model Class Initialized
INFO - 2018-02-22 14:53:36 --> Model Class Initialized
INFO - 2018-02-22 14:53:36 --> Model Class Initialized
INFO - 2018-02-22 14:53:36 --> Final output sent to browser
DEBUG - 2018-02-22 14:53:36 --> Total execution time: 0.0051
INFO - 2018-02-22 14:53:40 --> Config Class Initialized
INFO - 2018-02-22 14:53:40 --> Hooks Class Initialized
DEBUG - 2018-02-22 14:53:40 --> UTF-8 Support Enabled
INFO - 2018-02-22 14:53:40 --> Utf8 Class Initialized
INFO - 2018-02-22 14:53:40 --> URI Class Initialized
INFO - 2018-02-22 14:53:40 --> Router Class Initialized
INFO - 2018-02-22 14:53:40 --> Output Class Initialized
INFO - 2018-02-22 14:53:40 --> Security Class Initialized
DEBUG - 2018-02-22 14:53:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-22 14:53:40 --> Input Class Initialized
INFO - 2018-02-22 14:53:40 --> Language Class Initialized
INFO - 2018-02-22 14:53:40 --> Loader Class Initialized
INFO - 2018-02-22 14:53:40 --> Helper loaded: url_helper
INFO - 2018-02-22 14:53:40 --> Helper loaded: file_helper
INFO - 2018-02-22 14:53:40 --> Helper loaded: email_helper
INFO - 2018-02-22 14:53:40 --> Helper loaded: common_helper
INFO - 2018-02-22 14:53:40 --> Database Driver Class Initialized
DEBUG - 2018-02-22 14:53:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-22 14:53:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-22 14:53:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-22 14:53:40 --> Pagination Class Initialized
INFO - 2018-02-22 14:53:40 --> Helper loaded: form_helper
INFO - 2018-02-22 14:53:40 --> Form Validation Class Initialized
INFO - 2018-02-22 14:53:40 --> Model Class Initialized
INFO - 2018-02-22 14:53:40 --> Controller Class Initialized
DEBUG - 2018-02-22 14:53:40 --> Config file loaded: /var/www/html/project/radio/application/config/rest.php
INFO - 2018-02-22 14:53:40 --> Helper loaded: inflector_helper
INFO - 2018-02-22 14:53:40 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-22 14:53:40 --> Model Class Initialized
INFO - 2018-02-22 14:53:40 --> Model Class Initialized
INFO - 2018-02-22 14:53:40 --> Model Class Initialized
INFO - 2018-02-22 14:53:40 --> Model Class Initialized
INFO - 2018-02-22 14:53:40 --> Model Class Initialized
INFO - 2018-02-22 14:53:40 --> Model Class Initialized
INFO - 2018-02-22 14:53:40 --> Final output sent to browser
DEBUG - 2018-02-22 14:53:40 --> Total execution time: 0.0048
INFO - 2018-02-22 14:53:52 --> Config Class Initialized
INFO - 2018-02-22 14:53:52 --> Hooks Class Initialized
DEBUG - 2018-02-22 14:53:52 --> UTF-8 Support Enabled
INFO - 2018-02-22 14:53:52 --> Utf8 Class Initialized
INFO - 2018-02-22 14:53:52 --> URI Class Initialized
INFO - 2018-02-22 14:53:52 --> Router Class Initialized
INFO - 2018-02-22 14:53:52 --> Output Class Initialized
INFO - 2018-02-22 14:53:52 --> Security Class Initialized
DEBUG - 2018-02-22 14:53:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-22 14:53:52 --> Input Class Initialized
INFO - 2018-02-22 14:53:52 --> Language Class Initialized
INFO - 2018-02-22 14:53:52 --> Loader Class Initialized
INFO - 2018-02-22 14:53:52 --> Helper loaded: url_helper
INFO - 2018-02-22 14:53:52 --> Helper loaded: file_helper
INFO - 2018-02-22 14:53:52 --> Helper loaded: email_helper
INFO - 2018-02-22 14:53:52 --> Helper loaded: common_helper
INFO - 2018-02-22 14:53:52 --> Database Driver Class Initialized
DEBUG - 2018-02-22 14:53:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-22 14:53:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-22 14:53:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-22 14:53:52 --> Pagination Class Initialized
INFO - 2018-02-22 14:53:52 --> Helper loaded: form_helper
INFO - 2018-02-22 14:53:52 --> Form Validation Class Initialized
INFO - 2018-02-22 14:53:52 --> Model Class Initialized
INFO - 2018-02-22 14:53:52 --> Controller Class Initialized
DEBUG - 2018-02-22 14:53:52 --> Config file loaded: /var/www/html/project/radio/application/config/rest.php
INFO - 2018-02-22 14:53:52 --> Helper loaded: inflector_helper
INFO - 2018-02-22 14:53:52 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-22 14:53:52 --> Model Class Initialized
INFO - 2018-02-22 14:53:52 --> Model Class Initialized
INFO - 2018-02-22 14:53:52 --> Model Class Initialized
INFO - 2018-02-22 14:53:52 --> Model Class Initialized
INFO - 2018-02-22 14:53:52 --> Model Class Initialized
INFO - 2018-02-22 14:53:52 --> Model Class Initialized
INFO - 2018-02-22 14:55:48 --> Config Class Initialized
INFO - 2018-02-22 14:55:48 --> Hooks Class Initialized
DEBUG - 2018-02-22 14:55:48 --> UTF-8 Support Enabled
INFO - 2018-02-22 14:55:48 --> Utf8 Class Initialized
INFO - 2018-02-22 14:55:48 --> URI Class Initialized
INFO - 2018-02-22 14:55:48 --> Router Class Initialized
INFO - 2018-02-22 14:55:48 --> Output Class Initialized
INFO - 2018-02-22 14:55:48 --> Security Class Initialized
DEBUG - 2018-02-22 14:55:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-22 14:55:48 --> Input Class Initialized
INFO - 2018-02-22 14:55:48 --> Language Class Initialized
INFO - 2018-02-22 14:55:48 --> Loader Class Initialized
INFO - 2018-02-22 14:55:48 --> Helper loaded: url_helper
INFO - 2018-02-22 14:55:48 --> Helper loaded: file_helper
INFO - 2018-02-22 14:55:48 --> Helper loaded: email_helper
INFO - 2018-02-22 14:55:48 --> Helper loaded: common_helper
INFO - 2018-02-22 14:55:48 --> Database Driver Class Initialized
DEBUG - 2018-02-22 14:55:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-22 14:55:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-22 14:55:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-22 14:55:48 --> Pagination Class Initialized
INFO - 2018-02-22 14:55:48 --> Helper loaded: form_helper
INFO - 2018-02-22 14:55:48 --> Form Validation Class Initialized
INFO - 2018-02-22 14:55:48 --> Model Class Initialized
INFO - 2018-02-22 14:55:48 --> Controller Class Initialized
DEBUG - 2018-02-22 14:55:48 --> Config file loaded: /var/www/html/project/radio/application/config/rest.php
INFO - 2018-02-22 14:55:48 --> Helper loaded: inflector_helper
INFO - 2018-02-22 14:55:48 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-22 14:55:48 --> Model Class Initialized
INFO - 2018-02-22 14:55:48 --> Model Class Initialized
INFO - 2018-02-22 14:55:48 --> Model Class Initialized
INFO - 2018-02-22 14:55:48 --> Model Class Initialized
INFO - 2018-02-22 14:55:48 --> Model Class Initialized
INFO - 2018-02-22 14:55:48 --> Model Class Initialized
INFO - 2018-02-22 14:56:44 --> Config Class Initialized
INFO - 2018-02-22 14:56:44 --> Hooks Class Initialized
DEBUG - 2018-02-22 14:56:44 --> UTF-8 Support Enabled
INFO - 2018-02-22 14:56:44 --> Utf8 Class Initialized
INFO - 2018-02-22 14:56:44 --> URI Class Initialized
INFO - 2018-02-22 14:56:44 --> Router Class Initialized
INFO - 2018-02-22 14:56:44 --> Output Class Initialized
INFO - 2018-02-22 14:56:44 --> Security Class Initialized
DEBUG - 2018-02-22 14:56:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-22 14:56:44 --> Input Class Initialized
INFO - 2018-02-22 14:56:44 --> Language Class Initialized
INFO - 2018-02-22 14:56:44 --> Loader Class Initialized
INFO - 2018-02-22 14:56:44 --> Helper loaded: url_helper
INFO - 2018-02-22 14:56:44 --> Helper loaded: file_helper
INFO - 2018-02-22 14:56:44 --> Helper loaded: email_helper
INFO - 2018-02-22 14:56:44 --> Helper loaded: common_helper
INFO - 2018-02-22 14:56:44 --> Database Driver Class Initialized
DEBUG - 2018-02-22 14:56:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-22 14:56:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-22 14:56:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-22 14:56:44 --> Pagination Class Initialized
INFO - 2018-02-22 14:56:44 --> Helper loaded: form_helper
INFO - 2018-02-22 14:56:44 --> Form Validation Class Initialized
INFO - 2018-02-22 14:56:44 --> Model Class Initialized
INFO - 2018-02-22 14:56:44 --> Controller Class Initialized
INFO - 2018-02-22 14:56:44 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-22 14:56:44 --> Config Class Initialized
INFO - 2018-02-22 14:56:44 --> Hooks Class Initialized
DEBUG - 2018-02-22 14:56:44 --> UTF-8 Support Enabled
INFO - 2018-02-22 14:56:44 --> Utf8 Class Initialized
INFO - 2018-02-22 14:56:44 --> URI Class Initialized
DEBUG - 2018-02-22 14:56:44 --> No URI present. Default controller set.
INFO - 2018-02-22 14:56:44 --> Router Class Initialized
INFO - 2018-02-22 14:56:44 --> Output Class Initialized
INFO - 2018-02-22 14:56:44 --> Security Class Initialized
DEBUG - 2018-02-22 14:56:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-22 14:56:44 --> Input Class Initialized
INFO - 2018-02-22 14:56:44 --> Language Class Initialized
INFO - 2018-02-22 14:56:44 --> Loader Class Initialized
INFO - 2018-02-22 14:56:44 --> Helper loaded: url_helper
INFO - 2018-02-22 14:56:44 --> Helper loaded: file_helper
INFO - 2018-02-22 14:56:44 --> Helper loaded: email_helper
INFO - 2018-02-22 14:56:44 --> Helper loaded: common_helper
INFO - 2018-02-22 14:56:44 --> Database Driver Class Initialized
DEBUG - 2018-02-22 14:56:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-22 14:56:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-22 14:56:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-22 14:56:44 --> Pagination Class Initialized
INFO - 2018-02-22 14:56:44 --> Helper loaded: form_helper
INFO - 2018-02-22 14:56:44 --> Form Validation Class Initialized
INFO - 2018-02-22 14:56:44 --> Model Class Initialized
INFO - 2018-02-22 14:56:44 --> Controller Class Initialized
INFO - 2018-02-22 14:56:44 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-22 14:56:44 --> Model Class Initialized
INFO - 2018-02-22 14:56:44 --> Model Class Initialized
INFO - 2018-02-22 14:56:44 --> File loaded: /var/www/html/project/radio/application/views/index/index.php
INFO - 2018-02-22 14:56:44 --> Final output sent to browser
DEBUG - 2018-02-22 14:56:44 --> Total execution time: 0.0043
INFO - 2018-02-22 14:56:46 --> Config Class Initialized
INFO - 2018-02-22 14:56:46 --> Hooks Class Initialized
DEBUG - 2018-02-22 14:56:46 --> UTF-8 Support Enabled
INFO - 2018-02-22 14:56:46 --> Utf8 Class Initialized
INFO - 2018-02-22 14:56:46 --> URI Class Initialized
INFO - 2018-02-22 14:56:46 --> Router Class Initialized
INFO - 2018-02-22 14:56:46 --> Output Class Initialized
INFO - 2018-02-22 14:56:46 --> Security Class Initialized
DEBUG - 2018-02-22 14:56:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-22 14:56:46 --> Input Class Initialized
INFO - 2018-02-22 14:56:46 --> Language Class Initialized
INFO - 2018-02-22 14:56:46 --> Loader Class Initialized
INFO - 2018-02-22 14:56:46 --> Helper loaded: url_helper
INFO - 2018-02-22 14:56:46 --> Helper loaded: file_helper
INFO - 2018-02-22 14:56:46 --> Helper loaded: email_helper
INFO - 2018-02-22 14:56:46 --> Helper loaded: common_helper
INFO - 2018-02-22 14:56:46 --> Database Driver Class Initialized
DEBUG - 2018-02-22 14:56:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-22 14:56:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-22 14:56:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-22 14:56:46 --> Pagination Class Initialized
INFO - 2018-02-22 14:56:46 --> Helper loaded: form_helper
INFO - 2018-02-22 14:56:46 --> Form Validation Class Initialized
INFO - 2018-02-22 14:56:46 --> Model Class Initialized
INFO - 2018-02-22 14:56:46 --> Controller Class Initialized
INFO - 2018-02-22 14:56:46 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-22 14:56:46 --> Model Class Initialized
INFO - 2018-02-22 14:56:46 --> Model Class Initialized
ERROR - 2018-02-22 14:56:46 --> Severity: Notice --> Undefined index: remember_me /var/www/html/project/radio/application/controllers/Index.php 74
INFO - 2018-02-22 14:56:46 --> Config Class Initialized
INFO - 2018-02-22 14:56:46 --> Hooks Class Initialized
DEBUG - 2018-02-22 14:56:46 --> UTF-8 Support Enabled
INFO - 2018-02-22 14:56:46 --> Utf8 Class Initialized
INFO - 2018-02-22 14:56:46 --> URI Class Initialized
INFO - 2018-02-22 14:56:46 --> Router Class Initialized
INFO - 2018-02-22 14:56:46 --> Output Class Initialized
INFO - 2018-02-22 14:56:46 --> Security Class Initialized
DEBUG - 2018-02-22 14:56:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-22 14:56:46 --> Input Class Initialized
INFO - 2018-02-22 14:56:46 --> Language Class Initialized
INFO - 2018-02-22 14:56:46 --> Loader Class Initialized
INFO - 2018-02-22 14:56:46 --> Helper loaded: url_helper
INFO - 2018-02-22 14:56:46 --> Helper loaded: file_helper
INFO - 2018-02-22 14:56:46 --> Helper loaded: email_helper
INFO - 2018-02-22 14:56:46 --> Helper loaded: common_helper
INFO - 2018-02-22 14:56:46 --> Database Driver Class Initialized
DEBUG - 2018-02-22 14:56:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-22 14:56:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-22 14:56:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-22 14:56:46 --> Pagination Class Initialized
INFO - 2018-02-22 14:56:46 --> Helper loaded: form_helper
INFO - 2018-02-22 14:56:46 --> Form Validation Class Initialized
INFO - 2018-02-22 14:56:46 --> Model Class Initialized
INFO - 2018-02-22 14:56:46 --> Controller Class Initialized
INFO - 2018-02-22 14:56:46 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-22 14:56:46 --> Model Class Initialized
INFO - 2018-02-22 14:56:46 --> Model Class Initialized
INFO - 2018-02-22 14:56:46 --> Model Class Initialized
INFO - 2018-02-22 14:56:46 --> Model Class Initialized
INFO - 2018-02-22 14:56:46 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-22 14:56:46 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-22 14:56:46 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-22 14:56:46 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-22 14:56:46 --> File loaded: /var/www/html/project/radio/application/views/dashboard/index.php
INFO - 2018-02-22 14:56:46 --> Final output sent to browser
DEBUG - 2018-02-22 14:56:46 --> Total execution time: 0.0060
INFO - 2018-02-22 14:56:49 --> Config Class Initialized
INFO - 2018-02-22 14:56:49 --> Hooks Class Initialized
DEBUG - 2018-02-22 14:56:49 --> UTF-8 Support Enabled
INFO - 2018-02-22 14:56:49 --> Utf8 Class Initialized
INFO - 2018-02-22 14:56:49 --> URI Class Initialized
INFO - 2018-02-22 14:56:49 --> Router Class Initialized
INFO - 2018-02-22 14:56:49 --> Output Class Initialized
INFO - 2018-02-22 14:56:49 --> Security Class Initialized
DEBUG - 2018-02-22 14:56:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-22 14:56:49 --> Input Class Initialized
INFO - 2018-02-22 14:56:49 --> Language Class Initialized
INFO - 2018-02-22 14:56:49 --> Loader Class Initialized
INFO - 2018-02-22 14:56:49 --> Helper loaded: url_helper
INFO - 2018-02-22 14:56:49 --> Helper loaded: file_helper
INFO - 2018-02-22 14:56:49 --> Helper loaded: email_helper
INFO - 2018-02-22 14:56:49 --> Helper loaded: common_helper
INFO - 2018-02-22 14:56:49 --> Database Driver Class Initialized
DEBUG - 2018-02-22 14:56:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-22 14:56:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-22 14:56:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-22 14:56:49 --> Pagination Class Initialized
INFO - 2018-02-22 14:56:49 --> Helper loaded: form_helper
INFO - 2018-02-22 14:56:49 --> Form Validation Class Initialized
INFO - 2018-02-22 14:56:49 --> Model Class Initialized
INFO - 2018-02-22 14:56:49 --> Controller Class Initialized
INFO - 2018-02-22 14:56:49 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-22 14:56:49 --> Model Class Initialized
INFO - 2018-02-22 14:56:49 --> Model Class Initialized
INFO - 2018-02-22 14:56:49 --> Model Class Initialized
INFO - 2018-02-22 14:56:49 --> Model Class Initialized
INFO - 2018-02-22 14:56:49 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-22 14:56:49 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-22 14:56:49 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-22 14:56:49 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-22 14:56:49 --> File loaded: /var/www/html/project/radio/application/views/tracks/index.php
INFO - 2018-02-22 14:56:49 --> Final output sent to browser
DEBUG - 2018-02-22 14:56:49 --> Total execution time: 0.0058
INFO - 2018-02-22 14:56:49 --> Config Class Initialized
INFO - 2018-02-22 14:56:49 --> Hooks Class Initialized
DEBUG - 2018-02-22 14:56:49 --> UTF-8 Support Enabled
INFO - 2018-02-22 14:56:49 --> Utf8 Class Initialized
INFO - 2018-02-22 14:56:49 --> URI Class Initialized
INFO - 2018-02-22 14:56:49 --> Router Class Initialized
INFO - 2018-02-22 14:56:49 --> Output Class Initialized
INFO - 2018-02-22 14:56:49 --> Security Class Initialized
DEBUG - 2018-02-22 14:56:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-22 14:56:49 --> Input Class Initialized
INFO - 2018-02-22 14:56:49 --> Language Class Initialized
INFO - 2018-02-22 14:56:49 --> Loader Class Initialized
INFO - 2018-02-22 14:56:49 --> Helper loaded: url_helper
INFO - 2018-02-22 14:56:49 --> Helper loaded: file_helper
INFO - 2018-02-22 14:56:49 --> Helper loaded: email_helper
INFO - 2018-02-22 14:56:49 --> Helper loaded: common_helper
INFO - 2018-02-22 14:56:49 --> Database Driver Class Initialized
DEBUG - 2018-02-22 14:56:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-22 14:56:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-22 14:56:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-22 14:56:49 --> Pagination Class Initialized
INFO - 2018-02-22 14:56:49 --> Helper loaded: form_helper
INFO - 2018-02-22 14:56:49 --> Form Validation Class Initialized
INFO - 2018-02-22 14:56:49 --> Model Class Initialized
INFO - 2018-02-22 14:56:49 --> Controller Class Initialized
INFO - 2018-02-22 14:56:49 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-22 14:56:49 --> Model Class Initialized
INFO - 2018-02-22 14:56:49 --> Model Class Initialized
INFO - 2018-02-22 14:56:49 --> Model Class Initialized
INFO - 2018-02-22 14:56:49 --> Model Class Initialized
INFO - 2018-02-22 14:56:50 --> Config Class Initialized
INFO - 2018-02-22 14:56:50 --> Hooks Class Initialized
DEBUG - 2018-02-22 14:56:50 --> UTF-8 Support Enabled
INFO - 2018-02-22 14:56:50 --> Utf8 Class Initialized
INFO - 2018-02-22 14:56:50 --> URI Class Initialized
INFO - 2018-02-22 14:56:50 --> Router Class Initialized
INFO - 2018-02-22 14:56:50 --> Output Class Initialized
INFO - 2018-02-22 14:56:50 --> Security Class Initialized
DEBUG - 2018-02-22 14:56:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-22 14:56:50 --> Input Class Initialized
INFO - 2018-02-22 14:56:50 --> Language Class Initialized
INFO - 2018-02-22 14:56:50 --> Loader Class Initialized
INFO - 2018-02-22 14:56:50 --> Helper loaded: url_helper
INFO - 2018-02-22 14:56:50 --> Helper loaded: file_helper
INFO - 2018-02-22 14:56:50 --> Helper loaded: email_helper
INFO - 2018-02-22 14:56:50 --> Helper loaded: common_helper
INFO - 2018-02-22 14:56:50 --> Database Driver Class Initialized
DEBUG - 2018-02-22 14:56:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-22 14:56:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-22 14:56:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-22 14:56:50 --> Pagination Class Initialized
INFO - 2018-02-22 14:56:50 --> Helper loaded: form_helper
INFO - 2018-02-22 14:56:50 --> Form Validation Class Initialized
INFO - 2018-02-22 14:56:50 --> Model Class Initialized
INFO - 2018-02-22 14:56:50 --> Controller Class Initialized
INFO - 2018-02-22 14:56:50 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-22 14:56:50 --> Model Class Initialized
INFO - 2018-02-22 14:56:50 --> Model Class Initialized
INFO - 2018-02-22 14:56:50 --> Model Class Initialized
INFO - 2018-02-22 14:56:50 --> Model Class Initialized
INFO - 2018-02-22 14:56:50 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-22 14:56:50 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-22 14:56:50 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-22 14:56:50 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-22 14:56:50 --> File loaded: /var/www/html/project/radio/application/views/tracks/add_edit.php
INFO - 2018-02-22 14:56:50 --> Final output sent to browser
DEBUG - 2018-02-22 14:56:50 --> Total execution time: 0.0186
INFO - 2018-02-22 14:56:52 --> Config Class Initialized
INFO - 2018-02-22 14:56:52 --> Hooks Class Initialized
DEBUG - 2018-02-22 14:56:52 --> UTF-8 Support Enabled
INFO - 2018-02-22 14:56:52 --> Utf8 Class Initialized
INFO - 2018-02-22 14:56:52 --> URI Class Initialized
INFO - 2018-02-22 14:56:52 --> Router Class Initialized
INFO - 2018-02-22 14:56:52 --> Output Class Initialized
INFO - 2018-02-22 14:56:52 --> Security Class Initialized
DEBUG - 2018-02-22 14:56:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-22 14:56:52 --> Input Class Initialized
INFO - 2018-02-22 14:56:52 --> Language Class Initialized
INFO - 2018-02-22 14:56:52 --> Loader Class Initialized
INFO - 2018-02-22 14:56:52 --> Helper loaded: url_helper
INFO - 2018-02-22 14:56:52 --> Helper loaded: file_helper
INFO - 2018-02-22 14:56:52 --> Helper loaded: email_helper
INFO - 2018-02-22 14:56:52 --> Helper loaded: common_helper
INFO - 2018-02-22 14:56:52 --> Database Driver Class Initialized
DEBUG - 2018-02-22 14:56:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-22 14:56:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-22 14:56:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-22 14:56:52 --> Pagination Class Initialized
INFO - 2018-02-22 14:56:52 --> Helper loaded: form_helper
INFO - 2018-02-22 14:56:52 --> Form Validation Class Initialized
INFO - 2018-02-22 14:56:52 --> Model Class Initialized
INFO - 2018-02-22 14:56:52 --> Controller Class Initialized
INFO - 2018-02-22 14:56:52 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-22 14:56:52 --> Model Class Initialized
INFO - 2018-02-22 14:56:52 --> Model Class Initialized
INFO - 2018-02-22 14:56:52 --> Model Class Initialized
INFO - 2018-02-22 14:56:52 --> Model Class Initialized
INFO - 2018-02-22 14:57:22 --> Config Class Initialized
INFO - 2018-02-22 14:57:22 --> Hooks Class Initialized
DEBUG - 2018-02-22 14:57:22 --> UTF-8 Support Enabled
INFO - 2018-02-22 14:57:22 --> Utf8 Class Initialized
INFO - 2018-02-22 14:57:22 --> URI Class Initialized
INFO - 2018-02-22 14:57:22 --> Router Class Initialized
INFO - 2018-02-22 14:57:22 --> Output Class Initialized
INFO - 2018-02-22 14:57:22 --> Security Class Initialized
DEBUG - 2018-02-22 14:57:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-22 14:57:22 --> Input Class Initialized
INFO - 2018-02-22 14:57:22 --> Language Class Initialized
INFO - 2018-02-22 14:57:22 --> Loader Class Initialized
INFO - 2018-02-22 14:57:22 --> Helper loaded: url_helper
INFO - 2018-02-22 14:57:22 --> Helper loaded: file_helper
INFO - 2018-02-22 14:57:22 --> Helper loaded: email_helper
INFO - 2018-02-22 14:57:22 --> Helper loaded: common_helper
INFO - 2018-02-22 14:57:22 --> Database Driver Class Initialized
DEBUG - 2018-02-22 14:57:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-22 14:57:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-22 14:57:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-22 14:57:22 --> Pagination Class Initialized
INFO - 2018-02-22 14:57:22 --> Helper loaded: form_helper
INFO - 2018-02-22 14:57:22 --> Form Validation Class Initialized
INFO - 2018-02-22 14:57:22 --> Model Class Initialized
INFO - 2018-02-22 14:57:22 --> Controller Class Initialized
INFO - 2018-02-22 14:57:22 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-22 14:57:22 --> Model Class Initialized
INFO - 2018-02-22 14:57:22 --> Model Class Initialized
INFO - 2018-02-22 14:57:22 --> Model Class Initialized
INFO - 2018-02-22 14:57:22 --> Model Class Initialized
DEBUG - 2018-02-22 14:57:22 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-22 14:57:22 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-02-22 14:57:22 --> Config Class Initialized
INFO - 2018-02-22 14:57:22 --> Hooks Class Initialized
DEBUG - 2018-02-22 14:57:22 --> UTF-8 Support Enabled
INFO - 2018-02-22 14:57:22 --> Utf8 Class Initialized
INFO - 2018-02-22 14:57:22 --> URI Class Initialized
INFO - 2018-02-22 14:57:22 --> Router Class Initialized
INFO - 2018-02-22 14:57:22 --> Output Class Initialized
INFO - 2018-02-22 14:57:22 --> Security Class Initialized
DEBUG - 2018-02-22 14:57:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-22 14:57:22 --> Input Class Initialized
INFO - 2018-02-22 14:57:22 --> Language Class Initialized
INFO - 2018-02-22 14:57:22 --> Loader Class Initialized
INFO - 2018-02-22 14:57:22 --> Helper loaded: url_helper
INFO - 2018-02-22 14:57:22 --> Helper loaded: file_helper
INFO - 2018-02-22 14:57:22 --> Helper loaded: email_helper
INFO - 2018-02-22 14:57:22 --> Helper loaded: common_helper
INFO - 2018-02-22 14:57:22 --> Database Driver Class Initialized
DEBUG - 2018-02-22 14:57:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-22 14:57:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-22 14:57:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-22 14:57:22 --> Pagination Class Initialized
INFO - 2018-02-22 14:57:22 --> Helper loaded: form_helper
INFO - 2018-02-22 14:57:22 --> Form Validation Class Initialized
INFO - 2018-02-22 14:57:22 --> Model Class Initialized
INFO - 2018-02-22 14:57:22 --> Controller Class Initialized
INFO - 2018-02-22 14:57:22 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-22 14:57:22 --> Model Class Initialized
INFO - 2018-02-22 14:57:22 --> Model Class Initialized
INFO - 2018-02-22 14:57:22 --> Model Class Initialized
INFO - 2018-02-22 14:57:22 --> Model Class Initialized
INFO - 2018-02-22 14:57:22 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-22 14:57:22 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-22 14:57:22 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-22 14:57:22 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-22 14:57:22 --> File loaded: /var/www/html/project/radio/application/views/tracks/index.php
INFO - 2018-02-22 14:57:22 --> Final output sent to browser
DEBUG - 2018-02-22 14:57:22 --> Total execution time: 0.0045
INFO - 2018-02-22 14:57:22 --> Config Class Initialized
INFO - 2018-02-22 14:57:22 --> Hooks Class Initialized
DEBUG - 2018-02-22 14:57:22 --> UTF-8 Support Enabled
INFO - 2018-02-22 14:57:22 --> Utf8 Class Initialized
INFO - 2018-02-22 14:57:22 --> URI Class Initialized
INFO - 2018-02-22 14:57:22 --> Router Class Initialized
INFO - 2018-02-22 14:57:22 --> Output Class Initialized
INFO - 2018-02-22 14:57:22 --> Security Class Initialized
DEBUG - 2018-02-22 14:57:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-22 14:57:22 --> Input Class Initialized
INFO - 2018-02-22 14:57:22 --> Language Class Initialized
INFO - 2018-02-22 14:57:22 --> Loader Class Initialized
INFO - 2018-02-22 14:57:22 --> Helper loaded: url_helper
INFO - 2018-02-22 14:57:22 --> Helper loaded: file_helper
INFO - 2018-02-22 14:57:22 --> Helper loaded: email_helper
INFO - 2018-02-22 14:57:22 --> Helper loaded: common_helper
INFO - 2018-02-22 14:57:22 --> Database Driver Class Initialized
DEBUG - 2018-02-22 14:57:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-22 14:57:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-22 14:57:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-22 14:57:22 --> Pagination Class Initialized
INFO - 2018-02-22 14:57:22 --> Helper loaded: form_helper
INFO - 2018-02-22 14:57:22 --> Form Validation Class Initialized
INFO - 2018-02-22 14:57:22 --> Model Class Initialized
INFO - 2018-02-22 14:57:22 --> Controller Class Initialized
INFO - 2018-02-22 14:57:22 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-22 14:57:22 --> Model Class Initialized
INFO - 2018-02-22 14:57:22 --> Model Class Initialized
INFO - 2018-02-22 14:57:22 --> Model Class Initialized
INFO - 2018-02-22 14:57:22 --> Model Class Initialized
INFO - 2018-02-22 14:57:27 --> Config Class Initialized
INFO - 2018-02-22 14:57:27 --> Hooks Class Initialized
DEBUG - 2018-02-22 14:57:27 --> UTF-8 Support Enabled
INFO - 2018-02-22 14:57:27 --> Utf8 Class Initialized
INFO - 2018-02-22 14:57:27 --> URI Class Initialized
INFO - 2018-02-22 14:57:27 --> Router Class Initialized
INFO - 2018-02-22 14:57:27 --> Output Class Initialized
INFO - 2018-02-22 14:57:27 --> Security Class Initialized
DEBUG - 2018-02-22 14:57:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-22 14:57:27 --> Input Class Initialized
INFO - 2018-02-22 14:57:27 --> Language Class Initialized
INFO - 2018-02-22 14:57:27 --> Loader Class Initialized
INFO - 2018-02-22 14:57:27 --> Helper loaded: url_helper
INFO - 2018-02-22 14:57:27 --> Helper loaded: file_helper
INFO - 2018-02-22 14:57:27 --> Helper loaded: email_helper
INFO - 2018-02-22 14:57:27 --> Helper loaded: common_helper
INFO - 2018-02-22 14:57:27 --> Database Driver Class Initialized
DEBUG - 2018-02-22 14:57:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-22 14:57:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-22 14:57:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-22 14:57:27 --> Pagination Class Initialized
INFO - 2018-02-22 14:57:27 --> Helper loaded: form_helper
INFO - 2018-02-22 14:57:27 --> Form Validation Class Initialized
INFO - 2018-02-22 14:57:27 --> Model Class Initialized
INFO - 2018-02-22 14:57:27 --> Controller Class Initialized
DEBUG - 2018-02-22 14:57:27 --> Config file loaded: /var/www/html/project/radio/application/config/rest.php
INFO - 2018-02-22 14:57:27 --> Helper loaded: inflector_helper
INFO - 2018-02-22 14:57:27 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-22 14:57:27 --> Model Class Initialized
INFO - 2018-02-22 14:57:27 --> Model Class Initialized
INFO - 2018-02-22 14:57:27 --> Model Class Initialized
INFO - 2018-02-22 14:57:27 --> Model Class Initialized
INFO - 2018-02-22 14:57:27 --> Model Class Initialized
INFO - 2018-02-22 14:57:27 --> Model Class Initialized
INFO - 2018-02-22 14:57:59 --> Config Class Initialized
INFO - 2018-02-22 14:57:59 --> Hooks Class Initialized
DEBUG - 2018-02-22 14:57:59 --> UTF-8 Support Enabled
INFO - 2018-02-22 14:57:59 --> Utf8 Class Initialized
INFO - 2018-02-22 14:57:59 --> URI Class Initialized
INFO - 2018-02-22 14:57:59 --> Router Class Initialized
INFO - 2018-02-22 14:57:59 --> Output Class Initialized
INFO - 2018-02-22 14:57:59 --> Security Class Initialized
DEBUG - 2018-02-22 14:57:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-22 14:57:59 --> Input Class Initialized
INFO - 2018-02-22 14:57:59 --> Language Class Initialized
INFO - 2018-02-22 14:57:59 --> Loader Class Initialized
INFO - 2018-02-22 14:57:59 --> Helper loaded: url_helper
INFO - 2018-02-22 14:57:59 --> Helper loaded: file_helper
INFO - 2018-02-22 14:57:59 --> Helper loaded: email_helper
INFO - 2018-02-22 14:57:59 --> Helper loaded: common_helper
INFO - 2018-02-22 14:57:59 --> Database Driver Class Initialized
DEBUG - 2018-02-22 14:57:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-22 14:57:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-22 14:57:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-22 14:57:59 --> Pagination Class Initialized
INFO - 2018-02-22 14:57:59 --> Helper loaded: form_helper
INFO - 2018-02-22 14:57:59 --> Form Validation Class Initialized
INFO - 2018-02-22 14:57:59 --> Model Class Initialized
INFO - 2018-02-22 14:57:59 --> Controller Class Initialized
DEBUG - 2018-02-22 14:57:59 --> Config file loaded: /var/www/html/project/radio/application/config/rest.php
INFO - 2018-02-22 14:57:59 --> Helper loaded: inflector_helper
INFO - 2018-02-22 14:57:59 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-22 14:57:59 --> Model Class Initialized
INFO - 2018-02-22 14:57:59 --> Model Class Initialized
INFO - 2018-02-22 14:57:59 --> Model Class Initialized
INFO - 2018-02-22 14:57:59 --> Model Class Initialized
INFO - 2018-02-22 14:57:59 --> Model Class Initialized
INFO - 2018-02-22 14:57:59 --> Model Class Initialized
INFO - 2018-02-22 15:00:35 --> Config Class Initialized
INFO - 2018-02-22 15:00:35 --> Hooks Class Initialized
DEBUG - 2018-02-22 15:00:35 --> UTF-8 Support Enabled
INFO - 2018-02-22 15:00:35 --> Utf8 Class Initialized
INFO - 2018-02-22 15:00:35 --> URI Class Initialized
INFO - 2018-02-22 15:00:35 --> Router Class Initialized
INFO - 2018-02-22 15:00:35 --> Output Class Initialized
INFO - 2018-02-22 15:00:35 --> Security Class Initialized
DEBUG - 2018-02-22 15:00:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-22 15:00:35 --> Input Class Initialized
INFO - 2018-02-22 15:00:35 --> Language Class Initialized
INFO - 2018-02-22 15:00:35 --> Loader Class Initialized
INFO - 2018-02-22 15:00:35 --> Helper loaded: url_helper
INFO - 2018-02-22 15:00:35 --> Helper loaded: file_helper
INFO - 2018-02-22 15:00:35 --> Helper loaded: email_helper
INFO - 2018-02-22 15:00:35 --> Helper loaded: common_helper
INFO - 2018-02-22 15:00:35 --> Database Driver Class Initialized
DEBUG - 2018-02-22 15:00:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-22 15:00:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-22 15:00:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-22 15:00:36 --> Pagination Class Initialized
INFO - 2018-02-22 15:00:36 --> Helper loaded: form_helper
INFO - 2018-02-22 15:00:36 --> Form Validation Class Initialized
INFO - 2018-02-22 15:00:36 --> Model Class Initialized
INFO - 2018-02-22 15:00:36 --> Controller Class Initialized
DEBUG - 2018-02-22 15:00:36 --> Config file loaded: /var/www/html/project/radio/application/config/rest.php
INFO - 2018-02-22 15:00:36 --> Helper loaded: inflector_helper
INFO - 2018-02-22 15:00:36 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-22 15:00:36 --> Model Class Initialized
INFO - 2018-02-22 15:00:36 --> Model Class Initialized
INFO - 2018-02-22 15:00:36 --> Model Class Initialized
INFO - 2018-02-22 15:00:36 --> Model Class Initialized
INFO - 2018-02-22 15:00:36 --> Model Class Initialized
INFO - 2018-02-22 15:00:36 --> Model Class Initialized
INFO - 2018-02-22 15:00:36 --> Final output sent to browser
DEBUG - 2018-02-22 15:00:36 --> Total execution time: 0.0100
INFO - 2018-02-22 15:01:34 --> Config Class Initialized
INFO - 2018-02-22 15:01:34 --> Hooks Class Initialized
DEBUG - 2018-02-22 15:01:34 --> UTF-8 Support Enabled
INFO - 2018-02-22 15:01:34 --> Utf8 Class Initialized
INFO - 2018-02-22 15:01:34 --> URI Class Initialized
INFO - 2018-02-22 15:01:34 --> Router Class Initialized
INFO - 2018-02-22 15:01:34 --> Output Class Initialized
INFO - 2018-02-22 15:01:34 --> Security Class Initialized
DEBUG - 2018-02-22 15:01:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-22 15:01:34 --> Input Class Initialized
INFO - 2018-02-22 15:01:34 --> Language Class Initialized
INFO - 2018-02-22 15:01:34 --> Loader Class Initialized
INFO - 2018-02-22 15:01:34 --> Helper loaded: url_helper
INFO - 2018-02-22 15:01:34 --> Helper loaded: file_helper
INFO - 2018-02-22 15:01:34 --> Helper loaded: email_helper
INFO - 2018-02-22 15:01:34 --> Helper loaded: common_helper
INFO - 2018-02-22 15:01:34 --> Database Driver Class Initialized
DEBUG - 2018-02-22 15:01:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-22 15:01:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-22 15:01:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-22 15:01:34 --> Pagination Class Initialized
INFO - 2018-02-22 15:01:34 --> Helper loaded: form_helper
INFO - 2018-02-22 15:01:34 --> Form Validation Class Initialized
INFO - 2018-02-22 15:01:34 --> Model Class Initialized
INFO - 2018-02-22 15:01:34 --> Controller Class Initialized
DEBUG - 2018-02-22 15:01:34 --> Config file loaded: /var/www/html/project/radio/application/config/rest.php
INFO - 2018-02-22 15:01:34 --> Helper loaded: inflector_helper
INFO - 2018-02-22 15:01:34 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-22 15:01:34 --> Model Class Initialized
INFO - 2018-02-22 15:01:34 --> Model Class Initialized
INFO - 2018-02-22 15:01:34 --> Model Class Initialized
INFO - 2018-02-22 15:01:34 --> Model Class Initialized
INFO - 2018-02-22 15:01:34 --> Model Class Initialized
INFO - 2018-02-22 15:01:34 --> Model Class Initialized
INFO - 2018-02-22 15:01:58 --> Config Class Initialized
INFO - 2018-02-22 15:01:58 --> Hooks Class Initialized
DEBUG - 2018-02-22 15:01:58 --> UTF-8 Support Enabled
INFO - 2018-02-22 15:01:58 --> Utf8 Class Initialized
INFO - 2018-02-22 15:01:58 --> URI Class Initialized
INFO - 2018-02-22 15:01:58 --> Router Class Initialized
INFO - 2018-02-22 15:01:58 --> Output Class Initialized
INFO - 2018-02-22 15:01:58 --> Security Class Initialized
DEBUG - 2018-02-22 15:01:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-22 15:01:58 --> Input Class Initialized
INFO - 2018-02-22 15:01:58 --> Language Class Initialized
INFO - 2018-02-22 15:01:58 --> Loader Class Initialized
INFO - 2018-02-22 15:01:58 --> Helper loaded: url_helper
INFO - 2018-02-22 15:01:58 --> Helper loaded: file_helper
INFO - 2018-02-22 15:01:58 --> Helper loaded: email_helper
INFO - 2018-02-22 15:01:58 --> Helper loaded: common_helper
INFO - 2018-02-22 15:01:58 --> Database Driver Class Initialized
DEBUG - 2018-02-22 15:01:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-22 15:01:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-22 15:01:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-22 15:01:58 --> Pagination Class Initialized
INFO - 2018-02-22 15:01:58 --> Helper loaded: form_helper
INFO - 2018-02-22 15:01:58 --> Form Validation Class Initialized
INFO - 2018-02-22 15:01:58 --> Model Class Initialized
INFO - 2018-02-22 15:01:58 --> Controller Class Initialized
DEBUG - 2018-02-22 15:01:58 --> Config file loaded: /var/www/html/project/radio/application/config/rest.php
INFO - 2018-02-22 15:01:58 --> Helper loaded: inflector_helper
INFO - 2018-02-22 15:01:58 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-22 15:01:58 --> Model Class Initialized
INFO - 2018-02-22 15:01:58 --> Model Class Initialized
INFO - 2018-02-22 15:01:58 --> Model Class Initialized
INFO - 2018-02-22 15:01:58 --> Model Class Initialized
INFO - 2018-02-22 15:01:58 --> Model Class Initialized
INFO - 2018-02-22 15:01:58 --> Model Class Initialized
INFO - 2018-02-22 15:03:24 --> Config Class Initialized
INFO - 2018-02-22 15:03:24 --> Hooks Class Initialized
DEBUG - 2018-02-22 15:03:24 --> UTF-8 Support Enabled
INFO - 2018-02-22 15:03:24 --> Utf8 Class Initialized
INFO - 2018-02-22 15:03:24 --> URI Class Initialized
INFO - 2018-02-22 15:03:24 --> Router Class Initialized
INFO - 2018-02-22 15:03:24 --> Output Class Initialized
INFO - 2018-02-22 15:03:24 --> Security Class Initialized
DEBUG - 2018-02-22 15:03:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-22 15:03:24 --> Input Class Initialized
INFO - 2018-02-22 15:03:24 --> Language Class Initialized
INFO - 2018-02-22 15:03:24 --> Loader Class Initialized
INFO - 2018-02-22 15:03:24 --> Helper loaded: url_helper
INFO - 2018-02-22 15:03:24 --> Helper loaded: file_helper
INFO - 2018-02-22 15:03:24 --> Helper loaded: email_helper
INFO - 2018-02-22 15:03:24 --> Helper loaded: common_helper
INFO - 2018-02-22 15:03:24 --> Database Driver Class Initialized
DEBUG - 2018-02-22 15:03:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-22 15:03:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-22 15:03:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-22 15:03:24 --> Pagination Class Initialized
INFO - 2018-02-22 15:03:24 --> Helper loaded: form_helper
INFO - 2018-02-22 15:03:24 --> Form Validation Class Initialized
INFO - 2018-02-22 15:03:24 --> Model Class Initialized
INFO - 2018-02-22 15:03:24 --> Controller Class Initialized
DEBUG - 2018-02-22 15:03:24 --> Config file loaded: /var/www/html/project/radio/application/config/rest.php
INFO - 2018-02-22 15:03:24 --> Helper loaded: inflector_helper
INFO - 2018-02-22 15:03:24 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-22 15:03:24 --> Model Class Initialized
INFO - 2018-02-22 15:03:24 --> Model Class Initialized
INFO - 2018-02-22 15:03:24 --> Model Class Initialized
INFO - 2018-02-22 15:03:24 --> Model Class Initialized
INFO - 2018-02-22 15:03:24 --> Model Class Initialized
INFO - 2018-02-22 15:03:24 --> Model Class Initialized
INFO - 2018-02-22 15:03:24 --> Final output sent to browser
DEBUG - 2018-02-22 15:03:24 --> Total execution time: 0.0097
INFO - 2018-02-22 15:04:44 --> Config Class Initialized
INFO - 2018-02-22 15:04:44 --> Hooks Class Initialized
DEBUG - 2018-02-22 15:04:44 --> UTF-8 Support Enabled
INFO - 2018-02-22 15:04:44 --> Utf8 Class Initialized
INFO - 2018-02-22 15:04:44 --> URI Class Initialized
INFO - 2018-02-22 15:04:44 --> Router Class Initialized
INFO - 2018-02-22 15:04:44 --> Output Class Initialized
INFO - 2018-02-22 15:04:44 --> Security Class Initialized
DEBUG - 2018-02-22 15:04:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-22 15:04:44 --> Input Class Initialized
INFO - 2018-02-22 15:04:44 --> Language Class Initialized
INFO - 2018-02-22 15:04:44 --> Loader Class Initialized
INFO - 2018-02-22 15:04:44 --> Helper loaded: url_helper
INFO - 2018-02-22 15:04:44 --> Helper loaded: file_helper
INFO - 2018-02-22 15:04:44 --> Helper loaded: email_helper
INFO - 2018-02-22 15:04:44 --> Helper loaded: common_helper
INFO - 2018-02-22 15:04:44 --> Database Driver Class Initialized
DEBUG - 2018-02-22 15:04:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-22 15:04:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-22 15:04:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-22 15:04:44 --> Pagination Class Initialized
INFO - 2018-02-22 15:04:44 --> Helper loaded: form_helper
INFO - 2018-02-22 15:04:44 --> Form Validation Class Initialized
INFO - 2018-02-22 15:04:44 --> Model Class Initialized
INFO - 2018-02-22 15:04:44 --> Controller Class Initialized
INFO - 2018-02-22 15:04:44 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-22 15:04:44 --> Model Class Initialized
INFO - 2018-02-22 15:04:44 --> Model Class Initialized
INFO - 2018-02-22 15:04:44 --> Config Class Initialized
INFO - 2018-02-22 15:04:44 --> Hooks Class Initialized
DEBUG - 2018-02-22 15:04:44 --> UTF-8 Support Enabled
INFO - 2018-02-22 15:04:44 --> Utf8 Class Initialized
INFO - 2018-02-22 15:04:44 --> URI Class Initialized
INFO - 2018-02-22 15:04:44 --> Router Class Initialized
INFO - 2018-02-22 15:04:44 --> Output Class Initialized
INFO - 2018-02-22 15:04:44 --> Security Class Initialized
DEBUG - 2018-02-22 15:04:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-22 15:04:44 --> Input Class Initialized
INFO - 2018-02-22 15:04:44 --> Language Class Initialized
INFO - 2018-02-22 15:04:44 --> Loader Class Initialized
INFO - 2018-02-22 15:04:44 --> Helper loaded: url_helper
INFO - 2018-02-22 15:04:44 --> Helper loaded: file_helper
INFO - 2018-02-22 15:04:44 --> Helper loaded: email_helper
INFO - 2018-02-22 15:04:44 --> Helper loaded: common_helper
INFO - 2018-02-22 15:04:44 --> Database Driver Class Initialized
DEBUG - 2018-02-22 15:04:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-22 15:04:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-22 15:04:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-22 15:04:44 --> Pagination Class Initialized
INFO - 2018-02-22 15:04:44 --> Helper loaded: form_helper
INFO - 2018-02-22 15:04:44 --> Form Validation Class Initialized
INFO - 2018-02-22 15:04:44 --> Model Class Initialized
INFO - 2018-02-22 15:04:44 --> Controller Class Initialized
INFO - 2018-02-22 15:04:44 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-22 15:04:44 --> Model Class Initialized
INFO - 2018-02-22 15:04:44 --> Model Class Initialized
INFO - 2018-02-22 15:04:44 --> File loaded: /var/www/html/project/radio/application/views/index/index.php
INFO - 2018-02-22 15:04:44 --> Final output sent to browser
DEBUG - 2018-02-22 15:04:44 --> Total execution time: 0.0038
INFO - 2018-02-22 15:05:10 --> Config Class Initialized
INFO - 2018-02-22 15:05:10 --> Hooks Class Initialized
DEBUG - 2018-02-22 15:05:10 --> UTF-8 Support Enabled
INFO - 2018-02-22 15:05:10 --> Utf8 Class Initialized
INFO - 2018-02-22 15:05:10 --> URI Class Initialized
INFO - 2018-02-22 15:05:10 --> Router Class Initialized
INFO - 2018-02-22 15:05:10 --> Output Class Initialized
INFO - 2018-02-22 15:05:10 --> Security Class Initialized
DEBUG - 2018-02-22 15:05:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-22 15:05:10 --> Input Class Initialized
INFO - 2018-02-22 15:05:10 --> Language Class Initialized
INFO - 2018-02-22 15:05:10 --> Loader Class Initialized
INFO - 2018-02-22 15:05:10 --> Helper loaded: url_helper
INFO - 2018-02-22 15:05:10 --> Helper loaded: file_helper
INFO - 2018-02-22 15:05:10 --> Helper loaded: email_helper
INFO - 2018-02-22 15:05:10 --> Helper loaded: common_helper
INFO - 2018-02-22 15:05:10 --> Database Driver Class Initialized
DEBUG - 2018-02-22 15:05:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-22 15:05:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-22 15:05:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-22 15:05:10 --> Pagination Class Initialized
INFO - 2018-02-22 15:05:10 --> Helper loaded: form_helper
INFO - 2018-02-22 15:05:10 --> Form Validation Class Initialized
INFO - 2018-02-22 15:05:10 --> Model Class Initialized
INFO - 2018-02-22 15:05:10 --> Controller Class Initialized
INFO - 2018-02-22 15:05:10 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-22 15:05:10 --> Model Class Initialized
INFO - 2018-02-22 15:05:10 --> Model Class Initialized
ERROR - 2018-02-22 15:05:10 --> Severity: Notice --> Undefined index: remember_me /var/www/html/project/radio/application/controllers/Index.php 74
INFO - 2018-02-22 15:05:10 --> Config Class Initialized
INFO - 2018-02-22 15:05:10 --> Hooks Class Initialized
DEBUG - 2018-02-22 15:05:10 --> UTF-8 Support Enabled
INFO - 2018-02-22 15:05:10 --> Utf8 Class Initialized
INFO - 2018-02-22 15:05:10 --> URI Class Initialized
INFO - 2018-02-22 15:05:10 --> Router Class Initialized
INFO - 2018-02-22 15:05:10 --> Output Class Initialized
INFO - 2018-02-22 15:05:10 --> Security Class Initialized
DEBUG - 2018-02-22 15:05:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-22 15:05:10 --> Input Class Initialized
INFO - 2018-02-22 15:05:10 --> Language Class Initialized
INFO - 2018-02-22 15:05:10 --> Loader Class Initialized
INFO - 2018-02-22 15:05:10 --> Helper loaded: url_helper
INFO - 2018-02-22 15:05:10 --> Helper loaded: file_helper
INFO - 2018-02-22 15:05:10 --> Helper loaded: email_helper
INFO - 2018-02-22 15:05:10 --> Helper loaded: common_helper
INFO - 2018-02-22 15:05:10 --> Database Driver Class Initialized
DEBUG - 2018-02-22 15:05:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-22 15:05:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-22 15:05:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-22 15:05:10 --> Pagination Class Initialized
INFO - 2018-02-22 15:05:10 --> Helper loaded: form_helper
INFO - 2018-02-22 15:05:10 --> Form Validation Class Initialized
INFO - 2018-02-22 15:05:10 --> Model Class Initialized
INFO - 2018-02-22 15:05:10 --> Controller Class Initialized
INFO - 2018-02-22 15:05:10 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-22 15:05:10 --> Model Class Initialized
INFO - 2018-02-22 15:05:10 --> Model Class Initialized
INFO - 2018-02-22 15:05:10 --> Model Class Initialized
INFO - 2018-02-22 15:05:10 --> Model Class Initialized
INFO - 2018-02-22 15:05:10 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-22 15:05:10 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-22 15:05:10 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-22 15:05:10 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-22 15:05:10 --> File loaded: /var/www/html/project/radio/application/views/dashboard/index.php
INFO - 2018-02-22 15:05:10 --> Final output sent to browser
DEBUG - 2018-02-22 15:05:10 --> Total execution time: 0.0066
INFO - 2018-02-22 15:05:12 --> Config Class Initialized
INFO - 2018-02-22 15:05:12 --> Hooks Class Initialized
DEBUG - 2018-02-22 15:05:12 --> UTF-8 Support Enabled
INFO - 2018-02-22 15:05:12 --> Utf8 Class Initialized
INFO - 2018-02-22 15:05:12 --> URI Class Initialized
INFO - 2018-02-22 15:05:12 --> Router Class Initialized
INFO - 2018-02-22 15:05:12 --> Output Class Initialized
INFO - 2018-02-22 15:05:12 --> Security Class Initialized
DEBUG - 2018-02-22 15:05:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-22 15:05:12 --> Input Class Initialized
INFO - 2018-02-22 15:05:12 --> Language Class Initialized
INFO - 2018-02-22 15:05:12 --> Loader Class Initialized
INFO - 2018-02-22 15:05:12 --> Helper loaded: url_helper
INFO - 2018-02-22 15:05:12 --> Helper loaded: file_helper
INFO - 2018-02-22 15:05:12 --> Helper loaded: email_helper
INFO - 2018-02-22 15:05:12 --> Helper loaded: common_helper
INFO - 2018-02-22 15:05:12 --> Database Driver Class Initialized
DEBUG - 2018-02-22 15:05:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-22 15:05:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-22 15:05:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-22 15:05:12 --> Pagination Class Initialized
INFO - 2018-02-22 15:05:12 --> Helper loaded: form_helper
INFO - 2018-02-22 15:05:12 --> Form Validation Class Initialized
INFO - 2018-02-22 15:05:12 --> Model Class Initialized
INFO - 2018-02-22 15:05:12 --> Controller Class Initialized
INFO - 2018-02-22 15:05:12 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-22 15:05:12 --> Model Class Initialized
INFO - 2018-02-22 15:05:12 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-22 15:05:12 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-22 15:05:12 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-22 15:05:12 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-22 15:05:12 --> File loaded: /var/www/html/project/radio/application/views/category/index.php
INFO - 2018-02-22 15:05:12 --> Final output sent to browser
DEBUG - 2018-02-22 15:05:12 --> Total execution time: 0.0230
INFO - 2018-02-22 15:05:25 --> Config Class Initialized
INFO - 2018-02-22 15:05:25 --> Hooks Class Initialized
DEBUG - 2018-02-22 15:05:25 --> UTF-8 Support Enabled
INFO - 2018-02-22 15:05:25 --> Utf8 Class Initialized
INFO - 2018-02-22 15:05:25 --> URI Class Initialized
INFO - 2018-02-22 15:05:25 --> Router Class Initialized
INFO - 2018-02-22 15:05:25 --> Output Class Initialized
INFO - 2018-02-22 15:05:25 --> Security Class Initialized
DEBUG - 2018-02-22 15:05:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-22 15:05:25 --> Input Class Initialized
INFO - 2018-02-22 15:05:25 --> Language Class Initialized
INFO - 2018-02-22 15:05:25 --> Loader Class Initialized
INFO - 2018-02-22 15:05:25 --> Helper loaded: url_helper
INFO - 2018-02-22 15:05:25 --> Helper loaded: file_helper
INFO - 2018-02-22 15:05:25 --> Helper loaded: email_helper
INFO - 2018-02-22 15:05:25 --> Helper loaded: common_helper
INFO - 2018-02-22 15:05:25 --> Database Driver Class Initialized
DEBUG - 2018-02-22 15:05:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-22 15:05:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-22 15:05:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-22 15:05:25 --> Pagination Class Initialized
INFO - 2018-02-22 15:05:25 --> Helper loaded: form_helper
INFO - 2018-02-22 15:05:25 --> Form Validation Class Initialized
INFO - 2018-02-22 15:05:25 --> Model Class Initialized
INFO - 2018-02-22 15:05:25 --> Controller Class Initialized
INFO - 2018-02-22 15:05:25 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-22 15:05:25 --> Model Class Initialized
INFO - 2018-02-22 15:05:25 --> Model Class Initialized
INFO - 2018-02-22 15:05:25 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-22 15:05:25 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-22 15:05:25 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-22 15:05:25 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-22 15:05:25 --> File loaded: /var/www/html/project/radio/application/views/subcategory/index.php
INFO - 2018-02-22 15:05:25 --> Final output sent to browser
DEBUG - 2018-02-22 15:05:25 --> Total execution time: 0.0206
INFO - 2018-02-22 15:05:27 --> Config Class Initialized
INFO - 2018-02-22 15:05:27 --> Hooks Class Initialized
DEBUG - 2018-02-22 15:05:27 --> UTF-8 Support Enabled
INFO - 2018-02-22 15:05:27 --> Utf8 Class Initialized
INFO - 2018-02-22 15:05:27 --> URI Class Initialized
INFO - 2018-02-22 15:05:27 --> Router Class Initialized
INFO - 2018-02-22 15:05:27 --> Output Class Initialized
INFO - 2018-02-22 15:05:27 --> Security Class Initialized
DEBUG - 2018-02-22 15:05:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-22 15:05:27 --> Input Class Initialized
INFO - 2018-02-22 15:05:27 --> Language Class Initialized
INFO - 2018-02-22 15:05:27 --> Loader Class Initialized
INFO - 2018-02-22 15:05:27 --> Helper loaded: url_helper
INFO - 2018-02-22 15:05:27 --> Helper loaded: file_helper
INFO - 2018-02-22 15:05:27 --> Helper loaded: email_helper
INFO - 2018-02-22 15:05:27 --> Helper loaded: common_helper
INFO - 2018-02-22 15:05:27 --> Database Driver Class Initialized
DEBUG - 2018-02-22 15:05:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-22 15:05:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-22 15:05:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-22 15:05:27 --> Pagination Class Initialized
INFO - 2018-02-22 15:05:27 --> Helper loaded: form_helper
INFO - 2018-02-22 15:05:27 --> Form Validation Class Initialized
INFO - 2018-02-22 15:05:27 --> Model Class Initialized
INFO - 2018-02-22 15:05:27 --> Controller Class Initialized
INFO - 2018-02-22 15:05:27 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-22 15:05:27 --> Model Class Initialized
INFO - 2018-02-22 15:05:27 --> Model Class Initialized
INFO - 2018-02-22 15:05:27 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-22 15:05:27 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-22 15:05:27 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-22 15:05:27 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-22 15:05:27 --> File loaded: /var/www/html/project/radio/application/views/subcategory/add_edit.php
INFO - 2018-02-22 15:05:27 --> Final output sent to browser
DEBUG - 2018-02-22 15:05:27 --> Total execution time: 0.0064
INFO - 2018-02-22 15:05:33 --> Config Class Initialized
INFO - 2018-02-22 15:05:33 --> Hooks Class Initialized
DEBUG - 2018-02-22 15:05:33 --> UTF-8 Support Enabled
INFO - 2018-02-22 15:05:33 --> Utf8 Class Initialized
INFO - 2018-02-22 15:05:33 --> URI Class Initialized
INFO - 2018-02-22 15:05:33 --> Router Class Initialized
INFO - 2018-02-22 15:05:33 --> Output Class Initialized
INFO - 2018-02-22 15:05:33 --> Security Class Initialized
DEBUG - 2018-02-22 15:05:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-22 15:05:33 --> Input Class Initialized
INFO - 2018-02-22 15:05:33 --> Language Class Initialized
INFO - 2018-02-22 15:05:33 --> Loader Class Initialized
INFO - 2018-02-22 15:05:33 --> Helper loaded: url_helper
INFO - 2018-02-22 15:05:33 --> Helper loaded: file_helper
INFO - 2018-02-22 15:05:33 --> Helper loaded: email_helper
INFO - 2018-02-22 15:05:33 --> Helper loaded: common_helper
INFO - 2018-02-22 15:05:33 --> Database Driver Class Initialized
DEBUG - 2018-02-22 15:05:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-22 15:05:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-22 15:05:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-22 15:05:33 --> Pagination Class Initialized
INFO - 2018-02-22 15:05:33 --> Helper loaded: form_helper
INFO - 2018-02-22 15:05:33 --> Form Validation Class Initialized
INFO - 2018-02-22 15:05:33 --> Model Class Initialized
INFO - 2018-02-22 15:05:33 --> Controller Class Initialized
INFO - 2018-02-22 15:05:33 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-22 15:05:33 --> Model Class Initialized
INFO - 2018-02-22 15:05:33 --> Model Class Initialized
INFO - 2018-02-22 15:05:33 --> Config Class Initialized
INFO - 2018-02-22 15:05:33 --> Hooks Class Initialized
DEBUG - 2018-02-22 15:05:33 --> UTF-8 Support Enabled
INFO - 2018-02-22 15:05:33 --> Utf8 Class Initialized
INFO - 2018-02-22 15:05:33 --> URI Class Initialized
INFO - 2018-02-22 15:05:33 --> Router Class Initialized
INFO - 2018-02-22 15:05:33 --> Output Class Initialized
INFO - 2018-02-22 15:05:33 --> Security Class Initialized
DEBUG - 2018-02-22 15:05:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-22 15:05:33 --> Input Class Initialized
INFO - 2018-02-22 15:05:33 --> Language Class Initialized
INFO - 2018-02-22 15:05:33 --> Loader Class Initialized
INFO - 2018-02-22 15:05:33 --> Helper loaded: url_helper
INFO - 2018-02-22 15:05:33 --> Helper loaded: file_helper
INFO - 2018-02-22 15:05:33 --> Helper loaded: email_helper
INFO - 2018-02-22 15:05:33 --> Helper loaded: common_helper
INFO - 2018-02-22 15:05:33 --> Database Driver Class Initialized
DEBUG - 2018-02-22 15:05:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-22 15:05:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-22 15:05:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-22 15:05:33 --> Pagination Class Initialized
INFO - 2018-02-22 15:05:33 --> Helper loaded: form_helper
INFO - 2018-02-22 15:05:33 --> Form Validation Class Initialized
INFO - 2018-02-22 15:05:33 --> Model Class Initialized
INFO - 2018-02-22 15:05:33 --> Controller Class Initialized
INFO - 2018-02-22 15:05:33 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-22 15:05:33 --> Model Class Initialized
INFO - 2018-02-22 15:05:33 --> Model Class Initialized
DEBUG - 2018-02-22 15:05:33 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-22 15:05:33 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-02-22 15:05:33 --> Config Class Initialized
INFO - 2018-02-22 15:05:33 --> Hooks Class Initialized
DEBUG - 2018-02-22 15:05:33 --> UTF-8 Support Enabled
INFO - 2018-02-22 15:05:33 --> Utf8 Class Initialized
INFO - 2018-02-22 15:05:33 --> URI Class Initialized
INFO - 2018-02-22 15:05:33 --> Router Class Initialized
INFO - 2018-02-22 15:05:33 --> Output Class Initialized
INFO - 2018-02-22 15:05:33 --> Security Class Initialized
DEBUG - 2018-02-22 15:05:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-22 15:05:33 --> Input Class Initialized
INFO - 2018-02-22 15:05:33 --> Language Class Initialized
INFO - 2018-02-22 15:05:33 --> Loader Class Initialized
INFO - 2018-02-22 15:05:33 --> Helper loaded: url_helper
INFO - 2018-02-22 15:05:33 --> Helper loaded: file_helper
INFO - 2018-02-22 15:05:33 --> Helper loaded: email_helper
INFO - 2018-02-22 15:05:33 --> Helper loaded: common_helper
INFO - 2018-02-22 15:05:33 --> Database Driver Class Initialized
DEBUG - 2018-02-22 15:05:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-22 15:05:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-22 15:05:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-22 15:05:33 --> Pagination Class Initialized
INFO - 2018-02-22 15:05:33 --> Helper loaded: form_helper
INFO - 2018-02-22 15:05:33 --> Form Validation Class Initialized
INFO - 2018-02-22 15:05:33 --> Model Class Initialized
INFO - 2018-02-22 15:05:33 --> Controller Class Initialized
INFO - 2018-02-22 15:05:33 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-22 15:05:33 --> Model Class Initialized
INFO - 2018-02-22 15:05:33 --> Model Class Initialized
INFO - 2018-02-22 15:05:33 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-22 15:05:33 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-22 15:05:33 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-22 15:05:33 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-22 15:05:33 --> File loaded: /var/www/html/project/radio/application/views/subcategory/index.php
INFO - 2018-02-22 15:05:33 --> Final output sent to browser
DEBUG - 2018-02-22 15:05:33 --> Total execution time: 0.0081
INFO - 2018-02-22 15:05:51 --> Config Class Initialized
INFO - 2018-02-22 15:05:51 --> Hooks Class Initialized
DEBUG - 2018-02-22 15:05:51 --> UTF-8 Support Enabled
INFO - 2018-02-22 15:05:51 --> Utf8 Class Initialized
INFO - 2018-02-22 15:05:51 --> URI Class Initialized
INFO - 2018-02-22 15:05:51 --> Router Class Initialized
INFO - 2018-02-22 15:05:51 --> Output Class Initialized
INFO - 2018-02-22 15:05:51 --> Security Class Initialized
DEBUG - 2018-02-22 15:05:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-22 15:05:51 --> Input Class Initialized
INFO - 2018-02-22 15:05:51 --> Language Class Initialized
INFO - 2018-02-22 15:05:51 --> Loader Class Initialized
INFO - 2018-02-22 15:05:51 --> Helper loaded: url_helper
INFO - 2018-02-22 15:05:51 --> Helper loaded: file_helper
INFO - 2018-02-22 15:05:51 --> Helper loaded: email_helper
INFO - 2018-02-22 15:05:51 --> Helper loaded: common_helper
INFO - 2018-02-22 15:05:51 --> Database Driver Class Initialized
DEBUG - 2018-02-22 15:05:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-22 15:05:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-22 15:05:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-22 15:05:51 --> Pagination Class Initialized
INFO - 2018-02-22 15:05:51 --> Helper loaded: form_helper
INFO - 2018-02-22 15:05:51 --> Form Validation Class Initialized
INFO - 2018-02-22 15:05:51 --> Model Class Initialized
INFO - 2018-02-22 15:05:51 --> Controller Class Initialized
INFO - 2018-02-22 15:05:51 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-22 15:05:51 --> Model Class Initialized
INFO - 2018-02-22 15:05:51 --> Model Class Initialized
INFO - 2018-02-22 15:05:51 --> Model Class Initialized
INFO - 2018-02-22 15:05:51 --> Model Class Initialized
INFO - 2018-02-22 15:05:51 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-22 15:05:51 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-22 15:05:51 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-22 15:05:51 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-22 15:05:51 --> File loaded: /var/www/html/project/radio/application/views/tracks/index.php
INFO - 2018-02-22 15:05:51 --> Final output sent to browser
DEBUG - 2018-02-22 15:05:51 --> Total execution time: 0.0055
INFO - 2018-02-22 15:05:52 --> Config Class Initialized
INFO - 2018-02-22 15:05:52 --> Hooks Class Initialized
DEBUG - 2018-02-22 15:05:52 --> UTF-8 Support Enabled
INFO - 2018-02-22 15:05:52 --> Utf8 Class Initialized
INFO - 2018-02-22 15:05:52 --> URI Class Initialized
INFO - 2018-02-22 15:05:52 --> Router Class Initialized
INFO - 2018-02-22 15:05:52 --> Output Class Initialized
INFO - 2018-02-22 15:05:52 --> Security Class Initialized
DEBUG - 2018-02-22 15:05:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-22 15:05:52 --> Input Class Initialized
INFO - 2018-02-22 15:05:52 --> Language Class Initialized
INFO - 2018-02-22 15:05:52 --> Loader Class Initialized
INFO - 2018-02-22 15:05:52 --> Helper loaded: url_helper
INFO - 2018-02-22 15:05:52 --> Helper loaded: file_helper
INFO - 2018-02-22 15:05:52 --> Helper loaded: email_helper
INFO - 2018-02-22 15:05:52 --> Helper loaded: common_helper
INFO - 2018-02-22 15:05:52 --> Database Driver Class Initialized
DEBUG - 2018-02-22 15:05:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-22 15:05:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-22 15:05:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-22 15:05:52 --> Pagination Class Initialized
INFO - 2018-02-22 15:05:52 --> Helper loaded: form_helper
INFO - 2018-02-22 15:05:52 --> Form Validation Class Initialized
INFO - 2018-02-22 15:05:52 --> Model Class Initialized
INFO - 2018-02-22 15:05:52 --> Controller Class Initialized
INFO - 2018-02-22 15:05:52 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-22 15:05:52 --> Model Class Initialized
INFO - 2018-02-22 15:05:52 --> Model Class Initialized
INFO - 2018-02-22 15:05:52 --> Model Class Initialized
INFO - 2018-02-22 15:05:52 --> Model Class Initialized
INFO - 2018-02-22 15:05:57 --> Config Class Initialized
INFO - 2018-02-22 15:05:57 --> Hooks Class Initialized
DEBUG - 2018-02-22 15:05:57 --> UTF-8 Support Enabled
INFO - 2018-02-22 15:05:57 --> Utf8 Class Initialized
INFO - 2018-02-22 15:05:57 --> URI Class Initialized
INFO - 2018-02-22 15:05:57 --> Router Class Initialized
INFO - 2018-02-22 15:05:57 --> Output Class Initialized
INFO - 2018-02-22 15:05:57 --> Security Class Initialized
DEBUG - 2018-02-22 15:05:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-22 15:05:57 --> Input Class Initialized
INFO - 2018-02-22 15:05:57 --> Language Class Initialized
INFO - 2018-02-22 15:05:57 --> Loader Class Initialized
INFO - 2018-02-22 15:05:57 --> Helper loaded: url_helper
INFO - 2018-02-22 15:05:57 --> Helper loaded: file_helper
INFO - 2018-02-22 15:05:57 --> Helper loaded: email_helper
INFO - 2018-02-22 15:05:57 --> Helper loaded: common_helper
INFO - 2018-02-22 15:05:57 --> Database Driver Class Initialized
DEBUG - 2018-02-22 15:05:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-22 15:05:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-22 15:05:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-22 15:05:57 --> Pagination Class Initialized
INFO - 2018-02-22 15:05:57 --> Helper loaded: form_helper
INFO - 2018-02-22 15:05:57 --> Form Validation Class Initialized
INFO - 2018-02-22 15:05:57 --> Model Class Initialized
INFO - 2018-02-22 15:05:57 --> Controller Class Initialized
INFO - 2018-02-22 15:05:57 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-22 15:05:57 --> Model Class Initialized
INFO - 2018-02-22 15:05:57 --> Model Class Initialized
INFO - 2018-02-22 15:05:57 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-22 15:05:57 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-22 15:05:57 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-22 15:05:57 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-22 15:05:57 --> File loaded: /var/www/html/project/radio/application/views/subcategory/index.php
INFO - 2018-02-22 15:05:57 --> Final output sent to browser
DEBUG - 2018-02-22 15:05:57 --> Total execution time: 0.0066
INFO - 2018-02-22 15:06:22 --> Config Class Initialized
INFO - 2018-02-22 15:06:22 --> Hooks Class Initialized
DEBUG - 2018-02-22 15:06:22 --> UTF-8 Support Enabled
INFO - 2018-02-22 15:06:22 --> Utf8 Class Initialized
INFO - 2018-02-22 15:06:22 --> URI Class Initialized
INFO - 2018-02-22 15:06:22 --> Router Class Initialized
INFO - 2018-02-22 15:06:22 --> Output Class Initialized
INFO - 2018-02-22 15:06:22 --> Security Class Initialized
DEBUG - 2018-02-22 15:06:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-22 15:06:22 --> Input Class Initialized
INFO - 2018-02-22 15:06:22 --> Language Class Initialized
INFO - 2018-02-22 15:06:22 --> Loader Class Initialized
INFO - 2018-02-22 15:06:22 --> Helper loaded: url_helper
INFO - 2018-02-22 15:06:22 --> Helper loaded: file_helper
INFO - 2018-02-22 15:06:22 --> Helper loaded: email_helper
INFO - 2018-02-22 15:06:22 --> Helper loaded: common_helper
INFO - 2018-02-22 15:06:22 --> Database Driver Class Initialized
DEBUG - 2018-02-22 15:06:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-22 15:06:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-22 15:06:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-22 15:06:22 --> Pagination Class Initialized
INFO - 2018-02-22 15:06:22 --> Helper loaded: form_helper
INFO - 2018-02-22 15:06:22 --> Form Validation Class Initialized
INFO - 2018-02-22 15:06:22 --> Model Class Initialized
INFO - 2018-02-22 15:06:22 --> Controller Class Initialized
INFO - 2018-02-22 15:06:22 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-22 15:06:22 --> Model Class Initialized
INFO - 2018-02-22 15:06:22 --> Model Class Initialized
INFO - 2018-02-22 15:06:22 --> File loaded: /var/www/html/project/radio/application/views/index/index.php
INFO - 2018-02-22 15:06:22 --> Final output sent to browser
DEBUG - 2018-02-22 15:06:22 --> Total execution time: 0.0059
INFO - 2018-02-22 15:06:40 --> Config Class Initialized
INFO - 2018-02-22 15:06:40 --> Hooks Class Initialized
DEBUG - 2018-02-22 15:06:40 --> UTF-8 Support Enabled
INFO - 2018-02-22 15:06:40 --> Utf8 Class Initialized
INFO - 2018-02-22 15:06:40 --> URI Class Initialized
INFO - 2018-02-22 15:06:40 --> Router Class Initialized
INFO - 2018-02-22 15:06:40 --> Output Class Initialized
INFO - 2018-02-22 15:06:40 --> Security Class Initialized
DEBUG - 2018-02-22 15:06:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-22 15:06:40 --> Input Class Initialized
INFO - 2018-02-22 15:06:40 --> Language Class Initialized
INFO - 2018-02-22 15:06:40 --> Loader Class Initialized
INFO - 2018-02-22 15:06:40 --> Helper loaded: url_helper
INFO - 2018-02-22 15:06:40 --> Helper loaded: file_helper
INFO - 2018-02-22 15:06:40 --> Helper loaded: email_helper
INFO - 2018-02-22 15:06:40 --> Helper loaded: common_helper
INFO - 2018-02-22 15:06:40 --> Database Driver Class Initialized
DEBUG - 2018-02-22 15:06:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-22 15:06:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-22 15:06:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-22 15:06:40 --> Pagination Class Initialized
INFO - 2018-02-22 15:06:40 --> Helper loaded: form_helper
INFO - 2018-02-22 15:06:40 --> Form Validation Class Initialized
INFO - 2018-02-22 15:06:40 --> Model Class Initialized
INFO - 2018-02-22 15:06:40 --> Controller Class Initialized
INFO - 2018-02-22 15:06:40 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-22 15:06:40 --> Model Class Initialized
INFO - 2018-02-22 15:06:40 --> Model Class Initialized
INFO - 2018-02-22 15:06:40 --> Config Class Initialized
INFO - 2018-02-22 15:06:40 --> Hooks Class Initialized
DEBUG - 2018-02-22 15:06:40 --> UTF-8 Support Enabled
INFO - 2018-02-22 15:06:40 --> Utf8 Class Initialized
INFO - 2018-02-22 15:06:40 --> URI Class Initialized
INFO - 2018-02-22 15:06:40 --> Router Class Initialized
INFO - 2018-02-22 15:06:40 --> Output Class Initialized
INFO - 2018-02-22 15:06:40 --> Security Class Initialized
DEBUG - 2018-02-22 15:06:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-22 15:06:40 --> Input Class Initialized
INFO - 2018-02-22 15:06:40 --> Language Class Initialized
INFO - 2018-02-22 15:06:40 --> Loader Class Initialized
INFO - 2018-02-22 15:06:40 --> Helper loaded: url_helper
INFO - 2018-02-22 15:06:40 --> Helper loaded: file_helper
INFO - 2018-02-22 15:06:40 --> Helper loaded: email_helper
INFO - 2018-02-22 15:06:40 --> Helper loaded: common_helper
INFO - 2018-02-22 15:06:40 --> Database Driver Class Initialized
DEBUG - 2018-02-22 15:06:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-22 15:06:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-22 15:06:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-22 15:06:40 --> Pagination Class Initialized
INFO - 2018-02-22 15:06:40 --> Helper loaded: form_helper
INFO - 2018-02-22 15:06:40 --> Form Validation Class Initialized
INFO - 2018-02-22 15:06:40 --> Model Class Initialized
INFO - 2018-02-22 15:06:40 --> Controller Class Initialized
INFO - 2018-02-22 15:06:40 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-22 15:06:40 --> Model Class Initialized
INFO - 2018-02-22 15:06:40 --> Model Class Initialized
INFO - 2018-02-22 15:06:40 --> Model Class Initialized
INFO - 2018-02-22 15:06:40 --> Model Class Initialized
INFO - 2018-02-22 15:06:40 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-22 15:06:40 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-22 15:06:40 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-22 15:06:40 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-22 15:06:40 --> File loaded: /var/www/html/project/radio/application/views/dashboard/index.php
INFO - 2018-02-22 15:06:40 --> Final output sent to browser
DEBUG - 2018-02-22 15:06:40 --> Total execution time: 0.0082
INFO - 2018-02-22 15:06:45 --> Config Class Initialized
INFO - 2018-02-22 15:06:45 --> Hooks Class Initialized
DEBUG - 2018-02-22 15:06:45 --> UTF-8 Support Enabled
INFO - 2018-02-22 15:06:45 --> Utf8 Class Initialized
INFO - 2018-02-22 15:06:45 --> URI Class Initialized
INFO - 2018-02-22 15:06:45 --> Router Class Initialized
INFO - 2018-02-22 15:06:45 --> Output Class Initialized
INFO - 2018-02-22 15:06:45 --> Security Class Initialized
DEBUG - 2018-02-22 15:06:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-22 15:06:45 --> Input Class Initialized
INFO - 2018-02-22 15:06:45 --> Language Class Initialized
INFO - 2018-02-22 15:06:45 --> Loader Class Initialized
INFO - 2018-02-22 15:06:45 --> Helper loaded: url_helper
INFO - 2018-02-22 15:06:45 --> Helper loaded: file_helper
INFO - 2018-02-22 15:06:45 --> Helper loaded: email_helper
INFO - 2018-02-22 15:06:45 --> Helper loaded: common_helper
INFO - 2018-02-22 15:06:45 --> Database Driver Class Initialized
DEBUG - 2018-02-22 15:06:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-22 15:06:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-22 15:06:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-22 15:06:45 --> Pagination Class Initialized
INFO - 2018-02-22 15:06:45 --> Helper loaded: form_helper
INFO - 2018-02-22 15:06:45 --> Form Validation Class Initialized
INFO - 2018-02-22 15:06:45 --> Model Class Initialized
INFO - 2018-02-22 15:06:45 --> Controller Class Initialized
INFO - 2018-02-22 15:06:45 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-22 15:06:45 --> Model Class Initialized
INFO - 2018-02-22 15:06:45 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-22 15:06:45 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-22 15:06:45 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-22 15:06:45 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-22 15:06:45 --> File loaded: /var/www/html/project/radio/application/views/category/index.php
INFO - 2018-02-22 15:06:45 --> Final output sent to browser
DEBUG - 2018-02-22 15:06:45 --> Total execution time: 0.0077
INFO - 2018-02-22 15:06:49 --> Config Class Initialized
INFO - 2018-02-22 15:06:49 --> Hooks Class Initialized
DEBUG - 2018-02-22 15:06:49 --> UTF-8 Support Enabled
INFO - 2018-02-22 15:06:49 --> Utf8 Class Initialized
INFO - 2018-02-22 15:06:49 --> URI Class Initialized
INFO - 2018-02-22 15:06:49 --> Router Class Initialized
INFO - 2018-02-22 15:06:49 --> Output Class Initialized
INFO - 2018-02-22 15:06:49 --> Security Class Initialized
DEBUG - 2018-02-22 15:06:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-22 15:06:49 --> Input Class Initialized
INFO - 2018-02-22 15:06:49 --> Language Class Initialized
INFO - 2018-02-22 15:06:49 --> Loader Class Initialized
INFO - 2018-02-22 15:06:49 --> Helper loaded: url_helper
INFO - 2018-02-22 15:06:49 --> Helper loaded: file_helper
INFO - 2018-02-22 15:06:49 --> Helper loaded: email_helper
INFO - 2018-02-22 15:06:49 --> Helper loaded: common_helper
INFO - 2018-02-22 15:06:49 --> Database Driver Class Initialized
DEBUG - 2018-02-22 15:06:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-22 15:06:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-22 15:06:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-22 15:06:49 --> Pagination Class Initialized
INFO - 2018-02-22 15:06:49 --> Helper loaded: form_helper
INFO - 2018-02-22 15:06:49 --> Form Validation Class Initialized
INFO - 2018-02-22 15:06:49 --> Model Class Initialized
INFO - 2018-02-22 15:06:49 --> Controller Class Initialized
INFO - 2018-02-22 15:06:49 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-22 15:06:49 --> Model Class Initialized
INFO - 2018-02-22 15:06:49 --> Model Class Initialized
INFO - 2018-02-22 15:06:49 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-22 15:06:49 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-22 15:06:49 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-22 15:06:49 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-22 15:06:49 --> File loaded: /var/www/html/project/radio/application/views/subcategory/index.php
INFO - 2018-02-22 15:06:49 --> Final output sent to browser
DEBUG - 2018-02-22 15:06:49 --> Total execution time: 0.0072
INFO - 2018-02-22 15:06:55 --> Config Class Initialized
INFO - 2018-02-22 15:06:55 --> Hooks Class Initialized
DEBUG - 2018-02-22 15:06:55 --> UTF-8 Support Enabled
INFO - 2018-02-22 15:06:55 --> Utf8 Class Initialized
INFO - 2018-02-22 15:06:55 --> URI Class Initialized
INFO - 2018-02-22 15:06:55 --> Router Class Initialized
INFO - 2018-02-22 15:06:55 --> Output Class Initialized
INFO - 2018-02-22 15:06:55 --> Security Class Initialized
DEBUG - 2018-02-22 15:06:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-22 15:06:55 --> Input Class Initialized
INFO - 2018-02-22 15:06:55 --> Language Class Initialized
INFO - 2018-02-22 15:06:55 --> Loader Class Initialized
INFO - 2018-02-22 15:06:55 --> Helper loaded: url_helper
INFO - 2018-02-22 15:06:55 --> Helper loaded: file_helper
INFO - 2018-02-22 15:06:55 --> Helper loaded: email_helper
INFO - 2018-02-22 15:06:55 --> Helper loaded: common_helper
INFO - 2018-02-22 15:06:55 --> Database Driver Class Initialized
DEBUG - 2018-02-22 15:06:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-22 15:06:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-22 15:06:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-22 15:06:55 --> Pagination Class Initialized
INFO - 2018-02-22 15:06:55 --> Helper loaded: form_helper
INFO - 2018-02-22 15:06:55 --> Form Validation Class Initialized
INFO - 2018-02-22 15:06:55 --> Model Class Initialized
INFO - 2018-02-22 15:06:55 --> Controller Class Initialized
INFO - 2018-02-22 15:06:55 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-22 15:06:55 --> Model Class Initialized
INFO - 2018-02-22 15:06:55 --> Model Class Initialized
INFO - 2018-02-22 15:06:55 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-22 15:06:55 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-22 15:06:55 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-22 15:06:55 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-22 15:06:55 --> File loaded: /var/www/html/project/radio/application/views/subcategory/add_edit.php
INFO - 2018-02-22 15:06:55 --> Final output sent to browser
DEBUG - 2018-02-22 15:06:55 --> Total execution time: 0.0087
INFO - 2018-02-22 15:07:03 --> Config Class Initialized
INFO - 2018-02-22 15:07:03 --> Hooks Class Initialized
DEBUG - 2018-02-22 15:07:03 --> UTF-8 Support Enabled
INFO - 2018-02-22 15:07:03 --> Utf8 Class Initialized
INFO - 2018-02-22 15:07:03 --> URI Class Initialized
INFO - 2018-02-22 15:07:03 --> Router Class Initialized
INFO - 2018-02-22 15:07:03 --> Output Class Initialized
INFO - 2018-02-22 15:07:03 --> Security Class Initialized
DEBUG - 2018-02-22 15:07:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-22 15:07:03 --> Input Class Initialized
INFO - 2018-02-22 15:07:03 --> Language Class Initialized
INFO - 2018-02-22 15:07:03 --> Loader Class Initialized
INFO - 2018-02-22 15:07:03 --> Helper loaded: url_helper
INFO - 2018-02-22 15:07:03 --> Helper loaded: file_helper
INFO - 2018-02-22 15:07:03 --> Helper loaded: email_helper
INFO - 2018-02-22 15:07:03 --> Helper loaded: common_helper
INFO - 2018-02-22 15:07:03 --> Database Driver Class Initialized
DEBUG - 2018-02-22 15:07:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-22 15:07:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-22 15:07:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-22 15:07:03 --> Pagination Class Initialized
INFO - 2018-02-22 15:07:03 --> Helper loaded: form_helper
INFO - 2018-02-22 15:07:03 --> Form Validation Class Initialized
INFO - 2018-02-22 15:07:03 --> Model Class Initialized
INFO - 2018-02-22 15:07:03 --> Controller Class Initialized
INFO - 2018-02-22 15:07:03 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-22 15:07:03 --> Model Class Initialized
INFO - 2018-02-22 15:07:03 --> Model Class Initialized
INFO - 2018-02-22 15:07:03 --> Config Class Initialized
INFO - 2018-02-22 15:07:03 --> Hooks Class Initialized
DEBUG - 2018-02-22 15:07:03 --> UTF-8 Support Enabled
INFO - 2018-02-22 15:07:03 --> Utf8 Class Initialized
INFO - 2018-02-22 15:07:03 --> URI Class Initialized
INFO - 2018-02-22 15:07:03 --> Router Class Initialized
INFO - 2018-02-22 15:07:03 --> Output Class Initialized
INFO - 2018-02-22 15:07:03 --> Security Class Initialized
DEBUG - 2018-02-22 15:07:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-22 15:07:03 --> Input Class Initialized
INFO - 2018-02-22 15:07:03 --> Language Class Initialized
INFO - 2018-02-22 15:07:03 --> Loader Class Initialized
INFO - 2018-02-22 15:07:03 --> Helper loaded: url_helper
INFO - 2018-02-22 15:07:03 --> Helper loaded: file_helper
INFO - 2018-02-22 15:07:03 --> Helper loaded: email_helper
INFO - 2018-02-22 15:07:03 --> Helper loaded: common_helper
INFO - 2018-02-22 15:07:03 --> Database Driver Class Initialized
DEBUG - 2018-02-22 15:07:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-22 15:07:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-22 15:07:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-22 15:07:03 --> Pagination Class Initialized
INFO - 2018-02-22 15:07:03 --> Helper loaded: form_helper
INFO - 2018-02-22 15:07:03 --> Form Validation Class Initialized
INFO - 2018-02-22 15:07:03 --> Model Class Initialized
INFO - 2018-02-22 15:07:03 --> Controller Class Initialized
INFO - 2018-02-22 15:07:03 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-22 15:07:03 --> Model Class Initialized
INFO - 2018-02-22 15:07:03 --> Model Class Initialized
DEBUG - 2018-02-22 15:07:03 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-22 15:07:03 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-02-22 15:07:03 --> Config Class Initialized
INFO - 2018-02-22 15:07:03 --> Hooks Class Initialized
DEBUG - 2018-02-22 15:07:03 --> UTF-8 Support Enabled
INFO - 2018-02-22 15:07:03 --> Utf8 Class Initialized
INFO - 2018-02-22 15:07:03 --> URI Class Initialized
INFO - 2018-02-22 15:07:03 --> Router Class Initialized
INFO - 2018-02-22 15:07:03 --> Output Class Initialized
INFO - 2018-02-22 15:07:03 --> Security Class Initialized
DEBUG - 2018-02-22 15:07:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-22 15:07:03 --> Input Class Initialized
INFO - 2018-02-22 15:07:03 --> Language Class Initialized
INFO - 2018-02-22 15:07:03 --> Loader Class Initialized
INFO - 2018-02-22 15:07:03 --> Helper loaded: url_helper
INFO - 2018-02-22 15:07:03 --> Helper loaded: file_helper
INFO - 2018-02-22 15:07:03 --> Helper loaded: email_helper
INFO - 2018-02-22 15:07:03 --> Helper loaded: common_helper
INFO - 2018-02-22 15:07:03 --> Database Driver Class Initialized
DEBUG - 2018-02-22 15:07:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-22 15:07:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-22 15:07:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-22 15:07:03 --> Pagination Class Initialized
INFO - 2018-02-22 15:07:03 --> Helper loaded: form_helper
INFO - 2018-02-22 15:07:03 --> Form Validation Class Initialized
INFO - 2018-02-22 15:07:03 --> Model Class Initialized
INFO - 2018-02-22 15:07:03 --> Controller Class Initialized
INFO - 2018-02-22 15:07:03 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-22 15:07:03 --> Model Class Initialized
INFO - 2018-02-22 15:07:03 --> Model Class Initialized
INFO - 2018-02-22 15:07:03 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-22 15:07:03 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-22 15:07:03 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-22 15:07:03 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-22 15:07:03 --> File loaded: /var/www/html/project/radio/application/views/subcategory/index.php
INFO - 2018-02-22 15:07:03 --> Final output sent to browser
DEBUG - 2018-02-22 15:07:03 --> Total execution time: 0.0059
INFO - 2018-02-22 15:07:39 --> Config Class Initialized
INFO - 2018-02-22 15:07:39 --> Hooks Class Initialized
DEBUG - 2018-02-22 15:07:39 --> UTF-8 Support Enabled
INFO - 2018-02-22 15:07:39 --> Utf8 Class Initialized
INFO - 2018-02-22 15:07:39 --> URI Class Initialized
INFO - 2018-02-22 15:07:39 --> Router Class Initialized
INFO - 2018-02-22 15:07:39 --> Output Class Initialized
INFO - 2018-02-22 15:07:39 --> Security Class Initialized
DEBUG - 2018-02-22 15:07:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-22 15:07:39 --> Input Class Initialized
INFO - 2018-02-22 15:07:39 --> Language Class Initialized
INFO - 2018-02-22 15:07:39 --> Loader Class Initialized
INFO - 2018-02-22 15:07:39 --> Helper loaded: url_helper
INFO - 2018-02-22 15:07:39 --> Helper loaded: file_helper
INFO - 2018-02-22 15:07:39 --> Helper loaded: email_helper
INFO - 2018-02-22 15:07:39 --> Helper loaded: common_helper
INFO - 2018-02-22 15:07:39 --> Database Driver Class Initialized
DEBUG - 2018-02-22 15:07:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-22 15:07:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-22 15:07:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-22 15:07:39 --> Pagination Class Initialized
INFO - 2018-02-22 15:07:39 --> Helper loaded: form_helper
INFO - 2018-02-22 15:07:39 --> Form Validation Class Initialized
INFO - 2018-02-22 15:07:39 --> Model Class Initialized
INFO - 2018-02-22 15:07:39 --> Controller Class Initialized
DEBUG - 2018-02-22 15:07:39 --> Config file loaded: /var/www/html/project/radio/application/config/rest.php
INFO - 2018-02-22 15:07:39 --> Helper loaded: inflector_helper
INFO - 2018-02-22 15:07:39 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-22 15:07:39 --> Model Class Initialized
INFO - 2018-02-22 15:07:39 --> Model Class Initialized
INFO - 2018-02-22 15:07:39 --> Model Class Initialized
INFO - 2018-02-22 15:07:39 --> Model Class Initialized
INFO - 2018-02-22 15:07:39 --> Model Class Initialized
INFO - 2018-02-22 15:07:39 --> Model Class Initialized
INFO - 2018-02-22 15:07:39 --> Final output sent to browser
DEBUG - 2018-02-22 15:07:39 --> Total execution time: 0.0095
INFO - 2018-02-22 15:08:37 --> Config Class Initialized
INFO - 2018-02-22 15:08:37 --> Hooks Class Initialized
DEBUG - 2018-02-22 15:08:37 --> UTF-8 Support Enabled
INFO - 2018-02-22 15:08:37 --> Utf8 Class Initialized
INFO - 2018-02-22 15:08:37 --> URI Class Initialized
INFO - 2018-02-22 15:08:37 --> Router Class Initialized
INFO - 2018-02-22 15:08:37 --> Output Class Initialized
INFO - 2018-02-22 15:08:37 --> Security Class Initialized
DEBUG - 2018-02-22 15:08:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-22 15:08:37 --> Input Class Initialized
INFO - 2018-02-22 15:08:37 --> Language Class Initialized
INFO - 2018-02-22 15:08:37 --> Loader Class Initialized
INFO - 2018-02-22 15:08:37 --> Helper loaded: url_helper
INFO - 2018-02-22 15:08:37 --> Helper loaded: file_helper
INFO - 2018-02-22 15:08:37 --> Helper loaded: email_helper
INFO - 2018-02-22 15:08:37 --> Helper loaded: common_helper
INFO - 2018-02-22 15:08:37 --> Database Driver Class Initialized
DEBUG - 2018-02-22 15:08:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-22 15:08:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-22 15:08:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-22 15:08:37 --> Pagination Class Initialized
INFO - 2018-02-22 15:08:37 --> Helper loaded: form_helper
INFO - 2018-02-22 15:08:37 --> Form Validation Class Initialized
INFO - 2018-02-22 15:08:37 --> Model Class Initialized
INFO - 2018-02-22 15:08:37 --> Controller Class Initialized
DEBUG - 2018-02-22 15:08:37 --> Config file loaded: /var/www/html/project/radio/application/config/rest.php
INFO - 2018-02-22 15:08:37 --> Helper loaded: inflector_helper
INFO - 2018-02-22 15:08:37 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-22 15:08:37 --> Model Class Initialized
INFO - 2018-02-22 15:08:37 --> Model Class Initialized
INFO - 2018-02-22 15:08:37 --> Model Class Initialized
INFO - 2018-02-22 15:08:37 --> Model Class Initialized
INFO - 2018-02-22 15:08:37 --> Model Class Initialized
INFO - 2018-02-22 15:08:37 --> Model Class Initialized
INFO - 2018-02-22 15:08:37 --> Final output sent to browser
DEBUG - 2018-02-22 15:08:37 --> Total execution time: 0.0165
INFO - 2018-02-22 15:11:10 --> Config Class Initialized
INFO - 2018-02-22 15:11:10 --> Hooks Class Initialized
DEBUG - 2018-02-22 15:11:10 --> UTF-8 Support Enabled
INFO - 2018-02-22 15:11:10 --> Utf8 Class Initialized
INFO - 2018-02-22 15:11:10 --> URI Class Initialized
INFO - 2018-02-22 15:11:10 --> Router Class Initialized
INFO - 2018-02-22 15:11:10 --> Output Class Initialized
INFO - 2018-02-22 15:11:10 --> Security Class Initialized
DEBUG - 2018-02-22 15:11:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-22 15:11:10 --> Input Class Initialized
INFO - 2018-02-22 15:11:10 --> Language Class Initialized
ERROR - 2018-02-22 15:11:10 --> Severity: error --> Exception: syntax error, unexpected '}' /var/www/html/project/radio/application/controllers/api/Fetchappdata.php 260
INFO - 2018-02-22 15:11:23 --> Config Class Initialized
INFO - 2018-02-22 15:11:23 --> Hooks Class Initialized
DEBUG - 2018-02-22 15:11:23 --> UTF-8 Support Enabled
INFO - 2018-02-22 15:11:23 --> Utf8 Class Initialized
INFO - 2018-02-22 15:11:23 --> URI Class Initialized
INFO - 2018-02-22 15:11:23 --> Router Class Initialized
INFO - 2018-02-22 15:11:23 --> Output Class Initialized
INFO - 2018-02-22 15:11:23 --> Security Class Initialized
DEBUG - 2018-02-22 15:11:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-22 15:11:23 --> Input Class Initialized
INFO - 2018-02-22 15:11:23 --> Language Class Initialized
INFO - 2018-02-22 15:11:23 --> Loader Class Initialized
INFO - 2018-02-22 15:11:23 --> Helper loaded: url_helper
INFO - 2018-02-22 15:11:23 --> Helper loaded: file_helper
INFO - 2018-02-22 15:11:23 --> Helper loaded: email_helper
INFO - 2018-02-22 15:11:23 --> Helper loaded: common_helper
INFO - 2018-02-22 15:11:23 --> Database Driver Class Initialized
DEBUG - 2018-02-22 15:11:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-22 15:11:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-22 15:11:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-22 15:11:23 --> Pagination Class Initialized
INFO - 2018-02-22 15:11:23 --> Helper loaded: form_helper
INFO - 2018-02-22 15:11:23 --> Form Validation Class Initialized
INFO - 2018-02-22 15:11:23 --> Model Class Initialized
INFO - 2018-02-22 15:11:23 --> Controller Class Initialized
DEBUG - 2018-02-22 15:11:23 --> Config file loaded: /var/www/html/project/radio/application/config/rest.php
INFO - 2018-02-22 15:11:23 --> Helper loaded: inflector_helper
INFO - 2018-02-22 15:11:23 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-22 15:11:23 --> Model Class Initialized
INFO - 2018-02-22 15:11:23 --> Model Class Initialized
INFO - 2018-02-22 15:11:23 --> Model Class Initialized
INFO - 2018-02-22 15:11:23 --> Model Class Initialized
INFO - 2018-02-22 15:11:23 --> Model Class Initialized
INFO - 2018-02-22 15:11:23 --> Model Class Initialized
INFO - 2018-02-22 15:11:35 --> Config Class Initialized
INFO - 2018-02-22 15:11:35 --> Hooks Class Initialized
DEBUG - 2018-02-22 15:11:35 --> UTF-8 Support Enabled
INFO - 2018-02-22 15:11:35 --> Utf8 Class Initialized
INFO - 2018-02-22 15:11:35 --> URI Class Initialized
INFO - 2018-02-22 15:11:35 --> Router Class Initialized
INFO - 2018-02-22 15:11:35 --> Output Class Initialized
INFO - 2018-02-22 15:11:35 --> Security Class Initialized
DEBUG - 2018-02-22 15:11:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-22 15:11:35 --> Input Class Initialized
INFO - 2018-02-22 15:11:35 --> Language Class Initialized
INFO - 2018-02-22 15:11:35 --> Loader Class Initialized
INFO - 2018-02-22 15:11:35 --> Helper loaded: url_helper
INFO - 2018-02-22 15:11:35 --> Helper loaded: file_helper
INFO - 2018-02-22 15:11:35 --> Helper loaded: email_helper
INFO - 2018-02-22 15:11:35 --> Helper loaded: common_helper
INFO - 2018-02-22 15:11:35 --> Database Driver Class Initialized
DEBUG - 2018-02-22 15:11:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-22 15:11:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-22 15:11:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-22 15:11:35 --> Pagination Class Initialized
INFO - 2018-02-22 15:11:35 --> Helper loaded: form_helper
INFO - 2018-02-22 15:11:35 --> Form Validation Class Initialized
INFO - 2018-02-22 15:11:35 --> Model Class Initialized
INFO - 2018-02-22 15:11:35 --> Controller Class Initialized
DEBUG - 2018-02-22 15:11:35 --> Config file loaded: /var/www/html/project/radio/application/config/rest.php
INFO - 2018-02-22 15:11:35 --> Helper loaded: inflector_helper
INFO - 2018-02-22 15:11:35 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-22 15:11:35 --> Model Class Initialized
INFO - 2018-02-22 15:11:35 --> Model Class Initialized
INFO - 2018-02-22 15:11:35 --> Model Class Initialized
INFO - 2018-02-22 15:11:35 --> Model Class Initialized
INFO - 2018-02-22 15:11:35 --> Model Class Initialized
INFO - 2018-02-22 15:11:35 --> Model Class Initialized
INFO - 2018-02-22 15:11:35 --> Final output sent to browser
DEBUG - 2018-02-22 15:11:35 --> Total execution time: 0.0081
INFO - 2018-02-22 15:11:52 --> Config Class Initialized
INFO - 2018-02-22 15:11:52 --> Hooks Class Initialized
DEBUG - 2018-02-22 15:11:52 --> UTF-8 Support Enabled
INFO - 2018-02-22 15:11:52 --> Utf8 Class Initialized
INFO - 2018-02-22 15:11:52 --> URI Class Initialized
INFO - 2018-02-22 15:11:52 --> Router Class Initialized
INFO - 2018-02-22 15:11:52 --> Output Class Initialized
INFO - 2018-02-22 15:11:52 --> Security Class Initialized
DEBUG - 2018-02-22 15:11:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-22 15:11:52 --> Input Class Initialized
INFO - 2018-02-22 15:11:52 --> Language Class Initialized
INFO - 2018-02-22 15:11:52 --> Loader Class Initialized
INFO - 2018-02-22 15:11:52 --> Helper loaded: url_helper
INFO - 2018-02-22 15:11:52 --> Helper loaded: file_helper
INFO - 2018-02-22 15:11:52 --> Helper loaded: email_helper
INFO - 2018-02-22 15:11:52 --> Helper loaded: common_helper
INFO - 2018-02-22 15:11:52 --> Database Driver Class Initialized
DEBUG - 2018-02-22 15:11:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-22 15:11:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-22 15:11:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-22 15:11:52 --> Pagination Class Initialized
INFO - 2018-02-22 15:11:52 --> Helper loaded: form_helper
INFO - 2018-02-22 15:11:52 --> Form Validation Class Initialized
INFO - 2018-02-22 15:11:52 --> Model Class Initialized
INFO - 2018-02-22 15:11:52 --> Controller Class Initialized
DEBUG - 2018-02-22 15:11:52 --> Config file loaded: /var/www/html/project/radio/application/config/rest.php
INFO - 2018-02-22 15:11:52 --> Helper loaded: inflector_helper
INFO - 2018-02-22 15:11:52 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-22 15:11:52 --> Model Class Initialized
INFO - 2018-02-22 15:11:52 --> Model Class Initialized
INFO - 2018-02-22 15:11:52 --> Model Class Initialized
INFO - 2018-02-22 15:11:52 --> Model Class Initialized
INFO - 2018-02-22 15:11:52 --> Model Class Initialized
INFO - 2018-02-22 15:11:52 --> Model Class Initialized
INFO - 2018-02-22 15:11:52 --> Final output sent to browser
DEBUG - 2018-02-22 15:11:52 --> Total execution time: 0.0071
INFO - 2018-02-22 15:12:57 --> Config Class Initialized
INFO - 2018-02-22 15:12:57 --> Hooks Class Initialized
DEBUG - 2018-02-22 15:12:57 --> UTF-8 Support Enabled
INFO - 2018-02-22 15:12:57 --> Utf8 Class Initialized
INFO - 2018-02-22 15:12:57 --> URI Class Initialized
INFO - 2018-02-22 15:12:57 --> Router Class Initialized
INFO - 2018-02-22 15:12:57 --> Output Class Initialized
INFO - 2018-02-22 15:12:57 --> Security Class Initialized
DEBUG - 2018-02-22 15:12:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-22 15:12:57 --> Input Class Initialized
INFO - 2018-02-22 15:12:57 --> Language Class Initialized
INFO - 2018-02-22 15:12:57 --> Loader Class Initialized
INFO - 2018-02-22 15:12:57 --> Helper loaded: url_helper
INFO - 2018-02-22 15:12:57 --> Helper loaded: file_helper
INFO - 2018-02-22 15:12:57 --> Helper loaded: email_helper
INFO - 2018-02-22 15:12:57 --> Helper loaded: common_helper
INFO - 2018-02-22 15:12:57 --> Database Driver Class Initialized
DEBUG - 2018-02-22 15:12:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-22 15:12:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-22 15:12:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-22 15:12:57 --> Pagination Class Initialized
INFO - 2018-02-22 15:12:57 --> Helper loaded: form_helper
INFO - 2018-02-22 15:12:57 --> Form Validation Class Initialized
INFO - 2018-02-22 15:12:57 --> Model Class Initialized
INFO - 2018-02-22 15:12:57 --> Controller Class Initialized
DEBUG - 2018-02-22 15:12:57 --> Config file loaded: /var/www/html/project/radio/application/config/rest.php
INFO - 2018-02-22 15:12:57 --> Helper loaded: inflector_helper
INFO - 2018-02-22 15:12:57 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-22 15:12:57 --> Model Class Initialized
INFO - 2018-02-22 15:12:57 --> Model Class Initialized
INFO - 2018-02-22 15:12:57 --> Model Class Initialized
INFO - 2018-02-22 15:12:57 --> Model Class Initialized
INFO - 2018-02-22 15:12:57 --> Model Class Initialized
INFO - 2018-02-22 15:12:57 --> Model Class Initialized
INFO - 2018-02-22 15:12:57 --> Final output sent to browser
DEBUG - 2018-02-22 15:12:57 --> Total execution time: 0.0090
INFO - 2018-02-22 15:13:01 --> Config Class Initialized
INFO - 2018-02-22 15:13:01 --> Hooks Class Initialized
DEBUG - 2018-02-22 15:13:01 --> UTF-8 Support Enabled
INFO - 2018-02-22 15:13:01 --> Utf8 Class Initialized
INFO - 2018-02-22 15:13:01 --> URI Class Initialized
INFO - 2018-02-22 15:13:01 --> Router Class Initialized
INFO - 2018-02-22 15:13:01 --> Output Class Initialized
INFO - 2018-02-22 15:13:01 --> Security Class Initialized
DEBUG - 2018-02-22 15:13:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-22 15:13:01 --> Input Class Initialized
INFO - 2018-02-22 15:13:01 --> Language Class Initialized
INFO - 2018-02-22 15:13:01 --> Loader Class Initialized
INFO - 2018-02-22 15:13:01 --> Helper loaded: url_helper
INFO - 2018-02-22 15:13:01 --> Helper loaded: file_helper
INFO - 2018-02-22 15:13:01 --> Helper loaded: email_helper
INFO - 2018-02-22 15:13:01 --> Helper loaded: common_helper
INFO - 2018-02-22 15:13:01 --> Database Driver Class Initialized
DEBUG - 2018-02-22 15:13:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-22 15:13:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-22 15:13:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-22 15:13:01 --> Pagination Class Initialized
INFO - 2018-02-22 15:13:01 --> Helper loaded: form_helper
INFO - 2018-02-22 15:13:01 --> Form Validation Class Initialized
INFO - 2018-02-22 15:13:01 --> Model Class Initialized
INFO - 2018-02-22 15:13:01 --> Controller Class Initialized
INFO - 2018-02-22 15:13:01 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-22 15:13:01 --> Model Class Initialized
INFO - 2018-02-22 15:13:01 --> Model Class Initialized
INFO - 2018-02-22 15:13:01 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-22 15:13:01 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-22 15:13:01 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-22 15:13:01 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-22 15:13:01 --> File loaded: /var/www/html/project/radio/application/views/subcategory/add_edit.php
INFO - 2018-02-22 15:13:01 --> Final output sent to browser
DEBUG - 2018-02-22 15:13:01 --> Total execution time: 0.0087
INFO - 2018-02-22 15:13:11 --> Config Class Initialized
INFO - 2018-02-22 15:13:11 --> Hooks Class Initialized
DEBUG - 2018-02-22 15:13:11 --> UTF-8 Support Enabled
INFO - 2018-02-22 15:13:11 --> Utf8 Class Initialized
INFO - 2018-02-22 15:13:11 --> URI Class Initialized
INFO - 2018-02-22 15:13:11 --> Router Class Initialized
INFO - 2018-02-22 15:13:11 --> Output Class Initialized
INFO - 2018-02-22 15:13:11 --> Security Class Initialized
DEBUG - 2018-02-22 15:13:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-22 15:13:11 --> Input Class Initialized
INFO - 2018-02-22 15:13:11 --> Language Class Initialized
INFO - 2018-02-22 15:13:11 --> Loader Class Initialized
INFO - 2018-02-22 15:13:11 --> Helper loaded: url_helper
INFO - 2018-02-22 15:13:11 --> Helper loaded: file_helper
INFO - 2018-02-22 15:13:11 --> Helper loaded: email_helper
INFO - 2018-02-22 15:13:11 --> Helper loaded: common_helper
INFO - 2018-02-22 15:13:11 --> Database Driver Class Initialized
DEBUG - 2018-02-22 15:13:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-22 15:13:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-22 15:13:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-22 15:13:11 --> Pagination Class Initialized
INFO - 2018-02-22 15:13:11 --> Helper loaded: form_helper
INFO - 2018-02-22 15:13:11 --> Form Validation Class Initialized
INFO - 2018-02-22 15:13:11 --> Model Class Initialized
INFO - 2018-02-22 15:13:11 --> Controller Class Initialized
INFO - 2018-02-22 15:13:11 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-22 15:13:11 --> Model Class Initialized
INFO - 2018-02-22 15:13:11 --> Model Class Initialized
INFO - 2018-02-22 15:13:11 --> Config Class Initialized
INFO - 2018-02-22 15:13:11 --> Hooks Class Initialized
DEBUG - 2018-02-22 15:13:11 --> UTF-8 Support Enabled
INFO - 2018-02-22 15:13:11 --> Utf8 Class Initialized
INFO - 2018-02-22 15:13:11 --> URI Class Initialized
INFO - 2018-02-22 15:13:11 --> Router Class Initialized
INFO - 2018-02-22 15:13:11 --> Output Class Initialized
INFO - 2018-02-22 15:13:11 --> Security Class Initialized
DEBUG - 2018-02-22 15:13:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-22 15:13:11 --> Input Class Initialized
INFO - 2018-02-22 15:13:11 --> Language Class Initialized
INFO - 2018-02-22 15:13:11 --> Loader Class Initialized
INFO - 2018-02-22 15:13:11 --> Helper loaded: url_helper
INFO - 2018-02-22 15:13:11 --> Helper loaded: file_helper
INFO - 2018-02-22 15:13:11 --> Helper loaded: email_helper
INFO - 2018-02-22 15:13:11 --> Helper loaded: common_helper
INFO - 2018-02-22 15:13:11 --> Database Driver Class Initialized
DEBUG - 2018-02-22 15:13:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-22 15:13:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-22 15:13:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-22 15:13:11 --> Pagination Class Initialized
INFO - 2018-02-22 15:13:11 --> Helper loaded: form_helper
INFO - 2018-02-22 15:13:11 --> Form Validation Class Initialized
INFO - 2018-02-22 15:13:11 --> Model Class Initialized
INFO - 2018-02-22 15:13:11 --> Controller Class Initialized
INFO - 2018-02-22 15:13:11 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-22 15:13:11 --> Model Class Initialized
INFO - 2018-02-22 15:13:11 --> Model Class Initialized
DEBUG - 2018-02-22 15:13:11 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-22 15:13:11 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-02-22 15:13:11 --> Config Class Initialized
INFO - 2018-02-22 15:13:11 --> Hooks Class Initialized
DEBUG - 2018-02-22 15:13:11 --> UTF-8 Support Enabled
INFO - 2018-02-22 15:13:11 --> Utf8 Class Initialized
INFO - 2018-02-22 15:13:11 --> URI Class Initialized
INFO - 2018-02-22 15:13:11 --> Router Class Initialized
INFO - 2018-02-22 15:13:11 --> Output Class Initialized
INFO - 2018-02-22 15:13:11 --> Security Class Initialized
DEBUG - 2018-02-22 15:13:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-22 15:13:11 --> Input Class Initialized
INFO - 2018-02-22 15:13:11 --> Language Class Initialized
INFO - 2018-02-22 15:13:11 --> Loader Class Initialized
INFO - 2018-02-22 15:13:11 --> Helper loaded: url_helper
INFO - 2018-02-22 15:13:11 --> Helper loaded: file_helper
INFO - 2018-02-22 15:13:11 --> Helper loaded: email_helper
INFO - 2018-02-22 15:13:11 --> Helper loaded: common_helper
INFO - 2018-02-22 15:13:11 --> Database Driver Class Initialized
DEBUG - 2018-02-22 15:13:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-22 15:13:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-22 15:13:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-22 15:13:11 --> Pagination Class Initialized
INFO - 2018-02-22 15:13:11 --> Helper loaded: form_helper
INFO - 2018-02-22 15:13:11 --> Form Validation Class Initialized
INFO - 2018-02-22 15:13:11 --> Model Class Initialized
INFO - 2018-02-22 15:13:11 --> Controller Class Initialized
INFO - 2018-02-22 15:13:11 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-22 15:13:11 --> Model Class Initialized
INFO - 2018-02-22 15:13:11 --> Model Class Initialized
INFO - 2018-02-22 15:13:11 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-22 15:13:11 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-22 15:13:11 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-22 15:13:11 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-22 15:13:11 --> File loaded: /var/www/html/project/radio/application/views/subcategory/index.php
INFO - 2018-02-22 15:13:11 --> Final output sent to browser
DEBUG - 2018-02-22 15:13:11 --> Total execution time: 0.0066
INFO - 2018-02-22 15:13:25 --> Config Class Initialized
INFO - 2018-02-22 15:13:25 --> Hooks Class Initialized
DEBUG - 2018-02-22 15:13:25 --> UTF-8 Support Enabled
INFO - 2018-02-22 15:13:25 --> Utf8 Class Initialized
INFO - 2018-02-22 15:13:25 --> URI Class Initialized
INFO - 2018-02-22 15:13:25 --> Router Class Initialized
INFO - 2018-02-22 15:13:25 --> Output Class Initialized
INFO - 2018-02-22 15:13:25 --> Security Class Initialized
DEBUG - 2018-02-22 15:13:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-22 15:13:25 --> Input Class Initialized
INFO - 2018-02-22 15:13:25 --> Language Class Initialized
INFO - 2018-02-22 15:13:25 --> Loader Class Initialized
INFO - 2018-02-22 15:13:25 --> Helper loaded: url_helper
INFO - 2018-02-22 15:13:25 --> Helper loaded: file_helper
INFO - 2018-02-22 15:13:25 --> Helper loaded: email_helper
INFO - 2018-02-22 15:13:25 --> Helper loaded: common_helper
INFO - 2018-02-22 15:13:25 --> Database Driver Class Initialized
DEBUG - 2018-02-22 15:13:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-22 15:13:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-22 15:13:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-22 15:13:25 --> Pagination Class Initialized
INFO - 2018-02-22 15:13:25 --> Helper loaded: form_helper
INFO - 2018-02-22 15:13:25 --> Form Validation Class Initialized
INFO - 2018-02-22 15:13:25 --> Model Class Initialized
INFO - 2018-02-22 15:13:25 --> Controller Class Initialized
DEBUG - 2018-02-22 15:13:25 --> Config file loaded: /var/www/html/project/radio/application/config/rest.php
INFO - 2018-02-22 15:13:25 --> Helper loaded: inflector_helper
INFO - 2018-02-22 15:13:25 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-22 15:13:25 --> Model Class Initialized
INFO - 2018-02-22 15:13:25 --> Model Class Initialized
INFO - 2018-02-22 15:13:25 --> Model Class Initialized
INFO - 2018-02-22 15:13:25 --> Model Class Initialized
INFO - 2018-02-22 15:13:25 --> Model Class Initialized
INFO - 2018-02-22 15:13:25 --> Model Class Initialized
INFO - 2018-02-22 15:13:25 --> Final output sent to browser
DEBUG - 2018-02-22 15:13:25 --> Total execution time: 0.0087
INFO - 2018-02-22 15:14:27 --> Config Class Initialized
INFO - 2018-02-22 15:14:27 --> Hooks Class Initialized
DEBUG - 2018-02-22 15:14:27 --> UTF-8 Support Enabled
INFO - 2018-02-22 15:14:27 --> Utf8 Class Initialized
INFO - 2018-02-22 15:14:27 --> URI Class Initialized
INFO - 2018-02-22 15:14:27 --> Router Class Initialized
INFO - 2018-02-22 15:14:27 --> Output Class Initialized
INFO - 2018-02-22 15:14:27 --> Security Class Initialized
DEBUG - 2018-02-22 15:14:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-22 15:14:27 --> Input Class Initialized
INFO - 2018-02-22 15:14:27 --> Language Class Initialized
INFO - 2018-02-22 15:14:27 --> Loader Class Initialized
INFO - 2018-02-22 15:14:27 --> Helper loaded: url_helper
INFO - 2018-02-22 15:14:27 --> Helper loaded: file_helper
INFO - 2018-02-22 15:14:27 --> Helper loaded: email_helper
INFO - 2018-02-22 15:14:27 --> Helper loaded: common_helper
INFO - 2018-02-22 15:14:27 --> Database Driver Class Initialized
DEBUG - 2018-02-22 15:14:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-22 15:14:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-22 15:14:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-22 15:14:27 --> Pagination Class Initialized
INFO - 2018-02-22 15:14:27 --> Helper loaded: form_helper
INFO - 2018-02-22 15:14:27 --> Form Validation Class Initialized
INFO - 2018-02-22 15:14:27 --> Model Class Initialized
INFO - 2018-02-22 15:14:27 --> Controller Class Initialized
DEBUG - 2018-02-22 15:14:27 --> Config file loaded: /var/www/html/project/radio/application/config/rest.php
INFO - 2018-02-22 15:14:27 --> Helper loaded: inflector_helper
INFO - 2018-02-22 15:14:27 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-22 15:14:27 --> Model Class Initialized
INFO - 2018-02-22 15:14:27 --> Model Class Initialized
INFO - 2018-02-22 15:14:27 --> Model Class Initialized
INFO - 2018-02-22 15:14:27 --> Model Class Initialized
INFO - 2018-02-22 15:14:27 --> Model Class Initialized
INFO - 2018-02-22 15:14:27 --> Model Class Initialized
INFO - 2018-02-22 15:14:27 --> Final output sent to browser
DEBUG - 2018-02-22 15:14:27 --> Total execution time: 0.0102
INFO - 2018-02-22 15:15:24 --> Config Class Initialized
INFO - 2018-02-22 15:15:24 --> Hooks Class Initialized
DEBUG - 2018-02-22 15:15:24 --> UTF-8 Support Enabled
INFO - 2018-02-22 15:15:24 --> Utf8 Class Initialized
INFO - 2018-02-22 15:15:24 --> URI Class Initialized
INFO - 2018-02-22 15:15:24 --> Router Class Initialized
INFO - 2018-02-22 15:15:24 --> Output Class Initialized
INFO - 2018-02-22 15:15:24 --> Security Class Initialized
DEBUG - 2018-02-22 15:15:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-22 15:15:24 --> Input Class Initialized
INFO - 2018-02-22 15:15:24 --> Language Class Initialized
INFO - 2018-02-22 15:15:24 --> Loader Class Initialized
INFO - 2018-02-22 15:15:24 --> Helper loaded: url_helper
INFO - 2018-02-22 15:15:24 --> Helper loaded: file_helper
INFO - 2018-02-22 15:15:24 --> Helper loaded: email_helper
INFO - 2018-02-22 15:15:24 --> Helper loaded: common_helper
INFO - 2018-02-22 15:15:24 --> Database Driver Class Initialized
DEBUG - 2018-02-22 15:15:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-22 15:15:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-22 15:15:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-22 15:15:24 --> Pagination Class Initialized
INFO - 2018-02-22 15:15:24 --> Helper loaded: form_helper
INFO - 2018-02-22 15:15:24 --> Form Validation Class Initialized
INFO - 2018-02-22 15:15:24 --> Model Class Initialized
INFO - 2018-02-22 15:15:24 --> Controller Class Initialized
INFO - 2018-02-22 15:15:24 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-22 15:15:24 --> Model Class Initialized
INFO - 2018-02-22 15:15:24 --> Model Class Initialized
INFO - 2018-02-22 15:15:24 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-22 15:15:24 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-22 15:15:24 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-22 15:15:24 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-22 15:15:24 --> File loaded: /var/www/html/project/radio/application/views/subcategory/add_edit.php
INFO - 2018-02-22 15:15:24 --> Final output sent to browser
DEBUG - 2018-02-22 15:15:24 --> Total execution time: 0.0088
INFO - 2018-02-22 15:15:28 --> Config Class Initialized
INFO - 2018-02-22 15:15:28 --> Hooks Class Initialized
DEBUG - 2018-02-22 15:15:28 --> UTF-8 Support Enabled
INFO - 2018-02-22 15:15:28 --> Utf8 Class Initialized
INFO - 2018-02-22 15:15:28 --> URI Class Initialized
INFO - 2018-02-22 15:15:28 --> Router Class Initialized
INFO - 2018-02-22 15:15:28 --> Output Class Initialized
INFO - 2018-02-22 15:15:28 --> Security Class Initialized
DEBUG - 2018-02-22 15:15:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-22 15:15:28 --> Input Class Initialized
INFO - 2018-02-22 15:15:28 --> Language Class Initialized
INFO - 2018-02-22 15:15:28 --> Loader Class Initialized
INFO - 2018-02-22 15:15:28 --> Helper loaded: url_helper
INFO - 2018-02-22 15:15:28 --> Helper loaded: file_helper
INFO - 2018-02-22 15:15:28 --> Helper loaded: email_helper
INFO - 2018-02-22 15:15:28 --> Helper loaded: common_helper
INFO - 2018-02-22 15:15:28 --> Database Driver Class Initialized
DEBUG - 2018-02-22 15:15:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-22 15:15:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-22 15:15:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-22 15:15:28 --> Pagination Class Initialized
INFO - 2018-02-22 15:15:28 --> Helper loaded: form_helper
INFO - 2018-02-22 15:15:28 --> Form Validation Class Initialized
INFO - 2018-02-22 15:15:28 --> Model Class Initialized
INFO - 2018-02-22 15:15:28 --> Controller Class Initialized
INFO - 2018-02-22 15:15:28 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-22 15:15:28 --> Model Class Initialized
INFO - 2018-02-22 15:15:28 --> Model Class Initialized
INFO - 2018-02-22 15:15:28 --> Config Class Initialized
INFO - 2018-02-22 15:15:28 --> Hooks Class Initialized
DEBUG - 2018-02-22 15:15:28 --> UTF-8 Support Enabled
INFO - 2018-02-22 15:15:28 --> Utf8 Class Initialized
INFO - 2018-02-22 15:15:28 --> URI Class Initialized
INFO - 2018-02-22 15:15:28 --> Router Class Initialized
INFO - 2018-02-22 15:15:28 --> Output Class Initialized
INFO - 2018-02-22 15:15:28 --> Security Class Initialized
DEBUG - 2018-02-22 15:15:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-22 15:15:28 --> Input Class Initialized
INFO - 2018-02-22 15:15:28 --> Language Class Initialized
INFO - 2018-02-22 15:15:28 --> Loader Class Initialized
INFO - 2018-02-22 15:15:28 --> Helper loaded: url_helper
INFO - 2018-02-22 15:15:28 --> Helper loaded: file_helper
INFO - 2018-02-22 15:15:28 --> Helper loaded: email_helper
INFO - 2018-02-22 15:15:28 --> Helper loaded: common_helper
INFO - 2018-02-22 15:15:28 --> Database Driver Class Initialized
DEBUG - 2018-02-22 15:15:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-22 15:15:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-22 15:15:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-22 15:15:28 --> Pagination Class Initialized
INFO - 2018-02-22 15:15:28 --> Helper loaded: form_helper
INFO - 2018-02-22 15:15:28 --> Form Validation Class Initialized
INFO - 2018-02-22 15:15:28 --> Model Class Initialized
INFO - 2018-02-22 15:15:28 --> Controller Class Initialized
INFO - 2018-02-22 15:15:28 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-22 15:15:28 --> Model Class Initialized
INFO - 2018-02-22 15:15:28 --> Model Class Initialized
DEBUG - 2018-02-22 15:15:28 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-22 15:15:28 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-02-22 15:15:28 --> Config Class Initialized
INFO - 2018-02-22 15:15:28 --> Hooks Class Initialized
DEBUG - 2018-02-22 15:15:28 --> UTF-8 Support Enabled
INFO - 2018-02-22 15:15:28 --> Utf8 Class Initialized
INFO - 2018-02-22 15:15:28 --> URI Class Initialized
INFO - 2018-02-22 15:15:28 --> Router Class Initialized
INFO - 2018-02-22 15:15:28 --> Output Class Initialized
INFO - 2018-02-22 15:15:28 --> Security Class Initialized
DEBUG - 2018-02-22 15:15:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-22 15:15:28 --> Input Class Initialized
INFO - 2018-02-22 15:15:28 --> Language Class Initialized
INFO - 2018-02-22 15:15:28 --> Loader Class Initialized
INFO - 2018-02-22 15:15:28 --> Helper loaded: url_helper
INFO - 2018-02-22 15:15:28 --> Helper loaded: file_helper
INFO - 2018-02-22 15:15:28 --> Helper loaded: email_helper
INFO - 2018-02-22 15:15:28 --> Helper loaded: common_helper
INFO - 2018-02-22 15:15:28 --> Database Driver Class Initialized
DEBUG - 2018-02-22 15:15:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-22 15:15:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-22 15:15:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-22 15:15:28 --> Pagination Class Initialized
INFO - 2018-02-22 15:15:28 --> Helper loaded: form_helper
INFO - 2018-02-22 15:15:28 --> Form Validation Class Initialized
INFO - 2018-02-22 15:15:28 --> Model Class Initialized
INFO - 2018-02-22 15:15:28 --> Controller Class Initialized
INFO - 2018-02-22 15:15:28 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-22 15:15:28 --> Model Class Initialized
INFO - 2018-02-22 15:15:28 --> Model Class Initialized
INFO - 2018-02-22 15:15:28 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-22 15:15:28 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-22 15:15:28 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-22 15:15:28 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-22 15:15:28 --> File loaded: /var/www/html/project/radio/application/views/subcategory/index.php
INFO - 2018-02-22 15:15:28 --> Final output sent to browser
DEBUG - 2018-02-22 15:15:28 --> Total execution time: 0.0068
INFO - 2018-02-22 15:15:46 --> Config Class Initialized
INFO - 2018-02-22 15:15:46 --> Hooks Class Initialized
DEBUG - 2018-02-22 15:15:46 --> UTF-8 Support Enabled
INFO - 2018-02-22 15:15:46 --> Utf8 Class Initialized
INFO - 2018-02-22 15:15:46 --> URI Class Initialized
INFO - 2018-02-22 15:15:46 --> Router Class Initialized
INFO - 2018-02-22 15:15:46 --> Output Class Initialized
INFO - 2018-02-22 15:15:46 --> Security Class Initialized
DEBUG - 2018-02-22 15:15:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-22 15:15:46 --> Input Class Initialized
INFO - 2018-02-22 15:15:46 --> Language Class Initialized
INFO - 2018-02-22 15:15:46 --> Loader Class Initialized
INFO - 2018-02-22 15:15:46 --> Helper loaded: url_helper
INFO - 2018-02-22 15:15:46 --> Helper loaded: file_helper
INFO - 2018-02-22 15:15:46 --> Helper loaded: email_helper
INFO - 2018-02-22 15:15:46 --> Helper loaded: common_helper
INFO - 2018-02-22 15:15:46 --> Database Driver Class Initialized
DEBUG - 2018-02-22 15:15:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-22 15:15:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-22 15:15:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-22 15:15:46 --> Pagination Class Initialized
INFO - 2018-02-22 15:15:46 --> Helper loaded: form_helper
INFO - 2018-02-22 15:15:46 --> Form Validation Class Initialized
INFO - 2018-02-22 15:15:46 --> Model Class Initialized
INFO - 2018-02-22 15:15:46 --> Controller Class Initialized
DEBUG - 2018-02-22 15:15:46 --> Config file loaded: /var/www/html/project/radio/application/config/rest.php
INFO - 2018-02-22 15:15:46 --> Helper loaded: inflector_helper
INFO - 2018-02-22 15:15:46 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-22 15:15:46 --> Model Class Initialized
INFO - 2018-02-22 15:15:46 --> Model Class Initialized
INFO - 2018-02-22 15:15:46 --> Model Class Initialized
INFO - 2018-02-22 15:15:46 --> Model Class Initialized
INFO - 2018-02-22 15:15:46 --> Model Class Initialized
INFO - 2018-02-22 15:15:46 --> Model Class Initialized
INFO - 2018-02-22 15:15:46 --> Final output sent to browser
DEBUG - 2018-02-22 15:15:46 --> Total execution time: 0.0084
INFO - 2018-02-22 15:16:01 --> Config Class Initialized
INFO - 2018-02-22 15:16:01 --> Hooks Class Initialized
DEBUG - 2018-02-22 15:16:01 --> UTF-8 Support Enabled
INFO - 2018-02-22 15:16:01 --> Utf8 Class Initialized
INFO - 2018-02-22 15:16:01 --> URI Class Initialized
INFO - 2018-02-22 15:16:01 --> Router Class Initialized
INFO - 2018-02-22 15:16:01 --> Output Class Initialized
INFO - 2018-02-22 15:16:01 --> Security Class Initialized
DEBUG - 2018-02-22 15:16:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-22 15:16:01 --> Input Class Initialized
INFO - 2018-02-22 15:16:01 --> Language Class Initialized
INFO - 2018-02-22 15:16:01 --> Loader Class Initialized
INFO - 2018-02-22 15:16:01 --> Helper loaded: url_helper
INFO - 2018-02-22 15:16:01 --> Helper loaded: file_helper
INFO - 2018-02-22 15:16:01 --> Helper loaded: email_helper
INFO - 2018-02-22 15:16:01 --> Helper loaded: common_helper
INFO - 2018-02-22 15:16:01 --> Database Driver Class Initialized
DEBUG - 2018-02-22 15:16:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-22 15:16:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-22 15:16:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-22 15:16:01 --> Pagination Class Initialized
INFO - 2018-02-22 15:16:01 --> Helper loaded: form_helper
INFO - 2018-02-22 15:16:01 --> Form Validation Class Initialized
INFO - 2018-02-22 15:16:01 --> Model Class Initialized
INFO - 2018-02-22 15:16:01 --> Controller Class Initialized
DEBUG - 2018-02-22 15:16:01 --> Config file loaded: /var/www/html/project/radio/application/config/rest.php
INFO - 2018-02-22 15:16:01 --> Helper loaded: inflector_helper
INFO - 2018-02-22 15:16:01 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-22 15:16:01 --> Model Class Initialized
INFO - 2018-02-22 15:16:01 --> Model Class Initialized
INFO - 2018-02-22 15:16:01 --> Model Class Initialized
INFO - 2018-02-22 15:16:01 --> Model Class Initialized
INFO - 2018-02-22 15:16:01 --> Model Class Initialized
INFO - 2018-02-22 15:16:01 --> Model Class Initialized
INFO - 2018-02-22 15:16:01 --> Final output sent to browser
DEBUG - 2018-02-22 15:16:01 --> Total execution time: 0.0116
INFO - 2018-02-22 15:16:32 --> Config Class Initialized
INFO - 2018-02-22 15:16:32 --> Hooks Class Initialized
DEBUG - 2018-02-22 15:16:32 --> UTF-8 Support Enabled
INFO - 2018-02-22 15:16:32 --> Utf8 Class Initialized
INFO - 2018-02-22 15:16:32 --> URI Class Initialized
INFO - 2018-02-22 15:16:32 --> Router Class Initialized
INFO - 2018-02-22 15:16:32 --> Output Class Initialized
INFO - 2018-02-22 15:16:32 --> Security Class Initialized
DEBUG - 2018-02-22 15:16:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-22 15:16:32 --> Input Class Initialized
INFO - 2018-02-22 15:16:32 --> Language Class Initialized
INFO - 2018-02-22 15:16:32 --> Loader Class Initialized
INFO - 2018-02-22 15:16:32 --> Helper loaded: url_helper
INFO - 2018-02-22 15:16:32 --> Helper loaded: file_helper
INFO - 2018-02-22 15:16:32 --> Helper loaded: email_helper
INFO - 2018-02-22 15:16:32 --> Helper loaded: common_helper
INFO - 2018-02-22 15:16:32 --> Database Driver Class Initialized
DEBUG - 2018-02-22 15:16:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-22 15:16:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-22 15:16:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-22 15:16:32 --> Pagination Class Initialized
INFO - 2018-02-22 15:16:32 --> Helper loaded: form_helper
INFO - 2018-02-22 15:16:32 --> Form Validation Class Initialized
INFO - 2018-02-22 15:16:32 --> Model Class Initialized
INFO - 2018-02-22 15:16:32 --> Controller Class Initialized
DEBUG - 2018-02-22 15:16:32 --> Config file loaded: /var/www/html/project/radio/application/config/rest.php
INFO - 2018-02-22 15:16:32 --> Helper loaded: inflector_helper
INFO - 2018-02-22 15:16:32 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-22 15:16:32 --> Model Class Initialized
INFO - 2018-02-22 15:16:32 --> Model Class Initialized
INFO - 2018-02-22 15:16:32 --> Model Class Initialized
INFO - 2018-02-22 15:16:32 --> Model Class Initialized
INFO - 2018-02-22 15:16:32 --> Model Class Initialized
INFO - 2018-02-22 15:16:32 --> Model Class Initialized
INFO - 2018-02-22 15:16:32 --> Final output sent to browser
DEBUG - 2018-02-22 15:16:32 --> Total execution time: 0.0121
INFO - 2018-02-22 15:16:49 --> Config Class Initialized
INFO - 2018-02-22 15:16:49 --> Hooks Class Initialized
DEBUG - 2018-02-22 15:16:49 --> UTF-8 Support Enabled
INFO - 2018-02-22 15:16:49 --> Utf8 Class Initialized
INFO - 2018-02-22 15:16:49 --> URI Class Initialized
INFO - 2018-02-22 15:16:49 --> Router Class Initialized
INFO - 2018-02-22 15:16:49 --> Output Class Initialized
INFO - 2018-02-22 15:16:49 --> Security Class Initialized
DEBUG - 2018-02-22 15:16:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-22 15:16:49 --> Input Class Initialized
INFO - 2018-02-22 15:16:49 --> Language Class Initialized
INFO - 2018-02-22 15:16:49 --> Loader Class Initialized
INFO - 2018-02-22 15:16:49 --> Helper loaded: url_helper
INFO - 2018-02-22 15:16:49 --> Helper loaded: file_helper
INFO - 2018-02-22 15:16:49 --> Helper loaded: email_helper
INFO - 2018-02-22 15:16:49 --> Helper loaded: common_helper
INFO - 2018-02-22 15:16:49 --> Database Driver Class Initialized
DEBUG - 2018-02-22 15:16:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-22 15:16:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-22 15:16:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-22 15:16:49 --> Pagination Class Initialized
INFO - 2018-02-22 15:16:49 --> Helper loaded: form_helper
INFO - 2018-02-22 15:16:49 --> Form Validation Class Initialized
INFO - 2018-02-22 15:16:49 --> Model Class Initialized
INFO - 2018-02-22 15:16:49 --> Controller Class Initialized
DEBUG - 2018-02-22 15:16:49 --> Config file loaded: /var/www/html/project/radio/application/config/rest.php
INFO - 2018-02-22 15:16:49 --> Helper loaded: inflector_helper
INFO - 2018-02-22 15:16:49 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-22 15:16:49 --> Model Class Initialized
INFO - 2018-02-22 15:16:49 --> Model Class Initialized
INFO - 2018-02-22 15:16:49 --> Model Class Initialized
INFO - 2018-02-22 15:16:49 --> Model Class Initialized
INFO - 2018-02-22 15:16:49 --> Model Class Initialized
INFO - 2018-02-22 15:16:49 --> Model Class Initialized
INFO - 2018-02-22 15:16:49 --> Final output sent to browser
DEBUG - 2018-02-22 15:16:49 --> Total execution time: 0.0103
INFO - 2018-02-22 15:16:51 --> Config Class Initialized
INFO - 2018-02-22 15:16:51 --> Hooks Class Initialized
DEBUG - 2018-02-22 15:16:51 --> UTF-8 Support Enabled
INFO - 2018-02-22 15:16:51 --> Utf8 Class Initialized
INFO - 2018-02-22 15:16:51 --> URI Class Initialized
INFO - 2018-02-22 15:16:51 --> Router Class Initialized
INFO - 2018-02-22 15:16:51 --> Output Class Initialized
INFO - 2018-02-22 15:16:51 --> Security Class Initialized
DEBUG - 2018-02-22 15:16:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-22 15:16:51 --> Input Class Initialized
INFO - 2018-02-22 15:16:51 --> Language Class Initialized
INFO - 2018-02-22 15:16:51 --> Loader Class Initialized
INFO - 2018-02-22 15:16:51 --> Helper loaded: url_helper
INFO - 2018-02-22 15:16:51 --> Helper loaded: file_helper
INFO - 2018-02-22 15:16:51 --> Helper loaded: email_helper
INFO - 2018-02-22 15:16:51 --> Helper loaded: common_helper
INFO - 2018-02-22 15:16:51 --> Database Driver Class Initialized
DEBUG - 2018-02-22 15:16:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-22 15:16:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-22 15:16:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-22 15:16:51 --> Pagination Class Initialized
INFO - 2018-02-22 15:16:51 --> Helper loaded: form_helper
INFO - 2018-02-22 15:16:51 --> Form Validation Class Initialized
INFO - 2018-02-22 15:16:51 --> Model Class Initialized
INFO - 2018-02-22 15:16:51 --> Controller Class Initialized
DEBUG - 2018-02-22 15:16:51 --> Config file loaded: /var/www/html/project/radio/application/config/rest.php
INFO - 2018-02-22 15:16:51 --> Helper loaded: inflector_helper
INFO - 2018-02-22 15:16:51 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-22 15:16:51 --> Model Class Initialized
INFO - 2018-02-22 15:16:51 --> Model Class Initialized
INFO - 2018-02-22 15:16:51 --> Model Class Initialized
INFO - 2018-02-22 15:16:51 --> Model Class Initialized
INFO - 2018-02-22 15:16:51 --> Model Class Initialized
INFO - 2018-02-22 15:16:51 --> Model Class Initialized
INFO - 2018-02-22 15:16:51 --> Final output sent to browser
DEBUG - 2018-02-22 15:16:51 --> Total execution time: 0.0081
INFO - 2018-02-22 15:16:52 --> Config Class Initialized
INFO - 2018-02-22 15:16:52 --> Hooks Class Initialized
DEBUG - 2018-02-22 15:16:52 --> UTF-8 Support Enabled
INFO - 2018-02-22 15:16:52 --> Utf8 Class Initialized
INFO - 2018-02-22 15:16:52 --> URI Class Initialized
INFO - 2018-02-22 15:16:52 --> Router Class Initialized
INFO - 2018-02-22 15:16:52 --> Output Class Initialized
INFO - 2018-02-22 15:16:52 --> Security Class Initialized
DEBUG - 2018-02-22 15:16:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-22 15:16:52 --> Input Class Initialized
INFO - 2018-02-22 15:16:52 --> Language Class Initialized
INFO - 2018-02-22 15:16:52 --> Loader Class Initialized
INFO - 2018-02-22 15:16:52 --> Helper loaded: url_helper
INFO - 2018-02-22 15:16:52 --> Helper loaded: file_helper
INFO - 2018-02-22 15:16:52 --> Helper loaded: email_helper
INFO - 2018-02-22 15:16:52 --> Helper loaded: common_helper
INFO - 2018-02-22 15:16:52 --> Database Driver Class Initialized
DEBUG - 2018-02-22 15:16:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-22 15:16:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-22 15:16:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-22 15:16:52 --> Pagination Class Initialized
INFO - 2018-02-22 15:16:52 --> Helper loaded: form_helper
INFO - 2018-02-22 15:16:52 --> Form Validation Class Initialized
INFO - 2018-02-22 15:16:52 --> Model Class Initialized
INFO - 2018-02-22 15:16:52 --> Controller Class Initialized
DEBUG - 2018-02-22 15:16:52 --> Config file loaded: /var/www/html/project/radio/application/config/rest.php
INFO - 2018-02-22 15:16:52 --> Helper loaded: inflector_helper
INFO - 2018-02-22 15:16:52 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-22 15:16:52 --> Model Class Initialized
INFO - 2018-02-22 15:16:52 --> Model Class Initialized
INFO - 2018-02-22 15:16:52 --> Model Class Initialized
INFO - 2018-02-22 15:16:52 --> Model Class Initialized
INFO - 2018-02-22 15:16:52 --> Model Class Initialized
INFO - 2018-02-22 15:16:52 --> Model Class Initialized
INFO - 2018-02-22 15:16:52 --> Final output sent to browser
DEBUG - 2018-02-22 15:16:52 --> Total execution time: 0.0079
INFO - 2018-02-22 15:16:53 --> Config Class Initialized
INFO - 2018-02-22 15:16:53 --> Hooks Class Initialized
DEBUG - 2018-02-22 15:16:53 --> UTF-8 Support Enabled
INFO - 2018-02-22 15:16:53 --> Utf8 Class Initialized
INFO - 2018-02-22 15:16:53 --> URI Class Initialized
INFO - 2018-02-22 15:16:53 --> Router Class Initialized
INFO - 2018-02-22 15:16:53 --> Output Class Initialized
INFO - 2018-02-22 15:16:53 --> Security Class Initialized
DEBUG - 2018-02-22 15:16:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-22 15:16:53 --> Input Class Initialized
INFO - 2018-02-22 15:16:53 --> Language Class Initialized
INFO - 2018-02-22 15:16:53 --> Loader Class Initialized
INFO - 2018-02-22 15:16:53 --> Helper loaded: url_helper
INFO - 2018-02-22 15:16:53 --> Helper loaded: file_helper
INFO - 2018-02-22 15:16:53 --> Helper loaded: email_helper
INFO - 2018-02-22 15:16:53 --> Helper loaded: common_helper
INFO - 2018-02-22 15:16:53 --> Database Driver Class Initialized
DEBUG - 2018-02-22 15:16:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-22 15:16:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-22 15:16:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-22 15:16:53 --> Pagination Class Initialized
INFO - 2018-02-22 15:16:53 --> Helper loaded: form_helper
INFO - 2018-02-22 15:16:53 --> Form Validation Class Initialized
INFO - 2018-02-22 15:16:53 --> Model Class Initialized
INFO - 2018-02-22 15:16:53 --> Controller Class Initialized
DEBUG - 2018-02-22 15:16:53 --> Config file loaded: /var/www/html/project/radio/application/config/rest.php
INFO - 2018-02-22 15:16:53 --> Helper loaded: inflector_helper
INFO - 2018-02-22 15:16:53 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-22 15:16:53 --> Model Class Initialized
INFO - 2018-02-22 15:16:53 --> Model Class Initialized
INFO - 2018-02-22 15:16:53 --> Model Class Initialized
INFO - 2018-02-22 15:16:53 --> Model Class Initialized
INFO - 2018-02-22 15:16:53 --> Model Class Initialized
INFO - 2018-02-22 15:16:53 --> Model Class Initialized
INFO - 2018-02-22 15:16:53 --> Final output sent to browser
DEBUG - 2018-02-22 15:16:53 --> Total execution time: 0.0112
INFO - 2018-02-22 15:16:53 --> Config Class Initialized
INFO - 2018-02-22 15:16:53 --> Hooks Class Initialized
DEBUG - 2018-02-22 15:16:53 --> UTF-8 Support Enabled
INFO - 2018-02-22 15:16:53 --> Utf8 Class Initialized
INFO - 2018-02-22 15:16:53 --> URI Class Initialized
INFO - 2018-02-22 15:16:53 --> Router Class Initialized
INFO - 2018-02-22 15:16:53 --> Output Class Initialized
INFO - 2018-02-22 15:16:53 --> Security Class Initialized
DEBUG - 2018-02-22 15:16:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-22 15:16:53 --> Input Class Initialized
INFO - 2018-02-22 15:16:53 --> Language Class Initialized
INFO - 2018-02-22 15:16:53 --> Loader Class Initialized
INFO - 2018-02-22 15:16:53 --> Helper loaded: url_helper
INFO - 2018-02-22 15:16:53 --> Helper loaded: file_helper
INFO - 2018-02-22 15:16:53 --> Helper loaded: email_helper
INFO - 2018-02-22 15:16:53 --> Helper loaded: common_helper
INFO - 2018-02-22 15:16:53 --> Database Driver Class Initialized
DEBUG - 2018-02-22 15:16:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-22 15:16:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-22 15:16:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-22 15:16:53 --> Pagination Class Initialized
INFO - 2018-02-22 15:16:53 --> Helper loaded: form_helper
INFO - 2018-02-22 15:16:53 --> Form Validation Class Initialized
INFO - 2018-02-22 15:16:53 --> Model Class Initialized
INFO - 2018-02-22 15:16:53 --> Controller Class Initialized
DEBUG - 2018-02-22 15:16:53 --> Config file loaded: /var/www/html/project/radio/application/config/rest.php
INFO - 2018-02-22 15:16:53 --> Helper loaded: inflector_helper
INFO - 2018-02-22 15:16:53 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-22 15:16:53 --> Model Class Initialized
INFO - 2018-02-22 15:16:53 --> Model Class Initialized
INFO - 2018-02-22 15:16:53 --> Model Class Initialized
INFO - 2018-02-22 15:16:53 --> Model Class Initialized
INFO - 2018-02-22 15:16:53 --> Model Class Initialized
INFO - 2018-02-22 15:16:53 --> Model Class Initialized
INFO - 2018-02-22 15:16:53 --> Final output sent to browser
DEBUG - 2018-02-22 15:16:53 --> Total execution time: 0.0103
INFO - 2018-02-22 15:16:55 --> Config Class Initialized
INFO - 2018-02-22 15:16:55 --> Hooks Class Initialized
DEBUG - 2018-02-22 15:16:55 --> UTF-8 Support Enabled
INFO - 2018-02-22 15:16:55 --> Utf8 Class Initialized
INFO - 2018-02-22 15:16:55 --> URI Class Initialized
INFO - 2018-02-22 15:16:55 --> Router Class Initialized
INFO - 2018-02-22 15:16:55 --> Output Class Initialized
INFO - 2018-02-22 15:16:55 --> Security Class Initialized
DEBUG - 2018-02-22 15:16:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-22 15:16:55 --> Input Class Initialized
INFO - 2018-02-22 15:16:55 --> Language Class Initialized
INFO - 2018-02-22 15:16:55 --> Loader Class Initialized
INFO - 2018-02-22 15:16:55 --> Helper loaded: url_helper
INFO - 2018-02-22 15:16:55 --> Helper loaded: file_helper
INFO - 2018-02-22 15:16:55 --> Helper loaded: email_helper
INFO - 2018-02-22 15:16:55 --> Helper loaded: common_helper
INFO - 2018-02-22 15:16:55 --> Database Driver Class Initialized
DEBUG - 2018-02-22 15:16:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-22 15:16:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-22 15:16:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-22 15:16:55 --> Pagination Class Initialized
INFO - 2018-02-22 15:16:55 --> Helper loaded: form_helper
INFO - 2018-02-22 15:16:55 --> Form Validation Class Initialized
INFO - 2018-02-22 15:16:55 --> Model Class Initialized
INFO - 2018-02-22 15:16:55 --> Controller Class Initialized
DEBUG - 2018-02-22 15:16:55 --> Config file loaded: /var/www/html/project/radio/application/config/rest.php
INFO - 2018-02-22 15:16:55 --> Helper loaded: inflector_helper
INFO - 2018-02-22 15:16:55 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-22 15:16:55 --> Model Class Initialized
INFO - 2018-02-22 15:16:55 --> Model Class Initialized
INFO - 2018-02-22 15:16:55 --> Model Class Initialized
INFO - 2018-02-22 15:16:55 --> Model Class Initialized
INFO - 2018-02-22 15:16:55 --> Model Class Initialized
INFO - 2018-02-22 15:16:55 --> Model Class Initialized
INFO - 2018-02-22 15:16:55 --> Final output sent to browser
DEBUG - 2018-02-22 15:16:55 --> Total execution time: 0.0101
INFO - 2018-02-22 15:16:56 --> Config Class Initialized
INFO - 2018-02-22 15:16:56 --> Hooks Class Initialized
DEBUG - 2018-02-22 15:16:56 --> UTF-8 Support Enabled
INFO - 2018-02-22 15:16:56 --> Utf8 Class Initialized
INFO - 2018-02-22 15:16:56 --> URI Class Initialized
INFO - 2018-02-22 15:16:56 --> Router Class Initialized
INFO - 2018-02-22 15:16:56 --> Output Class Initialized
INFO - 2018-02-22 15:16:56 --> Security Class Initialized
DEBUG - 2018-02-22 15:16:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-22 15:16:56 --> Input Class Initialized
INFO - 2018-02-22 15:16:56 --> Language Class Initialized
INFO - 2018-02-22 15:16:56 --> Loader Class Initialized
INFO - 2018-02-22 15:16:56 --> Helper loaded: url_helper
INFO - 2018-02-22 15:16:56 --> Helper loaded: file_helper
INFO - 2018-02-22 15:16:56 --> Helper loaded: email_helper
INFO - 2018-02-22 15:16:56 --> Helper loaded: common_helper
INFO - 2018-02-22 15:16:56 --> Database Driver Class Initialized
DEBUG - 2018-02-22 15:16:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-22 15:16:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-22 15:16:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-22 15:16:56 --> Pagination Class Initialized
INFO - 2018-02-22 15:16:56 --> Helper loaded: form_helper
INFO - 2018-02-22 15:16:56 --> Form Validation Class Initialized
INFO - 2018-02-22 15:16:56 --> Model Class Initialized
INFO - 2018-02-22 15:16:56 --> Controller Class Initialized
DEBUG - 2018-02-22 15:16:56 --> Config file loaded: /var/www/html/project/radio/application/config/rest.php
INFO - 2018-02-22 15:16:56 --> Helper loaded: inflector_helper
INFO - 2018-02-22 15:16:56 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-22 15:16:56 --> Model Class Initialized
INFO - 2018-02-22 15:16:56 --> Model Class Initialized
INFO - 2018-02-22 15:16:56 --> Model Class Initialized
INFO - 2018-02-22 15:16:56 --> Model Class Initialized
INFO - 2018-02-22 15:16:56 --> Model Class Initialized
INFO - 2018-02-22 15:16:56 --> Model Class Initialized
INFO - 2018-02-22 15:16:56 --> Final output sent to browser
DEBUG - 2018-02-22 15:16:56 --> Total execution time: 0.0111
INFO - 2018-02-22 15:16:56 --> Config Class Initialized
INFO - 2018-02-22 15:16:56 --> Hooks Class Initialized
DEBUG - 2018-02-22 15:16:56 --> UTF-8 Support Enabled
INFO - 2018-02-22 15:16:56 --> Utf8 Class Initialized
INFO - 2018-02-22 15:16:56 --> URI Class Initialized
INFO - 2018-02-22 15:16:56 --> Router Class Initialized
INFO - 2018-02-22 15:16:56 --> Output Class Initialized
INFO - 2018-02-22 15:16:56 --> Security Class Initialized
DEBUG - 2018-02-22 15:16:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-22 15:16:56 --> Input Class Initialized
INFO - 2018-02-22 15:16:56 --> Language Class Initialized
INFO - 2018-02-22 15:16:56 --> Loader Class Initialized
INFO - 2018-02-22 15:16:56 --> Helper loaded: url_helper
INFO - 2018-02-22 15:16:56 --> Helper loaded: file_helper
INFO - 2018-02-22 15:16:56 --> Helper loaded: email_helper
INFO - 2018-02-22 15:16:56 --> Helper loaded: common_helper
INFO - 2018-02-22 15:16:56 --> Database Driver Class Initialized
DEBUG - 2018-02-22 15:16:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-22 15:16:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-22 15:16:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-22 15:16:56 --> Pagination Class Initialized
INFO - 2018-02-22 15:16:56 --> Helper loaded: form_helper
INFO - 2018-02-22 15:16:56 --> Form Validation Class Initialized
INFO - 2018-02-22 15:16:56 --> Model Class Initialized
INFO - 2018-02-22 15:16:56 --> Controller Class Initialized
DEBUG - 2018-02-22 15:16:56 --> Config file loaded: /var/www/html/project/radio/application/config/rest.php
INFO - 2018-02-22 15:16:56 --> Helper loaded: inflector_helper
INFO - 2018-02-22 15:16:56 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-22 15:16:56 --> Model Class Initialized
INFO - 2018-02-22 15:16:56 --> Model Class Initialized
INFO - 2018-02-22 15:16:56 --> Model Class Initialized
INFO - 2018-02-22 15:16:56 --> Model Class Initialized
INFO - 2018-02-22 15:16:56 --> Model Class Initialized
INFO - 2018-02-22 15:16:56 --> Model Class Initialized
INFO - 2018-02-22 15:16:56 --> Final output sent to browser
DEBUG - 2018-02-22 15:16:56 --> Total execution time: 0.0092
INFO - 2018-02-22 15:16:57 --> Config Class Initialized
INFO - 2018-02-22 15:16:57 --> Hooks Class Initialized
DEBUG - 2018-02-22 15:16:57 --> UTF-8 Support Enabled
INFO - 2018-02-22 15:16:57 --> Utf8 Class Initialized
INFO - 2018-02-22 15:16:57 --> URI Class Initialized
INFO - 2018-02-22 15:16:57 --> Router Class Initialized
INFO - 2018-02-22 15:16:57 --> Output Class Initialized
INFO - 2018-02-22 15:16:57 --> Security Class Initialized
DEBUG - 2018-02-22 15:16:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-22 15:16:57 --> Input Class Initialized
INFO - 2018-02-22 15:16:57 --> Language Class Initialized
INFO - 2018-02-22 15:16:57 --> Loader Class Initialized
INFO - 2018-02-22 15:16:57 --> Helper loaded: url_helper
INFO - 2018-02-22 15:16:57 --> Helper loaded: file_helper
INFO - 2018-02-22 15:16:57 --> Helper loaded: email_helper
INFO - 2018-02-22 15:16:57 --> Helper loaded: common_helper
INFO - 2018-02-22 15:16:57 --> Database Driver Class Initialized
DEBUG - 2018-02-22 15:16:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-22 15:16:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-22 15:16:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-22 15:16:57 --> Pagination Class Initialized
INFO - 2018-02-22 15:16:57 --> Helper loaded: form_helper
INFO - 2018-02-22 15:16:57 --> Form Validation Class Initialized
INFO - 2018-02-22 15:16:57 --> Model Class Initialized
INFO - 2018-02-22 15:16:57 --> Controller Class Initialized
DEBUG - 2018-02-22 15:16:57 --> Config file loaded: /var/www/html/project/radio/application/config/rest.php
INFO - 2018-02-22 15:16:57 --> Helper loaded: inflector_helper
INFO - 2018-02-22 15:16:57 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-22 15:16:57 --> Model Class Initialized
INFO - 2018-02-22 15:16:57 --> Model Class Initialized
INFO - 2018-02-22 15:16:57 --> Model Class Initialized
INFO - 2018-02-22 15:16:57 --> Model Class Initialized
INFO - 2018-02-22 15:16:57 --> Model Class Initialized
INFO - 2018-02-22 15:16:57 --> Model Class Initialized
INFO - 2018-02-22 15:16:57 --> Final output sent to browser
DEBUG - 2018-02-22 15:16:57 --> Total execution time: 0.0086
INFO - 2018-02-22 15:16:57 --> Config Class Initialized
INFO - 2018-02-22 15:16:57 --> Hooks Class Initialized
DEBUG - 2018-02-22 15:16:57 --> UTF-8 Support Enabled
INFO - 2018-02-22 15:16:57 --> Utf8 Class Initialized
INFO - 2018-02-22 15:16:57 --> URI Class Initialized
INFO - 2018-02-22 15:16:57 --> Router Class Initialized
INFO - 2018-02-22 15:16:57 --> Output Class Initialized
INFO - 2018-02-22 15:16:57 --> Security Class Initialized
DEBUG - 2018-02-22 15:16:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-22 15:16:57 --> Input Class Initialized
INFO - 2018-02-22 15:16:57 --> Language Class Initialized
INFO - 2018-02-22 15:16:57 --> Loader Class Initialized
INFO - 2018-02-22 15:16:57 --> Helper loaded: url_helper
INFO - 2018-02-22 15:16:57 --> Helper loaded: file_helper
INFO - 2018-02-22 15:16:57 --> Helper loaded: email_helper
INFO - 2018-02-22 15:16:57 --> Helper loaded: common_helper
INFO - 2018-02-22 15:16:57 --> Database Driver Class Initialized
DEBUG - 2018-02-22 15:16:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-22 15:16:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-22 15:16:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-22 15:16:57 --> Pagination Class Initialized
INFO - 2018-02-22 15:16:57 --> Helper loaded: form_helper
INFO - 2018-02-22 15:16:57 --> Form Validation Class Initialized
INFO - 2018-02-22 15:16:57 --> Model Class Initialized
INFO - 2018-02-22 15:16:57 --> Controller Class Initialized
DEBUG - 2018-02-22 15:16:57 --> Config file loaded: /var/www/html/project/radio/application/config/rest.php
INFO - 2018-02-22 15:16:57 --> Helper loaded: inflector_helper
INFO - 2018-02-22 15:16:57 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-22 15:16:57 --> Model Class Initialized
INFO - 2018-02-22 15:16:57 --> Model Class Initialized
INFO - 2018-02-22 15:16:57 --> Model Class Initialized
INFO - 2018-02-22 15:16:57 --> Model Class Initialized
INFO - 2018-02-22 15:16:57 --> Model Class Initialized
INFO - 2018-02-22 15:16:57 --> Model Class Initialized
INFO - 2018-02-22 15:16:57 --> Final output sent to browser
DEBUG - 2018-02-22 15:16:57 --> Total execution time: 0.0103
INFO - 2018-02-22 15:16:57 --> Config Class Initialized
INFO - 2018-02-22 15:16:57 --> Hooks Class Initialized
DEBUG - 2018-02-22 15:16:57 --> UTF-8 Support Enabled
INFO - 2018-02-22 15:16:57 --> Utf8 Class Initialized
INFO - 2018-02-22 15:16:57 --> URI Class Initialized
INFO - 2018-02-22 15:16:57 --> Router Class Initialized
INFO - 2018-02-22 15:16:57 --> Output Class Initialized
INFO - 2018-02-22 15:16:57 --> Security Class Initialized
DEBUG - 2018-02-22 15:16:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-22 15:16:57 --> Input Class Initialized
INFO - 2018-02-22 15:16:57 --> Language Class Initialized
INFO - 2018-02-22 15:16:57 --> Loader Class Initialized
INFO - 2018-02-22 15:16:57 --> Helper loaded: url_helper
INFO - 2018-02-22 15:16:57 --> Helper loaded: file_helper
INFO - 2018-02-22 15:16:57 --> Helper loaded: email_helper
INFO - 2018-02-22 15:16:57 --> Helper loaded: common_helper
INFO - 2018-02-22 15:16:57 --> Database Driver Class Initialized
DEBUG - 2018-02-22 15:16:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-22 15:16:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-22 15:16:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-22 15:16:57 --> Pagination Class Initialized
INFO - 2018-02-22 15:16:57 --> Helper loaded: form_helper
INFO - 2018-02-22 15:16:57 --> Form Validation Class Initialized
INFO - 2018-02-22 15:16:57 --> Model Class Initialized
INFO - 2018-02-22 15:16:57 --> Controller Class Initialized
DEBUG - 2018-02-22 15:16:57 --> Config file loaded: /var/www/html/project/radio/application/config/rest.php
INFO - 2018-02-22 15:16:57 --> Helper loaded: inflector_helper
INFO - 2018-02-22 15:16:57 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-22 15:16:57 --> Model Class Initialized
INFO - 2018-02-22 15:16:57 --> Model Class Initialized
INFO - 2018-02-22 15:16:57 --> Model Class Initialized
INFO - 2018-02-22 15:16:57 --> Model Class Initialized
INFO - 2018-02-22 15:16:57 --> Model Class Initialized
INFO - 2018-02-22 15:16:57 --> Model Class Initialized
INFO - 2018-02-22 15:16:57 --> Final output sent to browser
DEBUG - 2018-02-22 15:16:57 --> Total execution time: 0.0109
INFO - 2018-02-22 15:16:58 --> Config Class Initialized
INFO - 2018-02-22 15:16:58 --> Hooks Class Initialized
DEBUG - 2018-02-22 15:16:58 --> UTF-8 Support Enabled
INFO - 2018-02-22 15:16:58 --> Utf8 Class Initialized
INFO - 2018-02-22 15:16:58 --> URI Class Initialized
INFO - 2018-02-22 15:16:58 --> Router Class Initialized
INFO - 2018-02-22 15:16:58 --> Output Class Initialized
INFO - 2018-02-22 15:16:58 --> Security Class Initialized
DEBUG - 2018-02-22 15:16:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-22 15:16:58 --> Input Class Initialized
INFO - 2018-02-22 15:16:58 --> Language Class Initialized
INFO - 2018-02-22 15:16:58 --> Loader Class Initialized
INFO - 2018-02-22 15:16:58 --> Helper loaded: url_helper
INFO - 2018-02-22 15:16:58 --> Helper loaded: file_helper
INFO - 2018-02-22 15:16:58 --> Helper loaded: email_helper
INFO - 2018-02-22 15:16:58 --> Helper loaded: common_helper
INFO - 2018-02-22 15:16:58 --> Database Driver Class Initialized
DEBUG - 2018-02-22 15:16:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-22 15:16:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-22 15:16:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-22 15:16:58 --> Pagination Class Initialized
INFO - 2018-02-22 15:16:58 --> Helper loaded: form_helper
INFO - 2018-02-22 15:16:58 --> Form Validation Class Initialized
INFO - 2018-02-22 15:16:58 --> Model Class Initialized
INFO - 2018-02-22 15:16:58 --> Controller Class Initialized
DEBUG - 2018-02-22 15:16:58 --> Config file loaded: /var/www/html/project/radio/application/config/rest.php
INFO - 2018-02-22 15:16:58 --> Helper loaded: inflector_helper
INFO - 2018-02-22 15:16:58 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-22 15:16:58 --> Model Class Initialized
INFO - 2018-02-22 15:16:58 --> Model Class Initialized
INFO - 2018-02-22 15:16:58 --> Model Class Initialized
INFO - 2018-02-22 15:16:58 --> Model Class Initialized
INFO - 2018-02-22 15:16:58 --> Model Class Initialized
INFO - 2018-02-22 15:16:58 --> Model Class Initialized
INFO - 2018-02-22 15:16:58 --> Final output sent to browser
DEBUG - 2018-02-22 15:16:58 --> Total execution time: 0.0103
INFO - 2018-02-22 15:16:58 --> Config Class Initialized
INFO - 2018-02-22 15:16:58 --> Hooks Class Initialized
DEBUG - 2018-02-22 15:16:58 --> UTF-8 Support Enabled
INFO - 2018-02-22 15:16:58 --> Utf8 Class Initialized
INFO - 2018-02-22 15:16:58 --> URI Class Initialized
INFO - 2018-02-22 15:16:58 --> Router Class Initialized
INFO - 2018-02-22 15:16:58 --> Output Class Initialized
INFO - 2018-02-22 15:16:58 --> Security Class Initialized
DEBUG - 2018-02-22 15:16:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-22 15:16:58 --> Input Class Initialized
INFO - 2018-02-22 15:16:58 --> Language Class Initialized
INFO - 2018-02-22 15:16:58 --> Loader Class Initialized
INFO - 2018-02-22 15:16:58 --> Helper loaded: url_helper
INFO - 2018-02-22 15:16:58 --> Helper loaded: file_helper
INFO - 2018-02-22 15:16:58 --> Helper loaded: email_helper
INFO - 2018-02-22 15:16:58 --> Helper loaded: common_helper
INFO - 2018-02-22 15:16:58 --> Database Driver Class Initialized
DEBUG - 2018-02-22 15:16:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-22 15:16:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-22 15:16:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-22 15:16:58 --> Pagination Class Initialized
INFO - 2018-02-22 15:16:58 --> Helper loaded: form_helper
INFO - 2018-02-22 15:16:58 --> Form Validation Class Initialized
INFO - 2018-02-22 15:16:58 --> Model Class Initialized
INFO - 2018-02-22 15:16:58 --> Controller Class Initialized
DEBUG - 2018-02-22 15:16:58 --> Config file loaded: /var/www/html/project/radio/application/config/rest.php
INFO - 2018-02-22 15:16:58 --> Helper loaded: inflector_helper
INFO - 2018-02-22 15:16:58 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-22 15:16:58 --> Model Class Initialized
INFO - 2018-02-22 15:16:58 --> Model Class Initialized
INFO - 2018-02-22 15:16:58 --> Model Class Initialized
INFO - 2018-02-22 15:16:58 --> Model Class Initialized
INFO - 2018-02-22 15:16:58 --> Model Class Initialized
INFO - 2018-02-22 15:16:58 --> Model Class Initialized
INFO - 2018-02-22 15:16:58 --> Final output sent to browser
DEBUG - 2018-02-22 15:16:58 --> Total execution time: 0.0095
INFO - 2018-02-22 15:16:58 --> Config Class Initialized
INFO - 2018-02-22 15:16:58 --> Hooks Class Initialized
DEBUG - 2018-02-22 15:16:58 --> UTF-8 Support Enabled
INFO - 2018-02-22 15:16:58 --> Utf8 Class Initialized
INFO - 2018-02-22 15:16:58 --> URI Class Initialized
INFO - 2018-02-22 15:16:58 --> Router Class Initialized
INFO - 2018-02-22 15:16:58 --> Output Class Initialized
INFO - 2018-02-22 15:16:58 --> Security Class Initialized
DEBUG - 2018-02-22 15:16:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-22 15:16:58 --> Input Class Initialized
INFO - 2018-02-22 15:16:58 --> Language Class Initialized
INFO - 2018-02-22 15:16:58 --> Loader Class Initialized
INFO - 2018-02-22 15:16:58 --> Helper loaded: url_helper
INFO - 2018-02-22 15:16:58 --> Helper loaded: file_helper
INFO - 2018-02-22 15:16:58 --> Helper loaded: email_helper
INFO - 2018-02-22 15:16:58 --> Helper loaded: common_helper
INFO - 2018-02-22 15:16:58 --> Database Driver Class Initialized
DEBUG - 2018-02-22 15:16:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-22 15:16:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-22 15:16:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-22 15:16:58 --> Pagination Class Initialized
INFO - 2018-02-22 15:16:58 --> Helper loaded: form_helper
INFO - 2018-02-22 15:16:58 --> Form Validation Class Initialized
INFO - 2018-02-22 15:16:58 --> Model Class Initialized
INFO - 2018-02-22 15:16:58 --> Controller Class Initialized
DEBUG - 2018-02-22 15:16:58 --> Config file loaded: /var/www/html/project/radio/application/config/rest.php
INFO - 2018-02-22 15:16:58 --> Helper loaded: inflector_helper
INFO - 2018-02-22 15:16:58 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-22 15:16:58 --> Model Class Initialized
INFO - 2018-02-22 15:16:58 --> Model Class Initialized
INFO - 2018-02-22 15:16:58 --> Model Class Initialized
INFO - 2018-02-22 15:16:58 --> Model Class Initialized
INFO - 2018-02-22 15:16:58 --> Model Class Initialized
INFO - 2018-02-22 15:16:58 --> Model Class Initialized
INFO - 2018-02-22 15:16:58 --> Final output sent to browser
DEBUG - 2018-02-22 15:16:58 --> Total execution time: 0.0099
INFO - 2018-02-22 15:17:15 --> Config Class Initialized
INFO - 2018-02-22 15:17:15 --> Hooks Class Initialized
DEBUG - 2018-02-22 15:17:15 --> UTF-8 Support Enabled
INFO - 2018-02-22 15:17:15 --> Utf8 Class Initialized
INFO - 2018-02-22 15:17:15 --> URI Class Initialized
INFO - 2018-02-22 15:17:15 --> Router Class Initialized
INFO - 2018-02-22 15:17:15 --> Output Class Initialized
INFO - 2018-02-22 15:17:15 --> Security Class Initialized
DEBUG - 2018-02-22 15:17:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-22 15:17:15 --> Input Class Initialized
INFO - 2018-02-22 15:17:15 --> Language Class Initialized
INFO - 2018-02-22 15:17:15 --> Loader Class Initialized
INFO - 2018-02-22 15:17:15 --> Helper loaded: url_helper
INFO - 2018-02-22 15:17:15 --> Helper loaded: file_helper
INFO - 2018-02-22 15:17:15 --> Helper loaded: email_helper
INFO - 2018-02-22 15:17:15 --> Helper loaded: common_helper
INFO - 2018-02-22 15:17:15 --> Database Driver Class Initialized
DEBUG - 2018-02-22 15:17:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-22 15:17:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-22 15:17:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-22 15:17:15 --> Pagination Class Initialized
INFO - 2018-02-22 15:17:15 --> Helper loaded: form_helper
INFO - 2018-02-22 15:17:15 --> Form Validation Class Initialized
INFO - 2018-02-22 15:17:15 --> Model Class Initialized
INFO - 2018-02-22 15:17:15 --> Controller Class Initialized
DEBUG - 2018-02-22 15:17:15 --> Config file loaded: /var/www/html/project/radio/application/config/rest.php
INFO - 2018-02-22 15:17:15 --> Helper loaded: inflector_helper
INFO - 2018-02-22 15:17:15 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-22 15:17:15 --> Model Class Initialized
INFO - 2018-02-22 15:17:15 --> Model Class Initialized
INFO - 2018-02-22 15:17:15 --> Model Class Initialized
INFO - 2018-02-22 15:17:15 --> Model Class Initialized
INFO - 2018-02-22 15:17:15 --> Model Class Initialized
INFO - 2018-02-22 15:17:15 --> Model Class Initialized
INFO - 2018-02-22 15:17:15 --> Final output sent to browser
DEBUG - 2018-02-22 15:17:15 --> Total execution time: 0.0106
INFO - 2018-02-22 15:17:28 --> Config Class Initialized
INFO - 2018-02-22 15:17:28 --> Hooks Class Initialized
DEBUG - 2018-02-22 15:17:28 --> UTF-8 Support Enabled
INFO - 2018-02-22 15:17:28 --> Utf8 Class Initialized
INFO - 2018-02-22 15:17:28 --> URI Class Initialized
INFO - 2018-02-22 15:17:28 --> Router Class Initialized
INFO - 2018-02-22 15:17:28 --> Output Class Initialized
INFO - 2018-02-22 15:17:28 --> Security Class Initialized
DEBUG - 2018-02-22 15:17:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-22 15:17:28 --> Input Class Initialized
INFO - 2018-02-22 15:17:28 --> Language Class Initialized
INFO - 2018-02-22 15:17:28 --> Loader Class Initialized
INFO - 2018-02-22 15:17:28 --> Helper loaded: url_helper
INFO - 2018-02-22 15:17:28 --> Helper loaded: file_helper
INFO - 2018-02-22 15:17:28 --> Helper loaded: email_helper
INFO - 2018-02-22 15:17:28 --> Helper loaded: common_helper
INFO - 2018-02-22 15:17:28 --> Database Driver Class Initialized
DEBUG - 2018-02-22 15:17:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-22 15:17:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-22 15:17:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-22 15:17:28 --> Pagination Class Initialized
INFO - 2018-02-22 15:17:28 --> Helper loaded: form_helper
INFO - 2018-02-22 15:17:28 --> Form Validation Class Initialized
INFO - 2018-02-22 15:17:28 --> Model Class Initialized
INFO - 2018-02-22 15:17:28 --> Controller Class Initialized
INFO - 2018-02-22 15:17:28 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-22 15:17:28 --> Model Class Initialized
INFO - 2018-02-22 15:17:28 --> Model Class Initialized
INFO - 2018-02-22 15:17:28 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-22 15:17:28 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-22 15:17:28 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-22 15:17:28 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-22 15:17:28 --> File loaded: /var/www/html/project/radio/application/views/subcategory/add_edit.php
INFO - 2018-02-22 15:17:28 --> Final output sent to browser
DEBUG - 2018-02-22 15:17:28 --> Total execution time: 0.0072
INFO - 2018-02-22 15:17:31 --> Config Class Initialized
INFO - 2018-02-22 15:17:31 --> Hooks Class Initialized
DEBUG - 2018-02-22 15:17:31 --> UTF-8 Support Enabled
INFO - 2018-02-22 15:17:31 --> Utf8 Class Initialized
INFO - 2018-02-22 15:17:31 --> URI Class Initialized
INFO - 2018-02-22 15:17:31 --> Router Class Initialized
INFO - 2018-02-22 15:17:31 --> Output Class Initialized
INFO - 2018-02-22 15:17:31 --> Security Class Initialized
DEBUG - 2018-02-22 15:17:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-22 15:17:31 --> Input Class Initialized
INFO - 2018-02-22 15:17:31 --> Language Class Initialized
INFO - 2018-02-22 15:17:31 --> Loader Class Initialized
INFO - 2018-02-22 15:17:31 --> Helper loaded: url_helper
INFO - 2018-02-22 15:17:31 --> Helper loaded: file_helper
INFO - 2018-02-22 15:17:31 --> Helper loaded: email_helper
INFO - 2018-02-22 15:17:31 --> Helper loaded: common_helper
INFO - 2018-02-22 15:17:31 --> Database Driver Class Initialized
DEBUG - 2018-02-22 15:17:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-22 15:17:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-22 15:17:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-22 15:17:31 --> Pagination Class Initialized
INFO - 2018-02-22 15:17:31 --> Helper loaded: form_helper
INFO - 2018-02-22 15:17:31 --> Form Validation Class Initialized
INFO - 2018-02-22 15:17:31 --> Model Class Initialized
INFO - 2018-02-22 15:17:31 --> Controller Class Initialized
INFO - 2018-02-22 15:17:31 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-22 15:17:31 --> Model Class Initialized
INFO - 2018-02-22 15:17:31 --> Model Class Initialized
INFO - 2018-02-22 15:17:31 --> Config Class Initialized
INFO - 2018-02-22 15:17:31 --> Hooks Class Initialized
DEBUG - 2018-02-22 15:17:31 --> UTF-8 Support Enabled
INFO - 2018-02-22 15:17:31 --> Utf8 Class Initialized
INFO - 2018-02-22 15:17:31 --> URI Class Initialized
INFO - 2018-02-22 15:17:31 --> Router Class Initialized
INFO - 2018-02-22 15:17:31 --> Output Class Initialized
INFO - 2018-02-22 15:17:31 --> Security Class Initialized
DEBUG - 2018-02-22 15:17:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-22 15:17:31 --> Input Class Initialized
INFO - 2018-02-22 15:17:31 --> Language Class Initialized
INFO - 2018-02-22 15:17:31 --> Loader Class Initialized
INFO - 2018-02-22 15:17:31 --> Helper loaded: url_helper
INFO - 2018-02-22 15:17:31 --> Helper loaded: file_helper
INFO - 2018-02-22 15:17:31 --> Helper loaded: email_helper
INFO - 2018-02-22 15:17:31 --> Helper loaded: common_helper
INFO - 2018-02-22 15:17:31 --> Database Driver Class Initialized
DEBUG - 2018-02-22 15:17:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-22 15:17:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-22 15:17:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-22 15:17:31 --> Pagination Class Initialized
INFO - 2018-02-22 15:17:31 --> Helper loaded: form_helper
INFO - 2018-02-22 15:17:31 --> Form Validation Class Initialized
INFO - 2018-02-22 15:17:31 --> Model Class Initialized
INFO - 2018-02-22 15:17:31 --> Controller Class Initialized
INFO - 2018-02-22 15:17:31 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-22 15:17:31 --> Model Class Initialized
INFO - 2018-02-22 15:17:31 --> Model Class Initialized
DEBUG - 2018-02-22 15:17:31 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-22 15:17:31 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-02-22 15:17:32 --> Config Class Initialized
INFO - 2018-02-22 15:17:32 --> Hooks Class Initialized
DEBUG - 2018-02-22 15:17:32 --> UTF-8 Support Enabled
INFO - 2018-02-22 15:17:32 --> Utf8 Class Initialized
INFO - 2018-02-22 15:17:32 --> URI Class Initialized
INFO - 2018-02-22 15:17:32 --> Router Class Initialized
INFO - 2018-02-22 15:17:32 --> Output Class Initialized
INFO - 2018-02-22 15:17:32 --> Security Class Initialized
DEBUG - 2018-02-22 15:17:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-22 15:17:32 --> Input Class Initialized
INFO - 2018-02-22 15:17:32 --> Language Class Initialized
INFO - 2018-02-22 15:17:32 --> Loader Class Initialized
INFO - 2018-02-22 15:17:32 --> Helper loaded: url_helper
INFO - 2018-02-22 15:17:32 --> Helper loaded: file_helper
INFO - 2018-02-22 15:17:32 --> Helper loaded: email_helper
INFO - 2018-02-22 15:17:32 --> Helper loaded: common_helper
INFO - 2018-02-22 15:17:32 --> Database Driver Class Initialized
DEBUG - 2018-02-22 15:17:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-22 15:17:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-22 15:17:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-22 15:17:32 --> Pagination Class Initialized
INFO - 2018-02-22 15:17:32 --> Helper loaded: form_helper
INFO - 2018-02-22 15:17:32 --> Form Validation Class Initialized
INFO - 2018-02-22 15:17:32 --> Model Class Initialized
INFO - 2018-02-22 15:17:32 --> Controller Class Initialized
INFO - 2018-02-22 15:17:32 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-22 15:17:32 --> Model Class Initialized
INFO - 2018-02-22 15:17:32 --> Model Class Initialized
INFO - 2018-02-22 15:17:32 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-22 15:17:32 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-22 15:17:32 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-22 15:17:32 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-22 15:17:32 --> File loaded: /var/www/html/project/radio/application/views/subcategory/index.php
INFO - 2018-02-22 15:17:32 --> Final output sent to browser
DEBUG - 2018-02-22 15:17:32 --> Total execution time: 0.0059
INFO - 2018-02-22 15:17:38 --> Config Class Initialized
INFO - 2018-02-22 15:17:38 --> Hooks Class Initialized
DEBUG - 2018-02-22 15:17:38 --> UTF-8 Support Enabled
INFO - 2018-02-22 15:17:38 --> Utf8 Class Initialized
INFO - 2018-02-22 15:17:38 --> URI Class Initialized
INFO - 2018-02-22 15:17:38 --> Router Class Initialized
INFO - 2018-02-22 15:17:38 --> Output Class Initialized
INFO - 2018-02-22 15:17:38 --> Security Class Initialized
DEBUG - 2018-02-22 15:17:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-22 15:17:38 --> Input Class Initialized
INFO - 2018-02-22 15:17:38 --> Language Class Initialized
INFO - 2018-02-22 15:17:38 --> Loader Class Initialized
INFO - 2018-02-22 15:17:38 --> Helper loaded: url_helper
INFO - 2018-02-22 15:17:38 --> Helper loaded: file_helper
INFO - 2018-02-22 15:17:38 --> Helper loaded: email_helper
INFO - 2018-02-22 15:17:38 --> Helper loaded: common_helper
INFO - 2018-02-22 15:17:38 --> Database Driver Class Initialized
DEBUG - 2018-02-22 15:17:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-22 15:17:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-22 15:17:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-22 15:17:38 --> Pagination Class Initialized
INFO - 2018-02-22 15:17:38 --> Helper loaded: form_helper
INFO - 2018-02-22 15:17:38 --> Form Validation Class Initialized
INFO - 2018-02-22 15:17:38 --> Model Class Initialized
INFO - 2018-02-22 15:17:38 --> Controller Class Initialized
DEBUG - 2018-02-22 15:17:38 --> Config file loaded: /var/www/html/project/radio/application/config/rest.php
INFO - 2018-02-22 15:17:38 --> Helper loaded: inflector_helper
INFO - 2018-02-22 15:17:38 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-22 15:17:38 --> Model Class Initialized
INFO - 2018-02-22 15:17:38 --> Model Class Initialized
INFO - 2018-02-22 15:17:38 --> Model Class Initialized
INFO - 2018-02-22 15:17:38 --> Model Class Initialized
INFO - 2018-02-22 15:17:38 --> Model Class Initialized
INFO - 2018-02-22 15:17:38 --> Model Class Initialized
INFO - 2018-02-22 15:17:38 --> Final output sent to browser
DEBUG - 2018-02-22 15:17:38 --> Total execution time: 0.0108
INFO - 2018-02-22 15:18:08 --> Config Class Initialized
INFO - 2018-02-22 15:18:08 --> Hooks Class Initialized
DEBUG - 2018-02-22 15:18:08 --> UTF-8 Support Enabled
INFO - 2018-02-22 15:18:08 --> Utf8 Class Initialized
INFO - 2018-02-22 15:18:08 --> URI Class Initialized
INFO - 2018-02-22 15:18:08 --> Router Class Initialized
INFO - 2018-02-22 15:18:08 --> Output Class Initialized
INFO - 2018-02-22 15:18:08 --> Security Class Initialized
DEBUG - 2018-02-22 15:18:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-22 15:18:08 --> Input Class Initialized
INFO - 2018-02-22 15:18:08 --> Language Class Initialized
INFO - 2018-02-22 15:18:08 --> Loader Class Initialized
INFO - 2018-02-22 15:18:08 --> Helper loaded: url_helper
INFO - 2018-02-22 15:18:08 --> Helper loaded: file_helper
INFO - 2018-02-22 15:18:08 --> Helper loaded: email_helper
INFO - 2018-02-22 15:18:08 --> Helper loaded: common_helper
INFO - 2018-02-22 15:18:08 --> Database Driver Class Initialized
DEBUG - 2018-02-22 15:18:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-22 15:18:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-22 15:18:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-22 15:18:08 --> Pagination Class Initialized
INFO - 2018-02-22 15:18:08 --> Helper loaded: form_helper
INFO - 2018-02-22 15:18:08 --> Form Validation Class Initialized
INFO - 2018-02-22 15:18:08 --> Model Class Initialized
INFO - 2018-02-22 15:18:08 --> Controller Class Initialized
DEBUG - 2018-02-22 15:18:08 --> Config file loaded: /var/www/html/project/radio/application/config/rest.php
INFO - 2018-02-22 15:18:08 --> Helper loaded: inflector_helper
INFO - 2018-02-22 15:18:08 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-22 15:18:08 --> Model Class Initialized
INFO - 2018-02-22 15:18:08 --> Model Class Initialized
INFO - 2018-02-22 15:18:08 --> Model Class Initialized
INFO - 2018-02-22 15:18:08 --> Model Class Initialized
INFO - 2018-02-22 15:18:08 --> Model Class Initialized
INFO - 2018-02-22 15:18:08 --> Model Class Initialized
INFO - 2018-02-22 15:18:08 --> Final output sent to browser
DEBUG - 2018-02-22 15:18:08 --> Total execution time: 0.0057
INFO - 2018-02-22 15:18:25 --> Config Class Initialized
INFO - 2018-02-22 15:18:25 --> Hooks Class Initialized
DEBUG - 2018-02-22 15:18:25 --> UTF-8 Support Enabled
INFO - 2018-02-22 15:18:25 --> Utf8 Class Initialized
INFO - 2018-02-22 15:18:25 --> URI Class Initialized
INFO - 2018-02-22 15:18:25 --> Router Class Initialized
INFO - 2018-02-22 15:18:25 --> Output Class Initialized
INFO - 2018-02-22 15:18:25 --> Security Class Initialized
DEBUG - 2018-02-22 15:18:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-22 15:18:25 --> Input Class Initialized
INFO - 2018-02-22 15:18:25 --> Language Class Initialized
INFO - 2018-02-22 15:18:25 --> Loader Class Initialized
INFO - 2018-02-22 15:18:25 --> Helper loaded: url_helper
INFO - 2018-02-22 15:18:25 --> Helper loaded: file_helper
INFO - 2018-02-22 15:18:25 --> Helper loaded: email_helper
INFO - 2018-02-22 15:18:25 --> Helper loaded: common_helper
INFO - 2018-02-22 15:18:25 --> Database Driver Class Initialized
DEBUG - 2018-02-22 15:18:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-22 15:18:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-22 15:18:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-22 15:18:25 --> Pagination Class Initialized
INFO - 2018-02-22 15:18:25 --> Helper loaded: form_helper
INFO - 2018-02-22 15:18:25 --> Form Validation Class Initialized
INFO - 2018-02-22 15:18:25 --> Model Class Initialized
INFO - 2018-02-22 15:18:25 --> Controller Class Initialized
INFO - 2018-02-22 15:18:25 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-22 15:18:25 --> Model Class Initialized
INFO - 2018-02-22 15:18:25 --> Model Class Initialized
INFO - 2018-02-22 15:18:25 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-22 15:18:25 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-22 15:18:25 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-22 15:18:25 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-22 15:18:25 --> File loaded: /var/www/html/project/radio/application/views/subcategory/add_edit.php
INFO - 2018-02-22 15:18:25 --> Final output sent to browser
DEBUG - 2018-02-22 15:18:25 --> Total execution time: 0.0084
INFO - 2018-02-22 15:18:28 --> Config Class Initialized
INFO - 2018-02-22 15:18:28 --> Hooks Class Initialized
DEBUG - 2018-02-22 15:18:28 --> UTF-8 Support Enabled
INFO - 2018-02-22 15:18:28 --> Utf8 Class Initialized
INFO - 2018-02-22 15:18:28 --> URI Class Initialized
INFO - 2018-02-22 15:18:28 --> Router Class Initialized
INFO - 2018-02-22 15:18:28 --> Output Class Initialized
INFO - 2018-02-22 15:18:28 --> Security Class Initialized
DEBUG - 2018-02-22 15:18:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-22 15:18:28 --> Input Class Initialized
INFO - 2018-02-22 15:18:28 --> Language Class Initialized
INFO - 2018-02-22 15:18:28 --> Loader Class Initialized
INFO - 2018-02-22 15:18:28 --> Helper loaded: url_helper
INFO - 2018-02-22 15:18:28 --> Helper loaded: file_helper
INFO - 2018-02-22 15:18:28 --> Helper loaded: email_helper
INFO - 2018-02-22 15:18:28 --> Helper loaded: common_helper
INFO - 2018-02-22 15:18:28 --> Database Driver Class Initialized
DEBUG - 2018-02-22 15:18:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-22 15:18:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-22 15:18:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-22 15:18:28 --> Pagination Class Initialized
INFO - 2018-02-22 15:18:28 --> Helper loaded: form_helper
INFO - 2018-02-22 15:18:28 --> Form Validation Class Initialized
INFO - 2018-02-22 15:18:28 --> Model Class Initialized
INFO - 2018-02-22 15:18:28 --> Controller Class Initialized
INFO - 2018-02-22 15:18:28 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-22 15:18:28 --> Model Class Initialized
INFO - 2018-02-22 15:18:28 --> Model Class Initialized
INFO - 2018-02-22 15:18:28 --> Config Class Initialized
INFO - 2018-02-22 15:18:28 --> Hooks Class Initialized
DEBUG - 2018-02-22 15:18:28 --> UTF-8 Support Enabled
INFO - 2018-02-22 15:18:28 --> Utf8 Class Initialized
INFO - 2018-02-22 15:18:28 --> URI Class Initialized
INFO - 2018-02-22 15:18:28 --> Router Class Initialized
INFO - 2018-02-22 15:18:28 --> Output Class Initialized
INFO - 2018-02-22 15:18:28 --> Security Class Initialized
DEBUG - 2018-02-22 15:18:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-22 15:18:28 --> Input Class Initialized
INFO - 2018-02-22 15:18:28 --> Language Class Initialized
INFO - 2018-02-22 15:18:28 --> Loader Class Initialized
INFO - 2018-02-22 15:18:28 --> Helper loaded: url_helper
INFO - 2018-02-22 15:18:28 --> Helper loaded: file_helper
INFO - 2018-02-22 15:18:28 --> Helper loaded: email_helper
INFO - 2018-02-22 15:18:28 --> Helper loaded: common_helper
INFO - 2018-02-22 15:18:28 --> Database Driver Class Initialized
DEBUG - 2018-02-22 15:18:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-22 15:18:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-22 15:18:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-22 15:18:28 --> Pagination Class Initialized
INFO - 2018-02-22 15:18:28 --> Helper loaded: form_helper
INFO - 2018-02-22 15:18:28 --> Form Validation Class Initialized
INFO - 2018-02-22 15:18:28 --> Model Class Initialized
INFO - 2018-02-22 15:18:28 --> Controller Class Initialized
INFO - 2018-02-22 15:18:28 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-22 15:18:28 --> Model Class Initialized
INFO - 2018-02-22 15:18:28 --> Model Class Initialized
DEBUG - 2018-02-22 15:18:28 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-22 15:18:28 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-02-22 15:18:28 --> Config Class Initialized
INFO - 2018-02-22 15:18:28 --> Hooks Class Initialized
DEBUG - 2018-02-22 15:18:28 --> UTF-8 Support Enabled
INFO - 2018-02-22 15:18:28 --> Utf8 Class Initialized
INFO - 2018-02-22 15:18:28 --> URI Class Initialized
INFO - 2018-02-22 15:18:28 --> Router Class Initialized
INFO - 2018-02-22 15:18:28 --> Output Class Initialized
INFO - 2018-02-22 15:18:28 --> Security Class Initialized
DEBUG - 2018-02-22 15:18:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-22 15:18:28 --> Input Class Initialized
INFO - 2018-02-22 15:18:28 --> Language Class Initialized
INFO - 2018-02-22 15:18:28 --> Loader Class Initialized
INFO - 2018-02-22 15:18:28 --> Helper loaded: url_helper
INFO - 2018-02-22 15:18:28 --> Helper loaded: file_helper
INFO - 2018-02-22 15:18:28 --> Helper loaded: email_helper
INFO - 2018-02-22 15:18:28 --> Helper loaded: common_helper
INFO - 2018-02-22 15:18:28 --> Database Driver Class Initialized
DEBUG - 2018-02-22 15:18:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-22 15:18:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-22 15:18:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-22 15:18:28 --> Pagination Class Initialized
INFO - 2018-02-22 15:18:28 --> Helper loaded: form_helper
INFO - 2018-02-22 15:18:28 --> Form Validation Class Initialized
INFO - 2018-02-22 15:18:28 --> Model Class Initialized
INFO - 2018-02-22 15:18:28 --> Controller Class Initialized
INFO - 2018-02-22 15:18:28 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-22 15:18:28 --> Model Class Initialized
INFO - 2018-02-22 15:18:28 --> Model Class Initialized
INFO - 2018-02-22 15:18:28 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-22 15:18:28 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-22 15:18:28 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-22 15:18:28 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-22 15:18:28 --> File loaded: /var/www/html/project/radio/application/views/subcategory/index.php
INFO - 2018-02-22 15:18:28 --> Final output sent to browser
DEBUG - 2018-02-22 15:18:28 --> Total execution time: 0.0075
INFO - 2018-02-22 15:20:57 --> Config Class Initialized
INFO - 2018-02-22 15:20:57 --> Hooks Class Initialized
DEBUG - 2018-02-22 15:20:57 --> UTF-8 Support Enabled
INFO - 2018-02-22 15:20:57 --> Utf8 Class Initialized
INFO - 2018-02-22 15:20:57 --> URI Class Initialized
INFO - 2018-02-22 15:20:57 --> Router Class Initialized
INFO - 2018-02-22 15:20:57 --> Output Class Initialized
INFO - 2018-02-22 15:20:57 --> Security Class Initialized
DEBUG - 2018-02-22 15:20:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-22 15:20:57 --> Input Class Initialized
INFO - 2018-02-22 15:20:57 --> Language Class Initialized
INFO - 2018-02-22 15:20:57 --> Loader Class Initialized
INFO - 2018-02-22 15:20:57 --> Helper loaded: url_helper
INFO - 2018-02-22 15:20:57 --> Helper loaded: file_helper
INFO - 2018-02-22 15:20:57 --> Helper loaded: email_helper
INFO - 2018-02-22 15:20:57 --> Helper loaded: common_helper
INFO - 2018-02-22 15:20:57 --> Database Driver Class Initialized
DEBUG - 2018-02-22 15:20:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-22 15:20:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-22 15:20:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-22 15:20:57 --> Pagination Class Initialized
INFO - 2018-02-22 15:20:57 --> Helper loaded: form_helper
INFO - 2018-02-22 15:20:57 --> Form Validation Class Initialized
INFO - 2018-02-22 15:20:57 --> Model Class Initialized
INFO - 2018-02-22 15:20:57 --> Controller Class Initialized
DEBUG - 2018-02-22 15:20:57 --> Config file loaded: /var/www/html/project/radio/application/config/rest.php
INFO - 2018-02-22 15:20:57 --> Helper loaded: inflector_helper
INFO - 2018-02-22 15:20:57 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-22 15:20:57 --> Model Class Initialized
INFO - 2018-02-22 15:20:57 --> Model Class Initialized
INFO - 2018-02-22 15:20:57 --> Model Class Initialized
INFO - 2018-02-22 15:20:57 --> Model Class Initialized
INFO - 2018-02-22 15:20:57 --> Model Class Initialized
INFO - 2018-02-22 15:20:57 --> Model Class Initialized
INFO - 2018-02-22 15:20:57 --> Final output sent to browser
DEBUG - 2018-02-22 15:20:57 --> Total execution time: 0.0110
INFO - 2018-02-22 15:28:48 --> Config Class Initialized
INFO - 2018-02-22 15:28:48 --> Hooks Class Initialized
DEBUG - 2018-02-22 15:28:48 --> UTF-8 Support Enabled
INFO - 2018-02-22 15:28:48 --> Utf8 Class Initialized
INFO - 2018-02-22 15:28:48 --> URI Class Initialized
INFO - 2018-02-22 15:28:48 --> Router Class Initialized
INFO - 2018-02-22 15:28:48 --> Output Class Initialized
INFO - 2018-02-22 15:28:48 --> Security Class Initialized
DEBUG - 2018-02-22 15:28:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-22 15:28:48 --> Input Class Initialized
INFO - 2018-02-22 15:28:48 --> Language Class Initialized
INFO - 2018-02-22 15:28:48 --> Loader Class Initialized
INFO - 2018-02-22 15:28:48 --> Helper loaded: url_helper
INFO - 2018-02-22 15:28:48 --> Helper loaded: file_helper
INFO - 2018-02-22 15:28:48 --> Helper loaded: email_helper
INFO - 2018-02-22 15:28:48 --> Helper loaded: common_helper
INFO - 2018-02-22 15:28:48 --> Database Driver Class Initialized
DEBUG - 2018-02-22 15:28:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-22 15:28:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-22 15:28:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-22 15:28:48 --> Pagination Class Initialized
INFO - 2018-02-22 15:28:48 --> Helper loaded: form_helper
INFO - 2018-02-22 15:28:48 --> Form Validation Class Initialized
INFO - 2018-02-22 15:28:48 --> Model Class Initialized
INFO - 2018-02-22 15:28:48 --> Controller Class Initialized
DEBUG - 2018-02-22 15:28:48 --> Config file loaded: /var/www/html/project/radio/application/config/rest.php
INFO - 2018-02-22 15:28:48 --> Helper loaded: inflector_helper
INFO - 2018-02-22 15:28:48 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-22 15:28:48 --> Model Class Initialized
INFO - 2018-02-22 15:28:48 --> Model Class Initialized
INFO - 2018-02-22 15:28:48 --> Model Class Initialized
INFO - 2018-02-22 15:28:48 --> Model Class Initialized
INFO - 2018-02-22 15:28:48 --> Model Class Initialized
INFO - 2018-02-22 15:28:48 --> Model Class Initialized
INFO - 2018-02-22 15:32:30 --> Config Class Initialized
INFO - 2018-02-22 15:32:30 --> Hooks Class Initialized
DEBUG - 2018-02-22 15:32:30 --> UTF-8 Support Enabled
INFO - 2018-02-22 15:32:30 --> Utf8 Class Initialized
INFO - 2018-02-22 15:32:30 --> URI Class Initialized
INFO - 2018-02-22 15:32:30 --> Router Class Initialized
INFO - 2018-02-22 15:32:30 --> Output Class Initialized
INFO - 2018-02-22 15:32:30 --> Security Class Initialized
DEBUG - 2018-02-22 15:32:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-22 15:32:30 --> Input Class Initialized
INFO - 2018-02-22 15:32:30 --> Language Class Initialized
INFO - 2018-02-22 15:32:30 --> Loader Class Initialized
INFO - 2018-02-22 15:32:30 --> Helper loaded: url_helper
INFO - 2018-02-22 15:32:30 --> Helper loaded: file_helper
INFO - 2018-02-22 15:32:30 --> Helper loaded: email_helper
INFO - 2018-02-22 15:32:30 --> Helper loaded: common_helper
INFO - 2018-02-22 15:32:30 --> Database Driver Class Initialized
DEBUG - 2018-02-22 15:32:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-22 15:32:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-22 15:32:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-22 15:32:30 --> Pagination Class Initialized
INFO - 2018-02-22 15:32:30 --> Helper loaded: form_helper
INFO - 2018-02-22 15:32:30 --> Form Validation Class Initialized
INFO - 2018-02-22 15:32:30 --> Model Class Initialized
INFO - 2018-02-22 15:32:30 --> Controller Class Initialized
DEBUG - 2018-02-22 15:32:30 --> Config file loaded: /var/www/html/project/radio/application/config/rest.php
INFO - 2018-02-22 15:32:30 --> Helper loaded: inflector_helper
INFO - 2018-02-22 15:32:30 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-22 15:32:30 --> Model Class Initialized
INFO - 2018-02-22 15:32:30 --> Model Class Initialized
INFO - 2018-02-22 15:32:30 --> Model Class Initialized
INFO - 2018-02-22 15:32:30 --> Model Class Initialized
INFO - 2018-02-22 15:32:30 --> Model Class Initialized
INFO - 2018-02-22 15:32:30 --> Model Class Initialized
INFO - 2018-02-22 15:34:36 --> Config Class Initialized
INFO - 2018-02-22 15:34:36 --> Hooks Class Initialized
DEBUG - 2018-02-22 15:34:36 --> UTF-8 Support Enabled
INFO - 2018-02-22 15:34:36 --> Utf8 Class Initialized
INFO - 2018-02-22 15:34:36 --> URI Class Initialized
INFO - 2018-02-22 15:34:36 --> Router Class Initialized
INFO - 2018-02-22 15:34:36 --> Output Class Initialized
INFO - 2018-02-22 15:34:36 --> Security Class Initialized
DEBUG - 2018-02-22 15:34:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-22 15:34:36 --> Input Class Initialized
INFO - 2018-02-22 15:34:36 --> Language Class Initialized
INFO - 2018-02-22 15:34:36 --> Loader Class Initialized
INFO - 2018-02-22 15:34:36 --> Helper loaded: url_helper
INFO - 2018-02-22 15:34:36 --> Helper loaded: file_helper
INFO - 2018-02-22 15:34:36 --> Helper loaded: email_helper
INFO - 2018-02-22 15:34:36 --> Helper loaded: common_helper
INFO - 2018-02-22 15:34:36 --> Database Driver Class Initialized
DEBUG - 2018-02-22 15:34:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-22 15:34:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-22 15:34:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-22 15:34:36 --> Pagination Class Initialized
INFO - 2018-02-22 15:34:36 --> Helper loaded: form_helper
INFO - 2018-02-22 15:34:36 --> Form Validation Class Initialized
INFO - 2018-02-22 15:34:36 --> Model Class Initialized
INFO - 2018-02-22 15:34:36 --> Controller Class Initialized
DEBUG - 2018-02-22 15:34:36 --> Config file loaded: /var/www/html/project/radio/application/config/rest.php
INFO - 2018-02-22 15:34:36 --> Helper loaded: inflector_helper
INFO - 2018-02-22 15:34:36 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-22 15:34:36 --> Model Class Initialized
INFO - 2018-02-22 15:34:36 --> Model Class Initialized
INFO - 2018-02-22 15:34:36 --> Model Class Initialized
INFO - 2018-02-22 15:34:36 --> Model Class Initialized
INFO - 2018-02-22 15:34:36 --> Model Class Initialized
INFO - 2018-02-22 15:34:36 --> Model Class Initialized
INFO - 2018-02-22 15:36:03 --> Config Class Initialized
INFO - 2018-02-22 15:36:03 --> Hooks Class Initialized
DEBUG - 2018-02-22 15:36:03 --> UTF-8 Support Enabled
INFO - 2018-02-22 15:36:03 --> Utf8 Class Initialized
INFO - 2018-02-22 15:36:03 --> URI Class Initialized
INFO - 2018-02-22 15:36:03 --> Router Class Initialized
INFO - 2018-02-22 15:36:03 --> Output Class Initialized
INFO - 2018-02-22 15:36:03 --> Security Class Initialized
DEBUG - 2018-02-22 15:36:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-22 15:36:03 --> Input Class Initialized
INFO - 2018-02-22 15:36:03 --> Language Class Initialized
INFO - 2018-02-22 15:36:03 --> Loader Class Initialized
INFO - 2018-02-22 15:36:03 --> Helper loaded: url_helper
INFO - 2018-02-22 15:36:03 --> Helper loaded: file_helper
INFO - 2018-02-22 15:36:03 --> Helper loaded: email_helper
INFO - 2018-02-22 15:36:03 --> Helper loaded: common_helper
INFO - 2018-02-22 15:36:03 --> Database Driver Class Initialized
DEBUG - 2018-02-22 15:36:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-22 15:36:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-22 15:36:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-22 15:36:03 --> Pagination Class Initialized
INFO - 2018-02-22 15:36:03 --> Helper loaded: form_helper
INFO - 2018-02-22 15:36:03 --> Form Validation Class Initialized
INFO - 2018-02-22 15:36:03 --> Model Class Initialized
INFO - 2018-02-22 15:36:03 --> Controller Class Initialized
DEBUG - 2018-02-22 15:36:03 --> Config file loaded: /var/www/html/project/radio/application/config/rest.php
INFO - 2018-02-22 15:36:03 --> Helper loaded: inflector_helper
INFO - 2018-02-22 15:36:03 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-22 15:36:03 --> Model Class Initialized
INFO - 2018-02-22 15:36:03 --> Model Class Initialized
INFO - 2018-02-22 15:36:03 --> Model Class Initialized
INFO - 2018-02-22 15:36:03 --> Model Class Initialized
INFO - 2018-02-22 15:36:03 --> Model Class Initialized
INFO - 2018-02-22 15:36:03 --> Model Class Initialized
ERROR - 2018-02-22 15:36:03 --> Severity: Notice --> Undefined offset: 1 /var/www/html/project/radio/application/controllers/api/Fetchappdata.php 252
ERROR - 2018-02-22 15:36:03 --> Severity: Notice --> Undefined offset: 2 /var/www/html/project/radio/application/controllers/api/Fetchappdata.php 252
ERROR - 2018-02-22 15:36:03 --> Severity: Notice --> Undefined offset: 3 /var/www/html/project/radio/application/controllers/api/Fetchappdata.php 252
INFO - 2018-02-22 15:36:39 --> Config Class Initialized
INFO - 2018-02-22 15:36:39 --> Hooks Class Initialized
DEBUG - 2018-02-22 15:36:39 --> UTF-8 Support Enabled
INFO - 2018-02-22 15:36:39 --> Utf8 Class Initialized
INFO - 2018-02-22 15:36:39 --> URI Class Initialized
INFO - 2018-02-22 15:36:39 --> Router Class Initialized
INFO - 2018-02-22 15:36:39 --> Output Class Initialized
INFO - 2018-02-22 15:36:39 --> Security Class Initialized
DEBUG - 2018-02-22 15:36:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-22 15:36:39 --> Input Class Initialized
INFO - 2018-02-22 15:36:39 --> Language Class Initialized
INFO - 2018-02-22 15:36:39 --> Loader Class Initialized
INFO - 2018-02-22 15:36:39 --> Helper loaded: url_helper
INFO - 2018-02-22 15:36:39 --> Helper loaded: file_helper
INFO - 2018-02-22 15:36:39 --> Helper loaded: email_helper
INFO - 2018-02-22 15:36:39 --> Helper loaded: common_helper
INFO - 2018-02-22 15:36:39 --> Database Driver Class Initialized
DEBUG - 2018-02-22 15:36:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-22 15:36:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-22 15:36:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-22 15:36:39 --> Pagination Class Initialized
INFO - 2018-02-22 15:36:39 --> Helper loaded: form_helper
INFO - 2018-02-22 15:36:39 --> Form Validation Class Initialized
INFO - 2018-02-22 15:36:39 --> Model Class Initialized
INFO - 2018-02-22 15:36:39 --> Controller Class Initialized
DEBUG - 2018-02-22 15:36:39 --> Config file loaded: /var/www/html/project/radio/application/config/rest.php
INFO - 2018-02-22 15:36:39 --> Helper loaded: inflector_helper
INFO - 2018-02-22 15:36:39 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-22 15:36:39 --> Model Class Initialized
INFO - 2018-02-22 15:36:39 --> Model Class Initialized
INFO - 2018-02-22 15:36:39 --> Model Class Initialized
INFO - 2018-02-22 15:36:39 --> Model Class Initialized
INFO - 2018-02-22 15:36:39 --> Model Class Initialized
INFO - 2018-02-22 15:36:39 --> Model Class Initialized
INFO - 2018-02-22 15:37:38 --> Config Class Initialized
INFO - 2018-02-22 15:37:38 --> Hooks Class Initialized
DEBUG - 2018-02-22 15:37:38 --> UTF-8 Support Enabled
INFO - 2018-02-22 15:37:38 --> Utf8 Class Initialized
INFO - 2018-02-22 15:37:38 --> URI Class Initialized
INFO - 2018-02-22 15:37:38 --> Router Class Initialized
INFO - 2018-02-22 15:37:38 --> Output Class Initialized
INFO - 2018-02-22 15:37:38 --> Security Class Initialized
DEBUG - 2018-02-22 15:37:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-22 15:37:38 --> Input Class Initialized
INFO - 2018-02-22 15:37:38 --> Language Class Initialized
INFO - 2018-02-22 15:37:38 --> Loader Class Initialized
INFO - 2018-02-22 15:37:38 --> Helper loaded: url_helper
INFO - 2018-02-22 15:37:38 --> Helper loaded: file_helper
INFO - 2018-02-22 15:37:38 --> Helper loaded: email_helper
INFO - 2018-02-22 15:37:38 --> Helper loaded: common_helper
INFO - 2018-02-22 15:37:38 --> Database Driver Class Initialized
DEBUG - 2018-02-22 15:37:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-22 15:37:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-22 15:37:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-22 15:37:38 --> Pagination Class Initialized
INFO - 2018-02-22 15:37:38 --> Helper loaded: form_helper
INFO - 2018-02-22 15:37:38 --> Form Validation Class Initialized
INFO - 2018-02-22 15:37:38 --> Model Class Initialized
INFO - 2018-02-22 15:37:38 --> Controller Class Initialized
DEBUG - 2018-02-22 15:37:38 --> Config file loaded: /var/www/html/project/radio/application/config/rest.php
INFO - 2018-02-22 15:37:38 --> Helper loaded: inflector_helper
INFO - 2018-02-22 15:37:38 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-22 15:37:38 --> Model Class Initialized
INFO - 2018-02-22 15:37:38 --> Model Class Initialized
INFO - 2018-02-22 15:37:38 --> Model Class Initialized
INFO - 2018-02-22 15:37:38 --> Model Class Initialized
INFO - 2018-02-22 15:37:38 --> Model Class Initialized
INFO - 2018-02-22 15:37:38 --> Model Class Initialized
INFO - 2018-02-22 15:38:07 --> Config Class Initialized
INFO - 2018-02-22 15:38:07 --> Hooks Class Initialized
DEBUG - 2018-02-22 15:38:07 --> UTF-8 Support Enabled
INFO - 2018-02-22 15:38:07 --> Utf8 Class Initialized
INFO - 2018-02-22 15:38:07 --> URI Class Initialized
INFO - 2018-02-22 15:38:07 --> Router Class Initialized
INFO - 2018-02-22 15:38:07 --> Output Class Initialized
INFO - 2018-02-22 15:38:07 --> Security Class Initialized
DEBUG - 2018-02-22 15:38:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-22 15:38:07 --> Input Class Initialized
INFO - 2018-02-22 15:38:07 --> Language Class Initialized
INFO - 2018-02-22 15:38:07 --> Loader Class Initialized
INFO - 2018-02-22 15:38:07 --> Helper loaded: url_helper
INFO - 2018-02-22 15:38:07 --> Helper loaded: file_helper
INFO - 2018-02-22 15:38:07 --> Helper loaded: email_helper
INFO - 2018-02-22 15:38:07 --> Helper loaded: common_helper
INFO - 2018-02-22 15:38:07 --> Database Driver Class Initialized
DEBUG - 2018-02-22 15:38:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-22 15:38:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-22 15:38:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-22 15:38:07 --> Pagination Class Initialized
INFO - 2018-02-22 15:38:07 --> Helper loaded: form_helper
INFO - 2018-02-22 15:38:07 --> Form Validation Class Initialized
INFO - 2018-02-22 15:38:07 --> Model Class Initialized
INFO - 2018-02-22 15:38:07 --> Controller Class Initialized
DEBUG - 2018-02-22 15:38:07 --> Config file loaded: /var/www/html/project/radio/application/config/rest.php
INFO - 2018-02-22 15:38:07 --> Helper loaded: inflector_helper
INFO - 2018-02-22 15:38:07 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-22 15:38:07 --> Model Class Initialized
INFO - 2018-02-22 15:38:07 --> Model Class Initialized
INFO - 2018-02-22 15:38:07 --> Model Class Initialized
INFO - 2018-02-22 15:38:07 --> Model Class Initialized
INFO - 2018-02-22 15:38:07 --> Model Class Initialized
INFO - 2018-02-22 15:38:07 --> Model Class Initialized
INFO - 2018-02-22 15:38:31 --> Config Class Initialized
INFO - 2018-02-22 15:38:31 --> Hooks Class Initialized
DEBUG - 2018-02-22 15:38:31 --> UTF-8 Support Enabled
INFO - 2018-02-22 15:38:31 --> Utf8 Class Initialized
INFO - 2018-02-22 15:38:31 --> URI Class Initialized
INFO - 2018-02-22 15:38:31 --> Router Class Initialized
INFO - 2018-02-22 15:38:31 --> Output Class Initialized
INFO - 2018-02-22 15:38:31 --> Security Class Initialized
DEBUG - 2018-02-22 15:38:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-22 15:38:31 --> Input Class Initialized
INFO - 2018-02-22 15:38:31 --> Language Class Initialized
INFO - 2018-02-22 15:38:31 --> Loader Class Initialized
INFO - 2018-02-22 15:38:31 --> Helper loaded: url_helper
INFO - 2018-02-22 15:38:31 --> Helper loaded: file_helper
INFO - 2018-02-22 15:38:31 --> Helper loaded: email_helper
INFO - 2018-02-22 15:38:31 --> Helper loaded: common_helper
INFO - 2018-02-22 15:38:31 --> Database Driver Class Initialized
DEBUG - 2018-02-22 15:38:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-22 15:38:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-22 15:38:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-22 15:38:31 --> Pagination Class Initialized
INFO - 2018-02-22 15:38:31 --> Helper loaded: form_helper
INFO - 2018-02-22 15:38:31 --> Form Validation Class Initialized
INFO - 2018-02-22 15:38:31 --> Model Class Initialized
INFO - 2018-02-22 15:38:31 --> Controller Class Initialized
DEBUG - 2018-02-22 15:38:31 --> Config file loaded: /var/www/html/project/radio/application/config/rest.php
INFO - 2018-02-22 15:38:31 --> Helper loaded: inflector_helper
INFO - 2018-02-22 15:38:31 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-22 15:38:31 --> Model Class Initialized
INFO - 2018-02-22 15:38:31 --> Model Class Initialized
INFO - 2018-02-22 15:38:31 --> Model Class Initialized
INFO - 2018-02-22 15:38:31 --> Model Class Initialized
INFO - 2018-02-22 15:38:31 --> Model Class Initialized
INFO - 2018-02-22 15:38:31 --> Model Class Initialized
INFO - 2018-02-22 15:39:31 --> Config Class Initialized
INFO - 2018-02-22 15:39:31 --> Hooks Class Initialized
DEBUG - 2018-02-22 15:39:31 --> UTF-8 Support Enabled
INFO - 2018-02-22 15:39:31 --> Utf8 Class Initialized
INFO - 2018-02-22 15:39:31 --> URI Class Initialized
INFO - 2018-02-22 15:39:31 --> Router Class Initialized
INFO - 2018-02-22 15:39:31 --> Output Class Initialized
INFO - 2018-02-22 15:39:31 --> Security Class Initialized
DEBUG - 2018-02-22 15:39:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-22 15:39:31 --> Input Class Initialized
INFO - 2018-02-22 15:39:31 --> Language Class Initialized
INFO - 2018-02-22 15:39:31 --> Loader Class Initialized
INFO - 2018-02-22 15:39:31 --> Helper loaded: url_helper
INFO - 2018-02-22 15:39:31 --> Helper loaded: file_helper
INFO - 2018-02-22 15:39:31 --> Helper loaded: email_helper
INFO - 2018-02-22 15:39:31 --> Helper loaded: common_helper
INFO - 2018-02-22 15:39:31 --> Database Driver Class Initialized
DEBUG - 2018-02-22 15:39:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-22 15:39:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-22 15:39:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-22 15:39:31 --> Pagination Class Initialized
INFO - 2018-02-22 15:39:31 --> Helper loaded: form_helper
INFO - 2018-02-22 15:39:31 --> Form Validation Class Initialized
INFO - 2018-02-22 15:39:31 --> Model Class Initialized
INFO - 2018-02-22 15:39:31 --> Controller Class Initialized
DEBUG - 2018-02-22 15:39:31 --> Config file loaded: /var/www/html/project/radio/application/config/rest.php
INFO - 2018-02-22 15:39:31 --> Helper loaded: inflector_helper
INFO - 2018-02-22 15:39:31 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-22 15:39:31 --> Model Class Initialized
INFO - 2018-02-22 15:39:31 --> Model Class Initialized
INFO - 2018-02-22 15:39:31 --> Model Class Initialized
INFO - 2018-02-22 15:39:31 --> Model Class Initialized
INFO - 2018-02-22 15:39:31 --> Model Class Initialized
INFO - 2018-02-22 15:39:31 --> Model Class Initialized
INFO - 2018-02-22 15:42:00 --> Config Class Initialized
INFO - 2018-02-22 15:42:00 --> Hooks Class Initialized
DEBUG - 2018-02-22 15:42:00 --> UTF-8 Support Enabled
INFO - 2018-02-22 15:42:00 --> Utf8 Class Initialized
INFO - 2018-02-22 15:42:00 --> URI Class Initialized
INFO - 2018-02-22 15:42:00 --> Router Class Initialized
INFO - 2018-02-22 15:42:00 --> Output Class Initialized
INFO - 2018-02-22 15:42:00 --> Security Class Initialized
DEBUG - 2018-02-22 15:42:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-22 15:42:00 --> Input Class Initialized
INFO - 2018-02-22 15:42:00 --> Language Class Initialized
INFO - 2018-02-22 15:42:00 --> Loader Class Initialized
INFO - 2018-02-22 15:42:00 --> Helper loaded: url_helper
INFO - 2018-02-22 15:42:00 --> Helper loaded: file_helper
INFO - 2018-02-22 15:42:00 --> Helper loaded: email_helper
INFO - 2018-02-22 15:42:00 --> Helper loaded: common_helper
INFO - 2018-02-22 15:42:00 --> Database Driver Class Initialized
DEBUG - 2018-02-22 15:42:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-22 15:42:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-22 15:42:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-22 15:42:00 --> Pagination Class Initialized
INFO - 2018-02-22 15:42:00 --> Helper loaded: form_helper
INFO - 2018-02-22 15:42:00 --> Form Validation Class Initialized
INFO - 2018-02-22 15:42:00 --> Model Class Initialized
INFO - 2018-02-22 15:42:00 --> Controller Class Initialized
DEBUG - 2018-02-22 15:42:00 --> Config file loaded: /var/www/html/project/radio/application/config/rest.php
INFO - 2018-02-22 15:42:00 --> Helper loaded: inflector_helper
INFO - 2018-02-22 15:42:00 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-22 15:42:00 --> Model Class Initialized
INFO - 2018-02-22 15:42:00 --> Model Class Initialized
INFO - 2018-02-22 15:42:00 --> Model Class Initialized
INFO - 2018-02-22 15:42:00 --> Model Class Initialized
INFO - 2018-02-22 15:42:00 --> Model Class Initialized
INFO - 2018-02-22 15:42:00 --> Model Class Initialized
INFO - 2018-02-22 15:43:56 --> Config Class Initialized
INFO - 2018-02-22 15:43:56 --> Hooks Class Initialized
DEBUG - 2018-02-22 15:43:56 --> UTF-8 Support Enabled
INFO - 2018-02-22 15:43:56 --> Utf8 Class Initialized
INFO - 2018-02-22 15:43:56 --> URI Class Initialized
INFO - 2018-02-22 15:43:56 --> Router Class Initialized
INFO - 2018-02-22 15:43:56 --> Output Class Initialized
INFO - 2018-02-22 15:43:56 --> Security Class Initialized
DEBUG - 2018-02-22 15:43:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-22 15:43:56 --> Input Class Initialized
INFO - 2018-02-22 15:43:56 --> Language Class Initialized
INFO - 2018-02-22 15:43:56 --> Loader Class Initialized
INFO - 2018-02-22 15:43:56 --> Helper loaded: url_helper
INFO - 2018-02-22 15:43:56 --> Helper loaded: file_helper
INFO - 2018-02-22 15:43:56 --> Helper loaded: email_helper
INFO - 2018-02-22 15:43:56 --> Helper loaded: common_helper
INFO - 2018-02-22 15:43:56 --> Database Driver Class Initialized
DEBUG - 2018-02-22 15:43:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-22 15:43:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-22 15:43:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-22 15:43:56 --> Pagination Class Initialized
INFO - 2018-02-22 15:43:56 --> Helper loaded: form_helper
INFO - 2018-02-22 15:43:56 --> Form Validation Class Initialized
INFO - 2018-02-22 15:43:56 --> Model Class Initialized
INFO - 2018-02-22 15:43:56 --> Controller Class Initialized
DEBUG - 2018-02-22 15:43:56 --> Config file loaded: /var/www/html/project/radio/application/config/rest.php
INFO - 2018-02-22 15:43:56 --> Helper loaded: inflector_helper
INFO - 2018-02-22 15:43:56 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-22 15:43:56 --> Model Class Initialized
INFO - 2018-02-22 15:43:56 --> Model Class Initialized
INFO - 2018-02-22 15:43:56 --> Model Class Initialized
INFO - 2018-02-22 15:43:56 --> Model Class Initialized
INFO - 2018-02-22 15:43:56 --> Model Class Initialized
INFO - 2018-02-22 15:43:56 --> Model Class Initialized
INFO - 2018-02-22 15:44:26 --> Config Class Initialized
INFO - 2018-02-22 15:44:26 --> Hooks Class Initialized
DEBUG - 2018-02-22 15:44:26 --> UTF-8 Support Enabled
INFO - 2018-02-22 15:44:26 --> Utf8 Class Initialized
INFO - 2018-02-22 15:44:26 --> URI Class Initialized
INFO - 2018-02-22 15:44:26 --> Router Class Initialized
INFO - 2018-02-22 15:44:26 --> Output Class Initialized
INFO - 2018-02-22 15:44:26 --> Security Class Initialized
DEBUG - 2018-02-22 15:44:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-22 15:44:26 --> Input Class Initialized
INFO - 2018-02-22 15:44:26 --> Language Class Initialized
INFO - 2018-02-22 15:44:26 --> Loader Class Initialized
INFO - 2018-02-22 15:44:26 --> Helper loaded: url_helper
INFO - 2018-02-22 15:44:26 --> Helper loaded: file_helper
INFO - 2018-02-22 15:44:26 --> Helper loaded: email_helper
INFO - 2018-02-22 15:44:26 --> Helper loaded: common_helper
INFO - 2018-02-22 15:44:26 --> Database Driver Class Initialized
DEBUG - 2018-02-22 15:44:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-22 15:44:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-22 15:44:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-22 15:44:26 --> Pagination Class Initialized
INFO - 2018-02-22 15:44:26 --> Helper loaded: form_helper
INFO - 2018-02-22 15:44:26 --> Form Validation Class Initialized
INFO - 2018-02-22 15:44:26 --> Model Class Initialized
INFO - 2018-02-22 15:44:26 --> Controller Class Initialized
DEBUG - 2018-02-22 15:44:26 --> Config file loaded: /var/www/html/project/radio/application/config/rest.php
INFO - 2018-02-22 15:44:26 --> Helper loaded: inflector_helper
INFO - 2018-02-22 15:44:26 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-22 15:44:26 --> Model Class Initialized
INFO - 2018-02-22 15:44:26 --> Model Class Initialized
INFO - 2018-02-22 15:44:26 --> Model Class Initialized
INFO - 2018-02-22 15:44:26 --> Model Class Initialized
INFO - 2018-02-22 15:44:26 --> Model Class Initialized
INFO - 2018-02-22 15:44:26 --> Model Class Initialized
INFO - 2018-02-22 15:46:09 --> Config Class Initialized
INFO - 2018-02-22 15:46:09 --> Hooks Class Initialized
DEBUG - 2018-02-22 15:46:09 --> UTF-8 Support Enabled
INFO - 2018-02-22 15:46:09 --> Utf8 Class Initialized
INFO - 2018-02-22 15:46:09 --> URI Class Initialized
INFO - 2018-02-22 15:46:09 --> Router Class Initialized
INFO - 2018-02-22 15:46:09 --> Output Class Initialized
INFO - 2018-02-22 15:46:09 --> Security Class Initialized
DEBUG - 2018-02-22 15:46:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-22 15:46:09 --> Input Class Initialized
INFO - 2018-02-22 15:46:09 --> Language Class Initialized
INFO - 2018-02-22 15:46:09 --> Loader Class Initialized
INFO - 2018-02-22 15:46:09 --> Helper loaded: url_helper
INFO - 2018-02-22 15:46:09 --> Helper loaded: file_helper
INFO - 2018-02-22 15:46:09 --> Helper loaded: email_helper
INFO - 2018-02-22 15:46:09 --> Helper loaded: common_helper
INFO - 2018-02-22 15:46:09 --> Database Driver Class Initialized
DEBUG - 2018-02-22 15:46:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-22 15:46:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-22 15:46:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-22 15:46:09 --> Pagination Class Initialized
INFO - 2018-02-22 15:46:09 --> Helper loaded: form_helper
INFO - 2018-02-22 15:46:09 --> Form Validation Class Initialized
INFO - 2018-02-22 15:46:09 --> Model Class Initialized
INFO - 2018-02-22 15:46:09 --> Controller Class Initialized
DEBUG - 2018-02-22 15:46:09 --> Config file loaded: /var/www/html/project/radio/application/config/rest.php
INFO - 2018-02-22 15:46:09 --> Helper loaded: inflector_helper
INFO - 2018-02-22 15:46:09 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-22 15:46:09 --> Model Class Initialized
INFO - 2018-02-22 15:46:09 --> Model Class Initialized
INFO - 2018-02-22 15:46:09 --> Model Class Initialized
INFO - 2018-02-22 15:46:09 --> Model Class Initialized
INFO - 2018-02-22 15:46:09 --> Model Class Initialized
INFO - 2018-02-22 15:46:09 --> Model Class Initialized
INFO - 2018-02-22 15:46:09 --> Final output sent to browser
DEBUG - 2018-02-22 15:46:09 --> Total execution time: 0.0115
INFO - 2018-02-22 15:49:57 --> Config Class Initialized
INFO - 2018-02-22 15:49:57 --> Hooks Class Initialized
DEBUG - 2018-02-22 15:49:57 --> UTF-8 Support Enabled
INFO - 2018-02-22 15:49:57 --> Utf8 Class Initialized
INFO - 2018-02-22 15:49:57 --> URI Class Initialized
INFO - 2018-02-22 15:49:57 --> Router Class Initialized
INFO - 2018-02-22 15:49:57 --> Output Class Initialized
INFO - 2018-02-22 15:49:57 --> Security Class Initialized
DEBUG - 2018-02-22 15:49:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-22 15:49:57 --> Input Class Initialized
INFO - 2018-02-22 15:49:57 --> Language Class Initialized
INFO - 2018-02-22 15:49:57 --> Loader Class Initialized
INFO - 2018-02-22 15:49:57 --> Helper loaded: url_helper
INFO - 2018-02-22 15:49:57 --> Helper loaded: file_helper
INFO - 2018-02-22 15:49:57 --> Helper loaded: email_helper
INFO - 2018-02-22 15:49:57 --> Helper loaded: common_helper
INFO - 2018-02-22 15:49:57 --> Database Driver Class Initialized
DEBUG - 2018-02-22 15:49:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-22 15:49:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-22 15:49:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-22 15:49:57 --> Pagination Class Initialized
INFO - 2018-02-22 15:49:57 --> Helper loaded: form_helper
INFO - 2018-02-22 15:49:57 --> Form Validation Class Initialized
INFO - 2018-02-22 15:49:57 --> Model Class Initialized
INFO - 2018-02-22 15:49:57 --> Controller Class Initialized
DEBUG - 2018-02-22 15:49:57 --> Config file loaded: /var/www/html/project/radio/application/config/rest.php
INFO - 2018-02-22 15:49:57 --> Helper loaded: inflector_helper
INFO - 2018-02-22 15:49:57 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-22 15:49:57 --> Model Class Initialized
INFO - 2018-02-22 15:49:57 --> Model Class Initialized
INFO - 2018-02-22 15:49:57 --> Model Class Initialized
INFO - 2018-02-22 15:49:57 --> Model Class Initialized
INFO - 2018-02-22 15:49:57 --> Model Class Initialized
INFO - 2018-02-22 15:49:57 --> Model Class Initialized
INFO - 2018-02-22 15:49:57 --> Final output sent to browser
DEBUG - 2018-02-22 15:49:57 --> Total execution time: 0.0055
INFO - 2018-02-22 15:50:06 --> Config Class Initialized
INFO - 2018-02-22 15:50:06 --> Hooks Class Initialized
DEBUG - 2018-02-22 15:50:06 --> UTF-8 Support Enabled
INFO - 2018-02-22 15:50:06 --> Utf8 Class Initialized
INFO - 2018-02-22 15:50:06 --> URI Class Initialized
INFO - 2018-02-22 15:50:06 --> Router Class Initialized
INFO - 2018-02-22 15:50:06 --> Output Class Initialized
INFO - 2018-02-22 15:50:06 --> Security Class Initialized
DEBUG - 2018-02-22 15:50:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-22 15:50:06 --> Input Class Initialized
INFO - 2018-02-22 15:50:06 --> Language Class Initialized
INFO - 2018-02-22 15:50:06 --> Loader Class Initialized
INFO - 2018-02-22 15:50:06 --> Helper loaded: url_helper
INFO - 2018-02-22 15:50:06 --> Helper loaded: file_helper
INFO - 2018-02-22 15:50:06 --> Helper loaded: email_helper
INFO - 2018-02-22 15:50:06 --> Helper loaded: common_helper
INFO - 2018-02-22 15:50:06 --> Database Driver Class Initialized
DEBUG - 2018-02-22 15:50:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-22 15:50:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-22 15:50:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-22 15:50:06 --> Pagination Class Initialized
INFO - 2018-02-22 15:50:06 --> Helper loaded: form_helper
INFO - 2018-02-22 15:50:06 --> Form Validation Class Initialized
INFO - 2018-02-22 15:50:06 --> Model Class Initialized
INFO - 2018-02-22 15:50:06 --> Controller Class Initialized
DEBUG - 2018-02-22 15:50:06 --> Config file loaded: /var/www/html/project/radio/application/config/rest.php
INFO - 2018-02-22 15:50:06 --> Helper loaded: inflector_helper
INFO - 2018-02-22 15:50:06 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-22 15:50:06 --> Model Class Initialized
INFO - 2018-02-22 15:50:06 --> Model Class Initialized
INFO - 2018-02-22 15:50:06 --> Model Class Initialized
INFO - 2018-02-22 15:50:06 --> Model Class Initialized
INFO - 2018-02-22 15:50:06 --> Model Class Initialized
INFO - 2018-02-22 15:50:06 --> Model Class Initialized
INFO - 2018-02-22 15:50:06 --> Final output sent to browser
DEBUG - 2018-02-22 15:50:06 --> Total execution time: 0.0078
INFO - 2018-02-22 15:56:31 --> Config Class Initialized
INFO - 2018-02-22 15:56:31 --> Hooks Class Initialized
DEBUG - 2018-02-22 15:56:31 --> UTF-8 Support Enabled
INFO - 2018-02-22 15:56:31 --> Utf8 Class Initialized
INFO - 2018-02-22 15:56:31 --> URI Class Initialized
INFO - 2018-02-22 15:56:31 --> Router Class Initialized
INFO - 2018-02-22 15:56:31 --> Output Class Initialized
INFO - 2018-02-22 15:56:31 --> Security Class Initialized
DEBUG - 2018-02-22 15:56:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-22 15:56:31 --> Input Class Initialized
INFO - 2018-02-22 15:56:31 --> Language Class Initialized
INFO - 2018-02-22 15:56:31 --> Loader Class Initialized
INFO - 2018-02-22 15:56:31 --> Helper loaded: url_helper
INFO - 2018-02-22 15:56:31 --> Helper loaded: file_helper
INFO - 2018-02-22 15:56:31 --> Helper loaded: email_helper
INFO - 2018-02-22 15:56:31 --> Helper loaded: common_helper
INFO - 2018-02-22 15:56:31 --> Database Driver Class Initialized
DEBUG - 2018-02-22 15:56:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-22 15:56:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-22 15:56:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-22 15:56:31 --> Pagination Class Initialized
INFO - 2018-02-22 15:56:31 --> Helper loaded: form_helper
INFO - 2018-02-22 15:56:31 --> Form Validation Class Initialized
INFO - 2018-02-22 15:56:31 --> Model Class Initialized
INFO - 2018-02-22 15:56:31 --> Controller Class Initialized
DEBUG - 2018-02-22 15:56:31 --> Config file loaded: /var/www/html/project/radio/application/config/rest.php
INFO - 2018-02-22 15:56:31 --> Helper loaded: inflector_helper
INFO - 2018-02-22 15:56:31 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-22 15:56:31 --> Model Class Initialized
INFO - 2018-02-22 15:56:31 --> Model Class Initialized
INFO - 2018-02-22 15:56:31 --> Model Class Initialized
INFO - 2018-02-22 15:56:31 --> Model Class Initialized
INFO - 2018-02-22 15:56:31 --> Model Class Initialized
INFO - 2018-02-22 15:56:31 --> Model Class Initialized
INFO - 2018-02-22 15:56:31 --> Final output sent to browser
DEBUG - 2018-02-22 15:56:31 --> Total execution time: 0.0064
INFO - 2018-02-22 15:57:32 --> Config Class Initialized
INFO - 2018-02-22 15:57:32 --> Hooks Class Initialized
DEBUG - 2018-02-22 15:57:32 --> UTF-8 Support Enabled
INFO - 2018-02-22 15:57:32 --> Utf8 Class Initialized
INFO - 2018-02-22 15:57:32 --> URI Class Initialized
INFO - 2018-02-22 15:57:32 --> Router Class Initialized
INFO - 2018-02-22 15:57:32 --> Output Class Initialized
INFO - 2018-02-22 15:57:32 --> Security Class Initialized
DEBUG - 2018-02-22 15:57:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-22 15:57:32 --> Input Class Initialized
INFO - 2018-02-22 15:57:32 --> Language Class Initialized
INFO - 2018-02-22 15:57:32 --> Loader Class Initialized
INFO - 2018-02-22 15:57:32 --> Helper loaded: url_helper
INFO - 2018-02-22 15:57:32 --> Helper loaded: file_helper
INFO - 2018-02-22 15:57:32 --> Helper loaded: email_helper
INFO - 2018-02-22 15:57:32 --> Helper loaded: common_helper
INFO - 2018-02-22 15:57:32 --> Database Driver Class Initialized
DEBUG - 2018-02-22 15:57:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-22 15:57:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-22 15:57:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-22 15:57:32 --> Pagination Class Initialized
INFO - 2018-02-22 15:57:32 --> Helper loaded: form_helper
INFO - 2018-02-22 15:57:32 --> Form Validation Class Initialized
INFO - 2018-02-22 15:57:32 --> Model Class Initialized
INFO - 2018-02-22 15:57:32 --> Controller Class Initialized
DEBUG - 2018-02-22 15:57:32 --> Config file loaded: /var/www/html/project/radio/application/config/rest.php
INFO - 2018-02-22 15:57:32 --> Helper loaded: inflector_helper
INFO - 2018-02-22 15:57:32 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-22 15:57:32 --> Model Class Initialized
INFO - 2018-02-22 15:57:32 --> Model Class Initialized
INFO - 2018-02-22 15:57:32 --> Model Class Initialized
INFO - 2018-02-22 15:57:32 --> Model Class Initialized
INFO - 2018-02-22 15:57:32 --> Model Class Initialized
INFO - 2018-02-22 15:57:32 --> Model Class Initialized
INFO - 2018-02-22 15:57:32 --> Final output sent to browser
DEBUG - 2018-02-22 15:57:32 --> Total execution time: 0.0059
INFO - 2018-02-22 15:57:38 --> Config Class Initialized
INFO - 2018-02-22 15:57:38 --> Hooks Class Initialized
DEBUG - 2018-02-22 15:57:38 --> UTF-8 Support Enabled
INFO - 2018-02-22 15:57:38 --> Utf8 Class Initialized
INFO - 2018-02-22 15:57:38 --> URI Class Initialized
INFO - 2018-02-22 15:57:38 --> Router Class Initialized
INFO - 2018-02-22 15:57:38 --> Output Class Initialized
INFO - 2018-02-22 15:57:38 --> Security Class Initialized
DEBUG - 2018-02-22 15:57:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-22 15:57:38 --> Input Class Initialized
INFO - 2018-02-22 15:57:38 --> Language Class Initialized
INFO - 2018-02-22 15:57:38 --> Loader Class Initialized
INFO - 2018-02-22 15:57:38 --> Helper loaded: url_helper
INFO - 2018-02-22 15:57:38 --> Helper loaded: file_helper
INFO - 2018-02-22 15:57:38 --> Helper loaded: email_helper
INFO - 2018-02-22 15:57:38 --> Helper loaded: common_helper
INFO - 2018-02-22 15:57:38 --> Database Driver Class Initialized
DEBUG - 2018-02-22 15:57:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-22 15:57:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-22 15:57:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-22 15:57:38 --> Pagination Class Initialized
INFO - 2018-02-22 15:57:38 --> Helper loaded: form_helper
INFO - 2018-02-22 15:57:38 --> Form Validation Class Initialized
INFO - 2018-02-22 15:57:38 --> Model Class Initialized
INFO - 2018-02-22 15:57:38 --> Controller Class Initialized
DEBUG - 2018-02-22 15:57:38 --> Config file loaded: /var/www/html/project/radio/application/config/rest.php
INFO - 2018-02-22 15:57:38 --> Helper loaded: inflector_helper
INFO - 2018-02-22 15:57:38 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-22 15:57:38 --> Model Class Initialized
INFO - 2018-02-22 15:57:38 --> Model Class Initialized
INFO - 2018-02-22 15:57:38 --> Model Class Initialized
INFO - 2018-02-22 15:57:38 --> Model Class Initialized
INFO - 2018-02-22 15:57:38 --> Model Class Initialized
INFO - 2018-02-22 15:57:38 --> Model Class Initialized
INFO - 2018-02-22 15:57:38 --> Final output sent to browser
DEBUG - 2018-02-22 15:57:38 --> Total execution time: 0.0081
INFO - 2018-02-22 15:57:43 --> Config Class Initialized
INFO - 2018-02-22 15:57:43 --> Hooks Class Initialized
DEBUG - 2018-02-22 15:57:43 --> UTF-8 Support Enabled
INFO - 2018-02-22 15:57:43 --> Utf8 Class Initialized
INFO - 2018-02-22 15:57:43 --> URI Class Initialized
INFO - 2018-02-22 15:57:43 --> Router Class Initialized
INFO - 2018-02-22 15:57:43 --> Output Class Initialized
INFO - 2018-02-22 15:57:43 --> Security Class Initialized
DEBUG - 2018-02-22 15:57:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-22 15:57:43 --> Input Class Initialized
INFO - 2018-02-22 15:57:43 --> Language Class Initialized
INFO - 2018-02-22 15:57:43 --> Loader Class Initialized
INFO - 2018-02-22 15:57:43 --> Helper loaded: url_helper
INFO - 2018-02-22 15:57:43 --> Helper loaded: file_helper
INFO - 2018-02-22 15:57:43 --> Helper loaded: email_helper
INFO - 2018-02-22 15:57:43 --> Helper loaded: common_helper
INFO - 2018-02-22 15:57:43 --> Database Driver Class Initialized
DEBUG - 2018-02-22 15:57:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-22 15:57:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-22 15:57:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-22 15:57:43 --> Pagination Class Initialized
INFO - 2018-02-22 15:57:43 --> Helper loaded: form_helper
INFO - 2018-02-22 15:57:43 --> Form Validation Class Initialized
INFO - 2018-02-22 15:57:43 --> Model Class Initialized
INFO - 2018-02-22 15:57:43 --> Controller Class Initialized
DEBUG - 2018-02-22 15:57:43 --> Config file loaded: /var/www/html/project/radio/application/config/rest.php
INFO - 2018-02-22 15:57:43 --> Helper loaded: inflector_helper
INFO - 2018-02-22 15:57:43 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-22 15:57:43 --> Model Class Initialized
INFO - 2018-02-22 15:57:43 --> Model Class Initialized
INFO - 2018-02-22 15:57:43 --> Model Class Initialized
INFO - 2018-02-22 15:57:43 --> Model Class Initialized
INFO - 2018-02-22 15:57:43 --> Model Class Initialized
INFO - 2018-02-22 15:57:43 --> Model Class Initialized
INFO - 2018-02-22 15:57:43 --> Final output sent to browser
DEBUG - 2018-02-22 15:57:43 --> Total execution time: 0.0060
INFO - 2018-02-22 15:58:16 --> Config Class Initialized
INFO - 2018-02-22 15:58:16 --> Hooks Class Initialized
DEBUG - 2018-02-22 15:58:16 --> UTF-8 Support Enabled
INFO - 2018-02-22 15:58:16 --> Utf8 Class Initialized
INFO - 2018-02-22 15:58:16 --> URI Class Initialized
INFO - 2018-02-22 15:58:16 --> Router Class Initialized
INFO - 2018-02-22 15:58:16 --> Output Class Initialized
INFO - 2018-02-22 15:58:16 --> Security Class Initialized
DEBUG - 2018-02-22 15:58:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-22 15:58:16 --> Input Class Initialized
INFO - 2018-02-22 15:58:16 --> Language Class Initialized
INFO - 2018-02-22 15:58:16 --> Loader Class Initialized
INFO - 2018-02-22 15:58:16 --> Helper loaded: url_helper
INFO - 2018-02-22 15:58:16 --> Helper loaded: file_helper
INFO - 2018-02-22 15:58:16 --> Helper loaded: email_helper
INFO - 2018-02-22 15:58:16 --> Helper loaded: common_helper
INFO - 2018-02-22 15:58:16 --> Database Driver Class Initialized
DEBUG - 2018-02-22 15:58:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-22 15:58:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-22 15:58:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-22 15:58:16 --> Pagination Class Initialized
INFO - 2018-02-22 15:58:16 --> Helper loaded: form_helper
INFO - 2018-02-22 15:58:16 --> Form Validation Class Initialized
INFO - 2018-02-22 15:58:16 --> Model Class Initialized
INFO - 2018-02-22 15:58:16 --> Controller Class Initialized
DEBUG - 2018-02-22 15:58:16 --> Config file loaded: /var/www/html/project/radio/application/config/rest.php
INFO - 2018-02-22 15:58:16 --> Helper loaded: inflector_helper
INFO - 2018-02-22 15:58:16 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-22 15:58:16 --> Model Class Initialized
INFO - 2018-02-22 15:58:16 --> Model Class Initialized
INFO - 2018-02-22 15:58:16 --> Model Class Initialized
INFO - 2018-02-22 15:58:16 --> Model Class Initialized
INFO - 2018-02-22 15:58:16 --> Model Class Initialized
INFO - 2018-02-22 15:58:16 --> Model Class Initialized
INFO - 2018-02-22 15:58:16 --> Final output sent to browser
DEBUG - 2018-02-22 15:58:16 --> Total execution time: 0.0060
INFO - 2018-02-22 15:58:20 --> Config Class Initialized
INFO - 2018-02-22 15:58:20 --> Hooks Class Initialized
DEBUG - 2018-02-22 15:58:20 --> UTF-8 Support Enabled
INFO - 2018-02-22 15:58:20 --> Utf8 Class Initialized
INFO - 2018-02-22 15:58:20 --> URI Class Initialized
INFO - 2018-02-22 15:58:20 --> Router Class Initialized
INFO - 2018-02-22 15:58:20 --> Output Class Initialized
INFO - 2018-02-22 15:58:20 --> Security Class Initialized
DEBUG - 2018-02-22 15:58:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-22 15:58:20 --> Input Class Initialized
INFO - 2018-02-22 15:58:20 --> Language Class Initialized
INFO - 2018-02-22 15:58:20 --> Loader Class Initialized
INFO - 2018-02-22 15:58:20 --> Helper loaded: url_helper
INFO - 2018-02-22 15:58:20 --> Helper loaded: file_helper
INFO - 2018-02-22 15:58:20 --> Helper loaded: email_helper
INFO - 2018-02-22 15:58:20 --> Helper loaded: common_helper
INFO - 2018-02-22 15:58:20 --> Database Driver Class Initialized
DEBUG - 2018-02-22 15:58:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-22 15:58:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-22 15:58:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-22 15:58:20 --> Pagination Class Initialized
INFO - 2018-02-22 15:58:20 --> Helper loaded: form_helper
INFO - 2018-02-22 15:58:20 --> Form Validation Class Initialized
INFO - 2018-02-22 15:58:20 --> Model Class Initialized
INFO - 2018-02-22 15:58:20 --> Controller Class Initialized
DEBUG - 2018-02-22 15:58:20 --> Config file loaded: /var/www/html/project/radio/application/config/rest.php
INFO - 2018-02-22 15:58:20 --> Helper loaded: inflector_helper
INFO - 2018-02-22 15:58:20 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-22 15:58:20 --> Model Class Initialized
INFO - 2018-02-22 15:58:20 --> Model Class Initialized
INFO - 2018-02-22 15:58:20 --> Model Class Initialized
INFO - 2018-02-22 15:58:20 --> Model Class Initialized
INFO - 2018-02-22 15:58:20 --> Model Class Initialized
INFO - 2018-02-22 15:58:20 --> Model Class Initialized
INFO - 2018-02-22 15:58:20 --> Final output sent to browser
DEBUG - 2018-02-22 15:58:20 --> Total execution time: 0.0068
INFO - 2018-02-22 15:59:35 --> Config Class Initialized
INFO - 2018-02-22 15:59:35 --> Hooks Class Initialized
DEBUG - 2018-02-22 15:59:35 --> UTF-8 Support Enabled
INFO - 2018-02-22 15:59:35 --> Utf8 Class Initialized
INFO - 2018-02-22 15:59:35 --> URI Class Initialized
INFO - 2018-02-22 15:59:35 --> Router Class Initialized
INFO - 2018-02-22 15:59:35 --> Output Class Initialized
INFO - 2018-02-22 15:59:35 --> Security Class Initialized
DEBUG - 2018-02-22 15:59:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-22 15:59:35 --> Input Class Initialized
INFO - 2018-02-22 15:59:35 --> Language Class Initialized
INFO - 2018-02-22 15:59:35 --> Loader Class Initialized
INFO - 2018-02-22 15:59:35 --> Helper loaded: url_helper
INFO - 2018-02-22 15:59:35 --> Helper loaded: file_helper
INFO - 2018-02-22 15:59:35 --> Helper loaded: email_helper
INFO - 2018-02-22 15:59:35 --> Helper loaded: common_helper
INFO - 2018-02-22 15:59:35 --> Database Driver Class Initialized
DEBUG - 2018-02-22 15:59:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-22 15:59:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-22 15:59:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-22 15:59:35 --> Pagination Class Initialized
INFO - 2018-02-22 15:59:35 --> Helper loaded: form_helper
INFO - 2018-02-22 15:59:35 --> Form Validation Class Initialized
INFO - 2018-02-22 15:59:35 --> Model Class Initialized
INFO - 2018-02-22 15:59:35 --> Controller Class Initialized
DEBUG - 2018-02-22 15:59:35 --> Config file loaded: /var/www/html/project/radio/application/config/rest.php
INFO - 2018-02-22 15:59:35 --> Helper loaded: inflector_helper
INFO - 2018-02-22 15:59:35 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-22 15:59:35 --> Model Class Initialized
INFO - 2018-02-22 15:59:35 --> Model Class Initialized
INFO - 2018-02-22 15:59:35 --> Model Class Initialized
INFO - 2018-02-22 15:59:35 --> Model Class Initialized
INFO - 2018-02-22 15:59:35 --> Model Class Initialized
INFO - 2018-02-22 15:59:35 --> Model Class Initialized
INFO - 2018-02-22 15:59:35 --> Final output sent to browser
DEBUG - 2018-02-22 15:59:35 --> Total execution time: 0.0068
INFO - 2018-02-22 16:20:11 --> Config Class Initialized
INFO - 2018-02-22 16:20:11 --> Hooks Class Initialized
DEBUG - 2018-02-22 16:20:11 --> UTF-8 Support Enabled
INFO - 2018-02-22 16:20:11 --> Utf8 Class Initialized
INFO - 2018-02-22 16:20:11 --> URI Class Initialized
INFO - 2018-02-22 16:20:11 --> Router Class Initialized
INFO - 2018-02-22 16:20:11 --> Output Class Initialized
INFO - 2018-02-22 16:20:11 --> Security Class Initialized
DEBUG - 2018-02-22 16:20:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-22 16:20:11 --> Input Class Initialized
INFO - 2018-02-22 16:20:11 --> Language Class Initialized
INFO - 2018-02-22 16:20:11 --> Loader Class Initialized
INFO - 2018-02-22 16:20:11 --> Helper loaded: url_helper
INFO - 2018-02-22 16:20:11 --> Helper loaded: file_helper
INFO - 2018-02-22 16:20:11 --> Helper loaded: email_helper
INFO - 2018-02-22 16:20:11 --> Helper loaded: common_helper
INFO - 2018-02-22 16:20:11 --> Database Driver Class Initialized
DEBUG - 2018-02-22 16:20:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-22 16:20:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-22 16:20:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-22 16:20:11 --> Pagination Class Initialized
INFO - 2018-02-22 16:20:11 --> Helper loaded: form_helper
INFO - 2018-02-22 16:20:11 --> Form Validation Class Initialized
INFO - 2018-02-22 16:20:11 --> Model Class Initialized
INFO - 2018-02-22 16:20:11 --> Controller Class Initialized
DEBUG - 2018-02-22 16:20:11 --> Config file loaded: /var/www/html/project/radio/application/config/rest.php
INFO - 2018-02-22 16:20:11 --> Helper loaded: inflector_helper
INFO - 2018-02-22 16:20:11 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-22 16:20:11 --> Model Class Initialized
INFO - 2018-02-22 16:20:11 --> Model Class Initialized
INFO - 2018-02-22 16:20:11 --> Model Class Initialized
INFO - 2018-02-22 16:20:11 --> Model Class Initialized
INFO - 2018-02-22 16:20:11 --> Model Class Initialized
INFO - 2018-02-22 16:20:11 --> Model Class Initialized
INFO - 2018-02-22 16:20:11 --> Final output sent to browser
DEBUG - 2018-02-22 16:20:11 --> Total execution time: 0.0132
INFO - 2018-02-22 16:21:13 --> Config Class Initialized
INFO - 2018-02-22 16:21:13 --> Hooks Class Initialized
DEBUG - 2018-02-22 16:21:13 --> UTF-8 Support Enabled
INFO - 2018-02-22 16:21:13 --> Utf8 Class Initialized
INFO - 2018-02-22 16:21:13 --> URI Class Initialized
INFO - 2018-02-22 16:21:13 --> Router Class Initialized
INFO - 2018-02-22 16:21:13 --> Output Class Initialized
INFO - 2018-02-22 16:21:13 --> Security Class Initialized
DEBUG - 2018-02-22 16:21:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-22 16:21:13 --> Input Class Initialized
INFO - 2018-02-22 16:21:13 --> Language Class Initialized
INFO - 2018-02-22 16:21:13 --> Loader Class Initialized
INFO - 2018-02-22 16:21:13 --> Helper loaded: url_helper
INFO - 2018-02-22 16:21:13 --> Helper loaded: file_helper
INFO - 2018-02-22 16:21:13 --> Helper loaded: email_helper
INFO - 2018-02-22 16:21:13 --> Helper loaded: common_helper
INFO - 2018-02-22 16:21:13 --> Database Driver Class Initialized
DEBUG - 2018-02-22 16:21:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-22 16:21:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-22 16:21:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-22 16:21:13 --> Pagination Class Initialized
INFO - 2018-02-22 16:21:13 --> Helper loaded: form_helper
INFO - 2018-02-22 16:21:13 --> Form Validation Class Initialized
INFO - 2018-02-22 16:21:13 --> Model Class Initialized
INFO - 2018-02-22 16:21:13 --> Controller Class Initialized
DEBUG - 2018-02-22 16:21:13 --> Config file loaded: /var/www/html/project/radio/application/config/rest.php
INFO - 2018-02-22 16:21:13 --> Helper loaded: inflector_helper
INFO - 2018-02-22 16:21:13 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-22 16:21:13 --> Model Class Initialized
INFO - 2018-02-22 16:21:13 --> Model Class Initialized
INFO - 2018-02-22 16:21:13 --> Model Class Initialized
INFO - 2018-02-22 16:21:13 --> Model Class Initialized
INFO - 2018-02-22 16:21:13 --> Model Class Initialized
INFO - 2018-02-22 16:21:13 --> Model Class Initialized
INFO - 2018-02-22 16:21:49 --> Config Class Initialized
INFO - 2018-02-22 16:21:49 --> Hooks Class Initialized
DEBUG - 2018-02-22 16:21:49 --> UTF-8 Support Enabled
INFO - 2018-02-22 16:21:49 --> Utf8 Class Initialized
INFO - 2018-02-22 16:21:49 --> URI Class Initialized
INFO - 2018-02-22 16:21:49 --> Router Class Initialized
INFO - 2018-02-22 16:21:49 --> Output Class Initialized
INFO - 2018-02-22 16:21:49 --> Security Class Initialized
DEBUG - 2018-02-22 16:21:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-22 16:21:49 --> Input Class Initialized
INFO - 2018-02-22 16:21:49 --> Language Class Initialized
INFO - 2018-02-22 16:21:49 --> Loader Class Initialized
INFO - 2018-02-22 16:21:49 --> Helper loaded: url_helper
INFO - 2018-02-22 16:21:49 --> Helper loaded: file_helper
INFO - 2018-02-22 16:21:49 --> Helper loaded: email_helper
INFO - 2018-02-22 16:21:49 --> Helper loaded: common_helper
INFO - 2018-02-22 16:21:49 --> Database Driver Class Initialized
DEBUG - 2018-02-22 16:21:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-22 16:21:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-22 16:21:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-22 16:21:49 --> Pagination Class Initialized
INFO - 2018-02-22 16:21:49 --> Helper loaded: form_helper
INFO - 2018-02-22 16:21:49 --> Form Validation Class Initialized
INFO - 2018-02-22 16:21:49 --> Model Class Initialized
INFO - 2018-02-22 16:21:49 --> Controller Class Initialized
DEBUG - 2018-02-22 16:21:49 --> Config file loaded: /var/www/html/project/radio/application/config/rest.php
INFO - 2018-02-22 16:21:49 --> Helper loaded: inflector_helper
INFO - 2018-02-22 16:21:49 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-22 16:21:49 --> Model Class Initialized
INFO - 2018-02-22 16:21:49 --> Model Class Initialized
INFO - 2018-02-22 16:21:49 --> Model Class Initialized
INFO - 2018-02-22 16:21:49 --> Model Class Initialized
INFO - 2018-02-22 16:21:49 --> Model Class Initialized
INFO - 2018-02-22 16:21:49 --> Model Class Initialized
INFO - 2018-02-22 16:21:49 --> Final output sent to browser
DEBUG - 2018-02-22 16:21:49 --> Total execution time: 0.0085
INFO - 2018-02-22 16:39:07 --> Config Class Initialized
INFO - 2018-02-22 16:39:07 --> Hooks Class Initialized
DEBUG - 2018-02-22 16:39:07 --> UTF-8 Support Enabled
INFO - 2018-02-22 16:39:07 --> Utf8 Class Initialized
INFO - 2018-02-22 16:39:07 --> URI Class Initialized
INFO - 2018-02-22 16:39:07 --> Router Class Initialized
INFO - 2018-02-22 16:39:07 --> Output Class Initialized
INFO - 2018-02-22 16:39:07 --> Security Class Initialized
DEBUG - 2018-02-22 16:39:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-22 16:39:07 --> Input Class Initialized
INFO - 2018-02-22 16:39:07 --> Language Class Initialized
INFO - 2018-02-22 16:39:07 --> Loader Class Initialized
INFO - 2018-02-22 16:39:07 --> Helper loaded: url_helper
INFO - 2018-02-22 16:39:07 --> Helper loaded: file_helper
INFO - 2018-02-22 16:39:07 --> Helper loaded: email_helper
INFO - 2018-02-22 16:39:07 --> Helper loaded: common_helper
INFO - 2018-02-22 16:39:07 --> Database Driver Class Initialized
DEBUG - 2018-02-22 16:39:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-22 16:39:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-22 16:39:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-22 16:39:07 --> Pagination Class Initialized
INFO - 2018-02-22 16:39:07 --> Helper loaded: form_helper
INFO - 2018-02-22 16:39:07 --> Form Validation Class Initialized
INFO - 2018-02-22 16:39:07 --> Model Class Initialized
INFO - 2018-02-22 16:39:07 --> Controller Class Initialized
DEBUG - 2018-02-22 16:39:07 --> Config file loaded: /var/www/html/project/radio/application/config/rest.php
INFO - 2018-02-22 16:39:07 --> Helper loaded: inflector_helper
INFO - 2018-02-22 16:39:07 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-22 16:39:07 --> Model Class Initialized
INFO - 2018-02-22 16:39:07 --> Model Class Initialized
INFO - 2018-02-22 16:39:07 --> Model Class Initialized
INFO - 2018-02-22 16:39:07 --> Model Class Initialized
INFO - 2018-02-22 16:39:07 --> Model Class Initialized
INFO - 2018-02-22 16:39:07 --> Model Class Initialized
INFO - 2018-02-22 16:39:07 --> Final output sent to browser
DEBUG - 2018-02-22 16:39:07 --> Total execution time: 0.0067
INFO - 2018-02-22 16:39:30 --> Config Class Initialized
INFO - 2018-02-22 16:39:30 --> Hooks Class Initialized
DEBUG - 2018-02-22 16:39:30 --> UTF-8 Support Enabled
INFO - 2018-02-22 16:39:30 --> Utf8 Class Initialized
INFO - 2018-02-22 16:39:30 --> URI Class Initialized
INFO - 2018-02-22 16:39:30 --> Router Class Initialized
INFO - 2018-02-22 16:39:30 --> Output Class Initialized
INFO - 2018-02-22 16:39:30 --> Security Class Initialized
DEBUG - 2018-02-22 16:39:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-22 16:39:30 --> Input Class Initialized
INFO - 2018-02-22 16:39:30 --> Language Class Initialized
INFO - 2018-02-22 16:39:30 --> Loader Class Initialized
INFO - 2018-02-22 16:39:30 --> Helper loaded: url_helper
INFO - 2018-02-22 16:39:30 --> Helper loaded: file_helper
INFO - 2018-02-22 16:39:30 --> Helper loaded: email_helper
INFO - 2018-02-22 16:39:30 --> Helper loaded: common_helper
INFO - 2018-02-22 16:39:30 --> Database Driver Class Initialized
DEBUG - 2018-02-22 16:39:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-22 16:39:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-22 16:39:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-22 16:39:30 --> Pagination Class Initialized
INFO - 2018-02-22 16:39:30 --> Helper loaded: form_helper
INFO - 2018-02-22 16:39:30 --> Form Validation Class Initialized
INFO - 2018-02-22 16:39:30 --> Model Class Initialized
INFO - 2018-02-22 16:39:30 --> Controller Class Initialized
DEBUG - 2018-02-22 16:39:30 --> Config file loaded: /var/www/html/project/radio/application/config/rest.php
INFO - 2018-02-22 16:39:30 --> Helper loaded: inflector_helper
INFO - 2018-02-22 16:39:30 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-22 16:39:30 --> Model Class Initialized
INFO - 2018-02-22 16:39:30 --> Model Class Initialized
INFO - 2018-02-22 16:39:30 --> Model Class Initialized
INFO - 2018-02-22 16:39:30 --> Model Class Initialized
INFO - 2018-02-22 16:39:30 --> Model Class Initialized
INFO - 2018-02-22 16:39:30 --> Model Class Initialized
INFO - 2018-02-22 16:39:53 --> Config Class Initialized
INFO - 2018-02-22 16:39:53 --> Hooks Class Initialized
DEBUG - 2018-02-22 16:39:53 --> UTF-8 Support Enabled
INFO - 2018-02-22 16:39:53 --> Utf8 Class Initialized
INFO - 2018-02-22 16:39:53 --> URI Class Initialized
INFO - 2018-02-22 16:39:53 --> Router Class Initialized
INFO - 2018-02-22 16:39:53 --> Output Class Initialized
INFO - 2018-02-22 16:39:53 --> Security Class Initialized
DEBUG - 2018-02-22 16:39:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-22 16:39:53 --> Input Class Initialized
INFO - 2018-02-22 16:39:53 --> Language Class Initialized
INFO - 2018-02-22 16:39:53 --> Loader Class Initialized
INFO - 2018-02-22 16:39:53 --> Helper loaded: url_helper
INFO - 2018-02-22 16:39:53 --> Helper loaded: file_helper
INFO - 2018-02-22 16:39:53 --> Helper loaded: email_helper
INFO - 2018-02-22 16:39:53 --> Helper loaded: common_helper
INFO - 2018-02-22 16:39:53 --> Database Driver Class Initialized
DEBUG - 2018-02-22 16:39:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-22 16:39:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-22 16:39:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-22 16:39:53 --> Pagination Class Initialized
INFO - 2018-02-22 16:39:53 --> Helper loaded: form_helper
INFO - 2018-02-22 16:39:53 --> Form Validation Class Initialized
INFO - 2018-02-22 16:39:53 --> Model Class Initialized
INFO - 2018-02-22 16:39:53 --> Controller Class Initialized
DEBUG - 2018-02-22 16:39:53 --> Config file loaded: /var/www/html/project/radio/application/config/rest.php
INFO - 2018-02-22 16:39:53 --> Helper loaded: inflector_helper
INFO - 2018-02-22 16:39:53 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-22 16:39:53 --> Model Class Initialized
INFO - 2018-02-22 16:39:53 --> Model Class Initialized
INFO - 2018-02-22 16:39:53 --> Model Class Initialized
INFO - 2018-02-22 16:39:53 --> Model Class Initialized
INFO - 2018-02-22 16:39:53 --> Model Class Initialized
INFO - 2018-02-22 16:39:53 --> Model Class Initialized
INFO - 2018-02-22 16:39:53 --> Final output sent to browser
DEBUG - 2018-02-22 16:39:53 --> Total execution time: 0.0080
INFO - 2018-02-22 16:49:04 --> Config Class Initialized
INFO - 2018-02-22 16:49:04 --> Hooks Class Initialized
DEBUG - 2018-02-22 16:49:04 --> UTF-8 Support Enabled
INFO - 2018-02-22 16:49:04 --> Utf8 Class Initialized
INFO - 2018-02-22 16:49:04 --> URI Class Initialized
INFO - 2018-02-22 16:49:04 --> Router Class Initialized
INFO - 2018-02-22 16:49:04 --> Output Class Initialized
INFO - 2018-02-22 16:49:04 --> Security Class Initialized
DEBUG - 2018-02-22 16:49:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-22 16:49:04 --> Input Class Initialized
INFO - 2018-02-22 16:49:04 --> Language Class Initialized
INFO - 2018-02-22 16:49:04 --> Loader Class Initialized
INFO - 2018-02-22 16:49:04 --> Helper loaded: url_helper
INFO - 2018-02-22 16:49:04 --> Helper loaded: file_helper
INFO - 2018-02-22 16:49:04 --> Helper loaded: email_helper
INFO - 2018-02-22 16:49:04 --> Helper loaded: common_helper
INFO - 2018-02-22 16:49:04 --> Database Driver Class Initialized
DEBUG - 2018-02-22 16:49:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-22 16:49:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-22 16:49:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-22 16:49:04 --> Pagination Class Initialized
INFO - 2018-02-22 16:49:04 --> Helper loaded: form_helper
INFO - 2018-02-22 16:49:04 --> Form Validation Class Initialized
INFO - 2018-02-22 16:49:04 --> Model Class Initialized
INFO - 2018-02-22 16:49:04 --> Controller Class Initialized
DEBUG - 2018-02-22 16:49:04 --> Config file loaded: /var/www/html/project/radio/application/config/rest.php
INFO - 2018-02-22 16:49:04 --> Helper loaded: inflector_helper
INFO - 2018-02-22 16:49:04 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-22 16:49:04 --> Model Class Initialized
INFO - 2018-02-22 16:49:04 --> Model Class Initialized
INFO - 2018-02-22 16:49:04 --> Model Class Initialized
INFO - 2018-02-22 16:49:04 --> Model Class Initialized
INFO - 2018-02-22 16:49:04 --> Model Class Initialized
INFO - 2018-02-22 16:49:04 --> Model Class Initialized
INFO - 2018-02-22 16:49:04 --> Final output sent to browser
DEBUG - 2018-02-22 16:49:04 --> Total execution time: 0.0057
INFO - 2018-02-22 16:49:32 --> Config Class Initialized
INFO - 2018-02-22 16:49:32 --> Hooks Class Initialized
DEBUG - 2018-02-22 16:49:32 --> UTF-8 Support Enabled
INFO - 2018-02-22 16:49:32 --> Utf8 Class Initialized
INFO - 2018-02-22 16:49:32 --> URI Class Initialized
INFO - 2018-02-22 16:49:32 --> Router Class Initialized
INFO - 2018-02-22 16:49:32 --> Output Class Initialized
INFO - 2018-02-22 16:49:32 --> Security Class Initialized
DEBUG - 2018-02-22 16:49:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-22 16:49:32 --> Input Class Initialized
INFO - 2018-02-22 16:49:32 --> Language Class Initialized
INFO - 2018-02-22 16:49:32 --> Loader Class Initialized
INFO - 2018-02-22 16:49:32 --> Helper loaded: url_helper
INFO - 2018-02-22 16:49:32 --> Helper loaded: file_helper
INFO - 2018-02-22 16:49:32 --> Helper loaded: email_helper
INFO - 2018-02-22 16:49:32 --> Helper loaded: common_helper
INFO - 2018-02-22 16:49:32 --> Database Driver Class Initialized
DEBUG - 2018-02-22 16:49:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-22 16:49:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-22 16:49:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-22 16:49:32 --> Pagination Class Initialized
INFO - 2018-02-22 16:49:32 --> Helper loaded: form_helper
INFO - 2018-02-22 16:49:32 --> Form Validation Class Initialized
INFO - 2018-02-22 16:49:32 --> Model Class Initialized
INFO - 2018-02-22 16:49:32 --> Controller Class Initialized
DEBUG - 2018-02-22 16:49:32 --> Config file loaded: /var/www/html/project/radio/application/config/rest.php
INFO - 2018-02-22 16:49:32 --> Helper loaded: inflector_helper
INFO - 2018-02-22 16:49:32 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-22 16:49:32 --> Model Class Initialized
INFO - 2018-02-22 16:49:32 --> Model Class Initialized
INFO - 2018-02-22 16:49:32 --> Model Class Initialized
INFO - 2018-02-22 16:49:32 --> Model Class Initialized
INFO - 2018-02-22 16:49:32 --> Model Class Initialized
INFO - 2018-02-22 16:49:32 --> Model Class Initialized
INFO - 2018-02-22 16:49:32 --> Final output sent to browser
DEBUG - 2018-02-22 16:49:32 --> Total execution time: 0.0067
INFO - 2018-02-22 16:49:57 --> Config Class Initialized
INFO - 2018-02-22 16:49:57 --> Hooks Class Initialized
DEBUG - 2018-02-22 16:49:57 --> UTF-8 Support Enabled
INFO - 2018-02-22 16:49:57 --> Utf8 Class Initialized
INFO - 2018-02-22 16:49:57 --> URI Class Initialized
INFO - 2018-02-22 16:49:57 --> Router Class Initialized
INFO - 2018-02-22 16:49:57 --> Output Class Initialized
INFO - 2018-02-22 16:49:57 --> Security Class Initialized
DEBUG - 2018-02-22 16:49:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-22 16:49:57 --> Input Class Initialized
INFO - 2018-02-22 16:49:57 --> Language Class Initialized
INFO - 2018-02-22 16:49:57 --> Loader Class Initialized
INFO - 2018-02-22 16:49:57 --> Helper loaded: url_helper
INFO - 2018-02-22 16:49:57 --> Helper loaded: file_helper
INFO - 2018-02-22 16:49:57 --> Helper loaded: email_helper
INFO - 2018-02-22 16:49:57 --> Helper loaded: common_helper
INFO - 2018-02-22 16:49:57 --> Database Driver Class Initialized
DEBUG - 2018-02-22 16:49:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-22 16:49:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-22 16:49:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-22 16:49:57 --> Pagination Class Initialized
INFO - 2018-02-22 16:49:57 --> Helper loaded: form_helper
INFO - 2018-02-22 16:49:57 --> Form Validation Class Initialized
INFO - 2018-02-22 16:49:57 --> Model Class Initialized
INFO - 2018-02-22 16:49:57 --> Controller Class Initialized
DEBUG - 2018-02-22 16:49:57 --> Config file loaded: /var/www/html/project/radio/application/config/rest.php
INFO - 2018-02-22 16:49:57 --> Helper loaded: inflector_helper
INFO - 2018-02-22 16:49:57 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-22 16:49:57 --> Model Class Initialized
INFO - 2018-02-22 16:49:57 --> Model Class Initialized
INFO - 2018-02-22 16:49:57 --> Model Class Initialized
INFO - 2018-02-22 16:49:57 --> Model Class Initialized
INFO - 2018-02-22 16:49:57 --> Model Class Initialized
INFO - 2018-02-22 16:49:57 --> Model Class Initialized
INFO - 2018-02-22 16:49:57 --> Final output sent to browser
DEBUG - 2018-02-22 16:49:57 --> Total execution time: 0.0080
INFO - 2018-02-22 16:53:36 --> Config Class Initialized
INFO - 2018-02-22 16:53:36 --> Hooks Class Initialized
DEBUG - 2018-02-22 16:53:36 --> UTF-8 Support Enabled
INFO - 2018-02-22 16:53:36 --> Utf8 Class Initialized
INFO - 2018-02-22 16:53:36 --> URI Class Initialized
INFO - 2018-02-22 16:53:36 --> Router Class Initialized
INFO - 2018-02-22 16:53:36 --> Output Class Initialized
INFO - 2018-02-22 16:53:36 --> Security Class Initialized
DEBUG - 2018-02-22 16:53:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-22 16:53:36 --> Input Class Initialized
INFO - 2018-02-22 16:53:36 --> Language Class Initialized
INFO - 2018-02-22 16:53:36 --> Loader Class Initialized
INFO - 2018-02-22 16:53:36 --> Helper loaded: url_helper
INFO - 2018-02-22 16:53:36 --> Helper loaded: file_helper
INFO - 2018-02-22 16:53:36 --> Helper loaded: email_helper
INFO - 2018-02-22 16:53:36 --> Helper loaded: common_helper
INFO - 2018-02-22 16:53:36 --> Database Driver Class Initialized
DEBUG - 2018-02-22 16:53:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-22 16:53:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-22 16:53:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-22 16:53:36 --> Pagination Class Initialized
INFO - 2018-02-22 16:53:36 --> Helper loaded: form_helper
INFO - 2018-02-22 16:53:36 --> Form Validation Class Initialized
INFO - 2018-02-22 16:53:36 --> Model Class Initialized
INFO - 2018-02-22 16:53:36 --> Controller Class Initialized
DEBUG - 2018-02-22 16:53:36 --> Config file loaded: /var/www/html/project/radio/application/config/rest.php
INFO - 2018-02-22 16:53:36 --> Helper loaded: inflector_helper
INFO - 2018-02-22 16:53:36 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-22 16:53:36 --> Model Class Initialized
INFO - 2018-02-22 16:53:36 --> Model Class Initialized
INFO - 2018-02-22 16:53:36 --> Model Class Initialized
INFO - 2018-02-22 16:53:36 --> Model Class Initialized
INFO - 2018-02-22 16:53:36 --> Model Class Initialized
INFO - 2018-02-22 16:53:36 --> Model Class Initialized
INFO - 2018-02-22 16:53:36 --> Final output sent to browser
DEBUG - 2018-02-22 16:53:36 --> Total execution time: 0.0069
INFO - 2018-02-22 16:53:50 --> Config Class Initialized
INFO - 2018-02-22 16:53:50 --> Hooks Class Initialized
DEBUG - 2018-02-22 16:53:50 --> UTF-8 Support Enabled
INFO - 2018-02-22 16:53:50 --> Utf8 Class Initialized
INFO - 2018-02-22 16:53:50 --> URI Class Initialized
INFO - 2018-02-22 16:53:50 --> Router Class Initialized
INFO - 2018-02-22 16:53:50 --> Output Class Initialized
INFO - 2018-02-22 16:53:50 --> Security Class Initialized
DEBUG - 2018-02-22 16:53:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-22 16:53:50 --> Input Class Initialized
INFO - 2018-02-22 16:53:50 --> Language Class Initialized
INFO - 2018-02-22 16:53:50 --> Loader Class Initialized
INFO - 2018-02-22 16:53:50 --> Helper loaded: url_helper
INFO - 2018-02-22 16:53:50 --> Helper loaded: file_helper
INFO - 2018-02-22 16:53:50 --> Helper loaded: email_helper
INFO - 2018-02-22 16:53:50 --> Helper loaded: common_helper
INFO - 2018-02-22 16:53:50 --> Database Driver Class Initialized
DEBUG - 2018-02-22 16:53:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-22 16:53:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-22 16:53:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-22 16:53:50 --> Pagination Class Initialized
INFO - 2018-02-22 16:53:50 --> Helper loaded: form_helper
INFO - 2018-02-22 16:53:50 --> Form Validation Class Initialized
INFO - 2018-02-22 16:53:50 --> Model Class Initialized
INFO - 2018-02-22 16:53:50 --> Controller Class Initialized
DEBUG - 2018-02-22 16:53:50 --> Config file loaded: /var/www/html/project/radio/application/config/rest.php
INFO - 2018-02-22 16:53:50 --> Helper loaded: inflector_helper
INFO - 2018-02-22 16:53:50 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-22 16:53:50 --> Model Class Initialized
INFO - 2018-02-22 16:53:50 --> Model Class Initialized
INFO - 2018-02-22 16:53:50 --> Model Class Initialized
INFO - 2018-02-22 16:53:50 --> Model Class Initialized
INFO - 2018-02-22 16:53:50 --> Model Class Initialized
INFO - 2018-02-22 16:53:50 --> Model Class Initialized
INFO - 2018-02-22 16:53:50 --> Final output sent to browser
DEBUG - 2018-02-22 16:53:50 --> Total execution time: 0.0056
INFO - 2018-02-22 17:04:52 --> Config Class Initialized
INFO - 2018-02-22 17:04:52 --> Hooks Class Initialized
DEBUG - 2018-02-22 17:04:52 --> UTF-8 Support Enabled
INFO - 2018-02-22 17:04:52 --> Utf8 Class Initialized
INFO - 2018-02-22 17:04:52 --> URI Class Initialized
INFO - 2018-02-22 17:04:52 --> Router Class Initialized
INFO - 2018-02-22 17:04:52 --> Output Class Initialized
INFO - 2018-02-22 17:04:52 --> Security Class Initialized
DEBUG - 2018-02-22 17:04:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-22 17:04:52 --> Input Class Initialized
INFO - 2018-02-22 17:04:52 --> Language Class Initialized
INFO - 2018-02-22 17:04:52 --> Loader Class Initialized
INFO - 2018-02-22 17:04:52 --> Helper loaded: url_helper
INFO - 2018-02-22 17:04:52 --> Helper loaded: file_helper
INFO - 2018-02-22 17:04:52 --> Helper loaded: email_helper
INFO - 2018-02-22 17:04:52 --> Helper loaded: common_helper
INFO - 2018-02-22 17:04:52 --> Database Driver Class Initialized
DEBUG - 2018-02-22 17:04:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-22 17:04:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-22 17:04:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-22 17:04:52 --> Pagination Class Initialized
INFO - 2018-02-22 17:04:52 --> Helper loaded: form_helper
INFO - 2018-02-22 17:04:52 --> Form Validation Class Initialized
INFO - 2018-02-22 17:04:52 --> Model Class Initialized
INFO - 2018-02-22 17:04:52 --> Controller Class Initialized
DEBUG - 2018-02-22 17:04:52 --> Config file loaded: /var/www/html/project/radio/application/config/rest.php
INFO - 2018-02-22 17:04:52 --> Helper loaded: inflector_helper
INFO - 2018-02-22 17:04:52 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-22 17:04:52 --> Model Class Initialized
INFO - 2018-02-22 17:04:52 --> Model Class Initialized
INFO - 2018-02-22 17:04:52 --> Model Class Initialized
INFO - 2018-02-22 17:04:52 --> Model Class Initialized
INFO - 2018-02-22 17:04:52 --> Model Class Initialized
INFO - 2018-02-22 17:04:52 --> Model Class Initialized
INFO - 2018-02-22 17:04:52 --> Final output sent to browser
DEBUG - 2018-02-22 17:04:52 --> Total execution time: 0.0108
INFO - 2018-02-22 17:12:27 --> Config Class Initialized
INFO - 2018-02-22 17:12:27 --> Hooks Class Initialized
DEBUG - 2018-02-22 17:12:27 --> UTF-8 Support Enabled
INFO - 2018-02-22 17:12:27 --> Utf8 Class Initialized
INFO - 2018-02-22 17:12:27 --> URI Class Initialized
INFO - 2018-02-22 17:12:27 --> Router Class Initialized
INFO - 2018-02-22 17:12:27 --> Output Class Initialized
INFO - 2018-02-22 17:12:27 --> Security Class Initialized
DEBUG - 2018-02-22 17:12:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-22 17:12:27 --> Input Class Initialized
INFO - 2018-02-22 17:12:27 --> Language Class Initialized
INFO - 2018-02-22 17:12:27 --> Loader Class Initialized
INFO - 2018-02-22 17:12:27 --> Helper loaded: url_helper
INFO - 2018-02-22 17:12:27 --> Helper loaded: file_helper
INFO - 2018-02-22 17:12:27 --> Helper loaded: email_helper
INFO - 2018-02-22 17:12:27 --> Helper loaded: common_helper
INFO - 2018-02-22 17:12:27 --> Database Driver Class Initialized
DEBUG - 2018-02-22 17:12:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-22 17:12:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-22 17:12:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-22 17:12:27 --> Pagination Class Initialized
INFO - 2018-02-22 17:12:27 --> Helper loaded: form_helper
INFO - 2018-02-22 17:12:27 --> Form Validation Class Initialized
INFO - 2018-02-22 17:12:27 --> Model Class Initialized
INFO - 2018-02-22 17:12:27 --> Controller Class Initialized
INFO - 2018-02-22 17:12:27 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-22 17:12:27 --> Config Class Initialized
INFO - 2018-02-22 17:12:27 --> Hooks Class Initialized
DEBUG - 2018-02-22 17:12:27 --> UTF-8 Support Enabled
INFO - 2018-02-22 17:12:27 --> Utf8 Class Initialized
INFO - 2018-02-22 17:12:27 --> URI Class Initialized
DEBUG - 2018-02-22 17:12:27 --> No URI present. Default controller set.
INFO - 2018-02-22 17:12:27 --> Router Class Initialized
INFO - 2018-02-22 17:12:27 --> Output Class Initialized
INFO - 2018-02-22 17:12:27 --> Security Class Initialized
DEBUG - 2018-02-22 17:12:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-22 17:12:27 --> Input Class Initialized
INFO - 2018-02-22 17:12:27 --> Language Class Initialized
INFO - 2018-02-22 17:12:27 --> Loader Class Initialized
INFO - 2018-02-22 17:12:27 --> Helper loaded: url_helper
INFO - 2018-02-22 17:12:27 --> Helper loaded: file_helper
INFO - 2018-02-22 17:12:27 --> Helper loaded: email_helper
INFO - 2018-02-22 17:12:27 --> Helper loaded: common_helper
INFO - 2018-02-22 17:12:27 --> Database Driver Class Initialized
DEBUG - 2018-02-22 17:12:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-22 17:12:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-22 17:12:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-22 17:12:27 --> Pagination Class Initialized
INFO - 2018-02-22 17:12:27 --> Helper loaded: form_helper
INFO - 2018-02-22 17:12:27 --> Form Validation Class Initialized
INFO - 2018-02-22 17:12:27 --> Model Class Initialized
INFO - 2018-02-22 17:12:27 --> Controller Class Initialized
INFO - 2018-02-22 17:12:27 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-22 17:12:27 --> Model Class Initialized
INFO - 2018-02-22 17:12:27 --> Model Class Initialized
INFO - 2018-02-22 17:12:27 --> File loaded: /var/www/html/project/radio/application/views/index/index.php
INFO - 2018-02-22 17:12:27 --> Final output sent to browser
DEBUG - 2018-02-22 17:12:27 --> Total execution time: 0.0042
INFO - 2018-02-22 17:12:28 --> Config Class Initialized
INFO - 2018-02-22 17:12:28 --> Hooks Class Initialized
DEBUG - 2018-02-22 17:12:28 --> UTF-8 Support Enabled
INFO - 2018-02-22 17:12:28 --> Utf8 Class Initialized
INFO - 2018-02-22 17:12:28 --> URI Class Initialized
INFO - 2018-02-22 17:12:28 --> Router Class Initialized
INFO - 2018-02-22 17:12:28 --> Output Class Initialized
INFO - 2018-02-22 17:12:28 --> Security Class Initialized
DEBUG - 2018-02-22 17:12:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-22 17:12:28 --> Input Class Initialized
INFO - 2018-02-22 17:12:28 --> Language Class Initialized
INFO - 2018-02-22 17:12:28 --> Loader Class Initialized
INFO - 2018-02-22 17:12:28 --> Helper loaded: url_helper
INFO - 2018-02-22 17:12:28 --> Helper loaded: file_helper
INFO - 2018-02-22 17:12:28 --> Helper loaded: email_helper
INFO - 2018-02-22 17:12:28 --> Helper loaded: common_helper
INFO - 2018-02-22 17:12:28 --> Database Driver Class Initialized
DEBUG - 2018-02-22 17:12:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-22 17:12:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-22 17:12:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-22 17:12:28 --> Pagination Class Initialized
INFO - 2018-02-22 17:12:28 --> Helper loaded: form_helper
INFO - 2018-02-22 17:12:28 --> Form Validation Class Initialized
INFO - 2018-02-22 17:12:28 --> Model Class Initialized
INFO - 2018-02-22 17:12:28 --> Controller Class Initialized
INFO - 2018-02-22 17:12:28 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-22 17:12:28 --> Model Class Initialized
INFO - 2018-02-22 17:12:28 --> Model Class Initialized
ERROR - 2018-02-22 17:12:28 --> Severity: Notice --> Undefined index: remember_me /var/www/html/project/radio/application/controllers/Index.php 74
INFO - 2018-02-22 17:12:28 --> Config Class Initialized
INFO - 2018-02-22 17:12:28 --> Hooks Class Initialized
DEBUG - 2018-02-22 17:12:28 --> UTF-8 Support Enabled
INFO - 2018-02-22 17:12:28 --> Utf8 Class Initialized
INFO - 2018-02-22 17:12:28 --> URI Class Initialized
INFO - 2018-02-22 17:12:28 --> Router Class Initialized
INFO - 2018-02-22 17:12:28 --> Output Class Initialized
INFO - 2018-02-22 17:12:28 --> Security Class Initialized
DEBUG - 2018-02-22 17:12:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-22 17:12:28 --> Input Class Initialized
INFO - 2018-02-22 17:12:28 --> Language Class Initialized
INFO - 2018-02-22 17:12:28 --> Loader Class Initialized
INFO - 2018-02-22 17:12:28 --> Helper loaded: url_helper
INFO - 2018-02-22 17:12:28 --> Helper loaded: file_helper
INFO - 2018-02-22 17:12:28 --> Helper loaded: email_helper
INFO - 2018-02-22 17:12:28 --> Helper loaded: common_helper
INFO - 2018-02-22 17:12:28 --> Database Driver Class Initialized
DEBUG - 2018-02-22 17:12:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-22 17:12:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-22 17:12:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-22 17:12:28 --> Pagination Class Initialized
INFO - 2018-02-22 17:12:28 --> Helper loaded: form_helper
INFO - 2018-02-22 17:12:28 --> Form Validation Class Initialized
INFO - 2018-02-22 17:12:28 --> Model Class Initialized
INFO - 2018-02-22 17:12:28 --> Controller Class Initialized
INFO - 2018-02-22 17:12:28 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-22 17:12:28 --> Model Class Initialized
INFO - 2018-02-22 17:12:28 --> Model Class Initialized
INFO - 2018-02-22 17:12:28 --> Model Class Initialized
INFO - 2018-02-22 17:12:28 --> Model Class Initialized
INFO - 2018-02-22 17:12:28 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-22 17:12:28 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-22 17:12:28 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-22 17:12:28 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-22 17:12:28 --> File loaded: /var/www/html/project/radio/application/views/dashboard/index.php
INFO - 2018-02-22 17:12:28 --> Final output sent to browser
DEBUG - 2018-02-22 17:12:28 --> Total execution time: 0.0062
INFO - 2018-02-22 17:12:30 --> Config Class Initialized
INFO - 2018-02-22 17:12:30 --> Hooks Class Initialized
DEBUG - 2018-02-22 17:12:30 --> UTF-8 Support Enabled
INFO - 2018-02-22 17:12:30 --> Utf8 Class Initialized
INFO - 2018-02-22 17:12:30 --> URI Class Initialized
INFO - 2018-02-22 17:12:30 --> Router Class Initialized
INFO - 2018-02-22 17:12:30 --> Output Class Initialized
INFO - 2018-02-22 17:12:30 --> Security Class Initialized
DEBUG - 2018-02-22 17:12:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-22 17:12:30 --> Input Class Initialized
INFO - 2018-02-22 17:12:30 --> Language Class Initialized
INFO - 2018-02-22 17:12:30 --> Loader Class Initialized
INFO - 2018-02-22 17:12:30 --> Helper loaded: url_helper
INFO - 2018-02-22 17:12:30 --> Helper loaded: file_helper
INFO - 2018-02-22 17:12:30 --> Helper loaded: email_helper
INFO - 2018-02-22 17:12:30 --> Helper loaded: common_helper
INFO - 2018-02-22 17:12:30 --> Database Driver Class Initialized
DEBUG - 2018-02-22 17:12:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-22 17:12:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-22 17:12:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-22 17:12:30 --> Pagination Class Initialized
INFO - 2018-02-22 17:12:30 --> Helper loaded: form_helper
INFO - 2018-02-22 17:12:30 --> Form Validation Class Initialized
INFO - 2018-02-22 17:12:30 --> Model Class Initialized
INFO - 2018-02-22 17:12:30 --> Controller Class Initialized
INFO - 2018-02-22 17:12:30 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-22 17:12:30 --> Model Class Initialized
INFO - 2018-02-22 17:12:30 --> Model Class Initialized
INFO - 2018-02-22 17:12:30 --> Model Class Initialized
INFO - 2018-02-22 17:12:30 --> Model Class Initialized
INFO - 2018-02-22 17:12:30 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-22 17:12:30 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-22 17:12:30 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-22 17:12:30 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-22 17:12:30 --> File loaded: /var/www/html/project/radio/application/views/tracks/index.php
INFO - 2018-02-22 17:12:30 --> Final output sent to browser
DEBUG - 2018-02-22 17:12:30 --> Total execution time: 0.0037
INFO - 2018-02-22 17:12:31 --> Config Class Initialized
INFO - 2018-02-22 17:12:31 --> Hooks Class Initialized
DEBUG - 2018-02-22 17:12:31 --> UTF-8 Support Enabled
INFO - 2018-02-22 17:12:31 --> Utf8 Class Initialized
INFO - 2018-02-22 17:12:31 --> URI Class Initialized
INFO - 2018-02-22 17:12:31 --> Router Class Initialized
INFO - 2018-02-22 17:12:31 --> Output Class Initialized
INFO - 2018-02-22 17:12:31 --> Security Class Initialized
DEBUG - 2018-02-22 17:12:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-22 17:12:31 --> Input Class Initialized
INFO - 2018-02-22 17:12:31 --> Language Class Initialized
INFO - 2018-02-22 17:12:31 --> Loader Class Initialized
INFO - 2018-02-22 17:12:31 --> Helper loaded: url_helper
INFO - 2018-02-22 17:12:31 --> Helper loaded: file_helper
INFO - 2018-02-22 17:12:31 --> Helper loaded: email_helper
INFO - 2018-02-22 17:12:31 --> Helper loaded: common_helper
INFO - 2018-02-22 17:12:31 --> Database Driver Class Initialized
DEBUG - 2018-02-22 17:12:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-22 17:12:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-22 17:12:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-22 17:12:31 --> Pagination Class Initialized
INFO - 2018-02-22 17:12:31 --> Helper loaded: form_helper
INFO - 2018-02-22 17:12:31 --> Form Validation Class Initialized
INFO - 2018-02-22 17:12:31 --> Model Class Initialized
INFO - 2018-02-22 17:12:31 --> Controller Class Initialized
INFO - 2018-02-22 17:12:31 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-22 17:12:31 --> Model Class Initialized
INFO - 2018-02-22 17:12:31 --> Model Class Initialized
INFO - 2018-02-22 17:12:31 --> Model Class Initialized
INFO - 2018-02-22 17:12:31 --> Model Class Initialized
INFO - 2018-02-22 17:31:32 --> Config Class Initialized
INFO - 2018-02-22 17:31:32 --> Hooks Class Initialized
DEBUG - 2018-02-22 17:31:32 --> UTF-8 Support Enabled
INFO - 2018-02-22 17:31:32 --> Utf8 Class Initialized
INFO - 2018-02-22 17:31:32 --> URI Class Initialized
INFO - 2018-02-22 17:31:32 --> Router Class Initialized
INFO - 2018-02-22 17:31:32 --> Output Class Initialized
INFO - 2018-02-22 17:31:32 --> Security Class Initialized
DEBUG - 2018-02-22 17:31:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-22 17:31:32 --> Input Class Initialized
INFO - 2018-02-22 17:31:32 --> Language Class Initialized
INFO - 2018-02-22 17:31:32 --> Loader Class Initialized
INFO - 2018-02-22 17:31:32 --> Helper loaded: url_helper
INFO - 2018-02-22 17:31:32 --> Helper loaded: file_helper
INFO - 2018-02-22 17:31:32 --> Helper loaded: email_helper
INFO - 2018-02-22 17:31:32 --> Helper loaded: common_helper
INFO - 2018-02-22 17:31:32 --> Database Driver Class Initialized
DEBUG - 2018-02-22 17:31:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-22 17:31:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-22 17:31:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-22 17:31:32 --> Pagination Class Initialized
INFO - 2018-02-22 17:31:32 --> Helper loaded: form_helper
INFO - 2018-02-22 17:31:32 --> Form Validation Class Initialized
INFO - 2018-02-22 17:31:32 --> Model Class Initialized
INFO - 2018-02-22 17:31:32 --> Controller Class Initialized
DEBUG - 2018-02-22 17:31:32 --> Config file loaded: /var/www/html/project/radio/application/config/rest.php
INFO - 2018-02-22 17:31:32 --> Helper loaded: inflector_helper
INFO - 2018-02-22 17:31:32 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-22 17:31:32 --> Model Class Initialized
INFO - 2018-02-22 17:31:32 --> Model Class Initialized
INFO - 2018-02-22 17:31:32 --> Model Class Initialized
INFO - 2018-02-22 17:31:32 --> Model Class Initialized
INFO - 2018-02-22 17:31:32 --> Model Class Initialized
INFO - 2018-02-22 17:31:32 --> Model Class Initialized
INFO - 2018-02-22 17:31:32 --> Final output sent to browser
DEBUG - 2018-02-22 17:31:32 --> Total execution time: 0.0158
INFO - 2018-02-22 17:32:16 --> Config Class Initialized
INFO - 2018-02-22 17:32:16 --> Hooks Class Initialized
DEBUG - 2018-02-22 17:32:16 --> UTF-8 Support Enabled
INFO - 2018-02-22 17:32:16 --> Utf8 Class Initialized
INFO - 2018-02-22 17:32:16 --> URI Class Initialized
INFO - 2018-02-22 17:32:16 --> Router Class Initialized
INFO - 2018-02-22 17:32:16 --> Output Class Initialized
INFO - 2018-02-22 17:32:16 --> Security Class Initialized
DEBUG - 2018-02-22 17:32:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-22 17:32:16 --> Input Class Initialized
INFO - 2018-02-22 17:32:16 --> Language Class Initialized
INFO - 2018-02-22 17:32:16 --> Loader Class Initialized
INFO - 2018-02-22 17:32:16 --> Helper loaded: url_helper
INFO - 2018-02-22 17:32:16 --> Helper loaded: file_helper
INFO - 2018-02-22 17:32:16 --> Helper loaded: email_helper
INFO - 2018-02-22 17:32:16 --> Helper loaded: common_helper
INFO - 2018-02-22 17:32:16 --> Database Driver Class Initialized
DEBUG - 2018-02-22 17:32:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-22 17:32:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-22 17:32:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-22 17:32:16 --> Pagination Class Initialized
INFO - 2018-02-22 17:32:16 --> Helper loaded: form_helper
INFO - 2018-02-22 17:32:16 --> Form Validation Class Initialized
INFO - 2018-02-22 17:32:16 --> Model Class Initialized
INFO - 2018-02-22 17:32:16 --> Controller Class Initialized
DEBUG - 2018-02-22 17:32:16 --> Config file loaded: /var/www/html/project/radio/application/config/rest.php
INFO - 2018-02-22 17:32:16 --> Helper loaded: inflector_helper
INFO - 2018-02-22 17:32:16 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-22 17:32:16 --> Model Class Initialized
INFO - 2018-02-22 17:32:16 --> Model Class Initialized
INFO - 2018-02-22 17:32:16 --> Model Class Initialized
INFO - 2018-02-22 17:32:16 --> Model Class Initialized
INFO - 2018-02-22 17:32:16 --> Model Class Initialized
INFO - 2018-02-22 17:32:16 --> Model Class Initialized
INFO - 2018-02-22 17:32:16 --> Final output sent to browser
DEBUG - 2018-02-22 17:32:16 --> Total execution time: 0.0107
INFO - 2018-02-22 17:33:58 --> Config Class Initialized
INFO - 2018-02-22 17:33:58 --> Hooks Class Initialized
DEBUG - 2018-02-22 17:33:58 --> UTF-8 Support Enabled
INFO - 2018-02-22 17:33:58 --> Utf8 Class Initialized
INFO - 2018-02-22 17:33:58 --> URI Class Initialized
INFO - 2018-02-22 17:33:58 --> Router Class Initialized
INFO - 2018-02-22 17:33:58 --> Output Class Initialized
INFO - 2018-02-22 17:33:58 --> Security Class Initialized
DEBUG - 2018-02-22 17:33:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-22 17:33:58 --> Input Class Initialized
INFO - 2018-02-22 17:33:58 --> Language Class Initialized
INFO - 2018-02-22 17:33:58 --> Loader Class Initialized
INFO - 2018-02-22 17:33:58 --> Helper loaded: url_helper
INFO - 2018-02-22 17:33:58 --> Helper loaded: file_helper
INFO - 2018-02-22 17:33:58 --> Helper loaded: email_helper
INFO - 2018-02-22 17:33:58 --> Helper loaded: common_helper
INFO - 2018-02-22 17:33:58 --> Database Driver Class Initialized
DEBUG - 2018-02-22 17:33:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-22 17:33:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-22 17:33:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-22 17:33:58 --> Pagination Class Initialized
INFO - 2018-02-22 17:33:58 --> Helper loaded: form_helper
INFO - 2018-02-22 17:33:58 --> Form Validation Class Initialized
INFO - 2018-02-22 17:33:58 --> Model Class Initialized
INFO - 2018-02-22 17:33:58 --> Controller Class Initialized
DEBUG - 2018-02-22 17:33:58 --> Config file loaded: /var/www/html/project/radio/application/config/rest.php
INFO - 2018-02-22 17:33:58 --> Helper loaded: inflector_helper
INFO - 2018-02-22 17:33:58 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-22 17:33:58 --> Model Class Initialized
INFO - 2018-02-22 17:33:58 --> Model Class Initialized
INFO - 2018-02-22 17:33:58 --> Model Class Initialized
INFO - 2018-02-22 17:33:58 --> Model Class Initialized
INFO - 2018-02-22 17:33:58 --> Model Class Initialized
INFO - 2018-02-22 17:33:58 --> Model Class Initialized
INFO - 2018-02-22 17:33:58 --> Final output sent to browser
DEBUG - 2018-02-22 17:33:58 --> Total execution time: 0.0067
INFO - 2018-02-22 17:34:04 --> Config Class Initialized
INFO - 2018-02-22 17:34:04 --> Hooks Class Initialized
DEBUG - 2018-02-22 17:34:04 --> UTF-8 Support Enabled
INFO - 2018-02-22 17:34:04 --> Utf8 Class Initialized
INFO - 2018-02-22 17:34:04 --> URI Class Initialized
INFO - 2018-02-22 17:34:04 --> Router Class Initialized
INFO - 2018-02-22 17:34:04 --> Output Class Initialized
INFO - 2018-02-22 17:34:04 --> Security Class Initialized
DEBUG - 2018-02-22 17:34:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-22 17:34:04 --> Input Class Initialized
INFO - 2018-02-22 17:34:04 --> Language Class Initialized
INFO - 2018-02-22 17:34:04 --> Loader Class Initialized
INFO - 2018-02-22 17:34:04 --> Helper loaded: url_helper
INFO - 2018-02-22 17:34:04 --> Helper loaded: file_helper
INFO - 2018-02-22 17:34:04 --> Helper loaded: email_helper
INFO - 2018-02-22 17:34:04 --> Helper loaded: common_helper
INFO - 2018-02-22 17:34:04 --> Database Driver Class Initialized
DEBUG - 2018-02-22 17:34:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-22 17:34:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-22 17:34:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-22 17:34:04 --> Pagination Class Initialized
INFO - 2018-02-22 17:34:04 --> Helper loaded: form_helper
INFO - 2018-02-22 17:34:04 --> Form Validation Class Initialized
INFO - 2018-02-22 17:34:04 --> Model Class Initialized
INFO - 2018-02-22 17:34:04 --> Controller Class Initialized
DEBUG - 2018-02-22 17:34:04 --> Config file loaded: /var/www/html/project/radio/application/config/rest.php
INFO - 2018-02-22 17:34:04 --> Helper loaded: inflector_helper
INFO - 2018-02-22 17:34:04 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-22 17:34:04 --> Model Class Initialized
INFO - 2018-02-22 17:34:04 --> Model Class Initialized
INFO - 2018-02-22 17:34:04 --> Model Class Initialized
INFO - 2018-02-22 17:34:04 --> Model Class Initialized
INFO - 2018-02-22 17:34:04 --> Model Class Initialized
INFO - 2018-02-22 17:34:04 --> Model Class Initialized
INFO - 2018-02-22 17:34:04 --> Final output sent to browser
DEBUG - 2018-02-22 17:34:04 --> Total execution time: 0.0119
INFO - 2018-02-22 17:34:50 --> Config Class Initialized
INFO - 2018-02-22 17:34:50 --> Hooks Class Initialized
DEBUG - 2018-02-22 17:34:50 --> UTF-8 Support Enabled
INFO - 2018-02-22 17:34:50 --> Utf8 Class Initialized
INFO - 2018-02-22 17:34:50 --> URI Class Initialized
INFO - 2018-02-22 17:34:50 --> Router Class Initialized
INFO - 2018-02-22 17:34:50 --> Output Class Initialized
INFO - 2018-02-22 17:34:50 --> Security Class Initialized
DEBUG - 2018-02-22 17:34:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-22 17:34:50 --> Input Class Initialized
INFO - 2018-02-22 17:34:50 --> Language Class Initialized
INFO - 2018-02-22 17:34:50 --> Loader Class Initialized
INFO - 2018-02-22 17:34:50 --> Helper loaded: url_helper
INFO - 2018-02-22 17:34:50 --> Helper loaded: file_helper
INFO - 2018-02-22 17:34:50 --> Helper loaded: email_helper
INFO - 2018-02-22 17:34:50 --> Helper loaded: common_helper
INFO - 2018-02-22 17:34:50 --> Database Driver Class Initialized
DEBUG - 2018-02-22 17:34:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-22 17:34:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-22 17:34:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-22 17:34:50 --> Pagination Class Initialized
INFO - 2018-02-22 17:34:50 --> Helper loaded: form_helper
INFO - 2018-02-22 17:34:50 --> Form Validation Class Initialized
INFO - 2018-02-22 17:34:50 --> Model Class Initialized
INFO - 2018-02-22 17:34:50 --> Controller Class Initialized
DEBUG - 2018-02-22 17:34:50 --> Config file loaded: /var/www/html/project/radio/application/config/rest.php
INFO - 2018-02-22 17:34:50 --> Helper loaded: inflector_helper
INFO - 2018-02-22 17:34:50 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-22 17:34:50 --> Model Class Initialized
INFO - 2018-02-22 17:34:50 --> Model Class Initialized
INFO - 2018-02-22 17:34:50 --> Model Class Initialized
INFO - 2018-02-22 17:34:50 --> Model Class Initialized
INFO - 2018-02-22 17:34:50 --> Model Class Initialized
INFO - 2018-02-22 17:34:50 --> Model Class Initialized
INFO - 2018-02-22 17:34:50 --> Final output sent to browser
DEBUG - 2018-02-22 17:34:50 --> Total execution time: 0.0098
INFO - 2018-02-22 17:36:12 --> Config Class Initialized
INFO - 2018-02-22 17:36:12 --> Hooks Class Initialized
DEBUG - 2018-02-22 17:36:12 --> UTF-8 Support Enabled
INFO - 2018-02-22 17:36:12 --> Utf8 Class Initialized
INFO - 2018-02-22 17:36:12 --> URI Class Initialized
INFO - 2018-02-22 17:36:12 --> Router Class Initialized
INFO - 2018-02-22 17:36:12 --> Output Class Initialized
INFO - 2018-02-22 17:36:12 --> Security Class Initialized
DEBUG - 2018-02-22 17:36:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-22 17:36:12 --> Input Class Initialized
INFO - 2018-02-22 17:36:12 --> Language Class Initialized
INFO - 2018-02-22 17:36:12 --> Loader Class Initialized
INFO - 2018-02-22 17:36:12 --> Helper loaded: url_helper
INFO - 2018-02-22 17:36:12 --> Helper loaded: file_helper
INFO - 2018-02-22 17:36:12 --> Helper loaded: email_helper
INFO - 2018-02-22 17:36:12 --> Helper loaded: common_helper
INFO - 2018-02-22 17:36:12 --> Database Driver Class Initialized
DEBUG - 2018-02-22 17:36:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-22 17:36:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-22 17:36:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-22 17:36:12 --> Pagination Class Initialized
INFO - 2018-02-22 17:36:12 --> Helper loaded: form_helper
INFO - 2018-02-22 17:36:12 --> Form Validation Class Initialized
INFO - 2018-02-22 17:36:12 --> Model Class Initialized
INFO - 2018-02-22 17:36:12 --> Controller Class Initialized
INFO - 2018-02-22 17:36:12 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-22 17:36:12 --> Model Class Initialized
INFO - 2018-02-22 17:36:12 --> Model Class Initialized
INFO - 2018-02-22 17:36:12 --> File loaded: /var/www/html/project/radio/application/views/index/index.php
INFO - 2018-02-22 17:36:12 --> Final output sent to browser
DEBUG - 2018-02-22 17:36:12 --> Total execution time: 0.0052
INFO - 2018-02-22 17:36:14 --> Config Class Initialized
INFO - 2018-02-22 17:36:14 --> Hooks Class Initialized
DEBUG - 2018-02-22 17:36:14 --> UTF-8 Support Enabled
INFO - 2018-02-22 17:36:14 --> Utf8 Class Initialized
INFO - 2018-02-22 17:36:14 --> URI Class Initialized
INFO - 2018-02-22 17:36:14 --> Router Class Initialized
INFO - 2018-02-22 17:36:14 --> Output Class Initialized
INFO - 2018-02-22 17:36:14 --> Security Class Initialized
DEBUG - 2018-02-22 17:36:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-22 17:36:14 --> Input Class Initialized
INFO - 2018-02-22 17:36:14 --> Language Class Initialized
INFO - 2018-02-22 17:36:14 --> Loader Class Initialized
INFO - 2018-02-22 17:36:14 --> Helper loaded: url_helper
INFO - 2018-02-22 17:36:14 --> Helper loaded: file_helper
INFO - 2018-02-22 17:36:14 --> Helper loaded: email_helper
INFO - 2018-02-22 17:36:14 --> Helper loaded: common_helper
INFO - 2018-02-22 17:36:14 --> Database Driver Class Initialized
DEBUG - 2018-02-22 17:36:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-22 17:36:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-22 17:36:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-22 17:36:14 --> Pagination Class Initialized
INFO - 2018-02-22 17:36:14 --> Helper loaded: form_helper
INFO - 2018-02-22 17:36:14 --> Form Validation Class Initialized
INFO - 2018-02-22 17:36:14 --> Model Class Initialized
INFO - 2018-02-22 17:36:14 --> Controller Class Initialized
INFO - 2018-02-22 17:36:14 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-22 17:36:14 --> Model Class Initialized
INFO - 2018-02-22 17:36:14 --> Model Class Initialized
ERROR - 2018-02-22 17:36:14 --> Severity: Notice --> Undefined index: remember_me /var/www/html/project/radio/application/controllers/Index.php 74
INFO - 2018-02-22 17:36:14 --> Config Class Initialized
INFO - 2018-02-22 17:36:14 --> Hooks Class Initialized
DEBUG - 2018-02-22 17:36:14 --> UTF-8 Support Enabled
INFO - 2018-02-22 17:36:14 --> Utf8 Class Initialized
INFO - 2018-02-22 17:36:14 --> URI Class Initialized
INFO - 2018-02-22 17:36:14 --> Router Class Initialized
INFO - 2018-02-22 17:36:14 --> Output Class Initialized
INFO - 2018-02-22 17:36:14 --> Security Class Initialized
DEBUG - 2018-02-22 17:36:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-22 17:36:14 --> Input Class Initialized
INFO - 2018-02-22 17:36:14 --> Language Class Initialized
INFO - 2018-02-22 17:36:14 --> Loader Class Initialized
INFO - 2018-02-22 17:36:14 --> Helper loaded: url_helper
INFO - 2018-02-22 17:36:14 --> Helper loaded: file_helper
INFO - 2018-02-22 17:36:14 --> Helper loaded: email_helper
INFO - 2018-02-22 17:36:14 --> Helper loaded: common_helper
INFO - 2018-02-22 17:36:14 --> Database Driver Class Initialized
DEBUG - 2018-02-22 17:36:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-22 17:36:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-22 17:36:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-22 17:36:14 --> Pagination Class Initialized
INFO - 2018-02-22 17:36:14 --> Helper loaded: form_helper
INFO - 2018-02-22 17:36:14 --> Form Validation Class Initialized
INFO - 2018-02-22 17:36:14 --> Model Class Initialized
INFO - 2018-02-22 17:36:14 --> Controller Class Initialized
INFO - 2018-02-22 17:36:14 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-22 17:36:14 --> Model Class Initialized
INFO - 2018-02-22 17:36:14 --> Model Class Initialized
INFO - 2018-02-22 17:36:14 --> Model Class Initialized
INFO - 2018-02-22 17:36:14 --> Model Class Initialized
INFO - 2018-02-22 17:36:14 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-22 17:36:14 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-22 17:36:14 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-22 17:36:14 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-22 17:36:14 --> File loaded: /var/www/html/project/radio/application/views/dashboard/index.php
INFO - 2018-02-22 17:36:14 --> Final output sent to browser
DEBUG - 2018-02-22 17:36:14 --> Total execution time: 0.0080
INFO - 2018-02-22 17:36:17 --> Config Class Initialized
INFO - 2018-02-22 17:36:17 --> Hooks Class Initialized
DEBUG - 2018-02-22 17:36:17 --> UTF-8 Support Enabled
INFO - 2018-02-22 17:36:17 --> Utf8 Class Initialized
INFO - 2018-02-22 17:36:17 --> URI Class Initialized
INFO - 2018-02-22 17:36:17 --> Router Class Initialized
INFO - 2018-02-22 17:36:17 --> Output Class Initialized
INFO - 2018-02-22 17:36:17 --> Security Class Initialized
DEBUG - 2018-02-22 17:36:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-22 17:36:17 --> Input Class Initialized
INFO - 2018-02-22 17:36:17 --> Language Class Initialized
INFO - 2018-02-22 17:36:17 --> Loader Class Initialized
INFO - 2018-02-22 17:36:17 --> Helper loaded: url_helper
INFO - 2018-02-22 17:36:17 --> Helper loaded: file_helper
INFO - 2018-02-22 17:36:17 --> Helper loaded: email_helper
INFO - 2018-02-22 17:36:17 --> Helper loaded: common_helper
INFO - 2018-02-22 17:36:17 --> Database Driver Class Initialized
DEBUG - 2018-02-22 17:36:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-22 17:36:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-22 17:36:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-22 17:36:17 --> Pagination Class Initialized
INFO - 2018-02-22 17:36:17 --> Helper loaded: form_helper
INFO - 2018-02-22 17:36:17 --> Form Validation Class Initialized
INFO - 2018-02-22 17:36:17 --> Model Class Initialized
INFO - 2018-02-22 17:36:17 --> Controller Class Initialized
INFO - 2018-02-22 17:36:17 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-22 17:36:17 --> Model Class Initialized
INFO - 2018-02-22 17:36:17 --> Model Class Initialized
INFO - 2018-02-22 17:36:17 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-22 17:36:17 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-22 17:36:17 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-22 17:36:17 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-22 17:36:17 --> File loaded: /var/www/html/project/radio/application/views/subcategory/index.php
INFO - 2018-02-22 17:36:17 --> Final output sent to browser
DEBUG - 2018-02-22 17:36:17 --> Total execution time: 0.0076
INFO - 2018-02-22 17:36:20 --> Config Class Initialized
INFO - 2018-02-22 17:36:20 --> Hooks Class Initialized
DEBUG - 2018-02-22 17:36:20 --> UTF-8 Support Enabled
INFO - 2018-02-22 17:36:20 --> Utf8 Class Initialized
INFO - 2018-02-22 17:36:20 --> URI Class Initialized
INFO - 2018-02-22 17:36:20 --> Router Class Initialized
INFO - 2018-02-22 17:36:20 --> Output Class Initialized
INFO - 2018-02-22 17:36:20 --> Security Class Initialized
DEBUG - 2018-02-22 17:36:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-22 17:36:20 --> Input Class Initialized
INFO - 2018-02-22 17:36:20 --> Language Class Initialized
INFO - 2018-02-22 17:36:20 --> Loader Class Initialized
INFO - 2018-02-22 17:36:20 --> Helper loaded: url_helper
INFO - 2018-02-22 17:36:20 --> Helper loaded: file_helper
INFO - 2018-02-22 17:36:20 --> Helper loaded: email_helper
INFO - 2018-02-22 17:36:20 --> Helper loaded: common_helper
INFO - 2018-02-22 17:36:20 --> Database Driver Class Initialized
DEBUG - 2018-02-22 17:36:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-22 17:36:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-22 17:36:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-22 17:36:20 --> Pagination Class Initialized
INFO - 2018-02-22 17:36:20 --> Helper loaded: form_helper
INFO - 2018-02-22 17:36:20 --> Form Validation Class Initialized
INFO - 2018-02-22 17:36:20 --> Model Class Initialized
INFO - 2018-02-22 17:36:20 --> Controller Class Initialized
INFO - 2018-02-22 17:36:20 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-22 17:36:20 --> Model Class Initialized
INFO - 2018-02-22 17:36:20 --> Model Class Initialized
INFO - 2018-02-22 17:36:20 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-22 17:36:20 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-22 17:36:20 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-22 17:36:20 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-22 17:36:20 --> File loaded: /var/www/html/project/radio/application/views/subcategory/add_edit.php
INFO - 2018-02-22 17:36:20 --> Final output sent to browser
DEBUG - 2018-02-22 17:36:20 --> Total execution time: 0.0071
INFO - 2018-02-22 17:36:44 --> Config Class Initialized
INFO - 2018-02-22 17:36:44 --> Hooks Class Initialized
DEBUG - 2018-02-22 17:36:44 --> UTF-8 Support Enabled
INFO - 2018-02-22 17:36:44 --> Utf8 Class Initialized
INFO - 2018-02-22 17:36:44 --> URI Class Initialized
INFO - 2018-02-22 17:36:44 --> Router Class Initialized
INFO - 2018-02-22 17:36:44 --> Output Class Initialized
INFO - 2018-02-22 17:36:44 --> Security Class Initialized
DEBUG - 2018-02-22 17:36:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-22 17:36:44 --> Input Class Initialized
INFO - 2018-02-22 17:36:44 --> Language Class Initialized
INFO - 2018-02-22 17:36:44 --> Loader Class Initialized
INFO - 2018-02-22 17:36:44 --> Helper loaded: url_helper
INFO - 2018-02-22 17:36:44 --> Helper loaded: file_helper
INFO - 2018-02-22 17:36:44 --> Helper loaded: email_helper
INFO - 2018-02-22 17:36:44 --> Helper loaded: common_helper
INFO - 2018-02-22 17:36:44 --> Database Driver Class Initialized
DEBUG - 2018-02-22 17:36:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-22 17:36:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-22 17:36:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-22 17:36:44 --> Pagination Class Initialized
INFO - 2018-02-22 17:36:44 --> Helper loaded: form_helper
INFO - 2018-02-22 17:36:44 --> Form Validation Class Initialized
INFO - 2018-02-22 17:36:44 --> Model Class Initialized
INFO - 2018-02-22 17:36:44 --> Controller Class Initialized
INFO - 2018-02-22 17:36:44 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-22 17:36:44 --> Model Class Initialized
INFO - 2018-02-22 17:36:44 --> Model Class Initialized
INFO - 2018-02-22 17:36:44 --> Config Class Initialized
INFO - 2018-02-22 17:36:44 --> Hooks Class Initialized
DEBUG - 2018-02-22 17:36:44 --> UTF-8 Support Enabled
INFO - 2018-02-22 17:36:44 --> Utf8 Class Initialized
INFO - 2018-02-22 17:36:44 --> URI Class Initialized
INFO - 2018-02-22 17:36:44 --> Router Class Initialized
INFO - 2018-02-22 17:36:44 --> Output Class Initialized
INFO - 2018-02-22 17:36:44 --> Security Class Initialized
DEBUG - 2018-02-22 17:36:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-22 17:36:44 --> Input Class Initialized
INFO - 2018-02-22 17:36:44 --> Language Class Initialized
INFO - 2018-02-22 17:36:44 --> Loader Class Initialized
INFO - 2018-02-22 17:36:44 --> Helper loaded: url_helper
INFO - 2018-02-22 17:36:44 --> Helper loaded: file_helper
INFO - 2018-02-22 17:36:44 --> Helper loaded: email_helper
INFO - 2018-02-22 17:36:44 --> Helper loaded: common_helper
INFO - 2018-02-22 17:36:44 --> Database Driver Class Initialized
DEBUG - 2018-02-22 17:36:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-22 17:36:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-22 17:36:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-22 17:36:44 --> Pagination Class Initialized
INFO - 2018-02-22 17:36:44 --> Helper loaded: form_helper
INFO - 2018-02-22 17:36:44 --> Form Validation Class Initialized
INFO - 2018-02-22 17:36:44 --> Model Class Initialized
INFO - 2018-02-22 17:36:44 --> Controller Class Initialized
INFO - 2018-02-22 17:36:44 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-22 17:36:44 --> Model Class Initialized
INFO - 2018-02-22 17:36:44 --> Model Class Initialized
DEBUG - 2018-02-22 17:36:44 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-22 17:36:44 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-02-22 17:36:44 --> Config Class Initialized
INFO - 2018-02-22 17:36:44 --> Hooks Class Initialized
DEBUG - 2018-02-22 17:36:44 --> UTF-8 Support Enabled
INFO - 2018-02-22 17:36:44 --> Utf8 Class Initialized
INFO - 2018-02-22 17:36:44 --> URI Class Initialized
INFO - 2018-02-22 17:36:44 --> Router Class Initialized
INFO - 2018-02-22 17:36:44 --> Output Class Initialized
INFO - 2018-02-22 17:36:44 --> Security Class Initialized
DEBUG - 2018-02-22 17:36:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-22 17:36:44 --> Input Class Initialized
INFO - 2018-02-22 17:36:44 --> Language Class Initialized
INFO - 2018-02-22 17:36:44 --> Loader Class Initialized
INFO - 2018-02-22 17:36:44 --> Helper loaded: url_helper
INFO - 2018-02-22 17:36:44 --> Helper loaded: file_helper
INFO - 2018-02-22 17:36:44 --> Helper loaded: email_helper
INFO - 2018-02-22 17:36:44 --> Helper loaded: common_helper
INFO - 2018-02-22 17:36:44 --> Database Driver Class Initialized
DEBUG - 2018-02-22 17:36:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-22 17:36:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-22 17:36:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-22 17:36:44 --> Pagination Class Initialized
INFO - 2018-02-22 17:36:44 --> Helper loaded: form_helper
INFO - 2018-02-22 17:36:44 --> Form Validation Class Initialized
INFO - 2018-02-22 17:36:44 --> Model Class Initialized
INFO - 2018-02-22 17:36:44 --> Controller Class Initialized
INFO - 2018-02-22 17:36:44 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-22 17:36:44 --> Model Class Initialized
INFO - 2018-02-22 17:36:44 --> Model Class Initialized
INFO - 2018-02-22 17:36:44 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-22 17:36:44 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-22 17:36:44 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-22 17:36:44 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-22 17:36:44 --> File loaded: /var/www/html/project/radio/application/views/subcategory/index.php
INFO - 2018-02-22 17:36:44 --> Final output sent to browser
DEBUG - 2018-02-22 17:36:44 --> Total execution time: 0.0081
INFO - 2018-02-22 17:36:56 --> Config Class Initialized
INFO - 2018-02-22 17:36:56 --> Hooks Class Initialized
DEBUG - 2018-02-22 17:36:56 --> UTF-8 Support Enabled
INFO - 2018-02-22 17:36:56 --> Utf8 Class Initialized
INFO - 2018-02-22 17:36:56 --> URI Class Initialized
INFO - 2018-02-22 17:36:56 --> Router Class Initialized
INFO - 2018-02-22 17:36:56 --> Output Class Initialized
INFO - 2018-02-22 17:36:56 --> Security Class Initialized
DEBUG - 2018-02-22 17:36:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-22 17:36:56 --> Input Class Initialized
INFO - 2018-02-22 17:36:56 --> Language Class Initialized
INFO - 2018-02-22 17:36:56 --> Loader Class Initialized
INFO - 2018-02-22 17:36:56 --> Helper loaded: url_helper
INFO - 2018-02-22 17:36:56 --> Helper loaded: file_helper
INFO - 2018-02-22 17:36:56 --> Helper loaded: email_helper
INFO - 2018-02-22 17:36:56 --> Helper loaded: common_helper
INFO - 2018-02-22 17:36:56 --> Database Driver Class Initialized
DEBUG - 2018-02-22 17:36:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-22 17:36:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-22 17:36:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-22 17:36:56 --> Pagination Class Initialized
INFO - 2018-02-22 17:36:56 --> Helper loaded: form_helper
INFO - 2018-02-22 17:36:56 --> Form Validation Class Initialized
INFO - 2018-02-22 17:36:56 --> Model Class Initialized
INFO - 2018-02-22 17:36:56 --> Controller Class Initialized
DEBUG - 2018-02-22 17:36:56 --> Config file loaded: /var/www/html/project/radio/application/config/rest.php
INFO - 2018-02-22 17:36:56 --> Helper loaded: inflector_helper
INFO - 2018-02-22 17:36:56 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-22 17:36:56 --> Model Class Initialized
INFO - 2018-02-22 17:36:56 --> Model Class Initialized
INFO - 2018-02-22 17:36:56 --> Model Class Initialized
INFO - 2018-02-22 17:36:56 --> Model Class Initialized
INFO - 2018-02-22 17:36:56 --> Model Class Initialized
INFO - 2018-02-22 17:36:56 --> Model Class Initialized
INFO - 2018-02-22 17:36:56 --> Final output sent to browser
DEBUG - 2018-02-22 17:36:56 --> Total execution time: 0.0103
INFO - 2018-02-22 17:37:57 --> Config Class Initialized
INFO - 2018-02-22 17:37:57 --> Hooks Class Initialized
DEBUG - 2018-02-22 17:37:57 --> UTF-8 Support Enabled
INFO - 2018-02-22 17:37:57 --> Utf8 Class Initialized
INFO - 2018-02-22 17:37:57 --> URI Class Initialized
INFO - 2018-02-22 17:37:57 --> Router Class Initialized
INFO - 2018-02-22 17:37:57 --> Output Class Initialized
INFO - 2018-02-22 17:37:57 --> Security Class Initialized
DEBUG - 2018-02-22 17:37:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-22 17:37:57 --> Input Class Initialized
INFO - 2018-02-22 17:37:57 --> Language Class Initialized
INFO - 2018-02-22 17:37:57 --> Loader Class Initialized
INFO - 2018-02-22 17:37:57 --> Helper loaded: url_helper
INFO - 2018-02-22 17:37:57 --> Helper loaded: file_helper
INFO - 2018-02-22 17:37:57 --> Helper loaded: email_helper
INFO - 2018-02-22 17:37:57 --> Helper loaded: common_helper
INFO - 2018-02-22 17:37:57 --> Database Driver Class Initialized
DEBUG - 2018-02-22 17:37:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-22 17:37:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-22 17:37:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-22 17:37:57 --> Pagination Class Initialized
INFO - 2018-02-22 17:37:57 --> Helper loaded: form_helper
INFO - 2018-02-22 17:37:57 --> Form Validation Class Initialized
INFO - 2018-02-22 17:37:57 --> Model Class Initialized
INFO - 2018-02-22 17:37:57 --> Controller Class Initialized
DEBUG - 2018-02-22 17:37:57 --> Config file loaded: /var/www/html/project/radio/application/config/rest.php
INFO - 2018-02-22 17:37:57 --> Helper loaded: inflector_helper
INFO - 2018-02-22 17:37:57 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-22 17:37:57 --> Model Class Initialized
INFO - 2018-02-22 17:37:57 --> Model Class Initialized
INFO - 2018-02-22 17:37:57 --> Model Class Initialized
INFO - 2018-02-22 17:37:57 --> Model Class Initialized
INFO - 2018-02-22 17:37:57 --> Model Class Initialized
INFO - 2018-02-22 17:37:57 --> Model Class Initialized
INFO - 2018-02-22 17:37:57 --> Final output sent to browser
DEBUG - 2018-02-22 17:37:57 --> Total execution time: 0.0116
INFO - 2018-02-22 17:45:00 --> Config Class Initialized
INFO - 2018-02-22 17:45:00 --> Hooks Class Initialized
DEBUG - 2018-02-22 17:45:00 --> UTF-8 Support Enabled
INFO - 2018-02-22 17:45:00 --> Utf8 Class Initialized
INFO - 2018-02-22 17:45:00 --> URI Class Initialized
INFO - 2018-02-22 17:45:00 --> Router Class Initialized
INFO - 2018-02-22 17:45:00 --> Output Class Initialized
INFO - 2018-02-22 17:45:00 --> Security Class Initialized
DEBUG - 2018-02-22 17:45:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-22 17:45:00 --> Input Class Initialized
INFO - 2018-02-22 17:45:00 --> Language Class Initialized
INFO - 2018-02-22 17:45:00 --> Loader Class Initialized
INFO - 2018-02-22 17:45:00 --> Helper loaded: url_helper
INFO - 2018-02-22 17:45:00 --> Helper loaded: file_helper
INFO - 2018-02-22 17:45:00 --> Helper loaded: email_helper
INFO - 2018-02-22 17:45:00 --> Helper loaded: common_helper
INFO - 2018-02-22 17:45:00 --> Database Driver Class Initialized
DEBUG - 2018-02-22 17:45:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-22 17:45:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-22 17:45:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-22 17:45:00 --> Pagination Class Initialized
INFO - 2018-02-22 17:45:00 --> Helper loaded: form_helper
INFO - 2018-02-22 17:45:00 --> Form Validation Class Initialized
INFO - 2018-02-22 17:45:00 --> Model Class Initialized
INFO - 2018-02-22 17:45:00 --> Controller Class Initialized
DEBUG - 2018-02-22 17:45:00 --> Config file loaded: /var/www/html/project/radio/application/config/rest.php
INFO - 2018-02-22 17:45:00 --> Helper loaded: inflector_helper
INFO - 2018-02-22 17:45:00 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-22 17:45:00 --> Model Class Initialized
INFO - 2018-02-22 17:45:00 --> Model Class Initialized
INFO - 2018-02-22 17:45:00 --> Model Class Initialized
INFO - 2018-02-22 17:45:00 --> Model Class Initialized
INFO - 2018-02-22 17:45:00 --> Model Class Initialized
INFO - 2018-02-22 17:45:00 --> Model Class Initialized
INFO - 2018-02-22 17:45:00 --> Final output sent to browser
DEBUG - 2018-02-22 17:45:00 --> Total execution time: 0.0108
INFO - 2018-02-22 17:45:17 --> Config Class Initialized
INFO - 2018-02-22 17:45:17 --> Hooks Class Initialized
DEBUG - 2018-02-22 17:45:17 --> UTF-8 Support Enabled
INFO - 2018-02-22 17:45:17 --> Utf8 Class Initialized
INFO - 2018-02-22 17:45:17 --> URI Class Initialized
INFO - 2018-02-22 17:45:17 --> Router Class Initialized
INFO - 2018-02-22 17:45:17 --> Output Class Initialized
INFO - 2018-02-22 17:45:17 --> Security Class Initialized
DEBUG - 2018-02-22 17:45:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-22 17:45:17 --> Input Class Initialized
INFO - 2018-02-22 17:45:17 --> Language Class Initialized
INFO - 2018-02-22 17:45:17 --> Loader Class Initialized
INFO - 2018-02-22 17:45:17 --> Helper loaded: url_helper
INFO - 2018-02-22 17:45:17 --> Helper loaded: file_helper
INFO - 2018-02-22 17:45:17 --> Helper loaded: email_helper
INFO - 2018-02-22 17:45:17 --> Helper loaded: common_helper
INFO - 2018-02-22 17:45:17 --> Database Driver Class Initialized
DEBUG - 2018-02-22 17:45:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-22 17:45:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-22 17:45:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-22 17:45:17 --> Pagination Class Initialized
INFO - 2018-02-22 17:45:17 --> Helper loaded: form_helper
INFO - 2018-02-22 17:45:17 --> Form Validation Class Initialized
INFO - 2018-02-22 17:45:17 --> Model Class Initialized
INFO - 2018-02-22 17:45:17 --> Controller Class Initialized
INFO - 2018-02-22 17:45:17 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-22 17:45:17 --> Model Class Initialized
INFO - 2018-02-22 17:45:17 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-22 17:45:17 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-22 17:45:17 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-22 17:45:17 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-22 17:45:17 --> File loaded: /var/www/html/project/radio/application/views/category/index.php
INFO - 2018-02-22 17:45:17 --> Final output sent to browser
DEBUG - 2018-02-22 17:45:17 --> Total execution time: 0.0077
INFO - 2018-02-22 17:45:20 --> Config Class Initialized
INFO - 2018-02-22 17:45:20 --> Hooks Class Initialized
DEBUG - 2018-02-22 17:45:20 --> UTF-8 Support Enabled
INFO - 2018-02-22 17:45:20 --> Utf8 Class Initialized
INFO - 2018-02-22 17:45:20 --> URI Class Initialized
INFO - 2018-02-22 17:45:20 --> Router Class Initialized
INFO - 2018-02-22 17:45:20 --> Output Class Initialized
INFO - 2018-02-22 17:45:20 --> Security Class Initialized
DEBUG - 2018-02-22 17:45:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-22 17:45:20 --> Input Class Initialized
INFO - 2018-02-22 17:45:20 --> Language Class Initialized
INFO - 2018-02-22 17:45:20 --> Loader Class Initialized
INFO - 2018-02-22 17:45:20 --> Helper loaded: url_helper
INFO - 2018-02-22 17:45:20 --> Helper loaded: file_helper
INFO - 2018-02-22 17:45:20 --> Helper loaded: email_helper
INFO - 2018-02-22 17:45:20 --> Helper loaded: common_helper
INFO - 2018-02-22 17:45:20 --> Database Driver Class Initialized
DEBUG - 2018-02-22 17:45:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-22 17:45:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-22 17:45:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-22 17:45:20 --> Pagination Class Initialized
INFO - 2018-02-22 17:45:20 --> Helper loaded: form_helper
INFO - 2018-02-22 17:45:20 --> Form Validation Class Initialized
INFO - 2018-02-22 17:45:20 --> Model Class Initialized
INFO - 2018-02-22 17:45:20 --> Controller Class Initialized
INFO - 2018-02-22 17:45:20 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-22 17:45:20 --> Model Class Initialized
INFO - 2018-02-22 17:45:21 --> Config Class Initialized
INFO - 2018-02-22 17:45:21 --> Hooks Class Initialized
DEBUG - 2018-02-22 17:45:21 --> UTF-8 Support Enabled
INFO - 2018-02-22 17:45:21 --> Utf8 Class Initialized
INFO - 2018-02-22 17:45:21 --> URI Class Initialized
INFO - 2018-02-22 17:45:21 --> Router Class Initialized
INFO - 2018-02-22 17:45:21 --> Output Class Initialized
INFO - 2018-02-22 17:45:21 --> Security Class Initialized
DEBUG - 2018-02-22 17:45:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-22 17:45:21 --> Input Class Initialized
INFO - 2018-02-22 17:45:21 --> Language Class Initialized
INFO - 2018-02-22 17:45:21 --> Loader Class Initialized
INFO - 2018-02-22 17:45:21 --> Helper loaded: url_helper
INFO - 2018-02-22 17:45:21 --> Helper loaded: file_helper
INFO - 2018-02-22 17:45:21 --> Helper loaded: email_helper
INFO - 2018-02-22 17:45:21 --> Helper loaded: common_helper
INFO - 2018-02-22 17:45:21 --> Database Driver Class Initialized
DEBUG - 2018-02-22 17:45:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-22 17:45:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-22 17:45:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-22 17:45:21 --> Pagination Class Initialized
INFO - 2018-02-22 17:45:21 --> Helper loaded: form_helper
INFO - 2018-02-22 17:45:21 --> Form Validation Class Initialized
INFO - 2018-02-22 17:45:21 --> Model Class Initialized
INFO - 2018-02-22 17:45:21 --> Controller Class Initialized
INFO - 2018-02-22 17:45:21 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-22 17:45:21 --> Model Class Initialized
INFO - 2018-02-22 17:45:21 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-22 17:45:21 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-22 17:45:21 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-22 17:45:21 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-22 17:45:21 --> File loaded: /var/www/html/project/radio/application/views/category/index.php
INFO - 2018-02-22 17:45:21 --> Final output sent to browser
DEBUG - 2018-02-22 17:45:21 --> Total execution time: 0.0054
INFO - 2018-02-22 17:45:25 --> Config Class Initialized
INFO - 2018-02-22 17:45:25 --> Hooks Class Initialized
DEBUG - 2018-02-22 17:45:25 --> UTF-8 Support Enabled
INFO - 2018-02-22 17:45:25 --> Utf8 Class Initialized
INFO - 2018-02-22 17:45:25 --> URI Class Initialized
INFO - 2018-02-22 17:45:25 --> Router Class Initialized
INFO - 2018-02-22 17:45:25 --> Output Class Initialized
INFO - 2018-02-22 17:45:25 --> Security Class Initialized
DEBUG - 2018-02-22 17:45:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-22 17:45:25 --> Input Class Initialized
INFO - 2018-02-22 17:45:25 --> Language Class Initialized
INFO - 2018-02-22 17:45:25 --> Loader Class Initialized
INFO - 2018-02-22 17:45:25 --> Helper loaded: url_helper
INFO - 2018-02-22 17:45:25 --> Helper loaded: file_helper
INFO - 2018-02-22 17:45:25 --> Helper loaded: email_helper
INFO - 2018-02-22 17:45:25 --> Helper loaded: common_helper
INFO - 2018-02-22 17:45:25 --> Database Driver Class Initialized
DEBUG - 2018-02-22 17:45:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-22 17:45:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-22 17:45:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-22 17:45:25 --> Pagination Class Initialized
INFO - 2018-02-22 17:45:25 --> Helper loaded: form_helper
INFO - 2018-02-22 17:45:25 --> Form Validation Class Initialized
INFO - 2018-02-22 17:45:25 --> Model Class Initialized
INFO - 2018-02-22 17:45:25 --> Controller Class Initialized
DEBUG - 2018-02-22 17:45:25 --> Config file loaded: /var/www/html/project/radio/application/config/rest.php
INFO - 2018-02-22 17:45:25 --> Helper loaded: inflector_helper
INFO - 2018-02-22 17:45:25 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-22 17:45:25 --> Model Class Initialized
INFO - 2018-02-22 17:45:25 --> Model Class Initialized
INFO - 2018-02-22 17:45:25 --> Model Class Initialized
INFO - 2018-02-22 17:45:25 --> Model Class Initialized
INFO - 2018-02-22 17:45:25 --> Model Class Initialized
INFO - 2018-02-22 17:45:25 --> Model Class Initialized
INFO - 2018-02-22 17:45:25 --> Final output sent to browser
DEBUG - 2018-02-22 17:45:25 --> Total execution time: 0.0108
INFO - 2018-02-22 17:45:34 --> Config Class Initialized
INFO - 2018-02-22 17:45:34 --> Hooks Class Initialized
DEBUG - 2018-02-22 17:45:34 --> UTF-8 Support Enabled
INFO - 2018-02-22 17:45:34 --> Utf8 Class Initialized
INFO - 2018-02-22 17:45:34 --> URI Class Initialized
INFO - 2018-02-22 17:45:34 --> Router Class Initialized
INFO - 2018-02-22 17:45:34 --> Output Class Initialized
INFO - 2018-02-22 17:45:34 --> Security Class Initialized
DEBUG - 2018-02-22 17:45:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-22 17:45:34 --> Input Class Initialized
INFO - 2018-02-22 17:45:34 --> Language Class Initialized
INFO - 2018-02-22 17:45:34 --> Loader Class Initialized
INFO - 2018-02-22 17:45:34 --> Helper loaded: url_helper
INFO - 2018-02-22 17:45:34 --> Helper loaded: file_helper
INFO - 2018-02-22 17:45:34 --> Helper loaded: email_helper
INFO - 2018-02-22 17:45:34 --> Helper loaded: common_helper
INFO - 2018-02-22 17:45:34 --> Database Driver Class Initialized
DEBUG - 2018-02-22 17:45:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-22 17:45:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-22 17:45:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-22 17:45:34 --> Pagination Class Initialized
INFO - 2018-02-22 17:45:34 --> Helper loaded: form_helper
INFO - 2018-02-22 17:45:34 --> Form Validation Class Initialized
INFO - 2018-02-22 17:45:34 --> Model Class Initialized
INFO - 2018-02-22 17:45:34 --> Controller Class Initialized
INFO - 2018-02-22 17:45:34 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-22 17:45:34 --> Model Class Initialized
INFO - 2018-02-22 17:45:34 --> Model Class Initialized
INFO - 2018-02-22 17:45:34 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-22 17:45:34 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-22 17:45:34 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-22 17:45:34 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-22 17:45:34 --> File loaded: /var/www/html/project/radio/application/views/subcategory/index.php
INFO - 2018-02-22 17:45:34 --> Final output sent to browser
DEBUG - 2018-02-22 17:45:34 --> Total execution time: 0.0054
INFO - 2018-02-22 17:45:37 --> Config Class Initialized
INFO - 2018-02-22 17:45:37 --> Hooks Class Initialized
DEBUG - 2018-02-22 17:45:37 --> UTF-8 Support Enabled
INFO - 2018-02-22 17:45:37 --> Utf8 Class Initialized
INFO - 2018-02-22 17:45:37 --> URI Class Initialized
INFO - 2018-02-22 17:45:37 --> Router Class Initialized
INFO - 2018-02-22 17:45:37 --> Output Class Initialized
INFO - 2018-02-22 17:45:37 --> Security Class Initialized
DEBUG - 2018-02-22 17:45:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-22 17:45:37 --> Input Class Initialized
INFO - 2018-02-22 17:45:37 --> Language Class Initialized
INFO - 2018-02-22 17:45:37 --> Loader Class Initialized
INFO - 2018-02-22 17:45:37 --> Helper loaded: url_helper
INFO - 2018-02-22 17:45:37 --> Helper loaded: file_helper
INFO - 2018-02-22 17:45:37 --> Helper loaded: email_helper
INFO - 2018-02-22 17:45:37 --> Helper loaded: common_helper
INFO - 2018-02-22 17:45:37 --> Database Driver Class Initialized
DEBUG - 2018-02-22 17:45:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-22 17:45:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-22 17:45:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-22 17:45:37 --> Pagination Class Initialized
INFO - 2018-02-22 17:45:37 --> Helper loaded: form_helper
INFO - 2018-02-22 17:45:37 --> Form Validation Class Initialized
INFO - 2018-02-22 17:45:37 --> Model Class Initialized
INFO - 2018-02-22 17:45:37 --> Controller Class Initialized
INFO - 2018-02-22 17:45:37 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-22 17:45:37 --> Model Class Initialized
INFO - 2018-02-22 17:45:37 --> Model Class Initialized
INFO - 2018-02-22 17:45:37 --> Config Class Initialized
INFO - 2018-02-22 17:45:37 --> Hooks Class Initialized
DEBUG - 2018-02-22 17:45:37 --> UTF-8 Support Enabled
INFO - 2018-02-22 17:45:37 --> Utf8 Class Initialized
INFO - 2018-02-22 17:45:37 --> URI Class Initialized
INFO - 2018-02-22 17:45:37 --> Router Class Initialized
INFO - 2018-02-22 17:45:37 --> Output Class Initialized
INFO - 2018-02-22 17:45:37 --> Security Class Initialized
DEBUG - 2018-02-22 17:45:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-22 17:45:37 --> Input Class Initialized
INFO - 2018-02-22 17:45:37 --> Language Class Initialized
INFO - 2018-02-22 17:45:37 --> Loader Class Initialized
INFO - 2018-02-22 17:45:37 --> Helper loaded: url_helper
INFO - 2018-02-22 17:45:37 --> Helper loaded: file_helper
INFO - 2018-02-22 17:45:37 --> Helper loaded: email_helper
INFO - 2018-02-22 17:45:37 --> Helper loaded: common_helper
INFO - 2018-02-22 17:45:37 --> Database Driver Class Initialized
DEBUG - 2018-02-22 17:45:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-22 17:45:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-22 17:45:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-22 17:45:37 --> Pagination Class Initialized
INFO - 2018-02-22 17:45:37 --> Helper loaded: form_helper
INFO - 2018-02-22 17:45:37 --> Form Validation Class Initialized
INFO - 2018-02-22 17:45:37 --> Model Class Initialized
INFO - 2018-02-22 17:45:37 --> Controller Class Initialized
INFO - 2018-02-22 17:45:37 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-22 17:45:37 --> Model Class Initialized
INFO - 2018-02-22 17:45:37 --> Model Class Initialized
INFO - 2018-02-22 17:45:37 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-22 17:45:37 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-22 17:45:37 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-22 17:45:37 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-22 17:45:37 --> File loaded: /var/www/html/project/radio/application/views/subcategory/index.php
INFO - 2018-02-22 17:45:37 --> Final output sent to browser
DEBUG - 2018-02-22 17:45:37 --> Total execution time: 0.0067
INFO - 2018-02-22 17:45:39 --> Config Class Initialized
INFO - 2018-02-22 17:45:39 --> Hooks Class Initialized
DEBUG - 2018-02-22 17:45:39 --> UTF-8 Support Enabled
INFO - 2018-02-22 17:45:39 --> Utf8 Class Initialized
INFO - 2018-02-22 17:45:39 --> URI Class Initialized
INFO - 2018-02-22 17:45:39 --> Router Class Initialized
INFO - 2018-02-22 17:45:39 --> Output Class Initialized
INFO - 2018-02-22 17:45:39 --> Security Class Initialized
DEBUG - 2018-02-22 17:45:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-22 17:45:39 --> Input Class Initialized
INFO - 2018-02-22 17:45:39 --> Language Class Initialized
INFO - 2018-02-22 17:45:39 --> Loader Class Initialized
INFO - 2018-02-22 17:45:39 --> Helper loaded: url_helper
INFO - 2018-02-22 17:45:39 --> Helper loaded: file_helper
INFO - 2018-02-22 17:45:39 --> Helper loaded: email_helper
INFO - 2018-02-22 17:45:39 --> Helper loaded: common_helper
INFO - 2018-02-22 17:45:39 --> Database Driver Class Initialized
DEBUG - 2018-02-22 17:45:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-22 17:45:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-22 17:45:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-22 17:45:39 --> Pagination Class Initialized
INFO - 2018-02-22 17:45:39 --> Helper loaded: form_helper
INFO - 2018-02-22 17:45:39 --> Form Validation Class Initialized
INFO - 2018-02-22 17:45:39 --> Model Class Initialized
INFO - 2018-02-22 17:45:39 --> Controller Class Initialized
DEBUG - 2018-02-22 17:45:39 --> Config file loaded: /var/www/html/project/radio/application/config/rest.php
INFO - 2018-02-22 17:45:39 --> Helper loaded: inflector_helper
INFO - 2018-02-22 17:45:39 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-22 17:45:39 --> Model Class Initialized
INFO - 2018-02-22 17:45:39 --> Model Class Initialized
INFO - 2018-02-22 17:45:39 --> Model Class Initialized
INFO - 2018-02-22 17:45:39 --> Model Class Initialized
INFO - 2018-02-22 17:45:39 --> Model Class Initialized
INFO - 2018-02-22 17:45:39 --> Model Class Initialized
INFO - 2018-02-22 17:45:39 --> Final output sent to browser
DEBUG - 2018-02-22 17:45:39 --> Total execution time: 0.0068
INFO - 2018-02-22 17:45:47 --> Config Class Initialized
INFO - 2018-02-22 17:45:47 --> Hooks Class Initialized
DEBUG - 2018-02-22 17:45:47 --> UTF-8 Support Enabled
INFO - 2018-02-22 17:45:47 --> Utf8 Class Initialized
INFO - 2018-02-22 17:45:47 --> URI Class Initialized
INFO - 2018-02-22 17:45:47 --> Router Class Initialized
INFO - 2018-02-22 17:45:47 --> Output Class Initialized
INFO - 2018-02-22 17:45:47 --> Security Class Initialized
DEBUG - 2018-02-22 17:45:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-22 17:45:47 --> Input Class Initialized
INFO - 2018-02-22 17:45:47 --> Language Class Initialized
INFO - 2018-02-22 17:45:47 --> Loader Class Initialized
INFO - 2018-02-22 17:45:47 --> Helper loaded: url_helper
INFO - 2018-02-22 17:45:47 --> Helper loaded: file_helper
INFO - 2018-02-22 17:45:47 --> Helper loaded: email_helper
INFO - 2018-02-22 17:45:47 --> Helper loaded: common_helper
INFO - 2018-02-22 17:45:47 --> Database Driver Class Initialized
DEBUG - 2018-02-22 17:45:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-22 17:45:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-22 17:45:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-22 17:45:47 --> Pagination Class Initialized
INFO - 2018-02-22 17:45:47 --> Helper loaded: form_helper
INFO - 2018-02-22 17:45:47 --> Form Validation Class Initialized
INFO - 2018-02-22 17:45:47 --> Model Class Initialized
INFO - 2018-02-22 17:45:47 --> Controller Class Initialized
INFO - 2018-02-22 17:45:47 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-22 17:45:47 --> Model Class Initialized
INFO - 2018-02-22 17:45:47 --> Model Class Initialized
INFO - 2018-02-22 17:45:47 --> Config Class Initialized
INFO - 2018-02-22 17:45:47 --> Hooks Class Initialized
DEBUG - 2018-02-22 17:45:47 --> UTF-8 Support Enabled
INFO - 2018-02-22 17:45:47 --> Utf8 Class Initialized
INFO - 2018-02-22 17:45:47 --> URI Class Initialized
INFO - 2018-02-22 17:45:47 --> Router Class Initialized
INFO - 2018-02-22 17:45:47 --> Output Class Initialized
INFO - 2018-02-22 17:45:47 --> Security Class Initialized
DEBUG - 2018-02-22 17:45:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-22 17:45:47 --> Input Class Initialized
INFO - 2018-02-22 17:45:47 --> Language Class Initialized
INFO - 2018-02-22 17:45:47 --> Loader Class Initialized
INFO - 2018-02-22 17:45:47 --> Helper loaded: url_helper
INFO - 2018-02-22 17:45:47 --> Helper loaded: file_helper
INFO - 2018-02-22 17:45:47 --> Helper loaded: email_helper
INFO - 2018-02-22 17:45:47 --> Helper loaded: common_helper
INFO - 2018-02-22 17:45:47 --> Database Driver Class Initialized
DEBUG - 2018-02-22 17:45:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-22 17:45:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-22 17:45:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-22 17:45:47 --> Pagination Class Initialized
INFO - 2018-02-22 17:45:47 --> Helper loaded: form_helper
INFO - 2018-02-22 17:45:47 --> Form Validation Class Initialized
INFO - 2018-02-22 17:45:47 --> Model Class Initialized
INFO - 2018-02-22 17:45:47 --> Controller Class Initialized
INFO - 2018-02-22 17:45:47 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-22 17:45:47 --> Model Class Initialized
INFO - 2018-02-22 17:45:47 --> Model Class Initialized
INFO - 2018-02-22 17:45:47 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-22 17:45:47 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-22 17:45:47 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-22 17:45:47 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-22 17:45:47 --> File loaded: /var/www/html/project/radio/application/views/subcategory/index.php
INFO - 2018-02-22 17:45:47 --> Final output sent to browser
DEBUG - 2018-02-22 17:45:47 --> Total execution time: 0.0071
INFO - 2018-02-22 17:45:50 --> Config Class Initialized
INFO - 2018-02-22 17:45:50 --> Hooks Class Initialized
DEBUG - 2018-02-22 17:45:50 --> UTF-8 Support Enabled
INFO - 2018-02-22 17:45:50 --> Utf8 Class Initialized
INFO - 2018-02-22 17:45:50 --> URI Class Initialized
INFO - 2018-02-22 17:45:50 --> Router Class Initialized
INFO - 2018-02-22 17:45:50 --> Output Class Initialized
INFO - 2018-02-22 17:45:50 --> Security Class Initialized
DEBUG - 2018-02-22 17:45:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-22 17:45:50 --> Input Class Initialized
INFO - 2018-02-22 17:45:50 --> Language Class Initialized
INFO - 2018-02-22 17:45:50 --> Loader Class Initialized
INFO - 2018-02-22 17:45:50 --> Helper loaded: url_helper
INFO - 2018-02-22 17:45:50 --> Helper loaded: file_helper
INFO - 2018-02-22 17:45:50 --> Helper loaded: email_helper
INFO - 2018-02-22 17:45:50 --> Helper loaded: common_helper
INFO - 2018-02-22 17:45:50 --> Database Driver Class Initialized
DEBUG - 2018-02-22 17:45:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-22 17:45:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-22 17:45:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-22 17:45:50 --> Pagination Class Initialized
INFO - 2018-02-22 17:45:50 --> Helper loaded: form_helper
INFO - 2018-02-22 17:45:50 --> Form Validation Class Initialized
INFO - 2018-02-22 17:45:50 --> Model Class Initialized
INFO - 2018-02-22 17:45:50 --> Controller Class Initialized
DEBUG - 2018-02-22 17:45:50 --> Config file loaded: /var/www/html/project/radio/application/config/rest.php
INFO - 2018-02-22 17:45:50 --> Helper loaded: inflector_helper
INFO - 2018-02-22 17:45:50 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-22 17:45:50 --> Model Class Initialized
INFO - 2018-02-22 17:45:50 --> Model Class Initialized
INFO - 2018-02-22 17:45:50 --> Model Class Initialized
INFO - 2018-02-22 17:45:50 --> Model Class Initialized
INFO - 2018-02-22 17:45:50 --> Model Class Initialized
INFO - 2018-02-22 17:45:50 --> Model Class Initialized
INFO - 2018-02-22 17:45:50 --> Final output sent to browser
DEBUG - 2018-02-22 17:45:50 --> Total execution time: 0.0074
INFO - 2018-02-22 17:45:55 --> Config Class Initialized
INFO - 2018-02-22 17:45:55 --> Hooks Class Initialized
DEBUG - 2018-02-22 17:45:55 --> UTF-8 Support Enabled
INFO - 2018-02-22 17:45:55 --> Utf8 Class Initialized
INFO - 2018-02-22 17:45:55 --> URI Class Initialized
INFO - 2018-02-22 17:45:55 --> Router Class Initialized
INFO - 2018-02-22 17:45:55 --> Output Class Initialized
INFO - 2018-02-22 17:45:55 --> Security Class Initialized
DEBUG - 2018-02-22 17:45:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-22 17:45:55 --> Input Class Initialized
INFO - 2018-02-22 17:45:55 --> Language Class Initialized
INFO - 2018-02-22 17:45:55 --> Loader Class Initialized
INFO - 2018-02-22 17:45:55 --> Helper loaded: url_helper
INFO - 2018-02-22 17:45:55 --> Helper loaded: file_helper
INFO - 2018-02-22 17:45:55 --> Helper loaded: email_helper
INFO - 2018-02-22 17:45:55 --> Helper loaded: common_helper
INFO - 2018-02-22 17:45:55 --> Database Driver Class Initialized
DEBUG - 2018-02-22 17:45:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-22 17:45:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-22 17:45:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-22 17:45:55 --> Pagination Class Initialized
INFO - 2018-02-22 17:45:55 --> Helper loaded: form_helper
INFO - 2018-02-22 17:45:55 --> Form Validation Class Initialized
INFO - 2018-02-22 17:45:55 --> Model Class Initialized
INFO - 2018-02-22 17:45:55 --> Controller Class Initialized
INFO - 2018-02-22 17:45:55 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-22 17:45:55 --> Model Class Initialized
INFO - 2018-02-22 17:45:55 --> Config Class Initialized
INFO - 2018-02-22 17:45:55 --> Hooks Class Initialized
DEBUG - 2018-02-22 17:45:55 --> UTF-8 Support Enabled
INFO - 2018-02-22 17:45:55 --> Utf8 Class Initialized
INFO - 2018-02-22 17:45:55 --> URI Class Initialized
INFO - 2018-02-22 17:45:55 --> Router Class Initialized
INFO - 2018-02-22 17:45:55 --> Output Class Initialized
INFO - 2018-02-22 17:45:55 --> Security Class Initialized
DEBUG - 2018-02-22 17:45:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-22 17:45:55 --> Input Class Initialized
INFO - 2018-02-22 17:45:55 --> Language Class Initialized
INFO - 2018-02-22 17:45:55 --> Loader Class Initialized
INFO - 2018-02-22 17:45:55 --> Helper loaded: url_helper
INFO - 2018-02-22 17:45:55 --> Helper loaded: file_helper
INFO - 2018-02-22 17:45:55 --> Helper loaded: email_helper
INFO - 2018-02-22 17:45:55 --> Helper loaded: common_helper
INFO - 2018-02-22 17:45:55 --> Database Driver Class Initialized
DEBUG - 2018-02-22 17:45:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-22 17:45:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-22 17:45:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-22 17:45:55 --> Pagination Class Initialized
INFO - 2018-02-22 17:45:55 --> Helper loaded: form_helper
INFO - 2018-02-22 17:45:55 --> Form Validation Class Initialized
INFO - 2018-02-22 17:45:55 --> Model Class Initialized
INFO - 2018-02-22 17:45:55 --> Controller Class Initialized
INFO - 2018-02-22 17:45:55 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-22 17:45:55 --> Model Class Initialized
INFO - 2018-02-22 17:45:55 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-22 17:45:55 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-22 17:45:55 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-22 17:45:55 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-22 17:45:55 --> File loaded: /var/www/html/project/radio/application/views/category/index.php
INFO - 2018-02-22 17:45:55 --> Final output sent to browser
DEBUG - 2018-02-22 17:45:55 --> Total execution time: 0.0051
INFO - 2018-02-22 17:45:57 --> Config Class Initialized
INFO - 2018-02-22 17:45:57 --> Hooks Class Initialized
DEBUG - 2018-02-22 17:45:57 --> UTF-8 Support Enabled
INFO - 2018-02-22 17:45:57 --> Utf8 Class Initialized
INFO - 2018-02-22 17:45:57 --> URI Class Initialized
INFO - 2018-02-22 17:45:57 --> Router Class Initialized
INFO - 2018-02-22 17:45:57 --> Output Class Initialized
INFO - 2018-02-22 17:45:57 --> Security Class Initialized
DEBUG - 2018-02-22 17:45:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-22 17:45:57 --> Input Class Initialized
INFO - 2018-02-22 17:45:57 --> Language Class Initialized
INFO - 2018-02-22 17:45:57 --> Loader Class Initialized
INFO - 2018-02-22 17:45:57 --> Helper loaded: url_helper
INFO - 2018-02-22 17:45:57 --> Helper loaded: file_helper
INFO - 2018-02-22 17:45:57 --> Helper loaded: email_helper
INFO - 2018-02-22 17:45:57 --> Helper loaded: common_helper
INFO - 2018-02-22 17:45:57 --> Database Driver Class Initialized
DEBUG - 2018-02-22 17:45:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-22 17:45:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-22 17:45:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-22 17:45:57 --> Pagination Class Initialized
INFO - 2018-02-22 17:45:57 --> Helper loaded: form_helper
INFO - 2018-02-22 17:45:57 --> Form Validation Class Initialized
INFO - 2018-02-22 17:45:57 --> Model Class Initialized
INFO - 2018-02-22 17:45:57 --> Controller Class Initialized
DEBUG - 2018-02-22 17:45:57 --> Config file loaded: /var/www/html/project/radio/application/config/rest.php
INFO - 2018-02-22 17:45:57 --> Helper loaded: inflector_helper
INFO - 2018-02-22 17:45:57 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-22 17:45:57 --> Model Class Initialized
INFO - 2018-02-22 17:45:57 --> Model Class Initialized
INFO - 2018-02-22 17:45:57 --> Model Class Initialized
INFO - 2018-02-22 17:45:57 --> Model Class Initialized
INFO - 2018-02-22 17:45:57 --> Model Class Initialized
INFO - 2018-02-22 17:45:57 --> Model Class Initialized
INFO - 2018-02-22 17:45:57 --> Final output sent to browser
DEBUG - 2018-02-22 17:45:57 --> Total execution time: 0.0134
INFO - 2018-02-22 17:46:34 --> Config Class Initialized
INFO - 2018-02-22 17:46:34 --> Hooks Class Initialized
DEBUG - 2018-02-22 17:46:34 --> UTF-8 Support Enabled
INFO - 2018-02-22 17:46:34 --> Utf8 Class Initialized
INFO - 2018-02-22 17:46:34 --> URI Class Initialized
INFO - 2018-02-22 17:46:34 --> Router Class Initialized
INFO - 2018-02-22 17:46:34 --> Output Class Initialized
INFO - 2018-02-22 17:46:34 --> Security Class Initialized
DEBUG - 2018-02-22 17:46:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-22 17:46:34 --> Input Class Initialized
INFO - 2018-02-22 17:46:34 --> Language Class Initialized
INFO - 2018-02-22 17:46:34 --> Loader Class Initialized
INFO - 2018-02-22 17:46:34 --> Helper loaded: url_helper
INFO - 2018-02-22 17:46:34 --> Helper loaded: file_helper
INFO - 2018-02-22 17:46:34 --> Helper loaded: email_helper
INFO - 2018-02-22 17:46:34 --> Helper loaded: common_helper
INFO - 2018-02-22 17:46:34 --> Database Driver Class Initialized
DEBUG - 2018-02-22 17:46:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-22 17:46:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-22 17:46:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-22 17:46:34 --> Pagination Class Initialized
INFO - 2018-02-22 17:46:34 --> Helper loaded: form_helper
INFO - 2018-02-22 17:46:34 --> Form Validation Class Initialized
INFO - 2018-02-22 17:46:34 --> Model Class Initialized
INFO - 2018-02-22 17:46:34 --> Controller Class Initialized
DEBUG - 2018-02-22 17:46:34 --> Config file loaded: /var/www/html/project/radio/application/config/rest.php
INFO - 2018-02-22 17:46:34 --> Helper loaded: inflector_helper
INFO - 2018-02-22 17:46:34 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-22 17:46:34 --> Model Class Initialized
INFO - 2018-02-22 17:46:34 --> Model Class Initialized
INFO - 2018-02-22 17:46:34 --> Model Class Initialized
INFO - 2018-02-22 17:46:34 --> Model Class Initialized
INFO - 2018-02-22 17:46:34 --> Model Class Initialized
INFO - 2018-02-22 17:46:34 --> Model Class Initialized
INFO - 2018-02-22 17:46:34 --> Final output sent to browser
DEBUG - 2018-02-22 17:46:34 --> Total execution time: 0.0107
INFO - 2018-02-22 17:46:38 --> Config Class Initialized
INFO - 2018-02-22 17:46:38 --> Hooks Class Initialized
DEBUG - 2018-02-22 17:46:38 --> UTF-8 Support Enabled
INFO - 2018-02-22 17:46:38 --> Utf8 Class Initialized
INFO - 2018-02-22 17:46:38 --> URI Class Initialized
INFO - 2018-02-22 17:46:38 --> Router Class Initialized
INFO - 2018-02-22 17:46:38 --> Output Class Initialized
INFO - 2018-02-22 17:46:38 --> Security Class Initialized
DEBUG - 2018-02-22 17:46:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-22 17:46:38 --> Input Class Initialized
INFO - 2018-02-22 17:46:38 --> Language Class Initialized
INFO - 2018-02-22 17:46:38 --> Loader Class Initialized
INFO - 2018-02-22 17:46:38 --> Helper loaded: url_helper
INFO - 2018-02-22 17:46:38 --> Helper loaded: file_helper
INFO - 2018-02-22 17:46:38 --> Helper loaded: email_helper
INFO - 2018-02-22 17:46:38 --> Helper loaded: common_helper
INFO - 2018-02-22 17:46:38 --> Database Driver Class Initialized
DEBUG - 2018-02-22 17:46:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-22 17:46:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-22 17:46:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-22 17:46:38 --> Pagination Class Initialized
INFO - 2018-02-22 17:46:38 --> Helper loaded: form_helper
INFO - 2018-02-22 17:46:38 --> Form Validation Class Initialized
INFO - 2018-02-22 17:46:38 --> Model Class Initialized
INFO - 2018-02-22 17:46:38 --> Controller Class Initialized
INFO - 2018-02-22 17:46:38 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-22 17:46:38 --> Model Class Initialized
INFO - 2018-02-22 17:46:38 --> Config Class Initialized
INFO - 2018-02-22 17:46:38 --> Hooks Class Initialized
DEBUG - 2018-02-22 17:46:38 --> UTF-8 Support Enabled
INFO - 2018-02-22 17:46:38 --> Utf8 Class Initialized
INFO - 2018-02-22 17:46:38 --> URI Class Initialized
INFO - 2018-02-22 17:46:38 --> Router Class Initialized
INFO - 2018-02-22 17:46:38 --> Output Class Initialized
INFO - 2018-02-22 17:46:38 --> Security Class Initialized
DEBUG - 2018-02-22 17:46:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-22 17:46:38 --> Input Class Initialized
INFO - 2018-02-22 17:46:38 --> Language Class Initialized
INFO - 2018-02-22 17:46:38 --> Loader Class Initialized
INFO - 2018-02-22 17:46:38 --> Helper loaded: url_helper
INFO - 2018-02-22 17:46:38 --> Helper loaded: file_helper
INFO - 2018-02-22 17:46:38 --> Helper loaded: email_helper
INFO - 2018-02-22 17:46:38 --> Helper loaded: common_helper
INFO - 2018-02-22 17:46:38 --> Database Driver Class Initialized
DEBUG - 2018-02-22 17:46:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-22 17:46:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-22 17:46:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-22 17:46:38 --> Pagination Class Initialized
INFO - 2018-02-22 17:46:38 --> Helper loaded: form_helper
INFO - 2018-02-22 17:46:38 --> Form Validation Class Initialized
INFO - 2018-02-22 17:46:38 --> Model Class Initialized
INFO - 2018-02-22 17:46:38 --> Controller Class Initialized
INFO - 2018-02-22 17:46:38 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-22 17:46:38 --> Model Class Initialized
INFO - 2018-02-22 17:46:38 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-22 17:46:38 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-22 17:46:38 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-22 17:46:38 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-22 17:46:38 --> File loaded: /var/www/html/project/radio/application/views/category/index.php
INFO - 2018-02-22 17:46:38 --> Final output sent to browser
DEBUG - 2018-02-22 17:46:38 --> Total execution time: 0.0061
INFO - 2018-02-22 17:46:39 --> Config Class Initialized
INFO - 2018-02-22 17:46:39 --> Hooks Class Initialized
DEBUG - 2018-02-22 17:46:39 --> UTF-8 Support Enabled
INFO - 2018-02-22 17:46:39 --> Utf8 Class Initialized
INFO - 2018-02-22 17:46:39 --> URI Class Initialized
INFO - 2018-02-22 17:46:39 --> Router Class Initialized
INFO - 2018-02-22 17:46:39 --> Output Class Initialized
INFO - 2018-02-22 17:46:39 --> Security Class Initialized
DEBUG - 2018-02-22 17:46:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-22 17:46:39 --> Input Class Initialized
INFO - 2018-02-22 17:46:39 --> Language Class Initialized
INFO - 2018-02-22 17:46:39 --> Loader Class Initialized
INFO - 2018-02-22 17:46:39 --> Helper loaded: url_helper
INFO - 2018-02-22 17:46:39 --> Helper loaded: file_helper
INFO - 2018-02-22 17:46:39 --> Helper loaded: email_helper
INFO - 2018-02-22 17:46:39 --> Helper loaded: common_helper
INFO - 2018-02-22 17:46:39 --> Database Driver Class Initialized
DEBUG - 2018-02-22 17:46:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-22 17:46:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-22 17:46:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-22 17:46:39 --> Pagination Class Initialized
INFO - 2018-02-22 17:46:39 --> Helper loaded: form_helper
INFO - 2018-02-22 17:46:39 --> Form Validation Class Initialized
INFO - 2018-02-22 17:46:39 --> Model Class Initialized
INFO - 2018-02-22 17:46:39 --> Controller Class Initialized
DEBUG - 2018-02-22 17:46:39 --> Config file loaded: /var/www/html/project/radio/application/config/rest.php
INFO - 2018-02-22 17:46:39 --> Helper loaded: inflector_helper
INFO - 2018-02-22 17:46:39 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-22 17:46:39 --> Model Class Initialized
INFO - 2018-02-22 17:46:39 --> Model Class Initialized
INFO - 2018-02-22 17:46:39 --> Model Class Initialized
INFO - 2018-02-22 17:46:39 --> Model Class Initialized
INFO - 2018-02-22 17:46:39 --> Model Class Initialized
INFO - 2018-02-22 17:46:39 --> Model Class Initialized
INFO - 2018-02-22 17:46:39 --> Final output sent to browser
DEBUG - 2018-02-22 17:46:39 --> Total execution time: 0.0094
INFO - 2018-02-22 17:46:41 --> Config Class Initialized
INFO - 2018-02-22 17:46:41 --> Hooks Class Initialized
DEBUG - 2018-02-22 17:46:41 --> UTF-8 Support Enabled
INFO - 2018-02-22 17:46:41 --> Utf8 Class Initialized
INFO - 2018-02-22 17:46:41 --> URI Class Initialized
INFO - 2018-02-22 17:46:41 --> Router Class Initialized
INFO - 2018-02-22 17:46:41 --> Output Class Initialized
INFO - 2018-02-22 17:46:41 --> Security Class Initialized
DEBUG - 2018-02-22 17:46:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-22 17:46:41 --> Input Class Initialized
INFO - 2018-02-22 17:46:41 --> Language Class Initialized
INFO - 2018-02-22 17:46:41 --> Loader Class Initialized
INFO - 2018-02-22 17:46:41 --> Helper loaded: url_helper
INFO - 2018-02-22 17:46:41 --> Helper loaded: file_helper
INFO - 2018-02-22 17:46:41 --> Helper loaded: email_helper
INFO - 2018-02-22 17:46:41 --> Helper loaded: common_helper
INFO - 2018-02-22 17:46:41 --> Database Driver Class Initialized
DEBUG - 2018-02-22 17:46:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-22 17:46:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-22 17:46:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-22 17:46:41 --> Pagination Class Initialized
INFO - 2018-02-22 17:46:41 --> Helper loaded: form_helper
INFO - 2018-02-22 17:46:41 --> Form Validation Class Initialized
INFO - 2018-02-22 17:46:41 --> Model Class Initialized
INFO - 2018-02-22 17:46:41 --> Controller Class Initialized
INFO - 2018-02-22 17:46:41 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-22 17:46:41 --> Model Class Initialized
INFO - 2018-02-22 17:46:41 --> Config Class Initialized
INFO - 2018-02-22 17:46:41 --> Hooks Class Initialized
DEBUG - 2018-02-22 17:46:41 --> UTF-8 Support Enabled
INFO - 2018-02-22 17:46:41 --> Utf8 Class Initialized
INFO - 2018-02-22 17:46:41 --> URI Class Initialized
INFO - 2018-02-22 17:46:41 --> Router Class Initialized
INFO - 2018-02-22 17:46:41 --> Output Class Initialized
INFO - 2018-02-22 17:46:41 --> Security Class Initialized
DEBUG - 2018-02-22 17:46:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-22 17:46:41 --> Input Class Initialized
INFO - 2018-02-22 17:46:41 --> Language Class Initialized
INFO - 2018-02-22 17:46:41 --> Loader Class Initialized
INFO - 2018-02-22 17:46:41 --> Helper loaded: url_helper
INFO - 2018-02-22 17:46:41 --> Helper loaded: file_helper
INFO - 2018-02-22 17:46:41 --> Helper loaded: email_helper
INFO - 2018-02-22 17:46:41 --> Helper loaded: common_helper
INFO - 2018-02-22 17:46:41 --> Database Driver Class Initialized
DEBUG - 2018-02-22 17:46:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-22 17:46:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-22 17:46:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-22 17:46:41 --> Pagination Class Initialized
INFO - 2018-02-22 17:46:41 --> Helper loaded: form_helper
INFO - 2018-02-22 17:46:41 --> Form Validation Class Initialized
INFO - 2018-02-22 17:46:41 --> Model Class Initialized
INFO - 2018-02-22 17:46:41 --> Controller Class Initialized
INFO - 2018-02-22 17:46:41 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-22 17:46:41 --> Model Class Initialized
INFO - 2018-02-22 17:46:41 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-22 17:46:41 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-22 17:46:41 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-22 17:46:41 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-22 17:46:41 --> File loaded: /var/www/html/project/radio/application/views/category/index.php
INFO - 2018-02-22 17:46:41 --> Final output sent to browser
DEBUG - 2018-02-22 17:46:41 --> Total execution time: 0.0051
INFO - 2018-02-22 17:46:42 --> Config Class Initialized
INFO - 2018-02-22 17:46:42 --> Hooks Class Initialized
DEBUG - 2018-02-22 17:46:42 --> UTF-8 Support Enabled
INFO - 2018-02-22 17:46:42 --> Utf8 Class Initialized
INFO - 2018-02-22 17:46:42 --> URI Class Initialized
INFO - 2018-02-22 17:46:42 --> Router Class Initialized
INFO - 2018-02-22 17:46:42 --> Output Class Initialized
INFO - 2018-02-22 17:46:42 --> Security Class Initialized
DEBUG - 2018-02-22 17:46:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-22 17:46:42 --> Input Class Initialized
INFO - 2018-02-22 17:46:42 --> Language Class Initialized
INFO - 2018-02-22 17:46:42 --> Loader Class Initialized
INFO - 2018-02-22 17:46:42 --> Helper loaded: url_helper
INFO - 2018-02-22 17:46:42 --> Helper loaded: file_helper
INFO - 2018-02-22 17:46:42 --> Helper loaded: email_helper
INFO - 2018-02-22 17:46:42 --> Helper loaded: common_helper
INFO - 2018-02-22 17:46:42 --> Database Driver Class Initialized
DEBUG - 2018-02-22 17:46:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-22 17:46:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-22 17:46:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-22 17:46:42 --> Pagination Class Initialized
INFO - 2018-02-22 17:46:42 --> Helper loaded: form_helper
INFO - 2018-02-22 17:46:42 --> Form Validation Class Initialized
INFO - 2018-02-22 17:46:42 --> Model Class Initialized
INFO - 2018-02-22 17:46:42 --> Controller Class Initialized
DEBUG - 2018-02-22 17:46:42 --> Config file loaded: /var/www/html/project/radio/application/config/rest.php
INFO - 2018-02-22 17:46:42 --> Helper loaded: inflector_helper
INFO - 2018-02-22 17:46:42 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-22 17:46:42 --> Model Class Initialized
INFO - 2018-02-22 17:46:42 --> Model Class Initialized
INFO - 2018-02-22 17:46:42 --> Model Class Initialized
INFO - 2018-02-22 17:46:42 --> Model Class Initialized
INFO - 2018-02-22 17:46:42 --> Model Class Initialized
INFO - 2018-02-22 17:46:42 --> Model Class Initialized
INFO - 2018-02-22 17:46:42 --> Final output sent to browser
DEBUG - 2018-02-22 17:46:42 --> Total execution time: 0.0399
INFO - 2018-02-22 17:46:49 --> Config Class Initialized
INFO - 2018-02-22 17:46:49 --> Hooks Class Initialized
DEBUG - 2018-02-22 17:46:49 --> UTF-8 Support Enabled
INFO - 2018-02-22 17:46:49 --> Utf8 Class Initialized
INFO - 2018-02-22 17:46:49 --> URI Class Initialized
INFO - 2018-02-22 17:46:49 --> Router Class Initialized
INFO - 2018-02-22 17:46:49 --> Output Class Initialized
INFO - 2018-02-22 17:46:49 --> Security Class Initialized
DEBUG - 2018-02-22 17:46:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-22 17:46:49 --> Input Class Initialized
INFO - 2018-02-22 17:46:49 --> Language Class Initialized
INFO - 2018-02-22 17:46:49 --> Loader Class Initialized
INFO - 2018-02-22 17:46:49 --> Helper loaded: url_helper
INFO - 2018-02-22 17:46:49 --> Helper loaded: file_helper
INFO - 2018-02-22 17:46:49 --> Helper loaded: email_helper
INFO - 2018-02-22 17:46:49 --> Helper loaded: common_helper
INFO - 2018-02-22 17:46:49 --> Database Driver Class Initialized
DEBUG - 2018-02-22 17:46:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-22 17:46:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-22 17:46:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-22 17:46:49 --> Pagination Class Initialized
INFO - 2018-02-22 17:46:49 --> Helper loaded: form_helper
INFO - 2018-02-22 17:46:49 --> Form Validation Class Initialized
INFO - 2018-02-22 17:46:49 --> Model Class Initialized
INFO - 2018-02-22 17:46:49 --> Controller Class Initialized
INFO - 2018-02-22 17:46:49 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-22 17:46:49 --> Model Class Initialized
INFO - 2018-02-22 17:46:49 --> Model Class Initialized
INFO - 2018-02-22 17:46:49 --> Config Class Initialized
INFO - 2018-02-22 17:46:49 --> Hooks Class Initialized
DEBUG - 2018-02-22 17:46:49 --> UTF-8 Support Enabled
INFO - 2018-02-22 17:46:49 --> Utf8 Class Initialized
INFO - 2018-02-22 17:46:49 --> URI Class Initialized
INFO - 2018-02-22 17:46:49 --> Router Class Initialized
INFO - 2018-02-22 17:46:49 --> Output Class Initialized
INFO - 2018-02-22 17:46:49 --> Security Class Initialized
DEBUG - 2018-02-22 17:46:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-22 17:46:49 --> Input Class Initialized
INFO - 2018-02-22 17:46:49 --> Language Class Initialized
INFO - 2018-02-22 17:46:49 --> Loader Class Initialized
INFO - 2018-02-22 17:46:49 --> Helper loaded: url_helper
INFO - 2018-02-22 17:46:49 --> Helper loaded: file_helper
INFO - 2018-02-22 17:46:49 --> Helper loaded: email_helper
INFO - 2018-02-22 17:46:49 --> Helper loaded: common_helper
INFO - 2018-02-22 17:46:49 --> Database Driver Class Initialized
DEBUG - 2018-02-22 17:46:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-22 17:46:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-22 17:46:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-22 17:46:49 --> Pagination Class Initialized
INFO - 2018-02-22 17:46:49 --> Helper loaded: form_helper
INFO - 2018-02-22 17:46:49 --> Form Validation Class Initialized
INFO - 2018-02-22 17:46:49 --> Model Class Initialized
INFO - 2018-02-22 17:46:49 --> Controller Class Initialized
INFO - 2018-02-22 17:46:49 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-22 17:46:49 --> Model Class Initialized
INFO - 2018-02-22 17:46:49 --> Model Class Initialized
INFO - 2018-02-22 17:46:49 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-22 17:46:49 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-22 17:46:49 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-22 17:46:49 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-22 17:46:49 --> File loaded: /var/www/html/project/radio/application/views/subcategory/index.php
INFO - 2018-02-22 17:46:49 --> Final output sent to browser
DEBUG - 2018-02-22 17:46:49 --> Total execution time: 0.0058
INFO - 2018-02-22 17:46:51 --> Config Class Initialized
INFO - 2018-02-22 17:46:51 --> Hooks Class Initialized
DEBUG - 2018-02-22 17:46:51 --> UTF-8 Support Enabled
INFO - 2018-02-22 17:46:51 --> Utf8 Class Initialized
INFO - 2018-02-22 17:46:51 --> URI Class Initialized
INFO - 2018-02-22 17:46:51 --> Router Class Initialized
INFO - 2018-02-22 17:46:51 --> Output Class Initialized
INFO - 2018-02-22 17:46:51 --> Security Class Initialized
DEBUG - 2018-02-22 17:46:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-22 17:46:51 --> Input Class Initialized
INFO - 2018-02-22 17:46:51 --> Language Class Initialized
INFO - 2018-02-22 17:46:51 --> Loader Class Initialized
INFO - 2018-02-22 17:46:51 --> Helper loaded: url_helper
INFO - 2018-02-22 17:46:51 --> Helper loaded: file_helper
INFO - 2018-02-22 17:46:51 --> Helper loaded: email_helper
INFO - 2018-02-22 17:46:51 --> Helper loaded: common_helper
INFO - 2018-02-22 17:46:51 --> Database Driver Class Initialized
DEBUG - 2018-02-22 17:46:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-22 17:46:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-22 17:46:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-22 17:46:51 --> Pagination Class Initialized
INFO - 2018-02-22 17:46:51 --> Helper loaded: form_helper
INFO - 2018-02-22 17:46:51 --> Form Validation Class Initialized
INFO - 2018-02-22 17:46:51 --> Model Class Initialized
INFO - 2018-02-22 17:46:51 --> Controller Class Initialized
DEBUG - 2018-02-22 17:46:51 --> Config file loaded: /var/www/html/project/radio/application/config/rest.php
INFO - 2018-02-22 17:46:51 --> Helper loaded: inflector_helper
INFO - 2018-02-22 17:46:51 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-22 17:46:51 --> Model Class Initialized
INFO - 2018-02-22 17:46:51 --> Model Class Initialized
INFO - 2018-02-22 17:46:51 --> Model Class Initialized
INFO - 2018-02-22 17:46:51 --> Model Class Initialized
INFO - 2018-02-22 17:46:51 --> Model Class Initialized
INFO - 2018-02-22 17:46:51 --> Model Class Initialized
INFO - 2018-02-22 17:46:51 --> Final output sent to browser
DEBUG - 2018-02-22 17:46:51 --> Total execution time: 0.0097
INFO - 2018-02-22 17:46:56 --> Config Class Initialized
INFO - 2018-02-22 17:46:56 --> Hooks Class Initialized
DEBUG - 2018-02-22 17:46:56 --> UTF-8 Support Enabled
INFO - 2018-02-22 17:46:56 --> Utf8 Class Initialized
INFO - 2018-02-22 17:46:56 --> URI Class Initialized
INFO - 2018-02-22 17:46:56 --> Router Class Initialized
INFO - 2018-02-22 17:46:56 --> Output Class Initialized
INFO - 2018-02-22 17:46:56 --> Security Class Initialized
DEBUG - 2018-02-22 17:46:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-22 17:46:56 --> Input Class Initialized
INFO - 2018-02-22 17:46:56 --> Language Class Initialized
INFO - 2018-02-22 17:46:56 --> Loader Class Initialized
INFO - 2018-02-22 17:46:56 --> Helper loaded: url_helper
INFO - 2018-02-22 17:46:56 --> Helper loaded: file_helper
INFO - 2018-02-22 17:46:56 --> Helper loaded: email_helper
INFO - 2018-02-22 17:46:56 --> Helper loaded: common_helper
INFO - 2018-02-22 17:46:56 --> Database Driver Class Initialized
DEBUG - 2018-02-22 17:46:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-22 17:46:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-22 17:46:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-22 17:46:56 --> Pagination Class Initialized
INFO - 2018-02-22 17:46:56 --> Helper loaded: form_helper
INFO - 2018-02-22 17:46:56 --> Form Validation Class Initialized
INFO - 2018-02-22 17:46:56 --> Model Class Initialized
INFO - 2018-02-22 17:46:56 --> Controller Class Initialized
INFO - 2018-02-22 17:46:56 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-22 17:46:56 --> Model Class Initialized
INFO - 2018-02-22 17:46:56 --> Config Class Initialized
INFO - 2018-02-22 17:46:56 --> Hooks Class Initialized
DEBUG - 2018-02-22 17:46:56 --> UTF-8 Support Enabled
INFO - 2018-02-22 17:46:56 --> Utf8 Class Initialized
INFO - 2018-02-22 17:46:56 --> URI Class Initialized
INFO - 2018-02-22 17:46:56 --> Router Class Initialized
INFO - 2018-02-22 17:46:56 --> Output Class Initialized
INFO - 2018-02-22 17:46:56 --> Security Class Initialized
DEBUG - 2018-02-22 17:46:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-22 17:46:56 --> Input Class Initialized
INFO - 2018-02-22 17:46:56 --> Language Class Initialized
INFO - 2018-02-22 17:46:56 --> Loader Class Initialized
INFO - 2018-02-22 17:46:56 --> Helper loaded: url_helper
INFO - 2018-02-22 17:46:56 --> Helper loaded: file_helper
INFO - 2018-02-22 17:46:56 --> Helper loaded: email_helper
INFO - 2018-02-22 17:46:56 --> Helper loaded: common_helper
INFO - 2018-02-22 17:46:56 --> Database Driver Class Initialized
DEBUG - 2018-02-22 17:46:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-22 17:46:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-22 17:46:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-22 17:46:56 --> Pagination Class Initialized
INFO - 2018-02-22 17:46:56 --> Helper loaded: form_helper
INFO - 2018-02-22 17:46:56 --> Form Validation Class Initialized
INFO - 2018-02-22 17:46:56 --> Model Class Initialized
INFO - 2018-02-22 17:46:56 --> Controller Class Initialized
INFO - 2018-02-22 17:46:56 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-22 17:46:56 --> Model Class Initialized
INFO - 2018-02-22 17:46:56 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-22 17:46:56 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-22 17:46:56 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-22 17:46:56 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-22 17:46:56 --> File loaded: /var/www/html/project/radio/application/views/category/index.php
INFO - 2018-02-22 17:46:56 --> Final output sent to browser
DEBUG - 2018-02-22 17:46:56 --> Total execution time: 0.0064
INFO - 2018-02-22 17:46:58 --> Config Class Initialized
INFO - 2018-02-22 17:46:58 --> Hooks Class Initialized
DEBUG - 2018-02-22 17:46:58 --> UTF-8 Support Enabled
INFO - 2018-02-22 17:46:58 --> Utf8 Class Initialized
INFO - 2018-02-22 17:46:58 --> URI Class Initialized
INFO - 2018-02-22 17:46:58 --> Router Class Initialized
INFO - 2018-02-22 17:46:58 --> Output Class Initialized
INFO - 2018-02-22 17:46:58 --> Security Class Initialized
DEBUG - 2018-02-22 17:46:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-22 17:46:58 --> Input Class Initialized
INFO - 2018-02-22 17:46:58 --> Language Class Initialized
INFO - 2018-02-22 17:46:58 --> Loader Class Initialized
INFO - 2018-02-22 17:46:58 --> Helper loaded: url_helper
INFO - 2018-02-22 17:46:58 --> Helper loaded: file_helper
INFO - 2018-02-22 17:46:58 --> Helper loaded: email_helper
INFO - 2018-02-22 17:46:58 --> Helper loaded: common_helper
INFO - 2018-02-22 17:46:58 --> Database Driver Class Initialized
DEBUG - 2018-02-22 17:46:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-22 17:46:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-22 17:46:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-22 17:46:58 --> Pagination Class Initialized
INFO - 2018-02-22 17:46:58 --> Helper loaded: form_helper
INFO - 2018-02-22 17:46:58 --> Form Validation Class Initialized
INFO - 2018-02-22 17:46:58 --> Model Class Initialized
INFO - 2018-02-22 17:46:58 --> Controller Class Initialized
DEBUG - 2018-02-22 17:46:58 --> Config file loaded: /var/www/html/project/radio/application/config/rest.php
INFO - 2018-02-22 17:46:58 --> Helper loaded: inflector_helper
INFO - 2018-02-22 17:46:58 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-22 17:46:58 --> Model Class Initialized
INFO - 2018-02-22 17:46:58 --> Model Class Initialized
INFO - 2018-02-22 17:46:58 --> Model Class Initialized
INFO - 2018-02-22 17:46:58 --> Model Class Initialized
INFO - 2018-02-22 17:46:58 --> Model Class Initialized
INFO - 2018-02-22 17:46:58 --> Model Class Initialized
INFO - 2018-02-22 17:46:58 --> Final output sent to browser
DEBUG - 2018-02-22 17:46:58 --> Total execution time: 0.0127
INFO - 2018-02-22 17:47:00 --> Config Class Initialized
INFO - 2018-02-22 17:47:00 --> Hooks Class Initialized
DEBUG - 2018-02-22 17:47:00 --> UTF-8 Support Enabled
INFO - 2018-02-22 17:47:00 --> Utf8 Class Initialized
INFO - 2018-02-22 17:47:00 --> URI Class Initialized
INFO - 2018-02-22 17:47:00 --> Router Class Initialized
INFO - 2018-02-22 17:47:00 --> Output Class Initialized
INFO - 2018-02-22 17:47:00 --> Security Class Initialized
DEBUG - 2018-02-22 17:47:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-22 17:47:00 --> Input Class Initialized
INFO - 2018-02-22 17:47:00 --> Language Class Initialized
INFO - 2018-02-22 17:47:00 --> Loader Class Initialized
INFO - 2018-02-22 17:47:00 --> Helper loaded: url_helper
INFO - 2018-02-22 17:47:00 --> Helper loaded: file_helper
INFO - 2018-02-22 17:47:00 --> Helper loaded: email_helper
INFO - 2018-02-22 17:47:00 --> Helper loaded: common_helper
INFO - 2018-02-22 17:47:00 --> Database Driver Class Initialized
DEBUG - 2018-02-22 17:47:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-22 17:47:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-22 17:47:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-22 17:47:00 --> Pagination Class Initialized
INFO - 2018-02-22 17:47:00 --> Helper loaded: form_helper
INFO - 2018-02-22 17:47:00 --> Form Validation Class Initialized
INFO - 2018-02-22 17:47:00 --> Model Class Initialized
INFO - 2018-02-22 17:47:00 --> Controller Class Initialized
INFO - 2018-02-22 17:47:00 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-22 17:47:00 --> Model Class Initialized
INFO - 2018-02-22 17:47:00 --> Config Class Initialized
INFO - 2018-02-22 17:47:00 --> Hooks Class Initialized
DEBUG - 2018-02-22 17:47:00 --> UTF-8 Support Enabled
INFO - 2018-02-22 17:47:00 --> Utf8 Class Initialized
INFO - 2018-02-22 17:47:00 --> URI Class Initialized
INFO - 2018-02-22 17:47:00 --> Router Class Initialized
INFO - 2018-02-22 17:47:00 --> Output Class Initialized
INFO - 2018-02-22 17:47:00 --> Security Class Initialized
DEBUG - 2018-02-22 17:47:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-22 17:47:00 --> Input Class Initialized
INFO - 2018-02-22 17:47:00 --> Language Class Initialized
INFO - 2018-02-22 17:47:00 --> Loader Class Initialized
INFO - 2018-02-22 17:47:00 --> Helper loaded: url_helper
INFO - 2018-02-22 17:47:00 --> Helper loaded: file_helper
INFO - 2018-02-22 17:47:00 --> Helper loaded: email_helper
INFO - 2018-02-22 17:47:00 --> Helper loaded: common_helper
INFO - 2018-02-22 17:47:00 --> Database Driver Class Initialized
DEBUG - 2018-02-22 17:47:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-22 17:47:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-22 17:47:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-22 17:47:00 --> Pagination Class Initialized
INFO - 2018-02-22 17:47:00 --> Helper loaded: form_helper
INFO - 2018-02-22 17:47:00 --> Form Validation Class Initialized
INFO - 2018-02-22 17:47:00 --> Model Class Initialized
INFO - 2018-02-22 17:47:00 --> Controller Class Initialized
INFO - 2018-02-22 17:47:00 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-22 17:47:00 --> Model Class Initialized
INFO - 2018-02-22 17:47:00 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-22 17:47:00 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-22 17:47:00 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-22 17:47:00 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-22 17:47:00 --> File loaded: /var/www/html/project/radio/application/views/category/index.php
INFO - 2018-02-22 17:47:00 --> Final output sent to browser
DEBUG - 2018-02-22 17:47:00 --> Total execution time: 0.0052
INFO - 2018-02-22 17:47:02 --> Config Class Initialized
INFO - 2018-02-22 17:47:02 --> Hooks Class Initialized
DEBUG - 2018-02-22 17:47:02 --> UTF-8 Support Enabled
INFO - 2018-02-22 17:47:02 --> Utf8 Class Initialized
INFO - 2018-02-22 17:47:02 --> URI Class Initialized
INFO - 2018-02-22 17:47:02 --> Router Class Initialized
INFO - 2018-02-22 17:47:02 --> Output Class Initialized
INFO - 2018-02-22 17:47:02 --> Security Class Initialized
DEBUG - 2018-02-22 17:47:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-22 17:47:02 --> Input Class Initialized
INFO - 2018-02-22 17:47:02 --> Language Class Initialized
INFO - 2018-02-22 17:47:02 --> Loader Class Initialized
INFO - 2018-02-22 17:47:02 --> Helper loaded: url_helper
INFO - 2018-02-22 17:47:02 --> Helper loaded: file_helper
INFO - 2018-02-22 17:47:02 --> Helper loaded: email_helper
INFO - 2018-02-22 17:47:02 --> Helper loaded: common_helper
INFO - 2018-02-22 17:47:02 --> Database Driver Class Initialized
DEBUG - 2018-02-22 17:47:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-22 17:47:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-22 17:47:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-22 17:47:02 --> Pagination Class Initialized
INFO - 2018-02-22 17:47:02 --> Helper loaded: form_helper
INFO - 2018-02-22 17:47:02 --> Form Validation Class Initialized
INFO - 2018-02-22 17:47:02 --> Model Class Initialized
INFO - 2018-02-22 17:47:02 --> Controller Class Initialized
DEBUG - 2018-02-22 17:47:02 --> Config file loaded: /var/www/html/project/radio/application/config/rest.php
INFO - 2018-02-22 17:47:02 --> Helper loaded: inflector_helper
INFO - 2018-02-22 17:47:02 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-22 17:47:02 --> Model Class Initialized
INFO - 2018-02-22 17:47:02 --> Model Class Initialized
INFO - 2018-02-22 17:47:02 --> Model Class Initialized
INFO - 2018-02-22 17:47:02 --> Model Class Initialized
INFO - 2018-02-22 17:47:02 --> Model Class Initialized
INFO - 2018-02-22 17:47:02 --> Model Class Initialized
INFO - 2018-02-22 17:47:02 --> Final output sent to browser
DEBUG - 2018-02-22 17:47:02 --> Total execution time: 0.0103
INFO - 2018-02-22 17:47:05 --> Config Class Initialized
INFO - 2018-02-22 17:47:05 --> Hooks Class Initialized
DEBUG - 2018-02-22 17:47:05 --> UTF-8 Support Enabled
INFO - 2018-02-22 17:47:05 --> Utf8 Class Initialized
INFO - 2018-02-22 17:47:05 --> URI Class Initialized
INFO - 2018-02-22 17:47:05 --> Router Class Initialized
INFO - 2018-02-22 17:47:05 --> Output Class Initialized
INFO - 2018-02-22 17:47:05 --> Security Class Initialized
DEBUG - 2018-02-22 17:47:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-22 17:47:05 --> Input Class Initialized
INFO - 2018-02-22 17:47:05 --> Language Class Initialized
INFO - 2018-02-22 17:47:05 --> Loader Class Initialized
INFO - 2018-02-22 17:47:05 --> Helper loaded: url_helper
INFO - 2018-02-22 17:47:05 --> Helper loaded: file_helper
INFO - 2018-02-22 17:47:05 --> Helper loaded: email_helper
INFO - 2018-02-22 17:47:05 --> Helper loaded: common_helper
INFO - 2018-02-22 17:47:05 --> Database Driver Class Initialized
DEBUG - 2018-02-22 17:47:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-22 17:47:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-22 17:47:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-22 17:47:05 --> Pagination Class Initialized
INFO - 2018-02-22 17:47:05 --> Helper loaded: form_helper
INFO - 2018-02-22 17:47:05 --> Form Validation Class Initialized
INFO - 2018-02-22 17:47:05 --> Model Class Initialized
INFO - 2018-02-22 17:47:05 --> Controller Class Initialized
INFO - 2018-02-22 17:47:05 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-22 17:47:05 --> Model Class Initialized
INFO - 2018-02-22 17:47:05 --> Model Class Initialized
INFO - 2018-02-22 17:47:05 --> Config Class Initialized
INFO - 2018-02-22 17:47:05 --> Hooks Class Initialized
DEBUG - 2018-02-22 17:47:05 --> UTF-8 Support Enabled
INFO - 2018-02-22 17:47:05 --> Utf8 Class Initialized
INFO - 2018-02-22 17:47:05 --> URI Class Initialized
INFO - 2018-02-22 17:47:05 --> Router Class Initialized
INFO - 2018-02-22 17:47:05 --> Output Class Initialized
INFO - 2018-02-22 17:47:05 --> Security Class Initialized
DEBUG - 2018-02-22 17:47:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-22 17:47:05 --> Input Class Initialized
INFO - 2018-02-22 17:47:05 --> Language Class Initialized
INFO - 2018-02-22 17:47:05 --> Loader Class Initialized
INFO - 2018-02-22 17:47:05 --> Helper loaded: url_helper
INFO - 2018-02-22 17:47:05 --> Helper loaded: file_helper
INFO - 2018-02-22 17:47:05 --> Helper loaded: email_helper
INFO - 2018-02-22 17:47:05 --> Helper loaded: common_helper
INFO - 2018-02-22 17:47:05 --> Database Driver Class Initialized
DEBUG - 2018-02-22 17:47:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-22 17:47:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-22 17:47:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-22 17:47:05 --> Pagination Class Initialized
INFO - 2018-02-22 17:47:05 --> Helper loaded: form_helper
INFO - 2018-02-22 17:47:05 --> Form Validation Class Initialized
INFO - 2018-02-22 17:47:05 --> Model Class Initialized
INFO - 2018-02-22 17:47:05 --> Controller Class Initialized
INFO - 2018-02-22 17:47:05 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-22 17:47:05 --> Model Class Initialized
INFO - 2018-02-22 17:47:05 --> Model Class Initialized
INFO - 2018-02-22 17:47:05 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-22 17:47:05 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-22 17:47:05 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-22 17:47:05 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-22 17:47:05 --> File loaded: /var/www/html/project/radio/application/views/subcategory/index.php
INFO - 2018-02-22 17:47:05 --> Final output sent to browser
DEBUG - 2018-02-22 17:47:05 --> Total execution time: 0.0065
INFO - 2018-02-22 17:47:06 --> Config Class Initialized
INFO - 2018-02-22 17:47:06 --> Hooks Class Initialized
DEBUG - 2018-02-22 17:47:06 --> UTF-8 Support Enabled
INFO - 2018-02-22 17:47:06 --> Utf8 Class Initialized
INFO - 2018-02-22 17:47:06 --> URI Class Initialized
INFO - 2018-02-22 17:47:06 --> Router Class Initialized
INFO - 2018-02-22 17:47:06 --> Output Class Initialized
INFO - 2018-02-22 17:47:06 --> Security Class Initialized
DEBUG - 2018-02-22 17:47:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-22 17:47:06 --> Input Class Initialized
INFO - 2018-02-22 17:47:06 --> Language Class Initialized
INFO - 2018-02-22 17:47:06 --> Loader Class Initialized
INFO - 2018-02-22 17:47:06 --> Helper loaded: url_helper
INFO - 2018-02-22 17:47:06 --> Helper loaded: file_helper
INFO - 2018-02-22 17:47:06 --> Helper loaded: email_helper
INFO - 2018-02-22 17:47:06 --> Helper loaded: common_helper
INFO - 2018-02-22 17:47:06 --> Database Driver Class Initialized
DEBUG - 2018-02-22 17:47:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-22 17:47:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-22 17:47:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-22 17:47:06 --> Pagination Class Initialized
INFO - 2018-02-22 17:47:06 --> Helper loaded: form_helper
INFO - 2018-02-22 17:47:06 --> Form Validation Class Initialized
INFO - 2018-02-22 17:47:06 --> Model Class Initialized
INFO - 2018-02-22 17:47:06 --> Controller Class Initialized
DEBUG - 2018-02-22 17:47:06 --> Config file loaded: /var/www/html/project/radio/application/config/rest.php
INFO - 2018-02-22 17:47:06 --> Helper loaded: inflector_helper
INFO - 2018-02-22 17:47:06 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-22 17:47:06 --> Model Class Initialized
INFO - 2018-02-22 17:47:06 --> Model Class Initialized
INFO - 2018-02-22 17:47:06 --> Model Class Initialized
INFO - 2018-02-22 17:47:06 --> Model Class Initialized
INFO - 2018-02-22 17:47:06 --> Model Class Initialized
INFO - 2018-02-22 17:47:06 --> Model Class Initialized
INFO - 2018-02-22 17:47:06 --> Final output sent to browser
DEBUG - 2018-02-22 17:47:06 --> Total execution time: 0.0106
INFO - 2018-02-22 17:47:06 --> Config Class Initialized
INFO - 2018-02-22 17:47:06 --> Hooks Class Initialized
DEBUG - 2018-02-22 17:47:06 --> UTF-8 Support Enabled
INFO - 2018-02-22 17:47:06 --> Utf8 Class Initialized
INFO - 2018-02-22 17:47:06 --> URI Class Initialized
INFO - 2018-02-22 17:47:06 --> Router Class Initialized
INFO - 2018-02-22 17:47:06 --> Output Class Initialized
INFO - 2018-02-22 17:47:06 --> Security Class Initialized
DEBUG - 2018-02-22 17:47:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-22 17:47:06 --> Input Class Initialized
INFO - 2018-02-22 17:47:06 --> Language Class Initialized
INFO - 2018-02-22 17:47:06 --> Loader Class Initialized
INFO - 2018-02-22 17:47:06 --> Helper loaded: url_helper
INFO - 2018-02-22 17:47:06 --> Helper loaded: file_helper
INFO - 2018-02-22 17:47:06 --> Helper loaded: email_helper
INFO - 2018-02-22 17:47:06 --> Helper loaded: common_helper
INFO - 2018-02-22 17:47:06 --> Database Driver Class Initialized
DEBUG - 2018-02-22 17:47:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-22 17:47:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-22 17:47:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-22 17:47:06 --> Pagination Class Initialized
INFO - 2018-02-22 17:47:06 --> Helper loaded: form_helper
INFO - 2018-02-22 17:47:06 --> Form Validation Class Initialized
INFO - 2018-02-22 17:47:06 --> Model Class Initialized
INFO - 2018-02-22 17:47:06 --> Controller Class Initialized
INFO - 2018-02-22 17:47:06 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-22 17:47:06 --> Model Class Initialized
INFO - 2018-02-22 17:47:06 --> Model Class Initialized
INFO - 2018-02-22 17:47:06 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-22 17:47:06 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-22 17:47:06 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-22 17:47:06 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-22 17:47:06 --> File loaded: /var/www/html/project/radio/application/views/subcategory/add_edit.php
INFO - 2018-02-22 17:47:06 --> Final output sent to browser
DEBUG - 2018-02-22 17:47:06 --> Total execution time: 0.0052
INFO - 2018-02-22 17:47:16 --> Config Class Initialized
INFO - 2018-02-22 17:47:16 --> Hooks Class Initialized
DEBUG - 2018-02-22 17:47:16 --> UTF-8 Support Enabled
INFO - 2018-02-22 17:47:16 --> Utf8 Class Initialized
INFO - 2018-02-22 17:47:16 --> URI Class Initialized
INFO - 2018-02-22 17:47:16 --> Router Class Initialized
INFO - 2018-02-22 17:47:16 --> Output Class Initialized
INFO - 2018-02-22 17:47:16 --> Security Class Initialized
DEBUG - 2018-02-22 17:47:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-22 17:47:16 --> Input Class Initialized
INFO - 2018-02-22 17:47:16 --> Language Class Initialized
INFO - 2018-02-22 17:47:16 --> Loader Class Initialized
INFO - 2018-02-22 17:47:16 --> Helper loaded: url_helper
INFO - 2018-02-22 17:47:16 --> Helper loaded: file_helper
INFO - 2018-02-22 17:47:16 --> Helper loaded: email_helper
INFO - 2018-02-22 17:47:16 --> Helper loaded: common_helper
INFO - 2018-02-22 17:47:16 --> Database Driver Class Initialized
DEBUG - 2018-02-22 17:47:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-22 17:47:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-22 17:47:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-22 17:47:16 --> Pagination Class Initialized
INFO - 2018-02-22 17:47:16 --> Helper loaded: form_helper
INFO - 2018-02-22 17:47:16 --> Form Validation Class Initialized
INFO - 2018-02-22 17:47:16 --> Model Class Initialized
INFO - 2018-02-22 17:47:16 --> Controller Class Initialized
INFO - 2018-02-22 17:47:16 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-22 17:47:16 --> Model Class Initialized
INFO - 2018-02-22 17:47:16 --> Model Class Initialized
INFO - 2018-02-22 17:47:16 --> Config Class Initialized
INFO - 2018-02-22 17:47:16 --> Hooks Class Initialized
DEBUG - 2018-02-22 17:47:16 --> UTF-8 Support Enabled
INFO - 2018-02-22 17:47:16 --> Utf8 Class Initialized
INFO - 2018-02-22 17:47:16 --> URI Class Initialized
INFO - 2018-02-22 17:47:16 --> Router Class Initialized
INFO - 2018-02-22 17:47:16 --> Output Class Initialized
INFO - 2018-02-22 17:47:16 --> Security Class Initialized
DEBUG - 2018-02-22 17:47:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-22 17:47:16 --> Input Class Initialized
INFO - 2018-02-22 17:47:16 --> Language Class Initialized
INFO - 2018-02-22 17:47:16 --> Loader Class Initialized
INFO - 2018-02-22 17:47:16 --> Helper loaded: url_helper
INFO - 2018-02-22 17:47:16 --> Helper loaded: file_helper
INFO - 2018-02-22 17:47:16 --> Helper loaded: email_helper
INFO - 2018-02-22 17:47:16 --> Helper loaded: common_helper
INFO - 2018-02-22 17:47:16 --> Database Driver Class Initialized
DEBUG - 2018-02-22 17:47:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-22 17:47:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-22 17:47:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-22 17:47:16 --> Pagination Class Initialized
INFO - 2018-02-22 17:47:16 --> Helper loaded: form_helper
INFO - 2018-02-22 17:47:16 --> Form Validation Class Initialized
INFO - 2018-02-22 17:47:16 --> Model Class Initialized
INFO - 2018-02-22 17:47:16 --> Controller Class Initialized
INFO - 2018-02-22 17:47:16 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-22 17:47:16 --> Model Class Initialized
INFO - 2018-02-22 17:47:16 --> Model Class Initialized
DEBUG - 2018-02-22 17:47:16 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-22 17:47:16 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-02-22 17:47:16 --> Config Class Initialized
INFO - 2018-02-22 17:47:16 --> Hooks Class Initialized
DEBUG - 2018-02-22 17:47:16 --> UTF-8 Support Enabled
INFO - 2018-02-22 17:47:16 --> Utf8 Class Initialized
INFO - 2018-02-22 17:47:16 --> URI Class Initialized
INFO - 2018-02-22 17:47:16 --> Router Class Initialized
INFO - 2018-02-22 17:47:16 --> Output Class Initialized
INFO - 2018-02-22 17:47:16 --> Security Class Initialized
DEBUG - 2018-02-22 17:47:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-22 17:47:16 --> Input Class Initialized
INFO - 2018-02-22 17:47:16 --> Language Class Initialized
INFO - 2018-02-22 17:47:16 --> Loader Class Initialized
INFO - 2018-02-22 17:47:16 --> Helper loaded: url_helper
INFO - 2018-02-22 17:47:16 --> Helper loaded: file_helper
INFO - 2018-02-22 17:47:16 --> Helper loaded: email_helper
INFO - 2018-02-22 17:47:16 --> Helper loaded: common_helper
INFO - 2018-02-22 17:47:16 --> Database Driver Class Initialized
DEBUG - 2018-02-22 17:47:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-22 17:47:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-22 17:47:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-22 17:47:16 --> Pagination Class Initialized
INFO - 2018-02-22 17:47:16 --> Helper loaded: form_helper
INFO - 2018-02-22 17:47:16 --> Form Validation Class Initialized
INFO - 2018-02-22 17:47:16 --> Model Class Initialized
INFO - 2018-02-22 17:47:16 --> Controller Class Initialized
INFO - 2018-02-22 17:47:16 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-22 17:47:16 --> Model Class Initialized
INFO - 2018-02-22 17:47:16 --> Model Class Initialized
INFO - 2018-02-22 17:47:16 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-22 17:47:16 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-22 17:47:16 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-22 17:47:16 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-22 17:47:16 --> File loaded: /var/www/html/project/radio/application/views/subcategory/index.php
INFO - 2018-02-22 17:47:16 --> Final output sent to browser
DEBUG - 2018-02-22 17:47:16 --> Total execution time: 0.0068
INFO - 2018-02-22 17:47:24 --> Config Class Initialized
INFO - 2018-02-22 17:47:24 --> Hooks Class Initialized
DEBUG - 2018-02-22 17:47:24 --> UTF-8 Support Enabled
INFO - 2018-02-22 17:47:24 --> Utf8 Class Initialized
INFO - 2018-02-22 17:47:24 --> URI Class Initialized
INFO - 2018-02-22 17:47:24 --> Router Class Initialized
INFO - 2018-02-22 17:47:24 --> Output Class Initialized
INFO - 2018-02-22 17:47:24 --> Security Class Initialized
DEBUG - 2018-02-22 17:47:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-22 17:47:24 --> Input Class Initialized
INFO - 2018-02-22 17:47:24 --> Language Class Initialized
INFO - 2018-02-22 17:47:25 --> Loader Class Initialized
INFO - 2018-02-22 17:47:25 --> Helper loaded: url_helper
INFO - 2018-02-22 17:47:25 --> Helper loaded: file_helper
INFO - 2018-02-22 17:47:25 --> Helper loaded: email_helper
INFO - 2018-02-22 17:47:25 --> Helper loaded: common_helper
INFO - 2018-02-22 17:47:25 --> Database Driver Class Initialized
DEBUG - 2018-02-22 17:47:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-22 17:47:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-22 17:47:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-22 17:47:25 --> Pagination Class Initialized
INFO - 2018-02-22 17:47:25 --> Helper loaded: form_helper
INFO - 2018-02-22 17:47:25 --> Form Validation Class Initialized
INFO - 2018-02-22 17:47:25 --> Model Class Initialized
INFO - 2018-02-22 17:47:25 --> Controller Class Initialized
INFO - 2018-02-22 17:47:25 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-22 17:47:25 --> Model Class Initialized
INFO - 2018-02-22 17:47:25 --> Model Class Initialized
INFO - 2018-02-22 17:47:25 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-22 17:47:25 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-22 17:47:25 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-22 17:47:25 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-22 17:47:25 --> File loaded: /var/www/html/project/radio/application/views/subcategory/add_edit.php
INFO - 2018-02-22 17:47:25 --> Final output sent to browser
DEBUG - 2018-02-22 17:47:25 --> Total execution time: 0.0117
INFO - 2018-02-22 17:47:35 --> Config Class Initialized
INFO - 2018-02-22 17:47:35 --> Hooks Class Initialized
DEBUG - 2018-02-22 17:47:35 --> UTF-8 Support Enabled
INFO - 2018-02-22 17:47:35 --> Utf8 Class Initialized
INFO - 2018-02-22 17:47:35 --> URI Class Initialized
INFO - 2018-02-22 17:47:35 --> Router Class Initialized
INFO - 2018-02-22 17:47:35 --> Output Class Initialized
INFO - 2018-02-22 17:47:35 --> Security Class Initialized
DEBUG - 2018-02-22 17:47:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-22 17:47:35 --> Input Class Initialized
INFO - 2018-02-22 17:47:35 --> Language Class Initialized
INFO - 2018-02-22 17:47:35 --> Loader Class Initialized
INFO - 2018-02-22 17:47:35 --> Helper loaded: url_helper
INFO - 2018-02-22 17:47:35 --> Helper loaded: file_helper
INFO - 2018-02-22 17:47:35 --> Helper loaded: email_helper
INFO - 2018-02-22 17:47:35 --> Helper loaded: common_helper
INFO - 2018-02-22 17:47:35 --> Database Driver Class Initialized
DEBUG - 2018-02-22 17:47:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-22 17:47:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-22 17:47:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-22 17:47:35 --> Pagination Class Initialized
INFO - 2018-02-22 17:47:35 --> Helper loaded: form_helper
INFO - 2018-02-22 17:47:35 --> Form Validation Class Initialized
INFO - 2018-02-22 17:47:35 --> Model Class Initialized
INFO - 2018-02-22 17:47:35 --> Controller Class Initialized
INFO - 2018-02-22 17:47:35 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-22 17:47:35 --> Model Class Initialized
INFO - 2018-02-22 17:47:35 --> Model Class Initialized
INFO - 2018-02-22 17:47:35 --> Config Class Initialized
INFO - 2018-02-22 17:47:35 --> Hooks Class Initialized
DEBUG - 2018-02-22 17:47:35 --> UTF-8 Support Enabled
INFO - 2018-02-22 17:47:35 --> Utf8 Class Initialized
INFO - 2018-02-22 17:47:35 --> URI Class Initialized
INFO - 2018-02-22 17:47:35 --> Router Class Initialized
INFO - 2018-02-22 17:47:35 --> Output Class Initialized
INFO - 2018-02-22 17:47:35 --> Security Class Initialized
DEBUG - 2018-02-22 17:47:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-22 17:47:35 --> Input Class Initialized
INFO - 2018-02-22 17:47:35 --> Language Class Initialized
INFO - 2018-02-22 17:47:35 --> Loader Class Initialized
INFO - 2018-02-22 17:47:35 --> Helper loaded: url_helper
INFO - 2018-02-22 17:47:35 --> Helper loaded: file_helper
INFO - 2018-02-22 17:47:35 --> Helper loaded: email_helper
INFO - 2018-02-22 17:47:35 --> Helper loaded: common_helper
INFO - 2018-02-22 17:47:35 --> Database Driver Class Initialized
DEBUG - 2018-02-22 17:47:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-22 17:47:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-22 17:47:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-22 17:47:35 --> Pagination Class Initialized
INFO - 2018-02-22 17:47:35 --> Helper loaded: form_helper
INFO - 2018-02-22 17:47:35 --> Form Validation Class Initialized
INFO - 2018-02-22 17:47:35 --> Model Class Initialized
INFO - 2018-02-22 17:47:35 --> Controller Class Initialized
INFO - 2018-02-22 17:47:35 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-22 17:47:35 --> Model Class Initialized
INFO - 2018-02-22 17:47:35 --> Model Class Initialized
DEBUG - 2018-02-22 17:47:35 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-22 17:47:35 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-02-22 17:47:35 --> Config Class Initialized
INFO - 2018-02-22 17:47:35 --> Hooks Class Initialized
DEBUG - 2018-02-22 17:47:35 --> UTF-8 Support Enabled
INFO - 2018-02-22 17:47:35 --> Utf8 Class Initialized
INFO - 2018-02-22 17:47:35 --> URI Class Initialized
INFO - 2018-02-22 17:47:35 --> Router Class Initialized
INFO - 2018-02-22 17:47:35 --> Output Class Initialized
INFO - 2018-02-22 17:47:35 --> Security Class Initialized
DEBUG - 2018-02-22 17:47:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-22 17:47:35 --> Input Class Initialized
INFO - 2018-02-22 17:47:35 --> Language Class Initialized
INFO - 2018-02-22 17:47:35 --> Loader Class Initialized
INFO - 2018-02-22 17:47:35 --> Helper loaded: url_helper
INFO - 2018-02-22 17:47:35 --> Helper loaded: file_helper
INFO - 2018-02-22 17:47:35 --> Helper loaded: email_helper
INFO - 2018-02-22 17:47:35 --> Helper loaded: common_helper
INFO - 2018-02-22 17:47:35 --> Database Driver Class Initialized
DEBUG - 2018-02-22 17:47:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-22 17:47:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-22 17:47:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-22 17:47:35 --> Pagination Class Initialized
INFO - 2018-02-22 17:47:35 --> Helper loaded: form_helper
INFO - 2018-02-22 17:47:35 --> Form Validation Class Initialized
INFO - 2018-02-22 17:47:35 --> Model Class Initialized
INFO - 2018-02-22 17:47:35 --> Controller Class Initialized
INFO - 2018-02-22 17:47:35 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-22 17:47:35 --> Model Class Initialized
INFO - 2018-02-22 17:47:35 --> Model Class Initialized
INFO - 2018-02-22 17:47:35 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-22 17:47:35 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-22 17:47:35 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-22 17:47:35 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-22 17:47:35 --> File loaded: /var/www/html/project/radio/application/views/subcategory/index.php
INFO - 2018-02-22 17:47:35 --> Final output sent to browser
DEBUG - 2018-02-22 17:47:35 --> Total execution time: 0.0043
INFO - 2018-02-22 17:47:54 --> Config Class Initialized
INFO - 2018-02-22 17:47:54 --> Hooks Class Initialized
DEBUG - 2018-02-22 17:47:54 --> UTF-8 Support Enabled
INFO - 2018-02-22 17:47:54 --> Utf8 Class Initialized
INFO - 2018-02-22 17:47:54 --> URI Class Initialized
INFO - 2018-02-22 17:47:54 --> Router Class Initialized
INFO - 2018-02-22 17:47:54 --> Output Class Initialized
INFO - 2018-02-22 17:47:54 --> Security Class Initialized
DEBUG - 2018-02-22 17:47:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-22 17:47:54 --> Input Class Initialized
INFO - 2018-02-22 17:47:54 --> Language Class Initialized
INFO - 2018-02-22 17:47:54 --> Loader Class Initialized
INFO - 2018-02-22 17:47:54 --> Helper loaded: url_helper
INFO - 2018-02-22 17:47:54 --> Helper loaded: file_helper
INFO - 2018-02-22 17:47:54 --> Helper loaded: email_helper
INFO - 2018-02-22 17:47:54 --> Helper loaded: common_helper
INFO - 2018-02-22 17:47:54 --> Database Driver Class Initialized
DEBUG - 2018-02-22 17:47:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-22 17:47:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-22 17:47:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-22 17:47:54 --> Pagination Class Initialized
INFO - 2018-02-22 17:47:54 --> Helper loaded: form_helper
INFO - 2018-02-22 17:47:54 --> Form Validation Class Initialized
INFO - 2018-02-22 17:47:54 --> Model Class Initialized
INFO - 2018-02-22 17:47:54 --> Controller Class Initialized
DEBUG - 2018-02-22 17:47:54 --> Config file loaded: /var/www/html/project/radio/application/config/rest.php
INFO - 2018-02-22 17:47:54 --> Helper loaded: inflector_helper
INFO - 2018-02-22 17:47:54 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-22 17:47:54 --> Model Class Initialized
INFO - 2018-02-22 17:47:54 --> Model Class Initialized
INFO - 2018-02-22 17:47:54 --> Model Class Initialized
INFO - 2018-02-22 17:47:54 --> Model Class Initialized
INFO - 2018-02-22 17:47:54 --> Model Class Initialized
INFO - 2018-02-22 17:47:54 --> Model Class Initialized
INFO - 2018-02-22 17:47:54 --> Final output sent to browser
DEBUG - 2018-02-22 17:47:54 --> Total execution time: 0.0118
INFO - 2018-02-22 17:48:32 --> Config Class Initialized
INFO - 2018-02-22 17:48:32 --> Hooks Class Initialized
DEBUG - 2018-02-22 17:48:32 --> UTF-8 Support Enabled
INFO - 2018-02-22 17:48:32 --> Utf8 Class Initialized
INFO - 2018-02-22 17:48:32 --> URI Class Initialized
INFO - 2018-02-22 17:48:32 --> Router Class Initialized
INFO - 2018-02-22 17:48:32 --> Output Class Initialized
INFO - 2018-02-22 17:48:32 --> Security Class Initialized
DEBUG - 2018-02-22 17:48:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-22 17:48:32 --> Input Class Initialized
INFO - 2018-02-22 17:48:32 --> Language Class Initialized
INFO - 2018-02-22 17:48:32 --> Loader Class Initialized
INFO - 2018-02-22 17:48:32 --> Helper loaded: url_helper
INFO - 2018-02-22 17:48:32 --> Helper loaded: file_helper
INFO - 2018-02-22 17:48:32 --> Helper loaded: email_helper
INFO - 2018-02-22 17:48:32 --> Helper loaded: common_helper
INFO - 2018-02-22 17:48:32 --> Database Driver Class Initialized
DEBUG - 2018-02-22 17:48:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-22 17:48:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-22 17:48:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-22 17:48:32 --> Pagination Class Initialized
INFO - 2018-02-22 17:48:32 --> Helper loaded: form_helper
INFO - 2018-02-22 17:48:32 --> Form Validation Class Initialized
INFO - 2018-02-22 17:48:32 --> Model Class Initialized
INFO - 2018-02-22 17:48:32 --> Controller Class Initialized
DEBUG - 2018-02-22 17:48:32 --> Config file loaded: /var/www/html/project/radio/application/config/rest.php
INFO - 2018-02-22 17:48:32 --> Helper loaded: inflector_helper
INFO - 2018-02-22 17:48:32 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-22 17:48:32 --> Model Class Initialized
INFO - 2018-02-22 17:48:32 --> Model Class Initialized
INFO - 2018-02-22 17:48:32 --> Model Class Initialized
INFO - 2018-02-22 17:48:32 --> Model Class Initialized
INFO - 2018-02-22 17:48:32 --> Model Class Initialized
INFO - 2018-02-22 17:48:32 --> Model Class Initialized
INFO - 2018-02-22 17:48:32 --> Final output sent to browser
DEBUG - 2018-02-22 17:48:32 --> Total execution time: 0.0113
INFO - 2018-02-22 17:48:40 --> Config Class Initialized
INFO - 2018-02-22 17:48:40 --> Hooks Class Initialized
DEBUG - 2018-02-22 17:48:40 --> UTF-8 Support Enabled
INFO - 2018-02-22 17:48:40 --> Utf8 Class Initialized
INFO - 2018-02-22 17:48:40 --> URI Class Initialized
INFO - 2018-02-22 17:48:40 --> Router Class Initialized
INFO - 2018-02-22 17:48:40 --> Output Class Initialized
INFO - 2018-02-22 17:48:40 --> Security Class Initialized
DEBUG - 2018-02-22 17:48:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-22 17:48:40 --> Input Class Initialized
INFO - 2018-02-22 17:48:40 --> Language Class Initialized
INFO - 2018-02-22 17:48:40 --> Loader Class Initialized
INFO - 2018-02-22 17:48:40 --> Helper loaded: url_helper
INFO - 2018-02-22 17:48:40 --> Helper loaded: file_helper
INFO - 2018-02-22 17:48:40 --> Helper loaded: email_helper
INFO - 2018-02-22 17:48:40 --> Helper loaded: common_helper
INFO - 2018-02-22 17:48:40 --> Database Driver Class Initialized
DEBUG - 2018-02-22 17:48:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-22 17:48:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-22 17:48:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-22 17:48:40 --> Pagination Class Initialized
INFO - 2018-02-22 17:48:40 --> Helper loaded: form_helper
INFO - 2018-02-22 17:48:40 --> Form Validation Class Initialized
INFO - 2018-02-22 17:48:40 --> Model Class Initialized
INFO - 2018-02-22 17:48:40 --> Controller Class Initialized
INFO - 2018-02-22 17:48:40 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-22 17:48:40 --> Model Class Initialized
INFO - 2018-02-22 17:48:40 --> Model Class Initialized
INFO - 2018-02-22 17:48:40 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-22 17:48:40 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-22 17:48:40 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-22 17:48:40 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-22 17:48:40 --> File loaded: /var/www/html/project/radio/application/views/subcategory/add_edit.php
INFO - 2018-02-22 17:48:40 --> Final output sent to browser
DEBUG - 2018-02-22 17:48:40 --> Total execution time: 0.0062
INFO - 2018-02-22 17:48:49 --> Config Class Initialized
INFO - 2018-02-22 17:48:49 --> Hooks Class Initialized
DEBUG - 2018-02-22 17:48:49 --> UTF-8 Support Enabled
INFO - 2018-02-22 17:48:49 --> Utf8 Class Initialized
INFO - 2018-02-22 17:48:49 --> URI Class Initialized
INFO - 2018-02-22 17:48:49 --> Router Class Initialized
INFO - 2018-02-22 17:48:49 --> Output Class Initialized
INFO - 2018-02-22 17:48:49 --> Security Class Initialized
DEBUG - 2018-02-22 17:48:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-22 17:48:49 --> Input Class Initialized
INFO - 2018-02-22 17:48:49 --> Language Class Initialized
INFO - 2018-02-22 17:48:49 --> Loader Class Initialized
INFO - 2018-02-22 17:48:49 --> Helper loaded: url_helper
INFO - 2018-02-22 17:48:49 --> Helper loaded: file_helper
INFO - 2018-02-22 17:48:49 --> Helper loaded: email_helper
INFO - 2018-02-22 17:48:49 --> Helper loaded: common_helper
INFO - 2018-02-22 17:48:49 --> Database Driver Class Initialized
DEBUG - 2018-02-22 17:48:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-22 17:48:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-22 17:48:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-22 17:48:49 --> Pagination Class Initialized
INFO - 2018-02-22 17:48:49 --> Helper loaded: form_helper
INFO - 2018-02-22 17:48:49 --> Form Validation Class Initialized
INFO - 2018-02-22 17:48:49 --> Model Class Initialized
INFO - 2018-02-22 17:48:49 --> Controller Class Initialized
INFO - 2018-02-22 17:48:49 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-22 17:48:49 --> Model Class Initialized
INFO - 2018-02-22 17:48:49 --> Model Class Initialized
INFO - 2018-02-22 17:48:49 --> Config Class Initialized
INFO - 2018-02-22 17:48:49 --> Hooks Class Initialized
DEBUG - 2018-02-22 17:48:49 --> UTF-8 Support Enabled
INFO - 2018-02-22 17:48:49 --> Utf8 Class Initialized
INFO - 2018-02-22 17:48:49 --> URI Class Initialized
INFO - 2018-02-22 17:48:49 --> Router Class Initialized
INFO - 2018-02-22 17:48:49 --> Output Class Initialized
INFO - 2018-02-22 17:48:49 --> Security Class Initialized
DEBUG - 2018-02-22 17:48:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-22 17:48:49 --> Input Class Initialized
INFO - 2018-02-22 17:48:49 --> Language Class Initialized
INFO - 2018-02-22 17:48:49 --> Loader Class Initialized
INFO - 2018-02-22 17:48:49 --> Helper loaded: url_helper
INFO - 2018-02-22 17:48:49 --> Helper loaded: file_helper
INFO - 2018-02-22 17:48:49 --> Helper loaded: email_helper
INFO - 2018-02-22 17:48:49 --> Helper loaded: common_helper
INFO - 2018-02-22 17:48:49 --> Database Driver Class Initialized
DEBUG - 2018-02-22 17:48:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-22 17:48:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-22 17:48:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-22 17:48:49 --> Pagination Class Initialized
INFO - 2018-02-22 17:48:49 --> Helper loaded: form_helper
INFO - 2018-02-22 17:48:49 --> Form Validation Class Initialized
INFO - 2018-02-22 17:48:49 --> Model Class Initialized
INFO - 2018-02-22 17:48:49 --> Controller Class Initialized
INFO - 2018-02-22 17:48:49 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-22 17:48:49 --> Model Class Initialized
INFO - 2018-02-22 17:48:49 --> Model Class Initialized
DEBUG - 2018-02-22 17:48:49 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-22 17:48:49 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-02-22 17:48:49 --> Config Class Initialized
INFO - 2018-02-22 17:48:49 --> Hooks Class Initialized
DEBUG - 2018-02-22 17:48:49 --> UTF-8 Support Enabled
INFO - 2018-02-22 17:48:49 --> Utf8 Class Initialized
INFO - 2018-02-22 17:48:49 --> URI Class Initialized
INFO - 2018-02-22 17:48:49 --> Router Class Initialized
INFO - 2018-02-22 17:48:49 --> Output Class Initialized
INFO - 2018-02-22 17:48:49 --> Security Class Initialized
DEBUG - 2018-02-22 17:48:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-22 17:48:49 --> Input Class Initialized
INFO - 2018-02-22 17:48:49 --> Language Class Initialized
INFO - 2018-02-22 17:48:49 --> Loader Class Initialized
INFO - 2018-02-22 17:48:49 --> Helper loaded: url_helper
INFO - 2018-02-22 17:48:49 --> Helper loaded: file_helper
INFO - 2018-02-22 17:48:49 --> Helper loaded: email_helper
INFO - 2018-02-22 17:48:49 --> Helper loaded: common_helper
INFO - 2018-02-22 17:48:49 --> Database Driver Class Initialized
DEBUG - 2018-02-22 17:48:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-22 17:48:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-22 17:48:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-22 17:48:49 --> Pagination Class Initialized
INFO - 2018-02-22 17:48:49 --> Helper loaded: form_helper
INFO - 2018-02-22 17:48:49 --> Form Validation Class Initialized
INFO - 2018-02-22 17:48:49 --> Model Class Initialized
INFO - 2018-02-22 17:48:49 --> Controller Class Initialized
INFO - 2018-02-22 17:48:49 --> Language file loaded: language/english/english_lang.php
INFO - 2018-02-22 17:48:49 --> Model Class Initialized
INFO - 2018-02-22 17:48:49 --> Model Class Initialized
INFO - 2018-02-22 17:48:49 --> File loaded: /var/www/html/project/radio/application/views//template/side_bar.php
INFO - 2018-02-22 17:48:49 --> File loaded: /var/www/html/project/radio/application/views//template/header.php
INFO - 2018-02-22 17:48:49 --> File loaded: /var/www/html/project/radio/application/views//template/bread_crumb.php
INFO - 2018-02-22 17:48:49 --> File loaded: /var/www/html/project/radio/application/views//template/footer.php
INFO - 2018-02-22 17:48:49 --> File loaded: /var/www/html/project/radio/application/views/subcategory/index.php
INFO - 2018-02-22 17:48:49 --> Final output sent to browser
DEBUG - 2018-02-22 17:48:49 --> Total execution time: 0.0066
INFO - 2018-02-22 17:48:55 --> Config Class Initialized
INFO - 2018-02-22 17:48:55 --> Hooks Class Initialized
DEBUG - 2018-02-22 17:48:55 --> UTF-8 Support Enabled
INFO - 2018-02-22 17:48:55 --> Utf8 Class Initialized
INFO - 2018-02-22 17:48:55 --> URI Class Initialized
INFO - 2018-02-22 17:48:55 --> Router Class Initialized
INFO - 2018-02-22 17:48:55 --> Output Class Initialized
INFO - 2018-02-22 17:48:55 --> Security Class Initialized
DEBUG - 2018-02-22 17:48:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-22 17:48:55 --> Input Class Initialized
INFO - 2018-02-22 17:48:55 --> Language Class Initialized
INFO - 2018-02-22 17:48:55 --> Loader Class Initialized
INFO - 2018-02-22 17:48:55 --> Helper loaded: url_helper
INFO - 2018-02-22 17:48:55 --> Helper loaded: file_helper
INFO - 2018-02-22 17:48:55 --> Helper loaded: email_helper
INFO - 2018-02-22 17:48:55 --> Helper loaded: common_helper
INFO - 2018-02-22 17:48:55 --> Database Driver Class Initialized
DEBUG - 2018-02-22 17:48:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-22 17:48:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-22 17:48:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-22 17:48:55 --> Pagination Class Initialized
INFO - 2018-02-22 17:48:55 --> Helper loaded: form_helper
INFO - 2018-02-22 17:48:55 --> Form Validation Class Initialized
INFO - 2018-02-22 17:48:55 --> Model Class Initialized
INFO - 2018-02-22 17:48:55 --> Controller Class Initialized
DEBUG - 2018-02-22 17:48:55 --> Config file loaded: /var/www/html/project/radio/application/config/rest.php
INFO - 2018-02-22 17:48:55 --> Helper loaded: inflector_helper
INFO - 2018-02-22 17:48:55 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-22 17:48:55 --> Model Class Initialized
INFO - 2018-02-22 17:48:55 --> Model Class Initialized
INFO - 2018-02-22 17:48:55 --> Model Class Initialized
INFO - 2018-02-22 17:48:55 --> Model Class Initialized
INFO - 2018-02-22 17:48:55 --> Model Class Initialized
INFO - 2018-02-22 17:48:55 --> Model Class Initialized
INFO - 2018-02-22 17:48:55 --> Final output sent to browser
DEBUG - 2018-02-22 17:48:55 --> Total execution time: 0.0095
INFO - 2018-02-22 17:52:52 --> Config Class Initialized
INFO - 2018-02-22 17:52:52 --> Hooks Class Initialized
DEBUG - 2018-02-22 17:52:52 --> UTF-8 Support Enabled
INFO - 2018-02-22 17:52:52 --> Utf8 Class Initialized
INFO - 2018-02-22 17:52:52 --> URI Class Initialized
INFO - 2018-02-22 17:52:52 --> Router Class Initialized
INFO - 2018-02-22 17:52:52 --> Output Class Initialized
INFO - 2018-02-22 17:52:52 --> Security Class Initialized
DEBUG - 2018-02-22 17:52:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-22 17:52:52 --> Input Class Initialized
INFO - 2018-02-22 17:52:52 --> Language Class Initialized
INFO - 2018-02-22 17:52:52 --> Loader Class Initialized
INFO - 2018-02-22 17:52:52 --> Helper loaded: url_helper
INFO - 2018-02-22 17:52:52 --> Helper loaded: file_helper
INFO - 2018-02-22 17:52:52 --> Helper loaded: email_helper
INFO - 2018-02-22 17:52:52 --> Helper loaded: common_helper
INFO - 2018-02-22 17:52:52 --> Database Driver Class Initialized
DEBUG - 2018-02-22 17:52:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-22 17:52:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-22 17:52:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-22 17:52:52 --> Pagination Class Initialized
INFO - 2018-02-22 17:52:52 --> Helper loaded: form_helper
INFO - 2018-02-22 17:52:52 --> Form Validation Class Initialized
INFO - 2018-02-22 17:52:52 --> Model Class Initialized
INFO - 2018-02-22 17:52:52 --> Controller Class Initialized
DEBUG - 2018-02-22 17:52:52 --> Config file loaded: /var/www/html/project/radio/application/config/rest.php
INFO - 2018-02-22 17:52:52 --> Helper loaded: inflector_helper
INFO - 2018-02-22 17:52:52 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-22 17:52:52 --> Model Class Initialized
INFO - 2018-02-22 17:52:52 --> Model Class Initialized
INFO - 2018-02-22 17:52:52 --> Model Class Initialized
INFO - 2018-02-22 17:52:52 --> Model Class Initialized
INFO - 2018-02-22 17:52:52 --> Model Class Initialized
INFO - 2018-02-22 17:52:52 --> Model Class Initialized
INFO - 2018-02-22 17:52:52 --> Final output sent to browser
DEBUG - 2018-02-22 17:52:52 --> Total execution time: 0.0107
INFO - 2018-02-22 17:53:43 --> Config Class Initialized
INFO - 2018-02-22 17:53:43 --> Hooks Class Initialized
DEBUG - 2018-02-22 17:53:43 --> UTF-8 Support Enabled
INFO - 2018-02-22 17:53:43 --> Utf8 Class Initialized
INFO - 2018-02-22 17:53:43 --> URI Class Initialized
INFO - 2018-02-22 17:53:43 --> Router Class Initialized
INFO - 2018-02-22 17:53:43 --> Output Class Initialized
INFO - 2018-02-22 17:53:43 --> Security Class Initialized
DEBUG - 2018-02-22 17:53:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-22 17:53:43 --> Input Class Initialized
INFO - 2018-02-22 17:53:43 --> Language Class Initialized
INFO - 2018-02-22 17:53:43 --> Loader Class Initialized
INFO - 2018-02-22 17:53:43 --> Helper loaded: url_helper
INFO - 2018-02-22 17:53:43 --> Helper loaded: file_helper
INFO - 2018-02-22 17:53:43 --> Helper loaded: email_helper
INFO - 2018-02-22 17:53:43 --> Helper loaded: common_helper
INFO - 2018-02-22 17:53:43 --> Database Driver Class Initialized
DEBUG - 2018-02-22 17:53:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-22 17:53:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-22 17:53:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-22 17:53:43 --> Pagination Class Initialized
INFO - 2018-02-22 17:53:43 --> Helper loaded: form_helper
INFO - 2018-02-22 17:53:43 --> Form Validation Class Initialized
INFO - 2018-02-22 17:53:43 --> Model Class Initialized
INFO - 2018-02-22 17:53:43 --> Controller Class Initialized
DEBUG - 2018-02-22 17:53:43 --> Config file loaded: /var/www/html/project/radio/application/config/rest.php
INFO - 2018-02-22 17:53:43 --> Helper loaded: inflector_helper
INFO - 2018-02-22 17:53:43 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-22 17:53:43 --> Model Class Initialized
INFO - 2018-02-22 17:53:43 --> Model Class Initialized
INFO - 2018-02-22 17:53:43 --> Model Class Initialized
INFO - 2018-02-22 17:53:43 --> Model Class Initialized
INFO - 2018-02-22 17:53:43 --> Model Class Initialized
INFO - 2018-02-22 17:53:43 --> Model Class Initialized
INFO - 2018-02-22 17:53:43 --> Final output sent to browser
DEBUG - 2018-02-22 17:53:43 --> Total execution time: 0.0114
INFO - 2018-02-22 17:56:13 --> Config Class Initialized
INFO - 2018-02-22 17:56:13 --> Hooks Class Initialized
DEBUG - 2018-02-22 17:56:13 --> UTF-8 Support Enabled
INFO - 2018-02-22 17:56:13 --> Utf8 Class Initialized
INFO - 2018-02-22 17:56:13 --> URI Class Initialized
INFO - 2018-02-22 17:56:13 --> Router Class Initialized
INFO - 2018-02-22 17:56:13 --> Output Class Initialized
INFO - 2018-02-22 17:56:13 --> Security Class Initialized
DEBUG - 2018-02-22 17:56:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-22 17:56:13 --> Input Class Initialized
INFO - 2018-02-22 17:56:13 --> Language Class Initialized
INFO - 2018-02-22 17:56:13 --> Loader Class Initialized
INFO - 2018-02-22 17:56:13 --> Helper loaded: url_helper
INFO - 2018-02-22 17:56:13 --> Helper loaded: file_helper
INFO - 2018-02-22 17:56:13 --> Helper loaded: email_helper
INFO - 2018-02-22 17:56:13 --> Helper loaded: common_helper
INFO - 2018-02-22 17:56:13 --> Database Driver Class Initialized
DEBUG - 2018-02-22 17:56:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-22 17:56:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-22 17:56:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-22 17:56:13 --> Pagination Class Initialized
INFO - 2018-02-22 17:56:13 --> Helper loaded: form_helper
INFO - 2018-02-22 17:56:13 --> Form Validation Class Initialized
INFO - 2018-02-22 17:56:13 --> Model Class Initialized
INFO - 2018-02-22 17:56:13 --> Controller Class Initialized
DEBUG - 2018-02-22 17:56:13 --> Config file loaded: /var/www/html/project/radio/application/config/rest.php
INFO - 2018-02-22 17:56:13 --> Helper loaded: inflector_helper
INFO - 2018-02-22 17:56:13 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-22 17:56:13 --> Model Class Initialized
INFO - 2018-02-22 17:56:13 --> Model Class Initialized
INFO - 2018-02-22 17:56:13 --> Model Class Initialized
INFO - 2018-02-22 17:56:13 --> Model Class Initialized
INFO - 2018-02-22 17:56:13 --> Model Class Initialized
INFO - 2018-02-22 17:56:13 --> Model Class Initialized
INFO - 2018-02-22 17:56:13 --> Final output sent to browser
DEBUG - 2018-02-22 17:56:13 --> Total execution time: 0.0108
INFO - 2018-02-22 17:56:33 --> Config Class Initialized
INFO - 2018-02-22 17:56:33 --> Hooks Class Initialized
DEBUG - 2018-02-22 17:56:33 --> UTF-8 Support Enabled
INFO - 2018-02-22 17:56:33 --> Utf8 Class Initialized
INFO - 2018-02-22 17:56:33 --> URI Class Initialized
INFO - 2018-02-22 17:56:33 --> Router Class Initialized
INFO - 2018-02-22 17:56:33 --> Output Class Initialized
INFO - 2018-02-22 17:56:33 --> Security Class Initialized
DEBUG - 2018-02-22 17:56:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-22 17:56:33 --> Input Class Initialized
INFO - 2018-02-22 17:56:33 --> Language Class Initialized
INFO - 2018-02-22 17:56:33 --> Loader Class Initialized
INFO - 2018-02-22 17:56:33 --> Helper loaded: url_helper
INFO - 2018-02-22 17:56:33 --> Helper loaded: file_helper
INFO - 2018-02-22 17:56:33 --> Helper loaded: email_helper
INFO - 2018-02-22 17:56:33 --> Helper loaded: common_helper
INFO - 2018-02-22 17:56:33 --> Database Driver Class Initialized
DEBUG - 2018-02-22 17:56:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-22 17:56:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-22 17:56:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-22 17:56:33 --> Pagination Class Initialized
INFO - 2018-02-22 17:56:33 --> Helper loaded: form_helper
INFO - 2018-02-22 17:56:33 --> Form Validation Class Initialized
INFO - 2018-02-22 17:56:33 --> Model Class Initialized
INFO - 2018-02-22 17:56:33 --> Controller Class Initialized
DEBUG - 2018-02-22 17:56:33 --> Config file loaded: /var/www/html/project/radio/application/config/rest.php
INFO - 2018-02-22 17:56:33 --> Helper loaded: inflector_helper
INFO - 2018-02-22 17:56:33 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-22 17:56:33 --> Model Class Initialized
INFO - 2018-02-22 17:56:33 --> Model Class Initialized
INFO - 2018-02-22 17:56:33 --> Model Class Initialized
INFO - 2018-02-22 17:56:33 --> Model Class Initialized
INFO - 2018-02-22 17:56:33 --> Model Class Initialized
INFO - 2018-02-22 17:56:33 --> Model Class Initialized
INFO - 2018-02-22 17:56:33 --> Final output sent to browser
DEBUG - 2018-02-22 17:56:33 --> Total execution time: 0.0141
INFO - 2018-02-22 18:24:33 --> Config Class Initialized
INFO - 2018-02-22 18:24:33 --> Hooks Class Initialized
DEBUG - 2018-02-22 18:24:33 --> UTF-8 Support Enabled
INFO - 2018-02-22 18:24:33 --> Utf8 Class Initialized
INFO - 2018-02-22 18:24:33 --> URI Class Initialized
INFO - 2018-02-22 18:24:33 --> Router Class Initialized
INFO - 2018-02-22 18:24:33 --> Output Class Initialized
INFO - 2018-02-22 18:24:33 --> Security Class Initialized
DEBUG - 2018-02-22 18:24:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-22 18:24:33 --> Input Class Initialized
INFO - 2018-02-22 18:24:33 --> Language Class Initialized
INFO - 2018-02-22 18:24:33 --> Loader Class Initialized
INFO - 2018-02-22 18:24:33 --> Helper loaded: url_helper
INFO - 2018-02-22 18:24:33 --> Helper loaded: file_helper
INFO - 2018-02-22 18:24:33 --> Helper loaded: email_helper
INFO - 2018-02-22 18:24:33 --> Helper loaded: common_helper
INFO - 2018-02-22 18:24:33 --> Database Driver Class Initialized
DEBUG - 2018-02-22 18:24:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-22 18:24:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-22 18:24:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-22 18:24:33 --> Pagination Class Initialized
INFO - 2018-02-22 18:24:33 --> Helper loaded: form_helper
INFO - 2018-02-22 18:24:33 --> Form Validation Class Initialized
INFO - 2018-02-22 18:24:33 --> Model Class Initialized
INFO - 2018-02-22 18:24:33 --> Controller Class Initialized
DEBUG - 2018-02-22 18:24:33 --> Config file loaded: /var/www/html/project/radio/application/config/rest.php
INFO - 2018-02-22 18:24:33 --> Helper loaded: inflector_helper
INFO - 2018-02-22 18:24:33 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-22 18:24:33 --> Model Class Initialized
INFO - 2018-02-22 18:24:33 --> Model Class Initialized
INFO - 2018-02-22 18:24:33 --> Model Class Initialized
INFO - 2018-02-22 18:24:33 --> Model Class Initialized
INFO - 2018-02-22 18:24:33 --> Model Class Initialized
INFO - 2018-02-22 18:24:33 --> Model Class Initialized
INFO - 2018-02-22 18:24:33 --> Final output sent to browser
DEBUG - 2018-02-22 18:24:33 --> Total execution time: 0.0114

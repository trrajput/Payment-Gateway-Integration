<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2018-02-12 10:49:56 --> Config Class Initialized
INFO - 2018-02-12 10:49:56 --> Hooks Class Initialized
DEBUG - 2018-02-12 10:49:56 --> UTF-8 Support Enabled
INFO - 2018-02-12 10:49:56 --> Utf8 Class Initialized
INFO - 2018-02-12 10:49:56 --> URI Class Initialized
INFO - 2018-02-12 10:49:56 --> Router Class Initialized
INFO - 2018-02-12 10:49:56 --> Output Class Initialized
INFO - 2018-02-12 10:49:56 --> Security Class Initialized
DEBUG - 2018-02-12 10:49:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 10:49:56 --> Input Class Initialized
INFO - 2018-02-12 10:49:56 --> Language Class Initialized
INFO - 2018-02-12 10:49:56 --> Loader Class Initialized
INFO - 2018-02-12 10:49:56 --> Helper loaded: url_helper
INFO - 2018-02-12 10:49:56 --> Helper loaded: file_helper
INFO - 2018-02-12 10:49:56 --> Helper loaded: email_helper
ERROR - 2018-02-12 10:49:56 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC), expecting end of file /var/www/html/project/spamblocker/application/helpers/common_helper.php 254
INFO - 2018-02-12 10:50:22 --> Config Class Initialized
INFO - 2018-02-12 10:50:22 --> Hooks Class Initialized
DEBUG - 2018-02-12 10:50:22 --> UTF-8 Support Enabled
INFO - 2018-02-12 10:50:22 --> Utf8 Class Initialized
INFO - 2018-02-12 10:50:22 --> URI Class Initialized
INFO - 2018-02-12 10:50:22 --> Router Class Initialized
INFO - 2018-02-12 10:50:22 --> Output Class Initialized
INFO - 2018-02-12 10:50:22 --> Security Class Initialized
DEBUG - 2018-02-12 10:50:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 10:50:22 --> Input Class Initialized
INFO - 2018-02-12 10:50:22 --> Language Class Initialized
INFO - 2018-02-12 10:50:22 --> Loader Class Initialized
INFO - 2018-02-12 10:50:22 --> Helper loaded: url_helper
INFO - 2018-02-12 10:50:22 --> Helper loaded: file_helper
INFO - 2018-02-12 10:50:22 --> Helper loaded: email_helper
ERROR - 2018-02-12 10:50:22 --> Severity: error --> Exception: syntax error, unexpected ''host'' (T_CONSTANT_ENCAPSED_STRING), expecting ',' or ')' /var/www/html/project/spamblocker/application/helpers/common_helper.php 256
INFO - 2018-02-12 10:50:53 --> Config Class Initialized
INFO - 2018-02-12 10:50:53 --> Hooks Class Initialized
DEBUG - 2018-02-12 10:50:53 --> UTF-8 Support Enabled
INFO - 2018-02-12 10:50:53 --> Utf8 Class Initialized
INFO - 2018-02-12 10:50:53 --> URI Class Initialized
INFO - 2018-02-12 10:50:53 --> Router Class Initialized
INFO - 2018-02-12 10:50:53 --> Output Class Initialized
INFO - 2018-02-12 10:50:53 --> Security Class Initialized
DEBUG - 2018-02-12 10:50:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 10:50:53 --> Input Class Initialized
INFO - 2018-02-12 10:50:53 --> Language Class Initialized
INFO - 2018-02-12 10:50:53 --> Loader Class Initialized
INFO - 2018-02-12 10:50:53 --> Helper loaded: url_helper
INFO - 2018-02-12 10:50:53 --> Helper loaded: file_helper
INFO - 2018-02-12 10:50:53 --> Helper loaded: email_helper
INFO - 2018-02-12 10:50:53 --> Helper loaded: common_helper
INFO - 2018-02-12 10:50:53 --> Database Driver Class Initialized
DEBUG - 2018-02-12 10:50:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 10:50:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 10:50:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-12 10:50:53 --> Pagination Class Initialized
INFO - 2018-02-12 10:50:53 --> Helper loaded: form_helper
INFO - 2018-02-12 10:50:53 --> Form Validation Class Initialized
INFO - 2018-02-12 10:50:53 --> Model Class Initialized
INFO - 2018-02-12 10:50:53 --> Controller Class Initialized
DEBUG - 2018-02-12 10:50:53 --> Config file loaded: /var/www/html/project/spamblocker/application/config/rest.php
INFO - 2018-02-12 10:50:53 --> Helper loaded: inflector_helper
INFO - 2018-02-12 10:50:53 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-12 10:50:53 --> Model Class Initialized
INFO - 2018-02-12 10:50:53 --> Model Class Initialized
INFO - 2018-02-12 10:51:42 --> Config Class Initialized
INFO - 2018-02-12 10:51:42 --> Hooks Class Initialized
DEBUG - 2018-02-12 10:51:42 --> UTF-8 Support Enabled
INFO - 2018-02-12 10:51:42 --> Utf8 Class Initialized
INFO - 2018-02-12 10:51:42 --> URI Class Initialized
INFO - 2018-02-12 10:51:42 --> Router Class Initialized
INFO - 2018-02-12 10:51:42 --> Output Class Initialized
INFO - 2018-02-12 10:51:42 --> Security Class Initialized
DEBUG - 2018-02-12 10:51:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 10:51:42 --> Input Class Initialized
INFO - 2018-02-12 10:51:42 --> Language Class Initialized
INFO - 2018-02-12 10:51:42 --> Loader Class Initialized
INFO - 2018-02-12 10:51:42 --> Helper loaded: url_helper
INFO - 2018-02-12 10:51:42 --> Helper loaded: file_helper
INFO - 2018-02-12 10:51:42 --> Helper loaded: email_helper
INFO - 2018-02-12 10:51:42 --> Helper loaded: common_helper
INFO - 2018-02-12 10:51:42 --> Database Driver Class Initialized
DEBUG - 2018-02-12 10:51:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 10:51:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 10:51:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-12 10:51:42 --> Pagination Class Initialized
INFO - 2018-02-12 10:51:42 --> Helper loaded: form_helper
INFO - 2018-02-12 10:51:42 --> Form Validation Class Initialized
INFO - 2018-02-12 10:51:42 --> Model Class Initialized
INFO - 2018-02-12 10:51:42 --> Controller Class Initialized
DEBUG - 2018-02-12 10:51:42 --> Config file loaded: /var/www/html/project/spamblocker/application/config/rest.php
INFO - 2018-02-12 10:51:42 --> Helper loaded: inflector_helper
INFO - 2018-02-12 10:51:42 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-12 10:51:42 --> Model Class Initialized
INFO - 2018-02-12 10:51:42 --> Model Class Initialized
INFO - 2018-02-12 10:54:06 --> Config Class Initialized
INFO - 2018-02-12 10:54:06 --> Hooks Class Initialized
DEBUG - 2018-02-12 10:54:06 --> UTF-8 Support Enabled
INFO - 2018-02-12 10:54:06 --> Utf8 Class Initialized
INFO - 2018-02-12 10:54:06 --> URI Class Initialized
INFO - 2018-02-12 10:54:06 --> Router Class Initialized
INFO - 2018-02-12 10:54:06 --> Output Class Initialized
INFO - 2018-02-12 10:54:06 --> Security Class Initialized
DEBUG - 2018-02-12 10:54:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 10:54:06 --> Input Class Initialized
INFO - 2018-02-12 10:54:06 --> Language Class Initialized
INFO - 2018-02-12 10:54:06 --> Loader Class Initialized
INFO - 2018-02-12 10:54:06 --> Helper loaded: url_helper
INFO - 2018-02-12 10:54:06 --> Helper loaded: file_helper
INFO - 2018-02-12 10:54:06 --> Helper loaded: email_helper
INFO - 2018-02-12 10:54:06 --> Helper loaded: common_helper
INFO - 2018-02-12 10:54:06 --> Database Driver Class Initialized
DEBUG - 2018-02-12 10:54:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 10:54:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 10:54:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-12 10:54:06 --> Pagination Class Initialized
INFO - 2018-02-12 10:54:06 --> Helper loaded: form_helper
INFO - 2018-02-12 10:54:06 --> Form Validation Class Initialized
INFO - 2018-02-12 10:54:06 --> Model Class Initialized
INFO - 2018-02-12 10:54:06 --> Controller Class Initialized
DEBUG - 2018-02-12 10:54:06 --> Config file loaded: /var/www/html/project/spamblocker/application/config/rest.php
INFO - 2018-02-12 10:54:06 --> Helper loaded: inflector_helper
INFO - 2018-02-12 10:54:06 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-12 10:54:06 --> Model Class Initialized
INFO - 2018-02-12 10:54:06 --> Model Class Initialized
INFO - 2018-02-12 10:58:19 --> Config Class Initialized
INFO - 2018-02-12 10:58:19 --> Hooks Class Initialized
DEBUG - 2018-02-12 10:58:19 --> UTF-8 Support Enabled
INFO - 2018-02-12 10:58:19 --> Utf8 Class Initialized
INFO - 2018-02-12 10:58:19 --> URI Class Initialized
INFO - 2018-02-12 10:58:19 --> Router Class Initialized
INFO - 2018-02-12 10:58:19 --> Output Class Initialized
INFO - 2018-02-12 10:58:19 --> Security Class Initialized
DEBUG - 2018-02-12 10:58:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 10:58:19 --> Input Class Initialized
INFO - 2018-02-12 10:58:19 --> Language Class Initialized
INFO - 2018-02-12 10:58:19 --> Loader Class Initialized
INFO - 2018-02-12 10:58:19 --> Helper loaded: url_helper
INFO - 2018-02-12 10:58:19 --> Helper loaded: file_helper
INFO - 2018-02-12 10:58:19 --> Helper loaded: email_helper
INFO - 2018-02-12 10:58:19 --> Helper loaded: common_helper
INFO - 2018-02-12 10:58:19 --> Database Driver Class Initialized
DEBUG - 2018-02-12 10:58:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 10:58:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 10:58:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-12 10:58:19 --> Pagination Class Initialized
INFO - 2018-02-12 10:58:19 --> Helper loaded: form_helper
INFO - 2018-02-12 10:58:19 --> Form Validation Class Initialized
INFO - 2018-02-12 10:58:19 --> Model Class Initialized
INFO - 2018-02-12 10:58:19 --> Controller Class Initialized
DEBUG - 2018-02-12 10:58:19 --> Config file loaded: /var/www/html/project/spamblocker/application/config/rest.php
INFO - 2018-02-12 10:58:19 --> Helper loaded: inflector_helper
INFO - 2018-02-12 10:58:19 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-12 10:58:19 --> Model Class Initialized
INFO - 2018-02-12 10:58:19 --> Model Class Initialized
INFO - 2018-02-12 10:58:19 --> Final output sent to browser
DEBUG - 2018-02-12 10:58:19 --> Total execution time: 0.0553
INFO - 2018-02-12 10:58:19 --> Config Class Initialized
INFO - 2018-02-12 10:58:19 --> Hooks Class Initialized
DEBUG - 2018-02-12 10:58:19 --> UTF-8 Support Enabled
INFO - 2018-02-12 10:58:19 --> Utf8 Class Initialized
INFO - 2018-02-12 10:58:19 --> URI Class Initialized
INFO - 2018-02-12 10:58:19 --> Router Class Initialized
INFO - 2018-02-12 10:58:19 --> Output Class Initialized
INFO - 2018-02-12 10:58:19 --> Security Class Initialized
DEBUG - 2018-02-12 10:58:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 10:58:19 --> Input Class Initialized
INFO - 2018-02-12 10:58:19 --> Language Class Initialized
INFO - 2018-02-12 10:58:19 --> Loader Class Initialized
INFO - 2018-02-12 10:58:19 --> Helper loaded: url_helper
INFO - 2018-02-12 10:58:19 --> Helper loaded: file_helper
INFO - 2018-02-12 10:58:19 --> Helper loaded: email_helper
INFO - 2018-02-12 10:58:19 --> Helper loaded: common_helper
INFO - 2018-02-12 10:58:19 --> Database Driver Class Initialized
DEBUG - 2018-02-12 10:58:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 10:58:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 10:58:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-12 10:58:19 --> Pagination Class Initialized
INFO - 2018-02-12 10:58:19 --> Helper loaded: form_helper
INFO - 2018-02-12 10:58:19 --> Form Validation Class Initialized
INFO - 2018-02-12 10:58:19 --> Model Class Initialized
INFO - 2018-02-12 10:58:19 --> Controller Class Initialized
DEBUG - 2018-02-12 10:58:19 --> Config file loaded: /var/www/html/project/spamblocker/application/config/rest.php
INFO - 2018-02-12 10:58:19 --> Helper loaded: inflector_helper
INFO - 2018-02-12 10:58:19 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-12 10:58:19 --> Model Class Initialized
INFO - 2018-02-12 10:58:19 --> Model Class Initialized
INFO - 2018-02-12 10:58:19 --> Final output sent to browser
DEBUG - 2018-02-12 10:58:19 --> Total execution time: 0.0066
INFO - 2018-02-12 11:00:58 --> Config Class Initialized
INFO - 2018-02-12 11:00:58 --> Hooks Class Initialized
DEBUG - 2018-02-12 11:00:58 --> UTF-8 Support Enabled
INFO - 2018-02-12 11:00:58 --> Utf8 Class Initialized
INFO - 2018-02-12 11:00:58 --> URI Class Initialized
INFO - 2018-02-12 11:00:58 --> Router Class Initialized
INFO - 2018-02-12 11:00:58 --> Output Class Initialized
INFO - 2018-02-12 11:00:58 --> Security Class Initialized
DEBUG - 2018-02-12 11:00:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 11:00:58 --> Input Class Initialized
INFO - 2018-02-12 11:00:58 --> Language Class Initialized
INFO - 2018-02-12 11:00:58 --> Loader Class Initialized
INFO - 2018-02-12 11:00:58 --> Helper loaded: url_helper
INFO - 2018-02-12 11:00:58 --> Helper loaded: file_helper
INFO - 2018-02-12 11:00:58 --> Helper loaded: email_helper
INFO - 2018-02-12 11:00:58 --> Helper loaded: common_helper
INFO - 2018-02-12 11:00:58 --> Database Driver Class Initialized
DEBUG - 2018-02-12 11:00:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 11:00:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 11:00:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-12 11:00:58 --> Pagination Class Initialized
INFO - 2018-02-12 11:00:58 --> Helper loaded: form_helper
INFO - 2018-02-12 11:00:58 --> Form Validation Class Initialized
INFO - 2018-02-12 11:00:58 --> Model Class Initialized
INFO - 2018-02-12 11:00:58 --> Controller Class Initialized
DEBUG - 2018-02-12 11:00:58 --> Config file loaded: /var/www/html/project/spamblocker/application/config/rest.php
INFO - 2018-02-12 11:00:58 --> Helper loaded: inflector_helper
INFO - 2018-02-12 11:00:58 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-12 11:00:58 --> Model Class Initialized
INFO - 2018-02-12 11:00:58 --> Model Class Initialized
INFO - 2018-02-12 11:00:58 --> Final output sent to browser
DEBUG - 2018-02-12 11:00:58 --> Total execution time: 0.0510
INFO - 2018-02-12 11:00:58 --> Config Class Initialized
INFO - 2018-02-12 11:00:58 --> Hooks Class Initialized
DEBUG - 2018-02-12 11:00:58 --> UTF-8 Support Enabled
INFO - 2018-02-12 11:00:58 --> Utf8 Class Initialized
INFO - 2018-02-12 11:00:58 --> URI Class Initialized
INFO - 2018-02-12 11:00:58 --> Router Class Initialized
INFO - 2018-02-12 11:00:58 --> Output Class Initialized
INFO - 2018-02-12 11:00:58 --> Security Class Initialized
DEBUG - 2018-02-12 11:00:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 11:00:58 --> Input Class Initialized
INFO - 2018-02-12 11:00:58 --> Language Class Initialized
INFO - 2018-02-12 11:00:58 --> Loader Class Initialized
INFO - 2018-02-12 11:00:58 --> Helper loaded: url_helper
INFO - 2018-02-12 11:00:58 --> Helper loaded: file_helper
INFO - 2018-02-12 11:00:58 --> Helper loaded: email_helper
INFO - 2018-02-12 11:00:58 --> Helper loaded: common_helper
INFO - 2018-02-12 11:00:58 --> Database Driver Class Initialized
DEBUG - 2018-02-12 11:00:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 11:00:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 11:00:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-12 11:00:58 --> Pagination Class Initialized
INFO - 2018-02-12 11:00:58 --> Helper loaded: form_helper
INFO - 2018-02-12 11:00:58 --> Form Validation Class Initialized
INFO - 2018-02-12 11:00:58 --> Model Class Initialized
INFO - 2018-02-12 11:00:58 --> Controller Class Initialized
DEBUG - 2018-02-12 11:00:58 --> Config file loaded: /var/www/html/project/spamblocker/application/config/rest.php
INFO - 2018-02-12 11:00:58 --> Helper loaded: inflector_helper
INFO - 2018-02-12 11:00:58 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-12 11:00:58 --> Model Class Initialized
INFO - 2018-02-12 11:00:58 --> Model Class Initialized
INFO - 2018-02-12 11:00:58 --> Final output sent to browser
DEBUG - 2018-02-12 11:00:58 --> Total execution time: 0.0100
INFO - 2018-02-12 11:02:23 --> Config Class Initialized
INFO - 2018-02-12 11:02:23 --> Hooks Class Initialized
DEBUG - 2018-02-12 11:02:23 --> UTF-8 Support Enabled
INFO - 2018-02-12 11:02:23 --> Utf8 Class Initialized
INFO - 2018-02-12 11:02:23 --> URI Class Initialized
INFO - 2018-02-12 11:02:23 --> Router Class Initialized
INFO - 2018-02-12 11:02:23 --> Output Class Initialized
INFO - 2018-02-12 11:02:23 --> Security Class Initialized
DEBUG - 2018-02-12 11:02:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 11:02:23 --> Input Class Initialized
INFO - 2018-02-12 11:02:23 --> Language Class Initialized
INFO - 2018-02-12 11:02:23 --> Loader Class Initialized
INFO - 2018-02-12 11:02:23 --> Helper loaded: url_helper
INFO - 2018-02-12 11:02:23 --> Helper loaded: file_helper
INFO - 2018-02-12 11:02:23 --> Helper loaded: email_helper
INFO - 2018-02-12 11:02:23 --> Helper loaded: common_helper
INFO - 2018-02-12 11:02:23 --> Database Driver Class Initialized
DEBUG - 2018-02-12 11:02:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 11:02:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 11:02:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-12 11:02:23 --> Pagination Class Initialized
INFO - 2018-02-12 11:02:23 --> Helper loaded: form_helper
INFO - 2018-02-12 11:02:23 --> Form Validation Class Initialized
INFO - 2018-02-12 11:02:23 --> Model Class Initialized
INFO - 2018-02-12 11:02:23 --> Controller Class Initialized
DEBUG - 2018-02-12 11:02:23 --> Config file loaded: /var/www/html/project/spamblocker/application/config/rest.php
INFO - 2018-02-12 11:02:23 --> Helper loaded: inflector_helper
INFO - 2018-02-12 11:02:23 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-12 11:02:23 --> Model Class Initialized
INFO - 2018-02-12 11:02:23 --> Model Class Initialized
INFO - 2018-02-12 11:02:39 --> Config Class Initialized
INFO - 2018-02-12 11:02:39 --> Hooks Class Initialized
DEBUG - 2018-02-12 11:02:39 --> UTF-8 Support Enabled
INFO - 2018-02-12 11:02:39 --> Utf8 Class Initialized
INFO - 2018-02-12 11:02:39 --> URI Class Initialized
INFO - 2018-02-12 11:02:39 --> Router Class Initialized
INFO - 2018-02-12 11:02:39 --> Output Class Initialized
INFO - 2018-02-12 11:02:39 --> Security Class Initialized
DEBUG - 2018-02-12 11:02:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 11:02:39 --> Input Class Initialized
INFO - 2018-02-12 11:02:39 --> Language Class Initialized
INFO - 2018-02-12 11:02:39 --> Loader Class Initialized
INFO - 2018-02-12 11:02:39 --> Helper loaded: url_helper
INFO - 2018-02-12 11:02:39 --> Helper loaded: file_helper
INFO - 2018-02-12 11:02:39 --> Helper loaded: email_helper
INFO - 2018-02-12 11:02:39 --> Helper loaded: common_helper
INFO - 2018-02-12 11:02:39 --> Database Driver Class Initialized
DEBUG - 2018-02-12 11:02:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 11:02:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 11:02:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-12 11:02:39 --> Pagination Class Initialized
INFO - 2018-02-12 11:02:39 --> Helper loaded: form_helper
INFO - 2018-02-12 11:02:39 --> Form Validation Class Initialized
INFO - 2018-02-12 11:02:39 --> Model Class Initialized
INFO - 2018-02-12 11:02:39 --> Controller Class Initialized
DEBUG - 2018-02-12 11:02:39 --> Config file loaded: /var/www/html/project/spamblocker/application/config/rest.php
INFO - 2018-02-12 11:02:39 --> Helper loaded: inflector_helper
INFO - 2018-02-12 11:02:39 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-12 11:02:39 --> Model Class Initialized
INFO - 2018-02-12 11:02:39 --> Model Class Initialized
INFO - 2018-02-12 11:02:39 --> Model Class Initialized
INFO - 2018-02-12 11:02:39 --> Email Class Initialized
INFO - 2018-02-12 11:02:40 --> Language file loaded: language/english/email_lang.php
INFO - 2018-02-12 11:02:43 --> Final output sent to browser
DEBUG - 2018-02-12 11:02:43 --> Total execution time: 4.5120
INFO - 2018-02-12 11:04:34 --> Config Class Initialized
INFO - 2018-02-12 11:04:34 --> Hooks Class Initialized
DEBUG - 2018-02-12 11:04:34 --> UTF-8 Support Enabled
INFO - 2018-02-12 11:04:34 --> Utf8 Class Initialized
INFO - 2018-02-12 11:04:34 --> URI Class Initialized
INFO - 2018-02-12 11:04:34 --> Router Class Initialized
INFO - 2018-02-12 11:04:34 --> Output Class Initialized
INFO - 2018-02-12 11:04:34 --> Security Class Initialized
DEBUG - 2018-02-12 11:04:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 11:04:34 --> Input Class Initialized
INFO - 2018-02-12 11:04:34 --> Language Class Initialized
INFO - 2018-02-12 11:04:34 --> Loader Class Initialized
INFO - 2018-02-12 11:04:34 --> Helper loaded: url_helper
INFO - 2018-02-12 11:04:34 --> Helper loaded: file_helper
INFO - 2018-02-12 11:04:34 --> Helper loaded: email_helper
INFO - 2018-02-12 11:04:34 --> Helper loaded: common_helper
INFO - 2018-02-12 11:04:34 --> Database Driver Class Initialized
DEBUG - 2018-02-12 11:04:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 11:04:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 11:04:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-12 11:04:34 --> Pagination Class Initialized
INFO - 2018-02-12 11:04:34 --> Helper loaded: form_helper
INFO - 2018-02-12 11:04:34 --> Form Validation Class Initialized
INFO - 2018-02-12 11:04:34 --> Model Class Initialized
INFO - 2018-02-12 11:04:34 --> Controller Class Initialized
DEBUG - 2018-02-12 11:04:34 --> Config file loaded: /var/www/html/project/spamblocker/application/config/rest.php
INFO - 2018-02-12 11:04:34 --> Helper loaded: inflector_helper
INFO - 2018-02-12 11:04:34 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-12 11:04:34 --> Model Class Initialized
INFO - 2018-02-12 11:04:34 --> Model Class Initialized
INFO - 2018-02-12 11:04:34 --> Final output sent to browser
DEBUG - 2018-02-12 11:04:34 --> Total execution time: 0.0566
INFO - 2018-02-12 11:04:34 --> Config Class Initialized
INFO - 2018-02-12 11:04:34 --> Hooks Class Initialized
DEBUG - 2018-02-12 11:04:34 --> UTF-8 Support Enabled
INFO - 2018-02-12 11:04:34 --> Utf8 Class Initialized
INFO - 2018-02-12 11:04:34 --> URI Class Initialized
INFO - 2018-02-12 11:04:34 --> Router Class Initialized
INFO - 2018-02-12 11:04:34 --> Output Class Initialized
INFO - 2018-02-12 11:04:34 --> Security Class Initialized
DEBUG - 2018-02-12 11:04:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 11:04:34 --> Input Class Initialized
INFO - 2018-02-12 11:04:34 --> Language Class Initialized
INFO - 2018-02-12 11:04:34 --> Loader Class Initialized
INFO - 2018-02-12 11:04:34 --> Helper loaded: url_helper
INFO - 2018-02-12 11:04:34 --> Helper loaded: file_helper
INFO - 2018-02-12 11:04:34 --> Helper loaded: email_helper
INFO - 2018-02-12 11:04:34 --> Helper loaded: common_helper
INFO - 2018-02-12 11:04:34 --> Database Driver Class Initialized
DEBUG - 2018-02-12 11:04:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 11:04:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 11:04:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-12 11:04:34 --> Pagination Class Initialized
INFO - 2018-02-12 11:04:34 --> Helper loaded: form_helper
INFO - 2018-02-12 11:04:34 --> Form Validation Class Initialized
INFO - 2018-02-12 11:04:34 --> Model Class Initialized
INFO - 2018-02-12 11:04:34 --> Controller Class Initialized
DEBUG - 2018-02-12 11:04:34 --> Config file loaded: /var/www/html/project/spamblocker/application/config/rest.php
INFO - 2018-02-12 11:04:34 --> Helper loaded: inflector_helper
INFO - 2018-02-12 11:04:34 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-12 11:04:34 --> Model Class Initialized
INFO - 2018-02-12 11:04:34 --> Model Class Initialized
INFO - 2018-02-12 11:04:34 --> Final output sent to browser
DEBUG - 2018-02-12 11:04:34 --> Total execution time: 0.0074
INFO - 2018-02-12 11:06:16 --> Config Class Initialized
INFO - 2018-02-12 11:06:16 --> Hooks Class Initialized
DEBUG - 2018-02-12 11:06:16 --> UTF-8 Support Enabled
INFO - 2018-02-12 11:06:16 --> Utf8 Class Initialized
INFO - 2018-02-12 11:06:16 --> URI Class Initialized
INFO - 2018-02-12 11:06:16 --> Router Class Initialized
INFO - 2018-02-12 11:06:16 --> Output Class Initialized
INFO - 2018-02-12 11:06:16 --> Security Class Initialized
DEBUG - 2018-02-12 11:06:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 11:06:16 --> Input Class Initialized
INFO - 2018-02-12 11:06:16 --> Language Class Initialized
INFO - 2018-02-12 11:06:16 --> Loader Class Initialized
INFO - 2018-02-12 11:06:16 --> Helper loaded: url_helper
INFO - 2018-02-12 11:06:16 --> Helper loaded: file_helper
INFO - 2018-02-12 11:06:16 --> Helper loaded: email_helper
INFO - 2018-02-12 11:06:16 --> Helper loaded: common_helper
INFO - 2018-02-12 11:06:16 --> Database Driver Class Initialized
DEBUG - 2018-02-12 11:06:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 11:06:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 11:06:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-12 11:06:16 --> Pagination Class Initialized
INFO - 2018-02-12 11:06:16 --> Helper loaded: form_helper
INFO - 2018-02-12 11:06:16 --> Form Validation Class Initialized
INFO - 2018-02-12 11:06:16 --> Model Class Initialized
INFO - 2018-02-12 11:06:16 --> Controller Class Initialized
DEBUG - 2018-02-12 11:06:16 --> Config file loaded: /var/www/html/project/spamblocker/application/config/rest.php
INFO - 2018-02-12 11:06:16 --> Helper loaded: inflector_helper
INFO - 2018-02-12 11:06:16 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-12 11:06:16 --> Model Class Initialized
INFO - 2018-02-12 11:06:16 --> Model Class Initialized
INFO - 2018-02-12 11:06:17 --> Final output sent to browser
DEBUG - 2018-02-12 11:06:17 --> Total execution time: 0.0456
INFO - 2018-02-12 11:06:17 --> Config Class Initialized
INFO - 2018-02-12 11:06:17 --> Hooks Class Initialized
DEBUG - 2018-02-12 11:06:17 --> UTF-8 Support Enabled
INFO - 2018-02-12 11:06:17 --> Utf8 Class Initialized
INFO - 2018-02-12 11:06:17 --> URI Class Initialized
INFO - 2018-02-12 11:06:17 --> Router Class Initialized
INFO - 2018-02-12 11:06:17 --> Output Class Initialized
INFO - 2018-02-12 11:06:17 --> Security Class Initialized
DEBUG - 2018-02-12 11:06:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 11:06:17 --> Input Class Initialized
INFO - 2018-02-12 11:06:17 --> Language Class Initialized
INFO - 2018-02-12 11:06:17 --> Loader Class Initialized
INFO - 2018-02-12 11:06:17 --> Helper loaded: url_helper
INFO - 2018-02-12 11:06:17 --> Helper loaded: file_helper
INFO - 2018-02-12 11:06:17 --> Helper loaded: email_helper
INFO - 2018-02-12 11:06:17 --> Helper loaded: common_helper
INFO - 2018-02-12 11:06:17 --> Database Driver Class Initialized
DEBUG - 2018-02-12 11:06:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 11:06:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 11:06:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-12 11:06:17 --> Pagination Class Initialized
INFO - 2018-02-12 11:06:17 --> Helper loaded: form_helper
INFO - 2018-02-12 11:06:17 --> Form Validation Class Initialized
INFO - 2018-02-12 11:06:17 --> Model Class Initialized
INFO - 2018-02-12 11:06:17 --> Controller Class Initialized
DEBUG - 2018-02-12 11:06:17 --> Config file loaded: /var/www/html/project/spamblocker/application/config/rest.php
INFO - 2018-02-12 11:06:17 --> Helper loaded: inflector_helper
INFO - 2018-02-12 11:06:17 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-12 11:06:17 --> Model Class Initialized
INFO - 2018-02-12 11:06:17 --> Model Class Initialized
INFO - 2018-02-12 11:06:17 --> Final output sent to browser
DEBUG - 2018-02-12 11:06:17 --> Total execution time: 0.0067
INFO - 2018-02-12 11:07:20 --> Config Class Initialized
INFO - 2018-02-12 11:07:20 --> Hooks Class Initialized
DEBUG - 2018-02-12 11:07:20 --> UTF-8 Support Enabled
INFO - 2018-02-12 11:07:20 --> Utf8 Class Initialized
INFO - 2018-02-12 11:07:20 --> URI Class Initialized
INFO - 2018-02-12 11:07:20 --> Router Class Initialized
INFO - 2018-02-12 11:07:20 --> Output Class Initialized
INFO - 2018-02-12 11:07:20 --> Security Class Initialized
DEBUG - 2018-02-12 11:07:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 11:07:20 --> Input Class Initialized
INFO - 2018-02-12 11:07:20 --> Language Class Initialized
INFO - 2018-02-12 11:07:20 --> Loader Class Initialized
INFO - 2018-02-12 11:07:20 --> Helper loaded: url_helper
INFO - 2018-02-12 11:07:20 --> Helper loaded: file_helper
INFO - 2018-02-12 11:07:20 --> Helper loaded: email_helper
INFO - 2018-02-12 11:07:20 --> Helper loaded: common_helper
INFO - 2018-02-12 11:07:20 --> Database Driver Class Initialized
DEBUG - 2018-02-12 11:07:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 11:07:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 11:07:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-12 11:07:20 --> Pagination Class Initialized
INFO - 2018-02-12 11:07:20 --> Helper loaded: form_helper
INFO - 2018-02-12 11:07:20 --> Form Validation Class Initialized
INFO - 2018-02-12 11:07:20 --> Model Class Initialized
INFO - 2018-02-12 11:07:20 --> Controller Class Initialized
DEBUG - 2018-02-12 11:07:20 --> Config file loaded: /var/www/html/project/spamblocker/application/config/rest.php
INFO - 2018-02-12 11:07:20 --> Helper loaded: inflector_helper
INFO - 2018-02-12 11:07:20 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-12 11:07:20 --> Model Class Initialized
INFO - 2018-02-12 11:07:20 --> Model Class Initialized
INFO - 2018-02-12 11:07:47 --> Config Class Initialized
INFO - 2018-02-12 11:07:47 --> Hooks Class Initialized
DEBUG - 2018-02-12 11:07:47 --> UTF-8 Support Enabled
INFO - 2018-02-12 11:07:47 --> Utf8 Class Initialized
INFO - 2018-02-12 11:07:47 --> URI Class Initialized
INFO - 2018-02-12 11:07:47 --> Router Class Initialized
INFO - 2018-02-12 11:07:47 --> Output Class Initialized
INFO - 2018-02-12 11:07:47 --> Security Class Initialized
DEBUG - 2018-02-12 11:07:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 11:07:47 --> Input Class Initialized
INFO - 2018-02-12 11:07:47 --> Language Class Initialized
INFO - 2018-02-12 11:07:47 --> Loader Class Initialized
INFO - 2018-02-12 11:07:47 --> Helper loaded: url_helper
INFO - 2018-02-12 11:07:47 --> Helper loaded: file_helper
INFO - 2018-02-12 11:07:47 --> Helper loaded: email_helper
INFO - 2018-02-12 11:07:47 --> Helper loaded: common_helper
INFO - 2018-02-12 11:07:47 --> Database Driver Class Initialized
DEBUG - 2018-02-12 11:07:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 11:07:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 11:07:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-12 11:07:47 --> Pagination Class Initialized
INFO - 2018-02-12 11:07:47 --> Helper loaded: form_helper
INFO - 2018-02-12 11:07:47 --> Form Validation Class Initialized
INFO - 2018-02-12 11:07:47 --> Model Class Initialized
INFO - 2018-02-12 11:07:47 --> Controller Class Initialized
DEBUG - 2018-02-12 11:07:47 --> Config file loaded: /var/www/html/project/spamblocker/application/config/rest.php
INFO - 2018-02-12 11:07:47 --> Helper loaded: inflector_helper
INFO - 2018-02-12 11:07:47 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-12 11:07:47 --> Model Class Initialized
INFO - 2018-02-12 11:07:47 --> Model Class Initialized
INFO - 2018-02-12 11:08:18 --> Config Class Initialized
INFO - 2018-02-12 11:08:18 --> Hooks Class Initialized
DEBUG - 2018-02-12 11:08:18 --> UTF-8 Support Enabled
INFO - 2018-02-12 11:08:18 --> Utf8 Class Initialized
INFO - 2018-02-12 11:08:18 --> URI Class Initialized
INFO - 2018-02-12 11:08:18 --> Router Class Initialized
INFO - 2018-02-12 11:08:18 --> Output Class Initialized
INFO - 2018-02-12 11:08:18 --> Security Class Initialized
DEBUG - 2018-02-12 11:08:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 11:08:18 --> Input Class Initialized
INFO - 2018-02-12 11:08:18 --> Language Class Initialized
INFO - 2018-02-12 11:08:18 --> Loader Class Initialized
INFO - 2018-02-12 11:08:18 --> Helper loaded: url_helper
INFO - 2018-02-12 11:08:18 --> Helper loaded: file_helper
INFO - 2018-02-12 11:08:18 --> Helper loaded: email_helper
INFO - 2018-02-12 11:08:18 --> Helper loaded: common_helper
INFO - 2018-02-12 11:08:18 --> Database Driver Class Initialized
DEBUG - 2018-02-12 11:08:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 11:08:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 11:08:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-12 11:08:18 --> Pagination Class Initialized
INFO - 2018-02-12 11:08:18 --> Helper loaded: form_helper
INFO - 2018-02-12 11:08:18 --> Form Validation Class Initialized
INFO - 2018-02-12 11:08:18 --> Model Class Initialized
INFO - 2018-02-12 11:08:18 --> Controller Class Initialized
DEBUG - 2018-02-12 11:08:18 --> Config file loaded: /var/www/html/project/spamblocker/application/config/rest.php
INFO - 2018-02-12 11:08:18 --> Helper loaded: inflector_helper
INFO - 2018-02-12 11:08:18 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-12 11:08:18 --> Model Class Initialized
INFO - 2018-02-12 11:08:18 --> Model Class Initialized
INFO - 2018-02-12 11:08:41 --> Config Class Initialized
INFO - 2018-02-12 11:08:41 --> Hooks Class Initialized
DEBUG - 2018-02-12 11:08:41 --> UTF-8 Support Enabled
INFO - 2018-02-12 11:08:41 --> Utf8 Class Initialized
INFO - 2018-02-12 11:08:41 --> URI Class Initialized
INFO - 2018-02-12 11:08:41 --> Router Class Initialized
INFO - 2018-02-12 11:08:41 --> Output Class Initialized
INFO - 2018-02-12 11:08:41 --> Security Class Initialized
DEBUG - 2018-02-12 11:08:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 11:08:41 --> Input Class Initialized
INFO - 2018-02-12 11:08:41 --> Language Class Initialized
INFO - 2018-02-12 11:08:41 --> Loader Class Initialized
INFO - 2018-02-12 11:08:41 --> Helper loaded: url_helper
INFO - 2018-02-12 11:08:41 --> Helper loaded: file_helper
INFO - 2018-02-12 11:08:41 --> Helper loaded: email_helper
INFO - 2018-02-12 11:08:41 --> Helper loaded: common_helper
INFO - 2018-02-12 11:08:41 --> Database Driver Class Initialized
DEBUG - 2018-02-12 11:08:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 11:08:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 11:08:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-12 11:08:41 --> Pagination Class Initialized
INFO - 2018-02-12 11:08:41 --> Helper loaded: form_helper
INFO - 2018-02-12 11:08:41 --> Form Validation Class Initialized
INFO - 2018-02-12 11:08:41 --> Model Class Initialized
INFO - 2018-02-12 11:08:41 --> Controller Class Initialized
DEBUG - 2018-02-12 11:08:41 --> Config file loaded: /var/www/html/project/spamblocker/application/config/rest.php
INFO - 2018-02-12 11:08:41 --> Helper loaded: inflector_helper
INFO - 2018-02-12 11:08:41 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-12 11:08:41 --> Model Class Initialized
INFO - 2018-02-12 11:08:41 --> Model Class Initialized
INFO - 2018-02-12 11:09:03 --> Config Class Initialized
INFO - 2018-02-12 11:09:03 --> Hooks Class Initialized
DEBUG - 2018-02-12 11:09:03 --> UTF-8 Support Enabled
INFO - 2018-02-12 11:09:03 --> Utf8 Class Initialized
INFO - 2018-02-12 11:09:03 --> URI Class Initialized
INFO - 2018-02-12 11:09:03 --> Router Class Initialized
INFO - 2018-02-12 11:09:03 --> Output Class Initialized
INFO - 2018-02-12 11:09:03 --> Security Class Initialized
DEBUG - 2018-02-12 11:09:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 11:09:03 --> Input Class Initialized
INFO - 2018-02-12 11:09:03 --> Language Class Initialized
INFO - 2018-02-12 11:09:03 --> Loader Class Initialized
INFO - 2018-02-12 11:09:03 --> Helper loaded: url_helper
INFO - 2018-02-12 11:09:03 --> Helper loaded: file_helper
INFO - 2018-02-12 11:09:03 --> Helper loaded: email_helper
INFO - 2018-02-12 11:09:03 --> Helper loaded: common_helper
INFO - 2018-02-12 11:09:03 --> Database Driver Class Initialized
DEBUG - 2018-02-12 11:09:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 11:09:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 11:09:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-12 11:09:03 --> Pagination Class Initialized
INFO - 2018-02-12 11:09:03 --> Helper loaded: form_helper
INFO - 2018-02-12 11:09:03 --> Form Validation Class Initialized
INFO - 2018-02-12 11:09:03 --> Model Class Initialized
INFO - 2018-02-12 11:09:03 --> Controller Class Initialized
DEBUG - 2018-02-12 11:09:03 --> Config file loaded: /var/www/html/project/spamblocker/application/config/rest.php
INFO - 2018-02-12 11:09:03 --> Helper loaded: inflector_helper
INFO - 2018-02-12 11:09:03 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-12 11:09:03 --> Model Class Initialized
INFO - 2018-02-12 11:09:03 --> Model Class Initialized
INFO - 2018-02-12 11:10:08 --> Config Class Initialized
INFO - 2018-02-12 11:10:08 --> Hooks Class Initialized
DEBUG - 2018-02-12 11:10:08 --> UTF-8 Support Enabled
INFO - 2018-02-12 11:10:08 --> Utf8 Class Initialized
INFO - 2018-02-12 11:10:08 --> URI Class Initialized
INFO - 2018-02-12 11:10:08 --> Router Class Initialized
INFO - 2018-02-12 11:10:08 --> Output Class Initialized
INFO - 2018-02-12 11:10:08 --> Security Class Initialized
DEBUG - 2018-02-12 11:10:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 11:10:08 --> Input Class Initialized
INFO - 2018-02-12 11:10:08 --> Language Class Initialized
INFO - 2018-02-12 11:10:08 --> Loader Class Initialized
INFO - 2018-02-12 11:10:08 --> Helper loaded: url_helper
INFO - 2018-02-12 11:10:08 --> Helper loaded: file_helper
INFO - 2018-02-12 11:10:08 --> Helper loaded: email_helper
INFO - 2018-02-12 11:10:08 --> Helper loaded: common_helper
INFO - 2018-02-12 11:10:08 --> Database Driver Class Initialized
DEBUG - 2018-02-12 11:10:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 11:10:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 11:10:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-12 11:10:08 --> Pagination Class Initialized
INFO - 2018-02-12 11:10:08 --> Helper loaded: form_helper
INFO - 2018-02-12 11:10:08 --> Form Validation Class Initialized
INFO - 2018-02-12 11:10:08 --> Model Class Initialized
INFO - 2018-02-12 11:10:08 --> Controller Class Initialized
DEBUG - 2018-02-12 11:10:08 --> Config file loaded: /var/www/html/project/spamblocker/application/config/rest.php
INFO - 2018-02-12 11:10:08 --> Helper loaded: inflector_helper
INFO - 2018-02-12 11:10:08 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-12 11:10:08 --> Model Class Initialized
INFO - 2018-02-12 11:10:08 --> Model Class Initialized
INFO - 2018-02-12 11:10:09 --> Final output sent to browser
DEBUG - 2018-02-12 11:10:09 --> Total execution time: 0.0493
INFO - 2018-02-12 11:10:09 --> Config Class Initialized
INFO - 2018-02-12 11:10:09 --> Hooks Class Initialized
DEBUG - 2018-02-12 11:10:09 --> UTF-8 Support Enabled
INFO - 2018-02-12 11:10:09 --> Utf8 Class Initialized
INFO - 2018-02-12 11:10:09 --> URI Class Initialized
INFO - 2018-02-12 11:10:09 --> Router Class Initialized
INFO - 2018-02-12 11:10:09 --> Output Class Initialized
INFO - 2018-02-12 11:10:09 --> Security Class Initialized
DEBUG - 2018-02-12 11:10:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 11:10:09 --> Input Class Initialized
INFO - 2018-02-12 11:10:09 --> Language Class Initialized
INFO - 2018-02-12 11:10:09 --> Loader Class Initialized
INFO - 2018-02-12 11:10:09 --> Helper loaded: url_helper
INFO - 2018-02-12 11:10:09 --> Helper loaded: file_helper
INFO - 2018-02-12 11:10:09 --> Helper loaded: email_helper
INFO - 2018-02-12 11:10:09 --> Helper loaded: common_helper
INFO - 2018-02-12 11:10:09 --> Database Driver Class Initialized
DEBUG - 2018-02-12 11:10:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 11:10:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 11:10:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-12 11:10:09 --> Pagination Class Initialized
INFO - 2018-02-12 11:10:09 --> Helper loaded: form_helper
INFO - 2018-02-12 11:10:09 --> Form Validation Class Initialized
INFO - 2018-02-12 11:10:09 --> Model Class Initialized
INFO - 2018-02-12 11:10:09 --> Controller Class Initialized
DEBUG - 2018-02-12 11:10:09 --> Config file loaded: /var/www/html/project/spamblocker/application/config/rest.php
INFO - 2018-02-12 11:10:09 --> Helper loaded: inflector_helper
INFO - 2018-02-12 11:10:09 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-12 11:10:09 --> Model Class Initialized
INFO - 2018-02-12 11:10:09 --> Model Class Initialized
INFO - 2018-02-12 11:10:09 --> Model Class Initialized
INFO - 2018-02-12 11:10:09 --> Email Class Initialized
INFO - 2018-02-12 11:10:09 --> Language file loaded: language/english/email_lang.php
INFO - 2018-02-12 11:10:11 --> Final output sent to browser
DEBUG - 2018-02-12 11:10:11 --> Total execution time: 1.9985
INFO - 2018-02-12 11:13:06 --> Config Class Initialized
INFO - 2018-02-12 11:13:06 --> Hooks Class Initialized
DEBUG - 2018-02-12 11:13:06 --> UTF-8 Support Enabled
INFO - 2018-02-12 11:13:06 --> Utf8 Class Initialized
INFO - 2018-02-12 11:13:06 --> URI Class Initialized
INFO - 2018-02-12 11:13:06 --> Router Class Initialized
INFO - 2018-02-12 11:13:06 --> Output Class Initialized
INFO - 2018-02-12 11:13:06 --> Security Class Initialized
DEBUG - 2018-02-12 11:13:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 11:13:06 --> Input Class Initialized
INFO - 2018-02-12 11:13:06 --> Language Class Initialized
INFO - 2018-02-12 11:13:06 --> Loader Class Initialized
INFO - 2018-02-12 11:13:06 --> Helper loaded: url_helper
INFO - 2018-02-12 11:13:06 --> Helper loaded: file_helper
INFO - 2018-02-12 11:13:06 --> Helper loaded: email_helper
INFO - 2018-02-12 11:13:06 --> Helper loaded: common_helper
INFO - 2018-02-12 11:13:06 --> Database Driver Class Initialized
DEBUG - 2018-02-12 11:13:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 11:13:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 11:13:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-12 11:13:06 --> Pagination Class Initialized
INFO - 2018-02-12 11:13:06 --> Helper loaded: form_helper
INFO - 2018-02-12 11:13:06 --> Form Validation Class Initialized
INFO - 2018-02-12 11:13:06 --> Model Class Initialized
INFO - 2018-02-12 11:13:06 --> Controller Class Initialized
DEBUG - 2018-02-12 11:13:06 --> Config file loaded: /var/www/html/project/spamblocker/application/config/rest.php
INFO - 2018-02-12 11:13:06 --> Helper loaded: inflector_helper
INFO - 2018-02-12 11:13:06 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-12 11:13:06 --> Model Class Initialized
INFO - 2018-02-12 11:13:06 --> Model Class Initialized
INFO - 2018-02-12 11:13:06 --> Final output sent to browser
DEBUG - 2018-02-12 11:13:06 --> Total execution time: 0.0602
INFO - 2018-02-12 11:13:06 --> Config Class Initialized
INFO - 2018-02-12 11:13:06 --> Hooks Class Initialized
DEBUG - 2018-02-12 11:13:06 --> UTF-8 Support Enabled
INFO - 2018-02-12 11:13:06 --> Utf8 Class Initialized
INFO - 2018-02-12 11:13:06 --> URI Class Initialized
INFO - 2018-02-12 11:13:06 --> Router Class Initialized
INFO - 2018-02-12 11:13:06 --> Output Class Initialized
INFO - 2018-02-12 11:13:06 --> Security Class Initialized
DEBUG - 2018-02-12 11:13:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 11:13:06 --> Input Class Initialized
INFO - 2018-02-12 11:13:06 --> Language Class Initialized
INFO - 2018-02-12 11:13:06 --> Loader Class Initialized
INFO - 2018-02-12 11:13:06 --> Helper loaded: url_helper
INFO - 2018-02-12 11:13:06 --> Helper loaded: file_helper
INFO - 2018-02-12 11:13:06 --> Helper loaded: email_helper
INFO - 2018-02-12 11:13:06 --> Helper loaded: common_helper
INFO - 2018-02-12 11:13:06 --> Database Driver Class Initialized
DEBUG - 2018-02-12 11:13:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 11:13:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 11:13:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-12 11:13:06 --> Pagination Class Initialized
INFO - 2018-02-12 11:13:06 --> Helper loaded: form_helper
INFO - 2018-02-12 11:13:06 --> Form Validation Class Initialized
INFO - 2018-02-12 11:13:06 --> Model Class Initialized
INFO - 2018-02-12 11:13:06 --> Controller Class Initialized
DEBUG - 2018-02-12 11:13:06 --> Config file loaded: /var/www/html/project/spamblocker/application/config/rest.php
INFO - 2018-02-12 11:13:06 --> Helper loaded: inflector_helper
INFO - 2018-02-12 11:13:06 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-12 11:13:06 --> Model Class Initialized
INFO - 2018-02-12 11:13:06 --> Model Class Initialized
INFO - 2018-02-12 11:13:06 --> Model Class Initialized
INFO - 2018-02-12 11:13:06 --> Email Class Initialized
INFO - 2018-02-12 11:13:06 --> Language file loaded: language/english/email_lang.php
INFO - 2018-02-12 11:13:08 --> Final output sent to browser
DEBUG - 2018-02-12 11:13:08 --> Total execution time: 2.2407
INFO - 2018-02-12 11:14:17 --> Config Class Initialized
INFO - 2018-02-12 11:14:17 --> Hooks Class Initialized
DEBUG - 2018-02-12 11:14:17 --> UTF-8 Support Enabled
INFO - 2018-02-12 11:14:17 --> Utf8 Class Initialized
INFO - 2018-02-12 11:14:17 --> URI Class Initialized
INFO - 2018-02-12 11:14:17 --> Router Class Initialized
INFO - 2018-02-12 11:14:17 --> Output Class Initialized
INFO - 2018-02-12 11:14:17 --> Security Class Initialized
DEBUG - 2018-02-12 11:14:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 11:14:17 --> Input Class Initialized
INFO - 2018-02-12 11:14:17 --> Language Class Initialized
INFO - 2018-02-12 11:14:17 --> Loader Class Initialized
INFO - 2018-02-12 11:14:17 --> Helper loaded: url_helper
INFO - 2018-02-12 11:14:17 --> Helper loaded: file_helper
INFO - 2018-02-12 11:14:17 --> Helper loaded: email_helper
INFO - 2018-02-12 11:14:17 --> Helper loaded: common_helper
INFO - 2018-02-12 11:14:17 --> Database Driver Class Initialized
DEBUG - 2018-02-12 11:14:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 11:14:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 11:14:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-12 11:14:17 --> Pagination Class Initialized
INFO - 2018-02-12 11:14:17 --> Helper loaded: form_helper
INFO - 2018-02-12 11:14:17 --> Form Validation Class Initialized
INFO - 2018-02-12 11:14:17 --> Model Class Initialized
INFO - 2018-02-12 11:14:17 --> Controller Class Initialized
DEBUG - 2018-02-12 11:14:17 --> Config file loaded: /var/www/html/project/spamblocker/application/config/rest.php
INFO - 2018-02-12 11:14:17 --> Helper loaded: inflector_helper
INFO - 2018-02-12 11:14:17 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-12 11:14:17 --> Model Class Initialized
INFO - 2018-02-12 11:14:17 --> Model Class Initialized
INFO - 2018-02-12 11:14:17 --> Final output sent to browser
DEBUG - 2018-02-12 11:14:17 --> Total execution time: 0.0395
INFO - 2018-02-12 11:14:17 --> Config Class Initialized
INFO - 2018-02-12 11:14:17 --> Hooks Class Initialized
DEBUG - 2018-02-12 11:14:17 --> UTF-8 Support Enabled
INFO - 2018-02-12 11:14:17 --> Utf8 Class Initialized
INFO - 2018-02-12 11:14:17 --> URI Class Initialized
INFO - 2018-02-12 11:14:17 --> Router Class Initialized
INFO - 2018-02-12 11:14:17 --> Output Class Initialized
INFO - 2018-02-12 11:14:17 --> Security Class Initialized
DEBUG - 2018-02-12 11:14:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 11:14:17 --> Input Class Initialized
INFO - 2018-02-12 11:14:17 --> Language Class Initialized
INFO - 2018-02-12 11:14:17 --> Loader Class Initialized
INFO - 2018-02-12 11:14:17 --> Helper loaded: url_helper
INFO - 2018-02-12 11:14:17 --> Helper loaded: file_helper
INFO - 2018-02-12 11:14:17 --> Helper loaded: email_helper
INFO - 2018-02-12 11:14:17 --> Helper loaded: common_helper
INFO - 2018-02-12 11:14:17 --> Database Driver Class Initialized
DEBUG - 2018-02-12 11:14:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 11:14:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 11:14:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-12 11:14:17 --> Pagination Class Initialized
INFO - 2018-02-12 11:14:17 --> Helper loaded: form_helper
INFO - 2018-02-12 11:14:17 --> Form Validation Class Initialized
INFO - 2018-02-12 11:14:17 --> Model Class Initialized
INFO - 2018-02-12 11:14:17 --> Controller Class Initialized
DEBUG - 2018-02-12 11:14:17 --> Config file loaded: /var/www/html/project/spamblocker/application/config/rest.php
INFO - 2018-02-12 11:14:17 --> Helper loaded: inflector_helper
INFO - 2018-02-12 11:14:17 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-12 11:14:17 --> Model Class Initialized
INFO - 2018-02-12 11:14:17 --> Model Class Initialized
INFO - 2018-02-12 11:14:17 --> Model Class Initialized
INFO - 2018-02-12 11:14:17 --> Email Class Initialized
INFO - 2018-02-12 11:14:18 --> Language file loaded: language/english/email_lang.php
INFO - 2018-02-12 11:14:21 --> Final output sent to browser
DEBUG - 2018-02-12 11:14:21 --> Total execution time: 3.6364
INFO - 2018-02-12 11:22:39 --> Config Class Initialized
INFO - 2018-02-12 11:22:39 --> Hooks Class Initialized
DEBUG - 2018-02-12 11:22:39 --> UTF-8 Support Enabled
INFO - 2018-02-12 11:22:39 --> Utf8 Class Initialized
INFO - 2018-02-12 11:22:39 --> URI Class Initialized
INFO - 2018-02-12 11:22:39 --> Router Class Initialized
INFO - 2018-02-12 11:22:39 --> Output Class Initialized
INFO - 2018-02-12 11:22:39 --> Security Class Initialized
DEBUG - 2018-02-12 11:22:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 11:22:39 --> Input Class Initialized
INFO - 2018-02-12 11:22:39 --> Language Class Initialized
ERROR - 2018-02-12 11:22:39 --> Severity: error --> Exception: syntax error, unexpected '$postfields' (T_VARIABLE) /var/www/html/project/spamblocker/application/controllers/api/Oauth.php 625
INFO - 2018-02-12 11:24:17 --> Config Class Initialized
INFO - 2018-02-12 11:24:17 --> Hooks Class Initialized
DEBUG - 2018-02-12 11:24:17 --> UTF-8 Support Enabled
INFO - 2018-02-12 11:24:17 --> Utf8 Class Initialized
INFO - 2018-02-12 11:24:17 --> URI Class Initialized
INFO - 2018-02-12 11:24:17 --> Router Class Initialized
INFO - 2018-02-12 11:24:17 --> Output Class Initialized
INFO - 2018-02-12 11:24:17 --> Security Class Initialized
DEBUG - 2018-02-12 11:24:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 11:24:17 --> Input Class Initialized
INFO - 2018-02-12 11:24:17 --> Language Class Initialized
ERROR - 2018-02-12 11:24:17 --> Severity: error --> Exception: syntax error, unexpected '$postfields' (T_VARIABLE) /var/www/html/project/spamblocker/application/controllers/api/Oauth.php 626
INFO - 2018-02-12 11:25:37 --> Config Class Initialized
INFO - 2018-02-12 11:25:37 --> Hooks Class Initialized
DEBUG - 2018-02-12 11:25:37 --> UTF-8 Support Enabled
INFO - 2018-02-12 11:25:37 --> Utf8 Class Initialized
INFO - 2018-02-12 11:25:37 --> URI Class Initialized
INFO - 2018-02-12 11:25:37 --> Router Class Initialized
INFO - 2018-02-12 11:25:37 --> Output Class Initialized
INFO - 2018-02-12 11:25:37 --> Security Class Initialized
DEBUG - 2018-02-12 11:25:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 11:25:37 --> Input Class Initialized
INFO - 2018-02-12 11:25:37 --> Language Class Initialized
INFO - 2018-02-12 11:25:37 --> Loader Class Initialized
INFO - 2018-02-12 11:25:37 --> Helper loaded: url_helper
INFO - 2018-02-12 11:25:37 --> Helper loaded: file_helper
INFO - 2018-02-12 11:25:37 --> Helper loaded: email_helper
INFO - 2018-02-12 11:25:37 --> Helper loaded: common_helper
INFO - 2018-02-12 11:25:37 --> Database Driver Class Initialized
DEBUG - 2018-02-12 11:25:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 11:25:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 11:25:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-12 11:25:37 --> Pagination Class Initialized
INFO - 2018-02-12 11:25:37 --> Helper loaded: form_helper
INFO - 2018-02-12 11:25:37 --> Form Validation Class Initialized
INFO - 2018-02-12 11:25:37 --> Model Class Initialized
INFO - 2018-02-12 11:25:37 --> Controller Class Initialized
DEBUG - 2018-02-12 11:25:37 --> Config file loaded: /var/www/html/project/spamblocker/application/config/rest.php
INFO - 2018-02-12 11:25:37 --> Helper loaded: inflector_helper
INFO - 2018-02-12 11:25:37 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-12 11:25:37 --> Model Class Initialized
INFO - 2018-02-12 11:25:37 --> Model Class Initialized
INFO - 2018-02-12 11:26:01 --> Config Class Initialized
INFO - 2018-02-12 11:26:01 --> Hooks Class Initialized
DEBUG - 2018-02-12 11:26:01 --> UTF-8 Support Enabled
INFO - 2018-02-12 11:26:01 --> Utf8 Class Initialized
INFO - 2018-02-12 11:26:01 --> URI Class Initialized
INFO - 2018-02-12 11:26:01 --> Router Class Initialized
INFO - 2018-02-12 11:26:01 --> Output Class Initialized
INFO - 2018-02-12 11:26:01 --> Security Class Initialized
DEBUG - 2018-02-12 11:26:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 11:26:01 --> Input Class Initialized
INFO - 2018-02-12 11:26:01 --> Language Class Initialized
INFO - 2018-02-12 11:26:01 --> Loader Class Initialized
INFO - 2018-02-12 11:26:01 --> Helper loaded: url_helper
INFO - 2018-02-12 11:26:01 --> Helper loaded: file_helper
INFO - 2018-02-12 11:26:01 --> Helper loaded: email_helper
INFO - 2018-02-12 11:26:01 --> Helper loaded: common_helper
INFO - 2018-02-12 11:26:01 --> Database Driver Class Initialized
DEBUG - 2018-02-12 11:26:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 11:26:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 11:26:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-12 11:26:01 --> Pagination Class Initialized
INFO - 2018-02-12 11:26:01 --> Helper loaded: form_helper
INFO - 2018-02-12 11:26:01 --> Form Validation Class Initialized
INFO - 2018-02-12 11:26:01 --> Model Class Initialized
INFO - 2018-02-12 11:26:01 --> Controller Class Initialized
DEBUG - 2018-02-12 11:26:01 --> Config file loaded: /var/www/html/project/spamblocker/application/config/rest.php
INFO - 2018-02-12 11:26:01 --> Helper loaded: inflector_helper
INFO - 2018-02-12 11:26:01 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-12 11:26:01 --> Model Class Initialized
INFO - 2018-02-12 11:26:01 --> Model Class Initialized
INFO - 2018-02-12 11:28:42 --> Config Class Initialized
INFO - 2018-02-12 11:28:42 --> Hooks Class Initialized
DEBUG - 2018-02-12 11:28:42 --> UTF-8 Support Enabled
INFO - 2018-02-12 11:28:42 --> Utf8 Class Initialized
INFO - 2018-02-12 11:28:42 --> URI Class Initialized
INFO - 2018-02-12 11:28:42 --> Router Class Initialized
INFO - 2018-02-12 11:28:42 --> Output Class Initialized
INFO - 2018-02-12 11:28:42 --> Security Class Initialized
DEBUG - 2018-02-12 11:28:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 11:28:42 --> Input Class Initialized
INFO - 2018-02-12 11:28:42 --> Language Class Initialized
INFO - 2018-02-12 11:28:42 --> Loader Class Initialized
INFO - 2018-02-12 11:28:42 --> Helper loaded: url_helper
INFO - 2018-02-12 11:28:42 --> Helper loaded: file_helper
INFO - 2018-02-12 11:28:42 --> Helper loaded: email_helper
INFO - 2018-02-12 11:28:42 --> Helper loaded: common_helper
INFO - 2018-02-12 11:28:42 --> Database Driver Class Initialized
DEBUG - 2018-02-12 11:28:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 11:28:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 11:28:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-12 11:28:42 --> Pagination Class Initialized
INFO - 2018-02-12 11:28:42 --> Helper loaded: form_helper
INFO - 2018-02-12 11:28:42 --> Form Validation Class Initialized
INFO - 2018-02-12 11:28:42 --> Model Class Initialized
INFO - 2018-02-12 11:28:42 --> Controller Class Initialized
DEBUG - 2018-02-12 11:28:42 --> Config file loaded: /var/www/html/project/spamblocker/application/config/rest.php
INFO - 2018-02-12 11:28:42 --> Helper loaded: inflector_helper
INFO - 2018-02-12 11:28:42 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-12 11:28:42 --> Model Class Initialized
INFO - 2018-02-12 11:28:42 --> Model Class Initialized
INFO - 2018-02-12 11:28:42 --> Final output sent to browser
DEBUG - 2018-02-12 11:28:42 --> Total execution time: 0.0411
INFO - 2018-02-12 11:28:42 --> Config Class Initialized
INFO - 2018-02-12 11:28:42 --> Hooks Class Initialized
DEBUG - 2018-02-12 11:28:42 --> UTF-8 Support Enabled
INFO - 2018-02-12 11:28:42 --> Utf8 Class Initialized
INFO - 2018-02-12 11:28:42 --> URI Class Initialized
INFO - 2018-02-12 11:28:42 --> Router Class Initialized
INFO - 2018-02-12 11:28:42 --> Output Class Initialized
INFO - 2018-02-12 11:28:42 --> Security Class Initialized
DEBUG - 2018-02-12 11:28:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 11:28:42 --> Input Class Initialized
INFO - 2018-02-12 11:28:42 --> Language Class Initialized
INFO - 2018-02-12 11:28:42 --> Loader Class Initialized
INFO - 2018-02-12 11:28:42 --> Helper loaded: url_helper
INFO - 2018-02-12 11:28:42 --> Helper loaded: file_helper
INFO - 2018-02-12 11:28:42 --> Helper loaded: email_helper
INFO - 2018-02-12 11:28:42 --> Helper loaded: common_helper
INFO - 2018-02-12 11:28:42 --> Database Driver Class Initialized
DEBUG - 2018-02-12 11:28:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 11:28:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 11:28:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-12 11:28:42 --> Pagination Class Initialized
INFO - 2018-02-12 11:28:42 --> Helper loaded: form_helper
INFO - 2018-02-12 11:28:42 --> Form Validation Class Initialized
INFO - 2018-02-12 11:28:42 --> Model Class Initialized
INFO - 2018-02-12 11:28:42 --> Controller Class Initialized
DEBUG - 2018-02-12 11:28:42 --> Config file loaded: /var/www/html/project/spamblocker/application/config/rest.php
INFO - 2018-02-12 11:28:42 --> Helper loaded: inflector_helper
INFO - 2018-02-12 11:28:42 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-12 11:28:42 --> Model Class Initialized
INFO - 2018-02-12 11:28:42 --> Model Class Initialized
INFO - 2018-02-12 11:28:42 --> Model Class Initialized
INFO - 2018-02-12 11:28:42 --> Email Class Initialized
INFO - 2018-02-12 11:28:43 --> Language file loaded: language/english/email_lang.php
INFO - 2018-02-12 11:28:46 --> Final output sent to browser
DEBUG - 2018-02-12 11:28:46 --> Total execution time: 3.8638
INFO - 2018-02-12 11:28:57 --> Config Class Initialized
INFO - 2018-02-12 11:28:57 --> Hooks Class Initialized
DEBUG - 2018-02-12 11:28:57 --> UTF-8 Support Enabled
INFO - 2018-02-12 11:28:57 --> Utf8 Class Initialized
INFO - 2018-02-12 11:28:57 --> URI Class Initialized
INFO - 2018-02-12 11:28:57 --> Router Class Initialized
INFO - 2018-02-12 11:28:57 --> Output Class Initialized
INFO - 2018-02-12 11:28:57 --> Security Class Initialized
DEBUG - 2018-02-12 11:28:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 11:28:57 --> Input Class Initialized
INFO - 2018-02-12 11:28:57 --> Language Class Initialized
INFO - 2018-02-12 11:28:57 --> Loader Class Initialized
INFO - 2018-02-12 11:28:57 --> Helper loaded: url_helper
INFO - 2018-02-12 11:28:57 --> Helper loaded: file_helper
INFO - 2018-02-12 11:28:57 --> Helper loaded: email_helper
INFO - 2018-02-12 11:28:57 --> Helper loaded: common_helper
INFO - 2018-02-12 11:28:57 --> Database Driver Class Initialized
DEBUG - 2018-02-12 11:28:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 11:28:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 11:28:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-12 11:28:57 --> Pagination Class Initialized
INFO - 2018-02-12 11:28:57 --> Helper loaded: form_helper
INFO - 2018-02-12 11:28:57 --> Form Validation Class Initialized
INFO - 2018-02-12 11:28:57 --> Model Class Initialized
INFO - 2018-02-12 11:28:57 --> Controller Class Initialized
INFO - 2018-02-12 11:28:57 --> Model Class Initialized
INFO - 2018-02-12 11:28:57 --> File loaded: /var/www/html/project/spamblocker/application/views/index/resetPassword.php
INFO - 2018-02-12 11:28:57 --> Final output sent to browser
DEBUG - 2018-02-12 11:28:57 --> Total execution time: 0.0193

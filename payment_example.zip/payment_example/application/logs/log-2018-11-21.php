<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2018-11-21 05:35:03 --> Config Class Initialized
INFO - 2018-11-21 05:35:03 --> Hooks Class Initialized
DEBUG - 2018-11-21 05:35:03 --> UTF-8 Support Enabled
INFO - 2018-11-21 05:35:03 --> Utf8 Class Initialized
INFO - 2018-11-21 05:35:03 --> URI Class Initialized
INFO - 2018-11-21 05:35:03 --> Router Class Initialized
INFO - 2018-11-21 05:35:03 --> Output Class Initialized
INFO - 2018-11-21 05:35:03 --> Security Class Initialized
DEBUG - 2018-11-21 05:35:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-21 05:35:03 --> Input Class Initialized
INFO - 2018-11-21 05:35:03 --> Language Class Initialized
INFO - 2018-11-21 05:35:03 --> Loader Class Initialized
INFO - 2018-11-21 05:35:03 --> Helper loaded: url_helper
INFO - 2018-11-21 05:35:03 --> Helper loaded: file_helper
INFO - 2018-11-21 05:35:03 --> Helper loaded: email_helper
INFO - 2018-11-21 05:35:03 --> Helper loaded: common_helper
INFO - 2018-11-21 05:35:03 --> Database Driver Class Initialized
ERROR - 2018-11-21 05:35:04 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No connection could be made because the target machine actively refused it.
 C:\xampp\htdocs\wetinuneed\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2018-11-21 05:35:04 --> Unable to connect to the database
INFO - 2018-11-21 05:35:04 --> Language file loaded: language/english/db_lang.php
INFO - 2018-11-21 05:35:18 --> Config Class Initialized
INFO - 2018-11-21 05:35:18 --> Hooks Class Initialized
DEBUG - 2018-11-21 05:35:19 --> UTF-8 Support Enabled
INFO - 2018-11-21 05:35:19 --> Utf8 Class Initialized
INFO - 2018-11-21 05:35:19 --> URI Class Initialized
INFO - 2018-11-21 05:35:19 --> Router Class Initialized
INFO - 2018-11-21 05:35:19 --> Output Class Initialized
INFO - 2018-11-21 05:35:19 --> Security Class Initialized
DEBUG - 2018-11-21 05:35:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-21 05:35:19 --> Input Class Initialized
INFO - 2018-11-21 05:35:19 --> Language Class Initialized
INFO - 2018-11-21 05:35:19 --> Loader Class Initialized
INFO - 2018-11-21 05:35:19 --> Helper loaded: url_helper
INFO - 2018-11-21 05:35:19 --> Helper loaded: file_helper
INFO - 2018-11-21 05:35:19 --> Helper loaded: email_helper
INFO - 2018-11-21 05:35:19 --> Helper loaded: common_helper
INFO - 2018-11-21 05:35:19 --> Database Driver Class Initialized
DEBUG - 2018-11-21 05:35:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-21 05:35:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-21 05:35:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-21 05:35:19 --> Pagination Class Initialized
INFO - 2018-11-21 05:35:19 --> Helper loaded: form_helper
INFO - 2018-11-21 05:35:19 --> Form Validation Class Initialized
INFO - 2018-11-21 05:35:19 --> Model Class Initialized
INFO - 2018-11-21 05:35:19 --> Controller Class Initialized
INFO - 2018-11-21 05:35:19 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-21 05:35:19 --> Model Class Initialized
INFO - 2018-11-21 05:35:19 --> Model Class Initialized
INFO - 2018-11-21 05:35:19 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/index.php
INFO - 2018-11-21 05:35:19 --> Final output sent to browser
DEBUG - 2018-11-21 05:35:19 --> Total execution time: 0.4600
INFO - 2018-11-21 05:35:22 --> Config Class Initialized
INFO - 2018-11-21 05:35:22 --> Hooks Class Initialized
DEBUG - 2018-11-21 05:35:22 --> UTF-8 Support Enabled
INFO - 2018-11-21 05:35:22 --> Utf8 Class Initialized
INFO - 2018-11-21 05:35:22 --> URI Class Initialized
INFO - 2018-11-21 05:35:22 --> Router Class Initialized
INFO - 2018-11-21 05:35:22 --> Output Class Initialized
INFO - 2018-11-21 05:35:22 --> Security Class Initialized
DEBUG - 2018-11-21 05:35:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-21 05:35:22 --> Input Class Initialized
INFO - 2018-11-21 05:35:22 --> Language Class Initialized
INFO - 2018-11-21 05:35:22 --> Loader Class Initialized
INFO - 2018-11-21 05:35:22 --> Helper loaded: url_helper
INFO - 2018-11-21 05:35:22 --> Helper loaded: file_helper
INFO - 2018-11-21 05:35:22 --> Helper loaded: email_helper
INFO - 2018-11-21 05:35:22 --> Helper loaded: common_helper
INFO - 2018-11-21 05:35:22 --> Database Driver Class Initialized
DEBUG - 2018-11-21 05:35:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-21 05:35:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-21 05:35:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-21 05:35:22 --> Pagination Class Initialized
INFO - 2018-11-21 05:35:22 --> Helper loaded: form_helper
INFO - 2018-11-21 05:35:22 --> Form Validation Class Initialized
INFO - 2018-11-21 05:35:22 --> Model Class Initialized
INFO - 2018-11-21 05:35:22 --> Controller Class Initialized
INFO - 2018-11-21 05:35:22 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-21 05:35:22 --> Model Class Initialized
INFO - 2018-11-21 05:35:22 --> Model Class Initialized
ERROR - 2018-11-21 05:35:22 --> Severity: Notice --> Undefined index: remember_me C:\xampp\htdocs\wetinuneed\application\controllers\admin\Admin.php 76
INFO - 2018-11-21 05:35:22 --> Config Class Initialized
INFO - 2018-11-21 05:35:22 --> Hooks Class Initialized
DEBUG - 2018-11-21 05:35:22 --> UTF-8 Support Enabled
INFO - 2018-11-21 05:35:22 --> Utf8 Class Initialized
INFO - 2018-11-21 05:35:22 --> URI Class Initialized
INFO - 2018-11-21 05:35:22 --> Router Class Initialized
INFO - 2018-11-21 05:35:22 --> Output Class Initialized
INFO - 2018-11-21 05:35:22 --> Security Class Initialized
DEBUG - 2018-11-21 05:35:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-21 05:35:22 --> Input Class Initialized
INFO - 2018-11-21 05:35:22 --> Language Class Initialized
INFO - 2018-11-21 05:35:22 --> Loader Class Initialized
INFO - 2018-11-21 05:35:22 --> Helper loaded: url_helper
INFO - 2018-11-21 05:35:22 --> Helper loaded: file_helper
INFO - 2018-11-21 05:35:22 --> Helper loaded: email_helper
INFO - 2018-11-21 05:35:22 --> Helper loaded: common_helper
INFO - 2018-11-21 05:35:22 --> Database Driver Class Initialized
DEBUG - 2018-11-21 05:35:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-21 05:35:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-21 05:35:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-21 05:35:22 --> Pagination Class Initialized
INFO - 2018-11-21 05:35:22 --> Helper loaded: form_helper
INFO - 2018-11-21 05:35:22 --> Form Validation Class Initialized
INFO - 2018-11-21 05:35:22 --> Model Class Initialized
INFO - 2018-11-21 05:35:22 --> Controller Class Initialized
INFO - 2018-11-21 05:35:22 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-21 05:35:22 --> Model Class Initialized
INFO - 2018-11-21 05:35:22 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-21 05:35:22 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/sidebar.php
INFO - 2018-11-21 05:35:22 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/right-sidebar.php
INFO - 2018-11-21 05:35:22 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/footer.php
INFO - 2018-11-21 05:35:22 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/dashboard.php
INFO - 2018-11-21 05:35:22 --> Final output sent to browser
DEBUG - 2018-11-21 05:35:22 --> Total execution time: 0.0610
INFO - 2018-11-21 05:37:52 --> Config Class Initialized
INFO - 2018-11-21 05:37:52 --> Hooks Class Initialized
DEBUG - 2018-11-21 05:37:52 --> UTF-8 Support Enabled
INFO - 2018-11-21 05:37:52 --> Utf8 Class Initialized
INFO - 2018-11-21 05:37:52 --> URI Class Initialized
INFO - 2018-11-21 05:37:52 --> Router Class Initialized
INFO - 2018-11-21 05:37:52 --> Output Class Initialized
INFO - 2018-11-21 05:37:52 --> Security Class Initialized
DEBUG - 2018-11-21 05:37:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-21 05:37:52 --> Input Class Initialized
INFO - 2018-11-21 05:37:52 --> Language Class Initialized
INFO - 2018-11-21 05:37:52 --> Loader Class Initialized
INFO - 2018-11-21 05:37:52 --> Helper loaded: url_helper
INFO - 2018-11-21 05:37:52 --> Helper loaded: file_helper
INFO - 2018-11-21 05:37:52 --> Helper loaded: email_helper
INFO - 2018-11-21 05:37:52 --> Helper loaded: common_helper
INFO - 2018-11-21 05:37:52 --> Database Driver Class Initialized
DEBUG - 2018-11-21 05:37:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-21 05:37:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-21 05:37:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-21 05:37:52 --> Pagination Class Initialized
INFO - 2018-11-21 05:37:52 --> Helper loaded: form_helper
INFO - 2018-11-21 05:37:52 --> Form Validation Class Initialized
INFO - 2018-11-21 05:37:52 --> Model Class Initialized
INFO - 2018-11-21 05:37:52 --> Controller Class Initialized
INFO - 2018-11-21 05:37:52 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-21 05:37:52 --> Model Class Initialized
INFO - 2018-11-21 05:37:52 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-21 05:37:52 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/sidebar.php
INFO - 2018-11-21 05:37:52 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/right-sidebar.php
INFO - 2018-11-21 05:37:52 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/footer.php
INFO - 2018-11-21 05:37:52 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/dashboard.php
INFO - 2018-11-21 05:37:52 --> Final output sent to browser
DEBUG - 2018-11-21 05:37:52 --> Total execution time: 0.0650
INFO - 2018-11-21 05:37:57 --> Config Class Initialized
INFO - 2018-11-21 05:37:57 --> Hooks Class Initialized
DEBUG - 2018-11-21 05:37:57 --> UTF-8 Support Enabled
INFO - 2018-11-21 05:37:57 --> Utf8 Class Initialized
INFO - 2018-11-21 05:37:57 --> URI Class Initialized
INFO - 2018-11-21 05:37:57 --> Router Class Initialized
INFO - 2018-11-21 05:37:57 --> Output Class Initialized
INFO - 2018-11-21 05:37:57 --> Security Class Initialized
DEBUG - 2018-11-21 05:37:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-21 05:37:57 --> Input Class Initialized
INFO - 2018-11-21 05:37:57 --> Language Class Initialized
INFO - 2018-11-21 05:37:57 --> Loader Class Initialized
INFO - 2018-11-21 05:37:57 --> Helper loaded: url_helper
INFO - 2018-11-21 05:37:57 --> Helper loaded: file_helper
INFO - 2018-11-21 05:37:57 --> Helper loaded: email_helper
INFO - 2018-11-21 05:37:57 --> Helper loaded: common_helper
INFO - 2018-11-21 05:37:57 --> Database Driver Class Initialized
DEBUG - 2018-11-21 05:37:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-21 05:37:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-21 05:37:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-21 05:37:57 --> Pagination Class Initialized
INFO - 2018-11-21 05:37:57 --> Helper loaded: form_helper
INFO - 2018-11-21 05:37:57 --> Form Validation Class Initialized
INFO - 2018-11-21 05:37:57 --> Model Class Initialized
INFO - 2018-11-21 05:37:57 --> Controller Class Initialized
INFO - 2018-11-21 05:37:57 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-21 05:37:57 --> Model Class Initialized
INFO - 2018-11-21 05:37:57 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-21 05:37:57 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/sidebar.php
INFO - 2018-11-21 05:37:57 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/right-sidebar.php
INFO - 2018-11-21 05:37:57 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/footer.php
INFO - 2018-11-21 05:37:57 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/dashboard.php
INFO - 2018-11-21 05:37:57 --> Final output sent to browser
DEBUG - 2018-11-21 05:37:57 --> Total execution time: 0.0600
INFO - 2018-11-21 05:38:00 --> Config Class Initialized
INFO - 2018-11-21 05:38:00 --> Hooks Class Initialized
DEBUG - 2018-11-21 05:38:00 --> UTF-8 Support Enabled
INFO - 2018-11-21 05:38:00 --> Utf8 Class Initialized
INFO - 2018-11-21 05:38:00 --> URI Class Initialized
INFO - 2018-11-21 05:38:00 --> Router Class Initialized
INFO - 2018-11-21 05:38:00 --> Output Class Initialized
INFO - 2018-11-21 05:38:00 --> Security Class Initialized
DEBUG - 2018-11-21 05:38:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-21 05:38:00 --> Input Class Initialized
INFO - 2018-11-21 05:38:00 --> Language Class Initialized
INFO - 2018-11-21 05:38:00 --> Loader Class Initialized
INFO - 2018-11-21 05:38:00 --> Helper loaded: url_helper
INFO - 2018-11-21 05:38:00 --> Helper loaded: file_helper
INFO - 2018-11-21 05:38:00 --> Helper loaded: email_helper
INFO - 2018-11-21 05:38:00 --> Helper loaded: common_helper
INFO - 2018-11-21 05:38:00 --> Database Driver Class Initialized
DEBUG - 2018-11-21 05:38:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-21 05:38:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-21 05:38:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-21 05:38:00 --> Pagination Class Initialized
INFO - 2018-11-21 05:38:00 --> Helper loaded: form_helper
INFO - 2018-11-21 05:38:00 --> Form Validation Class Initialized
INFO - 2018-11-21 05:38:00 --> Model Class Initialized
INFO - 2018-11-21 05:38:00 --> Controller Class Initialized
INFO - 2018-11-21 05:38:00 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-21 05:38:00 --> Model Class Initialized
INFO - 2018-11-21 05:38:00 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-21 05:38:00 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/sidebar.php
INFO - 2018-11-21 05:38:00 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/right-sidebar.php
INFO - 2018-11-21 05:38:00 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/footer.php
INFO - 2018-11-21 05:38:00 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/dashboard.php
INFO - 2018-11-21 05:38:00 --> Final output sent to browser
DEBUG - 2018-11-21 05:38:00 --> Total execution time: 0.0510
INFO - 2018-11-21 05:54:55 --> Config Class Initialized
INFO - 2018-11-21 05:54:55 --> Hooks Class Initialized
DEBUG - 2018-11-21 05:54:55 --> UTF-8 Support Enabled
INFO - 2018-11-21 05:54:55 --> Utf8 Class Initialized
INFO - 2018-11-21 05:54:55 --> URI Class Initialized
INFO - 2018-11-21 05:54:55 --> Router Class Initialized
INFO - 2018-11-21 05:54:55 --> Output Class Initialized
INFO - 2018-11-21 05:54:55 --> Security Class Initialized
DEBUG - 2018-11-21 05:54:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-21 05:54:55 --> Input Class Initialized
INFO - 2018-11-21 05:54:55 --> Language Class Initialized
INFO - 2018-11-21 05:54:55 --> Loader Class Initialized
INFO - 2018-11-21 05:54:55 --> Helper loaded: url_helper
INFO - 2018-11-21 05:54:55 --> Helper loaded: file_helper
INFO - 2018-11-21 05:54:55 --> Helper loaded: email_helper
INFO - 2018-11-21 05:54:55 --> Helper loaded: common_helper
INFO - 2018-11-21 05:54:55 --> Database Driver Class Initialized
DEBUG - 2018-11-21 05:54:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-21 05:54:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-21 05:54:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-21 05:54:55 --> Pagination Class Initialized
INFO - 2018-11-21 05:54:55 --> Helper loaded: form_helper
INFO - 2018-11-21 05:54:55 --> Form Validation Class Initialized
INFO - 2018-11-21 05:54:55 --> Model Class Initialized
INFO - 2018-11-21 05:54:55 --> Controller Class Initialized
INFO - 2018-11-21 05:54:55 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-21 05:54:55 --> Model Class Initialized
INFO - 2018-11-21 05:54:55 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-21 05:54:55 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/sidebar.php
INFO - 2018-11-21 05:54:55 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/right-sidebar.php
INFO - 2018-11-21 05:54:55 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/footer.php
INFO - 2018-11-21 05:54:55 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/dashboard.php
INFO - 2018-11-21 05:54:55 --> Final output sent to browser
DEBUG - 2018-11-21 05:54:55 --> Total execution time: 0.0540
INFO - 2018-11-21 05:59:16 --> Config Class Initialized
INFO - 2018-11-21 05:59:16 --> Hooks Class Initialized
DEBUG - 2018-11-21 05:59:16 --> UTF-8 Support Enabled
INFO - 2018-11-21 05:59:16 --> Utf8 Class Initialized
INFO - 2018-11-21 05:59:16 --> URI Class Initialized
INFO - 2018-11-21 05:59:16 --> Router Class Initialized
INFO - 2018-11-21 05:59:16 --> Output Class Initialized
INFO - 2018-11-21 05:59:16 --> Security Class Initialized
DEBUG - 2018-11-21 05:59:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-21 05:59:16 --> Input Class Initialized
INFO - 2018-11-21 05:59:16 --> Language Class Initialized
INFO - 2018-11-21 05:59:16 --> Loader Class Initialized
INFO - 2018-11-21 05:59:16 --> Helper loaded: url_helper
INFO - 2018-11-21 05:59:16 --> Helper loaded: file_helper
INFO - 2018-11-21 05:59:16 --> Helper loaded: email_helper
INFO - 2018-11-21 05:59:16 --> Helper loaded: common_helper
INFO - 2018-11-21 05:59:16 --> Database Driver Class Initialized
DEBUG - 2018-11-21 05:59:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-21 05:59:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-21 05:59:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-21 05:59:16 --> Pagination Class Initialized
INFO - 2018-11-21 05:59:16 --> Helper loaded: form_helper
INFO - 2018-11-21 05:59:16 --> Form Validation Class Initialized
INFO - 2018-11-21 05:59:16 --> Model Class Initialized
INFO - 2018-11-21 05:59:16 --> Controller Class Initialized
INFO - 2018-11-21 05:59:16 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-21 05:59:16 --> Model Class Initialized
INFO - 2018-11-21 05:59:16 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-21 05:59:16 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/sidebar.php
INFO - 2018-11-21 05:59:16 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/right-sidebar.php
INFO - 2018-11-21 05:59:16 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/footer.php
INFO - 2018-11-21 05:59:16 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/dashboard.php
INFO - 2018-11-21 05:59:16 --> Final output sent to browser
DEBUG - 2018-11-21 05:59:16 --> Total execution time: 0.0560
INFO - 2018-11-21 05:59:53 --> Config Class Initialized
INFO - 2018-11-21 05:59:53 --> Hooks Class Initialized
DEBUG - 2018-11-21 05:59:53 --> UTF-8 Support Enabled
INFO - 2018-11-21 05:59:53 --> Utf8 Class Initialized
INFO - 2018-11-21 05:59:53 --> URI Class Initialized
INFO - 2018-11-21 05:59:53 --> Router Class Initialized
INFO - 2018-11-21 05:59:53 --> Output Class Initialized
INFO - 2018-11-21 05:59:53 --> Security Class Initialized
DEBUG - 2018-11-21 05:59:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-21 05:59:53 --> Input Class Initialized
INFO - 2018-11-21 05:59:53 --> Language Class Initialized
INFO - 2018-11-21 05:59:53 --> Loader Class Initialized
INFO - 2018-11-21 05:59:53 --> Helper loaded: url_helper
INFO - 2018-11-21 05:59:53 --> Helper loaded: file_helper
INFO - 2018-11-21 05:59:53 --> Helper loaded: email_helper
INFO - 2018-11-21 05:59:53 --> Helper loaded: common_helper
INFO - 2018-11-21 05:59:53 --> Database Driver Class Initialized
DEBUG - 2018-11-21 05:59:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-21 05:59:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-21 05:59:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-21 05:59:53 --> Pagination Class Initialized
INFO - 2018-11-21 05:59:53 --> Helper loaded: form_helper
INFO - 2018-11-21 05:59:53 --> Form Validation Class Initialized
INFO - 2018-11-21 05:59:53 --> Model Class Initialized
INFO - 2018-11-21 05:59:53 --> Controller Class Initialized
INFO - 2018-11-21 05:59:53 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-21 05:59:53 --> Model Class Initialized
INFO - 2018-11-21 05:59:53 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-21 05:59:53 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/sidebar.php
INFO - 2018-11-21 05:59:53 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/right-sidebar.php
INFO - 2018-11-21 05:59:53 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/footer.php
INFO - 2018-11-21 05:59:53 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/dashboard.php
INFO - 2018-11-21 05:59:53 --> Final output sent to browser
DEBUG - 2018-11-21 05:59:53 --> Total execution time: 0.0620
INFO - 2018-11-21 05:59:56 --> Config Class Initialized
INFO - 2018-11-21 05:59:56 --> Hooks Class Initialized
DEBUG - 2018-11-21 05:59:56 --> UTF-8 Support Enabled
INFO - 2018-11-21 05:59:56 --> Utf8 Class Initialized
INFO - 2018-11-21 05:59:56 --> URI Class Initialized
INFO - 2018-11-21 05:59:56 --> Router Class Initialized
INFO - 2018-11-21 05:59:56 --> Output Class Initialized
INFO - 2018-11-21 05:59:56 --> Security Class Initialized
DEBUG - 2018-11-21 05:59:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-21 05:59:56 --> Input Class Initialized
INFO - 2018-11-21 05:59:56 --> Language Class Initialized
INFO - 2018-11-21 05:59:56 --> Loader Class Initialized
INFO - 2018-11-21 05:59:56 --> Helper loaded: url_helper
INFO - 2018-11-21 05:59:56 --> Helper loaded: file_helper
INFO - 2018-11-21 05:59:56 --> Helper loaded: email_helper
INFO - 2018-11-21 05:59:56 --> Helper loaded: common_helper
INFO - 2018-11-21 05:59:56 --> Database Driver Class Initialized
DEBUG - 2018-11-21 05:59:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-21 05:59:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-21 05:59:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-21 05:59:56 --> Pagination Class Initialized
INFO - 2018-11-21 05:59:56 --> Helper loaded: form_helper
INFO - 2018-11-21 05:59:56 --> Form Validation Class Initialized
INFO - 2018-11-21 05:59:56 --> Model Class Initialized
INFO - 2018-11-21 05:59:56 --> Controller Class Initialized
INFO - 2018-11-21 05:59:56 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-21 05:59:56 --> Model Class Initialized
INFO - 2018-11-21 05:59:56 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-21 05:59:56 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/sidebar.php
INFO - 2018-11-21 05:59:56 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/right-sidebar.php
INFO - 2018-11-21 05:59:56 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/footer.php
INFO - 2018-11-21 05:59:56 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/dashboard.php
INFO - 2018-11-21 05:59:56 --> Final output sent to browser
DEBUG - 2018-11-21 05:59:56 --> Total execution time: 0.0730
INFO - 2018-11-21 06:03:32 --> Config Class Initialized
INFO - 2018-11-21 06:03:32 --> Hooks Class Initialized
DEBUG - 2018-11-21 06:03:32 --> UTF-8 Support Enabled
INFO - 2018-11-21 06:03:32 --> Utf8 Class Initialized
INFO - 2018-11-21 06:03:32 --> URI Class Initialized
INFO - 2018-11-21 06:03:32 --> Router Class Initialized
INFO - 2018-11-21 06:03:32 --> Output Class Initialized
INFO - 2018-11-21 06:03:32 --> Security Class Initialized
DEBUG - 2018-11-21 06:03:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-21 06:03:32 --> Input Class Initialized
INFO - 2018-11-21 06:03:32 --> Language Class Initialized
INFO - 2018-11-21 06:03:32 --> Loader Class Initialized
INFO - 2018-11-21 06:03:32 --> Helper loaded: url_helper
INFO - 2018-11-21 06:03:32 --> Helper loaded: file_helper
INFO - 2018-11-21 06:03:32 --> Helper loaded: email_helper
INFO - 2018-11-21 06:03:32 --> Helper loaded: common_helper
INFO - 2018-11-21 06:03:32 --> Database Driver Class Initialized
DEBUG - 2018-11-21 06:03:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-21 06:03:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-21 06:03:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-21 06:03:32 --> Pagination Class Initialized
INFO - 2018-11-21 06:03:32 --> Helper loaded: form_helper
INFO - 2018-11-21 06:03:32 --> Form Validation Class Initialized
INFO - 2018-11-21 06:03:32 --> Model Class Initialized
INFO - 2018-11-21 06:03:32 --> Controller Class Initialized
INFO - 2018-11-21 06:03:32 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-21 06:03:32 --> Model Class Initialized
INFO - 2018-11-21 06:03:32 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-21 06:03:32 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/sidebar.php
INFO - 2018-11-21 06:03:32 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/right-sidebar.php
INFO - 2018-11-21 06:03:32 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/footer.php
INFO - 2018-11-21 06:03:32 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/dashboard.php
INFO - 2018-11-21 06:03:32 --> Final output sent to browser
DEBUG - 2018-11-21 06:03:32 --> Total execution time: 0.0750
INFO - 2018-11-21 06:06:48 --> Config Class Initialized
INFO - 2018-11-21 06:06:48 --> Hooks Class Initialized
DEBUG - 2018-11-21 06:06:48 --> UTF-8 Support Enabled
INFO - 2018-11-21 06:06:48 --> Utf8 Class Initialized
INFO - 2018-11-21 06:06:48 --> URI Class Initialized
INFO - 2018-11-21 06:06:48 --> Router Class Initialized
INFO - 2018-11-21 06:06:48 --> Output Class Initialized
INFO - 2018-11-21 06:06:48 --> Security Class Initialized
DEBUG - 2018-11-21 06:06:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-21 06:06:48 --> Input Class Initialized
INFO - 2018-11-21 06:06:48 --> Language Class Initialized
INFO - 2018-11-21 06:06:48 --> Loader Class Initialized
INFO - 2018-11-21 06:06:48 --> Helper loaded: url_helper
INFO - 2018-11-21 06:06:48 --> Helper loaded: file_helper
INFO - 2018-11-21 06:06:48 --> Helper loaded: email_helper
INFO - 2018-11-21 06:06:48 --> Helper loaded: common_helper
INFO - 2018-11-21 06:06:48 --> Database Driver Class Initialized
DEBUG - 2018-11-21 06:06:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-21 06:06:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-21 06:06:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-21 06:06:48 --> Pagination Class Initialized
INFO - 2018-11-21 06:06:48 --> Helper loaded: form_helper
INFO - 2018-11-21 06:06:48 --> Form Validation Class Initialized
INFO - 2018-11-21 06:06:48 --> Model Class Initialized
INFO - 2018-11-21 06:06:48 --> Controller Class Initialized
INFO - 2018-11-21 06:06:48 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-21 06:06:48 --> Model Class Initialized
INFO - 2018-11-21 06:06:48 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-21 06:06:48 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/sidebar.php
INFO - 2018-11-21 06:06:48 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/right-sidebar.php
INFO - 2018-11-21 06:06:48 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/footer.php
INFO - 2018-11-21 06:06:48 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/dashboard.php
INFO - 2018-11-21 06:06:48 --> Final output sent to browser
DEBUG - 2018-11-21 06:06:48 --> Total execution time: 0.0550
INFO - 2018-11-21 06:07:02 --> Config Class Initialized
INFO - 2018-11-21 06:07:02 --> Hooks Class Initialized
DEBUG - 2018-11-21 06:07:02 --> UTF-8 Support Enabled
INFO - 2018-11-21 06:07:02 --> Utf8 Class Initialized
INFO - 2018-11-21 06:07:02 --> URI Class Initialized
INFO - 2018-11-21 06:07:02 --> Router Class Initialized
INFO - 2018-11-21 06:07:02 --> Output Class Initialized
INFO - 2018-11-21 06:07:02 --> Security Class Initialized
DEBUG - 2018-11-21 06:07:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-21 06:07:02 --> Input Class Initialized
INFO - 2018-11-21 06:07:02 --> Language Class Initialized
INFO - 2018-11-21 06:07:02 --> Loader Class Initialized
INFO - 2018-11-21 06:07:02 --> Helper loaded: url_helper
INFO - 2018-11-21 06:07:02 --> Helper loaded: file_helper
INFO - 2018-11-21 06:07:02 --> Helper loaded: email_helper
INFO - 2018-11-21 06:07:02 --> Helper loaded: common_helper
INFO - 2018-11-21 06:07:02 --> Database Driver Class Initialized
DEBUG - 2018-11-21 06:07:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-21 06:07:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-21 06:07:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-21 06:07:02 --> Pagination Class Initialized
INFO - 2018-11-21 06:07:02 --> Helper loaded: form_helper
INFO - 2018-11-21 06:07:02 --> Form Validation Class Initialized
INFO - 2018-11-21 06:07:02 --> Model Class Initialized
INFO - 2018-11-21 06:07:02 --> Controller Class Initialized
INFO - 2018-11-21 06:07:02 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-21 06:07:02 --> Model Class Initialized
INFO - 2018-11-21 06:07:02 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-21 06:07:02 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/sidebar.php
INFO - 2018-11-21 06:07:02 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/right-sidebar.php
INFO - 2018-11-21 06:07:02 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/footer.php
INFO - 2018-11-21 06:07:02 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/dashboard.php
INFO - 2018-11-21 06:07:02 --> Final output sent to browser
DEBUG - 2018-11-21 06:07:02 --> Total execution time: 0.0660
INFO - 2018-11-21 06:07:23 --> Config Class Initialized
INFO - 2018-11-21 06:07:23 --> Hooks Class Initialized
DEBUG - 2018-11-21 06:07:23 --> UTF-8 Support Enabled
INFO - 2018-11-21 06:07:23 --> Utf8 Class Initialized
INFO - 2018-11-21 06:07:23 --> URI Class Initialized
INFO - 2018-11-21 06:07:23 --> Router Class Initialized
INFO - 2018-11-21 06:07:23 --> Output Class Initialized
INFO - 2018-11-21 06:07:23 --> Security Class Initialized
DEBUG - 2018-11-21 06:07:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-21 06:07:23 --> Input Class Initialized
INFO - 2018-11-21 06:07:23 --> Language Class Initialized
INFO - 2018-11-21 06:07:23 --> Loader Class Initialized
INFO - 2018-11-21 06:07:23 --> Helper loaded: url_helper
INFO - 2018-11-21 06:07:23 --> Helper loaded: file_helper
INFO - 2018-11-21 06:07:23 --> Helper loaded: email_helper
INFO - 2018-11-21 06:07:23 --> Helper loaded: common_helper
INFO - 2018-11-21 06:07:23 --> Database Driver Class Initialized
DEBUG - 2018-11-21 06:07:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-21 06:07:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-21 06:07:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-21 06:07:23 --> Pagination Class Initialized
INFO - 2018-11-21 06:07:23 --> Helper loaded: form_helper
INFO - 2018-11-21 06:07:23 --> Form Validation Class Initialized
INFO - 2018-11-21 06:07:23 --> Model Class Initialized
INFO - 2018-11-21 06:07:23 --> Controller Class Initialized
INFO - 2018-11-21 06:07:23 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-21 06:07:23 --> Model Class Initialized
INFO - 2018-11-21 06:07:23 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-21 06:07:23 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/sidebar.php
INFO - 2018-11-21 06:07:23 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/right-sidebar.php
INFO - 2018-11-21 06:07:23 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/footer.php
INFO - 2018-11-21 06:07:23 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/dashboard.php
INFO - 2018-11-21 06:07:23 --> Final output sent to browser
DEBUG - 2018-11-21 06:07:23 --> Total execution time: 0.0570
INFO - 2018-11-21 06:09:57 --> Config Class Initialized
INFO - 2018-11-21 06:09:57 --> Hooks Class Initialized
DEBUG - 2018-11-21 06:09:57 --> UTF-8 Support Enabled
INFO - 2018-11-21 06:09:57 --> Utf8 Class Initialized
INFO - 2018-11-21 06:09:57 --> URI Class Initialized
INFO - 2018-11-21 06:09:57 --> Router Class Initialized
INFO - 2018-11-21 06:09:57 --> Output Class Initialized
INFO - 2018-11-21 06:09:57 --> Security Class Initialized
DEBUG - 2018-11-21 06:09:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-21 06:09:57 --> Input Class Initialized
INFO - 2018-11-21 06:09:57 --> Language Class Initialized
INFO - 2018-11-21 06:09:57 --> Loader Class Initialized
INFO - 2018-11-21 06:09:57 --> Helper loaded: url_helper
INFO - 2018-11-21 06:09:57 --> Helper loaded: file_helper
INFO - 2018-11-21 06:09:57 --> Helper loaded: email_helper
INFO - 2018-11-21 06:09:57 --> Helper loaded: common_helper
INFO - 2018-11-21 06:09:57 --> Database Driver Class Initialized
DEBUG - 2018-11-21 06:09:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-21 06:09:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-21 06:09:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-21 06:09:57 --> Pagination Class Initialized
INFO - 2018-11-21 06:09:57 --> Helper loaded: form_helper
INFO - 2018-11-21 06:09:57 --> Form Validation Class Initialized
INFO - 2018-11-21 06:09:57 --> Model Class Initialized
INFO - 2018-11-21 06:09:57 --> Controller Class Initialized
INFO - 2018-11-21 06:09:57 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-21 06:09:57 --> Model Class Initialized
INFO - 2018-11-21 06:09:57 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-21 06:09:57 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/sidebar.php
INFO - 2018-11-21 06:09:57 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/right-sidebar.php
INFO - 2018-11-21 06:09:57 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/footer.php
INFO - 2018-11-21 06:09:57 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/dashboard.php
INFO - 2018-11-21 06:09:57 --> Final output sent to browser
DEBUG - 2018-11-21 06:09:57 --> Total execution time: 0.0560
INFO - 2018-11-21 06:18:13 --> Config Class Initialized
INFO - 2018-11-21 06:18:13 --> Hooks Class Initialized
DEBUG - 2018-11-21 06:18:13 --> UTF-8 Support Enabled
INFO - 2018-11-21 06:18:13 --> Utf8 Class Initialized
INFO - 2018-11-21 06:18:13 --> URI Class Initialized
INFO - 2018-11-21 06:18:13 --> Router Class Initialized
INFO - 2018-11-21 06:18:13 --> Output Class Initialized
INFO - 2018-11-21 06:18:13 --> Security Class Initialized
DEBUG - 2018-11-21 06:18:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-21 06:18:13 --> Input Class Initialized
INFO - 2018-11-21 06:18:13 --> Language Class Initialized
INFO - 2018-11-21 06:18:13 --> Loader Class Initialized
INFO - 2018-11-21 06:18:13 --> Helper loaded: url_helper
INFO - 2018-11-21 06:18:13 --> Helper loaded: file_helper
INFO - 2018-11-21 06:18:13 --> Helper loaded: email_helper
INFO - 2018-11-21 06:18:13 --> Helper loaded: common_helper
INFO - 2018-11-21 06:18:13 --> Database Driver Class Initialized
DEBUG - 2018-11-21 06:18:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-21 06:18:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-21 06:18:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-21 06:18:13 --> Pagination Class Initialized
INFO - 2018-11-21 06:18:13 --> Helper loaded: form_helper
INFO - 2018-11-21 06:18:13 --> Form Validation Class Initialized
INFO - 2018-11-21 06:18:13 --> Model Class Initialized
INFO - 2018-11-21 06:18:13 --> Controller Class Initialized
INFO - 2018-11-21 06:18:13 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-21 06:18:13 --> Model Class Initialized
INFO - 2018-11-21 06:18:13 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-21 06:18:13 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/sidebar.php
INFO - 2018-11-21 06:18:13 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/right-sidebar.php
INFO - 2018-11-21 06:18:13 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/footer.php
INFO - 2018-11-21 06:18:13 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/dashboard.php
INFO - 2018-11-21 06:18:13 --> Final output sent to browser
DEBUG - 2018-11-21 06:18:13 --> Total execution time: 0.0480
INFO - 2018-11-21 06:18:52 --> Config Class Initialized
INFO - 2018-11-21 06:18:52 --> Hooks Class Initialized
DEBUG - 2018-11-21 06:18:52 --> UTF-8 Support Enabled
INFO - 2018-11-21 06:18:52 --> Utf8 Class Initialized
INFO - 2018-11-21 06:18:52 --> URI Class Initialized
INFO - 2018-11-21 06:18:52 --> Router Class Initialized
INFO - 2018-11-21 06:18:52 --> Output Class Initialized
INFO - 2018-11-21 06:18:52 --> Security Class Initialized
DEBUG - 2018-11-21 06:18:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-21 06:18:52 --> Input Class Initialized
INFO - 2018-11-21 06:18:52 --> Language Class Initialized
INFO - 2018-11-21 06:18:52 --> Loader Class Initialized
INFO - 2018-11-21 06:18:52 --> Helper loaded: url_helper
INFO - 2018-11-21 06:18:52 --> Helper loaded: file_helper
INFO - 2018-11-21 06:18:52 --> Helper loaded: email_helper
INFO - 2018-11-21 06:18:52 --> Helper loaded: common_helper
INFO - 2018-11-21 06:18:52 --> Database Driver Class Initialized
DEBUG - 2018-11-21 06:18:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-21 06:18:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-21 06:18:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-21 06:18:52 --> Pagination Class Initialized
INFO - 2018-11-21 06:18:52 --> Helper loaded: form_helper
INFO - 2018-11-21 06:18:52 --> Form Validation Class Initialized
INFO - 2018-11-21 06:18:52 --> Model Class Initialized
INFO - 2018-11-21 06:18:52 --> Controller Class Initialized
INFO - 2018-11-21 06:18:52 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-21 06:18:52 --> Model Class Initialized
INFO - 2018-11-21 06:18:52 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-21 06:18:52 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/sidebar.php
INFO - 2018-11-21 06:18:52 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/right-sidebar.php
INFO - 2018-11-21 06:18:52 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/footer.php
INFO - 2018-11-21 06:18:52 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/dashboard.php
INFO - 2018-11-21 06:18:52 --> Final output sent to browser
DEBUG - 2018-11-21 06:18:52 --> Total execution time: 0.0490
INFO - 2018-11-21 06:21:31 --> Config Class Initialized
INFO - 2018-11-21 06:21:31 --> Hooks Class Initialized
DEBUG - 2018-11-21 06:21:31 --> UTF-8 Support Enabled
INFO - 2018-11-21 06:21:31 --> Utf8 Class Initialized
INFO - 2018-11-21 06:21:31 --> URI Class Initialized
INFO - 2018-11-21 06:21:31 --> Router Class Initialized
INFO - 2018-11-21 06:21:31 --> Output Class Initialized
INFO - 2018-11-21 06:21:31 --> Security Class Initialized
DEBUG - 2018-11-21 06:21:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-21 06:21:31 --> Input Class Initialized
INFO - 2018-11-21 06:21:31 --> Language Class Initialized
INFO - 2018-11-21 06:21:31 --> Loader Class Initialized
INFO - 2018-11-21 06:21:31 --> Helper loaded: url_helper
INFO - 2018-11-21 06:21:31 --> Helper loaded: file_helper
INFO - 2018-11-21 06:21:31 --> Helper loaded: email_helper
INFO - 2018-11-21 06:21:31 --> Helper loaded: common_helper
INFO - 2018-11-21 06:21:31 --> Database Driver Class Initialized
DEBUG - 2018-11-21 06:21:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-21 06:21:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-21 06:21:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-21 06:21:31 --> Pagination Class Initialized
INFO - 2018-11-21 06:21:31 --> Helper loaded: form_helper
INFO - 2018-11-21 06:21:31 --> Form Validation Class Initialized
INFO - 2018-11-21 06:21:31 --> Model Class Initialized
INFO - 2018-11-21 06:21:31 --> Controller Class Initialized
INFO - 2018-11-21 06:21:31 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-21 06:21:31 --> Model Class Initialized
ERROR - 2018-11-21 06:21:31 --> Severity: Notice --> Undefined index: email C:\xampp\htdocs\wetinuneed\application\views\admin\ample\header.php 219
INFO - 2018-11-21 06:21:31 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-21 06:21:31 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/sidebar.php
INFO - 2018-11-21 06:21:31 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/right-sidebar.php
INFO - 2018-11-21 06:21:31 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/footer.php
INFO - 2018-11-21 06:21:31 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/dashboard.php
INFO - 2018-11-21 06:21:31 --> Final output sent to browser
DEBUG - 2018-11-21 06:21:31 --> Total execution time: 0.0590
INFO - 2018-11-21 06:21:48 --> Config Class Initialized
INFO - 2018-11-21 06:21:48 --> Hooks Class Initialized
DEBUG - 2018-11-21 06:21:48 --> UTF-8 Support Enabled
INFO - 2018-11-21 06:21:48 --> Utf8 Class Initialized
INFO - 2018-11-21 06:21:48 --> URI Class Initialized
INFO - 2018-11-21 06:21:48 --> Router Class Initialized
INFO - 2018-11-21 06:21:48 --> Output Class Initialized
INFO - 2018-11-21 06:21:48 --> Security Class Initialized
DEBUG - 2018-11-21 06:21:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-21 06:21:48 --> Input Class Initialized
INFO - 2018-11-21 06:21:48 --> Language Class Initialized
INFO - 2018-11-21 06:21:48 --> Loader Class Initialized
INFO - 2018-11-21 06:21:48 --> Helper loaded: url_helper
INFO - 2018-11-21 06:21:48 --> Helper loaded: file_helper
INFO - 2018-11-21 06:21:48 --> Helper loaded: email_helper
INFO - 2018-11-21 06:21:48 --> Helper loaded: common_helper
INFO - 2018-11-21 06:21:48 --> Database Driver Class Initialized
DEBUG - 2018-11-21 06:21:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-21 06:21:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-21 06:21:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-21 06:21:48 --> Pagination Class Initialized
INFO - 2018-11-21 06:21:48 --> Helper loaded: form_helper
INFO - 2018-11-21 06:21:48 --> Form Validation Class Initialized
INFO - 2018-11-21 06:21:48 --> Model Class Initialized
INFO - 2018-11-21 06:21:48 --> Controller Class Initialized
INFO - 2018-11-21 06:21:48 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-21 06:21:48 --> Model Class Initialized
INFO - 2018-11-21 06:21:48 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-21 06:21:48 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/sidebar.php
INFO - 2018-11-21 06:21:48 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/right-sidebar.php
INFO - 2018-11-21 06:21:48 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/footer.php
INFO - 2018-11-21 06:21:48 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/dashboard.php
INFO - 2018-11-21 06:21:48 --> Final output sent to browser
DEBUG - 2018-11-21 06:21:48 --> Total execution time: 0.0470
INFO - 2018-11-21 06:22:20 --> Config Class Initialized
INFO - 2018-11-21 06:22:20 --> Hooks Class Initialized
DEBUG - 2018-11-21 06:22:20 --> UTF-8 Support Enabled
INFO - 2018-11-21 06:22:20 --> Utf8 Class Initialized
INFO - 2018-11-21 06:22:20 --> URI Class Initialized
INFO - 2018-11-21 06:22:20 --> Router Class Initialized
INFO - 2018-11-21 06:22:20 --> Output Class Initialized
INFO - 2018-11-21 06:22:20 --> Security Class Initialized
DEBUG - 2018-11-21 06:22:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-21 06:22:20 --> Input Class Initialized
INFO - 2018-11-21 06:22:20 --> Language Class Initialized
INFO - 2018-11-21 06:22:20 --> Loader Class Initialized
INFO - 2018-11-21 06:22:20 --> Helper loaded: url_helper
INFO - 2018-11-21 06:22:20 --> Helper loaded: file_helper
INFO - 2018-11-21 06:22:20 --> Helper loaded: email_helper
INFO - 2018-11-21 06:22:20 --> Helper loaded: common_helper
INFO - 2018-11-21 06:22:20 --> Database Driver Class Initialized
DEBUG - 2018-11-21 06:22:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-21 06:22:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-21 06:22:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-21 06:22:20 --> Pagination Class Initialized
INFO - 2018-11-21 06:22:20 --> Helper loaded: form_helper
INFO - 2018-11-21 06:22:20 --> Form Validation Class Initialized
INFO - 2018-11-21 06:22:20 --> Model Class Initialized
INFO - 2018-11-21 06:22:20 --> Controller Class Initialized
INFO - 2018-11-21 06:22:20 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-21 06:22:20 --> Model Class Initialized
INFO - 2018-11-21 06:22:20 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-21 06:22:20 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/sidebar.php
INFO - 2018-11-21 06:22:20 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/right-sidebar.php
INFO - 2018-11-21 06:22:20 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/footer.php
INFO - 2018-11-21 06:22:20 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/dashboard.php
INFO - 2018-11-21 06:22:20 --> Final output sent to browser
DEBUG - 2018-11-21 06:22:20 --> Total execution time: 0.0540
INFO - 2018-11-21 06:23:02 --> Config Class Initialized
INFO - 2018-11-21 06:23:02 --> Hooks Class Initialized
DEBUG - 2018-11-21 06:23:02 --> UTF-8 Support Enabled
INFO - 2018-11-21 06:23:02 --> Utf8 Class Initialized
INFO - 2018-11-21 06:23:02 --> URI Class Initialized
INFO - 2018-11-21 06:23:02 --> Router Class Initialized
INFO - 2018-11-21 06:23:02 --> Output Class Initialized
INFO - 2018-11-21 06:23:02 --> Security Class Initialized
DEBUG - 2018-11-21 06:23:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-21 06:23:02 --> Input Class Initialized
INFO - 2018-11-21 06:23:02 --> Language Class Initialized
INFO - 2018-11-21 06:23:02 --> Loader Class Initialized
INFO - 2018-11-21 06:23:02 --> Helper loaded: url_helper
INFO - 2018-11-21 06:23:02 --> Helper loaded: file_helper
INFO - 2018-11-21 06:23:02 --> Helper loaded: email_helper
INFO - 2018-11-21 06:23:02 --> Helper loaded: common_helper
INFO - 2018-11-21 06:23:02 --> Database Driver Class Initialized
DEBUG - 2018-11-21 06:23:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-21 06:23:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-21 06:23:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-21 06:23:02 --> Pagination Class Initialized
INFO - 2018-11-21 06:23:02 --> Helper loaded: form_helper
INFO - 2018-11-21 06:23:02 --> Form Validation Class Initialized
INFO - 2018-11-21 06:23:02 --> Model Class Initialized
INFO - 2018-11-21 06:23:02 --> Controller Class Initialized
INFO - 2018-11-21 06:23:02 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-21 06:23:02 --> Model Class Initialized
INFO - 2018-11-21 06:23:02 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-21 06:23:02 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/sidebar.php
INFO - 2018-11-21 06:23:02 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/right-sidebar.php
INFO - 2018-11-21 06:23:02 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/footer.php
INFO - 2018-11-21 06:23:02 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/dashboard.php
INFO - 2018-11-21 06:23:02 --> Final output sent to browser
DEBUG - 2018-11-21 06:23:02 --> Total execution time: 0.0510
INFO - 2018-11-21 06:24:01 --> Config Class Initialized
INFO - 2018-11-21 06:24:01 --> Hooks Class Initialized
DEBUG - 2018-11-21 06:24:01 --> UTF-8 Support Enabled
INFO - 2018-11-21 06:24:01 --> Utf8 Class Initialized
INFO - 2018-11-21 06:24:01 --> URI Class Initialized
INFO - 2018-11-21 06:24:01 --> Router Class Initialized
INFO - 2018-11-21 06:24:01 --> Output Class Initialized
INFO - 2018-11-21 06:24:01 --> Security Class Initialized
DEBUG - 2018-11-21 06:24:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-21 06:24:01 --> Input Class Initialized
INFO - 2018-11-21 06:24:01 --> Language Class Initialized
INFO - 2018-11-21 06:24:01 --> Loader Class Initialized
INFO - 2018-11-21 06:24:01 --> Helper loaded: url_helper
INFO - 2018-11-21 06:24:01 --> Helper loaded: file_helper
INFO - 2018-11-21 06:24:01 --> Helper loaded: email_helper
INFO - 2018-11-21 06:24:01 --> Helper loaded: common_helper
INFO - 2018-11-21 06:24:01 --> Database Driver Class Initialized
DEBUG - 2018-11-21 06:24:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-21 06:24:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-21 06:24:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-21 06:24:01 --> Pagination Class Initialized
INFO - 2018-11-21 06:24:01 --> Helper loaded: form_helper
INFO - 2018-11-21 06:24:01 --> Form Validation Class Initialized
INFO - 2018-11-21 06:24:01 --> Model Class Initialized
INFO - 2018-11-21 06:24:01 --> Controller Class Initialized
INFO - 2018-11-21 06:24:01 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-21 06:24:01 --> Model Class Initialized
INFO - 2018-11-21 06:24:01 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-21 06:24:01 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/sidebar.php
INFO - 2018-11-21 06:24:01 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/right-sidebar.php
INFO - 2018-11-21 06:24:01 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/footer.php
INFO - 2018-11-21 06:24:01 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/dashboard.php
INFO - 2018-11-21 06:24:01 --> Final output sent to browser
DEBUG - 2018-11-21 06:24:01 --> Total execution time: 0.0480
INFO - 2018-11-21 06:24:51 --> Config Class Initialized
INFO - 2018-11-21 06:24:51 --> Hooks Class Initialized
DEBUG - 2018-11-21 06:24:51 --> UTF-8 Support Enabled
INFO - 2018-11-21 06:24:51 --> Utf8 Class Initialized
INFO - 2018-11-21 06:24:51 --> URI Class Initialized
INFO - 2018-11-21 06:24:51 --> Router Class Initialized
INFO - 2018-11-21 06:24:51 --> Output Class Initialized
INFO - 2018-11-21 06:24:51 --> Security Class Initialized
DEBUG - 2018-11-21 06:24:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-21 06:24:51 --> Input Class Initialized
INFO - 2018-11-21 06:24:51 --> Language Class Initialized
INFO - 2018-11-21 06:24:51 --> Loader Class Initialized
INFO - 2018-11-21 06:24:51 --> Helper loaded: url_helper
INFO - 2018-11-21 06:24:51 --> Helper loaded: file_helper
INFO - 2018-11-21 06:24:51 --> Helper loaded: email_helper
INFO - 2018-11-21 06:24:51 --> Helper loaded: common_helper
INFO - 2018-11-21 06:24:51 --> Database Driver Class Initialized
DEBUG - 2018-11-21 06:24:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-21 06:24:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-21 06:24:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-21 06:24:51 --> Pagination Class Initialized
INFO - 2018-11-21 06:24:51 --> Helper loaded: form_helper
INFO - 2018-11-21 06:24:51 --> Form Validation Class Initialized
INFO - 2018-11-21 06:24:51 --> Model Class Initialized
INFO - 2018-11-21 06:24:51 --> Controller Class Initialized
INFO - 2018-11-21 06:24:51 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-21 06:24:51 --> Model Class Initialized
INFO - 2018-11-21 06:24:51 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-21 06:24:51 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/sidebar.php
INFO - 2018-11-21 06:24:51 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/right-sidebar.php
INFO - 2018-11-21 06:24:51 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/footer.php
INFO - 2018-11-21 06:24:51 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/dashboard.php
INFO - 2018-11-21 06:24:51 --> Final output sent to browser
DEBUG - 2018-11-21 06:24:51 --> Total execution time: 0.0490
INFO - 2018-11-21 06:26:22 --> Config Class Initialized
INFO - 2018-11-21 06:26:22 --> Hooks Class Initialized
DEBUG - 2018-11-21 06:26:22 --> UTF-8 Support Enabled
INFO - 2018-11-21 06:26:22 --> Utf8 Class Initialized
INFO - 2018-11-21 06:26:22 --> URI Class Initialized
INFO - 2018-11-21 06:26:22 --> Router Class Initialized
INFO - 2018-11-21 06:26:22 --> Output Class Initialized
INFO - 2018-11-21 06:26:22 --> Security Class Initialized
DEBUG - 2018-11-21 06:26:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-21 06:26:22 --> Input Class Initialized
INFO - 2018-11-21 06:26:22 --> Language Class Initialized
INFO - 2018-11-21 06:26:22 --> Loader Class Initialized
INFO - 2018-11-21 06:26:22 --> Helper loaded: url_helper
INFO - 2018-11-21 06:26:22 --> Helper loaded: file_helper
INFO - 2018-11-21 06:26:22 --> Helper loaded: email_helper
INFO - 2018-11-21 06:26:22 --> Helper loaded: common_helper
INFO - 2018-11-21 06:26:22 --> Database Driver Class Initialized
DEBUG - 2018-11-21 06:26:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-21 06:26:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-21 06:26:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-21 06:26:22 --> Pagination Class Initialized
INFO - 2018-11-21 06:26:22 --> Helper loaded: form_helper
INFO - 2018-11-21 06:26:22 --> Form Validation Class Initialized
INFO - 2018-11-21 06:26:22 --> Model Class Initialized
INFO - 2018-11-21 06:26:22 --> Controller Class Initialized
INFO - 2018-11-21 06:26:22 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-21 06:26:22 --> Model Class Initialized
INFO - 2018-11-21 06:26:22 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-21 06:26:22 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/sidebar.php
INFO - 2018-11-21 06:26:22 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/right-sidebar.php
INFO - 2018-11-21 06:26:22 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/footer.php
INFO - 2018-11-21 06:26:22 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/dashboard.php
INFO - 2018-11-21 06:26:22 --> Final output sent to browser
DEBUG - 2018-11-21 06:26:22 --> Total execution time: 0.0610
INFO - 2018-11-21 06:27:09 --> Config Class Initialized
INFO - 2018-11-21 06:27:09 --> Hooks Class Initialized
DEBUG - 2018-11-21 06:27:09 --> UTF-8 Support Enabled
INFO - 2018-11-21 06:27:09 --> Utf8 Class Initialized
INFO - 2018-11-21 06:27:09 --> URI Class Initialized
INFO - 2018-11-21 06:27:09 --> Router Class Initialized
INFO - 2018-11-21 06:27:09 --> Output Class Initialized
INFO - 2018-11-21 06:27:09 --> Security Class Initialized
DEBUG - 2018-11-21 06:27:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-21 06:27:09 --> Input Class Initialized
INFO - 2018-11-21 06:27:09 --> Language Class Initialized
INFO - 2018-11-21 06:27:09 --> Loader Class Initialized
INFO - 2018-11-21 06:27:09 --> Helper loaded: url_helper
INFO - 2018-11-21 06:27:09 --> Helper loaded: file_helper
INFO - 2018-11-21 06:27:09 --> Helper loaded: email_helper
INFO - 2018-11-21 06:27:09 --> Helper loaded: common_helper
INFO - 2018-11-21 06:27:09 --> Database Driver Class Initialized
DEBUG - 2018-11-21 06:27:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-21 06:27:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-21 06:27:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-21 06:27:09 --> Pagination Class Initialized
INFO - 2018-11-21 06:27:09 --> Helper loaded: form_helper
INFO - 2018-11-21 06:27:09 --> Form Validation Class Initialized
INFO - 2018-11-21 06:27:09 --> Model Class Initialized
INFO - 2018-11-21 06:27:09 --> Controller Class Initialized
INFO - 2018-11-21 06:27:09 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-21 06:27:09 --> Model Class Initialized
INFO - 2018-11-21 06:27:09 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-21 06:27:09 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/sidebar.php
INFO - 2018-11-21 06:27:09 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/right-sidebar.php
INFO - 2018-11-21 06:27:09 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/footer.php
INFO - 2018-11-21 06:27:09 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/dashboard.php
INFO - 2018-11-21 06:27:09 --> Final output sent to browser
DEBUG - 2018-11-21 06:27:09 --> Total execution time: 0.0480
INFO - 2018-11-21 06:27:24 --> Config Class Initialized
INFO - 2018-11-21 06:27:24 --> Hooks Class Initialized
DEBUG - 2018-11-21 06:27:24 --> UTF-8 Support Enabled
INFO - 2018-11-21 06:27:24 --> Utf8 Class Initialized
INFO - 2018-11-21 06:27:24 --> URI Class Initialized
INFO - 2018-11-21 06:27:24 --> Router Class Initialized
INFO - 2018-11-21 06:27:24 --> Output Class Initialized
INFO - 2018-11-21 06:27:24 --> Security Class Initialized
DEBUG - 2018-11-21 06:27:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-21 06:27:24 --> Input Class Initialized
INFO - 2018-11-21 06:27:24 --> Language Class Initialized
INFO - 2018-11-21 06:27:24 --> Loader Class Initialized
INFO - 2018-11-21 06:27:24 --> Helper loaded: url_helper
INFO - 2018-11-21 06:27:24 --> Helper loaded: file_helper
INFO - 2018-11-21 06:27:24 --> Helper loaded: email_helper
INFO - 2018-11-21 06:27:24 --> Helper loaded: common_helper
INFO - 2018-11-21 06:27:24 --> Database Driver Class Initialized
DEBUG - 2018-11-21 06:27:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-21 06:27:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-21 06:27:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-21 06:27:24 --> Pagination Class Initialized
INFO - 2018-11-21 06:27:24 --> Helper loaded: form_helper
INFO - 2018-11-21 06:27:24 --> Form Validation Class Initialized
INFO - 2018-11-21 06:27:24 --> Model Class Initialized
INFO - 2018-11-21 06:27:24 --> Controller Class Initialized
INFO - 2018-11-21 06:27:24 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-21 06:27:24 --> Model Class Initialized
INFO - 2018-11-21 06:27:24 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-21 06:27:24 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/sidebar.php
INFO - 2018-11-21 06:27:24 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/right-sidebar.php
INFO - 2018-11-21 06:27:24 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/footer.php
INFO - 2018-11-21 06:27:24 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/dashboard.php
INFO - 2018-11-21 06:27:24 --> Final output sent to browser
DEBUG - 2018-11-21 06:27:24 --> Total execution time: 0.0460
INFO - 2018-11-21 07:05:31 --> Config Class Initialized
INFO - 2018-11-21 07:05:31 --> Hooks Class Initialized
DEBUG - 2018-11-21 07:05:31 --> UTF-8 Support Enabled
INFO - 2018-11-21 07:05:31 --> Utf8 Class Initialized
INFO - 2018-11-21 07:05:31 --> URI Class Initialized
INFO - 2018-11-21 07:05:31 --> Router Class Initialized
INFO - 2018-11-21 07:05:31 --> Output Class Initialized
INFO - 2018-11-21 07:05:31 --> Security Class Initialized
DEBUG - 2018-11-21 07:05:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-21 07:05:31 --> Input Class Initialized
INFO - 2018-11-21 07:05:31 --> Language Class Initialized
INFO - 2018-11-21 07:05:31 --> Loader Class Initialized
INFO - 2018-11-21 07:05:31 --> Helper loaded: url_helper
INFO - 2018-11-21 07:05:31 --> Helper loaded: file_helper
INFO - 2018-11-21 07:05:31 --> Helper loaded: email_helper
INFO - 2018-11-21 07:05:31 --> Helper loaded: common_helper
INFO - 2018-11-21 07:05:31 --> Database Driver Class Initialized
DEBUG - 2018-11-21 07:05:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-21 07:05:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-21 07:05:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-21 07:05:31 --> Pagination Class Initialized
INFO - 2018-11-21 07:05:31 --> Helper loaded: form_helper
INFO - 2018-11-21 07:05:31 --> Form Validation Class Initialized
INFO - 2018-11-21 07:05:31 --> Model Class Initialized
INFO - 2018-11-21 07:05:31 --> Controller Class Initialized
INFO - 2018-11-21 07:05:31 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-21 07:05:31 --> Model Class Initialized
INFO - 2018-11-21 07:05:31 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-21 07:05:31 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/sidebar.php
INFO - 2018-11-21 07:05:31 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/right-sidebar.php
INFO - 2018-11-21 07:05:31 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/footer.php
INFO - 2018-11-21 07:05:31 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/dashboard.php
INFO - 2018-11-21 07:05:31 --> Final output sent to browser
DEBUG - 2018-11-21 07:05:31 --> Total execution time: 0.0580
INFO - 2018-11-21 07:05:42 --> Config Class Initialized
INFO - 2018-11-21 07:05:42 --> Hooks Class Initialized
DEBUG - 2018-11-21 07:05:42 --> UTF-8 Support Enabled
INFO - 2018-11-21 07:05:42 --> Utf8 Class Initialized
INFO - 2018-11-21 07:05:42 --> URI Class Initialized
INFO - 2018-11-21 07:05:42 --> Router Class Initialized
INFO - 2018-11-21 07:05:42 --> Output Class Initialized
INFO - 2018-11-21 07:05:42 --> Security Class Initialized
DEBUG - 2018-11-21 07:05:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-21 07:05:42 --> Input Class Initialized
INFO - 2018-11-21 07:05:42 --> Language Class Initialized
INFO - 2018-11-21 07:05:42 --> Loader Class Initialized
INFO - 2018-11-21 07:05:42 --> Helper loaded: url_helper
INFO - 2018-11-21 07:05:42 --> Helper loaded: file_helper
INFO - 2018-11-21 07:05:42 --> Helper loaded: email_helper
INFO - 2018-11-21 07:05:42 --> Helper loaded: common_helper
INFO - 2018-11-21 07:05:42 --> Database Driver Class Initialized
DEBUG - 2018-11-21 07:05:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-21 07:05:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-21 07:05:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-21 07:05:42 --> Pagination Class Initialized
INFO - 2018-11-21 07:05:42 --> Helper loaded: form_helper
INFO - 2018-11-21 07:05:42 --> Form Validation Class Initialized
INFO - 2018-11-21 07:05:42 --> Model Class Initialized
INFO - 2018-11-21 07:05:42 --> Controller Class Initialized
INFO - 2018-11-21 07:05:42 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-21 07:05:42 --> Model Class Initialized
INFO - 2018-11-21 07:05:42 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-21 07:05:42 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/sidebar.php
INFO - 2018-11-21 07:05:42 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/right-sidebar.php
INFO - 2018-11-21 07:05:42 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/footer.php
INFO - 2018-11-21 07:05:42 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/dashboard.php
INFO - 2018-11-21 07:05:42 --> Final output sent to browser
DEBUG - 2018-11-21 07:05:42 --> Total execution time: 0.0490
INFO - 2018-11-21 07:05:53 --> Config Class Initialized
INFO - 2018-11-21 07:05:53 --> Hooks Class Initialized
DEBUG - 2018-11-21 07:05:53 --> UTF-8 Support Enabled
INFO - 2018-11-21 07:05:53 --> Utf8 Class Initialized
INFO - 2018-11-21 07:05:53 --> URI Class Initialized
INFO - 2018-11-21 07:05:53 --> Router Class Initialized
INFO - 2018-11-21 07:05:53 --> Output Class Initialized
INFO - 2018-11-21 07:05:53 --> Security Class Initialized
DEBUG - 2018-11-21 07:05:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-21 07:05:53 --> Input Class Initialized
INFO - 2018-11-21 07:05:53 --> Language Class Initialized
INFO - 2018-11-21 07:05:53 --> Loader Class Initialized
INFO - 2018-11-21 07:05:53 --> Helper loaded: url_helper
INFO - 2018-11-21 07:05:53 --> Helper loaded: file_helper
INFO - 2018-11-21 07:05:53 --> Helper loaded: email_helper
INFO - 2018-11-21 07:05:53 --> Helper loaded: common_helper
INFO - 2018-11-21 07:05:53 --> Database Driver Class Initialized
DEBUG - 2018-11-21 07:05:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-21 07:05:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-21 07:05:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-21 07:05:53 --> Pagination Class Initialized
INFO - 2018-11-21 07:05:53 --> Helper loaded: form_helper
INFO - 2018-11-21 07:05:53 --> Form Validation Class Initialized
INFO - 2018-11-21 07:05:53 --> Model Class Initialized
INFO - 2018-11-21 07:05:53 --> Controller Class Initialized
INFO - 2018-11-21 07:05:53 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-21 07:05:53 --> Model Class Initialized
INFO - 2018-11-21 07:05:53 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-21 07:05:53 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/sidebar.php
INFO - 2018-11-21 07:05:53 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/right-sidebar.php
INFO - 2018-11-21 07:05:53 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/footer.php
INFO - 2018-11-21 07:05:53 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/dashboard.php
INFO - 2018-11-21 07:05:53 --> Final output sent to browser
DEBUG - 2018-11-21 07:05:53 --> Total execution time: 0.0710
INFO - 2018-11-21 07:06:23 --> Config Class Initialized
INFO - 2018-11-21 07:06:23 --> Hooks Class Initialized
DEBUG - 2018-11-21 07:06:23 --> UTF-8 Support Enabled
INFO - 2018-11-21 07:06:23 --> Utf8 Class Initialized
INFO - 2018-11-21 07:06:23 --> URI Class Initialized
INFO - 2018-11-21 07:06:23 --> Router Class Initialized
INFO - 2018-11-21 07:06:23 --> Output Class Initialized
INFO - 2018-11-21 07:06:23 --> Security Class Initialized
DEBUG - 2018-11-21 07:06:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-21 07:06:23 --> Input Class Initialized
INFO - 2018-11-21 07:06:23 --> Language Class Initialized
INFO - 2018-11-21 07:06:23 --> Loader Class Initialized
INFO - 2018-11-21 07:06:23 --> Helper loaded: url_helper
INFO - 2018-11-21 07:06:23 --> Helper loaded: file_helper
INFO - 2018-11-21 07:06:23 --> Helper loaded: email_helper
INFO - 2018-11-21 07:06:23 --> Helper loaded: common_helper
INFO - 2018-11-21 07:06:23 --> Database Driver Class Initialized
DEBUG - 2018-11-21 07:06:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-21 07:06:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-21 07:06:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-21 07:06:23 --> Pagination Class Initialized
INFO - 2018-11-21 07:06:23 --> Helper loaded: form_helper
INFO - 2018-11-21 07:06:23 --> Form Validation Class Initialized
INFO - 2018-11-21 07:06:23 --> Model Class Initialized
INFO - 2018-11-21 07:06:23 --> Controller Class Initialized
INFO - 2018-11-21 07:06:23 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-21 07:06:23 --> Model Class Initialized
INFO - 2018-11-21 07:06:23 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-21 07:06:23 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/sidebar.php
INFO - 2018-11-21 07:06:23 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/right-sidebar.php
INFO - 2018-11-21 07:06:23 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/footer.php
INFO - 2018-11-21 07:06:23 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/dashboard.php
INFO - 2018-11-21 07:06:23 --> Final output sent to browser
DEBUG - 2018-11-21 07:06:23 --> Total execution time: 0.0590
INFO - 2018-11-21 07:07:53 --> Config Class Initialized
INFO - 2018-11-21 07:07:53 --> Hooks Class Initialized
DEBUG - 2018-11-21 07:07:53 --> UTF-8 Support Enabled
INFO - 2018-11-21 07:07:53 --> Utf8 Class Initialized
INFO - 2018-11-21 07:07:53 --> URI Class Initialized
INFO - 2018-11-21 07:07:53 --> Router Class Initialized
INFO - 2018-11-21 07:07:53 --> Output Class Initialized
INFO - 2018-11-21 07:07:53 --> Security Class Initialized
DEBUG - 2018-11-21 07:07:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-21 07:07:53 --> Input Class Initialized
INFO - 2018-11-21 07:07:53 --> Language Class Initialized
INFO - 2018-11-21 07:07:53 --> Loader Class Initialized
INFO - 2018-11-21 07:07:53 --> Helper loaded: url_helper
INFO - 2018-11-21 07:07:53 --> Helper loaded: file_helper
INFO - 2018-11-21 07:07:53 --> Helper loaded: email_helper
INFO - 2018-11-21 07:07:53 --> Helper loaded: common_helper
INFO - 2018-11-21 07:07:53 --> Database Driver Class Initialized
DEBUG - 2018-11-21 07:07:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-21 07:07:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-21 07:07:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-21 07:07:53 --> Pagination Class Initialized
INFO - 2018-11-21 07:07:53 --> Helper loaded: form_helper
INFO - 2018-11-21 07:07:53 --> Form Validation Class Initialized
INFO - 2018-11-21 07:07:53 --> Model Class Initialized
INFO - 2018-11-21 07:07:53 --> Controller Class Initialized
INFO - 2018-11-21 07:07:53 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-21 07:07:53 --> Model Class Initialized
INFO - 2018-11-21 07:07:53 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-21 07:07:53 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/sidebar.php
INFO - 2018-11-21 07:07:53 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/right-sidebar.php
INFO - 2018-11-21 07:07:53 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/footer.php
INFO - 2018-11-21 07:07:53 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/dashboard.php
INFO - 2018-11-21 07:07:53 --> Final output sent to browser
DEBUG - 2018-11-21 07:07:53 --> Total execution time: 0.0500
INFO - 2018-11-21 07:10:11 --> Config Class Initialized
INFO - 2018-11-21 07:10:11 --> Hooks Class Initialized
DEBUG - 2018-11-21 07:10:11 --> UTF-8 Support Enabled
INFO - 2018-11-21 07:10:11 --> Utf8 Class Initialized
INFO - 2018-11-21 07:10:11 --> URI Class Initialized
INFO - 2018-11-21 07:10:11 --> Router Class Initialized
INFO - 2018-11-21 07:10:11 --> Output Class Initialized
INFO - 2018-11-21 07:10:11 --> Security Class Initialized
DEBUG - 2018-11-21 07:10:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-21 07:10:11 --> Input Class Initialized
INFO - 2018-11-21 07:10:11 --> Language Class Initialized
INFO - 2018-11-21 07:10:11 --> Loader Class Initialized
INFO - 2018-11-21 07:10:11 --> Helper loaded: url_helper
INFO - 2018-11-21 07:10:11 --> Helper loaded: file_helper
INFO - 2018-11-21 07:10:11 --> Helper loaded: email_helper
INFO - 2018-11-21 07:10:11 --> Helper loaded: common_helper
INFO - 2018-11-21 07:10:11 --> Database Driver Class Initialized
DEBUG - 2018-11-21 07:10:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-21 07:10:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-21 07:10:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-21 07:10:11 --> Pagination Class Initialized
INFO - 2018-11-21 07:10:11 --> Helper loaded: form_helper
INFO - 2018-11-21 07:10:11 --> Form Validation Class Initialized
INFO - 2018-11-21 07:10:11 --> Model Class Initialized
INFO - 2018-11-21 07:10:11 --> Controller Class Initialized
INFO - 2018-11-21 07:10:11 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-21 07:10:11 --> Model Class Initialized
INFO - 2018-11-21 07:10:11 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-21 07:10:11 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/sidebar.php
INFO - 2018-11-21 07:10:11 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/right-sidebar.php
INFO - 2018-11-21 07:10:11 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/footer.php
INFO - 2018-11-21 07:10:11 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/dashboard.php
INFO - 2018-11-21 07:10:11 --> Final output sent to browser
DEBUG - 2018-11-21 07:10:11 --> Total execution time: 0.0490
INFO - 2018-11-21 07:10:16 --> Config Class Initialized
INFO - 2018-11-21 07:10:16 --> Hooks Class Initialized
DEBUG - 2018-11-21 07:10:16 --> UTF-8 Support Enabled
INFO - 2018-11-21 07:10:16 --> Utf8 Class Initialized
INFO - 2018-11-21 07:10:16 --> URI Class Initialized
INFO - 2018-11-21 07:10:16 --> Router Class Initialized
INFO - 2018-11-21 07:10:16 --> Output Class Initialized
INFO - 2018-11-21 07:10:16 --> Security Class Initialized
DEBUG - 2018-11-21 07:10:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-21 07:10:16 --> Input Class Initialized
INFO - 2018-11-21 07:10:16 --> Language Class Initialized
ERROR - 2018-11-21 07:10:16 --> 404 Page Not Found: admin/Admin/change-pasword
INFO - 2018-11-21 07:10:31 --> Config Class Initialized
INFO - 2018-11-21 07:10:31 --> Hooks Class Initialized
DEBUG - 2018-11-21 07:10:31 --> UTF-8 Support Enabled
INFO - 2018-11-21 07:10:31 --> Utf8 Class Initialized
INFO - 2018-11-21 07:10:31 --> URI Class Initialized
INFO - 2018-11-21 07:10:31 --> Router Class Initialized
INFO - 2018-11-21 07:10:31 --> Output Class Initialized
INFO - 2018-11-21 07:10:31 --> Security Class Initialized
DEBUG - 2018-11-21 07:10:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-21 07:10:31 --> Input Class Initialized
INFO - 2018-11-21 07:10:31 --> Language Class Initialized
ERROR - 2018-11-21 07:10:31 --> 404 Page Not Found: admin/Admin/change_pasword
INFO - 2018-11-21 07:10:34 --> Config Class Initialized
INFO - 2018-11-21 07:10:34 --> Hooks Class Initialized
DEBUG - 2018-11-21 07:10:34 --> UTF-8 Support Enabled
INFO - 2018-11-21 07:10:34 --> Utf8 Class Initialized
INFO - 2018-11-21 07:10:34 --> URI Class Initialized
INFO - 2018-11-21 07:10:34 --> Router Class Initialized
INFO - 2018-11-21 07:10:34 --> Output Class Initialized
INFO - 2018-11-21 07:10:34 --> Security Class Initialized
DEBUG - 2018-11-21 07:10:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-21 07:10:34 --> Input Class Initialized
INFO - 2018-11-21 07:10:34 --> Language Class Initialized
ERROR - 2018-11-21 07:10:34 --> 404 Page Not Found: admin/Admin/change_pasword
INFO - 2018-11-21 07:14:36 --> Config Class Initialized
INFO - 2018-11-21 07:14:36 --> Hooks Class Initialized
DEBUG - 2018-11-21 07:14:36 --> UTF-8 Support Enabled
INFO - 2018-11-21 07:14:36 --> Utf8 Class Initialized
INFO - 2018-11-21 07:14:36 --> URI Class Initialized
INFO - 2018-11-21 07:14:36 --> Router Class Initialized
INFO - 2018-11-21 07:14:36 --> Output Class Initialized
INFO - 2018-11-21 07:14:36 --> Security Class Initialized
DEBUG - 2018-11-21 07:14:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-21 07:14:36 --> Input Class Initialized
INFO - 2018-11-21 07:14:36 --> Language Class Initialized
ERROR - 2018-11-21 07:14:36 --> 404 Page Not Found: admin/Change_pasword/index
INFO - 2018-11-21 07:14:39 --> Config Class Initialized
INFO - 2018-11-21 07:14:39 --> Hooks Class Initialized
DEBUG - 2018-11-21 07:14:39 --> UTF-8 Support Enabled
INFO - 2018-11-21 07:14:39 --> Utf8 Class Initialized
INFO - 2018-11-21 07:14:39 --> URI Class Initialized
INFO - 2018-11-21 07:14:39 --> Router Class Initialized
INFO - 2018-11-21 07:14:39 --> Output Class Initialized
INFO - 2018-11-21 07:14:39 --> Security Class Initialized
DEBUG - 2018-11-21 07:14:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-21 07:14:39 --> Input Class Initialized
INFO - 2018-11-21 07:14:39 --> Language Class Initialized
ERROR - 2018-11-21 07:14:39 --> 404 Page Not Found: admin/Change_pasword/index
INFO - 2018-11-21 07:14:39 --> Config Class Initialized
INFO - 2018-11-21 07:14:39 --> Hooks Class Initialized
DEBUG - 2018-11-21 07:14:39 --> UTF-8 Support Enabled
INFO - 2018-11-21 07:14:39 --> Utf8 Class Initialized
INFO - 2018-11-21 07:14:39 --> URI Class Initialized
INFO - 2018-11-21 07:14:39 --> Router Class Initialized
INFO - 2018-11-21 07:14:39 --> Output Class Initialized
INFO - 2018-11-21 07:14:39 --> Security Class Initialized
DEBUG - 2018-11-21 07:14:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-21 07:14:39 --> Input Class Initialized
INFO - 2018-11-21 07:14:39 --> Language Class Initialized
ERROR - 2018-11-21 07:14:39 --> 404 Page Not Found: admin/Change_pasword/index
INFO - 2018-11-21 07:14:39 --> Config Class Initialized
INFO - 2018-11-21 07:14:39 --> Hooks Class Initialized
DEBUG - 2018-11-21 07:14:39 --> UTF-8 Support Enabled
INFO - 2018-11-21 07:14:39 --> Utf8 Class Initialized
INFO - 2018-11-21 07:14:39 --> URI Class Initialized
INFO - 2018-11-21 07:14:39 --> Router Class Initialized
INFO - 2018-11-21 07:14:39 --> Output Class Initialized
INFO - 2018-11-21 07:14:39 --> Security Class Initialized
DEBUG - 2018-11-21 07:14:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-21 07:14:39 --> Input Class Initialized
INFO - 2018-11-21 07:14:39 --> Language Class Initialized
ERROR - 2018-11-21 07:14:39 --> 404 Page Not Found: admin/Change_pasword/index
INFO - 2018-11-21 07:14:39 --> Config Class Initialized
INFO - 2018-11-21 07:14:39 --> Hooks Class Initialized
DEBUG - 2018-11-21 07:14:39 --> UTF-8 Support Enabled
INFO - 2018-11-21 07:14:39 --> Utf8 Class Initialized
INFO - 2018-11-21 07:14:39 --> URI Class Initialized
INFO - 2018-11-21 07:14:39 --> Router Class Initialized
INFO - 2018-11-21 07:14:39 --> Output Class Initialized
INFO - 2018-11-21 07:14:39 --> Security Class Initialized
DEBUG - 2018-11-21 07:14:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-21 07:14:39 --> Input Class Initialized
INFO - 2018-11-21 07:14:39 --> Language Class Initialized
ERROR - 2018-11-21 07:14:39 --> 404 Page Not Found: admin/Change_pasword/index
INFO - 2018-11-21 07:14:42 --> Config Class Initialized
INFO - 2018-11-21 07:14:42 --> Hooks Class Initialized
DEBUG - 2018-11-21 07:14:42 --> UTF-8 Support Enabled
INFO - 2018-11-21 07:14:42 --> Utf8 Class Initialized
INFO - 2018-11-21 07:14:42 --> URI Class Initialized
INFO - 2018-11-21 07:14:42 --> Router Class Initialized
INFO - 2018-11-21 07:14:42 --> Output Class Initialized
INFO - 2018-11-21 07:14:42 --> Security Class Initialized
DEBUG - 2018-11-21 07:14:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-21 07:14:42 --> Input Class Initialized
INFO - 2018-11-21 07:14:42 --> Language Class Initialized
ERROR - 2018-11-21 07:14:42 --> 404 Page Not Found: admin/Change_pasword/index
INFO - 2018-11-21 07:14:49 --> Config Class Initialized
INFO - 2018-11-21 07:14:49 --> Hooks Class Initialized
DEBUG - 2018-11-21 07:14:49 --> UTF-8 Support Enabled
INFO - 2018-11-21 07:14:49 --> Utf8 Class Initialized
INFO - 2018-11-21 07:14:49 --> URI Class Initialized
INFO - 2018-11-21 07:14:49 --> Router Class Initialized
INFO - 2018-11-21 07:14:49 --> Output Class Initialized
INFO - 2018-11-21 07:14:49 --> Security Class Initialized
DEBUG - 2018-11-21 07:14:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-21 07:14:49 --> Input Class Initialized
INFO - 2018-11-21 07:14:49 --> Language Class Initialized
ERROR - 2018-11-21 07:14:49 --> 404 Page Not Found: admin/Admin/change_pasword
INFO - 2018-11-21 07:14:51 --> Config Class Initialized
INFO - 2018-11-21 07:14:51 --> Hooks Class Initialized
DEBUG - 2018-11-21 07:14:51 --> UTF-8 Support Enabled
INFO - 2018-11-21 07:14:51 --> Utf8 Class Initialized
INFO - 2018-11-21 07:14:51 --> URI Class Initialized
INFO - 2018-11-21 07:14:51 --> Router Class Initialized
INFO - 2018-11-21 07:14:51 --> Output Class Initialized
INFO - 2018-11-21 07:14:51 --> Security Class Initialized
DEBUG - 2018-11-21 07:14:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-21 07:14:51 --> Input Class Initialized
INFO - 2018-11-21 07:14:51 --> Language Class Initialized
ERROR - 2018-11-21 07:14:51 --> 404 Page Not Found: admin/Admin/change_pasword
INFO - 2018-11-21 07:14:51 --> Config Class Initialized
INFO - 2018-11-21 07:14:51 --> Hooks Class Initialized
DEBUG - 2018-11-21 07:14:51 --> UTF-8 Support Enabled
INFO - 2018-11-21 07:14:51 --> Utf8 Class Initialized
INFO - 2018-11-21 07:14:51 --> URI Class Initialized
INFO - 2018-11-21 07:14:51 --> Router Class Initialized
INFO - 2018-11-21 07:14:51 --> Output Class Initialized
INFO - 2018-11-21 07:14:51 --> Security Class Initialized
DEBUG - 2018-11-21 07:14:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-21 07:14:51 --> Input Class Initialized
INFO - 2018-11-21 07:14:51 --> Language Class Initialized
ERROR - 2018-11-21 07:14:51 --> 404 Page Not Found: admin/Admin/change_pasword
INFO - 2018-11-21 07:14:52 --> Config Class Initialized
INFO - 2018-11-21 07:14:52 --> Hooks Class Initialized
DEBUG - 2018-11-21 07:14:52 --> UTF-8 Support Enabled
INFO - 2018-11-21 07:14:52 --> Utf8 Class Initialized
INFO - 2018-11-21 07:14:52 --> URI Class Initialized
INFO - 2018-11-21 07:14:52 --> Router Class Initialized
INFO - 2018-11-21 07:14:52 --> Output Class Initialized
INFO - 2018-11-21 07:14:52 --> Security Class Initialized
DEBUG - 2018-11-21 07:14:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-21 07:14:52 --> Input Class Initialized
INFO - 2018-11-21 07:14:52 --> Language Class Initialized
ERROR - 2018-11-21 07:14:52 --> 404 Page Not Found: admin/Admin/change_pasword
INFO - 2018-11-21 07:16:00 --> Config Class Initialized
INFO - 2018-11-21 07:16:00 --> Hooks Class Initialized
DEBUG - 2018-11-21 07:16:00 --> UTF-8 Support Enabled
INFO - 2018-11-21 07:16:00 --> Utf8 Class Initialized
INFO - 2018-11-21 07:16:00 --> URI Class Initialized
INFO - 2018-11-21 07:16:00 --> Router Class Initialized
INFO - 2018-11-21 07:16:00 --> Output Class Initialized
INFO - 2018-11-21 07:16:00 --> Security Class Initialized
DEBUG - 2018-11-21 07:16:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-21 07:16:00 --> Input Class Initialized
INFO - 2018-11-21 07:16:00 --> Language Class Initialized
ERROR - 2018-11-21 07:16:00 --> 404 Page Not Found: admin/Admin/change_pasword
INFO - 2018-11-21 07:16:02 --> Config Class Initialized
INFO - 2018-11-21 07:16:02 --> Hooks Class Initialized
DEBUG - 2018-11-21 07:16:02 --> UTF-8 Support Enabled
INFO - 2018-11-21 07:16:02 --> Utf8 Class Initialized
INFO - 2018-11-21 07:16:02 --> URI Class Initialized
INFO - 2018-11-21 07:16:02 --> Router Class Initialized
INFO - 2018-11-21 07:16:02 --> Output Class Initialized
INFO - 2018-11-21 07:16:02 --> Security Class Initialized
DEBUG - 2018-11-21 07:16:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-21 07:16:02 --> Input Class Initialized
INFO - 2018-11-21 07:16:02 --> Language Class Initialized
ERROR - 2018-11-21 07:16:02 --> 404 Page Not Found: admin/Admin/change_pasword
INFO - 2018-11-21 07:16:02 --> Config Class Initialized
INFO - 2018-11-21 07:16:02 --> Hooks Class Initialized
DEBUG - 2018-11-21 07:16:02 --> UTF-8 Support Enabled
INFO - 2018-11-21 07:16:02 --> Utf8 Class Initialized
INFO - 2018-11-21 07:16:02 --> URI Class Initialized
INFO - 2018-11-21 07:16:02 --> Router Class Initialized
INFO - 2018-11-21 07:16:02 --> Output Class Initialized
INFO - 2018-11-21 07:16:02 --> Security Class Initialized
DEBUG - 2018-11-21 07:16:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-21 07:16:02 --> Input Class Initialized
INFO - 2018-11-21 07:16:02 --> Language Class Initialized
ERROR - 2018-11-21 07:16:02 --> 404 Page Not Found: admin/Admin/change_pasword
INFO - 2018-11-21 07:16:03 --> Config Class Initialized
INFO - 2018-11-21 07:16:03 --> Hooks Class Initialized
DEBUG - 2018-11-21 07:16:03 --> UTF-8 Support Enabled
INFO - 2018-11-21 07:16:03 --> Utf8 Class Initialized
INFO - 2018-11-21 07:16:03 --> URI Class Initialized
INFO - 2018-11-21 07:16:03 --> Router Class Initialized
INFO - 2018-11-21 07:16:03 --> Output Class Initialized
INFO - 2018-11-21 07:16:03 --> Security Class Initialized
DEBUG - 2018-11-21 07:16:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-21 07:16:03 --> Input Class Initialized
INFO - 2018-11-21 07:16:03 --> Language Class Initialized
ERROR - 2018-11-21 07:16:03 --> 404 Page Not Found: admin/Admin/change_pasword
INFO - 2018-11-21 07:16:03 --> Config Class Initialized
INFO - 2018-11-21 07:16:03 --> Hooks Class Initialized
DEBUG - 2018-11-21 07:16:03 --> UTF-8 Support Enabled
INFO - 2018-11-21 07:16:03 --> Utf8 Class Initialized
INFO - 2018-11-21 07:16:03 --> URI Class Initialized
INFO - 2018-11-21 07:16:03 --> Router Class Initialized
INFO - 2018-11-21 07:16:03 --> Output Class Initialized
INFO - 2018-11-21 07:16:03 --> Security Class Initialized
DEBUG - 2018-11-21 07:16:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-21 07:16:03 --> Input Class Initialized
INFO - 2018-11-21 07:16:03 --> Language Class Initialized
ERROR - 2018-11-21 07:16:03 --> 404 Page Not Found: admin/Admin/change_pasword
INFO - 2018-11-21 07:16:03 --> Config Class Initialized
INFO - 2018-11-21 07:16:03 --> Hooks Class Initialized
DEBUG - 2018-11-21 07:16:03 --> UTF-8 Support Enabled
INFO - 2018-11-21 07:16:03 --> Utf8 Class Initialized
INFO - 2018-11-21 07:16:03 --> URI Class Initialized
INFO - 2018-11-21 07:16:03 --> Router Class Initialized
INFO - 2018-11-21 07:16:03 --> Output Class Initialized
INFO - 2018-11-21 07:16:03 --> Security Class Initialized
DEBUG - 2018-11-21 07:16:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-21 07:16:03 --> Input Class Initialized
INFO - 2018-11-21 07:16:03 --> Language Class Initialized
ERROR - 2018-11-21 07:16:03 --> 404 Page Not Found: admin/Admin/change_pasword
INFO - 2018-11-21 07:16:03 --> Config Class Initialized
INFO - 2018-11-21 07:16:03 --> Hooks Class Initialized
DEBUG - 2018-11-21 07:16:03 --> UTF-8 Support Enabled
INFO - 2018-11-21 07:16:03 --> Utf8 Class Initialized
INFO - 2018-11-21 07:16:03 --> URI Class Initialized
INFO - 2018-11-21 07:16:03 --> Router Class Initialized
INFO - 2018-11-21 07:16:03 --> Output Class Initialized
INFO - 2018-11-21 07:16:03 --> Security Class Initialized
DEBUG - 2018-11-21 07:16:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-21 07:16:03 --> Input Class Initialized
INFO - 2018-11-21 07:16:03 --> Language Class Initialized
ERROR - 2018-11-21 07:16:03 --> 404 Page Not Found: admin/Admin/change_pasword
INFO - 2018-11-21 07:16:17 --> Config Class Initialized
INFO - 2018-11-21 07:16:17 --> Hooks Class Initialized
DEBUG - 2018-11-21 07:16:17 --> UTF-8 Support Enabled
INFO - 2018-11-21 07:16:17 --> Utf8 Class Initialized
INFO - 2018-11-21 07:16:17 --> URI Class Initialized
INFO - 2018-11-21 07:16:17 --> Router Class Initialized
INFO - 2018-11-21 07:16:17 --> Output Class Initialized
INFO - 2018-11-21 07:16:17 --> Security Class Initialized
DEBUG - 2018-11-21 07:16:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-21 07:16:17 --> Input Class Initialized
INFO - 2018-11-21 07:16:17 --> Language Class Initialized
ERROR - 2018-11-21 07:16:17 --> 404 Page Not Found: admin/Admin/change_pasword
INFO - 2018-11-21 07:16:19 --> Config Class Initialized
INFO - 2018-11-21 07:16:19 --> Hooks Class Initialized
DEBUG - 2018-11-21 07:16:19 --> UTF-8 Support Enabled
INFO - 2018-11-21 07:16:19 --> Utf8 Class Initialized
INFO - 2018-11-21 07:16:19 --> URI Class Initialized
INFO - 2018-11-21 07:16:19 --> Router Class Initialized
INFO - 2018-11-21 07:16:19 --> Output Class Initialized
INFO - 2018-11-21 07:16:19 --> Security Class Initialized
DEBUG - 2018-11-21 07:16:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-21 07:16:19 --> Input Class Initialized
INFO - 2018-11-21 07:16:19 --> Language Class Initialized
ERROR - 2018-11-21 07:16:19 --> 404 Page Not Found: admin/Admin/change_pasword
INFO - 2018-11-21 07:16:38 --> Config Class Initialized
INFO - 2018-11-21 07:16:38 --> Hooks Class Initialized
DEBUG - 2018-11-21 07:16:38 --> UTF-8 Support Enabled
INFO - 2018-11-21 07:16:38 --> Utf8 Class Initialized
INFO - 2018-11-21 07:16:38 --> URI Class Initialized
INFO - 2018-11-21 07:16:38 --> Router Class Initialized
INFO - 2018-11-21 07:16:38 --> Output Class Initialized
INFO - 2018-11-21 07:16:38 --> Security Class Initialized
DEBUG - 2018-11-21 07:16:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-21 07:16:38 --> Input Class Initialized
INFO - 2018-11-21 07:16:38 --> Language Class Initialized
ERROR - 2018-11-21 07:16:38 --> 404 Page Not Found: admin/Admin/change_pasword
INFO - 2018-11-21 07:19:51 --> Config Class Initialized
INFO - 2018-11-21 07:19:51 --> Hooks Class Initialized
DEBUG - 2018-11-21 07:19:51 --> UTF-8 Support Enabled
INFO - 2018-11-21 07:19:51 --> Utf8 Class Initialized
INFO - 2018-11-21 07:19:51 --> URI Class Initialized
INFO - 2018-11-21 07:19:51 --> Router Class Initialized
INFO - 2018-11-21 07:19:51 --> Output Class Initialized
INFO - 2018-11-21 07:19:51 --> Security Class Initialized
DEBUG - 2018-11-21 07:19:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-21 07:19:51 --> Input Class Initialized
INFO - 2018-11-21 07:19:51 --> Language Class Initialized
INFO - 2018-11-21 07:19:51 --> Loader Class Initialized
INFO - 2018-11-21 07:19:51 --> Helper loaded: url_helper
INFO - 2018-11-21 07:19:51 --> Helper loaded: file_helper
INFO - 2018-11-21 07:19:51 --> Helper loaded: email_helper
INFO - 2018-11-21 07:19:51 --> Helper loaded: common_helper
INFO - 2018-11-21 07:19:51 --> Database Driver Class Initialized
DEBUG - 2018-11-21 07:19:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-21 07:19:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-21 07:19:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-21 07:19:51 --> Pagination Class Initialized
INFO - 2018-11-21 07:19:51 --> Helper loaded: form_helper
INFO - 2018-11-21 07:19:51 --> Form Validation Class Initialized
INFO - 2018-11-21 07:19:51 --> Model Class Initialized
INFO - 2018-11-21 07:19:51 --> Controller Class Initialized
INFO - 2018-11-21 07:19:51 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-21 07:19:51 --> Model Class Initialized
ERROR - 2018-11-21 07:19:51 --> Severity: Notice --> Undefined index: admin_url C:\xampp\htdocs\wetinuneed\application\views\admin\ample\header.php 223
INFO - 2018-11-21 07:19:51 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-21 07:19:51 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/sidebar.php
INFO - 2018-11-21 07:19:51 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/right-sidebar.php
INFO - 2018-11-21 07:19:51 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/footer.php
INFO - 2018-11-21 07:19:51 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/dashboard.php
INFO - 2018-11-21 07:19:51 --> Final output sent to browser
DEBUG - 2018-11-21 07:19:51 --> Total execution time: 0.0530
INFO - 2018-11-21 07:20:03 --> Config Class Initialized
INFO - 2018-11-21 07:20:03 --> Hooks Class Initialized
DEBUG - 2018-11-21 07:20:03 --> UTF-8 Support Enabled
INFO - 2018-11-21 07:20:03 --> Utf8 Class Initialized
INFO - 2018-11-21 07:20:03 --> URI Class Initialized
INFO - 2018-11-21 07:20:03 --> Router Class Initialized
INFO - 2018-11-21 07:20:03 --> Output Class Initialized
INFO - 2018-11-21 07:20:03 --> Security Class Initialized
DEBUG - 2018-11-21 07:20:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-21 07:20:03 --> Input Class Initialized
INFO - 2018-11-21 07:20:03 --> Language Class Initialized
ERROR - 2018-11-21 07:20:03 --> 404 Page Not Found: admin/Logout/index
INFO - 2018-11-21 07:20:10 --> Config Class Initialized
INFO - 2018-11-21 07:20:10 --> Hooks Class Initialized
DEBUG - 2018-11-21 07:20:10 --> UTF-8 Support Enabled
INFO - 2018-11-21 07:20:10 --> Utf8 Class Initialized
INFO - 2018-11-21 07:20:10 --> URI Class Initialized
INFO - 2018-11-21 07:20:10 --> Router Class Initialized
INFO - 2018-11-21 07:20:10 --> Output Class Initialized
INFO - 2018-11-21 07:20:10 --> Security Class Initialized
DEBUG - 2018-11-21 07:20:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-21 07:20:10 --> Input Class Initialized
INFO - 2018-11-21 07:20:10 --> Language Class Initialized
INFO - 2018-11-21 07:20:10 --> Loader Class Initialized
INFO - 2018-11-21 07:20:10 --> Helper loaded: url_helper
INFO - 2018-11-21 07:20:10 --> Helper loaded: file_helper
INFO - 2018-11-21 07:20:10 --> Helper loaded: email_helper
INFO - 2018-11-21 07:20:10 --> Helper loaded: common_helper
INFO - 2018-11-21 07:20:10 --> Database Driver Class Initialized
DEBUG - 2018-11-21 07:20:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-21 07:20:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-21 07:20:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-21 07:20:10 --> Pagination Class Initialized
INFO - 2018-11-21 07:20:10 --> Helper loaded: form_helper
INFO - 2018-11-21 07:20:10 --> Form Validation Class Initialized
INFO - 2018-11-21 07:20:10 --> Model Class Initialized
INFO - 2018-11-21 07:20:10 --> Controller Class Initialized
INFO - 2018-11-21 07:20:10 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-21 07:20:10 --> Model Class Initialized
INFO - 2018-11-21 07:20:10 --> Model Class Initialized
INFO - 2018-11-21 07:20:10 --> Config Class Initialized
INFO - 2018-11-21 07:20:10 --> Hooks Class Initialized
DEBUG - 2018-11-21 07:20:10 --> UTF-8 Support Enabled
INFO - 2018-11-21 07:20:10 --> Utf8 Class Initialized
INFO - 2018-11-21 07:20:10 --> URI Class Initialized
INFO - 2018-11-21 07:20:10 --> Router Class Initialized
INFO - 2018-11-21 07:20:10 --> Output Class Initialized
INFO - 2018-11-21 07:20:10 --> Security Class Initialized
DEBUG - 2018-11-21 07:20:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-21 07:20:10 --> Input Class Initialized
INFO - 2018-11-21 07:20:10 --> Language Class Initialized
INFO - 2018-11-21 07:20:10 --> Loader Class Initialized
INFO - 2018-11-21 07:20:10 --> Helper loaded: url_helper
INFO - 2018-11-21 07:20:10 --> Helper loaded: file_helper
INFO - 2018-11-21 07:20:10 --> Helper loaded: email_helper
INFO - 2018-11-21 07:20:10 --> Helper loaded: common_helper
INFO - 2018-11-21 07:20:10 --> Database Driver Class Initialized
DEBUG - 2018-11-21 07:20:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-21 07:20:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-21 07:20:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-21 07:20:10 --> Pagination Class Initialized
INFO - 2018-11-21 07:20:10 --> Helper loaded: form_helper
INFO - 2018-11-21 07:20:10 --> Form Validation Class Initialized
INFO - 2018-11-21 07:20:10 --> Model Class Initialized
INFO - 2018-11-21 07:20:10 --> Controller Class Initialized
INFO - 2018-11-21 07:20:10 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-21 07:20:10 --> Model Class Initialized
INFO - 2018-11-21 07:20:10 --> Model Class Initialized
INFO - 2018-11-21 07:20:10 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/index.php
INFO - 2018-11-21 07:20:10 --> Final output sent to browser
DEBUG - 2018-11-21 07:20:10 --> Total execution time: 0.0550
INFO - 2018-11-21 07:20:12 --> Config Class Initialized
INFO - 2018-11-21 07:20:12 --> Hooks Class Initialized
DEBUG - 2018-11-21 07:20:12 --> UTF-8 Support Enabled
INFO - 2018-11-21 07:20:12 --> Utf8 Class Initialized
INFO - 2018-11-21 07:20:12 --> URI Class Initialized
INFO - 2018-11-21 07:20:12 --> Router Class Initialized
INFO - 2018-11-21 07:20:12 --> Output Class Initialized
INFO - 2018-11-21 07:20:12 --> Security Class Initialized
DEBUG - 2018-11-21 07:20:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-21 07:20:12 --> Input Class Initialized
INFO - 2018-11-21 07:20:12 --> Language Class Initialized
INFO - 2018-11-21 07:20:12 --> Loader Class Initialized
INFO - 2018-11-21 07:20:12 --> Helper loaded: url_helper
INFO - 2018-11-21 07:20:12 --> Helper loaded: file_helper
INFO - 2018-11-21 07:20:12 --> Helper loaded: email_helper
INFO - 2018-11-21 07:20:12 --> Helper loaded: common_helper
INFO - 2018-11-21 07:20:12 --> Database Driver Class Initialized
DEBUG - 2018-11-21 07:20:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-21 07:20:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-21 07:20:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-21 07:20:12 --> Pagination Class Initialized
INFO - 2018-11-21 07:20:12 --> Helper loaded: form_helper
INFO - 2018-11-21 07:20:12 --> Form Validation Class Initialized
INFO - 2018-11-21 07:20:12 --> Model Class Initialized
INFO - 2018-11-21 07:20:12 --> Controller Class Initialized
INFO - 2018-11-21 07:20:12 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-21 07:20:12 --> Model Class Initialized
INFO - 2018-11-21 07:20:12 --> Model Class Initialized
ERROR - 2018-11-21 07:20:12 --> Severity: Notice --> Undefined index: remember_me C:\xampp\htdocs\wetinuneed\application\controllers\admin\Admin.php 77
INFO - 2018-11-21 07:20:12 --> Config Class Initialized
INFO - 2018-11-21 07:20:12 --> Hooks Class Initialized
DEBUG - 2018-11-21 07:20:12 --> UTF-8 Support Enabled
INFO - 2018-11-21 07:20:12 --> Utf8 Class Initialized
INFO - 2018-11-21 07:20:12 --> URI Class Initialized
INFO - 2018-11-21 07:20:12 --> Router Class Initialized
INFO - 2018-11-21 07:20:12 --> Output Class Initialized
INFO - 2018-11-21 07:20:12 --> Security Class Initialized
DEBUG - 2018-11-21 07:20:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-21 07:20:12 --> Input Class Initialized
INFO - 2018-11-21 07:20:12 --> Language Class Initialized
INFO - 2018-11-21 07:20:12 --> Loader Class Initialized
INFO - 2018-11-21 07:20:12 --> Helper loaded: url_helper
INFO - 2018-11-21 07:20:12 --> Helper loaded: file_helper
INFO - 2018-11-21 07:20:12 --> Helper loaded: email_helper
INFO - 2018-11-21 07:20:12 --> Helper loaded: common_helper
INFO - 2018-11-21 07:20:12 --> Database Driver Class Initialized
DEBUG - 2018-11-21 07:20:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-21 07:20:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-21 07:20:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-21 07:20:12 --> Pagination Class Initialized
INFO - 2018-11-21 07:20:12 --> Helper loaded: form_helper
INFO - 2018-11-21 07:20:12 --> Form Validation Class Initialized
INFO - 2018-11-21 07:20:12 --> Model Class Initialized
INFO - 2018-11-21 07:20:12 --> Controller Class Initialized
INFO - 2018-11-21 07:20:12 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-21 07:20:12 --> Model Class Initialized
INFO - 2018-11-21 07:20:12 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-21 07:20:12 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/sidebar.php
INFO - 2018-11-21 07:20:12 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/right-sidebar.php
INFO - 2018-11-21 07:20:12 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/footer.php
INFO - 2018-11-21 07:20:12 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/dashboard.php
INFO - 2018-11-21 07:20:12 --> Final output sent to browser
DEBUG - 2018-11-21 07:20:12 --> Total execution time: 0.0470
INFO - 2018-11-21 07:20:18 --> Config Class Initialized
INFO - 2018-11-21 07:20:18 --> Hooks Class Initialized
DEBUG - 2018-11-21 07:20:18 --> UTF-8 Support Enabled
INFO - 2018-11-21 07:20:18 --> Utf8 Class Initialized
INFO - 2018-11-21 07:20:18 --> URI Class Initialized
INFO - 2018-11-21 07:20:18 --> Router Class Initialized
INFO - 2018-11-21 07:20:18 --> Output Class Initialized
INFO - 2018-11-21 07:20:18 --> Security Class Initialized
DEBUG - 2018-11-21 07:20:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-21 07:20:18 --> Input Class Initialized
INFO - 2018-11-21 07:20:18 --> Language Class Initialized
ERROR - 2018-11-21 07:20:18 --> 404 Page Not Found: Adminadmin/change_pasword
INFO - 2018-11-21 07:20:34 --> Config Class Initialized
INFO - 2018-11-21 07:20:34 --> Hooks Class Initialized
DEBUG - 2018-11-21 07:20:34 --> UTF-8 Support Enabled
INFO - 2018-11-21 07:20:34 --> Utf8 Class Initialized
INFO - 2018-11-21 07:20:34 --> URI Class Initialized
INFO - 2018-11-21 07:20:34 --> Router Class Initialized
INFO - 2018-11-21 07:20:34 --> Output Class Initialized
INFO - 2018-11-21 07:20:34 --> Security Class Initialized
DEBUG - 2018-11-21 07:20:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-21 07:20:34 --> Input Class Initialized
INFO - 2018-11-21 07:20:34 --> Language Class Initialized
INFO - 2018-11-21 07:20:34 --> Loader Class Initialized
INFO - 2018-11-21 07:20:34 --> Helper loaded: url_helper
INFO - 2018-11-21 07:20:34 --> Helper loaded: file_helper
INFO - 2018-11-21 07:20:34 --> Helper loaded: email_helper
INFO - 2018-11-21 07:20:34 --> Helper loaded: common_helper
INFO - 2018-11-21 07:20:34 --> Database Driver Class Initialized
DEBUG - 2018-11-21 07:20:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-21 07:20:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-21 07:20:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-21 07:20:34 --> Pagination Class Initialized
INFO - 2018-11-21 07:20:34 --> Helper loaded: form_helper
INFO - 2018-11-21 07:20:34 --> Form Validation Class Initialized
INFO - 2018-11-21 07:20:34 --> Model Class Initialized
INFO - 2018-11-21 07:20:34 --> Controller Class Initialized
INFO - 2018-11-21 07:20:34 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-21 07:20:34 --> Model Class Initialized
INFO - 2018-11-21 07:20:34 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-21 07:20:34 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/sidebar.php
INFO - 2018-11-21 07:20:34 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/right-sidebar.php
INFO - 2018-11-21 07:20:34 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/footer.php
INFO - 2018-11-21 07:20:34 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/dashboard.php
INFO - 2018-11-21 07:20:34 --> Final output sent to browser
DEBUG - 2018-11-21 07:20:34 --> Total execution time: 0.0620
INFO - 2018-11-21 07:20:36 --> Config Class Initialized
INFO - 2018-11-21 07:20:36 --> Hooks Class Initialized
DEBUG - 2018-11-21 07:20:36 --> UTF-8 Support Enabled
INFO - 2018-11-21 07:20:36 --> Utf8 Class Initialized
INFO - 2018-11-21 07:20:36 --> URI Class Initialized
INFO - 2018-11-21 07:20:36 --> Router Class Initialized
INFO - 2018-11-21 07:20:36 --> Output Class Initialized
INFO - 2018-11-21 07:20:36 --> Security Class Initialized
DEBUG - 2018-11-21 07:20:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-21 07:20:36 --> Input Class Initialized
INFO - 2018-11-21 07:20:36 --> Language Class Initialized
INFO - 2018-11-21 07:20:36 --> Loader Class Initialized
INFO - 2018-11-21 07:20:36 --> Helper loaded: url_helper
INFO - 2018-11-21 07:20:36 --> Helper loaded: file_helper
INFO - 2018-11-21 07:20:36 --> Helper loaded: email_helper
INFO - 2018-11-21 07:20:36 --> Helper loaded: common_helper
INFO - 2018-11-21 07:20:36 --> Database Driver Class Initialized
DEBUG - 2018-11-21 07:20:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-21 07:20:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-21 07:20:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-21 07:20:36 --> Pagination Class Initialized
INFO - 2018-11-21 07:20:36 --> Helper loaded: form_helper
INFO - 2018-11-21 07:20:36 --> Form Validation Class Initialized
INFO - 2018-11-21 07:20:36 --> Model Class Initialized
INFO - 2018-11-21 07:20:36 --> Controller Class Initialized
INFO - 2018-11-21 07:20:36 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-21 07:20:36 --> Model Class Initialized
INFO - 2018-11-21 07:20:36 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-21 07:20:36 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/sidebar.php
INFO - 2018-11-21 07:20:36 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/right-sidebar.php
INFO - 2018-11-21 07:20:36 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/footer.php
INFO - 2018-11-21 07:20:36 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/dashboard.php
INFO - 2018-11-21 07:20:36 --> Final output sent to browser
DEBUG - 2018-11-21 07:20:36 --> Total execution time: 0.0600
INFO - 2018-11-21 07:20:41 --> Config Class Initialized
INFO - 2018-11-21 07:20:41 --> Hooks Class Initialized
DEBUG - 2018-11-21 07:20:41 --> UTF-8 Support Enabled
INFO - 2018-11-21 07:20:41 --> Utf8 Class Initialized
INFO - 2018-11-21 07:20:41 --> URI Class Initialized
INFO - 2018-11-21 07:20:41 --> Router Class Initialized
INFO - 2018-11-21 07:20:41 --> Output Class Initialized
INFO - 2018-11-21 07:20:41 --> Security Class Initialized
DEBUG - 2018-11-21 07:20:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-21 07:20:41 --> Input Class Initialized
INFO - 2018-11-21 07:20:41 --> Language Class Initialized
ERROR - 2018-11-21 07:20:41 --> 404 Page Not Found: admin/Admin/change_pasword
INFO - 2018-11-21 07:21:09 --> Config Class Initialized
INFO - 2018-11-21 07:21:09 --> Hooks Class Initialized
DEBUG - 2018-11-21 07:21:09 --> UTF-8 Support Enabled
INFO - 2018-11-21 07:21:09 --> Utf8 Class Initialized
INFO - 2018-11-21 07:21:09 --> URI Class Initialized
INFO - 2018-11-21 07:21:09 --> Router Class Initialized
INFO - 2018-11-21 07:21:09 --> Output Class Initialized
INFO - 2018-11-21 07:21:09 --> Security Class Initialized
DEBUG - 2018-11-21 07:21:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-21 07:21:09 --> Input Class Initialized
INFO - 2018-11-21 07:21:09 --> Language Class Initialized
ERROR - 2018-11-21 07:21:09 --> 404 Page Not Found: admin/Change_pasword/index
INFO - 2018-11-21 07:21:19 --> Config Class Initialized
INFO - 2018-11-21 07:21:19 --> Hooks Class Initialized
DEBUG - 2018-11-21 07:21:19 --> UTF-8 Support Enabled
INFO - 2018-11-21 07:21:19 --> Utf8 Class Initialized
INFO - 2018-11-21 07:21:19 --> URI Class Initialized
INFO - 2018-11-21 07:21:19 --> Router Class Initialized
INFO - 2018-11-21 07:21:19 --> Output Class Initialized
INFO - 2018-11-21 07:21:19 --> Security Class Initialized
DEBUG - 2018-11-21 07:21:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-21 07:21:19 --> Input Class Initialized
INFO - 2018-11-21 07:21:19 --> Language Class Initialized
ERROR - 2018-11-21 07:21:19 --> 404 Page Not Found: admin/Admin/change_pasword
INFO - 2018-11-21 07:22:24 --> Config Class Initialized
INFO - 2018-11-21 07:22:24 --> Hooks Class Initialized
DEBUG - 2018-11-21 07:22:24 --> UTF-8 Support Enabled
INFO - 2018-11-21 07:22:24 --> Utf8 Class Initialized
INFO - 2018-11-21 07:22:24 --> URI Class Initialized
INFO - 2018-11-21 07:22:24 --> Router Class Initialized
INFO - 2018-11-21 07:22:24 --> Output Class Initialized
INFO - 2018-11-21 07:22:24 --> Security Class Initialized
DEBUG - 2018-11-21 07:22:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-21 07:22:24 --> Input Class Initialized
INFO - 2018-11-21 07:22:24 --> Language Class Initialized
INFO - 2018-11-21 07:22:24 --> Loader Class Initialized
INFO - 2018-11-21 07:22:24 --> Helper loaded: url_helper
INFO - 2018-11-21 07:22:24 --> Helper loaded: file_helper
INFO - 2018-11-21 07:22:24 --> Helper loaded: email_helper
INFO - 2018-11-21 07:22:24 --> Helper loaded: common_helper
INFO - 2018-11-21 07:22:24 --> Database Driver Class Initialized
DEBUG - 2018-11-21 07:22:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-21 07:22:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-21 07:22:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-21 07:22:24 --> Pagination Class Initialized
INFO - 2018-11-21 07:22:24 --> Helper loaded: form_helper
INFO - 2018-11-21 07:22:24 --> Form Validation Class Initialized
INFO - 2018-11-21 07:22:24 --> Model Class Initialized
INFO - 2018-11-21 07:22:24 --> Controller Class Initialized
INFO - 2018-11-21 07:22:24 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-21 07:22:24 --> Model Class Initialized
INFO - 2018-11-21 07:22:24 --> Model Class Initialized
INFO - 2018-11-21 07:22:24 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-21 07:22:24 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/footer.php
INFO - 2018-11-21 07:22:24 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/change-password.php
INFO - 2018-11-21 07:22:24 --> Final output sent to browser
DEBUG - 2018-11-21 07:22:24 --> Total execution time: 0.0600
INFO - 2018-11-21 07:22:25 --> Config Class Initialized
INFO - 2018-11-21 07:22:25 --> Hooks Class Initialized
DEBUG - 2018-11-21 07:22:25 --> UTF-8 Support Enabled
INFO - 2018-11-21 07:22:25 --> Utf8 Class Initialized
INFO - 2018-11-21 07:22:25 --> URI Class Initialized
INFO - 2018-11-21 07:22:25 --> Router Class Initialized
INFO - 2018-11-21 07:22:25 --> Output Class Initialized
INFO - 2018-11-21 07:22:25 --> Security Class Initialized
DEBUG - 2018-11-21 07:22:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-21 07:22:25 --> Input Class Initialized
INFO - 2018-11-21 07:22:25 --> Language Class Initialized
ERROR - 2018-11-21 07:22:25 --> 404 Page Not Found: admin/Plugins/images
INFO - 2018-11-21 07:22:49 --> Config Class Initialized
INFO - 2018-11-21 07:22:49 --> Hooks Class Initialized
DEBUG - 2018-11-21 07:22:49 --> UTF-8 Support Enabled
INFO - 2018-11-21 07:22:49 --> Utf8 Class Initialized
INFO - 2018-11-21 07:22:49 --> URI Class Initialized
INFO - 2018-11-21 07:22:49 --> Router Class Initialized
INFO - 2018-11-21 07:22:49 --> Output Class Initialized
INFO - 2018-11-21 07:22:49 --> Security Class Initialized
DEBUG - 2018-11-21 07:22:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-21 07:22:49 --> Input Class Initialized
INFO - 2018-11-21 07:22:49 --> Language Class Initialized
ERROR - 2018-11-21 07:22:49 --> 404 Page Not Found: admin/Admin/change_pasword
INFO - 2018-11-21 07:23:01 --> Config Class Initialized
INFO - 2018-11-21 07:23:01 --> Hooks Class Initialized
DEBUG - 2018-11-21 07:23:01 --> UTF-8 Support Enabled
INFO - 2018-11-21 07:23:01 --> Utf8 Class Initialized
INFO - 2018-11-21 07:23:01 --> URI Class Initialized
INFO - 2018-11-21 07:23:01 --> Router Class Initialized
INFO - 2018-11-21 07:23:01 --> Output Class Initialized
INFO - 2018-11-21 07:23:01 --> Security Class Initialized
DEBUG - 2018-11-21 07:23:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-21 07:23:01 --> Input Class Initialized
INFO - 2018-11-21 07:23:01 --> Language Class Initialized
INFO - 2018-11-21 07:23:01 --> Loader Class Initialized
INFO - 2018-11-21 07:23:01 --> Helper loaded: url_helper
INFO - 2018-11-21 07:23:01 --> Helper loaded: file_helper
INFO - 2018-11-21 07:23:01 --> Helper loaded: email_helper
INFO - 2018-11-21 07:23:01 --> Helper loaded: common_helper
INFO - 2018-11-21 07:23:01 --> Database Driver Class Initialized
DEBUG - 2018-11-21 07:23:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-21 07:23:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-21 07:23:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-21 07:23:01 --> Pagination Class Initialized
INFO - 2018-11-21 07:23:01 --> Helper loaded: form_helper
INFO - 2018-11-21 07:23:01 --> Form Validation Class Initialized
INFO - 2018-11-21 07:23:01 --> Model Class Initialized
INFO - 2018-11-21 07:23:01 --> Controller Class Initialized
INFO - 2018-11-21 07:23:01 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-21 07:23:01 --> Model Class Initialized
INFO - 2018-11-21 07:23:01 --> Model Class Initialized
INFO - 2018-11-21 07:23:01 --> Config Class Initialized
INFO - 2018-11-21 07:23:01 --> Hooks Class Initialized
DEBUG - 2018-11-21 07:23:01 --> UTF-8 Support Enabled
INFO - 2018-11-21 07:23:01 --> Utf8 Class Initialized
INFO - 2018-11-21 07:23:01 --> URI Class Initialized
INFO - 2018-11-21 07:23:01 --> Router Class Initialized
INFO - 2018-11-21 07:23:01 --> Output Class Initialized
INFO - 2018-11-21 07:23:01 --> Security Class Initialized
DEBUG - 2018-11-21 07:23:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-21 07:23:01 --> Input Class Initialized
INFO - 2018-11-21 07:23:01 --> Language Class Initialized
INFO - 2018-11-21 07:23:01 --> Loader Class Initialized
INFO - 2018-11-21 07:23:01 --> Helper loaded: url_helper
INFO - 2018-11-21 07:23:01 --> Helper loaded: file_helper
INFO - 2018-11-21 07:23:01 --> Helper loaded: email_helper
INFO - 2018-11-21 07:23:01 --> Helper loaded: common_helper
INFO - 2018-11-21 07:23:01 --> Database Driver Class Initialized
DEBUG - 2018-11-21 07:23:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-21 07:23:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-21 07:23:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-21 07:23:01 --> Pagination Class Initialized
INFO - 2018-11-21 07:23:01 --> Helper loaded: form_helper
INFO - 2018-11-21 07:23:01 --> Form Validation Class Initialized
INFO - 2018-11-21 07:23:01 --> Model Class Initialized
INFO - 2018-11-21 07:23:01 --> Controller Class Initialized
INFO - 2018-11-21 07:23:01 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-21 07:23:01 --> Model Class Initialized
INFO - 2018-11-21 07:23:01 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-21 07:23:01 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/sidebar.php
INFO - 2018-11-21 07:23:01 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/right-sidebar.php
INFO - 2018-11-21 07:23:01 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/footer.php
INFO - 2018-11-21 07:23:01 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/dashboard.php
INFO - 2018-11-21 07:23:01 --> Final output sent to browser
DEBUG - 2018-11-21 07:23:01 --> Total execution time: 0.0790
INFO - 2018-11-21 07:23:02 --> Config Class Initialized
INFO - 2018-11-21 07:23:02 --> Hooks Class Initialized
DEBUG - 2018-11-21 07:23:02 --> UTF-8 Support Enabled
INFO - 2018-11-21 07:23:02 --> Utf8 Class Initialized
INFO - 2018-11-21 07:23:02 --> URI Class Initialized
INFO - 2018-11-21 07:23:02 --> Router Class Initialized
INFO - 2018-11-21 07:23:02 --> Output Class Initialized
INFO - 2018-11-21 07:23:02 --> Security Class Initialized
DEBUG - 2018-11-21 07:23:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-21 07:23:02 --> Input Class Initialized
INFO - 2018-11-21 07:23:02 --> Language Class Initialized
INFO - 2018-11-21 07:23:02 --> Loader Class Initialized
INFO - 2018-11-21 07:23:02 --> Helper loaded: url_helper
INFO - 2018-11-21 07:23:02 --> Helper loaded: file_helper
INFO - 2018-11-21 07:23:02 --> Helper loaded: email_helper
INFO - 2018-11-21 07:23:02 --> Helper loaded: common_helper
INFO - 2018-11-21 07:23:02 --> Database Driver Class Initialized
DEBUG - 2018-11-21 07:23:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-21 07:23:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-21 07:23:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-21 07:23:02 --> Pagination Class Initialized
INFO - 2018-11-21 07:23:02 --> Helper loaded: form_helper
INFO - 2018-11-21 07:23:02 --> Form Validation Class Initialized
INFO - 2018-11-21 07:23:02 --> Model Class Initialized
INFO - 2018-11-21 07:23:02 --> Controller Class Initialized
INFO - 2018-11-21 07:23:02 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-21 07:23:02 --> Model Class Initialized
INFO - 2018-11-21 07:23:02 --> Model Class Initialized
INFO - 2018-11-21 07:23:02 --> Config Class Initialized
INFO - 2018-11-21 07:23:02 --> Hooks Class Initialized
DEBUG - 2018-11-21 07:23:02 --> UTF-8 Support Enabled
INFO - 2018-11-21 07:23:02 --> Utf8 Class Initialized
INFO - 2018-11-21 07:23:02 --> URI Class Initialized
INFO - 2018-11-21 07:23:02 --> Router Class Initialized
INFO - 2018-11-21 07:23:02 --> Output Class Initialized
INFO - 2018-11-21 07:23:02 --> Security Class Initialized
DEBUG - 2018-11-21 07:23:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-21 07:23:02 --> Input Class Initialized
INFO - 2018-11-21 07:23:02 --> Language Class Initialized
INFO - 2018-11-21 07:23:02 --> Loader Class Initialized
INFO - 2018-11-21 07:23:02 --> Helper loaded: url_helper
INFO - 2018-11-21 07:23:02 --> Helper loaded: file_helper
INFO - 2018-11-21 07:23:02 --> Helper loaded: email_helper
INFO - 2018-11-21 07:23:02 --> Helper loaded: common_helper
INFO - 2018-11-21 07:23:02 --> Database Driver Class Initialized
DEBUG - 2018-11-21 07:23:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-21 07:23:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-21 07:23:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-21 07:23:02 --> Pagination Class Initialized
INFO - 2018-11-21 07:23:02 --> Helper loaded: form_helper
INFO - 2018-11-21 07:23:02 --> Form Validation Class Initialized
INFO - 2018-11-21 07:23:02 --> Model Class Initialized
INFO - 2018-11-21 07:23:02 --> Controller Class Initialized
INFO - 2018-11-21 07:23:02 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-21 07:23:02 --> Model Class Initialized
INFO - 2018-11-21 07:23:02 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-21 07:23:02 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/sidebar.php
INFO - 2018-11-21 07:23:02 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/right-sidebar.php
INFO - 2018-11-21 07:23:02 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/footer.php
INFO - 2018-11-21 07:23:02 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/dashboard.php
INFO - 2018-11-21 07:23:02 --> Final output sent to browser
DEBUG - 2018-11-21 07:23:02 --> Total execution time: 0.0520
INFO - 2018-11-21 07:23:22 --> Config Class Initialized
INFO - 2018-11-21 07:23:22 --> Hooks Class Initialized
DEBUG - 2018-11-21 07:23:22 --> UTF-8 Support Enabled
INFO - 2018-11-21 07:23:22 --> Utf8 Class Initialized
INFO - 2018-11-21 07:23:22 --> URI Class Initialized
INFO - 2018-11-21 07:23:22 --> Router Class Initialized
INFO - 2018-11-21 07:23:22 --> Output Class Initialized
INFO - 2018-11-21 07:23:22 --> Security Class Initialized
DEBUG - 2018-11-21 07:23:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-21 07:23:22 --> Input Class Initialized
INFO - 2018-11-21 07:23:22 --> Language Class Initialized
INFO - 2018-11-21 07:23:22 --> Loader Class Initialized
INFO - 2018-11-21 07:23:22 --> Helper loaded: url_helper
INFO - 2018-11-21 07:23:22 --> Helper loaded: file_helper
INFO - 2018-11-21 07:23:22 --> Helper loaded: email_helper
INFO - 2018-11-21 07:23:22 --> Helper loaded: common_helper
INFO - 2018-11-21 07:23:22 --> Database Driver Class Initialized
DEBUG - 2018-11-21 07:23:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-21 07:23:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-21 07:23:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-21 07:23:22 --> Pagination Class Initialized
INFO - 2018-11-21 07:23:22 --> Helper loaded: form_helper
INFO - 2018-11-21 07:23:22 --> Form Validation Class Initialized
INFO - 2018-11-21 07:23:22 --> Model Class Initialized
INFO - 2018-11-21 07:23:22 --> Controller Class Initialized
INFO - 2018-11-21 07:23:22 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-21 07:23:22 --> Model Class Initialized
INFO - 2018-11-21 07:23:22 --> Model Class Initialized
INFO - 2018-11-21 07:23:22 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-21 07:23:22 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/footer.php
INFO - 2018-11-21 07:23:22 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/change-password.php
INFO - 2018-11-21 07:23:22 --> Final output sent to browser
DEBUG - 2018-11-21 07:23:22 --> Total execution time: 0.0590
INFO - 2018-11-21 07:23:23 --> Config Class Initialized
INFO - 2018-11-21 07:23:23 --> Hooks Class Initialized
DEBUG - 2018-11-21 07:23:23 --> UTF-8 Support Enabled
INFO - 2018-11-21 07:23:23 --> Utf8 Class Initialized
INFO - 2018-11-21 07:23:23 --> URI Class Initialized
INFO - 2018-11-21 07:23:23 --> Router Class Initialized
INFO - 2018-11-21 07:23:23 --> Output Class Initialized
INFO - 2018-11-21 07:23:23 --> Security Class Initialized
DEBUG - 2018-11-21 07:23:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-21 07:23:23 --> Input Class Initialized
INFO - 2018-11-21 07:23:23 --> Language Class Initialized
ERROR - 2018-11-21 07:23:23 --> 404 Page Not Found: Plugins/images
INFO - 2018-11-21 07:23:45 --> Config Class Initialized
INFO - 2018-11-21 07:23:45 --> Hooks Class Initialized
DEBUG - 2018-11-21 07:23:45 --> UTF-8 Support Enabled
INFO - 2018-11-21 07:23:45 --> Utf8 Class Initialized
INFO - 2018-11-21 07:23:45 --> URI Class Initialized
INFO - 2018-11-21 07:23:45 --> Router Class Initialized
INFO - 2018-11-21 07:23:45 --> Output Class Initialized
INFO - 2018-11-21 07:23:45 --> Security Class Initialized
DEBUG - 2018-11-21 07:23:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-21 07:23:45 --> Input Class Initialized
INFO - 2018-11-21 07:23:45 --> Language Class Initialized
INFO - 2018-11-21 07:23:45 --> Loader Class Initialized
INFO - 2018-11-21 07:23:45 --> Helper loaded: url_helper
INFO - 2018-11-21 07:23:45 --> Helper loaded: file_helper
INFO - 2018-11-21 07:23:45 --> Helper loaded: email_helper
INFO - 2018-11-21 07:23:45 --> Helper loaded: common_helper
INFO - 2018-11-21 07:23:45 --> Database Driver Class Initialized
DEBUG - 2018-11-21 07:23:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-21 07:23:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-21 07:23:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-21 07:23:45 --> Pagination Class Initialized
INFO - 2018-11-21 07:23:45 --> Helper loaded: form_helper
INFO - 2018-11-21 07:23:45 --> Form Validation Class Initialized
INFO - 2018-11-21 07:23:45 --> Model Class Initialized
INFO - 2018-11-21 07:23:45 --> Controller Class Initialized
INFO - 2018-11-21 07:23:45 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-21 07:23:45 --> Model Class Initialized
INFO - 2018-11-21 07:23:45 --> Model Class Initialized
INFO - 2018-11-21 07:23:45 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-21 07:23:45 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/footer.php
INFO - 2018-11-21 07:23:45 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/change-password.php
INFO - 2018-11-21 07:23:45 --> Final output sent to browser
DEBUG - 2018-11-21 07:23:45 --> Total execution time: 0.0560
INFO - 2018-11-21 07:23:46 --> Config Class Initialized
INFO - 2018-11-21 07:23:46 --> Hooks Class Initialized
DEBUG - 2018-11-21 07:23:46 --> UTF-8 Support Enabled
INFO - 2018-11-21 07:23:46 --> Utf8 Class Initialized
INFO - 2018-11-21 07:23:46 --> URI Class Initialized
INFO - 2018-11-21 07:23:46 --> Router Class Initialized
INFO - 2018-11-21 07:23:46 --> Output Class Initialized
INFO - 2018-11-21 07:23:46 --> Security Class Initialized
DEBUG - 2018-11-21 07:23:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-21 07:23:46 --> Input Class Initialized
INFO - 2018-11-21 07:23:46 --> Language Class Initialized
ERROR - 2018-11-21 07:23:46 --> 404 Page Not Found: Plugins/images
INFO - 2018-11-21 07:24:16 --> Config Class Initialized
INFO - 2018-11-21 07:24:16 --> Hooks Class Initialized
DEBUG - 2018-11-21 07:24:16 --> UTF-8 Support Enabled
INFO - 2018-11-21 07:24:16 --> Utf8 Class Initialized
INFO - 2018-11-21 07:24:16 --> URI Class Initialized
INFO - 2018-11-21 07:24:16 --> Router Class Initialized
INFO - 2018-11-21 07:24:16 --> Output Class Initialized
INFO - 2018-11-21 07:24:16 --> Security Class Initialized
DEBUG - 2018-11-21 07:24:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-21 07:24:16 --> Input Class Initialized
INFO - 2018-11-21 07:24:16 --> Language Class Initialized
ERROR - 2018-11-21 07:24:16 --> 404 Page Not Found: Logout/index
INFO - 2018-11-21 07:24:24 --> Config Class Initialized
INFO - 2018-11-21 07:24:24 --> Hooks Class Initialized
DEBUG - 2018-11-21 07:24:24 --> UTF-8 Support Enabled
INFO - 2018-11-21 07:24:24 --> Utf8 Class Initialized
INFO - 2018-11-21 07:24:24 --> URI Class Initialized
INFO - 2018-11-21 07:24:24 --> Router Class Initialized
INFO - 2018-11-21 07:24:24 --> Output Class Initialized
INFO - 2018-11-21 07:24:24 --> Security Class Initialized
DEBUG - 2018-11-21 07:24:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-21 07:24:24 --> Input Class Initialized
INFO - 2018-11-21 07:24:24 --> Language Class Initialized
INFO - 2018-11-21 07:24:24 --> Loader Class Initialized
INFO - 2018-11-21 07:24:24 --> Helper loaded: url_helper
INFO - 2018-11-21 07:24:24 --> Helper loaded: file_helper
INFO - 2018-11-21 07:24:24 --> Helper loaded: email_helper
INFO - 2018-11-21 07:24:24 --> Helper loaded: common_helper
INFO - 2018-11-21 07:24:24 --> Database Driver Class Initialized
DEBUG - 2018-11-21 07:24:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-21 07:24:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-21 07:24:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-21 07:24:24 --> Pagination Class Initialized
INFO - 2018-11-21 07:24:24 --> Helper loaded: form_helper
INFO - 2018-11-21 07:24:24 --> Form Validation Class Initialized
INFO - 2018-11-21 07:24:24 --> Model Class Initialized
INFO - 2018-11-21 07:24:24 --> Controller Class Initialized
INFO - 2018-11-21 07:24:24 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-21 07:24:24 --> Model Class Initialized
INFO - 2018-11-21 07:24:24 --> Model Class Initialized
INFO - 2018-11-21 07:24:24 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-21 07:24:24 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/footer.php
INFO - 2018-11-21 07:24:24 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/change-password.php
INFO - 2018-11-21 07:24:24 --> Final output sent to browser
DEBUG - 2018-11-21 07:24:24 --> Total execution time: 0.0560
INFO - 2018-11-21 07:24:31 --> Config Class Initialized
INFO - 2018-11-21 07:24:31 --> Hooks Class Initialized
DEBUG - 2018-11-21 07:24:31 --> UTF-8 Support Enabled
INFO - 2018-11-21 07:24:31 --> Utf8 Class Initialized
INFO - 2018-11-21 07:24:31 --> URI Class Initialized
INFO - 2018-11-21 07:24:31 --> Router Class Initialized
INFO - 2018-11-21 07:24:31 --> Output Class Initialized
INFO - 2018-11-21 07:24:31 --> Security Class Initialized
DEBUG - 2018-11-21 07:24:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-21 07:24:31 --> Input Class Initialized
INFO - 2018-11-21 07:24:31 --> Language Class Initialized
INFO - 2018-11-21 07:24:31 --> Loader Class Initialized
INFO - 2018-11-21 07:24:31 --> Helper loaded: url_helper
INFO - 2018-11-21 07:24:31 --> Helper loaded: file_helper
INFO - 2018-11-21 07:24:31 --> Helper loaded: email_helper
INFO - 2018-11-21 07:24:31 --> Helper loaded: common_helper
INFO - 2018-11-21 07:24:31 --> Database Driver Class Initialized
DEBUG - 2018-11-21 07:24:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-21 07:24:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-21 07:24:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-21 07:24:31 --> Pagination Class Initialized
INFO - 2018-11-21 07:24:31 --> Helper loaded: form_helper
INFO - 2018-11-21 07:24:31 --> Form Validation Class Initialized
INFO - 2018-11-21 07:24:31 --> Model Class Initialized
INFO - 2018-11-21 07:24:31 --> Controller Class Initialized
INFO - 2018-11-21 07:24:31 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-21 07:24:31 --> Model Class Initialized
INFO - 2018-11-21 07:24:31 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-21 07:24:31 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/sidebar.php
INFO - 2018-11-21 07:24:31 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/right-sidebar.php
INFO - 2018-11-21 07:24:31 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/footer.php
INFO - 2018-11-21 07:24:31 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/dashboard.php
INFO - 2018-11-21 07:24:31 --> Final output sent to browser
DEBUG - 2018-11-21 07:24:31 --> Total execution time: 0.0550
INFO - 2018-11-21 07:24:56 --> Config Class Initialized
INFO - 2018-11-21 07:24:56 --> Hooks Class Initialized
DEBUG - 2018-11-21 07:24:56 --> UTF-8 Support Enabled
INFO - 2018-11-21 07:24:56 --> Utf8 Class Initialized
INFO - 2018-11-21 07:24:56 --> URI Class Initialized
INFO - 2018-11-21 07:24:56 --> Router Class Initialized
INFO - 2018-11-21 07:24:56 --> Output Class Initialized
INFO - 2018-11-21 07:24:56 --> Security Class Initialized
DEBUG - 2018-11-21 07:24:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-21 07:24:56 --> Input Class Initialized
INFO - 2018-11-21 07:24:56 --> Language Class Initialized
INFO - 2018-11-21 07:24:56 --> Loader Class Initialized
INFO - 2018-11-21 07:24:56 --> Helper loaded: url_helper
INFO - 2018-11-21 07:24:56 --> Helper loaded: file_helper
INFO - 2018-11-21 07:24:56 --> Helper loaded: email_helper
INFO - 2018-11-21 07:24:56 --> Helper loaded: common_helper
INFO - 2018-11-21 07:24:56 --> Database Driver Class Initialized
DEBUG - 2018-11-21 07:24:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-21 07:24:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-21 07:24:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-21 07:24:56 --> Pagination Class Initialized
INFO - 2018-11-21 07:24:56 --> Helper loaded: form_helper
INFO - 2018-11-21 07:24:56 --> Form Validation Class Initialized
INFO - 2018-11-21 07:24:56 --> Model Class Initialized
INFO - 2018-11-21 07:24:56 --> Controller Class Initialized
INFO - 2018-11-21 07:24:56 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-21 07:24:56 --> Model Class Initialized
INFO - 2018-11-21 07:24:56 --> Model Class Initialized
INFO - 2018-11-21 07:24:56 --> Config Class Initialized
INFO - 2018-11-21 07:24:56 --> Hooks Class Initialized
DEBUG - 2018-11-21 07:24:56 --> UTF-8 Support Enabled
INFO - 2018-11-21 07:24:56 --> Utf8 Class Initialized
INFO - 2018-11-21 07:24:56 --> URI Class Initialized
INFO - 2018-11-21 07:24:56 --> Router Class Initialized
INFO - 2018-11-21 07:24:56 --> Output Class Initialized
INFO - 2018-11-21 07:24:56 --> Security Class Initialized
DEBUG - 2018-11-21 07:24:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-21 07:24:56 --> Input Class Initialized
INFO - 2018-11-21 07:24:56 --> Language Class Initialized
INFO - 2018-11-21 07:24:56 --> Loader Class Initialized
INFO - 2018-11-21 07:24:56 --> Helper loaded: url_helper
INFO - 2018-11-21 07:24:56 --> Helper loaded: file_helper
INFO - 2018-11-21 07:24:56 --> Helper loaded: email_helper
INFO - 2018-11-21 07:24:56 --> Helper loaded: common_helper
INFO - 2018-11-21 07:24:56 --> Database Driver Class Initialized
DEBUG - 2018-11-21 07:24:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-21 07:24:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-21 07:24:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-21 07:24:56 --> Pagination Class Initialized
INFO - 2018-11-21 07:24:56 --> Helper loaded: form_helper
INFO - 2018-11-21 07:24:56 --> Form Validation Class Initialized
INFO - 2018-11-21 07:24:56 --> Model Class Initialized
INFO - 2018-11-21 07:24:56 --> Controller Class Initialized
INFO - 2018-11-21 07:24:56 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-21 07:24:56 --> Model Class Initialized
INFO - 2018-11-21 07:24:56 --> Model Class Initialized
INFO - 2018-11-21 07:24:56 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/index.php
INFO - 2018-11-21 07:24:56 --> Final output sent to browser
DEBUG - 2018-11-21 07:24:56 --> Total execution time: 0.0510
INFO - 2018-11-21 07:25:00 --> Config Class Initialized
INFO - 2018-11-21 07:25:00 --> Hooks Class Initialized
DEBUG - 2018-11-21 07:25:00 --> UTF-8 Support Enabled
INFO - 2018-11-21 07:25:00 --> Utf8 Class Initialized
INFO - 2018-11-21 07:25:00 --> URI Class Initialized
INFO - 2018-11-21 07:25:00 --> Router Class Initialized
INFO - 2018-11-21 07:25:00 --> Output Class Initialized
INFO - 2018-11-21 07:25:00 --> Security Class Initialized
DEBUG - 2018-11-21 07:25:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-21 07:25:00 --> Input Class Initialized
INFO - 2018-11-21 07:25:00 --> Language Class Initialized
INFO - 2018-11-21 07:25:00 --> Loader Class Initialized
INFO - 2018-11-21 07:25:00 --> Helper loaded: url_helper
INFO - 2018-11-21 07:25:00 --> Helper loaded: file_helper
INFO - 2018-11-21 07:25:00 --> Helper loaded: email_helper
INFO - 2018-11-21 07:25:00 --> Helper loaded: common_helper
INFO - 2018-11-21 07:25:00 --> Database Driver Class Initialized
DEBUG - 2018-11-21 07:25:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-21 07:25:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-21 07:25:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-21 07:25:00 --> Pagination Class Initialized
INFO - 2018-11-21 07:25:00 --> Helper loaded: form_helper
INFO - 2018-11-21 07:25:00 --> Form Validation Class Initialized
INFO - 2018-11-21 07:25:00 --> Model Class Initialized
INFO - 2018-11-21 07:25:00 --> Controller Class Initialized
INFO - 2018-11-21 07:25:00 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-21 07:25:00 --> Model Class Initialized
INFO - 2018-11-21 07:25:00 --> Model Class Initialized
ERROR - 2018-11-21 07:25:00 --> Severity: Notice --> Undefined index: remember_me C:\xampp\htdocs\wetinuneed\application\controllers\admin\Admin.php 77
INFO - 2018-11-21 07:25:00 --> Config Class Initialized
INFO - 2018-11-21 07:25:00 --> Hooks Class Initialized
DEBUG - 2018-11-21 07:25:00 --> UTF-8 Support Enabled
INFO - 2018-11-21 07:25:00 --> Utf8 Class Initialized
INFO - 2018-11-21 07:25:00 --> URI Class Initialized
INFO - 2018-11-21 07:25:00 --> Router Class Initialized
INFO - 2018-11-21 07:25:00 --> Output Class Initialized
INFO - 2018-11-21 07:25:00 --> Security Class Initialized
DEBUG - 2018-11-21 07:25:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-21 07:25:00 --> Input Class Initialized
INFO - 2018-11-21 07:25:00 --> Language Class Initialized
INFO - 2018-11-21 07:25:00 --> Loader Class Initialized
INFO - 2018-11-21 07:25:00 --> Helper loaded: url_helper
INFO - 2018-11-21 07:25:00 --> Helper loaded: file_helper
INFO - 2018-11-21 07:25:00 --> Helper loaded: email_helper
INFO - 2018-11-21 07:25:00 --> Helper loaded: common_helper
INFO - 2018-11-21 07:25:00 --> Database Driver Class Initialized
DEBUG - 2018-11-21 07:25:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-21 07:25:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-21 07:25:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-21 07:25:00 --> Pagination Class Initialized
INFO - 2018-11-21 07:25:00 --> Helper loaded: form_helper
INFO - 2018-11-21 07:25:00 --> Form Validation Class Initialized
INFO - 2018-11-21 07:25:00 --> Model Class Initialized
INFO - 2018-11-21 07:25:00 --> Controller Class Initialized
INFO - 2018-11-21 07:25:00 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-21 07:25:00 --> Model Class Initialized
INFO - 2018-11-21 07:25:00 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-21 07:25:00 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/sidebar.php
INFO - 2018-11-21 07:25:00 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/right-sidebar.php
INFO - 2018-11-21 07:25:00 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/footer.php
INFO - 2018-11-21 07:25:00 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/dashboard.php
INFO - 2018-11-21 07:25:00 --> Final output sent to browser
DEBUG - 2018-11-21 07:25:00 --> Total execution time: 0.0600
INFO - 2018-11-21 07:25:14 --> Config Class Initialized
INFO - 2018-11-21 07:25:14 --> Hooks Class Initialized
DEBUG - 2018-11-21 07:25:14 --> UTF-8 Support Enabled
INFO - 2018-11-21 07:25:14 --> Utf8 Class Initialized
INFO - 2018-11-21 07:25:14 --> URI Class Initialized
INFO - 2018-11-21 07:25:14 --> Router Class Initialized
INFO - 2018-11-21 07:25:14 --> Output Class Initialized
INFO - 2018-11-21 07:25:14 --> Security Class Initialized
DEBUG - 2018-11-21 07:25:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-21 07:25:14 --> Input Class Initialized
INFO - 2018-11-21 07:25:14 --> Language Class Initialized
INFO - 2018-11-21 07:25:14 --> Loader Class Initialized
INFO - 2018-11-21 07:25:14 --> Helper loaded: url_helper
INFO - 2018-11-21 07:25:14 --> Helper loaded: file_helper
INFO - 2018-11-21 07:25:14 --> Helper loaded: email_helper
INFO - 2018-11-21 07:25:14 --> Helper loaded: common_helper
INFO - 2018-11-21 07:25:14 --> Database Driver Class Initialized
DEBUG - 2018-11-21 07:25:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-21 07:25:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-21 07:25:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-21 07:25:14 --> Pagination Class Initialized
INFO - 2018-11-21 07:25:14 --> Helper loaded: form_helper
INFO - 2018-11-21 07:25:14 --> Form Validation Class Initialized
INFO - 2018-11-21 07:25:14 --> Model Class Initialized
INFO - 2018-11-21 07:25:14 --> Controller Class Initialized
INFO - 2018-11-21 07:25:14 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-21 07:25:14 --> Model Class Initialized
INFO - 2018-11-21 07:25:14 --> Model Class Initialized
INFO - 2018-11-21 07:25:14 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-21 07:25:14 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/footer.php
INFO - 2018-11-21 07:25:14 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/change-password.php
INFO - 2018-11-21 07:25:14 --> Final output sent to browser
DEBUG - 2018-11-21 07:25:14 --> Total execution time: 0.0590
INFO - 2018-11-21 07:27:02 --> Config Class Initialized
INFO - 2018-11-21 07:27:02 --> Hooks Class Initialized
DEBUG - 2018-11-21 07:27:02 --> UTF-8 Support Enabled
INFO - 2018-11-21 07:27:02 --> Utf8 Class Initialized
INFO - 2018-11-21 07:27:02 --> URI Class Initialized
INFO - 2018-11-21 07:27:02 --> Router Class Initialized
INFO - 2018-11-21 07:27:02 --> Output Class Initialized
INFO - 2018-11-21 07:27:02 --> Security Class Initialized
DEBUG - 2018-11-21 07:27:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-21 07:27:02 --> Input Class Initialized
INFO - 2018-11-21 07:27:02 --> Language Class Initialized
INFO - 2018-11-21 07:27:02 --> Loader Class Initialized
INFO - 2018-11-21 07:27:02 --> Helper loaded: url_helper
INFO - 2018-11-21 07:27:02 --> Helper loaded: file_helper
INFO - 2018-11-21 07:27:02 --> Helper loaded: email_helper
INFO - 2018-11-21 07:27:02 --> Helper loaded: common_helper
INFO - 2018-11-21 07:27:02 --> Database Driver Class Initialized
DEBUG - 2018-11-21 07:27:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-21 07:27:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-21 07:27:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-21 07:27:02 --> Pagination Class Initialized
INFO - 2018-11-21 07:27:02 --> Helper loaded: form_helper
INFO - 2018-11-21 07:27:02 --> Form Validation Class Initialized
INFO - 2018-11-21 07:27:02 --> Model Class Initialized
INFO - 2018-11-21 07:27:02 --> Controller Class Initialized
INFO - 2018-11-21 07:27:02 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-21 07:27:02 --> Model Class Initialized
INFO - 2018-11-21 07:27:02 --> Model Class Initialized
INFO - 2018-11-21 07:27:02 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-21 07:27:02 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/change-password.php
INFO - 2018-11-21 07:27:02 --> Final output sent to browser
DEBUG - 2018-11-21 07:27:02 --> Total execution time: 0.0590
INFO - 2018-11-21 07:27:04 --> Config Class Initialized
INFO - 2018-11-21 07:27:04 --> Hooks Class Initialized
DEBUG - 2018-11-21 07:27:04 --> UTF-8 Support Enabled
INFO - 2018-11-21 07:27:04 --> Utf8 Class Initialized
INFO - 2018-11-21 07:27:04 --> URI Class Initialized
INFO - 2018-11-21 07:27:04 --> Router Class Initialized
INFO - 2018-11-21 07:27:04 --> Output Class Initialized
INFO - 2018-11-21 07:27:04 --> Security Class Initialized
DEBUG - 2018-11-21 07:27:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-21 07:27:04 --> Input Class Initialized
INFO - 2018-11-21 07:27:04 --> Language Class Initialized
ERROR - 2018-11-21 07:27:04 --> 404 Page Not Found: Plugins/images
INFO - 2018-11-21 07:38:20 --> Config Class Initialized
INFO - 2018-11-21 07:38:20 --> Hooks Class Initialized
DEBUG - 2018-11-21 07:38:20 --> UTF-8 Support Enabled
INFO - 2018-11-21 07:38:20 --> Utf8 Class Initialized
INFO - 2018-11-21 07:38:20 --> URI Class Initialized
INFO - 2018-11-21 07:38:20 --> Router Class Initialized
INFO - 2018-11-21 07:38:20 --> Output Class Initialized
INFO - 2018-11-21 07:38:20 --> Security Class Initialized
DEBUG - 2018-11-21 07:38:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-21 07:38:20 --> Input Class Initialized
INFO - 2018-11-21 07:38:20 --> Language Class Initialized
INFO - 2018-11-21 07:38:20 --> Loader Class Initialized
INFO - 2018-11-21 07:38:20 --> Helper loaded: url_helper
INFO - 2018-11-21 07:38:20 --> Helper loaded: file_helper
INFO - 2018-11-21 07:38:20 --> Helper loaded: email_helper
INFO - 2018-11-21 07:38:20 --> Helper loaded: common_helper
INFO - 2018-11-21 07:38:20 --> Database Driver Class Initialized
DEBUG - 2018-11-21 07:38:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-21 07:38:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-21 07:38:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-21 07:38:20 --> Pagination Class Initialized
INFO - 2018-11-21 07:38:20 --> Helper loaded: form_helper
INFO - 2018-11-21 07:38:20 --> Form Validation Class Initialized
INFO - 2018-11-21 07:38:20 --> Model Class Initialized
INFO - 2018-11-21 07:38:20 --> Controller Class Initialized
INFO - 2018-11-21 07:38:20 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-21 07:38:20 --> Model Class Initialized
INFO - 2018-11-21 07:38:20 --> Model Class Initialized
INFO - 2018-11-21 07:38:20 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-21 07:38:20 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/change-password.php
INFO - 2018-11-21 07:38:20 --> Final output sent to browser
DEBUG - 2018-11-21 07:38:20 --> Total execution time: 0.0470
INFO - 2018-11-21 07:38:22 --> Config Class Initialized
INFO - 2018-11-21 07:38:22 --> Hooks Class Initialized
DEBUG - 2018-11-21 07:38:22 --> UTF-8 Support Enabled
INFO - 2018-11-21 07:38:22 --> Utf8 Class Initialized
INFO - 2018-11-21 07:38:22 --> URI Class Initialized
INFO - 2018-11-21 07:38:22 --> Router Class Initialized
INFO - 2018-11-21 07:38:22 --> Output Class Initialized
INFO - 2018-11-21 07:38:22 --> Security Class Initialized
DEBUG - 2018-11-21 07:38:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-21 07:38:22 --> Input Class Initialized
INFO - 2018-11-21 07:38:22 --> Language Class Initialized
ERROR - 2018-11-21 07:38:22 --> 404 Page Not Found: Plugins/images
INFO - 2018-11-21 07:39:09 --> Config Class Initialized
INFO - 2018-11-21 07:39:09 --> Hooks Class Initialized
DEBUG - 2018-11-21 07:39:09 --> UTF-8 Support Enabled
INFO - 2018-11-21 07:39:09 --> Utf8 Class Initialized
INFO - 2018-11-21 07:39:09 --> URI Class Initialized
INFO - 2018-11-21 07:39:09 --> Router Class Initialized
INFO - 2018-11-21 07:39:09 --> Output Class Initialized
INFO - 2018-11-21 07:39:09 --> Security Class Initialized
DEBUG - 2018-11-21 07:39:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-21 07:39:09 --> Input Class Initialized
INFO - 2018-11-21 07:39:09 --> Language Class Initialized
INFO - 2018-11-21 07:39:09 --> Loader Class Initialized
INFO - 2018-11-21 07:39:09 --> Helper loaded: url_helper
INFO - 2018-11-21 07:39:09 --> Helper loaded: file_helper
INFO - 2018-11-21 07:39:09 --> Helper loaded: email_helper
INFO - 2018-11-21 07:39:09 --> Helper loaded: common_helper
INFO - 2018-11-21 07:39:09 --> Database Driver Class Initialized
DEBUG - 2018-11-21 07:39:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-21 07:39:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-21 07:39:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-21 07:39:09 --> Pagination Class Initialized
INFO - 2018-11-21 07:39:09 --> Helper loaded: form_helper
INFO - 2018-11-21 07:39:09 --> Form Validation Class Initialized
INFO - 2018-11-21 07:39:09 --> Model Class Initialized
INFO - 2018-11-21 07:39:09 --> Controller Class Initialized
INFO - 2018-11-21 07:39:09 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-21 07:39:09 --> Model Class Initialized
INFO - 2018-11-21 07:39:09 --> Model Class Initialized
INFO - 2018-11-21 07:39:09 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-21 07:39:09 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/change-password.php
INFO - 2018-11-21 07:39:09 --> Final output sent to browser
DEBUG - 2018-11-21 07:39:09 --> Total execution time: 0.0600
INFO - 2018-11-21 07:39:10 --> Config Class Initialized
INFO - 2018-11-21 07:39:10 --> Hooks Class Initialized
DEBUG - 2018-11-21 07:39:10 --> UTF-8 Support Enabled
INFO - 2018-11-21 07:39:10 --> Utf8 Class Initialized
INFO - 2018-11-21 07:39:10 --> URI Class Initialized
INFO - 2018-11-21 07:39:10 --> Router Class Initialized
INFO - 2018-11-21 07:39:10 --> Output Class Initialized
INFO - 2018-11-21 07:39:10 --> Security Class Initialized
DEBUG - 2018-11-21 07:39:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-21 07:39:10 --> Input Class Initialized
INFO - 2018-11-21 07:39:10 --> Language Class Initialized
ERROR - 2018-11-21 07:39:10 --> 404 Page Not Found: Plugins/images
INFO - 2018-11-21 07:42:16 --> Config Class Initialized
INFO - 2018-11-21 07:42:16 --> Hooks Class Initialized
DEBUG - 2018-11-21 07:42:16 --> UTF-8 Support Enabled
INFO - 2018-11-21 07:42:16 --> Utf8 Class Initialized
INFO - 2018-11-21 07:42:16 --> URI Class Initialized
INFO - 2018-11-21 07:42:16 --> Router Class Initialized
INFO - 2018-11-21 07:42:16 --> Output Class Initialized
INFO - 2018-11-21 07:42:16 --> Security Class Initialized
DEBUG - 2018-11-21 07:42:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-21 07:42:16 --> Input Class Initialized
INFO - 2018-11-21 07:42:16 --> Language Class Initialized
INFO - 2018-11-21 07:42:16 --> Loader Class Initialized
INFO - 2018-11-21 07:42:16 --> Helper loaded: url_helper
INFO - 2018-11-21 07:42:16 --> Helper loaded: file_helper
INFO - 2018-11-21 07:42:16 --> Helper loaded: email_helper
INFO - 2018-11-21 07:42:16 --> Helper loaded: common_helper
INFO - 2018-11-21 07:42:16 --> Database Driver Class Initialized
DEBUG - 2018-11-21 07:42:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-21 07:42:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-21 07:42:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-21 07:42:16 --> Pagination Class Initialized
INFO - 2018-11-21 07:42:16 --> Helper loaded: form_helper
INFO - 2018-11-21 07:42:16 --> Form Validation Class Initialized
INFO - 2018-11-21 07:42:16 --> Model Class Initialized
INFO - 2018-11-21 07:42:16 --> Controller Class Initialized
INFO - 2018-11-21 07:42:16 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-21 07:42:16 --> Model Class Initialized
INFO - 2018-11-21 07:42:16 --> Model Class Initialized
INFO - 2018-11-21 07:42:16 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-21 07:42:16 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/change-password.php
INFO - 2018-11-21 07:42:16 --> Final output sent to browser
DEBUG - 2018-11-21 07:42:16 --> Total execution time: 0.0500
INFO - 2018-11-21 07:42:17 --> Config Class Initialized
INFO - 2018-11-21 07:42:17 --> Hooks Class Initialized
DEBUG - 2018-11-21 07:42:17 --> UTF-8 Support Enabled
INFO - 2018-11-21 07:42:17 --> Utf8 Class Initialized
INFO - 2018-11-21 07:42:17 --> URI Class Initialized
INFO - 2018-11-21 07:42:17 --> Router Class Initialized
INFO - 2018-11-21 07:42:17 --> Output Class Initialized
INFO - 2018-11-21 07:42:17 --> Security Class Initialized
DEBUG - 2018-11-21 07:42:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-21 07:42:17 --> Input Class Initialized
INFO - 2018-11-21 07:42:17 --> Language Class Initialized
ERROR - 2018-11-21 07:42:17 --> 404 Page Not Found: Plugins/images
INFO - 2018-11-21 07:42:34 --> Config Class Initialized
INFO - 2018-11-21 07:42:34 --> Hooks Class Initialized
DEBUG - 2018-11-21 07:42:34 --> UTF-8 Support Enabled
INFO - 2018-11-21 07:42:34 --> Utf8 Class Initialized
INFO - 2018-11-21 07:42:34 --> URI Class Initialized
INFO - 2018-11-21 07:42:34 --> Router Class Initialized
INFO - 2018-11-21 07:42:34 --> Output Class Initialized
INFO - 2018-11-21 07:42:34 --> Security Class Initialized
DEBUG - 2018-11-21 07:42:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-21 07:42:34 --> Input Class Initialized
INFO - 2018-11-21 07:42:34 --> Language Class Initialized
INFO - 2018-11-21 07:42:34 --> Loader Class Initialized
INFO - 2018-11-21 07:42:34 --> Helper loaded: url_helper
INFO - 2018-11-21 07:42:34 --> Helper loaded: file_helper
INFO - 2018-11-21 07:42:34 --> Helper loaded: email_helper
INFO - 2018-11-21 07:42:34 --> Helper loaded: common_helper
INFO - 2018-11-21 07:42:34 --> Database Driver Class Initialized
DEBUG - 2018-11-21 07:42:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-21 07:42:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-21 07:42:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-21 07:42:34 --> Pagination Class Initialized
INFO - 2018-11-21 07:42:34 --> Helper loaded: form_helper
INFO - 2018-11-21 07:42:34 --> Form Validation Class Initialized
INFO - 2018-11-21 07:42:34 --> Model Class Initialized
INFO - 2018-11-21 07:42:34 --> Controller Class Initialized
INFO - 2018-11-21 07:42:34 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-21 07:42:34 --> Model Class Initialized
INFO - 2018-11-21 07:42:34 --> Model Class Initialized
INFO - 2018-11-21 07:42:34 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-21 07:42:34 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/change-password.php
INFO - 2018-11-21 07:42:34 --> Final output sent to browser
DEBUG - 2018-11-21 07:42:34 --> Total execution time: 0.0500
INFO - 2018-11-21 07:42:36 --> Config Class Initialized
INFO - 2018-11-21 07:42:36 --> Hooks Class Initialized
DEBUG - 2018-11-21 07:42:36 --> UTF-8 Support Enabled
INFO - 2018-11-21 07:42:36 --> Utf8 Class Initialized
INFO - 2018-11-21 07:42:36 --> URI Class Initialized
INFO - 2018-11-21 07:42:36 --> Router Class Initialized
INFO - 2018-11-21 07:42:36 --> Output Class Initialized
INFO - 2018-11-21 07:42:36 --> Security Class Initialized
DEBUG - 2018-11-21 07:42:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-21 07:42:36 --> Input Class Initialized
INFO - 2018-11-21 07:42:36 --> Language Class Initialized
ERROR - 2018-11-21 07:42:36 --> 404 Page Not Found: Plugins/images
INFO - 2018-11-21 07:44:27 --> Config Class Initialized
INFO - 2018-11-21 07:44:27 --> Hooks Class Initialized
DEBUG - 2018-11-21 07:44:27 --> UTF-8 Support Enabled
INFO - 2018-11-21 07:44:27 --> Utf8 Class Initialized
INFO - 2018-11-21 07:44:27 --> URI Class Initialized
INFO - 2018-11-21 07:44:27 --> Router Class Initialized
INFO - 2018-11-21 07:44:27 --> Output Class Initialized
INFO - 2018-11-21 07:44:27 --> Security Class Initialized
DEBUG - 2018-11-21 07:44:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-21 07:44:27 --> Input Class Initialized
INFO - 2018-11-21 07:44:27 --> Language Class Initialized
INFO - 2018-11-21 07:44:27 --> Loader Class Initialized
INFO - 2018-11-21 07:44:27 --> Helper loaded: url_helper
INFO - 2018-11-21 07:44:27 --> Helper loaded: file_helper
INFO - 2018-11-21 07:44:27 --> Helper loaded: email_helper
INFO - 2018-11-21 07:44:27 --> Helper loaded: common_helper
INFO - 2018-11-21 07:44:27 --> Database Driver Class Initialized
DEBUG - 2018-11-21 07:44:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-21 07:44:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-21 07:44:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-21 07:44:27 --> Pagination Class Initialized
INFO - 2018-11-21 07:44:27 --> Helper loaded: form_helper
INFO - 2018-11-21 07:44:27 --> Form Validation Class Initialized
INFO - 2018-11-21 07:44:27 --> Model Class Initialized
INFO - 2018-11-21 07:44:27 --> Controller Class Initialized
INFO - 2018-11-21 07:44:27 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-21 07:44:27 --> Model Class Initialized
INFO - 2018-11-21 07:44:27 --> Model Class Initialized
INFO - 2018-11-21 07:44:27 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-21 07:44:27 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/change-password.php
INFO - 2018-11-21 07:44:27 --> Final output sent to browser
DEBUG - 2018-11-21 07:44:27 --> Total execution time: 0.0550
INFO - 2018-11-21 07:46:00 --> Config Class Initialized
INFO - 2018-11-21 07:46:00 --> Hooks Class Initialized
DEBUG - 2018-11-21 07:46:00 --> UTF-8 Support Enabled
INFO - 2018-11-21 07:46:00 --> Utf8 Class Initialized
INFO - 2018-11-21 07:46:00 --> URI Class Initialized
INFO - 2018-11-21 07:46:00 --> Router Class Initialized
INFO - 2018-11-21 07:46:00 --> Output Class Initialized
INFO - 2018-11-21 07:46:00 --> Security Class Initialized
DEBUG - 2018-11-21 07:46:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-21 07:46:00 --> Input Class Initialized
INFO - 2018-11-21 07:46:00 --> Language Class Initialized
INFO - 2018-11-21 07:46:00 --> Loader Class Initialized
INFO - 2018-11-21 07:46:00 --> Helper loaded: url_helper
INFO - 2018-11-21 07:46:00 --> Helper loaded: file_helper
INFO - 2018-11-21 07:46:00 --> Helper loaded: email_helper
INFO - 2018-11-21 07:46:00 --> Helper loaded: common_helper
INFO - 2018-11-21 07:46:00 --> Database Driver Class Initialized
DEBUG - 2018-11-21 07:46:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-21 07:46:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-21 07:46:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-21 07:46:00 --> Pagination Class Initialized
INFO - 2018-11-21 07:46:00 --> Helper loaded: form_helper
INFO - 2018-11-21 07:46:00 --> Form Validation Class Initialized
INFO - 2018-11-21 07:46:00 --> Model Class Initialized
INFO - 2018-11-21 07:46:00 --> Controller Class Initialized
INFO - 2018-11-21 07:46:00 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-21 07:46:00 --> Model Class Initialized
INFO - 2018-11-21 07:46:00 --> Model Class Initialized
INFO - 2018-11-21 07:46:00 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-21 07:46:00 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/change-password.php
INFO - 2018-11-21 07:46:00 --> Final output sent to browser
DEBUG - 2018-11-21 07:46:00 --> Total execution time: 0.0470
INFO - 2018-11-21 07:46:55 --> Config Class Initialized
INFO - 2018-11-21 07:46:55 --> Hooks Class Initialized
DEBUG - 2018-11-21 07:46:55 --> UTF-8 Support Enabled
INFO - 2018-11-21 07:46:55 --> Utf8 Class Initialized
INFO - 2018-11-21 07:46:55 --> URI Class Initialized
INFO - 2018-11-21 07:46:55 --> Router Class Initialized
INFO - 2018-11-21 07:46:55 --> Output Class Initialized
INFO - 2018-11-21 07:46:55 --> Security Class Initialized
DEBUG - 2018-11-21 07:46:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-21 07:46:55 --> Input Class Initialized
INFO - 2018-11-21 07:46:55 --> Language Class Initialized
INFO - 2018-11-21 07:46:55 --> Loader Class Initialized
INFO - 2018-11-21 07:46:55 --> Helper loaded: url_helper
INFO - 2018-11-21 07:46:55 --> Helper loaded: file_helper
INFO - 2018-11-21 07:46:55 --> Helper loaded: email_helper
INFO - 2018-11-21 07:46:55 --> Helper loaded: common_helper
INFO - 2018-11-21 07:46:55 --> Database Driver Class Initialized
DEBUG - 2018-11-21 07:46:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-21 07:46:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-21 07:46:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-21 07:46:55 --> Pagination Class Initialized
INFO - 2018-11-21 07:46:55 --> Helper loaded: form_helper
INFO - 2018-11-21 07:46:55 --> Form Validation Class Initialized
INFO - 2018-11-21 07:46:55 --> Model Class Initialized
INFO - 2018-11-21 07:46:55 --> Controller Class Initialized
INFO - 2018-11-21 07:46:55 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-21 07:46:55 --> Model Class Initialized
INFO - 2018-11-21 07:46:55 --> Model Class Initialized
INFO - 2018-11-21 07:46:55 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-21 07:46:55 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/change-password.php
INFO - 2018-11-21 07:46:55 --> Final output sent to browser
DEBUG - 2018-11-21 07:46:55 --> Total execution time: 0.0440
INFO - 2018-11-21 07:55:35 --> Config Class Initialized
INFO - 2018-11-21 07:55:35 --> Hooks Class Initialized
DEBUG - 2018-11-21 07:55:35 --> UTF-8 Support Enabled
INFO - 2018-11-21 07:55:35 --> Utf8 Class Initialized
INFO - 2018-11-21 07:55:35 --> URI Class Initialized
INFO - 2018-11-21 07:55:35 --> Router Class Initialized
INFO - 2018-11-21 07:55:35 --> Output Class Initialized
INFO - 2018-11-21 07:55:35 --> Security Class Initialized
DEBUG - 2018-11-21 07:55:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-21 07:55:35 --> Input Class Initialized
INFO - 2018-11-21 07:55:35 --> Language Class Initialized
INFO - 2018-11-21 07:55:35 --> Loader Class Initialized
INFO - 2018-11-21 07:55:35 --> Helper loaded: url_helper
INFO - 2018-11-21 07:55:35 --> Helper loaded: file_helper
INFO - 2018-11-21 07:55:35 --> Helper loaded: email_helper
INFO - 2018-11-21 07:55:35 --> Helper loaded: common_helper
INFO - 2018-11-21 07:55:35 --> Database Driver Class Initialized
DEBUG - 2018-11-21 07:55:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-21 07:55:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-21 07:55:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-21 07:55:35 --> Pagination Class Initialized
INFO - 2018-11-21 07:55:35 --> Helper loaded: form_helper
INFO - 2018-11-21 07:55:35 --> Form Validation Class Initialized
INFO - 2018-11-21 07:55:35 --> Model Class Initialized
INFO - 2018-11-21 07:55:35 --> Controller Class Initialized
INFO - 2018-11-21 07:55:35 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-21 07:55:35 --> Model Class Initialized
INFO - 2018-11-21 07:55:35 --> Model Class Initialized
INFO - 2018-11-21 07:55:35 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-21 07:55:35 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/change-password.php
INFO - 2018-11-21 07:55:35 --> Final output sent to browser
DEBUG - 2018-11-21 07:55:35 --> Total execution time: 0.0700
INFO - 2018-11-21 07:57:12 --> Config Class Initialized
INFO - 2018-11-21 07:57:12 --> Hooks Class Initialized
DEBUG - 2018-11-21 07:57:12 --> UTF-8 Support Enabled
INFO - 2018-11-21 07:57:12 --> Utf8 Class Initialized
INFO - 2018-11-21 07:57:12 --> URI Class Initialized
INFO - 2018-11-21 07:57:12 --> Router Class Initialized
INFO - 2018-11-21 07:57:12 --> Output Class Initialized
INFO - 2018-11-21 07:57:12 --> Security Class Initialized
DEBUG - 2018-11-21 07:57:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-21 07:57:12 --> Input Class Initialized
INFO - 2018-11-21 07:57:12 --> Language Class Initialized
INFO - 2018-11-21 07:57:12 --> Loader Class Initialized
INFO - 2018-11-21 07:57:12 --> Helper loaded: url_helper
INFO - 2018-11-21 07:57:12 --> Helper loaded: file_helper
INFO - 2018-11-21 07:57:12 --> Helper loaded: email_helper
INFO - 2018-11-21 07:57:12 --> Helper loaded: common_helper
INFO - 2018-11-21 07:57:12 --> Database Driver Class Initialized
DEBUG - 2018-11-21 07:57:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-21 07:57:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-21 07:57:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-21 07:57:12 --> Pagination Class Initialized
INFO - 2018-11-21 07:57:12 --> Helper loaded: form_helper
INFO - 2018-11-21 07:57:12 --> Form Validation Class Initialized
INFO - 2018-11-21 07:57:12 --> Model Class Initialized
INFO - 2018-11-21 07:57:12 --> Controller Class Initialized
INFO - 2018-11-21 07:57:12 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-21 07:57:12 --> Model Class Initialized
INFO - 2018-11-21 07:57:12 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-21 07:57:12 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/sidebar.php
INFO - 2018-11-21 07:57:12 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/right-sidebar.php
INFO - 2018-11-21 07:57:12 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/footer.php
INFO - 2018-11-21 07:57:12 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/dashboard.php
INFO - 2018-11-21 07:57:12 --> Final output sent to browser
DEBUG - 2018-11-21 07:57:12 --> Total execution time: 0.0530
INFO - 2018-11-21 07:58:25 --> Config Class Initialized
INFO - 2018-11-21 07:58:25 --> Hooks Class Initialized
DEBUG - 2018-11-21 07:58:25 --> UTF-8 Support Enabled
INFO - 2018-11-21 07:58:25 --> Utf8 Class Initialized
INFO - 2018-11-21 07:58:25 --> URI Class Initialized
INFO - 2018-11-21 07:58:25 --> Router Class Initialized
INFO - 2018-11-21 07:58:25 --> Output Class Initialized
INFO - 2018-11-21 07:58:25 --> Security Class Initialized
DEBUG - 2018-11-21 07:58:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-21 07:58:25 --> Input Class Initialized
INFO - 2018-11-21 07:58:25 --> Language Class Initialized
INFO - 2018-11-21 07:58:25 --> Loader Class Initialized
INFO - 2018-11-21 07:58:25 --> Helper loaded: url_helper
INFO - 2018-11-21 07:58:25 --> Helper loaded: file_helper
INFO - 2018-11-21 07:58:25 --> Helper loaded: email_helper
INFO - 2018-11-21 07:58:25 --> Helper loaded: common_helper
INFO - 2018-11-21 07:58:25 --> Database Driver Class Initialized
DEBUG - 2018-11-21 07:58:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-21 07:58:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-21 07:58:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-21 07:58:25 --> Pagination Class Initialized
INFO - 2018-11-21 07:58:25 --> Helper loaded: form_helper
INFO - 2018-11-21 07:58:25 --> Form Validation Class Initialized
INFO - 2018-11-21 07:58:25 --> Model Class Initialized
INFO - 2018-11-21 07:58:25 --> Controller Class Initialized
INFO - 2018-11-21 07:58:25 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-21 07:58:25 --> Model Class Initialized
INFO - 2018-11-21 07:58:25 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-21 07:58:25 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/sidebar.php
INFO - 2018-11-21 07:58:25 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/right-sidebar.php
INFO - 2018-11-21 07:58:25 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/footer.php
INFO - 2018-11-21 07:58:25 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/dashboard.php
INFO - 2018-11-21 07:58:25 --> Final output sent to browser
DEBUG - 2018-11-21 07:58:25 --> Total execution time: 0.0610
INFO - 2018-11-21 08:00:46 --> Config Class Initialized
INFO - 2018-11-21 08:00:46 --> Hooks Class Initialized
DEBUG - 2018-11-21 08:00:46 --> UTF-8 Support Enabled
INFO - 2018-11-21 08:00:46 --> Utf8 Class Initialized
INFO - 2018-11-21 08:00:46 --> URI Class Initialized
INFO - 2018-11-21 08:00:46 --> Router Class Initialized
INFO - 2018-11-21 08:00:46 --> Output Class Initialized
INFO - 2018-11-21 08:00:46 --> Security Class Initialized
DEBUG - 2018-11-21 08:00:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-21 08:00:46 --> Input Class Initialized
INFO - 2018-11-21 08:00:46 --> Language Class Initialized
INFO - 2018-11-21 08:00:46 --> Loader Class Initialized
INFO - 2018-11-21 08:00:46 --> Helper loaded: url_helper
INFO - 2018-11-21 08:00:46 --> Helper loaded: file_helper
INFO - 2018-11-21 08:00:46 --> Helper loaded: email_helper
INFO - 2018-11-21 08:00:46 --> Helper loaded: common_helper
INFO - 2018-11-21 08:00:46 --> Database Driver Class Initialized
DEBUG - 2018-11-21 08:00:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-21 08:00:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-21 08:00:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-21 08:00:46 --> Pagination Class Initialized
INFO - 2018-11-21 08:00:46 --> Helper loaded: form_helper
INFO - 2018-11-21 08:00:46 --> Form Validation Class Initialized
INFO - 2018-11-21 08:00:46 --> Model Class Initialized
INFO - 2018-11-21 08:00:46 --> Controller Class Initialized
INFO - 2018-11-21 08:00:46 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-21 08:00:46 --> Model Class Initialized
INFO - 2018-11-21 08:00:46 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-21 08:00:46 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/sidebar.php
INFO - 2018-11-21 08:00:46 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/right-sidebar.php
INFO - 2018-11-21 08:00:46 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/footer.php
INFO - 2018-11-21 08:00:46 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/dashboard.php
INFO - 2018-11-21 08:00:46 --> Final output sent to browser
DEBUG - 2018-11-21 08:00:46 --> Total execution time: 0.0440
INFO - 2018-11-21 08:01:32 --> Config Class Initialized
INFO - 2018-11-21 08:01:32 --> Hooks Class Initialized
DEBUG - 2018-11-21 08:01:32 --> UTF-8 Support Enabled
INFO - 2018-11-21 08:01:32 --> Utf8 Class Initialized
INFO - 2018-11-21 08:01:32 --> URI Class Initialized
INFO - 2018-11-21 08:01:32 --> Router Class Initialized
INFO - 2018-11-21 08:01:32 --> Output Class Initialized
INFO - 2018-11-21 08:01:32 --> Security Class Initialized
DEBUG - 2018-11-21 08:01:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-21 08:01:32 --> Input Class Initialized
INFO - 2018-11-21 08:01:32 --> Language Class Initialized
INFO - 2018-11-21 08:01:32 --> Loader Class Initialized
INFO - 2018-11-21 08:01:32 --> Helper loaded: url_helper
INFO - 2018-11-21 08:01:32 --> Helper loaded: file_helper
INFO - 2018-11-21 08:01:32 --> Helper loaded: email_helper
INFO - 2018-11-21 08:01:32 --> Helper loaded: common_helper
INFO - 2018-11-21 08:01:32 --> Database Driver Class Initialized
DEBUG - 2018-11-21 08:01:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-21 08:01:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-21 08:01:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-21 08:01:32 --> Pagination Class Initialized
INFO - 2018-11-21 08:01:32 --> Helper loaded: form_helper
INFO - 2018-11-21 08:01:32 --> Form Validation Class Initialized
INFO - 2018-11-21 08:01:32 --> Model Class Initialized
INFO - 2018-11-21 08:01:32 --> Controller Class Initialized
INFO - 2018-11-21 08:01:32 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-21 08:01:32 --> Model Class Initialized
INFO - 2018-11-21 08:01:32 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-21 08:01:32 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/sidebar.php
INFO - 2018-11-21 08:01:32 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/right-sidebar.php
INFO - 2018-11-21 08:01:32 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/footer.php
INFO - 2018-11-21 08:01:32 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/dashboard.php
INFO - 2018-11-21 08:01:32 --> Final output sent to browser
DEBUG - 2018-11-21 08:01:32 --> Total execution time: 0.0560
INFO - 2018-11-21 08:01:53 --> Config Class Initialized
INFO - 2018-11-21 08:01:53 --> Hooks Class Initialized
DEBUG - 2018-11-21 08:01:53 --> UTF-8 Support Enabled
INFO - 2018-11-21 08:01:53 --> Utf8 Class Initialized
INFO - 2018-11-21 08:01:53 --> URI Class Initialized
INFO - 2018-11-21 08:01:53 --> Router Class Initialized
INFO - 2018-11-21 08:01:53 --> Output Class Initialized
INFO - 2018-11-21 08:01:53 --> Security Class Initialized
DEBUG - 2018-11-21 08:01:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-21 08:01:53 --> Input Class Initialized
INFO - 2018-11-21 08:01:53 --> Language Class Initialized
INFO - 2018-11-21 08:01:53 --> Loader Class Initialized
INFO - 2018-11-21 08:01:53 --> Helper loaded: url_helper
INFO - 2018-11-21 08:01:53 --> Helper loaded: file_helper
INFO - 2018-11-21 08:01:53 --> Helper loaded: email_helper
INFO - 2018-11-21 08:01:53 --> Helper loaded: common_helper
INFO - 2018-11-21 08:01:53 --> Database Driver Class Initialized
DEBUG - 2018-11-21 08:01:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-21 08:01:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-21 08:01:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-21 08:01:53 --> Pagination Class Initialized
INFO - 2018-11-21 08:01:53 --> Helper loaded: form_helper
INFO - 2018-11-21 08:01:53 --> Form Validation Class Initialized
INFO - 2018-11-21 08:01:53 --> Model Class Initialized
INFO - 2018-11-21 08:01:53 --> Controller Class Initialized
INFO - 2018-11-21 08:01:53 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-21 08:01:53 --> Model Class Initialized
INFO - 2018-11-21 08:01:53 --> Model Class Initialized
INFO - 2018-11-21 08:01:53 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-21 08:01:53 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/change-password.php
INFO - 2018-11-21 08:01:53 --> Final output sent to browser
DEBUG - 2018-11-21 08:01:53 --> Total execution time: 0.0530
INFO - 2018-11-21 08:03:09 --> Config Class Initialized
INFO - 2018-11-21 08:03:09 --> Hooks Class Initialized
DEBUG - 2018-11-21 08:03:09 --> UTF-8 Support Enabled
INFO - 2018-11-21 08:03:09 --> Utf8 Class Initialized
INFO - 2018-11-21 08:03:09 --> URI Class Initialized
INFO - 2018-11-21 08:03:09 --> Router Class Initialized
INFO - 2018-11-21 08:03:09 --> Output Class Initialized
INFO - 2018-11-21 08:03:09 --> Security Class Initialized
DEBUG - 2018-11-21 08:03:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-21 08:03:09 --> Input Class Initialized
INFO - 2018-11-21 08:03:09 --> Language Class Initialized
INFO - 2018-11-21 08:03:09 --> Loader Class Initialized
INFO - 2018-11-21 08:03:09 --> Helper loaded: url_helper
INFO - 2018-11-21 08:03:09 --> Helper loaded: file_helper
INFO - 2018-11-21 08:03:09 --> Helper loaded: email_helper
INFO - 2018-11-21 08:03:09 --> Helper loaded: common_helper
INFO - 2018-11-21 08:03:09 --> Database Driver Class Initialized
DEBUG - 2018-11-21 08:03:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-21 08:03:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-21 08:03:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-21 08:03:09 --> Pagination Class Initialized
INFO - 2018-11-21 08:03:09 --> Helper loaded: form_helper
INFO - 2018-11-21 08:03:09 --> Form Validation Class Initialized
INFO - 2018-11-21 08:03:09 --> Model Class Initialized
INFO - 2018-11-21 08:03:09 --> Controller Class Initialized
INFO - 2018-11-21 08:03:09 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-21 08:03:09 --> Model Class Initialized
INFO - 2018-11-21 08:03:09 --> Model Class Initialized
INFO - 2018-11-21 08:03:09 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-21 08:03:09 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/change-password.php
INFO - 2018-11-21 08:03:09 --> Final output sent to browser
DEBUG - 2018-11-21 08:03:09 --> Total execution time: 0.0560
INFO - 2018-11-21 08:05:12 --> Config Class Initialized
INFO - 2018-11-21 08:05:12 --> Hooks Class Initialized
DEBUG - 2018-11-21 08:05:12 --> UTF-8 Support Enabled
INFO - 2018-11-21 08:05:12 --> Utf8 Class Initialized
INFO - 2018-11-21 08:05:12 --> URI Class Initialized
INFO - 2018-11-21 08:05:12 --> Router Class Initialized
INFO - 2018-11-21 08:05:13 --> Output Class Initialized
INFO - 2018-11-21 08:05:13 --> Security Class Initialized
DEBUG - 2018-11-21 08:05:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-21 08:05:13 --> Input Class Initialized
INFO - 2018-11-21 08:05:13 --> Language Class Initialized
INFO - 2018-11-21 08:05:13 --> Loader Class Initialized
INFO - 2018-11-21 08:05:13 --> Helper loaded: url_helper
INFO - 2018-11-21 08:05:13 --> Helper loaded: file_helper
INFO - 2018-11-21 08:05:13 --> Helper loaded: email_helper
INFO - 2018-11-21 08:05:13 --> Helper loaded: common_helper
INFO - 2018-11-21 08:05:13 --> Database Driver Class Initialized
DEBUG - 2018-11-21 08:05:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-21 08:05:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-21 08:05:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-21 08:05:13 --> Pagination Class Initialized
INFO - 2018-11-21 08:05:13 --> Helper loaded: form_helper
INFO - 2018-11-21 08:05:13 --> Form Validation Class Initialized
INFO - 2018-11-21 08:05:13 --> Model Class Initialized
INFO - 2018-11-21 08:05:13 --> Controller Class Initialized
INFO - 2018-11-21 08:05:13 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-21 08:05:13 --> Model Class Initialized
INFO - 2018-11-21 08:05:13 --> Model Class Initialized
INFO - 2018-11-21 08:05:13 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-21 08:05:13 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/change-password.php
INFO - 2018-11-21 08:05:13 --> Final output sent to browser
DEBUG - 2018-11-21 08:05:13 --> Total execution time: 0.0580
INFO - 2018-11-21 08:08:38 --> Config Class Initialized
INFO - 2018-11-21 08:08:38 --> Hooks Class Initialized
DEBUG - 2018-11-21 08:08:38 --> UTF-8 Support Enabled
INFO - 2018-11-21 08:08:38 --> Utf8 Class Initialized
INFO - 2018-11-21 08:08:38 --> URI Class Initialized
INFO - 2018-11-21 08:08:38 --> Router Class Initialized
INFO - 2018-11-21 08:08:38 --> Output Class Initialized
INFO - 2018-11-21 08:08:38 --> Security Class Initialized
DEBUG - 2018-11-21 08:08:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-21 08:08:38 --> Input Class Initialized
INFO - 2018-11-21 08:08:38 --> Language Class Initialized
INFO - 2018-11-21 08:08:38 --> Loader Class Initialized
INFO - 2018-11-21 08:08:38 --> Helper loaded: url_helper
INFO - 2018-11-21 08:08:38 --> Helper loaded: file_helper
INFO - 2018-11-21 08:08:38 --> Helper loaded: email_helper
INFO - 2018-11-21 08:08:38 --> Helper loaded: common_helper
INFO - 2018-11-21 08:08:38 --> Database Driver Class Initialized
DEBUG - 2018-11-21 08:08:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-21 08:08:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-21 08:08:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-21 08:08:38 --> Pagination Class Initialized
INFO - 2018-11-21 08:08:38 --> Helper loaded: form_helper
INFO - 2018-11-21 08:08:38 --> Form Validation Class Initialized
INFO - 2018-11-21 08:08:38 --> Model Class Initialized
INFO - 2018-11-21 08:08:38 --> Controller Class Initialized
INFO - 2018-11-21 08:08:38 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-21 08:08:38 --> Model Class Initialized
INFO - 2018-11-21 08:08:38 --> Model Class Initialized
INFO - 2018-11-21 08:08:38 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-21 08:08:38 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/change-password.php
INFO - 2018-11-21 08:08:38 --> Final output sent to browser
DEBUG - 2018-11-21 08:08:38 --> Total execution time: 0.0550
INFO - 2018-11-21 08:10:00 --> Config Class Initialized
INFO - 2018-11-21 08:10:00 --> Hooks Class Initialized
DEBUG - 2018-11-21 08:10:00 --> UTF-8 Support Enabled
INFO - 2018-11-21 08:10:00 --> Utf8 Class Initialized
INFO - 2018-11-21 08:10:00 --> URI Class Initialized
INFO - 2018-11-21 08:10:00 --> Router Class Initialized
INFO - 2018-11-21 08:10:00 --> Output Class Initialized
INFO - 2018-11-21 08:10:00 --> Security Class Initialized
DEBUG - 2018-11-21 08:10:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-21 08:10:00 --> Input Class Initialized
INFO - 2018-11-21 08:10:00 --> Language Class Initialized
INFO - 2018-11-21 08:10:00 --> Loader Class Initialized
INFO - 2018-11-21 08:10:00 --> Helper loaded: url_helper
INFO - 2018-11-21 08:10:00 --> Helper loaded: file_helper
INFO - 2018-11-21 08:10:00 --> Helper loaded: email_helper
INFO - 2018-11-21 08:10:00 --> Helper loaded: common_helper
INFO - 2018-11-21 08:10:00 --> Database Driver Class Initialized
DEBUG - 2018-11-21 08:10:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-21 08:10:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-21 08:10:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-21 08:10:00 --> Pagination Class Initialized
INFO - 2018-11-21 08:10:00 --> Helper loaded: form_helper
INFO - 2018-11-21 08:10:00 --> Form Validation Class Initialized
INFO - 2018-11-21 08:10:00 --> Model Class Initialized
INFO - 2018-11-21 08:10:00 --> Controller Class Initialized
INFO - 2018-11-21 08:10:00 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-21 08:10:00 --> Model Class Initialized
INFO - 2018-11-21 08:10:00 --> Model Class Initialized
INFO - 2018-11-21 08:10:00 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-21 08:10:00 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/change-password.php
INFO - 2018-11-21 08:10:00 --> Final output sent to browser
DEBUG - 2018-11-21 08:10:00 --> Total execution time: 0.0580
INFO - 2018-11-21 08:10:53 --> Config Class Initialized
INFO - 2018-11-21 08:10:53 --> Hooks Class Initialized
DEBUG - 2018-11-21 08:10:53 --> UTF-8 Support Enabled
INFO - 2018-11-21 08:10:53 --> Utf8 Class Initialized
INFO - 2018-11-21 08:10:53 --> URI Class Initialized
INFO - 2018-11-21 08:10:53 --> Router Class Initialized
INFO - 2018-11-21 08:10:53 --> Output Class Initialized
INFO - 2018-11-21 08:10:53 --> Security Class Initialized
DEBUG - 2018-11-21 08:10:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-21 08:10:53 --> Input Class Initialized
INFO - 2018-11-21 08:10:53 --> Language Class Initialized
INFO - 2018-11-21 08:10:53 --> Loader Class Initialized
INFO - 2018-11-21 08:10:53 --> Helper loaded: url_helper
INFO - 2018-11-21 08:10:53 --> Helper loaded: file_helper
INFO - 2018-11-21 08:10:53 --> Helper loaded: email_helper
INFO - 2018-11-21 08:10:53 --> Helper loaded: common_helper
INFO - 2018-11-21 08:10:53 --> Database Driver Class Initialized
DEBUG - 2018-11-21 08:10:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-21 08:10:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-21 08:10:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-21 08:10:53 --> Pagination Class Initialized
INFO - 2018-11-21 08:10:53 --> Helper loaded: form_helper
INFO - 2018-11-21 08:10:53 --> Form Validation Class Initialized
INFO - 2018-11-21 08:10:53 --> Model Class Initialized
INFO - 2018-11-21 08:10:53 --> Controller Class Initialized
INFO - 2018-11-21 08:10:53 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-21 08:10:53 --> Model Class Initialized
INFO - 2018-11-21 08:10:53 --> Model Class Initialized
INFO - 2018-11-21 08:10:53 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-21 08:10:53 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/change-password.php
INFO - 2018-11-21 08:10:53 --> Final output sent to browser
DEBUG - 2018-11-21 08:10:53 --> Total execution time: 0.0530
INFO - 2018-11-21 08:22:44 --> Config Class Initialized
INFO - 2018-11-21 08:22:44 --> Hooks Class Initialized
DEBUG - 2018-11-21 08:22:44 --> UTF-8 Support Enabled
INFO - 2018-11-21 08:22:44 --> Utf8 Class Initialized
INFO - 2018-11-21 08:22:44 --> URI Class Initialized
INFO - 2018-11-21 08:22:44 --> Router Class Initialized
INFO - 2018-11-21 08:22:44 --> Output Class Initialized
INFO - 2018-11-21 08:22:44 --> Security Class Initialized
DEBUG - 2018-11-21 08:22:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-21 08:22:44 --> Input Class Initialized
INFO - 2018-11-21 08:22:44 --> Language Class Initialized
INFO - 2018-11-21 08:22:44 --> Loader Class Initialized
INFO - 2018-11-21 08:22:44 --> Helper loaded: url_helper
INFO - 2018-11-21 08:22:44 --> Helper loaded: file_helper
INFO - 2018-11-21 08:22:44 --> Helper loaded: email_helper
INFO - 2018-11-21 08:22:44 --> Helper loaded: common_helper
INFO - 2018-11-21 08:22:44 --> Database Driver Class Initialized
DEBUG - 2018-11-21 08:22:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-21 08:22:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-21 08:22:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-21 08:22:44 --> Pagination Class Initialized
INFO - 2018-11-21 08:22:44 --> Helper loaded: form_helper
INFO - 2018-11-21 08:22:44 --> Form Validation Class Initialized
INFO - 2018-11-21 08:22:44 --> Model Class Initialized
INFO - 2018-11-21 08:22:44 --> Controller Class Initialized
INFO - 2018-11-21 08:22:44 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-21 08:22:44 --> Model Class Initialized
INFO - 2018-11-21 08:22:44 --> Model Class Initialized
INFO - 2018-11-21 08:22:44 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-21 08:22:44 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/change-password.php
INFO - 2018-11-21 08:22:44 --> Final output sent to browser
DEBUG - 2018-11-21 08:22:44 --> Total execution time: 0.0490
INFO - 2018-11-21 08:23:39 --> Config Class Initialized
INFO - 2018-11-21 08:23:39 --> Hooks Class Initialized
DEBUG - 2018-11-21 08:23:39 --> UTF-8 Support Enabled
INFO - 2018-11-21 08:23:39 --> Utf8 Class Initialized
INFO - 2018-11-21 08:23:39 --> URI Class Initialized
INFO - 2018-11-21 08:23:39 --> Router Class Initialized
INFO - 2018-11-21 08:23:39 --> Output Class Initialized
INFO - 2018-11-21 08:23:39 --> Security Class Initialized
DEBUG - 2018-11-21 08:23:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-21 08:23:39 --> Input Class Initialized
INFO - 2018-11-21 08:23:39 --> Language Class Initialized
INFO - 2018-11-21 08:23:39 --> Loader Class Initialized
INFO - 2018-11-21 08:23:39 --> Helper loaded: url_helper
INFO - 2018-11-21 08:23:39 --> Helper loaded: file_helper
INFO - 2018-11-21 08:23:39 --> Helper loaded: email_helper
INFO - 2018-11-21 08:23:39 --> Helper loaded: common_helper
INFO - 2018-11-21 08:23:39 --> Database Driver Class Initialized
DEBUG - 2018-11-21 08:23:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-21 08:23:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-21 08:23:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-21 08:23:39 --> Pagination Class Initialized
INFO - 2018-11-21 08:23:39 --> Helper loaded: form_helper
INFO - 2018-11-21 08:23:39 --> Form Validation Class Initialized
INFO - 2018-11-21 08:23:39 --> Model Class Initialized
INFO - 2018-11-21 08:23:39 --> Controller Class Initialized
INFO - 2018-11-21 08:23:39 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-21 08:23:39 --> Model Class Initialized
INFO - 2018-11-21 08:23:39 --> Model Class Initialized
INFO - 2018-11-21 08:23:39 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-21 08:23:39 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/change-password.php
INFO - 2018-11-21 08:23:39 --> Final output sent to browser
DEBUG - 2018-11-21 08:23:39 --> Total execution time: 0.0560
INFO - 2018-11-21 08:25:00 --> Config Class Initialized
INFO - 2018-11-21 08:25:00 --> Hooks Class Initialized
DEBUG - 2018-11-21 08:25:00 --> UTF-8 Support Enabled
INFO - 2018-11-21 08:25:00 --> Utf8 Class Initialized
INFO - 2018-11-21 08:25:00 --> URI Class Initialized
INFO - 2018-11-21 08:25:00 --> Router Class Initialized
INFO - 2018-11-21 08:25:00 --> Output Class Initialized
INFO - 2018-11-21 08:25:00 --> Security Class Initialized
DEBUG - 2018-11-21 08:25:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-21 08:25:00 --> Input Class Initialized
INFO - 2018-11-21 08:25:00 --> Language Class Initialized
INFO - 2018-11-21 08:25:00 --> Loader Class Initialized
INFO - 2018-11-21 08:25:00 --> Helper loaded: url_helper
INFO - 2018-11-21 08:25:00 --> Helper loaded: file_helper
INFO - 2018-11-21 08:25:00 --> Helper loaded: email_helper
INFO - 2018-11-21 08:25:00 --> Helper loaded: common_helper
INFO - 2018-11-21 08:25:00 --> Database Driver Class Initialized
DEBUG - 2018-11-21 08:25:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-21 08:25:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-21 08:25:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-21 08:25:00 --> Pagination Class Initialized
INFO - 2018-11-21 08:25:00 --> Helper loaded: form_helper
INFO - 2018-11-21 08:25:00 --> Form Validation Class Initialized
INFO - 2018-11-21 08:25:00 --> Model Class Initialized
INFO - 2018-11-21 08:25:00 --> Controller Class Initialized
INFO - 2018-11-21 08:25:00 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-21 08:25:00 --> Model Class Initialized
INFO - 2018-11-21 08:25:00 --> Model Class Initialized
INFO - 2018-11-21 08:25:00 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-21 08:25:00 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/change-password.php
INFO - 2018-11-21 08:25:00 --> Final output sent to browser
DEBUG - 2018-11-21 08:25:00 --> Total execution time: 0.0530
INFO - 2018-11-21 08:25:15 --> Config Class Initialized
INFO - 2018-11-21 08:25:15 --> Hooks Class Initialized
DEBUG - 2018-11-21 08:25:15 --> UTF-8 Support Enabled
INFO - 2018-11-21 08:25:15 --> Utf8 Class Initialized
INFO - 2018-11-21 08:25:15 --> URI Class Initialized
INFO - 2018-11-21 08:25:15 --> Router Class Initialized
INFO - 2018-11-21 08:25:15 --> Output Class Initialized
INFO - 2018-11-21 08:25:15 --> Security Class Initialized
DEBUG - 2018-11-21 08:25:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-21 08:25:15 --> Input Class Initialized
INFO - 2018-11-21 08:25:15 --> Language Class Initialized
INFO - 2018-11-21 08:25:15 --> Loader Class Initialized
INFO - 2018-11-21 08:25:15 --> Helper loaded: url_helper
INFO - 2018-11-21 08:25:15 --> Helper loaded: file_helper
INFO - 2018-11-21 08:25:15 --> Helper loaded: email_helper
INFO - 2018-11-21 08:25:15 --> Helper loaded: common_helper
INFO - 2018-11-21 08:25:15 --> Database Driver Class Initialized
DEBUG - 2018-11-21 08:25:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-21 08:25:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-21 08:25:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-21 08:25:15 --> Pagination Class Initialized
INFO - 2018-11-21 08:25:15 --> Helper loaded: form_helper
INFO - 2018-11-21 08:25:15 --> Form Validation Class Initialized
INFO - 2018-11-21 08:25:15 --> Model Class Initialized
INFO - 2018-11-21 08:25:15 --> Controller Class Initialized
INFO - 2018-11-21 08:25:15 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-21 08:25:15 --> Model Class Initialized
INFO - 2018-11-21 08:25:15 --> Model Class Initialized
INFO - 2018-11-21 08:25:15 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-21 08:25:15 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/change-password.php
INFO - 2018-11-21 08:25:15 --> Final output sent to browser
DEBUG - 2018-11-21 08:25:15 --> Total execution time: 0.0610
INFO - 2018-11-21 08:25:27 --> Config Class Initialized
INFO - 2018-11-21 08:25:27 --> Hooks Class Initialized
DEBUG - 2018-11-21 08:25:27 --> UTF-8 Support Enabled
INFO - 2018-11-21 08:25:27 --> Utf8 Class Initialized
INFO - 2018-11-21 08:25:27 --> URI Class Initialized
INFO - 2018-11-21 08:25:27 --> Router Class Initialized
INFO - 2018-11-21 08:25:27 --> Output Class Initialized
INFO - 2018-11-21 08:25:27 --> Security Class Initialized
DEBUG - 2018-11-21 08:25:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-21 08:25:28 --> Input Class Initialized
INFO - 2018-11-21 08:25:28 --> Language Class Initialized
INFO - 2018-11-21 08:25:28 --> Loader Class Initialized
INFO - 2018-11-21 08:25:28 --> Helper loaded: url_helper
INFO - 2018-11-21 08:25:28 --> Helper loaded: file_helper
INFO - 2018-11-21 08:25:28 --> Helper loaded: email_helper
INFO - 2018-11-21 08:25:28 --> Helper loaded: common_helper
INFO - 2018-11-21 08:25:28 --> Database Driver Class Initialized
DEBUG - 2018-11-21 08:25:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-21 08:25:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-21 08:25:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-21 08:25:28 --> Pagination Class Initialized
INFO - 2018-11-21 08:25:28 --> Helper loaded: form_helper
INFO - 2018-11-21 08:25:28 --> Form Validation Class Initialized
INFO - 2018-11-21 08:25:28 --> Model Class Initialized
INFO - 2018-11-21 08:25:28 --> Controller Class Initialized
INFO - 2018-11-21 08:25:28 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-21 08:25:28 --> Model Class Initialized
INFO - 2018-11-21 08:25:28 --> Model Class Initialized
INFO - 2018-11-21 08:25:28 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-21 08:25:28 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/change-password.php
INFO - 2018-11-21 08:25:28 --> Final output sent to browser
DEBUG - 2018-11-21 08:25:28 --> Total execution time: 0.0590
INFO - 2018-11-21 08:25:43 --> Config Class Initialized
INFO - 2018-11-21 08:25:43 --> Hooks Class Initialized
DEBUG - 2018-11-21 08:25:43 --> UTF-8 Support Enabled
INFO - 2018-11-21 08:25:43 --> Utf8 Class Initialized
INFO - 2018-11-21 08:25:43 --> URI Class Initialized
INFO - 2018-11-21 08:25:43 --> Router Class Initialized
INFO - 2018-11-21 08:25:43 --> Output Class Initialized
INFO - 2018-11-21 08:25:43 --> Security Class Initialized
DEBUG - 2018-11-21 08:25:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-21 08:25:43 --> Input Class Initialized
INFO - 2018-11-21 08:25:43 --> Language Class Initialized
INFO - 2018-11-21 08:25:43 --> Loader Class Initialized
INFO - 2018-11-21 08:25:43 --> Helper loaded: url_helper
INFO - 2018-11-21 08:25:43 --> Helper loaded: file_helper
INFO - 2018-11-21 08:25:43 --> Helper loaded: email_helper
INFO - 2018-11-21 08:25:43 --> Helper loaded: common_helper
INFO - 2018-11-21 08:25:43 --> Database Driver Class Initialized
DEBUG - 2018-11-21 08:25:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-21 08:25:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-21 08:25:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-21 08:25:43 --> Pagination Class Initialized
INFO - 2018-11-21 08:25:43 --> Helper loaded: form_helper
INFO - 2018-11-21 08:25:43 --> Form Validation Class Initialized
INFO - 2018-11-21 08:25:43 --> Model Class Initialized
INFO - 2018-11-21 08:25:43 --> Controller Class Initialized
INFO - 2018-11-21 08:25:43 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-21 08:25:43 --> Model Class Initialized
INFO - 2018-11-21 08:25:43 --> Model Class Initialized
INFO - 2018-11-21 08:25:43 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-21 08:25:43 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/change-password.php
INFO - 2018-11-21 08:25:43 --> Final output sent to browser
DEBUG - 2018-11-21 08:25:43 --> Total execution time: 0.0870
INFO - 2018-11-21 08:26:26 --> Config Class Initialized
INFO - 2018-11-21 08:26:26 --> Hooks Class Initialized
DEBUG - 2018-11-21 08:26:26 --> UTF-8 Support Enabled
INFO - 2018-11-21 08:26:26 --> Utf8 Class Initialized
INFO - 2018-11-21 08:26:26 --> URI Class Initialized
INFO - 2018-11-21 08:26:26 --> Router Class Initialized
INFO - 2018-11-21 08:26:26 --> Output Class Initialized
INFO - 2018-11-21 08:26:26 --> Security Class Initialized
DEBUG - 2018-11-21 08:26:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-21 08:26:26 --> Input Class Initialized
INFO - 2018-11-21 08:26:26 --> Language Class Initialized
INFO - 2018-11-21 08:26:26 --> Loader Class Initialized
INFO - 2018-11-21 08:26:26 --> Helper loaded: url_helper
INFO - 2018-11-21 08:26:26 --> Helper loaded: file_helper
INFO - 2018-11-21 08:26:26 --> Helper loaded: email_helper
INFO - 2018-11-21 08:26:26 --> Helper loaded: common_helper
INFO - 2018-11-21 08:26:26 --> Database Driver Class Initialized
DEBUG - 2018-11-21 08:26:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-21 08:26:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-21 08:26:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-21 08:26:26 --> Pagination Class Initialized
INFO - 2018-11-21 08:26:26 --> Helper loaded: form_helper
INFO - 2018-11-21 08:26:26 --> Form Validation Class Initialized
INFO - 2018-11-21 08:26:26 --> Model Class Initialized
INFO - 2018-11-21 08:26:26 --> Controller Class Initialized
INFO - 2018-11-21 08:26:26 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-21 08:26:26 --> Model Class Initialized
INFO - 2018-11-21 08:26:26 --> Model Class Initialized
INFO - 2018-11-21 08:26:26 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-21 08:26:26 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/change-password.php
INFO - 2018-11-21 08:26:26 --> Final output sent to browser
DEBUG - 2018-11-21 08:26:26 --> Total execution time: 0.0520
INFO - 2018-11-21 08:28:25 --> Config Class Initialized
INFO - 2018-11-21 08:28:25 --> Hooks Class Initialized
DEBUG - 2018-11-21 08:28:25 --> UTF-8 Support Enabled
INFO - 2018-11-21 08:28:25 --> Utf8 Class Initialized
INFO - 2018-11-21 08:28:25 --> URI Class Initialized
INFO - 2018-11-21 08:28:25 --> Router Class Initialized
INFO - 2018-11-21 08:28:25 --> Output Class Initialized
INFO - 2018-11-21 08:28:25 --> Security Class Initialized
DEBUG - 2018-11-21 08:28:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-21 08:28:25 --> Input Class Initialized
INFO - 2018-11-21 08:28:25 --> Language Class Initialized
INFO - 2018-11-21 08:28:25 --> Loader Class Initialized
INFO - 2018-11-21 08:28:25 --> Helper loaded: url_helper
INFO - 2018-11-21 08:28:25 --> Helper loaded: file_helper
INFO - 2018-11-21 08:28:25 --> Helper loaded: email_helper
INFO - 2018-11-21 08:28:25 --> Helper loaded: common_helper
INFO - 2018-11-21 08:28:25 --> Database Driver Class Initialized
DEBUG - 2018-11-21 08:28:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-21 08:28:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-21 08:28:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-21 08:28:25 --> Pagination Class Initialized
INFO - 2018-11-21 08:28:25 --> Helper loaded: form_helper
INFO - 2018-11-21 08:28:25 --> Form Validation Class Initialized
INFO - 2018-11-21 08:28:25 --> Model Class Initialized
INFO - 2018-11-21 08:28:25 --> Controller Class Initialized
INFO - 2018-11-21 08:28:25 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-21 08:28:25 --> Model Class Initialized
INFO - 2018-11-21 08:28:25 --> Model Class Initialized
INFO - 2018-11-21 08:28:25 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-21 08:28:25 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/change-password.php
INFO - 2018-11-21 08:28:25 --> Final output sent to browser
DEBUG - 2018-11-21 08:28:25 --> Total execution time: 0.0600
INFO - 2018-11-21 08:29:33 --> Config Class Initialized
INFO - 2018-11-21 08:29:33 --> Hooks Class Initialized
DEBUG - 2018-11-21 08:29:33 --> UTF-8 Support Enabled
INFO - 2018-11-21 08:29:33 --> Utf8 Class Initialized
INFO - 2018-11-21 08:29:33 --> URI Class Initialized
INFO - 2018-11-21 08:29:33 --> Router Class Initialized
INFO - 2018-11-21 08:29:33 --> Output Class Initialized
INFO - 2018-11-21 08:29:33 --> Security Class Initialized
DEBUG - 2018-11-21 08:29:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-21 08:29:33 --> Input Class Initialized
INFO - 2018-11-21 08:29:33 --> Language Class Initialized
INFO - 2018-11-21 08:29:33 --> Loader Class Initialized
INFO - 2018-11-21 08:29:33 --> Helper loaded: url_helper
INFO - 2018-11-21 08:29:33 --> Helper loaded: file_helper
INFO - 2018-11-21 08:29:33 --> Helper loaded: email_helper
INFO - 2018-11-21 08:29:33 --> Helper loaded: common_helper
INFO - 2018-11-21 08:29:33 --> Database Driver Class Initialized
DEBUG - 2018-11-21 08:29:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-21 08:29:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-21 08:29:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-21 08:29:33 --> Pagination Class Initialized
INFO - 2018-11-21 08:29:33 --> Helper loaded: form_helper
INFO - 2018-11-21 08:29:33 --> Form Validation Class Initialized
INFO - 2018-11-21 08:29:33 --> Model Class Initialized
INFO - 2018-11-21 08:29:33 --> Controller Class Initialized
INFO - 2018-11-21 08:29:33 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-21 08:29:33 --> Model Class Initialized
INFO - 2018-11-21 08:29:33 --> Model Class Initialized
INFO - 2018-11-21 08:29:33 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-21 08:29:33 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/change-password.php
INFO - 2018-11-21 08:29:33 --> Final output sent to browser
DEBUG - 2018-11-21 08:29:33 --> Total execution time: 0.0500
INFO - 2018-11-21 08:29:47 --> Config Class Initialized
INFO - 2018-11-21 08:29:47 --> Hooks Class Initialized
DEBUG - 2018-11-21 08:29:47 --> UTF-8 Support Enabled
INFO - 2018-11-21 08:29:47 --> Utf8 Class Initialized
INFO - 2018-11-21 08:29:47 --> URI Class Initialized
INFO - 2018-11-21 08:29:47 --> Router Class Initialized
INFO - 2018-11-21 08:29:47 --> Output Class Initialized
INFO - 2018-11-21 08:29:47 --> Security Class Initialized
DEBUG - 2018-11-21 08:29:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-21 08:29:47 --> Input Class Initialized
INFO - 2018-11-21 08:29:47 --> Language Class Initialized
INFO - 2018-11-21 08:29:47 --> Loader Class Initialized
INFO - 2018-11-21 08:29:47 --> Helper loaded: url_helper
INFO - 2018-11-21 08:29:47 --> Helper loaded: file_helper
INFO - 2018-11-21 08:29:47 --> Helper loaded: email_helper
INFO - 2018-11-21 08:29:47 --> Helper loaded: common_helper
INFO - 2018-11-21 08:29:47 --> Database Driver Class Initialized
DEBUG - 2018-11-21 08:29:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-21 08:29:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-21 08:29:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-21 08:29:47 --> Pagination Class Initialized
INFO - 2018-11-21 08:29:47 --> Helper loaded: form_helper
INFO - 2018-11-21 08:29:47 --> Form Validation Class Initialized
INFO - 2018-11-21 08:29:47 --> Model Class Initialized
INFO - 2018-11-21 08:29:47 --> Controller Class Initialized
INFO - 2018-11-21 08:29:47 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-21 08:29:47 --> Model Class Initialized
INFO - 2018-11-21 08:29:47 --> Model Class Initialized
INFO - 2018-11-21 08:29:47 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-21 08:29:47 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/change-password.php
INFO - 2018-11-21 08:29:47 --> Final output sent to browser
DEBUG - 2018-11-21 08:29:47 --> Total execution time: 0.0540
INFO - 2018-11-21 08:30:00 --> Config Class Initialized
INFO - 2018-11-21 08:30:00 --> Hooks Class Initialized
DEBUG - 2018-11-21 08:30:00 --> UTF-8 Support Enabled
INFO - 2018-11-21 08:30:00 --> Utf8 Class Initialized
INFO - 2018-11-21 08:30:00 --> URI Class Initialized
INFO - 2018-11-21 08:30:00 --> Router Class Initialized
INFO - 2018-11-21 08:30:00 --> Output Class Initialized
INFO - 2018-11-21 08:30:00 --> Security Class Initialized
DEBUG - 2018-11-21 08:30:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-21 08:30:00 --> Input Class Initialized
INFO - 2018-11-21 08:30:00 --> Language Class Initialized
INFO - 2018-11-21 08:30:00 --> Loader Class Initialized
INFO - 2018-11-21 08:30:00 --> Helper loaded: url_helper
INFO - 2018-11-21 08:30:00 --> Helper loaded: file_helper
INFO - 2018-11-21 08:30:00 --> Helper loaded: email_helper
INFO - 2018-11-21 08:30:00 --> Helper loaded: common_helper
INFO - 2018-11-21 08:30:00 --> Database Driver Class Initialized
DEBUG - 2018-11-21 08:30:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-21 08:30:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-21 08:30:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-21 08:30:00 --> Pagination Class Initialized
INFO - 2018-11-21 08:30:00 --> Helper loaded: form_helper
INFO - 2018-11-21 08:30:00 --> Form Validation Class Initialized
INFO - 2018-11-21 08:30:00 --> Model Class Initialized
INFO - 2018-11-21 08:30:00 --> Controller Class Initialized
INFO - 2018-11-21 08:30:00 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-21 08:30:00 --> Model Class Initialized
INFO - 2018-11-21 08:30:00 --> Model Class Initialized
INFO - 2018-11-21 08:30:00 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-21 08:30:00 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/change-password.php
INFO - 2018-11-21 08:30:00 --> Final output sent to browser
DEBUG - 2018-11-21 08:30:00 --> Total execution time: 0.0696
INFO - 2018-11-21 08:30:28 --> Config Class Initialized
INFO - 2018-11-21 08:30:28 --> Hooks Class Initialized
DEBUG - 2018-11-21 08:30:28 --> UTF-8 Support Enabled
INFO - 2018-11-21 08:30:28 --> Utf8 Class Initialized
INFO - 2018-11-21 08:30:28 --> URI Class Initialized
INFO - 2018-11-21 08:30:28 --> Router Class Initialized
INFO - 2018-11-21 08:30:28 --> Output Class Initialized
INFO - 2018-11-21 08:30:28 --> Security Class Initialized
DEBUG - 2018-11-21 08:30:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-21 08:30:28 --> Input Class Initialized
INFO - 2018-11-21 08:30:28 --> Language Class Initialized
INFO - 2018-11-21 08:30:28 --> Loader Class Initialized
INFO - 2018-11-21 08:30:28 --> Helper loaded: url_helper
INFO - 2018-11-21 08:30:28 --> Helper loaded: file_helper
INFO - 2018-11-21 08:30:28 --> Helper loaded: email_helper
INFO - 2018-11-21 08:30:28 --> Helper loaded: common_helper
INFO - 2018-11-21 08:30:28 --> Database Driver Class Initialized
DEBUG - 2018-11-21 08:30:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-21 08:30:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-21 08:30:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-21 08:30:28 --> Pagination Class Initialized
INFO - 2018-11-21 08:30:28 --> Helper loaded: form_helper
INFO - 2018-11-21 08:30:28 --> Form Validation Class Initialized
INFO - 2018-11-21 08:30:28 --> Model Class Initialized
INFO - 2018-11-21 08:30:28 --> Controller Class Initialized
INFO - 2018-11-21 08:30:28 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-21 08:30:28 --> Model Class Initialized
INFO - 2018-11-21 08:30:28 --> Model Class Initialized
INFO - 2018-11-21 08:30:28 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-21 08:30:28 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/change-password.php
INFO - 2018-11-21 08:30:28 --> Final output sent to browser
DEBUG - 2018-11-21 08:30:28 --> Total execution time: 0.0560
INFO - 2018-11-21 08:31:18 --> Config Class Initialized
INFO - 2018-11-21 08:31:18 --> Hooks Class Initialized
DEBUG - 2018-11-21 08:31:18 --> UTF-8 Support Enabled
INFO - 2018-11-21 08:31:18 --> Utf8 Class Initialized
INFO - 2018-11-21 08:31:18 --> URI Class Initialized
INFO - 2018-11-21 08:31:18 --> Router Class Initialized
INFO - 2018-11-21 08:31:18 --> Output Class Initialized
INFO - 2018-11-21 08:31:18 --> Security Class Initialized
DEBUG - 2018-11-21 08:31:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-21 08:31:18 --> Input Class Initialized
INFO - 2018-11-21 08:31:18 --> Language Class Initialized
INFO - 2018-11-21 08:31:18 --> Loader Class Initialized
INFO - 2018-11-21 08:31:18 --> Helper loaded: url_helper
INFO - 2018-11-21 08:31:18 --> Helper loaded: file_helper
INFO - 2018-11-21 08:31:18 --> Helper loaded: email_helper
INFO - 2018-11-21 08:31:18 --> Helper loaded: common_helper
INFO - 2018-11-21 08:31:18 --> Database Driver Class Initialized
DEBUG - 2018-11-21 08:31:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-21 08:31:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-21 08:31:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-21 08:31:18 --> Pagination Class Initialized
INFO - 2018-11-21 08:31:18 --> Helper loaded: form_helper
INFO - 2018-11-21 08:31:18 --> Form Validation Class Initialized
INFO - 2018-11-21 08:31:18 --> Model Class Initialized
INFO - 2018-11-21 08:31:18 --> Controller Class Initialized
INFO - 2018-11-21 08:31:18 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-21 08:31:18 --> Model Class Initialized
INFO - 2018-11-21 08:31:18 --> Model Class Initialized
INFO - 2018-11-21 08:31:18 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-21 08:31:18 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/change-password.php
INFO - 2018-11-21 08:31:18 --> Final output sent to browser
DEBUG - 2018-11-21 08:31:18 --> Total execution time: 0.0590
INFO - 2018-11-21 08:31:31 --> Config Class Initialized
INFO - 2018-11-21 08:31:31 --> Hooks Class Initialized
DEBUG - 2018-11-21 08:31:31 --> UTF-8 Support Enabled
INFO - 2018-11-21 08:31:31 --> Utf8 Class Initialized
INFO - 2018-11-21 08:31:31 --> URI Class Initialized
INFO - 2018-11-21 08:31:31 --> Router Class Initialized
INFO - 2018-11-21 08:31:31 --> Output Class Initialized
INFO - 2018-11-21 08:31:31 --> Security Class Initialized
DEBUG - 2018-11-21 08:31:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-21 08:31:31 --> Input Class Initialized
INFO - 2018-11-21 08:31:31 --> Language Class Initialized
INFO - 2018-11-21 08:31:31 --> Loader Class Initialized
INFO - 2018-11-21 08:31:31 --> Helper loaded: url_helper
INFO - 2018-11-21 08:31:31 --> Helper loaded: file_helper
INFO - 2018-11-21 08:31:31 --> Helper loaded: email_helper
INFO - 2018-11-21 08:31:31 --> Helper loaded: common_helper
INFO - 2018-11-21 08:31:31 --> Database Driver Class Initialized
DEBUG - 2018-11-21 08:31:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-21 08:31:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-21 08:31:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-21 08:31:31 --> Pagination Class Initialized
INFO - 2018-11-21 08:31:31 --> Helper loaded: form_helper
INFO - 2018-11-21 08:31:31 --> Form Validation Class Initialized
INFO - 2018-11-21 08:31:31 --> Model Class Initialized
INFO - 2018-11-21 08:31:31 --> Controller Class Initialized
INFO - 2018-11-21 08:31:31 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-21 08:31:31 --> Model Class Initialized
INFO - 2018-11-21 08:31:31 --> Model Class Initialized
INFO - 2018-11-21 08:31:31 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-21 08:31:31 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/change-password.php
INFO - 2018-11-21 08:31:31 --> Final output sent to browser
DEBUG - 2018-11-21 08:31:31 --> Total execution time: 0.0520
INFO - 2018-11-21 08:31:31 --> Config Class Initialized
INFO - 2018-11-21 08:31:31 --> Hooks Class Initialized
DEBUG - 2018-11-21 08:31:31 --> UTF-8 Support Enabled
INFO - 2018-11-21 08:31:31 --> Utf8 Class Initialized
INFO - 2018-11-21 08:31:31 --> URI Class Initialized
INFO - 2018-11-21 08:31:31 --> Router Class Initialized
INFO - 2018-11-21 08:31:31 --> Output Class Initialized
INFO - 2018-11-21 08:31:31 --> Security Class Initialized
DEBUG - 2018-11-21 08:31:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-21 08:31:31 --> Input Class Initialized
INFO - 2018-11-21 08:31:31 --> Language Class Initialized
INFO - 2018-11-21 08:31:31 --> Loader Class Initialized
INFO - 2018-11-21 08:31:31 --> Helper loaded: url_helper
INFO - 2018-11-21 08:31:31 --> Helper loaded: file_helper
INFO - 2018-11-21 08:31:31 --> Helper loaded: email_helper
INFO - 2018-11-21 08:31:31 --> Helper loaded: common_helper
INFO - 2018-11-21 08:31:31 --> Database Driver Class Initialized
DEBUG - 2018-11-21 08:31:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-21 08:31:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-21 08:31:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-21 08:31:31 --> Pagination Class Initialized
INFO - 2018-11-21 08:31:31 --> Helper loaded: form_helper
INFO - 2018-11-21 08:31:31 --> Form Validation Class Initialized
INFO - 2018-11-21 08:31:31 --> Model Class Initialized
INFO - 2018-11-21 08:31:31 --> Controller Class Initialized
INFO - 2018-11-21 08:31:31 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-21 08:31:31 --> Model Class Initialized
INFO - 2018-11-21 08:31:31 --> Model Class Initialized
INFO - 2018-11-21 08:31:31 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-21 08:31:31 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/change-password.php
INFO - 2018-11-21 08:31:31 --> Final output sent to browser
DEBUG - 2018-11-21 08:31:31 --> Total execution time: 0.0540
INFO - 2018-11-21 08:31:31 --> Config Class Initialized
INFO - 2018-11-21 08:31:31 --> Hooks Class Initialized
DEBUG - 2018-11-21 08:31:31 --> UTF-8 Support Enabled
INFO - 2018-11-21 08:31:31 --> Utf8 Class Initialized
INFO - 2018-11-21 08:31:31 --> URI Class Initialized
INFO - 2018-11-21 08:31:31 --> Router Class Initialized
INFO - 2018-11-21 08:31:31 --> Output Class Initialized
INFO - 2018-11-21 08:31:31 --> Security Class Initialized
DEBUG - 2018-11-21 08:31:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-21 08:31:31 --> Input Class Initialized
INFO - 2018-11-21 08:31:31 --> Language Class Initialized
INFO - 2018-11-21 08:31:31 --> Loader Class Initialized
INFO - 2018-11-21 08:31:31 --> Helper loaded: url_helper
INFO - 2018-11-21 08:31:31 --> Helper loaded: file_helper
INFO - 2018-11-21 08:31:31 --> Helper loaded: email_helper
INFO - 2018-11-21 08:31:31 --> Helper loaded: common_helper
INFO - 2018-11-21 08:31:31 --> Database Driver Class Initialized
DEBUG - 2018-11-21 08:31:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-21 08:31:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-21 08:31:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-21 08:31:31 --> Pagination Class Initialized
INFO - 2018-11-21 08:31:31 --> Helper loaded: form_helper
INFO - 2018-11-21 08:31:31 --> Form Validation Class Initialized
INFO - 2018-11-21 08:31:31 --> Model Class Initialized
INFO - 2018-11-21 08:31:31 --> Controller Class Initialized
INFO - 2018-11-21 08:31:31 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-21 08:31:31 --> Model Class Initialized
INFO - 2018-11-21 08:31:31 --> Model Class Initialized
INFO - 2018-11-21 08:31:31 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-21 08:31:31 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/change-password.php
INFO - 2018-11-21 08:31:32 --> Final output sent to browser
DEBUG - 2018-11-21 08:31:32 --> Total execution time: 0.0510
INFO - 2018-11-21 08:31:32 --> Config Class Initialized
INFO - 2018-11-21 08:31:32 --> Hooks Class Initialized
DEBUG - 2018-11-21 08:31:32 --> UTF-8 Support Enabled
INFO - 2018-11-21 08:31:32 --> Utf8 Class Initialized
INFO - 2018-11-21 08:31:32 --> URI Class Initialized
INFO - 2018-11-21 08:31:32 --> Router Class Initialized
INFO - 2018-11-21 08:31:32 --> Output Class Initialized
INFO - 2018-11-21 08:31:32 --> Security Class Initialized
DEBUG - 2018-11-21 08:31:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-21 08:31:32 --> Input Class Initialized
INFO - 2018-11-21 08:31:32 --> Language Class Initialized
INFO - 2018-11-21 08:31:32 --> Loader Class Initialized
INFO - 2018-11-21 08:31:32 --> Helper loaded: url_helper
INFO - 2018-11-21 08:31:32 --> Helper loaded: file_helper
INFO - 2018-11-21 08:31:32 --> Helper loaded: email_helper
INFO - 2018-11-21 08:31:32 --> Helper loaded: common_helper
INFO - 2018-11-21 08:31:32 --> Database Driver Class Initialized
DEBUG - 2018-11-21 08:31:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-21 08:31:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-21 08:31:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-21 08:31:32 --> Pagination Class Initialized
INFO - 2018-11-21 08:31:32 --> Helper loaded: form_helper
INFO - 2018-11-21 08:31:32 --> Form Validation Class Initialized
INFO - 2018-11-21 08:31:32 --> Model Class Initialized
INFO - 2018-11-21 08:31:32 --> Controller Class Initialized
INFO - 2018-11-21 08:31:32 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-21 08:31:32 --> Model Class Initialized
INFO - 2018-11-21 08:31:32 --> Model Class Initialized
INFO - 2018-11-21 08:31:32 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-21 08:31:32 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/change-password.php
INFO - 2018-11-21 08:31:32 --> Final output sent to browser
DEBUG - 2018-11-21 08:31:32 --> Total execution time: 0.1310
INFO - 2018-11-21 08:32:20 --> Config Class Initialized
INFO - 2018-11-21 08:32:20 --> Hooks Class Initialized
DEBUG - 2018-11-21 08:32:20 --> UTF-8 Support Enabled
INFO - 2018-11-21 08:32:20 --> Utf8 Class Initialized
INFO - 2018-11-21 08:32:20 --> URI Class Initialized
INFO - 2018-11-21 08:32:20 --> Router Class Initialized
INFO - 2018-11-21 08:32:20 --> Output Class Initialized
INFO - 2018-11-21 08:32:20 --> Security Class Initialized
DEBUG - 2018-11-21 08:32:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-21 08:32:20 --> Input Class Initialized
INFO - 2018-11-21 08:32:20 --> Language Class Initialized
INFO - 2018-11-21 08:32:20 --> Loader Class Initialized
INFO - 2018-11-21 08:32:20 --> Helper loaded: url_helper
INFO - 2018-11-21 08:32:20 --> Helper loaded: file_helper
INFO - 2018-11-21 08:32:20 --> Helper loaded: email_helper
INFO - 2018-11-21 08:32:20 --> Helper loaded: common_helper
INFO - 2018-11-21 08:32:20 --> Database Driver Class Initialized
DEBUG - 2018-11-21 08:32:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-21 08:32:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-21 08:32:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-21 08:32:20 --> Pagination Class Initialized
INFO - 2018-11-21 08:32:20 --> Helper loaded: form_helper
INFO - 2018-11-21 08:32:20 --> Form Validation Class Initialized
INFO - 2018-11-21 08:32:20 --> Model Class Initialized
INFO - 2018-11-21 08:32:20 --> Controller Class Initialized
INFO - 2018-11-21 08:32:20 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-21 08:32:20 --> Model Class Initialized
INFO - 2018-11-21 08:32:20 --> Model Class Initialized
INFO - 2018-11-21 08:32:20 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-21 08:32:20 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/change-password.php
INFO - 2018-11-21 08:32:20 --> Final output sent to browser
DEBUG - 2018-11-21 08:32:20 --> Total execution time: 0.0556
INFO - 2018-11-21 08:33:06 --> Config Class Initialized
INFO - 2018-11-21 08:33:06 --> Hooks Class Initialized
DEBUG - 2018-11-21 08:33:06 --> UTF-8 Support Enabled
INFO - 2018-11-21 08:33:06 --> Utf8 Class Initialized
INFO - 2018-11-21 08:33:06 --> URI Class Initialized
INFO - 2018-11-21 08:33:06 --> Router Class Initialized
INFO - 2018-11-21 08:33:06 --> Output Class Initialized
INFO - 2018-11-21 08:33:06 --> Security Class Initialized
DEBUG - 2018-11-21 08:33:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-21 08:33:06 --> Input Class Initialized
INFO - 2018-11-21 08:33:06 --> Language Class Initialized
INFO - 2018-11-21 08:33:06 --> Loader Class Initialized
INFO - 2018-11-21 08:33:06 --> Helper loaded: url_helper
INFO - 2018-11-21 08:33:06 --> Helper loaded: file_helper
INFO - 2018-11-21 08:33:06 --> Helper loaded: email_helper
INFO - 2018-11-21 08:33:06 --> Helper loaded: common_helper
INFO - 2018-11-21 08:33:06 --> Database Driver Class Initialized
DEBUG - 2018-11-21 08:33:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-21 08:33:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-21 08:33:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-21 08:33:06 --> Pagination Class Initialized
INFO - 2018-11-21 08:33:06 --> Helper loaded: form_helper
INFO - 2018-11-21 08:33:06 --> Form Validation Class Initialized
INFO - 2018-11-21 08:33:06 --> Model Class Initialized
INFO - 2018-11-21 08:33:06 --> Controller Class Initialized
INFO - 2018-11-21 08:33:06 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-21 08:33:06 --> Model Class Initialized
INFO - 2018-11-21 08:33:06 --> Model Class Initialized
INFO - 2018-11-21 08:33:06 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-21 08:33:06 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/change-password.php
INFO - 2018-11-21 08:33:06 --> Final output sent to browser
DEBUG - 2018-11-21 08:33:06 --> Total execution time: 0.0550
INFO - 2018-11-21 08:34:30 --> Config Class Initialized
INFO - 2018-11-21 08:34:30 --> Hooks Class Initialized
DEBUG - 2018-11-21 08:34:30 --> UTF-8 Support Enabled
INFO - 2018-11-21 08:34:30 --> Utf8 Class Initialized
INFO - 2018-11-21 08:34:30 --> URI Class Initialized
INFO - 2018-11-21 08:34:30 --> Router Class Initialized
INFO - 2018-11-21 08:34:30 --> Output Class Initialized
INFO - 2018-11-21 08:34:30 --> Security Class Initialized
DEBUG - 2018-11-21 08:34:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-21 08:34:30 --> Input Class Initialized
INFO - 2018-11-21 08:34:30 --> Language Class Initialized
INFO - 2018-11-21 08:34:30 --> Loader Class Initialized
INFO - 2018-11-21 08:34:30 --> Helper loaded: url_helper
INFO - 2018-11-21 08:34:30 --> Helper loaded: file_helper
INFO - 2018-11-21 08:34:30 --> Helper loaded: email_helper
INFO - 2018-11-21 08:34:30 --> Helper loaded: common_helper
INFO - 2018-11-21 08:34:30 --> Database Driver Class Initialized
DEBUG - 2018-11-21 08:34:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-21 08:34:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-21 08:34:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-21 08:34:30 --> Pagination Class Initialized
INFO - 2018-11-21 08:34:30 --> Helper loaded: form_helper
INFO - 2018-11-21 08:34:30 --> Form Validation Class Initialized
INFO - 2018-11-21 08:34:30 --> Model Class Initialized
INFO - 2018-11-21 08:34:30 --> Controller Class Initialized
INFO - 2018-11-21 08:34:30 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-21 08:34:30 --> Model Class Initialized
INFO - 2018-11-21 08:34:30 --> Model Class Initialized
INFO - 2018-11-21 08:34:30 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-21 08:34:30 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/change-password.php
INFO - 2018-11-21 08:34:30 --> Final output sent to browser
DEBUG - 2018-11-21 08:34:30 --> Total execution time: 0.0540
INFO - 2018-11-21 08:34:38 --> Config Class Initialized
INFO - 2018-11-21 08:34:38 --> Hooks Class Initialized
DEBUG - 2018-11-21 08:34:38 --> UTF-8 Support Enabled
INFO - 2018-11-21 08:34:38 --> Utf8 Class Initialized
INFO - 2018-11-21 08:34:38 --> URI Class Initialized
INFO - 2018-11-21 08:34:38 --> Router Class Initialized
INFO - 2018-11-21 08:34:38 --> Output Class Initialized
INFO - 2018-11-21 08:34:38 --> Security Class Initialized
DEBUG - 2018-11-21 08:34:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-21 08:34:38 --> Input Class Initialized
INFO - 2018-11-21 08:34:38 --> Language Class Initialized
INFO - 2018-11-21 08:34:38 --> Loader Class Initialized
INFO - 2018-11-21 08:34:38 --> Helper loaded: url_helper
INFO - 2018-11-21 08:34:38 --> Helper loaded: file_helper
INFO - 2018-11-21 08:34:38 --> Helper loaded: email_helper
INFO - 2018-11-21 08:34:38 --> Helper loaded: common_helper
INFO - 2018-11-21 08:34:38 --> Database Driver Class Initialized
DEBUG - 2018-11-21 08:34:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-21 08:34:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-21 08:34:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-21 08:34:38 --> Pagination Class Initialized
INFO - 2018-11-21 08:34:38 --> Helper loaded: form_helper
INFO - 2018-11-21 08:34:38 --> Form Validation Class Initialized
INFO - 2018-11-21 08:34:38 --> Model Class Initialized
INFO - 2018-11-21 08:34:38 --> Controller Class Initialized
INFO - 2018-11-21 08:34:38 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-21 08:34:38 --> Model Class Initialized
INFO - 2018-11-21 08:34:38 --> Model Class Initialized
INFO - 2018-11-21 08:34:38 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-21 08:34:38 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/change-password.php
INFO - 2018-11-21 08:34:38 --> Final output sent to browser
DEBUG - 2018-11-21 08:34:38 --> Total execution time: 0.0470
INFO - 2018-11-21 08:42:49 --> Config Class Initialized
INFO - 2018-11-21 08:42:49 --> Hooks Class Initialized
DEBUG - 2018-11-21 08:42:49 --> UTF-8 Support Enabled
INFO - 2018-11-21 08:42:49 --> Utf8 Class Initialized
INFO - 2018-11-21 08:42:49 --> URI Class Initialized
INFO - 2018-11-21 08:42:49 --> Router Class Initialized
INFO - 2018-11-21 08:42:49 --> Output Class Initialized
INFO - 2018-11-21 08:42:49 --> Security Class Initialized
DEBUG - 2018-11-21 08:42:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-21 08:42:49 --> Input Class Initialized
INFO - 2018-11-21 08:42:49 --> Language Class Initialized
INFO - 2018-11-21 08:42:49 --> Loader Class Initialized
INFO - 2018-11-21 08:42:49 --> Helper loaded: url_helper
INFO - 2018-11-21 08:42:49 --> Helper loaded: file_helper
INFO - 2018-11-21 08:42:49 --> Helper loaded: email_helper
INFO - 2018-11-21 08:42:49 --> Helper loaded: common_helper
INFO - 2018-11-21 08:42:49 --> Database Driver Class Initialized
DEBUG - 2018-11-21 08:42:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-21 08:42:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-21 08:42:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-21 08:42:49 --> Pagination Class Initialized
INFO - 2018-11-21 08:42:49 --> Helper loaded: form_helper
INFO - 2018-11-21 08:42:49 --> Form Validation Class Initialized
INFO - 2018-11-21 08:42:49 --> Model Class Initialized
INFO - 2018-11-21 08:42:49 --> Controller Class Initialized
INFO - 2018-11-21 08:42:49 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-21 08:42:49 --> Model Class Initialized
INFO - 2018-11-21 08:42:49 --> Model Class Initialized
INFO - 2018-11-21 08:42:49 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-21 08:42:49 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/change-password.php
INFO - 2018-11-21 08:42:49 --> Final output sent to browser
DEBUG - 2018-11-21 08:42:49 --> Total execution time: 0.0630
INFO - 2018-11-21 08:47:01 --> Config Class Initialized
INFO - 2018-11-21 08:47:01 --> Hooks Class Initialized
DEBUG - 2018-11-21 08:47:01 --> UTF-8 Support Enabled
INFO - 2018-11-21 08:47:01 --> Utf8 Class Initialized
INFO - 2018-11-21 08:47:01 --> URI Class Initialized
INFO - 2018-11-21 08:47:01 --> Router Class Initialized
INFO - 2018-11-21 08:47:01 --> Output Class Initialized
INFO - 2018-11-21 08:47:01 --> Security Class Initialized
DEBUG - 2018-11-21 08:47:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-21 08:47:01 --> Input Class Initialized
INFO - 2018-11-21 08:47:01 --> Language Class Initialized
INFO - 2018-11-21 08:47:01 --> Loader Class Initialized
INFO - 2018-11-21 08:47:01 --> Helper loaded: url_helper
INFO - 2018-11-21 08:47:01 --> Helper loaded: file_helper
INFO - 2018-11-21 08:47:01 --> Helper loaded: email_helper
INFO - 2018-11-21 08:47:01 --> Helper loaded: common_helper
INFO - 2018-11-21 08:47:01 --> Database Driver Class Initialized
DEBUG - 2018-11-21 08:47:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-21 08:47:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-21 08:47:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-21 08:47:01 --> Pagination Class Initialized
INFO - 2018-11-21 08:47:01 --> Helper loaded: form_helper
INFO - 2018-11-21 08:47:01 --> Form Validation Class Initialized
INFO - 2018-11-21 08:47:01 --> Model Class Initialized
INFO - 2018-11-21 08:47:01 --> Controller Class Initialized
INFO - 2018-11-21 08:47:01 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-21 08:47:01 --> Model Class Initialized
INFO - 2018-11-21 08:47:01 --> Model Class Initialized
INFO - 2018-11-21 08:47:01 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-21 08:47:01 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/change-password.php
INFO - 2018-11-21 08:47:01 --> Final output sent to browser
DEBUG - 2018-11-21 08:47:01 --> Total execution time: 0.0660
INFO - 2018-11-21 08:47:30 --> Config Class Initialized
INFO - 2018-11-21 08:47:30 --> Hooks Class Initialized
DEBUG - 2018-11-21 08:47:30 --> UTF-8 Support Enabled
INFO - 2018-11-21 08:47:30 --> Utf8 Class Initialized
INFO - 2018-11-21 08:47:30 --> URI Class Initialized
INFO - 2018-11-21 08:47:30 --> Router Class Initialized
INFO - 2018-11-21 08:47:30 --> Output Class Initialized
INFO - 2018-11-21 08:47:30 --> Security Class Initialized
DEBUG - 2018-11-21 08:47:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-21 08:47:30 --> Input Class Initialized
INFO - 2018-11-21 08:47:30 --> Language Class Initialized
INFO - 2018-11-21 08:47:30 --> Loader Class Initialized
INFO - 2018-11-21 08:47:30 --> Helper loaded: url_helper
INFO - 2018-11-21 08:47:30 --> Helper loaded: file_helper
INFO - 2018-11-21 08:47:30 --> Helper loaded: email_helper
INFO - 2018-11-21 08:47:30 --> Helper loaded: common_helper
INFO - 2018-11-21 08:47:30 --> Database Driver Class Initialized
DEBUG - 2018-11-21 08:47:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-21 08:47:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-21 08:47:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-21 08:47:30 --> Pagination Class Initialized
INFO - 2018-11-21 08:47:30 --> Helper loaded: form_helper
INFO - 2018-11-21 08:47:30 --> Form Validation Class Initialized
INFO - 2018-11-21 08:47:30 --> Model Class Initialized
INFO - 2018-11-21 08:47:30 --> Controller Class Initialized
INFO - 2018-11-21 08:47:30 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-21 08:47:30 --> Model Class Initialized
INFO - 2018-11-21 08:47:30 --> Model Class Initialized
INFO - 2018-11-21 08:47:30 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-21 08:47:30 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/change-password.php
INFO - 2018-11-21 08:47:30 --> Final output sent to browser
DEBUG - 2018-11-21 08:47:30 --> Total execution time: 0.0650
INFO - 2018-11-21 08:48:26 --> Config Class Initialized
INFO - 2018-11-21 08:48:26 --> Hooks Class Initialized
DEBUG - 2018-11-21 08:48:26 --> UTF-8 Support Enabled
INFO - 2018-11-21 08:48:26 --> Utf8 Class Initialized
INFO - 2018-11-21 08:48:26 --> URI Class Initialized
INFO - 2018-11-21 08:48:26 --> Router Class Initialized
INFO - 2018-11-21 08:48:26 --> Output Class Initialized
INFO - 2018-11-21 08:48:26 --> Security Class Initialized
DEBUG - 2018-11-21 08:48:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-21 08:48:26 --> Input Class Initialized
INFO - 2018-11-21 08:48:26 --> Language Class Initialized
INFO - 2018-11-21 08:48:26 --> Loader Class Initialized
INFO - 2018-11-21 08:48:26 --> Helper loaded: url_helper
INFO - 2018-11-21 08:48:26 --> Helper loaded: file_helper
INFO - 2018-11-21 08:48:26 --> Helper loaded: email_helper
INFO - 2018-11-21 08:48:26 --> Helper loaded: common_helper
INFO - 2018-11-21 08:48:26 --> Database Driver Class Initialized
DEBUG - 2018-11-21 08:48:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-21 08:48:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-21 08:48:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-21 08:48:26 --> Pagination Class Initialized
INFO - 2018-11-21 08:48:26 --> Helper loaded: form_helper
INFO - 2018-11-21 08:48:26 --> Form Validation Class Initialized
INFO - 2018-11-21 08:48:26 --> Model Class Initialized
INFO - 2018-11-21 08:48:26 --> Controller Class Initialized
INFO - 2018-11-21 08:48:26 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-21 08:48:26 --> Model Class Initialized
INFO - 2018-11-21 08:48:26 --> Model Class Initialized
INFO - 2018-11-21 08:48:26 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-21 08:48:26 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/change-password.php
INFO - 2018-11-21 08:48:26 --> Final output sent to browser
DEBUG - 2018-11-21 08:48:26 --> Total execution time: 0.0640
INFO - 2018-11-21 08:52:49 --> Config Class Initialized
INFO - 2018-11-21 08:52:49 --> Hooks Class Initialized
DEBUG - 2018-11-21 08:52:49 --> UTF-8 Support Enabled
INFO - 2018-11-21 08:52:49 --> Utf8 Class Initialized
INFO - 2018-11-21 08:52:49 --> URI Class Initialized
INFO - 2018-11-21 08:52:49 --> Router Class Initialized
INFO - 2018-11-21 08:52:49 --> Output Class Initialized
INFO - 2018-11-21 08:52:49 --> Security Class Initialized
DEBUG - 2018-11-21 08:52:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-21 08:52:49 --> Input Class Initialized
INFO - 2018-11-21 08:52:49 --> Language Class Initialized
INFO - 2018-11-21 08:52:49 --> Loader Class Initialized
INFO - 2018-11-21 08:52:49 --> Helper loaded: url_helper
INFO - 2018-11-21 08:52:49 --> Helper loaded: file_helper
INFO - 2018-11-21 08:52:49 --> Helper loaded: email_helper
INFO - 2018-11-21 08:52:49 --> Helper loaded: common_helper
INFO - 2018-11-21 08:52:49 --> Database Driver Class Initialized
DEBUG - 2018-11-21 08:52:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-21 08:52:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-21 08:52:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-21 08:52:49 --> Pagination Class Initialized
INFO - 2018-11-21 08:52:49 --> Helper loaded: form_helper
INFO - 2018-11-21 08:52:49 --> Form Validation Class Initialized
INFO - 2018-11-21 08:52:49 --> Model Class Initialized
INFO - 2018-11-21 08:52:49 --> Controller Class Initialized
INFO - 2018-11-21 08:52:49 --> Language file loaded: language/english/english_lang.php
INFO - 2018-11-21 08:52:49 --> Model Class Initialized
INFO - 2018-11-21 08:52:49 --> Model Class Initialized
INFO - 2018-11-21 08:52:49 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/ample/header.php
INFO - 2018-11-21 08:52:49 --> File loaded: C:\xampp\htdocs\wetinuneed\application\views\admin/change-password.php
INFO - 2018-11-21 08:52:49 --> Final output sent to browser
DEBUG - 2018-11-21 08:52:49 --> Total execution time: 0.0610

<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2018-02-07 10:38:11 --> Config Class Initialized
INFO - 2018-02-07 10:38:11 --> Hooks Class Initialized
DEBUG - 2018-02-07 10:38:11 --> UTF-8 Support Enabled
INFO - 2018-02-07 10:38:11 --> Utf8 Class Initialized
INFO - 2018-02-07 10:38:11 --> URI Class Initialized
INFO - 2018-02-07 10:38:11 --> Router Class Initialized
INFO - 2018-02-07 10:38:11 --> Output Class Initialized
INFO - 2018-02-07 10:38:11 --> Security Class Initialized
DEBUG - 2018-02-07 10:38:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 10:38:11 --> Input Class Initialized
INFO - 2018-02-07 10:38:11 --> Language Class Initialized
INFO - 2018-02-07 10:38:11 --> Loader Class Initialized
INFO - 2018-02-07 10:38:11 --> Helper loaded: url_helper
INFO - 2018-02-07 10:38:11 --> Helper loaded: file_helper
INFO - 2018-02-07 10:38:11 --> Helper loaded: email_helper
INFO - 2018-02-07 10:38:11 --> Helper loaded: common_helper
INFO - 2018-02-07 10:38:11 --> Database Driver Class Initialized
DEBUG - 2018-02-07 10:38:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 10:38:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 10:38:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-07 10:38:11 --> Pagination Class Initialized
INFO - 2018-02-07 10:38:11 --> Helper loaded: form_helper
INFO - 2018-02-07 10:38:11 --> Form Validation Class Initialized
INFO - 2018-02-07 10:38:11 --> Model Class Initialized
INFO - 2018-02-07 10:38:11 --> Controller Class Initialized
INFO - 2018-02-07 10:38:11 --> Model Class Initialized
INFO - 2018-02-07 10:38:11 --> File loaded: /var/www/html/spamblocker/application/views/index/resetPassword.php
INFO - 2018-02-07 10:38:11 --> Final output sent to browser
DEBUG - 2018-02-07 10:38:11 --> Total execution time: 0.0830
INFO - 2018-02-07 10:38:17 --> Config Class Initialized
INFO - 2018-02-07 10:38:17 --> Hooks Class Initialized
DEBUG - 2018-02-07 10:38:17 --> UTF-8 Support Enabled
INFO - 2018-02-07 10:38:17 --> Utf8 Class Initialized
INFO - 2018-02-07 10:38:17 --> URI Class Initialized
INFO - 2018-02-07 10:38:17 --> Router Class Initialized
INFO - 2018-02-07 10:38:17 --> Output Class Initialized
INFO - 2018-02-07 10:38:17 --> Security Class Initialized
DEBUG - 2018-02-07 10:38:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 10:38:17 --> Input Class Initialized
INFO - 2018-02-07 10:38:17 --> Language Class Initialized
INFO - 2018-02-07 10:38:17 --> Loader Class Initialized
INFO - 2018-02-07 10:38:17 --> Helper loaded: url_helper
INFO - 2018-02-07 10:38:17 --> Helper loaded: file_helper
INFO - 2018-02-07 10:38:17 --> Helper loaded: email_helper
INFO - 2018-02-07 10:38:17 --> Helper loaded: common_helper
INFO - 2018-02-07 10:38:17 --> Database Driver Class Initialized
DEBUG - 2018-02-07 10:38:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 10:38:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 10:38:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-07 10:38:17 --> Pagination Class Initialized
INFO - 2018-02-07 10:38:17 --> Helper loaded: form_helper
INFO - 2018-02-07 10:38:17 --> Form Validation Class Initialized
INFO - 2018-02-07 10:38:17 --> Model Class Initialized
INFO - 2018-02-07 10:38:17 --> Controller Class Initialized
INFO - 2018-02-07 10:38:17 --> Model Class Initialized
INFO - 2018-02-07 10:38:17 --> File loaded: /var/www/html/spamblocker/application/views/index/resetPassword.php
INFO - 2018-02-07 10:38:17 --> Final output sent to browser
DEBUG - 2018-02-07 10:38:17 --> Total execution time: 0.0056
INFO - 2018-02-07 10:38:35 --> Config Class Initialized
INFO - 2018-02-07 10:38:35 --> Hooks Class Initialized
DEBUG - 2018-02-07 10:38:35 --> UTF-8 Support Enabled
INFO - 2018-02-07 10:38:35 --> Utf8 Class Initialized
INFO - 2018-02-07 10:38:35 --> URI Class Initialized
INFO - 2018-02-07 10:38:35 --> Router Class Initialized
INFO - 2018-02-07 10:38:35 --> Output Class Initialized
INFO - 2018-02-07 10:38:35 --> Security Class Initialized
DEBUG - 2018-02-07 10:38:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 10:38:35 --> Input Class Initialized
INFO - 2018-02-07 10:38:35 --> Language Class Initialized
INFO - 2018-02-07 10:38:35 --> Loader Class Initialized
INFO - 2018-02-07 10:38:35 --> Helper loaded: url_helper
INFO - 2018-02-07 10:38:35 --> Helper loaded: file_helper
INFO - 2018-02-07 10:38:35 --> Helper loaded: email_helper
INFO - 2018-02-07 10:38:35 --> Helper loaded: common_helper
INFO - 2018-02-07 10:38:35 --> Database Driver Class Initialized
DEBUG - 2018-02-07 10:38:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 10:38:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 10:38:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-07 10:38:35 --> Pagination Class Initialized
INFO - 2018-02-07 10:38:35 --> Helper loaded: form_helper
INFO - 2018-02-07 10:38:35 --> Form Validation Class Initialized
INFO - 2018-02-07 10:38:35 --> Model Class Initialized
INFO - 2018-02-07 10:38:35 --> Controller Class Initialized
INFO - 2018-02-07 10:38:35 --> Model Class Initialized
INFO - 2018-02-07 10:38:35 --> File loaded: /var/www/html/spamblocker/application/views/index/resetPassword.php
INFO - 2018-02-07 10:38:35 --> Final output sent to browser
DEBUG - 2018-02-07 10:38:35 --> Total execution time: 0.0094
INFO - 2018-02-07 10:39:28 --> Config Class Initialized
INFO - 2018-02-07 10:39:28 --> Hooks Class Initialized
DEBUG - 2018-02-07 10:39:28 --> UTF-8 Support Enabled
INFO - 2018-02-07 10:39:28 --> Utf8 Class Initialized
INFO - 2018-02-07 10:39:28 --> URI Class Initialized
INFO - 2018-02-07 10:39:28 --> Router Class Initialized
INFO - 2018-02-07 10:39:28 --> Output Class Initialized
INFO - 2018-02-07 10:39:28 --> Security Class Initialized
DEBUG - 2018-02-07 10:39:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 10:39:28 --> Input Class Initialized
INFO - 2018-02-07 10:39:28 --> Language Class Initialized
INFO - 2018-02-07 10:39:28 --> Loader Class Initialized
INFO - 2018-02-07 10:39:28 --> Helper loaded: url_helper
INFO - 2018-02-07 10:39:28 --> Helper loaded: file_helper
INFO - 2018-02-07 10:39:28 --> Helper loaded: email_helper
INFO - 2018-02-07 10:39:28 --> Helper loaded: common_helper
INFO - 2018-02-07 10:39:28 --> Database Driver Class Initialized
DEBUG - 2018-02-07 10:39:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 10:39:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 10:39:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-07 10:39:28 --> Pagination Class Initialized
INFO - 2018-02-07 10:39:28 --> Helper loaded: form_helper
INFO - 2018-02-07 10:39:28 --> Form Validation Class Initialized
INFO - 2018-02-07 10:39:28 --> Model Class Initialized
INFO - 2018-02-07 10:39:28 --> Controller Class Initialized
INFO - 2018-02-07 10:39:28 --> Model Class Initialized
INFO - 2018-02-07 10:39:28 --> File loaded: /var/www/html/spamblocker/application/views/index/resetPassword.php
INFO - 2018-02-07 10:39:28 --> Final output sent to browser
DEBUG - 2018-02-07 10:39:28 --> Total execution time: 0.0087
INFO - 2018-02-07 10:39:40 --> Config Class Initialized
INFO - 2018-02-07 10:39:40 --> Hooks Class Initialized
DEBUG - 2018-02-07 10:39:40 --> UTF-8 Support Enabled
INFO - 2018-02-07 10:39:40 --> Utf8 Class Initialized
INFO - 2018-02-07 10:39:40 --> URI Class Initialized
INFO - 2018-02-07 10:39:40 --> Router Class Initialized
INFO - 2018-02-07 10:39:40 --> Output Class Initialized
INFO - 2018-02-07 10:39:40 --> Security Class Initialized
DEBUG - 2018-02-07 10:39:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 10:39:40 --> Input Class Initialized
INFO - 2018-02-07 10:39:40 --> Language Class Initialized
INFO - 2018-02-07 10:39:40 --> Loader Class Initialized
INFO - 2018-02-07 10:39:40 --> Helper loaded: url_helper
INFO - 2018-02-07 10:39:40 --> Helper loaded: file_helper
INFO - 2018-02-07 10:39:40 --> Helper loaded: email_helper
INFO - 2018-02-07 10:39:40 --> Helper loaded: common_helper
INFO - 2018-02-07 10:39:40 --> Database Driver Class Initialized
DEBUG - 2018-02-07 10:39:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 10:39:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 10:39:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-07 10:39:40 --> Pagination Class Initialized
INFO - 2018-02-07 10:39:40 --> Helper loaded: form_helper
INFO - 2018-02-07 10:39:40 --> Form Validation Class Initialized
INFO - 2018-02-07 10:39:40 --> Model Class Initialized
INFO - 2018-02-07 10:39:40 --> Controller Class Initialized
INFO - 2018-02-07 10:39:40 --> Model Class Initialized
INFO - 2018-02-07 10:39:40 --> File loaded: /var/www/html/spamblocker/application/views/index/resetPassword.php
INFO - 2018-02-07 10:39:40 --> Final output sent to browser
DEBUG - 2018-02-07 10:39:40 --> Total execution time: 0.0058
INFO - 2018-02-07 10:39:41 --> Config Class Initialized
INFO - 2018-02-07 10:39:41 --> Hooks Class Initialized
DEBUG - 2018-02-07 10:39:41 --> UTF-8 Support Enabled
INFO - 2018-02-07 10:39:41 --> Utf8 Class Initialized
INFO - 2018-02-07 10:39:41 --> URI Class Initialized
INFO - 2018-02-07 10:39:41 --> Router Class Initialized
INFO - 2018-02-07 10:39:41 --> Output Class Initialized
INFO - 2018-02-07 10:39:41 --> Security Class Initialized
DEBUG - 2018-02-07 10:39:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 10:39:41 --> Input Class Initialized
INFO - 2018-02-07 10:39:41 --> Language Class Initialized
INFO - 2018-02-07 10:39:41 --> Loader Class Initialized
INFO - 2018-02-07 10:39:41 --> Helper loaded: url_helper
INFO - 2018-02-07 10:39:41 --> Helper loaded: file_helper
INFO - 2018-02-07 10:39:41 --> Helper loaded: email_helper
INFO - 2018-02-07 10:39:41 --> Helper loaded: common_helper
INFO - 2018-02-07 10:39:41 --> Database Driver Class Initialized
DEBUG - 2018-02-07 10:39:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 10:39:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 10:39:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-07 10:39:41 --> Pagination Class Initialized
INFO - 2018-02-07 10:39:41 --> Helper loaded: form_helper
INFO - 2018-02-07 10:39:41 --> Form Validation Class Initialized
INFO - 2018-02-07 10:39:41 --> Model Class Initialized
INFO - 2018-02-07 10:39:41 --> Controller Class Initialized
INFO - 2018-02-07 10:39:41 --> Model Class Initialized
INFO - 2018-02-07 10:39:41 --> File loaded: /var/www/html/spamblocker/application/views/index/resetPassword.php
INFO - 2018-02-07 10:39:41 --> Final output sent to browser
DEBUG - 2018-02-07 10:39:41 --> Total execution time: 0.0096
INFO - 2018-02-07 10:39:51 --> Config Class Initialized
INFO - 2018-02-07 10:39:51 --> Hooks Class Initialized
DEBUG - 2018-02-07 10:39:51 --> UTF-8 Support Enabled
INFO - 2018-02-07 10:39:51 --> Utf8 Class Initialized
INFO - 2018-02-07 10:39:51 --> URI Class Initialized
INFO - 2018-02-07 10:39:51 --> Router Class Initialized
INFO - 2018-02-07 10:39:51 --> Output Class Initialized
INFO - 2018-02-07 10:39:51 --> Security Class Initialized
DEBUG - 2018-02-07 10:39:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 10:39:51 --> Input Class Initialized
INFO - 2018-02-07 10:39:51 --> Language Class Initialized
INFO - 2018-02-07 10:39:51 --> Loader Class Initialized
INFO - 2018-02-07 10:39:51 --> Helper loaded: url_helper
INFO - 2018-02-07 10:39:51 --> Helper loaded: file_helper
INFO - 2018-02-07 10:39:51 --> Helper loaded: email_helper
INFO - 2018-02-07 10:39:51 --> Helper loaded: common_helper
INFO - 2018-02-07 10:39:51 --> Database Driver Class Initialized
DEBUG - 2018-02-07 10:39:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 10:39:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 10:39:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-07 10:39:51 --> Pagination Class Initialized
INFO - 2018-02-07 10:39:51 --> Helper loaded: form_helper
INFO - 2018-02-07 10:39:51 --> Form Validation Class Initialized
INFO - 2018-02-07 10:39:51 --> Model Class Initialized
INFO - 2018-02-07 10:39:51 --> Controller Class Initialized
INFO - 2018-02-07 10:39:51 --> Model Class Initialized
INFO - 2018-02-07 10:39:51 --> File loaded: /var/www/html/spamblocker/application/views/index/resetPassword.php
INFO - 2018-02-07 10:39:51 --> Final output sent to browser
DEBUG - 2018-02-07 10:39:51 --> Total execution time: 0.0093
INFO - 2018-02-07 10:40:03 --> Config Class Initialized
INFO - 2018-02-07 10:40:03 --> Hooks Class Initialized
DEBUG - 2018-02-07 10:40:03 --> UTF-8 Support Enabled
INFO - 2018-02-07 10:40:03 --> Utf8 Class Initialized
INFO - 2018-02-07 10:40:03 --> URI Class Initialized
INFO - 2018-02-07 10:40:03 --> Router Class Initialized
INFO - 2018-02-07 10:40:03 --> Output Class Initialized
INFO - 2018-02-07 10:40:03 --> Security Class Initialized
DEBUG - 2018-02-07 10:40:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 10:40:03 --> Input Class Initialized
INFO - 2018-02-07 10:40:03 --> Language Class Initialized
INFO - 2018-02-07 10:40:03 --> Loader Class Initialized
INFO - 2018-02-07 10:40:03 --> Helper loaded: url_helper
INFO - 2018-02-07 10:40:03 --> Helper loaded: file_helper
INFO - 2018-02-07 10:40:03 --> Helper loaded: email_helper
INFO - 2018-02-07 10:40:03 --> Helper loaded: common_helper
INFO - 2018-02-07 10:40:03 --> Database Driver Class Initialized
DEBUG - 2018-02-07 10:40:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 10:40:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 10:40:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-07 10:40:03 --> Pagination Class Initialized
INFO - 2018-02-07 10:40:03 --> Helper loaded: form_helper
INFO - 2018-02-07 10:40:03 --> Form Validation Class Initialized
INFO - 2018-02-07 10:40:03 --> Model Class Initialized
INFO - 2018-02-07 10:40:03 --> Controller Class Initialized
INFO - 2018-02-07 10:40:03 --> Model Class Initialized
INFO - 2018-02-07 10:40:03 --> File loaded: /var/www/html/spamblocker/application/views/index/resetPassword.php
INFO - 2018-02-07 10:40:03 --> Final output sent to browser
DEBUG - 2018-02-07 10:40:03 --> Total execution time: 0.0057
INFO - 2018-02-07 10:40:50 --> Config Class Initialized
INFO - 2018-02-07 10:40:50 --> Hooks Class Initialized
DEBUG - 2018-02-07 10:40:50 --> UTF-8 Support Enabled
INFO - 2018-02-07 10:40:50 --> Utf8 Class Initialized
INFO - 2018-02-07 10:40:50 --> URI Class Initialized
INFO - 2018-02-07 10:40:50 --> Router Class Initialized
INFO - 2018-02-07 10:40:50 --> Output Class Initialized
INFO - 2018-02-07 10:40:50 --> Security Class Initialized
DEBUG - 2018-02-07 10:40:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 10:40:50 --> Input Class Initialized
INFO - 2018-02-07 10:40:50 --> Language Class Initialized
INFO - 2018-02-07 10:40:50 --> Loader Class Initialized
INFO - 2018-02-07 10:40:50 --> Helper loaded: url_helper
INFO - 2018-02-07 10:40:50 --> Helper loaded: file_helper
INFO - 2018-02-07 10:40:50 --> Helper loaded: email_helper
INFO - 2018-02-07 10:40:50 --> Helper loaded: common_helper
INFO - 2018-02-07 10:40:50 --> Database Driver Class Initialized
DEBUG - 2018-02-07 10:40:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 10:40:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 10:40:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-07 10:40:50 --> Pagination Class Initialized
INFO - 2018-02-07 10:40:50 --> Helper loaded: form_helper
INFO - 2018-02-07 10:40:50 --> Form Validation Class Initialized
INFO - 2018-02-07 10:40:50 --> Model Class Initialized
INFO - 2018-02-07 10:40:50 --> Controller Class Initialized
INFO - 2018-02-07 10:40:50 --> Model Class Initialized
INFO - 2018-02-07 10:40:50 --> File loaded: /var/www/html/spamblocker/application/views/index/resetPassword.php
INFO - 2018-02-07 10:40:50 --> Final output sent to browser
DEBUG - 2018-02-07 10:40:50 --> Total execution time: 0.0087
INFO - 2018-02-07 10:42:44 --> Config Class Initialized
INFO - 2018-02-07 10:42:44 --> Hooks Class Initialized
DEBUG - 2018-02-07 10:42:44 --> UTF-8 Support Enabled
INFO - 2018-02-07 10:42:44 --> Utf8 Class Initialized
INFO - 2018-02-07 10:42:44 --> URI Class Initialized
INFO - 2018-02-07 10:42:44 --> Router Class Initialized
INFO - 2018-02-07 10:42:44 --> Output Class Initialized
INFO - 2018-02-07 10:42:44 --> Security Class Initialized
DEBUG - 2018-02-07 10:42:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 10:42:44 --> Input Class Initialized
INFO - 2018-02-07 10:42:44 --> Language Class Initialized
INFO - 2018-02-07 10:42:44 --> Loader Class Initialized
INFO - 2018-02-07 10:42:44 --> Helper loaded: url_helper
INFO - 2018-02-07 10:42:44 --> Helper loaded: file_helper
INFO - 2018-02-07 10:42:44 --> Helper loaded: email_helper
INFO - 2018-02-07 10:42:44 --> Helper loaded: common_helper
INFO - 2018-02-07 10:42:44 --> Database Driver Class Initialized
DEBUG - 2018-02-07 10:42:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 10:42:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 10:42:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-07 10:42:44 --> Pagination Class Initialized
INFO - 2018-02-07 10:42:44 --> Helper loaded: form_helper
INFO - 2018-02-07 10:42:44 --> Form Validation Class Initialized
INFO - 2018-02-07 10:42:44 --> Model Class Initialized
INFO - 2018-02-07 10:42:44 --> Controller Class Initialized
INFO - 2018-02-07 10:42:44 --> Model Class Initialized
INFO - 2018-02-07 10:42:44 --> File loaded: /var/www/html/spamblocker/application/views/index/resetPassword.php
INFO - 2018-02-07 10:42:44 --> Final output sent to browser
DEBUG - 2018-02-07 10:42:44 --> Total execution time: 0.0055
INFO - 2018-02-07 10:43:26 --> Config Class Initialized
INFO - 2018-02-07 10:43:26 --> Hooks Class Initialized
DEBUG - 2018-02-07 10:43:26 --> UTF-8 Support Enabled
INFO - 2018-02-07 10:43:26 --> Utf8 Class Initialized
INFO - 2018-02-07 10:43:26 --> URI Class Initialized
INFO - 2018-02-07 10:43:26 --> Router Class Initialized
INFO - 2018-02-07 10:43:26 --> Output Class Initialized
INFO - 2018-02-07 10:43:26 --> Security Class Initialized
DEBUG - 2018-02-07 10:43:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 10:43:26 --> Input Class Initialized
INFO - 2018-02-07 10:43:26 --> Language Class Initialized
INFO - 2018-02-07 10:43:26 --> Loader Class Initialized
INFO - 2018-02-07 10:43:26 --> Helper loaded: url_helper
INFO - 2018-02-07 10:43:26 --> Helper loaded: file_helper
INFO - 2018-02-07 10:43:26 --> Helper loaded: email_helper
INFO - 2018-02-07 10:43:26 --> Helper loaded: common_helper
INFO - 2018-02-07 10:43:26 --> Database Driver Class Initialized
DEBUG - 2018-02-07 10:43:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 10:43:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 10:43:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-07 10:43:26 --> Pagination Class Initialized
INFO - 2018-02-07 10:43:26 --> Helper loaded: form_helper
INFO - 2018-02-07 10:43:26 --> Form Validation Class Initialized
INFO - 2018-02-07 10:43:26 --> Model Class Initialized
INFO - 2018-02-07 10:43:26 --> Controller Class Initialized
INFO - 2018-02-07 10:43:26 --> Model Class Initialized
INFO - 2018-02-07 10:43:26 --> File loaded: /var/www/html/spamblocker/application/views/index/resetPassword.php
INFO - 2018-02-07 10:43:26 --> Final output sent to browser
DEBUG - 2018-02-07 10:43:26 --> Total execution time: 0.0043
INFO - 2018-02-07 10:43:34 --> Config Class Initialized
INFO - 2018-02-07 10:43:34 --> Hooks Class Initialized
DEBUG - 2018-02-07 10:43:34 --> UTF-8 Support Enabled
INFO - 2018-02-07 10:43:34 --> Utf8 Class Initialized
INFO - 2018-02-07 10:43:34 --> URI Class Initialized
INFO - 2018-02-07 10:43:34 --> Router Class Initialized
INFO - 2018-02-07 10:43:34 --> Output Class Initialized
INFO - 2018-02-07 10:43:34 --> Security Class Initialized
DEBUG - 2018-02-07 10:43:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 10:43:34 --> Input Class Initialized
INFO - 2018-02-07 10:43:34 --> Language Class Initialized
INFO - 2018-02-07 10:43:34 --> Loader Class Initialized
INFO - 2018-02-07 10:43:34 --> Helper loaded: url_helper
INFO - 2018-02-07 10:43:34 --> Helper loaded: file_helper
INFO - 2018-02-07 10:43:34 --> Helper loaded: email_helper
INFO - 2018-02-07 10:43:34 --> Helper loaded: common_helper
INFO - 2018-02-07 10:43:34 --> Database Driver Class Initialized
DEBUG - 2018-02-07 10:43:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 10:43:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 10:43:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-07 10:43:34 --> Pagination Class Initialized
INFO - 2018-02-07 10:43:34 --> Helper loaded: form_helper
INFO - 2018-02-07 10:43:34 --> Form Validation Class Initialized
INFO - 2018-02-07 10:43:34 --> Model Class Initialized
INFO - 2018-02-07 10:43:34 --> Controller Class Initialized
INFO - 2018-02-07 10:43:34 --> Model Class Initialized
INFO - 2018-02-07 10:43:34 --> File loaded: /var/www/html/spamblocker/application/views/index/resetPassword.php
INFO - 2018-02-07 10:43:34 --> Final output sent to browser
DEBUG - 2018-02-07 10:43:34 --> Total execution time: 0.0089
INFO - 2018-02-07 10:47:34 --> Config Class Initialized
INFO - 2018-02-07 10:47:34 --> Hooks Class Initialized
DEBUG - 2018-02-07 10:47:34 --> UTF-8 Support Enabled
INFO - 2018-02-07 10:47:34 --> Utf8 Class Initialized
INFO - 2018-02-07 10:47:34 --> URI Class Initialized
INFO - 2018-02-07 10:47:34 --> Router Class Initialized
INFO - 2018-02-07 10:47:34 --> Output Class Initialized
INFO - 2018-02-07 10:47:34 --> Security Class Initialized
DEBUG - 2018-02-07 10:47:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 10:47:34 --> Input Class Initialized
INFO - 2018-02-07 10:47:34 --> Language Class Initialized
INFO - 2018-02-07 10:47:34 --> Loader Class Initialized
INFO - 2018-02-07 10:47:34 --> Helper loaded: url_helper
INFO - 2018-02-07 10:47:34 --> Helper loaded: file_helper
INFO - 2018-02-07 10:47:34 --> Helper loaded: email_helper
INFO - 2018-02-07 10:47:34 --> Helper loaded: common_helper
INFO - 2018-02-07 10:47:34 --> Database Driver Class Initialized
DEBUG - 2018-02-07 10:47:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 10:47:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 10:47:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-07 10:47:34 --> Pagination Class Initialized
INFO - 2018-02-07 10:47:34 --> Helper loaded: form_helper
INFO - 2018-02-07 10:47:34 --> Form Validation Class Initialized
INFO - 2018-02-07 10:47:34 --> Model Class Initialized
INFO - 2018-02-07 10:47:34 --> Controller Class Initialized
INFO - 2018-02-07 10:47:34 --> Model Class Initialized
INFO - 2018-02-07 10:47:34 --> File loaded: /var/www/html/spamblocker/application/views/index/resetPassword.php
INFO - 2018-02-07 10:47:34 --> Final output sent to browser
DEBUG - 2018-02-07 10:47:34 --> Total execution time: 0.0066
INFO - 2018-02-07 10:47:50 --> Config Class Initialized
INFO - 2018-02-07 10:47:50 --> Hooks Class Initialized
DEBUG - 2018-02-07 10:47:50 --> UTF-8 Support Enabled
INFO - 2018-02-07 10:47:50 --> Utf8 Class Initialized
INFO - 2018-02-07 10:47:50 --> URI Class Initialized
INFO - 2018-02-07 10:47:50 --> Router Class Initialized
INFO - 2018-02-07 10:47:50 --> Output Class Initialized
INFO - 2018-02-07 10:47:50 --> Security Class Initialized
DEBUG - 2018-02-07 10:47:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 10:47:50 --> Input Class Initialized
INFO - 2018-02-07 10:47:50 --> Language Class Initialized
INFO - 2018-02-07 10:47:50 --> Loader Class Initialized
INFO - 2018-02-07 10:47:50 --> Helper loaded: url_helper
INFO - 2018-02-07 10:47:50 --> Helper loaded: file_helper
INFO - 2018-02-07 10:47:50 --> Helper loaded: email_helper
INFO - 2018-02-07 10:47:50 --> Helper loaded: common_helper
INFO - 2018-02-07 10:47:50 --> Database Driver Class Initialized
DEBUG - 2018-02-07 10:47:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 10:47:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 10:47:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-07 10:47:50 --> Pagination Class Initialized
INFO - 2018-02-07 10:47:50 --> Helper loaded: form_helper
INFO - 2018-02-07 10:47:50 --> Form Validation Class Initialized
INFO - 2018-02-07 10:47:50 --> Model Class Initialized
INFO - 2018-02-07 10:47:50 --> Controller Class Initialized
INFO - 2018-02-07 10:47:50 --> Model Class Initialized
INFO - 2018-02-07 10:47:50 --> File loaded: /var/www/html/spamblocker/application/views/index/resetPassword.php
INFO - 2018-02-07 10:47:50 --> Final output sent to browser
DEBUG - 2018-02-07 10:47:50 --> Total execution time: 0.0091
INFO - 2018-02-07 10:48:05 --> Config Class Initialized
INFO - 2018-02-07 10:48:05 --> Hooks Class Initialized
DEBUG - 2018-02-07 10:48:05 --> UTF-8 Support Enabled
INFO - 2018-02-07 10:48:05 --> Utf8 Class Initialized
INFO - 2018-02-07 10:48:05 --> URI Class Initialized
INFO - 2018-02-07 10:48:05 --> Router Class Initialized
INFO - 2018-02-07 10:48:05 --> Output Class Initialized
INFO - 2018-02-07 10:48:05 --> Security Class Initialized
DEBUG - 2018-02-07 10:48:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 10:48:05 --> Input Class Initialized
INFO - 2018-02-07 10:48:05 --> Language Class Initialized
INFO - 2018-02-07 10:48:05 --> Loader Class Initialized
INFO - 2018-02-07 10:48:05 --> Helper loaded: url_helper
INFO - 2018-02-07 10:48:05 --> Helper loaded: file_helper
INFO - 2018-02-07 10:48:05 --> Helper loaded: email_helper
INFO - 2018-02-07 10:48:05 --> Helper loaded: common_helper
INFO - 2018-02-07 10:48:05 --> Database Driver Class Initialized
DEBUG - 2018-02-07 10:48:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 10:48:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 10:48:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-07 10:48:05 --> Pagination Class Initialized
INFO - 2018-02-07 10:48:05 --> Helper loaded: form_helper
INFO - 2018-02-07 10:48:05 --> Form Validation Class Initialized
INFO - 2018-02-07 10:48:05 --> Model Class Initialized
INFO - 2018-02-07 10:48:05 --> Controller Class Initialized
INFO - 2018-02-07 10:48:05 --> Model Class Initialized
INFO - 2018-02-07 10:48:05 --> File loaded: /var/www/html/spamblocker/application/views/index/resetPassword.php
INFO - 2018-02-07 10:48:05 --> Final output sent to browser
DEBUG - 2018-02-07 10:48:05 --> Total execution time: 0.0045
INFO - 2018-02-07 10:48:15 --> Config Class Initialized
INFO - 2018-02-07 10:48:15 --> Hooks Class Initialized
DEBUG - 2018-02-07 10:48:15 --> UTF-8 Support Enabled
INFO - 2018-02-07 10:48:15 --> Utf8 Class Initialized
INFO - 2018-02-07 10:48:15 --> URI Class Initialized
INFO - 2018-02-07 10:48:15 --> Router Class Initialized
INFO - 2018-02-07 10:48:15 --> Output Class Initialized
INFO - 2018-02-07 10:48:15 --> Security Class Initialized
DEBUG - 2018-02-07 10:48:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 10:48:15 --> Input Class Initialized
INFO - 2018-02-07 10:48:15 --> Language Class Initialized
INFO - 2018-02-07 10:48:15 --> Loader Class Initialized
INFO - 2018-02-07 10:48:15 --> Helper loaded: url_helper
INFO - 2018-02-07 10:48:15 --> Helper loaded: file_helper
INFO - 2018-02-07 10:48:15 --> Helper loaded: email_helper
INFO - 2018-02-07 10:48:15 --> Helper loaded: common_helper
INFO - 2018-02-07 10:48:15 --> Database Driver Class Initialized
DEBUG - 2018-02-07 10:48:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 10:48:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 10:48:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-07 10:48:15 --> Pagination Class Initialized
INFO - 2018-02-07 10:48:15 --> Helper loaded: form_helper
INFO - 2018-02-07 10:48:15 --> Form Validation Class Initialized
INFO - 2018-02-07 10:48:15 --> Model Class Initialized
INFO - 2018-02-07 10:48:15 --> Controller Class Initialized
INFO - 2018-02-07 10:48:15 --> Model Class Initialized
INFO - 2018-02-07 10:48:15 --> File loaded: /var/www/html/spamblocker/application/views/index/resetPassword.php
INFO - 2018-02-07 10:48:15 --> Final output sent to browser
DEBUG - 2018-02-07 10:48:15 --> Total execution time: 0.0096
INFO - 2018-02-07 10:48:41 --> Config Class Initialized
INFO - 2018-02-07 10:48:41 --> Hooks Class Initialized
DEBUG - 2018-02-07 10:48:41 --> UTF-8 Support Enabled
INFO - 2018-02-07 10:48:41 --> Utf8 Class Initialized
INFO - 2018-02-07 10:48:41 --> URI Class Initialized
INFO - 2018-02-07 10:48:41 --> Router Class Initialized
INFO - 2018-02-07 10:48:41 --> Output Class Initialized
INFO - 2018-02-07 10:48:41 --> Security Class Initialized
DEBUG - 2018-02-07 10:48:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 10:48:41 --> Input Class Initialized
INFO - 2018-02-07 10:48:41 --> Language Class Initialized
INFO - 2018-02-07 10:48:41 --> Loader Class Initialized
INFO - 2018-02-07 10:48:41 --> Helper loaded: url_helper
INFO - 2018-02-07 10:48:41 --> Helper loaded: file_helper
INFO - 2018-02-07 10:48:41 --> Helper loaded: email_helper
INFO - 2018-02-07 10:48:41 --> Helper loaded: common_helper
INFO - 2018-02-07 10:48:41 --> Database Driver Class Initialized
DEBUG - 2018-02-07 10:48:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 10:48:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 10:48:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-07 10:48:41 --> Pagination Class Initialized
INFO - 2018-02-07 10:48:41 --> Helper loaded: form_helper
INFO - 2018-02-07 10:48:41 --> Form Validation Class Initialized
INFO - 2018-02-07 10:48:41 --> Model Class Initialized
INFO - 2018-02-07 10:48:41 --> Controller Class Initialized
INFO - 2018-02-07 10:48:41 --> Model Class Initialized
INFO - 2018-02-07 10:48:41 --> File loaded: /var/www/html/spamblocker/application/views/index/resetPassword.php
INFO - 2018-02-07 10:48:41 --> Final output sent to browser
DEBUG - 2018-02-07 10:48:41 --> Total execution time: 0.0079
INFO - 2018-02-07 10:48:51 --> Config Class Initialized
INFO - 2018-02-07 10:48:51 --> Hooks Class Initialized
DEBUG - 2018-02-07 10:48:51 --> UTF-8 Support Enabled
INFO - 2018-02-07 10:48:51 --> Utf8 Class Initialized
INFO - 2018-02-07 10:48:51 --> URI Class Initialized
INFO - 2018-02-07 10:48:51 --> Router Class Initialized
INFO - 2018-02-07 10:48:51 --> Output Class Initialized
INFO - 2018-02-07 10:48:51 --> Security Class Initialized
DEBUG - 2018-02-07 10:48:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 10:48:51 --> Input Class Initialized
INFO - 2018-02-07 10:48:51 --> Language Class Initialized
INFO - 2018-02-07 10:48:51 --> Loader Class Initialized
INFO - 2018-02-07 10:48:51 --> Helper loaded: url_helper
INFO - 2018-02-07 10:48:51 --> Helper loaded: file_helper
INFO - 2018-02-07 10:48:51 --> Helper loaded: email_helper
INFO - 2018-02-07 10:48:51 --> Helper loaded: common_helper
INFO - 2018-02-07 10:48:51 --> Database Driver Class Initialized
DEBUG - 2018-02-07 10:48:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 10:48:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 10:48:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-07 10:48:51 --> Pagination Class Initialized
INFO - 2018-02-07 10:48:51 --> Helper loaded: form_helper
INFO - 2018-02-07 10:48:51 --> Form Validation Class Initialized
INFO - 2018-02-07 10:48:51 --> Model Class Initialized
INFO - 2018-02-07 10:48:51 --> Controller Class Initialized
INFO - 2018-02-07 10:48:51 --> Model Class Initialized
INFO - 2018-02-07 10:48:51 --> File loaded: /var/www/html/spamblocker/application/views/index/resetPassword.php
INFO - 2018-02-07 10:48:51 --> Final output sent to browser
DEBUG - 2018-02-07 10:48:51 --> Total execution time: 0.0056
INFO - 2018-02-07 10:49:05 --> Config Class Initialized
INFO - 2018-02-07 10:49:05 --> Hooks Class Initialized
DEBUG - 2018-02-07 10:49:05 --> UTF-8 Support Enabled
INFO - 2018-02-07 10:49:05 --> Utf8 Class Initialized
INFO - 2018-02-07 10:49:05 --> URI Class Initialized
INFO - 2018-02-07 10:49:05 --> Router Class Initialized
INFO - 2018-02-07 10:49:05 --> Output Class Initialized
INFO - 2018-02-07 10:49:05 --> Security Class Initialized
DEBUG - 2018-02-07 10:49:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 10:49:05 --> Input Class Initialized
INFO - 2018-02-07 10:49:05 --> Language Class Initialized
INFO - 2018-02-07 10:49:05 --> Loader Class Initialized
INFO - 2018-02-07 10:49:05 --> Helper loaded: url_helper
INFO - 2018-02-07 10:49:05 --> Helper loaded: file_helper
INFO - 2018-02-07 10:49:05 --> Helper loaded: email_helper
INFO - 2018-02-07 10:49:05 --> Helper loaded: common_helper
INFO - 2018-02-07 10:49:05 --> Database Driver Class Initialized
DEBUG - 2018-02-07 10:49:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 10:49:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 10:49:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-07 10:49:05 --> Pagination Class Initialized
INFO - 2018-02-07 10:49:05 --> Helper loaded: form_helper
INFO - 2018-02-07 10:49:05 --> Form Validation Class Initialized
INFO - 2018-02-07 10:49:05 --> Model Class Initialized
INFO - 2018-02-07 10:49:05 --> Controller Class Initialized
INFO - 2018-02-07 10:49:05 --> Model Class Initialized
INFO - 2018-02-07 10:49:05 --> File loaded: /var/www/html/spamblocker/application/views/index/resetPassword.php
INFO - 2018-02-07 10:49:05 --> Final output sent to browser
DEBUG - 2018-02-07 10:49:05 --> Total execution time: 0.0051
INFO - 2018-02-07 10:49:13 --> Config Class Initialized
INFO - 2018-02-07 10:49:13 --> Hooks Class Initialized
DEBUG - 2018-02-07 10:49:13 --> UTF-8 Support Enabled
INFO - 2018-02-07 10:49:13 --> Utf8 Class Initialized
INFO - 2018-02-07 10:49:13 --> URI Class Initialized
INFO - 2018-02-07 10:49:13 --> Router Class Initialized
INFO - 2018-02-07 10:49:13 --> Output Class Initialized
INFO - 2018-02-07 10:49:13 --> Security Class Initialized
DEBUG - 2018-02-07 10:49:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 10:49:13 --> Input Class Initialized
INFO - 2018-02-07 10:49:13 --> Language Class Initialized
INFO - 2018-02-07 10:49:13 --> Loader Class Initialized
INFO - 2018-02-07 10:49:13 --> Helper loaded: url_helper
INFO - 2018-02-07 10:49:13 --> Helper loaded: file_helper
INFO - 2018-02-07 10:49:13 --> Helper loaded: email_helper
INFO - 2018-02-07 10:49:13 --> Helper loaded: common_helper
INFO - 2018-02-07 10:49:13 --> Database Driver Class Initialized
DEBUG - 2018-02-07 10:49:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 10:49:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 10:49:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-07 10:49:13 --> Pagination Class Initialized
INFO - 2018-02-07 10:49:13 --> Helper loaded: form_helper
INFO - 2018-02-07 10:49:13 --> Form Validation Class Initialized
INFO - 2018-02-07 10:49:13 --> Model Class Initialized
INFO - 2018-02-07 10:49:13 --> Controller Class Initialized
INFO - 2018-02-07 10:49:13 --> Model Class Initialized
INFO - 2018-02-07 10:49:13 --> File loaded: /var/www/html/spamblocker/application/views/index/resetPassword.php
INFO - 2018-02-07 10:49:13 --> Final output sent to browser
DEBUG - 2018-02-07 10:49:13 --> Total execution time: 0.0060
INFO - 2018-02-07 10:49:24 --> Config Class Initialized
INFO - 2018-02-07 10:49:24 --> Hooks Class Initialized
DEBUG - 2018-02-07 10:49:24 --> UTF-8 Support Enabled
INFO - 2018-02-07 10:49:24 --> Utf8 Class Initialized
INFO - 2018-02-07 10:49:24 --> URI Class Initialized
INFO - 2018-02-07 10:49:24 --> Router Class Initialized
INFO - 2018-02-07 10:49:24 --> Output Class Initialized
INFO - 2018-02-07 10:49:24 --> Security Class Initialized
DEBUG - 2018-02-07 10:49:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 10:49:24 --> Input Class Initialized
INFO - 2018-02-07 10:49:24 --> Language Class Initialized
INFO - 2018-02-07 10:49:24 --> Loader Class Initialized
INFO - 2018-02-07 10:49:24 --> Helper loaded: url_helper
INFO - 2018-02-07 10:49:24 --> Helper loaded: file_helper
INFO - 2018-02-07 10:49:24 --> Helper loaded: email_helper
INFO - 2018-02-07 10:49:24 --> Helper loaded: common_helper
INFO - 2018-02-07 10:49:24 --> Database Driver Class Initialized
DEBUG - 2018-02-07 10:49:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 10:49:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 10:49:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-07 10:49:24 --> Pagination Class Initialized
INFO - 2018-02-07 10:49:24 --> Helper loaded: form_helper
INFO - 2018-02-07 10:49:24 --> Form Validation Class Initialized
INFO - 2018-02-07 10:49:24 --> Model Class Initialized
INFO - 2018-02-07 10:49:24 --> Controller Class Initialized
INFO - 2018-02-07 10:49:24 --> Model Class Initialized
INFO - 2018-02-07 10:49:24 --> File loaded: /var/www/html/spamblocker/application/views/index/resetPassword.php
INFO - 2018-02-07 10:49:24 --> Final output sent to browser
DEBUG - 2018-02-07 10:49:24 --> Total execution time: 0.0073
INFO - 2018-02-07 10:49:38 --> Config Class Initialized
INFO - 2018-02-07 10:49:38 --> Hooks Class Initialized
DEBUG - 2018-02-07 10:49:38 --> UTF-8 Support Enabled
INFO - 2018-02-07 10:49:38 --> Utf8 Class Initialized
INFO - 2018-02-07 10:49:38 --> URI Class Initialized
INFO - 2018-02-07 10:49:38 --> Router Class Initialized
INFO - 2018-02-07 10:49:38 --> Output Class Initialized
INFO - 2018-02-07 10:49:38 --> Security Class Initialized
DEBUG - 2018-02-07 10:49:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 10:49:38 --> Input Class Initialized
INFO - 2018-02-07 10:49:38 --> Language Class Initialized
INFO - 2018-02-07 10:49:38 --> Loader Class Initialized
INFO - 2018-02-07 10:49:38 --> Helper loaded: url_helper
INFO - 2018-02-07 10:49:38 --> Helper loaded: file_helper
INFO - 2018-02-07 10:49:38 --> Helper loaded: email_helper
INFO - 2018-02-07 10:49:38 --> Helper loaded: common_helper
INFO - 2018-02-07 10:49:38 --> Database Driver Class Initialized
DEBUG - 2018-02-07 10:49:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 10:49:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 10:49:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-07 10:49:38 --> Pagination Class Initialized
INFO - 2018-02-07 10:49:38 --> Helper loaded: form_helper
INFO - 2018-02-07 10:49:38 --> Form Validation Class Initialized
INFO - 2018-02-07 10:49:38 --> Model Class Initialized
INFO - 2018-02-07 10:49:38 --> Controller Class Initialized
INFO - 2018-02-07 10:49:38 --> Model Class Initialized
INFO - 2018-02-07 10:49:38 --> File loaded: /var/www/html/spamblocker/application/views/index/resetPassword.php
INFO - 2018-02-07 10:49:38 --> Final output sent to browser
DEBUG - 2018-02-07 10:49:38 --> Total execution time: 0.0091
INFO - 2018-02-07 10:50:14 --> Config Class Initialized
INFO - 2018-02-07 10:50:14 --> Hooks Class Initialized
DEBUG - 2018-02-07 10:50:14 --> UTF-8 Support Enabled
INFO - 2018-02-07 10:50:14 --> Utf8 Class Initialized
INFO - 2018-02-07 10:50:14 --> URI Class Initialized
INFO - 2018-02-07 10:50:14 --> Router Class Initialized
INFO - 2018-02-07 10:50:14 --> Output Class Initialized
INFO - 2018-02-07 10:50:14 --> Security Class Initialized
DEBUG - 2018-02-07 10:50:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 10:50:14 --> Input Class Initialized
INFO - 2018-02-07 10:50:14 --> Language Class Initialized
INFO - 2018-02-07 10:50:14 --> Loader Class Initialized
INFO - 2018-02-07 10:50:14 --> Helper loaded: url_helper
INFO - 2018-02-07 10:50:14 --> Helper loaded: file_helper
INFO - 2018-02-07 10:50:14 --> Helper loaded: email_helper
INFO - 2018-02-07 10:50:14 --> Helper loaded: common_helper
INFO - 2018-02-07 10:50:14 --> Database Driver Class Initialized
DEBUG - 2018-02-07 10:50:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 10:50:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 10:50:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-07 10:50:14 --> Pagination Class Initialized
INFO - 2018-02-07 10:50:14 --> Helper loaded: form_helper
INFO - 2018-02-07 10:50:14 --> Form Validation Class Initialized
INFO - 2018-02-07 10:50:14 --> Model Class Initialized
INFO - 2018-02-07 10:50:14 --> Controller Class Initialized
INFO - 2018-02-07 10:50:14 --> Model Class Initialized
INFO - 2018-02-07 10:50:14 --> File loaded: /var/www/html/spamblocker/application/views/index/resetPassword.php
INFO - 2018-02-07 10:50:14 --> Final output sent to browser
DEBUG - 2018-02-07 10:50:14 --> Total execution time: 0.0046
INFO - 2018-02-07 10:50:17 --> Config Class Initialized
INFO - 2018-02-07 10:50:17 --> Hooks Class Initialized
DEBUG - 2018-02-07 10:50:17 --> UTF-8 Support Enabled
INFO - 2018-02-07 10:50:17 --> Utf8 Class Initialized
INFO - 2018-02-07 10:50:17 --> URI Class Initialized
INFO - 2018-02-07 10:50:17 --> Router Class Initialized
INFO - 2018-02-07 10:50:17 --> Output Class Initialized
INFO - 2018-02-07 10:50:17 --> Security Class Initialized
DEBUG - 2018-02-07 10:50:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 10:50:17 --> Input Class Initialized
INFO - 2018-02-07 10:50:17 --> Language Class Initialized
INFO - 2018-02-07 10:50:17 --> Loader Class Initialized
INFO - 2018-02-07 10:50:17 --> Helper loaded: url_helper
INFO - 2018-02-07 10:50:17 --> Helper loaded: file_helper
INFO - 2018-02-07 10:50:17 --> Helper loaded: email_helper
INFO - 2018-02-07 10:50:17 --> Helper loaded: common_helper
INFO - 2018-02-07 10:50:17 --> Database Driver Class Initialized
DEBUG - 2018-02-07 10:50:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 10:50:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 10:50:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-07 10:50:17 --> Pagination Class Initialized
INFO - 2018-02-07 10:50:17 --> Helper loaded: form_helper
INFO - 2018-02-07 10:50:17 --> Form Validation Class Initialized
INFO - 2018-02-07 10:50:17 --> Model Class Initialized
INFO - 2018-02-07 10:50:17 --> Controller Class Initialized
INFO - 2018-02-07 10:50:17 --> Model Class Initialized
INFO - 2018-02-07 10:50:17 --> File loaded: /var/www/html/spamblocker/application/views/index/resetPassword.php
INFO - 2018-02-07 10:50:17 --> Final output sent to browser
DEBUG - 2018-02-07 10:50:17 --> Total execution time: 0.0081
INFO - 2018-02-07 10:51:03 --> Config Class Initialized
INFO - 2018-02-07 10:51:03 --> Hooks Class Initialized
DEBUG - 2018-02-07 10:51:03 --> UTF-8 Support Enabled
INFO - 2018-02-07 10:51:03 --> Utf8 Class Initialized
INFO - 2018-02-07 10:51:03 --> URI Class Initialized
INFO - 2018-02-07 10:51:03 --> Router Class Initialized
INFO - 2018-02-07 10:51:03 --> Output Class Initialized
INFO - 2018-02-07 10:51:03 --> Security Class Initialized
DEBUG - 2018-02-07 10:51:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 10:51:03 --> Input Class Initialized
INFO - 2018-02-07 10:51:03 --> Language Class Initialized
INFO - 2018-02-07 10:51:03 --> Loader Class Initialized
INFO - 2018-02-07 10:51:03 --> Helper loaded: url_helper
INFO - 2018-02-07 10:51:03 --> Helper loaded: file_helper
INFO - 2018-02-07 10:51:03 --> Helper loaded: email_helper
INFO - 2018-02-07 10:51:03 --> Helper loaded: common_helper
INFO - 2018-02-07 10:51:03 --> Database Driver Class Initialized
DEBUG - 2018-02-07 10:51:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 10:51:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 10:51:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-07 10:51:03 --> Pagination Class Initialized
INFO - 2018-02-07 10:51:03 --> Helper loaded: form_helper
INFO - 2018-02-07 10:51:03 --> Form Validation Class Initialized
INFO - 2018-02-07 10:51:03 --> Model Class Initialized
INFO - 2018-02-07 10:51:03 --> Controller Class Initialized
INFO - 2018-02-07 10:51:03 --> Model Class Initialized
INFO - 2018-02-07 10:51:03 --> File loaded: /var/www/html/spamblocker/application/views/index/resetPassword.php
INFO - 2018-02-07 10:51:03 --> Final output sent to browser
DEBUG - 2018-02-07 10:51:03 --> Total execution time: 0.0059
INFO - 2018-02-07 10:51:23 --> Config Class Initialized
INFO - 2018-02-07 10:51:23 --> Hooks Class Initialized
DEBUG - 2018-02-07 10:51:23 --> UTF-8 Support Enabled
INFO - 2018-02-07 10:51:23 --> Utf8 Class Initialized
INFO - 2018-02-07 10:51:23 --> URI Class Initialized
INFO - 2018-02-07 10:51:23 --> Router Class Initialized
INFO - 2018-02-07 10:51:23 --> Output Class Initialized
INFO - 2018-02-07 10:51:23 --> Security Class Initialized
DEBUG - 2018-02-07 10:51:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 10:51:23 --> Input Class Initialized
INFO - 2018-02-07 10:51:23 --> Language Class Initialized
INFO - 2018-02-07 10:51:23 --> Loader Class Initialized
INFO - 2018-02-07 10:51:23 --> Helper loaded: url_helper
INFO - 2018-02-07 10:51:23 --> Helper loaded: file_helper
INFO - 2018-02-07 10:51:23 --> Helper loaded: email_helper
INFO - 2018-02-07 10:51:23 --> Helper loaded: common_helper
INFO - 2018-02-07 10:51:23 --> Database Driver Class Initialized
DEBUG - 2018-02-07 10:51:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 10:51:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 10:51:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-07 10:51:23 --> Pagination Class Initialized
INFO - 2018-02-07 10:51:23 --> Helper loaded: form_helper
INFO - 2018-02-07 10:51:23 --> Form Validation Class Initialized
INFO - 2018-02-07 10:51:23 --> Model Class Initialized
INFO - 2018-02-07 10:51:23 --> Controller Class Initialized
INFO - 2018-02-07 10:51:23 --> Model Class Initialized
INFO - 2018-02-07 10:51:23 --> File loaded: /var/www/html/spamblocker/application/views/index/resetPassword.php
INFO - 2018-02-07 10:51:23 --> Final output sent to browser
DEBUG - 2018-02-07 10:51:23 --> Total execution time: 0.0063
INFO - 2018-02-07 10:52:01 --> Config Class Initialized
INFO - 2018-02-07 10:52:01 --> Hooks Class Initialized
DEBUG - 2018-02-07 10:52:01 --> UTF-8 Support Enabled
INFO - 2018-02-07 10:52:01 --> Utf8 Class Initialized
INFO - 2018-02-07 10:52:01 --> URI Class Initialized
INFO - 2018-02-07 10:52:01 --> Router Class Initialized
INFO - 2018-02-07 10:52:01 --> Output Class Initialized
INFO - 2018-02-07 10:52:01 --> Security Class Initialized
DEBUG - 2018-02-07 10:52:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 10:52:01 --> Input Class Initialized
INFO - 2018-02-07 10:52:01 --> Language Class Initialized
INFO - 2018-02-07 10:52:01 --> Loader Class Initialized
INFO - 2018-02-07 10:52:01 --> Helper loaded: url_helper
INFO - 2018-02-07 10:52:01 --> Helper loaded: file_helper
INFO - 2018-02-07 10:52:01 --> Helper loaded: email_helper
INFO - 2018-02-07 10:52:01 --> Helper loaded: common_helper
INFO - 2018-02-07 10:52:01 --> Database Driver Class Initialized
DEBUG - 2018-02-07 10:52:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 10:52:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 10:52:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-07 10:52:01 --> Pagination Class Initialized
INFO - 2018-02-07 10:52:01 --> Helper loaded: form_helper
INFO - 2018-02-07 10:52:01 --> Form Validation Class Initialized
INFO - 2018-02-07 10:52:01 --> Model Class Initialized
INFO - 2018-02-07 10:52:01 --> Controller Class Initialized
INFO - 2018-02-07 10:52:01 --> Model Class Initialized
INFO - 2018-02-07 10:52:01 --> File loaded: /var/www/html/spamblocker/application/views/index/resetPassword.php
INFO - 2018-02-07 10:52:01 --> Final output sent to browser
DEBUG - 2018-02-07 10:52:01 --> Total execution time: 0.0089
INFO - 2018-02-07 10:52:37 --> Config Class Initialized
INFO - 2018-02-07 10:52:37 --> Hooks Class Initialized
DEBUG - 2018-02-07 10:52:37 --> UTF-8 Support Enabled
INFO - 2018-02-07 10:52:37 --> Utf8 Class Initialized
INFO - 2018-02-07 10:52:37 --> URI Class Initialized
INFO - 2018-02-07 10:52:37 --> Router Class Initialized
INFO - 2018-02-07 10:52:37 --> Output Class Initialized
INFO - 2018-02-07 10:52:37 --> Security Class Initialized
DEBUG - 2018-02-07 10:52:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 10:52:37 --> Input Class Initialized
INFO - 2018-02-07 10:52:37 --> Language Class Initialized
INFO - 2018-02-07 10:52:37 --> Loader Class Initialized
INFO - 2018-02-07 10:52:37 --> Helper loaded: url_helper
INFO - 2018-02-07 10:52:37 --> Helper loaded: file_helper
INFO - 2018-02-07 10:52:37 --> Helper loaded: email_helper
INFO - 2018-02-07 10:52:37 --> Helper loaded: common_helper
INFO - 2018-02-07 10:52:37 --> Database Driver Class Initialized
DEBUG - 2018-02-07 10:52:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 10:52:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 10:52:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-07 10:52:37 --> Pagination Class Initialized
INFO - 2018-02-07 10:52:37 --> Helper loaded: form_helper
INFO - 2018-02-07 10:52:37 --> Form Validation Class Initialized
INFO - 2018-02-07 10:52:37 --> Model Class Initialized
INFO - 2018-02-07 10:52:37 --> Controller Class Initialized
INFO - 2018-02-07 10:52:37 --> Model Class Initialized
INFO - 2018-02-07 10:52:37 --> File loaded: /var/www/html/spamblocker/application/views/index/resetPassword.php
INFO - 2018-02-07 10:52:37 --> Final output sent to browser
DEBUG - 2018-02-07 10:52:37 --> Total execution time: 0.0109
INFO - 2018-02-07 10:53:39 --> Config Class Initialized
INFO - 2018-02-07 10:53:39 --> Hooks Class Initialized
DEBUG - 2018-02-07 10:53:39 --> UTF-8 Support Enabled
INFO - 2018-02-07 10:53:39 --> Utf8 Class Initialized
INFO - 2018-02-07 10:53:39 --> URI Class Initialized
INFO - 2018-02-07 10:53:39 --> Router Class Initialized
INFO - 2018-02-07 10:53:39 --> Output Class Initialized
INFO - 2018-02-07 10:53:39 --> Security Class Initialized
DEBUG - 2018-02-07 10:53:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 10:53:39 --> Input Class Initialized
INFO - 2018-02-07 10:53:39 --> Language Class Initialized
INFO - 2018-02-07 10:53:39 --> Loader Class Initialized
INFO - 2018-02-07 10:53:39 --> Helper loaded: url_helper
INFO - 2018-02-07 10:53:39 --> Helper loaded: file_helper
INFO - 2018-02-07 10:53:39 --> Helper loaded: email_helper
INFO - 2018-02-07 10:53:39 --> Helper loaded: common_helper
INFO - 2018-02-07 10:53:39 --> Database Driver Class Initialized
DEBUG - 2018-02-07 10:53:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 10:53:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 10:53:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-07 10:53:39 --> Pagination Class Initialized
INFO - 2018-02-07 10:53:39 --> Helper loaded: form_helper
INFO - 2018-02-07 10:53:39 --> Form Validation Class Initialized
INFO - 2018-02-07 10:53:39 --> Model Class Initialized
INFO - 2018-02-07 10:53:39 --> Controller Class Initialized
INFO - 2018-02-07 10:53:39 --> Model Class Initialized
INFO - 2018-02-07 10:53:39 --> File loaded: /var/www/html/spamblocker/application/views/index/resetPassword.php
INFO - 2018-02-07 10:53:39 --> Final output sent to browser
DEBUG - 2018-02-07 10:53:39 --> Total execution time: 0.0087
INFO - 2018-02-07 10:55:26 --> Config Class Initialized
INFO - 2018-02-07 10:55:26 --> Hooks Class Initialized
DEBUG - 2018-02-07 10:55:26 --> UTF-8 Support Enabled
INFO - 2018-02-07 10:55:26 --> Utf8 Class Initialized
INFO - 2018-02-07 10:55:26 --> URI Class Initialized
INFO - 2018-02-07 10:55:26 --> Router Class Initialized
INFO - 2018-02-07 10:55:26 --> Output Class Initialized
INFO - 2018-02-07 10:55:26 --> Security Class Initialized
DEBUG - 2018-02-07 10:55:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 10:55:26 --> Input Class Initialized
INFO - 2018-02-07 10:55:26 --> Language Class Initialized
INFO - 2018-02-07 10:55:26 --> Loader Class Initialized
INFO - 2018-02-07 10:55:26 --> Helper loaded: url_helper
INFO - 2018-02-07 10:55:26 --> Helper loaded: file_helper
INFO - 2018-02-07 10:55:26 --> Helper loaded: email_helper
INFO - 2018-02-07 10:55:26 --> Helper loaded: common_helper
INFO - 2018-02-07 10:55:26 --> Database Driver Class Initialized
DEBUG - 2018-02-07 10:55:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 10:55:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 10:55:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-07 10:55:26 --> Pagination Class Initialized
INFO - 2018-02-07 10:55:26 --> Helper loaded: form_helper
INFO - 2018-02-07 10:55:26 --> Form Validation Class Initialized
INFO - 2018-02-07 10:55:26 --> Model Class Initialized
INFO - 2018-02-07 10:55:26 --> Controller Class Initialized
INFO - 2018-02-07 10:55:26 --> Model Class Initialized
INFO - 2018-02-07 10:55:26 --> File loaded: /var/www/html/spamblocker/application/views/index/resetPassword.php
INFO - 2018-02-07 10:55:26 --> Final output sent to browser
DEBUG - 2018-02-07 10:55:26 --> Total execution time: 0.0051
INFO - 2018-02-07 10:55:50 --> Config Class Initialized
INFO - 2018-02-07 10:55:50 --> Hooks Class Initialized
DEBUG - 2018-02-07 10:55:50 --> UTF-8 Support Enabled
INFO - 2018-02-07 10:55:50 --> Utf8 Class Initialized
INFO - 2018-02-07 10:55:50 --> URI Class Initialized
INFO - 2018-02-07 10:55:50 --> Router Class Initialized
INFO - 2018-02-07 10:55:50 --> Output Class Initialized
INFO - 2018-02-07 10:55:50 --> Security Class Initialized
DEBUG - 2018-02-07 10:55:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 10:55:50 --> Input Class Initialized
INFO - 2018-02-07 10:55:50 --> Language Class Initialized
INFO - 2018-02-07 10:55:50 --> Loader Class Initialized
INFO - 2018-02-07 10:55:50 --> Helper loaded: url_helper
INFO - 2018-02-07 10:55:50 --> Helper loaded: file_helper
INFO - 2018-02-07 10:55:50 --> Helper loaded: email_helper
INFO - 2018-02-07 10:55:50 --> Helper loaded: common_helper
INFO - 2018-02-07 10:55:50 --> Database Driver Class Initialized
DEBUG - 2018-02-07 10:55:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 10:55:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 10:55:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-07 10:55:50 --> Pagination Class Initialized
INFO - 2018-02-07 10:55:50 --> Helper loaded: form_helper
INFO - 2018-02-07 10:55:50 --> Form Validation Class Initialized
INFO - 2018-02-07 10:55:50 --> Model Class Initialized
INFO - 2018-02-07 10:55:50 --> Controller Class Initialized
INFO - 2018-02-07 10:55:50 --> Model Class Initialized
INFO - 2018-02-07 10:55:50 --> File loaded: /var/www/html/spamblocker/application/views/index/resetPassword.php
INFO - 2018-02-07 10:55:50 --> Final output sent to browser
DEBUG - 2018-02-07 10:55:50 --> Total execution time: 0.0085
INFO - 2018-02-07 10:57:21 --> Config Class Initialized
INFO - 2018-02-07 10:57:21 --> Hooks Class Initialized
DEBUG - 2018-02-07 10:57:21 --> UTF-8 Support Enabled
INFO - 2018-02-07 10:57:21 --> Utf8 Class Initialized
INFO - 2018-02-07 10:57:21 --> URI Class Initialized
INFO - 2018-02-07 10:57:21 --> Router Class Initialized
INFO - 2018-02-07 10:57:21 --> Output Class Initialized
INFO - 2018-02-07 10:57:21 --> Security Class Initialized
DEBUG - 2018-02-07 10:57:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 10:57:21 --> Input Class Initialized
INFO - 2018-02-07 10:57:21 --> Language Class Initialized
INFO - 2018-02-07 10:57:21 --> Loader Class Initialized
INFO - 2018-02-07 10:57:21 --> Helper loaded: url_helper
INFO - 2018-02-07 10:57:21 --> Helper loaded: file_helper
INFO - 2018-02-07 10:57:21 --> Helper loaded: email_helper
INFO - 2018-02-07 10:57:21 --> Helper loaded: common_helper
INFO - 2018-02-07 10:57:21 --> Database Driver Class Initialized
DEBUG - 2018-02-07 10:57:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 10:57:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 10:57:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-07 10:57:21 --> Pagination Class Initialized
INFO - 2018-02-07 10:57:21 --> Helper loaded: form_helper
INFO - 2018-02-07 10:57:21 --> Form Validation Class Initialized
INFO - 2018-02-07 10:57:21 --> Model Class Initialized
INFO - 2018-02-07 10:57:21 --> Controller Class Initialized
INFO - 2018-02-07 10:57:21 --> Model Class Initialized
INFO - 2018-02-07 10:57:21 --> File loaded: /var/www/html/spamblocker/application/views/index/resetPassword.php
INFO - 2018-02-07 10:57:21 --> Final output sent to browser
DEBUG - 2018-02-07 10:57:21 --> Total execution time: 0.0090
INFO - 2018-02-07 10:58:00 --> Config Class Initialized
INFO - 2018-02-07 10:58:00 --> Hooks Class Initialized
DEBUG - 2018-02-07 10:58:00 --> UTF-8 Support Enabled
INFO - 2018-02-07 10:58:00 --> Utf8 Class Initialized
INFO - 2018-02-07 10:58:00 --> URI Class Initialized
INFO - 2018-02-07 10:58:00 --> Router Class Initialized
INFO - 2018-02-07 10:58:00 --> Output Class Initialized
INFO - 2018-02-07 10:58:00 --> Security Class Initialized
DEBUG - 2018-02-07 10:58:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 10:58:00 --> Input Class Initialized
INFO - 2018-02-07 10:58:00 --> Language Class Initialized
INFO - 2018-02-07 10:58:00 --> Loader Class Initialized
INFO - 2018-02-07 10:58:00 --> Helper loaded: url_helper
INFO - 2018-02-07 10:58:00 --> Helper loaded: file_helper
INFO - 2018-02-07 10:58:00 --> Helper loaded: email_helper
INFO - 2018-02-07 10:58:00 --> Helper loaded: common_helper
INFO - 2018-02-07 10:58:00 --> Database Driver Class Initialized
DEBUG - 2018-02-07 10:58:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 10:58:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 10:58:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-07 10:58:00 --> Pagination Class Initialized
INFO - 2018-02-07 10:58:00 --> Helper loaded: form_helper
INFO - 2018-02-07 10:58:00 --> Form Validation Class Initialized
INFO - 2018-02-07 10:58:00 --> Model Class Initialized
INFO - 2018-02-07 10:58:00 --> Controller Class Initialized
INFO - 2018-02-07 10:58:00 --> Model Class Initialized
INFO - 2018-02-07 10:58:00 --> File loaded: /var/www/html/spamblocker/application/views/index/resetPassword.php
INFO - 2018-02-07 10:58:00 --> Final output sent to browser
DEBUG - 2018-02-07 10:58:00 --> Total execution time: 0.0077
INFO - 2018-02-07 10:58:17 --> Config Class Initialized
INFO - 2018-02-07 10:58:17 --> Hooks Class Initialized
DEBUG - 2018-02-07 10:58:17 --> UTF-8 Support Enabled
INFO - 2018-02-07 10:58:17 --> Utf8 Class Initialized
INFO - 2018-02-07 10:58:17 --> URI Class Initialized
INFO - 2018-02-07 10:58:17 --> Router Class Initialized
INFO - 2018-02-07 10:58:17 --> Output Class Initialized
INFO - 2018-02-07 10:58:17 --> Security Class Initialized
DEBUG - 2018-02-07 10:58:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 10:58:17 --> Input Class Initialized
INFO - 2018-02-07 10:58:17 --> Language Class Initialized
INFO - 2018-02-07 10:58:17 --> Loader Class Initialized
INFO - 2018-02-07 10:58:17 --> Helper loaded: url_helper
INFO - 2018-02-07 10:58:17 --> Helper loaded: file_helper
INFO - 2018-02-07 10:58:17 --> Helper loaded: email_helper
INFO - 2018-02-07 10:58:17 --> Helper loaded: common_helper
INFO - 2018-02-07 10:58:17 --> Database Driver Class Initialized
DEBUG - 2018-02-07 10:58:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 10:58:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 10:58:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-07 10:58:17 --> Pagination Class Initialized
INFO - 2018-02-07 10:58:17 --> Helper loaded: form_helper
INFO - 2018-02-07 10:58:17 --> Form Validation Class Initialized
INFO - 2018-02-07 10:58:17 --> Model Class Initialized
INFO - 2018-02-07 10:58:17 --> Controller Class Initialized
INFO - 2018-02-07 10:58:17 --> Model Class Initialized
INFO - 2018-02-07 10:58:17 --> File loaded: /var/www/html/spamblocker/application/views/index/resetPassword.php
INFO - 2018-02-07 10:58:17 --> Final output sent to browser
DEBUG - 2018-02-07 10:58:17 --> Total execution time: 0.0057
INFO - 2018-02-07 11:00:21 --> Config Class Initialized
INFO - 2018-02-07 11:00:21 --> Hooks Class Initialized
DEBUG - 2018-02-07 11:00:21 --> UTF-8 Support Enabled
INFO - 2018-02-07 11:00:21 --> Utf8 Class Initialized
INFO - 2018-02-07 11:00:21 --> URI Class Initialized
INFO - 2018-02-07 11:00:21 --> Router Class Initialized
INFO - 2018-02-07 11:00:21 --> Output Class Initialized
INFO - 2018-02-07 11:00:21 --> Security Class Initialized
DEBUG - 2018-02-07 11:00:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 11:00:21 --> Input Class Initialized
INFO - 2018-02-07 11:00:21 --> Language Class Initialized
INFO - 2018-02-07 11:00:21 --> Loader Class Initialized
INFO - 2018-02-07 11:00:21 --> Helper loaded: url_helper
INFO - 2018-02-07 11:00:21 --> Helper loaded: file_helper
INFO - 2018-02-07 11:00:21 --> Helper loaded: email_helper
INFO - 2018-02-07 11:00:21 --> Helper loaded: common_helper
INFO - 2018-02-07 11:00:21 --> Database Driver Class Initialized
DEBUG - 2018-02-07 11:00:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 11:00:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 11:00:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-07 11:00:21 --> Pagination Class Initialized
INFO - 2018-02-07 11:00:21 --> Helper loaded: form_helper
INFO - 2018-02-07 11:00:21 --> Form Validation Class Initialized
INFO - 2018-02-07 11:00:21 --> Model Class Initialized
INFO - 2018-02-07 11:00:21 --> Controller Class Initialized
INFO - 2018-02-07 11:00:21 --> Model Class Initialized
INFO - 2018-02-07 11:00:21 --> File loaded: /var/www/html/spamblocker/application/views/index/resetPassword.php
INFO - 2018-02-07 11:00:21 --> Final output sent to browser
DEBUG - 2018-02-07 11:00:21 --> Total execution time: 0.0082
INFO - 2018-02-07 11:01:29 --> Config Class Initialized
INFO - 2018-02-07 11:01:29 --> Hooks Class Initialized
DEBUG - 2018-02-07 11:01:29 --> UTF-8 Support Enabled
INFO - 2018-02-07 11:01:29 --> Utf8 Class Initialized
INFO - 2018-02-07 11:01:29 --> URI Class Initialized
INFO - 2018-02-07 11:01:29 --> Router Class Initialized
INFO - 2018-02-07 11:01:29 --> Output Class Initialized
INFO - 2018-02-07 11:01:29 --> Security Class Initialized
DEBUG - 2018-02-07 11:01:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 11:01:29 --> Input Class Initialized
INFO - 2018-02-07 11:01:29 --> Language Class Initialized
INFO - 2018-02-07 11:01:29 --> Loader Class Initialized
INFO - 2018-02-07 11:01:29 --> Helper loaded: url_helper
INFO - 2018-02-07 11:01:29 --> Helper loaded: file_helper
INFO - 2018-02-07 11:01:29 --> Helper loaded: email_helper
INFO - 2018-02-07 11:01:29 --> Helper loaded: common_helper
INFO - 2018-02-07 11:01:29 --> Database Driver Class Initialized
DEBUG - 2018-02-07 11:01:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 11:01:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 11:01:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-07 11:01:29 --> Pagination Class Initialized
INFO - 2018-02-07 11:01:29 --> Helper loaded: form_helper
INFO - 2018-02-07 11:01:29 --> Form Validation Class Initialized
INFO - 2018-02-07 11:01:29 --> Model Class Initialized
INFO - 2018-02-07 11:01:29 --> Controller Class Initialized
INFO - 2018-02-07 11:01:29 --> Model Class Initialized
INFO - 2018-02-07 11:01:29 --> File loaded: /var/www/html/spamblocker/application/views/index/resetPassword.php
INFO - 2018-02-07 11:01:29 --> Final output sent to browser
DEBUG - 2018-02-07 11:01:29 --> Total execution time: 0.0087
INFO - 2018-02-07 11:02:55 --> Config Class Initialized
INFO - 2018-02-07 11:02:55 --> Hooks Class Initialized
DEBUG - 2018-02-07 11:02:55 --> UTF-8 Support Enabled
INFO - 2018-02-07 11:02:55 --> Utf8 Class Initialized
INFO - 2018-02-07 11:02:55 --> URI Class Initialized
INFO - 2018-02-07 11:02:55 --> Router Class Initialized
INFO - 2018-02-07 11:02:55 --> Output Class Initialized
INFO - 2018-02-07 11:02:55 --> Security Class Initialized
DEBUG - 2018-02-07 11:02:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 11:02:55 --> Input Class Initialized
INFO - 2018-02-07 11:02:55 --> Language Class Initialized
INFO - 2018-02-07 11:02:55 --> Loader Class Initialized
INFO - 2018-02-07 11:02:55 --> Helper loaded: url_helper
INFO - 2018-02-07 11:02:55 --> Helper loaded: file_helper
INFO - 2018-02-07 11:02:55 --> Helper loaded: email_helper
INFO - 2018-02-07 11:02:55 --> Helper loaded: common_helper
INFO - 2018-02-07 11:02:55 --> Database Driver Class Initialized
DEBUG - 2018-02-07 11:02:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 11:02:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 11:02:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-07 11:02:55 --> Pagination Class Initialized
INFO - 2018-02-07 11:02:55 --> Helper loaded: form_helper
INFO - 2018-02-07 11:02:55 --> Form Validation Class Initialized
INFO - 2018-02-07 11:02:55 --> Model Class Initialized
INFO - 2018-02-07 11:02:55 --> Controller Class Initialized
INFO - 2018-02-07 11:02:55 --> Model Class Initialized
INFO - 2018-02-07 11:02:55 --> File loaded: /var/www/html/spamblocker/application/views/index/resetPassword.php
INFO - 2018-02-07 11:02:55 --> Final output sent to browser
DEBUG - 2018-02-07 11:02:55 --> Total execution time: 0.0094
INFO - 2018-02-07 11:02:56 --> Config Class Initialized
INFO - 2018-02-07 11:02:56 --> Hooks Class Initialized
DEBUG - 2018-02-07 11:02:56 --> UTF-8 Support Enabled
INFO - 2018-02-07 11:02:56 --> Utf8 Class Initialized
INFO - 2018-02-07 11:02:56 --> URI Class Initialized
INFO - 2018-02-07 11:02:56 --> Router Class Initialized
INFO - 2018-02-07 11:02:56 --> Output Class Initialized
INFO - 2018-02-07 11:02:56 --> Security Class Initialized
DEBUG - 2018-02-07 11:02:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 11:02:56 --> Input Class Initialized
INFO - 2018-02-07 11:02:56 --> Language Class Initialized
INFO - 2018-02-07 11:02:56 --> Loader Class Initialized
INFO - 2018-02-07 11:02:56 --> Helper loaded: url_helper
INFO - 2018-02-07 11:02:56 --> Helper loaded: file_helper
INFO - 2018-02-07 11:02:56 --> Helper loaded: email_helper
INFO - 2018-02-07 11:02:56 --> Helper loaded: common_helper
INFO - 2018-02-07 11:02:56 --> Database Driver Class Initialized
DEBUG - 2018-02-07 11:02:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 11:02:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 11:02:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-07 11:02:56 --> Pagination Class Initialized
INFO - 2018-02-07 11:02:56 --> Helper loaded: form_helper
INFO - 2018-02-07 11:02:56 --> Form Validation Class Initialized
INFO - 2018-02-07 11:02:56 --> Model Class Initialized
INFO - 2018-02-07 11:02:56 --> Controller Class Initialized
INFO - 2018-02-07 11:02:56 --> Model Class Initialized
INFO - 2018-02-07 11:02:56 --> File loaded: /var/www/html/spamblocker/application/views/index/resetPassword.php
INFO - 2018-02-07 11:02:56 --> Final output sent to browser
DEBUG - 2018-02-07 11:02:56 --> Total execution time: 0.0041
INFO - 2018-02-07 11:02:57 --> Config Class Initialized
INFO - 2018-02-07 11:02:57 --> Hooks Class Initialized
DEBUG - 2018-02-07 11:02:57 --> UTF-8 Support Enabled
INFO - 2018-02-07 11:02:57 --> Utf8 Class Initialized
INFO - 2018-02-07 11:02:57 --> URI Class Initialized
INFO - 2018-02-07 11:02:57 --> Router Class Initialized
INFO - 2018-02-07 11:02:57 --> Output Class Initialized
INFO - 2018-02-07 11:02:57 --> Security Class Initialized
DEBUG - 2018-02-07 11:02:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 11:02:57 --> Input Class Initialized
INFO - 2018-02-07 11:02:57 --> Language Class Initialized
INFO - 2018-02-07 11:02:57 --> Loader Class Initialized
INFO - 2018-02-07 11:02:57 --> Helper loaded: url_helper
INFO - 2018-02-07 11:02:57 --> Helper loaded: file_helper
INFO - 2018-02-07 11:02:57 --> Helper loaded: email_helper
INFO - 2018-02-07 11:02:57 --> Helper loaded: common_helper
INFO - 2018-02-07 11:02:57 --> Database Driver Class Initialized
DEBUG - 2018-02-07 11:02:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 11:02:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 11:02:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-07 11:02:57 --> Pagination Class Initialized
INFO - 2018-02-07 11:02:57 --> Helper loaded: form_helper
INFO - 2018-02-07 11:02:57 --> Form Validation Class Initialized
INFO - 2018-02-07 11:02:57 --> Model Class Initialized
INFO - 2018-02-07 11:02:57 --> Controller Class Initialized
INFO - 2018-02-07 11:02:57 --> Model Class Initialized
INFO - 2018-02-07 11:02:57 --> File loaded: /var/www/html/spamblocker/application/views/index/resetPassword.php
INFO - 2018-02-07 11:02:57 --> Final output sent to browser
DEBUG - 2018-02-07 11:02:57 --> Total execution time: 0.0083
INFO - 2018-02-07 11:02:57 --> Config Class Initialized
INFO - 2018-02-07 11:02:57 --> Hooks Class Initialized
DEBUG - 2018-02-07 11:02:57 --> UTF-8 Support Enabled
INFO - 2018-02-07 11:02:57 --> Utf8 Class Initialized
INFO - 2018-02-07 11:02:57 --> URI Class Initialized
INFO - 2018-02-07 11:02:57 --> Router Class Initialized
INFO - 2018-02-07 11:02:57 --> Output Class Initialized
INFO - 2018-02-07 11:02:57 --> Security Class Initialized
DEBUG - 2018-02-07 11:02:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 11:02:57 --> Input Class Initialized
INFO - 2018-02-07 11:02:57 --> Language Class Initialized
INFO - 2018-02-07 11:02:57 --> Loader Class Initialized
INFO - 2018-02-07 11:02:57 --> Helper loaded: url_helper
INFO - 2018-02-07 11:02:57 --> Helper loaded: file_helper
INFO - 2018-02-07 11:02:57 --> Helper loaded: email_helper
INFO - 2018-02-07 11:02:57 --> Helper loaded: common_helper
INFO - 2018-02-07 11:02:57 --> Database Driver Class Initialized
DEBUG - 2018-02-07 11:02:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 11:02:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 11:02:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-07 11:02:57 --> Pagination Class Initialized
INFO - 2018-02-07 11:02:57 --> Helper loaded: form_helper
INFO - 2018-02-07 11:02:57 --> Form Validation Class Initialized
INFO - 2018-02-07 11:02:57 --> Model Class Initialized
INFO - 2018-02-07 11:02:57 --> Controller Class Initialized
INFO - 2018-02-07 11:02:57 --> Model Class Initialized
INFO - 2018-02-07 11:02:57 --> File loaded: /var/www/html/spamblocker/application/views/index/resetPassword.php
INFO - 2018-02-07 11:02:57 --> Final output sent to browser
DEBUG - 2018-02-07 11:02:57 --> Total execution time: 0.0052
INFO - 2018-02-07 11:02:57 --> Config Class Initialized
INFO - 2018-02-07 11:02:57 --> Hooks Class Initialized
DEBUG - 2018-02-07 11:02:57 --> UTF-8 Support Enabled
INFO - 2018-02-07 11:02:57 --> Utf8 Class Initialized
INFO - 2018-02-07 11:02:57 --> URI Class Initialized
INFO - 2018-02-07 11:02:57 --> Router Class Initialized
INFO - 2018-02-07 11:02:57 --> Output Class Initialized
INFO - 2018-02-07 11:02:57 --> Security Class Initialized
DEBUG - 2018-02-07 11:02:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 11:02:57 --> Input Class Initialized
INFO - 2018-02-07 11:02:57 --> Language Class Initialized
INFO - 2018-02-07 11:02:57 --> Loader Class Initialized
INFO - 2018-02-07 11:02:57 --> Helper loaded: url_helper
INFO - 2018-02-07 11:02:57 --> Helper loaded: file_helper
INFO - 2018-02-07 11:02:57 --> Helper loaded: email_helper
INFO - 2018-02-07 11:02:57 --> Helper loaded: common_helper
INFO - 2018-02-07 11:02:57 --> Database Driver Class Initialized
DEBUG - 2018-02-07 11:02:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 11:02:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 11:02:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-07 11:02:57 --> Pagination Class Initialized
INFO - 2018-02-07 11:02:57 --> Helper loaded: form_helper
INFO - 2018-02-07 11:02:57 --> Form Validation Class Initialized
INFO - 2018-02-07 11:02:57 --> Model Class Initialized
INFO - 2018-02-07 11:02:57 --> Controller Class Initialized
INFO - 2018-02-07 11:02:57 --> Model Class Initialized
INFO - 2018-02-07 11:02:57 --> File loaded: /var/www/html/spamblocker/application/views/index/resetPassword.php
INFO - 2018-02-07 11:02:57 --> Final output sent to browser
DEBUG - 2018-02-07 11:02:57 --> Total execution time: 0.0054
INFO - 2018-02-07 11:02:57 --> Config Class Initialized
INFO - 2018-02-07 11:02:57 --> Hooks Class Initialized
DEBUG - 2018-02-07 11:02:57 --> UTF-8 Support Enabled
INFO - 2018-02-07 11:02:57 --> Utf8 Class Initialized
INFO - 2018-02-07 11:02:57 --> URI Class Initialized
INFO - 2018-02-07 11:02:57 --> Router Class Initialized
INFO - 2018-02-07 11:02:57 --> Output Class Initialized
INFO - 2018-02-07 11:02:57 --> Security Class Initialized
DEBUG - 2018-02-07 11:02:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 11:02:57 --> Input Class Initialized
INFO - 2018-02-07 11:02:57 --> Language Class Initialized
INFO - 2018-02-07 11:02:57 --> Loader Class Initialized
INFO - 2018-02-07 11:02:57 --> Helper loaded: url_helper
INFO - 2018-02-07 11:02:57 --> Helper loaded: file_helper
INFO - 2018-02-07 11:02:57 --> Helper loaded: email_helper
INFO - 2018-02-07 11:02:57 --> Helper loaded: common_helper
INFO - 2018-02-07 11:02:57 --> Database Driver Class Initialized
DEBUG - 2018-02-07 11:02:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 11:02:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 11:02:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-07 11:02:57 --> Pagination Class Initialized
INFO - 2018-02-07 11:02:57 --> Helper loaded: form_helper
INFO - 2018-02-07 11:02:57 --> Form Validation Class Initialized
INFO - 2018-02-07 11:02:57 --> Model Class Initialized
INFO - 2018-02-07 11:02:57 --> Controller Class Initialized
INFO - 2018-02-07 11:02:57 --> Model Class Initialized
INFO - 2018-02-07 11:02:57 --> File loaded: /var/www/html/spamblocker/application/views/index/resetPassword.php
INFO - 2018-02-07 11:02:57 --> Final output sent to browser
DEBUG - 2018-02-07 11:02:57 --> Total execution time: 0.0094
INFO - 2018-02-07 11:02:57 --> Config Class Initialized
INFO - 2018-02-07 11:02:57 --> Hooks Class Initialized
DEBUG - 2018-02-07 11:02:57 --> UTF-8 Support Enabled
INFO - 2018-02-07 11:02:57 --> Utf8 Class Initialized
INFO - 2018-02-07 11:02:57 --> URI Class Initialized
INFO - 2018-02-07 11:02:57 --> Router Class Initialized
INFO - 2018-02-07 11:02:57 --> Output Class Initialized
INFO - 2018-02-07 11:02:57 --> Security Class Initialized
DEBUG - 2018-02-07 11:02:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 11:02:57 --> Input Class Initialized
INFO - 2018-02-07 11:02:57 --> Language Class Initialized
INFO - 2018-02-07 11:02:57 --> Loader Class Initialized
INFO - 2018-02-07 11:02:57 --> Helper loaded: url_helper
INFO - 2018-02-07 11:02:57 --> Helper loaded: file_helper
INFO - 2018-02-07 11:02:57 --> Helper loaded: email_helper
INFO - 2018-02-07 11:02:57 --> Helper loaded: common_helper
INFO - 2018-02-07 11:02:57 --> Database Driver Class Initialized
DEBUG - 2018-02-07 11:02:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 11:02:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 11:02:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-07 11:02:57 --> Pagination Class Initialized
INFO - 2018-02-07 11:02:57 --> Helper loaded: form_helper
INFO - 2018-02-07 11:02:57 --> Form Validation Class Initialized
INFO - 2018-02-07 11:02:57 --> Model Class Initialized
INFO - 2018-02-07 11:02:57 --> Controller Class Initialized
INFO - 2018-02-07 11:02:57 --> Model Class Initialized
INFO - 2018-02-07 11:02:57 --> File loaded: /var/www/html/spamblocker/application/views/index/resetPassword.php
INFO - 2018-02-07 11:02:57 --> Final output sent to browser
DEBUG - 2018-02-07 11:02:57 --> Total execution time: 0.0048
INFO - 2018-02-07 11:02:57 --> Config Class Initialized
INFO - 2018-02-07 11:02:57 --> Hooks Class Initialized
DEBUG - 2018-02-07 11:02:57 --> UTF-8 Support Enabled
INFO - 2018-02-07 11:02:57 --> Utf8 Class Initialized
INFO - 2018-02-07 11:02:57 --> URI Class Initialized
INFO - 2018-02-07 11:02:57 --> Router Class Initialized
INFO - 2018-02-07 11:02:57 --> Output Class Initialized
INFO - 2018-02-07 11:02:57 --> Security Class Initialized
DEBUG - 2018-02-07 11:02:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 11:02:57 --> Input Class Initialized
INFO - 2018-02-07 11:02:57 --> Language Class Initialized
INFO - 2018-02-07 11:02:57 --> Loader Class Initialized
INFO - 2018-02-07 11:02:57 --> Helper loaded: url_helper
INFO - 2018-02-07 11:02:57 --> Helper loaded: file_helper
INFO - 2018-02-07 11:02:57 --> Helper loaded: email_helper
INFO - 2018-02-07 11:02:57 --> Helper loaded: common_helper
INFO - 2018-02-07 11:02:57 --> Database Driver Class Initialized
DEBUG - 2018-02-07 11:02:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 11:02:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 11:02:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-07 11:02:57 --> Pagination Class Initialized
INFO - 2018-02-07 11:02:57 --> Helper loaded: form_helper
INFO - 2018-02-07 11:02:57 --> Form Validation Class Initialized
INFO - 2018-02-07 11:02:57 --> Model Class Initialized
INFO - 2018-02-07 11:02:57 --> Controller Class Initialized
INFO - 2018-02-07 11:02:57 --> Model Class Initialized
INFO - 2018-02-07 11:02:57 --> File loaded: /var/www/html/spamblocker/application/views/index/resetPassword.php
INFO - 2018-02-07 11:02:57 --> Final output sent to browser
DEBUG - 2018-02-07 11:02:57 --> Total execution time: 0.0035
INFO - 2018-02-07 11:03:23 --> Config Class Initialized
INFO - 2018-02-07 11:03:23 --> Hooks Class Initialized
DEBUG - 2018-02-07 11:03:23 --> UTF-8 Support Enabled
INFO - 2018-02-07 11:03:23 --> Utf8 Class Initialized
INFO - 2018-02-07 11:03:23 --> URI Class Initialized
INFO - 2018-02-07 11:03:23 --> Router Class Initialized
INFO - 2018-02-07 11:03:23 --> Output Class Initialized
INFO - 2018-02-07 11:03:23 --> Security Class Initialized
DEBUG - 2018-02-07 11:03:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 11:03:23 --> Input Class Initialized
INFO - 2018-02-07 11:03:23 --> Language Class Initialized
INFO - 2018-02-07 11:03:23 --> Loader Class Initialized
INFO - 2018-02-07 11:03:23 --> Helper loaded: url_helper
INFO - 2018-02-07 11:03:23 --> Helper loaded: file_helper
INFO - 2018-02-07 11:03:23 --> Helper loaded: email_helper
INFO - 2018-02-07 11:03:23 --> Helper loaded: common_helper
INFO - 2018-02-07 11:03:23 --> Database Driver Class Initialized
DEBUG - 2018-02-07 11:03:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 11:03:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 11:03:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-07 11:03:23 --> Pagination Class Initialized
INFO - 2018-02-07 11:03:23 --> Helper loaded: form_helper
INFO - 2018-02-07 11:03:23 --> Form Validation Class Initialized
INFO - 2018-02-07 11:03:23 --> Model Class Initialized
INFO - 2018-02-07 11:03:23 --> Controller Class Initialized
INFO - 2018-02-07 11:03:23 --> Model Class Initialized
INFO - 2018-02-07 11:03:23 --> File loaded: /var/www/html/spamblocker/application/views/index/resetPassword.php
INFO - 2018-02-07 11:03:23 --> Final output sent to browser
DEBUG - 2018-02-07 11:03:23 --> Total execution time: 0.0109
INFO - 2018-02-07 11:04:28 --> Config Class Initialized
INFO - 2018-02-07 11:04:28 --> Hooks Class Initialized
DEBUG - 2018-02-07 11:04:28 --> UTF-8 Support Enabled
INFO - 2018-02-07 11:04:28 --> Utf8 Class Initialized
INFO - 2018-02-07 11:04:28 --> URI Class Initialized
INFO - 2018-02-07 11:04:28 --> Router Class Initialized
INFO - 2018-02-07 11:04:28 --> Output Class Initialized
INFO - 2018-02-07 11:04:28 --> Security Class Initialized
DEBUG - 2018-02-07 11:04:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 11:04:28 --> Input Class Initialized
INFO - 2018-02-07 11:04:28 --> Language Class Initialized
INFO - 2018-02-07 11:04:28 --> Loader Class Initialized
INFO - 2018-02-07 11:04:28 --> Helper loaded: url_helper
INFO - 2018-02-07 11:04:28 --> Helper loaded: file_helper
INFO - 2018-02-07 11:04:28 --> Helper loaded: email_helper
INFO - 2018-02-07 11:04:28 --> Helper loaded: common_helper
INFO - 2018-02-07 11:04:28 --> Database Driver Class Initialized
DEBUG - 2018-02-07 11:04:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 11:04:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 11:04:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-07 11:04:28 --> Pagination Class Initialized
INFO - 2018-02-07 11:04:28 --> Helper loaded: form_helper
INFO - 2018-02-07 11:04:28 --> Form Validation Class Initialized
INFO - 2018-02-07 11:04:28 --> Model Class Initialized
INFO - 2018-02-07 11:04:28 --> Controller Class Initialized
INFO - 2018-02-07 11:04:28 --> Model Class Initialized
INFO - 2018-02-07 11:04:28 --> File loaded: /var/www/html/spamblocker/application/views/index/resetPassword.php
INFO - 2018-02-07 11:04:28 --> Final output sent to browser
DEBUG - 2018-02-07 11:04:28 --> Total execution time: 0.0063
INFO - 2018-02-07 11:06:28 --> Config Class Initialized
INFO - 2018-02-07 11:06:28 --> Hooks Class Initialized
DEBUG - 2018-02-07 11:06:28 --> UTF-8 Support Enabled
INFO - 2018-02-07 11:06:28 --> Utf8 Class Initialized
INFO - 2018-02-07 11:06:28 --> URI Class Initialized
INFO - 2018-02-07 11:06:28 --> Router Class Initialized
INFO - 2018-02-07 11:06:28 --> Output Class Initialized
INFO - 2018-02-07 11:06:28 --> Security Class Initialized
DEBUG - 2018-02-07 11:06:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 11:06:28 --> Input Class Initialized
INFO - 2018-02-07 11:06:28 --> Language Class Initialized
INFO - 2018-02-07 11:06:28 --> Loader Class Initialized
INFO - 2018-02-07 11:06:28 --> Helper loaded: url_helper
INFO - 2018-02-07 11:06:28 --> Helper loaded: file_helper
INFO - 2018-02-07 11:06:28 --> Helper loaded: email_helper
INFO - 2018-02-07 11:06:28 --> Helper loaded: common_helper
INFO - 2018-02-07 11:06:28 --> Database Driver Class Initialized
DEBUG - 2018-02-07 11:06:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 11:06:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 11:06:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-07 11:06:28 --> Pagination Class Initialized
INFO - 2018-02-07 11:06:28 --> Helper loaded: form_helper
INFO - 2018-02-07 11:06:28 --> Form Validation Class Initialized
INFO - 2018-02-07 11:06:28 --> Model Class Initialized
INFO - 2018-02-07 11:06:28 --> Controller Class Initialized
DEBUG - 2018-02-07 11:06:28 --> Config file loaded: /var/www/html/spamblocker/application/config/rest.php
INFO - 2018-02-07 11:06:28 --> Helper loaded: inflector_helper
INFO - 2018-02-07 11:06:28 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 11:06:28 --> Model Class Initialized
INFO - 2018-02-07 11:06:28 --> Model Class Initialized
INFO - 2018-02-07 11:06:28 --> Final output sent to browser
DEBUG - 2018-02-07 11:06:28 --> Total execution time: 0.0836
INFO - 2018-02-07 11:06:41 --> Config Class Initialized
INFO - 2018-02-07 11:06:41 --> Hooks Class Initialized
DEBUG - 2018-02-07 11:06:41 --> UTF-8 Support Enabled
INFO - 2018-02-07 11:06:41 --> Utf8 Class Initialized
INFO - 2018-02-07 11:06:41 --> URI Class Initialized
INFO - 2018-02-07 11:06:41 --> Router Class Initialized
INFO - 2018-02-07 11:06:41 --> Output Class Initialized
INFO - 2018-02-07 11:06:41 --> Security Class Initialized
DEBUG - 2018-02-07 11:06:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 11:06:41 --> Input Class Initialized
INFO - 2018-02-07 11:06:41 --> Language Class Initialized
INFO - 2018-02-07 11:06:41 --> Loader Class Initialized
INFO - 2018-02-07 11:06:41 --> Helper loaded: url_helper
INFO - 2018-02-07 11:06:41 --> Helper loaded: file_helper
INFO - 2018-02-07 11:06:41 --> Helper loaded: email_helper
INFO - 2018-02-07 11:06:41 --> Helper loaded: common_helper
INFO - 2018-02-07 11:06:41 --> Database Driver Class Initialized
DEBUG - 2018-02-07 11:06:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 11:06:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 11:06:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-07 11:06:41 --> Pagination Class Initialized
INFO - 2018-02-07 11:06:41 --> Helper loaded: form_helper
INFO - 2018-02-07 11:06:41 --> Form Validation Class Initialized
INFO - 2018-02-07 11:06:41 --> Model Class Initialized
INFO - 2018-02-07 11:06:41 --> Controller Class Initialized
DEBUG - 2018-02-07 11:06:41 --> Config file loaded: /var/www/html/spamblocker/application/config/rest.php
INFO - 2018-02-07 11:06:41 --> Helper loaded: inflector_helper
INFO - 2018-02-07 11:06:41 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 11:06:41 --> Model Class Initialized
INFO - 2018-02-07 11:06:41 --> Model Class Initialized
INFO - 2018-02-07 11:06:41 --> Final output sent to browser
DEBUG - 2018-02-07 11:06:41 --> Total execution time: 0.0076
INFO - 2018-02-07 11:06:50 --> Config Class Initialized
INFO - 2018-02-07 11:06:50 --> Hooks Class Initialized
DEBUG - 2018-02-07 11:06:50 --> UTF-8 Support Enabled
INFO - 2018-02-07 11:06:50 --> Utf8 Class Initialized
INFO - 2018-02-07 11:06:50 --> URI Class Initialized
INFO - 2018-02-07 11:06:50 --> Router Class Initialized
INFO - 2018-02-07 11:06:50 --> Output Class Initialized
INFO - 2018-02-07 11:06:50 --> Security Class Initialized
DEBUG - 2018-02-07 11:06:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 11:06:50 --> Input Class Initialized
INFO - 2018-02-07 11:06:50 --> Language Class Initialized
INFO - 2018-02-07 11:06:50 --> Loader Class Initialized
INFO - 2018-02-07 11:06:50 --> Helper loaded: url_helper
INFO - 2018-02-07 11:06:50 --> Helper loaded: file_helper
INFO - 2018-02-07 11:06:50 --> Helper loaded: email_helper
INFO - 2018-02-07 11:06:50 --> Helper loaded: common_helper
INFO - 2018-02-07 11:06:50 --> Database Driver Class Initialized
DEBUG - 2018-02-07 11:06:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 11:06:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 11:06:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-07 11:06:50 --> Pagination Class Initialized
INFO - 2018-02-07 11:06:50 --> Helper loaded: form_helper
INFO - 2018-02-07 11:06:50 --> Form Validation Class Initialized
INFO - 2018-02-07 11:06:50 --> Model Class Initialized
INFO - 2018-02-07 11:06:50 --> Controller Class Initialized
DEBUG - 2018-02-07 11:06:50 --> Config file loaded: /var/www/html/spamblocker/application/config/rest.php
INFO - 2018-02-07 11:06:50 --> Helper loaded: inflector_helper
INFO - 2018-02-07 11:06:50 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 11:06:50 --> Model Class Initialized
INFO - 2018-02-07 11:06:50 --> Model Class Initialized
INFO - 2018-02-07 11:06:50 --> Final output sent to browser
DEBUG - 2018-02-07 11:06:50 --> Total execution time: 0.0045
INFO - 2018-02-07 11:07:07 --> Config Class Initialized
INFO - 2018-02-07 11:07:07 --> Hooks Class Initialized
DEBUG - 2018-02-07 11:07:07 --> UTF-8 Support Enabled
INFO - 2018-02-07 11:07:07 --> Utf8 Class Initialized
INFO - 2018-02-07 11:07:07 --> URI Class Initialized
INFO - 2018-02-07 11:07:07 --> Router Class Initialized
INFO - 2018-02-07 11:07:07 --> Output Class Initialized
INFO - 2018-02-07 11:07:07 --> Security Class Initialized
DEBUG - 2018-02-07 11:07:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 11:07:07 --> Input Class Initialized
INFO - 2018-02-07 11:07:07 --> Language Class Initialized
INFO - 2018-02-07 11:07:07 --> Loader Class Initialized
INFO - 2018-02-07 11:07:07 --> Helper loaded: url_helper
INFO - 2018-02-07 11:07:07 --> Helper loaded: file_helper
INFO - 2018-02-07 11:07:07 --> Helper loaded: email_helper
INFO - 2018-02-07 11:07:07 --> Helper loaded: common_helper
INFO - 2018-02-07 11:07:07 --> Database Driver Class Initialized
DEBUG - 2018-02-07 11:07:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 11:07:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 11:07:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-07 11:07:07 --> Pagination Class Initialized
INFO - 2018-02-07 11:07:07 --> Helper loaded: form_helper
INFO - 2018-02-07 11:07:07 --> Form Validation Class Initialized
INFO - 2018-02-07 11:07:07 --> Model Class Initialized
INFO - 2018-02-07 11:07:07 --> Controller Class Initialized
DEBUG - 2018-02-07 11:07:07 --> Config file loaded: /var/www/html/spamblocker/application/config/rest.php
INFO - 2018-02-07 11:07:07 --> Helper loaded: inflector_helper
INFO - 2018-02-07 11:07:07 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 11:07:07 --> Model Class Initialized
INFO - 2018-02-07 11:07:07 --> Model Class Initialized
INFO - 2018-02-07 11:07:07 --> Email Class Initialized
INFO - 2018-02-07 11:07:08 --> Language file loaded: language/english/email_lang.php
INFO - 2018-02-07 11:07:12 --> Final output sent to browser
DEBUG - 2018-02-07 11:07:12 --> Total execution time: 4.6400
INFO - 2018-02-07 11:07:33 --> Config Class Initialized
INFO - 2018-02-07 11:07:33 --> Hooks Class Initialized
DEBUG - 2018-02-07 11:07:33 --> UTF-8 Support Enabled
INFO - 2018-02-07 11:07:33 --> Utf8 Class Initialized
INFO - 2018-02-07 11:07:33 --> URI Class Initialized
INFO - 2018-02-07 11:07:33 --> Router Class Initialized
INFO - 2018-02-07 11:07:33 --> Output Class Initialized
INFO - 2018-02-07 11:07:33 --> Security Class Initialized
DEBUG - 2018-02-07 11:07:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 11:07:33 --> Input Class Initialized
INFO - 2018-02-07 11:07:33 --> Language Class Initialized
INFO - 2018-02-07 11:07:33 --> Loader Class Initialized
INFO - 2018-02-07 11:07:33 --> Helper loaded: url_helper
INFO - 2018-02-07 11:07:33 --> Helper loaded: file_helper
INFO - 2018-02-07 11:07:33 --> Helper loaded: email_helper
INFO - 2018-02-07 11:07:33 --> Helper loaded: common_helper
INFO - 2018-02-07 11:07:33 --> Database Driver Class Initialized
DEBUG - 2018-02-07 11:07:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 11:07:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 11:07:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-07 11:07:33 --> Pagination Class Initialized
INFO - 2018-02-07 11:07:33 --> Helper loaded: form_helper
INFO - 2018-02-07 11:07:33 --> Form Validation Class Initialized
INFO - 2018-02-07 11:07:33 --> Model Class Initialized
INFO - 2018-02-07 11:07:33 --> Controller Class Initialized
INFO - 2018-02-07 11:07:33 --> Model Class Initialized
INFO - 2018-02-07 11:07:33 --> File loaded: /var/www/html/spamblocker/application/views/index/resetPassword.php
INFO - 2018-02-07 11:07:33 --> Final output sent to browser
DEBUG - 2018-02-07 11:07:33 --> Total execution time: 0.0053
INFO - 2018-02-07 11:31:49 --> Config Class Initialized
INFO - 2018-02-07 11:31:49 --> Hooks Class Initialized
DEBUG - 2018-02-07 11:31:49 --> UTF-8 Support Enabled
INFO - 2018-02-07 11:31:49 --> Utf8 Class Initialized
INFO - 2018-02-07 11:31:49 --> URI Class Initialized
INFO - 2018-02-07 11:31:49 --> Router Class Initialized
INFO - 2018-02-07 11:31:49 --> Output Class Initialized
INFO - 2018-02-07 11:31:49 --> Security Class Initialized
DEBUG - 2018-02-07 11:31:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 11:31:49 --> Input Class Initialized
INFO - 2018-02-07 11:31:49 --> Language Class Initialized
INFO - 2018-02-07 11:31:49 --> Loader Class Initialized
INFO - 2018-02-07 11:31:49 --> Helper loaded: url_helper
INFO - 2018-02-07 11:31:49 --> Helper loaded: file_helper
INFO - 2018-02-07 11:31:49 --> Helper loaded: email_helper
INFO - 2018-02-07 11:31:49 --> Helper loaded: common_helper
INFO - 2018-02-07 11:31:49 --> Database Driver Class Initialized
DEBUG - 2018-02-07 11:31:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 11:31:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 11:31:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-07 11:31:49 --> Pagination Class Initialized
INFO - 2018-02-07 11:31:49 --> Helper loaded: form_helper
INFO - 2018-02-07 11:31:49 --> Form Validation Class Initialized
INFO - 2018-02-07 11:31:49 --> Model Class Initialized
INFO - 2018-02-07 11:31:49 --> Controller Class Initialized
DEBUG - 2018-02-07 11:31:49 --> Config file loaded: /var/www/html/spamblocker/application/config/rest.php
INFO - 2018-02-07 11:31:49 --> Helper loaded: inflector_helper
INFO - 2018-02-07 11:31:49 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 11:31:49 --> Model Class Initialized
INFO - 2018-02-07 11:31:49 --> Model Class Initialized
ERROR - 2018-02-07 11:31:49 --> Severity: Notice --> Undefined variable: CI /var/www/html/spamblocker/application/helpers/common_helper.php 203
ERROR - 2018-02-07 11:31:49 --> Severity: Notice --> Trying to get property of non-object /var/www/html/spamblocker/application/helpers/common_helper.php 203
ERROR - 2018-02-07 11:31:49 --> Severity: error --> Exception: Call to a member function model() on null /var/www/html/spamblocker/application/helpers/common_helper.php 203
INFO - 2018-02-07 11:32:04 --> Config Class Initialized
INFO - 2018-02-07 11:32:04 --> Hooks Class Initialized
DEBUG - 2018-02-07 11:32:04 --> UTF-8 Support Enabled
INFO - 2018-02-07 11:32:04 --> Utf8 Class Initialized
INFO - 2018-02-07 11:32:04 --> URI Class Initialized
INFO - 2018-02-07 11:32:04 --> Router Class Initialized
INFO - 2018-02-07 11:32:04 --> Output Class Initialized
INFO - 2018-02-07 11:32:04 --> Security Class Initialized
DEBUG - 2018-02-07 11:32:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 11:32:04 --> Input Class Initialized
INFO - 2018-02-07 11:32:04 --> Language Class Initialized
INFO - 2018-02-07 11:32:04 --> Loader Class Initialized
INFO - 2018-02-07 11:32:04 --> Helper loaded: url_helper
INFO - 2018-02-07 11:32:04 --> Helper loaded: file_helper
INFO - 2018-02-07 11:32:04 --> Helper loaded: email_helper
INFO - 2018-02-07 11:32:04 --> Helper loaded: common_helper
INFO - 2018-02-07 11:32:04 --> Database Driver Class Initialized
DEBUG - 2018-02-07 11:32:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 11:32:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 11:32:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-07 11:32:04 --> Pagination Class Initialized
INFO - 2018-02-07 11:32:04 --> Helper loaded: form_helper
INFO - 2018-02-07 11:32:04 --> Form Validation Class Initialized
INFO - 2018-02-07 11:32:04 --> Model Class Initialized
INFO - 2018-02-07 11:32:04 --> Controller Class Initialized
DEBUG - 2018-02-07 11:32:04 --> Config file loaded: /var/www/html/spamblocker/application/config/rest.php
INFO - 2018-02-07 11:32:04 --> Helper loaded: inflector_helper
INFO - 2018-02-07 11:32:04 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 11:32:04 --> Model Class Initialized
INFO - 2018-02-07 11:32:04 --> Model Class Initialized
INFO - 2018-02-07 11:32:04 --> Model Class Initialized
INFO - 2018-02-07 11:32:04 --> Email Class Initialized
INFO - 2018-02-07 11:32:04 --> Language file loaded: language/english/email_lang.php
INFO - 2018-02-07 11:32:07 --> Final output sent to browser
DEBUG - 2018-02-07 11:32:07 --> Total execution time: 3.5751
INFO - 2018-02-07 11:32:27 --> Config Class Initialized
INFO - 2018-02-07 11:32:27 --> Hooks Class Initialized
DEBUG - 2018-02-07 11:32:27 --> UTF-8 Support Enabled
INFO - 2018-02-07 11:32:27 --> Utf8 Class Initialized
INFO - 2018-02-07 11:32:27 --> URI Class Initialized
INFO - 2018-02-07 11:32:27 --> Router Class Initialized
INFO - 2018-02-07 11:32:27 --> Output Class Initialized
INFO - 2018-02-07 11:32:27 --> Security Class Initialized
DEBUG - 2018-02-07 11:32:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 11:32:27 --> Input Class Initialized
INFO - 2018-02-07 11:32:27 --> Language Class Initialized
INFO - 2018-02-07 11:32:27 --> Loader Class Initialized
INFO - 2018-02-07 11:32:27 --> Helper loaded: url_helper
INFO - 2018-02-07 11:32:27 --> Helper loaded: file_helper
INFO - 2018-02-07 11:32:27 --> Helper loaded: email_helper
INFO - 2018-02-07 11:32:27 --> Helper loaded: common_helper
INFO - 2018-02-07 11:32:27 --> Database Driver Class Initialized
DEBUG - 2018-02-07 11:32:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 11:32:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 11:32:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-07 11:32:27 --> Pagination Class Initialized
INFO - 2018-02-07 11:32:27 --> Helper loaded: form_helper
INFO - 2018-02-07 11:32:27 --> Form Validation Class Initialized
INFO - 2018-02-07 11:32:27 --> Model Class Initialized
INFO - 2018-02-07 11:32:27 --> Controller Class Initialized
INFO - 2018-02-07 11:32:27 --> Model Class Initialized
INFO - 2018-02-07 11:32:27 --> File loaded: /var/www/html/spamblocker/application/views/index/resetPassword.php
INFO - 2018-02-07 11:32:27 --> Final output sent to browser
DEBUG - 2018-02-07 11:32:27 --> Total execution time: 0.0045
INFO - 2018-02-07 11:32:29 --> Config Class Initialized
INFO - 2018-02-07 11:32:29 --> Hooks Class Initialized
DEBUG - 2018-02-07 11:32:29 --> UTF-8 Support Enabled
INFO - 2018-02-07 11:32:29 --> Utf8 Class Initialized
INFO - 2018-02-07 11:32:29 --> URI Class Initialized
INFO - 2018-02-07 11:32:29 --> Router Class Initialized
INFO - 2018-02-07 11:32:29 --> Output Class Initialized
INFO - 2018-02-07 11:32:29 --> Security Class Initialized
DEBUG - 2018-02-07 11:32:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 11:32:29 --> Input Class Initialized
INFO - 2018-02-07 11:32:29 --> Language Class Initialized
INFO - 2018-02-07 11:32:29 --> Loader Class Initialized
INFO - 2018-02-07 11:32:29 --> Helper loaded: url_helper
INFO - 2018-02-07 11:32:29 --> Helper loaded: file_helper
INFO - 2018-02-07 11:32:29 --> Helper loaded: email_helper
INFO - 2018-02-07 11:32:29 --> Helper loaded: common_helper
INFO - 2018-02-07 11:32:29 --> Database Driver Class Initialized
DEBUG - 2018-02-07 11:32:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 11:32:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 11:32:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-07 11:32:29 --> Pagination Class Initialized
INFO - 2018-02-07 11:32:29 --> Helper loaded: form_helper
INFO - 2018-02-07 11:32:29 --> Form Validation Class Initialized
INFO - 2018-02-07 11:32:29 --> Model Class Initialized
INFO - 2018-02-07 11:32:29 --> Controller Class Initialized
INFO - 2018-02-07 11:32:29 --> Model Class Initialized
INFO - 2018-02-07 11:32:29 --> File loaded: /var/www/html/spamblocker/application/views/index/resetPassword.php
INFO - 2018-02-07 11:32:29 --> Final output sent to browser
DEBUG - 2018-02-07 11:32:29 --> Total execution time: 0.0047
INFO - 2018-02-07 11:34:41 --> Config Class Initialized
INFO - 2018-02-07 11:34:41 --> Hooks Class Initialized
DEBUG - 2018-02-07 11:34:41 --> UTF-8 Support Enabled
INFO - 2018-02-07 11:34:41 --> Utf8 Class Initialized
INFO - 2018-02-07 11:34:41 --> URI Class Initialized
INFO - 2018-02-07 11:34:41 --> Router Class Initialized
INFO - 2018-02-07 11:34:41 --> Output Class Initialized
INFO - 2018-02-07 11:34:41 --> Security Class Initialized
DEBUG - 2018-02-07 11:34:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 11:34:41 --> Input Class Initialized
INFO - 2018-02-07 11:34:41 --> Language Class Initialized
INFO - 2018-02-07 11:34:41 --> Loader Class Initialized
INFO - 2018-02-07 11:34:41 --> Helper loaded: url_helper
INFO - 2018-02-07 11:34:41 --> Helper loaded: file_helper
INFO - 2018-02-07 11:34:41 --> Helper loaded: email_helper
INFO - 2018-02-07 11:34:41 --> Helper loaded: common_helper
INFO - 2018-02-07 11:34:41 --> Database Driver Class Initialized
DEBUG - 2018-02-07 11:34:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 11:34:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 11:34:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-07 11:34:41 --> Pagination Class Initialized
INFO - 2018-02-07 11:34:41 --> Helper loaded: form_helper
INFO - 2018-02-07 11:34:41 --> Form Validation Class Initialized
INFO - 2018-02-07 11:34:41 --> Model Class Initialized
INFO - 2018-02-07 11:34:41 --> Controller Class Initialized
DEBUG - 2018-02-07 11:34:41 --> Config file loaded: /var/www/html/spamblocker/application/config/rest.php
INFO - 2018-02-07 11:34:41 --> Helper loaded: inflector_helper
INFO - 2018-02-07 11:34:41 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 11:34:41 --> Model Class Initialized
INFO - 2018-02-07 11:34:41 --> Model Class Initialized
INFO - 2018-02-07 11:34:41 --> Model Class Initialized
INFO - 2018-02-07 11:34:41 --> Email Class Initialized
INFO - 2018-02-07 11:34:47 --> Language file loaded: language/english/email_lang.php
INFO - 2018-02-07 11:34:50 --> Final output sent to browser
DEBUG - 2018-02-07 11:34:50 --> Total execution time: 8.5198
INFO - 2018-02-07 12:09:25 --> Config Class Initialized
INFO - 2018-02-07 12:09:25 --> Hooks Class Initialized
DEBUG - 2018-02-07 12:09:25 --> UTF-8 Support Enabled
INFO - 2018-02-07 12:09:25 --> Utf8 Class Initialized
INFO - 2018-02-07 12:09:25 --> URI Class Initialized
INFO - 2018-02-07 12:09:25 --> Router Class Initialized
INFO - 2018-02-07 12:09:25 --> Output Class Initialized
INFO - 2018-02-07 12:09:25 --> Security Class Initialized
DEBUG - 2018-02-07 12:09:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 12:09:25 --> Input Class Initialized
INFO - 2018-02-07 12:09:25 --> Language Class Initialized
INFO - 2018-02-07 12:09:25 --> Loader Class Initialized
INFO - 2018-02-07 12:09:25 --> Helper loaded: url_helper
INFO - 2018-02-07 12:09:25 --> Helper loaded: file_helper
INFO - 2018-02-07 12:09:25 --> Helper loaded: email_helper
INFO - 2018-02-07 12:09:25 --> Helper loaded: common_helper
INFO - 2018-02-07 12:09:25 --> Database Driver Class Initialized
DEBUG - 2018-02-07 12:09:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 12:09:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 12:09:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-07 12:09:25 --> Pagination Class Initialized
INFO - 2018-02-07 12:09:25 --> Helper loaded: form_helper
INFO - 2018-02-07 12:09:25 --> Form Validation Class Initialized
INFO - 2018-02-07 12:09:25 --> Model Class Initialized
INFO - 2018-02-07 12:09:25 --> Controller Class Initialized
DEBUG - 2018-02-07 12:09:25 --> Config file loaded: /var/www/html/spamblocker/application/config/rest.php
INFO - 2018-02-07 12:09:25 --> Helper loaded: inflector_helper
INFO - 2018-02-07 12:09:25 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 12:09:25 --> Model Class Initialized
INFO - 2018-02-07 12:09:25 --> Model Class Initialized
INFO - 2018-02-07 12:09:25 --> Model Class Initialized
INFO - 2018-02-07 12:09:25 --> Email Class Initialized
INFO - 2018-02-07 12:09:31 --> Language file loaded: language/english/email_lang.php
INFO - 2018-02-07 12:09:35 --> Final output sent to browser
DEBUG - 2018-02-07 12:09:35 --> Total execution time: 9.2569
INFO - 2018-02-07 12:09:40 --> Config Class Initialized
INFO - 2018-02-07 12:09:40 --> Hooks Class Initialized
DEBUG - 2018-02-07 12:09:40 --> UTF-8 Support Enabled
INFO - 2018-02-07 12:09:40 --> Utf8 Class Initialized
INFO - 2018-02-07 12:09:40 --> URI Class Initialized
INFO - 2018-02-07 12:09:40 --> Router Class Initialized
INFO - 2018-02-07 12:09:40 --> Output Class Initialized
INFO - 2018-02-07 12:09:40 --> Security Class Initialized
DEBUG - 2018-02-07 12:09:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 12:09:40 --> Input Class Initialized
INFO - 2018-02-07 12:09:40 --> Language Class Initialized
INFO - 2018-02-07 12:09:40 --> Loader Class Initialized
INFO - 2018-02-07 12:09:40 --> Helper loaded: url_helper
INFO - 2018-02-07 12:09:40 --> Helper loaded: file_helper
INFO - 2018-02-07 12:09:40 --> Helper loaded: email_helper
INFO - 2018-02-07 12:09:40 --> Helper loaded: common_helper
INFO - 2018-02-07 12:09:40 --> Database Driver Class Initialized
DEBUG - 2018-02-07 12:09:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 12:09:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 12:09:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-07 12:09:40 --> Pagination Class Initialized
INFO - 2018-02-07 12:09:40 --> Helper loaded: form_helper
INFO - 2018-02-07 12:09:40 --> Form Validation Class Initialized
INFO - 2018-02-07 12:09:40 --> Model Class Initialized
INFO - 2018-02-07 12:09:40 --> Controller Class Initialized
DEBUG - 2018-02-07 12:09:40 --> Config file loaded: /var/www/html/spamblocker/application/config/rest.php
INFO - 2018-02-07 12:09:40 --> Helper loaded: inflector_helper
INFO - 2018-02-07 12:09:40 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 12:09:40 --> Model Class Initialized
INFO - 2018-02-07 12:09:40 --> Model Class Initialized
INFO - 2018-02-07 12:09:40 --> Model Class Initialized
INFO - 2018-02-07 12:09:40 --> Email Class Initialized
INFO - 2018-02-07 12:09:41 --> Language file loaded: language/english/email_lang.php
INFO - 2018-02-07 12:09:44 --> Final output sent to browser
DEBUG - 2018-02-07 12:09:44 --> Total execution time: 3.5273
INFO - 2018-02-07 12:14:19 --> Config Class Initialized
INFO - 2018-02-07 12:14:19 --> Hooks Class Initialized
DEBUG - 2018-02-07 12:14:19 --> UTF-8 Support Enabled
INFO - 2018-02-07 12:14:19 --> Utf8 Class Initialized
INFO - 2018-02-07 12:14:19 --> URI Class Initialized
INFO - 2018-02-07 12:14:19 --> Router Class Initialized
INFO - 2018-02-07 12:14:19 --> Output Class Initialized
INFO - 2018-02-07 12:14:19 --> Security Class Initialized
DEBUG - 2018-02-07 12:14:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 12:14:19 --> Input Class Initialized
INFO - 2018-02-07 12:14:19 --> Language Class Initialized
INFO - 2018-02-07 12:14:19 --> Loader Class Initialized
INFO - 2018-02-07 12:14:19 --> Helper loaded: url_helper
INFO - 2018-02-07 12:14:19 --> Helper loaded: file_helper
INFO - 2018-02-07 12:14:19 --> Helper loaded: email_helper
INFO - 2018-02-07 12:14:19 --> Helper loaded: common_helper
INFO - 2018-02-07 12:14:19 --> Database Driver Class Initialized
DEBUG - 2018-02-07 12:14:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 12:14:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 12:14:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-07 12:14:19 --> Pagination Class Initialized
INFO - 2018-02-07 12:14:19 --> Helper loaded: form_helper
INFO - 2018-02-07 12:14:19 --> Form Validation Class Initialized
INFO - 2018-02-07 12:14:19 --> Model Class Initialized
INFO - 2018-02-07 12:14:19 --> Controller Class Initialized
DEBUG - 2018-02-07 12:14:19 --> Config file loaded: /var/www/html/spamblocker/application/config/rest.php
INFO - 2018-02-07 12:14:19 --> Helper loaded: inflector_helper
INFO - 2018-02-07 12:14:19 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 12:14:19 --> Model Class Initialized
INFO - 2018-02-07 12:14:19 --> Model Class Initialized
INFO - 2018-02-07 12:14:19 --> Model Class Initialized
INFO - 2018-02-07 12:14:19 --> Email Class Initialized
INFO - 2018-02-07 12:14:19 --> Language file loaded: language/english/email_lang.php
INFO - 2018-02-07 12:14:22 --> Final output sent to browser
DEBUG - 2018-02-07 12:14:22 --> Total execution time: 3.5017
INFO - 2018-02-07 12:14:27 --> Config Class Initialized
INFO - 2018-02-07 12:14:27 --> Hooks Class Initialized
DEBUG - 2018-02-07 12:14:27 --> UTF-8 Support Enabled
INFO - 2018-02-07 12:14:27 --> Utf8 Class Initialized
INFO - 2018-02-07 12:14:27 --> URI Class Initialized
INFO - 2018-02-07 12:14:27 --> Router Class Initialized
INFO - 2018-02-07 12:14:27 --> Output Class Initialized
INFO - 2018-02-07 12:14:27 --> Security Class Initialized
DEBUG - 2018-02-07 12:14:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 12:14:27 --> Input Class Initialized
INFO - 2018-02-07 12:14:27 --> Language Class Initialized
INFO - 2018-02-07 12:14:27 --> Loader Class Initialized
INFO - 2018-02-07 12:14:27 --> Helper loaded: url_helper
INFO - 2018-02-07 12:14:27 --> Helper loaded: file_helper
INFO - 2018-02-07 12:14:27 --> Helper loaded: email_helper
INFO - 2018-02-07 12:14:27 --> Helper loaded: common_helper
INFO - 2018-02-07 12:14:27 --> Database Driver Class Initialized
DEBUG - 2018-02-07 12:14:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 12:14:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 12:14:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-07 12:14:27 --> Pagination Class Initialized
INFO - 2018-02-07 12:14:27 --> Helper loaded: form_helper
INFO - 2018-02-07 12:14:27 --> Form Validation Class Initialized
INFO - 2018-02-07 12:14:27 --> Model Class Initialized
INFO - 2018-02-07 12:14:27 --> Controller Class Initialized
DEBUG - 2018-02-07 12:14:27 --> Config file loaded: /var/www/html/spamblocker/application/config/rest.php
INFO - 2018-02-07 12:14:27 --> Helper loaded: inflector_helper
INFO - 2018-02-07 12:14:27 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 12:14:27 --> Model Class Initialized
INFO - 2018-02-07 12:14:27 --> Model Class Initialized
INFO - 2018-02-07 12:14:27 --> Model Class Initialized
INFO - 2018-02-07 12:14:27 --> Email Class Initialized
INFO - 2018-02-07 12:14:27 --> Language file loaded: language/english/email_lang.php
INFO - 2018-02-07 12:14:30 --> Final output sent to browser
DEBUG - 2018-02-07 12:14:30 --> Total execution time: 3.6681
INFO - 2018-02-07 12:14:46 --> Config Class Initialized
INFO - 2018-02-07 12:14:46 --> Hooks Class Initialized
DEBUG - 2018-02-07 12:14:46 --> UTF-8 Support Enabled
INFO - 2018-02-07 12:14:46 --> Utf8 Class Initialized
INFO - 2018-02-07 12:14:46 --> URI Class Initialized
INFO - 2018-02-07 12:14:46 --> Router Class Initialized
INFO - 2018-02-07 12:14:46 --> Output Class Initialized
INFO - 2018-02-07 12:14:46 --> Security Class Initialized
DEBUG - 2018-02-07 12:14:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 12:14:46 --> Input Class Initialized
INFO - 2018-02-07 12:14:46 --> Language Class Initialized
INFO - 2018-02-07 12:14:46 --> Loader Class Initialized
INFO - 2018-02-07 12:14:46 --> Helper loaded: url_helper
INFO - 2018-02-07 12:14:46 --> Helper loaded: file_helper
INFO - 2018-02-07 12:14:46 --> Helper loaded: email_helper
INFO - 2018-02-07 12:14:46 --> Helper loaded: common_helper
INFO - 2018-02-07 12:14:46 --> Database Driver Class Initialized
DEBUG - 2018-02-07 12:14:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 12:14:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 12:14:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-07 12:14:46 --> Pagination Class Initialized
INFO - 2018-02-07 12:14:46 --> Helper loaded: form_helper
INFO - 2018-02-07 12:14:46 --> Form Validation Class Initialized
INFO - 2018-02-07 12:14:46 --> Model Class Initialized
INFO - 2018-02-07 12:14:46 --> Controller Class Initialized
INFO - 2018-02-07 12:14:46 --> Model Class Initialized
INFO - 2018-02-07 12:14:46 --> File loaded: /var/www/html/spamblocker/application/views/index/resetPassword.php
INFO - 2018-02-07 12:14:46 --> Final output sent to browser
DEBUG - 2018-02-07 12:14:46 --> Total execution time: 0.0055
INFO - 2018-02-07 12:17:09 --> Config Class Initialized
INFO - 2018-02-07 12:17:09 --> Hooks Class Initialized
DEBUG - 2018-02-07 12:17:09 --> UTF-8 Support Enabled
INFO - 2018-02-07 12:17:09 --> Utf8 Class Initialized
INFO - 2018-02-07 12:17:09 --> URI Class Initialized
INFO - 2018-02-07 12:17:09 --> Router Class Initialized
INFO - 2018-02-07 12:17:09 --> Output Class Initialized
INFO - 2018-02-07 12:17:09 --> Security Class Initialized
DEBUG - 2018-02-07 12:17:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 12:17:09 --> Input Class Initialized
INFO - 2018-02-07 12:17:09 --> Language Class Initialized
INFO - 2018-02-07 12:17:09 --> Loader Class Initialized
INFO - 2018-02-07 12:17:09 --> Helper loaded: url_helper
INFO - 2018-02-07 12:17:09 --> Helper loaded: file_helper
INFO - 2018-02-07 12:17:09 --> Helper loaded: email_helper
INFO - 2018-02-07 12:17:09 --> Helper loaded: common_helper
INFO - 2018-02-07 12:17:09 --> Database Driver Class Initialized
DEBUG - 2018-02-07 12:17:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 12:17:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 12:17:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-07 12:17:09 --> Pagination Class Initialized
INFO - 2018-02-07 12:17:09 --> Helper loaded: form_helper
INFO - 2018-02-07 12:17:09 --> Form Validation Class Initialized
INFO - 2018-02-07 12:17:09 --> Model Class Initialized
INFO - 2018-02-07 12:17:09 --> Controller Class Initialized
DEBUG - 2018-02-07 12:17:09 --> Config file loaded: /var/www/html/spamblocker/application/config/rest.php
INFO - 2018-02-07 12:17:09 --> Helper loaded: inflector_helper
INFO - 2018-02-07 12:17:09 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 12:17:09 --> Model Class Initialized
INFO - 2018-02-07 12:17:09 --> Model Class Initialized
INFO - 2018-02-07 12:17:09 --> Model Class Initialized
INFO - 2018-02-07 12:17:09 --> Email Class Initialized
INFO - 2018-02-07 12:17:09 --> Language file loaded: language/english/email_lang.php
INFO - 2018-02-07 12:17:12 --> Final output sent to browser
DEBUG - 2018-02-07 12:17:12 --> Total execution time: 3.5338
INFO - 2018-02-07 13:10:47 --> Config Class Initialized
INFO - 2018-02-07 13:10:47 --> Hooks Class Initialized
DEBUG - 2018-02-07 13:10:47 --> UTF-8 Support Enabled
INFO - 2018-02-07 13:10:47 --> Utf8 Class Initialized
INFO - 2018-02-07 13:10:47 --> URI Class Initialized
INFO - 2018-02-07 13:10:47 --> Router Class Initialized
INFO - 2018-02-07 13:10:47 --> Output Class Initialized
INFO - 2018-02-07 13:10:47 --> Security Class Initialized
DEBUG - 2018-02-07 13:10:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 13:10:47 --> Input Class Initialized
INFO - 2018-02-07 13:10:47 --> Language Class Initialized
INFO - 2018-02-07 13:10:47 --> Loader Class Initialized
INFO - 2018-02-07 13:10:47 --> Helper loaded: url_helper
INFO - 2018-02-07 13:10:47 --> Helper loaded: file_helper
INFO - 2018-02-07 13:10:47 --> Helper loaded: email_helper
INFO - 2018-02-07 13:10:47 --> Helper loaded: common_helper
INFO - 2018-02-07 13:10:47 --> Database Driver Class Initialized
DEBUG - 2018-02-07 13:10:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 13:10:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 13:10:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-07 13:10:47 --> Pagination Class Initialized
INFO - 2018-02-07 13:10:47 --> Helper loaded: form_helper
INFO - 2018-02-07 13:10:47 --> Form Validation Class Initialized
INFO - 2018-02-07 13:10:47 --> Model Class Initialized
INFO - 2018-02-07 13:10:47 --> Controller Class Initialized
DEBUG - 2018-02-07 13:10:47 --> Config file loaded: /var/www/html/spamblocker/application/config/rest.php
INFO - 2018-02-07 13:10:47 --> Helper loaded: inflector_helper
INFO - 2018-02-07 13:10:47 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 13:10:47 --> Model Class Initialized
INFO - 2018-02-07 13:10:47 --> Model Class Initialized
INFO - 2018-02-07 13:10:47 --> Final output sent to browser
DEBUG - 2018-02-07 13:10:47 --> Total execution time: 0.0059
INFO - 2018-02-07 13:11:28 --> Config Class Initialized
INFO - 2018-02-07 13:11:28 --> Hooks Class Initialized
DEBUG - 2018-02-07 13:11:28 --> UTF-8 Support Enabled
INFO - 2018-02-07 13:11:28 --> Utf8 Class Initialized
INFO - 2018-02-07 13:11:28 --> URI Class Initialized
INFO - 2018-02-07 13:11:28 --> Router Class Initialized
INFO - 2018-02-07 13:11:28 --> Output Class Initialized
INFO - 2018-02-07 13:11:28 --> Security Class Initialized
DEBUG - 2018-02-07 13:11:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 13:11:28 --> Input Class Initialized
INFO - 2018-02-07 13:11:28 --> Language Class Initialized
INFO - 2018-02-07 13:11:28 --> Loader Class Initialized
INFO - 2018-02-07 13:11:28 --> Helper loaded: url_helper
INFO - 2018-02-07 13:11:28 --> Helper loaded: file_helper
INFO - 2018-02-07 13:11:28 --> Helper loaded: email_helper
INFO - 2018-02-07 13:11:28 --> Helper loaded: common_helper
INFO - 2018-02-07 13:11:28 --> Database Driver Class Initialized
DEBUG - 2018-02-07 13:11:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 13:11:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 13:11:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-07 13:11:28 --> Pagination Class Initialized
INFO - 2018-02-07 13:11:28 --> Helper loaded: form_helper
INFO - 2018-02-07 13:11:28 --> Form Validation Class Initialized
INFO - 2018-02-07 13:11:28 --> Model Class Initialized
INFO - 2018-02-07 13:11:28 --> Controller Class Initialized
DEBUG - 2018-02-07 13:11:28 --> Config file loaded: /var/www/html/spamblocker/application/config/rest.php
INFO - 2018-02-07 13:11:28 --> Helper loaded: inflector_helper
INFO - 2018-02-07 13:11:28 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 13:11:28 --> Model Class Initialized
INFO - 2018-02-07 13:11:28 --> Model Class Initialized
INFO - 2018-02-07 13:11:59 --> Config Class Initialized
INFO - 2018-02-07 13:11:59 --> Hooks Class Initialized
DEBUG - 2018-02-07 13:11:59 --> UTF-8 Support Enabled
INFO - 2018-02-07 13:11:59 --> Utf8 Class Initialized
INFO - 2018-02-07 13:11:59 --> URI Class Initialized
INFO - 2018-02-07 13:11:59 --> Router Class Initialized
INFO - 2018-02-07 13:11:59 --> Output Class Initialized
INFO - 2018-02-07 13:11:59 --> Security Class Initialized
DEBUG - 2018-02-07 13:11:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 13:11:59 --> Input Class Initialized
INFO - 2018-02-07 13:11:59 --> Language Class Initialized
INFO - 2018-02-07 13:11:59 --> Loader Class Initialized
INFO - 2018-02-07 13:11:59 --> Helper loaded: url_helper
INFO - 2018-02-07 13:11:59 --> Helper loaded: file_helper
INFO - 2018-02-07 13:11:59 --> Helper loaded: email_helper
INFO - 2018-02-07 13:11:59 --> Helper loaded: common_helper
INFO - 2018-02-07 13:11:59 --> Database Driver Class Initialized
DEBUG - 2018-02-07 13:11:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 13:11:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 13:11:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-07 13:11:59 --> Pagination Class Initialized
INFO - 2018-02-07 13:11:59 --> Helper loaded: form_helper
INFO - 2018-02-07 13:11:59 --> Form Validation Class Initialized
INFO - 2018-02-07 13:11:59 --> Model Class Initialized
INFO - 2018-02-07 13:11:59 --> Controller Class Initialized
DEBUG - 2018-02-07 13:11:59 --> Config file loaded: /var/www/html/spamblocker/application/config/rest.php
INFO - 2018-02-07 13:11:59 --> Helper loaded: inflector_helper
INFO - 2018-02-07 13:11:59 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 13:11:59 --> Model Class Initialized
INFO - 2018-02-07 13:11:59 --> Model Class Initialized
INFO - 2018-02-07 13:13:07 --> Config Class Initialized
INFO - 2018-02-07 13:13:07 --> Hooks Class Initialized
DEBUG - 2018-02-07 13:13:07 --> UTF-8 Support Enabled
INFO - 2018-02-07 13:13:07 --> Utf8 Class Initialized
INFO - 2018-02-07 13:13:07 --> URI Class Initialized
INFO - 2018-02-07 13:13:07 --> Router Class Initialized
INFO - 2018-02-07 13:13:07 --> Output Class Initialized
INFO - 2018-02-07 13:13:07 --> Security Class Initialized
DEBUG - 2018-02-07 13:13:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 13:13:07 --> Input Class Initialized
INFO - 2018-02-07 13:13:07 --> Language Class Initialized
INFO - 2018-02-07 13:13:07 --> Loader Class Initialized
INFO - 2018-02-07 13:13:07 --> Helper loaded: url_helper
INFO - 2018-02-07 13:13:07 --> Helper loaded: file_helper
INFO - 2018-02-07 13:13:07 --> Helper loaded: email_helper
INFO - 2018-02-07 13:13:07 --> Helper loaded: common_helper
INFO - 2018-02-07 13:13:07 --> Database Driver Class Initialized
DEBUG - 2018-02-07 13:13:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 13:13:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 13:13:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-07 13:13:07 --> Pagination Class Initialized
INFO - 2018-02-07 13:13:07 --> Helper loaded: form_helper
INFO - 2018-02-07 13:13:07 --> Form Validation Class Initialized
INFO - 2018-02-07 13:13:07 --> Model Class Initialized
INFO - 2018-02-07 13:13:07 --> Controller Class Initialized
DEBUG - 2018-02-07 13:13:07 --> Config file loaded: /var/www/html/spamblocker/application/config/rest.php
INFO - 2018-02-07 13:13:07 --> Helper loaded: inflector_helper
INFO - 2018-02-07 13:13:07 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 13:13:07 --> Model Class Initialized
INFO - 2018-02-07 13:13:07 --> Model Class Initialized
INFO - 2018-02-07 13:14:25 --> Config Class Initialized
INFO - 2018-02-07 13:14:25 --> Hooks Class Initialized
DEBUG - 2018-02-07 13:14:25 --> UTF-8 Support Enabled
INFO - 2018-02-07 13:14:25 --> Utf8 Class Initialized
INFO - 2018-02-07 13:14:25 --> URI Class Initialized
INFO - 2018-02-07 13:14:25 --> Router Class Initialized
INFO - 2018-02-07 13:14:25 --> Output Class Initialized
INFO - 2018-02-07 13:14:25 --> Security Class Initialized
DEBUG - 2018-02-07 13:14:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 13:14:25 --> Input Class Initialized
INFO - 2018-02-07 13:14:25 --> Language Class Initialized
INFO - 2018-02-07 13:14:25 --> Loader Class Initialized
INFO - 2018-02-07 13:14:25 --> Helper loaded: url_helper
INFO - 2018-02-07 13:14:25 --> Helper loaded: file_helper
INFO - 2018-02-07 13:14:25 --> Helper loaded: email_helper
INFO - 2018-02-07 13:14:25 --> Helper loaded: common_helper
INFO - 2018-02-07 13:14:25 --> Database Driver Class Initialized
DEBUG - 2018-02-07 13:14:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 13:14:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 13:14:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-07 13:14:25 --> Pagination Class Initialized
INFO - 2018-02-07 13:14:25 --> Helper loaded: form_helper
INFO - 2018-02-07 13:14:25 --> Form Validation Class Initialized
INFO - 2018-02-07 13:14:25 --> Model Class Initialized
INFO - 2018-02-07 13:14:25 --> Controller Class Initialized
DEBUG - 2018-02-07 13:14:25 --> Config file loaded: /var/www/html/spamblocker/application/config/rest.php
INFO - 2018-02-07 13:14:25 --> Helper loaded: inflector_helper
INFO - 2018-02-07 13:14:25 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 13:14:25 --> Model Class Initialized
INFO - 2018-02-07 13:14:25 --> Model Class Initialized
INFO - 2018-02-07 13:16:21 --> Config Class Initialized
INFO - 2018-02-07 13:16:21 --> Hooks Class Initialized
DEBUG - 2018-02-07 13:16:21 --> UTF-8 Support Enabled
INFO - 2018-02-07 13:16:21 --> Utf8 Class Initialized
INFO - 2018-02-07 13:16:21 --> URI Class Initialized
INFO - 2018-02-07 13:16:21 --> Router Class Initialized
INFO - 2018-02-07 13:16:21 --> Output Class Initialized
INFO - 2018-02-07 13:16:21 --> Security Class Initialized
DEBUG - 2018-02-07 13:16:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 13:16:21 --> Input Class Initialized
INFO - 2018-02-07 13:16:21 --> Language Class Initialized
INFO - 2018-02-07 13:16:21 --> Loader Class Initialized
INFO - 2018-02-07 13:16:21 --> Helper loaded: url_helper
INFO - 2018-02-07 13:16:21 --> Helper loaded: file_helper
INFO - 2018-02-07 13:16:21 --> Helper loaded: email_helper
INFO - 2018-02-07 13:16:21 --> Helper loaded: common_helper
INFO - 2018-02-07 13:16:21 --> Database Driver Class Initialized
DEBUG - 2018-02-07 13:16:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 13:16:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 13:16:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-07 13:16:21 --> Pagination Class Initialized
INFO - 2018-02-07 13:16:21 --> Helper loaded: form_helper
INFO - 2018-02-07 13:16:21 --> Form Validation Class Initialized
INFO - 2018-02-07 13:16:21 --> Model Class Initialized
INFO - 2018-02-07 13:16:21 --> Controller Class Initialized
DEBUG - 2018-02-07 13:16:21 --> Config file loaded: /var/www/html/spamblocker/application/config/rest.php
INFO - 2018-02-07 13:16:21 --> Helper loaded: inflector_helper
INFO - 2018-02-07 13:16:21 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 13:16:21 --> Model Class Initialized
INFO - 2018-02-07 13:16:21 --> Model Class Initialized
INFO - 2018-02-07 13:24:03 --> Config Class Initialized
INFO - 2018-02-07 13:24:03 --> Hooks Class Initialized
DEBUG - 2018-02-07 13:24:03 --> UTF-8 Support Enabled
INFO - 2018-02-07 13:24:03 --> Utf8 Class Initialized
INFO - 2018-02-07 13:24:03 --> URI Class Initialized
INFO - 2018-02-07 13:24:03 --> Router Class Initialized
INFO - 2018-02-07 13:24:03 --> Output Class Initialized
INFO - 2018-02-07 13:24:03 --> Security Class Initialized
DEBUG - 2018-02-07 13:24:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 13:24:03 --> Input Class Initialized
INFO - 2018-02-07 13:24:03 --> Language Class Initialized
ERROR - 2018-02-07 13:24:03 --> Severity: Notice --> Undefined property: Oauth::$config /var/www/html/spamblocker/application/libraries/REST_Controller.php 630
INFO - 2018-02-07 13:24:25 --> Config Class Initialized
INFO - 2018-02-07 13:24:25 --> Hooks Class Initialized
DEBUG - 2018-02-07 13:24:25 --> UTF-8 Support Enabled
INFO - 2018-02-07 13:24:25 --> Utf8 Class Initialized
INFO - 2018-02-07 13:24:25 --> URI Class Initialized
INFO - 2018-02-07 13:24:25 --> Router Class Initialized
INFO - 2018-02-07 13:24:25 --> Output Class Initialized
INFO - 2018-02-07 13:24:25 --> Security Class Initialized
DEBUG - 2018-02-07 13:24:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 13:24:25 --> Input Class Initialized
INFO - 2018-02-07 13:24:25 --> Language Class Initialized
INFO - 2018-02-07 13:24:25 --> Loader Class Initialized
INFO - 2018-02-07 13:24:25 --> Helper loaded: url_helper
INFO - 2018-02-07 13:24:25 --> Helper loaded: file_helper
INFO - 2018-02-07 13:24:25 --> Helper loaded: email_helper
INFO - 2018-02-07 13:24:25 --> Helper loaded: common_helper
INFO - 2018-02-07 13:24:25 --> Database Driver Class Initialized
DEBUG - 2018-02-07 13:24:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 13:24:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 13:24:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-07 13:24:25 --> Pagination Class Initialized
INFO - 2018-02-07 13:24:25 --> Helper loaded: form_helper
INFO - 2018-02-07 13:24:25 --> Form Validation Class Initialized
INFO - 2018-02-07 13:24:25 --> Model Class Initialized
INFO - 2018-02-07 13:24:25 --> Controller Class Initialized
DEBUG - 2018-02-07 13:24:25 --> Config file loaded: /var/www/html/spamblocker/application/config/rest.php
INFO - 2018-02-07 13:25:02 --> Config Class Initialized
INFO - 2018-02-07 13:25:02 --> Hooks Class Initialized
DEBUG - 2018-02-07 13:25:02 --> UTF-8 Support Enabled
INFO - 2018-02-07 13:25:02 --> Utf8 Class Initialized
INFO - 2018-02-07 13:25:02 --> URI Class Initialized
INFO - 2018-02-07 13:25:02 --> Router Class Initialized
INFO - 2018-02-07 13:25:02 --> Output Class Initialized
INFO - 2018-02-07 13:25:02 --> Security Class Initialized
DEBUG - 2018-02-07 13:25:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 13:25:02 --> Input Class Initialized
INFO - 2018-02-07 13:25:02 --> Language Class Initialized
INFO - 2018-02-07 13:25:02 --> Loader Class Initialized
INFO - 2018-02-07 13:25:02 --> Helper loaded: url_helper
INFO - 2018-02-07 13:25:02 --> Helper loaded: file_helper
INFO - 2018-02-07 13:25:02 --> Helper loaded: email_helper
INFO - 2018-02-07 13:25:02 --> Helper loaded: common_helper
INFO - 2018-02-07 13:25:02 --> Database Driver Class Initialized
DEBUG - 2018-02-07 13:25:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 13:25:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 13:25:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-07 13:25:02 --> Pagination Class Initialized
INFO - 2018-02-07 13:25:02 --> Helper loaded: form_helper
INFO - 2018-02-07 13:25:02 --> Form Validation Class Initialized
INFO - 2018-02-07 13:25:02 --> Model Class Initialized
INFO - 2018-02-07 13:25:02 --> Controller Class Initialized
DEBUG - 2018-02-07 13:25:02 --> Config file loaded: /var/www/html/spamblocker/application/config/rest.php
INFO - 2018-02-07 13:25:02 --> Helper loaded: inflector_helper
INFO - 2018-02-07 13:25:02 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 13:25:29 --> Config Class Initialized
INFO - 2018-02-07 13:25:29 --> Hooks Class Initialized
DEBUG - 2018-02-07 13:25:29 --> UTF-8 Support Enabled
INFO - 2018-02-07 13:25:29 --> Utf8 Class Initialized
INFO - 2018-02-07 13:25:29 --> URI Class Initialized
INFO - 2018-02-07 13:25:29 --> Router Class Initialized
INFO - 2018-02-07 13:25:29 --> Output Class Initialized
INFO - 2018-02-07 13:25:29 --> Security Class Initialized
DEBUG - 2018-02-07 13:25:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 13:25:29 --> Input Class Initialized
INFO - 2018-02-07 13:25:29 --> Language Class Initialized
INFO - 2018-02-07 13:25:29 --> Loader Class Initialized
INFO - 2018-02-07 13:25:29 --> Helper loaded: url_helper
INFO - 2018-02-07 13:25:29 --> Helper loaded: file_helper
INFO - 2018-02-07 13:25:29 --> Helper loaded: email_helper
INFO - 2018-02-07 13:25:29 --> Helper loaded: common_helper
INFO - 2018-02-07 13:25:29 --> Database Driver Class Initialized
DEBUG - 2018-02-07 13:25:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 13:25:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 13:25:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-07 13:25:29 --> Pagination Class Initialized
INFO - 2018-02-07 13:25:29 --> Helper loaded: form_helper
INFO - 2018-02-07 13:25:29 --> Form Validation Class Initialized
INFO - 2018-02-07 13:25:29 --> Model Class Initialized
INFO - 2018-02-07 13:25:29 --> Controller Class Initialized
DEBUG - 2018-02-07 13:25:29 --> Config file loaded: /var/www/html/spamblocker/application/config/rest.php
INFO - 2018-02-07 13:25:29 --> Helper loaded: inflector_helper
INFO - 2018-02-07 13:25:29 --> Language file loaded: language/english/rest_controller_lang.php
ERROR - 2018-02-07 13:25:29 --> Severity: error --> Exception: Call to undefined method Oauth::input() /var/www/html/spamblocker/application/libraries/REST_Controller.php 513
INFO - 2018-02-07 13:25:44 --> Config Class Initialized
INFO - 2018-02-07 13:25:44 --> Hooks Class Initialized
DEBUG - 2018-02-07 13:25:44 --> UTF-8 Support Enabled
INFO - 2018-02-07 13:25:44 --> Utf8 Class Initialized
INFO - 2018-02-07 13:25:44 --> URI Class Initialized
INFO - 2018-02-07 13:25:44 --> Router Class Initialized
INFO - 2018-02-07 13:25:44 --> Output Class Initialized
INFO - 2018-02-07 13:25:44 --> Security Class Initialized
DEBUG - 2018-02-07 13:25:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 13:25:44 --> Input Class Initialized
INFO - 2018-02-07 13:25:44 --> Language Class Initialized
INFO - 2018-02-07 13:25:44 --> Loader Class Initialized
INFO - 2018-02-07 13:25:44 --> Helper loaded: url_helper
INFO - 2018-02-07 13:25:44 --> Helper loaded: file_helper
INFO - 2018-02-07 13:25:44 --> Helper loaded: email_helper
INFO - 2018-02-07 13:25:44 --> Helper loaded: common_helper
INFO - 2018-02-07 13:25:44 --> Database Driver Class Initialized
DEBUG - 2018-02-07 13:25:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 13:25:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 13:25:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-07 13:25:44 --> Pagination Class Initialized
INFO - 2018-02-07 13:25:44 --> Helper loaded: form_helper
INFO - 2018-02-07 13:25:44 --> Form Validation Class Initialized
INFO - 2018-02-07 13:25:44 --> Model Class Initialized
INFO - 2018-02-07 13:25:44 --> Controller Class Initialized
DEBUG - 2018-02-07 13:25:44 --> Config file loaded: /var/www/html/spamblocker/application/config/rest.php
INFO - 2018-02-07 13:25:44 --> Helper loaded: inflector_helper
INFO - 2018-02-07 13:25:44 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 13:26:05 --> Config Class Initialized
INFO - 2018-02-07 13:26:05 --> Hooks Class Initialized
DEBUG - 2018-02-07 13:26:05 --> UTF-8 Support Enabled
INFO - 2018-02-07 13:26:05 --> Utf8 Class Initialized
INFO - 2018-02-07 13:26:05 --> URI Class Initialized
INFO - 2018-02-07 13:26:05 --> Router Class Initialized
INFO - 2018-02-07 13:26:05 --> Output Class Initialized
INFO - 2018-02-07 13:26:05 --> Security Class Initialized
DEBUG - 2018-02-07 13:26:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 13:26:05 --> Input Class Initialized
INFO - 2018-02-07 13:26:05 --> Language Class Initialized
INFO - 2018-02-07 13:26:05 --> Loader Class Initialized
INFO - 2018-02-07 13:26:05 --> Helper loaded: url_helper
INFO - 2018-02-07 13:26:05 --> Helper loaded: file_helper
INFO - 2018-02-07 13:26:05 --> Helper loaded: email_helper
INFO - 2018-02-07 13:26:05 --> Helper loaded: common_helper
INFO - 2018-02-07 13:26:05 --> Database Driver Class Initialized
DEBUG - 2018-02-07 13:26:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 13:26:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 13:26:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-07 13:26:05 --> Pagination Class Initialized
INFO - 2018-02-07 13:26:05 --> Helper loaded: form_helper
INFO - 2018-02-07 13:26:05 --> Form Validation Class Initialized
INFO - 2018-02-07 13:26:05 --> Model Class Initialized
INFO - 2018-02-07 13:26:05 --> Controller Class Initialized
DEBUG - 2018-02-07 13:26:05 --> Config file loaded: /var/www/html/spamblocker/application/config/rest.php
INFO - 2018-02-07 13:26:05 --> Helper loaded: inflector_helper
INFO - 2018-02-07 13:26:05 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 14:06:20 --> Config Class Initialized
INFO - 2018-02-07 14:06:20 --> Hooks Class Initialized
DEBUG - 2018-02-07 14:06:20 --> UTF-8 Support Enabled
INFO - 2018-02-07 14:06:20 --> Utf8 Class Initialized
INFO - 2018-02-07 14:06:20 --> URI Class Initialized
INFO - 2018-02-07 14:06:20 --> Router Class Initialized
INFO - 2018-02-07 14:06:20 --> Output Class Initialized
INFO - 2018-02-07 14:06:20 --> Security Class Initialized
DEBUG - 2018-02-07 14:06:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 14:06:20 --> Input Class Initialized
INFO - 2018-02-07 14:06:20 --> Language Class Initialized
INFO - 2018-02-07 14:06:20 --> Loader Class Initialized
INFO - 2018-02-07 14:06:20 --> Helper loaded: url_helper
INFO - 2018-02-07 14:06:20 --> Helper loaded: file_helper
INFO - 2018-02-07 14:06:20 --> Helper loaded: email_helper
INFO - 2018-02-07 14:06:20 --> Helper loaded: common_helper
INFO - 2018-02-07 14:06:20 --> Database Driver Class Initialized
DEBUG - 2018-02-07 14:06:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 14:06:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 14:06:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-07 14:06:20 --> Pagination Class Initialized
INFO - 2018-02-07 14:06:20 --> Helper loaded: form_helper
INFO - 2018-02-07 14:06:20 --> Form Validation Class Initialized
INFO - 2018-02-07 14:06:20 --> Model Class Initialized
INFO - 2018-02-07 14:06:20 --> Controller Class Initialized
INFO - 2018-02-07 14:06:30 --> Config Class Initialized
INFO - 2018-02-07 14:06:30 --> Hooks Class Initialized
DEBUG - 2018-02-07 14:06:30 --> UTF-8 Support Enabled
INFO - 2018-02-07 14:06:30 --> Utf8 Class Initialized
INFO - 2018-02-07 14:06:30 --> URI Class Initialized
INFO - 2018-02-07 14:06:30 --> Router Class Initialized
INFO - 2018-02-07 14:06:30 --> Output Class Initialized
INFO - 2018-02-07 14:06:30 --> Security Class Initialized
DEBUG - 2018-02-07 14:06:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 14:06:30 --> Input Class Initialized
INFO - 2018-02-07 14:06:30 --> Language Class Initialized
INFO - 2018-02-07 14:06:30 --> Loader Class Initialized
INFO - 2018-02-07 14:06:30 --> Helper loaded: url_helper
INFO - 2018-02-07 14:06:30 --> Helper loaded: file_helper
INFO - 2018-02-07 14:06:30 --> Helper loaded: email_helper
INFO - 2018-02-07 14:06:30 --> Helper loaded: common_helper
INFO - 2018-02-07 14:06:30 --> Database Driver Class Initialized
DEBUG - 2018-02-07 14:06:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 14:06:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 14:06:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-07 14:06:30 --> Pagination Class Initialized
INFO - 2018-02-07 14:06:30 --> Helper loaded: form_helper
INFO - 2018-02-07 14:06:30 --> Form Validation Class Initialized
INFO - 2018-02-07 14:06:30 --> Model Class Initialized
INFO - 2018-02-07 14:06:30 --> Controller Class Initialized
INFO - 2018-02-07 14:06:36 --> Config Class Initialized
INFO - 2018-02-07 14:06:36 --> Hooks Class Initialized
DEBUG - 2018-02-07 14:06:36 --> UTF-8 Support Enabled
INFO - 2018-02-07 14:06:36 --> Utf8 Class Initialized
INFO - 2018-02-07 14:06:36 --> URI Class Initialized
INFO - 2018-02-07 14:06:36 --> Router Class Initialized
INFO - 2018-02-07 14:06:36 --> Output Class Initialized
INFO - 2018-02-07 14:06:36 --> Security Class Initialized
DEBUG - 2018-02-07 14:06:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 14:06:36 --> Input Class Initialized
INFO - 2018-02-07 14:06:36 --> Language Class Initialized
INFO - 2018-02-07 14:06:36 --> Loader Class Initialized
INFO - 2018-02-07 14:06:36 --> Helper loaded: url_helper
INFO - 2018-02-07 14:06:36 --> Helper loaded: file_helper
INFO - 2018-02-07 14:06:36 --> Helper loaded: email_helper
INFO - 2018-02-07 14:06:36 --> Helper loaded: common_helper
INFO - 2018-02-07 14:06:36 --> Database Driver Class Initialized
DEBUG - 2018-02-07 14:06:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 14:06:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 14:06:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-07 14:06:36 --> Pagination Class Initialized
INFO - 2018-02-07 14:06:36 --> Helper loaded: form_helper
INFO - 2018-02-07 14:06:36 --> Form Validation Class Initialized
INFO - 2018-02-07 14:06:36 --> Model Class Initialized
INFO - 2018-02-07 14:06:36 --> Controller Class Initialized
INFO - 2018-02-07 14:08:29 --> Config Class Initialized
INFO - 2018-02-07 14:08:29 --> Hooks Class Initialized
DEBUG - 2018-02-07 14:08:29 --> UTF-8 Support Enabled
INFO - 2018-02-07 14:08:29 --> Utf8 Class Initialized
INFO - 2018-02-07 14:08:29 --> URI Class Initialized
INFO - 2018-02-07 14:08:29 --> Router Class Initialized
INFO - 2018-02-07 14:08:29 --> Output Class Initialized
INFO - 2018-02-07 14:08:29 --> Security Class Initialized
DEBUG - 2018-02-07 14:08:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 14:08:29 --> Input Class Initialized
INFO - 2018-02-07 14:08:29 --> Language Class Initialized
INFO - 2018-02-07 14:08:29 --> Loader Class Initialized
INFO - 2018-02-07 14:08:29 --> Helper loaded: url_helper
INFO - 2018-02-07 14:08:29 --> Helper loaded: file_helper
INFO - 2018-02-07 14:08:29 --> Helper loaded: email_helper
INFO - 2018-02-07 14:08:29 --> Helper loaded: common_helper
INFO - 2018-02-07 14:08:29 --> Database Driver Class Initialized
DEBUG - 2018-02-07 14:08:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 14:08:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 14:08:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-07 14:08:29 --> Pagination Class Initialized
INFO - 2018-02-07 14:08:29 --> Helper loaded: form_helper
INFO - 2018-02-07 14:08:29 --> Form Validation Class Initialized
INFO - 2018-02-07 14:08:29 --> Model Class Initialized
INFO - 2018-02-07 14:08:29 --> Controller Class Initialized
INFO - 2018-02-07 14:08:40 --> Config Class Initialized
INFO - 2018-02-07 14:08:40 --> Hooks Class Initialized
DEBUG - 2018-02-07 14:08:40 --> UTF-8 Support Enabled
INFO - 2018-02-07 14:08:40 --> Utf8 Class Initialized
INFO - 2018-02-07 14:08:40 --> URI Class Initialized
INFO - 2018-02-07 14:08:40 --> Router Class Initialized
INFO - 2018-02-07 14:08:40 --> Output Class Initialized
INFO - 2018-02-07 14:08:40 --> Security Class Initialized
DEBUG - 2018-02-07 14:08:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 14:08:40 --> Input Class Initialized
INFO - 2018-02-07 14:08:40 --> Language Class Initialized
INFO - 2018-02-07 14:08:40 --> Loader Class Initialized
INFO - 2018-02-07 14:08:40 --> Helper loaded: url_helper
INFO - 2018-02-07 14:08:40 --> Helper loaded: file_helper
INFO - 2018-02-07 14:08:40 --> Helper loaded: email_helper
INFO - 2018-02-07 14:08:40 --> Helper loaded: common_helper
INFO - 2018-02-07 14:08:40 --> Database Driver Class Initialized
DEBUG - 2018-02-07 14:08:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 14:08:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 14:08:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-07 14:08:40 --> Pagination Class Initialized
INFO - 2018-02-07 14:08:40 --> Helper loaded: form_helper
INFO - 2018-02-07 14:08:40 --> Form Validation Class Initialized
INFO - 2018-02-07 14:08:40 --> Model Class Initialized
INFO - 2018-02-07 14:08:40 --> Controller Class Initialized
INFO - 2018-02-07 14:08:46 --> Config Class Initialized
INFO - 2018-02-07 14:08:46 --> Hooks Class Initialized
DEBUG - 2018-02-07 14:08:46 --> UTF-8 Support Enabled
INFO - 2018-02-07 14:08:46 --> Utf8 Class Initialized
INFO - 2018-02-07 14:08:46 --> URI Class Initialized
INFO - 2018-02-07 14:08:46 --> Router Class Initialized
INFO - 2018-02-07 14:08:46 --> Output Class Initialized
INFO - 2018-02-07 14:08:46 --> Security Class Initialized
DEBUG - 2018-02-07 14:08:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 14:08:46 --> Input Class Initialized
INFO - 2018-02-07 14:08:46 --> Language Class Initialized
INFO - 2018-02-07 14:08:46 --> Loader Class Initialized
INFO - 2018-02-07 14:08:46 --> Helper loaded: url_helper
INFO - 2018-02-07 14:08:46 --> Helper loaded: file_helper
INFO - 2018-02-07 14:08:46 --> Helper loaded: email_helper
INFO - 2018-02-07 14:08:46 --> Helper loaded: common_helper
INFO - 2018-02-07 14:08:46 --> Database Driver Class Initialized
DEBUG - 2018-02-07 14:08:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 14:08:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 14:08:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-07 14:08:46 --> Pagination Class Initialized
INFO - 2018-02-07 14:08:46 --> Helper loaded: form_helper
INFO - 2018-02-07 14:08:46 --> Form Validation Class Initialized
INFO - 2018-02-07 14:08:46 --> Model Class Initialized
INFO - 2018-02-07 14:08:46 --> Controller Class Initialized
ERROR - 2018-02-07 14:08:46 --> Severity: Notice --> Undefined variable: _FILE /var/www/html/spamblocker/application/libraries/REST_Controller.php 395
INFO - 2018-02-07 14:09:01 --> Config Class Initialized
INFO - 2018-02-07 14:09:01 --> Hooks Class Initialized
DEBUG - 2018-02-07 14:09:01 --> UTF-8 Support Enabled
INFO - 2018-02-07 14:09:01 --> Utf8 Class Initialized
INFO - 2018-02-07 14:09:01 --> URI Class Initialized
INFO - 2018-02-07 14:09:01 --> Router Class Initialized
INFO - 2018-02-07 14:09:01 --> Output Class Initialized
INFO - 2018-02-07 14:09:01 --> Security Class Initialized
DEBUG - 2018-02-07 14:09:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 14:09:01 --> Input Class Initialized
INFO - 2018-02-07 14:09:01 --> Language Class Initialized
INFO - 2018-02-07 14:09:01 --> Loader Class Initialized
INFO - 2018-02-07 14:09:01 --> Helper loaded: url_helper
INFO - 2018-02-07 14:09:01 --> Helper loaded: file_helper
INFO - 2018-02-07 14:09:01 --> Helper loaded: email_helper
INFO - 2018-02-07 14:09:01 --> Helper loaded: common_helper
INFO - 2018-02-07 14:09:01 --> Database Driver Class Initialized
DEBUG - 2018-02-07 14:09:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 14:09:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 14:09:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-07 14:09:01 --> Pagination Class Initialized
INFO - 2018-02-07 14:09:01 --> Helper loaded: form_helper
INFO - 2018-02-07 14:09:01 --> Form Validation Class Initialized
INFO - 2018-02-07 14:09:01 --> Model Class Initialized
INFO - 2018-02-07 14:09:01 --> Controller Class Initialized
INFO - 2018-02-07 14:09:07 --> Config Class Initialized
INFO - 2018-02-07 14:09:07 --> Hooks Class Initialized
DEBUG - 2018-02-07 14:09:07 --> UTF-8 Support Enabled
INFO - 2018-02-07 14:09:07 --> Utf8 Class Initialized
INFO - 2018-02-07 14:09:07 --> URI Class Initialized
INFO - 2018-02-07 14:09:07 --> Router Class Initialized
INFO - 2018-02-07 14:09:07 --> Output Class Initialized
INFO - 2018-02-07 14:09:07 --> Security Class Initialized
DEBUG - 2018-02-07 14:09:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 14:09:07 --> Input Class Initialized
INFO - 2018-02-07 14:09:07 --> Language Class Initialized
INFO - 2018-02-07 14:09:07 --> Loader Class Initialized
INFO - 2018-02-07 14:09:07 --> Helper loaded: url_helper
INFO - 2018-02-07 14:09:07 --> Helper loaded: file_helper
INFO - 2018-02-07 14:09:07 --> Helper loaded: email_helper
INFO - 2018-02-07 14:09:07 --> Helper loaded: common_helper
INFO - 2018-02-07 14:09:07 --> Database Driver Class Initialized
DEBUG - 2018-02-07 14:09:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 14:09:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 14:09:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-07 14:09:07 --> Pagination Class Initialized
INFO - 2018-02-07 14:09:07 --> Helper loaded: form_helper
INFO - 2018-02-07 14:09:07 --> Form Validation Class Initialized
INFO - 2018-02-07 14:09:07 --> Model Class Initialized
INFO - 2018-02-07 14:09:07 --> Controller Class Initialized
INFO - 2018-02-07 14:09:18 --> Config Class Initialized
INFO - 2018-02-07 14:09:18 --> Hooks Class Initialized
DEBUG - 2018-02-07 14:09:18 --> UTF-8 Support Enabled
INFO - 2018-02-07 14:09:18 --> Utf8 Class Initialized
INFO - 2018-02-07 14:09:18 --> URI Class Initialized
INFO - 2018-02-07 14:09:18 --> Router Class Initialized
INFO - 2018-02-07 14:09:18 --> Output Class Initialized
INFO - 2018-02-07 14:09:18 --> Security Class Initialized
DEBUG - 2018-02-07 14:09:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 14:09:18 --> Input Class Initialized
INFO - 2018-02-07 14:09:18 --> Language Class Initialized
INFO - 2018-02-07 14:09:18 --> Loader Class Initialized
INFO - 2018-02-07 14:09:18 --> Helper loaded: url_helper
INFO - 2018-02-07 14:09:18 --> Helper loaded: file_helper
INFO - 2018-02-07 14:09:18 --> Helper loaded: email_helper
INFO - 2018-02-07 14:09:18 --> Helper loaded: common_helper
INFO - 2018-02-07 14:09:18 --> Database Driver Class Initialized
DEBUG - 2018-02-07 14:09:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 14:09:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 14:09:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-07 14:09:18 --> Pagination Class Initialized
INFO - 2018-02-07 14:09:18 --> Helper loaded: form_helper
INFO - 2018-02-07 14:09:18 --> Form Validation Class Initialized
INFO - 2018-02-07 14:09:18 --> Model Class Initialized
INFO - 2018-02-07 14:09:18 --> Controller Class Initialized
INFO - 2018-02-07 14:09:59 --> Config Class Initialized
INFO - 2018-02-07 14:09:59 --> Hooks Class Initialized
DEBUG - 2018-02-07 14:09:59 --> UTF-8 Support Enabled
INFO - 2018-02-07 14:09:59 --> Utf8 Class Initialized
INFO - 2018-02-07 14:09:59 --> URI Class Initialized
INFO - 2018-02-07 14:09:59 --> Router Class Initialized
INFO - 2018-02-07 14:09:59 --> Output Class Initialized
INFO - 2018-02-07 14:09:59 --> Security Class Initialized
DEBUG - 2018-02-07 14:09:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 14:09:59 --> Input Class Initialized
INFO - 2018-02-07 14:09:59 --> Language Class Initialized
INFO - 2018-02-07 14:09:59 --> Loader Class Initialized
INFO - 2018-02-07 14:09:59 --> Helper loaded: url_helper
INFO - 2018-02-07 14:09:59 --> Helper loaded: file_helper
INFO - 2018-02-07 14:09:59 --> Helper loaded: email_helper
INFO - 2018-02-07 14:09:59 --> Helper loaded: common_helper
INFO - 2018-02-07 14:09:59 --> Database Driver Class Initialized
DEBUG - 2018-02-07 14:09:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 14:09:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 14:09:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-07 14:09:59 --> Pagination Class Initialized
INFO - 2018-02-07 14:09:59 --> Helper loaded: form_helper
INFO - 2018-02-07 14:09:59 --> Form Validation Class Initialized
INFO - 2018-02-07 14:09:59 --> Model Class Initialized
INFO - 2018-02-07 14:09:59 --> Controller Class Initialized
INFO - 2018-02-07 14:10:07 --> Config Class Initialized
INFO - 2018-02-07 14:10:07 --> Hooks Class Initialized
DEBUG - 2018-02-07 14:10:07 --> UTF-8 Support Enabled
INFO - 2018-02-07 14:10:07 --> Utf8 Class Initialized
INFO - 2018-02-07 14:10:07 --> URI Class Initialized
INFO - 2018-02-07 14:10:07 --> Router Class Initialized
INFO - 2018-02-07 14:10:07 --> Output Class Initialized
INFO - 2018-02-07 14:10:07 --> Security Class Initialized
DEBUG - 2018-02-07 14:10:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 14:10:07 --> Input Class Initialized
INFO - 2018-02-07 14:10:07 --> Language Class Initialized
INFO - 2018-02-07 14:10:07 --> Loader Class Initialized
INFO - 2018-02-07 14:10:07 --> Helper loaded: url_helper
INFO - 2018-02-07 14:10:07 --> Helper loaded: file_helper
INFO - 2018-02-07 14:10:07 --> Helper loaded: email_helper
INFO - 2018-02-07 14:10:07 --> Helper loaded: common_helper
INFO - 2018-02-07 14:10:07 --> Database Driver Class Initialized
DEBUG - 2018-02-07 14:10:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 14:10:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 14:10:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-07 14:10:07 --> Pagination Class Initialized
INFO - 2018-02-07 14:10:07 --> Helper loaded: form_helper
INFO - 2018-02-07 14:10:07 --> Form Validation Class Initialized
INFO - 2018-02-07 14:10:07 --> Model Class Initialized
INFO - 2018-02-07 14:10:07 --> Controller Class Initialized
INFO - 2018-02-07 14:10:14 --> Config Class Initialized
INFO - 2018-02-07 14:10:14 --> Hooks Class Initialized
DEBUG - 2018-02-07 14:10:14 --> UTF-8 Support Enabled
INFO - 2018-02-07 14:10:14 --> Utf8 Class Initialized
INFO - 2018-02-07 14:10:14 --> URI Class Initialized
INFO - 2018-02-07 14:10:14 --> Router Class Initialized
INFO - 2018-02-07 14:10:14 --> Output Class Initialized
INFO - 2018-02-07 14:10:14 --> Security Class Initialized
DEBUG - 2018-02-07 14:10:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 14:10:14 --> Input Class Initialized
INFO - 2018-02-07 14:10:14 --> Language Class Initialized
INFO - 2018-02-07 14:10:14 --> Loader Class Initialized
INFO - 2018-02-07 14:10:14 --> Helper loaded: url_helper
INFO - 2018-02-07 14:10:14 --> Helper loaded: file_helper
INFO - 2018-02-07 14:10:14 --> Helper loaded: email_helper
INFO - 2018-02-07 14:10:14 --> Helper loaded: common_helper
INFO - 2018-02-07 14:10:14 --> Database Driver Class Initialized
DEBUG - 2018-02-07 14:10:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 14:10:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 14:10:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-07 14:10:14 --> Pagination Class Initialized
INFO - 2018-02-07 14:10:14 --> Helper loaded: form_helper
INFO - 2018-02-07 14:10:14 --> Form Validation Class Initialized
INFO - 2018-02-07 14:10:14 --> Model Class Initialized
INFO - 2018-02-07 14:10:14 --> Controller Class Initialized
INFO - 2018-02-07 14:11:05 --> Config Class Initialized
INFO - 2018-02-07 14:11:05 --> Hooks Class Initialized
DEBUG - 2018-02-07 14:11:05 --> UTF-8 Support Enabled
INFO - 2018-02-07 14:11:05 --> Utf8 Class Initialized
INFO - 2018-02-07 14:11:05 --> URI Class Initialized
INFO - 2018-02-07 14:11:05 --> Router Class Initialized
INFO - 2018-02-07 14:11:05 --> Output Class Initialized
INFO - 2018-02-07 14:11:05 --> Security Class Initialized
DEBUG - 2018-02-07 14:11:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 14:11:05 --> Input Class Initialized
INFO - 2018-02-07 14:11:05 --> Language Class Initialized
INFO - 2018-02-07 14:11:05 --> Loader Class Initialized
INFO - 2018-02-07 14:11:05 --> Helper loaded: url_helper
INFO - 2018-02-07 14:11:05 --> Helper loaded: file_helper
INFO - 2018-02-07 14:11:05 --> Helper loaded: email_helper
INFO - 2018-02-07 14:11:05 --> Helper loaded: common_helper
INFO - 2018-02-07 14:11:05 --> Database Driver Class Initialized
DEBUG - 2018-02-07 14:11:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 14:11:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 14:11:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-07 14:11:05 --> Pagination Class Initialized
INFO - 2018-02-07 14:11:05 --> Helper loaded: form_helper
INFO - 2018-02-07 14:11:05 --> Form Validation Class Initialized
INFO - 2018-02-07 14:11:05 --> Model Class Initialized
INFO - 2018-02-07 14:11:05 --> Controller Class Initialized
INFO - 2018-02-07 14:12:48 --> Config Class Initialized
INFO - 2018-02-07 14:12:48 --> Hooks Class Initialized
DEBUG - 2018-02-07 14:12:48 --> UTF-8 Support Enabled
INFO - 2018-02-07 14:12:48 --> Utf8 Class Initialized
INFO - 2018-02-07 14:12:48 --> URI Class Initialized
INFO - 2018-02-07 14:12:48 --> Router Class Initialized
INFO - 2018-02-07 14:12:48 --> Output Class Initialized
INFO - 2018-02-07 14:12:48 --> Security Class Initialized
DEBUG - 2018-02-07 14:12:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 14:12:48 --> Input Class Initialized
INFO - 2018-02-07 14:12:48 --> Language Class Initialized
INFO - 2018-02-07 14:12:48 --> Loader Class Initialized
INFO - 2018-02-07 14:12:48 --> Helper loaded: url_helper
INFO - 2018-02-07 14:12:48 --> Helper loaded: file_helper
INFO - 2018-02-07 14:12:48 --> Helper loaded: email_helper
INFO - 2018-02-07 14:12:48 --> Helper loaded: common_helper
INFO - 2018-02-07 14:12:48 --> Database Driver Class Initialized
DEBUG - 2018-02-07 14:12:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 14:12:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 14:12:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-07 14:12:48 --> Pagination Class Initialized
INFO - 2018-02-07 14:12:48 --> Helper loaded: form_helper
INFO - 2018-02-07 14:12:48 --> Form Validation Class Initialized
INFO - 2018-02-07 14:12:48 --> Model Class Initialized
INFO - 2018-02-07 14:12:48 --> Controller Class Initialized
INFO - 2018-02-07 14:13:01 --> Config Class Initialized
INFO - 2018-02-07 14:13:01 --> Hooks Class Initialized
DEBUG - 2018-02-07 14:13:01 --> UTF-8 Support Enabled
INFO - 2018-02-07 14:13:01 --> Utf8 Class Initialized
INFO - 2018-02-07 14:13:01 --> URI Class Initialized
INFO - 2018-02-07 14:13:01 --> Router Class Initialized
INFO - 2018-02-07 14:13:01 --> Output Class Initialized
INFO - 2018-02-07 14:13:01 --> Security Class Initialized
DEBUG - 2018-02-07 14:13:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 14:13:01 --> Input Class Initialized
INFO - 2018-02-07 14:13:01 --> Language Class Initialized
INFO - 2018-02-07 14:13:01 --> Loader Class Initialized
INFO - 2018-02-07 14:13:01 --> Helper loaded: url_helper
INFO - 2018-02-07 14:13:01 --> Helper loaded: file_helper
INFO - 2018-02-07 14:13:01 --> Helper loaded: email_helper
INFO - 2018-02-07 14:13:01 --> Helper loaded: common_helper
INFO - 2018-02-07 14:13:01 --> Database Driver Class Initialized
DEBUG - 2018-02-07 14:13:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 14:13:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 14:13:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-07 14:13:01 --> Pagination Class Initialized
INFO - 2018-02-07 14:13:01 --> Helper loaded: form_helper
INFO - 2018-02-07 14:13:01 --> Form Validation Class Initialized
INFO - 2018-02-07 14:13:01 --> Model Class Initialized
INFO - 2018-02-07 14:13:01 --> Controller Class Initialized
DEBUG - 2018-02-07 14:13:01 --> Config file loaded: /var/www/html/spamblocker/application/config/rest.php
INFO - 2018-02-07 14:13:01 --> Helper loaded: inflector_helper
INFO - 2018-02-07 14:13:01 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 14:13:01 --> Model Class Initialized
INFO - 2018-02-07 14:13:01 --> Model Class Initialized
INFO - 2018-02-07 14:13:06 --> Config Class Initialized
INFO - 2018-02-07 14:13:06 --> Hooks Class Initialized
DEBUG - 2018-02-07 14:13:06 --> UTF-8 Support Enabled
INFO - 2018-02-07 14:13:06 --> Utf8 Class Initialized
INFO - 2018-02-07 14:13:06 --> URI Class Initialized
INFO - 2018-02-07 14:13:06 --> Router Class Initialized
INFO - 2018-02-07 14:13:06 --> Output Class Initialized
INFO - 2018-02-07 14:13:06 --> Security Class Initialized
DEBUG - 2018-02-07 14:13:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 14:13:06 --> Input Class Initialized
INFO - 2018-02-07 14:13:06 --> Language Class Initialized
INFO - 2018-02-07 14:13:06 --> Loader Class Initialized
INFO - 2018-02-07 14:13:06 --> Helper loaded: url_helper
INFO - 2018-02-07 14:13:06 --> Helper loaded: file_helper
INFO - 2018-02-07 14:13:06 --> Helper loaded: email_helper
INFO - 2018-02-07 14:13:06 --> Helper loaded: common_helper
INFO - 2018-02-07 14:13:06 --> Database Driver Class Initialized
DEBUG - 2018-02-07 14:13:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 14:13:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 14:13:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-07 14:13:06 --> Pagination Class Initialized
INFO - 2018-02-07 14:13:06 --> Helper loaded: form_helper
INFO - 2018-02-07 14:13:06 --> Form Validation Class Initialized
INFO - 2018-02-07 14:13:06 --> Model Class Initialized
INFO - 2018-02-07 14:13:06 --> Controller Class Initialized
DEBUG - 2018-02-07 14:13:06 --> Config file loaded: /var/www/html/spamblocker/application/config/rest.php
INFO - 2018-02-07 14:13:06 --> Helper loaded: inflector_helper
INFO - 2018-02-07 14:13:06 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 14:13:06 --> Model Class Initialized
INFO - 2018-02-07 14:13:06 --> Model Class Initialized
INFO - 2018-02-07 14:13:16 --> Config Class Initialized
INFO - 2018-02-07 14:13:16 --> Hooks Class Initialized
DEBUG - 2018-02-07 14:13:16 --> UTF-8 Support Enabled
INFO - 2018-02-07 14:13:16 --> Utf8 Class Initialized
INFO - 2018-02-07 14:13:16 --> URI Class Initialized
INFO - 2018-02-07 14:13:16 --> Router Class Initialized
INFO - 2018-02-07 14:13:16 --> Output Class Initialized
INFO - 2018-02-07 14:13:16 --> Security Class Initialized
DEBUG - 2018-02-07 14:13:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 14:13:16 --> Input Class Initialized
INFO - 2018-02-07 14:13:16 --> Language Class Initialized
INFO - 2018-02-07 14:13:16 --> Loader Class Initialized
INFO - 2018-02-07 14:13:16 --> Helper loaded: url_helper
INFO - 2018-02-07 14:13:16 --> Helper loaded: file_helper
INFO - 2018-02-07 14:13:16 --> Helper loaded: email_helper
INFO - 2018-02-07 14:13:16 --> Helper loaded: common_helper
INFO - 2018-02-07 14:13:16 --> Database Driver Class Initialized
DEBUG - 2018-02-07 14:13:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 14:13:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 14:13:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-07 14:13:16 --> Pagination Class Initialized
INFO - 2018-02-07 14:13:16 --> Helper loaded: form_helper
INFO - 2018-02-07 14:13:16 --> Form Validation Class Initialized
INFO - 2018-02-07 14:13:16 --> Model Class Initialized
INFO - 2018-02-07 14:13:16 --> Controller Class Initialized
DEBUG - 2018-02-07 14:13:16 --> Config file loaded: /var/www/html/spamblocker/application/config/rest.php
INFO - 2018-02-07 14:13:16 --> Helper loaded: inflector_helper
INFO - 2018-02-07 14:13:16 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 14:13:16 --> Model Class Initialized
INFO - 2018-02-07 14:13:16 --> Model Class Initialized
INFO - 2018-02-07 14:13:30 --> Config Class Initialized
INFO - 2018-02-07 14:13:30 --> Hooks Class Initialized
DEBUG - 2018-02-07 14:13:30 --> UTF-8 Support Enabled
INFO - 2018-02-07 14:13:30 --> Utf8 Class Initialized
INFO - 2018-02-07 14:13:30 --> URI Class Initialized
INFO - 2018-02-07 14:13:30 --> Router Class Initialized
INFO - 2018-02-07 14:13:30 --> Output Class Initialized
INFO - 2018-02-07 14:13:30 --> Security Class Initialized
DEBUG - 2018-02-07 14:13:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 14:13:30 --> Input Class Initialized
INFO - 2018-02-07 14:13:30 --> Language Class Initialized
INFO - 2018-02-07 14:13:30 --> Loader Class Initialized
INFO - 2018-02-07 14:13:30 --> Helper loaded: url_helper
INFO - 2018-02-07 14:13:30 --> Helper loaded: file_helper
INFO - 2018-02-07 14:13:30 --> Helper loaded: email_helper
INFO - 2018-02-07 14:13:30 --> Helper loaded: common_helper
INFO - 2018-02-07 14:13:30 --> Database Driver Class Initialized
DEBUG - 2018-02-07 14:13:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 14:13:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 14:13:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-07 14:13:30 --> Pagination Class Initialized
INFO - 2018-02-07 14:13:30 --> Helper loaded: form_helper
INFO - 2018-02-07 14:13:30 --> Form Validation Class Initialized
INFO - 2018-02-07 14:13:30 --> Model Class Initialized
INFO - 2018-02-07 14:13:30 --> Controller Class Initialized
DEBUG - 2018-02-07 14:13:30 --> Config file loaded: /var/www/html/spamblocker/application/config/rest.php
INFO - 2018-02-07 14:13:30 --> Helper loaded: inflector_helper
INFO - 2018-02-07 14:13:30 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 14:13:30 --> Model Class Initialized
INFO - 2018-02-07 14:13:30 --> Model Class Initialized
INFO - 2018-02-07 14:16:51 --> Config Class Initialized
INFO - 2018-02-07 14:16:51 --> Hooks Class Initialized
DEBUG - 2018-02-07 14:16:51 --> UTF-8 Support Enabled
INFO - 2018-02-07 14:16:51 --> Utf8 Class Initialized
INFO - 2018-02-07 14:16:51 --> URI Class Initialized
INFO - 2018-02-07 14:16:51 --> Router Class Initialized
INFO - 2018-02-07 14:16:51 --> Output Class Initialized
INFO - 2018-02-07 14:16:51 --> Security Class Initialized
DEBUG - 2018-02-07 14:16:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 14:16:51 --> Input Class Initialized
INFO - 2018-02-07 14:16:51 --> Language Class Initialized
INFO - 2018-02-07 14:16:51 --> Loader Class Initialized
INFO - 2018-02-07 14:16:51 --> Helper loaded: url_helper
INFO - 2018-02-07 14:16:51 --> Helper loaded: file_helper
INFO - 2018-02-07 14:16:51 --> Helper loaded: email_helper
INFO - 2018-02-07 14:16:51 --> Helper loaded: common_helper
INFO - 2018-02-07 14:16:51 --> Database Driver Class Initialized
DEBUG - 2018-02-07 14:16:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 14:16:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 14:16:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-07 14:16:51 --> Pagination Class Initialized
INFO - 2018-02-07 14:16:51 --> Helper loaded: form_helper
INFO - 2018-02-07 14:16:51 --> Form Validation Class Initialized
INFO - 2018-02-07 14:16:51 --> Model Class Initialized
INFO - 2018-02-07 14:16:51 --> Controller Class Initialized
DEBUG - 2018-02-07 14:16:51 --> Config file loaded: /var/www/html/spamblocker/application/config/rest.php
INFO - 2018-02-07 14:16:51 --> Helper loaded: inflector_helper
INFO - 2018-02-07 14:16:51 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 14:16:51 --> Model Class Initialized
INFO - 2018-02-07 14:16:51 --> Model Class Initialized
INFO - 2018-02-07 14:18:33 --> Config Class Initialized
INFO - 2018-02-07 14:18:33 --> Hooks Class Initialized
DEBUG - 2018-02-07 14:18:33 --> UTF-8 Support Enabled
INFO - 2018-02-07 14:18:33 --> Utf8 Class Initialized
INFO - 2018-02-07 14:18:33 --> URI Class Initialized
INFO - 2018-02-07 14:18:33 --> Router Class Initialized
INFO - 2018-02-07 14:18:33 --> Output Class Initialized
INFO - 2018-02-07 14:18:33 --> Security Class Initialized
DEBUG - 2018-02-07 14:18:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 14:18:33 --> Input Class Initialized
INFO - 2018-02-07 14:18:33 --> Language Class Initialized
INFO - 2018-02-07 14:18:33 --> Loader Class Initialized
INFO - 2018-02-07 14:18:33 --> Helper loaded: url_helper
INFO - 2018-02-07 14:18:33 --> Helper loaded: file_helper
INFO - 2018-02-07 14:18:33 --> Helper loaded: email_helper
INFO - 2018-02-07 14:18:33 --> Helper loaded: common_helper
INFO - 2018-02-07 14:18:33 --> Database Driver Class Initialized
DEBUG - 2018-02-07 14:18:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 14:18:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 14:18:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-07 14:18:33 --> Pagination Class Initialized
INFO - 2018-02-07 14:18:33 --> Helper loaded: form_helper
INFO - 2018-02-07 14:18:33 --> Form Validation Class Initialized
INFO - 2018-02-07 14:18:33 --> Model Class Initialized
INFO - 2018-02-07 14:18:33 --> Controller Class Initialized
DEBUG - 2018-02-07 14:18:33 --> Config file loaded: /var/www/html/spamblocker/application/config/rest.php
INFO - 2018-02-07 14:18:33 --> Helper loaded: inflector_helper
INFO - 2018-02-07 14:18:33 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 14:18:33 --> Model Class Initialized
INFO - 2018-02-07 14:18:33 --> Model Class Initialized
INFO - 2018-02-07 14:19:11 --> Config Class Initialized
INFO - 2018-02-07 14:19:11 --> Hooks Class Initialized
DEBUG - 2018-02-07 14:19:11 --> UTF-8 Support Enabled
INFO - 2018-02-07 14:19:11 --> Utf8 Class Initialized
INFO - 2018-02-07 14:19:11 --> URI Class Initialized
INFO - 2018-02-07 14:19:11 --> Router Class Initialized
INFO - 2018-02-07 14:19:11 --> Output Class Initialized
INFO - 2018-02-07 14:19:11 --> Security Class Initialized
DEBUG - 2018-02-07 14:19:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 14:19:11 --> Input Class Initialized
INFO - 2018-02-07 14:19:11 --> Language Class Initialized
INFO - 2018-02-07 14:19:11 --> Loader Class Initialized
INFO - 2018-02-07 14:19:11 --> Helper loaded: url_helper
INFO - 2018-02-07 14:19:11 --> Helper loaded: file_helper
INFO - 2018-02-07 14:19:11 --> Helper loaded: email_helper
INFO - 2018-02-07 14:19:11 --> Helper loaded: common_helper
INFO - 2018-02-07 14:19:11 --> Database Driver Class Initialized
DEBUG - 2018-02-07 14:19:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 14:19:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 14:19:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-07 14:19:11 --> Pagination Class Initialized
INFO - 2018-02-07 14:19:11 --> Helper loaded: form_helper
INFO - 2018-02-07 14:19:11 --> Form Validation Class Initialized
INFO - 2018-02-07 14:19:11 --> Model Class Initialized
INFO - 2018-02-07 14:19:11 --> Controller Class Initialized
DEBUG - 2018-02-07 14:19:11 --> Config file loaded: /var/www/html/spamblocker/application/config/rest.php
INFO - 2018-02-07 14:19:11 --> Helper loaded: inflector_helper
INFO - 2018-02-07 14:19:11 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 14:19:11 --> Model Class Initialized
INFO - 2018-02-07 14:19:11 --> Model Class Initialized
INFO - 2018-02-07 14:41:20 --> Config Class Initialized
INFO - 2018-02-07 14:41:20 --> Hooks Class Initialized
DEBUG - 2018-02-07 14:41:20 --> UTF-8 Support Enabled
INFO - 2018-02-07 14:41:20 --> Utf8 Class Initialized
INFO - 2018-02-07 14:41:20 --> URI Class Initialized
INFO - 2018-02-07 14:41:20 --> Router Class Initialized
INFO - 2018-02-07 14:41:20 --> Output Class Initialized
INFO - 2018-02-07 14:41:20 --> Security Class Initialized
DEBUG - 2018-02-07 14:41:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 14:41:20 --> Input Class Initialized
INFO - 2018-02-07 14:41:20 --> Language Class Initialized
INFO - 2018-02-07 14:41:20 --> Loader Class Initialized
INFO - 2018-02-07 14:41:20 --> Helper loaded: url_helper
INFO - 2018-02-07 14:41:20 --> Helper loaded: file_helper
INFO - 2018-02-07 14:41:20 --> Helper loaded: email_helper
INFO - 2018-02-07 14:41:20 --> Helper loaded: common_helper
INFO - 2018-02-07 14:41:20 --> Database Driver Class Initialized
DEBUG - 2018-02-07 14:41:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 14:41:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 14:41:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-07 14:41:20 --> Pagination Class Initialized
INFO - 2018-02-07 14:41:20 --> Helper loaded: form_helper
INFO - 2018-02-07 14:41:20 --> Form Validation Class Initialized
INFO - 2018-02-07 14:41:20 --> Model Class Initialized
INFO - 2018-02-07 14:41:20 --> Controller Class Initialized
DEBUG - 2018-02-07 14:41:20 --> Config file loaded: /var/www/html/spamblocker/application/config/rest.php
INFO - 2018-02-07 14:41:20 --> Helper loaded: inflector_helper
INFO - 2018-02-07 14:41:20 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 14:41:20 --> Model Class Initialized
INFO - 2018-02-07 14:41:20 --> Model Class Initialized
INFO - 2018-02-07 14:44:48 --> Config Class Initialized
INFO - 2018-02-07 14:44:48 --> Hooks Class Initialized
DEBUG - 2018-02-07 14:44:48 --> UTF-8 Support Enabled
INFO - 2018-02-07 14:44:48 --> Utf8 Class Initialized
INFO - 2018-02-07 14:44:48 --> URI Class Initialized
INFO - 2018-02-07 14:44:48 --> Router Class Initialized
INFO - 2018-02-07 14:44:48 --> Output Class Initialized
INFO - 2018-02-07 14:44:48 --> Security Class Initialized
DEBUG - 2018-02-07 14:44:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 14:44:48 --> Input Class Initialized
INFO - 2018-02-07 14:44:48 --> Language Class Initialized
INFO - 2018-02-07 14:44:48 --> Loader Class Initialized
INFO - 2018-02-07 14:44:48 --> Helper loaded: url_helper
INFO - 2018-02-07 14:44:48 --> Helper loaded: file_helper
INFO - 2018-02-07 14:44:48 --> Helper loaded: email_helper
INFO - 2018-02-07 14:44:48 --> Helper loaded: common_helper
INFO - 2018-02-07 14:44:48 --> Database Driver Class Initialized
DEBUG - 2018-02-07 14:44:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 14:44:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 14:44:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-07 14:44:48 --> Pagination Class Initialized
INFO - 2018-02-07 14:44:48 --> Helper loaded: form_helper
INFO - 2018-02-07 14:44:48 --> Form Validation Class Initialized
INFO - 2018-02-07 14:44:48 --> Model Class Initialized
INFO - 2018-02-07 14:44:48 --> Controller Class Initialized
DEBUG - 2018-02-07 14:44:48 --> Config file loaded: /var/www/html/spamblocker/application/config/rest.php
INFO - 2018-02-07 14:44:48 --> Helper loaded: inflector_helper
INFO - 2018-02-07 14:44:48 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 14:44:48 --> Model Class Initialized
INFO - 2018-02-07 14:44:48 --> Model Class Initialized
ERROR - 2018-02-07 14:44:48 --> Severity: Notice --> Use of undefined constant DOC_ROOT - assumed 'DOC_ROOT' /var/www/html/spamblocker/application/controllers/api/Oauth.php 511
INFO - 2018-02-07 14:45:57 --> Config Class Initialized
INFO - 2018-02-07 14:45:57 --> Hooks Class Initialized
DEBUG - 2018-02-07 14:45:57 --> UTF-8 Support Enabled
INFO - 2018-02-07 14:45:57 --> Utf8 Class Initialized
INFO - 2018-02-07 14:45:57 --> URI Class Initialized
INFO - 2018-02-07 14:45:57 --> Router Class Initialized
INFO - 2018-02-07 14:45:57 --> Output Class Initialized
INFO - 2018-02-07 14:45:57 --> Security Class Initialized
DEBUG - 2018-02-07 14:45:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 14:45:57 --> Input Class Initialized
INFO - 2018-02-07 14:45:57 --> Language Class Initialized
INFO - 2018-02-07 14:45:57 --> Loader Class Initialized
INFO - 2018-02-07 14:45:57 --> Helper loaded: url_helper
INFO - 2018-02-07 14:45:57 --> Helper loaded: file_helper
INFO - 2018-02-07 14:45:57 --> Helper loaded: email_helper
INFO - 2018-02-07 14:45:57 --> Helper loaded: common_helper
INFO - 2018-02-07 14:45:57 --> Database Driver Class Initialized
DEBUG - 2018-02-07 14:45:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 14:45:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 14:45:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-07 14:45:57 --> Pagination Class Initialized
INFO - 2018-02-07 14:45:57 --> Helper loaded: form_helper
INFO - 2018-02-07 14:45:57 --> Form Validation Class Initialized
INFO - 2018-02-07 14:45:57 --> Model Class Initialized
INFO - 2018-02-07 14:45:57 --> Controller Class Initialized
DEBUG - 2018-02-07 14:45:57 --> Config file loaded: /var/www/html/spamblocker/application/config/rest.php
INFO - 2018-02-07 14:45:57 --> Helper loaded: inflector_helper
INFO - 2018-02-07 14:45:57 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 14:45:57 --> Model Class Initialized
INFO - 2018-02-07 14:45:57 --> Model Class Initialized
INFO - 2018-02-07 15:17:45 --> Config Class Initialized
INFO - 2018-02-07 15:17:45 --> Hooks Class Initialized
DEBUG - 2018-02-07 15:17:45 --> UTF-8 Support Enabled
INFO - 2018-02-07 15:17:45 --> Utf8 Class Initialized
INFO - 2018-02-07 15:17:45 --> URI Class Initialized
INFO - 2018-02-07 15:17:45 --> Router Class Initialized
INFO - 2018-02-07 15:17:45 --> Output Class Initialized
INFO - 2018-02-07 15:17:45 --> Security Class Initialized
DEBUG - 2018-02-07 15:17:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 15:17:45 --> Input Class Initialized
INFO - 2018-02-07 15:17:45 --> Language Class Initialized
INFO - 2018-02-07 15:17:45 --> Loader Class Initialized
INFO - 2018-02-07 15:17:45 --> Helper loaded: url_helper
INFO - 2018-02-07 15:17:45 --> Helper loaded: file_helper
INFO - 2018-02-07 15:17:45 --> Helper loaded: email_helper
INFO - 2018-02-07 15:17:45 --> Helper loaded: common_helper
INFO - 2018-02-07 15:17:45 --> Database Driver Class Initialized
DEBUG - 2018-02-07 15:17:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 15:17:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 15:17:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-07 15:17:45 --> Pagination Class Initialized
INFO - 2018-02-07 15:17:45 --> Helper loaded: form_helper
INFO - 2018-02-07 15:17:45 --> Form Validation Class Initialized
INFO - 2018-02-07 15:17:45 --> Model Class Initialized
INFO - 2018-02-07 15:17:45 --> Controller Class Initialized
DEBUG - 2018-02-07 15:17:45 --> Config file loaded: /var/www/html/spamblocker/application/config/rest.php
INFO - 2018-02-07 15:17:45 --> Helper loaded: inflector_helper
INFO - 2018-02-07 15:17:45 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 15:17:45 --> Model Class Initialized
INFO - 2018-02-07 15:17:45 --> Model Class Initialized
INFO - 2018-02-07 15:17:45 --> Final output sent to browser
DEBUG - 2018-02-07 15:17:45 --> Total execution time: 0.0070
INFO - 2018-02-07 15:18:25 --> Config Class Initialized
INFO - 2018-02-07 15:18:25 --> Hooks Class Initialized
DEBUG - 2018-02-07 15:18:25 --> UTF-8 Support Enabled
INFO - 2018-02-07 15:18:25 --> Utf8 Class Initialized
INFO - 2018-02-07 15:18:25 --> URI Class Initialized
INFO - 2018-02-07 15:18:25 --> Router Class Initialized
INFO - 2018-02-07 15:18:25 --> Output Class Initialized
INFO - 2018-02-07 15:18:25 --> Security Class Initialized
DEBUG - 2018-02-07 15:18:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 15:18:25 --> Input Class Initialized
INFO - 2018-02-07 15:18:25 --> Language Class Initialized
INFO - 2018-02-07 15:18:25 --> Loader Class Initialized
INFO - 2018-02-07 15:18:25 --> Helper loaded: url_helper
INFO - 2018-02-07 15:18:25 --> Helper loaded: file_helper
INFO - 2018-02-07 15:18:25 --> Helper loaded: email_helper
INFO - 2018-02-07 15:18:25 --> Helper loaded: common_helper
INFO - 2018-02-07 15:18:25 --> Database Driver Class Initialized
DEBUG - 2018-02-07 15:18:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 15:18:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 15:18:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-07 15:18:25 --> Pagination Class Initialized
INFO - 2018-02-07 15:18:25 --> Helper loaded: form_helper
INFO - 2018-02-07 15:18:25 --> Form Validation Class Initialized
INFO - 2018-02-07 15:18:25 --> Model Class Initialized
INFO - 2018-02-07 15:18:25 --> Controller Class Initialized
DEBUG - 2018-02-07 15:18:25 --> Config file loaded: /var/www/html/spamblocker/application/config/rest.php
INFO - 2018-02-07 15:18:25 --> Helper loaded: inflector_helper
INFO - 2018-02-07 15:18:25 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 15:18:25 --> Model Class Initialized
INFO - 2018-02-07 15:18:25 --> Model Class Initialized
INFO - 2018-02-07 15:18:25 --> Final output sent to browser
DEBUG - 2018-02-07 15:18:25 --> Total execution time: 0.0444
INFO - 2018-02-07 15:18:38 --> Config Class Initialized
INFO - 2018-02-07 15:18:38 --> Hooks Class Initialized
DEBUG - 2018-02-07 15:18:38 --> UTF-8 Support Enabled
INFO - 2018-02-07 15:18:38 --> Utf8 Class Initialized
INFO - 2018-02-07 15:18:38 --> URI Class Initialized
INFO - 2018-02-07 15:18:38 --> Router Class Initialized
INFO - 2018-02-07 15:18:38 --> Output Class Initialized
INFO - 2018-02-07 15:18:38 --> Security Class Initialized
DEBUG - 2018-02-07 15:18:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 15:18:38 --> Input Class Initialized
INFO - 2018-02-07 15:18:38 --> Language Class Initialized
INFO - 2018-02-07 15:18:38 --> Loader Class Initialized
INFO - 2018-02-07 15:18:38 --> Helper loaded: url_helper
INFO - 2018-02-07 15:18:38 --> Helper loaded: file_helper
INFO - 2018-02-07 15:18:38 --> Helper loaded: email_helper
INFO - 2018-02-07 15:18:38 --> Helper loaded: common_helper
INFO - 2018-02-07 15:18:38 --> Database Driver Class Initialized
DEBUG - 2018-02-07 15:18:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 15:18:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 15:18:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-07 15:18:38 --> Pagination Class Initialized
INFO - 2018-02-07 15:18:38 --> Helper loaded: form_helper
INFO - 2018-02-07 15:18:38 --> Form Validation Class Initialized
INFO - 2018-02-07 15:18:38 --> Model Class Initialized
INFO - 2018-02-07 15:18:38 --> Controller Class Initialized
DEBUG - 2018-02-07 15:18:38 --> Config file loaded: /var/www/html/spamblocker/application/config/rest.php
INFO - 2018-02-07 15:18:38 --> Helper loaded: inflector_helper
INFO - 2018-02-07 15:18:38 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 15:18:38 --> Model Class Initialized
INFO - 2018-02-07 15:18:38 --> Model Class Initialized
INFO - 2018-02-07 15:18:38 --> Final output sent to browser
DEBUG - 2018-02-07 15:18:38 --> Total execution time: 0.0049
INFO - 2018-02-07 15:18:56 --> Config Class Initialized
INFO - 2018-02-07 15:18:56 --> Hooks Class Initialized
DEBUG - 2018-02-07 15:18:56 --> UTF-8 Support Enabled
INFO - 2018-02-07 15:18:56 --> Utf8 Class Initialized
INFO - 2018-02-07 15:18:56 --> URI Class Initialized
INFO - 2018-02-07 15:18:56 --> Router Class Initialized
INFO - 2018-02-07 15:18:56 --> Output Class Initialized
INFO - 2018-02-07 15:18:56 --> Security Class Initialized
DEBUG - 2018-02-07 15:18:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 15:18:56 --> Input Class Initialized
INFO - 2018-02-07 15:18:56 --> Language Class Initialized
INFO - 2018-02-07 15:18:56 --> Loader Class Initialized
INFO - 2018-02-07 15:18:56 --> Helper loaded: url_helper
INFO - 2018-02-07 15:18:56 --> Helper loaded: file_helper
INFO - 2018-02-07 15:18:56 --> Helper loaded: email_helper
INFO - 2018-02-07 15:18:56 --> Helper loaded: common_helper
INFO - 2018-02-07 15:18:56 --> Database Driver Class Initialized
DEBUG - 2018-02-07 15:18:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 15:18:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 15:18:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-07 15:18:56 --> Pagination Class Initialized
INFO - 2018-02-07 15:18:56 --> Helper loaded: form_helper
INFO - 2018-02-07 15:18:56 --> Form Validation Class Initialized
INFO - 2018-02-07 15:18:56 --> Model Class Initialized
INFO - 2018-02-07 15:18:56 --> Controller Class Initialized
DEBUG - 2018-02-07 15:18:56 --> Config file loaded: /var/www/html/spamblocker/application/config/rest.php
INFO - 2018-02-07 15:18:56 --> Helper loaded: inflector_helper
INFO - 2018-02-07 15:18:56 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 15:18:56 --> Model Class Initialized
INFO - 2018-02-07 15:18:56 --> Model Class Initialized
INFO - 2018-02-07 15:18:56 --> Final output sent to browser
DEBUG - 2018-02-07 15:18:56 --> Total execution time: 0.0355
INFO - 2018-02-07 15:19:57 --> Config Class Initialized
INFO - 2018-02-07 15:19:57 --> Hooks Class Initialized
DEBUG - 2018-02-07 15:19:57 --> UTF-8 Support Enabled
INFO - 2018-02-07 15:19:57 --> Utf8 Class Initialized
INFO - 2018-02-07 15:19:57 --> URI Class Initialized
INFO - 2018-02-07 15:19:57 --> Router Class Initialized
INFO - 2018-02-07 15:19:57 --> Output Class Initialized
INFO - 2018-02-07 15:19:57 --> Security Class Initialized
DEBUG - 2018-02-07 15:19:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 15:19:57 --> Input Class Initialized
INFO - 2018-02-07 15:19:57 --> Language Class Initialized
INFO - 2018-02-07 15:19:57 --> Loader Class Initialized
INFO - 2018-02-07 15:19:57 --> Helper loaded: url_helper
INFO - 2018-02-07 15:19:57 --> Helper loaded: file_helper
INFO - 2018-02-07 15:19:57 --> Helper loaded: email_helper
INFO - 2018-02-07 15:19:57 --> Helper loaded: common_helper
INFO - 2018-02-07 15:19:57 --> Database Driver Class Initialized
DEBUG - 2018-02-07 15:19:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 15:19:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 15:19:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-07 15:19:57 --> Pagination Class Initialized
INFO - 2018-02-07 15:19:57 --> Helper loaded: form_helper
INFO - 2018-02-07 15:19:57 --> Form Validation Class Initialized
INFO - 2018-02-07 15:19:57 --> Model Class Initialized
INFO - 2018-02-07 15:19:57 --> Controller Class Initialized
DEBUG - 2018-02-07 15:19:57 --> Config file loaded: /var/www/html/spamblocker/application/config/rest.php
INFO - 2018-02-07 15:19:57 --> Helper loaded: inflector_helper
INFO - 2018-02-07 15:19:57 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 15:19:57 --> Model Class Initialized
INFO - 2018-02-07 15:19:57 --> Model Class Initialized
INFO - 2018-02-07 15:20:14 --> Config Class Initialized
INFO - 2018-02-07 15:20:14 --> Hooks Class Initialized
DEBUG - 2018-02-07 15:20:14 --> UTF-8 Support Enabled
INFO - 2018-02-07 15:20:14 --> Utf8 Class Initialized
INFO - 2018-02-07 15:20:14 --> URI Class Initialized
INFO - 2018-02-07 15:20:14 --> Router Class Initialized
INFO - 2018-02-07 15:20:14 --> Output Class Initialized
INFO - 2018-02-07 15:20:14 --> Security Class Initialized
DEBUG - 2018-02-07 15:20:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 15:20:14 --> Input Class Initialized
INFO - 2018-02-07 15:20:14 --> Language Class Initialized
INFO - 2018-02-07 15:20:14 --> Loader Class Initialized
INFO - 2018-02-07 15:20:14 --> Helper loaded: url_helper
INFO - 2018-02-07 15:20:14 --> Helper loaded: file_helper
INFO - 2018-02-07 15:20:14 --> Helper loaded: email_helper
INFO - 2018-02-07 15:20:14 --> Helper loaded: common_helper
INFO - 2018-02-07 15:20:14 --> Database Driver Class Initialized
DEBUG - 2018-02-07 15:20:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 15:20:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 15:20:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-07 15:20:14 --> Pagination Class Initialized
INFO - 2018-02-07 15:20:14 --> Helper loaded: form_helper
INFO - 2018-02-07 15:20:14 --> Form Validation Class Initialized
INFO - 2018-02-07 15:20:14 --> Model Class Initialized
INFO - 2018-02-07 15:20:14 --> Controller Class Initialized
DEBUG - 2018-02-07 15:20:14 --> Config file loaded: /var/www/html/spamblocker/application/config/rest.php
INFO - 2018-02-07 15:20:14 --> Helper loaded: inflector_helper
INFO - 2018-02-07 15:20:14 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 15:20:14 --> Model Class Initialized
INFO - 2018-02-07 15:20:14 --> Model Class Initialized
INFO - 2018-02-07 15:20:14 --> Final output sent to browser
DEBUG - 2018-02-07 15:20:14 --> Total execution time: 0.0507
INFO - 2018-02-07 15:20:50 --> Config Class Initialized
INFO - 2018-02-07 15:20:50 --> Hooks Class Initialized
DEBUG - 2018-02-07 15:20:50 --> UTF-8 Support Enabled
INFO - 2018-02-07 15:20:50 --> Utf8 Class Initialized
INFO - 2018-02-07 15:20:50 --> URI Class Initialized
INFO - 2018-02-07 15:20:50 --> Router Class Initialized
INFO - 2018-02-07 15:20:50 --> Output Class Initialized
INFO - 2018-02-07 15:20:50 --> Security Class Initialized
DEBUG - 2018-02-07 15:20:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 15:20:50 --> Input Class Initialized
INFO - 2018-02-07 15:20:50 --> Language Class Initialized
INFO - 2018-02-07 15:20:50 --> Loader Class Initialized
INFO - 2018-02-07 15:20:50 --> Helper loaded: url_helper
INFO - 2018-02-07 15:20:50 --> Helper loaded: file_helper
INFO - 2018-02-07 15:20:50 --> Helper loaded: email_helper
INFO - 2018-02-07 15:20:50 --> Helper loaded: common_helper
INFO - 2018-02-07 15:20:50 --> Database Driver Class Initialized
DEBUG - 2018-02-07 15:20:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 15:20:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 15:20:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-07 15:20:50 --> Pagination Class Initialized
INFO - 2018-02-07 15:20:50 --> Helper loaded: form_helper
INFO - 2018-02-07 15:20:50 --> Form Validation Class Initialized
INFO - 2018-02-07 15:20:50 --> Model Class Initialized
INFO - 2018-02-07 15:20:50 --> Controller Class Initialized
DEBUG - 2018-02-07 15:20:50 --> Config file loaded: /var/www/html/spamblocker/application/config/rest.php
INFO - 2018-02-07 15:20:50 --> Helper loaded: inflector_helper
INFO - 2018-02-07 15:20:50 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 15:20:50 --> Model Class Initialized
INFO - 2018-02-07 15:20:50 --> Model Class Initialized
ERROR - 2018-02-07 15:20:50 --> Severity: Notice --> Undefined offset: 0 /var/www/html/spamblocker/application/controllers/api/Oauth.php 559
INFO - 2018-02-07 15:21:12 --> Config Class Initialized
INFO - 2018-02-07 15:21:12 --> Hooks Class Initialized
DEBUG - 2018-02-07 15:21:12 --> UTF-8 Support Enabled
INFO - 2018-02-07 15:21:12 --> Utf8 Class Initialized
INFO - 2018-02-07 15:21:12 --> URI Class Initialized
INFO - 2018-02-07 15:21:12 --> Router Class Initialized
INFO - 2018-02-07 15:21:12 --> Output Class Initialized
INFO - 2018-02-07 15:21:12 --> Security Class Initialized
DEBUG - 2018-02-07 15:21:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 15:21:12 --> Input Class Initialized
INFO - 2018-02-07 15:21:12 --> Language Class Initialized
INFO - 2018-02-07 15:21:12 --> Loader Class Initialized
INFO - 2018-02-07 15:21:12 --> Helper loaded: url_helper
INFO - 2018-02-07 15:21:12 --> Helper loaded: file_helper
INFO - 2018-02-07 15:21:12 --> Helper loaded: email_helper
INFO - 2018-02-07 15:21:12 --> Helper loaded: common_helper
INFO - 2018-02-07 15:21:12 --> Database Driver Class Initialized
DEBUG - 2018-02-07 15:21:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 15:21:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 15:21:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-07 15:21:12 --> Pagination Class Initialized
INFO - 2018-02-07 15:21:12 --> Helper loaded: form_helper
INFO - 2018-02-07 15:21:12 --> Form Validation Class Initialized
INFO - 2018-02-07 15:21:12 --> Model Class Initialized
INFO - 2018-02-07 15:21:12 --> Controller Class Initialized
DEBUG - 2018-02-07 15:21:12 --> Config file loaded: /var/www/html/spamblocker/application/config/rest.php
INFO - 2018-02-07 15:21:12 --> Helper loaded: inflector_helper
INFO - 2018-02-07 15:21:12 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 15:21:12 --> Model Class Initialized
INFO - 2018-02-07 15:21:12 --> Model Class Initialized
INFO - 2018-02-07 15:21:21 --> Config Class Initialized
INFO - 2018-02-07 15:21:21 --> Hooks Class Initialized
DEBUG - 2018-02-07 15:21:21 --> UTF-8 Support Enabled
INFO - 2018-02-07 15:21:21 --> Utf8 Class Initialized
INFO - 2018-02-07 15:21:21 --> URI Class Initialized
INFO - 2018-02-07 15:21:21 --> Router Class Initialized
INFO - 2018-02-07 15:21:21 --> Output Class Initialized
INFO - 2018-02-07 15:21:21 --> Security Class Initialized
DEBUG - 2018-02-07 15:21:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 15:21:21 --> Input Class Initialized
INFO - 2018-02-07 15:21:21 --> Language Class Initialized
INFO - 2018-02-07 15:21:21 --> Loader Class Initialized
INFO - 2018-02-07 15:21:21 --> Helper loaded: url_helper
INFO - 2018-02-07 15:21:21 --> Helper loaded: file_helper
INFO - 2018-02-07 15:21:21 --> Helper loaded: email_helper
INFO - 2018-02-07 15:21:21 --> Helper loaded: common_helper
INFO - 2018-02-07 15:21:21 --> Database Driver Class Initialized
DEBUG - 2018-02-07 15:21:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 15:21:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 15:21:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-07 15:21:21 --> Pagination Class Initialized
INFO - 2018-02-07 15:21:21 --> Helper loaded: form_helper
INFO - 2018-02-07 15:21:21 --> Form Validation Class Initialized
INFO - 2018-02-07 15:21:21 --> Model Class Initialized
INFO - 2018-02-07 15:21:21 --> Controller Class Initialized
DEBUG - 2018-02-07 15:21:21 --> Config file loaded: /var/www/html/spamblocker/application/config/rest.php
INFO - 2018-02-07 15:21:21 --> Helper loaded: inflector_helper
INFO - 2018-02-07 15:21:21 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 15:21:21 --> Model Class Initialized
INFO - 2018-02-07 15:21:21 --> Model Class Initialized
INFO - 2018-02-07 15:21:34 --> Config Class Initialized
INFO - 2018-02-07 15:21:34 --> Hooks Class Initialized
DEBUG - 2018-02-07 15:21:34 --> UTF-8 Support Enabled
INFO - 2018-02-07 15:21:34 --> Utf8 Class Initialized
INFO - 2018-02-07 15:21:34 --> URI Class Initialized
INFO - 2018-02-07 15:21:34 --> Router Class Initialized
INFO - 2018-02-07 15:21:34 --> Output Class Initialized
INFO - 2018-02-07 15:21:34 --> Security Class Initialized
DEBUG - 2018-02-07 15:21:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 15:21:34 --> Input Class Initialized
INFO - 2018-02-07 15:21:34 --> Language Class Initialized
INFO - 2018-02-07 15:21:34 --> Loader Class Initialized
INFO - 2018-02-07 15:21:34 --> Helper loaded: url_helper
INFO - 2018-02-07 15:21:34 --> Helper loaded: file_helper
INFO - 2018-02-07 15:21:34 --> Helper loaded: email_helper
INFO - 2018-02-07 15:21:34 --> Helper loaded: common_helper
INFO - 2018-02-07 15:21:34 --> Database Driver Class Initialized
DEBUG - 2018-02-07 15:21:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 15:21:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 15:21:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-07 15:21:34 --> Pagination Class Initialized
INFO - 2018-02-07 15:21:34 --> Helper loaded: form_helper
INFO - 2018-02-07 15:21:34 --> Form Validation Class Initialized
INFO - 2018-02-07 15:21:34 --> Model Class Initialized
INFO - 2018-02-07 15:21:34 --> Controller Class Initialized
DEBUG - 2018-02-07 15:21:34 --> Config file loaded: /var/www/html/spamblocker/application/config/rest.php
INFO - 2018-02-07 15:21:34 --> Helper loaded: inflector_helper
INFO - 2018-02-07 15:21:34 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 15:21:34 --> Model Class Initialized
INFO - 2018-02-07 15:21:34 --> Model Class Initialized
INFO - 2018-02-07 15:21:34 --> Upload Class Initialized
INFO - 2018-02-07 15:21:34 --> Language file loaded: language/english/upload_lang.php
ERROR - 2018-02-07 15:21:34 --> The upload path does not appear to be valid.
ERROR - 2018-02-07 15:21:34 --> Severity: Notice --> Undefined index: status /var/www/html/spamblocker/application/controllers/api/Oauth.php 564
INFO - 2018-02-07 15:21:34 --> Final output sent to browser
DEBUG - 2018-02-07 15:21:34 --> Total execution time: 0.0090
INFO - 2018-02-07 15:23:02 --> Config Class Initialized
INFO - 2018-02-07 15:23:02 --> Hooks Class Initialized
DEBUG - 2018-02-07 15:23:02 --> UTF-8 Support Enabled
INFO - 2018-02-07 15:23:02 --> Utf8 Class Initialized
INFO - 2018-02-07 15:23:02 --> URI Class Initialized
INFO - 2018-02-07 15:23:02 --> Router Class Initialized
INFO - 2018-02-07 15:23:02 --> Output Class Initialized
INFO - 2018-02-07 15:23:02 --> Security Class Initialized
DEBUG - 2018-02-07 15:23:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 15:23:02 --> Input Class Initialized
INFO - 2018-02-07 15:23:02 --> Language Class Initialized
INFO - 2018-02-07 15:23:02 --> Loader Class Initialized
INFO - 2018-02-07 15:23:02 --> Helper loaded: url_helper
INFO - 2018-02-07 15:23:02 --> Helper loaded: file_helper
INFO - 2018-02-07 15:23:02 --> Helper loaded: email_helper
INFO - 2018-02-07 15:23:02 --> Helper loaded: common_helper
INFO - 2018-02-07 15:23:02 --> Database Driver Class Initialized
DEBUG - 2018-02-07 15:23:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 15:23:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 15:23:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-07 15:23:02 --> Pagination Class Initialized
INFO - 2018-02-07 15:23:02 --> Helper loaded: form_helper
INFO - 2018-02-07 15:23:02 --> Form Validation Class Initialized
INFO - 2018-02-07 15:23:02 --> Model Class Initialized
INFO - 2018-02-07 15:23:02 --> Controller Class Initialized
DEBUG - 2018-02-07 15:23:02 --> Config file loaded: /var/www/html/spamblocker/application/config/rest.php
INFO - 2018-02-07 15:23:02 --> Helper loaded: inflector_helper
INFO - 2018-02-07 15:23:02 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 15:23:02 --> Model Class Initialized
INFO - 2018-02-07 15:23:02 --> Model Class Initialized
INFO - 2018-02-07 15:23:02 --> Upload Class Initialized
INFO - 2018-02-07 15:23:02 --> Language file loaded: language/english/upload_lang.php
ERROR - 2018-02-07 15:23:02 --> The upload path does not appear to be valid.
INFO - 2018-02-07 15:24:23 --> Config Class Initialized
INFO - 2018-02-07 15:24:23 --> Hooks Class Initialized
DEBUG - 2018-02-07 15:24:23 --> UTF-8 Support Enabled
INFO - 2018-02-07 15:24:23 --> Utf8 Class Initialized
INFO - 2018-02-07 15:24:23 --> URI Class Initialized
INFO - 2018-02-07 15:24:23 --> Router Class Initialized
INFO - 2018-02-07 15:24:23 --> Output Class Initialized
INFO - 2018-02-07 15:24:23 --> Security Class Initialized
DEBUG - 2018-02-07 15:24:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 15:24:23 --> Input Class Initialized
INFO - 2018-02-07 15:24:23 --> Language Class Initialized
INFO - 2018-02-07 15:24:23 --> Loader Class Initialized
INFO - 2018-02-07 15:24:23 --> Helper loaded: url_helper
INFO - 2018-02-07 15:24:23 --> Helper loaded: file_helper
INFO - 2018-02-07 15:24:23 --> Helper loaded: email_helper
INFO - 2018-02-07 15:24:23 --> Helper loaded: common_helper
INFO - 2018-02-07 15:24:23 --> Database Driver Class Initialized
DEBUG - 2018-02-07 15:24:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 15:24:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 15:24:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-07 15:24:23 --> Pagination Class Initialized
INFO - 2018-02-07 15:24:23 --> Helper loaded: form_helper
INFO - 2018-02-07 15:24:23 --> Form Validation Class Initialized
INFO - 2018-02-07 15:24:23 --> Model Class Initialized
INFO - 2018-02-07 15:24:23 --> Controller Class Initialized
DEBUG - 2018-02-07 15:24:23 --> Config file loaded: /var/www/html/spamblocker/application/config/rest.php
INFO - 2018-02-07 15:24:23 --> Helper loaded: inflector_helper
INFO - 2018-02-07 15:24:23 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 15:24:23 --> Model Class Initialized
INFO - 2018-02-07 15:24:23 --> Model Class Initialized
INFO - 2018-02-07 15:24:23 --> Upload Class Initialized
INFO - 2018-02-07 15:24:23 --> Language file loaded: language/english/upload_lang.php
ERROR - 2018-02-07 15:24:23 --> The upload path does not appear to be valid.
INFO - 2018-02-07 15:27:40 --> Config Class Initialized
INFO - 2018-02-07 15:27:40 --> Hooks Class Initialized
DEBUG - 2018-02-07 15:27:40 --> UTF-8 Support Enabled
INFO - 2018-02-07 15:27:40 --> Utf8 Class Initialized
INFO - 2018-02-07 15:27:40 --> URI Class Initialized
INFO - 2018-02-07 15:27:40 --> Router Class Initialized
INFO - 2018-02-07 15:27:40 --> Output Class Initialized
INFO - 2018-02-07 15:27:40 --> Security Class Initialized
DEBUG - 2018-02-07 15:27:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 15:27:40 --> Input Class Initialized
INFO - 2018-02-07 15:27:40 --> Language Class Initialized
INFO - 2018-02-07 15:27:40 --> Loader Class Initialized
INFO - 2018-02-07 15:27:40 --> Helper loaded: url_helper
INFO - 2018-02-07 15:27:40 --> Helper loaded: file_helper
INFO - 2018-02-07 15:27:40 --> Helper loaded: email_helper
INFO - 2018-02-07 15:27:40 --> Helper loaded: common_helper
INFO - 2018-02-07 15:27:40 --> Database Driver Class Initialized
DEBUG - 2018-02-07 15:27:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 15:27:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 15:27:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-07 15:27:40 --> Pagination Class Initialized
INFO - 2018-02-07 15:27:40 --> Helper loaded: form_helper
INFO - 2018-02-07 15:27:40 --> Form Validation Class Initialized
INFO - 2018-02-07 15:27:40 --> Model Class Initialized
INFO - 2018-02-07 15:27:40 --> Controller Class Initialized
DEBUG - 2018-02-07 15:27:40 --> Config file loaded: /var/www/html/spamblocker/application/config/rest.php
INFO - 2018-02-07 15:27:40 --> Helper loaded: inflector_helper
INFO - 2018-02-07 15:27:40 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 15:27:40 --> Model Class Initialized
INFO - 2018-02-07 15:27:40 --> Model Class Initialized
ERROR - 2018-02-07 15:27:40 --> Severity: Warning --> mkdir(): Permission denied /var/www/html/spamblocker/application/controllers/api/Oauth.php 629
ERROR - 2018-02-07 15:27:40 --> Severity: Warning --> mkdir(): Permission denied /var/www/html/spamblocker/application/controllers/api/Oauth.php 634
INFO - 2018-02-07 15:27:40 --> Upload Class Initialized
INFO - 2018-02-07 15:27:40 --> Language file loaded: language/english/upload_lang.php
ERROR - 2018-02-07 15:27:40 --> The upload path does not appear to be valid.
INFO - 2018-02-07 15:29:07 --> Config Class Initialized
INFO - 2018-02-07 15:29:07 --> Hooks Class Initialized
DEBUG - 2018-02-07 15:29:07 --> UTF-8 Support Enabled
INFO - 2018-02-07 15:29:07 --> Utf8 Class Initialized
INFO - 2018-02-07 15:29:07 --> URI Class Initialized
INFO - 2018-02-07 15:29:07 --> Router Class Initialized
INFO - 2018-02-07 15:29:07 --> Output Class Initialized
INFO - 2018-02-07 15:29:07 --> Security Class Initialized
DEBUG - 2018-02-07 15:29:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 15:29:07 --> Input Class Initialized
INFO - 2018-02-07 15:29:07 --> Language Class Initialized
INFO - 2018-02-07 15:29:07 --> Loader Class Initialized
INFO - 2018-02-07 15:29:07 --> Helper loaded: url_helper
INFO - 2018-02-07 15:29:07 --> Helper loaded: file_helper
INFO - 2018-02-07 15:29:07 --> Helper loaded: email_helper
INFO - 2018-02-07 15:29:07 --> Helper loaded: common_helper
INFO - 2018-02-07 15:29:07 --> Database Driver Class Initialized
DEBUG - 2018-02-07 15:29:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 15:29:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 15:29:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-07 15:29:07 --> Pagination Class Initialized
INFO - 2018-02-07 15:29:07 --> Helper loaded: form_helper
INFO - 2018-02-07 15:29:07 --> Form Validation Class Initialized
INFO - 2018-02-07 15:29:07 --> Model Class Initialized
INFO - 2018-02-07 15:29:07 --> Controller Class Initialized
DEBUG - 2018-02-07 15:29:07 --> Config file loaded: /var/www/html/spamblocker/application/config/rest.php
INFO - 2018-02-07 15:29:07 --> Helper loaded: inflector_helper
INFO - 2018-02-07 15:29:07 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 15:29:07 --> Model Class Initialized
INFO - 2018-02-07 15:29:07 --> Model Class Initialized
ERROR - 2018-02-07 15:29:07 --> Severity: Warning --> mkdir(): Permission denied /var/www/html/spamblocker/application/controllers/api/Oauth.php 629
ERROR - 2018-02-07 15:29:07 --> Severity: Warning --> mkdir(): No such file or directory /var/www/html/spamblocker/application/controllers/api/Oauth.php 634
INFO - 2018-02-07 15:29:07 --> Upload Class Initialized
INFO - 2018-02-07 15:29:07 --> Language file loaded: language/english/upload_lang.php
ERROR - 2018-02-07 15:29:07 --> The upload path does not appear to be valid.
INFO - 2018-02-07 15:30:31 --> Config Class Initialized
INFO - 2018-02-07 15:30:31 --> Hooks Class Initialized
DEBUG - 2018-02-07 15:30:31 --> UTF-8 Support Enabled
INFO - 2018-02-07 15:30:31 --> Utf8 Class Initialized
INFO - 2018-02-07 15:30:31 --> URI Class Initialized
INFO - 2018-02-07 15:30:31 --> Router Class Initialized
INFO - 2018-02-07 15:30:31 --> Output Class Initialized
INFO - 2018-02-07 15:30:31 --> Security Class Initialized
DEBUG - 2018-02-07 15:30:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 15:30:31 --> Input Class Initialized
INFO - 2018-02-07 15:30:31 --> Language Class Initialized
INFO - 2018-02-07 15:30:31 --> Loader Class Initialized
INFO - 2018-02-07 15:30:31 --> Helper loaded: url_helper
INFO - 2018-02-07 15:30:31 --> Helper loaded: file_helper
INFO - 2018-02-07 15:30:31 --> Helper loaded: email_helper
INFO - 2018-02-07 15:30:31 --> Helper loaded: common_helper
INFO - 2018-02-07 15:30:31 --> Database Driver Class Initialized
DEBUG - 2018-02-07 15:30:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 15:30:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 15:30:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-07 15:30:31 --> Pagination Class Initialized
INFO - 2018-02-07 15:30:31 --> Helper loaded: form_helper
INFO - 2018-02-07 15:30:31 --> Form Validation Class Initialized
INFO - 2018-02-07 15:30:31 --> Model Class Initialized
INFO - 2018-02-07 15:30:31 --> Controller Class Initialized
DEBUG - 2018-02-07 15:30:31 --> Config file loaded: /var/www/html/spamblocker/application/config/rest.php
INFO - 2018-02-07 15:30:31 --> Helper loaded: inflector_helper
INFO - 2018-02-07 15:30:31 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 15:30:31 --> Model Class Initialized
INFO - 2018-02-07 15:30:31 --> Model Class Initialized
ERROR - 2018-02-07 15:30:31 --> Severity: Warning --> mkdir(): Permission denied /var/www/html/spamblocker/application/controllers/api/Oauth.php 629
ERROR - 2018-02-07 15:30:31 --> Severity: Warning --> mkdir(): No such file or directory /var/www/html/spamblocker/application/controllers/api/Oauth.php 634
INFO - 2018-02-07 15:30:31 --> Upload Class Initialized
INFO - 2018-02-07 15:30:31 --> Language file loaded: language/english/upload_lang.php
ERROR - 2018-02-07 15:30:31 --> The upload path does not appear to be valid.
INFO - 2018-02-07 15:32:13 --> Config Class Initialized
INFO - 2018-02-07 15:32:13 --> Hooks Class Initialized
DEBUG - 2018-02-07 15:32:13 --> UTF-8 Support Enabled
INFO - 2018-02-07 15:32:13 --> Utf8 Class Initialized
INFO - 2018-02-07 15:32:13 --> URI Class Initialized
INFO - 2018-02-07 15:32:13 --> Router Class Initialized
INFO - 2018-02-07 15:32:13 --> Output Class Initialized
INFO - 2018-02-07 15:32:13 --> Security Class Initialized
DEBUG - 2018-02-07 15:32:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 15:32:13 --> Input Class Initialized
INFO - 2018-02-07 15:32:13 --> Language Class Initialized
INFO - 2018-02-07 15:32:13 --> Loader Class Initialized
INFO - 2018-02-07 15:32:13 --> Helper loaded: url_helper
INFO - 2018-02-07 15:32:13 --> Helper loaded: file_helper
INFO - 2018-02-07 15:32:13 --> Helper loaded: email_helper
INFO - 2018-02-07 15:32:13 --> Helper loaded: common_helper
INFO - 2018-02-07 15:32:13 --> Database Driver Class Initialized
DEBUG - 2018-02-07 15:32:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 15:32:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 15:32:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-07 15:32:13 --> Pagination Class Initialized
INFO - 2018-02-07 15:32:13 --> Helper loaded: form_helper
INFO - 2018-02-07 15:32:13 --> Form Validation Class Initialized
INFO - 2018-02-07 15:32:13 --> Model Class Initialized
INFO - 2018-02-07 15:32:13 --> Controller Class Initialized
DEBUG - 2018-02-07 15:32:13 --> Config file loaded: /var/www/html/spamblocker/application/config/rest.php
INFO - 2018-02-07 15:32:13 --> Helper loaded: inflector_helper
INFO - 2018-02-07 15:32:13 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 15:32:13 --> Model Class Initialized
INFO - 2018-02-07 15:32:13 --> Model Class Initialized
ERROR - 2018-02-07 15:32:13 --> Severity: Warning --> mkdir(): Permission denied /var/www/html/spamblocker/application/controllers/api/Oauth.php 629
ERROR - 2018-02-07 15:32:13 --> Severity: Warning --> chmod(): No such file or directory /var/www/html/spamblocker/application/controllers/api/Oauth.php 630
ERROR - 2018-02-07 15:32:13 --> Severity: Warning --> mkdir(): No such file or directory /var/www/html/spamblocker/application/controllers/api/Oauth.php 635
ERROR - 2018-02-07 15:32:13 --> Severity: Warning --> chmod(): No such file or directory /var/www/html/spamblocker/application/controllers/api/Oauth.php 636
INFO - 2018-02-07 15:32:13 --> Upload Class Initialized
INFO - 2018-02-07 15:32:13 --> Language file loaded: language/english/upload_lang.php
ERROR - 2018-02-07 15:32:13 --> The upload path does not appear to be valid.
INFO - 2018-02-07 15:35:56 --> Config Class Initialized
INFO - 2018-02-07 15:35:56 --> Hooks Class Initialized
DEBUG - 2018-02-07 15:35:56 --> UTF-8 Support Enabled
INFO - 2018-02-07 15:35:56 --> Utf8 Class Initialized
INFO - 2018-02-07 15:35:56 --> URI Class Initialized
INFO - 2018-02-07 15:35:56 --> Router Class Initialized
INFO - 2018-02-07 15:35:56 --> Output Class Initialized
INFO - 2018-02-07 15:35:56 --> Security Class Initialized
DEBUG - 2018-02-07 15:35:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 15:35:56 --> Input Class Initialized
INFO - 2018-02-07 15:35:56 --> Language Class Initialized
INFO - 2018-02-07 15:35:56 --> Loader Class Initialized
INFO - 2018-02-07 15:35:56 --> Helper loaded: url_helper
INFO - 2018-02-07 15:35:56 --> Helper loaded: file_helper
INFO - 2018-02-07 15:35:56 --> Helper loaded: email_helper
INFO - 2018-02-07 15:35:56 --> Helper loaded: common_helper
INFO - 2018-02-07 15:35:56 --> Database Driver Class Initialized
DEBUG - 2018-02-07 15:35:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 15:35:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 15:35:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-07 15:35:56 --> Pagination Class Initialized
INFO - 2018-02-07 15:35:56 --> Helper loaded: form_helper
INFO - 2018-02-07 15:35:56 --> Form Validation Class Initialized
INFO - 2018-02-07 15:35:56 --> Model Class Initialized
INFO - 2018-02-07 15:35:56 --> Controller Class Initialized
DEBUG - 2018-02-07 15:35:56 --> Config file loaded: /var/www/html/spamblocker/application/config/rest.php
INFO - 2018-02-07 15:35:56 --> Helper loaded: inflector_helper
INFO - 2018-02-07 15:35:56 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 15:35:56 --> Model Class Initialized
INFO - 2018-02-07 15:35:56 --> Model Class Initialized
INFO - 2018-02-07 15:35:57 --> Upload Class Initialized
INFO - 2018-02-07 15:35:57 --> Language file loaded: language/english/upload_lang.php
ERROR - 2018-02-07 15:35:57 --> The upload path does not appear to be valid.
INFO - 2018-02-07 15:36:02 --> Config Class Initialized
INFO - 2018-02-07 15:36:02 --> Hooks Class Initialized
DEBUG - 2018-02-07 15:36:02 --> UTF-8 Support Enabled
INFO - 2018-02-07 15:36:02 --> Utf8 Class Initialized
INFO - 2018-02-07 15:36:02 --> URI Class Initialized
INFO - 2018-02-07 15:36:02 --> Router Class Initialized
INFO - 2018-02-07 15:36:02 --> Output Class Initialized
INFO - 2018-02-07 15:36:02 --> Security Class Initialized
DEBUG - 2018-02-07 15:36:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 15:36:02 --> Input Class Initialized
INFO - 2018-02-07 15:36:02 --> Language Class Initialized
INFO - 2018-02-07 15:36:02 --> Loader Class Initialized
INFO - 2018-02-07 15:36:02 --> Helper loaded: url_helper
INFO - 2018-02-07 15:36:02 --> Helper loaded: file_helper
INFO - 2018-02-07 15:36:02 --> Helper loaded: email_helper
INFO - 2018-02-07 15:36:02 --> Helper loaded: common_helper
INFO - 2018-02-07 15:36:02 --> Database Driver Class Initialized
DEBUG - 2018-02-07 15:36:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 15:36:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 15:36:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-07 15:36:02 --> Pagination Class Initialized
INFO - 2018-02-07 15:36:02 --> Helper loaded: form_helper
INFO - 2018-02-07 15:36:02 --> Form Validation Class Initialized
INFO - 2018-02-07 15:36:02 --> Model Class Initialized
INFO - 2018-02-07 15:36:02 --> Controller Class Initialized
DEBUG - 2018-02-07 15:36:02 --> Config file loaded: /var/www/html/spamblocker/application/config/rest.php
INFO - 2018-02-07 15:36:02 --> Helper loaded: inflector_helper
INFO - 2018-02-07 15:36:02 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 15:36:02 --> Model Class Initialized
INFO - 2018-02-07 15:36:02 --> Model Class Initialized
INFO - 2018-02-07 15:36:02 --> Upload Class Initialized
INFO - 2018-02-07 15:36:02 --> Final output sent to browser
DEBUG - 2018-02-07 15:36:02 --> Total execution time: 0.0697
INFO - 2018-02-07 15:37:57 --> Config Class Initialized
INFO - 2018-02-07 15:37:57 --> Hooks Class Initialized
DEBUG - 2018-02-07 15:37:57 --> UTF-8 Support Enabled
INFO - 2018-02-07 15:37:57 --> Utf8 Class Initialized
INFO - 2018-02-07 15:37:57 --> URI Class Initialized
INFO - 2018-02-07 15:37:57 --> Router Class Initialized
INFO - 2018-02-07 15:37:57 --> Output Class Initialized
INFO - 2018-02-07 15:37:57 --> Security Class Initialized
DEBUG - 2018-02-07 15:37:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 15:37:57 --> Input Class Initialized
INFO - 2018-02-07 15:37:57 --> Language Class Initialized
INFO - 2018-02-07 15:37:57 --> Loader Class Initialized
INFO - 2018-02-07 15:37:57 --> Helper loaded: url_helper
INFO - 2018-02-07 15:37:57 --> Helper loaded: file_helper
INFO - 2018-02-07 15:37:57 --> Helper loaded: email_helper
INFO - 2018-02-07 15:37:57 --> Helper loaded: common_helper
INFO - 2018-02-07 15:37:57 --> Database Driver Class Initialized
DEBUG - 2018-02-07 15:37:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 15:37:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 15:37:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-07 15:37:57 --> Pagination Class Initialized
INFO - 2018-02-07 15:37:57 --> Helper loaded: form_helper
INFO - 2018-02-07 15:37:57 --> Form Validation Class Initialized
INFO - 2018-02-07 15:37:57 --> Model Class Initialized
INFO - 2018-02-07 15:37:57 --> Controller Class Initialized
DEBUG - 2018-02-07 15:37:57 --> Config file loaded: /var/www/html/spamblocker/application/config/rest.php
INFO - 2018-02-07 15:37:57 --> Helper loaded: inflector_helper
INFO - 2018-02-07 15:37:57 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 15:37:57 --> Model Class Initialized
INFO - 2018-02-07 15:37:57 --> Model Class Initialized
INFO - 2018-02-07 15:37:57 --> Upload Class Initialized
INFO - 2018-02-07 15:37:57 --> Final output sent to browser
DEBUG - 2018-02-07 15:37:57 --> Total execution time: 0.0443
INFO - 2018-02-07 15:39:02 --> Config Class Initialized
INFO - 2018-02-07 15:39:02 --> Hooks Class Initialized
DEBUG - 2018-02-07 15:39:02 --> UTF-8 Support Enabled
INFO - 2018-02-07 15:39:02 --> Utf8 Class Initialized
INFO - 2018-02-07 15:39:02 --> URI Class Initialized
INFO - 2018-02-07 15:39:02 --> Router Class Initialized
INFO - 2018-02-07 15:39:02 --> Output Class Initialized
INFO - 2018-02-07 15:39:02 --> Security Class Initialized
DEBUG - 2018-02-07 15:39:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 15:39:02 --> Input Class Initialized
INFO - 2018-02-07 15:39:02 --> Language Class Initialized
INFO - 2018-02-07 15:39:02 --> Loader Class Initialized
INFO - 2018-02-07 15:39:02 --> Helper loaded: url_helper
INFO - 2018-02-07 15:39:02 --> Helper loaded: file_helper
INFO - 2018-02-07 15:39:02 --> Helper loaded: email_helper
INFO - 2018-02-07 15:39:02 --> Helper loaded: common_helper
INFO - 2018-02-07 15:39:02 --> Database Driver Class Initialized
DEBUG - 2018-02-07 15:39:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 15:39:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 15:39:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-07 15:39:02 --> Pagination Class Initialized
INFO - 2018-02-07 15:39:02 --> Helper loaded: form_helper
INFO - 2018-02-07 15:39:02 --> Form Validation Class Initialized
INFO - 2018-02-07 15:39:02 --> Model Class Initialized
INFO - 2018-02-07 15:39:02 --> Controller Class Initialized
DEBUG - 2018-02-07 15:39:02 --> Config file loaded: /var/www/html/spamblocker/application/config/rest.php
INFO - 2018-02-07 15:39:02 --> Helper loaded: inflector_helper
INFO - 2018-02-07 15:39:02 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 15:39:02 --> Model Class Initialized
INFO - 2018-02-07 15:39:02 --> Model Class Initialized
INFO - 2018-02-07 15:39:02 --> Upload Class Initialized
INFO - 2018-02-07 15:39:02 --> Final output sent to browser
DEBUG - 2018-02-07 15:39:02 --> Total execution time: 0.0605
INFO - 2018-02-07 15:40:10 --> Config Class Initialized
INFO - 2018-02-07 15:40:10 --> Hooks Class Initialized
DEBUG - 2018-02-07 15:40:10 --> UTF-8 Support Enabled
INFO - 2018-02-07 15:40:10 --> Utf8 Class Initialized
INFO - 2018-02-07 15:40:10 --> URI Class Initialized
INFO - 2018-02-07 15:40:10 --> Router Class Initialized
INFO - 2018-02-07 15:40:10 --> Output Class Initialized
INFO - 2018-02-07 15:40:10 --> Security Class Initialized
DEBUG - 2018-02-07 15:40:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 15:40:10 --> Input Class Initialized
INFO - 2018-02-07 15:40:10 --> Language Class Initialized
INFO - 2018-02-07 15:40:10 --> Loader Class Initialized
INFO - 2018-02-07 15:40:10 --> Helper loaded: url_helper
INFO - 2018-02-07 15:40:10 --> Helper loaded: file_helper
INFO - 2018-02-07 15:40:10 --> Helper loaded: email_helper
INFO - 2018-02-07 15:40:10 --> Helper loaded: common_helper
INFO - 2018-02-07 15:40:10 --> Database Driver Class Initialized
DEBUG - 2018-02-07 15:40:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 15:40:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 15:40:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-07 15:40:10 --> Pagination Class Initialized
INFO - 2018-02-07 15:40:10 --> Helper loaded: form_helper
INFO - 2018-02-07 15:40:10 --> Form Validation Class Initialized
INFO - 2018-02-07 15:40:10 --> Model Class Initialized
INFO - 2018-02-07 15:40:10 --> Controller Class Initialized
DEBUG - 2018-02-07 15:40:10 --> Config file loaded: /var/www/html/spamblocker/application/config/rest.php
INFO - 2018-02-07 15:40:10 --> Helper loaded: inflector_helper
INFO - 2018-02-07 15:40:10 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 15:40:10 --> Model Class Initialized
INFO - 2018-02-07 15:40:10 --> Model Class Initialized
INFO - 2018-02-07 15:40:10 --> Final output sent to browser
DEBUG - 2018-02-07 15:40:10 --> Total execution time: 0.0356
INFO - 2018-02-07 15:40:25 --> Config Class Initialized
INFO - 2018-02-07 15:40:25 --> Hooks Class Initialized
DEBUG - 2018-02-07 15:40:25 --> UTF-8 Support Enabled
INFO - 2018-02-07 15:40:25 --> Utf8 Class Initialized
INFO - 2018-02-07 15:40:25 --> URI Class Initialized
INFO - 2018-02-07 15:40:25 --> Router Class Initialized
INFO - 2018-02-07 15:40:25 --> Output Class Initialized
INFO - 2018-02-07 15:40:25 --> Security Class Initialized
DEBUG - 2018-02-07 15:40:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 15:40:25 --> Input Class Initialized
INFO - 2018-02-07 15:40:25 --> Language Class Initialized
INFO - 2018-02-07 15:40:25 --> Loader Class Initialized
INFO - 2018-02-07 15:40:25 --> Helper loaded: url_helper
INFO - 2018-02-07 15:40:25 --> Helper loaded: file_helper
INFO - 2018-02-07 15:40:25 --> Helper loaded: email_helper
INFO - 2018-02-07 15:40:25 --> Helper loaded: common_helper
INFO - 2018-02-07 15:40:25 --> Database Driver Class Initialized
DEBUG - 2018-02-07 15:40:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 15:40:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 15:40:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-07 15:40:25 --> Pagination Class Initialized
INFO - 2018-02-07 15:40:25 --> Helper loaded: form_helper
INFO - 2018-02-07 15:40:25 --> Form Validation Class Initialized
INFO - 2018-02-07 15:40:25 --> Model Class Initialized
INFO - 2018-02-07 15:40:25 --> Controller Class Initialized
DEBUG - 2018-02-07 15:40:25 --> Config file loaded: /var/www/html/spamblocker/application/config/rest.php
INFO - 2018-02-07 15:40:25 --> Helper loaded: inflector_helper
INFO - 2018-02-07 15:40:25 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 15:40:25 --> Model Class Initialized
INFO - 2018-02-07 15:40:25 --> Model Class Initialized
INFO - 2018-02-07 15:40:25 --> Final output sent to browser
DEBUG - 2018-02-07 15:40:25 --> Total execution time: 0.0049
INFO - 2018-02-07 15:40:41 --> Config Class Initialized
INFO - 2018-02-07 15:40:41 --> Hooks Class Initialized
DEBUG - 2018-02-07 15:40:41 --> UTF-8 Support Enabled
INFO - 2018-02-07 15:40:41 --> Utf8 Class Initialized
INFO - 2018-02-07 15:40:41 --> URI Class Initialized
INFO - 2018-02-07 15:40:41 --> Router Class Initialized
INFO - 2018-02-07 15:40:41 --> Output Class Initialized
INFO - 2018-02-07 15:40:41 --> Security Class Initialized
DEBUG - 2018-02-07 15:40:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 15:40:41 --> Input Class Initialized
INFO - 2018-02-07 15:40:41 --> Language Class Initialized
INFO - 2018-02-07 15:40:41 --> Loader Class Initialized
INFO - 2018-02-07 15:40:41 --> Helper loaded: url_helper
INFO - 2018-02-07 15:40:41 --> Helper loaded: file_helper
INFO - 2018-02-07 15:40:41 --> Helper loaded: email_helper
INFO - 2018-02-07 15:40:41 --> Helper loaded: common_helper
INFO - 2018-02-07 15:40:41 --> Database Driver Class Initialized
DEBUG - 2018-02-07 15:40:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 15:40:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 15:40:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-07 15:40:41 --> Pagination Class Initialized
INFO - 2018-02-07 15:40:41 --> Helper loaded: form_helper
INFO - 2018-02-07 15:40:41 --> Form Validation Class Initialized
INFO - 2018-02-07 15:40:41 --> Model Class Initialized
INFO - 2018-02-07 15:40:41 --> Controller Class Initialized
DEBUG - 2018-02-07 15:40:41 --> Config file loaded: /var/www/html/spamblocker/application/config/rest.php
INFO - 2018-02-07 15:40:41 --> Helper loaded: inflector_helper
INFO - 2018-02-07 15:40:41 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 15:40:41 --> Model Class Initialized
INFO - 2018-02-07 15:40:41 --> Model Class Initialized
INFO - 2018-02-07 15:40:41 --> Model Class Initialized
INFO - 2018-02-07 15:40:41 --> Email Class Initialized
INFO - 2018-02-07 15:40:42 --> Language file loaded: language/english/email_lang.php
INFO - 2018-02-07 15:40:46 --> Final output sent to browser
DEBUG - 2018-02-07 15:40:46 --> Total execution time: 4.1991
INFO - 2018-02-07 15:41:03 --> Config Class Initialized
INFO - 2018-02-07 15:41:03 --> Hooks Class Initialized
DEBUG - 2018-02-07 15:41:03 --> UTF-8 Support Enabled
INFO - 2018-02-07 15:41:03 --> Utf8 Class Initialized
INFO - 2018-02-07 15:41:03 --> URI Class Initialized
INFO - 2018-02-07 15:41:03 --> Router Class Initialized
INFO - 2018-02-07 15:41:03 --> Output Class Initialized
INFO - 2018-02-07 15:41:03 --> Security Class Initialized
DEBUG - 2018-02-07 15:41:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 15:41:03 --> Input Class Initialized
INFO - 2018-02-07 15:41:03 --> Language Class Initialized
INFO - 2018-02-07 15:41:03 --> Loader Class Initialized
INFO - 2018-02-07 15:41:03 --> Helper loaded: url_helper
INFO - 2018-02-07 15:41:03 --> Helper loaded: file_helper
INFO - 2018-02-07 15:41:03 --> Helper loaded: email_helper
INFO - 2018-02-07 15:41:03 --> Helper loaded: common_helper
INFO - 2018-02-07 15:41:03 --> Database Driver Class Initialized
DEBUG - 2018-02-07 15:41:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 15:41:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 15:41:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-07 15:41:03 --> Pagination Class Initialized
INFO - 2018-02-07 15:41:03 --> Helper loaded: form_helper
INFO - 2018-02-07 15:41:03 --> Form Validation Class Initialized
INFO - 2018-02-07 15:41:03 --> Model Class Initialized
INFO - 2018-02-07 15:41:03 --> Controller Class Initialized
DEBUG - 2018-02-07 15:41:03 --> Config file loaded: /var/www/html/spamblocker/application/config/rest.php
INFO - 2018-02-07 15:41:03 --> Helper loaded: inflector_helper
INFO - 2018-02-07 15:41:03 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 15:41:03 --> Model Class Initialized
INFO - 2018-02-07 15:41:03 --> Model Class Initialized
INFO - 2018-02-07 15:41:03 --> Final output sent to browser
DEBUG - 2018-02-07 15:41:03 --> Total execution time: 0.0049
INFO - 2018-02-07 15:46:50 --> Config Class Initialized
INFO - 2018-02-07 15:46:50 --> Hooks Class Initialized
DEBUG - 2018-02-07 15:46:50 --> UTF-8 Support Enabled
INFO - 2018-02-07 15:46:50 --> Utf8 Class Initialized
INFO - 2018-02-07 15:46:50 --> URI Class Initialized
INFO - 2018-02-07 15:46:50 --> Router Class Initialized
INFO - 2018-02-07 15:46:50 --> Output Class Initialized
INFO - 2018-02-07 15:46:50 --> Security Class Initialized
DEBUG - 2018-02-07 15:46:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 15:46:50 --> Input Class Initialized
INFO - 2018-02-07 15:46:50 --> Language Class Initialized
INFO - 2018-02-07 15:46:50 --> Loader Class Initialized
INFO - 2018-02-07 15:46:50 --> Helper loaded: url_helper
INFO - 2018-02-07 15:46:50 --> Helper loaded: file_helper
INFO - 2018-02-07 15:46:50 --> Helper loaded: email_helper
INFO - 2018-02-07 15:46:50 --> Helper loaded: common_helper
INFO - 2018-02-07 15:46:50 --> Database Driver Class Initialized
DEBUG - 2018-02-07 15:46:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 15:46:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 15:46:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-07 15:46:50 --> Pagination Class Initialized
INFO - 2018-02-07 15:46:50 --> Helper loaded: form_helper
INFO - 2018-02-07 15:46:50 --> Form Validation Class Initialized
INFO - 2018-02-07 15:46:50 --> Model Class Initialized
INFO - 2018-02-07 15:46:50 --> Controller Class Initialized
DEBUG - 2018-02-07 15:46:50 --> Config file loaded: /var/www/html/spamblocker/application/config/rest.php
INFO - 2018-02-07 15:46:50 --> Helper loaded: inflector_helper
INFO - 2018-02-07 15:46:50 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 15:46:50 --> Model Class Initialized
INFO - 2018-02-07 15:46:50 --> Model Class Initialized
INFO - 2018-02-07 15:46:50 --> Model Class Initialized
INFO - 2018-02-07 15:46:50 --> Email Class Initialized
INFO - 2018-02-07 15:46:51 --> Language file loaded: language/english/email_lang.php
INFO - 2018-02-07 15:46:54 --> Final output sent to browser
DEBUG - 2018-02-07 15:46:54 --> Total execution time: 4.1745
INFO - 2018-02-07 16:12:25 --> Config Class Initialized
INFO - 2018-02-07 16:12:25 --> Hooks Class Initialized
DEBUG - 2018-02-07 16:12:25 --> UTF-8 Support Enabled
INFO - 2018-02-07 16:12:25 --> Utf8 Class Initialized
INFO - 2018-02-07 16:12:25 --> URI Class Initialized
INFO - 2018-02-07 16:12:25 --> Router Class Initialized
INFO - 2018-02-07 16:12:25 --> Output Class Initialized
INFO - 2018-02-07 16:12:25 --> Security Class Initialized
DEBUG - 2018-02-07 16:12:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 16:12:25 --> Input Class Initialized
INFO - 2018-02-07 16:12:25 --> Language Class Initialized
INFO - 2018-02-07 16:12:25 --> Loader Class Initialized
INFO - 2018-02-07 16:12:25 --> Helper loaded: url_helper
INFO - 2018-02-07 16:12:25 --> Helper loaded: file_helper
INFO - 2018-02-07 16:12:25 --> Helper loaded: email_helper
INFO - 2018-02-07 16:12:25 --> Helper loaded: common_helper
INFO - 2018-02-07 16:12:25 --> Database Driver Class Initialized
DEBUG - 2018-02-07 16:12:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 16:12:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 16:12:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-07 16:12:25 --> Pagination Class Initialized
INFO - 2018-02-07 16:12:25 --> Helper loaded: form_helper
INFO - 2018-02-07 16:12:25 --> Form Validation Class Initialized
INFO - 2018-02-07 16:12:25 --> Model Class Initialized
INFO - 2018-02-07 16:12:25 --> Controller Class Initialized
INFO - 2018-02-07 16:12:25 --> Model Class Initialized
INFO - 2018-02-07 16:12:25 --> File loaded: /var/www/html/spamblocker/application/views/index/resetPassword.php
INFO - 2018-02-07 16:12:25 --> Final output sent to browser
DEBUG - 2018-02-07 16:12:25 --> Total execution time: 0.0055
INFO - 2018-02-07 16:12:43 --> Config Class Initialized
INFO - 2018-02-07 16:12:43 --> Hooks Class Initialized
DEBUG - 2018-02-07 16:12:43 --> UTF-8 Support Enabled
INFO - 2018-02-07 16:12:43 --> Utf8 Class Initialized
INFO - 2018-02-07 16:12:43 --> URI Class Initialized
INFO - 2018-02-07 16:12:43 --> Router Class Initialized
INFO - 2018-02-07 16:12:43 --> Output Class Initialized
INFO - 2018-02-07 16:12:43 --> Security Class Initialized
DEBUG - 2018-02-07 16:12:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 16:12:43 --> Input Class Initialized
INFO - 2018-02-07 16:12:43 --> Language Class Initialized
INFO - 2018-02-07 16:12:43 --> Loader Class Initialized
INFO - 2018-02-07 16:12:43 --> Helper loaded: url_helper
INFO - 2018-02-07 16:12:43 --> Helper loaded: file_helper
INFO - 2018-02-07 16:12:43 --> Helper loaded: email_helper
INFO - 2018-02-07 16:12:43 --> Helper loaded: common_helper
INFO - 2018-02-07 16:12:43 --> Database Driver Class Initialized
DEBUG - 2018-02-07 16:12:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 16:12:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 16:12:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-07 16:12:43 --> Pagination Class Initialized
INFO - 2018-02-07 16:12:43 --> Helper loaded: form_helper
INFO - 2018-02-07 16:12:43 --> Form Validation Class Initialized
INFO - 2018-02-07 16:12:43 --> Model Class Initialized
INFO - 2018-02-07 16:12:43 --> Controller Class Initialized
INFO - 2018-02-07 16:12:43 --> Model Class Initialized
INFO - 2018-02-07 16:12:43 --> File loaded: /var/www/html/spamblocker/application/views/index/resetPassword.php
INFO - 2018-02-07 16:12:43 --> Final output sent to browser
DEBUG - 2018-02-07 16:12:43 --> Total execution time: 0.0406
INFO - 2018-02-07 16:12:45 --> Config Class Initialized
INFO - 2018-02-07 16:12:45 --> Hooks Class Initialized
DEBUG - 2018-02-07 16:12:45 --> UTF-8 Support Enabled
INFO - 2018-02-07 16:12:45 --> Utf8 Class Initialized
INFO - 2018-02-07 16:12:45 --> URI Class Initialized
INFO - 2018-02-07 16:12:45 --> Router Class Initialized
INFO - 2018-02-07 16:12:45 --> Output Class Initialized
INFO - 2018-02-07 16:12:45 --> Security Class Initialized
DEBUG - 2018-02-07 16:12:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 16:12:45 --> Input Class Initialized
INFO - 2018-02-07 16:12:45 --> Language Class Initialized
INFO - 2018-02-07 16:12:45 --> Loader Class Initialized
INFO - 2018-02-07 16:12:45 --> Helper loaded: url_helper
INFO - 2018-02-07 16:12:45 --> Helper loaded: file_helper
INFO - 2018-02-07 16:12:45 --> Helper loaded: email_helper
INFO - 2018-02-07 16:12:45 --> Helper loaded: common_helper
INFO - 2018-02-07 16:12:45 --> Database Driver Class Initialized
DEBUG - 2018-02-07 16:12:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 16:12:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 16:12:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-07 16:12:45 --> Pagination Class Initialized
INFO - 2018-02-07 16:12:45 --> Helper loaded: form_helper
INFO - 2018-02-07 16:12:45 --> Form Validation Class Initialized
INFO - 2018-02-07 16:12:45 --> Model Class Initialized
INFO - 2018-02-07 16:12:45 --> Controller Class Initialized
INFO - 2018-02-07 16:12:45 --> Model Class Initialized
INFO - 2018-02-07 16:12:45 --> File loaded: /var/www/html/spamblocker/application/views/index/resetPassword.php
INFO - 2018-02-07 16:12:45 --> Final output sent to browser
DEBUG - 2018-02-07 16:12:45 --> Total execution time: 0.0059
INFO - 2018-02-07 16:12:54 --> Config Class Initialized
INFO - 2018-02-07 16:12:54 --> Hooks Class Initialized
DEBUG - 2018-02-07 16:12:54 --> UTF-8 Support Enabled
INFO - 2018-02-07 16:12:54 --> Utf8 Class Initialized
INFO - 2018-02-07 16:12:54 --> URI Class Initialized
INFO - 2018-02-07 16:12:54 --> Router Class Initialized
INFO - 2018-02-07 16:12:54 --> Output Class Initialized
INFO - 2018-02-07 16:12:54 --> Security Class Initialized
DEBUG - 2018-02-07 16:12:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 16:12:54 --> Input Class Initialized
INFO - 2018-02-07 16:12:54 --> Language Class Initialized
INFO - 2018-02-07 16:12:54 --> Loader Class Initialized
INFO - 2018-02-07 16:12:54 --> Helper loaded: url_helper
INFO - 2018-02-07 16:12:54 --> Helper loaded: file_helper
INFO - 2018-02-07 16:12:54 --> Helper loaded: email_helper
INFO - 2018-02-07 16:12:54 --> Helper loaded: common_helper
INFO - 2018-02-07 16:12:54 --> Database Driver Class Initialized
DEBUG - 2018-02-07 16:12:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 16:12:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 16:12:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-07 16:12:54 --> Pagination Class Initialized
INFO - 2018-02-07 16:12:54 --> Helper loaded: form_helper
INFO - 2018-02-07 16:12:54 --> Form Validation Class Initialized
INFO - 2018-02-07 16:12:54 --> Model Class Initialized
INFO - 2018-02-07 16:12:54 --> Controller Class Initialized
DEBUG - 2018-02-07 16:12:54 --> Config file loaded: /var/www/html/spamblocker/application/config/rest.php
INFO - 2018-02-07 16:12:54 --> Helper loaded: inflector_helper
INFO - 2018-02-07 16:12:54 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 16:12:54 --> Model Class Initialized
INFO - 2018-02-07 16:12:54 --> Model Class Initialized
INFO - 2018-02-07 16:12:54 --> Final output sent to browser
DEBUG - 2018-02-07 16:12:54 --> Total execution time: 0.0048
INFO - 2018-02-07 16:13:05 --> Config Class Initialized
INFO - 2018-02-07 16:13:05 --> Hooks Class Initialized
DEBUG - 2018-02-07 16:13:05 --> UTF-8 Support Enabled
INFO - 2018-02-07 16:13:05 --> Utf8 Class Initialized
INFO - 2018-02-07 16:13:05 --> URI Class Initialized
INFO - 2018-02-07 16:13:05 --> Router Class Initialized
INFO - 2018-02-07 16:13:05 --> Output Class Initialized
INFO - 2018-02-07 16:13:05 --> Security Class Initialized
DEBUG - 2018-02-07 16:13:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 16:13:05 --> Input Class Initialized
INFO - 2018-02-07 16:13:05 --> Language Class Initialized
INFO - 2018-02-07 16:13:05 --> Loader Class Initialized
INFO - 2018-02-07 16:13:05 --> Helper loaded: url_helper
INFO - 2018-02-07 16:13:05 --> Helper loaded: file_helper
INFO - 2018-02-07 16:13:05 --> Helper loaded: email_helper
INFO - 2018-02-07 16:13:05 --> Helper loaded: common_helper
INFO - 2018-02-07 16:13:05 --> Database Driver Class Initialized
DEBUG - 2018-02-07 16:13:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 16:13:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 16:13:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-07 16:13:05 --> Pagination Class Initialized
INFO - 2018-02-07 16:13:05 --> Helper loaded: form_helper
INFO - 2018-02-07 16:13:05 --> Form Validation Class Initialized
INFO - 2018-02-07 16:13:05 --> Model Class Initialized
INFO - 2018-02-07 16:13:05 --> Controller Class Initialized
DEBUG - 2018-02-07 16:13:05 --> Config file loaded: /var/www/html/spamblocker/application/config/rest.php
INFO - 2018-02-07 16:13:05 --> Helper loaded: inflector_helper
INFO - 2018-02-07 16:13:05 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 16:13:05 --> Model Class Initialized
INFO - 2018-02-07 16:13:05 --> Model Class Initialized
INFO - 2018-02-07 16:13:05 --> Final output sent to browser
DEBUG - 2018-02-07 16:13:05 --> Total execution time: 0.0477
INFO - 2018-02-07 16:17:41 --> Config Class Initialized
INFO - 2018-02-07 16:17:41 --> Hooks Class Initialized
DEBUG - 2018-02-07 16:17:41 --> UTF-8 Support Enabled
INFO - 2018-02-07 16:17:41 --> Utf8 Class Initialized
INFO - 2018-02-07 16:17:41 --> URI Class Initialized
INFO - 2018-02-07 16:17:41 --> Router Class Initialized
INFO - 2018-02-07 16:17:41 --> Output Class Initialized
INFO - 2018-02-07 16:17:41 --> Security Class Initialized
DEBUG - 2018-02-07 16:17:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 16:17:41 --> Input Class Initialized
INFO - 2018-02-07 16:17:41 --> Language Class Initialized
INFO - 2018-02-07 16:17:41 --> Loader Class Initialized
INFO - 2018-02-07 16:17:41 --> Helper loaded: url_helper
INFO - 2018-02-07 16:17:41 --> Helper loaded: file_helper
INFO - 2018-02-07 16:17:41 --> Helper loaded: email_helper
INFO - 2018-02-07 16:17:41 --> Helper loaded: common_helper
INFO - 2018-02-07 16:17:41 --> Database Driver Class Initialized
DEBUG - 2018-02-07 16:17:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 16:17:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 16:17:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-07 16:17:41 --> Pagination Class Initialized
INFO - 2018-02-07 16:17:41 --> Helper loaded: form_helper
INFO - 2018-02-07 16:17:41 --> Form Validation Class Initialized
INFO - 2018-02-07 16:17:41 --> Model Class Initialized
INFO - 2018-02-07 16:17:41 --> Controller Class Initialized
DEBUG - 2018-02-07 16:17:41 --> Config file loaded: /var/www/html/spamblocker/application/config/rest.php
INFO - 2018-02-07 16:17:41 --> Helper loaded: inflector_helper
INFO - 2018-02-07 16:17:41 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 16:17:41 --> Model Class Initialized
INFO - 2018-02-07 16:17:41 --> Model Class Initialized
INFO - 2018-02-07 16:17:41 --> Final output sent to browser
DEBUG - 2018-02-07 16:17:41 --> Total execution time: 0.0473
INFO - 2018-02-07 16:18:19 --> Config Class Initialized
INFO - 2018-02-07 16:18:19 --> Hooks Class Initialized
DEBUG - 2018-02-07 16:18:19 --> UTF-8 Support Enabled
INFO - 2018-02-07 16:18:19 --> Utf8 Class Initialized
INFO - 2018-02-07 16:18:19 --> URI Class Initialized
INFO - 2018-02-07 16:18:19 --> Router Class Initialized
INFO - 2018-02-07 16:18:19 --> Output Class Initialized
INFO - 2018-02-07 16:18:19 --> Security Class Initialized
DEBUG - 2018-02-07 16:18:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 16:18:19 --> Input Class Initialized
INFO - 2018-02-07 16:18:19 --> Language Class Initialized
INFO - 2018-02-07 16:18:19 --> Loader Class Initialized
INFO - 2018-02-07 16:18:19 --> Helper loaded: url_helper
INFO - 2018-02-07 16:18:19 --> Helper loaded: file_helper
INFO - 2018-02-07 16:18:19 --> Helper loaded: email_helper
INFO - 2018-02-07 16:18:19 --> Helper loaded: common_helper
INFO - 2018-02-07 16:18:19 --> Database Driver Class Initialized
DEBUG - 2018-02-07 16:18:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 16:18:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 16:18:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-07 16:18:19 --> Pagination Class Initialized
INFO - 2018-02-07 16:18:19 --> Helper loaded: form_helper
INFO - 2018-02-07 16:18:19 --> Form Validation Class Initialized
INFO - 2018-02-07 16:18:19 --> Model Class Initialized
INFO - 2018-02-07 16:18:19 --> Controller Class Initialized
DEBUG - 2018-02-07 16:18:19 --> Config file loaded: /var/www/html/spamblocker/application/config/rest.php
INFO - 2018-02-07 16:18:19 --> Helper loaded: inflector_helper
INFO - 2018-02-07 16:18:19 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 16:18:19 --> Model Class Initialized
INFO - 2018-02-07 16:18:19 --> Model Class Initialized
INFO - 2018-02-07 16:18:19 --> Final output sent to browser
DEBUG - 2018-02-07 16:18:19 --> Total execution time: 0.0054
INFO - 2018-02-07 16:18:26 --> Config Class Initialized
INFO - 2018-02-07 16:18:26 --> Hooks Class Initialized
DEBUG - 2018-02-07 16:18:26 --> UTF-8 Support Enabled
INFO - 2018-02-07 16:18:26 --> Utf8 Class Initialized
INFO - 2018-02-07 16:18:26 --> URI Class Initialized
INFO - 2018-02-07 16:18:26 --> Router Class Initialized
INFO - 2018-02-07 16:18:26 --> Output Class Initialized
INFO - 2018-02-07 16:18:26 --> Security Class Initialized
DEBUG - 2018-02-07 16:18:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 16:18:26 --> Input Class Initialized
INFO - 2018-02-07 16:18:26 --> Language Class Initialized
INFO - 2018-02-07 16:18:26 --> Loader Class Initialized
INFO - 2018-02-07 16:18:26 --> Helper loaded: url_helper
INFO - 2018-02-07 16:18:26 --> Helper loaded: file_helper
INFO - 2018-02-07 16:18:26 --> Helper loaded: email_helper
INFO - 2018-02-07 16:18:26 --> Helper loaded: common_helper
INFO - 2018-02-07 16:18:26 --> Database Driver Class Initialized
DEBUG - 2018-02-07 16:18:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 16:18:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 16:18:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-07 16:18:26 --> Pagination Class Initialized
INFO - 2018-02-07 16:18:26 --> Helper loaded: form_helper
INFO - 2018-02-07 16:18:26 --> Form Validation Class Initialized
INFO - 2018-02-07 16:18:26 --> Model Class Initialized
INFO - 2018-02-07 16:18:26 --> Controller Class Initialized
DEBUG - 2018-02-07 16:18:26 --> Config file loaded: /var/www/html/spamblocker/application/config/rest.php
INFO - 2018-02-07 16:18:26 --> Helper loaded: inflector_helper
INFO - 2018-02-07 16:18:26 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 16:18:26 --> Model Class Initialized
INFO - 2018-02-07 16:18:26 --> Model Class Initialized
INFO - 2018-02-07 16:18:26 --> Final output sent to browser
DEBUG - 2018-02-07 16:18:26 --> Total execution time: 0.0080
INFO - 2018-02-07 16:30:04 --> Config Class Initialized
INFO - 2018-02-07 16:30:04 --> Hooks Class Initialized
DEBUG - 2018-02-07 16:30:04 --> UTF-8 Support Enabled
INFO - 2018-02-07 16:30:04 --> Utf8 Class Initialized
INFO - 2018-02-07 16:30:04 --> URI Class Initialized
INFO - 2018-02-07 16:30:04 --> Router Class Initialized
INFO - 2018-02-07 16:30:04 --> Output Class Initialized
INFO - 2018-02-07 16:30:04 --> Security Class Initialized
DEBUG - 2018-02-07 16:30:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 16:30:04 --> Input Class Initialized
INFO - 2018-02-07 16:30:04 --> Language Class Initialized
INFO - 2018-02-07 16:30:04 --> Loader Class Initialized
INFO - 2018-02-07 16:30:04 --> Helper loaded: url_helper
INFO - 2018-02-07 16:30:04 --> Helper loaded: file_helper
INFO - 2018-02-07 16:30:04 --> Helper loaded: email_helper
INFO - 2018-02-07 16:30:04 --> Helper loaded: common_helper
INFO - 2018-02-07 16:30:04 --> Database Driver Class Initialized
DEBUG - 2018-02-07 16:30:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 16:30:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 16:30:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-07 16:30:04 --> Pagination Class Initialized
INFO - 2018-02-07 16:30:04 --> Helper loaded: form_helper
INFO - 2018-02-07 16:30:04 --> Form Validation Class Initialized
INFO - 2018-02-07 16:30:04 --> Model Class Initialized
INFO - 2018-02-07 16:30:04 --> Controller Class Initialized
DEBUG - 2018-02-07 16:30:04 --> Config file loaded: /var/www/html/spamblocker/application/config/rest.php
INFO - 2018-02-07 16:30:04 --> Helper loaded: inflector_helper
INFO - 2018-02-07 16:30:04 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 16:30:04 --> Model Class Initialized
INFO - 2018-02-07 16:30:04 --> Model Class Initialized
INFO - 2018-02-07 16:32:57 --> Config Class Initialized
INFO - 2018-02-07 16:32:57 --> Hooks Class Initialized
DEBUG - 2018-02-07 16:32:57 --> UTF-8 Support Enabled
INFO - 2018-02-07 16:32:57 --> Utf8 Class Initialized
INFO - 2018-02-07 16:32:57 --> URI Class Initialized
INFO - 2018-02-07 16:32:57 --> Router Class Initialized
INFO - 2018-02-07 16:32:57 --> Output Class Initialized
INFO - 2018-02-07 16:32:57 --> Security Class Initialized
DEBUG - 2018-02-07 16:32:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 16:32:57 --> Input Class Initialized
INFO - 2018-02-07 16:32:57 --> Language Class Initialized
INFO - 2018-02-07 16:32:57 --> Loader Class Initialized
INFO - 2018-02-07 16:32:57 --> Helper loaded: url_helper
INFO - 2018-02-07 16:32:57 --> Helper loaded: file_helper
INFO - 2018-02-07 16:32:57 --> Helper loaded: email_helper
INFO - 2018-02-07 16:32:57 --> Helper loaded: common_helper
INFO - 2018-02-07 16:32:57 --> Database Driver Class Initialized
DEBUG - 2018-02-07 16:32:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 16:32:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 16:32:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-07 16:32:57 --> Pagination Class Initialized
INFO - 2018-02-07 16:32:57 --> Helper loaded: form_helper
INFO - 2018-02-07 16:32:57 --> Form Validation Class Initialized
INFO - 2018-02-07 16:32:57 --> Model Class Initialized
INFO - 2018-02-07 16:32:57 --> Controller Class Initialized
DEBUG - 2018-02-07 16:32:57 --> Config file loaded: /var/www/html/spamblocker/application/config/rest.php
INFO - 2018-02-07 16:32:57 --> Helper loaded: inflector_helper
INFO - 2018-02-07 16:32:57 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 16:32:57 --> Model Class Initialized
INFO - 2018-02-07 16:32:57 --> Model Class Initialized
INFO - 2018-02-07 16:32:57 --> Final output sent to browser
DEBUG - 2018-02-07 16:32:57 --> Total execution time: 0.0088
INFO - 2018-02-07 18:11:53 --> Config Class Initialized
INFO - 2018-02-07 18:11:53 --> Hooks Class Initialized
DEBUG - 2018-02-07 18:11:53 --> UTF-8 Support Enabled
INFO - 2018-02-07 18:11:53 --> Utf8 Class Initialized
INFO - 2018-02-07 18:11:53 --> URI Class Initialized
INFO - 2018-02-07 18:11:53 --> Router Class Initialized
INFO - 2018-02-07 18:11:53 --> Output Class Initialized
INFO - 2018-02-07 18:11:53 --> Security Class Initialized
DEBUG - 2018-02-07 18:11:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 18:11:53 --> Input Class Initialized
INFO - 2018-02-07 18:11:53 --> Language Class Initialized
INFO - 2018-02-07 18:11:53 --> Loader Class Initialized
INFO - 2018-02-07 18:11:53 --> Helper loaded: url_helper
INFO - 2018-02-07 18:11:53 --> Helper loaded: file_helper
INFO - 2018-02-07 18:11:53 --> Helper loaded: email_helper
INFO - 2018-02-07 18:11:53 --> Helper loaded: common_helper
INFO - 2018-02-07 18:11:53 --> Database Driver Class Initialized
DEBUG - 2018-02-07 18:11:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 18:11:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 18:11:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-07 18:11:53 --> Pagination Class Initialized
INFO - 2018-02-07 18:11:53 --> Helper loaded: form_helper
INFO - 2018-02-07 18:11:53 --> Form Validation Class Initialized
INFO - 2018-02-07 18:11:53 --> Model Class Initialized
INFO - 2018-02-07 18:11:53 --> Controller Class Initialized
DEBUG - 2018-02-07 18:11:53 --> Config file loaded: /var/www/html/spamblocker/application/config/rest.php
INFO - 2018-02-07 18:11:53 --> Helper loaded: inflector_helper
INFO - 2018-02-07 18:11:53 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 18:11:53 --> Model Class Initialized
INFO - 2018-02-07 18:11:53 --> Model Class Initialized
INFO - 2018-02-07 18:11:53 --> Final output sent to browser
DEBUG - 2018-02-07 18:11:53 --> Total execution time: 0.0058
INFO - 2018-02-07 18:12:15 --> Config Class Initialized
INFO - 2018-02-07 18:12:15 --> Hooks Class Initialized
DEBUG - 2018-02-07 18:12:15 --> UTF-8 Support Enabled
INFO - 2018-02-07 18:12:15 --> Utf8 Class Initialized
INFO - 2018-02-07 18:12:15 --> URI Class Initialized
INFO - 2018-02-07 18:12:15 --> Router Class Initialized
INFO - 2018-02-07 18:12:15 --> Output Class Initialized
INFO - 2018-02-07 18:12:15 --> Security Class Initialized
DEBUG - 2018-02-07 18:12:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 18:12:15 --> Input Class Initialized
INFO - 2018-02-07 18:12:15 --> Language Class Initialized
INFO - 2018-02-07 18:12:15 --> Loader Class Initialized
INFO - 2018-02-07 18:12:15 --> Helper loaded: url_helper
INFO - 2018-02-07 18:12:15 --> Helper loaded: file_helper
INFO - 2018-02-07 18:12:15 --> Helper loaded: email_helper
INFO - 2018-02-07 18:12:15 --> Helper loaded: common_helper
INFO - 2018-02-07 18:12:15 --> Database Driver Class Initialized
DEBUG - 2018-02-07 18:12:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 18:12:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 18:12:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-07 18:12:15 --> Pagination Class Initialized
INFO - 2018-02-07 18:12:15 --> Helper loaded: form_helper
INFO - 2018-02-07 18:12:15 --> Form Validation Class Initialized
INFO - 2018-02-07 18:12:15 --> Model Class Initialized
INFO - 2018-02-07 18:12:15 --> Controller Class Initialized
DEBUG - 2018-02-07 18:12:15 --> Config file loaded: /var/www/html/spamblocker/application/config/rest.php
INFO - 2018-02-07 18:12:15 --> Helper loaded: inflector_helper
INFO - 2018-02-07 18:12:15 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 18:12:15 --> Model Class Initialized
INFO - 2018-02-07 18:12:15 --> Model Class Initialized
INFO - 2018-02-07 18:12:15 --> Final output sent to browser
DEBUG - 2018-02-07 18:12:15 --> Total execution time: 0.0054
INFO - 2018-02-07 18:14:15 --> Config Class Initialized
INFO - 2018-02-07 18:14:15 --> Hooks Class Initialized
DEBUG - 2018-02-07 18:14:15 --> UTF-8 Support Enabled
INFO - 2018-02-07 18:14:15 --> Utf8 Class Initialized
INFO - 2018-02-07 18:14:15 --> URI Class Initialized
INFO - 2018-02-07 18:14:15 --> Router Class Initialized
INFO - 2018-02-07 18:14:15 --> Output Class Initialized
INFO - 2018-02-07 18:14:15 --> Security Class Initialized
DEBUG - 2018-02-07 18:14:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 18:14:15 --> Input Class Initialized
INFO - 2018-02-07 18:14:15 --> Language Class Initialized
INFO - 2018-02-07 18:14:15 --> Loader Class Initialized
INFO - 2018-02-07 18:14:15 --> Helper loaded: url_helper
INFO - 2018-02-07 18:14:15 --> Helper loaded: file_helper
INFO - 2018-02-07 18:14:15 --> Helper loaded: email_helper
INFO - 2018-02-07 18:14:15 --> Helper loaded: common_helper
INFO - 2018-02-07 18:14:15 --> Database Driver Class Initialized
DEBUG - 2018-02-07 18:14:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 18:14:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 18:14:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-07 18:14:15 --> Pagination Class Initialized
INFO - 2018-02-07 18:14:15 --> Helper loaded: form_helper
INFO - 2018-02-07 18:14:15 --> Form Validation Class Initialized
INFO - 2018-02-07 18:14:15 --> Model Class Initialized
INFO - 2018-02-07 18:14:15 --> Controller Class Initialized
DEBUG - 2018-02-07 18:14:15 --> Config file loaded: /var/www/html/spamblocker/application/config/rest.php
INFO - 2018-02-07 18:14:15 --> Helper loaded: inflector_helper
INFO - 2018-02-07 18:14:15 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 18:14:15 --> Model Class Initialized
INFO - 2018-02-07 18:14:15 --> Model Class Initialized
INFO - 2018-02-07 18:14:15 --> Final output sent to browser
DEBUG - 2018-02-07 18:14:15 --> Total execution time: 0.0559
INFO - 2018-02-07 18:14:19 --> Config Class Initialized
INFO - 2018-02-07 18:14:19 --> Hooks Class Initialized
DEBUG - 2018-02-07 18:14:19 --> UTF-8 Support Enabled
INFO - 2018-02-07 18:14:19 --> Utf8 Class Initialized
INFO - 2018-02-07 18:14:19 --> URI Class Initialized
INFO - 2018-02-07 18:14:19 --> Router Class Initialized
INFO - 2018-02-07 18:14:19 --> Output Class Initialized
INFO - 2018-02-07 18:14:19 --> Security Class Initialized
DEBUG - 2018-02-07 18:14:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 18:14:19 --> Input Class Initialized
INFO - 2018-02-07 18:14:19 --> Language Class Initialized
INFO - 2018-02-07 18:14:19 --> Loader Class Initialized
INFO - 2018-02-07 18:14:19 --> Helper loaded: url_helper
INFO - 2018-02-07 18:14:19 --> Helper loaded: file_helper
INFO - 2018-02-07 18:14:19 --> Helper loaded: email_helper
INFO - 2018-02-07 18:14:19 --> Helper loaded: common_helper
INFO - 2018-02-07 18:14:19 --> Database Driver Class Initialized
DEBUG - 2018-02-07 18:14:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 18:14:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 18:14:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-07 18:14:19 --> Pagination Class Initialized
INFO - 2018-02-07 18:14:19 --> Helper loaded: form_helper
INFO - 2018-02-07 18:14:19 --> Form Validation Class Initialized
INFO - 2018-02-07 18:14:19 --> Model Class Initialized
INFO - 2018-02-07 18:14:19 --> Controller Class Initialized
DEBUG - 2018-02-07 18:14:19 --> Config file loaded: /var/www/html/spamblocker/application/config/rest.php
INFO - 2018-02-07 18:14:19 --> Helper loaded: inflector_helper
INFO - 2018-02-07 18:14:19 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 18:14:19 --> Model Class Initialized
INFO - 2018-02-07 18:14:19 --> Model Class Initialized
INFO - 2018-02-07 18:14:19 --> Final output sent to browser
DEBUG - 2018-02-07 18:14:19 --> Total execution time: 0.0049
INFO - 2018-02-07 18:14:58 --> Config Class Initialized
INFO - 2018-02-07 18:14:58 --> Hooks Class Initialized
DEBUG - 2018-02-07 18:14:58 --> UTF-8 Support Enabled
INFO - 2018-02-07 18:14:58 --> Utf8 Class Initialized
INFO - 2018-02-07 18:14:58 --> URI Class Initialized
INFO - 2018-02-07 18:14:58 --> Router Class Initialized
INFO - 2018-02-07 18:14:58 --> Output Class Initialized
INFO - 2018-02-07 18:14:58 --> Security Class Initialized
DEBUG - 2018-02-07 18:14:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 18:14:58 --> Input Class Initialized
INFO - 2018-02-07 18:14:58 --> Language Class Initialized
INFO - 2018-02-07 18:14:58 --> Loader Class Initialized
INFO - 2018-02-07 18:14:58 --> Helper loaded: url_helper
INFO - 2018-02-07 18:14:58 --> Helper loaded: file_helper
INFO - 2018-02-07 18:14:58 --> Helper loaded: email_helper
INFO - 2018-02-07 18:14:58 --> Helper loaded: common_helper
INFO - 2018-02-07 18:14:58 --> Database Driver Class Initialized
DEBUG - 2018-02-07 18:14:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 18:14:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 18:14:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-07 18:14:58 --> Pagination Class Initialized
INFO - 2018-02-07 18:14:58 --> Helper loaded: form_helper
INFO - 2018-02-07 18:14:58 --> Form Validation Class Initialized
INFO - 2018-02-07 18:14:58 --> Model Class Initialized
INFO - 2018-02-07 18:14:58 --> Controller Class Initialized
DEBUG - 2018-02-07 18:14:58 --> Config file loaded: /var/www/html/spamblocker/application/config/rest.php
INFO - 2018-02-07 18:14:58 --> Helper loaded: inflector_helper
INFO - 2018-02-07 18:14:58 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 18:14:58 --> Model Class Initialized
INFO - 2018-02-07 18:14:58 --> Model Class Initialized
INFO - 2018-02-07 18:14:59 --> Final output sent to browser
DEBUG - 2018-02-07 18:14:59 --> Total execution time: 0.0620
INFO - 2018-02-07 18:15:01 --> Config Class Initialized
INFO - 2018-02-07 18:15:01 --> Hooks Class Initialized
DEBUG - 2018-02-07 18:15:01 --> UTF-8 Support Enabled
INFO - 2018-02-07 18:15:01 --> Utf8 Class Initialized
INFO - 2018-02-07 18:15:01 --> URI Class Initialized
INFO - 2018-02-07 18:15:01 --> Router Class Initialized
INFO - 2018-02-07 18:15:01 --> Output Class Initialized
INFO - 2018-02-07 18:15:01 --> Security Class Initialized
DEBUG - 2018-02-07 18:15:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 18:15:01 --> Input Class Initialized
INFO - 2018-02-07 18:15:01 --> Language Class Initialized
INFO - 2018-02-07 18:15:01 --> Loader Class Initialized
INFO - 2018-02-07 18:15:01 --> Helper loaded: url_helper
INFO - 2018-02-07 18:15:01 --> Helper loaded: file_helper
INFO - 2018-02-07 18:15:01 --> Helper loaded: email_helper
INFO - 2018-02-07 18:15:01 --> Helper loaded: common_helper
INFO - 2018-02-07 18:15:01 --> Database Driver Class Initialized
DEBUG - 2018-02-07 18:15:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 18:15:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 18:15:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-07 18:15:01 --> Pagination Class Initialized
INFO - 2018-02-07 18:15:01 --> Helper loaded: form_helper
INFO - 2018-02-07 18:15:01 --> Form Validation Class Initialized
INFO - 2018-02-07 18:15:01 --> Model Class Initialized
INFO - 2018-02-07 18:15:01 --> Controller Class Initialized
DEBUG - 2018-02-07 18:15:01 --> Config file loaded: /var/www/html/spamblocker/application/config/rest.php
INFO - 2018-02-07 18:15:01 --> Helper loaded: inflector_helper
INFO - 2018-02-07 18:15:01 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 18:15:01 --> Model Class Initialized
INFO - 2018-02-07 18:15:01 --> Model Class Initialized
INFO - 2018-02-07 18:15:01 --> Final output sent to browser
DEBUG - 2018-02-07 18:15:01 --> Total execution time: 0.0053
INFO - 2018-02-07 18:16:06 --> Config Class Initialized
INFO - 2018-02-07 18:16:06 --> Hooks Class Initialized
DEBUG - 2018-02-07 18:16:06 --> UTF-8 Support Enabled
INFO - 2018-02-07 18:16:06 --> Utf8 Class Initialized
INFO - 2018-02-07 18:16:06 --> URI Class Initialized
INFO - 2018-02-07 18:16:06 --> Router Class Initialized
INFO - 2018-02-07 18:16:06 --> Output Class Initialized
INFO - 2018-02-07 18:16:06 --> Security Class Initialized
DEBUG - 2018-02-07 18:16:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 18:16:06 --> Input Class Initialized
INFO - 2018-02-07 18:16:06 --> Language Class Initialized
INFO - 2018-02-07 18:16:06 --> Loader Class Initialized
INFO - 2018-02-07 18:16:06 --> Helper loaded: url_helper
INFO - 2018-02-07 18:16:06 --> Helper loaded: file_helper
INFO - 2018-02-07 18:16:06 --> Helper loaded: email_helper
INFO - 2018-02-07 18:16:06 --> Helper loaded: common_helper
INFO - 2018-02-07 18:16:06 --> Database Driver Class Initialized
DEBUG - 2018-02-07 18:16:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 18:16:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 18:16:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-07 18:16:06 --> Pagination Class Initialized
INFO - 2018-02-07 18:16:06 --> Helper loaded: form_helper
INFO - 2018-02-07 18:16:06 --> Form Validation Class Initialized
INFO - 2018-02-07 18:16:06 --> Model Class Initialized
INFO - 2018-02-07 18:16:06 --> Controller Class Initialized
DEBUG - 2018-02-07 18:16:06 --> Config file loaded: /var/www/html/spamblocker/application/config/rest.php
INFO - 2018-02-07 18:16:06 --> Helper loaded: inflector_helper
INFO - 2018-02-07 18:16:06 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 18:16:06 --> Model Class Initialized
INFO - 2018-02-07 18:16:06 --> Model Class Initialized
INFO - 2018-02-07 18:16:06 --> Final output sent to browser
DEBUG - 2018-02-07 18:16:06 --> Total execution time: 0.0043
INFO - 2018-02-07 18:16:15 --> Config Class Initialized
INFO - 2018-02-07 18:16:15 --> Hooks Class Initialized
DEBUG - 2018-02-07 18:16:15 --> UTF-8 Support Enabled
INFO - 2018-02-07 18:16:15 --> Utf8 Class Initialized
INFO - 2018-02-07 18:16:15 --> URI Class Initialized
INFO - 2018-02-07 18:16:15 --> Router Class Initialized
INFO - 2018-02-07 18:16:15 --> Output Class Initialized
INFO - 2018-02-07 18:16:15 --> Security Class Initialized
DEBUG - 2018-02-07 18:16:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 18:16:15 --> Input Class Initialized
INFO - 2018-02-07 18:16:15 --> Language Class Initialized
INFO - 2018-02-07 18:16:15 --> Loader Class Initialized
INFO - 2018-02-07 18:16:15 --> Helper loaded: url_helper
INFO - 2018-02-07 18:16:15 --> Helper loaded: file_helper
INFO - 2018-02-07 18:16:15 --> Helper loaded: email_helper
INFO - 2018-02-07 18:16:15 --> Helper loaded: common_helper
INFO - 2018-02-07 18:16:15 --> Database Driver Class Initialized
DEBUG - 2018-02-07 18:16:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 18:16:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 18:16:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-07 18:16:15 --> Pagination Class Initialized
INFO - 2018-02-07 18:16:15 --> Helper loaded: form_helper
INFO - 2018-02-07 18:16:15 --> Form Validation Class Initialized
INFO - 2018-02-07 18:16:15 --> Model Class Initialized
INFO - 2018-02-07 18:16:15 --> Controller Class Initialized
DEBUG - 2018-02-07 18:16:15 --> Config file loaded: /var/www/html/spamblocker/application/config/rest.php
INFO - 2018-02-07 18:16:15 --> Helper loaded: inflector_helper
INFO - 2018-02-07 18:16:15 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 18:16:15 --> Model Class Initialized
INFO - 2018-02-07 18:16:15 --> Model Class Initialized
INFO - 2018-02-07 18:16:15 --> Final output sent to browser
DEBUG - 2018-02-07 18:16:15 --> Total execution time: 0.0067
INFO - 2018-02-07 18:16:20 --> Config Class Initialized
INFO - 2018-02-07 18:16:20 --> Hooks Class Initialized
DEBUG - 2018-02-07 18:16:20 --> UTF-8 Support Enabled
INFO - 2018-02-07 18:16:20 --> Utf8 Class Initialized
INFO - 2018-02-07 18:16:20 --> URI Class Initialized
INFO - 2018-02-07 18:16:20 --> Router Class Initialized
INFO - 2018-02-07 18:16:20 --> Output Class Initialized
INFO - 2018-02-07 18:16:20 --> Security Class Initialized
DEBUG - 2018-02-07 18:16:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 18:16:20 --> Input Class Initialized
INFO - 2018-02-07 18:16:20 --> Language Class Initialized
INFO - 2018-02-07 18:16:20 --> Loader Class Initialized
INFO - 2018-02-07 18:16:20 --> Helper loaded: url_helper
INFO - 2018-02-07 18:16:20 --> Helper loaded: file_helper
INFO - 2018-02-07 18:16:20 --> Helper loaded: email_helper
INFO - 2018-02-07 18:16:20 --> Helper loaded: common_helper
INFO - 2018-02-07 18:16:20 --> Database Driver Class Initialized
DEBUG - 2018-02-07 18:16:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 18:16:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 18:16:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-07 18:16:20 --> Pagination Class Initialized
INFO - 2018-02-07 18:16:20 --> Helper loaded: form_helper
INFO - 2018-02-07 18:16:20 --> Form Validation Class Initialized
INFO - 2018-02-07 18:16:20 --> Model Class Initialized
INFO - 2018-02-07 18:16:20 --> Controller Class Initialized
DEBUG - 2018-02-07 18:16:20 --> Config file loaded: /var/www/html/spamblocker/application/config/rest.php
INFO - 2018-02-07 18:16:20 --> Helper loaded: inflector_helper
INFO - 2018-02-07 18:16:20 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 18:16:20 --> Model Class Initialized
INFO - 2018-02-07 18:16:20 --> Model Class Initialized
INFO - 2018-02-07 18:16:20 --> Final output sent to browser
DEBUG - 2018-02-07 18:16:20 --> Total execution time: 0.0063
INFO - 2018-02-07 18:16:26 --> Config Class Initialized
INFO - 2018-02-07 18:16:26 --> Hooks Class Initialized
DEBUG - 2018-02-07 18:16:26 --> UTF-8 Support Enabled
INFO - 2018-02-07 18:16:26 --> Utf8 Class Initialized
INFO - 2018-02-07 18:16:26 --> URI Class Initialized
INFO - 2018-02-07 18:16:26 --> Router Class Initialized
INFO - 2018-02-07 18:16:26 --> Output Class Initialized
INFO - 2018-02-07 18:16:26 --> Security Class Initialized
DEBUG - 2018-02-07 18:16:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 18:16:26 --> Input Class Initialized
INFO - 2018-02-07 18:16:26 --> Language Class Initialized
INFO - 2018-02-07 18:16:26 --> Loader Class Initialized
INFO - 2018-02-07 18:16:26 --> Helper loaded: url_helper
INFO - 2018-02-07 18:16:26 --> Helper loaded: file_helper
INFO - 2018-02-07 18:16:26 --> Helper loaded: email_helper
INFO - 2018-02-07 18:16:26 --> Helper loaded: common_helper
INFO - 2018-02-07 18:16:26 --> Database Driver Class Initialized
DEBUG - 2018-02-07 18:16:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 18:16:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 18:16:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-07 18:16:26 --> Pagination Class Initialized
INFO - 2018-02-07 18:16:26 --> Helper loaded: form_helper
INFO - 2018-02-07 18:16:26 --> Form Validation Class Initialized
INFO - 2018-02-07 18:16:26 --> Model Class Initialized
INFO - 2018-02-07 18:16:26 --> Controller Class Initialized
DEBUG - 2018-02-07 18:16:26 --> Config file loaded: /var/www/html/spamblocker/application/config/rest.php
INFO - 2018-02-07 18:16:26 --> Helper loaded: inflector_helper
INFO - 2018-02-07 18:16:26 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 18:16:26 --> Model Class Initialized
INFO - 2018-02-07 18:16:26 --> Model Class Initialized
INFO - 2018-02-07 18:16:26 --> Final output sent to browser
DEBUG - 2018-02-07 18:16:26 --> Total execution time: 0.0377
INFO - 2018-02-07 18:16:29 --> Config Class Initialized
INFO - 2018-02-07 18:16:29 --> Hooks Class Initialized
DEBUG - 2018-02-07 18:16:29 --> UTF-8 Support Enabled
INFO - 2018-02-07 18:16:29 --> Utf8 Class Initialized
INFO - 2018-02-07 18:16:29 --> URI Class Initialized
INFO - 2018-02-07 18:16:29 --> Router Class Initialized
INFO - 2018-02-07 18:16:29 --> Output Class Initialized
INFO - 2018-02-07 18:16:29 --> Security Class Initialized
DEBUG - 2018-02-07 18:16:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 18:16:29 --> Input Class Initialized
INFO - 2018-02-07 18:16:29 --> Language Class Initialized
INFO - 2018-02-07 18:16:29 --> Loader Class Initialized
INFO - 2018-02-07 18:16:29 --> Helper loaded: url_helper
INFO - 2018-02-07 18:16:29 --> Helper loaded: file_helper
INFO - 2018-02-07 18:16:29 --> Helper loaded: email_helper
INFO - 2018-02-07 18:16:29 --> Helper loaded: common_helper
INFO - 2018-02-07 18:16:29 --> Database Driver Class Initialized
DEBUG - 2018-02-07 18:16:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 18:16:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 18:16:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-07 18:16:29 --> Pagination Class Initialized
INFO - 2018-02-07 18:16:29 --> Helper loaded: form_helper
INFO - 2018-02-07 18:16:29 --> Form Validation Class Initialized
INFO - 2018-02-07 18:16:29 --> Model Class Initialized
INFO - 2018-02-07 18:16:29 --> Controller Class Initialized
DEBUG - 2018-02-07 18:16:29 --> Config file loaded: /var/www/html/spamblocker/application/config/rest.php
INFO - 2018-02-07 18:16:29 --> Helper loaded: inflector_helper
INFO - 2018-02-07 18:16:29 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 18:16:29 --> Model Class Initialized
INFO - 2018-02-07 18:16:29 --> Model Class Initialized
INFO - 2018-02-07 18:16:29 --> Final output sent to browser
DEBUG - 2018-02-07 18:16:29 --> Total execution time: 0.0061
INFO - 2018-02-07 18:16:42 --> Config Class Initialized
INFO - 2018-02-07 18:16:42 --> Hooks Class Initialized
DEBUG - 2018-02-07 18:16:42 --> UTF-8 Support Enabled
INFO - 2018-02-07 18:16:42 --> Utf8 Class Initialized
INFO - 2018-02-07 18:16:42 --> URI Class Initialized
INFO - 2018-02-07 18:16:42 --> Router Class Initialized
INFO - 2018-02-07 18:16:42 --> Output Class Initialized
INFO - 2018-02-07 18:16:42 --> Security Class Initialized
DEBUG - 2018-02-07 18:16:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 18:16:42 --> Input Class Initialized
INFO - 2018-02-07 18:16:42 --> Language Class Initialized
INFO - 2018-02-07 18:16:42 --> Loader Class Initialized
INFO - 2018-02-07 18:16:42 --> Helper loaded: url_helper
INFO - 2018-02-07 18:16:42 --> Helper loaded: file_helper
INFO - 2018-02-07 18:16:42 --> Helper loaded: email_helper
INFO - 2018-02-07 18:16:42 --> Helper loaded: common_helper
INFO - 2018-02-07 18:16:42 --> Database Driver Class Initialized
DEBUG - 2018-02-07 18:16:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 18:16:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 18:16:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-07 18:16:42 --> Pagination Class Initialized
INFO - 2018-02-07 18:16:42 --> Helper loaded: form_helper
INFO - 2018-02-07 18:16:42 --> Form Validation Class Initialized
INFO - 2018-02-07 18:16:42 --> Model Class Initialized
INFO - 2018-02-07 18:16:42 --> Controller Class Initialized
DEBUG - 2018-02-07 18:16:42 --> Config file loaded: /var/www/html/spamblocker/application/config/rest.php
INFO - 2018-02-07 18:16:42 --> Helper loaded: inflector_helper
INFO - 2018-02-07 18:16:42 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 18:16:42 --> Model Class Initialized
INFO - 2018-02-07 18:16:42 --> Model Class Initialized
INFO - 2018-02-07 18:16:42 --> Final output sent to browser
DEBUG - 2018-02-07 18:16:42 --> Total execution time: 0.0568
INFO - 2018-02-07 18:16:43 --> Config Class Initialized
INFO - 2018-02-07 18:16:43 --> Hooks Class Initialized
DEBUG - 2018-02-07 18:16:43 --> UTF-8 Support Enabled
INFO - 2018-02-07 18:16:43 --> Utf8 Class Initialized
INFO - 2018-02-07 18:16:43 --> URI Class Initialized
INFO - 2018-02-07 18:16:43 --> Router Class Initialized
INFO - 2018-02-07 18:16:43 --> Output Class Initialized
INFO - 2018-02-07 18:16:43 --> Security Class Initialized
DEBUG - 2018-02-07 18:16:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 18:16:43 --> Input Class Initialized
INFO - 2018-02-07 18:16:43 --> Language Class Initialized
INFO - 2018-02-07 18:16:43 --> Loader Class Initialized
INFO - 2018-02-07 18:16:43 --> Helper loaded: url_helper
INFO - 2018-02-07 18:16:43 --> Helper loaded: file_helper
INFO - 2018-02-07 18:16:43 --> Helper loaded: email_helper
INFO - 2018-02-07 18:16:43 --> Helper loaded: common_helper
INFO - 2018-02-07 18:16:43 --> Database Driver Class Initialized
DEBUG - 2018-02-07 18:16:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 18:16:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 18:16:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-07 18:16:43 --> Pagination Class Initialized
INFO - 2018-02-07 18:16:43 --> Helper loaded: form_helper
INFO - 2018-02-07 18:16:43 --> Form Validation Class Initialized
INFO - 2018-02-07 18:16:43 --> Model Class Initialized
INFO - 2018-02-07 18:16:43 --> Controller Class Initialized
DEBUG - 2018-02-07 18:16:43 --> Config file loaded: /var/www/html/spamblocker/application/config/rest.php
INFO - 2018-02-07 18:16:43 --> Helper loaded: inflector_helper
INFO - 2018-02-07 18:16:43 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 18:16:43 --> Model Class Initialized
INFO - 2018-02-07 18:16:43 --> Model Class Initialized
INFO - 2018-02-07 18:16:43 --> Final output sent to browser
DEBUG - 2018-02-07 18:16:43 --> Total execution time: 0.0069
INFO - 2018-02-07 18:19:56 --> Config Class Initialized
INFO - 2018-02-07 18:19:56 --> Hooks Class Initialized
DEBUG - 2018-02-07 18:19:56 --> UTF-8 Support Enabled
INFO - 2018-02-07 18:19:56 --> Utf8 Class Initialized
INFO - 2018-02-07 18:19:56 --> URI Class Initialized
INFO - 2018-02-07 18:19:56 --> Router Class Initialized
INFO - 2018-02-07 18:19:56 --> Output Class Initialized
INFO - 2018-02-07 18:19:56 --> Security Class Initialized
DEBUG - 2018-02-07 18:19:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 18:19:56 --> Input Class Initialized
INFO - 2018-02-07 18:19:56 --> Language Class Initialized
INFO - 2018-02-07 18:19:56 --> Loader Class Initialized
INFO - 2018-02-07 18:19:56 --> Helper loaded: url_helper
INFO - 2018-02-07 18:19:56 --> Helper loaded: file_helper
INFO - 2018-02-07 18:19:56 --> Helper loaded: email_helper
INFO - 2018-02-07 18:19:56 --> Helper loaded: common_helper
INFO - 2018-02-07 18:19:56 --> Database Driver Class Initialized
DEBUG - 2018-02-07 18:19:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 18:19:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 18:19:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-07 18:19:56 --> Pagination Class Initialized
INFO - 2018-02-07 18:19:56 --> Helper loaded: form_helper
INFO - 2018-02-07 18:19:56 --> Form Validation Class Initialized
INFO - 2018-02-07 18:19:56 --> Model Class Initialized
INFO - 2018-02-07 18:19:56 --> Controller Class Initialized
DEBUG - 2018-02-07 18:19:56 --> Config file loaded: /var/www/html/spamblocker/application/config/rest.php
INFO - 2018-02-07 18:19:56 --> Helper loaded: inflector_helper
INFO - 2018-02-07 18:19:56 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 18:19:56 --> Model Class Initialized
INFO - 2018-02-07 18:19:56 --> Model Class Initialized
INFO - 2018-02-07 18:19:56 --> Final output sent to browser
DEBUG - 2018-02-07 18:19:56 --> Total execution time: 0.0066
INFO - 2018-02-07 18:38:30 --> Config Class Initialized
INFO - 2018-02-07 18:38:30 --> Hooks Class Initialized
DEBUG - 2018-02-07 18:38:30 --> UTF-8 Support Enabled
INFO - 2018-02-07 18:38:30 --> Utf8 Class Initialized
INFO - 2018-02-07 18:38:30 --> URI Class Initialized
INFO - 2018-02-07 18:38:30 --> Router Class Initialized
INFO - 2018-02-07 18:38:30 --> Output Class Initialized
INFO - 2018-02-07 18:38:30 --> Security Class Initialized
DEBUG - 2018-02-07 18:38:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 18:38:30 --> Input Class Initialized
INFO - 2018-02-07 18:38:30 --> Language Class Initialized
INFO - 2018-02-07 18:38:30 --> Loader Class Initialized
INFO - 2018-02-07 18:38:30 --> Helper loaded: url_helper
INFO - 2018-02-07 18:38:30 --> Helper loaded: file_helper
INFO - 2018-02-07 18:38:30 --> Helper loaded: email_helper
INFO - 2018-02-07 18:38:30 --> Helper loaded: common_helper
INFO - 2018-02-07 18:38:30 --> Database Driver Class Initialized
DEBUG - 2018-02-07 18:38:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 18:38:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 18:38:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-07 18:38:30 --> Pagination Class Initialized
INFO - 2018-02-07 18:38:30 --> Helper loaded: form_helper
INFO - 2018-02-07 18:38:30 --> Form Validation Class Initialized
INFO - 2018-02-07 18:38:30 --> Model Class Initialized
INFO - 2018-02-07 18:38:30 --> Controller Class Initialized
DEBUG - 2018-02-07 18:38:30 --> Config file loaded: /var/www/html/spamblocker/application/config/rest.php
INFO - 2018-02-07 18:38:30 --> Helper loaded: inflector_helper
INFO - 2018-02-07 18:38:30 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 18:38:30 --> Model Class Initialized
INFO - 2018-02-07 18:38:30 --> Model Class Initialized
INFO - 2018-02-07 18:38:30 --> Final output sent to browser
DEBUG - 2018-02-07 18:38:30 --> Total execution time: 0.0062
INFO - 2018-02-07 18:38:39 --> Config Class Initialized
INFO - 2018-02-07 18:38:39 --> Hooks Class Initialized
DEBUG - 2018-02-07 18:38:39 --> UTF-8 Support Enabled
INFO - 2018-02-07 18:38:39 --> Utf8 Class Initialized
INFO - 2018-02-07 18:38:39 --> URI Class Initialized
INFO - 2018-02-07 18:38:39 --> Router Class Initialized
INFO - 2018-02-07 18:38:39 --> Output Class Initialized
INFO - 2018-02-07 18:38:39 --> Security Class Initialized
DEBUG - 2018-02-07 18:38:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 18:38:39 --> Input Class Initialized
INFO - 2018-02-07 18:38:39 --> Language Class Initialized
INFO - 2018-02-07 18:38:39 --> Loader Class Initialized
INFO - 2018-02-07 18:38:39 --> Helper loaded: url_helper
INFO - 2018-02-07 18:38:39 --> Helper loaded: file_helper
INFO - 2018-02-07 18:38:39 --> Helper loaded: email_helper
INFO - 2018-02-07 18:38:39 --> Helper loaded: common_helper
INFO - 2018-02-07 18:38:39 --> Database Driver Class Initialized
DEBUG - 2018-02-07 18:38:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 18:38:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 18:38:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-07 18:38:39 --> Pagination Class Initialized
INFO - 2018-02-07 18:38:39 --> Helper loaded: form_helper
INFO - 2018-02-07 18:38:39 --> Form Validation Class Initialized
INFO - 2018-02-07 18:38:39 --> Model Class Initialized
INFO - 2018-02-07 18:38:39 --> Controller Class Initialized
DEBUG - 2018-02-07 18:38:39 --> Config file loaded: /var/www/html/spamblocker/application/config/rest.php
INFO - 2018-02-07 18:38:39 --> Helper loaded: inflector_helper
INFO - 2018-02-07 18:38:39 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 18:38:39 --> Model Class Initialized
INFO - 2018-02-07 18:38:39 --> Model Class Initialized
INFO - 2018-02-07 18:38:39 --> Final output sent to browser
DEBUG - 2018-02-07 18:38:39 --> Total execution time: 0.0048
INFO - 2018-02-07 18:39:37 --> Config Class Initialized
INFO - 2018-02-07 18:39:37 --> Hooks Class Initialized
DEBUG - 2018-02-07 18:39:37 --> UTF-8 Support Enabled
INFO - 2018-02-07 18:39:37 --> Utf8 Class Initialized
INFO - 2018-02-07 18:39:37 --> URI Class Initialized
INFO - 2018-02-07 18:39:37 --> Router Class Initialized
INFO - 2018-02-07 18:39:37 --> Output Class Initialized
INFO - 2018-02-07 18:39:37 --> Security Class Initialized
DEBUG - 2018-02-07 18:39:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 18:39:37 --> Input Class Initialized
INFO - 2018-02-07 18:39:37 --> Language Class Initialized
INFO - 2018-02-07 18:39:37 --> Loader Class Initialized
INFO - 2018-02-07 18:39:37 --> Helper loaded: url_helper
INFO - 2018-02-07 18:39:37 --> Helper loaded: file_helper
INFO - 2018-02-07 18:39:37 --> Helper loaded: email_helper
INFO - 2018-02-07 18:39:37 --> Helper loaded: common_helper
INFO - 2018-02-07 18:39:37 --> Database Driver Class Initialized
DEBUG - 2018-02-07 18:39:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 18:39:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 18:39:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-07 18:39:37 --> Pagination Class Initialized
INFO - 2018-02-07 18:39:37 --> Helper loaded: form_helper
INFO - 2018-02-07 18:39:37 --> Form Validation Class Initialized
INFO - 2018-02-07 18:39:37 --> Model Class Initialized
INFO - 2018-02-07 18:39:37 --> Controller Class Initialized
DEBUG - 2018-02-07 18:39:37 --> Config file loaded: /var/www/html/spamblocker/application/config/rest.php
INFO - 2018-02-07 18:39:37 --> Helper loaded: inflector_helper
INFO - 2018-02-07 18:39:37 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 18:39:37 --> Model Class Initialized
INFO - 2018-02-07 18:39:37 --> Model Class Initialized
INFO - 2018-02-07 18:39:37 --> Final output sent to browser
DEBUG - 2018-02-07 18:39:37 --> Total execution time: 0.0052
INFO - 2018-02-07 18:39:47 --> Config Class Initialized
INFO - 2018-02-07 18:39:47 --> Hooks Class Initialized
DEBUG - 2018-02-07 18:39:47 --> UTF-8 Support Enabled
INFO - 2018-02-07 18:39:47 --> Utf8 Class Initialized
INFO - 2018-02-07 18:39:47 --> URI Class Initialized
INFO - 2018-02-07 18:39:47 --> Router Class Initialized
INFO - 2018-02-07 18:39:47 --> Output Class Initialized
INFO - 2018-02-07 18:39:47 --> Security Class Initialized
DEBUG - 2018-02-07 18:39:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 18:39:47 --> Input Class Initialized
INFO - 2018-02-07 18:39:47 --> Language Class Initialized
INFO - 2018-02-07 18:39:47 --> Loader Class Initialized
INFO - 2018-02-07 18:39:47 --> Helper loaded: url_helper
INFO - 2018-02-07 18:39:47 --> Helper loaded: file_helper
INFO - 2018-02-07 18:39:47 --> Helper loaded: email_helper
INFO - 2018-02-07 18:39:47 --> Helper loaded: common_helper
INFO - 2018-02-07 18:39:47 --> Database Driver Class Initialized
DEBUG - 2018-02-07 18:39:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 18:39:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 18:39:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-07 18:39:47 --> Pagination Class Initialized
INFO - 2018-02-07 18:39:47 --> Helper loaded: form_helper
INFO - 2018-02-07 18:39:47 --> Form Validation Class Initialized
INFO - 2018-02-07 18:39:47 --> Model Class Initialized
INFO - 2018-02-07 18:39:47 --> Controller Class Initialized
DEBUG - 2018-02-07 18:39:47 --> Config file loaded: /var/www/html/spamblocker/application/config/rest.php
INFO - 2018-02-07 18:39:47 --> Helper loaded: inflector_helper
INFO - 2018-02-07 18:39:47 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 18:39:47 --> Model Class Initialized
INFO - 2018-02-07 18:39:47 --> Model Class Initialized
INFO - 2018-02-07 18:39:47 --> Model Class Initialized
INFO - 2018-02-07 18:39:47 --> Email Class Initialized
INFO - 2018-02-07 18:39:47 --> Language file loaded: language/english/email_lang.php
INFO - 2018-02-07 18:39:51 --> Final output sent to browser
DEBUG - 2018-02-07 18:39:51 --> Total execution time: 4.4536
INFO - 2018-02-07 18:44:02 --> Config Class Initialized
INFO - 2018-02-07 18:44:02 --> Hooks Class Initialized
DEBUG - 2018-02-07 18:44:02 --> UTF-8 Support Enabled
INFO - 2018-02-07 18:44:02 --> Utf8 Class Initialized
INFO - 2018-02-07 18:44:02 --> URI Class Initialized
INFO - 2018-02-07 18:44:02 --> Router Class Initialized
INFO - 2018-02-07 18:44:02 --> Output Class Initialized
INFO - 2018-02-07 18:44:02 --> Security Class Initialized
DEBUG - 2018-02-07 18:44:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 18:44:02 --> Input Class Initialized
INFO - 2018-02-07 18:44:02 --> Language Class Initialized
INFO - 2018-02-07 18:44:02 --> Loader Class Initialized
INFO - 2018-02-07 18:44:02 --> Helper loaded: url_helper
INFO - 2018-02-07 18:44:02 --> Helper loaded: file_helper
INFO - 2018-02-07 18:44:02 --> Helper loaded: email_helper
INFO - 2018-02-07 18:44:02 --> Helper loaded: common_helper
INFO - 2018-02-07 18:44:02 --> Database Driver Class Initialized
DEBUG - 2018-02-07 18:44:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 18:44:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 18:44:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-07 18:44:02 --> Pagination Class Initialized
INFO - 2018-02-07 18:44:02 --> Helper loaded: form_helper
INFO - 2018-02-07 18:44:02 --> Form Validation Class Initialized
INFO - 2018-02-07 18:44:02 --> Model Class Initialized
INFO - 2018-02-07 18:44:02 --> Controller Class Initialized
DEBUG - 2018-02-07 18:44:02 --> Config file loaded: /var/www/html/spamblocker/application/config/rest.php
INFO - 2018-02-07 18:44:02 --> Helper loaded: inflector_helper
INFO - 2018-02-07 18:44:02 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 18:44:02 --> Model Class Initialized
INFO - 2018-02-07 18:44:02 --> Model Class Initialized
INFO - 2018-02-07 18:44:02 --> Final output sent to browser
DEBUG - 2018-02-07 18:44:02 --> Total execution time: 0.0414
INFO - 2018-02-07 18:44:37 --> Config Class Initialized
INFO - 2018-02-07 18:44:37 --> Hooks Class Initialized
DEBUG - 2018-02-07 18:44:37 --> UTF-8 Support Enabled
INFO - 2018-02-07 18:44:37 --> Utf8 Class Initialized
INFO - 2018-02-07 18:44:37 --> URI Class Initialized
INFO - 2018-02-07 18:44:37 --> Router Class Initialized
INFO - 2018-02-07 18:44:37 --> Output Class Initialized
INFO - 2018-02-07 18:44:37 --> Security Class Initialized
DEBUG - 2018-02-07 18:44:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 18:44:37 --> Input Class Initialized
INFO - 2018-02-07 18:44:37 --> Language Class Initialized
INFO - 2018-02-07 18:44:37 --> Loader Class Initialized
INFO - 2018-02-07 18:44:37 --> Helper loaded: url_helper
INFO - 2018-02-07 18:44:37 --> Helper loaded: file_helper
INFO - 2018-02-07 18:44:37 --> Helper loaded: email_helper
INFO - 2018-02-07 18:44:37 --> Helper loaded: common_helper
INFO - 2018-02-07 18:44:37 --> Database Driver Class Initialized
DEBUG - 2018-02-07 18:44:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 18:44:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 18:44:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-07 18:44:37 --> Pagination Class Initialized
INFO - 2018-02-07 18:44:37 --> Helper loaded: form_helper
INFO - 2018-02-07 18:44:37 --> Form Validation Class Initialized
INFO - 2018-02-07 18:44:37 --> Model Class Initialized
INFO - 2018-02-07 18:44:37 --> Controller Class Initialized
DEBUG - 2018-02-07 18:44:37 --> Config file loaded: /var/www/html/spamblocker/application/config/rest.php
INFO - 2018-02-07 18:44:37 --> Helper loaded: inflector_helper
INFO - 2018-02-07 18:44:37 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 18:44:37 --> Model Class Initialized
INFO - 2018-02-07 18:44:37 --> Model Class Initialized
INFO - 2018-02-07 18:44:37 --> Final output sent to browser
DEBUG - 2018-02-07 18:44:37 --> Total execution time: 0.1551
INFO - 2018-02-07 18:50:17 --> Config Class Initialized
INFO - 2018-02-07 18:50:17 --> Hooks Class Initialized
DEBUG - 2018-02-07 18:50:17 --> UTF-8 Support Enabled
INFO - 2018-02-07 18:50:17 --> Utf8 Class Initialized
INFO - 2018-02-07 18:50:17 --> URI Class Initialized
INFO - 2018-02-07 18:50:17 --> Router Class Initialized
INFO - 2018-02-07 18:50:17 --> Output Class Initialized
INFO - 2018-02-07 18:50:17 --> Security Class Initialized
DEBUG - 2018-02-07 18:50:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 18:50:17 --> Input Class Initialized
INFO - 2018-02-07 18:50:17 --> Language Class Initialized
INFO - 2018-02-07 18:50:17 --> Loader Class Initialized
INFO - 2018-02-07 18:50:17 --> Helper loaded: url_helper
INFO - 2018-02-07 18:50:17 --> Helper loaded: file_helper
INFO - 2018-02-07 18:50:17 --> Helper loaded: email_helper
INFO - 2018-02-07 18:50:17 --> Helper loaded: common_helper
INFO - 2018-02-07 18:50:17 --> Database Driver Class Initialized
DEBUG - 2018-02-07 18:50:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 18:50:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 18:50:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-07 18:50:17 --> Pagination Class Initialized
INFO - 2018-02-07 18:50:17 --> Helper loaded: form_helper
INFO - 2018-02-07 18:50:17 --> Form Validation Class Initialized
INFO - 2018-02-07 18:50:17 --> Model Class Initialized
INFO - 2018-02-07 18:50:17 --> Controller Class Initialized
DEBUG - 2018-02-07 18:50:17 --> Config file loaded: /var/www/html/spamblocker/application/config/rest.php
INFO - 2018-02-07 18:50:17 --> Helper loaded: inflector_helper
INFO - 2018-02-07 18:50:17 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 18:50:17 --> Model Class Initialized
INFO - 2018-02-07 18:50:17 --> Model Class Initialized
INFO - 2018-02-07 18:50:17 --> Model Class Initialized
INFO - 2018-02-07 18:50:17 --> Email Class Initialized
INFO - 2018-02-07 18:50:18 --> Language file loaded: language/english/email_lang.php
INFO - 2018-02-07 18:50:21 --> Final output sent to browser
DEBUG - 2018-02-07 18:50:21 --> Total execution time: 3.5360
INFO - 2018-02-07 18:50:46 --> Config Class Initialized
INFO - 2018-02-07 18:50:46 --> Hooks Class Initialized
DEBUG - 2018-02-07 18:50:46 --> UTF-8 Support Enabled
INFO - 2018-02-07 18:50:46 --> Utf8 Class Initialized
INFO - 2018-02-07 18:50:46 --> URI Class Initialized
INFO - 2018-02-07 18:50:46 --> Router Class Initialized
INFO - 2018-02-07 18:50:46 --> Output Class Initialized
INFO - 2018-02-07 18:50:46 --> Security Class Initialized
DEBUG - 2018-02-07 18:50:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 18:50:46 --> Input Class Initialized
INFO - 2018-02-07 18:50:46 --> Language Class Initialized
INFO - 2018-02-07 18:50:46 --> Loader Class Initialized
INFO - 2018-02-07 18:50:46 --> Helper loaded: url_helper
INFO - 2018-02-07 18:50:46 --> Helper loaded: file_helper
INFO - 2018-02-07 18:50:46 --> Helper loaded: email_helper
INFO - 2018-02-07 18:50:46 --> Helper loaded: common_helper
INFO - 2018-02-07 18:50:46 --> Database Driver Class Initialized
DEBUG - 2018-02-07 18:50:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 18:50:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 18:50:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-07 18:50:46 --> Pagination Class Initialized
INFO - 2018-02-07 18:50:46 --> Helper loaded: form_helper
INFO - 2018-02-07 18:50:46 --> Form Validation Class Initialized
INFO - 2018-02-07 18:50:46 --> Model Class Initialized
INFO - 2018-02-07 18:50:46 --> Controller Class Initialized
INFO - 2018-02-07 18:50:46 --> Model Class Initialized
INFO - 2018-02-07 18:50:46 --> File loaded: /var/www/html/spamblocker/application/views/index/resetPassword.php
INFO - 2018-02-07 18:50:46 --> Final output sent to browser
DEBUG - 2018-02-07 18:50:46 --> Total execution time: 0.0053

<?php 

function __construct(){
		parent::__construct();
		
		
		$this->load->library('pdf');
		
		//$this->load->model('User_model');
	}
	
$content=$this->load->view('email_template/outStandingAdmin',$data,true);
			$output='';
			$output=$this->pdf->create($content, $value['name']);
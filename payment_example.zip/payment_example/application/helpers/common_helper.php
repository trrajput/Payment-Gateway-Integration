<?php 
    
    function public_path($type="www")
    {
        return base_url()."public/";
    }

    function base_path($type="www")
    {
      return base_url();
    }

    function index_path($type="www")
    {
      return base_url()."index/";
    }

    function admin_path($type="www")
    {
      return base_url()."admin/";
    }

    function profile_img_path($type="www")
    {
        return base_url()."public/uploads/profile_images/";
    }
    function upload_path($type="www")
    {
        return base_url()."public/uploads/";
    }

    function translate($text)
    {
      $CI =& get_instance();
      $line=$CI->lang->line($text);
      if(empty($line))
      {
        $line=$text;
      }
      
      return $line;
    }

    function is_login()
    {

      $CI =& get_instance();
      $session = $CI->session->userdata('admin_session');
      if (!isset($session['admin_id'])) {
        redirect(base_url());
      }
    }

    function pr($arr, $option="")
    {
      echo "<pre>";
      print_r($arr);
      echo "</pre>";
      if ($option != "") {
        exit();
      }
    }

    function get_active_tab($tab)
    {
      $CI =& get_instance();
        if ($CI->router->fetch_class() == $tab) {
            return 'active';
        }
    }
    function randomString() 
    {

       $alphabet = "abcdefghijkmnopqrstuwxyzABCDEFGHJKLMNOPQRSTUWXYZ0123456789";
       $pass = array(); //remember to declare $pass as an array
       $alphaLength = strlen($alphabet) - 1; //put the length -1 in cache
       for ($i = 0; $i < 15; $i++) {
           $n = rand(0, $alphaLength);
           $pass[] = $alphabet[$n];
       }
       return implode($pass); //turn the array into a string
    } 



 	function generatePIN($digits = 4){
	    $i = 0; //counter
	    $pin = ""; //our default pin is blank.
	    while($i < $digits){
	        //generate a random number between 0 and 9.
	        $pin .= mt_rand(0, 9);
	        $i++;
	    }
	    return $pin;
	}

	function sendEmail($list,$subject,$content,$attachment=array())	
  {
    		
        
    $ci =& get_instance();
    $ci->load->library('email');
		$config['protocol'] = PROTOCOL;
		$config['smtp_crypto'] = SMTP_CRYPTO;
		$config['smtp_host'] = SMTP_HOST;
		$config['smtp_port'] = SMTP_PORT;
		$config['smtp_user'] = SMTP_USERNAME; 
		$config['smtp_pass'] = SMTP_PASSWORD;
		$config['charset'] = "utf-8";
		$config['mailtype'] = "html";
		$config['newline'] = "\r\n";
		$ci->email->initialize($config);
		$ci->email->from(FROM_EMAIL, FROM_NAME);
		//$list = array('manali@parextech.com');
		foreach($attachment as $k=>$v){
			$ci->email->attach($v);	
		}
		
		$ci->email->to($list);
		$ci->email->bcc(BCC);
		$ci->email->reply_to(REPLY_TO, REPLY_NAME);
		$ci->email->subject($subject);
		$ci->email->message($content);
		$email_Sent=$ci->email->send();
        return $email_Sent;
    }

    function sendGiftTpl($details)
    {
        $CI =& get_instance();

        $CI->load->model('Emailtemplate_model');

        $templateData = $CI->Emailtemplate_model->fetchTemplateData('vTemplateName','giftLink');

        $TemplateHtml = $templateData['txTemplate'];
        
        foreach ($details as $key => $value) {
            $TemplateHtml = str_replace("{{".$key."}}",$value,$TemplateHtml);
        }

        return $TemplateHtml;
    }

    function forgotTpl($details)
    {
        $CI =& get_instance();

        $CI->load->model('Emailtemplate_model');

        $templateData = $CI->Emailtemplate_model->fetchTemplateData('vTemplateName','resetPassword');

        $TemplateHtml = $templateData['txTemplate'];
        
        foreach ($details as $key => $value) {
            $TemplateHtml = str_replace("{{".$key."}}",$value,$TemplateHtml);
        }

        return $TemplateHtml;
    }

    function send_ios_notification($deviceToken,$message)
    {
      $ctx = stream_context_create();
      stream_context_set_option($ctx, 'ssl', 'local_cert', DOC_ROOT_PUBLIC_PATH.PUSHNOTIFACTIONFILE);
      stream_context_set_option($ctx, 'ssl', 'passphrase', PASSPHRASE);
      // Open a connection to the APNS server
      $fp = stream_socket_client(
      'ssl://gateway.sandbox.push.apple.com:2195', $err,  // For development
      // 'ssl://gateway.push.apple.com:2195', $err, // for production
      $errstr, 60, STREAM_CLIENT_CONNECT|STREAM_CLIENT_PERSISTENT, $ctx);
      if (!$fp)
      exit("Failed to connect: $err $errstr" . PHP_EOL);
      //echo 'Connected to APNS' . PHP_EOL;
      // Create the payload body
      $body['aps'] = array(
      'alert' => trim($message),
      'sound' =>'default'
      );
      // Encode the payload as JSON
      $payload = json_encode($body);
      // Build the binary notification
      $msg = chr(0) . pack('n', 32) . pack('H*', trim($deviceToken)) . pack('n', strlen($payload)) . $payload;
      // Send it to the server
      $result = fwrite($fp, $msg, strlen($msg));
      if (!$result){
      //echo 'Message not delivered' . PHP_EOL;
        return "error";
      }
      else
      {
      //echo 'Message successfully delivered' . PHP_EOL;
      return $result;
      }
      // Close the connection to the server
      fclose($fp);
    }


    function backgroundPost($url) {
        $parts = parse_url($url);
        $fp = fsockopen($parts['host'], isset($parts['port']) ? $parts['port'] : 80, $errno, $errstr, 30);

        if (!$fp) {
            return false;
        } else {

            if (!isset($parts['query'])) {
                $query = '';
            } else {
                $query = $parts['query'];
            }
            $out = "GET " . $parts['path']."?".$query . " HTTP/1.1\r\n";
            $out.= "Host: " . $parts['host'] . "\r\n";
            $out.= "Content-Type: application/x-www-form-urlencoded\r\n";
            $out.= "Content-Length: " . strlen($query) . "\r\n";
            $out.= "Connection: Close\r\n\r\n";
            $out.= $query;
            fwrite($fp, $out);
            fclose($fp);
            return true;
        }
    }

  



?>
<?php 
defined('BASEPATH') OR exit('No direct script access allowed');

class My_controller extends CI_Controller {
public function __construct() {
        parent::__construct();
        $this->load->database();
        $this->load->helper('url');       
    }
 public function index(){
    $query=$this->db->get('employee_details');
    $data['employees']=$query->result();
    $this->load->view('payu_payment/index',$data);
 }
 public function verify($emp_id){
     $this->db->where('emp_id',$emp_id);
     $query=$this->db->get('employee_details');
     $employees=$query->result();
     // all values are required when post by form
   /* $amount =  $this->input->post('payble_amount');
    $product_info = $this->input->post('product_info');
    $customer_name = $this->input->post('customer_name');
    $customer_emial = $this->input->post('customer_email');
    $customer_mobile = $this->input->post('mobile_number');
    $customer_address = $this->input->post('customer_address');*/
    // get form id 
    $amount =  $employees[0]->emp_salary;
    $product_info = "Salary";
    $customer_name = $employees[0]->emp_name;
    $customer_emial = $employees[0]->emp_email;
    $customer_mobile = $employees[0]->emp_mobile;
    $customer_address = $employees[0]->emp_address;
    //payumoney details
    
    
        $MERCHANT_KEY = "rjQUPktU"; //change  merchant with yours
        $SALT = "e5iIg1jwi8";  //change salt with yours 

        $txnid = substr(hash('sha256', mt_rand() . microtime()), 0, 20);
        //optional udf values 
        $udf1 = $emp_id;
        $udf2 = '';
        $udf3 = '';
        $udf4 = '';
        $udf5 = '';
        
         $hashstring = $MERCHANT_KEY . '|' . $txnid . '|' . $amount . '|' . $product_info . '|' . $customer_name . '|' . $customer_emial . '|' . $udf1 . '|' . $udf2 . '|' . $udf3 . '|' . $udf4 . '|' . $udf5 . '||||||' . $SALT;
         $hash = strtolower(hash('sha512', $hashstring));
         
       $success = base_url() . 'Status';  
        $fail = base_url() . 'Status';
        $cancel = base_url() . 'Status';
        
        
         $data = array(
            'mkey' => $MERCHANT_KEY,
            'tid' => $txnid,
            'hash' => $hash,
            'amount' => $amount,           
            'name' => $customer_name,
            'udf1' => $udf1,
            //'udf2' => $udf2,
            'productinfo' => $product_info,
            'mailid' => $customer_emial,
            'phoneno' => $customer_mobile,
            'address' => $customer_address,
            'action' => "https://test.payu.in", //for live change action  https://secure.payu.in  //client test cred https://sandboxsecure.payu.in
            'sucess' => $success,
            'failure' => $fail,
            'cancel' => $cancel            
        );
        $this->load->view('payu_payment/confirmation', $data);   
     }
   
    
   }

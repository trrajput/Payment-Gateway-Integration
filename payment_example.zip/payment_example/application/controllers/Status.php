<?php 
defined('BASEPATH') OR exit('No direct script access allowed');
class Status extends CI_Controller {
public function __construct() {
        parent::__construct();
        $this->load->helper('url');      
        $this->load->database();
    }
public function index() {
       $status = $this->input->post('status');
      if (empty($status)) {
            redirect('My_controller');
        }
       
        $firstname = $this->input->post('firstname');
        $amount = $this->input->post('amount');
        $txnid = $this->input->post('txnid');
        $posted_hash = $this->input->post('hash');
        $key = $this->input->post('key');
        $productinfo = $this->input->post('productinfo');
        $email = $this->input->post('email');
        $mode = $this->input->post('mode');
        $name_on_card = $this->input->post('name_on_card');
        $bank_ref_num = $this->input->post('bank_ref_num');
        $udf1 = $this->input->post('udf1');
        $udf1 = $this->input->post('udf1');
        $salt = "e5iIg1jwi8"; //  Your salt
        $add = $this->input->post('additionalCharges');
        If (isset($add)) {
            $additionalCharges = $this->input->post('additionalCharges');
            $retHashSeq = $additionalCharges . '|' . $salt . '|' . $status . '|||||||||||' . $email . '|' . $firstname . '|' . $productinfo . '|' . $amount . '|' . $txnid . '|' . $key;
        } else {

            $retHashSeq = $salt . '|' . $status . '|||||||||||' . $email . '|' . $firstname . '|' . $productinfo . '|' . $amount . '|' . $txnid . '|' . $key;
        }
         $data['hash'] = hash("sha512", $retHashSeq);
          $data['amount'] = $amount;
          $data['txnid'] = $txnid;
          $data['posted_hash'] = $posted_hash;
          $data['status'] = $status;
          $inset_data=array(
            'txn_id'=>$txnid,
            'emp_id'=>$udf1,
            'email'=>$email,
            'mode'=>$mode,
            'name'=>$name_on_card,
            'bank_ref_num'=>$name_on_card,
            'amount'=>$amount,
            'status'=>$status,
          );
          if($status == 'success'){
              //$query=$this->db->insert('emp_transaction',$inset_data);
               
              $this->load->view('payu_payment/success', $data);   
         }
         else{
              //$query=$this->db->insert('emp_transaction',$inset_data);
              $this->load->view('payu_payment/fail', $data); 
         }
     
    }
 
    
   }
